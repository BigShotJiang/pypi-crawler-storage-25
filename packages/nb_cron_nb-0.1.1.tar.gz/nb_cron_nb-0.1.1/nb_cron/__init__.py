"""
nb_cron - A powerful and simple cron job scheduler that dominates APScheduler.

Usage::

    from nb_cron import NbCron, cron_register, explain_cron

    cron = NbCron("my_project")  # name 必传，隔离不同项目

    @cron.job("0 */5 * * * *")
    @cron_register('my_task')
    def my_task():
        print("every 5 minutes")

    cron.start()  # 不阻塞，Ctrl+C 退出
"""

from nb_cron._version import __version__
from nb_cron.core.registry import add_cron_register, cron_register
from nb_cron.core.scheduler import NbCron
from nb_cron.cron_utils.translator import explain_cron
from nb_cron.executors.base_executor import BaseExecutor
from nb_cron.executors.thread_executor import ThreadExecutor

__all__ = [
    "NbCron",
    "cron_register",
    "add_cron_register",
    "explain_cron",
    "BaseExecutor",
    "ThreadExecutor",
    "__version__",
]
