# alpaca-market-mcp

MCP server for technical analysis with Alpaca market data. Computes Bollinger Bands, Moving Averages, Stochastics, candlestick patterns, and evaluates 11 trading strategies - all server-side, no Python execution needed on the client.

## Installation

```bash
# Via uvx (recommended)
uvx alpaca-market-mcp

# Via pip
pip install alpaca-market-mcp
```

## Configuration

### Claude Desktop / Claude.ai

Add to your MCP config:

```json
{
  "mcpServers": {
    "alpaca-market": {
      "command": "uvx",
      "args": ["alpaca-market-mcp"],
      "env": {
        "ALPACA_API_KEY": "your-api-key",
        "ALPACA_SECRET_KEY": "your-secret-key"
      }
    }
  }
}
```

### Claude Code

Add to `.mcp.json`:

```json
{
  "mcpServers": {
    "alpaca-market": {
      "command": "uvx",
      "args": ["alpaca-market-mcp", "--feed", "iex"],
      "env": {
        "ALPACA_API_KEY": "your-api-key",
        "ALPACA_SECRET_KEY": "your-secret-key"
      }
    }
  }
}
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ALPACA_API_KEY` | Yes | Alpaca API key |
| `ALPACA_SECRET_KEY` | Yes | Alpaca secret key |

## CLI Options

```
alpaca-market-mcp [OPTIONS]

Options:
  --transport [stdio|streamable-http|sse]  Transport protocol (default: stdio)
  --host TEXT                               Host to bind (HTTP only)
  --port INTEGER                            Port to bind (HTTP only)
  --feed [iex|sip|otc]                      Data feed (default: iex)
  --env-file PATH                           Load env vars from file
```

## Tools

### `analyze_ticker`
Full multi-timeframe technical analysis (15min, 1h, 1d). Returns Bollinger Bands, Moving Averages (SMA 20/40/100/200), candlestick patterns, volume, and Stochastics.

### `check_strategy`
Evaluate the 11 trading strategies from the options course. Returns condition-by-condition pass/fail with CUMPLIDA/PARCIAL/NO CUMPLIDA status.

### `get_indicators`
Get a specific indicator's values for a single timeframe. Supports: bb, sma, ema, stoch, rsi, macd, atr, volume, candles.

### `scan_tickers`
Scan multiple tickers for trading signals and active strategies.

### `get_stock_bars_with_indicators`
Historical OHLCV bars with indicator columns attached.

## Indicators

| Indicator | Weight | Parameters |
|-----------|--------|------------|
| Bollinger Bands | 50% | Period 20, Std 2.0 |
| Moving Averages | 25% | SMA 20, 40, 100, 200 |
| Candlestick Patterns | 15% | Body ratio classification |
| Volume | 5% | SMA(20) ratio |
| Worden Stochastics | 5% | K=14, D=3, Smooth=3 |

## 11 Trading Strategies

| # | Strategy | Action |
|---|----------|--------|
| 1 | Cambio tendencia al alza (BB Hora) | CALL |
| 2 | Cambio tendencia a la baja (BB Hora) | PUT |
| 3 | Rebote punto medio bajista (BB Dia) | PUT |
| 4 | Rebote punto medio alcista (BB Dia) | CALL |
| 5 | Salido BB sin volatilidad al alza (15 Min) | PUT |
| 6 | Efecto iman bajista (MA Hora + BB 15 Min) | CALL |
| 7 | Efecto iman alcista (MA Hora + BB 15 Min) | PUT |
| 8 | Cambio tendencia al alza (BB 15 Min) | CALL |
| 9 | Cambio tendencia a la baja (BB 15 Min) | PUT |
| 10 | Lateral a alcista mediano plazo (MAs) | CALL |
| 11 | Lateral a bajista mediano plazo (MAs) | PUT |

## Development

```bash
# Install dev dependencies
uv pip install -e ".[dev]"

# Run tests
uv run pytest

# Lint
uv run ruff check src/
```

## License

MIT
