"""Formatting helpers for technical analysis output.

Only utility functions - no print statements. The MCP returns dicts, not stdout.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def fmt(val, decimals: int = 2) -> str:
    """Format a numeric value for display."""
    if val is None or (isinstance(val, float) and (np.isnan(val) or np.isinf(val))):
        return "--"
    if isinstance(val, float):
        return f"{val:,.{decimals}f}"
    if isinstance(val, int):
        return f"{val:,}"
    return str(val)


def fmt_pct(val, decimals: int = 2) -> str:
    """Format as percentage."""
    if val is None or (isinstance(val, float) and np.isnan(val)):
        return "--"
    return f"{val:+.{decimals}f}%"


def fmt_ts(ts, timeframe: str = "1Day") -> str:
    """Format timestamp based on timeframe."""
    if pd.isna(ts):
        return "--"
    if isinstance(ts, pd.Timestamp):
        ts = ts.to_pydatetime()
    if timeframe in ("1Day", "1Week", "1Month"):
        return ts.strftime("%Y-%m-%d")
    return ts.strftime("%Y-%m-%d %H:%M")


def tf_display(tf: str) -> str:
    """Human-readable timeframe label."""
    labels = {
        "1Min": "1 Min",
        "5Min": "5 Min",
        "15Min": "15 Min",
        "30Min": "30 Min",
        "1Hour": "1 Hora",
        "1Day": "1 Dia",
        "1Week": "Semanal",
        "1Month": "Mensual",
    }
    return labels.get(tf, tf)
