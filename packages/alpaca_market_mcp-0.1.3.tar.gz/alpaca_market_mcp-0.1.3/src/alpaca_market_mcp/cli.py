"""CLI entry point for the Alpaca Market Analysis MCP Server."""

import os
import sys
from pathlib import Path
from typing import Optional

import click

from . import __version__


@click.command()
@click.version_option(version=__version__, prog_name="alpaca-market-mcp")
@click.option(
    "--transport",
    type=click.Choice(["stdio", "streamable-http", "sse"]),
    default="stdio",
    help="Transport protocol (default: stdio)",
)
@click.option("--host", default="127.0.0.1", help="Host to bind (HTTP transport only)")
@click.option("--port", type=int, default=8000, help="Port to bind (HTTP transport only)")
@click.option(
    "--feed",
    type=click.Choice(["iex", "sip", "otc"]),
    default="iex",
    help="Alpaca data feed: iex (free), sip (paid real-time). Default: iex",
)
@click.option(
    "--env-file",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Load environment variables from this file before starting",
)
def main(transport: str, host: str, port: int, feed: str, env_file: Optional[Path]):
    """Alpaca Market Analysis MCP Server - Technical indicators and trading strategies."""
    if env_file is not None:
        from dotenv import load_dotenv

        load_dotenv(env_file, override=False)

    if not os.environ.get("ALPACA_API_KEY") or not os.environ.get("ALPACA_SECRET_KEY"):
        click.echo(
            "Error: ALPACA_API_KEY and ALPACA_SECRET_KEY must be set.\n"
            "Set them in your MCP client config's env block or pass --env-file.",
            err=True,
        )
        sys.exit(1)

    from .server import build_server

    server = build_server(feed=feed)

    if transport == "stdio":
        server.run(transport="stdio")
    else:
        server.run(transport=transport, host=host, port=port)
