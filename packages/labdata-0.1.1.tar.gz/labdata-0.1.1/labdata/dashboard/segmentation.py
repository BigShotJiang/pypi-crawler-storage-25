import base64
import io
import pandas as pd
import streamlit as st
import numpy as np

MAX_PICKED = 3


def _normalize_image(img):
    img = np.asarray(img, dtype=float)
    lo, hi = img.min(), img.max()
    if hi > lo:
        img = (img - lo) / (hi - lo)
    return (img * 255).clip(0, 255).astype(np.uint8)


def _to_base64(arr):
    from PIL import Image as PILImage
    buf = io.BytesIO()
    PILImage.fromarray(arr).save(buf, format='PNG')
    return 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()


def segmentation_tab(schema=None):
    import altair as alt

    @st.cache_data
    def get_subjects():
        return list((schema.Subject & schema.CellSegmentation).fetch('subject_name'))

    @st.cache_data
    def get_session_counts():
        rows = (schema.Subject * schema.CellSegmentationParams).aggr(
            schema.CellSegmentation,
            n_sessions='count(session_name)'
        ).fetch(as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        df = df[df['n_sessions'] > 0].reset_index(drop=True)
        df['parameter_set_num'] = df['parameter_set_num'].astype(str)
        return df

    @st.cache_data
    def get_all_sessions():
        rows = (schema.CellSegmentation * schema.Session * schema.CellSegmentationParams).fetch(
            'subject_name', 'session_name', 'dataset_name', 'parameter_set_num',
            'algorithm_name', 'algorithm_version', 'n_rois', 'session_datetime',
            as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        df['parameter_set_num'] = df['parameter_set_num'].astype(str)
        return df.sort_values(['subject_name', 'session_datetime']).reset_index(drop=True)

    @st.cache_data
    def get_sessions(subject_name):
        rows = (schema.CellSegmentation * schema.Session * schema.CellSegmentationParams
                & dict(subject_name=subject_name)).fetch(
            'session_name', 'dataset_name', 'parameter_set_num',
            'algorithm_name', 'algorithm_version', 'n_rois', 'segmentation_datetime',
            'session_datetime', as_dict=True)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        cols = ['session_name', 'dataset_name', 'parameter_set_num', 'algorithm_name',
                'algorithm_version', 'n_rois', 'session_datetime', 'segmentation_datetime']
        return df[[c for c in cols if c in df.columns]].sort_values(
            'session_datetime', ascending=False).reset_index(drop=True)

    @st.cache_data
    def get_projections(subject_name, session_name, dataset_name, parameter_set_num):
        rows = (schema.CellSegmentation.Projection
                & dict(subject_name=subject_name, session_name=session_name,
                       dataset_name=dataset_name, parameter_set_num=parameter_set_num)
                ).fetch('plane_num', 'proj_name', 'proj_im', as_dict=True)
        for r in rows:
            arr = _normalize_image(r['proj_im'])
            r['h'], r['w'] = arr.shape[:2]
            r['url'] = _to_base64(arr)
            del r['proj_im']
        return rows

    @st.cache_data
    def get_roi_color_proj(subject_name, session_name, dataset_name, parameter_set_num,
                           sel_method, selected_only):
        from labdata.stacks import roi_color_projection
        key = dict(subject_name=subject_name, session_name=session_name,
                   dataset_name=dataset_name, parameter_set_num=parameter_set_num)
        plane_rows = (schema.CellSegmentation.Plane & key).fetch(
            'plane_num', 'dims', as_dict=True)
        results = []
        for plane in plane_rows:
            pnum = plane['plane_num']
            if plane['dims'] is None:
                continue
            plane_key = dict(key, plane_num=pnum)
            roi_table = schema.CellSegmentation.ROI & plane_key
            roi_nums = list(roi_table.fetch('roi_num'))
            if not roi_nums:
                continue
            if selected_only:
                sel_rois = set(
                    (schema.CellSegmentation.Selection
                     & dict(plane_key, selection_method=sel_method, selection=1)
                    ).fetch('roi_num'))
                cell_indices = [i for i, rn in enumerate(roi_nums) if rn in sel_rois]
            else:
                cell_indices = list(range(len(roi_nums)))
            if not cell_indices:
                continue
            all_masks = roi_table.get_roi_sparse_masks()
            masks = [all_masks[i] for i in cell_indices]
            rgb = roi_color_projection(masks)
            h, w = rgb.shape[:2]
            results.append(dict(plane_num=pnum, proj_name='roi color',
                                url=_to_base64(rgb), h=h, w=w))
        return results

    @st.cache_data
    def get_selection_methods(subject_name, session_name, dataset_name, parameter_set_num):
        key = dict(subject_name=subject_name, session_name=session_name,
                   dataset_name=dataset_name, parameter_set_num=parameter_set_num)
        methods = sorted(set(
            (schema.CellSegmentation.Selection & key).fetch('selection_method')))
        return methods or ['auto']

    @st.cache_data
    def get_roi_data(subject_name, session_name, dataset_name, parameter_set_num, sel_method):
        key = dict(subject_name=subject_name, session_name=session_name,
                   dataset_name=dataset_name, parameter_set_num=parameter_set_num)
        dims_map = {r['plane_num']: r['dims']
                    for r in (schema.CellSegmentation.Plane & key).fetch(
                        'plane_num', 'dims', as_dict=True)
                    if r['dims'] is not None}
        roi_rows = (schema.CellSegmentation.ROI & key).fetch(
            'plane_num', 'roi_num', 'roi_pixels', as_dict=True)
        sel_map = {(r['plane_num'], r['roi_num']): r['selection']
                   for r in (schema.CellSegmentation.Selection
                              & dict(key, selection_method=sel_method)).fetch(
                       'plane_num', 'roi_num', 'selection', as_dict=True)}
        centers = []
        for r in roi_rows:
            pnum = r['plane_num']
            dims = dims_map.get(pnum)
            if dims is None or r['roi_pixels'] is None:
                continue
            rows_idx, cols_idx = np.unravel_index(r['roi_pixels'], dims)
            is_cell = sel_map.get((pnum, r['roi_num']), None)
            db_label = ('cell' if is_cell == 1
                        else 'not cell' if is_cell == 0
                        else 'unclassified')
            centers.append(dict(roi_num=r['roi_num'], plane_num=pnum,
                                cy=float(np.median(rows_idx)),
                                cx=float(np.median(cols_idx)),
                                db_label=db_label))
        return centers

    @st.cache_data
    def get_frame_rate(subject_name, session_name, dataset_name):
        key = dict(subject_name=subject_name, session_name=session_name,
                   dataset_name=dataset_name)
        for table in (schema.TwoPhoton, schema.Miniscope):
            try:
                frame_rate, n_frames = (table & key).fetch1('frame_rate', 'n_frames')
                return float(frame_rate), int(n_frames)
            except Exception:
                pass
        return 1.0, 0

    @st.cache_data
    def get_traces(subject_name, session_name, dataset_name, parameter_set_num,
                   roi_keys, trace_type):
        key = dict(subject_name=subject_name, session_name=session_name,
                   dataset_name=dataset_name, parameter_set_num=parameter_set_num)
        traces = []
        for plane_num, roi_num in roi_keys:
            if roi_num is None:
                pass
            roi_key = dict(key, plane_num=int(plane_num), roi_num=int(roi_num))
            label = f'plane {plane_num}, roi {roi_num}'
            try:
                if trace_type == 'dff':
                    data = (schema.CellSegmentation.Traces & roi_key).fetch1('dff')
                elif trace_type == 'F':
                    data = (schema.CellSegmentation.RawTraces & roi_key).fetch1('f_trace')
                else:
                    data = (schema.CellSegmentation.Deconvolved & roi_key).fetch1('deconv')
                data = np.asarray(data, dtype=float)
                for t, v in enumerate(data):
                    traces.append({'t': t, 'value': float(v), 'roi': label})
            except Exception:
                pass
        return pd.DataFrame(traces)

    # get the seg_picked_rois from session state
    if 'seg_picked_rois' not in st.session_state:
        st.session_state['seg_picked_rois'] = []

    # get the subjects for session selection
    subjects = get_subjects()
    if not subjects:
        st.write('No cell segmentation data in the database.')
        return

    # sessions per subject for each parameter_set_num
    counts_df = get_session_counts()

    if not counts_df.empty:
        _colors = ['#000000', '#d62728', '#1f77b4', '#ff7f0e', '#2ca02c',
                   '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22']
        param_sets = sorted(counts_df['parameter_set_num'].unique().tolist())
        bar_color_scale = alt.Scale(
            domain=param_sets,
            range=[_colors[i % len(_colors)] for i in range(len(param_sets))])

        bar_sel = alt.selection_point(
            fields=['subject_name', 'parameter_set_num'], name='bar_sel')
        chart = (
            alt.Chart(counts_df).mark_bar().encode(
                x=alt.X('subject_name:N', sort='ascending', title='Subject'),
                xOffset=alt.XOffset('parameter_set_num:N', title='Param set'),
                y=alt.Y('n_sessions:Q', title='# sessions'),
                color=alt.Color('parameter_set_num:N', title='Param set',
                                scale=bar_color_scale),
                opacity=alt.condition(bar_sel, alt.value(1.0), alt.value(0.4)),
                tooltip=['subject_name:N', 'parameter_set_num:N', 'n_sessions:Q'],
            ).add_params(bar_sel).properties(height=200)
        )
        bar_event = st.altair_chart(chart, width='stretch', on_select='rerun',
                                    key='seg_sessions_bar')

        pts = (bar_event.selection or {}).get('bar_sel', [])
        if pts and pts[0].get('subject_name'):
            clicked_subject = pts[0]['subject_name']
            if clicked_subject in subjects:
                st.session_state['seg_subject'] = clicked_subject
                subj_df = get_all_sessions()
                subj_df = subj_df[subj_df['subject_name'] == clicked_subject]
                if not subj_df.empty:
                    first = subj_df.sort_values('session_datetime', ascending=False).iloc[0]
                    st.session_state['seg_scatter_sel_key'] = (
                        f"{first['session_name']}|{first['dataset_name']}")

    # All-sessions scatter: animals on Y, dates on X, color by parameter_set_num
    all_sessions_df = get_all_sessions()
    if not all_sessions_df.empty:
        scatter_all_df = all_sessions_df.copy()

        param_sets_all = sorted(scatter_all_df['parameter_set_num'].unique().tolist())
        _colors = ['#000000', '#d62728', '#1f77b4', '#ff7f0e', '#2ca02c',
                   '#9467bd', '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22']
        all_color_scale = alt.Scale(
            domain=param_sets_all,
            range=[_colors[i % len(_colors)] for i in range(len(param_sets_all))])

        all_scatter_click = alt.selection_point(
            fields=['session_name', 'dataset_name', 'subject_name'], name='all_sess_click')
        n_subjects = scatter_all_df['subject_name'].nunique()
        all_scatter_chart = (
            alt.Chart(scatter_all_df).mark_circle(size=80, opacity=0.7).encode(
                x=alt.X('session_datetime:T', title='Date',
                         axis=alt.Axis(tickCount='month', format='%b %Y', labelAngle=-45)),
                y=alt.Y('subject_name:N', title='Subject name', sort='ascending'),
                yOffset=alt.YOffset('jitter:Q', scale=alt.Scale(range=[-12, 12])),
                color=alt.Color('parameter_set_num:N', scale=all_color_scale,
                                title='Param set'),
                opacity=alt.condition(all_scatter_click, alt.value(0.9), alt.value(0.35)),
                tooltip=['subject_name:N', 'session_name:N', 'dataset_name:N',
                         'parameter_set_num:N',
                         alt.Tooltip('session_datetime:T', format='%Y-%m-%d'),
                         'n_rois:Q'],
            ).transform_calculate(jitter='random() - 0.5')
             .add_params(all_scatter_click)
             .properties(height=max(150, 60 * n_subjects + 60))
        )
        all_scatter_event = st.altair_chart(
            all_scatter_chart, width='stretch', on_select='rerun',
            key='seg_all_scatter')

        all_pts = (all_scatter_event.selection or {}).get('all_sess_click', [])
        if all_pts and all_pts[0].get('subject_name'):
            clicked_subject = all_pts[0]['subject_name']
            clicked_sname = all_pts[0].get('session_name', '')
            clicked_dname = all_pts[0].get('dataset_name', '')
            if clicked_subject in subjects:
                st.session_state['seg_subject'] = clicked_subject
            if clicked_sname:
                st.session_state['seg_scatter_sel_key'] = f"{clicked_sname}|{clicked_dname}"

    subject = st.selectbox('Subject', subjects, index=None, key='seg_subject')
    if not subject:
        return

    sessions = get_sessions(subject)
    if sessions.empty:
        st.write('No segmentation sessions found for this subject.')
        return


    # Resolve scatter selection before rendering the table so we can pre-select the row
    stored = st.session_state.get('seg_scatter_sel_key', '')
    scatter_sel_idx = None
    if stored:
        parts = stored.split('|', 1)
        matches = sessions[(sessions['session_name'] == parts[0]) &
                           (sessions['dataset_name'] == parts[1])]
        if not matches.empty:
            scatter_sel_idx = int(matches.index[0])

    # Pre-select the table row only when the scatter key is freshly set
    if scatter_sel_idx is not None and stored != st.session_state.get('seg_scatter_applied_key'):
        st.session_state['seg_sessions_table'] = {'selection': {'rows': [scatter_sel_idx], 'columns': []}}
        st.session_state['seg_scatter_applied_key'] = stored

    event_sess = st.dataframe(
        sessions, hide_index=True, width='stretch',
        on_select='rerun', selection_mode='single-row', key='seg_sessions_table',
    )
    table_rows = (event_sess.selection or {}).get('rows', [])

    if table_rows:
        sel_idx_final = table_rows[0]
    elif scatter_sel_idx is not None:
        sel_idx_final = scatter_sel_idx
    else:
        sel_idx_final = None

    if sel_idx_final is None:
        return

    row = sessions.iloc[sel_idx_final]
    param_set = int(row['parameter_set_num'])
    seg_key = dict(subject_name=subject, session_name=row['session_name'],
                   dataset_name=row['dataset_name'], parameter_set_num=param_set)

    # Reset state when session changes
    seg_key_id = f"{subject}|{row['session_name']}|{row['dataset_name']}|{param_set}"
    if st.session_state.get('seg_current_key') != seg_key_id:
        st.session_state['seg_current_key'] = seg_key_id
        st.session_state['seg_picked_rois'] = []
        st.session_state.pop('seg_selection_editor', None)
        for k in list(st.session_state.keys()):
            if k.startswith('seg_last_click_'):
                del st.session_state[k]

    st.write(f"**{row['session_name']}** — {row['algorithm_name']} — {row['n_rois']} ROIs")

    with st.spinner('Loading projections…'):
        projections = get_projections(
            subject, row['session_name'], row['dataset_name'], param_set)

    # ROI display controls
    methods = get_selection_methods(
        subject, row['session_name'], row['dataset_name'], param_set)

    if 'seg_sel_method_pending' in st.session_state:
        st.session_state['seg_sel_method'] = st.session_state.pop('seg_sel_method_pending')

    cA, cB, cC, cD = st.columns([1, 1, 1, 2])
    show_rois   = cA.toggle('Show ROI centers', value=True, key='seg_show_rois')
    show_mode   = cB.radio('ROIs to show', ['All', 'Selected'], horizontal=True,
                            key='seg_show_mode', label_visibility='collapsed')
    show_traces = cC.toggle('Show traces', value=True, key='seg_show_traces')
    sel_method  = cD.selectbox('Selection method', methods, key='seg_sel_method',
                                label_visibility='collapsed',
                                disabled=not show_rois)

    # Duplicate / delete selection methods
    _, _, dC = st.columns([1, 1, 2])
    with dC:
        dname, dbtn, del_btn = st.columns([3, 1, 1])
        new_name = dname.text_input('New method name', key='seg_new_method_name',
                                     placeholder=f'Duplicate "{sel_method}" as…',
                                     label_visibility='collapsed')
        if dbtn.button('Duplicate', key='seg_dup_btn'):
            nm = new_name.strip()
            if not nm:
                st.error('Enter a name for the new method.')
            elif nm in methods:
                st.error(f'Method "{nm}" already exists.')
            else:
                src_rows = (schema.CellSegmentation.Selection
                            & dict(seg_key, selection_method=sel_method)).fetch(as_dict=True)
                if not src_rows:
                    st.warning(f'No entries found for method "{sel_method}".')
                else:
                    try:
                        schema.CellSegmentation.Selection.insert(
                            [{**r, 'selection_method': nm} for r in src_rows])
                        get_selection_methods.clear()
                        get_roi_data.clear()
                        get_roi_color_proj.clear()
                        st.session_state['seg_sel_method_pending'] = nm
                        st.rerun()
                    except Exception as exc:
                        st.error(f'Insert failed: {exc}')

        if del_btn.button('Delete', key='seg_del_btn', type='secondary'):
            st.session_state['seg_del_confirm'] = sel_method

    pending_del = st.session_state.get('seg_del_confirm')
    if pending_del and pending_del == sel_method:
        st.warning(f'Delete selection method **"{pending_del}"**? This cannot be undone.')
        yes_col, no_col, _ = st.columns([1, 1, 6])
        if yes_col.button('Yes, delete', key='seg_del_yes', type='primary'):
            try:
                schema.dj.config['safemode'] = False # disable temporarly
                (schema.CellSegmentation.Selection
                 & dict(seg_key, selection_method=pending_del)).delete(force=True)
                schema.dj.config['safemode'] = True # re-enable
                get_selection_methods.clear()
                get_roi_data.clear()
                get_roi_color_proj.clear()
                st.session_state.pop('seg_del_confirm', None)
                st.rerun()
            except Exception as exc:
                st.error(f'Delete failed: {exc}')
        if no_col.button('Cancel', key='seg_del_no'):
            st.session_state.pop('seg_del_confirm', None)
            st.rerun()

    with st.spinner('Loading ROI positions…'):
        centers = get_roi_data(
            subject, row['session_name'], row['dataset_name'], param_set, sel_method)

    with st.spinner('Loading ROI color projection…'):
        roi_color_projs = get_roi_color_proj(
            subject, row['session_name'], row['dataset_name'], param_set, sel_method,
            selected_only=(show_mode == 'Selected'))

    all_projections = roi_color_projs + list(projections)

    picked: list = st.session_state['seg_picked_rois']

    color_domain = ['cell', 'not cell', 'unclassified', 'picked']
    color_range  = ['#d62728', '#4488ff', '#888888', '#ffff00']
    size_domain  = ['cell', 'not cell', 'unclassified', 'picked']
    size_range   = [80, 80, 60, 160]

    # projection tabs — 'roi color' first (default), then others sorted
    _other_names = sorted(set(r['proj_name'] for r in projections))
    proj_names = (['roi color'] if roi_color_projs else []) + _other_names
    if not proj_names:
        st.write('No projections found for this session.')
        return

    proj_tabs  = st.tabs(proj_names)

    for tab, pname in zip(proj_tabs, proj_names):
        with tab:
            plane_imgs = sorted([r for r in all_projections if r['proj_name'] == pname],
                                 key=lambda r: r['plane_num'])
            cols = st.columns(max(1, len(plane_imgs)))
            for col, r in zip(cols, plane_imgs):
                pnum = r['plane_num']
                w, h = r['w'], r['h']

                img_df = pd.DataFrame([{'x': 0, 'y': 0, 'x2': w, 'y2': h, 'url': r['url']}])
                img_layer = (
                    alt.Chart(img_df).mark_image(aspect=False).encode(
                        x=alt.X('x:Q', scale=alt.Scale(domain=[0, w]), axis=None),
                        y=alt.Y('y:Q', scale=alt.Scale(domain=[h, 0]), axis=None),
                        x2=alt.X2('x2'), y2=alt.Y2('y2'), url='url:N',
                        tooltip=alt.value(None),
                    )
                )

                plane_centers = [c for c in centers if c['plane_num'] == pnum] if centers else []

                scatter = None
                if show_rois and plane_centers:
                    picked_set = {(p['plane_num'], p['roi_num']) for p in picked}
                    visible = (
                        [c for c in plane_centers
                         if c['db_label'] == 'cell'
                         or (c['plane_num'], c['roi_num']) in picked_set]
                        if show_mode == 'Selected' else plane_centers
                    )
                    if visible:
                        roi_df = pd.DataFrame(visible)
                        roi_df['status'] = roi_df.apply(
                            lambda x: 'picked'
                            if (x['plane_num'], x['roi_num']) in picked_set
                            else x['db_label'], axis=1)
                        roi_df = roi_df.sort_values(
                            'status',
                            key=lambda s: s.map(
                                {'cell': 0, 'not cell': 1, 'unclassified': 2, 'picked': 3})
                        )
                        scatter = (
                            alt.Chart(roi_df).mark_point(filled=False, opacity=0.9, strokeWidth=1.5).encode(
                                x=alt.X('cx:Q', scale=alt.Scale(domain=[0, w]), axis=None),
                                y=alt.Y('cy:Q', scale=alt.Scale(domain=[h, 0]), axis=None),
                                color=alt.Color('status:N',
                                                scale=alt.Scale(domain=color_domain,
                                                                range=color_range),
                                                legend=None),
                                size=alt.Size('status:N',
                                              scale=alt.Scale(domain=size_domain,
                                                              range=size_range),
                                              legend=None),
                                tooltip=['status:N', 'roi_num:Q',
                                         alt.Tooltip('cx:Q', format='.0f', title='x'),
                                         alt.Tooltip('cy:Q', format='.0f', title='y')],
                            )
                        )

                if scatter is not None:
                    click_sel = alt.selection_point(
                        name='roi_click', fields=['roi_num', 'plane_num'], on='click')
                    display = img_layer + scatter.add_params(click_sel)
                else:
                    display = img_layer

                display = display.properties(width=350, height=350, title=f'Plane {pnum}').interactive()

                event = col.altair_chart(
                    display,
                    on_select='rerun',
                    key=f'seg_scatter_{pname}_{pnum}',
                    width='content',
                )

                if scatter is not None:
                    click_key = f'seg_last_click_{pname}_{pnum}'
                    current_click = (event.selection or {}).get('roi_click', [])
                    if current_click and current_click != st.session_state.get(click_key, []):
                        st.session_state[click_key] = current_click
                        pt = current_click[0]
                        roi_num    = pt.get('roi_num')
                        pnum_click = pt.get('plane_num')
                        if roi_num is not None and not pnum_click is None:
                            entry = {'plane_num': int(pnum_click), 'roi_num': int(roi_num)}
                            if entry in picked:
                                picked.remove(entry)
                            else:
                                picked.append(entry)
                            st.session_state['seg_picked_rois'] = picked
                            get_traces.clear()

    # traces
    if not picked:
        st.caption('Click ROI dots on the projection to select traces.')
        return

    st.divider()

    plot_picked = picked[-MAX_PICKED:]

    hA, hB = st.columns([3, 1])
    hA.write(f'**ROIs** (plotting last {len(plot_picked)} of {len(picked)} selected): '
             + '  '.join(f'plane {p["plane_num"]}, roi {p["roi_num"]}' for p in plot_picked))
    if hB.button('Clear all', key='seg_clear_picked'):
        st.session_state['seg_picked_rois'] = []
        st.session_state.pop('seg_selection_editor', None)
        get_traces.clear()
        st.rerun()

    rm_cols = st.columns(len(picked))
    for i, (rc, p) in enumerate(zip(rm_cols, picked[:])):
        if rc.button(f'✕ plane {p["plane_num"]}, roi {p["roi_num"]}', key=f'seg_rm_{i}'):
            picked.remove(p)
            st.session_state['seg_picked_rois'] = picked
            get_traces.clear()
            st.rerun()

    trace_type = st.radio('Trace', ['dff', 'F', 'deconv'],
                           horizontal=True, key='seg_trace_type',
                           disabled=not show_traces)

    roi_keys = tuple((p['plane_num'], p['roi_num']) for p in plot_picked)

    if show_traces:
        with st.spinner('Loading traces…'):
            traces_df = get_traces(subject, row['session_name'], row['dataset_name'],
                                   param_set, roi_keys, trace_type)

        if traces_df.empty:
            st.write(f'No `{trace_type}` traces found for the selected ROIs.')
        else:
            frame_rate, _ = get_frame_rate(subject, row['session_name'], row['dataset_name'])
            traces_df = traces_df.copy()
            traces_df['t_sec'] = traces_df['t'] / frame_rate

            window_s = 300.0
            total_s = float(traces_df['t_sec'].max())
            if total_s > window_s:
                max_start = round(total_s - window_s, 2)
                _lc, _sc = st.columns([1, 11])
                _lc.markdown('**Time (s)**')
                t_start = _sc.slider('Time (s)', 0.0, max_start, 0.0, step=30.0,
                                     key='seg_trace_window', label_visibility='collapsed')
            else:
                t_start = 0.0
            t_end = t_start + window_s

            view_df = traces_df[
                (traces_df['t_sec'] >= t_start) & (traces_df['t_sec'] <= t_end)]
            trace_chart = (
                alt.Chart(view_df)
                .mark_line(strokeWidth=1.2)
                .encode(
                    x=alt.X('t_sec:Q', title='Time (s)',
                             scale=alt.Scale(domain=[t_start, t_end]),
                             axis=alt.Axis(tickCount=5, tickSize=5, grid=False)),
                    y=alt.Y('value:Q', title=trace_type,
                             axis=alt.Axis(tickCount=5, tickSize=5, grid=False)),
                    color=alt.Color('roi:N', title='ROI',
                                    scale=alt.Scale(
                                        range=['#000000', '#d62728', '#1f77b4', '#ff7f0e',
                                               '#2ca02c', '#9467bd', '#8c564b', '#e377c2',
                                               '#7f7f7f', '#bcbd22'])),
                    tooltip=['roi:N', alt.Tooltip('t_sec:Q', title='Time (s)', format='.2f'),
                             alt.Tooltip('value:Q', format='.4f')],
                )
                .properties(height=220)
            )
            st.altair_chart(trace_chart, width='stretch')

    # classification editor 
    st.write('**ROI classification**')
    sel_rows = []
    for p in picked:
        roi_key = dict(seg_key, plane_num=p['plane_num'], roi_num=p['roi_num'])
        entry = (schema.CellSegmentation.Selection
                 & dict(roi_key, selection_method=sel_method)).fetch(
            'selection', as_dict=True)
        sel_rows.append({'plane': p['plane_num'], 'roi': p['roi_num'],
                         'method': sel_method,
                         'is_cell': bool(entry[0]['selection']) if entry else None})

    edited = st.data_editor(
        pd.DataFrame(sel_rows), hide_index=True, width='stretch',
        column_config={'is_cell': st.column_config.CheckboxColumn('Is cell?')},
        disabled=['plane', 'roi', 'method'],
        key='seg_selection_editor',
    )

    if st.button('Save classification', key='seg_save_selection'):
        changed = 0
        for _, erow in edited.iterrows():
            if erow['is_cell'] is None:
                continue
            roi_key = dict(seg_key, plane_num=int(erow['plane']),
                           roi_num=int(erow['roi']),
                           selection_method=sel_method)
            try:
                schema.CellSegmentation.Selection.update1(
                    {**roi_key, 'selection': 1 if erow['is_cell'] else 0})
                changed += 1
            except Exception as exc:
                st.error(f'Error updating plane {erow["plane"]} roi {erow["roi"]}: {exc}')
        if changed:
            st.success(f'Updated {changed} ROI classification(s).')
            get_roi_data.clear()
            get_roi_color_proj.clear()
            st.rerun()

