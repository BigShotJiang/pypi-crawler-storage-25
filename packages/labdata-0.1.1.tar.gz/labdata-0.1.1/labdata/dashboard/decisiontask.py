import pandas as pd
import streamlit as st
import numpy as np
import altair as alt

colors = ['#000000',
          '#d62728',
          '#1f77b4',
          '#ff7f0e',
          '#2ca02c',
          '#9467bd',
          '#8c564b',
          '#e377c2',
          '#7f7f7f',
          '#bcbd22']

def black_label_theme():
    return {
        'config': {
            'axis': {
                'labelColor': 'black',
                'titleColor': 'black',
                'domain' : True,
                'domainColor' : 'black',
                'domainCap':'butt',
                'domainWidth': 1.5,
                'tickWidth': 1.5,
                'gridColor':'black',
                'gridOpacity' : 0.5,
                'labelFontSize':16,
                'titleFontSize':18,
                'tickCount': 3,
                'tickSize' : 20,
                'grid':False
            },
            'header': {
                'labelColor': 'black',
                'titleColor': 'black'
            }
        }
    }
alt.themes.register('black_labels', black_label_theme)
alt.themes.enable('black_labels')
axis = alt.Axis(domain=True, domainColor='black', domainCap='butt',
                ticks=True, tickColor='black', tickSize=5)

def compute_psychometric(trialset_rows):
    """Proportion of rightward responses per condition per trialset with Wilson CI.
    response_values convention: left=1, no response=0, right=-1.
    """
    from scipy.stats import binomtest
    rows = []
    for row in trialset_rows:
        intensities = row.get('intensity_values')
        responses = row.get('response_values')
        desc = row.get('trialset_description', '')
        if intensities is None or responses is None:
            continue
        intensities = np.asarray(intensities, dtype=float)
        responses = np.asarray(responses, dtype=float)
        valid = (responses != 0) & ~np.isnan(intensities) & ~np.isnan(responses)
        intensities, responses = intensities[valid], responses[valid]
        if not len(intensities):
            continue
        for cond in np.unique(intensities):
            mask = intensities == cond
            n_total = int(mask.sum())
            n_side = int((responses[mask] == 1).sum())
            ci = binomtest(n_side, n_total).proportion_ci(confidence_level=0.95, method='wilson')
            rows.append(dict(condition=cond, n_side=n_side, n_total=n_total,
                             proportion=n_side / n_total,
                             ci_low=ci.low, ci_high=ci.high,
                             trialset_description=desc))
    return pd.DataFrame(rows)


def decisionmaking_tab(schema = None):
    @st.cache_data
    def get_subjects_last_ran():
        subs = schema.Subject & schema.DecisionTask
        try:
            max_date = (subs).aggr(schema.Session,ss='max(session_datetime)').fetch('ss').max().strftime('%Y-%m-%d')
        except:
            print('There are no sessions to max.')
            return [],[],None
        tt = (schema.DecisionTask()*schema.Session &
              f'session_datetime > (DATE("{max_date}") - INTERVAL 3 MONTH)')
        subjects = (schema.Subject() & tt).fetch(format = 'frame').reset_index()
        subjects = np.unique(subjects.subject_name.values)
        keys = [dict(subject_name = s) for s in subjects]
        return subs.fetch('subject_name'), keys, max_date

    @st.cache_data
    def get_summary_data(selected_indices,max_date):
        keys = [dict(subject_name = i) for i in selected_indices]
        max_date = schema.Subject.aggr(schema.Session & keys,ss='max(session_datetime)').fetch('ss').max().strftime('%Y-%m-%d')
        ses = (schema.Session()*schema.DecisionTask.TrialSet() & keys & f'session_datetime > (DATE("{max_date}") - INTERVAL 3 MONTH)').proj().fetch(as_dict = True)
    
        from datetime import timedelta
        summarysource = pd.DataFrame((schema.Session*schema.DecisionTask.TrialSet() & keys & 'trialset_description NOT LIKE "%opto%"'
                                    & f'session_datetime > (DATE("{max_date}") - INTERVAL 3 MONTH)').fetch())
        if not len(summarysource):
            return []
        days = np.array([(summarysource.session_datetime.max() - timedelta(days=d)).date() for d in range(40,-2,-1)])
        summarysource['date'] = summarysource.session_datetime.map(
                    lambda x: x.strftime("%y-%m-%d"))
        return summarysource

    if st.button('Refresh', icon=':material/refresh:'):
        get_subjects_last_ran.clear()
        get_summary_data.clear()

    all_subjects,subjects,max_date = get_subjects_last_ran()
    if not len(subjects):
        st.write('There are no sessions.')
        return

    selected_indices = st.multiselect('Select subjects:',all_subjects,default = [s['subject_name'] for s in subjects])
    if len(selected_indices):
        # cache data to run faster
        summarysource = get_summary_data(selected_indices,max_date)
        if not len(summarysource):
            st.write('Could not find sessions for the specified dates..')
            return
        point_selector = alt.selection_point(on="click")
        chart = alt.Chart(summarysource).mark_rect().encode(
            x=alt.X('session_datetime:T',timeUnit = 'yearmonthdate',
                    scale=alt.Scale(nice={'interval': 'day', 'step': 1})).axis(labelAngle=45,format='%Y-%m-%d').title('Date'),
            y=alt.Y('subject_name:O').title('Subject name'),
                    color=alt.Color('performance_easy:Q',
                    scale=alt.Scale(scheme='spectral', reverse=True, domain=[0.5,1], clamp=True)).title('Perf easy'),
                    tooltip = ['subject_name:N','session_name:N','session_datetime:T','performance_easy:Q','performance:Q','n_trials:Q']

        ).properties(width=1000, title ='Behavioral performance').add_params(point_selector)
        event_data = st.altair_chart(chart.interactive(), on_select='rerun')

        if len(event_data["selection"]["param_1"]):
            subject_name = event_data["selection"]["param_1"][0]["subject_name"]
            clicked_ts_raw = event_data["selection"]["param_1"][0].get("yearmonthdate_session_datetime")
            if clicked_ts_raw is not None:
                try:
                    clicked_ts = pd.Timestamp(clicked_ts_raw, unit='ms', tz='UTC').tz_localize(None)
                    sub_rows = summarysource[summarysource['subject_name'] == subject_name].copy()
                    diffs = (pd.to_datetime(sub_rows['session_datetime']) - clicked_ts).abs()
                    new_session = sub_rows.loc[diffs.idxmin(), 'session_name']
                    if new_session != st.session_state.get('decision_last_clicked_session'):
                        st.session_state['decision_selected_session'] = new_session
                        st.session_state['decision_last_clicked_session'] = new_session
                except Exception:
                    pass
            st.write(f'### _{subject_name}_')

            @st.cache_resource
            def get_subject_data(subject_name):
                trial_sets = pd.DataFrame((schema.DecisionTask.TrialSet*schema.Session & dict(subject_name = subject_name)).fetch())
                weights = pd.DataFrame((schema.Weighing & dict(subject_name = subject_name)).fetch())
                watering = pd.DataFrame((schema.Watering & dict(subject_name = subject_name)).fetch())
                return trial_sets, weights,watering

            @st.cache_data
            def get_session_trials(subject_name, session_name):
                cols = ['trialset_description', 'intensity_values', 'response_values', 'reaction_times']
                return (schema.DecisionTask.TrialSet * schema.Session
                        & dict(subject_name=subject_name, session_name=session_name)
                        ).fetch(*cols, as_dict=True)

            if st.button('Refresh sessions', icon=':material/refresh:'):
                get_subject_data.clear()
                get_session_trials.clear()

            trialset, weights, watering = get_subject_data(subject_name)
            sessions = sorted(trialset['session_datetime'].unique())

            # resolve default session from click
            clicked_ts_raw = event_data["selection"]["param_1"][0].get("yearmonthdate_session_datetime")
            default_idx = len(sessions) - 1
            if clicked_ts_raw is not None:
                try:
                    clicked_ts = pd.Timestamp(clicked_ts_raw, unit='ms', tz='UTC').tz_localize(None)
                    diffs = [abs((pd.Timestamp(s) - clicked_ts).total_seconds()) for s in sessions]
                    default_idx = int(np.argmin(diffs))
                except Exception:
                    pass

            # resolve selected session before columns so selected_dt is available everywhere
            session_names = trialset[['session_datetime','session_name']].drop_duplicates('session_name').sort_values('session_datetime')
            snames = list(session_names['session_name'])
            clicked_session = st.session_state.pop('decision_selected_session', None)
            if clicked_session in snames:
                st.session_state['decision_session_slider'] = snames.index(clicked_session)
            if 'decision_session_slider' not in st.session_state:
                st.session_state['decision_session_slider'] = default_idx
            st.session_state['decision_session_slider'] = min(
                st.session_state['decision_session_slider'], len(snames) - 1)
            session_idx = st.session_state.get('decision_session_slider', 0)
            selected_session = snames[session_idx]
            selected_dt = session_names.loc[session_names['session_name'] == selected_session, 'session_datetime'].iloc[0]

            col_summary, _, col_psych = st.columns([2, 0.15, 1])

            with col_summary:
                black, orange = '#000000','#ff7f0e'
                perf_val = trialset.dropna(subset=['performance_easy','performance']).sort_values('session_datetime').drop_duplicates('session_datetime').iloc[[-1]]
                x_enc = alt.X('session_datetime:T', axis=axis).title('Session date')
                perf_chart = (
                    alt.Chart(trialset).mark_line(color=black).encode(x=x_enc, y=alt.Y('performance_easy:Q', axis=axis).title('Performance')).properties(width=1000) +
                    alt.Chart(trialset).mark_point(color=black).encode(x=x_enc, y=alt.Y('performance_easy:Q'), tooltip=['session_name:N','session_datetime:T','performance_easy:Q','performance:Q']) +
                    alt.Chart(perf_val).mark_text(align='left', dx=6, dy=100, color=black).encode(x=x_enc, y=alt.Y('performance_easy:Q'), text=alt.value('easy')) +
                    alt.Chart(trialset).mark_line(color=orange).encode(x=x_enc, y=alt.Y('performance:Q', axis=axis)) +
                    alt.Chart(trialset).mark_point(color=orange).encode(x=x_enc, y=alt.Y('performance:Q'),
                                                                        tooltip=['session_name:N','session_datetime:T','performance_easy:Q','performance:Q']) +
                    alt.Chart(perf_val).mark_text(align='left', dx=6, dy=100, color=orange).encode(x=x_enc, y=alt.Y('performance:Q'), text=alt.value('all trials'))
                )
                ruler_df = pd.DataFrame({'t': [selected_dt]})
                def make_ruler(x_field):
                    return alt.Chart(ruler_df).mark_rule(
                        color='grey', strokeDash=[10, 10], strokeWidth=1.5
                    ).encode(x=alt.X(f't:T'))

                chartw = line_point_plot(weights,
                                x=alt.X('weighing_datetime:T',axis=axis).title(''),
                                y=alt.Y('weight:Q',axis=axis).title('Weight (g)'),
                                tooltip=['weighing_datetime', 'weight'],
                                color = colors[0])
                charth2o = line_point_plot(watering,
                                x=alt.X('watering_datetime:T',axis=axis).title('Session date'),
                                y=alt.Y('water_volume:Q',axis=axis).title('Water volume (mL)'),
                                tooltip=['watering_datetime', 'water_volume'],
                                color = colors[2])
                linked = alt.vconcat(
                    perf_chart + make_ruler('session_datetime'),
                    chartw    + make_ruler('weighing_datetime'),
                    charth2o  + make_ruler('watering_datetime'),
                ).resolve_scale(x='shared')
                st.altair_chart(linked.interactive(), width="stretch")

            with col_psych:

                trial_rows = get_session_trials(subject_name, selected_session)
                psych_df = compute_psychometric(trial_rows)
                if not psych_df.empty:
                    descs = list(psych_df['trialset_description'].unique())
                    color_scale = alt.Scale(domain=descs, range=colors[:len(descs)])
                    base = alt.Chart(psych_df).encode(
                        x=alt.X('condition:Q', axis=axis).title('Stimulus intensity'),
                        color=alt.Color('trialset_description:N', scale=color_scale,
                                        legend=alt.Legend(orient='bottom', title=None)).title('Trial set'),
                    )
                    pts = base.mark_point(size=60).encode(
                        y=alt.Y('proportion:Q', axis=axis,
                                scale=alt.Scale(domain=[0, 1])),
                        tooltip=['trialset_description:N', 'condition:Q',
                                 'proportion:Q', 'n_side:Q', 'n_total:Q'],
                    )
                    errorbars = base.mark_errorbar(ticks=True).encode(
                        y=alt.Y('ci_low:Q').title('Pside'),
                        y2=alt.Y2('ci_high:Q'),
                    )
                    lines = base.mark_line().encode(y=alt.Y('proportion:Q'))
                    st.altair_chart((lines + errorbars + pts).properties(
                        width=400, height=500, title=f'{pd.Timestamp(selected_dt).strftime("%Y-%m-%d %H:%M")}'
                    ).interactive(), width="stretch")

                    # reaction time per condition
                    rt_rows = []
                    for row in trial_rows:
                        rt = row.get('reaction_times')
                        intensities = row.get('intensity_values')
                        responses = row.get('response_values')
                        desc = row.get('trialset_description', '')
                        if rt is None or intensities is None:
                            continue
                        rt = np.asarray(rt, dtype=float)
                        intensities = np.asarray(intensities, dtype=float)
                        responses = np.asarray(responses, dtype=float) if responses is not None else np.ones_like(rt)
                        valid = ~np.isnan(rt) & ~np.isnan(intensities) & (responses != 0)
                        rt, intensities = rt[valid], intensities[valid]
                        for cond in np.unique(intensities):
                            vals = rt[intensities == cond]
                            rt_rows.append(dict(condition=cond, trialset_description=desc,
                                                median_rt=float(np.median(vals)),
                                                q25=float(np.percentile(vals, 25)),
                                                q75=float(np.percentile(vals, 75))))
                    if rt_rows:
                        rt_df = pd.DataFrame(rt_rows)
                        rt_base = alt.Chart(rt_df).encode(
                            x=alt.X('condition:Q', axis=axis).title('Stimulus intensity'),
                            color=alt.Color('trialset_description:N', scale=color_scale,
                                            legend=alt.Legend(orient='bottom', title=None)),
                        )
                        rt_pts = rt_base.mark_point(size=60).encode(
                            y=alt.Y('median_rt:Q', axis=axis).title('Reaction time (s)'),
                            tooltip=['trialset_description:N', 'condition:Q', 'median_rt:Q', 'q25:Q', 'q75:Q'],
                        )
                        rt_err = rt_base.mark_errorbar(ticks=True).encode(
                            y=alt.Y('q25:Q').title('Reaction time (s)'),
                            y2=alt.Y2('q75:Q'),
                        )
                        rt_lines = rt_base.mark_line().encode(y=alt.Y('median_rt:Q'))
                        st.altair_chart((rt_lines + rt_err + rt_pts).properties(
                            width=400, height=300, title='Reaction time per condition'
                        ).interactive(), width="stretch")
                else:
                    st.error('No data available for this session.')

                if len(snames) > 1:
                    st.slider('Session', min_value=0, max_value=len(snames)-1,
                              key='decision_session_slider')

                @st.cache_data
                def get_session_notes(subject_name, session_name):
                    rows = (schema.Dataset * schema.Note
                            & dict(subject_name=subject_name, session_name=session_name)
                            ).fetch('notes', 'notetaker', 'note_datetime', as_dict=True)
                    return rows

                notes = get_session_notes(subject_name, selected_session)
                if notes:
                    for n in notes:
                        st.caption(f"*{n['notetaker']} — {pd.Timestamp(n['note_datetime']).strftime('%Y-%m-%d %H:%M')}*")
                        st.write(n['notes'])

def line_point_plot(data, x, y, tooltip, color):
    if data is None or not len(data):
        return alt.Chart(pd.DataFrame()).mark_point()
    scatter = alt.Chart(data).mark_point(color=color).encode(
                x=x, y=y, tooltip=tooltip)
    line = alt.Chart(data).mark_line(color=color).encode(
                x=x, y=y).properties(width=1000)
    return scatter + line
