#!/usr/bin/env python3
# Copyright 2025-2026 Pushkar Singh / Meta-Agents.AI
# SPDX-License-Identifier: Apache-2.0
# Part of Meta-AgentsDB — the first database designed for autonomous AI agents.
# https://meta-agents.ai
"""
madb_mcp_report — CLI analytics report for MADB MCP usage
==========================================================

Reads the append-only ``mcp_analytics.jsonl`` log and produces a
human-readable or machine-readable usage report with Memory ROI.

Usage::

    python madb_mcp_report.py [--since 7d] [--format text|json] [--file PATH]

Defaults:
    --since   all (no time filter)
    --format  text
    --file    $MADB_DATA_DIR/mcp_analytics.jsonl  (or ~/.madb/data/mcp_analytics.jsonl)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

# Same constant as in madb_mcp_analytics.py
AVG_FILE_READ_TOKENS = 1500


def _parse_duration(s: str) -> float:
    """Parse a human duration like '7d', '24h', '30m' into seconds."""
    s = s.strip().lower()
    if s == "all":
        return 0.0
    multipliers = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}
    if s[-1] in multipliers:
        return float(s[:-1]) * multipliers[s[-1]]
    return float(s)


def _percentile(sorted_values: list[float], pct: float) -> float:
    if not sorted_values:
        return 0.0
    k = (len(sorted_values) - 1) * (pct / 100)
    f = int(k)
    c = f + 1
    if c >= len(sorted_values):
        return sorted_values[-1]
    return sorted_values[f] + (k - f) * (sorted_values[c] - sorted_values[f])


def load_entries(path: str, since_ts: float) -> list[dict]:
    """Load JSONL entries from disk, filtering by timestamp."""
    entries: list[dict] = []
    if not os.path.exists(path):
        return entries
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if entry.get("ts", 0) >= since_ts:
                entries.append(entry)
    return entries


def _build_session_stats(entries: list[dict]) -> dict[str, Any]:
    """Group entries by session_id and compute per-session metrics."""
    sessions: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "calls": 0, "first_ts": float("inf"), "last_ts": 0.0,
            "user": "", "host": "",
            "recalls": 0, "recall_hits": 0,
            "recall_tokens": 0, "top_scores": [],
            "writes": 0, "write_tokens": 0,
        }
    )

    for e in entries:
        sid = e.get("session_id", "unknown")
        s = sessions[sid]
        s["calls"] += 1
        ts = e.get("ts", 0)
        if ts < s["first_ts"]:
            s["first_ts"] = ts
        if ts > s["last_ts"]:
            s["last_ts"] = ts
        s["user"] = e.get("user", s["user"]) or s["user"]
        s["host"] = e.get("host", s["host"]) or s["host"]

        tool = e.get("tool", "")
        if tool == "recall":
            s["recalls"] += 1
            rc = e.get("result_count", 0)
            if rc > 0:
                s["recall_hits"] += 1
            s["recall_tokens"] += e.get("tokens", 0)
            top = e.get("top_score", 0.0)
            if top > 0:
                s["top_scores"].append(top)
        elif tool == "remember":
            s["writes"] += 1
            s["write_tokens"] += e.get("payload_tokens", 0)

    # Compute per-session derived metrics
    session_reports: list[dict[str, Any]] = []
    for sid, s in sorted(sessions.items(), key=lambda x: x[1]["first_ts"]):
        duration = max(s["last_ts"] - s["first_ts"], 0.001)
        hit_rate = round(s["recall_hits"] / max(s["recalls"], 1) * 100, 1)
        avg_top = (
            round(sum(s["top_scores"]) / len(s["top_scores"]), 3)
            if s["top_scores"] else 0.0
        )
        file_reads_avoided = round(s["recall_tokens"] / AVG_FILE_READ_TOKENS, 1)
        write_to_read = (
            round(s["recall_tokens"] / max(s["write_tokens"], 1), 2)
            if s["write_tokens"] > 0 else 0.0
        )
        session_reports.append({
            "session_id": sid,
            "user": s["user"],
            "host": s["host"],
            "duration_s": round(duration, 1),
            "calls": s["calls"],
            "recalls": s["recalls"],
            "recall_hits": s["recall_hits"],
            "recall_hit_rate_pct": hit_rate,
            "recall_tokens": s["recall_tokens"],
            "avg_top_score": avg_top,
            "writes": s["writes"],
            "write_tokens": s["write_tokens"],
            "est_file_reads_avoided": file_reads_avoided,
            "write_to_read_ratio": write_to_read,
        })

    return {
        "total_sessions": len(sessions),
        "sessions": session_reports,
    }


def build_report(entries: list[dict]) -> dict[str, Any]:
    """Build a structured report from JSONL entries."""
    tools: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "calls": 0, "errors": 0, "latencies": [],
            "result_count_sum": 0, "tokens_served": 0,
            "recalls_with_results": 0, "top_scores": [],
            "payload_tokens": 0,
        }
    )
    tenants: set[str] = set()
    users: set[str] = set()
    hosts: set[str] = set()
    total_calls = 0
    total_errors = 0

    for e in entries:
        tool = e.get("tool", "unknown")
        ts = tools[tool]
        ts["calls"] += 1
        ts["latencies"].append(e.get("latency_ms", 0))
        total_calls += 1
        if not e.get("ok", True):
            ts["errors"] += 1
            total_errors += 1
        tenant = e.get("tenant", "")
        if tenant:
            tenants.add(tenant)
        user = e.get("user", "")
        if user:
            users.add(user)
        host = e.get("host", "")
        if host:
            hosts.add(host)

        if tool == "recall":
            rc = e.get("result_count", 0)
            ts["result_count_sum"] += rc
            ts["tokens_served"] += e.get("tokens", 0)
            if rc > 0:
                ts["recalls_with_results"] += 1
            top = e.get("top_score", 0.0)
            if top > 0:
                ts["top_scores"].append(top)

        if tool == "remember":
            ts["payload_tokens"] += e.get("payload_tokens", 0)

    # Compute per-tool stats
    all_latencies: list[float] = []
    tool_reports: dict[str, dict[str, Any]] = {}
    for name in sorted(tools.keys(), key=lambda n: -tools[n]["calls"]):
        ts = tools[name]
        lats = sorted(ts["latencies"])
        all_latencies.extend(ts["latencies"])
        avg = sum(lats) / len(lats) if lats else 0
        report: dict[str, Any] = {
            "calls": ts["calls"],
            "errors": ts["errors"],
            "avg_latency_ms": round(avg, 1),
            "p50_latency_ms": round(_percentile(lats, 50), 1),
            "p99_latency_ms": round(_percentile(lats, 99), 1),
        }
        if name == "recall":
            total_recalls = ts["calls"]
            report["total_results"] = ts["result_count_sum"]
            report["tokens_served"] = ts["tokens_served"]
            report["recalls_with_results"] = ts["recalls_with_results"]
            report["recall_hit_rate"] = round(
                ts["recalls_with_results"] / max(total_recalls, 1) * 100, 1
            )
            report["avg_results_per_recall"] = round(
                ts["result_count_sum"] / max(total_recalls, 1), 1
            )
            report["avg_top_score"] = (
                round(sum(ts["top_scores"]) / len(ts["top_scores"]), 3)
                if ts["top_scores"] else 0.0
            )
        if name == "remember":
            report["memories_written"] = ts["calls"]
            report["memories_written_tokens"] = ts["payload_tokens"]
        tool_reports[name] = report

    # Aggregate ROI
    recall_ts = tools.get("recall", {})
    remember_ts = tools.get("remember", {})
    total_recall_tokens = recall_ts.get("tokens_served", 0) if recall_ts else 0
    total_write_tokens = remember_ts.get("payload_tokens", 0) if remember_ts else 0
    total_recalls = recall_ts.get("calls", 0) if recall_ts else 0
    recall_hits = recall_ts.get("recalls_with_results", 0) if recall_ts else 0
    all_top_scores = recall_ts.get("top_scores", []) if recall_ts else []

    all_sorted = sorted(all_latencies)

    session_stats = _build_session_stats(entries)

    return {
        "total_calls": total_calls,
        "total_errors": total_errors,
        "error_rate": round(total_errors / max(total_calls, 1) * 100, 2),
        "unique_tenants": len(tenants),
        "unique_users": sorted(users),
        "unique_hosts": sorted(hosts),
        "all_tool_p50_ms": round(_percentile(all_sorted, 50), 1),
        "all_tool_p99_ms": round(_percentile(all_sorted, 99), 1),
        "recall_precision": {
            "hit_rate_pct": round(recall_hits / max(total_recalls, 1) * 100, 1),
            "avg_top_score": (
                round(sum(all_top_scores) / len(all_top_scores), 3)
                if all_top_scores else 0.0
            ),
            "avg_results_per_recall": round(
                recall_ts.get("result_count_sum", 0) / max(total_recalls, 1), 1
            ) if recall_ts else 0.0,
            "total_recalls": total_recalls,
            "recalls_with_results": recall_hits,
        },
        "memory_roi": {
            "tokens_served_from_recall": total_recall_tokens,
            "memories_written": remember_ts.get("calls", 0) if remember_ts else 0,
            "memories_written_tokens": total_write_tokens,
            "est_file_reads_avoided": round(total_recall_tokens / AVG_FILE_READ_TOKENS, 1),
            "write_to_read_ratio": (
                round(total_recall_tokens / max(total_write_tokens, 1), 2)
                if total_write_tokens > 0 else 0.0
            ),
        },
        "sessions": session_stats,
        "tools": tool_reports,
    }


def _fmt_tokens(tokens: int) -> str:
    if tokens > 1_000_000:
        return f"~{tokens / 1_000_000:.1f}M"
    elif tokens > 1_000:
        return f"~{tokens / 1_000:.1f}K"
    return str(tokens)


def format_text(report: dict[str, Any], since_label: str) -> str:
    """Format report as human-readable text."""
    rp = report.get("recall_precision", {})
    roi = report.get("memory_roi", {})
    sess = report.get("sessions", {})

    lines = [
        f"MADB MCP Usage Report ({since_label})",
        "=" * 55,
        f"Total Tool Calls:   {report['total_calls']}",
        f"Total Errors:       {report['total_errors']}",
        f"Error Rate:         {report['error_rate']}%",
        f"Unique Tenants:     {report['unique_tenants']}",
        f"Users:              {', '.join(report['unique_users']) or 'n/a'}",
        f"Hosts:              {', '.join(report['unique_hosts']) or 'n/a'}",
        f"Sessions:           {sess.get('total_sessions', 0)}",
        "",
        "Tool Usage:",
    ]

    for name, ts in report.get("tools", {}).items():
        lines.append(
            f"  {name:15s}  {ts['calls']:>5} calls  "
            f"(avg {ts['avg_latency_ms']}ms, p99 {ts['p99_latency_ms']}ms)"
            + (f"  err={ts['errors']}" if ts["errors"] else "")
        )

    # Recall Precision
    lines.extend([
        "",
        "Recall Precision:",
        "-" * 55,
        f"  Hit Rate:           {rp.get('hit_rate_pct', 0)}% "
        f"({rp.get('recalls_with_results', 0)}/{rp.get('total_recalls', 0)} "
        "returned results)",
        f"  Avg Top Score:      {rp.get('avg_top_score', 0)} "
        "(composite similarity — 1.0 = perfect)",
        f"  Avg Results/Recall: {rp.get('avg_results_per_recall', 0)}",
    ])

    # Memory ROI
    recall_tokens = roi.get("tokens_served_from_recall", 0)
    lines.extend([
        "",
        "Memory ROI:",
        "-" * 55,
        f"  Tokens Served:      {_fmt_tokens(recall_tokens)} tokens "
        "(context from memory, not file re-reads)",
        f"  File Reads Saved:   ~{roi.get('est_file_reads_avoided', 0)} "
        f"(at ~{AVG_FILE_READ_TOKENS} tokens/file read)",
        f"  Memories Written:   {roi.get('memories_written', 0)} "
        f"({_fmt_tokens(roi.get('memories_written_tokens', 0))} tokens invested)",
        f"  Write-to-Read:      {roi.get('write_to_read_ratio', 0)}x "
        "(tokens recalled per token written)",
    ])

    # Per-session breakdown (top 10)
    session_list = sess.get("sessions", [])
    if session_list:
        lines.extend([
            "",
            f"Per-Session Breakdown (showing {min(len(session_list), 10)}"
            f" of {len(session_list)}):",
            "-" * 55,
        ])
        for s in session_list[:10]:
            sid = s["session_id"][:8]
            lines.append(
                f"  {sid}  user={s['user']:12s}  "
                f"calls={s['calls']:>3}  "
                f"recalls={s['recalls']}/{s['recall_hits']} hits  "
                f"tokens={_fmt_tokens(s['recall_tokens'])}  "
                f"score={s['avg_top_score']}  "
                f"files_saved=~{s['est_file_reads_avoided']}"
            )

    # Performance
    lines.extend([
        "",
        "Performance:",
        f"  All-Tool P50:       {report['all_tool_p50_ms']}ms",
        f"  All-Tool P99:       {report['all_tool_p99_ms']}ms",
    ])

    return "\n".join(lines)


def main() -> None:
    default_path = os.path.join(
        os.environ.get("MADB_DATA_DIR", str(Path.home() / ".madb" / "data")),
        "mcp_analytics.jsonl",
    )

    parser = argparse.ArgumentParser(
        description="MADB MCP usage analytics report",
    )
    parser.add_argument(
        "--since", default="all",
        help="Time window: '7d', '24h', '1h', 'all' (default: all)",
    )
    parser.add_argument(
        "--format", choices=["text", "json"], default="text",
        help="Output format (default: text)",
    )
    parser.add_argument(
        "--file", default=default_path,
        help=f"Path to mcp_analytics.jsonl (default: {default_path})",
    )
    args = parser.parse_args()

    duration = _parse_duration(args.since)
    since_ts = time.time() - duration if duration > 0 else 0.0
    since_label = f"Last {args.since}" if args.since != "all" else "All Time"

    entries = load_entries(args.file, since_ts)
    if not entries:
        print(f"No analytics data found in {args.file}", file=sys.stderr)
        sys.exit(0)

    report = build_report(entries)

    if args.format == "json":
        print(json.dumps(report, indent=2))
    else:
        print(format_text(report, since_label))


if __name__ == "__main__":
    main()
