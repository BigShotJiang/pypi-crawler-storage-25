"""Allow `python -m madb_mcp_server` to launch the MCP server."""
from madb_mcp_server import mcp

mcp.run()
