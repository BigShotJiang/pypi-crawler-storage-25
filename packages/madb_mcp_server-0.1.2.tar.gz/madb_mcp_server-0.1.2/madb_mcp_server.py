#!/usr/bin/env python3
# Copyright 2025-2026 Pushkar Singh / Meta-Agents.AI
# SPDX-License-Identifier: Apache-2.0
# Part of Meta-AgentsDB — the first database designed for autonomous AI agents.
# https://meta-agents.ai
"""
madb-mcp-server — Meta-AgentsDB MCP Server
===========================================

Exposes MADB as an MCP (Model Context Protocol) tool server so any
Claude session can use persistent, causal, policy-gated agent memory.

Tools:
  remember      — Write a memory event (with causal links, tags, importance)
  recall        — Semantic recall: vector search + composite scoring
  get_memory    — Point lookup by event_id
  forget        — Soft-delete a memory by event_id
  search        — Structured query by tenant + scope + tags
  list_recent   — Last N memories for a tenant
  save_skill    — Store a reusable skill/pattern (GC-protected, idempotent)
  recall_skill  — Semantic skill recall with structured output
  list_skills   — List all saved skills ranked by composite score
  stats         — Engine metrics snapshot
  trace_cause   — Walk the causal DAG forward or backward
  analytics     — MCP usage analytics snapshot

Resources:
  madb://memories/{event_id}  — Read a single memory record

Usage:
  # stdio transport (Claude Desktop / claude-code)
  python -m madb_mcp_server

  # or with uvx
  uvx madb-mcp-server

Environment:
  MADB_DATA_DIR  — Database directory (default: ~/.madb/data)
  MADB_TENANT_ID — Default tenant (default: "default")
"""

import json
import os
import sys
import time
from pathlib import Path

from mcp.server.fastmcp import FastMCP

# Ensure meta_agents_db is importable (the Rust extension)
try:
    from meta_agents_db import MetaAgentsDB
except ImportError:
    print(
        "ERROR: meta_agents_db not found. Install with: pip install meta-agents-db",
        file=sys.stderr,
    )
    sys.exit(1)

from madb_mcp_analytics import McpAnalytics

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DATA_DIR = os.environ.get("MADB_DATA_DIR", str(Path.home() / ".madb" / "data"))
DEFAULT_TENANT = os.environ.get("MADB_TENANT_ID", "default")

# ---------------------------------------------------------------------------
# Server + DB singleton + Analytics
# ---------------------------------------------------------------------------

mcp = FastMCP(
    "Meta-AgentsDB",
    instructions=(
        "Persistent, causal, policy-gated memory for autonomous AI agents. "
        "Write memories with causal links, recall them by semantic similarity, "
        "and inspect the full evidence chain."
    ),
)

_db: MetaAgentsDB | None = None
_analytics = McpAnalytics(os.path.join(DATA_DIR, "mcp_analytics.jsonl"))


def _get_db() -> MetaAgentsDB:
    """Lazy-init the database on first tool call."""
    global _db
    if _db is None:
        _db = MetaAgentsDB(DATA_DIR)
    return _db


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def remember(
    content: str,
    tags: list[str] | None = None,
    tenant_id: str | None = None,
    scope: str = "workspace",
    mem_type: str = "long_term",
    importance: float | None = None,
    caused_by: list[str] | None = None,
    actor: str = "claude",
    idempotency_key: str | None = None,
) -> str:
    """Store a memory in MADB with optional causal links and tags.

    Args:
        content: The memory content (text or JSON string).
        tags: Classification tags (e.g., ["trade", "SPY", "decision"]).
        tenant_id: Tenant isolation key. Defaults to MADB_TENANT_ID env var.
        scope: Visibility scope — "user", "workspace", "org", or "public_template".
        mem_type: Durability tier — "ephemeral", "session", "long_term", or "artifact".
        importance: Priority hint 0.0–1.0 (higher = more likely to be recalled).
        caused_by: List of parent event_id UUIDs for causal chain tracking.
        actor: Who created this memory (default: "claude").
        idempotency_key: Dedup key — re-submitting the same key is a no-op.

    Returns:
        The event_id (UUID) of the stored memory.
    """
    t0 = time.perf_counter()
    ok = True
    _payload_tokens = 0
    try:
        db = _get_db()
        tenant = tenant_id or DEFAULT_TENANT

        # Accept both raw text and JSON
        try:
            payload = json.loads(content)
        except (json.JSONDecodeError, TypeError):
            payload = {"content": content}

        payload_json = json.dumps(payload)
        event_id = db.write(
            tenant_id=tenant,
            scope=scope,
            mem_type=mem_type,
            payload=payload_json,
            tags=tags or [],
            caused_by=caused_by or [],
            importance_hint=importance,
            actor=actor,
            idempotency_key=idempotency_key,
        )
        _payload_tokens = len(payload_json) // 4
        return f"Stored memory: {event_id}"
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "remember", (time.perf_counter() - t0) * 1000, ok,
            {"tenant": tenant_id or DEFAULT_TENANT,
             "payload_tokens": _payload_tokens if ok else 0},
        )


@mcp.tool()
def recall(
    query: str,
    tenant_id: str | None = None,
    budget_tokens: int = 4000,
    top_k: int = 20,
    tag_filter: list[str] | None = None,
) -> str:
    """Semantic recall: find the most relevant memories for a query.

    Uses vector similarity + recency + causal proximity + importance
    to rank results. Returns up to budget_tokens worth of content.

    Args:
        query: Natural language query (e.g., "What did I decide about SPY puts?").
        tenant_id: Tenant key. Defaults to MADB_TENANT_ID env var.
        budget_tokens: Approximate token budget for returned content.
        top_k: Number of raw candidates to rescore.
        tag_filter: Only consider memories with these tags.

    Returns:
        Ranked list of relevant memories with scores.
    """
    t0 = time.perf_counter()
    ok = True
    meta: dict = {"tenant": tenant_id or DEFAULT_TENANT}
    try:
        db = _get_db()
        tenant = tenant_id or DEFAULT_TENANT

        results = db.recall(
            query=query,
            tenant_id=tenant,
            budget_tokens=budget_tokens,
            top_k=top_k,
            tag_filter=tag_filter,
        )

        meta["result_count"] = len(results) if results else 0

        if not results:
            return "No matching memories found."

        tokens_served = 0
        top_score = 0.0
        lines = []
        for i, r in enumerate(results, 1):
            payload = r.get("payload", "{}")
            score = r.get("score", 0.0)
            rtags = r.get("tags", [])
            eid = r.get("event_id", "?")
            pinned = " [PINNED]" if r.get("pinned") else ""
            lines.append(
                f"{i}. [{score:.2f}]{pinned} {payload}\n"
                f"   id={eid} tags={rtags}"
            )
            tokens_served += len(payload) // 4
            if score > top_score:
                top_score = score

        meta["tokens"] = tokens_served
        meta["top_score"] = top_score
        return "\n".join(lines)
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "recall", (time.perf_counter() - t0) * 1000, ok, meta,
        )


@mcp.tool()
def get_memory(event_id: str, tenant_id: str | None = None) -> str:
    """Retrieve a specific memory by its event_id.

    Args:
        event_id: UUID of the memory to retrieve.
        tenant_id: Not used for lookup but included for consistency.

    Returns:
        The full memory record as JSON, or "Not found".
    """
    t0 = time.perf_counter()
    ok = True
    try:
        db = _get_db()
        record = db.get(event_id)
        if record is None:
            return f"Memory {event_id} not found."
        return json.dumps(dict(record), indent=2, default=str)
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "get_memory", (time.perf_counter() - t0) * 1000, ok,
            {"tenant": tenant_id or DEFAULT_TENANT},
        )


@mcp.tool()
def forget(
    event_id: str,
    tenant_id: str | None = None,
) -> str:
    """Soft-delete a memory by event_id.

    The memory is marked as deleted but remains in the causal chain
    for audit purposes. It will no longer appear in recall results.

    Args:
        event_id: UUID of the memory to delete.
        tenant_id: Tenant key (for future multi-tenant enforcement).

    Returns:
        Confirmation message.
    """
    t0 = time.perf_counter()
    ok = True
    try:
        db = _get_db()
        ts = db.soft_delete(event_id)
        return f"Memory {event_id} soft-deleted at ts={ts}"
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "forget", (time.perf_counter() - t0) * 1000, ok,
            {"tenant": tenant_id or DEFAULT_TENANT},
        )


@mcp.tool()
def search(
    tenant_id: str | None = None,
    scope: str | None = None,
    limit: int = 20,
) -> str:
    """Query memories by tenant and optional scope filter.

    Args:
        tenant_id: Tenant key. Defaults to MADB_TENANT_ID env var.
        scope: Filter by scope ("user", "workspace", "org", "public_template").
        limit: Max records to return.

    Returns:
        List of matching memories.
    """
    t0 = time.perf_counter()
    ok = True
    try:
        db = _get_db()
        tenant = tenant_id or DEFAULT_TENANT

        results = db.query(tenant_id=tenant, scope=scope, limit=limit)

        if not results:
            return f"No memories found for tenant={tenant}" + (
                f" scope={scope}" if scope else ""
            )

        lines = []
        for r in results:
            payload = r.get("payload", "{}")
            rtags = r.get("tags", [])
            eid = r.get("event_id", "?")
            ts = r.get("ts", 0)
            lines.append(f"- {eid} [{','.join(rtags)}] ts={ts}: {payload[:200]}")

        return f"Found {len(results)} memories:\n" + "\n".join(lines)
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "search", (time.perf_counter() - t0) * 1000, ok,
            {"tenant": tenant_id or DEFAULT_TENANT},
        )


@mcp.tool()
def list_recent(
    tenant_id: str | None = None,
    limit: int = 10,
) -> str:
    """List the most recent memories for a tenant.

    Args:
        tenant_id: Tenant key. Defaults to MADB_TENANT_ID env var.
        limit: How many recent memories to return.

    Returns:
        Recent memories sorted by timestamp (newest first).
    """
    t0 = time.perf_counter()
    ok = True
    try:
        db = _get_db()
        tenant = tenant_id or DEFAULT_TENANT

        results = db.query(tenant_id=tenant, limit=limit)

        if not results:
            return "No memories yet."

        lines = []
        for r in results:
            payload = r.get("payload", "{}")
            rtags = r.get("tags", [])
            eid = r.get("event_id", "?")
            lines.append(f"- {eid} [{','.join(rtags)}]: {payload[:200]}")

        return f"Last {len(results)} memories:\n" + "\n".join(lines)
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "list_recent", (time.perf_counter() - t0) * 1000, ok,
            {"tenant": tenant_id or DEFAULT_TENANT},
        )


@mcp.tool()
def save_skill(
    name: str,
    description: str,
    pattern: str | None = None,
    language: str | None = None,
    examples: list[str] | None = None,
    source: str | None = None,
    tags: list[str] | None = None,
    tenant_id: str | None = None,
    importance: float = 0.9,
    caused_by: list[str] | None = None,
) -> str:
    """Store a reusable skill or coding pattern in MADB.

    Skills are stored as durable artifacts (never auto-GC'd) with importance
    >= 0.8, making them permanently available for recall. Re-saving the same
    skill name is idempotent (returns the same event_id).

    Args:
        name: Short skill identifier (e.g., "pytest-fixture-pattern").
        description: What the skill does and when to use it.
        pattern: Optional code pattern or template.
        language: Programming language (e.g., "python", "rust").
        examples: Optional usage examples.
        source: Where this skill was learned (e.g., file path, URL).
        tags: Additional tags (merged with "skill" tag automatically).
        tenant_id: Tenant key. Defaults to MADB_TENANT_ID env var.
        importance: Priority 0.0–1.0 (default 0.9 = GC-protected, not pinned).
        caused_by: Parent event_ids for causal chain tracking.

    Returns:
        The event_id of the stored skill.
    """
    t0 = time.perf_counter()
    ok = True
    _payload_tokens = 0
    try:
        db = _get_db()
        tenant = tenant_id or DEFAULT_TENANT

        # Build structured payload
        skill_payload: dict = {
            "skill": {
                "name": name,
                "description": description,
            }
        }
        if pattern is not None:
            skill_payload["skill"]["pattern"] = pattern
        if language is not None:
            skill_payload["skill"]["language"] = language
        if examples:
            skill_payload["skill"]["examples"] = examples
        if source is not None:
            skill_payload["skill"]["source"] = source

        # Merge user tags with mandatory "skill" tag
        merged_tags = list(set(["skill"] + (tags or [])))

        payload_json = json.dumps(skill_payload)
        event_id = db.write(
            tenant_id=tenant,
            scope="workspace",
            mem_type="artifact",
            payload=payload_json,
            tags=merged_tags,
            caused_by=caused_by or [],
            importance_hint=importance,
            actor="claude",
            idempotency_key=f"skill:{name}",
        )
        _payload_tokens = len(payload_json) // 4
        return f"Saved skill '{name}': {event_id}"
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "save_skill", (time.perf_counter() - t0) * 1000, ok,
            {"tenant": tenant_id or DEFAULT_TENANT,
             "payload_tokens": _payload_tokens if ok else 0},
        )


@mcp.tool()
def recall_skill(
    query: str,
    tenant_id: str | None = None,
    budget_tokens: int = 2000,
) -> str:
    """Recall skills matching a natural language query.

    Uses MADB's composite-scored recall with skill tag filtering and
    pinned-record inclusion. Returns structured skill details.

    Args:
        query: Natural language query (e.g., "error handling pattern").
        tenant_id: Tenant key. Defaults to MADB_TENANT_ID env var.
        budget_tokens: Approximate token budget for returned content.

    Returns:
        Ranked list of matching skills with scores and details.
    """
    t0 = time.perf_counter()
    ok = True
    meta: dict = {"tenant": tenant_id or DEFAULT_TENANT}
    try:
        db = _get_db()
        tenant = tenant_id or DEFAULT_TENANT

        results = db.recall_skills(
            query=query,
            tenant_id=tenant,
            budget_tokens=budget_tokens,
        )

        meta["result_count"] = len(results) if results else 0

        if not results:
            return "No matching skills found."

        tokens_served = 0
        top_score = 0.0
        lines = []
        for i, r in enumerate(results, 1):
            payload_raw = r.get("payload", "{}")
            score = r.get("score", 0.0)
            eid = r.get("event_id", "?")
            pinned = " [PINNED]" if r.get("pinned") else ""

            # Try to parse structured skill payload
            try:
                payload = json.loads(payload_raw) if isinstance(payload_raw, str) else payload_raw
            except (json.JSONDecodeError, TypeError):
                payload = {}

            skill = payload.get("skill", {})
            if skill:
                sname = skill.get("name", "unnamed")
                sdesc = skill.get("description", "")
                lines.append(f"{i}. [{score:.2f}]{pinned} {sname}")
                lines.append(f"   {sdesc}")
                if skill.get("pattern"):
                    lang = f" ({skill['language']})" if skill.get("language") else ""
                    lines.append(f"   Pattern{lang}: {skill['pattern'][:200]}")
                if skill.get("examples"):
                    lines.append(f"   Examples: {'; '.join(skill['examples'][:3])}")
                lines.append(f"   id={eid}")
            else:
                # Fallback for skills stored via generic remember
                lines.append(
                    f"{i}. [{score:.2f}]{pinned} {payload_raw[:200]}\n"
                    f"   id={eid}"
                )

            tokens_served += len(str(payload_raw)) // 4
            if score > top_score:
                top_score = score

        meta["tokens"] = tokens_served
        meta["top_score"] = top_score
        return "\n".join(lines)
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "recall_skill", (time.perf_counter() - t0) * 1000, ok, meta,
        )


@mcp.tool()
def list_skills(
    tenant_id: str | None = None,
    limit: int = 50,
) -> str:
    """List all saved skills ranked by composite score.

    Returns a compact summary of each skill (name, description,
    importance, event_id). Use recall_skill for detailed pattern lookup.

    Args:
        tenant_id: Tenant key. Defaults to MADB_TENANT_ID env var.
        limit: Maximum number of skills to return.

    Returns:
        Compact list of all skills.
    """
    t0 = time.perf_counter()
    ok = True
    try:
        db = _get_db()
        tenant = tenant_id or DEFAULT_TENANT

        # Use recall_skills with a broad query to get all skills ranked
        results = db.recall_skills(
            query="list all skills",
            tenant_id=tenant,
            budget_tokens=8000,
        )

        if not results:
            return "No skills saved yet."

        lines = [f"Skills ({min(len(results), limit)} found):"]
        for i, r in enumerate(results[:limit], 1):
            payload_raw = r.get("payload", "{}")
            score = r.get("score", 0.0)
            eid = r.get("event_id", "?")
            pinned = " [PINNED]" if r.get("pinned") else ""

            try:
                payload = json.loads(payload_raw) if isinstance(payload_raw, str) else payload_raw
            except (json.JSONDecodeError, TypeError):
                payload = {}

            skill = payload.get("skill", {})
            if skill:
                sname = skill.get("name", "unnamed")
                sdesc = skill.get("description", "")
                lines.append(f"  {i}. [{score:.2f}]{pinned} {sname} — {sdesc[:100]}")
            else:
                lines.append(f"  {i}. [{score:.2f}]{pinned} {str(payload_raw)[:120]}")
            lines.append(f"     id={eid}")

        return "\n".join(lines)
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "list_skills", (time.perf_counter() - t0) * 1000, ok,
            {"tenant": tenant_id or DEFAULT_TENANT},
        )


@mcp.tool()
def stats() -> str:
    """Engine metrics: writes, reads, flushes, compactions, WAL state, etc.

    Returns:
        JSON snapshot of all engine counters and derived metrics.
    """
    t0 = time.perf_counter()
    ok = True
    try:
        db = _get_db()
        s = dict(db.stats())
        return json.dumps(s, indent=2)
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "stats", (time.perf_counter() - t0) * 1000, ok,
        )


@mcp.tool()
def trace_cause(
    event_id: str,
    direction: str = "backward",
    max_depth: int = 5,
) -> str:
    """Trace the causal chain — see what caused a memory or what it caused.

    Walks the causal DAG by following ``caused_by`` links (backward) or
    finding memories that list this event in their ``caused_by`` (forward).

    Args:
        event_id: Starting event UUID.
        direction: "backward" (ancestors) or "forward" (descendants).
        max_depth: Maximum hops to traverse (default 5).

    Returns:
        Formatted causal chain with indentation showing depth.
    """
    t0 = time.perf_counter()
    ok = True
    try:
        db = _get_db()

        if direction == "backward":
            return _trace_backward(db, event_id, max_depth)
        elif direction == "forward":
            return _trace_forward(db, event_id, max_depth)
        else:
            return f"Invalid direction: {direction}. Use 'backward' or 'forward'."
    except Exception:
        ok = False
        raise
    finally:
        _analytics.record_call(
            "trace_cause", (time.perf_counter() - t0) * 1000, ok,
        )


def _trace_backward(db: MetaAgentsDB, start_id: str, max_depth: int) -> str:
    """Walk caused_by links upward to find ancestors."""
    lines: list[str] = []
    visited: set[str] = set()
    queue: list[tuple[str, int]] = [(start_id, 0)]

    while queue:
        eid, depth = queue.pop(0)
        if eid in visited or depth > max_depth:
            continue
        visited.add(eid)

        record = db.get(eid)
        if record is None:
            indent = "  " * depth
            lines.append(f"{indent}[{depth}] {eid} — NOT FOUND")
            continue

        rec = dict(record)
        indent = "  " * depth
        payload_preview = str(rec.get("payload", ""))[:120]
        tags = rec.get("tags", [])
        lines.append(
            f"{indent}[{depth}] {eid} [{','.join(tags)}]: {payload_preview}"
        )

        for parent_id in rec.get("caused_by", []):
            if parent_id not in visited:
                queue.append((parent_id, depth + 1))

    if not lines:
        return f"No causal chain found for {start_id}"
    return f"Causal chain (backward, max_depth={max_depth}):\n" + "\n".join(lines)


def _trace_forward(db: MetaAgentsDB, start_id: str, max_depth: int) -> str:
    """Find descendants — memories whose caused_by includes this event.

    Note: This does a scan of the tenant's memories to find forward links,
    since the engine doesn't maintain a forward index. Use sparingly.
    """
    db_inst = db
    # Get the starting record to find its tenant
    start_rec = db_inst.get(start_id)
    if start_rec is None:
        return f"Memory {start_id} not found."

    start_dict = dict(start_rec)
    tenant = start_dict.get("tenant_id", DEFAULT_TENANT)

    # Scan all memories for this tenant and build a forward adjacency map
    all_records = db_inst.query(tenant_id=tenant, limit=10000)
    forward_map: dict[str, list[str]] = {}
    record_map: dict[str, dict] = {}
    for r in all_records:
        rec = dict(r)
        eid = rec.get("event_id", "")
        record_map[eid] = rec
        for parent_id in rec.get("caused_by", []):
            forward_map.setdefault(parent_id, []).append(eid)

    lines: list[str] = []
    visited: set[str] = set()
    queue: list[tuple[str, int]] = [(start_id, 0)]

    while queue:
        eid, depth = queue.pop(0)
        if eid in visited or depth > max_depth:
            continue
        visited.add(eid)

        rec = record_map.get(eid)
        indent = "  " * depth
        if rec is None:
            lines.append(f"{indent}[{depth}] {eid} — NOT IN SCAN")
        else:
            payload_preview = str(rec.get("payload", ""))[:120]
            tags = rec.get("tags", [])
            lines.append(
                f"{indent}[{depth}] {eid} [{','.join(tags)}]: {payload_preview}"
            )

        for child_id in forward_map.get(eid, []):
            if child_id not in visited:
                queue.append((child_id, depth + 1))

    if not lines:
        return f"No descendants found for {start_id}"
    return f"Causal chain (forward, max_depth={max_depth}):\n" + "\n".join(lines)


@mcp.tool()
def analytics() -> str:
    """Show MADB MCP usage analytics: call counts, latencies, recall precision, and Memory ROI.

    Memory ROI measures how much value MADB recall provides to Claude Code:
    - Tokens served from recall (context delivered without file re-reads)
    - Estimated file reads avoided
    - Recall precision (hit rate + average relevance score)
    - Write-to-read ratio (how much value each written memory generates)

    Returns:
        Formatted usage snapshot including per-tool stats, recall precision,
        and Memory ROI metrics.
    """
    snap = _analytics.snapshot()
    rp = snap.get("recall_precision", {})
    roi = snap.get("memory_roi", {})

    lines = [
        "MADB MCP Usage Analytics",
        "=" * 50,
        f"Session:            {snap['session_id'][:8]}...",
        f"User:               {snap['user']}@{snap['host']}",
        f"Duration:           {snap['session_duration_s']}s",
        f"Calls/min:          {snap['calls_per_minute']}",
        f"Total Calls:        {snap['total_calls']}",
        f"Error Rate:         {snap['error_rate']}%",
        f"All-Tool P50:       {snap['all_tool_p50_ms']}ms",
        f"All-Tool P99:       {snap['all_tool_p99_ms']}ms",
        "",
        "Recall Precision:",
        "-" * 50,
        f"  Hit Rate:         {rp.get('hit_rate_pct', 0)}% "
        f"({rp.get('recalls_with_results', 0)}/{rp.get('total_recalls', 0)} returned results)",
        f"  Avg Top Score:    {rp.get('avg_top_score', 0)} "
        "(composite similarity — 1.0 = perfect match)",
        f"  Avg Results:      {rp.get('avg_results_per_recall', 0)} per recall",
        "",
        "Memory ROI:",
        "-" * 50,
        f"  Tokens Served:    {roi.get('tokens_served_from_recall', 0):,} "
        "(context from memory, not file re-reads)",
        f"  File Reads Saved: ~{roi.get('est_file_reads_avoided', 0)} "
        "(at ~1500 tokens/file read)",
        f"  Memories Written: {roi.get('memories_written', 0)} "
        f"({roi.get('memories_written_tokens', 0):,} tokens invested)",
        f"  Write-to-Read:    {roi.get('write_to_read_ratio', 0)}x "
        "(tokens recalled per token written)",
        "",
        "Per-Tool Breakdown:",
        "-" * 50,
    ]

    for tool_name, ts in snap.get("tools", {}).items():
        lines.append(
            f"  {tool_name:15s}  {ts['calls']:>5} calls  "
            f"avg={ts['avg_latency_ms']}ms  "
            f"p50={ts['p50_latency_ms']}ms  "
            f"p99={ts['p99_latency_ms']}ms  "
            f"err={ts['errors']}"
        )
        if "tokens_served" in ts:
            lines.append(
                f"{'':17s}  tokens_served={ts['tokens_served']}  "
                f"total_results={ts['total_results']}  "
                f"hits={ts.get('recall_hits', 0)}"
            )
        if "memories_written" in ts:
            lines.append(f"{'':17s}  memories_written={ts['memories_written']}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------


@mcp.resource("madb://memories/{event_id}")
def memory_resource(event_id: str) -> str:
    """Read a memory record by event_id as an MCP resource."""
    db = _get_db()
    record = db.get(event_id)
    if record is None:
        return f"Memory {event_id} not found."
    return json.dumps(dict(record), indent=2, default=str)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run()
