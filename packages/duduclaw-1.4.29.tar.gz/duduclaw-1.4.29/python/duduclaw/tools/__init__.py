"""MCP tools for agents"""
