"""Channel plugins for DuDuClaw"""
