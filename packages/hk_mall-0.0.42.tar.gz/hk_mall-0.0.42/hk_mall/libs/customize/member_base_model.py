# -*- coding: utf-8 -*-
"""
:Author: CaiYouBin
:Date: 2026-04-07 18:06:46
:LastEditTime: 2026-04-14 17:45:28
:LastEditors: CaiYouBin
:Description: 
"""
# -*- coding: utf-8 -*-
from hk_mall.libs.customize.member_helper import MemberHelper
"""
:Author: CaiYouBin
:Date: 2026-04-02 18:09:58
:LastEditTime: 2026-04-07 18:35:58
:LastEditors: CaiYouBin
:Description: 
"""
from seven_cloudapp_frame.libs.common import *
from seven_cloudapp_frame.models.seven_model import *
from seven_cloudapp_frame.libs.customize.seven_helper import *
from seven_cloudapp_frame.models.db_models.user.user_info_model import UserInfoModel
from hk_mall.models.db_models.member.member_info_model import *
from hk_mall.models.db_models.member.member_event_model import *
from seven_cloudapp_frame.models.app_base_model import *
from seven_cloudapp_frame.models.db_models.user.user_account_model import *
from hk_mall.models.db_models.scheme.scheme_info_model import *
from hk_mall.models.member_model import *
from hk_mall.models.db_models.member.member_asset_integral_model import *
from hk_mall.models.db_models.scheme.scheme_level_info_model import *
from hk_mall.models.db_models.scheme.scheme_info_model import *
from hk_mall.models.db_models.scheme.scheme_level_model import *
from hk_mall.models.db_models.scheme.scheme_integral_model import *
from hk_mall.models.db_models.scheme.scheme_growth_model import *



class MemberBaseModel:
    def __init__(self, context=None, logging_error=None, logging_info=None, db_config_dict=None):
        self.context = context
        self.logging_link_error = logging_error
        self.logging_link_info = logging_info
        self.db_config_dict = db_config_dict
    
    def member_register(self,app_id,act_id,ouid,join_date=""):
        """
        会员注册
        :param app_id: 应用ID
        :param act_id: 活动ID/账号ID
        :param ouid: 开放平台用户ID
        :param join_date: 入会时间
        :return: InvokeResultData 调用结果数据
        """
        invoke_result_data = InvokeResultData()
        
        now_time = TimeHelper.get_now_format_time()
        execute_lock_key = f"execute_lock_open:{self.__class__.__name__}_lock:{ouid}"
        try:
            if SevenHelper.is_continue_request(execute_lock_key, expire=1000 * 60 * 2) is True:
                invoke_result_data.error_code = "request_limit"
                invoke_result_data.error_message = '请求过于频繁，请稍后重试'
                return invoke_result_data
            
            app_info_dict = AppBaseModel().get_app_info_dict(app_id)
            scheme_info_dict = SchemeInfoModel().get_dict("app_id=%s", params=[app_info_dict["app_id"]])
            if not scheme_info_dict:
                invoke_result_data.error_code = "scheme_not_exist"
                invoke_result_data.error_message = "体系不存在"
                return invoke_result_data
            member_db_config = share_config.get_value("db_cloudapp_member")
            main_db_config = share_config.get_value("db_saas_hkhy_base")
            # 检查会员是否已存在
            db_transaction = DbTransaction(db_config_dict=member_db_config, context=self.context)
            user_info_model = UserInfoModel(db_connect_key="db_saas_hkhy_base",context=self.context).set_sub_table(app_id)
            member_info_model = MemberInfoModel(db_connect_key="db_cloudapp_member",context=self.context, db_transaction=db_transaction).set_sub_table(app_id)
            member_event_model = MemberEventModel(db_connect_key="db_cloudapp_member",context=self.context, db_transaction=db_transaction).set_sub_table(app_id)
            user_info_dict = user_info_model.get_cache_dict('act_id=%s and open_id=%s', field="*", params=[act_id,ouid], dependency_key=DependencyKey.user_info(act_id,"",ouid))
            omid = user_info_dict["open_id"]
            mobile = user_info_dict["telephone"]
            level_id = 0
            integral = 0
            real_name = ""
            birthday = user_info_dict["birthday"]
            sex = user_info_dict["sex"]
            province = ""
            city = ""
            join_date = join_date if join_date else now_time
            
            if user_info_dict:
                if user_info_dict["is_member"] == 1:
                    invoke_result_data.error_code = "already_bind"
                    invoke_result_data.error_message = "会员已绑定"
                    return invoke_result_data
                if user_info_dict["open_id"]:
                    member_info_dict = member_info_model.get_cache_dict(where="one_id=%s and business_id=%s", field="one_id,level_id,include_plattypes,include_stores,member_status", params=[user_info_dict["union_id"], app_info_dict["seller_id"]], dependency_key=CacheKey.member_info(user_info_dict["open_id"]))
                    # member_info_dict = member_info_model.get_dict(where="one_id=%s", field="one_id,level_id,include_plattypes,include_stores,member_status", params=[user_info_dict["one_id"]])
                    if not member_info_dict:
                        invoke_result_data = self.register(
                            mobile,
                            app_info_dict,
                            act_id,
                            user_info_dict, 
                            ouid, 
                            omid, 
                            real_name, 
                            birthday, 
                            sex, 
                            province, 
                            city, 
                            join_date, 
                            now_time, 
                            integral, 
                            level_id, 
                            db_transaction, 
                            user_info_model, 
                            member_info_model, 
                            member_event_model, 
                            scheme_info_dict
                        )
                        
                        return invoke_result_data
                    else:
                        # 生成会员事件记录
                        member_event = MemberEvent()
                        member_event.app_id = app_info_dict["app_id"]
                        member_event.business_id = app_info_dict["seller_id"]
                        member_event.one_id = user_info_dict["open_id"]
                        member_event.store_id = app_info_dict["store_id"]
                        member_event.platform_id = 4
                        member_event.event_type = 3
                        member_event.event_reason = '会员绑定'
                        member_event.event_desc = SevenHelper.json_dumps({"detail": f"会员绑定：{app_info_dict['store_name']}"})
                        member_event.create_date = now_time

                        member_condition_where = ConditionWhere()
                        member_info_dict["include_stores"] = SevenHelper.json_loads(member_info_dict["include_stores"])
                        member_info_dict["include_stores"].append({"store_id": app_info_dict["store_id"], "type": 4})
                        member_condition_where.add_condition("include_stores=%s", SevenHelper.json_dumps(member_info_dict["include_stores"]))
                        member_info_dict["include_plattypes"] = SevenHelper.json_loads(member_info_dict["include_plattypes"])
                        if member_info_dict['member_status'] == 2:
                            member_condition_where.add_condition("member_status=1")
                        member_condition_where.add_condition("last_join_date=%s,last_join_store_id=%s", [join_date, app_info_dict["store_id"]])

                        try:
                            db_transaction.begin_transaction()
                            user_info_model.update_table("is_member=1,d2=%s", where='act_id=%s and user_id=%s', params=[join_date,act_id, user_info_dict["user_id"]])
                            member_condition_where.params.append(user_info_dict["union_id"])
                            member_info_model.update_table(update_sql=member_condition_where.to_string(','), where="one_id=%s", params=member_condition_where.params)
                            member_event_model.add_entity(member_event)
                            result, msg = db_transaction.commit_transaction(return_detail_tuple=True)
                            if result is False:
                                raise Exception("事务执行异常：" + str(msg))
                            user_info_model.delete_dependency_keys([DependencyKey.user_info(act_id,"",user_info_dict["union_id"]),DependencyKey.user_info(act_id,user_info_dict["id_md5"])])

    
                            member_asset_1_model = MemberAssetIntegralModel(context=self).set_sub_table(app_id)
                            member_asset_1_dict = member_asset_1_model.get_dict("one_id=%s", field="asset_value", params=[user_info_dict['union_id']])
                            integral = member_asset_1_dict['asset_value'] if member_asset_1_dict else 0
                            invoke_result_data.success = True
                            invoke_result_data.data = {"one_id": user_info_dict['union_id'], "integral": integral, "level_id": member_info_dict['level_id']}
                            return invoke_result_data
                        except Exception as ex:
                            if self.context:
                                self.context.logging_link_error(f"会员绑定异常,ex:{traceback.format_exc()}")
                            elif self.logging_link_error:
                                self.logging_link_error(f"会员绑定异常,ex:{traceback.format_exc()}")
                            return self.response_json_error("error", "会员绑定失败")
            else:
                invoke_result_data.error_code = "error"
                invoke_result_data.error_message = "会员不存在或未绑定"
                return invoke_result_data
            
        except Exception as ex:
            
            invoke_result_data.error_code = "error"
            invoke_result_data.error_message = "会员注册或绑定失败"
            if self.context:
                self.context.logging_link_error(f"会员注册或绑定异常,ex:{traceback.format_exc()}")
            elif self.logging_link_error:
                self.logging_link_error(f"会员注册或绑定异常,ex:{traceback.format_exc()}")
            return invoke_result_data
        finally:
            SevenHelper.delete_continue_request(execute_lock_key)

    def register(self, mobile, app_info_dict,act_id,user_info_dict, ouid, one_id, real_name, birthday, sex, province, city, join_date, now_time, integral, level_id, db_transaction, user_info_model, member_info_model, member_event_model, scheme_info_dict):
        """
        :description: 会员注册
        :param mobile:手机号
        :param app_info_dict:应用信息
        :param user_id:用户id
        :param ouid:ouid
        :param one_id:one_id
        :param real_name:姓名
        :param birthday:生日
        :param sex:性别
        :param province:省
        :param city:市
        :param join_date:入会时间
        :param now_time:现在时间
        :param integral:积分
        :param level_id:等级
        :param db_transaction:事务对象
        :param user_info_model:用户信息对象
        :param member_info_model:会员信息对象
        :param member_event_model:会员事件对象
        :return:
        :last_editors: HuangJianYi
        """
        invoke_result_data = InvokeResultData()
        
        sensitive_encrypt_key = SevenHelper.json_loads(app_info_dict["s4"]).get('sensitive_encrypt_key', '')
        # 加密手机号
        aes_encrypt = CryptoHelper.aes_encrypt(mobile, sensitive_encrypt_key)
        user_id = user_info_dict["user_id"]
        member_info = MemberInfo()
        member_info.app_id = app_info_dict["app_id"]
        member_info.one_id = one_id
        member_info.member_telephone = aes_encrypt
        member_info.member_mask_telephone = MemberHelper.mask_telephone_middle(phone_str=mobile)
        member_info.business_id = app_info_dict["seller_id"]
        member_info.scheme_id = scheme_info_dict["id"]
        member_info.include_plattypes = SevenHelper.json_dumps([{"type": 4}])
        member_info.include_stores = SevenHelper.json_dumps([{"store_id": app_info_dict["store_id"], "type": 4}])
        member_info.level_id = 1  # 默认初始等级为1
        member_info.level_valid_date = '2900-01-01 00:00:00.000'
        member_info.first_ouid = ouid
        member_info.first_store_integral = integral
        member_info.first_store_level_id = level_id
        member_info.first_plat_store_id = app_info_dict["store_id"]
        member_info.first_join_date = join_date
        member_info.first_join_store_id = app_info_dict["store_id"]
        member_info.last_join_date = join_date
        member_info.last_join_store_id = app_info_dict["store_id"]
        member_info.extend_info = {}
        member_info.member_status = 1
        member_info.create_date = now_time
        member_info.modify_date = now_time

        # 生成会员事件记录
        member_event = MemberEvent()
        member_event.app_id = app_info_dict["app_id"]
        member_event.business_id = app_info_dict["seller_id"]
        member_event.one_id = one_id
        member_event.store_id = app_info_dict["store_id"]
        member_event.platform_id = 4
        member_event.event_type = 4
        member_event.event_reason = '会员注册'
        member_event.event_desc = SevenHelper.json_dumps({"detail": f"会员注册：{app_info_dict['store_name']}"})
        member_event.create_date = now_time

        try:
            db_transaction.begin_transaction()
            user_info_model.update_table("is_member=1,d2=%s", where='act_id=%s and open_id=%s', params=[join_date,act_id,ouid])
            member_info_model.add_entity(member_info)
            member_event_model.add_entity(member_event)
            result, msg = db_transaction.commit_transaction(return_detail_tuple=True)
            if result is False:
                raise Exception("事务执行异常：" + str(msg))
            redis_init = SevenHelper.redis_init()
            log_id = TimeHelper.get_now_timestamp(True)
            
            user_info_model.delete_dependency_keys([DependencyKey.user_info(act_id,"",user_info_dict["open_id"]),DependencyKey.user_info(act_id,user_info_dict["id_md5"])])
            

            # 新会员注册队列消息
            redis_init.rpush(ListKey.register_member_list(app_info_dict["seller_id"]), SevenHelper.json_dumps({
                    "user_id": user_id,
                    "scheme_id": scheme_info_dict["id"],
                    "app_id": app_info_dict["app_id"],
                    "log_id": log_id,
                }))
            
            invoke_result_data.data = {"one_id": one_id, "integral": integral, "level_id": level_id}
            return invoke_result_data
        except Exception as ex:
            if self.context:
                self.context.logging_link_error(f"会员注册异常,ex:{traceback.format_exc()}")
            elif self.logging_link_error:
                self.logging_link_error(f"会员注册异常,ex:{traceback.format_exc()}")
            invoke_result_data.error_code = "error"
            invoke_result_data.error_message = "会员注册失败"
            return invoke_result_data

    def update_member_profile(self, app_id, act_id, ouid, birthday=None, sex=None):
        """
        更新会员资料（生日和性别）
        :param app_id: 应用ID
        :param act_id: 活动ID/账号ID
        :param ouid: 开放平台用户ID
        :param birthday: 生日
        :param sex: 性别
        :return: InvokeResultData 调用结果数据
        """
        invoke_result_data = InvokeResultData()
        
        now_time = TimeHelper.get_now_format_time()
        execute_lock_key = f"execute_lock_open:{self.__class__.__name__}_profile_lock:{ouid}"
        try:
            if SevenHelper.is_continue_request(execute_lock_key, expire=1000 * 60 * 2) is True:
                invoke_result_data.error_code = "request_limit"
                invoke_result_data.error_message = '请求过于频繁，请稍后重试'
                return invoke_result_data
            
            app_info_dict = AppBaseModel().get_app_info_dict(app_id)
            scheme_info_dict = SchemeInfoModel().get_dict("app_id=%s", params=[app_info_dict["app_id"]])
            if not scheme_info_dict:
                invoke_result_data.error_code = "scheme_not_exist"
                invoke_result_data.error_message = "体系不存在"
                return invoke_result_data
            
            member_db_config = share_config.get_value("db_cloudapp_member")
            
            # 检查会员是否存在
            db_transaction = DbTransaction(db_config_dict=member_db_config, context=self.context)
            user_info_model = UserInfoModel(db_connect_key="db_saas_hkhy_base", context=self.context).set_sub_table(app_id)
            member_info_model = MemberInfoModel(db_connect_key="db_cloudapp_member", context=self.context, db_transaction=db_transaction).set_sub_table(app_id)
            member_event_model = MemberEventModel(db_connect_key="db_cloudapp_member", context=self.context, db_transaction=db_transaction).set_sub_table(app_id)
            
            user_info_dict = user_info_model.get_cache_dict('act_id=%s and open_id=%s', field="*", params=[act_id, ouid], dependency_key=DependencyKey.user_info(act_id, "", ouid))
            
            if not user_info_dict:
                invoke_result_data.error_code = "user_not_exist"
                invoke_result_data.error_message = "用户不存在"
                return invoke_result_data
            
            if user_info_dict.get("is_member") != 1:
                invoke_result_data.error_code = "not_member"
                invoke_result_data.error_message = "该用户还不是会员"
                return invoke_result_data
            
            if not user_info_dict.get("open_id"):
                invoke_result_data.error_code = "member_not_exist"
                invoke_result_data.error_message = "会员信息不存在"
                return invoke_result_data
            
            member_info_dict = member_info_model.get_cache_dict(
                where="one_id=%s and app_id=%s", 
                field="one_id,level_id,member_status", 
                params=[user_info_dict["open_id"], app_info_dict["app_id"]], 
                dependency_key=CacheKey.member_info(user_info_dict["open_id"])
            )
            
            if not member_info_dict:
                invoke_result_data.error_code = "member_not_exist"
                invoke_result_data.error_message = "会员信息不存在"
                return invoke_result_data
            
            # 构建更新字段
            update_fields = []
            update_params = []
            
            if birthday:
                update_fields.append("birthday=%s")
                update_params.append(birthday)
            
            if sex is not None:
                update_fields.append("sex=%s")
                update_params.append(sex)
            
            if not update_fields:
                invoke_result_data.error_code = "no_update_data"
                invoke_result_data.error_message = "没有需要更新的数据"
                return invoke_result_data
            
            # 添加修改时间到会员信息更新字段
            member_update_fields = update_fields + ["modify_date=%s"]
            member_update_params = update_params + [now_time]
            
            # 生成会员事件记录
            member_event = MemberEvent()
            member_event.app_id = app_info_dict["app_id"]
            member_event.business_id = app_info_dict["seller_id"]
            member_event.one_id = user_info_dict["union_id"]
            member_event.store_id = app_info_dict["store_id"]
            member_event.platform_id = 4
            member_event.event_type = 5  # 会员资料更新事件类型
            member_event.event_reason = '会员资料更新'
            
            event_detail = {"detail": f"会员资料更新：{app_info_dict['store_name']}"}
            if birthday:
                event_detail["birthday"] = birthday
            if sex is not None:
                event_detail["sex"] = sex
            member_event.event_desc = SevenHelper.json_dumps(event_detail)
            member_event.create_date = now_time
            
            try:
                db_transaction.begin_transaction()
                # 更新会员信息表（包含修改时间）
                member_info_model.update_table(
                    ",".join(member_update_fields), 
                    where='one_id=%s and app_id=%s', 
                    params=member_update_params + [user_info_dict["open_id"], app_info_dict["app_id"]]
                )
                # 添加会员事件记录
                member_event_model.add_entity(member_event)
                result, msg = db_transaction.commit_transaction(return_detail_tuple=True)
                if result is False:
                    raise Exception("事务执行异常：" + str(msg))
                
                # 清除缓存
                user_info_model.delete_dependency_keys([DependencyKey.user_info(act_id, "", user_info_dict["open_id"]), DependencyKey.user_info(act_id, user_info_dict.get("id_md5", ""))])
                
                invoke_result_data.success = True
                invoke_result_data.data = {"one_id": user_info_dict["open_id"], "message": "会员资料更新成功"}
                return invoke_result_data
            except Exception as ex:
                db_transaction.rollback_transaction()
                if self.context:
                    self.context.logging_link_error(f"会员资料更新异常,ex:{traceback.format_exc()}")
                elif self.logging_link_error:
                    self.logging_link_error(f"会员资料更新异常,ex:{traceback.format_exc()}")
                invoke_result_data.error_code = "error"
                invoke_result_data.error_message = "会员资料更新失败"
                return invoke_result_data
            
        except Exception as ex:
            invoke_result_data.error_code = "error"
            invoke_result_data.error_message = "会员资料更新失败"
            if self.context:
                self.context.logging_link_error(f"会员资料更新异常,ex:{traceback.format_exc()}")
            elif self.logging_link_error:
                self.logging_link_error(f"会员资料更新异常,ex:{traceback.format_exc()}")
            return invoke_result_data
        finally:
            SevenHelper.delete_continue_request(execute_lock_key)
    
    def get_scheme_id(self,app_id):
        """
        :description: 获取应用ID对应的体系ID
        :param app_id: 应用ID
        :return: 体系ID
        :last_editors: HuangJianYi
        """
        app_base_model = AppBaseModel(context=self.context)
        app_info_dict = app_base_model.get_app_info_dict(app_id)
        scheme_info_dict = SchemeInfoModel(context=self.context).get_cache_dict("business_id=%s", params=[app_info_dict["seller_id"]],dependency_key=CacheKey.scheme_info(app_info_dict["seller_id"]))
        if not scheme_info_dict:
            return 0
        return scheme_info_dict["id"]
    
    def get_scheme_level(self,app_id):
        """
        :description: 获取应用ID对应的体系等级配置
        :param app_id: 应用ID
        :return: 体系等级配置
        :last_editors: HuangJianYi
        """
        scheme_id = self.get_scheme_id(app_id)
        scheme_level_model = SchemeLevelModel(context=self.context)
        scheme_level_info_dict = scheme_level_model.get_cache_dict_list("scheme_id = %s", params=[scheme_id],dependency_key=CacheKey.scheme_level(scheme_id))
        return scheme_level_info_dict
    
    def get_scheme_integral_list(self,app_id):
        """
        :description: 获取应用ID对应的体系积分配置列表
        :param app_id: 应用ID
        :return: 体系积分配置列表
        :last_editors: HuangJianYi
        """
        scheme_id = self.get_scheme_id(app_id)
        scheme_integral_model = SchemeIntegralModel(context=self.context)
        scheme_integral_info_dict_list = scheme_integral_model.get_cache_dict_list("scheme_id = %s and is_grant = 1", params=[scheme_id],dependency_key=CacheKey.scheme_integral(scheme_id))
        return scheme_integral_info_dict_list
    
    def get_scheme_growth_list(self,app_id):
        """
        :description: 获取应用ID对应的体系成长值配置列表
        :param app_id: 应用ID
        :return: 体系成长值配置列表
        :last_editors: HuangJianYi
        """
        scheme_id = self.get_scheme_id(app_id)
        scheme_growth_model = SchemeGrowthModel(context=self.context)
        scheme_growth_info_dict_list = scheme_growth_model.get_cache_dict_list("scheme_id = %s and is_grant = 1", params=[scheme_id],dependency_key=CacheKey.scheme_growth(scheme_id))
        return scheme_growth_info_dict_list
    
    
    def get_member_level_info_list(self,app_id,level_id=None,field="*"):
        """
        :description: 获取会员等级信息列表
        :param app_id: 应用ID
        :param level_id: 等级ID
        :return: InvokeResultData 调用结果数据
        """
        scheme_id = self.get_scheme_id(app_id)
        scheme_level_info_model = SchemeLevelInfoModel(context=self.context)
        condition = ConditionWhere()
        condition.add_condition("scheme_id = %s")
        params=[scheme_id]
        if level_id:
            condition.add_condition("level_id = %s")
            params.append(level_id)
        
        scheme_level_info_dict_list = scheme_level_info_model.get_cache_dict_list(condition.to_string(), field=field, params=params,dependency_key=CacheKey.scheme_level_info(scheme_id))
        return scheme_level_info_dict_list

    
    def get_user_member_info(self,app_id,one_id=None,field="one_id,level_id,member_status"):
        """
        :description: 获取用户会员信息
        :param app_id: 应用ID
        :param open_id: 开放平台用户ID
        :param one_id: 会员ID
        :return: InvokeResultData 调用结果数据
        """

        
        app_base_model = AppBaseModel(context=self.context)
        member_info_model = MemberInfoModel(context=self.context).set_sub_table(app_id)
        scheme_level_info_model = SchemeLevelInfoModel(context=self.context)

        member_info_dict = member_info_model.get_cache_dict(
            where="one_id=%s and app_id=%s", 
            field=field, 
            params=[one_id, app_id], 
            dependency_key=CacheKey.member_info(one_id)
        )
        scheme_id = self.get_scheme_id(app_id)
        
        if not member_info_dict:
            return None
        
        scheme_level_info_dict = scheme_level_info_model.get_cache_dict(
            where="scheme_id=%s and level_id=%s", 
            field="*", 
            params=[scheme_id, member_info_dict["level_id"]], 
            dependency_key=CacheKey.scheme_level_info(scheme_id, member_info_dict["level_id"])
        )
        if not scheme_level_info_dict:
            return None
        
        member_info_dict["level_name"] = scheme_level_info_dict["level_name"]
        
        return member_info_dict
    
    
    