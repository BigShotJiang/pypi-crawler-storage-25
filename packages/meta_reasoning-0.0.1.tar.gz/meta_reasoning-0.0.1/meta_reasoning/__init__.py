"""
Meta-Reasoning SDK

Reasoning is not a property of the model —
it is an emergent dynamic of external control.
"""

from .controller import CognitiveController
from .engine import CognitiveEngine, CycleResult, EngineResult
from .ledger import EpistemicLedger
from .metrics import compute_metrics
from .mutations import generate_mutations
from .substrate import LLMBackend, Substrate
from .types import (
    CognitiveMetrics,
    CognitiveMove,
    LedgerEntry,
    Mutation,
    MutationType,
    ReasoningTrace,
    StructuredOutput,
)

__all__ = [
    "CognitiveController",
    "CognitiveEngine",
    "CognitiveMetrics",
    "CognitiveMove",
    "CycleResult",
    "EngineResult",
    "EpistemicLedger",
    "LedgerEntry",
    "LLMBackend",
    "Mutation",
    "MutationType",
    "ReasoningTrace",
    "StructuredOutput",
    "Substrate",
    "compute_metrics",
    "generate_mutations",
]
