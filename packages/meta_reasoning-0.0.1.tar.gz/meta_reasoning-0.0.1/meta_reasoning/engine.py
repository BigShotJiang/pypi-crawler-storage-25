"""
Cognitive Engine — the governed reasoning loop.

This is NOT an agent. There is no autonomous decision-making.
There is a governed cognitive loop where linguistic generation is
continuously deformed by external control that does not participate
in semantic production.

Loop:
  1. Substrate generates structured output under constraints
  2. Controller observes the cognitive form (not content)
  3. Controller decides: continue, fail, or terminate
  4. Controller generates mutations for the next cycle
  5. Repeat until termination or max cycles
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .controller import CognitiveController
from .ledger import EpistemicLedger
from .substrate import LLMBackend, Substrate
from .types import CognitiveMetrics, StructuredOutput


@dataclass
class CycleResult:
    """Result of a single cognitive cycle."""
    cycle: int
    output: StructuredOutput
    metrics: CognitiveMetrics
    outcome: str


@dataclass
class EngineResult:
    """Result of a complete reasoning session."""
    cycles: list[CycleResult] = field(default_factory=list)
    final_outcome: str = "not_started"

    @property
    def final_output(self) -> StructuredOutput | None:
        return self.cycles[-1].output if self.cycles else None


class CognitiveEngine:
    """Orchestrates the governed cognitive loop."""

    def __init__(
        self,
        backend: LLMBackend,
        max_cycles: int = 6,
        max_violations: int = 2,
    ) -> None:
        self._substrate = Substrate(backend)
        self._ledger = EpistemicLedger()
        self._controller = CognitiveController(
            ledger=self._ledger,
            max_violations=max_violations,
        )
        self._max_cycles = max_cycles

    @property
    def ledger(self) -> EpistemicLedger:
        return self._ledger

    @property
    def controller(self) -> CognitiveController:
        return self._controller

    def run(self, task: str) -> EngineResult:
        """Execute the full governed reasoning loop on a task."""
        result = EngineResult()

        for _ in range(self._max_cycles):
            mutations = self._controller.get_mutations()
            history_summary = self._ledger.summary_for_prompt()

            output = self._substrate.generate(
                task=task,
                mutations=mutations,
                history_summary=history_summary or None,
            )

            metrics = self._controller.observe(output)
            outcome = self._controller.decide(output, metrics)

            cycle_result = CycleResult(
                cycle=self._controller.cycle,
                output=output,
                metrics=metrics,
                outcome=outcome,
            )
            result.cycles.append(cycle_result)

            if outcome == "failed":
                result.final_outcome = "failed"
                return result

            if outcome == "terminated":
                result.final_outcome = "terminated"
                return result

        result.final_outcome = "max_cycles_reached"
        return result
