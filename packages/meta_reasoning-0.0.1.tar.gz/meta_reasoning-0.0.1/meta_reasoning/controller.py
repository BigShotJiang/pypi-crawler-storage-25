"""
Cognitive Controller (Level 2) — the heart of the SDK.

The controller is semantically blind. It does NOT evaluate whether
a response is "correct". It observes:
  - form
  - trajectory
  - redundancy
  - stall
  - premature convergence

It is a conductor, a coach, a theatre director.
It does not play the instrument.
"""

from __future__ import annotations

from .ledger import EpistemicLedger
from .metrics import compute_metrics
from .mutations import generate_mutations
from .types import (
    CognitiveMetrics,
    LedgerEntry,
    Mutation,
    ReasoningTrace,
    StructuredOutput,
)


class CognitiveController:
    """Semantically-blind governor of reasoning dynamics."""

    def __init__(
        self,
        ledger: EpistemicLedger | None = None,
        max_violations: int = 2,
    ) -> None:
        self._ledger = ledger or EpistemicLedger()
        self._max_violations = max_violations
        self._cycle = 0
        self._active_mutations: list[Mutation] = []

    @property
    def ledger(self) -> EpistemicLedger:
        return self._ledger

    @property
    def cycle(self) -> int:
        return self._cycle

    @property
    def active_mutations(self) -> list[Mutation]:
        return list(self._active_mutations)

    def observe(self, output: StructuredOutput) -> CognitiveMetrics:
        """Observe an LLM output and compute cognitive metrics."""
        history = [e.trace for e in self._ledger.entries]
        return compute_metrics(output.reasoning_trace, history, self._active_mutations)

    def decide(self, output: StructuredOutput, metrics: CognitiveMetrics) -> str:
        """Decide the outcome: 'continued', 'failed', or 'terminated'.
        Record the cycle in the ledger. Return the outcome."""
        self._cycle += 1
        failure_reason = None

        if metrics.constraint_violations > self._max_violations:
            outcome = "failed"
            failure_reason = f"Too many constraint violations ({metrics.constraint_violations})"
        elif metrics.strategy_repetition >= 1.0 and self._cycle > 2:
            outcome = "failed"
            failure_reason = "Complete strategy repetition — cognitive stall"
        else:
            outcome = "continued"

        entry = LedgerEntry(
            cycle=self._cycle,
            trace=output.reasoning_trace,
            metrics=metrics,
            mutations_applied=list(self._active_mutations),
            outcome=outcome,
            failure_reason=failure_reason,
        )
        self._ledger.record(entry)

        # Generate next mutations based on what we observed
        self._active_mutations = generate_mutations(metrics, self._cycle)

        return outcome

    def get_mutations(self) -> list[Mutation]:
        """Return the current set of mutations to impose on the next generation."""
        return list(self._active_mutations)

    def reset(self) -> None:
        """Reset cycle counter and mutations (ledger is preserved)."""
        self._cycle = 0
        self._active_mutations = []
