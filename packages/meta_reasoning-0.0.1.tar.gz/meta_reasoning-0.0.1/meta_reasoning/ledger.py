"""
Epistemic Ledger (Level 3) — structural memory.

Not "memory" in the RAG sense. This is:
- a trace of cognitive transformations
- a history of strategies used
- a map of failures

Its purpose: never return to the same mental state.
"""

from __future__ import annotations

import json
from pathlib import Path

from .types import CognitiveMove, LedgerEntry


class EpistemicLedger:
    """Append-only cognitive trajectory store."""

    def __init__(self) -> None:
        self._entries: list[LedgerEntry] = []

    @property
    def entries(self) -> list[LedgerEntry]:
        return list(self._entries)

    @property
    def size(self) -> int:
        return len(self._entries)

    def record(self, entry: LedgerEntry) -> None:
        self._entries.append(entry)

    def failures(self) -> list[LedgerEntry]:
        return [e for e in self._entries if e.outcome == "failed"]

    def strategies_tried(self) -> list[tuple[CognitiveMove, ...]]:
        return [tuple(e.trace.moves) for e in self._entries]

    def summary_for_prompt(self, max_entries: int = 5) -> str:
        """Generate a concise summary for the substrate to avoid repetition."""
        if not self._entries:
            return ""
        recent = self._entries[-max_entries:]
        lines = []
        for e in recent:
            moves_str = ", ".join(m.value for m in e.trace.moves)
            status = e.outcome
            if e.failure_reason:
                status += f" ({e.failure_reason})"
            lines.append(f"  Cycle {e.cycle}: [{moves_str}] → {status}")
        return "\n".join(lines)

    def save(self, path: str | Path) -> None:
        path = Path(path)
        data = [e.model_dump(mode="json") for e in self._entries]
        path.write_text(json.dumps(data, indent=2))

    def load(self, path: str | Path) -> None:
        path = Path(path)
        if not path.exists():
            return
        data = json.loads(path.read_text())
        self._entries = [LedgerEntry.model_validate(d) for d in data]
