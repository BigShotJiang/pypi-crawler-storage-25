#!/usr/bin/env python3
"""
Shim for CoReason CI/CD Self-Healing Assistant.
Imports and runs the module from coreason_infrastructure.
"""
import sys
import os

# Append the package src directory to sys.path in case it is not installed in the python environment
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, "..", "src"))
if src_dir not in sys.path:
    sys.path.insert(0, src_dir)

try:
    from coreason_release_healer.agent_ci_healer import main
except ImportError as e:
    print(f"Error: Could not import coreason_release_healer. Please make sure the package is installed or src/ is accessible. Detail: {e}", file=sys.stderr)
    sys.exit(1)

if __name__ == "__main__":
    main()
