# Changelog

## [0.22.0](https://github.com/CoReason-AI/coreason-release-healer/compare/v0.21.0...v0.22.0) (2026-05-23)


### Features

* **release-healer:** release coreason-urn-authority before coreason-ecosystem ([ff9e855](https://github.com/CoReason-AI/coreason-release-healer/commit/ff9e855856379bf68e4f730d0896c17740837a45))

## [0.21.0](https://github.com/CoReason-AI/coreason-release-healer/compare/v0.20.1...v0.21.0) (2026-05-23)


### Features

* **release:** add coreason-installer to synchronized release, healer, and telemetry ([6f6e409](https://github.com/CoReason-AI/coreason-release-healer/commit/6f6e409c8b70496e8435f1cc251ea737eaaef482))

## [0.20.1](https://github.com/CoReason-AI/coreason-release-healer/compare/v0.20.0...v0.20.1) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.20.1 ([6e4b4b2](https://github.com/CoReason-AI/coreason-release-healer/commit/6e4b4b2f29c30c657ef2cd7e338a8142220e343d))
* **orchestrator:** add fallback to get_tag_run_status without branch filter ([f8c3c1c](https://github.com/CoReason-AI/coreason-release-healer/commit/f8c3c1cdf599bee1035668a68b08b4fc4dd84457))

## [0.19.0](https://github.com/CoReason-AI/coreason-release-healer/compare/v0.18.0...v0.19.0) (2026-05-22)


### Features

* **healer:** add pre-commit self-healing support and release progress telemetry feed ([957a477](https://github.com/CoReason-AI/coreason-release-healer/commit/957a477fa0fa9f313a292ff6347fb54139c2b0b2))

## [0.17.0](https://github.com/CoReason-AI/coreason-release-healer/compare/v0.16.1...v0.17.0) (2026-05-22)


### Features

* **healer:** support monitoring and healing of parallel active branch runs (e.g. main) ([efe7453](https://github.com/CoReason-AI/coreason-release-healer/commit/efe7453319220730c12e44332b9342dc86e4605a))

## [0.16.1](https://github.com/CoReason-AI/coreason-release-healer/compare/v0.16.0...v0.16.1) (2026-05-22)


### Bug Fixes

* **orchestrator:** prioritize release runs and filter CI checks ([b8a39eb](https://github.com/CoReason-AI/coreason-release-healer/commit/b8a39ebf813cb26705f2dc7353c4d2a9a07c45fa))

## [0.15.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.14.0...v0.15.0) (2026-05-22)


### Features

* **ci:** implement automatic uv update mechanism at initialization ([196cdc0](https://github.com/CoReason-AI/coreason-infrastructure/commit/196cdc0bf0162f4e2d4b8513481d81ce1b107ce0))

## [0.14.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.13.0...v0.14.0) (2026-05-22)


### Features

* **ci:** implement hybrid self-healing release monitoring and GHA workflow status polling ([b532685](https://github.com/CoReason-AI/coreason-infrastructure/commit/b5326854b9cbd3923235729ba92fb75a7eb6ebe0))

## [0.13.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.12.0...v0.13.0) (2026-05-22)


### Features

* **release:** run self-healing daemon locally by default and revert GHA background execution ([ade1b40](https://github.com/CoReason-AI/coreason-infrastructure/commit/ade1b40c72ff0da08f3f4ded3557bc6e774cb07c))

## [0.12.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.11.0...v0.12.0) (2026-05-22)


### Features

* **release:** integrate self-healing daemon by default in synchronized release ([3fc941d](https://github.com/CoReason-AI/coreason-infrastructure/commit/3fc941d8558653d5b66f78401883a7273d4318cc))

## [0.11.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.10.0...v0.11.0) (2026-05-22)


### Features

* **healer:** implement precise AST-guided python code rewriting for ruff and bandit lints ([e7e32e7](https://github.com/CoReason-AI/coreason-infrastructure/commit/e7e32e7d193a368befc977fa5d8f04e9e06c6610))

## [0.10.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.9.2...v0.10.0) (2026-05-22)


### Features

* implement Ruff/Bandit self-healing code parsing and line patching ([020dd78](https://github.com/CoReason-AI/coreason-infrastructure/commit/020dd78af528238524487c770643afea4b403cf0))

## [0.9.2](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.9.1...v0.9.2) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.9.2 ([f346d8b](https://github.com/CoReason-AI/coreason-infrastructure/commit/f346d8b566dbd0720dcee663a39725bca6806274))

## [0.9.1](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.9.0...v0.9.1) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.9.1 ([fdf6bdc](https://github.com/CoReason-AI/coreason-infrastructure/commit/fdf6bdccd16b9cf32cdf11fc4c89238534b634f7))

## [0.9.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.8.1...v0.9.0) (2026-05-22)


### Features

* **ci:** implement orchestrator resumption, self-healing, advanced logging, and custom release report support ([ddd794e](https://github.com/CoReason-AI/coreason-infrastructure/commit/ddd794ed0fb1a16417efa5c90eca08d0ad948dcb))

## [0.8.1](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.8.0...v0.8.1) (2026-05-22)


### Bug Fixes

* **deps:** bump dependencies for synchronized release v0.8.1 ([38130c1](https://github.com/CoReason-AI/coreason-infrastructure/commit/38130c1e7237341c7e2d628d6fcf4395a87d6cc5))

## [0.8.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.7.5...v0.8.0) (2026-05-22)


### Features

* add automated synchronized release orchestrator and workflow ([70b13f5](https://github.com/CoReason-AI/coreason-infrastructure/commit/70b13f54c25ba7d68096409deed90ed6fe1f4257))

## [0.7.4](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.7.3...v0.7.4) (2026-05-22)


### Bug Fixes

* **gitops:** synchronize release to include latest app promotions ([5a7e341](https://github.com/CoReason-AI/coreason-infrastructure/commit/5a7e341792d284cdbbfe748ae4b03d8a18c3246f))

## [0.7.3](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.7.2...v0.7.3) (2026-05-22)


### Bug Fixes

* **ci:** handle policy-blocked release-please merge gracefully ([6b6be48](https://github.com/CoReason-AI/coreason-infrastructure/commit/6b6be482efbada31202f1b8d6feb12e79118c544))

## [0.7.2](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.7.1...v0.7.2) (2026-05-22)


### Bug Fixes

* **ci:** remove GHCR_PAT fallback from release-please token ([a70c166](https://github.com/CoReason-AI/coreason-infrastructure/commit/a70c166302b031f5e20b16af620395903eac5940))

## [0.7.1](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.7.0...v0.7.1) (2026-05-22)


### Bug Fixes

* **github:** add explicit repo targeting and merge fallbacks to release workflow ([a9ab57c](https://github.com/CoReason-AI/coreason-infrastructure/commit/a9ab57cb6a7423dd7a769a28c6c26cf52bcc43ae))
* **github:** parse release-please pr output JSON for automerge ([f54d98e](https://github.com/CoReason-AI/coreason-infrastructure/commit/f54d98ecaf830558cc83b2ca2ea79f01879a36a4))

## [0.7.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.6.0...v0.7.0) (2026-05-22)


### Features

* **bootstrap:** ephemeral certificate generation for local dev ([#4](https://github.com/CoReason-AI/coreason-infrastructure/issues/4)) ([d3701f2](https://github.com/CoReason-AI/coreason-infrastructure/commit/d3701f28227717620d968859f4edb578ebccc6d2))

## [0.6.0](https://github.com/CoReason-AI/coreason-infrastructure/compare/v0.5.0...v0.6.0) (2026-05-22)


### Features

* **infra:** HPA templates and external database config ([#5](https://github.com/CoReason-AI/coreason-infrastructure/issues/5)) ([47d08ec](https://github.com/CoReason-AI/coreason-infrastructure/commit/47d08ec334d4aad9a79e2a8ba47edb8223e6033f))
