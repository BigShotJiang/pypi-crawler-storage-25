#!/usr/bin/env python3
# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-release-healer>

"""
Ephemeral Certificate Generator for Local Development (#4).

Generates self-signed ECDSA P-256 certificates and keys for local mTLS
development when a full SPIRE server is not available.

Usage:
    python mesh_injector.py [--output-dir /tmp/certs] [--days 7] [--cn coreason-local]
"""

from __future__ import annotations

import argparse
import datetime
import sys
from pathlib import Path


def generate_ephemeral_certs(
    output_dir: str | Path = "/tmp/coreason-certs",  # noqa: S108
    common_name: str = "coreason-local",
    validity_days: int = 7,
    san_dns: list[str] | None = None,
) -> dict[str, Path]:
    """Generate ephemeral self-signed ECDSA P-256 certificates.

    Returns a dict with paths to the generated files:
    - ca_cert: CA certificate PEM
    - ca_key: CA private key PEM
    - server_cert: Server certificate PEM
    - server_key: Server private key PEM
    - client_cert: Client certificate PEM
    - client_key: Client private key PEM
    """
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    san_dns = san_dns or ["localhost", "*.coreason.local"]
    now = datetime.datetime.now(datetime.timezone.utc)
    expiry = now + datetime.timedelta(days=validity_days)

    # 1. Generate CA
    ca_key = ec.generate_private_key(ec.SECP256R1())
    ca_subject = x509.Name([
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "CoReason-AI"),
        x509.NameAttribute(NameOID.COMMON_NAME, f"{common_name}-ca"),
    ])
    ca_cert = (
        x509.CertificateBuilder()
        .subject_name(ca_subject)
        .issuer_name(ca_subject)
        .public_key(ca_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(expiry)
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .add_extension(
            x509.KeyUsage(
                digital_signature=True, key_cert_sign=True, crl_sign=True,
                content_commitment=False, key_encipherment=False,
                data_encipherment=False, key_agreement=False,
                encipher_only=False, decipher_only=False,
            ),
            critical=True,
        )
        .sign(ca_key, hashes.SHA256())
    )

    def _gen_leaf(name_suffix: str) -> tuple[ec.EllipticCurvePrivateKey, x509.Certificate]:
        """Generate a leaf certificate signed by the CA."""
        leaf_key = ec.generate_private_key(ec.SECP256R1())
        leaf_subject = x509.Name([
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "CoReason-AI"),
            x509.NameAttribute(NameOID.COMMON_NAME, f"{common_name}-{name_suffix}"),
        ])
        builder = (
            x509.CertificateBuilder()
            .subject_name(leaf_subject)
            .issuer_name(ca_subject)
            .public_key(leaf_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(expiry)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        )
        # Add SANs for server certs
        if name_suffix == "server":
            san_entries: list[x509.GeneralName] = [
                x509.DNSName(dns) for dns in san_dns
            ]
            san_entries.append(x509.IPAddress(
                __import__("ipaddress").IPv4Address("127.0.0.1")
            ))
            builder = builder.add_extension(
                x509.SubjectAlternativeName(san_entries),
                critical=False,
            )
        return leaf_key, builder.sign(ca_key, hashes.SHA256())

    server_key, server_cert = _gen_leaf("server")
    client_key, client_cert = _gen_leaf("client")

    # Write files
    def _write_pem(path: Path, data: bytes) -> Path:
        path.write_bytes(data)
        return path

    results: dict[str, Path] = {}
    results["ca_cert"] = _write_pem(
        out / "ca.crt",
        ca_cert.public_bytes(serialization.Encoding.PEM),
    )
    results["ca_key"] = _write_pem(
        out / "ca.key",
        ca_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        ),
    )
    results["server_cert"] = _write_pem(
        out / "server.crt",
        server_cert.public_bytes(serialization.Encoding.PEM),
    )
    results["server_key"] = _write_pem(
        out / "server.key",
        server_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        ),
    )
    results["client_cert"] = _write_pem(
        out / "client.crt",
        client_cert.public_bytes(serialization.Encoding.PEM),
    )
    results["client_key"] = _write_pem(
        out / "client.key",
        client_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.PKCS8,
            serialization.NoEncryption(),
        ),
    )

    return results


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Generate ephemeral mTLS certificates for local development"
    )
    parser.add_argument(
        "--output-dir", default="/tmp/coreason-certs",
        help="Directory to write certificates (default: /tmp/coreason-certs)",
    )
    parser.add_argument(
        "--days", type=int, default=7,
        help="Certificate validity in days (default: 7)",
    )
    parser.add_argument(
        "--cn", default="coreason-local",
        help="Common name prefix (default: coreason-local)",
    )
    args = parser.parse_args()

    results = generate_ephemeral_certs(
        output_dir=args.output_dir,
        common_name=args.cn,
        validity_days=args.days,
    )

    print(f"✓ Generated ephemeral certificates in {args.output_dir}:")
    for name, path in results.items():
        print(f"  {name}: {path}")
    print(f"\nCertificates expire in {args.days} days.")


if __name__ == "__main__":
    main()
