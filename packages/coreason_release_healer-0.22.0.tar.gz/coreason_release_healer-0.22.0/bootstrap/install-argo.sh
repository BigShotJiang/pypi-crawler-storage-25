#!/usr/bin/env bash

# Exit immediately if a command exits with a non-zero status
set -eo pipefail

echo "===================================================="
echo "☸️ Bootstrapping Argo CD on CoReason K3s Cluster..."
echo "===================================================="

# Check if kubectl is available and connected
if ! command -v kubectl &> /dev/null; then
    echo "❌ Error: kubectl is not installed or not in PATH."
    exit 1
fi

if ! kubectl cluster-info &> /dev/null; then
    echo "❌ Error: Cannot connect to Kubernetes cluster. Verify KUBECONFIG is set."
    exit 1
fi

echo "✅ Connected to cluster successfully."

# Create namespace if it doesn't exist
echo "Creating namespace 'argocd'..."
kubectl create namespace argocd --dry-run=client -o yaml | kubectl apply -f -

# Apply stable Argo CD manifests
echo "Applying official Argo CD manifests..."
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for Argo CD server components to become healthy
echo "Waiting for Argo CD deployments to stabilize..."
kubectl rollout status deployment/argocd-server -n argocd --timeout=300s
kubectl rollout status deployment/argocd-repo-server -n argocd --timeout=300s

echo "===================================================="
echo "🎉 Argo CD bootstrap complete!"
echo "👉 Access the UI via Port-Forwarding:"
echo "   kubectl port-forward svc/argocd-server -n argocd 8080:443"
echo "👉 Retrieve the default admin password:"
echo "   kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath=\"{.data.password}\" | base64 -d"
echo "===================================================="
