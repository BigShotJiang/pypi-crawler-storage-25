#!/usr/bin/env python3
import os
import sys
import json
import time
import subprocess
import concurrent.futures
from datetime import datetime
import re
import argparse
import http.server
import socketserver
import threading
import webbrowser

# Clear dummy/invalid GITHUB_TOKEN to let gh CLI fall back to keyring
if "GITHUB_TOKEN" in os.environ and os.environ["GITHUB_TOKEN"].startswith("github_pat_antigravitydummy"):
    del os.environ["GITHUB_TOKEN"]

# ANSI colors
COLOR_GREEN = "\033[92m"
COLOR_YELLOW = "\033[93m"
COLOR_RED = "\033[91m"
COLOR_CYAN = "\033[96m"
COLOR_MAGENTA = "\033[95m"
COLOR_GRAY = "\033[90m"
COLOR_BOLD = "\033[1m"
COLOR_RESET = "\033[0m"

TIERS = [
    ["coreason-manifest", "coreason-sensory-core"],
    ["coreason-urn-authority", "coreason-isv-admin", "coreason-sensory-app", "coreason-sensory-embed"],
    ["coreason-runtime", "coreason-ecosystem"],
    ["coreason-meta-engineering", "coreason-documentation"],
    ["coreason-release-healer"],
    ["coreason-installer"]
]

ALL_REPOS = [repo for tier in TIERS for repo in tier]

# In-memory status cache for the HTTP server to avoid GitHub API rate limiting
status_cache = {}
last_cache_update = 0
cache_lock = threading.Lock()
CACHE_TTL = 10  # seconds

def run_cmd(cmd, cwd=None):
    try:
        res = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", check=True)
        return res.stdout.strip()
    except Exception as e:
        return f"ERROR: {e}"

def get_repo_status(repo):
    cmd = [
        "gh", "run", "list",
        "--repo", f"CoReason-AI/{repo}",
        "--limit", "5",
        "--json", "databaseId,status,conclusion,name,headBranch,createdAt"
    ]
    out = run_cmd(cmd)
    if "ERROR" in out or not out:
        return repo, {"status": "Unknown", "conclusion": "N/A", "run_id": None, "branch": "N/A", "name": "N/A"}
    try:
        runs = json.loads(out)
        if not runs:
            return repo, {"status": "No Runs", "conclusion": "N/A", "run_id": None, "branch": "N/A", "name": "N/A"}
        
        # Prioritize release/publish run
        selected_run = runs[0]
        for run in runs:
            r_name = (run.get("name") or "").lower()
            if any(kw in r_name for kw in ["release", "publish", "container"]):
                selected_run = run
                break
        
        return repo, {
            "status": selected_run.get("status", "Unknown"),
            "conclusion": selected_run.get("conclusion") or "pending",
            "run_id": selected_run.get("databaseId"),
            "branch": selected_run.get("headBranch", "N/A"),
            "name": selected_run.get("name", "N/A")
        }
    except Exception:
        return repo, {"status": "Error Parsing", "conclusion": "N/A", "run_id": None, "branch": "N/A", "name": "N/A"}

def load_release_state(workspace_dir):
    state_path = os.path.join(workspace_dir, ".coreason", "release_state.json")
    if os.path.exists(state_path):
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None

def get_workspace_dir():
    cwd = os.getcwd()
    if os.path.exists(os.path.join(cwd, "coreason-release-healer")):
        return cwd
    return os.path.dirname(cwd) if os.path.exists(os.path.join(os.path.dirname(cwd), "coreason-release-healer")) else cwd

def parse_healing_events(workspace_dir):
    events = {}
    log_path = os.path.join(workspace_dir, ".coreason", "healer_detailed.log")
    if not os.path.exists(log_path):
        return events
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        
        # Scan last 1500 lines for healer actions
        lines = lines[-1500:]
        for line in lines:
            # Diagnose matching: "Diagnosing failure in coreason-isv-admin (Run 26310201873)..."
            m_diag = re.search(r'Diagnosing failure in ([\w-]+)', line)
            if m_diag:
                repo = m_diag.group(1)
                if repo not in events:
                    events[repo] = []
                timestamp = line[:19]
                msg = line.split(" - ")[-1].strip()
                # Check for duplicates
                if not any(e["message"] == msg for e in events[repo]):
                    events[repo].append({
                        "time": timestamp,
                        "type": "diagnosis",
                        "message": msg
                    })
            
            # Healing/Fix matching
            m_fix = re.search(r'(Successfully re-tagged [\w.]+ in ([\w-]+)|Injected .* in ([\w-]+)|Successfully healed ([\w-]+)|auto-fixed files in ([\w-]+)|Auto-fixing .* in ([\w-]+))', line, re.IGNORECASE)
            if m_fix:
                matched_text = m_fix.group(1)
                repo = None
                for grp in m_fix.groups()[1:]:
                    if grp and grp in ALL_REPOS:
                        repo = grp
                        break
                if not repo:
                    for r in ALL_REPOS:
                        if r in matched_text:
                            repo = r
                            break
                if repo:
                    if repo not in events:
                        events[repo] = []
                    timestamp = line[:19]
                    msg = line.split(" - ")[-1].strip()
                    if not any(e["message"] == msg for e in events[repo]):
                        events[repo].append({
                            "time": timestamp,
                            "type": "fix",
                            "message": msg
                        })
    except Exception:
        pass
    return events

def get_recent_logs(workspace_dir):
    log_path = os.path.join(workspace_dir, ".coreason", "healer_detailed.log")
    if not os.path.exists(log_path):
        return ["No logs found at " + log_path]
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        return [line.strip() for line in lines[-150:]]
    except Exception as e:
        return [f"Error reading logs: {e}"]

def get_cached_telemetry_data(workspace_dir):
    global last_cache_update, status_cache
    with cache_lock:
        now = time.time()
        if now - last_cache_update > CACHE_TTL or not status_cache:
            # 1. Load release state
            state = load_release_state(workspace_dir)
            
            # 2. Get repository statuses
            repo_statuses = {}
            with concurrent.futures.ThreadPoolExecutor(max_workers=len(ALL_REPOS)) as executor:
                futures = {executor.submit(get_repo_status, repo): repo for repo in ALL_REPOS}
                for future in concurrent.futures.as_completed(futures):
                    repo, status = future.result()
                    repo_statuses[repo] = status
                    
            # 3. Parse healer logs
            healing_events = parse_healing_events(workspace_dir)
            
            # 4. Check for local running healer PID
            healer_pid = None
            try:
                if sys.platform == "win32":
                    cmd = ["powershell", "-Command", "Get-CimInstance Win32_Process -Filter \"name = 'python.exe'\" | Where-Object {$_.CommandLine -like '*agent_ci_healer*'} | Select-Object -ExpandProperty ProcessId"]
                    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    if res.returncode == 0 and res.stdout.strip():
                        healer_pid = int(res.stdout.strip().splitlines()[0])
                else:
                    res = subprocess.run(["pgrep", "-f", "agent_ci_healer"], stdout=subprocess.PIPE, text=True)
                    if res.returncode == 0 and res.stdout.strip():
                        healer_pid = int(res.stdout.strip().splitlines()[0])
            except Exception:
                pass
                
            status_cache = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "state": state,
                "repo_statuses": repo_statuses,
                "healing_events": healing_events,
                "healer_pid": healer_pid
            }
            last_cache_update = now
        return status_cache

class TelemetryHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Suppress logging in console to avoid cluttering output
        pass

    def do_GET(self):
        workspace_dir = get_workspace_dir()
        if self.path == "/api/status":
            try:
                data = get_cached_telemetry_data(workspace_dir)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps(data).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))
        elif self.path == "/api/logs":
            try:
                logs = get_recent_logs(workspace_dir)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps({"logs": logs}).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))
        elif self.path == "/" or self.path == "/index.html":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(HTML_TEMPLATE.encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")

def start_web_server(port):
    server_address = ("", port)
    # Allow port reuse to avoid binding issues on quick restarts
    socketserver.TCPServer.allow_reuse_address = True
    try:
        with socketserver.TCPServer(server_address, TelemetryHandler) as httpd:
            print(f"{COLOR_GREEN}{COLOR_BOLD}[SERVER] Running Web Dashboard at http://localhost:{port}/{COLOR_RESET}")
            webbrowser.open(f"http://localhost:{port}/")
            httpd.serve_forever()
    except Exception as e:
        print(f"{COLOR_RED}[ERROR] Web server failed to start: {e}{COLOR_RESET}")
        sys.exit(1)

def print_console_telemetry(workspace_dir):
    # Fallback to keyless keyring auth
    if "GITHUB_TOKEN" in os.environ:
        del os.environ["GITHUB_TOKEN"]

    state = load_release_state(workspace_dir)
    current_level = 0
    completed_repos_state = []
    versions = {}
    if state:
        current_level = state.get("current_level", 0)
        completed_repos_state = state.get("completed_repos", [])
        versions = state.get("new_versions", {})
        
    print(f"{COLOR_CYAN}{COLOR_BOLD}=== COREASON SYNCHRONIZED RELEASE TELEMETRY FEED ==={COLOR_RESET}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    print(f"{COLOR_BOLD}Fetching GitHub Actions statuses in parallel...{COLOR_RESET}")
    start_time = time.time()
    
    repo_statuses = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(ALL_REPOS)) as executor:
        futures = {executor.submit(get_repo_status, repo): repo for repo in ALL_REPOS}
        for future in concurrent.futures.as_completed(futures):
            repo, status = future.result()
            repo_statuses[repo] = status
            
    total_repos = len(ALL_REPOS)
    completed_count = 0
    
    print(f"\n{COLOR_CYAN}{COLOR_BOLD}RELEASE PROGRESS DASHBOARD{COLOR_RESET}")
    print("=" * 95)
    
    for idx, tier in enumerate(TIERS):
        level = idx + 1
        is_current_level = (idx == current_level)
        is_past_level = (idx < current_level)
        
        level_status_str = ""
        if is_current_level:
            level_status_str = f"{COLOR_YELLOW}{COLOR_BOLD}[IN PROGRESS]{COLOR_RESET}"
        elif is_past_level:
            level_status_str = f"{COLOR_GREEN}{COLOR_BOLD}[COMPLETED]{COLOR_RESET}"
        else:
            level_status_str = f"{COLOR_GRAY}[PENDING]{COLOR_RESET}"
            
        print(f"\n{COLOR_BOLD}Level {level}:{COLOR_RESET} {level_status_str}")
        
        for repo in tier:
            gh_info = repo_statuses.get(repo, {})
            version_str = f"v{versions.get(repo)}" if repo in versions else "vX.Y.Z"
            
            # Determine GHA statuses
            gh_status = gh_info.get("status", "Unknown")
            gh_conclusion = gh_info.get("conclusion", "N/A")
            
            # A repo is considered done if it's in a past completed level, or if its GHA run succeeded in the current level
            is_done = False
            if is_past_level:
                is_done = True
                gh_status = "COMPLETED"
                gh_conclusion = "SUCCESS"
            elif is_current_level:
                if gh_status.lower() == "completed" and gh_conclusion.lower() == "success":
                    is_done = True
            
            if is_done:
                completed_count += 1
                status_color = COLOR_GREEN
                status_symbol = "[OK] "
            elif is_current_level:
                # Active tier, display real-time GHA status
                if gh_status.lower() in ["in_progress", "queued", "waiting"]:
                    status_color = COLOR_YELLOW
                    status_symbol = "[>>] "
                elif gh_conclusion.lower() in ["failure", "failed"]:
                    status_color = COLOR_RED
                    status_symbol = "[ERR]"
                else:
                    status_color = COLOR_GRAY
                    status_symbol = "[-] "
                    gh_status = "PENDING"
                    gh_conclusion = "PENDING"
            else:
                # Future tier, force pending
                status_color = COLOR_GRAY
                status_symbol = "[-] "
                gh_status = "PENDING"
                gh_conclusion = "PENDING"
                
            repo_disp = f"{repo} ({version_str})"
            run_details = ""
            if (is_past_level or is_current_level) and gh_info.get("run_id"):
                if is_current_level and gh_status == "PENDING":
                    pass
                else:
                    run_details = f" [Run: {gh_info['run_id']} - {gh_info['name'][:30]}]"
                
            print(f"  {status_color}{status_symbol} {repo_disp:<45} {gh_status.upper():<15} {gh_conclusion.upper():<10}{run_details}{COLOR_RESET}")
            
    print("\n" + "=" * 95)
    
    pct = (completed_count / total_repos) * 100
    bar_width = 30
    filled = int(bar_width * completed_count // total_repos)
    bar = "#" * filled + "-" * (bar_width - filled)
    
    print(f"{COLOR_BOLD}Overall Coordinated Progress:{COLOR_RESET} |{COLOR_CYAN}{bar}{COLOR_RESET}| {pct:.1f}% ({completed_count}/{total_repos} packages complete)")
    print(f"Diagnostic fetch duration: {time.time() - start_time:.2f} seconds\n")

def main():
    parser = argparse.ArgumentParser(description="CoReason Release Telemetry Dashboard")
    parser.add_argument("--web", action="store_true", help="Start the beautiful web-based telemetry dashboard server")
    parser.add_argument("--port", type=int, default=8080, help="Port to run the web server on (default: 8080)")
    parser.add_argument("--watch", action="store_true", help="Continuously poll and clear screen in console mode")
    parser.add_argument("--interval", type=int, default=15, help="Interval in seconds for watch/polling loop")
    
    args = parser.parse_args()
    workspace_dir = get_workspace_dir()
    
    if args.web:
        start_web_server(args.port)
    elif args.watch:
        try:
            while True:
                os.system("cls" if os.name == "nt" else "clear")
                print_console_telemetry(workspace_dir)
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\nWatch loop terminated.")
    else:
        print_console_telemetry(workspace_dir)

# Beautiful self-contained HTML/CSS/JS Telemetry Dashboard (Vanilla CSS)
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CoReason Coordinated Release Telemetry</title>
    <style>
        :root {
            --bg-color: #09090b;
            --card-bg: rgba(24, 24, 27, 0.7);
            --card-bg-solid: #18181b;
            --border-color: rgba(63, 63, 70, 0.4);
            --border-color-focus: rgba(99, 102, 241, 0.5);
            --text-primary: #fafafa;
            --text-secondary: #a1a1aa;
            --text-muted: #71717a;
            
            --success: #10b981;
            --success-glow: rgba(16, 185, 129, 0.15);
            --warning: #f59e0b;
            --warning-glow: rgba(245, 158, 11, 0.15);
            --danger: #ef4444;
            --danger-glow: rgba(239, 68, 68, 0.15);
            --info: #06b6d4;
            --info-glow: rgba(6, 182, 212, 0.15);
            --pending: #3f3f46;
            
            --indigo: #6366f1;
            --indigo-glow: rgba(99, 102, 241, 0.2);
            
            --font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            --font-mono: "Fira Code", Consolas, "Courier New", monospace;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            background-color: var(--bg-color);
            background-image: radial-gradient(circle at top right, rgba(99, 102, 241, 0.07), transparent 600px),
                              radial-gradient(circle at bottom left, rgba(6, 182, 212, 0.04), transparent 500px);
            color: var(--text-primary);
            font-family: var(--font-sans);
            min-height: 100vh;
            line-height: 1.5;
            padding: 2rem;
            overflow-y: scroll;
        }
        
        a {
            color: var(--indigo);
            text-decoration: none;
            transition: color 0.2s;
        }
        a:hover {
            color: #818cf8;
            text-decoration: underline;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }
        
        @media(min-width: 1024px) {
            .container {
                grid-template-columns: 1.7fr 1.3fr;
            }
            .header-banner {
                grid-column: span 2;
            }
            .pipeline-tiers {
                grid-column: span 2;
            }
        }
        
        .card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 1.5rem;
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.35);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .card:hover {
            border-color: var(--border-color-focus);
            box-shadow: 0 10px 40px var(--indigo-glow);
        }
        
        .header-banner {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 1.5rem;
            background: linear-gradient(135deg, rgba(24, 24, 27, 0.9), rgba(9, 9, 11, 0.95));
            border-bottom: 2px solid var(--indigo);
        }
        
        .header-title h1 {
            font-size: 1.8rem;
            font-weight: 800;
            letter-spacing: -0.025em;
            background: linear-gradient(to right, #ffffff, #a1a1aa, var(--indigo));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.25rem;
        }
        .header-title p {
            color: var(--text-secondary);
            font-size: 0.95rem;
        }
        
        .header-metrics {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .metric-box {
            background: rgba(0, 0, 0, 0.25);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            padding: 0.6rem 1.2rem;
            text-align: center;
            min-width: 110px;
        }
        .metric-value {
            font-family: var(--font-mono);
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--indigo);
        }
        .metric-label {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-secondary);
            margin-top: 0.2rem;
        }
        
        .top-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            margin-top: 0.5rem;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            padding-top: 1rem;
            flex-wrap: wrap;
            gap: 1rem;
        }
        
        .mode-selector {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(0, 0, 0, 0.2);
            padding: 0.35rem 0.75rem;
            border-radius: 6px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            font-size: 0.8rem;
        }
        
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 32px;
            height: 18px;
        }
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .slider {
            position: absolute;
            cursor: pointer;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: #3f3f46;
            transition: .3s;
            border-radius: 18px;
        }
        .slider:before {
            position: absolute;
            content: "";
            height: 12px; width: 12px;
            left: 3px; bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
        }
        input:checked + .slider {
            background-color: var(--indigo);
        }
        input:checked + .slider:before {
            transform: translateX(14px);
        }
        
        /* Topological Tiers Pipeline */
        .pipeline-tiers {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
            gap: 1rem;
            background: rgba(24, 24, 27, 0.35);
            padding: 1.25rem;
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.02);
        }
        
        .tier-node {
            background: var(--card-bg-solid);
            border: 1px solid var(--border-color);
            border-radius: 8px;
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            transition: all 0.3s;
        }
        .tier-node.completed {
            border-color: var(--success);
            box-shadow: 0 0 10px var(--success-glow);
        }
        .tier-node.active {
            border-color: var(--warning);
            box-shadow: 0 0 10px var(--warning-glow);
        }
        
        .tier-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .tier-title {
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .tier-badge {
            font-size: 0.65rem;
            font-weight: 700;
            padding: 0.1rem 0.35rem;
            border-radius: 4px;
            text-transform: uppercase;
        }
        .tier-badge.pending { background: #27272a; color: var(--text-secondary); }
        .tier-badge.active { background: rgba(245, 158, 11, 0.2); color: var(--warning); }
        .tier-badge.completed { background: rgba(16, 185, 129, 0.2); color: var(--success); }
        
        .tier-repos {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }
        .repo-pill {
            font-size: 0.75rem;
            background: rgba(255, 255, 255, 0.03);
            padding: 0.15rem 0.4rem;
            border-radius: 4px;
            border: 1px solid rgba(255, 255, 255, 0.01);
            color: var(--text-secondary);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .tier-node.completed .repo-pill {
            background: rgba(16, 185, 129, 0.05);
            border-color: rgba(16, 185, 129, 0.1);
            color: #a7f3d0;
        }
        .tier-node.active .repo-pill.active-pill {
            background: rgba(245, 158, 11, 0.07);
            border-color: rgba(245, 158, 11, 0.2);
            color: #fde68a;
            font-weight: 600;
        }
        
        /* Repository Cards */
        .repos-column {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        .repo-card {
            border-left: 4px solid var(--pending);
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            padding: 1.25rem;
        }
        .repo-card.completed { border-left-color: var(--success); }
        .repo-card.in_progress { border-left-color: var(--warning); }
        .repo-card.queued { border-left-color: var(--indigo); }
        .repo-card.failed { border-left-color: var(--danger); }
        .repo-card.healing { border-left-color: var(--info); }
        
        .repo-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .repo-title-block {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            flex-wrap: wrap;
        }
        .repo-card-name {
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-primary);
        }
        .repo-card-ver {
            font-family: var(--font-mono);
            font-size: 0.75rem;
            background: rgba(255, 255, 255, 0.06);
            padding: 0.1rem 0.35rem;
            border-radius: 4px;
            color: var(--text-secondary);
        }
        .repo-card-level {
            font-size: 0.65rem;
            font-weight: 600;
            padding: 0.1rem 0.3rem;
            border-radius: 3px;
            background: rgba(99, 102, 241, 0.12);
            color: #c7d2fe;
            border: 1px solid rgba(99, 102, 241, 0.15);
        }
        
        .status-badge {
            display: flex;
            align-items: center;
            gap: 0.3rem;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            padding: 0.25rem 0.6rem;
            border-radius: 6px;
        }
        .status-badge.success { background: rgba(16, 185, 129, 0.1); color: var(--success); border: 1px solid rgba(16, 185, 129, 0.2); }
        .status-badge.in-progress { background: rgba(245, 158, 11, 0.1); color: var(--warning); border: 1px solid rgba(245, 158, 11, 0.2); }
        .status-badge.queued { background: rgba(99, 102, 241, 0.1); color: var(--indigo); border: 1px solid rgba(99, 102, 241, 0.2); }
        .status-badge.failed { background: rgba(239, 68, 68, 0.1); color: var(--danger); border: 1px solid rgba(239, 68, 68, 0.2); }
        .status-badge.healing { background: rgba(6, 182, 212, 0.1); color: var(--info); border: 1px solid rgba(6, 182, 212, 0.2); animation: pulse 2s infinite ease-in-out; }
        .status-badge.pending { background: rgba(82, 82, 91, 0.1); color: var(--text-secondary); border: 1px solid rgba(82, 82, 91, 0.2); }
        
        .repo-card-body {
            font-size: 0.85rem;
            color: var(--text-secondary);
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
        }
        .repo-run-line {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        /* Log Terminal Card */
        .terminal-card {
            display: flex;
            flex-direction: column;
            height: 650px;
        }
        .terminal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.75rem;
        }
        .terminal-title {
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--indigo);
        }
        .terminal-controls {
            display: flex;
            gap: 0.5rem;
        }
        
        .terminal-body {
            flex-grow: 1;
            background: #050506;
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            padding: 1rem;
            overflow-y: auto;
            font-family: var(--font-mono);
            font-size: 0.75rem;
            line-height: 1.4;
            color: #e4e4e7;
            box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.95);
        }
        
        .log-line {
            display: block;
            margin-bottom: 0.2rem;
            white-space: pre-wrap;
        }
        .log-success { color: var(--success); }
        .log-warning { color: var(--warning); }
        .log-error { color: var(--danger); }
        .log-info { color: var(--info); }
        .log-debug { color: var(--text-secondary); }
        .log-muted { color: var(--text-muted); }
        
        .healing-box {
            background: rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(255, 255, 255, 0.03);
            border-radius: 6px;
            padding: 0.6rem;
            margin-top: 0.25rem;
            display: flex;
            flex-direction: column;
            gap: 0.3rem;
        }
        .healing-title {
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--success);
            display: flex;
            align-items: center;
            gap: 0.25rem;
        }
        .healing-step {
            display: flex;
            justify-content: space-between;
            font-size: 0.75rem;
            gap: 0.5rem;
        }
        .healing-step-time { color: var(--text-muted); font-family: var(--font-mono); }
        .healing-step-msg { color: #e2e8f0; flex-grow: 1; }
        
        .btn {
            background: #27272a;
            color: var(--text-primary);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 6px;
            padding: 0.3rem 0.6rem;
            font-size: 0.75rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn:hover {
            background: #3f3f46;
            border-color: rgba(255, 255, 255, 0.10);
        }
        
        .pulse-icon {
            width: 8px;
            height: 8px;
            background-color: currentColor;
            border-radius: 50%;
            display: inline-block;
            animation: pulse-glow 1.5s infinite ease-in-out;
        }
        
        .pulse-icon-static {
            width: 8px;
            height: 8px;
            background-color: currentColor;
            border-radius: 50%;
            display: inline-block;
        }

        .healing-box.resolved .healing-title {
            color: var(--text-muted);
        }
        
        .progress-bar-container {
            width: 100%;
            height: 6px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 9999px;
            overflow: hidden;
            margin-top: 0.4rem;
        }
        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--indigo), var(--info));
            border-radius: 9999px;
            transition: width 0.4s ease-out;
            width: 0%;
        }
        
        @keyframes pulse-glow {
            0%, 100% { transform: scale(1); opacity: 1; box-shadow: 0 0 0 0 currentColor; }
            50% { transform: scale(1.15); opacity: 0.5; box-shadow: 0 0 8px 2px currentColor; }
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
    </style>
</head>
<body>

    <div class="container">
        
        <!-- Header Visual -->
        <div class="card header-banner">
            <div class="header-title">
                <h1>CoReason Release Telemetry</h1>
                <p>Topological orchestrator monitoring & CI/CD self-healing events</p>
            </div>
            
            <div class="header-metrics">
                <div class="metric-box">
                    <div id="m-bump" class="metric-value">PATCH</div>
                    <div class="metric-label">Bump Type</div>
                </div>
                <div class="metric-box">
                    <div id="m-level" class="metric-value">-</div>
                    <div class="metric-label">Active Tier</div>
                </div>
                <div class="metric-box">
                    <div id="m-progress" class="metric-value">0%</div>
                    <div class="metric-label">Progress</div>
                </div>
                <div class="metric-box">
                    <div id="m-healer" class="metric-value">OFFLINE</div>
                    <div class="metric-label">Healer PID</div>
                </div>
            </div>
            
            <div class="top-controls">
                <div style="font-size: 0.85rem; color: var(--text-secondary); display: flex; align-items: center; gap: 0.5rem;">
                    <div class="pulse-icon" style="color: var(--success)"></div>
                    <span id="update-time">Last update: --:--:--</span>
                </div>
                
                <div style="display: flex; gap: 0.75rem;">
                    <div class="mode-selector">
                        <span>Simulation Mode</span>
                        <label class="toggle-switch">
                            <input type="checkbox" id="sim-toggle" onchange="toggleSimulation()">
                            <span class="slider"></span>
                        </label>
                    </div>
                    <button class="btn" onclick="triggerManualRefresh()">Force Refresh</button>
                    <button class="btn" id="sim-reset-btn" style="display:none;" onclick="resetSimulation()">Restart Sim</button>
                </div>
            </div>
        </div>
        
        <!-- Topological Pipeline -->
        <div class="card pipeline-tiers" id="pipeline-nodes">
            <!-- Rendered via Javascript -->
        </div>
        
        <!-- Left Side: Repositories Detailed -->
        <div class="repos-column">
            <div style="font-weight: 700; font-size: 1.1rem; letter-spacing: 0.02em; text-transform: uppercase; color: var(--text-secondary); margin-bottom: -0.5rem; display: flex; align-items: center; gap: 0.5rem;">
                <span>Release Components</span>
                <span style="font-size: 0.85rem; color: var(--text-muted); font-weight: normal;">(Topological Dependencies Order)</span>
            </div>
            <div class="repos-container" id="repos-list">
                <!-- Rendered via Javascript -->
            </div>
        </div>
        
        <!-- Right Side: Terminal Logs -->
        <div class="card terminal-card">
            <div class="terminal-header">
                <div class="terminal-title">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-terminal"><polyline points="4 17 10 11 4 5"></polyline><line x1="12" y1="19" x2="20" y2="19"></line></svg>
                    <span>Healing Daemon Logs</span>
                </div>
                <div class="terminal-controls">
                    <button class="btn" onclick="clearTerminal()">Clear</button>
                </div>
            </div>
            <div class="terminal-body" id="log-terminal">
                <!-- Rendered via Javascript -->
            </div>
        </div>
        
    </div>

    <script>
        const TIERS = [
            ["coreason-manifest", "coreason-sensory-core"],
            ["coreason-urn-authority", "coreason-isv-admin", "coreason-sensory-app", "coreason-sensory-embed"],
            ["coreason-runtime", "coreason-ecosystem"],
            ["coreason-meta-engineering", "coreason-documentation"],
            ["coreason-release-healer"],
            ["coreason-installer"]
        ];
        
        const ALL_REPOS = TIERS.flat();
        
        let isSimulated = false;
        let simIndex = 0;
        let updateInterval = 5000;
        let pollerTimer = null;
        
        // Simulated dataset mapping release stages
        const simStates = [
            {
                current_level: 0,
                completed_repos: [],
                repo_statuses: {
                    "coreason-manifest": { status: "queued", conclusion: "pending", run_id: 26315744993, name: "Release", branch: "main" },
                    "coreason-sensory-core": { status: "in_progress", conclusion: "pending", run_id: 26315728884, name: "Release", branch: "main" },
                    "coreason-urn-authority": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-ecosystem": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-isv-admin": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-sensory-app": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-sensory-embed": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-runtime": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-meta-engineering": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-documentation": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-release-healer": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" }
                },
                healing_events: {},
                logs: ["[INFO] Starting Synchronized Release: patch bump", "[INFO] === LEVEL 1 ORCHESTRATION ===", "[INFO] Processing coreason-manifest...", "[INFO] Processing coreason-sensory-core...", "[INFO] Waiting for Level 1 runs..."]
            },
            {
                current_level: 1,
                completed_repos: ["coreason-manifest", "coreason-sensory-core"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "queued", conclusion: "pending", run_id: 26315887120, name: "Release", branch: "main" },
                    "coreason-ecosystem": { status: "in_progress", conclusion: "pending", run_id: 26315888708, name: "Release", branch: "main" },
                    "coreason-isv-admin": { status: "in_progress", conclusion: "pending", run_id: 26315885992, name: "Release", branch: "main" },
                    "coreason-sensory-app": { status: "queued", conclusion: "pending", run_id: 26315891468, name: "Publish Container", branch: "main" },
                    "coreason-sensory-embed": { status: "queued", conclusion: "pending", run_id: 26315889022, name: "Publish Container", branch: "main" },
                    "coreason-runtime": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-meta-engineering": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-documentation": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-release-healer": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" }
                },
                healing_events: {},
                logs: ["[SUCCESS] Level 1 releases successfully completed!", "[INFO] === LEVEL 2 ORCHESTRATION ===", "[INFO] Processing Level 2 components...", "[INFO] Pushed version bumps for Level 2.", "[INFO] Waiting for Level 2 release actions..."]
            },
            {
                current_level: 1,
                completed_repos: ["coreason-urn-authority", "coreason-sensory-embed"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "completed", conclusion: "success", run_id: 26315887120, name: "Release", branch: "v0.37.7" },
                    "coreason-ecosystem": { status: "in_progress", conclusion: "pending", run_id: 26315888708, name: "Release", branch: "v0.60.8" },
                    "coreason-isv-admin": { status: "completed", conclusion: "failure", run_id: 26315885992, name: "Release", branch: "v0.88.6" },
                    "coreason-sensory-app": { status: "in_progress", conclusion: "pending", run_id: 26315891468, name: "Publish Container", branch: "v1.6.12" },
                    "coreason-sensory-embed": { status: "completed", conclusion: "success", run_id: 26315889022, name: "Publish Container", branch: "v1.1.8" },
                    "coreason-runtime": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-meta-engineering": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-documentation": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-release-healer": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" }
                },
                healing_events: {},
                logs: ["[INFO] Level 2: coreason-urn-authority succeeded.", "[INFO] Level 2: coreason-sensory-embed succeeded.", "[ERROR] Level 2: coreason-isv-admin release run 26315885992 failed!", "[ERROR] Failing CI/CD runs detected! Fetching failure logs..."]
            },
            {
                current_level: 1,
                completed_repos: ["coreason-urn-authority", "coreason-sensory-embed"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "completed", conclusion: "success", run_id: 26315887120, name: "Release", branch: "v0.37.7" },
                    "coreason-ecosystem": { status: "in_progress", conclusion: "pending", run_id: 26315888708, name: "Release", branch: "v0.60.8" },
                    "coreason-isv-admin": { status: "healing", conclusion: "pending", run_id: 26315885992, name: "Release", branch: "v0.88.6" },
                    "coreason-sensory-app": { status: "in_progress", conclusion: "pending", run_id: 26315891468, name: "Publish Container", branch: "v1.6.12" },
                    "coreason-sensory-embed": { status: "completed", conclusion: "success", run_id: 26315889022, name: "Publish Container", branch: "v1.1.8" },
                    "coreason-runtime": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-meta-engineering": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-documentation": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-release-healer": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" }
                },
                healing_events: {
                    "coreason-isv-admin": [
                        { time: "2026-05-22 19:10:00", type: "diagnosis", message: "Diagnosing failure in coreason-isv-admin (Run 26315885992)" },
                        { time: "2026-05-22 19:10:05", type: "fix", message: "Ruff formatting check failed. Running auto-fix locally..." }
                    ]
                },
                logs: ["[INFO] Diagnosing failure in coreason-isv-admin (Run 26315885992)...", "[WARNING] Signature matched: Ruff formatting issue (fixable).", "[INFO] Applying ruff check --fix in coreason-isv-admin local clone...", "[SUCCESS] Formatting fixed! Committing changes..."]
            },
            {
                current_level: 1,
                completed_repos: ["coreason-urn-authority", "coreason-sensory-embed"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "completed", conclusion: "success", run_id: 26315887120, name: "Release", branch: "v0.37.7" },
                    "coreason-ecosystem": { status: "in_progress", conclusion: "pending", run_id: 26315888708, name: "Release", branch: "v0.60.8" },
                    "coreason-isv-admin": { status: "in_progress", conclusion: "pending", run_id: 26315895400, name: "Release (Retry)", branch: "v0.88.6" },
                    "coreason-sensory-app": { status: "in_progress", conclusion: "pending", run_id: 26315891468, name: "Publish Container", branch: "v1.6.12" },
                    "coreason-sensory-embed": { status: "completed", conclusion: "success", run_id: 26315889022, name: "Publish Container", branch: "v1.1.8" },
                    "coreason-runtime": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-meta-engineering": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-documentation": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-release-healer": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" }
                },
                healing_events: {
                    "coreason-isv-admin": [
                        { time: "2026-05-22 19:10:00", type: "diagnosis", message: "Diagnosing failure in coreason-isv-admin (Run 26315885992)" },
                        { time: "2026-05-22 19:10:05", type: "fix", message: "Ruff formatting check failed. Running auto-fix locally..." },
                        { time: "2026-05-22 19:10:15", type: "fix", message: "Pushed formatting fix. Re-tagging v0.88.6..." }
                    ]
                },
                logs: ["[INFO] Pushed fixed files. Re-tagging release v0.88.6 in coreason-isv-admin...", "[SUCCESS] Re-tagging successful. Re-triggering release run...", "[INFO] Release run 26315895400 registered for coreason-isv-admin. Polling..."]
            },
            {
                current_level: 2,
                completed_repos: ["coreason-runtime"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "completed", conclusion: "success", run_id: 26315887120, name: "Release", branch: "v0.37.7" },
                    "coreason-ecosystem": { status: "completed", conclusion: "success", run_id: 26315888708, name: "Release", branch: "v0.60.8" },
                    "coreason-isv-admin": { status: "completed", conclusion: "success", run_id: 26315895400, name: "Release (Retry)", branch: "v0.88.6" },
                    "coreason-sensory-app": { status: "completed", conclusion: "success", run_id: 26315891468, name: "Publish Container", branch: "v1.6.12" },
                    "coreason-sensory-embed": { status: "completed", conclusion: "success", run_id: 26315889022, name: "Publish Container", branch: "v1.1.8" },
                    "coreason-runtime": { status: "in_progress", conclusion: "pending", run_id: 26316149270, name: "Release", branch: "v0.75.4" },
                    "coreason-meta-engineering": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-documentation": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" },
                    "coreason-release-healer": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" }
                },
                healing_events: {
                    "coreason-isv-admin": [
                        { time: "2026-05-22 19:10:00", type: "diagnosis", message: "Diagnosing failure in coreason-isv-admin (Run 26315885992)" },
                        { time: "2026-05-22 19:10:05", type: "fix", message: "Ruff formatting check failed. Running auto-fix locally..." },
                        { time: "2026-05-22 19:10:15", type: "fix", message: "Pushed formatting fix. Re-tagging v0.88.6..." }
                    ]
                },
                logs: ["[SUCCESS] Level 2: coreason-ecosystem release succeeded!", "[SUCCESS] Level 2: coreason-isv-admin retry succeeded!", "[SUCCESS] Level 2: coreason-sensory-app succeeded!", "[SUCCESS] Level 2 releases successfully completed!", "[INFO] === LEVEL 3 ORCHESTRATION ===", "[INFO] Processing coreason-runtime...", "[INFO] Bumping downstream deps and compiling lockfile...", "[INFO] Committed & pushed bump changes.", "[INFO] Waiting for Level 3 release run..."]
            },
            {
                current_level: 3,
                completed_repos: ["coreason-meta-engineering", "coreason-documentation"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "completed", conclusion: "success", run_id: 26315887120, name: "Release", branch: "v0.37.7" },
                    "coreason-ecosystem": { status: "completed", conclusion: "success", run_id: 26315888708, name: "Release", branch: "v0.60.8" },
                    "coreason-isv-admin": { status: "completed", conclusion: "success", run_id: 26315895400, name: "Release (Retry)", branch: "v0.88.6" },
                    "coreason-sensory-app": { status: "completed", conclusion: "success", run_id: 26315891468, name: "Publish Container", branch: "v1.6.12" },
                    "coreason-sensory-embed": { status: "completed", conclusion: "success", run_id: 26315889022, name: "Publish Container", branch: "v1.1.8" },
                    "coreason-runtime": { status: "completed", conclusion: "success", run_id: 26316149270, name: "Release", branch: "v0.75.4" },
                    "coreason-meta-engineering": { status: "in_progress", conclusion: "pending", run_id: 26316200120, name: "Release", branch: "main" },
                    "coreason-documentation": { status: "completed", conclusion: "success", run_id: 26316200250, name: "Release Please", branch: "main" },
                    "coreason-release-healer": { status: "pending", conclusion: "pending", run_id: null, name: "N/A", branch: "N/A" }
                },
                healing_events: {},
                logs: ["[SUCCESS] Level 3: coreason-runtime release succeeded!", "[SUCCESS] Level 3 releases successfully completed!", "[INFO] === LEVEL 4 ORCHESTRATION ===", "[INFO] Processing Level 4: coreason-meta-engineering, coreason-documentation...", "[INFO] Waiting for Level 4 release actions..."]
            },
            {
                current_level: 4,
                completed_repos: ["coreason-release-healer"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "completed", conclusion: "success", run_id: 26315887120, name: "Release", branch: "v0.37.7" },
                    "coreason-ecosystem": { status: "completed", conclusion: "success", run_id: 26315888708, name: "Release", branch: "v0.60.8" },
                    "coreason-isv-admin": { status: "completed", conclusion: "success", run_id: 26315895400, name: "Release (Retry)", branch: "v0.88.6" },
                    "coreason-sensory-app": { status: "completed", conclusion: "success", run_id: 26315891468, name: "Publish Container", branch: "v1.6.12" },
                    "coreason-sensory-embed": { status: "completed", conclusion: "success", run_id: 26315889022, name: "Publish Container", branch: "v1.1.8" },
                    "coreason-runtime": { status: "completed", conclusion: "success", run_id: 26316149270, name: "Release", branch: "v0.75.4" },
                    "coreason-meta-engineering": { status: "completed", conclusion: "success", run_id: 26316200120, name: "Release", branch: "v0.33.10" },
                    "coreason-documentation": { status: "completed", conclusion: "success", run_id: 26316200250, name: "Release Please", branch: "main" },
                    "coreason-release-healer": { status: "in_progress", conclusion: "pending", run_id: 26316219306, name: "Publish Release Artifacts", branch: "main" }
                },
                healing_events: {},
                logs: ["[SUCCESS] Level 4: coreason-meta-engineering release succeeded!", "[SUCCESS] Level 4 releases successfully completed!", "[INFO] === LEVEL 5 ORCHESTRATION ===", "[INFO] Processing coreason-release-healer...", "[INFO] Waiting for Level 5 release actions..."]
            },
            {
                current_level: 5,
                completed_repos: ["coreason-release-healer"],
                repo_statuses: {
                    "coreason-manifest": { status: "completed", conclusion: "success", run_id: 26315744993, name: "Release", branch: "v0.94.12" },
                    "coreason-sensory-core": { status: "completed", conclusion: "success", run_id: 26315728884, name: "Release", branch: "v1.5.9" },
                    "coreason-urn-authority": { status: "completed", conclusion: "success", run_id: 26315887120, name: "Release", branch: "v0.37.7" },
                    "coreason-ecosystem": { status: "completed", conclusion: "success", run_id: 26315888708, name: "Release", branch: "v0.60.8" },
                    "coreason-isv-admin": { status: "completed", conclusion: "success", run_id: 26315895400, name: "Release (Retry)", branch: "v0.88.6" },
                    "coreason-sensory-app": { status: "completed", conclusion: "success", run_id: 26315891468, name: "Publish Container", branch: "v1.6.12" },
                    "coreason-sensory-embed": { status: "completed", conclusion: "success", run_id: 26315889022, name: "Publish Container", branch: "v1.1.8" },
                    "coreason-runtime": { status: "completed", conclusion: "success", run_id: 26316149270, name: "Release", branch: "v0.75.4" },
                    "coreason-meta-engineering": { status: "completed", conclusion: "success", run_id: 26316200120, name: "Release", branch: "v0.33.10" },
                    "coreason-documentation": { status: "completed", conclusion: "success", run_id: 26316200250, name: "Release Please", branch: "main" },
                    "coreason-release-healer": { status: "completed", conclusion: "success", run_id: 26316219306, name: "Publish Release Artifacts", branch: "v0.2.8" }
                },
                healing_events: {},
                logs: ["[SUCCESS] Level 5: coreason-release-healer release succeeded!", "[SUCCESS] Level 5 releases successfully completed!", "[SUCCESS] === SYNCHRONIZED RELEASE COMPLETE ===", "[SUCCESS] Packages updated successfully: 11 / 11"]
            }
        ];
        
        function getStatusColor(status, conclusion) {
            status = (status || "").toLowerCase();
            conclusion = (conclusion || "").toLowerCase();
            
            if (status === "completed" && conclusion === "success") return "success";
            if (status === "in_progress") return "in-progress";
            if (status === "queued" || status === "waiting") return "queued";
            if (conclusion === "failure" || conclusion === "failed" || status === "failed") return "failed";
            if (status === "healing") return "healing";
            return "pending";
        }
        
        function renderPipeline(currentLevel) {
            const container = document.getElementById("pipeline-nodes");
            container.innerHTML = "";
            
            TIERS.forEach((tier, idx) => {
                const levelNum = idx + 1;
                const isActive = idx === currentLevel;
                const isCompleted = idx < currentLevel;
                
                let tierStatus = "pending";
                if (isActive) tierStatus = "active";
                else if (isCompleted) tierStatus = "completed";
                
                let reposHTML = "";
                tier.forEach(repo => {
                    reposHTML += `<div class="repo-pill" id="pill-${repo}">${repo}</div>`;
                });
                
                const card = document.createElement("div");
                card.className = `tier-node ${tierStatus}`;
                card.innerHTML = `
                    <div class="tier-header">
                        <span class="tier-title">Level ${levelNum}</span>
                        <span class="tier-badge ${tierStatus}">${tierStatus}</span>
                    </div>
                    <div class="tier-repos">
                        ${reposHTML}
                    </div>
                `;
                container.appendChild(card);
            });
        }
        
        function updatePills(repoStatuses) {
            for (const [repo, info] of Object.entries(repoStatuses)) {
                const pill = document.getElementById(`pill-${repo}`);
                if (pill) {
                    pill.className = "repo-pill";
                    const status = getStatusColor(info.status, info.conclusion);
                    if (status === "in-progress" || status === "healing") {
                        pill.classList.add("active-pill");
                    }
                }
            }
        }
        
        function renderRepos(repoStatuses, healingEvents, state) {
            const container = document.getElementById("repos-list");
            container.innerHTML = "";
            
            const currentLevel = state ? state.current_level : 0;
            const completedRepos = state ? (state.completed_repos || []) : [];
            const versions = state ? (state.new_versions || {}) : {};
            
            ALL_REPOS.forEach(repo => {
                const info = repoStatuses[repo] || { status: "pending", conclusion: "N/A", run_id: null, branch: "N/A", name: "N/A" };
                const events = healingEvents[repo] || [];
                const status = getStatusColor(info.status, info.conclusion);
                const levelIdx = TIERS.findIndex(t => t.includes(repo));
                
                // Strict release plan status determination
                let finalStatus = "pending";
                if (levelIdx < currentLevel) {
                    finalStatus = "success";
                } else if (levelIdx === currentLevel) {
                    if (status === "success") {
                        finalStatus = "success";
                    } else if (status === "in-progress" || status === "failed" || status === "healing" || status === "queued") {
                        finalStatus = status;
                    } else {
                        finalStatus = "pending";
                    }
                } else {
                    finalStatus = "pending";
                }
                
                const statusLabelMap = {
                    "success": "succeeded",
                    "in-progress": "in progress",
                    "queued": "queued",
                    "failed": "failed",
                    "healing": "healing",
                    "pending": "pending"
                };
                
                let badgeClass = finalStatus;
                if (badgeClass === "success") badgeClass = "success";
                
                let badgeHTML = `<span class="status-badge ${badgeClass}">${statusLabelMap[finalStatus]}</span>`;
                if (finalStatus === "in-progress" || finalStatus === "healing") {
                    badgeHTML = `<span class="status-badge ${badgeClass}"><span class="pulse-icon"></span> ${statusLabelMap[finalStatus]}</span>`;
                }
                
                const version = versions[repo] ? "v" + versions[repo] : "vX.Y.Z";
                
                let runDetails = "No active workflow run";
                const isStartedOrDone = (levelIdx < currentLevel) || (levelIdx === currentLevel && (completedRepos.includes(repo) || status === "in-progress" || status === "failed" || status === "healing" || status === "queued"));
                if (info.run_id && isStartedOrDone) {
                    const runUrl = `https://github.com/CoReason-AI/${repo}/actions/runs/${info.run_id}`;
                    runDetails = `<div class="repo-run-line">
                        <span>Workflow: <strong>${info.name}</strong></span>
                        <span>Run ID: <a href="${runUrl}" target="_blank">${info.run_id}</a></span>
                    </div>`;
                }
                
                let healingHTML = "";
                if (events.length > 0) {
                    let stepsHTML = "";
                    events.forEach(ev => {
                        stepsHTML += `
                            <div class="healing-step">
                                <span class="healing-step-time">${ev.time.substring(11, 19)}</span>
                                <span class="healing-step-msg">${ev.message}</span>
                            </div>
                        `;
                    });
                    const isSuccess = finalStatus === "success";
                    const boxClass = isSuccess ? "healing-box resolved" : "healing-box";
                    const iconClass = isSuccess ? "pulse-icon-static" : "pulse-icon";
                    const iconColor = isSuccess ? "var(--text-muted)" : "var(--success)";
                    healingHTML = `
                        <div class="${boxClass}">
                            <div class="healing-title">
                                <span class="${iconClass}" style="color:${iconColor}"></span> Healer Interventions
                            </div>
                            ${stepsHTML}
                        </div>
                    `;
                }
                
                const card = document.createElement("div");
                card.className = `card repo-card ${finalStatus}`;
                card.innerHTML = `
                    <div class="repo-header">
                        <div class="repo-title-block">
                            <span class="repo-card-name">${repo}</span>
                            <span class="repo-card-ver">${version}</span>
                            <span class="repo-card-level">Tier ${levelIdx + 1}</span>
                        </div>
                        ${badgeHTML}
                    </div>
                    <div class="repo-card-body">
                        ${runDetails}
                        ${healingHTML}
                    </div>
                `;
                container.appendChild(card);
            });
        }
        
        function appendLogs(logLines) {
            const term = document.getElementById("log-terminal");
            // If clearing or starting fresh
            if (term.children.length > 500) {
                term.innerHTML = "";
            }
            
            logLines.forEach(line => {
                let logClass = "log-debug";
                if (line.includes("[SUCCESS]")) logClass = "log-success";
                else if (line.includes("[ERROR]") || line.includes("AGENT_HEALING_REQUIRED")) logClass = "log-error";
                else if (line.includes("[WARNING]")) logClass = "log-warning";
                else if (line.includes("[INFO]")) logClass = "log-info";
                else if (line.includes("DEBUG")) logClass = "log-debug";
                else if (line.trim().startsWith("-")) logClass = "log-muted";
                
                const span = document.createElement("span");
                span.className = `log-line ${logClass}`;
                span.textContent = line;
                term.appendChild(span);
            });
            term.scrollTop = term.scrollHeight;
        }
        
        function updateDashboard(data) {
            document.getElementById("update-time").textContent = "Last update: " + new Date().toLocaleTimeString();
            
            // 1. Render metrics
            const state = data.state;
            let currentLevel = 0;
            let completedCount = 0;
            
            if (state) {
                currentLevel = state.current_level || 0;
                document.getElementById("m-bump").textContent = (state.bump_type || "PATCH").toUpperCase();
                document.getElementById("m-level").textContent = "Tier " + (currentLevel + 1);
                
                // Calculate percentage based on completed repos in state + level tiers
                const totalRepos = ALL_REPOS.length;
                
                // Add up past level repos
                TIERS.forEach((tier, idx) => {
                    if (idx < currentLevel) {
                        completedCount += tier.length;
                    }
                });
                // Add up current level completed repos
                const completedInCurrent = state.completed_repos || [];
                completedCount += completedInCurrent.length;
                
                // Cap completedCount to totalRepos
                completedCount = Math.min(completedCount, totalRepos);
                const pct = Math.round((completedCount / totalRepos) * 100);
                
                document.getElementById("m-progress").textContent = pct + "%";
            }
            
            const healerPid = data.healer_pid;
            const healerBox = document.getElementById("m-healer");
            if (healerPid) {
                healerBox.textContent = healerPid;
                healerBox.style.color = "var(--success)";
            } else {
                healerBox.textContent = "OFFLINE";
                healerBox.style.color = "var(--text-muted)";
            }
            
            // 2. Render Topological nodes
            renderPipeline(currentLevel);
            
            // 3. Update nodes pills classes
            updatePills(data.repo_statuses);
            
            // 4. Render Repository Cards list
            renderRepos(data.repo_statuses, data.healing_events, state);
        }
        
        function fetchTelemetry() {
            if (isSimulated) return;
            
            fetch("/api/status")
                .then(res => res.json())
                .then(data => {
                    updateDashboard(data);
                })
                .catch(err => console.error("Error fetching status:", err));
                
            fetch("/api/logs")
                .then(res => res.json())
                .then(data => {
                    const term = document.getElementById("log-terminal");
                    term.innerHTML = ""; // Full reload to get exact logs tail
                    appendLogs(data.logs);
                })
                .catch(err => console.error("Error fetching logs:", err));
        }
        
        function toggleSimulation() {
            const toggle = document.getElementById("sim-toggle");
            isSimulated = toggle.checked;
            
            const resetBtn = document.getElementById("sim-reset-btn");
            if (isSimulated) {
                resetBtn.style.display = "inline-block";
                clearInterval(pollerTimer);
                simIndex = 0;
                clearTerminal();
                runSimulationStep();
                pollerTimer = setInterval(runSimulationStep, 4500);
            } else {
                resetBtn.style.display = "none";
                clearInterval(pollerTimer);
                clearTerminal();
                fetchTelemetry();
                pollerTimer = setInterval(fetchTelemetry, updateInterval);
            }
        }
        
        function resetSimulation() {
            simIndex = 0;
            clearTerminal();
            runSimulationStep();
        }
        
        function runSimulationStep() {
            if (!isSimulated) return;
            
            const state = simStates[simIndex];
            if (!state) return;
            
            document.getElementById("update-time").textContent = "Simulated Update: " + new Date().toLocaleTimeString();
            
            // Calculate progress
            let completedCount = 0;
            TIERS.forEach((tier, idx) => {
                if (idx < state.current_level) {
                    completedCount += tier.length;
                }
            });
            completedCount += (state.completed_repos || []).length;
            const pct = Math.round((completedCount / ALL_REPOS.length) * 100);
            
            document.getElementById("m-bump").textContent = "PATCH";
            document.getElementById("m-level").textContent = "Tier " + (state.current_level + 1);
            document.getElementById("m-progress").textContent = pct + "%";
            document.getElementById("m-healer").textContent = "20264 (SIM)";
            document.getElementById("m-healer").style.color = "var(--success)";
            
            // Render layouts
            renderPipeline(state.current_level);
            updatePills(state.repo_statuses);
            
            // Fake release state object for renderer
            const mockState = {
                current_level: state.current_level,
                completed_repos: state.completed_repos,
                new_versions: {
                    "coreason-manifest": "0.94.12",
                    "coreason-sensory-core": "1.5.9",
                    "coreason-urn-authority": "0.37.7",
                    "coreason-ecosystem": "0.60.8",
                    "coreason-isv-admin": "0.88.6",
                    "coreason-sensory-app": "1.6.12",
                    "coreason-sensory-embed": "1.1.8",
                    "coreason-runtime": "0.75.4",
                    "coreason-meta-engineering": "0.33.10",
                    "coreason-documentation": "vX.Y.Z",
                    "coreason-release-healer": "vX.Y.Z"
                }
            };
            
            renderRepos(state.repo_statuses, state.healing_events, mockState);
            appendLogs(state.logs);
            
            // Advance state
            simIndex = (simIndex + 1) % simStates.length;
        }
        
        function clearTerminal() {
            document.getElementById("log-terminal").innerHTML = "";
        }
        
        function triggerManualRefresh() {
            fetchTelemetry();
        }
        
        // Initialize polling
        fetchTelemetry();
        pollerTimer = setInterval(fetchTelemetry, updateInterval);
        
    </script>
</body>
</html>
"""

if __name__ == "__main__":
    main()
