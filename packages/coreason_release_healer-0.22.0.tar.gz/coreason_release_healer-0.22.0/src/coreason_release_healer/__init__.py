# CoReason Infrastructure Tooling Package
__version__ = "0.22.0"
