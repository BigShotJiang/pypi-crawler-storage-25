#!/usr/bin/env python3
"""
CoReason Synchronized Release Orchestrator
Automates cascading releases across all 11 coreason-ai packages in topological order.
"""

import os
import sys
import re
import json
import subprocess
import argparse
import time
import atexit
import urllib.request
import urllib.error

# Crate name mappings for polling crates.io registry
PUBLISHED_CRATES = {
    "coreason-runtime": "coreason-runtime",
    "coreason-urn-authority": "coreason-urn-authority",
    "coreason-meta-engineering": "coreason-meta-engineering"
}

def wait_for_crate_publication(crate_name, version, timeout=300, interval=10):
    log_info(f"Waiting for crate '{crate_name}' version '{version}' to be available on crates.io...")
    start = time.time()
    url = f"https://crates.io/api/v1/crates/{crate_name}"
    
    req = urllib.request.Request(
        url,
        headers={"User-Agent": "CoReason Release Bot (release-bot@coreason.ai)"}
    )
    
    while time.time() - start < timeout:
        try:
            with urllib.request.urlopen(req) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode())
                    versions = [v.get("num") for v in data.get("versions", [])]
                    if version in versions:
                        log_success(f"Crate '{crate_name}' version '{version}' is now available on crates.io!")
                        return True
        except Exception as e:
            log_warning(f"Error querying crates.io for '{crate_name}': {e}")
            
        time.sleep(interval)
        
    log_error(f"Timed out waiting for crate '{crate_name}' version '{version}' to be published on crates.io.")
    return False


# Clear dummy/invalid GITHUB_TOKEN to let gh CLI fall back to keyring
if "GITHUB_TOKEN" in os.environ and os.environ["GITHUB_TOKEN"].startswith("github_pat_antigravitydummy"):
    del os.environ["GITHUB_TOKEN"]

# ANSI color codes for premium CLI output
COLOR_GREEN = "\033[92m"
COLOR_YELLOW = "\033[93m"
COLOR_RED = "\033[91m"
COLOR_CYAN = "\033[96m"
COLOR_MAGENTA = "\033[95m"
COLOR_BOLD = "\033[1m"
COLOR_RESET = "\033[0m"

# Topological Tiers as analyzed from dependencies
TIERS = [
    # Level 1: Root nodes
    ["coreason-manifest", "coreason-sensory-core"],
    # Level 2: Dependents on Level 1
    ["coreason-urn-authority", "coreason-isv-admin", "coreason-sensory-app", "coreason-sensory-embed"],
    # Level 3: Dependents on Level 2
    ["coreason-runtime", "coreason-ecosystem"],
    # Level 4: Dependents on Level 3
    ["coreason-meta-engineering", "coreason-documentation"],
    # Level 5: Deploys all
    ["coreason-release-healer"],
    # Level 6: Enclave Installer
    ["coreason-installer"]
]

# Mapping from repo name to Helm charts / other deployment updates
HELM_CHARTS = {
    "coreason-runtime": "charts/coreason-runtime/values.yaml",
    "coreason-sensory-app": "charts/coreason-sensory-app/values.yaml"
}

def log_info(msg):
    print(f"{COLOR_CYAN}{COLOR_BOLD}[INFO]{COLOR_RESET} {msg}")

def log_success(msg):
    print(f"{COLOR_GREEN}{COLOR_BOLD}[SUCCESS]{COLOR_RESET} {msg}")

def log_warning(msg):
    print(f"{COLOR_YELLOW}{COLOR_BOLD}[WARNING]{COLOR_RESET} {msg}")

def log_error(msg):
    print(f"{COLOR_RED}{COLOR_BOLD}[ERROR]{COLOR_RESET} {msg}")

def run_cmd(cmd, cwd=None):
    try:
        res = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace", check=True)
        return res.stdout.strip()
    except subprocess.CalledProcessError as e:
        err_msg = (e.stderr or "").strip() or (e.stdout or "").strip()
        return f"ERROR: {err_msg}"
    except Exception as e:
        return f"ERROR: {str(e)}"

def save_state(state_path, state_data):
    try:
        os.makedirs(os.path.dirname(state_path), exist_ok=True)
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump(state_data, f, indent=2)
        log_info(f"Saved release state to {state_path}")
    except Exception as e:
        log_error(f"Failed to save state to {state_path}: {e}")

def load_state(state_path):
    if not os.path.exists(state_path):
        log_error(f"State file not found at {state_path}")
        sys.exit(1)
    try:
        with open(state_path, "r", encoding="utf-8") as f:
            state_data = json.load(f)
        log_info(f"Loaded release state from {state_path}")
        return state_data
    except Exception as e:
        log_error(f"Failed to load state from {state_path}: {e}")
        sys.exit(1)

def write_failure_diagnostic(failure_path, repo, command, error, level):
    try:
        os.makedirs(os.path.dirname(failure_path), exist_ok=True)
        diag = {
            "repo": repo,
            "command": command,
            "error": error,
            "level": level,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%SZ", time.gmtime())
        }
        with open(failure_path, "w", encoding="utf-8") as f:
            json.dump(diag, f, indent=2)
        log_info(f"Wrote failure diagnostics to {failure_path}")
    except Exception as e:
        log_error(f"Failed to write failure diagnostics to {failure_path}: {e}")

def cleanup_files(state_path, failure_path):
    for path in (state_path, failure_path):
        if os.path.exists(path):
            try:
                os.remove(path)
                log_info(f"Cleaned up {path}")
            except Exception as e:
                log_warning(f"Could not clean up {path}: {e}")

def handle_failure(state_path, failure_path, state_data, repo, command, error, level):
    save_state(state_path, state_data)
    write_failure_diagnostic(failure_path, repo, command, error, level)
    print(f"\n{COLOR_RED}{COLOR_BOLD}AGENT_HEALING_REQUIRED{COLOR_RESET}: Release failed on Level {level} for {repo}.")
    print(f"Diagnostics written to {failure_path}. Fix the issue and resume.")
    sys.exit(1)

def get_latest_remote_tag(repo_dir):
    cmd = ["git", "ls-remote", "--tags", "origin"]
    out = run_cmd(cmd, cwd=repo_dir)
    if out.startswith("ERROR"):
        log_warning(f"Could not fetch remote tags for {os.path.basename(repo_dir)}: {out}")
        return "v0.0.0"
        
    tags = []
    for line in out.splitlines():
        parts = line.split()
        if len(parts) != 2:
            continue
        ref = parts[1]
        if not ref.startswith("refs/tags/"):
            continue
        tag = ref.replace("refs/tags/", "")
        if tag.endswith("^{}"):
            tag = tag[:-3]
        
        # Match vX.Y.Z
        m = re.match(r'^v?(\d+)\.(\d+)\.(\d+)$', tag)
        if m:
            major, minor, patch = int(m.group(1)), int(m.group(2)), int(m.group(3))
            tags.append(((major, minor, patch), tag))
            
    if not tags:
        return "v0.0.0"
    tags.sort(key=lambda x: x[0])
    return tags[-1][1]

def calculate_next_tag(current_tag, bump_type):
    tag_clean = current_tag.lstrip("v")
    parts = tag_clean.split(".")
    if len(parts) != 3:
        return "v0.0.1"
    try:
        major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2])
        if bump_type == "major":
            next_ver = f"{major+1}.0.0"
        elif bump_type == "minor":
            next_ver = f"{major}.{minor+1}.0"
        else: # patch
            next_ver = f"{major}.{minor}.{patch+1}"
        return f"v{next_ver}"
    except ValueError:
        return "v0.0.1"

def update_pyproject_deps(pyproject_path, updated_versions):
    if not os.path.exists(pyproject_path):
        return False
        
    with open(pyproject_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    original_content = content
    
    for repo, new_ver in updated_versions.items():
        repo_parts = repo.split("-")
        name_pattern = "[-_]".join(re.escape(part) for part in repo_parts)
        
        # Match "coreason-manifest>=0.94.0" or 'coreason-manifest>=0.94.0'
        pattern = r'(["\']' + name_pattern + r'(?:>=|==))([0-9.]+)(["\'])'
        content = re.sub(pattern, rf'\g<1>{new_ver}\g<3>', content)
        
    if content != original_content:
        with open(pyproject_path, "w", encoding="utf-8") as f:
            f.write(content)
        return True
    return False

def update_helm_chart(values_path, image_name, tag):
    if not os.path.exists(values_path):
        log_error(f"Helm values file not found: {values_path}")
        return False
        
    with open(values_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    original_content = content
    
    if image_name == "coreason-runtime":
        lines = content.splitlines()
        in_runtime_image = False
        for i, line in enumerate(lines):
            if 'runtime:' in line:
                in_runtime_image = True
            elif in_runtime_image and 'image:' in line:
                pass
            elif in_runtime_image and 'tag:' in line:
                lines[i] = f'    tag: {tag}'
                break
        new_content = '\n'.join(lines) + '\n'
    elif image_name == "coreason-sensory-app":
        lines = content.splitlines()
        in_image = False
        for i, line in enumerate(lines):
            if 'image:' in line:
                in_image = True
            elif in_image and 'tag:' in line:
                lines[i] = f'  tag: {tag}'
                break
        new_content = '\n'.join(lines) + '\n'
    else:
        new_content = content
        
    if new_content != original_content:
        with open(values_path, "w", encoding="utf-8") as f:
            f.write(new_content)
        return True
    return False

def update_installer_compose(compose_path, updated_versions):
    if not os.path.exists(compose_path):
        log_error(f"Compose file not found: {compose_path}")
        return False
        
    with open(compose_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    original_content = content
    
    for repo, new_ver in updated_versions.items():
        pattern = rf'(ghcr\.io/coreason-ai/{re.escape(repo)}:)([0-9.-]+(?:-dev)?)'
        content = re.sub(pattern, rf'\g<1>{new_ver}', content)
        
    if content != original_content:
        with open(compose_path, "w", encoding="utf-8", newline="\n") as f:
            f.write(content)
        return True
    return False

def cleanup_healer(proc):
    if proc and proc.poll() is None:
        log_info("Terminating local background self-healing daemon...")
        try:
            proc.terminate()
            proc.wait(timeout=5)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

def get_tag_run_status(repo, tag):
    cmd = [
        "gh", "run", "list",
        "--repo", f"CoReason-AI/{repo}",
        "--branch", tag,
        "--limit", "10",
        "--json", "databaseId,status,conclusion,name"
    ]
    out = run_cmd(cmd)
    runs = []
    if "ERROR" not in out:
        try:
            runs = json.loads(out)
        except Exception:
            pass

    if not runs:
        cmd_fallback = [
            "gh", "run", "list",
            "--repo", f"CoReason-AI/{repo}",
            "--limit", "10",
            "--json", "databaseId,status,conclusion,name"
        ]
        out_fallback = run_cmd(cmd_fallback)
        if "ERROR" not in out_fallback:
            try:
                runs = json.loads(out_fallback)
            except Exception:
                pass

    if runs:
        # Prioritize the actual release/publish/container run over standard CI check runs
        for run in runs:
            run_name = (run.get("name") or "").lower()
            if any(kw in run_name for kw in ["release", "publish", "container"]):
                return run
        return runs[0]
    return None


def ensure_uv_updated(dry_run=False):
    if dry_run:
        log_info("[DRY-RUN] Would check and update uv tool.")
        return
    log_info("Ensuring uv is up-to-date...")
    
    # 1. Try standalone update via "uv self update"
    res = run_cmd(["uv", "self", "update"])
    if "ERROR" not in res and "Self-update is only available" not in res:
        log_success(f"uv successfully updated: {res}")
        return
        
    # 2. Try upgrading via pip
    log_info("uv self update is not supported for this installation. Attempting upgrade via pip...")
    pip_cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "uv"]
    pip_res = run_cmd(pip_cmd)
    if "ERROR" not in pip_res:
        ver_res = run_cmd(["uv", "--version"])
        log_success(f"uv successfully updated via pip. Current version: {ver_res}")
    else:
        log_warning(f"Could not update uv automatically: {pip_res}. Please ensure uv is up-to-date manually.")

def get_workspace_dir(file_path):
    # Try finding based on cwd
    cwd = os.getcwd()
    if os.path.exists(os.path.join(cwd, "coreason-release-healer")) or os.path.exists(os.path.join(cwd, "coreason-infrastructure")):
        return cwd
    if os.path.basename(cwd) in ("coreason-release-healer", "coreason-infrastructure"):
        return os.path.dirname(cwd)
        
    # Fallback to file path traversal
    path = os.path.abspath(file_path)
    curr = os.path.dirname(path)
    while True:
        parent = os.path.dirname(curr)
        if parent == curr:  # reached root
            break
        if os.path.exists(os.path.join(curr, "coreason-release-healer")) or os.path.exists(os.path.join(curr, "coreason-infrastructure")):
            return curr
        if os.path.basename(curr) in ("coreason-release-healer", "coreason-infrastructure"):
            return parent
        curr = parent
        
    # Final fallback
    return os.getcwd()

def main():
    parser = argparse.ArgumentParser(description="CoReason Synchronized Release Orchestrator")
    parser.add_argument("--bump-type", choices=["major", "minor", "patch"], default="patch", help="The semver component to bump")
    parser.add_argument("--dry-run", action="store_true", help="Print actions without committing/pushing")
    parser.add_argument("--poll-timeout", type=int, default=600, help="Maximum timeout in seconds to poll for tags")
    parser.add_argument("--poll-interval", type=int, default=15, help="Seconds between polls")
    parser.add_argument("--resume", action="store_true", help="Resume progress from a saved state file")
    parser.add_argument("--state-file", help="Path to the JSON file to save/load release state")
    parser.add_argument("--failure-file", help="Path to the JSON file to save failure diagnostics")
    parser.add_argument("--no-self-healing", dest="self_healing", action="store_false", help="Disable automatic local background self-healing daemon")
    parser.set_defaults(self_healing=True)
    parser.add_argument("--no-uv-update", dest="uv_update", action="store_false", help="Disable automatic updating of uv tool")
    parser.set_defaults(uv_update=True)
    
    args = parser.parse_args()
    
    if args.uv_update:
        ensure_uv_updated(dry_run=args.dry_run)
        
    workspace_dir = get_workspace_dir(__file__)
    
    # Automatically start the healer locally by default if requested and not in GitHub Actions
    is_github_actions = os.environ.get("GITHUB_ACTIONS") == "true"
    if args.self_healing and not is_github_actions and not args.dry_run:
        log_info("Starting local background self-healing daemon...")
        try:
            # Set up PYTHONPATH for the subprocess
            env = os.environ.copy()
            pythonpath = env.get("PYTHONPATH", "")
            extra_paths = []
            
            # Local checkout src folder
            local_src = os.path.join(workspace_dir, "coreason-release-healer", "src")
            if not os.path.exists(local_src):
                local_src = os.path.join(workspace_dir, "coreason-infrastructure", "src")
            if os.path.exists(local_src):
                extra_paths.append(local_src)
                
            # Package's own parent folder (if running from source checkout)
            package_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if os.path.exists(os.path.join(package_dir, "coreason_release_healer")):
                extra_paths.append(package_dir)
                
            if extra_paths:
                separator = ";" if os.name == "nt" else ":"
                if pythonpath:
                    env["PYTHONPATH"] = pythonpath + separator + separator.join(extra_paths)
                else:
                    env["PYTHONPATH"] = separator.join(extra_paths)
            
            healer_process = subprocess.Popen(
                [sys.executable, "-m", "coreason_release_healer.agent_ci_healer", "--monitor"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                env=env,
            )
            log_success(f"Self-healing daemon started in background (PID: {healer_process.pid})")
            atexit.register(cleanup_healer, healer_process)
        except Exception as e:
            log_warning(f"Failed to start self-healing daemon: {e}")
    
    state_path = args.state_file or os.path.join(workspace_dir, ".coreason", "release_state.json")
    failure_path = args.failure_file or os.path.join(workspace_dir, ".coreason", "release_failure.json")
    
    # We will build a map of new versions we release during this run
    new_versions = {}
    completed_repos = []
    start_tier_idx = 0
    bump_type = args.bump_type
    dry_run = args.dry_run

    if args.resume:
        state = load_state(state_path)
        bump_type = state.get("bump_type", bump_type)
        dry_run = state.get("dry_run", dry_run)
        new_versions = state.get("new_versions", {})
        start_tier_idx = state.get("current_level", 0)
        completed_repos = state.get("completed_repos", [])
        log_info(f"Resuming release. Bump Type: {bump_type}, Starting from Level {start_tier_idx + 1}")
    else:
        cleanup_files(state_path, failure_path)
        
    log_info(f"Starting synchronized release orchestration in workspace: {workspace_dir}")
    log_info(f"Bump Type: {bump_type}")
    if dry_run:
        log_warning("DRY RUN MODE ENABLED - No changes will be saved, committed, or pushed")
        
    for tier_idx, repos in enumerate(TIERS):
        if tier_idx < start_tier_idx:
            continue
            
        level = tier_idx + 1
        log_info(f"\n=== LEVEL {level} ORCHESTRATION ===")
        
        # If we are resuming the start tier, we keep the loaded completed_repos.
        # Otherwise, clear it for the new tier.
        if tier_idx > start_tier_idx:
            completed_repos = []
            
        # 1. Update and commit/push for all repos in this tier
        actions_to_poll = []
        
        for repo in repos:
            repo_dir = os.path.join(workspace_dir, repo)
            if not os.path.exists(repo_dir):
                handle_failure(
                    state_path=state_path,
                    failure_path=failure_path,
                    state_data={
                        "bump_type": bump_type,
                        "dry_run": dry_run,
                        "new_versions": new_versions,
                        "current_level": tier_idx,
                        "completed_repos": completed_repos
                    },
                    repo=repo,
                    command="check_dir_exists",
                    error=f"Missing repository folder: {repo_dir}",
                    level=level
                )
                
            if repo in completed_repos:
                log_info(f"Repository {repo} already processed and pushed in this tier. Skipping updates...")
                next_tag = f"v{new_versions[repo]}"
                if not dry_run:
                    actions_to_poll.append((repo, repo_dir, next_tag))
                continue
                
            log_info(f"Processing repository: {repo}")
            
            # Reset and pull latest main
            if not dry_run:
                checkout_res = run_cmd(["git", "checkout", "main"], cwd=repo_dir)
                if "ERROR" in checkout_res:
                    handle_failure(
                        state_path=state_path,
                        failure_path=failure_path,
                        state_data={
                            "bump_type": bump_type,
                            "dry_run": dry_run,
                            "new_versions": new_versions,
                            "current_level": tier_idx,
                            "completed_repos": completed_repos
                        },
                        repo=repo,
                        command="git checkout main",
                        error=checkout_res,
                        level=level
                    )
                pull_res = run_cmd(["git", "pull", "origin", "main"], cwd=repo_dir)
                if "ERROR" in pull_res:
                    log_warning(f"Git pull failed for {repo}: {pull_res}. Proceeding anyway...")
            
            # Determine versions
            if repo in new_versions:
                next_ver_no_v = new_versions[repo]
                next_tag = f"v{next_ver_no_v}"
                latest_tag = "unknown"
                log_info(f"  Target release version (restored from state): {next_tag}")
            else:
                latest_tag = get_latest_remote_tag(repo_dir)
                next_tag = calculate_next_tag(latest_tag, bump_type)
                next_ver_no_v = next_tag.lstrip("v")
                log_info(f"  Current remote version: {latest_tag}")
                log_info(f"  Target release version: {next_tag}")
            
            # Update dependency pins if we are on levels > 1
            modified = False
            
            if level > 1:
                # Update pyproject.toml if present
                pyproject_path = os.path.join(repo_dir, "pyproject.toml")
                if os.path.exists(pyproject_path):
                    if dry_run:
                        log_info(f"  [DRY-RUN] Would update dependency pins in pyproject.toml with: {new_versions}")
                        modified = True
                    else:
                        if update_pyproject_deps(pyproject_path, new_versions):
                            log_success(f"  Updated dependency pins in {repo}/pyproject.toml")
                            modified = True
                            
                # Special Helm Chart values updates for coreason-release-healer
                if repo == "coreason-release-healer":
                    for dep_repo, values_file in HELM_CHARTS.items():
                        if dep_repo in new_versions:
                            v_tag = f"v{new_versions[dep_repo]}"
                            values_path = os.path.join(repo_dir, values_file)
                            if dry_run:
                                log_info(f"  [DRY-RUN] Would update Helm tag to {v_tag} in {values_file}")
                                modified = True
                            else:
                                if update_helm_chart(values_path, dep_repo, v_tag):
                                    log_success(f"  Updated Helm tag to {v_tag} in {values_file}")
                                    modified = True

                # Special Compose templates updates for coreason-installer
                if repo == "coreason-installer":
                    compose_path = os.path.join(repo_dir, "templates", "compose.yaml")
                    if os.path.exists(compose_path):
                        if dry_run:
                            log_info(f"  [DRY-RUN] Would update compose images in templates/compose.yaml with: {new_versions}")
                            modified = True
                        else:
                            if update_installer_compose(compose_path, new_versions):
                                log_success(f"  Updated compose images in {repo}/templates/compose.yaml")
                                modified = True
            
            # Run Lock compiles if files modified
            if modified and not dry_run:
                pyproject_path = os.path.join(repo_dir, "pyproject.toml")
                if os.path.exists(pyproject_path):
                    log_info(f"  Compiling python lockfile (uv lock) in {repo}...")
                    lock_res = run_cmd(["uv", "lock"], cwd=repo_dir)
                    if "ERROR" in lock_res:
                        handle_failure(
                            state_path=state_path,
                            failure_path=failure_path,
                            state_data={
                                "bump_type": bump_type,
                                "dry_run": dry_run,
                                "new_versions": new_versions,
                                "current_level": tier_idx,
                                "completed_repos": completed_repos
                            },
                            repo=repo,
                            command="uv lock",
                            error=lock_res,
                            level=level
                        )
                    log_success(f"  Compiled lockfile for {repo}")
                    
                pkg_path = os.path.join(repo_dir, "package.json")
                if os.path.exists(pkg_path):
                    log_info(f"  Compiling node lockfile (npm install) in {repo}...")
                    lock_res = run_cmd(["npm", "install", "--package-lock-only"], cwd=repo_dir)
                    if "ERROR" in lock_res:
                        handle_failure(
                            state_path=state_path,
                            failure_path=failure_path,
                            state_data={
                                "bump_type": bump_type,
                                "dry_run": dry_run,
                                "new_versions": new_versions,
                                "current_level": tier_idx,
                                "completed_repos": completed_repos
                            },
                            repo=repo,
                            command="npm install --package-lock-only",
                            error=lock_res,
                            level=level
                        )
                    log_success(f"  Compiled lockfile for {repo}")
            
            # Commit and push
            commit_msg = ""
            if bump_type == "patch":
                commit_msg = f"fix(deps): bump dependencies for synchronized release {next_tag}"
            elif bump_type == "minor":
                commit_msg = f"feat(deps): bump dependencies for synchronized release {next_tag}"
            else: # major
                commit_msg = f"feat(deps)!: bump dependencies for synchronized release {next_tag}\n\nBREAKING CHANGE: synchronized major release"
                
            if dry_run:
                log_info(f"  [DRY-RUN] Would commit changes with message: '{commit_msg.splitlines()[0]}'")
                log_info(f"  [DRY-RUN] Would push to origin main")
                new_versions[repo] = next_ver_no_v
                completed_repos.append(repo)
                save_state(state_path, {
                    "bump_type": bump_type,
                    "dry_run": dry_run,
                    "new_versions": new_versions,
                    "current_level": tier_idx,
                    "completed_repos": completed_repos
                })
            else:
                # Set release bot user identity
                run_cmd(["git", "config", "user.name", "CoReason Release Bot"], cwd=repo_dir)
                run_cmd(["git", "config", "user.email", "release-bot@coreason.ai"], cwd=repo_dir)
                
                run_cmd(["git", "add", "."], cwd=repo_dir)
                commit_res = run_cmd(["git", "commit", "--allow-empty", "-m", commit_msg], cwd=repo_dir)
                if "ERROR" in commit_res:
                    handle_failure(
                        state_path=state_path,
                        failure_path=failure_path,
                        state_data={
                            "bump_type": bump_type,
                            "dry_run": dry_run,
                            "new_versions": new_versions,
                            "current_level": tier_idx,
                            "completed_repos": completed_repos
                        },
                        repo=repo,
                        command="git commit",
                        error=commit_res,
                        level=level
                    )
                log_info(f"  Committed to {repo}")
                
                push_res = run_cmd(["git", "push", "origin", "main"], cwd=repo_dir)
                if "ERROR" in push_res:
                    handle_failure(
                        state_path=state_path,
                        failure_path=failure_path,
                        state_data={
                            "bump_type": bump_type,
                            "dry_run": dry_run,
                            "new_versions": new_versions,
                            "current_level": tier_idx,
                            "completed_repos": completed_repos
                        },
                        repo=repo,
                        command="git push",
                        error=push_res,
                        level=level
                    )
                log_success(f"  Pushed to origin main for {repo}")
                
                actions_to_poll.append((repo, repo_dir, next_tag))
                new_versions[repo] = next_ver_no_v
                completed_repos.append(repo)
                save_state(state_path, {
                    "bump_type": bump_type,
                    "dry_run": dry_run,
                    "new_versions": new_versions,
                    "current_level": tier_idx,
                    "completed_repos": completed_repos
                })
                

        # 2. Wait / Poll for tags for all repos in this tier (if not dry-run)
        if not dry_run and actions_to_poll:
            log_info(f"Waiting for release tags and successful GitHub Actions workflows on Level {level} repositories...")
            start_time = time.time()
            pending = list(actions_to_poll)
            
            tag_detected = {p_repo: False for p_repo, _, _ in pending}
            
            while pending:
                if time.time() - start_time > args.poll_timeout:
                    err_msg = f"Timed out waiting for release runs after {args.poll_timeout} seconds!"
                    handle_failure(
                        state_path=state_path,
                        failure_path=failure_path,
                        state_data={
                            "bump_type": bump_type,
                            "dry_run": dry_run,
                            "new_versions": new_versions,
                            "current_level": tier_idx,
                            "completed_repos": completed_repos
                        },
                        repo=[p[0] for p in pending],
                        command="poll_tags_and_runs",
                        error=err_msg,
                        level=level
                    )
                    
                next_pending = []
                for p_repo, p_dir, p_tag in pending:
                    if not tag_detected[p_repo]:
                        cmd = ["git", "ls-remote", "--tags", "origin", f"refs/tags/{p_tag}"]
                        tag_check = run_cmd(cmd, cwd=p_dir)
                        if p_tag in tag_check:
                            log_success(f"  Tag {p_tag} detected for {p_repo}! Checking publish workflow status...")
                            tag_detected[p_repo] = True
                        else:
                            next_pending.append((p_repo, p_dir, p_tag))
                            continue
                            
                    run_info = get_tag_run_status(p_repo, p_tag)
                    if not run_info:
                        log_info(f"  Waiting for GitHub Actions release run to register for {p_repo} ({p_tag})...")
                        next_pending.append((p_repo, p_dir, p_tag))
                        continue
                        
                    run_id = run_info.get("databaseId")
                    status = run_info.get("status")
                    conclusion = run_info.get("conclusion") or "pending"
                    
                    if status == "completed":
                        if conclusion == "success":
                            log_success(f"  Release run {run_id} for {p_repo} succeeded!")
                            if p_repo in PUBLISHED_CRATES:
                                crate_ver = p_tag.lstrip("v")
                                if not wait_for_crate_publication(PUBLISHED_CRATES[p_repo], crate_ver):
                                    handle_failure(
                                        state_path=state_path,
                                        failure_path=failure_path,
                                        state_data={
                                            "bump_type": bump_type,
                                            "dry_run": dry_run,
                                            "new_versions": new_versions,
                                            "current_level": tier_idx,
                                            "completed_repos": completed_repos
                                        },
                                        repo=p_repo,
                                        command="wait_for_crate_publication",
                                        error=f"Crate {PUBLISHED_CRATES[p_repo]} version {crate_ver} was not indexed on crates.io in time",
                                        level=level
                                    )
                        else:
                            log_warning(f"  Release run {run_id} for {p_repo} ended with status '{conclusion}'. Waiting for self-healing/retry/re-tagging...")
                            next_pending.append((p_repo, p_dir, p_tag))
                    else:
                        log_info(f"  Release run {run_id} for {p_repo} is currently {status} (conclusion: {conclusion})...")
                        next_pending.append((p_repo, p_dir, p_tag))
                        
                pending = next_pending
                if pending:
                    time.sleep(args.poll_interval)
                    
            log_success(f"Level {level} releases successfully completed!")
            
    log_success("\n=== SYNCHRONIZED RELEASE COMPLETE ===")
    for repo, ver in new_versions.items():
        print(f" - {repo}: v{ver}")
        
    cleanup_files(state_path, failure_path)

if __name__ == "__main__":
    main()
