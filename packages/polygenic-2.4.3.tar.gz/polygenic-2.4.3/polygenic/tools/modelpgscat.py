import argparse
import sys
import os
import re
import csv
import math
from tqdm import tqdm

import polygenic.tools.utils as utils
from polygenic.data.vcf_accessor import VcfAccessor
from polygenic.error.polygenic_exception import PolygenicException

def download_index(args):
    utils.download(args.index_url, args.index_file)
    return

def download_prs(args):
    output = None
    with open(args.index_file, 'r') as indexfile:
        firstline = next(csv.reader([indexfile.readline()]))
        phenocode_colnumber = firstline.index("Polygenic Score (PGS) ID")
        while True:
            line = indexfile.readline()
            if not line:
                break
            line = next(csv.reader([line]))
            if line[phenocode_colnumber] != args.code:
                continue
            url = f"https://ftp.ebi.ac.uk/pub/databases/spot/pgs/scores/{args.code}/ScoringFiles/Harmonized/{args.code}_hmPOS_GRCh38.txt.gz"
            output = line
    if not url is None:
        output_directory = os.path.abspath(os.path.expanduser(args.output_directory))
        output_file_name = (os.path.splitext(os.path.basename(url))[0]).lower()
        output_path = output_directory + "/" + output_file_name
        utils.download(url=url, output_path=output_path, force=False, progress=True)
        args.gwas_file = output_path
        return output_path
    return output

def get_model_info(args):
    with open(args.index_file, 'r') as indexfile:
        firstline = indexfile.readline()
        colnames = next(csv.reader([firstline]))
        phenocode_colnumber = colnames.index("Polygenic Score (PGS) ID")
        while True:
            line = indexfile.readline()
            if not line:
                break
            splitted_line = next(csv.reader([line]))
            if splitted_line[phenocode_colnumber] != args.code:
                continue
            output = dict()
            for i in range(len(colnames) - 1):
                output[colnames[i]] = splitted_line[i]
            header = utils.read_header(args.gwas_file)
            for key in header:
                output[key] = header[key]
            return output
        
    return dict()


def validate_files(args):
    if not utils.is_valid_path(args.output_directory, is_directory=True): raise PolygenicException("Output directory does not exists")
    if not utils.is_valid_path(args.gwas_file): raise PolygenicException("PRS file does not exists")
    if not utils.is_valid_path(args.ref_vcf): PolygenicException("GRCh38 reference vcf does not exists")

def get_model_type(args,metadata) -> str:
    if "Type of Variant Weight" in metadata:
        if metadata["Type of Variant Weight"].lower() == "beta":
            return "beta"
        if metadata["Type of Variant Weight"].lower() == "or":
            return "or"
        if metadata["Type of Variant Weight"].lower() == "log(or)":
            return "logor"
    if "weight_type" in metadata:
        if metadata["weight_type"].lower() == "beta":
            return "beta"
        if metadata["weight_type"].lower() == "or":
            return "or"
        if metadata["weight_type"].lower() == "log(or)":
            return "logor"
    data = utils.read_table(args.gwas_file)
    for line in data:
        if "effect_weight" in line:
            if float(line["effect_weight"]) < 0:
                return "logor"
    return "or"

def read_variants(args, model_type):
    data = utils.read_table(args.gwas_file)
    if "rsID" in data[0]:
        for line in data: line.update({"rsid": line["rsID"]}) 
    if "chr_name" in data[0]:
        for line in data: line.update({"chr": line["chr_name"]})
    if "hm_chr" in data[0]:
        for line in data: line.update({"chr": line["hm_chr"]})
    if "hm_pos" in data[0] and data[0]["hm_pos"] != "":
        for line in data: line.update({"pos": line["hm_pos"]})
    if "reference_allele" in data[0]:
        for line in data: line.update({"ref": line["reference_allele"]})
    if "other_allele" in data[0]:
        for line in data: line.update({"ref": line["other_allele"]})
    if "effect_allele" in data[0]:
        for line in data: line.update({"alt": line["effect_allele"]})
    if "effect_weight" in data[0]:
        if model_type == "beta" or model_type == "logor":
            for line in data: line.update({"beta": float(line["effect_weight"])})
        else:
            for line in data:
                line.update({"beta": math.log(float(line["effect_weight"]))})
        for line in data: line.update({"or": math.exp(line["beta"])})
    if "weight_type" in data[0]:
        for line in data: line.update({"weight_type": line["weight_type"]})
    if "allelefrequency_effect" in data[0]:
        for line in data: line.update({"af": float(line["allelefrequency_effect"])})
    if "chr" in data[0] and "pos" in data[0] and "ref" in data[0] and "alt" in data[0]:
        for line in data: line.update({"gnomadid": line['chr'] + "-" + line['pos'] + "-" + line['ref'] + "-" + line['alt']})
    return data

def run(args):
    download_index(args)
    download_prs(args)
    validate_files(args)
    description = {"info": get_model_info(args), "args":{}}
    model_type = get_model_type(args, description["info"])
    if args.parameters:
        for parameter in args.parameters:
            key, value = parameter.split(":")
            description["args"][key] = value
    data = read_variants(args, model_type) # read filtered variants
    data = utils.validate_with_source(data, args.ref_vcf, ignore_warnings = args.ignore_warnings) # validate if variants are present in hg38
    for line in data: 
        line.update({"gnomad_id": line['chr'] + "-" + line['pos'] + "-" + line['ref'] + "-" + line['alt']})
    final_beta = utils.sum_beta(data)
    data = utils.annotate_with_symbols(data, args.gene_positions)
    genes = utils.get_gene_symbols(data)
    if "af" not in data[0]:
        data = utils.annotate_with_af(data, args.af_vcf, af_field = args.af_field, default_af = 0)
    
    description["arguments"] = utils.args_to_dict(args)
    description["parameters"] = utils.simulate_parameters(data)
    description["parameters"]["number of variants"] = len(data)
    description["parameters"]["final_beta"] = final_beta
    description["pmid"] = description["info"]['Publication (PMID)']
    description["genes"] = {"symbols": genes}
    name = re.sub("[^0-9a-zA-Z]+", "_", description["info"]["Reported Trait"].lower().replace(" ", "_")) # trait name
    filename = "-".join(["pgscat", args.code, name, args.af_field]) + ".yml"
    model_path = "/".join([args.output_directory, filename]) # output path
    utils.write_model(data, description, model_path, id_field="gnomad_id", included_fields_list = ['ref', 'gnomadid', 'af']) # writing model
    return

def main(args):

    #args = parse_args(args) 
    args.logger = utils.setup_logger(args.log_file) if args.log_file else utils.setup_logger(args.output_directory + "/pgstk.log")

    try:
        run(args)
    except PolygenicException as e:
        utils.error_exit(e)

if __name__ == '__main__':
    main(sys.argv[1:])