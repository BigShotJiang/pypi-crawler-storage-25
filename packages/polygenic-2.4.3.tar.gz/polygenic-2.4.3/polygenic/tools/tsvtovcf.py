import csv
import gzip
from tqdm import tqdm

def open_file(file_path, mode='r'):
    if file_path.endswith('.gz'):
        return gzip.open(file_path, mode + 't')
    return open(file_path, mode)

def run(args):
    input_file = args.input
    max_lines = 30000000

    with open_file(input_file, 'r') as tsv_file:
        tsv_reader = csv.reader(tsv_file, delimiter='\t')
        next(tsv_reader)  # Skip header row

        with tqdm(total=max_lines, desc="Processing TSV") as pbar:
            for row in tsv_reader:
                if len(row) < 4:
                    continue  # Skip invalid rows
                pbar.update(1)

    print(f"Processing complete. Processed {pbar.n} lines from {input_file}")
