"""Batch processing manager — native and concurrent."""

from __future__ import annotations

import asyncio
import os
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any

from anymodel._types import AnyModelError
from anymodel.batch._store import BatchStore
from anymodel.providers._adapter import BatchAdapter
from anymodel.utils._adaptive_concurrency import AdaptiveConcurrencyController
from anymodel.utils._id import generate_id
from anymodel.utils._model_parser import parse_model_string

try:
    from anymodel.generated.pricing import calculate_cost as _calculate_cost
except ImportError:
    def _calculate_cost(model_id: str, prompt_tokens: int, completion_tokens: int) -> float:  # type: ignore[misc]
        return 0.0


class BatchManager:
    """Manages batch processing with native and concurrent paths."""

    def __init__(
        self,
        router: Any,
        *,
        dir: str | None = None,
        concurrency: int | str = 5,
        concurrency_max: int | None = None,
        poll_interval: float = 5.0,
        aliases: dict[str, str] | None = None,
    ) -> None:
        self._store = BatchStore(dir)
        self._router = router
        self._concurrency: int | str = concurrency
        self._concurrency_max = concurrency_max
        self._default_poll_interval = poll_interval
        self._aliases = aliases or {}
        self._batch_adapters: dict[str, BatchAdapter] = {}

    def get_store(self) -> BatchStore:
        """Expose the store for use by BatchBuilder."""
        return self._store

    def register_batch_adapter(self, provider_name: str, adapter: BatchAdapter) -> None:
        """Register a native batch adapter for a provider."""
        self._batch_adapters[provider_name] = adapter

    def _get_native_adapter(self, model: str) -> BatchAdapter | None:
        """Check if the model's provider has a native batch adapter."""
        parsed = parse_model_string(model, self._aliases)
        return self._batch_adapters.get(parsed.provider)

    @staticmethod
    def _batch_discount(batch: dict[str, Any]) -> float:
        """Return the cost multiplier for a batch.

        - native batches: 0.5 (50% off)
        - concurrent + flex: 0.5
        - concurrent + auto/None: 1.0
        """
        if batch.get("batch_mode") == "native":
            return 0.5
        if batch.get("service_tier") == "flex":
            return 0.5
        return 1.0

    async def create(self, request: dict[str, Any]) -> dict[str, Any]:
        """Create a batch. Routes to native or concurrent processing."""
        model = request["model"]
        requests = request["requests"]
        parsed = parse_model_string(model, self._aliases)
        force_mode = request.get("batch_mode")
        adapter = self._get_native_adapter(model) if force_mode != "concurrent" else None

        batch_id = generate_id("batch")
        now = datetime.now(timezone.utc).isoformat()
        batch_mode = "native" if adapter else "concurrent"

        # Resolve service_tier: options > first request item
        options = request.get("options")
        service_tier = (options or {}).get("service_tier")
        if service_tier is None and requests:
            service_tier = requests[0].get("service_tier")

        batch: dict[str, Any] = {
            "id": batch_id,
            "object": "batch",
            "status": "pending",
            "model": model,
            "provider_name": parsed.provider,
            "batch_mode": batch_mode,
            "total": len(requests),
            "completed": 0,
            "failed": 0,
            "created_at": now,
            "completed_at": None,
            "expires_at": None,
        }
        if service_tier is not None:
            batch["service_tier"] = service_tier

        await self._store.create(batch)
        await self._store.save_requests(batch_id, requests)

        if adapter:
            await self._process_native_batch(batch, adapter, requests, request.get("options"))
        else:
            # Fire off concurrent processing in the background — streams from disk
            asyncio.create_task(self._process_concurrent_batch(batch, request.get("options")))

        return batch

    async def create_and_poll(
        self,
        request: dict[str, Any],
        *,
        interval: float | None = None,
        on_progress: Callable[[dict[str, Any]], None] | None = None,
    ) -> dict[str, Any]:
        """Create a batch and poll until completion."""
        batch = await self.create(request)
        return await self.poll(batch["id"], interval=interval, on_progress=on_progress)

    async def poll(
        self,
        batch_id: str,
        *,
        interval: float | None = None,
        on_progress: Callable[[dict[str, Any]], None] | None = None,
        log_to_console: bool | None = None,
    ) -> dict[str, Any]:
        """Poll a batch until completion."""
        poll_interval = interval or self._default_poll_interval

        # Resolve console logging: explicit param > env var
        if log_to_console is None:
            env_val = os.environ.get("ANYMODEL_BATCH_POLL_LOG", "").strip().lower()
            log_to_console = env_val in ("1", "true", "yes")

        while True:
            batch = await self._store.get_meta(batch_id)
            if batch is None:
                raise AnyModelError(404, f"Batch {batch_id} not found.")

            # Sync native batch status if applicable
            if batch["batch_mode"] == "native" and batch["status"] in ("pending", "processing"):
                await self._sync_native_batch_status(batch)
                batch = await self._store.get_meta(batch_id)
                if batch is None:
                    raise AnyModelError(404, f"Batch {batch_id} not found.")

            if on_progress:
                on_progress(batch)

            if log_to_console:
                print(
                    f"[anymodel][batch.poll] id={batch['id']} status={batch['status']}"
                    f" mode={batch['batch_mode']} progress={batch['completed']}/{batch['total']}"
                    f" failed={batch['failed']}"
                )

            if batch["status"] in ("completed", "failed", "cancelled"):
                results = await self._store.get_results(batch_id)
                usage = {"total_prompt_tokens": 0, "total_completion_tokens": 0, "estimated_cost": 0.0}
                for r in results:
                    resp = r.get("response")
                    if resp and resp.get("usage"):
                        usage["total_prompt_tokens"] += resp["usage"].get("prompt_tokens", 0)
                        usage["total_completion_tokens"] += resp["usage"].get("completion_tokens", 0)
                usage["estimated_cost"] = _calculate_cost(
                    batch["model"],
                    usage["total_prompt_tokens"],
                    usage["total_completion_tokens"],
                ) * self._batch_discount(batch)
                return {
                    "id": batch_id,
                    "status": batch["status"],
                    "results": results,
                    "usage_summary": usage,
                }

            await asyncio.sleep(poll_interval)

    async def get(self, batch_id: str) -> dict[str, Any] | None:
        """Get batch metadata."""
        return await self._store.get_meta(batch_id)

    async def list(self) -> list[dict[str, Any]]:
        """List all batches."""
        ids = await self._store.list_batches()
        batches = []
        for bid in ids:
            meta = await self._store.get_meta(bid)
            if meta:
                batches.append(meta)
        return batches

    async def results(self, batch_id: str) -> dict[str, Any]:
        """Get batch results."""
        batch = await self._store.get_meta(batch_id)
        if batch is None:
            raise AnyModelError(404, f"Batch {batch_id} not found.")

        result_items = await self._store.get_results(batch_id)
        usage = {"total_prompt_tokens": 0, "total_completion_tokens": 0, "estimated_cost": 0.0}
        for r in result_items:
            resp = r.get("response")
            if resp and resp.get("usage"):
                usage["total_prompt_tokens"] += resp["usage"].get("prompt_tokens", 0)
                usage["total_completion_tokens"] += resp["usage"].get("completion_tokens", 0)
        usage["estimated_cost"] = _calculate_cost(
            batch["model"],
            usage["total_prompt_tokens"],
            usage["total_completion_tokens"],
        ) * self._batch_discount(batch)

        return {
            "id": batch_id,
            "status": batch["status"],
            "results": result_items,
            "usage_summary": usage,
        }

    async def cancel(self, batch_id: str) -> dict[str, Any]:
        """Cancel a batch."""
        batch = await self._store.get_meta(batch_id)
        if batch is None:
            raise AnyModelError(404, f"Batch {batch_id} not found.")

        # Cancel at provider for native batches
        if batch["batch_mode"] == "native":
            adapter = self._batch_adapters.get(batch["provider_name"])
            if adapter:
                provider_state = await self._store.load_provider_state(batch_id)
                if provider_state and provider_state.get("providerBatchId"):
                    try:
                        await adapter.cancel_batch(provider_state["providerBatchId"])
                    except Exception:
                        pass  # Best-effort cancellation

        batch["status"] = "cancelled"
        batch["completed_at"] = datetime.now(timezone.utc).isoformat()
        await self._store.update_meta(batch)
        return batch

    async def _process_native_batch(
        self,
        batch: dict[str, Any],
        adapter: BatchAdapter,
        requests: list[dict[str, Any]],
        options: dict[str, Any] | None,
    ) -> None:
        """Submit batch to native provider API."""
        try:
            parsed = parse_model_string(batch["model"], self._aliases)
            result = await adapter.create_batch(parsed.model, requests, options)

            await self._store.save_provider_state(batch["id"], {
                "providerBatchId": result["providerBatchId"],
                "metadata": result.get("metadata"),
            })

            batch["status"] = "processing"
            await self._store.update_meta(batch)

        except Exception:
            batch["status"] = "failed"
            batch["completed_at"] = datetime.now(timezone.utc).isoformat()
            await self._store.update_meta(batch)
            raise

    async def _sync_native_batch_status(self, batch: dict[str, Any]) -> None:
        """Poll native provider and sync status."""
        adapter = self._batch_adapters.get(batch["provider_name"])
        if not adapter:
            return

        provider_state = await self._store.load_provider_state(batch["id"])
        if not provider_state or not provider_state.get("providerBatchId"):
            return

        provider_id = provider_state["providerBatchId"]
        status = await adapter.poll_batch(provider_id)

        batch["completed"] = status.completed
        batch["failed"] = status.failed

        if status.status == "completed":
            # Download results
            results = await adapter.get_batch_results(provider_id)
            for r in results:
                await self._store.append_result(batch["id"], r)

            batch["status"] = "completed"
            batch["completed_at"] = datetime.now(timezone.utc).isoformat()
        elif status.status == "failed":
            batch["status"] = "failed"
            batch["completed_at"] = datetime.now(timezone.utc).isoformat()
        elif status.status == "cancelled":
            batch["status"] = "cancelled"
            batch["completed_at"] = datetime.now(timezone.utc).isoformat()
        else:
            batch["status"] = "processing"

        await self._store.update_meta(batch)

    def _build_concurrency_controller(self) -> AdaptiveConcurrencyController | None:
        """Build an adaptive concurrency controller if concurrency is 'auto'."""
        if self._concurrency == "auto":
            return AdaptiveConcurrencyController(
                max=self._concurrency_max or 500,
            )
        return None

    async def _process_concurrent_batch(
        self,
        batch: dict[str, Any],
        options: dict[str, Any] | None,
    ) -> None:
        """Process batch with concurrent requests. Streams from disk."""
        batch["status"] = "processing"
        await self._store.update_meta(batch)

        controller = self._build_concurrency_controller()
        fixed_concurrency = self._concurrency if isinstance(self._concurrency, int) else 5
        semaphore = asyncio.Semaphore(controller.max_concurrency if controller else fixed_concurrency)
        active: set[asyncio.Task[None]] = set()

        async def process_one(req: dict[str, Any]) -> None:
            # Respect adaptive delay if controller is active
            if controller:
                delay = controller.get_delay()
                if delay > 0:
                    await asyncio.sleep(delay / 1000.0)

            async with semaphore:
                custom_id = req.get("custom_id", generate_id("req"))
                try:
                    chat_request: dict[str, Any] = {
                        "model": batch["model"],
                        "messages": req["messages"],
                    }
                    if options:
                        chat_request.update(options)
                    for key in ("max_tokens", "temperature", "top_p", "top_k", "stop",
                                "response_format", "tools", "tool_choice", "service_tier"):
                        if key in req:
                            chat_request[key] = req[key]

                    if controller and hasattr(self._router, "complete_with_meta"):
                        result_with_meta = await self._router.complete_with_meta(chat_request)
                        result = result_with_meta["completion"]
                        controller.record_success(result_with_meta.get("meta"))
                    else:
                        result = await self._router.complete(chat_request)
                        if controller:
                            controller.record_success()

                    await self._store.append_result(batch["id"], {
                        "custom_id": custom_id,
                        "status": "success",
                        "response": result,
                        "error": None,
                    })
                    batch["completed"] += 1
                except AnyModelError as e:
                    if controller and e.code == 429:
                        retry_after = e.metadata.get("retry_after_ms") if e.metadata else None
                        controller.record_throttle(retry_after)
                    code = e.code
                    await self._store.append_result(batch["id"], {
                        "custom_id": custom_id,
                        "status": "error",
                        "response": None,
                        "error": {"code": code, "message": str(e)},
                    })
                    batch["failed"] += 1
                except Exception as e:
                    code = getattr(e, "code", 500)
                    await self._store.append_result(batch["id"], {
                        "custom_id": custom_id,
                        "status": "error",
                        "response": None,
                        "error": {"code": code, "message": str(e)},
                    })
                    batch["failed"] += 1

                await self._store.update_meta(batch)

        # Stream requests from disk instead of holding all in memory
        async for req in self._store.stream_requests(batch["id"]):
            meta = await self._store.get_meta(batch["id"])
            if meta and meta["status"] == "cancelled":
                break

            # Update semaphore limit dynamically for adaptive mode
            effective = controller.max_concurrency if controller else fixed_concurrency
            if len(active) >= effective:
                done, active_set = await asyncio.wait(active, return_when=asyncio.FIRST_COMPLETED)
                active = active_set

            task = asyncio.create_task(process_one(req))
            active.add(task)

        if active:
            await asyncio.wait(active)

        batch = await self._store.get_meta(batch["id"]) or batch
        if batch["status"] != "cancelled":
            batch["status"] = "completed" if batch["failed"] < batch["total"] else "failed"
            batch["completed_at"] = datetime.now(timezone.utc).isoformat()
            await self._store.update_meta(batch)
