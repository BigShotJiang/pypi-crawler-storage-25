"""Tests for the FastAPI app factory and server."""

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock, patch

import httpx
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pytest_httpx import HTTPXMock

from piface.server import create_app


class _FakeUpstreamWebSocket:
    def __init__(self, subprotocol: str | None) -> None:
        self.subprotocol = subprotocol
        self.sent_messages: list[str | bytes] = []
        self.closed = False

    async def send(self, data: str | bytes) -> None:
        self.sent_messages.append(data)

    async def close(self) -> None:
        self.closed = True

    def __aiter__(self) -> "_FakeUpstreamWebSocket":
        return self

    async def __anext__(self) -> str:
        # Keep the upstream-to-browser task alive until cancelled.
        await asyncio.sleep(3600)
        raise StopAsyncIteration


class _FakeConnectContext:
    def __init__(self, upstream: _FakeUpstreamWebSocket) -> None:
        self.upstream = upstream

    async def __aenter__(self) -> _FakeUpstreamWebSocket:
        return self.upstream

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None


@pytest.fixture
def state_dir(tmp_path: Path) -> Path:
    return tmp_path / "state"


@pytest.fixture(autouse=True)
def _skip_frontend_build() -> None:
    """Don't attempt real frontend builds during tests."""
    with patch("piface.server.ensure_frontend"):
        yield  # type: ignore[func-returns-value]


class TestCreateApp:
    def test_creates_fastapi_app(self, state_dir: Path) -> None:
        app = create_app(state_path=state_dir / "state.json")
        assert isinstance(app, FastAPI)

    def test_app_configures_default_direnv_behavior(self, state_dir: Path) -> None:
        app = create_app(state_path=state_dir / "state.json", use_direnv_default=False)
        assert app.state.session_manager.use_direnv_default is False

    def test_app_has_session_routes(self, state_dir: Path) -> None:
        app = create_app(state_path=state_dir / "state.json")
        paths = [route.path for route in app.routes]  # type: ignore[union-attr]
        assert "/api/sessions" in paths
        assert "/api/sessions/{piface_id}/tts" in paths
        assert "/api/audio/tts/{cache_key}.mp3" in paths
        assert "/api/fs/list" in paths
        assert "/api/fs/complete" in paths
        assert "/api/fs/file" in paths
        assert "/api/fs/raw" in paths

    def test_app_has_ws_route(self, state_dir: Path) -> None:
        app = create_app(state_path=state_dir / "state.json")
        paths = [route.path for route in app.routes]  # type: ignore[union-attr]
        assert "/ws/sessions/{session_id}" in paths

    def test_startup_restores_sessions_and_preloads_models(self, state_dir: Path) -> None:
        with (
            patch(
                "piface.server.SessionManager.restore_sessions",
                new_callable=AsyncMock,
            ) as restore_sessions,
            patch(
                "piface.server.SessionManager.preload_available_models",
                new_callable=AsyncMock,
            ) as preload_models,
        ):
            app = create_app(state_path=state_dir / "state.json")
            with TestClient(app):
                pass

        restore_sessions.assert_awaited_once()
        preload_models.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_app_health_endpoint(self, state_dir: Path) -> None:
        app = create_app(state_path=state_dir / "state.json")
        transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/api/health")
            assert resp.status_code == 200
            assert resp.json()["status"] == "ok"

    @pytest.mark.asyncio
    async def test_spa_fallback_serves_index_html(self, state_dir: Path, tmp_path: Path) -> None:
        """SPA routes like /session/xxx should serve index.html, not 404."""

        # Create a temporary static dir with an index.html
        fake_static = tmp_path / "static"
        fake_static.mkdir()
        (fake_static / "index.html").write_text("<html><body>SPA</body></html>")

        with patch("piface.server.STATIC_DIR", fake_static):
            app = create_app(state_path=state_dir / "state.json")

        transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
            # Root should work
            resp = await c.get("/")
            assert resp.status_code == 200
            assert "SPA" in resp.text

            # SPA route should also return index.html, not 404
            resp = await c.get("/session/some-uuid-here")
            assert resp.status_code == 200
            assert "SPA" in resp.text

            # API routes should still work normally
            resp = await c.get("/api/health")
            assert resp.status_code == 200
            assert resp.json()["status"] == "ok"

            # Non-matching API paths fall through to SPA (expected for catch-all)
            # Real API routes are registered before the static mount and take priority

    @pytest.mark.asyncio
    async def test_dev_mode_proxies_frontend_requests(
        self,
        state_dir: Path,
        httpx_mock: HTTPXMock,
    ) -> None:
        httpx_mock.add_response(
            method="GET",
            url="http://127.0.0.1:5173/session/demo?tab=chat",
            status_code=200,
            text="<html>vite-dev</html>",
            headers={"content-type": "text/html"},
        )

        app = create_app(state_path=state_dir / "state.json", dev=True)
        transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]

        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/session/demo", params={"tab": "chat"})

        assert resp.status_code == 200
        assert "vite-dev" in resp.text

    @pytest.mark.asyncio
    async def test_dev_mode_still_serves_api_routes_without_proxy(
        self,
        state_dir: Path,
        httpx_mock: HTTPXMock,
    ) -> None:
        app = create_app(state_path=state_dir / "state.json", dev=True)
        transport = httpx.ASGITransport(app=app)  # type: ignore[arg-type]

        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            resp = await client.get("/api/health")

        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
        assert httpx_mock.get_requests() == []


class TestDevWebSocketProxy:
    def test_dev_ws_proxy_forwards_requested_subprotocol(
        self,
        state_dir: Path,
    ) -> None:
        app = create_app(state_path=state_dir / "state.json", dev=True)

        captured: dict[str, object] = {}
        upstream = _FakeUpstreamWebSocket(subprotocol="vite-hmr")

        def fake_connect(url: str, *, subprotocols: list[str] | None = None) -> _FakeConnectContext:
            captured["url"] = url
            captured["subprotocols"] = subprotocols
            return _FakeConnectContext(upstream)

        with patch("piface.server.websockets.connect", side_effect=fake_connect):
            client = TestClient(app)
            with client.websocket_connect("/?token=test-token", subprotocols=["vite-hmr"]) as ws:
                assert ws.accepted_subprotocol == "vite-hmr"
                ws.send_text("ping")

        assert captured["url"] == "ws://127.0.0.1:5173/?token=test-token"
        assert captured["subprotocols"] == ["vite-hmr"]
        assert upstream.sent_messages == ["ping"]
        assert upstream.closed is True
