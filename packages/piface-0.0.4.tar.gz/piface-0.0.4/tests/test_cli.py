"""Tests for the CLI module."""

from typing import Any

from typer.testing import CliRunner

from piface.cli import app

runner = CliRunner()


def _stub_server_launch(monkeypatch: Any) -> dict[str, Any]:
    captured: dict[str, Any] = {}
    fake_app = object()
    captured["fake_app"] = fake_app

    def fake_create_app(**kwargs: Any) -> object:
        captured["create_app_kwargs"] = kwargs
        return fake_app

    def fake_uvicorn_run(
        app_instance: object,
        *,
        host: str,
        port: int,
        log_level: str,
    ) -> None:
        captured["uvicorn_run_kwargs"] = {
            "app_instance": app_instance,
            "host": host,
            "port": port,
            "log_level": log_level,
        }

    monkeypatch.setattr("piface.server.create_app", fake_create_app)
    monkeypatch.setattr("piface.cli.uvicorn.run", fake_uvicorn_run)
    return captured


class TestCli:
    def test_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "piface" in result.output.lower() or "serve" in result.output.lower()

    def test_serve_help(self) -> None:
        result = runner.invoke(app, ["serve", "--help"])
        assert result.exit_code == 0
        assert "--port" in result.output
        assert "--host" in result.output
        assert "--dev" in result.output
        assert "--direnv" in result.output
        assert "--no-direnv" in result.output
        assert "--speech" in result.output
        assert "--no-speech" in result.output
        assert "--speech-model" in result.output
        assert "--tts" in result.output
        assert "--no-tts" in result.output
        assert "--tts-model" in result.output
        assert "--tts-gpu" in result.output
        assert "--tts-cpu" in result.output

    def test_no_subcommand_defaults_to_serve(self, monkeypatch: Any) -> None:
        captured = _stub_server_launch(monkeypatch)

        result = runner.invoke(app, [])

        assert result.exit_code == 0
        assert captured["create_app_kwargs"] == {
            "dev": False,
            "use_direnv_default": True,
            "speech_enabled": True,
            "speech_model": "nvidia/parakeet-tdt-0.6b-v3",
            "speech_prefer_gpu": True,
            "tts_enabled": True,
            "tts_model": "tts_models/en/ljspeech/vits",
            "tts_prefer_gpu": True,
        }
        assert captured["uvicorn_run_kwargs"] == {
            "app_instance": captured["fake_app"],
            "host": "0.0.0.0",
            "port": 7832,
            "log_level": "info",
        }

    def test_no_subcommand_accepts_serve_options(self, monkeypatch: Any) -> None:
        captured = _stub_server_launch(monkeypatch)

        result = runner.invoke(
            app,
            [
                "--port",
                "9000",
                "--host",
                "127.0.0.1",
                "--dev",
                "--no-direnv",
                "--speech-model",
                "custom-stt",
                "--speech-cpu",
                "--tts-model",
                "custom-tts",
                "--tts-cpu",
            ],
        )

        assert result.exit_code == 0
        assert captured["create_app_kwargs"] == {
            "dev": True,
            "use_direnv_default": False,
            "speech_enabled": True,
            "speech_model": "custom-stt",
            "speech_prefer_gpu": False,
            "tts_enabled": True,
            "tts_model": "custom-tts",
            "tts_prefer_gpu": False,
        }
        assert captured["uvicorn_run_kwargs"] == {
            "app_instance": captured["fake_app"],
            "host": "127.0.0.1",
            "port": 9000,
            "log_level": "info",
        }
