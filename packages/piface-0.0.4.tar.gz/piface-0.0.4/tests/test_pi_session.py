"""Tests for PiSession — single pi subprocess wrapper."""

import asyncio
import sys
from pathlib import Path

import pytest

import piface.pi_session as pi_session_module
from piface.pi_session import PiSession, PiSessionConfig

# ---------------------------------------------------------------------------
# A tiny fake "pi" script that echoes events back
# ---------------------------------------------------------------------------

FAKE_PI_SCRIPT = """\
import json, sys

# Emit a ready-ish event
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    try:
        cmd = json.loads(line)
    except Exception:
        continue
    cmd_type = cmd.get("type", "")
    cmd_id = cmd.get("id")

    # Echo a response
    resp = {"type": "response", "command": cmd_type, "success": True}
    if cmd_id:
        resp["id"] = cmd_id
    sys.stdout.write(json.dumps(resp) + "\\n")
    sys.stdout.flush()

    if cmd_type == "prompt":
        # Simulate agent events
        sys.stdout.write(json.dumps({"type": "agent_start"}) + "\\n")
        sys.stdout.write(json.dumps({
            "type": "message_update",
            "message": {"role": "assistant"},
            "assistantMessageEvent": {"type": "text_delta", "delta": "Hello!"}
        }) + "\\n")
        sys.stdout.write(json.dumps({"type": "agent_end", "messages": []}) + "\\n")
        sys.stdout.flush()
    elif cmd_type == "get_state":
        resp_data = {"type": "response", "command": "get_state", "success": True,
                     "data": {"sessionFile": "/tmp/fake.jsonl", "isStreaming": False}}
        if cmd_id:
            resp_data["id"] = cmd_id
        sys.stdout.write(json.dumps(resp_data) + "\\n")
        sys.stdout.flush()
"""


@pytest.fixture
def fake_pi_script(tmp_path: Path) -> Path:
    script = tmp_path / "fake_pi.py"
    script.write_text(FAKE_PI_SCRIPT)
    return script


@pytest.fixture
def config(tmp_path: Path) -> PiSessionConfig:
    return PiSessionConfig(working_dir=str(tmp_path))


class TestPiSessionConfig:
    def test_defaults(self, tmp_path: Path) -> None:
        cfg = PiSessionConfig(working_dir=str(tmp_path))
        assert cfg.no_session is False
        assert cfg.provider == "openai-codex"
        assert cfg.model == "gpt-5.5"
        assert cfg.thinking_level == "medium"
        assert cfg.session_file is None
        assert cfg.use_direnv is True

    def test_build_args_minimal(self, tmp_path: Path) -> None:
        cfg = PiSessionConfig(working_dir=str(tmp_path))
        args = cfg.build_args()
        assert args == [
            "pi",
            "--mode",
            "rpc",
            "--provider",
            "openai-codex",
            "--model",
            "gpt-5.5",
            "--thinking",
            "medium",
        ]

    def test_build_args_full(self, tmp_path: Path) -> None:
        cfg = PiSessionConfig(
            working_dir=str(tmp_path),
            provider="anthropic",
            model="claude-sonnet-4-20250514",
            thinking_level="high",
            no_session=True,
        )
        args = cfg.build_args()
        assert "--provider" in args
        assert "anthropic" in args
        assert "--model" in args
        assert "claude-sonnet-4-20250514" in args
        assert "--thinking" in args
        assert "high" in args
        assert "--no-session" in args

    def test_build_args_with_session_file(self, tmp_path: Path) -> None:
        cfg = PiSessionConfig(
            working_dir=str(tmp_path),
            session_file="/home/user/.pi/agent/sessions/--tmp--/session.jsonl",
        )
        args = cfg.build_args()
        assert "--session" in args
        assert "/home/user/.pi/agent/sessions/--tmp--/session.jsonl" in args

    def test_build_args_no_session_flag_without_file(self, tmp_path: Path) -> None:
        cfg = PiSessionConfig(working_dir=str(tmp_path))
        assert "--session" not in cfg.build_args()


class TestPiSession:
    def test_build_command_uses_direnv_when_available(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(pi_session_module.shutil, "which", lambda _: "/usr/bin/direnv")
        config = PiSessionConfig(working_dir=str(tmp_path))
        session = PiSession(config)

        assert session._build_command() == [
            "direnv",
            "exec",
            str(tmp_path),
            "pi",
            "--mode",
            "rpc",
            "--provider",
            "openai-codex",
            "--model",
            "gpt-5.5",
            "--thinking",
            "medium",
        ]

    def test_build_command_skips_direnv_when_disabled(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(pi_session_module.shutil, "which", lambda _: "/usr/bin/direnv")
        config = PiSessionConfig(working_dir=str(tmp_path), use_direnv=False)
        session = PiSession(config)

        assert session._build_command() == [
            "pi",
            "--mode",
            "rpc",
            "--provider",
            "openai-codex",
            "--model",
            "gpt-5.5",
            "--thinking",
            "medium",
        ]

    def test_build_command_with_launch_prefix(self, tmp_path: Path) -> None:
        prefix = ["bash", "-lc", 'useaion\nexec "$@"', "bash"]
        config = PiSessionConfig(
            working_dir=str(tmp_path),
            launch_command_prefix=prefix,
        )
        session = PiSession(config)
        cmd = session._build_command()
        # launch prefix is prepended to pi args
        assert cmd[:4] == prefix
        assert "pi" in cmd[4:]
        assert "--mode" in cmd[4:]

    def test_build_command_launch_prefix_overrides_direnv(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(pi_session_module.shutil, "which", lambda _: "/usr/bin/direnv")
        prefix = ["direnv", "exec", "/tmp/ws", "bash", "-lc", 'useaion\nexec "$@"', "bash"]
        config = PiSessionConfig(
            working_dir=str(tmp_path),
            use_direnv=True,
            launch_command_prefix=prefix,
        )
        session = PiSession(config)
        cmd = session._build_command()
        # prefix takes precedence, no double-wrapping
        assert cmd[: len(prefix)] == prefix
        assert cmd.count("direnv") == 1

    @pytest.mark.asyncio
    async def test_start_and_stop(self, fake_pi_script: Path, config: PiSessionConfig) -> None:
        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(fake_pi_script)]

        await session.start()
        assert session.is_alive

        await session.stop()
        assert not session.is_alive

    @pytest.mark.asyncio
    async def test_start_raises_on_immediate_process_exit(
        self, tmp_path: Path, config: PiSessionConfig
    ) -> None:
        failing_script = tmp_path / "failing_pi.py"
        failing_script.write_text(
            "import sys\n"
            'sys.stderr.write("direnv: error /tmp/project/.envrc is blocked\\n")\n'
            "sys.stderr.flush()\n"
            "raise SystemExit(1)\n"
        )

        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(failing_script)]

        with pytest.raises(RuntimeError, match="exited immediately"):
            await session.start()

    @pytest.mark.asyncio
    async def test_send_and_receive_events(
        self, fake_pi_script: Path, config: PiSessionConfig
    ) -> None:
        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(fake_pi_script)]

        events: list[dict] = []
        session.on_event = lambda evt: events.append(evt)

        await session.start()
        await session.send({"type": "prompt", "message": "hi"})

        # Give the reader task time to process
        await asyncio.sleep(0.3)

        await session.stop()

        # Should have received: response, agent_start, message_update, agent_end
        types = [e["type"] for e in events]
        assert "response" in types
        assert "agent_start" in types
        assert "message_update" in types
        assert "agent_end" in types

    @pytest.mark.asyncio
    async def test_send_with_id(self, fake_pi_script: Path, config: PiSessionConfig) -> None:
        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(fake_pi_script)]

        events: list[dict] = []
        session.on_event = lambda evt: events.append(evt)

        await session.start()
        await session.send({"type": "abort", "id": "req-42"})
        await asyncio.sleep(0.2)
        await session.stop()

        responses = [e for e in events if e.get("type") == "response"]
        assert any(r.get("id") == "req-42" for r in responses)

    @pytest.mark.asyncio
    async def test_stop_already_stopped(self, config: PiSessionConfig) -> None:
        session = PiSession(config)
        # Should not raise
        await session.stop()

    @pytest.mark.asyncio
    async def test_process_exit_detected(
        self, fake_pi_script: Path, config: PiSessionConfig
    ) -> None:
        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(fake_pi_script)]

        await session.start()
        # Kill the process externally
        assert session._process is not None
        session._process.terminate()
        await asyncio.sleep(0.3)
        assert not session.is_alive

    @pytest.mark.asyncio
    async def test_internal_listeners_called(
        self, fake_pi_script: Path, config: PiSessionConfig
    ) -> None:
        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(fake_pi_script)]

        internal_events: list[dict] = []
        external_events: list[dict] = []

        session.add_listener(lambda evt: internal_events.append(evt))
        session.on_event = lambda evt: external_events.append(evt)

        await session.start()
        await session.send({"type": "prompt", "message": "hi"})
        await asyncio.sleep(0.3)
        await session.stop()

        # Both should receive the same events
        assert len(internal_events) > 0
        assert len(internal_events) == len(external_events)

    @pytest.mark.asyncio
    async def test_large_payload_no_crash(self, tmp_path: Path, config: PiSessionConfig) -> None:
        """Ensure lines larger than 64 KiB don't crash the read loop.

        This is a regression test for the LimitOverrunError bug where
        asyncio's default 64 KiB stream buffer caused the read loop to
        die on large pi JSON lines (e.g. file contents).
        """
        # Script that emits a single JSON line > 64 KiB
        big_script = tmp_path / "big_pi.py"
        big_script.write_text(
            "import json, sys\n"
            'data = {"type": "message_update", "big": "x" * 200_000}\n'
            'sys.stdout.write(json.dumps(data) + "\\n")\n'
            "sys.stdout.flush()\n"
        )
        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(big_script)]

        events: list[dict] = []
        session.on_event = lambda evt: events.append(evt)

        await session.start()
        # Wait for the script to emit and exit
        await asyncio.sleep(0.5)
        await session.stop()

        assert len(events) == 1
        assert events[0]["type"] == "message_update"
        assert len(events[0]["big"]) == 200_000

    @pytest.mark.asyncio
    async def test_very_large_payload_no_crash(
        self,
        tmp_path: Path,
        config: PiSessionConfig,
    ) -> None:
        """Ensure replay-sized payloads (~20 MiB) are readable.

        Replaying long sessions can exceed 16 MiB in a single JSON line.
        The read loop must still parse and dispatch the event.
        """
        huge_script = tmp_path / "huge_pi.py"
        huge_script.write_text(
            "import json, sys\n"
            "size = 20 * 1024 * 1024\n"
            "message = {'role': 'assistant', 'content': [{'type': 'text', 'text': 'x' * size}]}\n"
            "data = {'type': 'response', 'id': '__piface_replay__', 'success': True, "
            "'data': {'messages': [message]}}\n"
            "sys.stdout.write(json.dumps(data) + '\\n')\n"
            "sys.stdout.flush()\n"
        )

        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(huge_script)]

        events: list[dict] = []
        session.on_event = lambda evt: events.append(evt)

        await session.start()
        await asyncio.sleep(0.6)
        await session.stop()

        assert len(events) == 1
        assert events[0]["type"] == "response"
        assert events[0]["id"] == "__piface_replay__"
        text = events[0]["data"]["messages"][0]["content"][0]["text"]
        assert len(text) == 20 * 1024 * 1024

    @pytest.mark.asyncio
    async def test_remove_listener(self, fake_pi_script: Path, config: PiSessionConfig) -> None:
        session = PiSession(config)
        session._build_command = lambda: [sys.executable, str(fake_pi_script)]

        events: list[dict] = []

        def listener(evt: dict) -> None:
            events.append(evt)

        session.add_listener(listener)
        session.remove_listener(listener)

        await session.start()
        await session.send({"type": "prompt", "message": "hi"})
        await asyncio.sleep(0.3)
        await session.stop()

        # Should have no events since we removed the listener
        assert len(events) == 0
