from __future__ import annotations

import json
import tomllib
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

import piface
from piface.server import create_app

ROOT = Path(__file__).resolve().parents[1]


def test_project_versions_are_consistent() -> None:
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text())
    frontend_package = json.loads((ROOT / "frontend" / "package.json").read_text())

    expected = pyproject["project"]["version"]

    assert piface.__version__ == expected
    assert frontend_package["version"] == expected


def test_openapi_reports_package_version(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("piface.server.ensure_frontend", lambda: None)
    app = create_app(state_path=tmp_path / "state.json")

    with TestClient(app) as client:
        response = client.get("/openapi.json")

    assert response.status_code == 200
    assert response.json()["info"]["version"] == piface.__version__
