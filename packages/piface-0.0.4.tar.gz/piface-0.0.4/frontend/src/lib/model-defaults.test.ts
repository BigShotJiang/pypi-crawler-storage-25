import { describe, expect, it } from 'vitest';

import {
	DEFAULT_MODEL,
	DEFAULT_PROVIDER,
	resolveDefaultModel,
	resolveDefaultProvider
} from './model-defaults';

const models = [
	{ id: 'gpt-5.4-mini', name: 'GPT-5.4 Mini', provider: 'openai-codex' },
	{ id: 'gpt-5.5', name: 'GPT-5.5', provider: 'openai-codex' },
	{ id: 'claude-sonnet-4-20250514', name: 'Claude Sonnet 4', provider: 'anthropic' }
];

describe('model defaults', () => {
	it('uses a Codex model name supported by ChatGPT-backed Codex accounts', () => {
		expect(DEFAULT_PROVIDER).toBe('openai-codex');
		expect(DEFAULT_MODEL).toBe('gpt-5.5');
	});

	it('prefers gpt-5.5 when it is available for openai-codex', () => {
		expect(resolveDefaultProvider(models)).toBe('openai-codex');
		expect(resolveDefaultModel(models, 'openai-codex')).toBe('gpt-5.5');
	});

	it('uses gpt-5.5 when provider is blank but the preferred Codex model is available', () => {
		expect(resolveDefaultModel(models, '')).toBe('gpt-5.5');
	});

	it('falls back to the first available model for a provider when gpt-5.5 is unavailable', () => {
		expect(
			resolveDefaultModel([
				{ id: 'gpt-5.4-mini', name: 'GPT-5.4 Mini', provider: 'openai-codex' }
			], 'openai-codex')
		).toBe('gpt-5.4-mini');
	});

	it('falls back to the first provider when openai-codex is unavailable', () => {
		expect(resolveDefaultProvider([models[2]])).toBe('anthropic');
		expect(resolveDefaultModel([models[2]], 'anthropic')).toBe('claude-sonnet-4-20250514');
	});
});
