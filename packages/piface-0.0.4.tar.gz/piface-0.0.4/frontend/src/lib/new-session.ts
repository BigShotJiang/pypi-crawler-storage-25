import { DEFAULT_MODEL, DEFAULT_PROVIDER, DEFAULT_THINKING } from './model-defaults';

export type DirenvMode = 'default' | 'on' | 'off';

export const DEFAULT_NEW_SESSION_SHARED = true;

export interface NewSessionFormInput {
	workingDir: string;
	provider: string;
	model: string;
	thinkingLevel: string;
	sessionName: string;
	noSession: boolean;
	direnvMode: DirenvMode;
	shared: boolean;
}

export interface ExistingSessionDefaults {
	working_dir?: string | null;
	project_dir?: string | null;
	model_provider?: string | null;
	model_id?: string | null;
	thinking_level?: string | null;
	no_session?: boolean;
	use_direnv?: boolean | null;
}

export function buildCreateSessionPayload(input: NewSessionFormInput): Record<string, unknown> {
	const body: Record<string, unknown> = { working_dir: input.workingDir.trim() };

	if (input.provider.trim()) body.provider = input.provider.trim();
	if (input.model.trim()) body.model = input.model.trim();
	if (input.thinkingLevel) body.thinking_level = input.thinkingLevel;
	if (input.sessionName.trim()) body.session_name = input.sessionName.trim();
	if (input.noSession) body.no_session = true;
	if (input.shared) body.shared = true;
	if (input.direnvMode === 'on') body.use_direnv = true;
	if (input.direnvMode === 'off') body.use_direnv = false;

	return body;
}

export function buildCloneSessionPayload(
	source: ExistingSessionDefaults,
	sessionName = ''
): Record<string, unknown> {
	const workingDir = (source.project_dir ?? source.working_dir ?? '').trim();
	const provider = (source.model_provider ?? '').trim() || DEFAULT_PROVIDER;
	const model = (source.model_id ?? '').trim() || DEFAULT_MODEL;
	const thinkingLevel = (source.thinking_level ?? '').trim() || DEFAULT_THINKING;

	const body: Record<string, unknown> = {
		working_dir: workingDir,
		provider,
		model,
		thinking_level: thinkingLevel,
		shared: DEFAULT_NEW_SESSION_SHARED
	};

	if (source.no_session === true) {
		body.no_session = true;
	}
	if (typeof source.use_direnv === 'boolean') {
		body.use_direnv = source.use_direnv;
	}
	if (sessionName.trim()) {
		body.session_name = sessionName.trim();
	}

	return body;
}
