export const AWAITING_INSTRUCTIONS_SUFFIX = '(awaiting instructions)';

type SessionLike = {
	session_name?: string | null;
	working_dir?: string | null;
};

function safeTrim(value: string | null | undefined): string {
	return typeof value === 'string' ? value.trim() : '';
}

export function getSessionDisplayName(session: SessionLike | null | undefined): string {
	const byName = safeTrim(session?.session_name);
	if (byName) return byName;

	const byDir = safeTrim(session?.working_dir)
		.split('/')
		.filter(Boolean)
		.pop();
	if (byDir) return byDir;

	return 'Session';
}

export function buildSessionDocumentTitle(
	session: SessionLike | null | undefined,
	awaitingInstructions: boolean
): string {
	const base = `${getSessionDisplayName(session)} — piface`;
	return awaitingInstructions ? `${base} ${AWAITING_INSTRUCTIONS_SUFFIX}` : base;
}

type AudioContextLike = {
	currentTime: number;
	destination: unknown;
	resume?: () => Promise<void>;
	createOscillator: () => {
		type: string;
		frequency: { value: number };
		connect: (dest: unknown) => void;
		start: (when?: number) => void;
		stop: (when?: number) => void;
	};
	createGain: () => {
		gain: {
			value: number;
			setValueAtTime: (value: number, when: number) => void;
			exponentialRampToValueAtTime: (value: number, when: number) => void;
		};
		connect: (dest: unknown) => void;
	};
};

export function playCompletionDing(createAudioContext?: () => AudioContextLike | null): void {
	try {
		const fallbackFactory = () => {
			if (typeof window === 'undefined') return null;
			const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
			if (!AudioCtx) return null;
			return new AudioCtx() as AudioContextLike;
		};

		const ctx = (createAudioContext ?? fallbackFactory)();
		if (!ctx) return;

		void ctx.resume?.();

		const now = ctx.currentTime;
		const osc = ctx.createOscillator();
		const gain = ctx.createGain();
		osc.type = 'sine';
		osc.frequency.value = 880;
		gain.gain.value = 0.0001;
		gain.gain.setValueAtTime(0.0001, now);
		gain.gain.exponentialRampToValueAtTime(0.09, now + 0.02);
		gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);
		osc.connect(gain);
		gain.connect(ctx.destination);
		osc.start(now);
		osc.stop(now + 0.22);
	} catch {
		// ignore audio failures (unsupported browser, autoplay restrictions, etc.)
	}
}
