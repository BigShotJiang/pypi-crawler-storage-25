<script lang="ts">
	interface Props {
		projectDir: string;
		onclose: () => void;
	}
	let { projectDir, onclose }: Props = $props();

	let loading = $state(true);
	let saving = $state(false);
	let error = $state('');
	let saveMessage = $state('');
	let hasConfigFile = $state(false);

	// Config fields
	let mode = $state('git_worktree');
	let root = $state('~/.local/share/piface/worktrees/{project_slug}');
	let nameTemplate = $state('{session_slug}-{short_id}');
	let defaultBase = $state('current_branch');
	let branchPrefix = $state('piface');
	let autoCleanup = $state(false);

	let useDirenv = $state(true);

	let fileCopy = $state('');
	let fileSymlink = $state('');

	let bootstrapScript = $state('');
	let bootstrapShell = $state('bash');
	let bootstrapTimeout = $state(1800);
	let bootstrapUseDirenv = $state(true);

	let launchScript = $state('');
	let launchShell = $state('bash');
	let launchApplyPi = $state(true);
	let launchApplyPty = $state(true);
	let launchTimeout = $state(30);

	let createBranch = $state(true);
	let branchTemplate = $state('{branch_prefix}/{workspace_name}');
	let detach = $state(false);

	let uiLabelTemplate = $state('{session_name} [{workspace_name}]');
	let themeOverride = $state<'none' | 'light' | 'dark'>('none');
	let skinOverride = $state<
		| 'none'
		| 'default'
		| 'beos'
		| 'facebook2007'
		| 'nintendo'
		| 'nintendo-nes'
		| 'windows98'
		| 'winamp'
		| 'protoss'
		| 'terran'
		| 'zerg'
		| 'synthwave'
		| 'macos8'
	>('none');

	async function loadConfig() {
		loading = true;
		error = '';
		try {
			const res = await fetch(
				`/api/workspace/config?path=${encodeURIComponent(projectDir)}`
			);
			if (!res.ok) {
				const body = await res.json().catch(() => ({}));
				error = body.detail || `Error ${res.status}`;
				return;
			}
			const data = await res.json();
			hasConfigFile = data.has_config_file;
			applyConfig(data.config);
		} catch (e: any) {
			error = e.message || 'Failed to load config';
		} finally {
			loading = false;
		}
	}

	function applyConfig(c: any) {
		mode = c.workspace?.mode ?? 'git_worktree';
		root = c.workspace?.root ?? '~/.local/share/piface/worktrees/{project_slug}';
		nameTemplate = c.workspace?.name_template ?? '{session_slug}-{short_id}';
		defaultBase = c.workspace?.default_base ?? 'current_branch';
		branchPrefix = c.workspace?.branch_prefix ?? 'piface';
		autoCleanup = c.workspace?.auto_cleanup ?? false;

		useDirenv = c.env?.use_direnv ?? true;

		fileCopy = (c.files?.copy ?? []).join(', ');
		fileSymlink = (c.files?.symlink ?? []).join(', ');

		if (c.bootstrap) {
			bootstrapScript = c.bootstrap.script ?? '';
			bootstrapShell = c.bootstrap.shell ?? 'bash';
			bootstrapTimeout = c.bootstrap.timeout_seconds ?? 1800;
			bootstrapUseDirenv = c.bootstrap.use_direnv ?? true;
		} else {
			bootstrapScript = '';
		}

		if (c.launch) {
			launchScript = c.launch.script ?? '';
			launchShell = c.launch.shell ?? 'bash';
			const applyTo: string[] = c.launch.apply_to ?? ['pi', 'pty'];
			launchApplyPi = applyTo.includes('pi');
			launchApplyPty = applyTo.includes('pty');
			launchTimeout = c.launch.timeout_seconds ?? 30;
		} else {
			launchScript = '';
		}

		createBranch = c.git?.create_branch ?? true;
		branchTemplate = c.git?.branch_template ?? '{branch_prefix}/{workspace_name}';
		detach = c.git?.detach ?? false;

		uiLabelTemplate = c.ui?.label_template ?? '{session_name} [{workspace_name}]';
		const configuredOverride = c.ui?.theme_override;
		themeOverride =
			configuredOverride === 'light' || configuredOverride === 'dark'
				? configuredOverride
				: 'none';
		const configuredSkin = c.ui?.skin_override;
		skinOverride =
			configuredSkin === 'default' ||
			configuredSkin === 'beos' ||
			configuredSkin === 'facebook2007' ||
			configuredSkin === 'nintendo' ||
			configuredSkin === 'nintendo-nes' ||
			configuredSkin === 'windows98' ||
			configuredSkin === 'winamp' ||
			configuredSkin === 'protoss' ||
			configuredSkin === 'terran' ||
			configuredSkin === 'zerg' ||
			configuredSkin === 'synthwave' ||
			configuredSkin === 'macos8'
				? configuredSkin
				: 'none';
	}

	function buildConfig(): Record<string, any> {
		const parseCsv = (s: string) =>
			s
				.split(',')
				.map((x) => x.trim())
				.filter(Boolean);

		const config: Record<string, any> = {
			version: 1,
			workspace: {
				mode,
				root,
				name_template: nameTemplate,
				default_base: defaultBase,
				branch_prefix: branchPrefix,
				auto_cleanup: autoCleanup
			},
			env: { use_direnv: useDirenv },
			files: {
				copy: parseCsv(fileCopy),
				symlink: parseCsv(fileSymlink)
			},
			bootstrap: bootstrapScript.trim()
				? {
						shell: bootstrapShell,
						use_direnv: bootstrapUseDirenv,
						cwd: 'workspace_root',
						script: bootstrapScript,
						timeout_seconds: bootstrapTimeout
					}
				: null,
			launch: launchScript.trim()
				? {
						shell: launchShell,
						apply_to: [
							...(launchApplyPi ? ['pi'] : []),
							...(launchApplyPty ? ['pty'] : [])
						],
						script: launchScript,
						timeout_seconds: launchTimeout
					}
				: null,
			git: {
				create_branch: createBranch,
				branch_template: branchTemplate,
				detach
			},
			ui: {
				label_template: uiLabelTemplate,
				theme_override: themeOverride === 'none' ? null : themeOverride,
				skin_override: skinOverride === 'none' ? null : skinOverride
			}
		};
		return config;
	}

	async function saveConfig() {
		saving = true;
		error = '';
		saveMessage = '';
		try {
			const res = await fetch('/api/workspace/config', {
				method: 'PUT',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ path: projectDir, config: buildConfig() })
			});
			if (!res.ok) {
				const body = await res.json().catch(() => ({}));
				error = body.detail || `Error ${res.status}`;
				return;
			}
			hasConfigFile = true;
			saveMessage = 'Saved. New sessions will use this config.';
			setTimeout(() => (saveMessage = ''), 4000);
		} catch (e: any) {
			error = e.message || 'Failed to save';
		} finally {
			saving = false;
		}
	}

	// Auto-reload on window focus
	function onFocus() {
		if (!saving) loadConfig();
	}

	$effect(() => {
		loadConfig();
		window.addEventListener('focus', onFocus);
		return () => window.removeEventListener('focus', onFocus);
	});
</script>

<!-- svelte-ignore a11y_no_static_element_interactions -->
<div class="modal-overlay" onclick={onclose} onkeydown={(e) => e.key === 'Escape' && onclose()}>
	<!-- svelte-ignore a11y_no_static_element_interactions -->
	<div
		class="modal-card config-modal"
		onclick={(e) => e.stopPropagation()}
		onkeydown={(e) => e.stopPropagation()}
		role="dialog"
		aria-modal="true"
		aria-label="Project config"
		tabindex="-1"
	>
		<div class="config-header">
			<h2>Project Config</h2>
			<button class="btn-icon close-btn" onclick={onclose}>x</button>
		</div>
		<p class="config-path">{projectDir}</p>
		{#if !hasConfigFile}
			<p class="config-hint">
				No project config found. Saving will create one.
			</p>
		{/if}

		{#if loading}
			<p class="loading">Loading...</p>
		{:else}
			<form
				class="config-form"
				onsubmit={(e) => {
					e.preventDefault();
					saveConfig();
				}}
			>
				<fieldset>
					<legend>Appearance</legend>
					<label>
						<span>Session theme mode override</span>
						<select bind:value={themeOverride}>
							<option value="none">None (use browser mode)</option>
							<option value="light">Light</option>
							<option value="dark">Dark</option>
						</select>
					</label>
					<label>
						<span>Session skin override</span>
						<select bind:value={skinOverride}>
							<option value="none">None (use browser skin)</option>
							<option value="default">Default</option>
							<option value="beos">BeOS Classic</option>
							<option value="facebook2007">Facebook 2007</option>
							<option value="nintendo">Nintendo Happy</option>
							<option value="nintendo-nes">Nintendo NES</option>
							<option value="windows98">Windows 98</option>
							<option value="macos8">Mac OS 8</option>
							<option value="winamp">Winamp</option>
							<option value="protoss">Protoss</option>
							<option value="terran">Terran Industrial</option>
							<option value="zerg">Zerg Organic</option>
							<option value="synthwave">Synthwave Neon</option>
						</select>
					</label>
				</fieldset>

				<fieldset>
					<legend>Environment</legend>
					<label class="checkbox">
						<input type="checkbox" bind:checked={useDirenv} />
						<span>Use direnv</span>
					</label>
				</fieldset>

				<!-- File preparation and one-time bootstrap settings hidden for now. -->

				<fieldset>
					<legend>Launch</legend>
					<label>
						<span>Script (runs before pi/PTY on every session start)</span>
						<textarea rows="3" bind:value={launchScript} placeholder="useaion"></textarea>
					</label>
					{#if launchScript.trim()}
						<div class="inline-row">
							<label class="small">
								<span>Shell</span>
								<input type="text" bind:value={launchShell} />
							</label>
							<label class="small">
								<span>Timeout (s)</span>
								<input type="number" bind:value={launchTimeout} />
							</label>
							<label class="checkbox">
								<input type="checkbox" bind:checked={launchApplyPi} />
								<span>pi</span>
							</label>
							<label class="checkbox">
								<input type="checkbox" bind:checked={launchApplyPty} />
								<span>pty</span>
							</label>
						</div>
					{/if}
				</fieldset>

				<!-- Git isolation settings hidden for now. -->

				{#if error}
					<p class="error">{error}</p>
				{/if}
				{#if saveMessage}
					<p class="save-ok">{saveMessage}</p>
				{/if}
				<div class="config-actions">
					<button type="submit" class="btn primary" disabled={saving}>
						{saving ? 'Saving...' : 'Save'}
					</button>
					<button type="button" class="btn" onclick={onclose}>Cancel</button>
				</div>
			</form>
		{/if}
	</div>
</div>

<style>
	.modal-overlay {
		position: fixed;
		inset: 0;
		background: rgba(0, 0, 0, 0.5);
		display: flex;
		align-items: center;
		justify-content: center;
		z-index: 1000;
	}
	.config-modal {
		background: var(--bg-secondary, #1e1e1e);
		color: var(--text-primary, #e0e0e0);
		border-radius: 8px;
		padding: 1.5rem;
		width: min(640px, 90vw);
		max-height: 85vh;
		overflow-y: auto;
	}
	.config-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.config-header h2 {
		margin: 0;
		font-size: 1.2rem;
	}
	.close-btn {
		background: none;
		border: none;
		color: var(--text-secondary, #aaa);
		font-size: 1.2rem;
		cursor: pointer;
	}
	.config-path {
		font-family: monospace;
		font-size: 0.85rem;
		color: var(--text-secondary, #aaa);
		margin: 0.25rem 0 0.75rem;
	}
	.config-hint {
		font-size: 0.85rem;
		color: var(--text-secondary, #aaa);
		margin-bottom: 0.75rem;
	}
	fieldset {
		border: 1px solid var(--border-primary, #333);
		border-radius: 6px;
		padding: 0.75rem;
		margin-bottom: 0.75rem;
	}
	legend {
		font-size: 0.85rem;
		font-weight: 600;
		color: var(--text-secondary, #aaa);
		padding: 0 0.3rem;
	}
	label {
		display: flex;
		flex-direction: column;
		gap: 0.25rem;
		margin-bottom: 0.5rem;
	}
	label span {
		font-size: 0.8rem;
		color: var(--text-secondary, #aaa);
	}
	label.checkbox {
		flex-direction: row;
		align-items: center;
		gap: 0.4rem;
	}
	label.checkbox span {
		color: var(--text-primary, #e0e0e0);
	}
	input[type='text'],
	input[type='number'],
	select,
	textarea {
		background: var(--bg-tertiary, #2a2a2a);
		border: 1px solid var(--border-primary, #333);
		border-radius: 4px;
		color: var(--text-primary, #e0e0e0);
		padding: 0.4rem 0.5rem;
		font-family: monospace;
		font-size: 0.85rem;
	}
	textarea {
		resize: vertical;
	}
	.inline-row {
		display: flex;
		gap: 0.75rem;
		align-items: flex-end;
		flex-wrap: wrap;
	}
	.inline-row label.small {
		flex: 0 0 auto;
		min-width: 80px;
	}
	.inline-row label.small input {
		width: 80px;
	}
	.error {
		color: #ff6b6b;
		font-size: 0.85rem;
	}
	.save-ok {
		color: #69db7c;
		font-size: 0.85rem;
	}
	.loading {
		color: var(--text-secondary, #aaa);
	}
	.config-actions {
		display: flex;
		gap: 0.5rem;
		margin-top: 0.5rem;
	}
	.btn {
		padding: 0.4rem 1rem;
		border-radius: 4px;
		border: 1px solid var(--border-primary, #333);
		background: var(--bg-tertiary, #2a2a2a);
		color: var(--text-primary, #e0e0e0);
		cursor: pointer;
		font-size: 0.85rem;
	}
	.btn.primary {
		background: var(--accent, #4a9eff);
		color: #fff;
		border-color: var(--accent, #4a9eff);
	}
	.btn:disabled {
		opacity: 0.5;
	}
</style>
