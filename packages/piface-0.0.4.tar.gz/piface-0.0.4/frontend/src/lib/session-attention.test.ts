import { describe, expect, it, vi } from 'vitest';

import {
	AWAITING_INSTRUCTIONS_SUFFIX,
	buildSessionDocumentTitle,
	getSessionDisplayName,
	playCompletionDing
} from './session-attention';

describe('session attention helpers', () => {
	it('uses session name when available', () => {
		expect(getSessionDisplayName({ session_name: 'backend-refactor', working_dir: '/tmp/foo' })).toBe(
			'backend-refactor'
		);
	});

	it('falls back to working directory basename', () => {
		expect(getSessionDisplayName({ session_name: '', working_dir: '/Users/alex/project-a' })).toBe(
			'project-a'
		);
	});

	it('falls back to Session when metadata is missing', () => {
		expect(getSessionDisplayName(null)).toBe('Session');
		expect(getSessionDisplayName({})).toBe('Session');
	});

	it('builds the normal session title', () => {
		expect(buildSessionDocumentTitle({ session_name: 'agent-ui' }, false)).toBe('agent-ui — piface');
	});

	it('appends awaiting instructions suffix when attention is needed', () => {
		expect(buildSessionDocumentTitle({ session_name: 'agent-ui' }, true)).toBe(
			`agent-ui — piface ${AWAITING_INSTRUCTIONS_SUFFIX}`
		);
	});

	it('plays a short completion ding when an audio context is available', () => {
		const oscillator = {
			type: 'sine',
			frequency: { value: 0 },
			connect: vi.fn(),
			start: vi.fn(),
			stop: vi.fn()
		};
		const gainNode = {
			gain: {
				value: 0,
				setValueAtTime: vi.fn(),
				exponentialRampToValueAtTime: vi.fn()
			},
			connect: vi.fn()
		};
		const ctx = {
			currentTime: 10,
			destination: {},
			createOscillator: vi.fn(() => oscillator),
			createGain: vi.fn(() => gainNode),
			resume: vi.fn().mockResolvedValue(undefined)
		};

		playCompletionDing(() => ctx as any);

		expect(ctx.createOscillator).toHaveBeenCalledOnce();
		expect(ctx.createGain).toHaveBeenCalledOnce();
		expect(oscillator.connect).toHaveBeenCalledWith(gainNode);
		expect(gainNode.connect).toHaveBeenCalledWith(ctx.destination);
		expect(oscillator.start).toHaveBeenCalledWith(10);
		expect(oscillator.stop).toHaveBeenCalledWith(10.22);
	});

	it('is a no-op when no audio context factory is available', () => {
		expect(() => playCompletionDing()).not.toThrow();
		expect(() => playCompletionDing(() => null as any)).not.toThrow();
	});
});
