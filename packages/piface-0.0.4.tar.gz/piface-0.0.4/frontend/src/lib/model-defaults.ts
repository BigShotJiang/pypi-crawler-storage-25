export type PiModel = {
	id: string;
	name?: string;
	provider: string;
	[key: string]: unknown;
};

export const DEFAULT_PROVIDER = 'openai-codex';
export const DEFAULT_MODEL = 'gpt-5.5';
export const DEFAULT_THINKING = 'medium';

function validModels(models: unknown[]): PiModel[] {
	return models.filter((model): model is PiModel => {
		return (
			typeof model === 'object' &&
			model !== null &&
			typeof (model as { id?: unknown }).id === 'string' &&
			typeof (model as { provider?: unknown }).provider === 'string'
		);
	});
}

export function resolveDefaultProvider(
	models: unknown[],
	preferredProvider = DEFAULT_PROVIDER
): string {
	const providers = [...new Set(validModels(models).map((model) => model.provider))];
	if (providers.includes(preferredProvider)) return preferredProvider;
	return providers[0] ?? preferredProvider;
}

export function resolveDefaultModel(
	models: unknown[],
	provider: string,
	preferredModel = !provider || provider === DEFAULT_PROVIDER ? DEFAULT_MODEL : ''
): string {
	const available = validModels(models);
	const effectiveProvider =
		!provider && available.some((model) => model.provider === DEFAULT_PROVIDER)
			? DEFAULT_PROVIDER
			: provider;
	const candidates = available.filter(
		(model) => !effectiveProvider || model.provider === effectiveProvider
	);
	if (candidates.length === 0) {
		return preferredModel || (!provider || provider === DEFAULT_PROVIDER ? DEFAULT_MODEL : '');
	}
	if (preferredModel && candidates.some((model) => model.id === preferredModel)) {
		return preferredModel;
	}
	return candidates[0].id;
}
