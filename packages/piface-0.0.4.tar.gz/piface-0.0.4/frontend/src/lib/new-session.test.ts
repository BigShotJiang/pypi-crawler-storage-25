import { describe, expect, it } from 'vitest';

import {
	DEFAULT_NEW_SESSION_SHARED,
	buildCloneSessionPayload,
	buildCreateSessionPayload
} from './new-session';

describe('new session defaults', () => {
	it('defaults new sessions to shared directory mode', () => {
		expect(DEFAULT_NEW_SESSION_SHARED).toBe(true);
	});
});

describe('buildCreateSessionPayload', () => {
	it('omits use_direnv when direnv mode is default', () => {
		const payload = buildCreateSessionPayload({
			workingDir: '/tmp/project',
			provider: '',
			model: '',
			thinkingLevel: '',
			sessionName: '',
			noSession: false,
			direnvMode: 'default',
			shared: false
		});

		expect(payload).toEqual({ working_dir: '/tmp/project' });
	});

	it('sets use_direnv=true when mode is on', () => {
		const payload = buildCreateSessionPayload({
			workingDir: '/tmp/project',
			provider: '',
			model: '',
			thinkingLevel: '',
			sessionName: '',
			noSession: false,
			direnvMode: 'on',
			shared: false
		});

		expect(payload.use_direnv).toBe(true);
	});

	it('sets use_direnv=false when mode is off', () => {
		const payload = buildCreateSessionPayload({
			workingDir: '/tmp/project',
			provider: '',
			model: '',
			thinkingLevel: '',
			sessionName: '',
			noSession: false,
			direnvMode: 'off',
			shared: false
		});

		expect(payload.use_direnv).toBe(false);
	});

	it('sets shared=true when shared mode requested', () => {
		const payload = buildCreateSessionPayload({
			workingDir: '/tmp/project',
			provider: '',
			model: '',
			thinkingLevel: '',
			sessionName: '',
			noSession: false,
			direnvMode: 'default',
			shared: true
		});

		expect(payload.shared).toBe(true);
	});
});

describe('buildCloneSessionPayload', () => {
	it('copies session defaults including working directory', () => {
		const payload = buildCloneSessionPayload(
			{
				working_dir: '/tmp/project',
				model_provider: 'anthropic',
				model_id: 'claude-sonnet-4-20250514',
				thinking_level: 'high',
				no_session: true,
				use_direnv: false
			},
			'clone name'
		);

		expect(payload).toEqual({
			working_dir: '/tmp/project',
			provider: 'anthropic',
			model: 'claude-sonnet-4-20250514',
			thinking_level: 'high',
			no_session: true,
			use_direnv: false,
			shared: true,
			session_name: 'clone name'
		});
	});

	it('falls back to app defaults when source values are missing', () => {
		const payload = buildCloneSessionPayload({
			working_dir: '/tmp/project',
			model_provider: null,
			model_id: null,
			thinking_level: null
		});

		expect(payload).toEqual({
			working_dir: '/tmp/project',
			provider: 'openai-codex',
			model: 'gpt-5.5',
			thinking_level: 'medium',
			shared: true
		});
	});

	it('uses project_dir for clone working_dir when available', () => {
		const payload = buildCloneSessionPayload({
			working_dir: '/worktrees/proj-abc/myworkspace',
			project_dir: '/home/user/project',
			model_provider: 'anthropic',
			model_id: 'claude-sonnet-4-20250514',
			thinking_level: 'high'
		});
		expect(payload.working_dir).toBe('/home/user/project');
	});

	it('falls back to working_dir when project_dir is absent', () => {
		const payload = buildCloneSessionPayload({
			working_dir: '/tmp/project',
			model_provider: null
		});
		expect(payload.working_dir).toBe('/tmp/project');
	});
});
