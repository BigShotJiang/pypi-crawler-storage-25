import { describe, expect, it } from 'vitest';

import { getLastAssistantMessageText, parseComposerSlashCommand } from './composer-slash';

describe('parseComposerSlashCommand', () => {
	it('returns null for normal prompts and unknown slash commands', () => {
		expect(parseComposerSlashCommand('hello')).toBeNull();
		expect(parseComposerSlashCommand('/skill:foo')).toBeNull();
		expect(parseComposerSlashCommand('/copycat')).toBeNull();
		expect(parseComposerSlashCommand('/reloading')).toBeNull();
	});

	it('parses /copy', () => {
		expect(parseComposerSlashCommand('/copy')).toEqual({ kind: 'copy' });
		expect(parseComposerSlashCommand('   /copy   ')).toEqual({ kind: 'copy' });
	});

	it('parses /compact with and without custom instructions', () => {
		expect(parseComposerSlashCommand('/compact')).toEqual({ kind: 'compact' });
		expect(parseComposerSlashCommand('/compact   ')).toEqual({ kind: 'compact' });
		expect(parseComposerSlashCommand('/compact Focus on code changes')).toEqual({
			kind: 'compact',
			customInstructions: 'Focus on code changes'
		});
	});

	it('parses /reload', () => {
		expect(parseComposerSlashCommand('/reload')).toEqual({ kind: 'reload' });
		expect(parseComposerSlashCommand(' /reload ')).toEqual({ kind: 'reload' });
	});
});

describe('getLastAssistantMessageText', () => {
	it('returns the most recent assistant text message', () => {
		const text = getLastAssistantMessageText([
			{ role: 'assistant', content: 'first' },
			{ role: 'user', content: 'question' },
			{ role: 'assistant', content: 'latest' }
		]);

		expect(text).toBe('latest');
	});

	it('supports structured assistant content and skips non-assistant entries', () => {
		const text = getLastAssistantMessageText([
			{ role: 'toolResult', content: [{ type: 'text', text: 'ignore me' }] },
			{
				role: 'assistant',
				content: [
					{ type: 'thinking', thinking: 'hmm' },
					{ type: 'text', text: 'hello ' },
					{ type: 'text', text: 'world' }
				]
			}
		]);

		expect(text).toBe('hello world');
	});

	it('falls back to an earlier assistant message if the latest one has no text', () => {
		const text = getLastAssistantMessageText([
			{ role: 'assistant', content: 'copy this' },
			{ role: 'assistant', content: [{ type: 'toolCall', name: 'bash', arguments: {} }] }
		]);

		expect(text).toBe('copy this');
	});

	it('returns assistant error text when the latest assistant message failed', () => {
		const text = getLastAssistantMessageText([
			{ role: 'assistant', content: 'earlier' },
			{ role: 'assistant', content: [], errorMessage: '{"detail":"bad model"}' }
		]);

		expect(text).toBe('Model request failed: bad model');
	});

	it('returns empty string when no assistant text is available', () => {
		expect(getLastAssistantMessageText([{ role: 'user', content: 'hi' }])).toBe('');
		expect(getLastAssistantMessageText([])).toBe('');
	});
});
