export type SkinName =
	| 'default'
	| 'beos'
	| 'facebook2007'
	| 'nintendo'
	| 'nintendo-nes'
	| 'windows98'
	| 'winamp'
	| 'protoss'
	| 'terran'
	| 'zerg'
	| 'synthwave'
	| 'macos8';

export type SkinOverride = SkinName | null;

export const SKIN_STORAGE_KEY = 'piface.theme.skin';

export interface SkinStorage {
	getItem(key: string): string | null;
	setItem(key: string, value: string): void;
}

export interface SkinDocument {
	documentElement: {
		dataset: Record<string, string | undefined>;
	};
}

interface SkinOptions {
	document?: SkinDocument | null;
	storage?: SkinStorage | null;
}

let currentSkin: SkinName = 'default';
let currentOverride: SkinOverride = null;

function isSkinName(value: string | null): value is SkinName {
	return (
		value === 'default' ||
		value === 'beos' ||
		value === 'facebook2007' ||
		value === 'nintendo' ||
		value === 'nintendo-nes' ||
		value === 'windows98' ||
		value === 'winamp' ||
		value === 'protoss' ||
		value === 'terran' ||
		value === 'zerg' ||
		value === 'synthwave' ||
		value === 'macos8'
	);
}

function getBrowserDocument(): SkinDocument | null {
	if (typeof document === 'undefined') {
		return null;
	}
	return document as unknown as SkinDocument;
}

function getBrowserStorageCandidates(): SkinStorage[] {
	if (typeof window === 'undefined') {
		return [];
	}

	const storages: SkinStorage[] = [];
	try {
		storages.push(window.localStorage);
	} catch {
		// ignore
	}
	try {
		if (window.sessionStorage !== window.localStorage) {
			storages.push(window.sessionStorage);
		}
	} catch {
		// ignore
	}
	return storages;
}

function getBrowserStorage(): SkinStorage | null {
	return getBrowserStorageCandidates()[0] ?? null;
}

export function getStoredSkin(storage: SkinStorage | null = null): SkinName {
	if (storage) {
		const raw = storage.getItem(SKIN_STORAGE_KEY);
		return isSkinName(raw) ? raw : 'default';
	}

	for (const candidate of getBrowserStorageCandidates()) {
		const raw = candidate.getItem(SKIN_STORAGE_KEY);
		if (isSkinName(raw)) {
			return raw;
		}
	}

	return 'default';
}

export function applySkin(
	skin: SkinName,
	options: Pick<SkinOptions, 'document'> = {}
): SkinName {
	const doc = options.document ?? getBrowserDocument();
	if (doc) {
		doc.documentElement.dataset.skin = skin;
	}
	return skin;
}

function applyCurrentSkin(options: Pick<SkinOptions, 'document'> = {}): SkinName {
	return applySkin(currentOverride ?? currentSkin, options);
}

export function setSkin(skin: SkinName, options: SkinOptions = {}): SkinName {
	currentSkin = skin;
	const storages = options.storage ? [options.storage] : getBrowserStorageCandidates();
	for (const storage of storages) {
		try {
			storage.setItem(SKIN_STORAGE_KEY, skin);
			break;
		} catch {
			// try the next storage candidate
		}
	}
	return applyCurrentSkin(options);
}

export function setSkinOverride(
	override: SkinOverride,
	options: Pick<SkinOptions, 'document'> = {}
): SkinName {
	currentOverride = override;
	return applyCurrentSkin(options);
}

export function initSkin(options: SkinOptions = {}): SkinName {
	currentSkin = getStoredSkin(options.storage ?? null);
	applyCurrentSkin({ document: options.document });
	return currentSkin;
}
