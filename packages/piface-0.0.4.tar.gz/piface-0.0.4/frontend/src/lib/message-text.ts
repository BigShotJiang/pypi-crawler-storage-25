function getContentText(content: unknown): string {
	if (typeof content === 'string') return content;
	if (!Array.isArray(content)) return '';
	return content
		.filter((chunk) => {
			return (
				typeof chunk === 'object' &&
				chunk !== null &&
				(chunk as { type?: unknown }).type === 'text' &&
				typeof (chunk as { text?: unknown }).text === 'string'
			);
		})
		.map((chunk) => (chunk as { text: string }).text)
		.join('');
}

export function formatAssistantErrorMessage(errorMessage: unknown): string {
	if (typeof errorMessage !== 'string') return '';
	let detail = errorMessage.trim();
	if (!detail) return '';

	try {
		const parsed = JSON.parse(detail) as { detail?: unknown; error?: unknown; message?: unknown };
		if (typeof parsed.detail === 'string' && parsed.detail.trim()) {
			detail = parsed.detail.trim();
		} else if (typeof parsed.error === 'string' && parsed.error.trim()) {
			detail = parsed.error.trim();
		} else if (typeof parsed.message === 'string' && parsed.message.trim()) {
			detail = parsed.message.trim();
		}
	} catch {
		// Plain string error; use as-is.
	}

	return `Model request failed: ${detail}`;
}

export function getMessageText(message: unknown): string {
	if (typeof message !== 'object' || message === null) return '';
	const text = getContentText((message as { content?: unknown }).content);
	if (text.trim()) return text;

	if ((message as { role?: unknown }).role === 'assistant') {
		return formatAssistantErrorMessage((message as { errorMessage?: unknown }).errorMessage);
	}

	return '';
}
