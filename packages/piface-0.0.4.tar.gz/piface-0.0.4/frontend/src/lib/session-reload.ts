type FetchLike = (input: string, init?: { method?: string }) => Promise<{
	ok: boolean;
	status?: number;
	json?: () => Promise<any>;
}>;

export const RELOAD_SEMANTIC_WARNING =
	'piface /reload compatibility mode\n\n' +
	'This does not run pi\'s native interactive /reload flow.\n' +
	'Instead, piface will kill and resume this RPC session process.\n' +
	'Conversation history/session file are preserved, but in-memory runtime state is reset.\n\n' +
	'Continue?';

export type SlashReloadResult =
	| { ok: true }
	| { ok: false; skipped: 'invalid' | 'cancelled' }
	| { ok: false; error: string };

export async function restartSessionViaSlashReload(input: {
	sessionId: string | null | undefined;
	sessionStatus: string | null | undefined;
	noSession: boolean;
	confirmReload: () => boolean;
	fetchImpl?: FetchLike;
	onBeforeRestart?: () => void;
	onAfterRestart: () => Promise<void> | void;
}): Promise<SlashReloadResult> {
	const {
		sessionId,
		sessionStatus,
		noSession,
		confirmReload,
		onBeforeRestart,
		onAfterRestart
	} = input;
	const fetchImpl: FetchLike = input.fetchImpl ?? ((url, init) => fetch(url, init as RequestInit) as any);

	if (!sessionId || sessionStatus !== 'live') {
		return { ok: false, skipped: 'invalid' };
	}

	if (noSession) {
		return { ok: false, error: 'Ephemeral sessions cannot be reloaded.' };
	}

	if (!confirmReload()) {
		return { ok: false, skipped: 'cancelled' };
	}

	const killResp = await fetchImpl(`/api/sessions/${encodeURIComponent(sessionId)}/kill`, {
		method: 'POST'
	});
	if (!killResp.ok) {
		const body = await killResp.json?.().catch(() => ({}));
		return { ok: false, error: body?.detail ?? `Failed to close session (${killResp.status ?? 0}).` };
	}

	onBeforeRestart?.();

	const resumeResp = await fetchImpl(`/api/sessions/${encodeURIComponent(sessionId)}/resume`, {
		method: 'POST'
	});
	if (!resumeResp.ok) {
		const body = await resumeResp.json?.().catch(() => ({}));
		const detail = body?.detail ?? `Failed to resume session (${resumeResp.status ?? 0}).`;
		if (
			resumeResp.status === 409 &&
			typeof detail === 'string' &&
			detail.toLowerCase().includes('already live')
		) {
			await onAfterRestart();
			return { ok: true };
		}
		return { ok: false, error: detail };
	}

	await onAfterRestart();
	return { ok: true };
}
