import { describe, expect, it } from 'vitest';

import { formatAssistantErrorMessage, getMessageText } from './message-text';

describe('formatAssistantErrorMessage', () => {
	it('extracts JSON detail from pi errorMessage payloads', () => {
		expect(
			formatAssistantErrorMessage(
				'{"detail":"The \'gpt-5.5-codex\' model is not supported when using Codex with a ChatGPT account."}'
			)
		).toBe(
			"Model request failed: The 'gpt-5.5-codex' model is not supported when using Codex with a ChatGPT account."
		);
	});

	it('handles plain string errors', () => {
		expect(formatAssistantErrorMessage('network unavailable')).toBe(
			'Model request failed: network unavailable'
		);
	});
});

describe('getMessageText', () => {
	it('extracts regular text content', () => {
		expect(
			getMessageText({
				role: 'assistant',
				content: [{ type: 'text', text: 'hello' }],
				errorMessage: 'ignored'
			})
		).toBe('hello');
	});

	it('falls back to assistant errorMessage when content is empty', () => {
		expect(
			getMessageText({
				role: 'assistant',
				content: [],
				errorMessage: '{"detail":"bad model"}'
			})
		).toBe('Model request failed: bad model');
	});
});
