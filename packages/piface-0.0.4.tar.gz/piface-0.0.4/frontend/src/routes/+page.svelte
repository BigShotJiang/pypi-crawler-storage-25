<script lang="ts">
	import { onMount } from 'svelte';
	import { goto } from '$app/navigation';
	import DirBrowser from '$lib/DirBrowser.svelte';
	import {
		getDirectoryPage,
		groupSessionsByDirectory,
		SESSIONS_PER_DIRECTORY_PAGE
	} from '$lib/session-pagination';
	import { getStoredThemeMode, setThemeMode, type ThemeMode } from '$lib/theme';
	import { getStoredSkin, setSkin, type SkinName } from '$lib/skin';
	import {
		DEFAULT_NEW_SESSION_SHARED,
		buildCreateSessionPayload,
		type DirenvMode
	} from '$lib/new-session';
	import {
		DEFAULT_MODEL,
		DEFAULT_PROVIDER,
		DEFAULT_THINKING,
		resolveDefaultModel,
		resolveDefaultProvider,
		type PiModel
	} from '$lib/model-defaults';
	import { CREATE_SESSION_THINKING_LEVELS } from '$lib/thinking-levels';
	import { allowDirenvForDirectory, isDirenvBlockedError } from '$lib/direnv';
	import WorkspaceConfigModal from '$lib/WorkspaceConfigModal.svelte';

	// Session list
	let sessions: any[] = $state([]);
	let dirPages: Record<string, number> = $state({});
	let health: string = $state('…');
	let themeMode: ThemeMode = $state('auto');
	let skinName: SkinName = $state('default');

	// Models from startup cache/live sessions
	let allModels: PiModel[] = $state([]);

	// New session form
	let showForm = $state(false);
	let formDir = $state('');
	let formProvider = $state(DEFAULT_PROVIDER);
	let formModel = $state(DEFAULT_MODEL);
	let formThinking = $state(DEFAULT_THINKING);
	let providers: string[] = $derived(
		[...new Set(allModels.map((m) => m.provider))].sort()
	);
	let filteredModels: PiModel[] = $derived(
		formProvider ? allModels.filter((m) => m.provider === formProvider) : allModels
	);
	let hasModels = $derived(allModels.length > 0);
	let formName = $state('');
	let formNoSession = $state(false);
	let formShared = $state(DEFAULT_NEW_SESSION_SHARED);
	let formDirenvMode: DirenvMode = $state('default');
	let creating = $state(false);
	let error = $state('');
	let configDir: string | null = $state(null);

	function syncDirectoryPages(nextSessions: any[]) {
		const grouped = groupSessionsByDirectory(nextSessions);
		const nextPages: Record<string, number> = {};
		for (const [dir, group] of grouped) {
			const current = dirPages[dir] ?? 0;
			nextPages[dir] = getDirectoryPage(group, current, SESSIONS_PER_DIRECTORY_PAGE).page;
		}
		dirPages = nextPages;
	}

	async function refresh() {
		try {
			const s = await fetch('/api/sessions').then((r) => r.json());
			sessions = s.sessions ?? [];
			syncDirectoryPages(sessions);
		} catch {
			// ignore
		}
	}

	function applyDefaultModelSelection(models: PiModel[] = allModels) {
		formProvider = resolveDefaultProvider(models);
		formModel = resolveDefaultModel(models, formProvider);
	}

	async function fetchModels(syncDefaults = false) {
		try {
			const res = await fetch('/api/models').then((r) => r.json());
			allModels = Array.isArray(res.models) ? res.models : [];
		} catch {
			allModels = [];
		}

		if (syncDefaults) {
			applyDefaultModelSelection(allModels);
		}
	}

	onMount(async () => {
		themeMode = getStoredThemeMode();
		skinName = getStoredSkin();
		try {
			const h = await fetch('/api/health').then((r) => r.json());
			health = h.status;
		} catch {
			health = 'unreachable';
		}
		await Promise.all([refresh(), fetchModels()]);
	});

	function openForm(dir?: string) {
		formDir = dir ?? '';
		applyDefaultModelSelection();
		formThinking = DEFAULT_THINKING;
		formName = '';
		formNoSession = false;
		formShared = DEFAULT_NEW_SESSION_SHARED;
		formDirenvMode = 'default';
		showForm = true;
		void fetchModels(true); // refresh models each time form opens and sync defaults
		// Scroll the form into view after it renders
		requestAnimationFrame(() => {
			document.querySelector('.form-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
		});
	}

	async function createSession() {
		if (!formDir.trim()) {
			error = 'Working directory is required';
			return;
		}
		creating = true;
		error = '';
		try {
			const body = buildCreateSessionPayload({
				workingDir: formDir,
				provider: formProvider,
				model: formModel,
				thinkingLevel: formThinking,
				sessionName: formName,
				noSession: formNoSession,
				shared: formShared,
				direnvMode: formDirenvMode
			});

			const submitCreate = async () =>
				fetch('/api/sessions', {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(body)
				});

			let res = await submitCreate();
			if (!res.ok) {
				const e = await res.json().catch(() => ({}));
				const detail = e.detail || `Error ${res.status}`;

				if (res.status === 409 && isDirenvBlockedError(detail) && typeof window !== 'undefined') {
					const confirmed = window.confirm(
						'This directory has a blocked .envrc. Allow it in this piface environment and retry?'
					);
					if (confirmed) {
						const allow = await allowDirenvForDirectory({ workingDir: formDir.trim() });
						if (!allow.ok) {
							error = allow.error;
							return;
						}
						res = await submitCreate();
					}
				}
			}

			if (!res.ok) {
				const e = await res.json().catch(() => ({}));
				error = e.detail || `Error ${res.status}`;
				return;
			}

			const sessionData = await res.json();
			showForm = false;
			formDir = '';
			formProvider = DEFAULT_PROVIDER;
			formModel = DEFAULT_MODEL;
			formThinking = DEFAULT_THINKING;
			formName = '';
			formNoSession = false;
			formShared = DEFAULT_NEW_SESSION_SHARED;
			formDirenvMode = 'default';

			await goto(`/session/${sessionData.piface_id}`);
		} catch (e: any) {
			error = e.message || 'Failed to create session';
		} finally {
			creating = false;
		}
	}

	async function killSession(id: string) {
		await fetch(`/api/sessions/${id}/kill`, { method: 'POST' });
		await refresh();
	}

	async function resumeSession(id: string) {
		error = '';
		if (typeof window !== 'undefined') {
			const confirmed = window.confirm('Resume this archived session?');
			if (!confirmed) return;
		}

		const submitResume = async () => fetch(`/api/sessions/${id}/resume`, { method: 'POST' });
		let res = await submitResume();

		if (!res.ok) {
			const body = await res.json().catch(() => ({}));
			const detail = body.detail || `Error ${res.status}`;
			const detailLower = typeof detail === 'string' ? detail.toLowerCase() : '';

			if (res.status === 409 && detailLower.includes('already live')) {
				await goto(`/session/${id}`);
				return;
			}

			if (res.status === 409 && isDirenvBlockedError(detail)) {
				const record = sessions.find((s) => s.piface_id === id);
				const workingDir = typeof record?.working_dir === 'string' ? record.working_dir : '';
				if (!workingDir) {
					error = detail;
					return;
				}

				if (typeof window !== 'undefined') {
					const confirmed = window.confirm(
						'This directory has a blocked .envrc. Allow it in this piface environment and retry resume?'
					);
					if (!confirmed) {
						error = detail;
						return;
					}
				}

				const allow = await allowDirenvForDirectory({ workingDir });
				if (!allow.ok) {
					error = allow.error;
					return;
				}

				res = await submitResume();
			}
		}

		if (!res.ok) {
			const body = await res.json().catch(() => ({}));
			const detail = body.detail || `Error ${res.status}`;
			const detailLower = typeof detail === 'string' ? detail.toLowerCase() : '';
			error =
				res.status === 409 && detailLower.includes('ephemeral')
					? 'This session is ephemeral and cannot be resumed.'
					: detail;
			return;
		}
		await refresh();
		await goto(`/session/${id}`);
	}

	async function removeDirectory(dir: string) {
		if (confirm(`Remove ${dir} from history?`)) {
			await fetch(`/api/directories/remove`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ path: dir })
			});
			await refresh();
		}
	}

	function onProviderChange() {
		formModel = resolveDefaultModel(allModels, formProvider);
	}

	function onThemeModeChange(event: Event) {
		const mode = (event.currentTarget as HTMLSelectElement).value as ThemeMode;
		themeMode = mode;
		setThemeMode(mode);
	}

	function onSkinChange(event: Event) {
		const skin = (event.currentTarget as HTMLSelectElement).value as SkinName;
		skinName = skin;
		setSkin(skin);
	}

	function goToDirectoryPage(dir: string, group: any[], nextPage: number) {
		dirPages[dir] = getDirectoryPage(group, nextPage, SESSIONS_PER_DIRECTORY_PAGE).page;
	}

	function modelLabel(m: PiModel): string {
		return m.name || m.id;
	}
</script>

<svelte:head>
	<title>piface</title>
</svelte:head>

<main>
	<header>
		<div>
			<h1>piface</h1>
			<p class="sub">Server: <code>{health}</code></p>
		</div>
		<div class="header-actions">
			<label class="theme-picker">
				<span>Theme</span>
				<select value={themeMode} onchange={onThemeModeChange} aria-label="Theme">
					<option value="auto">Auto</option>
					<option value="light">Light</option>
					<option value="dark">Dark</option>
				</select>
			</label>
			<label class="skin-picker">
				<span>Skin</span>
				<select value={skinName} onchange={onSkinChange} aria-label="Skin">
					<option value="default">Default</option>
					<option value="beos">BeOS Classic</option>
					<option value="facebook2007">Facebook 2007</option>
					<option value="nintendo">Nintendo Happy</option>
					<option value="nintendo-nes">Nintendo NES</option>
					<option value="windows98">Windows 98</option>
					<option value="macos8">Mac OS 8</option>
					<option value="winamp">Winamp</option>
					<option value="protoss">Protoss</option>
					<option value="terran">Terran Industrial</option>
					<option value="zerg">Zerg Organic</option>
					<option value="synthwave">Synthwave Neon</option>
				</select>
			</label>
			<button class="btn primary" onclick={() => showForm ? (showForm = false) : openForm()}>
				{showForm ? 'Cancel' : '+ New Session'}
			</button>
		</div>
	</header>

	{#if showForm}
		<section class="form-section">
			<h2>New Session</h2>
			<form onsubmit={(e) => { e.preventDefault(); createSession(); }}>
				<label>
					<span>Working Directory <span class="req">*</span></span>
					<DirBrowser bind:value={formDir} placeholder="/path/to/project" />
				</label>
				<div class="row">
					<label class="half">
						<span>Provider</span>
						{#if hasModels}
							<select bind:value={formProvider} onchange={onProviderChange}>
								<option value="">Any</option>
								{#each providers as p}
									<option value={p}>{p}</option>
								{/each}
							</select>
						{:else}
							<input type="text" bind:value={formProvider} placeholder="anthropic" />
						{/if}
					</label>
					<label class="half">
						<span>Model</span>
						{#if hasModels}
							<select bind:value={formModel}>
								<option value="">Default</option>
								{#each filteredModels as m}
									<option value={m.id}>{modelLabel(m)}</option>
								{/each}
							</select>
						{:else}
							<input type="text" bind:value={formModel} placeholder="claude-sonnet-4-..." />
						{/if}
					</label>
				</div>
				{#if !hasModels}
					<p class="hint">No live sessions — type provider/model manually, or create a session first to load the model list.</p>
				{/if}
				<div class="row">
					<label class="half">
						<span>Thinking Level</span>
						<select bind:value={formThinking}>
							{#each CREATE_SESSION_THINKING_LEVELS as level}
								<option value={level}>
									{level === '' ? 'Default' : level === 'xhigh' ? 'XHigh' : level[0].toUpperCase() + level.slice(1)}
								</option>
							{/each}
						</select>
					</label>
					<label class="half">
						<span>Session Name</span>
						<input type="text" bind:value={formName} placeholder="my-feature" />
					</label>
				</div>
				<label>
					<span>Direnv</span>
					<select bind:value={formDirenvMode}>
						<option value="default">Use server default</option>
						<option value="on">Always enable direnv for this session</option>
						<option value="off">Disable direnv for this session</option>
					</select>
				</label>
				<label class="checkbox">
					<input type="checkbox" bind:checked={formNoSession} />
					<span>Ephemeral (no session persistence)</span>
				</label>
				<!-- Directory isolation option hidden for now. -->
				{#if error}
					<p class="error">{error}</p>
				{/if}
				<button type="submit" class="btn primary" disabled={creating}>
					{creating ? 'Creating…' : 'Create Session'}
				</button>
			</form>
		</section>
	{/if}

	{#if sessions.length === 0}
		<section class="empty">
			<p>No sessions yet.</p>
			<p class="muted">Click <strong>+ New Session</strong> above to start one.</p>
		</section>
	{:else}
		{#each [...groupSessionsByDirectory(sessions)] as [dir, group]}
			{@const pageData = getDirectoryPage(group, dirPages[dir] ?? 0, SESSIONS_PER_DIRECTORY_PAGE)}
			<section>
				<div class="dir-header-row">
					<h2 class="dir-header">{dir}</h2>
					<div class="dir-actions">
						{#if !group.some(s => s.status === 'live')}
							<button
								class="btn-icon btn-delete"
								title="Remove {dir} from history"
								onclick={() => removeDirectory(dir)}
							>×</button>
						{/if}
						<button
							class="btn-icon"
							title="Project config for {dir}"
							onclick={() => (configDir = dir)}
						>&#9881;</button>
						<button
							class="btn-icon"
							title="New session in {dir}"
							onclick={() => openForm(dir)}
						>+</button>
					</div>
				</div>
				<ul class="session-list">
					{#each pageData.items as s}
						<li>
							<div class="session-info">
								<a href="/session/{s.piface_id}" class="session-link" target="_blank" rel="noopener noreferrer">
									{s.session_name || dir.split('/').pop()}
								</a>
								{#if s.model_id}
									<span class="model">{s.model_id}</span>
								{/if}
								<!-- Isolated directory badge hidden for now. -->
								<span
									class="badge"
									class:live={s.status === 'live'}
									class:closed={s.status === 'closed'}
								>
									{s.status}
								</span>
							</div>
							<div class="session-actions">
								<span class="time"
									>{new Date(s.last_active).toLocaleTimeString()}</span
								>
								{#if s.status === 'live'}
									<button class="btn small danger" onclick={() => killSession(s.piface_id)}>
										Kill
									</button>
								{:else if s.status === 'closed' && !s.no_session}
									<button class="btn small" onclick={() => resumeSession(s.piface_id)}>
										Resume
									</button>
								{/if}
							</div>
						</li>
					{/each}
				</ul>
				{#if pageData.totalPages > 1}
					<div class="pagination-row">
						<button
							class="btn small"
							onclick={() => goToDirectoryPage(dir, group, pageData.page - 1)}
							disabled={!pageData.hasPrev}
						>
							Back
						</button>
						<span class="page-indicator">Page {pageData.page + 1} of {pageData.totalPages}</span>
						<button
							class="btn small"
							onclick={() => goToDirectoryPage(dir, group, pageData.page + 1)}
							disabled={!pageData.hasNext}
						>
							Forward
						</button>
					</div>
				{/if}
			</section>
		{/each}
	{/if}
</main>

{#if configDir}
	<WorkspaceConfigModal projectDir={configDir} onclose={() => (configDir = null)} />
{/if}

<style>
	:global(*),
	:global(*::before),
	:global(*::after) {
		box-sizing: border-box;
	}
	:global(body) {
		font-family: system-ui, -apple-system, sans-serif;
		background-color: var(--color-bg);
		background-image:
			radial-gradient(1000px 600px at 10% -10%, var(--skin-page-glow-1), transparent 60%),
			radial-gradient(900px 580px at 100% 0%, var(--skin-page-glow-2), transparent 62%),
			linear-gradient(
				180deg,
				color-mix(in srgb, var(--color-bg) 88%, transparent),
				color-mix(in srgb, var(--color-bg) 92%, transparent)
			),
			var(--skin-texture-page);
		background-size: auto, auto, auto, 1200px auto;
		background-repeat: no-repeat, no-repeat, no-repeat, repeat;
		background-attachment: fixed, fixed, fixed, fixed;
		color: var(--color-text);
		margin: 0;
		padding: 2rem 1rem;
		padding-left: max(1rem, env(safe-area-inset-left));
		padding-right: max(1rem, env(safe-area-inset-right));
		display: flex;
		justify-content: center;
	}
	main {
		max-width: 1100px;
		width: 100%;
	}
	header {
		display: flex;
		justify-content: space-between;
		align-items: flex-start;
		margin-bottom: 1.5rem;
		gap: 0.75rem;
	}
	h1 {
		font-size: 1.75rem;
		margin-bottom: 0.15rem;
	}
	.sub {
		color: var(--color-muted);
		font-size: 0.85rem;
	}
	code {
		background: var(--surface-2);
		padding: 0.1em 0.35em;
		border-radius: 4px;
		font-size: 0.85em;
	}
	.header-actions {
		display: flex;
		align-items: flex-end;
		gap: 0.6rem;
		flex-wrap: wrap;
		justify-content: flex-end;
	}
	.theme-picker,
	.skin-picker {
		display: flex;
		flex-direction: column;
		gap: 0.2rem;
		min-width: 6.5rem;
	}
	.theme-picker span,
	.skin-picker span {
		font-size: 0.72rem;
		color: var(--color-muted);
	}
	.theme-picker select,
	.skin-picker select {
		padding: 0.45rem 0.55rem;
		font-size: 0.85rem;
	}

	/* Buttons */
	.btn {
		padding: 0.55rem 1rem;
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		background-color: var(--surface-2);
		background-image:
			linear-gradient(
				180deg,
				color-mix(in srgb, var(--surface-2) 86%, transparent),
				color-mix(in srgb, var(--surface-2) 92%, transparent)
			),
			var(--skin-texture-button);
		background-size: auto, 1200px auto;
		background-repeat: no-repeat, repeat;
		color: var(--color-text);
		cursor: pointer;
		font-size: 0.85rem;
		transition: background 0.15s;
		white-space: nowrap;
		-webkit-tap-highlight-color: transparent;
		touch-action: manipulation;
	}
	.btn:hover {
		background: var(--surface-hover);
	}
	.btn.primary {
		background-color: var(--primary-bg);
		background-image:
			linear-gradient(
				180deg,
				color-mix(in srgb, var(--primary-bg) 88%, transparent),
				color-mix(in srgb, var(--primary-bg) 93%, transparent)
			),
			var(--skin-texture-button);
		border-color: var(--primary-border);
		color: var(--primary-text);
	}
	.btn.primary:hover {
		background-color: var(--primary-bg-hover);
	}
	.btn.primary:disabled {
		opacity: 0.5;
		cursor: not-allowed;
	}
	.btn.small {
		padding: 0.3rem 0.7rem;
		font-size: 0.8rem;
		min-height: 2rem;
	}
	.btn.danger {
		background-color: var(--danger-bg);
		background-image:
			linear-gradient(
				180deg,
				color-mix(in srgb, var(--danger-bg) 88%, transparent),
				color-mix(in srgb, var(--danger-bg) 93%, transparent)
			),
			var(--skin-texture-button);
		border-color: var(--danger-border);
		color: var(--danger-text);
	}
	.btn.danger:hover {
		background-color: var(--danger-bg-hover);
	}

	/* Sections */
	section {
		background-color: var(--surface-1);
		background-image:
			linear-gradient(
				180deg,
				color-mix(in srgb, var(--surface-1) 90%, transparent),
				color-mix(in srgb, var(--surface-1) 94%, transparent)
			),
			var(--skin-texture-panel);
		background-size: auto, 1400px auto;
		background-repeat: no-repeat, repeat;
		border: 1px solid var(--border);
		border-radius: 8px;
		padding: 1.25rem;
		margin-bottom: 1rem;
	}
	section h2 {
		font-size: 0.95rem;
		margin-bottom: 0.75rem;
	}
	.empty {
		text-align: center;
		padding: 2.5rem 1rem;
	}
	.empty .muted {
		color: var(--color-subtle);
		margin-top: 0.4rem;
		font-size: 0.9rem;
	}

	/* Form */
	.form-section form {
		display: flex;
		flex-direction: column;
		gap: 0.75rem;
	}
	label {
		display: flex;
		flex-direction: column;
		gap: 0.3rem;
	}
	label span {
		font-size: 0.8rem;
		color: var(--color-muted-2);
	}
	.req {
		color: var(--danger-text);
	}
	input[type='text'],
	select {
		padding: 0.5rem 0.6rem;
		background-color: var(--surface-2);
		background-image:
			linear-gradient(
				180deg,
				color-mix(in srgb, var(--surface-2) 92%, transparent),
				color-mix(in srgb, var(--surface-2) 96%, transparent)
			),
			var(--skin-texture-panel);
		background-size: auto, 1600px auto;
		background-repeat: no-repeat, repeat;
		border: 1px solid var(--border-strong);
		border-radius: 6px;
		color: var(--color-text);
		/* 16px prevents iOS auto-zoom on focus */
		font-size: 1rem;
		width: 100%;
	}
	input[type='text']:focus,
	select:focus {
		outline: none;
		border-color: var(--primary-text);
	}
	input[type='text']::placeholder {
		color: var(--color-muted);
		opacity: 1;
	}
	select {
		cursor: pointer;
	}
	.row {
		display: flex;
		gap: 0.75rem;
	}
	.half {
		flex: 1;
		min-width: 0;
	}
	.checkbox {
		flex-direction: row;
		align-items: center;
		gap: 0.5rem;
		min-height: 2.75rem;
	}
	.checkbox input {
		width: 1.25rem;
		height: 1.25rem;
		accent-color: var(--primary-text);
	}
	.error {
		color: var(--danger-text);
		font-size: 0.85rem;
	}
	.hint {
		color: var(--color-subtle);
		font-size: 0.8rem;
		font-style: italic;
	}

	/* Session list */
	.dir-header-row {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 0.75rem;
		gap: 0.5rem;
	}
	.dir-header {
		font-family: ui-monospace, 'SF Mono', monospace;
		font-size: 0.85rem;
		color: var(--color-muted);
		font-weight: normal;
		margin-bottom: 0;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		min-width: 0;
	}
	.btn-icon {
		width: 2rem;
		height: 2rem;
		display: flex;
		align-items: center;
		justify-content: center;
		border: 1px solid var(--border-strong);
		border-radius: 5px;
		background: var(--surface-2);
		color: var(--color-muted);
		cursor: pointer;
		font-size: 1rem;
		line-height: 1;
		padding: 0;
		flex-shrink: 0;
		transition: all 0.15s;
		-webkit-tap-highlight-color: transparent;
		touch-action: manipulation;
	}
	.btn-icon:hover {
		background: var(--primary-bg);
		border-color: var(--primary-border);
		color: var(--primary-text);
	}
	.btn-delete {
		color: var(--danger-text);
	}
	.btn-delete:hover {
		background: var(--danger-bg);
		border-color: var(--danger-border);
		color: var(--danger-text);
	}
	.dir-actions {
		display: flex;
		gap: 0.5rem;
		align-items: center;
	}
	.session-list {
		list-style: none;
		padding: 0;
		margin: 0;
	}
	.session-list li {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 0.6rem 0;
		border-top: 1px solid var(--border-soft);
		gap: 0.5rem;
	}
	.session-list li:first-child {
		border-top: none;
	}
	.session-info {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		flex-wrap: wrap;
		min-width: 0;
	}
	.session-actions {
		display: flex;
		align-items: center;
		gap: 0.5rem;
		flex-shrink: 0;
	}
	.session-link {
		color: var(--color-text);
		text-decoration: none;
		font-weight: bold;
		-webkit-tap-highlight-color: transparent;
	}
	.session-link:hover {
		color: var(--primary-text);
		text-decoration: underline;
	}
	.model {
		font-size: 0.75rem;
		color: var(--color-dim);
		font-family: ui-monospace, 'SF Mono', monospace;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		max-width: 10rem;
	}
	.time {
		font-size: 0.75rem;
		color: var(--color-faint);
		white-space: nowrap;
	}
	.badge {
		font-size: 0.7rem;
		padding: 0.1em 0.45em;
		border-radius: 4px;
		white-space: nowrap;
	}
	.badge.live {
		background: var(--success-bg);
		color: var(--success-text);
	}
	.badge.closed {
		background: var(--danger-bg);
		color: var(--danger-text);
	}
	.pagination-row {
		display: flex;
		justify-content: flex-end;
		align-items: center;
		gap: 0.5rem;
		margin-top: 0.6rem;
	}
	.page-indicator {
		font-size: 0.75rem;
		color: var(--color-faint);
		min-width: 6.5rem;
		text-align: center;
	}

	/* ---- Mobile breakpoint ---- */
	@media (max-width: 480px) {
		:global(body) {
			padding: 1rem 0.75rem;
			padding-left: max(0.75rem, env(safe-area-inset-left));
			padding-right: max(0.75rem, env(safe-area-inset-right));
		}
		h1 {
			font-size: 1.35rem;
		}
		header {
			flex-direction: column;
			align-items: stretch;
		}
		.header-actions {
			justify-content: space-between;
			align-items: center;
		}
		.theme-picker,
		.skin-picker {
			min-width: 5.5rem;
		}
		section {
			padding: 1rem;
			border-radius: 6px;
		}
		.row {
			flex-direction: column;
			gap: 0.75rem;
		}
		.model {
			max-width: 7rem;
		}
		.pagination-row {
			justify-content: center;
			flex-wrap: wrap;
		}
	}
</style>
