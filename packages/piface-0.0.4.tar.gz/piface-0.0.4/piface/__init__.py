"""Piface — web-based remote interface for pi."""

import tomllib
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

try:
    __version__ = version("piface")
except PackageNotFoundError:  # pragma: no cover - source tree without editable install
    pyproject = tomllib.loads((Path(__file__).resolve().parents[1] / "pyproject.toml").read_text())
    __version__ = pyproject["project"]["version"]
