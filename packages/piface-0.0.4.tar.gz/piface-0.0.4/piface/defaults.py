"""Shared application defaults for piface."""

DEFAULT_MODEL_PROVIDER = "openai-codex"
DEFAULT_MODEL_ID = "gpt-5.5"
DEFAULT_THINKING_LEVEL = "medium"
