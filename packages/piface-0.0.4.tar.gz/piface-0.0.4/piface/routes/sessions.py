"""REST API routes for session management and directory browsing."""

from __future__ import annotations

import asyncio
import base64
import binascii
import logging
import mimetypes
from pathlib import Path
from typing import Any, Literal
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from piface.defaults import DEFAULT_MODEL_ID, DEFAULT_MODEL_PROVIDER, DEFAULT_THINKING_LEVEL
from piface.session_manager import SessionManager
from piface.speech import SpeechTranscriptionError
from piface.state import SessionStatus
from piface.tts import SpeechSynthesisError
from piface.workspace_config import (
    WorkspaceConfig,
    load_workspace_config,
    save_workspace_config,
)

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CreateSessionRequest(BaseModel):
    working_dir: str
    provider: str | None = DEFAULT_MODEL_PROVIDER
    model: str | None = DEFAULT_MODEL_ID
    thinking_level: str | None = DEFAULT_THINKING_LEVEL
    session_name: str | None = None
    no_session: bool = False
    render_markdown: bool = True
    use_direnv: bool | None = None
    shared: bool = False


class UpdateSessionRequest(BaseModel):
    render_markdown: bool | None = None


class DirEntry(BaseModel):
    name: str
    path: str
    is_dir: bool


class RemoveDirectoryRequest(BaseModel):
    path: str


class DirenvAllowRequest(BaseModel):
    working_dir: str


class SessionHistoryResponse(BaseModel):
    messages: list[dict[str, Any]]
    source: str
    error: str | None = None


class UploadFileRequest(BaseModel):
    file_name: str
    mime_type: str
    data: str


class UploadFilesRequest(BaseModel):
    files: list[UploadFileRequest]


class TranscribeAudioRequest(BaseModel):
    audio_base64: str
    mime_type: str = "audio/webm"
    clean_with_pi: bool = False


class TranscribeAudioResponse(BaseModel):
    text: str
    raw_text: str
    cleaned: bool


class PrepareTtsRequest(BaseModel):
    text: str


class PrepareTtsResponse(BaseModel):
    cache_key: str
    audio_url: str
    media_type: str
    cached: bool


class BranchSessionRequest(BaseModel):
    entry_id: str
    session_name: str | None = None


class FilePreviewResponse(BaseModel):
    path: str
    name: str
    size: int
    mime_type: str
    kind: Literal["code", "markdown", "html", "image", "binary"]
    content: str | None = None
    raw_url: str | None = None


class GitChangedFile(BaseModel):
    path: str
    status: str
    staged: bool
    unstaged: bool
    untracked: bool
    old_path: str | None = None


class GitStatusResponse(BaseModel):
    is_repo: bool
    repo_root: str | None = None
    branch: str | None = None
    head: str | None = None
    files: list[GitChangedFile] = Field(default_factory=list)


class GitDiffResponse(BaseModel):
    is_repo: bool
    repo_root: str | None = None
    path: str | None = None
    staged: bool = False
    diff: str = ""
    truncated: bool = False


# ---------------------------------------------------------------------------
# Router factory
# ---------------------------------------------------------------------------


def _get_manager(request: Request) -> SessionManager:
    return request.app.state.session_manager


logger = logging.getLogger(__name__)

_MAX_UPLOAD_BYTES = 10 * 1024 * 1024  # 10 MiB per file
_MAX_AUDIO_BYTES = 25 * 1024 * 1024  # 25 MiB per recording
_MAX_TTS_TEXT_CHARS = 12_000
_MAX_UPLOAD_COUNT = 8
_MAX_TEXT_PREVIEW_BYTES = 512 * 1024  # 512 KiB
_MAX_RAW_PREVIEW_BYTES = 8 * 1024 * 1024  # 8 MiB
_MAX_GIT_DIFF_BYTES = 512 * 1024  # 512 KiB
_GIT_COMMAND_TIMEOUT_SECONDS = 8.0

_MARKDOWN_SUFFIXES = {".md", ".markdown", ".mdx"}
_HTML_SUFFIXES = {".html", ".htm"}
_CODELIKE_SUFFIXES = {
    ".txt",
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".ini",
    ".cfg",
    ".xml",
    ".css",
    ".scss",
    ".sql",
    ".sh",
    ".bash",
    ".zsh",
    ".go",
    ".rs",
    ".java",
    ".kt",
    ".c",
    ".h",
    ".cc",
    ".cpp",
    ".hpp",
    ".swift",
    ".rb",
    ".php",
    ".svelte",
    ".vue",
    ".lock",
    ".gitignore",
    ".dockerignore",
    ".env",
}


def _guess_mime_type(path: Path) -> str:
    mime_type, _ = mimetypes.guess_type(path.name)
    return mime_type or "application/octet-stream"


def _classify_file_kind(
    path: Path,
    mime_type: str,
) -> Literal["code", "markdown", "html", "image", "binary"]:
    suffix = path.suffix.lower()
    if mime_type.startswith("image/"):
        return "image"
    if suffix in _MARKDOWN_SUFFIXES:
        return "markdown"
    if suffix in _HTML_SUFFIXES or mime_type == "text/html":
        return "html"
    if (
        mime_type.startswith("text/")
        or path.name.lower() in _CODELIKE_SUFFIXES
        or suffix in _CODELIKE_SUFFIXES
    ):
        return "code"
    return "binary"


def _validate_file_path(path: str) -> Path:
    p = Path(path)
    if not p.is_file():
        raise HTTPException(status_code=400, detail=f"Not a file: {path}")
    return p


async def _run_command(
    command: list[str],
    *,
    cwd: str,
    timeout_seconds: float = _GIT_COMMAND_TIMEOUT_SECONDS,
) -> tuple[int, str, str]:
    process = await asyncio.create_subprocess_exec(
        *command,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=timeout_seconds)
    except TimeoutError as exc:
        process.kill()
        await process.communicate()
        raise HTTPException(status_code=504, detail="Command timed out") from exc

    return process.returncode, stdout.decode(errors="replace"), stderr.decode(errors="replace")


async def _run_git(working_dir: str, args: list[str]) -> tuple[int, str, str]:
    return await _run_command(["git", "-C", working_dir, *args], cwd=working_dir)


async def _resolve_repo_root(working_dir: str) -> Path | None:
    code, stdout, _ = await _run_git(working_dir, ["rev-parse", "--is-inside-work-tree"])
    if code != 0 or stdout.strip() != "true":
        return None

    code, stdout, stderr = await _run_git(working_dir, ["rev-parse", "--show-toplevel"])
    if code != 0:
        raise HTTPException(status_code=500, detail=stderr.strip() or "Failed to resolve repo root")
    return Path(stdout.strip())


def _parse_git_porcelain_status(output: str) -> list[GitChangedFile]:
    rows = output.split("\x00")
    if rows and rows[-1] == "":
        rows = rows[:-1]

    files: list[GitChangedFile] = []
    i = 0
    while i < len(rows):
        row = rows[i]
        i += 1
        if len(row) < 4:
            continue

        code = row[:2]
        path = row[3:]
        old_path: str | None = None

        if (code[0] in {"R", "C"} or code[1] in {"R", "C"}) and i < len(rows):
            old_path = rows[i]
            i += 1

        staged = code[0] not in {" ", "?"}
        unstaged = code[1] not in {" ", "?"}
        untracked = code == "??"

        files.append(
            GitChangedFile(
                path=path,
                status=code,
                staged=staged,
                unstaged=unstaged,
                untracked=untracked,
                old_path=old_path,
            )
        )

    return sorted(files, key=lambda item: item.path.lower())


def _normalize_git_path(repo_root: Path, path: str) -> str:
    if not path.strip():
        raise HTTPException(status_code=400, detail="Path cannot be empty")

    root = repo_root.resolve()
    requested = Path(path)
    candidate = requested if requested.is_absolute() else root / requested
    normalized = candidate.resolve()

    if not normalized.is_relative_to(root):
        raise HTTPException(status_code=400, detail="Path must stay inside the repository")

    return str(normalized.relative_to(root))


def _truncate_text_bytes(text: str, max_bytes: int) -> tuple[str, bool]:
    encoded = text.encode("utf-8")
    if len(encoded) <= max_bytes:
        return text, False
    return encoded[:max_bytes].decode("utf-8", errors="ignore"), True


def create_sessions_router() -> APIRouter:
    router = APIRouter()

    # -- Sessions --

    @router.get("/sessions")
    async def list_sessions(request: Request) -> dict:
        mgr = _get_manager(request)
        records = mgr.list_sessions()
        return {"sessions": [r.model_dump(mode="json") for r in records]}

    @router.post("/sessions", status_code=201)
    async def create_session(request: Request, body: CreateSessionRequest) -> dict:
        mgr = _get_manager(request)

        # Validate working dir
        wd = Path(body.working_dir)
        if not wd.is_dir():
            raise HTTPException(
                status_code=400,
                detail=f"Directory does not exist: {body.working_dir}",
            )

        try:
            piface_id = await mgr.create_session(
                working_dir=body.working_dir,
                provider=body.provider,
                model=body.model,
                thinking_level=body.thinking_level,
                session_name=body.session_name,
                no_session=body.no_session,
                render_markdown=body.render_markdown,
                use_direnv=body.use_direnv,
                shared=body.shared,
            )
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=500, detail="Failed to create session")
        return record.model_dump(mode="json")

    @router.post("/direnv/allow")
    async def allow_direnv(request: Request, body: DirenvAllowRequest) -> dict:
        mgr = _get_manager(request)

        wd = Path(body.working_dir)
        if not wd.is_dir():
            raise HTTPException(
                status_code=400,
                detail=f"Directory does not exist: {body.working_dir}",
            )

        try:
            await mgr.allow_direnv(body.working_dir)
        except (ValueError, RuntimeError) as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc

        return {"success": True, "working_dir": str(wd)}

    # -- Workspace config ---------------------------------------------------

    @router.get("/workspace/config")
    async def get_workspace_config(path: str) -> dict:
        p = Path(path)
        if not p.is_dir():
            raise HTTPException(
                status_code=400,
                detail=f"Directory does not exist: {path}",
            )
        try:
            config = load_workspace_config(path)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        config_path = p / ".piface" / "workspace.toml"
        return {
            "project_dir": str(p),
            "has_config_file": config_path.is_file(),
            "config": config.model_dump(mode="json", by_alias=True),
        }

    @router.put("/workspace/config")
    async def put_workspace_config(request: Request) -> dict:
        body = await request.json()
        path = body.get("path")
        config_data = body.get("config")
        if not path or not isinstance(path, str):
            raise HTTPException(status_code=400, detail="path is required")
        if not config_data or not isinstance(config_data, dict):
            raise HTTPException(status_code=400, detail="config is required")

        p = Path(path)
        if not p.is_dir():
            raise HTTPException(
                status_code=400,
                detail=f"Directory does not exist: {path}",
            )

        # Handle optional sections: if script is empty, set to None
        if "bootstrap" in config_data:
            bs = config_data["bootstrap"]
            if isinstance(bs, dict):
                script = bs.get("script")
                if not script or not script.strip():
                    config_data["bootstrap"] = None
        if "launch" in config_data:
            la = config_data["launch"]
            if isinstance(la, dict):
                script = la.get("script")
                if not script or not script.strip():
                    config_data["launch"] = None

        try:
            config = WorkspaceConfig.model_validate(config_data)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Invalid config: {exc}") from exc

        try:
            save_workspace_config(path, config)
        except OSError as exc:
            raise HTTPException(status_code=500, detail=f"Failed to write config: {exc}") from exc

        return {
            "success": True,
            "project_dir": str(p),
            "config": config.model_dump(mode="json", by_alias=True),
        }

    @router.get("/sessions/{piface_id}")
    async def get_session(request: Request, piface_id: str) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")
        return record.model_dump(mode="json")

    @router.patch("/sessions/{piface_id}")
    async def update_session(
        request: Request,
        piface_id: str,
        body: UpdateSessionRequest,
    ) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        if body.render_markdown is None:
            raise HTTPException(status_code=400, detail="No updatable fields provided")

        updated = mgr.set_render_markdown(piface_id, body.render_markdown)
        if updated is None:
            raise HTTPException(status_code=404, detail="Session not found")
        return updated.model_dump(mode="json")

    @router.get("/sessions/{piface_id}/history")
    async def get_session_history(request: Request, piface_id: str) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        if not record.session_file:
            response = SessionHistoryResponse(
                messages=[],
                source="session_file",
                error="missing_session_file",
            )
            return response.model_dump(mode="json")

        messages, error = mgr.read_history_from_session_file(record.session_file)
        response = SessionHistoryResponse(
            messages=messages,
            source="session_file",
            error=error,
        )
        return response.model_dump(mode="json")

    @router.get("/sessions/{piface_id}/fork-messages")
    async def get_fork_messages(request: Request, piface_id: str) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        try:
            messages = await mgr.get_fork_messages(piface_id)
        except ValueError as exc:
            detail = str(exc)
            status = 409 if detail in {"file_not_found", "file_read_error"} else 400
            raise HTTPException(status_code=status, detail=detail) from exc

        return {"messages": messages}

    @router.post("/sessions/{piface_id}/branch", status_code=201)
    async def branch_session(
        request: Request,
        piface_id: str,
        body: BranchSessionRequest,
    ) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        if not body.entry_id.strip():
            raise HTTPException(status_code=400, detail="entry_id is required")

        try:
            branched, selected_text, cancelled = await mgr.branch_session(
                piface_id,
                entry_id=body.entry_id.strip(),
                session_name=body.session_name,
            )
        except ValueError as exc:
            detail = str(exc)
            if detail == "Fork cancelled":
                return {"cancelled": True, "selected_text": "", "session": None}
            raise HTTPException(status_code=409, detail=detail) from exc

        return {
            "cancelled": cancelled,
            "selected_text": selected_text,
            "session": branched.model_dump(mode="json"),
        }

    @router.post("/sessions/{piface_id}/uploads")
    async def upload_session_files(
        request: Request,
        piface_id: str,
        body: UploadFilesRequest,
    ) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        if not record.session_file:
            raise HTTPException(
                status_code=409,
                detail=(
                    "Session file not available yet. Send a first prompt before uploading files."
                ),
            )

        if not body.files:
            raise HTTPException(status_code=400, detail="No files provided")

        if len(body.files) > _MAX_UPLOAD_COUNT:
            raise HTTPException(
                status_code=400,
                detail=f"Too many files. Max {_MAX_UPLOAD_COUNT} files per request.",
            )

        uploads: list[dict[str, Any]] = []
        for file in body.files:
            mime_type = file.mime_type.strip() or "application/octet-stream"

            try:
                decoded = base64.b64decode(file.data, validate=True)
            except binascii.Error as exc:
                raise HTTPException(status_code=400, detail="Invalid base64 file payload") from exc

            if len(decoded) > _MAX_UPLOAD_BYTES:
                raise HTTPException(
                    status_code=413,
                    detail=f"File too large. Max {_MAX_UPLOAD_BYTES} bytes.",
                )

            upload = mgr.create_upload(
                piface_id,
                file_name=file.file_name,
                mime_type=mime_type,
                data=decoded,
            )
            uploads.append(upload)

        return {"uploads": uploads}

    @router.post("/sessions/{piface_id}/transcribe")
    async def transcribe_audio(
        request: Request,
        piface_id: str,
        body: TranscribeAudioRequest,
    ) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")
        if record.status != SessionStatus.LIVE:
            raise HTTPException(
                status_code=409,
                detail="Speech transcription requires a live session",
            )

        transcriber = getattr(request.app.state, "speech_transcriber", None)
        if transcriber is None:
            raise HTTPException(
                status_code=503,
                detail="Speech transcription is not configured on this server",
            )

        try:
            audio_bytes = base64.b64decode(body.audio_base64, validate=True)
        except binascii.Error as exc:
            raise HTTPException(status_code=400, detail="Invalid base64 audio payload") from exc

        if not audio_bytes:
            raise HTTPException(status_code=400, detail="Audio payload is empty")
        if len(audio_bytes) > _MAX_AUDIO_BYTES:
            raise HTTPException(
                status_code=413,
                detail=f"Audio payload too large. Max {_MAX_AUDIO_BYTES} bytes.",
            )

        try:
            raw_text = (await transcriber.transcribe(audio_bytes, body.mime_type)).strip()
        except SpeechTranscriptionError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception("Unexpected speech transcription failure")
            raise HTTPException(status_code=500, detail="Speech transcription failed") from exc

        text = raw_text
        if body.clean_with_pi and raw_text:
            try:
                cleaned = (await mgr.cleanup_transcript_with_pi(piface_id, raw_text)).strip()
            except (ValueError, RuntimeError) as exc:
                raise HTTPException(status_code=502, detail=str(exc)) from exc
            text = cleaned or raw_text

        response = TranscribeAudioResponse(
            text=text,
            raw_text=raw_text,
            cleaned=body.clean_with_pi,
        )
        return response.model_dump(mode="json")

    @router.post("/sessions/{piface_id}/tts")
    async def prepare_tts_audio(
        request: Request,
        piface_id: str,
        body: PrepareTtsRequest,
    ) -> dict:
        mgr = _get_manager(request)
        if mgr.get_record(piface_id) is None:
            raise HTTPException(status_code=404, detail="Session not found")

        synthesizer = getattr(request.app.state, "tts_synthesizer", None)
        if synthesizer is None:
            raise HTTPException(
                status_code=503,
                detail="Text-to-speech is not configured on this server",
            )

        text = body.text.replace("\r\n", "\n").strip()
        if not text:
            raise HTTPException(status_code=400, detail="TTS text is empty")
        if len(text) > _MAX_TTS_TEXT_CHARS:
            raise HTTPException(
                status_code=413,
                detail=f"TTS text is too long. Max {_MAX_TTS_TEXT_CHARS} characters.",
            )

        try:
            prepared = await synthesizer.prepare(text)
        except SpeechSynthesisError as exc:
            raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
        except Exception as exc:
            logger.exception("Unexpected text-to-speech preparation failure")
            raise HTTPException(status_code=500, detail="Text-to-speech failed") from exc

        response = PrepareTtsResponse(
            cache_key=prepared.cache_key,
            audio_url=f"/api/audio/tts/{prepared.cache_key}.mp3",
            media_type=prepared.media_type,
            cached=prepared.cached,
        )
        return response.model_dump(mode="json")

    @router.get("/audio/tts/{cache_key}.mp3")
    async def get_tts_audio(request: Request, cache_key: str) -> FileResponse:
        synthesizer = getattr(request.app.state, "tts_synthesizer", None)
        if synthesizer is None:
            raise HTTPException(
                status_code=503,
                detail="Text-to-speech is not configured on this server",
            )

        prepared = synthesizer.get_cached_audio(cache_key)
        if prepared is None:
            raise HTTPException(status_code=404, detail="TTS audio not found")

        return FileResponse(
            prepared.file_path,
            media_type=prepared.media_type,
            headers={
                "Cache-Control": "public, max-age=31536000, immutable",
                "ETag": f'"{prepared.cache_key}"',
            },
        )

    @router.post("/sessions/{piface_id}/kill")
    async def kill_session(request: Request, piface_id: str) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        await mgr.kill_session(piface_id)
        record = mgr.get_record(piface_id)
        assert record is not None
        return record.model_dump(mode="json")

    @router.post("/sessions/{piface_id}/resume")
    async def resume_session(request: Request, piface_id: str) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        live_session = mgr.get_session(piface_id)
        if live_session is not None and live_session.is_alive:
            raise HTTPException(status_code=409, detail="Session is already live")

        try:
            resumed = await mgr.resume_session(piface_id)
        except (ValueError, RuntimeError) as exc:
            detail = str(exc)
            raise HTTPException(status_code=409, detail=detail) from exc

        return resumed.model_dump(mode="json")

    # -- Git diff --

    @router.get("/sessions/{piface_id}/git/status")
    async def get_git_status(request: Request, piface_id: str) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        repo_root = await _resolve_repo_root(record.effective_execution_dir)
        if repo_root is None:
            return GitStatusResponse(is_repo=False).model_dump(mode="json")

        branch_code, branch_out, _ = await _run_git(
            record.effective_execution_dir,
            ["rev-parse", "--abbrev-ref", "HEAD"],
        )
        head_code, head_out, _ = await _run_git(
            record.effective_execution_dir,
            ["rev-parse", "--short", "HEAD"],
        )
        status_code, status_out, status_err = await _run_git(
            record.effective_execution_dir,
            ["status", "--porcelain=v1", "-z"],
        )
        if status_code != 0:
            raise HTTPException(status_code=500, detail=status_err.strip() or "git status failed")

        files = _parse_git_porcelain_status(status_out)
        response = GitStatusResponse(
            is_repo=True,
            repo_root=str(repo_root),
            branch=branch_out.strip() if branch_code == 0 else None,
            head=head_out.strip() if head_code == 0 else None,
            files=files,
        )
        return response.model_dump(mode="json")

    @router.get("/sessions/{piface_id}/git/diff")
    async def get_git_diff(
        request: Request,
        piface_id: str,
        path: str | None = None,
        staged: bool = False,
    ) -> dict:
        mgr = _get_manager(request)
        record = mgr.get_record(piface_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Session not found")

        repo_root = await _resolve_repo_root(record.effective_execution_dir)
        if repo_root is None:
            return GitDiffResponse(is_repo=False, path=path, staged=staged).model_dump(mode="json")

        normalized_path: str | None = None
        if path is not None:
            normalized_path = _normalize_git_path(repo_root, path)

        args = ["diff"]
        if staged:
            args.append("--cached")
        args.extend(["--no-color", "--no-ext-diff", "--"])
        if normalized_path is not None:
            args.append(normalized_path)

        code, diff_out, diff_err = await _run_git(record.effective_execution_dir, args)
        if code != 0:
            raise HTTPException(status_code=500, detail=diff_err.strip() or "git diff failed")

        if normalized_path and not staged and not diff_out:
            absolute_path = repo_root / normalized_path
            if absolute_path.exists():
                tracked_code, _, _ = await _run_git(
                    record.effective_execution_dir,
                    ["ls-files", "--error-unmatch", "--", normalized_path],
                )
                if tracked_code != 0:
                    code, untracked_out, untracked_err = await _run_git(
                        record.effective_execution_dir,
                        [
                            "diff",
                            "--no-index",
                            "--no-color",
                            "--no-ext-diff",
                            "--",
                            "/dev/null",
                            normalized_path,
                        ],
                    )
                    if code not in {0, 1}:
                        raise HTTPException(
                            status_code=500,
                            detail=untracked_err.strip() or "git diff failed",
                        )
                    diff_out = untracked_out

        trimmed_diff, truncated = _truncate_text_bytes(diff_out, _MAX_GIT_DIFF_BYTES)
        response = GitDiffResponse(
            is_repo=True,
            repo_root=str(repo_root),
            path=normalized_path,
            staged=staged,
            diff=trimmed_diff,
            truncated=truncated,
        )
        return response.model_dump(mode="json")

    # -- Models --

    @router.get("/models")
    async def get_models(request: Request) -> dict:
        mgr = _get_manager(request)
        models = await mgr.get_available_models()
        return {"models": models}

    @router.post("/directories/remove")
    async def remove_directory(request: Request, body: RemoveDirectoryRequest) -> dict:
        mgr = _get_manager(request)
        # Close all sessions in this directory
        for record in mgr.list_sessions():
            if record.effective_project_dir == body.path or record.working_dir == body.path:
                if record.status == "live":
                    await mgr.kill_session(record.piface_id)
                # Remove from session manager's state
                mgr.remove_record(record.piface_id)
        return {"success": True, "path": body.path}

    # -- Directory browsing --

    @router.get("/fs/list")
    async def list_directory(path: str) -> dict:
        p = Path(path)
        if not p.is_dir():
            raise HTTPException(status_code=400, detail=f"Not a directory: {path}")

        entries = []
        try:
            for child in sorted(p.iterdir()):
                entries.append(
                    DirEntry(
                        name=child.name,
                        path=str(child),
                        is_dir=child.is_dir(),
                    ).model_dump()
                )
        except PermissionError:
            raise HTTPException(status_code=403, detail=f"Permission denied: {path}")
        return {"entries": entries}

    @router.get("/fs/complete")
    async def complete_directory(prefix: str) -> dict:
        p = Path(prefix)
        parent = p.parent
        partial = p.name

        if not parent.is_dir():
            return {"matches": []}

        matches = []
        try:
            for child in sorted(parent.iterdir()):
                if child.is_dir() and child.name.startswith(partial):
                    matches.append(str(child))
        except PermissionError:
            pass
        return {"matches": matches}

    @router.get("/fs/file")
    async def preview_file(path: str) -> dict:
        p = _validate_file_path(path)

        try:
            size = p.stat().st_size
            mime_type = _guess_mime_type(p)
            kind = _classify_file_kind(p, mime_type)
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=f"Permission denied: {path}") from exc

        content: str | None = None
        if kind in {"code", "markdown"}:
            if size > _MAX_TEXT_PREVIEW_BYTES:
                raise HTTPException(
                    status_code=413,
                    detail=f"File too large to preview. Max {_MAX_TEXT_PREVIEW_BYTES} bytes.",
                )
            try:
                content = p.read_text(encoding="utf-8", errors="replace")
            except PermissionError as exc:
                raise HTTPException(status_code=403, detail=f"Permission denied: {path}") from exc

        raw_url = None
        if kind in {"html", "image"}:
            raw_url = f"/api/fs/raw?path={quote(str(p))}"

        response = FilePreviewResponse(
            path=str(p),
            name=p.name,
            size=size,
            mime_type=mime_type,
            kind=kind,
            content=content,
            raw_url=raw_url,
        )
        return response.model_dump(mode="json")

    @router.get("/fs/raw")
    async def raw_file(path: str) -> FileResponse:
        p = _validate_file_path(path)

        try:
            size = p.stat().st_size
            if size > _MAX_RAW_PREVIEW_BYTES:
                raise HTTPException(
                    status_code=413,
                    detail=f"File too large to preview. Max {_MAX_RAW_PREVIEW_BYTES} bytes.",
                )
            mime_type = _guess_mime_type(p)
        except PermissionError as exc:
            raise HTTPException(status_code=403, detail=f"Permission denied: {path}") from exc

        return FileResponse(path=p, media_type=mime_type)

    return router
