import{b as r}from"./u96St577.js";var e=4;function a(o){return r(o,e)}export{a as c};
