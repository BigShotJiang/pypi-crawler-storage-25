import{_ as e,b as n}from"../chunks/DecgDgNk.js";export{e as component,n as universal};
