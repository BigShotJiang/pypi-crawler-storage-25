"""FastAPI app factory and lifecycle management."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator, Mapping
from contextlib import asynccontextmanager
from pathlib import Path

import httpx
import websockets
from fastapi import FastAPI, Request, WebSocket
from fastapi.responses import JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.responses import FileResponse
from starlette.types import Receive, Scope, Send
from starlette.websockets import WebSocketState

from piface import __version__
from piface.build import ensure_frontend
from piface.routes.sessions import create_sessions_router
from piface.routes.ws import create_ws_router
from piface.session_manager import SessionManager
from piface.speech import ParakeetTranscriber
from piface.state import default_state_path
from piface.tts import CoquiTtsSynthesizer
from piface.workspace_manager import WorkspaceManager

logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"
DEV_FRONTEND_HTTP_ORIGIN = "http://127.0.0.1:5173"
DEV_FRONTEND_WS_ORIGIN = "ws://127.0.0.1:5173"
HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
    "host",
    "content-length",
}


def create_app(
    state_path: Path | None = None,
    dev: bool = False,
    use_direnv_default: bool = True,
    speech_enabled: bool = True,
    speech_model: str = "nvidia/parakeet-tdt-0.6b-v3",
    speech_prefer_gpu: bool = True,
    tts_enabled: bool = True,
    tts_model: str = "tts_models/en/ljspeech/vits",
    tts_prefer_gpu: bool = True,
) -> FastAPI:
    """Create and configure the FastAPI application."""
    resolved_state_path = state_path or default_state_path()
    workspace_manager = WorkspaceManager()
    manager = SessionManager(
        state_path=state_path,
        use_direnv_default=use_direnv_default,
        workspace_manager=workspace_manager,
    )

    # Auto-build frontend before creating the app (non-dev mode only)
    if not dev:
        ensure_frontend()

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        logger.info("Piface starting up (state: %s)", resolved_state_path)
        await manager.restore_sessions()
        await manager.preload_available_models()
        yield
        logger.info("Piface shutting down")
        await manager.shutdown()

    app = FastAPI(
        title="Piface",
        description="Web-based remote interface for pi",
        version=__version__,
        lifespan=lifespan,
    )
    app.state.session_manager = manager
    app.state.speech_transcriber = (
        ParakeetTranscriber(model_name=speech_model, prefer_gpu=speech_prefer_gpu)
        if speech_enabled
        else None
    )
    app.state.tts_synthesizer = (
        CoquiTtsSynthesizer(
            cache_dir=resolved_state_path.parent / "tts-cache",
            model_name=tts_model,
            prefer_gpu=tts_prefer_gpu,
        )
        if tts_enabled
        else None
    )

    # Routes
    app.include_router(create_sessions_router(), prefix="/api")
    app.include_router(create_ws_router())

    @app.get("/api/health")
    async def health() -> dict:
        return {"status": "ok"}

    if dev:
        _install_dev_proxy(app)
    elif STATIC_DIR.is_dir():
        # Serve built frontend from piface/static/ with SPA fallback
        app.mount("/", SPAStaticFiles(directory=str(STATIC_DIR), html=True), name="static")

    return app


def _install_dev_proxy(app: FastAPI) -> None:
    """Install reverse proxy routes to the Vite development server."""

    @app.api_route(
        "/{full_path:path}",
        methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    )
    async def dev_proxy(full_path: str, request: Request) -> Response:
        upstream_url = _build_upstream_url(DEV_FRONTEND_HTTP_ORIGIN, full_path, request.url.query)
        headers = _strip_hop_by_hop_headers(request.headers)
        body = await request.body()

        try:
            async with httpx.AsyncClient() as client:
                upstream = await client.request(
                    request.method,
                    upstream_url,
                    headers=headers,
                    content=body,
                )
        except httpx.HTTPError:
            logger.exception("Dev HTTP proxy failed for path: %s", request.url.path)
            return JSONResponse(
                status_code=502,
                content={
                    "detail": (
                        "Unable to reach frontend dev server at "
                        f"{DEV_FRONTEND_HTTP_ORIGIN}. Is `pnpm dev` running?"
                    )
                },
            )

        response_headers = _strip_hop_by_hop_headers(upstream.headers)
        return Response(
            content=upstream.content,
            status_code=upstream.status_code,
            headers=response_headers,
        )

    @app.websocket("/{full_path:path}")
    async def dev_ws_proxy(websocket: WebSocket, full_path: str) -> None:
        upstream_url = _build_upstream_url(DEV_FRONTEND_WS_ORIGIN, full_path, websocket.url.query)
        requested_subprotocols = _parse_websocket_subprotocols(
            websocket.headers.get("sec-websocket-protocol")
        )

        try:
            async with websockets.connect(
                upstream_url,
                subprotocols=requested_subprotocols or None,
            ) as upstream:
                await websocket.accept(subprotocol=upstream.subprotocol)

                async def browser_to_upstream() -> None:
                    while True:
                        msg = await websocket.receive()
                        msg_type = msg.get("type")

                        if msg_type == "websocket.disconnect":
                            await upstream.close()
                            return

                        text = msg.get("text")
                        if text is not None:
                            await upstream.send(text)
                            continue

                        data = msg.get("bytes")
                        if data is not None:
                            await upstream.send(data)

                async def upstream_to_browser() -> None:
                    async for msg in upstream:
                        if isinstance(msg, bytes):
                            await websocket.send_bytes(msg)
                        else:
                            await websocket.send_text(msg)

                tasks = {
                    asyncio.create_task(browser_to_upstream()),
                    asyncio.create_task(upstream_to_browser()),
                }
                done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
                for task in pending:
                    task.cancel()
                await asyncio.gather(*pending, return_exceptions=True)
                await asyncio.gather(*done, return_exceptions=True)

        except Exception:
            logger.exception("Dev WebSocket proxy failed for path: %s", websocket.url.path)
            if websocket.client_state in {WebSocketState.CONNECTED, WebSocketState.CONNECTING}:
                await websocket.close(code=1011, reason="Unable to reach frontend dev server")


def _parse_websocket_subprotocols(header_value: str | None) -> list[str]:
    if not header_value:
        return []
    return [part.strip() for part in header_value.split(",") if part.strip()]


def _build_upstream_url(origin: str, path: str, query: str) -> str:
    url = f"{origin}/{path}" if path else f"{origin}/"
    return f"{url}?{query}" if query else url


def _strip_hop_by_hop_headers(headers: Mapping[str, str]) -> dict[str, str]:
    return {k: v for k, v in headers.items() if k.lower() not in HOP_BY_HOP_HEADERS}


class SPAStaticFiles(StaticFiles):
    """StaticFiles subclass that falls back to index.html for SPA routing."""

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        try:
            await super().__call__(scope, receive, send)
        except Exception:
            # If the file isn't found, serve index.html and let the SPA router handle it
            index = Path(self.directory) / "index.html"  # type: ignore[arg-type]
            if index.is_file():
                response = FileResponse(index, media_type="text/html")
                await response(scope, receive, send)
            else:
                raise
