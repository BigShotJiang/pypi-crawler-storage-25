"""CLI entry point: `piface` / `piface serve`."""

from __future__ import annotations

import logging
from typing import Annotated

import typer
import uvicorn

DEFAULT_PORT = 7832
DEFAULT_HOST = "0.0.0.0"
DEFAULT_SPEECH_MODEL = "nvidia/parakeet-tdt-0.6b-v3"
DEFAULT_TTS_MODEL = "tts_models/en/ljspeech/vits"

PortOption = Annotated[int, typer.Option(help="Server port")]
HostOption = Annotated[str, typer.Option(help="Bind address")]
DevOption = Annotated[bool, typer.Option(help="Dev mode: proxy frontend to Svelte dev server")]
DirenvOption = Annotated[
    bool,
    typer.Option(
        "--direnv/--no-direnv",
        help="Use direnv for spawned pi sessions when available",
    ),
]
SpeechOption = Annotated[
    bool,
    typer.Option(
        "--speech/--no-speech",
        help="Enable voice transcription endpoints",
    ),
]
SpeechModelOption = Annotated[
    str,
    typer.Option(help="Parakeet model name for speech transcription"),
]
SpeechGpuOption = Annotated[
    bool,
    typer.Option(
        "--speech-gpu/--speech-cpu",
        help="Prefer GPU for speech transcription when CUDA is available",
    ),
]
TtsOption = Annotated[
    bool,
    typer.Option(
        "--tts/--no-tts",
        help="Enable assistant text-to-speech endpoints",
    ),
]
TtsModelOption = Annotated[
    str,
    typer.Option(help="Coqui TTS model name for assistant speech playback"),
]
TtsGpuOption = Annotated[
    bool,
    typer.Option(
        "--tts-gpu/--tts-cpu",
        help="Prefer GPU for assistant text-to-speech when CUDA is available",
    ),
]

app = typer.Typer(name="piface", help="Web-based remote interface for pi.")


def _run_server(
    *,
    port: int,
    host: str,
    dev: bool,
    direnv: bool,
    speech: bool,
    speech_model: str,
    speech_gpu: bool,
    tts: bool,
    tts_model: str,
    tts_gpu: bool,
) -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    from piface.server import create_app

    app_instance = create_app(
        dev=dev,
        use_direnv_default=direnv,
        speech_enabled=speech,
        speech_model=speech_model,
        speech_prefer_gpu=speech_gpu,
        tts_enabled=tts,
        tts_model=tts_model,
        tts_prefer_gpu=tts_gpu,
    )
    uvicorn.run(app_instance, host=host, port=port, log_level="info")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    port: PortOption = DEFAULT_PORT,
    host: HostOption = DEFAULT_HOST,
    dev: DevOption = False,
    direnv: DirenvOption = True,
    speech: SpeechOption = True,
    speech_model: SpeechModelOption = DEFAULT_SPEECH_MODEL,
    speech_gpu: SpeechGpuOption = True,
    tts: TtsOption = True,
    tts_model: TtsModelOption = DEFAULT_TTS_MODEL,
    tts_gpu: TtsGpuOption = True,
) -> None:
    """Piface — web-based remote interface for pi."""
    if ctx.invoked_subcommand is None:
        _run_server(
            port=port,
            host=host,
            dev=dev,
            direnv=direnv,
            speech=speech,
            speech_model=speech_model,
            speech_gpu=speech_gpu,
            tts=tts,
            tts_model=tts_model,
            tts_gpu=tts_gpu,
        )


@app.command("serve")
def serve(
    port: PortOption = DEFAULT_PORT,
    host: HostOption = DEFAULT_HOST,
    dev: DevOption = False,
    direnv: DirenvOption = True,
    speech: SpeechOption = True,
    speech_model: SpeechModelOption = DEFAULT_SPEECH_MODEL,
    speech_gpu: SpeechGpuOption = True,
    tts: TtsOption = True,
    tts_model: TtsModelOption = DEFAULT_TTS_MODEL,
    tts_gpu: TtsGpuOption = True,
) -> None:
    """Start the piface server."""
    _run_server(
        port=port,
        host=host,
        dev=dev,
        direnv=direnv,
        speech=speech,
        speech_model=speech_model,
        speech_gpu=speech_gpu,
        tts=tts,
        tts_model=tts_model,
        tts_gpu=tts_gpu,
    )
