---
description: Example rule
---
