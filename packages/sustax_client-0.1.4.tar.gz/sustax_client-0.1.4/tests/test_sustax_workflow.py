import time
from pathlib import Path
from pprint import pprint
import os

import pytest

from sustax_client import SustaxClient, load_sustax_file


# TEMPORARY LOCAL TEST CREDENTIALS
# Do not commit this file with real credentials.
SUSTAX_USERNAME = os.getenv("SUSTAX_USERNAME")  # Prefer env var for safety
SUSTAX_PASSWORD = os.getenv("SUSTAX_PASSWORD")  # Prefer env var for safety


# Middle of the Atlantic Ocean
LAT = 0.0
LON = -30.0

# Small year range for lightweight tests
YEAR_FROM = 2024
YEAR_TO = 2024


def _extract_one_climate_variable_id(catalog: list) -> int:
    """
    Extract one Sustax climate variable scenario ID.

    Actual API shape:
        catalog == [
            {
                "climateVariable": "Temperature at Surface",
                "dataset": [
                    {
                        "name": "2 Metre Temperature",
                        "scenarios": [
                            {"scenario": "SSP119", "sustaxId": 604},
                            {"scenario": "SSP126", "sustaxId": 605},
                            ...
                        ],
                    },
                    ...
                ],
            },
            ...
        ]

    We return one sustaxId from the first usable dataset/scenario.
    Prefer a monthly-looking dataset if such metadata appears.
    """
    assert isinstance(catalog, list), f"Expected catalog list, got {type(catalog)}"
    assert catalog, "Catalog is empty"

    # Prefer something that looks monthly, if present.
    for climate_variable in catalog:
        assert isinstance(climate_variable, dict), (
            f"Expected catalog item dict, got {type(climate_variable)}"
        )

        datasets = climate_variable.get("dataset", [])
        assert isinstance(datasets, list), (
            f"Expected dataset list, got {type(datasets)}"
        )

        for dataset in datasets:
            if not isinstance(dataset, dict):
                continue

            text = " ".join(str(v).lower() for v in dataset.values())

            looks_monthly = (
                "monthly" in text
                or "month" in text
                or "mon" in text
            )

            if not looks_monthly:
                continue

            scenarios = dataset.get("scenarios", [])

            if not isinstance(scenarios, list):
                continue

            for scenario in scenarios:
                if isinstance(scenario, dict) and "sustaxId" in scenario:
                    return int(scenario["sustaxId"])

    # Fallback: first available scenario sustaxId.
    for climate_variable in catalog:
        if not isinstance(climate_variable, dict):
            continue

        datasets = climate_variable.get("dataset", [])

        if not isinstance(datasets, list):
            continue

        for dataset in datasets:
            if not isinstance(dataset, dict):
                continue

            scenarios = dataset.get("scenarios", [])

            if not isinstance(scenarios, list):
                continue

            for scenario in scenarios:
                if isinstance(scenario, dict) and "sustaxId" in scenario:
                    return int(scenario["sustaxId"])

    raise AssertionError("Could not extract any sustaxId from catalog")


@pytest.mark.integration
def test_authenticate_get_catalog_coordinates_and_price_request():
    """
    Safe live API workflow test.

    This test:
      - authenticates
      - gets the variable catalog
      - selects one climate variable sustaxId
      - checks nearest coordinates
      - checks price request

    This test does NOT call buy_data(), so it should not spend Sustax coins.
    """
    with SustaxClient() as sua:
        token = sua.authenticate(
            username=SUSTAX_USERNAME,
            password=SUSTAX_PASSWORD,
        )

        assert isinstance(token, str)
        assert len(token) > 20

        catalog = sua.get_variables_id()

        print("\nCatalog preview:")
        pprint(catalog[:1])

        assert isinstance(catalog, list)
        assert len(catalog) > 0

        variable_id = _extract_one_climate_variable_id(catalog)

        print("\nSelected climate variable sustaxId:")
        pprint(variable_id)

        coords = sua.get_coordinates(lat=LAT, lon=LON)

        print("\nNearest coordinate response:")
        pprint(coords)

        assert isinstance(coords, dict)
        assert len(coords) > 0

        price = sua.view_price_request(
            lat=LAT,
            lon=LON,
            year_from=YEAR_FROM,
            year_to=YEAR_TO,
            sustax_code_ids=[variable_id],
        )

        print("\nPrice response:")
        pprint(price)

        assert isinstance(price, dict)
        assert "message" in price
        assert "Grand Total (Sustax coins)" in price
        assert "separated_prices" in price


@pytest.mark.integration
def test_get_user_coins():
    """
    Safe live API test for get_user_coins().
    """
    with SustaxClient() as sua:
        sua.authenticate(
            username=SUSTAX_USERNAME,
            password=SUSTAX_PASSWORD,
        )

        coins = sua.get_user_coins()

        print("\nUser coins:")
        pprint(coins)

        assert isinstance(coins, int)
        assert coins >= 0


def test_requires_authentication_before_api_calls():
    """
    Unit-style test: confirms methods protected by @_require_auth
    raise RuntimeError before authentication.
    """
    client = SustaxClient()

    with pytest.raises(RuntimeError, match="Authentication required"):
        client.get_variables_id()

    with pytest.raises(RuntimeError, match="Authentication required"):
        client.get_coordinates(lat=LAT, lon=LON)

    with pytest.raises(RuntimeError, match="Authentication required"):
        client.get_user_coins()

    client.close()


def test_location_payload_for_point_of_interest():
    """
    Unit-style test for POI payload construction.
    """
    client = SustaxClient()

    payload = client._build_location_payload(lat=LAT, lon=LON)

    assert payload == {
        "lat": float(LAT),
        "lon": float(LON),
    }

    client.close()


def test_location_payload_for_region_of_interest():
    """
    Unit-style test for ROI payload construction.

    Input lat/lon order should be normalized:
      - lat sorted reverse=True -> north then south
      - lon sorted ascending -> west then east
    """
    client = SustaxClient()

    payload = client._build_location_payload(
        lat=[-1.0, 1.0],
        lon=[-31.0, -29.0],
    )

    assert payload == {
        "lat": 1.0,
        "lon": -31.0,
        "lat2": -1.0,
        "lon2": -29.0,
    }

    client.close()


def test_location_payload_for_postal_code():
    """
    Unit-style test for postal-code payload.
    """
    client = SustaxClient()

    payload = client._build_location_payload(
        postal_code=" 12345 ",
        country="uk",
    )

    assert payload == {
        "postalCode": "12345",
        "country": "GB",
    }

    client.close()


def test_location_payload_rejects_missing_location():
    client = SustaxClient()

    with pytest.raises(Exception):
        client._build_location_payload()

    client.close()


def test_location_payload_rejects_multiple_location_methods():
    client = SustaxClient()

    with pytest.raises(ValueError, match="Specify exactly one location method"):
        client._build_location_payload(
            lat=LAT,
            lon=LON,
            postal_code="12345",
            country="US",
        )

    client.close()


def test_validate_year_range_accepts_valid_range():
    SustaxClient._validate_year_range(1979, 2080)
    SustaxClient._validate_year_range(2024, 2024)


@pytest.mark.parametrize(
    "year_from, year_to",
    [
        (2025, 2024),
        (1978, 2024),
        (2024, 2081),
        (None, 2024),
        (2024, None),
        ("bad", 2024),
    ],
)
def test_validate_year_range_rejects_invalid_range(year_from, year_to):
    with pytest.raises(ValueError):
        SustaxClient._validate_year_range(year_from, year_to)


@pytest.mark.integration
@pytest.mark.purchase
def test_full_buy_download_unzip_and_parse_workflow(tmp_path):
    """
    Full end-to-end workflow test.

    WARNING:
    This calls buy_data() and may spend Sustax coins.

    To run this intentionally, remove the pytest.skip line below.
    """

    with SustaxClient() as sua:
        sua.authenticate(
            username=SUSTAX_USERNAME,
            password=SUSTAX_PASSWORD,
        )

        catalog = sua.get_variables_id()

        assert isinstance(catalog, list)
        assert len(catalog) > 0

        variable_id = _extract_one_climate_variable_id(catalog)

        price = sua.view_price_request(
            lat=LAT,
            lon=LON,
            year_from=YEAR_FROM,
            year_to=YEAR_TO,
            sustax_code_ids=[variable_id],
        )

        print("\nPrice before purchase:")
        pprint(price)

        req = sua.buy_data(
            lat=LAT,
            lon=LON,
            year_from=YEAR_FROM,
            year_to=YEAR_TO,
            sustax_code_ids=[variable_id],
            acceptance_sustax_disclaimer=True,
        )

        print("\nBuy data response:")
        pprint(req)

        assert isinstance(req, dict)

        request_id = req.get("idRequest") or req.get("request_id") or req.get("id")
        assert request_id is not None

        download_url = req.get("url")
        final_state = None

        for _ in range(30):
            state = sua.view_request_state(request_id)
            final_state = state

            print("\nRequest state:")
            pprint(state)

            download_url = (
                state.get("url")
                or state.get("downloadUrl")
                or state.get("download_url")
                or download_url
            )

            status_text = str(state).lower()

            if download_url:
                break

            if (
                "finished" in status_text
                or "complete" in status_text
                or "done" in status_text
            ):
                break

            time.sleep(10)

        assert isinstance(final_state, dict)
        assert download_url, f"No download URL found. Last state: {final_state}"

        zip_path = sua.download_file(download_url, tmp_path)

        zip_path = Path(zip_path)
        assert zip_path.exists()
        assert zip_path.suffix.lower() == ".zip"

        extract_dir = sua.unzip_download(tmp_path)
        extract_dir = Path(extract_dir)

        assert extract_dir.exists()

        csv_files = list(extract_dir.rglob("*.csv"))
        assert csv_files, f"No CSV files found in {extract_dir}"

        parsed = load_sustax_file(
            csv_files[0],
            return_pandas_df=True,
            return_metadata=True,
        )

        assert parsed is not None
        assert isinstance(parsed, tuple)
        assert len(parsed) >= 3