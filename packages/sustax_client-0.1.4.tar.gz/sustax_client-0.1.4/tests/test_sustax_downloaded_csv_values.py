import os
import time
from pathlib import Path
from pprint import pprint
import os
import pytest

from sustax_client import SustaxClient, load_sustax_file


# TEMPORARY LOCAL TEST CREDENTIALS
# Replace these for local testing, but do not commit real credentials.
SUSTAX_USERNAME = os.getenv("sustax_username")
SUSTAX_PASSWORD = os.getenv("sustax_password")


# Middle of Atlantic Ocean
LAT = 0.0
LON = -30.0

YEAR_FROM = 2024
YEAR_TO = 2024


def _extract_one_sustax_id(catalog: list) -> int:
    """
    Extract one sustaxId from the actual get_variables_id() API shape.

    Expected shape:
        [
            {
                "climateVariable": "...",
                "dataset": [
                    {
                        "name": "...",
                        "scenarios": [
                            {"scenario": "SSP119", "sustaxId": 604},
                            ...
                        ]
                    }
                ]
            }
        ]
    """
    assert isinstance(catalog, list)
    assert len(catalog) > 0

    # Prefer the same kind of variable you already bought successfully:
    # Total Precipitation -> Monthly Modified Fournier Index -> SSP119
    for climate_variable in catalog:
        if not isinstance(climate_variable, dict):
            continue

        if climate_variable.get("climateVariable") != "Total Precipitation":
            continue

        for dataset in climate_variable.get("dataset", []):
            if not isinstance(dataset, dict):
                continue

            if dataset.get("name") != "Monthly Modified Fournier Index":
                continue

            for scenario in dataset.get("scenarios", []):
                if scenario.get("scenario") == "SSP119":
                    return int(scenario["sustaxId"])

    # Fallback: first available sustaxId
    for climate_variable in catalog:
        for dataset in climate_variable.get("dataset", []):
            for scenario in dataset.get("scenarios", []):
                if isinstance(scenario, dict) and "sustaxId" in scenario:
                    return int(scenario["sustaxId"])

    raise AssertionError("Could not find any sustaxId in catalog")


@pytest.mark.integration
@pytest.mark.purchase
def test_downloaded_csv_contains_expected_real_value(tmp_path):
    """
    End-to-end test:
      - authenticate
      - buy one small dataset
      - download ZIP
      - unzip
      - load the downloaded Sustax CSV
      - assert that the CSV contains actual data values

    WARNING:
    This calls buy_data() and may spend Sustax coins.
    """

    with SustaxClient() as sua:
        sua.authenticate(
            username=SUSTAX_USERNAME,
            password=SUSTAX_PASSWORD,
        )

        catalog = sua.get_variables_id()
        variable_id = _extract_one_sustax_id(catalog)

        print("\nSelected sustaxId:")
        pprint(variable_id)

        price = sua.view_price_request(
            lat=LAT,
            lon=LON,
            year_from=YEAR_FROM,
            year_to=YEAR_TO,
            sustax_code_ids=[variable_id],
        )

        print("\nPrice:")
        pprint(price)

        assert price["Grand Total (Sustax coins)"] >= 0

        req = sua.buy_data(
            lat=LAT,
            lon=LON,
            year_from=YEAR_FROM,
            year_to=YEAR_TO,
            sustax_code_ids=[variable_id],
            acceptance_sustax_disclaimer=True,
        )

        print("\nBuy response:")
        pprint(req)

        request_id = (
            req.get("requestId")
            or req.get("idRequest")
            or req.get("request_id")
            or req.get("id")
        )
        assert request_id is not None, f"No request ID found in response: {req}"

        download_url = req.get("url")

        for _ in range(30):
            if download_url:
                break

            state = sua.view_request_state(request_id)

            print("\nRequest state:")
            pprint(state)

            download_url = (
                state.get("url")
                or state.get("downloadUrl")
                or state.get("download_url")
            )

            if download_url:
                break

            time.sleep(10)

        assert download_url is not None, "No download URL found"

        zip_path = sua.download_file(download_url, tmp_path)
        zip_path = Path(zip_path)

        assert zip_path.exists()
        assert zip_path.suffix.lower() == ".zip"

        extract_dir = sua.unzip_download(tmp_path)
        extract_dir = Path(extract_dir)

        csv_files = list(extract_dir.rglob("*.csv"))
        assert csv_files, f"No CSV files found in {extract_dir}"

        csv_path = csv_files[0]

        print("\nCSV file:")
        print(csv_path)

        parsed = load_sustax_file(
            csv_path,
            return_pandas_df=True,
            return_metadata=True,
        )

        print("\nParsed object type:")
        print(type(parsed))

        assert isinstance(parsed, tuple)
        assert len(parsed) >= 3

        climate_data = parsed[0]
        accuracy_metrics = parsed[1]

        print("\nClimate data preview:")
        print(climate_data.head() if hasattr(climate_data, "head") else climate_data)

        print("\nAccuracy metrics preview:")
        print(accuracy_metrics.head() if hasattr(accuracy_metrics, "head") else accuracy_metrics)

        # Main actual-value checks:
        # The downloaded CSV should not parse into empty data.
        assert climate_data is not None
        assert len(climate_data) > 0

        # If returned as a pandas DataFrame, assert it contains at least one real numeric value.
        if hasattr(climate_data, "select_dtypes"):
            numeric_values = climate_data.select_dtypes(include="number")

            assert not numeric_values.empty, (
                "Climate data has no numeric columns"
            )

            assert numeric_values.notna().any().any(), (
                "Climate data contains no non-null numeric values"
            )

            first_real_value = numeric_values.stack().dropna().iloc[0]

            print("\nFirst real numeric climate value:")
            print(first_real_value)

            assert isinstance(float(first_real_value), float)
            assert float(first_real_value) == pytest.approx(0.009923656471073627, rel=1e-6)

        else:
            # Fallback if load_sustax_file returns dict-like arrays instead of DataFrame.
            found_numeric_value = False

            if isinstance(climate_data, dict):
                for values in climate_data.values():
                    try:
                        for value in values:
                            if value is not None:
                                float(value)
                                found_numeric_value = True
                                break
                    except TypeError:
                        continue

                    if found_numeric_value:
                        break

            assert found_numeric_value, "No numeric value found in parsed climate data"
