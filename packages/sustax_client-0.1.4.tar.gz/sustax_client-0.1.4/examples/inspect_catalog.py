"""
Inspect the Sustax variable catalog.

Run from the repository root:

    python examples/inspect_catalog.py
"""

import os
from typing import Any, Dict, Iterable

from sustax_client import SustaxClient


def flatten_catalog_items(obj: Any) -> Iterable[Dict[str, Any]]:
    """
    Recursively yield dictionary items from a nested Sustax catalog response.

    Parameters
    ----------
    obj : Any
        Nested object returned by SustaxClient.get_variables_id().

    Yields
    ------
    dict
        Dictionary entries found anywhere inside the catalog.
    """
    if isinstance(obj, dict):
        yield obj

        for value in obj.values():
            yield from flatten_catalog_items(value)

    elif isinstance(obj, list):
        for item in obj:
            yield from flatten_catalog_items(item)


def main() -> None:
    """
    Authenticate and print catalog entries that contain an ID.
    """
    username = os.getenv("SUSTAX_USERNAME")
    password = os.getenv("SUSTAX_PASSWORD")

    if not username or not password:
        raise RuntimeError(
            "Set SUSTAX_USERNAME and SUSTAX_PASSWORD before running this script."
        )

    with SustaxClient() as client:
        client.authenticate(username, password)

        catalog = client.get_variables_id()

    items_with_ids = [
        item for item in flatten_catalog_items(catalog)
        if "id" in item
    ]

    for item in items_with_ids:
        print(item)


if __name__ == "__main__":
    main()
