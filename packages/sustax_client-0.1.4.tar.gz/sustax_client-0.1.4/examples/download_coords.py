"""
Download Sustax climate data by latitude and longitude.

Run from the repository root:

    python examples/download_coords.py
"""

import os
from pathlib import Path

from sustax_client import SustaxClient, load_sustax_file

from _helpers import (
    find_download_url,
    find_first_csv,
    get_sustax_code_ids,
    wait_for_request,
)


def main() -> None:
    """
    Authenticate, request data by coordinates, download the ZIP, unzip it,
    and load the Sustax CSV as pandas dataframes.
    """
    username = os.getenv("SUSTAX_USERNAME")
    password = os.getenv("SUSTAX_PASSWORD")

    if not username or not password:
        raise RuntimeError(
            "Set SUSTAX_USERNAME and SUSTAX_PASSWORD before running this script."
        )

    lat = 40.7128
    lon = -74.0060

    year_from = 2020
    year_to = 2020

    variable_codes = [
        "tas",
        "hurs",
        "pr",
        "sfcWindmax",
        "rsds",
    ]

    output_dir = Path("outputs") / "coords"
    output_dir.mkdir(parents=True, exist_ok=True)

    with SustaxClient() as client:
        client.authenticate(username, password)

        nearest_pixel = client.get_coordinates(lat=lat, lon=lon)

        catalog = client.get_variables_id()
        sustax_code_ids = get_sustax_code_ids(catalog, variable_codes)

        price = client.view_price_request(
            lat=lat,
            lon=lon,
            year_from=year_from,
            year_to=year_to,
            sustax_code_ids=sustax_code_ids,
        )

        request = client.buy_data(
            lat=lat,
            lon=lon,
            year_from=year_from,
            year_to=year_to,
            sustax_code_ids=sustax_code_ids,
            acceptance_sustax_disclaimer=True,
        )

        request_id = request.get("requestId") or request.get("id")

        if request_id is None:
            raise RuntimeError(f"Could not find request ID in response: {request}")

        final_state = wait_for_request(client, request_id)

        download_url = find_download_url(request, final_state)

        if not download_url:
            raise RuntimeError(
                "Could not find download URL in buy_data() or "
                f"view_request_state() response.\nRequest: {request}\n"
                f"Final state: {final_state}"
            )

        zip_path = client.download_file(
            url=download_url,
            dest_dir=output_dir,
        )

        extracted_dir = client.unzip_download(
            dest_dir=output_dir / zip_path.stem,
        )

    csv_path = find_first_csv(extracted_dir)

    values_df, metrics_df, metadata = load_sustax_file(
        csv_path,
        return_pandas_df=True,
        return_metadata=True,
    )

    print("Nearest Sustax pixel:")
    print(nearest_pixel)

    print("\nPrice response:")
    print(price)

    print("\nLoaded CSV:")
    print(csv_path)

    print("\nValues dataframe:")
    print(values_df.head())

    print("\nMetrics dataframe:")
    print(metrics_df.head())

    print("\nMetadata:")
    print(metadata)


if __name__ == "__main__":
    main()
