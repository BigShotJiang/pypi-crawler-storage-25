"""sustax-client: Python package for the Sustax User API and CSV parsing."""

from .client import SustaxClient
from .parser import load_sustax_file

__all__ = [
    "SustaxClient",
    "load_sustax_file",
]

__version__ = "0.1.1"
