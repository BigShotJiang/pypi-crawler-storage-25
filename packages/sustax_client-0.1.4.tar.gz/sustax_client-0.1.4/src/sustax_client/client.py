import re
import zipfile
import requests
from pathlib import Path
from functools import wraps
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from typing import Any, Dict, List, Tuple, Optional, Union

class SustaxClient:
    """
    Client for SUA, the Sustax User API (https://app.sustax.earth) with 
    automatic authentication and token refresh on expiry.
    
    Public methods:
    -------------
        - authenticate(username, password, remember_me=True) -> str
                              Authenticate and return JWT token.
        - get_variables_id() -> Dict
                              Get full catalog of datasets and scenarios (use for sustax_code_ids).
        - view_price_request(lat, lon, year_from, year_to, sustax_code_ids, postal_code, country) -> Dict
                              Get price quote before buying (supports POI/ROI/postal).
        - buy_data(lat, lon, year_from, year_to, sustax_code_ids, postal_code, country) -> Dict
                              Purchase data and return request details (supports POI/ROI/postal).
        - download_file(url, dest_dir, chunk_size, mk_parents, exist_ok) -> Path
                              Stream-download ZIP to dest_dir.
        - unzip_download(dest_dir) -> Path
                              Unzip self.dest (last download) to dest_dir.
        - get_coordinates(lat, lon) -> Dict
                              Get nearest pixel coords for POI.
        - view_request_state(request_id) -> Dict
                              Poll buy_data request status.
        - get_user_coints() -> Int
                              Returns amount of coins the user owns in Sustax
    
    Usage:
    -----
      >>> with SustaxClient() as SUA:
      >>>     SUA.authenticate("user", "pass")
      >>>     ids = SUA.get_variables_id()["climateVariable"]  # Get dataset IDs
      >>>     price = SUA.view_price_request(lat=41.4, lon=2.1, sustax_code_ids=ids)
      >>>     req = SUA.buy_data(lat=41.4, lon=2.1, sustax_code_ids=ids[:2])
      >>>     #Check req["requestId"] with SUA.view_request_state
      >>>     SUA.download_file(req['url'], "directory")
      >>>     SUA.unzip_download("directory")
      >>> #Use stx_csv_load() to load your csv from here
    """

    def __init__(self, base_url: str = "https://app.sustax.earth", 
                 timeout: Union[float, Tuple[float, float]] = (30, 300)) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session_get = requests.Session()
        self.session_post = requests.Session()
        for s in (self.session_get, self.session_post):
            s.headers.update({"Accept": "application/json"})

        # Retry on DNS/connection failures - Two adapters GET & POST
        retry_get = Retry(
            total=5, connect=3, read=3, status=5, other=0,
            backoff_factor = 2., backoff_max=120, backoff_jitter=.5,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset({"GET", "HEAD", "OPTIONS"}),
            respect_retry_after_header=True,
        )
        self.session_get.mount("https://", HTTPAdapter(max_retries=retry_get))
        self.session_get.mount("http://", HTTPAdapter(max_retries=retry_get))
        retry_post = Retry(
            total=3, connect=3, read=0, status=0, other=0, redirect=0,
            backoff_factor = 1, backoff_max=30,
            allowed_methods=frozenset({"POST"}),
            respect_retry_after_header=True,
        )
        self.session_post.mount("https://", HTTPAdapter(max_retries=retry_post))
        self.session_post.mount("http://", HTTPAdapter(max_retries=retry_post))
        
        self._token: Optional[str] = None
        self._username: Optional[str] = None
        self._password: Optional[str] = None
        self._remember_me: bool = True
        self._creds_ok: bool = False
        self.dest: Optional[Path] = None

    # ---------------------- authentication checking ----------------------

    @staticmethod
    def _require_auth(func):
        """Decorator to ensure authentication before API calls."""
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            if not self._token:
                raise RuntimeError(
                    f"Authentication required. Call authenticate() before using {func.__name__}()."
                )
            return func(self, *args, **kwargs)
        return wrapper

    def _reauth_if_possible(self) -> str:
        """Re-authenticate using stored credentials."""
        if self._username and self._password:
            return self.authenticate(self._username, self._password, self._remember_me)
        raise RuntimeError("Token expired and no stored credentials to re-authenticate.")

    def close(self) -> None:
        self.session_get.close()
        self.session_post.close()

    def __enter__(self) -> "SustaxClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
    
    # ---------------------- internal helpers ----------------------

    def _authorized_post(self, url: str, **kwargs) -> requests.Response:
        """POST with automatic one-time re-auth on 401."""
        headers = kwargs.pop("headers", {})
        headers = {**self.session_post.headers, "Content-Type": "application/json", **headers}
        timeout = kwargs.pop("timeout", self.timeout)
        resp = self.session_post.post(url, headers=headers, timeout=timeout, **kwargs)
        if (resp.status_code == 401) and self._creds_ok:
            self._reauth_if_possible()
            resp = self.session_post.post(url, headers=headers, timeout=timeout, **kwargs)
        resp.raise_for_status()
        return resp

    def _authorized_get(self, url: str, **kwargs) -> requests.Response:
        """GET with automatic one-time re-auth on 401."""
        timeout = kwargs.pop("timeout", self.timeout)
        resp = self.session_get.get(url, timeout=timeout, **kwargs)
        if (resp.status_code == 401) and self._creds_ok:
            self._reauth_if_possible()
            resp = self.session_get.get(url, timeout=timeout, **kwargs)
        resp.raise_for_status()
        return resp

    def _build_location_payload(self,*,lat: Optional[Union[int,float,str,list,tuple]] = None,
                                       lon: Optional[Union[int,float,str,list,tuple]] = None,
                                       postal_code: Optional[str] = None,
                                       country: Optional[str] = None,) -> Dict[str, Any]:
        # Decide which location method to use
        has_poi = isinstance(lat, (int,float,str)) and isinstance(lon, (int,float,str))
        has_roi = isinstance(lat, (list,tuple)) and isinstance(lon, (list,tuple))
        has_postal = (postal_code is not None and country is not None)
        if (has_poi or has_roi) and has_postal:
            raise ValueError("Specify exactly one location method:\nEither direct "
                             "from coordinates (lat/lon) OR from (postal_code+country).")
        if sum((has_poi,has_roi,has_postal)) != 1:
            raise Exception("Please select either point coordinates (lat, lon), "
                            "region coordinates (lat, lon as list) or point from "
                            "postal code + country")
        # Check what's the type of user request ROI / POI / POstal Code
        if has_roi:
            if (len(lat) != 2) or (len(lon) != 2):
                raise Exception("For ROI purchases user must pass `lat` and "
                                "`lon` as a list,\n(min_lat, max_lat) and"
                                "(min_lon, max_lon)")
            # Bounding box is: (North, West) to (South, East)
            lat, lon = sorted(lat, reverse=True), sorted(lon)
            return {"lat": float(lat[0]), "lon": float(lon[0]),
                    "lat2": float(lat[1]), "lon2": float(lon[1])}
        elif has_postal:
            return {"postalCode": self._check_postal_code(str(postal_code)),
                    "country": self._check_country_iso2(country),}
        else:
            return {"lat": float(lat), "lon": float(lon)}

    @staticmethod
    def _validate_year_range(year_from: int, year_to: int) -> None:
        min_year, max_year = 1979, 2080
        if year_from is None or year_to is None:
            raise ValueError("year_from and year_to must be provided.")
        try:
            yf = int(year_from)
            yt = int(year_to)
        except Exception as e:
            raise ValueError(f"year_from/year_to must be integers (got {year_from!r}, {year_to!r}).") from e
        if yf > yt:
            raise ValueError(f"Invalid year range: year_from ({yf}) must be <= year_to ({yt}).")
        if yf < min_year or yt > max_year:
            raise ValueError(f"Year range out of bounds: must be within {min_year}..{max_year} (got {yf}..{yt}).")

    @staticmethod
    def _check_postal_code(s: str) -> str:
        pc = str(s).strip()
        return re.sub(r"\s+", " ", pc)

    @staticmethod
    def _check_country_iso2(s: str) -> str:
        _COUNTRY_ALIASES = {
            "UK": "GB",
            "EL": "GR",
        }
        cc = str(s).strip().upper()
        return _COUNTRY_ALIASES.get(cc, cc)

    # ---------------------- public API ----------------------

    def authenticate(self, username: str, password: str, remember_me: bool = True) -> str:
        """
        Authenticate and obtain API token.
        
        Args:
            username: Sustax account username
            password: Sustax account password
            remember_me: Whether to maintain longer session
            
        Returns:
            JWT token string
        """
        url = f"{self.base_url}/api/authenticate"
        payload = {"username": username, "password": password, "rememberMe": remember_me}
        r = self.session_post.post(url, json=payload, timeout=(10, 60))
        r.raise_for_status()
        data = r.json()

        token = data.get("id_token")
        if not token:
            raise RuntimeError(f"Auth response did not include a token: {data}")

        self._creds_ok = True
        self._token = token
        self._username = username
        self._password = password
        self._remember_me = remember_me
        for s in (self.session_get, self.session_post):
            s.headers["Authorization"] = f"Bearer {token}"
        return token

    @_require_auth
    def get_variables_id(self) -> Dict[str, Any]:
        """
        Retrieves the full catalog of available Sustax datasets and scenarios.
        """
        url = f"{self.base_url}/api/getData"
        resp = self._authorized_get(url)
        return resp.json()

    @_require_auth
    def view_price_request(
        self,
        lat: Optional[Union[int,float,str,list,tuple]] = None,
        lon: Optional[Union[int,float,str,list,tuple]] = None,
        year_from: int = 1979,
        year_to: int = 2080,
        sustax_code_ids: List[int] = None,
        postal_code: Optional[str] = None,
        country: Optional[str] = None,  
    ) -> Dict[str, Any]:
        """
        View the price (Grand Total) for a specific request, useful to run before
        purchasing any dataset or to set cost controls. Supports 3 location specifications
        that are:
        
            - Point of Interest: lat, lon as floats
            - Region of Interest: lat and lon as list [lat1, lat2], [lon1, lon2]
            - Postal code: postal_code + country (ISO-2 official format)
        """
        ## Checks
        if not sustax_code_ids:
            raise ValueError("Please pass a list of integers with the ID of"
                             "each Sustax dataset")  
        self._validate_year_range(year_from, year_to)

        url = f"{self.base_url}/api/viewPriceRequest"
        payload: Dict[str, Any] = {
            "yearFrom": int(year_from),
            "yearTo": int(year_to),
            "sustaxCodes": [{"id": int(i)} for i in sustax_code_ids],
        }

        loc_payload = self._build_location_payload(lat = lat, lon = lon,
                                                   postal_code = postal_code,
                                                   country = country,)
        payload.update(loc_payload)
        
        resp = self._authorized_post(url, json=payload).json()
        message = resp.get("message", "")
        price = resp.get("price", None)
        separated_prices = resp.get("separatedPrices", {}) or {}
        
        return {'message':message} | {'Grand Total (Sustax coins)':price} | {'separated_prices' : separated_prices}

    @_require_auth
    def buy_data(
        self,
        lat: Optional[Union[int,float,str,list,tuple]] = None,
        lon: Optional[Union[int,float,str,list,tuple]] = None,
        year_from: int = 1979,
        year_to: int = 2080,
        sustax_code_ids: List[int] = None,
        postal_code: Optional[str] = None,
        country: Optional[str] = None,  
        acceptance_sustax_disclaimer: bool = True,
    ) -> Dict[str, Any]:
        """
        Purchase Sustax data for specified time range and scenario IDs. Three
        types of data purchasing, based on locations specifications. The 
        supported location specifications are:
        
            - Point of Interest: lat, lon as floats
            - Region of Interest: lat and lon as list [lat1, lat2], [lon1, lon2]
            - Postal code: postal_code + country (ISO-2 official format)

        Sustax Disclaimer is accepted by default in this class
            - acceptance_sustax_disclaimer. See https://sustax.earth/sustax-user-disclaimer/
        """
        ## Checks
        if not sustax_code_ids:
            raise ValueError("Please pass a list of integers with the ID of "
                             "each Sustax dataset")
        if acceptance_sustax_disclaimer != True:
            raise Exception("Sustax Disclaimer must be accepted, by passing "
                            "`acceptance_sustax_disclaimer = True` to proceed.\n"
                            "Please review it in: `https://sustax.earth/sustax-user-disclaimer/`")
        self._validate_year_range(year_from, year_to)
        
        url = f"{self.base_url}/api/buyData"
        payload: Dict[str, Any] = {
            "yearFrom": int(year_from),
            "yearTo": int(year_to),
            "sustaxCodes": [{"id": int(i)} for i in sustax_code_ids],
            # https://sustax.earth/sustax-user-disclaimer/
            "disclaimerAcceptance": bool(acceptance_sustax_disclaimer),
        }
 
        loc_payload = self._build_location_payload(lat = lat, lon = lon,
                                                   postal_code = postal_code,
                                                   country = country,)
        payload.update(loc_payload)
        return self._authorized_post(url, json=payload, timeout=(10, 1250)).json()

    @_require_auth
    def download_file(
        self, 
        url: str, 
        dest_dir: Union[Path, str, None] = None, 
        chunk_size: int = 8192,
        mk_parents: bool = True, 
        exist_ok: bool = True
    ) -> Path:
        """
        Download file from URL and save to destination directory.
        """
        dest_dir = Path(dest_dir) if dest_dir else Path.cwd()
        if mk_parents:
            dest_dir.mkdir(parents=True, exist_ok=exist_ok)

        # Extract filename from URL
        tokens = [s for s in url.split('_') if 'ID' in s]
        stem = tokens[0] if tokens else "download"
        filename = f"{stem}.zip"
        dest = dest_dir / filename

        # Stream download
        with self._authorized_get(url, stream=True) as r:
            with open(dest, "wb") as f:
                for chunk in r.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)

        self.dest = dest
        return dest

    def unzip_download(self, dest_dir: Union[Path, str, None] = None) -> Path:
        """
        Unzip the last downloaded ZIP file.
        
        Args:
            dest_dir: Extraction directory (defaults to zip location)
            
        Returns:
            Path to extraction directory
        """
        if not self.dest or not self.dest.exists():
            raise FileNotFoundError(
                "No downloaded ZIP found. Call download_file() first."
            )

        if dest_dir is None:
            dest_dir = self.dest.with_suffix("")
        dest_dir = Path(dest_dir)
        dest_dir.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(self.dest, "r") as zf:
            zf.extractall(dest_dir)

        return dest_dir

    @_require_auth
    def get_coordinates(self, lat: Union[int,float,str], lon: Union[int,float,str]) -> Dict[str, Any]:
        """
        Given a point of interest (lat/lon), returns the nearest available pixel
        coordinates where Sustax has measurement data.
        """
        url = f"{self.base_url}/api/getCoordinates"
        params = {"lat": float(lat), "lon": float(lon),}
        resp = self._authorized_get(url, params=params)
        return resp.json()

    @_require_auth
    def view_request_state(self, request_id: Union[int,str]) -> Dict[str, Any]:
        """
        Check processing state for a request by ID.
        """
        url = f"{self.base_url}/api/viewRequestState/{request_id}"
        resp = self._authorized_get(url)
        try:
            return resp.json()
        except Exception:
            return {"state": resp.text.strip()}

    @_require_auth
    def get_user_coins(self) -> int:
        """
        Retrieves the current Sustax credit balance for the authenticated user.
        """
        url = f"{self.base_url}/api/users/getUserCoins"
        resp = self._authorized_get(url)
        return resp.json()