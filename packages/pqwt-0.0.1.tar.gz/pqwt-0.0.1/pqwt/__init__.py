"""Reserved for the pqdx ecosystem — https://pqdx.dev"""
__version__ = "0.0.1"
