#!/usr/bin/python3
# -*- coding: utf-8 -*-

import math
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from ase.data import covalent_radii, atomic_numbers, chemical_symbols


BANNER = r"""
======================================================================
                           AROGEOMETRIC
            Geometric Criteria for Aromaticity Evaluation
======================================================================

AroGeometric implements widely used geometric descriptors of aromaticity:

 • HOMA93 (Harmonic Oscillator Model of Aromaticity with experimental data)
 • HOMAc (Harmonic Oscillator Model of Aromaticity with computational data)
 • HOMER (excited-state aromaticity)

Capabilities:

 • Automatic ring detection from molecular geometry
 • Quantification of bond-length equalization (BLA)
 • Analysis of mono- and polycyclic systems
 • Graph-based ring identification
 • Interactive 3D visualization of rings

Geometric indices complement magnetic criteria by providing structural
evidence of electron delocalization in cyclic molecules.

----------------------------------------------------------------------
Developed by:

   Fernando Martínez-Villarino
   Gabriel Merino

   Cinvestav – Mérida
   Centro de Investigación y de Estudios Avanzados del IPN

----------------------------------------------------------------------
Citation:

   Martínez-Villarino, F.; Orozco-Ic, M.; Merino, G.
   AromaTools 1.0, Cinvestav Mérida, Mérida, Mexico, 2025.

======================================================================
"""

# Diccionarios de parámetros
R_opt = {'HOMA93': {'CC': 1.388, 'CN': 1.334, 'NN': 1.309, 'CO': 1.265},
         'HOMER': {'CC': 1.437, 'CN': 1.39, 'NN': 1.375, 'CO': 1.379},
         'HOMAC': {'CC': 1.392, 'CN': 1.333, 'NN': 1.318, 'CO': 1.315, 'SiSi': 2.163, 'CSi': 1.752}}

alpha = {'HOMA93': {'CC': 257.7, 'CN': 93.52, 'NN': 130.33, 'CO': 157.38},
         'HOMER': {'CC': 950.74, 'CN': 506.43, 'NN': 187.36, 'CO': 164.96},
         'HOMAC': {'CC': 153.37, 'CN': 111.83, 'NN': 98.99, 'CO': 335.16, 'SiSi': 325.6, 'CSi': 115.41}}

def build_graph(atoms, tol=0.45):
    G = nx.Graph()
    for idx, (sym, _, _, _) in enumerate(atoms):
        G.add_node(idx, element=sym)
    for i in range(len(atoms)):
        sym1, x1, y1, z1 = atoms[i]
        r1 = covalent_radii[atomic_numbers[sym1]]
        for j in range(i + 1, len(atoms)):
            sym2, x2, y2, z2 = atoms[j]
            r2 = covalent_radii[atomic_numbers[sym2]]
            dist = math.sqrt((x1 - x2)**2 + (y1 - y2)**2 + (z1 - z2)**2)
            if dist <= r1 + r2 + tol:
                bond_type = ''.join(sorted(sym1 + sym2))
                G.add_edge(i, j, length=dist, bond_type=bond_type)
    return G

def find_rings_by_size(G, sizes=None):
    rings = set()

    if sizes is None:
        sizes = tuple(range(3, len(G.nodes()) + 1))

    if isinstance(sizes, int):
        sizes = (sizes,)
    elif isinstance(sizes, range):
        sizes = tuple(sizes)

    max_size = max(sizes)

    def canon_ring(path):
        seq1 = list(path)
        seq2 = list(reversed(path))

        def normalize(seq):
            m = min(seq)
            i = seq.index(m)
            return tuple(seq[i:] + seq[:i])

        return min(normalize(seq1), normalize(seq2))

    def dfs(path, depth):
        current = path[-1]

        if len(set(path)) != len(path):
            return

        if depth > max_size:
            return

        for neighbor in G.neighbors(current):
            if neighbor == path[0] and len(path) in sizes:
                rings.add(canon_ring(path))
            elif neighbor not in path:
                dfs(path + [neighbor], depth + 1)

    for start in G.nodes():
        dfs([start], 1)

    return [list(r) for r in rings]

def compute_index(G, atoms, index_type):
    rings = find_elementary_rings(G, sizes=range(3, len(G.nodes()) + 1))
    ring_data = []
    bond_rows = []
    coords = {i: (x, y, z) for i, (_, x, y, z) in enumerate(atoms)}
    symbols = {i: sym for i, (sym, _, _, _) in enumerate(atoms)}

    if index_type == "HOMA":
        sub_indices = ["HOMA93", "HOMAC"]
    elif index_type == "HOMER":
        sub_indices = ["HOMER"]
    else:
        raise ValueError("Invalid index_type. Choose 'HOMA' or 'HOMER'.")

    for idx, ring in enumerate(rings, start=1):
        try:
            ordered_ring = order_ring_nodes(G, ring)
        except ValueError:
            continue
        ring_atoms = ordered_ring + [ordered_ring[0]]
        distances = []
        bond_info = []
        completo = True

        for i in range(len(ring)):
            a1, a2 = ring_atoms[i], ring_atoms[i+1]
            if a1 not in coords or a2 not in coords:
                completo = False
                break
            x1, y1, z1 = coords[a1]
            x2, y2, z2 = coords[a2]
            sym1 = symbols[a1]
            sym2 = symbols[a2]
            dist = math.sqrt((x1 - x2)**2 + (y1 - y2)**2 + (z1 - z2)**2)
            bond_type = ''.join(sorted(sym1 + sym2))
            bond_info.append({
                "type": bond_type,
                "length": dist
            })
            distances.append(dist)

        if not completo or len(distances) != len(ring):
            continue
        for b in bond_info:
            bond_rows.append({
                "Ring": idx,
                "Type_Bond": b["type"],
                "Length (Å)": round(b["length"], 4)
            })
        row = {
            "Ring": f"Ring {idx}", 
            "Bonds": [round(d, 4) for d in distances]
        }
        for sub_index in sub_indices:
            contribs = []
            for b in bond_info:
                bt = b["type"]
                if bt in R_opt[sub_index]:
                    Ropt = R_opt[sub_index][bt]
                    a = alpha[sub_index][bt]
                    contribs.append(a * (b["length"] - Ropt)**2)
                else:
                    print(f"[!] Tipo de enlace {bt} no soportado para {sub_index}")

            if contribs:
                n = len(contribs)
                value = 1.0 - sum(contribs) / n
                row[sub_index] = round(value, 4)

        if len(distances) >= 3:
            n = len(distances)
            bla = sum(abs(distances[i] - distances[(i+1) % n]) for i in range(n)) / n
            row["BLA"] = round(bla, 4)

        ring_data.append(row)

    df = pd.DataFrame(ring_data)
    df_main = pd.DataFrame(ring_data)
    df_main.index += 1
    df_bonds = pd.DataFrame(bond_rows)
    df_bonds.index += 1
    ring_indices = [(i, row.get("HOMAC", row.get("HOMA93", row.get("HOMER", 0.0)))) for i, row in enumerate(ring_data)]

    return rings, ring_indices, df_main, df_bonds

'''def find_elementary_rings(G, sizes=None):
    if sizes is None:
        sizes = range(3, len(G.nodes()) + 1)

    if isinstance(sizes, int):
        sizes = (sizes,)
    elif isinstance(sizes, range):
        sizes = tuple(sizes)

    sizes = set(sizes)
    max_size = max(sizes)
    rings = set()

    def canon_ring(cycle):
        cycle = list(cycle)

        def normalize(seq):
            m = min(seq)
            i = seq.index(m)
            return tuple(seq[i:] + seq[:i])

        seq1 = normalize(cycle)
        seq2 = normalize(list(reversed(cycle)))
        return min(seq1, seq2)

    for start in G.nodes():
        stack = [(start, [start])]

        while stack:
            current, path = stack.pop()

            for neighbor in G.neighbors(current):
                if neighbor == start and len(path) >= 3:
                    if len(path) in sizes:
                        subG = G.subgraph(path)
                        degrees = dict(subG.degree())

                        # ciclo simple elemental
                        if nx.is_connected(subG) and all(d == 2 for d in degrees.values()):
                            rings.add(canon_ring(path))

                elif neighbor not in path and len(path) < max_size:
                    stack.append((neighbor, path + [neighbor]))

    return [list(r) for r in sorted(rings, key=lambda r: (len(r), r))]'''

def find_elementary_rings(G, sizes=None):
    if sizes is None:
        sizes = range(3, len(G.nodes()) + 1)

    if isinstance(sizes, int):
        sizes = (sizes,)
    elif isinstance(sizes, range):
        sizes = tuple(sizes)

    sizes = set(sizes)

    def canon_ring(cycle):
        cycle = list(cycle)

        def normalize(seq):
            m = min(seq)
            i = seq.index(m)
            return tuple(seq[i:] + seq[:i])

        seq1 = normalize(cycle)
        seq2 = normalize(list(reversed(cycle)))
        return min(seq1, seq2)

    is_planar, embedding = nx.check_planarity(G)
    if not is_planar:
        raise ValueError("The molecular graph is not planar. Minimal ring detection by planar faces is not applicable.")
    rings = set()
    seen_half_edges = set()
    for u in embedding:
        for v in embedding[u]:
            if (u, v) in seen_half_edges:
                continue
            face = embedding.traverse_face(u, v)
            for i in range(len(face)):
                a = face[i]
                b = face[(i + 1) % len(face)]
                seen_half_edges.add((a, b))

            if len(face) in sizes:
                rings.add(canon_ring(face))

    rings = [list(r) for r in rings]

    minimal_rings = []
    ring_sets = [set(r) for r in rings]

    for i, ring_i in enumerate(rings):
        Si = ring_sets[i]
        is_minimal = True
        for j, ring_j in enumerate(rings):
            if i == j:
                continue
            Sj = ring_sets[j]
            if len(Sj) < len(Si) and Sj.issubset(Si):
                is_minimal = False
                break
        if is_minimal:
            minimal_rings.append(ring_i)

    minimal_rings = sorted(minimal_rings, key=lambda r: (len(r), r))
    return minimal_rings

def order_ring_nodes(G, ring):
    subG = G.subgraph(ring)

    if not nx.is_connected(subG):
        raise ValueError(f"Ring is not connected: {ring}")
    degrees = dict(subG.degree())
    if not all(d == 2 for d in degrees.values()):
        raise ValueError(f"Ring is not a simple cycle: {ring}")
    start = ring[0]
    neighbors = list(subG.neighbors(start))
    if len(neighbors) != 2:
        raise ValueError(f"Invalid cycle start node: {start}")
    ordered = [start, neighbors[0]]
    while len(ordered) < len(ring):
        prev = ordered[-2]
        curr = ordered[-1]
        next_nodes = [n for n in subG.neighbors(curr) if n != prev]
        if not next_nodes:
            raise ValueError(f"Could not continue ordering ring: {ring}")
        nxt = next_nodes[0]
        if nxt == start and len(ordered) != len(ring):
            raise ValueError(f"Premature ring closure: {ring}")
        if nxt in ordered:
            raise ValueError(f"Repeated node while ordering ring: {ring}")
        ordered.append(nxt)
    if start not in subG.neighbors(ordered[-1]):
        raise ValueError(f"Ring does not close properly: {ring}")
    return ordered

def get_3Dgraph(G, atoms, rings, ring_indices):
    node_xyz = [(x, y, z) for _, x, y, z in atoms]
    edges = list(G.edges())
    x_edges = []
    y_edges = []
    z_edges = []
    for u, v in edges:
        x_edges += [node_xyz[u][0], node_xyz[v][0], None]
        y_edges += [node_xyz[u][1], node_xyz[v][1], None]
        z_edges += [node_xyz[u][2], node_xyz[v][2], None]
    x_nodes = [coord[0] for coord in node_xyz]
    y_nodes = [coord[1] for coord in node_xyz]
    z_nodes = [coord[2] for coord in node_xyz]
    symbols = [atoms[i][0] for i in range(len(atoms))]
    node_trace = go.Scatter3d(
        x=x_nodes, y=y_nodes, z=z_nodes,
        mode='markers+text',
        text=symbols,
        textposition='top center',
        marker=dict(size=5, color='lightblue'),
        name="Atoms"
    )
    edge_trace = go.Scatter3d(
        x=x_edges, y=y_edges, z=z_edges,
        mode='lines',
        line=dict(width=2, color='gray'),
        name="Bonds"
    )
    x_c_list, y_c_list, z_c_list, text_list = [], [], [], []

    for i, ring in enumerate(rings):
        coords = [node_xyz[a] for a in ring]
        x_c = sum(coord[0] for coord in coords) / len(coords)
        y_c = sum(coord[1] for coord in coords) / len(coords)
        z_c = sum(coord[2] for coord in coords) / len(coords)
        value = ring_indices.get(i, None) if isinstance(ring_indices, dict) else dict(ring_indices).get(i, None)
        if value is not None:
            x_c_list.append(x_c); y_c_list.append(y_c); z_c_list.append(z_c)
            text_list.append(f"{value:.3f}")

    centroid_trace = go.Scatter3d(
        x=x_c_list, y=y_c_list, z=z_c_list,
        mode='text',
        text=text_list,
        textfont=dict(size=10, color='red'),
        textposition='middle center',
        name="Indices"
    )
    fig = go.Figure(data=[edge_trace, node_trace, centroid_trace])
    fig.update_layout(
        margin=dict(l=0, r=0, b=0, t=30),
        showlegend=False,
        scene=dict(xaxis=dict(visible=False), yaxis=dict(visible=False), zaxis=dict(visible=False))
    )

    for i, ring in enumerate(rings):
        x, y, z = zip(*[atoms[idx][1:] for idx in ring])
        centroid = (sum(x)/len(x), sum(y)/len(y), sum(z)/len(z))

        fig.add_trace(go.Scatter3d(
            x=[centroid[0]],
            y=[centroid[1]],
            z=[centroid[2]],
            mode='text',
            text=[f"Ring {i+1}"],
            textposition="top center",
            textfont=dict(color='black', size=12),
            hoverinfo='none',
            showlegend=False
    ))

    return fig

def extract_atoms_from_output(fileout):
    atoms = []
    with open(fileout, 'r') as f:
        lines = f.readlines()
    if any("Entering Gaussian System" in line for line in lines):
        for i in range(len(lines) - 5):
            if "Standard orientation" in lines[i]:
                atoms = []
                j = i + 5
                while not "---" in lines[j]:
                    parts = lines[j].split()
                    atomic_number = int(parts[1])
                    symbol = chemical_symbols[atomic_number]
                    x, y, z = map(float, parts[3:6])
                    atoms.append((symbol, x, y, z))
                    j += 1
    elif any("O   R   C   A" in line for line in lines):
        atoms = []
        start = False
        for line in lines:
            if "CARTESIAN COORDINATES (ANGSTROEM)" in line:
                atoms = []
                start = True
                continue
            if start:
                if "---" in line or not line.strip():
                    start = False
                    continue
                parts = line.strip().split()
                if len(parts) == 4:
                    symbol = parts[0]
                    x, y, z = map(float, parts[1:])
                    atoms.append((symbol, x, y, z))
    df = pd.DataFrame(atoms, columns=["Element", "X", "Y", "Z"])
    return df

def main():
    print(BANNER)


