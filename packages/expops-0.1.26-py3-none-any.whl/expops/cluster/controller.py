#!/usr/bin/env python3
import argparse
import os
import subprocess
import sys
import time
import yaml
import logging
from pathlib import Path
from typing import Optional, Dict, Any

from expops.core.compute_config import load_compute_config, map_compute_to_executor
from expops.core.platform_install import ensure_platform_importable

def _default_workspace_dir() -> Path:
    raw = os.environ.get("MLOPS_WORKSPACE_DIR")
    if raw:
        try:
            return Path(raw).expanduser().resolve()
        except Exception:
            return Path(raw)
    return Path.cwd()


def _project_cache_base(project_id: str) -> Path:
    """Prefer new cache namespace, but reuse legacy cache when present."""
    new_base = Path.home() / ".cache" / "expops-platform" / project_id
    legacy_base = Path.home() / ".cache" / "mlops-platform" / project_id
    if not new_base.exists() and legacy_base.exists():
        return legacy_base
    return new_base


# Source-checkout support: make <workspace>/src importable when present; otherwise assume installed package.
_WORKSPACE_ROOT = _default_workspace_dir()
_SRC_DIR = _WORKSPACE_ROOT / "src"
if _SRC_DIR.exists() and str(_SRC_DIR) not in sys.path:
    sys.path.insert(0, str(_SRC_DIR))

class ClusterController:
    def __init__(self, project_dir: Path):
        self.project_dir = project_dir.resolve()
        self.logs_dir: Optional[Path] = None
        self.artifacts_dir: Optional[Path] = None
        self.logger = logging.getLogger("CLUSTER_CONTROLLER")

    def _ensure_dirs(self) -> None:
        """Create logs_dir and artifacts_dir when set (project-specific paths only)."""
        if self.logs_dir is not None:
            self.logs_dir.mkdir(parents=True, exist_ok=True)
        if self.artifacts_dir is not None:
            self.artifacts_dir.mkdir(parents=True, exist_ok=True)

    def _build_kv_env(self, project_id: str) -> Dict[str, str]:
        """Build environment variables for KV backend from project or compute config."""
        env: Dict[str, str] = {}
        try:
            import yaml as _yaml
            from expops.runtime.env_export import export_kv_env
            proj_cfg_path = self.project_dir / project_id / "configs" / "project_config.yaml"
            proj_cfg = {}
            if proj_cfg_path.exists():
                with open(proj_cfg_path, 'r') as _f:
                    proj_cfg = _yaml.safe_load(_f) or {}
            # Navigate to experiment.cache.backend
            try:
                kv_cfg = ((proj_cfg.get('experiment') or {}).get('cache', {}) or {})
                backend_cfg = kv_cfg.get('backend') if isinstance(kv_cfg, dict) else {}
                if isinstance(backend_cfg, dict) and backend_cfg:
                    env.update(
                        export_kv_env(
                            backend_cfg,
                            workspace_root=self.project_dir,
                            project_root=(self.project_dir / project_id),
                        )
                    )
            except Exception:
                pass
            # Fallback to compute kv_store block if present
            if not env:
                cfg_path = self.project_dir / project_id / "configs" / "compute_config.yaml"
                compute_cfg_local: Dict[str, Any] = {}
                if cfg_path.exists():
                    with open(cfg_path, 'r') as _f:
                        compute_cfg_local = _yaml.safe_load(_f) or {}
                compute_kv = compute_cfg_local.get('kv_store') if isinstance(compute_cfg_local, dict) else None
                if isinstance(compute_kv, dict):
                    backend = compute_kv.get('backend', 'redis')
                    if backend == 'redis':
                        backend_cfg2 = {
                            "type": "redis",
                            "host": compute_kv.get("host"),
                            "port": compute_kv.get("port"),
                            "db": compute_kv.get("db"),
                            "password": compute_kv.get("password"),
                        }
                        env.update(
                            export_kv_env(
                                backend_cfg2,
                                workspace_root=self.project_dir,
                                project_root=(self.project_dir / project_id),
                            )
                        )
                    elif backend == 'gcp':
                        backend_cfg2 = {
                            "type": "gcp",
                            "gcp_project": compute_kv.get("gcp_project"),
                            "emulator_host": compute_kv.get("emulator_host"),
                            "credentials_json": compute_kv.get("credentials_json"),
                        }
                        env.update(
                            export_kv_env(
                                backend_cfg2,
                                workspace_root=self.project_dir,
                                project_root=(self.project_dir / project_id),
                            )
                        )
        except Exception:
            env = {}
        return env

    def _load_executor_config(self, project_id: str) -> Dict[str, Any]:
        """Load executor config mapped from compute_config.yaml."""
        try:
            cfg_path = self.project_dir / project_id / "configs" / "compute_config.yaml"
            compute_cfg = load_compute_config(cfg_path)
            executor_cfg = map_compute_to_executor(compute_cfg)
            return executor_cfg if isinstance(executor_cfg, dict) else {}
        except Exception:
            return {}

    @staticmethod
    def _extract_comm_compression(executor_cfg: Dict[str, Any]) -> Optional[str]:
        if not isinstance(executor_cfg, dict):
            return None
        dask_cfg = executor_cfg.get('dask') or executor_cfg.get('dask_config') or {}
        if not isinstance(dask_cfg, dict):
            return None
        comm_cfg = dask_cfg.get('comm') or {}
        if isinstance(comm_cfg, dict):
            comp = comm_cfg.get('compression') or comm_cfg.get('codec')
            if comp:
                return str(comp)
        comp = dask_cfg.get('compression')
        return str(comp) if comp else None

    def run_project_with_dask(self, project_id: str,
                               cluster_provider: Optional[str] = None,
                               num_workers: int = 2,
                               provider_options: Optional[Dict[str, Any]] = None) -> None:
        """Run the project locally while provisioning a Dask cluster via a provider (slurm/ansible)."""
        if self.logs_dir is None or self.artifacts_dir is None:
            runtime_root = self.project_dir / project_id / f".{project_id}"
            self.logs_dir = runtime_root / "logs"
            self.artifacts_dir = runtime_root / "artifacts"
            self._ensure_dirs()
        self.logger.info(f"Project directory: {self.project_dir}")
        self.logger.info(f"Logs directory: {self.logs_dir}")
        self.logger.info(f"Artifacts directory: {self.artifacts_dir}")

        # Prepare KV env from config
        kv_env = self._build_kv_env(project_id)
        executor_cfg = self._load_executor_config(project_id)
        comm_compression = self._extract_comm_compression(executor_cfg)

        # Prepare a per-project interpreter using the environment manager
        cache_base = _project_cache_base(project_id)
        env_file = cache_base / "python_interpreter.txt"
        env_file.parent.mkdir(parents=True, exist_ok=True)
        self.logger.info(f"Ensuring project interpreter at {env_file}")
        setup_script = self.project_dir / "src" / "expops" / "environment" / "setup_env.py"
        if setup_script.exists():
            setup_cmd = [
                sys.executable,
                str(setup_script),
                "--project-id", project_id,
                "--project-dir", str(self.project_dir),
                "--env-file", str(env_file),
            ]
        else:
            setup_cmd = [
                sys.executable,
                "-m",
                "expops.environment.setup_env",
                "--project-id", project_id,
                "--project-dir", str(self.project_dir),
                "--env-file", str(env_file),
            ]
        # Log file for this run (unique per run)
        env_log_hint = os.environ.get("MLOPS_RUN_LOG_FILE")
        if env_log_hint:
            proj_log_file = Path(env_log_hint)
            proj_log_file.parent.mkdir(parents=True, exist_ok=True)
        else:
            runtime_root = self.project_dir / project_id / f".{project_id}"
            proj_logs_dir = runtime_root / "logs"
            proj_logs_dir.mkdir(parents=True, exist_ok=True)
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            proj_log_file = proj_logs_dir / f"{project_id}_{timestamp}.log"
            os.environ["MLOPS_RUN_LOG_FILE"] = str(proj_log_file)
        # Note: pointers are printed in main() before re-exec; avoid duplicate prints here
        with open(proj_log_file, "a", encoding="utf-8") as lf:
            res = subprocess.run(setup_cmd, stdout=lf, stderr=lf, text=True)
        if res.returncode != 0:
            self.logger.error("Project environment setup failed. See project log for details.")
            raise RuntimeError("Failed to set up project environment")

        # Read the project interpreter path produced by setup
        if not env_file.exists():
            raise RuntimeError(f"Missing environment interpreter file at {env_file}")
        project_python = env_file.read_text().strip()
        if not project_python:
            raise RuntimeError("Empty interpreter path read from env file")
        # Make sure required dependencies are present in the project environment
        try:
            # Upgrade pip and core build tools
            with open(proj_log_file, "a", encoding="utf-8") as lf:
                subprocess.run([project_python, "-m", "pip", "install", "--quiet", "--upgrade", "pip", "setuptools", "wheel"], check=False, stdout=lf, stderr=lf, text=True)

            with open(proj_log_file, "a", encoding="utf-8") as lf:
                installed_ok = ensure_platform_importable(
                    project_python,
                    import_module="expops.core",
                    log_stream=lf,
                )
                if not installed_ok:
                    raise RuntimeError(
                        "Project interpreter cannot import 'expops.core'. "
                        "Ensure 'expops' is installed in the project environment (or run from a source checkout with workspace/src present)."
                    )

            # Ensure pydantic is available for adapters/config schema regardless of editable install success
            try:
                subprocess.run([project_python, "-c", "import pydantic"], check=True, capture_output=True, text=True)
            except Exception:
                with open(proj_log_file, "a", encoding="utf-8") as lf:
                    lf.write("Installing missing dependency: pydantic>=2\n")
                    res = subprocess.run([project_python, "-m", "pip", "install", "--quiet", "pydantic>=2"], check=False, stdout=lf, stderr=lf, text=True)
                    if res.returncode != 0:
                        lf.write("Retrying pydantic install with --user...\n")
                        subprocess.run([project_python, "-m", "pip", "install", "--quiet", "--user", "pydantic>=2"], check=False, stdout=lf, stderr=lf, text=True)
        except Exception as e:
            self.logger.error(
                f"Project environment validation failed: {e}. "
                "See project log for details."
            )
            raise

        # Verify core distributed dependencies; attempt to install if missing
        def _ensure_importable(py: str, module: str) -> bool:
            try:
                subprocess.run([py, "-c", f"import {module}"], check=True, capture_output=True, text=True)
                return True
            except Exception:
                return False

        def _log_import_failure(module: str) -> None:
            try:
                res = subprocess.run(
                    [project_python, "-c", f"import {module}"],
                    check=False,
                    capture_output=True,
                    text=True,
                )
                if getattr(res, "returncode", 0) != 0:
                    details = (res.stderr or res.stdout or "").strip()
                    msg = f"Import check failed for {module}: {details or 'unknown error'}"
                    self.logger.error(msg)
                    with open(proj_log_file, "a", encoding="utf-8") as lf:
                        lf.write(f"{msg}\n")
            except Exception as e:
                self.logger.error(f"Failed to capture import error for {module}: {e}")

        def _pip_install(packages: list[str], label: str) -> bool:
            if not packages:
                return True
            cmd = [project_python, "-m", "pip", "install", "--upgrade", "--no-cache-dir", *packages]
            with open(proj_log_file, "a", encoding="utf-8") as lf:
                lf.write(f"Installing {label}: {' '.join(packages)}\n")
                res = subprocess.run(cmd, check=False, stdout=lf, stderr=lf, text=True)
            if getattr(res, "returncode", 1) != 0:
                self.logger.warning(
                    f"pip install failed for {label} (exit code {getattr(res, 'returncode', 'unknown')}). "
                    f"See {proj_log_file}"
                )
                return False
            return True

        core_missing = []
        for mod in ("dask", "distributed"):
            if not _ensure_importable(project_python, mod):
                core_missing.append(mod)
        if core_missing:
            self.logger.info(f"Installing missing core deps into project env: {', '.join(core_missing)}")
            _pip_install(core_missing, "core deps")
        # For slurm provider ensure dask-jobqueue is present
        if cluster_provider == 'slurm' and not _ensure_importable(project_python, "dask_jobqueue"):
            self.logger.info("Installing missing SLURM extra: dask-jobqueue>=0.8.0")
            _pip_install(["dask-jobqueue>=0.8.0"], "SLURM extra")
        # Final gate: give a clear error early if deps are still missing
        missing_core = [m for m in ("dask", "distributed") if not _ensure_importable(project_python, m)]
        if missing_core:
            for m in missing_core:
                _log_import_failure(m)
            raise RuntimeError(
                "Dask is not available in the project environment. "
                "Auto-install may have failed; check the project log for pip errors: "
                f"{proj_log_file}"
            )
        if cluster_provider == 'slurm' and not _ensure_importable(project_python, "dask_jobqueue"):
            _log_import_failure("dask_jobqueue")
            raise RuntimeError(
                "dask-jobqueue is not available in the project environment. "
                "Auto-install may have failed; check the project log for pip errors: "
                f"{proj_log_file}"
            )

        # In-process import sanity (rare HPC oddities): ensure this running interpreter can import dask/distributed
        try:
            import dask as _d  # type: ignore
            import distributed as _dist  # type: ignore
            try:
                _dv = getattr(_d, "__version__", "unknown")
            except Exception:
                _dv = "unknown"
            try:
                _disv = getattr(_dist, "__version__", "unknown")
            except Exception:
                _disv = "unknown"
            self.logger.info(f"Dask import OK in-process: dask={_dv}, distributed={_disv}")
        except Exception as _imp_e:
            self.logger.warning(f"In-process import of dask failed: {_imp_e}. Patching sys.path using project env site-packages...")
            try:
                sp = subprocess.run(
                    [project_python, "-c", "import sysconfig; print(sysconfig.get_paths().get('purelib') or '')"],
                    capture_output=True,
                    text=True,
                    check=False,
                )
                site_pkgs = (sp.stdout or "").strip()
                if site_pkgs:
                    if site_pkgs not in sys.path:
                        sys.path.insert(0, site_pkgs)
                    try:
                        import dask as _d2  # type: ignore
                        import distributed as _dist2  # type: ignore
                        _dv2 = getattr(_d2, "__version__", "unknown")
                        _disv2 = getattr(_dist2, "__version__", "unknown")
                        self.logger.info(f"Dask import OK after patch: dask={_dv2}, distributed={_disv2}")
                    except Exception as _imp_e2:
                        raise RuntimeError(f"Dask remains unimportable after site-packages patch: {_imp_e2}")
                else:
                    raise RuntimeError("Unable to resolve site-packages path for project interpreter")
            except Exception as _patch_e:
                raise RuntimeError(f"Failed to ensure in-process dask importability: {_patch_e}")

        # If SLURM provider is requested, ensure this process can import dask_jobqueue.
        if cluster_provider == 'slurm':
            try:
                import dask_jobqueue as _dj  # type: ignore
                _djv = getattr(_dj, "__version__", "unknown")
            except Exception as _imp_e:
                try:
                    sp = subprocess.run(
                        [project_python, "-c", "import sysconfig; print(sysconfig.get_paths().get('purelib') or '')"],
                        capture_output=True,
                        text=True,
                        check=False,
                    )
                    site_pkgs = (sp.stdout or "").strip()
                    if site_pkgs:
                        if site_pkgs not in sys.path:
                            sys.path.insert(0, site_pkgs)
                        try:
                            import dask_jobqueue as _dj2  # type: ignore
                            _djv2 = getattr(_dj2, "__version__", "unknown")
                            self.logger.info(f"dask_jobqueue import OK after patch: {_djv2}")
                        except Exception as _imp_e2:
                            raise RuntimeError(
                                f"dask_jobqueue remains unimportable after site-packages patch: {_imp_e2}"
                            )
                    else:
                        raise RuntimeError("Unable to resolve site-packages path for project interpreter")
                except Exception as _patch_e:
                    raise RuntimeError(f"Failed to ensure in-process dask_jobqueue importability: {_patch_e}")

        # Prepare environment for running the pipeline
        env = os.environ.copy()
        if comm_compression:
            env['DASK_DISTRIBUTED__COMM__COMPRESSION'] = comm_compression
        else:
            env.setdefault('DASK_DISTRIBUTED__COMM__COMPRESSION', 'zlib')
        env['PYTHONUNBUFFERED'] = '1'
        env['PYTHONPATH'] = f"{self.project_dir / 'src'}:{env.get('PYTHONPATH', '')}".rstrip(':')
        for k, v in kv_env.items():
            env[k] = v

        provider_options = dict(provider_options or {})
        if comm_compression:
            provider_options.setdefault('comm_compression', comm_compression)

        # If a provider is requested, start it here, run pipeline, then stop it
        provider_obj = None
        if cluster_provider:
            self.logger.info(f"Starting provider: {cluster_provider} with {num_workers} workers")
            try:
                from expops.cluster.providers import SlurmClusterProvider, AnsibleClusterProvider
                if cluster_provider == 'slurm':
                    provider_obj = SlurmClusterProvider()
                elif cluster_provider == 'ansible':
                    provider_obj = AnsibleClusterProvider()
                else:
                    raise ValueError(f"Unknown provider: {cluster_provider}")
                # Ensure workers use the same Python interpreter as the prepared project environment
                provider_options = provider_options or {}
                cluster_kwargs = dict((provider_options.get('cluster_kwargs') or {}))
                cluster_kwargs.setdefault('python', project_python)
                provider_options['cluster_kwargs'] = cluster_kwargs
                _, addr = provider_obj.start(num_workers=num_workers, options=provider_options or {})
                if not addr:
                    raise RuntimeError("Failed to obtain scheduler address from provider")
                env['DASK_SCHEDULER_ADDRESS'] = str(addr)
                self.logger.info(f"Using Dask scheduler at {addr}")
                try:
                    print(f"Dask scheduler: {addr}")
                except Exception:
                    pass
            except Exception as e:
                if provider_obj:
                    try:
                        provider_obj.stop()
                    except Exception:
                        pass
                raise

        # Run the pipeline using the prepared interpreter
        self.logger.info(f"Running pipeline for project '{project_id}'")
        run_cmd = [project_python, "-m", "expops.main", "run", project_id]
        # Ensure inner processes honor this unique run log
        env['MLOPS_RUN_LOG_FILE'] = str(proj_log_file)
        env['MLOPS_ENV_READY'] = '1'
        # Prevent recursion back into the controller when the CLI decides how to run
        env['MLOPS_FORCE_LOCAL'] = '1'
        with open(proj_log_file, "a", encoding="utf-8") as lf:
            result = subprocess.run(run_cmd, env=env, stdout=lf, stderr=lf, text=True)
        rc = result.returncode
        try:
            with open(proj_log_file, "a", encoding="utf-8") as lf:
                lf.write(f"Inner run command exit code: {rc}\n")
        except Exception:
            pass
        # Try to extract and surface the run ID from the project log
        try:
            run_id_val = None
            with open(proj_log_file, "r", encoding="utf-8") as rf:
                for line in rf:
                    if "with run_id:" in line:
                        # e.g., Executing project 'my-project' with run_id: project-my-project-XXXX
                        idx = line.find("with run_id:")
                        if idx >= 0:
                            run_id_val = line[idx + len("with run_id:"):].strip().strip("'\"")
                    elif "ID: 'project-" in line:
                        # e.g., [NoOpTracker] Started run ... ID: 'project-...'
                        try:
                            start = line.index("ID: '") + 5
                            end = line.index("'", start)
                            run_id_val = line[start:end]
                        except Exception:
                            pass
            if run_id_val:
                print(f"Run ID: {run_id_val}")
        except Exception:
            pass
        # Always attempt to stop provider
        if provider_obj:
            try:
                provider_obj.stop()
            except Exception as e:
                self.logger.warning(f"Provider stop returned error: {e}")
        if rc != 0:
            try:
                print(f"Pipeline failed (exit code {rc}). See project log: {proj_log_file}")
            except Exception:
                pass
            raise SystemExit(rc)
        try:
            print("Pipeline completed successfully.")
        except Exception:
            pass
        self.logger.info("Project completed successfully via Dask scheduler.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Cluster Controller")
    parser.add_argument(
        "--project-dir",
        type=str,
        default=str(_WORKSPACE_ROOT),
        help="Base project directory on the cluster (defaults to repo root).",
    )
    parser.add_argument("--project-id", type=str, help="Project ID (e.g., my-project)")
    parser.add_argument("--compute-config", type=str, default=None, help="Path to compute_config.yaml (defaults to project's configs folder)")
    parser.add_argument("--log-file", type=str, default=None, help="Per-run project log file path (overrides auto timestamped path)")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    project_dir = Path(args.project_dir).resolve()
    controller = ClusterController(project_dir)
    if args.project_id:
        runtime_root = project_dir / args.project_id / f".{args.project_id}"
        controller.logs_dir = runtime_root / "logs"
        controller.artifacts_dir = runtime_root / "artifacts"
        controller._ensure_dirs()

    # Proactively print pointers so users can find logs even before re-exec (print once only)
    try:
        if not os.environ.get("MLOPS_LOG_POINTERS_PRINTED"):
            if args.project_id:
                proj_logs_dir = project_dir / args.project_id / f".{args.project_id}" / "logs"
            else:
                proj_logs_dir = project_dir / "unknown" / "logs"
            # Always use a fresh per-run log path unless explicitly overridden by --log-file
            if args.log_file:
                proj_log_file = Path(args.log_file)
            else:
                import time as _time
                ts = _time.strftime("%Y%m%d_%H%M%S")
                proj_log_file = proj_logs_dir / f"{args.project_id}_{ts}.log" if args.project_id else None
            if proj_log_file:
                proj_log_file.parent.mkdir(parents=True, exist_ok=True)
                os.environ["MLOPS_RUN_LOG_FILE"] = str(proj_log_file)
            print(f"Project: {args.project_id}", flush=True)
            if proj_log_file:
                print(f"Project log: {proj_log_file}", flush=True)
            os.environ["MLOPS_LOG_POINTERS_PRINTED"] = "1"
    except Exception as _e:
        logging.getLogger("CLUSTER_CONTROLLER").warning(f"Failed to print log pointers: {_e}")

    if not args.project_id:
        logging.getLogger("CLUSTER_CONTROLLER").error("Requires --project-id")
        return
    cache_base = _project_cache_base(args.project_id)
    env_file = cache_base / "python_interpreter.txt"
    env_file.parent.mkdir(parents=True, exist_ok=True)
    try:
        from expops.core.graph.pipeline_utils import setup_environment_and_write_interpreter
        project_python = setup_environment_and_write_interpreter(project_dir, args.project_id, env_file)
    except Exception as e:
        logging.getLogger("CLUSTER_CONTROLLER").error(f"Failed to set up environment: {e}")
        raise
    if Path(sys.executable).resolve() != Path(project_python).resolve():
        cmd = [project_python, str(Path(__file__).resolve()), "--project-dir", str(project_dir), "--project-id", args.project_id]
        if getattr(args, "compute_config", None):
            cmd.extend(["--compute-config", str(args.compute_config)])
        os.execv(cmd[0], cmd)
    default_compute_cfg_path = project_dir / args.project_id / "configs" / "compute_config.yaml"
    compute_cfg = {}
    cfg_path = Path(args.compute_config).resolve() if getattr(args, "compute_config", None) else default_compute_cfg_path
    if cfg_path.exists():
        try:
            with open(cfg_path, 'r') as f:
                compute_cfg = yaml.safe_load(f) or {}
            logging.getLogger("CLUSTER_CONTROLLER").info(f"Loaded compute config from: {cfg_path}")
        except Exception as e:
            logging.getLogger("CLUSTER_CONTROLLER").warning(f"Failed to read compute config at {cfg_path}: {e}")
            compute_cfg = {}

    # Extract values strictly from compute_config.yaml
    cluster_provider = compute_cfg.get('provider')
    cfg_num_workers = compute_cfg.get('num_workers')
    try:
        num_workers = int(cfg_num_workers) if cfg_num_workers is not None else 2
    except Exception:
        num_workers = 2
    provider_options: Optional[Dict[str, Any]] = None
    cfg_options = compute_cfg.get('options') if isinstance(compute_cfg, dict) else None
    if isinstance(cfg_options, dict):
        provider_options = dict(cfg_options)
    controller.run_project_with_dask(
        project_id=args.project_id,
        cluster_provider=cluster_provider,
        num_workers=num_workers,
        provider_options=provider_options,
    )


if __name__ == "__main__":
    main() 