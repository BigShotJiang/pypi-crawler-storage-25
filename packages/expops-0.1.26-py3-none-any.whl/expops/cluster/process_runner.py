#!/usr/bin/env python3
import argparse
import os
import sys
from pathlib import Path
import yaml

def _workspace_root() -> Path:
    raw = os.environ.get("MLOPS_WORKSPACE_DIR")
    if raw:
        try:
            return Path(raw).expanduser().resolve()
        except Exception:
            return Path(raw)
    return Path.cwd()


# Source-checkout support: when running on a shared filesystem, ensure <workspace>/src is importable.
WORKSPACE_ROOT = _workspace_root()
SRC_DIR = WORKSPACE_ROOT / "src"
if SRC_DIR.exists() and str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from expops.adapters.custom.custom_adapter import CustomModelAdapter
from expops.adapters.config_schema import AdapterConfig
from expops.core.compute_config import load_compute_config, map_compute_to_executor
from expops.core.hashing.data_hashing import compute_data_hash_from_config
from expops.core.workspace import get_workspace_root


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Run a single process of a project pipeline")
    p.add_argument("--project-id", required=True, help="Project ID, e.g., my-project")
    p.add_argument("--process", required=True, help="Process name to execute (e.g., data_preparation)")
    p.add_argument("--run-id", required=True, help="Shared run_id across processes")
    p.add_argument("--config", help="Path to project_config.yaml (optional)")
    return p.parse_args()


def load_project_config(project_id: str, config_path_arg: str | None) -> tuple[dict, Path]:
    project_path = WORKSPACE_ROOT / project_id
    if config_path_arg:
        config_path = Path(config_path_arg)
    else:
        config_path = project_path / "configs" / "project_config.yaml"
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)
    return config, project_path


def main() -> None:
    args = parse_args()
    platform_config, project_path = load_project_config(args.project_id, args.config)

    compute_cfg = load_compute_config(project_path / "configs" / "compute_config.yaml")
    executor_cfg = map_compute_to_executor(compute_cfg) or {}
    try:
        slurm_cpus = int(os.environ.get("SLURM_CPUS_PER_TASK") or os.environ.get("SLURM_CPUS_ON_NODE") or 0)
    except Exception:
        slurm_cpus = 0
    if slurm_cpus and (not isinstance(executor_cfg, dict) or not executor_cfg.get("n_workers")):
        suggested = max(1, slurm_cpus - 1) if slurm_cpus > 2 else slurm_cpus
        os.environ.setdefault("MLOPS_N_WORKERS", str(suggested))

    # Derive defaults for experiment header so project_config.yaml can omit them.
    meta_section = (platform_config.get("metadata") or {}) if isinstance(platform_config, dict) else {}
    exp_section_in = (platform_config.get("experiment") or {}) if isinstance(platform_config, dict) else {}
    exp_section = dict(exp_section_in) if isinstance(exp_section_in, dict) else {}
    if "framework" not in exp_section or exp_section.get("framework") in (None, ""):
        exp_section["framework"] = "custom"
    if "language" not in exp_section or exp_section.get("language") in (None, ""):
        exp_section["language"] = "python"
    if "name" not in exp_section or exp_section.get("name") in (None, ""):
        fallback_name = meta_section.get("name") or args.project_id or "model"
        exp_section["name"] = fallback_name
    if "version" not in exp_section or exp_section.get("version") in (None, ""):
        fallback_version = meta_section.get("version") or "0.0.0"
        exp_section["version"] = fallback_version
    platform_config["experiment"] = exp_section

    adapter_config = AdapterConfig(**platform_config.get("experiment", {}) or {})

    adapter = CustomModelAdapter(
        config=adapter_config,
        python_interpreter=sys.executable,
        project_path=project_path,
    )
    adapter.initialize()

    training_data = platform_config.get("data", {}).get("sources", {}).get("training", {}).get("path")
    training_data_path = None
    if training_data:
        p = Path(training_data)
        if p.is_absolute():
            training_data_path = p
        else:
            cand = (project_path / p)
            training_data_path = cand if cand.exists() else (WORKSPACE_ROOT / p)

    data_hash = None
    try:
        data_hash = compute_data_hash_from_config(
            platform_config,
            project_root=project_path,
            workspace_root=get_workspace_root(),
        )
    except FileNotFoundError as hash_err:
        print(f"[process_runner] Data path not found for hashing: {hash_err}")
    except Exception as hash_err:
        print(f"[process_runner] Failed to compute data hash: {hash_err}")

    adapter.run(
        data_paths={"training": training_data_path} if training_data_path else {},
        run_id=args.run_id,
        resume_from_process=args.process,
        single_process=True,
        data_hash=data_hash,
    )


if __name__ == "__main__":
    main() 