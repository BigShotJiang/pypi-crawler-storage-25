from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from datetime import datetime
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import time
import uuid

import yaml

from .adapters.plugin_manager import AdapterPluginManager
from .adapters.config_schema import AdapterConfig
from .managers.reproducibility_manager import ReproducibilityManager
from .managers.project_manager import ProjectManager
from .core.workspace import get_projects_root, get_workspace_root, infer_source_root, get_project_runtime_root


class MLPlatform:
    """Main platform class that orchestrates the ML pipeline."""
    
    def __init__(self) -> None:
        self.adapter_manager = AdapterPluginManager()
        # Adapter discovery already tries both `expops.*` and `src.expops.*` layouts.
        self.adapter_manager.discover_adapters("expops.adapters")

        # Track output directories of dynamic charts so we can upload artifacts later.
        self._dynamic_chart_outputs: list[tuple[str, Path]] = []

    def _repo_root(self) -> Path:
        # Legacy name; this is now the workspace root (where projects live).
        try:
            return get_workspace_root()
        except Exception:
            return Path.cwd()

    def _set_env_var(self, key: str, value: str) -> None:
        """Best-effort environment variable setter (never raises)."""
        try:
            os.environ[key] = value
        except Exception:
            pass

    def _get_env_python_map(self) -> Dict[str, str]:
        try:
            raw = os.environ.get("MLOPS_ENV_PYTHON_MAP") or ""
            if not raw:
                return {}
            parsed = json.loads(raw)
            if not isinstance(parsed, dict):
                return {}
            return {str(k): str(v) for k, v in parsed.items() if v}
        except Exception:
            return {}

    def _get_reporting_python_exec(self) -> str:
        try:
            env_map = self._get_env_python_map()
            reporting_env = os.environ.get("MLOPS_REPORTING_ENV") or ""
            if reporting_env and reporting_env in env_map:
                return env_map[reporting_env]
            default_env = os.environ.get("MLOPS_DEFAULT_ENV") or ""
            if default_env and default_env in env_map:
                return env_map[default_env]
            return os.environ.get("MLOPS_RUNTIME_PYTHON") or sys.executable
        except Exception:
            return sys.executable

    def _get_python_for_env(self, env_name: Optional[str]) -> str:
        try:
            env_map = self._get_env_python_map()
            if env_name and env_name in env_map:
                return env_map[env_name]
        except Exception:
            pass
        return self._get_reporting_python_exec()

    def _in_distributed_mode(self) -> bool:
        return bool(os.environ.get("DASK_SCHEDULER_ADDRESS") or os.environ.get("MLOPS_CLUSTER_MODE"))

    def _get_project_id_from_adapter(self, adapter: Any) -> str:
        try:
            ssm = getattr(adapter, 'step_state_manager', None)
            kv = getattr(ssm, 'kv_store', None) if ssm else None
            return (getattr(kv, 'project_id', None) if kv else None) or os.environ.get("MLOPS_PROJECT_ID") or ""
        except Exception:
            return os.environ.get("MLOPS_PROJECT_ID") or ""

    def _get_project_dir_hint(self, project_id: str):
        try:
            pm = ProjectManager()
            return pm.get_project_path(project_id)
        except Exception:
            return None

    def _resolve_entrypoint_path(self, entrypoint: str, project_dir_hint: Path | None = None) -> Path | None:
        try:
            ep = Path(entrypoint)
            if ep.is_absolute() and ep.exists():
                return ep
            if ep.exists():
                return ep
            if project_dir_hint:
                cand = (Path(project_dir_hint) / entrypoint)
                if cand.exists():
                    return cand
            ws = self._repo_root()
            cand = (ws / entrypoint)
            return cand if cand.exists() else None
        except Exception:
            return None

    def _default_reporting_entrypoint_path(self) -> Path | None:
        """Return the built-in reporting entrypoint file path (inside the installed package)."""
        try:
            import expops.reporting.entrypoint as _entry
            p = Path(getattr(_entry, "__file__", "") or "")
            return p if p.exists() else None
        except Exception:
            return None

    def _maybe_apply_cache_env(self, env: dict, platform_config: Dict[str, Any], project_dir_hint) -> None:
        cache_cfg = ((platform_config.get("experiment") or {}).get("cache") or {})
        if not isinstance(cache_cfg, dict):
            return
        backend_cfg = cache_cfg.get("backend") or {}
        if not isinstance(backend_cfg, dict):
            return

        gcp_project = backend_cfg.get("gcp_project")
        if gcp_project:
            env["GOOGLE_CLOUD_PROJECT"] = str(gcp_project)
        emulator_host = backend_cfg.get("emulator_host")
        if emulator_host:
            env["FIRESTORE_EMULATOR_HOST"] = str(emulator_host)
        creds_path = backend_cfg.get("credentials_json")
        if creds_path:
            try:
                creds_path_val = str(creds_path)
                if not Path(creds_path_val).is_absolute() and project_dir_hint:
                    creds_path_val = str(Path(project_dir_hint) / creds_path_val)
                env["GOOGLE_APPLICATION_CREDENTIALS"] = creds_path_val
            except Exception:
                pass

    def _ensure_repo_src_on_pythonpath(self, env: dict) -> None:
        src_root = infer_source_root()
        if not src_root:
            return
        repo_src = str(src_root / "src")
        prev_pp = str(env.get("PYTHONPATH", "") or "")
        if repo_src in prev_pp.split(":"):
            return
        env["PYTHONPATH"] = f"{repo_src}:{prev_pp}".rstrip(":")

    def _compute_config_hash(self, config_content: Dict[str, Any]) -> str:
        """Compute a stable hash of the configuration content (excluding run_id)."""
        logger = logging.getLogger(__name__)
        try:
            config_copy = dict(config_content)
            config_copy.pop("run_id", None)
            
            config_str = json.dumps(config_copy, sort_keys=True, default=str, separators=(",", ":"))
            
            return hashlib.sha256(config_str.encode()).hexdigest()
        except Exception as e:
            logger.warning(f"Failed to compute config hash: {e}. Falling back to random UUID-based hash.")
            return str(uuid.uuid4()).replace("-", "")[:16]

    def _generate_run_id(self, platform_config: Dict[str, Any], project_id: str | None = None) -> str:
        """Generate or extract run ID from configuration."""
        run_id_from_config = platform_config.get("run_id") 
        if run_id_from_config and run_id_from_config not in ["${RUN_ID:-auto-generated}", "auto-generated"]:
            return str(run_id_from_config)
        
        # Always add a unique suffix so every execution has a distinct run_id
        unique_suffix = datetime.utcnow().strftime("%Y%m%d%H%M%S") + "-" + uuid.uuid4().hex[:8]
        if project_id:
            return f"project-{project_id}-{unique_suffix}"
        return f"config-{unique_suffix}"

    def _prepare_run_metadata(self, platform_config: Dict[str, Any], run_id: str) -> Dict[str, Any]:
        """Prepare run metadata for tracking."""
        run_name = platform_config.get("metadata", {}).get("name", "ml-pipeline-run")
        run_tags = platform_config.get("metadata", {}).get("tags", {})
        if isinstance(run_tags, list):
            run_tags = {tag: "true" for tag in run_tags}
        
        return {
            "run_name": f"{run_name}-{run_id[:8]}",
            "run_id": run_id,
            "tags": run_tags
        }

    def _execute_pipeline(
        self,
        adapter,
        platform_config: Dict[str, Any],
        run_id: str,
        project_path: Optional[Path] = None,
    ) -> Dict[str, Any]:
        """Execute the ML pipeline using the specified adapter."""
        logger = logging.getLogger(__name__)
        print(f"[MLPlatform] Starting pipeline execution for run_id: {run_id}")
        
        
        dynamic_chart_processes = []
        try:
            dynamic_chart_processes = self._start_dynamic_charts(adapter, platform_config, run_id)
        except Exception as _dynamic_e:
            logger.warning(f"Failed to start dynamic charts: {_dynamic_e}")
        
        data_sources = platform_config.get("data", {}).get("sources", {})
        training_params = platform_config.get("training", {}).get("parameters", {})

        training_path_cfg = data_sources.get("training") or {}
        validation_path_cfg = data_sources.get("validation") or {}

        training_data_path = Path(training_path_cfg["path"]) if isinstance(training_path_cfg, dict) and training_path_cfg.get("path") else None
        validation_data_path = Path(validation_path_cfg["path"]) if isinstance(validation_path_cfg, dict) and validation_path_cfg.get("path") else None

        adapter_kwargs = dict(training_params) if isinstance(training_params, dict) else {}
        adapter_kwargs["data_paths"] = {}
        if training_data_path:
            adapter_kwargs["data_paths"]["training"] = training_data_path
        if validation_data_path:
            adapter_kwargs["data_paths"]["validation"] = validation_data_path

        # Provide selected top-level sections to adapters/workers for cache hashing hooks.
        full_cfg_hash = self._compute_config_hash(platform_config)
        cache_version_hash = None
        if project_path is not None:
            try:
                from .core.cache_probe.cache_layout import compute_cache_version_hash
                cache_version_hash = compute_cache_version_hash(Path(project_path))
            except Exception:
                pass
        adapter_kwargs["global_config_overrides"] = {
            "reproducibility": (platform_config.get("reproducibility", {}) or {}),
            "data": (platform_config.get("data", {}) or {}),
            "project_config_file_hash": full_cfg_hash,
        }
        if cache_version_hash:
            adapter_kwargs["global_config_overrides"]["cache_version_hash"] = cache_version_hash

        data_hash = None
        try:
            from expops.core.hashing.data_hashing import compute_data_hash_from_config
            data_hash = compute_data_hash_from_config(
                platform_config,
                project_root=project_path,
                workspace_root=get_workspace_root(),
            )
        except FileNotFoundError as hash_err:
            logger.warning(f"Data path not found for hashing: {hash_err}")
        except Exception as hash_err:
            logger.warning(f"Failed to compute data hash: {hash_err}")

        pipeline_results = adapter.run(
            data_paths=adapter_kwargs.get("data_paths"),
            run_id=run_id,
            data_hash=data_hash,
            **{k: v for k, v in adapter_kwargs.items() if k != "data_paths"}
        )
        print(f"[MLPlatform] Pipeline completed")

        try:
            if dynamic_chart_processes:
                is_distributed = self._in_distributed_mode()
                if is_distributed:
                    logger.info(f"Dynamic chart jobs submitted to cluster: {', '.join(dynamic_chart_processes)}")
                else:
                    pids = ", ".join([str(p.pid) for p in dynamic_chart_processes if getattr(p, "pid", None)])
                    logger.info(f"Dynamic chart(s) running in background (PIDs: {pids})")

                # Best-effort: upload artifacts produced by dynamic charts (async)
                try:
                    self._upload_dynamic_chart_artifacts_async(adapter, run_id)
                except Exception as _dyn_up_e:
                    logger.warning(f"Dynamic chart artifact upload failed: {_dyn_up_e}")
        except Exception as _report_e:
            logger.warning(f"Reporting failed: {_report_e}")

        return {
            "run_id": run_id,
            "pipeline_results": pipeline_results
        }

    def _get_reporting_cfg(self, platform_config: Dict[str, Any]) -> Dict[str, Any]:
        cfg = (platform_config or {}).get("reporting") or {}
        return cfg if isinstance(cfg, dict) else {}

    def _get_reporting_entrypoint(self, reporting_cfg: Dict[str, Any]) -> str:
        return str(reporting_cfg.get("static_entrypoint") or reporting_cfg.get("entrypoint") or "").strip()

    def _get_pipeline_cfg(self, platform_config: Dict[str, Any]) -> Dict[str, Any]:
        try:
            exp_cfg = (platform_config or {}).get("experiment") or {}
            pipeline_cfg = exp_cfg.get("pipeline") or {}
            return pipeline_cfg if isinstance(pipeline_cfg, dict) else {}
        except Exception:
            return {}

    def _resolve_script_key_from_spec(self, spec: Dict[str, Any], scripts_section: Dict[str, Any] | None, default_script: str | None) -> str | None:
        """
        Determine the script key for a process/spec using the new code-based convention.

        Precedence:
        - Explicit spec["script"] when present (legacy but still honored)
        - Prefix of spec["code"] when it looks like "<script_key>.<func_name>" and script_key exists in scripts
        - Fallback to default_script (first key in scripts) for backwards compatibility
        """
        try:
            script_key = spec.get("script")
        except Exception:
            script_key = None

        if not script_key:
            code_val = None
            try:
                code_val = spec.get("code")
            except Exception:
                code_val = None
            if isinstance(code_val, str) and scripts_section and isinstance(scripts_section, dict):
                if "." in code_val:
                    prefix = code_val.split(".", 1)[0].strip()
                    if prefix and prefix in scripts_section:
                        script_key = prefix

        if not script_key:
            script_key = default_script

        return script_key

    def _resolve_node_executable(self, logger: logging.Logger) -> str | None:
        """Resolve optional Node.js executable for JS backend chart processes."""
        def _resolve_candidate(value: str) -> str | None:
            resolved_local = None
            try:
                resolved_local = shutil.which(value)
            except Exception:
                resolved_local = None
            if not resolved_local:
                try:
                    candidate = Path(value).expanduser()
                    if candidate.exists() and os.access(candidate, os.X_OK):
                        resolved_local = str(candidate)
                except Exception:
                    resolved_local = None
            return resolved_local

        raw_exec = str(os.environ.get("MLOPS_NODE_EXECUTABLE") or "").strip()
        if raw_exec:
            resolved = _resolve_candidate(raw_exec)
            if resolved:
                return resolved
            logger.warning(
                "MLOPS_NODE_EXECUTABLE is set but not executable: %s. Falling back to PATH lookup for node.",
                raw_exec,
            )

        for candidate in ("node", "nodejs"):
            resolved = _resolve_candidate(candidate)
            if resolved:
                return resolved
        return None

    def _resolve_platform_mlops_charts_path(self) -> Optional[Path]:
        """Return path to platform mlops-charts.js for Node backend chart runs."""
        try:
            pkg_root = Path(__file__).resolve().parent
            candidate = pkg_root / "web" / "ui" / "mlops-charts.js"
            return candidate if candidate.exists() else None
        except Exception:
            return None

    def _write_dynamic_js_manifest(
        self,
        chart_out: Path,
        *,
        project_id: str,
        run_id: str,
        chart_name: str,
        script_path: str,
        resolved_script: Path | None,
        probe_paths: Any,
        node_executable: str | None,
    ) -> Path | None:
        """Write a small manifest artifact for frontend-rendered JS dynamic charts."""
        try:
            chart_out.mkdir(parents=True, exist_ok=True)
            manifest_path = chart_out / "dynamic_manifest.json"
            payload = {
                "project_id": str(project_id),
                "run_id": str(run_id),
                "chart_name": str(chart_name),
                "chart_type": "dynamic",
                "entrypoint_type": "javascript",
                "script_path": str(script_path),
                "resolved_script_path": str(resolved_script) if resolved_script else None,
                "probe_paths": probe_paths if isinstance(probe_paths, dict) else {},
                "backend_node_executable": str(node_executable) if node_executable else None,
                "mode": "backend-js-enabled" if node_executable else "frontend-only",
                "created_at": datetime.now().isoformat(),
            }
            with open(manifest_path, "w") as f:
                json.dump(payload, f, indent=2)
            return manifest_path
        except Exception:
            return None

    def _get_dynamic_chart_specs(self, platform_config: Dict[str, Any]) -> list[dict]:
        pipeline_cfg = self._get_pipeline_cfg(platform_config)
        processes = pipeline_cfg.get("processes") or []
        if not isinstance(processes, list):
            return []
        expanded_processes = []
        try:
            from expops.core.graph.networkx_parser import parse_networkx_pipeline_from_config
            from expops.core.graph.graph_expansion import expand_process_graph
            nx_cfg = parse_networkx_pipeline_from_config(pipeline_cfg)
            expanded_processes = expand_process_graph(nx_cfg.processes or [])
        except Exception:
            expanded_processes = []
        out: list[dict] = []
        for proc in processes:
            if not isinstance(proc, dict):
                continue
            if proc.get("probe_paths") is None:
                continue
            chart_type = str(proc.get("chart_type") or "static").lower()
            if chart_type == "dynamic":
                spec = dict(proc)
                if expanded_processes:
                    try:
                        from expops.core.cache_probe.probe_path_selectors import expand_probe_paths
                        spec["probe_paths"] = expand_probe_paths(spec.get("probe_paths") or {}, expanded_processes)
                    except Exception:
                        pass
                out.append(spec)
        return out

    def _resolve_reporting_entry_to_run(self, configured_entry: Path) -> tuple[Path, str | None]:
        """Resolve the actual script/module to run for reporting.

        If config points to a user script, run the framework entrypoint and import the user file.
        """
        default_entry = self._default_reporting_entrypoint_path()
        if default_entry is None:
            return configured_entry, None
        try:
            if configured_entry.resolve() != default_entry.resolve():
                return default_entry, str(configured_entry)
        except Exception:
            pass
        return default_entry, None

    def _start_dynamic_charts(self, adapter: Any, platform_config: Dict[str, Any], run_id: str) -> list:
        """Start dynamic charts as background processes (local) or cluster jobs (distributed).
        
        Returns list of subprocess.Popen objects (local) or job IDs (distributed) for tracking.
        """
        logger = logging.getLogger(__name__)
        
        # Detect if we're in cluster/distributed mode
        is_distributed = self._in_distributed_mode()
        
        if is_distributed:
            return self._start_dynamic_charts_distributed(adapter, platform_config, run_id)
        else:
            return self._start_dynamic_charts_local(adapter, platform_config, run_id)
    
    def _start_dynamic_charts_local(self, adapter: Any, platform_config: Dict[str, Any], run_id: str) -> list:
        """Start dynamic charts as local background processes.
        
        Returns list of subprocess.Popen objects for the started dynamic chart processes.
        """
        logger = logging.getLogger(__name__)
        
        project_id = self._get_project_id_from_adapter(adapter)

        dynamic_charts = self._get_dynamic_chart_specs(platform_config)
        if not dynamic_charts:
            return []

        project_dir_hint = self._get_project_dir_hint(project_id)

        # Output under .project_id/artifacts/<version_hash>/<encoded_probe_path>/
        try:
            if project_dir_hint:
                proj_root = Path(project_dir_hint)
            else:
                proj_root = get_projects_root(self._repo_root()) / project_id
            runtime_root = get_project_runtime_root(proj_root, project_id)
        except Exception:
            proj_root = Path.cwd()
            runtime_root = Path.cwd() / f".{project_id}"

        try:
            from expops.core.cache_probe.cache_layout import compute_cache_version_hash, build_artifact_relative_path
            from expops.core.cache_probe.probe_path import get_encoded_probe_path
            _version_hash = compute_cache_version_hash(proj_root)
        except Exception:
            _version_hash = "default"

        # Load scripts section for script key resolution (using code-based convention)
        scripts_section = platform_config.get("scripts") if isinstance(platform_config, dict) else None
        default_script = next(iter(scripts_section)) if scripts_section and isinstance(scripts_section, dict) else None
        from expops.core.graph.pipeline_utils import resolve_script_path
        node_exec = self._resolve_node_executable(logger)

        dynamic_processes = []
        
        for spec in dynamic_charts:
            name = str(spec.get("name") or "dynamic_chart").strip()
            script_key = self._resolve_script_key_from_spec(spec, scripts_section if isinstance(scripts_section, dict) else None, default_script)
            script_path = resolve_script_path(script_key, scripts_section, default_script) if scripts_section and script_key else None
            script_path = str(script_path).strip() if script_path else ""
            if not script_path:
                logger.warning(f"Dynamic chart '{name}' missing script; skipping.")
                continue
            try:
                # Dynamic charts should store artifacts under the chart process probe path
                # (the chart name), not under an upstream probed node.
                encoded_probe = get_encoded_probe_path(process_name=name, step_name=None)
            except Exception:
                encoded_probe = get_encoded_probe_path(process_name=name, step_name=None)
            rel_path = build_artifact_relative_path(_version_hash, encoded_probe)
            chart_out = runtime_root / "artifacts" / rel_path
            if script_path.lower().endswith(".js"):
                chart_script = self._resolve_entrypoint_path(script_path, project_dir_hint=project_dir_hint)
                manifest_path = self._write_dynamic_js_manifest(
                    chart_out,
                    project_id=project_id,
                    run_id=run_id,
                    chart_name=name,
                    script_path=script_path,
                    resolved_script=chart_script,
                    probe_paths=spec.get("probe_paths"),
                    node_executable=node_exec,
                )
                if not node_exec:
                    logger.warning(
                        "Dynamic chart '%s' missing Node executable; skipping. Set MLOPS_NODE_EXECUTABLE or ensure 'node' is on PATH for JS dynamic charts.",
                        name,
                    )
                    continue
                if not chart_script:
                    logger.warning(
                        "Dynamic chart '%s' script not found: %s; skipping.",
                        name,
                        script_path,
                    )
                    continue
                # Run Node from a dir that contains both the chart script and mlops-charts.js
                # so that import './mlops-charts.js' resolves (browser keeps using '/mlops-charts.js').
                try:
                    chart_out.mkdir(parents=True, exist_ok=True)
                except Exception:
                    pass
                mlops_charts_src = self._resolve_platform_mlops_charts_path()
                script_to_run = chart_script
                if mlops_charts_src and mlops_charts_src.exists() and chart_script.exists():
                    try:
                        dest_charts = chart_out / "mlops-charts.js"
                        shutil.copy2(mlops_charts_src, dest_charts)
                        script_content = chart_script.read_text(encoding="utf-8", errors="replace")
                        script_content = script_content.replace("from '/mlops-charts.js'", "from './mlops-charts.js'").replace('from "/mlops-charts.js"', 'from "./mlops-charts.js"')
                        script_to_run = chart_out / chart_script.name
                        script_to_run.write_text(script_content, encoding="utf-8")
                    except Exception as _copy_e:
                        logger.warning("Could not prepare chart dir for '%s': %s", name, _copy_e)
                        script_to_run = chart_script
                # Track for optional artifact upload if backend JS process emits PNGs.
                try:
                    self._dynamic_chart_outputs.append((name, chart_out))
                except Exception:
                    pass

                # Declare chart dir as ESM so Node does not re-parse or warn (MODULE_TYPELESS_PACKAGE_JSON).
                try:
                    (chart_out / "package.json").write_text('{"type": "module"}', encoding="utf-8")
                except Exception:
                    pass

                env = os.environ.copy()
                applied_run_env = False
                try:
                    from expops.runtime.env_export import export_run_env

                    rc = getattr(adapter, "run_context", None)
                    if rc is not None:
                        env.update(export_run_env(rc))
                        applied_run_env = True
                except Exception:
                    applied_run_env = False
                if project_id:
                    env["MLOPS_PROJECT_ID"] = project_id
                env["MLOPS_OUTPUT_DIR"] = str(chart_out)
                env["MLOPS_CHART_NAME"] = name
                env["MLOPS_RUN_ID"] = run_id
                env["MLOPS_CHART_TYPE"] = "dynamic"
                if not applied_run_env:
                    self._maybe_apply_cache_env(env, platform_config, project_dir_hint)
                if "probe_paths" in spec:
                    try:
                        env["MLOPS_PROBE_PATHS"] = json.dumps(spec.get("probe_paths"))
                    except Exception:
                        pass
                env["MLOPS_CHART_IMPORT_FILES"] = str(script_to_run)

                try:
                    logger.info(f"Starting JS dynamic chart backend runner '{name}' -> {chart_out}")
                    cmd = [str(node_exec), str(script_to_run)] + list(spec.get("args") or [])
                    proc = subprocess.Popen(cmd, env=env, cwd=str(chart_out))
                    dynamic_processes.append(proc)
                    logger.info(f"JS dynamic chart '{name}' backend runner started with PID {proc.pid}")
                except Exception as _js_e:
                    logger.warning(f"Failed to start JS dynamic chart backend runner '{name}': {_js_e}")
                continue
            
            try:
                chart_out.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
            # Track for later upload
            try:
                self._dynamic_chart_outputs.append((name, chart_out))
            except Exception:
                pass
            
            env = os.environ.copy()
            applied_run_env = False
            try:
                # Centralized env export for process boundaries (best-effort).
                from expops.runtime.env_export import export_run_env

                rc = getattr(adapter, "run_context", None)
                if rc is not None:
                    env.update(export_run_env(rc))
                    applied_run_env = True
            except Exception:
                applied_run_env = False
            if project_id:
                env["MLOPS_PROJECT_ID"] = project_id
            env["MLOPS_OUTPUT_DIR"] = str(chart_out)
            env["MLOPS_CHART_NAME"] = name
            env["MLOPS_RUN_ID"] = run_id
            env["MLOPS_CHART_TYPE"] = "dynamic"
            
            if not applied_run_env:
                self._maybe_apply_cache_env(env, platform_config, project_dir_hint)
            
            if "probe_paths" in spec:
                try:
                    env["MLOPS_PROBE_PATHS"] = json.dumps(spec.get("probe_paths"))
                except Exception:
                    pass

            chart_script = self._resolve_entrypoint_path(script_path, project_dir_hint=project_dir_hint)
            if not chart_script:
                logger.warning(f"Dynamic chart '{name}' script not found: {script_path}")
                continue
            env["MLOPS_CHART_IMPORT_FILES"] = str(chart_script)

            try:
                self._ensure_repo_src_on_pythonpath(env)
            except Exception as _path_e:
                logger.warning(f"Failed to set PYTHONPATH for dynamic chart '{name}': {_path_e}")

            env_name = spec.get("environment")
            reporting_python = self._get_python_for_env(str(env_name) if env_name else None)
            cmd = [reporting_python, "-u", "-m", "expops.reporting.entrypoint"]
            
            try:
                logger.info(f"Starting dynamic chart '{name}' in background -> {chart_out}")
                proc = subprocess.Popen(cmd, env=env, cwd=str(chart_out))
                dynamic_processes.append(proc)
                logger.info(f"Dynamic chart '{name}' started with PID {proc.pid}")
            except Exception as _e:
                logger.warning(f"Failed to start dynamic chart '{name}': {_e}")
        
        if dynamic_processes:
            logger.info(f"Started {len(dynamic_processes)} dynamic chart(s) in background")
        
        return dynamic_processes
    
    def _start_dynamic_charts_distributed(self, adapter: Any, platform_config: Dict[str, Any], run_id: str) -> list:
        """Start dynamic charts via the configured cluster provider.

        Returns list of provider-specific job identifiers (strings)."""
        provider = self._get_cluster_provider_name(adapter)
        if provider == "slurm":
            return self._start_dynamic_charts_distributed_slurm(adapter, platform_config, run_id)
        elif provider == "ansible":
            # Run on head node as a fallback; return labels as job ids
            procs = self._start_dynamic_charts_local(adapter, platform_config, run_id)
            return [f"pid-{getattr(p, 'pid', 'unknown')}" for p in (procs or [])]
        else:
            logging.getLogger(__name__).warning(f"Unknown cluster provider '{provider}'. Falling back to local dynamic charts.")
            procs = self._start_dynamic_charts_local(adapter, platform_config, run_id)
            return [f"pid-{getattr(p, 'pid', 'unknown')}" for p in (procs or [])]

    def _get_cluster_provider_name(self, adapter: Any) -> str:
        """Determine the cluster provider from env or project compute_config.yaml."""
        try:
            prov = os.environ.get("MLOPS_CLUSTER_PROVIDER")
            if isinstance(prov, str) and prov.strip():
                return prov.strip().lower()
        except Exception:
            pass
        # Try project compute_config.yaml
        project_id = self._get_project_id_from_adapter(adapter)
        project_dir_hint = self._get_project_dir_hint(project_id)
        if project_dir_hint:
            cfg_path = Path(project_dir_hint) / "configs" / "compute_config.yaml"
        else:
            cfg_path = get_projects_root(self._repo_root()) / project_id / "configs" / "compute_config.yaml"
        try:
            if cfg_path.exists():
                with open(cfg_path) as f:
                    data = yaml.safe_load(f) or {}
                provider = data.get("provider")
                if isinstance(provider, str) and provider.strip():
                    return provider.strip().lower()
        except Exception:
            pass
        return "slurm"

    def _start_dynamic_charts_distributed_slurm(self, adapter: Any, platform_config: Dict[str, Any], run_id: str) -> list:
        """Start dynamic charts by submitting SLURM sbatch jobs."""
        logger = logging.getLogger(__name__)

        project_id = self._get_project_id_from_adapter(adapter)

        dynamic_charts = self._get_dynamic_chart_specs(platform_config)
        if not dynamic_charts:
            return []
        project_dir_hint = self._get_project_dir_hint(project_id)

        # Output under .project_id/artifacts/<version_hash>/<encoded_probe_path>/
        try:
            if project_dir_hint:
                proj_root = Path(project_dir_hint)
            else:
                proj_root = get_projects_root(self._repo_root()) / project_id
            runtime_root = get_project_runtime_root(proj_root, project_id)
        except Exception:
            proj_root = Path.cwd()
            runtime_root = Path.cwd() / f".{project_id}"

        try:
            from expops.core.cache_probe.cache_layout import compute_cache_version_hash, build_artifact_relative_path
            from expops.core.cache_probe.probe_path import get_encoded_probe_path
            _version_hash = compute_cache_version_hash(proj_root)
        except Exception:
            _version_hash = "default"

        # Load scripts section for script key resolution (using code-based convention)
        scripts_section = platform_config.get("scripts") if isinstance(platform_config, dict) else None
        default_script = next(iter(scripts_section)) if scripts_section and isinstance(scripts_section, dict) else None
        from expops.core.graph.pipeline_utils import resolve_script_path
        node_exec = self._resolve_node_executable(logger)

        job_ids: list[str] = []
        for spec in dynamic_charts:
            name = str(spec.get("name") or "dynamic_chart").strip()
            script_key = self._resolve_script_key_from_spec(spec, scripts_section if isinstance(scripts_section, dict) else None, default_script)
            script_path = resolve_script_path(script_key, scripts_section, default_script) if scripts_section and script_key else None
            script_path = str(script_path).strip() if script_path else ""
            if not script_path:
                logger.warning(f"Dynamic chart '{name}' missing script; skipping.")
                continue
            try:
                # Dynamic charts should store artifacts under the chart process probe path
                # (the chart name), not under an upstream probed node.
                encoded_probe = get_encoded_probe_path(process_name=name, step_name=None)
            except Exception:
                encoded_probe = get_encoded_probe_path(process_name=name, step_name=None)
            rel_path = build_artifact_relative_path(_version_hash, encoded_probe)
            chart_out = runtime_root / "artifacts" / rel_path
            if script_path.lower().endswith(".js"):
                chart_script = self._resolve_entrypoint_path(script_path, project_dir_hint=project_dir_hint)
                manifest_path = self._write_dynamic_js_manifest(
                    chart_out,
                    project_id=project_id,
                    run_id=run_id,
                    chart_name=name,
                    script_path=script_path,
                    resolved_script=chart_script,
                    probe_paths=spec.get("probe_paths"),
                    node_executable=node_exec,
                )
                if not node_exec:
                    logger.info(
                        "Dynamic chart '%s' Node executable not found on launcher host; SLURM job will resolve Node on execution host.",
                        name,
                    )
                if not chart_script:
                    logger.warning(
                        "Dynamic chart '%s' script not found: %s; skipping.",
                        name,
                        script_path,
                    )
                    continue
                try:
                    self._dynamic_chart_outputs.append((name, chart_out))
                except Exception:
                    pass

                env_vars = []
                try:
                    rc = getattr(adapter, "run_context", None)
                    if rc is not None:
                        from expops.runtime.env_export import export_run_env
                        for k, v in export_run_env(rc).items():
                            if v is not None:
                                env_vars.append(f"{k}={v}")
                except Exception:
                    pass
                if project_id:
                    env_vars.append(f"MLOPS_PROJECT_ID={project_id}")
                try:
                    env_vars.append(f"MLOPS_WORKSPACE_DIR={self._repo_root()}")
                except Exception:
                    pass
                env_vars.append(f"MLOPS_OUTPUT_DIR={chart_out}")
                env_vars.append(f"MLOPS_CHART_NAME={name}")
                env_vars.append(f"MLOPS_RUN_ID={run_id}")
                env_vars.append("MLOPS_CHART_TYPE=dynamic")
                env_vars.append(f"MLOPS_CHART_IMPORT_FILES={chart_script}")

                tmp_env = {}
                self._maybe_apply_cache_env(tmp_env, platform_config, project_dir_hint)
                for k, v in tmp_env.items():
                    env_vars.append(f"{k}={v}")

                if "probe_paths" in spec:
                    try:
                        probe_paths_json = json.dumps(spec.get("probe_paths")).replace('"', '\\"')
                        env_vars.append(f'MLOPS_PROBE_PATHS="{probe_paths_json}"')
                    except Exception:
                        pass

                chart_cmd = f'"$NODE_EXEC" "{chart_script}"'
                sbatch_script = f"""#!/bin/bash
#SBATCH --job-name={name}
#SBATCH --output={chart_out}/slurm-%j.out
#SBATCH --error={chart_out}/slurm-%j.err
#SBATCH --time=01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G

# Export environment variables
{chr(10).join(f'export {var}' for var in env_vars)}

# Run from output dir so relative file writes go there
cd "$MLOPS_OUTPUT_DIR" || true

# Resolve Node on execution host (best-effort; backend JS runner is optional).
NODE_EXEC=""
if [ -n "${{MLOPS_NODE_EXECUTABLE:-}}" ]; then
  if command -v "${{MLOPS_NODE_EXECUTABLE}}" >/dev/null 2>&1; then
    NODE_EXEC="$(command -v "${{MLOPS_NODE_EXECUTABLE}}")"
  elif [ -x "${{MLOPS_NODE_EXECUTABLE}}" ]; then
    NODE_EXEC="${{MLOPS_NODE_EXECUTABLE}}"
  fi
fi
if [ -z "$NODE_EXEC" ] && command -v node >/dev/null 2>&1; then
  NODE_EXEC="$(command -v node)"
fi
if [ -z "$NODE_EXEC" ] && command -v nodejs >/dev/null 2>&1; then
  NODE_EXEC="$(command -v nodejs)"
fi
if [ -z "$NODE_EXEC" ]; then
  echo "[expops] Node executable not found on execution host; skipping JS backend runner for $MLOPS_CHART_NAME."
  exit 0
fi

# Run the chart
{chart_cmd}
"""
                submit_script = chart_out / f"submit_{name}.sh"
                try:
                    submit_script.write_text(sbatch_script)
                    submit_script.chmod(0o755)
                except Exception as e:
                    logger.warning(f"Failed to write sbatch script for '{name}': {e}")
                    continue
                try:
                    logger.info(f"Submitting JS dynamic chart '{name}' to cluster -> {chart_out}")
                    result = subprocess.run(["sbatch", str(submit_script)], capture_output=True, text=True, check=True)
                    output = result.stdout.strip()
                    if "Submitted batch job" in output:
                        job_id = output.split()[-1]
                        job_ids.append(job_id)
                        logger.info(f"JS dynamic chart '{name}' submitted as job {job_id}")
                    else:
                        logger.warning(f"Unexpected sbatch output for '{name}': {output}")
                except Exception as e:
                    logger.warning(f"Failed to submit JS dynamic chart '{name}': {e}")
                continue
            try:
                chart_out.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass
            try:
                self._dynamic_chart_outputs.append((name, chart_out))
            except Exception:
                pass

            env_vars = []
            try:
                rc = getattr(adapter, "run_context", None)
                if rc is not None:
                    from expops.runtime.env_export import export_run_env
                    for k, v in export_run_env(rc).items():
                        if v is not None:
                            env_vars.append(f"{k}={v}")
            except Exception:
                pass
            if project_id:
                env_vars.append(f"MLOPS_PROJECT_ID={project_id}")
            try:
                env_vars.append(f"MLOPS_WORKSPACE_DIR={self._repo_root()}")
            except Exception:
                pass
            env_vars.append(f"MLOPS_OUTPUT_DIR={chart_out}")
            env_vars.append(f"MLOPS_CHART_NAME={name}")
            env_vars.append(f"MLOPS_RUN_ID={run_id}")
            env_vars.append(f"MLOPS_CHART_TYPE=dynamic")

            chart_script = self._resolve_entrypoint_path(script_path, project_dir_hint=project_dir_hint)
            if not chart_script:
                logger.warning(f"Dynamic chart '{name}' script not found: {script_path}")
                continue
            env_vars.append(f"MLOPS_CHART_IMPORT_FILES={chart_script}")

            tmp_env = {}
            self._maybe_apply_cache_env(tmp_env, platform_config, project_dir_hint)
            for k, v in tmp_env.items():
                env_vars.append(f"{k}={v}")

            if "probe_paths" in spec:
                try:
                    probe_paths_json = json.dumps(spec.get("probe_paths")).replace('"', '\\"')
                    env_vars.append(f'MLOPS_PROBE_PATHS="{probe_paths_json}"')
                except Exception:
                    pass

            try:
                src_root = infer_source_root()
                if src_root and (src_root / "src").exists():
                    repo_src = str(src_root / "src")
                    env_vars.append(f"PYTHONPATH={repo_src}:$PYTHONPATH")
            except Exception:
                pass

            env_name = spec.get("environment")
            reporting_python = self._get_python_for_env(str(env_name) if env_name else None)
            chart_cmd = f"{reporting_python} -u -m expops.reporting.entrypoint"

            sbatch_script = f"""#!/bin/bash
#SBATCH --job-name={name}
#SBATCH --output={chart_out}/slurm-%j.out
#SBATCH --error={chart_out}/slurm-%j.err
#SBATCH --time=01:00:00
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem=4G

# Export environment variables
{chr(10).join(f'export {var}' for var in env_vars)}

# Run from output dir so relative file writes (e.g. plt.savefig) go there
cd "$MLOPS_OUTPUT_DIR" || true

# Run the chart
{chart_cmd}
"""

            script_path = chart_out / f"submit_{name}.sh"
            try:
                script_path.write_text(sbatch_script)
                script_path.chmod(0o755)
            except Exception as e:
                logger.warning(f"Failed to write sbatch script for '{name}': {e}")
                continue

            try:
                logger.info(f"Submitting dynamic chart '{name}' to cluster -> {chart_out}")
                result = subprocess.run(["sbatch", str(script_path)], capture_output=True, text=True, check=True)
                output = result.stdout.strip()
                if "Submitted batch job" in output:
                    job_id = output.split()[-1]
                    job_ids.append(job_id)
                    logger.info(f"Dynamic chart '{name}' submitted as job {job_id}")
                else:
                    logger.warning(f"Unexpected sbatch output for '{name}': {output}")
            except Exception as e:
                logger.warning(f"Failed to submit dynamic chart '{name}': {e}")

        if job_ids:
            logger.info(f"Submitted {len(job_ids)} dynamic chart(s) to cluster: {', '.join(job_ids)}")
        return job_ids
    
    def _upload_dynamic_chart_artifacts_async(self, adapter: Any, run_id: str) -> None:
        """Upload PNG artifacts from dynamic chart output directories asynchronously.
        
        This runs in a background thread to avoid blocking the main execution flow.
        """
        import threading
        logger = logging.getLogger(__name__)
        
        def _upload_worker():
            try:
                self._upload_dynamic_chart_artifacts(adapter, run_id)
            except Exception as e:
                logger.warning(f"Async dynamic chart upload failed: {e}")
        
        # Start upload in background thread
        upload_thread = threading.Thread(target=_upload_worker, daemon=True)
        upload_thread.start()
        logger.info("Dynamic chart artifact upload started in background")

    def _upload_dynamic_chart_artifacts(self, adapter: Any, run_id: str) -> None:
        """Upload PNG artifacts from dynamic chart output directories and record them in KV.
        
        Best-effort: skips silently if directories are missing or object store is unavailable.
        """
        logger = logging.getLogger(__name__)
        try:
            tracked: list = getattr(self, "_dynamic_chart_outputs", []) or []
        except Exception:
            tracked = []
        if not tracked:
            return
        uploaded_any = False
        for item in tracked:
            try:
                name, chart_out = item
            except Exception:
                continue
            try:
                # Ensure path is a Path
                chart_out = Path(chart_out)
            except Exception:
                continue
            if not chart_out.exists():
                # Skip missing dirs (e.g., remote-only paths)
                continue
            try:
                self._upload_single_chart_artifacts(adapter, run_id, name, chart_out, chart_type="dynamic")
                uploaded_any = True
            except Exception as _e:
                logger.warning(f"Dynamic chart upload failed for '{name}': {_e}")
        if uploaded_any:
            logger.info("Uploaded dynamic chart artifacts and recorded in KV store")

    def _upload_single_chart_artifacts(self, adapter: Any, run_id: str, name: str, chart_out: Path, chart_type: str | None = None) -> None:
        """Upload PNG artifacts for a single chart and record them in KV.

        Uses layout: <project_id>/artifacts/<version_hash>/<encoded_probe_path>/<filename>
        chart_type: optional "static" or "dynamic" for UI differentiation.
        """
        logger = logging.getLogger(__name__)
        ssm = getattr(adapter, 'step_state_manager', None)
        obj_store = getattr(ssm, 'object_store', None) if ssm else None
        kv = getattr(ssm, 'kv_store', None) if ssm else None
        try:
            project_ns = os.environ.get('MLOPS_PROJECT_ID', '')
        except Exception:
            project_ns = ''
        # Derive artifact relative path from chart_out: .../artifacts/<version_hash>/<encoded_probe_path>
        try:
            artifacts_root = chart_out
            while artifacts_root != artifacts_root.parent and artifacts_root.name != "artifacts":
                artifacts_root = artifacts_root.parent
            if artifacts_root.name == "artifacts":
                rel_path = chart_out.relative_to(artifacts_root)
            else:
                rel_path = Path(name)
        except Exception:
            rel_path = Path(name)
        rel_path_str = str(rel_path).replace("\\", "/")
        abs_artifacts_root = None
        try:
            if obj_store:
                bname = getattr(obj_store, "_bucket", None)
                if bname is not None:
                    bname = getattr(bname, "name", None)
                if not bname:
                    bname = getattr(obj_store, "_bucket_name", None)
                if bname:
                    abs_artifacts_root = f"gs://{bname}/{project_ns}/artifacts/{rel_path_str}"
        except Exception:
            abs_artifacts_root = None
        import time as _time
        artifacts: list[dict] = []
        # Capture PNGs recursively to support nested structures under chart output
        for p in chart_out.rglob("*.png"):
            obj_path = None
            # Always capture local cache path so UI can fetch from server if object store is unavailable
            try:
                local_path = str(p.resolve())
            except Exception:
                local_path = str(p)
            try:
                file_rel = str(p.relative_to(chart_out)).replace("\\", "/")
            except Exception:
                file_rel = p.name
            if obj_store:
                try:
                    if abs_artifacts_root:
                        remote = obj_store.build_uri(abs_artifacts_root, file_rel)
                    else:
                        base = f"{project_ns}/artifacts/{rel_path_str}"
                        remote = obj_store.build_uri(base, file_rel)
                    with open(p, 'rb') as f:
                        obj_store.put_bytes(remote, f.read(), content_type="image/png")
                    obj_path = remote
                except Exception as _ue:
                    logger.warning(f"Upload failed for chart '{name}' file {p.name}: {_ue}")
            if not obj_path:
                # Fallback to local cache path if no remote object path
                obj_path = local_path
            try:
                artifacts.append({
                    "title": p.name,
                    "object_path": obj_path,
                    "cache_path": local_path,
                    "mime_type": "image/png",
                    "size_bytes": p.stat().st_size,
                    "created_at": _time.time(),
                    "chart_type": (chart_type or "static"),
                })
            except Exception:
                pass
        # Record artifacts in KV store for UI listing
        try:
            if kv and hasattr(kv, 'record_run_chart_artifacts'):
                kv.record_run_chart_artifacts(run_id, name, artifacts)
        except Exception:
            pass

    # -------------------- Cloud bootstrap helpers --------------------

    def _configure_logging(self, config: Dict[str, Any], project_path: Path) -> None:
        """Configure Python logging system based on the config.

        Honors MLOPS_RUN_LOG_FILE env var to force a unique per-run log file.
        """
        env_log = os.environ.get("MLOPS_RUN_LOG_FILE")
        root_logger = logging.getLogger()
        if env_log:
            try:
                env_log_path = Path(env_log).resolve()
                for h in list(root_logger.handlers):
                    try:
                        if isinstance(h, logging.FileHandler):
                            handler_path = Path(getattr(h, "baseFilename", "")).resolve()
                            if handler_path == env_log_path:
                                return
                    except Exception:
                        continue
            except Exception:
                # Fall back to configuring logging below if path resolution fails.
                pass

        # Prefer explicit per-run log path if it is timestamped; otherwise, create a timestamped file
        # under the hidden runtime logs directory.
        try:
            runtime_root = get_project_runtime_root(project_path, project_path.name)
        except Exception:
            runtime_root = project_path / f".{project_path.name}"
        chosen_log_file: str
        if env_log:
            try:
                name = Path(env_log).name
                pattern = rf"^{re.escape(project_path.name)}_\d{{8}}_\d{{6}}\.log$"
                if re.match(pattern, name):
                    chosen_log_file = env_log
                else:
                    raise ValueError("Non-timestamped log path provided; overriding with timestamped path")
            except Exception:
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                chosen_log_file = str(runtime_root / "logs" / f"{project_path.name}_{ts}.log")
                self._set_env_var("MLOPS_RUN_LOG_FILE", chosen_log_file)
        else:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            chosen_log_file = str(runtime_root / "logs" / f"{project_path.name}_{ts}.log")
            self._set_env_var("MLOPS_RUN_LOG_FILE", chosen_log_file)
        log_path = Path(chosen_log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)

        handlers = [logging.FileHandler(str(log_path), encoding="utf-8")]
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=handlers,
            force=True
        )

        # Redirect stdout/stderr prints to the logging system so nothing goes to the terminal
        class _StreamToLogger:
            def __init__(self, logger: logging.Logger, level: int):
                self.logger = logger
                self.level = level
                self._buffer = ""

            def write(self, message: str) -> None:
                if not message:
                    return
                self._buffer += message
                while "\n" in self._buffer:
                    line, self._buffer = self._buffer.split("\n", 1)
                    if line.strip():
                        self.logger.log(self.level, line)

            def flush(self) -> None:
                if self._buffer.strip():
                    self.logger.log(self.level, self._buffer.strip())
                    self._buffer = ""

        root_logger = logging.getLogger()
        sys.stdout = _StreamToLogger(root_logger, logging.INFO)
        sys.stderr = _StreamToLogger(root_logger, logging.ERROR)

    def run_pipeline_for_project(self, project_id: str, config_path: str) -> Dict[str, Any]:
        """
        Run the ML pipeline for a specific project.
        
        Args:
            project_id: The project identifier
            config_path: Path to the project's configuration file
            
        Returns:
            Pipeline execution results
        """
        project_manager = ProjectManager()
        
        if not project_manager.project_exists(project_id):
            raise ValueError(f"Project '{project_id}' does not exist")
        
        project_path = project_manager.get_project_path(project_id)
        try:
            runtime_root = get_project_runtime_root(project_path, project_id)
        except Exception:
            runtime_root = project_path / f".{project_id}"

        # Ensure workers (e.g., Dask distributed) can resolve workspace-relative paths regardless of CWD.
        # Many components (templates, charts, cache backends) rely on this.
        try:
            self._set_env_var("MLOPS_WORKSPACE_DIR", str(get_workspace_root()))
        except Exception:
            pass
        
        with open(config_path) as f:
            platform_config = yaml.safe_load(f)
        
        self._update_config_for_project(platform_config, project_path, project_id)

        # Export project id so reporting and upload paths use the correct namespace.
        self._set_env_var("MLOPS_PROJECT_ID", str(project_id))
        
        self._configure_logging(platform_config, project_path)
        logger = logging.getLogger(__name__)
        
        repro_manager = ReproducibilityManager(config_path, project_path=project_path)
        
        repro_manager.ensure_reproducibility_setup()
        # Ensure both runtime and reporting environments are initialized so their interpreters are available
        try:
            repro_manager.setup_environment()
        except Exception as _env_e:
            logger.warning(f"Environment setup skipped or failed: {_env_e}")

        # Export the project runtime and reporting interpreters so auto-installs go into the venvs
        try:
            if getattr(repro_manager, 'python_interpreter', None):
                self._set_env_var("MLOPS_RUNTIME_PYTHON", str(repro_manager.python_interpreter))
        except Exception:
            pass
        try:
            env_map = getattr(repro_manager, "environment_python_map", None)
            if isinstance(env_map, dict) and env_map:
                self._set_env_var("MLOPS_ENV_PYTHON_MAP", json.dumps(env_map))
        except Exception:
            pass

        # Ensure expops (and all its dependencies) is installed in every non-primary environment
        # (e.g. reporting/chart envs). These envs only list chart-specific packages in their
        # requirements, so expops itself — and transitive deps like joblib — would be missing
        # unless we install it here.
        try:
            from expops.core.platform_install import ensure_platform_importable as _ensure_importable
            primary_py = str(getattr(repro_manager, "python_interpreter", "") or "")
            all_env_map = getattr(repro_manager, "environment_python_map", {}) or {}
            for _env_name, _env_py in all_env_map.items():
                if _env_py and _env_py != primary_py:
                    try:
                        logger.info(f"Ensuring expops is importable in environment '{_env_name}' ({_env_py})")
                        _ensure_importable(_env_py, import_module="expops.core")
                    except Exception as _ie:
                        logger.warning(f"Platform install in environment '{_env_name}' failed: {_ie}")
        except Exception as _all_env_e:
            logger.warning(f"Per-environment platform install check skipped: {_all_env_e}")
        try:
            default_env = getattr(repro_manager, "default_environment_name", None) or getattr(repro_manager, "environment_name", None)
            if default_env:
                self._set_env_var("MLOPS_DEFAULT_ENV", str(default_env))
        except Exception:
            pass
        try:
            rep_cfg_env = None
            rep_cfg_in = (platform_config or {}).get("reporting", {}) or {}
            if isinstance(rep_cfg_in, dict):
                rep_cfg_env = rep_cfg_in.get("environment")
            if not rep_cfg_env:
                rep_cfg_env = getattr(repro_manager, "default_environment_name", None) or getattr(repro_manager, "environment_name", None)
            if rep_cfg_env:
                self._set_env_var("MLOPS_REPORTING_ENV", str(rep_cfg_env))
        except Exception:
            pass

        # Export reporting config for workers (charts metadata and entrypoints)
        try:
            rep_cfg_in = (platform_config or {}).get('reporting', {}) or {}
            rep_cfg: dict = rep_cfg_in if isinstance(rep_cfg_in, dict) else {}
            # Include interpreter hints so chart runners can reliably select the reporting env
            # even when env propagation is imperfect (e.g., distributed workers).
            try:
                if getattr(repro_manager, "python_interpreter", None):
                    rep_cfg.setdefault("runtime_python", str(repro_manager.python_interpreter))
                default_env = getattr(repro_manager, "default_environment_name", None) or getattr(repro_manager, "environment_name", None)
                if default_env:
                    rep_cfg.setdefault("default_environment", str(default_env))
                    rep_cfg.setdefault("environment", str(default_env))
            except Exception:
                pass
            self._set_env_var("MLOPS_REPORTING_CONFIG", json.dumps(rep_cfg))
        except Exception:
            pass

        experiment_section = platform_config.get("experiment", {}) or {}
        try:
            repro_manager.apply_cloud_env_from_config(experiment_section)
            repro_manager.ensure_cloud_dependencies(experiment_section)
        except Exception as _cloud_e:
            logger.warning(f"Cloud bootstrap skipped or failed: {_cloud_e}")


        # Derive sensible defaults for experiment header fields so configs may omit them.
        meta_section = platform_config.get("metadata", {}) or {}
        exp_section = dict(experiment_section) if isinstance(experiment_section, dict) else {}
        if "framework" not in exp_section or exp_section.get("framework") in (None, ""):
            exp_section["framework"] = "custom"
        if "language" not in exp_section or exp_section.get("language") in (None, ""):
            exp_section["language"] = "python"
        if "name" not in exp_section or exp_section.get("name") in (None, ""):
            fallback_name = (
                meta_section.get("name")
                or (str(project_id) if project_id is not None else None)
                or "model"
            )
            exp_section["name"] = fallback_name
        if "version" not in exp_section or exp_section.get("version") in (None, ""):
            fallback_version = meta_section.get("version") or "0.0.0"
            exp_section["version"] = fallback_version
        platform_config["experiment"] = exp_section

        run_id = self._generate_run_id(platform_config, project_id)
        
        # Keep this exact substring ("with run_id:") stable; cluster controller parses it.
        print(f"Executing project '{project_id}' with run_id: {run_id}")

        try:
            model_config = AdapterConfig(**platform_config.get("experiment", {}) or {})

            # Build a typed run context so adapters/executors can avoid relying on implicit env vars.
            try:
                from expops.runtime.context import RunContext, parse_execution_workspace_config
                workspace_root = get_workspace_root()
                cache_cfg = ((platform_config.get("experiment") or {}).get("cache") or {})
                cache_cfg = cache_cfg if isinstance(cache_cfg, dict) else {}
                backend_cfg = cache_cfg.get("backend") or {}
                backend_cfg = backend_cfg if isinstance(backend_cfg, dict) else {}
                reporting_cfg = (platform_config.get("reporting") or {}) if isinstance(platform_config.get("reporting"), dict) else {}
                exec_cfg = (platform_config.get("execution") or {}) if isinstance(platform_config.get("execution"), dict) else {}
                execution_workspace = parse_execution_workspace_config(exec_cfg.get("workspace") if isinstance(exec_cfg.get("workspace"), dict) else None)
                env_map = {}
                try:
                    env_map = getattr(repro_manager, "environment_python_map", {}) or {}
                except Exception:
                    env_map = {}
                default_env = getattr(repro_manager, "default_environment_name", None) or getattr(repro_manager, "environment_name", None)
                reporting_env = None
                try:
                    reporting_env = reporting_cfg.get("environment") if isinstance(reporting_cfg, dict) else None
                except Exception:
                    reporting_env = None
                if not reporting_env:
                    reporting_env = default_env
                reporting_py = None
                try:
                    if reporting_env:
                        reporting_py = env_map.get(str(reporting_env))
                except Exception:
                    reporting_py = None
                run_context = RunContext(
                    workspace_root=workspace_root,
                    project_id=str(project_id),
                    project_root=project_path,
                    run_id=str(run_id),
                    runtime_python=getattr(repro_manager, "python_interpreter", None),
                    reporting_python=reporting_py,
                    env_python_map=dict(env_map) if isinstance(env_map, dict) else {},
                    default_environment=str(default_env) if default_env else None,
                    reporting_environment=str(reporting_env) if reporting_env else None,
                    cache_backend=dict(backend_cfg),
                    cache_config=dict(cache_cfg),
                    reporting_config=dict(reporting_cfg),
                    execution_workspace=execution_workspace,
                )
            except Exception:
                run_context = None

            adapter = self.adapter_manager.create_adapter(
                getattr(model_config, "framework", None) or "custom",
                model_config,
                python_interpreter=repro_manager.python_interpreter,
                environment_name=repro_manager.environment_name,
                project_path=project_manager.get_project_path(project_id),
                run_context=run_context,
            )
            
            if adapter is None:
                raise ValueError(f"Could not create adapter for framework: {getattr(model_config, 'framework', None)}")
            
            adapter.initialize()

            pipeline_results = self._execute_pipeline(adapter, platform_config, run_id, project_path=project_path)

            pipeline_results["artifact_paths"] = {}
            print(f"Project '{project_id}' pipeline execution completed successfully!")
            return pipeline_results
            
        except Exception as e:
            print(f"Pipeline execution failed: {e}")
            raise

    def _update_config_for_project(self, config: Dict[str, Any], project_path: Path, project_id: str) -> None:
        """Update configuration paths to be project-specific."""
        try:
            runtime_root = get_project_runtime_root(project_path, project_id)
        except Exception:
            runtime_root = project_path / f".{project_id}"
        repro = config.get("reproducibility")
        if isinstance(repro, dict):
            artifacts_config = repro.get("artifacts")
            if isinstance(artifacts_config, dict):
                data_cfg = artifacts_config.get("data")
                if isinstance(data_cfg, dict):
                    # Data path uses runtime root; artifacts layout is version/probe-scoped
                    data_cfg["path"] = str(runtime_root / "data")

            tracking_config = repro.get("experiment_tracking")
            if isinstance(tracking_config, dict):
                params = tracking_config.get("parameters")
                if isinstance(params, dict):
                    tracking_uri = params.get("tracking_uri")
                    if isinstance(tracking_uri, str) and "sqlite" in tracking_uri:
                        params["tracking_uri"] = f"sqlite:///{runtime_root}/artifacts/experiments.db"

    