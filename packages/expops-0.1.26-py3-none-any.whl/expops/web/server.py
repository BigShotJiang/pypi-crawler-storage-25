from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional
from pathlib import Path
import os

from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import mimetypes

from expops.core.workspace import get_projects_root, get_workspace_root
from expops.storage.factory import create_kv_store as _create_kv_store

WORKSPACE_ROOT = get_workspace_root()
PROJECTS_DIR = get_projects_root(WORKSPACE_ROOT)


def _app_version() -> str:
    try:
        from importlib.metadata import PackageNotFoundError, version  # type: ignore
        # Primary distribution name is `expops`; keep legacy aliases for older builds.
        for dist in ("expops", "mlops-platform", "mlops_platform"):
            try:
                v = version(dist)
                if v:
                    return str(v)
            except PackageNotFoundError:
                continue
            except Exception:
                continue
    except Exception:
        pass
    return "0.0.0"


app = FastAPI(title="MLOps Platform UI API", version=_app_version())
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # local dev only
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _is_project_dir(path: Path) -> bool:
    if not path.exists() or not path.is_dir():
        return False
    if (path / "configs" / "project_config.yaml").exists():
        return True
    return False


def _read_projects_index() -> Dict[str, Any]:
    # Enumerate project directories under the workspace root
    out: Dict[str, Any] = {}
    for child in sorted(PROJECTS_DIR.iterdir() if PROJECTS_DIR.exists() else []):
        if not _is_project_dir(child):
            continue
        out[child.name] = {"project_path": f"{child.name}", "description": ""}
    return out


def _parse_graph(project_id: str) -> Dict[str, Any]:
    # Lazy import to avoid runtime import for users not using the UI
    from expops.core.graph.pipeline_utils import parse_networkx_config_from_project, get_process_graph_summary
    cfg_like = parse_networkx_config_from_project(str(WORKSPACE_ROOT), project_id)
    return get_process_graph_summary(cfg_like)


def _load_cache_cfg(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Load cache config from experiment or model blocks.
    Prefer experiment.cache / model.cache; fall back to experiment.parameters.cache for legacy configs.
    """
    try:
        for root_key in ("experiment", "model"):
            root = cfg.get(root_key, {}) or {}
            if not isinstance(root, dict):
                continue
            # New path: experiment.cache
            cache = root.get("cache", {}) or {}
            if cache:
                return cache
            # Legacy path: experiment.parameters.cache
            params = root.get("parameters", {}) or {}
            cache = params.get("cache", {}) or {}
            if cache:
                return cache
    except Exception:
        return {}
    return {}


def _load_kv_cfg_from_project_config(project_id: str) -> Dict[str, Any]:
    """Best-effort load of KV backend config from <workspace>/<id>/configs/project_config.yaml."""
    try:
        import yaml
        cfg_path = PROJECTS_DIR / project_id / "configs" / "project_config.yaml"
        if not cfg_path.exists():
            return {}
        cfg = yaml.safe_load(cfg_path.read_text()) or {}
        cache = _load_cache_cfg(cfg)
        backend = cache.get("backend", {}) or {}
        return backend
    except Exception:
        return {}


def _load_object_store_cfg_from_project_config(project_id: str) -> Dict[str, Any]:
    """Load object_store config from <workspace>/<id>/configs/project_config.yaml."""
    try:
        import yaml
        cfg_path = PROJECTS_DIR / project_id / "configs" / "project_config.yaml"
        if not cfg_path.exists():
            return {}
        cfg = yaml.safe_load(cfg_path.read_text()) or {}
        cache = _load_cache_cfg(cfg)
        store = cache.get("object_store", {}) or {}
        return store
    except Exception:
        return {}


def _kv_for_project(project_id: str):
    backend_cfg = _load_kv_cfg_from_project_config(project_id)
    project_root = PROJECTS_DIR / project_id
    env_for_factory: dict[str, str] | os._Environ[str] = os.environ
    backend_type = _norm_backend_type((backend_cfg or {}).get("type"))
    try:
        if isinstance(backend_cfg, dict) and str(backend_cfg.get("type") or "").strip():
            env_for_factory = dict(os.environ)
            env_for_factory.pop("MLOPS_KV_BACKEND", None)
    except Exception:
        env_for_factory = os.environ
    if not backend_type:
        try:
            env_for_factory = dict(env_for_factory)
            env_for_factory.setdefault("MLOPS_LOCAL_RUN", "1")
        except Exception:
            pass
    return _create_kv_store(
        project_id,
        backend_cfg if isinstance(backend_cfg, dict) else {},
        env=env_for_factory,
        workspace_root=WORKSPACE_ROOT,
        project_root=project_root,
    )

def _parse_ts(val: Any) -> Optional[float]:
    if not val:
        return None
    try:
        if isinstance(val, (int, float)):
            return float(val)
        s = str(val)
        try:
            return datetime.fromisoformat(s).timestamp()
        except Exception:
            return float(s)
    except Exception:
        return None


def _safe_float(v: Any) -> Optional[float]:
    try:
        return float(v) if v is not None else None
    except Exception:
        return None


def _derive_process_info(
    steps: Dict[str, Any],
) -> tuple[Dict[str, str], Dict[str, Dict[str, Any]]]:
    process_status: Dict[str, str] = {}
    process_info: Dict[str, Dict[str, Any]] = {}
    rank = {"completed": 4, "failed": 4, "cached": 4, "running": 3, "": 0}

    for key, rec in steps.items():
        proc = str(rec.get("process_name") or (key.split(".")[0] if isinstance(key, str) and "." in key else ""))
        st = str(rec.get("status") or "").lower()
        if not proc:
            continue
        prev = process_status.get(proc)
        st_effective = "running" if (prev == "running" and st in ("", "pending")) else st
        if prev is None or rank.get(st_effective, 0) > rank.get(prev, 0):
            process_status[proc] = st_effective

        info = process_info.setdefault(
            proc,
            {"status": "pending", "started_at": None, "ended_at": None, "duration_sec": None},
        )
        step_name = str(rec.get("step_name") or (key.split(".", 1)[1] if isinstance(key, str) and "." in key else ""))
        is_summary = step_name == "__process__"
        ts_start = _parse_ts(rec.get("started_at")) if is_summary else None
        ts_end = _parse_ts(rec.get("ended_at")) if is_summary else None
        exec_time = _safe_float(rec.get("execution_time"))

        if is_summary:
            if st:
                info["status"] = st
            if st in ("completed", "cached", "failed") and isinstance(exec_time, float) and exec_time > 0:
                info["duration_sec"] = exec_time
            if isinstance(ts_start, float):
                cur = info.get("started_at")
                info["started_at"] = min(cur, ts_start) if isinstance(cur, (int, float)) else ts_start
            if isinstance(ts_end, float):
                cur = info.get("ended_at")
                info["ended_at"] = max(cur, ts_end) if isinstance(cur, (int, float)) else ts_end
        else:
            if st == "failed":
                info["status"] = "failed"
            elif st in ("completed", "cached") and info["status"] not in ("failed", "completed", "cached"):
                if isinstance(info.get("started_at"), (int, float)):
                    info["status"] = "running"
            elif st == "running":
                info["status"] = "running"

    now_ts = datetime.now().timestamp()
    for proc, info in process_info.items():
        if proc in process_status:
            info["status"] = process_status[proc]
        cur_status = str(info.get("status") or "").lower()
        if cur_status == "running":
            info["ended_at"] = None
        sa, ea = info.get("started_at"), info.get("ended_at")
        if isinstance(sa, float) and isinstance(ea, float):
            diff = max(0.0, ea - sa)
            cur_dur = _safe_float(info.get("duration_sec"))
            if cur_dur is None or cur_dur <= 0.0:
                info["duration_sec"] = diff
        if cur_status == "running" and isinstance(sa, float):
            live = max(0.0, now_ts - sa)
            cur_dur = _safe_float(info.get("duration_sec"))
            if cur_dur is None or cur_dur <= 0.0 or live > cur_dur:
                info["duration_sec"] = live
        if not info.get("status"):
            info["status"] = "pending"
    return process_status, process_info


def _get_run_status_snapshot(project_id: str, run_id: str) -> Dict[str, Any]:
    kv = _kv_for_project(project_id)
    status: Optional[str] = None
    steps: Dict[str, Any] = {}
    try:
        status = kv.get_run_status(run_id)
        steps = kv.list_run_steps(run_id) or {}
    except Exception:
        pass
    process_status, process_info = _derive_process_info(steps)
    return {
        "status": status or "unknown",
        "steps": steps,
        "process_status": process_status,
        "process_info": process_info,
    }


def _get_probe_path_candidates(project_id: str, probe_path: str, cfg: Dict[str, Any] | None = None) -> list[str]:
    from expops.core.cache_probe.probe_path_selectors import is_probe_path_xpath, resolve_probe_paths_for_kv_lookup

    if not is_probe_path_xpath(probe_path):
        return [probe_path]
    expanded = load_expanded_processes_for_project(project_id, cfg=cfg)
    if not expanded:
        return [probe_path]
    try:
        resolved = resolve_probe_paths_for_kv_lookup(probe_path, expanded)
        return resolved if resolved else [probe_path]
    except Exception:
        return [probe_path]


def _norm_backend_type(value: Any) -> str:
    """Normalize backend type strings (aligns with expops.storage.factory)."""
    try:
        s = str(value or "").strip().lower()
    except Exception:
        return ""
    aliases = {
        "sqlite": "local",
        "firestore": "gcp",
    }
    return aliases.get(s, s)


def resolve_effective_kv_backend_for_listener(
    project_id: str,
) -> tuple[str, Dict[str, Any]]:
    """Return (effective_backend_type, backend_cfg) matching create_kv_store / _kv_for_project.

    The webapp must use the same listener mode (Firestore vs local SSE) as the KV store
    actually uses. Previously backend-config only read YAML ``type``, so it could report
    ``local`` while MLOPS_KV_BACKEND or env made the server use GCP/Firestore.
    """
    backend_cfg = _load_kv_cfg_from_project_config(project_id)
    env_for_factory: dict[str, str] = dict(os.environ)
    backend_type = _norm_backend_type((backend_cfg or {}).get("type"))
    try:
        if isinstance(backend_cfg, dict) and str(backend_cfg.get("type") or "").strip():
            env_for_factory = dict(os.environ)
            env_for_factory.pop("MLOPS_KV_BACKEND", None)
    except Exception:
        env_for_factory = dict(os.environ)
    if not backend_type:
        try:
            env_for_factory = dict(env_for_factory)
            env_for_factory.setdefault("MLOPS_LOCAL_RUN", "1")
        except Exception:
            pass
    env_backend = env_for_factory.get("MLOPS_KV_BACKEND")
    cfg = backend_cfg if isinstance(backend_cfg, dict) else {}
    effective = _norm_backend_type(env_backend or cfg.get("type") or "")
    if not effective:
        effective = "local"
    return effective, cfg


def _resolve_firebase_api_key(
    backend_cfg: Dict[str, Any],
    project_id: str,
) -> Optional[str]:
    """Resolve the Firebase API key from config, file, or environment.

    Precedence:
    1. Inline ``firebase_api_key`` in backend config (backward compat)
    2. ``firebase_api_key_file`` – relative path resolved against the project dir
    3. ``FIREBASE_API_KEY`` environment variable
    4. ``NEXT_PUBLIC_FIREBASE_API_KEY`` environment variable
    """
    # 1. Inline value
    inline = str(backend_cfg.get("firebase_api_key") or "").strip()
    if inline:
        return inline

    # 2. File path
    key_file_rel = backend_cfg.get("firebase_api_key_file")
    if key_file_rel:
        try:
            key_path = (PROJECTS_DIR / project_id / str(key_file_rel)).resolve()
            if key_path.exists():
                value = key_path.read_text().strip()
                if value:
                    return value
        except Exception:
            pass

    # 3. Environment variable fallbacks
    return (
        os.getenv("FIREBASE_API_KEY")
        or os.getenv("NEXT_PUBLIC_FIREBASE_API_KEY")
        or None
    )


@app.get("/api/projects")
def list_projects() -> Dict[str, Any]:
    idx = _read_projects_index()
    return {"projects": sorted(idx.keys())}


def _object_store_for_project(project_id: str):
    cfg = _load_object_store_cfg_from_project_config(project_id)
    if not isinstance(cfg, dict):
        return None
    typ = str(cfg.get("type", "")).lower()
    if typ == "gcs":
        try:
            # Set up credentials if provided in the KV backend config (same credentials used for both)
            backend_cfg = _load_kv_cfg_from_project_config(project_id)
            if isinstance(backend_cfg, dict):
                creds_rel = backend_cfg.get("credentials_json")
                if creds_rel and not os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
                    cred_path = PROJECTS_DIR / project_id / creds_rel
                    if cred_path.exists():
                        os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS", str(cred_path.resolve()))
            from expops.storage.adapters.gcs_object_store import GCSObjectStore  # type: ignore
            bucket = cfg.get("bucket")
            if not bucket:
                return None
            # Prefix values in config are ignored; manifests and artifacts carry
            # full gs:// URIs generated by the state manager.
            return GCSObjectStore(bucket=bucket)
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"Failed to initialize GCS object store: {e}")
            return None
    return None


@app.get("/api/projects/{project_id}/runs")
def list_runs(project_id: str) -> Dict[str, Any]:
    kv = _kv_for_project(project_id)
    try:
        runs = kv.list_runs()
    except Exception:
        runs = []
    return {"runs": runs}


@app.get("/api/projects/{project_id}/graph")
def get_graph(project_id: str) -> Dict[str, Any]:
    try:
        graph = _parse_graph(project_id)
        return graph
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse graph: {e}")


@app.get("/api/projects/{project_id}/runs/{run_id}/status")
def get_run_status(project_id: str, run_id: str) -> Dict[str, Any]:
    return _get_run_status_snapshot(project_id, run_id)


def _resolve_script_key_for_proc_charts(
    proc: Dict[str, Any], scripts: Dict[str, Any] | None, default_key: str | None
) -> str | None:
    """Determine script key for a process using script or code (\"<script_key>.<func>\")."""
    try:
        script_key = proc.get("script")
    except Exception:
        script_key = None

    if not script_key:
        code_val = None
        try:
            code_val = proc.get("code")
        except Exception:
            code_val = None
        if isinstance(code_val, str) and scripts and isinstance(scripts, dict):
            if "." in code_val:
                prefix = code_val.split(".", 1)[0].strip()
                if prefix and prefix in scripts:
                    script_key = prefix

    if not script_key:
        script_key = default_key

    return script_key


def expand_process_graph_after_script_paths(
    pipeline_cfg: Dict[str, Any],
    processes: list[Any],
    scripts_section: Any,
    default_script: str | None,
) -> list[Any]:
    """Resolve script_path on process dicts and expand the pipeline graph (shared with chart-config)."""
    from expops.core.graph.pipeline_utils import resolve_script_path

    for proc in processes:
        if isinstance(proc, dict):
            sk = _resolve_script_key_for_proc_charts(
                proc, scripts_section if isinstance(scripts_section, dict) else None, default_script
            )
            if sk and scripts_section:
                sp = resolve_script_path(sk, scripts_section, default_script)
                if sp:
                    proc["script_path"] = sp
    try:
        from expops.core.graph.networkx_parser import parse_networkx_pipeline_from_config
        from expops.core.graph.graph_expansion import expand_process_graph

        nx_cfg = parse_networkx_pipeline_from_config(pipeline_cfg, scripts_section=scripts_section)
        return list(expand_process_graph(nx_cfg.processes or []))
    except Exception:
        return []


def load_expanded_processes_for_project(project_id: str, cfg: Dict[str, Any] | None = None) -> list[Any]:
    """Load project_config.yaml and return expanded processes for XPath / metrics resolution.

    If *cfg* is provided it is used directly; otherwise falls back to reading
    from the local filesystem.
    """
    try:
        import yaml

        if cfg is None:
            cfg_path = PROJECTS_DIR / project_id / "configs" / "project_config.yaml"
            if not cfg_path.exists():
                return []
            cfg = yaml.safe_load(cfg_path.read_text()) or {}
        if not isinstance(cfg, dict):
            return []
        scripts_section = cfg.get("scripts") if isinstance(cfg, dict) else None
        default_script = (
            next(iter(scripts_section)) if scripts_section and isinstance(scripts_section, dict) else None
        )
        exp_cfg = cfg.get("experiment", {}) if isinstance(cfg, dict) else {}
        params_cfg = (exp_cfg.get("parameters", {}) or {}) if isinstance(exp_cfg, dict) else {}
        pipeline_cfg = (exp_cfg.get("pipeline") or params_cfg.get("pipeline") or {}) if isinstance(exp_cfg, dict) else {}
        if not isinstance(pipeline_cfg, dict):
            pipeline_cfg = {}
        processes = pipeline_cfg.get("processes", []) or []
        if not isinstance(processes, list):
            processes = []
        return expand_process_graph_after_script_paths(
            pipeline_cfg, processes, scripts_section, default_script
        )
    except Exception:
        return []


def _get_chart_config_impl(project_id: str, cfg: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Core chart-config logic.

    If *cfg* is provided it is used directly; otherwise falls back to reading
    ``project_config.yaml`` from the local filesystem.
    """
    try:
        import yaml
        if cfg is None:
            cfg_path = PROJECTS_DIR / project_id / "configs" / "project_config.yaml"
            if not cfg_path.exists():
                return {"charts": [], "entrypoint": None}
            cfg = yaml.safe_load(cfg_path.read_text()) or {}
        project_root = PROJECTS_DIR / project_id
        scripts_section = cfg.get("scripts") if isinstance(cfg, dict) else None
        default_script = next(iter(scripts_section)) if scripts_section and isinstance(scripts_section, dict) else None

        # Support both new-style structured `reporting` blocks and legacy string paths.
        raw_reporting = cfg.get("reporting", {}) or {}
        if isinstance(raw_reporting, dict):
            reporting_cfg = raw_reporting
        else:
            # Legacy config: `reporting: "path/to/plot_metrics.py"` (string)
            # Treat this as a static entrypoint hint while keeping an empty
            # reporting config for charts.
            reporting_cfg = {}
        exp_cfg = cfg.get("experiment", {}) if isinstance(cfg, dict) else {}
        params_cfg = (exp_cfg.get("parameters", {}) or {}) if isinstance(exp_cfg, dict) else {}
        # Pipeline lives at experiment.pipeline (premier-league, sklearn-component); legacy at experiment.parameters.pipeline
        pipeline_cfg = (exp_cfg.get("pipeline") or params_cfg.get("pipeline") or {}) if isinstance(exp_cfg, dict) else {}
        if not isinstance(pipeline_cfg, dict):
            pipeline_cfg = {}
        processes = pipeline_cfg.get("processes", []) or []
        if not isinstance(processes, list):
            processes = []

        expanded_processes = expand_process_graph_after_script_paths(
            pipeline_cfg, processes, scripts_section, default_script
        )

        charts_list = reporting_cfg.get("charts", []) or []
        # New config keys: prefer explicit dynamic_entrypoint for web UI JS, then derive from static_entrypoint, then legacy entrypoint.
        dyn_entry_cfg = str(reporting_cfg.get("dynamic_entrypoint", "") or "").strip()
        static_entry_cfg = str(reporting_cfg.get("static_entrypoint", "") or "").strip()
        legacy_entry_cfg = str(reporting_cfg.get("entrypoint", "") or "").strip()
        # Legacy fallback: when `reporting` was a bare string path, treat it as
        # a static Python entrypoint if no structured keys were provided.
        if not dyn_entry_cfg and not static_entry_cfg and not legacy_entry_cfg and isinstance(raw_reporting, str):
            legacy_str = raw_reporting.strip()
            if legacy_str:
                static_entry_cfg = legacy_str

        def _entrypoint_exists(candidate_path: str | Path) -> bool:
            cand = Path(candidate_path)
            if cand.exists():
                return True
            if cand.is_absolute():
                return False
            if (project_root / cand).exists():
                return True
            if (WORKSPACE_ROOT / cand).exists():
                return True
            return False

        def _projects_static_entrypoint(entrypoint: str | None) -> str | None:
            """Return an entrypoint path relative to PROJECTS_DIR for /projects mount.

            Examples:
            - "src/plot_metrics.js" -> "<project_id>/src/plot_metrics.js"
            - "<project_id>/src/plot_metrics.js" -> unchanged
            - absolute path under project root -> "<project_id>/src/plot_metrics.js"
            """
            raw = str(entrypoint or "").strip()
            if not raw:
                return None
            p = Path(raw)
            normalized_project_prefix = f"{project_id}/"
            # Already in project-scoped static form.
            if raw.startswith(normalized_project_prefix):
                return raw

            # Absolute path that points into this project directory.
            if p.is_absolute():
                try:
                    rel = p.resolve().relative_to(project_root.resolve())
                    return f"{project_id}/{str(rel).replace(os.sep, '/')}"
                except Exception:
                    # Non-project absolute paths are not valid for /projects static mount.
                    return None

            # Relative path: scope it to project directory for /projects mount.
            return f"{project_id}/{raw.lstrip('/')}"
        
        # Resolve JS entrypoint for frontend dynamic charts
        js_entrypoint = None
        # 1) Explicit dynamic_entrypoint (expected to be a .js path under <id>/charts)
        if dyn_entry_cfg:
            if _entrypoint_exists(dyn_entry_cfg):
                js_entrypoint = dyn_entry_cfg
        # 2) Derive from static_entrypoint (.py -> .js)
        if not js_entrypoint and static_entry_cfg:
            py_path = Path(static_entry_cfg)
            js_path = py_path.with_suffix('.js')
            if _entrypoint_exists(js_path):
                js_entrypoint = str(js_path)
        # 3) Legacy: derive from entrypoint (.py -> .js)
        if not js_entrypoint and legacy_entry_cfg:
            py_path = Path(legacy_entry_cfg)
            js_path = py_path.with_suffix('.js')
            if _entrypoint_exists(js_path):
                js_entrypoint = str(js_path)

        def _expand_probe_paths(paths: Any) -> dict:
            try:
                from expops.core.cache_probe.probe_path_selectors import expand_probe_paths
                return expand_probe_paths(paths or {}, expanded_processes or [])
            except Exception:
                return paths or {}
        
        chart_map: Dict[str, Dict[str, Any]] = {}
        pipeline_js_entrypoint = None
        for proc in processes:
            if not isinstance(proc, dict):
                continue
            name = str(proc.get("name") or "").strip()
            if not name:
                continue
            probe_paths = proc.get("probe_paths")
            proc_type = str(proc.get("type") or "process").lower()
            chart_type = str(proc.get("chart_type") or "static").lower()
            is_chart = proc_type == "chart" or probe_paths is not None or proc.get("chart_type") is not None
            if not is_chart:
                continue
            chart_map[name] = {
                "name": name,
                "type": chart_type,
                "probe_paths": _expand_probe_paths(probe_paths),
            }
            if not js_entrypoint and not pipeline_js_entrypoint and chart_type == "dynamic":
                script_path = str(proc.get("script_path") or "").strip()
                if script_path.lower().endswith(".js"):
                    if _entrypoint_exists(script_path):
                        pipeline_js_entrypoint = script_path
        
        for chart_def in charts_list:
            if not isinstance(chart_def, dict):
                continue
            name = str(chart_def.get("name") or "").strip()
            if not name:
                continue
            chart_map[name] = {
                "name": name,
                "type": str(chart_def.get("type", "static") or "static").lower(),
                "probe_paths": _expand_probe_paths(chart_def.get("probe_paths")),
            }
        
        if not js_entrypoint and pipeline_js_entrypoint:
            js_entrypoint = pipeline_js_entrypoint

        js_entrypoint = _projects_static_entrypoint(js_entrypoint)
        
        result_charts = list(chart_map.values())
        
        return {
            "charts": result_charts,
            "entrypoint": js_entrypoint
        }
    except Exception as e:
        return {"charts": [], "entrypoint": None, "error": str(e)}


@app.get("/api/projects/{project_id}/chart-config")
def get_chart_config(project_id: str) -> Dict[str, Any]:
    """Get chart configuration from project_config.yaml including probe_paths."""
    return _get_chart_config_impl(project_id)


def _normalize_chart_key(name: str) -> str:
    """Strip XPath wrapper from a chart key so UI can look up by short process name.

    The executor stores charts under the canonical XPath process name
    (e.g. ``//process[@name='plot_metrics']``).  The frontend looks up
    charts by the short config name (``plot_metrics``).  This extracts
    the ``@name`` attribute value when present, leaving plain names
    unchanged.
    """
    import re
    m = re.search(r"@name='([^']+)'", name)
    return m.group(1) if m else name


@app.get("/api/projects/{project_id}/runs/{run_id}/charts")
def list_charts(project_id: str, run_id: str) -> Dict[str, Any]:
    """List charts for a run from KV store, including static/dynamic and cache paths."""
    kv = _kv_for_project(project_id)
    try:
        charts = kv.list_run_charts(run_id) or {}
    except Exception:
        charts = {}
    # Normalize chart keys: strip canonical XPath wrappers so the frontend
    # can look up charts by the short process name from the pipeline config.
    if charts:
        charts = {_normalize_chart_key(k): v for k, v in charts.items()}
    return {"charts": charts}


@app.get("/api/projects/{project_id}/runs/{run_id}/metrics/{probe_path:path}")
def get_probe_metrics(project_id: str, run_id: str, probe_path: str) -> Dict[str, Any]:
    """Get current metrics for a specific probe path."""
    return _get_probe_metrics_impl(project_id, run_id, probe_path)


def _get_probe_metrics_impl(
    project_id: str,
    run_id: str,
    probe_path: str,
    cfg: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    """Shared probe-metrics logic used by server and run_server.

    The optional cfg parameter is accepted for API compatibility with run_server.
    """
    kv = _kv_for_project(project_id)
    try:
        metrics = kv.get_probe_metrics_by_path(run_id, probe_path) or {}
        if not metrics:
            for candidate in _get_probe_path_candidates(project_id, probe_path, cfg=cfg):
                if candidate == probe_path:
                    continue
                metrics = kv.get_probe_metrics_by_path(run_id, candidate) or {}
                if metrics:
                    break
        return {"metrics": metrics or {}}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch metrics: {e}")


@app.get("/api/projects/{project_id}/runs/{run_id}/charts/fetch")
def fetch_chart(project_id: str, run_id: str, uri: str = "", cache_path: str = "") -> Response:
    """Fetch a single chart image.

    Prefer cache_path (local filesystem) when provided and exists. Otherwise, if
    uri is a gs:// path and object store is configured, fetch from object store.
    If uri is a local path, try to read it directly.
    """
    if cache_path and isinstance(cache_path, str):
        try:
            p = Path(cache_path)
            if p.exists() and p.is_file():
                data = p.read_bytes()
                mime, _ = mimetypes.guess_type(p.name)
                return Response(content=data, media_type=mime or "image/png")
        except Exception:
            pass
    
    # If no uri provided, fail
    if not uri or not isinstance(uri, str):
        raise HTTPException(status_code=400, detail="Invalid chart reference")
    
    # If uri is a gs:// path, use object store
    if uri.startswith("gs://"):
        store = _object_store_for_project(project_id)
        if not store or not hasattr(store, "get_bytes"):
            raise HTTPException(status_code=404, detail="Object store not configured")
        try:
            data = store.get_bytes(uri)
        except Exception as e:
            raise HTTPException(status_code=404, detail=f"Object not found: {e}")
        mime, _ = mimetypes.guess_type(uri)
        return Response(content=data, media_type=mime or "image/png")
    
    # Otherwise, treat uri as a local file path (fallback when no object store)
    try:
        p = Path(uri)
        if p.exists() and p.is_file():
            data = p.read_bytes()
            mime, _ = mimetypes.guess_type(p.name)
            return Response(content=data, media_type=mime or "image/png")
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Local file not found: {e}")
    
    raise HTTPException(status_code=404, detail="Chart not found")

PROJECTS_STATIC_DIR = PROJECTS_DIR
if PROJECTS_STATIC_DIR.exists():
    # Mount /projects BEFORE mounting / so that requests to /projects/... resolve here
    app.mount("/projects", StaticFiles(directory=str(PROJECTS_STATIC_DIR)), name="projects-static")

# Serve static frontend (dev fallback; packaged UI is handled separately)
PKG_UI_DIR = Path(__file__).resolve().parent / "ui"
if PKG_UI_DIR.exists():
    app.mount("/", StaticFiles(directory=str(PKG_UI_DIR), html=True), name="static")
else:
    STATIC_DIR = WORKSPACE_ROOT / "web-ui"
    if STATIC_DIR.exists():
        app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")


def create_app() -> FastAPI:
    return app


if __name__ == "__main__":
    import uvicorn 
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run("expops.web.server:app", host=host, port=port, reload=False)


