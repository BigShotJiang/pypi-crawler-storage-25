/**
 * MLOps Dynamic Charts SDK
 * 
 * This library provides a user-friendly API for creating dynamic charts that
 * listen to metrics in real-time, similar to the Python @chart() decorator.
 */

/** Encode probe path for Firestore doc id (matches ts-sdk probe-path-encoding.ts). */
function encodeProbePathForFirestore(probePath) {
  const raw = new TextEncoder().encode(probePath);
  let b64 = btoa(String.fromCharCode(...raw));
  b64 = b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  return `p_${b64}`;
}

class MetricsListener {
  constructor(projectId, runId, apiBase, options = {}) {
    this.projectId = projectId;
    this.runId = runId;
    this.apiBase = apiBase;
    this.chartName = options.chartName || null;
    this.listeners = new Map(); // probe_path -> { callbacks, currentData, hasFetchedOnce, hasData }
    this.runFinished = false;
    this.terminalStatusSeenAt = null;
    this.terminalStatusGraceMs = 12000;
    this.terminalFinalFetchTriggered = false;
    this._graceTimer = null;
    /** @type {Map<string, string>} */
    this._probeAliases = new Map(); // alias probe path -> primary subscribed probe path
    /** @type {Map<string, Set<string>>} */
    this._primaryAliasSets = new Map(); // primary -> alias probe paths
    /** @type {Map<string, string>} */
    this._primarySelectedSource = new Map(); // primary -> selected source probe path
    /** @type {Map<string, boolean>} */
    this._primaryHasNonEmptyData = new Map(); // primary -> has seen non-empty metrics

    /** @type {WebSocket|null} */
    this._ws = options.ws || null;
    /** @type {object|null} */
    this._firebaseApp = options.firebaseApp || null;
    /** @type {{ getFirestore: Function, doc: Function, onSnapshot: Function, initializeFirestore?: Function, memoryLocalCache?: Function }|null} */
    this._firebaseFirestore = options.firebaseFirestore || null;
    this._onListenerError = typeof options.onListenerError === 'function'
      ? options.onListenerError
      : null;
    this._onListenerMetrics = typeof options.onListenerMetrics === 'function'
      ? options.onListenerMetrics
      : null;
    /** @type {Map<string, () => void>} */
    this._firestoreUnsubs = new Map();
    this._wsMessageHandler = null;
    this._wsOpenHandler = null;
    this._wsErrorHandler = null;
    this._wsCloseHandler = null;

    if (this._ws) {
      this._setupWebSocket();
    }
  }

  _reportListenerError(detail) {
    const payload = {
      chartName: this.chartName || undefined,
      ...detail,
      timestamp: Date.now(),
    };
    try {
      if (this._onListenerError) this._onListenerError(payload);
    } catch (_) {
      // ignore callback errors
    }
    try {
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent('expops:listener-error', { detail: payload }));
      }
    } catch (_) {
      // ignore DOM event dispatch errors
    }
  }

  _reportListenerMetrics(detail) {
    const payload = {
      chartName: this.chartName || undefined,
      probePath: detail?.probePath,
      hasData: detail?.hasData,
      hasFetchedOnce: detail?.hasFetchedOnce,
      timestamp: Date.now(),
    };
    try {
      if (this._onListenerMetrics) this._onListenerMetrics(payload);
    } catch (_) {
      // ignore callback errors
    }
  }

  /**
   * Live probe metrics via Firestore onSnapshot (same paths as @expops/listener-sdk).
   */
  _attachFirestoreProbeForPath(probePath) {
    if (!this._firebaseApp || !this._firebaseFirestore || this._ws) return;
    if (this._firestoreUnsubs.has(probePath)) return;
    const {
      getFirestore,
      doc,
      onSnapshot,
      initializeFirestore,
      memoryLocalCache,
    } = this._firebaseFirestore;

    // Align Firestore listener initialization with the listener-sdk:
    // - in-memory cache keeps onSnapshot delivery closer to real-time
    // - long polling avoids bursty websocket transport on some networks
    try {
      if (typeof initializeFirestore === "function" && typeof memoryLocalCache === "function") {
        initializeFirestore(this._firebaseApp, {
          localCache: memoryLocalCache(),
          experimentalForceLongPolling: true,
        });
      }
    } catch (_) {
      // Already initialized elsewhere; ignore.
    }

    const db = getFirestore(this._firebaseApp);
    const encoded = encodeProbePathForFirestore(probePath);
    const ref = doc(
      db,
      "mlops_projects",
      this.projectId,
      "metric",
      this.runId,
      "probes_by_path",
      encoded,
    );
    const unsub = onSnapshot(
      ref,
      (snap) => {
        if (!snap.exists()) return;
        const data = { ...snap.data() };
        delete data.updated_at;
        this._applyFetchedMetrics(probePath, data);
      },
      (err) => {
        this._reportListenerError({
          scope: 'probe.metrics',
          probePath,
          message: err?.message || 'Firestore onSnapshot error',
          code: err?.code || undefined,
        });
      },
    );
    this._firestoreUnsubs.set(probePath, unsub);
  }

  /**
   * Set up WebSocket message handler for probe.metrics and run.status events.
   */
  _setupWebSocket() {
    this._wsOpenHandler = () => {
      // Flush any probe subscriptions that were requested while socket was connecting.
      for (const probePath of this.listeners.keys()) {
        this._wsSubscribe(probePath);
        const aliases = this._primaryAliasSets.get(probePath);
        if (aliases) {
          for (const alias of aliases) this._wsSubscribe(alias);
        }
      }
    };
    this._wsMessageHandler = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.type === 'probe.metrics' && msg.probe_path && msg.data) {
          this._applyFetchedMetrics(msg.probe_path, msg.data);
        } else if (msg.type === 'run.status' && msg.data) {
          const status = (msg.data.status || '').toLowerCase();
          if (['completed', 'failed', 'cancelled'].includes(status)) {
            this._handleTerminalStatus();
          }
        }
      } catch (_) {
        // Ignore malformed messages
      }
    };
    this._wsErrorHandler = () => {
      this._reportListenerError({
        scope: 'probe.metrics',
        message: 'WebSocket listener error',
      });
    };
    this._wsCloseHandler = (event) => {
      this._reportListenerError({
        scope: 'probe.metrics',
        message: 'WebSocket listener closed',
        code: event?.code ? String(event.code) : undefined,
      });
    };
    this._ws.addEventListener('open', this._wsOpenHandler);
    this._ws.addEventListener('message', this._wsMessageHandler);
    this._ws.addEventListener('error', this._wsErrorHandler);
    this._ws.addEventListener('close', this._wsCloseHandler);
  }

  /**
   * Send a subscribe.probe_metrics message over WebSocket.
   */
  _wsSubscribe(probePath) {
    if (this._ws && this._ws.readyState === WebSocket.OPEN) {
      this._ws.send(JSON.stringify({
        type: 'subscribe.probe_metrics',
        probe_path: probePath,
      }));
    }
  }

  _extractXPathNames(probePath) {
    if (typeof probePath !== 'string') return [];
    const names = [];
    const re = /@name='([^']+)'/g;
    let m = null;
    while ((m = re.exec(probePath)) !== null) {
      if (m[1]) names.push(m[1]);
    }
    return names;
  }

  _probePathCandidates(probePath) {
    const out = [];
    if (typeof probePath === 'string' && probePath.trim()) out.push(probePath);
    if (!(typeof probePath === 'string' && probePath.includes("@name='"))) {
      return out;
    }

    const names = this._extractXPathNames(probePath);
    if (names.length === 0) return out;

    const processName = names[0];
    const stepName = names.length >= 2 ? names[1] : null;

    // Canonical KV path shape used by StepStateManager for new metrics.
    const canonicalProcess = `//process[@name='${processName}']`;
    out.push(canonicalProcess);
    // Legacy fallback path shape for backward compatibility.
    out.push(processName);

    if (stepName) {
      out.push(`${canonicalProcess}/step[@name='${stepName}']`);
      out.push(`${processName}/${stepName}`);
    }

    const unique = [];
    const seen = new Set();
    for (const p of out) {
      if (!p || seen.has(p)) continue;
      seen.add(p);
      unique.push(p);
    }
    return unique;
  }

  _detachProbePath(probePath) {
    const unsub = this._firestoreUnsubs.get(probePath);
    if (!unsub) return;
    try {
      unsub();
    } catch (_) {
      // ignore
    }
    this._firestoreUnsubs.delete(probePath);
  }

  async _fetchInitialMetrics(probePath) {
    try {
      const encoded = encodeURIComponent(String(probePath || ''));
      const url = `${this.apiBase}/projects/${encodeURIComponent(this.projectId)}/runs/${encodeURIComponent(this.runId)}/metrics/${encoded}`;
      const resp = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain' },
        body: '',
      });
      if (!resp.ok) return;
      const body = await resp.json();
      if (body && typeof body === 'object' && Object.prototype.hasOwnProperty.call(body, 'metrics')) {
        this._applyFetchedMetrics(probePath, body.metrics || {});
      }
    } catch {
      // Best-effort backfill; WS updates can still populate chart.
    }
  }

  _handleTerminalStatus() {
    if (this.terminalStatusSeenAt !== null) return;
    this.terminalStatusSeenAt = Date.now();

    if (this._allSubscribedProbesFetchedOnce()) {
      this.runFinished = true;
      this.stopAll();
      return;
    }

    // Best-effort terminal final fetch:
    // if WS updates race with completion, this last read helps charts capture
    // final metrics before teardown.
    this._triggerTerminalFinalFetch();

    // Grace period: stop even if some probes never received data
    this._graceTimer = setTimeout(() => {
      this._maybeStopAfterTerminalStatus(true);
    }, this.terminalStatusGraceMs);
  }

  _maybeStopAfterTerminalStatus(graceExpired = false) {
    if (this.terminalStatusSeenAt === null) return;
    if (!(this._allSubscribedProbesFetchedOnce() || graceExpired)) return;
    if (this._graceTimer) {
      clearTimeout(this._graceTimer);
      this._graceTimer = null;
    }
    this.runFinished = true;
    this.stopAll();
  }

  _terminalFetchCandidates() {
    const candidates = new Set();
    for (const [primaryProbePath] of this.listeners) {
      candidates.add(primaryProbePath);
      const aliases = this._primaryAliasSets.get(primaryProbePath);
      if (aliases) {
        for (const alias of aliases) candidates.add(alias);
      }
    }
    return Array.from(candidates);
  }

  async _fetchAllSubscribedProbesOnce() {
    const paths = this._terminalFetchCandidates();
    if (paths.length === 0) return;
    await Promise.all(paths.map((p) => this._fetchInitialMetrics(p)));
  }

  async _triggerTerminalFinalFetch() {
    if (this.terminalFinalFetchTriggered) return;
    this.terminalFinalFetchTriggered = true;

    try {
      await this._fetchAllSubscribedProbesOnce();
    } catch (_) {
      // Best-effort only; rely on grace timer fallback.
    }

    this._maybeStopAfterTerminalStatus(false);
  }

  /**
   * Subscribe to metrics updates for a probe path
   * @param {string} probePath - The probe path (e.g., "nn_training_a/train_and_evaluate_nn")
   * @param {Function} callback - Called when metrics update: (metrics) => void
   * @returns {Function} Unsubscribe function
   */
  subscribe(probePath, callback) {
    if (!this.listeners.has(probePath)) {
      const listenerData = {
        callbacks: new Set(),
        currentData: null,
        hasFetchedOnce: false,
        hasData: false
      };
      this.listeners.set(probePath, listenerData);
      const candidates = this._probePathCandidates(probePath);
      const aliasSet = new Set();
      this._primarySelectedSource.set(probePath, probePath);
      this._primaryHasNonEmptyData.set(probePath, false);
      for (const candidate of candidates) {
        if (candidate !== probePath) {
          this._probeAliases.set(candidate, probePath);
          aliasSet.add(candidate);
        }
        this._wsSubscribe(candidate);
        // Let the UI know we've attached a listener for this probe path candidate.
        this._reportListenerMetrics({
          probePath: candidate,
          hasData: false,
          hasFetchedOnce: false,
        });
        // Backfill once so completed runs render immediately even without new WS events.
        this._fetchInitialMetrics(candidate);
        if (this._firebaseApp && this._firebaseFirestore && !this._ws) {
          this._attachFirestoreProbeForPath(candidate);
        }
      }
      this._primaryAliasSets.set(probePath, aliasSet);
    }

    const listenerData = this.listeners.get(probePath);
    listenerData.callbacks.add(callback);

    // Immediately invoke callback if we have data
    if (listenerData.currentData) {
      callback(listenerData.currentData);
    }

    // Return unsubscribe function
    return () => {
      listenerData.callbacks.delete(callback);
      if (listenerData.callbacks.size === 0) {
        const aliases = this._primaryAliasSets.get(probePath);
        if (aliases) {
          for (const alias of aliases) {
            this._probeAliases.delete(alias);
            this._detachProbePath(alias);
          }
        }
        this._primaryAliasSets.delete(probePath);
        this._primarySelectedSource.delete(probePath);
        this._primaryHasNonEmptyData.delete(probePath);
        this._detachProbePath(probePath);
        this.listeners.delete(probePath);
      }
    };
  }

  /**
   * Subscribe to multiple probe paths
   * @param {Object} probePaths - Map of { key: probePath }
   * @param {Function} callback - Called with { key: metrics, ... }
   * @returns {Function} Unsubscribe function
   */
  subscribeAll(probePaths, callback) {
    const aggregatedData = {};
    const unsubscribers = [];

    for (const [key, probePath] of Object.entries(probePaths)) {
      const unsub = this.subscribe(probePath, (metrics) => {
        aggregatedData[key] = metrics;
        callback(aggregatedData);
      });
      unsubscribers.push(unsub);
    }

    return () => {
      unsubscribers.forEach(unsub => unsub());
    };
  }

  _metricsHasData(metrics) {
    if (metrics === null || metrics === undefined) return false;
    if (Array.isArray(metrics)) return metrics.length > 0;
    if (typeof metrics === 'object') return Object.keys(metrics).length > 0;
    return true;
  }

  _applyFetchedMetrics(probePath, metrics) {
    const primaryProbePath = this.listeners.has(probePath)
      ? probePath
      : this._probeAliases.get(probePath);
    const listenerData = primaryProbePath ? this.listeners.get(primaryProbePath) : null;
    if (!listenerData || metrics === null) return;

    const hasData = this._metricsHasData(metrics);
    const selectedSource = this._primarySelectedSource.get(primaryProbePath) || primaryProbePath;
    const seenNonEmpty = this._primaryHasNonEmptyData.get(primaryProbePath) === true;

    // Avoid cross-path churn: only switch source if we haven't observed data yet.
    if (probePath !== selectedSource) {
      if (!hasData || seenNonEmpty) return;
      this._primarySelectedSource.set(primaryProbePath, probePath);
    }

    // Once non-empty data was seen, ignore empty regressions from stale docs.
    if (!hasData && seenNonEmpty) {
      return;
    }

    listenerData.hasFetchedOnce = true;
    listenerData.hasData = hasData;
    listenerData.currentData = metrics;
    if (hasData) {
      this._primaryHasNonEmptyData.set(primaryProbePath, true);
    }
    listenerData.callbacks.forEach(callback => {
      try {
        callback(metrics);
      } catch (error) {
        console.error('Error in metrics callback:', error);
      }
    });

    this._reportListenerMetrics({
      probePath: this._primarySelectedSource.get(primaryProbePath) || primaryProbePath,
      hasData: listenerData.hasData,
      hasFetchedOnce: listenerData.hasFetchedOnce,
    });

    // If terminal status was already seen, check if all probes have data.
    this._maybeStopAfterTerminalStatus(false);
  }

  _allSubscribedProbesFetchedOnce() {
    for (const [, listenerData] of this.listeners) {
      if (!listenerData.hasFetchedOnce) return false;
    }
    return true;
  }

  stopAll() {
    if (this._graceTimer) {
      clearTimeout(this._graceTimer);
      this._graceTimer = null;
    }

    for (const unsub of this._firestoreUnsubs.values()) {
      try {
        unsub();
      } catch (_) {
        // ignore
      }
    }
    this._firestoreUnsubs.clear();
    this._probeAliases.clear();
    this._primaryAliasSets.clear();
    this._primarySelectedSource.clear();
    this._primaryHasNonEmptyData.clear();

    // Clean up WebSocket listener (don't close the WS — it's shared)
    if (this._ws && this._wsOpenHandler) {
      this._ws.removeEventListener('open', this._wsOpenHandler);
      this._wsOpenHandler = null;
    }
    if (this._ws && this._wsMessageHandler) {
      this._ws.removeEventListener('message', this._wsMessageHandler);
      this._wsMessageHandler = null;
    }
    if (this._ws && this._wsErrorHandler) {
      this._ws.removeEventListener('error', this._wsErrorHandler);
      this._wsErrorHandler = null;
    }
    if (this._ws && this._wsCloseHandler) {
      this._ws.removeEventListener('close', this._wsCloseHandler);
      this._wsCloseHandler = null;
    }

    this.listeners.clear();
  }
}

class ChartContext {
  constructor(projectId, runId, chartName, containerElement, apiBase) {
    this.projectId = projectId;
    this.runId = runId;
    this.chartName = chartName;
    this.containerElement = containerElement;
    this.apiBase = apiBase;
    this.chartInstance = null; // For Chart.js instances
  }

  /**
   * Helper to convert metrics data to time series array
   * Handles both dict {step: value} and array formats
   */
  toSeries(data) {
    if (typeof data === 'object' && !Array.isArray(data) && data !== null) {
      // Dict format: {0: val, 1: val, ...}
      const items = Object.entries(data).sort((a, b) => {
        const aNum = parseInt(a[0]);
        const bNum = parseInt(b[0]);
        return (isNaN(aNum) ? 0 : aNum) - (isNaN(bNum) ? 0 : bNum);
      });
      return items.map(([_, v]) => parseFloat(v));
    } else if (Array.isArray(data)) {
      return data.map(v => parseFloat(v));
    }
    return [];
  }

  /**
   * Get the latest scalar value from metrics data
   * Useful for static metrics or getting the final value
   */
  getValue(data) {
    if (typeof data === 'number') {
      return data;
    } else if (typeof data === 'object' && !Array.isArray(data) && data !== null) {
      const items = Object.entries(data).sort((a, b) => {
        const aNum = parseInt(a[0]);
        const bNum = parseInt(b[0]);
        return (isNaN(aNum) ? 0 : aNum) - (isNaN(bNum) ? 0 : bNum);
      });
      return items.length > 0 ? parseFloat(items[items.length - 1][1]) : null;
    } else if (Array.isArray(data) && data.length > 0) {
      return parseFloat(data[data.length - 1]);
    }
    return null;
  }

  /**
   * Clear the chart container
   */
  clear() {
    if (this.chartInstance && typeof this.chartInstance.destroy === 'function') {
      this.chartInstance.destroy();
      this.chartInstance = null;
    }
    this.containerElement.innerHTML = '';
  }

  /**
   * Set the chart instance (for Chart.js charts)
   */
  setChartInstance(chart) {
    if (this.chartInstance && typeof this.chartInstance.destroy === 'function') {
      this.chartInstance.destroy();
    }
    this.chartInstance = chart;
  }
}

// ==================== User-Facing Registry ====================

const CHART_REGISTRY = (() => {
  try {
    const g = globalThis;
    if (!g.__EXPOPS_CHART_REGISTRY__) {
      g.__EXPOPS_CHART_REGISTRY__ = new Map();
    }
    return g.__EXPOPS_CHART_REGISTRY__;
  } catch (_) {
    return new Map();
  }
})();

/**
 * Decorator-style function to register a chart
 * 
 * Usage:
 *   chart('my_chart_name', (probePaths, ctx, listener) => {
 *     // Your chart logic here
 *   });
 * 
 * @param {string} name - Chart name (must match config)
 * @param {Function} renderFunction - Function with signature: (probePaths, ctx, listener) => void
 */
export function chart(name, renderFunction) {
  if (typeof name !== 'string' || !name.trim()) {
    throw new Error('Chart name must be a non-empty string');
  }
  if (typeof renderFunction !== 'function') {
    throw new Error('Chart render function must be a function');
  }
  
  CHART_REGISTRY.set(name, renderFunction);
}

/**
 * Get a registered chart by name
 * @param {string} name
 * @returns {Function|null}
 */
export function getChart(name) {
  return CHART_REGISTRY.get(name) || null;
}

/**
 * List all registered chart names
 * @returns {string[]}
 */
export function listCharts() {
  return Array.from(CHART_REGISTRY.keys());
}

// ==================== Chart Renderer ====================

/**
 * Render a dynamic chart in a container
 * 
 * @param {string} projectId
 * @param {string} runId
 * @param {string} chartName
 * @param {Object} chartConfig - Chart config from backend (includes probe_paths)
 * @param {HTMLElement} containerElement
 * @param {string} apiBase - API base URL
 * @returns {Function} Cleanup function
 */
export function renderDynamicChart(projectId, runId, chartName, chartConfig, containerElement, apiBase = '/api', options = {}) {
  const renderFunction = CHART_REGISTRY.get(chartName);
  if (!renderFunction) {
    containerElement.innerHTML = `<div class="chart-error">Chart '${chartName}' not found. Did you register it?</div>`;
    return () => {};
  }

  const ctx = new ChartContext(projectId, runId, chartName, containerElement, apiBase);
  const listener = new MetricsListener(projectId, runId, apiBase, {
    chartName,
    ws: options.ws ?? null,
    firebaseApp: options.firebaseApp ?? null,
    firebaseFirestore: options.firebaseFirestore ?? null,
    onListenerError: options.onListenerError ?? null,
    onListenerMetrics: options.onListenerMetrics ?? null,
  });

  try {
    // Extract probe_paths from config
    const probePaths = chartConfig.probe_paths || {};
    
    // Call user's render function
    renderFunction(probePaths, ctx, listener);
  } catch (error) {
    console.error(`Error rendering chart '${chartName}':`, error);
    containerElement.innerHTML = `<div class="chart-error">Error: ${error.message}</div>`;
  }
  
  // Return cleanup function
  return () => {
    ctx.clear();
    listener.stopAll();
  };
}

/**
 * Render a static chart (just display the image)
 * 
 * @param {string} imageUrl - URL to the chart image
 * @param {HTMLElement} containerElement
 */
export function renderStaticChart(imageUrl, containerElement) {
  containerElement.innerHTML = '';
  const img = document.createElement('img');
  img.src = imageUrl;
  img.alt = 'Chart';
  img.style.maxWidth = '100%';
  img.style.height = 'auto';
  containerElement.appendChild(img);
}

// ==================== Exports ====================

export {
  MetricsListener,
  ChartContext,
  CHART_REGISTRY
};

