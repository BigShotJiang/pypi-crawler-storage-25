from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Optional, TextIO, Tuple


def _current_dist_info() -> Optional[Tuple[str, str]]:
    """Return (distribution_name, version) for the installed platform package."""
    try:
        from importlib.metadata import PackageNotFoundError, version  # type: ignore
    except Exception:
        return None

    for dist in ("expops", "mlops-platform", "mlops_platform"):
        try:
            v = version(dist)
            if v:
                return (str(dist), str(v))
        except PackageNotFoundError:
            continue
        except Exception:
            continue
    return None


def _run_cmd(
    cmd: list[str],
    *,
    log_stream: Optional[TextIO] = None,
    env: Optional[dict[str, str]] = None,
) -> subprocess.CompletedProcess[str]:
    run_kw: dict = {"check": False, "text": True}
    if env is not None:
        run_kw["env"] = env
    if log_stream is not None:
        run_kw["stdout"] = log_stream
        run_kw["stderr"] = log_stream
        return subprocess.run(cmd, **run_kw)
    run_kw["capture_output"] = True
    return subprocess.run(cmd, **run_kw)


def ensure_platform_importable(
    python_exec: str,
    *,
    import_module: str = "expops.core",
    log_stream: Optional[TextIO] = None,
    no_deps: bool = False,
    quiet: bool = True,
) -> bool:
    """Install platform package into target interpreter until module is importable."""
    from .workspace import infer_source_root

    def _log(message: str) -> None:
        if log_stream is None:
            return
        try:
            log_stream.write(f"{message}\n")
        except Exception:
            pass

    def _make_import_check_env() -> dict[str, str]:
        """Build env for import check with workspace src stripped from PYTHONPATH."""
        sanitized = dict(os.environ)
        try:
            src_root = infer_source_root()
            if src_root and (src_root / "src").exists():
                repo_src = str((src_root / "src").resolve())
                pp = sanitized.get("PYTHONPATH", "") or ""
                parts = [p.strip() for p in pp.split(os.pathsep) if p.strip()]
                filtered = []
                for p in parts:
                    try:
                        if str(Path(p).resolve()) != repo_src:
                            filtered.append(p)
                    except Exception:
                        filtered.append(p)
                sanitized["PYTHONPATH"] = os.pathsep.join(filtered) if filtered else ""
        except Exception:
            pass
        return sanitized

    def _pip_install(args: list[str], label: str) -> bool:
        cmd = [python_exec, "-m", "pip", "install"]
        if quiet:
            cmd.append("--quiet")
        if no_deps:
            cmd.append("--no-deps")
        cmd.extend(args)
        _log(f"{label}: {' '.join(args)}")
        res = _run_cmd(cmd, log_stream=log_stream)
        return getattr(res, "returncode", 1) == 0

    def _import_ok() -> bool:
        """Run import check with env that excludes repo src; do not log stderr (expected to fail before install)."""
        check_env = _make_import_check_env()
        res = _run_cmd(
            [python_exec, "-c", f"import {import_module}"],
            log_stream=None,  # capture output so ModuleNotFoundError traceback is not written to log
            env=check_env,
        )
        return getattr(res, "returncode", 1) == 0

    if _import_ok():
        return True

    source_root: Optional[Path] = None
    try:
        source_root = infer_source_root()
    except Exception:
        source_root = None

    source_installable = bool(
        source_root
        and (
            (source_root / "pyproject.toml").exists()
            or (source_root / "setup.py").exists()
        )
    )

    if source_installable and source_root is not None:
        if _pip_install(["-e", str(source_root)], "Installing platform from local source checkout (editable)"):
            if _import_ok():
                return True
            _log(f"Editable install completed, but '{import_module}' is still not importable.")
        else:
            _log("Editable install failed; continuing with index-based install.")

    dist_info = _current_dist_info()
    if dist_info:
        dist_name, dist_version = dist_info
        if _pip_install([f"{dist_name}=={dist_version}"], "Installing pinned platform package"):
            if _import_ok():
                return True
            _log(f"Pinned install completed, but '{import_module}' is still not importable.")
        else:
            _log(
                f"Pinned install failed for {dist_name}=={dist_version}; "
                "falling back to latest pre-release."
            )
    else:
        _log("Could not determine current platform distribution/version; falling back to latest pre-release.")

    _pip_install(["--pre", "--upgrade", "expops"], "Installing platform fallback")
    return _import_ok()
