from __future__ import annotations

from typing import Any, Dict, List, Optional

from datetime import datetime
import json
import logging
import numbers
import os
import shutil
import uuid
from pathlib import Path
import time
import sys

from expops.core.graph.graph_types import ExecutionResult
from expops.core.runtime.payload_spill import spill_large_payloads
from expops.core.workspace import get_projects_root, get_workspace_root, infer_source_root, resolve_relative_path, get_project_runtime_root
from expops.core.parallelism_utils import (
    normalize_data_parallelism_cfg as _normalize_data_parallelism_cfg,
    normalize_seed_parallelism_cfg as _normalize_seed_parallelism_cfg,
)

logger = logging.getLogger(__name__)


LIGHTWEIGHT_RESULT_KEY = "__mlops_lightweight_result__"


def _apply_hash_overrides(proc_payload: Dict[str, Any], config_hash: Optional[str], function_hash: Optional[str]) -> tuple[Optional[str], Optional[str]]:
    """Apply optional hash overrides supplied by the driver (used for chart nodes)."""
    overrides = proc_payload.get("hash_overrides") if isinstance(proc_payload, dict) else None
    if isinstance(overrides, dict):
        config_hash = overrides.get("config_hash") or config_hash
        function_hash = overrides.get("function_hash") or function_hash
    return config_hash, function_hash


def _ensure_chart_function_hash(proc_payload: Dict[str, Any], ctx: Any, function_hash: Optional[str]) -> Optional[str]:
    """Best-effort fallback to hash chart entrypoint content when override is missing."""
    if function_hash:
        return function_hash
    try:
        is_chart = (
            str(proc_payload.get("process_type", "process")).lower() == "chart"
            or isinstance(proc_payload.get("chart_spec"), dict)
        )
        if not is_chart:
            return function_hash

        chart_spec = proc_payload.get("chart_spec") if isinstance(proc_payload, dict) else {}
        entrypoint = ""
        if isinstance(chart_spec, dict):
            entrypoint = str(chart_spec.get("entrypoint") or chart_spec.get("script_path") or "").strip()
        if not entrypoint:
            entrypoint = str(proc_payload.get("script_path") or "").strip()
        if not entrypoint:
            return function_hash

        project_id = str(getattr(ctx, "project_id", None) or os.environ.get("MLOPS_PROJECT_ID") or "").strip()
        workspace_root = get_workspace_root()
        project_root = (get_projects_root(workspace_root) / project_id) if project_id else None
        resolved = resolve_relative_path(entrypoint, project_root=project_root, workspace_root=workspace_root)
        if not resolved.exists() or not resolved.is_file():
            return function_hash

        import hashlib

        return hashlib.sha256(resolved.read_bytes()).hexdigest()
    except Exception:
        return function_hash


def _strip_internal_keys(value: Any) -> Any:
    if isinstance(value, dict):
        keep_keys = {
            "__data_partition_hashes__",
            "__data_partition_data_name__",
            "__data_hash__",
            "__parallel_context__",
        }
        return {k: v for k, v in value.items() if (k in keep_keys) or (not str(k).startswith("__"))}
    return value


def _is_lightweight_result_payload(value: Any) -> bool:
    return isinstance(value, dict) and bool(value.get(LIGHTWEIGHT_RESULT_KEY))


def _resolve_process_cache_path(
    state_manager: Any,
    process_name: Optional[str],
    input_hash: Optional[str],
    config_hash: Optional[str],
    function_hash: Optional[str],
) -> Optional[str]:
    if state_manager is None or not process_name:
        return None
    try:
        kv = getattr(state_manager, "kv_store", None)
        if kv is None or not hasattr(kv, "get_process_cache_path"):
            return None
        return kv.get_process_cache_path(process_name, input_hash, config_hash, function_hash)
    except Exception:
        return None


def _build_lightweight_result_envelope(
    process_name: Optional[str],
    result_payload: Optional[Dict[str, Any]],
    cache_path: Optional[str],
    input_hash: Optional[str],
    config_hash: Optional[str],
    function_hash: Optional[str],
) -> Dict[str, Any]:
    envelope: Dict[str, Any] = {
        LIGHTWEIGHT_RESULT_KEY: True,
    }
    if cache_path:
        envelope["cache_path"] = cache_path
    if input_hash and config_hash:
        envelope["cache_lookup"] = {
            "process_name": process_name,
            "input_hash": input_hash,
            "config_hash": config_hash,
            "function_hash": function_hash,
        }
    if isinstance(result_payload, dict):
        for key in ("__logs__", "__data_partition_hashes__", "__data_partition_data_name__", "__data_hash__"):
            if key in result_payload:
                envelope[key] = result_payload.get(key)
    return envelope


def _record_chart_artifacts(
    state_manager: Any,
    project_id: str,
    run_id: str,
    chart_name: str,
    out_dir: Path,
    chart_type: str = "static",
) -> None:
    """Best-effort: upload PNG artifacts and record them in the KV store for UI listing.

    Uses layout: <project_id>/artifacts/<version_hash>/<encoded_probe_path>/<filename>
    """
    try:
        obj_store = getattr(state_manager, "object_store", None)
        kv = getattr(state_manager, "kv_store", None)
    except Exception:
        return

    try:
        pngs = list(out_dir.rglob("*.png"))
    except Exception:
        pngs = []

    # Derive artifact relative path from out_dir: .../artifacts/<version_hash>/<encoded_probe_path>
    try:
        artifacts_root = out_dir
        while artifacts_root != artifacts_root.parent and artifacts_root.name != "artifacts":
            artifacts_root = artifacts_root.parent
        if artifacts_root.name == "artifacts":
            rel_path_str = str(out_dir.relative_to(artifacts_root)).replace("\\", "/")
        else:
            rel_path_str = chart_name
    except Exception:
        rel_path_str = chart_name

    abs_artifacts_root = None
    try:
        if obj_store:
            bname = getattr(obj_store, "_bucket", None)
            if bname is not None:
                bname = getattr(bname, "name", None)
            if not bname:
                bname = getattr(obj_store, "_bucket_name", None)
            if bname:
                abs_artifacts_root = f"gs://{bname}/{project_id}/artifacts/{rel_path_str}"
    except Exception:
        abs_artifacts_root = None

    artifacts: list[dict] = []
    for p in pngs:
        try:
            local_path = str(p.resolve())
        except Exception:
            local_path = str(p)
        try:
            file_rel = str(p.relative_to(out_dir)).replace("\\", "/")
        except Exception:
            file_rel = p.name

        obj_path = None
        if obj_store:
            try:
                if abs_artifacts_root:
                    remote = obj_store.build_uri(abs_artifacts_root, file_rel)
                else:
                    base = f"{project_id}/artifacts/{rel_path_str}"
                    remote = obj_store.build_uri(base, file_rel)
                with open(p, "rb") as f:
                    obj_store.put_bytes(remote, f.read(), content_type="image/png")
                obj_path = remote
            except Exception as upload_err:
                logger.warning(f"[Charts] Upload failed for {p.name}: {upload_err}")
                obj_path = None

        if not obj_path:
            obj_path = local_path

        try:
            artifacts.append(
                {
                    "title": p.name,
                    "object_path": obj_path,
                    "cache_path": local_path,
                    "mime_type": "image/png",
                    "size_bytes": p.stat().st_size,
                    "created_at": time.time(),
                    "chart_type": chart_type,
                }
            )
        except Exception:
            continue

    try:
        if kv and hasattr(kv, "record_run_chart_artifacts"):
            kv.record_run_chart_artifacts(str(run_id), str(chart_name), artifacts)
    except Exception as kv_err:
        logger.warning(f"[Charts] Failed to record artifacts in KV: {kv_err}")


def _create_process_temp_workspace(base_dir: str, project_id: str, run_id: str, process_name: str) -> Path:
    """Create a unique temp directory for process execution under base_dir.

    Layout: <base_dir>/mlops/<project_id>/<run_id>/<encoded_process_id>/<short_id>
    Uses encoded process ID (safe for filesystem) when process_name is canonical XPath.
    """
    base = Path(base_dir).resolve()
    short_id = uuid.uuid4().hex[:12]
    try:
        from expops.core.cache_probe.probe_path import get_encoded_probe_path
        dir_segment = get_encoded_probe_path(process_name, None) or (process_name or "process")
    except Exception:
        dir_segment = process_name or "process"
    # Sanitize for filesystem: encoded form is safe; fallback may contain / [ ] etc.
    if "/" in dir_segment or "[" in dir_segment or "]" in dir_segment:
        dir_segment = dir_segment.replace("/", "_").replace("[", "_").replace("]", "_").replace("'", "_").replace("=", "_")[:64]
    path = base / "mlops" / project_id / run_id / dir_segment / short_id
    path.mkdir(parents=True, exist_ok=True)
    return path


# Directories under project root to copy into process temp workspace so relative paths (e.g. data/train.csv) resolve.
# No env vars or __file__ needed in user code; platform ensures these exist in the temp cwd.
_PROJECT_WORKSPACE_COPY_DIRS = ("data",)


def _copy_project_data_dirs_into_temp_workspace(project_root: Path, temp_workspace: Path) -> None:
    """Copy project data dirs (e.g. data/) into temp_workspace so relative paths work when cwd is temp_workspace."""
    if not project_root.exists() or not project_root.is_dir():
        return
    for dir_name in _PROJECT_WORKSPACE_COPY_DIRS:
        src = project_root / dir_name
        if not src.is_dir():
            continue
        dest = temp_workspace / dir_name
        try:
            if dest.exists():
                shutil.rmtree(dest, ignore_errors=True)
            shutil.copytree(src, dest)
        except Exception as copy_err:
            logger.warning("[Workspace] Copy project dir %s -> temp workspace failed: %s", dir_name, copy_err)


def _sync_process_workspace_to_artifacts(
    temp_workspace: Path,
    state_manager: Any,
    project_id: str,
    run_id: str,
    process_name: str,
    probe_paths: Optional[Any] = None,
    chart_type: str = "static",
) -> None:
    """Recursively sync all files from process temp workspace to artifact store.

    Uses layout: <project_id>/artifacts/<version_hash>/<encoded_probe_path>/<relative_path>
    """
    if not temp_workspace.exists() or not temp_workspace.is_dir():
        return
    try:
        obj_store = getattr(state_manager, "object_store", None)
        kv = getattr(state_manager, "kv_store", None)
    except Exception:
        return
    try:
        from expops.core.cache_probe.cache_layout import compute_cache_version_hash, build_artifact_relative_path
        from expops.core.cache_probe.probe_path import get_encoded_probe_path
        proj_root = get_projects_root(get_workspace_root()) / str(project_id)
        if getattr(state_manager, "_version_hash", None):
            _version_hash = state_manager._version_hash
        else:
            _version_hash = compute_cache_version_hash(proj_root)
        # Charts should always store artifacts under their own process probe path.
        # `probe_paths` are only for metrics lookup / chart logic, not artifact namespacing.
        encoded_probe = get_encoded_probe_path(process_name=process_name, step_name=None)
        rel_base = build_artifact_relative_path(_version_hash, encoded_probe)
        runtime_root = get_project_runtime_root(proj_root, project_id)
        local_artifacts_base = runtime_root / "artifacts" / rel_base
    except Exception:
        rel_base = "default"
        runtime_root = None
        local_artifacts_base = None
    artifacts: List[dict] = []
    for f in temp_workspace.rglob("*"):
        if not f.is_file():
            continue
        try:
            file_rel = str(f.relative_to(temp_workspace)).replace("\\", "/")
        except Exception:
            file_rel = f.name
        # Do not sync copied-in project data dirs (e.g. data/) to artifacts; artifacts are for chart outputs only.
        if any(file_rel == d or file_rel.startswith(d + "/") for d in _PROJECT_WORKSPACE_COPY_DIRS):
            continue
        obj_path = None
        cache_path = str(f.resolve())
        if obj_store:
            try:
                base_uri = f"{project_id}/artifacts/{rel_base}"
                remote = obj_store.build_uri(base_uri, file_rel)
                with open(f, "rb") as fp:
                    data = fp.read()
                content_type = "application/octet-stream"
                if file_rel.lower().endswith(".png"):
                    content_type = "image/png"
                elif file_rel.lower().endswith((".json", ".jsonl")):
                    content_type = "application/json"
                obj_store.put_bytes(remote, data, content_type=content_type)
                obj_path = remote
            except Exception as upload_err:
                logger.warning(f"[Artifacts] Upload failed for {file_rel}: {upload_err}")
        if not obj_path and local_artifacts_base is not None:
            try:
                dest = local_artifacts_base / file_rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(f, dest)
                obj_path = str(dest.resolve())
                cache_path = obj_path
            except Exception as copy_err:
                logger.warning(f"[Artifacts] Local copy failed for {file_rel}: {copy_err}")
                obj_path = str(f.resolve())
        if not obj_path:
            obj_path = str(f.resolve())
        try:
            artifacts.append({
                "title": f.name,
                "object_path": obj_path,
                "cache_path": cache_path,
                "mime_type": "image/png" if f.suffix.lower() == ".png" else "application/octet-stream",
                "size_bytes": f.stat().st_size,
                "created_at": time.time(),
                "chart_type": chart_type,
            })
        except Exception:
            continue
    try:
        if kv and artifacts and hasattr(kv, "record_run_chart_artifacts"):
            kv.record_run_chart_artifacts(str(run_id), str(process_name), artifacts)
    except Exception as kv_err:
        logger.warning(f"[Artifacts] Failed to record in KV: {kv_err}")


def _build_step_context_from_payload(context_payload: Dict[str, Any]) -> Any:
    from expops.core.runtime.step_system import StepContext as _Ctx
    try:
        payload = context_payload if isinstance(context_payload, dict) else {}

        step_results_in = payload.get("step_results") or {}
        step_results: Dict[str, Any] = {}
        if isinstance(step_results_in, dict):
            for key, val in step_results_in.items():
                if isinstance(val, dict):
                    data = val.get("data")
                    if isinstance(data, dict):
                        step_results[key] = dict(data)
                    else:
                        step_results[key] = _strip_internal_keys(val)
                else:
                    step_results[key] = val

        data_paths: Dict[str, Path] = {}
        data_paths_in = payload.get("data_paths") or {}
        if isinstance(data_paths_in, dict):
            for k, v in data_paths_in.items():
                try:
                    data_paths[str(k)] = Path(v)
                except Exception:
                    continue

        ctx = _Ctx(
            project_id=payload.get("project_id"),
            run_id=payload.get("run_id"),
            step_results=step_results,
            global_config=payload.get("global_config") or {},
            data_paths=data_paths,
            data_hash=payload.get("data_hash"),
        )
        if payload.get("seed_value") is not None:
            ctx.shared_state["seed_value"] = payload["seed_value"]
        return ctx
    except Exception:
        # Fall back to a minimal context if anything in the payload is malformed.
        try:
            pid = context_payload.get("project_id") if isinstance(context_payload, dict) else "default"
        except Exception:
            pid = "default"
        return _Ctx(project_id=pid)

def _is_numeric_metric_value(value: Any) -> bool:
    if isinstance(value, bool):
        return False
    return isinstance(value, numbers.Number)


def _to_native_scalar(value: Any) -> Any:
    try:
        if hasattr(value, "item") and callable(getattr(value, "item")):
            return value.item()
    except Exception:
        pass
    return value


def _normalize_metric_input_aliases(raw_aliases: Any) -> Dict[str, str]:
    if not isinstance(raw_aliases, dict):
        return {}
    normalized: Dict[str, str] = {}
    for canonical_key, source_key in raw_aliases.items():
        if canonical_key is None or source_key is None:
            continue
        normalized[str(canonical_key)] = str(source_key)
    return normalized


def _resolve_metric_source_value(
    source_key: str,
    result_payload: Dict[str, Any],
    runner_inputs: Dict[str, Any],
    input_aliases: Dict[str, str] | None = None,
) -> Any:
    if source_key in result_payload:
        return result_payload.get(source_key)
    if source_key in runner_inputs:
        return runner_inputs.get(source_key)
    if input_aliases:
        mapped_source_key = input_aliases.get(source_key)
        if mapped_source_key in runner_inputs:
            return runner_inputs.get(mapped_source_key)
    return None


def _first_available_metric_value(
    candidates: List[str],
    result_payload: Dict[str, Any],
    runner_inputs: Dict[str, Any],
    input_aliases: Dict[str, str] | None = None,
) -> Any:
    for key in candidates:
        value = _resolve_metric_source_value(key, result_payload, runner_inputs, input_aliases)
        if value is not None:
            return value
    return None


def _builtin_metric_fn(metric_id: str) -> Any:
    try:
        from sklearn.metrics import (
            accuracy_score,
            f1_score,
            precision_score,
            recall_score,
            mean_squared_error,
            mean_absolute_error,
            r2_score,
            roc_auc_score,
            log_loss,
        )
    except Exception:
        return None

    registry = {
        "accuracy_score": accuracy_score,
        "f1_score": f1_score,
        "precision_score": precision_score,
        "recall_score": recall_score,
        "mean_squared_error": mean_squared_error,
        "mean_absolute_error": mean_absolute_error,
        "r2_score": r2_score,
        "roc_auc_score": roc_auc_score,
        "log_loss": log_loss,
    }
    return registry.get(metric_id)


def _default_metric_inputs(metric_id: str) -> Dict[str, List[str]]:
    y_true_candidates = ["y_true", "y_test", "labels", "target", "targets", "y"]
    y_pred_candidates = ["y_pred", "predictions", "preds", "y_hat"]
    y_score_candidates = ["y_score", "probabilities", "probs", "y_proba", "scores"]

    if metric_id in {"roc_auc_score"}:
        return {"y_true": y_true_candidates, "y_score": y_score_candidates + y_pred_candidates}
    if metric_id in {"log_loss"}:
        return {"y_true": y_true_candidates, "y_pred": y_score_candidates + y_pred_candidates}
    return {"y_true": y_true_candidates, "y_pred": y_pred_candidates}


def _log_metric_payload(
    state_manager: Any,
    run_id: str,
    process_name: str,
    metric_name: str,
    value: Any,
) -> None:
    metric_name = str(metric_name).strip()
    if not metric_name:
        return

    if isinstance(value, dict):
        ordered_steps: list[tuple[int, Any]] = []
        for k, v in value.items():
            try:
                step_idx = int(k)
            except Exception:
                ordered_steps = []
                break
            ordered_steps.append((step_idx, v))
        if ordered_steps:
            for step_idx, raw_val in sorted(ordered_steps, key=lambda item: item[0]):
                scalar = _to_native_scalar(raw_val)
                if _is_numeric_metric_value(scalar):
                    state_manager.log_metric(
                        run_id=run_id,
                        process_name=process_name,
                        step_name=None,
                        metric_name=metric_name,
                        value=float(scalar),
                        step=int(step_idx),
                    )
            return

    if isinstance(value, (list, tuple)):
        has_logged = False
        for idx, raw_val in enumerate(value, start=1):
            scalar = _to_native_scalar(raw_val)
            if not _is_numeric_metric_value(scalar):
                continue
            state_manager.log_metric(
                run_id=run_id,
                process_name=process_name,
                step_name=None,
                metric_name=metric_name,
                value=float(scalar),
                step=idx,
            )
            has_logged = True
        if has_logged:
            return

    scalar = _to_native_scalar(value)
    if _is_numeric_metric_value(scalar):
        state_manager.log_metric(
            run_id=run_id,
            process_name=process_name,
            step_name=None,
            metric_name=metric_name,
            value=float(scalar),
            step=None,
        )
        return

    state_manager.log_metric(
        run_id=run_id,
        process_name=process_name,
        step_name=None,
        metric_name=metric_name,
        value=value,
        step=None,
    )


def _compute_metric_value_from_spec(
    metric_spec: Dict[str, Any],
    result_payload: Dict[str, Any],
    runner_inputs: Dict[str, Any],
    process_name: str,
    input_aliases: Dict[str, str] | None = None,
) -> Any:
    metric_name = str(metric_spec.get("name", "")).strip()
    if not metric_name:
        return None

    metric_fn = metric_spec.get("fn")
    metric_fn_name = str(metric_fn).strip() if metric_fn is not None else ""
    if metric_fn_name:
        fn = _builtin_metric_fn(metric_fn_name)
        if fn is None:
            logger.warning(
                "Skipping metric '%s' for process '%s': unknown fn '%s'.",
                metric_name,
                process_name,
                metric_fn_name,
            )
            return None
        raw_inputs = metric_spec.get("inputs")
        input_map = raw_inputs if isinstance(raw_inputs, dict) else {}
        kwargs: Dict[str, Any] = {}
        if input_map:
            for arg_name, source_key in input_map.items():
                key = str(source_key).strip()
                if not key:
                    continue
                kwargs[str(arg_name)] = _resolve_metric_source_value(
                    key,
                    result_payload,
                    runner_inputs,
                    input_aliases,
                )
        else:
            defaults = _default_metric_inputs(metric_fn_name)
            for arg_name, candidates in defaults.items():
                kwargs[arg_name] = _first_available_metric_value(
                    candidates,
                    result_payload,
                    runner_inputs,
                    input_aliases,
                )

        missing_args = [k for k, v in kwargs.items() if v is None]
        if missing_args:
            logger.warning(
                "Skipping metric '%s' for process '%s': missing inputs %s.",
                metric_name,
                process_name,
                ", ".join(sorted(missing_args)),
            )
            return None
        try:
            return fn(**kwargs)
        except Exception as err:
            logger.warning(
                "Failed computing metric '%s' for process '%s' via fn '%s': %s",
                metric_name,
                process_name,
                metric_fn_name,
                err,
            )
            return None

    from_result = metric_spec.get("from_result")
    source_key = str(from_result).strip() if from_result is not None else metric_name
    value = _resolve_metric_source_value(source_key, result_payload, runner_inputs, input_aliases)
    if value is None:
        logger.warning(
            "Skipping metric '%s' for process '%s': source key '%s' not found.",
            metric_name,
            process_name,
            source_key,
        )
    return value


def _log_configured_process_metrics(
    state_manager: Any,
    run_id: str,
    process_name: str,
    metric_specs: Any,
    result_payload: Dict[str, Any],
    runner_inputs: Dict[str, Any],
    input_aliases: Dict[str, str] | None = None,
) -> None:
    if not isinstance(metric_specs, list):
        return
    for spec in metric_specs:
        if not isinstance(spec, dict):
            continue
        metric_name = str(spec.get("name", "")).strip()
        if not metric_name:
            continue
        value = _compute_metric_value_from_spec(
            spec,
            result_payload,
            runner_inputs,
            process_name,
            input_aliases,
        )
        if value is None:
            continue
        try:
            _log_metric_payload(
                state_manager=state_manager,
                run_id=run_id,
                process_name=process_name,
                metric_name=metric_name,
                value=value,
            )
        except Exception as err:
            logger.warning(
                "Failed logging metric '%s' for process '%s': %s",
                metric_name,
                process_name,
                err,
            )


def _derive_task_seed(base_seed: int, parts: List[str]) -> int:
    import hashlib as _hashlib
    payload = f"{base_seed}|" + "|".join(parts)
    digest = _hashlib.sha256(payload.encode()).digest()
    val = int.from_bytes(digest[:4], "big") & 0x7FFFFFFF
    return val or (base_seed & 0x7FFFFFFF) or 1


def _seed_all(seed: int) -> None:
    import random as _random
    try:
        _random.seed(seed)
    except Exception:
        pass
    try:
        import numpy as _np  # type: ignore
        _np.random.seed(seed)
    except Exception:
        pass
    # Best-effort deep learning libs
    try:
        import torch as _torch  # type: ignore
        try:
            _torch.manual_seed(seed)
        except Exception:
            pass
        try:
            if _torch.cuda.is_available():
                _torch.cuda.manual_seed_all(seed)
        except Exception:
            pass
        try:
            _torch.use_deterministic_algorithms(True)  # type: ignore[attr-defined]
        except Exception:
            pass
    except Exception:
        pass
    


def _seed_rng_for_task(
    run_id: Optional[str],
    process_name: Optional[str],
    step_name: Optional[str],
    iteration: Optional[int],
    seed_override: Optional[int] = None,
) -> None:
    # Gate with task-level seeding toggle; default enabled.
    try:
        enabled = str(os.environ.get("MLOPS_TASK_LEVEL_SEEDING", "1")).lower() not in ("0", "false", "no")
    except Exception:
        enabled = True
    if not enabled:
        return

    if seed_override is None:
        try:
            base = int(os.environ.get("MLOPS_RANDOM_SEED", "42") or 42)
        except Exception:
            base = 42
    else:
        try:
            base = int(seed_override)
        except Exception:
            base = 42

    parts: List[str] = []
    if process_name:
        parts.append(str(process_name))
    if step_name:
        parts.append(str(step_name))
    if iteration is not None:
        try:
            parts.append(str(int(iteration)))
        except Exception:
            parts.append(str(iteration))

    seed_val = _derive_task_seed(base, parts)
    _seed_all(seed_val)


def _maybe_import_custom_model_from_global_config(
    global_params: Dict[str, Any],
    process_name: Optional[str] = None,
) -> None:
    if not isinstance(global_params, dict):
        return

    # Try to load scripts section from project config
    scripts_section: Dict[str, str] | None = None
    default_script: str | None = None
    try:
        project_id = os.environ.get("MLOPS_PROJECT_ID")
        if project_id:
            workspace_root = get_workspace_root()
            project_path = workspace_root / project_id
            config_path = project_path / "configs" / "project_config.yaml"
            if config_path.exists():
                import yaml
                with open(config_path, "r") as f:
                    full_config = yaml.safe_load(f) or {}
                scripts_section = full_config.get("scripts")
                if scripts_section and isinstance(scripts_section, dict):
                    default_script = next(iter(scripts_section)) if scripts_section else None
    except Exception:
        pass

    from expops.core.graph.pipeline_utils import resolve_script_path

    pipeline_cfg = global_params.get("pipeline", {}) if isinstance(global_params, dict) else {}
    process_cfgs = pipeline_cfg.get("processes", []) if isinstance(pipeline_cfg, dict) else []
    script_paths: list[str] = []

    def _base_process_name(name: str) -> str:
        import re

        base = str(name)
        m_seed = re.match(r"^(.*)_seed-?\d+$", base)
        if m_seed and m_seed.group(1):
            base = m_seed.group(1)
        m_part = re.match(r"^(.*)__p\d+$", base)
        if m_part and m_part.group(1):
            base = m_part.group(1)
        return base

    if process_name:
        candidates = {str(process_name), _base_process_name(str(process_name))}
        for proc in process_cfgs:
            if not isinstance(proc, dict) or proc.get("name") not in candidates:
                continue
            component_ref = str(proc.get("component", "")).strip() if isinstance(proc.get("component"), str) else ""
            if component_ref:
                break
            raw_code = proc.get("code")
            code_str = str(raw_code).strip() if isinstance(raw_code, str) else ""
            has_explicit_code = bool(code_str)
            has_data_parallelism = proc.get("data_parallelism") is not None
            has_seed_parallelism = proc.get("seed_parallelism") is not None
            is_default_split = (not has_explicit_code) and (has_data_parallelism or has_seed_parallelism)
            if is_default_split:
                break
            script_key = None
            if has_explicit_code and "." in code_str:
                script_key, _ = code_str.rsplit(".", 1)
                script_key = script_key or None
            sp = resolve_script_path(script_key, scripts_section, default_script) if scripts_section else None
            if sp:
                script_paths = [str(sp)]
            break

    if not script_paths:
        for proc in process_cfgs:
            if not isinstance(proc, dict):
                continue
            component_ref = str(proc.get("component", "")).strip() if isinstance(proc.get("component"), str) else ""
            if component_ref:
                continue
            proc_type = str(proc.get("type", "process"))
            if proc_type == "chart":
                continue
            raw_code = proc.get("code")
            code_str = str(raw_code).strip() if isinstance(raw_code, str) else ""
            has_explicit_code = bool(code_str)
            has_data_parallelism = proc.get("data_parallelism") is not None
            has_seed_parallelism = proc.get("seed_parallelism") is not None
            is_default_split = (not has_explicit_code) and (has_data_parallelism or has_seed_parallelism)
            if is_default_split:
                continue
            script_key = None
            if has_explicit_code and "." in code_str:
                script_key, _ = code_str.rsplit(".", 1)
                script_key = script_key or None
            sp = resolve_script_path(script_key, scripts_section, default_script) if scripts_section else None
            if sp:
                script_paths.append(str(sp))

    if not script_paths:
        return

    unique_script_paths: list[str] = []
    seen_paths: set[str] = set()
    for sp in script_paths:
        if sp not in seen_paths:
            seen_paths.add(sp)
            unique_script_paths.append(sp)

    import importlib
    import importlib.util
    import sys as _sys

    for idx, script_path_str in enumerate(unique_script_paths):
        try:
            module_name = f"custom_model_{idx}_{Path(script_path_str).stem}"
            spec = importlib.util.spec_from_file_location(module_name, script_path_str)
            if spec and spec.loader:
                mod = importlib.util.module_from_spec(spec)
                _sys.modules[module_name] = mod
                spec.loader.exec_module(mod)  # type: ignore[attr-defined]
                continue
        except Exception:
            pass

        # Fall back to importing by module name.
        try:
            stem = Path(script_path_str).stem
            importlib.import_module(stem)
            continue
        except Exception:
            pass


def _maybe_import_builtin_component_runners(global_params: Dict[str, Any]) -> None:
    if not isinstance(global_params, dict):
        return
    pipeline_cfg = global_params.get("pipeline", {}) if isinstance(global_params, dict) else {}
    process_cfgs = pipeline_cfg.get("processes", []) if isinstance(pipeline_cfg, dict) else []
    required_prefixes: list[str] = []
    supported_prefixes = ("sklearn.", "matplotlib.")
    for proc in process_cfgs:
        if not isinstance(proc, dict):
            continue
        component_ref = str(proc.get("component", "")).strip() if isinstance(proc.get("component"), str) else ""
        for prefix in supported_prefixes:
            if component_ref.startswith(prefix) and prefix not in required_prefixes:
                required_prefixes.append(prefix)
    if not required_prefixes:
        return
    try:
        from expops.components.plugin_loader import ensure_component_runners_registered

        ensure_component_runners_registered(required_component_prefixes=required_prefixes)
    except Exception:
        return


def _partition_indices_from_name(name: str) -> list[int]:
    try:
        import re
        return [int(v) for v in re.findall(r"__p(\d+)", str(name))]
    except Exception:
        return []


def _partition_index_from_name(name: str) -> Optional[int]:
    values = _partition_indices_from_name(name)
    return values[-1] if values else None


def _seed_values_from_name(name: str) -> list[int]:
    try:
        import re
        return [int(v) for v in re.findall(r"_seed(-?\d+)", str(name))]
    except Exception:
        return []


def _seed_value_from_name(name: str) -> Optional[int]:
    values = _seed_values_from_name(name)
    return values[-1] if values else None


def _looks_like_partition_map(value: Any) -> bool:
    try:
        if not isinstance(value, dict):
            return False
        for k in value.keys():
            if not isinstance(k, str) or not k.startswith("data"):
                return False
            suffix = k[4:]
            if not suffix.isdigit():
                return False
        return True if value else False
    except Exception:
        return False


def _looks_like_seed_map(value: Any) -> bool:
    try:
        if not isinstance(value, dict):
            return False
        for k in value.keys():
            if not isinstance(k, str):
                return False
            if not k.startswith("seed"):
                return False
            suffix = k[4:]
            if not suffix:
                return False
            if suffix[0] == "-":
                if not suffix[1:].isdigit():
                    return False
            elif not suffix.isdigit():
                return False
        return True if value else False
    except Exception:
        return False


def _looks_like_data_seed_map(value: Any) -> bool:
    try:
        if not isinstance(value, dict):
            return False
        if not value:
            return False
        for k, v in value.items():
            if not isinstance(k, str) or not k.startswith("data"):
                return False
            suffix = k[4:]
            if not suffix.isdigit():
                return False
            if not _looks_like_seed_map(v):
                return False
        return True
    except Exception:
        return False


def _looks_like_partitioned_list(value: Any) -> bool:
    try:
        if not isinstance(value, list):
            return False
        if not value:
            return False
        first = value[0]
        if isinstance(first, (list, tuple)):
            return True
        if hasattr(first, "iloc") and hasattr(first, "shape"):
            return True
        return False
    except Exception:
        return False


def _looks_like_data_parallel_output(result: Any, data_name: str) -> bool:
    try:
        if not isinstance(result, dict):
            return False
        marker = result.get("__data_partition_data_name__")
        if marker is not None and marker != data_name:
            return False
        data_value = result.get(data_name)
        if not isinstance(data_value, list):
            return False
        hashes = result.get("__data_partition_hashes__")
        if isinstance(hashes, list):
            try:
                return len(hashes) == len(data_value)
            except Exception:
                return False
        return _looks_like_partitioned_list(data_value)
    except Exception:
        return False


def _data_key_for_index(part_idx: Optional[int], existing: Optional[dict[str, Any]] = None) -> str:
    if part_idx is not None:
        return f"data{part_idx}"
    if existing:
        return f"data{len(existing) + 1}"
    return "data1"


def _seed_key_for_value(seed_val: Optional[int], existing: Optional[dict[str, Any]] = None) -> str:
    if seed_val is not None:
        return f"seed{seed_val}"
    if existing:
        return f"seed{len(existing) + 1}"
    return "seed1"


def _prepare_runner_kwargs(
    sig: Any,
    ctx: Any,
    process_name: Optional[str],
    dependencies: List[str],
    allow_data_aggregation: bool = False,
    allow_seed_aggregation: bool = False,
    extra_inputs: Optional[Dict[str, Any]] = None,
    partition_index: Optional[int] = None,
    parallel_context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    kwargs: Dict[str, Any] = {}
    sig_params = getattr(sig, "parameters", {}) or {}
    try:
        from collections.abc import Mapping
        if isinstance(sig_params, Mapping):
            sig_params = dict(sig_params)
        else:
            sig_params = {}
    except Exception:
        sig_params = sig_params if isinstance(sig_params, dict) else {}

    if not sig_params:
        return kwargs

    inputs: Dict[str, Any] = {}
    sources: Dict[str, str] = {}
    source_partitions: Dict[str, Optional[int]] = {}
    source_seeds: Dict[str, Optional[int]] = {}

    data_source, data_name = _data_parallel_context_info(parallel_context)

    for dep_name in dependencies or []:
        dep_result = ctx.get_step_result(dep_name) if (ctx and hasattr(ctx, "get_step_result")) else None
        if not dep_result:
            continue
        if not isinstance(dep_result, dict):
            raise ValueError(
                f"Process '{process_name}' dependency '{dep_name}' must return a dictionary, "
                f"got {type(dep_result).__name__}."
            )
        if partition_index is not None and data_name and isinstance(dep_result.get(data_name), list):
            should_select = False
            if data_source and _matches_data_source(dep_name, data_source):
                should_select = True
            elif _looks_like_data_parallel_output(dep_result, data_name):
                should_select = True
            if should_select:
                dep_result = _select_partition_value(dep_result, data_name, int(partition_index))
        part_idx = None
        seed_val = None
        try:
            if isinstance(dep_result, dict):
                part_idx = dep_result.get("__partition_index__")
                seed_val = dep_result.get("__seed_value__")
        except Exception:
            part_idx = None
            seed_val = None
        # Fallback to parsing partition/seed indices from the dependency name when
        # structured metadata is not present on the result payload. This keeps real
        # metadata authoritative while allowing name-based aggregation for simple
        # dict results (e.g. in tests or lightweight contexts).
        if part_idx is None:
            part_idx = _partition_index_from_name(dep_name)
        if seed_val is None:
            seed_val = _seed_value_from_name(dep_name)
        for key, value in dep_result.items():
            if isinstance(key, str) and key.startswith("__"):
                continue
            if key in inputs:
                if not allow_data_aggregation and not allow_seed_aggregation:
                    prev_source = sources.get(key, "unknown")
                    raise ValueError(
                        f"Duplicate input key '{key}' from dependency '{dep_name}' conflicts with '{prev_source}'."
                    )
                if allow_data_aggregation and allow_seed_aggregation:
                    existing = inputs.get(key)
                    if not _looks_like_data_seed_map(existing):
                        prev_idx = source_partitions.get(key)
                        prev_seed = source_seeds.get(key)
                        nested: Dict[str, Any] = {}
                        data_key = _data_key_for_index(prev_idx)
                        nested[data_key] = {_seed_key_for_value(prev_seed): existing}
                        inputs[key] = nested
                    nested = inputs.get(key)
                    if not isinstance(nested, dict):
                        nested = {}
                        inputs[key] = nested
                    data_key = _data_key_for_index(part_idx, nested)
                    data_bucket = nested.get(data_key)
                    if not isinstance(data_bucket, dict):
                        data_bucket = {}
                        nested[data_key] = data_bucket
                    seed_key = _seed_key_for_value(seed_val, data_bucket)
                    data_bucket[seed_key] = value
                    continue
                if allow_data_aggregation:
                    existing = inputs.get(key)
                    if not _looks_like_partition_map(existing):
                        prev_idx = source_partitions.get(key)
                        part_map: Dict[str, Any] = {}
                        part_map[_data_key_for_index(prev_idx)] = existing
                        inputs[key] = part_map
                    part_map = inputs.get(key)
                    if not isinstance(part_map, dict):
                        part_map = {}
                        inputs[key] = part_map
                    data_key = _data_key_for_index(part_idx, part_map)
                    part_map[data_key] = value
                    continue
                if allow_seed_aggregation:
                    existing = inputs.get(key)
                    if not _looks_like_seed_map(existing):
                        prev_seed = source_seeds.get(key)
                        seed_map: Dict[str, Any] = {}
                        seed_map[_seed_key_for_value(prev_seed)] = existing
                        inputs[key] = seed_map
                    seed_map = inputs.get(key)
                    if not isinstance(seed_map, dict):
                        seed_map = {}
                        inputs[key] = seed_map
                    seed_key = _seed_key_for_value(seed_val, seed_map)
                    seed_map[seed_key] = value
                    continue
            inputs[key] = value
            sources[key] = f"dependency:{dep_name}"
            source_partitions[key] = part_idx
            source_seeds[key] = seed_val

    try:
        proc_params = ctx.get_parameters(process_name) if ctx else {}
    except Exception:
        proc_params = {}
    if isinstance(proc_params, dict):
        for key, value in proc_params.items():
            if key in inputs:
                prev_source = sources.get(key, "dependency")
                raise ValueError(
                    f"Duplicate input key '{key}' from parameters conflicts with '{prev_source}'."
                )
            inputs[key] = value
            sources[key] = "parameters"
            source_partitions[key] = None
            source_seeds[key] = None

    if isinstance(extra_inputs, dict):
        for key, value in extra_inputs.items():
            inputs[key] = value
            sources[key] = "extra"
            source_partitions[key] = None
            source_seeds[key] = None

    import inspect
    param_values = list(sig_params.values())
    has_var_kw = any(
        isinstance(param, inspect.Parameter) and param.kind == inspect.Parameter.VAR_KEYWORD
        for param in param_values
    )
    if has_var_kw:
        kwargs.update(inputs)
        return kwargs
    if param_values and not all(isinstance(param, inspect.Parameter) for param in param_values):
        kwargs.update(inputs)
        return kwargs

    missing_required: List[str] = []
    for param in param_values:
        if not isinstance(param, inspect.Parameter):
            continue
        if param.kind not in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.KEYWORD_ONLY):
            continue
        if param.default is not inspect._empty:
            continue
        if param.name == "context":
            continue
        if param.name not in inputs:
            missing_required.append(param.name)
    if missing_required:
        available = ", ".join(sorted(inputs.keys())) or "none"
        missing = ", ".join(sorted(set(missing_required)))
        raise ValueError(
            f"Process '{process_name}' missing required inputs: {missing}. "
            f"Available inputs: {available}."
        )

    for name in sig_params.keys():
        if name in inputs:
            kwargs[name] = inputs[name]
    return kwargs


def _resolve_partition_sizes(total: int, size_spec: Any) -> List[int]:
    if isinstance(size_spec, (list, tuple)):
        sizes = [int(x) for x in size_spec]
        if any(s < 0 for s in sizes):
            raise ValueError("Partition sizes must be non-negative.")
        if sum(sizes) != total:
            raise ValueError(f"Partition sizes must sum to {total}, got {sum(sizes)}.")
        return sizes
    count = int(size_spec)
    if count <= 0:
        raise ValueError("Partition count must be > 0.")
    base = total // count
    rem = total % count
    return [base + (1 if i < rem else 0) for i in range(count)]


def _split_rows(value: Any, size_spec: Any) -> List[Any]:
    try:
        total = len(value)
    except Exception:
        raise ValueError("Data parallelism expects a row-splittable object with length.")
    sizes = _resolve_partition_sizes(total, size_spec)
    parts: List[Any] = []
    start = 0
    for size in sizes:
        end = start + size
        if hasattr(value, "iloc"):
            part = value.iloc[start:end]
        else:
            part = value[start:end]
        parts.append(part)
        start = end
    return parts


def _collect_dependency_outputs(ctx: Any, dependencies: List[str]) -> dict[str, Any]:
    merged: Dict[str, Any] = {}
    for dep_name in dependencies or []:
        dep_result = ctx.get_step_result(dep_name) if (ctx and hasattr(ctx, "get_step_result")) else None
        if not dep_result:
            continue
        if not isinstance(dep_result, dict):
            raise ValueError(
                f"Process dependency '{dep_name}' must return a dictionary, got {type(dep_result).__name__}."
            )
        for key, value in dep_result.items():
            if isinstance(key, str) and key.startswith("__"):
                continue
            if key in merged:
                raise ValueError(
                    f"Duplicate input key '{key}' from dependency '{dep_name}' conflicts with another upstream."
                )
            merged[key] = value
    return merged


def _merge_upstream_data_parallel_value(merged: dict[str, Any], dp_cfg: dict[str, Any]) -> dict[str, Any]:
    """If merged[data_name] is a list of partition-like items (e.g. from chained data_parallel),
    concatenate into a single row-splittable value so _apply_data_parallel_split splits rows, not the list.
    """
    data_name = dp_cfg.get("data_name") or "data"
    if data_name not in merged:
        return merged
    val = merged[data_name]
    if not isinstance(val, list) or len(val) == 0:
        return merged
    try:
        first = val[0]
        if hasattr(first, "iloc"):
            import pandas as pd
            merged[data_name] = pd.concat(val, axis=0, ignore_index=True)
            return merged
    except Exception:
        pass
    try:
        if hasattr(first, "__array_interface__") or (type(first).__name__ == "ndarray"):
            import numpy as np
            merged[data_name] = np.concatenate(val, axis=0)
            return merged
    except Exception:
        pass
    try:
        import itertools
        merged[data_name] = list(itertools.chain.from_iterable(val))
        return merged
    except Exception:
        return merged


def _apply_data_parallel_split(ret: Any, dp_cfg: dict[str, Any], default_data_name: str = "data") -> dict[str, Any]:
    data_name = dp_cfg.get("data_name") or None
    if isinstance(ret, list):
        if not data_name:
            data_name = default_data_name
        ret = {data_name: ret}
    if not isinstance(ret, dict):
        raise ValueError(f"Data-parallel process must return a list or dict, got {type(ret).__name__}.")
    if not data_name:
        if "data" in ret:
            data_name = "data"
        else:
            raise ValueError("data_name is required when returning a dict for data parallelism.")
    if data_name not in ret:
        raise ValueError(f"Data-parallel output missing '{data_name}' key.")
    ret[data_name] = _split_rows(ret[data_name], dp_cfg.get("size"))
    try:
        from ..hashing.data_hashing import compute_partition_hashes
        ret["__data_partition_hashes__"] = compute_partition_hashes(ret[data_name])
        ret["__data_partition_data_name__"] = data_name
    except Exception:
        pass
    return ret


def _select_partition_value(split_result: dict[str, Any], data_name: str, partition_index: int) -> dict[str, Any]:
    if data_name not in split_result:
        raise ValueError(f"Partition input missing '{data_name}' key.")
    partitions = split_result.get(data_name)
    if not isinstance(partitions, list):
        raise ValueError("Partition input is not a list of partitions.")
    if partition_index <= 0 or partition_index > len(partitions):
        raise ValueError(f"Partition index {partition_index} out of range (1..{len(partitions)}).")
    out = dict(split_result)
    out[data_name] = partitions[partition_index - 1]
    # Propagate selected partition hash so downstream nodes can resolve partition-aware cache keys.
    try:
        hashes = split_result.get("__data_partition_hashes__")
        if isinstance(hashes, list) and 0 < partition_index <= len(hashes):
            selected_hash = hashes[partition_index - 1]
            if selected_hash is not None:
                out["__data_hash__"] = str(selected_hash)
        elif split_result.get("__data_hash__"):
            out["__data_hash__"] = str(split_result.get("__data_hash__"))
    except Exception:
        pass
    return out


def _data_parallel_context_info(parallel_ctx: Any) -> tuple[Optional[str], Optional[str]]:
    if not isinstance(parallel_ctx, dict):
        return None, None
    layers = parallel_ctx.get("data_layers")
    if isinstance(layers, list) and layers:
        latest = layers[-1] if isinstance(layers[-1], dict) else None
        if latest:
            source = latest.get("source")
            data_name = latest.get("data_name") or "data"
            return (str(source) if source is not None else None), (str(data_name) if data_name is not None else None)
    if str(parallel_ctx.get("type") or "") != "data_parallelism":
        return None, None
    source = parallel_ctx.get("source")
    data_name = parallel_ctx.get("data_name") or "data"
    return (str(source) if source is not None else None), (str(data_name) if data_name is not None else None)


def _resolve_process_data_hash(
    ctx: Any,
    dependencies: List[str],
    parallel_context: Any,
) -> tuple[Optional[str], bool]:
    try:
        from ..hashing.data_hashing import resolve_data_hash_for_process
    except Exception:
        return (getattr(ctx, "data_hash", None), False)
    return resolve_data_hash_for_process(
        dependencies or [],
        parallel_context,
        get_result=lambda name: (
            ctx.get_step_result_for_hash(name) 
            if (ctx and hasattr(ctx, "get_step_result_for_hash")) 
            else (ctx.get_step_result(name) if (ctx and hasattr(ctx, "get_step_result")) else None)
        ),
        fallback_hash=getattr(ctx, "data_hash", None),
    )


def _matches_data_source(dep_name: str, source: Optional[str]) -> bool:
    """Delegate to the shared data_hashing helper to avoid drift."""
    try:
        from ..hashing.data_hashing import matches_data_source as _matches
    except Exception:
        _matches = None  # type: ignore[assignment]
    if _matches is None:
        if not source:
            return False
        dep = str(dep_name)
        if dep == source:
            return True
        return dep.startswith(f"{source}_seed") or dep.startswith(f"{source}__p")
    return _matches(dep_name, source)


def _maybe_select_partition_output(
    result: Any,
    dependencies: List[str],
    partition_index: Optional[int],
    parallel_ctx: Any,
) -> Any:
    if partition_index is None:
        return result
    data_source, data_name = _data_parallel_context_info(parallel_ctx)
    if not data_source or not data_name:
        return result
    if not any(_matches_data_source(dep, data_source) for dep in (dependencies or [])):
        return result
    if not isinstance(result, dict):
        return result
    if not isinstance(result.get(data_name), list):
        return result
    return _select_partition_value(result, data_name, int(partition_index))


def _compute_process_lookup_hashes_worker(
    state_manager: Any,
    ctx: Any,
    process_name: str,
    dependencies: List[str],
    dependency_map: Optional[Dict[str, List[str]]] = None,
    lookup_name: Optional[str] = None,
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Compute (ih, ch, fh) on the worker using the same helper as the driver."""
    try:
        from ..hashing.process_hashing import compute_process_hashes
    except Exception:
        compute_process_hashes = None  # type: ignore[assignment]

    dep_map: Dict[str, List[str]] = {}
    try:
        for k, v in (dependency_map or {}).items():
            dep_map[str(k)] = sorted(set(v or []))
    except Exception:
        dep_map = {}
    dep_map.setdefault(process_name, sorted(set(dependencies or [])))

    if compute_process_hashes:
        ih, ch, fh = compute_process_hashes(state_manager, ctx, process_name, dep_map, lookup_name=lookup_name)
    else:
        ih = ch = fh = None

    return (ih, ch, fh)


def _execute_process_on_worker(ctx: Any, proc_payload: Dict[str, Any], run_id: Optional[str]) -> ExecutionResult:
    process_name = proc_payload.get('name')
    lightweight_requested = isinstance(proc_payload, dict) and bool(proc_payload.get('lightweight_result'))
    start_time = time.time()
    runner_inputs: Dict[str, Any] = {}
    # Deterministic task-level seeding (process scope)
    seed_override = None
    if isinstance(proc_payload, dict):
        seed_override = proc_payload.get("seed_value")
    _seed_rng_for_task(run_id, process_name, None, 0, seed_override=seed_override)

    dp_cfg = _normalize_data_parallelism_cfg(proc_payload.get("data_parallelism") if isinstance(proc_payload, dict) else None)
    sp_cfg = _normalize_seed_parallelism_cfg(proc_payload.get("seed_parallelism") if isinstance(proc_payload, dict) else None)
    parallel_ctx = proc_payload.get("parallel_context") if isinstance(proc_payload, dict) else {}
    is_partition_node = (
        str(proc_payload.get("process_type", "")) == "data_partition"
        or (isinstance(parallel_ctx, dict) and parallel_ctx.get("role") == "partition")
    )
    partition_index = proc_payload.get("partition_index") if isinstance(proc_payload, dict) else None
    seed_value = proc_payload.get("seed_value") if isinstance(proc_payload, dict) else None

    from expops.core.runtime.step_system import get_process_registry as _get_pr, set_current_context as _set_ctx, set_current_process_context as _set_proc
    import io as _io
    import contextlib as _ctxlib
    import logging as _logging
    _log_stream = _io.StringIO()
    _stdout_stream = _io.StringIO()
    _stderr_stream = _io.StringIO()
    _root_logger = _logging.getLogger()
    _prev_root_level = getattr(_root_logger, "level", _logging.INFO)
    _handler = _logging.StreamHandler(_log_stream)
    _prev_http_levels: dict = {}
    try:
        _handler.setLevel(_logging.DEBUG)
        _root_logger.addHandler(_handler)
        _root_logger.setLevel(_logging.DEBUG)
        for _name in ("urllib3", "urllib3.connectionpool", "google.auth", "google.auth.transport.requests", "google.resumable_media"):
            _lg = _logging.getLogger(_name)
            _prev_http_levels[_lg] = _lg.level
            _lg.setLevel(_logging.WARNING)
    except Exception:
        pass

    def _cleanup_capture() -> None:
        try:
            _root_logger.removeHandler(_handler)
        except Exception:
            pass
        try:
            _root_logger.setLevel(_prev_root_level)
        except Exception:
            pass
        for _lg, _lvl in _prev_http_levels.items():
            try:
                _lg.setLevel(_lvl)
            except Exception:
                pass

    state_manager = None
    cache_config = proc_payload.get('cache_config', {}) if isinstance(proc_payload, dict) else {}
    if cache_config:
        try:
            state_manager = _create_worker_state_manager(cache_config)
        except Exception:
            state_manager = None
    if not state_manager:
        try:
            from expops.core.runtime.step_system import get_current_state_manager
            state_manager = get_current_state_manager()
        except Exception:
            state_manager = None
    if not state_manager:
        try:
            from expops.core.runtime.step_system import _get_step_system
            ss = _get_step_system()
            if ss and hasattr(ss, 'state_manager'):
                state_manager = ss.state_manager
        except Exception:
            state_manager = None
    # Final fallback: initialize worker state manager from context if still missing
    if not state_manager:
        try:
            _gc_ctx = getattr(ctx, 'global_config', {}) if ctx else {}
            _pid_ctx = getattr(ctx, 'project_id', None)
            _maybe_init_worker_state_manager(_gc_ctx, _pid_ctx)
            from expops.core.runtime.step_system import get_state_manager as _get_sm_fallback
            state_manager = _get_sm_fallback()
        except Exception:
            state_manager = None

    # Resolve process definition early to compute canonical hashes using code_function mapping
    pr = _get_pr()
    lookup_name = proc_payload.get('code_function') or process_name
    pdef = pr.get_process(lookup_name) if pr else None
    runner = getattr(pdef, 'runner', None) if pdef else None
    if not callable(runner):
        _maybe_import_builtin_component_runners(getattr(ctx, 'global_config', {}) or {})
        _maybe_import_custom_model_from_global_config(getattr(ctx, 'global_config', {}) or {}, process_name=process_name)
        pr = _get_pr()
        pdef = pr.get_process(lookup_name) if pr else None
        runner = getattr(pdef, 'runner', None) if pdef else None
    data_hash = None
    partition_expected = False
    data_aware_ih = None
    completion_ih: Optional[str] = None
    completion_ch: Optional[str] = None
    completion_fh: Optional[str] = None
    # Record process started exactly at timing start using unified hashing
    try:
        if state_manager and run_id and process_name:
            deps = proc_payload.get('dependencies', []) or []
            dep_map = proc_payload.get('dependency_map') or {}
            ih, ch, fh = _compute_process_lookup_hashes_worker(
                state_manager, ctx, process_name, deps, dep_map, lookup_name=lookup_name
            )
            ch, fh = _apply_hash_overrides(proc_payload, ch, fh)
            fh = _ensure_chart_function_hash(proc_payload, ctx, fh)
            data_hash, partition_expected = _resolve_process_data_hash(ctx, deps, parallel_ctx)
            try:
                from ..hashing.data_hashing import compute_data_aware_input_hash
                data_aware_ih = compute_data_aware_input_hash(state_manager, ih, data_hash)
            except Exception:
                data_aware_ih = ih
            if partition_expected and not data_hash:
                data_aware_ih = None
            state_manager.record_process_started(
                run_id,
                process_name,
                input_hash=data_aware_ih,
                config_hash=ch,
                function_hash=fh,
                started_at=start_time,
            )
    except Exception:
        pass

    # Process-level cache check on worker when partition hashes are only known here
    if state_manager and process_name and data_aware_ih and proc_payload.get("has_state_manager"):
        try:
            cached_data = state_manager.get_cached_process_result_with_metadata(
                process_name,
                input_hash=data_aware_ih,
                config_hash=ch,
                function_hash=fh,
            )
        except Exception:
            cached_data = None
        if cached_data is not None:
            try:
                cached_proc, cached_run_id, cached_metadata = cached_data
            except Exception:
                cached_proc = cached_data if not isinstance(cached_data, tuple) else None
            if isinstance(cached_proc, dict) and data_hash:
                cached_proc.setdefault("__data_hash__", data_hash)
            if lightweight_requested:
                cache_path = _resolve_process_cache_path(
                    state_manager,
                    process_name,
                    data_aware_ih,
                    ch,
                    fh,
                )
                if cache_path:
                    envelope = _build_lightweight_result_envelope(
                        process_name=process_name,
                        result_payload=cached_proc if isinstance(cached_proc, dict) else None,
                        cache_path=cache_path,
                        input_hash=data_aware_ih,
                        config_hash=ch,
                        function_hash=fh,
                    )
                    _cleanup_capture()
                    return ExecutionResult(
                        name=process_name,
                        result=envelope,
                        execution_time=0.0,
                        was_cached=True,
                        error=None,
                    )
            _cleanup_capture()
            return ExecutionResult(
                name=process_name,
                result=cached_proc,
                execution_time=0.0,
                was_cached=True,
                error=None,
            )

    base_dir = (os.environ.get("MLOPS_WORKSPACE_BASE_DIR") or "/tmp").strip() or "/tmp"
    project_id_ws = getattr(ctx, "project_id", None) or os.environ.get("MLOPS_PROJECT_ID") or "default"
    run_id_val = run_id or getattr(ctx, "run_id", None) or os.environ.get("MLOPS_RUN_ID") or "default"
    cleanup_policy = (os.environ.get("MLOPS_WORKSPACE_CLEANUP") or "always").strip().lower()
    temp_workspace = _create_process_temp_workspace(base_dir, str(project_id_ws), str(run_id_val), process_name or "process")
    try:
        project_root = get_projects_root(get_workspace_root()) / str(project_id_ws)
        _copy_project_data_dirs_into_temp_workspace(project_root, temp_workspace)
    except Exception as copy_exc:
        logger.debug("[Workspace] Copy project data dirs into temp workspace skipped: %s", copy_exc)
    _old_cwd = os.getcwd()
    _old_tmpdir = os.environ.get("TMPDIR")
    _old_tmp = os.environ.get("TMP")
    _old_temp = os.environ.get("TEMP")
    try:
        os.chdir(temp_workspace)
        os.environ["TMPDIR"] = os.environ["TMP"] = os.environ["TEMP"] = str(temp_workspace)
    except Exception:
        pass
    try:
        try:
            if ctx is not None:
                ctx.current_data_hash = data_hash or getattr(ctx, "data_hash", None)
        except Exception:
            pass

        # Special handling for chart processes
        if str(proc_payload.get('process_type', 'process')) == 'chart':
            try:
                result = _run_chart_process_on_worker(ctx, proc_payload, run_id, process_workspace_dir=temp_workspace)
                exec_time = time.time() - start_time
                if isinstance(result, dict):
                    rc = result.get("returncode")
                    artifact_count = result.get("artifact_count")
                    try:
                        rc_int = int(rc) if rc is not None else 0
                    except Exception:
                        rc_int = 0
                    try:
                        art_int = int(artifact_count) if artifact_count is not None else 0
                    except Exception:
                        art_int = 0

                    # When using process temp workspace, sync chart output to persistent artifacts and record in KV
                    if temp_workspace is not None and art_int > 0 and state_manager:
                        try:
                            chart_spec = proc_payload.get("chart_spec") or {}
                            _sync_process_workspace_to_artifacts(
                                temp_workspace,
                                state_manager,
                                str(project_id_ws),
                                str(run_id or "default"),
                                process_name,
                                probe_paths=chart_spec.get("probe_paths"),
                                chart_type=str(chart_spec.get("chart_type") or "static").lower(),
                            )
                        except Exception as sync_exc:
                            logger.warning("[Charts] Sync chart artifacts failed: %s", sync_exc)

                    chart_error: Optional[str] = None
                    if rc_int != 0:
                        chart_error = (
                            f"Chart subprocess failed (exit_code={rc_int}). "
                            "Search for '[Charts]' in logs for subprocess output."
                        )
                    elif art_int <= 0:
                        chart_error = (
                            "Chart produced no artifacts (0 files). "
                            "Ensure the chart function calls plt.savefig(...) or writes files to the process output dir. "
                            f"Output dir: {result.get('output_dir')}. "
                            "Search for '[Charts]' in logs for subprocess output."
                        )

                    is_success = chart_error is None

                    # Record completion for chart processes so UI/KV reflect status immediately
                    try:
                        from ..runtime.step_state_manager import ProcessExecutionResult as _ProcessExec
                        if state_manager:
                            ih, ch, fh = _compute_process_lookup_hashes_worker(
                                state_manager,
                                ctx,
                                process_name,
                                proc_payload.get('dependencies', []) or [],
                                proc_payload.get('dependency_map') or {},
                                lookup_name=lookup_name,
                            )
                            ch, fh = _apply_hash_overrides(proc_payload, ch, fh)
                            fh = _ensure_chart_function_hash(proc_payload, ctx, fh)
                            data_hash, partition_expected = _resolve_process_data_hash(
                                ctx, proc_payload.get('dependencies', []) or [], parallel_ctx
                            )
                            try:
                                from ..hashing.data_hashing import compute_data_aware_input_hash
                                data_aware_ih = compute_data_aware_input_hash(state_manager, ih, data_hash)
                            except Exception:
                                data_aware_ih = ih
                            if partition_expected and not data_hash:
                                data_aware_ih = None
                            enable_logging = proc_payload.get('logging', True) if isinstance(proc_payload, dict) else True
                            state_manager.record_process_completion(
                                run_id or 'default',
                                _ProcessExec(
                                    process_name=process_name,
                                    success=is_success,
                                    result=result if is_success else None,
                                    error=chart_error,
                                    execution_time=exec_time,
                                    timestamp=datetime.now().isoformat(),
                                ),
                                input_hash=data_aware_ih,
                                config_hash=ch,
                                function_hash=fh,
                                was_cached=False,
                                enable_logging=enable_logging,
                            )
                    except Exception:
                        pass
                    _cleanup_capture()
                    return ExecutionResult(name=process_name, result=result, execution_time=exec_time, was_cached=False, error=chart_error)
                else:
                    _cleanup_capture()
                    return ExecutionResult(name=process_name, result={'__logs__': 'Invalid chart result'}, execution_time=exec_time, was_cached=False, error=None)
            except Exception as e:
                exec_time = time.time() - start_time
                try:
                    from ..runtime.step_state_manager import ProcessExecutionResult as _ProcessExec
                    if state_manager:
                        ih, ch, fh = _compute_process_lookup_hashes_worker(
                            state_manager,
                            ctx,
                            process_name,
                            proc_payload.get('dependencies', []) or [],
                            proc_payload.get('dependency_map') or {},
                            lookup_name=lookup_name,
                        )
                        ch, fh = _apply_hash_overrides(proc_payload, ch, fh)
                        fh = _ensure_chart_function_hash(proc_payload, ctx, fh)
                        data_hash, partition_expected = _resolve_process_data_hash(
                            ctx, proc_payload.get('dependencies', []) or [], parallel_ctx
                        )
                        try:
                            from ..hashing.data_hashing import compute_data_aware_input_hash
                            data_aware_ih = compute_data_aware_input_hash(state_manager, ih, data_hash)
                        except Exception:
                            data_aware_ih = ih
                        if partition_expected and not data_hash:
                            data_aware_ih = None
                        enable_logging = proc_payload.get('logging', True) if isinstance(proc_payload, dict) else True
                        state_manager.record_process_completion(
                            run_id or 'default',
                            _ProcessExec(
                                process_name=process_name,
                                success=False,
                                result=None,
                                error=str(e),
                                execution_time=exec_time,
                                timestamp=datetime.now().isoformat(),
                            ),
                            input_hash=data_aware_ih,
                            config_hash=ch,
                            function_hash=fh,
                            was_cached=False,
                            enable_logging=enable_logging,
                        )
                except Exception:
                    pass
                _cleanup_capture()
                return ExecutionResult(name=process_name, result={'__error_context__': str(e)}, execution_time=exec_time, was_cached=False, error=str(e))

        _set_ctx(ctx)
        try:
            try:
                _set_proc(process_name)
            except Exception:
                pass
            dependencies = proc_payload.get('dependencies', [])
            did_split = False
            with _ctxlib.redirect_stdout(_stdout_stream), _ctxlib.redirect_stderr(_stderr_stream):
                if not callable(runner):
                    if is_partition_node:
                        if not dependencies:
                            raise ValueError(f"Partition node '{process_name}' has no upstream dependency.")
                        upstream_name = dependencies[0]
                        upstream_result = ctx.get_step_result(upstream_name) if (ctx and hasattr(ctx, "get_step_result")) else None
                        if not isinstance(upstream_result, dict):
                            raise ValueError(f"Partition input from '{upstream_name}' must be a dict.")
                        data_name = None
                        if isinstance(parallel_ctx, dict):
                            data_name = parallel_ctx.get("data_name")
                        data_name = data_name or "data"
                        part_idx = int(partition_index or 1)
                        ret = _select_partition_value(upstream_result, data_name, part_idx)
                    elif dp_cfg:
                        merged = _collect_dependency_outputs(ctx, dependencies)
                        merged = _merge_upstream_data_parallel_value(merged, dp_cfg)
                        data_name = (dp_cfg.get("data_name") or "data") if isinstance(dp_cfg, dict) else "data"
                        if (
                            partition_index is not None
                            and data_name in merged
                            and not isinstance(merged.get(data_name), list)
                        ):
                            part_count = (dp_cfg.get("size") or 1) if isinstance(dp_cfg, dict) else 1
                            if part_count > 1:
                                try:
                                    chunks = _split_rows(merged[data_name], part_count)
                                    idx = int(partition_index)
                                    if 1 <= idx <= len(chunks):
                                        merged[data_name] = chunks[idx - 1]
                                except Exception:
                                    pass
                        ret = _apply_data_parallel_split(merged, dp_cfg)
                        did_split = True
                    elif sp_cfg:
                        ret = _collect_dependency_outputs(ctx, dependencies)
                        ret = _maybe_select_partition_output(ret, dependencies, partition_index, parallel_ctx)
                    else:
                        raise RuntimeError(f"No runner defined for process '{process_name}'.")
                else:
                    import inspect
                    try:
                        original_func = getattr(pdef, 'original_func', None) if pdef else None
                        sig = inspect.signature(original_func) if original_func else inspect.signature(runner)
                    except Exception:
                        sig = inspect.signature(runner)
                    allow_data_agg = bool(proc_payload.get("data_aggregation")) if isinstance(proc_payload, dict) else False
                    allow_seed_agg = bool(proc_payload.get("seed_aggregation")) if isinstance(proc_payload, dict) else False
                    extra_inputs = {}
                    seed_value = proc_payload.get("seed_value") if isinstance(proc_payload, dict) else None
                    if seed_value is not None:
                        try:
                            extra_inputs["random_seed"] = int(seed_value)
                        except Exception:
                            extra_inputs["random_seed"] = seed_value
                    try:
                        seeds_val = sp_cfg.get("seeds") if isinstance(sp_cfg, dict) else None
                        if seeds_val is not None:
                            extra_inputs["seeds"] = list(seeds_val) if isinstance(seeds_val, (list, tuple)) else seeds_val
                    except Exception:
                        extra_inputs = {}
                    kwargs = _prepare_runner_kwargs(
                        sig,
                        ctx,
                        process_name,
                        dependencies,
                        allow_data_aggregation=allow_data_agg,
                        allow_seed_aggregation=allow_seed_agg,
                        extra_inputs=extra_inputs if extra_inputs else None,
                        partition_index=partition_index,
                        parallel_context=parallel_ctx,
                    )
                    runner_inputs = dict(kwargs) if isinstance(kwargs, dict) else {}
                    ret = runner(**kwargs) if kwargs else runner()
        except Exception as runner_error:
            exec_time = time.time() - start_time
            error_result = {
                '__logs__': (_log_stream.getvalue() or '') + (_stdout_stream.getvalue() or '') + (_stderr_stream.getvalue() or '')
            }
            # Best-effort: record a failed completion so UIs and tests can observe terminal status,
            # even when the runner raises before normal completion bookkeeping.
            try:
                if state_manager and process_name:
                    try:
                        from ..runtime.step_state_manager import StepStateManager as _SSM, ProcessExecutionResult as _ProcessExec  # type: ignore
                    except Exception:
                        _SSM = None  # type: ignore[assignment]
                        _ProcessExec = None  # type: ignore[assignment]
                    # When using a real StepStateManager, compute hashes and call the full API.
                    if _SSM is not None and isinstance(state_manager, _SSM) and _ProcessExec is not None:
                        try:
                            deps = proc_payload.get('dependencies', []) or []
                            dep_map = proc_payload.get('dependency_map') or {}
                            ih, ch, fh = _compute_process_lookup_hashes_worker(
                                state_manager,
                                ctx,
                                process_name,
                                deps,
                                dep_map,
                                lookup_name=lookup_name,
                            )
                            ch, fh = _apply_hash_overrides(proc_payload, ch, fh)
                            fh = _ensure_chart_function_hash(proc_payload, ctx, fh)
                            data_hash, partition_expected = _resolve_process_data_hash(ctx, deps, parallel_ctx)
                            try:
                                from ..hashing.data_hashing import compute_data_aware_input_hash
                                data_aware_ih = compute_data_aware_input_hash(state_manager, ih, data_hash)
                            except Exception:
                                data_aware_ih = ih
                            if partition_expected and not data_hash:
                                data_aware_ih = None
                        except Exception:
                            data_aware_ih = None
                            ch = fh = None
                        enable_logging = proc_payload.get('logging', True) if isinstance(proc_payload, dict) else True
                        try:
                            state_manager.record_process_completion(
                                run_id or 'default',
                                _ProcessExec(
                                    process_name=process_name,
                                    success=False,
                                    result=None,
                                    error=str(runner_error),
                                    execution_time=exec_time,
                                    timestamp=datetime.now().isoformat(),
                                ),
                                input_hash=data_aware_ih,
                                config_hash=ch,
                                function_hash=fh,
                                was_cached=False,
                                enable_logging=enable_logging,
                            )
                        except Exception:
                            pass
                    else:
                        # Fallback for tests or custom state manager implementations:
                        # call record_process_completion with a minimal payload.
                        try:
                            from types import SimpleNamespace as _NS
                            proc_result = _NS(
                                process_name=process_name,
                                success=False,
                                result=None,
                                error=str(runner_error),
                                execution_time=exec_time,
                                timestamp=datetime.now().isoformat(),
                            )
                            state_manager.record_process_completion(run_id or 'default', proc_result)
                        except Exception:
                            pass
            except Exception:
                pass
            return ExecutionResult(name=process_name, result=error_result, execution_time=exec_time, was_cached=False, error=str(runner_error))
        finally:
            try:
                _set_proc(None)
            except Exception:
                pass
            try:
                if ctx is not None:
                    ctx.current_data_hash = None
            except Exception:
                pass
            _set_ctx(None)
            _cleanup_capture()

        if dp_cfg and not did_split:
            try:
                ret = _apply_data_parallel_split(ret, dp_cfg)
            except Exception as split_err:
                exec_time = time.time() - start_time
                _cleanup_capture()
                return ExecutionResult(
                    name=process_name,
                    result={'__logs__': (_log_stream.getvalue() or '') + (_stdout_stream.getvalue() or '') + (_stderr_stream.getvalue() or '')},
                    execution_time=exec_time,
                    was_cached=False,
                    error=str(split_err),
                )

        if not isinstance(ret, dict):
            exec_time = time.time() - start_time
            try:
                _captured = {
                    '__logs__': (_log_stream.getvalue() or '') + (_stdout_stream.getvalue() or '') + (_stderr_stream.getvalue() or '')
                }
            except Exception:
                _captured = None
            return ExecutionResult(name=process_name, result=_captured, execution_time=exec_time, was_cached=False, error=f"Process '{process_name}' must return a dictionary, got {type(ret).__name__}.")

        if isinstance(ret, dict):
            # Attach structured parallelism metadata to the result so downstream
            # aggregation can rely on it instead of parsing name suffixes.
            try:
                if partition_index is not None:
                    ret.setdefault("__partition_index__", partition_index)
            except Exception:
                pass
            try:
                if seed_value is not None:
                    ret.setdefault("__seed_value__", seed_value)
            except Exception:
                pass
            try:
                if data_hash:
                    ret.setdefault("__data_hash__", data_hash)
            except Exception:
                pass
            # Expose the full layered parallel context (data/seed) on the result
            # payload so downstream consumers can reason about multi-layer
            # partition/seed structure without relying on process names.
            try:
                if isinstance(parallel_ctx, dict):
                    data_layers_src = parallel_ctx.get("data_layers")
                    seed_layers_src = parallel_ctx.get("seed_layers")
                    layers: Dict[str, Any] = {}
                    if isinstance(data_layers_src, list) and data_layers_src:
                        dl_clean: list[dict[str, Any]] = []
                        for layer in data_layers_src:
                            if not isinstance(layer, dict):
                                continue
                            dl_clean.append(
                                {
                                    "source": layer.get("source"),
                                    "partition_index": layer.get("partition_index"),
                                    "data_name": layer.get("data_name"),
                                }
                            )
                        if dl_clean:
                            layers["data_layers"] = dl_clean
                    if isinstance(seed_layers_src, list) and seed_layers_src:
                        sl_clean: list[dict[str, Any]] = []
                        for layer in seed_layers_src:
                            if not isinstance(layer, dict):
                                continue
                            sl_clean.append(
                                {
                                    "source": layer.get("source"),
                                    "seed_value": layer.get("seed_value"),
                                }
                            )
                        if sl_clean:
                            layers["seed_layers"] = sl_clean
                    if layers and "__parallel_context__" not in ret:
                        ret["__parallel_context__"] = layers
            except Exception:
                pass

        if state_manager and isinstance(ret, dict):
            try:
                enable_logging = proc_payload.get("logging", True) if isinstance(proc_payload, dict) else True
                metric_specs = proc_payload.get("metrics") if isinstance(proc_payload, dict) else None
                if enable_logging:
                    _log_configured_process_metrics(
                        state_manager=state_manager,
                        run_id=run_id or "default",
                        process_name=process_name,
                        metric_specs=metric_specs,
                        result_payload=ret,
                        runner_inputs=runner_inputs,
                        input_aliases=_normalize_metric_input_aliases(
                            proc_payload.get("input_transform") if isinstance(proc_payload, dict) else None
                        ),
                    )
            except Exception as metric_err:
                logger.warning(
                    "Configured metric logging failed for process '%s': %s",
                    process_name,
                    metric_err,
                )

            if state_manager and isinstance(ret, dict):
                try:
                    ret = spill_large_payloads(ret, state_manager, run_id, process_name)
                except Exception as spill_err:
                    logger.error("[PayloadSpill] Failed to spill payload for process %s: %s", process_name, spill_err)
                    raise

            exec_time = time.time() - start_time
            ret["__logs__"] = (_log_stream.getvalue() or "") + (_stdout_stream.getvalue() or "") + (_stderr_stream.getvalue() or "")

            try:
                from ..runtime.step_state_manager import ProcessExecutionResult as _ProcessExec
                if state_manager and ret:
                    ih, ch, fh = _compute_process_lookup_hashes_worker(
                        state_manager,
                        ctx,
                        process_name,
                        proc_payload.get('dependencies', []) or [],
                        proc_payload.get('dependency_map') or {},
                        lookup_name=lookup_name,
                    )
                    data_hash, partition_expected = _resolve_process_data_hash(
                        ctx, proc_payload.get('dependencies', []) or [], parallel_ctx
                    )
                    try:
                        from ..hashing.data_hashing import compute_data_aware_input_hash
                        data_aware_ih = compute_data_aware_input_hash(state_manager, ih, data_hash)
                    except Exception:
                        data_aware_ih = ih
                    if partition_expected and not data_hash:
                        data_aware_ih = None
                    completion_ih = data_aware_ih
                    completion_ch = ch
                    completion_fh = fh
                    enable_logging = proc_payload.get('logging', True) if isinstance(proc_payload, dict) else True
                    state_manager.record_process_completion(
                        run_id or 'default',
                        _ProcessExec(
                            process_name=process_name,
                            success=True,
                            result=ret,
                            execution_time=exec_time,
                            timestamp=datetime.now().isoformat(),
                        ),
                        input_hash=data_aware_ih,
                        config_hash=ch,
                        function_hash=fh,
                        was_cached=False,
                        enable_logging=enable_logging,
                    )
            except Exception:
                pass

            if lightweight_requested:
                try:
                    cache_path = _resolve_process_cache_path(
                        state_manager,
                        process_name,
                        completion_ih,
                        completion_ch,
                        completion_fh,
                    )
                    if cache_path:
                        envelope = _build_lightweight_result_envelope(
                            process_name=process_name,
                            result_payload=ret if isinstance(ret, dict) else None,
                            cache_path=cache_path,
                            input_hash=completion_ih,
                            config_hash=completion_ch,
                            function_hash=completion_fh,
                        )
                        return ExecutionResult(
                            name=process_name,
                            result=envelope,
                            execution_time=exec_time,
                            was_cached=False,
                            error=None,
                        )
                    logger.warning(
                        "[Worker] Lightweight result requested for process '%s' but cache_path was not found; returning full payload",
                        process_name,
                    )
                except Exception:
                    logger.warning(
                        "[Worker] Failed to construct lightweight result envelope for process '%s'; returning full payload",
                        process_name,
                    )

            return ExecutionResult(name=process_name, result=ret, execution_time=exec_time, was_cached=False, error=None)
    finally:
        try:
            is_chart = str(proc_payload.get("process_type", "process")) == "chart"
            if is_chart:
                _sync_process_workspace_to_artifacts(
                    temp_workspace,
                    state_manager,
                    str(project_id_ws),
                    str(run_id_val),
                    process_name or "process",
                    probe_paths=proc_payload.get("probe_paths"),
                    chart_type="static",
                )
        except Exception:
            pass
        try:
            os.chdir(_old_cwd)
        except Exception:
            pass
        if _old_tmpdir is not None:
            os.environ["TMPDIR"] = _old_tmpdir
        else:
            os.environ.pop("TMPDIR", None)
        if _old_tmp is not None:
            os.environ["TMP"] = _old_tmp
        else:
            os.environ.pop("TMP", None)
        if _old_temp is not None:
            os.environ["TEMP"] = _old_temp
        else:
            os.environ.pop("TEMP", None)
        if cleanup_policy == "always":
            try:
                shutil.rmtree(temp_workspace, ignore_errors=True)
            except Exception:
                pass


def _run_chart_process_on_worker(
    ctx: Any,
    proc_payload: Dict[str, Any],
    run_id: Optional[str],
    process_workspace_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    name = proc_payload.get('name')
    if not name:
        logger.error("[Charts] No chart name in proc_payload")
        return {'output_dir': '', 'artifact_count': 0}

    chart_spec = proc_payload.get('chart_spec') or {}
    entrypoint = chart_spec.get('entrypoint') or ''
    if not chart_spec.get('probe_paths'):
        try:
            gcfg = getattr(ctx, 'global_config', {}) if ctx else {}
            pipeline_cfg = (gcfg.get('pipeline') or {}) if isinstance(gcfg, dict) else {}
            processes_cfg = pipeline_cfg.get('processes') or []
            if isinstance(processes_cfg, list):
                for proc in processes_cfg:
                    if isinstance(proc, dict) and proc.get('name') == name and proc.get('probe_paths'):
                        chart_spec['probe_paths'] = proc.get('probe_paths') or {}
                        break
        except Exception:
            pass
    def _probe_paths_preview(value: Any, max_items: int = 8) -> str:
        try:
            if not isinstance(value, dict):
                return str(value)
            parts: list[str] = []
            for idx, (k, v) in enumerate(value.items()):
                if idx >= max_items:
                    parts.append("...")
                    break
                parts.append(f"{k}=>{str(v)[:140]}")
            return ", ".join(parts)
        except Exception:
            return "<unavailable>"

    # Prefer driver-expanded probe paths when already canonical (process[@name=...])
    # so chart subprocess gets the same paths used when writing metrics; only re-expand when needed.
    def _probe_paths_look_expanded(paths: Any) -> bool:
        if not paths or not isinstance(paths, dict):
            return False
        for v in paths.values():
            if isinstance(v, str):
                if "process[@name=" not in v:
                    return False
                continue
            if isinstance(v, dict):
                raw_path = v.get("path")
                if not isinstance(raw_path, str) or "process[@name=" not in raw_path:
                    return False
                continue
            return False
        return True

    try:
        if chart_spec.get('probe_paths') and not _probe_paths_look_expanded(chart_spec.get('probe_paths')):
            gcfg = getattr(ctx, 'global_config', {}) if ctx else {}
            pipeline_cfg = (gcfg.get('pipeline') or {}) if isinstance(gcfg, dict) else {}
            if isinstance(pipeline_cfg, dict) and pipeline_cfg:
                from expops.core.graph.networkx_parser import parse_networkx_pipeline_from_config
                from expops.core.graph.graph_expansion import expand_process_graph
                from expops.core.graph.pipeline_tree import build_pipeline_tree
                from expops.core.cache_probe.probe_path_selectors import (
                    expand_probe_path_xpath,
                    is_probe_path_xpath,
                )

                nx_cfg = parse_networkx_pipeline_from_config(pipeline_cfg)
                expanded_procs = expand_process_graph(nx_cfg.processes or [])
                probe_paths_raw = chart_spec.get('probe_paths') or {}
                if expanded_procs and probe_paths_raw and isinstance(probe_paths_raw, dict):
                    path_selectors: list[str] = []
                    for pv in probe_paths_raw.values():
                        if isinstance(pv, dict):
                            pv_path = pv.get("path")
                            path_selectors.append(str(pv_path or ""))
                        else:
                            path_selectors.append(str(pv or ""))

                    any_xpath = any(is_probe_path_xpath(p) for p in path_selectors if p)
                    pipeline_tree = build_pipeline_tree(
                        expanded_procs, probe_paths_values=path_selectors
                    ) if any_xpath else None

                    expanded: dict[str, Any] = {}
                    for user_key, pv in probe_paths_raw.items():
                        key = str(user_key)
                        if isinstance(pv, dict):
                            selector = pv.get("path")
                            metric = pv.get("metric")
                            label = pv.get("label")
                        else:
                            selector = pv
                            metric = None
                            label = None

                        if not isinstance(selector, str):
                            continue

                        if pipeline_tree is None:
                            expanded_list = [selector]
                        else:
                            expanded_list = expand_probe_path_xpath(selector, pipeline_tree)

                        if not expanded_list:
                            # Keep original selector if expansion matched nothing.
                            if isinstance(pv, dict):
                                out_val = dict(pv)
                                out_val["path"] = selector
                                expanded.setdefault(key, out_val)
                            else:
                                expanded.setdefault(key, selector)
                            continue

                        if len(expanded_list) == 1:
                            resolved = expanded_list[0]
                            if isinstance(pv, dict):
                                out_val = dict(pv)
                                out_val["path"] = resolved
                                expanded.setdefault(key, out_val)
                            else:
                                expanded.setdefault(key, resolved)
                        else:
                            for resolved in expanded_list:
                                if resolved in expanded:
                                    continue
                                if isinstance(pv, dict):
                                    out_val = dict(pv)
                                    out_val["path"] = resolved
                                    # metric/label already in out_val; keep them.
                                    expanded[resolved] = out_val
                                else:
                                    expanded[resolved] = resolved

                    chart_spec['probe_paths'] = expanded
                    logger.info(
                        "[Charts] Probe paths resolved for '%s': %s",
                        name,
                        _probe_paths_preview(chart_spec.get('probe_paths')),
                    )
        elif chart_spec.get('probe_paths') and _probe_paths_look_expanded(chart_spec.get('probe_paths')):
            logger.debug("[Charts] Using driver-expanded probe paths for '%s'", name)
    except Exception as exc:
        # Best-effort only; fall back to raw probe_paths if expansion fails.
        logger.warning(
            "[Charts] Failed to expand probe_paths for '%s': %s. Using raw probe_paths: %s",
            name,
            exc,
            _probe_paths_preview(chart_spec.get('probe_paths')),
        )
    def _load_env_python_map() -> dict[str, str]:
        try:
            raw = os.environ.get("MLOPS_ENV_PYTHON_MAP") or ""
            if not raw:
                return {}
            parsed = json.loads(raw)
            if not isinstance(parsed, dict):
                return {}
            return {str(k): str(v) for k, v in parsed.items() if v}
        except Exception:
            return {}

    env_name = proc_payload.get('environment') or chart_spec.get('environment')
    env_map = _load_env_python_map()
    reporting_python = chart_spec.get('python_interpreter') or (env_map.get(str(env_name)) if env_name else None)
    project_id = getattr(ctx, 'project_id', None) or os.environ.get('MLOPS_PROJECT_ID') or 'default'
    rid = run_id or getattr(ctx, 'run_id', None) or os.environ.get('MLOPS_RUN_ID') or 'default'
    workspace_root = get_workspace_root()
    projects_root = get_projects_root(workspace_root)

    # Safeguard: mark process as running when the chart actually begins execution
    try:
        from expops.core.runtime.step_system import get_state_manager as _get_sm
        sm = _get_sm()
    except Exception:
        sm = None
    try:
        if sm and rid and name:
            already_running = False
            try:
                prev = sm.kv_store.list_run_steps(rid) if hasattr(sm, 'kv_store') else {}
                rec = (prev or {}).get(f"{name}.__process__") or {}
                status = str(rec.get('status') or '').lower()
                already_running = status in ('running','completed','cached','failed')
            except Exception:
                already_running = False
            if not already_running:
                deps = proc_payload.get('dependencies', []) or []
                dep_map = proc_payload.get('dependency_map') or {}
                ih, ch, fh = _compute_process_lookup_hashes_worker(sm, ctx, name, deps, dep_map)
                ch, fh = _apply_hash_overrides(proc_payload, ch, fh)
                fh = _ensure_chart_function_hash(proc_payload, ctx, fh)
                sm.record_process_started(
                    rid,
                    name,
                    input_hash=ih,
                    config_hash=ch,
                    function_hash=fh,
                    started_at=time.time(),
                )
    except Exception:
        pass

    # Use process temp workspace when provided (cwd-based artifact output); otherwise legacy artifacts path
    if process_workspace_dir is not None and process_workspace_dir.exists():
        out_dir = Path(process_workspace_dir)
    else:
        try:
            proj_root = projects_root / project_id
            runtime_root = get_project_runtime_root(proj_root, project_id)
        except Exception:
            runtime_root = Path.cwd() / f".{project_id}"

        try:
            from expops.core.cache_probe.cache_layout import compute_cache_version_hash, build_artifact_relative_path
            from expops.core.cache_probe.probe_path import get_encoded_probe_path
            if sm is not None and hasattr(sm, '_version_hash'):
                _version_hash = sm._version_hash
            else:
                _version_hash = compute_cache_version_hash(proj_root)
            encoded_probe = get_encoded_probe_path(process_name=name, step_name=None, probe_paths=chart_spec.get('probe_paths'))
            rel_path = build_artifact_relative_path(_version_hash, encoded_probe)
        except Exception:
            try:
                from expops.core.cache_probe.cache_layout import compute_cache_version_hash, build_artifact_relative_path
                from expops.core.cache_probe.probe_path import get_encoded_probe_path
                _version_hash = compute_cache_version_hash(proj_root)
                encoded_probe = get_encoded_probe_path(process_name=name, step_name=None)
                rel_path = build_artifact_relative_path(_version_hash, encoded_probe)
            except Exception:
                rel_path = "default"
        out_dir = runtime_root / 'artifacts' / rel_path
        out_dir.mkdir(parents=True, exist_ok=True)

    # Prepare environment
    env = os.environ.copy()
    # Centralized env export for KV backend (best-effort).
    try:
        from expops.runtime.env_export import export_kv_env

        gc = getattr(ctx, "global_config", {}) if ctx else {}
        cache_cfg = (gc.get("cache") or {}) if isinstance(gc, dict) else {}
        backend_cfg = (cache_cfg.get("backend") or {}) if isinstance(cache_cfg, dict) else {}
        project_root = projects_root / str(project_id)
        env.update(export_kv_env(backend_cfg if isinstance(backend_cfg, dict) else {}, workspace_root=workspace_root, project_root=project_root))
    except Exception:
        pass
    env['MLOPS_PROJECT_ID'] = str(project_id)
    env['MLOPS_RUN_ID'] = str(rid)
    env['MLOPS_OUTPUT_DIR'] = str(out_dir)
    env['MLOPS_CHART_NAME'] = str(name)
    env['MLOPS_CHART_TYPE'] = str(chart_spec.get('chart_type') or 'static').lower()

    # Include probe_paths (chart-level overrides merged with global spec at driver)
    try:
        if chart_spec.get('probe_paths'):
            env['MLOPS_PROBE_PATHS'] = json.dumps(chart_spec['probe_paths'])
    except Exception:
        pass

    # Ensure PYTHONPATH contains src dir only for source checkouts (installed packages don't need it)
    try:
        src_root = infer_source_root()
        if src_root and (src_root / "src").exists():
            env['PYTHONPATH'] = f"{src_root / 'src'}:{env.get('PYTHONPATH', '')}".rstrip(":")
    except Exception:
        pass

    # Always use framework entrypoint as a module, and import user script if provided
    # This ensures chart functions are properly discovered and executed
    if entrypoint:
        project_root = projects_root / project_id
        ep = resolve_relative_path(entrypoint, project_root=project_root, workspace_root=workspace_root)
        # Set import path for user's chart script
        env['MLOPS_CHART_IMPORT_FILES'] = str(ep)

    # Build command - always use framework entrypoint as module
    py = reporting_python or os.environ.get('MLOPS_RUNTIME_PYTHON') or sys.executable
    
    # Check if Python interpreter exists and is executable (only for absolute paths)
    py_path = Path(py) if py.startswith('/') else None
    if py_path and not py_path.exists():
        logger.error(f"[Charts] Python interpreter not found: {py}")
        logger.warning(f"[Charts] Falling back to sys.executable")
        py = sys.executable
    
    # Always run as module to ensure proper initialization
    cmd = [py, '-u', '-m', 'expops.reporting.entrypoint', '--oneshot'] + list(chart_spec.get('args') or [])

    # Capture stdout/stderr so output can be returned via __logs__ and logged in the main process.
    # Do NOT use logger here — this runs in a Dask worker process whose handlers are not
    # wired to the main log file.
    import subprocess as _subprocess
    run_cwd = str(out_dir) if (process_workspace_dir is not None and out_dir == Path(process_workspace_dir)) else str(get_workspace_root())
    result = _subprocess.run(cmd, env=env, check=False, cwd=run_cwd,
                             stdout=_subprocess.PIPE, stderr=_subprocess.STDOUT, text=True)
    chart_stdout = (result.stdout or "").strip()

    try:
        returncode = int(getattr(result, "returncode", 0) or 0)
    except Exception:
        returncode = 0
    
    # Upload/record artifacts (best-effort).
    try:
        from expops.core.runtime.step_system import get_state_manager as _get_sm
        sm = _get_sm()
    except Exception:
        sm = None

    if sm is not None and process_workspace_dir is None:
        try:
            _record_chart_artifacts(sm, str(project_id), str(rid), str(name), out_dir, chart_type="static")
        except Exception as upload_exc:
            logger.warning(f"[Charts] Artifact recording failed: {upload_exc}")
    elif sm is None:
        logger.warning("[Charts] No state manager available - artifacts not recorded")

    try:
        final_count = sum(1 for _ in out_dir.rglob("*") if _.is_file())
    except Exception:
        final_count = 0

    # Build __logs__ prefix so the main process can tell the chart output apart
    log_prefix = f"[Charts] '{name}' output (exit_code={returncode}):\n" if chart_stdout else ""
    return {
        'output_dir': str(out_dir),
        'artifact_count': final_count,
        'returncode': returncode,
        '__logs__': (log_prefix + chart_stdout) if chart_stdout else '',
    }


def _return_placeholder_cached_process_execution_result(process_name: str) -> ExecutionResult:
    return ExecutionResult(name=process_name, result=None, execution_time=0.0, was_cached=True, error=None)

def _return_placeholder_cached_process_execution_result_with_deps(process_name: str, dep_results: List[ExecutionResult]) -> ExecutionResult:
    for dep in dep_results or []:
        if dep and dep.error is not None:
            return ExecutionResult(name=process_name, result=None, execution_time=0.0, was_cached=False, error=f"Dependency {dep.name} failed: {dep.error}")
    return ExecutionResult(name=process_name, result=None, execution_time=0.0, was_cached=True, error=None)


def _worker_execute_step_task(step_name: str, process_name: Optional[str], context_arg: Any,
                              iteration: int = 0, run_id: Optional[str] = None) -> ExecutionResult:
    from expops.core.runtime.step_system import get_step_registry, set_current_context
    registry = get_step_registry()
    step_def = registry.get_step(step_name)
    if not step_def:
        try:
            if isinstance(context_arg, dict):
                global_params = context_arg.get('global_config') or {}
            else:
                global_params = getattr(context_arg, 'global_config', {}) or {}
            _maybe_import_custom_model_from_global_config(global_params)
            step_def = registry.get_step(step_name)
        except Exception:
            step_def = registry.get_step(step_name)
    if not step_def:
        raise ValueError(f"Step '{step_name}' not found in registry (worker). Ensure the model module defines and registers it.")

    try:
        from dask.distributed import get_worker  # type: ignore
        _worker = get_worker()
        _worker_addr = getattr(_worker, "address", "unknown")
    except Exception:
        _worker_addr = None
    try:
        import socket as _socket
        _host = _socket.gethostname()
    except Exception:
        _host = "unknown"
    logger.info(
        f"[Distributed] Executing step '{step_name}' (process {process_name}, iter {iteration}) "
        f"on worker={_worker_addr or 'n/a'} host={_host}"
    )

    start_time = time.time()

    from expops.core.runtime.step_system import StepContext as _Ctx
    if isinstance(context_arg, _Ctx):
        ctx = context_arg
    else:
        if isinstance(context_arg, dict):
            ctx = _build_step_context_from_payload(context_arg)
        else:
            try:
                ctx = _Ctx(project_id=getattr(context_arg, 'project_id', 'default'))
            except Exception:
                ctx = _Ctx(project_id='default')

    try:
        _gc = getattr(ctx, 'global_config', {}) if ctx else {}
        _pid = getattr(ctx, 'project_id', None)
        _maybe_init_worker_state_manager(_gc, _pid)
    except Exception as e:
        logger.warning(f"[Distributed] Worker state manager init failed for step {step_name}: {e}")

    set_current_context(ctx)
    # Deterministic task-level seeding (step scope) using structured seed value
    seed_override = None
    try:
        seed_override = getattr(ctx, "shared_state", {}).get("seed_value")
    except Exception:
        seed_override = None
    _seed_rng_for_task(run_id, process_name, step_name, iteration, seed_override=seed_override)
    try:
        from expops.core.runtime.step_system import get_current_state_manager as _get_sm
        _sm = _get_sm()
    except Exception:
        _sm = None
    try:
        _proc_name = process_name or getattr(ctx, 'current_process', None)
        if _sm and run_id and _proc_name and step_name:
            _sm.record_step_started(run_id, _proc_name, step_name)
    except Exception:
        pass
    try:
        # Execute step without auto-parameter resolution; context is available via current context
        # The step wrapper will inject context automatically if declared in the signature.
        result = step_def.func()
    finally:
        set_current_context(None)

    if not isinstance(result, dict):
        raise ValueError(f"Step '{step_name}' must return a dictionary, got {type(result).__name__}.")
    try:
        def _json_safe(v: Any) -> Any:
            import json as _json
            from collections.abc import Mapping, Sequence
            primitives = (str, int, float, bool, type(None))
            if isinstance(v, primitives):
                return v
            if isinstance(v, Mapping):
                return {str(k): _json_safe(val) for k, val in v.items()}
            if isinstance(v, Sequence) and not isinstance(v, (str, bytes, bytearray)):
                return [_json_safe(x) for x in v]
            try:
                _json.dumps(v)
                return v
            except Exception:
                return str(v)
        result = {k: _json_safe(v) for k, v in result.items()}
    except Exception:
        pass
    exec_time = time.time() - start_time
    if isinstance(result, dict):
        result['__execution_time__'] = exec_time
    ctx.step_results[step_name] = result
    return ExecutionResult(name=step_name, result=result, execution_time=exec_time, was_cached=False, error=None)


def _worker_execute_step_with_deps(step_name: str, process_name: Optional[str], context_payload: dict,
                                   dep_results: List[ExecutionResult], iteration: int = 0,
                                   run_id: Optional[str] = None) -> ExecutionResult:
    from expops.core.runtime.step_system import StepContext as _Ctx
    ctx = _build_step_context_from_payload(context_payload) if isinstance(context_payload, dict) else _Ctx(project_id='default')
    try:
        setattr(ctx, 'current_process', process_name)
    except Exception:
        pass
    for dep in dep_results:
        if dep.error is None and dep.result:
            ctx.step_results[dep.name] = dep.result
        else:
            raise RuntimeError(f"Dependency step {dep.name} failed: {dep.error}")
    return _worker_execute_step_task(step_name, process_name, ctx, iteration, run_id)


def _create_worker_state_manager(cache_config: Dict[str, Any]):
    from ..runtime.step_state_manager import StepStateManager
    from pathlib import Path
    import os
    import logging

    try:
        from expops.storage.factory import create_kv_store as _create_kv_store, create_object_store as _create_obj_store
    except Exception:
        _create_kv_store = None  # type: ignore[assignment]
        _create_obj_store = None  # type: ignore[assignment]

    kv_cfg = cache_config.get("kv_store_config", {}) if isinstance(cache_config, dict) else {}
    kv_store_type = str(cache_config.get("kv_store_type", "") or "")
    backend_type_explicit = str(cache_config.get("backend_type", "") or "").strip().lower() if isinstance(cache_config, dict) else ""
    backend_cfg_explicit = cache_config.get("backend_config", {}) if isinstance(cache_config, dict) else {}
    project_id = None
    try:
        project_id = kv_cfg.get("project_id")
    except Exception:
        project_id = None
    project_id = str(project_id or os.getenv("MLOPS_PROJECT_ID") or "default")

    backend_cfg: Dict[str, Any] = {}
    if isinstance(backend_cfg_explicit, dict) and backend_cfg_explicit:
        backend_cfg = dict(backend_cfg_explicit)
        if backend_type_explicit and not backend_cfg.get("type"):
            backend_cfg["type"] = backend_type_explicit
    elif backend_type_explicit == "gcp":
        backend_cfg = {
            "type": "gcp",
            "gcp_project": kv_cfg.get("gcp_project"),
            "topic_name": kv_cfg.get("topic_name"),
            "emulator_host": kv_cfg.get("emulator_host"),
        }
    elif backend_type_explicit == "redis":
        backend_cfg = {
            "type": "redis",
            "host": kv_cfg.get("host"),
            "port": kv_cfg.get("port"),
            "db": kv_cfg.get("db"),
            "password": kv_cfg.get("password"),
        }
    elif backend_type_explicit == "local":
        backend_cfg = {"type": "local"}
    elif "GCP" in kv_store_type or "Firestore" in kv_store_type:
        backend_cfg = {
            "type": "gcp",
            "gcp_project": kv_cfg.get("gcp_project"),
            "topic_name": kv_cfg.get("topic_name"),
            "emulator_host": kv_cfg.get("emulator_host"),
        }
    elif "Redis" in kv_store_type:
        backend_cfg = {
            "type": "redis",
            "host": kv_cfg.get("host"),
            "port": kv_cfg.get("port"),
            "db": kv_cfg.get("db"),
            "password": kv_cfg.get("password"),
        }
    else:
        backend_cfg = {"type": os.getenv("MLOPS_KV_BACKEND") or "local"}
        logging.getLogger(__name__).warning(
            "Worker cache backend metadata missing; defaulting backend_cfg=%s from env/type heuristics",
            backend_cfg,
        )

    kv_store = None
    if _create_kv_store:
        try:
            kv_store = _create_kv_store(project_id, backend_cfg, env=os.environ)
        except Exception:
            kv_store = None

    if kv_store is None:
        try:
            from expops.storage.adapters.memory_store import InMemoryStore  # type: ignore
            kv_store = InMemoryStore(project_id)
        except Exception:
            kv_store = None

    object_store = None
    if _create_obj_store:
        try:
            obj_cfg = cache_config.get("object_store_config", {}) if isinstance(cache_config, dict) else {}
            obj_type = str(cache_config.get("object_store_type", "") or "")
            cache_cfg: Dict[str, Any] = {}
            if "GCS" in obj_type:
                cache_cfg = {"object_store": {"type": "gcs", "bucket": obj_cfg.get("bucket")}}
            object_store = _create_obj_store(cache_cfg, env=os.environ, project_id=project_id) if cache_cfg else None
        except Exception:
            object_store = None

    if kv_store:
        env_cache = os.getenv('MLOPS_STEP_CACHE_DIR')
        if env_cache:
            cache_dir = Path(env_cache)
        else:
            try:
                ws_root = get_workspace_root()
                proj_root = get_projects_root(ws_root) / project_id
                runtime_root = get_project_runtime_root(proj_root, project_id)
                cache_dir = runtime_root / "cache" / "steps"
            except Exception:
                cache_dir = Path('/tmp/mlops-step-cache')
        version_hash = cache_config.get("cache_version_hash") if isinstance(cache_config, dict) else None
        proj_root_for_version = None
        try:
            proj_root_for_version = get_projects_root(get_workspace_root()) / project_id
        except Exception:
            pass
        return StepStateManager(
            cache_dir=cache_dir,
            kv_store=kv_store,
            logger=logging.getLogger(__name__),
            object_store=object_store,
            object_prefix=f"{project_id}/cache" if project_id else None,
            version_hash=version_hash,
            project_root=proj_root_for_version,
        )
    return None


def _worker_execute_process_task(proc_payload: Dict[str, Any], context_payload: Dict[str, Any],
                                run_id: Optional[str] = None) -> ExecutionResult:
    process_name = proc_payload.get('name')
    start_time = time.time()

    from expops.core.runtime.step_system import StepContext as _Ctx
    try:
        if isinstance(context_payload, _Ctx):
            ctx = context_payload
        else:
            ctx = _build_step_context_from_payload(context_payload) if isinstance(context_payload, dict) else _Ctx(project_id='default')
    except Exception:
        ctx = _Ctx(project_id='default')

    try:
        try:
            _gc2 = context_payload.get('global_config') if isinstance(context_payload, dict) else {}
            _pid2 = context_payload.get('project_id') if isinstance(context_payload, dict) else None
            _maybe_init_worker_state_manager(_gc2, _pid2)
        except Exception:
            pass

        # Deterministic task-level seeding (process scope)
        seed_override = None
        if isinstance(proc_payload, dict):
            seed_override = proc_payload.get("seed_value")
        _seed_rng_for_task(run_id, process_name, None, 0, seed_override=seed_override)

        # Process start is now recorded inside _execute_process_on_worker at the exact timing start

        return _execute_process_on_worker(ctx, proc_payload, run_id)
    except Exception as e:
        exec_time = time.time() - start_time
        error_result = {'__error_context__': str(e)}
        return ExecutionResult(name=process_name, result=error_result, execution_time=exec_time, was_cached=False, error=str(e))


def _worker_execute_process_with_deps(proc_payload: Dict[str, Any], context_payload: Dict[str, Any],
                                     dep_results: List[ExecutionResult], run_id: Optional[str] = None) -> ExecutionResult:
    from expops.core.runtime.step_system import StepContext as _Ctx
    ctx = _build_step_context_from_payload(context_payload) if isinstance(context_payload, dict) else _Ctx(project_id='default')
    try:
        setattr(ctx, 'current_process', proc_payload.get('name'))
    except Exception:
        pass
    # Ensure a worker state manager exists (with object store when available) and custom model is imported
    try:
        from expops.core.runtime.step_system import get_state_manager as _get_sm, set_state_manager as _set_sm
        sm_existing = _get_sm()
        # Prefer cache_config-provisioned state manager when missing or when object_store is absent
        try:
            cfg = proc_payload.get('cache_config') if isinstance(proc_payload, dict) else None
        except Exception:
            cfg = None
        needs_obj_store = False
        if sm_existing is None:
            needs_obj_store = True
        else:
            try:
                needs_obj_store = getattr(sm_existing, 'object_store', None) is None
            except Exception:
                needs_obj_store = True
        if cfg and needs_obj_store:
            try:
                sm_new = _create_worker_state_manager(cfg)
                if sm_new is not None:
                    _set_sm(sm_new)
            except Exception:
                pass
        # Import custom model on the worker so process/step registries are populated for hashing
        try:
            _maybe_import_builtin_component_runners(getattr(ctx, 'global_config', {}) or {})
        except Exception:
            pass
        try:
            _maybe_import_custom_model_from_global_config(getattr(ctx, 'global_config', {}) or {})
        except Exception:
            pass
    except Exception:
        pass
    for dep in dep_results:
        if dep.error is not None:
            return ExecutionResult(name=proc_payload.get('name'), result=None, execution_time=0.0, was_cached=False, error=f"Dependency {dep.name} failed: {dep.error}")
        if not getattr(dep, 'was_cached', False) and not dep.result:
            return ExecutionResult(name=proc_payload.get('name'), result=None, execution_time=0.0, was_cached=False, error=f"Dependency {dep.name} failed: {dep.error}")
        try:
            dep_payload = dep.result if isinstance(dep.result, dict) else None
            needs_cache_hydration = dep.result is None or _is_lightweight_result_payload(dep_payload)
            loaded: Any = None

            if needs_cache_hydration:
                # Hydrate dependency from cache/object-store when payload is omitted or lightweight.
                try:
                    from expops.core.runtime.step_system import get_state_manager as _get_sm
                    sm = _get_sm()
                except Exception:
                    sm = None

                cache_hint = None
                try:
                    if isinstance(dep_payload, dict):
                        cache_hint = dep_payload.get("cache_path")
                except Exception:
                    cache_hint = None

                if cache_hint is None:
                    try:
                        s = (context_payload.get('step_results') or {}).get(dep.name, {}) if isinstance(context_payload, dict) else {}
                        cache_hint = s.get('cache_path') if isinstance(s, dict) else None
                    except Exception:
                        cache_hint = None

                if sm is not None and cache_hint and hasattr(sm, 'load_process_result_from_path'):
                    try:
                        loaded = sm.load_process_result_from_path(cache_hint)
                    except Exception:
                        loaded = None

                if sm is not None and loaded is None:
                    try:
                        # Compute hashes for the dependency using the same worker helper
                        deps_for_dep = []
                        try:
                            dep_map = proc_payload.get('dependency_map') or {}
                            deps_for_dep = (dep_map or {}).get(dep.name, [])
                        except Exception:
                            deps_for_dep = []
                        ih, ch, fh = _compute_process_lookup_hashes_worker(
                            sm,
                            ctx,
                            dep.name,
                            deps_for_dep,
                            proc_payload.get('dependency_map') or {},
                        )
                        try:
                            from ..hashing.data_hashing import compute_data_aware_input_hash
                            data_ih = compute_data_aware_input_hash(sm, ih, getattr(ctx, "data_hash", None))
                        except Exception:
                            data_ih = ih
                    except Exception:
                        ih = ch = fh = None
                        data_ih = None
                    try:
                        if hasattr(sm, 'get_cached_process_result_with_metadata'):
                            data = sm.get_cached_process_result_with_metadata(dep.name, input_hash=data_ih, config_hash=ch, function_hash=fh)
                            if data is not None:
                                loaded, _, _ = data
                    except Exception:
                        loaded = None

                if isinstance(loaded, dict):
                    try:
                        ctx.step_results[dep.name] = _strip_internal_keys(loaded)
                    except Exception:
                        ctx.step_results[dep.name] = loaded
                elif _is_lightweight_result_payload(dep_payload):
                    hint = f" (cache_hint={cache_hint})" if cache_hint else ""
                    return ExecutionResult(
                        name=proc_payload.get('name'),
                        result=None,
                        execution_time=0.0,
                        was_cached=False,
                        error=f"Dependency {dep.name} returned lightweight payload but cache hydration failed{hint}.",
                    )
                elif dep.result is None:
                    hint = f" (cache_hint={cache_hint})" if cache_hint else ""
                    return ExecutionResult(
                        name=proc_payload.get('name'),
                        result=None,
                        execution_time=0.0,
                        was_cached=False,
                        error=f"Dependency {dep.name} returned no payload and cache hydration failed{hint}.",
                    )
            elif dep.result is not None:
                ctx.step_results[dep.name] = _strip_internal_keys(dep.result)
            inner = {}
            try:
                source_payload = loaded if isinstance(loaded, dict) else dep.result
                inner = source_payload.get('__step_results__', {}) if isinstance(source_payload, dict) else {}
            except Exception:
                inner = {}
            if isinstance(inner, dict):
                ctx.step_results.update(inner)
        except Exception:
            continue
    return _worker_execute_process_task(proc_payload, ctx, run_id)


def _maybe_init_worker_state_manager(global_config: Any, project_id: Optional[str]) -> None:
    try:
        from expops.core.runtime.step_system import get_state_manager as _get_sm, set_state_manager as _set_sm
        sm_existing = _get_sm()
        if sm_existing is not None:
            return
        import os as _os
        import logging as _logging
        logger = _logging.getLogger(__name__)
        gcp_creds = _os.getenv('GOOGLE_APPLICATION_CREDENTIALS')
        gcp_project = _os.getenv('GOOGLE_CLOUD_PROJECT')
        # Prefer top-level cache configuration
        cache_cfg = (global_config.get('cache') or {}) if isinstance(global_config, dict) else {}
        backend_cfg = cache_cfg.get('backend') if isinstance(cache_cfg, dict) else {}
        # Derive missing GCP env from backend config and project layout
        try:
            from pathlib import Path as _Path
            creds_rel = (backend_cfg or {}).get('credentials_json')
            if creds_rel and not _os.getenv('GOOGLE_APPLICATION_CREDENTIALS'):
                repo_root = get_workspace_root()
                pid_effective = project_id or _os.getenv('MLOPS_PROJECT_ID') or 'default'
                cred_path = (get_projects_root(repo_root) / str(pid_effective) / str(creds_rel)).resolve()
                if cred_path.exists():
                    _os.environ.setdefault('GOOGLE_APPLICATION_CREDENTIALS', str(cred_path))
            if (backend_cfg or {}).get('gcp_project') and not _os.getenv('GOOGLE_CLOUD_PROJECT'):
                _os.environ.setdefault('GOOGLE_CLOUD_PROJECT', str(backend_cfg.get('gcp_project')))
        except Exception:
            pass
        pid_effective = project_id or _os.getenv('MLOPS_PROJECT_ID') or 'default'
        ws_root = get_workspace_root()
        proj_root = get_projects_root(ws_root) / str(pid_effective)
        backend_type = (backend_cfg.get('type') if isinstance(backend_cfg, dict) else None) or _os.getenv('MLOPS_KV_BACKEND') or 'local'
        try:
            from expops.storage.factory import create_kv_store as _create_kv_store, create_object_store as _create_obj_store
            kv_store = _create_kv_store(
                str(pid_effective),
                backend_cfg if isinstance(backend_cfg, dict) else {},
                env=_os.environ,
                workspace_root=ws_root,
                project_root=proj_root,
            )
            obj_store = _create_obj_store(
                cache_cfg if isinstance(cache_cfg, dict) else {},
                env=_os.environ,
                project_id=str(pid_effective),
            )
            obj_prefix = f"{pid_effective}/cache"
        except Exception:
            from expops.storage.adapters.memory_store import InMemoryStore
            kv_store = InMemoryStore(str(pid_effective))
            obj_store = None
            obj_prefix = None
        from pathlib import Path as _Path
        _env_cache = _os.getenv('MLOPS_STEP_CACHE_DIR')
        if _env_cache:
            cache_dir = _Path(_env_cache)
        else:
            try:
                runtime_root = get_project_runtime_root(proj_root, str(pid_effective))
                cache_dir = runtime_root / "cache" / "steps"
            except Exception:
                cache_dir = proj_root / "cache" / "steps"
        from ..runtime.step_state_manager import StepStateManager as _SSM
        try:
            ttl_val = int(((cache_cfg or {}).get('ttl_hours') if isinstance(cache_cfg, dict) else 24) or 24)
        except Exception:
            ttl_val = 24
        version_hash = None
        if isinstance(global_config, dict):
            version_hash = global_config.get("cache_version_hash")
        sm_new = _SSM(
            cache_dir=cache_dir,
            kv_store=kv_store,
            logger=logging.getLogger(__name__),
            cache_ttl_hours=ttl_val,
            object_store=obj_store,
            object_prefix=obj_prefix,
            version_hash=version_hash,
            project_root=proj_root,
        )
        _set_sm(sm_new)
    except Exception:
        return


