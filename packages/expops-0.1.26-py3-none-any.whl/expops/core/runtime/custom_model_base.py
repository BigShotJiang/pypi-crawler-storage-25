from __future__ import annotations

from typing import Any, Optional


class MLOpsCustomModelBase:
    """Lightweight base class for user-defined models.

    This class is intentionally minimal: it stores parameters and (when not
    explicitly provided) tries to resolve process-scoped parameters from the
    active `StepContext`.
    """

    def __init__(self, parameters: Optional[dict[str, Any]] = None) -> None:
        """Initialize with parameters.

        If not provided, automatically resolve merged parameters from the
        active step context for the current process (global overrides -> process overrides).
        """
        if parameters and isinstance(parameters, dict):
            self.parameters = parameters
            return
        try:
            from .step_system import get_current_context
            ctx = get_current_context()
            if ctx and hasattr(ctx, 'get_parameters'):
                proc = getattr(ctx, 'current_process', None)
                resolved = ctx.get_parameters(proc)
                self.parameters = resolved if isinstance(resolved, dict) else {}
            else:
                self.parameters = {}
        except Exception:
            self.parameters = {}
    
    def get_step_registry(self) -> Any:
        """Get the step registry containing all @step decorated functions."""
        from .step_system import get_step_registry
        return get_step_registry()