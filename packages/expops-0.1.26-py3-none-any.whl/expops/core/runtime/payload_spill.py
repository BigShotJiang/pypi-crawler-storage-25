from __future__ import annotations

import io
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, Tuple, Optional

try:
    import numpy as np  # type: ignore
except Exception:  # pragma: no cover
    np = None  # type: ignore

if np is not None:

    class SpillArray(np.ndarray):  # type: ignore[misc]
        """ndarray subclass with list-like truthiness semantics."""

        def __new__(cls, input_array: "np.ndarray", origin_type: Optional[str] = None):
            obj = np.asarray(input_array).view(cls)
            obj._origin_type = origin_type  # type: ignore[attr-defined]
            return obj

        def __array_finalize__(self, obj):
            if obj is None:
                return
            self._origin_type = getattr(obj, "_origin_type", None)

        def __bool__(self) -> bool:  # pragma: no cover - trivial behaviour
            return bool(self.size)

else:  # pragma: no cover - numpy unavailable
    SpillArray = None  # type: ignore

PAYLOAD_REF_KEY = "__mlops_payload_ref__"
PAYLOAD_META_VERSION = 2
MODEL_REF_KEY = "__mlops_model_ref__"
MODEL_META_VERSION = 1
DEFAULT_SPILL_THRESHOLD_BYTES = 256_000
DEFAULT_DISTRIBUTED_SPILL_THRESHOLD_BYTES = 128_000


class PayloadHydrationError(RuntimeError):
    """Raised when a payload or model ref cannot be hydrated after retries."""

    def __init__(self, message: str, uri: Optional[str] = None, cause: Optional[Exception] = None) -> None:
        super().__init__(message)
        self.uri = uri
        self.cause = cause


def _get_logger() -> logging.Logger:
    return logging.getLogger(__name__)


def _coerce_array(value: Any) -> Optional["np.ndarray"]:
    """Best-effort conversion of supported payloads to a numpy array."""
    if np is None:
        return None
    if isinstance(value, np.ndarray):
        return value
    if hasattr(value, "to_numpy"):
        try:
            arr = value.to_numpy()
            return arr if isinstance(arr, np.ndarray) else None
        except Exception:
            return None
    if isinstance(value, (list, tuple)):
        try:
            arr = np.asarray(value)
            if arr.dtype == object:
                return None
            return arr
        except Exception:
            return None
    return None


def _estimate_bytes(value: Any) -> int:
    if np is not None and isinstance(value, np.ndarray):
        return int(value.nbytes)
    if isinstance(value, (bytes, bytearray)):
        return len(value)
    if isinstance(value, (list, tuple)):
        try:
            if all(isinstance(v, (int, float)) for v in value):
                return len(value) * 8
        except Exception:
            return 0
    return 0


def _parse_int_env(name: str) -> Optional[int]:
    raw = os.environ.get(name)
    if raw is None:
        return None
    try:
        parsed = int(str(raw).strip())
    except Exception:
        return None
    return parsed if parsed > 0 else None


def _hydrate_retries() -> int:
    explicit = _parse_int_env("MLOPS_HYDRATE_RETRIES")
    return explicit if explicit is not None else 3


def _hydrate_retry_delay_sec() -> float:
    raw = os.environ.get("MLOPS_HYDRATE_RETRY_DELAY_SEC")
    if raw is None:
        return 1.0
    try:
        parsed = float(str(raw).strip())
        return max(0.0, min(parsed, 60.0))
    except Exception:
        return 1.0


def _is_distributed_runtime() -> bool:
    # Workers typically have one of these set in distributed runs.
    return bool(os.environ.get("DASK_SCHEDULER_ADDRESS") or os.environ.get("DASK_WORKER_ID"))


def _resolve_spill_threshold_bytes(fallback: int) -> int:
    explicit = _parse_int_env("MLOPS_SPILL_THRESHOLD_BYTES")
    if explicit is not None:
        return explicit
    if _is_distributed_runtime():
        dist_explicit = _parse_int_env("MLOPS_SPILL_THRESHOLD_DISTRIBUTED_BYTES")
        if dist_explicit is not None:
            return dist_explicit
        return min(int(fallback), int(DEFAULT_DISTRIBUTED_SPILL_THRESHOLD_BYTES))
    return int(fallback)


def _log_no_spill(process_name: Optional[str], key_path: Tuple[str, ...], approx_bytes: int, reason: str) -> None:
    try:
        key = "/".join(key_path) if key_path else "payload"
        _get_logger().info(
            f"[PayloadSpill] Did not spill payload for {process_name}:{key} "
            f"({int(approx_bytes)} bytes, reason={reason})"
        )
    except Exception:
        pass


def _should_spill(value: Any, threshold_bytes: int) -> bool:
    arr = _coerce_array(value)
    if arr is None:
        return False
    approx = _estimate_bytes(arr)
    return approx >= threshold_bytes


def _model_spill_enabled() -> bool:
    raw = os.environ.get("MLOPS_SPILL_MODELS")
    if raw is None:
        return True
    return str(raw).strip().lower() not in {"0", "false", "no", "off"}


def _is_model(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, dict) and value.get(MODEL_REF_KEY):
        return False
    try:
        import xgboost  # type: ignore  # noqa: F401
        from xgboost.core import Booster  # type: ignore
        from xgboost.sklearn import XGBModel  # type: ignore
        if isinstance(value, (Booster, XGBModel)):
            return True
    except Exception:
        pass
    try:
        from sklearn.base import BaseEstimator  # type: ignore
        if isinstance(value, BaseEstimator):
            return True
    except Exception:
        pass
    try:
        mod = getattr(value.__class__, "__module__", "") or ""
        if mod.startswith("xgboost") or mod.startswith("sklearn"):
            return True
    except Exception:
        pass
    return False


def _serialize_model(model: Any) -> Tuple[bytes, Dict[str, Any]]:
    try:
        import joblib  # type: ignore
    except Exception as exc: 
        raise RuntimeError(f"joblib unavailable for model spill: {exc}") from exc
    buf = io.BytesIO()
    joblib.dump(model, buf)
    payload = buf.getvalue()
    meta = {
        "format": "joblib",
        "bytes": int(len(payload)),
        "class": getattr(model.__class__, "__name__", "unknown"),
        "module": getattr(model.__class__, "__module__", "unknown"),
    }
    return payload, meta


def _serialize_array(arr: "np.ndarray", origin_type: Optional[str] = None) -> Tuple[bytes, Dict[str, Any]]:
    buf = io.BytesIO()
    np.savez_compressed(buf, data=arr)
    meta = {
        "shape": list(arr.shape),
        "dtype": str(arr.dtype),
        "approx_bytes": int(arr.nbytes),
        "format": "npz",
        "origin_type": origin_type or "ndarray",
    }
    return buf.getvalue(), meta


def _wrap_spilled_array(arr: "np.ndarray", origin_type: Optional[str]) -> Any:
    if origin_type == "list":
        return arr.tolist()
    if origin_type == "tuple":
        return tuple(arr.tolist())
    if np is not None and isinstance(arr, np.ndarray) and SpillArray is not None:
        try:
            wrapped = arr.view(SpillArray)
            wrapped._origin_type = origin_type  # type: ignore[attr-defined]
            return wrapped
        except Exception:
            return arr
    return arr


def _build_payload_filename(state_manager: Any, run_id: Optional[str], process_name: Optional[str], key_path: Iterable[str]) -> str:
    """Build relative path under cache/<version>/<encodedProbe>/payloads/..."""
    path_tuple = tuple(key_path)
    if path_tuple:
        path_segment = "-".join(part or "part" for part in path_tuple)
    else:
        path_segment = "data"
    enc = state_manager._get_encoded_probe_path(process_name, None)
    rel = state_manager._get_probe_scoped_relative_path(
        enc, "payloads", run_id or "default", path_segment.replace(" ", "_"), str(uuid.uuid4())
    )
    return rel + ".npz"


def _build_model_filename(state_manager: Any, process_name: Optional[str], key_path: Iterable[str]) -> str:
    """Build relative path under cache/<version>/<encodedProbe>/model_spill/<model_name>.joblib.

    model_name is the key-path leaf (or 'model' if empty).
    """
    path_tuple = tuple(key_path)
    model_name = (path_tuple[-1] if path_tuple else "model").strip("/").replace(" ", "_") or "model"
    enc = state_manager._get_encoded_probe_path(process_name, None)
    rel = state_manager._get_probe_scoped_relative_path(enc, "model_spill", f"{model_name}.joblib")
    return rel


def _store_bytes(state_manager: Any, filename: str, payload: bytes) -> str:
    """Persist bytes via object store when configured, otherwise on the local cache path.

    filename is the full relative path under cache root (version/enc/kind/...).
    """
    if getattr(state_manager, "object_store", None):
        try:
            build_uri = getattr(state_manager, "_build_object_uri", None)
            if callable(build_uri):
                uri = build_uri(filename)
            else:
                uri = state_manager.object_store.build_uri(filename)  # type: ignore[call-arg]
            state_manager.object_store.put_bytes(uri, payload, content_type="application/octet-stream")  # type: ignore[attr-defined]
            return uri
        except Exception as e:
            _get_logger().warning(f"[PayloadSpill] Failed to put bytes to object store ({filename}): {e}")
    heavy_base = getattr(state_manager, "_cache_root", None)
    if heavy_base is None:
        cache_dir = Path(getattr(state_manager, "cache_dir", Path(".")))
        heavy_base = cache_dir
        try:
            if cache_dir.name == "steps" and cache_dir.parent.name == "cache":
                heavy_base = cache_dir.parent
        except Exception:
            pass
    local_path = Path(heavy_base) / filename
    local_path.parent.mkdir(parents=True, exist_ok=True)
    with open(local_path, "wb") as fout:
        fout.write(payload)
    return str(local_path.resolve())


def spill_large_payloads(
    result: Dict[str, Any],
    state_manager: Any,
    run_id: Optional[str],
    process_name: Optional[str],
    threshold_bytes: int = DEFAULT_SPILL_THRESHOLD_BYTES,
) -> Dict[str, Any]:
    """
    Normalize a process/step result dictionary into a lightweight *manifest*.

    Manifest invariants:
    - Large array-like payloads are stored as standalone binary blobs under ``payloads/``
      and represented in the manifest as small reference dictionaries containing
      ``PAYLOAD_REF_KEY`` (``__mlops_payload_ref__``) plus metadata and an object URI.
    - All recognized model objects (sklearn/xgboost and similar) are always serialized
      and stored under ``model_spill/`` and represented in the manifest via
      ``MODEL_REF_KEY`` (``__mlops_model_ref__``), regardless of their size, when
      model spilling is enabled.
    - Scalars, short strings and small config-like dictionaries remain inline so the
      manifest stays readable and cheap to deserialize.

    The returned dictionary is the value that will ultimately be cached (e.g. inside
    the ``.pkl`` artifacts managed by ``StepStateManager``); any heavy artifacts are
    retrieved lazily via :func:`hydrate_payload_refs`.
    """
    if not isinstance(result, dict) or state_manager is None or np is None:
        return result
    threshold_bytes = _resolve_spill_threshold_bytes(int(threshold_bytes))
    no_spill_log_floor = max(1_000_000, threshold_bytes)

    def _process(key: str, value: Any, path: Tuple[str, ...]) -> Any:
        if isinstance(value, dict):
            if value.get(PAYLOAD_REF_KEY) or value.get(MODEL_REF_KEY):
                return value
            return {k: _process(k, v, path + (k,)) for k, v in value.items()}
        approx_bytes = 0
        try:
            approx_bytes = _estimate_bytes(value)
        except Exception:
            approx_bytes = 0
        if _model_spill_enabled() and _is_model(value):
            # All recognized models are always spilled so that manifests only
            # contain lightweight references and all model bytes live under
            # the dedicated ``model_spill/`` prefix in the object store.
            return _spill_model_value(value, path)
        if isinstance(value, list):
            if _should_spill(value, threshold_bytes):
                return _spill_value(value, path)
            if approx_bytes >= no_spill_log_floor:
                _log_no_spill(process_name, path, approx_bytes, "non_numeric_or_below_threshold")
            try:
                return [_process(str(idx), item, path + (str(idx),)) for idx, item in enumerate(value)]
            except Exception:
                pass
        if isinstance(value, tuple):
            if _should_spill(value, threshold_bytes):
                return _spill_value(list(value), path)
            if approx_bytes >= no_spill_log_floor:
                _log_no_spill(process_name, path, approx_bytes, "non_numeric_or_below_threshold")
            return tuple(_process(str(idx), item, path + (str(idx),)) for idx, item in enumerate(value))
        if _should_spill(value, threshold_bytes):
            return _spill_value(value, path)
        if approx_bytes >= no_spill_log_floor:
            reason = "unsupported_type_for_array_spill" if _coerce_array(value) is None else "below_threshold"
            _log_no_spill(process_name, path, approx_bytes, reason)
        return value

    def _spill_value(payload_value: Any, key_path: Tuple[str, ...]) -> Dict[str, Any]:
        arr = _coerce_array(payload_value)
        if arr is None:
            return payload_value  # type: ignore[return-value]
        if isinstance(payload_value, list):
            origin_type = "list"
        elif isinstance(payload_value, tuple):
            origin_type = "tuple"
        elif np is not None and isinstance(payload_value, np.ndarray):
            origin_type = "ndarray"
        else:
            origin_type = type(payload_value).__name__
        data_bytes, meta = _serialize_array(arr, origin_type=origin_type)
        path_tuple = key_path or ("payload",)
        filename = _build_payload_filename(state_manager, run_id, process_name, path_tuple)
        uri = _store_bytes(state_manager, filename, data_bytes)
        ref = {
            PAYLOAD_REF_KEY: True,
            "uri": uri,
            "meta": meta,
            "version": PAYLOAD_META_VERSION,
            "key_path": "/".join(path_tuple),
            "process": process_name,
            "run_id": run_id,
        }
        try:
            _get_logger().info(f"[PayloadSpill] Spilled payload for {process_name}:{ref['key_path']} -> {uri} ({meta['approx_bytes']} bytes)")
        except Exception:
            pass
        return ref

    def _spill_model_value(model_value: Any, key_path: Tuple[str, ...]) -> Any:
        try:
            data_bytes, meta = _serialize_model(model_value)
        except Exception as e:
            _get_logger().warning(f"[ModelSpill] Failed to serialize model for {process_name}: {e}")
            return model_value
        path_tuple = key_path or ("model",)
        filename = _build_model_filename(state_manager, process_name, path_tuple)
        uri = _store_bytes(state_manager, filename, data_bytes)
        ref = {
            MODEL_REF_KEY: True,
            "uri": uri,
            "meta": meta,
            "version": MODEL_META_VERSION,
            "key_path": "/".join(path_tuple),
            "process": process_name,
            "run_id": run_id,
        }
        return ref

    new_result = {}
    for k, v in result.items():
        key = str(k)
        new_result[key] = _process(key, v, (key,))
    return new_result


def hydrate_payload_refs(data: Any, state_manager: Any) -> Any:
    """
    Hydrate a manifest produced by :func:`spill_large_payloads`.

    This function walks the nested structure of dictionaries/lists/tuples and
    replaces any payload/model reference dictionaries with the concrete numpy
    arrays or model instances loaded from the object store (or local cache
    fallback). Non-reference values are returned unchanged.
    """
    if state_manager is None or np is None:
        return data
    if isinstance(data, dict):
        if data.get(MODEL_REF_KEY):
            return _load_model(data, state_manager)
        if data.get(PAYLOAD_REF_KEY):
            return _load_payload(data, state_manager)
        return {k: hydrate_payload_refs(v, state_manager) for k, v in data.items()}
    if isinstance(data, list):
        return [hydrate_payload_refs(v, state_manager) for v in data]
    if isinstance(data, tuple):
        return tuple(hydrate_payload_refs(v, state_manager) for v in data)
    return data


def _load_payload(ref: Dict[str, Any], state_manager: Any) -> Any:
    uri = ref.get("uri")
    if not uri:
        return ref
    max_attempts = max(1, _hydrate_retries())
    delay = _hydrate_retry_delay_sec()
    last_error: Optional[Exception] = None
    for attempt in range(max_attempts):
        try:
            payload_bytes = None
            if str(uri).startswith("gs://") and getattr(state_manager, "object_store", None):
                payload_bytes = state_manager.object_store.get_bytes(uri)  # type: ignore[attr-defined]
            else:
                path = Path(uri)
                if not path.is_absolute():
                    base = getattr(state_manager, "_cache_root", None) or getattr(state_manager, "cache_dir", None)
                    if base is not None:
                        path = Path(base) / path
                with open(path, "rb") as fin:
                    payload_bytes = fin.read()
            if payload_bytes is None:
                raise RuntimeError("No payload bytes resolved")
            with np.load(io.BytesIO(payload_bytes), allow_pickle=False) as npz:
                arr = npz["data"]
            meta = ref.get("meta") if isinstance(ref.get("meta"), dict) else {}
            origin_type = meta.get("origin_type") if isinstance(meta, dict) else None
            return _wrap_spilled_array(arr, origin_type)
        except Exception as e:
            last_error = e
            _get_logger().warning(
                "[PayloadSpill] Failed to hydrate payload %s (attempt %s/%s): %s",
                uri,
                attempt + 1,
                max_attempts,
                e,
            )
            if attempt < max_attempts - 1 and delay > 0:
                time.sleep(delay)
    msg = f"Failed to hydrate payload after {max_attempts} attempt(s): {uri}"
    if last_error is not None:
        msg += f" — {last_error}"
    _get_logger().warning("[PayloadSpill] %s", msg)
    raise PayloadHydrationError(msg, uri=uri, cause=last_error)


def _load_model(ref: Dict[str, Any], state_manager: Any) -> Any:
    uri = ref.get("uri")
    if not uri:
        return ref
    try:
        import joblib  # type: ignore
    except Exception as exc:  # pragma: no cover - optional dependency
        raise RuntimeError(f"joblib unavailable for model hydrate: {exc}") from exc
    max_attempts = max(1, _hydrate_retries())
    delay = _hydrate_retry_delay_sec()
    last_error: Optional[Exception] = None
    for attempt in range(max_attempts):
        try:
            payload_bytes = None
            if str(uri).startswith("gs://") and getattr(state_manager, "object_store", None):
                payload_bytes = state_manager.object_store.get_bytes(uri)  # type: ignore[attr-defined]
                if payload_bytes is not None:
                    return joblib.load(io.BytesIO(payload_bytes))
            path = Path(uri)
            if not path.is_absolute():
                base = getattr(state_manager, "_cache_root", None) or getattr(state_manager, "cache_dir", None)
                if base is not None:
                    path = Path(base) / path
            return joblib.load(path)
        except Exception as e:
            last_error = e
            _get_logger().warning(
                "[ModelSpill] Failed to hydrate model %s (attempt %s/%s): %s",
                uri,
                attempt + 1,
                max_attempts,
                e,
            )
            if attempt < max_attempts - 1 and delay > 0:
                time.sleep(delay)
    msg = f"Failed to hydrate model after {max_attempts} attempt(s): {uri}"
    if last_error is not None:
        msg += f" — {last_error}"
    _get_logger().warning("[ModelSpill] %s", msg)
    raise PayloadHydrationError(msg, uri=uri, cause=last_error)


if __name__ == "__main__":  # pragma: no cover - developer self-test hook
    logging.basicConfig(level=logging.INFO)
    if np is None:
        print("NumPy is not available; skipping payload spill self-test.")
    else:
        from ..cache_probe.cache_layout import DEFAULT_VERSION_HASH
        from expops.storage.path_utils import encode_probe_path

        class _TempStateManager:
            def __init__(self) -> None:
                self.cache_dir = Path(os.environ.get("PAYLOAD_SPILL_TMP", "/tmp/payload_spill_test"))
                self.object_store = None
                self._cache_root = self.cache_dir.parent if self.cache_dir.name == "steps" else self.cache_dir
                self._version_hash = DEFAULT_VERSION_HASH

            def _get_encoded_probe_path(self, process_name: Optional[str], step_name: Optional[str] = None) -> str:
                xpath = f"//process[@name='{process_name or 'no_process'}']"
                if step_name:
                    xpath = f"{xpath}/step[@name='{step_name}']"
                return encode_probe_path(xpath)

            def _get_probe_scoped_relative_path(self, encoded_probe: str, kind: str, *segments: str) -> str:
                parts = [self._version_hash, encoded_probe, kind]
                parts.extend(s.strip("/").replace(" ", "_") for s in segments if s)
                return "/".join(parts)

        tmp = Path(os.environ.get("PAYLOAD_SPILL_TMP", "/tmp/payload_spill_test"))
        (tmp / "steps").mkdir(parents=True, exist_ok=True)
        sm = _TempStateManager()
        sm.cache_dir = tmp / "steps"
        sm._cache_root = tmp
        sample = {"X_test": np.random.rand(2000, 200)}  # ~3.2 MB -> forces spill
        spilled = spill_large_payloads(sample, sm, run_id="selftest", process_name="demo", threshold_bytes=1_000_000)
        print(spilled)


