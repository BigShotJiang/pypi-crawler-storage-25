from __future__ import annotations

"""Shared helpers for data/seed parallelism and process-name normalization.

These utilities centralize logic that was previously duplicated across
``networkx_parser``, ``process_hashing``, and ``executor_worker`` so that
parallelism semantics remain consistent throughout the core engine.
"""

from typing import Any, Optional, Dict, List


def _merge_list_of_dicts(value: Any) -> Any:
    """If value is a list of dicts, merge into a single dict; otherwise return as-is."""
    cfg = value
    if isinstance(cfg, list):
        merged: dict[str, Any] = {}
        for item in cfg:
            if isinstance(item, dict):
                merged.update(item)
        cfg = merged
    return cfg


def normalize_data_parallelism_to_dict(value: Any) -> dict[str, Any] | None:
    """Normalize arbitrary data_parallelism config into a simple dict.

    Returns a mapping with keys ``size`` and ``data_name`` when possible,
    or ``None`` when the input cannot be interpreted as a valid config.
    """
    if value is None:
        return None
    cfg = _merge_list_of_dicts(value)
    if not isinstance(cfg, dict):
        return None
    return {"size": cfg.get("size"), "data_name": cfg.get("data_name")}


def normalize_seed_parallelism_to_dict(value: Any) -> dict[str, Any] | None:
    """Normalize arbitrary seed_parallelism config into a simple dict.

    Returns a mapping with key ``seeds`` when possible, or ``None`` when
    the input cannot be interpreted as a valid config.
    """
    if value is None:
        return None
    cfg = _merge_list_of_dicts(value)
    # List of primitive seed values
    if isinstance(value, list) and (not cfg or not isinstance(cfg, dict)):
        try:
            return {"seeds": [int(x) for x in value]}
        except Exception:
            return None
    if isinstance(cfg, dict):
        seeds = cfg.get("seeds")
        if isinstance(seeds, (list, tuple)):
            try:
                return {"seeds": [int(x) for x in seeds]}
            except Exception:
                return None
        return {"seeds": seeds}
    return None


def normalize_data_parallelism_cfg(raw: Any) -> Dict[str, Any]:
    """Driver/worker-friendly normalization for data_parallelism configs.

    Mirrors the behavior previously implemented in ``executor_worker`` while
    delegating to :func:`normalize_data_parallelism_to_dict` for dict-like
    payloads and supporting dataclass-style objects with ``size`` attributes.
    """
    if raw is None:
        return {}
    # Dataclass / object with attributes
    if hasattr(raw, "size"):
        try:
            return {
                "size": getattr(raw, "size", None),
                "data_name": getattr(raw, "data_name", None),
            }
        except Exception:
            return {}
    cfg = normalize_data_parallelism_to_dict(raw)
    return cfg or {}


def normalize_seed_parallelism_cfg(raw: Any) -> Dict[str, Any]:
    """Driver/worker-friendly normalization for seed_parallelism configs.

    Mirrors the behavior previously implemented in ``executor_worker`` while
    delegating to :func:`normalize_seed_parallelism_to_dict`.
    """
    if raw is None:
        return {}
    if hasattr(raw, "seeds"):
        try:
            seeds = list(getattr(raw, "seeds", []) or [])
            return {"seeds": [int(x) for x in seeds]}
        except Exception:
            try:
                return {"seeds": list(getattr(raw, "seeds", []) or [])}
            except Exception:
                return {}
    cfg = normalize_seed_parallelism_to_dict(raw)
    if cfg is None:
        return {}
    seeds = cfg.get("seeds")
    if isinstance(seeds, (list, tuple)):
        try:
            return {"seeds": [int(x) for x in seeds]}
        except Exception:
            return {"seeds": list(seeds)}
    return {"seeds": seeds}


def base_process_name(name: str) -> str:
    """Strip partition/seed suffixes (``__pN`` and ``_seedK``) from a process name."""
    try:
        import re

        base = str(name)
        m_seed = re.match(r"^(.*)_seed-?\d+$", base)
        if m_seed and m_seed.group(1):
            base = m_seed.group(1)
        m_part = re.match(r"^(.*)__p\d+$", base)
        if m_part and m_part.group(1):
            return m_part.group(1)
        return base
    except Exception:
        return name


def base_name_from_xpath(xpath: str) -> str:
    """Extract base process name from a canonical XPath process identifier.

    If xpath looks like ``//.../process[@name='X']`` or ``//process[@name='X']``,
    returns X. Otherwise returns the input unchanged (e.g. legacy expanded name).
    """
    import re
    s = str(xpath).strip()
    if not s.startswith("//") or "process[@name=" not in s:
        return s
    # Match last process[@name='...'] segment (handles single or nested)
    m = re.search(r"process\[@name='([^']*)'\]", s)
    if m:
        return m.group(1)  # may be empty
    return s

