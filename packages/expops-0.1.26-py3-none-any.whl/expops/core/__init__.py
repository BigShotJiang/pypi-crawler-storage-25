"""
MLOps Core Module (lazy-loading)

Provides the core components for the NetworkX-based pipeline execution system.
Heavy submodules are imported lazily on attribute access to minimize required
runtime dependencies for lightweight utilities (e.g., pipeline_utils).
"""

from typing import Any
import importlib

__all__ = [
    # step_system exports
    "step",
    "process",
    "StepContext",
    "StepContextFactory",
    "StepDefinition",
    "StepRegistry",
    "ProcessDefinition",
    "ProcessRegistry",
    "get_step_registry",
    "get_process_registry",
    "get_current_context",
    "set_current_context",
    "get_context_factory",
    "set_current_process_context",
    "get_current_process_context",
    "get_parameter_resolver",
    "set_state_manager",
    "get_state_manager",
    "log_metric",
    "SerializableData",
    "ModelData",
    # custom model
    "MLOpsCustomModelBase",
    # graph types + parser
    "NetworkXGraphConfig",
    "ProcessConfig",
    "StepConfig",
    "ExecutionResult",
    "NodeType",
    "NetworkXPipelineParser",
    "parse_networkx_pipeline_from_config",
    # state manager
    "StepStateManager",
]

_lazy_attr_to_module = {
    # runtime / step_system
    "step": ("expops.core.runtime.step_system", "step"),
    "process": ("expops.core.runtime.step_system", "process"),
    "StepContext": ("expops.core.runtime.step_system", "StepContext"),
    "StepContextFactory": ("expops.core.runtime.step_system", "StepContextFactory"),
    "StepDefinition": ("expops.core.runtime.step_system", "StepDefinition"),
    "StepRegistry": ("expops.core.runtime.step_system", "StepRegistry"),
    "ProcessDefinition": ("expops.core.runtime.step_system", "ProcessDefinition"),
    "ProcessRegistry": ("expops.core.runtime.step_system", "ProcessRegistry"),
    "get_step_registry": ("expops.core.runtime.step_system", "get_step_registry"),
    "get_process_registry": ("expops.core.runtime.step_system", "get_process_registry"),
    "get_current_context": ("expops.core.runtime.step_system", "get_current_context"),
    "set_current_context": ("expops.core.runtime.step_system", "set_current_context"),
    "get_context_factory": ("expops.core.runtime.step_system", "get_context_factory"),
    "set_current_process_context": ("expops.core.runtime.step_system", "set_current_process_context"),
    "get_current_process_context": ("expops.core.runtime.step_system", "get_current_process_context"),
    "get_parameter_resolver": ("expops.core.runtime.step_system", "get_parameter_resolver"),
    "set_state_manager": ("expops.core.runtime.step_system", "set_state_manager"),
    "get_state_manager": ("expops.core.runtime.step_system", "get_state_manager"),
    "log_metric": ("expops.core.runtime.step_system", "log_metric"),
    "SerializableData": ("expops.core.runtime.step_system", "SerializableData"),
    "ModelData": ("expops.core.runtime.step_system", "ModelData"),
    # module-level shim for backwards-compat imports in tests: `from expops.core import step_system`
    "step_system": ("expops.core.runtime.step_system", None),
    # execution modules for backwards-compat imports in tests
    "executor_worker": ("expops.core.execution.executor_worker", None),
    "dask_networkx_executor": ("expops.core.execution.dask_networkx_executor", None),
    # custom model base
    "MLOpsCustomModelBase": ("expops.core.runtime.custom_model_base", "MLOpsCustomModelBase"),
    # graph types + parser
    "NetworkXGraphConfig": ("expops.core.graph.graph_types", "NetworkXGraphConfig"),
    "ProcessConfig": ("expops.core.graph.graph_types", "ProcessConfig"),
    "StepConfig": ("expops.core.graph.graph_types", "StepConfig"),
    "ExecutionResult": ("expops.core.graph.graph_types", "ExecutionResult"),
    "NodeType": ("expops.core.graph.graph_types", "NodeType"),
    "NetworkXPipelineParser": ("expops.core.graph.networkx_parser", "NetworkXPipelineParser"),
    "parse_networkx_pipeline_from_config": (
        "expops.core.graph.networkx_parser",
        "parse_networkx_pipeline_from_config",
    ),
    # state manager
    "StepStateManager": ("expops.core.runtime.step_state_manager", "StepStateManager"),
}


def __getattr__(name: str) -> Any:
    if name in _lazy_attr_to_module:
        module_name, attr_name = _lazy_attr_to_module[name]
        module = importlib.import_module(module_name)
        if attr_name is None:
            return module
        return getattr(module, attr_name)
    raise AttributeError(f"module 'expops.core' has no attribute '{name}'")


def __dir__() -> list[str]:
    return sorted(list(globals().keys()) + __all__) 