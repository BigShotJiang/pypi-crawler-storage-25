"""Probe path formatting and encoding for cache and artifacts layout.

Shared logic for canonical XPath-style probe paths used by StepStateManager,
cache layout, and artifact path construction.
"""

from __future__ import annotations

from typing import Any, List, Optional

from expops.storage.path_utils import encode_probe_path


def format_xpath_probe_path(
    process_name: Optional[str],
    step_name: Optional[str] = None,
) -> str:
    """Canonical XPath-style probe path used as the primary metric key.

    Matches the form produced by `resolve_tree_node_to_probe_path` in
    `pipeline_tree.py`, including partition/seed prefixes when present.
    """
    base_proc = str(process_name or "no_process").strip()

    # If the process name already looks like a canonical XPath produced by the
    # pipeline tree helpers, treat it as canonical and only append the step
    # selector when needed.
    if base_proc.startswith("//") and "process[@name=" in base_proc:
        if step_name:
            return f"{base_proc}/step[@name='{step_name}']"
        return base_proc

    # Non-XPath input: treat as a single base process name (no partition/seed parsing).
    xpath = "//" + f"process[@name='{base_proc}']"
    if step_name:
        xpath = f"{xpath}/step[@name='{step_name}']"
    return xpath


def get_encoded_probe_path(
    process_name: Optional[str],
    step_name: Optional[str] = None,
    probe_paths: Optional[Any] = None,
) -> str:
    """Return encoded canonical XPath probe path for cache/artifact namespacing.

    If probe_paths is provided and non-empty, uses the first path (assumed
    already in XPath form). Supports list or dict (uses first value for dict).
    Otherwise derives from process_name and step_name.
    """
    def _extract_path(value: Any) -> Optional[str]:
        if isinstance(value, str):
            raw = value.strip()
            return raw or None
        if isinstance(value, dict):
            raw = value.get("path")
            if isinstance(raw, str):
                raw = raw.strip()
                return raw or None
        return None

    if probe_paths:
        first: Any = None
        if isinstance(probe_paths, dict) and probe_paths:
            first = next(iter(probe_paths.values()), None)
        elif isinstance(probe_paths, (list, tuple)) and len(probe_paths) > 0:
            first = probe_paths[0]
        extracted = _extract_path(first)
        if extracted:
            return encode_probe_path(extracted)
    xpath = format_xpath_probe_path(process_name, step_name)
    return encode_probe_path(xpath)
