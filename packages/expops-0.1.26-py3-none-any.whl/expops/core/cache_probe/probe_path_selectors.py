from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Optional
import logging
import re
import fnmatch

from expops.core.graph.pipeline_tree import build_pipeline_tree, resolve_tree_node_to_probe_path, canonical_process_xpath_from_config, _extract_process_info
from expops.core.cache_probe.probe_path_values import coerce_probe_path_map_to_strings

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class DataSelector:
    split_glob: str
    partition_index: Optional[int] = None


@dataclass(frozen=True)
class SeedSelector:
    split_glob: str
    seed_value: Optional[int] = None


@dataclass(frozen=True)
class ParsedProbeSelector:
    base_glob: str
    data: list[DataSelector] = field(default_factory=list)
    seed: list[SeedSelector] = field(default_factory=list)
    step: Optional[str] = None


_SEGMENT_RE = re.compile(r"^(?P<split>[^\[]+)(?:\[(?P<value>[^\]]+)\])?$")


def _normalize_probe_paths_config(probe_paths_config: Any) -> dict[str, str]:
    return coerce_probe_path_map_to_strings(probe_paths_config)


def is_probe_path_xpath(path: str) -> bool:
    """True if path looks like an XPath selector (e.g. //*[@partition="p1"]/...)."""
    raw = str(path or "").strip()
    if not raw:
        return False
    if (raw.startswith("//") or raw.startswith("/")) and ("[" in raw or "@" in raw):
        return True
    return "@" in raw and ("[" in raw or raw.lstrip().startswith("//") or raw.lstrip().startswith("/"))

def _parse_data_segment(segment: str) -> DataSelector:
    payload = segment[len("data:"):]
    match = _SEGMENT_RE.match(payload.strip())
    if not match:
        raise ValueError(f"Invalid data selector segment: {segment}")
    split_glob = match.group("split").strip()
    if not split_glob:
        raise ValueError(f"Data selector missing split name: {segment}")
    raw_value = match.group("value")
    if raw_value is None or raw_value.strip() == "*" or raw_value.strip() == "":
        return DataSelector(split_glob=split_glob, partition_index=None)
    cleaned = raw_value.strip().lower()
    if cleaned.startswith("p"):
        cleaned = cleaned[1:]
    if not cleaned.isdigit():
        raise ValueError(f"Invalid data partition selector: {segment}")
    return DataSelector(split_glob=split_glob, partition_index=int(cleaned))


def _parse_seed_segment(segment: str) -> SeedSelector:
    payload = segment[len("seed:"):]
    match = _SEGMENT_RE.match(payload.strip())
    if not match:
        raise ValueError(f"Invalid seed selector segment: {segment}")
    split_glob = match.group("split").strip()
    if not split_glob:
        raise ValueError(f"Seed selector missing split name: {segment}")
    raw_value = match.group("value")
    if raw_value is None or raw_value.strip() == "*" or raw_value.strip() == "":
        return SeedSelector(split_glob=split_glob, seed_value=None)
    cleaned = raw_value.strip()
    if not cleaned.isdigit():
        raise ValueError(f"Invalid seed selector: {segment}")
    return SeedSelector(split_glob=split_glob, seed_value=int(cleaned))


def parse_probe_path_selector(path: str) -> ParsedProbeSelector:
    raw = str(path or "").strip()
    if not raw:
        raise ValueError("Probe path selector cannot be empty")
    segments = [seg for seg in raw.split("/") if seg]
    if not segments:
        raise ValueError("Probe path selector has no segments")
    base = segments[0].strip()
    if not base:
        raise ValueError("Probe path selector missing base process")

    data_sel: list[DataSelector] = []
    seed_sel: list[SeedSelector] = []
    step: Optional[str] = None

    for seg in segments[1:]:
        if seg.startswith("data:"):
            data_sel.append(_parse_data_segment(seg))
            continue
        if seg.startswith("seed:"):
            seed_sel.append(_parse_seed_segment(seg))
            continue
        if seg.startswith("step:"):
            if step is not None:
                raise ValueError("Multiple step selectors are not supported")
            step = seg[len("step:") :].strip()
            if not step:
                raise ValueError("Step selector cannot be empty")
            continue
        raise ValueError(f"Unrecognized selector segment: {seg}")

    return ParsedProbeSelector(base_glob=base, data=data_sel, seed=seed_sel, step=step)


def _matches_base(selector: ParsedProbeSelector, info: dict[str, Any]) -> bool:
    base_glob = selector.base_glob
    if fnmatch.fnmatchcase(info["base_name"], base_glob):
        return True
    return fnmatch.fnmatchcase(info["name"], base_glob)


def _matches_data(selector: ParsedProbeSelector, info: dict[str, Any]) -> bool:
    data_sels = selector.data or []
    if not data_sels:
        return True
    layers = info.get("data_layers") or []
    if not layers:
        return False
    if len(data_sels) == 1:
        return _matches_data_layer(data_sels[0], layers[-1])
    if len(layers) < len(data_sels):
        return False
    for sel, layer in zip(data_sels, layers):
        if not _matches_data_layer(sel, layer):
            return False
    return True


def _matches_seed(selector: ParsedProbeSelector, info: dict[str, Any]) -> bool:
    seed_sels = selector.seed or []
    if not seed_sels:
        return True
    layers = info.get("seed_layers") or []
    if not layers:
        return False
    if len(seed_sels) == 1:
        return _matches_seed_layer(seed_sels[0], layers[-1])
    if len(layers) < len(seed_sels):
        return False
    for sel, layer in zip(seed_sels, layers):
        if not _matches_seed_layer(sel, layer):
            return False
    return True


def _matches_data_layer(selector: DataSelector, layer: dict[str, Any]) -> bool:
    data_source = layer.get("source")
    if not data_source or not fnmatch.fnmatchcase(str(data_source), selector.split_glob):
        return False
    partition_index = layer.get("partition_index")
    if partition_index is None:
        return False
    if selector.partition_index is None:
        return True
    try:
        return int(partition_index) == int(selector.partition_index)
    except Exception:
        return False


def _matches_seed_layer(selector: SeedSelector, layer: dict[str, Any]) -> bool:
    seed_source = layer.get("source")
    if not seed_source or not fnmatch.fnmatchcase(str(seed_source), selector.split_glob):
        return False
    seed_value = layer.get("seed_value")
    if seed_value is None:
        return False
    if selector.seed_value is None:
        return True
    try:
        return int(seed_value) == int(selector.seed_value)
    except Exception:
        return False


def _sort_key(info: dict[str, Any]) -> tuple:
    base = info.get("base_name") or info.get("name") or ""
    part = info.get("partition_index")
    seed = info.get("seed_value")
    part_val = int(part) if isinstance(part, int) else -1
    seed_val = int(seed) if isinstance(seed, int) else -1
    return (str(base), part_val, seed_val, str(info.get("name") or ""))


def expand_probe_path_xpath(xpath: str, pipeline_tree: Any) -> list[str]:
    """Evaluate XPath against the pipeline tree and return concrete probe path strings."""
    if pipeline_tree is None:
        return []
    resolved: list[str] = []
    try:
        nodes = pipeline_tree.xpath(xpath)
    except Exception as e:
        logger.warning("XPath evaluation failed for '%s': %s", xpath, e)
        return []
    for node in nodes:
        if not hasattr(node, "tag"):
            continue
        path_str = resolve_tree_node_to_probe_path(node)
        if path_str and path_str not in resolved:
            resolved.append(path_str)
    return sorted(resolved)


def resolve_probe_paths_for_kv_lookup(
    probe_path: str, expanded_processes: Iterable[Any]
) -> list[str]:
    """Map an incoming metrics probe path to canonical XPath strings used at write time.

    Non-XPath keys are returned unchanged (single-element list). XPath selectors are
    evaluated against the expanded pipeline tree, same as :func:`expand_probe_paths`.
    """
    raw = str(probe_path or "").strip()
    if not raw:
        return []
    if not is_probe_path_xpath(raw):
        return [raw]
    tree = build_pipeline_tree(expanded_processes, probe_paths_values=[raw])
    return expand_probe_path_xpath(raw, tree)


def expand_probe_paths(probe_paths_config: Any, processes: Iterable[Any]) -> dict[str, str]:
    """Expand probe_paths config to concrete probe path -> path mapping. Uses XPath only."""
    mappings = _normalize_probe_paths_config(probe_paths_config)
    if not mappings:
        return {}
    out: dict[str, str] = {}
    path_values = list(mappings.values())
    any_xpath = any(is_probe_path_xpath(p) for p in path_values)
    pipeline_tree = None
    if any_xpath and processes:
        pipeline_tree = build_pipeline_tree(processes, probe_paths_values=path_values)

    for key, path in mappings.items():
        if pipeline_tree is None:
            logger.warning("No pipeline tree available for XPath '%s'", path)
            if key not in out:
                out[key] = str(path)
            continue
        try:
            expanded = expand_probe_path_xpath(path, pipeline_tree)
        except Exception as exc:
            logger.warning("Invalid probe path XPath '%s': %s", path, exc)
            if key not in out:
                out[key] = str(path)
            continue
        if not expanded:
            logger.warning(
                "XPath '%s' matched no nodes in the expanded pipeline tree. "
                "Verify probe_paths selectors against canonical process/step names "
                "(process[@name='...']/step[@name='...']).",
                path,
            )
            if key not in out:
                out[key] = str(path)
            continue
        # Preserve user key when XPath resolves to a single path so chart scripts get metrics[key].
        if len(expanded) == 1:
            if key not in out:
                out[key] = expanded[0]
        else:
            for resolved in expanded:
                if resolved not in out:
                    out[resolved] = resolved
    return out


def expand_probe_path_selector(selector: str, processes: Iterable[Any]) -> list[str]:
    """Expand a single selector string to canonical XPath probe paths.

    This is a convenience wrapper that accepts either:

    - A full XPath expression (delegated to :func:`expand_probe_path_xpath`), or
    - A structured selector string understood by :func:`parse_probe_path_selector`.
    """
    raw = str(selector or "").strip()
    if not raw:
        raise ValueError("Probe path selector cannot be empty")
    # Direct XPath: reuse the pipeline tree path.
    if is_probe_path_xpath(raw):
        tree = build_pipeline_tree(processes, probe_paths_values=[raw])
        return expand_probe_path_xpath(raw, tree)

    sel = parse_probe_path_selector(raw)
    infos = [_extract_process_info(p) for p in processes or []]
    matched: list[str] = []
    for info in sorted(infos, key=_sort_key):
        if not _matches_base(sel, info):
            continue
        if not _matches_data(sel, info):
            continue
        if not _matches_seed(sel, info):
            continue
        xpath = canonical_process_xpath_from_config(info["raw"])
        if not xpath:
            continue
        if sel.step:
            xpath = f"{xpath}/step[@name='{sel.step}']"
        if xpath not in matched:
            matched.append(xpath)
    return matched


__all__ = [
    "is_probe_path_xpath",
    "parse_probe_path_selector",
    "expand_probe_path_selector",
    "expand_probe_path_xpath",
    "expand_probe_paths",
    "resolve_probe_paths_for_kv_lookup",
]
