"""Cache layout helpers: version hash and probe-scoped path construction."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Optional

from expops.storage.path_utils import encode_probe_path


DEFAULT_VERSION_HASH = hashlib.sha256(b"mlops-cache-v1").hexdigest()


def compute_cache_version_hash(project_root: Path) -> str:
    """Compute deterministic cache version hash from project config + scripts.

    Formula: sha256(config_file_sha256 + script_tree_sha256)
    - config_file_sha256: sha256 of raw project_config.yaml bytes
    - script_tree_sha256: sha256 of leaf hashes concatenated, where each leaf is
      sha256(key_bytes + script_file_bytes), iterated in sorted key order

    Returns a hex digest. Uses DEFAULT_VERSION_HASH when config is missing.
    """
    config_path = project_root / "configs" / "project_config.yaml"
    if not config_path.exists() or not config_path.is_file():
        return DEFAULT_VERSION_HASH

    try:
        config_bytes = config_path.read_bytes()
    except Exception:
        return DEFAULT_VERSION_HASH

    config_sha = hashlib.sha256(config_bytes).hexdigest()

    try:
        import yaml
        cfg = yaml.safe_load(config_bytes) or {}
    except Exception:
        return hashlib.sha256(config_sha.encode()).hexdigest()

    scripts_section = cfg.get("scripts")
    if not isinstance(scripts_section, dict):
        return hashlib.sha256(config_sha.encode()).hexdigest()

    script_leaf_hashes: list[str] = []
    for key in sorted(scripts_section.keys()):
        rel_path = scripts_section.get(key)
        if not isinstance(rel_path, str):
            content = b""
        else:
            script_path = (project_root / rel_path).resolve()
            try:
                content = script_path.read_bytes() if script_path.exists() and script_path.is_file() else b""
            except Exception:
                content = b""
        leaf = hashlib.sha256(key.encode() + content).hexdigest()
        script_leaf_hashes.append(leaf)

    tree_hasher = hashlib.sha256()
    for leaf in script_leaf_hashes:
        tree_hasher.update(leaf.encode())
    script_sha = tree_hasher.hexdigest()
    combined = config_sha + script_sha
    return hashlib.sha256(combined.encode()).hexdigest()


def get_cache_root_from_steps_dir(cache_dir: Path) -> Path:
    """Resolve the cache root from a cache_dir that may point at .../cache/steps."""
    try:
        if cache_dir.name == "steps" and cache_dir.parent.name == "cache":
            return cache_dir.parent
    except Exception:
        pass
    return cache_dir


def build_probe_scoped_relative_path(
    encoded_probe_path: str,
    kind: str,
    *segments: str,
) -> str:
    """Build a relative path under cache/<version>/<encodedProbePath>/<kind>/<segments>.

    kind is one of: steps, payloads, model_spill
    """
    parts = [encoded_probe_path, kind]
    parts.extend(s.strip("/").replace(" ", "_") for s in segments if s)
    return "/".join(parts)


def build_artifact_relative_path(
    version_hash: str,
    encoded_probe_path: str,
    *segments: str,
) -> str:
    """Build a relative path under artifacts/<version_hash>/<encoded_probe_path>/<segments>.

    Used for both local filesystem and GCS object store layouts.
    Example: build_artifact_relative_path(vh, enc, "nn_losses.png") -> "vh/enc/nn_losses.png"
    """
    parts = [version_hash, encoded_probe_path]
    parts.extend(s.strip("/").replace(" ", "_") for s in segments if s)
    return "/".join(parts)
