from __future__ import annotations

from typing import Any


def _iter_probe_path_entries(probe_paths_config: Any) -> list[tuple[str, Any]]:
    entries: list[tuple[str, Any]] = []
    if isinstance(probe_paths_config, list):
        for item in probe_paths_config:
            if not isinstance(item, dict):
                continue
            for key, value in item.items():
                entries.append((str(key), value))
        return entries
    if isinstance(probe_paths_config, dict):
        for key, value in probe_paths_config.items():
            entries.append((str(key), value))
    return entries


def coerce_probe_path_map_to_strings(probe_paths_config: Any) -> dict[str, str]:
    """Return probe_paths as key -> path strings.

    Values may be direct string-like path selectors or objects with a `path` field.
    """
    out: dict[str, str] = {}
    for key, raw_value in _iter_probe_path_entries(probe_paths_config):
        if isinstance(raw_value, dict):
            path_value = raw_value.get("path")
        else:
            path_value = raw_value
        out[str(key)] = str(path_value)
    return out


def extract_probe_bar_per_key_metrics(probe_paths_config: Any) -> dict[str, str | None]:
    """Return optional per-key bar metrics declared alongside probe paths."""
    out: dict[str, str | None] = {}
    for key, raw_value in _iter_probe_path_entries(probe_paths_config):
        metric_value: Any = None
        if isinstance(raw_value, dict):
            metric_value = raw_value.get("metric")
        metric_name = str(metric_value).strip() if metric_value is not None else ""
        out[str(key)] = metric_name or None
    return out


__all__ = [
    "coerce_probe_path_map_to_strings",
    "extract_probe_bar_per_key_metrics",
]
