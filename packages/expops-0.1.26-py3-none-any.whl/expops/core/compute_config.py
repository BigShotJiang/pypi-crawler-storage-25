from __future__ import annotations

from pathlib import Path
from typing import Any, Dict


def resolve_compute_config_path(project_dir: Path, project_id: str) -> Path:
    return Path(project_dir) / project_id / "configs" / "compute_config.yaml"


def load_compute_config(path: Path) -> Dict[str, Any]:
    if not path.exists():
        return {}
    try:
        import yaml  # type: ignore
    except Exception:
        return {}
    try:
        with open(path, "r") as f:
            data = yaml.safe_load(f) or {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def map_compute_to_executor(compute_cfg: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(compute_cfg, dict):
        return {}
    executor_cfg: Dict[str, Any] = {}
    num_workers = compute_cfg.get("num_workers")
    if num_workers is not None:
        executor_cfg["n_workers"] = num_workers
    options = compute_cfg.get("options")
    if isinstance(options, dict):
        scheduler_address = options.get("scheduler_address")
        if scheduler_address is not None and str(scheduler_address).strip():
            executor_cfg["scheduler_address"] = scheduler_address
    return executor_cfg

