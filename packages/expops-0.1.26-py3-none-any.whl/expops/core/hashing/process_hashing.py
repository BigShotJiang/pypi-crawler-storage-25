from __future__ import annotations

from typing import Any, Optional

COMPONENT_PROCESS_RUNNERS_BY_PREFIX = {
    "sklearn.": "run_sklearn_component",
    "matplotlib.": "run_matplotlib_component",
}


def _resolve_component_process_runner(component_ref: str) -> str | None:
    for prefix, runner_name in COMPONENT_PROCESS_RUNNERS_BY_PREFIX.items():
        if component_ref.startswith(prefix):
            return runner_name
    return None

from expops.core.parallelism_utils import (
    normalize_data_parallelism_to_dict as _normalize_data_parallelism,
    normalize_seed_parallelism_to_dict as _normalize_seed_parallelism,
    base_process_name as _base_process_name,
    base_name_from_xpath as _base_name_from_xpath,
)

def _normalize_data_parallelism(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    cfg = value
    if isinstance(cfg, list):
        merged: dict[str, Any] = {}
        for item in cfg:
            if isinstance(item, dict):
                merged.update(item)
        cfg = merged
    if isinstance(cfg, dict):
        return {"size": cfg.get("size"), "data_name": cfg.get("data_name")}
    return None


def _normalize_seed_parallelism(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    cfg = value
    if isinstance(cfg, list):
        if cfg and all(isinstance(item, dict) for item in cfg):
            merged: dict[str, Any] = {}
            for item in cfg:
                if isinstance(item, dict):
                    merged.update(item)
            cfg = merged
        else:
            try:
                return {"seeds": [int(x) for x in cfg]}
            except Exception:
                return None
    if isinstance(cfg, dict):
        seeds = cfg.get("seeds")
        if isinstance(seeds, (list, tuple)):
            try:
                return {"seeds": [int(x) for x in seeds]}
            except Exception:
                return None
        return {"seeds": seeds}
    return None


def _base_process_name(name: str) -> str:
    try:
        import re
        base = str(name)
        m_seed = re.match(r"^(.*)_seed-?\d+$", base)
        if m_seed and m_seed.group(1):
            base = m_seed.group(1)
        m_part = re.match(r"^(.*)__p\d+$", base)
        if m_part and m_part.group(1):
            return m_part.group(1)
        return base
    except Exception:
        return name
        
def compute_process_hashes(
    state_manager: Any,
    context: Any,
    process_name: str,
    dependency_map: dict[str, list[str]],
    lookup_name: Optional[str] = None,
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Compute (input_hash, config_hash, function_hash) deterministically for a process.

    Determinism requirements:
    - Predecessors are traversed using a sorted order
    - Upstream signatures are dictionaries with stable key order (sorted by name)
    - Config hashing uses a filtered, ordered payload
    - Function hash is augmented with nested step AST and referenced step function hashes
    """
    try:
        from expops.core.runtime.step_system import get_process_registry, get_step_registry
    except Exception:
        get_process_registry = None  # type: ignore[assignment]
        get_step_registry = None  # type: ignore[assignment]

    # Build a stable mapping of configured process names -> code function names (registry keys)
    _lookup_map: dict[str, str] = {}
    try:
        global_cfg = getattr(context, "global_config", {}) or {}
        pipeline_cfg = (global_cfg.get("pipeline", {}) or {}) if isinstance(global_cfg, dict) else {}
        for p in (pipeline_cfg.get("processes", []) or []):
            if not isinstance(p, dict):
                continue
            name = p.get("name")
            component_ref = str(p.get("component", "")).strip() if isinstance(p.get("component"), str) else ""
            raw_code = p.get("code")
            code_str = str(raw_code).strip() if isinstance(raw_code, str) else ""
            if not name:
                continue
            if component_ref and not code_str:
                runner_name = _resolve_component_process_runner(component_ref)
                if runner_name:
                    _lookup_map[str(name)] = runner_name
                continue
            if not code_str:
                continue
            # Parse `code` into function name; ignore script key here.
            if "." in code_str:
                _, fn = code_str.rsplit(".", 1)
                fn = fn or None
            else:
                fn = code_str
            if fn:
                _lookup_map[str(name)] = str(fn)
    except Exception:
        _lookup_map = {}

    def _filtered_global_settings(gc: Any) -> dict[str, Any]:
        try:
            if not isinstance(gc, dict):
                return {}
            return {
                k: v
                for k, v in gc.items()
                if k not in ("pipeline", "project_config_file_hash", "cache_version_hash")
            }
        except Exception:
            return {}

    # 1) Build upstream_signatures recursively (ih/ch/fh) using dependency_map
    def _sorted_preds(name: str) -> list[str]:
        try:
            preds = list(dependency_map.get(name, []) or [])
            preds = sorted(set(preds))
            return preds
        except Exception:
            return []

    def _sig_for(up_proc: str) -> dict[str, Optional[str]]:
        ih_u, ch_u, fh_u = _compute_for(up_proc)
        return {"ih": ih_u, "ch": ch_u, "fh": fh_u}

    memo: dict[str, tuple[Optional[str], Optional[str], Optional[str]]] = {}

    def _compute_for(name: str) -> tuple[Optional[str], Optional[str], Optional[str]]:
        cached = memo.get(name)
        if cached is not None:
            return cached

        # Recursively compute signature for an upstream process
        try:
            upstream_signatures: dict[str, dict[str, Optional[str]]] = {}
            for p in _sorted_preds(name):
                try:
                    upstream_signatures[p] = _sig_for(p)
                except Exception:
                    continue
            input_surface = {
                "global_config_keys": sorted(list((getattr(context, "global_config", {}) or {}).keys())),
                "project_id": getattr(context, "project_id", None),
                "upstream_signatures": {k: upstream_signatures[k] for k in sorted(upstream_signatures.keys())},
            }
            ih = state_manager._compute_hash(input_surface) if state_manager else None
        except Exception:
            ih = None

        try:
            global_config = getattr(context, "global_config", {}) or {}
            # Load scripts section for script key resolution
            scripts_section: dict[str, str] | None = None
            default_script: str | None = None
            try:
                project_id = getattr(context, "project_id", None)
                if project_id:
                    from expops.core.workspace import get_workspace_root
                    workspace_root = get_workspace_root()
                    project_path = workspace_root / project_id
                    config_path = project_path / "configs" / "project_config.yaml"
                    if config_path.exists():
                        import yaml
                        with open(config_path, "r") as f:
                            full_config = yaml.safe_load(f) or {}
                        scripts_section = full_config.get("scripts")
                        if scripts_section and isinstance(scripts_section, dict):
                            default_script = next(iter(scripts_section)) if scripts_section else None
            except Exception:
                pass
            
            from expops.core.graph.pipeline_utils import resolve_script_path
            
            # Build process-scoped config hash: (global_without_pipeline, current process parameters, process name)
            process_params: dict[str, Any] = {}
            process_env: Optional[str] = None
            process_type: Optional[str] = None
            process_script_path: Optional[str] = None
            process_component: Optional[str] = None
            process_inputs: dict[str, str] = {}
            process_outputs: dict[str, str] = {}
            process_component_operation: Optional[str] = None
            process_data_parallelism: Optional[dict[str, Any]] = None
            process_data_aggregation: Optional[bool] = None
            process_seed_parallelism: Optional[dict[str, Any]] = None
            process_seed_aggregation: Optional[bool] = None
            try:
                pipeline_cfg = global_config.get("pipeline", {}) if isinstance(global_config, dict) else {}
                if name.startswith("//") and "process[@name=" in name:
                    match_name = _base_name_from_xpath(name)
                else:
                    match_name = _base_process_name(name)
                for proc_cfg in (pipeline_cfg.get("processes", []) or []):
                    if isinstance(proc_cfg, dict) and proc_cfg.get("name") == match_name:
                        maybe = proc_cfg.get("parameters", {}) or {}
                        process_params = dict(maybe) if isinstance(maybe, dict) else {}
                        hyper = proc_cfg.get("hyperparameters", {}) or {}
                        if isinstance(hyper, dict):
                            process_params = {**process_params, **dict(hyper)}
                        process_env = proc_cfg.get("environment")
                        process_type = proc_cfg.get("type")
                        process_component = (
                            str(proc_cfg.get("component", "")).strip()
                            if isinstance(proc_cfg.get("component"), str)
                            else None
                        )
                        # For component processes, hash the declarative input
                        # transform mapping (canonical input key -> upstream key).
                        # Non-component processes keep using `inputs` for any
                        # generic alias metadata.
                        raw_inputs = None
                        if process_component:
                            raw_inputs = proc_cfg.get("input_transform")
                        if not isinstance(raw_inputs, dict):
                            raw_inputs = proc_cfg.get("inputs")
                        if isinstance(raw_inputs, dict):
                            process_inputs = {
                                str(k): str(v)
                                for k, v in raw_inputs.items()
                                if k is not None and v is not None
                            }
                        # For component processes, hash output_mapping (canonical -> exposed).
                        raw_outputs = proc_cfg.get("output_mapping") if process_component else None
                        if isinstance(raw_outputs, dict):
                            process_outputs = {
                                str(k): str(v)
                                for k, v in raw_outputs.items()
                                if k is not None and v is not None
                            }
                        # Derive component operation from the component suffix when present,
                        # then fall back to an explicit parameters.operation value.
                        if isinstance(process_component, str):
                            for prefix in COMPONENT_PROCESS_RUNNERS_BY_PREFIX.keys():
                                if process_component.startswith(prefix):
                                    comp_body = process_component[len(prefix) :].strip()
                                    if "." in comp_body:
                                        _, op = comp_body.rsplit(".", 1)
                                        op = op.strip()
                                        if op:
                                            process_component_operation = op
                                    break
                        if process_component_operation is None:
                            op_val = process_params.get("operation")
                            if op_val is not None:
                                process_component_operation = str(op_val)
                        # Resolve script key to path from unified `code` field.
                        raw_code = proc_cfg.get("code")
                        code_str = str(raw_code).strip() if isinstance(raw_code, str) else ""
                        script_key = None
                        if code_str and "." in code_str:
                            script_key, _ = code_str.rsplit(".", 1)
                            script_key = script_key or None
                        process_script_path = resolve_script_path(script_key, scripts_section, default_script) if scripts_section else None
                        if process_component:
                            process_script_path = None
                        process_data_parallelism = _normalize_data_parallelism(proc_cfg.get("data_parallelism"))
                        process_seed_parallelism = _normalize_seed_parallelism(proc_cfg.get("seed_parallelism"))
                        process_data_aggregation = bool(proc_cfg.get("data_aggregation", False))
                        process_seed_aggregation = bool(proc_cfg.get("seed_aggregation", False))
                        break
            except Exception:
                process_params = {}
            # Exclude the pipeline graph and synthetic full-config hash to avoid global invalidations
            enhanced_config = {
                "global_config": _filtered_global_settings(global_config),
                "process_parameters": process_params,
                "process_environment": process_env,
                "process_type": process_type,
                "process_script_path": process_script_path,
                "process_component": process_component,
                "process_component_inputs": process_inputs,
                "process_component_outputs": process_outputs,
                "process_component_operation": process_component_operation,
                "process_data_parallelism": process_data_parallelism,
                "process_data_aggregation": process_data_aggregation,
                "process_seed_parallelism": process_seed_parallelism,
                "process_seed_aggregation": process_seed_aggregation,
                "process_name": name,
            }
            ch = state_manager._compute_hash(enhanced_config) if state_manager else None
        except Exception:
            try:
                # Last resort fallback: minimal global-only hash without pipeline
                minimal = _filtered_global_settings(getattr(context, "global_config", {}) or {})
                ch = state_manager._compute_hash(minimal) if state_manager else None
            except Exception:
                ch = None

        try:
            pr = get_process_registry() if callable(get_process_registry) else None
            # Graph nodes may be canonical XPaths (e.g. //process[@name='foo']) while
            # _lookup_map and the process registry use short YAML names (foo).
            # The lookup_name fallback only applies when name == outer process_name, so
            # recursive upstream resolution must also map XPath -> base name or
            # get_process() misses and fh stays None — downstream input_hash then never
            # tracks upstream code changes (stale process-level cache hits).
            _base_proc_name = (
                _base_name_from_xpath(name)
                if name.startswith("//") and "process[@name=" in name
                else name
            )
            _node_lookup = _lookup_map.get(name) or (
                _lookup_map.get(_base_proc_name) if _base_proc_name else None
            )
            if not _node_lookup and name == process_name:
                _node_lookup = lookup_name
            _registry_key = _node_lookup or _base_proc_name or name
            pdef = pr.get_process(_registry_key) if pr else None
            orig_fn = getattr(pdef, "original_func", None) if pdef else None
            fh = state_manager._compute_function_hash(orig_fn or getattr(pdef, "runner", None)) if (state_manager and pdef) else None

            try:
                sr = get_step_registry() if callable(get_step_registry) else None
                used_step_names = set()
                try:
                    import inspect as _inspect, ast as _ast
                    src = _inspect.getsource(orig_fn or getattr(pdef, "runner", None)) if pdef else ""
                    tree = _ast.parse(src) if src else None

                    class _CallVisitor(_ast.NodeVisitor):
                        def __init__(self):
                            self.names = set()
                        def visit_Call(self, node):
                            try:
                                if isinstance(node.func, _ast.Name):
                                    self.names.add(node.func.id)
                                elif isinstance(node.func, _ast.Attribute):
                                    self.names.add(node.func.attr)
                            except Exception:
                                pass
                            self.generic_visit(node)

                    class _NestedStepVisitor(_ast.NodeVisitor):
                        def __init__(self):
                            self.func_nodes = {}
                        def visit_FunctionDef(self, node):
                            try:
                                has_step = False
                                for deco in (node.decorator_list or []):
                                    if isinstance(deco, _ast.Name) and deco.id == "step":
                                        has_step = True
                                    elif isinstance(deco, _ast.Call) and isinstance(deco.func, _ast.Name) and deco.func.id == "step":
                                        has_step = True
                                if has_step and isinstance(node.name, str):
                                    self.func_nodes[node.name] = node
                            except Exception:
                                pass
                            self.generic_visit(node)

                    nv = None
                    if tree is not None:
                        cv = _CallVisitor()
                        cv.visit(tree)
                        used_step_names = set(cv.names or set())
                        nv = _NestedStepVisitor()
                        nv.visit(tree)
                except Exception:
                    used_step_names = set()
                    nv = None

                step_hashes: dict[str, str] = {}
                # 1) Nested steps (AST)
                try:
                    import ast as _ast
                    if nv and getattr(nv, "func_nodes", None):
                        for _nm in sorted(nv.func_nodes.keys()):
                            try:
                                _node = nv.func_nodes[_nm]
                                normalized = _ast.dump(_node, annotate_fields=True, include_attributes=False)
                                s_hash = state_manager._compute_hash({"ast": normalized}) if state_manager else None
                                if s_hash:
                                    step_hashes[_nm] = s_hash
                            except Exception:
                                continue
                except Exception:
                    pass
                for _nm in sorted(list(used_step_names)):
                    if _nm in step_hashes:
                        continue
                    try:
                        sdef = sr.get_step(_nm) if sr else None
                        if sdef is not None:
                            s_orig = getattr(sdef, "original_func", None) or getattr(sdef, "func", None)
                            s_hash = state_manager._compute_function_hash(s_orig) if (state_manager and s_orig) else None
                            if s_hash:
                                step_hashes[_nm] = s_hash
                    except Exception:
                        continue
                if step_hashes and fh:
                    # Stable combination by sorting keys
                    ordered = {k: step_hashes[k] for k in sorted(step_hashes.keys())}
                    fh = state_manager._compute_hash({"proc": fh, "steps": ordered})
            except Exception:
                pass
        except Exception:
            fh = None

        out = (ih, ch, fh)
        memo[name] = out
        return out

    return _compute_for(process_name)


