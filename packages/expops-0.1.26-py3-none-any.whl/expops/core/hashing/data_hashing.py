from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

from expops.core.workspace import resolve_relative_path


def _to_canonical(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, datetime):
        return {"__datetime__": True, "iso": value.isoformat()}
    if isinstance(value, (bytes, bytearray, memoryview)):
        bh = hashlib.sha256()
        bh.update(bytes(value))
        return {"__bytes__": True, "sha256": bh.hexdigest()}
    if isinstance(value, dict):
        return {str(k): _to_canonical(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (list, tuple)):
        return [_to_canonical(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted([_to_canonical(v) for v in value], key=lambda x: json.dumps(x, sort_keys=True, separators=(",", ":")))
    if hasattr(value, "tolist"):
        try:
            return _to_canonical(value.tolist())
        except Exception:
            pass
    return {"__repr__": True, "type": type(value).__name__, "value": repr(value)}


def _iter_rows(value: Any) -> Iterable[Any]:
    if value is None:
        return []
    if hasattr(value, "itertuples") and hasattr(value, "columns"):
        try:
            return value.itertuples(index=False, name=None)
        except Exception:
            pass
    if isinstance(value, dict):
        return [value]
    if isinstance(value, (str, bytes, bytearray, memoryview)):
        return [value]
    try:
        return iter(value)
    except Exception:
        return [value]


def compute_rows_hash(rows: Any) -> str:
    """Compute a stable hash for row-based data (lists, DataFrames, etc.)."""
    hasher = hashlib.sha256()
    for idx, row in enumerate(_iter_rows(rows)):
        payload = _to_canonical(row)
        serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        hasher.update(b"row:")
        hasher.update(str(idx).encode("utf-8"))
        hasher.update(b"|")
        hasher.update(serialized.encode("utf-8"))
        hasher.update(b"\n")
    return hasher.hexdigest()


def compute_partition_hashes(partitions: Any) -> list[str]:
    if not isinstance(partitions, list):
        return [compute_rows_hash(partitions)]
    return [compute_rows_hash(part) for part in partitions]


def compute_csv_row_hash(path: Path) -> str:
    """Compute a row-based hash for a CSV file."""
    hasher = hashlib.sha256()
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        for idx, row in enumerate(reader):
            payload = _to_canonical(row)
            serialized = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            hasher.update(b"row:")
            hasher.update(str(idx).encode("utf-8"))
            hasher.update(b"|")
            hasher.update(serialized.encode("utf-8"))
            hasher.update(b"\n")
    return hasher.hexdigest()


def resolve_data_hash_path(
    config: dict[str, Any],
    *,
    project_root: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
) -> Optional[Path]:
    if not isinstance(config, dict):
        return None
    data_cfg = config.get("data") or {}
    if not isinstance(data_cfg, dict):
        return None

    # New format: data.path
    raw_path = data_cfg.get("path")
    if not raw_path:
        # Legacy format: data.hash.path
        hash_cfg = data_cfg.get("hash") or {}
        if not isinstance(hash_cfg, dict):
            return None
        raw_path = hash_cfg.get("path")
    if not raw_path:
        return None
    try:
        return resolve_relative_path(str(raw_path), project_root=project_root, workspace_root=workspace_root)
    except Exception:
        return None


def compute_data_hash_from_config(
    config: dict[str, Any],
    *,
    project_root: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
) -> Optional[str]:
    path = resolve_data_hash_path(config, project_root=project_root, workspace_root=workspace_root)
    if not path:
        return None
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"Data path not found for hashing: {path}")
    return compute_csv_row_hash(path)


def matches_data_source(dep_name: str, source: Optional[str]) -> bool:
    if not source:
        return False
    dep = str(dep_name)
    if dep == source:
        return True
    return dep.startswith(f"{source}_seed") or dep.startswith(f"{source}__p")


def _data_layer_for_hash(parallel_context: Any) -> Optional[dict[str, Any]]:
    if not isinstance(parallel_context, dict):
        return None
    layers = parallel_context.get("data_layers")
    if not isinstance(layers, list) or not layers:
        return None
    for layer in reversed(layers):
        if isinstance(layer, dict) and layer.get("partition_index") is not None:
            return layer
    return None


def _extract_partition_hash(result: Any, partition_index: int, data_name: Optional[str]) -> Optional[str]:
    if not isinstance(result, dict):
        return None
    hashes = result.get("__data_partition_hashes__")
    if isinstance(hashes, list) and 0 < partition_index <= len(hashes):
        val = hashes[partition_index - 1]
        return str(val) if val is not None else None
    if data_name:
        value = result.get(data_name)
        if isinstance(value, list):
            try:
                computed = compute_partition_hashes(value)
                if 0 < partition_index <= len(computed):
                    return computed[partition_index - 1]
            except Exception:
                pass
    return None


def resolve_data_hash_for_process(
    dependencies: list[str],
    parallel_context: Any,
    *,
    get_result: Callable[[str], Any],
    fallback_hash: Optional[str] = None,
) -> tuple[Optional[str], bool]:
    """Return (data_hash, partition_expected) for a process."""
    layer = _data_layer_for_hash(parallel_context)
    if not layer:
        return fallback_hash, False
    try:
        partition_index = int(layer.get("partition_index"))
    except Exception:
        return None, True
    source = layer.get("source") or layer.get("parallel_source")
    data_name = layer.get("data_name")
    if source:
        for dep in dependencies or []:
            if matches_data_source(dep, str(source)):
                dep_result = get_result(dep)
                resolved = _extract_partition_hash(dep_result, partition_index, data_name)
                if resolved:
                    return resolved, True
    for dep in dependencies or []:
        dep_result = get_result(dep)
        if isinstance(dep_result, dict) and dep_result.get("__data_hash__"):
            return str(dep_result.get("__data_hash__")), True
    return None, True


def compute_data_aware_input_hash(
    state_manager: Any,
    base_input_hash: Optional[str],
    data_hash: Optional[str],
) -> Optional[str]:
    if not base_input_hash:
        return None
    if not data_hash:
        return base_input_hash
    payload = {"input_hash": base_input_hash, "data_hash": data_hash}
    try:
        if state_manager:
            return state_manager._compute_hash(payload)
    except Exception:
        pass
    serialized = json.dumps(_to_canonical(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(serialized).hexdigest()
