from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

ENV_WORKSPACE_DIR = "MLOPS_WORKSPACE_DIR"
ENV_PROJECT_ID = "MLOPS_PROJECT_ID"


def get_workspace_root() -> Path:
    """Return the workspace root directory.

    The workspace is where project folders live directly. Resolution order:
    1) `MLOPS_WORKSPACE_DIR`
    2) current working directory
    """
    raw = os.environ.get(ENV_WORKSPACE_DIR)
    if raw:
        try:
            return Path(raw).expanduser().resolve()
        except Exception:
            return Path(raw)
    return Path.cwd()


def get_projects_root(workspace_root: Optional[Path] = None) -> Path:
    """Return the root directory where projects live (workspace root)."""
    return workspace_root or get_workspace_root()


def get_project_runtime_root(project_path: Path, project_id: Optional[str] = None) -> Path:
    """Return the hidden per-project runtime directory.

    Layout convention:
      - project_path: <workspace_root>/<project_id>
      - runtime root: <workspace_root>/<project_id>/.<project_id>
    """
    try:
        pid = (project_id or project_path.name) or ""
    except Exception:
        pid = project_id or ""
    return project_path / f".{pid}" if pid else project_path / ".runtime"


def resolve_relative_path(
    p: str | Path,
    *,
    project_root: Optional[Path] = None,
    workspace_root: Optional[Path] = None,
) -> Path:
    """Resolve a user-provided path against likely bases.

    - Absolute paths are returned as-is.
    - Relative paths are tried against:
      1) current working directory
      2) `project_root` (if provided)
      3) `workspace_root` / `MLOPS_WORKSPACE_DIR` (if provided/available)

    Returns a Path even if it does not exist (best-effort).
    """
    path = Path(p)
    if path.is_absolute():
        return path

    # 1) As given relative to CWD
    try:
        if path.exists():
            return path
    except Exception:
        pass

    # 2) Relative to project root
    if project_root is not None:
        try:
            cand = (project_root / path)
            if cand.exists():
                return cand
        except Exception:
            pass

    # 3) Relative to workspace root
    wr = workspace_root or get_workspace_root()
    try:
        cand = (wr / path)
        if cand.exists():
            return cand
    except Exception:
        pass

    # Fall back to the most likely base for debugging
    if project_root is not None:
        return project_root / path
    return (wr / path)


def infer_source_root() -> Optional[Path]:
    """Best-effort: detect a source checkout root (repo root) when running from source.

    This is used only for backwards-compatible PYTHONPATH/editable-install fallbacks.
    """
    try:
        # workspace.py lives at <root>/src/expops/core/workspace.py in source checkouts
        expops_pkg_dir = Path(__file__).resolve().parents[1]  # .../expops
        src_dir = expops_pkg_dir.parent  # .../src (source) or .../site-packages (installed)
        root = src_dir.parent
        if (root / "pyproject.toml").exists() or (root / "setup.py").exists():
            # Heuristic: source checkout root should contain packaging metadata.
            return root
    except Exception:
        pass
    return None


