from __future__ import annotations

from typing import Any, Dict
import logging

from .graph_types import (
    NetworkXGraphConfig,
    ProcessConfig,
    StepConfig,
    DataParallelismConfig,
    SeedParallelismConfig,
    MetricConfig,
)
from expops.core.runtime.step_system import get_step_registry
from expops.core.parallelism_utils import (
    normalize_data_parallelism_to_dict,
    normalize_seed_parallelism_to_dict,
)

logger = logging.getLogger(__name__)
SKLEARN_COMPONENT_PROCESS_RUNNER = "run_sklearn_component"
MATPLOTLIB_COMPONENT_PROCESS_RUNNER = "run_matplotlib_component"
COMPONENT_PROCESS_RUNNERS_BY_PREFIX = {
    "sklearn.": SKLEARN_COMPONENT_PROCESS_RUNNER,
    "matplotlib.": MATPLOTLIB_COMPONENT_PROCESS_RUNNER,
}


def _resolve_component_process_runner(component_ref: str) -> str | None:
    for prefix, runner_name in COMPONENT_PROCESS_RUNNERS_BY_PREFIX.items():
        if component_ref.startswith(prefix):
            return runner_name
    return None


def _normalize_data_parallelism(value: Any) -> DataParallelismConfig | None:
    """Normalize to DataParallelismConfig using shared dict-based semantics."""
    cfg = normalize_data_parallelism_to_dict(value)
    if cfg is None:
        return None
    size = cfg.get("size")
    if size is None:
        return None
    return DataParallelismConfig(size=size, data_name=cfg.get("data_name"))


def _normalize_seed_parallelism(value: Any) -> SeedParallelismConfig | None:
    """Normalize to SeedParallelismConfig using shared dict-based semantics."""
    cfg = normalize_seed_parallelism_to_dict(value)
    if cfg is None:
        return None
    seeds = cfg.get("seeds")
    if seeds is None or not isinstance(seeds, (list, tuple)):
        return None
    try:
        return SeedParallelismConfig(seeds=[int(x) for x in seeds])
    except Exception:
        return None


def _normalize_alias_map(value: Any) -> dict[str, str] | None:
    if value is None:
        return None
    if not isinstance(value, dict):
        return None
    normalized: dict[str, str] = {}
    for key, target in value.items():
        if key is None or target is None:
            continue
        normalized[str(key)] = str(target)
    return normalized


def _normalize_metric_configs(value: Any) -> list[MetricConfig] | None:
    if value is None:
        return None
    if not isinstance(value, list):
        raise ValueError("Process 'metrics' must be a list of metric definitions.")

    normalized: list[MetricConfig] = []
    for metric in value:
        if not isinstance(metric, dict):
            raise ValueError("Each metric definition must be a dictionary.")
        raw_name = metric.get("name")
        name = str(raw_name).strip() if raw_name is not None else ""
        if not name:
            raise ValueError("Each metric definition must include a non-empty 'name'.")

        raw_from_result = metric.get("from_result")
        from_result = str(raw_from_result).strip() if raw_from_result is not None else None
        if from_result == "":
            from_result = None

        raw_fn = metric.get("fn")
        fn = str(raw_fn).strip() if raw_fn is not None else None
        if fn == "":
            fn = None

        inputs = _normalize_alias_map(metric.get("inputs")) or {}
        if fn is None and from_result is None:
            from_result = name

        normalized.append(
            MetricConfig(
                name=name,
                from_result=from_result,
                fn=fn,
                inputs=inputs,
            )
        )
    return normalized


class NetworkXPipelineParser:
    """Parser for NetworkX-based pipeline configurations with loop support."""
    
    def __init__(self, scripts_section: Dict[str, str] | None = None) -> None:
        self.processes: Dict[str, ProcessConfig] = {}
        self.steps: Dict[str, StepConfig] = {}
        self.scripts_section = scripts_section
        self.default_script = next(iter(scripts_section)) if scripts_section else None
        
    def parse_pipeline_config(self, pipeline_config: Dict[str, Any]) -> NetworkXGraphConfig:
        """Parse pipeline config and return NetworkX graph configuration."""
        self.processes = {}
        self.steps = {}
        
        if "processes" in pipeline_config:
            self._parse_networkx_format(pipeline_config)

        config = self._generate_networkx_config(pipeline_config)
        
        return config
        
    def _parse_networkx_format(self, pipeline_config: Dict[str, Any]) -> None:
        """Parse NetworkX configuration format with DAG flow support."""
        
        if "process_adjlist" in pipeline_config:
            self._parse_process_adjlist(pipeline_config["process_adjlist"])
        
        # Import resolve_script_path helper
        from .pipeline_utils import resolve_script_path

        for process_data in pipeline_config.get("processes", []):
            process_name = process_data["name"]
            proc_type = process_data.get("type", "process")
            probe_paths = process_data.get("probe_paths")
            chart_type = process_data.get("chart_type")
            proc_env = process_data.get("environment")
            component_ref = str(process_data.get("component", "")).strip() if isinstance(process_data.get("component"), str) else ""

            # For sklearn-style components, use `input_transform` for input aliasing and
            # reject legacy component-level `inputs` / `outputs` keys. Non-component
            # processes keep using `inputs` / `outputs` as before.
            has_component = bool(component_ref)
            if has_component:
                legacy_keys = [k for k in ("inputs", "outputs") if k in process_data]
                if legacy_keys:
                    joined = ", ".join(sorted(legacy_keys))
                    raise ValueError(
                        f"Process '{process_name}' declares 'component' but also uses legacy key(s) "
                        f"{joined}. Use 'input_transform' for input aliasing and 'output_mapping' for "
                        "output aliasing."
                    )
                input_aliases = _normalize_alias_map(process_data.get("input_transform"))
                output_aliases = _normalize_alias_map(process_data.get("output_mapping"))
            else:
                input_aliases = _normalize_alias_map(process_data.get("inputs"))
                output_aliases = _normalize_alias_map(process_data.get("outputs"))
            metric_configs = _normalize_metric_configs(process_data.get("metrics"))
            data_parallelism = _normalize_data_parallelism(process_data.get("data_parallelism"))
            seed_parallelism = _normalize_seed_parallelism(process_data.get("seed_parallelism"))
            data_aggregation = bool(process_data.get("data_aggregation", False))
            seed_aggregation = bool(process_data.get("seed_aggregation", False))

            # Derive code_function and script_path from the unified `code` field.
            # - code: "script_key.func_name" -> script_key + func_name
            # - code: "func_name" -> default script_key, function = func_name
            # - no code:
            #   - default split/aggregation nodes (data/seed parallelism without explicit code) remain function-less
            #   - all other processes default to function == process name on the default script
            raw_code = process_data.get("code")
            code_str = str(raw_code).strip() if isinstance(raw_code, str) else ""
            has_explicit_code = bool(code_str)
            has_data_parallelism = data_parallelism is not None
            has_seed_parallelism = seed_parallelism is not None
            is_default_split = (not has_explicit_code) and (has_data_parallelism or has_seed_parallelism)

            if has_explicit_code and has_component:
                raise ValueError(
                    f"Process '{process_name}' cannot declare both 'code' and 'component'. "
                    "Choose exactly one implementation source."
                )
            if has_component and str(proc_type).lower() == "chart":
                raise ValueError(
                    f"Process '{process_name}' cannot declare 'component' with chart type."
                )

            script_key = None
            code_function = None
            if has_component:
                code_function = _resolve_component_process_runner(component_ref)
                if not code_function:
                    supported = ", ".join(sorted(COMPONENT_PROCESS_RUNNERS_BY_PREFIX.keys()))
                    raise ValueError(
                        f"Process '{process_name}' declares unsupported component '{component_ref}'. "
                        f"Supported component prefixes: {supported}."
                    )
            elif has_explicit_code:
                if "." in code_str:
                    script_key, code_function = code_str.rsplit(".", 1)
                    script_key = script_key or None
                    code_function = code_function or None
                else:
                    code_function = code_str
            else:
                if not is_default_split:
                    code_function = process_name

            # Resolve script key to path (may be None for split nodes or when scripts are not configured)
            script_path = (
                None
                if has_component
                else (resolve_script_path(script_key, self.scripts_section, self.default_script) if self.scripts_section else None)
            )

            if probe_paths is not None:
                # Matplotlib component processes use probe_paths for in-process KV lookups in the
                # expops-matplotlib runner; they must remain `process` type (not chart subprocess).
                matplotlib_probe_component = (
                    has_component
                    and isinstance(component_ref, str)
                    and component_ref.startswith("matplotlib.")
                )
                if not matplotlib_probe_component:
                    proc_type = "chart"
            if str(proc_type).lower() == "chart" and not chart_type:
                chart_type = "static"
            
            if process_name in self.processes:
                process_config = self.processes[process_name]
                process_config.parallel = process_data.get("parallel", process_config.parallel)
                if data_parallelism is not None:
                    process_config.data_parallelism = data_parallelism
                if seed_parallelism is not None:
                    process_config.seed_parallelism = seed_parallelism
                if "data_aggregation" in process_data:
                    process_config.data_aggregation = data_aggregation
                if "seed_aggregation" in process_data:
                    process_config.seed_aggregation = seed_aggregation
                # Update derived code_function and script_path
                process_config.code_function = code_function
                process_config.script_path = script_path
                process_config.component = component_ref or None
                process_config.inputs = input_aliases or {}
                process_config.outputs = output_aliases or {}
                process_config.metrics = metric_configs or []
                # Update process_type if provided (important for chart processes)
                if proc_type:
                    process_config.process_type = str(proc_type)
                if probe_paths is not None:
                    process_config.probe_paths = probe_paths
                if chart_type:
                    process_config.chart_type = str(chart_type)
                if proc_env:
                    process_config.environment = str(proc_env)
            else:
                process_config = ProcessConfig(
                    name=process_name,
                    parallel=process_data.get("parallel", True),
                    data_parallelism=data_parallelism,
                    seed_parallelism=seed_parallelism,
                    data_aggregation=data_aggregation,
                    seed_aggregation=seed_aggregation,
                    code_function=code_function,
                    script_path=script_path,
                    component=component_ref or None,
                    inputs=input_aliases or {},
                    outputs=output_aliases or {},
                    metrics=metric_configs or [],
                    process_type=str(proc_type),
                    probe_paths=probe_paths,
                    chart_type=str(chart_type) if chart_type else "static",
                    environment=str(proc_env) if proc_env else None,
                )

                self.processes[process_name] = process_config
            
        # Manual-step mode: steps are executed inside process runners, not scheduled as nodes.
    
    def _parse_process_adjlist(self, adjlist_value: Any) -> None:
        """Parse process-level DAG from adjacency list string or list of lines.
        
        Adjacency list lines follow NetworkX semantics: first token is the source node,
        subsequent tokens are target nodes. Lines may include comments after a '#'.
        """
        if isinstance(adjlist_value, str):
            lines = adjlist_value.splitlines()
        elif isinstance(adjlist_value, list):
            lines = [str(x) for x in adjlist_value]
        else:
            raise ValueError("process_adjlist must be a string or list of lines")
        
        for raw_line in lines:
            line = raw_line.strip()
            if not line:
                continue
            # Remove comments after '#'
            if "#" in line:
                line = line.split("#", 1)[0].strip()
            if not line:
                continue
            parts = line.split()
            if not parts:
                continue
            source = parts[0]
            targets = parts[1:]
            
            # Ensure source process exists
            if source not in self.processes:
                self.processes[source] = ProcessConfig(name=source, depends_on=[])
            
            # Add or update targets with dependency on source
            for target in targets:
                if target not in self.processes:
                    self.processes[target] = ProcessConfig(name=target, depends_on=[source])
                else:
                    deps = self.processes[target].depends_on or []
                    if source not in deps:
                        self.processes[target].depends_on = deps + [source]
    
    def _discover_steps_from_registry(self) -> None:
        """Manual-step mode: keep for compatibility; intentionally a no-op."""
        try:
            step_registry = get_step_registry()
            registered_steps = step_registry.list_steps() if step_registry else []
            logger.debug(f"Manual-step mode enabled; ignoring {len(registered_steps)} registered steps during parsing")
        except Exception:
            logger.debug("Manual-step mode enabled; no step registry available")
    
    def _generate_networkx_config(self, pipeline_config: Dict[str, Any]) -> NetworkXGraphConfig:
        """Generate NetworkX configuration from parsed processes and steps."""
        
        execution_config = pipeline_config.get("execution", {})
        execution = {
            "parallel": execution_config.get("parallel", True),
            "max_workers": execution_config.get("max_workers", 4)
        }
        
        return NetworkXGraphConfig(
            processes=list(self.processes.values()),
            steps=list(self.steps.values()),
            execution=execution
        )


def parse_networkx_pipeline_from_config(pipeline_config: Dict[str, Any], scripts_section: Dict[str, str] | None = None) -> NetworkXGraphConfig:
    """Parse pipeline configuration into NetworkX format."""
    parser = NetworkXPipelineParser(scripts_section=scripts_section)
    return parser.parse_pipeline_config(pipeline_config) 