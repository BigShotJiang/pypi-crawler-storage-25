"""Build an XML pipeline tree from expanded processes for XPath probe path resolution."""

from __future__ import annotations

import ast
import logging
import os
import re
from pathlib import Path
from typing import Any, Iterable

logger = logging.getLogger(__name__)


def _get_attr(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _extract_process_info(proc: Any) -> dict[str, Any]:
    """Extract process metadata from an expanded ProcessConfig.

    The returned mapping is intentionally small and serialization‑friendly so it
    can be reused by helpers that need to derive canonical probe paths without
    depending on concrete ProcessConfig types.
    """
    name = _get_attr(proc, "name")
    base_name = _get_attr(proc, "base_name") or name
    parallel_context = _get_attr(proc, "parallel_context") or {}
    if not isinstance(parallel_context, dict):
        parallel_context = {}
    data_layers: list[dict[str, Any]] = []
    seed_layers: list[dict[str, Any]] = []
    for layer in parallel_context.get("data_layers") or []:
        if isinstance(layer, dict):
            data_layers.append(
                {
                    "source": layer.get("source"),
                    "partition_index": layer.get("partition_index"),
                }
            )
    for layer in parallel_context.get("seed_layers") or []:
        if isinstance(layer, dict):
            seed_layers.append(
                {
                    "source": layer.get("source"),
                    "seed_value": layer.get("seed_value"),
                }
            )
    script_path = _get_attr(proc, "script_path")
    code_function = _get_attr(proc, "code_function")
    return {
        "name": str(name or ""),
        "base_name": str(base_name or name or ""),
        "data_layers": data_layers,
        "seed_layers": seed_layers,
        "script_path": str(script_path) if script_path else None,
        "code_function": str(code_function) if code_function else None,
    }


def _discover_process_step_names(processes: Iterable[Any]) -> dict[str, set[str]]:
    """Statically discover step names per base process from process scripts.

    Uses AST analysis to:
      - Find top-level functions decorated with @step / @step(...)
      - For each process function, collect:
          * Calls to those top-level step functions
          * Nested functions inside the process decorated with @step / @step(...)
    Returns mapping: base_name -> set(step_names).
    Best-effort: on any error, returns an empty mapping and falls back to XPath parsing.
    """
    base_to_meta: dict[str, tuple[str, str]] = {}
    for proc in processes or []:
        info = _extract_process_info(proc)
        base_name = info.get("base_name") or info.get("name")
        script_path = info.get("script_path")
        code_function = info.get("code_function") or base_name
        if not base_name or not script_path or not code_function:
            continue
        # Deduplicate by base_name: first occurrence wins
        base_to_meta.setdefault(str(base_name), (str(script_path), str(code_function)))

    if not base_to_meta:
        return {}

    # Group processes by script file so each module is parsed once.
    def _resolve_script_file(script_path: str) -> Path | None:
        """Best-effort resolution for project-relative script paths."""
        try:
            raw = str(script_path or "").strip()
            if not raw:
                return None
            path_obj = Path(raw).expanduser()
            # 1) Absolute path as-is.
            if path_obj.is_absolute():
                return path_obj

            # 2) Relative to current working directory.
            cwd_candidate = (Path.cwd() / path_obj)
            if cwd_candidate.exists():
                return cwd_candidate

            # 3/4) Relative to workspace root (project-aware, then direct).
            try:
                from expops.core.workspace import get_workspace_root

                workspace_root = Path(get_workspace_root())
            except Exception:
                workspace_root = Path.cwd()

            project_id = str(os.environ.get("MLOPS_PROJECT_ID") or "").strip()
            if project_id:
                project_candidate = workspace_root / project_id / path_obj
                if project_candidate.exists():
                    return project_candidate

            workspace_candidate = workspace_root / path_obj
            if workspace_candidate.exists():
                return workspace_candidate

            # Fall back to a deterministic path for debugging/logging.
            return workspace_candidate
        except Exception:
            return None

    script_to_items: dict[Path, list[tuple[str, str]]] = {}
    for base_name, (script_path, code_function) in base_to_meta.items():
        p = _resolve_script_file(script_path)
        if p is None:
            continue
        script_to_items.setdefault(p, []).append((base_name, code_function))

    result: dict[str, set[str]] = {}

    def _is_step_decorator(node: ast.AST) -> bool:
        try:
            if isinstance(node, ast.Name) and node.id == "step":
                return True
            if isinstance(node, ast.Attribute) and node.attr == "step":
                return True
            if isinstance(node, ast.Call):
                func = node.func
                if isinstance(func, ast.Name) and func.id == "step":
                    return True
                if isinstance(func, ast.Attribute) and func.attr == "step":
                    return True
        except Exception:
            return False
        return False

    class _CallVisitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.names: set[str] = set()

        def visit_Call(self, node: ast.Call) -> None:  # type: ignore[override]
            try:
                func = node.func
                if isinstance(func, ast.Name):
                    self.names.add(func.id)
                elif isinstance(func, ast.Attribute):
                    self.names.add(func.attr)
            except Exception:
                pass
            self.generic_visit(node)

    class _NestedStepVisitor(ast.NodeVisitor):
        def __init__(self) -> None:
            self.func_nodes: dict[str, ast.FunctionDef] = {}

        def visit_FunctionDef(self, node: ast.FunctionDef) -> None:  # type: ignore[override]
            has_step = False
            for deco in node.decorator_list or []:
                if _is_step_decorator(deco):
                    has_step = True
                    break
            if has_step and isinstance(node.name, str):
                self.func_nodes[node.name] = node
            self.generic_visit(node)

    for script_path, items in script_to_items.items():
        try:
            if not script_path.exists() or not script_path.is_file():
                continue
            try:
                source = script_path.read_text(encoding="utf-8")
            except Exception:
                source = script_path.read_text()
            module = ast.parse(source)
        except Exception as exc:
            logger.debug("Failed to parse script '%s' for step discovery: %s", script_path, exc)
            continue

        # Index top-level functions and candidate step functions in this module.
        func_defs: dict[str, ast.FunctionDef] = {}
        candidate_step_funcs: set[str] = set()
        for node in module.body:
            if isinstance(node, ast.FunctionDef):
                func_defs[node.name] = node
                for deco in node.decorator_list or []:
                    if _is_step_decorator(deco):
                        candidate_step_funcs.add(node.name)
                        break

        for base_name, code_function in items:
            try:
                proc_node = func_defs.get(code_function) or func_defs.get(base_name)
                if proc_node is None:
                    continue
                call_visitor = _CallVisitor()
                call_visitor.visit(proc_node)
                nested_visitor = _NestedStepVisitor()
                nested_visitor.visit(proc_node)

                step_names: set[str] = set()
                for nm in sorted(call_visitor.names):
                    if nm in candidate_step_funcs:
                        step_names.add(nm)
                for nm in sorted(nested_visitor.func_nodes.keys()):
                    step_names.add(nm)

                if step_names:
                    result.setdefault(base_name, set()).update(step_names)
            except Exception as exc:
                logger.debug(
                    "Failed to discover steps for process '%s' in '%s': %s",
                    base_name,
                    script_path,
                    exc,
                )
                continue

    return result


def _step_names_from_xpath_strings(paths: Iterable[str]) -> dict[str, set[str]]:
    """Collect (process base_name -> set of step names) from XPath strings.

    Looks for *[@name="process_name"]/step[@name="step_name"] or
    *[@name="process_name"]/*[@name="step_name"] to associate steps with processes.
    Also collects step[@name="X"] alone and adds X to every process that already has steps.
    """
    process_step_re = re.compile(
        r'\*\s*\[\s*@name\s*=\s*["\']([^"\']+)["\']\s*\]\s*/\s*step\s*\[\s*@name\s*=\s*["\']([^"\']+)["\']\s*\]'
    )
    process_step_asterisk_re = re.compile(
        r'\*\s*\[\s*@name\s*=\s*["\']([^"\']+)["\']\s*\]\s*/\s*\*\s*\[\s*@name\s*=\s*["\']([^"\']+)["\']\s*\]'
    )
    bare_step_re = re.compile(r'/step\s*\[\s*@name\s*=\s*["\']([^"\']+)["\']\s*\]')
    bare_wild_name_re = re.compile(r'^/{1,2}\*\s*\[\s*@name\s*=\s*["\']([^"\']+)["\']\s*\]\s*$')
    result: dict[str, set[str]] = {}
    for path in paths:
        path = (path or "").strip()
        if not path or "@name" not in path:
            continue
        for m in process_step_re.finditer(path):
            proc_name, step_name = m.group(1), m.group(2)
            result.setdefault(proc_name, set()).add(step_name)
        for m in process_step_asterisk_re.finditer(path):
            proc_name, step_name = m.group(1), m.group(2)
            result.setdefault(proc_name, set()).add(step_name)
    for path in paths:
        path = (path or "").strip()
        if not path:
            continue
        for m in bare_step_re.finditer(path):
            step_name = m.group(1)
            if result:
                for proc_name in result:
                    result[proc_name].add(step_name)
            else:
                result.setdefault("", set()).add(step_name)
        m = bare_wild_name_re.fullmatch(path)
        if m:
            step_name = m.group(1)
            if result:
                for proc_name in result:
                    result[proc_name].add(step_name)
            else:
                result.setdefault("", set()).add(step_name)
    return result


def build_pipeline_tree(
    processes: Iterable[Any],
    probe_paths_values: Iterable[str] | None = None,
) -> Any:
    """Build an lxml Element tree representing the pipeline for XPath evaluation.

    Tree structure:
      pipeline
        process @name=<data_source> @partition=p1|p2|...
          process @name=<seed_source> @seed=41|42|...
            process @name=<base_name>
              step @name=...

    Behavior:
    - Uses the expanded process list (after data/seed parallelism expansion).
    - Discovers step names per base process by statically inspecting process code
      via script_path/code_function (AST-based step discovery).
    - Merges in any additional step names referenced explicitly in XPath
      probe_paths_values (e.g., *[@name=\"...\"]/step[@name=\"...\"], bare step[@name=\"...\"]).
    - Falls back to a pure XPath-derived representation when code introspection is
      not possible (e.g., missing script_path or unreadable modules), preserving
      legacy behavior.
    """
    from lxml import etree
    root = etree.Element("pipeline")
    # (data_chain, seed_chain) -> (base_name -> expanded_name); we need to add process nodes and steps
    # data_chain = tuple of (source, partition_index), seed_chain = tuple of (source, seed_value)
    # We'll build a nested dict: by data_chain -> by seed_chain -> list of (base_name, expanded_name)
    by_path: dict[tuple, dict[tuple, list[tuple[str, str]]]] = {}
    for proc in processes or []:
        info = _extract_process_info(proc)
        name = info["name"]
        base_name = info["base_name"]
        data_layers = info.get("data_layers") or []
        seed_layers = info.get("seed_layers") or []
        data_chain = tuple((lay.get("source"), lay.get("partition_index")) for lay in data_layers)
        seed_chain = tuple((lay.get("source"), lay.get("seed_value")) for lay in seed_layers)
        by_path.setdefault(data_chain, {}).setdefault(seed_chain, []).append((base_name, name))

    # Deduplicate (base_name, expanded_name) per (data_chain, seed_chain)
    for data_chain in by_path:
        for seed_chain in by_path[data_chain]:
            seen: set[str] = set()
            unique: list[tuple[str, str]] = []
            for base_name, expanded_name in by_path[data_chain][seed_chain]:
                if base_name not in seen:
                    seen.add(base_name)
                    unique.append((base_name, expanded_name))
            by_path[data_chain][seed_chain] = unique

    # Start from statically discovered steps, then merge in any extra steps
    # referenced explicitly in XPath probe paths.
    step_names_by_process = _discover_process_step_names(processes)
    xpath_step_names = _step_names_from_xpath_strings(probe_paths_values or [])
    unbound_steps = xpath_step_names.pop("", set())

    if not step_names_by_process:
        # Fallback: pure XPath-derived behavior (legacy).
        step_names_by_process = xpath_step_names
    else:
        # Merge per-process XPath-derived steps into the discovered sets.
        for proc_name, steps in xpath_step_names.items():
            if not proc_name:
                continue
            step_names_by_process.setdefault(proc_name, set()).update(steps)

    # Handle unbound selectors (e.g. //*[@name='step_name']) conservatively.
    # Prefer discovered process-step mappings and avoid broad fan-out.
    if unbound_steps:
        base_names_in_graph: set[str] = set()
        for seed_map in by_path.values():
            for base_list in seed_map.values():
                for base_name, _ in base_list:
                    base_names_in_graph.add(base_name)

        target_base_names: set[str] = set()
        for step_name in unbound_steps:
            for proc_name, proc_steps in step_names_by_process.items():
                if step_name in proc_steps:
                    target_base_names.add(proc_name)
        if not target_base_names:
            if len(step_names_by_process) == 1:
                target_base_names.update(step_names_by_process.keys())
            elif not step_names_by_process and len(base_names_in_graph) == 1:
                target_base_names.update(base_names_in_graph)
        for base_name in target_base_names:
            step_names_by_process.setdefault(base_name, set()).update(unbound_steps)

    # Helper: get or create child element by key
    def ensure_path(
        parent: Any,
        data_chain: tuple,
        seed_chain: tuple,
        base_name: str,
        expanded_name: str,
    ) -> Any:
        current = parent
        # Data layers: process with @partition
        for i, (source, part_idx) in enumerate(data_chain):
            source_str = str(source or "")
            part_val = f"p{part_idx}" if part_idx is not None else ""
            # Find existing child process with same name and partition
            found = None
            for child in current:
                if child.tag != "process":
                    continue
                if child.get("name") == source_str and child.get("partition") == part_val:
                    found = child
                    break
            if found is None:
                found = etree.SubElement(current, "process", name=source_str)
                if part_val:
                    found.set("partition", part_val)
            current = found
        # Seed layers: process with @seed
        for i, (source, seed_val) in enumerate(seed_chain):
            source_str = str(source or "")
            seed_str = str(seed_val) if seed_val is not None else ""
            found = None
            for child in current:
                if child.tag != "process":
                    continue
                if child.get("name") == source_str and child.get("seed") == seed_str:
                    found = child
                    break
            if found is None:
                found = etree.SubElement(current, "process", name=source_str)
                if seed_str:
                    found.set("seed", seed_str)
            current = found
        # Leaf process (base_name)
        found = None
        for child in current:
            if child.tag != "process":
                continue
            if child.get("name") == base_name and "partition" not in child.attrib and "seed" not in child.attrib:
                found = child
                break
        if found is None:
            found = etree.SubElement(current, "process", name=base_name)
        # Store expanded name on element for resolution (custom attribute; XPath doesn't need it)
        found.set("_expanded_name", expanded_name)
        return found

    for data_chain, seed_map in by_path.items():
        for seed_chain, base_list in seed_map.items():
            for base_name, expanded_name in base_list:
                proc_el = ensure_path(root, data_chain, seed_chain, base_name, expanded_name)
                steps = step_names_by_process.get(base_name) or set()
                for step_name in sorted(steps):
                    # Avoid duplicate step elements
                    has_step = any(
                        c.tag == "step" and c.get("name") == step_name
                        for c in proc_el
                    )
                    if not has_step:
                        etree.SubElement(proc_el, "step", name=step_name)

    return root


def resolve_tree_node_to_probe_path(node: Any, step_name: str | None = None) -> str | None:
    """From a matched tree node (process or step), compute the canonical XPath-style probe path string.

    Canonical form:
      - Base process (no partition/seed): "//process[@name='<base_name>']"
      - With partition/seed ancestors:
          "//*[@partition='p1']/*[@seed='41']/process[@name='<base_name>']"
      - Steps:
          "<process_xpath>/step[@name='<step_name>']"
    """
    if node is None:
        return None

    # If the node is a step, build the path based on its parent process.
    if node.tag == "step":
        parent = node.getparent()
        if parent is None:
            return None
        step_nm = step_name or node.get("name")
        if not step_nm:
            return None
        base_xpath = resolve_tree_node_to_probe_path(parent, None)
        if not base_xpath:
            return None
        return f"{base_xpath}/step[@name='{step_nm}']"

    if node.tag != "process":
        return None

    # Collect the chain of process nodes from the root down to this node.
    chain: list[Any] = []
    cur = node
    while cur is not None and cur.tag != "pipeline":
        if cur.tag == "process":
            chain.append(cur)
        cur = cur.getparent()
    if not chain:
        return None
    chain.reverse()

    segments: list[str] = []
    for idx, proc in enumerate(chain):
        name = proc.get("name", "")
        partition = proc.get("partition")
        seed = proc.get("seed")
        is_leaf = idx == len(chain) - 1
        if is_leaf:
            if not name:
                return None
            segments.append(f"process[@name='{name}']")
        else:
            if partition:
                segments.append(f"*[@partition='{partition}']")
            elif seed is not None:
                segments.append(f"*[@seed='{seed}']")
            elif name:
                segments.append(f"process[@name='{name}']")

    if not segments:
        return None

    xpath = "//" + "/".join(segments)
    if step_name:
        xpath = f"{xpath}/step[@name='{step_name}']"
    return xpath


def _canonical_process_xpath_from_layers(
    base_name: str,
    data_layers: list[dict[str, Any]],
    seed_layers: list[dict[str, Any]],
) -> str:
    """Build canonical process XPath from base name and data/seed layer dicts (no config)."""
    base_name = (base_name or "").strip()
    if not base_name:
        return "//process[@name='']"
    segments: list[str] = []
    for layer in data_layers or []:
        try:
            part_idx = layer.get("partition_index")
        except Exception:
            part_idx = None
        if part_idx is not None:
            segments.append(f"*[@partition='p{part_idx}']")
    for layer in seed_layers or []:
        try:
            seed_val = layer.get("seed_value")
        except Exception:
            seed_val = None
        if seed_val is not None:
            segments.append(f"*[@seed='{seed_val}']")
    segments.append(f"process[@name='{base_name}']")
    return "//" + "/".join(segments)


def _extract_base_name_from_canonical_xpath(xpath: str) -> str | None:
    """Extract process base name from canonical XPath-like process identifier."""
    raw = (xpath or "").strip()
    if not raw.startswith("//") or "process[@name=" not in raw:
        return None
    m = re.search(r"process\[@name='([^']*)'\]", raw)
    if not m:
        return None
    return m.group(1)


def canonical_process_xpath_from_config(proc: Any) -> str | None:
    """Compute the canonical process-level XPath for an expanded process config.

    This mirrors the structure produced by ``build_pipeline_tree`` and
    ``resolve_tree_node_to_probe_path``:

      - Base process (no partition/seed layers):
          ``//process[@name='<base_name>']``
      - With data/seed layers from the expanded parallel_context:
          ``//*[@partition='p1']/*[@seed='41']/process[@name='<base_name>']``
    """
    try:
        info = _extract_process_info(proc)
    except Exception:
        return None

    proc_name = (info.get("name") or "").strip()
    base_name = (info.get("base_name") or proc_name or "").strip()
    if not base_name:
        return None

    data_layers = info.get("data_layers") or []
    seed_layers = info.get("seed_layers") or []
    if proc_name.startswith("//") and "process[@name=" in proc_name:
        parsed_base = _extract_base_name_from_canonical_xpath(proc_name)
        if parsed_base:
            base_name = parsed_base
        # Idempotent behavior: already canonical and no parallel layers.
        if not data_layers and not seed_layers:
            return proc_name
    return _canonical_process_xpath_from_layers(base_name, data_layers, seed_layers)


def canonical_step_xpath_from_config(proc: Any, step_name: str) -> str | None:
    """Canonical step-level XPath for a step belonging to an expanded process."""
    if not step_name:
        return None
    base_xpath = canonical_process_xpath_from_config(proc)
    if not base_xpath:
        return None
    return f"{base_xpath}/step[@name='{step_name}']"


def canonical_process_xpath_from_layers(
    base_name: str,
    data_layers: list[dict[str, Any]],
    seed_layers: list[dict[str, Any]],
) -> str:
    """Build canonical process XPath from base name and data/seed layer dicts. Public for graph_expansion."""
    return _canonical_process_xpath_from_layers(base_name, data_layers, seed_layers)


__all__ = [
    "build_pipeline_tree",
    "resolve_tree_node_to_probe_path",
    "canonical_process_xpath_from_config",
    "canonical_process_xpath_from_layers",
    "canonical_step_xpath_from_config",
]
