from __future__ import annotations

from typing import Any, Optional
from dataclasses import dataclass
from enum import Enum


class NodeType(Enum):
    """Types of nodes in the execution graph."""
    PROCESS = "process"
    STEP = "step"


@dataclass
class DataParallelismConfig:
    """Configuration for data-parallel process expansion."""
    size: int | list[int]
    data_name: Optional[str] = None


@dataclass
class SeedParallelismConfig:
    """Configuration for seed-parallel process expansion."""
    seeds: list[int]


@dataclass
class MetricConfig:
    """Configuration for declarative process metric logging."""

    name: str
    from_result: Optional[str] = None
    fn: Optional[str] = None
    inputs: dict[str, str] | None = None

    def __post_init__(self) -> None:
        if self.inputs is None:
            self.inputs = {}


@dataclass
class ProcessConfig:
    """Configuration for a process node."""
    name: str
    depends_on: list[str] | None = None
    parallel: bool = True
    data_parallelism: Optional[DataParallelismConfig] = None
    seed_parallelism: Optional[SeedParallelismConfig] = None
    data_aggregation: bool = False
    seed_aggregation: bool = False
    code_function: Optional[str] = None  # Function name to execute (if different from name)
    script_path: Optional[str] = None  # Resolved path to the Python file (resolved from script key in scripts section)
    component: Optional[str] = None  # Built-in component reference (e.g., "sklearn.LogisticRegression")
    inputs: dict[str, str] | None = None  # Canonical input key -> upstream key alias
    outputs: dict[str, str] | None = None  # Canonical output key -> emitted key alias
    process_type: str = "process"  # e.g., "process" or special types like "chart"
    probe_paths: dict[str, str] | None = None  # Chart probe mappings (chart processes only)
    chart_type: str = "static"  # Chart subtype for chart processes
    environment: Optional[str] = None  # Environment name to use for this process
    base_name: Optional[str] = None  # Original process name when duplicated
    parallel_context: dict[str, Any] | None = None  # Parallelism metadata for UI/worker
    partition_index: Optional[int] = None  # 1-based partition index for duplicated nodes
    seed_value: Optional[int] = None  # Seed value for seed-parallel duplicates
    metrics: list[MetricConfig] | None = None  # Declarative metric definitions
    
    def __post_init__(self) -> None:
        if self.depends_on is None:
            self.depends_on = []
        if self.probe_paths is None:
            self.probe_paths = {}
        if self.inputs is None:
            self.inputs = {}
        if self.outputs is None:
            self.outputs = {}
        if self.parallel_context is None:
            self.parallel_context = {}
        if self.metrics is None:
            self.metrics = []


@dataclass 
class StepConfig:
    """Configuration for a step node."""
    name: str
    type: str = "step"
    process: Optional[str] = None
    inputs: list[str] | None = None
    outputs: list[str] | None = None
    loop_back_to: Optional[str] = None
    condition: Optional[str] = None
    parallel: bool = True


@dataclass
class NetworkXGraphConfig:
    """Configuration for NetworkX-based graph execution."""
    processes: list[ProcessConfig] | None = None
    steps: list[StepConfig] | None = None
    execution: dict[str, Any] | None = None
    
    def __post_init__(self) -> None:
        if self.processes is None:
            self.processes = []
        if self.steps is None:
            self.steps = []
        if self.execution is None:
            self.execution = {}


@dataclass 
class ExecutionResult:
    """Result of executing a node (process or step)."""
    name: str
    result: Optional[dict[str, Any]] = None  # Dictionary containing step/process results
    execution_time: float = 0.0
    was_cached: bool = False
    error: Optional[str] = None 