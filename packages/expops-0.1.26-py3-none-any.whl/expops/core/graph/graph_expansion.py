from __future__ import annotations

from dataclasses import replace
from typing import Any
import itertools

from .graph_types import ProcessConfig, DataParallelismConfig, SeedParallelismConfig
from .pipeline_tree import canonical_process_xpath_from_layers


def _data_context_key(split_name: str) -> str:
    return f"data_parallel:{split_name}"


def _seed_context_key(split_name: str) -> str:
    return f"seed_parallel:{split_name}"


def _partition_count(cfg: DataParallelismConfig) -> int:
    try:
        size = cfg.size
        if isinstance(size, (list, tuple)):
            return len(size)
        return int(size)
    except Exception:
        return 0


def _seed_values(cfg: SeedParallelismConfig) -> list[int]:
    try:
        seeds = list(getattr(cfg, "seeds", []) or [])
    except Exception:
        return []
    if not seeds:
        return []
    out: list[int] = []
    for s in seeds:
        try:
            out.append(int(s))
        except Exception:
            return []
    if len(set(out)) != len(out):
        return []
    return out


def _clone_process(
    base: ProcessConfig,
    *,
    name: str,
    depends_on: list[str],
    base_name: str | None = None,
    parallel_context: dict[str, Any] | None = None,
    partition_index: int | None = None,
    process_type: str | None = None,
    code_function: str | None | object = ...,
    data_parallelism: DataParallelismConfig | None | object = ...,
    data_aggregation: bool | object = ...,
    seed_parallelism: SeedParallelismConfig | None | object = ...,
    seed_aggregation: bool | object = ...,
    seed_value: int | None | object = ...,
) -> ProcessConfig:
    cfg = replace(
        base,
        name=name,
        depends_on=list(depends_on),
        base_name=base_name,
        parallel_context=parallel_context or {},
        partition_index=partition_index,
        process_type=process_type or base.process_type,
    )
    if code_function is not ...:
        cfg.code_function = code_function  # type: ignore[assignment]
    if data_parallelism is not ...:
        cfg.data_parallelism = data_parallelism  # type: ignore[assignment]
    if data_aggregation is not ...:
        cfg.data_aggregation = bool(data_aggregation)  # type: ignore[assignment]
    if seed_parallelism is not ...:
        cfg.seed_parallelism = seed_parallelism  # type: ignore[assignment]
    if seed_aggregation is not ...:
        cfg.seed_aggregation = bool(seed_aggregation)  # type: ignore[assignment]
    if seed_value is not ...:
        cfg.seed_value = seed_value  # type: ignore[assignment]
    return cfg


def expand_process_graph(processes: list[ProcessConfig]) -> list[ProcessConfig]:
    """Expand a process DAG for data/seed parallelism.

    - data_parallelism nodes remain single; their downstream is duplicated by partitions.
    - seed_parallelism nodes remain single; their downstream is duplicated by seed.
    - Multiple data/seed layers are supported and expanded cartesianly.
    - data_aggregation collapses one (latest) data-parallel layer.
    - seed_aggregation collapses one (latest) seed-parallel layer.
    """
    base_cfgs = {p.name: p for p in processes}
    nodes = list(base_cfgs.keys())
    deps_map: dict[str, list[str]] = {n: list(base_cfgs[n].depends_on or []) for n in nodes}

    # Build adjacency + topo order
    adj: dict[str, list[str]] = {n: [] for n in nodes}
    indeg: dict[str, int] = {n: 0 for n in nodes}
    for n, deps in deps_map.items():
        for dep in deps:
            adj.setdefault(dep, []).append(n)
            indeg[n] = indeg.get(n, 0) + 1

    queue = [n for n in nodes if indeg.get(n, 0) == 0]
    topo: list[str] = []
    while queue:
        cur = queue.pop(0)
        topo.append(cur)
        for nxt in adj.get(cur, []):
            indeg[nxt] = indeg.get(nxt, 0) - 1
            if indeg[nxt] <= 0:
                queue.append(nxt)
    if len(topo) != len(nodes):
        # Fallback to original order if a cycle or mismatch is detected.
        topo = nodes

    expanded: list[ProcessConfig] = []
    base_data_ctxs: dict[str, tuple[str, ...]] = {}
    base_seed_ctxs: dict[str, tuple[str, ...]] = {}
    split_data_ctxs: dict[str, str] = {}
    split_seed_ctxs: dict[str, str] = {}
    context_meta: dict[str, dict[str, Any]] = {}

    def _single_stack(stacks: list[tuple[str, ...]], kind: str, name: str) -> tuple[str, ...]:
        uniq = {tuple(s) for s in stacks if s is not None}
        if len(uniq) > 1:
            raise ValueError(
                f"Process '{name}' cannot depend on multiple {kind}-parallel stacks: {sorted(uniq)}"
            )
        return next(iter(uniq)) if uniq else ()

    def _is_prefix(prefix: tuple[str, ...], full: tuple[str, ...]) -> bool:
        if len(prefix) > len(full):
            return False
        return full[: len(prefix)] == prefix

    def _data_ctx_size(ctx: str) -> int:
        meta = context_meta.get(ctx, {})
        try:
            return int(meta.get("size") or 0)
        except Exception:
            return 0

    def _seed_ctx_values(ctx: str) -> list[int]:
        meta = context_meta.get(ctx, {})
        vals = meta.get("seeds")
        try:
            return list(vals or [])
        except Exception:
            return []

    def _data_indices_for_stack(stack: tuple[str, ...]) -> list[list[int]]:
        out: list[list[int]] = []
        for ctx_key in stack:
            count = _data_ctx_size(ctx_key)
            if count <= 0:
                raise ValueError(f"Unknown data-parallel context size for '{ctx_key}'.")
            out.append(list(range(1, count + 1)))
        return out

    def _seed_values_for_stack(stack: tuple[str, ...]) -> list[list[int]]:
        out: list[list[int]] = []
        for ctx_key in stack:
            values = _seed_ctx_values(ctx_key)
            if not values:
                raise ValueError(f"Unknown seed-parallel context seeds for '{ctx_key}'.")
            out.append(list(values))
        return out

    def _build_parallel_context(
        data_ctxs: tuple[str, ...],
        seed_ctxs: tuple[str, ...],
        data_indices: tuple[int | None, ...],
        seed_values: tuple[int | None, ...],
        *,
        role: str | None = None,
    ) -> dict[str, Any]:
        ctx: dict[str, Any] = {}
        data_layers: list[dict[str, Any]] = []
        seed_layers: list[dict[str, Any]] = []

        for ctx_key, idx in zip(data_ctxs, data_indices):
            meta = context_meta.get(ctx_key, {}) if ctx_key else {}
            layer: dict[str, Any] = {}
            if isinstance(meta, dict):
                layer.update(meta)
            if idx is not None:
                layer["partition_index"] = idx
            data_layers.append(layer)

        for ctx_key, sval in zip(seed_ctxs, seed_values):
            meta = context_meta.get(ctx_key, {}) if ctx_key else {}
            layer = {}
            if isinstance(meta, dict):
                layer.update(meta)
            if sval is not None:
                layer["seed_value"] = sval
            seed_layers.append(layer)

        if data_layers:
            ctx["data_layers"] = data_layers
            latest = data_layers[-1]
            if latest.get("type") is not None:
                ctx["type"] = latest.get("type")
            if latest.get("source") is not None:
                ctx["source"] = latest.get("source")
                ctx["parallel_source"] = latest.get("source")
            if latest.get("data_name") is not None:
                ctx["data_name"] = latest.get("data_name")
            if latest.get("size") is not None:
                ctx["size"] = latest.get("size")

        if seed_layers:
            ctx["seed_layers"] = seed_layers
            latest = seed_layers[-1]
            if latest.get("source") is not None:
                ctx["seed_source"] = latest.get("source")
            if latest.get("seeds") is not None:
                try:
                    ctx["seed_values"] = list(latest.get("seeds") or [])
                except Exception:
                    ctx["seed_values"] = latest.get("seeds")
            if latest.get("size") is not None:
                ctx["seed_size"] = latest.get("size")
            if "type" not in ctx:
                ctx["type"] = latest.get("type")

        if role and (data_layers or seed_layers):
            ctx["role"] = role
        return ctx

    def _xpath_for_variant(
        base_name: str,
        data_indices: tuple[int | None, ...],
        seed_values: tuple[int | None, ...],
    ) -> str:
        """Canonical XPath for an expanded process variant."""
        data_layers = [{"partition_index": idx} for idx in data_indices if idx is not None]
        seed_layers = [{"seed_value": v} for v in seed_values if v is not None]
        return canonical_process_xpath_from_layers(base_name, data_layers, seed_layers)

    def _resolve_dep_names(
        dep: str,
        *,
        data_stack: tuple[str, ...],
        seed_stack: tuple[str, ...],
        data_idx_map: dict[str, int],
        seed_val_map: dict[str, int],
        data_agg: bool,
        seed_agg: bool,
    ) -> list[str]:
        dep_data_stack = base_data_ctxs.get(dep, ())
        dep_seed_stack = base_seed_ctxs.get(dep, ())
        dep_output_data_stack = dep_data_stack + ((split_data_ctxs[dep],) if dep in split_data_ctxs else ())
        dep_output_seed_stack = dep_seed_stack + ((split_seed_ctxs[dep],) if dep in split_seed_ctxs else ())

        if not _is_prefix(dep_output_data_stack, data_stack):
            raise ValueError(f"Process '{dep}' depends on mismatched data-parallel contexts.")
        if not _is_prefix(dep_output_seed_stack, seed_stack):
            raise ValueError(f"Process '{dep}' depends on mismatched seed-parallel contexts.")

        agg_data_ctx = data_stack[-1] if (data_agg and data_stack) else None
        agg_seed_ctx = seed_stack[-1] if (seed_agg and seed_stack) else None

        dep_data_options: list[list[int]] = []
        for ctx_key in dep_data_stack:
            if agg_data_ctx is not None and ctx_key == agg_data_ctx:
                count = _data_ctx_size(ctx_key)
                if count <= 0:
                    raise ValueError(f"Unknown data-parallel context size for '{dep}'.")
                dep_data_options.append(list(range(1, count + 1)))
                continue
            if ctx_key not in data_idx_map:
                raise ValueError(
                    f"Process '{base_name}' must aggregate data-parallel upstream '{dep}' before merging."
                )
            dep_data_options.append([data_idx_map[ctx_key]])

        dep_seed_options: list[list[int]] = []
        for ctx_key in dep_seed_stack:
            if agg_seed_ctx is not None and ctx_key == agg_seed_ctx:
                values = _seed_ctx_values(ctx_key)
                if not values:
                    raise ValueError(f"Unknown seed-parallel context seeds for '{dep}'.")
                dep_seed_options.append(list(values))
                continue
            if ctx_key not in seed_val_map:
                raise ValueError(
                    f"Process '{base_name}' must aggregate seed-parallel upstream '{dep}' before merging."
                )
            dep_seed_options.append([seed_val_map[ctx_key]])

        data_product = list(itertools.product(*dep_data_options)) if dep_data_options else [()]
        seed_product = list(itertools.product(*dep_seed_options)) if dep_seed_options else [()]
        names: list[str] = []
        for di in data_product:
            for sv in seed_product:
                names.append(_xpath_for_variant(dep, tuple(di), tuple(sv)))
        return names

    for base_name in topo:
        cfg = base_cfgs[base_name]
        deps = deps_map.get(base_name, [])

        incoming_data_stacks: list[tuple[str, ...]] = []
        incoming_seed_stacks: list[tuple[str, ...]] = []
        for dep in deps:
            dep_data_stack = base_data_ctxs.get(dep, ())
            dep_seed_stack = base_seed_ctxs.get(dep, ())
            if dep in split_data_ctxs:
                dep_data_stack = dep_data_stack + (split_data_ctxs[dep],)
            if dep in split_seed_ctxs:
                dep_seed_stack = dep_seed_stack + (split_seed_ctxs[dep],)
            incoming_data_stacks.append(dep_data_stack)
            incoming_seed_stacks.append(dep_seed_stack)

        data_stack = _single_stack(incoming_data_stacks, "data", base_name)
        seed_stack = _single_stack(incoming_seed_stacks, "seed", base_name)

        if cfg.data_parallelism is not None and cfg.seed_parallelism is not None:
            raise ValueError(
                f"Process '{base_name}' cannot declare both data_parallelism and seed_parallelism."
            )

        if cfg.data_parallelism is not None:
            ctx_key = _data_context_key(base_name)
            split_data_ctxs[base_name] = ctx_key
            part_count = _partition_count(cfg.data_parallelism)
            if part_count <= 0:
                raise ValueError(f"Invalid data_parallelism.size for '{base_name}': {cfg.data_parallelism.size}")

            context_meta[ctx_key] = {
                "type": "data_parallelism",
                "source": base_name,
                "size": part_count,
                "data_name": cfg.data_parallelism.data_name,
            }

            # Use an explicit code_function for all expanded variants so workers
            # can resolve the correct @process even when names are suffixed.
            effective_code_fn = cfg.code_function or base_name

            data_product = (
                list(itertools.product(*_data_indices_for_stack(data_stack))) if data_stack else [()]
            )
            seed_product = (
                list(itertools.product(*_seed_values_for_stack(seed_stack))) if seed_stack else [()]
            )

            for data_vals in data_product:
                for seed_vals in seed_product:
                    data_idx_map = {ctx: int(idx) for ctx, idx in zip(data_stack, data_vals)}
                    seed_val_map = {ctx: int(val) for ctx, val in zip(seed_stack, seed_vals)}
                    split_xpath = _xpath_for_variant(
                        base_name,
                        tuple(data_vals),
                        tuple(seed_vals),
                    )
                    split_deps: list[str] = []
                    for dep in deps:
                        split_deps.extend(
                            _resolve_dep_names(
                                dep,
                                data_stack=data_stack,
                                seed_stack=seed_stack,
                                data_idx_map=data_idx_map,
                                seed_val_map=seed_val_map,
                                data_agg=False,
                                seed_agg=False,
                            )
                        )
                    data_ctx_for_ctx = data_stack + (ctx_key,)
                    data_indices_for_ctx = tuple(list(data_vals) + [None])
                    seed_indices_for_ctx = tuple(seed_vals)
                    part_ctx = _build_parallel_context(
                        data_ctx_for_ctx,
                        seed_stack,
                        data_indices_for_ctx,
                        seed_indices_for_ctx,
                    )
                    split_node = _clone_process(
                        cfg,
                        name=split_xpath,
                        depends_on=split_deps,
                        base_name=base_name,
                        partition_index=(data_vals[-1] if data_vals else None),
                        seed_value=(seed_vals[-1] if seed_vals else None),
                        parallel_context=part_ctx,
                        code_function=effective_code_fn,
                    )
                    expanded.append(split_node)

            base_data_ctxs[base_name] = tuple(data_stack)
            base_seed_ctxs[base_name] = tuple(seed_stack)
            continue

        if cfg.seed_parallelism is not None:
            ctx_key = _seed_context_key(base_name)
            split_seed_ctxs[base_name] = ctx_key
            seeds = _seed_values(cfg.seed_parallelism)
            if not seeds:
                raise ValueError(f"Invalid seed_parallelism.seeds for '{base_name}'.")

            context_meta[ctx_key] = {
                "type": "seed_parallelism",
                "source": base_name,
                "size": len(seeds),
                "seeds": seeds,
            }

            # Use an explicit code_function for all expanded variants so workers
            # can resolve the correct @process even when names are suffixed.
            effective_code_fn = cfg.code_function or base_name

            data_product = (
                list(itertools.product(*_data_indices_for_stack(data_stack))) if data_stack else [()]
            )
            seed_product = (
                list(itertools.product(*_seed_values_for_stack(seed_stack))) if seed_stack else [()]
            )

            for data_vals in data_product:
                for seed_vals in seed_product:
                    data_idx_map = {ctx: int(idx) for ctx, idx in zip(data_stack, data_vals)}
                    seed_val_map = {ctx: int(val) for ctx, val in zip(seed_stack, seed_vals)}
                    split_xpath = _xpath_for_variant(
                        base_name,
                        tuple(data_vals),
                        tuple(seed_vals),
                    )
                    split_deps: list[str] = []
                    for dep in deps:
                        split_deps.extend(
                            _resolve_dep_names(
                                dep,
                                data_stack=data_stack,
                                seed_stack=seed_stack,
                                data_idx_map=data_idx_map,
                                seed_val_map=seed_val_map,
                                data_agg=False,
                                seed_agg=False,
                            )
                        )
                    seed_ctx_for_ctx = seed_stack + (ctx_key,)
                    seed_values_for_ctx = tuple(list(seed_vals) + [None])
                    data_indices_for_ctx = tuple(data_vals)
                    part_ctx = _build_parallel_context(
                        data_stack,
                        seed_ctx_for_ctx,
                        data_indices_for_ctx,
                        seed_values_for_ctx,
                    )
                    if part_ctx:
                        part_ctx["role"] = "parallel"
                    split_node = _clone_process(
                        cfg,
                        name=split_xpath,
                        depends_on=split_deps,
                        base_name=base_name,
                        parallel_context=part_ctx or {},
                        partition_index=(data_vals[-1] if data_vals else None),
                        seed_value=(seed_vals[-1] if seed_vals else None),
                        code_function=effective_code_fn,
                    )
                    expanded.append(split_node)

            base_data_ctxs[base_name] = tuple(data_stack)
            base_seed_ctxs[base_name] = tuple(seed_stack)
            continue

        data_agg = bool(cfg.data_aggregation)
        seed_agg = bool(cfg.seed_aggregation)

        data_stack_out = data_stack[:-1] if (data_agg and data_stack) else data_stack
        seed_stack_out = seed_stack[:-1] if (seed_agg and seed_stack) else seed_stack

        data_product = (
            list(itertools.product(*_data_indices_for_stack(data_stack_out))) if data_stack_out else [()]
        )
        seed_product = (
            list(itertools.product(*_seed_values_for_stack(seed_stack_out))) if seed_stack_out else [()]
        )

        # For duplicated downstream nodes, ensure an explicit code_function so
        # suffixed variants still resolve to the base @process definition.
        effective_code_fn = cfg.code_function or base_name

        for data_vals in data_product:
            for seed_vals in seed_product:
                data_idx_map = {ctx: int(idx) for ctx, idx in zip(data_stack_out, data_vals)}
                seed_val_map = {ctx: int(val) for ctx, val in zip(seed_stack_out, seed_vals)}
                node_deps: list[str] = []
                for dep in deps:
                    node_deps.extend(
                        _resolve_dep_names(
                            dep,
                            data_stack=data_stack,
                            seed_stack=seed_stack,
                            data_idx_map=data_idx_map,
                            seed_val_map=seed_val_map,
                            data_agg=data_agg,
                            seed_agg=seed_agg,
                        )
                    )
                part_ctx = _build_parallel_context(
                    data_stack_out,
                    seed_stack_out,
                    tuple(data_vals),
                    tuple(seed_vals),
                    role="parallel",
                )
                node_xpath = _xpath_for_variant(
                    base_name,
                    tuple(data_vals),
                    tuple(seed_vals),
                )
                node = _clone_process(
                    cfg,
                    name=node_xpath,
                    depends_on=node_deps,
                    base_name=base_name,
                    parallel_context=part_ctx or {},
                    partition_index=(data_vals[-1] if data_vals else None),
                    seed_value=(seed_vals[-1] if seed_vals else None),
                    code_function=effective_code_fn,
                )
                expanded.append(node)

        base_data_ctxs[base_name] = tuple(data_stack_out)
        base_seed_ctxs[base_name] = tuple(seed_stack_out)

    return expanded
