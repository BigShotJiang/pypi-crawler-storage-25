from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


def resolve_script_path(
    script_key: Optional[str],
    scripts_section: Optional[Dict[str, str]],
    default_script: Optional[str] = None,
) -> Optional[str]:
    """
    Resolve a script key to its actual path from the scripts section.
    
    Args:
        script_key: The script key to resolve (e.g., "main", "reporting")
        scripts_section: Dictionary mapping script keys to paths
        default_script: Optional default script key (if None, uses first script in section)
    
    Returns:
        The resolved script path, or None if not found
    """
    if not scripts_section:
        return None
    
    # If script_key is not provided, use default (first script in section)
    if not script_key:
        if default_script and default_script in scripts_section:
            return scripts_section[default_script]
        # Use first script as default
        if scripts_section:
            first_key = next(iter(scripts_section))
            return scripts_section[first_key]
        return None
    
    # Resolve the script key
    return scripts_section.get(script_key)


def _load_project_config(project_dir: Path | str, project_id: str) -> Dict[str, Any]:
    import yaml  # Local import to avoid import-time dependency if unused
    project_dir = Path(project_dir).resolve()
    config_path = project_dir / project_id / "configs" / "project_config.yaml"
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _get_pipeline_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    """Return pipeline config from experiment (experiment.pipeline)."""
    experiment_cfg = (cfg.get("experiment", {}) or {}) if isinstance(cfg, dict) else {}
    pipeline_cfg = (experiment_cfg.get("pipeline", {}) or {}) if isinstance(experiment_cfg, dict) else {}
    return pipeline_cfg if isinstance(pipeline_cfg, dict) else {}


def _parse_processes_from_pipeline(pipeline_config: Dict[str, Any]) -> List[str]:
    processes: List[str] = []

    # From explicit processes list
    for p in pipeline_config.get("processes", []) or []:
        name = p.get("name")
        if name and name not in processes:
            processes.append(name)

    # From adjacency list (NetworkX-like string or list)
    for src, tgt in _iter_adjlist_edges(pipeline_config.get("process_adjlist")):
        if src and src not in processes:
            processes.append(src)
        if tgt and tgt not in processes:
            processes.append(tgt)

    return processes


def _iter_adjlist_edges(adjlist: Any) -> List[tuple[str, str]]:
    """Parse a NetworkX-style adjacency list into directed edges (src, tgt)."""
    lines: List[str] = []
    if isinstance(adjlist, str):
        lines = adjlist.splitlines()
    elif isinstance(adjlist, list):
        lines = [str(x) for x in adjlist]

    edges: List[tuple[str, str]] = []
    for raw in lines:
        line = str(raw).strip()
        if not line:
            continue
        if "#" in line:
            line = line.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            # No outgoing edges on this line
            continue
        src = parts[0]
        for tgt in parts[1:]:
            edges.append((src, tgt))
    return edges


def _build_process_adjacency(pipeline_config: Dict[str, Any]) -> Dict[str, List[str]]:
    processes = _parse_processes_from_pipeline(pipeline_config)
    adj: Dict[str, List[str]] = {p: [] for p in processes}

    # From explicit processes depends_on
    for p in pipeline_config.get("processes", []) or []:
        name = p.get("name")
        deps = p.get("depends_on", []) or []
        for dep in deps:
            adj.setdefault(dep, [])
            if name not in adj[dep]:
                adj[dep].append(name)

    # From adjacency list
    for src, tgt in _iter_adjlist_edges(pipeline_config.get("process_adjlist")):
        adj.setdefault(src, [])
        if tgt not in adj[src]:
            adj[src].append(tgt)

    return adj



def parse_networkx_config_from_project(project_dir: Path | str, project_id: str) -> Dict[str, Any]:
    """Return a parsed view: {processes: [names], adj: {u:[v,...]}, steps_by_process: {proc:[step_names]}}"""
    cfg = _load_project_config(project_dir, project_id)
    pipeline_cfg = _get_pipeline_config(cfg)
    scripts_section = cfg.get("scripts") if isinstance(cfg, dict) else None

    # Use full parser + expansion to surface data-parallel duplicates in the UI.
    from .networkx_parser import parse_networkx_pipeline_from_config
    from .graph_expansion import expand_process_graph

    nx_cfg = parse_networkx_pipeline_from_config(pipeline_cfg, scripts_section=scripts_section)
    expanded_processes = expand_process_graph(nx_cfg.processes or [])

    processes = [p.name for p in expanded_processes]
    adj: Dict[str, List[str]] = {p: [] for p in processes}
    for proc in expanded_processes:
        for dep in (proc.depends_on or []):
            adj.setdefault(dep, [])
            if proc.name not in adj[dep]:
                adj[dep].append(proc.name)

    # Manual-step mode: do not consider configured or auto-discovered steps
    steps_by_process: Dict[str, List[str]] = {p: [] for p in processes}

    return {
        "processes": processes,
        "adj": adj,
        "steps_by_process": steps_by_process,
        "global_config": (cfg.get("experiment", {}) or {}) if isinstance(cfg, dict) else {},
        "process_configs": expanded_processes,
    }


def _partition_indices_from_xpath(xpath: str) -> List[int]:
    """Extract ordered partition indices from canonical xpath, e.g. @partition='p1' -> 1, @partition='p2' -> 2."""
    out: List[int] = []
    for m in re.finditer(r"@partition='p(\d+)'", xpath):
        try:
            out.append(int(m.group(1)))
        except (ValueError, IndexError):
            continue
    return out


def _seed_value_path_from_xpath(xpath: str) -> List[int]:
    """Extract ordered seed values from canonical xpath, e.g. @seed='41' -> 41."""
    out: List[int] = []
    for m in re.finditer(r"@seed='(\d+)'", xpath):
        try:
            out.append(int(m.group(1)))
        except (ValueError, IndexError):
            continue
    return out


def get_process_graph_summary(config_like: Dict[str, Any]) -> Dict[str, Any]:
    # Import locally to avoid circular imports at module load time.
    from .pipeline_tree import canonical_process_xpath_from_config

    processes: List[str] = list(config_like.get("processes", []) or [])
    adj_legacy: Dict[str, List[str]] = dict(config_like.get("adj", {}) or {})
    proc_cfgs = config_like.get("process_configs") or []

    # Build mapping from expanded process name -> canonical XPath id.
    name_to_xpath: Dict[str, str] = {}
    for cfg in proc_cfgs:
        try:
            name = getattr(cfg, "name", None) or (cfg.get("name") if isinstance(cfg, dict) else None)
        except Exception:
            name = None
        if not name:
            continue
        xpath = canonical_process_xpath_from_config(cfg) or str(name)
        name_to_xpath[str(name)] = xpath

    # Rebuild adjacency using canonical XPath IDs.
    adj: Dict[str, List[str]] = {}
    node_set: set[str] = set()
    for u_legacy, vs_legacy in adj_legacy.items():
        u = name_to_xpath.get(str(u_legacy), str(u_legacy))
        node_set.add(u)
        for v_legacy in vs_legacy:
            v = name_to_xpath.get(str(v_legacy), str(v_legacy))
            node_set.add(v)
            adj.setdefault(u, [])
            if v not in adj[u]:
                adj[u].append(v)

    # Ensure standalone processes without outgoing edges are present.
    for name in processes:
        xid = name_to_xpath.get(str(name), str(name))
        node_set.add(xid)
        adj.setdefault(xid, [])

    nodes = list(node_set)
    indeg: Dict[str, int] = {n: 0 for n in nodes}
    for u, vs in adj.items():
        for v in vs:
            indeg[v] = indeg.get(v, 0) + 1

    process_meta: Dict[str, Dict[str, Any]] = {}
    for cfg in proc_cfgs:
        try:
            name = getattr(cfg, "name", None) or (cfg.get("name") if isinstance(cfg, dict) else None)
            if not name:
                continue
            node_id = name_to_xpath.get(str(name), str(name))
            proc_type = getattr(cfg, "process_type", None)
            if proc_type is None and isinstance(cfg, dict):
                proc_type = cfg.get("process_type", cfg.get("type"))
            chart_type = getattr(cfg, "chart_type", None)
            if chart_type is None and isinstance(cfg, dict):
                chart_type = cfg.get("chart_type")
            probe_paths = getattr(cfg, "probe_paths", None)
            if probe_paths is None and isinstance(cfg, dict):
                probe_paths = cfg.get("probe_paths")
            data_parallelism = getattr(cfg, "data_parallelism", None)
            data_aggregation = bool(getattr(cfg, "data_aggregation", False))
            seed_parallelism = getattr(cfg, "seed_parallelism", None)
            seed_aggregation = bool(getattr(cfg, "seed_aggregation", False))
            parallel_context = (
                (cfg.get("parallel_context") if isinstance(cfg, dict) else None)
                or getattr(cfg, "parallel_context", None)
                or {}
            )
            if not isinstance(parallel_context, dict):
                parallel_context = {}
            partition_index = (
                cfg.get("partition_index") if isinstance(cfg, dict) else getattr(cfg, "partition_index", None)
            )
            seed_value = getattr(cfg, "seed_value", None)
            base_name = getattr(cfg, "base_name", None)
            role = None
            seed_role = None
            if isinstance(parallel_context, dict):
                role = parallel_context.get("role")
            if data_parallelism is not None:
                role = role or "split"
            if seed_parallelism is not None:
                seed_role = "split"
            is_chart = False
            if isinstance(proc_type, str) and proc_type.lower() == "chart":
                is_chart = True
            elif probe_paths:
                is_chart = True
            meta = {
                "base_name": base_name or name,
                "partition_index": partition_index,
                "parallel_role": role,
                "data_aggregation": data_aggregation,
                "seed_aggregation": seed_aggregation,
                "seed_value": seed_value,
                "seed_parallel_role": seed_role,
                "process_type": str(proc_type) if proc_type is not None else "process",
                "chart_type": str(chart_type) if chart_type is not None else None,
                "is_chart": is_chart,
            }
            try:
                if data_parallelism is not None:
                    size_val = getattr(data_parallelism, "size", None)
                    size_count = len(size_val) if isinstance(size_val, (list, tuple)) else int(size_val)
                    meta["parallel_size"] = size_count
                    meta["data_name"] = getattr(data_parallelism, "data_name", None)
            except Exception:
                pass
            try:
                if seed_parallelism is not None:
                    seeds = getattr(seed_parallelism, "seeds", None)
                    if isinstance(seeds, (list, tuple)):
                        meta["seed_parallel_size"] = len(seeds)
            except Exception:
                pass
            try:
                if isinstance(parallel_context, dict):
                    meta["parallel_source"] = parallel_context.get("source")
                    if "seed_source" in parallel_context:
                        meta["seed_source"] = parallel_context.get("seed_source")
                    if "seed_values" in parallel_context:
                        meta["seed_values"] = parallel_context.get("seed_values")
                    if "seed_size" in parallel_context and "seed_parallel_size" not in meta:
                        meta["seed_parallel_size"] = parallel_context.get("seed_size")
                    if "size" in parallel_context and "parallel_size" not in meta:
                        meta["parallel_size"] = parallel_context.get("size")
                    if "data_name" in parallel_context and "data_name" not in meta:
                        meta["data_name"] = parallel_context.get("data_name")
                    if "data_layers" in parallel_context:
                        meta["data_layers"] = parallel_context.get("data_layers")
                    if "seed_layers" in parallel_context:
                        meta["seed_layers"] = parallel_context.get("seed_layers")
            except Exception:
                pass
            # Multi-layer display: expose partition_indices and seed_value_path for UI labels
            data_layers = meta.get("data_layers") or []
            seed_layers = meta.get("seed_layers") or []
            partition_indices = [
                L.get("partition_index")
                for L in data_layers
                if L.get("partition_index") is not None
            ]
            seed_value_path = [
                L.get("seed_value")
                for L in seed_layers
                if L.get("seed_value") is not None
            ]
            # Fallback: derive from node_id (canonical xpath) when parallel_context didn't provide layers
            node_id_str = str(node_id)
            if not partition_indices and "@partition=" in node_id_str:
                partition_indices = _partition_indices_from_xpath(node_id_str)
            if not seed_value_path and "@seed=" in node_id_str:
                seed_value_path = _seed_value_path_from_xpath(node_id_str)
            if partition_indices:
                meta["partition_indices"] = partition_indices
            if seed_value_path:
                meta["seed_value_path"] = seed_value_path
            process_meta[node_id_str] = meta
        except Exception:
            continue

    return {"nodes": nodes, "adj": adj, "indeg": indeg, "process_meta": process_meta}


def get_process_graph_summary_from_project(project_dir: Path | str, project_id: str) -> Dict[str, Any]:
    config_like = parse_networkx_config_from_project(project_dir, project_id)
    return get_process_graph_summary(config_like)




def setup_environment_and_write_interpreter(
    project_dir: Path | str,
    project_id: str,
    env_file: Path | str,
) -> str:
    # Use a relative import to work whether invoked as `expops.*` or `src.expops.*`
    from ...managers.reproducibility_manager import ReproducibilityManager

    project_dir = Path(project_dir).resolve()
    env_file = Path(env_file)

    config_path = project_dir / project_id / "configs" / "project_config.yaml"
    rm = ReproducibilityManager(str(config_path), project_path=project_dir / project_id)
    cfg = rm.config or {}
    env_cfg = cfg.get("environment", {}) if isinstance(cfg.get("environment", {}), dict) else {}

    if "venv" in env_cfg:
        vcfg = env_cfg.get("venv") or {}
        if not isinstance(vcfg, dict):
            vcfg = {}
        if not vcfg.get("name"):
            vcfg["name"] = project_id
        env_cfg["venv"] = vcfg
        cfg["environment"] = env_cfg
        rm.config = cfg

    rm.setup_environment()
    py = rm.python_interpreter or sys.executable
    Path(env_file).write_text(py)
    return py 