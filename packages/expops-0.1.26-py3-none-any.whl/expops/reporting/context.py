from __future__ import annotations

from pathlib import Path
from typing import Any, Optional


class ChartContext:
    """Runtime context passed to chart functions.

    The platform supports two chart styles:
    - **static**: chart function receives resolved `metrics` (dict)
    - **dynamic**: chart function receives `probe_paths` and may subscribe to updates
    """

    def __init__(
        self,
        output_dir: Path,
        project_id: str,
        run_id: str,
        theme: str,
        chart_name: str,
        metrics: Optional[dict[str, Any]] = None,
        chart_type: str = "static",
    ):
        self.output_dir = output_dir
        self.project_id = project_id
        self.run_id = run_id
        self.theme = theme
        self.chart_name = chart_name
        self.metrics = metrics or {}
        self.chart_type = chart_type

    def get_run_status(self) -> Optional[str]:
        """Return lowercased run status (best-effort)."""
        try:
            from .kv_utils import create_kv_store
            kv = create_kv_store(self.project_id)
            if kv and hasattr(kv, "get_run_status"):
                status = kv.get_run_status(self.run_id)
                if status:
                    return str(status).lower()
        except Exception:
            pass
        return None

    def is_run_finished(self) -> bool:
        """Return True if the run status indicates completion/failure/cancellation.

        This is a convenience predicate for chart scripts to decide when to
        unsubscribe their listeners and exit.
        """
        status = self.get_run_status()
        return status in {"completed", "failed", "cancelled"}


__all__ = [
    "ChartContext",
]


