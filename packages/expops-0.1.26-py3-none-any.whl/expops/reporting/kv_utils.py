from __future__ import annotations

import os
from typing import Any, Optional

from expops.core.workspace import get_projects_root, get_workspace_root
from expops.storage.factory import create_kv_store as _create_kv_store


def _load_backend_cfg_from_project_config(project_id: str) -> dict[str, Any]:
    root = get_workspace_root()
    cfg_path = get_projects_root(root) / project_id / "configs" / "project_config.yaml"
    if not cfg_path.exists():
        return {}
    try:
        import yaml  # type: ignore
    except Exception:
        return {}
    try:
        cfg = yaml.safe_load(cfg_path.read_text()) or {}
        cache_cfg = (((cfg.get("experiment") or {}).get("cache") or {}))
        backend_cfg = (cache_cfg.get("backend") or {}) if isinstance(cache_cfg, dict) else {}
        return backend_cfg if isinstance(backend_cfg, dict) else {}
    except Exception:
        return {}


def create_kv_store(project_id: str) -> Optional[Any]:
    """Create a KV store instance for chart subprocesses.

    Priority:
    - `MLOPS_KV_BACKEND` (if set)
    - project config `<workspace>/<id>/configs/project_config.yaml` (cache.backend)
    - environment-driven heuristics
    """
    backend_cfg = _load_backend_cfg_from_project_config(project_id)
    root = get_workspace_root()
    project_root = get_projects_root(root) / project_id
    return _create_kv_store(
        project_id,
        backend_cfg,
        env=os.environ,
        workspace_root=root,
        project_root=project_root,
    )


__all__ = [
    "create_kv_store",
]


