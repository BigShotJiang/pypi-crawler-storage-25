from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional


# Defaults for execution workspace (temp dir for process runs)
DEFAULT_WORKSPACE_BASE_DIR = "/tmp"


@dataclass(frozen=True)
class ExecutionWorkspaceConfig:
    """Configuration for per-process temporary workspace execution.

    Processes run in an isolated temp directory under base_dir; artifacts are
    synced to the object store after completion. Cleanup is always "always"
    and mode is always "strict_process_workers".
    """

    base_dir: str = DEFAULT_WORKSPACE_BASE_DIR


def parse_execution_workspace_config(raw: Optional[Dict[str, Any]]) -> ExecutionWorkspaceConfig:
    """Parse execution.workspace from project_config into ExecutionWorkspaceConfig."""
    if not isinstance(raw, dict) or not raw:
        return ExecutionWorkspaceConfig()
    return ExecutionWorkspaceConfig(
        base_dir=str(raw.get("base_dir", DEFAULT_WORKSPACE_BASE_DIR)).strip() or DEFAULT_WORKSPACE_BASE_DIR,
    )


@dataclass(frozen=True)
class RunContext:
    """Typed, run-scoped context passed through orchestration/execution boundaries.

    This is intentionally small in Phase 2: it centralizes the identity (project/run)
    and key resolved paths/config snapshots so components don't rely on implicit
    global state or environment variables.
    """

    workspace_root: Path
    project_id: str
    project_root: Path
    run_id: str

    runtime_python: Optional[str] = None
    reporting_python: Optional[str] = None
    env_python_map: Dict[str, str] = field(default_factory=dict)
    default_environment: Optional[str] = None
    reporting_environment: Optional[str] = None

    cache_backend: Dict[str, Any] = field(default_factory=dict)
    cache_config: Dict[str, Any] = field(default_factory=dict)
    reporting_config: Dict[str, Any] = field(default_factory=dict)
    execution_workspace: Optional[ExecutionWorkspaceConfig] = None


__all__ = [
    "DEFAULT_WORKSPACE_BASE_DIR",
    "ExecutionWorkspaceConfig",
    "RunContext",
    "parse_execution_workspace_config",
]


