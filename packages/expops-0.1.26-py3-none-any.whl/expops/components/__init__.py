"""Component runner plugin loading for expops.

This package allows external expops components (e.g., expops-matplotlib,
expops-sklearn) to register themselves via Python entry points.
"""

