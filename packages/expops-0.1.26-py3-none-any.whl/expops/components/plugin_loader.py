from __future__ import annotations

import logging
from importlib import metadata
from typing import Iterable, Sequence

logger = logging.getLogger(__name__)

# Cache loaded entry points so we don't repeatedly import plugins.
_loaded_entrypoint_names: set[str] = set()


def _should_load(entrypoint_name: str, required_component_prefixes: Sequence[str] | None) -> bool:
    """
    `required_component_prefixes` is derived from `component:` refs like:
      - "sklearn." and "matplotlib."
    Entry point names from component packages are usually:
      - "sklearn" and "matplotlib"
    """
    if not required_component_prefixes:
        return True
    for req_prefix in required_component_prefixes:
        # Use startswith to handle both "matplotlib." and "matplotlib".
        if str(req_prefix).startswith(entrypoint_name):
            return True
    return False


def _iter_component_runner_entrypoints() -> Iterable[metadata.EntryPoint]:
    eps = metadata.entry_points()
    # Py3.10+ returns EntryPoints with `.select`.
    select = getattr(eps, "select", None)
    if callable(select):
        return eps.select(group="expops.component_runners")  # type: ignore[no-any-return]

    # Older-style dict mapping.
    return eps.get("expops.component_runners", [])  # type: ignore[no-any-return]


def ensure_component_runners_registered(required_component_prefixes: Sequence[str] | None = None) -> None:
    """
    Load expops component runner plugins registered under the
    `expops.component_runners` entry-point group.

    Each entry point should expose a callable like `register()` (via
    `module:function`) that registers expops `process` runners.
    """
    try:
        entrypoints = list(_iter_component_runner_entrypoints())
    except Exception as e:
        logger.warning("Failed to read entry points for expops components: %s", e)
        return

    # Normalize required prefixes once.
    required_prefixes_norm: list[str] = []
    if required_component_prefixes:
        for p in required_component_prefixes:
            if p is None:
                continue
            required_prefixes_norm.append(str(p))

    for ep in entrypoints:
        if not hasattr(ep, "name"):
            continue
        ep_name = str(ep.name)

        if ep_name in _loaded_entrypoint_names:
            continue
        if not _should_load(ep_name, required_prefixes_norm):
            continue

        try:
            register_fn = ep.load()
            if callable(register_fn):
                register_fn()
                _loaded_entrypoint_names.add(ep_name)
            else:
                logger.warning(
                    "Entry point %s did not resolve to a callable register() hook.",
                    ep.value,
                )
        except Exception as e:
            logger.warning("Failed to load component runner entry point %s: %s", getattr(ep, "value", ep_name), e)

