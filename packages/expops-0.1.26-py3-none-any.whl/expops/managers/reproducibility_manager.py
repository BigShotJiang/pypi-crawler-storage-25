from pathlib import Path
from typing import Dict, Any, Optional, List
import hashlib
import json
import yaml
import subprocess
from datetime import datetime
import numpy as np
import os
import random

from ..core.platform_install import ensure_platform_importable
from ..environment.factory import create_environment_manager, create_environment_managers
from ..environment.base import EnvironmentManager


class ReproducibilityManager:
    """Lightweight reproducibility manager for custom models."""
    
    def __init__(self, config_path: str, project_path: Optional[Path] = None):
        self.config_path = Path(config_path)
        self.project_path = project_path
        self.config = self._load_config()
        self.environment_managers: Dict[str, EnvironmentManager] = {}
        self.environment_manager: Optional[EnvironmentManager] = None
        self.default_environment_name: Optional[str] = None
        self._environment_python_map: Dict[str, str] = {}
        
        # Export project/workspace hints for downstream components that rely on env vars
        # (e.g., environment file resolution) when running inside a project context.
        try:
            if self.project_path is not None:
                proj = Path(self.project_path)
                os.environ.setdefault("MLOPS_PROJECT_ID", proj.name)
                parent = proj.parent
                if str(parent):
                    os.environ.setdefault("MLOPS_WORKSPACE_DIR", str(parent))
        except Exception:
            pass

    @property
    def environment_name(self) -> Optional[str]:
        """Get the name of the current environment."""
        if self.default_environment_name:
            return self.default_environment_name
        return self.environment_manager.get_environment_name() if self.environment_manager else None

    @property
    def python_interpreter(self) -> Optional[str]:
        """Get the Python interpreter path for the current environment."""
        return self.environment_manager.get_python_interpreter() if self.environment_manager else None

    @property
    def environment_python_map(self) -> Dict[str, str]:
        """Get a mapping of environment name to Python interpreter path."""
        return dict(self._environment_python_map)

    def ensure_reproducibility_setup(self) -> None:
        """Set up reproducibility across common ML libraries (minimal).

        - Seed Python's random and NumPy RNGs
        - Best-effort seed for PyTorch and TensorFlow if installed
        - Apply environment flags that encourage deterministic behavior
        """
        random_seed_config = self.config.get("reproducibility", {}).get("random_seed")

        if not isinstance(random_seed_config, int):
            random_seed_config = 42

        seed = int(random_seed_config)

        # Core Python and NumPy
        try:
            random.seed(seed)
        except Exception as e:
            print(f"[ReproducibilityManager] Failed to seed Python random: {e}")
        try:
            np.random.seed(seed)
        except Exception as e:
            print(f"[ReproducibilityManager] Failed to seed NumPy: {e}")

        # Best-effort environment flags for deterministic operations in DL frameworks
        try:
            os.environ.setdefault("TF_DETERMINISTIC_OPS", "1")
            os.environ.setdefault("TF_CUDNN_DETERMINISTIC", "1")
            os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":16:8")
        except Exception:
            pass

        # Framework-specific seeding
        self._seed_pytorch_if_available(seed)
        self._seed_tensorflow_if_available(seed)

        # Export base seed and task-level seeding toggle for workers/subprocesses
        try:
            os.environ.setdefault("MLOPS_RANDOM_SEED", str(seed))
        except Exception:
            pass
        try:
            tl_seed_cfg = self.config.get("reproducibility", {}).get("task_level_seeding")
            enabled = True if tl_seed_cfg is None else bool(tl_seed_cfg)
            os.environ.setdefault("MLOPS_TASK_LEVEL_SEEDING", "1" if enabled else "0")
        except Exception:
            pass

    def _seed_pytorch_if_available(self, seed: int) -> None:
        try:
            import torch
            try:
                torch.manual_seed(seed)
            except Exception:
                pass
            try:
                if torch.cuda.is_available():
                    torch.cuda.manual_seed_all(seed)
                # Ensure deterministic behavior when possible
                try:
                    torch.use_deterministic_algorithms(True)  # type: ignore[attr-defined]
                except Exception:
                    pass
                try:
                    import torch.backends.cudnn as cudnn  # type: ignore
                    cudnn.deterministic = True
                    cudnn.benchmark = False
                except Exception:
                    pass
            except Exception:
                pass
        except Exception:
            # PyTorch not installed or failed to import; ignore silently
            pass

    def _seed_tensorflow_if_available(self, seed: int) -> None:
        try:
            import tensorflow as tf
            try:
                tf.random.set_seed(seed)
            except Exception:
                pass
        except Exception:
            pass



    def _load_config(self) -> Dict[str, Any]:
        """Load and parse the configuration file."""
        with open(self.config_path) as f:
            return yaml.safe_load(f)

    def setup_environment(self) -> None:
        """Set up the environment based on configuration."""
        self.environment_managers, self.default_environment_name = create_environment_managers(self.config)
        if self.default_environment_name and self.default_environment_name in self.environment_managers:
            self.environment_manager = self.environment_managers[self.default_environment_name]
        elif self.environment_managers:
            self.environment_manager = next(iter(self.environment_managers.values()))
        else:
            self.environment_manager = create_environment_manager(self.config)
            self.environment_managers = {self.environment_manager.get_environment_name(): self.environment_manager}
            self.default_environment_name = self.environment_manager.get_environment_name()

        self._environment_python_map = {}
        for env_name, manager in self.environment_managers.items():
            try:
                manager.setup_environment()
            except RuntimeError as e:
                print(f"[ReproducibilityManager] Environment setup failed for '{env_name}': {e}")
                raise
            try:
                py_exec = manager.get_python_interpreter()
                self._environment_python_map[env_name] = py_exec
            except Exception:
                py_exec = None

        # Ensure chart/reporting environments can import the platform.
        try:
            for env_name in self._get_chart_environment_names():
                py_exec = self._environment_python_map.get(env_name)
                if py_exec:
                    self._ensure_platform_importable(py_exec)
        except Exception as e:
            print(f"[ReproducibilityManager] Reporting environment setup skipped or failed: {e}")

    def _get_chart_environment_names(self) -> List[str]:
        envs: set[str] = set()
        default_env = self.default_environment_name or (
            self.environment_manager.get_environment_name() if self.environment_manager else None
        )
        try:
            experiment_cfg = self.config.get("experiment", {}) if isinstance(self.config, dict) else {}
            pipeline_cfg = (experiment_cfg.get("pipeline", {}) or {}) if isinstance(experiment_cfg, dict) else {}
            processes = pipeline_cfg.get("processes", []) or []
            for proc in processes:
                if not isinstance(proc, dict):
                    continue
                proc_type = str(proc.get("type", "process")).lower()
                chart_type = str(proc.get("chart_type") or "").lower()
                has_probe_paths = proc.get("probe_paths") is not None
                is_chart = (proc_type == "chart") or bool(chart_type) or has_probe_paths
                if is_chart:
                    env_name = proc.get("environment") or default_env
                    if env_name:
                        envs.add(str(env_name))
        except Exception:
            pass

        try:
            reporting_cfg = self.config.get("reporting", {}) if isinstance(self.config, dict) else {}
            if isinstance(reporting_cfg, dict):
                rep_env = reporting_cfg.get("environment")
                if rep_env:
                    envs.add(str(rep_env))
        except Exception:
            pass

        return sorted(envs)

    def _ensure_platform_importable(self, python_exec: str) -> None:
        try:
            ensure_platform_importable(
                python_exec,
                import_module="expops.reporting",
                no_deps=True,
                quiet=False,
            )
        except Exception as _e:
            print(
                "[ReproducibilityManager] Warning: failed to ensure platform is importable "
                f"for interpreter {python_exec}: {_e}"
            )

    def apply_cloud_env_from_config(self, experiment_section: Dict[str, Any]) -> None:
        """Apply cloud-related environment variables from the YAML config.

        Sets GOOGLE_APPLICATION_CREDENTIALS, GOOGLE_CLOUD_PROJECT, and FIRESTORE_EMULATOR_HOST
        if present under experiment.cache.backend. Only applies when configured.
        """
        try:
            base_dir = self.project_path or Path.cwd()
            cache_cfg = (experiment_section or {}).get("cache", {}) or {}
            backend_cfg = cache_cfg.get("backend", {}) or {}

            creds_rel = backend_cfg.get("credentials_json")
            if creds_rel:
                candidates = [
                    (base_dir / creds_rel).resolve(),
                    (Path.cwd() / creds_rel).resolve(),
                ]
                chosen = next((p for p in candidates if p.exists()), None)
                if chosen is not None:
                    current = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
                    if not current or not Path(current).expanduser().exists():
                        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(chosen)
                else:
                    print(
                        f"[ReproducibilityManager] GCP credentials not found at: "
                        + ", ".join(str(p) for p in candidates)
                    )

            gcp_project = backend_cfg.get("gcp_project")
            if gcp_project:
                os.environ.setdefault("GOOGLE_CLOUD_PROJECT", str(gcp_project))

            emulator_host = backend_cfg.get("emulator_host")
            if emulator_host:
                os.environ.setdefault("FIRESTORE_EMULATOR_HOST", str(emulator_host))
        except Exception as e:
            print(f"[ReproducibilityManager] Failed to apply cloud env: {e}")

    def _pip_install(self, python_exec: str, packages: List[str]) -> None:
        if not packages or not python_exec:
            return
        try:
            # Pre-upgrade pip tooling
            try:
                subprocess.run([python_exec, "-m", "pip", "install", "--quiet", "--upgrade", "pip", "setuptools", "wheel"], check=False)
            except Exception:
                pass
            timeout_env = os.getenv("MLOPS_PIP_TIMEOUT", "")
            try:
                timeout_s = int(timeout_env) if timeout_env.strip().isdigit() else 1200
            except Exception:
                timeout_s = 1200
            try:
                subprocess.run([python_exec, "-m", "pip", "install", *packages], check=True, timeout=timeout_s)
            except subprocess.TimeoutExpired:
                print(f"[ReproducibilityManager] pip install timed out for: {', '.join(packages)}. Retrying without timeout...")
                subprocess.run([python_exec, "-m", "pip", "install", "--quiet", *packages], check=True)
        except Exception as e:
            print(f"[ReproducibilityManager] pip install failed for {packages} into {python_exec}: {e}")

    def _python_can_import(self, python_exec: Optional[str], module_name: str) -> bool:
        """Check module importability in a specific interpreter."""
        if not python_exec:
            return False
        try:
            res = subprocess.run(
                [python_exec, "-c", f"import {module_name}"],
                check=False,
                capture_output=True,
                text=True,
            )
            return res.returncode == 0
        except Exception:
            return False

    def ensure_cloud_dependencies(self, model_section: Dict[str, Any]) -> None:
        """Ensure cloud libs are present based on configured backend/object store.

        - google-cloud-storage when object_store.type == 'gcs'
        - google-cloud-firestore and google-cloud-pubsub when backend.type == 'gcp'
        - redis when backend.type == 'redis'
        Installs into training/runtime interpreter and reporting interpreter if available.
        """
        cache_cfg = (model_section or {}).get("cache", {}) or {}
        backend_cfg = cache_cfg.get("backend", {}) or {}
        store_cfg = cache_cfg.get("object_store", {}) or {}

        backend_type = backend_cfg.get("type")
        need_storage = (store_cfg.get("type") == "gcs")
        need_firestore = (backend_type == "gcp")
        need_redis = (backend_type == "redis")

        to_install: List[str] = []
        runtime_python = self.python_interpreter
        if need_storage and not self._python_can_import(runtime_python, "google.cloud.storage"):
            to_install.append("google-cloud-storage>=2.10.0")
        if need_firestore:
            if not self._python_can_import(runtime_python, "google.cloud.firestore"):
                to_install.append("google-cloud-firestore>=2.11.0")
            if not self._python_can_import(runtime_python, "google.cloud.pubsub"):
                to_install.append("google-cloud-pubsub>=2.13.0")
        if need_redis and not self._python_can_import(runtime_python, "redis"):
            to_install.append("redis>=5.0.0")

        # Deduplicate
        seen = set()
        final = [p for p in to_install if not (p in seen or seen.add(p))]
        if final and self.python_interpreter:
            self._pip_install(self.python_interpreter, final)

        # Reporting/chart envs (if any)
        reporting_packages: List[str] = []
        if need_firestore:
            reporting_packages += ["google-cloud-firestore>=2.11.0", "google-cloud-pubsub>=2.13.0"]
        if need_storage:
            reporting_packages += ["google-cloud-storage>=2.10.0"]
        seen_r = set()
        reporting_final = [p for p in reporting_packages if not (p in seen_r or seen_r.add(p))]
        if reporting_final:
            try:
                chart_envs = set(self._get_chart_environment_names())
            except Exception:
                chart_envs = set()
            for env_name in chart_envs:
                py_exec = self._environment_python_map.get(env_name)
                if py_exec and py_exec != self.python_interpreter:
                    missing_for_env: List[str] = []
                    for pkg in reporting_final:
                        if "google-cloud-firestore" in pkg and not self._python_can_import(py_exec, "google.cloud.firestore"):
                            missing_for_env.append(pkg)
                        elif "google-cloud-pubsub" in pkg and not self._python_can_import(py_exec, "google.cloud.pubsub"):
                            missing_for_env.append(pkg)
                        elif "google-cloud-storage" in pkg and not self._python_can_import(py_exec, "google.cloud.storage"):
                            missing_for_env.append(pkg)
                    if missing_for_env:
                        self._pip_install(py_exec, missing_for_env)

    def verify_environment(self) -> bool:
        """Verify that the environment is properly configured."""
        if not self.environment_manager:
            print("[ReproducibilityManager] Environment manager not initialized.")
            return False
        
        return self.environment_manager.verify_environment()

    @property
    def reporting_python_interpreter(self) -> Optional[str]:
        """Get Python interpreter for the reporting environment, if configured."""
        try:
            reporting_cfg = self.config.get("reporting", {}) if isinstance(self.config, dict) else {}
            if isinstance(reporting_cfg, dict):
                env_name = reporting_cfg.get("environment")
                if env_name:
                    return self._environment_python_map.get(str(env_name))
        except Exception:
            return None
        return None

    def compute_data_hash(self, data_path: str) -> str:
        """Compute a hash of the input data (file or directory)."""
        path = Path(data_path)
        if not path.exists():
            raise FileNotFoundError(f"Data path {data_path} not found for hashing.")

        if path.is_dir():
            hasher = hashlib.sha256()
            for item in sorted(os.listdir(path)):
                item_path = path / item
                hasher.update(item.encode())
                if item_path.is_file():
                    with open(item_path, 'rb') as f:
                        hasher.update(f.read())
            return hasher.hexdigest()
        else:
            with open(data_path, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()

    def save_artifacts(self, run_id: str, artifacts: Dict[str, Any]) -> Dict[str, str]:
        """Save artifacts locally and return their paths.

        Uses layout: .project_id/artifacts/<version_hash>/<encoded_probe_path>/
        with synthetic probe path repro/run_id for reproducibility artifacts.
        """
        saved_paths = {}
        if not artifacts:
            return saved_paths
        if self.project_path is not None:
            try:
                from expops.core.workspace import get_project_runtime_root
                from expops.core.cache_layout import compute_cache_version_hash, build_artifact_relative_path
                from expops.core.probe_path import get_encoded_probe_path
                runtime_root = get_project_runtime_root(self.project_path, self.project_path.name)
                version_hash = compute_cache_version_hash(self.project_path)
                encoded_probe = get_encoded_probe_path(process_name="repro", step_name=run_id)
                rel_path = build_artifact_relative_path(version_hash, encoded_probe)
                base_path = runtime_root / "artifacts" / rel_path
            except Exception:
                try:
                    runtime_root = self.project_path / f".{self.project_path.name}"
                    base_path = runtime_root / "artifacts" / run_id
                except Exception:
                    base_path = Path(".runtime") / "artifacts" / run_id
        else:
            base_path = Path(".runtime") / "artifacts" / run_id
        base_path.mkdir(parents=True, exist_ok=True)

        for artifact_name, artifact_data in artifacts.items():
            try:
                artifact_path = base_path / f"{artifact_name}.json"
                
                with open(artifact_path, "w") as f:
                    if isinstance(artifact_data, (dict, list)):
                        json.dump(artifact_data, f, indent=2, default=str)
                    else:
                        json.dump({"data": str(artifact_data)}, f, indent=2)
                
                saved_paths[artifact_name] = str(artifact_path)
                print(f"Artifact '{artifact_name}' saved to {artifact_path}")
                
            except Exception as e:
                print(f"Error saving artifact '{artifact_name}': {e}")

        return saved_paths

    def capture_environment_info(self) -> Dict[str, Any]:
        """Capture environment information for logging."""
        import platform
        import sys
        
        env_info = {
            "python_version": sys.version,
            "platform": platform.platform(),
            "processor": platform.processor(),
            "random_seed": self.config.get("reproducibility", {}).get("random_seed", "not_set")
        }
        
        if self.environment_manager:
            env_info["environment_name"] = self.environment_name
            env_info["python_interpreter"] = self.python_interpreter
        
        return env_info