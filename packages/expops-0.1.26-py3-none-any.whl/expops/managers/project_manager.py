import os
import shutil
import yaml
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import json


# Default .gitignore for new projects (blank, --config, or --template).
# Ensures the hidden runtime directory and common Python/local paths are ignored.
DEFAULT_PROJECT_GITIGNORE = """# Project outputs and runtime
.<PROJECT_ID>/

# Python
.venv/
venv/
env/
__pycache__/
*.py[cod]
*.pyo
.Python
*.egg-info/
.eggs/

# Environment and tooling
.env
.coverage
htmlcov/
.pytest_cache/
.mypy_cache/
.DS_Store
"""


class ProjectManager:
    """Manages MLOps projects with isolated state, caching, and configurations."""
    
    def __init__(self, projects_root: Optional[Union[str, Path]] = None):
        # Interpret projects_root relative to workspace root so callers can pass
        # `--workspace` / `MLOPS_WORKSPACE_DIR` and still work from any CWD.
        if projects_root is None:
            try:
                from expops.core.workspace import get_projects_root
                self.projects_root = get_projects_root()
            except Exception:
                self.projects_root = Path(".")
        else:
            pr = Path(projects_root)
            if not pr.is_absolute():
                try:
                    from expops.core.workspace import get_workspace_root
                    pr = get_workspace_root() / pr
                except Exception:
                    pass
            self.projects_root = pr

        self.projects_root.mkdir(parents=True, exist_ok=True)

    def _project_path(self, project_id: str) -> Path:
        return self.projects_root / project_id

    def _build_project_info_from_fs(self, project_id: str, project_path: Path) -> Dict[str, Any]:
        """
        Build project metadata derived from the filesystem.

        This replaces the old project_info.json-based metadata. No on-disk metadata
        is read or written here; callers should treat the returned dict as
        best-effort, computed on demand.
        """
        try:
            from expops.core.workspace import get_workspace_root

            rel_project_path = project_path.relative_to(get_workspace_root())
        except Exception:
            rel_project_path = project_path

        cfg_path = project_path / "configs" / "project_config.yaml"

        # Best-effort timestamps from filesystem; fall back to "now".
        now = datetime.now().isoformat()
        try:
            created_ts = datetime.fromtimestamp(project_path.stat().st_ctime).isoformat()
        except Exception:
            created_ts = now
        try:
            last_modified_ts = datetime.fromtimestamp(
                (cfg_path if cfg_path.exists() else project_path).stat().st_mtime
            ).isoformat()
        except Exception:
            last_modified_ts = created_ts

        info: Dict[str, Any] = {
            "project_id": project_id,
            "description": "",
            "created_at": created_ts,
            "last_modified": last_modified_ts,
            "base_config_path": None,
            "project_path": str(rel_project_path),
            # Runs are now tracked via KV backends / UI APIs; keep an empty list
            # for callers that still expect the key to exist.
            "runs": [],
        }
        if cfg_path.exists():
            info["active_config"] = str(cfg_path)
        return info

    def _is_project_dir(self, path: Path) -> bool:
        """Best-effort check that a directory is a project."""
        if not path.exists() or not path.is_dir():
            return False
        if (path / "configs" / "project_config.yaml").exists():
            return True
        return False
    
    def _list_available_templates(self) -> List[str]:
        """List built-in templates shipped with the package (best-effort)."""
        templates: List[str] = []
        try:
            from importlib import resources

            root = resources.files("expops") / "templates"
            if not root.is_dir():
                return []
            for child in root.iterdir():
                try:
                    if not child.is_dir():
                        continue
                    # New format: templates/<name>/configs/project_config.yaml
                    if (child / "configs" / "project_config.yaml").is_file():
                        templates.append(child.name)
                        continue
                    # Legacy format: templates/<name>/project_config.yaml
                    if (child / "project_config.yaml").is_file():
                        templates.append(child.name)
                except Exception:
                    continue
        except Exception:
            return []
        return sorted(set([t for t in templates if t]))

    def _apply_template(self, project_path: Path, project_id: str, template: str) -> Path:
        """Copy a built-in template into the project directory and return config path."""
        from importlib import resources
        from pathlib import Path as _Path

        available = self._list_available_templates()
        if template not in available:
            raise ValueError(
                f"Unknown template '{template}'. Available templates: {', '.join(available) if available else '(none found)'}"
            )

        root = resources.files("expops") / "templates" / template

        # New format: full project folder skeleton under the template root.
        new_cfg = root / "configs" / "project_config.yaml"
        legacy_cfg = root / "project_config.yaml"

        def _copy_tree(src_dir, dst_dir: Path) -> None:
            """Recursively copy an importlib.resources Traversable dir into dst_dir."""
            try:
                entries = list(src_dir.iterdir())
            except Exception:
                entries = []
            for entry in entries:
                try:
                    name = entry.name
                except Exception:
                    continue
                rel = _Path(name)
                try:
                    if entry.is_dir():
                        _copy_tree(entry, dst_dir / rel)
                        continue
                except Exception:
                    # Treat unknown entries as files
                    pass

                dest_path = dst_dir / rel
                dest_path.parent.mkdir(parents=True, exist_ok=True)

                # Read bytes from resource file
                try:
                    with entry.open("rb") as f:
                        raw = f.read()
                except Exception:
                    raw = b""

                # Best-effort: treat common text files as UTF-8 and expand template vars
                suffix = dest_path.suffix.lower()
                if suffix in {".yaml", ".yml", ".py", ".md", ".txt", ".csv", ".json"}:
                    try:
                        text = raw.decode("utf-8")
                        text = text.replace("{{PROJECT_ID}}", project_id)
                        dest_path.write_text(text, encoding="utf-8")
                        continue
                    except Exception:
                        pass

                dest_path.write_bytes(raw)

        if new_cfg.is_file():
            # Copy the entire template tree into the project root (configs/, data/, models/, charts/, etc.)
            _copy_tree(root, project_path)
            config_dest = project_path / "configs" / "project_config.yaml"
            if not config_dest.exists():
                raise ValueError(f"Template '{template}' did not produce configs/project_config.yaml")
            return config_dest

        # Legacy fallback: copy flat files into expected project folders.
        if legacy_cfg.is_file():
            # Write config (with placeholder expansion)
            try:
                with legacy_cfg.open("r", encoding="utf-8") as f:
                    cfg_text = f.read()
            except TypeError:
                with legacy_cfg.open("r") as f:
                    cfg_text = f.read()
            cfg_text = cfg_text.replace("{{PROJECT_ID}}", project_id)

            config_dest = project_path / "configs" / "project_config.yaml"
            config_dest.parent.mkdir(exist_ok=True)
            config_dest.write_text(cfg_text, encoding="utf-8")

            data_res = root / "train.csv"
            if data_res.is_file():
                data_dest = project_path / "data" / "train.csv"
                data_dest.parent.mkdir(exist_ok=True)
                with data_res.open("rb") as f:
                    data_dest.write_bytes(f.read())
            return config_dest

        raise ValueError(f"Template '{template}' is missing configs/project_config.yaml")

    def create_project(
        self,
        project_id: str,
        base_config_path: Optional[str] = None,
        description: str = "",
        template: Optional[str] = None,
        *,
        allow_existing_dir: bool = False,
    ) -> Dict[str, Any]:
        """
        Create a new project with isolated workspace.
        
        Args:
            project_id: Unique identifier for the project
            base_config_path: Optional path to base configuration to copy
            description: Project description
            template: Optional built-in template name to scaffold a runnable starter project
            
        Returns:
            Project information dictionary
        """
        if self.project_exists(project_id):
            raise ValueError(f"Project '{project_id}' already exists")

        if template and base_config_path:
            raise ValueError("Use either 'template' or 'base_config_path', not both")
        
        # Create project directory structure
        project_path = self._project_path(project_id)
        if project_path.exists():
            if not allow_existing_dir:
                raise ValueError(f"Project path already exists: {project_path}")
            # If the folder already looks like a project, treat it as "exists".
            if self._is_project_dir(project_path):
                raise ValueError(f"Project '{project_id}' already exists")
            # Safety: only allow scaffolding into an empty directory (with a few ignorable files).
            try:
                ignore = {".git", ".gitignore", ".DS_Store"}
                entries = [p for p in project_path.iterdir() if p.name not in ignore]
            except Exception:
                entries = []
            if entries:
                raise ValueError(
                    f"Target directory is not empty: {project_path}\n"
                    + "Please run `expops create <project_id>` from the workspace root, or use an empty directory for in-place creation."
                )
        else:
            project_path.mkdir(parents=True, exist_ok=True)
        try:
            from expops.core.workspace import get_workspace_root, get_project_runtime_root  # local import to avoid cycles

            workspace_root = get_workspace_root()
            rel_project_path = project_path.relative_to(workspace_root)
        except Exception:
            workspace_root = None
            rel_project_path = project_path
        
        # Create user-visible project subdirectories
        (project_path / "configs").mkdir(exist_ok=True)
        (project_path / "src").mkdir(exist_ok=True)
        (project_path / "data").mkdir(exist_ok=True)

        # Create hidden runtime directory for stateful outputs
        try:
            runtime_root = get_project_runtime_root(project_path, project_id) if workspace_root is not None else project_path / f".{project_id}"
        except Exception:
            runtime_root = project_path / f".{project_id}"

        (runtime_root / "envs").mkdir(parents=True, exist_ok=True)
        (runtime_root / "logs").mkdir(parents=True, exist_ok=True)
        (runtime_root / "cache").mkdir(parents=True, exist_ok=True)
        # artifacts/<version_hash>/<encoded_probe_path> created on demand by platform
        # Apply built-in template (copies config + optional sample data)
        if template:
            config_dest = self._apply_template(project_path, project_id, template)
            base_config_path = f"template:{template}"

        # Copy base configuration if provided
        if (not template) and base_config_path and Path(base_config_path).exists():
            config_dest = project_path / "configs" / "project_config.yaml"
            shutil.copy2(base_config_path, config_dest)
        # Build in-memory metadata from filesystem; no project_info.json persists.
        project_info = self._build_project_info_from_fs(project_id, project_path)
        project_info["description"] = description
        project_info["base_config_path"] = base_config_path

        # Write/merge project .gitignore so runtime state and basics are ignored
        gitignore_contents = DEFAULT_PROJECT_GITIGNORE.replace("<PROJECT_ID>", project_id)
        gitignore_path = project_path / ".gitignore"
        if gitignore_path.exists():
            try:
                existing = gitignore_path.read_text(encoding="utf-8")
            except Exception:
                existing = ""
            # Append only missing lines; don't overwrite user content.
            existing_lines = {ln.strip() for ln in existing.splitlines() if ln.strip()}
            to_add = []
            for ln in gitignore_contents.splitlines():
                s = ln.strip()
                if not s:
                    continue
                if s not in existing_lines:
                    to_add.append(ln)
            if to_add:
                try:
                    sep = "\n" if existing.endswith("\n") or existing == "" else "\n"
                    gitignore_path.write_text(existing + sep + "\n".join(to_add) + "\n", encoding="utf-8")
                except Exception:
                    pass
        else:
            gitignore_path.write_text(gitignore_contents, encoding="utf-8")

        print(f"✅ Project '{project_id}' created successfully at: {project_path}")
        return project_info
    
    def delete_project(self, project_id: str, confirm: bool = False) -> bool:
        """
        Delete a project and all its associated data.
        
        Args:
            project_id: Project to delete
            confirm: If True, skip confirmation prompt
            
        Returns:
            True if project was deleted, False otherwise
        """
        if not self.project_exists(project_id):
            print(f"❌ Project '{project_id}' does not exist")
            return False
        
        project_path = self.get_project_path(project_id)
        
        if not confirm:
            response = input(f"⚠️  Are you sure you want to delete project '{project_id}' and all its data? [y/N]: ")
            if response.lower() != 'y':
                print("❌ Project deletion cancelled")
                return False
        
        # Remove project directory
        shutil.rmtree(project_path)
        
        print(f"✅ Project '{project_id}' deleted successfully")
        return True
    
    def project_exists(self, project_id: str) -> bool:
        """Check if a project exists."""
        return self._is_project_dir(self._project_path(project_id))
    
    def get_project_path(self, project_id: str) -> Path:
        """Get the path to a project."""
        if not self.project_exists(project_id):
            raise ValueError(f"Project '{project_id}' does not exist")
        return self._project_path(project_id)
    
    def list_projects(self) -> List[Dict[str, Any]]:
        """List all projects."""
        projects: List[Dict[str, Any]] = []
        try:
            candidates = sorted(self.projects_root.iterdir())
        except Exception:
            candidates = []

        for project_dir in candidates:
            if not self._is_project_dir(project_dir):
                continue
            project_id = project_dir.name
            try:
                projects.append(self._build_project_info_from_fs(project_id, project_dir))
            except Exception as e:
                print(f"Warning: Could not build info for project '{project_id}': {e}")

        return projects
    
    def get_project_info(self, project_id: str) -> Dict[str, Any]:
        """Get detailed information about a project."""
        if not self.project_exists(project_id):
            raise ValueError(f"Project '{project_id}' does not exist")

        project_path = self.get_project_path(project_id)
        return self._build_project_info_from_fs(project_id, project_path)
    
    def update_project_config(self, project_id: str, config_updates: Dict[str, Any]) -> None:
        """Update project configuration."""
        if not self.project_exists(project_id):
            raise ValueError(f"Project '{project_id}' does not exist")
        
        project_path = self.get_project_path(project_id)
        config_file = project_path / "configs" / "project_config.yaml"
        
        # Load existing config or create new one
        if config_file.exists():
            with open(config_file, 'r') as f:
                config = yaml.safe_load(f) or {}
        else:
            config = {}
        
        # Deep merge config updates
        self._deep_merge(config, config_updates)
        
        # Save updated config
        with open(config_file, 'w') as f:
            yaml.dump(config, f, default_flow_style=False)
        
        print(f"✅ Project '{project_id}' configuration updated")
    
    def _deep_merge(self, base_dict: Dict[str, Any], update_dict: Dict[str, Any]) -> None:
        """Deep merge two dictionaries."""
        for key, value in update_dict.items():
            if key in base_dict and isinstance(base_dict[key], dict) and isinstance(value, dict):
                self._deep_merge(base_dict[key], value)
            else:
                base_dict[key] = value
    
    def get_project_config_path(self, project_id: str) -> Path:
        """Get the path to project's active configuration."""
        if not self.project_exists(project_id):
            raise ValueError(f"Project '{project_id}' does not exist")
        
        project_path = self.get_project_path(project_id)
        config_file = project_path / "configs" / "project_config.yaml"
        
        return config_file
    
    def add_run_to_project(self, project_id: str, run_id: str, config_hash: str) -> None:
        """
        Add a run record to the project.

        This method is retained for backwards compatibility but no longer writes
        project-level metadata to disk. Run history is tracked via KV backends
        used by adapters and the web UI.
        """
        if not self.project_exists(project_id):
            raise ValueError(f"Project '{project_id}' does not exist")
        # No-op on purpose: callers should rely on KV-backed run tracking.