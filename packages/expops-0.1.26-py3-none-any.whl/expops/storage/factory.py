from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Mapping, Optional


def _as_int(val: Any) -> Optional[int]:
    if val is None or val == "":
        return None
    try:
        return int(val)
    except Exception:
        return None


def _norm_backend_type(value: Any) -> str:
    try:
        s = str(value or "").strip().lower()
    except Exception:
        return ""
    aliases = {
        "sqlite": "local",
        "firestore": "gcp",
    }
    return aliases.get(s, s)


def _resolve_relative_path(
    raw: Any,
    *,
    workspace_root: Optional[Path] = None,
    project_root: Optional[Path] = None,
) -> Optional[Path]:
    if not raw:
        return None
    try:
        p = Path(str(raw))
    except Exception:
        return None
    if p.is_absolute():
        return p
    candidates: list[Path] = []
    if project_root is not None:
        candidates.append(project_root / p)
    if workspace_root is not None:
        candidates.append(workspace_root / p)
    candidates.append(Path.cwd() / p)
    for c in candidates:
        try:
            if c.exists():
                return c.resolve()
        except Exception:
            continue
    # Fall back to the most likely base for debugging purposes.
    return (candidates[0] if candidates else p)


def _maybe_apply_gcp_env(backend_cfg: dict[str, Any], *, workspace_root: Optional[Path], project_root: Optional[Path]) -> None:
    """Best-effort: export GCP env vars from backend config if present.

    This mirrors existing behavior across the codebase and ensures that Firestore/GCS
    SDKs can locate credentials when chart subprocesses or web server runs separately.
    """
    try:
        import os

        creds_rel = backend_cfg.get("credentials_json")
        if creds_rel:
            p = _resolve_relative_path(creds_rel, workspace_root=workspace_root, project_root=project_root)
            # If an explicit credentials file is configured, prefer it. Avoid
            # overriding a valid, existing env var path, but do override when the
            # current env var is missing or points at a non-existent file.
            try:
                existing = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS")
                existing_ok = bool(existing and Path(existing).expanduser().exists())
            except Exception:
                existing_ok = False
            try:
                cfg_ok = bool(p and p.exists())
            except Exception:
                cfg_ok = False
            if cfg_ok and not existing_ok:
                os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = str(p)

        gcp_project = backend_cfg.get("gcp_project") or os.environ.get("GOOGLE_CLOUD_PROJECT")
        # If project is provided in config, prefer it over ambient env.
        if backend_cfg.get("gcp_project"):
            os.environ["GOOGLE_CLOUD_PROJECT"] = str(backend_cfg.get("gcp_project"))
        elif gcp_project and not os.environ.get("GOOGLE_CLOUD_PROJECT"):
            os.environ.setdefault("GOOGLE_CLOUD_PROJECT", str(gcp_project))

        emulator_host = backend_cfg.get("emulator_host")
        if emulator_host:
            os.environ["FIRESTORE_EMULATOR_HOST"] = str(emulator_host)
    except Exception:
        return


def create_kv_store(
    project_id: str,
    backend_cfg: Optional[dict[str, Any]] = None,
    *,
    env: Optional[Mapping[str, str]] = None,
    workspace_root: Optional[Path] = None,
    project_root: Optional[Path] = None,
) -> Any:
    """Create a KV store instance (Redis, GCP Firestore/PubSub, or local SQLite).

    Precedence:
    - `MLOPS_KV_BACKEND` env override (if set)
    - `backend_cfg['type']` from config
    - default: local (SQLite). Safe fallback on creation failure: in-memory.
    """
    from expops.storage.adapters.memory_store import InMemoryStore

    cfg = backend_cfg if isinstance(backend_cfg, dict) else {}
    logger = logging.getLogger(__name__)

    def _env_get(key: str) -> Optional[str]:
        try:
            if env is not None:
                v = env.get(key)
                return str(v) if v is not None else None
            import os
            return os.environ.get(key)
        except Exception:
            return None

    def _default_local_path() -> Path:
        base = project_root
        if base is None:
            try:
                base = (workspace_root / project_id) if workspace_root else None
            except Exception:
                base = None
        if base is None:
            base = Path.cwd() / project_id
        return base / f".{project_id}" / "metrics.sqlite"

    env_backend = _env_get("MLOPS_KV_BACKEND")
    backend_source = "env" if env_backend else "config"
    backend_type = _norm_backend_type(env_backend or cfg.get("type") or "")
    if not backend_type:
        backend_source = "default"
        backend_type = "local"
    logger.info(
        "KV backend resolution project_id=%s source=%s backend=%s",
        project_id,
        backend_source,
        backend_type,
    )

    if backend_type == "local":
        try:
            from expops.storage.adapters.sqlite_store import SQLiteStore

            raw_path = _env_get("MLOPS_KV_PATH") or cfg.get("path") or cfg.get("db_path")
            if raw_path:
                resolved = _resolve_relative_path(raw_path, workspace_root=workspace_root, project_root=project_root)
                db_path = str(resolved) if resolved is not None else str(raw_path)
            else:
                db_path = str(_default_local_path())
            return SQLiteStore(project_id, db_path)
        except Exception as e:
            logger.warning("KV backend local init failed; falling back to in-memory: %s", e)
            return InMemoryStore(project_id)

    if backend_type == "redis":
        try:
            from expops.storage.adapters.redis_store import RedisStore

            host = _env_get("MLOPS_REDIS_HOST") or cfg.get("host")
            port = _as_int(_env_get("MLOPS_REDIS_PORT") or cfg.get("port"))
            db = _as_int(_env_get("MLOPS_REDIS_DB") or cfg.get("db"))
            password = _env_get("MLOPS_REDIS_PASSWORD") or cfg.get("password")
            return RedisStore(project_id=project_id, host=host, port=port, db=db, password=password)
        except Exception as e:
            logger.warning("KV backend redis init failed; falling back to in-memory: %s", e)
            return InMemoryStore(project_id)

    if backend_type == "gcp":
        # GCP backend requires at least minimal explicit configuration. When neither
        # backend config nor the provided env mapping contains GCP identifiers, we
        # fall back to an in-memory store instead of attempting a best-effort GCP
        # connection that may depend on ambient machine state.
        try:
            from expops.storage.adapters.gcp_kv_store import GCPStore
        except Exception as e:
            logger.warning("KV backend gcp unavailable; falling back to in-memory: %s", e)
            return InMemoryStore(project_id)

        env_map: Mapping[str, str] = {}
        try:
            env_map = dict(env or {})
        except Exception:
            env_map = {}

        gcp_project = cfg.get("gcp_project") or env_map.get("GOOGLE_CLOUD_PROJECT")
        emulator_host = cfg.get("emulator_host") or env_map.get("FIRESTORE_EMULATOR_HOST")
        if not gcp_project and not emulator_host:
            logger.warning(
                "KV backend gcp requested but missing gcp_project/emulator_host; falling back to in-memory"
            )
            return InMemoryStore(project_id)

        try:
            _maybe_apply_gcp_env(cfg, workspace_root=workspace_root, project_root=project_root)
            return GCPStore(
                project_id=project_id,
                gcp_project=gcp_project,
                emulator_host=emulator_host,
            )
        except Exception as e:
            logger.warning("KV backend gcp init failed; falling back to in-memory: %s", e)
            return InMemoryStore(project_id)

    # Unknown type: fall back safely.
    logger.warning("Unknown KV backend '%s'; falling back to in-memory", backend_type)
    return InMemoryStore(project_id)


def create_object_store(
    cache_cfg: Optional[dict[str, Any]] = None,
    *,
    env: Optional[Mapping[str, str]] = None,
    project_id: Optional[str] = None,
) -> Any:
    """Create an object store instance for cache artifacts (currently GCS only).

    The layout within the bucket is standardized by higher-level components
    (for example, StepStateManager) using the provided `project_id`. Prefix
    values in config or environment variables are intentionally ignored.
    """
    cfg = cache_cfg if isinstance(cache_cfg, dict) else {}
    store_cfg = cfg.get("object_store") if isinstance(cfg.get("object_store"), dict) else {}
    if store_cfg.get("prefix") is not None:
        logging.getLogger(__name__).warning(
            "object_store.prefix is deprecated and ignored; layout is controlled by StepStateManager"
        )
    store_type = _norm_backend_type(store_cfg.get("type") or "")

    def _env_get(key: str) -> Optional[str]:
        try:
            if env is not None:
                v = env.get(key)
                return str(v) if v is not None else None
            import os
            return os.environ.get(key)
        except Exception:
            return None

    if store_type == "gcs":
        bucket = store_cfg.get("bucket") or _env_get("MLOPS_GCS_BUCKET")
        if not bucket:
            return None
        try:
            from expops.storage.adapters.gcs_object_store import GCSObjectStore

            # Do not pass a prefix here; StepStateManager/object_prefix control
            # the cache layout (for example, <project_id>/cache/steps/...).
            return GCSObjectStore(bucket=str(bucket))
        except Exception:
            return None

    return None


__all__ = [
    "create_kv_store",
    "create_object_store",
]


