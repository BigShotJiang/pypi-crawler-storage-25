from __future__ import annotations

from typing import Any, Dict, Optional
from pathlib import Path
import json
import sqlite3
import time

from ..interfaces.kv_store import KeyValueEventStore
from ..path_utils import encode_probe_path, decode_probe_path


class SQLiteStore(KeyValueEventStore):
    """SQLite-backed KV store for local persistence."""

    def __init__(self, project_id: str, db_path: str, busy_timeout_ms: int = 5000) -> None:
        self.project_id = project_id
        self.db_path = Path(db_path)
        try:
            self.busy_timeout_ms = int(busy_timeout_ms)
        except Exception:
            self.busy_timeout_ms = 5000
        self._ensure_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            str(self.db_path),
            timeout=float(self.busy_timeout_ms) / 1000.0,
            check_same_thread=False,
        )
        try:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            conn.execute("PRAGMA busy_timeout = ?;", (self.busy_timeout_ms,))
        except Exception:
            pass
        return conn

    def _ensure_db(self) -> None:
        try:
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        try:
            with self._connect() as conn:
                conn.execute(
                    "CREATE TABLE IF NOT EXISTS kv ("
                    "key TEXT PRIMARY KEY, "
                    "value TEXT, "
                    "updated_at REAL"
                    ")"
                )
                conn.execute("CREATE INDEX IF NOT EXISTS idx_kv_updated_at ON kv(updated_at)")
                conn.commit()
        except Exception:
            pass

    def _json_set(self, key: str, value: Any) -> None:
        payload = json.dumps(value, default=str)
        now = time.time()
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO kv (key, value, updated_at) VALUES (?, ?, ?)",
                (key, payload, now),
            )
            conn.commit()

    def _json_get(self, key: str) -> Optional[Any]:
        with self._connect() as conn:
            row = conn.execute("SELECT value FROM kv WHERE key = ?", (key,)).fetchone()
        if not row:
            return None
        try:
            return json.loads(row[0]) if row[0] is not None else None
        except Exception:
            return None

    def _scan_prefix(self, prefix: str) -> Dict[str, Any]:
        pattern = f"{prefix}%"
        with self._connect() as conn:
            rows = conn.execute("SELECT key, value FROM kv WHERE key LIKE ?", (pattern,)).fetchall()
        out: Dict[str, Any] = {}
        for key, value in rows:
            try:
                out[str(key)] = json.loads(value) if value is not None else None
            except Exception:
                out[str(key)] = None
        return out

    def _fetch_keys(self, keys: list[str]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        if not keys:
            return out
        with self._connect() as conn:
            chunk_size = 900
            for i in range(0, len(keys), chunk_size):
                chunk = keys[i : i + chunk_size]
                placeholders = ",".join(["?"] * len(chunk))
                rows = conn.execute(
                    f"SELECT key, value FROM kv WHERE key IN ({placeholders})",
                    chunk,
                ).fetchall()
                for key, value in rows:
                    try:
                        out[str(key)] = json.loads(value) if value is not None else None
                    except Exception:
                        out[str(key)] = None
        return out

    # Cache indices
    def set_step_cache_record(
        self,
        process_name: str,
        step_name: str,
        input_hash: str,
        config_hash: str,
        function_hash: Optional[str],
        record: Dict[str, Any],
        ttl_seconds: Optional[int] = None,
    ) -> None:
        key = f"steps:{process_name}:{step_name}:{input_hash}:{config_hash}:{function_hash or 'none'}"
        self._json_set(key, record)

    def get_step_cache_path(
        self,
        process_name: str,
        step_name: str,
        input_hash: Optional[str],
        config_hash: Optional[str],
        function_hash: Optional[str],
    ) -> Optional[str]:
        if not input_hash or not config_hash:
            return None
        key = f"steps:{process_name}:{step_name}:{input_hash}:{config_hash}:{function_hash or 'none'}"
        rec = self._json_get(key)
        if rec and rec.get("status") in ("completed", "cached") and rec.get("cache_path"):
            return rec["cache_path"]
        return None

    def get_step_cache_record(
        self,
        process_name: str,
        step_name: str,
        input_hash: Optional[str],
        config_hash: Optional[str],
        function_hash: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        if not input_hash or not config_hash:
            return None
        key = f"steps:{process_name}:{step_name}:{input_hash}:{config_hash}:{function_hash or 'none'}"
        rec = self._json_get(key)
        return rec if isinstance(rec, dict) else None

    def set_process_cache_record(
        self,
        process_name: str,
        input_hash: str,
        config_hash: str,
        function_hash: Optional[str],
        record: Dict[str, Any],
        ttl_seconds: Optional[int] = None,
    ) -> None:
        key = f"process:{process_name}:{input_hash}:{config_hash}:{function_hash or 'none'}"
        self._json_set(key, record)

    def get_process_cache_path(
        self,
        process_name: str,
        input_hash: Optional[str],
        config_hash: Optional[str],
        function_hash: Optional[str],
    ) -> Optional[str]:
        if not input_hash or not config_hash:
            return None
        key = f"process:{process_name}:{input_hash}:{config_hash}:{function_hash or 'none'}"
        rec = self._json_get(key)
        if rec and rec.get("status") in ("completed", "cached") and rec.get("cache_path"):
            return rec["cache_path"]
        return None

    def get_process_cache_record(
        self,
        process_name: str,
        input_hash: Optional[str],
        config_hash: Optional[str],
        function_hash: Optional[str],
    ) -> Optional[Dict[str, Any]]:
        if not input_hash or not config_hash:
            return None
        key = f"process:{process_name}:{input_hash}:{config_hash}:{function_hash or 'none'}"
        rec = self._json_get(key)
        return rec if isinstance(rec, dict) else None

    def get_process_cache_paths_batch(
        self,
        lookups: list[tuple[str, Optional[str], Optional[str], Optional[str]]],
    ) -> dict[str, Optional[str]]:
        out: dict[str, Optional[str]] = {}
        keys: list[str] = []
        key_map: dict[str, str] = {}
        for process_name, ih, ch, fh in lookups or []:
            fhash = (fh or "none") if (ih and ch) else (fh or "none")
            comp = f"{process_name}|{ih}|{ch}|{fhash}"
            if not ih or not ch:
                out[comp] = None
                continue
            key = f"process:{process_name}:{ih}:{ch}:{fhash}"
            keys.append(key)
            key_map[key] = comp
        if not keys:
            return out
        records = self._fetch_keys(keys)
        for key, comp in key_map.items():
            rec = records.get(key)
            if rec and rec.get("status") in ("completed", "cached") and rec.get("cache_path"):
                out[comp] = rec.get("cache_path")
            else:
                out[comp] = None
        return out

    # Run lifecycle + metrics
    def mark_pipeline_started(self, run_id: str) -> None:
        self._json_set(f"runs:{run_id}:status", "running")
        self._json_set(f"runs:{run_id}:timestamps", {"start": time.time(), "end": None})

    def mark_pipeline_completed(self, run_id: str, success: bool) -> None:
        status = "completed" if success else "failed"
        self._json_set(f"runs:{run_id}:status", status)
        self._json_set(f"runs:{run_id}:timestamps", {"start": None, "end": time.time()})

    def get_run_status(self, run_id: str) -> Optional[str]:
        status = self._json_get(f"runs:{run_id}:status")
        if status is None:
            return None
        try:
            return str(status).lower()
        except Exception:
            return None

    # Per-run step bookkeeping
    def record_run_step(self, run_id: str, process_name: str, step_name: str, record: Dict[str, Any]) -> None:
        self._json_set(f"runs:{run_id}:steps:{process_name}:{step_name}", record)

    def list_run_steps(self, run_id: str) -> Dict[str, Dict[str, Any]]:
        prefix = f"runs:{run_id}:steps:"
        items = self._scan_prefix(prefix)
        out: Dict[str, Dict[str, Any]] = {}
        for key, val in items.items():
            try:
                _, _, _, process, step = key.split(":", 4)
                out[f"{process}.{step}"] = val if isinstance(val, dict) else {}
            except Exception:
                continue
        return out

    # Stats
    def increment_stat(self, run_id: str, name: str, amount: int = 1) -> None:
        hkey = f"runs:{run_id}:stats:{name}"
        current = self._json_get(hkey)
        try:
            cur_val = int(current or 0)
        except Exception:
            cur_val = 0
        self._json_set(hkey, cur_val + int(amount))

    def get_pipeline_stats(self, run_id: str) -> Dict[str, Any]:
        prefix = f"runs:{run_id}:stats:"
        items = self._scan_prefix(prefix)
        out: Dict[str, Any] = {}
        for key, val in items.items():
            try:
                metric = key[len(prefix) :]
                out[metric] = int(val)
            except Exception:
                continue
        return out

    # Charts index
    def record_run_chart_artifacts(self, run_id: str, chart_name: str, artifacts: list[dict[str, Any]]) -> None:
        idx_key = f"runs:{run_id}:charts:{chart_name}"
        self._json_set(idx_key, {"items": artifacts})

    def list_run_charts(self, run_id: str) -> Dict[str, Any]:
        prefix = f"runs:{run_id}:charts:"
        items = self._scan_prefix(prefix)
        out: Dict[str, Any] = {}
        for key, data in items.items():
            name = key[len(prefix) :]
            payload = data if isinstance(data, dict) else {}
            items_list = payload.get("items", []) if isinstance(payload, dict) else []
            ctype = None
            try:
                if isinstance(items_list, list) and items_list and isinstance(items_list[0], dict):
                    ctype = items_list[0].get("chart_type")
            except Exception:
                ctype = None
            out[name] = {"type": (ctype or "static"), "items": items_list}
        return out

    def copy_run_chart_artifacts(self, from_run_id: str, to_run_id: str, chart_name: str) -> bool:
        from_key = f"runs:{from_run_id}:charts:{chart_name}"
        from_data = self._json_get(from_key)
        if not from_data:
            return False
        to_key = f"runs:{to_run_id}:charts:{chart_name}"
        self._json_set(to_key, from_data)
        return True

    # Probe metrics
    def save_probe_metrics_by_path(self, run_id: str, probe_path: str, metrics: Dict[str, Any]) -> None:
        enc = encode_probe_path(probe_path)
        self._json_set(f"metric:{run_id}:probe_path:{enc}", metrics)

    def get_probe_metrics_by_path(self, run_id: str, probe_path: str) -> Dict[str, Any]:
        enc = encode_probe_path(probe_path)
        data = self._json_get(f"metric:{run_id}:probe_path:{enc}")
        return data if isinstance(data, dict) else {}

    def list_probe_paths(self, run_id: str) -> list[str]:
        prefix = f"metric:{run_id}:probe_path:"
        pattern = f"{prefix}%"
        try:
            with self._connect() as conn:
                rows = conn.execute("SELECT key FROM kv WHERE key LIKE ?", (pattern,)).fetchall()
        except Exception:
            rows = []
        out: list[str] = []
        seen: set[str] = set()
        for (key,) in rows:
            try:
                key_str = str(key)
                if not key_str.startswith(prefix):
                    continue
                enc = key_str[len(prefix) :]
                if not enc:
                    continue
                try:
                    path = decode_probe_path(enc)
                except Exception:
                    path = enc
                if path not in seen:
                    seen.add(path)
                    out.append(path)
            except Exception:
                continue
        return out

    # Run listing (for UI)
    def list_runs(self, limit: int = 100) -> list[str]:
        pattern = "runs:%:status"
        with self._connect() as conn:
            rows = conn.execute("SELECT key FROM kv WHERE key LIKE ? ORDER BY updated_at DESC", (pattern,)).fetchall()
        ids: list[str] = []
        for (key,) in rows:
            try:
                k = str(key)
                rid = k[len("runs:") : -len(":status")]
                ids.append(rid)
            except Exception:
                continue
        return ids[:limit]
