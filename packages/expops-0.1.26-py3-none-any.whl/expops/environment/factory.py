from __future__ import annotations

from typing import Any

from .base import EnvironmentManager
from .conda_manager import CondaEnvironmentManager
from .venv_manager import VenvEnvironmentManager
from .system_manager import SystemEnvironmentManager
from .pyenv_manager import PyenvEnvironmentManager


class EnvironmentManagerFactory:
    """Factory for creating environment managers based on configuration."""
    
    _managers: dict[str, type[EnvironmentManager]] = {
        "conda": CondaEnvironmentManager,
        "venv": VenvEnvironmentManager,
        "virtualenv": VenvEnvironmentManager,
        "pyenv": PyenvEnvironmentManager,
        "system": SystemEnvironmentManager,
    }
    
    @classmethod
    def create_environment_manager(cls, platform_config: dict[str, Any]) -> EnvironmentManager:
        """Create an environment manager based on the platform configuration."""
        env_config = platform_config.get("environment")
        if not isinstance(env_config, dict) or not env_config:
            return SystemEnvironmentManager({})

        if cls._has_mixed_env_map(env_config):
            raise ValueError(
                "Environment section mixes legacy and new formats. "
                "Use consistent format: name: { env_type: [requirements_path, ...] } "
                "or legacy: name: [requirements_path, environment_type]"
            )
        if cls._is_env_map(env_config):
            env_map, default_name = cls._build_env_map(env_config)
            if default_name and default_name in env_map:
                return env_map[default_name]
            return SystemEnvironmentManager({})

        env_type, env_specific_config = cls._select_manager(env_config)
        manager_class = cls._managers.get(env_type)
        if manager_class is None:
            raise ValueError(
                f"Unsupported environment type: {env_type}. Supported types: {sorted(cls._managers.keys())}"
            )
        return manager_class(env_specific_config)

    @classmethod
    def create_environment_managers(cls, platform_config: dict[str, Any]) -> tuple[dict[str, EnvironmentManager], str | None]:
        """Create environment managers for all configured environments."""
        env_config = platform_config.get("environment")
        if not isinstance(env_config, dict) or not env_config:
            manager = SystemEnvironmentManager({})
            name = manager.get_environment_name()
            return {name: manager}, name

        if cls._has_mixed_env_map(env_config):
            raise ValueError(
                "Environment section mixes legacy and new formats. "
                "Use consistent format: name: { env_type: [requirements_path, ...] } "
                "or legacy: name: [requirements_path, environment_type]"
            )
        if cls._is_env_map(env_config):
            return cls._build_env_map(env_config)

        # Legacy single-environment fallback
        manager = cls.create_environment_manager(platform_config)
        name = manager.get_environment_name()
        return {name: manager}, name

    @classmethod
    def _select_manager(cls, env_config: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        # Primary form (legacy):
        #   environment: { venv: {...} } or { conda: {...} } etc.
        for supported_type in cls._managers:
            if supported_type in env_config:
                raw = env_config.get(supported_type)
                return supported_type, raw if isinstance(raw, dict) else {}

        # Legacy fallbacks where `environment:` contains the manager's config directly.
        if any(k in env_config for k in ("environment_file",)):
            return "conda", env_config
        if any(k in env_config for k in ("requirements_file",)):
            return "venv", env_config

        return "system", env_config

    @classmethod
    def _is_env_map(cls, env_config: dict[str, Any]) -> bool:
        """Check if config uses the new nested dict format: env_name: { env_type: [...] }"""
        if not isinstance(env_config, dict) or not env_config:
            return False
        for value in env_config.values():
            # New format: value is a dict with env_type keys mapping to lists
            if isinstance(value, dict):
                # Check if it's a single-key dict with a list value
                if len(value) == 1:
                    env_type_key = next(iter(value.keys()))
                    if env_type_key in cls._managers:
                        list_value = value[env_type_key]
                        if isinstance(list_value, (list, tuple)) and len(list_value) > 0:
                            return True
        return False

    @classmethod
    def _has_mixed_env_map(cls, env_config: dict[str, Any]) -> bool:
        """Detect mixing of old list format and new dict format."""
        if not isinstance(env_config, dict) or not env_config:
            return False
        has_list_format = False
        has_dict_format = False
        for value in env_config.values():
            if isinstance(value, dict) and len(value) == 1:
                env_type_key = next(iter(value.keys()))
                if env_type_key in cls._managers:
                    has_dict_format = True
        return has_list_format and has_dict_format

    @classmethod
    def _build_env_map(
        cls, env_config: dict[str, Any]
    ) -> tuple[dict[str, EnvironmentManager], str | None]:
        env_map: dict[str, EnvironmentManager] = {}
        default_name: str | None = None
        for raw_name, raw_value in env_config.items():
            name = str(raw_name)
            if default_name is None:
                default_name = name
            
            # New format: env_name: { env_type: [requirements_path, ...] }
            if isinstance(raw_value, dict):
                if len(raw_value) != 1:
                    raise ValueError(
                        f"Environment '{name}' must have exactly one environment type key. "
                        f"Format: {name}: {{ env_type: [requirements_path, ...] }}"
                    )
                env_type = next(iter(raw_value.keys()))
                env_type = str(env_type).strip().lower()
                args_list = raw_value[env_type]
                
                if not isinstance(args_list, (list, tuple)) or len(args_list) == 0:
                    raise ValueError(
                        f"Environment '{name}' must have a non-empty list of arguments. "
                        f"Format: {name}: {{ {env_type}: [requirements_path, ...] }}"
                    )
                req_path = args_list[0]
                
            # Old format: env_name: [requirements_path, env_type] (for backward compatibility)
            elif isinstance(raw_value, (list, tuple)):
                if len(raw_value) != 2:
                    raise ValueError(
                        f"Legacy format requires a two-item list: "
                        f"[requirements_path, environment_type]. "
                        f"New format: {name}: {{ env_type: [requirements_path, ...] }}"
                    )
                req_path = raw_value[0]
                env_type = str(raw_value[1]).strip().lower()
            else:
                raise ValueError(
                    f"Environment '{name}' must be either a dict {{ env_type: [...] }} "
                    f"or a legacy list [requirements_path, env_type]."
                )
            
            if not env_type:
                raise ValueError(f"Environment type missing for '{name}'.")
            
            manager_class = cls._managers.get(env_type)
            if manager_class is None:
                raise ValueError(
                    f"Unsupported environment type: {env_type}. Supported types: {sorted(cls._managers.keys())}"
                )
            config: dict[str, Any] = {"name": name}
            if env_type == "conda":
                if not req_path:
                    raise ValueError(f"Conda environment '{name}' requires an environment file path.")
                config["environment_file"] = req_path
            else:
                if not req_path:
                    raise ValueError(f"Environment '{name}' requires a requirements file path.")
                config["requirements_file"] = req_path
            env_map[name] = manager_class(config)
        return env_map, default_name
    
    @classmethod
    def list_supported_types(cls) -> list[str]:
        """List all supported environment types."""
        return list(cls._managers.keys())
    
    @classmethod
    def register_manager(cls, env_type: str, manager_class: type[EnvironmentManager]) -> None:
        """Register a new environment manager type."""
        if not issubclass(manager_class, EnvironmentManager):
            raise ValueError(f"Manager class must inherit from EnvironmentManager")
        cls._managers[env_type] = manager_class


def create_environment_manager(platform_config: dict[str, Any]) -> EnvironmentManager:
    """Convenience function to create an environment manager."""
    return EnvironmentManagerFactory.create_environment_manager(platform_config) 


def create_environment_managers(platform_config: dict[str, Any]) -> tuple[dict[str, EnvironmentManager], str | None]:
    """Convenience function to create environment managers."""
    return EnvironmentManagerFactory.create_environment_managers(platform_config)