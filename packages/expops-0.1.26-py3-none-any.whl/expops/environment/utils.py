from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import Any

from expops.core.workspace import get_workspace_root, get_projects_root


def _read_requirement_lines(path: Path) -> list[str]:
    lines: list[str] = []
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            lines.append(line)
    return lines


def resolve_env_path(raw_path: str | Path) -> Path:
    """Resolve an environment file path using project root when available.

    Resolution order for relative paths:
    1) <projects_root>/<MLOPS_PROJECT_ID>/<raw_path> (when project id is set)
    2) Path.cwd() / raw_path  (backwards-compatible fallback)
    Absolute paths are returned as-is.
    """
    path = Path(raw_path)
    if path.is_absolute():
        return path

    candidates: list[Path] = []

    # Project-root-aware resolution when running inside a project.
    try:
        project_id = os.environ.get("MLOPS_PROJECT_ID") or ""
        if project_id:
            try:
                workspace_root = get_workspace_root()
            except Exception:
                workspace_root = Path.cwd()
            try:
                projects_root = get_projects_root(workspace_root)
            except Exception:
                projects_root = workspace_root
            candidates.append(projects_root / project_id / path)
    except Exception:
        pass

    # Backwards-compatible fallback: relative to current working directory.
    candidates.append(Path.cwd() / path)

    for cand in candidates:
        try:
            if cand.exists():
                return cand
        except Exception:
            continue

    # If nothing exists yet, return the first candidate so callers can surface
    # a consistent FileNotFoundError with the most likely intended path.
    return candidates[0]


def load_requirements(config: dict[str, Any]) -> list[str]:
    """Load pip-style requirements from a config dict.
    
    Supported keys:
    - `requirements_file`: path to a requirements.txt file
    """
    if "requirements" in config:
        raise ValueError(
            "Inline requirements are no longer supported. "
            "Use 'requirements_file' to point to a requirements.txt file."
        )

    req_file = config.get("requirements_file")
    if req_file:
        path = resolve_env_path(str(req_file))
        if not path.exists():
            raise FileNotFoundError(f"Requirements file not found: {path}")
        return _read_requirement_lines(path)

    return []


_NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+")


def requirement_to_package_name(requirement: str) -> str:
    """Best-effort extract a package name for `pip show` from a requirement spec."""
    s = str(requirement).strip()
    if not s:
        return ""

    # Handle "name @ url"
    if "@" in s and not s.startswith("@"):
        s = s.split("@", 1)[0].strip()

    # Strip environment markers (PEP 508)
    if ";" in s:
        s = s.split(";", 1)[0].strip()

    # Strip extras
    if "[" in s:
        s = s.split("[", 1)[0].strip()

    # Strip version specifiers (common cases)
    for op in ("===", "==", ">=", "<=", "!=", "~=", ">", "<", "="):
        if op in s:
            s = s.split(op, 1)[0].strip()
            break

    m = _NAME_RE.match(s)
    return m.group(0) if m else s


def verify_pip_requirements(python_exec: str, requirements: list[str]) -> tuple[bool, list[str]]:
    """Return (ok, missing_packages) using `pip show`."""
    missing: list[str] = []
    for req in requirements or []:
        name = requirement_to_package_name(req)
        if not name:
            continue
        try:
            subprocess.check_output(
                [python_exec, "-m", "pip", "show", name],
                text=True,
                stderr=subprocess.DEVNULL,
            )
        except subprocess.CalledProcessError:
            missing.append(name)
        except FileNotFoundError:
            missing.append(name)
    return (len(missing) == 0), missing


