from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from expops.core.workspace import (
    get_workspace_root,
    get_projects_root,
    get_project_runtime_root,
)

from .base import EnvironmentManager
from .utils import load_requirements, verify_pip_requirements


class VenvEnvironmentManager(EnvironmentManager):
    """Standard Python venv-based environment management."""
    
    def __init__(self, config: dict[str, Any]):
        super().__init__(config)
        self.requirements = load_requirements(config)
        
        env_name = config.get("name")
        if not env_name:
            raise ValueError(
                "Virtual environment name must be explicitly specified in the configuration. "
                "Please add 'name' field under 'environment.venv' in your config file."
            )
        self.environment_name = env_name

        # Prefer per-project runtime `envs/` directory when running inside a project;
        # fall back to a workspace-level `.venvs/` folder only for non-project usage.
        project_root: Path | None = None
        runtime_root: Path | None = None
        try:
            project_id = os.environ.get("MLOPS_PROJECT_ID") or ""
            if project_id:
                try:
                    workspace_root = get_workspace_root()
                except Exception:
                    workspace_root = Path.cwd()
                try:
                    projects_root = get_projects_root(workspace_root)
                except Exception:
                    projects_root = workspace_root
                project_root = projects_root / project_id
                try:
                    runtime_root = get_project_runtime_root(project_root, project_id)
                except Exception:
                    runtime_root = project_root / f".{project_id}"
        except Exception:
            project_root = None
            runtime_root = None

        if runtime_root is not None:
            preferred_path = runtime_root / "envs" / self.environment_name
        else:
            try:
                workspace_root = get_workspace_root()
            except Exception:
                workspace_root = Path.cwd()
            preferred_path = workspace_root / ".venvs" / self.environment_name

        cache_path = Path.home() / ".cache" / "expops-platform" / "venvs" / self.environment_name
        legacy_cache_path = Path.home() / ".cache" / "mlops-platform" / "venvs" / self.environment_name

        if self._python_path(preferred_path).exists():
            self.venv_path = preferred_path
        elif self._python_path(cache_path).exists():
            self.venv_path = cache_path
        elif self._python_path(legacy_cache_path).exists():
            self.venv_path = legacy_cache_path
        else:
            self.venv_path = preferred_path if self._ensure_writable_dir(preferred_path.parent) else cache_path

    @staticmethod
    def _python_path(venv_path: Path) -> Path:
        if os.name == "nt":
            return venv_path / "Scripts" / "python.exe"
        return venv_path / "bin" / "python"

    @staticmethod
    def _ensure_writable_dir(dir_path: Path) -> bool:
        try:
            dir_path.mkdir(parents=True, exist_ok=True)
            probe = dir_path / ".mlops_write_probe"
            probe.write_text("", encoding="utf-8")
            probe.unlink(missing_ok=True)
            return True
        except Exception:
            return False

    def get_environment_type(self) -> str:
        return "venv"

    def get_environment_name(self) -> str:
        return self.environment_name

    def get_python_interpreter(self) -> str:
        if not self.python_interpreter:
            raise RuntimeError("Environment not set up yet. Call setup_environment() first.")
        return self.python_interpreter

    def environment_exists(self) -> bool:
        """Check if the virtual environment already exists."""
        return self._python_path(self.venv_path).exists()

    def setup_environment(self) -> None:
        """Set up the virtual environment based on configuration."""
        
        if not self.environment_exists():
            print(f"[VenvEnvironmentManager] Environment '{self.environment_name}' not found. Creating it...")
            
            self.venv_path.parent.mkdir(parents=True, exist_ok=True)
            
            try:
                subprocess.run([sys.executable, "-m", "venv", str(self.venv_path)], check=True)
            except subprocess.CalledProcessError as e:
                # One more fallback: use virtualenv if available
                try:
                    subprocess.run([sys.executable, "-m", "virtualenv", str(self.venv_path)], check=True)
                except Exception:
                    raise RuntimeError(f"Failed to create virtual environment '{self.environment_name}': {e}")

        self.python_interpreter = str(self._python_path(self.venv_path))
        
        if not Path(self.python_interpreter).exists():
            raise FileNotFoundError(f"Python interpreter not found in environment '{self.environment_name}' at expected path: {self.python_interpreter}")

        if self.requirements:
            try:
                # Ensure modern build tooling to prefer wheels over source builds
                subprocess.run([self.python_interpreter, "-m", "pip", "install", "--quiet", "--upgrade", "pip", "setuptools", "wheel"], check=True)
                pip_install_cmd = [self.python_interpreter, "-m", "pip", "install", "--quiet", "--no-cache-dir"] + self.requirements
                subprocess.run(pip_install_cmd, check=True)
            except subprocess.CalledProcessError as e:
                raise RuntimeError(f"Failed to install requirements: {e}")

    def verify_environment(self) -> bool:
        """Verify that the environment is properly configured."""
        if not self.python_interpreter:
            print("[VenvEnvironmentManager] Python interpreter not set. Cannot verify environment.")
            return False

        try:
            python_version_output = subprocess.check_output([self.python_interpreter, '--version'], text=True, stderr=subprocess.STDOUT).strip()
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            print(f"[VenvEnvironmentManager] Python interpreter '{self.python_interpreter}' is not working: {e}")
            return False

        if self.requirements:
            ok, missing = verify_pip_requirements(self.python_interpreter, self.requirements)
            if not ok:
                print(f"[VenvEnvironmentManager] Missing packages: {', '.join(missing)}")
                print(f"[VenvEnvironmentManager] Environment verification failed for '{self.environment_name}'.")
                return False
        
        return True 