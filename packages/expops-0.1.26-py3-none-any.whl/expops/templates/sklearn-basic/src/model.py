from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

from expops.core import log_metric, process

def _load_xy(csv_path: str | Path):
    df = pd.read_csv(Path(csv_path))
    y = df.pop("label").values
    x = df.values
    return x, y


def _training_csv_path() -> Path:
    return Path("data/train.csv")


def _validation_csv_path() -> Path:
    return _training_csv_path()


@process()
def train_model():
    """
    Train a logistic regression classifier on the template dataset.

    This process:
    - Reads training data from `<project_root>/data/train.csv`.
    - Fits a `LogisticRegression` model with up to 200 iterations.
    - Logs training accuracy as the `accuracy` metric.

    Returns
    -------
    dict
        Dictionary containing:

        - **model** (`sklearn.linear_model.LogisticRegression`): Trained classifier.
    """
    train_path = _training_csv_path()
    x, y = _load_xy(train_path)
    model = LogisticRegression(max_iter=200)
    model.fit(x, y)

    train_acc = float(accuracy_score(y, model.predict(x)))
    log_metric("accuracy", train_acc)

    return {"model": model}


@process()
def evaluate_model(model):
    """
    Evaluate a trained model on the validation dataset.

    This process:
    - Loads validation data from `<project_root>/data/train.csv`.
    - Runs predictions using the provided model.
    - Logs validation accuracy as the `accuracy` metric.

    Parameters
    ----------
    model : sklearn.base.ClassifierMixin
        Trained estimator implementing `predict(X)`. Typically the `model`
        output from `train_model`.

    Returns
    -------
    dict
        Empty dictionary.

    Raises
    ------
    ValueError
        If `model` is None (missing upstream training output).
    FileNotFoundError
        If the validation CSV does not exist at the expected path.
    """
    if model is None:
        raise ValueError("Missing upstream model. Expected `model` from training process.")

    val_path = _validation_csv_path()
    if not val_path.exists():
        raise FileNotFoundError(
            f"Validation CSV not found at {val_path}. "
            "Expected the template dataset at <project_root>/data/train.csv."
        )
    x, y = _load_xy(val_path)
    eval_acc = float(accuracy_score(y, model.predict(x)))
    log_metric("accuracy", eval_acc)

    return {}

