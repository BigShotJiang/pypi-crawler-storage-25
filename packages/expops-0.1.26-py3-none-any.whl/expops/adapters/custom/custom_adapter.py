from __future__ import annotations

import importlib.util
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

from expops.core import StepStateManager, get_context_factory, get_step_registry, set_current_context
from expops.core.compute_config import load_compute_config, map_compute_to_executor
from expops.core.runtime.custom_model_base import MLOpsCustomModelBase
from expops.core.execution.dask_networkx_executor import DaskNetworkXExecutor
from expops.core.graph.networkx_parser import parse_networkx_pipeline_from_config

from ..base import ModelAdapter
from ..config_schema import AdapterConfig


def _as_dict(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    try:
        if hasattr(value, "model_dump"):
            return value.model_dump()  # type: ignore[attr-defined]
    except Exception:
        pass
    try:
        return dict(value)  # type: ignore[arg-type]
    except Exception:
        return {}


def _to_int(value: Any) -> Optional[int]:
    try:
        if value is None:
            return None
        return int(value)
    except Exception:
        return None


def _to_float(value: Any) -> Optional[float]:
    try:
        if value is None:
            return None
        return float(value)
    except Exception:
        return None


class CustomModelAdapter(ModelAdapter):
    """Adapter for user-provided Python model scripts.

    Responsibilities:
    - Load the custom script and register `@step` functions
    - Build a StepStateManager (KV + optional object store)
    - Execute the configured NetworkX pipeline via DaskNetworkXExecutor
    """

    def __init__(
        self,
        config: AdapterConfig,
        python_interpreter: Optional[str] = None,
        environment_name: Optional[str] = None,
        conda_env_name: Optional[str] = None,
        project_path: Optional[Path] = None,
        run_context: Optional[object] = None,
    ) -> None:
        super().__init__(config, python_interpreter=python_interpreter, environment_name=environment_name, conda_env_name=conda_env_name)
        self.project_path = project_path
        self.run_context = run_context
        self.step_registry = get_step_registry()
        self.step_state_manager: StepStateManager | None = None
        self.networkx_executor: DaskNetworkXExecutor | None = None
        self._local_cluster: Any = None
        self._local_client: Any = None
        self.logger = logging.getLogger(__name__)
        self._script_paths: list[Path] = []
        self._chart_script_paths: list[Path] = []
        self._scripts_section: Dict[str, str] | None = None
        self._default_script: str | None = None

    def _repo_root(self) -> Path:
        """Best-effort workspace root resolution (where projects live)."""
        try:
            from expops.core.workspace import get_workspace_root
            return get_workspace_root()
        except Exception:
            return Path.cwd()

    def _resolve_custom_script_path(self, custom_script_path: str) -> Path:
        p = Path(custom_script_path)
        if p.is_absolute() and p.exists():
            return p
        if p.exists():
            return p
        # Try relative to project path (for configs that use "models/foo.py")
        try:
            if self.project_path and (self.project_path / p).exists():
                return self.project_path / p
        except Exception:
            pass
        # Try relative to repo root (for configs that use "<id>/models/foo.py")
        try:
            repo_root = self._repo_root()
            cand = repo_root / p
            if cand.exists():
                return cand
        except Exception:
            pass
        return p

    def _ensure_runtime_sys_path(self, script_path: Path) -> None:
        candidates: list[Path] = []
        try:
            if script_path.parent.exists():
                candidates.append(script_path.parent)
        except Exception:
            pass
        try:
            if self.project_path and self.project_path.exists():
                candidates.append(self.project_path)
            else:
                guess_root = script_path.parent.parent
                if guess_root.exists():
                    candidates.append(guess_root)
        except Exception:
            pass
        try:
            from expops.core.workspace import infer_source_root

            src_root = infer_source_root()
            if src_root:
                candidates.append(src_root / "src")
        except Exception:
            pass

        for path in candidates:
            path_str = str(path)
            if path_str and path_str not in sys.path:
                sys.path.insert(0, path_str)
        
    def initialize(self) -> None:
        """Initialize the adapter: import model module, configure caching, and set up the executor."""
        self.logger = logging.getLogger(__name__)

        # Load scripts and execution.workspace from config file
        full_config: Dict[str, Any] = {}
        try:
            if self.project_path:
                config_path = self.project_path / "configs" / "project_config.yaml"
                if config_path.exists():
                    import yaml
                    with open(config_path, "r") as f:
                        full_config = yaml.safe_load(f) or {}
                    self._scripts_section = full_config.get("scripts")
                    if self._scripts_section and isinstance(self._scripts_section, dict):
                        # Get first script key as default
                        self._default_script = next(iter(self._scripts_section)) if self._scripts_section else None
        except Exception as e:
            self.logger.warning(f"Failed to load scripts section from config: {e}")

        execution_workspace = getattr(self.run_context, "execution_workspace", None) if self.run_context else None
        if execution_workspace is None and full_config:
            from expops.runtime.context import parse_execution_workspace_config
            exec_cfg = full_config.get("execution") if isinstance(full_config.get("execution"), dict) else {}
            execution_workspace = parse_execution_workspace_config(exec_cfg.get("workspace") if isinstance(exec_cfg.get("workspace"), dict) else None)
        
        scripts_section = self._scripts_section
        default_script = self._default_script

        custom_target = getattr(self.config, "custom_target", None)
        pipeline_config = getattr(self.config, "pipeline", None)
        pipeline_dict = pipeline_config.model_dump() if hasattr(pipeline_config, "model_dump") else (pipeline_config or {})
        process_cfgs = pipeline_dict.get("processes", []) if isinstance(pipeline_dict, dict) else []

        required_component_prefixes: list[str] = []
        for proc in process_cfgs:
            if not isinstance(proc, dict):
                continue
            component_ref = str(proc.get("component", "")).strip() if isinstance(proc.get("component"), str) else ""
            for prefix in ("sklearn.", "matplotlib."):
                if component_ref.startswith(prefix) and prefix not in required_component_prefixes:
                    required_component_prefixes.append(prefix)
        if required_component_prefixes:
            try:
                from expops.components.plugin_loader import ensure_component_runners_registered

                ensure_component_runners_registered(required_component_prefixes=required_component_prefixes)
            except Exception as e:
                self.logger.warning(f"Failed to register built-in component runners: {e}")

        script_paths: list[str] = []
        chart_script_paths: list[str] = []
        missing_script_paths: list[str] = []
        has_component_process = False

        # Import resolve_script_path helper
        from expops.core.graph.pipeline_utils import resolve_script_path

        for proc in process_cfgs:
            if not isinstance(proc, dict):
                continue
            proc_type = str(proc.get("type", "process"))
            probe_paths = proc.get("probe_paths")
            chart_type = proc.get("chart_type")
            component_ref = str(proc.get("component", "")).strip() if isinstance(proc.get("component"), str) else ""
            # Matplotlib "component" chart renderers (e.g., BarChart.render) use `probe_paths`,
            # but they must remain normal component processes (not chart subprocesses).
            matplotlib_probe_component = (
                bool(component_ref)
                and component_ref.startswith("matplotlib.")
                and probe_paths is not None
            )
            is_chart = (
                (proc_type == "chart")
                or (probe_paths is not None and not matplotlib_probe_component)
                or (chart_type is not None)
            )

            # Derive script key from unified `code` field where possible.
            raw_code = proc.get("code")
            code_str = str(raw_code).strip() if isinstance(raw_code, str) else ""
            if component_ref and code_str:
                raise ValueError(
                    f"Process '{proc.get('name', 'unknown')}' cannot declare both 'code' and 'component'."
                )
            if component_ref and is_chart:
                raise ValueError(
                    f"Process '{proc.get('name', 'unknown')}' cannot declare 'component' for chart process."
                )
            has_explicit_code = bool(code_str)
            has_data_parallelism = proc.get("data_parallelism") is not None
            has_seed_parallelism = proc.get("seed_parallelism") is not None
            is_default_split = (not has_explicit_code) and (has_data_parallelism or has_seed_parallelism)

            script_key: str | None = None
            if has_explicit_code:
                if "." in code_str:
                    script_key, _ = code_str.rsplit(".", 1)
                    script_key = script_key or None
                else:
                    # No explicit script key: use default script
                    script_key = None

            if is_chart:
                script_path = resolve_script_path(script_key, scripts_section, default_script) if scripts_section else None
                if script_path and str(script_path).lower().endswith(".py"):
                    chart_script_paths.append(str(script_path))
                continue
            if component_ref:
                has_component_process = True
                continue

            script_path = resolve_script_path(script_key, scripts_section, default_script) if scripts_section else None
            if not script_path:
                if is_default_split:
                    # Default data/seed split nodes without explicit code may omit scripts.
                    continue
                missing_script_paths.append(str(proc.get("name", "unknown")))
                continue
            script_paths.append(str(script_path))

        if missing_script_paths:
            missing = ", ".join(sorted(set(missing_script_paths)))
            raise ValueError(
                "script must be specified for non-chart processes "
                "(except default data/seed split nodes without explicit code): "
                f"{missing}"
            )
        if not script_paths and not has_component_process:
            raise ValueError("No script entries found for non-chart processes in pipeline configuration")

        unique_script_paths: list[str] = []
        seen_paths: set[str] = set()
        for path in script_paths:
            if path not in seen_paths:
                seen_paths.add(path)
                unique_script_paths.append(path)

        imported_modules = []
        resolved_script_paths: list[Path] = []
        for idx, raw_path in enumerate(unique_script_paths):
            script_path = self._resolve_custom_script_path(str(raw_path))
            if not script_path.exists():
                raise FileNotFoundError(f"Custom script not found: {raw_path}")
            resolved_script_paths.append(script_path)
            self._ensure_runtime_sys_path(script_path)

            module_name = f"custom_model_{idx}_{script_path.stem}"
            spec = importlib.util.spec_from_file_location(module_name, str(script_path.resolve()))
            if spec is None or spec.loader is None:
                raise ImportError(f"Failed to create import spec for: {script_path}")
            custom_module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = custom_module
            spec.loader.exec_module(custom_module)  # type: ignore[attr-defined]
            imported_modules.append(custom_module)
            self.logger.info(f"Imported model module from: {raw_path}")

        unique_chart_paths: list[str] = []
        seen_chart_paths: set[str] = set()
        for path in chart_script_paths:
            if path not in seen_chart_paths:
                seen_chart_paths.add(path)
                unique_chart_paths.append(path)

        resolved_chart_paths: list[Path] = []
        for raw_path in unique_chart_paths:
            chart_path = self._resolve_custom_script_path(str(raw_path))
            if chart_path.exists():
                resolved_chart_paths.append(chart_path)

        if custom_target:
            target_found = False
            for custom_module in imported_modules:
                if hasattr(custom_module, custom_target):
                    self.model_class = getattr(custom_module, custom_target)
                    target_found = True
                    try:
                        if not issubclass(self.model_class, MLOpsCustomModelBase):
                            self.logger.info(f"Target '{custom_target}' does not inherit MLOpsCustomModelBase; proceeding anyway.")
                    except TypeError:
                        pass
                    break
            if not target_found:
                candidates = ", ".join(unique_script_paths)
                raise AttributeError(f"Target '{custom_target}' not found in any script_path: {candidates}")

        self._script_paths = resolved_script_paths
        self._chart_script_paths = resolved_chart_paths

        # Steps are registered via decorators during import.
        self.step_registry = get_step_registry()
        try:
            step_names = list(getattr(self.step_registry, "_steps", {}).keys())
        except Exception:
            pass

        cache_config = getattr(self.config, "cache", {}) or {}
        cache_config = _as_dict(cache_config)
        cache_ttl_hours = cache_config.get("ttl_hours", 24) if isinstance(cache_config, dict) else 24

        step_cache_dir: Path
        env_cache_dir = os.getenv("MLOPS_STEP_CACHE_DIR")
        if env_cache_dir:
            step_cache_dir = Path(env_cache_dir)
        elif self.project_path:
            try:
                from expops.core.workspace import get_project_runtime_root

                runtime_root = get_project_runtime_root(self.project_path, self.project_path.name)
                step_cache_dir = runtime_root / "cache" / "steps"
            except Exception:
                step_cache_dir = self.project_path / "cache" / "steps"
        else:
            step_cache_dir = Path("step_cache")

        project_id_for_ns = self.project_path.name if self.project_path else "default"
        backend_cfg = _as_dict(cache_config.get("backend", {}))

        # Centralized KV/object-store creation (config -> env override -> safe fallback).
        try:
            from expops.storage.factory import create_kv_store, create_object_store
        except Exception:
            create_kv_store = None  # type: ignore[assignment]
            create_object_store = None  # type: ignore[assignment]

        try:
            ws_root = self._repo_root()
        except Exception:
            ws_root = None

        if create_kv_store:
            kv_store = create_kv_store(
                project_id_for_ns,
                backend_cfg if isinstance(backend_cfg, dict) else {},
                env=os.environ,
                workspace_root=ws_root,
                project_root=self.project_path,
            )
        else:
            from expops.storage.adapters.memory_store import InMemoryStore
            kv_store = InMemoryStore(project_id_for_ns)

        obj_store = None
        obj_prefix = None
        if create_object_store:
            try:
                obj_store = create_object_store(cache_config if isinstance(cache_config, dict) else {}, env=os.environ)
                if obj_store is not None:
                    obj_prefix = f"{project_id_for_ns}/cache"
            except Exception:
                obj_store = None
                obj_prefix = None

        self.step_state_manager = StepStateManager(
            cache_dir=step_cache_dir,
            kv_store=kv_store,
            logger=self.logger,
            cache_ttl_hours=cache_ttl_hours,
            object_store=obj_store,
            object_prefix=obj_prefix,
            project_root=self.project_path,
        )

        compute_cfg = {}
        try:
            if self.project_path:
                compute_cfg = load_compute_config(self.project_path / "configs" / "compute_config.yaml")
        except Exception:
            compute_cfg = {}
        executor_config = _as_dict(map_compute_to_executor(compute_cfg) or {})
        env_workers = os.environ.get("MLOPS_N_WORKERS")
        try:
            n_workers = int(env_workers) if env_workers else int(executor_config.get("n_workers", 2))
        except Exception:
            n_workers = 2

        dask_tuning_cfg = _as_dict(executor_config.get("dask") or {})
        if isinstance(dask_tuning_cfg, dict) and not dask_tuning_cfg and executor_config.get("dask_config"):
            dask_tuning_cfg = _as_dict(executor_config.get("dask_config"))

        min_workers_override = _to_int(executor_config.get("min_workers")) if isinstance(executor_config, dict) else None
        wait_for_workers_override = _to_float(executor_config.get("wait_for_workers_sec")) if isinstance(executor_config, dict) else None
        if isinstance(dask_tuning_cfg, dict):
            if min_workers_override is None:
                min_workers_override = _to_int(dask_tuning_cfg.get("min_workers"))
            if wait_for_workers_override is None:
                wait_for_workers_override = _to_float(dask_tuning_cfg.get("wait_for_workers_sec"))

        dask_overrides: Dict[str, Any] = {}
        compression_setting = None
        if isinstance(dask_tuning_cfg, dict):
            comm_cfg = _as_dict(dask_tuning_cfg.get("comm") or {})
            if isinstance(comm_cfg, dict):
                compression_setting = comm_cfg.get("compression") or comm_cfg.get("codec")
            if compression_setting:
                dask_overrides["distributed.comm.compression"] = str(compression_setting)
            memory_cfg = _as_dict(dask_tuning_cfg.get("memory") or {})
            if isinstance(memory_cfg, dict):
                mem_map = {
                    "worker_target_fraction": "distributed.worker.memory.target",
                    "worker_spill_fraction": "distributed.worker.memory.spill",
                    "worker_pause_fraction": "distributed.worker.memory.pause",
                }
                for src_key, dst_key in mem_map.items():
                    val = memory_cfg.get(src_key)
                    if val is not None:
                        try:
                            dask_overrides[dst_key] = float(val)
                        except Exception:
                            dask_overrides[dst_key] = val
            overrides_block = dask_tuning_cfg.get("overrides")
            if isinstance(overrides_block, dict):
                for key, value in overrides_block.items():
                    if isinstance(key, str):
                        dask_overrides[key] = value

        if compression_setting:
            try:
                os.environ.setdefault("DASK_DISTRIBUTED__COMM__COMPRESSION", str(compression_setting))
            except Exception:
                pass

        scheduler_address = executor_config.get("scheduler_address") or os.environ.get("DASK_SCHEDULER_ADDRESS")
        initial_client: Any = None
        if not scheduler_address and execution_workspace is not None:
            try:
                try:
                    from distributed import Client, LocalCluster
                except Exception:
                    from dask.distributed import Client, LocalCluster
                self._local_cluster = LocalCluster(
                    n_workers=max(1, n_workers),
                    threads_per_worker=1,
                )
                self._local_client = Client(self._local_cluster)
                initial_client = self._local_client
                scheduler_address = getattr(self._local_cluster, "scheduler_address", None) or getattr(getattr(self._local_client, "scheduler", None), "address", None)
                self.logger.info(f"Started local process workers (strict_process_workers): n_workers={n_workers}, scheduler={scheduler_address}")
            except Exception as e:
                self.logger.warning(f"Failed to start local process workers, falling back to threads: {e}")
                self._local_cluster = None
                self._local_client = None
        scheduler_mode = "distributed" if (scheduler_address or initial_client) else "threads"

        extra_files_to_upload: list[str] = []
        try:
            extra_files_to_upload = [str(path) for path in self._script_paths if path]
            extra_files_to_upload.extend([str(path) for path in self._chart_script_paths if path])
        except Exception:
            extra_files_to_upload = []
        # Paths to upload but not load (chart/reporting scripts run in subprocess with reporting env).
        extra_files_no_load: list[str] = []
        try:
            extra_files_no_load = [str(path) for path in self._chart_script_paths if path]
        except Exception:
            pass
        # Upload reporting entrypoint for worker-side chart imports (best-effort).
        try:
            rep_cfg_text = os.environ.get("MLOPS_REPORTING_CONFIG") or ""
            if rep_cfg_text:
                rep_cfg = json.loads(rep_cfg_text) or {}
                ep = rep_cfg.get("static_entrypoint") or rep_cfg.get("entrypoint")
                if isinstance(ep, str) and ep.strip():
                    p = Path(ep)
                    if not p.is_absolute():
                        p = self._repo_root() / p
                    if p.exists():
                        extra_files_to_upload.append(str(p))
                        extra_files_no_load.append(str(p))
        except Exception:
            pass

        self.networkx_executor = DaskNetworkXExecutor(
            step_registry=self.step_registry,
            state_manager=self.step_state_manager,
            logger=self.logger,
            n_workers=n_workers,
            scheduler_mode=scheduler_mode,
            scheduler_address=scheduler_address,
            client=initial_client,
            extra_files_to_upload=extra_files_to_upload,
            extra_files_no_load=extra_files_no_load,
            min_workers=min_workers_override,
            wait_for_workers_sec=wait_for_workers_override,
            dask_config_overrides=dask_overrides,
            run_context=self.run_context,
        )
        mode_label = "distributed" if scheduler_mode == "distributed" else "threads"
        self.logger.info(f"Initialized Dask NetworkX executor with {n_workers} workers ({mode_label} scheduler)")
        
        self.logger.info("Enhanced caching with function hashing: ENABLED")

        # Make state manager available for manual step-level caching in decorators
        try:
            from expops.core.runtime.step_system import set_state_manager as _set_sm
            _set_sm(self.step_state_manager)
        except Exception:
            pass
        
        

    def _execute_step_graph(self, run_id: str, data_paths: Dict[str, Path], **kwargs) -> Dict[str, Any]:
        """Execute the configured pipeline once."""
        if not self.networkx_executor or not self.step_state_manager:
            raise RuntimeError("NetworkX execution not properly initialized")
            
        pipeline_config = self.config.pipeline
        if not pipeline_config:
            raise ValueError("NetworkX executor requires pipeline configuration with 'processes' and 'steps' sections")
            
        pipeline_dict = pipeline_config.model_dump() if hasattr(pipeline_config, 'model_dump') else pipeline_config
        
        if "processes" not in pipeline_dict:
            raise ValueError(
                "NetworkX executor requires 'processes' section in pipeline configuration. "
                "Legacy 'main_flow' syntax is no longer supported. "
                "Please use the NetworkX format with processes and steps."
            )
        
        networkx_config = parse_networkx_pipeline_from_config(pipeline_dict, scripts_section=self._scripts_section)
        
        try:
            project_id = getattr(getattr(self, "run_context", None), "project_id", None) or (
                self.project_path.name if self.project_path else "default"
            )
        except Exception:
            project_id = self.project_path.name if self.project_path else "default"
        
        context_factory = get_context_factory()
        global_cfg = _as_dict(self.config)
        overrides = kwargs.get("global_config_overrides")
        if isinstance(overrides, dict) and overrides:
            global_cfg = {**global_cfg, **overrides}

        context = context_factory.create_context(
            project_id=project_id,
            run_id=run_id,
            global_config=global_cfg,
            data_paths=data_paths,
            data_hash=kwargs.get("data_hash"),
        )
        
        set_current_context(context)
        
        try:
            resume_from_process = kwargs.get("resume_from_process")
            config_hash = self.step_state_manager._compute_config_hash(pipeline_dict)
            
            if resume_from_process and self.step_state_manager.can_resume_from_step(run_id, resume_from_process, config_hash):
                self.logger.info(f"Resuming execution from process: {resume_from_process}")
                context.step_results = self.step_state_manager.get_step_results(run_id)
            else:
                self.step_state_manager.start_pipeline_execution(run_id, pipeline_dict)
                
            single_process = kwargs.get("single_process", False)
            execution_results = self.networkx_executor.execute_graph(
                networkx_config,
                context,
                run_id=run_id,
                resume_from_process=resume_from_process,
                stop_after_process=single_process,
            )
            
            results = {}
            
            for process_name, process_result in execution_results.items():
                if process_result.error is None:  # success check for simplified result
                    if process_result.result:
                        result_dict = process_result.result
                        results[f"{process_name}_result"] = result_dict
                        
                        if process_name == "model_training" and result_dict:
                            training_summary = {}
                            if 'model' in result_dict:
                                model = result_dict['model']
                                if hasattr(model, 'get_training_metrics'):
                                    training_summary['model_metrics'] = model.get_training_metrics()
                                training_summary['model_type'] = type(model).__name__
                            results[f"{process_name}_summary"] = training_summary
                        
                        elif process_name == "evaluate_model" and result_dict:
                            evaluation_summary = {}
                            if 'evaluation_metrics' in result_dict:
                                evaluation_summary['final_metrics'] = result_dict['evaluation_metrics']
                            if 'predictions' in result_dict:
                                evaluation_summary['prediction_count'] = len(result_dict['predictions'])
                            results[f"{process_name}_summary"] = evaluation_summary
                
                else:
                    results[f"{process_name}_error"] = process_result.error
                    self.logger.error(f"Process {process_name} failed: {process_result.error}")
            
            return results
            
        finally:
            set_current_context(None)

    def run(self, data_paths: Dict[str, Path] | None = None, **kwargs) -> Dict[str, Any]:
        """Run the pipeline once according to the configured processes/steps."""
        run_id = kwargs.pop("run_id", f"run_{int(time.time())}")
        normalized_paths: Dict[str, Path] = data_paths or {}
        return self._execute_step_graph(run_id=run_id, data_paths=normalized_paths, **kwargs)

    def save_model(self, model_path: str, **kwargs) -> None:
        """Save model artifacts (handled automatically by step system)."""
        self.logger.info(f"Model artifacts will be saved automatically by the step system to: {model_path}")

    def load_model(self, model_path: str, **kwargs) -> Any:
        """Load model artifacts (handled automatically by step system)."""
        self.logger.info(f"Model artifacts will be loaded automatically by the step system from: {model_path}")
        return None

        

    @classmethod
    def validate_config(cls, config: AdapterConfig) -> bool:
        """Validate the adapter configuration."""
        try:
            if not config.pipeline:
                return False
            pipeline_dict = config.pipeline.model_dump() if hasattr(config.pipeline, 'model_dump') else config.pipeline
            if "processes" not in pipeline_dict:
                return False
            for proc in (pipeline_dict.get("processes", []) or []):
                if not isinstance(proc, dict):
                    continue
                proc_type = str(proc.get("type", "process"))
                metrics = proc.get("metrics")
                if metrics is not None:
                    if not isinstance(metrics, list):
                        return False
                    for metric_def in metrics:
                        if not isinstance(metric_def, dict):
                            return False
                        metric_name = str(metric_def.get("name", "")).strip()
                        if not metric_name:
                            return False
                        metric_fn = metric_def.get("fn")
                        metric_from = metric_def.get("from_result")
                        if metric_fn is not None and not str(metric_fn).strip():
                            return False
                        if metric_from is not None and not str(metric_from).strip():
                            return False
                        metric_inputs = metric_def.get("inputs")
                        if metric_inputs is not None and not isinstance(metric_inputs, dict):
                            return False
                if proc_type == "chart":
                    continue
                component_ref = str(proc.get("component", "")).strip() if isinstance(proc.get("component"), str) else ""
                raw_code = proc.get("code")
                code_str = str(raw_code).strip() if isinstance(raw_code, str) else ""
                if component_ref and code_str:
                    return False
                if component_ref:
                    continue
                has_explicit_code = bool(code_str)
                has_data_parallelism = proc.get("data_parallelism") is not None
                has_seed_parallelism = proc.get("seed_parallelism") is not None
                is_default_split = (not has_explicit_code) and (has_data_parallelism or has_seed_parallelism)
                if is_default_split:
                    continue
                # For non-split processes, we require either explicit code or default
                # behavior (code omitted but no split flags). In both cases validation passes.
            return True
        except Exception:
            return False

    def save(self, path: Path) -> None:
        """Save adapter state."""
        pass

    def load(self, path: Path) -> None:
        """Load adapter state."""
        pass

Adapter = CustomModelAdapter 