"""Version information for the Bimiyun Python SDK."""

__version__ = "0.1.0"
__title__ = "bimiyun-python"
__description__ = "Bimiyun Search API Python SDK"
__author__ = "Bimiyun Team"
__license__ = "MIT"
__url__ = "https://github.com/bimiyun-ai/bimiyun-python"
