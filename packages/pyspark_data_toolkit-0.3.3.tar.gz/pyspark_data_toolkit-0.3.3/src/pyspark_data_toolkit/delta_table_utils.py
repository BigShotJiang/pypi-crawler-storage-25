from pyspark.sql import DataFrame, SparkSession
from delta.tables import DeltaTable
from typing import Dict, List, Any, Optional, Union
import logging
from logging_metrics import configure_basic_logging
import os
from pyspark_data_toolkit.schema_utils import align_dataframe_to_table_schema
import json
import logging

__all__ = [
    "write_delta_table",
    "replace_delta_partitions",
    "merge_delta_table",
    "optimize_delta_table",
    "vacuum_delta_table",
    "set_table_properties",
    "optimize_and_vacuum_delta_table",
    "update_delta_table_column_comments"
]

def get_logger() -> logging.Logger:
    """Retorna um logger configurado."""
    return configure_basic_logging()

def _build_where_clause(filters: Union[str, Dict[str, Any]]) -> str:
    """
    Constrói uma cláusula WHERE de forma inteligente.
    
    Args:
        filters: Pode ser:
            - String SQL: "region = 'BR' AND date >= '2024-01-01'"
            - Dict simples: {"region": "BR", "date": "2024-01-01"}
            - Dict com operadores: {"date": {">=": "2024-01-01"}, "status": ["active", "pending"]}
    
    Returns:
        str: Cláusula WHERE formatada
    """
    if isinstance(filters, str):
        return filters
    
    if not isinstance(filters, dict):
        raise ValueError(f"filters deve ser str ou dict, recebido: {type(filters)}")
    
    clauses = []
    
    for column, condition in filters.items():
        if isinstance(condition, list):
            # Lista de valores -> IN
            if len(condition) == 1:
                clauses.append(f"{column} = {repr(condition[0])}")
            else:
                formatted_values = [repr(v) for v in condition]
                clauses.append(f"{column} IN ({', '.join(formatted_values)})")
        
        elif isinstance(condition, dict):
            # Dict com operadores
            for operator, value in condition.items():
                op_lower = operator.lower()
                
                if op_lower == "between" and isinstance(value, list) and len(value) == 2:
                    clauses.append(f"{column} BETWEEN {repr(value[0])} AND {repr(value[1])}")
                elif op_lower == "in" and isinstance(value, list):
                    if len(value) == 1:
                        clauses.append(f"{column} = {repr(value[0])}")
                    else:
                        formatted_values = [repr(v) for v in value]
                        clauses.append(f"{column} IN ({', '.join(formatted_values)})")
                elif op_lower in ["is", "is not"]:
                    clauses.append(f"{column} {operator.upper()} {value}")
                else:
                    clauses.append(f"{column} {operator} {repr(value)}")
        else:
            # Valor simples -> igualdade
            clauses.append(f"{column} = {repr(condition)}")
    
    return " AND ".join(clauses)

def _ensure_path_exists(path: str) -> None:
    """Garante que o diretório existe."""
    os.makedirs(path, exist_ok=True)

def set_table_properties(
    spark: SparkSession, 
    table_name: str, 
    log_retention_duration: int = 30,
    deletedFileRetentionDuration: int = 30
) -> None:
    """
    Define propriedades padrão para otimização automática.
    
    Args:
        spark: Sessão do Spark
        table_name: Nome da tabela
        log_retention_duration: Dias para retenção de logs (padrão: 30)
        deletedFileRetentionDuration: Dias para retenção de arquivos deletados (padrão: 30)

    """
    spark.sql(f"""
        ALTER TABLE {table_name}
        SET TBLPROPERTIES (
            'delta.autoOptimize.optimizeWrite' = 'true',
            'delta.autoOptimize.autoCompact'  = 'true',
            'delta.logRetentionDuration' = '{log_retention_duration} days',
            'delta.deletedFileRetentionDuration' = '{deletedFileRetentionDuration} days',
            'delta.columnMapping.mode' = 'name'
        )
    """)

# =============================================================================
# FUNÇÕES DE ESCRITA
# =============================================================================

def write_delta_table(
        df: DataFrame,
        table_name: str,
        table_path: str,
        mode: str = "overwrite",
        merge_keys: Optional[List[str]] = None,
        version_col: Optional[str] = None,
        columns_to_update: Optional[List[str]] = None,
        partition_cols: Optional[List[str]] = None,
        log_retention_duration: int = 30,
        align_schema: bool = True,
        logger: Optional[logging.Logger] = None
) -> None:
    """
    Escreve dados em uma tabela Delta com suporte a múltiplos modos de operação.
    """
    logger = logger or get_logger()

    if mode not in ["create", "append", "overwrite", "merge"]:
        raise ValueError(f"Mode inválido: {mode}. Opções: 'create', 'append', 'overwrite', 'merge'")

    if mode == "merge" and not merge_keys:
        raise ValueError("merge_keys é obrigatório quando mode='merge'")

    try:
        _ensure_path_exists(table_path)

        table_exists = DeltaTable.isDeltaTable(df.sparkSession, table_path)

        if not table_exists or mode == "create":
            logger.warning(f"Tabela não existe: {table_name}. Criando nova tabela...")

            writer = (
                df.write
                .format("delta")
                .mode("overwrite")
                .option("mergeSchema", "true")
                .option("path", table_path)
            )

            if partition_cols:
                logger.info(f"Criando tabela particionada por: {partition_cols}")
                writer = writer.partitionBy(*partition_cols)

            writer.saveAsTable(table_name)
            set_table_properties(df.sparkSession, table_name, log_retention_duration)

            logger.info(f"Tabela criada com sucesso: {table_name}")

        if align_schema:
            logger.info(f"Alinhando schema do DataFrame ao schema da tabela: {table_name}")
            df, _ = align_dataframe_to_table_schema(
                df_source=df,
                table_name=table_name,
                merge_columns=True,
                spark=df.sparkSession
            )

        if mode == "merge":
            # Chamar função existente diretamente
            merge_delta_table(
                df=df,
                table_name=table_name,
                table_path=table_path,
                merge_keys=merge_keys,
                version_col=version_col,
                columns_to_update=columns_to_update,
                align_schema=align_schema,
                logger=logger
            )

        if mode == "append":
            (
                df.write
                .format("delta")
                .mode("append")
                .option("mergeSchema", "true")
                .option("path", table_path)
                .saveAsTable(table_name)
            )

            logger.info(f"Dados adicionados com sucesso: {table_name}")

        elif mode == "overwrite":
            (
                df.write
                .format("delta")
                .mode("overwrite")
                .option("mergeSchema", "true")
                .option("path", table_path)
                .saveAsTable(table_name)
            )
            logger.info(f"Tabela substituída com sucesso: {table_name}")

    except Exception as e:
        logger.error(f"Erro ao escrever na tabela {table_name} (mode={mode}): {e}", exc_info=True)
        raise

def replace_delta_partitions(
    df: DataFrame,
    table_name: str,
    table_path: str,
    partition_filter: Union[str, Dict[str, Any]],
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Substitui apenas partições específicas de uma tabela Delta.
    
    Args:
        df: DataFrame com os novos dados
        table_name: Nome completo da tabela
        table_path: Caminho da tabela
        partition_filter: Filtro para as partições a serem substituídas
        logger: Logger para uso (opcional)
    
    Exemplos:
        # String SQL
        replace_delta_partitions(df, "my_table", "/path", "year = 2024 AND region = 'BR'")
        
        # Dict simples
        replace_delta_partitions(df, "my_table", "/path", {"year": 2024, "region": "BR"})
        
        # Dict com operadores
        replace_delta_partitions(df, "my_table", "/path", {
            "year": 2024,
            "region": ["BR", "US"],
            "date": {">=": "2024-01-01"}
        })
    """
    logger = logger or get_logger()
    
    try:
        _ensure_path_exists(table_path)
        
        where_clause = _build_where_clause(partition_filter)
        logger.info(f"Substituindo partições com filtro: {where_clause}")
        
        (
            df.write
            .format("delta")
            .mode("overwrite")
            .option("replaceWhere", where_clause)
            .option("path", table_path)
            .saveAsTable(table_name)
        )
        
        logger.info(f"Partições substituídas com sucesso: {table_name}")
        
    except Exception as e:
        logger.error(f"Erro ao substituir partições da tabela {table_name}: {e}", exc_info=True)
        raise


def merge_delta_table(
        df: DataFrame,
        table_name: str,
        table_path: str,
        merge_keys: List[str],
        version_col: Optional[str] = None,
        columns_to_update: Optional[List[str]] = None,
        align_schema: bool = True,  # NOVO
        logger: Optional[logging.Logger] = None
) -> None:
    """
    Executa operação MERGE: atualiza registros existentes ou insere novos.
    Faz alinhamento automático de schema se necessário.

    Args:
        df: DataFrame fonte para o merge
        table_name: Nome completo da tabela
        table_path: Caminho da tabela
        merge_keys: Colunas usadas para identificar registros
        version_col: Coluna para comparar versões (opcional)
        columns_to_update: Lista de colunas para atualizar (None = todas)
        align_schema: Se True, alinha o DataFrame ao schema da tabela (padrão: True)
        logger: Logger para uso (opcional)
    """
    logger = logger or get_logger()

    if not merge_keys:
        raise ValueError("merge_keys não pode estar vazio")

    try:
        if not DeltaTable.isDeltaTable(df.sparkSession, table_path):
            raise ValueError(f"Tabela Delta não existe em: {table_path}")

        if align_schema:
            logger.info(f"Alinhando schema do DataFrame ao schema da tabela: {table_name}")
            df, table_schema = align_dataframe_to_table_schema(
                df_source=df,
                table_name=table_name,
                merge_columns=True,
                spark=df.sparkSession
            )
            logger.info(f"Schema alinhado com sucesso. Novas colunas detectadas.")

        # Validações
        missing_keys = [col for col in merge_keys if col not in df.columns]
        if missing_keys:
            raise ValueError(f"Colunas de merge não encontradas: {missing_keys}")

        if version_col and version_col not in df.columns:
            raise ValueError(f"Coluna de versão '{version_col}' não encontrada")

        record_count = df.count()
        logger.info(f"Executando merge de {record_count} registros na tabela: {table_name}")

        delta_table = DeltaTable.forPath(df.sparkSession, table_path)
        merge_condition = " AND ".join([f"target.{col} = source.{col}" for col in merge_keys])

        logger.info(f"Condição de merge: {merge_condition}")

        merge = delta_table.alias("target").merge(df.alias("source"), merge_condition)

        # UPDATE
        if version_col:
            update_condition = f"source.{version_col} >= target.{version_col}"

            if columns_to_update:
                # Atualizar só colunas específicas
                update_dict = {f"target.{col}": f"source.{col}" for col in columns_to_update}
                merge = merge.whenMatchedUpdate(
                    condition=update_condition,
                    set=update_dict
                )
            else:
                merge = merge.whenMatchedUpdateAll(condition=update_condition)
        else:
            if columns_to_update:
                update_dict = {f"target.{col}": f"source.{col}" for col in columns_to_update}
                merge = merge.whenMatchedUpdate(set=update_dict)
            else:
                merge = merge.whenMatchedUpdateAll()

        merge.whenNotMatchedInsertAll().execute()

        logger.info(f"Merge executado com sucesso: {table_name}")

    except Exception as e:
        logger.error(f"Erro ao executar merge na tabela {table_name}: {e}", exc_info=True)
        raise

# =============================================================================
# FUNÇÕES DE MANUTENÇÃO
# =============================================================================
def optimize_delta_table(
    spark: SparkSession,
    table_name: str,
    zorder_cols: Optional[List[str]] = None,
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Executa OPTIMIZE em uma tabela Delta, opcionalmente com ZORDER.
    
    Args:
        spark: Sessão Spark ativa
        table_name: Nome completo da tabela
        zorder_cols: Colunas para ZORDER BY (opcional)
        logger: Logger para uso (opcional)
    """
    logger = logger or get_logger()
    
    try:
        if zorder_cols:
            zorder_expr = ", ".join(zorder_cols)
            logger.info(f"Executando OPTIMIZE com ZORDER BY ({zorder_expr}) na tabela: {table_name}")
            spark.sql(f"OPTIMIZE {table_name} ZORDER BY ({zorder_expr})")
        else:
            logger.info(f"Executando OPTIMIZE na tabela: {table_name}")
            spark.sql(f"OPTIMIZE {table_name}")
            
        logger.info(f"OPTIMIZE executado com sucesso: {table_name}")
        
    except Exception as e:
        logger.error(f"Erro ao otimizar tabela {table_name}: {e}", exc_info=True)
        raise

def vacuum_delta_table(
    spark: SparkSession,
    table_name: str,
    retention_hours: int = 168,
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Executa VACUUM em uma tabela Delta para limpeza de arquivos antigos.
    
    Args:
        spark: Sessão Spark ativa
        table_name: Nome completo da tabela
        retention_hours: Período de retenção em horas (padrão: 168 = 7 dias)
        logger: Logger para uso (opcional)
    """
    logger = logger or get_logger()
    
    try:
        logger.info(f"Executando VACUUM na tabela: {table_name} (retenção: {retention_hours}h)")
        spark.sql(f"VACUUM {table_name} RETAIN {retention_hours} HOURS")
        logger.info(f"VACUUM executado com sucesso: {table_name}")
        
    except Exception as e:
        logger.error(f"Erro ao executar VACUUM na tabela {table_name}: {e}", exc_info=True)
        raise

# =============================================================================
# FUNÇÕES DE CONVENIÊNCIA
# =============================================================================
def optimize_and_vacuum_delta_table(
    spark: SparkSession,
    table_name: str,
    zorder_cols: Optional[List[str]] = None,
    retention_hours: int = 168,
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Executa OPTIMIZE seguido de VACUUM em uma tabela Delta.
    
    Args:
        spark: Sessão Spark ativa
        table_name: Nome completo da tabela
        zorder_cols: Colunas para ZORDER BY (opcional)
        retention_hours: Período de retenção para VACUUM (padrão: 168h = 7 dias)
        logger: Logger para uso (opcional)
    """
    logger = logger or get_logger()
    
    try:
        logger.info(f"Iniciando otimização completa da tabela: {table_name}")
        optimize_delta_table(spark, table_name, zorder_cols, logger)
        vacuum_delta_table(spark, table_name, retention_hours, logger)
        logger.info(f"Otimização completa finalizada: {table_name}")
        
    except Exception as e:
        logger.error(f"Erro na otimização completa da tabela {table_name}: {e}", exc_info=True)
        raise

def update_delta_table_column_comments(
    spark: SparkSession,
    table_name: str,
    metadata: Union[
        str,
        Dict[str, str],
        List[Dict]
    ],
    use_new_name: bool = True,
    logger: Optional[logging.Logger] = None
) -> None:
    """
    Add or update Delta table column comments.

    Supports two input formats:

    1. Dict format:
        {
            "col1": "comment 1",
            "col2": "comment 2"
        }

    2. Metadata list format:
        [
            {
                "column_name": "col1",
                "new_name": "new_col1",
                "comment": "comment 1"
            }
        ]

    Args:
        spark (SparkSession):
            Active Spark session.

        table_name (str):
            Full Delta table name.

        metadata (
            Union[str, Dict[str, str], List[Dict]]
        ):
            Metadata definition.

            Accepted formats:
                - JSON string
                - dict[column, comment]
                - list of metadata dicts

        use_new_name (bool):
            Use `new_name` instead of `column_name`
            when metadata list format is used.

        logger (logging.Logger, optional):
            Custom logger instance.

    Raises:
        ValueError:
            Invalid metadata structure.

        Exception:
            Spark execution errors.
    """

    logger = logger or get_logger()

    try:

        # -----------------------------------------
        # Parse JSON string
        # -----------------------------------------
        if isinstance(metadata, str):
            metadata = json.loads(metadata)

        # -----------------------------------------
        # Get table columns
        # -----------------------------------------
        table_columns = {
            field.name
            for field in spark.table(table_name).schema.fields
        }

        # -----------------------------------------
        # CASE 1 -> Dict format
        # -----------------------------------------
        if isinstance(metadata, dict):

            for column_name, comment in metadata.items():

                if column_name not in table_columns:
                    logger.warning(
                        f"Column '{column_name}' "
                        f"not found in '{table_name}'."
                    )
                    continue

                safe_comment = str(comment).replace("'", "''")

                sql = f"""
                    ALTER TABLE {table_name}
                    ALTER COLUMN {column_name}
                    COMMENT '{safe_comment}'
                """

                logger.info(
                    f"Updating comment for '{column_name}'."
                )

                spark.sql(sql)

        # -----------------------------------------
        # CASE 2 -> Metadata list format
        # -----------------------------------------
        elif isinstance(metadata, list):

            for item in metadata:

                if not isinstance(item, dict):
                    logger.warning(
                        f"Invalid metadata item skipped: {item}"
                    )
                    continue

                column_name = (
                    item.get("new_name")
                    if use_new_name
                    else item.get("column_name")
                )

                comment = item.get("comment")

                if not column_name:
                    logger.warning(
                        f"Missing column name in item: {item}"
                    )
                    continue

                if not comment:
                    logger.warning(
                        f"Missing comment for column "
                        f"'{column_name}'. Skipping."
                    )
                    continue

                if column_name not in table_columns:
                    logger.warning(
                        f"Column '{column_name}' "
                        f"not found in '{table_name}'."
                    )
                    continue

                safe_comment = str(comment).replace("'", "''")

                sql = f"""
                    ALTER TABLE {table_name}
                    ALTER COLUMN {column_name}
                    COMMENT '{safe_comment}'
                """

                logger.info(
                    f"Updating comment for '{column_name}'."
                )

                spark.sql(sql)

        else:
            raise ValueError(
                "Unsupported metadata format."
            )

        logger.info(
            f"Comments updated successfully "
            f"for table '{table_name}'."
        )

    except Exception as e:
        logger.exception(
            f"Error updating comments: {e}"
        )
        raise