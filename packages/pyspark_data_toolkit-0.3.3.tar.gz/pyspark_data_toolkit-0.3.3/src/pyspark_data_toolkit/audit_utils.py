from pyspark.sql import DataFrame, functions as F
from typing import List, Optional, Dict, Any
import uuid
import logging
from logging_metrics import configure_basic_logging

__all__ = [
    "add_control_columns",
    "add_audit_trail_columns",
    "validate_control_columns",
    "check_row_duplicates",
    "add_metadata_columns"
]

def get_logger() -> logging.Logger:
    """Initializes and returns a basic logger for file output.

    Returns:
        logging.Logger: A configured logger with file rotation.
    """
    return configure_basic_logging()


def add_control_columns(
    df: DataFrame,
    is_source_path: bool = False,
    is_user: bool = False,
    source_system: Optional[str] = None,
    is_batch_id:  bool = False,
    batch_id: Optional[str] = None,
    is_hash: bool = False,
    hash_columns: Optional[List[str]] = None,
    layout_version: str = "v2",
    timezone: str = "America/Sao_Paulo",
    file_path: Optional[str] = None,
    pipeline_name: Optional[str] = None,
    log: Optional[logging.Logger] = None
) -> DataFrame:
    """
    Add audit and control columns to the DataFrame.

    Args:
        df (DataFrame): Input Spark DataFrame.
        source_path (bool): Whether to add source file path column. Default is False.
        user (bool): Whether to add the current user column. Default is False.
        source_system (Optional[str]): Source system name. Default is None.
        batch_id (Optional[str]): Batch ID. If None, a semantic ID is auto-generated.
        add_hash (bool): Whether to add a row hash column. Default is False.
        lst_hash_columns (Optional[List[str]]): Columns to include in the hash. If None, all columns are used.
        version (str): Layout version; 'v1' uses 'sys_file_path', 'v2' uses 'sys_source_file_path'.
        timezone (str): Timezone for timestamps. Default is 'America/Sao_Paulo'.
        default_file_path (Optional[str]): Fallback file path if metadata is unavailable.
        pipeline_name (Optional[str]): Pipeline name to tag rows with.
        log (Optional[logging.Logger]): Logger instance.

    Returns:
        DataFrame: Spark DataFrame with audit and control columns added.
    """
    logger = log or get_logger()

    def _add_hash_column(df: DataFrame, hash_columns: Optional[List[str]] = None) -> DataFrame:
        try:
            cols_to_hash = hash_columns or df.columns
            log_source = "hash_columns" if hash_columns else "all columns"
            logger.info(f"Using {log_source} for hashing: {cols_to_hash if hash_columns else len(cols_to_hash)}")

            missing = [c for c in cols_to_hash if c not in df.columns]
            if missing:
                logger.warning(f"Columns not found in DataFrame, skipping from hash: {missing}")
                cols_to_hash = [c for c in cols_to_hash if c in df.columns]

            if not cols_to_hash:
                raise ValueError("No valid columns available for hashing")

            result = df.withColumn(
                "sys_hash_row",
                F.sha2(
                    F.concat_ws("||", *[F.coalesce(F.col(c).cast("string"), F.lit("")) for c in cols_to_hash]),
                    256
                )
            )
            logger.info(f"Added sys_hash_row using {len(cols_to_hash)} columns")
            return result

        except Exception as e:
            logger.error(f"Failed to create sys_hash_row: {e}")
            raise

    def _add_batch_id_column(df: DataFrame, batch_id) -> DataFrame:
      try:
        if batch_id is None:
          from datetime import datetime
          from zoneinfo import ZoneInfo
          timestamp = datetime.now(ZoneInfo(timezone)).strftime('%Y%m%d_%H%M%S')
          context = source_system.lower().replace(' ', '_') if source_system else "unknown"
          batch_id = f"{context}_batch_{timestamp}"
          logger.info(f"Generated semantic batch_id: {batch_id}")
      except Exception as e:
          batch_id = str(uuid.uuid4())
          logger.warning(f"Falling back to UUID batch_id: {e}")

      return df.withColumn("sys_batch_id", F.lit(batch_id))

    def _add_path_column(df: DataFrame, version: str) -> DataFrame:
        column_name = "sys_file_path" if version == "v1" else "sys_source_file_path"
        try:
            if file_path:
                return df.withColumn(column_name, F.lit(file_path))
            elif "_metadata" in df.columns or any(c.startswith("_metadata") for c in df.schema.names):
                logger.info(f"Using _metadata.file_path for '{column_name}'")
                return df.withColumn(column_name, F.col("_metadata.file_path"))
            else:
                logger.info(f"Using input_file_name() for '{column_name}'")
                return df.withColumn(column_name, F.input_file_name())
        except Exception as e:
            logger.warning(f"Could not determine file path ({e}), using fallback")
            return df.withColumn(column_name, F.lit("logical_path_or_unknown"))

    def _add_user_column(df: DataFrame) -> DataFrame:
        try:
            from IPython import get_ipython
            ipython = get_ipython()
            if ipython and "dbutils" in ipython.user_ns:
                dbutils = ipython.user_ns["dbutils"]
            elif "dbutils" in globals():
                dbutils = globals()["dbutils"]
            else:
                dbutils = None

            current_user = (
                dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
                if dbutils else "unknown"
            )
        except Exception as e:
            logger.warning(f"Failed to retrieve user: {e}")
            current_user = "unknown"

        return df.withColumn("sys_user", F.lit(current_user))

    # --- Pipeline ---
    result_df = df

    if is_hash:
        result_df = _add_hash_column(result_df, hash_columns)

    result_df = (
        result_df
        .withColumn(
            "sys_load_date",
            F.date_format(F.current_date(), "yyyy-MM-dd")
        )
        .withColumn(
            "sys_load_timestamp",
            F.from_utc_timestamp(F.current_timestamp(), timezone)
        )
    )

    if is_batch_id:
      result_df = _add_batch_id_column(result_df, batch_id)

    if source_system is not None:
        result_df = result_df.withColumn("sys_source_system", F.lit(source_system))

    if is_source_path:
        result_df = _add_path_column(result_df, layout_version)

    if is_user:
        result_df = _add_user_column(result_df)

    if pipeline_name:
        result_df = result_df.withColumn("sys_exec_pipeline", F.lit(pipeline_name))

    return result_df


def add_audit_trail_columns(
    df: DataFrame,
    updated_by: Optional[str] = None,
    add_timestamp: bool = True,
    timezone: str = "America/Sao_Paulo",
) -> DataFrame:
    """
    Add update audit columns such as timestamp and user.

    Args:
        df (DataFrame): Input Spark DataFrame.
        updated_by (Optional[str]): Username or system performing the update.
        add_timestamp (bool): Whether to add a timestamp column. Default is True.
        timezone (str): Timezone to use for the timestamp.

    Returns:
        DataFrame: Spark DataFrame with audit trail columns.
    """
    result_df = df
    if add_timestamp:
        result_df = result_df.withColumn(
            "sys_updated_at",
            F.from_utc_timestamp(F.current_timestamp(), timezone)
        )
    if updated_by:
        result_df = result_df.withColumn("sys_updated_by", F.lit(updated_by))
    return result_df


def validate_control_columns(
    df: DataFrame,
    required_columns: Optional[List[str]] = None
) -> bool:
    """
    Validate whether required audit/control columns exist in the DataFrame.

    Args:
        df (DataFrame): Input Spark DataFrame.
        required_columns (Optional[List[str]]): List of required column names. Default includes main audit columns.

    Raises:
        ValueError: If any required column is missing.

    Returns:
        bool: True if all required columns exist.
    """
    required = required_columns or [
        "sys_load_date", "sys_load_timestamp", "sys_user", "sys_batch_id"
    ]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing audit/control columns: {missing}")
    return True


def check_row_duplicates(
    df: DataFrame,
    hash_column: str = "sys_hash_row"
) -> DataFrame:
    """
    Identify duplicate rows based on a hash column.

    Args:
        df (DataFrame): Input Spark DataFrame.
        hash_column (str): Name of the column used for duplicate detection.

    Returns:
        DataFrame: DataFrame containing duplicated hash values and their counts.
    """
    return (
        df.groupBy(hash_column)
          .count()
          .filter(F.col("count") > 1)
    )


def add_metadata_columns(
    df: DataFrame,
    metadata: Dict[str, Any]
) -> DataFrame:
    """
    Add custom metadata columns to the DataFrame.

    Args:
        df (DataFrame): Input Spark DataFrame.
        metadata (Dict[str, Any]): Dictionary of key-value pairs to add as columns.

    Returns:
        DataFrame: DataFrame with metadata columns added.
    """
    result_df = df
    for key, value in metadata.items():
        result_df = result_df.withColumn(f"meta_{key}", F.lit(value))
    return result_df
