from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

from hetzner_mcp.models import HttpResult
from hetzner_mcp.registry import OperationRegistry
from hetzner_mcp.server import (
    DOCS_TO_EXEC_MAX_INTERACTIONS,
    EXECUTION_RELEVANCE_MAX_INTERACTIONS,
    HetznerMCPApplication,
)


@dataclass
class _DummyClient:
    def execute(
        self,
        *,
        operation: Any,
        path_params: dict[str, Any],
        query_params: dict[str, Any],
        body: Any,
    ) -> HttpResult:
        return HttpResult(
            ok=True,
            status_code=200,
            headers={},
            data={
                "operation": operation.operation_id,
                "path_params": path_params,
                "query_params": query_params,
                "body": body,
            },
            raw_text="",
            request_url="https://example.invalid/request",
            retries=0,
        )


def _app() -> HetznerMCPApplication:
    registry = OperationRegistry.load(refresh_specs=False)
    return HetznerMCPApplication(registry=registry, client=_DummyClient())


def test_list_tools_includes_full_dynamic_set() -> None:
    app = _app()
    tools = app.list_tools()

    names = {tool.name for tool in tools}
    assert "list_api_operations" in names
    assert "get_api_operation_details" in names
    assert "search_api_operations" in names
    assert "list_api_categories" in names
    assert "get_api_category_details" in names
    assert "wait_for_action" in names
    assert "create_server" in names
    assert "create_storage_box" in names
    assert "guide_create_server" in names
    assert "guide_create_storage_box" in names

    category_count = len(app.registry.all_categories())
    helper_count = 6
    expected_tools = (app.registry.operation_count * 2) + category_count + helper_count
    assert len(tools) == expected_tools


def test_get_api_operation_details_helper() -> None:
    app = _app()
    result = asyncio.run(
        app.call_tool(
            name="get_api_operation_details",
            arguments={"operation_id": "create_server"},
        )
    )
    assert result.isError is False
    assert result.structuredContent is not None
    assert result.structuredContent["operation_id"] == "create_server"


def test_operation_call_routes_to_http_client() -> None:
    app = _app()
    unlock = asyncio.run(
        app.call_tool(
            name="guide_get_action",
            arguments={},
            session_key="session-a",
        )
    )
    assert unlock.isError is False

    result = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )

    assert result.isError is False
    assert result.structuredContent is not None
    assert result.structuredContent["status_code"] == 200
    response = result.structuredContent["response"]
    assert response["operation"] == "get_action"
    assert response["path_params"] == {"id": 123}


def test_operation_requires_docs_first_in_same_session() -> None:
    app = _app()

    blocked = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )
    assert blocked.isError is True
    assert blocked.structuredContent is not None
    assert blocked.structuredContent["error"]["code"] == "docs_required"

    unlocked = asyncio.run(
        app.call_tool(
            name="guide_get_action",
            arguments={},
            session_key="session-a",
        )
    )
    assert unlocked.isError is False

    allowed = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )
    assert allowed.isError is False


def test_docs_unlock_is_session_scoped() -> None:
    app = _app()

    unlock = asyncio.run(
        app.call_tool(
            name="guide_get_action",
            arguments={},
            session_key="session-a",
        )
    )
    assert unlock.isError is False

    blocked_other_session = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-b",
        )
    )
    assert blocked_other_session.isError is True
    assert blocked_other_session.structuredContent is not None
    assert blocked_other_session.structuredContent["error"]["code"] == "docs_required"


def test_docs_unlock_expires_by_interaction_distance_before_first_execution() -> None:
    app = _app()

    unlock = asyncio.run(
        app.call_tool(
            name="guide_get_action",
            arguments={},
            session_key="session-a",
        )
    )
    assert unlock.isError is False

    for _ in range(DOCS_TO_EXEC_MAX_INTERACTIONS + 1):
        noop = asyncio.run(
            app.call_tool(
                name="list_api_operations",
                arguments={"limit": 1},
                session_key="session-a",
            )
        )
        assert noop.isError is False

    blocked = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )
    assert blocked.isError is True
    assert blocked.structuredContent is not None
    assert blocked.structuredContent["error"]["code"] == "docs_required"


def test_recent_execution_keeps_endpoint_unlocked_without_reread() -> None:
    app = _app()

    unlock = asyncio.run(
        app.call_tool(
            name="guide_get_action",
            arguments={},
            session_key="session-a",
        )
    )
    assert unlock.isError is False

    first_exec = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )
    assert first_exec.isError is False

    for _ in range(EXECUTION_RELEVANCE_MAX_INTERACTIONS - 2):
        noop = asyncio.run(
            app.call_tool(
                name="list_api_operations",
                arguments={"limit": 1},
                session_key="session-a",
            )
        )
        assert noop.isError is False

    second_exec = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )
    assert second_exec.isError is False


def test_stale_execution_requires_reread_after_context_drift() -> None:
    app = _app()

    unlock = asyncio.run(
        app.call_tool(
            name="guide_get_action",
            arguments={},
            session_key="session-a",
        )
    )
    assert unlock.isError is False

    first_exec = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )
    assert first_exec.isError is False

    for _ in range(EXECUTION_RELEVANCE_MAX_INTERACTIONS + 1):
        noop = asyncio.run(
            app.call_tool(
                name="list_api_operations",
                arguments={"limit": 1},
                session_key="session-a",
            )
        )
        assert noop.isError is False

    blocked = asyncio.run(
        app.call_tool(
            name="get_action",
            arguments={"path": {"id": 123}},
            session_key="session-a",
        )
    )
    assert blocked.isError is True
    assert blocked.structuredContent is not None
    assert blocked.structuredContent["error"]["code"] == "docs_required"


def test_endpoint_guide_tool_returns_detailed_docs_payload() -> None:
    app = _app()
    result = asyncio.run(
        app.call_tool(
            name="guide_create_server",
            arguments={},
        )
    )

    assert result.isError is False
    assert result.structuredContent is not None
    assert result.structuredContent["operation"]["operation_id"] == "create_server"
    assert "what_it_is_for" in result.structuredContent
    assert result.structuredContent["execute_tool"] == "create_server"


def test_category_guide_tool_returns_category_docs_payload() -> None:
    app = _app()
    category = app.registry.get_category("cloud:servers")
    result = asyncio.run(
        app.call_tool(
            name=category.tool_name,
            arguments={},
        )
    )

    assert result.isError is False
    assert result.structuredContent is not None
    assert result.structuredContent["category"]["category_id"] == "cloud:servers"
    assert len(result.structuredContent["operations"]) >= 1
