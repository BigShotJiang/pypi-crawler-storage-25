"""Sherpa reconciliation processor"""

__version__ = "0.6.25"
