# 腾讯广告 Marketing API v3 使用说明

新模块路径：`lazyad.open.qq_v3`

这个模块不改动旧的 `lazyad.open.qq`，适合新代码直接接入腾讯广告官方 v3.0 文档。当前覆盖旧模块里已有的功能：

- 获取/刷新 OAuth token
- 查询组织下广告账户
- 查询业务单元下广告账户
- 查询广告主账号所属业务单元
- 查询广告主日预算
- 批量修改广告主日预算
- 获取广告主/业务单元日报表和分页拉取日报表
- 获取/更新广告
- 获取/更新动态创意

官方入口：

- 开发者注册：https://developers.e.qq.com/v3.0/pages/regist_developer
- OAuth token：https://developers.e.qq.com/v3.0/docs/api/oauth/token
- 日报表：https://developers.e.qq.com/v3.0/docs/api/daily_reports/get

## 授权

```python
from lazyad.open.qq_v3 import oauth_token

response = oauth_token(
    app_id=123456,
    app_secret="your_app_secret",
    grant_type="authorization_code",
    authorization_code="authorization_code_from_callback",
    redirect_uri="https://example.com/callback",
)

access_token = response["data"]["access_token"]
```

刷新 token：

```python
from lazyad.open.qq_v3 import oauth_token

response = oauth_token(
    app_id=123456,
    app_secret="your_app_secret",
    grant_type="refresh_token",
    refresh_token="your_refresh_token",
)
```

注意：官方文档说明 OAuth token 接口不需要 `access_token`、`timestamp`、`nonce`，新模块不会给 token 接口附加这些参数。

## 创建客户端

```python
from lazyad.open.qq_v3 import TencentAdsClient

client = TencentAdsClient(
    access_token="your_access_token",
    user_token="your_user_token",  # 受限写接口需要时传
)
```

`user_token` 是实名认证要求参数。更新广告、更新创意、修改预算等受限接口需要时传；如果构造客户端时没传，也可以在具体方法里传。

## 查询组织下广告账户

```python
from lazyad.open.qq_v3 import get_organization_account_relation

response = get_organization_account_relation(
    access_token="your_access_token",
    pagination_mode="PAGINATION_MODE_CURSOR",
    page_size=100,
)
```

游标翻页时，第一次不需要传 `cursor`；后续请求传接口返回的 `cursor`。

```python
response = get_organization_account_relation(
    access_token="your_access_token",
    pagination_mode="PAGINATION_MODE_CURSOR",
    cursor=123456,
    page_size=100,
)
```

## 查询业务单元下广告账户

官方 `organization_account_relation/get` 使用 `business_unit_id` 过滤业务单元下的广告账户。新模块封装了语义化方法：

```python
from lazyad.open.qq_v3 import get_business_unit_accounts

response = get_business_unit_accounts(
    access_token="your_access_token",
    business_unit_id=999999,
    pagination_mode="PAGINATION_MODE_CURSOR",
    page_size=100,
)
```

用客户端调用：

```python
client = TencentAdsClient(access_token="your_access_token")

response = client.get_business_unit_accounts(
    business_unit_id=999999,
    page_size=100,
)
```

游标分页拉取全部账户：

```python
accounts = client.get_business_unit_accounts_all(
    business_unit_id=999999,
    page_size=100,
)
```

只查询指定广告主类型：

```python
accounts = client.get_business_unit_accounts_all(
    business_unit_id=999999,
    advertiser_type="SUB_ADVERTISER",
)
```

## 查询广告主账号所属业务单元

官方 `business_unit_account/get` 用于根据广告主账号列表查询对应的客户业务单元信息。

```python
from lazyad.open.qq_v3 import get_account_business_units

response = get_account_business_units(
    access_token="your_access_token",
    account_id_list=[111111, 222222],
)
```

用客户端调用：

```python
client = TencentAdsClient(access_token="your_access_token")

response = client.get_account_business_units(
    account_id_list=[111111, 222222],
)
```

如果需要保持和官方接口路径一致的命名，也可以使用：

```python
response = client.business_unit_account_get(
    account_id_list=[111111, 222222],
)
```

## 查询广告主日预算

```python
from lazyad.open.qq_v3 import get_advertiser_daily_budget

response = get_advertiser_daily_budget(
    access_token="your_access_token",
    account_id=111111,
)
```

## 修改广告主日预算

单账户：

```python
from lazyad.open.qq_v3 import update_daily_budget

response = update_daily_budget(
    access_token="your_access_token",
    account_id=111111,
    daily_budget=1000000,  # 单位：分
    user_token="your_user_token",
)
```

批量：

```python
from lazyad.open.qq_v3 import update_daily_budget

response = update_daily_budget(
    access_token="your_access_token",
    user_token="your_user_token",
    update_daily_budget_spec=[
        {"account_id": 111111, "daily_budget": 1000000},
        {"account_id": 222222, "daily_budget": 5000000},
    ],
)
```

## 获取日报表

```python
from lazyad.open.qq_v3 import TencentAdsClient

client = TencentAdsClient(access_token="your_access_token")

response = client.get_daily_reports(
    account_id=111111,
    level="REPORT_LEVEL_DYNAMIC_CREATIVE",
    start_date="2026-04-01",
    end_date="2026-04-01",
    fields=["date", "account_id", "dynamic_creative_id", "cost"],
    group_by=["date", "dynamic_creative_id"],
    page=1,
    page_size=100,
)
```

分页拉取并把金额字段从“分”转成“元”：

```python
rows = client.get_daily_reports_day_all(
    account_id=111111,
    level="REPORT_LEVEL_DYNAMIC_CREATIVE",
    start_date="2026-04-01",
    end_date="2026-04-01",
    cost_min=10,
)
```

官方同步日报表限制 `page * page_size <= 20000`。超过这个规模时应使用异步报表任务。

## 获取业务单元日报表

官方 `daily_reports/get` 里使用 `organization_id` 表示业务单元 id。新模块对外统一命名为 `business_unit_id`：

```python
response = client.get_business_unit_daily_reports(
    business_unit_id=999999,
    level="REPORT_LEVEL_DYNAMIC_CREATIVE",
    start_date="2026-04-01",
    end_date="2026-04-01",
    fields=["date", "account_id", "dynamic_creative_id", "cost"],
    group_by=["date", "dynamic_creative_id"],
    page=1,
    page_size=100,
)
```

如果还需要限定某个广告主账户，可以同时传 `account_id`：

```python
response = client.get_business_unit_daily_reports(
    business_unit_id=999999,
    account_id=111111,
    level="REPORT_LEVEL_DYNAMIC_CREATIVE",
    start_date="2026-04-01",
    end_date="2026-04-01",
)
```

分页拉取业务单元日报表：

```python
rows = client.get_business_unit_daily_reports_all(
    business_unit_id=999999,
    level="REPORT_LEVEL_DYNAMIC_CREATIVE",
    start_date="2026-04-01",
    end_date="2026-04-01",
    cost_min=10,
)
```

注意：官方文档说明查询业务单元报表时，`level` 只支持组件层级。实际可用枚举以官方接口文档和账户权限为准。

## 获取广告

```python
response = client.adgroups_get(
    account_id=111111,
    fields=["adgroup_id", "adgroup_name", "configured_status", "system_status"],
    filtering=[
        {
            "field": "configured_status",
            "operator": "EQUALS",
            "values": ["AD_STATUS_NORMAL"],
        }
    ],
)
```

## 更新广告状态

```python
response = client.adgroups_update(
    account_id=111111,
    adgroup_id=333333,
    configured_status="AD_STATUS_SUSPEND",
)
```

如果没有在客户端里配置 `user_token`：

```python
response = client.adgroups_update(
    account_id=111111,
    adgroup_id=333333,
    configured_status="AD_STATUS_NORMAL",
    user_token="your_user_token",
)
```

## 获取动态创意

```python
response = client.dynamic_creatives_get(
    account_id=111111,
    fields=[
        "dynamic_creative_id",
        "dynamic_creative_name",
        "configured_status",
        "system_status",
    ],
    pagination_mode="PAGINATION_MODE_CURSOR",
)
```

## 更新动态创意状态

```python
response = client.dynamic_creatives_update(
    account_id=111111,
    dynamic_creative_id=444444,
    configured_status="AD_STATUS_SUSPEND",
)
```

## 兼容旧命名

新模块保留了旧模块里的部分命名，便于迁移：

```python
from lazyad.open.qq_v3 import DevelopersEQQ, oauth_token2, oauth_token3

client = DevelopersEQQ(access_token="your_access_token")
```

`oauth_token2()` 和 `oauth_token3()` 会走官方当前 token 地址，并且不会给 OAuth 接口附加通用参数。
