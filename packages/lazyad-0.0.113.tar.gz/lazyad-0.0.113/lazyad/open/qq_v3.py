"""
Tencent Ads Marketing API v3 helpers.

This module is independent from ``lazyad.open.qq``. It follows the current
v3.0 API docs and keeps compatibility aliases for the old function/class names
where practical.
"""

from datetime import datetime, timedelta, timezone
import json
import time
import uuid

from lazysdk import lazyrequests


API_BASE_URL = "https://api.e.qq.com"
API_V3_BASE_URL = f"{API_BASE_URL}/v3.0"
OAUTH_TOKEN_URL = f"{API_BASE_URL}/oauth/token"

PAGINATION_MODE_NORMAL = "PAGINATION_MODE_NORMAL"
PAGINATION_MODE_CURSOR = "PAGINATION_MODE_CURSOR"


def make_nonce():
    """
    Return a globally unique nonce string.

    Tencent Ads global parameters require nonce length <= 32 characters.
    ``uuid4().hex`` is exactly 32 characters.
    """
    return uuid.uuid4().hex


def _today_gmt8():
    return datetime.now(timezone(timedelta(hours=8))).strftime("%Y-%m-%d")


def _json_encode_get_params(params):
    """
    Encode GET params according to Tencent Ads examples.

    Lists and structs are sent as JSON strings. Scalars are left as-is. ``None``
    values are dropped so optional parameters are truly omitted.
    """
    encoded = {}
    for key, value in params.items():
        if value is None:
            continue
        if isinstance(value, (dict, list, bool)):
            encoded[key] = json.dumps(value, ensure_ascii=False)
        else:
            encoded[key] = value
    return encoded


def _common_params(access_token, user_token=None):
    params = {
        "access_token": access_token,
        "timestamp": int(time.time()),
        "nonce": make_nonce(),
    }
    if user_token:
        params["user_token"] = user_token
    return params


def _get(url, access_token, params=None, user_token=None):
    request_params = _common_params(access_token=access_token, user_token=user_token)
    if params:
        request_params.update(params)
    return lazyrequests.lazy_requests(
        method="GET",
        url=url,
        params=_json_encode_get_params(request_params),
    )


def _post_json(url, access_token, data, user_token=None):
    return lazyrequests.lazy_requests(
        method="POST",
        url=url,
        params=_json_encode_get_params(
            _common_params(access_token=access_token, user_token=user_token)
        ),
        json=data,
    )


def oauth_token(
        app_id,
        app_secret,
        grant_type="authorization_code",
        authorization_code=None,
        refresh_token=None,
        redirect_uri=None,
):
    """
    Get or refresh OAuth access token.

    Docs: https://developers.e.qq.com/v3.0/docs/api/oauth/token

    OAuth APIs do not use ``access_token``, ``timestamp`` or ``nonce``.
    ``authorization_code`` is required when ``grant_type`` is
    ``authorization_code``. ``refresh_token`` is required when ``grant_type`` is
    ``refresh_token``.
    """
    params = {
        "client_id": app_id,
        "client_secret": app_secret,
        "grant_type": grant_type,
    }
    if authorization_code:
        params["authorization_code"] = authorization_code
    if refresh_token:
        params["refresh_token"] = refresh_token
    if redirect_uri:
        params["redirect_uri"] = redirect_uri

    return lazyrequests.lazy_requests(
        method="GET",
        url=OAUTH_TOKEN_URL,
        params=_json_encode_get_params(params),
    )


def oauth_token2(
        app_id,
        app_secret,
        redirect_uri,
        grant_type="authorization_code",
        auth_code=None,
        refresh_token=None,
):
    """
    Compatibility wrapper for the old ``oauth_token2`` name.
    """
    return oauth_token(
        app_id=app_id,
        app_secret=app_secret,
        grant_type=grant_type,
        authorization_code=auth_code,
        refresh_token=refresh_token,
        redirect_uri=redirect_uri,
    )


def oauth_token3(
        app_id,
        app_secret,
        redirect_uri=None,
        access_token=None,
        grant_type="authorization_code",
        auth_code=None,
        refresh_token=None,
):
    """
    Compatibility wrapper for the old ``oauth_token3`` name.

    ``access_token`` is accepted for call compatibility but intentionally not
    sent, because the official OAuth token endpoint does not use global params.
    """
    _ = access_token
    return oauth_token(
        app_id=app_id,
        app_secret=app_secret,
        grant_type=grant_type,
        authorization_code=auth_code,
        refresh_token=refresh_token,
        redirect_uri=redirect_uri,
    )


def get_organization_account_relation(
        access_token,
        account_id=None,
        advertiser_type=None,
        business_unit_id=None,
        cursor=None,
        page=1,
        page_size=100,
        pagination_mode=PAGINATION_MODE_CURSOR,
):
    """
    Query advertiser accounts under an organization.

    Docs:
    https://developers.e.qq.com/v3.0/docs/api/organization_account_relation/get
    """
    params = {
        "account_id": account_id,
        "advertiser_type": advertiser_type,
        "business_unit_id": business_unit_id,
        "pagination_mode": pagination_mode,
        "page_size": page_size,
    }
    if pagination_mode == PAGINATION_MODE_NORMAL:
        params["page"] = page
    elif pagination_mode == PAGINATION_MODE_CURSOR:
        params["cursor"] = cursor
    else:
        raise ValueError(
            "pagination_mode must be PAGINATION_MODE_NORMAL or "
            "PAGINATION_MODE_CURSOR"
        )

    return _get(
        url=f"{API_V3_BASE_URL}/organization_account_relation/get",
        access_token=access_token,
        params=params,
    )


def get_business_unit_accounts(
        access_token,
        business_unit_id,
        advertiser_type=None,
        cursor=None,
        page=1,
        page_size=100,
        pagination_mode=PAGINATION_MODE_CURSOR,
):
    """
    Query advertiser accounts under a business unit.

    This is a semantic wrapper around
    ``organization_account_relation/get`` with ``business_unit_id`` set.
    """
    return get_organization_account_relation(
        access_token=access_token,
        advertiser_type=advertiser_type,
        business_unit_id=business_unit_id,
        cursor=cursor,
        page=page,
        page_size=page_size,
        pagination_mode=pagination_mode,
    )


def get_business_unit_accounts_all(
        access_token,
        business_unit_id,
        advertiser_type=None,
        page_size=100,
        max_pages=1000,
):
    """
    Fetch all advertiser accounts under a business unit with cursor pagination.
    """
    accounts = []
    cursor = None
    for _ in range(max_pages):
        response = get_business_unit_accounts(
            access_token=access_token,
            business_unit_id=business_unit_id,
            advertiser_type=advertiser_type,
            cursor=cursor,
            page_size=page_size,
            pagination_mode=PAGINATION_MODE_CURSOR,
        )
        if not isinstance(response, dict) or response.get("code") != 0:
            break

        data = response.get("data") or {}
        accounts.extend(data.get("list") or [])

        cursor_page_info = data.get("cursor_page_info") or {}
        if not cursor_page_info.get("has_more"):
            break
        cursor = cursor_page_info.get("cursor")
        if cursor is None:
            break

    return accounts


def get_account_business_units(access_token, account_id_list):
    """
    Query business units that advertiser accounts belong to.

    Docs: https://developers.e.qq.com/v3.0/docs/api/business_unit_account/get
    """
    return _post_json(
        url=f"{API_V3_BASE_URL}/business_unit_account/get",
        access_token=access_token,
        data={"account_id_list": account_id_list},
    )


def business_unit_account_get(access_token, account_id_list):
    """
    Compatibility-style wrapper for ``business_unit_account/get``.
    """
    return get_account_business_units(
        access_token=access_token,
        account_id_list=account_id_list,
    )


def get_advertiser_daily_budget(
        access_token,
        account_id,
        fields=None,
):
    """
    Get advertiser daily budget.

    Docs: https://developers.e.qq.com/v3.0/docs/api/advertiser_daily_budget/get
    """
    if fields is None:
        fields = ["account_id", "daily_budget", "min_daily_budget"]
    return _get(
        url=f"{API_V3_BASE_URL}/advertiser_daily_budget/get",
        access_token=access_token,
        params={
            "account_id": account_id,
            "fields": fields,
        },
    )


def update_daily_budget(
        access_token,
        account_id=None,
        daily_budget=None,
        update_daily_budget_spec=None,
        use_min_daily_budget=None,
        user_token=None,
):
    """
    Batch update advertiser daily budget.

    Docs: https://developers.e.qq.com/v3.0/docs/api/advertiser/update_daily_budget
    """
    if update_daily_budget_spec is None:
        if account_id is None or daily_budget is None:
            raise ValueError(
                "account_id and daily_budget are required when "
                "update_daily_budget_spec is not provided"
            )
        item = {
            "account_id": account_id,
            "daily_budget": daily_budget,
        }
        if use_min_daily_budget is not None:
            item["use_min_daily_budget"] = use_min_daily_budget
        update_daily_budget_spec = [item]

    return _post_json(
        url=f"{API_V3_BASE_URL}/advertiser/update_daily_budget",
        access_token=access_token,
        user_token=user_token,
        data={"update_daily_budget_spec": update_daily_budget_spec},
    )


class TencentAdsClient:
    """
    Small client for Tencent Ads Marketing API v3.
    """

    def __init__(self, access_token, user_token=None):
        self.access_token = access_token
        self.user_token = user_token

    def get_daily_reports(
            self,
            account_id,
            level,
            page=1,
            page_size=100,
            start_date=None,
            end_date=None,
            fields=None,
            group_by=None,
            filtering=None,
            order_by=None,
            time_line="REQUEST_TIME",
            organization_id=None,
    ):
        """
        Get daily reports.

        Docs: https://developers.e.qq.com/v3.0/docs/api/daily_reports/get
        """
        if start_date is None:
            start_date = _today_gmt8()
        if end_date is None:
            end_date = _today_gmt8()
        if fields is None:
            fields = ["account_id", "date", "cost"]
        if group_by is None:
            group_by = ["date"]

        params = {
            "account_id": account_id,
            "level": level,
            "time_line": time_line,
            "date_range": {
                "start_date": start_date,
                "end_date": end_date,
            },
            "group_by": group_by,
            "order_by": order_by,
            "page": page,
            "page_size": page_size,
            "fields": fields,
            "filtering": filtering,
            "organization_id": organization_id,
        }
        return _get(
            url=f"{API_V3_BASE_URL}/daily_reports/get",
            access_token=self.access_token,
            params=params,
        )

    def get_business_unit_daily_reports(
            self,
            business_unit_id,
            level,
            account_id=None,
            page=1,
            page_size=100,
            start_date=None,
            end_date=None,
            fields=None,
            group_by=None,
            filtering=None,
            order_by=None,
            time_line="REQUEST_TIME",
    ):
        """
        Get daily reports by business unit.

        Tencent Ads uses ``organization_id`` for the business unit id in
        ``daily_reports/get``.
        """
        return self.get_daily_reports(
            account_id=account_id,
            level=level,
            page=page,
            page_size=page_size,
            start_date=start_date,
            end_date=end_date,
            fields=fields,
            group_by=group_by,
            filtering=filtering,
            order_by=order_by,
            time_line=time_line,
            organization_id=business_unit_id,
        )

    def get_business_unit_daily_reports_all(
            self,
            business_unit_id,
            level,
            account_id=None,
            cost_min=None,
            start_date=None,
            end_date=None,
            fields=None,
            group_by=None,
            page_size=100,
            max_rows=20000,
            include_access_token=False,
    ):
        """
        Fetch all available report pages for a business unit.
        """
        if fields is None:
            fields = [
                "date",
                "account_id",
                "cost",
                "thousand_display_price",
                "valid_click_count",
                "conversions_count",
                "from_follow_uv",
                "dynamic_creative_id",
                "dynamic_creative_name",
                "scan_follow_user_count",
                "cpc",
                "scan_follow_user_cost",
                "income_val_1",
            ]
        if group_by is None:
            group_by = ["date", "dynamic_creative_id"]

        rows = []
        page = 1
        while page * page_size <= max_rows:
            response = self.get_business_unit_daily_reports(
                business_unit_id=business_unit_id,
                account_id=account_id,
                level=level,
                page=page,
                page_size=page_size,
                start_date=start_date,
                end_date=end_date,
                fields=fields,
                group_by=group_by,
            )
            if not isinstance(response, dict) or response.get("code") != 0:
                break

            data = response.get("data") or {}
            response_list = data.get("list") or []
            page_info = data.get("page_info") or {}
            total_page = page_info.get("total_page") or 0

            for item in response_list:
                cost = item.get("cost", 0) or 0
                cost_yuan = cost / 100
                if cost_min is not None and cost_yuan < cost_min:
                    continue

                normalized = dict(item)
                normalized["cost"] = cost_yuan
                normalized["thousand_display_price"] = (
                    (normalized.get("thousand_display_price", 0) or 0) / 100
                )
                normalized["fans_add"] = (
                    (normalized.get("conversions_count", 0) or 0)
                    + (normalized.get("from_follow_uv", 0) or 0)
                    + (normalized.get("scan_follow_user_count", 0) or 0)
                )
                if include_access_token:
                    normalized["access_token"] = self.access_token
                rows.append(normalized)

            if not response_list or page >= total_page:
                break
            page += 1

        return rows

    def get_business_unit_accounts(
            self,
            business_unit_id,
            advertiser_type=None,
            cursor=None,
            page=1,
            page_size=100,
            pagination_mode=PAGINATION_MODE_CURSOR,
    ):
        """
        Query advertiser accounts under a business unit.
        """
        return get_business_unit_accounts(
            access_token=self.access_token,
            business_unit_id=business_unit_id,
            advertiser_type=advertiser_type,
            cursor=cursor,
            page=page,
            page_size=page_size,
            pagination_mode=pagination_mode,
        )

    def get_business_unit_accounts_all(
            self,
            business_unit_id,
            advertiser_type=None,
            page_size=100,
            max_pages=1000,
    ):
        """
        Fetch all advertiser accounts under a business unit.
        """
        return get_business_unit_accounts_all(
            access_token=self.access_token,
            business_unit_id=business_unit_id,
            advertiser_type=advertiser_type,
            page_size=page_size,
            max_pages=max_pages,
        )

    def get_account_business_units(self, account_id_list):
        """
        Query business units that advertiser accounts belong to.
        """
        return get_account_business_units(
            access_token=self.access_token,
            account_id_list=account_id_list,
        )

    def business_unit_account_get(self, account_id_list):
        """
        Compatibility-style wrapper for ``business_unit_account/get``.
        """
        return self.get_account_business_units(account_id_list=account_id_list)

    def get_daily_reports_day_all(
            self,
            account_id,
            level,
            cost_min=None,
            start_date=None,
            end_date=None,
            fields=None,
            group_by=None,
            page_size=100,
            max_rows=20000,
            include_access_token=False,
    ):
        """
        Fetch all available pages for daily reports within API sync limits.

        The official sync report API requires ``page * page_size <= 20000``.
        Use Tencent Ads async report APIs for larger exports.
        """
        if fields is None:
            fields = [
                "date",
                "account_id",
                "cost",
                "thousand_display_price",
                "valid_click_count",
                "conversions_count",
                "from_follow_uv",
                "dynamic_creative_id",
                "dynamic_creative_name",
                "scan_follow_user_count",
                "cpc",
                "scan_follow_user_cost",
                "income_val_1",
            ]
        if group_by is None:
            group_by = ["date", "dynamic_creative_id"]

        rows = []
        page = 1
        while page * page_size <= max_rows:
            response = self.get_daily_reports(
                account_id=account_id,
                level=level,
                page=page,
                page_size=page_size,
                start_date=start_date,
                end_date=end_date,
                fields=fields,
                group_by=group_by,
            )
            if not isinstance(response, dict) or response.get("code") != 0:
                break

            data = response.get("data") or {}
            response_list = data.get("list") or []
            page_info = data.get("page_info") or {}
            total_page = page_info.get("total_page") or 0

            for item in response_list:
                cost = item.get("cost", 0) or 0
                cost_yuan = cost / 100
                if cost_min is not None and cost_yuan < cost_min:
                    continue

                normalized = dict(item)
                normalized["cost"] = cost_yuan
                normalized["thousand_display_price"] = (
                    (normalized.get("thousand_display_price", 0) or 0) / 100
                )
                normalized["fans_add"] = (
                    (normalized.get("conversions_count", 0) or 0)
                    + (normalized.get("from_follow_uv", 0) or 0)
                    + (normalized.get("scan_follow_user_count", 0) or 0)
                )
                if include_access_token:
                    normalized["access_token"] = self.access_token
                rows.append(normalized)

            if not response_list or page >= total_page:
                break
            page += 1

        return rows

    def adgroups_get(
            self,
            account_id,
            page=1,
            page_size=100,
            fields=None,
            filtering=None,
            is_deleted=False,
            pagination_mode=None,
            cursor=None,
    ):
        """
        Get adgroups.

        Docs: https://developers.e.qq.com/v3.0/docs/api/adgroups/get
        """
        if fields is None:
            fields = ["account_id", "system_status", "configured_status"]
        params = {
            "account_id": account_id,
            "page": page,
            "page_size": page_size,
            "is_deleted": is_deleted,
            "fields": fields,
            "filtering": filtering,
            "pagination_mode": pagination_mode,
            "cursor": cursor,
        }
        return _get(
            url=f"{API_V3_BASE_URL}/adgroups/get",
            access_token=self.access_token,
            params=params,
        )

    def adgroups_update(
            self,
            account_id,
            adgroup_id,
            configured_status=None,
            user_token=None,
            **kwargs,
    ):
        """
        Update an adgroup.

        Docs: https://developers.e.qq.com/v3.0/docs/api/adgroups/update
        """
        data = {
            "account_id": account_id,
            "adgroup_id": adgroup_id,
        }
        if configured_status is not None:
            data["configured_status"] = configured_status
        data.update({key: value for key, value in kwargs.items() if value is not None})
        return _post_json(
            url=f"{API_V3_BASE_URL}/adgroups/update",
            access_token=self.access_token,
            user_token=user_token or self.user_token,
            data=data,
        )

    def dynamic_creatives_get(
            self,
            account_id,
            page=1,
            page_size=100,
            fields=None,
            filtering=None,
            is_deleted=False,
            pagination_mode=None,
            cursor=None,
    ):
        """
        Get dynamic creatives.

        Docs: https://developers.e.qq.com/v3.0/docs/api/dynamic_creatives/get
        """
        if fields is None:
            fields = [
                "account_id",
                "dynamic_creative_id",
                "dynamic_creative_name",
                "configured_status",
                "system_status",
                "is_deleted",
            ]
        params = {
            "account_id": account_id,
            "page": page,
            "page_size": page_size,
            "is_deleted": is_deleted,
            "fields": fields,
            "filtering": filtering,
            "pagination_mode": pagination_mode,
            "cursor": cursor,
        }
        return _get(
            url=f"{API_V3_BASE_URL}/dynamic_creatives/get",
            access_token=self.access_token,
            params=params,
        )

    def dynamic_creatives_update(
            self,
            account_id,
            dynamic_creative_id,
            configured_status=None,
            user_token=None,
            **kwargs,
    ):
        """
        Update a dynamic creative.

        Docs: https://developers.e.qq.com/v3.0/docs/api/dynamic_creatives/update
        """
        data = {
            "account_id": account_id,
            "dynamic_creative_id": dynamic_creative_id,
        }
        if configured_status is not None:
            data["configured_status"] = configured_status
        data.update({key: value for key, value in kwargs.items() if value is not None})
        return _post_json(
            url=f"{API_V3_BASE_URL}/dynamic_creatives/update",
            access_token=self.access_token,
            user_token=user_token or self.user_token,
            data=data,
        )


class DevelopersEQQ(TencentAdsClient):
    """
    Compatibility alias for the old client class name.
    """
