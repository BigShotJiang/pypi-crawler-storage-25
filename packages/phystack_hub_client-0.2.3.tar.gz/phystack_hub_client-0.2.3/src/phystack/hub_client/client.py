"""
PhyHub Client

Main client for connecting to PhyHub and communicating with twins.
Provides events, actions, DataChannel, and MediaStream functionality.
"""

import asyncio
from typing import Any, Callable, Optional, Set

from phystack.hub_client.services.phyhub_connection import (
    PhyHubConnection,
    ConnectionConfig,
    ConnectionMode,
)
from phystack.hub_client.twin_messaging import (
    TwinMessaging,
    TwinMessagingContext,
    create_twin_messaging,
)
from phystack.hub_client.types.twin_types import (
    TwinMessageResult,
    TwinMessageResultStatus,
    TwinResponse,
    TwinProperties,
    TwinTypeEnum,
    EventPayload,
)
from phystack.hub_client.services.webrtc.data_channel import (
    DataChannelHandler,
    DataChannelOptions,
    PhygridDataChannel,
    TwinMessagingInterface as DataChannelMessaging,
)
from phystack.hub_client.services.webrtc.media_stream import (
    MediaStreamHandler,
    MediaStreamOptions,
    PhygridMediaStream,
    TwinMessagingInterface as MediaStreamMessaging,
)
from phystack.hub_client.instances.edge_instance import EdgeInstance
from phystack.hub_client.instances.peripheral_instance import PeripheralInstance
from phystack.hub_client.twin_registry import TwinRegistry


class PhyHubClient:
    """Client for connecting to PhyHub.

    Provides:
    - Connection management
    - Twin messaging (events and actions)
    - DataChannel (WebRTC P2P data)
    - MediaStream (WebRTC P2P video/audio)

    Usage:
        async with PhyHubClient.from_env() as client:
            instance = await client.get_instance()
            instance.on("my-event", lambda data, respond: print(data))
    """

    # Socket.IO event names
    class EVENTS:
        CONNECT = "connect"
        DISCONNECT = "disconnect"
        TWIN_MESSAGE = "twinMessage"
        TWIN_SUBSCRIBE = "twinSubscribe"
        TWIN_UPDATED = "twinUpdated"
        GET_TWIN_BY_ID = "getTwinById"
        REPORT_SCREEN_PROPERTIES = "reportScreenTwinProperties"
        REPORT_EDGE_PROPERTIES = "reportEdgeTwinProperties"
        REPORT_PERIPHERAL_PROPERTIES = "reportPeripheralTwinProperties"
        GET_DEVICE_STATUS = "getDeviceStatus"
        GET_DEVICE_INSTANCE = "getDeviceInstance"
        GET_DEVICE_NETWORKS = "getDeviceNetworks"

    def __init__(
        self,
        device_id: Optional[str] = None,
        access_key: Optional[str] = None,
        phyhub_url: Optional[str] = None,
        instance_id: Optional[str] = None,
    ) -> None:
        """Initialize PhyHub client.

        Args:
            device_id: Device identifier.
            access_key: Access key for authentication.
            phyhub_url: PhyHub server URL.
            instance_id: Optional specific twin ID to use.
        """
        self._connection: Optional[PhyHubConnection] = None
        self._instance_id: Optional[str] = instance_id
        self._instance: Optional[EdgeInstance] = None
        self._subscribed_twins: Set[str] = set()
        self._twin_message_listeners: dict[str, Set[Callable[[dict[str, Any]], None]]] = {}
        self._twin_update_listeners: dict[str, Set[Callable[[dict[str, Any]], None]]] = {}
        self._twin_data_cache: dict[str, dict[str, Any]] = {}
        self._connected = False
        self._registry: Optional[TwinRegistry] = None

        if device_id and access_key:
            self._connection = PhyHubConnection(
                ConnectionConfig(
                    mode=ConnectionMode.DIRECT,
                    url=phyhub_url or "https://phyhub.eu.omborigrid.net",
                    device_id=device_id,
                    access_key=access_key,
                    instance_id=instance_id,
                )
            )

    @classmethod
    def from_env(cls) -> "PhyHubClient":
        """Create client from environment variables.

        Environment variables:
            DEVICE_ID or PHYGRID_DEVICE_ID: Device identifier
            ACCESS_KEY or PHYGRID_DEVICE_KEY: Access key
            PHYHUB_URL or PHYHUB_REGION: Server URL or region (eu, us, etc.)
            TWIN_ID or INSTANCE_ID: Optional specific twin ID

        Returns:
            Configured PhyHubClient instance.
        """
        client = cls()
        client._connection = PhyHubConnection.from_env()
        client._instance_id = client._connection.instance_id
        return client

    @property
    def is_connected(self) -> bool:
        """Check if connected to PhyHub."""
        return self._connected and self._connection is not None

    async def connect(self) -> "PhyHubClient":
        """Connect to PhyHub.

        Returns:
            Self for chaining.

        Raises:
            ConnectionError: If connection fails.
        """
        if not self._connection:
            raise ValueError("No connection configured. Use from_env() or provide credentials.")

        await self._connection.connect()
        self._connected = True

        # Create twin registry
        self._registry = TwinRegistry(self)

        # Set up event handlers
        self._setup_socket_listeners()

        # Only direct mode needs explicit authenticate/connectDevice handshake.
        # PhyOS and Simulator handle auth at Socket.IO connection time.
        if self._connection.is_direct:
            await self._initialize_device_twin()
        else:
            print(f"[PhyHubClient] Connected ({self._connection.config.mode.value} mode)")

        return self

    async def disconnect(self) -> None:
        """Disconnect from PhyHub."""
        if self._connection:
            await self._connection.disconnect()
        self._connected = False
        self._instance = None
        if self._registry:
            self._registry.clear()

    def _setup_socket_listeners(self) -> None:
        """Set up Socket.IO event handlers."""
        if not self._connection:
            return

        def on_twin_message(payload: dict[str, Any], callback: Any = None) -> Any:
            """Handle incoming twin messages."""
            twin_id = payload.get("twinId")
            result: Optional[TwinMessageResult] = None

            if twin_id and payload.get("data"):
                listeners = self._twin_message_listeners.get(twin_id)
                if listeners:
                    for listener in listeners:
                        try:
                            listener(payload)
                            result = TwinMessageResult(
                                status=TwinMessageResultStatus.SUCCESS,
                                message="Action completed",
                            )
                        except Exception as e:
                            result = TwinMessageResult(
                                status=TwinMessageResultStatus.ERROR,
                                message=str(e),
                            )
                else:
                    result = TwinMessageResult(
                        status=TwinMessageResultStatus.WARNING,
                        message=f"No listeners found for twin {twin_id}",
                    )

                if callback and result:
                    return {"status": result.status.value, "message": result.message}

            return None

        self._connection.on(self.EVENTS.TWIN_MESSAGE, on_twin_message)

        def on_twin_updated(payload: dict[str, Any]) -> None:
            """Handle twin property update events."""
            twin_data = payload.get("data") or payload
            twin_id = payload.get("twinId") or (twin_data.get("id") if isinstance(twin_data, dict) else None)

            if not twin_id:
                return

            # Notify twin update listeners
            listeners = self._twin_update_listeners.get(twin_id)
            if listeners:
                for callback in listeners:
                    try:
                        callback(twin_data)
                    except Exception as e:
                        print(f"[PhyHubClient] Error in twin update listener: {e}")

        self._connection.on(self.EVENTS.TWIN_UPDATED, on_twin_updated)

    async def _initialize_device_twin(self) -> None:
        """Initialize device twin via authentication."""
        if not self._connection:
            return

        # Authenticate - server responds with deviceAuthenticated event
        print("[PhyHubClient] Authenticating...")
        auth_result = await self._connection.emit(
            "authenticate",
            {
                "deviceId": self._connection.device_id,
                "accessKey": self._connection.config.access_key,
            },
            response_event="deviceAuthenticated",
        )

        if auth_result.get("status") != "success":
            raise ConnectionError(f"Authentication failed: {auth_result.get('message')}")

        print(f"[PhyHubClient] Authenticated: {auth_result}")

        # Connect device - server uses callback pattern (no payload needed)
        print("[PhyHubClient] Connecting device...")
        connect_result = await self._connection.emit(
            "connectDevice",
            callback=True,
        )

        if connect_result.get("status") != "success":
            raise ConnectionError(f"Device connection failed: {connect_result.get('message')}")

        # Extract twin info - prefer server response for device twin ID
        twins = connect_result.get("twins", [])
        if twins:
            device_twin = next(
                (t for t in twins if t.get("type") == "Device"),
                twins[0],
            )
            # Use server's twin ID unless user explicitly set a different one
            server_twin_id = device_twin.get("id")
            if server_twin_id:
                self._instance_id = server_twin_id
            print(f"[PhyHubClient] Connected. Twin ID: {self._instance_id}")

    async def get_instance(self) -> Optional[EdgeInstance]:
        """Get or create the edge instance.

        Returns:
            EdgeInstance for messaging, or None if not connected.
        """
        if not self._connected or not self._registry:
            return None

        if self._instance:
            return self._instance

        self._instance = await self._registry.get_edge_instance()
        return self._instance

    async def get_peripheral_instance(self, twin_id: str) -> Optional[PeripheralInstance]:
        """Get a peripheral instance by twin ID.

        Args:
            twin_id: ID of the peripheral twin.

        Returns:
            PeripheralInstance or None if not found.
        """
        if not self._registry:
            return None

        return await self._registry.get_peripheral_instance(twin_id)

    def _send_event(self, target_twin_id: str, payload: dict[str, Any]) -> None:
        """Send event to a twin (fire-and-forget).

        In direct mode: socket.emit('twinMessage', payload)
        In PhyOS mode: socket.emit(instanceId, { method: 'twinMessage', ...payload })
        """
        if not self._connection:
            return

        event_payload = {
            "twinId": target_twin_id,
            "sourceTwinId": self._instance_id,
            "sourceDeviceId": self._connection.device_id if self._connection else None,
            "data": payload,
        }

        # Fire and forget - use asyncio to schedule
        asyncio.create_task(self._emit_to_socket(self.EVENTS.TWIN_MESSAGE, event_payload))

    async def _emit_to_socket(
        self, method: str, payload: dict[str, Any], callback: bool = False
    ) -> Any:
        """Unified emit — routes through instance ID channel or direct, based on mode.

        In direct mode: socket.emit(method, payload)
        In PhyOS/Simulator mode: socket.emit(instanceId, { method, ...payload })

        Args:
            method: Event/method name.
            payload: Data to send.
            callback: If True, wait for ack response (for RPC calls).

        Returns:
            Response from server if callback is True, else None.
        """
        if not self._connection:
            return None

        if self._connection.is_direct:
            # Direct mode: emit to event name directly
            return await self._connection.emit(method, payload, callback=callback)
        else:
            # PhyOS/Simulator: wrap in instance ID channel with method field
            phyos_payload = {"method": method, **payload}
            return await self._connection.emit(
                self._instance_id or "", phyos_payload, callback=callback
            )

    def on_twin_message(
        self,
        twin_id: str,
        callback: Callable[[dict[str, Any]], None],
    ) -> None:
        """Register a callback for messages to a twin.

        Args:
            twin_id: Twin ID to listen for.
            callback: Handler function.
        """
        if twin_id not in self._twin_message_listeners:
            self._twin_message_listeners[twin_id] = set()
        self._twin_message_listeners[twin_id].add(callback)

    def off_twin_message(
        self,
        twin_id: str,
        callback: Optional[Callable[[dict[str, Any]], None]] = None,
    ) -> bool:
        """Remove a message callback.

        Args:
            twin_id: Twin ID.
            callback: Specific callback to remove, or None for all.

        Returns:
            True if removed, False otherwise.
        """
        if twin_id not in self._twin_message_listeners:
            return False

        if callback:
            self._twin_message_listeners[twin_id].discard(callback)
            if not self._twin_message_listeners[twin_id]:
                del self._twin_message_listeners[twin_id]
            return True
        else:
            del self._twin_message_listeners[twin_id]
            return True

    async def subscribe_twin(self, target_twin_id: str) -> dict[str, Any]:
        """Subscribe to receive messages from a twin.

        Args:
            target_twin_id: Twin ID to subscribe to.

        Returns:
            Subscription response.
        """
        if not self._connection:
            raise ConnectionError("Not connected")

        # Skip if already subscribed
        if target_twin_id in self._subscribed_twins:
            return {"status": "success", "message": "Already subscribed"}

        self._subscribed_twins.add(target_twin_id)

        payload = {
            "twinId": target_twin_id,
            "sourceTwinId": self._instance_id,
            "sourceDeviceId": self._connection.device_id,
        }

        # Fire-and-forget subscription using unified emit
        asyncio.create_task(self._emit_to_socket(self.EVENTS.TWIN_SUBSCRIBE, payload))

        return {"status": "success", "message": "Subscribed"}

    async def get_twin_by_id(self, twin_id: str) -> Optional[dict[str, Any]]:
        """Get twin data by ID.

        Args:
            twin_id: Twin ID to fetch.

        Returns:
            Twin data dictionary.
        """
        result = await self._emit_to_socket(
            self.EVENTS.GET_TWIN_BY_ID,
            {"data": {"twinId": twin_id}},
            callback=True,
        )

        return result.get("twin") if result else None

    # =========================================================================
    # Settings API
    # =========================================================================

    async def get_settings(self) -> dict[str, Any]:
        """Get settings from edge instance desired properties.

        Returns:
            Settings dictionary.
        """
        instance = await self.get_instance()
        if instance:
            return instance.get_settings()
        return {}



    # =========================================================================
    # Twin Update API
    # =========================================================================

    def on_twin_update(
        self,
        twin_id: str,
        callback: Callable[[dict[str, Any]], None],
    ) -> None:
        """Register callback for twin property updates.

        Args:
            twin_id: Twin ID to listen for updates.
            callback: Handler called with twin data when properties change.
        """
        if twin_id not in self._twin_update_listeners:
            self._twin_update_listeners[twin_id] = set()
        self._twin_update_listeners[twin_id].add(callback)

        # Ensure subscribed
        asyncio.create_task(self.subscribe_twin(twin_id))

    def off_twin_update(
        self,
        twin_id: str,
        callback: Optional[Callable[[dict[str, Any]], None]] = None,
    ) -> bool:
        """Remove twin update callback.

        Args:
            twin_id: Twin ID.
            callback: Specific callback to remove, or None for all.

        Returns:
            True if removed, False otherwise.
        """
        if twin_id not in self._twin_update_listeners:
            return False

        if callback:
            self._twin_update_listeners[twin_id].discard(callback)
            if not self._twin_update_listeners[twin_id]:
                del self._twin_update_listeners[twin_id]
            return True
        else:
            del self._twin_update_listeners[twin_id]
            return True

    # =========================================================================
    # Properties API
    # =========================================================================

    async def update_reported_properties(
        self,
        twin_id: str,
        properties: dict[str, Any],
        twin_type: Optional[TwinTypeEnum] = None,
    ) -> Optional[dict[str, Any]]:
        """Update reported properties for a twin.

        Args:
            twin_id: Twin ID to update.
            properties: Properties to set.
            twin_type: Twin type to determine correct event. Defaults to Peripheral.

        Returns:
            Updated twin data.
        """
        # Dispatch to correct event based on twin type (matches Node.js behavior)
        if twin_type == TwinTypeEnum.Screen:
            event = self.EVENTS.REPORT_SCREEN_PROPERTIES
        elif twin_type == TwinTypeEnum.Edge:
            event = self.EVENTS.REPORT_EDGE_PROPERTIES
        else:
            event = self.EVENTS.REPORT_PERIPHERAL_PROPERTIES

        payload = {"twinId": twin_id, "data": properties}
        result = await self._emit_to_socket(event, payload, callback=True)
        return result.get("twin") if result else None

    # =========================================================================
    # Signals / Analytics API
    # =========================================================================

    async def initialize_signals(
        self, params: Optional["InitSignalPayload"] = None
    ) -> "SignalsService":
        """Initialize the signals/analytics service.

        When called without params, auto-populates from device status and
        instance twin data (matches Node.js hub-client behavior).

        Args:
            params: Optional signal initialization parameters. If None,
                    auto-populates from device status and edge instance.

        Returns:
            Initialized SignalsService instance.
        """
        from phystack.hub_client.services.signals import SignalsService, InitSignalPayload

        # Auto-populate from device status + instance (matches Node.js)
        device_status: dict[str, Any] = {}
        instance_data: dict[str, Any] = {}

        if not params:
            device_status = await self.get_device_status() or {}
            edge_instance = await self.get_instance()
            if edge_instance:
                instance_data = edge_instance._twin_data or {}

        p = params or InitSignalPayload()

        payload = InitSignalPayload(
            tenant_id=p.tenant_id or device_status.get("tenantId", ""),
            space_id=p.space_id or device_status.get("spaceId", ""),
            device_id=p.device_id or instance_data.get("deviceId") or device_status.get("deviceId", ""),
            installation_id=p.installation_id or (
                instance_data.get("properties", {}).get("desired", {}).get("installationId", "")
            ),
            environment=p.environment or device_status.get("gridEnv", ""),
            data_residency=p.data_residency or (
                device_status.get("dataResidency", "")
            ).upper(),
            country=p.country or "SE",
            app_id=p.app_id or "XXXXXXXXXXXXXXXXXXXXXXXX",
            app_version=p.app_version or "XXXXXXXXXXXXXXXXXXXXXXXX",
            installation_version=p.installation_version or "XXXXXXXXXXXXXXXXXXXXXXXX",
            ip=p.ip or (
                device_status.get("ip", [{}])[0].get("ipv4", "N/A")
                if isinstance(device_status.get("ip"), list) and device_status.get("ip")
                else "N/A"
            ),
            session_id=p.session_id,
            client_id=p.client_id,
            latitude=p.latitude,
            longitude=p.longitude,
            location_accuracy=p.location_accuracy,
            create_new_session_after_last_activity_mins=p.create_new_session_after_last_activity_mins,
        )

        service = SignalsService(self, payload)
        await service.initialize()
        return service

    async def send_signal(
        self, data_type: "DataRequestTypeEnum", data: dict[str, Any]
    ) -> Any:
        """Send a signal to the server.

        Args:
            data_type: Type of signal (EVENT, SESSION, CLIENT, CHECKOUT, PURCHASE).
            data: Signal data (already key-shortened).
        """
        from phystack.hub_client.services.signals import DataRequestTypeEnum

        event_map = {
            DataRequestTypeEnum.EVENT: "sendEventSignal",
            DataRequestTypeEnum.CHECKOUT: "sendEventSignal",
            DataRequestTypeEnum.PURCHASE: "sendEventSignal",
            DataRequestTypeEnum.SESSION: "sendSessionSignal",
            DataRequestTypeEnum.CLIENT: "sendClientSignal",
        }
        event = event_map.get(data_type, "sendEventSignal")
        return await self._emit_to_socket(event, {"data": data})

    # =========================================================================
    # Device API
    # =========================================================================

    async def get_device_status(self) -> Optional[dict[str, Any]]:
        """Get device status (IP, serial, env, etc.).

        Returns:
            Device status dictionary.
        """
        return await self._emit_to_socket(
            self.EVENTS.GET_DEVICE_STATUS, {}, callback=True
        )

    async def get_device_instance(self) -> Optional[dict[str, Any]]:
        """Get device instance data.

        Returns:
            Device instance dictionary.
        """
        return await self._emit_to_socket(
            self.EVENTS.GET_DEVICE_INSTANCE, {}, callback=True
        )

    async def get_device_networks(self) -> Optional[dict[str, Any]]:
        """Get available networks on the device.

        Returns:
            Device networks dictionary.
        """
        return await self._emit_to_socket(
            self.EVENTS.GET_DEVICE_NETWORKS, {}, callback=True
        )

    # =========================================================================
    # WebRTC Helpers
    # =========================================================================

    def _create_twin_messaging_interface(self) -> DataChannelMessaging:
        """Create a twin messaging interface for WebRTC handlers.

        This interface matches the npm TwinMessagingInterface and is used
        for WebRTC signaling (offer/answer/ice exchange).
        """
        async def send_message(target_twin_id: str, payload: dict[str, Any]) -> None:
            """Send a twin message for signaling.

            Unlike _send_event (fire-and-forget), this awaits the emit
            to ensure signaling messages are sent before proceeding.
            """
            if not self._connection:
                return

            event_payload = {
                "twinId": target_twin_id,
                "sourceTwinId": self._instance_id,
                "sourceDeviceId": self._connection.device_id if self._connection else None,
                "data": payload,
            }

            # Use unified emit pattern
            await self._emit_to_socket(self.EVENTS.TWIN_MESSAGE, event_payload)

        async def subscribe(twin_id: str) -> None:
            await self.subscribe_twin(twin_id)

        def get_own_twin_id() -> str:
            if not self._instance_id:
                raise ValueError("Instance ID not set")
            return self._instance_id

        return DataChannelMessaging(
            send_message=send_message,
            subscribe=subscribe,
            on_message=self.on_twin_message,
            off_message=lambda tid, cb: self.off_twin_message(tid, cb),
            get_own_twin_id=get_own_twin_id,
        )

    async def create_data_channel(
        self,
        target_twin_id: str,
        is_initiator: bool = True,
        options: Optional[DataChannelOptions] = None,
        channel_name: str = "default",
        blocking: bool = True,
    ) -> PhygridDataChannel:
        """Create a WebRTC DataChannel connection to another twin.

        Args:
            target_twin_id: ID of the twin to connect to.
            is_initiator: Whether this side initiates the connection.
            options: DataChannel configuration options.
            channel_name: Name for the data channel.
            blocking: If True (default), wait for connection to complete.
                     If False, return immediately and connect in background.

        Returns:
            PhygridDataChannel for sending/receiving data.
        """
        if not self._connected:
            raise ConnectionError("Not connected to PhyHub")

        # Subscribe to target twin
        await self.subscribe_twin(target_twin_id)

        # Create messaging interface
        messaging = self._create_twin_messaging_interface()

        # Create handler
        handler = DataChannelHandler(
            target_twin_id=target_twin_id,
            is_initiator=is_initiator,
            twin_messaging=messaging,
            options=options,
            channel_name=channel_name,
        )

        # Connect and return
        return await handler.connect(blocking=blocking)

    async def create_media_stream(
        self,
        target_twin_id: str,
        is_initiator: bool = True,
        options: Optional[MediaStreamOptions] = None,
        stream_name: str = "default",
        blocking: bool = True,
    ) -> PhygridMediaStream:
        """Create a WebRTC MediaStream connection to another twin.

        Args:
            target_twin_id: ID of the twin to connect to.
            is_initiator: Whether this side initiates the connection.
            options: MediaStream configuration options.
            stream_name: Name for the media stream.
            blocking: If True (default), wait for connection to complete.
                     If False, return immediately and connect in background.

        Returns:
            PhygridMediaStream for video/audio streaming.
        """
        if not self._connected:
            raise ConnectionError("Not connected to PhyHub")

        # Subscribe to target twin
        await self.subscribe_twin(target_twin_id)

        # Create messaging interface (same structure as DataChannel)
        messaging_interface = self._create_twin_messaging_interface()
        media_messaging = MediaStreamMessaging(
            send_message=messaging_interface.send_message,
            subscribe=messaging_interface.subscribe,
            on_message=messaging_interface.on_message,
            off_message=messaging_interface.off_message,
            get_own_twin_id=messaging_interface.get_own_twin_id,
        )

        # Create handler
        handler = MediaStreamHandler(
            target_twin_id=target_twin_id,
            is_initiator=is_initiator,
            twin_messaging=media_messaging,
            options=options,
            stream_name=stream_name,
        )

        # Connect and return
        return await handler.connect(blocking=blocking)

    async def __aenter__(self) -> "PhyHubClient":
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Async context manager exit."""
        await self.disconnect()
