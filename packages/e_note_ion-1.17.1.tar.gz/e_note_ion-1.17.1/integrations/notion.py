# integrations/notion.py
#
# Notion webhook integration — displays automation-triggered notifications.
#
# Notion automations send an HTTP POST to the webhook endpoint with a
# structured payload. This integration parses the payload and formats a
# display message with a static "[W] NOTION" header row.
#
# No config.toml keys are required for the integration itself. To override
# hold/timeout/priority for the notification template, add a
# [notion.schedules.notification] section to config.toml — the same override
# syntax used for scheduled templates.

import json
import logging
import re
from pathlib import Path
from typing import Any

from scheduler import WebhookMessage

logger = logging.getLogger(__name__)

# Matches color tags like [R], [G], etc. in user-supplied text.
# Brackets are not in the Vestaboard character set, so [R] cannot render as
# literal text. Replace with the bare letter so intent is preserved.
_COLOR_TAG_RE = re.compile(r'\[([ROYGBVWK])\]')

_NOTION_JSON_PATH = Path(__file__).parent.parent / 'content' / 'contrib' / 'notion.json'


def _load_template_config(template_name: str) -> dict[str, Any]:
  """Return effective config for a webhook-only template from notion.json.

  Applies any [notion.schedules.<template_name>] overrides from config.toml
  on top of the JSON defaults, matching the behaviour of scheduled templates.
  """
  import config as _config_mod

  with open(_NOTION_JSON_PATH) as f:
    content = json.load(f)
  template = content['templates'][template_name]
  schedule = template['schedule']

  effective: dict[str, Any] = {
    'hold': schedule['hold'],
    'timeout': schedule['timeout'],
    'priority': template['priority'],
    'truncation': template.get('truncation', 'hard'),
    'templates': template.get('templates', []),
  }

  override = _config_mod.get_schedule_override(f'notion.{template_name}')
  for field in ('hold', 'timeout'):
    val = override.get(field)
    if isinstance(val, int) and val >= 0:
      effective[field] = val
  priority_val = override.get('priority')
  if isinstance(priority_val, int) and 0 <= priority_val <= 10:
    effective['priority'] = priority_val

  return effective


def handle_webhook(payload: dict[str, Any], credential_name: str | None = None) -> WebhookMessage | None:
  """Process a Notion webhook payload and return a WebhookMessage or None.

  Expects the Notion automation webhook format, where page data is nested under
  payload["data"]["properties"]. The integration reads three page properties:
    message (title, required): body text; newlines produce multiple display lines.
    urgent  (checkbox, optional, default false): if true, interrupt the current hold.
    tag     (select, optional, default "notion"): deduplication key — queued messages
            with the same namespaced tag are replaced by this one. Set to "" to
            disable superseding entirely.

  credential_name identifies the named credential that authenticated this request.

  Returns None if message is missing or blank, or on any unexpected error.
  """
  try:
    data = payload.get('data')
    if not isinstance(data, dict):
      logger.debug('notion: discarding: missing or invalid data key')
      return None
    properties = data.get('properties')
    if not isinstance(properties, dict):
      logger.debug('notion: discarding: missing or invalid properties key')
      return None

    title_items = properties.get('message', {}).get('title', [])
    message = ''.join(item.get('plain_text', '') for item in title_items if isinstance(item, dict))
    message_lines = [
      _COLOR_TAG_RE.sub(r'\1', line.strip().upper()).strip() for line in message.split('\n') if line.strip()
    ]
    message_lines = [line for line in message_lines if line]
    if not message_lines:
      logger.debug('notion: discarding: empty or missing message')
      return None

    urgent = bool(properties.get('urgent', {}).get('checkbox', False))

    select = properties.get('tag', {}).get('select')
    if select is None:
      supersede_tag = 'notion'
    elif isinstance(select, dict):
      raw_tag = select.get('name', '')
      supersede_tag = f'notion.{raw_tag}' if raw_tag else ''
    else:
      logger.debug('notion: invalid tag select type %r, using default', type(select).__name__)
      supersede_tag = 'notion'

    cfg = _load_template_config('notification')

    logger.debug(
      'notion: enqueueing notification (urgent=%s, tag=%r, credential=%r)',
      urgent,
      supersede_tag,
      credential_name,
    )
    return WebhookMessage(
      data={
        'templates': cfg['templates'],
        'variables': {'message': [message_lines]},
        'truncation': cfg['truncation'],
      },
      priority=cfg['priority'],
      hold=cfg['hold'],
      timeout=cfg['timeout'],
      interrupt=urgent,
      supersede_tag=supersede_tag,
    )
  except Exception as e:  # noqa: BLE001
    logger.error('Notion webhook error: %s', e)
    return None
