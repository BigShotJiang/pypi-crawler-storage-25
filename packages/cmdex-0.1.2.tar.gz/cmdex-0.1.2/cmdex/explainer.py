# cmdex/explainer.py
import json
from rich import print
from rich.panel import Panel
import importlib.resources as pkg_resources
from cmdex import db  # important

def load_db():
    with pkg_resources.files("cmdex").joinpath("db.json").open("r") as f:
        return json.load(f)

def explain_command(cmd):
    db = load_db()
    parts = cmd.strip().split()
    
    if not parts:
        return "[red]No command provided[/red]"

    command = parts[0]
    flags = [p for p in parts if p.startswith("-")]
    args = [p for p in parts[1:] if not p.startswith("-")]

    output = []

    # Explain command
    if command in db["commands"]:
        output.append(f"[cyan]{command}[/cyan] → {db['commands'][command]}")
    else:
        output.append(f"[red]{command}[/red] → Unknown command")

    # Explain flags
    for flag in flags:
        meaning = db["flags"].get(flag, "Unknown flag")
        output.append(f"[yellow]{flag}[/yellow] → {meaning}")

    # Show arguments
    if args:
        output.append(f"[green]Arguments[/green] → {' '.join(args)}")

    # Danger detection
    danger_msg = db.get("dangerous", {}).get(cmd)
    if danger_msg:
        output.append(f"\n[bold red]🚨 DANGER: {danger_msg}[/bold red]")
        output.append("💡 Safer alternative: Think twice before running!")

    # Special checks for known risky patterns
    if command == "rm" and "-rf" in cmd:
        output.append("[bold red]⚠ WARNING: Force delete detected[/bold red]")
    if "chmod 777" in cmd:
        output.append("[bold red]⚠ WARNING: Full permissions granted[/bold red]")

    return Panel("\n".join(output), title="Cmdex Explanation", expand=False)