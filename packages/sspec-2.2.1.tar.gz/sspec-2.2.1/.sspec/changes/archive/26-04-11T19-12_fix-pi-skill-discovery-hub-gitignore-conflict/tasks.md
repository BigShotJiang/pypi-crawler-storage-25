---
change: "fix-pi-skill-discovery-hub-gitignore-conflict"
updated: "2026-04-11T19:14"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks

### Phase 1: Ignore-scope service repair ✅
- [x] Update `src/sspec/skill_installer.py` — add/adjust helpers so spoke `.gitignore` management stays on the parent directory while hub-managed entries can target `.sspec/.gitignore` as `skills/<name>` paths
- [x] Update `src/sspec/services/project_update_service.py` — replace hub `.sspec/skills/.gitignore` sync with `.sspec/.gitignore` sync and add legacy hub-file fenced-block cleanup/deletion behavior
- [x] Update `src/sspec/commands/project.py` — align update output text with the new hub ignore sync target and cleanup behavior
**Verification**: targeted service behavior matches spec: hub-managed entries land in `.sspec/.gitignore`, spoke-parent ignores still use `skills`, and legacy `.sspec/skills/.gitignore` managed blocks are removed on update.

### Phase 2: Regression tests and contract docs ✅
- [x] Update `tests/test_skill_installer.py` — cover hub-targeted vs spoke-targeted gitignore writes and idempotent fenced-block behavior
- [x] Update `tests/test_project_update_service.py` — assert hub sync writes `.sspec/.gitignore`, dry-run stays read-only, and legacy `.sspec/skills/.gitignore` cleanup works including empty-file deletion
- [x] Confirm `tests/test_project_init_skill_sync.py` still locks spoke-parent `.gitignore` behavior; adjust only if needed for clarity
- [x] Update `.sspec/spec-docs/skill-installation.md` — document the new hub ignore scope and Pi interoperability constraint
**Verification**: `uv run pytest tests/test_skill_installer.py tests/test_project_update_service.py tests/test_project_init_skill_sync.py -q`

### Phase 3: Self-host sync and focused verification ✅
- [x] Run `uv pip install -e .`
- [x] Run `uv run sspec project update`
- [x] Run `uv run pytest tests/test_skill_installer.py tests/test_project_update_service.py tests/test_project_init_skill_sync.py -q`
- [x] Run `uv run ruff check src/`
**Verification**: self-hosted copies reflect the repaired contract, focused tests pass, and lint reports no new issues in touched source files. Repository-wide `uv run ruff check src/` still has pre-existing unrelated issues in `src/sspec/builtin_tools/treesitter.py`; touched files pass focused lint.

---

## Progress

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1: Ignore-scope service repair | 100% | ✅ |
| Phase 2: Regression tests and contract docs | 100% | ✅ |
| Phase 3: Self-host sync and focused verification | 100% | ✅ |

**Recent**:
- Completed: hub managed-skill ignores now sync to `.sspec/.gitignore`; spoke-parent `skills` ignore behavior unchanged
- Completed: `project update` now removes legacy `.sspec/skills/.gitignore` managed blocks and deletes the file when empty
- Verified: `uv run pytest tests/test_skill_installer.py tests/test_project_update_service.py tests/test_project_init_skill_sync.py -q` → 24 passed
- Verified: `uv run sspec project update` synced self-hosted `.sspec/.gitignore` managed entries
- Verified: focused `ruff check` on touched source files passed; repo-wide `src/sspec/builtin_tools/treesitter.py` still has unrelated pre-existing lint issues
