---
name: fix-pi-skill-discovery-hub-gitignore-conflict
status: DONE
change-type: single
created: 2026-04-11 19:12:25
reference:
- source: .sspec/requests/archive/26-04-11T19-07_pi-skill-discovery-hub-gitignore-conflict.md
  type: request
archived: '2026-04-11T20:29:25'
---
# fix-pi-skill-discovery-hub-gitignore-conflict

## Problem Statement

In the current hub-spoke skill layout, at least 1 documented Pi discovery location (`.agents/skills`) can resolve to 0 discovered `sspec-*` skills when it points at `.sspec/skills`.

The direct cause is contract leakage between Git hygiene and runtime discovery:
- sspec currently writes managed skill names into `.sspec/skills/.gitignore`
- Pi follows `.agents/skills -> .sspec/skills` and respects ignore files during recursive skill discovery
- the hub-local ignore file therefore hides the very managed skills that should remain consumable at runtime

This leaves the product in an internally inconsistent state: `AGENTS.md` can advertise the SSPEC workflow while Pi's `available_skills` omits `sspec-*`, so users cannot actually invoke the advertised skill set through the documented discovery path.

## Proposed Solution

### Approach

Treat this as an ignore-scope bug, not a skill-install topology redesign. Keep `.sspec/skills` as the hub and keep spoke locations such as `.agents/skills` ignored as distribution views, but move managed hub ignore rules out of the hub directory itself.

The repair is to scope managed ignores at `.sspec/.gitignore` using `skills/<name>` entries instead of maintaining a `.sspec/skills/.gitignore` managed block. This preserves Git hygiene for template-managed hub skills while avoiding runtime discovery pollution when external tools traverse a link/junction into the hub.

`project update` must also clean up the legacy managed block from `.sspec/skills/.gitignore` so existing projects stop leaking the old behavior after upgrade. Spoke `.gitignore` behavior stays unchanged.

### Key Change

**Fix A: Hub ignore relocation** — Stop writing managed hub skill entries into `.sspec/skills/.gitignore` and instead maintain them in `.sspec/.gitignore` as `skills/<skill-name>` paths.

**Fix B: Legacy hub-ignore cleanup** — During update, remove the sspec-managed fenced block from `.sspec/skills/.gitignore`; if no user content remains, delete the file.

**Fix C: Spoke stability contract** — Keep spoke-parent ignore behavior unchanged so locations like `.agents/.gitignore` still ignore `skills` as a distribution view.

**Fix D: Regression coverage and docs** — Update tests and the skill-installation spec-doc to lock in the new ignore-scope contract and the Pi interoperability rationale.

### Scope Summary

| File | Change |
|------|--------|
| `src/sspec/skill_installer.py` | Add/adjust gitignore helpers so hub-managed ignores can target `.sspec/.gitignore` while spoke handling remains unchanged |
| `src/sspec/services/project_update_service.py` | Replace hub `.gitignore` sync with `.sspec/.gitignore` sync and legacy `.sspec/skills/.gitignore` cleanup |
| `src/sspec/commands/project.py` | Update project-update messaging to describe the new hub ignore sync target and cleanup behavior |
| `tests/test_skill_installer.py` | Add low-level gitignore helper coverage for hub vs spoke behavior |
| `tests/test_project_update_service.py` | Update hub gitignore tests to assert `.sspec/.gitignore` writes and legacy hub-file cleanup |
| `tests/test_project_init_skill_sync.py` | Keep spoke gitignore contract covered so the behavior remains stable |
| `.sspec/spec-docs/skill-installation.md` | Document the new hub ignore scope and the reason hub-local `.gitignore` is forbidden for managed skills |

### What Stays Unchanged

- `.sspec/skills` remains the single hub/source-of-truth for installed skills
- spoke locations such as `.agents/skills`, `.claude/skills`, and `.github/skills` remain distribution views created via link/copy
- custom user-added skills under `.sspec/skills` remain allowed and should not be blanket-ignored
- this change does not redesign Pi skill discovery; it only removes sspec's current interoperability bug
