# Memory: fix-pi-skill-discovery-hub-gitignore-conflict

**Updated**: 2026-04-11T20:29+08:00

## Git Baseline (Immutable)
<!-- Captured during `sspec change new` before any change files are written.
This section records the change starting point in git and MUST NOT be edited or refreshed later. -->

- Captured: before change file creation
- Repository: `H:/SrcCode/playground/sspec`
- Branch: `main`
- HEAD: `82645c452d5f5590299566a2824398a129ae697a`
- Worktree: `dirty`
- Status Snapshot: raw `git status --short --branch` output

```text
## main...origin/main
?? .sspec/requests/archive/26-04-11T19-07_pi-skill-discovery-hub-gitignore-conflict.md
```

## State
User accepted the change and requested close-out. Next: archive the completed change, then create a git commit for the staged result.

## Key Files
- `src/sspec/skill_installer.py` — shared gitignore helper logic; now separates hub-managed `.sspec/.gitignore` sync from spoke-parent `skills` ignores
- `src/sspec/services/project_update_service.py` — update-time hub ignore sync and legacy `.sspec/skills/.gitignore` managed-block cleanup
- `src/sspec/services/project_init_service.py` — init order adjusted so default `.sspec/.gitignore` exists before hub skill sync merges managed entries
- `tmp/test_pi_skill_gitignore_smoke/` — manual sandbox proving init/update behavior with `.agents/skills -> .sspec/skills`

## Knowledge
- [2026-04-11T20:27+08:00] [Decision] The fix keeps the hub-spoke topology unchanged; only the ignore scope moved from `.sspec/skills/.gitignore` to `.sspec/.gitignore` using `skills/<name>` entries.
- [2026-04-11T20:27+08:00] [VitalFinding] Real filesystem inspection showed `.agents/skills` was present and resolved to `.sspec/skills`; the failure was runtime discovery filtering, not missing links or missing files.
- [2026-04-11T20:27+08:00] [Gotcha] `project init` had to create `.sspec/.gitignore` before hub skill installation, otherwise the new hub-sync helper could overwrite the default ignore rules by creating a fresh file containing only the managed block.
- [2026-04-11T20:27+08:00] [VitalFinding] Manual sandbox verification in `tmp/test_pi_skill_gitignore_smoke/` confirmed two edge cases: fresh init keeps default `.sspec/.gitignore` rules while adding `skills/<name>` entries, and update removes only the legacy managed fenced block from `.sspec/skills/.gitignore` while preserving user-authored lines such as `user-keep-me`.
- [2026-04-11T20:27+08:00] [Constraint] User explicitly preferred real tmp/mock execution over adding extra dedicated pytest coverage for the remaining edge cases.

## Milestones
- [2026-04-11T19:12+08:00] Change created from request `26-04-11T19-07_pi-skill-discovery-hub-gitignore-conflict` to repair Pi/sspec skill discovery interoperability.
- [2026-04-11T19:14+08:00] Design and plan aligned: move managed hub ignores to `.sspec/.gitignore`, preserve spoke behavior, clean legacy hub-local managed block.
- [2026-04-11T20:05+08:00] Implemented service/helper/doc updates; focused pytest passed (`24 passed`), editable reinstall completed, and self-host `sspec project update` synced `.sspec/.gitignore` managed entries.
- [2026-04-11T20:20+08:00] Independent code-reviewer subagent reviewed `git diff --cached` and suggested init/migration edge verification rather than more code changes.
- [2026-04-11T20:27+08:00] Manual tmp smoke test verified fresh init plus legacy-cleanup behavior with `.agents/skills -> .sspec/skills`, including preservation of user-authored hub `.gitignore` lines.
- [2026-04-11T20:29+08:00] User accepted the result and requested the standard close-out flow: mark DONE, archive the change, then commit.
