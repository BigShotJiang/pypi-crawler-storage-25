# Handover: agents-rewrite

**Updated**: <!-- ISO timestamp, minute precision -->

---

## Background
<!-- Write once. What this change does and why (1-3 sentences).
Update only if scope fundamentally changes. -->

## Git Baseline (Immutable)
<!-- Captured by `sspec change new`. MUST NOT be edited later. -->

- Captured: before change file creation
- Repository: `H:/SrcCode/playground/sspec`
- Branch: `refactor/sspec-vnext`
- HEAD: `987ccd7fbf4c40fbb9044fe0f1ea5d91bea62da6`
- Worktree: `dirty`
- Status Snapshot: raw `git status --short --branch` output

```text
## refactor/sspec-vnext
 M .sspec/changes/archive/26-04-08T17-37_sspec-vnext/handover.md
 M .sspec/changes/archive/26-04-08T18-15_skill-slimdown/spec.md
?? .sspec/changes/archive/26-04-08T17-37_sspec-vnext/reference/
```

## Working Memory (Stable)
<!-- Curated, long-lived context. Survives sessions and context compression. -->

### Key Files
<!-- Files critical to this change.
- `path/file` — what it contains, why it matters -->

### Durable Memory
<!-- Typed, timestamped. Promote only facts useful beyond the current session.
Types: Alignment, Decision, VitalFinding, Constraint, Risk, VerificationShortcut.
Format: - [2026-04-08T17:00] [Decision] Redis over Memcached because per-key TTL matters.
Obsolete items: mark with timestamp, don't delete silently. -->

## Session Log (Append-Only)
<!-- Newest first. Each entry = one atomic work batch.
User interaction (feedback, @align, @argue) MUST start a new entry. -->

### <ISO timestamp> [tag] <short title>

**Accomplished**
- ...

**Next**
- ...

**Notes** (optional)
- ...
