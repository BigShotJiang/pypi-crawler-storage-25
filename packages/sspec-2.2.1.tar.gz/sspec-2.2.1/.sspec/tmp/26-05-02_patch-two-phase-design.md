# Design: patch tool Two-Phase Apply

> 26-05-02 | mini change | request: 26-05-02T17-42_patch-method.md

## Problem

`apply_patches()` 顺序 apply：每条 patch 独立调用 `apply_patch()`，后者每次重新读文件。
前一条 patch 的 REPLACE 改变了文件内容，后续 patch 的 SEARCH 基于新内容匹配 → 失败。

```
文件: foo bar
Patch 1: SEARCH "foo" → REPLACE "bar"  → 文件变为 "bar bar"
Patch 2: SEARCH "bar" → REPLACE "tee"  → 匹配到两处 → search_ambiguous ❌
```

Agent 意图是两个 patch 都能 apply，但顺序执行破坏了匹配基础。

## Design

**核心思路**：同文件多条 search patch → 全部基于原始内容 match → overlap 检查 → 从后往前 apply。

### 架构

```
apply_patches()                           # 改写
  ├─ parse_patches()                      # 不动
  ├─ group patches by file                # 新增
  └─ per file group:
      ├─ 1 patch → apply_patch()          # 不动
      └─ ≥2 search patches →
           _apply_search_patches_batch()  # 新增
```

### 新增数据结构

```python
@dataclass
class PatchMatch:
    """Phase 1 match 结果，不做任何写入"""
    patch: PatchBlock
    abs_start: int            # 文件绝对行索引（0-based）
    abs_end: int              # exclusive，基于绝对坐标
    match_mode: str           # 'exact' | 'loose'
    match_line: int           # 文件中 1-based 行号（= abs_start + 1）
    status: str               # 'matched' | 'already_applied' | 'search_not_found' | 'search_ambiguous' | 'overlap_conflict'
    error: str | None = None
    related_lines: list[int] | None = None
```

> **注**：存绝对行索引而非 region-relative 偏移，避免跨不同 `line_range` 的 patch 坐标空间不一致导致 overlap 误判。

### 新增函数：`_apply_search_patches_batch()`

```python
def _apply_search_patches_batch(
    patches: list[PatchBlock],
    *,
    dry_run: bool = False,
) -> list[PatchApplyResult]:
    """
    同文件多条 search patch 的协调 apply：
    Phase 1: 所有 patch 基于原始文件内容 match（只读）
    Phase 2: 验证无 overlap → 从后往前 apply
    """
```

**Phase 1 详细流程**：

```
1. 读文件内容，检测编码和换行
2. 逐条 patch:
   a. 按 line_range 裁剪搜索区域（与现有 apply_patch 一致）
   b. find_preferred_matches() 找 match
   c. 结果写入 PatchMatch
   d. 异常情况直接标记 status（already_applied / not_found / ambiguous）
3. 检查 overlap：所有 status='matched' 的 match 基于**绝对行索引**两两比较
   - 有 overlap → 全部标记为新 status='overlap_conflict'，附带 overlap 对的行号信息
```

**Phase 2 详细流程**：

```
1. 若有任何 success=False 的 status（search_not_found / search_ambiguous / overlap_conflict / missing_file 等）→ 不 apply，全部返回各自结果；already_applied 视为成功，不阻塞 apply
2. 按 abs_start 降序排列（绝对坐标，splice 时不影响前面的索引）
3. new_lines = file_lines[:] 作为 mutable 工作副本
4. 逐个 splice：new_lines[:abs_start] + replace_lines + new_lines[abs_end:]（累积作用在上一次结果上）
5. atomic_write_text(''.join(new_lines))
```

### 改写 `apply_patches()`

```python
def apply_patches(patch_text, *, project_root=None, dry_run=False):
    parse_result = parse_patches(patch_text, project_root=project_root)
    if parse_result.errors:
        return BatchApplyResult(results=[...error results...])

    # Group by (file_path, operation)
    from itertools import groupby
    patches = parse_result.patches

    # 分离独立操作和需要协调的 search 操作，记录原始顺序
    indexed_results: list[tuple[int, PatchApplyResult]] = []
    file_search_patches: dict[Path, list[tuple[int, PatchBlock]]] = {}

    for idx, p in enumerate(patches):
        if p.operation == 'search':
            file_search_patches.setdefault(p.file_path, []).append((idx, p))
        else:
            # CREATE / OVERWRITE 直接 apply（独立）
            indexed_results.append((idx, apply_patch(p, dry_run=dry_run)))

    # 同文件多 search → batch
    for file_path, indexed_search_ps in file_search_patches.items():
        if len(indexed_search_ps) == 1:
            orig_idx, p = indexed_search_ps[0]
            indexed_results.append((orig_idx, apply_patch(p, dry_run=dry_run)))
        else:
            search_ps = [p for _, p in indexed_search_ps]
            batch_results = _apply_search_patches_batch(search_ps, dry_run=dry_run)
            for (orig_idx, _), result in zip(indexed_search_ps, batch_results):
                indexed_results.append((orig_idx, result))

    # 按原始 patch 顺序排列，保证 CLI 输出顺序与输入一致
    indexed_results.sort(key=lambda x: x[0])
    results = [r for _, r in indexed_results]

    return BatchApplyResult(results=results)
```

### Overlap 检测算法

```python
def _check_overlap(matches: list[PatchMatch]) -> list[tuple[PatchMatch, PatchMatch]]:
    """基于绝对行索引返回所有重叠的 match 对"""
    matched = [m for m in matches if m.status == 'matched']
    overlaps = []
    for i in range(len(matched)):
        for j in range(i + 1, len(matched)):
            a, b = matched[i], matched[j]
            if a.abs_start < b.abs_end and b.abs_start < a.abs_end:
                overlaps.append((a, b))
    return overlaps
```

### 不动的部分

| 组件 | 原因 |
|------|------|
| `apply_patch()` | 单条 patch 逻辑正确，复用它处理单文件单 patch |
| `parse_patches()` | 解析层无问题 |
| CLI 层 (`register_command`) | 纯展示 + 调度，不需要改 |
| 所有 norm / match 工具函数 | 直接复用 |

## 边界情况

| 场景 | 行为 |
|------|------|
| 同文件 CREATE + SEARCH | CREATE 独立 apply，SEARCH 单独走 apply_patch |
| 同文件 OVERWRITE + SEARCH | OVERWRITE 先 apply（顺序），SEARCH 后 apply |
| patch 内 line_range | Phase 1 match 时按 line_range 裁剪 region |
| 文件不存在 | Phase 1 读文件失败 → 全部 `missing_file` |
| 已 apply 过（REPLACE 已在文件中） | Phase 1 `already_applied` → 不 apply 也不报错 |
| 换行风格差异 | 与现有逻辑一致，detect + convert |

## 代码量估算

- `PatchMatch` dataclass: ~12 行
- `_apply_search_patches_batch()`: ~80 行
- `apply_patches()` 改写: ~35 行（含排序逻辑）
- `_check_overlap()`: ~10 行
- `PATCH_PROMPT` 措辞更新: ~2 行
- **总计: ~140 行新增/改写，0 行删除**

### PATCH_PROMPT 更新

WARN 段落从：
> patch-blocks are applied sequentially, lines affected by previous blocks may cause later blocks to fail.

改为：
> Multi-blocks targeting the same file are matched against the original content (not sequentially). Overlapping matches cause all related blocks to fail.

## 测试计划

```
1. 基本 two-phase: 同文件 2 条不重叠 search patch → 都 apply
2. overlap 检测: 2 条 search 区间重叠 → 全部失败
3. 单文件单 patch: 走原有 apply_patch()，行为不变
4. 已 apply 检测: REPLACE 已存在 → already_applied
5. line_range 限制: 带 line_range 的 patch → match 区域正确裁剪
6. 混合操作: CREATE + 多 search → CREATE 独立，search 走 two-phase
7. 多文件交织: patch text 含 file1 + file2 + file1 → 正确分组
8. 现有测试: uv run pytest tests/ 全通过（回归）
```
