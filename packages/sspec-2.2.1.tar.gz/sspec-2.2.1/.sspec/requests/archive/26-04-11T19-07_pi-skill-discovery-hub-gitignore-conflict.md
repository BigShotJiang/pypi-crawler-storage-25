---
created: 2026-04-11 19:07:06+08:00
status: DONE
attach-change: .sspec/changes/archive/26-04-11T19-12_fix-pi-skill-discovery-hub-gitignore-conflict
tldr: Move managed hub-skill ignore rules out of .sspec/skills/.gitignore so Pi can
  discover sspec skills through .agents/skills symlink without breaking Git hygiene.
archived: '2026-04-11T20:29:28'
---
# Request: pi-skill-discovery-hub-gitignore-conflict

## What I Want

Adjust sspec's hub skill gitignore design so that Pi can correctly discover sspec skills when `.agents/skills` is a symlink/junction to `.sspec/skills`.

Current desired outcome:
- keep `.sspec/skills` as the hub/source-of-truth
- keep spoke directories like `.agents/skills` ignored as distribution views
- keep managed template skills ignored from Git by default
- but do **not** let hub-local ignore rules hide skills from runtime skill discovery tools

A likely direction is:
- stop writing managed skill names into `.sspec/skills/.gitignore`
- instead write hub-managed ignore entries into `.sspec/.gitignore` as `skills/<name>` paths
- keep spoke `.gitignore` behavior unchanged (`<spoke-parent>/.gitignore` ignores `skills`)

## Why

In Pi, project `.agents/skills` is a documented and supported skill discovery location. Pi also follows symlinked directories and respects `.gitignore` / `.ignore` / `.fdignore` during recursive skill discovery.

In a real project using sspec:
- `.agents/skills` was a symlink to `.sspec/skills`
- sspec had written managed entries like `sspec-align`, `sspec-design`, etc. into `.sspec/skills/.gitignore`
- Pi followed the symlink, read that `.gitignore`, and filtered out all managed sspec skills
- result: AGENTS.md contained SSPEC protocol text, but `available_skills` did not include any `sspec-*` skills

So the current hub `.gitignore` placement creates an interoperability bug: Git-management details inside the hub directory leak into runtime discovery semantics for external agent tools.

## Additional Context

Relevant files:
- `src/sspec/services/project_update_service.py`
- `src/sspec/skill_installer.py`
- `.sspec/spec-docs/skill-installation.md`
- `tests/test_project_update_service.py`
- `tests/test_skill_installer.py`
- `tests/test_project_init_skill_sync.py`

Observed current behavior:
- spoke ignore behavior is reasonable: e.g. `.agents/.gitignore` contains `skills`
- hub ignore behavior is problematic: `.sspec/skills/.gitignore` contains managed skill directory names

Important nuance:
- the issue is **not** that Pi fails to support `.agents/skills`
- the issue is **not** that Pi fails to follow symlinks
- the issue is the interaction between symlinked hub consumption and hub-local ignore rules

Expected design constraints:
- preserve current Git hygiene goals
- preserve support for user-added custom skills under `.sspec/skills`
- avoid breaking update/migration/orphan-cleanup flows
- ideally add/adjust tests to lock in the new contract

## Suggested Acceptance Criteria

- Managed hub skill ignore rules are no longer written to `.sspec/skills/.gitignore`
- Equivalent ignore behavior is implemented at `.sspec/.gitignore` scope using `skills/<name>` entries or another solution that does not poison hub-root runtime discovery
- `.agents/skills -> .sspec/skills` remains consumable by Pi skill discovery
- Existing spoke ignore behavior remains unchanged
- Relevant tests and spec-docs are updated
