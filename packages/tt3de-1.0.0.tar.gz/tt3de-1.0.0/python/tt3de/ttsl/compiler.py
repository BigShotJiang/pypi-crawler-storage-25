# -*- coding: utf-8 -*-
from dataclasses import dataclass
from collections import defaultdict
import ast
import traceback
from typing import Any, Dict, List, Optional, Tuple, Set

from pyglm import glm

from tt3de.ttsl.ttisa.low_level_def import generate_all_forms, Form
from tt3de.ttsl.ttsl_assembly import (
    CFG,
    STR_TO_IRTYPE,
    IRInstr,
    IROperand,
    IRProgram,
    IRType,
    NodeID,
    OpCodes,
    SSAVarID,
    Temp,
    TempID,
    is_operand_ssavar,
    CFGNode,
    build_cfg_from_ir,
    ConstantPool,
)

PRELUDE_GLM_IMPORT = """
# GLM prelude
from pyglm import glm
vec2 = glm.vec2
vec3 = glm.vec3
vec4 = glm.vec4
# End GLM prelude
"""
# defines allowed types in the IR:
ALLOWED_IR_TYPES = {
    float: IRType.F32,
    int: IRType.I32,
    bool: IRType.BOOL,
    glm.vec2: IRType.V2,
    glm.vec3: IRType.V3,
    glm.vec4: IRType.V4,
}

VECTOR_CONSTRUCTORS = {"vec2": IRType.V2, "vec3": IRType.V3, "vec4": IRType.V4}

# TTSL names follow the OpenGL/GLSL convention `gl_<CamelCase>` as `tt_<CamelCase>`.
# Pixel inputs (`PIXEL_VARIABLES_STR_TYPE`) are always predeclared; engine uniforms such as
# `GLOBAL_VAR_TT_TIME`, `GLOBAL_VAR_TT_DELTA_TIME`, `GLOBAL_VAR_TT_FRAME`,
# `GLOBAL_VAR_TT_RESOLUTION`, `GLOBAL_VAR_TT_NEAR`, and `GLOBAL_VAR_TT_FAR` are only
# bound when passed in `globals_dict`. Keep names in sync with `source/ttsl.md`.
GLOBAL_VAR_TT_TIME: str = "tt_Time"
GLOBAL_VAR_TT_DELTA_TIME: str = "tt_DeltaTime"
GLOBAL_VAR_TT_FRAME: str = "tt_Frame"
GLOBAL_VAR_TT_RESOLUTION: str = "tt_Resolution"
GLOBAL_VAR_TT_NEAR: str = "tt_Near"
GLOBAL_VAR_TT_FAR: str = "tt_Far"
PIXELVAR_TT_FRAGCOORD: str = "tt_FragCoord"
PIXELVAR_TT_TEXCOORD0: str = "tt_TexCoord0"
PIXELVAR_TT_TEXCOORD1: str = "tt_TexCoord1"
PIXELVAR_TT_FRAGPOS: str = "tt_FragPos"
PIXELVAR_TT_FRONT_FACING: str = "tt_FrontFacing"
PIXELVAR_TT_FRAG_DEPTH: str = "tt_FragDepth"
PIXELVAR_TT_LINE_COORD: str = "tt_LineCoord"
PIXELVAR_TT_POINT_COORD: str = "tt_PointCoord"
PIXELVAR_TT_PRIMITIVE_ID: str = "tt_PrimitiveID"

PIXEL_VARIABLES_STR_TYPE = {
    PIXELVAR_TT_FRAGCOORD: IRType.V2,
    PIXELVAR_TT_TEXCOORD0: IRType.V2,
    PIXELVAR_TT_TEXCOORD1: IRType.V2,
    PIXELVAR_TT_FRAGPOS: IRType.V2,
    PIXELVAR_TT_POINT_COORD: IRType.V2,
    PIXELVAR_TT_FRONT_FACING: IRType.BOOL,
    PIXELVAR_TT_FRAG_DEPTH: IRType.F32,
    PIXELVAR_TT_LINE_COORD: IRType.F32,
    PIXELVAR_TT_PRIMITIVE_ID: IRType.I32,
}

NATIVE_UNI_OPS_TYPE = {
    "sin": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "cos": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "tan": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "abs": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "neg": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "floor": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "ceil": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "fract": (IRType.F32, IRType.V2, IRType.V3, IRType.V4),
    "norm": (IRType.V2, IRType.V3, IRType.V4),
}

GLM_TOOLS = {
    "mix": (
        (IRType.V2, IRType.V3, IRType.V4),  # input types x
        (IRType.V2, IRType.V3, IRType.V4),  # input types y
        (IRType.F32),  # input type a
    ),
    "mix_vec": (
        (IRType.V2, IRType.V3, IRType.V4),
        (IRType.V2, IRType.V3, IRType.V4),
        (IRType.V2, IRType.V3, IRType.V4),
    ),
    "cross": (
        (IRType.V3,),
        (IRType.V3,),
    ),
    "dot": (
        (IRType.V2, IRType.V3, IRType.V4),
        (IRType.V2, IRType.V3, IRType.V4),
    ),
}


class CleanPythonTreePass(ast.NodeTransformer):
    def visit_Expr(self, node):
        # Strip out bare `print(...)` calls from the AST
        if (
            isinstance(node.value, ast.Call)
            and getattr(node.value.func, "id", None) == "print"
        ):
            return None
        if isinstance(node.value, ast.Import) or isinstance(node.value, ast.ImportFrom):
            return None

        return node


class CompileError(Exception):
    def __init__(self, node, *args):
        super().__init__(*args)
        self.node = node


class TTSLCompilerContext:
    def __init__(self, globals_dict: Dict[SSAVarID, IRType]):
        self.code = IRProgram()
        self.globals: Dict[SSAVarID, IRType] = globals_dict
        self.named_variables: Dict[SSAVarID, Temp] = {}
        self.next_temp_id = len(self.named_variables)
        self._temp_collection: List[Temp] = []

        # place holder for later passes
        self.cfg: CFG | None = None
        self.ssa_var_definitions: Dict[SSAVarID, Set[NodeID]] = {}
        self.const_pool: ConstantPool = ConstantPool()
        # Filled in `parse_args`: names live at function entry (pixel inputs, uniforms, params).
        self.ssa_entry_seed_names: frozenset[SSAVarID] = frozenset()

        # Predefine some variables
        for name, ty in self.always_present_variables_at_init().items():
            self.named_variables[name] = self.alloc_temp_for_type(ty)
        for name, ty in self.globals.items():
            self.named_variables[name] = self.alloc_temp_for_type(ty)

    def temp_id_to_variable(self, temp_id: TempID) -> Optional[SSAVarID]:
        for var_name, temp in self.named_variables.items():
            if temp.id == temp_id:
                return var_name
        return None

    def always_present_variables_at_init(self) -> Dict[str, IRType]:
        return self.always_present_variables()

    @classmethod
    def always_present_variables(cls) -> Dict[str, IRType]:
        """Per-cell inputs only (including ``tt_FrontFacing`` as ``bool``, winding-based,
        ``tt_FragDepth`` as ``float`` (depth value for the shaded depth layer from the
        depth buffer), ``tt_LineCoord`` as ``float`` (parametric coordinate along rasterized
        line segments, ``0.0`` when not a line), ``tt_PointCoord`` as ``glm.vec2`` (coordinates
        within a point sprite, ``(0, 0)`` when not a point), and ``tt_PrimitiveID`` as ``int``: per-pixel
        index of the depth-winning primitive,
        ``[0..PrimitiveBuffer.current_size-1]``; mirrors GLSL ``gl_PrimitiveID``).
        Engine uniforms such as ``tt_Time`` / ``tt_DeltaTime`` (``float``), ``tt_Frame``
        (``int``), ``tt_Resolution`` (``glm.vec2``: width_cells, height_cells), and
        ``tt_Near`` / ``tt_Far`` (``float``: clip distances) must be
        passed via ``globals_dict`` when referenced."""
        return dict(PIXEL_VARIABLES_STR_TYPE)

    def comment(self, text: str):
        instr = IRInstr(
            op=OpCodes.COMMENT,
            src1=None,
            src2=None,
            src3=None,
            src4=None,
            dst=None,
            imm=None,
            label=None,
            comment=text,
        )
        return self.code.append(instr)

    def emit_1(self, op, src1, dst, comment=None, imm=None):
        instr = IRInstr(
            op=op,
            src1=src1,
            src2=None,
            src3=None,
            src4=None,
            dst=dst,
            imm=imm,
            label=None,
            comment=comment,
        )
        return self.code.append(instr)

    def emit_2(self, op, src1, src2, dst, comment=None):
        instr = IRInstr(
            op=op,
            src1=src1,
            src2=src2,
            src3=None,
            src4=None,
            dst=dst,
            imm=None,
            label=None,
            comment=comment,
        )
        return self.code.append(instr)

    def emit(self, op, src1, src2, src3, src4, dst, comment=None):
        instr = IRInstr(
            op=op,
            src1=src1,
            src2=src2,
            src3=src3,
            src4=src4,
            dst=dst,
            imm=None,
            label=None,
            comment=comment,
        )
        return self.code.append(instr)

    def alloc_temp_for_type(self, ty: IRType) -> Temp:
        reg = Temp(id=self.next_temp_id, ty=ty)
        self._temp_collection.append(reg)
        self.next_temp_id += 1
        return reg

    def get_tempid_type(self, tempid: TempID) -> IRType:
        for temp in self._temp_collection:
            if temp.id == tempid:
                return temp.ty
        raise RuntimeError(f"TempID {tempid} not found")

    def find_temp_by_id(self, tempid: TempID) -> Temp:
        for temp in self._temp_collection:
            if temp.id == tempid:
                return temp
        raise RuntimeError(f"TempID {tempid} not found")

    def _last_meaningful_ir_op(self) -> Optional[OpCodes]:
        """Last opcode in the IR stream, ignoring span bookkeeping (LABEL / COMMENT)."""
        skip = {OpCodes.COMMENT, OpCodes.LABEL}
        for instr in reversed(self.code.instrs):
            if instr.op in skip:
                continue
            return instr.op
        return None

    def _compile_return_shader_triple(self, node: ast.Return) -> None:
        if node.value is None:
            raise CompileError(
                node,
                "TTSL shader must return (front: vec3, back: vec3, glyph: int); "
                "bare return is not allowed",
            )
        val = node.value
        if not isinstance(val, ast.Tuple):
            raise CompileError(
                val,
                "TTSL shader must return a 3-tuple (front, back, glyph) with types "
                "(vec3, vec3, int), e.g. return (color, color, 0); "
                "a single vec3 is no longer valid",
            )
        if len(val.elts) != 3:
            raise CompileError(
                val,
                "TTSL return tuple must have exactly 3 elements (front, back, glyph); "
                f"got {len(val.elts)}",
            )
        e_front, e_back, e_glyph = val.elts
        t_front = self.type_of(e_front)
        t_back = self.type_of(e_back)
        t_glyph = self.type_of(e_glyph)
        if (t_front, t_back, t_glyph) != (IRType.V3, IRType.V3, IRType.I32):
            raise CompileError(
                val,
                "TTSL return element types must be (vec3, vec3, int); "
                f"got ({t_front}, {t_back}, {t_glyph})",
            )
        r_front = self.compile_expr(e_front, forced_type=IRType.V3)
        r_back = self.compile_expr(e_back, forced_type=IRType.V3)
        r_glyph = self.compile_expr(e_glyph, forced_type=IRType.I32)
        self.emit(
            OpCodes.RET,
            r_front,
            r_back,
            r_glyph,
            None,
            None,
            comment=(
                f"return (front r{r_front.id}, back r{r_back.id}, glyph r{r_glyph.id})"
            ),
        )

    def compile_block(self, stmts: list[ast.stmt]):
        with self.code.block() as _block:
            for s in stmts:
                self.compile_stmt(s)

    def compile_stmt(self, node):
        if isinstance(node, ast.Assign):
            if not len(node.targets) == 1:
                raise CompileError(node, "Multiple assignment targets not supported")
            target = node.targets[0]
            value = node.value
            value_type = self.type_of(value)
            t = self.compile_expr(target, forced_type=value_type)
            v = self.compile_expr(value, forced_type=value_type)
            # emit store from v to t
            comment = f"r{t.id}:{value_type} <- r{v.id}:{value_type}"
            self.emit_1(OpCodes.STORE, v, t, comment=comment)
            # raise NotImplementedError("Use AnnAssign for typed assignments")
        elif isinstance(node, ast.AnnAssign):
            target = node.target

            value = node.value
            value_type = self.type_of(value)

            ty = type_of_annotation(node.annotation)

            if not (value_type == ty):
                raise CompileError(
                    node,
                    f"Type mismatch in assignment: expected {ty}, got {value_type}",
                )

            t = self.compile_expr(target, forced_type=ty)
            v = self.compile_expr(value, forced_type=ty)
            # emit store from v to t
            comment = f"Assign r{v.id}:{ty} to r{t.id}:{ty}"
            self.emit_1(OpCodes.STORE, v, t, comment=comment)
        elif isinstance(node, ast.If):
            self.compile_if(node)
        elif isinstance(node, ast.While):
            self.compile_while(node)
        elif isinstance(node, ast.Return):
            self._compile_return_shader_triple(node)
        else:
            raise NotImplementedError(type(node))

    def compile_expr(self, node, forced_type=None) -> Temp:
        if isinstance(node, ast.Name):
            if node.id not in self.named_variables:
                if forced_type is not None:
                    # Declare a new temp for this variable with the forced type
                    reg = self.alloc_temp_for_type(forced_type)
                    self.named_variables[node.id] = reg
                else:
                    raise CompileError(
                        node,
                        (
                            f"Unknown variable '{node.id}': not declared "
                            "(use an annotated assignment or globals_dict)."
                        ),
                    )
            in_env = self.named_variables[node.id]
            if forced_type is not None and in_env.ty != forced_type:
                raise CompileError(
                    node,
                    f"Type mismatch for variable {node.id}: expected {forced_type}, got {in_env.ty}",
                )
            return self.named_variables[node.id]
        if isinstance(node, ast.Attribute):
            if node.attr in ("x", "y", "z", "w"):
                if forced_type is not None and forced_type != IRType.F32:
                    raise RuntimeError(
                        f"Type mismatch: expected {forced_type}, got F32 from attribute access"
                    )
                parent_type = self.type_of(node.value)
                if parent_type not in (IRType.V2, IRType.V3, IRType.V4):
                    raise RuntimeError(
                        f"Attribute access on non-vector type: {parent_type}"
                    )
                reg = self.compile_expr(node.value, forced_type=parent_type)

                if reg.ty in (IRType.V2, IRType.V3, IRType.V4):
                    result_reg = self.alloc_temp_for_type(IRType.F32)
                    # read the x component from a vector into a float
                    opcode = {
                        "x": OpCodes.READ_AXIS_X,
                        "y": OpCodes.READ_AXIS_Y,
                        "z": OpCodes.READ_AXIS_Z,
                        "w": OpCodes.READ_AXIS_W,
                    }[node.attr]
                    self.emit_1(opcode, reg, result_reg)
                    return result_reg

            raise NotImplementedError(type(node))
        if isinstance(node, ast.Constant):
            type_ret = self.type_of(node)
            reg = self.alloc_temp_for_type(type_ret)
            const_index = self.code.add_constant(node.value, type_ret)
            comment = (
                f"load_const [{const_index}] '{node.value}':{type_ret} into r{reg.id}"
            )
            self.emit_1(OpCodes.LOAD_CONST, None, reg, comment=comment, imm=const_index)
            return reg

        if isinstance(node, ast.BinOp):
            left_type = self.type_of(node.left)
            right_type = self.type_of(node.right)
            left_reg = self.compile_expr(node.left, left_type)
            right_reg = self.compile_expr(node.right, right_type)
            result_reg = self.alloc_temp_for_type(self.type_of(node))
            opcode = opcode_for_binop(node.op, left_reg.ty, right_reg.ty)
            comment = (
                f"({opcode.name} r{left_reg.id}, r{right_reg.id}) -> r{result_reg.id}"
            )
            self.emit_2(
                opcode,
                left_reg,
                right_reg,
                result_reg,
                comment=comment,
            )
            return result_reg
        if isinstance(node, ast.UnaryOp):
            operand_type = self.type_of(node.operand)
            operand_reg = self.compile_expr(node.operand, operand_type)
            if isinstance(node.op, ast.USub):
                result_reg = self.alloc_temp_for_type(operand_type)
                opcode = OpCodes.NEG

                comment = f"NEG r{operand_reg.id} -> r{result_reg.id}"
                self.emit_1(opcode, operand_reg, result_reg, comment=comment)
                return result_reg
            raise NotImplementedError(type(node))
        if isinstance(node, ast.Call):
            func = node.func
            args = node.args
            if "id" in func._fields:
                if func.id in ("sin", "abs", "cos", "floor", "ceil", "fract"):
                    assert len(args) == 1
                    return_type = self.type_of(args[0])
                    arg_reg = self.compile_expr(args[0], return_type)
                    result_reg = self.alloc_temp_for_type(return_type)

                    opcode = opcode_for_uniop(func.id, return_type)
                    self.emit_1(opcode, arg_reg, result_reg)
                    return result_reg
                elif func.id == "mod":
                    if len(args) != 2:
                        raise CompileError(
                            node,
                            f"mod expects 2 arguments (x, y), got {len(args)}",
                        )
                    x_ty = self.type_of(args[0])
                    y_ty = self.type_of(args[1])
                    if x_ty != y_ty:
                        raise CompileError(
                            node,
                            f"mod arguments must have the same type, got {x_ty} and {y_ty}",
                        )
                    x_reg = self.compile_expr(args[0], x_ty)
                    y_reg = self.compile_expr(args[1], y_ty)
                    result_reg = self.alloc_temp_for_type(x_ty)
                    self.emit_2(OpCodes.MOD, x_reg, y_reg, result_reg,
                                comment=f"mod r{x_reg.id}, r{y_reg.id} -> r{result_reg.id}")
                    return result_reg
                elif func.id in VECTOR_CONSTRUCTORS:
                    return self.compile_vec_constructor(
                        node, vec_name=func.id, args=args
                    )
                elif func.id in GLM_TOOLS:
                    return self.compile_glm_tool_call(node, func.id, args)
                elif func.id == "tt_texture":
                    if len(args) != 2:
                        raise CompileError(
                            node,
                            f"tt_texture expects 2 arguments (tex_index: int, coord: vec2), got {len(args)}",
                        )
                    i_ty = self.type_of(args[0])
                    uv_ty = self.type_of(args[1])
                    if i_ty != IRType.I32:
                        raise CompileError(
                            node,
                            f"tt_texture first argument must be int, got {i_ty}",
                        )
                    if uv_ty != IRType.V2:
                        raise CompileError(
                            node,
                            f"tt_texture second argument must be vec2, got {uv_ty}",
                        )
                    idx_reg = self.compile_expr(args[0], IRType.I32)
                    uv_reg = self.compile_expr(args[1], IRType.V2)
                    result_reg = self.alloc_temp_for_type(IRType.V4)
                    self.emit(
                        OpCodes.TT_TEXTURE,
                        idx_reg,
                        uv_reg,
                        None,
                        None,
                        result_reg,
                        comment=(
                            f"tt_texture r{idx_reg.id}, r{uv_reg.id} -> r{result_reg.id}"
                        ),
                    )
                    return result_reg
                raise CompileError(node, f"Unsupported function call '{func.id}'")
            elif "attr" in func._fields:
                if "value" in func._fields and "id" in func.value._fields:
                    if func.value.id == "glm":
                        assert isinstance(func.attr, str)
                        func_name: str = func.attr
                        if func_name in VECTOR_CONSTRUCTORS:
                            return self.compile_vec_constructor(
                                node, vec_name=func_name, args=args
                            )
                        elif func_name in NATIVE_UNI_OPS_TYPE:
                            assert len(args) == 1
                            return_type = self.type_of(args[0])  #
                            arg_reg = self.compile_expr(args[0], return_type)
                            result_reg = self.alloc_temp_for_type(return_type)
                            opcode = opcode_for_uniop(func_name, return_type)
                            self.emit_1(
                                opcode,
                                arg_reg,
                                result_reg,
                                comment=f"glm.{func_name} r{arg_reg.id} -> r{result_reg.id}",
                            )
                            return result_reg
                        elif func_name == "mod":
                            if len(args) != 2:
                                raise CompileError(
                                    node,
                                    f"glm.mod expects 2 arguments (x, y), got {len(args)}",
                                )
                            x_ty = self.type_of(args[0])
                            y_ty = self.type_of(args[1])
                            if x_ty != y_ty:
                                raise CompileError(
                                    node,
                                    f"glm.mod arguments must have the same type, got {x_ty} and {y_ty}",
                                )
                            x_reg = self.compile_expr(args[0], x_ty)
                            y_reg = self.compile_expr(args[1], y_ty)
                            result_reg = self.alloc_temp_for_type(x_ty)
                            self.emit_2(OpCodes.MOD, x_reg, y_reg, result_reg,
                                        comment=f"glm.mod r{x_reg.id}, r{y_reg.id} -> r{result_reg.id}")
                            return result_reg
                        elif func_name in GLM_TOOLS:
                            return self.compile_glm_tool_call(node, func_name, args)
                        raise CompileError(
                            node, f"Unsupported glm function call '{func_name}'"
                        )
            raise NotImplementedError(type(node))

        if isinstance(node, ast.Compare):
            # left: expr
            # ops: list[cmpop]
            # comparators: list[expr]

            left_type = self.type_of(node.left)
            left_reg = self.compile_expr(node.left, left_type)
            assert len(node.ops) == 1
            assert len(node.comparators) == 1
            right_type = self.type_of(node.comparators[0])
            right_reg = self.compile_expr(node.comparators[0], right_type)

            if left_type != right_type:
                raise CompileError(
                    node, f"Type mismatch in comparison: {left_type} vs {right_type}"
                )

            result_reg = self.alloc_temp_for_type(IRType.BOOL)
            if isinstance(node.ops[0], ast.Gt):
                opcode = OpCodes.CMP_GT
                self.emit_2(opcode, left_reg, right_reg, result_reg)
                return result_reg
            elif isinstance(node.ops[0], ast.GtE):
                opcode = OpCodes.CMP_GTE
                self.emit_2(opcode, left_reg, right_reg, result_reg)
                return result_reg
            elif isinstance(node.ops[0], ast.Lt):
                # a < b  <=>  b > a
                opcode = OpCodes.CMP_GT
                self.emit_2(opcode, right_reg, left_reg, result_reg)
                return result_reg
            elif isinstance(node.ops[0], ast.LtE):
                # a <= b  <=>  b >= a
                opcode = OpCodes.CMP_GTE
                self.emit_2(opcode, right_reg, left_reg, result_reg)
                return result_reg
            else:
                raise NotImplementedError(
                    f"Unsupported comparison operator {node.ops[0]}"
                )
        raise NotImplementedError(type(node))

    def compile_vec_constructor(
        self, node: ast.Call, vec_name: str, args: list[ast.expr]
    ) -> Temp:
        target_vector_dimension = {"vec2": 2, "vec3": 3, "vec4": 4}[vec_name]
        if not len(args) == target_vector_dimension:
            raise CompileError(
                node,
                f"Function 'glm.{vec_name}' expects {target_vector_dimension} arguments, got {len(args)}",
            )
        for arg in args:
            arg_type = self.type_of(arg)
            if arg_type != IRType.F32:
                raise CompileError(
                    node,
                    f"Function 'glm.{vec_name}' expects f32 arguments, got {arg_type}",
                )
        arg_regs = [self.compile_expr(arg, IRType.F32) for arg in args]
        result_type = {
            2: IRType.V2,
            3: IRType.V3,
            4: IRType.V4,
        }[target_vector_dimension]
        result_reg = self.alloc_temp_for_type(result_type)
        # Assuming a constructor call
        comment = f"glm.{vec_name} arg {[r.id for r in arg_regs]} -> r{result_reg.id}"
        if target_vector_dimension == 2:
            self.emit_2(
                OpCodes.STORE_VEC_FROM_SCALAR,
                arg_regs[0],
                arg_regs[1],
                result_reg,
                comment=comment,
            )
        elif target_vector_dimension == 3:
            self.emit(
                OpCodes.STORE_VEC_FROM_SCALAR,
                arg_regs[0],
                arg_regs[1],
                arg_regs[2],
                None,
                result_reg,
                comment=comment,
            )
        elif target_vector_dimension == 4:
            self.emit(
                OpCodes.STORE_VEC_FROM_SCALAR,
                arg_regs[0],
                arg_regs[1],
                arg_regs[2],
                arg_regs[3],
                result_reg,
                comment=comment,
            )
        else:
            raise CompileError(
                node,
                f"Unsupported vector dimension: {target_vector_dimension}",
            )
        return result_reg

    def compile_glm_tool_call(
        self, node: ast.Call, func_attr: str, args: list[ast.expr]
    ) -> Temp:
        tool_signatures = GLM_TOOLS[func_attr]
        if len(args) != len(tool_signatures):
            raise CompileError(
                node,
                f"Function 'glm.{func_attr}' expects {len(tool_signatures)} arguments, got {len(args)}",
            )
        if func_attr == "mix":
            # glm.mix(x: vecN, y: vecN, a: f32) -> vecN
            x_type = self.type_of(args[0])
            y_type = self.type_of(args[1])
            a_type = self.type_of(args[2])
            if x_type != y_type:
                raise CompileError(
                    node,
                    f"Function 'glm.{func_attr}' expects first two arguments of same type, got {x_type} and {y_type}",
                )
            if a_type != IRType.F32:
                raise CompileError(
                    node,
                    f"Function 'glm.{func_attr}' expects third argument of type f32, got {a_type}",
                )
            if x_type not in tool_signatures[0]:
                raise CompileError(
                    node,
                    f"Function 'glm.{func_attr}' does not support argument type {x_type}",
                )
            x_reg = self.compile_expr(args[0], x_type)
            y_reg = self.compile_expr(args[1], y_type)
            a_reg = self.compile_expr(args[2], IRType.F32)
            result_reg = self.alloc_temp_for_type(x_type)
            comment = f"glm.{func_attr} r{x_reg.id}, r{y_reg.id}, r{a_reg.id} -> r{result_reg.id}"
            self.emit(
                OpCodes.MIX,
                x_reg,
                y_reg,
                a_reg,
                None,
                result_reg,
                comment=comment,
            )
            return result_reg
        raise CompileError(
            node,
            f"Unsupported glm tool function '{func_attr}'",
        )

    def compile_if(self, node: ast.If):
        # 1. condition
        test_type = self.type_of(node.test)
        if test_type != IRType.BOOL:
            raise CompileError(
                node,
                f"If condition must be of type BOOL, got {test_type}",
            )
        cond_reg = self.compile_expr(node.test, test_type)

        # 2. jump to else if false
        jmp_false_pos = self.emit_2(
            OpCodes.JMP_IF_FALSE, cond_reg, None, None
        )  # target to fill later

        # 3. then block
        self.compile_block(node.body)

        # 4. jump to end (skip else) — skip when the then-branch already ends in RET,
        #    otherwise we emit dead IR after RET that breaks CFG construction.
        jmp_end_pos: Optional[int] = None
        if self._last_meaningful_ir_op() != OpCodes.RET:
            jmp_end_pos = self.emit_2(OpCodes.JMP, None, None, None)

        # 5. else block
        else_start = self.code.instructions_count()
        self.compile_block(node.orelse)

        # 6. patch false jump to else start
        self.code.patch_target(jmp_false_pos, else_start)

        # 7. patch jump to end (if we emitted one)
        if jmp_end_pos is not None:
            end_pos = self.code.instructions_count()
            self.code.patch_target(jmp_end_pos, end_pos)

    def compile_while(self, node: ast.While):
        loop_start = len(self.code)

        cond_reg = self.compile_expr(node.test)

        jmp_exit_pos = self.emit_2(
            OpCodes.JMP_IF_FALSE, cond_reg.index, 0, 0
        )  # patch later

        self.compile_block(node.body)

        self.emit_2(OpCodes.JMP, loop_start, 0, 0)
        exit_pos = len(self.code)
        self.code.patch_target(jmp_exit_pos, exit_pos)

    def parse_args(self, fn_node: ast.FunctionDef):
        for arg in fn_node.args.args:
            arg_name = arg.arg
            assert "annotation" in arg._fields
            arg_annotation = arg.annotation
            try:
                arg_type = type_of_annotation(arg_annotation)
            except NotImplementedError as e:
                raise CompileError(
                    arg,
                    f"Unsupported type annotation for argument '{arg_name}': {arg_annotation}",
                ) from e
            # Allocate a temp for this argument
            arg_temp = self.alloc_temp_for_type(arg_type)
            self.named_variables[arg_name] = arg_temp

        self.ssa_entry_seed_names = frozenset(
            set(self.always_present_variables().keys())
            | set(self.globals.keys())
            | {a.arg for a in fn_node.args.args}
        )

    def type_of(self, node: ast.expr, type_args=None) -> IRType:
        if isinstance(node, ast.Constant):
            py_type = type(node.value)
            if py_type in ALLOWED_IR_TYPES:
                return ALLOWED_IR_TYPES[type(node.value)]
            else:
                raise NotImplementedError(f"Constant of type {py_type} not supported")
        elif isinstance(node, ast.BinOp):
            left_type = self.type_of(node.left)
            right_type = self.type_of(node.right)
            if isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div)):
                if left_type == right_type:
                    return left_type
                elif left_type in (IRType.F32, IRType.I32) and right_type in (
                    IRType.V2,
                    IRType.V3,
                    IRType.V4,
                ):
                    return right_type
                elif right_type in (IRType.F32, IRType.I32) and left_type in (
                    IRType.V2,
                    IRType.V3,
                    IRType.V4,
                ):
                    return left_type
                else:
                    raise RuntimeError(
                        f"Type mismatch in binary operation: {left_type} vs {right_type}"
                    )
            else:
                raise NotImplementedError(
                    f"Unsupported binary operation {node.op} for types: {left_type}, {right_type}"
                )
        elif isinstance(node, ast.Name):
            if "id" in node._fields:
                if node.id in self.named_variables:
                    return self.named_variables[node.id].ty
                elif node.id in ("abs", "sin", "cos", "floor", "ceil", "fract"):
                    if type_args is not None and len(type_args) == 1:
                        return type_args[0]
                    raise CompileError(
                        node, f"Cannot determine return type of function '{node.id}'"
                    )
                elif node.id == "mod":
                    if type_args is not None and len(type_args) == 2:
                        if type_args[0] != type_args[1]:
                            raise CompileError(
                                node,
                                f"mod arguments must have the same type, got {type_args[0]} and {type_args[1]}",
                            )
                        return type_args[0]
                    raise CompileError(
                        node,
                        "Cannot determine return type of mod (need 2 same-type arguments)",
                    )
                elif node.id == "tt_texture":
                    if type_args is not None and len(type_args) == 2:
                        ti, tv = type_args
                        if ti != IRType.I32:
                            raise CompileError(
                                node,
                                f"tt_texture expects int texture index, got {ti}",
                            )
                        if tv != IRType.V2:
                            raise CompileError(
                                node,
                                f"tt_texture expects vec2 coord, got {tv}",
                            )
                        return IRType.V4
                    raise CompileError(
                        node,
                        "Cannot determine return type of tt_texture (need int, vec2 arguments)",
                    )
                elif node.id in PIXEL_VARIABLES_STR_TYPE:  #
                    return PIXEL_VARIABLES_STR_TYPE[node.id]
                elif node.id in STR_TO_IRTYPE:  #
                    return STR_TO_IRTYPE[node.id]

            raise CompileError(
                node,
                (
                    f"Unknown variable '{node.id}': not a TTSL built-in, "
                    "shader parameter, or globals_dict uniform "
                    "(check spelling; built-ins use tt_<CamelCase>)."
                ),
            )
        elif isinstance(node, ast.Attribute):
            if node.attr in ("x", "y", "z", "w"):
                value_type = self.type_of(node.value)
                if value_type == IRType.V2:
                    return IRType.F32
                elif value_type == IRType.V3:
                    return IRType.F32
                elif value_type == IRType.V4:
                    return IRType.F32
            elif node.attr in ("sin", "cos", "floor", "ceil", "fract"):
                if type_args is not None and len(type_args) == 1:
                    return type_args[0]
                raise CompileError(
                    node,
                    f"Function '{node.attr}' expects one Typed argument, got {type_args}",
                )
            elif node.attr == "mod":
                if type_args is not None and len(type_args) == 2:
                    if type_args[0] != type_args[1]:
                        raise CompileError(
                            node,
                            f"mod arguments must have the same type, got {type_args[0]} and {type_args[1]}",
                        )
                    return type_args[0]
                raise CompileError(
                    node,
                    f"Function 'mod' expects 2 same-type arguments, got {type_args}",
                )
            elif node.attr in ("vec3", "vec2", "vec4"):
                count = {"vec2": 2, "vec3": 3, "vec4": 4}[node.attr]
                if type_args is not None and len(type_args) == count:
                    for type_arg in type_args:
                        if type_arg != IRType.F32:
                            raise CompileError(
                                node,
                                f"Function '{node.attr}' expects f32 arguments, got {type_args}",
                            )

                    return {
                        2: IRType.V2,
                        3: IRType.V3,
                        4: IRType.V4,
                    }[count]

                raise CompileError(
                    node,
                    f"Function '{node.attr}' expects {count} f32 arguments, got {type_args}",
                )
        elif isinstance(node, ast.Call):
            func = node.func
            args = node.args
            type_args = [self.type_of(arg) for arg in args]
            func_type = self.type_of(func, type_args)
            return func_type
        elif isinstance(node, ast.Compare):
            return IRType.BOOL
        # elif isinstance(node, ast.Return):
        elif isinstance(node, ast.UnaryOp):
            operand_type = self.type_of(node.operand)
            if isinstance(node.op, ast.USub):
                return operand_type
            else:
                raise NotImplementedError(f"Unsupported unary operation {node.op}")
        raise NotImplementedError(f"Cannot determine type of node: {node}")


def compile_ttsl(src, function_name, globals_dict: Dict) -> TTSLCompilerContext:
    _, fn_node = parse_ttsl_source(src, function_name)
    return compile_ttsl_function(fn_node, globals_dict)


def compile_ttsl_function(
    fn_node: ast.FunctionDef, globals_dict: Dict
) -> TTSLCompilerContext:
    tree = CleanPythonTreePass().visit(fn_node)
    tree = ast.fix_missing_locations(tree)

    _validate_shader_returns_annotation(fn_node)

    typed_globals = {}
    for k, pytype in globals_dict.items():
        if pytype not in ALLOWED_IR_TYPES:
            raise CompileError(
                fn_node,
                f"Unsupported global variable type for '{k}': {pytype}",
            )
        typed_globals[k] = ALLOWED_IR_TYPES[pytype]

    sc = TTSLCompilerContext(typed_globals)
    sc.parse_args(fn_node)
    sc.compile_block(tree.body)
    sc.code.fix_jump_targets()
    return sc


def parse_ttsl_source(src: str, function_name: str) -> Tuple[ast.Module, ast.FunctionDef]:
    tree = ast.parse(src)
    fn_node: Optional[ast.FunctionDef] = None
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name == function_name:
            fn_node = node
            break
    if fn_node is None:
        raise RuntimeError("Could not find function node in AST")
    return tree, fn_node


def type_of_annotation(arg_annotation) -> IRType:
    if isinstance(arg_annotation, ast.Attribute):
        return IRType.from_str(arg_annotation.attr)
    elif isinstance(arg_annotation, ast.Name):
        return IRType.from_str(arg_annotation.id)
    raise NotImplementedError(f"Unsupported annotation type: {arg_annotation}")


def _validate_shader_returns_annotation(fn_node: ast.FunctionDef) -> None:
    """If the shader function has a return annotation, require tuple[vec3, vec3, int]."""
    ann = fn_node.returns
    if ann is None:
        return
    elts: Optional[List[ast.expr]] = None
    if isinstance(ann, ast.Subscript):
        base = ann.value
        ok_base = (isinstance(base, ast.Name) and base.id == "tuple") or (
            isinstance(base, ast.Attribute) and base.attr == "Tuple"
        )
        if ok_base:
            sl = ann.slice
            if isinstance(sl, ast.Tuple):
                elts = list(sl.elts)
    if elts is None:
        raise CompileError(
            ann,
            "TTSL shader return annotation must be tuple[vec3, vec3, int] "
            "(or typing.Tuple[vec3, vec3, int]) when a return type is given",
        )
    if len(elts) != 3:
        raise CompileError(
            ann,
            f"TTSL return annotation must list exactly 3 types (vec3, vec3, int); "
            f"got {len(elts)}",
        )
    try:
        got = tuple(type_of_annotation(e) for e in elts)
    except (NotImplementedError, ValueError) as ex:
        raise CompileError(
            elts[0],
            f"Unsupported type in shader return annotation: {ex}",
        ) from ex
    if got != (IRType.V3, IRType.V3, IRType.I32):
        raise CompileError(
            ann,
            "TTSL shader return annotation must be tuple[vec3, vec3, int]; "
            f"got ({', '.join(str(t) for t in got)})",
        )


def opcode_for_binop(op, left_type: IRType, right_type: IRType) -> OpCodes:
    if isinstance(op, ast.Add):
        return OpCodes.ADD
    if isinstance(op, ast.Sub):
        return OpCodes.SUB
    if isinstance(op, ast.Mult):
        return OpCodes.MUL
    if isinstance(op, ast.Div):
        return OpCodes.DIV
    raise NotImplementedError(
        f"Unsupported binary operation for types: {left_type}, {right_type}"
    )


def opcode_for_uniop(op_name: str, operand_type: IRType) -> OpCodes:
    if operand_type in (IRType.BOOL,):
        raise NotImplementedError(
            f"Unsupported unary operation for type: {operand_type}"
        )
    elif operand_type in (IRType.F32, IRType.I32, IRType.V2, IRType.V3, IRType.V4):
        name_to_op = {
            "sin": OpCodes.SIN,
            "abs": OpCodes.ABS,
            "floor": OpCodes.FLOOR,
            "ceil": OpCodes.CEIL,
            "fract": OpCodes.FRACT,
        }
        if op_name in name_to_op:
            return name_to_op[op_name]
    raise NotImplementedError(f"Unsupported unary operation: {op_name}")


class SSARenamer:
    def __init__(
        self,
        cfg: CFG,
        ttsl_compiler: TTSLCompilerContext,
        dom_tree: Dict[NodeID, List[NodeID]],
        entry_idx: NodeID,
    ):
        self.cfg = cfg
        self.ttsl_compiler = ttsl_compiler
        self.ir: IRProgram = ttsl_compiler.code
        self.dom_tree = dom_tree
        self.entry_idx = entry_idx

        # var -> stack of TempID (SSA versions)
        self.stack: Dict[SSAVarID, List[TempID]] = {}

        # var -> counter (optional; if you just use global temp allocator, you don’t need this)
        # self.var_version: Dict[Any, int] = {}
        self.__allocated_temps: List[Temp] = []

    def _has_allocated_temp_for_id(self, tid: TempID) -> bool:
        # Check if allocated Temp exists for given TempID
        return any(_t.id == tid for _t in self.__allocated_temps)

    def _allocated_temps_for_id(self, tid: TempID) -> Temp:
        # Find allocated Temp by its ID or raise Exception if not found
        found_temps = [_t for _t in self.__allocated_temps if _t.id == tid]
        if not found_temps:
            raise RuntimeError(f"TempID {tid} not found in allocated temps")
        return found_temps[0]

    def new_temp(self, ty: IRType) -> Temp:
        """Allocate a fresh TempID."""
        assert ty is not None
        temp = self.ttsl_compiler.alloc_temp_for_type(ty)
        self.__allocated_temps.append(temp)
        return temp

    # ---------- Stack helpers ----------
    def push(self, var: SSAVarID, tid: TempID) -> None:
        self.stack.setdefault(var, []).append(tid)

    def pop(self, var: SSAVarID) -> TempID:
        return self.stack[var].pop()

    def top(self, var: SSAVarID) -> Optional[TempID]:
        st = self.stack.get(var)
        return st[-1] if st else None

    # ---------- Operand rewriting ----------
    def rewrite_use(self, op: Optional[IROperand]) -> Optional[IROperand]:
        """Rewrite a use operand: VarRef(v) -> TempRef(current_version(v))."""
        if op is None:
            return None

        if is_operand_ssavar(op):
            assert isinstance(op, str)
            v = op
            t = self.top(v)
            if t is None:
                # Uninitialized use:
                raise ValueError(f"SSA rename: use of variable {v!r} before definition")
            return self._allocated_temps_for_id(t)

        elif isinstance(op, Temp):
            #  if op is a temps which ID is actually SSAVarID string
            maybe_variable = self.ttsl_compiler.temp_id_to_variable(op.id)
            if maybe_variable is not None:
                v = maybe_variable
                t = self.top(v)
                if t is None:
                    raise ValueError(
                        f"SSA rename: use of variable {v!r} before definition"
                    )
                if self._has_allocated_temp_for_id(t):
                    return self._allocated_temps_for_id(t)
                else:
                    return op
                # return TempID(t)
        return op  # TempRef/ConstRef unchanged

    def is_var_def(self, dst: Optional[IROperand]) -> bool:
        """True if this instruction defines a variable (dst is VarRef)."""

        if isinstance(dst, Temp):
            if self.ttsl_compiler.temp_id_to_variable(dst.id) is not None:
                # This is a named variable (not a temporary)
                return True
        elif isinstance(dst, int):
            if self._has_allocated_temp_for_id(dst):
                return True
        return dst is not None and is_operand_ssavar(dst)

    def rewrite_def(self, dst: IROperand, ty: IRType) -> Tuple[SSAVarID, Temp]:
        """
        Rewrite a definition: VarRef(v) = ... becomes TempRef(new) = ...
        Push the new temp as current version for v.
        """

        assert (
            is_operand_ssavar(dst)
            or self.ttsl_compiler.temp_id_to_variable(dst.id) is not None
        )
        v = self.ttsl_compiler.temp_id_to_variable(dst.id)
        assert isinstance(v, str)
        new_temp = self.new_temp(ty)
        new_tid = new_temp.id
        self.push(v, new_tid)

        return v, self._allocated_temps_for_id(new_tid)

    # ---------- Instruction rewriting ----------
    def rewrite_instruction(self, instr: IRInstr) -> List[Any]:
        """
        Rewrite one instruction in-place.

        Returns list of variables pushed (so we can pop when leaving the block).
        """
        pushed_vars: List[SSAVarID] = []
        if instr.op == OpCodes.JMP:
            # Jump destination is patched later as a block label; no SSA operands.
            return pushed_vars
        if instr.op == OpCodes.JMP_IF_FALSE:
            # Condition register must use the current SSA version; jump target stays symbolic.
            instr.src1 = self.rewrite_use(instr.src1)
            return pushed_vars
        # Rewrite uses first
        instr.src1 = self.rewrite_use(instr.src1)
        instr.src2 = self.rewrite_use(instr.src2)
        instr.src3 = self.rewrite_use(instr.src3)
        instr.src4 = self.rewrite_use(instr.src4)
        # If you have extra operands, rewrite them too.

        # Rewrite def if dst is a VarRef

        if self.is_var_def(instr.dst):
            assert isinstance(instr.dst, Temp)
            ty = instr.dst.ty

            v, new_dst = self.rewrite_def(instr.dst, ty=ty)
            instr.dst = new_dst
            pushed_vars.append(v)

        return pushed_vars

    # ---------- Phi rewriting ----------
    def define_phi_dsts(self, node_id: NodeID) -> List[SSAVarID]:
        """
        At block entry: for each phi(var) in this block,
        allocate a new TempID, assign phi.dst, push it.
        Return list of vars pushed for popping later.
        """
        node = self.cfg.nodes[node_id]
        pushed: List[SSAVarID] = []

        assert self.ttsl_compiler.named_variables is not None

        for var, phi in node.phis.items():
            # Allocate new SSA version for the phi result
            assert isinstance(phi.dst, SSAVarID)
            temp = self.new_temp(self.ttsl_compiler.named_variables[phi.dst].ty)
            tid = temp.id
            phi.dst = temp
            self.push(var, tid)
            pushed.append(var)

        return pushed

    def fill_phi_operands_from_block(self, block_idx: int) -> None:
        """For each successor S of block_idx, for each phi(var) in S, set operand for
        predecessor block_idx to current top(var)."""
        for succ_idx in self.cfg.successors(block_idx):
            succ_node = self.cfg.nodes[succ_idx]
            if succ_node is None:
                continue

            for var, phi in succ_node.phis.items():
                cur = self.top(var)
                if cur is None:
                    raise ValueError(
                        f"SSA rename: no current version for var {var!r} "
                        f"when filling phi operand from pred {block_idx} -> {succ_idx}"
                    )
                assert isinstance(phi.phi_operands, Dict)
                phi.phi_operands[block_idx] = cur

    # ---------- Main traversal ----------
    def rename(self) -> None:
        """
        Execute SSA renaming starting at entry (init) block.

        You MUST pre-seed stacks for globals/params if they’re representable as
        variables.
        """
        self._rename_block(self.entry_idx)

    def _rename_block(self, nodeId: NodeID) -> None:
        node = self.cfg.nodes[nodeId]
        if node is None:
            return

        # Track what we pushed in THIS block so we can pop on exit
        pushed_vars: List[SSAVarID] = []

        # 1) Phi defs at top of block
        pushed_vars.extend(self.define_phi_dsts(nodeId))

        # 2) Rewrite normal instructions within the block
        for instr in node.instrs():
            pushed_vars.extend(self.rewrite_instruction(instr))

        # 3) Fill phi operands in successors
        self.fill_phi_operands_from_block(nodeId)

        # 4) Recurse into dominator tree children
        for child in self.dom_tree.get(nodeId, []):
            self._rename_block(child)

        # 5) Pop versions defined in this block (in reverse push order)
        for v in reversed(pushed_vars):
            self.pop(v)


class CompilationPass:
    def __init__(self, ttsl_compiler: TTSLCompilerContext):
        self.ttsl_compiler: TTSLCompilerContext = ttsl_compiler


class PassSSARenamer(CompilationPass):
    def __init__(self, ttsl_compiler: TTSLCompilerContext):
        super().__init__(ttsl_compiler)

    def run(self) -> None:
        ttsl_compiler = self.ttsl_compiler
        assert isinstance(ttsl_compiler.cfg, CFG)
        cfg = ttsl_compiler.cfg
        # 1) Build dominators/idom/dom-tree (you have it)
        dom = cfg.compute_dominators()
        # console.print("compute_dominators:", dom)
        idom = cfg.compute_immediate_dominators(cfg.init_idx, dom)
        # console.print("idom Tree:", idom)
        dom_tree = cfg.dominator_tree(cfg.init_idx, idom=idom)
        # console.print("Dominator Tree:", dom_tree)
        # dof = cfg.compute_dominance_frontiers(dom,idom)
        dof = cfg.compute_dominance_frontiers(cfg.init_idx, idom, dom)
        # console.print("compute_dominance_frontiers :", dof)

        # 1.b) Insert phi nodes

        ssavars_defs = ttsl_compiler.ssa_var_definitions
        cret = cfg.cytron_insert_phi_nodes(
            ssavars_defs, ttsl_compiler.named_variables, dof
        )
        # print("cytron_insert_phi_nodes :", cret)
        for node_id, phis in cret.items():
            # console.print(f"Node {node_id} phi nodes:")
            cfg.nodes[node_id].phis = phis
            # for var, phi_instr in phis.items():
            #     pass
            #     #console.print(f"  Var {var}: {phi_instr}")

        # 2) Run renaming
        renamer = SSARenamer(cfg, ttsl_compiler, dom_tree, entry_idx=cfg.init_idx)

        # Seed stacks for all variables live at function entry (pixel inputs, globals_dict
        # uniforms, and shader parameters).
        for name in ttsl_compiler.ssa_entry_seed_names:
            existing_temp = ttsl_compiler.named_variables[name]
            renamer.push(name, existing_temp.id)

        renamer.rename()

        # Blocks that never appear in the dominator-tree walk (e.g. `_END_`) can still
        # receive Cytron-inserted phis. Operand TempIDs are filled by fill_phi_operands,
        # but define_phi_dsts never ran, so phi.dst stays an SSAVarID string — fix that.
        for node_id in cfg.all_nodes():
            node = cfg.nodes[node_id]
            if node is None or not node.phis:
                continue
            for var, phi in node.phis.items():
                if phi.op == OpCodes.PHI and isinstance(phi.dst, str):
                    temp = renamer.new_temp(ttsl_compiler.named_variables[var].ty)
                    phi.dst = temp


# post optimization passes


class PassPhiNodeLowering(CompilationPass):
    @dataclass(frozen=True)
    class Copy:
        dst: TempID
        src: TempID

    def run(self) -> None:
        ttsl_compiler = self.ttsl_compiler
        cfg = ttsl_compiler.cfg
        assert isinstance(cfg, CFG)

        # ------------------------------------------------------------------
        # 1) Collect edge copy sets: (pred, block) -> [Copy(dst, src)]
        # ------------------------------------------------------------------
        edge_copies: Dict[Tuple[NodeID, NodeID], List[PassPhiNodeLowering.Copy]] = (
            defaultdict(list)
        )

        for b in cfg.all_nodes():
            block = cfg.nodes[b]
            if block is None:
                continue

            # Scan block instructions; collect phi copies; drop phi from block
            new_instrs: List[IRInstr] = []
            for instr in block.instrs():
                if instr.op == OpCodes.PHI:
                    # dst is the phi result temp
                    phi_dst = instr.dst
                    assert isinstance(phi_dst, Temp), "PHI dst must be Temp"
                    phi_dst_id: TempID = phi_dst.id

                    # operands: pred_node_id -> TempID
                    for pred_id, src_tid in instr.phi_operands.items():
                        assert isinstance(src_tid, int)
                        edge_copies[(pred_id, b)].append(
                            PassPhiNodeLowering.Copy(dst=phi_dst_id, src=src_tid)
                        )
                else:
                    new_instrs.append(instr)

            block.set_instrs(new_instrs)

        # Early exit: no phis
        if not edge_copies:
            return

        # ------------------------------------------------------------------
        # 2) For each edge with copies: split critical edges as needed
        #    and insert copy sequences (parallel-copy resolved).
        # ------------------------------------------------------------------
        for (pred_id, succ_id), copies in list(edge_copies.items()):
            # Skip trivial no-op copies (dst==src)
            copies = [c for c in copies if c.dst != c.src]
            if not copies:
                continue

            pred = cfg.nodes[pred_id]
            succ = cfg.nodes[succ_id]
            if pred is None or succ is None:
                continue

            pred_succs = cfg.successors(pred_id)
            succ_preds = cfg.predecessors(succ_id)

            is_critical = (len(pred_succs) > 1) and (len(succ_preds) > 1)

            if is_critical:
                # Split edge pred->succ into pred->split->succ
                split_id = self._split_edge(cfg, pred_id, succ_id)

                split_block = cfg.nodes[split_id]
                # Insert copies into split block (safe, executes only on that edge)
                self._emit_parallel_copies_into_block(
                    ttsl_compiler, split_block, copies
                )

            else:
                # Non-critical: insert into predecessor before terminator
                self._emit_parallel_copies_before_terminator(
                    ttsl_compiler, pred, copies
                )

    # ----------------------------------------------------------------------
    # Edge splitting
    # ----------------------------------------------------------------------
    def _split_edge(self, cfg: "CFG", pred_id: NodeID, succ_id: NodeID) -> NodeID:
        """
        Create a new block S such that pred->succ becomes pred->S->succ.

        Update:
          - pred terminator target(s)
          - CFG arcs
        """
        split_name = f"_split_{pred_id}_{succ_id}"
        split_node = CFGNode(name=split_name)
        split_id = cfg.add_node(split_node)

        # Split block will just jump to succ (terminator)
        split_node.set_instrs(
            [IRInstr.uniop(op=OpCodes.JMP, dst=cfg.nodes[succ_id].name)]
        )

        # Update predecessor terminator(s): replace succ_id with split_id
        self._replace_edge_in_terminator(
            cfg.nodes[pred_id], old_succ=succ_id, new_succ=split_id
        )

        # Update CFG arcs: remove (pred,succ), add (pred,split), (split,succ)
        cfg.remove_arc_idx(pred_id, succ_id)
        cfg.add_arc_idx(pred_id, split_id)
        cfg.add_arc_idx(split_id, succ_id)

        return split_id

    def _replace_edge_in_terminator(
        self, pred_node: "CFGNode", old_succ: NodeID, new_succ: NodeID
    ) -> None:
        """
        Replace successor target inside pred_node's terminator. You MUST adapt this to
        your exact terminator encoding.

        Common cases:
          - JMP: instr.target
          - JMP_IF_FALSE: instr.target (false) and/or instr.target_true
        """
        term = pred_node.get_terminator()
        if term is None:
            # fallthrough blocks: in your CFG world, these typically have implicit successor;
            # but since you said you use NodeID targets, you likely always have terminators.
            return

        cfg = self.ttsl_compiler.cfg
        assert isinstance(cfg, CFG)

        old_succ_name = cfg.nodes[old_succ].name
        new_succ_name = cfg.nodes[new_succ].name
        if term.op == OpCodes.JMP:
            if term.dst == old_succ_name:
                term.dst = new_succ_name

        elif term.op == OpCodes.JMP_IF_FALSE:
            # Adapt depending on your representation:
            # Example: term.target is the "false" target
            if term.dst == old_succ_name:
                term.dst = new_succ_name
            # # If you also store true-target:
            # if hasattr(term, "target_true") and term.target_true == old_succ_name:
            #     term.target_true = new_succ_name

        else:
            # RET/CRASH shouldn't have successors
            pass

    # ----------------------------------------------------------------------
    # Parallel copy emission
    # ----------------------------------------------------------------------
    def _emit_parallel_copies_before_terminator(
        self,
        ttsl_compiler: "TTSLCompilerContext",
        pred_node: "CFGNode",
        copies: List[Copy],
    ) -> None:
        seq = self._resolve_parallel_copies(ttsl_compiler, copies)
        for move in seq:
            pred_node.insert_before_terminator(move)

    def _emit_parallel_copies_into_block(
        self,
        ttsl_compiler: "TTSLCompilerContext",
        block: "CFGNode",
        copies: List[Copy],
    ) -> None:
        """Insert into block body *before* its terminator (block is a split node with
        JMP succ)."""
        seq = self._resolve_parallel_copies(ttsl_compiler, copies)
        for move in seq:
            block.insert_before_terminator(move)

    def _resolve_parallel_copies(
        self,
        ttsl_compiler: "TTSLCompilerContext",
        copies: List[Copy],
    ) -> List["IRInstr"]:
        """
        Resolve a set of parallel copies into a sequence of STORE (or MOVE)
        instructions. Handles cycles using a scratch temp.

        copies: list of (dst <- src) that must behave as if executed in parallel.
        """
        # Build mutable maps
        pending: Dict[TempID, TempID] = {c.dst: c.src for c in copies if c.dst != c.src}
        if not pending:
            return []

        out: List[IRInstr] = []

        def emit_store(dst: TempID, src: TempID) -> None:
            dst_temp = self.ttsl_compiler.find_temp_by_id(dst)
            src_temp = self.ttsl_compiler.find_temp_by_id(src)
            out.append(IRInstr.uniop(op=OpCodes.STORE, dst=dst_temp, src=src_temp))

        while pending:
            # Find an acyclic move: src not currently a dst of any pending move
            progress = False
            for dst, src in list(pending.items()):
                if src not in pending.keys():
                    emit_store(dst, src)
                    del pending[dst]
                    progress = True
            if progress:
                continue

            # Cycle exists. Break it using a scratch temp:
            # Choose any dst in the cycle.
            cycle_dst = next(iter(pending.keys()))
            cycle_src = pending[cycle_dst]

            # Allocate scratch of the right type.
            # You need a way to get temp type; adapt to your compiler.
            dst_ty = ttsl_compiler.get_tempid_type(cycle_dst)
            scratch = ttsl_compiler.alloc_temp_for_type(dst_ty)

            # scratch = cycle_src
            emit_store(scratch.id, cycle_src)

            # Now replace all occurrences of cycle_src in pending sources with scratch
            for d in list(pending.keys()):
                if pending[d] == cycle_src:
                    pending[d] = scratch.id

            # Now cycle_dst <- scratch is acyclic and will be emitted in the next loop iteration

        return out


class CFGSimplifyPass(CompilationPass):
    def run(self) -> None:
        ttsl_compiler = self.ttsl_compiler
        _cfg = ttsl_compiler.cfg


RegisterAddress = Tuple[IRType, int]  # (type, register_id)


@dataclass
class RegisterAllocationResult:
    var_names_to_registers: Dict[str, RegisterAddress]
    tempids_to_registers: Dict[TempID, RegisterAddress]
    # Keyed by (const_id, dst_temp_id) so that every distinct ``LOAD_CONST`` Temp's
    # allocated register is recorded — not just the last temp keyed by ``const_id``.
    # The front-end may emit multiple ``LOAD_CONST`` for the same constant pool index,
    # each with its own ``dst`` Temp; the register allocator gives each Temp a distinct
    # physical register, and **all** of them must be seeded with the constant value
    # (``LOAD_CONST`` is dropped during bytecode emission, so any unseeded register
    # would read as ``0`` at runtime).
    const_id_to_registers: Dict[Tuple[int, TempID], Tuple[RegisterAddress, Any]]


class RegisterAllocatorPass(CompilationPass):
    def run(self) -> RegisterAllocationResult:
        ttsl_compiler = self.ttsl_compiler
        cfg = ttsl_compiler.cfg
        assert isinstance(cfg, CFG)

        # count of registers per type (must stay within VM banks: [T; 256], indices 0..255;
        # allocator uses 1..=count; reg 0 reserved for default_vars_to_registers bindings)
        register_counts: dict[IRType, int] = {
            IRType.BOOL: 255,
            IRType.I32: 255,
            IRType.F32: 255,
            IRType.V2: 255,
            IRType.V3: 255,
            IRType.V4: 255,
        }
        allocated_registers: Dict[IRType, Set[int]] = {}

        # ``ShaderInputBinding`` defaults in ``shader_material.rs`` write PixInfo UVs into
        # ``regs.v3[0]`` and ``regs.v3[1]`` before ``run_ttsl``. Reserve those indices so
        # shader temps (e.g. ``vec3`` locals / ``OP_RET`` payloads) never alias them.
        allocated_registers[IRType.V3] = {0, 1}
        # Mirror ``ShaderInputBinding::default()`` in ``shader_material.rs``: per-pixel
        # ``tt_PrimitiveID`` is pinned (below) to ``regs.i32_[0]`` so the Rust side can write
        # ``PixInfo::primitive_id`` into a fixed slot. The remaining shadow PixInfo i32 IDs
        # (``material_id`` / ``node_id`` / ``geometry_id``) are not yet TTSL-named and live in
        # ``regs.i32_[1]`` / ``[2]`` / ``[3]``. Reserve those slots so user temps / globals never
        # alias them. ``tt_PrimitiveID``'s slot (``0``) is reserved explicitly when the variable
        # is encountered in ``named_variables`` below (see ``PIXELVAR_TT_PRIMITIVE_ID`` branch).
        allocated_registers[IRType.I32] = {1, 2, 3}

        def next_free_register(ty: IRType) -> int:
            used = allocated_registers.setdefault(ty, set())
            for reg_id in range(1, register_counts[ty] + 1):
                if reg_id not in used:
                    used.add(reg_id)
                    return reg_id
            raise RuntimeError(f"No free registers available for type {ty}")

        # allocate registers for all variables first
        named_variables = ttsl_compiler.named_variables
        assert isinstance(named_variables, Dict)

        var_names_to_registers: Dict[str, RegisterAddress] = {}
        tempids_to_registers: Dict[TempID, RegisterAddress] = {}

        for var_name, temp in named_variables.items():
            assert isinstance(temp, Temp)
            assert isinstance(temp.ty, IRType)
            assert isinstance(var_name, str)

            if var_name == PIXELVAR_TT_PRIMITIVE_ID:
                # Pin to ``regs.i32_[0]`` so ``ShaderInputBinding::primitive_id_i32_reg`` (default
                # ``0``) and ``ShaderMaterial::render_mat`` write ``PixInfo::primitive_id`` into the
                # exact register the bytecode reads from.
                assert temp.ty == IRType.I32, (
                    "tt_PrimitiveID must be IRType.I32 (declared in PIXEL_VARIABLES_STR_TYPE)"
                )
                idx = 0
                allocated_registers.setdefault(IRType.I32, set()).add(0)
            else:
                idx = next_free_register(temp.ty)
            var_names_to_registers[var_name] = (temp.ty, idx)
            tempids_to_registers[temp.id] = (temp.ty, idx)

        # Then allocate registers for constants (because OpCode can't carry the constant value)
        const_pool = ttsl_compiler.const_pool
        assert const_pool is not None
        const_id_to_registers: Dict[
            Tuple[int, TempID], Tuple[RegisterAddress, Any]
        ] = {}

        # Seek LOAD_CONST instructions and map their dst temps to the allocated registers.
        # The same ``const_id`` may appear in multiple LOAD_CONST instructions (each with
        # its own ``dst`` Temp); every distinct (const_id, dst_temp_id) pair must be
        # recorded so the seeding loop downstream writes the literal value into **every**
        # register that bytecode operands later reference. Keying by ``const_id`` alone
        # would lose all but the last ``dst`` register, leaving the others at ``0`` at
        # runtime (since LOAD_CONST is dropped during bytecode emission).
        for node_id, node in cfg.node_items():
            for instr in node.instrs():
                assert instr.byte_code is not None
                assert len(instr.byte_code) == 6

                if instr.op == OpCodes.LOAD_CONST:
                    const_id = instr.imm
                    assert isinstance(const_id, int)
                    constant_dst_temp = instr.dst
                    assert isinstance(constant_dst_temp, Temp)
                    assert const_id in const_pool

                    (pyvalue, const_ty) = const_pool[const_id]
                    const_temp_id = constant_dst_temp.id
                    const_temp_ty = constant_dst_temp.ty

                    assert (
                        const_temp_ty == const_ty
                    )  # type matches between temp and pool

                    if const_temp_id not in tempids_to_registers:
                        next_reg_id = next_free_register(constant_dst_temp.ty)
                        tempids_to_registers[const_temp_id] = (
                            constant_dst_temp.ty,
                            next_reg_id,
                        )

                    const_id_to_registers[(const_id, const_temp_id)] = (
                        tempids_to_registers[const_temp_id],
                        pyvalue,
                    )

        # Then simple register allocation: map each Temp to a unique register ID
        for node_id, node in cfg.node_items():
            for instr in node.instrs():
                if instr.op in (OpCodes.LABEL, OpCodes.COMMENT):
                    continue
                # Allocate registers for src operands
                for src in [instr.src1, instr.src2, instr.src3, instr.src4]:
                    if src is None:
                        continue
                    elif isinstance(src, Temp):
                        if src.id not in tempids_to_registers:
                            next_reg_id = next_free_register(src.ty)
                            tempids_to_registers[src.id] = (src.ty, next_reg_id)
                    else:
                        raise RuntimeError(
                            f"Unexpected source operand type for register allocation: {src}"
                        )

                if instr.op not in (OpCodes.JMP, OpCodes.JMP_IF_FALSE):
                    # Allocate register for dst operand
                    dst = instr.dst
                    if instr.op in (OpCodes.RET,):
                        continue  # no dst operand
                    elif isinstance(dst, Temp):
                        if dst.id not in tempids_to_registers:
                            next_reg_id = next_free_register(dst.ty)
                            tempids_to_registers[dst.id] = (dst.ty, next_reg_id)
                    else:
                        raise RuntimeError(
                            f"Unexpected dst operand type for register allocation: {dst}"
                        )

        return RegisterAllocationResult(
            var_names_to_registers=var_names_to_registers,
            tempids_to_registers=tempids_to_registers,
            const_id_to_registers=const_id_to_registers,
        )


class PassNormalizeTerminators(CompilationPass):
    def run(self) -> None:
        cfg = self.ttsl_compiler.cfg
        assert isinstance(cfg, CFG)
        cfg.remove_node(cfg.end_idx)  #
        for b in cfg.all_nodes():
            node = cfg.nodes[b]
            if node is None:
                continue

            term = node.get_terminator()
            if term is not None:
                continue

            succs = [s for s in cfg.successors(b) if cfg.nodes[s] is not None]
            if len(succs) != 1:
                raise ValueError(
                    f"Block {b} has no terminator but has {len(succs)} successors; "
                    f"cannot normalize."
                )

            node.append_instruction(
                IRInstr.uniop(op=OpCodes.JMP, dst=cfg.nodes[succs[0]].name)
            )


def build_layout_with_fallthrough(cfg: CFG, rpo: List[int]) -> List[int]:
    """
    Build a layout that respects *required* fallthrough.

    Two kinds of blocks impose a required next-in-bytecode successor:

    1. Blocks with no terminator at all (single successor): the bytecode literally
       falls into the next instruction, so that successor must be physically next.
    2. Blocks ending in ``JMP_IF_FALSE``: the false branch is encoded as a target
       address, but the **true** branch is the implicit fall-through (``pc + 1``),
       so the true (non-jump-target) successor must be physically next as well.
       Without this, a cascade of ``if cond: return ...`` (no ``else``) can place
       the false-target block right after the conditional and silently drop the
       true branches at the end of the layout — every conditional then flows down
       to the final return regardless of the condition (regression covered by
       ``test_depth_fog_glyph_shader_vm_vs_python_reference``).

    Other blocks fall back to a greedy heuristic that prefers placing JMP targets
    or any unplaced successor next.
    """
    rpo_set = set(rpo)
    placed: Set[int] = set()
    layout: List[int] = []

    # --- 1) Compute required fallthrough edges: b -> ft[b] ---
    fallthrough: Dict[int, int] = {}

    for b in rpo:
        node = cfg.nodes[b]
        if node is None:
            continue
        term = node.get_terminator()
        if term is None:
            succs = [s for s in cfg.successors(b) if cfg.nodes[s] is not None]
            if len(succs) != 1:
                if b == cfg.end_idx:
                    # allow end block to have no terminator and no successors
                    continue
                raise ValueError(
                    f"Block {b} has no terminator but has {len(succs)} successors; "
                    f"cannot model fallthrough unambiguously."
                )
            fallthrough[b] = succs[0]
        elif term.op == OpCodes.JMP_IF_FALSE:
            # The false branch is an explicit address (`term.dst` label, encoded by
            # `PassToByteCode`); the true branch is the implicit `pc + 1` fall-through,
            # so the non-jump-target successor MUST be the next block in the layout.
            assert isinstance(term.dst, str)
            false_target_name = term.dst
            succs = [s for s in cfg.successors(b) if cfg.nodes[s] is not None]
            ft_succs = [s for s in succs if cfg.nodes[s].name != false_target_name]
            if len(ft_succs) != 1:
                raise ValueError(
                    f"Block {b} (`{node.name}`) ends in JMP_IF_FALSE to "
                    f"`{false_target_name}` but has {len(ft_succs)} fall-through "
                    f"successors {[cfg.nodes[s].name for s in ft_succs]}; "
                    f"layout cannot place the true branch unambiguously."
                )
            fallthrough[b] = ft_succs[0]

    # --- 2) Utility: follow required fallthrough chain ---
    def place_fallthrough_chain(start: int) -> None:
        cur = start
        while (
            cur is not None
            and cur in rpo_set
            and cur not in placed
            and cfg.nodes[cur] is not None
        ):
            placed.add(cur)
            layout.append(cur)

            nxt = fallthrough.get(cur)
            if nxt is None:
                break

            # if already placed, this is a layout conflict -> must introduce a JMP later or split.
            if nxt in placed:
                # We *could* allow this and later force a JMP at end of cur,
                # but if cur has no terminator, you said you'd be doomed.
                raise ValueError(
                    f"Required fallthrough from {cur} to {nxt} cannot be satisfied because {nxt} is already placed."
                )

            cur = nxt

    # --- 3) Preferred successor for non-required cases (simple heuristic) ---
    def pick_preferred_successor(b: int) -> Optional[int]:
        node = cfg.nodes[b]
        if node is None:
            return None
        term = node.get_terminator()
        if term is None:
            # required fallthrough handled by chain
            return None

        # Unconditional JMP: prefer its target
        if term.op == OpCodes.JMP:
            assert isinstance(term.dst, str)
            t = cfg._node_name_to_id[term.dst]

            if t in rpo_set and t not in placed and cfg.nodes[t] is not None:
                return t

        # Conditional: prefer any unplaced successor (heuristic)
        for s in cfg.successors(b):
            if s in rpo_set and s not in placed and cfg.nodes[s] is not None:
                return s

        return None

    def place_greedy_chain(start: int) -> None:
        cur = start
        while (
            cur is not None
            and cur in rpo_set
            and cur not in placed
            and cfg.nodes[cur] is not None
        ):
            # If cur has required fallthrough, place the entire required chain from cur
            if cur in fallthrough:
                place_fallthrough_chain(cur)
                return

            placed.add(cur)
            layout.append(cur)

            cur = pick_preferred_successor(cur)

    # --- 4) Build layout: ensure required fallthrough chains always placed intact ---
    for b in rpo:
        if b in placed or cfg.nodes[b] is None:
            continue
        # If b is in the middle of someone else's required chain, it will be placed when its head is placed.
        # We still allow starting at b; chain logic will enforce correctness.
        place_greedy_chain(b)

    return layout


class PassToByteCode(CompilationPass):
    def run(self, rar: RegisterAllocationResult) -> List[List[int]]:
        self.all_ops = [f for cat in generate_all_forms() for f in cat.forms]

        ttsl_compiler = self.ttsl_compiler
        cfg = ttsl_compiler.cfg
        assert isinstance(cfg, CFG)
        # order the nodes in a way that respects control flow
        rpo: List[NodeID] = cfg.reverse_post_order()
        layout: List[NodeID] = build_layout_with_fallthrough(cfg, rpo)
        # all_nodes = cfg.bfs(cfg.init_idx)

        self.blocks_name_to_address: Dict[str, int] = {}

        # clean up instructions per block
        for node_id in layout:
            node = cfg.nodes[node_id]
            rewrittend_instructions: List[IRInstr] = []
            for instr in node.instrs(include_phis=False):
                if instr.op == OpCodes.PHI:
                    raise Exception(
                        "PHI nodes should have been lowered before bytecode emission"
                    )
                elif instr.op == OpCodes.LABEL:
                    # Labels are not emitted in bytecode
                    continue
                elif instr.op == OpCodes.COMMENT:
                    # Comments are not emitted in bytecode
                    continue
                elif instr.op == OpCodes.LOAD_CONST:
                    # not emitted as LOAD_CONST; replaced by STORE to allocated register
                    continue
                else:
                    self.transform_instr_to_bytecode(instr, rar)
                    rewrittend_instructions.append(instr)
            node.set_instrs(rewrittend_instructions)
        # now assign addresses to blocks
        current_address = 0
        for node_id in layout:
            node = cfg.nodes[node_id]
            instrs = node.instrs(include_phis=False)
            self.blocks_name_to_address[node.name] = current_address
            current_address += len(instrs)

        # now patch jump targets in the bytecode
        for node_id in layout:
            node = cfg.nodes[node_id]
            for instr in node.instrs(include_phis=False):
                assert instr.byte_code is not None
                if instr.op == OpCodes.JMP:
                    target_block_name = instr.dst
                    assert isinstance(target_block_name, str)
                    target_address = self.blocks_name_to_address[target_block_name]

                    instr.byte_code[1] = target_address
                elif instr.op == OpCodes.JMP_IF_FALSE:
                    target_block_name = instr.dst
                    assert isinstance(target_block_name, str)
                    target_address = self.blocks_name_to_address[target_block_name]
                    instr.byte_code[1] = target_address

        # now extract final bytecode
        final_bytecode: List[List[int]] = []
        for node_id in layout:
            node = cfg.nodes[node_id]

            for instr in node.instrs(include_phis=False):
                assert instr.byte_code is not None
                final_bytecode.append(instr.byte_code)
        return final_bytecode

    def find_form(self, instr: IRInstr) -> Form:
        instr.src1
        instr.src2
        instr.src3
        instr.src4
        for form in self.all_ops:
            form["type"]  # output_type
            op_name = form["name"]  # opcode name

            form.opcode_index
            form.output_type
            input_types = [
                it for it in form["input_types"] if it is not None
            ]  # input types
            # form.opcode_index
            if instr.op == OpCodes.JMP and op_name == "OP_JMP":
                return form
            elif instr.op == OpCodes.JMP_IF_FALSE and op_name == "OP_JMP_IF_FALSE":
                return form
            elif instr.op == OpCodes.RET and op_name == "OP_RET":
                for label, op, expect in (
                    ("src1", instr.src1, IRType.V3),
                    ("src2", instr.src2, IRType.V3),
                    ("src3", instr.src3, IRType.I32),
                ):
                    if not isinstance(op, Temp) or op.ty != expect:
                        raise ValueError(
                            f"OP_RET expects {label} temp of type {expect}, got {op!r}"
                        )
                return form
            elif instr.op.name in op_name:
                # check types now
                instr_types = []
                if instr.dst is not None:
                    instr_types.append(instr.dst.ty)
                if instr.src1 is not None:
                    instr_types.append(instr.src1.ty)
                if instr.src2 is not None:
                    instr_types.append(instr.src2.ty)
                if instr.src3 is not None:
                    instr_types.append(instr.src3.ty)
                if instr.src4 is not None:
                    instr_types.append(instr.src4.ty)

                target_typing = tuple([form["type"]] + input_types)
                if tuple(instr_types) == target_typing:
                    return form

        raise ValueError(f"No matching form found for instruction: {instr}")

    def transform_instr_to_bytecode(
        self, instr: IRInstr, rar: RegisterAllocationResult
    ) -> None:
        if instr.op in (OpCodes.LABEL, OpCodes.PHI, OpCodes.COMMENT):
            return  # No bytecode for these

        form = self.find_form(instr)

        srcs = [instr.src1, instr.src2, instr.src3, instr.src4]
        dst = instr.dst

        # Convert operands to their integer representations
        src_ids: List[int] = []
        for src in srcs:
            if src is None:
                src_ids.append(0)
            elif isinstance(src, Temp):
                # find the register id for the temp
                op_ty, op_reg = rar.tempids_to_registers[src.id]  # get register id
                src_ids.append(op_reg)
            else:
                raise ValueError(f"Unsupported source operand type: {src}")
        assert len(src_ids) == 4

        #
        dst_id: Optional[int] = None
        if dst is None:
            dst_id = 0
        elif isinstance(dst, Temp):
            op_ty, op_reg = rar.tempids_to_registers[dst.id]  # get register id
            dst_id = op_reg
        elif instr.op in (OpCodes.JMP, OpCodes.JMP_IF_FALSE):
            dst_id = 0  # placeholder, will be patched later
        else:
            raise ValueError(f"Unsupported dst operand type: {dst}")

        assert isinstance(dst_id, int)
        assert isinstance(form.opcode_index, int)
        bytecode = [form.opcode_index, dst_id] + src_ids
        instr.byte_code = bytecode


class RegisterSettings:
    @classmethod
    def default_vars_to_registers(cls) -> Dict[str, RegisterAddress]:
        d = {}
        taken_registers: Dict[str, Set[int]] = {}
        for k, v in TTSLCompilerContext.always_present_variables().items():
            if k in taken_registers:
                used_regs = taken_registers[k]
                reg_id = 1
                while reg_id in used_regs:
                    reg_id += 1
                taken_registers[k].add(reg_id)
                d[k] = (v, reg_id)
            else:
                taken_registers[k] = {0}
                d[k] = (v, 0)  # default to register 0 for each variable
        return d

    def __init__(self, vars_to_registers: Dict[str, RegisterAddress]):
        self.regs: Dict[IRType, Dict[int, Any]] = {ty: {} for ty in IRType}
        self.var_name_to_registers: Dict[str, RegisterAddress] = vars_to_registers

    def set_register(self, ty: IRType, reg_id: int, value: Any):
        self.regs[ty][reg_id] = value

    def set_variable(self, name: str, value: Any):
        if name not in self.var_name_to_registers:
            raise ValueError(f"Variable {name} not found in register allocation.")
        ty, reg_id = self.var_name_to_registers[name]
        self.set_register(ty, reg_id, value)

    def get_register_list(self):
        reg_types = [
            IRType.BOOL,
            IRType.F32,
            IRType.I32,
            IRType.V2,
            IRType.V3,
            IRType.V4,
        ]
        regs = []
        for ty in reg_types:
            regs.append(self.regs[ty])
        return regs

    def fork(self) -> "RegisterSettings":
        """Copy allocation maps so per-material ``set_variable`` calls do not alias state.

        Used when one compiled bytecode is shared across multiple ``ShaderPy`` instances
        with different register seeds (for example per-instance ``u_albedo``).
        """
        out = RegisterSettings(dict(self.var_name_to_registers))
        for ty in IRType:
            out.regs[ty] = dict(self.regs[ty])
        return out


def shader_py_frag_depth_clip_kwargs(reg_settings: RegisterSettings) -> Dict[str, int]:
    """Keyword arguments for ``ShaderPy`` when the shader uses ``tt_FragDepth``, ``tt_Near``, and ``tt_Far``.

    Call after ``all_passes_compilation`` with a ``globals_dict`` that includes
    ``GLOBAL_VAR_TT_NEAR`` and ``GLOBAL_VAR_TT_FAR`` so clip uniforms are allocated.

    Returns:
        ``frag_depth_f32_reg``, ``near_f32_reg``, and ``far_f32_reg`` register indices.

    Raises:
        ValueError: if ``tt_FragDepth``, ``tt_Near``, or ``tt_Far`` are missing from the allocation.
    """
    bindings: List[Tuple[str, str]] = [
        (PIXELVAR_TT_FRAG_DEPTH, "frag_depth_f32_reg"),
        (GLOBAL_VAR_TT_NEAR, "near_f32_reg"),
        (GLOBAL_VAR_TT_FAR, "far_f32_reg"),
    ]
    missing = [name for name, _ in bindings if name not in reg_settings.var_name_to_registers]
    if missing:
        raise ValueError(
            "Register allocation is missing depth/clip bindings for shader_py_frag_depth_clip_kwargs: "
            + ", ".join(missing)
        )
    out: Dict[str, int] = {}
    for var_name, kw in bindings:
        _ty, reg_id = reg_settings.var_name_to_registers[var_name]
        out[kw] = reg_id
    return out


def apply_engine_uniform_register_defaults(reg_settings: RegisterSettings) -> None:
    """Seed registers for globals / always-present builtins that have a documented default.

    ``tt_Frame`` defaults to ``0`` until the host writes a frame counter. ``tt_Resolution``
    defaults to ``(1, 1)`` cells when the host has not written a size yet; components ``<= 0``
    are treated as invalid by the Rust setter and replaced with ``1``.

    ``tt_Near`` / ``tt_Far`` default to ``0.1`` and ``100.0`` (documented placeholder clip
    distances) until ``MaterialBufferPy.set_shader_near`` / ``set_shader_far`` overwrites them;
    hosts should set values consistent with the active projection and ``tt_FragDepth`` encoding.

    ``tt_FrontFacing`` defaults to ``True``, matching ``PixInfo`` initialization and non-triangle
    raster paths (2D / point sampling). ``ShaderMaterial`` overwrites the bound bool register
    each pixel from ``PixInfo::front_facing`` when ``ShaderPy.front_facing_bool_reg`` is set.

    ``tt_PrimitiveID`` defaults to ``0`` so VM-only harnesses (no ``ShaderMaterial`` per-pixel
    write) see the same value ``PixInfo::primitive_id`` initializes to; ``ShaderMaterial``
    overwrites it each pixel from ``PixInfo::primitive_id``.

        ``tt_FragDepth`` defaults to ``0.0`` for standalone VM runs; ``ShaderMaterial`` writes
    the bound ``f32`` register each pixel from the active depth layer when
    ``ShaderPy.frag_depth_f32_reg`` is set.

    ``tt_LineCoord`` defaults to ``0.0`` (non-line primitives and standalone VM runs);
    ``ShaderMaterial`` writes ``PixInfo::line_coord`` when ``ShaderPy.line_coord_f32_reg`` is set
    (line rasterization supplies ``0.0``..``1.0`` along the segment).

    ``tt_PointCoord`` defaults to ``(0, 0)`` (non-point primitives and standalone VM runs);
    ``ShaderMaterial`` writes ``PixInfo::point_coord`` when ``ShaderPy.point_coord_v2_reg`` is set
    (point rasterization supplies ``(0.5, 0.5)`` for the single-cell sprite path).
    """
    names = reg_settings.var_name_to_registers
    if GLOBAL_VAR_TT_FRAME in names:
        reg_settings.set_variable(GLOBAL_VAR_TT_FRAME, 0)
    if GLOBAL_VAR_TT_RESOLUTION in names:
        reg_settings.set_variable(GLOBAL_VAR_TT_RESOLUTION, glm.vec2(1.0, 1.0))
    if PIXELVAR_TT_FRONT_FACING in names:
        reg_settings.set_variable(PIXELVAR_TT_FRONT_FACING, True)
    if PIXELVAR_TT_FRAG_DEPTH in names:
        reg_settings.set_variable(PIXELVAR_TT_FRAG_DEPTH, 0.0)
    if PIXELVAR_TT_LINE_COORD in names:
        reg_settings.set_variable(PIXELVAR_TT_LINE_COORD, 0.0)
    if PIXELVAR_TT_POINT_COORD in names:
        reg_settings.set_variable(PIXELVAR_TT_POINT_COORD, glm.vec2(0.0, 0.0))
    if PIXELVAR_TT_PRIMITIVE_ID in names:
        reg_settings.set_variable(PIXELVAR_TT_PRIMITIVE_ID, 0)
    if GLOBAL_VAR_TT_NEAR in names:
        # Documented default clip distances (see `source/ttsl.md`); host should overwrite
        # from the active projection. Matches the common 0.1 / 100 hyperbolic depth scale
        # used in depth-fog demos before these uniforms shipped.
        reg_settings.set_variable(GLOBAL_VAR_TT_NEAR, 0.1)
    if GLOBAL_VAR_TT_FAR in names:
        reg_settings.set_variable(GLOBAL_VAR_TT_FAR, 100.0)


@dataclass
class CompilationStateResult:
    ast_module: Optional[ast.Module] = None
    ast_function: Optional[ast.FunctionDef] = None
    context: Optional[TTSLCompilerContext] = None
    last_completed_stage: str = "start"
    register_allocation: Optional[RegisterAllocationResult] = None
    final_byte_code: Optional[List[List[int]]] = None
    byte_array: Optional[bytes] = None
    register_settings: Optional[RegisterSettings] = None
    error: Optional[Exception] = None
    traceback_text: str = ""

    @property
    def ok(self) -> bool:
        return self.error is None


def all_passes_compilation_with_state(
    src: str, func_name: str, globals_dict: Dict[str, Any]
) -> CompilationStateResult:
    result = CompilationStateResult()
    try:
        ast_module, fn_node = parse_ttsl_source(src, func_name)
        result.ast_module = ast_module
        result.ast_function = fn_node
        result.last_completed_stage = "parse"
    except Exception as exc:
        result.error = exc
        result.traceback_text = traceback.format_exc()
        return result

    try:
        cc = compile_ttsl_function(fn_node, globals_dict)
        result.context = cc
        result.last_completed_stage = "ir"
    except Exception as exc:
        result.error = exc
        result.traceback_text = traceback.format_exc()
        return result

    assert result.context is not None
    cc = result.context
    stages = [
        ("cfg", lambda: build_cfg_from_ir(cc)),
        ("ssa", lambda: PassSSARenamer(cc).run()),
        ("phi_lower", lambda: PassPhiNodeLowering(cc).run()),
        ("cfg_simplify", lambda: CFGSimplifyPass(cc).run()),
    ]

    for stage_name, stage_fn in stages:
        try:
            stage_fn()
            result.last_completed_stage = stage_name
        except Exception as exc:
            result.error = exc
            result.traceback_text = traceback.format_exc()
            return result

    try:
        rar = RegisterAllocatorPass(cc).run()
        result.register_allocation = rar
        result.last_completed_stage = "reg_alloc"
    except Exception as exc:
        result.error = exc
        result.traceback_text = traceback.format_exc()
        return result

    try:
        PassNormalizeTerminators(cc).run()
        result.last_completed_stage = "normalize_terms"
    except Exception as exc:
        result.error = exc
        result.traceback_text = traceback.format_exc()
        return result

    assert result.register_allocation is not None
    try:
        final_byte_code = PassToByteCode(cc).run(result.register_allocation)
        result.final_byte_code = final_byte_code

        reg_settings = RegisterSettings(result.register_allocation.var_names_to_registers)
        for (ty, reg_id), value in result.register_allocation.const_id_to_registers.values():
            reg_settings.set_register(ty, reg_id, value)
        apply_engine_uniform_register_defaults(reg_settings)
        result.register_settings = reg_settings

        all_bytecode_instrs = []
        for bytecode_instr in final_byte_code:
            all_bytecode_instrs.extend(bytecode_instr)
        result.byte_array = bytes(all_bytecode_instrs)
        result.last_completed_stage = "bytecode"
    except Exception as exc:
        result.error = exc
        result.traceback_text = traceback.format_exc()
        return result

    return result


def all_passes_compilation(
    src: str, func_name: str, globals_dict: Dict[str, Any]
) -> Tuple[bytes, RegisterSettings]:
    cc = compile_ttsl(src, func_name, globals_dict)
    build_cfg_from_ir(cc)
    PassSSARenamer(cc).run()

    PassPhiNodeLowering(cc).run()
    CFGSimplifyPass(cc).run()
    rar = RegisterAllocatorPass(cc).run()

    PassNormalizeTerminators(cc).run()
    final_byte_code = PassToByteCode(cc).run(rar)

    reg_settings = RegisterSettings(rar.var_names_to_registers)
    for (ty, reg_id), value in rar.const_id_to_registers.values():
        reg_settings.set_register(ty, reg_id, value)
    apply_engine_uniform_register_defaults(reg_settings)

    all_bytecode_instrs = []
    for bytecode_instr in final_byte_code:
        all_bytecode_instrs.extend(bytecode_instr)
    # convert the bytecode to a bytes array
    byte_array = bytes(all_bytecode_instrs)
    return byte_array, reg_settings
