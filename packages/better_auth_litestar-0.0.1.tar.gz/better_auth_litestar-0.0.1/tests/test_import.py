import better_auth.litestar


def test_import():
    assert better_auth.litestar.__name__ == "better_auth.litestar"
