from __future__ import annotations

import unittest

from comate_cli.terminal_agent.tool_view import ToolEventView, should_show_tool_in_scrollback


class TestToolEventView(unittest.TestCase):
    def test_render_result_mutates_same_text_reference(self) -> None:
        view = ToolEventView(fancy_progress_effect=False)
        text_ref = view.render_call(
            "Read",
            {"path": "/tmp/demo.py", "offset_line": 1, "limit_lines": 50},
            "tc_read_1",
        )

        self.assertIn("→ Read", text_ref.plain)
        self.assertIn("path=/tmp/demo.py", text_ref.plain)

        view.render_result(
            tool_name="Read",
            tool_call_id="tc_read_1",
            result="ok",
            is_error=False,
        )
        self.assertIn("✓ Read", text_ref.plain)
        self.assertIn("path=/tmp/demo.py", text_ref.plain)

    def test_interrupt_running_marks_text_ref_as_interrupted(self) -> None:
        view = ToolEventView(fancy_progress_effect=False)
        text_ref = view.render_call(
            "Bash",
            {"command": "npm test"},
            "tc_bash_1",
        )

        view.interrupt_running()
        self.assertIn("已中断", text_ref.plain)
        self.assertIn("⏹ Bash", text_ref.plain)

    def test_has_running_tasks_only_counts_task_tool(self) -> None:
        view = ToolEventView(fancy_progress_effect=False)
        view.render_call("Read", {"path": "/tmp/a.py"}, "tc_read_2")
        self.assertFalse(view.has_running_tasks())

        task_ref = view.render_call(
            "Task",
            {"subagent_type": "Planner", "description": "拆解任务"},
            "tc_task_1",
        )
        self.assertTrue(view.has_running_tasks())

        view.render_result(
            tool_name="Agent",
            tool_call_id="tc_task_1",
            result="done",
            is_error=False,
        )
        self.assertFalse(view.has_running_tasks())
        self.assertIn("✓ Planner(拆解任务) · 完成", task_ref.plain)


class TestShouldShowToolInScrollback(unittest.TestCase):
    # --- TaskCreate: hidden except error ---
    def test_taskcreate_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskCreate", {"subject": "do X"}))

    def test_taskcreate_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskCreate", {"subject": "do X"}, is_result=True))

    def test_taskcreate_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskCreate", {}, is_result=True, is_error=True))

    # --- TaskUpdate: hidden except error ---
    def test_taskupdate_completed_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "completed"}))

    def test_taskupdate_completed_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "completed"}, is_result=True))

    def test_taskupdate_completed_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "completed"}, is_result=True, is_error=True))

    def test_taskupdate_in_progress_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "in_progress"}))

    def test_taskupdate_in_progress_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "in_progress"}, is_result=True))

    def test_taskupdate_in_progress_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskUpdate", {"taskId": "1", "status": "in_progress"}, is_result=True, is_error=True))

    def test_taskupdate_empty_args_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskUpdate", {}))

    def test_taskupdate_empty_args_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskUpdate", {}, is_result=True, is_error=True))

    # --- TaskList: hidden except error ---
    def test_tasklist_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskList", {}))

    def test_tasklist_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskList", {}, is_result=True))

    def test_tasklist_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskList", {}, is_result=True, is_error=True))

    # --- TaskGet: hidden except error ---
    def test_taskget_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("TaskGet", {}))

    def test_taskget_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("TaskGet", {}, is_result=True, is_error=True))

    # --- AskUserQuestion: hidden except error ---
    def test_askuserquestion_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("AskUserQuestion", {}))

    def test_askuserquestion_result_success_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("AskUserQuestion", {}, is_result=True))

    def test_askuserquestion_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("AskUserQuestion", {}, is_result=True, is_error=True))

    # --- ExitPlanMode: hidden except error ---
    def test_exitplanmode_toolcall_hidden(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("ExitPlanMode", {}))

    def test_exitplanmode_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("ExitPlanMode", {}, is_result=True, is_error=True))

    # --- Normal tools: always show ---
    def test_read_always_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("Read", {"file_path": "/tmp/a.py"}))

    def test_edit_result_error_shown(self) -> None:
        self.assertTrue(should_show_tool_in_scrollback("Edit", {}, is_result=True, is_error=True))

    # --- Case insensitivity ---
    def test_case_insensitive(self) -> None:
        self.assertFalse(should_show_tool_in_scrollback("tasklist", {}))
        self.assertFalse(should_show_tool_in_scrollback("TASKCREATE", {"subject": "x"}))


if __name__ == "__main__":
    unittest.main(verbosity=2)
