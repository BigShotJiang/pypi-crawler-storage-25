from __future__ import annotations

import unittest

from rich.console import Console
from rich.text import Text

from comate_cli.terminal_agent.history_printer import render_history_group
from comate_cli.terminal_agent.models import HistoryEntry


def _identity_md(text: str, **kwargs) -> str:
    return text


class TestSubtitleRendering(unittest.TestCase):
    """Verify that subtitle lines are rendered for tool_result entries."""

    def _render_to_str(self, entries: list[HistoryEntry]) -> str:
        console = Console(file=None, force_terminal=True, width=120)
        group = render_history_group(
            console, entries, terminal_width=120, render_markdown_to_plain=_identity_md,
        )
        if group is None:
            return ""
        with console.capture() as capture:
            console.print(group)
        return capture.get()

    def test_tool_result_with_subtitle_renders_hook_line(self) -> None:
        entry = HistoryEntry(
            entry_type="tool_result", text="Read(path=test.py)", subtitle="Read 10 lines"
        )
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Read 10 lines", output)

    def test_tool_result_without_subtitle_no_hook_line(self) -> None:
        entry = HistoryEntry(entry_type="tool_result", text="Agent(task)")
        output = self._render_to_str([entry])
        self.assertNotIn("⎿", output)

    def test_rich_text_tool_result_with_subtitle(self) -> None:
        text_obj = Text("Update(test.py)")
        text_obj.append("\n")
        text_obj.append("+added line", style="green")
        entry = HistoryEntry(
            entry_type="tool_result", text=text_obj, subtitle="Added 1 line, removed 0 lines"
        )
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Added 1 line, removed 0 lines", output)
        self.assertLess(output.index("Update(test.py)"), output.index("⎿"))
        self.assertLess(output.index("⎿"), output.index("+added line"))

    def test_error_tool_result_with_subtitle(self) -> None:
        entry = HistoryEntry(
            entry_type="tool_result", text="Read(path=bad.py)",
            severity="error", subtitle="File not found",
        )
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("File not found", output)

    def test_file_ref_entry_renders_subtitle_style(self) -> None:
        """file_ref entries render with ⎿ subtitle style, no bullet prefix."""
        entry = HistoryEntry(entry_type="file_ref", text="Read main.py  (42 lines)")
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Read main.py", output)
        self.assertIn("42 lines", output)
        self.assertNotIn("•", output)

    def test_file_ref_directory_renders_subtitle_style(self) -> None:
        """file_ref entries for directories render with ⎿ subtitle style."""
        entry = HistoryEntry(entry_type="file_ref", text="Listed directory src/components/")
        output = self._render_to_str([entry])
        self.assertIn("⎿", output)
        self.assertIn("Listed directory src/components/", output)
        self.assertNotIn("•", output)
