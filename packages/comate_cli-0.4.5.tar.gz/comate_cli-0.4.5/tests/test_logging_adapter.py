from __future__ import annotations

import io
import logging
import sys

from comate_cli.terminal_agent.logging_adapter import (
    TUILoggingHandler,
    TUILoggingSession,
    setup_tui_logging,
)


class _FakeRenderer:
    def __init__(self) -> None:
        self.messages: list[tuple[str, str]] = []

    def append_system_message(self, message: str, *, severity: str) -> None:
        self.messages.append((message, severity))


def test_setup_tui_logging_preserves_existing_root_handlers_and_restores_them() -> None:
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    stderr_handler = logging.StreamHandler(sys.stderr)
    root.addHandler(stderr_handler)

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())

        assert stderr_handler in root.handlers
        assert any(isinstance(handler, TUILoggingHandler) for handler in root.handlers)
        assert root.level == logging.DEBUG
        assert len(stderr_handler.filters) == 1
    finally:
        if session is not None:
            session.close()
        if stderr_handler in root.handlers:
            root.removeHandler(stderr_handler)
        root.handlers[:] = original_handlers
        root.setLevel(original_level)

    assert stderr_handler.filters == []
    assert root.handlers == original_handlers
    assert root.level == original_level


def test_setup_tui_logging_does_not_mute_non_terminal_stream_handlers() -> None:
    root = logging.getLogger()
    original_handlers = list(root.handlers)
    original_level = root.level
    buffer_handler = logging.StreamHandler(io.StringIO())
    root.addHandler(buffer_handler)

    session: TUILoggingSession | None = None
    try:
        session = setup_tui_logging(_FakeRenderer())
        assert buffer_handler in root.handlers
        assert buffer_handler.filters == []
    finally:
        if session is not None:
            session.close()
        if buffer_handler in root.handlers:
            root.removeHandler(buffer_handler)
        root.handlers[:] = original_handlers
        root.setLevel(original_level)
