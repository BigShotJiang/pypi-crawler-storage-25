from __future__ import annotations

import logging
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from comate_agent_sdk.agent.events import (
    CompactionResultEvent,
    PlanApprovalRequiredEvent,
    SessionInitEvent,
    StepCompleteEvent,
    StopEvent,
    SubagentProgressEvent,
    SubagentStartEvent,
    SubagentStopEvent,
    SubagentToolCallEvent,
    SubagentToolResultEvent,
    TeamMessageEvent,
    TextEvent,
    ThinkingEvent,
    TaskUpdatedEvent,
    ToolCallEvent,
    ToolResultEvent,
    UsageDeltaEvent,
    UserQuestionEvent,
)

from rich.console import RenderableType
from rich.text import Text

from comate_cli.terminal_agent.models import HistoryEntry, LoadingState
from comate_cli.terminal_agent.tool_view import summarize_tool_args, resolve_display_tool_name, should_show_tool_in_scrollback
from comate_cli.terminal_agent.env_utils import read_env_int
from comate_cli.terminal_agent.custom_slash_commands import FILE_REF_PATTERN

logger = logging.getLogger(__name__)

_DEFAULT_TOOL_ERROR_SUMMARY_MAX_LEN = 160
_DEFAULT_TOOL_PANEL_MAX_LINES = 4
_DEFAULT_TASK_PANEL_MAX_LINES = 6
_RECENT_TEAM_EVENT_CACHE_SIZE = 128
_FILE_REF_MAX_COUNT_BYTES = 10 * 1024 * 1024  # 10 MB


def _truncate(content: str, max_len: int = 120) -> str:
    if len(content) <= max_len:
        return content
    return f"{content[:max_len]}..."


def _format_duration(seconds: float) -> str:
    elapsed = max(seconds, 0.0)
    if elapsed < 60:
        return f"{elapsed:.1f}s"
    minutes = int(elapsed // 60)
    remaining_seconds = int(elapsed % 60)
    if minutes < 60:
        return f"{minutes}m{remaining_seconds:02d}s"
    hours = minutes // 60
    remaining_minutes = minutes % 60
    return f"{hours}h{remaining_minutes:02d}m"


def _format_tokens(token_count: int) -> str:
    tokens = max(int(token_count), 0)
    if tokens < 1_000:
        return f"{tokens} tok"
    compact = f"{tokens / 1_000:.1f}".rstrip("0").rstrip(".")
    return f"{compact}k tok"


def _extract_task_title(args: dict[str, Any]) -> str:
    description = str(args.get("description", "")).strip()
    if description:
        return description

    subagent_name = str(args.get("subagent_type", "")).strip() or "Agent"
    return subagent_name


def _one_line(text: str) -> str:
    return " ".join(str(text).split())


def _tool_signature(tool_name: str, args_summary: str) -> str:
    normalized = args_summary.strip()
    if normalized:
        return f"{tool_name}({normalized})"
    return f"{tool_name}()"


def _task_sort_key(task: dict[str, Any]) -> tuple[int, int]:
    status = str(task.get("status", "pending")).strip().lower()
    open_blocked_by = task.get("open_blocked_by", [])
    is_blocked = isinstance(open_blocked_by, list) and len(open_blocked_by) > 0
    if status == "in_progress":
        rank = 0
    elif status == "pending" and not is_blocked:
        rank = 1
    elif status == "pending":
        rank = 2
    else:
        rank = 3

    try:
        numeric_id = int(task.get("id", 0))
    except (TypeError, ValueError):
        numeric_id = 0
    return rank, numeric_id


def _task_stats_header(tasks: list[dict[str, Any]]) -> str:
    """生成 task 统计标题，如 '3 tasks (1 done, 2 open)'。"""
    total = len(tasks)
    done = sum(
        1 for t in tasks
        if str(t.get("status", "")).strip().lower() == "completed"
    )
    open_count = total - done
    noun = "task" if total == 1 else "tasks"
    return f"{total} {noun} ({done} done, {open_count} open)"


def _format_task_row(task: dict[str, Any]) -> str:
    """格式化单条 task 行。

    符号约定：
    - ✓ completed
    - ◼ in_progress
    - ▢ pending (unblocked)
    - ▫ pending (blocked) — 视觉相似的中间符号，渲染层统一显示为 ▢ 但应用不同颜色
    """
    subject = str(task.get("subject", "")).strip() or "(untitled)"
    status = str(task.get("status", "pending")).strip().lower()
    open_blocked_by = task.get("open_blocked_by", [])

    if status == "completed":
        return f"✓ {subject}"
    if status == "in_progress":
        return f"◼ {subject}"
    if isinstance(open_blocked_by, list) and open_blocked_by:
        return f"▫ {subject}"
    return f"▢ {subject}"


@dataclass
class _SubagentTool:
    """Subagent 内部的工具调用"""
    tool_name: str
    args_summary: str
    started_at_monotonic: float
    status: Literal["running", "completed", "error"] = "running"
    duration_ms: float = 0.0


@dataclass
class _RunningTool:
    tool_name: str
    title: str
    started_at_monotonic: float
    is_task: bool
    args_summary: str
    display_tool_name: str = ""
    progress_tokens: int = 0
    subagent_name: str = ""
    subagent_status: str = ""
    subagent_description: str = ""
    nested_tools: list[tuple[str, _SubagentTool]] = field(default_factory=list)
    show_init: bool = False
    subagent_model_name: str = ""


class EventRenderer:
    """Convert SDK events to lightweight terminal state for prompt_toolkit UI."""

    def __init__(self, project_root: Path | None = None) -> None:
        self._history: list[HistoryEntry] = []
        self._running_tools: dict[str, _RunningTool] = {}
        self._tool_call_args: dict[str, dict[str, Any]] = {}
        self._thinking_content: str = ""
        self._assistant_buffer = ""
        self._loading_state: LoadingState = LoadingState.idle()
        self._current_tasks: list[dict[str, Any]] = []
        self._current_task_title: str | None = None
        self._task_started_at_monotonic: float | None = None
        self._project_root = project_root
        self._tool_error_summary_max_len = read_env_int(
            "AGENT_SDK_TUI_TOOL_ERROR_SUMMARY_MAX_LEN",
            _DEFAULT_TOOL_ERROR_SUMMARY_MAX_LEN,
        )
        self._tool_panel_max_lines = read_env_int(
            "AGENT_SDK_TUI_TOOL_PANEL_MAX_LINES",
            _DEFAULT_TOOL_PANEL_MAX_LINES,
        )
        self._task_panel_max_lines = read_env_int(
            "AGENT_SDK_TUI_TASK_PANEL_MAX_LINES",
            _DEFAULT_TASK_PANEL_MAX_LINES,
        )
        self._diff_max_lines = read_env_int(
            "AGENT_SDK_TUI_DIFF_MAX_LINES",
            50,
        )
        self._latest_diff_lines: list[str] | None = None
        self._recent_team_event_keys: deque[tuple[str, str, str, str, str, str]] = deque(
            maxlen=_RECENT_TEAM_EVENT_CACHE_SIZE
        )

    def start_turn(self) -> None:
        self._flush_assistant_segment()
        self._thinking_content = ""
        self._rebuild_loading_line()

    def seed_user_message(self, content: str) -> None:
        normalized = content.strip()
        if not normalized:
            return
        self._flush_assistant_segment()
        self._history.append(HistoryEntry(entry_type="user", text=normalized))
        self._maybe_append_file_ref_hint(normalized)

    def _maybe_append_file_ref_hint(self, text: str) -> None:
        """Append a dim ⎿ hint for the first valid @path reference."""
        if self._project_root is None:
            return
        for match in FILE_REF_PATTERN.finditer(text):
            raw_path = match.group(1)
            candidate = self._project_root / raw_path
            try:
                if candidate.is_dir():
                    self._history.append(HistoryEntry(entry_type="file_ref", text=f"Listed directory {raw_path}"))
                    return
                if candidate.is_file():
                    hint = f"Read {raw_path}"
                    if candidate.stat().st_size <= _FILE_REF_MAX_COUNT_BYTES:
                        try:
                            with open(candidate, "rb") as fh:
                                line_count = sum(1 for _ in fh)
                            hint += f"  ({line_count} lines)"
                        except OSError:
                            pass
                    self._history.append(HistoryEntry(entry_type="file_ref", text=hint))
                    return
            except OSError:
                continue

    def close(self) -> None:
        return

    def finalize_turn(self) -> None:
        self._flush_assistant_segment()
        self._rebuild_loading_line()

    def tick_progress(self) -> None:
        self._rebuild_loading_line()

    def refresh_loading_animation(self) -> None:
        self._rebuild_loading_line()

    def interrupt_turn(self) -> None:
        if self._running_tools:
            self._history.append(
                HistoryEntry(
                    entry_type="system",
                    text=f"Current task interrupted ({len(self._running_tools)} running tools)",
                    severity="warning",
                )
            )
        self._running_tools.clear()
        self._flush_assistant_segment()
        self._thinking_content = ""
        self._rebuild_loading_line()

    def history_entries(self) -> list[HistoryEntry]:
        return list(self._history)

    def reset_history_view(self) -> None:
        """重置 history 视图状态（用于会话切换后的重新加载）。"""
        self._history = []
        self._recent_team_event_keys.clear()
        self._running_tools.clear()
        self._tool_call_args.clear()
        self._thinking_content = ""
        self._assistant_buffer = ""
        self._loading_state = LoadingState.idle()
        self._current_tasks = []
        self._current_task_title = None
        self._task_started_at_monotonic = None
        self._latest_diff_lines = None

    @property
    def latest_diff_lines(self) -> list[str] | None:
        return self._latest_diff_lines

    def has_running_tools(self) -> bool:
        return bool(self._running_tools)

    def has_running_subagents(self) -> bool:
        """Return whether any running tool is an Agent(subagent) tool."""
        return any(state.is_task for state in self._running_tools.values())

    def has_active_tasks(self) -> bool:
        return bool(self._current_tasks)

    def has_active_todos(self) -> bool:
        return self.has_active_tasks()

    def has_in_progress_tasks(self) -> bool:
        return any(
            str(t.get("status", "")).strip().lower() == "in_progress"
            for t in self._current_tasks
        )

    def compute_required_tool_panel_lines(self) -> int:
        """计算显示所有 running tools 所需的最小行数。"""
        if not self._running_tools:
            return 0
        total_lines = 0
        for tool_call_id, state in self._running_tools.items():
            if state.is_task:
                total_lines += 1  # 主标题行
                # 嵌套工具（最多 3 个）
                total_lines += min(len(state.nested_tools), 3)
                # init 行（仅在创建后、首个有效子事件前显示）
                if state.show_init:
                    total_lines += 1
            else:
                total_lines += 1
        return total_lines

    def loading_state(self) -> LoadingState:
        """返回语义化的 loading 状态，用于 UI 层决定渲染策略。"""
        return self._loading_state

    def loading_line(self) -> str:
        """兼容旧接口，返回 loading 状态的文本内容。"""
        return self._loading_state.text

    def append_subtitle(self, text: str) -> None:
        """Append a ⎿ subtitle entry, visually attached to the preceding entry."""
        normalized = text.strip()
        if not normalized:
            return
        self._history.append(HistoryEntry(entry_type="file_ref", text=normalized))

    def append_system_message(
        self,
        content: str,
        *,
        severity: Literal["info", "warning", "error"] = "info",
    ) -> None:
        normalized = content.strip()
        if not normalized:
            return
        self._flush_assistant_segment()
        self._history.append(
            HistoryEntry(entry_type="system", text=normalized, severity=severity)
        )

    @staticmethod
    def _team_event_key(
        *,
        agent_name: str,
        from_agent: str,
        to_agent: str | None,
        message_type: str,
        timestamp: str,
        content_preview: str,
    ) -> tuple[str, str, str, str, str, str]:
        return (
            str(agent_name or "").strip(),
            str(from_agent or "").strip(),
            str(to_agent or "").strip(),
            str(message_type or "").strip(),
            str(timestamp or "").strip(),
            str(content_preview or "").strip(),
        )

    def append_team_message_event(
        self,
        *,
        agent_name: str,
        from_agent: str,
        to_agent: str | None,
        message_type: str,
        content_preview: str,
        timestamp: str,
    ) -> bool:
        event_key = self._team_event_key(
            agent_name=agent_name,
            from_agent=from_agent,
            to_agent=to_agent,
            message_type=message_type,
            timestamp=timestamp,
            content_preview=content_preview,
        )
        if event_key in self._recent_team_event_keys:
            logger.debug(
                "[team-diag] renderer_dedupe "
                "agent=%r from=%r to=%r type=%r timestamp=%r preview=%r",
                agent_name,
                from_agent,
                to_agent,
                message_type,
                timestamp,
                content_preview,
            )
            return False

        self._recent_team_event_keys.append(event_key)
        target = to_agent or "[broadcast]"
        preview_str = f' "{content_preview}"' if content_preview else ""
        text = f"[team] {from_agent} → {target}: ({message_type}){preview_str}"
        logger.debug(
            "[team-diag] renderer_append "
            "agent=%r from=%r to=%r type=%r timestamp=%r preview=%r history_len_before=%d",
            agent_name,
            from_agent,
            to_agent,
            message_type,
            timestamp,
            content_preview,
            len(self._history),
        )
        self.append_system_message(text)
        return True

    def append_elapsed_message(self, content: str) -> None:
        """追加一条灰色无前缀的计时统计行到 history scrollback."""
        normalized = content.strip()
        if not normalized:
            return
        self._flush_assistant_segment()
        self._history.append(HistoryEntry(entry_type="elapsed", text=normalized))

    def append_assistant_message(self, content: str) -> None:
        normalized = content.strip()
        if not normalized:
            return
        self._flush_assistant_segment()
        self._history.append(HistoryEntry(entry_type="assistant", text=normalized))

    def tool_panel_entries(
        self, *, max_lines: int | None = None
    ) -> list[tuple[int, str | list[tuple[str, str]]]]:
        """Return panel entries for running tools.

        Each entry is a tuple: (indent_level, content).
        content is either a plain str or a list of (style, text) prompt_toolkit fragments.
        indent_level == 0 means a primary tool line; >0 means nested status.
        indent_level < 0 means a meta line (no dot prefix).
        """
        limit = max_lines if max_lines is not None else self._tool_panel_max_lines
        normalized_limit = max(1, int(limit))
        if not self._running_tools:
            return []

        now = time.monotonic()
        entries: list[tuple[int, str]] = []
        tool_items = list(self._running_tools.items())
        for idx, (tool_call_id, state) in enumerate(tool_items):
            elapsed = _format_duration(now - state.started_at_monotonic)
            lines_to_add = 1
            if state.is_task:
                tokens_suffix = (
                    f" · {_format_tokens(state.progress_tokens)}"
                    if state.progress_tokens > 0
                    else ""
                )
                # 主标题行 + 嵌套工具（最多 3 个）+ 状态行（如果有状态）
                lines_to_add = 1 + min(len(state.nested_tools), 3)
                if state.show_init:
                    lines_to_add += 1
            else:
                lines_to_add = 1

            if len(entries) + lines_to_add > normalized_limit:
                remaining_tools = len(tool_items) - idx
                entries.append((-1, f"… (+{remaining_tools})"))
                break

            if state.is_task:
                tokens_suffix = (
                    f" · {_format_tokens(state.progress_tokens)}"
                    if state.progress_tokens > 0
                    else ""
                )
                # 格式：SubagentName(描述) · model(dim) · elapsed · tools · tokens
                subagent_name = state.subagent_name or "Agent"
                description = state.subagent_description or state.title
                title = f"{subagent_name}({description})"
                tool_count = len(state.nested_tools)
                tool_count_suffix = f" · +{tool_count} tool uses" if tool_count > 0 else ""
                rest = f" · {elapsed}{tool_count_suffix}{tokens_suffix}"
                if state.subagent_model_name:
                    # Return styled fragments: model_name in dim
                    frags: list[tuple[str, str]] = [
                        ("", title),
                        ("class:dim", f" · {state.subagent_model_name}"),
                        ("", rest),
                    ]
                    entries.append((0, frags))
                else:
                    entries.append((0, f"{title}{rest}"))

                # 嵌套工具调用（最多显示最近 3 个）
                for child_id, child_tool in state.nested_tools[-3:]:
                    child_display = resolve_display_tool_name(child_tool.tool_name, {})
                    signature = _tool_signature(child_display, child_tool.args_summary)
                    if child_tool.status == "running":
                        entries.append((1, f"⎿ {signature}"))
                    else:
                        icon = "✓" if child_tool.status == "completed" else "✗"
                        entries.append((1, f"⎿ {icon} {signature}"))

                if state.show_init:
                    entries.append((1, "⎿ init"))
            else:
                display_name = state.display_tool_name or state.tool_name
                signature = _tool_signature(display_name, state.args_summary)
                entries.append((0, f"{signature} · {elapsed}"))

        return entries[:normalized_limit]

    def task_panel_lines(self, *, max_lines: int | None = None) -> list[str]:
        lines = self.full_task_panel_lines()
        if not lines:
            return []

        limit = max_lines if max_lines is not None else self._task_panel_max_lines
        normalized_limit = max(1, int(limit))
        if len(lines) <= normalized_limit:
            return lines

        clipped = lines[: normalized_limit - 1]
        clipped.append(f"… (+{len(lines) - (normalized_limit - 1)})")
        return clipped

    def full_task_panel_lines(self) -> list[str]:
        tasks = list(self._current_tasks)
        if not tasks:
            return []

        header = str(self._current_task_title or "").strip()
        if not header:
            header = _task_stats_header(tasks)
        lines: list[str] = [header]
        for task in sorted(tasks, key=_task_sort_key):
            lines.append(_format_task_row(task))
        return lines

    def _flush_assistant_segment(self) -> None:
        if not self._assistant_buffer:
            return
        self._history.append(HistoryEntry(entry_type="assistant", text=self._assistant_buffer))
        self._assistant_buffer = ""

    def _append_assistant_text(self, text: str) -> None:
        self._assistant_buffer += text

    def _append_tool_call(self, tool_name: str, args: dict[str, Any], tool_call_id: str) -> None:
        self._running_tools[tool_call_id] = self._make_running_tool(tool_name, args)

    def _build_tool_subtitle(
        self, tool_name: str, result: str, metadata: dict[str, Any] | None = None,
        output: Any = None,
    ) -> str | None:
        """Build a subtitle string for tool result display.

        Returns None for tools that don't need a subtitle line.
        """
        import re

        lowered = tool_name.lower()

        # ── typed output 优先路径 ──
        if output is not None:
            try:
                from comate_agent_sdk.tool_schemas.write import WriteOutput
                from comate_agent_sdk.tool_schemas.read import ReadOutput
                from comate_agent_sdk.tool_schemas.bash import BashOutput
                from comate_agent_sdk.tool_schemas.search import GlobOutput, GrepOutput, LSOutput

                if lowered == "write" and isinstance(output, WriteOutput):
                    return f"Write {output.lines_written} lines"

                if lowered == "read" and isinstance(output, ReadOutput):
                    return f"Read {output.lines_returned} lines of {output.total_lines}"

                if lowered == "bash" and isinstance(output, BashOutput):
                    return f"Exit code {output.exit_code}"

                if lowered in ("glob", "ls") and isinstance(output, (GlobOutput, LSOutput)):
                    return f"Found {output.count} files"

                if lowered == "grep" and isinstance(output, GrepOutput):
                    return f"Found {output.total_matches} matches"
            except ImportError:
                pass  # SDK not available, fall through to legacy

        if lowered == "skill":
            return "Successfully loaded skill"

        if lowered == "read":
            if isinstance(metadata, dict):
                lines_returned = metadata.get("lines_returned")
                start_line = metadata.get("start_line")
                end_line = metadata.get("end_line")
                total_lines = metadata.get("total_lines")
                if (
                    isinstance(lines_returned, int)
                    and lines_returned >= 0
                    and isinstance(start_line, int)
                    and start_line >= 0
                    and isinstance(end_line, int)
                    and end_line >= 0
                    and isinstance(total_lines, int)
                    and total_lines >= 0
                ):
                    return f"Read {lines_returned} lines · Lines {start_line}-{end_line} of {total_lines}"
            lines = result.split("\n") if result else []
            if lines and lines[-1] == "":
                lines = lines[:-1]
            return f"Read {len(lines)} lines"

        if lowered == "write":
            lines = result.split("\n") if result else []
            if lines and lines[-1] == "":
                lines = lines[:-1]
            return f"Write {len(lines)} lines"

        if lowered in ("edit", "multiedit"):
            if not metadata:
                return None
            diff_lines = metadata.get("diff")
            if not isinstance(diff_lines, list) or not diff_lines:
                return None
            added = sum(1 for line in diff_lines if line.startswith("+") and not line.startswith("+++"))
            removed = sum(1 for line in diff_lines if line.startswith("-") and not line.startswith("---"))
            parts = []
            if added:
                a_unit = "line" if added == 1 else "lines"
                parts.append(f"Added {added} {a_unit}")
            if removed:
                r_unit = "line" if removed == 1 else "lines"
                prefix = "Removed" if not parts else "removed"
                parts.append(f"{prefix} {removed} {r_unit}")
            if not parts:
                return "No changes"
            return ", ".join(parts)

        if lowered == "bash":
            match = re.search(r"Exit code (\d+)", result or "")
            if match:
                return f"Exit code {match.group(1)}"
            return "Completed"

        if lowered in ("glob", "ls"):
            lines = [line for line in (result or "").splitlines() if line.strip()]
            return f"Found {len(lines)} files"

        if lowered == "grep":
            lines = [line for line in (result or "").splitlines() if line.strip()]
            return f"Found matches in {len(lines)} files"

        return None

    def append_static_tool_result(
        self,
        signature: str,
        is_error: bool = False,
        diff_lines: list[str] | None = None,
        model_name: str = "",
        subtitle: str | None = None,
    ) -> None:
        """Append a tool result to history as a static entry (no timer).

        Args:
            signature: 工具签名，例如 "Read(path=xxx)"
            is_error: 是否为错误结果
            diff_lines: optional diff lines for Edit/MultiEdit
            model_name: model name for Agent tools (rendered dim)
            subtitle: optional subtitle rendered as `⎿ ...`
        """
        sev: Literal["info", "warning", "error"] = "error" if is_error else "info"
        if not is_error and diff_lines and len(diff_lines) > 0:
            self._latest_diff_lines = diff_lines
            text_obj = Text(signature)
            if model_name:
                text_obj.append(f" · {model_name}", style="dim")
            text_obj.append("\n")
            text_obj.append(self._render_diff_text(diff_lines, max_lines=self._diff_max_lines))
            self._history.append(
                HistoryEntry(entry_type="tool_result", text=text_obj, severity="info", subtitle=subtitle)
            )
            return
        if model_name:
            text_obj = Text(signature)
            text_obj.append(f" · {model_name}", style="dim")
            self._history.append(
                HistoryEntry(entry_type="tool_result", text=text_obj, severity=sev, subtitle=subtitle)
            )
            return
        self._history.append(
            HistoryEntry(
                entry_type="tool_result",
                text=signature,
                severity=sev,
                subtitle=subtitle,
            )
        )

    def _make_running_tool(self, tool_name: str, args: dict[str, Any]) -> _RunningTool:
        """Create a _RunningTool from tool name and args dict."""
        title = tool_name
        is_task = tool_name.lower() == "agent"
        summary = summarize_tool_args(tool_name, args, self._project_root).strip()
        display_name = resolve_display_tool_name(tool_name, args)
        subagent_name = ""
        subagent_description = ""
        if is_task:
            title = _extract_task_title(args)
            summary = ""
            subagent_name = str(args.get("subagent_type", "")).strip() or "Agent"
            subagent_description = str(args.get("description", "")).strip()

        return _RunningTool(
            tool_name=tool_name,
            display_tool_name=display_name,
            title=title,
            started_at_monotonic=time.monotonic(),
            is_task=is_task,
            args_summary=summary,
            show_init=is_task,
            subagent_name=subagent_name,
            subagent_description=subagent_description,
        )

    def _append_tool_result(
        self,
        tool_name: str,
        tool_call_id: str,
        is_error: bool,
        result: Any,
        metadata: dict[str, Any] | None = None,
        output: Any = None,
    ) -> None:
        sev: Literal["info", "warning", "error"] = "error" if is_error else "info"
        if is_error:
            subtitle = _truncate(_one_line(result), self._tool_error_summary_max_len)
        else:
            subtitle = self._build_tool_subtitle(tool_name, str(result), metadata, output)
        state = self._running_tools.pop(tool_call_id, None)
        if state is None:
            display_name = resolve_display_tool_name(tool_name, {})
            signature = _tool_signature(display_name, "")
            self._history.append(HistoryEntry(entry_type="tool_result", text=signature, severity=sev, subtitle=subtitle))
            return

        if state.is_task:
            subagent_name = state.subagent_name or "Agent"
            description = state.subagent_description or state.title
            if description and description != subagent_name:
                task_title = f"{subagent_name}({description})"
            else:
                task_title = subagent_name

            model_name = ""
            if metadata and isinstance(metadata, dict):
                model_name = metadata.get("model_name", "")

            tool_count = len(state.nested_tools)
            base = Text(task_title)
            if model_name:
                base.append(f" · {model_name}", style="dim")
            if tool_count > 0:
                base.append(f" · +{tool_count} tool uses")
            if state.progress_tokens > 0:
                base.append(f" · {_format_tokens(state.progress_tokens)}")
        else:
            display_name = state.display_tool_name or state.tool_name
            summary = state.args_summary
            # Append line range for Edit/MultiEdit
            if display_name == "Update" and metadata:
                sl = metadata.get("start_line")
                el = metadata.get("end_line")
                if isinstance(sl, int) and sl > 0:
                    line_suffix = f":L{sl}-L{el}" if isinstance(el, int) and el > sl else f":L{sl}"
                    summary = f"{summary}{line_suffix}" if summary else line_suffix
            signature = _tool_signature(display_name, summary)
            base = f"{signature}"

        # Render diff for Edit/MultiEdit if metadata contains diff lines
        if not is_error and metadata:
            diff_lines = metadata.get("diff")
            if isinstance(diff_lines, list) and len(diff_lines) > 0:
                self._latest_diff_lines = diff_lines
                if isinstance(base, Text):
                    text_obj = base
                else:
                    text_obj = Text(base)
                text_obj.append("\n")
                text_obj.append(self._render_diff_text(diff_lines, max_lines=self._diff_max_lines))
                self._history.append(
                    HistoryEntry(entry_type="tool_result", text=text_obj, severity="info", subtitle=subtitle)
                )
                return

        if isinstance(base, Text):
            self._history.append(HistoryEntry(entry_type="tool_result", text=base, severity=sev, subtitle=subtitle))
        else:
            self._history.append(HistoryEntry(entry_type="tool_result", text=base, severity=sev, subtitle=subtitle))

    @staticmethod
    def _render_diff_text(diff_lines: list[str], max_lines: int = 50) -> Text:
        """Render diff lines as colored Rich Text with line numbers."""
        import re
        import shutil

        result = Text()
        visible_lines = [
            line for line in diff_lines if not (line.startswith("---") or line.startswith("+++"))
        ]
        total_lines = len(visible_lines)
        displayed_lines = visible_lines[:max_lines] if max_lines > 0 else visible_lines

        # Get terminal width for padding
        try:
            terminal_width = shutil.get_terminal_size().columns
        except Exception:
            terminal_width = 120

        old_line = 0
        new_line = 0
        hunk_pattern = re.compile(r"^@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@")

        for line in displayed_lines:
            m = hunk_pattern.match(line)
            if m:
                old_line = int(m.group(1))
                new_line = int(m.group(2))
                result.append(line, style="cyan")
                result.append("\n")
                continue

            if line.startswith("-"):
                result.append(f"{old_line:>4} ", style="#ffffff on #4a0202")
                result.append(line, style="#ffffff on #4a0202")
                # Calculate padding to fill the entire line
                content_width = 5 + len(line)  # line number (4) + space (1) + content
                padding = max(0, terminal_width - content_width)
                result.append(" " * padding, style="#ffffff on #4a0202")
                result.append("\n")
                old_line += 1
            elif line.startswith("+"):
                result.append(f"{new_line:>4} ", style="#c6c6c6 on #2e502e")
                result.append(line, style="#ffffff on #2e502e")
                # Calculate padding to fill the entire line
                content_width = 5 + len(line)  # line number (4) + space (1) + content
                padding = max(0, terminal_width - content_width)
                result.append(" " * padding, style="#ffffff on #2e502e")
                result.append("\n")
                new_line += 1
            else:
                result.append(f"{new_line:>4} ", style="dim")
                result.append(line, style="dim")
                result.append("\n")
                old_line += 1
                new_line += 1

        if max_lines > 0 and total_lines > max_lines:
            result.append(
                f"... ({total_lines - max_lines} more lines, Ctrl+O to expand)",
                style="dim italic",
            )

        return result

    def _rebuild_loading_line(self) -> None:
        if self._thinking_content:
            text = f"🤔 {_truncate(self._thinking_content, 90)}"
            self._loading_state = LoadingState.thinking(
                text=text,
                content=self._thinking_content,
            )
            return

        self._loading_state = LoadingState.idle()

    def _append_questions(self, questions: list[dict[str, Any]]) -> None:
        if not questions:
            return
        self._history.append(
            HistoryEntry(
                entry_type="tool_result",
                text=f"Input required: {len(questions)} question(s) pending.",
            )
        )
        for idx, question in enumerate(questions, 1):
            question_text = str(question.get("question", "")).strip()
            header = str(question.get("header", f"Question {idx}")).strip()
            options = question.get("options", [])
            labels: list[str] = []
            if isinstance(options, list):
                for option in options[:3]:
                    if not isinstance(option, dict):
                        continue
                    label = str(option.get("label", "")).strip()
                    if label:
                        labels.append(label)
            choice_preview = f" (Options: {' / '.join(labels)})" if labels else ""
            self._history.append(
                HistoryEntry(
                    entry_type="tool_result",
                    text=f"  {idx}. {header}: {question_text} {choice_preview}".strip(),
                )
            )

    def _update_tasks(self, tasks: list[dict[str, Any]], *, list_id: str) -> None:
        """更新当前共享任务列表状态。"""
        normalized = list(tasks) if tasks else []
        if not normalized:
            self._current_tasks = []
            self._current_task_title = None
            self._task_started_at_monotonic = None
            return

        all_completed = all(str(item.get("status", "")).strip().lower() == "completed" for item in normalized)
        # 标题：显示 ID 最小的 in_progress task 的 subject，否则统计摘要
        in_progress_tasks = [
            t for t in normalized
            if str(t.get("status", "")).strip().lower() == "in_progress"
        ]
        if in_progress_tasks:
            in_progress_tasks.sort(key=lambda t: int(t.get("id", 0)))
            header = str(in_progress_tasks[0].get("subject", "")).strip() or "Tasks"
        else:
            header = _task_stats_header(normalized)
        if not all_completed:
            if not self._current_tasks:
                self._task_started_at_monotonic = time.monotonic()
            self._current_task_title = header
            self._current_tasks = normalized
            return

        # All completed: hide panel and write a summary entry once.
        # 守卫：_current_tasks 已空说明完成总结已写过，跳过重复写入
        if not self._current_tasks:
            return
        started = self._task_started_at_monotonic
        elapsed_suffix = ""
        if started is not None:
            elapsed_suffix = f" · {_format_duration(time.monotonic() - started)}"
        total = len(normalized)
        self._history.append(
            HistoryEntry(
                entry_type="tool_result",
                text=f"tasks {total}/{total} completed{elapsed_suffix}",
                severity="info",
            )
        )
        self._current_tasks = []
        self._current_task_title = None
        self._task_started_at_monotonic = None

    def task_renderable(self) -> RenderableType | None:
        """将当前任务工作集渲染为 Rich 组件。

        Returns:
            Rich RenderableType 或 None（如果没有 task）
        """
        if not self._current_tasks:
            return None

        tasks = list(sorted(self._current_tasks, key=_task_sort_key))
        total = len(tasks)
        completed = sum(1 for task in tasks if task.get("status") == "completed")

        # 构建 Rich Text 组件
        result = Text()

        # 标题
        result.append(f"{self._current_task_title or 'Tasks'} ({completed}/{total} completed)\n")

        for task in tasks:
            line = _format_task_row(task)
            if line.startswith("✓ "):
                result.append("  ✓ ")
                result.append(line[2:], style="green strike")
            elif line.startswith("◼ "):
                result.append("  ◼ ")
                result.append(line[2:], style="#F97316")
            elif line.startswith("▫ "):
                # blocked pending: display as ▢ + dim
                result.append("  ▢ ")
                result.append(line[2:], style="dim")
            elif line.startswith("▢ "):
                result.append("  ▢ ")
                result.append(line[2:])
            else:
                result.append(f"  {line}")
            result.append("\n")

        # 移除末尾的换行
        if result.plain.endswith("\n"):
            result = result[:-1]

        return result

    def task_lines(self) -> list[str]:
        """返回当前任务面板行列表（用于测试）。"""
        return self.task_panel_lines(max_lines=6)

    def todo_panel_lines(self, *, max_lines: int | None = None) -> list[str]:
        return self.task_panel_lines(max_lines=max_lines)

    def todo_all_lines(self) -> list[str]:
        return self.full_task_panel_lines()

    def todo_renderable(self) -> RenderableType | None:
        return self.task_renderable()

    def todo_lines(self) -> list[str]:
        return self.task_lines()

    def handle_event(self, event: Any) -> tuple[bool, list[dict[str, Any]] | None]:
        if not isinstance(event, TextEvent):
            self._flush_assistant_segment()

        match event:
            case SessionInitEvent(session_id=_):
                pass
            case ThinkingEvent(content=thinking):
                self._thinking_content = thinking
                self._history.append(HistoryEntry(entry_type="thinking", text=thinking))
            case CompactionResultEvent(
                current_tokens=tokens,
                threshold=threshold,
                trigger=trigger,
                attempted=attempted,
                compacted=compacted,
                reason=reason,
                tokens_before=tokens_before,
                tokens_after=tokens_after,
            ):
                pct = int(tokens / threshold * 100) if threshold > 0 else 0
                if compacted:
                    self.append_system_message(
                        (
                            f"Context compaction completed ({trigger}): "
                            f"{tokens_before:,} → {tokens_after:,} tokens "
                            f"(check {tokens:,}/{threshold:,}, {pct}%)"
                        ),
                        severity="info",
                    )
                elif attempted:
                    self.append_system_message(
                        (
                            f"Context compaction attempt failed ({trigger}): "
                            f"kept {tokens_after:,} tokens "
                            f"(check {tokens:,}/{threshold:,}, {pct}%, reason={reason})"
                        ),
                        severity="warning",
                    )
                else:
                    self.append_system_message(
                        (
                            f"Context compaction skipped ({trigger}): "
                            f"{tokens:,}/{threshold:,} tokens ({pct}%), reason={reason}"
                        ),
                        severity="warning",
                    )
            case ToolCallEvent(tool=tool_name, args=arguments, tool_call_id=tool_call_id):
                args_dict = arguments if isinstance(arguments, dict) else {"_raw": str(arguments)}
                self._thinking_content = ""
                # Store args for ToolResult phase lookup.
                self._tool_call_args[tool_call_id] = args_dict
                if not should_show_tool_in_scrollback(tool_name, args_dict):
                    self._rebuild_loading_line()
                    return (False, None)
                self._append_tool_call(tool_name, args_dict, tool_call_id)
            case ToolResultEvent(tool=tool_name, result=result, tool_call_id=tool_call_id, is_error=is_error, metadata=metadata, output=output):
                stored_args = self._tool_call_args.pop(tool_call_id, {})
                if not should_show_tool_in_scrollback(tool_name, stored_args, is_result=True, is_error=is_error):
                    self._running_tools.pop(tool_call_id, None)
                    self._rebuild_loading_line()
                    return (False, None)
                self._append_tool_result(
                    tool_name=tool_name,
                    tool_call_id=tool_call_id,
                    is_error=is_error,
                    result=result,
                    metadata=metadata,
                    output=output,
                )
            case UsageDeltaEvent(
                source=_,
                model=_,
                level=_,
                delta_prompt_tokens=_,
                delta_prompt_cached_tokens=_,
                delta_completion_tokens=_,
                delta_total_tokens=_,
            ):
                pass
            case SubagentStartEvent(tool_call_id=_, subagent_name=_, description=_):
                pass
            case SubagentProgressEvent(
                tool_call_id=tool_call_id,
                subagent_name=subagent_name,
                description=description,
                status=status,
                elapsed_ms=elapsed_ms,
                tokens=tokens,
                model_name=model_name,
            ):
                state = self._running_tools.get(tool_call_id)
                if state is not None:
                    if tokens is not None:
                        state.progress_tokens = max(int(tokens), 0)
                    if elapsed_ms is not None:
                        normalized = max(float(elapsed_ms), 0.0)
                        state.started_at_monotonic = time.monotonic() - (normalized / 1000)
                    # Subagent-specific status for task tool panel.
                    state.subagent_name = str(subagent_name or "").strip()
                    state.subagent_status = str(status or "").strip()
                    state.subagent_description = str(description or "").strip()
                    if model_name:
                        state.subagent_model_name = str(model_name)
                    # 首个有效子事件后移除 init 占位。
                    progress_status = str(status or "").strip().lower()
                    has_activity = bool(tokens and int(tokens) > 0) or bool(
                        elapsed_ms and float(elapsed_ms) > 0.0
                    )
                    if has_activity or progress_status in {"completed", "error", "timeout", "cancelled"}:
                        state.show_init = False
            case SubagentStopEvent(tool_call_id=_, subagent_name=_, status=_, duration_ms=_, error=_):
                pass
            case SubagentToolCallEvent(
                parent_tool_call_id=parent_tool_call_id,
                subagent_name=_,
                tool=tool,
                args=args,
                tool_call_id=tool_call_id,
            ):
                # 将嵌套工具调用添加到父 Agent 的 nested_tools
                parent_state = self._running_tools.get(parent_tool_call_id)
                if parent_state is not None:
                    args_summary = summarize_tool_args(tool, args, self._project_root).strip()
                    nested_tool = _SubagentTool(
                        tool_name=tool,
                        args_summary=args_summary,
                        started_at_monotonic=time.monotonic(),
                        status="running",
                    )
                    parent_state.nested_tools.append((tool_call_id, nested_tool))
                    parent_state.show_init = False
            case SubagentToolResultEvent(
                parent_tool_call_id=parent_tool_call_id,
                subagent_name=_,
                tool=_,
                tool_call_id=tool_call_id,
                is_error=is_error,
                duration_ms=duration_ms,
            ):
                # 更新嵌套工具的状态
                parent_state = self._running_tools.get(parent_tool_call_id)
                if parent_state is not None:
                    for nested_id, nested_tool in parent_state.nested_tools:
                        if nested_id == tool_call_id:
                            nested_tool.status = "error" if is_error else "completed"
                            nested_tool.duration_ms = duration_ms
                            parent_state.show_init = False
                            break
            case TaskUpdatedEvent(list_id=list_id, tasks=tasks):
                self._update_tasks(tasks, list_id=list_id)
            case UserQuestionEvent(questions=questions, tool_call_id=_):
                self._append_questions(questions)
                self._rebuild_loading_line()
                return (True, questions)
            case TextEvent(content=text):
                self._thinking_content = ""
                if text:
                    self._append_assistant_text(text)
            case StepCompleteEvent(step_id=step_id, status=_, duration_ms=_):
                # Cancellation/error paths may emit StepCompleteEvent without ToolResultEvent.
                # Ensure tool panel state is cleaned up by step id.
                self._running_tools.pop(step_id, None)
            case StopEvent(reason=reason):
                self._flush_assistant_segment()
                self._thinking_content = ""
                # Safety net: if any running tool rows remain, stop event means this turn is ending.
                self._running_tools.clear()
                self._rebuild_loading_line()
                if reason == "waiting_for_input":
                    return (True, None)
                if reason == "waiting_for_plan_approval":
                    return (False, None)
                if reason == "interrupted":
                    self._history.append(
                        HistoryEntry(entry_type="system", text="Current task interrupted.", severity="warning")
                    )
            case PlanApprovalRequiredEvent(
                plan_path=plan_path,
                summary=summary,
                execution_prompt=_,
                plan_markdown=plan_markdown,
            ):
                # 在 scrollback 渲染计划内容，让用户审阅后再决策。
                # 优先使用事件携带正文，避免依赖本地二次读文件。
                plan_content = str(plan_markdown or "")
                if not plan_content:
                    try:
                        plan_content = Path(plan_path).read_text(encoding="utf-8")
                    except Exception:
                        logger.warning("ExitPlanMode: Failed to read plan file %s", plan_path)
                if plan_content:
                    self._history.append(
                        HistoryEntry(
                            entry_type="system",
                            text="─── Here is the plan, please review and approve or reject ───",
                        )
                    )
                    self._history.append(HistoryEntry(entry_type="assistant", text=plan_content))

                text = f"Plan ready for review: {plan_path}"
                if summary:
                    text = f"{text} | {summary}"
                self._history.append(
                    HistoryEntry(entry_type="system", text=text)
                )
            case TeamMessageEvent(
                agent_name=agent_name,
                from_agent=from_agent,
                to_agent=to_agent,
                message_type=message_type,
                content_preview=content_preview,
                timestamp=timestamp,
            ):
                self.append_team_message_event(
                    agent_name=agent_name,
                    from_agent=from_agent,
                    to_agent=to_agent,
                    message_type=message_type,
                    content_preview=content_preview,
                    timestamp=timestamp,
                )
            case _:
                logger.debug("Unhandled event type: %s", type(event).__name__)

        self._rebuild_loading_line()
        return (False, None)
