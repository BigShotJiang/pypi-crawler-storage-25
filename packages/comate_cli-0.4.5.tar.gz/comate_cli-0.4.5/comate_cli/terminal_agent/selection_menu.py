"""通用选择菜单 UI 组件。

提供简单的单选菜单界面，支持上下选择、Enter 确认、Esc 取消。
可用于模型切换、配置选择等二级选择场景。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal

from prompt_toolkit.filters import Condition
from prompt_toolkit.layout import HSplit, Window
from prompt_toolkit.layout.controls import FormattedTextControl
from prompt_toolkit.utils import get_cwidth

from comate_cli.terminal_agent.text_effects import fit_single_line


@dataclass(frozen=True, slots=True)
class SelectionOption:
    """单个选项。"""

    value: str
    label: str
    description: str = ""


@dataclass(slots=True)
class SelectionMenuState:
    """选择菜单状态。"""

    title: str = ""
    options: list[SelectionOption] = field(default_factory=list)
    selected_index: int = 0
    viewport_start: int = 0
    page_size: int = 0
    item_gap_lines: int = 0
    wrap_navigation: bool = True
    description_selected_only: bool = False
    line_wrap: bool = True
    layout_mode: Literal["stacked", "inline"] = "stacked"
    inline_total_width: int | None = None
    inline_name_min_width: int = 12
    inline_name_max_width: int = 28
    inline_gap_spaces: int = 2
    context_lines: list[str] = field(default_factory=list)
    is_confirmed: bool = False
    is_cancelled: bool = False


@dataclass(frozen=True, slots=True)
class SelectionResult:
    """选择结果。"""

    confirmed: bool
    value: str | None = None
    label: str | None = None


class SelectionMenuUI:
    """通用选择菜单 UI 组件。

    适用于简单的单选场景，如：
    - 模型级别切换 (LOW/MID/HIGH)
    - 配置选项选择
    - 快捷操作菜单

    按键：
    - ↑/↓ 或 k/j: 移动选择
    - Enter: 确认选择
    - Esc: 取消
    """

    def __init__(self) -> None:
        self._state = SelectionMenuState()
        self._on_confirm: Callable[[str], None] | None = None
        self._on_cancel: Callable[[], None] | None = None

        self._title_control = FormattedTextControl(text=self._title_fragments)
        self._options_control = FormattedTextControl(text=self._options_fragments)

        self._title_window = Window(
            content=self._title_control,
            height=1,
            dont_extend_height=True,
            style="class:selection.title",
        )
        self._options_window = Window(
            content=self._options_control,
            wrap_lines=Condition(lambda: self._state.line_wrap),
            dont_extend_height=False,
            style="class:selection.body",
            always_hide_cursor=True,
        )

        self._root = HSplit(
            [
                self._title_window,
                Window(height=1, char="─", style="class:selection.divider"),
                self._options_window,
            ]
        )

    @property
    def container(self) -> HSplit:
        return self._root

    def set_options(
        self,
        title: str,
        options: list[dict[str, str]],
        on_confirm: Callable[[str], None] | None = None,
        on_cancel: Callable[[], None] | None = None,
        *,
        page_size: int | None = None,
        item_gap_lines: int = 0,
        wrap_navigation: bool = True,
        description_selected_only: bool = False,
        line_wrap: bool = True,
        layout_mode: Literal["stacked", "inline"] = "stacked",
        inline_total_width: int | None = None,
        inline_name_min_width: int = 12,
        inline_name_max_width: int = 28,
        inline_gap_spaces: int = 2,
        context_lines: list[str] | None = None,
    ) -> bool:
        """设置选项。

        Args:
            title: 菜单标题
            options: 选项列表，每个选项为 {"value": "xxx", "label": "显示文本", "description": "描述"}
            on_confirm: 确认回调，参数为选中的 value
            on_cancel: 取消回调

        Returns:
            是否成功设置（至少有一个有效选项）
        """
        parsed_options: list[SelectionOption] = []
        for opt in options:
            if not isinstance(opt, dict):
                continue
            value = str(opt.get("value", "")).strip()
            label = str(opt.get("label", "")).strip()
            if not value or not label:
                continue
            description = str(opt.get("description", "")).strip()
            parsed_options.append(SelectionOption(value=value, label=label, description=description))

        if not parsed_options:
            return False

        self._state.title = title
        self._state.options = parsed_options
        self._state.selected_index = 0
        total = len(parsed_options)
        if page_size is None:
            normalized_page_size = total
        else:
            normalized_page_size = max(1, int(page_size))
            normalized_page_size = min(normalized_page_size, total)
        self._state.page_size = normalized_page_size
        self._state.item_gap_lines = max(0, int(item_gap_lines))
        self._state.viewport_start = 0
        self._state.wrap_navigation = bool(wrap_navigation)
        self._state.description_selected_only = bool(description_selected_only)
        self._state.line_wrap = bool(line_wrap)
        self._state.layout_mode = (
            layout_mode if layout_mode in {"stacked", "inline"} else "stacked"
        )
        self._state.inline_total_width = (
            int(inline_total_width) if inline_total_width is not None else None
        )
        self._state.inline_name_min_width = max(4, int(inline_name_min_width))
        self._state.inline_name_max_width = max(
            self._state.inline_name_min_width,
            int(inline_name_max_width),
        )
        self._state.inline_gap_spaces = max(1, int(inline_gap_spaces))
        self._state.context_lines = [str(line) for line in (context_lines or [])]
        self._state.is_confirmed = False
        self._state.is_cancelled = False
        self._on_confirm = on_confirm
        self._on_cancel = on_cancel
        return True

    def clear(self) -> None:
        """清除状态。"""
        self._state = SelectionMenuState()
        self._on_confirm = None
        self._on_cancel = None

    def has_options(self) -> bool:
        """是否有选项。"""
        return bool(self._state.options)

    def move_selection(self, delta: int) -> None:
        """移动选择。"""
        if not self._state.options:
            return
        count = len(self._state.options)
        if self._state.wrap_navigation:
            self._state.selected_index = (self._state.selected_index + delta) % count
        else:
            self._state.selected_index = max(
                0,
                min(self._state.selected_index + delta, count - 1),
            )
        self._ensure_selected_visible()

    def confirm(self) -> SelectionResult | None:
        """确认当前选择。

        Returns:
            选择结果，如果没有选项则返回 None
        """
        if not self._state.options:
            return None

        option = self._state.options[self._state.selected_index]
        self._state.is_confirmed = True

        if self._on_confirm:
            self._on_confirm(option.value)

        return SelectionResult(confirmed=True, value=option.value, label=option.label)

    def cancel(self) -> SelectionResult:
        """取消选择。

        Returns:
            取消结果
        """
        self._state.is_cancelled = True

        if self._on_cancel:
            self._on_cancel()

        return SelectionResult(confirmed=False)

    def get_selected(self) -> SelectionOption | None:
        """获取当前选中的选项。"""
        if not self._state.options:
            return None
        return self._state.options[self._state.selected_index]

    def _title_fragments(self) -> list[tuple[str, str]]:
        if not self._state.title:
            return [("class:selection.title", "  Select an option")]
        return [("class:selection.title", f"  {self._state.title}")]

    def _options_fragments(self) -> list[tuple[str, str]]:
        if not self._state.options:
            return [("class:selection.body", "  No options available")]

        fragments: list[tuple[str, str]] = []
        if self._state.context_lines:
            for raw_line in self._state.context_lines:
                line = str(raw_line)
                if line:
                    fragments.append(("class:selection.description", f"  {line}"))
                else:
                    fragments.append(("", ""))
                fragments.append(("", "\n"))
            fragments.append(("", "\n"))

        options_count = len(self._state.options)
        page_size = self._normalized_page_size()
        max_start = max(0, options_count - page_size)
        start = min(max(self._state.viewport_start, 0), max_start)
        end = min(options_count, start + page_size)

        for idx in range(start, end):
            option = self._state.options[idx]
            is_selected = idx == self._state.selected_index
            cursor = "▶" if is_selected else " "
            marker = "●" if is_selected else "○"

            line_style = "class:selection.option.selected" if is_selected else "class:selection.option"
            desc_style = "class:selection.description.selected" if is_selected else "class:selection.description"

            if self._state.layout_mode == "inline":
                fragments.append(
                    (
                        line_style,
                        self._inline_option_line(
                            option=option,
                            cursor=cursor,
                            marker=marker,
                        ),
                    )
                )
                fragments.append(("", "\n"))
            else:
                # 主选项行
                fragments.append((line_style, f"  {cursor} {marker} {option.label}"))
                fragments.append(("", "\n"))

                # 描述行（如果有）
                should_show_description = option.description and (
                    not self._state.description_selected_only or is_selected
                )
                if should_show_description:
                    fragments.append((desc_style, f"      {option.description}"))
                    fragments.append(("", "\n"))

            if idx < end - 1:
                for _ in range(self._state.item_gap_lines):
                    fragments.append(("", "\n"))

        # 底部提示
        fragments.append(("", "\n"))
        if options_count > page_size:
            fragments.append(
                (
                    "class:selection.hint",
                    f"  Showing {start + 1}-{end}/{options_count}",
                )
            )
            fragments.append(("", "\n"))
        fragments.append(
            ("class:selection.hint", "  ↑/↓ or k/j: Move  Enter: Confirm  Esc: Cancel")
        )
        return fragments

    def _inline_option_line(
        self,
        *,
        option: SelectionOption,
        cursor: str,
        marker: str,
    ) -> str:
        total_width = max(20, int(self._state.inline_total_width or 100))
        prefix = f"  {cursor} {marker} "
        prefix_width = get_cwidth(prefix)
        content_width = max(8, total_width - prefix_width)

        gap_width = max(1, int(self._state.inline_gap_spaces))
        name_min = max(4, int(self._state.inline_name_min_width))
        name_max = max(name_min, int(self._state.inline_name_max_width))
        name_width = min(name_max, max(name_min, content_width // 3))

        if option.description and (content_width - name_width - gap_width) < 8:
            name_width = max(4, content_width - gap_width - 8)
        name_width = max(4, min(name_width, content_width))

        desc_width = max(0, content_width - name_width - gap_width)
        name_text = fit_single_line(option.label, name_width)
        name_padding = " " * max(0, name_width - get_cwidth(name_text))

        if desc_width <= 0:
            return fit_single_line(f"{prefix}{name_text}", total_width)

        description = option.description.strip()
        desc_text = fit_single_line(description, desc_width) if description else ""
        if desc_text:
            return f"{prefix}{name_text}{name_padding}{' ' * gap_width}{desc_text}"
        return f"{prefix}{name_text}{name_padding}"

    def _normalized_page_size(self) -> int:
        options_count = len(self._state.options)
        if options_count <= 0:
            return 0
        return max(1, min(self._state.page_size or options_count, options_count))

    def _ensure_selected_visible(self) -> None:
        options_count = len(self._state.options)
        if options_count <= 0:
            self._state.viewport_start = 0
            return

        page_size = self._normalized_page_size()
        if page_size >= options_count:
            self._state.viewport_start = 0
            return

        selected = max(0, min(self._state.selected_index, options_count - 1))
        start = self._state.viewport_start
        end = start + page_size - 1
        if selected < start:
            start = selected
        elif selected > end:
            start = selected - page_size + 1

        max_start = max(0, options_count - page_size)
        self._state.viewport_start = min(max(start, 0), max_start)

    def refresh(self) -> None:
        """刷新显示（触发重绘）。"""
        self._title_control.text = self._title_fragments
        self._options_control.text = self._options_fragments

    def focus_target(self) -> Window:
        """获取焦点目标窗口。"""
        return self._options_window

    def __pt_formatted_text__(self) -> list[tuple[str, str]]:
        """支持直接作为 formatted text 使用。"""
        return self._options_fragments()


# 便捷函数：创建模型级别选择菜单
def create_model_level_menu(
    current_level: str | None,
    llm_levels: dict[str, Any] | None,
    on_confirm: Callable[[str], None],
    on_cancel: Callable[[], None],
) -> SelectionMenuUI:
    """创建模型级别选择菜单。

    Args:
        current_level: 当前级别 (LOW/MID/HIGH)
        llm_levels: LLM 级别配置字典，包含实际的模型实例
        on_confirm: 确认回调
        on_cancel: 取消回调

    Returns:
        配置好的 SelectionMenuUI 实例
    """
    ui = SelectionMenuUI()

    title, options = build_model_level_options(
        current_level=current_level or "MID",
        llm_levels=llm_levels,
    )

    ui.set_options(
        title=title,
        options=options,
        on_confirm=on_confirm,
        on_cancel=on_cancel,
    )
    return ui


def build_model_level_options(
    *,
    current_level: str,
    llm_levels: dict[str, Any] | None,
) -> tuple[str, list[dict[str, str]]]:
    def get_model_name(level: str) -> str:
        if llm_levels and level in llm_levels:
            llm = llm_levels[level]
            model = getattr(llm, "model", None)
            if model:
                return str(model)
        return "unknown"

    options = [
        {
            "value": "LOW",
            "label": "LOW  - Fast & Cheap",
            "description": f"{get_model_name('LOW')}",
        },
        {
            "value": "MID",
            "label": "MID  - Balanced",
            "description": f"{get_model_name('MID')}",
        },
        {
            "value": "HIGH",
            "label": "HIGH - Best Quality",
            "description": f"{get_model_name('HIGH')}",
        },
    ]

    normalized = current_level.upper().strip() or "MID"
    for opt in options:
        if opt["value"] == normalized:
            opt["label"] = f"{opt['label']}  (current)"
            break

    return "Select Model Level", options
