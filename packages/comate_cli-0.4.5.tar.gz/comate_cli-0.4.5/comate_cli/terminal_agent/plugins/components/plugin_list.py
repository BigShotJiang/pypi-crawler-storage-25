"""Plugin picker 列表组件。

纯状态 + formatted text 渲染，支持导航、多选、viewport 滚动。
"""

from __future__ import annotations


class PluginListControl:
    """插件列表：支持上下导航、多选、viewport 滚动。

    渲染为 prompt_toolkit style tuples，由上层 layout 消费。
    """

    def __init__(
        self,
        items: list[dict] | None = None,
    ) -> None:
        self._items: list[dict] = list(items) if items else []
        self._selected_index = 0
        self._selected_items: set[int] = set()

    @property
    def items(self) -> list[dict]:
        return self._items

    @items.setter
    def items(self, value: list[dict]) -> None:
        self._items = list(value) if value else []
        self._selected_index = 0
        self._selected_items.clear()

    @property
    def selected_index(self) -> int:
        return self._selected_index

    @property
    def selected_items(self) -> set[int]:
        return self._selected_items

    def move_down(self) -> None:
        """向下移动（循环）。"""
        if self._items:
            self._selected_index = (self._selected_index + 1) % len(self._items)

    def move_up(self) -> None:
        """向上移动（循环）。"""
        if self._items:
            self._selected_index = (self._selected_index - 1) % len(self._items)

    def toggle_select(self) -> None:
        """切换当前项的选中状态。"""
        if not self._items:
            return
        idx = self._selected_index
        if idx in self._selected_items:
            self._selected_items.discard(idx)
        else:
            self._selected_items.add(idx)

    def get_selected_items(self) -> list[dict]:
        """返回所有被选中的 item 数据。"""
        return [self._items[i] for i in sorted(self._selected_items) if i < len(self._items)]

    def get_current_item(self) -> dict | None:
        """返回当前光标所在的 item。"""
        if not self._items:
            return None
        return self._items[self._selected_index]

    def get_formatted_text(
        self,
        viewport_height: int = 16,
        max_width: int = 120,
    ) -> list[tuple[str, str]]:
        """返回 prompt_toolkit style tuples。

        渲染 viewport 窗口内的条目，每项两行：
        - 第一行：cursor + checkbox + 名称 · marketplace
        - 第二行：描述（缩进，超长截断）

        viewport 跟随光标滚动，光标尽量保持在中间位置。
        """
        if not self._items:
            return [("class:plugin.empty", "  No plugins found")]

        items_per_viewport = max(1, viewport_height // 2)
        half = items_per_viewport // 2
        viewport_start = max(0, self._selected_index - half)
        viewport_end = viewport_start + items_per_viewport
        if viewport_end > len(self._items):
            viewport_end = len(self._items)
            viewport_start = max(0, viewport_end - items_per_viewport)

        fragments: list[tuple[str, str]] = []

        if viewport_start > 0:
            fragments.append(("class:plugin.scroll-hint", "  ↑ more above"))
            fragments.append(("", "\n"))

        for idx in range(viewport_start, viewport_end):
            item = self._items[idx]
            is_cursor = idx == self._selected_index
            is_selected = idx in self._selected_items
            is_installed = item.get("installed", False)

            cursor = "> " if is_cursor else "  "

            if is_installed:
                checkbox_style = "class:plugin.checkbox.installed"
                checkbox = "(*)"
            elif is_selected:
                checkbox_style = "class:plugin.checkbox.selected"
                checkbox = "(x)"
            else:
                checkbox_style = "class:plugin.checkbox"
                checkbox = "( )"

            name = item.get("name", "unknown")
            marketplace = item.get("marketplace", "")

            name_style = "class:plugin.name.cursor" if is_cursor else "class:plugin.name"
            fragments.append(("bold" if is_cursor else "", cursor))
            fragments.append((checkbox_style, checkbox))
            fragments.append(("", " "))
            fragments.append((name_style, name))
            if marketplace:
                fragments.append(("class:plugin.separator", " · "))
                fragments.append(("class:plugin.marketplace", marketplace))
            fragments.append(("", "\n"))

            description = item.get("description", "")
            if description:
                indent = "      "
                max_desc = max_width - len(indent)
                if len(description) > max_desc:
                    description = description[: max_desc - 3] + "..."
                fragments.append(("class:plugin.description", f"{indent}{description}"))
                fragments.append(("", "\n"))

        if viewport_end < len(self._items):
            fragments.append(("class:plugin.scroll-hint", "  ↓ more below"))
            fragments.append(("", "\n"))

        return fragments
