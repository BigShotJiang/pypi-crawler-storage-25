"""MCP Server 重连面板 — 轻量级 TUI 组件。

显示连接进度，支持 Esc 取消，20 秒超时。
完成后通过 on_done 回调通知调用方。
"""

from __future__ import annotations

import asyncio
import logging

from prompt_toolkit.application.current import get_app_or_none
from prompt_toolkit.layout.containers import Window
from prompt_toolkit.layout.controls import FormattedTextControl

logger = logging.getLogger(__name__)

_PANEL_HEIGHT = 8

_H = "\u2500"  # ─
_TL = "\u256d"  # ╭
_TR = "\u256e"  # ╮
_BL = "\u2570"  # ╰
_BR = "\u256f"  # ╯
_V = "\u2502"  # │

_CONNECT_TIMEOUT_S = 20.0


class McpConnectingView:
    """轻量 MCP 重连面板，嵌入主 TUI 底部交互带。"""

    def __init__(self) -> None:
        self._alias: str = ""
        self._task: asyncio.Task[None] | None = None
        self._on_done: callable | None = None
        self._retry_coro = None

        self._content_window = Window(
            content=FormattedTextControl(self._render, focusable=True),
            height=_PANEL_HEIGHT,
            dont_extend_height=True,
            always_hide_cursor=True,
        )

    @property
    def container(self) -> Window:
        return self._content_window

    def focus_target(self) -> Window:
        return self._content_window

    def enter(
        self,
        alias: str,
        retry_coro,
        on_done: callable,
    ) -> None:
        """初始化并启动连接。"""
        self._alias = alias
        self._retry_coro = retry_coro
        self._on_done = on_done
        self._task = asyncio.create_task(self._do_connect())
        self._task.add_done_callback(self._on_task_done)

    def handle_escape(self) -> bool:
        """Esc 取消连接。返回 True 表示面板应关闭。"""
        if self._task and not self._task.done():
            self._task.cancel()
        return True

    async def _do_connect(self) -> None:
        try:
            result = await asyncio.wait_for(
                self._retry_coro,
                timeout=_CONNECT_TIMEOUT_S,
            )
            if result:
                self._on_done(True, "")
            else:
                self._on_done(False, "connection failed")
        except asyncio.TimeoutError:
            self._on_done(False, f"timed out after {int(_CONNECT_TIMEOUT_S)}s")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            self._on_done(False, str(exc))

    def _on_task_done(self, task: asyncio.Task[None]) -> None:
        self._task = None
        app = get_app_or_none()
        if app is not None:
            app.invalidate()

    def _render(self) -> list[tuple[str, str]]:
        app = get_app_or_none()
        width = 80
        if app is not None:
            try:
                width = app.output.get_size().columns
            except Exception:
                pass
        inner_w = max(20, width - 4)

        lines: list[list[tuple[str, str]]] = []
        lines.append([("bold", f"Connecting to {self._alias}\u2026")])
        lines.append([])
        lines.append([("class:dim", " \u273d Establishing connection to MCP server")])
        lines.append([])
        lines.append([("class:dim", " This may take a few moments.")])

        content_lines = _PANEL_HEIGHT - 3
        while len(lines) < content_lines:
            lines.append([])

        fragments: list[tuple[str, str]] = []

        fragments.append(("class:plugin.divider", f"{_TL}{_H * (width - 2)}{_TR}"))
        fragments.append(("", "\n"))

        for line_frags in lines[:content_lines]:
            fragments.append(("class:plugin.divider", f"{_V} "))
            line_len = sum(len(text) for _, text in line_frags)
            for style, text in line_frags:
                fragments.append((style, text))
            pad = inner_w - line_len
            if pad > 0:
                fragments.append(("", " " * pad))
            fragments.append(("class:plugin.divider", f" {_V}"))
            fragments.append(("", "\n"))

        fragments.append(("class:plugin.divider", f"{_BL}{_H * (width - 2)}{_BR}"))
        fragments.append(("", "\n"))

        fragments.append(("class:dim", "   Esc to cancel"))

        return fragments
