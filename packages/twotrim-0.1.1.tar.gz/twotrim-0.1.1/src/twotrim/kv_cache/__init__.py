"""KV cache optimization module."""
