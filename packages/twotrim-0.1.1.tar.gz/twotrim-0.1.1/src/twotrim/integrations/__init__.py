"""OSS integration layer module."""
