"""Response compression module."""
