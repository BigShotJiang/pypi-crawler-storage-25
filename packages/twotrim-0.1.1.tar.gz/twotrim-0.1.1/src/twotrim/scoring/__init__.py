"""Token importance scoring module."""
