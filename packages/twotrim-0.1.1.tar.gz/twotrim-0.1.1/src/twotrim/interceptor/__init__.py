"""Universal LLM interceptor module."""
