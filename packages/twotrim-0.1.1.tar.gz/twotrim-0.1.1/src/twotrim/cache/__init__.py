"""Global cache fabric module."""
