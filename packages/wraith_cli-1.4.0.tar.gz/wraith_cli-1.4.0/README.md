[![Documentation](https://img.shields.io/badge/docs-live-brightgreen)](https://www.thomaspeoples.com/gitea-repos/wraith-cli/)
![PyPI - Version](https://img.shields.io/pypi/v/wraith-cli)
![PyPI - License](https://img.shields.io/pypi/l/wraith-cli)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/wraith-cli)


# 👻 Wraith-CLI
### *Sovereign Orchestration for the Ghost Stack*

**Wraith-CLI** is the nervous system of the Ghost Stack. It bridges the gap between
high-level container orchestration and bare-metal reality, providing the "Ghost Factory"
for instant project scaffolding.


---

## 🚀 Installation & Updates

**Wraith-CLI** is managed via `uv` for hermetic stability.

```bash
# Initial Installation
uv tool install wraith-cli

# Sovereign Update
wraith update
```

---

## 🔐 Environment Configuration

Defined in your `.env` or system environment. **HTTPS is required** for automated
Gitea provisioning.

| Variable               | Purpose                                          | Required For    |
|------------------------|--------------------------------------------------|-----------------|
| `GITEA_API_URL`        | Base URL (e.g., `https://git.domain.com`)        | `spawn`         |
| `GITEA_TOKEN`          | Personal Access Token (PAT)                      | `spawn`         |
| `GITEA_TEMPLATE_URL`   | HTTPS URL of your base `ghost-template`          | `spawn`         |
| `GITEA_COMPOSE_PATH`   | Path to Gitea Docker directory                   | `runner-reset`  |
| `VIKING_BASE_URL`      | API endpoint for heartbeat checks                | `status`        |
| `WRAITH_COMPOSE_PATH`  | Default path for stack logs/ps                   | `tail`, `ps`    |

---

## 🧪 Developer Quality Gate

We use `uv` for hermetic environment management and maintain a strict **>80% coverage**
requirement.

```bash
# Initialise the Environment
uv sync --all-extras
uv run pre-commit install

# The Quality Gate
uv run pytest --cov=src
```

---

## 📜 Sovereign Principles

1. **Distributed Sovereignty:** Available on PyPI for the world, but optimised for
   local-first, private-registry mirrors.
2. **Atomic Execution:** Use `uv run` to ensure consistency across the stack.
3. **Hardware First:** Prioritise bare-metal health and container stability over
   abstraction.
