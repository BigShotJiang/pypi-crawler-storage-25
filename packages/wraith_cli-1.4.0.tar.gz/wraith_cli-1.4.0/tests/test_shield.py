import json
import subprocess
from unittest.mock import Mock, patch

import pytest
import requests
from rich.table import Table

from wraith_cli.shield import (
    get_scrutiny_health,
    get_tailscale_mesh,
    run_security_audit,
)


@patch("wraith_cli.shield.requests.get")
def test_get_scrutiny_health_success(mock_get):
    """Test successful retrieval of Scrutiny health data."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "data": {
            "summary": {
                "WWN1": {
                    "device": {"name": "sda", "capacity": 10**12},
                    "smart": {"temp": 30, "status": "passed"},
                }
            }
        }
    }
    mock_response.raise_for_status.return_value = None
    mock_get.return_value = mock_response

    table = get_scrutiny_health()
    assert isinstance(table, Table)
    assert len(table.rows) == 1
    # Check rendered output of the first row
    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "sda"
    assert str(cells[1]) == "1.0 TB"
    assert str(cells[2]) == "30°C"
    assert "PASSED" in str(cells[3])


@patch("wraith_cli.shield.requests.get")
def test_get_scrutiny_health_no_devices(mock_get):
    """Test Scrutiny API returning no devices."""
    mock_response = Mock()
    mock_response.json.return_value = {"data": {"summary": {}}}
    mock_response.raise_for_status.return_value = None
    mock_get.return_value = mock_response

    table = get_scrutiny_health()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "No devices found."


@patch("wraith_cli.shield.requests.get")
def test_get_scrutiny_health_api_error(mock_get):
    """Test handling of a Scrutiny API request error."""
    mock_get.side_effect = requests.exceptions.RequestException("API down")

    table = get_scrutiny_health()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert "API Error: API down" in str(cells[0])


@patch("wraith_cli.shield.requests.get")
def test_get_scrutiny_health_missing_data(mock_get):
    """Test Scrutiny data with missing fields to check defaults."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "data": {
            "summary": {
                "WWN1": {
                    "device": {},
                    "smart": {"status": "failed"},
                }
            }
        }
    }
    mock_response.raise_for_status.return_value = None
    mock_get.return_value = mock_response

    table = get_scrutiny_health()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "Unknown"
    assert str(cells[1]) == "Unknown"
    assert str(cells[2]) == "N/A°C"
    assert "FAILED" in str(cells[3])


@patch("wraith_cli.shield.requests.get")
def test_get_scrutiny_health_missing_smart_data(mock_get):
    """Test Scrutiny data with missing 'smart' section."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "data": {
            "summary": {
                "WWN1": {
                    "device": {"name": "sdb", "capacity": 2 * 10**12},
                    # 'smart' key is entirely missing
                }
            }
        }
    }
    mock_response.raise_for_status.return_value = None
    mock_get.return_value = mock_response

    table = get_scrutiny_health()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "sdb"
    assert str(cells[1]) == "2.0 TB"
    assert str(cells[2]) == "N/A°C"
    assert "UNKNOWN" in str(cells[3])


@patch("wraith_cli.shield.subprocess.run")
def test_get_tailscale_mesh_success(mock_run):
    """Test successful retrieval of Tailscale mesh data."""
    mock_process = Mock()
    mock_process.stdout = json.dumps(
        {
            "Peer": {
                "peer1": {
                    "HostName": "node1",
                    "TailscaleIPs": ["100.64.0.1"],
                    "OS": "Linux",
                    "Online": True,
                },
                "peer2": {
                    "HostName": "node2",
                    "TailscaleIPs": ["100.64.0.2"],
                    "OS": "Windows",
                    "Online": False,
                },
            }
        }
    )
    mock_run.return_value = mock_process

    table = get_tailscale_mesh()
    assert len(table.rows) == 2

    # Check first row (online)
    cells1 = [list(col.cells)[0] for col in table.columns]
    assert str(cells1[0]) == "node1"
    assert str(cells1[1]) == "100.64.0.1"
    assert "Online" in str(cells1[3])

    # Check second row (offline)
    cells2 = [list(col.cells)[1] for col in table.columns]
    assert str(cells2[0]) == "node2"
    assert "Offline" in str(cells2[3])


@patch("wraith_cli.shield.subprocess.run")
def test_get_tailscale_mesh_generic_error(mock_run):
    """Test handling of a generic error when running tailscale command."""
    mock_run.side_effect = Exception("Generic error for tailscale")

    table = get_tailscale_mesh()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert "Mesh Error: Generic error for tailscale" in str(cells[0])


@patch("wraith_cli.shield.subprocess.run")
def test_get_tailscale_mesh_called_process_error(mock_run):
    """Test handling of subprocess.CalledProcessError for tailscale."""
    mock_run.side_effect = subprocess.CalledProcessError(1, ["tailscale"])

    table = get_tailscale_mesh()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert ("Error: Tailscale container not found or stopped"
            in str(cells[0]))


@patch("wraith_cli.shield.subprocess.run")
def test_get_tailscale_mesh_no_peers(mock_run):
    """Test Tailscale mesh when no peers are found."""
    mock_process = Mock()
    mock_process.stdout = json.dumps({"Peer": {}})  # Empty peers
    mock_run.return_value = mock_process

    table = get_tailscale_mesh()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "No peers found"
    assert "[yellow]Solo Node[/yellow]" in str(cells[3])


@patch("wraith_cli.shield.subprocess.run")
def test_get_tailscale_mesh_empty_ips(mock_run):
    """Test Tailscale mesh with empty TailscaleIPs list."""
    mock_process = Mock()
    mock_process.stdout = json.dumps(
        {
            "Peer": {
                "peer1": {
                    "HostName": "node1",
                    "TailscaleIPs": [],  # Empty IPs
                    "OS": "Linux",
                    "Online": True,
                }
            }
        }
    )
    mock_run.return_value = mock_process

    table = get_tailscale_mesh()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "node1"
    assert str(cells[1]) == "Unknown"
    assert str(cells[2]) == "Linux"
    assert "Online" in str(cells[3])


@patch("wraith_cli.shield.subprocess.run")
def test_get_tailscale_mesh_malformed_json(mock_run):
    """Test Tailscale mesh with malformed JSON output."""
    mock_process = Mock()
    mock_process.stdout = "this is not json"
    mock_run.return_value = mock_process

    table = get_tailscale_mesh()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert "Mesh Error: Expecting value" in str(cells[0])


@patch("wraith_cli.shield.subprocess.run")
def test_run_security_audit_no_containers(mock_run):
    """Test security audit when no containers are running."""
    mock_ps_result = Mock(stdout="")
    mock_run.return_value = mock_ps_result

    table = run_security_audit()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "No running containers."


def mock_container_inspect(user, ports):
    """Helper to create a mock container inspect JSON."""
    config_data = {}
    if user is not None:
        config_data["User"] = user
    return {
        "Name": "/test-container",
        "Config": config_data,
        "NetworkSettings": {"Ports": ports},
    }


@pytest.mark.parametrize(
    "user, ports, expected_user, expected_ports, expected_verdict",
    [
        (
            "root",
            {"80/tcp": [{"HostIp": "0.0.0.0", "HostPort": "8080"}]},
            "[red]ROOT[/red]",
            "[yellow]8080->80/tcp (Global)[/yellow]",
            "CRITICAL",
        ),
        (
            "0",
            {"80/tcp": [{"HostIp": "", "HostPort": "8080"}]},
            "[red]ROOT[/red]",
            "[yellow]8080->80/tcp (Global)[/yellow]",
            "CRITICAL",
        ),
        (
            "",
            {"80/tcp": [{"HostIp": "127.0.0.1", "HostPort": "8080"}]},
            "[red]ROOT[/red]",
            "8080->80/tcp",
            "WARNING: Root Context",
        ),
        (
            "testuser",
            {"80/tcp": [{"HostIp": "0.0.0.0", "HostPort": "8080"}]},
            "[green]testuser[/green]",
            "[yellow]8080->80/tcp (Global)[/yellow]",
            "WARNING: Global Exposure",
        ),
        (
            "testuser",
            {"80/tcp": [{"HostIp": "127.0.0.1", "HostPort": "8080"}]},
            "[green]testuser[/green]",
            "8080->80/tcp",
            "SECURE",
        ),
        ("testuser", {}, "[green]testuser[/green]", "Internal Only", "SECURE"),
        (
            None,  # Simulate missing 'User' key in Config
            {"80/tcp": [{"HostIp": "127.0.0.1", "HostPort": "8080"}]},
            "[red]ROOT[/red]",
            "8080->80/tcp",
            "WARNING: Root Context",
        ),
    ],
)
@patch("wraith_cli.shield.subprocess.run")
def test_run_security_audit_scenarios(
    mock_run, user, ports, expected_user, expected_ports, expected_verdict
):
    """Test various security audit scenarios for containers."""
    mock_ps_result = Mock(stdout="container1\n")
    inspect_json = json.dumps([mock_container_inspect(user, ports)])
    mock_inspect_result = Mock(stdout=inspect_json)

    # Side effect to handle two different calls to subprocess.run
    mock_run.side_effect = [mock_ps_result, mock_inspect_result]

    table = run_security_audit()
    assert len(table.rows) == 1

    cells = [list(col.cells)[0] for col in table.columns]
    assert str(cells[0]) == "test-container"
    assert str(cells[1]) == expected_user
    assert str(cells[2]) == expected_ports
    assert expected_verdict in str(cells[3])


@patch("wraith_cli.shield.subprocess.run")
def test_run_security_audit_error(mock_run):
    """Test handling of an error during the security audit."""
    mock_run.side_effect = Exception("Docker not running")

    table = run_security_audit()
    assert len(table.rows) == 1
    cells = [list(col.cells)[0] for col in table.columns]
    assert "Audit Error: Docker not running" in str(cells[0])
