from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import requests

from wraith_cli import repo_make


def test_create_gitea_repo_success():
    with patch("requests.post") as mock_post:
        mock_resp = MagicMock()
        # Mocking both; the new logic priorities clone_url (HTTPS)
        mock_resp.json.return_value = {
            "clone_url": "https://gitea.local/test/repo.git",
            "ssh_url": "git@gitea.local:test/repo.git",
        }
        mock_resp.raise_for_status.return_value = None
        mock_post.return_value = mock_resp

        url = repo_make.create_gitea_repo(
            "test-repo", "http://gitea", "token123"
        )
        # Verify it picks the HTTPS URL
        assert url == "https://gitea.local/test/repo.git"
        mock_post.assert_called_once()


def test_create_gitea_repo_failure():
    with patch("requests.post") as mock_post:
        mock_post.side_effect = requests.exceptions.HTTPError(
            "401 Unauthorized"
        )
        with pytest.raises(requests.exceptions.HTTPError):
            repo_make.create_gitea_repo(
                "test-repo", "http://gitea", "bad-token"
            )


def test_clone_and_bleach_success(tmp_path):
    target = tmp_path / "new-repo"

    with patch("subprocess.run") as mock_run:

        def side_effect(*args, **kwargs):
            target.mkdir(parents=True, exist_ok=True)
            (target / ".git").mkdir()
            return MagicMock(returncode=0)

        mock_run.side_effect = side_effect

        # Added token123 to match new signature
        result = repo_make.clone_and_bleach(
            "https://template.git", target, "token123"
        )

        assert result is True
        assert target.exists()
        assert not (target / ".git").exists()  # Bleach successful


def test_clone_and_bleach_exists_error(tmp_path):
    target = tmp_path / "existing-dir"
    target.mkdir()  # Make it exist beforehand

    with pytest.raises(FileExistsError):
        # Added token123 to match new signature
        repo_make.clone_and_bleach("https://template.git", target, "token123")


def test_clone_and_bleach_http_url(tmp_path):
    """Test clone_and_bleach with an http URL to cover auth injection."""
    target = tmp_path / "new-repo"
    with patch("subprocess.run") as mock_run:

        def side_effect(*args, **kwargs):
            # Simulate git clone creating the directory
            target.mkdir()
            (target / ".git").mkdir()
            return MagicMock(returncode=0)

        mock_run.side_effect = side_effect

        repo_make.clone_and_bleach("http://template.git", target, "token123")

        # Check that git clone was called with the authenticated URL
        called_cmd = mock_run.call_args[0][0]
        assert "http://oauth2:token123@template.git" in called_cmd


def test_init_and_push():
    target = Path("/fake/dir")
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0)

        # Added token123 to match new signature
        result = repo_make.init_and_push(
            target, "https://remote.git", "token123"
        )

        assert result is True
        assert mock_run.call_count == 6  # 6 git commands run


def test_init_and_push_http_url():
    """Test init_and_push with an http URL to cover auth injection."""
    target = Path("/fake/dir")
    with patch("subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0)

        repo_make.init_and_push(target, "http://remote.git", "token123")

        # git remote add is the 5th command
        remote_add_cmd = mock_run.call_args_list[4].args[0]
        assert "http://oauth2:token123@remote.git" in remote_add_cmd
