from unittest.mock import patch

import requests

from wraith_cli import qol


def test_get_latest_version_success():
    with patch("requests.get") as mock_get:
        mock_get.return_value.json.return_value = {
            "info": {"version": "2.0.0"}
        }
        assert qol.get_latest_version() == "2.0.0"


def test_format_docker_table_empty():
    table = qol.format_docker_table("")
    assert len(table.rows) == 0


@patch("subprocess.run")
def test_run_tail_execution(mock_run, tmp_path):
    # Setup a dummy docker-compose file
    d_file = tmp_path / "docker-compose.yml"
    d_file.touch()

    qol.run_tail("nginx", tmp_path)
    mock_run.assert_called_once()


def test_get_latest_version_failure():
    # Use side_effect to raise an error, not return a value
    with patch(
        "requests.get", side_effect=requests.exceptions.ConnectionError
    ):
        assert qol.get_latest_version() == "0.0.0"


def test_run_tail_no_file(tmp_path):
    # Tests the "if not docker_file.exists()" block
    # Pass a directory that exists but does not contain a docker-compose.yml
    success = qol.run_tail("nginx", tmp_path)
    assert success is False


@patch("subprocess.run")
def test_update_command_already_current(mock_run):
    # This helps cover the logic in main.py where local == remote
    from typer.testing import CliRunner

    from wraith_cli.main import app

    runner = CliRunner()

    with patch("wraith_cli.qol.get_latest_version", return_value="1.1.0"):
        with patch("importlib.metadata.version", return_value="1.1.0"):
            result = runner.invoke(app, ["update"])
            assert "up to date" in result.stdout
