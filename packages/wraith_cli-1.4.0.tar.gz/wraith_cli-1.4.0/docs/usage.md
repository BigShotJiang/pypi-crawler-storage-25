# CLI

Wraith Sovereign CLI: Ghost Stack Orchestrator

**Usage**:

```console
$ [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--version`: Show version and exit.
* `--install-completion`: Install completion for the current shell.
* `--show-completion`: Show completion for the current shell, to copy it or customize the installation.
* `--help`: Show this message and exit.

**Commands**:

* `status`: Check the heartbeat of the OpenViking Stack.
* `update`: Sync Wraith with the latest PyPI release.
* `ps`: List running containers with Sovereign...
* `tail`: Stream live logs from a specific service.
* `runner-reset`: Repair hung or offline Gitea Action Runners.
* `spawn`: 🏭 Scaffold a new repository instantly.
* `logs`: Unified hardware health and logging portal.
* `mesh`: Map the Tailscale Ghost Mesh network.
* `audit`: Execute a Sovereign security and...

## `status`

Check the heartbeat of the OpenViking Stack.

 Polls the configured VIKING_BASE_URL health
nendpoint to verify if the orchestrator API is responsive.

**Usage**:

```console
$ status [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.

## `update`

Sync Wraith with the latest PyPI release.

Compares local versioning against the remote registry and
automatically triggers an upgrade via &#x27;uv tool&#x27; if a newer
version is detected.

**Usage**:

```console
$ update [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.

## `ps`

List running containers with Sovereign styling.

Wraps &#x27;docker ps&#x27; to provide a high-contrast,
readable table summarising service names,
container status, and source images.

**Usage**:

```console
$ ps [OPTIONS]
```

**Options**:

* `-a, --all`: Show all containers
* `--help`: Show this message and exit.

## `tail`

Stream live logs from a specific service.

Connects to a running container to output real-time logs.
Resolves Compose paths via CLI flags,
environment variables, or local directory discovery.

Priority:
   1. Passed flag --path
   2. Env Var WRAITH_COMPOSE_PATH
   3. Current Directory

**Usage**:

```console
$ tail [OPTIONS] SERVICE
```

**Arguments**:

* `SERVICE`: Service name (e.g., ollama, gitea)  [required]

**Options**:

* `-p, --path PATH`: Path to directory with docker-compose.yml.  [env var: WRAITH_COMPOSE_PATH]
* `--help`: Show this message and exit.

## `runner-reset`

Repair hung or offline Gitea Action Runners.

Performs a nuclear reset: stops the container,
purges the local registration data, and restarts
the service to force a fresh handshake with Gitea.

Requires GITEA_COMPOSE_PATH as an envelope variable

**Usage**:

```console
$ runner-reset [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.

## `spawn`

🏭 Scaffold a new repository instantly.

Atomic scaffolding for new Ghost Stack repositories.
Clones a template, bleaches git history,
provisions a remote repository via API, and
pushes the initial commit in one sequence.

**Usage**:

```console
$ spawn [OPTIONS] REPO_NAME
```

**Arguments**:

* `REPO_NAME`: Name of the new Ghost Stack repository  [required]

**Options**:

* `--help`: Show this message and exit.

## `logs`

Unified hardware health and logging portal.

Default behavior provides log-tailing instructions.
Using the --health flag triggers a deep-dive query
into the Scrutiny API for SMART drive data and disk temps.

**Usage**:

```console
$ logs [OPTIONS]
```

**Options**:

* `--health`: Pull SMART data summary from Scrutiny API
* `--help`: Show this message and exit.

## `mesh`

Map the Tailscale Ghost Mesh network.

Interrogates the Tailscale daemon (local or containerised)
to return a list of active peers, their internal IPs, and
current online/offline status.

**Usage**:

```console
$ mesh [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.

## `audit`

Execute a Sovereign security and compliance scan.

Audits the running stack for common vulnerabilities, including
containers running with root privileges and exposed ports
that deviate from the Registry Spec.

**Usage**:

```console
$ audit [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.
