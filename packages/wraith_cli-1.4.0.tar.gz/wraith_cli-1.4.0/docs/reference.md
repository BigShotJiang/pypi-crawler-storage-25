# 🔩 Technical Reference

---

## 🏗️ Architecture

**Wraith** is engineered on **Python 3.12+**. Like its namesake, it is designed for silent, effortless power. It leverages a modern Sovereign stack:

| Concern            | Library      | Role                                                  |
|--------------------|--------------|-------------------------------------------------------|
| **Orchestration**  | `typer`      | CLI interface and command routing.                    |
| **Visuals**        | `rich`       | High-contrast terminal rendering and Markdown support.|
| **Package Mgmt**   | `uv`         | Lightning-fast, hermetic dependency locking.          |
| **Networking**     | `requests`   | Gitea API interactions.                               |
| **System**         | `subprocess` | Low-level Docker and Git execution.                   |

---

## 🧬 Modular Logic

The codebase is partitioned to ensure high testability and separation of concerns:

| Module        | Responsibility                                                          |
|---------------|-------------------------------------------------------------------------|
| `main.py`     | **The Switchboard.** CLI routing, UI splash, and env var loading.       |
| `repo_make.py`| **The Factory.** Gitea API calls and Git "Bleach & Push" logic.         |
| `qol.py`      | **Quality of Life.** Docker table formatting and version checks.        |

### 🔐 Authentication Logic

Wraith uses **HTTPS Token Injection** to bypass interactive password prompts. When a command requires Gitea access, the logic identifies the protocol and injects credentials as follows:

```
https://oauth2:{GITEA_TOKEN}@git.domain.com/repo.git
```

---

## 🚨 Error Codes & Troubleshooting

| Code     | Meaning                  | Resolution                                                     |
|----------|--------------------------|----------------------------------------------------------------|
| `0`      | Success                  | Command executed perfectly.                                    |
| `1`      | Configuration Error      | Missing `.env` variables or 404 API endpoint.                  |
| `128`    | Git / Auth Error         | Token invalid, or repository already exists on remote.         |
| `Abort`  | User Cancelled           | Triggered during `runner-reset` if requirements aren't met.    |

---

## 🧪 Test Suite & Quality Gate

We maintain a strict **Sovereign Quality Gate**. No code enters the main branch without passing the full suite.

- **Coverage Target:** >80%, strictly enforced via `pytest-cov`.
- **Engine:** `pytest` + `coverage.py`.
- **Mocking:** All network and `subprocess` calls must be mocked under `tests/` to
  permit offline, hermetic testing.

```bash
# Run the Gate locally
uv run pytest --cov=src --cov-report=term-missing
```
