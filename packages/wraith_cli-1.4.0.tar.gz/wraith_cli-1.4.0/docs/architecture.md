# 🏛️ Architecture & Decision Records

---

## 1. High-Level Design

Wraith follows a **Functional Core, Imperative Shell** pattern.

- **The Shell (`main.py`):** Handles the "dirty" work of CLI parsing, environment
  loading, and printing to `stdout`.
- **The Core (`repo_make.py`, `qol.py`):** Pure logic functions that perform the actual
  heavy lifting — API calls, Git operations, Docker formatting.

This separation ensures the core remains independently testable without invoking the
CLI layer, and that the shell stays thin enough to reason about at a glance.

---

## 2. ADR 001 — Tooling Selection

> **Status:** Accepted. These dependencies are intentional and should not be replaced
> without a corresponding ADR entry.

| Decision           | Choice    | Rationale                                                                                      |
|--------------------|-----------|------------------------------------------------------------------------------------------------|
| **CLI Framework**  | `typer`   | Native type-hint support. Built on Click but with significantly less boilerplate.              |
| **Package Manager**| `uv`      | Rust-based, hermetic, and fast. Replaces `pip`, `poetry`, and `venv` with a single binary.    |
| **Terminal Output**| `rich`    | First-class Markdown and table rendering. Essential for the Sovereign Dark aesthetic.          |
| **Testing**        | `pytest`  | Industry standard. Excellent `subprocess` mocking support for hermetic offline tests.          |

---

## 3. ADR 002 — Sovereign Security & Authentication

> **Status:** Accepted. Do not introduce persistent credential storage without
> revisiting this decision.

**Decision:** Environment-only credential configuration via `.env` or shell exports.

**Rejected alternative:** Storing Gitea credentials in a local SQLite database or
config file (e.g., `~/.wraith/config`).

**Rationale:** Keeps Wraith stateless between sessions. If a machine is compromised,
credentials are not sitting in a plaintext config file — they vanish when the shell
session ends. The attack surface is the user's environment, not Wraith's own storage.

---

## 4. The Quality Gate

We treat **type hints** as a functional requirement, not a suggestion. Because `typer`
relies on Python 3.12+ annotations to construct its CLI interface, a type error is a
runtime bug — not a style violation.

### Static Analysis — Ruff

All code is linted and formatted via `ruff` in opinionated mode, enforced at commit
time via `pre-commit`. This covers style, import ordering, and security anti-patterns
in a single pass.

### Type Integrity

Type annotations are enforced strictly. Functions accepting a `Path` must not receive
a `str`; optional environment variables must be handled as `Optional[str]`, not assumed
present.

### Test Coverage — pytest

We maintain a strict **>80% coverage gate**, with all network and `subprocess` calls
mocked for offline, hermetic execution.

```bash
# The Lead Engineer's Pre-Flight Check
uv run ruff check .      # Linting & security anti-patterns
uv run ruff format .     # Consistency
uv run pytest --cov=src  # Logical integrity & coverage gate
```

---

## 5. Future Roadmap

| Path | Codename            | Description                                                                 |
|------|---------------------|-----------------------------------------------------------------------------|
| 3    | **Ghost Watcher**   | Background daemon to monitor stack health via `status` and auto-restart failed runners. |
| 4    | **Sovereign UI**    | `textual`-based TUI for real-time stack dashboarding.                       |
