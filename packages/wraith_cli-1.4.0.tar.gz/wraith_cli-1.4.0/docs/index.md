# Wraith CLI

![Coverage](coverage.svg)
![PyPI - Version](https://img.shields.io/pypi/v/wraith_cli)

---

--8<-- "README.md"
