# 🛡️ Security Policy

---

## 1. The Sovereign Security Model

**Wraith** operates as the nervous system of your stack. Because it handles Personal Access Tokens (PATs) and interacts with Docker sockets, it must be treated as a **High-Privilege Utility**.

> ⚠️ **This software is provided as-is, without warranty of any kind.** Use in production environments is at your own risk. No support, patches, or security updates are guaranteed.

### 🔐 Credential Handling

- **No Persistence:** Wraith does *not* store tokens in its own configuration database. It reads them from the environment (`.env` or shell exports) at runtime.
- **Memory Safety:** Tokens are used to construct authenticated URLs for Git subprocesses and are not logged to `stdout` or `stderr`.
- **HTTPS Enforcement:** All Ghost Factory operations require `https://` to ensure tokens are encrypted in transit.

> ⚠️ **Be aware:** On shared hardware, `git clone` URLs containing injected tokens can briefly appear in the system process list (e.g., `ps aux`). See [§3 Hardening](#3-hardening-your-installation) for mitigation.

---

## 2. Reporting a Vulnerability

If you discover a security issue, you are welcome to open a **private Gitea issue** or contact the maintainer directly. However, **no response timeline or resolution is guaranteed.** This project is maintained by a single human puppeteer, on their own terms.

---

## 3. Hardening Your Installation

You downloaded it. You ran it. That makes it your stack now, here's how to keep it clean.

### Token Hygiene
- **Scope minimally:** Your `GITEA_TOKEN` should carry only the permissions Wraith needs, typically repository read/write. Do not use an admin-scoped token.
- **Rotate regularly:** Treat PATs like passwords. Rotate on a schedule or immediately following any suspected exposure.
- **Never commit tokens:** Ensure `.env` is listed in `.gitignore`. The Ghost Factory will not protect you from a pushed credential.

### Environment Isolation
- Do not run Wraith in environments where `ps aux` or the process environment is visible to untrusted users.
- Prefer user-scoped shell exports over project-level `.env` files on shared systems.

### Subprocess Awareness
- Token-injected URLs (e.g., `https://oauth2:{token}@git.domain.com/repo.git`) are passed directly to `git` subprocesses. On shared hardware, these may be transiently visible in the process list.
- On security-sensitive hosts, consider a **netrc-based credential helper** as an alternative to URL injection, which keeps the token out of the process argument list entirely.
