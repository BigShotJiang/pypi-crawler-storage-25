# 👻 Contributing to the Wraith CLI

This project is a UV-first, bleached repository. We prioritise local sovereignty, minimal VRAM footprints, and automated Gitea CI/CD.

## 🏗️ The Engineering Stack
 * Runtime/Registry: uv
 * VCS / Identity: Gitea + OIDC Provider
 * Automation: Gitea Actions + Commitizen (.cz.yaml)
 * AI Logic: Local Core (Qwen 3.5 0.8b) compatible

## 🚀 Local Development Setup
We do not use pip. All environments must be managed via uv to ensure architectural parity with the Ghost Stack.

```bash
# Clone from the Gitea Mesh:
git clone https://git.thomaspeoples.com/thomaspeoples/wraith-cli.git
cd wraith-cli

# Initialise the Hermetic Environment:
./bin/build.sh
```

## 🛠️ Workflow & Commit Logic
This repository uses Commitizen to automate :ghost: emoji releases. All commits must be conventional.

 * Feature: feat: [description]
 * Fix: fix: [description]
 * Refactor: refactor: [description]

To ensure the release logic triggers correctly, use the built-in CLI:
`uv run cz commit`

## 🧪 Testing & Quality Gates
Before pushing to the Gitea remote, ensure the code passes the "Bleach" test. The Gitea Action will reject any PR that fails these:

 * Linting (Ruff):
   `uv run ruff check .`

 * Formatting (Black/Sovereign Dark):
   `uv run black .`

 * Unit Tests:
   `uv run pytest`

## 🛰️ Sovereign Protocols
 * No Internal IPs: Ensure no 192.x.x.x or 10[0].x.x.x addresses are committed.
 * Context Awareness: Keep code lean for the local LLM inference core. If it can be done with a standard library, do it.
 * OIDC Integrity: Do not bypass the Gitea master auth authority for external calls.

System Status: Architectural Peak. Maintain the Lead Engineer's vision.
