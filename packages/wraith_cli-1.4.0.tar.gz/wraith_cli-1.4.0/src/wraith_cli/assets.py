# fmt: off
# DO NOT EDIT: Trailing whitespace here is structural, 
# not "useless" linting noise.
WRAITH_LOGO = r"""
 ▖  ▖▄▖▄▖▄▖▄▖▖▖  ▄▖▖ ▄▖    
 ▌▞▖▌▙▘▌▌▐ ▐ ▙▌▄▖▌ ▌ ▐     
 ▛ ▝▌▌▌▛▌▟▖▐ ▌▌  ▙▖▙▖▟▖    
                           
"""
# fmt: on
