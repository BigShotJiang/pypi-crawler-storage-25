import os
import subprocess
from importlib.metadata import version as get_local_version
from pathlib import Path
from typing import Annotated

import requests
import typer
from dotenv import load_dotenv
from rich.align import Align
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text

from wraith_cli import assets, qol, repo_make, shield

SOVEREIGN_ADVISORY = """
## Sovereign Security Advisory – Please Read

**Wraith-CLI** is your stack’s nervous system and has sharp edges.
The commands in this toolkit can wipe runner data (`runner-reset`),
view across all containers (`ps`), and expose sensitive stack paths.

**A bad config or unintended command can destabilise your core stack.**

Recommended baseline:
- Use strong passphrases on private keys if exposed to Wraith.
- Sandboxed execution where possible for third-party modules.
- Audit environment variable scope (`GITEA_COMPOSE_PATH`, etc.)
"""

# Load environment variables from .env
load_dotenv()

# Initialise Typer App
app = typer.Typer(
    help="Wraith Sovereign CLI: Ghost Stack Orchestrator",
    rich_markup_mode="rich",
)

# --- Configuration ---
VIKING_URL = os.getenv(
    "VIKING_BASE_URL", "http://127.0.0.1:1933/api/v1"
).rstrip("/")
GITEA_PATH = os.getenv("GITEA_COMPOSE_PATH")
GITEA_API_URL = os.getenv("GITEA_API_URL")
GITEA_TOKEN = os.getenv("GITEA_TOKEN")
GITEA_TEMPLATE_URL = os.getenv("GITEA_TEMPLATE_URL")


# --- Callbacks ---
def version_callback(value: bool):
    """
    Display the current Wraith-CLI version.

    Checks the local metadata to return the
    installed version string before exiting the application.
    """
    if value:
        v = get_local_version("wraith-cli")
        typer.echo(f"Wraith CLI v{v}")
        raise typer.Exit()


def print_wraith_welcome():  # pragma: no cover
    """Renders the definitive OpenClaw-inspired Sovereign splash."""
    console = qol.console
    local_v = get_local_version("wraith-cli")

    logo_text = Text(assets.WRAITH_LOGO, style="bold black on white")
    console.print(Align.center(logo_text))

    sub_header_markup = (
        "[bold bright_black]The Nervous System[/bold bright_black]"
    )
    sub_header = Text.from_markup(sub_header_markup)
    console.print(sub_header, justify="center")
    console.print("\n")

    md = Markdown(SOVEREIGN_ADVISORY)

    panel = Panel(
        md,
        title=(
            "Wraith Orchestrator – "
            f"[bright_black]v{local_v} Advisory[/bright_black]"
        ),
        border_style="bright_black",
        padding=(1, 2),
    )
    console.print(panel)
    console.print("\n")


# --- Modify the Callback ---
@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            callback=version_callback,
            is_eager=True,
            help="Show version and exit.",
        ),
    ] = None,
):
    """
    [bold green]Wraith-CLI[/bold green]
    The nervous system of the Sovereign Ghost Stack.

    Orchestrate your local infrastructure, manage Gitea repositories,
    and monitor system-wide health from a single unified entry point.
    """

    if ctx.invoked_subcommand is None and not version:
        print_wraith_welcome()


# --- Commands ---


@app.command()
def status():
    """
     Check the heartbeat of the OpenViking Stack.

     Polls the configured VIKING_BASE_URL health
    nendpoint to verify if the orchestrator API is responsive.
    """
    url = f"{VIKING_URL}/health"
    try:
        response = requests.get(url, timeout=3)
        if response.status_code == 200:
            typer.secho("🟢 OpenViking: Online", fg=typer.colors.GREEN)
        else:
            typer.secho(
                f"🟡 OpenViking: Warning ({response.status_code})",
                fg=typer.colors.YELLOW,
            )
    except Exception:
        typer.secho("🔴 OpenViking: Offline", fg=typer.colors.RED)


@app.command()
def update():
    """
    Sync Wraith with the latest PyPI release.

    Compares local versioning against the remote registry and
    automatically triggers an upgrade via 'uv tool' if a newer
    version is detected.
    """
    try:
        local_v = get_local_version("wraith-cli")
        remote_v = qol.get_latest_version()

        if remote_v > local_v:
            typer.echo(
                f"✨ New version available: {remote_v} (Local: {local_v})"
            )
            subprocess.run(["uv", "tool", "upgrade", "wraith-cli"])
        else:
            typer.secho(f"✅ Wraith is up to date (v{local_v})", fg="green")
    except Exception as e:
        typer.secho(f"❌ Update check failed: {e}", fg="red")


@app.command()
def ps(
    all: Annotated[
        bool, typer.Option("--all", "-a", help="Show all containers")
    ] = False,
):
    """
    List running containers with Sovereign styling.

    Wraps 'docker ps' to provide a high-contrast,
    readable table summarising service names,
    container status, and source images.
    """
    cmd = ["docker", "ps"]
    if all:
        cmd.append("-a")

    # Custom format for our Rich table conversion
    cmd.extend(["--format", "table {{.Names}}\t{{.Status}}\t{{.Image}}"])

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        typer.secho("❌ Docker is not running or accessible.", fg="red")
        return

    rich_table = qol.format_docker_table(result.stdout)
    qol.console.print(rich_table)


@app.command()
def tail(
    service: str = typer.Argument(
        ..., help="Service name (e.g., ollama, gitea)"
    ),
    path: Annotated[
        Path | None,
        typer.Option(
            "--path",
            "-p",
            envvar="WRAITH_COMPOSE_PATH",
            help="Path to directory with docker-compose.yml.",
        ),
    ] = None,
):
    """
    Stream live logs from a specific service.

    Connects to a running container to output real-time logs.
    Resolves Compose paths via CLI flags,
    environment variables, or local directory discovery.

    Priority:
       1. Passed flag --path
       2. Env Var WRAITH_COMPOSE_PATH
       3. Current Directory
    """
    target_path = path or Path.cwd()

    typer.echo(f"🔍 Searching for {service} in {target_path}...")
    success = qol.run_tail(service, target_path)

    if not success:
        typer.secho(
            f"❌ No docker-compose.yml found in {target_path}", fg="red"
        )
        raise typer.Exit(1)


@app.command()
def runner_reset():
    """
    Repair hung or offline Gitea Action Runners.

    Performs a nuclear reset: stops the container,
    purges the local registration data, and restarts
    the service to force a fresh handshake with Gitea.

    Requires GITEA_COMPOSE_PATH as an envelope variable
    """
    if not GITEA_PATH:
        typer.secho("❌ Error: GITEA_COMPOSE_PATH not set in .env", fg="red")
        raise typer.Exit(1)

    compose_path = Path(GITEA_PATH)
    docker_file = compose_path / "docker-compose.yml"
    runner_data = compose_path / "data/act_runner/.runner"

    if not docker_file.exists():
        typer.secho(f"❌ Compose file not found at: {docker_file}", fg="red")
        raise typer.Exit(1)

    typer.echo("👻 Wraith-CLI: Killing Gitea Runner...")
    subprocess.run(["docker", "compose", "-f", str(docker_file), "stop"])

    if runner_data.exists():
        typer.echo(f"🧹 Wiping registration: {runner_data}")
        subprocess.run(["sudo", "rm", "-f", str(runner_data)])

    typer.echo("🚀 Restarting Runner...")
    subprocess.run(["docker", "compose", "-f", str(docker_file), "up", "-d"])
    typer.secho("✅ Runner state reset.", fg="green", bold=True)


@app.command()
def spawn(
    repo_name: str = typer.Argument(
        ..., help="Name of the new Ghost Stack repository"
    ),
):
    """
    🏭 Scaffold a new repository instantly.

    Atomic scaffolding for new Ghost Stack repositories.
    Clones a template, bleaches git history,
    provisions a remote repository via API, and
    pushes the initial commit in one sequence.
    """
    if not all([GITEA_API_URL, GITEA_TOKEN, GITEA_TEMPLATE_URL]):
        typer.secho(
            """❌ Missing Environment Variables!
            Check .env for
                GITEA_API_URL,
                GITEA_TOKEN,
                and GITEA_TEMPLATE_URL.
            """,
            fg="red",
        )
        raise typer.Exit(1)

    assert GITEA_API_URL is not None
    assert GITEA_TOKEN is not None
    assert GITEA_TEMPLATE_URL is not None

    target_dir = Path.cwd() / repo_name
    typer.echo(f"👻 Spawning '{repo_name}' from Repo Factory...")

    try:
        typer.echo("   └── 🧬 Cloning template and bleaching history...")
        repo_make.clone_and_bleach(GITEA_TEMPLATE_URL, target_dir, GITEA_TOKEN)

        typer.echo("   └── 🌐 Provisioning repository on Gitea...")
        remote_url = repo_make.create_gitea_repo(
            repo_name, GITEA_API_URL, GITEA_TOKEN
        )

        typer.echo(f"   └── 🚀 Initialising and pushing to {remote_url}...")
        repo_make.init_and_push(target_dir, remote_url, GITEA_TOKEN)

        typer.secho(
            f"\n✅ Success! Gitea Repo '{repo_name}' is alive.",
            fg="green",
            bold=True,
        )
        typer.echo(f"👉 cd {repo_name} && code .")

    except FileExistsError as e:
        typer.secho(f"❌ Error: {e}", fg="red")
        raise typer.Exit(1) from e
    except Exception as e:
        typer.secho(f"❌ Critical Failure: {e}", fg="red")
        raise typer.Exit(1) from e


@app.command()
def logs(
    health: Annotated[
        bool,
        typer.Option(
            "--health", help="Pull SMART data summary from Scrutiny API"
        ),
    ] = False,
):
    """
    Unified hardware health and logging portal.

    Default behavior provides log-tailing instructions.
    Using the --health flag triggers a deep-dive query
    into the Scrutiny API for SMART drive data and disk temps.
    """
    if health:
        typer.echo("🔍 Polling Bare-Metal SMART data via Scrutiny...")
        health_table = shield.get_scrutiny_health()
        qol.console.print(health_table)
    else:
        typer.echo(
            "Use 'wraith tail <svc>' for logs. Pass --health for drive health."
        )


@app.command()
def mesh():
    """
    Map the Tailscale Ghost Mesh network.

    Interrogates the Tailscale daemon (local or containerised)
    to return a list of active peers, their internal IPs, and
    current online/offline status.
    """
    typer.echo("🌐 Querying Ghost Mesh (Tailscale)...")
    mesh_table = shield.get_tailscale_mesh()
    qol.console.print(mesh_table)


@app.command()
def audit():
    """
    Execute a Sovereign security and compliance scan.

    Audits the running stack for common vulnerabilities, including
    containers running with root privileges and exposed ports
    that deviate from the Registry Spec.
    """
    typer.echo("🛡️ Initiating Sovereign Security Audit...")
    audit_table = shield.run_security_audit()
    qol.console.print(audit_table)


if __name__ == "__main__":  # pragma: no cover
    app()
