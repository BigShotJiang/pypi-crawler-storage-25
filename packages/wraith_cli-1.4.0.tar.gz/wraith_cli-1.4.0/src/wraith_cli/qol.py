import subprocess
from pathlib import Path

import requests
from rich.console import Console
from rich.table import Table

console = Console()


def get_latest_version(package_name: str = "wraith-cli") -> str:
    """Fetch the latest version from PyPI."""
    url = f"https://pypi.org/pypi/{package_name}/json"
    try:
        response = requests.get(url, timeout=3)
        return response.json()["info"]["version"]
    except Exception:
        return "0.0.0"


def format_docker_table(raw_output: str) -> Table:
    """Converts raw docker ps output into a Sovereign Rich table."""
    table = Table(border_style="bright_black", header_style="bold green")
    lines = [line for line in raw_output.split("\n") if line.strip()]
    if not lines:
        return table

    headers = lines[0].split("\t")
    for header in headers:
        table.add_column(header.strip())

    for line in lines[1:]:
        table.add_row(*line.split("\t"))
    return table


def run_tail(service: str, target_path: Path) -> bool:
    """The actual logic to run the docker command."""
    docker_file = target_path / "docker-compose.yml"
    if not docker_file.exists():
        return False

    # Run docker compose logs
    subprocess.run(
        ["docker", "compose", "-f", str(docker_file), "logs", "-f", service]
    )
    return True
