import shutil
import subprocess
from pathlib import Path

import requests


def create_gitea_repo(repo_name: str, api_url: str, token: str) -> str:
    """Uses the Gitea API to create a new private repository."""
    headers = {
        "Authorization": f"token {token}",
        "Content-Type": "application/json",
    }
    data = {"name": repo_name, "private": True}
    endpoint = f"{api_url.rstrip('/')}/api/v1/user/repos"

    response = requests.post(endpoint, headers=headers, json=data, timeout=5)
    response.raise_for_status()

    repo_data = response.json()

    # Prioritise HTTPS (clone_url) over SSH since we are using token auth
    return repo_data.get("clone_url", repo_data.get("ssh_url"))


def clone_and_bleach(template_url: str, target_dir: Path, token: str) -> bool:
    """Clones the template and removes the origin .git history."""
    if target_dir.exists():
        raise FileExistsError(f"Directory '{target_dir}' already exists.")

    # Inject token for HTTPS/HTTP authentication to prevent git hanging
    auth_url = template_url
    if template_url.startswith("https://"):
        auth_url = template_url.replace("https://", f"https://oauth2:{token}@")
    elif template_url.startswith("http://"):
        auth_url = template_url.replace("http://", f"http://oauth2:{token}@")

    # 1. Clone
    subprocess.run(
        ["git", "clone", auth_url, str(target_dir)],
        check=True,
        capture_output=True,
    )

    # 2. Bleach
    git_dir = target_dir / ".git"
    if git_dir.exists():
        shutil.rmtree(git_dir)

    return True


def init_and_push(target_dir: Path, remote_url: str, token: str) -> bool:
    """
    Initialises a fresh git repo,
    commits the template,
    and pushes to remote.
    """

    # Inject token for HTTPS/HTTP authentication to prevent git hanging
    auth_remote = remote_url
    if remote_url.startswith("https://"):
        auth_remote = remote_url.replace(
            "https://", f"https://oauth2:{token}@"
        )
    elif remote_url.startswith("http://"):
        auth_remote = remote_url.replace("http://", f"http://oauth2:{token}@")

    commands = [
        ["git", "init"],
        ["git", "checkout", "-b", "main"],
        ["git", "add", "."],
        [
            "git",
            "commit",
            "-m",
            ":tada: Initial commit from Wraith Ghost Factory",
        ],
        ["git", "remote", "add", "origin", auth_remote],
        ["git", "push", "-u", "origin", "main"],
    ]

    for cmd in commands:
        subprocess.run(
            cmd, cwd=str(target_dir), check=True, capture_output=True
        )

    return True
