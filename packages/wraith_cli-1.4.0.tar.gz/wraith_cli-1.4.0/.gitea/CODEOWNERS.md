# Global owners
* @thomaspeoples

# Specialised owners
# /bin/ @thomaspeoples @ghost-bot
# /src/ @thomaspeoples
