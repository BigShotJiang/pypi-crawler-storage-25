from setuptools import setup

setup(
    name="nqueen-generator-vikas",
    version="0.1",
    py_modules=["generator"],
    entry_points={
        'console_scripts': [
            'generate-nqueen=generator:generate_nqueen',
        ],
    },
    author="Vikas Singh",
    description="Generates N-Queen Python code",
)