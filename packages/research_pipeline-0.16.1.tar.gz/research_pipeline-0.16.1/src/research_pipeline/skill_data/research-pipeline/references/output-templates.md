# Output Templates

## Formatting Guidelines

All generated reports (final research report, synthesis, analysis) MUST use:

- **Table of contents**: every final report MUST start with a
  `## Contents` section containing Markdown-link entries to every
  top-level section (GitHub-flavored slug anchors).
- **Human-readable structure**: clear headings, short paragraphs, concise
  takeaways before detail, and no wall-of-text sections
- **Mermaid** for diagrams and flowcharts (never ASCII art — it breaks easily).
  At minimum, include: (a) a pipeline/methodology diagram and (b) at least
  one diagram per architectural or taxonomic theme discussed.
- **Vertical Mermaid charts by default** (`flowchart TD` or `flowchart TB`);
  use horizontal charts only for compact diagrams where it improves readability
- **LaTeX** for every mathematical formula or equation (inline `$...$` or
  display `$$...$$`). Do not render formulas as plain text, code blocks,
  or Unicode approximations.
- **Markdown tables** for structured data comparisons
- **Internal Markdown links** for exploration: contents links, section links,
  paper/reference links, and links from recommendations to supporting findings
  or gaps

## Resume-on-top workflow

When a prior `<topic-slug>-research-report.md` exists in the working
directory, the report MUST be regenerated (not appended). Carry forward:

1. Prior paper IDs — pass to `research-pipeline expand --paper-ids ...`
   and let the global paper index deduplicate downloads/conversions.
2. Prior unresolved gaps and open questions — inject into the new
   `query_plan.json` as additional `query_variants`.
3. Prior contradictions — re-evaluate against the new evidence and
   either resolve them or carry them into the new contradictions table.

The snapshot of the old report (renamed to
`<topic-slug>-research-report.<YYYY-MM-DD>.md`) is preserved in the
working directory but never referenced from the new report body.

Examples:

```markdown
<!-- Mermaid diagram -->
```mermaid
flowchart TD
    A[Search] --> B[Screen]
    B --> C[Analyze]
```

<!-- LaTeX formula -->
The composite quality score is computed as:

$$Q = w_c \times C + w_v \times V + w_a \times A + w_r \times R$$

where $w_c = 0.35$, $w_v = 0.25$, $w_a = 0.25$, $w_r = 0.15$.
```

## Pipeline Status (after each stage)

```
## Pipeline Status — Run <RUN_ID>

| Stage | Status | Details |
|-------|--------|---------|
| Plan | ✅ Done | Topic: "...", N query variants |
| Search | ✅ Done | N candidates (arXiv: X, Scholar: Y) |
| Screen | ✅ Done | N → M shortlisted |
| Quality | ⬜ Optional | — |
| Expand | ⬜ Optional | — |
| Download | ✅ Done | N/N PDFs (size) |
| Convert | ✅ Done | N/N Markdown files |
| Extract | ⬜ Pending | — |
| Summarize | ⬜ Pending | — |

Run directory: runs/<RUN_ID>/
```

## Final Report Location

Write the final report to the **current working directory**:
```
./<topic-slug>-research-report.md
```
Example: `./local-memory-system-for-ai-agents-research-report.md`

NOT inside `runs/<run_id>/`.

## Final Research Report Template

The final report MUST follow this structure. Every section is required
unless marked (optional). Sections marked **[EVIDENCE REQUIRED]** must
cite specific papers with `[arxiv_id]` or `[Author, Year]` references.

````markdown
# Research Report: [Topic]

## Contents

- [Executive Summary](#executive-summary)
- [Round History](#round-history)
- [Research Question](#research-question)
- [Methodology](#methodology)
- [Papers Reviewed](#papers-reviewed)
- [Research Landscape](#research-landscape)
- [Research Gaps](#research-gaps)
- [Practical Recommendations](#practical-recommendations)
- [References](#references)
- [Appendix: Run Metadata](#appendix-run-metadata)

## Round History

Iterative gap-closure loop (hard cap: 4 rounds). See
`references/iterative-synthesis.md` for the full loop definition.

| Round | Run ID | Topic / Gap Focus | New Papers | Gaps Addressed | Remaining Gaps |
|-------|--------|-------------------|------------|----------------|----------------|
| 1 | <run-id-1> | <original topic> | N | initial shortlist | A academic, E engineering |
| 2 | <run-id-2> | <academic gap focus> | N | … | … |

**Stop reason**: [converged — no open gaps | 4-round cap reached |
new search returned 0 relevant papers | remaining gaps marked out-of-scope]

## Executive Summary

[3-5 sentences: research question, scope (N papers from M sources),
key conclusion, and confidence level. Must mention the strongest finding
and the most significant gap.]

**Scope**: N papers analyzed from [sources] over [date range]
**Overall Confidence**: High / Medium / Low
**Verdict**: [IMPLEMENTATION_READY | HAS_GAPS | NOT_APPLICABLE]

## Research Question

[Precise statement of what was investigated. Include scope boundaries:
what's in vs. out.]

## Methodology

### Search Strategy
- **Sources**: [arXiv, Google Scholar, Semantic Scholar, ...]
- **Query variants**: [list the key queries used]
- **Time window**: [date range]
- **Screening**: [BM25 + sub-agent / BM25 only]

### Pipeline Summary

```mermaid
flowchart TD
    A["Searched<br/>N candidates"] --> B["Screened<br/>M shortlisted"]
    B --> C["Downloaded<br/>P PDFs"]
    C --> D["Converted<br/>Q markdown"]
    D --> E["Analyzed<br/>R papers"]
```

| Metric | Count |
|--------|-------|
| Total candidates | N |
| After screening | M |
| Downloaded | P |
| Successfully converted | Q |
| Deeply analyzed | R |
| Iterations (if system-building) | I |

## Papers Reviewed

| # | Title | Authors | Year | Venue | Quality Score | Relevance |
|---|-------|---------|------|-------|--------------|-----------|
| 1 | [Title] [arxiv_id] | First Author et al. | YYYY | Venue | X.X/5 | HIGH / MEDIUM / LOW |

## Research Landscape

### Theme 1: [Theme Name]

**Coverage**: N papers | **Confidence**: High / Medium / Low
**Supporting papers**: [arxiv_id_1], [arxiv_id_2], ...

[Narrative description of the theme with evidence citations.] **[EVIDENCE REQUIRED]**

Key findings:
1. [Finding with citation: "Paper A [arxiv_id] demonstrated X with Y% improvement"]
2. [Finding with citation]

### Theme 2: [Theme Name]
[Same structure as Theme 1]

## Methodology Comparison

| Approach | Papers | Strengths | Weaknesses | Best For | Performance |
|----------|--------|-----------|------------|----------|-------------|
| [Approach A] | [ids] | ... | ... | ... | [metric if available] |
| [Approach B] | [ids] | ... | ... | ... | [metric if available] |

## Confidence-Graded Findings

### 🟢 High Confidence (supported by 3+ papers with consistent results)

1. **[Finding]** — Supported by [paper_1], [paper_2], [paper_3].
   [Brief evidence summary with specific numbers if available.]

### 🟡 Medium Confidence (supported by 1-2 papers or with caveats)

1. **[Finding]** — Reported by [paper_1]. [Caveat or limitation.]

### 🔴 Low Confidence (preliminary, single-source, or contradicted)

1. **[Finding]** — Only reported by [paper_1]. [Why confidence is low.]

## Trade-Off Analysis

| Decision | Option A | Option B | Recommendation |
|----------|----------|----------|----------------|
| [Design choice] | [Pros/cons with evidence] | [Pros/cons with evidence] | [Which and why] |

## Points of Agreement **[EVIDENCE REQUIRED]**

1. [Consensus finding] — Confirmed by [paper_1], [paper_2], [paper_3].

## Points of Contradiction **[EVIDENCE REQUIRED]**

1. **[Topic]**: [Paper A] claims X, but [Paper B] shows Y.
   - **Possible explanation**: [Why they disagree — different datasets, metrics, scope]
   - **Implication**: [What this means for the reader]

## Research Gaps

| # | Gap | Type | Severity | Impact on Goals |
|---|-----|------|----------|----------------|
| 1 | [What's missing] | ACADEMIC / ENGINEERING | HIGH / MEDIUM / LOW | [Why it matters] |

### Academic Gaps (require more papers)

1. **[Gap]**: [Description]. Suggested queries: `"query 1"`, `"query 2"`.

### Engineering Gaps (fillable without papers)

1. **[Gap]**: [Description]. Suggested resolution: [approach].

## Reproducibility Notes

| Paper | Code Available | Data Available | Sufficient Detail | License |
|-------|---------------|----------------|-------------------|---------|
| [arxiv_id] | ✅ [link] / ❌ | ✅ [link] / ❌ | ✅ / ⚠️ / ❌ | [license] |

## Practical Recommendations **[EVIDENCE REQUIRED]**

1. **[Recommendation]** — Based on [evidence from papers].
   *Confidence*: High / Medium / Low

## Future Directions

1. [Research direction enabled by current findings]

## Readiness Assessment (System-Building Mode)

### Verdict: [IMPLEMENTATION_READY | HAS_GAPS | NOT_APPLICABLE]

### Assessment Summary
[2-3 sentences: Is the synthesis sufficient to design and build the system?]

### Coverage Matrix

| Dimension | Status | Evidence |
|-----------|--------|----------|
| Architecture patterns | ✅ Sufficient / ⚠️ Partial / ❌ Missing | [papers] |
| Technology stack | ✅ / ⚠️ / ❌ | [papers] |
| Performance baselines | ✅ / ⚠️ / ❌ | [papers] |
| Security model | ✅ / ⚠️ / ❌ | [papers] |
| Trade-off map | ✅ / ⚠️ / ❌ | [papers] |

### Gap Resolution Plan

| # | Gap | Type | Severity | Resolution |
|---|-----|------|----------|------------|
| 1 | ... | ENGINEERING / ACADEMIC | HIGH / MEDIUM / LOW | [action] |

## Evidence Map

| Research Question Aspect | Paper 1 | Paper 2 | Paper 3 | ... |
|--------------------------|---------|---------|---------|-----|
| [Aspect 1]               | ✓ (§3)  |         | ✓ (§4)  | ... |
| [Aspect 2]               |         | ✓ (§2)  |         | ... |

## References

1. [arxiv_id] — [Title]. [Authors]. [Year]. [Venue].
2. ...

## Appendix: Run Metadata

- **Run ID**: <RUN_ID>
- **Sources**: [list]
- **Pipeline version**: [version]
- **Date**: [date]
- **Artifacts**: `runs/<RUN_ID>/`
````

## Final Summary (in chat)

After writing the full report file, provide this condensed summary in chat:

```
## Research Summary — "<topic>"

**Run ID**: <RUN_ID>
**Sources**: arXiv, Google Scholar
**Timeline**: <start_time> → <end_time>
**Iterations**: <N> (if system-building mode)

### Pipeline Results
- **Searched**: <N> candidates from <sources>
- **Screened**: <N> → <M> shortlisted (top relevance: <score>)
- **Downloaded**: <N> PDFs (<size>)
- **Converted**: <N> Markdown files
- **Errors**: <list or "None">

### Key Findings (Confidence-Graded)
1. 🟢 <high-confidence finding with paper citation>
2. 🟡 <medium-confidence finding with paper citation>
3. ...

### Top Papers
| # | Paper | Score | Key Contribution |
|---|-------|-------|------------------|
| 1 | <title> (arxiv_id) | <score> | <one-line summary> |

### Artifacts
- Final report: ./<topic-slug>-research-report.md
- Run data: runs/<RUN_ID>/
```
