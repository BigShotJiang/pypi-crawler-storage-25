# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Activate venv (always do this first)
source .venv/bin/activate

# Run tests
python -m pytest tests/ -v --tb=short

# Run a single test file
python -m pytest tests/test_analyzer.py -v

# Install in editable mode (after pulling changes)
pip install -e ".[dev]"

# Run the CLI
hpf analyze --study <name> --file <path.db>
hpf setup
```

## Architecture

The pipeline is linear: `StudyAnalyzer → RangeSuggester → LLMClient → Reporter`

**`hpf/models.py`** — all shared dataclasses (`AnalysisResult`, `ParameterStats`, `ParameterSuggestion`, `HPFReport`). Every module imports from here; never duplicate these types.

**`hpf/analyzer.py`** — `StudyAnalyzer.analyze(study, model_type)` filters complete trials, sorts by objective direction, takes top-K% (floor 3), and builds `ParameterStats` per parameter. Uses Optuna's `FloatDistribution`, `IntDistribution`, `CategoricalDistribution` to detect type and scale.

**`hpf/range_suggester.py`** — `RangeSuggester.suggest(analysis)` applies a 4-rule waterfall per numeric param: LOG_SCALE → EXPAND → NARROW → KEEP. Uses numpy for percentile calculations. Also contains `_generate_optuna_code()`.

**`hpf/llm/`** — abstract `LLMClient` base with `_build_prompt()` shared logic. `OllamaClient` and `OpenAIClient` are concrete implementations. `SetupWizard` saves config to `~/.hpf/config.json`.

**`hpf/formatters/report.py`** — `Reporter.print_report(HPFReport)` renders the full terminal output using `rich`. Order: welcome banner → study summary → parameter table → LLM panel → code block → next steps.

**`hpf/formatters/code_gen.py`** — standalone `generate_optuna_code(suggestions, study_name)` function, no external state.

**`hpf/cli.py`** — two Typer commands: `analyze` (full pipeline) and `setup` (wizard). Error handling with rich panels.

## Key design rules

- Optuna-only for HPO framework support (no Ray Tune, HyperOpt, etc. yet)
- LLM is always optional — all statistical analysis works without it
- `ParameterStats.best_values` are raw sampled values (not normalized); the suggester works in the original parameter space
- Categorical params use `best_values` as a set membership check (not numeric comparisons)
- The `boundary_threshold` in `RangeSuggester` is a fraction of the range, not an absolute value
