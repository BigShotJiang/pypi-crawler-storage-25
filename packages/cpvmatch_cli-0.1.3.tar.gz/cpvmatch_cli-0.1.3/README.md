# cpvmatch-cli

[![PyPI version](https://badge.fury.io/py/cpvmatch-cli.svg)](https://badge.fury.io/py/cpvmatch-cli)
[![Python](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)

Semantic annotation CLI tool for CPV entity recognition. Supports brand, category, metric, and attribute entity identification in natural language queries.

## Install

```shell
# From PyPI (recommended)
pip install cpvmatch-cli

# Or via uv
uv tool install cpvmatch-cli

# Or run without installing
uvx cpvmatch-cli
```

## Quick Start

### 1. Configure API Key

**Option 1: Environment variable (recommended)**
```bash
export CPVMATCH_APIKEY="your-api-key-here"
```

**Option 2: Login to save locally**
```bash
cpvmatch-cli login
# Or pipe the key directly
echo "your-api-key-here" | cpvmatch-cli login
```

**Option 3: Pass as argument**
```bash
cpvmatch-cli annotation -q 'question' -k "your-api-key-here"
```

### 2. Annotate

```bash
cpvmatch-cli annotation -q '元气森林今年的销售额'
cpvmatch-cli annotation -q '查询元气森林无糖茶在即饮茶的市占率'

# Specify category scope
cpvmatch-cli annotation -q '元气森林销售额' --attribute-categories '饮料,食品'

# Disable full mode
cpvmatch-cli annotation -q '元气森林销售额' --no-full-mode
```

## CLI Commands

### login

Save API Key to `~/.cpvmatch/config.json`.

```bash
cpvmatch-cli login
```

### annotation

Annotate a natural language question.

| Flag | Description |
|------|-------------|
| `-q, --question` | Natural language question to annotate (required) |
| `-k, --apikey` | API Key (optional if set via env or login) |
| `--full-mode / --no-full-mode` | Enable/disable full mode (default: enabled) |
| `--attribute-categories` | Category scope, comma-separated, e.g., `饮料,食品` |

## API Key Priority

CLI argument > `CPVMATCH_APIKEY` env var > saved config via `cpvmatch-cli login`

## Development

```bash
# Install dependencies
uv sync

# Run tests
uv run pytest tests/ -v

# Lint
uv run ruff check .

# Format
uv run ruff format .

# Install locally
uv tool install .
```

## Project Structure

```
cpvmatch-cli/
├── cpvmatch_cli/
│   ├── __init__.py    # Package init, version
│   ├── api.py         # HTTP API client
│   ├── cli.py         # Typer CLI commands
│   └── config.py      # Local config management
├── tests/
│   ├── test_api.py
│   ├── test_cli.py
│   └── test_config.py
├── pyproject.toml
├── Justfile
```