"""cpvmatch-cli API client."""

import httpx

BASE_URL = "https://ml-jsonrpc.banmahui.cn/cpvmatch"
_API_VERSION = "v2"
_TIMEOUT = 30.0


def annotate(
    apikey: str,
    question: str,
    full_mode: bool = True,
    attribute_categories: list[str] | None = None,
) -> dict:
    """
    Call the annotation endpoint.

    Args:
        apikey: API key for authentication.
        question: Natural language question to annotate.
        full_mode: Enable full annotation mode (default True).
        attribute_categories: Optional list of attribute categories to restrict scope.

    Returns:
        Annotation result as a dict.
    """
    categories_value: str | list[str] | None
    if attribute_categories is not None:
        categories_value = attribute_categories
    else:
        categories_value = "auto"

    with httpx.Client(
        base_url=BASE_URL,
        headers={"apikey": apikey, "content-type": "application/json"},
        timeout=_TIMEOUT,
    ) as client:
        resp = client.post(
            f"/{_API_VERSION}/annotation",
            json={
                "question": question,
                "full_mode": full_mode,
                "attribute_categories": categories_value,
            },
        )
        resp.raise_for_status()
        return resp.json()
