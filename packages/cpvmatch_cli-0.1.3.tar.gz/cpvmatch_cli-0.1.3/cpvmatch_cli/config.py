"""cpvmatch-cli local config management."""

from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)

CONFIG_DIR = Path.home() / ".cpvmatch"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_config() -> dict:
    """Load config from disk. Returns empty dict if file is missing or unreadable."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to read config file %s: %s", CONFIG_FILE, e)
        return {}


def save_config(config: dict) -> None:
    """Atomically save config to disk and lock file permissions to user-only."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    # Write to a temp file first, then atomically replace the target.
    tmp_path = CONFIG_FILE.with_suffix(".tmp")
    tmp_path.write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # Set permissions before the rename so the file is never world-readable.
    _chmod_600(tmp_path)
    shutil.move(tmp_path, CONFIG_FILE)


def _chmod_600(path: Path) -> None:
    """Set 0o600 permissions, ignoring errors (e.g. on Windows)."""
    try:
        path.chmod(0o600)
    except OSError:
        pass


def get_apikey() -> str | None:
    """Return the saved API Key, or None if not configured."""
    return load_config().get("apikey")
