"""cpvmatch-cli CLI commands."""

from __future__ import annotations

import json
import os

import httpx
import typer
from rich import print as rprint

from cpvmatch_cli.api import annotate
from cpvmatch_cli.config import get_apikey, save_config

app = typer.Typer(name="cpvmatch-cli", help="CPVMatch semantic annotation CLI tool")


def _resolve_apikey(override: str | None) -> str:
    """
    Resolve API key with priority: CLI arg > env vars > saved config > prompt.

    Raises:
        SystemExit: If no API key is available and user cannot or refuses to provide one.
    """
    # 1. CLI argument (interface passthrough) — highest priority
    if override:
        return override

    # 2. Environment variables
    for env_key in ("CPVMATCH_API_KEY", "CPVMATCH_APIKEY"):
        env_val = os.getenv(env_key, "")
        if env_val:
            return env_val

    # 3. Saved config from login
    saved = get_apikey()
    if saved:
        return saved

    # 4. Prompt user for input
    apikey = typer.prompt("Enter your CPVMATCH API Key")
    if not apikey:
        rprint("[red]API Key cannot be empty[/red]")
        raise typer.Exit(code=1)
    return apikey


@app.command()
def login():
    """Save your API Key locally after verifying it with the server."""
    # 1. Check existing saved config first
    saved = get_apikey()
    if saved:
        try:
            annotate(saved, "测试")
            mask = saved[:6] + "*" * max(0, len(saved) - 6)
            rprint(f"[green]已登录，有效[/green] ({mask})")
            return
        except httpx.HTTPError:
            rprint("[yellow]已失效，重新输入APIKEY[/yellow]")

    # 2. Fall back to env var as pre-filled input
    apikey = os.getenv("CPVMATCH_APIKEY", "")

    attempts = 0
    max_attempts = 3
    while True:
        if not apikey:
            apikey = typer.prompt("请输入APIKEY")

        if not apikey:
            rprint("[red]API Key cannot be empty[/red]")
            apikey = ""
            continue

        # Test the API key by calling the annotate endpoint with a dummy question.
        try:
            annotate(apikey, "测试")
            break
        except httpx.HTTPError:
            attempts += 1
            apikey = ""
            if attempts >= max_attempts:
                rprint(f"[red]API Key 验证连续失败 {max_attempts} 次，退出。[/red]")
                raise typer.Exit(code=1)
            rprint(f"[red]无效，重新输入[/red] ({attempts}/{max_attempts})")

    save_config({"apikey": apikey})
    mask = apikey[:6] + "*" * max(0, len(apikey) - 6)
    rprint(f"[green]登录成功[/green] ({mask})")


@app.command()
def clear():
    """Remove the locally saved API Key."""
    from cpvmatch_cli.config import CONFIG_FILE

    saved = get_apikey()
    if not saved:
        rprint("[yellow]No local API Key found.[/yellow]")
        return

    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()
    rprint("[green]Local API Key cleared.[/green]")


@app.command()
def annotation(
    question: str = typer.Option(
        ..., "--question", "-q", help="Natural language question to annotate"
    ),
    apikey: str | None = typer.Option(
        None, "--apikey", "-k", help="API Key (or set CPVMATCH_APIKEY env var)"
    ),
    full_mode: bool = typer.Option(
        True, "--full-mode/--no-full-mode", help="Enable full annotation mode"
    ),
    attribute_categories: str | None = typer.Option(
        None, help="Comma-separated attribute categories, e.g. 饮料,食品"
    ),
):
    """Annotate a natural language question for CPV entities."""
    categories: list[str] | None = None
    if attribute_categories:
        categories = [s.strip() for s in attribute_categories.split(",") if s.strip()]

    resolved = _resolve_apikey(apikey)

    try:
        result = annotate(resolved, question, full_mode, categories)
        rprint(json.dumps(result, ensure_ascii=False, indent=2))
    except httpx.HTTPError as e:
        if isinstance(e, httpx.ConnectError):
            rprint("[red]Could not connect to server — check your network[/red]")
        elif isinstance(e, httpx.ReadTimeout):
            rprint("[red]Request timed out — please try again[/red]")
        else:
            rprint(f"[red]Request error: {e}[/red]")
        raise typer.Exit(code=1)


if __name__ == "__main__":
    app()
