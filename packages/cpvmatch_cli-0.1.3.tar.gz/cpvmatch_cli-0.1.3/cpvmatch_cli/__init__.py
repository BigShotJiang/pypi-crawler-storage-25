"""cpvmatch-cli: CPV semantic annotation CLI tool."""

__version__ = "0.1.3"
