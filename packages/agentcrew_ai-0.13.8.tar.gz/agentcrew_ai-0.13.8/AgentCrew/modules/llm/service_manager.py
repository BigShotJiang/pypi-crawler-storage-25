from __future__ import annotations
from typing import Dict, Optional, Callable, TYPE_CHECKING
from AgentCrew.modules.llm.base import BaseLLMService
from AgentCrew.modules.llm.model_registry import ModelRegistry
from loguru import logger
import os

if TYPE_CHECKING:
    from AgentCrew.modules.llm.types import Model


class ServiceManager:
    """Singleton manager for LLM service instances with lazy loading."""

    _instance = None

    @classmethod
    def get_instance(cls):
        """Get the singleton instance of ServiceManager."""
        if cls._instance is None:
            cls._instance = ServiceManager()
        return cls._instance

    def __init__(self):
        """Initialize the service manager with empty service instances."""
        if ServiceManager._instance is not None:
            raise RuntimeError(
                "ServiceManager is a singleton. Use get_instance() instead."
            )

        self.services: Dict[str, BaseLLMService] = {}

        # Lazy import factories keyed by service implementation name.
        # A single vendor (e.g. openai) may expose multiple service families.
        self.service_factories: Dict[str, Callable[[], BaseLLMService]] = {
            "claude": self._create_anthropic_service,
            "openai": self._create_openai_service,
            "openai_response": self._create_openai_response_service,
            "openai_codex": self._create_openai_codex_service,
            "google": self._create_google_service,
            "deepinfra": self._create_deepinfra_service,
            "together": self._create_together_service,
            "opencode_go": self._create_opencode_go_service,
            "opencode_anthropic": self._create_opencode_anthropic_service,
            "github_copilot": self._create_github_copilot_service,
            "copilot_response": self._create_copilot_response_service,
        }

        # Store details for custom providers
        self.custom_provider_details: Dict[str, Dict] = {}
        self._load_custom_provider_configs()

    # Lazy import factory methods
    def _create_anthropic_service(self) -> BaseLLMService:
        """Lazy import and create Anthropic service."""
        if os.getenv("ANTHROPIC_API_KEY"):
            from AgentCrew.modules.anthropic import AnthropicService

            return AnthropicService()
        raise RuntimeError("API key for Anthropic not found.")

    def _create_opencode_anthropic_service(self) -> BaseLLMService:
        if os.getenv("OPENCODE_API_KEY"):
            from AgentCrew.modules.anthropic import AnthropicService

            llm = AnthropicService(
                os.getenv("OPENCODE_API_KEY"),
                "https://opencode.ai/zen/go",
                provider_name="opencode_go",
            )
            llm.model = "minimax-m2.7"
            return llm
        raise RuntimeError("API key for Anthropic not found.")

    def _create_openai_service(self) -> BaseLLMService:
        """Lazy import and create OpenAI Chat Completions service."""
        if os.getenv("OPENAI_API_KEY"):
            from AgentCrew.modules.openai.service import OpenAIService

            return OpenAIService()
        raise RuntimeError("API key for OpenAI not found.")

    def _create_openai_response_service(self) -> BaseLLMService:
        """Lazy import and create OpenAI Response API service."""
        if os.getenv("OPENAI_API_KEY"):
            from AgentCrew.modules.openai import OpenAIResponseService

            return OpenAIResponseService()
        raise RuntimeError("API key for OpenAI not found.")

    def _create_openai_codex_service(self) -> BaseLLMService:
        """Lazy import and create OpenAI Codex service using ChatGPT subscription OAuth."""
        from AgentCrew.modules.openai_codex import OpenAICodexService

        return OpenAICodexService()

    def _create_google_service(self) -> BaseLLMService:
        """Lazy import and create Google AI service."""
        if os.getenv("GEMINI_API_KEY"):
            from AgentCrew.modules.google import GoogleAINativeService

            return GoogleAINativeService()
        raise RuntimeError("API key for Google AI not found.")

    def _create_deepinfra_service(self) -> BaseLLMService:
        """Lazy import and create DeepInfra service."""
        if os.getenv("DEEPINFRA_API_KEY"):
            from AgentCrew.modules.custom_llm import DeepInfraService

            return DeepInfraService()
        raise RuntimeError("API key for DeepInfra not found.")

    def _create_together_service(self) -> BaseLLMService:
        """Lazy import and create Together service."""
        if os.getenv("TOGETHER_API_KEY"):
            from AgentCrew.modules.together import TogetherAIService

            return TogetherAIService()
        raise RuntimeError("API key for Together not found.")

    def _create_opencode_go_service(self) -> BaseLLMService:
        """Lazy import and create OpenCode Go service."""
        from AgentCrew.modules.custom_llm import OpenCodeService

        api_key = os.getenv("OPENCODE_API_KEY")
        if api_key:
            llm = OpenCodeService(
                base_url="https://opencode.ai/zen/go/v1",
                api_key=api_key,
                provider_name="opencode_go",
            )
            llm.model = "glm-5.1"
            return llm
        raise RuntimeError("API key for OpenCode Go not found.")

    def _create_github_copilot_service(
        self, api_key: Optional[str] = None, provider_name: str = "github_copilot"
    ) -> BaseLLMService:
        """Lazy import and create GitHub Copilot service."""
        if os.getenv("GITHUB_COPILOT_API_KEY"):
            from AgentCrew.modules.custom_llm import GithubCopilotService

            return GithubCopilotService(api_key=api_key, provider_name=provider_name)
        raise RuntimeError("API key for GitHub Copilot not found.")

    def _create_copilot_response_service(
        self, api_key: Optional[str] = None, provider_name: str = "github_copilot"
    ) -> BaseLLMService:
        """Lazy import and create Copilot Response service."""
        if os.getenv("GITHUB_COPILOT_API_KEY"):
            from AgentCrew.modules.custom_llm import GithubCopilotResponseService

            return GithubCopilotResponseService(
                api_key=api_key, provider_name=provider_name
            )
        raise RuntimeError("API key for GitHub Copilot not found.")

    def _create_custom_llm_service(
        self,
        base_url: str,
        api_key: str,
        provider_name: str,
        extra_headers: Optional[Dict] = None,
    ) -> BaseLLMService:
        """Lazy import and create Custom LLM service."""
        from AgentCrew.modules.custom_llm import CustomLLMService

        return CustomLLMService(
            base_url=base_url,
            api_key=api_key,
            provider_name=provider_name,
            extra_headers=extra_headers,
        )

    def _load_custom_provider_configs(self):
        """Loads configurations for custom LLM providers."""
        from AgentCrew.modules.config.global_config import GlobalConfig

        try:
            custom_providers = GlobalConfig().read_custom_llm_providers_config()
            for provider_config in custom_providers:
                name = provider_config.get("name")
                # We are interested in 'openai_compatible' type for CustomLLMService
                if name and provider_config.get("type") == "openai_compatible":
                    if not provider_config.get("api_base_url"):
                        logger.warning(
                            f"Custom provider '{name}' is missing 'api_base_url' and will be skipped."
                        )
                        continue
                    self.custom_provider_details[name] = {
                        "api_base_url": provider_config.get("api_base_url"),
                        "api_key": provider_config.get("api_key", ""),
                        "extra_headers": provider_config.get("extra_headers", {}),
                    }
        except Exception as e:
            logger.warning(
                f"Error loading custom LLM provider configurations for services: {e}"
            )

    def initialize_standalone_service(self, service_name: str) -> BaseLLMService:
        """
        Initializes and returns a new service instance for the specified service name.
        This does not cache the service instance in self.services.
        """
        if service_name in self.custom_provider_details:
            details = self.custom_provider_details[service_name]
            api_key = details.get("api_key", "")
            extra_headers = details.get("extra_headers", None)

            if not details.get("api_base_url"):
                raise ValueError(
                    f"Missing api_base_url for custom provider: {service_name}"
                )

            if (
                details.get("api_base_url", "")
                .rstrip("/")
                .endswith(".githubcopilot.com")
            ):
                # Special case for GitHub Copilot compatible providers
                return self._create_github_copilot_service(
                    api_key=api_key, provider_name=service_name
                )
            else:
                return self._create_custom_llm_service(
                    base_url=details["api_base_url"],
                    api_key=api_key,
                    provider_name=service_name,
                    extra_headers=extra_headers,
                )
        elif service_name in self.service_factories:
            return self.service_factories[service_name]()
        else:
            known = list(self.service_factories.keys()) + list(
                self.custom_provider_details.keys()
            )
            raise ValueError(
                f"Unknown service: {service_name}. Available services: {', '.join(sorted(list(set(known))))}"
            )

    def initialize_standalone_service_for_model(self, model: "Model") -> BaseLLMService:
        """Initialize a standalone service for the given model."""
        return self.initialize_standalone_service(model.resolved_service_name())

    def get_service(
        self, service_name: str, provider_name: Optional[str] = None
    ) -> BaseLLMService:
        """
        Get or create a service instance for the specified service name.
        Caches the instance for subsequent calls.

        Args:
            service_name: The service implementation name (e.g. "openai", "openai_response")

        Returns:
            An instance of the appropriate LLM service
        """
        if service_name in self.services:
            return self.services[service_name]

        service_instance: Optional[BaseLLMService] = None

        if service_name in self.custom_provider_details:
            details = self.custom_provider_details[service_name]
            api_key = details.get("api_key", "")
            extra_headers = details.get("extra_headers", None)

            if not details.get("api_base_url"):
                raise RuntimeError(
                    f"Configuration error: Missing api_base_url for custom provider {service_name}"
                )

            try:
                if (
                    details.get("api_base_url", "")
                    .rstrip("/")
                    .endswith(".githubcopilot.com")
                ):
                    # Special case for GitHub Copilot compatible providers
                    service_instance = self._create_github_copilot_service(
                        api_key=api_key, provider_name=service_name
                    )
                else:
                    service_instance = self._create_custom_llm_service(
                        base_url=details["api_base_url"],
                        api_key=api_key,
                        provider_name=provider_name or service_name,
                        extra_headers=extra_headers,
                    )
            except Exception as e:
                raise RuntimeError(
                    f"Failed to initialize custom provider service '{service_name}': {str(e)}"
                )

        elif service_name in self.service_factories:
            try:
                service_instance = self.service_factories[service_name]()
            except Exception as e:
                raise RuntimeError(
                    f"Failed to initialize built-in '{service_name}' service: {str(e)}"
                )

        if service_instance:
            self.services[service_name] = service_instance
            return service_instance
        else:
            known = list(self.service_factories.keys()) + list(
                self.custom_provider_details.keys()
            )
            raise ValueError(
                f"Unknown service: {service_name}. Available services: {', '.join(sorted(list(set(known))))}"
            )

    def get_service_for_model(self, model: Model) -> BaseLLMService:
        """
        Get or create a service instance for the given model,
        using the model's declared service_name.
        """
        return self.get_service(model.resolved_service_name(), model.provider)

    def get_service_for_provider(self, provider: str) -> BaseLLMService:
        """
        Get or create a service instance for the given provider name,
        by resolving the provider's default model and using its service_name.
        This preserves backward compatibility when only a provider string is known.
        """
        registry = ModelRegistry.get_instance()
        models = registry.get_models_by_provider(provider)
        if models:
            default_model = next((m for m in models if m.default), models[0])
            return self.get_service_for_model(default_model)
        # Fallback: treat provider as a direct service name
        return self.get_service(provider)

    def set_model(self, service_name: str, model_id: str) -> bool:
        """
        Set the model for a specific service.

        Args:
            service_name: The service implementation name
            model_id: The model ID to use

        Returns:
            True if successful, False otherwise
        """
        service = self.get_service(service_name)
        if hasattr(service, "model"):
            service.model = model_id
            self.apply_model_defaults(service, service_name, model_id)
            return True
        return False

    def set_model_for_model(self, model: Model):
        """Set the model on the service instance declared by the given model."""
        service = self.get_service_for_model(model)
        service.model = model.id
        self.apply_model_defaults(service, model.provider, model.id)

    def apply_model_defaults(
        self, service: BaseLLMService, provider: str, model_id: str
    ) -> None:
        full_model_id = f"{provider}/{model_id}"
        model = ModelRegistry.get_instance().get_model(full_model_id)
        if not model or not hasattr(service, "reasoning_effort"):
            return

        if model.default_reasoning is not None:
            setattr(service, "reasoning_effort", model.default_reasoning)
