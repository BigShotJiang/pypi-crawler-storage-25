"""Video processing utilities."""
