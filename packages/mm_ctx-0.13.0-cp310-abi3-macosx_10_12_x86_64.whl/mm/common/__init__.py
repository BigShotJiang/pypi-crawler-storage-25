"""Shared utilities for mm."""
