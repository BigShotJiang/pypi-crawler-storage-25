"""MCP server exposing memorized as a small, scope-gated set of tools.

Launched by ``memorized mcp`` (or ``python -m memorized mcp``). Defaults to
stdio transport; ``--transport streamable-http`` (or ``sse``) runs it as an
HTTP server instead.

Env vars injected at launch:

- ``MEMORIZED_BASE_URL``      (default ``http://127.0.0.1:8765``)
- ``MEMORIZED_API_TOKEN``     (required — per-user bearer; user_id is
                                derived from the token, so one holder
                                cannot post as another user)
- ``MEMORIZED_WORKSPACE_ID``  (optional — pin to a workspace)
- ``MEMORIZED_CHANNEL_ID``    (optional — pin to a channel; needs
                                WORKSPACE_ID)
- ``MEMORIZED_USER_ID``       (optional — echoed into write bodies, but
                                ignored server-side)

The exposed tool set adapts to the binding depth (principle of least
authority — the narrower the scope, the fewer the tools):

- **L0** (only ``API_TOKEN``): workspace-plane discovery/creation —
  ``list_workspaces``, ``create_workspace``.
- **L1** (+ ``WORKSPACE_ID``): channel-plane + append-only messaging —
  ``list_channels``, ``create_channel``, ``share``, ``read``, ``comment``,
  ``list_comments`` (every per-call tool requires an explicit
  ``channel_id`` argument).
- **L2** (+ ``CHANNEL_ID``): pinned agent — ``share``, ``read``,
  ``comment``, ``list_comments`` (``channel_id`` defaults from env;
  channel CRUD is hidden because the agent cannot act on siblings).

``edit`` / ``delete`` (messages), ``delete_channel`` and
``delete_workspace`` are deliberately **not** exposed — the shared log is
append-only from the agent's perspective, preserving a clean audit trail
and preventing one agent from silently rewriting another's findings.
Corrections should be posted as a new ``share`` or a ``comment``; hard
mutations stay with human admins (CLI / admin UI).
"""
from __future__ import annotations

import asyncio
import atexit
import functools
import os
from collections.abc import Awaitable, Callable
from typing import Annotated, Any, Literal, TypeVar

Transport = Literal["stdio", "sse", "streamable-http"]

from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.exceptions import ToolError
from pydantic import Field

from memorized.client import AsyncMemorizedClient
from memorized.exceptions import MemorizedError
from memorized.schemas import (
    ChannelOut,
    CommentOut,
    MessageCreateOut,
    MessageOut,
    WorkspaceOut,
)

BASE_URL = os.environ.get("MEMORIZED_BASE_URL", "http://127.0.0.1:8765")
WORKSPACE_ID = os.environ.get("MEMORIZED_WORKSPACE_ID")
CHANNEL_ID = os.environ.get("MEMORIZED_CHANNEL_ID")
USER_ID = os.environ.get("MEMORIZED_USER_ID")
API_TOKEN = os.environ.get("MEMORIZED_API_TOKEN")

mcp = FastMCP("memorized")


def _validate_env() -> None:
    """Check the launch env and raise a clear error if it's misconfigured.

    Deferred to ``main()`` (not import time) so the module can be
    imported by sibling CLI entry points (``memorized server``,
    ``memorized admin``) that do not care about these vars.
    """
    if API_TOKEN is None:
        raise RuntimeError(
            "MEMORIZED_API_TOKEN must be set before memorized mcp starts — "
            "mint a per-user token at /ui/admin/tokens/new/ or via "
            "`memorized admin create-token`"
        )
    if CHANNEL_ID is not None and WORKSPACE_ID is None:
        raise RuntimeError(
            "MEMORIZED_CHANNEL_ID is set but MEMORIZED_WORKSPACE_ID is not — "
            "a channel always lives inside a workspace"
        )


class _ClientHolder:
    """Process-wide slot for the lazily-built MCP client.

    A class attribute avoids the ``global`` statement that ruff (and most
    style guides) discourage, while keeping the same "construct once,
    reuse forever" semantics.
    """

    instance: AsyncMemorizedClient | None = None

    @classmethod
    async def close(cls) -> None:
        if cls.instance is not None:
            await cls.instance.aclose()
            cls.instance = None


async def _get_client() -> AsyncMemorizedClient:
    if _ClientHolder.instance is None:
        assert WORKSPACE_ID is not None  # guarded by tool-registration gate
        _ClientHolder.instance = AsyncMemorizedClient(
            BASE_URL, WORKSPACE_ID, CHANNEL_ID,
            user_id=USER_ID, api_token=API_TOKEN,
        )
    return _ClientHolder.instance


def _cleanup_client() -> None:
    if _ClientHolder.instance is not None:
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(_ClientHolder.close())
            else:
                loop.run_until_complete(_ClientHolder.close())
        except RuntimeError:
            # No event loop available at exit — connection will be GC'd.
            pass


atexit.register(_cleanup_client)


T = TypeVar("T")


def _tool_errors(
    fn: Callable[..., Awaitable[T]],
) -> Callable[..., Awaitable[T]]:
    """Turn every ``MemorizedError`` / ``ValueError`` into a FastMCP
    ``ToolError`` so the MCP client gets a clean ``isError=true`` response
    with the structured body as the error message — and doesn't get a raw
    stack trace from a pydantic validation mismatch.
    """

    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> T:
        try:
            return await fn(*args, **kwargs)
        except MemorizedError as exc:
            body = exc.to_body().model_dump(mode="json")
            raise ToolError(
                f"{body.get('code', 'error')}: {body.get('message', str(exc))}"
            ) from exc
        except ValueError as exc:
            raise ToolError(f"bad_request: {exc}") from exc
        except Exception as exc:
            # Anything else (transport hiccup, pydantic response-model
            # mismatch, etc.) would otherwise hit FastMCP's default handler
            # and collapse into an opaque "Internal server error." on the
            # client side. Surface the exception class + message so the
            # caller has something to act on.
            raise ToolError(f"unexpected: {type(exc).__name__}: {exc}") from exc

    return wrapper


_CHANNEL_ID_FIELD = Field(
    description=(
        "Channel to target inside this workspace. Optional if the MCP "
        "process was launched with MEMORIZED_CHANNEL_ID set; required "
        "otherwise. Call list_channels() first if you don't know which "
        "channels exist."
    ),
)

_MSG_ID_FIELD = Field(
    description=(
        "Id of an existing message, as returned by share() or as the "
        "'id' field on a MessageOut from read()."
    ),
    ge=1,
)


# ---------------------------------------------------------------------------
# L0: workspace-plane tools (registered only when WORKSPACE_ID is unset)
# ---------------------------------------------------------------------------


if WORKSPACE_ID is None:

    @mcp.tool()
    @_tool_errors
    async def list_workspaces() -> list[WorkspaceOut]:
        """List every workspace this token can see.

        Use this on startup when the MCP process was launched without a
        default ``MEMORIZED_WORKSPACE_ID``. To actually post or read
        messages you still need to relaunch with the picked id bound into
        the env, since the per-channel tools are not registered at this
        level.
        """
        return await AsyncMemorizedClient.list_workspaces(
            BASE_URL, api_token=API_TOKEN,
        )

    @mcp.tool()
    @_tool_errors
    async def create_workspace(
        id: Annotated[
            str,
            Field(
                description=(
                    "Short, URL-safe identifier for the new workspace "
                    "(letters, digits, '_', '-', '.'). Example: 'defcon-2026'."
                ),
                min_length=1,
                max_length=64,
                pattern=r"^[A-Za-z0-9_\-\.]+$",
            ),
        ],
        title: Annotated[
            str | None,
            Field(description="Optional human-readable title; falls back to the id."),
        ] = None,
        description: Annotated[
            str | None,
            Field(description="Optional short description of what the workspace is for."),
        ] = None,
    ) -> WorkspaceOut:
        """Create a new workspace.

        Requires the token to have ``workspace:write`` (or higher).
        Tokens scoped to a specific workspace cannot create new ones —
        the server returns a structured ``forbidden`` error.
        """
        metadata: dict[str, Any] = {}
        if title is not None:
            metadata["title"] = title
        if description is not None:
            metadata["description"] = description
        return await AsyncMemorizedClient.create_workspace(
            BASE_URL, id, metadata=metadata, api_token=API_TOKEN,
        )


# ---------------------------------------------------------------------------
# L1+: channel-plane tools (registered when WORKSPACE_ID is set but
# CHANNEL_ID is not — a pinned-to-channel agent cannot list siblings)
# ---------------------------------------------------------------------------


if WORKSPACE_ID is not None and CHANNEL_ID is None:

    @mcp.tool()
    @_tool_errors
    async def list_channels() -> list[ChannelOut]:
        """List every channel in this workspace the caller can see.

        Use this on startup to discover what channels exist. Pick a
        channel id from the result and pass it as ``channel_id`` to
        ``share`` / ``read`` / ``comment`` / ``list_comments``.
        """
        return await AsyncMemorizedClient.list_channels(
            BASE_URL, WORKSPACE_ID, api_token=API_TOKEN,
        )

    @mcp.tool()
    @_tool_errors
    async def create_channel(
        id: Annotated[
            str,
            Field(
                description=(
                    "Short, URL-safe identifier for the new channel "
                    "(letters, digits, '_', '-', '.'). Example: 'web-chall-5'."
                ),
                min_length=1,
                max_length=64,
                pattern=r"^[A-Za-z0-9_\-\.]+$",
            ),
        ],
        title: Annotated[
            str | None,
            Field(description="Optional human-readable title; falls back to the id."),
        ] = None,
        description: Annotated[
            str | None,
            Field(description="Optional short description of what the channel is for."),
        ] = None,
    ) -> ChannelOut:
        """Create a new channel in this workspace.

        Requires the token to have ``channel:write`` (or higher) on this
        workspace. A token scoped to a single channel cannot create new
        ones — the server returns a structured ``forbidden`` error.
        """
        metadata: dict[str, Any] = {}
        if title is not None:
            metadata["title"] = title
        if description is not None:
            metadata["description"] = description
        return await AsyncMemorizedClient.create_channel(
            BASE_URL, WORKSPACE_ID, id, metadata=metadata, api_token=API_TOKEN,
        )


# ---------------------------------------------------------------------------
# L1+: message + comment tools (append-only; registered when WORKSPACE_ID
# is set — channel_id is optional iff CHANNEL_ID env is set)
# ---------------------------------------------------------------------------


if WORKSPACE_ID is not None:

    @mcp.tool()
    @_tool_errors
    async def share(
        text: Annotated[
            str,
            Field(
                description=(
                    "A meaningful finding you want the whole team to know about. "
                    "Only call this when you have real progress worth pinning for "
                    "teammates who start later or restart after a failure — a "
                    "significant finding, validated result, confirmed dead-end, "
                    "or decision worth preserving. Do NOT post trivial status "
                    "updates, thinking-out-loud, or acknowledgements. Treat the "
                    "log as append-only: to correct an earlier finding, post a "
                    "new share() that references the older message, or use "
                    "comment() to annotate it."
                ),
                min_length=1,
            ),
        ],
        tags: Annotated[
            list[str] | None,
            Field(
                description=(
                    "Optional free-form tags, e.g. ['finding'] or "
                    "['result','ingestion']."
                ),
            ),
        ] = None,
        confidence: Annotated[
            float | None,
            Field(
                description=(
                    "How confident you are in this information, from 0.0 (guess) "
                    "to 1.0 (certain). Omit if unknown."
                ),
                ge=0.0,
                le=1.0,
            ),
        ] = None,
        channel_id: Annotated[str | None, _CHANNEL_ID_FIELD] = None,
    ) -> MessageCreateOut:
        """Post a message to a channel in this workspace.

        Every agent assigned to the target channel — including ones that
        start later or restart after a crash — will be able to read it
        back via ``read``. This is the only way to hand knowledge to a
        future teammate, so use it when (and only when) you have
        something worth preserving.
        """
        client = await _get_client()
        return await client.share(
            text, tags=tags, confidence=confidence, channel_id=channel_id,
        )

    @mcp.tool()
    @_tool_errors
    async def read(
        since: Annotated[
            int,
            Field(
                description=(
                    "Last message id you have already processed. Pass 0 to read "
                    "the full history from the start of this channel — do this "
                    "once when your agent starts up, then track the max id you "
                    "have seen and poll with that value."
                ),
                ge=0,
            ),
        ] = 0,
        limit: Annotated[int, Field(ge=1, le=2000)] = 500,
        q: Annotated[
            str | None,
            Field(
                description=(
                    "Optional full-text search over message text (SQLite FTS5, "
                    "prefix-matching each whitespace-separated token). Omit to "
                    "skip the text filter."
                ),
                max_length=500,
            ),
        ] = None,
        tags: Annotated[
            list[str] | None,
            Field(
                description=(
                    "Optional tag filter — only messages tagged with ALL of "
                    "these tags are returned (AND semantics). Omit to skip "
                    "the tag filter."
                ),
            ),
        ] = None,
        channel_id: Annotated[str | None, _CHANNEL_ID_FIELD] = None,
    ) -> list[MessageOut]:
        """Read messages from a channel in this workspace.

        Returns messages with ``id > since``, in ascending id order
        (chronological). Call once with ``since=0`` on startup to catch
        up on what your teammates have found; then poll periodically
        with the largest id you have seen.

        Use ``q`` and/or ``tags`` to narrow the window down to a
        specific thread — cheaper than pulling full history and
        filtering client-side.
        """
        client = await _get_client()
        return await client.read(
            since=since, limit=limit, q=q, tags=tags, channel_id=channel_id,
        )

    @mcp.tool()
    @_tool_errors
    async def comment(
        msg_id: Annotated[int, _MSG_ID_FIELD],
        text: Annotated[
            str,
            Field(
                description=(
                    "Annotation on an existing message — a cross-reference, "
                    "correction, verification result, or discussion reply. "
                    "Use this instead of posting a new share() when you're "
                    "reacting to a specific prior finding; it keeps the main "
                    "stream clean. If you're introducing a new finding of "
                    "your own, use share() instead."
                ),
                min_length=1,
            ),
        ],
        channel_id: Annotated[str | None, _CHANNEL_ID_FIELD] = None,
    ) -> CommentOut:
        """Attach a comment to an existing message.

        Comments are pinned to one message and do not advance the main
        ``read`` cursor — use ``list_comments(msg_id)`` to retrieve the
        thread. Ideal for agent-to-agent discussion without cluttering
        the shared finding stream.
        """
        client = await _get_client()
        return await client.add_comment(msg_id, text, channel_id=channel_id)

    @mcp.tool()
    @_tool_errors
    async def list_comments(
        msg_id: Annotated[int, _MSG_ID_FIELD],
        channel_id: Annotated[str | None, _CHANNEL_ID_FIELD] = None,
    ) -> list[CommentOut]:
        """List every comment attached to a message, in chronological order.

        Useful after ``read`` surfaces a finding that has active
        discussion — pull the thread to see whether teammates have
        verified, corrected, or built on it.
        """
        client = await _get_client()
        return await client.list_comments(msg_id, channel_id=channel_id)


def main(
    transport: Transport = "stdio",
    host: str | None = None,
    port: int | None = None,
) -> None:
    """Entry point for ``memorized mcp``. Defaults to stdio transport."""
    _validate_env()
    if host is not None:
        mcp.settings.host = host
    if port is not None:
        mcp.settings.port = port
    mcp.run(transport=transport)


if __name__ == "__main__":
    main()
