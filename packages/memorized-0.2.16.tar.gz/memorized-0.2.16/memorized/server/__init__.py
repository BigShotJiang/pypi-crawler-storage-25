"""FastAPI app factory + unified exception handling.

``create_app(settings)`` builds a fully-wired FastAPI application with:
  - SQLite database bootstrapped via lifespan
  - four routers (workspaces + channels + messages + admin)
  - static Web UI mounted at ``/ui/``
  - a single pipeline that renders every error — ours, pydantic's, Starlette's,
    unhandled — into the shared ``ErrorBody`` envelope

Authentication is no longer a middleware — it's a per-route
``Depends(current_identity)`` (see ``auth.py``) that both resolves the
caller and enforces fine-grained permissions.
"""
from __future__ import annotations

import logging
import time
import traceback
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from http import HTTPStatus
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from memorized.exceptions import MemorizedError, ValidationError
from memorized.schemas import (
    ErrorBody,
    ErrorCode,
    ErrorResponse,
    FieldError,
    HealthIdentityOut,
    HealthOut,
)
from memorized.server.auth import OptionalIdentityDep
from memorized.server.config import Settings
from memorized.server.db import Database
from memorized.server.routes import (
    admin_router,
    channels_router,
    messages_router,
    workspaces_router,
)

STATIC_DIR = Path(__file__).parent / "static"


def _server_version() -> str:
    """Runtime version of the installed ``memorized`` distribution.

    Falls back to ``"dev"`` when run from a source tree without the
    package installed (e.g. ``python -m memorized`` with only the repo on
    PYTHONPATH). The Docker image and ``pip install memorized`` always
    get the real version.
    """
    try:
        return _pkg_version("memorized")
    except PackageNotFoundError:
        return "dev"

_STATUS_TO_CODE: dict[int, ErrorCode] = {
    HTTPStatus.NOT_FOUND: ErrorCode.not_found,
    HTTPStatus.METHOD_NOT_ALLOWED: ErrorCode.method_not_allowed,
    HTTPStatus.BAD_REQUEST: ErrorCode.bad_request,
}


def _envelope(body: ErrorBody) -> JSONResponse:
    return JSONResponse(
        status_code=body.status,
        content=ErrorResponse(error=body).model_dump(mode="json"),
    )


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings()
    database = Database(settings.db_path)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        await database.migrate()
        app.state.db = database
        app.state.settings = settings
        try:
            yield
        finally:
            await database.dispose()

    app = FastAPI(title="memorized", version=_server_version(), lifespan=lifespan)
    logger = logging.getLogger("memorized.server")

    @app.exception_handler(MemorizedError)
    async def _memorized_error(_: Request, exc: MemorizedError) -> JSONResponse:
        return _envelope(exc.to_body())

    @app.exception_handler(RequestValidationError)
    async def _request_validation(
        _: Request, exc: RequestValidationError
    ) -> JSONResponse:
        # Reshape pydantic errors into compact FieldError entries. We drop
        # `input` because it can echo back large request bodies, which is
        # noise in an LLM's context window.
        fields = [
            FieldError(
                loc=".".join(str(x) for x in err["loc"]),
                msg=err["msg"],
                type=err["type"],
            )
            for err in exc.errors()
        ]
        err = ValidationError.from_fields(
            f"Request validation failed ({len(fields)} field error(s)).",
            fields,
        )
        return _envelope(err.to_body())

    @app.exception_handler(StarletteHTTPException)
    async def _starlette_http(_: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = _STATUS_TO_CODE.get(exc.status_code, ErrorCode.bad_request)
        message = exc.detail if isinstance(exc.detail, str) else str(exc.detail)
        return _envelope(
            ErrorBody(code=code, message=message, status=exc.status_code)
        )

    @app.exception_handler(Exception)
    async def _unhandled(request: Request, exc: Exception) -> JSONResponse:
        tb = traceback.format_exc()
        logger.error("Unhandled error on %s %s\n%s", request.method, request.url.path, tb)
        # Surface the exception type + truncated str() in the message so MCP
        # clients and curl users see something like "OperationalError: no such
        # column: messages.text" instead of a bare "Internal server error."
        # SQLAlchemy / pydantic / builtin exceptions don't echo request bodies
        # in their str(), so this is safe to return without debug mode.
        summary = f"{type(exc).__name__}: {str(exc)[:200]}"
        context: dict[str, object] = {"exception_type": type(exc).__name__}
        if settings.debug:
            context["traceback"] = tb.splitlines()
        return _envelope(
            ErrorBody(
                code=ErrorCode.internal_error,
                message=f"Internal server error: {summary}",
                status=HTTPStatus.INTERNAL_SERVER_ERROR,
                hint=(
                    "This is a bug in the server. Set MEMORIZED_DEBUG=true to see "
                    "the full traceback in the response body, or check the server logs."
                ),
                context=context,
            )
        )

    app.include_router(workspaces_router)
    app.include_router(channels_router)
    app.include_router(messages_router)
    app.include_router(admin_router)

    @app.get("/healthz", response_model=HealthOut, tags=["health"])
    async def _healthz(identity: OptionalIdentityDep) -> HealthOut:
        """Public health probe. Identity echoes the caller when a valid
        token is presented — lets the UI status bar show "signed in as X"
        and gate UI affordances to what the server would actually
        accept. Server-side ``require(...)`` checks remain authoritative."""
        return HealthOut(
            version=_server_version(),
            time=time.time(),
            identity=(
                HealthIdentityOut(
                    user_id=identity.user_id,
                    is_super_admin=identity.is_super_admin,
                    permissions=identity.permissions,
                    scope=identity.scope,
                )
                if identity is not None
                else None
            ),
        )

    # The Astro frontend (./frontend/) builds into STATIC_DIR and serves
    # both the main workspace UI at /ui/ and the admin routes at
    # /ui/admin/*. A single mount handles everything — plus an SPA
    # fallback below so client-side routes like /ui/w/{ws}/c/{ch}/ resolve
    # to the same shell.
    if STATIC_DIR.exists():
        index_html = STATIC_DIR / "index.html"

        # SPA fallback for client-routed paths under /ui/w/**. Declared
        # before the mount so it takes precedence; otherwise StaticFiles
        # would 404 on these unknown paths.
        @app.get("/ui/w/{rest:path}", include_in_schema=False)
        async def _ui_spa_shell(rest: str) -> FileResponse:
            del rest
            return FileResponse(index_html)

        app.mount("/ui", StaticFiles(directory=STATIC_DIR, html=True), name="ui")

    @app.get("/", include_in_schema=False)
    async def _root() -> RedirectResponse:
        return RedirectResponse("/ui/")

    return app


__all__ = ["Settings", "create_app"]
