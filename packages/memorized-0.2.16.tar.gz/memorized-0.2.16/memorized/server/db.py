"""SQLite persistence: engine, tables, and CRUD helpers.

The ``Database`` class owns the async engine + session maker. Tables form a
four-level hierarchy: ``Workspace`` (top-level container) → ``Channel``
(one shared chat stream) → ``Message`` → ``Comment``. The CRUD helpers are
plain async functions so unit tests can drive them against an in-memory
aiosqlite DB without needing FastAPI.

Schema evolution is managed by alembic (see ``alembic/`` in the repo
root). ``Database.migrate()`` runs ``alembic upgrade head`` against the
SQLite file on server boot, adopting old pre-alembic deployments by
stamping them at the baseline revision on first run.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import secrets
import time
from pathlib import Path
from typing import Any

from sqlalchemy import JSON, Column, ForeignKey, UniqueConstraint, create_engine, inspect, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.pool import NullPool
from sqlmodel import Field, SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession

from memorized.exceptions import NotFoundError

_ALEMBIC_INI = Path(__file__).resolve().parent.parent.parent / "alembic.ini"
_BASELINE_REVISION = "0001"

# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------


class Workspace(SQLModel, table=True):
    """Top-level container. Groups related channels (e.g. "defcon-2026")."""

    __tablename__ = "workspaces"

    id: str = Field(primary_key=True)
    meta: dict[str, Any] = Field(default_factory=dict, sa_column=Column("metadata", JSON))
    created_at: float = Field(default_factory=time.time)


class Channel(SQLModel, table=True):
    """One shared chat stream scoped to a workspace. Holds messages.

    Uses a surrogate ``pk`` so messages can FK to a single integer. The
    business identifier is ``(workspace_id, id)`` — unique together, but
    the same ``id`` (e.g. ``"web-chall-5"``) can appear in different
    workspaces.
    """

    __tablename__ = "channels"
    __table_args__ = (UniqueConstraint("workspace_id", "id", name="uq_channels_workspace_id"),)

    pk: int | None = Field(default=None, primary_key=True)
    workspace_id: str = Field(
        sa_column=Column(
            ForeignKey("workspaces.id", ondelete="CASCADE"),
            index=True,
            nullable=False,
        )
    )
    id: str = Field(index=True)
    meta: dict[str, Any] = Field(default_factory=dict, sa_column=Column("metadata", JSON))
    created_at: float = Field(default_factory=time.time)


class Message(SQLModel, table=True):
    """A single chat message posted to a channel.

    The integer primary key doubles as the monotonic cursor used by clients:
    ``GET …/messages?since=<id>`` returns every message with ``id > since``,
    in ascending order, so a restarted agent can replay the channel history
    from ``since=0`` and then poll with the max id it has seen.
    """

    __tablename__ = "messages"

    id: int | None = Field(default=None, primary_key=True)
    channel_pk: int = Field(
        sa_column=Column(
            ForeignKey("channels.pk", ondelete="CASCADE"),
            index=True,
            nullable=False,
        )
    )
    user_id: str
    text: str
    tags: list[str] = Field(default_factory=list, sa_column=Column(JSON))
    confidence: float | None = Field(default=None)
    ts: float = Field(default_factory=time.time)
    edited_at: float | None = Field(default=None)
    edited_by: str | None = Field(default=None)
    deleted: bool = Field(default=False)
    deleted_by: str | None = Field(default=None)


class Comment(SQLModel, table=True):
    """A comment / annotation on a message."""

    __tablename__ = "comments"

    id: int | None = Field(default=None, primary_key=True)
    message_id: int = Field(
        sa_column=Column(
            ForeignKey("messages.id", ondelete="CASCADE"),
            index=True,
            nullable=False,
        )
    )
    user_id: str
    text: str
    ts: float = Field(default_factory=time.time)


class AuditLog(SQLModel, table=True):
    """Immutable record of admin-triggered mutations.

    Written by super-admin token endpoints so operators can answer "who
    issued/revoked which credential, and when." Queryable at
    ``GET /admin/audit``; rows are never updated or deleted.
    """

    __tablename__ = "audit_logs"

    id: int | None = Field(default=None, primary_key=True)
    ts: float = Field(default_factory=time.time, index=True)
    actor_id: str = Field(index=True)
    action: str = Field(index=True)
    target: str | None = Field(default=None, index=True)
    context: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))


class UserCredential(SQLModel, table=True):
    """A per-user API token.

    ``token_hash`` is the primary key (sha256 of the plaintext secret — the
    plaintext itself is never persisted). ``scope`` and ``permissions`` are
    JSON blobs so the schema can grow without a migration per new resource
    or level:

    - ``scope`` = ``{"workspace_ids": ["a","b"]}`` or
      ``{"workspace_ids": "*"}`` (no restriction).
    - ``permissions`` = ``{"workspace": "read", "channel": "write",
      "message": "write", "comment": "write"}``; unlisted resources default
      to ``"none"``.
    """

    __tablename__ = "user_credentials"

    token_hash: str = Field(primary_key=True)
    user_id: str = Field(unique=True, index=True)
    name: str | None = Field(default=None)
    scope: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    permissions: dict[str, Any] = Field(default_factory=dict, sa_column=Column(JSON))
    expires_at: float | None = Field(default=None)
    created_at: float = Field(default_factory=time.time)
    revoked_at: float | None = Field(default=None)


# ---------------------------------------------------------------------------
# Database connection manager
# ---------------------------------------------------------------------------


_PRAGMAS = [
    "PRAGMA journal_mode = WAL",
    "PRAGMA synchronous = NORMAL",
    "PRAGMA foreign_keys = ON",
]

_FTS_STATEMENTS = [
    """
    CREATE VIRTUAL TABLE IF NOT EXISTS messages_fts USING fts5(
        text,
        content='messages',
        content_rowid='id',
        tokenize='porter unicode61'
    )
    """,
    """
    CREATE TRIGGER IF NOT EXISTS messages_ai AFTER INSERT ON messages BEGIN
        INSERT INTO messages_fts(rowid, text) VALUES (new.id, new.text);
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS messages_ad AFTER DELETE ON messages BEGIN
        INSERT INTO messages_fts(messages_fts, rowid, text)
            VALUES('delete', old.id, old.text);
    END
    """,
    """
    CREATE TRIGGER IF NOT EXISTS messages_au AFTER UPDATE ON messages BEGIN
        INSERT INTO messages_fts(messages_fts, rowid, text)
            VALUES('delete', old.id, old.text);
        INSERT INTO messages_fts(rowid, text) VALUES (new.id, new.text);
    END
    """,
    "INSERT INTO messages_fts(messages_fts) VALUES('rebuild')",
]


class Database:
    """Owns the async engine + session maker. One instance per running app."""

    def __init__(self, db_path: Path | str) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._engine: AsyncEngine = create_async_engine(
            f"sqlite+aiosqlite:///{self.db_path}",
            future=True,
            echo=False,
            poolclass=NullPool,
        )
        self._sessionmaker: async_sessionmaker[AsyncSession] = async_sessionmaker(
            self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
        )

    async def migrate(self) -> None:
        """Bring the DB to the latest schema, then set up FTS + pragmas.

        Schema DDL comes from alembic migrations in ``alembic/versions/``;
        virtual-table + trigger DDL is idempotent and lives here because
        it's per-connection session state, not versioned schema.
        """
        # Alembic's command API is sync; running in a thread keeps the
        # async lifespan clean and stops uvicorn's event loop blocking.
        await asyncio.to_thread(self._run_alembic_upgrade)
        async with self._engine.begin() as conn:
            for stmt in _PRAGMAS:
                await conn.exec_driver_sql(stmt)
            for stmt in _FTS_STATEMENTS:
                await conn.exec_driver_sql(stmt)

    def _run_alembic_upgrade(self) -> None:
        """Synchronous alembic bootstrap. Called from ``migrate()``.

        Adopts pre-alembic deployments: when the DB has the old tables but
        no ``alembic_version`` row, we stamp it at the baseline revision
        before applying any new migrations. Fresh DBs run the full chain
        from scratch.
        """
        from alembic import command
        from alembic.config import Config as AlembicConfig
        from alembic.runtime.migration import MigrationContext
        from alembic.script import ScriptDirectory

        cfg = AlembicConfig(str(_ALEMBIC_INI))
        sync_url = f"sqlite:///{self.db_path}"
        cfg.attributes["db_url"] = sync_url

        sync_engine = create_engine(sync_url, poolclass=NullPool)
        try:
            with sync_engine.connect() as conn:
                existing = set(inspect(conn).get_table_names())
            if "alembic_version" not in existing and "workspaces" in existing:
                # Legacy DB predates alembic adoption — pin it at the baseline.
                command.stamp(cfg, _BASELINE_REVISION)
            command.upgrade(cfg, "head")

            # Fail fast when the DB's stamped heads don't match the shipped
            # scripts. Catches the "alembic thinks it's at head but a prior
            # run was killed mid-migration" case that otherwise surfaces as
            # opaque 500s from missing tables/columns on the first request.
            script_heads = set(ScriptDirectory.from_config(cfg).get_heads())
            with sync_engine.connect() as conn:
                current_heads = set(
                    MigrationContext.configure(conn).get_current_heads()
                )
            if current_heads != script_heads:
                raise RuntimeError(
                    f"Alembic head mismatch after upgrade: "
                    f"db={sorted(current_heads)} scripts={sorted(script_heads)} "
                    f"db_path={self.db_path}. Delete the DB or run "
                    f"`alembic upgrade head` manually."
                )
        finally:
            sync_engine.dispose()

    async def dispose(self) -> None:
        await self._engine.dispose()

    def session(self) -> AsyncSession:
        return self._sessionmaker()


# ---------------------------------------------------------------------------
# Workspace CRUD
# ---------------------------------------------------------------------------


async def create_workspace(
    session: AsyncSession,
    *,
    id: str,
    metadata: dict[str, Any] | None = None,
) -> Workspace:
    stmt = select(Workspace).where(Workspace.id == id)
    existing = (await session.exec(stmt)).first()
    if existing is not None:
        return existing
    ws = Workspace(id=id, meta=metadata or {})
    session.add(ws)
    await session.flush()
    return ws


async def list_workspaces(session: AsyncSession) -> list[Workspace]:
    stmt = select(Workspace).order_by(Workspace.created_at.desc())
    return list((await session.exec(stmt)).all())


async def list_workspaces_with_counts(
    session: AsyncSession,
) -> list[tuple[Workspace, int]]:
    """Return all workspaces with their channel counts, newest first."""
    stmt = text(
        "SELECT w.id, w.metadata, w.created_at, "
        "  COUNT(c.pk) AS cnt "
        "FROM workspaces w "
        "LEFT JOIN channels c ON c.workspace_id = w.id "
        "GROUP BY w.id "
        "ORDER BY w.created_at DESC"
    )
    rows = (await session.exec(stmt)).all()  # type: ignore[arg-type]
    results: list[tuple[Workspace, int]] = []
    for row in rows:
        ws = Workspace(
            id=row[0],
            meta=json.loads(row[1]) if isinstance(row[1], str) else row[1],
            created_at=row[2],
        )
        results.append((ws, int(row[3])))
    return results


async def ensure_workspace(session: AsyncSession, workspace_id: str) -> None:
    """Raise ``NotFoundError`` if the workspace does not exist."""
    stmt = select(Workspace.id).where(Workspace.id == workspace_id)
    if (await session.exec(stmt)).first() is None:
        raise NotFoundError.workspace(workspace_id)


async def delete_workspace(
    session: AsyncSession,
    *,
    workspace_id: str,
) -> None:
    """Hard-delete a workspace and everything scoped under it.

    Cascades via FK ``ON DELETE CASCADE``: channels, messages, and
    comments all go with it. Raises ``NotFoundError`` if the workspace
    does not exist.
    """
    stmt = select(Workspace).where(Workspace.id == workspace_id)
    ws = (await session.exec(stmt)).first()
    if ws is None:
        raise NotFoundError.workspace(workspace_id)
    await session.delete(ws)
    await session.flush()


# ---------------------------------------------------------------------------
# Channel CRUD
# ---------------------------------------------------------------------------


async def create_channel(
    session: AsyncSession,
    *,
    workspace_id: str,
    id: str,
    metadata: dict[str, Any] | None = None,
) -> Channel:
    """Create a channel inside a workspace. Idempotent on ``(workspace_id, id)``.

    Raises ``NotFoundError.workspace`` if the parent workspace does not exist.
    """
    await ensure_workspace(session, workspace_id)
    stmt = select(Channel).where(
        Channel.workspace_id == workspace_id, Channel.id == id
    )
    existing = (await session.exec(stmt)).first()
    if existing is not None:
        return existing
    ch = Channel(workspace_id=workspace_id, id=id, meta=metadata or {})
    session.add(ch)
    await session.flush()
    return ch


async def list_channels_with_counts(
    session: AsyncSession,
    *,
    workspace_id: str,
    limit: int | None = None,
    offset: int = 0,
) -> list[tuple[Channel, int]]:
    """Return channels in a workspace with non-deleted message counts."""
    await ensure_workspace(session, workspace_id)
    sql = (
        "SELECT c.pk, c.workspace_id, c.id, c.metadata, c.created_at, "
        "  COALESCE(SUM(CASE WHEN msg.deleted = 0 THEN 1 ELSE 0 END), 0) AS cnt "
        "FROM channels c "
        "LEFT JOIN messages msg ON msg.channel_pk = c.pk "
        "WHERE c.workspace_id = :workspace_id "
        "GROUP BY c.pk "
        "ORDER BY c.created_at DESC"
    )
    params: dict[str, object] = {"workspace_id": workspace_id}
    if limit is not None:
        sql += " LIMIT :limit OFFSET :offset"
        params["limit"] = limit
        params["offset"] = offset
    stmt = text(sql)
    conn = await session.connection()
    rows = (await conn.execute(stmt, params)).fetchall()
    results: list[tuple[Channel, int]] = []
    for row in rows:
        ch = Channel(
            pk=row[0],
            workspace_id=row[1],
            id=row[2],
            meta=json.loads(row[3]) if isinstance(row[3], str) else row[3],
            created_at=row[4],
        )
        results.append((ch, int(row[5])))
    return results


async def ensure_channel(
    session: AsyncSession,
    *,
    workspace_id: str,
    channel_id: str,
) -> Channel:
    """Return the channel or raise ``NotFoundError``.

    Raises ``workspace_not_found`` if the workspace is missing,
    ``channel_not_found`` if the workspace exists but the channel doesn't.
    """
    await ensure_workspace(session, workspace_id)
    stmt = select(Channel).where(
        Channel.workspace_id == workspace_id, Channel.id == channel_id
    )
    ch = (await session.exec(stmt)).first()
    if ch is None:
        raise NotFoundError.channel(workspace_id, channel_id)
    return ch


async def delete_channel(
    session: AsyncSession,
    *,
    workspace_id: str,
    channel_id: str,
) -> None:
    """Hard-delete a channel and all messages/comments inside it."""
    ch = await ensure_channel(
        session, workspace_id=workspace_id, channel_id=channel_id
    )
    await session.delete(ch)
    await session.flush()


# ---------------------------------------------------------------------------
# Message CRUD (all scoped by channel_pk)
# ---------------------------------------------------------------------------


async def create_message(
    session: AsyncSession,
    *,
    channel_pk: int,
    user_id: str,
    text: str,
    tags: list[str],
    confidence: float | None = None,
) -> Message:
    msg = Message(
        channel_pk=channel_pk,
        user_id=user_id,
        text=text,
        tags=tags,
        confidence=confidence,
    )
    session.add(msg)
    await session.flush()
    return msg


async def list_messages(
    session: AsyncSession,
    *,
    channel_pk: int,
    since: int = 0,
    limit: int = 500,
) -> list[Message]:
    stmt = (
        select(Message)
        .where(Message.channel_pk == channel_pk)
        .where(Message.id > since)
        .where(Message.deleted == False)  # noqa: E712
        .order_by(Message.id)
        .limit(limit)
    )
    return list((await session.exec(stmt)).all())


async def list_messages_with_counts(
    session: AsyncSession,
    *,
    channel_pk: int,
    since: int = 0,
    limit: int = 500,
) -> list[tuple[Message, int]]:
    """Like :func:`list_messages` but also returns each row's comment count."""
    msgs = await list_messages(
        session, channel_pk=channel_pk, since=since, limit=limit,
    )
    return await _attach_comment_counts(session, msgs)


async def _attach_comment_counts(
    session: AsyncSession, msgs: list[Message],
) -> list[tuple[Message, int]]:
    """Fan out one ``COUNT(*) GROUP BY message_id`` for the given messages."""
    if not msgs:
        return []
    ids = [m.id for m in msgs if m.id is not None]
    if not ids:
        return [(m, 0) for m in msgs]
    placeholders = ",".join(f":id_{i}" for i in range(len(ids)))
    params = {f"id_{i}": mid for i, mid in enumerate(ids)}
    stmt = text(
        f"SELECT message_id, COUNT(*) AS cnt FROM comments "
        f"WHERE message_id IN ({placeholders}) GROUP BY message_id"
    )
    conn = await session.connection()
    rows = (await conn.execute(stmt, params)).fetchall()
    counts = {int(r[0]): int(r[1]) for r in rows}
    return [(m, counts.get(m.id or -1, 0)) for m in msgs]


def _build_fts_query(raw: str) -> str:
    tokens = raw.split()
    if not tokens:
        return ""
    return " ".join(f'"{t.replace(chr(34), chr(34)*2)}"*' for t in tokens)


async def search_messages_with_counts(
    session: AsyncSession,
    *,
    channel_pk: int,
    q: str | None = None,
    tags: list[str] | None = None,
    since: int = 0,
    limit: int = 500,
) -> list[tuple[Message, int]]:
    """Like :func:`search_messages` but also returns each row's comment count."""
    msgs = await search_messages(
        session, channel_pk=channel_pk, q=q, tags=tags, since=since, limit=limit,
    )
    return await _attach_comment_counts(session, msgs)


async def search_messages(
    session: AsyncSession,
    *,
    channel_pk: int,
    q: str | None = None,
    tags: list[str] | None = None,
    since: int = 0,
    limit: int = 500,
) -> list[Message]:
    tags = tags or []
    fts_query = _build_fts_query(q) if q else ""

    if not fts_query and not tags:
        return await list_messages(
            session, channel_pk=channel_pk, since=since, limit=limit
        )

    clauses: list[str] = [
        "m.channel_pk = :channel_pk",
        "m.id > :since",
        "m.deleted = 0",
    ]
    params: dict[str, object] = {
        "channel_pk": channel_pk,
        "since": since,
        "limit": limit,
    }

    if fts_query:
        clauses.append("m.id IN (SELECT rowid FROM messages_fts WHERE messages_fts MATCH :fts_query)")
        params["fts_query"] = fts_query

    for i, tag in enumerate(tags):
        key = f"tag_{i}"
        clauses.append(
            f"EXISTS (SELECT 1 FROM json_each(m.tags) WHERE value = :{key})"
        )
        params[key] = tag

    where = " AND ".join(clauses)
    sql = text(
        f"SELECT m.id, m.channel_pk, m.user_id, m.text, m.tags, "
        f"m.confidence, m.ts, m.edited_at, m.deleted "
        f"FROM messages m WHERE {where} ORDER BY m.id LIMIT :limit"
    )

    conn = await session.connection()
    rows = (await conn.execute(sql, params)).fetchall()
    return [
        Message(
            id=r.id,
            channel_pk=r.channel_pk,
            user_id=r.user_id,
            text=r.text,
            tags=json.loads(r.tags) if isinstance(r.tags, str) else r.tags,
            confidence=r.confidence,
            ts=r.ts,
            edited_at=r.edited_at,
            deleted=bool(r.deleted),
        )
        for r in rows
    ]


async def get_message(
    session: AsyncSession,
    *,
    channel_pk: int,
    message_id: int,
) -> Message:
    """Fetch a single message by ID, scoped to the channel.

    Raises ``NotFoundError`` if the message does not exist or belongs to a
    different channel.
    """
    stmt = (
        select(Message)
        .where(Message.id == message_id)
        .where(Message.channel_pk == channel_pk)
    )
    msg = (await session.exec(stmt)).first()
    if msg is None:
        raise NotFoundError.for_message(message_id)
    return msg


async def update_message(
    session: AsyncSession,
    *,
    channel_pk: int,
    message_id: int,
    text: str | None = None,
    tags: list[str] | None = None,
    confidence: float | None = None,
    fields_set: set[str] | None = None,
    editor_user_id: str | None = None,
) -> Message:
    """Partial update of a message. Only fields present in *fields_set* are
    applied so that ``None`` can be distinguished from "not provided".

    ``editor_user_id`` is stamped onto ``edited_by`` when provided, giving
    a cheap forensic trail for admin-level edits.
    """
    fields_set = fields_set or set()
    msg = await get_message(session, channel_pk=channel_pk, message_id=message_id)
    if "text" in fields_set and text is not None:
        msg.text = text
    if "tags" in fields_set and tags is not None:
        msg.tags = tags
    if "confidence" in fields_set:
        msg.confidence = confidence
    msg.edited_at = time.time()
    if editor_user_id is not None:
        msg.edited_by = editor_user_id
    session.add(msg)
    await session.flush()
    return msg


async def delete_message(
    session: AsyncSession,
    *,
    channel_pk: int,
    message_id: int,
    deleter_user_id: str | None = None,
) -> Message:
    """Soft-delete a message. The row stays so the monotonic cursor is
    preserved, but the text is wiped and the ``deleted`` flag is set.

    ``deleter_user_id`` is recorded in ``deleted_by`` when provided.
    """
    msg = await get_message(session, channel_pk=channel_pk, message_id=message_id)
    msg.deleted = True
    msg.text = "[deleted]"
    if deleter_user_id is not None:
        msg.deleted_by = deleter_user_id
    session.add(msg)
    await session.flush()
    return msg


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


async def create_comment(
    session: AsyncSession,
    *,
    message_id: int,
    user_id: str,
    text: str,
) -> Comment:
    comment = Comment(message_id=message_id, user_id=user_id, text=text)
    session.add(comment)
    await session.flush()
    return comment


async def list_comments(
    session: AsyncSession,
    *,
    message_id: int,
) -> list[Comment]:
    stmt = (
        select(Comment)
        .where(Comment.message_id == message_id)
        .order_by(Comment.id)
    )
    return list((await session.exec(stmt)).all())


# ---------------------------------------------------------------------------
# UserCredential CRUD (fine-grained per-user tokens)
# ---------------------------------------------------------------------------


def hash_token(secret: str) -> str:
    """sha256 the plaintext. Used on both write (persist) and lookup."""
    return hashlib.sha256(secret.encode("utf-8")).hexdigest()


def generate_token_secret() -> str:
    """Generate a new 32-byte urlsafe token prefixed with ``mem_`` for eyeballing."""
    return "mem_" + secrets.token_urlsafe(32)


async def create_credential(
    session: AsyncSession,
    *,
    user_id: str,
    scope: dict[str, Any],
    permissions: dict[str, Any],
    name: str | None = None,
    expires_at: float | None = None,
    token_secret: str | None = None,
) -> tuple[UserCredential, str]:
    """Create a new credential. Returns ``(row, plaintext_secret)``.

    The plaintext is shown **once** at creation; thereafter only the hash
    is stored. Fails with ``ValueError`` if ``user_id`` already has an
    active credential (caller should revoke first).
    """
    existing = (
        await session.exec(
            select(UserCredential).where(UserCredential.user_id == user_id)
        )
    ).first()
    if existing is not None and existing.revoked_at is None:
        raise ValueError(f"user_id {user_id!r} already has an active token")

    secret = token_secret or generate_token_secret()
    cred = UserCredential(
        token_hash=hash_token(secret),
        user_id=user_id,
        name=name,
        scope=scope,
        permissions=permissions,
        expires_at=expires_at,
    )
    session.add(cred)
    await session.flush()
    return cred, secret


async def lookup_credential(
    session: AsyncSession,
    *,
    token_secret: str,
) -> UserCredential | None:
    """Return the credential matching the plaintext secret, or ``None``.

    Does not filter revoked / expired rows — the caller decides how to
    surface those (usually as 401).
    """
    token_hash = hash_token(token_secret)
    stmt = select(UserCredential).where(UserCredential.token_hash == token_hash)
    return (await session.exec(stmt)).first()


async def list_credentials(
    session: AsyncSession,
    *,
    include_revoked: bool = True,
) -> list[UserCredential]:
    stmt = select(UserCredential).order_by(UserCredential.created_at.desc())
    if not include_revoked:
        stmt = stmt.where(UserCredential.revoked_at == None)  # noqa: E711
    return list((await session.exec(stmt)).all())


async def get_credential_by_user(
    session: AsyncSession,
    *,
    user_id: str,
) -> UserCredential | None:
    stmt = select(UserCredential).where(UserCredential.user_id == user_id)
    return (await session.exec(stmt)).first()


async def revoke_credential(
    session: AsyncSession,
    *,
    user_id: str,
) -> UserCredential:
    """Mark the credential as revoked. Raises ``NotFoundError`` if missing."""
    cred = await get_credential_by_user(session, user_id=user_id)
    if cred is None:
        raise NotFoundError.credential(user_id)
    cred.revoked_at = time.time()
    session.add(cred)
    await session.flush()
    return cred


async def regenerate_credential(
    session: AsyncSession,
    *,
    user_id: str,
) -> tuple[UserCredential, str]:
    """Issue a new secret for an existing credential, keeping user_id,
    scope, permissions, and name. Returns ``(row, plaintext_secret)``.

    The old hash is replaced — previous plaintext stops working immediately.
    """
    cred = await get_credential_by_user(session, user_id=user_id)
    if cred is None:
        raise NotFoundError.credential(user_id)
    secret = generate_token_secret()
    cred.token_hash = hash_token(secret)
    cred.revoked_at = None
    session.add(cred)
    await session.flush()
    return cred, secret


async def record_audit(
    session: AsyncSession,
    *,
    actor_id: str,
    action: str,
    target: str | None = None,
    context: dict[str, Any] | None = None,
) -> AuditLog:
    """Append an immutable row to the audit log.

    Called by admin token CRUD endpoints. Keep the ``action`` string stable
    (``token.create`` / ``token.revoke`` / ``token.regenerate``) since the
    audit UI groups and filters on it.
    """
    row = AuditLog(
        actor_id=actor_id,
        action=action,
        target=target,
        context=context or {},
    )
    session.add(row)
    await session.flush()
    return row


async def list_audit(
    session: AsyncSession,
    *,
    limit: int = 200,
    before_id: int | None = None,
) -> list[AuditLog]:
    """Newest-first audit entries. ``before_id`` paginates older rows."""
    stmt = select(AuditLog).order_by(AuditLog.id.desc()).limit(limit)
    if before_id is not None:
        stmt = stmt.where(AuditLog.id < before_id)
    return list((await session.exec(stmt)).all())
