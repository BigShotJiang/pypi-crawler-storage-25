"""HTTP route handlers.

Four routers — workspaces, channels, messages, admin — that thinly adapt
the CRUD helpers in ``db.py`` to the pydantic wire schemas. FastAPI
dependencies for database, session, identity, and workspace/channel
existence are defined at the top of the file.

Every handler takes ``IdentityDep`` and calls ``require(...)`` from
``auth.py`` to gate by fine-grained permission level and workspace scope.
Super-admins (bootstrap token or auth-disabled mode) bypass all checks.

URL hierarchy mirrors the data model: ``/workspaces/{ws}/channels/{ch}/...``.
"""
from __future__ import annotations

import time
from collections.abc import AsyncIterator
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Request
from sqlmodel.ext.asyncio.session import AsyncSession

from memorized.exceptions import ValidationError
from memorized.schemas import (
    AuditLogEntryOut,
    ChannelCreate,
    ChannelOut,
    CommentIn,
    CommentOut,
    FieldError,
    MessageCreateOut,
    MessageIn,
    MessageOut,
    MessageUpdate,
    TokenCreate,
    TokenCreateOut,
    TokenOut,
    WorkspaceCreate,
    WorkspaceOut,
)
from memorized.server import db
from memorized.server.auth import (
    IdentityDep,
    require,
    require_super_admin,
)

# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def get_database(request: Request) -> db.Database:
    """Return the app-wide ``Database`` instance.

    Exposed as its own dependency (instead of reading ``request.app.state``
    inline inside ``get_session``) so tests can swap it via
    ``app.dependency_overrides[get_database] = ...`` if they ever need to.
    """
    return request.app.state.db


DbDep = Annotated[db.Database, Depends(get_database)]


async def get_session(database: DbDep) -> AsyncIterator[AsyncSession]:
    """Yield a session scoped to one request.

    Commits are the handler's responsibility and MUST happen before the
    handler returns — FastAPI runs this dependency's post-yield cleanup
    *after* the response has been delivered, so a commit here would not
    be visible to the client's next request. We only roll back on
    exception and close the session on exit.
    """
    async with database.session() as session:
        try:
            yield session
        except Exception:
            await session.rollback()
            raise


SessionDep = Annotated[AsyncSession, Depends(get_session)]


async def ensure_workspace_dep(
    ws: str, session: SessionDep, identity: IdentityDep,
) -> str:
    # ``identity`` is listed as a dep so FastAPI resolves auth BEFORE hitting
    # the DB — otherwise an unauthenticated caller could probe workspace
    # existence via 404 vs 401 timing.
    del identity  # intentionally unused here; presence gates the call
    await db.ensure_workspace(session, ws)
    return ws


WorkspaceDep = Annotated[str, Depends(ensure_workspace_dep)]


async def ensure_channel_dep(
    ws: str, ch: str, session: SessionDep, identity: IdentityDep,
) -> db.Channel:
    del identity
    return await db.ensure_channel(session, workspace_id=ws, channel_id=ch)


ChannelDep = Annotated[db.Channel, Depends(ensure_channel_dep)]


def _author_for_write(identity, body_user_id: str | None) -> str:
    """Pick the ``user_id`` to stamp on a write.

    The identity is always authoritative — any body-supplied ``user_id``
    is discarded. This is the server-side bind that prevents
    user-to-user impersonation.
    """
    del body_user_id
    return identity.user_id


# ---------------------------------------------------------------------------
# Workspaces
# ---------------------------------------------------------------------------


workspaces_router = APIRouter(prefix="/workspaces", tags=["workspaces"])


@workspaces_router.post("", response_model=WorkspaceOut)
async def post_workspace(
    body: WorkspaceCreate, session: SessionDep, identity: IdentityDep,
) -> WorkspaceOut:
    require(identity, resource="workspace", level="write")
    ws = await db.create_workspace(session, id=body.id, metadata=body.metadata)
    await session.commit()
    return WorkspaceOut(id=ws.id, metadata=ws.meta, created_at=ws.created_at)


@workspaces_router.get("", response_model=list[WorkspaceOut])
async def get_workspaces(
    session: SessionDep, identity: IdentityDep,
) -> list[WorkspaceOut]:
    require(identity, resource="workspace", level="read")
    rows = await db.list_workspaces_with_counts(session)
    out = [
        WorkspaceOut(
            id=w.id,
            metadata=w.meta,
            created_at=w.created_at,
            channel_count=cnt,
        )
        for w, cnt in rows
    ]
    # Trim the visible list to the caller's scope — a narrowly-scoped token
    # should not see workspace ids it can't touch.
    if not identity.is_super_admin and identity.scope.workspace_ids != "*":
        allowed = set(identity.scope.workspace_ids)
        out = [w for w in out if w.id in allowed]
    return out


@workspaces_router.delete("/{ws}", status_code=204)
async def delete_workspace(
    ws: str, session: SessionDep, identity: IdentityDep,
) -> None:
    require(identity, resource="workspace", level="admin", workspace=ws)
    await db.delete_workspace(session, workspace_id=ws)
    await session.commit()


# ---------------------------------------------------------------------------
# Channels
# ---------------------------------------------------------------------------


channels_router = APIRouter(
    prefix="/workspaces/{ws}/channels", tags=["channels"]
)


@channels_router.post("", response_model=ChannelOut)
async def post_channel(
    ws: WorkspaceDep, body: ChannelCreate, session: SessionDep,
    identity: IdentityDep,
) -> ChannelOut:
    require(identity, resource="channel", level="write", workspace=ws)
    ch = await db.create_channel(
        session, workspace_id=ws, id=body.id, metadata=body.metadata
    )
    await session.commit()
    return ChannelOut(
        id=ch.id,
        workspace_id=ch.workspace_id,
        metadata=ch.meta,
        created_at=ch.created_at,
    )


@channels_router.get("", response_model=list[ChannelOut])
async def get_channels(
    ws: WorkspaceDep,
    session: SessionDep,
    identity: IdentityDep,
    limit: int | None = Query(default=None, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> list[ChannelOut]:
    require(identity, resource="channel", level="read", workspace=ws)
    # Default is unpaginated (all channels) to preserve the wire contract
    # for MCP / SDK clients that call ``list_channels`` and expect every
    # row back. The web UI opts into pagination by passing ``limit``.
    rows = await db.list_channels_with_counts(
        session, workspace_id=ws, limit=limit, offset=offset,
    )
    out = [
        ChannelOut(
            id=c.id,
            workspace_id=c.workspace_id,
            metadata=c.meta,
            created_at=c.created_at,
            message_count=cnt,
        )
        for c, cnt in rows
    ]
    # Trim to the channels this token can see, mirroring the workspace
    # trim in get_workspaces. Super-admins and "*"-scoped tokens see all.
    if not identity.is_super_admin:
        out = [c for c in out if identity.scope.covers_channel(ws, c.id)]
    return out


@channels_router.delete("/{ch}", status_code=204)
async def delete_channel(
    ws: WorkspaceDep, ch: str, session: SessionDep, identity: IdentityDep,
) -> None:
    require(
        identity, resource="channel", level="admin", workspace=ws, channel=ch,
    )
    await db.delete_channel(session, workspace_id=ws, channel_id=ch)
    await session.commit()


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


messages_router = APIRouter(
    prefix="/workspaces/{ws}/channels/{ch}/messages", tags=["messages"]
)


def _to_out(msg: db.Message, comment_count: int = 0) -> MessageOut:
    if msg.id is None:
        raise ValueError("persisted Message must have an id")
    return MessageOut(
        id=msg.id,
        user_id=msg.user_id,
        text=msg.text,
        tags=msg.tags,
        confidence=msg.confidence,
        ts=msg.ts,
        edited_at=msg.edited_at,
        edited_by=msg.edited_by,
        deleted=msg.deleted,
        deleted_by=msg.deleted_by,
        comment_count=comment_count,
    )


def _channel_pk(ch: db.Channel) -> int:
    if ch.pk is None:
        raise ValueError("persisted Channel must have a pk")
    return ch.pk


@messages_router.post("", response_model=MessageCreateOut)
async def post_message(
    ws: str,
    body: MessageIn,
    ch: ChannelDep,
    session: SessionDep,
    identity: IdentityDep,
) -> MessageCreateOut:
    require(
        identity, resource="message", level="write", workspace=ws, channel=ch.id,
    )
    msg = await db.create_message(
        session,
        channel_pk=_channel_pk(ch),
        user_id=_author_for_write(identity, body.user_id),
        text=body.text,
        tags=body.tags,
        confidence=body.confidence,
    )
    await session.commit()
    if msg.id is None:
        raise ValueError("persisted Message must have an id")
    return MessageCreateOut(id=msg.id)


@messages_router.get("", response_model=list[MessageOut])
async def get_messages(
    ws: str,
    ch: ChannelDep,
    session: SessionDep,
    identity: IdentityDep,
    since: int = Query(default=0, ge=0),
    limit: int = Query(default=500, ge=1, le=2000),
    q: str | None = Query(default=None, max_length=500),
    tags: list[str] = Query(default_factory=list),
) -> list[MessageOut]:
    require(
        identity, resource="message", level="read", workspace=ws, channel=ch.id,
    )
    pk = _channel_pk(ch)
    if q or tags:
        rows = await db.search_messages_with_counts(
            session, channel_pk=pk, q=q, tags=tags, since=since, limit=limit,
        )
    else:
        rows = await db.list_messages_with_counts(
            session, channel_pk=pk, since=since, limit=limit,
        )
    return [_to_out(msg, cnt) for msg, cnt in rows]


@messages_router.patch("/{msg_id}", response_model=MessageOut)
async def patch_message(
    ws: str,
    msg_id: int,
    body: MessageUpdate,
    ch: ChannelDep,
    session: SessionDep,
    identity: IdentityDep,
) -> MessageOut:
    require(
        identity, resource="message", level="admin", workspace=ws, channel=ch.id,
    )
    msg = await db.update_message(
        session,
        channel_pk=_channel_pk(ch),
        message_id=msg_id,
        text=body.text,
        tags=body.tags,
        confidence=body.confidence,
        fields_set=body.model_fields_set,
        editor_user_id=identity.user_id,
    )
    await session.commit()
    return _to_out(msg)


@messages_router.delete("/{msg_id}", status_code=204)
async def delete_message(
    ws: str,
    msg_id: int,
    ch: ChannelDep,
    session: SessionDep,
    identity: IdentityDep,
) -> None:
    require(
        identity, resource="message", level="admin", workspace=ws, channel=ch.id,
    )
    await db.delete_message(
        session, channel_pk=_channel_pk(ch), message_id=msg_id,
        deleter_user_id=identity.user_id,
    )
    await session.commit()


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


def _comment_out(c: db.Comment) -> CommentOut:
    assert c.id is not None
    return CommentOut(
        id=c.id,
        message_id=c.message_id,
        user_id=c.user_id,
        text=c.text,
        ts=c.ts,
    )


@messages_router.post("/{msg_id}/comments", response_model=CommentOut)
async def post_comment(
    ws: str,
    msg_id: int,
    body: CommentIn,
    ch: ChannelDep,
    session: SessionDep,
    identity: IdentityDep,
) -> CommentOut:
    require(
        identity, resource="comment", level="write", workspace=ws, channel=ch.id,
    )
    await db.get_message(
        session, channel_pk=_channel_pk(ch), message_id=msg_id
    )
    comment = await db.create_comment(
        session,
        message_id=msg_id,
        user_id=_author_for_write(identity, body.user_id),
        text=body.text,
    )
    await session.commit()
    return _comment_out(comment)


@messages_router.get("/{msg_id}/comments", response_model=list[CommentOut])
async def get_comments(
    ws: str,
    msg_id: int,
    ch: ChannelDep,
    session: SessionDep,
    identity: IdentityDep,
) -> list[CommentOut]:
    require(
        identity, resource="comment", level="read", workspace=ws, channel=ch.id,
    )
    await db.get_message(
        session, channel_pk=_channel_pk(ch), message_id=msg_id
    )
    rows = await db.list_comments(session, message_id=msg_id)
    return [_comment_out(c) for c in rows]


# ---------------------------------------------------------------------------
# Admin: fine-grained token lifecycle
# ---------------------------------------------------------------------------


admin_router = APIRouter(prefix="/admin", tags=["admin"])


def _cred_to_out(cred: db.UserCredential) -> TokenOut:
    return TokenOut(
        user_id=cred.user_id,
        name=cred.name,
        scope=cred.scope or {"workspace_ids": []},  # type: ignore[arg-type]
        permissions=cred.permissions or {},  # type: ignore[arg-type]
        expires_at=cred.expires_at,
        created_at=cred.created_at,
        revoked_at=cred.revoked_at,
    )


@admin_router.post("/tokens", response_model=TokenCreateOut)
async def create_token(
    body: TokenCreate, session: SessionDep, identity: IdentityDep,
) -> TokenCreateOut:
    require_super_admin(identity)
    expires_at = (
        time.time() + body.expires_in_seconds
        if body.expires_in_seconds is not None
        else None
    )
    try:
        cred, secret = await db.create_credential(
            session,
            user_id=body.user_id,
            name=body.name,
            scope=body.scope.model_dump(),
            permissions=body.permissions.model_dump(),
            expires_at=expires_at,
        )
    except ValueError as exc:
        raise ValidationError.from_fields(
            str(exc), [FieldError(loc="user_id", msg=str(exc), type="duplicate")]
        ) from exc
    await db.record_audit(
        session,
        actor_id=identity.user_id,
        action="token.create",
        target=cred.user_id,
        context={
            "name": cred.name,
            "scope": cred.scope,
            "permissions": cred.permissions,
            "expires_at": cred.expires_at,
        },
    )
    await session.commit()
    return TokenCreateOut(token=secret, metadata=_cred_to_out(cred))


@admin_router.get("/tokens", response_model=list[TokenOut])
async def list_tokens(
    session: SessionDep, identity: IdentityDep,
) -> list[TokenOut]:
    require_super_admin(identity)
    rows = await db.list_credentials(session)
    return [_cred_to_out(c) for c in rows]


@admin_router.delete("/tokens/{user_id}", response_model=TokenOut)
async def revoke_token(
    user_id: str, session: SessionDep, identity: IdentityDep,
) -> TokenOut:
    require_super_admin(identity)
    cred = await db.revoke_credential(session, user_id=user_id)
    await db.record_audit(
        session,
        actor_id=identity.user_id,
        action="token.revoke",
        target=cred.user_id,
    )
    await session.commit()
    return _cred_to_out(cred)


@admin_router.post("/tokens/{user_id}/regenerate", response_model=TokenCreateOut)
async def regenerate_token(
    user_id: str, session: SessionDep, identity: IdentityDep,
) -> TokenCreateOut:
    require_super_admin(identity)
    cred, secret = await db.regenerate_credential(session, user_id=user_id)
    await db.record_audit(
        session,
        actor_id=identity.user_id,
        action="token.regenerate",
        target=cred.user_id,
    )
    await session.commit()
    return TokenCreateOut(token=secret, metadata=_cred_to_out(cred))


@admin_router.get("/audit", response_model=list[AuditLogEntryOut])
async def list_audit(
    session: SessionDep,
    identity: IdentityDep,
    limit: int = Query(default=200, ge=1, le=1000),
    before_id: int | None = Query(default=None, ge=1),
) -> list[AuditLogEntryOut]:
    require_super_admin(identity)
    rows = await db.list_audit(session, limit=limit, before_id=before_id)
    return [
        AuditLogEntryOut(
            id=r.id or 0,
            ts=r.ts,
            actor_id=r.actor_id,
            action=r.action,
            target=r.target,
            context=r.context,
        )
        for r in rows
    ]
