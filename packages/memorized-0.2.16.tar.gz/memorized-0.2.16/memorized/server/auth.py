"""Identity resolution + permission gate for the HTTP surface.

Every request must carry ``Authorization: Bearer <secret>``. One secret is
the bootstrap super-admin (``settings.admin_token``), everything else is a
DB-backed ``UserCredential`` with a scope + permission matrix. The
``current_identity`` dependency resolves the caller, and ``require(...)``
enforces per-route permission + scope.

``user_id`` is always taken from the authenticated identity — clients
cannot impersonate another user just by lying in the body.
"""
from __future__ import annotations

import secrets
import time
from collections.abc import AsyncIterator
from dataclasses import dataclass
from typing import Annotated

from fastapi import Depends, Request
from sqlmodel.ext.asyncio.session import AsyncSession

from memorized.exceptions import AuthenticationError, ForbiddenError
from memorized.schemas import Permissions, ResourceKind, Scope
from memorized.server import db as _db

# Super-admin user_id when the bootstrap token is presented. Reserved; the
# TokenCreate schema refuses to let regular tokens claim it.
ADMIN_USER_ID = "admin"

_ALL_ADMIN = Permissions(
    workspace="admin", channel="admin", message="admin", comment="admin"
)
_ALL_ADMIN_SCOPE = Scope(workspace_ids="*")


@dataclass(frozen=True, slots=True)
class Identity:
    """Who is making the request and what they can do.

    ``user_id`` is the server-authoritative author for any write this
    request performs. ``is_super_admin`` carries the bootstrap-token case
    so admin-only endpoints can be gated with one check.
    """

    user_id: str
    permissions: Permissions
    scope: Scope
    is_super_admin: bool = False


def _parse_bearer(request: Request) -> str | None:
    auth = request.headers.get("authorization", "")
    scheme, _, token = auth.partition(" ")
    if scheme.lower() != "bearer" or not token:
        return None
    return token


async def _get_session(request: Request) -> AsyncIterator[AsyncSession]:
    """Short-lived session scoped to auth resolution only.

    We can't reuse the route's ``SessionDep`` because that dependency is
    declared downstream; FastAPI would still work, but keeping the auth
    session separate avoids accidental cross-contamination with route
    transactions.
    """
    database: _db.Database = request.app.state.db
    async with database.session() as session:
        yield session


SessionDep = Annotated[AsyncSession, Depends(_get_session)]


async def current_identity(
    request: Request, session: SessionDep,
) -> Identity:
    """Resolve the caller's identity from the ``Authorization`` header.

    Returns a fully-populated ``Identity``; raises
    ``AuthenticationError`` if the token is missing, unknown, revoked, or
    expired.
    """
    settings = request.app.state.settings
    # The CLI materializes a token at startup — this should never be None in
    # a running server. The guard is here so an import-time misuse surfaces
    # as a clear error instead of a silent auth bypass.
    if settings.admin_token is None:
        raise RuntimeError(
            "settings.admin_token is unset; cli.server should have "
            "materialized one before creating the app"
        )

    token = _parse_bearer(request)
    if token is None:
        raise AuthenticationError.missing_or_invalid()

    # Constant-time compare against the bootstrap token.
    if secrets.compare_digest(token, settings.admin_token):
        return Identity(
            user_id=ADMIN_USER_ID,
            permissions=_ALL_ADMIN,
            scope=_ALL_ADMIN_SCOPE,
            is_super_admin=True,
        )

    cred = await _db.lookup_credential(session, token_secret=token)
    if cred is None:
        raise AuthenticationError.missing_or_invalid()
    if cred.revoked_at is not None:
        raise AuthenticationError.revoked_or_expired()
    if cred.expires_at is not None and cred.expires_at < time.time():
        raise AuthenticationError.revoked_or_expired()

    return Identity(
        user_id=cred.user_id,
        permissions=Permissions.model_validate(cred.permissions or {}),
        scope=Scope.model_validate(cred.scope or {}),
    )


IdentityDep = Annotated[Identity, Depends(current_identity)]


async def optional_identity(
    request: Request, session: SessionDep,
) -> Identity | None:
    """Like ``current_identity`` but never raises on missing/bad tokens.

    Returns ``None`` when the request has no token or the token is
    invalid. For endpoints that should work for signed-out clients too
    (health probes, public metadata) — regular routes should keep using
    ``IdentityDep`` so they 401 as expected.
    """
    try:
        return await current_identity(request, session)
    except AuthenticationError:
        return None


OptionalIdentityDep = Annotated[Identity | None, Depends(optional_identity)]


def require(
    identity: Identity,
    *,
    resource: ResourceKind,
    level: str,
    workspace: str | None = None,
    channel: str | None = None,
) -> None:
    """Gate a route by permission level and scope.

    Raises ``ForbiddenError`` when the identity holds a weaker level than
    requested, when the request targets a workspace outside the
    identity's scope, or when the request targets a channel the scope
    does not cover. Super-admins always pass.
    """
    if identity.is_super_admin:
        return
    if not identity.permissions.allows(resource, level):  # type: ignore[arg-type]
        raise ForbiddenError.insufficient_permission(
            resource=resource,
            required=level,
            held=identity.permissions.level(resource),
        )
    if workspace is not None and not identity.scope.covers_workspace(workspace):
        raise ForbiddenError.out_of_scope(workspace)
    if channel is not None:
        # Only meaningful when a workspace is also specified — without one
        # we can't disambiguate which "ch_id" we mean.
        if workspace is None:
            raise ValueError("channel= requires workspace= to be set")
        if not identity.scope.covers_channel(workspace, channel):
            raise ForbiddenError.out_of_scope(f"{workspace}/{channel}")


def require_super_admin(identity: Identity) -> None:
    """Admin-only endpoints (token lifecycle) use this gate."""
    if not identity.is_super_admin:
        raise ForbiddenError.insufficient_permission(
            resource="admin", required="admin", held="user",
        )
