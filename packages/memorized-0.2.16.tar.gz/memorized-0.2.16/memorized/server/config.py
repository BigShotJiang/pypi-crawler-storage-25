"""Typed runtime configuration, driven by env vars with sensible defaults."""
from __future__ import annotations

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Environment-backed settings. Override any field via ``MEMORIZED_<NAME>``."""

    model_config = SettingsConfigDict(
        env_prefix="MEMORIZED_", env_file=".env", extra="ignore"
    )

    db_path: Path = Field(default=Path("memorized.db"))
    host: str = Field(default="127.0.0.1")
    port: int = Field(default=8765, ge=1, le=65535)
    debug: bool = Field(
        default=False,
        description="When true, unhandled-exception responses include the traceback.",
    )
    log_dir: Path = Field(
        default_factory=lambda: Path.home() / ".memorized" / "logs",
        description=(
            "Directory for rotating server log files (server.log). Only used "
            "by the HTTP server CLI; the stdio MCP server ignores this."
        ),
    )

    admin_token: str | None = Field(
        default=None,
        description=(
            "Bootstrap super-admin bearer. Holder can create / list / revoke "
            "per-agent tokens at /admin/tokens and has full access to every "
            "resource in every workspace. If unset, one is generated on first "
            "boot and appended to ``./.env`` (see ``cli.server``)."
        ),
    )
