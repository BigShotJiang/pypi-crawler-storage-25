"""Single ``memorized`` CLI with five subcommand groups.

All workspace / channel / user / message targeting is done via named
options so the shape is obvious in an agent-generated invocation (and
order never matters). Workspace, channel and user id also fall back to
the same environment variables the MCP server reads, so a one-time
``export`` is enough:

    export MEMORIZED_WORKSPACE_ID=defcon-2026
    export MEMORIZED_CHANNEL_ID=web-chall-5
    export MEMORIZED_USER_ID=coder:claude:1

    memorized server --db PATH --host HOST --port PORT
    memorized mcp
    memorized workspace create --workspace NAME
    memorized workspace list
    memorized channel create --workspace W --channel C
    memorized channel list --workspace W
    memorized msg send   [--workspace W] [--channel C] [--user-id A] [--text T] [--tag ...]
    memorized msg read   [--workspace W] [--channel C] [--since N] [--limit N]

``server`` starts the HTTP + Web UI process. ``mcp`` starts the stdio MCP
server (used by MCP clients that spawn subprocesses). ``workspace``,
``channel`` and ``msg`` are the client-side operations an operator or CI
script would use.
"""
from __future__ import annotations

import json
import logging
import os
import secrets
import sys
from importlib.metadata import version as _pkg_version
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Annotated

import httpx
import typer
import uvicorn
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from memorized.client import MemorizedClient
from memorized.exceptions import MemorizedError
from memorized.mcp_server import main as mcp_main
from memorized.server import create_app
from memorized.server.config import Settings

console = Console()
err_console = Console(stderr=True)

app = typer.Typer(
    name="memorized",
    help="Shared append-only chat log for collaborating multi-agent systems.",
    no_args_is_help=True,
    add_completion=False,
)
workspace_app = typer.Typer(help="Workspace commands (top-level container).", no_args_is_help=True)
channel_app = typer.Typer(help="Channel commands (shared chat stream inside a workspace).", no_args_is_help=True)
msg_app = typer.Typer(help="Message commands.", no_args_is_help=True)
admin_app = typer.Typer(help="Admin commands (fine-grained token lifecycle).", no_args_is_help=True)
app.add_typer(workspace_app, name="workspace")
app.add_typer(channel_app, name="channel")
app.add_typer(msg_app, name="msg")
app.add_typer(admin_app, name="admin")


def _version_cb(value: bool) -> None:
    if value:
        console.print(f"memorized {_pkg_version('memorized')}")
        raise typer.Exit()


@app.callback()
def _main(
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            "-V",
            help="Show version and exit.",
            is_eager=True,
            callback=_version_cb,
        ),
    ] = False,
) -> None:
    """Shared append-only chat log for collaborating multi-agent systems."""


BASE_URL_ENV = "MEMORIZED_BASE_URL"
API_TOKEN_ENV = "MEMORIZED_API_TOKEN"
WORKSPACE_ENV = "MEMORIZED_WORKSPACE_ID"
CHANNEL_ENV = "MEMORIZED_CHANNEL_ID"
USER_ID_ENV = "MEMORIZED_USER_ID"
DEFAULT_BASE_URL = "http://127.0.0.1:8765"


def _base_url() -> str:
    return os.environ.get(BASE_URL_ENV, DEFAULT_BASE_URL)


def _api_token() -> str | None:
    return os.environ.get(API_TOKEN_ENV)


def _require(flag_value: str | None, env_name: str, flag_name: str) -> str:
    """Resolve a value from `--flag` or env var, erroring with a helpful
    message if both are missing."""
    value = flag_value or os.environ.get(env_name)
    if not value:
        raise typer.BadParameter(f"pass {flag_name} or set {env_name}")
    return value


# Reusable Annotated option types so every subcommand that targets a
# workspace / channel / user uses the exact same flag name and help text.
WorkspaceOpt = Annotated[
    str | None,
    typer.Option(
        "--workspace",
        "-w",
        help=f"Workspace id. Falls back to ${WORKSPACE_ENV}.",
    ),
]
ChannelOpt = Annotated[
    str | None,
    typer.Option(
        "--channel",
        "-c",
        help=f"Channel id (inside the workspace). Falls back to ${CHANNEL_ENV}.",
    ),
]
UserIdOpt = Annotated[
    str | None,
    typer.Option(
        "--user-id",
        "-a",
        help=f"Agent id. Falls back to ${USER_ID_ENV}.",
    ),
]
MsgIdOpt = Annotated[
    int,
    typer.Option("--msg-id", help="Message id."),
]


# ---------------------------------------------------------------------------
# server / mcp
# ---------------------------------------------------------------------------


_DEFAULT_DB = Path("memorized.db")
_ADMIN_TOKEN_KEY = "MEMORIZED_ADMIN_TOKEN"


def _env_has_key(env_path: Path, key: str) -> bool:
    """True iff ``env_path`` already defines ``key=...`` (skipping blanks/comments)."""
    if not env_path.exists():
        return False
    prefix = f"{key}="
    for raw in env_path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):]
        if line.startswith(prefix):
            return True
    return False


def _append_env(env_path: Path, key: str, value: str) -> None:
    """Append ``KEY=VALUE`` to ``.env``, creating it (mode 0600) if needed.

    No-op when ``key`` is already defined in the file — we never clobber
    an operator-managed value.
    """
    if _env_has_key(env_path, key):
        return
    env_path.parent.mkdir(parents=True, exist_ok=True)
    prefix = ""
    if env_path.exists():
        existing = env_path.read_text()
        if existing and not existing.endswith("\n"):
            prefix = "\n"
    with env_path.open("a") as fh:
        fh.write(f"{prefix}{key}={value}\n")
    try:
        env_path.chmod(0o600)
    except OSError:
        # Windows / some filesystems reject chmod; accept looser perms
        # there rather than failing boot.
        pass


def _materialize_admin_token(settings: Settings, db_path: Path) -> str:
    """Ensure ``settings.admin_token`` is non-None. Returns the source tag.

    Priority:
        1. ``settings.admin_token`` already populated — by shell env var
           (``"env"``) or by a pre-existing ``.env`` line (``"envfile"``).
        2. Legacy ``admin_token`` file sitting beside the DB — read it
           and migrate the value into ``./.env`` (``"migrated"``). The
           old file is left on disk for the operator to delete.
        3. Neither — mint with ``secrets.token_urlsafe(32)`` and append
           ``MEMORIZED_ADMIN_TOKEN=<value>`` to ``./.env`` (``"fresh"``).

    The returned tag drives the startup panel text only; callers that
    just want "did we mint a new one?" can compare to ``"fresh"``.
    """
    env_path = Path.cwd() / ".env"

    if settings.admin_token is not None:
        if os.environ.get(_ADMIN_TOKEN_KEY):
            return "env"
        return "envfile"

    legacy = db_path.parent / "admin_token"
    if legacy.exists():
        token = legacy.read_text().strip()
        object.__setattr__(settings, "admin_token", token)
        _append_env(env_path, _ADMIN_TOKEN_KEY, token)
        return "migrated"

    token = secrets.token_urlsafe(32)
    _append_env(env_path, _ADMIN_TOKEN_KEY, token)
    object.__setattr__(settings, "admin_token", token)
    return "fresh"


def _configure_file_logging(log_dir: Path) -> Path:
    """Attach a rotating FileHandler to root + app + uvicorn loggers.

    Returns the absolute path of the active log file so the caller can
    show it at startup — otherwise operators have to guess where logs
    live when a 500 happens and stderr goes to a lost pty.
    """
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / "server.log"
    handler = RotatingFileHandler(
        log_file, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s [%(name)s] %(message)s")
    )
    for name in ("", "memorized", "uvicorn", "uvicorn.error", "uvicorn.access"):
        target = logging.getLogger(name)
        # Idempotent — running `memorized server` twice in one process
        # (tests do this) shouldn't stack handlers.
        if not any(
            isinstance(h, RotatingFileHandler)
            and getattr(h, "baseFilename", None) == str(log_file.resolve())
            for h in target.handlers
        ):
            target.addHandler(handler)
    logging.getLogger("").setLevel(logging.INFO)
    return log_file.resolve()


@app.command()
def server(
    db: Annotated[Path, typer.Option(help="SQLite file backing the workspace.")] = _DEFAULT_DB,
    host: Annotated[str, typer.Option(help="Bind host.")] = "127.0.0.1",
    port: Annotated[int, typer.Option(help="Bind port.")] = 8765,
) -> None:
    """Run the HTTP + Web UI server."""
    settings = Settings(db_path=db, host=host, port=port)
    log_file = _configure_file_logging(settings.log_dir)
    source = _materialize_admin_token(settings, db.resolve())
    env_path = Path.cwd() / ".env"

    if source == "fresh":
        token_line = (
            f"[bold yellow]generated admin token (saved to "
            f"{env_path}):[/bold yellow]\n[green]{settings.admin_token}[/green]\n\n"
        )
    elif source == "migrated":
        legacy = db.resolve().parent / "admin_token"
        token_line = (
            f"admin    migrated [cyan]{legacy}[/cyan] → [cyan]{env_path}[/cyan]\n"
            f"         (the old file is no longer read; delete it when ready)\n"
        )
    elif source == "env":
        token_line = f"admin    loaded from [cyan]shell env[/cyan]\n"
    else:  # "envfile"
        token_line = f"admin    loaded from [cyan]{env_path}[/cyan]\n"

    console.print(
        Panel.fit(
            f"[bold]memorized[/bold]\n"
            f"db       [cyan]{db}[/cyan]\n"
            f"logs     [cyan]{log_file}[/cyan]\n"
            f"http     [cyan]http://{host}:{port}[/cyan]\n"
            f"ui       [cyan]http://{host}:{port}/ui/[/cyan]\n"
            f"openapi  [cyan]http://{host}:{port}/docs[/cyan]\n"
            f"{token_line}",
            title="starting",
            border_style="green",
        )
    )
    uvicorn.run(create_app(settings), host=host, port=port, log_level="info")


@app.command()
def mcp(
    transport: Annotated[
        str,
        typer.Option(
            "--transport",
            "-t",
            help="MCP transport: stdio (default, for subprocess clients), "
            "streamable-http, or sse.",
        ),
    ] = "stdio",
    host: Annotated[
        str,
        typer.Option(help="Bind host (http/sse transports only)."),
    ] = "127.0.0.1",
    port: Annotated[
        int,
        typer.Option(help="Bind port (http/sse transports only)."),
    ] = 8000,
) -> None:
    """Run the MCP server. Defaults to stdio; pass --transport for HTTP."""
    if transport not in ("stdio", "streamable-http", "sse"):
        raise typer.BadParameter(
            f"transport must be stdio|streamable-http|sse, got {transport!r}"
        )
    mcp_main(transport=transport, host=host, port=port)  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# workspaces
# ---------------------------------------------------------------------------


@workspace_app.command("create")
def workspace_create(workspace: WorkspaceOpt = None) -> None:
    """Create (or return existing) workspace with the given id."""
    ws_id = _require(workspace, WORKSPACE_ENV, "--workspace")
    ws = MemorizedClient.create_workspace(_base_url(), ws_id, api_token=_api_token())
    console.print(f"[green]created[/green] [cyan]{ws.id}[/cyan]")


@workspace_app.command("list")
def workspace_list() -> None:
    """List all workspaces on the server."""
    workspaces = MemorizedClient.list_workspaces(_base_url(), api_token=_api_token())
    table = Table(title="Workspaces")
    table.add_column("id", style="cyan")
    table.add_column("channels", justify="right")
    table.add_column("metadata")
    table.add_column("created_at", justify="right")
    for w in workspaces:
        meta_str = json.dumps(w.metadata, ensure_ascii=False) if w.metadata else ""
        table.add_row(w.id, str(w.channel_count), meta_str, f"{w.created_at:.0f}")
    console.print(table)


@workspace_app.command("delete")
def workspace_delete(workspace: WorkspaceOpt = None) -> None:
    """Delete a workspace and all channels/messages inside it. Cannot be undone."""
    ws_id = _require(workspace, WORKSPACE_ENV, "--workspace")
    MemorizedClient.delete_workspace(_base_url(), ws_id, api_token=_api_token())
    console.print(f"[green]deleted[/green] workspace [cyan]{ws_id}[/cyan]")


# ---------------------------------------------------------------------------
# channels
# ---------------------------------------------------------------------------


@channel_app.command("create")
def channel_create(
    workspace: WorkspaceOpt = None, channel: ChannelOpt = None,
) -> None:
    """Create (or return existing) channel inside a workspace."""
    ws_id = _require(workspace, WORKSPACE_ENV, "--workspace")
    ch_id = _require(channel, CHANNEL_ENV, "--channel")
    ch = MemorizedClient.create_channel(
        _base_url(), ws_id, ch_id, api_token=_api_token(),
    )
    console.print(
        f"[green]created[/green] channel [cyan]{ch.id}[/cyan] "
        f"in workspace [cyan]{ch.workspace_id}[/cyan]"
    )


@channel_app.command("list")
def channel_list(workspace: WorkspaceOpt = None) -> None:
    """List all channels inside a workspace."""
    ws_id = _require(workspace, WORKSPACE_ENV, "--workspace")
    channels = MemorizedClient.list_channels(_base_url(), ws_id, api_token=_api_token())
    table = Table(title=f"Channels in {ws_id}")
    table.add_column("id", style="cyan")
    table.add_column("messages", justify="right")
    table.add_column("metadata")
    table.add_column("created_at", justify="right")
    for c in channels:
        meta_str = json.dumps(c.metadata, ensure_ascii=False) if c.metadata else ""
        table.add_row(c.id, str(c.message_count), meta_str, f"{c.created_at:.0f}")
    console.print(table)


@channel_app.command("delete")
def channel_delete(
    workspace: WorkspaceOpt = None, channel: ChannelOpt = None,
) -> None:
    """Delete a channel and all messages/comments inside it. Cannot be undone."""
    ws_id = _require(workspace, WORKSPACE_ENV, "--workspace")
    ch_id = _require(channel, CHANNEL_ENV, "--channel")
    MemorizedClient.delete_channel(
        _base_url(), ws_id, ch_id, api_token=_api_token(),
    )
    console.print(
        f"[green]deleted[/green] channel [cyan]{ch_id}[/cyan] "
        f"in workspace [cyan]{ws_id}[/cyan]"
    )


# ---------------------------------------------------------------------------
# messages
# ---------------------------------------------------------------------------


def _require_ws_and_ch(
    workspace: str | None, channel: str | None,
) -> tuple[str, str]:
    ws_id = _require(workspace, WORKSPACE_ENV, "--workspace")
    ch_id = _require(channel, CHANNEL_ENV, "--channel")
    return ws_id, ch_id


@msg_app.command("send")
def msg_send(
    workspace: WorkspaceOpt = None,
    channel: ChannelOpt = None,
    user_id: UserIdOpt = None,
    text: Annotated[
        str | None,
        typer.Option("--text", help="Message text. Omit to read from stdin."),
    ] = None,
    tag: Annotated[
        list[str] | None,
        typer.Option("--tag", help="Repeat for multiple tags."),
    ] = None,
    confidence: Annotated[
        float | None,
        typer.Option("--confidence", help="Confidence score 0.0–1.0."),
    ] = None,
) -> None:
    """Post a message to a channel."""
    ws_id, ch_id = _require_ws_and_ch(workspace, channel)
    ag_id = _require(user_id, USER_ID_ENV, "--user-id")
    body = text if text is not None else sys.stdin.read()
    if not body.strip():
        err_console.print("[red]error[/red] empty message (nothing on stdin?)")
        raise typer.Exit(code=1)
    with MemorizedClient(
        _base_url(), ws_id, ch_id, user_id=ag_id, api_token=_api_token(),
    ) as c:
        r = c.share(body, tags=tag or [], confidence=confidence)
    console.print(f"[green]sent[/green] id=[cyan]{r.id}[/cyan]")


@msg_app.command("read")
def msg_read(
    workspace: WorkspaceOpt = None,
    channel: ChannelOpt = None,
    since: Annotated[int, typer.Option(help="Only return messages with id > since.")] = 0,
    limit: Annotated[int, typer.Option(help="Max messages to return.")] = 500,
) -> None:
    """Read messages from a channel."""
    ws_id, ch_id = _require_ws_and_ch(workspace, channel)
    with MemorizedClient(_base_url(), ws_id, ch_id, api_token=_api_token()) as c:
        msgs = c.read(since=since, limit=limit)
    table = Table(title=f"Messages ({len(msgs)}) · since={since}")
    table.add_column("id", style="cyan", justify="right")
    table.add_column("user_id")
    table.add_column("conf", justify="right")
    table.add_column("tags")
    table.add_column("text")
    for m in msgs:
        conf_str = f"{m.confidence:.0%}" if m.confidence is not None else ""
        table.add_row(str(m.id), m.user_id, conf_str, ",".join(m.tags), m.text)
    console.print(table)


@msg_app.command("edit")
def msg_edit(
    msg_id: MsgIdOpt,
    workspace: WorkspaceOpt = None,
    channel: ChannelOpt = None,
    text: Annotated[str | None, typer.Option("--text", help="New message text.")] = None,
    tag: Annotated[list[str] | None, typer.Option("--tag", help="New tags (replaces all).")] = None,
    confidence: Annotated[float | None, typer.Option("--confidence", help="New confidence 0.0–1.0.")] = None,
) -> None:
    """Edit an existing message."""
    ws_id, ch_id = _require_ws_and_ch(workspace, channel)
    with MemorizedClient(_base_url(), ws_id, ch_id, api_token=_api_token()) as c:
        m = c.edit(msg_id, text=text, tags=tag, confidence=confidence)
    console.print(f"[green]edited[/green] id=[cyan]{m.id}[/cyan]")


@msg_app.command("delete")
def msg_delete(
    msg_id: MsgIdOpt,
    workspace: WorkspaceOpt = None,
    channel: ChannelOpt = None,
) -> None:
    """Soft-delete a message."""
    ws_id, ch_id = _require_ws_and_ch(workspace, channel)
    with MemorizedClient(_base_url(), ws_id, ch_id, api_token=_api_token()) as c:
        c.delete(msg_id)
    console.print(f"[green]deleted[/green] id=[cyan]{msg_id}[/cyan]")


@msg_app.command("comment")
def msg_comment(
    msg_id: MsgIdOpt,
    text: Annotated[str, typer.Option("--text", help="Comment text.")],
    workspace: WorkspaceOpt = None,
    channel: ChannelOpt = None,
    user_id: UserIdOpt = None,
) -> None:
    """Add a comment to a message."""
    ws_id, ch_id = _require_ws_and_ch(workspace, channel)
    ag_id = _require(user_id, USER_ID_ENV, "--user-id")
    with MemorizedClient(
        _base_url(), ws_id, ch_id, user_id=ag_id, api_token=_api_token(),
    ) as c:
        r = c.add_comment(msg_id, text)
    console.print(
        f"[green]commented[/green] id=[cyan]{r.id}[/cyan] on msg [cyan]{msg_id}[/cyan]"
    )


@msg_app.command("comments")
def msg_comments(
    msg_id: MsgIdOpt,
    workspace: WorkspaceOpt = None,
    channel: ChannelOpt = None,
) -> None:
    """List comments on a message."""
    ws_id, ch_id = _require_ws_and_ch(workspace, channel)
    with MemorizedClient(_base_url(), ws_id, ch_id, api_token=_api_token()) as c:
        comments = c.list_comments(msg_id)
    table = Table(title=f"Comments on message {msg_id} ({len(comments)})")
    table.add_column("id", style="cyan", justify="right")
    table.add_column("user_id")
    table.add_column("text")
    for co in comments:
        table.add_row(str(co.id), co.user_id, co.text)
    console.print(table)


# ---------------------------------------------------------------------------
# admin — fine-grained token lifecycle
# ---------------------------------------------------------------------------


ADMIN_TOKEN_ENV = "MEMORIZED_ADMIN_TOKEN"


def _admin_token() -> str:
    """Pull the bootstrap super-admin bearer from env; error if missing."""
    token = os.environ.get(ADMIN_TOKEN_ENV)
    if not token:
        raise typer.BadParameter(
            f"set ${ADMIN_TOKEN_ENV} to the bootstrap super-admin token "
            "before calling `memorized admin ...`"
        )
    return token


def _admin_request(
    method: str, path: str, *, json: dict[str, object] | None = None,
) -> httpx.Response:
    """Hit /admin/* on the running server with the super-admin bearer."""
    headers = {"Authorization": f"Bearer {_admin_token()}"}
    try:
        r = httpx.request(
            method,
            f"{_base_url()}{path}",
            json=json,
            headers=headers,
            timeout=30.0,
        )
    except httpx.TransportError as exc:
        err_console.print(f"[red]transport error[/red] {type(exc).__name__}: {exc}")
        raise typer.Exit(code=2) from exc
    if r.status_code >= 400:
        try:
            body = r.json().get("error", {})
            err_console.print(
                f"[red]error[/red] [bold]{body.get('code', '?')}[/bold] "
                f"([yellow]{r.status_code}[/yellow]) {body.get('message', r.text)}"
            )
        except ValueError:
            err_console.print(f"[red]error[/red] HTTP {r.status_code}: {r.text[:200]}")
        raise typer.Exit(code=2)
    return r


_LEVEL_CHOICES = "[none|read|write|admin]"


def _parse_scope(
    workspaces_raw: str | None, channels_raw: str | None,
) -> dict[str, object]:
    """Build a Scope-shaped dict from CLI inputs.

    ``workspaces_raw`` — ``"*"`` or ``"a,b,c"`` (missing / empty → ``"*"``).
    ``channels_raw`` — ``"*"`` or ``"ws/ch,ws2/ch2"`` to restrict further.
    """
    if workspaces_raw is None or workspaces_raw == "*":
        scope: dict[str, object] = {"workspace_ids": "*"}
    else:
        scope = {
            "workspace_ids": [
                w.strip() for w in workspaces_raw.split(",") if w.strip()
            ],
        }
    if channels_raw is None or channels_raw == "*":
        scope["channel_ids"] = "*"
    else:
        scope["channel_ids"] = [
            c.strip() for c in channels_raw.split(",") if c.strip()
        ]
    return scope


def _parse_expires_in(raw: str | None) -> int | None:
    """Accept '', None, '30d', '12h', '45m', or a raw number of seconds."""
    if not raw:
        return None
    raw = raw.strip()
    if raw.isdigit():
        return int(raw)
    unit = raw[-1].lower()
    try:
        n = int(raw[:-1])
    except ValueError as exc:
        raise typer.BadParameter(
            f"--expires-in must be e.g. '30d', '12h', '45m' or seconds; got {raw!r}"
        ) from exc
    if unit == "d":
        return n * 86400
    if unit == "h":
        return n * 3600
    if unit == "m":
        return n * 60
    if unit == "s":
        return n
    raise typer.BadParameter(
        f"--expires-in unit must be d/h/m/s; got {raw!r}"
    )


@admin_app.command("create-token")
def admin_create_token(
    user_id: Annotated[
        str,
        typer.Option("--user-id", help="Agent id bound to this token (unique)."),
    ],
    name: Annotated[
        str | None,
        typer.Option("--name", help="Optional display label."),
    ] = None,
    workspaces: Annotated[
        str | None,
        typer.Option(
            "--workspaces",
            help="Comma-separated workspace ids, or '*' for all. Default: [] (no scope).",
        ),
    ] = None,
    channels: Annotated[
        str | None,
        typer.Option(
            "--channels",
            help=(
                "Comma-separated 'ws/ch' ids to restrict further, or '*' for "
                "all channels in the listed workspaces. Default: '*'."
            ),
        ),
    ] = None,
    workspace_perm: Annotated[
        str, typer.Option("--workspace-perm", help=f"Workspace permission {_LEVEL_CHOICES}."),
    ] = "none",
    channel_perm: Annotated[
        str, typer.Option("--channel-perm", help=f"Channel permission {_LEVEL_CHOICES}."),
    ] = "none",
    message_perm: Annotated[
        str, typer.Option("--message-perm", help=f"Message permission {_LEVEL_CHOICES}."),
    ] = "none",
    comment_perm: Annotated[
        str, typer.Option("--comment-perm", help=f"Comment permission {_LEVEL_CHOICES}."),
    ] = "none",
    expires_in: Annotated[
        str | None,
        typer.Option(
            "--expires-in",
            help="Lifetime, e.g. '30d', '12h', '45m', or raw seconds. Omit for no expiry.",
        ),
    ] = None,
) -> None:
    """Create a fine-grained API token bound to ``user_id``.

    The plaintext secret is printed ONCE here and never stored. Copy it
    somewhere safe before leaving the terminal.
    """
    body: dict[str, object] = {
        "user_id": user_id,
        "name": name,
        "scope": _parse_scope(workspaces, channels),
        "permissions": {
            "workspace": workspace_perm,
            "channel": channel_perm,
            "message": message_perm,
            "comment": comment_perm,
        },
    }
    seconds = _parse_expires_in(expires_in)
    if seconds is not None:
        body["expires_in_seconds"] = seconds

    r = _admin_request("POST", "/admin/tokens", json=body)
    data = r.json()
    meta = data["metadata"]
    console.print(
        Panel.fit(
            f"[bold]user_id[/bold]    {meta['user_id']}\n"
            f"[bold]name[/bold]        {meta['name'] or '(none)'}\n"
            f"[bold]workspaces[/bold]  {meta['scope']['workspace_ids']}\n"
            f"[bold]channels[/bold]    {meta['scope'].get('channel_ids', '*')}\n"
            f"[bold]permissions[/bold] {meta['permissions']}\n"
            f"[bold]expires_at[/bold]  {meta['expires_at'] or '(no expiry)'}\n"
            f"\n[bold yellow]token (copy now — shown only this once):[/bold yellow]\n"
            f"[green]{data['token']}[/green]",
            title="token created",
            border_style="green",
        )
    )


@admin_app.command("list-tokens")
def admin_list_tokens() -> None:
    """List every credential the server knows about (metadata only)."""
    r = _admin_request("GET", "/admin/tokens")
    rows = r.json()
    table = Table(title=f"Tokens ({len(rows)})")
    table.add_column("user_id", style="cyan")
    table.add_column("name")
    table.add_column("workspaces")
    table.add_column("channels")
    table.add_column("perms")
    table.add_column("expires_at", justify="right")
    table.add_column("revoked", justify="center")
    for row in rows:
        perms = row["permissions"]
        perm_str = (
            f"W:{perms.get('workspace', 'none')[0]} "
            f"C:{perms.get('channel', 'none')[0]} "
            f"M:{perms.get('message', 'none')[0]} "
            f"Cm:{perms.get('comment', 'none')[0]}"
        )
        ws = row["scope"]["workspace_ids"]
        ws_str = "*" if ws == "*" else ",".join(ws) if ws else "(none)"
        ch = row["scope"].get("channel_ids", "*")
        ch_str = "*" if ch == "*" else ",".join(ch) if ch else "(none)"
        exp = f"{row['expires_at']:.0f}" if row["expires_at"] else "—"
        revoked = "yes" if row["revoked_at"] else ""
        table.add_row(
            row["user_id"], row["name"] or "",
            ws_str, ch_str, perm_str, exp, revoked,
        )
    console.print(table)


@admin_app.command("revoke")
def admin_revoke(
    user_id: Annotated[str, typer.Option("--user-id", help="Which token to revoke.")],
) -> None:
    """Revoke the credential bound to ``user_id`` (immediate effect)."""
    _admin_request("DELETE", f"/admin/tokens/{user_id}")
    console.print(f"[green]revoked[/green] token for user_id [cyan]{user_id}[/cyan]")


@admin_app.command("regenerate")
def admin_regenerate(
    user_id: Annotated[str, typer.Option("--user-id", help="Which token to regenerate.")],
) -> None:
    """Issue a new secret for an existing token; old one stops working."""
    r = _admin_request("POST", f"/admin/tokens/{user_id}/regenerate")
    data = r.json()
    console.print(
        Panel.fit(
            f"[bold]user_id[/bold] {data['metadata']['user_id']}\n\n"
            f"[bold yellow]new token (copy now — shown only this once):[/bold yellow]\n"
            f"[green]{data['token']}[/green]",
            title="regenerated",
            border_style="green",
        )
    )


# ---------------------------------------------------------------------------
# error rendering
# ---------------------------------------------------------------------------


def _render_error(exc: MemorizedError) -> None:
    err_console.print(
        f"[red]error[/red] [bold]{exc.code.value}[/bold] "
        f"([yellow]{exc.status}[/yellow])"
    )
    err_console.print(f"  {exc.message}")
    if exc.hint:
        err_console.print(f"  [dim]hint:[/dim] {exc.hint}")
    if exc.fields:
        err_console.print("  [dim]fields:[/dim]")
        for f in exc.fields:
            err_console.print(f"    [yellow]{f.loc}[/yellow]: {f.msg} [dim]({f.type})[/dim]")
    if exc.context:
        err_console.print("  [dim]context:[/dim]")
        for k, v in exc.context.items():
            err_console.print(f"    {k}: {v}")


def main() -> None:
    """Entry point for the ``memorized`` console script."""
    try:
        app()
    except MemorizedError as exc:
        _render_error(exc)
        sys.exit(2)


if __name__ == "__main__":
    main()
