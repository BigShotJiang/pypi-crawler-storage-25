"""Wire schemas shared by every layer (server, client, MCP, CLI).

Pure pydantic — no FastAPI, no SQLModel, no httpx imports — so both sides of
the wire (server handlers and client parsers) can speak the same types
without pulling in each other's frameworks.
"""
from __future__ import annotations

from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class ErrorCode(StrEnum):
    validation_error = "validation_error"
    workspace_not_found = "workspace_not_found"
    channel_not_found = "channel_not_found"
    not_found = "not_found"
    method_not_allowed = "method_not_allowed"
    bad_request = "bad_request"
    unauthorized = "unauthorized"
    forbidden = "forbidden"
    transport_error = "transport_error"
    internal_error = "internal_error"


class FieldError(BaseModel):
    """One pydantic validation failure, reshaped for agent consumption."""

    loc: str
    msg: str
    type: str


class ErrorBody(BaseModel):
    code: ErrorCode
    message: str
    status: int
    hint: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    fields: list[FieldError] = Field(default_factory=list)


class ErrorResponse(BaseModel):
    error: ErrorBody


# ---------------------------------------------------------------------------
# Workspaces (top-level container; groups related channels)
# ---------------------------------------------------------------------------


class WorkspaceCreate(BaseModel):
    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_\-\.]+$")
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkspaceOut(BaseModel):
    id: str
    metadata: dict[str, Any]
    created_at: float
    channel_count: int = 0


# ---------------------------------------------------------------------------
# Channels (shared chat streams inside a workspace; hold messages)
# ---------------------------------------------------------------------------


class ChannelCreate(BaseModel):
    id: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_\-\.]+$")
    metadata: dict[str, Any] = Field(default_factory=dict)


class ChannelOut(BaseModel):
    id: str
    workspace_id: str
    metadata: dict[str, Any]
    created_at: float
    message_count: int = 0


# ---------------------------------------------------------------------------
# Messages
# ---------------------------------------------------------------------------


class MessageIn(BaseModel):
    """Request body for creating a message.

    ``user_id`` in the body is accepted but always ignored — the server
    derives the author from the caller's token. This is the anti-
    impersonation bind: one token holder cannot post as another user.
    """

    user_id: str | None = Field(default=None, min_length=1)
    text: str = Field(min_length=1)
    tags: list[str] = Field(default_factory=list)
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)


class MessageUpdate(BaseModel):
    """Partial update — only fields present in the request body are applied."""

    text: str | None = Field(default=None, min_length=1)
    tags: list[str] | None = None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)


class MessageOut(BaseModel):
    id: int
    user_id: str
    text: str
    tags: list[str]
    confidence: float | None = None
    ts: float
    edited_at: float | None = None
    edited_by: str | None = None
    deleted: bool = False
    deleted_by: str | None = None
    # Populated by list / search endpoints so the UI can flag threaded
    # messages without a second request. Single-message mutations
    # (POST/PATCH/DELETE) return 0 — refetch to get a live count.
    comment_count: int = 0


class MessageCreateOut(BaseModel):
    id: int


# ---------------------------------------------------------------------------
# Comments
# ---------------------------------------------------------------------------


class CommentIn(BaseModel):
    """Request body for creating a comment.

    ``user_id`` in the body is accepted but always ignored — the server
    derives the author from the caller's token.
    """

    user_id: str | None = Field(default=None, min_length=1)
    text: str = Field(min_length=1)


class CommentOut(BaseModel):
    id: int
    message_id: int
    user_id: str
    text: str
    ts: float


# ---------------------------------------------------------------------------
# Agent credentials / fine-grained tokens
# ---------------------------------------------------------------------------


PermissionLevel = Literal["none", "read", "write", "admin"]
"""One level per resource kind. ``admin`` implies ``write`` implies ``read``."""

ResourceKind = Literal["workspace", "channel", "message", "comment"]

_LEVEL_ORDER: dict[str, int] = {"none": 0, "read": 1, "write": 2, "admin": 3}


def _cmp_level(a: str, b: str) -> int:
    """Compare two permission levels. Returns negative / zero / positive."""
    return _LEVEL_ORDER[a] - _LEVEL_ORDER[b]


class Permissions(BaseModel):
    """Per-resource permission levels. Unset resource defaults to ``"none"``."""

    workspace: PermissionLevel = "none"
    channel: PermissionLevel = "none"
    message: PermissionLevel = "none"
    comment: PermissionLevel = "none"

    def level(self, resource: ResourceKind) -> PermissionLevel:
        return getattr(self, resource)  # type: ignore[no-any-return]

    def allows(self, resource: ResourceKind, required: PermissionLevel) -> bool:
        return _cmp_level(self.level(resource), required) >= 0


class Scope(BaseModel):
    """Which workspaces and channels a token can touch.

    - ``workspace_ids`` — list of workspace ids, or ``"*"`` for every
      workspace. Controls workspace-level operations and is the outer
      gate for channel/message/comment operations.
    - ``channel_ids`` — list of fully-qualified ``"ws_id/ch_id"`` entries,
      or ``"*"`` for every channel. When a workspace has **no** entries
      in this list (but is allowed by ``workspace_ids``), all its
      channels are allowed. When a workspace has at least one entry,
      only the listed channels are allowed. This keeps common cases
      (e.g. "all channels in ws-a, only ch-1 in ws-b") expressible
      without a nested structure.
    """

    workspace_ids: list[str] | Literal["*"] = Field(default_factory=list)
    channel_ids: list[str] | Literal["*"] = "*"

    @field_validator("workspace_ids")
    @classmethod
    def _normalize_workspace_ids(
        cls, v: list[str] | str
    ) -> list[str] | Literal["*"]:
        if isinstance(v, str):
            if v != "*":
                raise ValueError("workspace_ids string form must be '*'")
            return "*"
        return list(v)

    @field_validator("channel_ids")
    @classmethod
    def _normalize_channel_ids(
        cls, v: list[str] | str
    ) -> list[str] | Literal["*"]:
        if isinstance(v, str):
            if v != "*":
                raise ValueError("channel_ids string form must be '*'")
            return "*"
        # Every entry must be "ws_id/ch_id" — fail fast on mis-shaped data.
        for entry in v:
            if "/" not in entry or entry.startswith("/") or entry.endswith("/"):
                raise ValueError(
                    f"channel_ids entry must be 'workspace_id/channel_id', got {entry!r}"
                )
        return list(v)

    def covers_workspace(self, workspace_id: str | None) -> bool:
        """True if the token applies to the given workspace. ``None`` means
        the endpoint is not workspace-scoped (e.g. POST /workspaces)."""
        if workspace_id is None:
            return True
        if self.workspace_ids == "*":
            return True
        return workspace_id in self.workspace_ids

    def covers_channel(self, workspace_id: str, channel_id: str) -> bool:
        """True if the token applies to the given channel.

        Rules (both must hold):
        - The workspace must be covered.
        - Either ``channel_ids`` is ``"*"``, OR the workspace has no
          entries in ``channel_ids`` (= unrestricted within that ws), OR
          the specific ``ws/ch`` is listed.
        """
        if not self.covers_workspace(workspace_id):
            return False
        if self.channel_ids == "*":
            return True
        prefix = f"{workspace_id}/"
        has_entry_for_ws = any(e.startswith(prefix) for e in self.channel_ids)
        if not has_entry_for_ws:
            return True
        return f"{workspace_id}/{channel_id}" in self.channel_ids


class TokenCreate(BaseModel):
    """Body of ``POST /admin/tokens``."""

    user_id: str = Field(min_length=1, max_length=128)
    name: str | None = Field(default=None, max_length=128)
    scope: Scope = Field(default_factory=Scope)
    permissions: Permissions = Field(default_factory=Permissions)
    expires_in_seconds: int | None = Field(default=None, ge=60)

    @field_validator("user_id")
    @classmethod
    def _no_admin_prefix(cls, v: str) -> str:
        # Reserve "admin" as a server-owned user_id for the bootstrap token.
        if v.lower() == "admin":
            raise ValueError("'admin' is reserved for the bootstrap super-admin")
        return v


class TokenOut(BaseModel):
    """Metadata for an existing token (never includes the plaintext secret)."""

    user_id: str
    name: str | None
    scope: Scope
    permissions: Permissions
    expires_at: float | None
    created_at: float
    revoked_at: float | None


class TokenCreateOut(BaseModel):
    """Response to POST /admin/tokens — the **only** time the plaintext is shown."""

    token: str
    metadata: TokenOut


class HealthIdentityOut(BaseModel):
    """Server-resolved identity + capabilities surfaced in ``/healthz``.

    The UI uses ``permissions`` + ``scope`` to decide which buttons /
    composers to render — the server is still the source of truth on
    every request, so these fields are a UX hint, not a security gate.
    """

    user_id: str
    is_super_admin: bool
    permissions: Permissions
    scope: Scope


class HealthOut(BaseModel):
    """Public health + server info. No auth required.

    ``identity`` echoes the caller's resolved identity so the UI can
    display "you are signed in as X"; it's ``null`` when no valid token
    was sent.
    """

    version: str
    time: float
    identity: HealthIdentityOut | None = None


class AuditLogEntryOut(BaseModel):
    """A single audit log row from ``GET /admin/audit``."""

    id: int
    ts: float
    actor_id: str
    action: str
    target: str | None
    context: dict[str, object] = Field(default_factory=dict)
