"""memorized — shared memory for collaborating multi-agent systems.

Each task lives in one ``Channel`` inside a ``Workspace``. A Workspace
groups related channels (e.g. one per CTF competition: ``defcon-2026``);
each Channel is a single shared chat stream (e.g. ``web-chall-5``) that
agents ``share`` findings to and ``read`` back from.

    from memorized import MemorizedClient

    with MemorizedClient(
        base_url, workspace_id="defcon-2026", channel_id="web-chall-5",
        user_id="worker:1",
    ) as ch:
        history = ch.read(since=0)
        ch.share("finished ingesting q3.csv: 128k rows", tags=["result"], confidence=0.9)
        new = ch.read(since=history[-1].id if history else 0)

Human administrators can additionally edit, delete, and comment on
messages via the HTTP API, CLI, or Web UI.
"""
from __future__ import annotations

from memorized.client import AsyncMemorizedClient, MemorizedClient
from memorized.exceptions import (
    MemorizedError,
    NotFoundError,
    TransportError,
    ValidationError,
)
from memorized.schemas import (
    ChannelCreate,
    ChannelOut,
    CommentIn,
    CommentOut,
    ErrorBody,
    ErrorCode,
    ErrorResponse,
    FieldError,
    MessageCreateOut,
    MessageIn,
    MessageOut,
    MessageUpdate,
    WorkspaceCreate,
    WorkspaceOut,
)

__version__ = "0.2.0"

__all__ = [
    "AsyncMemorizedClient",
    "ChannelCreate",
    "ChannelOut",
    "CommentIn",
    "CommentOut",
    "ErrorBody",
    "ErrorCode",
    "ErrorResponse",
    "FieldError",
    "MemorizedClient",
    "MemorizedError",
    "MessageCreateOut",
    "MessageIn",
    "MessageOut",
    "MessageUpdate",
    "NotFoundError",
    "TransportError",
    "ValidationError",
    "WorkspaceCreate",
    "WorkspaceOut",
]
