"""Sync + async HTTP clients for the memorized server.

Two classes, ``MemorizedClient`` (sync) and ``AsyncMemorizedClient`` (async),
wrap the server's endpoint surface:

- ``create_workspace`` / ``list_workspaces`` / ``delete_workspace`` — classmethods (top-level container CRUD)
- ``create_channel`` / ``list_channels`` / ``delete_channel`` — classmethods (channel CRUD inside a workspace)
- ``share`` / ``read`` / ``edit`` / ``delete`` / ``add_comment`` / ``list_comments``
  — instance methods scoped to one ``(workspace_id, channel_id)`` pair

The scheduler injects ``workspace_id``, ``channel_id``, and ``user_id``
when it constructs the client. ``user_id`` is required for ``share`` but
unused by ``read``, so it is optional — a read-only client (e.g. a
dashboard) can pass ``None``. ``channel_id`` is also optional at
construction time; if omitted, every per-channel method requires an
explicit ``channel_id`` keyword argument. This lets a single client
instance work across multiple channels within the same workspace — useful
for MCP-style agents that discover channels at runtime.

Example (channel-scoped — classic usage)::

    from memorized import MemorizedClient

    with MemorizedClient(
        base_url, workspace_id="defcon-2026", channel_id="web-chall-5",
        user_id="worker:1",
    ) as ch:
        history = ch.read(since=0)            # catch up on restart
        ch.share(
            "finished ingesting q3.csv: 128k rows, 3 schema drifts",
            tags=["ingestion", "result"],
        )
        new = ch.read(since=history[-1].id if history else 0)
        drifts = ch.read(since=0, q="drift", tags=["ingestion"])

Example (workspace-scoped — agent picks the channel per call)::

    with MemorizedClient(base_url, "defcon-2026", None, user_id="worker:1") as c:
        channels = MemorizedClient.list_channels(base_url, "defcon-2026")
        c.share("hello", channel_id=channels[0].id)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from memorized.exceptions import raise_for_response, wrap_transport_error
from memorized.schemas import (
    ChannelCreate,
    ChannelOut,
    CommentIn,
    CommentOut,
    MessageCreateOut,
    MessageIn,
    MessageOut,
    MessageUpdate,
    WorkspaceCreate,
    WorkspaceOut,
)

# ---------------------------------------------------------------------------
# Wire operations — transport-agnostic description of each endpoint
# ---------------------------------------------------------------------------

_UNSET: Any = object()
"""Sentinel distinguishing 'caller omitted the argument' from 'caller passed None'."""


@dataclass(frozen=True, slots=True)
class _Op:
    method: str
    path: str
    json: dict[str, Any] | None = None
    params: dict[str, Any] | None = None


# workspace ops -------------------------------------------------------------


def _op_create_workspace(id: str, metadata: dict[str, Any] | None = None) -> _Op:
    return _Op(
        "POST",
        "/workspaces",
        json=WorkspaceCreate(id=id, metadata=metadata or {}).model_dump(mode="json"),
    )


def _op_list_workspaces() -> _Op:
    return _Op("GET", "/workspaces")


def _op_delete_workspace(ws: str) -> _Op:
    return _Op("DELETE", f"/workspaces/{ws}")


# channel ops ---------------------------------------------------------------


def _op_create_channel(ws: str, id: str, metadata: dict[str, Any] | None = None) -> _Op:
    return _Op(
        "POST",
        f"/workspaces/{ws}/channels",
        json=ChannelCreate(id=id, metadata=metadata or {}).model_dump(mode="json"),
    )


def _op_list_channels(ws: str) -> _Op:
    return _Op("GET", f"/workspaces/{ws}/channels")


def _op_delete_channel(ws: str, ch: str) -> _Op:
    return _Op("DELETE", f"/workspaces/{ws}/channels/{ch}")


# message ops ---------------------------------------------------------------


def _msg_base(ws: str, ch: str) -> str:
    return f"/workspaces/{ws}/channels/{ch}/messages"


def _op_share(
    ws: str, ch: str, user_id: str | None, text: str, tags: list[str],
    confidence: float | None = None,
) -> _Op:
    body = MessageIn(
        user_id=user_id, text=text, tags=tags, confidence=confidence
    ).model_dump(mode="json")
    return _Op("POST", _msg_base(ws, ch), json=body)


def _op_read(
    ws: str, ch: str, since: int, limit: int,
    q: str | None = None, tags: list[str] | None = None,
) -> _Op:
    params: dict[str, Any] = {"since": since, "limit": limit}
    if q is not None:
        params["q"] = q
    if tags:
        params["tags"] = list(tags)
    return _Op("GET", _msg_base(ws, ch), params=params)


def _op_edit(
    ws: str, ch: str, msg_id: int, text: str | None, tags: list[str] | None,
    confidence: float | None, fields_set: set[str],
) -> _Op:
    body = MessageUpdate(text=text, tags=tags, confidence=confidence)
    # Only include fields the caller explicitly set.
    payload = body.model_dump(mode="json", include=fields_set)
    return _Op("PATCH", f"{_msg_base(ws, ch)}/{msg_id}", json=payload)


def _op_delete_msg(ws: str, ch: str, msg_id: int) -> _Op:
    return _Op("DELETE", f"{_msg_base(ws, ch)}/{msg_id}")


def _op_add_comment(
    ws: str, ch: str, msg_id: int, user_id: str | None, comment_text: str
) -> _Op:
    body = CommentIn(user_id=user_id, text=comment_text).model_dump(mode="json")
    return _Op("POST", f"{_msg_base(ws, ch)}/{msg_id}/comments", json=body)


def _op_list_comments(ws: str, ch: str, msg_id: int) -> _Op:
    return _Op("GET", f"{_msg_base(ws, ch)}/{msg_id}/comments")


def _auth_headers(api_token: str | None) -> dict[str, str]:
    if api_token:
        return {"Authorization": f"Bearer {api_token}"}
    return {}


def _require_user(user_id: str | None) -> str | None:
    """Return ``user_id`` as-is.

    Historically this raised when missing because the server treated the
    field as required. With fine-grained tokens the server derives
    ``user_id`` from the bearer on every write, so ``None`` is fine and
    the field is ignored server-side. Kept as a function (not inlined) so
    callers still have a single place to add client-side warnings later.
    """
    return user_id


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------


class MemorizedClient:
    """Synchronous HTTP client scoped to one workspace, optionally one channel.

    ``channel_id`` defaults the per-channel instance methods. Passing
    ``channel_id=None`` at construction time is allowed — then every
    per-channel method requires the keyword argument explicitly.
    """

    def __init__(
        self,
        base_url: str,
        workspace_id: str,
        channel_id: str | None,
        *,
        user_id: str | None = None,
        api_token: str | None = None,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.workspace_id = workspace_id
        self.channel_id = channel_id
        self.user_id = user_id
        headers = _auth_headers(api_token)
        self._http = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            transport=transport,
            headers=headers,
        )

    def _resolve_channel(self, channel_id: str | None) -> str:
        ch = channel_id if channel_id is not None else self.channel_id
        if ch is None:
            raise ValueError(
                "channel_id must be supplied either at client construction "
                "or as a per-call keyword argument",
            )
        return ch

    def _do(self, op: _Op) -> httpx.Response:
        try:
            r = self._http.request(
                op.method, op.path, json=op.json, params=op.params
            )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc, base_url=self.base_url) from exc
        raise_for_response(r)
        return r

    # workspaces (classmethods) ----------------------------------------
    @classmethod
    def create_workspace(
        cls, base_url: str, id: str, metadata: dict[str, Any] | None = None,
        *, api_token: str | None = None,
    ) -> WorkspaceOut:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_token)) as http:
            op = _op_create_workspace(id, metadata)
            try:
                r = http.request(op.method, op.path, json=op.json)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return WorkspaceOut.model_validate(r.json())

    @classmethod
    def list_workspaces(cls, base_url: str, *, api_token: str | None = None) -> list[WorkspaceOut]:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_token)) as http:
            op = _op_list_workspaces()
            try:
                r = http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return [WorkspaceOut.model_validate(item) for item in r.json()]

    @classmethod
    def delete_workspace(
        cls, base_url: str, id: str, *, api_token: str | None = None,
    ) -> None:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_token)) as http:
            op = _op_delete_workspace(id)
            try:
                r = http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)

    # channels (classmethods) ------------------------------------------
    @classmethod
    def create_channel(
        cls, base_url: str, workspace_id: str, id: str,
        metadata: dict[str, Any] | None = None,
        *, api_token: str | None = None,
    ) -> ChannelOut:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_token)) as http:
            op = _op_create_channel(workspace_id, id, metadata)
            try:
                r = http.request(op.method, op.path, json=op.json)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return ChannelOut.model_validate(r.json())

    @classmethod
    def list_channels(
        cls, base_url: str, workspace_id: str, *, api_token: str | None = None,
    ) -> list[ChannelOut]:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_token)) as http:
            op = _op_list_channels(workspace_id)
            try:
                r = http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return [ChannelOut.model_validate(item) for item in r.json()]

    @classmethod
    def delete_channel(
        cls, base_url: str, workspace_id: str, channel_id: str,
        *, api_token: str | None = None,
    ) -> None:
        with httpx.Client(base_url=base_url.rstrip("/"), headers=_auth_headers(api_token)) as http:
            op = _op_delete_channel(workspace_id, channel_id)
            try:
                r = http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)

    # messages (instance methods) --------------------------------------
    def share(
        self, text: str, tags: list[str] | None = None,
        confidence: float | None = None,
        *, channel_id: str | None = None,
    ) -> MessageCreateOut:
        op = _op_share(
            self.workspace_id, self._resolve_channel(channel_id),
            _require_user(self.user_id), text, tags or [],
            confidence=confidence,
        )
        return MessageCreateOut.model_validate(self._do(op).json())

    def read(
        self, since: int = 0, limit: int = 500,
        *, q: str | None = None, tags: list[str] | None = None,
        channel_id: str | None = None,
    ) -> list[MessageOut]:
        op = _op_read(
            self.workspace_id, self._resolve_channel(channel_id), since, limit,
            q=q, tags=tags,
        )
        return [MessageOut.model_validate(item) for item in self._do(op).json()]

    def edit(
        self,
        msg_id: int,
        *,
        text: str | None | Any = _UNSET,
        tags: list[str] | None | Any = _UNSET,
        confidence: float | None | Any = _UNSET,
        channel_id: str | None = None,
    ) -> MessageOut:
        # Track which kwargs the caller actually passed.
        fields: set[str] = set()
        if text is not _UNSET:
            fields.add("text")
        if tags is not _UNSET:
            fields.add("tags")
        if confidence is not _UNSET:
            fields.add("confidence")
        op = _op_edit(
            self.workspace_id, self._resolve_channel(channel_id), msg_id,
            text if text is not _UNSET else None,
            tags if tags is not _UNSET else None,
            confidence if confidence is not _UNSET else None,
            fields,
        )
        return MessageOut.model_validate(self._do(op).json())

    def delete(self, msg_id: int, *, channel_id: str | None = None) -> None:
        op = _op_delete_msg(
            self.workspace_id, self._resolve_channel(channel_id), msg_id,
        )
        self._do(op)

    def add_comment(
        self, msg_id: int, text: str,
        *, channel_id: str | None = None,
    ) -> CommentOut:
        op = _op_add_comment(
            self.workspace_id, self._resolve_channel(channel_id), msg_id,
            _require_user(self.user_id), text,
        )
        return CommentOut.model_validate(self._do(op).json())

    def list_comments(
        self, msg_id: int, *, channel_id: str | None = None,
    ) -> list[CommentOut]:
        op = _op_list_comments(
            self.workspace_id, self._resolve_channel(channel_id), msg_id,
        )
        return [CommentOut.model_validate(item) for item in self._do(op).json()]

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> MemorizedClient:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Asynchronous client
# ---------------------------------------------------------------------------


class AsyncMemorizedClient:
    """Async mirror of ``MemorizedClient``."""

    def __init__(
        self,
        base_url: str,
        workspace_id: str,
        channel_id: str | None,
        *,
        user_id: str | None = None,
        api_token: str | None = None,
        timeout: float = 30.0,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.workspace_id = workspace_id
        self.channel_id = channel_id
        self.user_id = user_id
        headers = _auth_headers(api_token)
        self._http = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            transport=transport,
            headers=headers,
        )

    def _resolve_channel(self, channel_id: str | None) -> str:
        ch = channel_id if channel_id is not None else self.channel_id
        if ch is None:
            raise ValueError(
                "channel_id must be supplied either at client construction "
                "or as a per-call keyword argument",
            )
        return ch

    async def _do(self, op: _Op) -> httpx.Response:
        try:
            r = await self._http.request(
                op.method, op.path, json=op.json, params=op.params
            )
        except httpx.TransportError as exc:
            raise wrap_transport_error(exc, base_url=self.base_url) from exc
        raise_for_response(r)
        return r

    # workspaces (classmethods) ----------------------------------------
    @classmethod
    async def create_workspace(
        cls, base_url: str, id: str, metadata: dict[str, Any] | None = None,
        *, api_token: str | None = None,
    ) -> WorkspaceOut:
        headers = _auth_headers(api_token)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_create_workspace(id, metadata)
            try:
                r = await http.request(op.method, op.path, json=op.json)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return WorkspaceOut.model_validate(r.json())

    @classmethod
    async def list_workspaces(
        cls, base_url: str, *, api_token: str | None = None,
    ) -> list[WorkspaceOut]:
        headers = _auth_headers(api_token)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_list_workspaces()
            try:
                r = await http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return [WorkspaceOut.model_validate(item) for item in r.json()]

    @classmethod
    async def delete_workspace(
        cls, base_url: str, id: str, *, api_token: str | None = None,
    ) -> None:
        headers = _auth_headers(api_token)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_delete_workspace(id)
            try:
                r = await http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)

    # channels (classmethods) ------------------------------------------
    @classmethod
    async def create_channel(
        cls, base_url: str, workspace_id: str, id: str,
        metadata: dict[str, Any] | None = None,
        *, api_token: str | None = None,
    ) -> ChannelOut:
        headers = _auth_headers(api_token)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_create_channel(workspace_id, id, metadata)
            try:
                r = await http.request(op.method, op.path, json=op.json)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return ChannelOut.model_validate(r.json())

    @classmethod
    async def list_channels(
        cls, base_url: str, workspace_id: str, *, api_token: str | None = None,
    ) -> list[ChannelOut]:
        headers = _auth_headers(api_token)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_list_channels(workspace_id)
            try:
                r = await http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)
            return [ChannelOut.model_validate(item) for item in r.json()]

    @classmethod
    async def delete_channel(
        cls, base_url: str, workspace_id: str, channel_id: str,
        *, api_token: str | None = None,
    ) -> None:
        headers = _auth_headers(api_token)
        async with httpx.AsyncClient(base_url=base_url.rstrip("/"), headers=headers) as http:
            op = _op_delete_channel(workspace_id, channel_id)
            try:
                r = await http.request(op.method, op.path)
            except httpx.TransportError as exc:
                raise wrap_transport_error(exc, base_url=base_url) from exc
            raise_for_response(r)

    # messages (instance methods) --------------------------------------
    async def share(
        self, text: str, tags: list[str] | None = None,
        confidence: float | None = None,
        *, channel_id: str | None = None,
    ) -> MessageCreateOut:
        op = _op_share(
            self.workspace_id, self._resolve_channel(channel_id),
            _require_user(self.user_id), text, tags or [],
            confidence=confidence,
        )
        r = await self._do(op)
        return MessageCreateOut.model_validate(r.json())

    async def read(
        self, since: int = 0, limit: int = 500,
        *, q: str | None = None, tags: list[str] | None = None,
        channel_id: str | None = None,
    ) -> list[MessageOut]:
        r = await self._do(_op_read(
            self.workspace_id, self._resolve_channel(channel_id), since, limit,
            q=q, tags=tags,
        ))
        return [MessageOut.model_validate(item) for item in r.json()]

    async def edit(
        self,
        msg_id: int,
        *,
        text: str | None | Any = _UNSET,
        tags: list[str] | None | Any = _UNSET,
        confidence: float | None | Any = _UNSET,
        channel_id: str | None = None,
    ) -> MessageOut:
        fields: set[str] = set()
        if text is not _UNSET:
            fields.add("text")
        if tags is not _UNSET:
            fields.add("tags")
        if confidence is not _UNSET:
            fields.add("confidence")
        op = _op_edit(
            self.workspace_id, self._resolve_channel(channel_id), msg_id,
            text if text is not _UNSET else None,
            tags if tags is not _UNSET else None,
            confidence if confidence is not _UNSET else None,
            fields,
        )
        r = await self._do(op)
        return MessageOut.model_validate(r.json())

    async def delete(self, msg_id: int, *, channel_id: str | None = None) -> None:
        await self._do(_op_delete_msg(
            self.workspace_id, self._resolve_channel(channel_id), msg_id,
        ))

    async def add_comment(
        self, msg_id: int, text: str,
        *, channel_id: str | None = None,
    ) -> CommentOut:
        op = _op_add_comment(
            self.workspace_id, self._resolve_channel(channel_id), msg_id,
            _require_user(self.user_id), text,
        )
        r = await self._do(op)
        return CommentOut.model_validate(r.json())

    async def list_comments(
        self, msg_id: int, *, channel_id: str | None = None,
    ) -> list[CommentOut]:
        r = await self._do(
            _op_list_comments(
                self.workspace_id, self._resolve_channel(channel_id), msg_id,
            )
        )
        return [CommentOut.model_validate(item) for item in r.json()]

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> AsyncMemorizedClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()
