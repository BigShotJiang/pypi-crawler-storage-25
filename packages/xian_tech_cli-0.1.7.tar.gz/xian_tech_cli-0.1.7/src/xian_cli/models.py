from __future__ import annotations

import decimal
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

from xian_runtime_types.decimal import ContractingDecimal
from xian_runtime_types.encoding import encode
from xian_runtime_types.time import Datetime

SCHEMA_VERSION = 1
SUPPORTED_NETWORK_MODES = {"join", "create"}
SUPPORTED_BLOCK_POLICY_MODES = {"on_demand", "idle_interval", "periodic"}
SUPPORTED_NODE_IMAGE_MODES = {"local_build", "registry"}
SUPPORTED_OPERATOR_PROFILES = {
    "local_development",
    "indexed_development",
    "shared_network",
    "embedded_backend",
}
SUPPORTED_MONITORING_PROFILES = {
    "none",
    "local_stack",
    "service_node",
}
SUPPORTED_INTENTKIT_NETWORK_IDS = {
    "xian-mainnet",
    "xian-testnet",
    "xian-devnet",
    "xian-localnet",
}
SUPPORTED_SHIELDED_RELAYER_AUTH_SCHEMES = {"none", "bearer"}
SUPPORTED_SHIELDED_RELAYER_SUBMISSION_KINDS = {
    "shielded_note_relay_transfer",
    "shielded_command",
}
SUPPORTED_SHIELDED_HISTORY_COMPATIBILITY = {
    "best_effort",
    "versioned",
}
SUPPORTED_SHIELDED_HISTORY_RETENTION = {
    "operator_defined",
    "archive",
}
SUPPORTED_PRIVACY_DISCLOSURE_POLICIES = {
    "user_controlled",
    "network_governed",
}
SUPPORTED_APP_LOG_LEVELS = {
    "TRACE",
    "DEBUG",
    "INFO",
    "SUCCESS",
    "WARNING",
    "ERROR",
    "CRITICAL",
}
SUPPORTED_RECOVERY_ARTIFACT_KINDS = {"snapshot_url"}
MODULE_SCHEMA = "xian.module.v1"
SOLUTION_SCHEMA = "xian.solution.v1"
SUPPORTED_MODULE_INSTALL_KINDS = {
    "external",
    "xian-stack.localnet-dex-bootstrap",
}


def _require_str(payload: dict, key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a non-empty string")
    return value


def _require_optional_str(payload: dict, key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a non-empty string when provided")
    return value


def _require_sha256(payload: dict, key: str) -> str:
    value = _require_str(payload, key).lower()
    if len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value):
        raise ValueError(f"{key} must be a 64-character lowercase hex sha256")
    return value


def _require_optional_choice(
    payload: dict,
    key: str,
    *,
    supported: set[str],
    default: str | None = None,
) -> str | None:
    value = payload.get(key, default)
    if value is None:
        return None
    if not isinstance(value, str) or value not in supported:
        raise ValueError(f"{key} must be one of {sorted(supported)}")
    return value


def _require_bool(payload: dict, key: str, *, default: bool) -> bool:
    value = payload.get(key, default)
    if not isinstance(value, bool):
        raise ValueError(f"{key} must be a boolean")
    return value


def _require_int(payload: dict, key: str, *, default: int) -> int:
    value = payload.get(key, default)
    if not isinstance(value, int):
        raise ValueError(f"{key} must be an integer")
    return value


def _require_non_negative_int(payload: dict, key: str, *, default: int) -> int:
    value = payload.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{key} must be a non-negative integer")
    return value


def _require_positive_int(payload: dict, key: str, *, default: int) -> int:
    value = payload.get(key, default)
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{key} must be a positive integer")
    return value


def _require_positive_int_no_default(payload: dict, key: str) -> int:
    value = payload.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ValueError(f"{key} must be a positive integer")
    return value


def _require_str_list(payload: dict, key: str) -> list[str]:
    value = payload.get(key, [])
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item for item in value
    ):
        raise ValueError(f"{key} must be a list of non-empty strings")
    return value


def _normalize_node_release_manifest(
    payload: dict,
    key: str,
) -> dict | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{key} must be an object when provided")
    if value.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"{key}.schema_version must be {SCHEMA_VERSION}")

    components_raw = value.get("components")
    if not isinstance(components_raw, dict) or not components_raw:
        raise ValueError(f"{key}.components must be a non-empty object")
    components: dict[str, dict[str, str]] = {}
    for component_name, component in components_raw.items():
        if not isinstance(component_name, str) or not component_name:
            raise ValueError(f"{key}.components keys must be non-empty strings")
        if not isinstance(component, dict):
            raise ValueError(
                f"{key}.components.{component_name} must be an object"
            )
        components[component_name] = {
            "repository": _require_str(component, "repository"),
            "ref": _require_str(component, "ref"),
        }

    build_raw = value.get("build")
    if not isinstance(build_raw, dict):
        raise ValueError(f"{key}.build must be an object")
    build = {
        "python_image": _require_str(build_raw, "python_image"),
        "go_image": _require_str(build_raw, "go_image"),
        "cometbft_version": _require_str(build_raw, "cometbft_version"),
        "cometbft_source_url": _require_str(build_raw, "cometbft_source_url"),
        "cometbft_source_sha256": _require_sha256(
            build_raw, "cometbft_source_sha256"
        ),
        "s6_overlay_version": _require_str(build_raw, "s6_overlay_version"),
        "s6_overlay_noarch_sha256": _require_sha256(
            build_raw, "s6_overlay_noarch_sha256"
        ),
        "s6_overlay_x86_64_sha256": _require_sha256(
            build_raw, "s6_overlay_x86_64_sha256"
        ),
        "s6_overlay_aarch64_sha256": _require_sha256(
            build_raw, "s6_overlay_aarch64_sha256"
        ),
    }

    images_raw = value.get("images")
    if not isinstance(images_raw, dict):
        raise ValueError(f"{key}.images must be an object")
    images = {
        "integrated": _require_str(images_raw, "integrated"),
        "split": _require_str(images_raw, "split"),
    }

    return {
        "schema_version": SCHEMA_VERSION,
        "components": components,
        "build": build,
        "images": images,
    }


def _normalize_shielded_relayer_entry(
    payload: dict,
    key: str,
    *,
    default_id: str,
) -> dict:
    if not isinstance(payload, dict):
        raise ValueError(f"{key} must be an object")
    submission_kinds = _require_str_list(payload, "submission_kinds")
    if submission_kinds:
        invalid_kinds = sorted(
            set(submission_kinds) - SUPPORTED_SHIELDED_RELAYER_SUBMISSION_KINDS
        )
        if invalid_kinds:
            raise ValueError(
                f"{key}.submission_kinds contains unsupported values: "
                f"{invalid_kinds}"
            )
    return {
        "id": _require_optional_str(payload, "id") or default_id,
        "base_url": _require_str(payload, "base_url"),
        "auth_scheme": _require_optional_choice(
            payload,
            "auth_scheme",
            supported=SUPPORTED_SHIELDED_RELAYER_AUTH_SCHEMES,
            default="none",
        )
        or "none",
        "public_info": _require_bool(payload, "public_info", default=True),
        "public_quote": _require_bool(payload, "public_quote", default=False),
        "public_job_lookup": _require_bool(
            payload, "public_job_lookup", default=False
        ),
        "priority": _require_non_negative_int(payload, "priority", default=100),
        "submission_kinds": (
            submission_kinds
            if submission_kinds
            else sorted(SUPPORTED_SHIELDED_RELAYER_SUBMISSION_KINDS)
        ),
    }


def _normalize_shielded_relayers_manifest(
    payload: dict,
) -> list[dict]:
    relayers_raw = payload.get("shielded_relayers")
    if relayers_raw is None:
        return []
    if not isinstance(relayers_raw, list):
        raise ValueError("shielded_relayers must be a list when provided")
    relayers = [
        _normalize_shielded_relayer_entry(
            item,
            f"shielded_relayers[{index}]",
            default_id=f"relayer-{index + 1}",
        )
        for index, item in enumerate(relayers_raw)
    ]
    seen_ids: set[str] = set()
    for relayer in relayers:
        relayer_id = relayer["id"]
        if relayer_id in seen_ids:
            raise ValueError(
                f"shielded_relayers contains duplicate id: {relayer_id}"
            )
        seen_ids.add(relayer_id)
    sorted_relayers = sorted(
        relayers,
        key=lambda item: (
            int(item["priority"]),
            str(item["id"]),
            str(item["base_url"]),
        ),
    )
    return sorted_relayers


def _normalize_privacy_artifact_catalog(
    payload: dict,
    key: str,
) -> dict | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{key} must be an object when provided")
    return {
        "path": _require_str(value, "path"),
        "sha256": _require_sha256(value, "sha256"),
    }


def _normalize_shielded_history_policy(
    payload: dict,
    key: str,
) -> dict | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{key} must be an object when provided")
    compatibility_commitment = _require_optional_choice(
        value,
        "compatibility_commitment",
        supported=SUPPORTED_SHIELDED_HISTORY_COMPATIBILITY,
    )
    if compatibility_commitment is None:
        raise ValueError(f"{key}.compatibility_commitment is required")
    retention_class = _require_optional_choice(
        value,
        "retention_class",
        supported=SUPPORTED_SHIELDED_HISTORY_RETENTION,
    )
    if retention_class is None:
        raise ValueError(f"{key}.retention_class is required")
    return {
        "feed_version": _require_positive_int_no_default(value, "feed_version"),
        "compatibility_commitment": compatibility_commitment,
        "retention_class": retention_class,
        "bds_snapshot_support": _require_bool(
            value, "bds_snapshot_support", default=False
        ),
        "operator_notice": _require_str(value, "operator_notice"),
    }


def _normalize_privacy_submission_policy(
    payload: dict,
    key: str,
) -> dict | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{key} must be an object when provided")
    disclosure_policy = _require_optional_choice(
        value,
        "disclosure_policy",
        supported=SUPPORTED_PRIVACY_DISCLOSURE_POLICIES,
    )
    if disclosure_policy is None:
        raise ValueError(f"{key}.disclosure_policy is required")
    return {
        "disclosure_policy": disclosure_policy,
        "shared_relayer_auth_required": _require_bool(
            value, "shared_relayer_auth_required", default=False
        ),
        "hidden_sender_submission_mode": _require_str(
            value, "hidden_sender_submission_mode"
        ),
        "operator_notice": _require_str(value, "operator_notice"),
    }


def _require_schema_version(payload: dict) -> int:
    schema_version = payload.get("schema_version")
    if schema_version != SCHEMA_VERSION:
        raise ValueError(
            f"unsupported schema_version: {schema_version}; "
            f"expected {SCHEMA_VERSION}"
        )
    return schema_version


def _require_schema(payload: dict, *, expected: str) -> str:
    schema = _require_str(payload, "schema")
    if schema != expected:
        raise ValueError(f"unsupported schema: {schema}; expected {expected}")
    return schema


def _reject_removed_fields(payload: dict, *keys: str) -> None:
    for key in keys:
        if key in payload:
            raise ValueError(f"{key} has been removed")


def _require_node_image_mode(payload: dict, key: str) -> str:
    value = payload.get(key, "local_build")
    if not isinstance(value, str) or value not in SUPPORTED_NODE_IMAGE_MODES:
        raise ValueError(
            f"{key} must be one of {sorted(SUPPORTED_NODE_IMAGE_MODES)}"
        )
    return value


def _require_optional_node_image_mode(payload: dict, key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, str) or value not in SUPPORTED_NODE_IMAGE_MODES:
        raise ValueError(
            f"{key} must be one of {sorted(SUPPORTED_NODE_IMAGE_MODES)}"
        )
    return value


def _validate_node_image_config(
    *,
    mode: str | None,
    integrated_image: str | None,
    split_image: str | None,
) -> tuple[str | None, str | None, str | None]:
    if mode != "registry" and (
        integrated_image is not None or split_image is not None
    ):
        raise ValueError(
            "node_integrated_image and node_split_image require "
            "node_image_mode=registry"
        )
    if mode == "registry" and (integrated_image is None or split_image is None):
        raise ValueError(
            "registry node image mode requires both "
            "node_integrated_image and node_split_image"
        )
    return mode, integrated_image, split_image


def _require_block_policy_mode(payload: dict, key: str) -> str:
    value = payload.get(key, "on_demand")
    if not isinstance(value, str) or value not in SUPPORTED_BLOCK_POLICY_MODES:
        raise ValueError(
            f"{key} must be one of {sorted(SUPPORTED_BLOCK_POLICY_MODES)}"
        )
    return value


def _require_block_policy_interval(payload: dict, key: str) -> str:
    value = payload.get(key, "0s")
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a non-empty string")
    return value


def _require_app_log_level(payload: dict, key: str) -> str:
    value = payload.get(key, "INFO")
    if not isinstance(value, str):
        raise ValueError(f"{key} must be a string")
    normalized = value.upper()
    if normalized not in SUPPORTED_APP_LOG_LEVELS:
        raise ValueError(
            f"{key} must be one of {sorted(SUPPORTED_APP_LOG_LEVELS)}"
        )
    return normalized


def _require_mode(payload: dict) -> str:
    mode = _require_str(payload, "mode")
    if mode not in SUPPORTED_NETWORK_MODES:
        raise ValueError(
            f"mode must be one of {sorted(SUPPORTED_NETWORK_MODES)}"
        )
    return mode


def normalize_network_manifest(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("network manifest must be a JSON object")
    _reject_removed_fields(payload, "runtime_backend")
    shielded_relayers = _normalize_shielded_relayers_manifest(payload)

    node_image_mode, node_integrated_image, node_split_image = (
        _validate_node_image_config(
            mode=_require_node_image_mode(payload, "node_image_mode"),
            integrated_image=_require_optional_str(
                payload, "node_integrated_image"
            ),
            split_image=_require_optional_str(payload, "node_split_image"),
        )
    )

    genesis_preset = _require_optional_str(payload, "genesis_preset")
    genesis_time = _require_optional_str(payload, "genesis_time")
    if genesis_time is not None and genesis_preset is None:
        raise ValueError("genesis_time requires genesis_preset")

    return {
        "schema_version": _require_schema_version(payload),
        "name": _require_str(payload, "name"),
        "chain_id": _require_str(payload, "chain_id"),
        "mode": _require_mode(payload),
        "genesis_source": _require_optional_str(payload, "genesis_source"),
        "genesis_preset": genesis_preset,
        "genesis_time": genesis_time,
        "snapshot_url": _require_optional_str(payload, "snapshot_url"),
        "snapshot_signing_keys": _require_str_list(
            payload, "snapshot_signing_keys"
        ),
        "seed_nodes": _require_str_list(payload, "seed_nodes"),
        "block_policy_mode": _require_block_policy_mode(
            payload, "block_policy_mode"
        ),
        "block_policy_interval": _require_block_policy_interval(
            payload, "block_policy_interval"
        ),
        "node_image_mode": node_image_mode,
        "node_integrated_image": node_integrated_image,
        "node_split_image": node_split_image,
        "shielded_relayers": shielded_relayers,
        "privacy_artifact_catalog": _normalize_privacy_artifact_catalog(
            payload, "privacy_artifact_catalog"
        ),
        "shielded_history_policy": _normalize_shielded_history_policy(
            payload, "shielded_history_policy"
        ),
        "privacy_submission_policy": _normalize_privacy_submission_policy(
            payload, "privacy_submission_policy"
        ),
        "node_release_manifest": _normalize_node_release_manifest(
            payload,
            "node_release_manifest",
        ),
    }


def normalize_node_profile(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("node profile must be a JSON object")
    _reject_removed_fields(payload, "runtime_backend")

    node_image_mode, node_integrated_image, node_split_image = (
        _validate_node_image_config(
            mode=_require_optional_node_image_mode(payload, "node_image_mode"),
            integrated_image=_require_optional_str(
                payload, "node_integrated_image"
            ),
            split_image=_require_optional_str(payload, "node_split_image"),
        )
    )

    return {
        "schema_version": _require_schema_version(payload),
        "name": _require_str(payload, "name"),
        "network": _require_str(payload, "network"),
        "moniker": _require_str(payload, "moniker"),
        "validator_key_ref": _require_optional_str(
            payload,
            "validator_key_ref",
        ),
        "node_image_mode": node_image_mode,
        "node_integrated_image": node_integrated_image,
        "node_split_image": node_split_image,
        "node_release_manifest": _normalize_node_release_manifest(
            payload,
            "node_release_manifest",
        ),
        "stack_dir": _require_optional_str(payload, "stack_dir"),
        "seeds": _require_str_list(payload, "seeds"),
        "genesis_url": _require_optional_str(payload, "genesis_url"),
        "snapshot_url": _require_optional_str(payload, "snapshot_url"),
        "snapshot_signing_keys": _require_str_list(
            payload, "snapshot_signing_keys"
        ),
        "service_node": _require_bool(payload, "service_node", default=False),
        "home": _require_optional_str(payload, "home"),
        "pruning_enabled": _require_bool(
            payload, "pruning_enabled", default=False
        ),
        "blocks_to_keep": _require_int(
            payload, "blocks_to_keep", default=100000
        ),
        "block_policy_mode": _require_block_policy_mode(
            payload, "block_policy_mode"
        ),
        "block_policy_interval": _require_block_policy_interval(
            payload, "block_policy_interval"
        ),
        "transaction_trace_logging": _require_bool(
            payload, "transaction_trace_logging", default=False
        ),
        "app_log_level": _require_app_log_level(payload, "app_log_level"),
        "app_log_json": _require_bool(payload, "app_log_json", default=False),
        "app_log_rotation_hours": _require_positive_int(
            payload, "app_log_rotation_hours", default=1
        ),
        "app_log_retention_days": _require_positive_int(
            payload, "app_log_retention_days", default=7
        ),
        "simulation_enabled": _require_bool(
            payload, "simulation_enabled", default=True
        ),
        "simulation_max_concurrency": _require_positive_int(
            payload, "simulation_max_concurrency", default=2
        ),
        "simulation_timeout_ms": _require_positive_int(
            payload, "simulation_timeout_ms", default=3000
        ),
        "simulation_max_chi": _require_positive_int(
            payload, "simulation_max_chi", default=1_000_000
        ),
        "parallel_execution_enabled": _require_bool(
            payload, "parallel_execution_enabled", default=False
        ),
        "parallel_execution_workers": _require_non_negative_int(
            payload, "parallel_execution_workers", default=0
        ),
        "parallel_execution_min_transactions": _require_non_negative_int(
            payload, "parallel_execution_min_transactions", default=8
        ),
        "operator_profile": _require_optional_choice(
            payload,
            "operator_profile",
            supported=SUPPORTED_OPERATOR_PROFILES,
            default=None,
        ),
        "monitoring_profile": _require_optional_choice(
            payload,
            "monitoring_profile",
            supported=SUPPORTED_MONITORING_PROFILES,
            default=None,
        ),
        "dashboard_enabled": _require_bool(
            payload, "dashboard_enabled", default=False
        ),
        "monitoring_enabled": _require_bool(
            payload, "monitoring_enabled", default=False
        ),
        "dashboard_host": _require_str(payload, "dashboard_host")
        if "dashboard_host" in payload
        else "127.0.0.1",
        "dashboard_port": _require_int(payload, "dashboard_port", default=8080),
        "intentkit_enabled": _require_bool(
            payload, "intentkit_enabled", default=False
        ),
        "intentkit_network_id": _require_optional_choice(
            payload,
            "intentkit_network_id",
            supported=SUPPORTED_INTENTKIT_NETWORK_IDS,
            default=None,
        ),
        "intentkit_host": _require_str(payload, "intentkit_host")
        if "intentkit_host" in payload
        else "127.0.0.1",
        "intentkit_port": _require_int(
            payload,
            "intentkit_port",
            default=38000,
        ),
        "intentkit_api_port": _require_int(
            payload, "intentkit_api_port", default=38080
        ),
        "dex_automation_enabled": _require_bool(
            payload, "dex_automation_enabled", default=False
        ),
        "dex_automation_host": _require_str(payload, "dex_automation_host")
        if "dex_automation_host" in payload
        else "127.0.0.1",
        "dex_automation_port": _require_int(
            payload,
            "dex_automation_port",
            default=38280,
        ),
        "dex_automation_config": _require_optional_str(
            payload,
            "dex_automation_config",
        ),
        "shielded_relayer_enabled": _require_bool(
            payload, "shielded_relayer_enabled", default=False
        ),
        "shielded_relayer_host": _require_str(payload, "shielded_relayer_host")
        if "shielded_relayer_host" in payload
        else "127.0.0.1",
        "shielded_relayer_port": _require_int(
            payload,
            "shielded_relayer_port",
            default=38180,
        ),
    }


def normalize_network_template(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("network template must be a JSON object")
    _reject_removed_fields(payload, "runtime_backend")

    return {
        "schema_version": _require_schema_version(payload),
        "name": _require_str(payload, "name"),
        "display_name": _require_str(payload, "display_name"),
        "description": _require_str(payload, "description"),
        "block_policy_mode": _require_block_policy_mode(
            payload, "block_policy_mode"
        ),
        "block_policy_interval": _require_block_policy_interval(
            payload, "block_policy_interval"
        ),
        "transaction_trace_logging": _require_bool(
            payload, "transaction_trace_logging", default=False
        ),
        "app_log_level": _require_app_log_level(payload, "app_log_level"),
        "app_log_json": _require_bool(payload, "app_log_json", default=False),
        "app_log_rotation_hours": _require_positive_int(
            payload, "app_log_rotation_hours", default=1
        ),
        "app_log_retention_days": _require_positive_int(
            payload, "app_log_retention_days", default=7
        ),
        "simulation_enabled": _require_bool(
            payload, "simulation_enabled", default=True
        ),
        "simulation_max_concurrency": _require_positive_int(
            payload, "simulation_max_concurrency", default=2
        ),
        "simulation_timeout_ms": _require_positive_int(
            payload, "simulation_timeout_ms", default=3000
        ),
        "simulation_max_chi": _require_positive_int(
            payload, "simulation_max_chi", default=1_000_000
        ),
        "parallel_execution_enabled": _require_bool(
            payload, "parallel_execution_enabled", default=False
        ),
        "parallel_execution_workers": _require_non_negative_int(
            payload, "parallel_execution_workers", default=0
        ),
        "parallel_execution_min_transactions": _require_non_negative_int(
            payload, "parallel_execution_min_transactions", default=8
        ),
        "operator_profile": _require_optional_choice(
            payload,
            "operator_profile",
            supported=SUPPORTED_OPERATOR_PROFILES,
        ),
        "monitoring_profile": _require_optional_choice(
            payload,
            "monitoring_profile",
            supported=SUPPORTED_MONITORING_PROFILES,
        ),
        "bootstrap_node_name": _require_optional_str(
            payload, "bootstrap_node_name"
        ),
        "additional_validator_names": _require_str_list(
            payload, "additional_validator_names"
        ),
        "service_node": _require_bool(payload, "service_node", default=False),
        "dashboard_enabled": _require_bool(
            payload, "dashboard_enabled", default=False
        ),
        "monitoring_enabled": _require_bool(
            payload, "monitoring_enabled", default=False
        ),
        "dashboard_host": _require_str(payload, "dashboard_host")
        if "dashboard_host" in payload
        else "127.0.0.1",
        "dashboard_port": _require_int(payload, "dashboard_port", default=8080),
        "intentkit_enabled": _require_bool(
            payload, "intentkit_enabled", default=False
        ),
        "intentkit_network_id": _require_optional_choice(
            payload,
            "intentkit_network_id",
            supported=SUPPORTED_INTENTKIT_NETWORK_IDS,
            default=None,
        ),
        "intentkit_host": _require_str(payload, "intentkit_host")
        if "intentkit_host" in payload
        else "127.0.0.1",
        "intentkit_port": _require_int(
            payload,
            "intentkit_port",
            default=38000,
        ),
        "intentkit_api_port": _require_int(
            payload, "intentkit_api_port", default=38080
        ),
        "dex_automation_enabled": _require_bool(
            payload, "dex_automation_enabled", default=False
        ),
        "dex_automation_host": _require_str(payload, "dex_automation_host")
        if "dex_automation_host" in payload
        else "127.0.0.1",
        "dex_automation_port": _require_int(
            payload,
            "dex_automation_port",
            default=38280,
        ),
        "dex_automation_config": _require_optional_str(
            payload,
            "dex_automation_config",
        ),
        "shielded_relayer_enabled": _require_bool(
            payload, "shielded_relayer_enabled", default=False
        ),
        "shielded_relayer_host": _require_str(payload, "shielded_relayer_host")
        if "shielded_relayer_host" in payload
        else "127.0.0.1",
        "shielded_relayer_port": _require_int(
            payload,
            "shielded_relayer_port",
            default=38180,
        ),
        "pruning_enabled": _require_bool(
            payload, "pruning_enabled", default=False
        ),
        "blocks_to_keep": _require_int(
            payload, "blocks_to_keep", default=100000
        ),
    }


def _normalize_starter_step(payload: dict, *, label: str) -> dict:
    if not isinstance(payload, dict):
        raise ValueError(f"{label} step must be a JSON object")

    commands = _require_str_list(payload, "commands")
    if not commands:
        raise ValueError(f"{label} step commands must not be empty")

    return {
        "title": _require_str(payload, "title"),
        "commands": commands,
        "notes": _require_str_list(payload, "notes"),
    }


def _normalize_starter_flow(payload: dict, *, label: str) -> dict:
    if not isinstance(payload, dict):
        raise ValueError(f"{label} starter flow must be a JSON object")

    steps = payload.get("steps")
    if (
        not isinstance(steps, list)
        or not steps
        or any(not isinstance(item, dict) for item in steps)
    ):
        raise ValueError(
            f"{label} starter flow steps must be a non-empty list of objects"
        )

    return {
        "name": _require_str(payload, "name"),
        "display_name": _require_str(payload, "display_name"),
        "template": _require_str(payload, "template"),
        "summary": _require_str(payload, "summary"),
        "network_name": _require_optional_str(payload, "network_name"),
        "node_name": _require_optional_str(payload, "node_name"),
        "steps": [_normalize_starter_step(item, label=label) for item in steps],
    }


def _normalize_module_recipe(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("module recipe must be a JSON object")

    install = payload.get("install")
    if not isinstance(install, dict):
        raise ValueError("module recipe install must be a JSON object")
    install_kind = _require_str(install, "kind")
    if install_kind not in SUPPORTED_MODULE_INSTALL_KINDS:
        raise ValueError(
            "module recipe install.kind must be one of "
            f"{sorted(SUPPORTED_MODULE_INSTALL_KINDS)}"
        )

    return {
        "name": _require_str(payload, "name"),
        "display_name": _require_str(payload, "display_name"),
        "summary": _require_str(payload, "summary"),
        "install": dict(install),
    }


def normalize_module(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("module must be a JSON object")

    recipes = payload.get("recipes")
    if (
        not isinstance(recipes, list)
        or not recipes
        or any(not isinstance(item, dict) for item in recipes)
    ):
        raise ValueError("module recipes must be a non-empty list of objects")

    normalized_recipes = [_normalize_module_recipe(item) for item in recipes]
    recipe_names = {item["name"] for item in normalized_recipes}
    default_recipe = _require_str(payload, "default_recipe")
    if default_recipe not in recipe_names:
        raise ValueError("module default_recipe must name an existing recipe")

    return {
        "schema": _require_schema(payload, expected=MODULE_SCHEMA),
        "schema_version": _require_schema_version(payload),
        "name": _require_str(payload, "name"),
        "display_name": _require_str(payload, "display_name"),
        "category": _require_str(payload, "category"),
        "maturity": _require_str(payload, "maturity"),
        "description": _require_str(payload, "description"),
        "source_owner_repo": _require_str(payload, "source_owner_repo"),
        "docs_path": _require_str(payload, "docs_path"),
        "default_recipe": default_recipe,
        "contract_paths": _require_str_list(payload, "contract_paths"),
        "contract_bundle_paths": _require_str_list(
            payload, "contract_bundle_paths"
        ),
        "recipes": normalized_recipes,
    }


def _normalize_solution_module_ref(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("solution module reference must be a JSON object")
    return {
        "name": _require_str(payload, "name"),
        "recipe": _require_optional_str(payload, "recipe"),
    }


def normalize_solution(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("solution must be a JSON object")

    starter_flows = payload.get("starter_flows")
    if (
        not isinstance(starter_flows, list)
        or not starter_flows
        or any(not isinstance(item, dict) for item in starter_flows)
    ):
        raise ValueError(
            "solution starter_flows must be a non-empty list of flow objects"
        )

    modules = payload.get("modules", [])
    if not isinstance(modules, list) or any(
        not isinstance(item, dict) for item in modules
    ):
        raise ValueError("solution modules must be a list of objects")

    return {
        "schema": _require_schema(payload, expected=SOLUTION_SCHEMA),
        "schema_version": _require_schema_version(payload),
        "name": _require_str(payload, "name"),
        "display_name": _require_str(payload, "display_name"),
        "description": _require_str(payload, "description"),
        "use_case": _require_str(payload, "use_case"),
        "recommended_local_template": _require_str(
            payload, "recommended_local_template"
        ),
        "recommended_remote_template": _require_str(
            payload, "recommended_remote_template"
        ),
        "docs_path": _require_str(payload, "docs_path"),
        "example_dir": _require_str(payload, "example_dir"),
        "modules": [_normalize_solution_module_ref(item) for item in modules],
        "services": _require_str_list(payload, "services"),
        "contract_paths": _require_str_list(payload, "contract_paths"),
        "contract_bundle_paths": _require_str_list(
            payload, "contract_bundle_paths"
        ),
        "starter_flows": [
            _normalize_starter_flow(item, label="solution")
            for item in starter_flows
        ],
    }


def normalize_recovery_plan(payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ValueError("recovery plan must be a JSON object")

    artifact = payload.get("artifact")
    if not isinstance(artifact, dict):
        raise ValueError("artifact must be a JSON object")
    artifact_kind = _require_str(artifact, "kind")
    if artifact_kind not in SUPPORTED_RECOVERY_ARTIFACT_KINDS:
        raise ValueError(
            "artifact.kind must be one of "
            f"{sorted(SUPPORTED_RECOVERY_ARTIFACT_KINDS)}"
        )

    runtime = payload.get("runtime", {})
    if not isinstance(runtime, dict):
        raise ValueError("runtime must be a JSON object when provided")

    follow_up_state_patch = payload.get("follow_up_state_patch")
    if follow_up_state_patch is not None and not isinstance(
        follow_up_state_patch, dict
    ):
        raise ValueError(
            "follow_up_state_patch must be a JSON object when provided"
        )

    normalized = {
        "schema_version": _require_schema_version(payload),
        "name": _require_str(payload, "name"),
        "chain_id": _require_str(payload, "chain_id"),
        "target_height": _require_positive_int_no_default(
            payload, "target_height"
        ),
        "trusted_block_hash": _require_str(payload, "trusted_block_hash"),
        "trusted_app_hash": _require_str(payload, "trusted_app_hash"),
        "reason": _require_str(payload, "reason"),
        "artifact": {
            "kind": artifact_kind,
            "uri": _require_str(artifact, "uri"),
            "sha256": _require_optional_str(artifact, "sha256"),
        },
        "runtime": {
            "xian_abci_version": _require_optional_str(
                runtime, "xian_abci_version"
            ),
            "cometbft_version": _require_optional_str(
                runtime, "cometbft_version"
            ),
        },
        "follow_up_state_patch": None,
    }
    if follow_up_state_patch is not None:
        activation_height = _require_positive_int_no_default(
            follow_up_state_patch, "activation_height"
        )
        if activation_height <= normalized["target_height"]:
            raise ValueError(
                "follow_up_state_patch.activation_height must be greater than "
                "target_height"
            )
        normalized["follow_up_state_patch"] = {
            "patch_id": _require_str(follow_up_state_patch, "patch_id"),
            "bundle_hash": _require_str(follow_up_state_patch, "bundle_hash"),
            "activation_height": activation_height,
        }

    return normalized


@dataclass(slots=True)
class NetworkManifest:
    name: str
    chain_id: str
    mode: str = "join"
    node_image_mode: str = "local_build"
    node_integrated_image: str | None = None
    node_split_image: str | None = None
    shielded_relayers: list[dict] = field(default_factory=list)
    privacy_artifact_catalog: dict | None = None
    shielded_history_policy: dict | None = None
    privacy_submission_policy: dict | None = None
    node_release_manifest: dict | None = None
    genesis_source: str | None = None
    genesis_preset: str | None = None
    genesis_time: str | None = None
    snapshot_url: str | None = None
    snapshot_signing_keys: list[str] = field(default_factory=list)
    seed_nodes: list[str] = field(default_factory=list)
    block_policy_mode: str = "on_demand"
    block_policy_interval: str = "0s"
    schema_version: int = SCHEMA_VERSION

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class NodeProfile:
    name: str
    network: str
    moniker: str
    validator_key_ref: str | None = None
    node_image_mode: str | None = None
    node_integrated_image: str | None = None
    node_split_image: str | None = None
    node_release_manifest: dict | None = None
    stack_dir: str | None = None
    seeds: list[str] = field(default_factory=list)
    genesis_url: str | None = None
    snapshot_url: str | None = None
    snapshot_signing_keys: list[str] = field(default_factory=list)
    service_node: bool = False
    home: str | None = None
    pruning_enabled: bool = False
    blocks_to_keep: int = 100000
    block_policy_mode: str = "on_demand"
    block_policy_interval: str = "0s"
    transaction_trace_logging: bool = False
    app_log_level: str = "INFO"
    app_log_json: bool = False
    app_log_rotation_hours: int = 1
    app_log_retention_days: int = 7
    simulation_enabled: bool = True
    simulation_max_concurrency: int = 2
    simulation_timeout_ms: int = 3000
    simulation_max_chi: int = 1_000_000
    parallel_execution_enabled: bool = False
    parallel_execution_workers: int = 0
    parallel_execution_min_transactions: int = 8
    operator_profile: str | None = None
    monitoring_profile: str | None = None
    dashboard_enabled: bool = False
    monitoring_enabled: bool = False
    dashboard_host: str = "127.0.0.1"
    dashboard_port: int = 8080
    intentkit_enabled: bool = False
    intentkit_network_id: str | None = None
    intentkit_host: str = "127.0.0.1"
    intentkit_port: int = 38000
    intentkit_api_port: int = 38080
    dex_automation_enabled: bool = False
    dex_automation_host: str = "127.0.0.1"
    dex_automation_port: int = 38280
    dex_automation_config: str | None = None
    shielded_relayer_enabled: bool = False
    shielded_relayer_host: str = "127.0.0.1"
    shielded_relayer_port: int = 38180
    schema_version: int = SCHEMA_VERSION

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class NetworkTemplate:
    name: str
    display_name: str
    description: str
    block_policy_mode: str = "on_demand"
    block_policy_interval: str = "0s"
    transaction_trace_logging: bool = False
    app_log_level: str = "INFO"
    app_log_json: bool = False
    app_log_rotation_hours: int = 1
    app_log_retention_days: int = 7
    simulation_enabled: bool = True
    simulation_max_concurrency: int = 2
    simulation_timeout_ms: int = 3000
    simulation_max_chi: int = 1_000_000
    parallel_execution_enabled: bool = False
    parallel_execution_workers: int = 0
    parallel_execution_min_transactions: int = 8
    operator_profile: str | None = None
    monitoring_profile: str | None = None
    bootstrap_node_name: str | None = None
    additional_validator_names: list[str] = field(default_factory=list)
    service_node: bool = False
    dashboard_enabled: bool = False
    monitoring_enabled: bool = False
    dashboard_host: str = "127.0.0.1"
    dashboard_port: int = 8080
    intentkit_enabled: bool = False
    intentkit_network_id: str | None = None
    intentkit_host: str = "127.0.0.1"
    intentkit_port: int = 38000
    intentkit_api_port: int = 38080
    dex_automation_enabled: bool = False
    dex_automation_host: str = "127.0.0.1"
    dex_automation_port: int = 38280
    dex_automation_config: str | None = None
    shielded_relayer_enabled: bool = False
    shielded_relayer_host: str = "127.0.0.1"
    shielded_relayer_port: int = 38180
    pruning_enabled: bool = False
    blocks_to_keep: int = 100000
    schema_version: int = SCHEMA_VERSION

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class SolutionPackStarterStep:
    title: str
    commands: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class SolutionPackStarterFlow:
    name: str
    display_name: str
    template: str
    summary: str
    network_name: str | None = None
    node_name: str | None = None
    steps: list[SolutionPackStarterStep] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(slots=True)
class SolutionPack:
    name: str
    display_name: str
    description: str
    use_case: str
    recommended_local_template: str
    recommended_remote_template: str
    docs_path: str
    example_dir: str
    contract_paths: list[str] = field(default_factory=list)
    contract_bundle_paths: list[str] = field(default_factory=list)
    starter_flows: list[SolutionPackStarterFlow] = field(default_factory=list)
    schema_version: int = SCHEMA_VERSION

    def to_dict(self) -> dict:
        return asdict(self)


def _normalize_json_value(value, *, preserve_runtime_types: bool = False):
    if isinstance(value, dict):
        return {
            str(key): _normalize_json_value(
                nested, preserve_runtime_types=preserve_runtime_types
            )
            for key, nested in value.items()
        }
    if isinstance(value, list):
        return [
            _normalize_json_value(
                item, preserve_runtime_types=preserve_runtime_types
            )
            for item in value
        ]
    if isinstance(value, tuple):
        return [
            _normalize_json_value(
                item, preserve_runtime_types=preserve_runtime_types
            )
            for item in value
        ]
    if isinstance(value, (ContractingDecimal, decimal.Decimal, Datetime)):
        if preserve_runtime_types:
            return json.loads(encode(value))
        return str(value)
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.hex()
    return value


def write_json(
    path: Path,
    payload: dict,
    *,
    force: bool = False,
    preserve_runtime_types: bool = False,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not force:
        raise FileExistsError(
            f"{path} already exists; pass --force to overwrite"
        )
    normalized = _normalize_json_value(
        payload, preserve_runtime_types=preserve_runtime_types
    )
    path.write_text(json.dumps(normalized, indent=2) + "\n", encoding="utf-8")


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def read_network_manifest(path: Path) -> dict:
    return normalize_network_manifest(read_json(path))


def read_node_profile(path: Path) -> dict:
    return normalize_node_profile(read_json(path))


def read_network_template(path: Path) -> dict:
    return normalize_network_template(read_json(path))


def read_module(path: Path) -> dict:
    return normalize_module(read_json(path))


def read_solution(path: Path) -> dict:
    return normalize_solution(read_json(path))


def read_recovery_plan(path: Path) -> dict:
    return normalize_recovery_plan(read_json(path))
