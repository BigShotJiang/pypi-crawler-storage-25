from __future__ import annotations

import argparse
import base64
import json
import os
import shlex
import shutil
import subprocess
import sys
import tomllib
from datetime import UTC, datetime
from pathlib import Path
from urllib.parse import urlparse

from xian_cli.abci_bridge import (
    get_genesis_builder_module,
    get_node_admin_module,
    get_node_setup_module,
)
from xian_cli.config_repo import (
    list_module_paths,
    list_network_template_paths,
    list_solution_paths,
    resolve_configs_dir,
    resolve_module_path,
    resolve_network_manifest_path,
    resolve_network_template_path,
    resolve_solution_path,
)
from xian_cli.contract_bundles import validate_contract_bundle
from xian_cli.models import (
    SUPPORTED_NODE_IMAGE_MODES,
    NetworkManifest,
    NodeProfile,
    read_json,
    read_module,
    read_network_manifest,
    read_network_template,
    read_node_profile,
    read_recovery_plan,
    read_solution,
    write_json,
)
from xian_cli.network_plans import build_profile_runtime_fields
from xian_cli.parser import build_parser as _build_parser
from xian_cli.runtime import (
    default_home_for_backend,
    fetch_json,
    get_xian_stack_node_endpoints,
    get_xian_stack_node_health,
    get_xian_stack_node_status,
    resolve_stack_dir,
    start_xian_stack_node,
    stop_xian_stack_node,
)


def _block_age_seconds(block_time: object) -> float | None:
    """
    Seconds elapsed since ``block_time``.

    Surfaces sync lag in ``node status`` — fresh blocks return a small value,
    a stalled chain returns a large one. Returns None if the input is missing
    or unparseable so the caller can omit the field instead of showing 0.
    """
    if not isinstance(block_time, str) or not block_time:
        return None
    try:
        # CometBFT emits e.g. "2024-01-01T12:00:00.123456789Z" — Python's
        # datetime can't parse sub-microsecond precision or the trailing Z,
        # so normalize before handing to fromisoformat.
        normalized = block_time.rstrip("Z")
        if "." in normalized:
            head, frac = normalized.split(".", 1)
            frac = frac[:6]
            normalized = f"{head}.{frac}"
        parsed = datetime.fromisoformat(normalized).replace(tzinfo=UTC)
    except ValueError:
        return None
    delta = datetime.now(UTC) - parsed
    return max(delta.total_seconds(), 0.0)


def _write_validator_material_files(
    *,
    out_dir: Path,
    private_key: str | None = None,
    force: bool = False,
) -> Path:
    node_setup = get_node_setup_module()
    payload = node_setup.generate_validator_material(private_key)
    write_json(
        out_dir / "priv_validator_key.json",
        payload["priv_validator_key"],
        force=force,
    )
    metadata_path = out_dir / "validator_key_info.json"
    write_json(metadata_path, payload, force=force)
    return metadata_path


def _stringify_path_for_profile(path: Path, *, base_dir: Path) -> str:
    resolved_path = path
    if not resolved_path.is_absolute():
        resolved_path = (base_dir / resolved_path).resolve()
    else:
        resolved_path = resolved_path.resolve()
    try:
        return str(resolved_path.relative_to(base_dir.resolve()))
    except ValueError:
        return str(resolved_path)


def _default_network_manifest_path(base_dir: Path, network_name: str) -> Path:
    return base_dir / "networks" / network_name / "manifest.json"


def _resolve_output_path(
    *,
    base_dir: Path,
    explicit_output: Path | None,
    default_path: Path,
) -> Path:
    target = explicit_output or default_path
    if not target.is_absolute():
        target = (base_dir / target).resolve()
    return target


def _pick_template_value(
    explicit,
    template_value,
    default,
):
    if explicit is not None:
        return explicit
    if template_value is not None:
        return template_value
    return default


def _default_intentkit_network_id(network_name: str | None) -> str:
    normalized = (network_name or "").strip().lower()
    if normalized in {"mainnet", "xian-mainnet"}:
        return "xian-mainnet"
    if normalized in {"testnet", "xian-testnet"}:
        return "xian-testnet"
    if normalized in {"devnet", "xian-devnet"}:
        return "xian-devnet"
    return "xian-localnet"


def _effective_node_image_config(
    profile: dict[str, object],
    network: dict[str, object] | None = None,
) -> tuple[str, str | None, str | None]:
    network_mode = (
        None
        if network is None
        else network.get("node_image_mode") or "local_build"
    )
    return _resolve_node_image_settings(
        node_image_mode=str(
            profile.get("node_image_mode") or network_mode or "local_build"
        ),
        node_integrated_image=(
            profile.get("node_integrated_image")
            or (
                None
                if network is None
                else network.get("node_integrated_image")
            )
        ),
        node_split_image=(
            profile.get("node_split_image")
            or (None if network is None else network.get("node_split_image"))
        ),
    )


def _effective_node_release_manifest(
    profile: dict[str, object],
    network: dict[str, object] | None = None,
) -> dict[str, object] | None:
    node_image_mode, _, _ = _effective_node_image_config(profile, network)
    if node_image_mode != "registry":
        return None
    profile_manifest = profile.get("node_release_manifest")
    if isinstance(profile_manifest, dict):
        return profile_manifest
    network_manifest = (
        None if network is None else network.get("node_release_manifest")
    )
    return network_manifest if isinstance(network_manifest, dict) else None


def _stack_runtime_profile_kwargs(
    profile: dict[str, object],
    network: dict[str, object] | None = None,
) -> dict[str, object]:
    node_image_mode, node_integrated_image, node_split_image = (
        _effective_node_image_config(profile, network)
    )
    return {
        "node_image_mode": node_image_mode,
        "node_integrated_image": node_integrated_image,
        "node_split_image": node_split_image,
        "service_node": bool(profile.get("service_node")),
        "dashboard_enabled": bool(profile.get("dashboard_enabled")),
        "monitoring_enabled": bool(profile.get("monitoring_enabled")),
        "dashboard_host": str(profile.get("dashboard_host", "127.0.0.1")),
        "dashboard_port": int(profile.get("dashboard_port", 8080)),
        "intentkit_enabled": bool(profile.get("intentkit_enabled")),
        "intentkit_network_id": str(
            profile.get("intentkit_network_id")
            or _default_intentkit_network_id(profile.get("network"))
        ),
        "intentkit_host": str(profile.get("intentkit_host", "127.0.0.1")),
        "intentkit_port": int(profile.get("intentkit_port", 38000)),
        "intentkit_api_port": int(profile.get("intentkit_api_port", 38080)),
        "dex_automation_enabled": bool(profile.get("dex_automation_enabled")),
        "dex_automation_host": str(
            profile.get("dex_automation_host", "127.0.0.1")
        ),
        "dex_automation_port": int(profile.get("dex_automation_port", 38280)),
        "dex_automation_config": profile.get("dex_automation_config"),
        "shielded_relayer_enabled": bool(
            profile.get("shielded_relayer_enabled")
        ),
        "shielded_relayer_host": str(
            profile.get("shielded_relayer_host", "127.0.0.1")
        ),
        "shielded_relayer_port": int(
            profile.get("shielded_relayer_port", 38180)
        ),
    }


def _network_shielded_relayer_endpoints(
    network: dict[str, object] | None,
) -> dict[str, object]:
    relayers_raw = []
    if isinstance(network, dict):
        list_value = network.get("shielded_relayers")
        if isinstance(list_value, list):
            relayers_raw = [
                item for item in list_value if isinstance(item, dict)
            ]
    if not relayers_raw:
        return {}
    relayers = sorted(
        relayers_raw,
        key=lambda item: (
            int(item.get("priority", 100)),
            str(item.get("id", "")),
            str(item.get("base_url", "")),
        ),
    )
    catalog: list[dict[str, object]] = []
    for relayer in relayers:
        base_url = relayer.get("base_url")
        if not isinstance(base_url, str) or not base_url:
            continue
        normalized_base = base_url.rstrip("/")
        catalog.append(
            {
                "id": relayer.get("id"),
                "base_url": normalized_base,
                "auth_scheme": relayer.get("auth_scheme"),
                "public_info": relayer.get("public_info"),
                "public_quote": relayer.get("public_quote"),
                "public_job_lookup": relayer.get("public_job_lookup"),
                "priority": relayer.get("priority", 100),
                "submission_kinds": relayer.get("submission_kinds", []),
                "endpoints": {
                    "shielded_relayer": normalized_base,
                    "shielded_relayer_info": f"{normalized_base}/v1/info",
                    "shielded_relayer_metrics": f"{normalized_base}/metrics",
                    "shielded_relayer_quote": f"{normalized_base}/v1/quote",
                    "shielded_relayer_jobs": f"{normalized_base}/v1/jobs",
                },
            }
        )
    if not catalog:
        return {}
    primary = catalog[0]
    endpoints = dict(primary["endpoints"])
    endpoints["shielded_relayer_primary_id"] = str(primary.get("id") or "")
    endpoints["shielded_relayers"] = catalog
    return endpoints


def _resolve_node_image_settings(
    *,
    node_image_mode: str,
    node_integrated_image: str | None,
    node_split_image: str | None,
) -> tuple[str, str | None, str | None]:
    if node_image_mode not in SUPPORTED_NODE_IMAGE_MODES:
        raise ValueError(
            "node_image_mode must be one of "
            f"{sorted(SUPPORTED_NODE_IMAGE_MODES)}"
        )
    if node_image_mode == "registry" and (
        not node_integrated_image or not node_split_image
    ):
        raise ValueError(
            "registry node image mode requires both "
            "--node-integrated-image and --node-split-image"
        )
    return node_image_mode, node_integrated_image, node_split_image


def _load_template(
    *,
    base_dir: Path,
    template_name: str | None,
    configs_dir: Path | None,
) -> dict | None:
    if template_name is None:
        return None
    template_path = resolve_network_template_path(
        base_dir=base_dir,
        template_name=template_name,
        configs_dir=configs_dir,
    )
    return read_network_template(template_path)


def _handle_network_template_list(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    templates = [
        read_network_template(path)
        for path in list_network_template_paths(
            base_dir=base_dir,
            configs_dir=args.configs_dir,
        )
    ]
    print(json.dumps(templates, indent=2))
    return 0


def _handle_network_template_show(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    template = _load_template(
        base_dir=base_dir,
        template_name=args.name,
        configs_dir=args.configs_dir,
    )
    print(json.dumps(template, indent=2))
    return 0


def _catalog_root_for_manifest(
    manifest_path: Path,
    collection_name: str,
) -> Path:
    resolved = manifest_path.resolve()
    for parent in resolved.parents:
        if parent.name == collection_name:
            return parent.parent
    return resolved.parent


def _resolve_catalog_ref(
    manifest_path: Path,
    ref: str,
    *,
    collection_name: str,
) -> Path:
    raw_ref = Path(ref)
    if raw_ref.is_absolute():
        return raw_ref.expanduser().resolve()

    catalog_root = _catalog_root_for_manifest(manifest_path, collection_name)
    rooted = (catalog_root / raw_ref).resolve()
    if rooted.exists():
        return rooted
    return (manifest_path.parent / raw_ref).resolve()


def _validate_module_assets(module_path: Path, module: dict) -> dict:
    contract_paths: list[str] = module["contract_paths"]
    contract_bundle_paths: list[str] = module["contract_bundle_paths"]
    missing_contracts = [
        ref
        for ref in contract_paths
        if not _resolve_catalog_ref(
            module_path,
            ref,
            collection_name="modules",
        ).exists()
    ]
    if missing_contracts:
        raise FileNotFoundError(
            f"module {module['name']} references missing contracts: "
            f"{missing_contracts}"
        )

    validated_bundles = []
    for bundle_ref in contract_bundle_paths:
        bundle_path = _resolve_catalog_ref(
            module_path,
            bundle_ref,
            collection_name="modules",
        )
        if not bundle_path.exists():
            raise FileNotFoundError(f"module bundle not found: {bundle_ref}")
        validated_bundles.append(validate_contract_bundle(bundle_path))

    return {
        "ok": True,
        "path": str(module_path.resolve()),
        "name": module["name"],
        "contract_count": len(contract_paths),
        "contract_bundle_count": len(contract_bundle_paths),
        "bundles": validated_bundles,
    }


def _load_module(
    *,
    base_dir: Path,
    module_name: str,
    configs_dir: Path | None,
) -> tuple[Path, dict]:
    module_path = resolve_module_path(
        base_dir=base_dir,
        module_name=module_name,
        configs_dir=configs_dir,
    )
    return module_path, read_module(module_path)


def _module_recipe(module: dict, recipe_name: str | None) -> dict:
    selected_recipe = recipe_name or module["default_recipe"]
    for recipe in module["recipes"]:
        if recipe["name"] == selected_recipe:
            return recipe
    available = sorted(recipe["name"] for recipe in module["recipes"])
    raise ValueError(
        f"module recipe '{selected_recipe}' not found; available: {available}"
    )


def _bool_backend_arg(name: str, value: bool) -> str:
    return f"--{name}" if value else f"--no-{name}"


def _env_var_for_repo(repo_name: str) -> str:
    return repo_name.upper().replace("-", "_") + "_DIR"


def _resolve_external_repo_dir(
    *,
    base_dir: Path,
    repo_name: str,
    explicit: Path | None = None,
) -> Path:
    candidates: list[Path] = []
    if explicit is not None:
        candidates.append(explicit)

    env_value = os.environ.get(_env_var_for_repo(repo_name))
    if env_value:
        candidates.append(Path(env_value))

    candidates.extend(
        [
            base_dir / repo_name,
            base_dir.parent / repo_name,
            Path(__file__).resolve().parents[3] / repo_name,
        ]
    )
    for candidate in candidates:
        resolved = candidate.expanduser().resolve()
        if resolved.exists():
            return resolved

    raise FileNotFoundError(
        f"unable to resolve {repo_name}; pass --repo-dir or set "
        f"{_env_var_for_repo(repo_name)}"
    )


def _handle_external_module_install(
    *,
    args: argparse.Namespace,
    base_dir: Path,
    module: dict,
    recipe: dict,
    install: dict,
) -> int:
    repo_name = install.get("repo")
    command_text = install.get("command")
    if not isinstance(repo_name, str) or not repo_name:
        raise ValueError("external module installer must define repo")
    if not isinstance(command_text, str) or not command_text:
        raise ValueError("external module installer must define command")

    repo_dir = _resolve_external_repo_dir(
        base_dir=base_dir,
        repo_name=repo_name,
        explicit=args.repo_dir,
    )
    command = shlex.split(command_text)
    payload = {
        "module": module["name"],
        "recipe": recipe["name"],
        "repo": repo_name,
        "cwd": str(repo_dir),
        "command": command,
    }
    if args.dry_run:
        payload["dry_run"] = True
        print(json.dumps(payload, indent=2))
        return 0

    result = subprocess.run(
        command,
        cwd=repo_dir,
        check=True,
        capture_output=True,
        text=True,
    )
    try:
        command_payload = json.loads(result.stdout) if result.stdout else {}
    except json.JSONDecodeError:
        command_payload = {"stdout": result.stdout}
    if result.stderr:
        command_payload["stderr"] = result.stderr
    command_payload.update(payload)
    print(json.dumps(command_payload, indent=2))
    return 0


def _handle_module_list(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    modules = [
        read_module(path)
        for path in list_module_paths(
            base_dir=base_dir,
            configs_dir=args.configs_dir,
        )
    ]
    summaries = [
        {
            "name": module["name"],
            "display_name": module["display_name"],
            "category": module["category"],
            "maturity": module["maturity"],
            "description": module["description"],
            "default_recipe": module["default_recipe"],
            "docs_path": module["docs_path"],
        }
        for module in modules
    ]
    print(json.dumps(summaries, indent=2))
    return 0


def _handle_module_show(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    _, module = _load_module(
        base_dir=base_dir,
        module_name=args.name,
        configs_dir=args.configs_dir,
    )
    print(json.dumps(module, indent=2))
    return 0


def _handle_module_validate(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    module_path, module = _load_module(
        base_dir=base_dir,
        module_name=args.name,
        configs_dir=args.configs_dir,
    )
    print(json.dumps(_validate_module_assets(module_path, module), indent=2))
    return 0


def _handle_module_install(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    module_path, module = _load_module(
        base_dir=base_dir,
        module_name=args.name,
        configs_dir=args.configs_dir,
    )
    _validate_module_assets(module_path, module)
    recipe = _module_recipe(module, args.recipe)
    install = recipe["install"]
    if install["kind"] == "external":
        return _handle_external_module_install(
            args=args,
            base_dir=base_dir,
            module=module,
            recipe=recipe,
            install=install,
        )
    if install["kind"] != "xian-stack.localnet-dex-bootstrap":
        raise ValueError(
            f"module {module['name']} recipe {recipe['name']} uses install "
            f"kind {install['kind']!r}; run the owning repo bootstrap command"
        )
    if module["name"] != "dex":
        raise ValueError("only the dex module has a stack installer today")

    if not module["contract_bundle_paths"]:
        raise ValueError("dex module must define a contract bundle")
    dex_bundle = _resolve_catalog_ref(
        module_path,
        module["contract_bundle_paths"][0],
        collection_name="modules",
    )
    stack_dir = resolve_stack_dir(base_dir, explicit=args.stack_dir)
    command = [
        sys.executable,
        str(stack_dir / "scripts" / "backend.py"),
        "localnet-dex-bootstrap",
        "--dex-bundle",
        str(dex_bundle),
        _bool_backend_arg("deploy-helper", bool(install["deploy_helper"])),
        _bool_backend_arg(
            "seed-demo-pool",
            bool(install["seed_demo_pool"]),
        ),
        _bool_backend_arg(
            "top-up-liquidity",
            bool(install["top_up_liquidity"]) or args.top_up_liquidity,
        ),
        _bool_backend_arg(
            "emit-test-swap",
            bool(install["emit_test_swap"]) or args.emit_test_swap,
        ),
    ]
    if args.rpc_url is not None:
        command.extend(["--rpc-url", args.rpc_url])
    if args.chain_id is not None:
        command.extend(["--chain-id", args.chain_id])
    if args.deployer_private_key is not None:
        command.extend(["--deployer-private-key", args.deployer_private_key])

    if args.dry_run:
        print(
            json.dumps(
                {
                    "dry_run": True,
                    "module": module["name"],
                    "recipe": recipe["name"],
                    "bundle": str(dex_bundle),
                    "command": command,
                },
                indent=2,
            )
        )
        return 0

    result = subprocess.run(
        command,
        cwd=stack_dir,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(result.stdout)
    payload["module"] = module["name"]
    payload["recipe"] = recipe["name"]
    print(json.dumps(payload, indent=2))
    return 0


def _load_solution(
    *,
    base_dir: Path,
    solution_name: str,
    configs_dir: Path | None,
) -> dict:
    solution_path = resolve_solution_path(
        base_dir=base_dir,
        solution_name=solution_name,
        configs_dir=configs_dir,
    )
    return read_solution(solution_path)


def _handle_solution_list(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    solutions = [
        read_solution(path)
        for path in list_solution_paths(
            base_dir=base_dir,
            configs_dir=args.configs_dir,
        )
    ]
    summaries = [
        {
            "name": solution["name"],
            "display_name": solution["display_name"],
            "description": solution["description"],
            "recommended_local_template": solution[
                "recommended_local_template"
            ],
            "recommended_remote_template": solution[
                "recommended_remote_template"
            ],
            "docs_path": solution["docs_path"],
            "example_dir": solution["example_dir"],
            "modules": solution["modules"],
            "services": solution["services"],
        }
        for solution in solutions
    ]
    print(json.dumps(summaries, indent=2))
    return 0


def _handle_solution_show(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    solution = _load_solution(
        base_dir=base_dir,
        solution_name=args.name,
        configs_dir=args.configs_dir,
    )
    print(json.dumps(solution, indent=2))
    return 0


def _handle_solution_starter(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    solution = _load_solution(
        base_dir=base_dir,
        solution_name=args.name,
        configs_dir=args.configs_dir,
    )
    flow = next(
        (
            item
            for item in solution["starter_flows"]
            if item["name"] == args.flow
        ),
        None,
    )
    if flow is None:
        available = sorted(item["name"] for item in solution["starter_flows"])
        raise ValueError(
            f"solution flow '{args.flow}' not found; available: {available}"
        )

    starter = {
        "name": solution["name"],
        "display_name": solution["display_name"],
        "description": solution["description"],
        "use_case": solution["use_case"],
        "docs_path": solution["docs_path"],
        "example_dir": solution["example_dir"],
        "modules": solution["modules"],
        "services": solution["services"],
        "contract_bundle_paths": solution["contract_bundle_paths"],
        "contract_paths": solution["contract_paths"],
        "flow": flow,
    }
    print(json.dumps(starter, indent=2))
    return 0


def _handle_contract_bundle_validate(args: argparse.Namespace) -> int:
    result = validate_contract_bundle(args.path)
    print(json.dumps(result, indent=2))
    return 0


def _handle_contract_build_artifacts(args: argparse.Namespace) -> int:
    source_path = args.source
    if str(source_path) == "-":
        source = sys.stdin.read()
        if not args.name:
            raise ValueError(
                "--name is required when reading source from stdin"
            )
        module_name = args.name
    else:
        source_path = source_path.resolve()
        source = source_path.read_text(encoding="utf-8")
        module_name = args.name or _infer_contract_module_name(source_path)

    try:
        from contracting.artifacts import build_contract_artifacts
    except ImportError as exc:  # pragma: no cover - packaging guard
        raise RuntimeError(
            "xian contract build-artifacts requires xian-tech-contracting"
        ) from exc

    artifacts = build_contract_artifacts(
        module_name=module_name,
        source=source,
        lint=not args.no_lint,
        vm_profile="xian_vm_v1",
    )
    if args.output is None:
        print(json.dumps(artifacts, indent=2, sort_keys=True))
    else:
        write_json(args.output.resolve(), artifacts, force=args.force)
    return 0


def _infer_contract_module_name(source_path: Path) -> str:
    filename = source_path.name
    if filename.endswith(".s.py"):
        return filename[: -len(".s.py")]
    return source_path.stem


def _handle_keys_validator_generate(args: argparse.Namespace) -> int:
    if args.out_dir is not None:
        metadata_path = _write_validator_material_files(
            out_dir=args.out_dir.resolve(),
            private_key=args.private_key,
            force=args.force,
        )
        payload = read_json(metadata_path)
    else:
        payload = get_node_setup_module().generate_validator_material(
            args.private_key
        )

    json.dump(payload, sys.stdout, indent=2)
    sys.stdout.write("\n")
    return 0


def _collect_creation_validator_names(
    args: argparse.Namespace,
    *,
    template: dict | None = None,
) -> tuple[str | None, list[str]]:
    bootstrap_name = args.bootstrap_node
    if bootstrap_name is None and template is not None:
        bootstrap_name = template.get("bootstrap_node_name")
    validator_names: list[str] = []

    if bootstrap_name is not None:
        validator_names.append(bootstrap_name)

    validator_inputs = (
        args.validator
        if args.validator is not None
        else (template.get("additional_validator_names") if template else [])
    )
    for validator_name in validator_inputs or []:
        if validator_name in validator_names:
            raise ValueError(
                "duplicate validator name in network creation: "
                f"{validator_name}"
            )
        validator_names.append(validator_name)

    return bootstrap_name, validator_names


def _collect_creation_validators(
    *,
    args: argparse.Namespace,
    base_dir: Path,
    bootstrap_name: str | None,
    validator_names: list[str],
) -> list[dict[str, object]]:
    validators: list[dict[str, object]] = []
    if not validator_names:
        if args.validator_key_ref is not None:
            raise ValueError("--validator-key-ref requires --bootstrap-node")
        return validators

    if not args.generate_validator_key:
        if len(validator_names) > 1:
            raise ValueError(
                "multi-validator network creation currently requires "
                "--generate-validator-key"
            )
        if args.validator_key_ref is None:
            return validators

    for index, validator_name in enumerate(validator_names):
        validator_key_ref: str | None = None
        validator_key_payload: dict | None = None

        if args.generate_validator_key:
            key_dir = (
                args.validator_key_dir or base_dir / "keys" / validator_name
            )
            if args.validator_key_dir is not None and len(validator_names) > 1:
                key_dir = key_dir / validator_name
            if not key_dir.is_absolute():
                key_dir = (base_dir / key_dir).resolve()
            metadata_path = _write_validator_material_files(
                out_dir=key_dir,
                force=args.force,
            )
            validator_key_ref = _stringify_path_for_profile(
                metadata_path,
                base_dir=base_dir,
            )
            validator_key_payload = read_json(metadata_path)
        elif index == 0 and args.validator_key_ref is not None:
            validator_key_path = _resolve_output_path(
                base_dir=base_dir,
                explicit_output=args.validator_key_ref,
                default_path=args.validator_key_ref,
            )
            validator_key_ref = _stringify_path_for_profile(
                validator_key_path,
                base_dir=base_dir,
            )
            validator_key_payload = read_json(validator_key_path)

        validators.append(
            {
                "name": validator_name,
                "moniker": (
                    args.moniker
                    if validator_name == bootstrap_name
                    and args.moniker is not None
                    else validator_name
                ),
                "validator_key_ref": validator_key_ref,
                "validator_key_payload": validator_key_payload,
                "power": args.validator_power,
                "is_bootstrap": validator_name == bootstrap_name,
            }
        )

    return validators


def _handle_network_create(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    template = _load_template(
        base_dir=base_dir,
        template_name=args.template,
        configs_dir=args.configs_dir,
    )
    target = _resolve_output_path(
        base_dir=base_dir,
        explicit_output=args.output,
        default_path=_default_network_manifest_path(base_dir, args.name),
    )
    network_dir = target.parent

    if args.generate_validator_key and args.validator_key_ref is not None:
        raise ValueError(
            "pass either --validator-key-ref or --generate-validator-key, "
            "not both"
        )
    if args.validator_key_dir is not None and not args.generate_validator_key:
        raise ValueError(
            "--validator-key-dir requires --generate-validator-key"
        )
    if args.init_node and args.bootstrap_node is None:
        if template is None or template.get("bootstrap_node_name") is None:
            raise ValueError("--init-node requires --bootstrap-node")
    if getattr(args, "dry_run", False):
        # All argument validation has passed; summarize the planned layout
        # without writing files or generating keys. If the user then drops
        # the --dry-run flag, the same inputs will run the real flow.
        dry_plan: dict[str, object] = {
            "dry_run": True,
            "name": args.name,
            "template": template["name"] if template else None,
            "manifest_path": str(target),
            "network_dir": str(network_dir),
            "bootstrap_node": args.bootstrap_node,
            "generate_validator_key": bool(args.generate_validator_key),
            "init_node": bool(args.init_node),
            "genesis_source": args.genesis_source,
        }
        print(json.dumps(dry_plan, indent=2))
        return 0
    bootstrap_name, validator_names = _collect_creation_validator_names(
        args,
        template=template,
    )
    if args.init_node and bootstrap_name is None:
        raise ValueError("--init-node requires --bootstrap-node")
    validators = _collect_creation_validators(
        args=args,
        base_dir=base_dir,
        bootstrap_name=bootstrap_name,
        validator_names=validator_names,
    )

    genesis_source = args.genesis_source
    generated_genesis_path: Path | None = None
    if genesis_source is None:
        if not validators or any(
            validator["validator_key_payload"] is None
            for validator in validators
        ):
            if bootstrap_name is not None or validator_names:
                raise ValueError(
                    "local network creation without --genesis-source "
                    "requires validator key material; pass "
                    "--generate-validator-key or --validator-key-ref"
                )
        else:
            founder_private_key = (
                args.founder_private_key
                or _extract_validator_private_key_hex(
                    validators[0]["validator_key_payload"]
                )
            )
            generated_genesis_path = network_dir / "genesis.json"
            genesis = _build_creation_genesis(
                chain_id=args.chain_id,
                founder_private_key=founder_private_key,
                validators=validators,
                genesis_preset=args.genesis_preset,
            )
            write_json(
                generated_genesis_path,
                genesis,
                force=args.force,
                preserve_runtime_types=True,
            )
            genesis_source = "./genesis.json"
    if bootstrap_name is not None and genesis_source is None and not validators:
        raise ValueError(
            "--bootstrap-node requires either --genesis-source or local "
            "genesis generation via validator key material"
        )
    if validators and any(
        validator["validator_key_ref"] is None for validator in validators
    ):
        raise ValueError(
            "initial validator profiles require validator key material; "
            "pass --generate-validator-key"
        )

    node_image_mode, node_integrated_image, node_split_image = (
        _resolve_node_image_settings(
            node_image_mode=_pick_template_value(
                args.node_image_mode,
                None,
                "local_build",
            ),
            node_integrated_image=args.node_integrated_image,
            node_split_image=args.node_split_image,
        )
    )

    manifest = NetworkManifest(
        name=args.name,
        chain_id=args.chain_id,
        mode=args.mode,
        genesis_source=genesis_source,
        snapshot_url=args.snapshot_url,
        snapshot_signing_keys=args.snapshot_signing_key or [],
        seed_nodes=args.seed or [],
        block_policy_mode=_pick_template_value(
            args.block_policy_mode,
            None if template is None else template.get("block_policy_mode"),
            "on_demand",
        ),
        block_policy_interval=_pick_template_value(
            args.block_policy_interval,
            None if template is None else template.get("block_policy_interval"),
            "0s",
        ),
        node_image_mode=node_image_mode,
        node_integrated_image=node_integrated_image,
        node_split_image=node_split_image,
        node_release_manifest=None,
    )
    write_json(target, manifest.to_dict(), force=args.force)

    result: dict[str, object] = {
        "manifest_path": str(target),
        "mode": args.mode,
        "genesis_source": genesis_source,
        "template": None if template is None else template["name"],
    }
    if generated_genesis_path is not None:
        result["generated_genesis_path"] = str(generated_genesis_path)
    result["validators"] = []

    for validator in validators:
        validator_result: dict[str, object] = {
            "name": validator["name"],
            "moniker": validator["moniker"],
            "validator_key_ref": validator["validator_key_ref"],
        }
        profile_path = _resolve_output_path(
            base_dir=base_dir,
            explicit_output=(
                args.node_output if validator["is_bootstrap"] else None
            ),
            default_path=base_dir / "nodes" / f"{validator['name']}.json",
        )
        profile = NodeProfile(
            name=validator["name"],
            network=args.name,
            moniker=validator["moniker"],
            validator_key_ref=validator["validator_key_ref"],
            node_image_mode=manifest.node_image_mode,
            node_integrated_image=manifest.node_integrated_image,
            node_split_image=manifest.node_split_image,
            node_release_manifest=manifest.node_release_manifest,
            stack_dir=(
                str(args.stack_dir)
                if validator["is_bootstrap"] and args.stack_dir is not None
                else None
            ),
            seeds=[],
            genesis_url=None,
            snapshot_url=(
                args.snapshot_url if validator["is_bootstrap"] else None
            ),
            snapshot_signing_keys=(
                list(args.snapshot_signing_key or [])
                if validator["is_bootstrap"]
                else []
            ),
            home=(
                str(args.home)
                if validator["is_bootstrap"] and args.home is not None
                else None
            ),
            block_policy_mode=manifest.block_policy_mode,
            block_policy_interval=manifest.block_policy_interval,
            **build_profile_runtime_fields(
                args=args,
                template=template,
                runtime_services=bool(validator["is_bootstrap"]),
                intentkit_network_id_default="xian-localnet",
            ),
        )
        write_json(profile_path, profile.to_dict(), force=args.force)
        validator_result["profile_path"] = str(profile_path)
        result["validators"].append(validator_result)

        if validator["is_bootstrap"]:
            result["profile_path"] = str(profile_path)
            if validator["validator_key_ref"] is not None:
                result["validator_key_ref"] = validator["validator_key_ref"]

    if bootstrap_name is not None:
        bootstrap_validator = next(
            (
                validator
                for validator in validators
                if validator["name"] == bootstrap_name
            ),
            None,
        )
        if (
            bootstrap_validator is None
            or bootstrap_validator["validator_key_ref"] is None
        ):
            raise ValueError(
                "--bootstrap-node requires validator key material; "
                "pass --generate-validator-key or --validator-key-ref"
            )

        if args.init_node:
            bootstrap_profile_path = Path(result["profile_path"])
            init_args = argparse.Namespace(
                name=bootstrap_name,
                base_dir=base_dir,
                profile=bootstrap_profile_path,
                network=target,
                validator_key=None,
                stack_dir=args.stack_dir,
                configs_dir=args.configs_dir,
                home=args.home,
                force=args.force,
                restore_snapshot=False,
                snapshot_url=None,
            )
            result["node_initialized"] = True
            result["node_init"] = _initialize_node_from_args(init_args)

    print(json.dumps(result, indent=2))
    return 0


def _handle_network_join(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    template = _load_template(
        base_dir=base_dir,
        template_name=args.template,
        configs_dir=args.configs_dir,
    )
    network_path = resolve_network_manifest_path(
        base_dir=base_dir,
        network_name=args.network,
        explicit_manifest=args.network_manifest,
        configs_dir=args.configs_dir,
    )
    network = read_network_manifest(network_path)
    if args.generate_validator_key and args.validator_key_ref is not None:
        raise ValueError(
            "pass either --validator-key-ref or --generate-validator-key, "
            "not both"
        )
    if args.validator_key_dir is not None and not args.generate_validator_key:
        raise ValueError(
            "--validator-key-dir requires --generate-validator-key"
        )
    if args.restore_snapshot and not args.init_node:
        raise ValueError("--restore-snapshot requires --init-node")

    if getattr(args, "dry_run", False):
        target_profile = _resolve_output_path(
            base_dir=base_dir,
            explicit_output=args.output,
            default_path=base_dir / "nodes" / f"{args.name}.json",
        )
        dry_plan: dict[str, object] = {
            "dry_run": True,
            "name": args.name,
            "network": args.network,
            "network_manifest": str(network_path),
            "node_profile_path": str(target_profile),
            "generate_validator_key": bool(args.generate_validator_key),
            "init_node": bool(args.init_node),
            "restore_snapshot": bool(args.restore_snapshot),
        }
        print(json.dumps(dry_plan, indent=2))
        return 0

    requested_node_image_mode = _pick_template_value(
        args.node_image_mode,
        None,
        network.get("node_image_mode") or "local_build",
    )
    node_image_mode, node_integrated_image, node_split_image = (
        _resolve_node_image_settings(
            node_image_mode=requested_node_image_mode,
            node_integrated_image=_pick_template_value(
                args.node_integrated_image,
                None,
                network.get("node_integrated_image")
                if requested_node_image_mode == "registry"
                else None,
            ),
            node_split_image=_pick_template_value(
                args.node_split_image,
                None,
                network.get("node_split_image")
                if requested_node_image_mode == "registry"
                else None,
            ),
        )
    )

    validator_key_ref: str | None = None
    if args.validator_key_ref is not None:
        validator_key_ref = _stringify_path_for_profile(
            args.validator_key_ref,
            base_dir=base_dir,
        )
    elif args.generate_validator_key:
        key_dir = args.validator_key_dir or base_dir / "keys" / args.name
        if not key_dir.is_absolute():
            key_dir = (base_dir / key_dir).resolve()
        metadata_path = _write_validator_material_files(
            out_dir=key_dir,
            force=args.force,
        )
        validator_key_ref = _stringify_path_for_profile(
            metadata_path,
            base_dir=base_dir,
        )

    profile = NodeProfile(
        name=args.name,
        network=args.network,
        moniker=args.moniker or args.name,
        validator_key_ref=validator_key_ref,
        node_image_mode=node_image_mode,
        node_integrated_image=node_integrated_image,
        node_split_image=node_split_image,
        node_release_manifest=_effective_node_release_manifest(
            {
                "node_image_mode": node_image_mode,
                "node_integrated_image": node_integrated_image,
                "node_split_image": node_split_image,
            },
            network,
        ),
        stack_dir=str(args.stack_dir) if args.stack_dir is not None else None,
        seeds=args.seed or [],
        genesis_url=args.genesis_url,
        snapshot_url=args.snapshot_url,
        snapshot_signing_keys=args.snapshot_signing_key or [],
        home=str(args.home) if args.home is not None else None,
        block_policy_mode=_pick_template_value(
            args.block_policy_mode,
            None if template is None else template.get("block_policy_mode"),
            network.get("block_policy_mode", "on_demand"),
        ),
        block_policy_interval=_pick_template_value(
            args.block_policy_interval,
            None if template is None else template.get("block_policy_interval"),
            network.get("block_policy_interval", "0s"),
        ),
        **build_profile_runtime_fields(
            args=args,
            template=template,
            runtime_services=True,
            intentkit_network_id_default=_default_intentkit_network_id(
                network.get("name")
            ),
        ),
    )
    target = args.output or base_dir / "nodes" / f"{args.name}.json"
    if not target.is_absolute():
        target = (base_dir / target).resolve()
    write_json(target, profile.to_dict(), force=args.force)
    if not args.init_node:
        print(f"wrote node profile to {target} using {network_path}")
        return 0

    init_args = argparse.Namespace(
        name=args.name,
        base_dir=base_dir,
        profile=target,
        network=network_path,
        validator_key=None,
        stack_dir=args.stack_dir,
        configs_dir=args.configs_dir,
        home=args.home,
        force=args.force,
        restore_snapshot=args.restore_snapshot,
        snapshot_url=args.snapshot_url,
    )
    init_result = _initialize_node_from_args(init_args)
    print(
        json.dumps(
            {
                "profile_path": str(target),
                "network_path": str(network_path),
                "template": None if template is None else template["name"],
                "validator_key_ref": validator_key_ref,
                "node_initialized": True,
                "node_init": init_result,
            },
            indent=2,
        )
    )
    return 0


def _write_text_file(
    path: Path,
    content: str,
    *,
    force: bool = False,
    executable: bool = False,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not force:
        raise FileExistsError(
            f"{path} already exists; pass --force to overwrite"
        )
    path.write_text(content, encoding="utf-8")
    if executable:
        path.chmod(path.stat().st_mode | 0o755)


def _safe_bundle_relative_path(ref: str) -> Path:
    path = Path(ref)
    if path.is_absolute() or ".." in path.parts:
        raise ValueError(f"bundle reference must stay relative: {ref}")
    return path


def _copy_optional_network_asset(
    *,
    manifest_path: Path,
    bundle_dir: Path,
    ref: str,
    force: bool,
) -> None:
    source_path = _resolve_path(
        ref,
        base_dir=manifest_path.parent,
        fallback_dir=manifest_path.parent,
    )
    if source_path is None or not source_path.exists():
        raise FileNotFoundError(f"network asset not found: {ref}")
    target_path = bundle_dir / _safe_bundle_relative_path(ref)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    if target_path.exists() and not force:
        raise FileExistsError(
            f"{target_path} already exists; pass --force to overwrite"
        )
    shutil.copyfile(source_path, target_path)


def _operator_join_script(*, network_name: str, service_node: bool) -> str:
    if service_node:
        service_args = """
  --service-node
  --enable-monitoring
  --enable-dashboard
  --dashboard-host "${DASHBOARD_HOST:-127.0.0.1}"
  --dashboard-port "${DASHBOARD_PORT:-8080}"
"""
    else:
        service_args = """
  --no-service-node
  --no-enable-monitoring
  --no-enable-dashboard
"""
    return f"""#!/usr/bin/env bash
set -euo pipefail

BUNDLE_DIR="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"
XIAN_CMD="${{XIAN_CMD:-xian}}"
NODE_NAME="${{NODE_NAME:?set NODE_NAME}}"
if [[ -z "${{BOOTSTRAP_SEED:-}}" ]]; then
  BOOTSTRAP_SEED="$(tr -d '\\n' < "${{BUNDLE_DIR}}/bootstrap-seed.txt")"
fi
PARALLEL_EXECUTION_WORKERS="${{PARALLEL_EXECUTION_WORKERS:-8}}"
PARALLEL_MIN_TXS="${{PARALLEL_EXECUTION_MIN_TRANSACTIONS:-8}}"

if [[ "${{BOOTSTRAP_SEED}}" == REPLACE_WITH_* ]]; then
  echo "set BOOTSTRAP_SEED or update bootstrap-seed.txt before joining" >&2
  exit 2
fi

args=(
  network join "${{NODE_NAME}}"
  --base-dir "${{BUNDLE_DIR}}"
  --network "{network_name}"
  --network-manifest "${{BUNDLE_DIR}}/manifest.json"
  --generate-validator-key
  --seed "${{BOOTSTRAP_SEED}}"
  --simulation-enabled
  --parallel-execution-enabled
  --parallel-execution-workers "${{PARALLEL_EXECUTION_WORKERS}}"
  --parallel-execution-min-transactions "${{PARALLEL_MIN_TXS}}"
{service_args}  --init-node
)

if [[ -n "${{STACK_DIR:-}}" ]]; then
  args+=(--stack-dir "${{STACK_DIR}}")
fi
if [[ -n "${{CONFIGS_DIR:-}}" ]]; then
  args+=(--configs-dir "${{CONFIGS_DIR}}")
fi
if [[ -n "${{NODE_IMAGE_MODE:-}}" ]]; then
  args+=(--node-image-mode "${{NODE_IMAGE_MODE}}")
fi

"${{XIAN_CMD}}" "${{args[@]}}"
"${{XIAN_CMD}}" node start "${{NODE_NAME}}" --base-dir "${{BUNDLE_DIR}}"
"${{XIAN_CMD}}" node health "${{NODE_NAME}}" --base-dir "${{BUNDLE_DIR}}"
"""


def _operator_bundle_readme(
    *,
    network_name: str,
    chain_id: str,
    includes_privacy_catalog: bool,
) -> str:
    privacy_note = (
        "- `privacy/` - copied privacy artifact catalog referenced by the "
        "manifest\n"
        if includes_privacy_catalog
        else ""
    )
    return f"""# {network_name} Operator Bundle

This bundle is a shareable handoff for operators joining `{chain_id}`.

## Included Files

- `manifest.json` - modern network manifest
- `genesis.json` - materialized genesis for this network
- `bootstrap-seed.txt` - bootstrap seed placeholder or live seed
- `participant-join.sh` - join as a lean validator-capable node
- `participant-service-node.sh` - join with BDS, dashboard, and monitoring
- `SMOKE-CHECKLIST.md` - quick post-start checks
{privacy_note}
No private validator keys, node homes, databases, or logs are included.

## Lean Validator

```bash
NODE_NAME=<node-name> ./participant-join.sh
```

If `bootstrap-seed.txt` still contains a placeholder:

```bash
BOOTSTRAP_SEED='<node_id>@<public-host>:26656' \\
  NODE_NAME=<node-name> \\
  ./participant-join.sh
```

## Service Node

```bash
NODE_NAME=<node-name> ./participant-service-node.sh
```

Optional environment variables:

- `XIAN_CMD` - xian CLI executable, defaults to `xian`
- `STACK_DIR` - explicit `xian-stack` checkout
- `CONFIGS_DIR` - explicit `xian-configs` checkout
- `NODE_IMAGE_MODE` - override manifest image mode, for example `local_build`
- `DASHBOARD_HOST` / `DASHBOARD_PORT` - service-node dashboard bind settings
- `PARALLEL_EXECUTION_WORKERS` - defaults to `8`
- `PARALLEL_EXECUTION_MIN_TRANSACTIONS` - defaults to `8`

Keep RPC, GraphQL, Prometheus, and Grafana private unless you intentionally
operate them as public services.
"""


def _operator_bundle_smoke_checklist(*, chain_id: str) -> str:
    return f"""# Smoke Checklist

Run after the node starts.

```bash
xian node health <node-name> --base-dir .
xian node endpoints <node-name> --base-dir .
curl -fsS http://127.0.0.1:26657/status
```

Confirm:

- the status response reports network `{chain_id}`
- `catching_up` becomes `false` after initial sync
- service nodes expose dashboard status at `http://127.0.0.1:8080/api/status`
- service nodes expose GraphQL at `http://127.0.0.1:5000/graphql`

For validator onboarding, send the generated validator public key to the
network coordinator after startup:

```bash
python3 - <<'PY'
import json
from pathlib import Path

key_path = Path("keys/<node-name>/validator_key_info.json")
payload = json.loads(key_path.read_text())
print(payload["validator_public_key_hex"])
PY
```
"""


def _handle_network_package_operator_bundle(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    manifest_path = resolve_network_manifest_path(
        base_dir=base_dir,
        network_name=args.network,
        explicit_manifest=args.network_manifest,
        configs_dir=args.configs_dir,
    )
    network = read_network_manifest(manifest_path)
    output_dir = args.output or (
        base_dir / "dist" / f"{network['name']}-operator-bundle"
    )
    if not output_dir.is_absolute():
        output_dir = (base_dir / output_dir).resolve()
    if output_dir.exists() and not output_dir.is_dir():
        raise FileExistsError(f"bundle output is not a directory: {output_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)

    genesis, genesis_ref = _resolve_effective_genesis_payload(
        profile={},
        network=network,
        base_dir=base_dir,
        manifest_path=manifest_path,
        configs_dir=args.configs_dir,
    )

    bundled_manifest = dict(network)
    bundled_manifest["genesis_source"] = "./genesis.json"
    bundled_manifest["genesis_preset"] = None
    bundled_manifest["genesis_time"] = None
    if args.bootstrap_seed:
        seed_nodes = list(bundled_manifest.get("seed_nodes") or [])
        if args.bootstrap_seed not in seed_nodes:
            seed_nodes.append(args.bootstrap_seed)
        bundled_manifest["seed_nodes"] = seed_nodes

    write_json(output_dir / "manifest.json", bundled_manifest, force=args.force)
    write_json(
        output_dir / "genesis.json",
        genesis,
        force=args.force,
        preserve_runtime_types=True,
    )

    privacy_catalog = bundled_manifest.get("privacy_artifact_catalog")
    includes_privacy_catalog = False
    if isinstance(privacy_catalog, dict) and privacy_catalog.get("path"):
        _copy_optional_network_asset(
            manifest_path=manifest_path,
            bundle_dir=output_dir,
            ref=str(privacy_catalog["path"]),
            force=args.force,
        )
        includes_privacy_catalog = True

    bootstrap_seed = args.bootstrap_seed
    if bootstrap_seed is None:
        seed_nodes = bundled_manifest.get("seed_nodes") or []
        bootstrap_seed = (
            seed_nodes[0]
            if seed_nodes
            else "REPLACE_WITH_<node_id>@<public-host>:26656"
        )
    _write_text_file(
        output_dir / "bootstrap-seed.txt",
        f"{bootstrap_seed}\n",
        force=args.force,
    )
    _write_text_file(
        output_dir / "README.md",
        _operator_bundle_readme(
            network_name=network["name"],
            chain_id=network["chain_id"],
            includes_privacy_catalog=includes_privacy_catalog,
        ),
        force=args.force,
    )
    _write_text_file(
        output_dir / "SMOKE-CHECKLIST.md",
        _operator_bundle_smoke_checklist(chain_id=network["chain_id"]),
        force=args.force,
    )
    _write_text_file(
        output_dir / "participant-join.sh",
        _operator_join_script(network_name=network["name"], service_node=False),
        force=args.force,
        executable=True,
    )
    _write_text_file(
        output_dir / "participant-service-node.sh",
        _operator_join_script(network_name=network["name"], service_node=True),
        force=args.force,
        executable=True,
    )
    bundle_metadata = {
        "schema": "xian.operator_bundle.v1",
        "schema_version": 1,
        "network": network["name"],
        "chain_id": network["chain_id"],
        "source_manifest": str(manifest_path),
        "source_genesis": genesis_ref,
        "bootstrap_seed": bootstrap_seed,
        "files": [
            "manifest.json",
            "genesis.json",
            "bootstrap-seed.txt",
            "README.md",
            "SMOKE-CHECKLIST.md",
            "participant-join.sh",
            "participant-service-node.sh",
        ],
    }
    if includes_privacy_catalog:
        bundle_metadata["files"].append(str(privacy_catalog["path"]))
    write_json(
        output_dir / "operator-bundle.json",
        bundle_metadata,
        force=args.force,
    )

    archive_path = None
    if args.archive:
        candidate = output_dir.with_suffix(output_dir.suffix + ".tar.gz")
        if candidate.exists() and not args.force:
            raise FileExistsError(
                f"{candidate} already exists; pass --force to overwrite"
            )
        archive_path = shutil.make_archive(
            str(output_dir),
            "gztar",
            root_dir=output_dir.parent,
            base_dir=output_dir.name,
        )

    result = {
        "bundle_dir": str(output_dir),
        "manifest_path": str(output_dir / "manifest.json"),
        "genesis_path": str(output_dir / "genesis.json"),
        "network": network["name"],
        "chain_id": network["chain_id"],
        "archive_path": archive_path,
    }
    print(json.dumps(result, indent=2))
    return 0


def _resolve_path(
    value: str | None, *, base_dir: Path, fallback_dir: Path | None = None
) -> Path | None:
    if value is None:
        return None

    raw_path = Path(value).expanduser()
    if raw_path.is_absolute():
        return raw_path

    candidates = [base_dir / raw_path]
    if fallback_dir is not None:
        candidates.append(fallback_dir / raw_path)

    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()

    return candidates[0].resolve()


def _resolve_stack_dir_from_profile(
    *,
    base_dir: Path,
    profile: dict,
    explicit_stack_dir: Path | None,
) -> Path | None:
    stack_dir = explicit_stack_dir
    if stack_dir is None and profile.get("stack_dir"):
        stack_dir = _resolve_path(
            profile["stack_dir"],
            base_dir=base_dir,
        )
    if stack_dir is not None and not stack_dir.is_absolute():
        stack_dir = (base_dir / stack_dir).resolve()
    return stack_dir


def _load_genesis_payload(
    genesis_source: str, *, base_dir: Path, manifest_path: Path
) -> dict:
    parsed = urlparse(genesis_source)
    if parsed.scheme in {"http", "https"}:
        return fetch_json(genesis_source)

    genesis_path = _resolve_path(
        genesis_source,
        base_dir=base_dir,
        fallback_dir=manifest_path.parent,
    )
    if genesis_path is None or not genesis_path.exists():
        raise FileNotFoundError(f"genesis source not found: {genesis_source}")

    return read_json(genesis_path)


def _build_preset_genesis_payload(
    *,
    base_dir: Path,
    chain_id: str,
    genesis_preset: str,
    genesis_time: str | None,
    configs_dir: Path | None,
) -> dict:
    genesis_builder = get_genesis_builder_module()
    resolved_configs_dir = resolve_configs_dir(base_dir, explicit=configs_dir)
    return genesis_builder.build_bundle_network_genesis(
        chain_id=chain_id,
        network=genesis_preset,
        contracts_dir=resolved_configs_dir / "contracts",
        genesis_time=genesis_time,
    )


def _resolve_effective_genesis_payload(
    *,
    profile: dict,
    network: dict,
    base_dir: Path,
    manifest_path: Path,
    configs_dir: Path | None,
) -> tuple[dict, str]:
    genesis_source = profile.get("genesis_url") or network.get("genesis_source")
    if genesis_source:
        return (
            _load_genesis_payload(
                genesis_source,
                base_dir=base_dir,
                manifest_path=manifest_path,
            ),
            genesis_source,
        )

    genesis_preset = network.get("genesis_preset")
    if genesis_preset:
        return (
            _build_preset_genesis_payload(
                base_dir=base_dir,
                chain_id=network["chain_id"],
                genesis_preset=genesis_preset,
                genesis_time=network.get("genesis_time"),
                configs_dir=configs_dir,
            ),
            f"preset:{genesis_preset}",
        )

    raise ValueError(
        "no genesis source configured; set genesis_source or genesis_preset "
        "in the network manifest"
    )


def _extract_priv_validator_key(payload: dict) -> dict:
    if "priv_validator_key" in payload:
        return payload["priv_validator_key"]

    if {"address", "pub_key", "priv_key"}.issubset(payload.keys()):
        return payload

    raise ValueError(
        "validator key file must contain either priv_validator_key or a raw "
        "priv_validator_key.json payload"
    )


def _extract_validator_private_key_hex(payload: dict) -> str:
    private_key_hex = payload.get("validator_private_key_hex")
    if private_key_hex is not None:
        return private_key_hex

    priv_validator_key = _extract_priv_validator_key(payload)
    try:
        raw_private_key = base64.b64decode(
            priv_validator_key["priv_key"]["value"].encode("ascii")
        )
    except (KeyError, ValueError) as exc:
        raise ValueError(
            "validator key file does not contain a usable private key"
        ) from exc

    if len(raw_private_key) < 32:
        raise ValueError(
            "validator key file does not contain a usable private key"
        )
    return raw_private_key[:32].hex()


def _extract_validator_public_key_hex(payload: dict) -> str:
    public_key_hex = payload.get("validator_public_key_hex")
    if public_key_hex is not None:
        return public_key_hex

    priv_validator_key = _extract_priv_validator_key(payload)
    try:
        raw_public_key = base64.b64decode(
            priv_validator_key["pub_key"]["value"].encode("ascii")
        )
    except (KeyError, ValueError) as exc:
        raise ValueError(
            "validator key file does not contain a usable public key"
        ) from exc

    if len(raw_public_key) != 32:
        raise ValueError(
            "validator key file does not contain a usable public key"
        )
    return raw_public_key.hex()


def _build_creation_validator_entries(
    *,
    validators: list[dict[str, object]],
) -> list[dict[str, object]]:
    return [
        {
            "account_public_key": _extract_validator_public_key_hex(
                validator["validator_key_payload"]
            ),
            "name": validator["name"],
            "power": validator["power"],
            "priv_validator_key": _extract_priv_validator_key(
                validator["validator_key_payload"]
            ),
        }
        for validator in validators
    ]


def _build_creation_genesis(
    *,
    chain_id: str,
    founder_private_key: str,
    validators: list[dict[str, object]],
    genesis_preset: str,
) -> dict:
    genesis_builder = get_genesis_builder_module()
    return genesis_builder.build_local_network_genesis(
        chain_id=chain_id,
        founder_private_key=founder_private_key,
        validators=_build_creation_validator_entries(validators=validators),
        network=genesis_preset,
    )


def _resolve_home(
    *,
    base_dir: Path,
    profile: dict,
    profile_path: Path,
    stack_dir: Path | None,
    explicit_home: Path | None = None,
) -> Path:
    resolved_home = explicit_home
    if resolved_home is not None and not resolved_home.is_absolute():
        resolved_home = (base_dir / resolved_home).resolve()

    home = resolved_home or _resolve_path(
        profile.get("home"),
        base_dir=base_dir,
        fallback_dir=profile_path.parent,
    )
    if home is None:
        home = default_home_for_backend(
            base_dir=base_dir,
            stack_dir=stack_dir,
        )
    return home


def _resolve_effective_snapshot_url(
    *,
    profile: dict,
    network: dict,
    explicit_snapshot_url: str | None = None,
) -> str | None:
    return (
        explicit_snapshot_url
        or profile.get("snapshot_url")
        or network.get("snapshot_url")
    )


def _resolve_effective_snapshot_signing_keys(
    *,
    profile: dict,
    network: dict,
) -> list[str]:
    profile_keys = profile.get("snapshot_signing_keys")
    if isinstance(profile_keys, list) and profile_keys:
        return list(profile_keys)
    network_keys = network.get("snapshot_signing_keys")
    if isinstance(network_keys, list):
        return list(network_keys)
    return []


def _restore_snapshot(
    *,
    base_dir: Path,
    profile: dict,
    profile_path: Path,
    network: dict,
    stack_dir: Path | None,
    explicit_home: Path | None = None,
    explicit_snapshot_url: str | None = None,
) -> dict:
    home = _resolve_home(
        base_dir=base_dir,
        profile=profile,
        profile_path=profile_path,
        stack_dir=stack_dir,
        explicit_home=explicit_home,
    )
    config_path = home / "config" / "config.toml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"{config_path} does not exist; "
            f"run `xian node init {profile['name']}` first"
        )

    snapshot_url = _resolve_effective_snapshot_url(
        profile=profile,
        network=network,
        explicit_snapshot_url=explicit_snapshot_url,
    )
    snapshot_signing_keys = _resolve_effective_snapshot_signing_keys(
        profile=profile,
        network=network,
    )
    if not snapshot_url:
        raise ValueError(
            "no snapshot source configured; "
            "set snapshot_url in the network manifest or node profile"
        )

    node_admin = get_node_admin_module()
    snapshot_archive_name = node_admin.apply_snapshot_archive(
        snapshot_url,
        home,
        trusted_manifest_public_keys=snapshot_signing_keys,
        expected_chain_id=network.get("chain_id"),
    )
    return {
        "home": str(home),
        "snapshot_url": snapshot_url,
        "snapshot_archive_name": snapshot_archive_name,
    }


def _resolve_recovery_rpc_status(
    *,
    rpc_url: str,
) -> dict | None:
    try:
        return fetch_json(rpc_url, timeout=5.0)
    except Exception:
        return None


def _build_recovery_backup(
    *,
    home: Path,
    backup_dir: Path,
    plan_name: str,
    node_name: str,
) -> Path:
    backup_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    archive_base = backup_dir / f"{plan_name}-{node_name}-{timestamp}"
    archive_path = Path(
        shutil.make_archive(
            str(archive_base),
            "gztar",
            root_dir=home.parent,
            base_dir=home.name,
        )
    )
    return archive_path


def _validate_recovery_context(
    *,
    plan: dict,
    profile: dict,
    network: dict,
    home: Path,
    rpc_url: str | None,
) -> dict:
    config_path = home / "config" / "config.toml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"{config_path} does not exist; "
            f"run `xian node init {profile['name']}` first"
        )

    if network["chain_id"] != plan["chain_id"]:
        raise ValueError(
            "recovery plan chain_id does not match the node network manifest"
        )

    rpc_status = None
    rpc_checked = False
    if rpc_url:
        rpc_status = _resolve_recovery_rpc_status(rpc_url=rpc_url)
        rpc_checked = rpc_status is not None
        if rpc_status is not None:
            network_id = (
                rpc_status.get("result", {}).get("node_info", {}).get("network")
            )
            if network_id and network_id != plan["chain_id"]:
                raise ValueError(
                    "live RPC chain_id does not match the recovery plan"
                )
            latest_height = (
                rpc_status.get("result", {})
                .get("sync_info", {})
                .get("latest_block_height")
            )
            if latest_height is not None:
                try:
                    latest_height_int = int(latest_height)
                except TypeError, ValueError:
                    latest_height_int = None
                if (
                    latest_height_int is not None
                    and latest_height_int < plan["target_height"]
                ):
                    raise ValueError(
                        "live RPC height is below the recovery target height"
                    )

    return {
        "home": str(home),
        "config_path": str(config_path),
        "rpc_checked": rpc_checked,
        "rpc_status": rpc_status,
        "requires_manual_hash_confirmation": True,
    }


def _prepare_recovery_payload(
    *,
    plan: dict,
    profile: dict,
    network: dict,
    home: Path,
    validation: dict,
) -> dict:
    return {
        "plan": plan,
        "node": {
            "name": profile["name"],
            "network": profile["network"],
            "home": str(home),
        },
        "validation": validation,
        "manual_confirmation": {
            "trusted_block_hash": plan["trusted_block_hash"],
            "trusted_app_hash": plan["trusted_app_hash"],
        },
    }


def _handle_recovery_validate(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    plan_path = args.plan.resolve()
    plan = read_recovery_plan(plan_path)
    profile_path, profile, _, network = _load_profile_and_network(
        base_dir=base_dir,
        name=args.name,
        profile_arg=args.profile,
        network_arg=args.network,
        configs_dir=args.configs_dir,
    )
    stack_dir = _resolve_stack_dir_from_profile(
        base_dir=base_dir,
        profile=profile,
        explicit_stack_dir=args.stack_dir,
    )
    home = _resolve_home(
        base_dir=base_dir,
        profile=profile,
        profile_path=profile_path,
        stack_dir=stack_dir,
        explicit_home=args.home,
    )
    validation = _validate_recovery_context(
        plan=plan,
        profile=profile,
        network=network,
        home=home,
        rpc_url=args.rpc_url,
    )
    payload = _prepare_recovery_payload(
        plan=plan,
        profile=profile,
        network=network,
        home=home,
        validation=validation,
    )
    payload["dry_run"] = True
    print(json.dumps(payload, indent=2))
    return 0


def _handle_recovery_apply(args: argparse.Namespace) -> int:
    if not args.yes:
        raise ValueError(
            "recovery apply is destructive; pass --yes after reviewing the plan"
        )

    base_dir = args.base_dir.resolve()
    plan_path = args.plan.resolve()
    plan = read_recovery_plan(plan_path)
    profile_path, profile, _, network = _load_profile_and_network(
        base_dir=base_dir,
        name=args.name,
        profile_arg=args.profile,
        network_arg=args.network,
        configs_dir=args.configs_dir,
    )
    stack_dir = _resolve_stack_dir_from_profile(
        base_dir=base_dir,
        profile=profile,
        explicit_stack_dir=args.stack_dir,
    )
    home = _resolve_home(
        base_dir=base_dir,
        profile=profile,
        profile_path=profile_path,
        stack_dir=stack_dir,
        explicit_home=args.home,
    )
    validation = _validate_recovery_context(
        plan=plan,
        profile=profile,
        network=network,
        home=home,
        rpc_url=args.rpc_url,
    )
    payload = _prepare_recovery_payload(
        plan=plan,
        profile=profile,
        network=network,
        home=home,
        validation=validation,
    )

    if args.dry_run:
        payload["dry_run"] = True
        print(json.dumps(payload, indent=2))
        return 0

    stop_result = None
    if not args.skip_stop:
        if stack_dir is None:
            raise ValueError(
                "recovery apply requires a resolved xian-stack directory "
                "unless --skip-stop is used"
            )
        stop_result = stop_xian_stack_node(
            stack_dir=stack_dir,
            cometbft_home=home,
            **_stack_runtime_profile_kwargs(profile, network),
        )

    backup_archive = None
    if not args.skip_backup:
        backup_dir = args.backup_dir
        if backup_dir is None:
            backup_dir = base_dir / "recovery-backups"
        if not backup_dir.is_absolute():
            backup_dir = (base_dir / backup_dir).resolve()
        backup_archive = _build_recovery_backup(
            home=home,
            backup_dir=backup_dir,
            plan_name=plan["name"],
            node_name=profile["name"],
        )

    node_admin = get_node_admin_module()
    snapshot_archive_name = node_admin.apply_snapshot_archive(
        plan["artifact"]["uri"],
        home,
        expected_sha256=plan["artifact"].get("sha256"),
    )

    start_result = None
    if args.start_node:
        if stack_dir is None:
            raise ValueError(
                "--start-node requires a resolved xian-stack directory"
            )
        start_result = start_xian_stack_node(
            stack_dir=stack_dir,
            cometbft_home=home,
            **_stack_runtime_profile_kwargs(profile, network),
            wait_for_rpc=not args.no_wait,
            rpc_timeout_seconds=args.rpc_timeout_seconds,
        )

    payload.update(
        {
            "dry_run": False,
            "stopped_node": stop_result is not None,
            "stop_result": stop_result,
            "backup_archive": (
                None if backup_archive is None else str(backup_archive)
            ),
            "snapshot_restore": {
                "artifact_kind": plan["artifact"]["kind"],
                "artifact_uri": plan["artifact"]["uri"],
                "snapshot_archive_name": snapshot_archive_name,
            },
            "started_node": start_result is not None,
            "start_result": start_result,
        }
    )
    print(json.dumps(payload, indent=2))
    return 0


def _load_profile_and_network(
    *,
    base_dir: Path,
    name: str,
    profile_arg: Path | None,
    network_arg: Path | None,
    configs_dir: Path | None = None,
) -> tuple[Path, dict, Path, dict]:
    profile_path = profile_arg or base_dir / "nodes" / f"{name}.json"
    if not profile_path.is_absolute():
        profile_path = (base_dir / profile_path).resolve()
    if not profile_path.exists():
        raise FileNotFoundError(f"node profile not found: {profile_path}")

    profile = read_node_profile(profile_path)
    network_name = profile.get("network")
    if not network_name:
        raise ValueError(
            "node profile is missing network; "
            "recreate it with xian network join"
        )

    network_path = resolve_network_manifest_path(
        base_dir=base_dir,
        network_name=network_name,
        explicit_manifest=network_arg,
        configs_dir=configs_dir,
    )
    network = read_network_manifest(network_path)
    return profile_path, profile, network_path, network


def _initialize_node_from_args(args: argparse.Namespace) -> dict:
    node_setup = get_node_setup_module()

    base_dir = args.base_dir.resolve()
    profile_path, profile, network_path, network = _load_profile_and_network(
        base_dir=base_dir,
        name=args.name,
        profile_arg=args.profile,
        network_arg=args.network,
        configs_dir=args.configs_dir,
    )

    stack_dir = _resolve_stack_dir_from_profile(
        base_dir=base_dir,
        profile=profile,
        explicit_stack_dir=args.stack_dir,
    )

    explicit_validator_key = args.validator_key
    if (
        explicit_validator_key is not None
        and not explicit_validator_key.is_absolute()
    ):
        explicit_validator_key = (base_dir / explicit_validator_key).resolve()

    validator_key_ref = explicit_validator_key or _resolve_path(
        profile.get("validator_key_ref"),
        base_dir=base_dir,
        fallback_dir=profile_path.parent,
    )
    if validator_key_ref is None or not validator_key_ref.exists():
        raise FileNotFoundError(
            "validator key reference is required; set validator_key_ref in the "
            "node profile or pass --validator-key"
        )

    validator_key_payload = _extract_priv_validator_key(
        read_json(validator_key_ref)
    )
    genesis, effective_genesis_source = _resolve_effective_genesis_payload(
        profile=profile,
        network=network,
        base_dir=base_dir,
        manifest_path=network_path,
        configs_dir=args.configs_dir,
    )

    if genesis.get("chain_id") and genesis["chain_id"] != network["chain_id"]:
        raise ValueError(
            f"genesis chain_id {genesis['chain_id']} does not match manifest "
            f"chain_id {network['chain_id']}"
        )

    home = _resolve_home(
        base_dir=base_dir,
        profile=profile,
        profile_path=profile_path,
        stack_dir=stack_dir,
        explicit_home=args.home,
    )

    seed_nodes = list(network.get("seed_nodes") or [])
    seed_nodes.extend(profile.get("seeds") or [])

    configs = node_setup.render_node_configs(
        options=node_setup.NodeConfigOptions(
            moniker=profile["moniker"],
            seed_nodes=tuple(seed_nodes),
            service_node=bool(profile.get("service_node")),
            enable_pruning=bool(profile.get("pruning_enabled")),
            blocks_to_keep=int(profile.get("blocks_to_keep", 100000)),
            block_policy_mode=str(
                profile.get(
                    "block_policy_mode",
                    network.get("block_policy_mode", "on_demand"),
                )
            ),
            block_policy_interval=str(
                profile.get(
                    "block_policy_interval",
                    network.get("block_policy_interval", "0s"),
                )
            ),
            transaction_trace_logging=bool(
                profile.get("transaction_trace_logging", False)
            ),
            app_logging=node_setup.AppLoggingOptions(
                level=str(profile.get("app_log_level", "INFO")),
                json_logging=bool(profile.get("app_log_json", False)),
                rotation_hours=int(profile.get("app_log_rotation_hours", 1)),
                retention_days=int(profile.get("app_log_retention_days", 7)),
            ),
            simulation=node_setup.SimulationOptions(
                enabled=bool(profile.get("simulation_enabled", True)),
                max_concurrency=int(
                    profile.get("simulation_max_concurrency", 2)
                ),
                timeout_ms=int(profile.get("simulation_timeout_ms", 3000)),
                max_chi=int(profile.get("simulation_max_chi", 1_000_000)),
            ),
            parallel_execution=node_setup.ParallelExecutionOptions(
                enabled=bool(profile.get("parallel_execution_enabled", False)),
                workers=int(profile.get("parallel_execution_workers", 0)),
                min_transactions=int(
                    profile.get("parallel_execution_min_transactions", 8)
                ),
            ),
            # The xian-stack runtime publishes the app metrics port from Docker,
            # so the in-container exporter must listen on all interfaces.
            metrics=node_setup.MetricsOptions(host="0.0.0.0"),
        )
    )
    config = configs["cometbft"]
    xian_config = configs["xian"]

    result = node_setup.materialize_cometbft_home(
        home=home,
        config=config,
        xian_config=xian_config,
        genesis=genesis,
        priv_validator_key=validator_key_payload,
        overwrite=args.force,
    )
    effective_snapshot_url = _resolve_effective_snapshot_url(
        profile=profile,
        network=network,
        explicit_snapshot_url=getattr(args, "snapshot_url", None),
    )
    result["effective_snapshot_url"] = effective_snapshot_url
    result["effective_genesis_source"] = effective_genesis_source
    result["snapshot_restored"] = False
    if getattr(args, "restore_snapshot", False):
        snapshot_result = _restore_snapshot(
            base_dir=base_dir,
            profile=profile,
            profile_path=profile_path,
            network=network,
            stack_dir=stack_dir,
            explicit_home=home,
            explicit_snapshot_url=getattr(args, "snapshot_url", None),
        )
        result["snapshot_restored"] = True
        result["snapshot"] = snapshot_result
    return result


def _handle_node_init(args: argparse.Namespace) -> int:
    result = _initialize_node_from_args(args)
    print(json.dumps(result, indent=2))
    return 0


def _handle_node_start(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    profile_path, profile, _, network = _load_profile_and_network(
        base_dir=base_dir,
        name=args.name,
        profile_arg=args.profile,
        network_arg=args.network,
        configs_dir=args.configs_dir,
    )

    stack_dir = resolve_stack_dir(
        base_dir,
        explicit=_resolve_stack_dir_from_profile(
            base_dir=base_dir,
            profile=profile,
            explicit_stack_dir=args.stack_dir,
        ),
    )
    home = _resolve_home(
        base_dir=base_dir,
        profile=profile,
        profile_path=profile_path,
        stack_dir=stack_dir,
    )
    config_path = home / "config" / "config.toml"
    xian_config_path = home / "config" / "xian.toml"
    if not config_path.exists():
        raise FileNotFoundError(
            f"{config_path} does not exist; "
            f"run `xian node init {args.name}` first"
        )
    if not xian_config_path.exists():
        raise FileNotFoundError(
            f"{xian_config_path} does not exist; "
            f"run `xian node init {args.name}` first"
        )

    result = start_xian_stack_node(
        stack_dir=stack_dir,
        cometbft_home=home,
        **_stack_runtime_profile_kwargs(profile, network),
        wait_for_rpc=not args.skip_health_check,
        rpc_timeout_seconds=args.rpc_timeout_seconds,
    )
    print(json.dumps(result, indent=2))
    return 0


def _handle_node_stop(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    profile_path, profile, _, network = _load_profile_and_network(
        base_dir=base_dir,
        name=args.name,
        profile_arg=args.profile,
        network_arg=args.network,
        configs_dir=args.configs_dir,
    )

    stack_dir = resolve_stack_dir(
        base_dir,
        explicit=_resolve_stack_dir_from_profile(
            base_dir=base_dir,
            profile=profile,
            explicit_stack_dir=args.stack_dir,
        ),
    )
    result = stop_xian_stack_node(
        stack_dir=stack_dir,
        cometbft_home=_resolve_home(
            base_dir=base_dir,
            profile=profile,
            profile_path=profile_path,
            stack_dir=stack_dir,
        ),
        **_stack_runtime_profile_kwargs(profile, network),
    )
    print(json.dumps(result, indent=2))
    return 0


def _resolve_node_context(args: argparse.Namespace) -> dict[str, object]:
    base_dir = args.base_dir.resolve()
    profile_path, profile, network_path, network = _load_profile_and_network(
        base_dir=base_dir,
        name=args.name,
        profile_arg=args.profile,
        network_arg=args.network,
        configs_dir=args.configs_dir,
    )

    stack_dir = _resolve_stack_dir_from_profile(
        base_dir=base_dir,
        profile=profile,
        explicit_stack_dir=args.stack_dir,
    )
    stack_dir = resolve_stack_dir(base_dir, explicit=stack_dir)

    home = _resolve_home(
        base_dir=base_dir,
        profile=profile,
        profile_path=profile_path,
        stack_dir=stack_dir,
        explicit_home=getattr(args, "home", None),
    )
    return {
        "base_dir": base_dir,
        "profile_path": profile_path,
        "profile": profile,
        "network_path": network_path,
        "network": network,
        "stack_dir": stack_dir,
        "home": home,
    }


def _format_url_host(hostname: str) -> str:
    if ":" in hostname and not hostname.startswith("["):
        return f"[{hostname}]"
    return hostname


def _display_endpoint_host(hostname: str) -> str:
    if hostname == "0.0.0.0":
        return "127.0.0.1"
    if hostname == "::":
        return "::1"
    return hostname


def _replace_url_port(url: str, *, port: int, suffix: str = "") -> str:
    parsed = urlparse(url)
    scheme = parsed.scheme or "http"
    hostname = _format_url_host(parsed.hostname or "127.0.0.1")
    return f"{scheme}://{hostname}:{port}{suffix}"


def _rpc_base_url(rpc_status_url: str) -> str:
    if rpc_status_url.endswith("/status"):
        return rpc_status_url[: -len("/status")]
    return rpc_status_url.rstrip("/")


def _fallback_node_endpoints(
    *,
    rpc_status_url: str,
    profile: NodeProfile,
    network: dict[str, object] | None = None,
) -> dict[str, str]:
    base_url = _rpc_base_url(rpc_status_url)
    endpoints = {
        "rpc": base_url,
        "rpc_status": rpc_status_url,
        "abci_query": f"{base_url}/abci_query",
        "cometbft_metrics": _replace_url_port(
            base_url,
            port=26660,
            suffix="/metrics",
        ),
        "xian_metrics": _replace_url_port(
            base_url,
            port=9108,
            suffix="/metrics",
        ),
    }
    if bool(profile.get("dashboard_enabled")):
        dashboard_host = _display_endpoint_host(
            str(profile.get("dashboard_host", "127.0.0.1"))
        )
        dashboard_port = int(profile.get("dashboard_port", 8080))
        dashboard_url = f"http://{dashboard_host}:{dashboard_port}"
        endpoints["dashboard"] = dashboard_url
        endpoints["dashboard_status"] = f"{dashboard_url}/api/status"
    if bool(profile.get("monitoring_enabled")):
        endpoints["prometheus"] = _replace_url_port(base_url, port=9090)
        endpoints["grafana"] = _replace_url_port(base_url, port=3000)
    if bool(profile.get("intentkit_enabled")):
        intentkit_host = _display_endpoint_host(
            str(profile.get("intentkit_host", "127.0.0.1"))
        )
        intentkit_port = int(profile.get("intentkit_port", 38000))
        intentkit_api_port = int(profile.get("intentkit_api_port", 38080))
        frontend_url = f"http://{intentkit_host}:{intentkit_port}"
        api_url = f"http://{intentkit_host}:{intentkit_api_port}"
        endpoints["intentkit"] = frontend_url
        endpoints["intentkit_api"] = api_url
        endpoints["intentkit_api_health"] = f"{api_url}/health"
    if bool(profile.get("shielded_relayer_enabled")):
        relayer_host = _display_endpoint_host(
            str(profile.get("shielded_relayer_host", "127.0.0.1"))
        )
        relayer_port = int(profile.get("shielded_relayer_port", 38180))
        relayer_url = f"http://{relayer_host}:{relayer_port}"
        endpoints["shielded_relayer"] = relayer_url
        endpoints["shielded_relayer_health"] = f"{relayer_url}/health"
        endpoints["shielded_relayer_info"] = f"{relayer_url}/v1/info"
        endpoints["shielded_relayer_metrics"] = f"{relayer_url}/metrics"
        endpoints["shielded_relayer_quote"] = f"{relayer_url}/v1/quote"
        endpoints["shielded_relayer_jobs"] = f"{relayer_url}/v1/jobs"
    else:
        endpoints.update(_network_shielded_relayer_endpoints(network))
    return endpoints


def _collect_node_endpoints(args: argparse.Namespace) -> dict[str, object]:
    context = _resolve_node_context(args)
    profile = context["profile"]
    network = context["network"]
    stack_dir = context["stack_dir"]
    home = context["home"]
    rpc_status_url = getattr(args, "rpc_url", "http://127.0.0.1:26657/status")
    node_image_mode, node_integrated_image, node_split_image = (
        _effective_node_image_config(profile, network)
    )

    payload: dict[str, object] = {
        "profile_path": str(context["profile_path"]),
        "network_path": str(context["network_path"]),
        "node_image_mode": node_image_mode,
        "node_integrated_image": node_integrated_image,
        "node_split_image": node_split_image,
        "service_node": bool(profile.get("service_node")),
        "operator_profile": profile.get("operator_profile"),
        "monitoring_profile": profile.get("monitoring_profile"),
        "dashboard_enabled": bool(profile.get("dashboard_enabled")),
        "monitoring_enabled": bool(profile.get("monitoring_enabled")),
        "intentkit_enabled": bool(profile.get("intentkit_enabled")),
        "dex_automation_enabled": bool(profile.get("dex_automation_enabled")),
        "shielded_relayer_enabled": bool(
            profile.get("shielded_relayer_enabled")
        ),
        "intentkit_network_id": profile.get("intentkit_network_id"),
    }
    if stack_dir is not None:
        payload["stack_dir"] = str(stack_dir)

    if stack_dir is not None:
        try:
            backend_payload = get_xian_stack_node_endpoints(
                stack_dir=stack_dir,
                cometbft_home=home,
                **_stack_runtime_profile_kwargs(profile, context["network"]),
            )
            payload["endpoints"] = backend_payload["endpoints"]
            payload["backend_checked"] = True
            return payload
        except Exception as exc:
            payload["backend_checked"] = True
            payload["backend_error"] = str(exc)

    payload["endpoints"] = _fallback_node_endpoints(
        rpc_status_url=rpc_status_url,
        profile=profile,
        network=network,
    )
    return payload


def _summarize_node_status(result: dict[str, object]) -> dict[str, object]:
    rpc_payload = result.get("rpc_status")
    rpc_result = (
        rpc_payload.get("result", {}) if isinstance(rpc_payload, dict) else {}
    )
    sync_info = (
        rpc_result.get("sync_info", {}) if isinstance(rpc_result, dict) else {}
    )
    node_info = (
        rpc_result.get("node_info", {}) if isinstance(rpc_result, dict) else {}
    )
    other = node_info.get("other", {}) if isinstance(node_info, dict) else {}

    state = "ready"
    if not result.get("initialized"):
        state = "not_initialized"
    elif result.get("backend_checked") and not result.get("backend_running"):
        state = "stopped"
    elif result.get("rpc_checked") and not result.get("rpc_reachable"):
        state = "rpc_unreachable"

    summary: dict[str, object] = {
        "state": state,
        "initialized": bool(result.get("initialized")),
        "service_node": bool(result.get("profile", {}).get("service_node")),
        "operator_profile": result.get("profile", {}).get("operator_profile"),
        "monitoring_profile": result.get("profile", {}).get(
            "monitoring_profile"
        ),
        "dashboard_enabled": bool(
            result.get("profile", {}).get("dashboard_enabled")
        ),
        "monitoring_enabled": bool(
            result.get("profile", {}).get("monitoring_enabled")
        ),
        "intentkit_enabled": bool(
            result.get("profile", {}).get("intentkit_enabled")
        ),
        "dex_automation_enabled": bool(
            result.get("profile", {}).get("dex_automation_enabled")
        ),
        "shielded_relayer_enabled": bool(
            result.get("profile", {}).get("shielded_relayer_enabled")
        ),
        "backend_running": result.get("backend_running"),
        "rpc_reachable": result.get("rpc_reachable"),
        "rpc_height": sync_info.get("latest_block_height"),
        "rpc_latest_block_time": sync_info.get("latest_block_time"),
        "rpc_block_age_seconds": _block_age_seconds(
            sync_info.get("latest_block_time")
        ),
        "rpc_catching_up": sync_info.get("catching_up"),
        "rpc_network": node_info.get("network"),
        "peer_count": other.get("n_peers"),
        "node_image_mode": result.get("profile", {}).get("node_image_mode"),
        "node_integrated_image": result.get("profile", {}).get(
            "node_integrated_image"
        ),
        "node_split_image": result.get("profile", {}).get("node_split_image"),
    }

    release_manifest = result.get("node_release_manifest")
    if isinstance(release_manifest, dict):
        components = release_manifest.get("components")
        build = release_manifest.get("build")
        if isinstance(components, dict):
            summary["release_manifest_refs"] = {
                str(name): component.get("ref")
                for name, component in components.items()
                if isinstance(name, str) and isinstance(component, dict)
            }
        if isinstance(build, dict):
            summary["release_manifest_build"] = {
                "python_image": build.get("python_image"),
                "go_image": build.get("go_image"),
                "cometbft_version": build.get("cometbft_version"),
                "cometbft_source_url": build.get("cometbft_source_url"),
                "cometbft_source_sha256": build.get("cometbft_source_sha256"),
                "s6_overlay_version": build.get("s6_overlay_version"),
                "s6_overlay_noarch_sha256": build.get(
                    "s6_overlay_noarch_sha256"
                ),
                "s6_overlay_x86_64_sha256": build.get(
                    "s6_overlay_x86_64_sha256"
                ),
                "s6_overlay_aarch64_sha256": build.get(
                    "s6_overlay_aarch64_sha256"
                ),
            }

    backend_status = result.get("backend_status")
    if isinstance(backend_status, dict):
        compose_services = backend_status.get("compose_services")
        if isinstance(compose_services, list):
            runtime_images = {
                str(service.get("service")): service.get("image")
                for service in compose_services
                if isinstance(service, dict)
                and isinstance(service.get("service"), str)
                and service.get("image")
            }
            if runtime_images:
                summary["runtime_service_images"] = runtime_images
        if summary["dashboard_enabled"]:
            summary["dashboard_reachable"] = backend_status.get(
                "dashboard_reachable"
            )
        if summary["monitoring_enabled"]:
            summary["prometheus_reachable"] = backend_status.get(
                "prometheus_reachable"
            )
            summary["grafana_reachable"] = backend_status.get(
                "grafana_reachable"
            )
        if summary["intentkit_enabled"]:
            summary["intentkit_running"] = backend_status.get(
                "intentkit_running"
            )
            summary["intentkit_reachable"] = backend_status.get(
                "intentkit_reachable"
            )
            summary["intentkit_api_reachable"] = backend_status.get(
                "intentkit_api_reachable"
            )
        if summary["dex_automation_enabled"]:
            summary["dex_automation_running"] = backend_status.get(
                "dex_automation_running"
            )
            summary["dex_automation_reachable"] = backend_status.get(
                "dex_automation_reachable"
            )
        if summary["shielded_relayer_enabled"]:
            summary["shielded_relayer_running"] = backend_status.get(
                "shielded_relayer_running"
            )
            summary["shielded_relayer_reachable"] = backend_status.get(
                "shielded_relayer_reachable"
            )
    return summary


def _collect_node_status(
    args: argparse.Namespace,
    *,
    check_rpc: bool,
    check_backend: bool = True,
) -> dict:
    context = _resolve_node_context(args)
    profile_path = context["profile_path"]
    profile = context["profile"]
    network_path = context["network_path"]
    network = context["network"]
    stack_dir = context["stack_dir"]
    home = context["home"]
    node_image_mode, node_integrated_image, node_split_image = (
        _effective_node_image_config(profile, network)
    )
    node_release_manifest = _effective_node_release_manifest(profile, network)
    config_path = home / "config" / "config.toml"
    xian_config_path = home / "config" / "xian.toml"
    genesis_path = home / "config" / "genesis.json"
    node_key_path = home / "config" / "node_key.json"
    validator_state_path = home / "data" / "priv_validator_state.json"

    result: dict[str, object] = {
        "profile_path": str(profile_path),
        "network_path": str(network_path),
        "home": str(home),
        "initialized": config_path.exists() and xian_config_path.exists(),
        "config_present": config_path.exists(),
        "xian_config_present": xian_config_path.exists(),
        "genesis_present": genesis_path.exists(),
        "node_key_present": node_key_path.exists(),
        "priv_validator_state_present": validator_state_path.exists(),
        "effective_genesis_source": (
            profile.get("genesis_url")
            or network.get("genesis_source")
            or (
                None
                if network.get("genesis_preset") is None
                else f"preset:{network['genesis_preset']}"
            )
        ),
        "effective_snapshot_url": _resolve_effective_snapshot_url(
            profile=profile,
            network=network,
        ),
        "rpc_checked": check_rpc,
        "profile": {
            "name": args.name,
            "network": profile.get("network"),
            "node_image_mode": node_image_mode,
            "node_integrated_image": node_integrated_image,
            "node_split_image": node_split_image,
            "node_release_manifest": node_release_manifest,
            "service_node": bool(profile.get("service_node")),
            "operator_profile": profile.get("operator_profile"),
            "monitoring_profile": profile.get("monitoring_profile"),
            "dashboard_enabled": bool(profile.get("dashboard_enabled")),
            "monitoring_enabled": bool(profile.get("monitoring_enabled")),
            "intentkit_enabled": bool(profile.get("intentkit_enabled")),
            "intentkit_network_id": profile.get("intentkit_network_id"),
            "dex_automation_enabled": bool(
                profile.get("dex_automation_enabled")
            ),
        },
    }
    result["node_release_manifest"] = node_release_manifest
    if stack_dir is not None:
        result["stack_dir"] = str(stack_dir)

    if node_key_path.exists():
        try:
            result["node_id"] = read_json(node_key_path).get("node_id")
        except json.JSONDecodeError:
            result["node_id"] = None

    if stack_dir is not None and check_backend:
        try:
            backend_status = get_xian_stack_node_status(
                stack_dir=stack_dir,
                cometbft_home=home,
                **_stack_runtime_profile_kwargs(profile, context["network"]),
            )
            result["backend_status"] = backend_status
            result["backend_checked"] = True
            result["backend_running"] = backend_status.get("backend_running")
            if result.get("node_id") is None:
                result["node_id"] = backend_status.get("node_id")
        except Exception as exc:
            result["backend_checked"] = True
            result["backend_error"] = str(exc)

    if check_rpc:
        try:
            result["rpc_status"] = fetch_json(args.rpc_url)
            result["rpc_reachable"] = True
        except Exception as exc:
            result["rpc_reachable"] = False
            result["rpc_error"] = str(exc)

    if isinstance(result.get("backend_status"), dict) and isinstance(
        result["backend_status"].get("endpoints"), dict
    ):
        result["endpoints"] = result["backend_status"]["endpoints"]
    else:
        result["endpoints"] = _fallback_node_endpoints(
            rpc_status_url=args.rpc_url,
            profile=profile,
        )

    result["summary"] = _summarize_node_status(result)
    return result


def _handle_node_status(args: argparse.Namespace) -> int:
    result = _collect_node_status(args, check_rpc=not args.skip_rpc)
    print(json.dumps(result, indent=2))
    return 0


def _handle_node_endpoints(args: argparse.Namespace) -> int:
    result = _collect_node_endpoints(args)
    print(json.dumps(result, indent=2))
    return 0


def _read_rendered_config_toml(home: Path) -> dict[str, object]:
    config_path = home / "config" / "config.toml"
    if not config_path.exists():
        raise FileNotFoundError(f"{config_path} does not exist")
    try:
        return tomllib.loads(config_path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as exc:
        raise ValueError(f"invalid TOML in {config_path}") from exc


def _collect_statesync_readiness(home: Path) -> dict[str, object]:
    config = _read_rendered_config_toml(home)
    statesync = config.get("statesync", {})
    enabled = bool(statesync.get("enable"))
    rpc_servers = [
        server.strip()
        for server in str(statesync.get("rpc_servers", "")).split(",")
        if server.strip()
    ]
    trust_height = int(statesync.get("trust_height", 0) or 0)
    trust_hash = str(statesync.get("trust_hash", "") or "")
    trust_period = str(statesync.get("trust_period", "") or "")

    if not enabled:
        state = "disabled"
        ready = False
    else:
        ready = (
            len(rpc_servers) >= 2
            and trust_height > 0
            and bool(trust_hash)
            and bool(trust_period)
        )
        state = "configured" if ready else "incomplete"

    return {
        "enabled": enabled,
        "state": state,
        "ready": ready,
        "rpc_servers": rpc_servers,
        "trust_height": trust_height,
        "trust_hash_present": bool(trust_hash),
        "trust_period": trust_period,
    }


def _collect_node_health(args: argparse.Namespace) -> dict[str, object]:
    context = _resolve_node_context(args)
    profile = context["profile"]
    network = context["network"]
    stack_dir = context["stack_dir"]
    home = context["home"]
    node_image_mode, node_integrated_image, node_split_image = (
        _effective_node_image_config(profile, network)
    )

    payload: dict[str, object] = {
        "profile_path": str(context["profile_path"]),
        "network_path": str(context["network_path"]),
        "node_image_mode": node_image_mode,
        "node_integrated_image": node_integrated_image,
        "node_split_image": node_split_image,
        "home": str(home),
        "service_node": bool(profile.get("service_node")),
        "operator_profile": profile.get("operator_profile"),
        "monitoring_profile": profile.get("monitoring_profile"),
        "dashboard_enabled": bool(profile.get("dashboard_enabled")),
        "monitoring_enabled": bool(profile.get("monitoring_enabled")),
        "intentkit_enabled": bool(profile.get("intentkit_enabled")),
        "intentkit_network_id": profile.get("intentkit_network_id"),
        "dex_automation_enabled": bool(profile.get("dex_automation_enabled")),
        "effective_snapshot_url": _resolve_effective_snapshot_url(
            profile=profile,
            network=context["network"],
        ),
    }
    if stack_dir is not None:
        payload["stack_dir"] = str(stack_dir)

    try:
        payload["statesync"] = _collect_statesync_readiness(home)
    except Exception as exc:
        payload["statesync"] = {
            "state": "unavailable",
            "error": str(exc),
        }

    if stack_dir is not None:
        payload["health"] = get_xian_stack_node_health(
            stack_dir=stack_dir,
            cometbft_home=home,
            **_stack_runtime_profile_kwargs(profile, network),
            rpc_url=args.rpc_url,
            check_disk=not args.skip_disk_check,
        )
        payload["endpoints"] = payload["health"].get("endpoints", {})
    else:
        payload["endpoints"] = _fallback_node_endpoints(
            rpc_status_url=args.rpc_url,
            profile=profile,
        )
    return payload


def _handle_node_health(args: argparse.Namespace) -> int:
    result = _collect_node_health(args)
    print(json.dumps(result, indent=2))
    return 0


def _handle_snapshot_restore(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    profile_path, profile, _, network = _load_profile_and_network(
        base_dir=base_dir,
        name=args.name,
        profile_arg=args.profile,
        network_arg=args.network,
        configs_dir=args.configs_dir,
    )
    stack_dir = _resolve_stack_dir_from_profile(
        base_dir=base_dir,
        profile=profile,
        explicit_stack_dir=args.stack_dir,
    )
    result = _restore_snapshot(
        base_dir=base_dir,
        profile=profile,
        profile_path=profile_path,
        network=network,
        stack_dir=stack_dir,
        explicit_home=args.home,
        explicit_snapshot_url=args.snapshot_url,
    )
    print(json.dumps(result, indent=2))
    return 0


def _run_check(name: str, fn) -> dict[str, object]:
    try:
        detail = fn()
    except Exception as exc:
        return {
            "name": name,
            "ok": False,
            "detail": str(exc),
        }

    return {
        "name": name,
        "ok": True,
        "detail": detail,
    }


def _doctor_node_artifacts(status: dict[str, object]) -> dict[str, object]:
    missing = []
    if not status.get("config_present"):
        missing.append("config.toml")
    if not status.get("xian_config_present"):
        missing.append("xian.toml")
    if not status.get("genesis_present"):
        missing.append("genesis.json")
    if not status.get("node_key_present"):
        missing.append("node_key.json")
    if not status.get("priv_validator_state_present"):
        missing.append("priv_validator_state.json")
    if not status.get("initialized") or missing:
        detail = ", ".join(missing) if missing else "node home not initialized"
        raise RuntimeError(detail)
    return {
        "home": status.get("home"),
        "node_id": status.get("node_id"),
    }


def _doctor_backend_check(status: dict[str, object]) -> dict[str, object]:
    if status.get("backend_error"):
        raise RuntimeError(str(status["backend_error"]))
    if not status.get("backend_running"):
        raise RuntimeError("xian-stack backend is not running")
    return {
        "stack_dir": status.get("stack_dir"),
        "backend_running": True,
    }


def _doctor_rpc_check(status: dict[str, object]) -> dict[str, object]:
    if not status.get("rpc_reachable"):
        raise RuntimeError(str(status.get("rpc_error", "RPC is unreachable")))
    return status.get("summary", {})


def _doctor_statesync_check(status: dict[str, object]) -> dict[str, object]:
    readiness = _collect_statesync_readiness(Path(str(status["home"])))
    if readiness["state"] == "incomplete":
        raise RuntimeError(
            "statesync is enabled but trust settings are incomplete"
        )
    return readiness


def _doctor_snapshot_check(status: dict[str, object]) -> dict[str, object]:
    return {
        "effective_snapshot_url": status.get("effective_snapshot_url"),
        "available": bool(status.get("effective_snapshot_url")),
    }


def _doctor_service_check(
    status: dict[str, object],
    *,
    service_name: str,
    reachable_key: str,
    error_key: str,
) -> dict[str, object]:
    backend_status = status.get("backend_status")
    if not isinstance(backend_status, dict):
        raise RuntimeError("backend status is unavailable")
    if not backend_status.get(reachable_key):
        raise RuntimeError(
            str(backend_status.get(error_key, f"{service_name} is unreachable"))
        )
    return {
        "service": service_name,
        "reachable": True,
        "url": status.get("endpoints", {}).get(service_name),
    }


def _handle_doctor(args: argparse.Namespace) -> int:
    base_dir = args.base_dir.resolve()
    checks = [
        _run_check(
            "configs_dir",
            lambda: str(
                resolve_configs_dir(base_dir, explicit=args.configs_dir)
            ),
        ),
        _run_check(
            "stack_dir",
            lambda: str(resolve_stack_dir(base_dir, explicit=args.stack_dir)),
        ),
        _run_check("node_setup", lambda: get_node_setup_module().__name__),
        _run_check("node_admin", lambda: get_node_admin_module().__name__),
        _run_check(
            "genesis_builder",
            lambda: get_genesis_builder_module().__name__,
        ),
    ]

    if args.name is not None:
        status_args = argparse.Namespace(
            name=args.name,
            base_dir=base_dir,
            profile=args.profile,
            network=args.network,
            stack_dir=args.stack_dir,
            configs_dir=args.configs_dir,
            home=args.home,
            rpc_url=args.rpc_url,
            skip_rpc=args.skip_live_checks,
        )
        node_status = _collect_node_status(
            status_args,
            check_rpc=not args.skip_live_checks,
            check_backend=not args.skip_live_checks,
        )
        checks.append(
            _run_check(
                "node_status",
                lambda: node_status,
            )
        )
        checks.append(
            _run_check(
                "node_artifacts",
                lambda: _doctor_node_artifacts(node_status),
            )
        )
        checks.append(
            _run_check(
                "endpoints",
                lambda: node_status.get("endpoints", {}),
            )
        )
        checks.append(
            _run_check(
                "statesync",
                lambda: _doctor_statesync_check(node_status),
            )
        )
        checks.append(
            _run_check(
                "snapshot_bootstrap",
                lambda: _doctor_snapshot_check(node_status),
            )
        )
        if not args.skip_live_checks:
            checks.append(
                _run_check(
                    "backend",
                    lambda: _doctor_backend_check(node_status),
                )
            )
            checks.append(
                _run_check(
                    "rpc",
                    lambda: _doctor_rpc_check(node_status),
                )
            )
            profile = node_status.get("profile", {})
            if profile.get("dashboard_enabled"):
                checks.append(
                    _run_check(
                        "dashboard",
                        lambda: _doctor_service_check(
                            node_status,
                            service_name="dashboard",
                            reachable_key="dashboard_reachable",
                            error_key="dashboard_error",
                        ),
                    )
                )
            if profile.get("monitoring_enabled"):
                checks.append(
                    _run_check(
                        "prometheus",
                        lambda: _doctor_service_check(
                            node_status,
                            service_name="prometheus",
                            reachable_key="prometheus_reachable",
                            error_key="prometheus_error",
                        ),
                    )
                )
            if profile.get("intentkit_enabled"):
                checks.append(
                    _run_check(
                        "intentkit",
                        lambda: _doctor_service_check(
                            node_status,
                            service_name="intentkit",
                            reachable_key="intentkit_reachable",
                            error_key="intentkit_probe_error",
                        ),
                    )
                )
                checks.append(
                    _run_check(
                        "intentkit_api",
                        lambda: _doctor_service_check(
                            node_status,
                            service_name="intentkit_api",
                            reachable_key="intentkit_api_reachable",
                            error_key="intentkit_api_error",
                        ),
                    )
                )
            if profile.get("dex_automation_enabled"):
                checks.append(
                    _run_check(
                        "dex_automation",
                        lambda: _doctor_service_check(
                            node_status,
                            service_name="dex_automation",
                            reachable_key="dex_automation_reachable",
                            error_key="dex_automation_error",
                        ),
                    )
                )
            if profile.get("monitoring_enabled"):
                checks.append(
                    _run_check(
                        "grafana",
                        lambda: _doctor_service_check(
                            node_status,
                            service_name="grafana",
                            reachable_key="grafana_reachable",
                            error_key="grafana_error",
                        ),
                    )
                )

    result = {
        "ok": all(check["ok"] for check in checks),
        "checks": checks,
    }
    if args.name is not None:
        result["node"] = node_status
    print(json.dumps(result, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    return _build_parser()


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
