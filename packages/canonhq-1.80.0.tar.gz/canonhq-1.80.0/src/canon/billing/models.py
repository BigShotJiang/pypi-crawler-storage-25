"""Pydantic models for billing and subscriptions."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Literal, Self

from pydantic import BaseModel, Field, model_validator

# --- Pricing constants ---

MIN_SEATS = 3

PLAN_PRICES = {
    "starter": {"monthly": 900, "annual": 8600},  # cents: $9/mo, $86/yr
    "pro": {"monthly": 1900, "annual": 18200},  # cents: $19/mo, $182/yr
}

AI_OPS_PER_SEAT = 500  # included ops per seat per month on Pro
AI_OP_OVERAGE_CENTS = 8  # $0.08 per overage op

STARTER_MAX_REPOS = 10

# Free tier (DB-only — no Stripe customer/subscription). Auto-enrolled
# on org creation for managed-cloud deployments.
FREE_MAX_REPOS = 3
FREE_MAX_INTEGRATIONS = 1
FREE_AI_OPS_INCLUDED = 50  # total per month, not per-seat

# Internal tier (comped via Stripe 100%-off coupon, plan stored as
# "internal" in DB so feature gates treat the org as fully uncapped).
# Not in the public pricing matrix. `None` AI-op caps mean "unlimited";
# callers must branch on None rather than rely on a sentinel integer.

# Operations that count as AI ops
AI_OP_TYPES = frozenset(
    {
        "pr_analysis",
        "doc_update_generation",
        "spec_coverage_scan",
        "slack_qa_response",
        "spec_generation_assist",
    }
)


class Plan(StrEnum):
    FREE = "free"
    STARTER = "starter"
    PRO = "pro"
    ENTERPRISE = "enterprise"
    INTERNAL = "internal"


class BillingCycle(StrEnum):
    MONTHLY = "monthly"
    ANNUAL = "annual"


class SubscriptionStatus(StrEnum):
    ACTIVE = "active"
    PAST_DUE = "past_due"
    CANCELED = "canceled"
    TRIALING = "trialing"


class Subscription(BaseModel):
    id: str
    org_login: str
    stripe_customer_id: str | None = None
    stripe_subscription_id: str | None = None
    plan: Plan
    billing_cycle: BillingCycle
    status: SubscriptionStatus = SubscriptionStatus.ACTIVE
    seat_count: int = Field(default=MIN_SEATS, ge=MIN_SEATS)
    current_period_start: datetime | None = None
    current_period_end: datetime | None = None
    trial_start: datetime | None = None
    trial_end: datetime | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    @model_validator(mode="after")
    def _check_stripe_ids_match_plan(self) -> Self:
        """Free orgs have no Stripe customer (Free is DB-only).
        Internal orgs do have a Stripe sub (Pro pricing + 100%-off coupon).
        Paid tiers (Starter/Pro/Enterprise) always have a customer once
        the row is past initial construction — but transitional state
        (e.g. a row mid-checkout) may briefly have None. We only enforce
        the Free invariant; the rest is informational."""
        if self.plan == Plan.FREE and self.stripe_subscription_id is not None:
            raise ValueError(
                "Free plan must have no Stripe subscription — "
                f"got stripe_subscription_id={self.stripe_subscription_id!r}"
            )
        return self

    @model_validator(mode="after")
    def _check_free_seat_count(self) -> Self:
        """Free tier is fixed at MIN_SEATS — no upgrades within the tier."""
        if self.plan == Plan.FREE and self.seat_count != MIN_SEATS:
            raise ValueError(
                f"Free plan is fixed at {MIN_SEATS} seats — got seat_count={self.seat_count}"
            )
        return self

    @property
    def is_trialing(self) -> bool:
        return self.status == SubscriptionStatus.TRIALING

    @property
    def is_trial_eligible(self) -> bool:
        # Free orgs can trial. Orgs whose paid sub was cancelled can trial
        # again — but only if their previous plan was a customer-facing
        # paid tier. INTERNAL/ENTERPRISE orgs whose Stripe sub gets
        # cancelled (revoked comp coupon, expired contract) must NOT be
        # silently downgraded into a 14-day Pro trial — their DB plan is
        # the source of truth and the admin/sales path owns re-provisioning.
        if self.plan == Plan.FREE:
            return True
        if self.status == SubscriptionStatus.CANCELED:
            return self.plan in (Plan.STARTER, Plan.PRO)
        return False

    @property
    def ai_ops_included(self) -> int | None:
        """AI ops included this billing period. `None` means unlimited
        (callers should render as 'Unlimited' and skip remaining/overage
        math). 0 means no included ops on this tier."""
        match self.plan:
            case Plan.INTERNAL | Plan.ENTERPRISE:
                return None
            case Plan.PRO:
                return self.seat_count * AI_OPS_PER_SEAT
            case Plan.FREE:
                return FREE_AI_OPS_INCLUDED
            case Plan.STARTER:
                return 0  # BYOK — no included ops

    @property
    def max_repos(self) -> int | None:
        """Max repos allowed. `None` means unlimited."""
        match self.plan:
            case Plan.FREE:
                return FREE_MAX_REPOS
            case Plan.STARTER:
                return STARTER_MAX_REPOS
            case Plan.PRO | Plan.ENTERPRISE | Plan.INTERNAL:
                return None

    @property
    def max_integrations(self) -> int | None:
        """Max integration providers allowed. `None` means unlimited."""
        match self.plan:
            case Plan.FREE:
                return FREE_MAX_INTEGRATIONS
            case Plan.STARTER | Plan.PRO | Plan.ENTERPRISE | Plan.INTERNAL:
                return None


class CheckoutRequest(BaseModel):
    plan: Plan
    billing_cycle: BillingCycle = BillingCycle.MONTHLY
    seat_count: int = Field(default=MIN_SEATS, ge=MIN_SEATS)
    success_url: str
    cancel_url: str

    @model_validator(mode="after")
    def _reject_non_checkable_plans(self) -> Self:
        if self.plan == Plan.ENTERPRISE:
            raise ValueError("Enterprise plan requires contacting sales")
        if self.plan == Plan.FREE:
            raise ValueError(
                "Free plan is auto-enrolled at org creation — not selectable via checkout"
            )
        if self.plan == Plan.INTERNAL:
            raise ValueError("Internal plan is admin-only — not selectable via checkout")
        return self


TeamSize = Literal["1-10", "11-50", "51-200", "200+"]


class EnterpriseContactRequest(BaseModel):
    name: str = Field(min_length=1)
    email: str
    company: str = Field(min_length=1)
    team_size: TeamSize
    message: str = ""
    honeypot: str = ""  # spam prevention — should be empty


class AnthropicKeyRequest(BaseModel):
    api_key: str = Field(min_length=10, repr=False)


class AnthropicKeyStatus(BaseModel):
    exists: bool
    suffix: str = ""
    status: str = "none"
    last_validated_at: datetime | None = None


class AiOpUsage(BaseModel):
    """AI operation usage for a billing period. `ops_included = None`
    means unlimited (Internal / Enterprise tiers); the frontend should
    render 'Unlimited' and skip remaining/overage math for those."""

    org_login: str
    period_start: datetime
    period_end: datetime
    ops_used: int = 0
    ops_included: int | None = 0

    @property
    def ops_remaining(self) -> int | None:
        if self.ops_included is None:
            return None
        return max(0, self.ops_included - self.ops_used)

    @property
    def overage_ops(self) -> int:
        if self.ops_included is None:
            return 0
        return max(0, self.ops_used - self.ops_included)

    @property
    def overage_cost_cents(self) -> int:
        return self.overage_ops * AI_OP_OVERAGE_CENTS
