"""Auth0 OIDC provider implementation — cloud-only, excluded from OSS export."""

from __future__ import annotations

import asyncio
import logging
import time
from urllib.parse import quote, urlencode

import httpx

from ...settings import Settings
from .protocol import DeviceCodeResponse, OrgInfo, Pending, TokenSet

logger = logging.getLogger(__name__)


class Auth0Provider:
    """Auth0-specific OIDC provider with Organizations and Management API support."""

    def __init__(self, *, settings: Settings, http_client: httpx.AsyncClient | None = None) -> None:
        if not settings.auth0_domain:
            raise ValueError("auth0_domain is required for Auth0Provider")
        self._settings = settings
        self._http = http_client or httpx.AsyncClient(timeout=30)
        self._domain = settings.auth0_domain
        self._client_id = settings.auth0_client_id
        self._client_secret = settings.auth0_client_secret
        self._audience = settings.auth0_audience
        self._device_client_id = settings.auth0_device_client_id or settings.auth0_client_id
        # M2M credentials for Management API
        self._m2m_client_id = settings.auth0_m2m_client_id
        self._m2m_client_secret = settings.auth0_m2m_client_secret
        self._mgmt_token: str = ""
        self._mgmt_token_expires: float = 0
        self._mgmt_token_lock = asyncio.Lock()

    async def get_login_url(self, *, redirect_uri: str, state: str, org_hint: str = "") -> str:
        params = {
            "response_type": "code",
            "client_id": self._client_id,
            "redirect_uri": redirect_uri,
            "scope": "openid email profile",
            "state": state,
        }
        if self._audience:
            params["audience"] = self._audience
        if org_hint:
            params["organization"] = org_hint
        return f"https://{self._domain}/authorize?{urlencode(params)}"

    async def exchange_code(self, *, code: str, redirect_uri: str) -> TokenSet:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "authorization_code",
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "code": code,
                "redirect_uri": redirect_uri,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError("Token exchange returned no access_token")
        return TokenSet(
            access_token=access_token,
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def refresh_tokens(self, *, refresh_token: str) -> TokenSet:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "refresh_token",
                "client_id": self._device_client_id,
                "refresh_token": refresh_token,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError("Token refresh returned no access_token")
        return TokenSet(
            access_token=access_token,
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", refresh_token),
            expires_in=data.get("expires_in", 0),
        )

    async def get_jwks_uri(self) -> str:
        return f"https://{self._domain}/.well-known/jwks.json"

    async def get_logout_url(self, *, return_to: str) -> str | None:
        params = urlencode({"client_id": self._client_id, "returnTo": return_to})
        return f"https://{self._domain}/v2/logout?{params}"

    async def get_device_code(
        self, *, audience: str = "", scope: str = "", organization: str = ""
    ) -> DeviceCodeResponse | None:
        data: dict[str, str] = {
            "client_id": self._device_client_id,
            "scope": scope or "openid profile email offline_access",
            "audience": audience or self._audience,
        }
        # When an Auth0 Organization id is supplied, forward it so the
        # resulting access token carries an ``org_id`` claim. This is how
        # multi-org deployments resolve the caller's tenant in device flow.
        if organization:
            data["organization"] = organization
        resp = await self._http.post(
            f"https://{self._domain}/oauth/device/code",
            data=data,
        )
        if resp.status_code != 200:
            logger.warning(
                "Auth0 device code request failed: status=%d body=%s",
                resp.status_code,
                resp.text[:500],
            )
            return None
        data = resp.json()
        return DeviceCodeResponse(
            device_code=data["device_code"],
            user_code=data["user_code"],
            verification_uri=data.get("verification_uri", ""),
            verification_uri_complete=data.get("verification_uri_complete", ""),
            interval=data.get("interval", 5),
            expires_in=data.get("expires_in", 900),
        )

    async def poll_device_token(self, device_code: str) -> TokenSet | Pending:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "client_id": self._device_client_id,
                "device_code": device_code,
            },
        )
        if resp.status_code == 403:
            error = resp.json().get("error", "")
            if error in ("authorization_pending", "slow_down"):
                return Pending(slow_down=error == "slow_down")
            raise RuntimeError(f"Device auth error: {error}")
        if resp.status_code != 200:
            raise RuntimeError(f"Device token request failed: {resp.status_code}")
        data = resp.json()
        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError(
                f"Device token response missing access_token (status={resp.status_code})"
            )
        return TokenSet(
            access_token=access_token,
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def get_user_orgs(self, user_id: str) -> list[OrgInfo]:
        if not self._m2m_client_id or not self._m2m_client_secret:
            logger.warning(
                "AUTH0_M2M_CLIENT_ID/SECRET not configured — cannot fetch user organizations"
            )
            return []
        token = await self._get_mgmt_token()
        encoded_id = quote(user_id, safe="")
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/users/{encoded_id}/organizations",
            headers={"Authorization": f"Bearer {token}"},
            params={"per_page": "100"},
        )
        resp.raise_for_status()
        return [
            OrgInfo(
                id=o.get("id", ""), name=o.get("name", ""), display_name=o.get("display_name", "")
            )
            for o in resp.json()
        ]

    # ─── Organization provisioning (Management API) ────────────────────

    async def get_connection_by_name(self, name: str) -> str:
        """Look up an Auth0 connection ID by name."""
        token = await self._get_mgmt_token()
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/connections",
            headers={"Authorization": f"Bearer {token}"},
            params={"name": name, "per_page": "1"},
        )
        resp.raise_for_status()
        connections = resp.json()
        if not connections:
            raise ValueError(f"Auth0 connection not found: {name}")
        return connections[0]["id"]

    async def get_organization_by_name(self, name: str) -> str | None:
        """Look up an Auth0 Organization by name. Returns org_id or None."""
        token = await self._get_mgmt_token()
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/organizations/name/{quote(name, safe='')}",
            headers={"Authorization": f"Bearer {token}"},
        )
        if resp.status_code == 404:
            return None
        resp.raise_for_status()
        return resp.json()["id"]

    async def create_organization(self, *, name: str, display_name: str) -> str:
        """Create an Auth0 Organization and return its org_id."""
        token = await self._get_mgmt_token()
        resp = await self._http.post(
            f"https://{self._domain}/api/v2/organizations",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": name, "display_name": display_name},
        )
        resp.raise_for_status()
        return resp.json()["id"]

    async def update_organization(
        self,
        org_id: str,
        *,
        display_name: str | None = None,
        metadata: dict | None = None,
    ) -> dict:
        """Patch an Auth0 Organization. Returns the updated org record.

        Only the fields passed as non-None are included in the request body,
        so callers can update display_name and metadata independently.
        """
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        body: dict = {}
        if display_name is not None:
            body["display_name"] = display_name
        if metadata is not None:
            body["metadata"] = metadata
        if not body:
            # No-op patch; return current state rather than hitting the API
            resp = await self._http.get(
                f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}",
                headers={"Authorization": f"Bearer {await self._get_mgmt_token()}"},
            )
            resp.raise_for_status()
            return resp.json()
        token = await self._get_mgmt_token()
        resp = await self._http.patch(
            f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}",
            headers={"Authorization": f"Bearer {token}"},
            json=body,
        )
        resp.raise_for_status()
        return resp.json()

    async def enable_org_connections(
        self, org_id: str, github_conn_id: str, db_conn_id: str
    ) -> None:
        """Enable GitHub and DB connections on an organization.

        Idempotent: 409 Conflict (already enabled) is silently ignored.
        GitHub gets assign_membership_on_login=True (safe: gated by restrict_signups).
        DB gets assign_membership_on_login=False (prevents cross-tenant membership).
        """
        token = await self._get_mgmt_token()
        for conn_id, auto_membership in (
            (github_conn_id, True),
            (db_conn_id, False),
        ):
            resp = await self._http.post(
                f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}/enabled_connections",
                headers={"Authorization": f"Bearer {token}"},
                json={
                    "connection_id": conn_id,
                    "assign_membership_on_login": auto_membership,
                },
            )
            if resp.status_code == 409:
                continue  # already enabled
            resp.raise_for_status()

    async def disable_org_connections(self, org_id: str) -> None:
        """Disable all connections on an organization (keeps org for audit)."""
        token = await self._get_mgmt_token()
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}/enabled_connections",
            headers={"Authorization": f"Bearer {token}"},
        )
        resp.raise_for_status()
        for conn in resp.json():
            conn_id = conn.get("connection_id") or conn.get("connection", {}).get("id", "")
            if not conn_id:
                continue
            resp = await self._http.delete(
                f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}/enabled_connections/{quote(conn_id, safe='')}",
                headers={"Authorization": f"Bearer {token}"},
            )
            resp.raise_for_status()

    async def list_users(
        self, *, page: int = 0, per_page: int = 50, search: str = ""
    ) -> list[dict]:
        """List users from Auth0 Management API (GET /api/v2/users)."""
        if not self._m2m_client_id:
            return []
        token = await self._get_mgmt_token()
        params: dict = {"page": page, "per_page": per_page, "include_totals": "false"}
        if search:
            params["q"] = search
            params["search_engine"] = "v3"
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/users",
            headers={"Authorization": f"Bearer {token}"},
            params=params,
        )
        if resp.status_code != 200:
            logger.warning("Auth0 list_users failed: %s %s", resp.status_code, resp.text[:200])
            return []
        return resp.json()

    async def get_user(self, user_id: str) -> dict | None:
        """Get a single user from Auth0 (GET /api/v2/users/{user_id})."""
        if not self._m2m_client_id:
            return None
        token = await self._get_mgmt_token()
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/users/{user_id}",
            headers={"Authorization": f"Bearer {token}"},
        )
        if resp.status_code != 200:
            return None
        return resp.json()

    async def list_organizations(self) -> list[dict]:
        """List all Auth0 Organizations, paginating automatically."""
        if not self._m2m_client_id:
            return []
        token = await self._get_mgmt_token()
        all_orgs: list[dict] = []
        page = 0
        per_page = 100
        while True:
            resp = await self._http.get(
                f"https://{self._domain}/api/v2/organizations",
                headers={"Authorization": f"Bearer {token}"},
                params={"page": page, "per_page": per_page, "include_totals": "false"},
            )
            if resp.status_code != 200:
                logger.warning("Auth0 list_organizations failed: %s", resp.status_code)
                break
            batch = resp.json()
            all_orgs.extend(batch)
            if len(batch) < per_page:
                break
            page += 1
        return all_orgs

    async def update_user(self, user_id: str, patch: dict) -> dict:
        """PATCH an Auth0 user profile. Caller is expected to whitelist keys.

        Used by the Profile → Account self-serve identity edit endpoint.
        The Management API accepts ``name``, ``nickname``, ``picture``, and
        ``email`` among many other fields; callers in this codebase only
        ever pass that subset.
        """
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        token = await self._get_mgmt_token()
        encoded_id = quote(user_id, safe="")
        resp = await self._http.patch(
            f"https://{self._domain}/api/v2/users/{encoded_id}",
            headers={"Authorization": f"Bearer {token}"},
            json=patch,
        )
        resp.raise_for_status()
        return resp.json()

    async def delete_user(self, user_id: str) -> None:
        """Delete an Auth0 user. Raises on any non-2xx response.

        Used by the admin GDPR delete path which expects to roll back the
        Canon DB delete if Auth0 deletion fails. The Management API returns
        204 on success and 404 if the user is already gone — we treat 404
        as success so the caller can complete the rollback chain.
        """
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        token = await self._get_mgmt_token()
        encoded_id = quote(user_id, safe="")
        resp = await self._http.delete(
            f"https://{self._domain}/api/v2/users/{encoded_id}",
            headers={"Authorization": f"Bearer {token}"},
        )
        if resp.status_code == 404:
            return
        resp.raise_for_status()

    async def add_org_member(self, *, org_id: str, user_id: str) -> None:
        """Add a single user to an Auth0 Organization.

        The Management API accepts a batch of user IDs in the body
        (``{"members": [...]}``). We expose a single-user wrapper because
        the admin UI adds one member at a time; the batch form is a trivial
        extension if bulk ever lands.
        """
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        token = await self._get_mgmt_token()
        resp = await self._http.post(
            f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}/members",
            headers={"Authorization": f"Bearer {token}"},
            json={"members": [user_id]},
        )
        # 201 Created on success, 409 if already a member — both are OK
        if resp.status_code == 409:
            return
        resp.raise_for_status()

    async def remove_org_member(self, *, org_id: str, user_id: str) -> None:
        """Remove a single user from an Auth0 Organization.

        Uses the ``DELETE /organizations/{id}/members`` endpoint with the
        same ``{"members": [...]}`` body shape as add. 404 is treated as a
        no-op so the admin endpoint is idempotent across partial failures.
        """
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        token = await self._get_mgmt_token()
        resp = await self._http.request(
            "DELETE",
            f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}/members",
            headers={"Authorization": f"Bearer {token}"},
            json={"members": [user_id]},
        )
        if resp.status_code == 404:
            return
        resp.raise_for_status()

    async def create_invitation(
        self,
        *,
        org_id: str,
        inviter_name: str,
        invitee_email: str,
        client_id: str | None = None,
        connection_id: str | None = None,
        roles: list[str] | None = None,
        ttl_sec: int = 7 * 24 * 3600,
    ) -> dict:
        """Create an Auth0 organization invitation. Returns the full invite record.

        ``client_id`` defaults to the configured Auth0 client. Auth0 requires
        ``inviter`` and ``invitee`` objects in the body and rejects calls
        without them. The returned record contains the ``invitation_url``
        the user receives in the email.
        """
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        token = await self._get_mgmt_token()
        body: dict = {
            "inviter": {"name": inviter_name},
            "invitee": {"email": invitee_email},
            "client_id": client_id or self._client_id,
            "ttl_sec": ttl_sec,
            "send_invitation_email": True,
        }
        if connection_id is not None:
            body["connection_id"] = connection_id
        if roles is not None:
            body["roles"] = roles
        resp = await self._http.post(
            f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}/invitations",
            headers={"Authorization": f"Bearer {token}"},
            json=body,
        )
        resp.raise_for_status()
        return resp.json()

    async def create_password_change_ticket(
        self,
        *,
        user_id: str,
        result_url: str | None = None,
        ttl_sec: int = 24 * 3600,
        mark_email_as_verified: bool = False,
    ) -> dict:
        """Create a password-change ticket. Returns ``{"ticket": <url>}``."""
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        token = await self._get_mgmt_token()
        body: dict = {
            "user_id": user_id,
            "ttl_sec": ttl_sec,
            "mark_email_as_verified": mark_email_as_verified,
        }
        if result_url is not None:
            body["result_url"] = result_url
        resp = await self._http.post(
            f"https://{self._domain}/api/v2/tickets/password-change",
            headers={"Authorization": f"Bearer {token}"},
            json=body,
        )
        resp.raise_for_status()
        return resp.json()

    async def create_email_verification_ticket(
        self,
        *,
        user_id: str,
        result_url: str | None = None,
        ttl_sec: int = 24 * 3600,
    ) -> dict:
        """Create an email-verification ticket. Returns ``{"ticket": <url>}``."""
        if not self._m2m_client_id:
            raise RuntimeError("Auth0 M2M client not configured")
        token = await self._get_mgmt_token()
        body: dict = {
            "user_id": user_id,
            "ttl_sec": ttl_sec,
        }
        if result_url is not None:
            body["result_url"] = result_url
        resp = await self._http.post(
            f"https://{self._domain}/api/v2/tickets/email-verification",
            headers={"Authorization": f"Bearer {token}"},
            json=body,
        )
        resp.raise_for_status()
        return resp.json()

    async def get_org_members(self, org_id: str) -> list[dict]:
        """Get all members of an Auth0 Organization, paginating if needed."""
        if not self._m2m_client_id:
            return []
        token = await self._get_mgmt_token()
        all_members: list[dict] = []
        page = 0
        per_page = 100
        while True:
            resp = await self._http.get(
                f"https://{self._domain}/api/v2/organizations/{quote(org_id, safe='')}/members",
                headers={"Authorization": f"Bearer {token}"},
                params={"per_page": per_page, "page": page},
            )
            if resp.status_code != 200:
                break
            batch = resp.json()
            all_members.extend(batch)
            if len(batch) < per_page:
                break
            page += 1
            if page > 50:  # safety cap: 5000 members max
                break
        return all_members

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def _get_mgmt_token(self) -> str:
        if self._mgmt_token and time.monotonic() < self._mgmt_token_expires:
            return self._mgmt_token
        async with self._mgmt_token_lock:
            # Double-check after acquiring lock
            if self._mgmt_token and time.monotonic() < self._mgmt_token_expires:
                return self._mgmt_token
            resp = await self._http.post(
                f"https://{self._domain}/oauth/token",
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._m2m_client_id,
                    "client_secret": self._m2m_client_secret,
                    "audience": f"https://{self._domain}/api/v2/",
                },
            )
            resp.raise_for_status()
            data = resp.json()
            self._mgmt_token = data["access_token"]
            self._mgmt_token_expires = time.monotonic() + data.get("expires_in", 86400) - 60
            return self._mgmt_token
