"""Integration tests for billing routes and external webhook handlers.

Tests Stripe billing routes and Jira/Linear/Asana webhook signature
verification through the real FastAPI stack.
"""

from __future__ import annotations

import hashlib
import hmac
import json
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.billing.models import BillingCycle, Plan, Subscription, SubscriptionStatus
from canon.main import app

from .conftest import (
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)


def _free_subscription(org_login: str = "test-org") -> Subscription:
    """A Free-tier subscription matching what _auto_enroll_free produces."""
    return Subscription(
        id="1",
        org_login=org_login,
        stripe_customer_id=None,
        stripe_subscription_id=None,
        plan=Plan.FREE,
        billing_cycle=BillingCycle.MONTHLY,
        status=SubscriptionStatus.ACTIVE,
        seat_count=3,
    )


pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _hmac_sha256(payload: bytes, secret: str) -> str:
    """Compute HMAC SHA-256 hex digest."""
    return hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()


# ---------------------------------------------------------------------------
# External Webhooks — Jira
# ---------------------------------------------------------------------------

JIRA_SECRET = "test-jira-secret"
LINEAR_SECRET = "test-linear-secret"
ASANA_SECRET = "test-asana-secret"


@pytest.fixture
async def webhook_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """Client with webhook secrets configured."""
    settings = _base_settings(
        jira_webhook_secret=JIRA_SECRET,
        linear_webhook_secret=LINEAR_SECRET,
        asana_webhook_secret=ASANA_SECRET,
    )
    originals = _set_app_state(settings, github_client=mock_github_client)

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            yield client

    _restore_app_state(originals)


@pytest.fixture
async def unconfigured_webhook_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """Client without webhook secrets (fail-closed mode)."""
    settings = _base_settings()  # No webhook secrets
    originals = _set_app_state(settings, github_client=mock_github_client)

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(transport=transport, base_url="http://test") as client:
            yield client

    _restore_app_state(originals)


class TestJiraWebhook:
    async def test_valid_signature_accepted(self, webhook_client: httpx.AsyncClient):
        payload = json.dumps(
            {
                "webhookEvent": "jira:issue_updated",
                "issue": {
                    "key": "PROJ-42",
                    "fields": {"status": {"statusCategory": {"key": "done"}}},
                },
            }
        ).encode()
        sig = _hmac_sha256(payload, JIRA_SECRET)

        with patch(
            "canon.webhooks.router._process_across_repos", new_callable=AsyncMock
        ) as mock_proc:
            from canon.webhooks.processor import ProcessResult

            mock_proc.return_value = ProcessResult(processed=True)
            resp = await webhook_client.post(
                "/webhooks/jira",
                content=payload,
                headers={"x-hub-signature": sig, "content-type": "application/json"},
            )
        assert resp.status_code == 200

    async def test_invalid_signature_rejected(self, webhook_client: httpx.AsyncClient):
        payload = b'{"webhookEvent": "jira:issue_updated"}'
        resp = await webhook_client.post(
            "/webhooks/jira",
            content=payload,
            headers={"x-hub-signature": "invalid-sig", "content-type": "application/json"},
        )
        assert resp.status_code == 401

    async def test_missing_signature_rejected(self, webhook_client: httpx.AsyncClient):
        resp = await webhook_client.post(
            "/webhooks/jira",
            content=b"{}",
            headers={"content-type": "application/json"},
        )
        assert resp.status_code == 401


class TestLinearWebhook:
    async def test_valid_signature_accepted(self, webhook_client: httpx.AsyncClient):
        payload = json.dumps(
            {
                "action": "update",
                "type": "Issue",
                "data": {
                    "id": "uuid-123",
                    "identifier": "ENG-42",
                    "state": {"type": "completed"},
                },
            }
        ).encode()
        sig = _hmac_sha256(payload, LINEAR_SECRET)

        with patch(
            "canon.webhooks.router._process_across_repos", new_callable=AsyncMock
        ) as mock_proc:
            from canon.webhooks.processor import ProcessResult

            mock_proc.return_value = ProcessResult(processed=True)
            resp = await webhook_client.post(
                "/webhooks/linear",
                content=payload,
                headers={"linear-signature": sig, "content-type": "application/json"},
            )
        assert resp.status_code == 200

    async def test_invalid_signature_rejected(self, webhook_client: httpx.AsyncClient):
        payload = b'{"action": "update", "type": "Issue"}'
        resp = await webhook_client.post(
            "/webhooks/linear",
            content=payload,
            headers={"linear-signature": "bad", "content-type": "application/json"},
        )
        assert resp.status_code == 401


class TestAsanaWebhook:
    async def test_handshake_echoes_secret(self, webhook_client: httpx.AsyncClient):
        """Asana webhook registration handshake echoes X-Hook-Secret."""
        resp = await webhook_client.post(
            "/webhooks/asana",
            content=b"",
            headers={"x-hook-secret": "asana-setup-token-abc"},
        )
        assert resp.status_code == 200
        assert resp.headers.get("x-hook-secret") == "asana-setup-token-abc"

    async def test_invalid_signature_rejected(self, webhook_client: httpx.AsyncClient):
        payload = b'{"events": []}'
        resp = await webhook_client.post(
            "/webhooks/asana",
            content=payload,
            headers={"x-hook-signature": "bad", "content-type": "application/json"},
        )
        assert resp.status_code == 401

    async def test_valid_signature_returns_501(self, webhook_client: httpx.AsyncClient):
        """Asana processing not yet implemented — returns 501."""
        payload = b'{"events": []}'
        sig = _hmac_sha256(payload, ASANA_SECRET)
        resp = await webhook_client.post(
            "/webhooks/asana",
            content=payload,
            headers={"x-hook-signature": sig, "content-type": "application/json"},
        )
        assert resp.status_code == 501


class TestUnconfiguredWebhooks:
    """Endpoints return 503 when secrets are not configured."""

    async def test_jira_returns_503(self, unconfigured_webhook_client: httpx.AsyncClient):
        resp = await unconfigured_webhook_client.post(
            "/webhooks/jira", content=b"{}", headers={"content-type": "application/json"}
        )
        assert resp.status_code == 503

    async def test_linear_returns_503(self, unconfigured_webhook_client: httpx.AsyncClient):
        resp = await unconfigured_webhook_client.post(
            "/webhooks/linear", content=b"{}", headers={"content-type": "application/json"}
        )
        assert resp.status_code == 503

    async def test_asana_returns_503(self, unconfigured_webhook_client: httpx.AsyncClient):
        resp = await unconfigured_webhook_client.post(
            "/webhooks/asana", content=b"{}", headers={"content-type": "application/json"}
        )
        assert resp.status_code == 503


# ---------------------------------------------------------------------------
# Billing Routes (Stripe)
# ---------------------------------------------------------------------------


@pytest.fixture
async def billing_client(mock_github_client: MagicMock) -> httpx.AsyncClient:
    """Authenticated client with billing service configured. Default
    subscription is Free (matches the new always-real-Subscription contract
    enforced by BillingService.get_subscription post-PR #782)."""
    billing_service = AsyncMock()
    billing_service.get_subscription = AsyncMock(return_value=_free_subscription())

    stripe_client = MagicMock()

    settings = _base_settings(
        stripe_secret_key="sk_test_xxx",
        stripe_publishable_key="pk_test_xxx",
        stripe_webhook_secret="whsec_test",
        stripe_starter_monthly_price_id="price_m",
        stripe_starter_annual_price_id="price_a",
        stripe_pro_monthly_price_id="price_pm",
        stripe_pro_annual_price_id="price_pa",
        platform_url="https://app.canonhq.co",
    )
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        billing_service=billing_service,
        stripe_client=stripe_client,
    )

    cookie = make_session_cookie(_session_data_for_user())

    with (
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
    ):
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        async with httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
            cookies={"session": cookie},
        ) as client:
            yield client

    _restore_app_state(originals)


class TestBillingRoutes:
    """Billing routes live at /app/{org}/api/billing/*."""

    async def test_subscription_returns_current_state(self, billing_client: httpx.AsyncClient):
        resp = await billing_client.get("/app/test-org/api/billing/subscription")
        # Returns subscription state (null subscription = no active plan)
        assert resp.status_code == 200

    async def test_checkout_requires_plan(self, billing_client: httpx.AsyncClient):
        resp = await billing_client.post(
            "/app/test-org/api/checkout",
            json={},
        )
        # Should fail validation (missing required fields)
        assert resp.status_code == 422

    async def test_portal_free_org_returns_409(self, billing_client: httpx.AsyncClient):
        """Free orgs have no Stripe customer; portal returns 409 with an
        upgrade message (was 404 pre-#782)."""
        # billing_client default fixture already returns a Free subscription.
        resp = await billing_client.post("/app/test-org/api/billing/portal")
        assert resp.status_code == 409
        assert "error" in resp.json()

    async def test_billing_without_stripe_returns_503(self, mock_github_client: MagicMock):
        """Billing endpoints return 503 when Stripe is not configured."""
        settings = _base_settings(platform_url="https://app.canonhq.co")
        originals = _set_app_state(settings, github_client=mock_github_client)

        cookie = make_session_cookie(_session_data_for_user())
        with (
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
        ):
            from httpx import ASGITransport

            transport = ASGITransport(app=app, raise_app_exceptions=False)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://test",
                cookies={"session": cookie},
            ) as client:
                resp = await client.get("/app/test-org/api/billing/subscription")
                assert resp.status_code == 503

        _restore_app_state(originals)
