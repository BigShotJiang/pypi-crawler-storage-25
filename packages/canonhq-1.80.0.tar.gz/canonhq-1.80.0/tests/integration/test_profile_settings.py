"""Integration tests for profile and settings routes.

Tests /app/{org}/api/profile and integration/connection settings
through the real FastAPI stack with auth.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from httpx import ASGITransport

from canon.main import app

from .conftest import (
    SEED_ORG,
    _base_settings,
    _restore_app_state,
    _session_data_for_user,
    _set_app_state,
    make_session_cookie,
)

pytestmark = pytest.mark.integration


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


async def _make_profile_client(
    mock_github_client: MagicMock,
    *,
    user_store: AsyncMock | None = None,
    connection_store: AsyncMock | None = None,
    integration_store: AsyncMock | None = None,
    session_store: AsyncMock | None = None,
    extra_cookies: dict[str, str] | None = None,
):
    settings = _base_settings(
        oidc_issuer="https://idp.example.com",
        oidc_client_id="test-client",
        oidc_client_secret="test-oidc-secret",
        web_org="",
    )
    originals = _set_app_state(
        settings,
        github_client=mock_github_client,
        oidc_provider=MagicMock(),
        user_store=user_store,
        session_store=session_store,
    )
    if connection_store is not None:
        app.state.connection_store = connection_store
    if integration_store is not None:
        app.state.integration_store = integration_store

    cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))

    patches = [
        patch("canon.main.settings", settings),
        patch("canon.main._get_client", return_value=mock_github_client),
        patch("canon.main.analytics"),
        patch("canon.web.routes._get_spa_html", return_value=None),
    ]
    for p in patches:
        p.start()

    cookies = {"session": cookie}
    if extra_cookies:
        cookies.update(extra_cookies)
    transport = ASGITransport(app=app, raise_app_exceptions=False)
    client = httpx.AsyncClient(
        transport=transport,
        base_url="http://test",
        cookies=cookies,
    )
    return client, originals, patches


async def _cleanup(client, originals, patches):
    await client.aclose()
    for p in patches:
        p.stop()
    _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Profile route
# ---------------------------------------------------------------------------


class TestProfileRoute:
    async def test_profile_returns_user_info(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/profile returns user profile."""
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value=None)

        client, originals, patches = await _make_profile_client(
            mock_github_client, user_store=user_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile")
            assert resp.status_code == 200
            data = resp.json()
            assert "email" in data
            assert "permissions" in data
        finally:
            await _cleanup(client, originals, patches)

    async def test_profile_includes_last_login(self, mock_github_client: MagicMock):
        """Profile includes last_login_at when available in DB."""
        from datetime import UTC, datetime

        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(
            return_value={
                "sub": "test-user-1",
                "last_login_at": datetime(2026, 4, 1, tzinfo=UTC),
            }
        )

        client, originals, patches = await _make_profile_client(
            mock_github_client, user_store=user_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile")
            assert resp.status_code == 200
            data = resp.json()
            assert data.get("last_login_at") is not None
        finally:
            await _cleanup(client, originals, patches)

    async def test_profile_without_user_store(self, mock_github_client: MagicMock):
        """Profile works when user_store is None."""
        client, originals, patches = await _make_profile_client(mock_github_client, user_store=None)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Security: sessions
# ---------------------------------------------------------------------------


class TestSecuritySessions:
    """`GET/DELETE/POST /app/{org}/api/profile/security/sessions[…]`."""

    @staticmethod
    def _session_row(
        sid: str = "sid-1", device: str = "Chrome on macOS", user_id: int = 42
    ) -> dict:
        from datetime import UTC, datetime, timedelta

        now = datetime.now(UTC)
        return {
            "id": sid,
            "user_id": user_id,
            "device_label": device,
            "created_at": now - timedelta(days=1),
            "last_used_at": now,
            "expires_at": now + timedelta(days=30),
            "org_login": SEED_ORG,
        }

    async def _make(self, mock_github_client, *, sessions=None, current_sid=None):
        """`current_sid` simulates the (rare) case where the refresh cookie is present.

        In production the `sw_refresh` cookie is scoped `path=/auth` so it does
        not reach this endpoint — `_resolve_current_session_id` returns None
        and `is_current` is False for every row. The `current_sid` parameter
        lets a test simulate a future code path (or a non-browser caller)
        where the cookie *is* presented.
        """
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value={"id": 42, "sub": "test-user-1"})

        session_store = AsyncMock()
        session_store.list_sessions = AsyncMock(return_value=sessions or [])
        session_store.revoke_session = AsyncMock(return_value=True)
        session_store.revoke_all_sessions = AsyncMock(return_value=2)

        if current_sid is not None:
            session_store.get_session_by_refresh_hash = AsyncMock(
                return_value={"id": current_sid, "user_id": 42}
            )
        else:
            session_store.get_session_by_refresh_hash = AsyncMock(return_value=None)

        extra = {"sw_refresh": "fake-refresh-token"} if current_sid else None
        return await _make_profile_client(
            mock_github_client,
            user_store=user_store,
            session_store=session_store,
            extra_cookies=extra,
        ), session_store

    async def test_list_returns_sessions(self, mock_github_client: MagicMock):
        sessions = [
            self._session_row(sid="sid-1", device="Chrome"),
            self._session_row(sid="sid-2", device="Firefox"),
        ]
        (client, originals, patches), _ = await self._make(
            mock_github_client, sessions=sessions, current_sid="sid-1"
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile/security/sessions")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data["sessions"]) == 2
            current = next(s for s in data["sessions"] if s["id"] == "sid-1")
            other = next(s for s in data["sessions"] if s["id"] == "sid-2")
            assert current["is_current"] is True
            assert other["is_current"] is False
            assert current["device_label"] == "Chrome"
        finally:
            await _cleanup(client, originals, patches)

    async def test_list_without_refresh_cookie_marks_none_current(
        self, mock_github_client: MagicMock
    ):
        """API-key / JWT auth has no current session — `is_current` is false everywhere."""
        sessions = [self._session_row(sid="sid-1")]
        (client, originals, patches), _ = await self._make(
            mock_github_client, sessions=sessions, current_sid=None
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile/security/sessions")
            assert resp.status_code == 200
            assert resp.json()["sessions"][0]["is_current"] is False
        finally:
            await _cleanup(client, originals, patches)

    async def test_revoke_session_calls_store(self, mock_github_client: MagicMock):
        (client, originals, patches), session_store = await self._make(mock_github_client)
        try:
            resp = await client.delete(f"/app/{SEED_ORG}/api/profile/security/sessions/sid-1")
            assert resp.status_code == 204
            session_store.revoke_session.assert_awaited_once_with(session_id="sid-1", user_id=42)
        finally:
            await _cleanup(client, originals, patches)

    async def test_revoke_unknown_session_returns_404(self, mock_github_client: MagicMock):
        """Cross-user revoke or unknown id collapses to 404 (no enumeration disclosure)."""
        (client, originals, patches), session_store = await self._make(mock_github_client)
        session_store.revoke_session = AsyncMock(return_value=False)
        try:
            resp = await client.delete(f"/app/{SEED_ORG}/api/profile/security/sessions/not-mine")
            assert resp.status_code == 404
        finally:
            await _cleanup(client, originals, patches)

    async def test_revoke_others_returns_count(self, mock_github_client: MagicMock):
        (client, originals, patches), session_store = await self._make(
            mock_github_client, current_sid="sid-1"
        )
        try:
            resp = await client.post(f"/app/{SEED_ORG}/api/profile/security/sessions/revoke-others")
            assert resp.status_code == 200
            assert resp.json() == {"revoked": 2}
            session_store.revoke_all_sessions.assert_awaited_once_with(
                user_id=42, except_session_id="sid-1"
            )
        finally:
            await _cleanup(client, originals, patches)

    async def test_revoke_others_without_current_returns_409(self, mock_github_client: MagicMock):
        """No `sw_refresh` cookie → refuse with 409 instead of nuking every
        row. Browser callers (whose Starlette session isn't in the
        ``sessions`` table) should revoke CLI rows individually."""
        (client, originals, patches), session_store = await self._make(
            mock_github_client, current_sid=None
        )
        try:
            resp = await client.post(f"/app/{SEED_ORG}/api/profile/security/sessions/revoke-others")
            assert resp.status_code == 409
            session_store.revoke_all_sessions.assert_not_awaited()
        finally:
            await _cleanup(client, originals, patches)

    async def test_revoke_emits_audit_event(self, mock_github_client: MagicMock):
        audit_store = AsyncMock()
        audit_store.log = AsyncMock()
        (client, originals, patches), _ = await self._make(mock_github_client)
        app.state.audit_store = audit_store
        try:
            resp = await client.delete(f"/app/{SEED_ORG}/api/profile/security/sessions/sid-1")
            assert resp.status_code == 204
            audit_store.log.assert_awaited_once()
            call_kwargs = audit_store.log.await_args.kwargs
            assert call_kwargs["event_type"] == "profile.session.revoked"
            assert call_kwargs["resource_id"] == "sid-1"
            assert call_kwargs["actor_sub"] == "test-user-1"
        finally:
            app.state.audit_store = None
            await _cleanup(client, originals, patches)

    async def test_revoke_others_emits_audit_event(self, mock_github_client: MagicMock):
        audit_store = AsyncMock()
        audit_store.log = AsyncMock()
        (client, originals, patches), _ = await self._make(mock_github_client, current_sid="sid-1")
        app.state.audit_store = audit_store
        try:
            resp = await client.post(f"/app/{SEED_ORG}/api/profile/security/sessions/revoke-others")
            assert resp.status_code == 200
            audit_store.log.assert_awaited_once()
            call_kwargs = audit_store.log.await_args.kwargs
            assert call_kwargs["event_type"] == "profile.session.revoked_all"
            assert call_kwargs["detail"]["revoked_count"] == 2
        finally:
            app.state.audit_store = None
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Notifications + Preferences
# ---------------------------------------------------------------------------


class TestNotifications:
    @staticmethod
    def _make_prefs_store(initial: dict | None = None) -> AsyncMock:
        from datetime import UTC, datetime

        defaults = {
            "user_id": 42,
            "org_login": SEED_ORG,
            "slack_dm_enabled": True,
            "slack_dm_pr_comments": True,
            "slack_dm_spec_drift": True,
            "email_digest_cadence": "weekly",
            "email_pr_comments": False,
            "theme": "system",
            "timezone": "",
            "relative_time": True,
            "updated_at": datetime.now(UTC),
        }
        if initial:
            defaults.update(initial)
        store = AsyncMock()
        store.get = AsyncMock(return_value=defaults)
        store.update = AsyncMock(return_value=defaults)
        return store

    async def _make(self, mock_github_client, prefs_store=None):
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value={"id": 42, "sub": "test-user-1"})
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="x",
            oidc_client_secret="y",
            web_org="",
        )
        originals = _set_app_state(
            settings, github_client=mock_github_client, user_store=user_store
        )
        app.state.user_preferences_store = prefs_store or self._make_prefs_store()
        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))
        patches = [
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ]
        for p in patches:
            p.start()
        client = httpx.AsyncClient(
            transport=ASGITransport(app=app, raise_app_exceptions=False),
            base_url="http://test",
            cookies={"session": cookie},
        )
        return client, originals, patches

    async def test_get_returns_notification_prefs(self, mock_github_client: MagicMock):
        client, originals, patches = await self._make(mock_github_client)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile/notifications")
            assert resp.status_code == 200
            data = resp.json()
            assert data["slack_dm_enabled"] is True
            assert data["email_digest_cadence"] == "weekly"
        finally:
            app.state.user_preferences_store = None
            await _cleanup(client, originals, patches)

    async def test_patch_persists(self, mock_github_client: MagicMock):
        prefs = self._make_prefs_store({"slack_dm_enabled": False})
        client, originals, patches = await self._make(mock_github_client, prefs)
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/notifications",
                json={"slack_dm_enabled": False, "email_digest_cadence": "daily"},
            )
            assert resp.status_code == 200
            prefs.update.assert_awaited_once()
            patch_arg = prefs.update.await_args.kwargs["patch"]
            assert patch_arg == {"slack_dm_enabled": False, "email_digest_cadence": "daily"}
        finally:
            app.state.user_preferences_store = None
            await _cleanup(client, originals, patches)

    async def test_patch_rejects_invalid_cadence(self, mock_github_client: MagicMock):
        client, originals, patches = await self._make(mock_github_client)
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/notifications",
                json={"email_digest_cadence": "yearly"},
            )
            assert resp.status_code == 422
        finally:
            app.state.user_preferences_store = None
            await _cleanup(client, originals, patches)


class TestPreferences:
    async def _make(self, mock_github_client):
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value={"id": 42, "sub": "test-user-1"})
        prefs = TestNotifications._make_prefs_store()
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="x",
            oidc_client_secret="y",
            web_org="",
        )
        originals = _set_app_state(
            settings, github_client=mock_github_client, user_store=user_store
        )
        app.state.user_preferences_store = prefs
        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))
        patches = [
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ]
        for p in patches:
            p.start()
        client = httpx.AsyncClient(
            transport=ASGITransport(app=app, raise_app_exceptions=False),
            base_url="http://test",
            cookies={"session": cookie},
        )
        return client, originals, patches, prefs

    async def test_get_returns_preferences(self, mock_github_client: MagicMock):
        client, originals, patches, _ = await self._make(mock_github_client)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile/preferences")
            assert resp.status_code == 200
            data = resp.json()
            assert data["theme"] == "system"
            assert data["relative_time"] is True
        finally:
            app.state.user_preferences_store = None
            await _cleanup(client, originals, patches)

    async def test_patch_accepts_valid_theme(self, mock_github_client: MagicMock):
        client, originals, patches, prefs = await self._make(mock_github_client)
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/preferences",
                json={"theme": "dark"},
            )
            assert resp.status_code == 200
            prefs.update.assert_awaited_once()
        finally:
            app.state.user_preferences_store = None
            await _cleanup(client, originals, patches)

    async def test_patch_rejects_invalid_theme(self, mock_github_client: MagicMock):
        client, originals, patches, _ = await self._make(mock_github_client)
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/preferences",
                json={"theme": "neon"},
            )
            assert resp.status_code == 422
        finally:
            app.state.user_preferences_store = None
            await _cleanup(client, originals, patches)

    async def test_patch_rejects_invalid_timezone(self, mock_github_client: MagicMock):
        client, originals, patches, _ = await self._make(mock_github_client)
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/preferences",
                json={"timezone": "Mars/Phobos"},
            )
            assert resp.status_code == 422
        finally:
            app.state.user_preferences_store = None
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Security: self-serve password reset
# ---------------------------------------------------------------------------


class TestSecurityPasswordReset:
    """`POST /app/{org}/api/profile/security/password-reset`."""

    async def _make(self, mock_github_client, *, provider=None, with_audit=True):
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value={"id": 42, "sub": "test-user-1"})

        if provider is None:
            provider = MagicMock()
            provider.create_password_change_ticket = AsyncMock(
                return_value={"ticket": "https://canon.us.auth0.com/lo/reset?token=abc"}
            )

        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=provider,
            user_store=user_store,
        )
        if with_audit:
            audit_store = AsyncMock()
            audit_store.log = AsyncMock()
            app.state.audit_store = audit_store
        else:
            audit_store = None

        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))
        patches = [
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ]
        for p in patches:
            p.start()
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        client = httpx.AsyncClient(
            transport=transport, base_url="http://test", cookies={"session": cookie}
        )
        return client, originals, patches, provider, audit_store

    async def test_returns_email_sent_in_production(self, mock_github_client: MagicMock):
        client, originals, patches, provider, audit_store = await self._make(mock_github_client)
        # Default _base_settings carries environment="development"; override
        # for this scenario to verify dev-only ticket-url echo is suppressed.
        app.state.settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
            environment="production",
        )
        try:
            resp = await client.post(f"/app/{SEED_ORG}/api/profile/security/password-reset")
            assert resp.status_code == 200
            data = resp.json()
            assert data["email_sent"] is True
            assert "ticket_url" not in data
            provider.create_password_change_ticket.assert_awaited_once_with(user_id="test-user-1")
            audit_store.log.assert_awaited_once()
            assert audit_store.log.await_args.kwargs["event_type"] == "profile.password_reset"
        finally:
            app.state.audit_store = None
            await client.aclose()
            for p in patches:
                p.stop()
            _restore_app_state(originals)

    async def test_returns_ticket_url_in_dev_mode(self, mock_github_client: MagicMock):
        client, originals, patches, _, _ = await self._make(mock_github_client)
        app.state.settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
            environment="development",
        )
        try:
            resp = await client.post(f"/app/{SEED_ORG}/api/profile/security/password-reset")
            assert resp.status_code == 200
            data = resp.json()
            assert data["email_sent"] is True
            assert data["ticket_url"].startswith("https://")
        finally:
            app.state.audit_store = None
            await client.aclose()
            for p in patches:
                p.stop()
            _restore_app_state(originals)

    async def test_returns_501_when_provider_unsupported(self, mock_github_client: MagicMock):
        """Generic OIDC providers (Keycloak, Zitadel, …) don't expose the
        Auth0 Management password-change-ticket flow."""
        provider = MagicMock(spec=["get_logout_url"])  # no create_password_change_ticket
        client, originals, patches, _, _ = await self._make(mock_github_client, provider=provider)
        try:
            resp = await client.post(f"/app/{SEED_ORG}/api/profile/security/password-reset")
            assert resp.status_code == 501
            assert "not supported" in resp.json()["detail"].lower()
        finally:
            app.state.audit_store = None
            await client.aclose()
            for p in patches:
                p.stop()
            _restore_app_state(originals)

    async def test_502_when_provider_errors(self, mock_github_client: MagicMock):
        provider = MagicMock()
        provider.create_password_change_ticket = AsyncMock(side_effect=RuntimeError("boom"))
        client, originals, patches, _, _ = await self._make(mock_github_client, provider=provider)
        try:
            resp = await client.post(f"/app/{SEED_ORG}/api/profile/security/password-reset")
            assert resp.status_code == 502
        finally:
            app.state.audit_store = None
            await client.aclose()
            for p in patches:
                p.stop()
            _restore_app_state(originals)


# ---------------------------------------------------------------------------
# Account: editable identity
# ---------------------------------------------------------------------------


class TestAccount:
    async def _make(self, mock_github_client, *, provider=None):
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value={"id": 42, "sub": "test-user-1"})
        user_store.upsert_user = AsyncMock(return_value={"id": 42})
        if provider is None:
            provider = MagicMock()
            provider.update_user = AsyncMock(return_value={"email_verified": True})
        return await _make_profile_client(mock_github_client, user_store=user_store), provider

    async def test_get_returns_identity(self, mock_github_client: MagicMock):
        (client, originals, patches), provider = await self._make(mock_github_client)
        app.state.oidc_provider = provider
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile/account")
            assert resp.status_code == 200
            assert resp.json()["email"] == "user@test.com"
        finally:
            await _cleanup(client, originals, patches)

    async def test_patch_updates_name(self, mock_github_client: MagicMock):
        (client, originals, patches), provider = await self._make(mock_github_client)
        app.state.oidc_provider = provider
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/account",
                json={"name": "New Name"},
            )
            assert resp.status_code == 200
            provider.update_user.assert_awaited_once_with("test-user-1", {"name": "New Name"})
        finally:
            await _cleanup(client, originals, patches)

    async def test_patch_rejects_non_https_picture(self, mock_github_client: MagicMock):
        (client, originals, patches), provider = await self._make(mock_github_client)
        app.state.oidc_provider = provider
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/account",
                json={"picture": "http://insecure.example/avatar.png"},
            )
            assert resp.status_code == 422
        finally:
            await _cleanup(client, originals, patches)

    async def test_patch_501_when_provider_unsupported(self, mock_github_client: MagicMock):
        provider = MagicMock(spec=["get_logout_url"])  # no update_user
        (client, originals, patches), _ = await self._make(mock_github_client, provider=provider)
        app.state.oidc_provider = provider
        try:
            resp = await client.patch(
                f"/app/{SEED_ORG}/api/profile/account",
                json={"name": "X"},
            )
            assert resp.status_code == 501
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Security: user-scoped API keys
# ---------------------------------------------------------------------------


class TestProfileApiKeys:
    @staticmethod
    def _key_row(key_id: int = 1, label: str = "laptop"):
        from datetime import UTC, datetime

        now = datetime.now(UTC)
        return {
            "id": key_id,
            "label": label,
            "org_login": SEED_ORG,
            "scopes": ["specs:read"],
            "created_at": now,
            "expires_at": None,
            "revoked_at": None,
            "last_used_at": None,
        }

    async def _make(
        self, mock_github_client, *, list_return=None, create_return=None, revoke_return=True
    ):
        user_store = AsyncMock()
        user_store.get_user_by_sub = AsyncMock(return_value={"id": 42, "sub": "test-user-1"})
        user_store.list_api_keys = AsyncMock(return_value=list_return or [])
        if create_return is None:
            create_return = ("sw_rawkey", self._key_row())
        user_store.create_api_key = AsyncMock(return_value=create_return)
        user_store.revoke_api_key = AsyncMock(return_value=revoke_return)
        return await _make_profile_client(mock_github_client, user_store=user_store)

    async def test_list_returns_keys(self, mock_github_client: MagicMock):
        client, originals, patches = await self._make(
            mock_github_client, list_return=[self._key_row(1, "laptop"), self._key_row(2, "ci")]
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/profile/security/api-keys")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data["keys"]) == 2
            assert data["keys"][0]["label"] == "laptop"
        finally:
            await _cleanup(client, originals, patches)

    async def test_create_returns_raw_key_once(self, mock_github_client: MagicMock):
        client, originals, patches = await self._make(mock_github_client)
        try:
            resp = await client.post(
                f"/app/{SEED_ORG}/api/profile/security/api-keys",
                json={"label": "laptop", "scopes": ["specs:read"]},
            )
            assert resp.status_code == 201
            assert resp.json()["key"] == "sw_rawkey"
        finally:
            await _cleanup(client, originals, patches)

    async def test_create_rejects_scope_user_lacks(self, mock_github_client: MagicMock):
        """User cannot mint a key with a scope they don't currently hold."""
        client, originals, patches = await self._make(mock_github_client)
        try:
            resp = await client.post(
                f"/app/{SEED_ORG}/api/profile/security/api-keys",
                json={"label": "bad", "scopes": ["does:not:exist"]},
            )
            assert resp.status_code == 400
        finally:
            await _cleanup(client, originals, patches)

    async def test_revoke_returns_204(self, mock_github_client: MagicMock):
        client, originals, patches = await self._make(mock_github_client)
        try:
            resp = await client.delete(f"/app/{SEED_ORG}/api/profile/security/api-keys/1")
            assert resp.status_code == 204
        finally:
            await _cleanup(client, originals, patches)

    async def test_revoke_unknown_returns_404(self, mock_github_client: MagicMock):
        client, originals, patches = await self._make(mock_github_client, revoke_return=False)
        try:
            resp = await client.delete(f"/app/{SEED_ORG}/api/profile/security/api-keys/999")
            assert resp.status_code == 404
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Connection settings
# ---------------------------------------------------------------------------


class TestConnectionSettings:
    async def test_list_connections_returns_200(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/settings/connections returns connections."""
        connection_store = AsyncMock()
        connection_store.list_connections = AsyncMock(return_value=[])

        client, originals, patches = await _make_profile_client(
            mock_github_client, connection_store=connection_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/connections")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)

    async def test_connections_without_store_returns_empty(self, mock_github_client: MagicMock):
        """Connections endpoint returns empty list when store is None.

        This is intentional: connection_store is only initialized when
        byok_encryption_key is set. Empty list = feature not configured.
        """
        client, originals, patches = await _make_profile_client(
            mock_github_client, connection_store=None
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/connections")
            assert resp.status_code == 200
            assert resp.json() == {"connections": []}
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Integration settings
# ---------------------------------------------------------------------------


class TestIntegrationSettings:
    async def test_list_integrations_returns_200(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/settings/integrations returns integrations."""
        integration_store = AsyncMock()
        integration_store.list_integrations = AsyncMock(return_value=[])

        client, originals, patches = await _make_profile_client(
            mock_github_client, integration_store=integration_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/integrations")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)

    async def test_integration_summary_returns_200(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/settings/integrations/summary returns summary."""
        integration_store = AsyncMock()
        integration_store.list_integrations = AsyncMock(return_value=[])
        integration_store.get_summary = AsyncMock(
            return_value={"total": 0, "connected": 0, "needs_attention": 0}
        )

        client, originals, patches = await _make_profile_client(
            mock_github_client, integration_store=integration_store
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/settings/integrations/summary")
            assert resp.status_code == 200
        finally:
            await _cleanup(client, originals, patches)


# ---------------------------------------------------------------------------
# Session API (SPA bootstrap data)
# ---------------------------------------------------------------------------


class TestSessionApi:
    async def test_session_api_returns_user_data(self, mock_github_client: MagicMock):
        """GET /app/{org}/api/session returns session bootstrap data for SPA."""
        client, originals, patches = await _make_profile_client(mock_github_client)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/session")
            assert resp.status_code == 200
            data = resp.json()
            assert "user" in data
            assert "permissions" in data
        finally:
            await _cleanup(client, originals, patches)

    async def test_session_api_exposes_feature_flags(self, mock_github_client: MagicMock):
        """Session dict carries feature_flags so the SPA can gate UI."""
        client, originals, patches = await _make_profile_client(mock_github_client)
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/session")
            data = resp.json()
            assert "feature_flags" in data
            # Default profile hub is off; tab shell stays single-card until flipped.
            assert data["feature_flags"]["profile_hub_enabled"] is False
        finally:
            await _cleanup(client, originals, patches)

    async def test_session_api_reflects_profile_hub_flag(self, mock_github_client: MagicMock):
        """When profile_hub_enabled is set, the flag flows to the SPA."""
        settings = _base_settings(
            oidc_issuer="https://idp.example.com",
            oidc_client_id="test-client",
            oidc_client_secret="test-oidc-secret",
            web_org="",
            profile_hub_enabled=True,
        )
        originals = _set_app_state(
            settings,
            github_client=mock_github_client,
            oidc_provider=MagicMock(),
        )
        cookie = make_session_cookie(_session_data_for_user(org_login=SEED_ORG))
        patches = [
            patch("canon.main.settings", settings),
            patch("canon.main._get_client", return_value=mock_github_client),
            patch("canon.main.analytics"),
            patch("canon.web.routes._get_spa_html", return_value=None),
        ]
        for p in patches:
            p.start()
        transport = ASGITransport(app=app, raise_app_exceptions=False)
        client = httpx.AsyncClient(
            transport=transport,
            base_url="http://test",
            cookies={"session": cookie},
        )
        try:
            resp = await client.get(f"/app/{SEED_ORG}/api/session")
            assert resp.status_code == 200
            assert resp.json()["feature_flags"]["profile_hub_enabled"] is True
        finally:
            await client.aclose()
            for p in patches:
                p.stop()
            _restore_app_state(originals)
