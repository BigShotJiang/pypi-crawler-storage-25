"""Tests for billing API routes with mocked dependencies."""

from __future__ import annotations

import base64
import os
from unittest.mock import AsyncMock, MagicMock, patch

import anthropic as anthropic_sdk
import pytest
import stripe as stripe_mod
from httpx import ASGITransport, AsyncClient

from canon.auth.models import CurrentUser
from canon.auth.permissions import Permission
from canon.billing.models import (
    MIN_SEATS,
    BillingCycle,
    Plan,
    Subscription,
    SubscriptionStatus,
)
from canon.main import app
from canon.settings import Settings


def _test_user(org_login: str = "test-org") -> CurrentUser:
    return CurrentUser(
        sub="user-1",
        email="user@test.com",
        name="Test User",
        org_login=org_login,
        permissions=frozenset(Permission),
        auth_method="session",
    )


def _make_subscription(**overrides) -> Subscription:
    defaults = dict(
        id="1",
        org_login="test-org",
        stripe_customer_id="cus_123",
        stripe_subscription_id="sub_456",
        plan=Plan.PRO,
        billing_cycle=BillingCycle.MONTHLY,
        status=SubscriptionStatus.ACTIVE,
    )
    defaults.update(overrides)
    # Free orgs are DB-only — the Subscription validator rejects Stripe
    # IDs on Free, so force them null. Callers explicitly testing the
    # rejection should construct Subscription directly, not via this helper.
    if defaults.get("plan") in (Plan.FREE, "free"):
        defaults["stripe_customer_id"] = None
        defaults["stripe_subscription_id"] = None
        defaults.setdefault("seat_count", MIN_SEATS)
    return Subscription(**defaults)


@pytest.fixture(autouse=True)
def _setup():
    """Set up app state with mocked billing dependencies."""
    app.state.settings = Settings(
        platform_url="https://app.canonhq.co",
        stripe_secret_key="sk_test_xxx",
        stripe_publishable_key="pk_test_xxx",
        stripe_webhook_secret="whsec_test",
        stripe_starter_monthly_price_id="price_starter_m",
        stripe_starter_annual_price_id="price_starter_a",
        stripe_pro_monthly_price_id="price_pro_m",
        stripe_pro_annual_price_id="price_pro_a",
        byok_encryption_key=base64.b64encode(os.urandom(32)).decode(),
    )
    app.state.billing_service = AsyncMock()
    app.state.stripe_client = MagicMock()
    app.state.cache = MagicMock()
    app.state.github_client = MagicMock()
    app.state.db_pool = None
    app.state.user_store = None
    app.state.registry = None


@pytest.fixture
def client():
    return AsyncClient(
        transport=ASGITransport(app=app), base_url="http://test", follow_redirects=False
    )


ORG = "test-org"
_PREFIX = f"/app/{ORG}/api"


def _patch_auth(user: CurrentUser | None = None):
    """Return a patch context manager that bypasses auth and returns the given user."""
    target_user = user or _test_user()
    return patch("canon.auth.deps.get_current_user", return_value=target_user)


class TestCreateCheckout:
    async def test_successful_checkout_new_customer(self, client: AsyncClient):
        # Free org upgrading via checkout — no existing Stripe customer yet.
        free_sub = _make_subscription(
            plan="free", stripe_customer_id=None, stripe_subscription_id=None
        )
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)
        app.state.stripe_client.get_price_id = MagicMock(return_value="price_pro_m")

        mock_session = MagicMock()
        mock_session.url = "https://checkout.stripe.com/session/abc"
        app.state.stripe_client.create_checkout_session = MagicMock(return_value=mock_session)

        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.return_value = mock_session
            resp = await client.post(
                f"{_PREFIX}/checkout",
                json={
                    "plan": "pro",
                    "billing_cycle": "monthly",
                    "success_url": "https://app.canonhq.co/success",
                    "cancel_url": "https://app.canonhq.co/cancel",
                },
            )

        assert resp.status_code == 200
        data = resp.json()
        assert "checkout_url" in data

    async def test_checkout_existing_customer(self, client: AsyncClient):
        sub = _make_subscription()
        app.state.billing_service.get_subscription = AsyncMock(return_value=sub)
        app.state.stripe_client.get_price_id = MagicMock(return_value="price_pro_m")

        mock_session = MagicMock()
        mock_session.url = "https://checkout.stripe.com/session/abc"

        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.return_value = mock_session
            resp = await client.post(
                f"{_PREFIX}/checkout",
                json={
                    "plan": "pro",
                    "billing_cycle": "monthly",
                    "success_url": "https://app.canonhq.co/success",
                    "cancel_url": "https://app.canonhq.co/cancel",
                },
            )

        assert resp.status_code == 200

    async def test_checkout_enterprise_rejected(self, client: AsyncClient):
        """Enterprise plan should be rejected by the Pydantic model validator."""
        with _patch_auth():
            resp = await client.post(
                f"{_PREFIX}/checkout",
                json={
                    "plan": "enterprise",
                    "billing_cycle": "monthly",
                    "success_url": "https://app.canonhq.co/success",
                    "cancel_url": "https://app.canonhq.co/cancel",
                },
            )
        assert resp.status_code == 422  # Pydantic validation error

    async def test_checkout_invalid_price_returns_400(self, client: AsyncClient):
        free_sub = _make_subscription(
            plan="free", stripe_customer_id=None, stripe_subscription_id=None
        )
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)
        app.state.stripe_client.get_price_id = MagicMock(
            side_effect=ValueError("No Stripe Price configured")
        )

        with _patch_auth():
            resp = await client.post(
                f"{_PREFIX}/checkout",
                json={
                    "plan": "starter",
                    "billing_cycle": "monthly",
                    "success_url": "https://app.canonhq.co/success",
                    "cancel_url": "https://app.canonhq.co/cancel",
                },
            )

        assert resp.status_code == 400
        assert "error" in resp.json()

    async def test_checkout_rejects_when_platform_url_unset(self, client: AsyncClient):
        app.state.settings.platform_url = ""
        free_sub = _make_subscription(
            plan="free", stripe_customer_id=None, stripe_subscription_id=None
        )
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)
        app.state.stripe_client.get_price_id = MagicMock(return_value="price_pro_m")

        with _patch_auth():
            resp = await client.post(
                f"{_PREFIX}/checkout",
                json={
                    "plan": "pro",
                    "billing_cycle": "monthly",
                    "success_url": "https://evil.example.com/steal",
                    "cancel_url": "https://evil.example.com/steal",
                },
            )

        assert resp.status_code == 500
        assert "configuration" in resp.json()["error"].lower()

    async def test_checkout_stripe_error_returns_502(self, client: AsyncClient):
        free_sub = _make_subscription(
            plan="free", stripe_customer_id=None, stripe_subscription_id=None
        )
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)
        app.state.stripe_client.get_price_id = MagicMock(return_value="price_starter_m")

        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.side_effect = stripe_mod.StripeError("connection failed")
            resp = await client.post(
                f"{_PREFIX}/checkout",
                json={
                    "plan": "starter",
                    "billing_cycle": "monthly",
                    "success_url": "https://app.canonhq.co/success",
                    "cancel_url": "https://app.canonhq.co/cancel",
                },
            )

        assert resp.status_code == 502
        assert "error" in resp.json()


class TestBillingPortal:
    async def test_portal_success(self, client: AsyncClient):
        sub = _make_subscription()
        app.state.billing_service.get_subscription = AsyncMock(return_value=sub)

        mock_portal = MagicMock()
        mock_portal.url = "https://billing.stripe.com/portal/abc"

        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.return_value = mock_portal
            resp = await client.post(f"{_PREFIX}/billing/portal")

        assert resp.status_code == 200
        assert "url" in resp.json()

    async def test_portal_free_org_returns_409(self, client: AsyncClient):
        # Free orgs have no Stripe customer; portal isn't applicable —
        # direct them to upgrade.
        free_sub = _make_subscription(
            plan="free", stripe_customer_id=None, stripe_subscription_id=None
        )
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)

        with _patch_auth():
            resp = await client.post(f"{_PREFIX}/billing/portal")

        assert resp.status_code == 409
        assert "error" in resp.json()


class TestGetSubscription:
    async def test_returns_subscription(self, client: AsyncClient):
        sub = _make_subscription()
        app.state.billing_service.get_subscription = AsyncMock(return_value=sub)

        with _patch_auth():
            resp = await client.get(f"{_PREFIX}/billing/subscription")

        assert resp.status_code == 200
        data = resp.json()
        assert data["plan"] == "pro"
        assert data["org_login"] == "test-org"

    async def test_returns_free_when_org_has_no_paid_subscription(self, client: AsyncClient):
        """get_subscription auto-enrolls new orgs in Free, so the route
        always returns a real Subscription. The Vue frontend depends on
        this contract — see SettingsBillingTab.vue planLabel()."""
        free_sub = _make_subscription(plan="free", seat_count=3)
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)

        with _patch_auth():
            resp = await client.get(f"{_PREFIX}/billing/subscription")

        assert resp.status_code == 200
        data = resp.json()
        assert data["plan"] == "free"
        assert data["status"] == "active"
        assert data["max_repos"] == 3
        assert data["max_integrations"] == 1


class TestStripeWebhook:
    def _make_event(self, event_type: str, data: dict, event_id: str = "evt_1") -> dict:
        return {
            "id": event_id,
            "type": event_type,
            "data": {"object": data},
        }

    async def test_checkout_completed_creates_subscription(self, client: AsyncClient):
        event = self._make_event(
            "checkout.session.completed",
            {
                "customer": "cus_new",
                "subscription": "sub_new",
                "metadata": {
                    "org_login": "acme",
                    "plan": "pro",
                    "billing_cycle": "monthly",
                },
            },
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=True)
        app.state.billing_service.record_billing_event = AsyncMock()
        app.state.billing_service.create_subscription = AsyncMock()
        app.state.billing_service.get_org_login_by_subscription = AsyncMock(return_value=None)

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 200
        assert resp.json()["ok"] is True
        app.state.billing_service.create_subscription.assert_awaited_once()

    async def test_checkout_missing_metadata_still_succeeds(self, client: AsyncClient):
        event = self._make_event(
            "checkout.session.completed",
            {
                "customer": "cus_new",
                "subscription": "sub_new",
                "metadata": {},  # Missing required fields
            },
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=True)
        app.state.billing_service.record_billing_event = AsyncMock()
        app.state.billing_service.get_org_login_by_subscription = AsyncMock(return_value="acme")

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 200
        assert resp.json()["ok"] is True

    async def test_subscription_updated(self, client: AsyncClient):
        event = self._make_event(
            "customer.subscription.updated",
            {
                "id": "sub_123",
                "status": "past_due",
                "current_period_start": 1700000000,
                "current_period_end": 1702592000,
                "metadata": {"org_login": "acme"},
            },
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=True)
        app.state.billing_service.record_billing_event = AsyncMock()
        app.state.billing_service.update_subscription_status = AsyncMock()
        app.state.billing_service.update_subscription_period = AsyncMock()
        app.state.billing_service.update_subscription_from_stripe = AsyncMock()
        app.state.billing_service.update_subscription_price = AsyncMock()
        app.state.billing_service.get_org_login_by_subscription = AsyncMock(return_value=None)

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 200
        app.state.billing_service.update_subscription_status.assert_awaited_once_with(
            "sub_123", SubscriptionStatus.PAST_DUE
        )
        # Period dates should be synced
        app.state.billing_service.update_subscription_period.assert_awaited_once()

    async def test_subscription_deleted(self, client: AsyncClient):
        event = self._make_event(
            "customer.subscription.deleted",
            {"id": "sub_123", "metadata": {"org_login": "acme"}},
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=True)
        app.state.billing_service.record_billing_event = AsyncMock()
        app.state.billing_service.update_subscription_status = AsyncMock()
        app.state.billing_service.get_org_login_by_subscription = AsyncMock(return_value=None)

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 200
        app.state.billing_service.update_subscription_status.assert_awaited_once_with(
            "sub_123", SubscriptionStatus.CANCELED
        )

    async def test_invoice_payment_failed(self, client: AsyncClient):
        # Invoice objects don't carry org_login in metadata — org_login
        # should be resolved from the subscription row in our DB.
        event = self._make_event(
            "invoice.payment_failed",
            {"subscription": "sub_123"},
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=True)
        app.state.billing_service.record_billing_event = AsyncMock()
        app.state.billing_service.update_subscription_status = AsyncMock()
        app.state.billing_service.get_org_login_by_subscription = AsyncMock(return_value="acme")

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 200
        app.state.billing_service.update_subscription_status.assert_awaited_once_with(
            "sub_123", SubscriptionStatus.PAST_DUE
        )
        # Verify org_login was resolved from subscription, not metadata
        app.state.billing_service.get_org_login_by_subscription.assert_awaited_once_with("sub_123")
        # Verify record_billing_event was called with resolved org_login
        call_kwargs = app.state.billing_service.record_billing_event.call_args
        assert call_kwargs.kwargs.get("org_login") == "acme"

    async def test_duplicate_event_skipped(self, client: AsyncClient):
        event = self._make_event(
            "checkout.session.completed",
            {"metadata": {"org_login": "acme"}},
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=False)

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 200
        assert resp.json()["skipped"] is True

    async def test_invalid_signature_returns_400(self, client: AsyncClient):
        app.state.stripe_client.construct_webhook_event = MagicMock(
            side_effect=stripe_mod.SignatureVerificationError("bad sig", "sig_header")
        )

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "bad_sig"},
        )

        assert resp.status_code == 400
        assert "Invalid signature" in resp.json()["error"]

    async def test_unknown_subscription_status_still_succeeds(self, client: AsyncClient):
        event = self._make_event(
            "customer.subscription.updated",
            {
                "id": "sub_123",
                "status": "totally_unknown_status",
                "metadata": {"org_login": "acme"},
            },
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=True)
        app.state.billing_service.record_billing_event = AsyncMock()
        app.state.billing_service.get_org_login_by_subscription = AsyncMock(return_value=None)

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 200
        assert resp.json()["ok"] is True

    async def test_processing_error_returns_500_without_stamping(self, client: AsyncClient):
        """On processing failure, event is NOT stamped so Stripe can retry."""
        event = self._make_event(
            "checkout.session.completed",
            {
                "customer": "cus_1",
                "subscription": "sub_1",
                "metadata": {
                    "org_login": "acme",
                    "plan": "pro",
                    "billing_cycle": "monthly",
                },
            },
        )
        app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
        app.state.billing_service.claim_event = AsyncMock(return_value=True)
        app.state.billing_service.record_billing_event = AsyncMock()
        app.state.billing_service.create_subscription = AsyncMock(
            side_effect=RuntimeError("db down")
        )

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig_valid"},
        )

        assert resp.status_code == 500
        # Event should NOT be stamped — Stripe will retry
        app.state.billing_service.record_billing_event.assert_not_awaited()

    async def test_subscription_status_mapping(self, client: AsyncClient):
        """Verify all Stripe statuses map correctly."""
        status_cases = [
            ("active", SubscriptionStatus.ACTIVE),
            ("past_due", SubscriptionStatus.PAST_DUE),
            ("canceled", SubscriptionStatus.CANCELED),
            ("trialing", SubscriptionStatus.TRIALING),
            ("unpaid", SubscriptionStatus.PAST_DUE),
            ("incomplete", SubscriptionStatus.PAST_DUE),
            ("incomplete_expired", SubscriptionStatus.CANCELED),
            ("paused", SubscriptionStatus.PAST_DUE),
        ]
        for stripe_status, expected in status_cases:
            event = self._make_event(
                "customer.subscription.updated",
                {
                    "id": "sub_123",
                    "status": stripe_status,
                    "metadata": {"org_login": "acme"},
                },
            )
            app.state.stripe_client.construct_webhook_event = MagicMock(return_value=event)
            app.state.billing_service.is_event_processed = AsyncMock(return_value=False)
            app.state.billing_service.record_billing_event = AsyncMock(return_value=True)
            app.state.billing_service.update_subscription_status = AsyncMock()
            app.state.billing_service.update_subscription_period = AsyncMock()
            app.state.billing_service.update_subscription_from_stripe = AsyncMock()
            app.state.billing_service.update_subscription_price = AsyncMock()
            app.state.billing_service.get_org_login_by_subscription = AsyncMock(return_value=None)

            resp = await client.post(
                "/api/webhooks/stripe",
                content=b"payload",
                headers={"stripe-signature": "sig"},
            )

            assert resp.status_code == 200, f"Failed for Stripe status {stripe_status}"
            app.state.billing_service.update_subscription_status.assert_awaited_once_with(
                "sub_123", expected
            )


class TestSubmitAnthropicKey:
    async def test_successful_key_submission(self, client: AsyncClient):
        app.state.billing_service.store_anthropic_key = AsyncMock()

        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.return_value = MagicMock()  # Successful API call
            resp = await client.post(
                f"{_PREFIX}/settings/anthropic-key",
                json={"api_key": "sk-ant-api03-test-key-1234"},
            )

        assert resp.status_code == 201
        data = resp.json()
        assert data["ok"] is True
        assert data["suffix"] == "1234"
        assert data["status"] == "valid"
        app.state.billing_service.store_anthropic_key.assert_awaited_once()

    async def test_invalid_key_returns_400(self, client: AsyncClient):
        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.side_effect = anthropic_sdk.AuthenticationError(
                message="Invalid API key",
                response=MagicMock(status_code=401),
                body=None,
            )
            resp = await client.post(
                f"{_PREFIX}/settings/anthropic-key",
                json={"api_key": "sk-ant-api03-invalid-key"},
            )

        assert resp.status_code == 400
        assert "Invalid API key" in resp.json()["error"]

    async def test_rate_limited_returns_429(self, client: AsyncClient):
        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.side_effect = anthropic_sdk.RateLimitError(
                message="Rate limited",
                response=MagicMock(status_code=429),
                body=None,
            )
            resp = await client.post(
                f"{_PREFIX}/settings/anthropic-key",
                json={"api_key": "sk-ant-api03-rate-limited"},
            )

        assert resp.status_code == 429

    async def test_connection_error_returns_502(self, client: AsyncClient):
        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.side_effect = anthropic_sdk.APIConnectionError(
                request=MagicMock(),
            )
            resp = await client.post(
                f"{_PREFIX}/settings/anthropic-key",
                json={"api_key": "sk-ant-api03-connection-err"},
            )

        assert resp.status_code == 502

    async def test_api_status_error_returns_502(self, client: AsyncClient):
        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.side_effect = anthropic_sdk.APIStatusError(
                message="Server error",
                response=MagicMock(status_code=500),
                body=None,
            )
            resp = await client.post(
                f"{_PREFIX}/settings/anthropic-key",
                json={"api_key": "sk-ant-api03-server-error"},
            )

        assert resp.status_code == 502

    async def test_store_failure_returns_500(self, client: AsyncClient):
        app.state.billing_service.store_anthropic_key = AsyncMock(
            side_effect=RuntimeError("db error")
        )

        with (
            _patch_auth(),
            patch("asyncio.to_thread", new_callable=AsyncMock) as mock_thread,
        ):
            mock_thread.return_value = MagicMock()
            resp = await client.post(
                f"{_PREFIX}/settings/anthropic-key",
                json={"api_key": "sk-ant-api03-store-fails"},
            )

        assert resp.status_code == 500

    async def test_key_too_short_rejected(self, client: AsyncClient):
        """Key under 10 chars should be rejected by Pydantic validator."""
        with _patch_auth():
            resp = await client.post(
                f"{_PREFIX}/settings/anthropic-key",
                json={"api_key": "short"},
            )
        assert resp.status_code == 422


class TestDeleteAnthropicKey:
    async def test_successful_deletion(self, client: AsyncClient):
        app.state.billing_service.delete_anthropic_key = AsyncMock()

        with _patch_auth():
            resp = await client.delete(f"{_PREFIX}/settings/anthropic-key")

        assert resp.status_code == 200
        assert resp.json()["ok"] is True
        app.state.billing_service.delete_anthropic_key.assert_awaited_once_with("test-org")


class TestGetAnthropicKeyStatus:
    async def test_returns_status(self, client: AsyncClient):
        from canon.billing.models import AnthropicKeyStatus

        status = AnthropicKeyStatus(
            exists=True,
            suffix="abcd",
            status="active",
        )
        app.state.billing_service.get_anthropic_key_status = AsyncMock(return_value=status)

        with _patch_auth():
            resp = await client.get(f"{_PREFIX}/settings/anthropic-key")

        assert resp.status_code == 200
        data = resp.json()
        assert data["exists"] is True
        assert data["suffix"] == "abcd"
        assert data["status"] == "active"


class TestEnterpriseContact:
    async def test_successful_submission(self, client: AsyncClient):
        app.state.billing_service.save_enterprise_contact = AsyncMock()

        with patch("canon.billing.routes.analytics"):
            resp = await client.post(
                "/api/contact/enterprise",
                json={
                    "name": "Jane Doe",
                    "email": "jane@acme.com",
                    "company": "Acme Inc",
                    "team_size": "51-200",
                    "message": "Need enterprise features",
                },
            )

        assert resp.status_code == 201
        assert resp.json()["ok"] is True
        app.state.billing_service.save_enterprise_contact.assert_awaited_once()

    async def test_honeypot_silently_ignored(self, client: AsyncClient):
        """Requests with honeypot filled should be silently accepted (bot prevention)."""
        app.state.billing_service.save_enterprise_contact = AsyncMock()

        resp = await client.post(
            "/api/contact/enterprise",
            json={
                "name": "Bot",
                "email": "bot@spam.com",
                "company": "Spam Inc",
                "team_size": "1-10",
                "honeypot": "i am a bot",
            },
        )

        assert resp.status_code == 200
        assert resp.json()["ok"] is True
        # save_enterprise_contact should NOT be called for bots
        app.state.billing_service.save_enterprise_contact.assert_not_awaited()

    async def test_invalid_email_returns_400(self, client: AsyncClient):
        resp = await client.post(
            "/api/contact/enterprise",
            json={
                "name": "Jane",
                "email": "not-an-email",
                "company": "Acme",
                "team_size": "1-10",
            },
        )

        assert resp.status_code == 400
        assert "email" in resp.json()["error"].lower()

    async def test_email_without_tld_returns_400(self, client: AsyncClient):
        resp = await client.post(
            "/api/contact/enterprise",
            json={
                "name": "Jane",
                "email": "jane@localhost",
                "company": "Acme",
                "team_size": "1-10",
            },
        )

        assert resp.status_code == 400

    async def test_valid_email_formats_accepted(self, client: AsyncClient):
        app.state.billing_service.save_enterprise_contact = AsyncMock()

        with patch("canon.billing.routes.analytics"):
            resp = await client.post(
                "/api/contact/enterprise",
                json={
                    "name": "Jane",
                    "email": "jane+tag@sub.example.com",
                    "company": "Acme",
                    "team_size": "1-10",
                },
            )

        assert resp.status_code == 201


class TestStartTrial:
    async def test_successful_trial_start(self, client: AsyncClient):
        # Free orgs are eligible for the trial.
        free_sub = _make_subscription(
            plan="free", stripe_customer_id=None, stripe_subscription_id=None
        )
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)
        trial_sub = _make_subscription(
            status=SubscriptionStatus.TRIALING,
            plan=Plan.PRO,
        )
        app.state.billing_service.start_trial = AsyncMock(return_value=trial_sub)

        with _patch_auth():
            resp = await client.post(f"{_PREFIX}/billing/start-trial")

        assert resp.status_code == 201
        data = resp.json()
        assert data["ok"] is True
        assert data["plan"] == "pro"
        assert data["status"] == "trialing"

    async def test_trial_rejected_if_subscription_exists(self, client: AsyncClient):
        sub = _make_subscription()
        app.state.billing_service.get_subscription = AsyncMock(return_value=sub)

        with _patch_auth():
            resp = await client.post(f"{_PREFIX}/billing/start-trial")

        assert resp.status_code == 409
        assert "already has an active subscription" in resp.json()["error"]

    async def test_trial_rejected_for_cancelled_internal_org(self, client: AsyncClient):
        # Regression: an INTERNAL-plan org whose comp Stripe sub got
        # cancelled must not slip into a 14-day Pro trial via the
        # CANCELED-status bypass.
        internal_sub = _make_subscription(plan=Plan.INTERNAL, status=SubscriptionStatus.CANCELED)
        app.state.billing_service.get_subscription = AsyncMock(return_value=internal_sub)

        with _patch_auth():
            resp = await client.post(f"{_PREFIX}/billing/start-trial")

        assert resp.status_code == 409
        # start_trial must not have been invoked.
        app.state.billing_service.start_trial = AsyncMock()
        app.state.billing_service.start_trial.assert_not_called()


class TestGetSeatInfo:
    async def test_returns_seat_info(self, client: AsyncClient):
        from datetime import UTC, datetime

        now = datetime.now(UTC)
        sub = _make_subscription(seat_count=5, current_period_start=now, current_period_end=now)
        app.state.billing_service.get_subscription = AsyncMock(return_value=sub)
        app.state.billing_service.get_active_seat_count = AsyncMock(return_value=3)

        with _patch_auth():
            resp = await client.get(f"{_PREFIX}/billing/seats")

        assert resp.status_code == 200
        data = resp.json()
        assert data["seat_count"] == 5
        assert data["active_seats"] == 3
        assert data["plan"] == "pro"

    async def test_free_org_returns_seat_info(self, client: AsyncClient):
        # Free orgs now get a real seats response (no 404).
        free_sub = _make_subscription(plan="free", seat_count=3, stripe_customer_id=None)
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)

        with _patch_auth():
            resp = await client.get(f"{_PREFIX}/billing/seats")

        assert resp.status_code == 200
        data = resp.json()
        assert data["plan"] == "free"
        assert data["seat_count"] == 3
        assert data["active_seats"] == 0


class TestGetAiOpsUsage:
    async def test_returns_ai_ops_usage(self, client: AsyncClient):
        from datetime import UTC, datetime

        from canon.billing.models import AiOpUsage

        now = datetime.now(UTC)
        sub = _make_subscription(current_period_start=now, current_period_end=now)
        app.state.billing_service.get_subscription = AsyncMock(return_value=sub)
        usage = AiOpUsage(
            org_login="test-org",
            period_start=now,
            period_end=now,
            ops_used=100,
            ops_included=2500,
        )
        app.state.billing_service.get_ai_op_usage = AsyncMock(return_value=usage)

        with _patch_auth():
            resp = await client.get(f"{_PREFIX}/billing/ai-ops")

        assert resp.status_code == 200
        data = resp.json()
        assert data["ops_used"] == 100
        assert data["ops_included"] == 2500
        assert data["ops_remaining"] == 2400

    async def test_free_org_returns_zero_usage(self, client: AsyncClient):
        # Free orgs get a real ai-ops response with their 50-op quota,
        # zero used (no 404).
        free_sub = _make_subscription(
            plan="free", stripe_customer_id=None, current_period_start=None, current_period_end=None
        )
        app.state.billing_service.get_subscription = AsyncMock(return_value=free_sub)

        with _patch_auth():
            resp = await client.get(f"{_PREFIX}/billing/ai-ops")

        assert resp.status_code == 200
        data = resp.json()
        assert data["ops_used"] == 0
        assert data["ops_included"] == 50
        assert data["ops_remaining"] == 50


class TestBillingServiceUnavailable:
    async def test_checkout_503_without_billing(self, client: AsyncClient):
        app.state.billing_service = None
        app.state.stripe_client = None

        with _patch_auth():
            resp = await client.post(
                f"{_PREFIX}/checkout",
                json={
                    "plan": "pro",
                    "billing_cycle": "monthly",
                    "success_url": "https://app.canonhq.co/s",
                    "cancel_url": "https://app.canonhq.co/c",
                },
            )

        assert resp.status_code == 503

    async def test_portal_503_without_billing(self, client: AsyncClient):
        app.state.billing_service = None
        app.state.stripe_client = None

        with _patch_auth():
            resp = await client.post(f"{_PREFIX}/billing/portal")

        assert resp.status_code == 503

    async def test_webhook_503_without_stripe(self, client: AsyncClient):
        app.state.stripe_client = None

        resp = await client.post(
            "/api/webhooks/stripe",
            content=b"payload",
            headers={"stripe-signature": "sig"},
        )

        assert resp.status_code == 503
