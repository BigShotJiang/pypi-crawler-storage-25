"""Tests for BillingService with mocked asyncpg pool."""

from __future__ import annotations

import base64
import os
from contextlib import asynccontextmanager
from datetime import UTC, datetime
from unittest.mock import AsyncMock, MagicMock

import pytest
from cryptography.exceptions import InvalidTag

from canon.billing.encryption import encrypt_api_key
from canon.billing.models import (
    BillingCycle,
    Plan,
    SubscriptionStatus,
)
from canon.billing.service import BillingService


def _make_encryption_key() -> str:
    return base64.b64encode(os.urandom(32)).decode()


def _mock_pool(mock_conn: AsyncMock) -> MagicMock:
    """Create a mock pool whose acquire() yields mock_conn."""
    mock_pool = MagicMock()

    @asynccontextmanager
    async def _acquire():
        yield mock_conn

    mock_pool.acquire = _acquire
    return mock_pool


def _make_sub_row(**overrides) -> dict:
    """Build a mock subscription database row."""
    now = datetime.now(UTC)
    defaults = {
        "id": "uuid-1",
        "org_login": "test-org",
        "stripe_customer_id": "cus_123",
        "stripe_subscription_id": "sub_456",
        "plan": "pro",
        "billing_cycle": "monthly",
        "status": "active",
        "seat_count": 5,
        "current_period_start": now,
        "current_period_end": now,
        "trial_start": None,
        "trial_end": None,
        "created_at": now,
        "updated_at": now,
    }
    defaults.update(overrides)
    return defaults


class TestBillingServiceInit:
    def test_valid_init(self):
        conn = AsyncMock()
        pool = _mock_pool(conn)
        stripe_client = MagicMock()
        key = _make_encryption_key()
        service = BillingService(pool, stripe_client, key)
        assert service is not None

    def test_empty_encryption_key_raises(self):
        pool = _mock_pool(AsyncMock())
        stripe_client = MagicMock()
        with pytest.raises(ValueError, match="byok_encryption_key is required"):
            BillingService(pool, stripe_client, "")

    def test_invalid_encryption_key_raises(self):
        pool = _mock_pool(AsyncMock())
        stripe_client = MagicMock()
        # 16-byte key (128-bit) instead of 32-byte (256-bit)
        bad_key = base64.b64encode(os.urandom(16)).decode()
        with pytest.raises(ValueError, match="256 bits"):
            BillingService(pool, stripe_client, bad_key)


class TestGetSubscription:
    async def test_returns_subscription_when_found(self):
        conn = AsyncMock()
        row = _make_sub_row()
        conn.fetchrow = AsyncMock(return_value=row)
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        sub = await service.get_subscription("test-org")
        assert sub is not None
        assert sub.org_login == "test-org"
        assert sub.plan == Plan.PRO
        assert sub.billing_cycle == BillingCycle.MONTHLY
        assert sub.status == SubscriptionStatus.ACTIVE
        assert sub.seat_count == 5
        conn.fetchrow.assert_awaited_once()

    async def test_auto_enrolls_free_when_not_found(self):
        # First fetchrow (SELECT lookup) → no existing row.
        # Second fetchrow (INSERT ON CONFLICT DO NOTHING RETURNING *) → the new Free row.
        now = datetime.now(UTC)
        free_row = _make_sub_row(
            org_login="new-org",
            plan="free",
            seat_count=3,
            stripe_customer_id=None,
            stripe_subscription_id=None,
            created_at=now,
            updated_at=now,
        )
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(side_effect=[None, free_row])
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        sub = await service.get_subscription("new-org")

        assert sub.plan.value == "free"
        assert sub.stripe_customer_id is None
        assert sub.seat_count == 3
        assert conn.fetchrow.await_count == 2

        # Verify the INSERT carries the right plan/seat_count/status so a
        # regression that auto-enrolls into Pro (or skips a column) would fail.
        insert_call = conn.fetchrow.await_args_list[1]
        sql = insert_call.args[0]
        assert "INSERT INTO subscriptions" in sql
        assert "ON CONFLICT (org_login) DO NOTHING" in sql
        # Positional args after the SQL string: org_login, plan, cycle, seats, status, period_start, period_end.
        assert insert_call.args[1] == "new-org"
        assert insert_call.args[2] == "free"
        assert insert_call.args[3] == "monthly"
        assert insert_call.args[4] == 3
        assert insert_call.args[5] == "active"

    async def test_auto_enroll_returns_existing_row_on_conflict(self):
        # Simulates the race: SELECT returns None (no row yet), INSERT
        # ON CONFLICT DO NOTHING returns None (a concurrent caller wrote
        # first), re-SELECT returns the concurrent caller's row — which
        # may be a real paid sub, not Free. Must NOT clobber.
        now = datetime.now(UTC)
        pro_row = _make_sub_row(
            org_login="racing-org",
            plan="pro",
            seat_count=5,
            stripe_customer_id="cus_real",
            stripe_subscription_id="sub_real",
            created_at=now,
            updated_at=now,
        )
        conn = AsyncMock()
        # Calls: 1) initial SELECT misses, 2) INSERT DO NOTHING → None, 3) re-SELECT finds Pro row.
        conn.fetchrow = AsyncMock(side_effect=[None, None, pro_row])
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        sub = await service.get_subscription("racing-org")

        assert sub.plan.value == "pro"
        assert sub.stripe_customer_id == "cus_real"
        assert sub.stripe_subscription_id == "sub_real"
        assert conn.fetchrow.await_count == 3


class TestCreateSubscription:
    async def test_creates_and_returns_subscription(self):
        conn = AsyncMock()
        now = datetime.now(UTC)
        row = _make_sub_row(
            org_login="new-org",
            plan="starter",
            billing_cycle="annual",
            current_period_start=now,
            current_period_end=now,
        )
        conn.fetchrow = AsyncMock(return_value=row)
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        sub = await service.create_subscription(
            org_login="new-org",
            stripe_customer_id="cus_new",
            stripe_subscription_id="sub_new",
            plan=Plan.STARTER,
            billing_cycle=BillingCycle.ANNUAL,
            period_start=now,
            period_end=now,
        )

        assert sub.org_login == "new-org"
        conn.fetchrow.assert_awaited_once()
        # Verify the SQL was called with the right positional args
        call_args = conn.fetchrow.call_args
        assert "new-org" in call_args[0]


class TestUpdateSubscriptionStatus:
    async def test_updates_status(self):
        conn = AsyncMock()
        conn.execute = AsyncMock(return_value="UPDATE 1")
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.update_subscription_status("sub_123", SubscriptionStatus.PAST_DUE)
        conn.execute.assert_awaited_once()
        call_args = conn.execute.call_args[0]
        assert "past_due" in call_args
        assert "sub_123" in call_args

    async def test_empty_subscription_id_returns_early(self):
        conn = AsyncMock()
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.update_subscription_status("", SubscriptionStatus.CANCELED)
        conn.execute.assert_not_awaited()

    async def test_no_matching_subscription_logs_error(self):
        conn = AsyncMock()
        conn.execute = AsyncMock(return_value="UPDATE 0")
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        # Should not raise, just log
        await service.update_subscription_status("sub_missing", SubscriptionStatus.ACTIVE)
        conn.execute.assert_awaited_once()


class TestClaimEvent:
    async def test_returns_true_for_new_event(self):
        conn = AsyncMock()
        conn.execute = AsyncMock(return_value="INSERT 0 1")
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        result = await service.claim_event("evt_123", "checkout.session.completed")
        assert result is True
        conn.execute.assert_awaited_once()

    async def test_returns_false_for_duplicate_event(self):
        conn = AsyncMock()
        conn.execute = AsyncMock(return_value="INSERT 0 0")
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        result = await service.claim_event("evt_123", "checkout.session.completed")
        assert result is False


class TestRecordBillingEvent:
    async def test_updates_event_row(self):
        conn = AsyncMock()
        conn.execute = AsyncMock()
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.record_billing_event(
            org_login="org",
            stripe_event_id="evt_123",
            event_type="checkout.session.completed",
            payload={"test": True},
        )
        conn.execute.assert_awaited_once()


class TestStoreAnthropicKey:
    async def test_stores_encrypted_key(self):
        conn = AsyncMock()
        conn.execute = AsyncMock()
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.store_anthropic_key("org-1", "sk-ant-api03-test1234")
        conn.execute.assert_awaited_once()

        call_args = conn.execute.call_args[0]
        # First positional arg is SQL, then org_login, encrypted_key, suffix, timestamp
        assert call_args[1] == "org-1"
        # The encrypted key should be bytes
        assert isinstance(call_args[2], bytes)
        # Suffix should be last 4 chars
        assert call_args[3] == "1234"


class TestGetAnthropicKey:
    async def test_returns_decrypted_key(self):
        enc_key = _make_encryption_key()
        api_key = "sk-ant-api03-secret-key"
        encrypted = encrypt_api_key(api_key, enc_key)

        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value={"encrypted_key": encrypted, "status": "active"})
        pool = _mock_pool(conn)
        service = BillingService(pool, MagicMock(), enc_key)

        result = await service.get_anthropic_key("org-1")
        assert result == api_key

    async def test_returns_none_when_no_row(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        result = await service.get_anthropic_key("org-1")
        assert result is None

    async def test_returns_none_when_status_not_active(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value={"encrypted_key": b"something", "status": "invalid"})
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        result = await service.get_anthropic_key("org-1")
        assert result is None

    async def test_raises_on_corrupted_data(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value={"encrypted_key": b"\x00" * 50, "status": "active"})
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        with pytest.raises(InvalidTag):
            await service.get_anthropic_key("org-1")


class TestGetAnthropicKeyStatus:
    async def test_no_key_returns_exists_false(self):
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(return_value=None)
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        status = await service.get_anthropic_key_status("org-1")
        assert not status.exists
        assert status.suffix == ""
        assert status.status == "none"

    async def test_has_key_returns_status(self):
        now = datetime.now(UTC)
        conn = AsyncMock()
        conn.fetchrow = AsyncMock(
            return_value={"key_suffix": "abcd", "status": "active", "last_validated_at": now}
        )
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        status = await service.get_anthropic_key_status("org-1")
        assert status.exists
        assert status.suffix == "abcd"
        assert status.status == "active"
        assert status.last_validated_at == now


class TestDeleteAnthropicKey:
    async def test_deletes_key(self):
        conn = AsyncMock()
        conn.execute = AsyncMock()
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.delete_anthropic_key("org-1")
        conn.execute.assert_awaited_once()
        call_args = conn.execute.call_args[0]
        assert "org-1" in call_args


class TestMarkAnthropicKeyInvalid:
    async def test_marks_key_invalid(self):
        conn = AsyncMock()
        conn.execute = AsyncMock()
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.mark_anthropic_key_invalid("org-1")
        conn.execute.assert_awaited_once()
        call_args = conn.execute.call_args[0]
        assert "invalid" in call_args[0]  # SQL contains 'invalid'
        assert "org-1" in call_args


class TestSaveEnterpriseContact:
    async def test_saves_contact(self):
        conn = AsyncMock()
        conn.execute = AsyncMock()
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.save_enterprise_contact(
            name="Jane Doe",
            email="jane@acme.com",
            company="Acme Inc",
            team_size="51-200",
            message="Need custom features",
        )
        conn.execute.assert_awaited_once()
        call_args = conn.execute.call_args[0]
        assert "Jane Doe" in call_args
        assert "jane@acme.com" in call_args
        assert "Acme Inc" in call_args
        assert "51-200" in call_args
        assert "Need custom features" in call_args

    async def test_saves_contact_without_message(self):
        conn = AsyncMock()
        conn.execute = AsyncMock()
        pool = _mock_pool(conn)
        key = _make_encryption_key()
        service = BillingService(pool, MagicMock(), key)

        await service.save_enterprise_contact(
            name="Jane",
            email="jane@acme.com",
            company="Acme",
            team_size="1-10",
        )
        conn.execute.assert_awaited_once()
