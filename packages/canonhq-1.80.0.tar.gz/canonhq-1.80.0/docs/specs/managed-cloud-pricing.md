---
title: "Managed Cloud Pricing & Stripe Billing"
status: done
owner: ng
team: platform
ticket_project: null
created: 2026-03-14
updated: 2026-03-20
tags: [billing, stripe, pricing, enterprise]
---

# Managed Cloud Pricing & Stripe Billing

Implement a production billing stack for Canon's managed cloud offering with per-seat pricing, Stripe integration, BYOK pricing differentiation, AI operation metering, and enterprise contact flow.

## 1. Background
<!-- canon:system:1 status:done -->

Canon currently offers a free, self-hosted deployment with a "Coming Soon" waitlist for managed cloud. The managed cloud uses per-seat pricing to align revenue growth with team adoption.

This spec covers the initial monetization of Canon's Tier 1 (Repo Agents) capabilities. Future tiers (Agent Mesh, Org Brain) will build on this billing infrastructure but are out of scope here.

**Key insight — BYOK as a pricing lever:** Canon's primary variable cost is Claude API usage for PR analysis and spec realization. Users who bring their own Anthropic API key eliminate this cost, enabling a lower price point that drives adoption while preserving margin on the all-inclusive tier.

### Current State

- Pricing section on landing page: Self-Hosted (free) + Managed Cloud (TBD / waitlist)
- Waitlist email capture via `POST /api/waitlist` → PostHog event
- Auth0 user management with no billing fields
- No payment processing, subscription logic, or plan enforcement

### Goals

1. Launch managed cloud with per-seat pricing and Stripe checkout
2. Differentiate BYOK vs all-inclusive pricing to reflect cost structure
3. Enable self-service billing management (upgrades, downgrades, invoices)
4. Provide enterprise contact path for custom deals
5. Build billing infrastructure that supports future tiers
6. 14-day Pro trial to maximize top-of-funnel conversion

## 2. Pricing Model

<!-- canon:system:2 status:done -->

### 2.1 Tier Definitions

<!-- canon:system:2.1 status:done -->
| | Self-Hosted | Free (managed) | Starter | Pro | Enterprise |
|---|---|---|---|---|---|
| **Price** | Free forever | $0 | $9/user/mo | $19/user/mo | Custom |
| **Trial** | N/A | N/A (already free) | 14-day Pro | 14-day Pro | POC engagement |
| **Repos** | Unlimited | Up to 3 | Up to 10 | Unlimited | Unlimited |
| **Users** | Unlimited | Up to 3 | 3+ | 3+ | Negotiated |
| **AI Compute** | Your infra | 50 ops/mo total (Canon-supplied) | BYOK (you pay Anthropic) | 500 ops/user/mo included | Unlimited included |
| **AI Overage** | N/A | None — hard cap | N/A (BYOK) | $0.08/op | Negotiated |
| **PR Analysis** | Yes | Yes | Yes | Yes | Yes |
| **Spec Indexing** | Yes | Yes | Yes | Yes | Yes |
| **Ticket Sync** | 1 system | 1 integration max | 1 system | All systems | All + custom |
| **Auto Doc PRs** | Yes | Yes | Yes | Yes | Yes |
| **Stale Detection** | Yes | Yes | Yes | Yes | Yes |
| **Slack Q&A** | — | — | — | Yes | Yes |
| **SSO / SAML** | — | — | — | — | Yes |
| **Audit Logs** | — | — | — | — | Yes |
| **Support** | Community | Community | Email | Priority | Dedicated |

**Minimum 3 seats** on all paid plans. **Free is fixed at 3 seats** (auto-enrolled). Signals Canon is a team product.

**Self-Hosted vs Free (managed):** Self-hosted runs in your own infra with no Canon-enforced limits — you bring your own compute and Anthropic key. Free (managed) is hosted by Canon at canonhq.co with caps that drive upgrade to Starter/Pro.

**Internal tier (not in the public matrix):** Reserved for Canon's own dev/test orgs and similar comp accounts. Provisioned via admin endpoint, backed by a Pro Stripe subscription with the `internal_comp_100` coupon attached (100% off forever). DB plan is stored as `internal` so feature gates treat the org as fully uncapped.

### 2.2 Annual Discount (20%)

<!-- canon:system:2.2 status:done -->
- Starter: $86/user/yr ($7.17/mo effective)
- Pro: $182/user/yr ($15.17/mo effective)

### 2.3 AI Operations

<!-- canon:system:2.3 status:done -->
Each of these counts as 1 operation:
- PR analysis (reviewing a pull request against specs)
- Doc update generation (creating a PR to update stale docs)
- Spec coverage scan (checking implementation against acceptance criteria)
- Slack Q&A response (answering a question from indexed docs)
- Spec generation assist (AI-powered spec writing in web editor)

Spec parsing, ticket sync, and CLI/MCP queries do NOT count as ops.

### 2.4 Seat Counting

<!-- canon:system:2.4 status:done -->
A "seat" = any user who interacts with Canon in a billing period:
- Views the Canon dashboard or billing page
- Triggers a PR analysis or spec coverage scan
- Uses the CLI or MCP tools
- Receives a Canon PR comment (passive interaction counts)
- Uses Slack Q&A

Billing mechanics:
- Monthly: billed for max active seats in the billing period
- Annual: billed for committed seat count, true-up quarterly if exceeded
- Seat count visible in billing dashboard with per-user activity breakdown

### 2.5 BYOK (Bring Your Own Key)

<!-- canon:system:2.5 status:done -->
Users on the Starter tier provide their own Anthropic API key. Canon stores the key encrypted at rest and uses it for all Claude API calls associated with the user's repos. This means:

- Canon pays zero AI compute cost for BYOK users
- User has full visibility into their Anthropic usage/billing
- User can set their own rate limits and model preferences
- If the user's key is revoked or runs out of credits, agent features degrade gracefully

### 2.6 Trial Mechanics

New managed-cloud orgs are auto-enrolled in **Free** at first billing-endpoint access (see §3.2). The Pro trial is an opt-in upgrade from Free, not the default starting state.

- 14-day Pro trial available to any org currently on Free that has never held a paid subscription
- Full Pro features during trial (AI included, unlimited repos, all integrations)
- No credit card required to start trial
- Auto-downgrade to **Free** at trial end (org keeps Free-tier caps; no surprise charge)
- Orgs on a paid plan, in an active trial, or with a previously-cancelled paid subscription are not eligible for a second trial (`POST /app/{org}/api/billing/start-trial` returns 409)

### Acceptance Criteria

- [x] Pricing page displays all four tiers with accurate feature comparison
<!-- canon:realized-in:PR#321 file:frontend/src/views/PricingView.vue -->
<!-- canon:realized-in:PR#782 file:docs/specs/managed-cloud-pricing.md -->
- [x] BYOK and all-inclusive pricing is clearly differentiated
- [x] Per-seat pricing with minimum 3 seats enforced
<!-- canon:realized-in:PR#321 file:src/canon/billing/models.py -->
<!-- canon:realized-in:PR#782 file:src/canon/billing/models.py -->
- [x] Annual billing option applies 20% discount
- [x] Monthly/annual toggle on pricing page
- [x] AI operations defined and metered for Pro tier
- [x] 14-day Pro trial available without credit card
<!-- canon:realized-in:PR#321 file:src/canon/billing/service.py -->
<!-- canon:realized-in:PR#782 file:src/canon/billing/routes.py -->

## 3. Stripe Integration

<!-- canon:system:3 status:done -->

### 3.1 Stripe Setup

<!-- canon:system:3.1 status:done -->
Stripe Products and Prices (per-seat) for paid tiers. Free orgs do NOT have Stripe resources — they live only in the `subscriptions` DB table (Stripe doesn't smoothly support $0 recurring prices via the `lukasaron/stripe` provider, and free orgs don't need Stripe accounting noise).

```
Products:
  canon_starter       → "Canon Starter"
  canon_pro           → "Canon Pro"
  (no canon_free product — Free is DB-only)

Prices (per product):
  starter_monthly     → $9/seat/mo (per-unit)
  starter_annual      → $86/seat/yr (per-unit)
  pro_monthly         → $19/seat/mo (per-unit)
  pro_annual          → $182/seat/yr (per-unit)

Coupons:
  internal_comp_100   → 100% off forever (for Internal-tier orgs)
```

### 3.2 Checkout Flow

<!-- canon:system:3.2 status:done -->
New managed-cloud orgs are auto-enrolled in **Free** at creation (DB row only — no Stripe customer yet). Upgrading from Free:

1. User clicks "Start Free Trial" (Pro trial) or "Get Started" on a paid plan
2. `POST /app/{org}/api/checkout` creates a Stripe Checkout Session with seat quantity. Free orgs are eligible for the 14-day Pro trial; orgs that already paid before are not.
3. Stripe Checkout handles payment details, tax calculation, and 3D Secure
4. On success, webhook confirms subscription creation and updates the org's DB row from `plan=free` to `plan=starter` or `plan=pro`

### 3.3 Billing Portal

<!-- canon:system:3.3 status:done -->
Stripe's Customer Portal for self-service:

- View/download invoices
- Update payment method
- Switch between monthly/annual billing
- Cancel subscription
- Adjust seat count

Only available to orgs with an active Stripe subscription (Starter, Pro, Enterprise, or Internal). Free orgs have no Stripe customer record, so `POST /app/{org}/api/billing/portal` returns **409 Conflict** with an "upgrade to access billing portal" message. (This replaces the original 404 behavior, which was a leftover from the pre-Free design where missing Stripe customer was treated as a not-found error.)

### 3.4 Webhook Handler

`POST /api/webhooks/stripe` handles these events:

| Event | Action |
|-------|--------|
| `checkout.session.completed` | Create subscription with seat count from metadata |
| `customer.subscription.updated` | Handle plan/seat changes, update entitlements |
| `customer.subscription.deleted` | Revoke managed cloud access, notify user |
| `invoice.payment_failed` | Notify user, mark subscription past_due |

### 3.5 Internal Comp

Reserved for Canon's own dev/test orgs (and similar comp accounts) so they can exercise the full product without billing.

**Mechanism:**
1. Super-admin hits `POST /admin/orgs/{org}/comp`.
2. Backend creates a Stripe customer for the org (if not already present), creates a Pro subscription, and attaches the `internal_comp_100` coupon (Stripe coupon ID `9wUmbcEi`, 100% off forever). Stripe still tracks the org as a real customer for accounting visibility — invoices net to $0.
3. Backend sets the DB `plan` field to `internal`. Feature gates throughout the app key off the DB plan, so the org gets uncapped repos/seats/AI ops/integrations regardless of what Stripe thinks the tier is.

`DELETE /admin/orgs/{org}/comp` reverses this — cancels the Stripe subscription and downgrades DB plan back to `free`.

The Internal tier is intentionally not exposed in the public pricing matrix. It exists for operator convenience, not as a customer-facing option.

### Acceptance Criteria

- [x] Stripe Prices support per-seat quantity
<!-- canon:realized-in:PR#782 file:infra/modules/stripe/main.tf -->
- [x] Checkout flow passes seat_count in metadata
<!-- canon:realized-in:PR#321 file:src/canon/billing/routes.py -->
- [x] Trial period (14 days) enabled for new customers — Free orgs only
- [x] Billing Portal allows subscription management (paid orgs only; Free returns 409 directing to upgrade)
- [x] Webhook handler processes all subscription lifecycle events
- [x] Webhook signature verification prevents spoofed events
- [x] Free tier auto-enrolled on first billing-endpoint access (no Stripe involvement)
<!-- canon:realized-in:audit file:src/canon/billing/service.py method:_auto_enroll_free -->
- [x] `internal_comp_100` coupon exists in Stripe (`9wUmbcEi`) and is stored in Doppler as `STRIPE_INTERNAL_COMP_COUPON_ID`
<!-- canon:realized-in:audit file:infra/modules/stripe/main.tf resource:stripe_coupon.internal_comp -->

## 4. BYOK Key Management

<!-- canon:system:4 status:done -->

(Same as before — encryption, validation, routing, graceful degradation.)

### Acceptance Criteria

- [x] Anthropic API key can be submitted and is encrypted at rest (AES-256-GCM)
<!-- canon:realized-in:PR#321 file:src/canon/billing/encryption.py -->
- [x] Key validation endpoint verifies key works before storing
- [x] Key is never returned in full via API (last 4 chars only)
- [x] Agent uses BYOK key for Starter plans, Canon key for Pro/Enterprise
<!-- canon:realized-in:audit file:src/canon/agent/client.py:110-113 -->
- [x] Graceful degradation when BYOK key fails
<!-- canon:realized-in:PR#390 file:src/canon/agent/analyzer.py -->

## 5. Enterprise Contact Flow

<!-- canon:system:5 status:done -->

### Acceptance Criteria

- [x] Enterprise contact form collects name, email, company, team size
- [x] Form submission sends email to sales@canonhq.co
<!-- canon:realized-in:PR#390 file:src/canon/billing/email.py -->
<!-- canon:realized-in:PR#390 file:src/canon/billing/routes.py -->
- [x] PostHog event tracks enterprise contact (no PII in event)
- [x] Honeypot field prevents basic spam bots
- [x] User sees confirmation message after submission
<!-- canon:realized-in:audit file:frontend/src/views/PricingView.vue:475-485 -->

## 6. Backend Architecture

<!-- canon:system:6 status:done -->

### 6.1 Modules

<!-- canon:system:6.1 status:done -->
```
src/canon/
  billing/
    __init__.py
    stripe_client.py     # Stripe API wrapper (Checkout, Portal, Webhooks)
    models.py            # Pydantic: Subscription, Plan, AiOpUsage, seat/ops constants
    service.py           # Business logic: subscriptions, seats, AI ops, BYOK, trials
    encryption.py        # AES-256-GCM encrypt/decrypt for BYOK keys
    routes.py            # FastAPI routes: checkout, billing, seats, AI ops, BYOK, enterprise
```

### 6.2 Database Tables

<!-- canon:system:6.2 status:done -->
```sql
subscriptions           -- Org subscriptions with seat_count, trial dates
seat_activity           -- Per-user activity tracking for seat counting
ai_op_usage             -- Individual AI operation records
ai_op_monthly_summary   -- Monthly aggregated usage (for billing)
billing_events          -- Stripe webhook audit log
anthropic_keys          -- Encrypted BYOK keys
enterprise_contacts     -- Sales inquiry leads
```

### 6.3 API Routes

Org-scoped routes use the `/app/{org}/api/` prefix (matching ticket, profile, and API key routes). The Stripe webhook stays at `/api/` since it's called by Stripe, not the frontend.

```
POST   /app/{org}/api/checkout                  # Create Stripe Checkout Session (per-seat)
POST   /app/{org}/api/billing/portal            # Create Stripe Billing Portal session
GET    /app/{org}/api/billing/subscription      # Get current subscription details
GET    /app/{org}/api/billing/seats             # Get seat count and active users
GET    /app/{org}/api/billing/ai-ops            # Get AI operation usage for current period
POST   /app/{org}/api/billing/start-trial       # Start 14-day Pro trial (no card required)
POST   /app/{org}/api/settings/anthropic-key    # Submit/validate BYOK key
GET    /app/{org}/api/settings/anthropic-key    # Get BYOK key status
DELETE /app/{org}/api/settings/anthropic-key    # Remove BYOK key
POST   /app/{org}/api/contact/enterprise        # Enterprise contact form
POST   /api/webhooks/stripe                     # Stripe webhook handler (separate router)
```

### Acceptance Criteria

- [x] Billing module is organized with per-seat models
- [x] Database schema includes seat_activity and ai_op_usage tables
- [x] All API routes are implemented
- [x] Settings loaded from environment variables
- [x] Comprehensive test suite (140 tests passing)
<!-- canon:realized-in:PR#321 file:tests/test_billing/test_models.py -->
<!-- canon:realized-in:PR#321 file:tests/test_billing/test_service.py -->
<!-- canon:realized-in:PR#321 file:tests/test_billing/test_routes.py -->
<!-- canon:realized-in:PR#782 file:tests/test_billing/test_routes.py -->
<!-- canon:realized-in:PR#782 file:tests/test_billing/test_models.py -->
<!-- canon:realized-in:PR#782 file:tests/test_billing/test_service.py -->

## 7. Known Deferrals
<!-- canon:system:7 status:done -->

Items identified in PR review that are tracked for follow-up:

- **BYOK rate limiting**: `POST /settings/anthropic-key` makes a real Anthropic API call per request. Add per-org rate limit (e.g. 5 attempts/hour) to prevent abuse.
- **Stripe SDK global state**: `stripe.api_key` is set as a module-level global in `stripe_client.py`. Use the instance-level `stripe.StripeClient(api_key)` API to avoid test isolation issues.
- ~~**Enterprise email notifications**~~: Resolved — SMTP-based email added in `billing/email.py` (conditional on `smtp_enabled`).
- ~~**BYOK graceful degradation**~~: Resolved — invalid/missing keys raise `AgentUnavailableError`. 401/403 errors during PR analysis return `None` gracefully. No automatic retry or re-validation cron yet.

## 8. Open Questions
<!-- canon:system:8 status:done -->

- Should BYOK remain available on Pro as a cost-saving option?
- What's the right ops/user/mo number for Pro? (500 is a starting guess — needs validation against actual Anthropic API costs per operation)
- Grace period duration for failed payments?
