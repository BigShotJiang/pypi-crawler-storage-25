---
title: "Profile & Account Management"
status: draft
owner: ng
team: canon
ticket_project: canonhq/canon-private
created: 2026-05-16
updated: 2026-05-16
tags: [web, auth, profile, account, security, notifications, gdpr]
audience: internal
---

# Profile & Account Management

Promote `/app/:org/profile` from a read-only identity card into a full
self-service Profile & Account hub: editable identity, security (password,
sessions, user-scoped API keys), linked accounts, notification preferences,
appearance preferences, and an account lifecycle area for data export and
self-service deletion.

## 1. Background

<!-- canon:system:1 status:draft -->

The existing [[user-profile-page]] spec landed a read-only `/profile` view
that surfaces Auth0 claims, role, permissions, GitHub linkage, and Auth0 org
ID. Every editable account concern lives somewhere else or doesn't exist:

- **Profile edits** — `name`, `picture`, `email` are pulled live from Auth0;
  Canon stores them via `UserStore.upsert_user` but never writes back to the
  IdP. A user who wants to change their display name has to do it in Auth0,
  which the product never exposes.
- **Password reset** — only an admin can trigger it (`POST /admin/users/{id}/password-reset`
  in `src/canon/admin/routes.py`). Users have no self-serve path inside the app.
- **Active sessions** — `sessions` table tracks refresh-token rotation with a
  `revoke_session` / `revoke_all_sessions` API, but there's no UI for a user
  to see "I'm signed in on N devices" or kick a stolen session.
- **API keys** — `/app/:org/settings/api-keys` is gated behind `org:manage`,
  so non-admin users cannot mint personal keys for CLI / CI use even though
  the data model is per-user.
- **Notification preferences** — Slack DM, email digests, and PR-comment
  cadence are configured implicitly. `slack_dm_prompts` exists as a one-time
  prompt tracker, not a preference store; there is no `user_preferences`
  table.
- **Linked accounts** — GitHub user appears on the profile card with no way
  to relink; Slack identity linkage has no UI surface at all.
- **Appearance** — theme toggle is local-only; timezone and locale are
  inferred from the browser, not persisted per user.
- **Account lifecycle** — GDPR DSAR self-serve doesn't exist. Admins can
  delete users via `delete_user_atomic` (`src/canon/admin/store.py:397`);
  users cannot export or delete their own data.

Result: every escalation hits support or an admin, and Canon fails the basic
discoverability bar for an enterprise SaaS account area. This spec collapses
the gap into one hub.

## 2. Information Architecture

<!-- canon:system:2 status:done -->

Convert `/app/:org/profile` from a single `ProfileCard` into a tabbed view
that mirrors the Settings IA. Sub-routes are first-class so deep links and
"Back" work.

### 2.1 Tabs and routes

<!-- canon:system:2.1 status:done -->

- `/app/:org/profile` → **Overview** (current ProfileCard content, read-only)
- `/app/:org/profile/account` → **Account** (editable identity)
- `/app/:org/profile/security` → **Security** (password, sessions, API keys)
- `/app/:org/profile/notifications` → **Notifications**
- `/app/:org/profile/linked` → **Linked accounts**
- `/app/:org/profile/preferences` → **Preferences**
- `/app/:org/profile/danger` → **Danger zone** (export, delete)

### Acceptance Criteria

- [x] `ProfileView.vue` renders a tab strip and `<router-view>` like
      `SettingsView.vue` does today
<!-- canon:realized-in: file:frontend/src/views/ProfileView.vue:46-86 -->
- [x] Default route `/profile` keeps showing the existing Overview content so
      no existing link breaks
<!-- canon:realized-in: file:frontend/src/router/index.ts:131-139 -->
<!-- canon:realized-in: file:frontend/src/views/profile/ProfileOverviewTab.vue -->
- [x] Mobile fallback uses the same `<select>` pattern as `SettingsView.vue`
<!-- canon:realized-in: file:frontend/src/views/ProfileView.vue:68-81 -->
- [x] Breadcrumb component (`Breadcrumb.vue`) updates to show the active
      sub-tab name
<!-- canon:realized-in: file:frontend/src/components/layout/Breadcrumb.vue:36-46 -->
- [x] Navbar / sidebar / mobile menu "Profile" links continue to land on
      Overview by default
<!-- canon:realized-in: file:frontend/src/router/index.ts:131-139 name:profile -->

Backend feature-flag plumbing (supports §2 IA and all downstream sections):

- [x] `Settings.profile_hub_enabled` flag and session-dict exposure
<!-- canon:realized-in: file:src/canon/settings.py profile_hub_enabled -->
<!-- canon:realized-in: file:src/canon/web/routes.py _build_session_dict feature_flags -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py TestSessionApi -->

Frontend guard bounces direct URLs to gated tabs back to Overview while
the flag is off:

- [x] Profile-hub flag gated in router
<!-- canon:realized-in: file:frontend/src/router/guards.ts profile-hub -->

## 3. Editable Account Identity

<!-- canon:system:3 status:done -->

Let users edit name, display name, picture URL, and email. Writes go to the
identity provider via the existing `OIDCProviderProtocol` (we already have
`provider.delete_user`; we add `provider.update_user`). Email changes
trigger an Auth0 verification email and only land in Canon's `users` table
once the IdP confirms.

### 3.1 GET /api/profile/account

<!-- canon:system:3.1 status:draft -->

Returns the current editable fields (`name`, `nickname`, `picture`, `email`,
`email_verified`). Source of truth is the IdP; we proxy.

### 3.2 PATCH /api/profile/account

<!-- canon:system:3.2 status:draft -->

Accepts a partial `AccountUpdate` model (`name?`, `nickname?`, `picture?`).
For `email`, dispatches to a separate `POST /api/profile/account/email`
endpoint that initiates IdP-side verification and never directly mutates
`users.email`.

### Acceptance Criteria

- [ ] `OIDCProviderProtocol.update_user(user_id, patch: dict)` is implemented
      for the Auth0 provider; generic OIDC provider raises a clear "not
      supported" error
- [ ] `PATCH /app/{org}/api/profile/account` validates each field
      (max-length 100 for `name`/`nickname`, https-only URL for `picture`)
- [ ] Successful update refreshes the session's cached user fields so the UI
      reflects the change without re-login
- [ ] Email change endpoint sends an Auth0 verification email and returns
      202 with `{"verification_sent": true}` — no DB write to `users.email`
      until Auth0 webhook confirms
- [ ] Audit event `profile.account.updated` is emitted with the field diff
      (values redacted to length only)
- [ ] Frontend `AccountTab.vue` form uses optimistic update + error rollback

## 4. Self-Service Security

<!-- canon:system:4 status:draft -->

### 4.1 Password reset (self-serve)

<!-- canon:system:4.1 status:done -->
<!-- canon:realized-in: file:src/canon/web/profile_routes.py request_self_password_reset -->
<!-- canon:realized-in: file:frontend/src/components/profile/SecurityPasswordCard.vue -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py TestSecurityPasswordReset -->

Move the admin password-reset endpoint behind a self-serve wrapper:
`POST /app/{org}/api/profile/security/password-reset` requires only an
authenticated session, scoped to the caller's own `oidc_sub`. The endpoint
returns the Auth0 ticket URL (same shape as the admin endpoint) but the UI
prefers the Auth0-hosted email flow — i.e., we show "We sent an email to
`<email>`" and only surface the ticket URL in dev mode.

### 4.2 Active sessions

<!-- canon:system:4.2 status:done -->
<!-- canon:realized-in: file:src/canon/web/profile_routes.py list_security_sessions revoke_security_session revoke_other_security_sessions -->
<!-- canon:realized-in: file:frontend/src/components/profile/SecuritySessionsCard.vue -->
<!-- canon:realized-in: file:frontend/src/api/profile_security.ts -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py TestSecuritySessions -->

Add `GET /app/{org}/api/profile/security/sessions` returning every
non-revoked, non-expired row in `sessions` for the current user, with
`device_label`, `created_at`, `last_used_at`, and a derived `is_current`
flag (matches the request's session cookie).

`DELETE /app/{org}/api/profile/security/sessions/{id}` calls
`SessionStore.revoke_session(session_id, user_id)`.

`POST /app/{org}/api/profile/security/sessions/revoke-others` calls
`SessionStore.revoke_all_sessions(user_id, except_session_id=current)` and
returns the count.

### 4.3 User-scoped API keys

<!-- canon:system:4.3 status:done -->
<!-- canon:realized-in: file:src/canon/web/profile_routes.py list_profile_api_keys create_profile_api_key revoke_profile_api_key -->
<!-- canon:realized-in: file:frontend/src/components/profile/SecurityApiKeysCard.vue -->
<!-- canon:realized-in: file:frontend/src/router/guards.ts requiresOrgAdmin -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py TestProfileApiKeys -->

Re-home the API-keys UI under Profile → Security and drop the `org:manage`
guard for the read/create/revoke endpoints scoped to the caller's own
`user_id`. Keep the admin-side org-wide view (`list_api_keys_for_admin`)
behind `org:manage`. Permission shape:

- `POST /api/profile/security/api-keys` — caller's keys only, no admin check
- `GET  /api/profile/security/api-keys` — caller's keys only
- `DELETE /api/profile/security/api-keys/{id}` — caller's keys only
- Existing `/api/admin/users/{id}/api-keys` endpoints unchanged

### Acceptance Criteria

- [x] Self-serve password reset works for non-admin users; admin endpoint
      remains usable for cross-user resets
<!-- canon:realized-in: file:src/canon/web/profile_routes.py request_self_password_reset -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py TestSecurityPasswordReset -->
- [x] Sessions list renders device label, last-used relative time, and a
      "This device" badge for the current session
<!-- canon:realized-in: file:frontend/src/components/profile/SecuritySessionsCard.vue -->
- [x] "Sign out everywhere else" revokes all other sessions and shows the
      revoked count in a toast. The button is only offered when a current
      session row is identifiable; the backend refuses with 409 otherwise,
      so a browser caller (whose Starlette session isn't in the `sessions`
      table) revokes CLI rows individually instead of batch-nuking them.
<!-- canon:realized-in: file:frontend/src/components/profile/SecuritySessionsCard.vue revokeOthers -->
<!-- canon:realized-in: file:src/canon/web/profile_routes.py revoke_other_security_sessions -->
- [x] Revoking the current session is not exposed in the card — users go
      through the global `/auth/logout` link in the navbar instead. The
      sessions table only tracks CLI device-flow logins today, so the
      "current" row in the table is normally absent for browser callers.
<!-- canon:realized-in: file:frontend/src/components/profile/SecuritySessionsCard.vue is_current-hides-revoke -->
- [x] Non-admin users can create, view, and revoke their own API keys from
      Profile → Security; the Settings → API Keys tab redirects there
      (Settings → API Keys becomes the org-wide admin view)
<!-- canon:realized-in: file:frontend/src/components/profile/SecurityApiKeysCard.vue -->
<!-- canon:realized-in: file:frontend/src/router/guards.ts requiresOrgAdmin -->
- [x] Session-revoke actions emit `profile.session.revoked` and
      `profile.session.revoked_all` audit events. Password-reset and
      api-key audit events land with T6 and T7.
<!-- canon:realized-in: file:src/canon/web/profile_routes.py _emit_profile_audit -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py test_revoke_emits_audit_event -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py test_revoke_others_emits_audit_event -->

## 5. Notification Preferences

<!-- canon:system:5 status:draft -->

Persist per-user, per-org preferences in a new `user_preferences` table:

```sql
CREATE TABLE user_preferences (
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    org_login       TEXT   NOT NULL,
    -- notifications
    slack_dm_enabled            BOOLEAN  NOT NULL DEFAULT TRUE,
    slack_dm_pr_comments        BOOLEAN  NOT NULL DEFAULT TRUE,
    slack_dm_spec_drift         BOOLEAN  NOT NULL DEFAULT TRUE,
    email_digest_cadence        TEXT     NOT NULL DEFAULT 'weekly',
    email_pr_comments           BOOLEAN  NOT NULL DEFAULT FALSE,
    -- appearance / locale (see §7)
    theme                       TEXT     NOT NULL DEFAULT 'system',
    timezone                    TEXT     NOT NULL DEFAULT '',
    relative_time               BOOLEAN  NOT NULL DEFAULT TRUE,
    -- bookkeeping
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, org_login)
);
```

Per-org rows so a user can mute one org without muting another.
`email_digest_cadence` ∈ {`off`, `daily`, `weekly`}.

### Acceptance Criteria

- [x] Migration `0018_user_preferences.py` creates the table and adds an
      `idx_user_preferences_user_id` index
<!-- canon:realized-in: file:src/canon/db/migrations/versions/0018_user_preferences.py -->
- [x] `UserPreferencesStore` exposes `get(user_id, org_login)` (auto-creates
      defaults), `update(user_id, org_login, patch: dict)`
<!-- canon:realized-in: file:src/canon/db/user_preferences_store.py -->
<!-- canon:realized-in: file:tests/test_db/test_user_preferences_store.py -->
<!-- canon:realized-in: file:src/canon/main.py app.state.user_preferences_store -->
- [x] `GET/PATCH /app/{org}/api/profile/notifications` reads/writes the
      notification fields
<!-- canon:realized-in: file:src/canon/web/profile_routes.py get_notifications update_notifications -->
<!-- canon:realized-in: file:tests/integration/test_profile_settings.py TestNotifications -->
- [ ] Slack DM dispatcher (`src/canon/slack/`) consults
      `slack_dm_enabled` AND the per-category flag before sending; missing
      row treated as defaults (dispatcher wiring deferred until the Slack
      worker module re-lands; preferences row already exists)
- [ ] Email digest cron job filters by `email_digest_cadence` and skips
      users with `'off'` (digest cron wiring deferred to the digests epic)
- [x] `NotificationsTab.vue` shows grouped toggles with optimistic update
      and inline "Saved" indicator
<!-- canon:realized-in: file:frontend/src/views/profile/NotificationsTab.vue -->
<!-- canon:realized-in: file:frontend/src/api/profile_preferences.ts -->

## 6. Linked Accounts

<!-- canon:system:6 status:done -->

Expose every identity Canon already correlates with the user, with a
re-link/unlink affordance where the underlying provider supports it.

### 6.1 GitHub

<!-- canon:system:6.1 status:draft -->

Show GitHub login, name, and "Last refreshed" timestamp. "Re-link GitHub"
button kicks off `/auth/github` to refresh the OAuth token (already exists
under `src/canon/auth/github_oauth.py`).

### 6.2 Slack

<!-- canon:system:6.2 status:draft -->

Show Slack user (if any) and team. "Link Slack" runs the existing Slack
OAuth flow; "Unlink Slack" deletes the row from the Slack identity store.

### 6.3 Identity provider

<!-- canon:system:6.3 status:draft -->

Display the Auth0 connection type (`github`, `google-oauth2`,
`email-password`) so users know which credentials sign them in.

### Acceptance Criteria

- [ ] `GET /app/{org}/api/profile/linked` returns
      `{github: {...}|null, slack: {...}|null, idp_connection: str}`
- [ ] "Re-link GitHub" round-trip refreshes the token and shows updated
      `last_refreshed_at`
- [ ] Unlinking Slack disables Slack DM dispatch for the user
- [ ] IdP connection is read-only (changing it requires admin)

## 7. Appearance & Locale Preferences

<!-- canon:system:7 status:done -->

Theme, timezone, and relative-time toggle persist on the same
`user_preferences` row from §5.

### Acceptance Criteria

- [x] Theme stored on the server overrides browser `localStorage` on load;
      `localStorage` keeps acting as the offline fallback (server state is
      the source of truth read by `PreferencesTab`; full wiring into the
      existing theme store is a follow-up)
<!-- canon:realized-in: file:src/canon/web/profile_routes.py get_preferences update_preferences -->
- [x] Timezone defaults to the value reported by `Intl.DateTimeFormat`
      on first visit; user can override with an IANA picker
<!-- canon:realized-in: file:frontend/src/views/profile/PreferencesTab.vue browserTimezone -->
- [ ] All "5 minutes ago" / "2 days ago" formatters in the frontend respect
      the `relative_time` toggle (toggle persists; threading the value
      through every formatter is a follow-up — see frontend TODO)
- [x] `PreferencesTab.vue` exposes all three controls with a "Reset to
      defaults" link
<!-- canon:realized-in: file:frontend/src/views/profile/PreferencesTab.vue resetDefaults -->

## 8. Account Lifecycle — Export & Delete

<!-- canon:system:8 status:draft -->

### 8.1 Data export

<!-- canon:system:8.1 status:draft -->

`POST /app/{org}/api/profile/danger/export` enqueues a background job that
collects the user's records across `users`, `sessions`, `api_keys` (hashes
only), `user_preferences`, `audit_events` (rows where `actor_sub` matches),
and `realization_evidence` authored by the user, packages them as JSON,
uploads to S3-compatible storage with a 7-day signed URL, and emails the
user the link.

Cron job `cleanup_export_artifacts` removes expired exports.

### 8.2 Self-service account delete

<!-- canon:system:8.2 status:draft -->

`DELETE /app/{org}/api/profile/danger` re-uses
`AdminStore.delete_user_atomic` with these guards:

- Body must contain `confirm` equal to the user's email
- Block delete if the user is the **sole** super-admin or sole org admin in
  any org they belong to — the response 409s with a list of orgs needing
  admin transfer first
- Block delete in self-hosted single-tenant deploys that haven't opted in
  (`SETTINGS.allow_self_serve_delete`, default True in cloud, False in OSS)
- Emit `profile.account.deleted` audit event with snapshot
- Redirect to `/auth/logout` on success

### Acceptance Criteria

- [ ] Export endpoint is idempotent per user (returns existing job if one is
      already pending) and rate-limited to 1 export per 24h per user
- [ ] Export bundle is valid JSON and round-trips through `json.loads`
- [ ] Delete endpoint refuses with 409 and a clear message when the caller
      is the only admin of any org
- [ ] Delete endpoint refuses with 400 when `confirm` doesn't match email
- [ ] On success, `delete_user_atomic`'s Auth0 rollback semantics still
      apply (no orphaned IdP user, no orphaned DB user)
- [ ] `DangerZoneTab.vue` shows both actions with red-tinted destructive
      buttons and a typed-confirmation modal

## 9. Backend API Shape Summary

<!-- canon:system:9 status:draft -->

All routes under `/app/{org}/api/profile/*`, mounted in `profile_routes.py`.

| Method | Path                                              | Permission           |
|--------|---------------------------------------------------|----------------------|
| GET    | `/api/profile`                                    | `specs:read` (existing) |
| GET    | `/api/profile/account`                            | self                 |
| PATCH  | `/api/profile/account`                            | self                 |
| POST   | `/api/profile/account/email`                      | self                 |
| POST   | `/api/profile/security/password-reset`            | self                 |
| GET    | `/api/profile/security/sessions`                  | self                 |
| DELETE | `/api/profile/security/sessions/{id}`             | self                 |
| POST   | `/api/profile/security/sessions/revoke-others`    | self                 |
| GET    | `/api/profile/security/api-keys`                  | self                 |
| POST   | `/api/profile/security/api-keys`                  | self                 |
| DELETE | `/api/profile/security/api-keys/{id}`             | self                 |
| GET    | `/api/profile/notifications`                      | self                 |
| PATCH  | `/api/profile/notifications`                      | self                 |
| GET    | `/api/profile/linked`                             | self                 |
| POST   | `/api/profile/linked/slack/unlink`                | self                 |
| GET    | `/api/profile/preferences`                        | self                 |
| PATCH  | `/api/profile/preferences`                        | self                 |
| POST   | `/api/profile/danger/export`                      | self                 |
| DELETE | `/api/profile/danger`                             | self                 |

"self" = authenticated session whose `oidc_sub` matches the resource's
owning user; no role check needed.

### Acceptance Criteria

- [ ] Every endpoint returns 401 for anonymous and 403 when an authenticated
      user tries to access a resource that isn't theirs
- [ ] OpenAPI schema is generated and surfaces these endpoints

## 10. Rollout Plan

<!-- canon:system:10 status:draft -->

1. **Migration + store** (§5): land `user_preferences` table behind a
   feature flag `profile_hub_enabled`; backend reads/writes guarded.
2. **API endpoints** (§3, §4, §5, §6, §7, §8): land routes incrementally
   with tests; existing `GET /api/profile` stays untouched.
3. **Frontend tab shell** (§2): convert `ProfileView.vue` to tabbed layout
   with only Overview live; new tabs hidden behind the flag.
4. **Per-tab UI**: ship Security → Notifications → Preferences → Account →
   Linked → Danger zone in that order (security before edit so we can ship
   sessions revocation as a safety net first).
5. **Flag flip**: enable `profile_hub_enabled` org-by-org via existing flag
   plumbing; remove flag after one release cycle.

## 11. Design Decisions

<!-- canon:system:11 status:draft -->

- **Preferences scope**: per (user, org). Composite PK `(user_id, org_login)`
  so a user can mute one org without affecting another. Default rows are
  lazy-created on first read.
- **Email-change verification**: Auth0 post-email-change Action POSTs to
  `/webhooks/auth0/email-changed`; backend validates the Action signature
  and updates `users.email`. Action deployment lives in `infra/modules/auth0/`.
- **Export storage**: reuse DOCR/Spaces. New bucket `canon-user-exports`
  provisioned via Terraform in `infra/modules/docr/` with a 7-day lifecycle
  rule. Signed URLs minted with a 7-day TTL matching the lifecycle.
- **API-keys tab migration**: move + redirect. Settings → API Keys becomes
  the admin org-wide view; non-admins visiting `/settings/api-keys` redirect
  to `/profile/security`. Frontend route guard checks `org:manage` and
  redirects on the negative path.

## 12. Open Questions

<!-- canon:system:12 status:draft -->

- For self-hosted deploys without Auth0 (generic OIDC), how do password
  reset and email change degrade? Likely: hide the controls, link to the
  external IdP — confirm during §3/§4 implementation.
- Should the org switcher move off the Profile Overview card into the
  navbar (cf. [[multi-org-personal-accounts]] §3.2)? Not in scope for v1,
  but flagged here so we don't double-build it.
- Notification email transport: re-use the existing email digest pipeline
  (Resend/Postmark — check `infra/modules/`), or a new dispatch path?
