---
title: "Terraform Credentials: Short-Lived Identity for infra/"
type: adr
status: draft
owner: ng
team: platform
review_status: draft
tags: [infra, terraform, aws, oidc, iam, doppler, security]
depends_on:
  - infra-enablement-billing-email
created: "2026-05-16"
updated: "2026-05-16"
---

# Terraform Credentials: Short-Lived Identity for infra/

## 1. Status

Draft. Not yet approved. Captured to record the trade-off identified while landing
the SES module (PR #776) so the decision isn't lost.

## 2. Context

Terraform under `infra/` provisions resources across multiple providers:
DigitalOcean (DOKS, DOCR), Stripe, Auth0, GCP, PostHog, OpenSearch, and now AWS
(SES, Route 53, IAM). The current pattern across all providers is:

> Operator runs `doppler run --config prd -- terraform apply` from their laptop.
> Each provider's credential lives in Doppler `canon/prd` as a long-lived
> `TF_VAR_*` (or provider-conventional env var: `STRIPE_SECRET_KEY`,
> `DIGITALOCEAN_TOKEN`, etc.).

For AWS specifically (introduced by `infra/modules/ses/`), this means a new
long-lived IAM user `canon-terraform-bootstrap` with permissions for
`ses:*`, `iam:CreateUser` / `iam:CreateAccessKey` / `iam:PutUserPolicy`, and
`route53:ChangeResourceRecordSets` on the canon zone. The access key sits in
Doppler indefinitely; rotation is manual.

The same pattern is used by every other provider, so AWS isn't the outlier —
but it is the trigger for re-examining the pattern, because AWS has the
broadest blast radius if a key leaks (the bootstrap user can mint other IAM
users, create access keys, alter DNS, send mail).

### 2.1 Prior Art in `gv-infra`

The sibling repo `gv-infra` already implements GHA OIDC role-assumption for
its AWS apply pipeline. `.github/workflows/{core,experiment}-{plan,apply}.yml`
use `aws-actions/configure-aws-credentials@v4` with `role-to-assume:
${{ secrets.AWS_ROLE_ARN }}`. The AWS OIDC provider, IAM role, and trust
policy permitting `repo:Gerner-Ventures/gv-infra:*` already exist in the
shared AWS account `052504386588` — the same account that owns the
`canonhq.co` Route 53 zone Canon writes DKIM CNAMEs into.

This materially changes the cost/risk calculus for canon-private: the
foundational pieces (OIDC provider in IAM, base trust patterns, S3 backend
access via DO Spaces, the `tfrun.sh` Doppler-to-`TF_VAR` mapping) are all
proven in the sibling repo. The canon-private migration becomes "extend the
trust policy to permit `repo:canonhq/canon-private:ref:refs/heads/main`" (or
create a sibling `canon-terraform-deploy` role) plus port the workflow file —
much smaller than greenfield OIDC setup.

## 3. Problem

Long-lived static credentials with broad permissions stored in Doppler create
risk that scales with the number of providers we add:

- **Blast radius**: a leaked key holds for as long as it takes someone to
  notice and rotate. Worst case (AWS): create users, mint keys, send mail,
  alter DNS — all before detection.
- **Rotation friction**: manual key rotation across 7 providers won't happen
  on a healthy cadence. The Stripe key in Doppler today is older than this
  repo.
- **Audit trail**: provider audit logs show "the canon-terraform user did
  this", not "Nick did this at 14:32 from his laptop". When multiple humans
  share the same key, attribution is lost.
- **Doppler as secret-store-of-last-resort**: any compromise of Doppler
  cascades into compromise of every provider. Today that's
  acceptable because Doppler is the only thing that holds them; with
  short-lived creds, Doppler holds trust *anchors* but not bearer tokens.

## 4. Decision (proposed)

Migrate `infra/` apply credentials from long-lived static keys to short-lived
credentials, scoped per-provider, with a single trust anchor per provider.

**Target shape:**

1. **Per-provider IAM role** (where the provider supports OIDC + IAM-equivalent):
   - AWS: IAM role `canon-terraform-deploy` with the bootstrap policy inline.
   - GCP: service account `canon-terraform@…` impersonated via workload-identity.
   - Anything else (Stripe, Auth0, DO, PostHog): keep static keys but rotate
     on a schedule; these providers don't have a role/OIDC story.
2. **Trust anchor**: GitHub Actions OIDC. The role's trust policy permits
   assume-role only from a specific GHA workflow + branch (`infra/main.yml`
   on `main`).
3. **Apply runs in CI**, not on laptops. The workflow:
   - Authenticates to AWS via `aws-actions/configure-aws-credentials@v4`
     using OIDC.
   - Runs `terraform plan` on PR, comments the plan back.
   - Runs `terraform apply` on merge to `main`.
4. **Laptop apply remains supported for emergencies** via SSO assume-role:
   operator runs `aws sso login` → `terraform apply`. No static keys ever
   on disk.

**Doppler retains**: provider creds that have no OIDC story (Stripe, DO,
Auth0, PostHog), but flagged for periodic rotation.

## 5. Consequences

**Positive:**
- No long-lived AWS/GCP credentials anywhere.
- Apply is gated by GitHub branch protection — no one applies infra without
  a merged PR.
- CloudTrail / GCP audit logs attribute changes to the specific GHA run +
  triggering commit.
- Failed/aborted applies don't leave stale creds on a developer's machine.

**Negative:**
- Initial setup work: GHA workflow, role trust policy update or new role,
  porting `tfrun.sh`-equivalent for canon-private's Doppler project. Lower
  than greenfield given gv-infra's prior art — closer to half a day than
  two days, dominated by testing the apply path end-to-end.
- Emergency apply path requires AWS SSO (or temporary admin role) — a step
  more than `doppler run`.
- Plan output in PR comments may leak resource names/IDs publicly; the repo
  is private but worth verifying.
- Doesn't help the providers without OIDC (Stripe/DO/Auth0/PostHog) — those
  remain static keys, just with rotation discipline.

## 6. Alternatives Considered

**A. Manual IAM user, static key in Doppler (status quo)**
Lowest setup cost; matches existing pattern for other providers. Used for the
short-term path while SES is unblocked. Long-term: same blast-radius problem
this ADR is trying to address.

**B. IaC the bootstrap IAM user via `infra/modules/aws-bootstrap/`**
Apply once with admin creds, then check in. Cleaner than (A) because the
user's policy is reviewable in git. Still long-lived keys. Doesn't solve
the rotation or audit-trail problem.

**C. AWS SSO only (no GHA)**
Operator uses SSO to assume role at apply time. No static keys, but apply
is still laptop-driven — no automatic plan-on-PR, no audit trail tied to
PR merges. Reasonable middle ground if GHA OIDC setup proves heavyweight.

**D. HashiCorp Vault as broker**
Vault issues short-lived creds for each provider on demand. Best-in-class
but adds an entire new system to run. Overkill for current scale.

## 7. Short-Term Path

While this ADR is in `draft`, AWS provisioning under `infra/modules/ses/`
uses Option A:

1. Manual IAM user `canon-terraform-bootstrap` in the AWS account.
2. Inline policy: `ses:*`, `iam:*` scoped to users with name `canon-ses-*`,
   `route53:ChangeResourceRecordSets` on zone `Z03344451DPT3I6Y2WA1U`.
3. Access key stored in Doppler `canon/prd` as `AWS_ACCESS_KEY_ID` /
   `AWS_SECRET_ACCESS_KEY`.
4. Documented as temporary in `infra/README.md` with a pointer to this ADR.

## 8. Implementation (when accepted)

#### Acceptance Criteria

- [ ] GHA workflow `infra-apply.yml` runs `terraform plan` on PRs touching
      `infra/**` and comments the plan.
- [ ] Same workflow runs `terraform apply` on merge to `main`, gated on
      manual approval.
- [ ] AWS OIDC provider exists in the AWS account (provisioned via the
      bootstrap module or manually, once).
- [ ] `canon-terraform-deploy` IAM role exists with trust policy scoped to
      the GHA workflow and `repo:canonhq/canon-private:ref:refs/heads/main`.
- [ ] No `TF_VAR_aws_*` or `AWS_ACCESS_KEY_*` secrets remain in Doppler
      `canon/prd` after migration.
- [ ] `infra/README.md` documents both CI apply (default) and SSO-based
      emergency apply.
- [ ] Manual IAM user `canon-terraform-bootstrap` is deleted after
      migration; the SES module's `canon-ses-smtp` user is unaffected.

## 9. Open Questions

- **Shared role vs. sibling role.** Should canon-private's apply assume the
  *same* role as gv-infra (one role, trust policy widened to two repos), or
  a sibling `canon-terraform-deploy` role with its own policy scoped only to
  Canon's resources (SES, SES SMTP IAM user, DKIM records in zone
  `Z03344451DPT3I6Y2WA1U`)? Sibling role gives tighter blast-radius
  containment but doubles the IaC to maintain. Default proposal: sibling
  role with a narrow inline policy.
- Does the laptop-emergency path use the same role (assume from SSO) or a
  separate `canon-terraform-break-glass` role with audit alerting?
- For GCP, do we use workload identity federation from GHA, or a service-
  account key in Doppler until GCP usage actually grows?
- Should provider static keys (Stripe, DO, Auth0, PostHog) move out of
  Doppler into 1Password with a Doppler-fetch script, or stay where they
  are? Out of scope for this ADR, but worth a follow-up.
