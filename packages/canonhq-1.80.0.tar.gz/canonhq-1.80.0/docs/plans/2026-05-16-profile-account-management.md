---
title: "Profile & Account Management"
spec: docs/specs/profile-account-management.md
status: draft
created: "2026-05-16"
---

# Implementation Plan: Profile & Account Management

Executes the spec in 13 tasks. T1 + T2 are foundation and can land in
parallel. T3-T12 all depend on T1; pick up in the recommended order
(T5 → T6 → T7 → T3 → T4 → T8 → T10 → T9 → T11 → T12). T13 is cleanup.

Feature flag `profile_hub_enabled` (settings + frontend `useAuthStore`)
gates every new tab and route. Set default to `False` until T13.

---

## Task 1 — Tabbed Profile shell + feature flag

**ACs:** §2.1 all four bullets, §2 router/breadcrumb wiring

**Files:**
- `EDIT frontend/src/views/ProfileView.vue` — convert from single-card to
  tabbed shell mirroring `SettingsView.vue` (lines 14-86). Tabs:
  `overview`, `account`, `security`, `notifications`, `linked`,
  `preferences`, `danger`. Build `tabs` computed from
  `useAuthStore().featureFlags.profile_hub_enabled` — if flag off, return
  only `overview`. Active tab derived from `route.name`. Mobile
  `<select>` fallback identical to `SettingsView.vue`.
- `CREATE frontend/src/views/profile/ProfileOverviewTab.vue` — move
  current `ProfileCard` rendering out of `ProfileView.vue` into this
  child route component.
- `CREATE frontend/src/views/profile/AccountTab.vue` — stub returning
  `<div>Account (T8)</div>`.
- `CREATE frontend/src/views/profile/SecurityTab.vue` — stub for T5/T6/T7.
- `CREATE frontend/src/views/profile/NotificationsTab.vue` — stub for T3.
- `CREATE frontend/src/views/profile/LinkedTab.vue` — stub for T10.
- `CREATE frontend/src/views/profile/PreferencesTab.vue` — stub for T4.
- `CREATE frontend/src/views/profile/DangerZoneTab.vue` — stub for T11/T12.
- `EDIT frontend/src/router/index.ts` — change `/app/:org/profile` from
  flat route to nested with `children` matching the 7 tabs:
  ```ts
  { path: 'profile', component: ProfileView, children: [
      { path: '', name: 'profile', component: ProfileOverviewTab },
      { path: 'account', name: 'profile-account', ... },
      ... etc
  ]}
  ```
- `EDIT frontend/src/components/layout/Breadcrumb.vue` — extend the
  `name === 'profile'` branch (line 35) to handle
  `profile-account`, `profile-security`, etc., returning
  `[...base, { label: 'Profile', to: …profile }, { label: <tab name> }]`.
- `EDIT src/canon/settings.py` — add `profile_hub_enabled: bool = False`.
- `EDIT src/canon/web/profile_routes.py` — add `GET /app/{org}/api/profile/features`
  returning `{"profile_hub_enabled": settings.profile_hub_enabled}` so
  the frontend store can read it.
- `EDIT frontend/src/stores/auth.ts` — fetch and expose
  `featureFlags.profile_hub_enabled`.

**Tests:**
- `CREATE tests/web/test_profile_routes_features.py` — assert
  `/api/profile/features` returns the flag and respects env override.
- Frontend: manual smoke (no Vue test infra wired for nested routes today).

**Verify:**
```bash
uv run pytest tests/web/test_profile_routes_features.py -v
uv run ruff check src/canon/web/profile_routes.py
```

---

## Task 2 — `user_preferences` table + store

**ACs:** §5 first bullet (migration), §5 second bullet (store)

**Files:**
- `CREATE src/canon/db/migrations/versions/0018_user_preferences.py` —
  Alembic migration creating `user_preferences` per spec §5 SQL,
  `idx_user_preferences_user_id` index. Downgrade drops table + index.
- `CREATE src/canon/db/user_preferences_store.py` — `UserPreferencesStore`
  class wrapping an `asyncpg.Pool`:
  - `async def get(self, user_id: int, org_login: str) -> dict` — `SELECT … WHERE user_id=$1 AND org_login=$2`; if no row, `INSERT … DEFAULT VALUES RETURNING *` then return.
  - `async def update(self, user_id: int, org_login: str, patch: dict) -> dict` — dynamic `UPDATE` of only the keys in `patch` (whitelist against allowed columns), bumps `updated_at`, `RETURNING *`. Lazy-creates the row first by calling `self.get()` if missing.
  - Column allow-list: `{slack_dm_enabled, slack_dm_pr_comments, slack_dm_spec_drift, email_digest_cadence, email_pr_comments, theme, timezone, relative_time}`.
- `EDIT src/canon/main.py` — instantiate `UserPreferencesStore` on app
  startup and attach to `app.state.user_preferences_store` (search for
  where `UserStore` is wired — same pattern).

**Tests:**
- `CREATE tests/db/test_user_preferences_store.py` — integration test
  against the real Postgres (follow `tests/db/test_user_store.py` pattern):
  - `test_get_creates_default_row` — first read returns defaults and the
    row exists in the DB.
  - `test_update_partial_patch` — patching one field leaves others at
    default.
  - `test_update_rejects_unknown_column` — passing a key not in the
    allow-list raises `ValueError`.
  - `test_per_org_isolation` — same user, two orgs, independent state.

**Verify:**
```bash
devbox run integration -- tests/db/test_user_preferences_store.py
uv run ruff check src/canon/db/user_preferences_store.py
```

---

## Task 3 — Notifications tab

**ACs:** §5 third bullet (routes), §5 fourth bullet (Slack), §5 fifth bullet (email digest), §5 sixth bullet (UI)

**Files:**
- `EDIT src/canon/web/profile_routes.py` — add:
  - `GET /app/{org}/api/profile/notifications` — returns
    `{slack_dm_enabled, slack_dm_pr_comments, slack_dm_spec_drift,
    email_digest_cadence, email_pr_comments}` from
    `user_preferences_store.get(user.id_in_db, org)`.
  - `PATCH /app/{org}/api/profile/notifications` — body is
    `NotificationPreferencesPatch` Pydantic model with all 5 fields
    optional; validates `email_digest_cadence ∈ {'off','daily','weekly'}`;
    calls `update()`; returns the new row.
- `CREATE src/canon/web/models_notifications.py` (or extend
  `src/canon/web/models.py`) — `NotificationPreferences`,
  `NotificationPreferencesPatch` Pydantic models.
- `EDIT src/canon/slack/dispatch.py` (or whichever file sends DMs —
  grep for `slack.*send_message` in `src/canon/slack/`) — before each
  send, fetch `user_preferences_store.get(...)`; skip if
  `slack_dm_enabled is False` or the category flag is False.
- `EDIT src/canon/cron/digests.py` (or equivalent — grep for "digest" in
  `src/canon/cron/`) — filter users by
  `email_digest_cadence != 'off'` and respect cadence.
- `EDIT frontend/src/views/profile/NotificationsTab.vue` — replace stub
  with grouped toggle UI:
  - Slack section: 3 toggles (enabled + 2 categories).
  - Email section: cadence `<select>` + 1 toggle.
  - Each toggle uses `useMutation` + optimistic update; inline "Saved"
    badge on success.
- `CREATE frontend/src/api/profile_notifications.ts` —
  `fetchNotifications(org)`, `updateNotifications(org, patch)`.

**Tests:**
- `CREATE tests/web/test_profile_notifications.py` —
  - `GET` returns defaults for a fresh user.
  - `PATCH` with valid body persists.
  - `PATCH` with `email_digest_cadence='yearly'` returns 422.
  - Anonymous request returns 401.
- `EDIT tests/slack/test_dispatch.py` — add a case where
  `slack_dm_enabled=False` and assert no API call.

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_notifications.py tests/slack/test_dispatch.py
```

---

## Task 4 — Preferences tab (appearance + locale)

**ACs:** §7 all four bullets

**Files:**
- `EDIT src/canon/web/profile_routes.py` —
  - `GET /app/{org}/api/profile/preferences` — returns
    `{theme, timezone, relative_time}` from `user_preferences_store`.
  - `PATCH /app/{org}/api/profile/preferences` — validates `theme ∈
    {'system','light','dark'}`, `timezone` is a valid IANA zone (use
    `zoneinfo.available_timezones()`), `relative_time` is a bool.
- `EDIT frontend/src/views/profile/PreferencesTab.vue` — three controls:
  - Theme: 3-button segmented control (System / Light / Dark).
  - Timezone: `<select>` with `Intl.supportedValuesOf('timeZone')` as
    options; "Use browser default" preset.
  - Relative time: toggle.
  - "Reset to defaults" link calls `PATCH` with `{theme:'system',
    timezone:'', relative_time:true}`.
- `EDIT frontend/src/stores/preferences.ts` (CREATE if missing) — Pinia
  store mirroring server preferences; on app load, fetch from server and
  override `localStorage` theme.
- `EDIT frontend/src/composables/useTheme.ts` (or wherever theme lives —
  grep for `theme-toggle`) — read from preferences store first,
  `localStorage` second.
- `EDIT` every component using relative-time formatting — search for
  `formatDistanceToNow|relative` in `frontend/src/` and wrap with a
  shared `formatTime(date)` util that consults `preferences.relative_time`.

**Tests:**
- `CREATE tests/web/test_profile_preferences.py` —
  - `PATCH` with invalid IANA zone returns 422.
  - `PATCH` with valid bundle persists.
- Frontend: manual smoke (toggle theme, refresh, persists).

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_preferences.py
```

---

## Task 5 — Security tab: sessions

**ACs:** §4.2 all bullets

**Files:**
- `EDIT src/canon/db/session_store.py` — add
  `async def list_sessions(self, *, user_id: int) -> list[dict]` —
  `SELECT id, device_label, created_at, last_used_at FROM sessions
  WHERE user_id=$1 AND revoked_at IS NULL AND expires_at > now() ORDER BY last_used_at DESC`.
- `EDIT src/canon/web/profile_routes.py` —
  - `GET /app/{org}/api/profile/security/sessions` — calls
    `list_sessions`; resolves `current_session_id` from
    `request.session.get('session_id')`; marks `is_current` on the
    matching row.
  - `DELETE /app/{org}/api/profile/security/sessions/{id}` — calls
    `session_store.revoke_session(session_id=id, user_id=user.id_in_db)`;
    returns 204 on success, 404 if not found.
  - `POST /app/{org}/api/profile/security/sessions/revoke-others` —
    calls `revoke_all_sessions(user_id=..., except_session_id=current)`;
    returns `{"revoked": <count>}`.
- `CREATE frontend/src/components/profile/SecuritySessionsCard.vue` —
  table of sessions with device label, last-used relative time, "This
  device" badge for `is_current`, "Revoke" button per row, "Sign out
  everywhere else" button at bottom. Optimistic updates via
  `useMutation`.
- `EDIT frontend/src/views/profile/SecurityTab.vue` — render
  `<SecuritySessionsCard />` (the other security cards land in T6/T7).
- `CREATE frontend/src/api/profile_security.ts` — `fetchSessions(org)`,
  `revokeSession(org, id)`, `revokeOtherSessions(org)`.

**Tests:**
- `CREATE tests/web/test_profile_sessions.py` —
  - `GET` lists only non-revoked, non-expired sessions for the caller.
  - `is_current` flag matches the request's session cookie.
  - `DELETE` revokes; second `GET` excludes the row.
  - `POST revoke-others` leaves the current session intact.
  - Cross-user `DELETE` returns 404 (not 403, to avoid disclosing existence).

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_sessions.py
```

---

## Task 6 — Security tab: self-serve password reset

**ACs:** §4.1

**Files:**
- `EDIT src/canon/web/profile_routes.py` —
  - `POST /app/{org}/api/profile/security/password-reset` — re-uses the
    Auth0 ticket logic from `src/canon/admin/routes.py` (search for
    `password-reset` around line 750-798); strips the admin check; scopes
    target user to `user.id_in_db` from the session; emits audit event
    `profile.password_reset`. In production, returns
    `{"email_sent": true}` (Auth0 sends the email automatically); in dev
    mode (`settings.environment == "dev"`), also returns `ticket_url`.
- `CREATE frontend/src/components/profile/SecurityPasswordCard.vue` —
  single button "Send password reset email"; on click, POSTs and shows
  "We sent a reset link to `<email>`." If response includes `ticket_url`
  (dev mode), shows a "Open ticket (dev)" link.
- `EDIT frontend/src/views/profile/SecurityTab.vue` — add
  `<SecurityPasswordCard />` above sessions.
- `EDIT frontend/src/api/profile_security.ts` — add
  `requestPasswordReset(org)`.

**Tests:**
- `EDIT tests/web/test_profile_sessions.py` (or new file) —
  - `POST password-reset` returns 200 with `email_sent: true` for
    authenticated user; audit event recorded.
  - Auth0 provider error (`HTTPException 502`) bubbles as 502.
  - Generic OIDC provider returns 501 with "self-serve password reset
    not supported by this identity provider" message.

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_password_reset.py
```

---

## Task 7 — Security tab: user-scoped API keys + Settings redirect

**ACs:** §4.3 all bullets

**Files:**
- `EDIT src/canon/web/profile_routes.py` —
  - `GET /app/{org}/api/profile/security/api-keys` — calls
    `user_store.list_api_keys(user_id=user.id_in_db, org_login=org)`.
  - `POST /app/{org}/api/profile/security/api-keys` — body
    `{label, scopes, expires_at}`; calls
    `user_store.create_api_key(user_id=..., org_login=org, ...)`;
    returns `{raw_key, key}` — the raw key shown once.
  - `DELETE /app/{org}/api/profile/security/api-keys/{id}` — calls
    `user_store.revoke_api_key(key_id=id, user_id=..., org_login=org)`;
    returns 204 or 404.
  - All three emit audit events
    (`profile.api_key.{created,viewed,revoked}`).
- `EDIT src/canon/auth/api_key_routes.py` — keep existing
  `/api-keys` routes for backward compatibility but tag them deprecated;
  do **not** remove until T13.
- `CREATE frontend/src/components/profile/SecurityApiKeysCard.vue` —
  re-uses the existing key-creation modal logic from
  `frontend/src/views/settings/SettingsApiKeysTab.vue` (extract to a
  shared `ApiKeyCreateModal.vue` if it isn't already). Lists user's own
  keys with last-used, scopes, revoke action.
- `EDIT frontend/src/views/profile/SecurityTab.vue` — add
  `<SecurityApiKeysCard />`.
- `EDIT frontend/src/router/index.ts` — add `beforeEnter` guard on the
  `/settings/api-keys` route: if
  `!auth.hasPermission('org:manage')`, redirect to
  `/app/${org}/profile/security`.
- `EDIT frontend/src/views/SettingsView.vue` — when the flag is on,
  rename the "API Keys" tab label to "Org API Keys (admin)" and
  conditionally show only for admins (it already is — confirm at lines 14-27).

**Tests:**
- `CREATE tests/web/test_profile_api_keys.py` —
  - Non-admin can `POST/GET/DELETE` their own keys.
  - User A cannot see / revoke User B's keys.
  - Existing admin endpoints continue to work.
- Frontend: manual smoke that non-admin redirect from `/settings/api-keys`
  lands on `/profile/security` with the keys section visible.

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_api_keys.py
```

---

## Task 8 — Account tab: editable identity (name/nickname/picture)

**ACs:** §3.1, §3.2 (name/nickname/picture only — email defers to T9)

**Files:**
- `EDIT src/canon/auth/providers/protocol.py` — add
  ```python
  async def update_user(self, user_id: str, patch: dict) -> dict: ...
  ```
  to `OIDCProviderProtocol`.
- `EDIT src/canon/auth/providers/auth0.py` — implement `update_user`
  calling `PATCH https://{domain}/api/v2/users/{user_id}` with the
  Management API token (re-use the helper that backs `delete_user`).
  Strip any keys not in `{'name', 'nickname', 'picture', 'email'}`.
- `EDIT src/canon/auth/providers/generic_oidc.py` — raise
  `NotImplementedError("Profile editing requires Auth0; configure Auth0 provider")`.
- `EDIT src/canon/web/profile_routes.py` —
  - `GET /app/{org}/api/profile/account` — returns the editable subset
    from the session + `users` row.
  - `PATCH /app/{org}/api/profile/account` — body `AccountPatch` model
    (`name?`, `nickname?`, `picture?`), validates max-length 100 +
    https-only URL for picture; calls `provider.update_user(user.sub, patch)`;
    on success, updates the cached session fields and refreshes the
    `users` row; emits `profile.account.updated` audit event.
  - Returns 501 if provider raises `NotImplementedError`.
- `CREATE src/canon/web/models_account.py` — `AccountResponse`,
  `AccountPatch` Pydantic models with field validators.
- `EDIT frontend/src/views/profile/AccountTab.vue` — form with three
  inputs (name, display name, picture URL) and live preview of avatar.
  On submit, optimistic update + rollback on error. Show banner
  explaining "Profile editing is disabled for non-Auth0 deploys" when
  the API returns 501.
- `CREATE frontend/src/api/profile_account.ts` — `fetchAccount(org)`,
  `updateAccount(org, patch)`.

**Tests:**
- `CREATE tests/web/test_profile_account.py` —
  - `PATCH` updates name; subsequent `GET /api/profile` reflects it.
  - `PATCH` with `picture: 'http://insecure'` returns 422.
  - Generic-OIDC fixture returns 501.
- `EDIT tests/auth/test_providers.py` — assert `Auth0Provider.update_user`
  calls the right endpoint with the right payload (mocked).

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_account.py tests/auth/test_providers.py
```

---

## Task 9 — Email-change verification flow

**ACs:** §3.2 (email half)

**Files:**
- `EDIT src/canon/web/profile_routes.py` —
  - `POST /app/{org}/api/profile/account/email` — body
    `{new_email: EmailStr}`; calls
    `provider.send_email_change_verification(user.sub, new_email)` (new
    provider method); returns 202 `{"verification_sent": true}`.
- `EDIT src/canon/auth/providers/protocol.py` — add
  `send_email_change_verification(user_id, new_email)` and document
  that the Auth0 implementation triggers an Action.
- `EDIT src/canon/auth/providers/auth0.py` — implement via Management
  API: `PATCH /api/v2/users/{id}` with `{email: new_email, email_verified: false}` then
  `POST /api/v2/jobs/verification-email` to dispatch the verification mail.
- `CREATE src/canon/auth/webhooks_routes.py` (or extend
  `src/canon/auth/routes.py`) —
  - `POST /webhooks/auth0/email-changed` — signature-verifies the
    payload using a shared secret in `settings.auth0_action_secret`;
    body shape `{user_id, new_email, verified_at}`; updates
    `users.email = new_email` for the matching `oidc_sub`; emits
    `profile.email.verified` audit event.
- `EDIT src/canon/main.py` — mount the webhooks router.
- `EDIT src/canon/settings.py` — add
  `auth0_action_secret: SecretStr | None = None`.
- `CREATE infra/modules/auth0/actions/post-email-change.js` — Auth0
  Action source; on `api.user.setEmail` flow completion, POST to
  `{CANON_BASE_URL}/webhooks/auth0/email-changed` with HMAC signature.
- `EDIT infra/modules/auth0/main.tf` — `auth0_action` resource for the
  post-email-change action and binding to the flow.
- `EDIT frontend/src/views/profile/AccountTab.vue` — add an "Email"
  field with a "Change email" button (separate from the main form); on
  click, prompt for new email and call the endpoint; show "We sent a
  verification link to `<new_email>`."

**Tests:**
- `CREATE tests/web/test_profile_email_change.py` —
  - `POST /account/email` returns 202; provider mock records the call.
  - Webhook with bad signature returns 401.
  - Webhook with good signature updates `users.email`.

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_email_change.py
cd infra && doppler run -- terraform plan -target=module.auth0
```

---

## Task 10 — Linked accounts tab

**ACs:** §6 all bullets

**Files:**
- `EDIT src/canon/web/profile_routes.py` —
  - `GET /app/{org}/api/profile/linked` — returns
    `{github, slack, idp_connection}`. GitHub from `request.session.get('github_user')`
    + `oauth_integrations.get_github_token_meta(user.sub)`. Slack from
    `slack_identity_store.get_by_user(user.sub)` (find the existing
    Slack identity store — grep `slack_identity` in `src/canon/slack/`).
    IdP connection inferred from `user.sub.split('|')[0]`.
  - `POST /app/{org}/api/profile/linked/slack/unlink` — deletes the
    Slack identity row; sets
    `user_preferences.slack_dm_enabled = False`; returns 204.
- `CREATE frontend/src/views/profile/LinkedTab.vue` — three cards
  (GitHub, Slack, IdP) with appropriate actions. Re-link GitHub button
  hits `/auth/github?redirect=/app/${org}/profile/linked`.
- `CREATE frontend/src/api/profile_linked.ts` — `fetchLinked(org)`,
  `unlinkSlack(org)`.

**Tests:**
- `CREATE tests/web/test_profile_linked.py` —
  - `GET` returns null for missing Slack, populated for present GitHub.
  - `POST slack/unlink` removes the row and disables `slack_dm_enabled`.

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_linked.py
```

---

## Task 11 — Danger zone: data export

**ACs:** §8.1 all bullets

**Files:**
- `EDIT infra/modules/docr/main.tf` (or whichever module owns Spaces
  buckets — search for `digitalocean_spaces_bucket` in `infra/`) — add
  `canon-user-exports` bucket with a 7-day lifecycle rule, private ACL.
- `EDIT infra/main.tf` — pass the new bucket name into the Helm chart
  values via `chart/canon/values.tfvars`.
- `EDIT chart/canon/values.yaml` and `chart/canon/templates/configmap.yaml` —
  expose `CANON_USER_EXPORTS_BUCKET` env var.
- `EDIT src/canon/settings.py` — add `user_exports_bucket: str = ""` and
  `user_export_rate_limit_hours: int = 24`.
- `CREATE src/canon/web/exports.py` — `UserExportJob` class:
  - `collect(user_id, org_login) -> dict` — gathers user-scoped rows
    from `users`, `sessions`, `api_keys` (hashes only, no raw),
    `user_preferences`, `audit_events`, `realization_evidence`.
  - `upload(payload: dict) -> str` — serializes JSON, uploads to
    `s3://{bucket}/exports/{user_id}/{uuid}.json`, returns presigned URL
    with 7-day TTL.
  - `email_signed_url(user_email, url)` — sends via the existing
    email transport.
- `CREATE src/canon/db/migrations/versions/0019_user_export_jobs.py` —
  small table `user_export_jobs(user_id, org_login, status, signed_url,
  created_at, expires_at, requested_at)` for idempotency + rate limiting.
- `EDIT src/canon/web/profile_routes.py` —
  - `POST /app/{org}/api/profile/danger/export` — checks rate limit (1
    per 24h per user) returning 429 with retry-after; checks for an
    in-flight job (status='pending') and returns 202 with that job; else
    inserts a new job and schedules
    `asyncio.create_task(UserExportJob().run(...))`.
- `CREATE src/canon/cron/cleanup_exports.py` — cron job that deletes
  `user_export_jobs` rows + S3 objects past `expires_at`. Register in
  `src/canon/cron/__init__.py` or wherever the cron registry lives.
- `EDIT chart/canon/templates/cronjob-cleanup-exports.yaml` — new
  K8s CronJob.
- `CREATE frontend/src/components/profile/DangerZoneExportCard.vue` —
  button "Export my data" → shows pending state → "We emailed you a
  link" toast. Disabled when rate-limited.

**Tests:**
- `CREATE tests/web/test_profile_export.py` —
  - `POST export` enqueues a job; second `POST` within 24h returns 429.
  - `UserExportJob.collect` returns valid JSON including each user-scoped
    table.
  - Cleanup job deletes expired rows.

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_export.py
cd infra && doppler run -- terraform plan
```

---

## Task 12 — Danger zone: self-serve account delete

**ACs:** §8.2 all bullets

**Files:**
- `EDIT src/canon/admin/store.py` — extract a helper
  `async def check_sole_admin_orgs(self, user_id: int) -> list[dict]`
  that returns orgs where the user is the only admin (used by both the
  self-serve flow and as a sanity check in the admin flow).
- `EDIT src/canon/web/profile_routes.py` —
  - `DELETE /app/{org}/api/profile/danger` — body `{confirm: str}`:
    - Validate `confirm == user.email` else 400.
    - Validate `settings.allow_self_serve_delete` else 403.
    - Call `admin_store.check_sole_admin_orgs(user.id_in_db)`; if
      non-empty, return 409 `{"sole_admin_of": [{org_login, ...}, ...]}`.
    - Call `admin_store.delete_user_atomic(user.id_in_db,
      auth0_delete=provider.delete_user)`.
    - Emit audit `profile.account.deleted`.
    - Return `{"deleted": true, "logout_url": "/auth/logout"}` so the
      frontend can hard-redirect.
- `EDIT src/canon/settings.py` — add
  `allow_self_serve_delete: bool = True` (override to `False` in OSS via
  CANON.yaml or env).
- `CREATE frontend/src/components/profile/DangerZoneDeleteCard.vue` —
  destructive red button "Delete my account" → typed-confirmation modal
  ("Type your email to confirm: `<email>`") → on 409, display the list of
  orgs needing admin transfer with links to `/app/{org}/admin/users`; on
  200, `window.location = '/auth/logout'`.
- `EDIT frontend/src/views/profile/DangerZoneTab.vue` — render
  `<DangerZoneExportCard />` then `<DangerZoneDeleteCard />`.

**Tests:**
- `CREATE tests/web/test_profile_delete.py` —
  - `DELETE` with wrong `confirm` returns 400.
  - Sole-admin user returns 409 with the org list.
  - Successful delete invokes `delete_user_atomic` and emits audit.
  - `allow_self_serve_delete=False` returns 403.
- `EDIT tests/admin/test_admin_store.py` — assert
  `check_sole_admin_orgs` correctness for 0 / 1 / N admin scenarios.

**Verify:**
```bash
devbox run integration -- tests/web/test_profile_delete.py tests/admin/test_admin_store.py
```

---

## Task 13 — Flag flip + cleanup

**ACs:** All — closes the spec by realizing every §

**Files:**
- `EDIT src/canon/settings.py` — flip `profile_hub_enabled` default to
  `True`.
- `EDIT src/canon/web/profile_routes.py` — remove
  `GET /api/profile/features` (frontend no longer reads it).
- `EDIT frontend/src/stores/auth.ts` — remove `profile_hub_enabled`
  branching.
- `EDIT frontend/src/views/ProfileView.vue` — drop the flag check, always
  show all 7 tabs.
- `EDIT src/canon/auth/api_key_routes.py` — delete deprecated user-key
  routes shadowed by Profile → Security.
- `EDIT frontend/src/router/index.ts` — confirm
  `/settings/api-keys` is admin-only; remove the redirect guard once
  Profile → Security is the canonical user-facing surface.
- `EDIT frontend/src/views/SettingsView.vue` — rename "API Keys" tab to
  "Org API Keys" permanently.
- `EDIT docs/specs/profile-account-management.md` — set frontmatter
  `status: done`; mark each `<!-- canon:system:N status:draft -->`
  → `done`; add `<!-- canon:realized-in:PR#... -->` lines on relevant
  ACs.
- `EDIT docs/specs/user-profile-page.md` — add a "Superseded by [[profile-account-management]]"
  note at the top of §1 (its ACs stay marked done).
- `EDIT docs-site/src/changelog.md` — add a v1.72 entry: "Profile &
  Account hub: editable identity, sessions, notifications, preferences,
  linked accounts, data export, account deletion."

**Tests:**
- Run the full suite end-to-end:
  ```bash
  devbox run test
  devbox run integration
  ```
- Manual: walk through every tab with a fresh user; trigger export +
  delete in a staging org.

**Verify:**
```bash
devbox run test
devbox run integration
uv run canon doctor
# /canon:verify --gate docs/specs/profile-account-management.md
```

---

## Cross-cutting checklist

- [ ] Every new route emits an audit event (per §3-§8 ACs).
- [ ] Every new route returns 401 anon and 403 cross-user.
- [ ] Every new tab has its own E2E happy-path smoke (manual is fine for
      v1).
- [ ] `uv run ruff check` clean.
- [ ] `uv run pytest` + `devbox run integration` green before T13.
- [ ] `canon:realized-in` evidence comments added on AC checkboxes during
      `/canon:verify`.

## Risk register

- **Auth0 Action latency** (T9) — if the Action fails to dispatch, email
  updates silently fail. Mitigation: cron reconciler as a fallback,
  added in T9 if time permits or in a follow-up.
- **API-keys redirect** (T7) — admins may bookmark
  `/settings/api-keys`. Mitigation: keep it functional, only change the
  default redirect for non-admins.
- **Export bundle PII** (T11) — JSON includes audit events with IPs.
  Mitigation: 7-day signed URL + lifecycle delete + private bucket; no
  public links.
- **Sole-admin block** (T12) — users may get stuck if every org they're
  in needs transfer. Mitigation: 409 response lists the orgs and links
  to the admin user-management page for transfer.
