"""Rich-enhanced logger with box-drawing file format and RichHandler console output."""
import logging
import os
from datetime import datetime
from typing import Optional

from rich.console import Console
from rich.logging import RichHandler

from .config import runtime_config_display_sections


class Logger:
    def __init__(self,
                 name: str = "ViT",
                 log_dir: str = "experiments/logs",
                 level: int = logging.INFO,
                 console: bool = True):
        self.name = name
        self.log_dir = log_dir
        self.level = level

        os.makedirs(log_dir, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = os.path.join(log_dir, f"{name}_{timestamp}.log")
        self.log_file = log_file

        logger_name = f"{name}:{os.path.abspath(log_dir)}"
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(level)
        self.logger.propagate = False

        for handler in list(self.logger.handlers):
            self.logger.removeHandler(handler)
            handler.close()

        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)

        if console:
            rich_handler = RichHandler(
                console=Console(stderr=True),
                show_time=True,
                show_path=False,
                markup=True,
            )
            rich_handler.setLevel(level)
            self.logger.addHandler(rich_handler)

    def info(self, message: str):
        self.logger.info(message)

    def debug(self, message: str):
        self.logger.debug(message)

    def warning(self, message: str):
        self.logger.warning(message)

    def error(self, message: str):
        self.logger.error(message)

    def critical(self, message: str):
        self.logger.critical(message)

    def log_config(self, config):
        sections = runtime_config_display_sections(config)

        # Suppress console output during config dump (Rich panel already shown at startup)
        console_handlers = [h for h in self.logger.handlers if isinstance(h, RichHandler)]
        for h in console_handlers:
            h.setLevel(logging.CRITICAL + 1)

        width = 60
        hline = "+" + "-" * (width - 2) + "+"

        self.info(hline)
        self.info("| {:<{w}} |".format("ViT Training Configuration", w=width - 4))
        self.info(hline)

        first = True
        for section_name, items in sections.items():
            if not first:
                self.info(hline)
            first = False
            self.info("| {:<{w}} |".format(section_name, w=width - 4))

            if isinstance(items, dict):
                for key, value in items.items():
                    dot_count = max(1, 20 - len(str(key)))
                    dots = "." * dot_count
                    val_str = str(value)
                    line = f"  {key} {dots} {val_str}"
                    if len(line) > width - 4:
                        line = line[:width - 7] + "..."
                    self.info("| {:<{w}} |".format(line, w=width - 4))

        self.info(hline)

        # Restore console handlers
        for h in console_handlers:
            h.setLevel(self.level)

    def log_metrics(self, metrics: dict, step: Optional[int] = None):
        prefix = f"[Step {step}] " if step is not None else ""
        parts = []
        for key, value in metrics.items():
            if isinstance(value, float):
                parts.append(f"{key}={value:.4f}")
            else:
                parts.append(f"{key}={value}")
        self.info(f"{prefix}{' | '.join(parts)}")

    def log_model_summary(self, model):
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

        self.info("+" + "-" * 46 + "+")
        self.info("| {:<{w}} |".format("Model Summary", w=46))
        self.info("+" + "-" * 46 + "+")
        self.info("| {:<{w}} |".format(f"  Type:            {type(model).__name__}", w=46))
        self.info("| {:<{w}} |".format(f"  Total params:    {total_params:,}", w=46))
        self.info("| {:<{w}} |".format(f"  Trainable:       {trainable_params:,}", w=46))
        self.info("| {:<{w}} |".format(f"  Size:            {total_params * 4 / 1024 / 1024:.2f} MB", w=46))
        self.info("+" + "-" * 46 + "+")


def get_logger(name: str = "ViT",
               log_dir: str = "experiments/logs",
               level: int = logging.INFO,
               console: bool = True) -> Logger:
    return Logger(name, log_dir, level, console)
