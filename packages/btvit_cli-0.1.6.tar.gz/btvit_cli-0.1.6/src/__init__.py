"""ViT医学影像分类项目 - 源代码包"""

__version__ = "0.1.6"
__author__ = "SuShuHeng"
__description__ = "基于PyTorch的ViT脑部肿瘤医学影像分类CLI"
