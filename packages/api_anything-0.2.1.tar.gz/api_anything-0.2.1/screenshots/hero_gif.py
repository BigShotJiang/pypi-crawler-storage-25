"""Hero GIF: playwright headless + Pillow, zero focus steal.

Captures 6 frames of the Gradio UI, composites an animated GIF, and
writes it to ``assets/hero.gif`` for the project README.
"""
from __future__ import annotations

import time
from pathlib import Path

from PIL import Image
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
FRAMES = ROOT / "screenshots" / "hero_frames"
ASSETS.mkdir(exist_ok=True)
FRAMES.mkdir(exist_ok=True)

URL = "http://127.0.0.1:7861"
VIEWPORT = {"width": 1280, "height": 720}
GIF_SIZE = (960, 540)  # 75% scale for smaller file
FRAME_DURATIONS_MS = [2200, 1500, 1500, 3200, 2200, 2200]  # per frame


def wait_tier_result(page) -> None:
    for _ in range(40):
        time.sleep(0.5)
        txt = page.evaluate("() => document.body.innerText.toLowerCase()")
        if "tier 1" in txt or "verdict" in txt:
            return


def capture_frames() -> list[Path]:
    paths: list[Path] = []
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport=VIEWPORT)
        page.goto(URL, wait_until="load", timeout=60000)
        time.sleep(3)

        # Frame 1: Dashboard
        f1 = FRAMES / "01_dashboard.png"
        page.screenshot(path=str(f1), full_page=False)
        paths.append(f1)
        print(f"  [frame 1] {f1.name}")

        # Frame 2: Tier Detection tab (empty)
        page.click("button[role='tab']:has-text('Tier Detection')")
        time.sleep(1.2)
        f2 = FRAMES / "02_tier_empty.png"
        page.screenshot(path=str(f2), full_page=False)
        paths.append(f2)
        print(f"  [frame 2] {f2.name}")

        # Frame 3: Input filled
        page.fill("input[placeholder*='ffmpeg']", "ffmpeg")
        time.sleep(0.6)
        f3 = FRAMES / "03_tier_filled.png"
        page.screenshot(path=str(f3), full_page=False)
        paths.append(f3)
        print(f"  [frame 3] {f3.name}")

        # Frame 4: Detect result
        page.click("button:has-text('Detect Tier')")
        wait_tier_result(page)
        time.sleep(0.8)
        f4 = FRAMES / "04_tier_result.png"
        page.screenshot(path=str(f4), full_page=False)
        paths.append(f4)
        print(f"  [frame 4] {f4.name}")

        # Frame 5: API Explorer
        page.click("button[role='tab']:has-text('API Explorer')")
        time.sleep(1.5)
        f5 = FRAMES / "05_explorer.png"
        page.screenshot(path=str(f5), full_page=False)
        paths.append(f5)
        print(f"  [frame 5] {f5.name}")

        # Frame 6: Back to Dashboard (closes the loop)
        page.click("button[role='tab']:has-text('Dashboard')")
        time.sleep(1.5)
        f6 = FRAMES / "06_dashboard_end.png"
        page.screenshot(path=str(f6), full_page=False)
        paths.append(f6)
        print(f"  [frame 6] {f6.name}")

        browser.close()
    return paths


def build_gif(frame_paths: list[Path], output: Path) -> None:
    images = []
    for fp in frame_paths:
        img = Image.open(fp).convert("RGB")
        img.thumbnail(GIF_SIZE, Image.Resampling.LANCZOS)
        images.append(img)

    images[0].save(
        output,
        save_all=True,
        append_images=images[1:],
        duration=FRAME_DURATIONS_MS,
        loop=0,
        optimize=True,
    )
    size_kb = output.stat().st_size / 1024
    print(f"\nGIF written: {output}  ({size_kb:.0f} KB)")


def main() -> None:
    print("Capturing frames (headless)...")
    frame_paths = capture_frames()
    print("\nCompositing GIF...")
    build_gif(frame_paths, ASSETS / "hero.gif")


if __name__ == "__main__":
    main()
