"""hero_demo_v2 — split-screen GIF of api-anything driving Notepad.

Left panel: fake terminal showing the Python command.
Right panel: PrintWindow capture of real Notepad updating (no focus steal).

Replaces v1 (逛 Gradio UI). Uses the ``windows`` Skill for background
screenshot and ``api_anything.apis.Notepad`` for UIA-driven control.
"""
from __future__ import annotations

import sys
import time
from io import BytesIO
from pathlib import Path

# Ensure windows Skill importable before the other imports that depend on it.
_WIN_SKILL_DIR = Path.home() / ".claude" / "skills" / "windows"
if str(_WIN_SKILL_DIR) not in sys.path:
    sys.path.insert(0, str(_WIN_SKILL_DIR))

import windows as w  # type: ignore  # noqa: E402
from PIL import Image, ImageDraw, ImageFont  # noqa: E402

from api_anything.apis import Notepad  # noqa: E402

# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
FRAMES = ROOT / "screenshots" / "hero_frames"
GIF_PATH = ASSETS / "hero.gif"

FRAME_W = 1280
FRAME_H = 540
TERM_W = FRAME_W // 2
SHOT_W = FRAME_W - TERM_W

TERM_BG = (12, 12, 12)
TERM_FG = (204, 204, 204)
TERM_PROMPT = (97, 175, 239)
TERM_OK = (152, 195, 121)
TERM_COMMENT = (92, 99, 112)
BORDER = (58, 58, 58)

FONT_REG = ImageFont.truetype("C:/Windows/Fonts/consola.ttf", 18)
FONT_SMALL = ImageFont.truetype("C:/Windows/Fonts/consola.ttf", 15)
FONT_HEAD = ImageFont.truetype("C:/Windows/Fonts/consolab.ttf", 20)

Line = tuple[str, tuple[int, int, int]]


# --------------------------------------------------------------------------
# Rendering
# --------------------------------------------------------------------------
def render_terminal(
    lines: list[Line], *, title: str = "python  —  api-anything",
) -> Image.Image:
    """Draw a fake terminal window.

    ``lines`` is a list of (text, rgb) tuples rendered top-down.
    """
    img = Image.new("RGB", (TERM_W, FRAME_H), TERM_BG)
    d = ImageDraw.Draw(img)

    d.rectangle([(0, 0), (TERM_W, 32)], fill=(30, 30, 30))
    d.ellipse([(12, 10), (24, 22)], fill=(255, 95, 86))
    d.ellipse([(32, 10), (44, 22)], fill=(255, 189, 46))
    d.ellipse([(52, 10), (64, 22)], fill=(39, 201, 63))
    d.text((80, 7), title, fill=(180, 180, 180), font=FONT_SMALL)

    y = 50
    line_h = 24
    for text, color in lines:
        if y > FRAME_H - line_h:
            break
        d.text((20, y), text, fill=color, font=FONT_REG)
        y += line_h

    d.line([(TERM_W - 1, 0), (TERM_W - 1, FRAME_H)], fill=BORDER, width=1)
    return img


def render_shot(hwnd: int) -> Image.Image:
    """PrintWindow capture of the given hwnd, fit into the right panel."""
    png_bytes = w.screenshot_window(hwnd=hwnd)
    shot = Image.open(BytesIO(png_bytes)).convert("RGB")
    sw, sh = shot.size
    scale = min(SHOT_W / sw, FRAME_H / sh)
    new_w = int(sw * scale)
    new_h = int(sh * scale)
    shot = shot.resize((new_w, new_h), Image.LANCZOS)

    panel = Image.new("RGB", (SHOT_W, FRAME_H), (245, 245, 245))
    off_x = (SHOT_W - new_w) // 2
    off_y = (FRAME_H - new_h) // 2
    panel.paste(shot, (off_x, off_y))
    return panel


def compose_frame(
    term_lines: list[Line], hwnd: int,
    *, title: str = "python  —  api-anything",
) -> Image.Image:
    term = render_terminal(term_lines, title=title)
    shot = render_shot(hwnd)
    frame = Image.new("RGB", (FRAME_W, FRAME_H), (0, 0, 0))
    frame.paste(term, (0, 0))
    frame.paste(shot, (TERM_W, 0))
    return frame


def _step(step_num: int, total: int) -> str:
    return f"# step {step_num}/{total}"


# --------------------------------------------------------------------------
# Frame scripts (one function per frame keeps main() short)
# --------------------------------------------------------------------------
TOTAL = 7


def frame_1_launch(n: Notepad) -> Image.Image:
    lines: list[Line] = [
        ("$ python", TERM_PROMPT),
        (">>> from api_anything.apis import Notepad", TERM_FG),
        (">>> n = Notepad()", TERM_FG),
        (">>> n.launch()", TERM_FG),
        ("", TERM_FG),
        ("# No source code. No CLI flags.", TERM_COMMENT),
        ("# Pure Python -> real Windows app.", TERM_COMMENT),
        ("", TERM_FG),
        (_step(1, TOTAL), TERM_COMMENT),
        ("OK  Notepad launched via UIA", TERM_OK),
    ]
    return compose_frame(lines, n._hwnd)


def frame_2_set_text(n: Notepad) -> Image.Image:
    n.set_text("Hello from API-Anything!\n")
    time.sleep(0.4)
    lines: list[Line] = [
        ("$ python", TERM_PROMPT),
        (">>> n.set_text(", TERM_FG),
        ("...     'Hello from API-Anything!\\n'", TERM_FG),
        ("... )", TERM_FG),
        ("", TERM_FG),
        ("# UIA Value pattern -> no SendInput,", TERM_COMMENT),
        ("# no focus steal, no keyboard race.", TERM_COMMENT),
        ("", TERM_FG),
        (_step(2, TOTAL), TERM_COMMENT),
        ("OK  text set", TERM_OK),
    ]
    return compose_frame(lines, n._hwnd)


def frame_3_append(n: Notepad) -> Image.Image:
    n.append_text("\n27 built-in APIs. 295 methods.\n")
    # Win11 UWP Notepad needs >1s for inner surface to repaint after append;
    # PrintWindow captures frame buffer, so wait for the text to be visible.
    time.sleep(1.3)
    lines: list[Line] = [
        ("$ python", TERM_PROMPT),
        (">>> n.append_text(", TERM_FG),
        ("...     '\\n27 built-in APIs.'", TERM_FG),
        ("...     ' 295 methods.\\n'", TERM_FG),
        ("... )", TERM_FG),
        ("", TERM_FG),
        (_step(3, TOTAL), TERM_COMMENT),
        ("OK  2 lines appended", TERM_OK),
    ]
    return compose_frame(lines, n._hwnd)


def frame_4_append_more(n: Notepad) -> Image.Image:
    n.append_text("Notepad, SQLite, FFmpeg, Git,\nBlender, Krita, Godot, Docker...\n")
    time.sleep(1.3)
    lines: list[Line] = [
        ("$ python", TERM_PROMPT),
        (">>> n.append_text(", TERM_FG),
        ("...   'Notepad, SQLite, FFmpeg, Git,\\n'", TERM_FG),
        ("...   'Blender, Krita, Godot, Docker...\\n'", TERM_FG),
        ("... )", TERM_FG),
        ("", TERM_FG),
        ("# Each API auto-generated from", TERM_COMMENT),
        ("# tier detection (CLI / API / UIA).", TERM_COMMENT),
        ("", TERM_FG),
        (_step(4, TOTAL), TERM_COMMENT),
        ("OK  appended", TERM_OK),
    ]
    return compose_frame(lines, n._hwnd)


def frame_5_replace(n: Notepad) -> Image.Image:
    n.find_replace("Hello", "Greetings")
    time.sleep(0.35)
    lines: list[Line] = [
        ("$ python", TERM_PROMPT),
        (">>> n.find_replace(", TERM_FG),
        ("...     'Hello', 'Greetings'", TERM_FG),
        ("... )", TERM_FG),
        ("", TERM_FG),
        ("# UIA tree walk -> Edit control,", TERM_COMMENT),
        ("# zero brittle screen scrapes.", TERM_COMMENT),
        ("", TERM_FG),
        (_step(5, TOTAL), TERM_COMMENT),
        ("OK  'Hello' -> 'Greetings'", TERM_OK),
    ]
    return compose_frame(lines, n._hwnd)


def frame_6_readback(n: Notepad) -> Image.Image:
    buf = n.get_text()
    buf_len = len(buf)
    first = (buf.splitlines() or [""])[0]
    if len(first) > 36:
        first = first[:33] + "..."
    lines: list[Line] = [
        ("$ python", TERM_PROMPT),
        (">>> text = n.get_text()", TERM_FG),
        (">>> len(text)", TERM_FG),
        (f"{buf_len}", TERM_OK),
        (">>> text.splitlines()[0]", TERM_FG),
        (f"'{first}'", TERM_OK),
        ("", TERM_FG),
        ("# Round-trip: drive + read back,", TERM_COMMENT),
        ("# ready for assertions / pipelines.", TERM_COMMENT),
        ("", TERM_FG),
        (_step(6, TOTAL), TERM_COMMENT),
        ("OK  state round-tripped", TERM_OK),
    ]
    return compose_frame(lines, n._hwnd)


def frame_7_pitch(n: Notepad) -> Image.Image:
    lines: list[Line] = [
        ("$ python", TERM_PROMPT),
        (">>> # 1 minute, 7 calls,", TERM_COMMENT),
        (">>> # a real app under control.", TERM_COMMENT),
        ("", TERM_FG),
        ("  api-anything v0.1.0", TERM_PROMPT),
        ("  ---------------------", TERM_COMMENT),
        ("  - CLI tools      (git, ffmpeg...)", TERM_FG),
        ("  - Python libs    (sqlite, requests...)", TERM_FG),
        ("  - UIA desktop    (Notepad, Krita...)", TERM_FG),
        ("", TERM_FG),
        ("  One import away from automating", TERM_OK),
        ("  anything on your machine.", TERM_OK),
        ("", TERM_FG),
        ("$ pip install api-anything", TERM_PROMPT),
    ]
    return compose_frame(lines, n._hwnd, title="api-anything — ship it")


FRAME_BUILDERS = [
    frame_1_launch,
    frame_2_set_text,
    frame_3_append,
    frame_4_append_more,
    frame_5_replace,
    frame_6_readback,
    frame_7_pitch,
]
DURATIONS_MS = [1600, 1500, 1400, 1700, 1500, 2000, 2600]


# --------------------------------------------------------------------------
# GIF assembly
# --------------------------------------------------------------------------
def build_gif(frames: list[Image.Image], path: Path) -> int:
    """Downscale, palette-quantize, write GIF. Returns file size bytes."""
    target_w = 960
    target_h = int(FRAME_H * target_w / FRAME_W)
    scaled = [f.resize((target_w, target_h), Image.LANCZOS) for f in frames]
    scaled_p = [
        f.convert("P", palette=Image.ADAPTIVE, colors=128) for f in scaled
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    scaled_p[0].save(
        path,
        save_all=True,
        append_images=scaled_p[1:],
        duration=DURATIONS_MS,
        loop=0,
        optimize=True,
        disposal=2,
    )
    return path.stat().st_size


def _clean_frames_dir() -> None:
    FRAMES.mkdir(parents=True, exist_ok=True)
    for p in FRAMES.glob("hero_v2_*.png"):
        p.unlink()


def _persist_frames(frames: list[Image.Image]) -> None:
    for i, img in enumerate(frames, start=1):
        img.save(FRAMES / f"hero_v2_{i:02d}.png", "PNG")


def main() -> int:
    _clean_frames_dir()
    assert len(FRAME_BUILDERS) == len(DURATIONS_MS), "builder/duration mismatch"

    print("[launch] Notepad")
    n = Notepad()
    n.launch()
    time.sleep(1.2)

    frames: list[Image.Image] = []
    for i, build in enumerate(FRAME_BUILDERS, start=1):
        print(f"[frame {i}] building...")
        frames.append(build(n))

    _persist_frames(frames)

    try:
        n.close(save=False)
    except Exception as e:  # noqa: BLE001
        print(f"[warn] close failed: {e}")

    size = build_gif(frames, GIF_PATH)
    print(f"[done] wrote {GIF_PATH} ({size / 1024:.1f} KB, {len(frames)} frames)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
