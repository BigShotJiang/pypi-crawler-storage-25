"""Live visible demo: Explorer + Playwright headful browser.

Runs scripted actions on the Gradio UI so the user can watch.
"""
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.expanduser(r"~/.claude/skills/browser"))
import browser as b  # noqa: E402

SCREENS = os.path.dirname(os.path.abspath(__file__))
URL = "http://127.0.0.1:7861"


def pause(label: str, seconds: float) -> None:
    print(f"  [+{seconds:.0f}s] {label}")
    time.sleep(seconds)


def wait_for_tier_result() -> None:
    for _ in range(40):
        time.sleep(1)
        txt = b.eval_js("() => document.body.innerText.toLowerCase()")
        if "tier 1" in txt or "verdict" in txt or "confidence" in txt:
            return


def main() -> None:
    print("[1] Open Windows Explorer on screenshots folder")
    subprocess.Popen(["explorer", SCREENS.replace("/", "\\")])
    pause("Explorer should now be visible", 2)

    print("[2] Launch VISIBLE Chromium (headful mode)")
    b.launch(headless=False, viewport={"width": 1440, "height": 900})
    b.goto(URL)
    pause("Dashboard: 27 APIs / 295 methods / 204 tests", 5)

    print("[3] Switch to Tier Detection tab")
    b.click("button[role='tab']:has-text('Tier Detection')")
    pause("Tier Detection tab visible", 3)

    print("[4] Fill 'ffmpeg' in Software Name")
    b.fill("input[placeholder*='ffmpeg']", "ffmpeg")
    pause("Input filled", 2)

    print("[5] Click Detect Tier button")
    b.click("button:has-text('Detect Tier')")
    wait_for_tier_result()
    pause("Detection report visible (Tier 1 *****, 98% confidence)", 5)

    print("[6] Switch to Dashboard to show stats")
    b.click("button[role='tab']:has-text('Dashboard')")
    pause("Dashboard with 27 APIs", 5)

    print("[7] Switch to API Explorer")
    b.click("button[role='tab']:has-text('API Explorer')")
    pause("Explorer tab visible", 5)

    print("[8] Switch to Generate (v0.2 preview)")
    b.click("button[role='tab']:has-text('Generate')")
    pause("Generate tab visible", 5)

    print("[9] Keep browser open 8 more seconds for inspection")
    time.sleep(8)

    print("[10] Close browser")
    b.close()


if __name__ == "__main__":
    main()
