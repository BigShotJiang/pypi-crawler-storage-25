"""Capture 4 Gradio tabs for API-Anything v0.1.0 handoff verification."""
import os
import sys
import time

sys.path.insert(0, os.path.expanduser(r"~/.claude/skills/browser"))
import browser as b  # noqa: E402

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
URL = "http://127.0.0.1:7861"


def shot(name: str) -> str:
    path = os.path.join(OUT_DIR, f"{name}.png")
    b.screenshot(path=path, full_page=True)
    print(f"  -> {path}")
    return path


def main() -> None:
    b.launch(headless=True, viewport={"width": 1440, "height": 900})
    b.goto(URL)
    time.sleep(3)
    print("[1/4] Dashboard")
    shot("01_dashboard")

    print("[2/4] Tier Detection")
    b.click("button[role='tab']:has-text('Tier Detection')")
    time.sleep(1.5)
    shot("02_tier_detection")

    print("[3/4] API Explorer")
    b.click("button[role='tab']:has-text('API Explorer')")
    time.sleep(1.5)
    shot("03_api_explorer")

    print("[4/4] Generate")
    b.click("button[role='tab']:has-text('Generate')")
    time.sleep(1.5)
    shot("04_generate")

    title = b.eval_js("document.title")
    print(f"document.title = {title!r}")
    b.close()


if __name__ == "__main__":
    main()
