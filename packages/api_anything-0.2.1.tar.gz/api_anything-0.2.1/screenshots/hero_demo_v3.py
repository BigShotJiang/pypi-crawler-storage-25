"""hero_demo_v3 — two hero GIFs without Notepad or any user-owned app.

Produces two GIFs that showcase api-anything:
    1. ``assets/hero_cli.gif``  — pure Rich CLI reports (detect / list).
    2. ``assets/hero_repl.gif`` — split-screen SQLite ``:memory:`` REPL.

Privacy rules (hard):
    * No Windows user name.
    * No real user paths (``C:/Users/<name>``, ``AppData``, personal .db).
    * No subprocess that probes PATH / PyPI — we render hand-crafted text
      that MATCHES the real CLI layout. The REPL demo is real but pinned to
      an in-memory SQLite connection.
    * Every frame's text is captured into ``FRAME_TEXTS`` and swept for PII
      tokens before GIF is written. Any hit aborts the run.

Usage:
    python screenshots/hero_demo_v3.py
"""
from __future__ import annotations

import os
import re
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

# Ensure src/ is on sys.path so we can import the in-process SQLite API.
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from api_anything.apis import SQLite  # noqa: E402

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
ASSETS = ROOT / "assets"
FRAMES = ROOT / "screenshots" / "hero_frames"

FRAME_W = 960
FRAME_H = 540

# Terminal theme (macOS dark).
TERM_BG = (18, 18, 22)
TERM_FG = (210, 210, 214)
TERM_PROMPT = (97, 175, 239)       # cmd prompt "$"
TERM_USER = (152, 195, 121)        # username / success
TERM_COMMENT = (110, 118, 129)     # dim
TERM_CYAN = (86, 182, 194)
TERM_YELLOW = (229, 192, 123)
TERM_PURPLE = (198, 120, 221)
TERM_RED = (224, 108, 117)
TERM_STAR = (255, 209, 102)
BORDER = (58, 58, 66)
TITLE_BAR = (30, 30, 36)

FONT_REG = ImageFont.truetype("C:/Windows/Fonts/consola.ttf", 15)
FONT_SMALL = ImageFont.truetype("C:/Windows/Fonts/consola.ttf", 13)
FONT_HEAD = ImageFont.truetype("C:/Windows/Fonts/consolab.ttf", 15)
# Segoe UI Symbol is the Windows font that actually ships the ★ glyph.
# Consolas renders U+2605 as tofu, so we swap fonts per-line when it appears.
FONT_SYMBOL = ImageFont.truetype("C:/Windows/Fonts/seguisym.ttf", 15)

_SYMBOL_CHARS = ("★", "☆", "\u2605", "\u2606")


def _needs_symbol_font(text: str) -> bool:
    return any(ch in text for ch in _SYMBOL_CHARS)

Line = tuple[str, tuple[int, int, int]]

#: Every piece of text drawn into any frame is appended here so the PII sweep
#: can scan it before the GIF is serialised.
FRAME_TEXTS: list[str] = []

#: Substrings that would indicate a privacy leak. Tested case-insensitively.
PII_BLOCKLIST = (
    "zerox",
    "c:/users/",
    "c:\\users\\",
    "/users/aiking",
    "appdata",
    "onedrive",
    "desktop/",
    "desktop\\",
    ".ssh",
    # No realistic user-owned .db files — :memory: is safe to keep in text.
)

_REALISTIC_DB_RE = re.compile(r"[a-z]:[\\/][^\s:]*\.db\b", re.IGNORECASE)


def _record(text: str) -> None:
    """Record text for the final PII sweep."""
    FRAME_TEXTS.append(text)


def pii_sweep() -> list[str]:
    """Return a list of violations found across FRAME_TEXTS (empty = OK)."""
    hits: list[str] = []
    joined = "\n".join(FRAME_TEXTS)
    lower = joined.lower()
    for needle in PII_BLOCKLIST:
        if needle in lower:
            hits.append(f"blocklist: {needle!r}")
    for m in _REALISTIC_DB_RE.finditer(joined):
        hits.append(f"realistic-db-path: {m.group(0)!r}")
    return hits


# ---------------------------------------------------------------------------
# Box-drawing helpers (keep literals ≤ 70 chars wide to stay under E501).
# ---------------------------------------------------------------------------
def _hbar(width: int, left: str = "┌", mid: str = "─", right: str = "┐") -> str:
    return left + mid * (width - 2) + right


def _centered(width: int, text: str, left: str = "│", right: str = "│") -> str:
    inner = width - 2
    pad_l = (inner - len(text)) // 2
    pad_r = inner - len(text) - pad_l
    return f"{left}{' ' * pad_l}{text}{' ' * pad_r}{right}"


def _row(width: int, text: str, left: str = "│", right: str = "│") -> str:
    inner = width - 2
    text = text.ljust(inner)[:inner]
    return f"{left}{text}{right}"


# ---------------------------------------------------------------------------
# Terminal rendering
# ---------------------------------------------------------------------------
def _draw_title_bar(d: ImageDraw.ImageDraw, w: int, title: str) -> None:
    d.rectangle([(0, 0), (w, 28)], fill=TITLE_BAR)
    d.ellipse([(10, 9), (22, 21)], fill=(255, 95, 86))
    d.ellipse([(28, 9), (40, 21)], fill=(255, 189, 46))
    d.ellipse([(46, 9), (58, 21)], fill=(39, 201, 63))
    d.text((w // 2 - 90, 7), title, fill=(180, 180, 185), font=FONT_SMALL)


def render_pane(
    width: int,
    height: int,
    lines: list[Line],
    *,
    title: str,
    line_h: int = 19,
    pad_x: int = 18,
    pad_y: int = 40,
) -> Image.Image:
    img = Image.new("RGB", (width, height), TERM_BG)
    d = ImageDraw.Draw(img)
    _draw_title_bar(d, width, title)
    y = pad_y
    for text, color in lines:
        _record(text)
        if y > height - line_h:
            break
        font = FONT_SYMBOL if _needs_symbol_font(text) else FONT_REG
        d.text((pad_x, y), text, fill=color, font=font)
        y += line_h
    return img


def compose_split(left: Image.Image, right: Image.Image) -> Image.Image:
    """Horizontally stack two panes with a 1px divider."""
    w = left.width + right.width
    img = Image.new("RGB", (w, max(left.height, right.height)), TERM_BG)
    img.paste(left, (0, 0))
    img.paste(right, (left.width, 0))
    d = ImageDraw.Draw(img)
    d.line(
        [(left.width - 1, 0), (left.width - 1, img.height)],
        fill=BORDER,
        width=1,
    )
    return img


# ---------------------------------------------------------------------------
# Hero A — CLI Rich reports (hand-crafted, privacy-safe)
# ---------------------------------------------------------------------------
CLI_BOX_W = 64  # keeps literals well below 100 char ruff ceiling
HEAD_PURPLE = TERM_PURPLE


def _prompt(cmd: str) -> Line:
    return (f"$ {cmd}", TERM_USER)


def _titled_hbar(width: int, title: str) -> str:
    """Top border with an inline centered title.

    e.g. ``┌─────── api-anything ────────┐``
    """
    inner = width - 2  # interior between ┌ and ┐
    label = f" {title} "
    pad = inner - len(label)
    left_pad = pad // 2
    right_pad = pad - left_pad
    return "┌" + "─" * left_pad + label + "─" * right_pad + "┐"


def _cli_frame_detect(
    software: str,
    tier_label: str,
    tier_color: tuple[int, int, int],
    checks: list[tuple[str, str, str, tuple[int, int, int]]],
    confidence: str,
    verdict: str,
    verdict_color: tuple[int, int, int],
) -> list[Line]:
    w = CLI_BOX_W
    lines: list[Line] = [
        _prompt(f"api-anything detect {software}"),
        (_titled_hbar(w, "api-anything"), TERM_FG),
        (_row(w, ""), TERM_FG),
        (_row(w, "  [*] API-Anything Tier Detection"), TERM_FG),
        (_row(w, f"     Software: {software}"), TERM_FG),
        (_row(w, f"     Tier: {tier_label}"), tier_color),
        (_row(w, ""), TERM_FG),
        (_hbar(w, "└", "─", "┘"), TERM_FG),
        (_titled_hbar(w, "Detection Checks"), TERM_FG),
    ]
    for flag, name, detail, color in checks:
        row_text = f"  {flag:<4}{name:<16}{detail}"
        lines.append((_row(w, row_text), color))
    lines.append((_hbar(w, "└", "─", "┘"), TERM_FG))
    lines.append((f"  Confidence: {confidence}", TERM_CYAN))
    lines.append((f"  Verdict: {verdict}", verdict_color))
    return lines


def _cli_frame_detect_sqlite() -> list[Line]:
    checks = [
        ("OK", "Python binding", "stdlib sqlite3", TERM_USER),
        ("OK", "CLI support", "standard shell", TERM_USER),
        ("--", "UIA quality", "headless (no GUI)", TERM_COMMENT),
        ("OK", "Source code", "cpython stdlib", TERM_USER),
    ]
    return _cli_frame_detect(
        software="sqlite3  v3.45",
        tier_label="1 ★★★★★",
        tier_color=TERM_STAR,
        checks=checks,
        confidence="98%  |  Est. tokens: ~2K",
        verdict=">> Direct binding — wrap and ship!",
        verdict_color=TERM_YELLOW,
    )


def _cli_frame_detect_electron() -> list[Line]:
    checks = [
        ("--", "Source code", "proprietary, no repo", TERM_COMMENT),
        ("--", "CLI support", "not in PATH", TERM_COMMENT),
        ("!!", "UIA quality", "Electron shell: 12%", TERM_RED),
        ("--", "Python binding", "no match on PyPI", TERM_COMMENT),
    ]
    return _cli_frame_detect(
        software="BaiduNetdisk  (Electron shell)",
        tier_label="4 ★☆☆☆☆",
        tier_color=TERM_RED,
        checks=checks,
        confidence="15%  |  Est. tokens: ~100K",
        verdict="!! Pixel-level — vision model required",
        verdict_color=TERM_RED,
    )


def _cli_frame_list() -> list[Line]:
    w = CLI_BOX_W
    apis = [
        ("FFmpeg", "2A", 12, "Video / audio conversion"),
        ("Git", "2A", 15, "Version control"),
        ("Docker", "2A", 15, "Container management"),
        ("SQLite", "1", 12, "Database (stdlib)"),
        ("ImageMagick", "2A", 11, "Image processing"),
        ("Pandoc", "2A", 10, "Document conversion"),
        ("Notepad", "3A", 19, "Windows Notepad (UIA)"),
        ("Blender", "2A", 10, "3D modelling, rendering"),
        ("Ollama", "1", 10, "Local LLM (REST API)"),
        ("ComfyUI", "1", 10, "Stable Diffusion workflow"),
    ]
    lines: list[Line] = [
        _prompt("api-anything list --detail"),
        (_centered(w, "Available APIs (27 built-in)"), HEAD_PURPLE),
        (_hbar(w, "┌", "─", "┐"), TERM_FG),
        (_row(w, "  Name          Tier   Methods   Description"), HEAD_PURPLE),
        (_hbar(w, "├", "─", "┤"), TERM_FG),
    ]
    for name, tier, nmeth, desc in apis:
        text = f"  {name:<14}{tier:<7}{nmeth:>5}     {desc}"
        lines.append((_row(w, text), TERM_FG))
    lines.append((_row(w, "   ...           ..       ...     17 more APIs"),
                  TERM_COMMENT))
    lines.append((_hbar(w, "└", "─", "┘"), TERM_FG))
    lines.append(("  Total: 27 APIs, 295 methods", TERM_YELLOW))
    return lines


def _cli_frame_help() -> list[Line]:
    w = CLI_BOX_W
    methods = [
        ("create_table", "(name, columns: dict) -> None"),
        ("insert", "(table, data: dict) -> int (rowid)"),
        ("query", "(sql, params=None) -> list[dict]"),
        ("update", "(table, data, where) -> int"),
        ("delete", "(table, where) -> int"),
        ("get_tables", "() -> list[str]"),
        ("get_schema", "(table) -> str"),
        ("export_csv", "(table, output_path) -> None"),
        ("import_csv", "(table, csv_path) -> int"),
        ("backup", "(output_path) -> None"),
        ("execute", "(sql, params=None) -> int"),
        ("close", "() -> None"),
    ]
    lines: list[Line] = [
        _prompt("api-anything run sqlite --help"),
        (_centered(w, "SQLite — 12 methods  (Tier 1 ★★★★★)"), TERM_STAR),
        (_hbar(w, "┌", "─", "┐"), TERM_FG),
        (_row(w, "  Method           Signature"), HEAD_PURPLE),
        (_hbar(w, "├", "─", "┤"), TERM_FG),
    ]
    for name, sig in methods:
        text = f"  {name:<17}{sig}"
        lines.append((_row(w, text), TERM_CYAN))
    lines.append((_hbar(w, "└", "─", "┘"), TERM_FG))
    lines.append(("  Zero dependencies. Pure stdlib sqlite3.", TERM_USER))
    return lines


def build_hero_cli_frames() -> tuple[list[Image.Image], list[int]]:
    frames: list[Image.Image] = []
    durations: list[int] = []

    def add(lines: list[Line], title: str, ms: int) -> None:
        frame = render_pane(FRAME_W, FRAME_H, lines, title=title)
        frames.append(frame)
        durations.append(ms)

    add(_cli_frame_detect_sqlite(), "api-anything — detect", 2200)
    add(
        _cli_frame_detect_electron(),
        "api-anything — detect (Electron)",
        2200,
    )
    add(_cli_frame_list(), "api-anything — list --detail", 2400)
    add(_cli_frame_help(), "api-anything — run sqlite --help", 2600)
    return frames, durations


# ---------------------------------------------------------------------------
# Hero B — SQLite :memory: REPL split-screen
# ---------------------------------------------------------------------------
def _render_rich_table(
    title: str, rows: list[dict], *, max_rows: int = 8,
) -> list[Line]:
    """Render a list-of-dicts as a plain ASCII-boxed result panel."""
    if not rows:
        return [(f"[{title}] (no rows)", TERM_COMMENT)]
    cols = list(rows[0].keys())
    widths = {
        c: max(len(c), max((len(str(r[c])) for r in rows), default=0))
        for c in cols
    }
    sep = "+" + "+".join("-" * (widths[c] + 2) for c in cols) + "+"
    header = "|" + "|".join(f" {c:<{widths[c]}} " for c in cols) + "|"
    out: list[Line] = [
        (f"  result: {title}", TERM_YELLOW),
        (sep, TERM_FG),
        (header, TERM_PURPLE),
        (sep, TERM_FG),
    ]
    for r in rows[:max_rows]:
        cells = [f" {r[c]!s:<{widths[c]}} " for c in cols]
        body = "|" + "|".join(cells) + "|"
        out.append((body, TERM_CYAN))
    out.append((sep, TERM_FG))
    if len(rows) > max_rows:
        out.append((f"  ... {len(rows) - max_rows} more rows", TERM_COMMENT))
    return out


def _repl_banner() -> list[Line]:
    return [
        ("api-anything REPL  —  SQLite (Tier 1 ★★★★★)", TERM_STAR),
        ("connection: :memory:   methods: 12   tier: 1", TERM_COMMENT),
        ("Type .help for commands, .quit to exit", TERM_COMMENT),
        ("", TERM_FG),
    ]


def _right_result_pane(lines: list[Line], title: str) -> Image.Image:
    pad: list[Line] = [("", TERM_FG), *lines]
    return render_pane(FRAME_W // 2, FRAME_H, pad, title=title)


def _repl_help_right() -> list[Line]:
    return [
        ("  REPL Commands", TERM_PURPLE),
        ("  .help        show this help", TERM_FG),
        ("  .json        toggle JSON output", TERM_FG),
        ("  .undo/.redo  time-travel last calls", TERM_FG),
        ("  .export FILE export session script", TERM_FG),
        ("  .tier        show tier detection", TERM_FG),
        ("  .quit        exit REPL", TERM_FG),
        ("", TERM_FG),
        ("  SQLite methods: 12  (see help table)", TERM_CYAN),
    ]


def _repl_create_step(transcript: list[Line], db: SQLite) -> list[Line]:
    db.create_table("demo", {"id": "INTEGER PRIMARY KEY", "name": "TEXT"})
    transcript.extend([
        ("sqlite[:memory:]> create_table(", TERM_PROMPT),
        ("...     'demo',", TERM_FG),
        ("...     {'id': 'INTEGER PRIMARY KEY',", TERM_FG),
        ("...      'name': 'TEXT'}", TERM_FG),
        ("... )", TERM_FG),
        ("OK", TERM_USER),
    ])
    return [
        ("  CREATE TABLE IF NOT EXISTS demo (", TERM_CYAN),
        ("    id INTEGER PRIMARY KEY,", TERM_CYAN),
        ("    name TEXT", TERM_CYAN),
        ("  )", TERM_CYAN),
        ("", TERM_FG),
        ("  table 'demo' created.", TERM_USER),
    ]


def _repl_insert_step(
    transcript: list[Line], db: SQLite, row_id: int, name: str,
) -> list[Line]:
    rowid = db.insert("demo", {"id": row_id, "name": name})
    transcript.append((
        f"sqlite[:memory:]> insert('demo', {{'id':{row_id},'name':'{name}'}})",
        TERM_PROMPT,
    ))
    transcript.append((f"{rowid}", TERM_CYAN))
    return [
        ("  INSERT INTO demo (id, name)", TERM_CYAN),
        ("  VALUES (?, ?)", TERM_CYAN),
        (f"  params: [{row_id}, '{name}']", TERM_FG),
        ("", TERM_FG),
        (f"  -> rowid = {rowid}", TERM_USER),
    ]


def _repl_tables_step(transcript: list[Line], db: SQLite) -> list[Line]:
    tables = db.get_tables()
    transcript.append(("sqlite[:memory:]> get_tables()", TERM_PROMPT))
    transcript.append((f"{tables}", TERM_CYAN))
    return [
        ("  sqlite_master -> table list", TERM_CYAN),
        ("", TERM_FG),
        ("  +---------+", TERM_FG),
        ("  | name    |", TERM_PURPLE),
        ("  +---------+", TERM_FG),
        *[(f"  | {t:<7} |", TERM_CYAN) for t in tables],
        ("  +---------+", TERM_FG),
        (f"  -> {len(tables)} table(s)", TERM_USER),
    ]


def _repl_query_step(transcript: list[Line], db: SQLite) -> list[Line]:
    rows = db.query("SELECT * FROM demo ORDER BY id")
    transcript.append((
        "sqlite[:memory:]> query('SELECT * FROM demo')", TERM_PROMPT,
    ))
    for r in rows:
        transcript.append((f"  {dict(r)}", TERM_CYAN))
    return [
        ("  SELECT * FROM demo ORDER BY id", TERM_CYAN),
        ("", TERM_FG),
        *_render_rich_table("rows", rows),
        ("", TERM_FG),
        (f"  -> {len(rows)} row(s) round-tripped", TERM_USER),
    ]


def build_hero_repl_frames() -> tuple[list[Image.Image], list[int]]:
    """Run real SQLite calls in-memory; assemble split-screen frames."""
    db = SQLite(":memory:")
    frames: list[Image.Image] = []
    durations: list[int] = []
    transcript: list[Line] = []
    transcript.extend(_repl_banner())

    def snapshot(right_lines: list[Line], title: str, ms: int) -> None:
        visible = transcript[-24:]
        left = render_pane(
            FRAME_W // 2, FRAME_H, visible, title="sqlite[:memory:]",
        )
        right = _right_result_pane(right_lines, title)
        frames.append(compose_split(left, right))
        durations.append(ms)

    transcript.append(("sqlite[:memory:]> .help", TERM_PROMPT))
    snapshot(_repl_help_right(), "result — .help", 1600)
    snapshot(_repl_create_step(transcript, db), "result — create_table", 1500)
    snapshot(
        _repl_insert_step(transcript, db, 1, "Alice"), "result — insert", 1400,
    )
    snapshot(
        _repl_insert_step(transcript, db, 2, "Bob"), "result — insert", 1300,
    )
    snapshot(_repl_tables_step(transcript, db), "result — get_tables", 1500)
    snapshot(_repl_query_step(transcript, db), "result — query", 2000)

    db.close()
    return frames, durations


# ---------------------------------------------------------------------------
# GIF assembly
# ---------------------------------------------------------------------------
def build_gif(
    frames: list[Image.Image], durations: list[int], path: Path,
) -> int:
    """Palette-quantize and write a looping GIF. Returns byte size."""
    path.parent.mkdir(parents=True, exist_ok=True)
    palette_frames = [
        f.convert("P", palette=Image.ADAPTIVE, colors=96) for f in frames
    ]
    palette_frames[0].save(
        path,
        save_all=True,
        append_images=palette_frames[1:],
        duration=durations,
        loop=0,
        optimize=True,
        disposal=2,
    )
    return path.stat().st_size


def _persist_frames(frames: list[Image.Image], prefix: str) -> None:
    FRAMES.mkdir(parents=True, exist_ok=True)
    for p in FRAMES.glob(f"{prefix}_*.png"):
        p.unlink()
    for i, img in enumerate(frames, start=1):
        img.save(FRAMES / f"{prefix}_{i:02d}.png", "PNG")


def main() -> int:
    FRAME_TEXTS.clear()

    print("[hero_cli] building frames…")
    cli_frames, cli_durs = build_hero_cli_frames()
    _persist_frames(cli_frames, "hero_cli")

    print("[hero_repl] building frames (real :memory: SQLite)…")
    repl_frames, repl_durs = build_hero_repl_frames()
    _persist_frames(repl_frames, "hero_repl")

    violations = pii_sweep()
    if violations:
        print("[FAIL] PII sweep hit the following:", file=sys.stderr)
        for v in violations:
            print(f"  - {v}", file=sys.stderr)
        return 2
    print("[pii] sweep clean — no zerox / user path / .db leak")

    cli_size = build_gif(cli_frames, cli_durs, ASSETS / "hero_cli.gif")
    repl_size = build_gif(repl_frames, repl_durs, ASSETS / "hero_repl.gif")

    print(
        f"[done] hero_cli.gif  = {cli_size/1024:6.1f} KB  "
        f"({len(cli_frames)} frames)\n"
        f"       hero_repl.gif = {repl_size/1024:6.1f} KB  "
        f"({len(repl_frames)} frames)"
    )
    return 0


if __name__ == "__main__":
    # Force UTF-8 stdio on Windows so Rich box-drawing chars never crash.
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    raise SystemExit(main())
