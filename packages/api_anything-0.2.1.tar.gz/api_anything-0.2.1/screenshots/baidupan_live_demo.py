"""Live demo: attach to Baidu Netdisk and explore its UIA tree.

Runs on demand only — do NOT execute automatically. The user will
trigger it by saying "測試".

Strategy
--------
1. List current windows via the windows Skill, find Baidu Netdisk
   (class / title match)
2. If not running, launch it (users have it installed at a known path)
3. Attach + walk UIA tree to discover controls (buttons, list, etc.)
4. Demonstrate one safe action — e.g. read the currently selected
   folder path, or click the "refresh" button — without triggering
   uploads/downloads.
5. Detach cleanly (no process kill).

Baidu Netdisk app is a WPF/Qt hybrid — its UIA quality is typically
Tier 3B (partial named controls). This is an honest Tier 3 demo:
not perfect automation, but agent-readable surface.
"""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

# ensure windows Skill on path
sys.path.insert(0, os.path.expanduser(r"~/.claude/skills/windows"))
import windows as w  # noqa: E402


BAIDUPAN_CANDIDATES = [
    "百度网盘",
    "BaiduNetdisk",
    "百度网盘同步版",
    "BaiduYun",
    "Baidu Netdisk",
]

BAIDUPAN_EXE = Path.home() / "AppData/Roaming/baidu/BaiduNetdisk/BaiduNetdisk.exe"


def ensure_baidupan_running(timeout: float = 15.0) -> dict | None:
    """Launch Baidu Netdisk if not running and wait for its window."""
    win = find_baidupan_window()
    if win:
        return win
    if not BAIDUPAN_EXE.exists():
        print(f"  Binary not found at {BAIDUPAN_EXE}")
        return None
    print(f"  Launching: {BAIDUPAN_EXE}")
    subprocess.Popen(
        [str(BAIDUPAN_EXE)],
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
    )
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        time.sleep(1.0)
        win = find_baidupan_window()
        if win:
            return win
    return None


def find_baidupan_window() -> dict | None:
    """Scan window_list for a Baidu Netdisk match."""
    for win in w.window_list():
        title = win.get("title", "")
        for kw in BAIDUPAN_CANDIDATES:
            if kw in title:
                return win
    return None


def dump_uia_tree(hwnd: int, max_depth: int = 3) -> None:
    """Walk the UIA tree under hwnd and print a compact tree."""
    try:
        import uiautomation as auto
    except ImportError:
        print("  (uiautomation not installed — skipping UIA tree walk)")
        return

    try:
        control = auto.ControlFromHandle(hwnd)
    except Exception as exc:
        print(f"  (ControlFromHandle failed: {exc})")
        return

    def walk(ctrl, depth: int) -> None:
        if depth > max_depth:
            return
        indent = "  " * depth
        try:
            name = ctrl.Name[:50] if ctrl.Name else ""
            ctrl_type = ctrl.ControlTypeName
            auto_id = ctrl.AutomationId or ""
            print(f"{indent}- {ctrl_type} name={name!r} id={auto_id!r}")
        except Exception as exc:
            print(f"{indent}- <unreadable: {exc}>")
            return
        try:
            children = ctrl.GetChildren()
        except Exception:
            children = []
        for child in children[:12]:  # cap fan-out
            walk(child, depth + 1)

    walk(control, 0)


def main() -> None:
    print("== API-Anything -> Baidu Netdisk (Tier 3 UIA exploration) ==")

    print("[1] Scanning windows for Baidu Netdisk (auto-launch if needed)")
    win = ensure_baidupan_running(timeout=20.0)
    if not win:
        print("  NOT FOUND / launch failed")
        print(f"  Tried: {BAIDUPAN_EXE}")
        print(f"  Tried title keywords: {BAIDUPAN_CANDIDATES}")
        return

    print(f"  Found: hwnd={win['hwnd']}, title={win['title']!r}")
    print(f"  bounds={win['bounds']}")

    print("\n[2] Screenshotting the window (non-foreground, PrintWindow)")
    shot_path = Path(__file__).resolve().parent / "baidupan_window.png"
    try:
        w.screenshot_window(hwnd=win["hwnd"], path=str(shot_path))
        print(f"  screenshot -> {shot_path}")
    except AttributeError:
        w.screenshot(path=str(shot_path))
        print(f"  fallback full-desktop screenshot -> {shot_path}")

    print("\n[3] Walking UIA control tree (depth 3)")
    dump_uia_tree(win["hwnd"], max_depth=3)

    print("\n[4] Running api-anything tier detection for 'baidupan'")
    try:
        from api_anything.tier_detect import detect_tier
        result = detect_tier(software_name="baidupan")
        print(f"  Tier: {result.tier}  Confidence: {result.confidence}%")
        print(f"  Verdict: {result.verdict}")
    except Exception as exc:
        print(f"  tier_detect error: {exc}")

    print("\n== Done. No upload/download/destructive action taken. ==")


if __name__ == "__main__":
    main()
