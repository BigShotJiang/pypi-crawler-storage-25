"""Live Notepad demo: api-anything drives a real Windows program via UIA.

Watch your desktop — Notepad will launch, text will appear, find/replace
will run, and the file will save. All driven from Python, zero keyboard
input from you.
"""
from __future__ import annotations

import time
from pathlib import Path

from api_anything.apis import Notepad

OUT_FILE = Path(__file__).resolve().parent / "notepad_demo_output.txt"


def step(label: str, seconds: float = 2.0) -> None:
    print(f"  ... {label}")
    time.sleep(seconds)


def main() -> None:
    print("== API-Anything -> Notepad (Tier 3A UIA demo) ==")
    n = Notepad()

    print("[1] Launching Notepad")
    n.launch()
    step("Notepad window should now be visible on your desktop", 3)

    print("[2] Writing initial text")
    n.set_text(
        "Hello from API-Anything!\n"
        "\n"
        "This Notepad window is controlled via UIA (UI Automation).\n"
        "No keyboard, no mouse, no CLI flags -- pure Python API.\n"
        "\n"
        "27 built-in APIs.  295 methods.  204 tests.\n"
    )
    step("Text appeared", 3)

    print("[3] Appending more text")
    n.append_text("\n-- appended via n.append_text() --\n")
    step("Line appended", 2)

    print("[4] Find & replace: 'Hello' -> 'Greetings'")
    n.find_replace("Hello", "Greetings")
    step("Replacement done", 2)

    print("[5] Reading current buffer back")
    current = n.get_text()
    print(f"    buffer length = {len(current)} chars")
    print(f"    first line    = {current.splitlines()[0]!r}")
    step("get_text() returned", 1.5)

    print(f"[6] Save as {OUT_FILE}")
    if OUT_FILE.exists():
        OUT_FILE.unlink()
    n.save_as(str(OUT_FILE))
    step("File saved", 2)

    print("[7] Closing Notepad")
    n.close(save=False)
    print("== Done ==")
    if OUT_FILE.exists():
        print(f"Output file: {OUT_FILE}  ({OUT_FILE.stat().st_size} bytes)")
    else:
        # Win11 UWP Notepad save dialog is not driven via the classic
        # UIA path; the buffer was captured above via get_text() instead.
        print(
            "Output file not persisted to disk (Win11 UWP Save As dialog "
            "limitation); buffer captured via get_text() earlier."
        )


if __name__ == "__main__":
    main()
