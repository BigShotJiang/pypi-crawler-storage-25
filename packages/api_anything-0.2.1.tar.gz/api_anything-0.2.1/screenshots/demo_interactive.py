"""Interactive Gradio demo: fill Tier Detection form, click, capture."""
import os
import sys
import time

sys.path.insert(0, os.path.expanduser(r"~/.claude/skills/browser"))
import browser as b  # noqa: E402

OUT = os.path.dirname(os.path.abspath(__file__))
URL = "http://127.0.0.1:7861"


def shot(name: str) -> None:
    b.screenshot(path=os.path.join(OUT, f"{name}.png"), full_page=True)
    print(f"  -> {name}.png")


def main() -> None:
    b.launch(headless=True, viewport={"width": 1440, "height": 900})
    b.goto(URL)
    time.sleep(2)

    print("[Demo] Tier Detection for 'ffmpeg'")
    b.click("button[role='tab']:has-text('Tier Detection')")
    time.sleep(1.5)
    b.fill("input[placeholder*='ffmpeg']", "ffmpeg")
    shot("demo_01_tier_input")

    b.click("button:has-text('Detect Tier')")
    # Tier detection does subprocess + PyPI + GitHub lookups; 30s ample
    for _ in range(30):
        time.sleep(1)
        txt = b.eval_js(
            "() => document.body.innerText.toLowerCase()"
        )
        if "tier:" in txt or "confidence" in txt or "verdict" in txt:
            break
    shot("demo_02_tier_result")

    print(f"document.title = {b.eval_js('document.title')!r}")
    b.close()


if __name__ == "__main__":
    main()
