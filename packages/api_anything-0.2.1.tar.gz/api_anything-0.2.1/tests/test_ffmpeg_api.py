"""Tests for FFmpeg API (API-Anything POC #2).

All tests run WITHOUT ffmpeg installed by mocking subprocess calls.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# examples/ is not a package — add it to sys.path for import
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "examples"))

from ffmpeg_api import FFmpeg, FFmpegNotFoundError

# ── Fixtures ─────────────────────────────────────────────────────


@pytest.fixture()
def ff() -> FFmpeg:
    """Return an FFmpeg instance with mocked binary resolution."""
    return FFmpeg()


def _mock_run_ok(stdout: str = "", stderr: str = "") -> MagicMock:
    """Create a mock subprocess.CompletedProcess for successful runs."""
    m = MagicMock()
    m.stdout = stdout
    m.stderr = stderr
    m.returncode = 0
    return m


_PROBE_OUTPUT = json.dumps({
    "format": {"duration": "120.5", "bit_rate": "2500000"},
    "streams": [
        {
            "codec_type": "video",
            "codec_name": "h264",
            "width": 1920,
            "height": 1080,
            "r_frame_rate": "30/1",
        },
        {
            "codec_type": "audio",
            "codec_name": "aac",
            "sample_rate": "44100",
            "channels": 2,
        },
    ],
})


# ── Probe ────────────────────────────────────────────────────────


class TestProbe:
    """ffprobe JSON parsing."""

    @patch("shutil.which", return_value="/usr/bin/ffprobe")
    @patch("subprocess.run", return_value=_mock_run_ok(stdout=_PROBE_OUTPUT))
    def test_probe_parses_all_fields(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        info = ff.probe("input.mp4")

        assert info["duration"] == 120.5
        assert info["width"] == 1920
        assert info["height"] == 1080
        assert info["codec"] == "h264"
        assert info["fps"] == 30.0
        assert info["audio_codec"] == "aac"
        assert info["sample_rate"] == 44100
        assert info["channels"] == 2
        assert info["bitrate"] == 2500000

    @patch("shutil.which", return_value="/usr/bin/ffprobe")
    @patch("subprocess.run", return_value=_mock_run_ok(stdout=_PROBE_OUTPUT))
    def test_probe_calls_ffprobe_with_json_format(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.probe("video.mkv")
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "ffprobe"
        assert "-print_format" in cmd
        assert "json" in cmd
        assert "video.mkv" in cmd


# ── Convert ──────────────────────────────────────────────────────


class TestConvert:
    """Convert builds correct ffmpeg commands."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_simple_convert(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.convert("in.mp4", "out.webm")
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "ffmpeg"
        assert "-i" in cmd
        assert "in.mp4" in cmd
        assert "out.webm" in cmd

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_convert_with_options(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.convert(
            "in.mp4", "out.mp4",
            codec="libx265", bitrate="5M",
            resolution="1280x720", fps=24,
        )
        cmd = mock_run.call_args[0][0]
        assert "-c:v" in cmd
        assert "libx265" in cmd
        assert "-b:v" in cmd
        assert "5M" in cmd
        assert "-r" in cmd
        assert "24" in cmd
        assert "scale=1280:720" in " ".join(cmd)


# ── Extract audio ────────────────────────────────────────────────


class TestExtractAudio:
    """Extract audio track from video."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_extract_audio_defaults(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.extract_audio("video.mp4", "audio.mp3")
        cmd = mock_run.call_args[0][0]
        assert "-vn" in cmd
        assert "-acodec" in cmd
        assert "mp3" in cmd
        assert "-ab" in cmd
        assert "192k" in cmd


# ── Trim ─────────────────────────────────────────────────────────


class TestTrim:
    """Trim with start+duration vs start+end."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_trim_with_duration(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.trim("in.mp4", "out.mp4", start="00:01:00", duration="00:00:30")
        cmd = mock_run.call_args[0][0]
        assert "-ss" in cmd
        assert "00:01:00" in cmd
        assert "-t" in cmd
        assert "00:00:30" in cmd
        assert "-c" in cmd
        assert "copy" in cmd

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_trim_with_end(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.trim("in.mp4", "out.mp4", start="00:01:00", end="00:02:00")
        cmd = mock_run.call_args[0][0]
        assert "-to" in cmd
        assert "00:02:00" in cmd
        assert "-t" not in cmd


# ── Concat ───────────────────────────────────────────────────────


class TestConcat:
    """Concatenation via concat demuxer."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_concat_creates_temp_file(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.concat(["a.mp4", "b.mp4", "c.mp4"], "out.mp4")
        cmd = mock_run.call_args[0][0]
        assert "-f" in cmd
        assert "concat" in cmd
        assert "-safe" in cmd
        assert "0" in cmd

    def test_concat_rejects_single_file(self, ff: FFmpeg) -> None:
        with pytest.raises(ValueError, match="at least 2"):
            ff.concat(["only.mp4"], "out.mp4")


# ── GIF ──────────────────────────────────────────────────────────


class TestGif:
    """GIF conversion includes fps/width filters."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_gif_includes_filters(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.gif("in.mp4", "out.gif", fps=15, width=320)
        cmd = mock_run.call_args[0][0]
        cmd_str = " ".join(cmd)
        assert "fps=15" in cmd_str
        assert "scale=320" in cmd_str
        assert "palettegen" in cmd_str
        assert "paletteuse" in cmd_str


# ── Resize ───────────────────────────────────────────────────────


class TestResize:
    """Resize with width/height vs scale."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_resize_with_dimensions(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.resize("in.mp4", "out.mp4", width=1280, height=720)
        cmd = mock_run.call_args[0][0]
        assert "scale=1280:720" in " ".join(cmd)

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_resize_with_scale(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.resize("in.mp4", "out.mp4", scale=0.5)
        cmd = mock_run.call_args[0][0]
        assert "scale=iw*0.5:ih*0.5" in " ".join(cmd)

    def test_resize_no_args_raises(self, ff: FFmpeg) -> None:
        with pytest.raises(ValueError, match="width/height or scale"):
            ff.resize("in.mp4", "out.mp4")


# ── Watermark ────────────────────────────────────────────────────


class TestWatermark:
    """Watermark position mapping."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_watermark_bottom_right(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.watermark("in.mp4", "out.mp4", "logo.png", position="bottom-right")
        cmd = mock_run.call_args[0][0]
        cmd_str = " ".join(cmd)
        pos = "overlay=main_w-overlay_w-10:main_h-overlay_h-10"
        assert pos in cmd_str

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_watermark_center(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.watermark(
            "in.mp4", "out.mp4", "logo.png",
            position="center", opacity=0.8,
        )
        cmd = mock_run.call_args[0][0]
        cmd_str = " ".join(cmd)
        assert "(main_w-overlay_w)/2:(main_h-overlay_h)/2" in cmd_str
        assert "aa=0.8" in cmd_str

    def test_watermark_invalid_position(self, ff: FFmpeg) -> None:
        with pytest.raises(ValueError, match="Invalid position"):
            ff.watermark(
                "in.mp4", "out.mp4", "logo.png", position="nowhere",
            )


# ── Speed ────────────────────────────────────────────────────────


class TestSpeed:
    """Speed factor applied to video and audio."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch("subprocess.run", return_value=_mock_run_ok())
    def test_speed_2x(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        ff.speed("in.mp4", "out.mp4", factor=2.0)
        cmd = mock_run.call_args[0][0]
        cmd_str = " ".join(cmd)
        assert "setpts=PTS/2.0" in cmd_str
        assert "atempo=2.0" in cmd_str

    def test_speed_zero_raises(self, ff: FFmpeg) -> None:
        with pytest.raises(ValueError, match="positive"):
            ff.speed("in.mp4", "out.mp4", factor=0)


# ── Error handling ───────────────────────────────────────────────


class TestErrors:
    """Error handling and binary detection."""

    @patch("shutil.which", return_value=None)
    def test_missing_binary_raises(
        self, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        with pytest.raises(FFmpegNotFoundError, match="ffmpeg"):
            ff.convert("in.mp4", "out.mp4")

    @patch("shutil.which", return_value=None)
    def test_missing_ffprobe_raises(
        self, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        with pytest.raises(FFmpegNotFoundError, match="ffprobe"):
            ff.probe("in.mp4")


# ── Version ──────────────────────────────────────────────────────


class TestVersion:
    """Version property parsing."""

    @patch("shutil.which", return_value="/usr/bin/ffmpeg")
    @patch(
        "subprocess.run",
        return_value=_mock_run_ok(
            stdout="ffmpeg version 6.1.1 Copyright (c) 2000-2023\n",
        ),
    )
    def test_version_parses(
        self, mock_run: MagicMock, _w: MagicMock, ff: FFmpeg,
    ) -> None:
        assert ff.version == "6.1.1"
