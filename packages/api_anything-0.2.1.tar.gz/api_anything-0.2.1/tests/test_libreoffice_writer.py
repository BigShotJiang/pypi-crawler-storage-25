"""Tests for LibreOffice Writer API (API-Anything POC #1).

All document-creation tests run with pure Python (no LibreOffice needed).
Export tests that need the ``libreoffice`` binary are skipped when it is absent.
"""

from __future__ import annotations

import shutil
import sys
import zipfile
from pathlib import Path

import pytest

# examples/ is not a package — add it to sys.path for import
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "examples"))

from libreoffice_writer import LibreOfficeWriter

_HAS_LIBREOFFICE = shutil.which("libreoffice") or shutil.which("soffice")


@pytest.fixture()
def tmp_odt(tmp_path: Path) -> Path:
    """Return a path for a temporary .odt file."""
    return tmp_path / "test.odt"


# ── Document lifecycle ────────────────────────────────────────────


class TestCreateAndSave:
    """Creating and saving produces a valid ODF ZIP."""

    def test_create_produces_valid_odt(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.save()

        assert tmp_odt.exists()
        assert zipfile.is_zipfile(tmp_odt)

    def test_odt_contains_required_entries(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.save()

        with zipfile.ZipFile(tmp_odt) as zf:
            names = zf.namelist()
            assert "mimetype" in names
            assert "content.xml" in names
            assert "styles.xml" in names
            assert "META-INF/manifest.xml" in names

    def test_mimetype_is_first_and_uncompressed(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.save()

        with zipfile.ZipFile(tmp_odt) as zf:
            info = zf.infolist()
            assert info[0].filename == "mimetype"
            assert info[0].compress_type == zipfile.ZIP_STORED

    def test_save_without_path_raises(self) -> None:
        w = LibreOfficeWriter()
        with pytest.raises(RuntimeError, match="No document path"):
            w.save()


# ── Content manipulation ─────────────────────────────────────────


class TestHeading:
    def test_add_heading_appears_in_text(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_heading("Chapter 1", level=1)
        assert "Chapter 1" in w.get_text()

    def test_invalid_heading_level_raises(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        with pytest.raises(ValueError, match="1-6"):
            w.add_heading("Bad", level=0)


class TestParagraph:
    def test_add_paragraph_appears_in_text(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_paragraph("Hello, world!")
        assert "Hello, world!" in w.get_text()

    def test_multiple_paragraphs(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_paragraph("First")
        w.add_paragraph("Second")
        text = w.get_text()
        assert "First" in text
        assert "Second" in text


class TestTable:
    def test_add_table_content_in_text(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_table(headers=["Name", "Age"], rows=[["Alice", "30"]])
        text = w.get_text()
        assert "Name" in text
        assert "Alice" in text
        assert "30" in text

    def test_table_appears_in_html(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_table(headers=["X"], rows=[["Y"]])
        html = w.to_html()
        assert "<table" in html
        assert "<td>X</td>" in html
        assert "<td>Y</td>" in html


# ── Find & replace ───────────────────────────────────────────────


class TestFindReplace:
    def test_find_replace_returns_count(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_paragraph("foo bar foo")
        count = w.find_replace("foo", "baz")
        assert count == 2
        assert "baz bar baz" in w.get_text()

    def test_find_replace_no_match(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_paragraph("hello")
        assert w.find_replace("xyz", "abc") == 0


# ── HTML export ──────────────────────────────────────────────────


class TestToHtml:
    def test_heading_renders_as_html_tag(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_heading("Title", level=2)
        html = w.to_html()
        assert "<h2>Title</h2>" in html

    def test_paragraph_renders_as_p(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_paragraph("Content")
        assert "<p>Content</p>" in w.to_html()


# ── Round-trip ───────────────────────────────────────────────────


class TestRoundTrip:
    def test_save_and_reopen_preserves_content(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_heading("Round Trip", level=1)
        w.add_paragraph("Persistent content")
        w.save()

        w2 = LibreOfficeWriter()
        w2.open_document(str(tmp_odt))
        text = w2.get_text()
        assert "Round Trip" in text
        assert "Persistent content" in text


# ── Page break & font ────────────────────────────────────────────


class TestPageBreakAndFont:
    def test_page_break_does_not_crash(self, tmp_odt: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_page_break()
        w.save()
        assert tmp_odt.exists()

    def test_set_font_stores_values(self) -> None:
        w = LibreOfficeWriter()
        w.set_font("Arial", 14)
        assert w._font_name == "Arial"
        assert w._font_size == 14


# ── Export (requires LibreOffice) ─────────────────────────────────


@pytest.mark.skipif(not _HAS_LIBREOFFICE, reason="LibreOffice not installed")
class TestExport:
    def test_export_pdf(self, tmp_odt: Path, tmp_path: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_paragraph("PDF test")
        w.save()

        pdf_path = tmp_path / "out.pdf"
        w.export_pdf(str(pdf_path))
        assert pdf_path.exists()

    def test_export_docx(self, tmp_odt: Path, tmp_path: Path) -> None:
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.add_paragraph("DOCX test")
        w.save()

        docx_path = tmp_path / "out.docx"
        w.export_docx(str(docx_path))
        assert docx_path.exists()


class TestExportWithoutLibreOffice:
    def test_export_pdf_raises_without_lo(
        self, tmp_odt: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setattr(
            "libreoffice_writer._find_libreoffice", lambda: None
        )
        w = LibreOfficeWriter()
        w.create_document(str(tmp_odt))
        w.save()
        with pytest.raises(RuntimeError, match="LibreOffice not found"):
            w.export_pdf("out.pdf")
