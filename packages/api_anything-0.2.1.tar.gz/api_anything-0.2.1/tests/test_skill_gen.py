"""Tests for api_anything.skill_gen — SKILL.md generation from Python modules."""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from api_anything.skill_gen import (
    _ClassInfo,
    _derive_triggers,
    _extract_methods,
    _find_api_class,
    _load_module,
    _MethodInfo,
    _render_frontmatter,
    _render_method_table,
    generate_skill_md,
)

# ---------------------------------------------------------------------------
# Fixtures: sample module files
# ---------------------------------------------------------------------------


_SAMPLE_MODULE = textwrap.dedent("""\
    \"\"\"Sample API module for testing.\"\"\"


    class SampleAPI:
        \"\"\"Python API for Sample tool. Converts things.\"\"\"

        def convert(self, input_path: str, output_path: str) -> str:
            \"\"\"Convert input to output format.

            Example:
                api.convert("a.txt", "b.csv")
            \"\"\"
            return output_path

        def probe(self, path: str) -> dict:
            \"\"\"Get info about a file.\"\"\"
            return {}

        def _internal(self) -> None:
            \"\"\"This is private and should be filtered out.\"\"\"
            pass
""")


_EMPTY_MODULE = textwrap.dedent("""\
    \"\"\"Module with no classes.\"\"\"

    def standalone_func():
        pass
""")


_NO_DOC_MODULE = textwrap.dedent("""\
    class PlainAPI:
        def do_thing(self, x: int) -> None:
            pass

        def other(self):
            pass
""")


_MULTI_CLASS_MODULE = textwrap.dedent("""\
    \"\"\"Module with multiple classes.\"\"\"

    class HelperUtil:
        \"\"\"Not the main API.\"\"\"
        def help(self):
            pass

    class WidgetAPI:
        \"\"\"The main API.\"\"\"
        def create(self, name: str) -> str:
            \"\"\"Create a widget.\"\"\"
            return name

        def delete(self, widget_id: int) -> None:
            \"\"\"Delete a widget.\"\"\"
            pass
""")


@pytest.fixture
def sample_py(tmp_path: Path) -> Path:
    """Write sample module to a temp .py file."""
    p = tmp_path / "sample_api.py"
    p.write_text(_SAMPLE_MODULE, encoding="utf-8")
    return p


@pytest.fixture
def empty_py(tmp_path: Path) -> Path:
    p = tmp_path / "empty_mod.py"
    p.write_text(_EMPTY_MODULE, encoding="utf-8")
    return p


@pytest.fixture
def no_doc_py(tmp_path: Path) -> Path:
    p = tmp_path / "plain_api.py"
    p.write_text(_NO_DOC_MODULE, encoding="utf-8")
    return p


@pytest.fixture
def multi_class_py(tmp_path: Path) -> Path:
    p = tmp_path / "multi_api.py"
    p.write_text(_MULTI_CLASS_MODULE, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Tests: module loading
# ---------------------------------------------------------------------------


class TestLoadModule:
    def test_load_from_file(self, sample_py: Path) -> None:
        mod = _load_module(str(sample_py))
        assert hasattr(mod, "SampleAPI")

    def test_load_nonexistent_raises(self) -> None:
        with pytest.raises((ImportError, ModuleNotFoundError)):
            _load_module("nonexistent_module_xyz_12345")


# ---------------------------------------------------------------------------
# Tests: class finding
# ---------------------------------------------------------------------------


class TestFindAPIClass:
    def test_finds_api_suffix(self, sample_py: Path) -> None:
        mod = _load_module(str(sample_py))
        cls = _find_api_class(mod)
        assert cls is not None
        assert cls.__name__ == "SampleAPI"

    def test_returns_none_for_empty(self, empty_py: Path) -> None:
        mod = _load_module(str(empty_py))
        cls = _find_api_class(mod)
        assert cls is None

    def test_prefers_api_suffix(self, multi_class_py: Path) -> None:
        mod = _load_module(str(multi_class_py))
        cls = _find_api_class(mod)
        assert cls is not None
        assert cls.__name__ == "WidgetAPI"


# ---------------------------------------------------------------------------
# Tests: method extraction
# ---------------------------------------------------------------------------


class TestExtractMethods:
    def test_filters_private(self, sample_py: Path) -> None:
        mod = _load_module(str(sample_py))
        methods = _extract_methods(mod.SampleAPI)
        names = [m.name for m in methods]
        assert "convert" in names
        assert "probe" in names
        assert "_internal" not in names

    def test_captures_params(self, sample_py: Path) -> None:
        mod = _load_module(str(sample_py))
        methods = _extract_methods(mod.SampleAPI)
        convert = next(m for m in methods if m.name == "convert")
        param_names = [p[0] for p in convert.params]
        assert "input_path" in param_names
        assert "output_path" in param_names
        assert "self" not in param_names

    def test_no_doc_class(self, no_doc_py: Path) -> None:
        mod = _load_module(str(no_doc_py))
        methods = _extract_methods(mod.PlainAPI)
        assert len(methods) == 2
        # doc should be empty string, not None
        for m in methods:
            assert isinstance(m.doc, str)


# ---------------------------------------------------------------------------
# Tests: YAML frontmatter
# ---------------------------------------------------------------------------


class TestFrontmatter:
    def test_valid_yaml_structure(self) -> None:
        info = _ClassInfo(
            name="FFmpegAPI",
            module_name="ffmpeg_api",
            doc="Python API for FFmpeg.",
            methods=[],
        )
        triggers = ["ffmpeg", "video", "audio"]
        fm = _render_frontmatter(info, triggers)
        assert fm.startswith("---")
        assert fm.endswith("---")
        assert "name: ffmpeg" in fm
        assert "description: Python API for FFmpeg." in fm
        assert "  - ffmpeg" in fm
        assert "  - video" in fm

    def test_empty_doc_fallback(self) -> None:
        info = _ClassInfo(name="FooAPI", module_name="foo_api", doc="", methods=[])
        fm = _render_frontmatter(info, ["foo"])
        assert "description: Python API for foo" in fm


# ---------------------------------------------------------------------------
# Tests: method table
# ---------------------------------------------------------------------------


class TestMethodTable:
    def test_generates_markdown_table(self) -> None:
        methods = [
            _MethodInfo(
                name="convert",
                signature="convert(input_path, output_path)",
                doc="Convert format.",
                params=[("input_path", "str"), ("output_path", "str")],
                return_annotation="str",
            ),
        ]
        table = _render_method_table(methods)
        assert "| Method |" in table
        assert "`convert(input_path, output_path)`" in table
        assert "Convert format." in table
        assert "`input_path`" in table

    def test_no_params_shows_dash(self) -> None:
        methods = [
            _MethodInfo(
                name="close",
                signature="close()",
                doc="Close.",
                params=[],
                return_annotation="None",
            ),
        ]
        table = _render_method_table(methods)
        assert "| - |" in table


# ---------------------------------------------------------------------------
# Tests: trigger derivation
# ---------------------------------------------------------------------------


class TestDeriveTriggers:
    def test_extracts_from_class_name(self) -> None:
        info = _ClassInfo(name="FFmpegAPI", module_name="ffmpeg_api", doc="", methods=[])
        triggers = _derive_triggers(info)
        assert "ffmpeg" in triggers

    def test_filters_stop_words(self) -> None:
        info = _ClassInfo(
            name="TheAPI", module_name="the_api",
            doc="A tool for the people", methods=[],
        )
        triggers = _derive_triggers(info)
        assert "the" not in triggers
        assert "for" not in triggers


# ---------------------------------------------------------------------------
# Tests: full generation
# ---------------------------------------------------------------------------


class TestGenerateSkillMd:
    def test_full_output(self, sample_py: Path) -> None:
        content = generate_skill_md(str(sample_py))
        assert "---" in content
        assert "# Sample API" in content
        assert "## Quick Start" in content
        assert "## Available Methods" in content
        assert "`convert" in content
        assert "`probe" in content
        assert "_internal" not in content

    def test_writes_to_file(self, sample_py: Path, tmp_path: Path) -> None:
        out = tmp_path / "output" / "SKILL.md"
        content = generate_skill_md(str(sample_py), output_path=str(out))
        assert out.exists()
        assert out.read_text(encoding="utf-8") == content

    def test_no_class_raises(self, empty_py: Path) -> None:
        with pytest.raises(ValueError, match="No API class found"):
            generate_skill_md(str(empty_py))

    def test_no_doc_class(self, no_doc_py: Path) -> None:
        content = generate_skill_md(str(no_doc_py))
        assert "# Plain API" in content
        assert "## Available Methods" in content


# ---------------------------------------------------------------------------
# Tests: CLI integration
# ---------------------------------------------------------------------------


class TestCLISkillCommand:
    def test_skill_stdout(self, sample_py: Path) -> None:
        from api_anything.cli import main
        # Should return 0 and not raise
        ret = main(["skill", str(sample_py)])
        assert ret == 0

    def test_skill_json(self, sample_py: Path) -> None:
        from api_anything.cli import main
        ret = main(["skill", str(sample_py), "--json"])
        assert ret == 0

    def test_skill_bad_module(self) -> None:
        from api_anything.cli import main
        ret = main(["skill", "nonexistent_xyz_99999.py"])
        assert ret == 1


class TestCLIDetectJson:
    def test_detect_json_flag_parses(self) -> None:
        """Verify --json flag is accepted by the parser."""
        from api_anything.cli import _build_parser
        parser = _build_parser()
        args = parser.parse_args(["detect", "ffmpeg", "--json"])
        assert args.json_output is True
        assert args.software == "ffmpeg"
