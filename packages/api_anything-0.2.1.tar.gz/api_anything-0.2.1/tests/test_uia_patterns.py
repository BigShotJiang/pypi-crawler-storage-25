# ruff: noqa: RUF003
"""RFC v0.3 M0: tests for uia_patterns module and generator pattern dispatch."""

from __future__ import annotations

import ast

import pytest

from api_anything.generator import (
    _enrich_method_with_pattern,
    _primary_pattern_of_class,
    _render_pattern_body,
    generate_api,
    render_api_code,
)
from api_anything.models import APIMethod, UIControl
from api_anything.uia_patterns import (
    SUPPORTED_PATTERNS,
    UIA_PATTERN_METHOD_TEMPLATES,
    get_template,
    infer_pattern_from_control_type,
    list_patterns_for_control,
    select_primary_pattern,
)

# ---------------------------------------------------------------------------
# 1. uia_patterns constant + helper sanity
# ---------------------------------------------------------------------------


class TestPatternCoverage:
    """22-pattern coverage + template structure."""

    def test_22_patterns_defined(self) -> None:
        # RFC v0.3 §C.2 lists the full 22-pattern taxonomy.
        assert len(UIA_PATTERN_METHOD_TEMPLATES) == 22

    def test_supported_patterns_matches_mapping(self) -> None:
        assert set(SUPPORTED_PATTERNS) == set(UIA_PATTERN_METHOD_TEMPLATES.keys())

    def test_every_template_has_methods(self) -> None:
        for name, tmpl in UIA_PATTERN_METHOD_TEMPLATES.items():
            assert "methods" in tmpl, f"{name} missing methods"
            assert len(tmpl["methods"]) >= 1, f"{name} has empty methods list"

    def test_every_template_has_priority(self) -> None:
        for name, tmpl in UIA_PATTERN_METHOD_TEMPLATES.items():
            assert "priority" in tmpl, f"{name} missing priority"
            assert isinstance(tmpl["priority"], int)

    def test_method_entry_required_keys(self) -> None:
        required = {"verb", "body", "confidence", "return_type", "params", "suffix_mode"}
        for name, tmpl in UIA_PATTERN_METHOD_TEMPLATES.items():
            for m in tmpl["methods"]:
                missing = required - set(m.keys())
                assert not missing, f"{name} method missing keys: {missing}"


# ---------------------------------------------------------------------------
# 2. Template rendering produces valid Python
# ---------------------------------------------------------------------------


class TestTemplateBodiesAreValidPython:
    """Each template body (after format) must parse as Python."""

    @pytest.mark.parametrize("pattern_name", sorted(UIA_PATTERN_METHOD_TEMPLATES.keys()))
    def test_body_formats_and_parses(self, pattern_name: str) -> None:
        tmpl = UIA_PATTERN_METHOD_TEMPLATES[pattern_name]
        for m in tmpl["methods"]:
            raw = m["body"]
            # locator 是唯一 placeholder
            try:
                rendered = raw.format(locator="SampleControl")
            except (KeyError, IndexError) as exc:
                pytest.fail(f"{pattern_name} body format error: {exc}")
            # Wrap into a dummy function to parse
            wrapped = "def _dummy(self):\n" + "\n".join(
                f"    {line}" for line in rendered.splitlines()
            )
            ast.parse(wrapped)


# ---------------------------------------------------------------------------
# 3. select_primary_pattern priority logic
# ---------------------------------------------------------------------------


class TestSelectPrimaryPattern:
    def test_value_beats_invoke(self) -> None:
        # ValuePattern priority 90 vs InvokePattern 80 → Value wins
        assert select_primary_pattern(["InvokePattern", "ValuePattern"]) == "ValuePattern"

    def test_toggle_beats_invoke(self) -> None:
        assert (
            select_primary_pattern(["InvokePattern", "TogglePattern"]) == "TogglePattern"
        )

    def test_expand_beats_selection(self) -> None:
        # ExpandCollapsePattern (70) > SelectionPattern (60)
        assert (
            select_primary_pattern(["SelectionPattern", "ExpandCollapsePattern"])
            == "ExpandCollapsePattern"
        )

    def test_empty_returns_none(self) -> None:
        assert select_primary_pattern([]) is None
        assert select_primary_pattern(None) is None

    def test_unknown_only_returns_none(self) -> None:
        assert select_primary_pattern(["UnicornPattern"]) is None

    def test_mixed_known_unknown(self) -> None:
        # Unknown 過濾掉，留下 Invoke
        assert (
            select_primary_pattern(["UnicornPattern", "InvokePattern"]) == "InvokePattern"
        )


class TestInferFromControlType:
    def test_button(self) -> None:
        assert infer_pattern_from_control_type("Button") == "InvokePattern"

    def test_textbox(self) -> None:
        assert infer_pattern_from_control_type("TextBox") == "ValuePattern"

    def test_checkbox(self) -> None:
        assert infer_pattern_from_control_type("CheckBox") == "TogglePattern"

    def test_slider(self) -> None:
        assert infer_pattern_from_control_type("Slider") == "RangeValuePattern"

    def test_unknown(self) -> None:
        assert infer_pattern_from_control_type("NotAControl") is None


class TestListPatternsForControl:
    def test_orders_by_priority(self) -> None:
        out = list_patterns_for_control(["InvokePattern", "ValuePattern", "TogglePattern"])
        # Value(90) > Toggle(85) > Invoke(80)
        assert out == ["ValuePattern", "TogglePattern", "InvokePattern"]

    def test_none_input(self) -> None:
        assert list_patterns_for_control(None) == []


class TestGetTemplate:
    def test_known(self) -> None:
        tmpl = get_template("InvokePattern")
        assert tmpl is not None
        assert tmpl["priority"] == 80

    def test_unknown(self) -> None:
        assert get_template("GhostPattern") is None


# ---------------------------------------------------------------------------
# 4. _enrich_method_with_pattern behaviour
# ---------------------------------------------------------------------------


class TestEnrichMethodWithPattern:
    def test_explicit_value_pattern_appends_getter(self) -> None:
        ctrl = UIControl(name="Name", control_type="TextBox", patterns=["ValuePattern"])
        method = APIMethod(
            name="set_name",
            docstring="Set name.",
            operation_mode="uia",
        )
        extras = _enrich_method_with_pattern(method, ctrl)
        # ValuePattern template has 2 methods (set + get) → 1 extra (getter)
        assert len(extras) == 1
        assert extras[0].name.startswith("get_")
        assert extras[0].uia_pattern == "ValuePattern"
        assert method.uia_pattern == "ValuePattern"
        assert method.internal_mode == "uia_pattern"

    def test_infer_fallback_does_not_duplicate(self) -> None:
        # Legacy path: no patterns list → infer only, no extra method.
        ctrl = UIControl(name="OK", control_type="Button", patterns=None)
        method = APIMethod(name="click_ok", docstring=".", operation_mode="uia")
        extras = _enrich_method_with_pattern(method, ctrl)
        assert extras == []
        assert method.uia_pattern == "InvokePattern"
        assert method.internal_mode == "uia_pattern"

    def test_unknown_control_type_stays_legacy(self) -> None:
        ctrl = UIControl(name="?", control_type="Mystery", patterns=None)
        method = APIMethod(name="click_x", docstring=".", operation_mode="uia")
        extras = _enrich_method_with_pattern(method, ctrl)
        assert extras == []
        assert method.internal_mode == "uia_legacy"

    def test_priority_value_over_invoke(self) -> None:
        # Control 同時支援 Value + Invoke → 選 ValuePattern
        ctrl = UIControl(
            name="Field",
            control_type="Edit",
            patterns=["InvokePattern", "ValuePattern"],
        )
        method = APIMethod(name="set_field", docstring=".", operation_mode="uia")
        _enrich_method_with_pattern(method, ctrl)
        assert method.uia_pattern == "ValuePattern"


# ---------------------------------------------------------------------------
# 5. _render_pattern_body
# ---------------------------------------------------------------------------


class TestRenderPatternBody:
    def test_invoke_pattern_produces_invoke_call(self) -> None:
        method = APIMethod(
            name="invoke_save",
            docstring=".",
            operation_mode="uia",
            uia_pattern="InvokePattern",
        )
        ctrl = UIControl(name="Save", control_type="Button", patterns=["InvokePattern"])
        body = _render_pattern_body(method, ctrl)
        assert body is not None
        joined = "\n".join(body)
        assert "GetInvokePattern" in joined
        assert ".Invoke()" in joined
        assert "'Save'" in joined  # locator repr

    def test_value_setter_body_has_setvalue(self) -> None:
        method = APIMethod(
            name="set_name",
            docstring=".",
            operation_mode="uia",
            uia_pattern="ValuePattern",
        )
        ctrl = UIControl(name="Name", control_type="Edit", patterns=["ValuePattern"])
        body = _render_pattern_body(method, ctrl)
        assert body is not None
        joined = "\n".join(body)
        assert "GetValuePattern" in joined
        assert "SetValue(value)" in joined

    def test_no_pattern_returns_none(self) -> None:
        method = APIMethod(name="do_x", docstring=".", operation_mode="uia")
        ctrl = UIControl(name="X", control_type="Button")
        assert _render_pattern_body(method, ctrl) is None


# ---------------------------------------------------------------------------
# 6. End-to-end: generate_api + render_api_code pattern wiring
# ---------------------------------------------------------------------------


class TestGeneratePatternIntegration:
    def test_generate_with_explicit_patterns(self) -> None:
        controls = [
            UIControl(name="Save", control_type="Button", patterns=["InvokePattern"]),
            UIControl(
                name="File Name",
                control_type="TextBox",
                patterns=["ValuePattern"],
            ),
        ]
        result = generate_api("Notepad", controls, tier="3A")
        # Control-derived UIA methods must carry pattern metadata.
        # (Lifecycle 'close' on tier 3A is also UIA but has no source control.)
        control_methods = [
            m
            for m in result.api_class.methods
            if m.operation_mode == "uia" and m.name not in {"launch", "close"}
        ]
        assert control_methods, "expected at least one control-derived UIA method"
        for m in control_methods:
            assert m.uia_pattern in SUPPORTED_PATTERNS
            assert m.internal_mode == "uia_pattern"

    def test_generate_pattern_used_metadata(self) -> None:
        controls = [
            UIControl(name="X", control_type="Button", patterns=["InvokePattern"]),
        ]
        result = generate_api("App", controls, tier="3A")
        assert result.pattern_used in SUPPORTED_PATTERNS

    def test_rendered_source_is_parseable(self) -> None:
        controls = [
            UIControl(
                name="Name",
                control_type="TextBox",
                patterns=["ValuePattern"],
            ),
            UIControl(
                name="Dark Mode",
                control_type="CheckBox",
                patterns=["TogglePattern"],
            ),
        ]
        result = generate_api("DemoApp", controls, tier="3A")
        ast.parse(result.source_code)

    def test_rendered_source_contains_pattern_body(self) -> None:
        controls = [
            UIControl(name="Save", control_type="Button", patterns=["InvokePattern"]),
        ]
        result = generate_api("App", controls, tier="3A")
        # Pattern-driven body uses GetInvokePattern().Invoke()
        assert "GetInvokePattern" in result.source_code

    def test_docstring_contains_pattern_metadata(self) -> None:
        controls = [
            UIControl(name="Save", control_type="Button", patterns=["InvokePattern"]),
        ]
        result = generate_api("App", controls, tier="3A")
        # v0.3 M0 docstring 三欄位
        assert "internal_mode:" in result.source_code
        assert "pattern_used: InvokePattern" in result.source_code
        assert "generation_confidence:" in result.source_code

    def test_value_pattern_generates_getter_method(self) -> None:
        controls = [
            UIControl(
                name="Username",
                control_type="TextBox",
                patterns=["ValuePattern"],
            ),
        ]
        result = generate_api("App", controls, tier="3A")
        method_names = [m.name for m in result.api_class.methods]
        # set_username 由 v0.2 path 生，get_username 是 v0.3 衍生
        assert "set_username" in method_names
        assert "get_username" in method_names

    def test_legacy_no_patterns_v02_behaviour_preserved(self) -> None:
        # 不給 patterns → v0.2 legacy path, infer only, no extras
        controls = [
            UIControl(name="Save", control_type="Button"),  # patterns=None
        ]
        result = generate_api("App", controls, tier="3A")
        method_names = [m.name for m in result.api_class.methods]
        # launch + click_save + close only (3 methods)
        assert method_names == ["launch", "click_save", "close"]


# ---------------------------------------------------------------------------
# 7. _primary_pattern_of_class selection
# ---------------------------------------------------------------------------


class TestPrimaryPatternOfClass:
    def test_most_frequent_wins(self) -> None:
        controls = [
            UIControl(name="A", control_type="Button", patterns=["InvokePattern"]),
            UIControl(name="B", control_type="Button", patterns=["InvokePattern"]),
            UIControl(name="C", control_type="Edit", patterns=["ValuePattern"]),
        ]
        result = generate_api("App", controls, tier="3A")
        # Invoke 出現 2 次（A + B），Value 1 次（C 加上 getter = 2）→ tie
        # tie 時 select_primary_pattern 取 priority 高者 = ValuePattern (90)
        assert result.pattern_used in {"InvokePattern", "ValuePattern"}

    def test_empty_methods_none(self) -> None:
        from api_anything.models import APIClass

        cls = APIClass(
            class_name="X",
            module_name="x",
            docstring=".",
            software_name="x",
        )
        assert _primary_pattern_of_class(cls) is None


# ---------------------------------------------------------------------------
# 8. Fallback backwards-compat (v0.2 A 未破)
# ---------------------------------------------------------------------------


class TestFallbackStillWorks:
    def test_tier_3b_still_wires_cli_fallback(self) -> None:
        # v0.2 A 合約：tier 3B 生成碼必 import invoke_cli
        controls = [
            UIControl(name="Save", control_type="Button", patterns=["InvokePattern"]),
        ]
        result = generate_api("App", controls, tier="3B")
        assert "from api_anything.cli_fallback import invoke_cli" in result.source_code

    def test_render_without_controls_is_v02_body(self) -> None:
        # render_api_code 不給 controls → legacy body (NotImplementedError)
        controls = [UIControl(name="X", control_type="Button")]
        result = generate_api("App", controls, tier="3A")
        # 這裡 generate_api 給了 controls，所以應該是 pattern path — 確認 legacy
        # 測試需先拆 api_class 再 render 不傳 controls
        code_no_ctrl = render_api_code(result.api_class, fallback_enabled=False)
        assert "NotImplementedError" in code_no_ctrl

    def test_rendered_has_available_patterns_list_when_given(self) -> None:
        controls = [
            UIControl(
                name="Save",
                control_type="Button",
                patterns=["InvokePattern", "TogglePattern"],
            ),
        ]
        result = generate_api("App", controls, tier="3A")
        assert "available_patterns:" in result.source_code
