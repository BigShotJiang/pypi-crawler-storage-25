"""Tests for session persistence, config, replay, and the ``run`` subcommand."""

from __future__ import annotations

import json
import textwrap
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from api_anything.repl import (
    HistoryEntry,
    LoadedAPI,
    ReplState,
    get_public_methods,
    handle_dot_command,
    load_config,
    load_session,
    replay_session,
    run_repl,
    save_config,
    save_session,
)
from api_anything.cli import main as cli_main


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

class _FakeAPI:
    """Minimal API for testing."""

    def greet(self, name: str) -> str:
        return f"Hello, {name}!"

    def add(self, a: int, b: int) -> int:
        return a + b


@pytest.fixture()
def loaded_api() -> LoadedAPI:
    methods = get_public_methods(_FakeAPI)
    return LoadedAPI(
        name="FakeAPI",
        instance=_FakeAPI(),
        cls=_FakeAPI,
        methods=methods,
        module_path="fake.py",
    )


@pytest.fixture()
def state(loaded_api: LoadedAPI) -> ReplState:
    return ReplState(apis=[loaded_api])


@pytest.fixture()
def console() -> MagicMock:
    return MagicMock()


# ---------------------------------------------------------------------------
# Session save / load
# ---------------------------------------------------------------------------

class TestSessionSaveLoad:
    """Test session file persistence."""

    def test_save_creates_json(self, state: ReplState, tmp_path: Path) -> None:
        state.history.append(
            HistoryEntry(command='greet("world")', result="Hello, world!", timestamp=time.time())
        )
        path = save_session(state, session_dir=tmp_path)
        assert path.exists()
        assert path.suffix == ".json"
        data = json.loads(path.read_text(encoding="utf-8"))
        assert data["class"] == "FakeAPI"
        assert len(data["commands"]) == 1
        assert data["commands"][0]["input"] == 'greet("world")'

    def test_save_skips_dot_commands(self, state: ReplState, tmp_path: Path) -> None:
        state.history.append(HistoryEntry(command=".json", result=None, timestamp=time.time()))
        state.history.append(HistoryEntry(command='add(1, 2)', result=3, timestamp=time.time()))
        path = save_session(state, session_dir=tmp_path)
        data = json.loads(path.read_text(encoding="utf-8"))
        assert len(data["commands"]) == 1
        assert data["commands"][0]["input"] == "add(1, 2)"

    def test_load_most_recent(self, tmp_path: Path) -> None:
        # Write two session files, verify latest is loaded
        (tmp_path / "20260101T000000.json").write_text(
            json.dumps({"commands": [{"input": "old()"}]}), encoding="utf-8"
        )
        import time as _time
        _time.sleep(0.05)  # ensure different mtime
        (tmp_path / "20260102T000000.json").write_text(
            json.dumps({"commands": [{"input": "new()"}]}), encoding="utf-8"
        )
        data = load_session(session_dir=tmp_path)
        assert data is not None
        assert data["commands"][0]["input"] == "new()"

    def test_load_empty_dir(self, tmp_path: Path) -> None:
        assert load_session(session_dir=tmp_path) is None

    def test_load_nonexistent_dir(self, tmp_path: Path) -> None:
        assert load_session(session_dir=tmp_path / "nope") is None


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

class TestConfig:
    """Test config file creation and loading."""

    def test_default_config(self, tmp_path: Path) -> None:
        config = load_config(config_path=tmp_path / "config.json")
        assert config["auto_save"] is True
        assert config["json_output"] is False
        assert config["theme"] == "dark"

    def test_save_and_load_config(self, tmp_path: Path) -> None:
        path = tmp_path / "config.json"
        save_config({"json_output": True, "theme": "light"}, config_path=path)
        config = load_config(config_path=path)
        assert config["json_output"] is True
        assert config["theme"] == "light"
        # Defaults should still be present for unset keys
        assert config["auto_save"] is True


# ---------------------------------------------------------------------------
# Replay
# ---------------------------------------------------------------------------

class TestReplay:
    """Test .replay dot-command."""

    def test_replay_executes_history(self, state: ReplState, console: MagicMock) -> None:
        state.history.append(
            HistoryEntry(command='greet("replay")', result="Hello, replay!", timestamp=time.time())
        )
        replay_session(state, console)
        # Should have printed the command, the result, and the summary
        calls = [str(c) for c in console.print.call_args_list]
        joined = " ".join(calls)
        assert "replay" in joined.lower() or "Replayed 1" in joined

    def test_replay_via_dot_command(self, state: ReplState, console: MagicMock) -> None:
        state.history.append(
            HistoryEntry(command='add(2, 3)', result=5, timestamp=time.time())
        )
        handle_dot_command(".replay", state, console)
        calls = [str(c) for c in console.print.call_args_list]
        joined = " ".join(calls)
        assert "Replayed" in joined


# ---------------------------------------------------------------------------
# run subcommand (CLI)
# ---------------------------------------------------------------------------

class TestRunSubcommand:
    """Test ``api-anything run <module> <method> [args]``."""

    def test_run_no_args(self, tmp_path: Path) -> None:
        py = tmp_path / "sample_api.py"
        py.write_text(textwrap.dedent("""\
            class SampleAPI:
                def ping(self) -> str:
                    return "pong"
        """))
        code = cli_main(["run", str(py), "ping"])
        assert code == 0

    def test_run_with_args(self, tmp_path: Path) -> None:
        py = tmp_path / "math_api.py"
        py.write_text(textwrap.dedent("""\
            class MathAPI:
                def add(self, a: int, b: int) -> int:
                    return a + b
        """))
        code = cli_main(["run", str(py), "add", "3", "4"])
        assert code == 0

    def test_run_bad_method(self, tmp_path: Path) -> None:
        py = tmp_path / "tiny_api.py"
        py.write_text("class TinyAPI:\n    def f(self): return 1\n")
        code = cli_main(["run", str(py), "nonexistent"])
        assert code == 1

    def test_run_bad_module(self) -> None:
        code = cli_main(["run", "/nonexistent/fake.py", "ping"])
        assert code == 1


# ---------------------------------------------------------------------------
# REPL auto-save integration
# ---------------------------------------------------------------------------

class TestReplAutoSave:
    """Test that run_repl auto-saves session on exit."""

    def test_auto_save_on_quit(self, tmp_path: Path) -> None:
        py = tmp_path / "auto_api.py"
        py.write_text(textwrap.dedent("""\
            class AutoAPI:
                def ping(self) -> str:
                    return "pong"
        """))
        session_dir = tmp_path / "sessions"
        config_path = tmp_path / "config.json"
        save_config({"auto_save": True}, config_path=config_path)

        with patch("api_anything.repl._HAS_PROMPT_TOOLKIT", False), \
             patch("builtins.input", side_effect=['ping()', ".quit"]):
            code = run_repl(
                [str(py)],
                session_dir=session_dir,
                config_path=config_path,
            )
        assert code == 0
        # Session file should exist
        files = list(session_dir.glob("*.json"))
        assert len(files) == 1
        data = json.loads(files[0].read_text(encoding="utf-8"))
        assert len(data["commands"]) == 1
        assert data["commands"][0]["input"] == "ping()"
