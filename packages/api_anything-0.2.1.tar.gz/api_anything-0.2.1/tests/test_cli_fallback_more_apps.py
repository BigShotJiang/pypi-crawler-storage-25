"""v0.2.1 A 測試: audacity / kdenlive / krita 的 cli_fallback schema + decorator.

- Schema 可以 load 成 dict 並通過 shape 檢查
- 三個 apis/*.py 的關鍵 method 確實被 @with_cli_fallback 包裝
- Windows 專屬 module 在 test method 內 import, 避免 collection 階段炸

搭配 test_cli_fallback.py 的 Notepad 整合測試, 補齊 v0.2 A 剩餘 3 款應用。
"""

from __future__ import annotations

import sys

import pytest

from api_anything.cli_fallback import CliFallbackError, load_schema


class TestNewSchemas:
    """audacity / kdenlive / krita YAML schema 完整性."""

    SCHEMAS = ("audacity", "kdenlive", "krita")

    def test_audacity_schema_loads(self) -> None:
        schema = load_schema("audacity")
        assert schema["cli_binary"] == "cli-anything-audacity"
        assert "export_audio" in schema["methods"]
        assert schema["methods"]["export_audio"]["subcmd"] == "export"

    def test_kdenlive_schema_loads(self) -> None:
        schema = load_schema("kdenlive")
        assert schema["cli_binary"] == "cli-anything-kdenlive"
        assert "render" in schema["methods"]
        assert schema["methods"]["render"]["subcmd"] == "render"
        # render 必須把 project_path + output_path 都放進 args
        assert "project_path" in schema["methods"]["render"]["args"]
        assert "output_path" in schema["methods"]["render"]["args"]

    def test_krita_schema_loads(self) -> None:
        schema = load_schema("krita")
        assert schema["cli_binary"] == "cli-anything-krita"
        assert "export" in schema["methods"]
        assert "export_png" in schema["methods"]
        assert "export_jpg" in schema["methods"]

    def test_all_new_schemas_have_required_keys(self) -> None:
        """三個 schema 必須通過最小 shape: cli_binary / methods / method.subcmd."""
        for sw in self.SCHEMAS:
            schema = load_schema(sw)
            assert "cli_binary" in schema, f"{sw} missing cli_binary"
            assert "methods" in schema, f"{sw} missing methods"
            assert isinstance(schema["methods"], dict)
            assert len(schema["methods"]) >= 1, f"{sw} has no methods"
            for name, spec in schema["methods"].items():
                assert "subcmd" in spec, f"{sw}.{name} missing subcmd"
                assert "args" in spec, f"{sw}.{name} missing args"
                assert isinstance(spec["args"], list)

    def test_version_pin_is_string_when_present(self) -> None:
        """soft pin: 若有 version_pin 必為 str."""
        for sw in self.SCHEMAS:
            schema = load_schema(sw)
            pin = schema.get("version_pin")
            if pin is not None:
                assert isinstance(pin, str)

    def test_missing_schema_still_raises(self) -> None:
        """regression guard: load_schema 對於未知 software 仍應拋 CliFallbackError."""
        with pytest.raises(CliFallbackError):
            load_schema("nonexistent-app-xyz-v021")


class TestKdenliveDecorator:
    """Kdenlive 的 render / render_with_profile / list_profiles 必須被包裝."""

    def test_render_wrapped(self) -> None:
        from api_anything.apis.kdenlive import Kdenlive
        assert hasattr(Kdenlive.render, "__wrapped__"), (
            "Kdenlive.render 未掛 @with_cli_fallback"
        )

    def test_render_with_profile_wrapped(self) -> None:
        from api_anything.apis.kdenlive import Kdenlive
        assert hasattr(Kdenlive.render_with_profile, "__wrapped__")

    def test_list_profiles_wrapped(self) -> None:
        from api_anything.apis.kdenlive import Kdenlive
        assert hasattr(Kdenlive.list_profiles, "__wrapped__")

    def test_wrapped_preserves_name(self) -> None:
        from api_anything.apis.kdenlive import Kdenlive
        assert Kdenlive.render.__name__ == "render"
        assert Kdenlive.list_profiles.__name__ == "list_profiles"


class TestKritaDecorator:
    """Krita 的 export / export_png / export_jpg 必須被包裝."""

    def test_export_wrapped(self) -> None:
        from api_anything.apis.krita import Krita
        assert hasattr(Krita.export, "__wrapped__")

    def test_export_png_wrapped(self) -> None:
        from api_anything.apis.krita import Krita
        assert hasattr(Krita.export_png, "__wrapped__")

    def test_export_jpg_wrapped(self) -> None:
        from api_anything.apis.krita import Krita
        assert hasattr(Krita.export_jpg, "__wrapped__")

    def test_wrapped_preserves_doc(self) -> None:
        from api_anything.apis.krita import Krita
        # 原始 docstring 應保留
        assert "PNG" in (Krita.export_png.__doc__ or "")


class TestAudacityDecorator:
    """Audacity 的 import_audio / export / get_info 必須被包裝.

    Audacity import 在非 Windows 也可行 (沒有 sys.platform guard 在 module top),
    但 connect() 才需要 pipe; 所以 class 定義階段 decorator 檢查可在任何平台跑.
    """

    def test_import_audio_wrapped(self) -> None:
        from api_anything.apis.audacity import Audacity
        assert hasattr(Audacity.import_audio, "__wrapped__")

    def test_export_wrapped(self) -> None:
        from api_anything.apis.audacity import Audacity
        assert hasattr(Audacity.export, "__wrapped__")

    def test_get_info_wrapped(self) -> None:
        from api_anything.apis.audacity import Audacity
        assert hasattr(Audacity.get_info, "__wrapped__")


class TestFallbackTriggersByName:
    """Decorator 掛上後, 對應 Error 子類應觸發 cli fallback.

    這驗證 fallback_on=["XxxError"] 的 name-based match 路徑在新 apis 模組可用.
    """

    def test_kdenlive_not_found_triggers_fallback(self) -> None:
        from unittest.mock import patch

        from api_anything.apis.kdenlive import Kdenlive, KdenliveNotFoundError

        kd = Kdenlive.__new__(Kdenlive)
        kd._exe = "nonexistent-kdenlive-binary"

        # 讓 primary 炸出 KdenliveNotFoundError (FileNotFoundError 子類,
        # 同時也被 fallback_on 名稱白名單涵蓋)
        # 模擬 cli-anything-kdenlive 也不存在 -> CliFallbackError
        with patch.object(
            Kdenlive, "_ensure_binary", side_effect=KdenliveNotFoundError(),
        ), patch(
            "api_anything.cli_fallback.shutil.which", return_value=None,
        ), pytest.raises(CliFallbackError):
            kd.render("x.kdenlive", "out.mp4")

    def test_krita_not_found_triggers_fallback(self) -> None:
        from unittest.mock import patch

        from api_anything.apis.krita import Krita, KritaNotFoundError

        k = Krita()
        with patch.object(
            Krita, "_ensure_binary", side_effect=KritaNotFoundError(),
        ), patch(
            "api_anything.cli_fallback.shutil.which", return_value=None,
        ), pytest.raises(CliFallbackError):
            k.export("a.kra", "a.png")


class TestAudacityOnlyImportableOnSupportedPlatforms:
    """audacity.py module top 無 sys.platform guard, 故應在任何平台 importable.

    保障 ship 時 macOS/Linux 使用者 pip install 不炸.
    """

    def test_module_imports_on_this_platform(self) -> None:
        # 實際 import 本身就是測試
        import api_anything.apis.audacity as au_mod

        assert au_mod.Audacity is not None
        # sys 被 module 使用, 順手確認存在 (防 pre-existing regressions)
        assert sys is not None
