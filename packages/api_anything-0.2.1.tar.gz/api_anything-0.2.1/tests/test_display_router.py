"""Tests for ``api_anything.display_router`` (v0.2 C 項).

涵蓋矩陣（channel × payload type）：

|              | CLI              | JSON           | REPL   | WEB      |
|--------------|------------------|----------------|--------|----------|
| TierResult   | Panel            | json.loads OK  | str    | dict+md  |
| CheckResult  | Panel            | json.loads OK  | str    | dict     |
| APIClass     | Panel            | json.loads OK  | str    | dict     |
| APIMethod    | Panel            | json.loads OK  | str    | dict     |
| GenResult    | Panel            | json.loads OK  | str    | dict     |
| dict         | Table            | json str       | str    | dict     |
| error        | Panel            | json str       | str    | dict     |
| unsupported  | raise            | raise          | raise  | raise    |
"""

from __future__ import annotations

import json

import pytest
from rich.panel import Panel
from rich.table import Table

from api_anything.display_router import (
    DisplayRouter,
    OutputChannel,
    UnsupportedPayloadError,
    render,
    render_error,
)
from api_anything.models import APIClass, APIMethod, APIParam, GenerationResult
from api_anything.tier_detect import CheckResult, Tier, TierResult


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def sample_tier_result() -> TierResult:
    return TierResult(
        software="notepad",
        version="v1.0",
        tier=Tier.T3A,
        checks={
            "python_binding": CheckResult(passed=False, detail="not on PyPI"),
            "source_code": CheckResult(passed=False, detail="--"),
            "cli_support": CheckResult(passed=False, detail="not in PATH"),
            "uia_quality": CheckResult(passed=True, detail="80%", value=0.8),
        },
        electron_suspected=True,
    )


@pytest.fixture
def sample_api_class() -> APIClass:
    return APIClass(
        class_name="NotepadAPI",
        module_name="notepad_api",
        docstring="Controls Windows Notepad.",
        software_name="notepad",
        tier="3A",
        methods=[
            APIMethod(
                name="open_file",
                docstring="Open a file.",
                params=[APIParam(name="path", type_hint="str")],
                return_type="None",
                operation_mode="uia",
            ),
        ],
    )


@pytest.fixture
def sample_generation_result(sample_api_class: APIClass) -> GenerationResult:
    return GenerationResult(
        api_class=sample_api_class,
        source_code="class NotepadAPI: ...",
        test_code="def test_foo(): pass",
        tokens_used=1234,
        generation_time_seconds=2.5,
    )


# ---------------------------------------------------------------------------
# Channel instantiation
# ---------------------------------------------------------------------------


class TestChannelInit:
    def test_enum_channel(self) -> None:
        r = DisplayRouter(OutputChannel.CLI)
        assert r.channel is OutputChannel.CLI

    def test_string_channel_valid(self) -> None:
        r = DisplayRouter("json")
        assert r.channel is OutputChannel.JSON

    def test_string_channel_invalid(self) -> None:
        with pytest.raises(UnsupportedPayloadError):
            DisplayRouter("invalid_channel")


# ---------------------------------------------------------------------------
# TierResult across channels
# ---------------------------------------------------------------------------


class TestTierResultRendering:
    def test_cli_returns_panel(self, sample_tier_result: TierResult) -> None:
        out = DisplayRouter(OutputChannel.CLI).render(sample_tier_result)
        assert isinstance(out, Panel)

    def test_json_roundtrip(self, sample_tier_result: TierResult) -> None:
        out = DisplayRouter(OutputChannel.JSON).render(sample_tier_result)
        assert isinstance(out, str)
        data = json.loads(out)
        assert data["software"] == "notepad"
        assert data["tier"] == "3A"
        assert "checks" in data
        assert data["electron_suspected"] is True

    def test_repl_is_plain_text(self, sample_tier_result: TierResult) -> None:
        out = DisplayRouter(OutputChannel.REPL).render(sample_tier_result)
        assert isinstance(out, str)
        assert "notepad" in out
        assert "Tier 3A" in out
        # Electron suspected hint appears only in REPL text
        assert "electron" in out.lower() or "shell" in out.lower()

    def test_web_is_dict_with_markdown(
        self, sample_tier_result: TierResult,
    ) -> None:
        out = DisplayRouter(OutputChannel.WEB).render(sample_tier_result)
        assert isinstance(out, dict)
        assert "markdown" in out
        assert out["tier"] == "3A"
        assert "Tier Detection Report" in out["markdown"]


# ---------------------------------------------------------------------------
# CheckResult across channels
# ---------------------------------------------------------------------------


class TestCheckResultRendering:
    def test_cli(self) -> None:
        cr = CheckResult(passed=True, detail="found")
        out = DisplayRouter(OutputChannel.CLI).render(cr, title="PyPI")
        assert isinstance(out, Panel)

    def test_json(self) -> None:
        cr = CheckResult(passed=False, detail="missing")
        out = DisplayRouter(OutputChannel.JSON).render(cr)
        data = json.loads(out)
        assert data == {"passed": False, "detail": "missing", "value": None}

    def test_repl(self) -> None:
        cr = CheckResult(passed=True, detail="ok")
        out = DisplayRouter(OutputChannel.REPL).render(cr, title="pypi")
        assert isinstance(out, str)
        assert "[OK]" in out and "pypi" in out

    def test_web(self) -> None:
        cr = CheckResult(passed=True, detail="ok")
        out = DisplayRouter(OutputChannel.WEB).render(cr, title="PyPI")
        assert out["passed"] is True
        assert "markdown" in out


# ---------------------------------------------------------------------------
# APIClass / APIMethod
# ---------------------------------------------------------------------------


class TestAPIClassRendering:
    def test_cli(self, sample_api_class: APIClass) -> None:
        out = DisplayRouter(OutputChannel.CLI).render(sample_api_class)
        assert isinstance(out, Panel)

    def test_json(self, sample_api_class: APIClass) -> None:
        out = DisplayRouter(OutputChannel.JSON).render(sample_api_class)
        data = json.loads(out)
        assert data["class_name"] == "NotepadAPI"
        assert len(data["methods"]) == 1

    def test_repl(self, sample_api_class: APIClass) -> None:
        out = DisplayRouter(OutputChannel.REPL).render(sample_api_class)
        assert "NotepadAPI" in out and "3A" in out

    def test_web(self, sample_api_class: APIClass) -> None:
        out = DisplayRouter(OutputChannel.WEB).render(sample_api_class)
        assert out["class_name"] == "NotepadAPI"
        assert len(out["rows"]) == 1
        assert out["rows"][0]["method"] == "open_file"


class TestAPIMethodRendering:
    @pytest.fixture
    def m(self) -> APIMethod:
        return APIMethod(
            name="read",
            docstring="Read file.",
            params=[APIParam(name="path", type_hint="str")],
            return_type="str",
        )

    def test_cli(self, m: APIMethod) -> None:
        out = DisplayRouter(OutputChannel.CLI).render(m)
        assert isinstance(out, Panel)

    def test_json(self, m: APIMethod) -> None:
        out = DisplayRouter(OutputChannel.JSON).render(m)
        data = json.loads(out)
        assert data["name"] == "read"

    def test_repl(self, m: APIMethod) -> None:
        out = DisplayRouter(OutputChannel.REPL).render(m)
        assert "read(" in out and "-> str" in out

    def test_web(self, m: APIMethod) -> None:
        out = DisplayRouter(OutputChannel.WEB).render(m)
        assert out["name"] == "read"


# ---------------------------------------------------------------------------
# GenerationResult
# ---------------------------------------------------------------------------


class TestGenerationResultRendering:
    def test_cli(self, sample_generation_result: GenerationResult) -> None:
        out = DisplayRouter(OutputChannel.CLI).render(sample_generation_result)
        assert isinstance(out, Panel)

    def test_json(self, sample_generation_result: GenerationResult) -> None:
        out = DisplayRouter(OutputChannel.JSON).render(sample_generation_result)
        data = json.loads(out)
        assert data["api_class"]["class_name"] == "NotepadAPI"
        assert data["tokens_used"] == 1234

    def test_json_with_tier_result(
        self,
        sample_generation_result: GenerationResult,
        sample_tier_result: TierResult,
    ) -> None:
        """tier_result 為 TierResult 時仍可 json round-trip。"""
        sample_generation_result.tier_result = sample_tier_result
        out = DisplayRouter(OutputChannel.JSON).render(sample_generation_result)
        data = json.loads(out)
        assert data["tier_result"]["software"] == "notepad"

    def test_repl(self, sample_generation_result: GenerationResult) -> None:
        out = DisplayRouter(OutputChannel.REPL).render(sample_generation_result)
        assert "NotepadAPI" in out and "1234 tokens" in out

    def test_web(self, sample_generation_result: GenerationResult) -> None:
        out = DisplayRouter(OutputChannel.WEB).render(sample_generation_result)
        assert out["class_name"] == "NotepadAPI"
        assert out["source_code"] == "class NotepadAPI: ..."


# ---------------------------------------------------------------------------
# Generic dict / list / primitive
# ---------------------------------------------------------------------------


class TestGenericRendering:
    def test_cli_dict_returns_table(self) -> None:
        out = DisplayRouter(OutputChannel.CLI).render(
            {"a": 1, "b": 2}, title="stats",
        )
        assert isinstance(out, Table)

    def test_cli_list_returns_panel(self) -> None:
        out = DisplayRouter(OutputChannel.CLI).render([1, 2, 3])
        assert isinstance(out, Panel)

    def test_json_dict(self) -> None:
        out = DisplayRouter(OutputChannel.JSON).render({"x": 1})
        assert json.loads(out) == {"x": 1}

    def test_repl_none(self) -> None:
        out = DisplayRouter(OutputChannel.REPL).render(None)
        assert out == "OK"

    def test_web_dict(self) -> None:
        out = DisplayRouter(OutputChannel.WEB).render({"k": "v"}, title="t")
        assert "markdown" in out and out["data"] == {"k": "v"}


# ---------------------------------------------------------------------------
# Error rendering
# ---------------------------------------------------------------------------


class TestErrorRendering:
    def test_cli_error(self) -> None:
        out = DisplayRouter(OutputChannel.CLI).render_error(
            ValueError("bad"), context="detect",
        )
        assert isinstance(out, Panel)

    def test_json_error(self) -> None:
        out = DisplayRouter(OutputChannel.JSON).render_error(
            RuntimeError("boom"),
        )
        data = json.loads(out)
        assert data["error"]["type"] == "RuntimeError"
        assert data["error"]["message"] == "boom"

    def test_repl_error(self) -> None:
        out = DisplayRouter(OutputChannel.REPL).render_error(
            "plain msg", context="load",
        )
        assert "Error" in out and "plain msg" in out and "load" in out

    def test_web_error(self) -> None:
        out = DisplayRouter(OutputChannel.WEB).render_error(
            ValueError("bad"), context="detect",
        )
        assert out["error"] is True
        assert out["type"] == "ValueError"


# ---------------------------------------------------------------------------
# Unsupported payload
# ---------------------------------------------------------------------------


class TestUnsupportedPayload:
    def test_raises_on_arbitrary_object(self) -> None:
        class Weird:
            pass

        for ch in OutputChannel:
            with pytest.raises(UnsupportedPayloadError):
                DisplayRouter(ch).render(Weird())

    def test_json_handles_unserialisable_via_default(self) -> None:
        """dict 含 non-JSON 物件 → default=str 避免 raise，回合法 JSON。"""
        class X:
            def __str__(self) -> str:
                return "X-instance"

        out = DisplayRouter(OutputChannel.JSON).render({"x": X()})
        data = json.loads(out)
        assert data == {"x": "X-instance"}


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


class TestModuleHelpers:
    def test_render_helper(self, sample_tier_result: TierResult) -> None:
        out = render(sample_tier_result, "json")
        data = json.loads(out)
        assert data["software"] == "notepad"

    def test_render_error_helper(self) -> None:
        out = render_error(ValueError("oops"), OutputChannel.JSON)
        data = json.loads(out)
        assert data["error"]["type"] == "ValueError"
