"""Tests for api_anything.apis package — lazy imports + CLI list subcommand."""

from __future__ import annotations

import os
import subprocess
import sys

import pytest


def _utf8_env() -> dict[str, str]:
    """Subprocess env forcing UTF-8 stdio (Windows GBK fallback kills Rich output)."""
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"
    return env


class TestApisImports:
    """Test that built-in APIs are importable via api_anything.apis."""

    def test_import_ffmpeg(self):
        from api_anything.apis import FFmpeg

        assert FFmpeg is not None
        assert callable(FFmpeg)

    def test_import_git(self):
        from api_anything.apis import Git

        assert Git is not None

    def test_import_docker(self):
        from api_anything.apis import Docker

        assert Docker is not None

    def test_import_sqlite(self):
        """SQLite uses stdlib sqlite3, should always be available."""
        from api_anything.apis import SQLite

        assert SQLite is not None
        # Verify it actually works (stdlib, no binary needed)
        db = SQLite(":memory:")
        db.create_table("t", {"id": "INTEGER"})
        tables = db.get_tables()
        assert "t" in tables
        db.close()

    def test_import_imagemagick(self):
        from api_anything.apis import ImageMagick

        assert ImageMagick is not None

    def test_import_pandoc(self):
        from api_anything.apis import Pandoc

        assert Pandoc is not None

    def test_import_libreoffice(self):
        from api_anything.apis import LibreOfficeWriter

        assert LibreOfficeWriter is not None

    @pytest.mark.skipif(sys.platform != "win32", reason="Windows only")
    def test_import_notepad(self):
        from api_anything.apis import Notepad

        assert Notepad is not None

    def test_all_contains_available(self):
        """__all__ should list importable API names."""
        from api_anything.apis import __all__ as available

        assert isinstance(available, list)
        # SQLite always available (stdlib)
        assert "SQLite" in available
        # On Windows, Notepad should be available
        if sys.platform == "win32":
            assert "Notepad" in available

    def test_unavailable_api_no_crash(self):
        """Importing the package should not crash even if some APIs are unavailable."""
        import api_anything.apis

        # The module should load without error
        assert hasattr(api_anything.apis, "__all__")
        assert hasattr(api_anything.apis, "_REGISTRY")

    def test_getattr_unknown_raises(self):
        """Accessing a non-existent API should raise AttributeError."""
        import api_anything.apis

        with pytest.raises(AttributeError, match="NoSuchAPI"):
            _ = api_anything.apis.NoSuchAPI  # type: ignore[attr-defined]

    def test_registry_has_all_27(self):
        """The registry should contain 27 APIs (8 initial + 19 v0.1 expansion)."""
        from api_anything.apis import _REGISTRY

        assert len(_REGISTRY) == 27
        core = {
            "FFmpeg", "Git", "Docker", "SQLite",
            "ImageMagick", "Pandoc", "LibreOfficeWriter", "Notepad",
        }
        expansion = {
            "Blender", "GIMP", "Inkscape", "Audacity", "OBS", "Kdenlive",
            "Krita", "FreeCAD", "QGIS", "Ollama", "ComfyUI", "Godot",
            "MuseScore", "Curl", "Wget", "Tar", "SevenZip", "Jq", "Rsync",
        }
        assert set(_REGISTRY.keys()) == core | expansion


class TestListSubcommand:
    """Test the `api-anything list` CLI subcommand."""

    def test_list_basic(self):
        result = subprocess.run(
            [sys.executable, "-m", "api_anything.cli", "list"],
            capture_output=True, text=True, timeout=30,
            encoding="utf-8", env=_utf8_env(),
        )
        assert result.returncode == 0
        assert "SQLite" in result.stdout

    def test_list_detail(self):
        result = subprocess.run(
            [sys.executable, "-m", "api_anything.cli", "list", "--detail"],
            capture_output=True, text=True, timeout=30,
            encoding="utf-8", env=_utf8_env(),
        )
        assert result.returncode == 0
        assert "SQLite" in result.stdout
        assert "Total:" in result.stdout
