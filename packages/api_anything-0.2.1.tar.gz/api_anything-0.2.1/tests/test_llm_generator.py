"""Tests for api_anything.llm_generator — RFC v0.2 D 項 LLM-driven generation.

鐵律：**全部 mock LLM**，絕不實呼 anthropic API。
"""

from __future__ import annotations

import ast
from unittest.mock import MagicMock

import pytest

from api_anything.generator import (
    _LLM_DRIVEN_TIERS,
    _resolve_llm_driven,
    generate_api,
)
from api_anything.llm_generator import (
    LLMGenerateOutcome,
    _build_llm_prompt,
    _check_safety,
    _check_structure,
    _check_syntax,
    _extract_code_from_response,
    _validate_generated_code,
    llm_driven_generate,
)
from api_anything.models import UIControl


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_controls() -> list[UIControl]:
    """同 test_generator 的 control 集合，方便比對。"""
    return [
        UIControl(name="Open", control_type="Button"),
        UIControl(name="File Name", control_type="TextBox"),
        UIControl(name="File", control_type="Menu"),
    ]


def _valid_llm_output() -> str:
    """LLM 應該吐的合法 Python class（通過三關）。"""
    return '''"""Auto-generated API for testapp. Tier 3A."""

from __future__ import annotations

import logging
import subprocess

logger = logging.getLogger(__name__)


class TestappAPI:
    """Python API wrapper for testapp."""

    def __init__(self) -> None:
        """Initialize TestappAPI."""
        self._software = "testapp"

    def launch(self) -> None:
        """Launch testapp."""
        subprocess.run([self._software], check=True)

    def close(self) -> None:
        """Close testapp."""
        raise NotImplementedError("close pending")
'''


def _make_mock_client(response_text: str) -> MagicMock:
    """Build a MagicMock anthropic-compatible client.

    結構：client.messages.create(...) 回傳有 `.content[0].text = response_text`
    的物件。這精確對應 anthropic SDK 真實 shape。
    """
    client = MagicMock()
    text_block = MagicMock()
    text_block.text = response_text
    response = MagicMock()
    response.content = [text_block]
    client.messages.create.return_value = response
    return client


# ---------------------------------------------------------------------------
# Gate 1: syntax
# ---------------------------------------------------------------------------


class TestCheckSyntax:
    def test_valid_python_passes(self) -> None:
        ok, err = _check_syntax("x = 1\n")
        assert ok is True
        assert err is None

    def test_syntax_error_caught(self) -> None:
        ok, err = _check_syntax("def foo(:\n")
        assert ok is False
        assert err is not None
        assert "SyntaxError" in err


# ---------------------------------------------------------------------------
# Gate 2: structure
# ---------------------------------------------------------------------------


class TestCheckStructure:
    def test_valid_class_passes(self) -> None:
        code = _valid_llm_output()
        ok, failures = _check_structure(code)
        assert ok is True
        assert failures == []

    def test_no_class_fails(self) -> None:
        code = "def top_level_func():\n    return 1\n"
        ok, failures = _check_structure(code)
        assert ok is False
        assert any("no class" in f for f in failures)

    def test_class_without_init_fails(self) -> None:
        code = "class Foo:\n    def bar(self) -> None:\n        pass\n"
        ok, failures = _check_structure(code)
        assert ok is False

    def test_class_with_only_init_fails(self) -> None:
        # RFC 要求 ≥1 額外 method，光有 __init__ 不夠
        code = (
            "class Foo:\n"
            "    def __init__(self) -> None:\n"
            "        pass\n"
        )
        ok, failures = _check_structure(code)
        assert ok is False


# ---------------------------------------------------------------------------
# Gate 3: safety (blacklist)
# ---------------------------------------------------------------------------


class TestCheckSafety:
    def test_clean_code_passes(self) -> None:
        ok, failures = _check_safety(_valid_llm_output())
        assert ok is True
        assert failures == []

    def test_os_system_blocked(self) -> None:
        ok, failures = _check_safety('import os\nos.system("rm -rf /")\n')
        assert ok is False
        assert any("os.system" in f for f in failures)

    def test_eval_blocked(self) -> None:
        ok, failures = _check_safety("x = eval('1+1')\n")
        assert ok is False
        assert any("eval" in f for f in failures)

    def test_exec_blocked(self) -> None:
        ok, failures = _check_safety("exec('print(1)')\n")
        assert ok is False
        assert any("exec" in f for f in failures)

    def test_subprocess_shell_true_blocked(self) -> None:
        code = 'subprocess.Popen("ls", shell=True)\n'
        ok, failures = _check_safety(code)
        assert ok is False
        assert any("shell=True" in f for f in failures)

    def test_subprocess_run_shell_true_blocked(self) -> None:
        code = 'subprocess.run(["ls"], shell=True)\n'
        ok, failures = _check_safety(code)
        assert ok is False

    def test_subprocess_without_shell_ok(self) -> None:
        code = 'subprocess.run(["ls"], check=True)\n'
        ok, _failures = _check_safety(code)
        assert ok is True

    def test_dunder_import_blocked(self) -> None:
        code = 'm = __import__("os")\n'
        ok, failures = _check_safety(code)
        assert ok is False
        assert any("__import__" in f for f in failures)


# ---------------------------------------------------------------------------
# _validate_generated_code: 三關整合
# ---------------------------------------------------------------------------


class TestValidateGeneratedCode:
    def test_valid_code_all_gates_pass(self) -> None:
        result = _validate_generated_code(_valid_llm_output())
        assert result.passed is True
        assert result.syntax_ok is True
        assert result.structure_ok is True
        assert result.safety_ok is True
        assert result.failures == []

    def test_syntax_error_rejected(self) -> None:
        result = _validate_generated_code("def foo(:\n")
        assert result.passed is False
        assert result.syntax_ok is False

    def test_dangerous_code_rejected_even_if_valid_syntax(self) -> None:
        code = (
            "class Foo:\n"
            "    def __init__(self) -> None:\n"
            "        pass\n"
            "    def run(self) -> None:\n"
            '        import os\n'
            '        os.system("whoami")\n'
        )
        result = _validate_generated_code(code)
        assert result.passed is False
        assert result.syntax_ok is True  # syntax OK
        assert result.safety_ok is False  # safety fail

    def test_to_dict_shape(self) -> None:
        result = _validate_generated_code(_valid_llm_output())
        d = result.to_dict()
        assert d["passed"] is True
        assert d["syntax_ok"] is True
        assert d["structure_ok"] is True
        assert d["safety_ok"] is True
        assert d["failures"] == []


# ---------------------------------------------------------------------------
# _extract_code_from_response: markdown fence handling
# ---------------------------------------------------------------------------


class TestExtractCode:
    def test_plain_code_passthrough(self) -> None:
        code = "class Foo:\n    pass\n"
        assert _extract_code_from_response(code) == code.strip()

    def test_python_fence_stripped(self) -> None:
        raw = "```python\nclass Foo:\n    pass\n```"
        assert _extract_code_from_response(raw) == "class Foo:\n    pass"

    def test_bare_fence_stripped(self) -> None:
        raw = "```\nclass Foo:\n    pass\n```"
        assert _extract_code_from_response(raw) == "class Foo:\n    pass"


# ---------------------------------------------------------------------------
# llm_driven_generate: integration with mocked client
# ---------------------------------------------------------------------------


class TestLLMDrivenGenerate:
    def test_valid_llm_output_accepted(self) -> None:
        client = _make_mock_client(_valid_llm_output())
        outcome = llm_driven_generate(
            software_name="testapp",
            controls=_make_controls(),
            client=client,
            tier="3A",
        )
        assert isinstance(outcome, LLMGenerateOutcome)
        assert outcome.validation.passed is True
        # source_code 可被 ast.parse
        ast.parse(outcome.source_code)
        # client 確實被呼到
        client.messages.create.assert_called_once()

    def test_invalid_syntax_rejected(self) -> None:
        client = _make_mock_client("def foo(:\n")
        outcome = llm_driven_generate(
            software_name="testapp",
            controls=_make_controls(),
            client=client,
            tier="3A",
        )
        assert outcome.validation.passed is False
        assert outcome.validation.syntax_ok is False

    def test_blacklist_output_rejected(self) -> None:
        bad_code = (
            "class Foo:\n"
            "    def __init__(self) -> None:\n"
            "        pass\n"
            "    def run(self) -> None:\n"
            '        import os\n'
            '        os.system("whoami")\n'
        )
        client = _make_mock_client(bad_code)
        outcome = llm_driven_generate(
            software_name="testapp",
            controls=_make_controls(),
            client=client,
            tier="3A",
        )
        assert outcome.validation.passed is False
        assert outcome.validation.safety_ok is False

    def test_llm_api_error_captured(self) -> None:
        # Client raises — llm_driven_generate 應吞掉並回 passed=False
        client = MagicMock()
        client.messages.create.side_effect = RuntimeError("429 rate limited")
        outcome = llm_driven_generate(
            software_name="testapp",
            controls=_make_controls(),
            client=client,
            tier="3A",
        )
        assert outcome.validation.passed is False
        assert any("llm_call_error" in f for f in outcome.validation.failures)

    def test_markdown_fence_stripped_and_validated(self) -> None:
        # LLM 違規包 fence 的情況，extract 後仍能驗證通過
        wrapped = f"```python\n{_valid_llm_output()}\n```"
        client = _make_mock_client(wrapped)
        outcome = llm_driven_generate(
            software_name="testapp",
            controls=_make_controls(),
            client=client,
            tier="3A",
        )
        assert outcome.validation.passed is True

    def test_fallback_hint_injected_when_enabled(self) -> None:
        # fallback_enabled=True 時 prompt 含 Fallback Note
        prompt = _build_llm_prompt(
            software_name="krita",
            controls=[],
            screenshot_path=None,
            source_text=None,
            tier="3B",
            fallback_enabled=True,
        )
        assert "Fallback Note" in prompt

    def test_fallback_hint_absent_when_disabled(self) -> None:
        prompt = _build_llm_prompt(
            software_name="foo",
            controls=[],
            screenshot_path=None,
            source_text=None,
            tier="2A",
            fallback_enabled=False,
        )
        assert "Fallback Note" not in prompt


# ---------------------------------------------------------------------------
# _resolve_llm_driven: 觸發決策矩陣
# ---------------------------------------------------------------------------


class TestResolveLLMDriven:
    def test_no_client_never_llm_driven(self) -> None:
        # 無 llm_client 永遠走 False，無論其他條件
        assert _resolve_llm_driven("3A", None, True, client=None) is False
        assert _resolve_llm_driven("4", 20, True, client=None) is False

    def test_explicit_true_wins_over_tier(self) -> None:
        client = MagicMock()
        # Tier 1 通常 False，但 explicit=True 覆寫
        assert _resolve_llm_driven("1", 100, True, client=client) is True

    def test_explicit_false_wins_over_tier(self) -> None:
        client = MagicMock()
        # Tier 3B 通常 True，但 explicit=False 覆寫
        assert _resolve_llm_driven("3B", None, False, client=client) is False

    @pytest.mark.parametrize("tier", sorted(_LLM_DRIVEN_TIERS))
    def test_high_tiers_auto_enable(self, tier: str) -> None:
        client = MagicMock()
        assert _resolve_llm_driven(tier, None, None, client=client) is True

    def test_low_confidence_enables(self) -> None:
        client = MagicMock()
        # tier 2A 但 confidence<60
        assert _resolve_llm_driven("2A", 50, None, client=client) is True

    def test_high_confidence_skips(self) -> None:
        client = MagicMock()
        assert _resolve_llm_driven("2A", 95, None, client=client) is False

    def test_tier_1_high_confidence_skips(self) -> None:
        client = MagicMock()
        assert _resolve_llm_driven("1", None, None, client=client) is False


# ---------------------------------------------------------------------------
# generate_api: end-to-end LLM-driven path
# ---------------------------------------------------------------------------


class TestGenerateApiLLMDriven:
    def test_llm_driven_success_sets_mode(self) -> None:
        client = _make_mock_client(_valid_llm_output())
        result = generate_api(
            software_name="testapp",
            controls=_make_controls(),
            tier="3A",
            llm_client=client,
        )
        assert result.generation_mode == "llm_driven"
        assert result.validation is not None
        assert result.validation["passed"] is True
        # source_code 必可 parse
        ast.parse(result.source_code)

    def test_llm_driven_validation_fail_falls_back(self) -> None:
        # LLM 吐垃圾 → 驗證 fail → 回 schema/mock（本例無 schema client 故走 mock）
        client = _make_mock_client("def foo(:\n")
        result = generate_api(
            software_name="testapp",
            controls=_make_controls(),
            tier="3A",
            llm_client=client,
        )
        assert result.generation_mode == "llm_driven_fallback_to_schema"
        # fallback 後仍產出合法 Python
        ast.parse(result.source_code)
        # validation 留痕
        assert result.validation is not None
        assert result.validation["passed"] is False

    def test_no_llm_client_falls_through_to_mock(self) -> None:
        # 即使 tier 3A（_LLM_DRIVEN_TIERS 命中），無 llm_client 也不走 LLM path
        result = generate_api(
            software_name="testapp",
            controls=_make_controls(),
            tier="3A",
        )
        assert result.generation_mode == "mock"
        assert result.validation is None

    def test_explicit_llm_driven_false_forces_schema_path(self) -> None:
        # 即使 tier 3B 預設開 LLM，explicit=False 強制關閉
        llm_client = _make_mock_client(_valid_llm_output())
        result = generate_api(
            software_name="testapp",
            controls=_make_controls(),
            tier="3B",
            llm_client=llm_client,
            llm_driven=False,
        )
        assert result.generation_mode == "mock"
        # llm_client 不該被呼
        llm_client.messages.create.assert_not_called()

    def test_blacklist_violation_falls_back(self) -> None:
        # LLM 吐 os.system → safety fail → fallback
        bad_code = (
            '"""Evil."""\n'
            "from __future__ import annotations\n"
            "import os\n"
            "class Foo:\n"
            "    def __init__(self) -> None:\n"
            '        os.system("whoami")\n'
            "    def run(self) -> None:\n"
            "        pass\n"
        )
        client = _make_mock_client(bad_code)
        result = generate_api(
            software_name="bar",
            controls=[],
            tier="3A",
            llm_client=client,
        )
        assert result.generation_mode == "llm_driven_fallback_to_schema"
        # 回 mock path 產的 source_code 不含 os.system
        assert "os.system" not in result.source_code
        assert result.validation is not None
        assert result.validation["safety_ok"] is False
