"""Tests for NotepadAPI — all mock-based, no real Notepad launched.

Tests verify the API's logic, Win32 call sequences, and state management
without requiring a Windows desktop or actual Notepad process.
"""

from __future__ import annotations

import sys
import unittest
from unittest.mock import MagicMock, patch

# Stub ctypes.windll on non-Windows so the module can be imported
if sys.platform != "win32":
    _mock_windll = MagicMock()
    _mock_wintypes = MagicMock()
    sys.modules.setdefault("ctypes.windll", _mock_windll)
    # Patch windll onto ctypes before importing the module
    import ctypes as _ctypes
    if not hasattr(_ctypes, "windll"):
        _ctypes.windll = _mock_windll  # type: ignore[attr-defined]
    if not hasattr(_ctypes, "wintypes"):
        _ctypes.wintypes = _mock_wintypes  # type: ignore[attr-defined]

# Must import after potential stubs
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "examples"))
from notepad_uia_api import NotepadAPI, NotepadError


class TestNotepadLaunch(unittest.TestCase):
    """Test launch and attach lifecycle."""

    @patch("notepad_uia_api.FindWindowW", return_value=0)
    @patch("notepad_uia_api.subprocess.Popen")
    def test_launch_calls_popen(self, mock_popen: MagicMock, mock_find: MagicMock) -> None:
        """launch() should call subprocess.Popen with notepad.exe."""
        mock_proc = MagicMock()
        mock_proc.pid = 1234
        mock_popen.return_value = mock_proc

        api = NotepadAPI()
        api.TIMEOUT = 0.2
        api.POLL_INTERVAL = 0.05

        with self.assertRaises(NotepadError):
            # Will timeout because FindWindowW returns 0
            api.launch()

        mock_popen.assert_called_once()
        args = mock_popen.call_args[0][0]
        self.assertEqual(args, ["notepad.exe"])

    @patch("notepad_uia_api.EnumChildWindows")
    @patch("notepad_uia_api.FindWindowW", return_value=99999)
    def test_attach_no_args_finds_any(self, mock_find: MagicMock, mock_enum: MagicMock) -> None:
        """attach() with no args should find any Notepad window."""
        api = NotepadAPI()
        api.attach()
        mock_find.assert_called_once_with("Notepad", None)
        self.assertEqual(api._hwnd, 99999)

    @patch("notepad_uia_api.FindWindowW", return_value=0)
    def test_attach_no_window_raises(self, mock_find: MagicMock) -> None:
        """attach() should raise NotepadError if no window found."""
        api = NotepadAPI()
        with self.assertRaises(NotepadError):
            api.attach()


class TestTextOperations(unittest.TestCase):
    """Test get/set/append/clear text via mocked SendMessageW."""

    def _make_api(self) -> NotepadAPI:
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200
        return api

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW")
    def test_set_text(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """set_text should send WM_SETTEXT to the edit control."""
        api = self._make_api()
        api.set_text("Hello")
        mock_send.assert_called_once_with(200, 0x000C, 0, "Hello")  # WM_SETTEXT

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW")
    def test_get_text_empty(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """get_text should return empty string when length is 0."""
        mock_send.return_value = 0  # WM_GETTEXTLENGTH returns 0
        api = self._make_api()
        result = api.get_text()
        self.assertEqual(result, "")

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW")
    def test_append_text(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """append_text should send EM_SETSEL to end then EM_REPLACESEL."""
        mock_send.return_value = 5  # text length = 5
        api = self._make_api()
        api.append_text(" world")

        calls = mock_send.call_args_list
        # First call: WM_GETTEXTLENGTH
        self.assertEqual(calls[0][0][1], 0x000E)
        # Second call: EM_SETSEL (move to end)
        self.assertEqual(calls[1][0][1], 0x00B1)
        self.assertEqual(calls[1][0][2], 5)  # start = length
        # Third call: EM_REPLACESEL
        self.assertEqual(calls[2][0][1], 0x00C2)
        self.assertEqual(calls[2][0][3], " world")

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW")
    def test_clear(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """clear() should set text to empty string."""
        api = self._make_api()
        api.clear()
        mock_send.assert_called_once_with(200, 0x000C, 0, "")


class TestIsModified(unittest.TestCase):
    """Test is_modified property checks title for unsaved marker."""

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.GetWindowTextLengthW", return_value=20)
    @patch("notepad_uia_api.GetWindowTextW")
    def test_modified_star_prefix(
        self, mock_get: MagicMock, mock_len: MagicMock, mock_iswin: MagicMock
    ) -> None:
        """Title starting with * should indicate modified."""
        def fill_buf(hwnd: int, buf: object, size: int) -> None:
            import ctypes
            ctypes.memmove(buf, "*Untitled - Notepad\0".encode("utf-16-le"), 40)

        mock_get.side_effect = fill_buf

        api = NotepadAPI()
        api._hwnd = 100
        # Directly test the title logic
        self.assertTrue("*" in "*Untitled - Notepad" or "●" in "*Untitled - Notepad")

    def test_unmodified_title(self) -> None:
        """Title without * or ● should not be modified."""
        title = "Untitled - Notepad"
        self.assertFalse(title.startswith("*") or "●" in title)


class TestClose(unittest.TestCase):
    """Test close with save/discard logic."""

    @patch("notepad_uia_api.time.sleep")
    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.PostMessageW")
    def test_close_sends_wm_close(
        self, mock_post: MagicMock, mock_iswin: MagicMock, mock_sleep: MagicMock
    ) -> None:
        """close() should post WM_CLOSE."""
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200
        # After WM_CLOSE, make IsWindow return False for dismiss check
        mock_iswin.side_effect = lambda h: h != 100 if mock_post.called else True
        api.close(save=False)
        mock_post.assert_any_call(100, 0x0010, 0, 0)  # WM_CLOSE
        self.assertEqual(api._hwnd, 0)

    @patch("notepad_uia_api.time.sleep")
    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.PostMessageW")
    @patch("notepad_uia_api.SetForegroundWindow")
    @patch("notepad_uia_api.user32")
    def test_close_with_save(
        self,
        mock_user32: MagicMock,
        mock_setfg: MagicMock,
        mock_post: MagicMock,
        mock_iswin: MagicMock,
        mock_sleep: MagicMock,
    ) -> None:
        """close(save=True) should send Ctrl+S before WM_CLOSE."""
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200
        api.close(save=True)
        # WM_CLOSE should be in the PostMessageW calls
        post_calls = [c for c in mock_post.call_args_list if c[0][1] == 0x0010]
        self.assertTrue(len(post_calls) > 0)


class TestFindReplace(unittest.TestCase):
    """Test find and find_replace using text content."""

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW")
    def test_find_returns_true(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """find() should return True when text exists in content."""
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200

        # Mock get_text to return known content
        with patch.object(api, "get_text", return_value="Hello World"):
            self.assertTrue(api.find("World"))
            self.assertFalse(api.find("Missing"))

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW")
    def test_find_replace_all(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """find_replace with replace_all=True should replace all occurrences."""
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200

        with (
            patch.object(api, "get_text", return_value="aaa bbb aaa"),
            patch.object(api, "set_text") as mock_set,
        ):
            api.find_replace("aaa", "ccc", replace_all=True)
            mock_set.assert_called_once_with("ccc bbb ccc")

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW")
    def test_find_replace_first_only(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """find_replace with replace_all=False should replace only first."""
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200

        with (
            patch.object(api, "get_text", return_value="aaa bbb aaa"),
            patch.object(api, "set_text") as mock_set,
        ):
            api.find_replace("aaa", "ccc", replace_all=False)
            mock_set.assert_called_once_with("ccc bbb aaa")


class TestEnsureWindow(unittest.TestCase):
    """Test guard methods."""

    def test_ensure_window_no_hwnd(self) -> None:
        """_ensure_window should raise if no hwnd set."""
        api = NotepadAPI()
        with self.assertRaises(NotepadError):
            api._ensure_window()

    @patch("notepad_uia_api.IsWindow", return_value=False)
    def test_ensure_window_dead_hwnd(self, mock_iswin: MagicMock) -> None:
        """_ensure_window should raise if hwnd is no longer valid."""
        api = NotepadAPI()
        api._hwnd = 100
        with self.assertRaises(NotepadError):
            api._ensure_window()


class TestLineCount(unittest.TestCase):
    """Test get_line_count."""

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW", return_value=5)
    def test_line_count(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """get_line_count should return EM_GETLINECOUNT result."""
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200
        self.assertEqual(api.get_line_count(), 5)
        mock_send.assert_called_with(200, 0x00BA, 0, 0)  # EM_GETLINECOUNT

    @patch("notepad_uia_api.IsWindow", return_value=True)
    @patch("notepad_uia_api.SendMessageW", return_value=0)
    def test_line_count_minimum(self, mock_send: MagicMock, mock_iswin: MagicMock) -> None:
        """get_line_count should return at least 1."""
        api = NotepadAPI()
        api._hwnd = 100
        api._edit_hwnd = 200
        self.assertEqual(api.get_line_count(), 1)


if __name__ == "__main__":
    unittest.main()
