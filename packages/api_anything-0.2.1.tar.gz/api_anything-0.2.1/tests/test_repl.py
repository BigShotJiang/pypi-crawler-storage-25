"""Tests for api_anything.repl — all mock-based, no interactive REPL."""

from __future__ import annotations

import textwrap
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from api_anything.repl import (
    HistoryEntry,
    LoadedAPI,
    ReplState,
    build_loaded_api,
    discover_classes,
    execute_method,
    export_session,
    format_result,
    get_public_methods,
    handle_dot_command,
    load_module_from_path,
    parse_method_call,
    run_repl,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

class _FakeAPI:
    """Fake API class for testing."""

    def greet(self, name: str) -> str:
        """Say hello."""
        return f"Hello, {name}!"

    def add(self, a: int, b: int) -> int:
        """Add two numbers."""
        return a + b

    def noop(self) -> None:
        """Do nothing."""

    def _private(self) -> str:
        return "hidden"


@pytest.fixture()
def fake_module():
    """Create a mock module containing _FakeAPI."""
    mod = MagicMock()
    mod.__name__ = "fake_module"
    mod._FakeAPI = _FakeAPI  # private — should be skipped
    mod.FakeAPI = _FakeAPI
    mod.FakeAPI.__module__ = "fake_module"
    # Make inspect.getmembers work
    mod.__dict__ = {"FakeAPI": _FakeAPI, "_FakeAPI": _FakeAPI}
    return mod


@pytest.fixture()
def loaded_api() -> LoadedAPI:
    """A pre-built LoadedAPI for testing."""
    methods = get_public_methods(_FakeAPI)
    return LoadedAPI(
        name="FakeAPI",
        instance=_FakeAPI(),
        cls=_FakeAPI,
        methods=methods,
        module_path="fake.py",
    )


@pytest.fixture()
def state(loaded_api: LoadedAPI) -> ReplState:
    """A ReplState with one loaded API."""
    return ReplState(apis=[loaded_api])


@pytest.fixture()
def console() -> MagicMock:
    return MagicMock()


# ---------------------------------------------------------------------------
# Module loading
# ---------------------------------------------------------------------------

class TestModuleLoading:
    """Tests for load_module_from_path and discover_classes."""

    def test_file_not_found(self) -> None:
        with pytest.raises(FileNotFoundError):
            load_module_from_path("/nonexistent/path/module.py")

    def test_not_python_file(self, tmp_path: Path) -> None:
        txt = tmp_path / "data.txt"
        txt.write_text("hello")
        with pytest.raises(ImportError, match="Not a Python file"):
            load_module_from_path(str(txt))

    def test_load_valid_module(self, tmp_path: Path) -> None:
        py = tmp_path / "sample_api.py"
        py.write_text(textwrap.dedent("""\
            class SampleAPI:
                def ping(self) -> str:
                    return "pong"
        """))
        mod = load_module_from_path(str(py))
        assert hasattr(mod, "SampleAPI")

    def test_discover_skips_private(self, tmp_path: Path) -> None:
        py = tmp_path / "mixed.py"
        py.write_text(textwrap.dedent("""\
            class PublicAPI:
                pass
            class _PrivateHelper:
                pass
        """))
        mod = load_module_from_path(str(py))
        classes = discover_classes(mod)
        names = [c.__name__ for c in classes]
        assert "PublicAPI" in names
        assert "_PrivateHelper" not in names

    def test_build_loaded_api(self, tmp_path: Path) -> None:
        py = tmp_path / "builder_test.py"
        py.write_text(textwrap.dedent("""\
            class MyAPI:
                def do_stuff(self, x: int) -> int:
                    return x * 2
        """))
        mod = load_module_from_path(str(py))
        api = build_loaded_api(mod, str(py))
        assert api.name == "MyAPI"
        assert "do_stuff" in api.methods


# ---------------------------------------------------------------------------
# Introspection
# ---------------------------------------------------------------------------

class TestIntrospection:
    """Tests for get_public_methods."""

    def test_finds_public_methods(self) -> None:
        methods = get_public_methods(_FakeAPI)
        assert "greet" in methods
        assert "add" in methods
        assert "noop" in methods

    def test_skips_private_methods(self) -> None:
        methods = get_public_methods(_FakeAPI)
        assert "_private" not in methods

    def test_signature_strips_self(self) -> None:
        methods = get_public_methods(_FakeAPI)
        params = list(methods["greet"].parameters.keys())
        assert "self" not in params
        assert "name" in params


# ---------------------------------------------------------------------------
# Command parsing
# ---------------------------------------------------------------------------

class TestParsing:
    """Tests for parse_method_call."""

    def test_simple_call(self) -> None:
        result = parse_method_call('greet("world")')
        assert result is not None
        assert result[0] == "greet"

    def test_no_parens(self) -> None:
        assert parse_method_call("just_a_word") is None

    def test_dot_command_not_parsed(self) -> None:
        # Dot commands are not method calls
        assert parse_method_call(".help") is None

    def test_empty_args(self) -> None:
        result = parse_method_call("noop()")
        assert result is not None
        assert result[0] == "noop"

    def test_unclosed_paren(self) -> None:
        assert parse_method_call("greet(") is None


# ---------------------------------------------------------------------------
# Method execution
# ---------------------------------------------------------------------------

class TestExecution:
    """Tests for execute_method."""

    def test_call_with_args(self, loaded_api: LoadedAPI) -> None:
        result = execute_method(loaded_api, "greet", '"world"')
        assert result == "Hello, world!"

    def test_call_numeric(self, loaded_api: LoadedAPI) -> None:
        result = execute_method(loaded_api, "add", "3, 4")
        assert result == 7

    def test_call_no_args(self, loaded_api: LoadedAPI) -> None:
        result = execute_method(loaded_api, "noop", "")
        assert result is None

    def test_missing_method(self, loaded_api: LoadedAPI) -> None:
        with pytest.raises(AttributeError, match="No method 'bogus'"):
            execute_method(loaded_api, "bogus", "")


# ---------------------------------------------------------------------------
# JSON output
# ---------------------------------------------------------------------------

class TestJsonOutput:
    """Tests for format_result in JSON mode (v0.2.1 B: router-backed).

    v0.2.1 B note: ``format_result`` now delegates to :class:`DisplayRouter`
    REPL/JSON channel. REPL channel returns plain str, so ``console.print``
    receives a string instead of the original int/dict (rich still renders
    it as plain text).
    """

    def test_json_dict(self, console: MagicMock) -> None:
        format_result({"key": "value"}, json_mode=True, console=console)
        console.print.assert_called_once()
        # The Syntax object was printed
        call_args = console.print.call_args[0][0]
        assert hasattr(call_args, "code")  # Rich Syntax object

    def test_json_none(self, console: MagicMock) -> None:
        format_result(None, json_mode=True, console=console)
        console.print.assert_called_once()
        call_args = console.print.call_args[0][0]
        assert hasattr(call_args, "code")  # Syntax wrapping "null"

    def test_plain_mode(self, console: MagicMock) -> None:
        # v0.2.1 B: REPL channel maps int -> str("42")
        format_result(42, json_mode=False, console=console)
        console.print.assert_called_once_with("42")

    def test_plain_mode_none(self, console: MagicMock) -> None:
        """REPL channel: None -> "OK"."""
        format_result(None, json_mode=False, console=console)
        console.print.assert_called_once_with("OK")

    def test_plain_mode_dict(self, console: MagicMock) -> None:
        """REPL channel: dict -> JSON-compact str (no border box)."""
        format_result({"a": 1, "b": "x"}, json_mode=False, console=console)
        console.print.assert_called_once()
        out = console.print.call_args[0][0]
        assert isinstance(out, str)
        assert '"a"' in out and '"b"' in out

    def test_plain_mode_list(self, console: MagicMock) -> None:
        """REPL channel: list -> JSON-compact str."""
        format_result([1, 2, 3], json_mode=False, console=console)
        console.print.assert_called_once()
        out = console.print.call_args[0][0]
        assert isinstance(out, str)
        assert "1" in out and "2" in out and "3" in out

    def test_plain_mode_string(self, console: MagicMock) -> None:
        """REPL channel: str -> passthrough."""
        format_result("hello world", json_mode=False, console=console)
        console.print.assert_called_once_with("hello world")

    def test_plain_mode_fallback_unsupported(self, console: MagicMock) -> None:
        """Unsupported payload (custom class) -> fall back to console.print.

        Router raises UnsupportedPayloadError for non-whitelisted types
        (set, custom class, etc.). Fallback preserves rich's native
        formatting instead of lossy str coercion.
        """
        class _Custom:
            def __repr__(self) -> str:
                return "<Custom>"

        obj = _Custom()
        format_result(obj, json_mode=False, console=console)
        console.print.assert_called_once_with(obj)

    def test_json_mode_list(self, console: MagicMock) -> None:
        """JSON channel: list -> Syntax-wrapped JSON."""
        format_result([1, {"k": "v"}], json_mode=True, console=console)
        console.print.assert_called_once()
        call_args = console.print.call_args[0][0]
        assert hasattr(call_args, "code")


# ---------------------------------------------------------------------------
# Session history
# ---------------------------------------------------------------------------

class TestSessionHistory:
    """Tests for history, undo, redo."""

    def test_history_append(self, state: ReplState) -> None:
        entry = HistoryEntry(command="greet('x')", result="Hello, x!", timestamp=time.time())
        state.history.append(entry)
        assert len(state.history) == 1

    def test_undo(self, state: ReplState, console: MagicMock) -> None:
        entry = HistoryEntry(command="greet('x')", result="Hello, x!", timestamp=time.time())
        state.history.append(entry)
        handle_dot_command(".undo", state, console)
        assert len(state.history) == 0
        assert len(state.undo_stack) == 1

    def test_redo(self, state: ReplState, console: MagicMock) -> None:
        entry = HistoryEntry(command="greet('x')", result="Hello, x!", timestamp=time.time())
        state.history.append(entry)
        handle_dot_command(".undo", state, console)
        handle_dot_command(".redo", state, console)
        assert len(state.history) == 1
        assert len(state.undo_stack) == 0

    def test_undo_empty(self, state: ReplState, console: MagicMock) -> None:
        handle_dot_command(".undo", state, console)
        # Should print warning, not crash
        console.print.assert_called()

    def test_redo_empty(self, state: ReplState, console: MagicMock) -> None:
        handle_dot_command(".redo", state, console)
        console.print.assert_called()


# ---------------------------------------------------------------------------
# Export
# ---------------------------------------------------------------------------

class TestExport:
    """Tests for .export generating valid Python."""

    def test_export_creates_file(
        self, state: ReplState, console: MagicMock, tmp_path: Path,
    ) -> None:
        state.history.append(
            HistoryEntry(command='greet("world")', result="Hello, world!", timestamp=time.time())
        )
        out = tmp_path / "session.py"
        export_session(state, str(out), console)
        assert out.exists()
        content = out.read_text(encoding="utf-8")
        assert "api.greet" in content
        assert "FakeAPI" in content

    def test_export_skips_dot_commands(
        self, state: ReplState, console: MagicMock, tmp_path: Path,
    ) -> None:
        state.history.append(HistoryEntry(command=".json", result=None, timestamp=time.time()))
        state.history.append(HistoryEntry(command='add(1, 2)', result=3, timestamp=time.time()))
        out = tmp_path / "session2.py"
        export_session(state, str(out), console)
        content = out.read_text(encoding="utf-8")
        assert ".json" not in content
        assert "api.add" in content


# ---------------------------------------------------------------------------
# Dot-command handling
# ---------------------------------------------------------------------------

class TestDotCommands:
    """Tests for handle_dot_command."""

    def test_json_toggle(self, state: ReplState, console: MagicMock) -> None:
        assert not state.json_mode
        handle_dot_command(".json", state, console)
        assert state.json_mode
        handle_dot_command(".json", state, console)
        assert not state.json_mode

    def test_quit(self, state: ReplState, console: MagicMock) -> None:
        assert state.running
        handle_dot_command(".quit", state, console)
        assert not state.running

    def test_help_no_crash(self, state: ReplState, console: MagicMock) -> None:
        handle_dot_command(".help", state, console)
        assert console.print.called

    def test_tier_no_crash(self, state: ReplState, console: MagicMock) -> None:
        handle_dot_command(".tier", state, console)
        assert console.print.called

    def test_unknown_command(self, state: ReplState, console: MagicMock) -> None:
        handle_dot_command(".bogus", state, console)
        # Should print error
        call_text = str(console.print.call_args)
        assert "Unknown" in call_text or "bogus" in call_text


# ---------------------------------------------------------------------------
# Fallback mode (no prompt_toolkit)
# ---------------------------------------------------------------------------

class TestFallbackMode:
    """Verify REPL works without prompt_toolkit."""

    def test_run_repl_quit_immediately(self, tmp_path: Path) -> None:
        py = tmp_path / "tiny.py"
        py.write_text(textwrap.dedent("""\
            class TinyAPI:
                def ping(self) -> str:
                    return "pong"
        """))
        # Simulate user typing .quit
        with patch("api_anything.repl._HAS_PROMPT_TOOLKIT", False), \
             patch("builtins.input", side_effect=[".quit"]):
            code = run_repl([str(py)])
        assert code == 0

    def test_run_repl_eof(self, tmp_path: Path) -> None:
        py = tmp_path / "tiny2.py"
        py.write_text("class X:\n    def f(self): return 1\n")
        with patch("api_anything.repl._HAS_PROMPT_TOOLKIT", False), \
             patch("builtins.input", side_effect=EOFError):
            code = run_repl([str(py)])
        assert code == 0

    def test_run_repl_no_modules(self) -> None:
        code = run_repl(["/nonexistent/fake.py"])
        assert code == 1
