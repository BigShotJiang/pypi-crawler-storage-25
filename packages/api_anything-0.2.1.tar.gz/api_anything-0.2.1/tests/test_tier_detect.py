"""Tests for the Phase 0 Tier Detection system."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import httpx
import pytest

from api_anything.tier_detect import (
    CheckResult,
    RuntimeProbeResult,
    Tier,
    TierResult,
    _determine_tier,
    _enrich_checks,
    _fallback_hint_for,
    _looks_like_electron,
    _refine_tier_from_probe,
    check_cli,
    check_pypi,
    check_source,
    check_uia,
    cli_alias_candidates,
    detect_install_path,
    detect_tier,
    print_report,
)

# ---------------------------------------------------------------------------
# TierResult model
# ---------------------------------------------------------------------------


class TestTierResult:
    """TierResult Pydantic model validation."""

    def test_basic_construction(self) -> None:
        r = TierResult(software="test", tier=Tier.T1, confidence=98, est_tokens_k=2)
        assert r.tier == Tier.T1
        assert r.stars == "★★★★★"
        assert r.confidence == 98

    def test_auto_fills_derived_fields(self) -> None:
        r = TierResult(software="x", tier=Tier.T3B, confidence=0, est_tokens_k=0)
        assert r.stars == "★★☆☆☆"
        assert r.verdict != ""
        assert r.est_tokens_k == 40  # from _EST_TOKENS
        assert r.confidence == 50  # from _CONFIDENCE

    def test_checks_dict(self) -> None:
        c = CheckResult(passed=True, detail="ok")
        r = TierResult(
            software="a",
            tier=Tier.T2A,
            confidence=90,
            est_tokens_k=8,
            checks={"cli": c},
        )
        assert r.checks["cli"].passed is True


# ---------------------------------------------------------------------------
# check_pypi
# ---------------------------------------------------------------------------


class TestCheckPypi:
    """PyPI binding check."""

    def test_known_package_exists(self) -> None:
        """python-docx should exist on PyPI."""
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"info": {"version": "1.1.2"}}

        with patch("api_anything.tier_detect.httpx.get", return_value=mock_resp):
            result = check_pypi("python-docx")
        assert result.passed is True
        assert "PyPI" in result.detail

    def test_nonexistent_package(self) -> None:
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 404

        with patch("api_anything.tier_detect.httpx.get", return_value=mock_resp):
            result = check_pypi("xyzzy-nonexistent-pkg-12345")
        assert result.passed is False

    def test_network_error(self) -> None:
        with patch(
            "api_anything.tier_detect.httpx.get",
            side_effect=httpx.ConnectError("no network"),
        ):
            result = check_pypi("anything")
        assert result.passed is False
        assert "failed" in result.detail.lower()


# ---------------------------------------------------------------------------
# check_cli
# ---------------------------------------------------------------------------


class TestCheckCli:
    """CLI availability check."""

    def test_known_command_found(self) -> None:
        """python should be findable on any dev machine."""
        with patch("api_anything.tier_detect.shutil.which", return_value="/usr/bin/python"):
            result = check_cli("python")
        assert result.passed is True

    def test_missing_command(self) -> None:
        with patch("api_anything.tier_detect.shutil.which", return_value=None):
            result = check_cli("xyzzy_nonexistent_cmd")
        assert result.passed is False
        assert "not found" in result.detail.lower()


# ---------------------------------------------------------------------------
# check_source
# ---------------------------------------------------------------------------


class TestCheckSource:
    """Source code availability check."""

    def test_local_path_exists(self, tmp_path: Path) -> None:
        (tmp_path / "main.py").write_text("print('hi')")
        result = check_source(path=str(tmp_path))
        assert result.passed is True

    def test_local_path_missing(self) -> None:
        result = check_source(path="/nonexistent/path/xyz")
        assert result.passed is False

    def test_no_source_provided(self) -> None:
        result = check_source()
        assert result.passed is False
        assert "no source" in result.detail.lower()

    def test_github_url_success(self) -> None:
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 200

        with patch("api_anything.tier_detect.httpx.head", return_value=mock_resp):
            result = check_source(url="https://github.com/org/repo")
        assert result.passed is True


# ---------------------------------------------------------------------------
# check_uia
# ---------------------------------------------------------------------------


class TestCheckUia:
    """UIA quality check."""

    def test_uia_not_installed(self) -> None:
        """Graceful skip when uiautomation is not importable."""
        with patch.dict("sys.modules", {"uiautomation": None}), patch(
            "builtins.__import__",
            side_effect=ImportError("no uiautomation"),
        ):
            result = check_uia("Notepad")
        # Should not crash — returns failed check
        assert result.passed is False
        assert result.value == 0.0


# ---------------------------------------------------------------------------
# _determine_tier
# ---------------------------------------------------------------------------


class TestDetermineTier:
    """Tier determination logic."""

    def test_pypi_wins(self) -> None:
        tier = _determine_tier(
            pypi=CheckResult(passed=True),
            source=CheckResult(passed=False),
            cli=CheckResult(passed=False),
            uia=CheckResult(passed=False, value=0.0),
        )
        assert tier == Tier.T1

    def test_source_and_cli(self) -> None:
        tier = _determine_tier(
            pypi=CheckResult(passed=False),
            source=CheckResult(passed=True),
            cli=CheckResult(passed=True),
            uia=CheckResult(passed=False, value=0.0),
        )
        assert tier == Tier.T2A

    def test_source_no_cli(self) -> None:
        tier = _determine_tier(
            pypi=CheckResult(passed=False),
            source=CheckResult(passed=True),
            cli=CheckResult(passed=False),
            uia=CheckResult(passed=False, value=0.0),
        )
        assert tier == Tier.T2B

    def test_uia_high(self) -> None:
        tier = _determine_tier(
            pypi=CheckResult(passed=False),
            source=CheckResult(passed=False),
            cli=CheckResult(passed=False),
            uia=CheckResult(passed=True, value=0.75),
        )
        assert tier == Tier.T3A

    def test_uia_medium(self) -> None:
        tier = _determine_tier(
            pypi=CheckResult(passed=False),
            source=CheckResult(passed=False),
            cli=CheckResult(passed=False),
            uia=CheckResult(passed=True, value=0.45),
        )
        assert tier == Tier.T3B

    def test_uia_low(self) -> None:
        tier = _determine_tier(
            pypi=CheckResult(passed=False),
            source=CheckResult(passed=False),
            cli=CheckResult(passed=False),
            uia=CheckResult(passed=True, value=0.15),
        )
        assert tier == Tier.T3C

    def test_nothing_found(self) -> None:
        tier = _determine_tier(
            pypi=CheckResult(passed=False),
            source=CheckResult(passed=False),
            cli=CheckResult(passed=False),
            uia=CheckResult(passed=False, value=0.0),
        )
        assert tier == Tier.T4


# ---------------------------------------------------------------------------
# print_report (smoke test)
# ---------------------------------------------------------------------------


class TestPrintReport:
    """Verify print_report doesn't crash."""

    def test_smoke(self, capsys: pytest.CaptureFixture[str]) -> None:
        from rich.console import Console

        console = Console(force_terminal=True, width=80)
        result = TierResult(
            software="test-app",
            tier=Tier.T2A,
            confidence=90,
            est_tokens_k=8,
            checks={
                "python_binding": CheckResult(passed=False, detail="not found"),
                "source_code": CheckResult(passed=True, detail="local: /src"),
                "cli_support": CheckResult(passed=True, detail="/usr/bin/test-app"),
                "uia_quality": CheckResult(passed=False, detail="skipped", value=0.0),
            },
        )
        # Should not raise
        print_report(result, console=console)


# ---------------------------------------------------------------------------
# fallback_hint & runtime probe
# ---------------------------------------------------------------------------


class TestFallbackHint:
    """``fallback_hint`` auto-fill behaviour."""

    def test_tier3c_suggests_cli_anything(self) -> None:
        hint = _fallback_hint_for(Tier.T3C, "SomeApp")
        assert hint == "cli-anything-someapp"

    def test_tier4_suggests_vision(self) -> None:
        assert _fallback_hint_for(Tier.T4, "baidupan") == "vision-model"

    def test_tier1_no_hint(self) -> None:
        assert _fallback_hint_for(Tier.T1, "ffmpeg") is None

    def test_tier_result_autofills_hint(self) -> None:
        r = TierResult(software="baidupan", tier=Tier.T4)
        assert r.fallback_hint == "vision-model"

    def test_tier_result_explicit_hint_preserved(self) -> None:
        r = TierResult(software="x", tier=Tier.T4, fallback_hint="custom-hint")
        assert r.fallback_hint == "custom-hint"


class TestRefineTierFromProbe:
    """``_refine_tier_from_probe`` downgrade / upgrade rules."""

    def test_tier1_preserved(self) -> None:
        probe = RuntimeProbeResult(launched=True, total_controls=10, named_controls=0)
        assert _refine_tier_from_probe(Tier.T1, probe) == Tier.T1

    def test_tier2a_preserved(self) -> None:
        probe = RuntimeProbeResult(launched=False)
        assert _refine_tier_from_probe(Tier.T2A, probe) == Tier.T2A

    def test_webview_shell_empty_tree_downgrades_to_tier4(self) -> None:
        probe = RuntimeProbeResult(
            launched=True,
            total_controls=0,
            has_webview_shell=True,
            detail="empty CEF shell",
        )
        assert _refine_tier_from_probe(Tier.T1, probe) == Tier.T1  # T1 protected
        assert _refine_tier_from_probe(Tier.T3A, probe) == Tier.T4

    def test_high_named_ratio_promotes_to_tier3a(self) -> None:
        probe = RuntimeProbeResult(
            launched=True, total_controls=20, named_controls=16, named_ratio=0.8,
        )
        assert _refine_tier_from_probe(Tier.T4, probe) == Tier.T3A

    def test_mid_ratio_tier3b(self) -> None:
        probe = RuntimeProbeResult(
            launched=True, total_controls=20, named_controls=10, named_ratio=0.5,
        )
        assert _refine_tier_from_probe(Tier.T4, probe) == Tier.T3B

    def test_low_ratio_tier3c(self) -> None:
        probe = RuntimeProbeResult(
            launched=True, total_controls=20, named_controls=2, named_ratio=0.1,
        )
        assert _refine_tier_from_probe(Tier.T3A, probe) == Tier.T3C


# ---------------------------------------------------------------------------
# detect_tier(runtime_probe=...) integration
# ---------------------------------------------------------------------------


class TestDetectTierRuntimeProbe:
    """End-to-end ``detect_tier`` with the new ``runtime_probe`` flag.

    Patches ``runtime_probe_target`` + the individual check helpers so
    tests work on any OS and don't actually launch GUIs.
    """

    def _mock_checks(
        self,
        *,
        pypi: bool = False,
        source: bool = False,
        cli: bool = False,
        uia_value: float = 0.0,
    ) -> dict[str, object]:
        return {
            "check_pypi": MagicMock(
                return_value=CheckResult(passed=pypi, detail="v1.0" if pypi else "miss"),
            ),
            "check_source": MagicMock(
                return_value=CheckResult(passed=source, detail=""),
            ),
            "check_cli": MagicMock(
                return_value=CheckResult(passed=cli, detail=""),
            ),
            "check_uia": MagicMock(
                return_value=CheckResult(passed=uia_value > 0, value=uia_value),
            ),
        }

    def test_baidupan_static_misclassified_as_tier1(self) -> None:
        """Current bug baseline: static detect returns Tier 1 from same-name PyPI."""
        mocks = self._mock_checks(pypi=True, source=False, cli=False)
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
        ):
            result = detect_tier("baidupan", runtime_probe=False)
        assert result.tier == Tier.T1
        assert result.runtime_probed is False

    def test_baidupan_probe_demotes_to_tier4(self) -> None:
        """With --probe and empty CEF shell, baidupan drops to Tier 4."""
        mocks = self._mock_checks(pypi=True, source=False, cli=False)
        fake_probe = RuntimeProbeResult(
            launched=True,
            exe_path="C:/fake/baidupan.exe",
            pid=12345,
            total_controls=1,
            named_controls=0,
            named_ratio=0.0,
            has_webview_shell=True,
            detail="0/1 named (0%) — CEF shell",
        )
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
            patch(
                "api_anything.tier_detect.runtime_probe_target",
                return_value=fake_probe,
            ),
        ):
            result = detect_tier("baidupan", runtime_probe=True)
        assert result.tier == Tier.T4
        assert result.runtime_probed is True
        assert result.fallback_hint == "vision-model"
        assert "runtime_probe" in result.checks

    def test_mspaint_probe_promotes_to_tier3a(self) -> None:
        """--probe can also promote a misjudged Tier 4 (no PyPI / source) to 3A."""
        mocks = self._mock_checks(pypi=False, source=False, cli=False, uia_value=0.0)
        fake_probe = RuntimeProbeResult(
            launched=True,
            exe_path="C:/Windows/System32/mspaint.exe",
            pid=22222,
            total_controls=30,
            named_controls=24,
            named_ratio=0.8,
            has_webview_shell=False,
            detail="24/30 named (80%)",
        )
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
            patch(
                "api_anything.tier_detect.runtime_probe_target",
                return_value=fake_probe,
            ),
        ):
            result = detect_tier("mspaint", runtime_probe=True)
        assert result.tier == Tier.T3A
        assert result.runtime_probed is True
        assert result.fallback_hint is None

    def test_probe_skipped_when_tier2a_has_source_and_cli(self) -> None:
        """Tier 2A (source + CLI) should NOT trigger a probe — strong evidence."""
        mocks = self._mock_checks(pypi=False, source=True, cli=True)
        probe_mock = MagicMock()
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
            patch("api_anything.tier_detect.runtime_probe_target", probe_mock),
        ):
            result = detect_tier("ffmpeg", runtime_probe=True)
        assert result.tier == Tier.T2A
        assert result.runtime_probed is False
        probe_mock.assert_not_called()

    def test_probe_default_false_preserves_legacy_behaviour(self) -> None:
        """Calling without ``runtime_probe=`` must not change existing behaviour."""
        mocks = self._mock_checks(pypi=False, source=False, cli=False, uia_value=0.0)
        probe_mock = MagicMock()
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
            patch("api_anything.tier_detect.runtime_probe_target", probe_mock),
        ):
            result = detect_tier("unknown-app")
        assert result.tier == Tier.T4
        assert result.runtime_probed is False
        probe_mock.assert_not_called()


# ---------------------------------------------------------------------------
# B 項：cli_alias_candidates
# ---------------------------------------------------------------------------


class TestCliAliasCandidates:
    """``cli_alias_candidates`` 產生常見 Windows 變體。"""

    def test_basic_expansion(self) -> None:
        out = cli_alias_candidates("ffmpeg")
        assert "ffmpeg" in out
        assert "ffmpeg.exe" in out
        assert "ffmpeg-win64" in out
        # 保留順序 + 去重
        assert len(out) == len(set(out))

    def test_strips_exe_suffix_before_expanding(self) -> None:
        """傳入 'name.exe' 不應產生 'name.exe.exe'。"""
        out = cli_alias_candidates("ffmpeg.exe")
        assert "ffmpeg.exe.exe" not in out
        assert "ffmpeg" in out

    def test_empty_name_returns_empty_list(self) -> None:
        assert cli_alias_candidates("") == []
        assert cli_alias_candidates("   ") == []


# ---------------------------------------------------------------------------
# B 項：detect_install_path
# ---------------------------------------------------------------------------


class TestDetectInstallPath:
    """``detect_install_path`` 掃描多個 Windows 安裝位置。"""

    def test_found_in_path(self) -> None:
        """PATH 命中 → 直接回傳 shutil.which 結果。"""
        with (
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Windows",
            ),
            patch(
                "api_anything.tier_detect.shutil.which",
                side_effect=lambda n: (
                    "C:/tools/bin/ffmpeg.exe" if n == "ffmpeg" else None
                ),
            ),
        ):
            assert detect_install_path("ffmpeg") == "C:/tools/bin/ffmpeg.exe"

    def test_non_windows_uses_shutil_which(self) -> None:
        """Linux/macOS 時只用 shutil.which（無 registry / ProgramFiles）。"""
        with (
            patch(
                "api_anything.tier_detect.platform.system", return_value="Linux",
            ),
            patch(
                "api_anything.tier_detect.shutil.which",
                return_value="/usr/bin/ffmpeg",
            ),
        ):
            assert detect_install_path("ffmpeg") == "/usr/bin/ffmpeg"

    def test_localappdata_programs_scan(self, tmp_path: Path) -> None:
        """找不到 PATH 時，掃 LOCALAPPDATA\\Programs。"""
        programs = tmp_path / "Programs" / "cursor"
        programs.mkdir(parents=True)
        fake_exe = programs / "cursor.exe"
        fake_exe.write_bytes(b"MZ")  # PE header stub

        with (
            patch(
                "api_anything.tier_detect.platform.system", return_value="Windows",
            ),
            patch("api_anything.tier_detect.shutil.which", return_value=None),
            patch.dict(
                "api_anything.tier_detect.os.environ",
                {"LOCALAPPDATA": str(tmp_path)},
                clear=False,
            ),
        ):
            # winreg 一定失敗 → 走到 ProgramFiles/LOCALAPPDATA 掃描
            result = detect_install_path("cursor")
        # 確認有搜到（str 比較兼容不同斜線）
        assert result is not None
        assert "cursor.exe" in result.lower()

    def test_returns_none_when_nothing_found(self) -> None:
        with (
            patch(
                "api_anything.tier_detect.platform.system", return_value="Windows",
            ),
            patch("api_anything.tier_detect.shutil.which", return_value=None),
            patch.dict(
                "api_anything.tier_detect.os.environ",
                {
                    "ProgramFiles": r"C:\Nonexistent\ProgramFiles",
                    "ProgramFiles(x86)": r"C:\Nonexistent\PF86",
                    "LOCALAPPDATA": r"C:\Nonexistent\LAD",
                    "USERPROFILE": r"C:\Nonexistent\User",
                    "ChocolateyInstall": r"C:\Nonexistent\choco",
                },
                clear=False,
            ),
        ):
            assert detect_install_path("xyzzy-nonexistent-app-12345") is None


# ---------------------------------------------------------------------------
# B 項：_looks_like_electron 指紋判斷
# ---------------------------------------------------------------------------


class TestLooksLikeElectron:
    """Electron / CEF fingerprint heuristic."""

    def test_known_electron_name(self) -> None:
        """已知 Electron app 名直接命中，不看 path。"""
        assert _looks_like_electron(None, "discord") is True
        assert _looks_like_electron(None, "Slack") is True
        assert _looks_like_electron(None, "VSCode") is True

    def test_asar_path_marker(self) -> None:
        path = r"C:\Users\x\AppData\Local\Programs\foo\resources\app.asar"
        assert _looks_like_electron(path, "foo") is True

    def test_cef_dll_marker(self) -> None:
        assert _looks_like_electron(r"C:\apps\something\libcef.dll", "x") is True

    def test_regular_win32_app_not_flagged(self) -> None:
        """C:\\Windows\\System32\\notepad.exe 不該被誤判。"""
        assert _looks_like_electron(r"C:\Windows\System32\notepad.exe", "notepad") is False

    def test_none_path_unknown_name_false(self) -> None:
        assert _looks_like_electron(None, "ffmpeg") is False


# ---------------------------------------------------------------------------
# B 項：_enrich_checks 整合行為
# ---------------------------------------------------------------------------


class TestEnrichChecks:
    """``_enrich_checks`` post-processing behaviour."""

    def _base_checks(
        self,
        *,
        pypi: bool = False,
        source: bool = False,
        cli: bool = False,
        uia_value: float = 0.0,
    ) -> dict[str, CheckResult]:
        return {
            "python_binding": CheckResult(passed=pypi),
            "source_code": CheckResult(passed=source),
            "cli_support": CheckResult(passed=cli, detail=""),
            "uia_quality": CheckResult(passed=uia_value > 0, value=uia_value),
        }

    def test_host_os_populated(self) -> None:
        with patch(
            "api_anything.tier_detect.platform.system",
            return_value="Linux",
        ), patch(
            "api_anything.tier_detect.detect_install_path", return_value=None,
        ):
            _, _, _, _, host_os = _enrich_checks(
                "ffmpeg", self._base_checks(), Tier.T4,
            )
        assert host_os == "Linux"

    def test_cli_alias_rescue_upgrades_t2b_to_t2a(self) -> None:
        """Source OK + check_cli miss + alias 'ffmpeg-win64' 找到 → T2A。"""
        checks = self._base_checks(source=True, cli=False)

        def fake_which(alias: str) -> str | None:
            return r"C:\tools\ffmpeg-win64.exe" if alias == "ffmpeg-win64" else None

        with (
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Windows",
            ),
            patch(
                "api_anything.tier_detect.detect_install_path",
                return_value=r"C:\tools\ffmpeg-win64.exe",
            ),
            patch("api_anything.tier_detect.shutil.which", side_effect=fake_which),
        ):
            enriched, tier, install_path, electron, host_os = _enrich_checks(
                "ffmpeg", checks, Tier.T2B,
            )
        assert tier == Tier.T2A
        assert enriched["cli_support"].passed is True
        assert "alias" in enriched["cli_support"].detail
        assert install_path == r"C:\tools\ffmpeg-win64.exe"
        assert electron is False
        assert host_os == "Windows"

    def test_electron_fingerprint_flagged_on_known_app(self) -> None:
        """PyPI 假命中 + 無 source + 無 CLI + 已知 Electron 名 → flag。"""
        checks = self._base_checks(pypi=True, source=False, cli=False)
        with (
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Windows",
            ),
            patch(
                "api_anything.tier_detect.detect_install_path",
                return_value=r"C:\Users\u\AppData\Local\Programs\discord\Discord.exe",
            ),
            patch(
                "api_anything.tier_detect.shutil.which", return_value=None,
            ),
        ):
            enriched, tier, install_path, electron, _ = _enrich_checks(
                "discord", checks, Tier.T1,
            )
        assert electron is True
        # _enrich_checks 不硬改 tier，只加 flag + fingerprint check
        assert tier == Tier.T1
        assert "electron_fingerprint" in enriched
        assert install_path is not None

    def test_electron_not_flagged_when_source_present(self) -> None:
        """有 source / CLI → 不是同名騙子，不觸 Electron flag。"""
        checks = self._base_checks(pypi=True, source=True, cli=True)
        with (
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Windows",
            ),
            patch(
                "api_anything.tier_detect.detect_install_path",
                return_value=r"C:\Program Files\Discord\Discord.exe",
            ),
            patch(
                "api_anything.tier_detect.shutil.which",
                return_value=r"C:\Program Files\Discord\Discord.exe",
            ),
        ):
            _, _, _, electron, _ = _enrich_checks("discord", checks, Tier.T1)
        assert electron is False

    def test_linux_uia_skipped_marker(self) -> None:
        """Linux 上 UIA check 被標記 skipped。"""
        checks = self._base_checks(uia_value=0.0)
        with (
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Linux",
            ),
            patch(
                "api_anything.tier_detect.detect_install_path",
                return_value=None,
            ),
        ):
            enriched, _, _, _, _ = _enrich_checks(
                "audacity", checks, Tier.T4,
            )
        assert "skipped" in enriched["uia_quality"].detail.lower()
        assert "Linux" in enriched["uia_quality"].detail


# ---------------------------------------------------------------------------
# B 項：TierResult 新 fields + detect_tier integration
# ---------------------------------------------------------------------------


class TestTierResultNewFields:
    """B 項新增的 TierResult 欄位 default 正確。"""

    def test_defaults(self) -> None:
        r = TierResult(software="x", tier=Tier.T1)
        assert r.install_path is None
        assert r.electron_suspected is False
        assert r.host_os == ""

    def test_explicit_values_preserved(self) -> None:
        r = TierResult(
            software="discord",
            tier=Tier.T1,
            install_path=r"C:\Programs\Discord.exe",
            electron_suspected=True,
            host_os="Windows",
        )
        assert r.install_path == r"C:\Programs\Discord.exe"
        assert r.electron_suspected is True
        assert r.host_os == "Windows"


class TestDetectTierEnrichIntegration:
    """End-to-end：detect_tier → enrich → 填入新 fields。"""

    def _mock_checks(
        self,
        *,
        pypi: bool = False,
        source: bool = False,
        cli: bool = False,
        uia_value: float = 0.0,
    ) -> dict[str, object]:
        return {
            "check_pypi": MagicMock(
                return_value=CheckResult(passed=pypi, detail="v1.0" if pypi else ""),
            ),
            "check_source": MagicMock(
                return_value=CheckResult(passed=source, detail=""),
            ),
            "check_cli": MagicMock(
                return_value=CheckResult(passed=cli, detail=""),
            ),
            "check_uia": MagicMock(
                return_value=CheckResult(passed=uia_value > 0, value=uia_value),
            ),
        }

    def test_detect_tier_discord_electron_flag(self) -> None:
        """Discord 靜態偵測：PyPI 假命中 → electron_suspected=True。"""
        mocks = self._mock_checks(pypi=True, source=False, cli=False)
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
            patch(
                "api_anything.tier_detect.detect_install_path",
                return_value=r"C:\Users\u\AppData\Local\Programs\discord\Discord.exe",
            ),
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Windows",
            ),
        ):
            result = detect_tier("discord")
        assert result.electron_suspected is True
        assert result.install_path is not None
        assert result.host_os == "Windows"

    def test_detect_tier_electron_suspicion_triggers_probe(self) -> None:
        """Electron 指紋 + runtime_probe=True → 觸 probe 並 demote 到 T4。"""
        mocks = self._mock_checks(pypi=True, source=False, cli=False)
        fake_probe = RuntimeProbeResult(
            launched=True,
            exe_path=r"C:\Programs\Discord.exe",
            pid=9999,
            total_controls=2,
            named_controls=0,
            named_ratio=0.0,
            has_webview_shell=True,
            detail="CEF shell",
        )
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
            patch(
                "api_anything.tier_detect.detect_install_path",
                return_value=r"C:\Programs\Discord.exe",
            ),
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Windows",
            ),
            patch(
                "api_anything.tier_detect.runtime_probe_target",
                return_value=fake_probe,
            ),
        ):
            result = detect_tier("discord", runtime_probe=True)
        assert result.tier == Tier.T4
        assert result.runtime_probed is True
        assert result.electron_suspected is True
        assert result.fallback_hint == "vision-model"

    def test_detect_tier_host_os_always_populated(self) -> None:
        """任何 detect_tier 呼叫後 host_os 都有值；非 Windows host 不觸發 runtime_probe。"""
        mocks = self._mock_checks(pypi=False, source=False, cli=False)
        probe_mock = MagicMock()
        with (
            patch("api_anything.tier_detect.check_pypi", mocks["check_pypi"]),
            patch("api_anything.tier_detect.check_source", mocks["check_source"]),
            patch("api_anything.tier_detect.check_cli", mocks["check_cli"]),
            patch("api_anything.tier_detect.check_uia", mocks["check_uia"]),
            patch(
                "api_anything.tier_detect.detect_install_path",
                return_value=None,
            ),
            patch(
                "api_anything.tier_detect.platform.system",
                return_value="Darwin",
            ),
            patch("api_anything.tier_detect.runtime_probe_target", probe_mock),
        ):
            result = detect_tier("audacity")
        assert result.host_os == "Darwin"
        probe_mock.assert_not_called()
