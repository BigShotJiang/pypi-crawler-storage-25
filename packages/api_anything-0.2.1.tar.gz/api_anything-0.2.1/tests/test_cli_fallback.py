"""Tests for CLI-Anything fallback layer (RFC §3 方案 C).

All tests mock subprocess / shutil.which — no real CLI-Anything install needed.
"""

from __future__ import annotations

import json
import subprocess
from unittest.mock import MagicMock, patch

import pytest

from api_anything.cli_fallback import (
    CLI_BINARY_PREFIX,
    CliFallbackError,
    invoke_cli,
    is_cli_available,
    load_schema,
    with_cli_fallback,
)

# ── helpers ──────────────────────────────────────────────────────────────


def _ok(stdout: str = "", stderr: str = "", returncode: int = 0) -> MagicMock:
    """Return a mock subprocess.CompletedProcess."""
    m = MagicMock()
    m.stdout = stdout
    m.stderr = stderr
    m.returncode = returncode
    return m


# ── is_cli_available ─────────────────────────────────────────────────────


class TestIsCliAvailable:
    def test_present_short_name(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which") as which:
            which.return_value = "/usr/local/bin/cli-anything-ffmpeg"
            assert is_cli_available("ffmpeg") is True
            which.assert_called_once_with("cli-anything-ffmpeg")

    def test_present_full_name(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which") as which:
            which.return_value = "C:/tools/cli-anything-git.exe"
            assert is_cli_available("cli-anything-git") is True
            which.assert_called_once_with("cli-anything-git")

    def test_missing(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which", return_value=None):
            assert is_cli_available("nonexistent-xyz") is False

    def test_empty_name(self) -> None:
        # Short-circuit: empty name never calls which.
        with patch("api_anything.cli_fallback.shutil.which") as which:
            assert is_cli_available("") is False
            which.assert_not_called()


# ── invoke_cli ───────────────────────────────────────────────────────────


class TestInvokeCli:
    def test_success_json(self) -> None:
        payload = {"status": "ok", "files": ["a.mp4"]}
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout=json.dumps(payload)),
        ) as run:
            result = invoke_cli("ffmpeg", "probe", ["/tmp/a.mp4"])
        assert result == payload
        called_cmd = run.call_args[0][0]
        assert called_cmd[0] == "cli-anything-ffmpeg"
        assert called_cmd[1] == "probe"
        assert "/tmp/a.mp4" in called_cmd
        assert "--json" in called_cmd

    def test_success_raw_when_json_parse_fails(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout="not json text"),
        ):
            result = invoke_cli("ffmpeg", "probe", [], json_output=True)
        assert result == "not json text"

    def test_success_no_json_flag(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout="raw"),
        ) as run:
            result = invoke_cli("git", "status", ["/repo"], json_output=False)
        assert result == "raw"
        called_cmd = run.call_args[0][0]
        assert "--json" not in called_cmd

    def test_binary_missing_raises(self) -> None:
        with (
            patch("api_anything.cli_fallback.shutil.which", return_value=None),
            pytest.raises(CliFallbackError) as exc_info,
        ):
            invoke_cli("ffmpeg", "probe", [])
        assert "pip install cli-anything-ffmpeg" in str(exc_info.value)

    def test_non_zero_exit_raises(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout="", stderr="boom\nbad flag", returncode=3),
        ), pytest.raises(CliFallbackError) as exc_info:
            invoke_cli("ffmpeg", "convert", ["a", "b"])
        assert exc_info.value.exit_code == 3
        assert "boom" in (exc_info.value.stderr or "")

    def test_timeout_raises(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            side_effect=subprocess.TimeoutExpired(cmd="x", timeout=1.0),
        ), pytest.raises(CliFallbackError) as exc_info:
            invoke_cli("ffmpeg", "probe", [], timeout=1.0)
        assert "timed out" in str(exc_info.value)

    def test_check_false_returns_on_nonzero(self) -> None:
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout='{"k": 1}', returncode=2),
        ):
            # check=False → no raise even on non-zero
            result = invoke_cli("ffmpeg", "probe", [], check=False)
        assert result == {"k": 1}


# ── with_cli_fallback decorator ──────────────────────────────────────────


class _DummyApi:
    """Test double for decorator — primary behaviour is configurable."""

    def __init__(self, raise_exc: Exception | None = None) -> None:
        self._raise_exc = raise_exc

    @with_cli_fallback("ffmpeg", "convert")
    def convert(self, src: str, dst: str) -> dict:
        if self._raise_exc:
            raise self._raise_exc
        return {"primary": True, "src": src, "dst": dst}

    @with_cli_fallback("git", "status", fallback_on=["RuntimeError"])
    def status(self, repo: str) -> dict:
        if self._raise_exc:
            raise self._raise_exc
        return {"primary": True, "repo": repo}


class TestDecorator:
    def test_primary_succeeds_no_fallback(self) -> None:
        api = _DummyApi(raise_exc=None)
        with patch("api_anything.cli_fallback.subprocess.run") as run:
            result = api.convert("a.mp4", "b.mp4")
        assert result == {"primary": True, "src": "a.mp4", "dst": "b.mp4"}
        run.assert_not_called()

    def test_primary_raises_triggers_fallback(self) -> None:
        api = _DummyApi(raise_exc=NotImplementedError("primary not ready"))
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout='{"fallback": true}'),
        ) as run:
            result = api.convert("a.mp4", "b.mp4")
        assert result == {"fallback": True}
        # Verify fallback passed positional args minus self
        called_cmd = run.call_args[0][0]
        assert called_cmd[:2] == ["cli-anything-ffmpeg", "convert"]
        assert "a.mp4" in called_cmd and "b.mp4" in called_cmd

    def test_fallback_cli_also_fails_propagates(self) -> None:
        api = _DummyApi(raise_exc=NotImplementedError("primary dead"))
        # CLI binary also missing -> CliFallbackError
        with (
            patch("api_anything.cli_fallback.shutil.which", return_value=None),
            pytest.raises(CliFallbackError),
        ):
            api.convert("a", "b")

    def test_custom_fallback_on_list(self) -> None:
        api = _DummyApi(raise_exc=RuntimeError("primary runtime issue"))
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout='{"ok": 1}'),
        ):
            result = api.status("/repo")
        assert result == {"ok": 1}

    def test_non_trigger_exception_propagates(self) -> None:
        # ValueError is not in default fallback list for convert()
        api = _DummyApi(raise_exc=ValueError("bad input"))
        with (
            patch("api_anything.cli_fallback.subprocess.run") as run,
            pytest.raises(ValueError, match="bad input"),
        ):
            api.convert("a", "b")
        run.assert_not_called()

    def test_name_matched_exception_triggers_fallback(self) -> None:
        """Exception with matching name but unknown class still triggers fallback."""

        class UIACoverageError(Exception):
            """Declared locally — not imported by cli_fallback module."""

        class _UiaApi:
            def __init__(self, exc: Exception) -> None:
                self._exc = exc

            @with_cli_fallback("notepad", "open")
            def open(self, path: str) -> dict:
                raise self._exc

        api = _UiaApi(UIACoverageError("coverage 12%"))
        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout='{"via_cli": true}'),
        ) as run:
            result = api.open("note.txt")
        assert result == {"via_cli": True}
        called_cmd = run.call_args[0][0]
        assert called_cmd[0] == "cli-anything-notepad"

    def test_arg_builder_override(self) -> None:
        def build(self, src: str, dst: str) -> list[str]:
            return ["--input", src, "--output", dst, "--codec", "h264"]

        class _Api:
            @with_cli_fallback("ffmpeg", "convert", arg_builder=build)
            def convert(self, src: str, dst: str) -> dict:
                raise NotImplementedError

        with patch("api_anything.cli_fallback.shutil.which", return_value="x"), patch(
            "api_anything.cli_fallback.subprocess.run",
            return_value=_ok(stdout='{"ok": 1}'),
        ) as run:
            _Api().convert("a.mp4", "b.mp4")
        called_cmd = run.call_args[0][0]
        assert "--codec" in called_cmd and "h264" in called_cmd


# ── load_schema ──────────────────────────────────────────────────────────


class TestLoadSchema:
    def test_ffmpeg_schema_loads(self) -> None:
        schema = load_schema("ffmpeg")
        assert schema["cli_binary"] == "cli-anything-ffmpeg"
        assert "methods" in schema
        assert "convert" in schema["methods"]
        assert schema["methods"]["convert"]["subcmd"] == "convert"

    def test_git_schema_loads(self) -> None:
        schema = load_schema("git")
        assert schema["cli_binary"] == "cli-anything-git"
        assert "clone" in schema["methods"]

    def test_notepad_schema_loads(self) -> None:
        schema = load_schema("notepad")
        assert schema["cli_binary"] == "cli-anything-notepad"
        assert "open_file" in schema["methods"]

    def test_missing_schema_raises(self) -> None:
        with pytest.raises(CliFallbackError) as exc_info:
            load_schema("nonexistent-software-xyz")
        assert "not found" in str(exc_info.value)

    def test_all_schemas_have_required_keys(self) -> None:
        for sw in ("ffmpeg", "git", "notepad"):
            schema = load_schema(sw)
            assert "cli_binary" in schema
            assert "methods" in schema
            assert isinstance(schema["methods"], dict)
            assert len(schema["methods"]) >= 1
            for method_name, method_spec in schema["methods"].items():
                assert "subcmd" in method_spec, f"{sw}.{method_name} missing subcmd"


# ── CLI binary prefix constant ───────────────────────────────────────────


def test_cli_binary_prefix() -> None:
    assert CLI_BINARY_PREFIX == "cli-anything-"


# ── Notepad decorator integration (RFC v0.2 A4) ──────────────────────────


class TestNotepadDecorator:
    """Notepad 的 @with_cli_fallback decorator 已正確掛上.

    Notepad 只在 Windows 可 import (sys.platform guard),
    因此這裡 import 在 test method 內部, 避免非 Windows 環境 collection 失敗.
    """

    def _get_notepad_cls(self) -> type | None:
        import sys

        if sys.platform != "win32":
            return None
        from api_anything.apis.notepad import Notepad
        return Notepad

    def test_notepad_methods_are_wrapped(self) -> None:
        """5 個 schema-mapped 方法必須是被 @with_cli_fallback 包裝."""
        cls = self._get_notepad_cls()
        if cls is None:
            pytest.skip("Notepad only on Windows")
        wrapped_methods = ("set_text", "get_text", "open_file", "save_as", "close")
        for name in wrapped_methods:
            fn = getattr(cls, name)
            # with_cli_fallback 用 functools.wraps, 包裝後 wrapper 有 __wrapped__
            assert hasattr(fn, "__wrapped__"), (
                f"{name} is not wrapped with @with_cli_fallback"
            )

    def test_wrapped_method_preserves_signature(self) -> None:
        """@wraps 須保留原簽名 (否則 IDE / 靜態分析壞掉)."""
        cls = self._get_notepad_cls()
        if cls is None:
            pytest.skip("Notepad only on Windows")
        # set_text 原簽名: (self, text: str) -> None
        assert cls.set_text.__name__ == "set_text"
        # docstring 也須保留
        assert "text content" in (cls.set_text.__doc__ or "")
