"""Tests for additional API-Anything POC modules.

All tests use mocking — no actual software installation required.
Tests verify: command construction, binary-not-found handling, output parsing.
"""

from __future__ import annotations

import sys
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "examples"))

from docker_api import DockerAPI, DockerNotFoundError  # noqa: E402
from git_api import GitAPI, GitNotFoundError  # noqa: E402
from imagemagick_api import ImageMagickAPI, ImageMagickNotFoundError  # noqa: E402
from pandoc_api import PandocAPI, PandocNotFoundError  # noqa: E402
from sqlite_api import SQLiteAPI  # noqa: E402


# ═══════════════════════════════════════════════════════════════
# SQLite (Tier 1 — in-process, no mocking needed for basic ops)
# ═══════════════════════════════════════════════════════════════


class TestSQLiteAPI:
    def test_create_table_and_insert(self) -> None:
        db = SQLiteAPI(":memory:")
        db.create_table("users", {"id": "INTEGER PRIMARY KEY", "name": "TEXT"})
        row_id = db.insert("users", {"name": "Alice"})
        assert row_id == 1
        rows = db.query("SELECT * FROM users")
        assert len(rows) == 1
        assert rows[0]["name"] == "Alice"
        db.close()

    def test_get_tables_and_schema(self) -> None:
        db = SQLiteAPI(":memory:")
        db.create_table("items", {"id": "INTEGER", "val": "TEXT"})
        tables = db.get_tables()
        assert "items" in tables
        schema = db.get_schema("items")
        assert "items" in schema
        db.close()

    def test_update_and_delete(self) -> None:
        db = SQLiteAPI(":memory:")
        db.create_table("t", {"id": "INTEGER PRIMARY KEY", "v": "INTEGER"})
        db.insert("t", {"v": 10})
        db.insert("t", {"v": 20})
        updated = db.update("t", {"v": 99}, "id = 1")
        assert updated == 1
        deleted = db.delete("t", "v = 20")
        assert deleted == 1
        rows = db.query("SELECT * FROM t")
        assert len(rows) == 1
        assert rows[0]["v"] == 99
        db.close()


# ═══════════════════════════════════════════════════════════════
# ImageMagick (Tier 2A — subprocess mock)
# ═══════════════════════════════════════════════════════════════


class TestImageMagickAPI:
    def test_resize_command(self) -> None:
        with patch("imagemagick_api.shutil.which", return_value="/usr/bin/magick"), \
             patch("imagemagick_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            im = ImageMagickAPI()
            im.resize("in.jpg", "out.jpg", 800, 600)
            cmd = mock_run.call_args[0][0]
            assert cmd[0] == "magick"
            assert "-resize" in cmd
            assert "800x600!" in cmd

    def test_not_found(self) -> None:
        with patch("imagemagick_api.shutil.which", return_value=None):
            im = ImageMagickAPI(magick_path="magick")
            with pytest.raises(ImageMagickNotFoundError):
                im.resize("in.jpg", "out.jpg", 100, 100)

    def test_get_info_command(self) -> None:
        fake_json = '{"format":"JPEG","width":1920,"height":1080,"size":"500KB","colorspace":"sRGB"}'
        with patch("imagemagick_api.shutil.which", return_value="/usr/bin/magick"), \
             patch("imagemagick_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=fake_json, stderr="")
            im = ImageMagickAPI()
            info = im.get_info("photo.jpg")
            assert info["width"] == 1920
            assert info["format"] == "JPEG"


# ═══════════════════════════════════════════════════════════════
# Pandoc (Tier 2A — subprocess mock)
# ═══════════════════════════════════════════════════════════════


class TestPandocAPI:
    def test_markdown_to_html_command(self) -> None:
        with patch("pandoc_api.shutil.which", return_value="/usr/bin/pandoc"), \
             patch("pandoc_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            pd = PandocAPI()
            pd.markdown_to_html("doc.md", "doc.html")
            cmd = mock_run.call_args[0][0]
            assert "pandoc" in cmd[0]
            assert "-f" in cmd and "markdown" in cmd
            assert "-t" in cmd and "html" in cmd

    def test_not_found(self) -> None:
        with patch("pandoc_api.shutil.which", return_value=None):
            pd = PandocAPI()
            with pytest.raises(PandocNotFoundError):
                pd.convert("in.md", "out.html")

    def test_version_parsing(self) -> None:
        with patch("pandoc_api.shutil.which", return_value="/usr/bin/pandoc"), \
             patch("pandoc_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(
                returncode=0, stdout="pandoc 3.1.9\nCompiled with...", stderr=""
            )
            pd = PandocAPI()
            assert pd.version() == "3.1.9"


# ═══════════════════════════════════════════════════════════════
# Git (Tier 2A — subprocess mock)
# ═══════════════════════════════════════════════════════════════


class TestGitAPI:
    def test_status_parsing(self) -> None:
        porcelain = "M  file1.py\n?? newfile.txt\nA  staged.py\n"
        with patch("git_api.shutil.which", return_value="/usr/bin/git"), \
             patch("git_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=porcelain, stderr="")
            git = GitAPI("/tmp/repo")
            status = git.status()
            assert "newfile.txt" in status["untracked"]
            assert "staged.py" in status["staged"]

    def test_not_found(self) -> None:
        with patch("git_api.shutil.which", return_value=None):
            git = GitAPI()
            with pytest.raises(GitNotFoundError):
                git.status()

    def test_log_parsing(self) -> None:
        sep = "---GIT-SEP---"
        log_output = f"abc123{sep}Alice{sep}2026-01-01 12:00:00{sep}feat: init\n"
        with patch("git_api.shutil.which", return_value="/usr/bin/git"), \
             patch("git_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=log_output, stderr="")
            git = GitAPI("/tmp/repo")
            entries = git.log(1)
            assert len(entries) == 1
            assert entries[0]["hash"] == "abc123"
            assert entries[0]["subject"] == "feat: init"


# ═══════════════════════════════════════════════════════════════
# Docker (Tier 2A — subprocess mock)
# ═══════════════════════════════════════════════════════════════


class TestDockerAPI:
    def test_run_command(self) -> None:
        with patch("docker_api.shutil.which", return_value="/usr/bin/docker"), \
             patch("docker_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="abc123def\n", stderr="")
            dk = DockerAPI()
            cid = dk.run("nginx:latest", name="web", ports={"80": "8080"})
            cmd = mock_run.call_args[0][0]
            assert "run" in cmd
            assert "--name" in cmd
            assert "-p" in cmd
            assert "80:8080" in cmd
            assert cid == "abc123def"

    def test_not_found(self) -> None:
        with patch("docker_api.shutil.which", return_value=None):
            dk = DockerAPI()
            with pytest.raises(DockerNotFoundError):
                dk.ps()

    def test_ps_json_parsing(self) -> None:
        json_lines = '{"ID":"abc","Names":"web","Image":"nginx"}\n{"ID":"def","Names":"api","Image":"python"}\n'
        with patch("docker_api.shutil.which", return_value="/usr/bin/docker"), \
             patch("docker_api.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout=json_lines, stderr="")
            dk = DockerAPI()
            containers = dk.ps()
            assert len(containers) == 2
            assert containers[0]["Names"] == "web"
