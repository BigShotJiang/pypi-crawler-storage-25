"""Tests for api_anything.generator — code generation pipeline."""

from __future__ import annotations

import ast

from api_anything.generator import (
    _resolve_fallback_enabled,
    generate_api,
    render_api_code,
    render_test_code,
)
from api_anything.models import (
    APIClass,
    APIMethod,
    APIParam,
    UIControl,
)


def _make_controls() -> list[UIControl]:
    """Build a representative set of mock UI controls."""
    return [
        UIControl(name="Open", control_type="Button"),
        UIControl(name="Save", control_type="Button"),
        UIControl(name="File Name", control_type="TextBox"),
        UIControl(name="File", control_type="Menu"),
        UIControl(name="Volume", control_type="Slider"),
        UIControl(name="Dark Mode", control_type="CheckBox"),
    ]


def _make_api_class() -> APIClass:
    """Build a minimal APIClass for rendering tests."""
    return APIClass(
        class_name="NotepadAPI",
        module_name="notepad_api",
        docstring="Python API for Notepad.",
        software_name="notepad",
        tier="3A",
        methods=[
            APIMethod(
                name="open_file",
                docstring="Open a file in Notepad.",
                params=[
                    APIParam(name="path", type_hint="str"),
                ],
                return_type="None",
                operation_mode="subprocess",
                implementation_hint="Run notepad.exe with path arg",
            ),
            APIMethod(
                name="click_save",
                docstring="Click the Save button.",
                params=[],
                return_type="None",
                operation_mode="uia",
                implementation_hint="Find Save button via UIA",
            ),
        ],
        imports=["subprocess", "time"],
        setup_code='self._process = None\nself._software = "notepad"',
    )


class TestRenderApiCode:
    """Tests for render_api_code."""

    def test_produces_valid_python(self) -> None:
        api_class = _make_api_class()
        code = render_api_code(api_class)
        # Must parse without SyntaxError
        ast.parse(code)

    def test_contains_class_name(self) -> None:
        api_class = _make_api_class()
        code = render_api_code(api_class)
        assert "class NotepadAPI:" in code

    def test_contains_methods(self) -> None:
        api_class = _make_api_class()
        code = render_api_code(api_class)
        assert "def open_file(" in code
        assert "def click_save(" in code

    def test_contains_init(self) -> None:
        api_class = _make_api_class()
        code = render_api_code(api_class)
        assert "def __init__(self)" in code

    def test_empty_methods(self) -> None:
        api_class = APIClass(
            class_name="EmptyAPI",
            module_name="empty_api",
            docstring="Empty.",
            software_name="empty",
        )
        code = render_api_code(api_class)
        ast.parse(code)
        assert "class EmptyAPI:" in code


class TestRenderTestCode:
    """Tests for render_test_code."""

    def test_produces_valid_python(self) -> None:
        api_class = _make_api_class()
        code = render_test_code(api_class)
        ast.parse(code)

    def test_contains_fixture(self) -> None:
        api_class = _make_api_class()
        code = render_test_code(api_class)
        assert "@pytest.fixture" in code
        assert "def api(" in code

    def test_contains_test_per_method(self) -> None:
        api_class = _make_api_class()
        code = render_test_code(api_class)
        assert "def test_open_file(" in code
        assert "def test_click_save(" in code


class TestGenerateApi:
    """Tests for the full generate_api pipeline (mock mode)."""

    def test_mock_generation(self) -> None:
        controls = _make_controls()
        result = generate_api("TestApp", controls, tier="3A")
        assert result.api_class.class_name == "TestappAPI"
        assert result.source_code
        assert result.test_code
        assert result.generation_time_seconds >= 0

    def test_mock_always_has_launch_close(self) -> None:
        controls = _make_controls()
        result = generate_api("MyApp", controls)
        method_names = [m.name for m in result.api_class.methods]
        assert "launch" in method_names
        assert "close" in method_names

    def test_mock_source_compiles(self) -> None:
        controls = _make_controls()
        result = generate_api("DemoApp", controls, tier="2A")
        ast.parse(result.source_code)
        ast.parse(result.test_code)

    def test_empty_controls(self) -> None:
        result = generate_api("Bare", [])
        assert len(result.api_class.methods) >= 2  # launch + close
        ast.parse(result.source_code)

    def test_all_control_types(self) -> None:
        controls = _make_controls()
        result = generate_api("Full", controls)
        method_names = [m.name for m in result.api_class.methods]
        # Should generate methods for Button, TextBox, Menu, Slider, CheckBox
        assert len(method_names) >= 7  # 6 controls + launch (close from controls)


# ---------------------------------------------------------------------------
# RFC v0.2 A 項 — Fallback P2/P3 (generator integration)
# ---------------------------------------------------------------------------


class TestResolveFallbackEnabled:
    """_resolve_fallback_enabled 的 tier/confidence 決策矩陣。"""

    def test_explicit_true_wins(self) -> None:
        # explicit 覆寫 tier/confidence
        assert _resolve_fallback_enabled("1", 100, True) is True

    def test_explicit_false_wins(self) -> None:
        # explicit False 即使 tier 3B 也不開啟
        assert _resolve_fallback_enabled("3B", 40, False) is False

    def test_tier_3b_auto_enables(self) -> None:
        assert _resolve_fallback_enabled("3B", None, None) is True

    def test_tier_3c_auto_enables(self) -> None:
        assert _resolve_fallback_enabled("3C", None, None) is True

    def test_tier_4_auto_enables(self) -> None:
        assert _resolve_fallback_enabled("4", None, None) is True

    def test_tier_1_skips_fallback(self) -> None:
        # Tier 1 has native bindings, so CLI degradation is unnecessary.
        assert _resolve_fallback_enabled("1", None, None) is False

    def test_tier_2a_skips_fallback(self) -> None:
        assert _resolve_fallback_enabled("2A", None, None) is False

    def test_low_confidence_enables(self) -> None:
        # confidence < 70 即使 tier 2A 也啟用
        assert _resolve_fallback_enabled("2A", 65, None) is True

    def test_high_confidence_skips(self) -> None:
        assert _resolve_fallback_enabled("2A", 95, None) is False


class TestRenderWithFallback:
    """Structure of rendered code when fallback_enabled=True."""

    def test_uia_method_body_has_fallback_import(self) -> None:
        api_class = _make_api_class()  # tier 3A, UIA method present
        code = render_api_code(api_class, fallback_enabled=True)
        # Module-level try-import for the CLI degradation layer.
        assert "from api_anything.cli_fallback import invoke_cli" in code

    def test_uia_method_body_catches_not_implemented(self) -> None:
        api_class = _make_api_class()
        code = render_api_code(api_class, fallback_enabled=True)
        assert "except NotImplementedError:" in code
        # The fallback branch must dispatch to invoke_cli.
        assert "invoke_cli(" in code

    def test_uia_method_body_no_fallback_when_disabled(self) -> None:
        api_class = _make_api_class()
        code = render_api_code(api_class, fallback_enabled=False)
        # Without fallback, UIA methods keep the legacy path (RuntimeError).
        assert "invoke_cli(" not in code
        assert "cli_fallback" not in code

    def test_subprocess_method_unaffected_by_fallback(self) -> None:
        # subprocess methods share the same path regardless of fallback flag.
        api_class = _make_api_class()
        code_on = render_api_code(api_class, fallback_enabled=True)
        # subprocess method body should only contain subprocess.run, no invoke_cli.
        idx_open_file = code_on.index("def open_file(")
        # Bound the search with the next method definition.
        idx_next = code_on.index("def click_save(", idx_open_file)
        body = code_on[idx_open_file:idx_next]
        assert "subprocess.run(" in body
        assert "invoke_cli(" not in body

    def test_rendered_code_still_valid_python(self) -> None:
        api_class = _make_api_class()
        code = render_api_code(api_class, fallback_enabled=True)
        # Must pass ast.parse so the generated module remains importable.
        ast.parse(code)


class TestGenerateApiFallbackPropagation:
    """generate_api end-to-end: tier decides final fallback behaviour."""

    def test_tier_3b_generates_with_fallback(self) -> None:
        controls = _make_controls()
        result = generate_api("MyGuiApp", controls, tier="3B")
        # Tier 3B auto-enables fallback -> rendered code imports invoke_cli.
        assert "from api_anything.cli_fallback import invoke_cli" in result.source_code

    def test_tier_2a_skips_fallback(self) -> None:
        controls = _make_controls()
        result = generate_api("MyCliApp", controls, tier="2A")
        assert "from api_anything.cli_fallback import invoke_cli" not in result.source_code

    def test_explicit_fallback_enabled_override(self) -> None:
        # Tier 1 normally skips fallback, but explicit=True forces it on.
        controls = _make_controls()
        result = generate_api("MyApp", controls, tier="1", fallback_enabled=True)
        assert "from api_anything.cli_fallback import invoke_cli" in result.source_code

    def test_low_confidence_tier_2a_enables_fallback(self) -> None:
        controls = _make_controls()
        result = generate_api("MyApp", controls, tier="2A", confidence=50)
        # confidence < 70 auto-enables even on tier 2A.
        assert "from api_anything.cli_fallback import invoke_cli" in result.source_code
