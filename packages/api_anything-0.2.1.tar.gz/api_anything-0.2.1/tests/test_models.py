"""Tests for api_anything.models — Pydantic model validation."""

from __future__ import annotations

from api_anything.models import (
    APIClass,
    APIMethod,
    APIParam,
    GenerationResult,
    UIControl,
)


class TestUIControl:
    """UIControl model tests."""

    def test_minimal_creation(self) -> None:
        ctrl = UIControl(name="OK", control_type="Button")
        assert ctrl.name == "OK"
        assert ctrl.control_type == "Button"
        assert ctrl.automation_id == ""
        assert ctrl.children == []

    def test_nested_children(self) -> None:
        child = UIControl(name="Save", control_type="Button")
        parent = UIControl(
            name="File",
            control_type="Menu",
            children=[child],
        )
        assert len(parent.children) == 1
        assert parent.children[0].name == "Save"

    def test_with_value_range(self) -> None:
        ctrl = UIControl(
            name="Volume",
            control_type="Slider",
            value_range=(0.0, 100.0),
            current_value="50",
        )
        assert ctrl.value_range == (0.0, 100.0)
        assert ctrl.current_value == "50"

    def test_deep_nesting(self) -> None:
        leaf = UIControl(name="Leaf", control_type="Button")
        mid = UIControl(name="Mid", control_type="Pane", children=[leaf])
        root = UIControl(name="Root", control_type="Window", children=[mid])
        assert root.children[0].children[0].name == "Leaf"


class TestAPIParam:
    """APIParam model tests."""

    def test_required_param(self) -> None:
        p = APIParam(name="path", type_hint="str", description="File path")
        assert p.name == "path"
        assert p.default is None

    def test_optional_param(self) -> None:
        p = APIParam(name="timeout", type_hint="int", default="30")
        assert p.default == "30"


class TestAPIMethod:
    """APIMethod model tests."""

    def test_no_params(self) -> None:
        m = APIMethod(name="close", docstring="Close the app.")
        assert m.params == []
        assert m.return_type == "None"
        assert m.operation_mode == "subprocess"

    def test_with_params(self) -> None:
        m = APIMethod(
            name="set_volume",
            docstring="Set volume level.",
            params=[
                APIParam(name="level", type_hint="float"),
            ],
            return_type="None",
            operation_mode="uia",
            implementation_hint="Use slider control",
        )
        assert len(m.params) == 1
        assert m.operation_mode == "uia"


class TestAPIClass:
    """APIClass model tests."""

    def test_minimal(self) -> None:
        cls = APIClass(
            class_name="NotepadAPI",
            module_name="notepad_api",
            docstring="Notepad wrapper.",
            software_name="notepad",
        )
        assert cls.tier == "2A"
        assert cls.methods == []
        assert cls.imports == []

    def test_serialization_roundtrip(self) -> None:
        cls = APIClass(
            class_name="NotepadAPI",
            module_name="notepad_api",
            docstring="Notepad wrapper.",
            software_name="notepad",
            methods=[
                APIMethod(
                    name="open_file",
                    docstring="Open a file.",
                    params=[APIParam(name="path", type_hint="str")],
                ),
            ],
        )
        data = cls.model_dump()
        restored = APIClass.model_validate(data)
        assert restored.class_name == "NotepadAPI"
        assert len(restored.methods) == 1
        assert restored.methods[0].params[0].name == "path"

    def test_json_roundtrip(self) -> None:
        cls = APIClass(
            class_name="CalcAPI",
            module_name="calc_api",
            docstring="Calculator wrapper.",
            software_name="calc",
            tier="3A",
        )
        json_str = cls.model_dump_json()
        restored = APIClass.model_validate_json(json_str)
        assert restored.tier == "3A"


class TestGenerationResult:
    """GenerationResult model tests."""

    def test_creation(self) -> None:
        cls = APIClass(
            class_name="TestAPI",
            module_name="test_api",
            docstring="Test.",
            software_name="test",
        )
        result = GenerationResult(
            api_class=cls,
            source_code="class TestAPI: pass",
            test_code="def test_it(): pass",
            tokens_used=100,
            generation_time_seconds=1.5,
        )
        assert result.tokens_used == 100
        assert result.generation_time_seconds == 1.5
        assert result.tier_result is None

    def test_with_tier_result(self) -> None:
        cls = APIClass(
            class_name="TestAPI",
            module_name="test_api",
            docstring="Test.",
            software_name="test",
        )
        result = GenerationResult(
            api_class=cls,
            source_code="",
            test_code="",
            tier_result={"tier": "2A", "confidence": 90},
        )
        assert result.tier_result["tier"] == "2A"
