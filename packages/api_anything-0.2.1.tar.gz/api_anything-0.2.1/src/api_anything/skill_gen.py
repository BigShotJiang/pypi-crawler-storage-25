"""Generate SKILL.md from a Python API module.

Introspects a Python module to find API classes, extracts method signatures,
docstrings, and produces a SKILL.md compatible with Claude Code / OpenClaw.
"""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import re
import sys
import textwrap
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class _MethodInfo:
    """Extracted metadata for a single public method."""

    name: str
    signature: str
    doc: str
    params: list[tuple[str, str]]  # (name, annotation_str)
    return_annotation: str


@dataclass
class _ClassInfo:
    """Extracted metadata for an API class."""

    name: str
    module_name: str
    doc: str
    methods: list[_MethodInfo] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Introspection
# ---------------------------------------------------------------------------


def _load_module(module_path: str) -> Any:
    """Load a Python module from a file path or dotted module name.

    Supports both ``path/to/module.py`` and ``package.module`` forms.
    """
    p = Path(module_path)
    if p.suffix == ".py" and p.exists():
        spec = importlib.util.spec_from_file_location(p.stem, p)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot create module spec from {module_path}")
        mod = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = mod
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
        return mod

    return importlib.import_module(module_path)


def _annotation_str(annotation: Any) -> str:
    """Convert an annotation object to a readable string."""
    if annotation is inspect.Parameter.empty:
        return ""
    if isinstance(annotation, type):
        return annotation.__name__
    return str(annotation)


def _extract_methods(cls: type) -> list[_MethodInfo]:
    """Extract public method metadata from *cls*."""
    methods: list[_MethodInfo] = []
    for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
        if name.startswith("_"):
            continue
        sig = inspect.signature(method)
        doc = inspect.getdoc(method) or ""
        params: list[tuple[str, str]] = []
        for pname, param in sig.parameters.items():
            if pname == "self":
                continue
            params.append((pname, _annotation_str(param.annotation)))

        ret = _annotation_str(sig.return_annotation)
        # Build a compact signature string for the table
        param_strs = [pname for pname, _ in params]
        compact_sig = f"{name}({', '.join(param_strs)})"

        methods.append(
            _MethodInfo(
                name=name,
                signature=compact_sig,
                doc=doc,
                params=params,
                return_annotation=ret,
            )
        )
    return methods


def _find_api_class(mod: Any) -> type | None:
    """Find the main API class in a module.

    Heuristic priority:
    1. Class whose name ends with ``API``
    2. First public class with public methods
    3. None if nothing found
    """
    classes = [
        (name, cls)
        for name, cls in inspect.getmembers(mod, inspect.isclass)
        if cls.__module__ == mod.__name__ and not name.startswith("_")
    ]
    if not classes:
        return None

    # Prefer *API suffix
    for name, cls in classes:
        if name.endswith("API"):
            return cls

    # Fallback: first class with public methods
    for _, cls in classes:
        pub = [m for m in dir(cls) if not m.startswith("_") and callable(getattr(cls, m, None))]
        if pub:
            return cls

    return classes[0][1] if classes else None


def _extract_class_info(mod: Any, cls: type) -> _ClassInfo:
    """Build a ``_ClassInfo`` from a module and its main class."""
    return _ClassInfo(
        name=cls.__name__,
        module_name=mod.__name__,
        doc=inspect.getdoc(cls) or "",
        methods=_extract_methods(cls),
    )


# ---------------------------------------------------------------------------
# Trigger keyword extraction
# ---------------------------------------------------------------------------

_STOP_WORDS = frozenset([
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "shall",
    "should", "may", "might", "can", "could", "of", "in", "to", "for",
    "on", "with", "at", "by", "from", "and", "or", "not", "no",
])


def _derive_triggers(class_info: _ClassInfo) -> list[str]:
    """Derive trigger keywords from class name, docstring, and method names."""
    raw_words: list[str] = []

    # From class name: full lowered name (minus API suffix) + PascalCase split
    base_name = re.sub(r"API$", "", class_info.name)
    if base_name:
        raw_words.append(base_name.lower())
    parts = re.findall(r"[A-Z][a-z]+|[a-z]+|[A-Z]+", class_info.name)
    raw_words.extend(w.lower() for w in parts if w.lower() not in ("api",))

    # From docstring first line
    if class_info.doc:
        first_line = class_info.doc.split("\n")[0]
        raw_words.extend(
            w.lower() for w in re.findall(r"\w+", first_line) if len(w) > 2
        )

    # From method names
    for m in class_info.methods[:10]:
        raw_words.extend(m.name.split("_"))

    # Deduplicate, remove stop words, keep order
    seen: set[str] = set()
    triggers: list[str] = []
    for w in raw_words:
        if w not in seen and w not in _STOP_WORDS and len(w) > 1:
            seen.add(w)
            triggers.append(w)

    return triggers[:8]


# ---------------------------------------------------------------------------
# Example extraction
# ---------------------------------------------------------------------------

_EXAMPLE_RE = re.compile(
    r"(?:>>>|Example[s]?:?\s*\n)\s*(.+?)(?:\n\n|\n[A-Z]|\Z)",
    re.DOTALL,
)


def _extract_examples(class_info: _ClassInfo) -> list[tuple[str, str]]:
    """Extract (title, code) example pairs from method docstrings."""
    examples: list[tuple[str, str]] = []
    for m in class_info.methods:
        if not m.doc:
            continue
        # Look for >>> style or Example: style
        for match in _EXAMPLE_RE.finditer(m.doc):
            code = textwrap.dedent(match.group(1)).strip()
            if code:
                title = m.name.replace("_", " ").title()
                examples.append((title, code))
    return examples[:5]


# ---------------------------------------------------------------------------
# Markdown generation
# ---------------------------------------------------------------------------


def _render_frontmatter(class_info: _ClassInfo, triggers: list[str]) -> str:
    """Render YAML frontmatter block."""
    # Derive a short name from class (strip trailing API)
    short = re.sub(r"API$", "", class_info.name).lower() or class_info.name.lower()
    desc = class_info.doc.split("\n")[0] if class_info.doc else f"Python API for {short}"

    lines = ["---"]
    lines.append(f"name: {short}")
    lines.append(f"description: {desc}")
    lines.append("triggers:")
    for t in triggers:
        lines.append(f"  - {t}")
    lines.append("---")
    return "\n".join(lines)


def _render_method_table(methods: list[_MethodInfo]) -> str:
    """Render the Available Methods markdown table."""
    lines = [
        "| Method | Description | Key Parameters |",
        "|--------|-------------|----------------|",
    ]
    for m in methods:
        first_line = m.doc.split("\n")[0] if m.doc else ""
        params_desc = ", ".join(f"`{p[0]}`" for p in m.params) if m.params else "-"
        lines.append(f"| `{m.signature}` | {first_line} | {params_desc} |")
    return "\n".join(lines)


def _render_markdown(class_info: _ClassInfo) -> str:
    """Render the full SKILL.md body (after frontmatter)."""
    triggers = _derive_triggers(class_info)
    parts: list[str] = []

    # Frontmatter
    parts.append(_render_frontmatter(class_info, triggers))
    parts.append("")

    # Title
    short = re.sub(r"API$", "", class_info.name) or class_info.name
    parts.append(f"# {short} API")
    parts.append("")

    # Description
    if class_info.doc:
        parts.append(class_info.doc.split("\n")[0])
    parts.append("")

    # Quick Start
    parts.append("## Quick Start")
    parts.append("")
    parts.append("```python")
    parts.append(f"from {class_info.module_name} import {class_info.name}")
    parts.append("")
    # Use a short variable name
    var = short[0].lower() if short else "api"
    parts.append(f"{var} = {class_info.name}()")
    if class_info.methods:
        m0 = class_info.methods[0]
        sample_args = ", ".join(f'"{p[0]}"' for p in m0.params[:2])
        parts.append(f"{var}.{m0.name}({sample_args})")
    parts.append("```")
    parts.append("")

    # Method table
    if class_info.methods:
        parts.append("## Available Methods")
        parts.append("")
        parts.append(_render_method_table(class_info.methods))
        parts.append("")

    # Examples from docstrings
    examples = _extract_examples(class_info)
    if examples:
        parts.append("## Usage Examples")
        parts.append("")
        for title, code in examples:
            parts.append(f"### {title}")
            parts.append("```python")
            parts.append(code)
            parts.append("```")
            parts.append("")

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def generate_skill_md(
    module_path: str,
    output_path: str | None = None,
) -> str:
    """Generate SKILL.md from a Python API module.

    Introspects the module to find the main API class, extracts method
    signatures, docstrings, and generates a SKILL.md compatible with
    Claude Code / OpenClaw.

    Parameters
    ----------
    module_path:
        Path to a ``.py`` file or a dotted module name.
    output_path:
        If provided, write the SKILL.md to this path.

    Returns
    -------
    str
        The generated SKILL.md content.

    Raises
    ------
    ImportError
        If the module cannot be loaded.
    ValueError
        If no API class is found in the module.
    """
    mod = _load_module(module_path)
    cls = _find_api_class(mod)
    if cls is None:
        raise ValueError(f"No API class found in {module_path}")

    info = _extract_class_info(mod, cls)
    content = _render_markdown(info)

    if output_path is not None:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(content, encoding="utf-8")

    return content
