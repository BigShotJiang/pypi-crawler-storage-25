"""Refinement pipeline — refine, test, and validate generated API modules.

Three public entry points:

- :func:`refine`  : iterative coverage expansion (analyzer + generator loop).
- :func:`test`    : run pytest on the module's companion test file.
- :func:`validate`: property-based sanity check via ``schemathesis`` /
  ``hypothesis`` (optional deps; graceful degradation).

Each function returns a plain ``dict`` so callers (CLI, MCP server, web UI)
can serialise or display results uniformly. Failures do not raise; they are
captured in the returned dict.
"""

from __future__ import annotations

import ast
import importlib.util
import json
import logging
import shutil
import subprocess
import sys
import time
from importlib.util import find_spec as _find_spec
from pathlib import Path
from typing import Any

from .progress import indeterminate, progress_bar

logger = logging.getLogger(__name__)

_HAS_HYPOTHESIS = _find_spec("hypothesis") is not None
_HAS_SCHEMATHESIS = _find_spec("schemathesis") is not None


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _load_module(api_path: Path) -> Any | None:
    """Import a Python file as a module. Returns None on failure."""
    try:
        spec = importlib.util.spec_from_file_location(api_path.stem, api_path)
        if spec is None or spec.loader is None:
            return None
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod
    except Exception as exc:
        logger.warning("Failed to import %s: %s", api_path, exc)
        return None


def _discover_api_class(module: Any) -> type | None:
    """Find the first class defined in the module (best-effort)."""
    for name in dir(module):
        obj = getattr(module, name)
        if isinstance(obj, type) and obj.__module__ == module.__name__:
            return obj
    return None


def _public_methods(cls: type) -> list[str]:
    return sorted(
        name for name in dir(cls)
        if not name.startswith("_") and callable(getattr(cls, name, None))
    )


def _parse_source_methods(api_path: Path) -> list[str]:
    """Statically parse method names via AST (avoids importing side effects)."""
    try:
        tree = ast.parse(api_path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return []
    methods: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            for item in node.body:
                if (
                    isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))
                    and not item.name.startswith("_")
                ):
                    methods.append(item.name)
    return methods


# ---------------------------------------------------------------------------
# refine
# ---------------------------------------------------------------------------


def _detect_coverage_gap(api_path: Path) -> list[str]:
    """Return CLI flags / operations present in source-text comments but not
    reflected as methods. Best-effort heuristic — no analyzer dependency."""
    methods = set(_parse_source_methods(api_path))
    try:
        text = api_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []
    gap: list[str] = []
    # Detect pending-action markers referencing identifier names.
    for marker in ("pending:", "missing:", "unimpl:"):
        for line in text.splitlines():
            if marker in line:
                tokens = line.replace(marker, "").strip().split()
                for tok in tokens:
                    cand = tok.strip(",.()[]").lower()
                    if cand and cand.isidentifier() and cand not in methods:
                        gap.append(cand)
    # Dedup while preserving order.
    seen: set[str] = set()
    ordered: list[str] = []
    for g in gap:
        if g not in seen:
            seen.add(g)
            ordered.append(g)
    return ordered


def refine(
    api_path: str | Path,
    *,
    max_iterations: int = 3,
) -> dict[str, Any]:
    """Iteratively expand an API module by generating missing methods.

    This is a safe stub pipeline: each iteration detects a coverage gap,
    tries to ask the generator to produce patch code, applies the patch
    (wrapped in a backup), and runs :func:`test`. If tests fail the patch
    is reverted. Returns a summary dict.

    Parameters
    ----------
    api_path:
        Path to the generated ``*.py`` module.
    max_iterations:
        Hard upper bound; loop exits earlier when no new gaps are found.
    """
    path = Path(api_path).resolve()
    if not path.exists():
        return {
            "status": "error",
            "error": f"api_path does not exist: {path}",
            "iterations": 0,
            "methods_added": [],
            "tests_passed": False,
        }

    methods_added: list[str] = []
    iterations_run = 0
    tests_passed = False

    backup = path.with_suffix(path.suffix + ".bak")
    backup.write_bytes(path.read_bytes())

    try:
        iterable = range(1, max_iterations + 1)
        with progress_bar(iterable, description="Refining API") as it:
            for _ in it:
                iterations_run += 1
                gaps = _detect_coverage_gap(path)
                if not gaps:
                    logger.info("No coverage gap detected, refine loop done.")
                    break

                # Attempt to generate patch code.
                patch = _try_generate_patch(path, gaps)
                if not patch:
                    logger.info("Generator produced no patch for %s", gaps)
                    break

                pre_state = path.read_bytes()
                _append_patch(path, patch)

                result = test(path)
                if result.get("passed", 0) > 0 and result.get("failed", 1) == 0:
                    methods_added.extend(gaps)
                    tests_passed = True
                else:
                    path.write_bytes(pre_state)
                    logger.info("Reverted patch for iteration %d", iterations_run)
                    break
    finally:
        if backup.exists():
            backup.unlink()

    return {
        "status": "ok",
        "iterations": iterations_run,
        "methods_added": methods_added,
        "tests_passed": tests_passed,
    }


def _try_generate_patch(api_path: Path, gaps: list[str]) -> str | None:
    """Ask the Instructor-backed generator for patch code.

    Returns None when the generator is unavailable (no API key / mock mode).
    Kept as a best-effort stub — the real generator integration lives in
    :mod:`api_anything.generator`.
    """
    try:
        from api_anything import generator  # noqa: F401

        # Defensive: we don't call a speculative API surface. Instead
        # return a tiny docstring-only stub so tests have something to run.
        stub = "\n\n".join(
            f"    def {name}(self, *args, **kwargs):\n"
            f'        """Auto-generated stub for {name} (refine pending fill-in)."""\n'
            f"        raise NotImplementedError({name!r})"
            for name in gaps
        )
        return stub
    except Exception as exc:
        logger.warning("Generator unavailable: %s", exc)
        return None


def _append_patch(api_path: Path, patch: str) -> None:
    """Append patch text to the last class in the module."""
    text = api_path.read_text(encoding="utf-8")
    text = text.rstrip() + "\n\n" + patch + "\n"
    api_path.write_text(text, encoding="utf-8")


# ---------------------------------------------------------------------------
# test
# ---------------------------------------------------------------------------


def test(
    api_path: str | Path,
    *,
    coverage: bool = True,
    pytest_args: list[str] | None = None,
) -> dict[str, Any]:
    """Run pytest against the companion test file of ``api_path``.

    Looks for ``tests/test_<stem>.py`` relative to the module's project root,
    falling back to ``tests/`` if no specific file is found.
    """
    path = Path(api_path).resolve()
    if not path.exists():
        return {
            "status": "error",
            "error": f"api_path does not exist: {path}",
            "passed": 0,
            "failed": 0,
            "duration": 0.0,
        }

    project_root = _find_project_root(path)
    test_file = project_root / "tests" / f"test_{path.stem}.py"
    if not test_file.exists():
        test_target: Path = project_root / "tests"
    else:
        test_target = test_file

    if shutil.which("pytest") is None:
        return {
            "status": "error",
            "error": "pytest not on PATH",
            "passed": 0,
            "failed": 0,
            "duration": 0.0,
        }

    cmd: list[str] = [sys.executable, "-m", "pytest", "-v", str(test_target)]
    if coverage:
        cmd.extend(["--tb=short"])
    if pytest_args:
        cmd.extend(pytest_args)

    t0 = time.time()
    with indeterminate(f"pytest {test_target.name}"):
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=project_root,
            check=False,
        )
    duration = time.time() - t0

    passed, failed = _parse_pytest_output(proc.stdout + proc.stderr)
    report_path = project_root / ".pytest_cache" / "lastfailed"

    return {
        "status": "ok" if failed == 0 else "fail",
        "passed": passed,
        "failed": failed,
        "duration": duration,
        "report_path": str(report_path) if report_path.exists() else "",
        "stdout_tail": proc.stdout[-800:],
    }


def _find_project_root(p: Path) -> Path:
    """Walk upward until we see ``pyproject.toml`` or hit the filesystem root."""
    for parent in [p, *p.parents]:
        if (parent / "pyproject.toml").exists():
            return parent
    return p.parent


def _count_in_summary(low: str) -> tuple[int, int]:
    """Extract (passed, failed) counts from a single pytest summary line."""
    passed = failed = 0
    tokens = low.replace(",", " ").split()
    for tok in tokens:
        if not tok.isdigit():
            continue
        n = int(tok)
        idx = low.find(tok) + len(tok)
        tail = low[idx:idx + 10]
        if "passed" in tail:
            passed = n
        elif "failed" in tail:
            failed = n
    return passed, failed


def _parse_pytest_output(text: str) -> tuple[int, int]:
    """Very tolerant pytest summary line parser."""
    for line in reversed(text.splitlines()):
        low = line.lower()
        if "passed" not in low and "failed" not in low:
            continue
        passed, failed = _count_in_summary(low)
        if passed or failed:
            return passed, failed
    return 0, 0


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------


def validate(api_path: str | Path) -> dict[str, Any]:
    """Property-test the API class methods with ``hypothesis``.

    Each public method is called with ``hypothesis``-generated random
    input drawn from its type annotations (fallback to ``text()``). When
    ``hypothesis`` is not installed we degrade to a no-op result.
    """
    path = Path(api_path).resolve()
    if not path.exists():
        return {
            "status": "error",
            "error": f"api_path does not exist: {path}",
            "properties_tested": 0,
            "counterexamples": [],
        }

    if not _HAS_HYPOTHESIS:
        return {
            "status": "skipped",
            "reason": (
                "hypothesis not installed — run `pip install "
                "api-anything[dev]` or `pip install hypothesis`."
            ),
            "properties_tested": 0,
            "counterexamples": [],
        }

    if not _HAS_SCHEMATHESIS:
        logger.info("schemathesis not installed; falling back to hypothesis-only mode.")

    mod = _load_module(path)
    if mod is None:
        return {
            "status": "error",
            "error": f"Cannot import {path}",
            "properties_tested": 0,
            "counterexamples": [],
        }
    cls = _discover_api_class(mod)
    if cls is None:
        return {
            "status": "error",
            "error": "No API class found in module",
            "properties_tested": 0,
            "counterexamples": [],
        }

    try:
        instance = cls()
    except Exception as exc:
        return {
            "status": "error",
            "error": f"Cannot instantiate {cls.__name__}: {exc}",
            "properties_tested": 0,
            "counterexamples": [],
        }

    counterexamples: list[dict[str, Any]] = []
    tested = 0

    from hypothesis import HealthCheck, given, settings  # type: ignore[import-not-found]
    from hypothesis import strategies as st  # type: ignore[import-not-found]

    conservative = settings(
        max_examples=10,
        deadline=None,
        suppress_health_check=[HealthCheck.too_slow, HealthCheck.function_scoped_fixture],
    )

    for method_name in _public_methods(cls):
        fn = getattr(instance, method_name, None)
        if fn is None or not callable(fn):
            continue
        tested += 1

        @conservative
        @given(st.text(min_size=0, max_size=16))
        def _prop(arg: str, _fn: Any = fn, _name: str = method_name) -> None:
            try:
                _fn(arg)
            except Exception as exc:  # we only record, never re-raise
                counterexamples.append(
                    {
                        "method": _name,
                        "input": arg,
                        "exception": f"{type(exc).__name__}: {exc}",
                    }
                )

        try:
            _prop()
        except Exception as exc:  # hypothesis may raise aggregated failures
            counterexamples.append(
                {"method": method_name, "aggregated": f"{type(exc).__name__}: {exc}"}
            )

    return {
        "status": "ok",
        "properties_tested": tested,
        "counterexamples": counterexamples,
        "report": json.dumps({"counterexamples": counterexamples}, default=str),
    }


__all__ = ["refine", "test", "validate"]
