"""Stdin/stdout pipe runner for ``api-anything run`` style invocations.

Enables ergonomic Unix pipelines::

    cat data.json | api-anything run jq query '.field'
    echo "hello" | api-anything run pandoc convert --from md --to html

The runner detects a piped stdin, feeds its payload as the first positional
argument to the target method, executes the method, and writes the result to
stdout using type-aware formatting:

- ``str``   -> raw text (adds trailing newline when interactive)
- ``bytes`` -> base64 payload on stdout (safe for pipelines)
- ``dict``/``list`` -> ``json.dumps`` with ``ensure_ascii=False``
- other objects -> ``repr`` fallback

Exit codes: 0 = success, 1 = load/exec failure, 2 = user error (bad args).
"""

from __future__ import annotations

import base64
import importlib
import inspect
import json
import sys
from typing import Any

from rich.console import Console


def _resolve_api(api: str) -> Any:
    """Return an instantiated API object from a registry name or file path."""
    from api_anything.apis import _REGISTRY

    lowered = api.lower()
    registry_hit = next(
        (k for k in _REGISTRY if k.lower() == lowered),
        None,
    )
    if registry_hit is not None:
        mod_path, cls_name = _REGISTRY[registry_hit]
        mod = importlib.import_module(mod_path)
        cls = getattr(mod, cls_name)
        return cls()

    # Fallback: treat ``api`` as a .py path (delegates to repl helpers).
    from api_anything.repl import build_loaded_api, load_module_from_path

    module = load_module_from_path(api)
    loaded = build_loaded_api(module, api)
    return loaded.instance


def _read_stdin_if_piped() -> str | None:
    """Return stdin text when data is piped, else None."""
    if sys.stdin.isatty():
        return None
    try:
        data = sys.stdin.read()
    except (OSError, ValueError):
        return None
    return data if data else None


def _coerce_arg(raw: str) -> Any:
    """Best-effort coerce a CLI positional into a typed value.

    Tries JSON first (supports numbers, booleans, null, quoted strings,
    objects, arrays); falls back to the raw string otherwise.
    """
    stripped = raw.strip()
    if not stripped:
        return raw
    try:
        return json.loads(stripped)
    except (ValueError, TypeError):
        return raw


def _format_output(result: Any) -> str:
    """Serialise a method result for stdout pipeline use."""
    if result is None:
        return ""
    if isinstance(result, str):
        return result
    if isinstance(result, bytes):
        return base64.b64encode(result).decode("ascii")
    if isinstance(result, (dict, list, tuple, int, float, bool)):
        try:
            return json.dumps(result, ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            return repr(result)
    return repr(result)


def run_with_pipe(api: str, method: str, argv: list[str]) -> int:
    """Invoke ``api.method(*argv)`` with piped stdin as the first argument.

    Parameters
    ----------
    api:
        Registry name (``"FFmpeg"``) or filesystem path to a Python module.
    method:
        Public method name on the API class.
    argv:
        Extra positional arguments from the CLI (strings).

    Returns
    -------
    int
        Shell exit code.
    """
    console = Console(stderr=True)
    try:
        instance = _resolve_api(api)
    except Exception as exc:
        console.print(f"[red]Failed to load API {api!r}: {exc}[/red]")
        return 1

    func = getattr(instance, method, None)
    if func is None or not callable(func):
        console.print(
            f"[red]Method {method!r} not found on {api!r}.[/red]"
        )
        return 2

    piped = _read_stdin_if_piped()
    positional: list[Any] = []
    if piped is not None:
        positional.append(piped)
    positional.extend(_coerce_arg(a) for a in argv)

    # Align positional list with the signature so extra args trigger
    # a clearer error than an opaque TypeError.
    try:
        sig = inspect.signature(func)
        # Count non-var-positional params (minus self which is already bound).
        positional_params = [
            p for p in sig.parameters.values()
            if p.kind in (
                inspect.Parameter.POSITIONAL_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            )
        ]
        max_pos = len(positional_params)
        has_varargs = any(
            p.kind is inspect.Parameter.VAR_POSITIONAL
            for p in sig.parameters.values()
        )
        if not has_varargs and len(positional) > max_pos:
            positional = positional[:max_pos]
    except (TypeError, ValueError):
        # Builtins / C extensions without introspectable signatures: pass
        # through untouched.
        pass

    try:
        result = func(*positional)
    except Exception as exc:
        console.print(f"[red]{method} raised {type(exc).__name__}: {exc}[/red]")
        return 1

    out = _format_output(result)
    if out:
        # Preserve binary-safe output: avoid adding extra newlines when
        # stdout is a pipe, but keep human-friendly newline on a TTY.
        if sys.stdout.isatty() and not out.endswith("\n"):
            out += "\n"
        sys.stdout.write(out)
        sys.stdout.flush()
    return 0


__all__ = ["run_with_pipe"]
