# ruff: noqa: RUF001, RUF002, RUF003
"""UIA Control Pattern to method template mapping (RFC v0.3 M0).

將 22 個 Microsoft UI Automation control patterns 對應到 generator 可 render
的 method template。v0.2 的 `control_type → method_prefix` dispatch 只看
`ControlTypeName`（Button / TextBox / Menu / ...），對 ComboBox 類同時支援多
pattern 的 control 覆蓋率不足；v0.3 M0 改為 pattern-first dispatch，
Tier 2A/3A 的生成信心從 60-70% 提到 85%+。

參考：
- `docs/v0.3_sota_notes.md` §4（UIA 高階 Pattern 完整清單）
- `RFC_v0.3_api_generation.md` §C（改造設計）
- Microsoft Docs: UI Automation Control Patterns Overview

⚠ 本 module **純純函式 + 常數**，不 import `uiautomation`，所有 body 都是
字串模板，由 `generator._render_method` 在 render 階段代入。執行期的實際
UIA 呼叫在 generated code 內部用 `uiautomation` 套件（透過 try/except
import 保護）。
"""

from __future__ import annotations

from typing import TypedDict

# ---------------------------------------------------------------------------
# 核心型別
# ---------------------------------------------------------------------------


class PatternTemplate(TypedDict, total=False):
    """單一 UIA pattern 的 method template 描述。

    欄位：
        methods: 該 pattern 會衍生出的 method 列表。每個 dict 含：
            verb         — method name 前綴動詞（e.g. "click", "set", "toggle"）
            suffix_mode  — "name" 用 control name；"fixed" 用固定字（罕用）
            params       — list[dict(name, type_hint, default)]，空代表無參數
            body         — Python code 片段（會被 `str.format(name=...)` 展開）
            return_type  — 字串型別註解
            confidence   — 0-100，該 template 的生成信心
        priority: 當多 pattern 同時支援時決定 dispatch 順序（數字大者優先）。
        notes: 人類可讀的一句話說明（docstring 或 log 用）。
    """

    methods: list[dict]
    priority: int
    notes: str


# ---------------------------------------------------------------------------
# 22 UIA Pattern 對應表
# ---------------------------------------------------------------------------
# NOTE: priority 採「常用度 + API 信心度」的經驗值：
#   - Value (90)：setter + getter 是最常需求，優先最高
#   - Toggle (85)：布林狀態機械，信心高
#   - Invoke (80)：Button 預設動作，信心高但資訊量低
#   - RangeValue (75)：Slider/Spinner 明確值域
#   - ExpandCollapse (70)：Menu / TreeItem 樹狀展開
#   - SelectionItem (65) / Selection (60)：list item 選取
#   - Scroll/ScrollItem (50)：可視區域操作
#   - Text (45)：唯讀居多
#   - Grid/Table (40-42)：結構資料
#   - Transform/Window (35-38)：版面 / 視窗層級
#   - 其餘罕用：20-30
# 若 generator 遇到多 pattern，依 priority desc 排序取第一個（或全部生成）。

UIA_PATTERN_METHOD_TEMPLATES: dict[str, PatternTemplate] = {
    # -------------------------------------------------------------------
    # 一線常用 Pattern（高信心，必然實作）
    # -------------------------------------------------------------------
    "InvokePattern": {
        "methods": [
            {
                "verb": "invoke",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetInvokePattern().Invoke()"
                ),
                "confidence": 88,
            }
        ],
        "priority": 80,
        "notes": "Button / 單次動作觸發（Invoke = 執行 control 的 default action）。",
    },
    "ValuePattern": {
        "methods": [
            {
                "verb": "set",
                "suffix_mode": "name",
                "params": [
                    {"name": "value", "type_hint": "str", "default": None},
                ],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetValuePattern().SetValue(value)"
                ),
                "confidence": 90,
            },
            {
                "verb": "get",
                "suffix_mode": "name",
                "params": [],
                "return_type": "str",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "return control.GetValuePattern().Value"
                ),
                "confidence": 90,
            },
        ],
        "priority": 90,
        "notes": "TextBox / Edit / DatePicker — SetValue 比 SendKeys 穩（中英文不漏字）。",
    },
    "TogglePattern": {
        "methods": [
            {
                "verb": "toggle",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetTogglePattern().Toggle()"
                ),
                "confidence": 88,
            },
            {
                "verb": "is",
                "suffix_mode": "name",
                "params": [],
                "return_type": "bool",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "state = control.GetTogglePattern().ToggleState\n"
                    "return bool(state)  # ToggleState.On == 1"
                ),
                "confidence": 85,
            },
        ],
        "priority": 85,
        "notes": "CheckBox / 可切換 MenuItem — Toggle + state query。",
    },
    "RangeValuePattern": {
        "methods": [
            {
                "verb": "set",
                "suffix_mode": "name",
                "params": [
                    {"name": "value", "type_hint": "float", "default": None},
                ],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetRangeValuePattern().SetValue(value)"
                ),
                "confidence": 85,
            },
            {
                "verb": "get",
                "suffix_mode": "name",
                "params": [],
                "return_type": "float",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "return float(control.GetRangeValuePattern().Value)"
                ),
                "confidence": 85,
            },
        ],
        "priority": 75,
        "notes": "Slider / Spinner — min/max 範圍內的數值。",
    },
    "ExpandCollapsePattern": {
        "methods": [
            {
                "verb": "expand",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetExpandCollapsePattern().Expand()"
                ),
                "confidence": 82,
            },
            {
                "verb": "collapse",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetExpandCollapsePattern().Collapse()"
                ),
                "confidence": 82,
            },
        ],
        "priority": 70,
        "notes": "Menu / TreeItem / ComboBox — 展開或收合。",
    },
    "SelectionItemPattern": {
        "methods": [
            {
                "verb": "select",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetSelectionItemPattern().Select()"
                ),
                "confidence": 80,
            },
        ],
        "priority": 65,
        "notes": "ListItem / ComboBoxItem — 選取單一項目。",
    },
    "SelectionPattern": {
        "methods": [
            {
                "verb": "select",
                "suffix_mode": "name",
                "params": [
                    {"name": "option", "type_hint": "str", "default": None},
                ],
                "return_type": "None",
                "body": (
                    "container = self._locate_control({locator!r})\n"
                    "for child in container.GetChildren():\n"
                    "    if (child.Name or '') == option:\n"
                    "        child.GetSelectionItemPattern().Select()\n"
                    "        return\n"
                    "raise LookupError(f'Selection option not found: {{option}}')"
                ),
                "confidence": 75,
            },
        ],
        "priority": 60,
        "notes": "ListBox / ComboBox container — 在子項中依名稱選取。",
    },
    # -------------------------------------------------------------------
    # 二線 Pattern（中信心，常見但不是第一手動作）
    # -------------------------------------------------------------------
    "ScrollPattern": {
        "methods": [
            {
                "verb": "scroll",
                "suffix_mode": "name",
                "params": [
                    {
                        "name": "horizontal_percent",
                        "type_hint": "float",
                        "default": "-1.0",
                    },
                    {
                        "name": "vertical_percent",
                        "type_hint": "float",
                        "default": "-1.0",
                    },
                ],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetScrollPattern().SetScrollPercent("
                    "horizontal_percent, vertical_percent)"
                ),
                "confidence": 72,
            },
        ],
        "priority": 50,
        "notes": "可捲動容器 — 0-100 百分比，-1 代表不改。",
    },
    "ScrollItemPattern": {
        "methods": [
            {
                "verb": "scroll_into_view",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetScrollItemPattern().ScrollIntoView()"
                ),
                "confidence": 75,
            },
        ],
        "priority": 50,
        "notes": "list / tree item — 捲到可見。",
    },
    "TextPattern": {
        "methods": [
            {
                "verb": "get_text",
                "suffix_mode": "name",
                "params": [],
                "return_type": "str",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "return control.GetTextPattern().DocumentRange.GetText(-1)"
                ),
                "confidence": 78,
            },
        ],
        "priority": 45,
        "notes": "RichEdit / Document — 讀取文字內容（唯讀）。",
    },
    "GridPattern": {
        "methods": [
            {
                "verb": "get_cell",
                "suffix_mode": "name",
                "params": [
                    {"name": "row", "type_hint": "int", "default": None},
                    {"name": "col", "type_hint": "int", "default": None},
                ],
                "return_type": "str",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "item = control.GetGridPattern().GetItem(row, col)\n"
                    "return item.Name or ''"
                ),
                "confidence": 70,
            },
        ],
        "priority": 42,
        "notes": "Grid 表格 — 依行列索引取格。",
    },
    "TablePattern": {
        "methods": [
            {
                "verb": "get_row_headers",
                "suffix_mode": "name",
                "params": [],
                "return_type": "list[str]",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "pattern = control.GetTablePattern()\n"
                    "return [h.Name or '' for h in pattern.GetRowHeaders()]"
                ),
                "confidence": 65,
            },
        ],
        "priority": 40,
        "notes": "含 header 的 table — 取 row header。",
    },
    "TransformPattern": {
        "methods": [
            {
                "verb": "move",
                "suffix_mode": "name",
                "params": [
                    {"name": "x", "type_hint": "float", "default": None},
                    {"name": "y", "type_hint": "float", "default": None},
                ],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetTransformPattern().Move(x, y)"
                ),
                "confidence": 68,
            },
            {
                "verb": "resize",
                "suffix_mode": "name",
                "params": [
                    {"name": "width", "type_hint": "float", "default": None},
                    {"name": "height", "type_hint": "float", "default": None},
                ],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetTransformPattern().Resize(width, height)"
                ),
                "confidence": 68,
            },
        ],
        "priority": 38,
        "notes": "可拖移 / 縮放元素。",
    },
    "WindowPattern": {
        "methods": [
            {
                "verb": "maximize",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "import uiautomation as _uia\n"
                    "control.GetWindowPattern().SetWindowVisualState("
                    "_uia.WindowVisualState.Maximized)"
                ),
                "confidence": 75,
            },
            {
                "verb": "minimize",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "import uiautomation as _uia\n"
                    "control.GetWindowPattern().SetWindowVisualState("
                    "_uia.WindowVisualState.Minimized)"
                ),
                "confidence": 75,
            },
            {
                "verb": "close",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetWindowPattern().Close()"
                ),
                "confidence": 78,
            },
        ],
        "priority": 35,
        "notes": "頂層視窗 / dialog — 視窗狀態控制。",
    },
    # -------------------------------------------------------------------
    # 三線罕用 Pattern（stub，body NotImplementedError）
    # -------------------------------------------------------------------
    "DockPattern": {
        "methods": [
            {
                "verb": "set_dock",
                "suffix_mode": "name",
                "params": [
                    {"name": "position", "type_hint": "str", "default": None},
                ],
                "return_type": "None",
                "body": (
                    "raise NotImplementedError("
                    "'DockPattern generation pending (RFC v0.3 M0 stub)'"
                    ")"
                ),
                "confidence": 40,
            },
        ],
        "priority": 25,
        "notes": "toolbar / tool palette docking 位置（罕用，v0.3 M0 stub）。",
    },
    "MultipleViewPattern": {
        "methods": [
            {
                "verb": "set_view",
                "suffix_mode": "name",
                "params": [
                    {"name": "view_id", "type_hint": "int", "default": None},
                ],
                "return_type": "None",
                "body": (
                    "raise NotImplementedError("
                    "'MultipleViewPattern generation pending (RFC v0.3 M0 stub)'"
                    ")"
                ),
                "confidence": 40,
            },
        ],
        "priority": 22,
        "notes": "list view 切視圖（圖示/清單/細節，罕用，v0.3 M0 stub）。",
    },
    "VirtualizedItemPattern": {
        "methods": [
            {
                "verb": "realize",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "raise NotImplementedError("
                    "'VirtualizedItemPattern unsupported by uiautomation package "
                    "(no GetVirtualizedItemPattern); v0.3 M0 stub'"
                    ")"
                ),
                "confidence": 35,
            },
        ],
        "priority": 30,
        "notes": "虛擬列表項 — uiautomation 套件未 wrap，v0.3 M0 stub（必須 NotImpl）。",
    },
    "ItemContainerPattern": {
        "methods": [
            {
                "verb": "find_item",
                "suffix_mode": "name",
                "params": [
                    {"name": "property_id", "type_hint": "int", "default": None},
                    {"name": "value", "type_hint": "str", "default": None},
                ],
                "return_type": "object",
                "body": (
                    "raise NotImplementedError("
                    "'ItemContainerPattern generation pending (RFC v0.3 M0 stub)'"
                    ")"
                ),
                "confidence": 40,
            },
        ],
        "priority": 28,
        "notes": "virtual container — 未實體化找 item（罕用，v0.3 M0 stub）。",
    },
    "LegacyIAccessiblePattern": {
        "methods": [
            {
                "verb": "default_action",
                "suffix_mode": "name",
                "params": [],
                "return_type": "None",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "control.GetLegacyIAccessiblePattern().DoDefaultAction()"
                ),
                "confidence": 60,
            },
        ],
        "priority": 20,
        "notes": "舊 MSAA 控制的最後退路 — DoDefaultAction()。",
    },
    "SynchronizedInputPattern": {
        "methods": [
            {
                "verb": "start_listening",
                "suffix_mode": "name",
                "params": [
                    {
                        "name": "input_type",
                        "type_hint": "int",
                        "default": None,
                    }
                ],
                "return_type": "None",
                "body": (
                    "raise NotImplementedError("
                    "'SynchronizedInputPattern generation pending (RFC v0.3 M0 stub)'"
                    ")"
                ),
                "confidence": 35,
            },
        ],
        "priority": 18,
        "notes": "同步輸入擷取（罕用，v0.3 M0 stub）。",
    },
    # GridItem / TableItem — pattern 存在但 API 多是讀屬性（Row/Column），
    # 沒 imperative method，list 出來方便 diagnose() 盤點，body 為 stub。
    "GridItemPattern": {
        "methods": [
            {
                "verb": "get_grid_coords",
                "suffix_mode": "name",
                "params": [],
                "return_type": "tuple",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "p = control.GetGridItemPattern()\n"
                    "return (p.Row, p.Column, p.RowSpan, p.ColumnSpan)"
                ),
                "confidence": 60,
            },
        ],
        "priority": 32,
        "notes": "Grid cell — 讀 Row/Column 位置屬性。",
    },
    "TableItemPattern": {
        "methods": [
            {
                "verb": "get_column_header",
                "suffix_mode": "name",
                "params": [],
                "return_type": "list[str]",
                "body": (
                    "control = self._locate_control({locator!r})\n"
                    "items = control.GetTableItemPattern().GetColumnHeaderItems()\n"
                    "return [h.Name or '' for h in items]"
                ),
                "confidence": 55,
            },
        ],
        "priority": 30,
        "notes": "Table cell — 取對應 column header。",
    },
}


# 對外公開常數：支援的 pattern 名稱集合（驗證用）
SUPPORTED_PATTERNS: frozenset[str] = frozenset(UIA_PATTERN_METHOD_TEMPLATES.keys())


# ---------------------------------------------------------------------------
# Dispatch helpers
# ---------------------------------------------------------------------------


def select_primary_pattern(patterns: list[str] | None) -> str | None:
    """從 control 支援的 pattern list 中選出主 pattern。

    規則：過濾出 `SUPPORTED_PATTERNS` 內的 pattern，依 `priority` 降序取第一個。
    多 pattern tie → list 出現順序為 tie-breaker。

    Args:
        patterns: 例如 ``["InvokePattern", "ExpandCollapsePattern"]``

    Returns:
        最佳 pattern 名稱；若 list 空 / 全不支援 → ``None``。
    """
    if not patterns:
        return None

    known = [p for p in patterns if p in SUPPORTED_PATTERNS]
    if not known:
        return None

    # priority desc，stable sort → list 出現順序為 tie-breaker
    known.sort(key=lambda p: UIA_PATTERN_METHOD_TEMPLATES[p]["priority"], reverse=True)
    return known[0]


def get_template(pattern_name: str) -> PatternTemplate | None:
    """查詢 pattern template。不存在回 None。"""
    return UIA_PATTERN_METHOD_TEMPLATES.get(pattern_name)


def list_patterns_for_control(patterns: list[str] | None) -> list[str]:
    """回傳 control 支援且本 module 認得的 pattern，依 priority 降序。"""
    if not patterns:
        return []
    known = [p for p in patterns if p in SUPPORTED_PATTERNS]
    known.sort(key=lambda p: UIA_PATTERN_METHOD_TEMPLATES[p]["priority"], reverse=True)
    return known


# ---------------------------------------------------------------------------
# Legacy control_type → pattern hint（向下相容 v0.2 mock controls）
# ---------------------------------------------------------------------------
# 當 UIControl.patterns 為 None/空（舊資料 / 未探測），generator 仍需 dispatch。
# 依 control_type 推 one 個最可能的 pattern，方便走 v0.3 新路徑同時保持 v0.2
# 舊測試對 method 名稱的期望（click_save / set_file_name / toggle_dark_mode ...）。

_CONTROL_TYPE_TO_PATTERN: dict[str, str] = {
    "Button": "InvokePattern",
    "TextBox": "ValuePattern",
    "Edit": "ValuePattern",
    "CheckBox": "TogglePattern",
    "Slider": "RangeValuePattern",
    "Spinner": "RangeValuePattern",
    "Menu": "ExpandCollapsePattern",
    "MenuItem": "InvokePattern",
    "TreeItem": "ExpandCollapsePattern",
    "ListItem": "SelectionItemPattern",
    "ComboBox": "ExpandCollapsePattern",
    "Window": "WindowPattern",
    "Document": "TextPattern",
}


def infer_pattern_from_control_type(control_type: str) -> str | None:
    """從 control_type 推主 pattern（當 `patterns` 欄位缺）。"""
    return _CONTROL_TYPE_TO_PATTERN.get(control_type)
