"""Shell completion script generator for ``api-anything``.

Produces a completion script for Bash, Zsh, or Fish by introspecting the
argparse tree built by :func:`api_anything.cli._build_parser`.

Usage::

    api-anything completions bash >> ~/.bashrc
    api-anything completions zsh  > _api-anything
    api-anything completions fish > ~/.config/fish/completions/api-anything.fish

The generated scripts also resolve the list of built-in API names at runtime
by spawning ``api-anything list`` (falling back to a hard-coded snapshot),
so new APIs appear in completions automatically.
"""

from __future__ import annotations

import argparse
from typing import Any

_SUPPORTED_SHELLS = ("bash", "zsh", "fish")


# ---------------------------------------------------------------------------
# Introspection
# ---------------------------------------------------------------------------


def _subparsers(parser: argparse.ArgumentParser) -> dict[str, argparse.ArgumentParser]:
    """Return ``{subcommand_name: subparser}`` for the given parser."""
    found: dict[str, argparse.ArgumentParser] = {}
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            for name, sub in action.choices.items():
                found[name] = sub
    return found


def _options(parser: argparse.ArgumentParser) -> list[str]:
    """Collect all long/short options defined on the parser."""
    opts: list[str] = []
    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            continue
        for opt in action.option_strings:
            opts.append(opt)
    return sorted(set(opts))


def _registry_names_snapshot() -> list[str]:
    """Return current registry names (snapshot used as bash fallback)."""
    try:
        from api_anything.apis import _REGISTRY

        return sorted(_REGISTRY.keys())
    except Exception:
        return []


# ---------------------------------------------------------------------------
# Generators per shell
# ---------------------------------------------------------------------------


def _gen_bash(parser: argparse.ArgumentParser) -> str:
    subs = _subparsers(parser)
    sub_names = " ".join(sorted(subs))
    api_names = " ".join(_registry_names_snapshot())

    blocks: list[str] = []
    for name, sub in sorted(subs.items()):
        opts = " ".join(_options(sub))
        blocks.append(
            f'        {name})\n'
            f'            COMPREPLY=( $(compgen -W "{opts}" -- "$cur") )\n'
            f'            return 0\n'
            f'            ;;'
        )
    per_sub_block = "\n".join(blocks)

    return f"""# api-anything bash completion
_api_anything_complete() {{
    local cur prev words cword
    _init_completion || return

    local subcommands="{sub_names}"
    local apis
    if command -v api-anything >/dev/null 2>&1; then
        apis=$(api-anything list 2>/dev/null | awk 'NR>2 && $1 !~ /^-/ {{print $1}}' | tr -d '[]')
    fi
    if [[ -z "$apis" ]]; then
        apis="{api_names}"
    fi

    if [[ ${{cword}} -eq 1 ]]; then
        COMPREPLY=( $(compgen -W "$subcommands" -- "$cur") )
        return 0
    fi

    case "${{words[1]}}" in
{per_sub_block}
    esac
}}
complete -F _api_anything_complete api-anything
"""


def _gen_zsh(parser: argparse.ArgumentParser) -> str:
    subs = _subparsers(parser)
    lines: list[str] = [
        "#compdef api-anything",
        "",
        "_api_anything() {",
        "    local -a subcommands",
        "    subcommands=(",
    ]
    for name, sub in sorted(subs.items()):
        help_text = (sub.description or sub.prog or name).replace("'", "")
        lines.append(f"        '{name}:{help_text}'")
    lines.extend([
        "    )",
        "",
        "    _arguments -C \\",
        "        '1: :->command' \\",
        "        '*::arg:->args'",
        "",
        "    case $state in",
        "        command)",
        "            _describe -t commands 'api-anything command' subcommands",
        "            ;;",
        "        args)",
        "            case $line[1] in",
    ])
    for name, sub in sorted(subs.items()):
        opts = _options(sub)
        if not opts:
            lines.append(f"                {name}) ;;")
            continue
        opt_list = " ".join(f"'{o}'" for o in opts)
        lines.append(
            f"                {name})\n"
            f"                    _arguments {opt_list}\n"
            f"                    ;;"
        )
    lines.extend([
        "            esac",
        "            ;;",
        "    esac",
        "}",
        "",
        "_api_anything \"$@\"",
    ])
    return "\n".join(lines) + "\n"


def _gen_fish(parser: argparse.ArgumentParser) -> str:
    subs = _subparsers(parser)
    lines: list[str] = [
        "# api-anything fish completion",
        "complete -c api-anything -f",
    ]
    # Top-level: require no-subcommand-seen.
    sub_names = " ".join(sorted(subs))
    for name, sub in sorted(subs.items()):
        desc = (sub.description or name).replace("'", "")
        lines.append(
            f"complete -c api-anything -n \"not __fish_seen_subcommand_from {sub_names}\" "
            f"-a '{name}' -d '{desc}'"
        )

    for name, sub in sorted(subs.items()):
        for action in sub._actions:
            if isinstance(action, argparse._SubParsersAction):
                continue
            opts = action.option_strings
            if not opts:
                continue
            desc = (action.help or "").replace("'", "")
            long_opt = next(
                (o for o in opts if o.startswith("--")), None
            )
            short_opt = next(
                (o for o in opts if o.startswith("-") and not o.startswith("--")),
                None,
            )
            flag_parts: list[str] = []
            if long_opt:
                flag_parts.extend(["-l", long_opt.lstrip("-")])
            if short_opt:
                flag_parts.extend(["-s", short_opt.lstrip("-")])
            flag_str = " ".join(flag_parts)
            lines.append(
                f"complete -c api-anything -n \"__fish_seen_subcommand_from {name}\" "
                f"{flag_str} -d '{desc}'"
            )
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def generate(shell: str, parser: argparse.ArgumentParser | None = None) -> str:
    """Return a completion script for ``shell``.

    Parameters
    ----------
    shell:
        One of ``"bash"``, ``"zsh"``, ``"fish"``.
    parser:
        Optional argparse parser; defaults to the live ``api-anything`` parser.

    Raises
    ------
    ValueError
        If ``shell`` is not supported.
    """
    if shell not in _SUPPORTED_SHELLS:
        raise ValueError(
            f"Unsupported shell {shell!r}. Choose from {_SUPPORTED_SHELLS}."
        )

    if parser is None:
        from api_anything.cli import _build_parser  # local import to dodge cycles

        parser = _build_parser()

    if shell == "bash":
        return _gen_bash(parser)
    if shell == "zsh":
        return _gen_zsh(parser)
    return _gen_fish(parser)


def supported_shells() -> tuple[str, ...]:
    """Return the tuple of shells this module can generate completions for."""
    return _SUPPORTED_SHELLS


__all__ = ["generate", "supported_shells"]

# Silence "Any imported but unused" — kept for forward extensions.
_ = Any
