"""Enterprise-grade Gradio Web UI for API-Anything.

Provides a four-tab interface:
  1. Dashboard  -- product landing page with stats and API overview
  2. Tier Detection -- detect feasibility tier for any software
  3. API Explorer -- browse built-in APIs, inspect methods, try them live
  4. Generate -- preview of future code-generation capability

Launch via CLI:  ``api-anything web [--port 7860] [--share]``
Or directly:     ``python -m api_anything.web``
"""

from __future__ import annotations

import importlib
import inspect
import traceback
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import gradio as gr

# ---------------------------------------------------------------------------
# Custom CSS
# ---------------------------------------------------------------------------

_CSS = """
.gradio-container { max-width: 1400px !important; margin: 0 auto; }

.main-header {
    text-align: center; margin-bottom: 2rem;
    padding: 2.5rem 1rem 1.5rem;
}
.main-header h1 {
    font-size: 2.8rem; font-weight: 800; letter-spacing: -0.02em;
    background: linear-gradient(135deg, #60a5fa 0%, #a78bfa 50%, #60a5fa 100%);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    background-clip: text; margin-bottom: 0.5rem;
}
.main-header .tagline {
    font-size: 1.15rem; color: #94a3b8; font-weight: 400;
}

.stat-card {
    background: linear-gradient(135deg, #1e3a5f 0%, #0f172a 100%);
    border-radius: 12px; padding: 1.5rem; text-align: center;
    border: 1px solid #334155;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
}
.stat-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 24px rgba(96, 165, 250, 0.12);
}
.stat-number {
    font-size: 2.5rem; font-weight: 700;
    color: #60a5fa; line-height: 1.1;
}
.stat-label {
    font-size: 0.9rem; color: #94a3b8; margin-top: 0.5rem;
}

.section-header {
    font-size: 1.3rem; font-weight: 600; color: #1e293b;
    margin: 1.5rem 0 0.75rem; padding-bottom: 0.5rem;
    border-bottom: 1px solid #cbd5e1;
}
.dark .section-header { color: #e2e8f0; border-bottom-color: #334155; }

.tier-report { font-family: 'JetBrains Mono', monospace; line-height: 1.7; }
.tier-report h2 { color: #60a5fa; }
.tier-report .pass { color: #4ade80; font-weight: 600; }
.tier-report .fail { color: #f87171; }
.tier-report .verdict-box {
    border-left: 3px solid #60a5fa; padding: 0.75rem 1rem;
    margin: 1rem 0; background: rgba(96, 165, 250, 0.06);
    border-radius: 0 8px 8px 0;
}

.api-table { border-radius: 8px; overflow: hidden; }

.code-snippet {
    background: #0f172a; border: 1px solid #334155;
    border-radius: 8px; padding: 1.25rem;
    font-family: 'JetBrains Mono', monospace;
    font-size: 0.875rem; line-height: 1.6;
    color: #e2e8f0; overflow-x: auto;
}

.explorer-info {
    border: 1px solid #334155; border-radius: 8px;
    padding: 1rem 1.25rem; background: rgba(15, 23, 42, 0.4);
    margin-bottom: 0.75rem;
}

.app-footer {
    text-align: center; padding: 1.5rem 0 0.5rem;
    color: #64748b; font-size: 0.85rem;
    border-top: 1px solid #1e293b; margin-top: 2rem;
}

.coming-soon-badge {
    display: inline-block; padding: 0.25rem 0.75rem;
    background: linear-gradient(135deg, #1e3a5f, #312e81);
    border: 1px solid #4338ca; border-radius: 16px;
    font-size: 0.8rem; font-weight: 600;
    color: #a5b4fc; letter-spacing: 0.05em;
}

.tab-nav button {
    font-weight: 600 !important; font-size: 0.95rem !important;
}
"""

# ---------------------------------------------------------------------------
# Helpers -- Registry & Inspection
# ---------------------------------------------------------------------------

_API_META: dict[str, dict[str, str]] = {
    "FFmpeg": {"tier": "2A", "desc": "Video/audio conversion, trimming, compression"},
    "Git": {"tier": "2A", "desc": "Git version control operations"},
    "Docker": {"tier": "2A", "desc": "Container management"},
    "SQLite": {"tier": "1", "desc": "Database operations (stdlib)"},
    "ImageMagick": {"tier": "2A", "desc": "Image processing and conversion"},
    "Pandoc": {"tier": "2A", "desc": "Document format conversion"},
    "LibreOfficeWriter": {"tier": "2A", "desc": "Document creation and export"},
    "Notepad": {"tier": "3A", "desc": "Windows Notepad control (UIA)"},
    # --- v0.1 expansion: +19 APIs (total 27) ---
    "Blender": {"tier": "2A", "desc": "3D modelling and rendering"},
    "GIMP": {"tier": "2A", "desc": "Raster image editing via Script-Fu"},
    "Inkscape": {"tier": "2A", "desc": "SVG vector graphics conversion"},
    "Audacity": {"tier": "3B", "desc": "Audio editing via mod-script-pipe"},
    "OBS": {"tier": "2B", "desc": "Streaming/recording via obs-websocket v5"},
    "Kdenlive": {"tier": "3B", "desc": "Video editing (MLT render + XML project)"},
    "Krita": {"tier": "3B", "desc": "Digital painting, batch export"},
    "FreeCAD": {"tier": "2A", "desc": "Parametric CAD + STEP/STL/IGES export"},
    "QGIS": {"tier": "2A", "desc": "GIS processing via qgis_process"},
    "Ollama": {"tier": "1", "desc": "Local LLM runtime (REST API)"},
    "ComfyUI": {"tier": "1", "desc": "Stable Diffusion workflows (REST API)"},
    "Godot": {"tier": "2A", "desc": "Game engine export + headless scripts"},
    "MuseScore": {"tier": "2A", "desc": "Music notation convert/export"},
    "Curl": {"tier": "2A", "desc": "HTTP client (GET/POST/download/upload)"},
    "Wget": {"tier": "2A", "desc": "Download, mirror, resume"},
    "Tar": {"tier": "1", "desc": "Tar archive create/extract (stdlib)"},
    "SevenZip": {"tier": "2A", "desc": "Multi-format archive compression"},
    "Jq": {"tier": "2A", "desc": "JSON query and transformation"},
    "Rsync": {"tier": "2A", "desc": "Fast file sync and mirror"},
}

_SAFE_APIS = {"SQLite", "LibreOfficeWriter"}


def _get_registry() -> dict[str, tuple[str, str]]:
    """Return the API registry, importing lazily."""
    from api_anything.apis import _REGISTRY

    return dict(_REGISTRY)


def _get_available() -> list[str]:
    """Return names of APIs that are importable on this machine."""
    from api_anything.apis import __all__ as available

    return list(available)


def _count_methods(cls: type) -> int:
    """Count public (non-dunder, non-private) methods on *cls*."""
    return sum(
        1
        for n in dir(cls)
        if not n.startswith("_") and callable(getattr(cls, n, None))
    )


def _load_class(name: str) -> type | None:
    """Import and return the API class for *name*, or None on failure."""
    registry = _get_registry()
    if name not in registry:
        return None
    mod_path, cls_name = registry[name]
    try:
        mod = importlib.import_module(mod_path)
        return getattr(mod, cls_name)
    except Exception:
        return None


def _get_methods(cls: type) -> list[dict[str, str]]:
    """Return ``[{name, signature, docstring}, ...]`` for public methods."""
    methods: list[dict[str, str]] = []
    for name in sorted(dir(cls)):
        if name.startswith("_"):
            continue
        attr = getattr(cls, name, None)
        if not callable(attr):
            continue
        try:
            sig = str(inspect.signature(attr))
        except (ValueError, TypeError):
            sig = "(...)"
        doc = inspect.getdoc(attr) or ""
        methods.append({"name": name, "signature": sig, "docstring": doc})
    return methods


def _get_method_params(
    cls: type, method_name: str,
) -> list[dict[str, Any]]:
    """Return parameter metadata for a method (excluding self)."""
    attr = getattr(cls, method_name, None)
    if attr is None:
        return []
    try:
        sig = inspect.signature(attr)
    except (ValueError, TypeError):
        return []
    params: list[dict[str, Any]] = []
    for pname, p in sig.parameters.items():
        if pname == "self":
            continue
        default = (
            None
            if p.default is inspect.Parameter.empty
            else repr(p.default)
        )
        annotation = ""
        if p.annotation is not inspect.Parameter.empty:
            annotation = getattr(
                p.annotation, "__name__", str(p.annotation),
            )
        params.append({
            "name": pname,
            "default": default,
            "annotation": annotation,
            "kind": str(p.kind),
        })
    return params


# ---------------------------------------------------------------------------
# Dashboard Helpers
# ---------------------------------------------------------------------------


def _build_stats() -> tuple[int, int, int]:
    """Return (api_count, method_count, test_count)."""
    registry = _get_registry()
    api_count = len(registry)
    method_count = 0
    for name in registry:
        cls = _load_class(name)
        if cls is not None:
            method_count += _count_methods(cls)
    test_count = 204
    return api_count, method_count, test_count


def _build_api_table_data() -> list[list[str]]:
    """Return rows for the Dashboard API table."""
    registry = _get_registry()
    available = set(_get_available())
    rows: list[list[str]] = []
    for name in registry:
        meta = _API_META.get(name, {"tier": "?", "desc": ""})
        cls = _load_class(name)
        n_methods = _count_methods(cls) if cls else 0
        status = "Available" if name in available else "Not installed"
        rows.append([
            name, meta["tier"], str(n_methods), meta["desc"], status,
        ])
    return rows


# ---------------------------------------------------------------------------
# Tier Detection Formatting
# ---------------------------------------------------------------------------


def _format_tier_report(
    software: str, github: str, source: str,
) -> str:
    """Run tier detection and return a Markdown-formatted report.

    v0.2 C: delegates Markdown rendering to :class:`DisplayRouter` so
    web/cli/repl share one source of truth. The confidence progress-bar is
    appended afterwards because it's a web-only visual affordance.
    """
    from api_anything.display_router import DisplayRouter, OutputChannel
    from api_anything.tier_detect import detect_tier

    result = detect_tier(
        software_name=software.strip(),
        source_path=source.strip() or None,
        github_url=github.strip() or None,
    )

    web_out = DisplayRouter(OutputChannel.WEB).render(result)
    # WEB channel for TierResult always returns a dict with "markdown"
    assert isinstance(web_out, dict), "WEB channel must return dict"
    md = web_out["markdown"]

    # Web-only affordance: textual progress bar for confidence
    conf_bar = _text_bar(result.confidence / 100)
    md = md.replace(
        f"**Confidence:** {result.confidence}%",
        f"**Confidence:** {result.confidence}% &nbsp; {conf_bar}",
    )
    return md


def _text_bar(ratio: float, width: int = 20) -> str:
    """Return a simple text-based progress bar."""
    filled = int(ratio * width)
    return "`" + "#" * filled + "-" * (width - filled) + "`"


# ---------------------------------------------------------------------------
# API Explorer Helpers
# ---------------------------------------------------------------------------


def _on_api_selected(api_name: str) -> tuple[str, list[str]]:
    """Return (info_markdown, method_names) for the selected API."""
    if not api_name:
        return "Select an API from the dropdown.", []

    cls = _load_class(api_name)
    if cls is None:
        return (
            f"Could not load **{api_name}**. "
            "The required software may not be installed."
        ), []

    meta = _API_META.get(api_name, {"tier": "?", "desc": ""})
    methods = _get_methods(cls)
    method_names = [m["name"] for m in methods]

    lines: list[str] = [
        f"### {api_name}",
        f"**Tier {meta['tier']}** | {meta['desc']}",
        "",
    ]

    _append_usage_example(api_name, lines)

    lines += [
        "### Methods",
        "",
        "| Method | Signature | Description |",
        "|--------|-----------|-------------|",
    ]
    for m in methods:
        doc_first = (
            m["docstring"].split("\n")[0] if m["docstring"] else "--"
        )
        sig_escaped = m["signature"].replace("|", "\\|")
        lines.append(
            f"| `{m['name']}` | `{sig_escaped}` | {doc_first} |",
        )

    return "\n".join(lines), method_names


def _append_usage_example(api_name: str, lines: list[str]) -> None:
    """Extract usage block from module docstring and append to *lines*."""
    mod_path = _get_registry()[api_name][0]
    try:
        mod = importlib.import_module(mod_path)
        mod_doc = mod.__doc__ or ""
        if "Usage:" not in mod_doc:
            return
        usage_block = mod_doc.split("Usage:")[1].strip()
        lines.append("**Quick Start:**")
        lines.append("```python")
        for uline in usage_block.split("\n"):
            stripped = uline.strip()
            if stripped:
                lines.append(stripped)
            elif lines[-1] != "```python":
                break
        lines.append("```")
        lines.append("")
    except Exception:
        pass


def _on_method_selected(api_name: str, method_name: str) -> str:
    """Return Markdown description of method parameters."""
    if not api_name or not method_name:
        return ""
    cls = _load_class(api_name)
    if cls is None:
        return ""

    params = _get_method_params(cls, method_name)
    if not params:
        return f"**`{method_name}()`** takes no arguments."

    lines = [f"**`{method_name}`** parameters:", ""]
    for p in params:
        default_str = (
            f" = {p['default']}"
            if p["default"] is not None
            else " *(required)*"
        )
        ann_str = f" : {p['annotation']}" if p["annotation"] else ""
        lines.append(f"- **{p['name']}**{ann_str}{default_str}")
    return "\n".join(lines)


def _parse_arg(raw: str) -> Any:
    """Parse a single CLI-style argument string into a Python value."""
    raw = raw.strip()
    if not raw:
        return raw
    try:
        return int(raw)
    except ValueError:
        pass
    try:
        return float(raw)
    except ValueError:
        pass
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in ('"', "'"):
        return raw[1:-1]
    return raw


def _run_method(
    api_name: str, method_name: str, args_text: str,
) -> str:
    """Execute a method and return the result as formatted text."""
    if not api_name or not method_name:
        return "Select an API and method first."

    if api_name not in _SAFE_APIS:
        return (
            f"[Execution unavailable] {api_name} requires external "
            f"software to be installed. Only SQLite and "
            f"LibreOfficeWriter can run directly in the browser.\n\n"
            f"To try this API locally:\n"
            f"  pip install api-anything\n"
            f"  api-anything run {api_name} {method_name} "
            f"{args_text or ''}"
        )

    cls = _load_class(api_name)
    if cls is None:
        return f"Failed to load {api_name}."

    try:
        return _execute_and_format(cls, method_name, args_text)
    except Exception:
        return f"Error:\n{traceback.format_exc()}"


def _execute_and_format(
    cls: type, method_name: str, args_text: str,
) -> str:
    """Instantiate *cls*, call *method_name*, and format the result."""
    instance = cls()
    method = getattr(instance, method_name, None)
    if method is None:
        return f"Method '{method_name}' not found."

    args: list[Any] = []
    if args_text and args_text.strip():
        args = [_parse_arg(p) for p in args_text.split(",") if p.strip()]

    result = method(*args)

    if result is None:
        return "Executed successfully. (no return value)"
    if isinstance(result, list):
        return _format_list_result(result)
    return f"Result:\n  {result}"


def _format_list_result(items: list[Any]) -> str:
    """Format a list result for display."""
    if not items:
        return "Result: [] (empty list)"
    cap = 50
    formatted = [f"  [{i}] {item}" for i, item in enumerate(items[:cap])]
    out = "\n".join(formatted)
    if len(items) > cap:
        out += f"\n  ... and {len(items) - cap} more rows"
    return f"Result ({len(items)} items):\n{out}"


# ---------------------------------------------------------------------------
# Tab Builders (split from create_app for readability)
# ---------------------------------------------------------------------------


def _build_tab_dashboard(
    gr_mod: Any,
    api_count: int,
    method_count: int,
    test_count: int,
    api_table_data: list[list[str]],
) -> None:
    """Populate the Dashboard tab."""
    gr_mod.Markdown('<p class="section-header">Overview</p>')

    with gr_mod.Row(equal_height=True):
        for number, label in [
            (api_count, "Built-in APIs"),
            (method_count, "Total Methods"),
            (test_count, "Tests Passing"),
        ]:
            gr_mod.HTML(
                '<div class="stat-card">'
                f'<div class="stat-number">{number}</div>'
                f'<div class="stat-label">{label}</div>'
                "</div>"
            )

    gr_mod.Markdown(
        '<p class="section-header">Built-in API Catalog</p>',
    )
    gr_mod.Dataframe(
        value=api_table_data,
        headers=["Name", "Tier", "Methods", "Description", "Status"],
        datatype=["str", "str", "str", "str", "str"],
        interactive=False,
        wrap=True,
        elem_classes=["api-table"],
    )

    gr_mod.Markdown('<p class="section-header">Quick Start</p>')
    gr_mod.Markdown(
        '<div class="code-snippet"><pre>'
        "pip install api-anything\n\n"
        "# Detect what tier a piece of software falls into\n"
        "api-anything detect notepad\n\n"
        "# Use a built-in API\n"
        "from api_anything.apis import SQLite\n\n"
        'db = SQLite(":memory:")\n'
        "db.create_table(\"users\", "
        '{"id": "INTEGER PRIMARY KEY", "name": "TEXT"})\n'
        'db.insert("users", {"name": "Alice"})\n'
        'rows = db.query("SELECT * FROM users")\n\n'
        "# Launch interactive REPL\n"
        "api-anything repl sqlite\n\n"
        "# Launch this Web UI\n"
        "api-anything web"
        "</pre></div>"
    )

    gr_mod.Markdown('<p class="section-header">Tier System</p>')
    gr_mod.Markdown(
        "| Tier | Rating | Description | Approach |\n"
        "|------|--------|-------------|----------|\n"
        "| 1 | +++++ | Python binding on PyPI | Direct wrapper |\n"
        "| 2A | ++++ | Source + CLI available | CLI subprocess |\n"
        "| 2B | +++ | Source only, no CLI | API extraction |\n"
        "| 3A | +++ | No source, rich UIA | UI automation |\n"
        "| 3B | ++ | No source, partial UIA | Hybrid |\n"
        "| 3C | + | No source, sparse UIA | Heuristics |\n"
        "| 4 | + | Canvas / custom render | Vision model |"
    )


def _build_tab_detect(gr_mod: Any) -> None:
    """Populate the Tier Detection tab."""
    gr_mod.Markdown(
        '<p class="section-header">'
        "Analyze Software Feasibility</p>"
    )
    gr_mod.Markdown(
        "Enter a software name to detect which tier it falls "
        "into. This determines the best strategy for "
        "generating a Python API."
    )

    with gr_mod.Row():
        with gr_mod.Column(scale=2):
            detect_software = gr_mod.Textbox(
                label="Software Name",
                placeholder="e.g. ffmpeg, notepad, blender",
                max_lines=1,
            )
        with gr_mod.Column(scale=2):
            detect_github = gr_mod.Textbox(
                label="GitHub URL (optional)",
                placeholder="https://github.com/org/repo",
                max_lines=1,
            )
        with gr_mod.Column(scale=2):
            detect_source = gr_mod.Textbox(
                label="Local Source Path (optional)",
                placeholder="C:/path/to/source",
                max_lines=1,
            )

    detect_btn = gr_mod.Button(
        "Detect Tier", variant="primary", size="lg",
    )
    detect_output = gr_mod.Markdown(
        value="*Results will appear here after detection.*",
        elem_classes=["tier-report"],
    )
    detect_btn.click(
        fn=_format_tier_report,
        inputs=[detect_software, detect_github, detect_source],
        outputs=detect_output,
    )


def _build_tab_explorer(gr_mod: Any, api_names: list[str]) -> None:
    """Populate the API Explorer tab."""
    gr_mod.Markdown(
        '<p class="section-header">'
        "Browse and Test Built-in APIs</p>"
    )

    with gr_mod.Row():
        with gr_mod.Column(scale=3):
            explorer_dd = gr_mod.Dropdown(
                choices=api_names,
                label="Select API",
                value=api_names[0] if api_names else None,
                interactive=True,
            )
            explorer_info = gr_mod.Markdown(
                value="Select an API to view details.",
                elem_classes=["explorer-info"],
            )

        with gr_mod.Column(scale=2):
            gr_mod.Markdown("**Try It**")
            method_dd = gr_mod.Dropdown(
                choices=[], label="Method", interactive=True,
            )
            method_info = gr_mod.Markdown(value="")
            method_args = gr_mod.Textbox(
                label="Arguments (comma-separated)",
                placeholder='"users", "SELECT * FROM users"',
                max_lines=2,
            )
            run_btn = gr_mod.Button("Run", variant="primary")
            gr_mod.Markdown(
                "*Only SQLite and LibreOfficeWriter can execute "
                "directly. Other APIs require their software "
                "to be installed locally.*",
            )
            run_output = gr_mod.Textbox(
                label="Output",
                lines=10,
                interactive=False,
            )

    method_state = gr_mod.State([])

    def _handle_api_change(
        name: str,
    ) -> tuple[str, Any, list[str]]:
        info_md, m_names = _on_api_selected(name)
        return (
            info_md,
            gr_mod.update(
                choices=m_names,
                value=m_names[0] if m_names else None,
            ),
            m_names,
        )

    explorer_dd.change(
        fn=_handle_api_change,
        inputs=explorer_dd,
        outputs=[explorer_info, method_dd, method_state],
    )
    method_dd.change(
        fn=_on_method_selected,
        inputs=[explorer_dd, method_dd],
        outputs=method_info,
    )
    run_btn.click(
        fn=_run_method,
        inputs=[explorer_dd, method_dd, method_args],
        outputs=run_output,
    )


def _build_tab_generate(gr_mod: Any) -> None:
    """Populate the Generate (preview) tab."""
    gr_mod.Markdown(
        '<p class="section-header">'
        "API Code Generation "
        '<span class="coming-soon-badge">COMING IN v0.2</span>'
        "</p>"
    )
    gr_mod.Markdown(
        "Provide a software name, optional source code, and an "
        "optional screenshot. API-Anything will generate a "
        "complete, typed Python API wrapper with error handling, "
        "docstrings, and tests."
    )

    placeholder_code = (
        "# API generation is coming in v0.2.\n"
        "#\n"
        "# In the meantime, explore the 8 built-in APIs\n"
        "# in the API Explorer tab, or use the CLI:\n"
        "#\n"
        "#   api-anything detect <software>\n"
        "#   api-anything repl <api>\n"
        "#   api-anything run <api> <method> [args]\n"
    )

    with gr_mod.Row():
        with gr_mod.Column(scale=1):
            gr_mod.Textbox(
                label="Software Name",
                placeholder="e.g. OBS Studio",
                max_lines=1,
            )
            gr_mod.Code(
                label="Source Code (optional)",
                language="python",
                lines=12,
            )
            gr_mod.Image(
                label="Screenshot (optional)",
                type="filepath",
            )
            gr_mod.Button(
                "Generate API",
                variant="primary",
                interactive=False,
            )

        with gr_mod.Column(scale=1):
            gr_mod.Code(
                label="Generated API",
                language="python",
                lines=25,
                value=placeholder_code,
                interactive=False,
            )

    gr_mod.Markdown(
        "**Planned capabilities for v0.2:**\n\n"
        "- LLM-driven code generation from tier detection\n"
        "- Automatic test scaffolding\n"
        "- Screenshot-to-UIA mapping for Tier 3+ software\n"
        "- Multi-file output with error handling and type hints"
    )


# ---------------------------------------------------------------------------
# Application Factory
# ---------------------------------------------------------------------------


def create_app() -> gr.Blocks:
    """Create and return the Gradio Blocks application."""
    import gradio as gr_mod

    theme = gr_mod.themes.Base(
        primary_hue=gr_mod.themes.colors.blue,
        secondary_hue=gr_mod.themes.colors.slate,
        neutral_hue=gr_mod.themes.colors.gray,
        spacing_size=gr_mod.themes.sizes.spacing_md,
        radius_size=gr_mod.themes.sizes.radius_md,
        font=(
            gr_mod.themes.GoogleFont("Inter"),
            "system-ui",
            "sans-serif",
        ),
        font_mono=(
            gr_mod.themes.GoogleFont("JetBrains Mono"),
            "monospace",
        ),
    )

    api_count, method_count, test_count = _build_stats()
    api_table_data = _build_api_table_data()
    api_names = list(_get_registry().keys())

    with gr_mod.Blocks(
        title="API-Anything",
        analytics_enabled=False,
    ) as demo:
        demo._api_anything_theme = theme
        demo._api_anything_css = _CSS
        gr_mod.HTML(
            '<div class="main-header">'
            "<h1>API-Anything</h1>"
            '<p class="tagline">'
            "Auto-generate Python APIs from any software. "
            "Beyond CLI wrappers."
            "</p></div>"
        )

        with gr_mod.Tabs():
            with gr_mod.Tab("Dashboard"):
                _build_tab_dashboard(
                    gr_mod, api_count, method_count,
                    test_count, api_table_data,
                )
            with gr_mod.Tab("Tier Detection"):
                _build_tab_detect(gr_mod)
            with gr_mod.Tab("API Explorer"):
                _build_tab_explorer(gr_mod, api_names)
            with gr_mod.Tab("Generate"):
                _build_tab_generate(gr_mod)

        gr_mod.HTML(
            '<div class="app-footer">'
            "API-Anything v0.1.0 &middot; "
            "Apache-2.0 License &middot; "
            "Built by AI King"
            "</div>"
        )

    return demo


# ---------------------------------------------------------------------------
# CLI Entry
# ---------------------------------------------------------------------------


def main(port: int = 7860, share: bool = False) -> None:
    """Launch the Gradio web UI.

    Parameters
    ----------
    port:
        HTTP port to listen on (default 7860).
    share:
        Whether to create a public Gradio share link.
    """
    demo = create_app()
    theme = getattr(demo, "_api_anything_theme", None)
    css = getattr(demo, "_api_anything_css", None)
    launch_kwargs: dict[str, Any] = {
        "server_name": "0.0.0.0",
        "server_port": port,
        "share": share,
        "show_error": True,
    }
    if theme is not None:
        launch_kwargs["theme"] = theme
    if css is not None:
        launch_kwargs["css"] = css
    demo.launch(**launch_kwargs)


if __name__ == "__main__":
    main()
