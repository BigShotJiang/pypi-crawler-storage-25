"""LLM-driven code generation — 讓 LLM 自由撰寫整個 Python class body。

RFC v0.2 第 4 節 D 項。v0.1 的 `_instructor_generate` 是 schema-driven
（LLM 只填 Pydantic 欄位，renderer 拼模板），優點是穩定、缺點是機械。

本模組走 **LLM-driven** 路徑：LLM 直接吐出整段 Python 原始碼，適用場景：

- Tier 3A 以上（UIA-heavy GUI，schema 模板無法覆蓋細節）
- 需要客製 docstring / 智慧參數設計 / 使用場景推斷
- schema-driven 的 confidence 低於閾值（<60）

LLM 輸出**不可信**，必過三關驗證（`_validate_generated_code`）：

1. `ast.parse` syntax gate
2. 結構 gate：必含 `class X:` + `__init__` + ≥1 `def`
3. blacklist gate：`os.system` / `subprocess.Popen(shell=True)` /
   `eval` / `exec` / `__import__`

任一關失敗 → caller 回退到 schema-driven。

測試鐵律：**全部 mock LLM**，絕不實呼 anthropic API。
"""

from __future__ import annotations

import ast
import logging
import re
import textwrap
from dataclasses import dataclass, field
from typing import Any

from .models import UIControl

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 驗證關卡（post-generation gates）
# ---------------------------------------------------------------------------

# 黑名單 substring — RFC D 項明列的危險 pattern。保守做，只擋以下幾個，
# 其餘 v0.2.1 補。注意：這是 substring 比對不是 AST，LLM 繞過的話需升級為
# AST walker（未來版本）。
_BLACKLIST_SUBSTRINGS: tuple[str, ...] = (
    "os.system(",
    "eval(",
    "exec(",
    "__import__(",
    "compile(",
)

# 正則：`subprocess.Popen(..., shell=True)` 或同 call 用 `shell=True`。
# 行為：抓任何 Popen/run/call/check_output 後面帶 shell=True 的。
_SHELL_TRUE_RE = re.compile(
    r"subprocess\.(?:Popen|run|call|check_output|check_call)\s*\([^)]*shell\s*=\s*True",
    re.DOTALL,
)


@dataclass
class ValidationResult:
    """LLM-driven generate 的三關驗證結果。

    `passed` 為 True 才允許採用 LLM 輸出；否則 caller 回退到 schema-driven。
    `failures` 是給 logger / CLI 使用者看的具體失敗理由列表。
    """

    passed: bool
    failures: list[str] = field(default_factory=list)
    # 三關個別通過狀態，方便 CLI --verbose / observability
    syntax_ok: bool = False
    structure_ok: bool = False
    safety_ok: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "failures": list(self.failures),
            "syntax_ok": self.syntax_ok,
            "structure_ok": self.structure_ok,
            "safety_ok": self.safety_ok,
        }


def _check_syntax(source_code: str) -> tuple[bool, str | None]:
    """Gate 1：`ast.parse` 確認是合法 Python。"""
    try:
        ast.parse(source_code)
    except SyntaxError as exc:
        return False, f"SyntaxError: {exc.msg} @ line {exc.lineno}"
    return True, None


def _check_structure(source_code: str) -> tuple[bool, list[str]]:
    """Gate 2：必含 `class X:` + `__init__` + ≥1 method。

    用 AST walker 而不是 regex，避開 docstring 裡 `class` 字樣的假陽性。
    """
    failures: list[str] = []
    try:
        tree = ast.parse(source_code)
    except SyntaxError:
        # syntax gate 會先擋，這裡只是保險
        return False, ["structure check skipped: syntax invalid"]

    class_nodes = [n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)]
    if not class_nodes:
        failures.append("no class definition found")
        return False, failures

    # 至少一個 class 要含 __init__ 和 ≥1 其他 method
    has_valid_class = False
    for cls in class_nodes:
        methods = [n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        method_names = {m.name for m in methods}
        if "__init__" not in method_names:
            continue
        other_methods = method_names - {"__init__"}
        if not other_methods:
            continue
        has_valid_class = True
        break

    if not has_valid_class:
        failures.append("no class with __init__ and >=1 additional method")
        return False, failures

    return True, []


def _check_safety(source_code: str) -> tuple[bool, list[str]]:
    """Gate 3：黑名單 pattern 掃描。

    RFC D 明列：`os.system` / `subprocess.Popen(..., shell=True)` /
    `eval` / `exec`。保守做法用 substring + regex，覆蓋率不如 AST 但足夠 RFC 範圍。
    """
    failures: list[str] = []
    for pat in _BLACKLIST_SUBSTRINGS:
        if pat in source_code:
            failures.append(f"blacklist hit: {pat}")
    if _SHELL_TRUE_RE.search(source_code):
        failures.append("blacklist hit: subprocess with shell=True")
    return (not failures), failures


def _validate_generated_code(source_code: str) -> ValidationResult:
    """三關驗證：syntax → structure → safety。

    任一關失敗即 `passed=False`，但其餘關仍會跑完（方便一次列所有問題）。
    caller 看 `passed` 決定是否採用 LLM 輸出。
    """
    result = ValidationResult(passed=False)

    ok1, err1 = _check_syntax(source_code)
    result.syntax_ok = ok1
    if err1:
        result.failures.append(err1)

    ok2, err2 = _check_structure(source_code)
    result.structure_ok = ok2
    result.failures.extend(err2)

    ok3, err3 = _check_safety(source_code)
    result.safety_ok = ok3
    result.failures.extend(err3)

    result.passed = ok1 and ok2 and ok3
    return result


# ---------------------------------------------------------------------------
# Prompt（LLM-driven 專用，和 schema-driven _build_prompt 分開）
# ---------------------------------------------------------------------------

_LLM_DRIVEN_SYSTEM_PROMPT = textwrap.dedent(
    """\
    You are an expert Python API designer. Your task is to generate a complete,
    production-ready Python module that wraps a desktop software application.

    OUTPUT RULES (強制):
    - Output ONLY Python source code. No markdown fences, no prose, no explanations.
    - Start with `from __future__ import annotations`.
    - Define exactly one class that wraps the software.
    - The class must have `__init__` and at least one additional method.
    - Every method must have a type-hinted signature and a docstring.
    - Use `subprocess.run` for CLI-accessible actions; raise `NotImplementedError`
      for GUI-only actions you cannot implement confidently.

    SAFETY RULES (絕對禁止):
    - No `os.system(...)`.
    - No `subprocess.Popen(..., shell=True)` or any other `shell=True` variant.
    - No `eval(...)`, `exec(...)`, `compile(...)`, `__import__(...)`.

    STYLE:
    - Use `logging.getLogger(__name__)` for observability.
    - Include a module docstring mentioning the target software and tier.
    """
)


def _build_llm_prompt(
    software_name: str,
    controls: list[UIControl],
    screenshot_path: str | None,
    source_text: str | None,
    tier: str,
    fallback_enabled: bool,
) -> str:
    """組 LLM-driven user prompt。與 `generator._build_prompt` 類似但
    要求整段原始碼，不是 Pydantic schema。"""
    parts: list[str] = []
    parts.append(f"# Target Software: {software_name}")
    parts.append(f"# Detected Tier: {tier}")

    if controls:
        parts.append("\n## UI Controls")
        for ctrl in controls[:50]:
            aid = f" (id={ctrl.automation_id})" if ctrl.automation_id else ""
            parts.append(f"- [{ctrl.control_type}] {ctrl.name}{aid}")

    if source_text:
        parts.append(f"\n## Source Code Excerpts\n{source_text[:5000]}")

    if screenshot_path:
        parts.append(f"\n## Screenshot\n{screenshot_path}")

    if fallback_enabled:
        parts.append(
            "\n## Fallback Note\n"
            "GUI-only methods that you cannot implement confidently may raise "
            "NotImplementedError. The runtime has a CLI-Anything fallback "
            "layer that will catch it and degrade gracefully."
        )

    class_name = _pascal_from_name(software_name)
    parts.append(
        "\n## Deliverable\n"
        f"A complete Python module defining class `{class_name}` that wraps "
        f"{software_name}. Output raw Python only."
    )
    return "\n".join(parts)


def _pascal_from_name(software_name: str) -> str:
    """`my cool app` → `MyCoolAppAPI`。與 generator 保持一致的命名。"""
    cleaned = "".join(c if c.isalnum() or c == " " else " " for c in software_name)
    return "".join(w.capitalize() for w in cleaned.split()) + "API"


# ---------------------------------------------------------------------------
# LLM 呼叫（anthropic client，tests 必 mock）
# ---------------------------------------------------------------------------


def _extract_code_from_response(raw: str) -> str:
    """把 LLM response 裡可能的 markdown fence 剝掉。

    Claude 偶爾會違反 "no markdown fences" 指令，包成 ```python ... ```。
    這裡做兩層防禦：先嘗試抓 fence、失敗就原樣返回由驗證關卡處理。
    """
    stripped = raw.strip()
    # 常見形式 ```python\n...\n```
    fence_match = re.match(
        r"^```(?:python|py)?\s*\n(.*?)\n```\s*$", stripped, re.DOTALL
    )
    if fence_match:
        return fence_match.group(1)
    # Fallback: 原樣
    return stripped


def _call_anthropic(
    client: Any,
    system_prompt: str,
    user_prompt: str,
    model: str = "claude-opus-4-5",
    max_tokens: int = 4096,
) -> str:
    """呼 anthropic messages API。

    `client` 是 `anthropic.Anthropic()` instance 或 mock。使用 duck typing —
    只要物件有 `.messages.create(...)` 即可。tests 全用 `MagicMock` 注入。

    Raises:
        RuntimeError: client 結構不符 / response 非預期。
    """
    try:
        messages_api = client.messages
    except AttributeError as exc:
        raise RuntimeError(f"anthropic client missing .messages: {exc}") from exc

    response = messages_api.create(
        model=model,
        max_tokens=max_tokens,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )

    # anthropic SDK: response.content 是 list[TextBlock]，每個有 .text
    try:
        content = response.content
        if not content:
            raise RuntimeError("empty response.content")
        first = content[0]
        text = getattr(first, "text", None)
        if text is None:
            raise RuntimeError("response.content[0] missing .text")
        return str(text)
    except (AttributeError, IndexError, TypeError) as exc:
        raise RuntimeError(f"malformed anthropic response: {exc}") from exc


# ---------------------------------------------------------------------------
# 對外入口
# ---------------------------------------------------------------------------


@dataclass
class LLMGenerateOutcome:
    """LLM-driven generate 的完整結果（成功或失敗）。

    `source_code` 僅在 `validation.passed=True` 時可信。caller 應檢查 validation
    再決定是否採用；失敗時 fallback to schema-driven。
    """

    source_code: str
    validation: ValidationResult
    raw_response: str  # 除錯用，LLM 原始輸出（含 fence 未剝）


def llm_driven_generate(
    software_name: str,
    controls: list[UIControl],
    client: Any,
    *,
    screenshot_path: str | None = None,
    source_text: str | None = None,
    tier: str = "3A",
    fallback_enabled: bool = False,
    model: str = "claude-opus-4-5",
) -> LLMGenerateOutcome:
    """LLM-driven 產出完整 Python 原始碼 + 三關驗證。

    Args:
        software_name: 目標軟體名（用於 class 名稱推導 + prompt context）。
        controls: analyzer 抓到的 UI controls。
        client: anthropic-compatible client（有 `.messages.create(...)`）。
            **禁止在 tests 傳真實 client**，tests 必用 `MagicMock`。
        screenshot_path: 截圖路徑（供 vision prompt，目前僅納入文字 context）。
        source_text: 原始碼摘要（Tier 1/2）。
        tier: 偵測 tier，用於 prompt adaption。
        fallback_enabled: 若 True，prompt 告知 LLM 可對無法實作的 UIA method
            raise NotImplementedError（runtime 會 degrade 到 CLI-Anything）。
        model: anthropic model id。預設 opus-4-5，可覆寫。

    Returns:
        LLMGenerateOutcome，含驗證結果。caller 必檢查 `outcome.validation.passed`
        再決定是否採用。
    """
    system_prompt = _LLM_DRIVEN_SYSTEM_PROMPT
    user_prompt = _build_llm_prompt(
        software_name=software_name,
        controls=controls,
        screenshot_path=screenshot_path,
        source_text=source_text,
        tier=tier,
        fallback_enabled=fallback_enabled,
    )

    try:
        raw = _call_anthropic(client, system_prompt, user_prompt, model=model)
    except Exception as exc:  # 任何呼叫層錯誤都歸「LLM 失敗」
        logger.warning("LLM-driven generate failed at API layer: %s", exc)
        validation = ValidationResult(
            passed=False,
            failures=[f"llm_call_error: {exc}"],
        )
        return LLMGenerateOutcome(source_code="", validation=validation, raw_response="")

    code = _extract_code_from_response(raw)
    validation = _validate_generated_code(code)

    if not validation.passed:
        logger.info(
            "LLM-driven output rejected by validation: %s",
            "; ".join(validation.failures),
        )

    return LLMGenerateOutcome(source_code=code, validation=validation, raw_response=raw)
