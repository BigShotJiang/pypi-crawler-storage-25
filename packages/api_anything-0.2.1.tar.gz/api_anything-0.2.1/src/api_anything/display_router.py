"""Unified output router for API-Anything (v0.2 C 項).

目標：把 ``cli.py`` / ``web.py`` / ``repl.py`` 散落的輸出邏輯統一成單一
路由層。任何內部結果（``TierResult`` / ``APIClass`` / ``GenerationResult``
/ 錯誤 / 任意 dict）都經過 :class:`DisplayRouter` 分派到 4 個通道：

- ``cli``  -- Rich ``RenderableType``（Panel / Table），呼叫端自己 ``console.print``
- ``json`` -- ``json.dumps`` 字串，適合 ``--json`` / pipe
- ``repl`` -- 簡化 text，REPL 友善（不含外框）
- ``web``  -- Gradio-friendly dict（含 ``markdown`` 字串 + 結構化資訊）

設計鐵律（見 RFC v0.2 §4 C）：

1. Rich channel **不直接 print**，而是回 ``rich.console.RenderableType``；
   呼叫端（cli.py 的 handler）決定何時 ``console.print``
2. JSON channel 用 Pydantic ``model_dump(mode="json")``，禁 ``__dict__``
3. Web channel 不引入新依賴，用 Gradio 已經有的 ``pd.DataFrame`` /
   ``dict`` / Markdown string
4. 型別 mismatch → 拋 :class:`UnsupportedPayloadError`（不 silent fallback
   到 ``repr``，避免真的有 bug 被掩蓋）

Extensibility：新增 channel 只需加 ``OutputChannel`` enum + 對應
``_render_<type>_<channel>`` 方法或在 ``render`` dispatch 加一 case。
"""

from __future__ import annotations

import json
from enum import Enum
from typing import TYPE_CHECKING, Any

from rich.console import RenderableType
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from api_anything.models import APIClass, APIMethod, GenerationResult
from api_anything.tier_detect import CheckResult, TierResult

if TYPE_CHECKING:  # pragma: no cover - type only
    pass


# ---------------------------------------------------------------------------
# Public enums + exceptions
# ---------------------------------------------------------------------------


class OutputChannel(str, Enum):
    """支援的輸出通道列舉。"""

    CLI = "cli"
    JSON = "json"
    REPL = "repl"
    WEB = "web"


class UnsupportedPayloadError(TypeError):
    """Payload 型別 router 不認得（或某 channel 不支援）。

    故意繼承 ``TypeError``，讓呼叫端能用一般 ``except TypeError`` 接住；
    也保留自訂類別方便測試精準斷言。
    """


# Router 可直接認得的 payload 型別（型別分派白名單）
_KNOWN_TYPES: tuple[type, ...] = (
    TierResult,
    CheckResult,
    APIClass,
    APIMethod,
    GenerationResult,
)


# ---------------------------------------------------------------------------
# Display Router
# ---------------------------------------------------------------------------


class DisplayRouter:
    """統一出口，把 payload 路由到四種 channel。

    典型用法::

        router = DisplayRouter(OutputChannel.CLI)
        renderable = router.render(tier_result)
        console.print(renderable)  # CLI channel 回 rich Renderable

        router = DisplayRouter(OutputChannel.JSON)
        print(router.render(tier_result))  # JSON channel 回 str

    Parameters
    ----------
    channel:
        :class:`OutputChannel` 值，或其字串表示（``"cli"`` / ``"json"``
        / ``"repl"`` / ``"web"``）。
    """

    def __init__(self, channel: OutputChannel | str) -> None:
        if isinstance(channel, str):
            try:
                channel = OutputChannel(channel)
            except ValueError as exc:
                raise UnsupportedPayloadError(
                    f"Unknown channel: {channel!r}. "
                    f"Valid: {[c.value for c in OutputChannel]}"
                ) from exc
        self.channel: OutputChannel = channel

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def render(
        self,
        payload: Any,
        *,
        title: str = "",
    ) -> RenderableType | str | dict[str, Any]:
        """Route *payload* to the current channel's renderer.

        Returns type depends on channel:

        - ``CLI``  -> ``rich.console.RenderableType``（``Panel`` / ``Table``）
        - ``JSON`` -> ``str``（``json.dumps`` 輸出）
        - ``REPL`` -> ``str``（簡化純文字）
        - ``WEB``  -> ``dict``（含 ``markdown`` key，Gradio 可直接 return）

        Raises
        ------
        UnsupportedPayloadError
            若 payload 型別 router 不認得（且非 dict / 非 str）。
        """
        if isinstance(payload, TierResult):
            return self._render_tier_result(payload)
        if isinstance(payload, CheckResult):
            return self._render_check_result(payload, title=title)
        if isinstance(payload, GenerationResult):
            return self._render_generation_result(payload)
        if isinstance(payload, APIClass):
            return self._render_api_class(payload)
        if isinstance(payload, APIMethod):
            return self._render_api_method(payload)

        # Dict / list / primitive fallback（結構化但無 schema）
        if isinstance(payload, (dict, list, str, int, float, bool, type(None))):
            return self._render_generic(payload, title=title)

        raise UnsupportedPayloadError(
            f"DisplayRouter cannot render payload of type "
            f"{type(payload).__name__}. Supported: "
            f"{[t.__name__ for t in _KNOWN_TYPES]} + dict/list/primitives."
        )

    def render_error(
        self,
        exc: BaseException | str,
        *,
        context: str = "",
    ) -> RenderableType | str | dict[str, Any]:
        """Render an exception / error string uniformly across channels."""
        msg = str(exc) if isinstance(exc, BaseException) else exc
        exc_type = type(exc).__name__ if isinstance(exc, BaseException) else "Error"

        if self.channel is OutputChannel.CLI:
            body = Text()
            if context:
                body.append(f"{context}\n", style="dim")
            body.append(f"[{exc_type}] ", style="bold red")
            body.append(msg, style="red")
            return Panel(body, title="Error", border_style="red", padding=(0, 2))
        if self.channel is OutputChannel.JSON:
            return json.dumps(
                {"error": {"type": exc_type, "message": msg, "context": context}},
                indent=2, ensure_ascii=False,
            )
        if self.channel is OutputChannel.REPL:
            prefix = f"{context}: " if context else ""
            return f"Error: {prefix}{msg}"
        if self.channel is OutputChannel.WEB:
            return {
                "markdown": (
                    f"### Error\n\n**{exc_type}**: {msg}"
                    + (f"\n\n_Context: {context}_" if context else "")
                ),
                "error": True,
                "type": exc_type,
                "message": msg,
            }
        # 理論上不會到（channel 在 __init__ 已驗證）
        raise UnsupportedPayloadError(f"Unhandled channel: {self.channel}")

    # ------------------------------------------------------------------
    # TierResult
    # ------------------------------------------------------------------

    def _render_tier_result(
        self, result: TierResult,
    ) -> RenderableType | str | dict[str, Any]:
        if self.channel is OutputChannel.CLI:
            return self._tier_result_rich(result)
        if self.channel is OutputChannel.JSON:
            return json.dumps(
                result.model_dump(mode="json"), indent=2, ensure_ascii=False,
            )
        if self.channel is OutputChannel.REPL:
            return self._tier_result_text(result)
        if self.channel is OutputChannel.WEB:
            return {
                "markdown": self._tier_result_markdown(result),
                "tier": result.tier.value,
                "confidence": result.confidence,
                "software": result.software,
            }
        raise UnsupportedPayloadError(f"Unhandled channel: {self.channel}")

    def _tier_result_rich(self, result: TierResult) -> RenderableType:
        """Build a Rich ``Panel`` for a TierResult — 不直接 print。"""
        body = Text()
        body.append(f"Software: {result.software}", style="bold white")
        body.append(f"  ({result.version})\n", style="dim")
        body.append(f"Tier {result.tier.value}  ", style="bold magenta")
        body.append(f"{result.stars}\n", style="yellow")

        table = Table(show_header=True, header_style="bold blue", expand=False)
        table.add_column("Check", style="cyan")
        table.add_column("Status", justify="center")
        table.add_column("Detail", style="dim")

        ordered_keys = [
            "python_binding", "source_code", "cli_support",
            "uia_quality", "electron_fingerprint", "runtime_probe",
        ]
        for key in ordered_keys:
            check = result.checks.get(key)
            if check is None:
                continue
            tag = "OK" if check.passed else "--"
            style = "green" if check.passed else "red"
            table.add_row(
                key, Text(tag, style=style), check.detail or "-",
            )

        footer = Text()
        footer.append(f"\nConfidence: {result.confidence}%", style="bold")
        footer.append(f"  |  Est. tokens: ~{result.est_tokens_k}K\n", style="dim")
        footer.append(f"Verdict: {result.verdict}", style="italic")

        # Compose as Panel containing header + table + footer
        from rich.console import Group
        return Panel(
            Group(body, table, footer),
            title="API-Anything Tier Detection",
            border_style="cyan",
            padding=(1, 2),
        )

    def _tier_result_text(self, result: TierResult) -> str:
        """REPL-friendly plain text."""
        lines = [
            f"[{result.software} v{result.version}] Tier {result.tier.value} "
            f"{result.stars}",
            f"  Confidence: {result.confidence}%  "
            f"| Est tokens: ~{result.est_tokens_k}K",
            f"  Verdict: {result.verdict}",
            "  Checks:",
        ]
        for key, check in result.checks.items():
            tag = "OK" if check.passed else "--"
            lines.append(f"    [{tag}] {key}: {check.detail}")
        if result.electron_suspected:
            lines.append("  (electron/CEF shell suspected — try --probe)")
        return "\n".join(lines)

    def _tier_result_markdown(self, result: TierResult) -> str:
        """Gradio-friendly Markdown — 保留原 web.py 外觀慣例。"""
        lines: list[str] = [
            f"## Tier Detection Report: {result.software}",
            "",
            f"**Tier {result.tier.value}** &nbsp; {result.stars}",
            "",
            "### Detection Checks",
            "",
            "| Check | Status | Detail |",
            "|-------|--------|--------|",
        ]
        labels = {
            "python_binding": "Python Binding (PyPI)",
            "source_code": "Source Code",
            "cli_support": "CLI Support",
            "uia_quality": "UIA Quality",
            "electron_fingerprint": "Electron Fingerprint",
            "runtime_probe": "Runtime Probe",
        }
        for key in [
            "python_binding", "source_code", "cli_support",
            "uia_quality", "electron_fingerprint", "runtime_probe",
        ]:
            check = result.checks.get(key)
            if check is None:
                continue
            tag = "PASS" if check.passed else "FAIL"
            css = "pass" if check.passed else "fail"
            label = labels.get(key, key)
            lines.append(
                f'| {label} | <span class="{css}">{tag}</span> | '
                f"{check.detail or '--'} |",
            )
        lines += [
            "",
            "### Analysis",
            "",
            f"**Confidence:** {result.confidence}%",
            "",
            f"**Estimated Generation Cost:** ~{result.est_tokens_k}K tokens",
            "",
            '<div class="verdict-box">',
            f"**Verdict:** {result.verdict}",
            "</div>",
        ]
        if result.electron_suspected:
            lines += [
                "",
                "> Electron/CEF/WebView2 shell suspected. "
                "Re-run with `runtime_probe=True` to refine.",
            ]
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # CheckResult (single row)
    # ------------------------------------------------------------------

    def _render_check_result(
        self, check: CheckResult, *, title: str = "",
    ) -> RenderableType | str | dict[str, Any]:
        if self.channel is OutputChannel.CLI:
            tag = "OK" if check.passed else "--"
            style = "green" if check.passed else "red"
            body = Text()
            body.append(f"[{tag}] ", style=f"bold {style}")
            body.append(check.detail or "-")
            return Panel(body, title=title or "Check", border_style=style)
        if self.channel is OutputChannel.JSON:
            return json.dumps(
                check.model_dump(mode="json"), indent=2, ensure_ascii=False,
            )
        if self.channel is OutputChannel.REPL:
            tag = "OK" if check.passed else "--"
            return f"[{tag}] {title or 'check'}: {check.detail}"
        if self.channel is OutputChannel.WEB:
            return {
                "markdown": (
                    f"**{title or 'Check'}**: "
                    f"{'PASS' if check.passed else 'FAIL'} — "
                    f"{check.detail or '-'}"
                ),
                "passed": check.passed,
                "detail": check.detail,
            }
        raise UnsupportedPayloadError(f"Unhandled channel: {self.channel}")

    # ------------------------------------------------------------------
    # GenerationResult
    # ------------------------------------------------------------------

    def _render_generation_result(
        self, gen: GenerationResult,
    ) -> RenderableType | str | dict[str, Any]:
        if self.channel is OutputChannel.CLI:
            body = Text()
            body.append(
                f"Generated: {gen.api_class.class_name}\n", style="bold green",
            )
            body.append(f"  module: {gen.api_class.module_name}\n", style="dim")
            body.append(
                f"  tier: {gen.api_class.tier}  "
                f"methods: {len(gen.api_class.methods)}  "
                f"imports: {len(gen.api_class.imports)}\n",
                style="cyan",
            )
            body.append(f"  tokens used: {gen.tokens_used}  ", style="dim")
            body.append(f"time: {gen.generation_time_seconds:.2f}s", style="dim")
            return Panel(
                body, title="Generation Result",
                border_style="green", padding=(0, 2),
            )
        if self.channel is OutputChannel.JSON:
            data = gen.model_dump(mode="json")
            # tier_result 可能是 TierResult；確保 JSON-serialisable
            if isinstance(gen.tier_result, TierResult):
                data["tier_result"] = gen.tier_result.model_dump(mode="json")
            return json.dumps(data, indent=2, ensure_ascii=False)
        if self.channel is OutputChannel.REPL:
            return (
                f"Generated {gen.api_class.class_name} "
                f"({len(gen.api_class.methods)} methods, "
                f"tier={gen.api_class.tier}, "
                f"{gen.tokens_used} tokens, "
                f"{gen.generation_time_seconds:.2f}s)"
            )
        if self.channel is OutputChannel.WEB:
            return {
                "markdown": (
                    f"### {gen.api_class.class_name}\n\n"
                    f"- **Module**: `{gen.api_class.module_name}`\n"
                    f"- **Tier**: {gen.api_class.tier}\n"
                    f"- **Methods**: {len(gen.api_class.methods)}\n"
                    f"- **Tokens**: {gen.tokens_used}\n"
                    f"- **Time**: {gen.generation_time_seconds:.2f}s"
                ),
                "source_code": gen.source_code,
                "test_code": gen.test_code,
                "class_name": gen.api_class.class_name,
            }
        raise UnsupportedPayloadError(f"Unhandled channel: {self.channel}")

    # ------------------------------------------------------------------
    # APIClass / APIMethod
    # ------------------------------------------------------------------

    def _render_api_class(
        self, api_class: APIClass,
    ) -> RenderableType | str | dict[str, Any]:
        if self.channel is OutputChannel.CLI:
            body = Text()
            body.append(f"{api_class.class_name}\n", style="bold cyan")
            body.append(f"  module: {api_class.module_name}\n", style="dim")
            body.append(f"  tier: {api_class.tier}\n", style="dim")
            body.append(
                f"  methods ({len(api_class.methods)}):\n", style="dim",
            )
            for m in api_class.methods:
                body.append(f"    - {m.name}({len(m.params)} params)\n")
            return Panel(body, title="APIClass", border_style="cyan")
        if self.channel is OutputChannel.JSON:
            return json.dumps(
                api_class.model_dump(mode="json"), indent=2, ensure_ascii=False,
            )
        if self.channel is OutputChannel.REPL:
            return (
                f"{api_class.class_name} [{api_class.tier}] "
                f"— {len(api_class.methods)} methods"
            )
        if self.channel is OutputChannel.WEB:
            rows = [
                {
                    "method": m.name,
                    "params": len(m.params),
                    "return": m.return_type,
                    "mode": m.operation_mode,
                }
                for m in api_class.methods
            ]
            return {
                "markdown": (
                    f"### {api_class.class_name}\n\n"
                    f"_{api_class.docstring or ''}_\n\n"
                    f"**Tier**: {api_class.tier}  |  "
                    f"**Methods**: {len(api_class.methods)}"
                ),
                "rows": rows,
                "class_name": api_class.class_name,
            }
        raise UnsupportedPayloadError(f"Unhandled channel: {self.channel}")

    def _render_api_method(
        self, method: APIMethod,
    ) -> RenderableType | str | dict[str, Any]:
        sig = ", ".join(
            f"{p.name}: {p.type_hint}" + (f" = {p.default}" if p.default else "")
            for p in method.params
        )
        header = f"{method.name}({sig}) -> {method.return_type}"
        if self.channel is OutputChannel.CLI:
            body = Text()
            body.append(f"{header}\n", style="bold cyan")
            body.append(f"  mode: {method.operation_mode}\n", style="dim")
            if method.docstring:
                body.append(f"  {method.docstring}\n", style="italic")
            return Panel(body, title="APIMethod", border_style="cyan")
        if self.channel is OutputChannel.JSON:
            return json.dumps(
                method.model_dump(mode="json"), indent=2, ensure_ascii=False,
            )
        if self.channel is OutputChannel.REPL:
            return header
        if self.channel is OutputChannel.WEB:
            return {
                "markdown": (
                    f"**`{header}`**\n\n"
                    f"_{method.docstring or 'no docstring'}_"
                ),
                "name": method.name,
                "operation_mode": method.operation_mode,
            }
        raise UnsupportedPayloadError(f"Unhandled channel: {self.channel}")

    # ------------------------------------------------------------------
    # Generic (dict / list / primitive)
    # ------------------------------------------------------------------

    def _render_generic(
        self, payload: Any, *, title: str = "",
    ) -> RenderableType | str | dict[str, Any]:
        if self.channel is OutputChannel.CLI:
            if isinstance(payload, dict):
                table = Table(
                    title=title or None,
                    show_header=True, header_style="bold",
                )
                table.add_column("key", style="cyan")
                table.add_column("value")
                for k, v in payload.items():
                    table.add_row(str(k), str(v))
                return table
            if isinstance(payload, list):
                body = Text()
                for i, item in enumerate(payload[:50]):
                    body.append(f"[{i}] ", style="dim")
                    body.append(f"{item}\n")
                if len(payload) > 50:
                    body.append(
                        f"... {len(payload) - 50} more\n", style="dim",
                    )
                return Panel(body, title=title or "List")
            return Text(str(payload))
        if self.channel is OutputChannel.JSON:
            try:
                return json.dumps(payload, indent=2, ensure_ascii=False, default=str)
            except (TypeError, ValueError) as exc:
                raise UnsupportedPayloadError(
                    f"JSON encoding failed for payload: {exc}"
                ) from exc
        if self.channel is OutputChannel.REPL:
            if payload is None:
                return "OK"
            if isinstance(payload, (dict, list)):
                try:
                    return json.dumps(payload, ensure_ascii=False, default=str)
                except (TypeError, ValueError):
                    return str(payload)
            return str(payload)
        if self.channel is OutputChannel.WEB:
            if isinstance(payload, dict):
                md_lines = [f"### {title}\n"] if title else []
                md_lines += [f"- **{k}**: {v}" for k, v in payload.items()]
                return {"markdown": "\n".join(md_lines), "data": payload}
            if isinstance(payload, list):
                return {
                    "markdown": "\n".join(
                        f"- {item}" for item in payload[:50]
                    ),
                    "data": payload,
                }
            return {"markdown": str(payload), "data": payload}
        raise UnsupportedPayloadError(f"Unhandled channel: {self.channel}")


# ---------------------------------------------------------------------------
# Convenience module-level helpers（cli.py / repl.py 可直接 import 用）
# ---------------------------------------------------------------------------


def render(
    payload: Any,
    channel: OutputChannel | str,
    *,
    title: str = "",
) -> RenderableType | str | dict[str, Any]:
    """One-shot helper — 建立 router 並 render，不保留狀態。"""
    return DisplayRouter(channel).render(payload, title=title)


def render_error(
    exc: BaseException | str,
    channel: OutputChannel | str,
    *,
    context: str = "",
) -> RenderableType | str | dict[str, Any]:
    """One-shot error renderer helper。"""
    return DisplayRouter(channel).render_error(exc, context=context)
