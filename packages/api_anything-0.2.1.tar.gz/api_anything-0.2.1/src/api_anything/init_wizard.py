"""First-run initialisation wizard for api-anything.

Interactive onboarding powered by ``rich.prompt``. Detects the user's main
use case, recommends a starter set of APIs, checks whether the required
binaries are on PATH, and persists the selection to
``~/.api-anything/config.toml``.

Running a second time is safe — the previous config is read, and the wizard
exits early unless ``force=True``.
"""

from __future__ import annotations

import datetime as _dt
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.prompt import IntPrompt
from rich.table import Table

# ---------------------------------------------------------------------------
# Static data
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class UseCase:
    """A recommended onboarding profile."""

    key: str
    label: str
    default_mode: str
    recommended: tuple[str, ...]


_USE_CASES: tuple[UseCase, ...] = (
    UseCase(
        key="agent",
        label="AI Agent integration (Claude/Cursor/Cline)",
        default_mode="mcp",
        recommended=("SQLite", "FFmpeg", "Git", "ImageMagick"),
    ),
    UseCase(
        key="cli",
        label="CLI tool usage (terminal power user)",
        default_mode="run",
        recommended=("FFmpeg", "Git", "ImageMagick", "Pandoc"),
    ),
    UseCase(
        key="python",
        label="Python import (library-style)",
        default_mode="library",
        recommended=("SQLite", "Git", "Pandoc"),
    ),
    UseCase(
        key="mixed",
        label="Mixed / I want everything",
        default_mode="repl",
        recommended=(
            "FFmpeg", "Git", "Docker", "SQLite",
            "ImageMagick", "Pandoc", "LibreOfficeWriter",
        ),
    ),
)

# API -> binary name to probe on PATH + install hint
_API_PROBE: dict[str, tuple[str, str]] = {
    "FFmpeg": ("ffmpeg", "https://ffmpeg.org/download.html"),
    "Git": ("git", "https://git-scm.com/downloads"),
    "Docker": ("docker", "https://www.docker.com/products/docker-desktop"),
    "SQLite": ("", "bundled with Python stdlib"),
    "ImageMagick": ("magick", "https://imagemagick.org/script/download.php"),
    "Pandoc": ("pandoc", "https://pandoc.org/installing.html"),
    "LibreOfficeWriter": ("soffice", "https://www.libreoffice.org/download/"),
    "Notepad": ("notepad", "bundled with Windows"),
}


def _config_path() -> Path:
    """Return the config file path (honouring ``API_ANYTHING_HOME``)."""
    override = os.environ.get("API_ANYTHING_HOME")
    root = Path(override) if override else Path.home() / ".api-anything"
    return root / "config.toml"


# ---------------------------------------------------------------------------
# TOML helpers (stdlib tomllib read, hand-rolled writer for broad support)
# ---------------------------------------------------------------------------


def _load_config() -> dict[str, Any]:
    path = _config_path()
    if not path.exists():
        return {}
    try:
        import tomllib  # py311+
    except ModuleNotFoundError:  # pragma: no cover
        try:
            import tomli as tomllib  # type: ignore[import-not-found]
        except ModuleNotFoundError:
            return {}
    with path.open("rb") as f:
        try:
            return tomllib.load(f)
        except Exception:
            return {}


def _escape_toml_str(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def _write_config(data: dict[str, Any]) -> Path:
    """Serialise a flat TOML config (strings + lists of strings)."""
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = ["# api-anything config.toml", ""]
    for key, value in data.items():
        if isinstance(value, list):
            items = ", ".join(f'"{_escape_toml_str(str(v))}"' for v in value)
            lines.append(f"{key} = [{items}]")
        elif isinstance(value, bool):
            lines.append(f"{key} = {str(value).lower()}")
        elif isinstance(value, (int, float)):
            lines.append(f"{key} = {value}")
        else:
            lines.append(f'{key} = "{_escape_toml_str(str(value))}"')
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


# ---------------------------------------------------------------------------
# Probes
# ---------------------------------------------------------------------------


def _probe_apis(names: tuple[str, ...]) -> dict[str, tuple[bool, str]]:
    """Check each API's binary; return ``{name: (available, hint_or_path)}``."""
    results: dict[str, tuple[bool, str]] = {}
    for name in names:
        binary, hint = _API_PROBE.get(name, ("", ""))
        if not binary:
            # Python stdlib / bundled: mark as available.
            results[name] = (True, hint or "(bundled)")
            continue
        path = shutil.which(binary)
        if path:
            results[name] = (True, path)
        else:
            results[name] = (False, hint or f"install {binary}")
    return results


# ---------------------------------------------------------------------------
# Wizard
# ---------------------------------------------------------------------------


def _print_banner(console: Console) -> None:
    console.print(
        Panel.fit(
            "[bold cyan]api-anything[/bold cyan] — first-run setup\n\n"
            "Auto-generate Python APIs for any software.\n"
            "This wizard picks a starter set that fits how you plan to use it.",
            title="Welcome",
            border_style="cyan",
        )
    )


def _choose_use_case(console: Console) -> UseCase:
    console.print("\n[bold]Which best describes how you'll use api-anything?[/bold]")
    for idx, uc in enumerate(_USE_CASES, start=1):
        console.print(f"  [cyan]{idx}[/cyan]. {uc.label}")
    choice = IntPrompt.ask(
        "Pick a number",
        choices=[str(i) for i in range(1, len(_USE_CASES) + 1)],
        default=1,
    )
    return _USE_CASES[choice - 1]


def _print_availability(
    console: Console,
    probes: dict[str, tuple[bool, str]],
) -> list[str]:
    """Print the availability table and return the list of missing APIs."""
    table = Table(title="Recommended APIs")
    table.add_column("API", style="cyan")
    table.add_column("Status")
    table.add_column("Location / install hint")

    missing: list[str] = []
    for name, (ok, info) in probes.items():
        if ok:
            table.add_row(name, "[green]ready[/green]", info)
        else:
            table.add_row(name, "[yellow]missing[/yellow]", info)
            missing.append(name)
    console.print(table)
    return missing


def _print_next_steps(console: Console, uc: UseCase) -> None:
    console.print("\n[bold]Next steps[/bold]")
    if uc.default_mode == "mcp":
        console.print("  • Start the MCP server:  [cyan]api-anything mcp-serve[/cyan]")
    elif uc.default_mode == "run":
        console.print("  • One-shot call:         [cyan]api-anything run <api> <method> ...[/cyan]")
    elif uc.default_mode == "library":
        console.print("  • Import in Python:      [cyan]from api_anything.apis import <Api>[/cyan]")
    else:
        console.print("  • Launch REPL:           [cyan]api-anything repl <api>[/cyan]")
    console.print("  • Detect any software:   [cyan]api-anything detect <name>[/cyan]")
    console.print("  • Show all APIs:         [cyan]api-anything list --detail[/cyan]")


def run_wizard(
    *,
    console: Console | None = None,
    force: bool = False,
    non_interactive: bool = False,
) -> dict[str, Any]:
    """Run the first-run wizard.

    Parameters
    ----------
    console:
        Optional ``rich.Console`` for output.
    force:
        If True, run even when a config already exists.
    non_interactive:
        If True, skip prompts and pick the ``"mixed"`` use case (useful for
        CI or ``api-anything init --yes``).

    Returns
    -------
    dict
        The config dict written to disk (also returned for programmatic use).
    """
    console = console or Console()

    existing = _load_config()
    if existing and not force:
        console.print(
            f"[yellow]Config already exists at {_config_path()}.[/yellow] "
            "Re-run with [cyan]--force[/cyan] to overwrite."
        )
        return existing

    _print_banner(console)

    if non_interactive or not sys.stdin.isatty():
        uc = next(u for u in _USE_CASES if u.key == "mixed")
        console.print("\n[dim]Running non-interactively; defaulting to 'Mixed'.[/dim]")
    else:
        uc = _choose_use_case(console)

    probes = _probe_apis(uc.recommended)
    missing = _print_availability(console, probes)

    config: dict[str, Any] = {
        "use_case": uc.key,
        "default_mode": uc.default_mode,
        "recommended_apis": list(uc.recommended),
        "first_run_date": _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "version": _current_version(),
    }
    path = _write_config(config)
    console.print(f"\n[green]Config written to {path}[/green]")

    if missing:
        console.print(
            f"\n[yellow]Heads up:[/yellow] "
            f"{len(missing)} recommended tool(s) are missing: "
            f"{', '.join(missing)}."
        )
    _print_next_steps(console, uc)
    return config


def _current_version() -> str:
    try:
        from importlib.metadata import version

        return version("api-anything")
    except Exception:
        return "0.0.0"


__all__ = ["run_wizard"]
