# api-anything CLI entry wiring reference

Merge-only reference for the main agent integrating `cli.py`. Each row lists
the new subcommand, its argparse shape, and the function it must dispatch to.

## Subcommand table

| Subcommand | Arguments | Dispatch |
|---|---|---|
| `mcp-serve` | `[--host HOST] [--port PORT] [--transport {stdio,sse,http}]` | `api_anything.mcp_server.run_server(host, port, transport)` |
| `completions` | `{bash,zsh,fish}` (positional) | `api_anything.shell_complete.generate(shell)` (print to stdout) |
| `init` | `[--force] [--yes]` | `api_anything.init_wizard.run_wizard(force=..., non_interactive=...)` |
| `refine` | `<api_path> [--max-iter N]` | `api_anything.refine_pipeline.refine(api_path, max_iterations=N)` |
| `test` | `<api_path> [--coverage/--no-coverage]` | `api_anything.refine_pipeline.test(api_path, coverage=...)` |
| `validate` | `<api_path>` | `api_anything.refine_pipeline.validate(api_path)` |
| `pipe` *(optional alias)* | `<api> <method> [args ...]` | `api_anything.pipe_runner.run_with_pipe(api, method, list(argv))` |

`pipe` can also be folded into the existing `run` subcommand (detect
`sys.stdin.isatty() == False` and call `run_with_pipe` instead of the
argparse-based runner). Either wiring is compatible with the module.

## Defaults

- `mcp-serve`: `host=127.0.0.1`, `port=8765`, `transport=stdio`.
- `init`: `force=False`, `non_interactive=(--yes or not isatty)`.
- `refine`: `max_iterations=3`.
- `test`: `coverage=True`.

## Exit codes (reference)

| Module | Contract |
|---|---|
| `mcp_server.run_server` | 0 = clean shutdown; 1 = missing `mcp` package. |
| `shell_complete.generate` | Returns `str`; CLI wrapper should `print(...)` and exit 0. Raises `ValueError` on unsupported shell → exit 2. |
| `init_wizard.run_wizard` | Returns `dict`; CLI wrapper always exits 0 unless an unexpected exception surfaces. |
| `refine_pipeline.refine` / `test` / `validate` | Return `dict` with `status` in `{"ok","skipped","error","fail"}`. CLI wrapper: exit 0 when `status in {"ok","skipped"}`, else exit 1. Pass `--json` to print the dict verbatim. |
| `pipe_runner.run_with_pipe` | Returns the exit code directly (already int). |

## JSON mode

Every entry point returns structured Python objects, so the CLI can simply
`print(json.dumps(result, default=str, indent=2))` when `--json` is passed.

## Optional dependency gating

- `mcp_server` needs `mcp>=1.0`. On import failure the `run_server` returns 1
  and writes a rich hint to stderr — the CLI just surfaces the exit code.
- `refine_pipeline.validate` soft-requires `hypothesis` (and optionally
  `schemathesis`). Missing deps return `{"status":"skipped", "reason": ...}`.
- `init_wizard` uses `tomllib` (3.11+) and falls back to `tomli` when
  available; neither is required to *write* the config.

## pyproject extras (suggested; not applied by this subagent)

```toml
[project.optional-dependencies]
mcp = ["mcp>=1.0"]
test = ["hypothesis>=6.0", "schemathesis>=3.0", "pytest>=8.0"]
```
