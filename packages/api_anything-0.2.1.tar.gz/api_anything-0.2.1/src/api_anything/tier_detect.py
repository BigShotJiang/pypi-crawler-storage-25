"""Phase 0 Tier Detection — classify software by API-generation feasibility.

Tiers:
    1   ★★★★★  Python binding exists on PyPI
    2A  ★★★★   Source code available + CLI/headless mode
    2B  ★★★☆   Source code available, no CLI
    3A  ★★★    No source, UIA >=70% named controls
    3B  ★★☆    No source, UIA 30-70% named controls
    3C  ★☆     No source, UIA <30% named controls
    4   ★      Canvas/game/custom-rendered (worst case)

Runtime Coverage Audit (``runtime_probe=True``):
    Static-only probes mis-classify CEF / Electron / WebView2 shells as
    high-tier because the shell *binary* may still get picked up (e.g. a
    random same-name PyPI package claims a hit). The runtime auditor
    launches the target, walks the UIA tree, measures ``named_ratio`` and
    ``has_webview_shell``, then demotes the tier to the real story.
"""

from __future__ import annotations

import contextlib
import os
import platform
import shutil
from enum import Enum
from pathlib import Path
from typing import Any

import httpx
from pydantic import BaseModel, Field
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_PYPI_TIMEOUT = 10.0
_UIA_IMPORT_ERROR_MSG = (
    "uiautomation not installed — UIA check skipped (pip install uiautomation)"
)

# Estimated LLM tokens per tier (rough heuristic for wrapper generation cost).
_EST_TOKENS: dict[str, int] = {
    "1": 2,
    "2A": 8,
    "2B": 15,
    "3A": 25,
    "3B": 40,
    "3C": 60,
    "4": 100,
}

# Star display strings per tier.
_STARS: dict[str, str] = {
    "1": "★★★★★",
    "2A": "★★★★☆",
    "2B": "★★★☆☆",
    "3A": "★★★☆☆",
    "3B": "★★☆☆☆",
    "3C": "★☆☆☆☆",
    "4": "★☆☆☆☆",
}

_VERDICTS: dict[str, str] = {
    "1": "Direct binding — wrap and ship!",
    "2A": "Source + CLI — high confidence generation",
    "2B": "Source only — needs API surface extraction",
    "3A": "UIA-rich — reliable UI automation path",
    "3B": "UIA-partial — automation possible with gaps",
    "3C": "UIA-sparse — fragile, needs heavy heuristics",
    "4": "Pixel-level — vision model required",
}

_CONFIDENCE: dict[str, int] = {
    "1": 98,
    "2A": 90,
    "2B": 75,
    "3A": 70,
    "3B": 50,
    "3C": 30,
    "4": 15,
}


# ---------------------------------------------------------------------------
# Enums & Models
# ---------------------------------------------------------------------------


class Tier(str, Enum):
    """Software tier for API generation feasibility."""

    T1 = "1"
    T2A = "2A"
    T2B = "2B"
    T3A = "3A"
    T3B = "3B"
    T3C = "3C"
    T4 = "4"


class CheckResult(BaseModel):
    """Result of a single detection check."""

    passed: bool
    detail: str = ""
    value: float | None = None  # e.g. UIA percentage


class TierResult(BaseModel):
    """Full tier detection result for a piece of software."""

    software: str
    version: str = "unknown"
    tier: Tier
    stars: str = Field(default="")
    confidence: int = Field(default=0, ge=0, le=100)
    est_tokens_k: int = Field(
        default=0, ge=0, description="Estimated generation tokens (K)",
    )
    verdict: str = ""
    checks: dict[str, CheckResult] = Field(default_factory=dict)
    fallback_hint: str | None = Field(
        default=None,
        description=(
            "Suggestion for Tier 3C/4 targets when UI automation is unreliable — "
            "e.g. 'cli-anything-<name>' or 'vision-model'."
        ),
    )
    runtime_probed: bool = Field(
        default=False,
        description="Whether tier was refined by a live UIA walk.",
    )
    install_path: str | None = Field(
        default=None,
        description=(
            "Resolved executable path (B 項 enrich 後填入) — 若偵測過且找到，"
            "供 runtime_probe / display_router 顯示，None 表示未偵測或未找到。"
        ),
    )
    electron_suspected: bool = Field(
        default=False,
        description=(
            "Heuristic flag: PyPI 命中但無 CLI + 無 source，且 app path 指向 "
            "Electron/CEF/WebView2 shell 特徵 — suggest runtime_probe=True 修正。"
        ),
    )
    host_os: str = Field(
        default="",
        description=(
            "Platform 偵測到的 OS（Windows/Linux/Darwin），影響 UIA check 可用性。"
        ),
    )

    def model_post_init(self, __context: Any) -> None:
        """Fill derived fields from tier if not set."""
        if not self.stars:
            self.stars = _STARS.get(self.tier.value, "?")
        if not self.verdict:
            self.verdict = _VERDICTS.get(self.tier.value, "Unknown")
        if self.est_tokens_k == 0:
            self.est_tokens_k = _EST_TOKENS.get(self.tier.value, 0)
        if self.confidence == 0:
            self.confidence = _CONFIDENCE.get(self.tier.value, 0)
        if self.fallback_hint is None:
            self.fallback_hint = _fallback_hint_for(self.tier, self.software)


def _fallback_hint_for(tier: Tier, software: str) -> str | None:
    """Return a fallback suggestion for fragile tiers.

    Tier 3C → ``cli-anything-<name>`` (fall back to CLI generator).
    Tier 4  → ``vision-model`` (pixel-level automation needed).
    Higher tiers return ``None`` — the generated API is expected to work.
    """
    if tier == Tier.T3C:
        safe = "".join(c if c.isalnum() else "-" for c in software.lower()).strip("-")
        return f"cli-anything-{safe}" if safe else "cli-anything"
    if tier == Tier.T4:
        return "vision-model"
    return None


# ---------------------------------------------------------------------------
# Individual Checks
# ---------------------------------------------------------------------------


def check_pypi(name: str) -> CheckResult:
    """Check whether a Python binding exists on PyPI for *name*.

    Queries ``https://pypi.org/pypi/{name}/json`` and returns ``True`` when
    the package exists (HTTP 200).
    """
    url = f"https://pypi.org/pypi/{name}/json"
    try:
        resp = httpx.get(url, timeout=_PYPI_TIMEOUT, follow_redirects=True)
        if resp.status_code == 200:
            data = resp.json()
            version = data.get("info", {}).get("version", "?")
            return CheckResult(passed=True, detail=f"v{version} on PyPI")
        return CheckResult(passed=False, detail="not found on PyPI")
    except httpx.HTTPError as exc:
        return CheckResult(passed=False, detail=f"PyPI query failed: {exc}")


def check_source(path: str | None = None, url: str | None = None) -> CheckResult:
    """Check whether source code is accessible via local *path* or *url*.

    For a local path the directory must exist and contain at least one file.
    For a GitHub URL a HEAD request must return HTTP 200.
    """
    if path:
        p = Path(path)
        if p.is_dir() and any(p.iterdir()):
            return CheckResult(passed=True, detail=f"local: {p}")
        return CheckResult(passed=False, detail=f"path missing or empty: {p}")

    if url:
        try:
            resp = httpx.head(url, timeout=_PYPI_TIMEOUT, follow_redirects=True)
            if resp.status_code == 200:
                return CheckResult(passed=True, detail=f"repo: {url}")
            return CheckResult(passed=False, detail=f"repo HTTP {resp.status_code}")
        except httpx.HTTPError as exc:
            return CheckResult(passed=False, detail=f"repo unreachable: {exc}")

    return CheckResult(passed=False, detail="no source path or URL provided")


def check_cli(name: str) -> CheckResult:
    """Check whether *name* is available as a CLI command via ``shutil.which``."""
    location = shutil.which(name)
    if location:
        return CheckResult(passed=True, detail=location)
    return CheckResult(passed=False, detail="not found in PATH")


def check_uia(window_title: str) -> CheckResult:
    """Inspect a running window's UIA tree and return the ratio of named controls.

    Returns a ``CheckResult`` whose ``value`` is a float in [0.0, 1.0]
    representing the fraction of controls that have a non-empty ``Name``
    property.  When the ``uiautomation`` package is unavailable, the check
    is skipped gracefully.
    """
    try:
        import uiautomation as uia  # type: ignore[import-untyped]
    except ImportError:
        return CheckResult(passed=False, detail=_UIA_IMPORT_ERROR_MSG, value=0.0)

    try:
        window = uia.WindowControl(searchDepth=1, Name=window_title)
        if not window.Exists(maxSearchSeconds=3):
            return CheckResult(
                passed=False,
                detail=f"window '{window_title}' not found",
                value=0.0,
            )

        controls = window.GetChildren()
        if not controls:
            return CheckResult(passed=False, detail="no child controls", value=0.0)

        total = 0
        named = 0
        stack = list(controls)
        while stack and total < 500:  # cap to avoid perf issues
            ctrl = stack.pop()
            total += 1
            if ctrl.Name:
                named += 1
            with contextlib.suppress(Exception):
                stack.extend(ctrl.GetChildren())

        ratio = named / total if total > 0 else 0.0
        pct = int(ratio * 100)
        detail = f"{named}/{total} named ({pct}%)"
        return CheckResult(passed=ratio >= 0.3, detail=detail, value=ratio)

    except Exception as exc:
        return CheckResult(passed=False, detail=f"UIA error: {exc}", value=0.0)


# ---------------------------------------------------------------------------
# Runtime Coverage Audit
# ---------------------------------------------------------------------------


class RuntimeProbeResult(BaseModel):
    """Outcome of a live UIA walk against a launched target."""

    launched: bool = False
    exe_path: str | None = None
    pid: int | None = None
    total_controls: int = 0
    named_controls: int = 0
    named_ratio: float = 0.0
    has_webview_shell: bool = False
    detail: str = ""


# ---------------------------------------------------------------------------
# CLI alias expansion + install path heuristic (B 項新增)
# ---------------------------------------------------------------------------


def cli_alias_candidates(name: str) -> list[str]:
    """Expand *name* into likely CLI command aliases.

    為了處理 Windows 下常見的命名變體：``name`` / ``name.exe`` /
    ``name-win64`` / ``name_x64`` 等。回傳 **de-duplicated** 順序保留的
    候選清單，caller 可逐一呼叫 ``shutil.which``（單次 <1ms）。

    Examples
    --------
    >>> cli_alias_candidates("ffmpeg")
    ['ffmpeg', 'ffmpeg.exe', 'ffmpeg-win64', 'ffmpeg-win32', 'ffmpeg_x64']
    """
    base = name.strip()
    if not base:
        return []
    # 去除可能的 .exe 後綴以便展開基礎名
    lower = base.lower()
    bare = base[:-4] if lower.endswith(".exe") else base

    candidates: list[str] = [
        bare,
        f"{bare}.exe",
        f"{bare}-win64",
        f"{bare}-win32",
        f"{bare}_x64",
        f"{bare}_x86",
        f"{bare}64",
    ]
    # 保留順序同時去重
    seen: set[str] = set()
    out: list[str] = []
    for cand in candidates:
        if cand and cand not in seen:
            seen.add(cand)
            out.append(cand)
    return out


def detect_install_path(name: str) -> str | None:
    """Scan common Windows install locations for *name* executable.

    覆蓋路徑（按 B 項 RFC 要求擴充）：

    1. ``PATH`` — 透過 ``shutil.which``（含 alias 展開）
    2. Windows App Paths registry（HKLM + HKCU）
    3. ``%ProgramFiles%`` / ``%ProgramFiles(x86)%``
    4. ``%LOCALAPPDATA%\\Programs``（Electron apps 常用）
    5. Scoop: ``%USERPROFILE%\\scoop\\shims``
    6. Chocolatey: ``C:\\tools`` / ``%ChocolateyInstall%\\bin``
    7. ``C:\\Windows\\System32``

    非 Windows host 回傳 ``shutil.which(name)`` 或 ``None``。
    """
    # 0. 非 Windows：只 PATH 查
    if platform.system() != "Windows":
        return shutil.which(name)

    # 1. PATH + alias 展開
    for alias in cli_alias_candidates(name):
        via_path = shutil.which(alias)
        if via_path:
            return via_path

    # 2. Windows App Paths registry (HKLM + HKCU).
    exe = name if name.lower().endswith(".exe") else f"{name}.exe"
    with contextlib.suppress(ImportError):
        import winreg

        sub_key = rf"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{exe}"
        for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                with winreg.OpenKey(root, sub_key) as key:
                    value, _ = winreg.QueryValueEx(key, None)
                    if value and Path(value).is_file():
                        return str(value)
            except OSError:
                continue

    # 3-7. 掃常見安裝目錄（env var + 靜態路徑）
    program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
    program_files_x86 = os.environ.get(
        "ProgramFiles(x86)", r"C:\Program Files (x86)",
    )
    localappdata = os.environ.get(
        "LOCALAPPDATA",
        str(Path.home() / "AppData" / "Local"),
    )
    userprofile = os.environ.get("USERPROFILE", str(Path.home()))
    choco_install = os.environ.get("ChocolateyInstall", r"C:\ProgramData\chocolatey")

    # 候選路徑集合（保留順序）
    search_dirs: list[Path] = [
        Path(program_files) / name,
        Path(program_files_x86) / name,
        Path(localappdata) / "Programs" / name,
        Path(userprofile) / "scoop" / "shims",
        Path(userprofile) / "scoop" / "apps" / name / "current",
        Path(choco_install) / "bin",
        Path(r"C:\tools") / name,
        Path(r"C:\Windows\System32"),
    ]
    for directory in search_dirs:
        candidate = directory / exe
        if candidate.is_file():
            return str(candidate)
    return None


def _resolve_exe_path(software_name: str) -> str | None:
    """Find an executable path for *software_name*.

    Thin wrapper over :func:`detect_install_path` — 保留舊簽名方便
    ``runtime_probe_target`` 呼叫，實際邏輯已下放到 ``detect_install_path``。
    """
    return detect_install_path(software_name)


def _count_controls(
    root: object, max_controls: int = 500, max_depth: int = 3,
) -> tuple[int, int, bool]:
    """Walk a UIA tree and return ``(total, named, has_webview_shell)``.

    ``has_webview_shell`` flags a common CEF/WebView2 fingerprint: a single
    ``Pane`` or ``Document`` child whose ``AutomationId`` is ``"app"`` or
    whose name is empty while owning no meaningful descendants.
    """
    total = 0
    named = 0
    has_webview_shell = False

    # Breadth-wise but depth-capped walk.
    stack: list[tuple[object, int]] = [(root, 0)]
    while stack and total < max_controls:
        ctrl, depth = stack.pop()
        if depth > max_depth:
            continue
        total += 1
        try:
            name = getattr(ctrl, "Name", "") or ""
            automation_id = getattr(ctrl, "AutomationId", "") or ""
            control_type = getattr(ctrl, "ControlTypeName", "") or ""
        except Exception:
            continue
        if name:
            named += 1
        if (
            automation_id.lower() == "app"
            and control_type in {"PaneControl", "DocumentControl"}
        ):
            has_webview_shell = True
        with contextlib.suppress(Exception):
            for child in ctrl.GetChildren():  # type: ignore[union-attr]
                stack.append((child, depth + 1))

    return total, named, has_webview_shell


def runtime_probe_target(
    software_name: str,
    *,
    launch_timeout: float = 6.0,
    settle_time: float = 2.0,
) -> RuntimeProbeResult:
    """Launch *software_name*, walk its UIA tree, then terminate it.

    Fails gracefully — any missing dependency, unresolvable exe, or launch
    error returns a ``RuntimeProbeResult`` with ``launched=False`` and a
    descriptive ``detail`` string. The probe only kills the process it
    spawned; pre-existing instances of the software are not touched.
    """
    import subprocess
    import time

    exe_path = _resolve_exe_path(software_name)
    if not exe_path:
        return RuntimeProbeResult(
            launched=False, detail=f"exe not found for '{software_name}'",
        )

    try:
        import uiautomation as uia  # type: ignore[import-untyped]
    except ImportError:
        return RuntimeProbeResult(
            launched=False,
            exe_path=exe_path,
            detail=_UIA_IMPORT_ERROR_MSG,
        )

    proc: subprocess.Popen[bytes] | None = None
    try:
        try:
            proc = subprocess.Popen(
                [exe_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
        except (OSError, ValueError) as exc:
            return RuntimeProbeResult(
                launched=False, exe_path=exe_path, detail=f"launch failed: {exc}",
            )

        # Wait for the app to render a top-level window.
        deadline = time.monotonic() + launch_timeout
        window = None
        while time.monotonic() < deadline:
            try:
                window = uia.GetRootControl().Control(  # type: ignore[attr-defined]
                    searchDepth=1, ProcessId=proc.pid,
                )
                if window.Exists(maxSearchSeconds=1):  # type: ignore[union-attr]
                    break
            except Exception:
                pass
            time.sleep(0.25)

        if window is None or not window.Exists(maxSearchSeconds=0.5):  # type: ignore[union-attr]
            return RuntimeProbeResult(
                launched=True,
                exe_path=exe_path,
                pid=proc.pid,
                detail="window never rendered",
            )

        # Small settle to let CEF/Electron paint delayed controls.
        time.sleep(settle_time)

        total, named, has_webview = _count_controls(window)
        ratio = named / total if total > 0 else 0.0
        return RuntimeProbeResult(
            launched=True,
            exe_path=exe_path,
            pid=proc.pid,
            total_controls=total,
            named_controls=named,
            named_ratio=ratio,
            has_webview_shell=has_webview,
            detail=f"{named}/{total} named ({int(ratio * 100)}%)",
        )
    except Exception as exc:
        return RuntimeProbeResult(
            launched=proc is not None,
            exe_path=exe_path,
            pid=proc.pid if proc else None,
            detail=f"probe error: {exc}",
        )
    finally:
        if proc is not None and proc.poll() is None:
            with contextlib.suppress(Exception):
                proc.terminate()
                try:
                    proc.wait(timeout=3.0)
                except subprocess.TimeoutExpired:
                    proc.kill()


def _refine_tier_from_probe(static_tier: Tier, probe: RuntimeProbeResult) -> Tier:
    """Demote (or promote) the static tier using live probe evidence.

    Rules:
        * Tier 1/2A/2B → unchanged (PyPI/source beats UI probing).
        * WebView/CEF shell with empty UIA → force Tier 4.
        * Else classify by ``named_ratio``: ≥0.7 → 3A, ≥0.3 → 3B,
          >0 → 3C, else → 4.
    """
    if static_tier in {Tier.T1, Tier.T2A, Tier.T2B}:
        return static_tier
    if not probe.launched or probe.total_controls == 0:
        # Launched but empty tree → treat as Tier 4 (no UIA surface).
        if probe.has_webview_shell or probe.launched:
            return Tier.T4
        return static_tier
    if probe.has_webview_shell and probe.named_ratio < 0.3:
        return Tier.T4
    ratio = probe.named_ratio
    if ratio >= 0.70:
        return Tier.T3A
    if ratio >= 0.30:
        return Tier.T3B
    if ratio > 0.0:
        return Tier.T3C
    return Tier.T4


# ---------------------------------------------------------------------------
# Tier Determination
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Enrichment layer — Electron / CEF / OS guards (B 項新增)
# ---------------------------------------------------------------------------


# Electron / CEF / WebView2 shell 檔名指紋（lowercase）
_ELECTRON_PATH_MARKERS = (
    "resources\\app.asar",
    "resources/app.asar",
    "\\electron\\",
    "/electron/",
    "cefsharp",
    "libcef.dll",
    "webview2",
    "msedgewebview2",
)

# 已知 Electron app 名（小寫）— 當 PyPI 命中但明顯是 Electron shell 時提示升級
_KNOWN_ELECTRON_APPS = frozenset(
    {
        "discord",
        "slack",
        "vscode",
        "code",
        "atom",
        "signal",
        "teams",
        "obsidian",
        "notion",
        "figma",
        "spotify",
        "whatsapp",
        "skype",
        "telegram",
        "baidupan",
    },
)


def _looks_like_electron(install_path: str | None, software_name: str) -> bool:
    """Return True when *install_path* or *software_name* smells Electron/CEF.

    判斷依據：
    1. ``install_path`` 含典型 Electron 目錄片段（resources/app.asar 等）
    2. ``install_path`` 落在 ``%LOCALAPPDATA%\\Programs``（Electron installer 慣例）
    3. ``software_name`` 在已知 Electron app 清單

    ⛔ 不硬改 tier，只設 ``electron_suspected=True`` 當作 probe hint。
    """
    lower_name = software_name.lower().strip()
    if lower_name in _KNOWN_ELECTRON_APPS:
        return True

    if not install_path:
        return False
    lower_path = install_path.lower()
    if any(marker in lower_path for marker in _ELECTRON_PATH_MARKERS):
        return True
    # %LOCALAPPDATA%\Programs\<app>\<app>.exe 是 Electron squirrel 安裝器慣例
    localappdata = os.environ.get("LOCALAPPDATA", "").lower()
    if localappdata and localappdata in lower_path and "\\programs\\" in lower_path:
        return True
    return False


def _enrich_checks(
    software_name: str,
    checks: dict[str, CheckResult],
    tier: Tier,
) -> tuple[dict[str, CheckResult], Tier, str | None, bool, str]:
    """Post-process check results with OS / Electron / alias heuristics.

    **純函式，不啟動進程**。產出額外資訊供 ``TierResult`` 填入，可選擇性
    建議 tier 調整（目前只調整「CLI alias 找到但 check_cli 初次 miss」的
    case，其他僅 flag 不改 tier）。

    Returns
    -------
    tuple
        ``(enriched_checks, enriched_tier, install_path, electron_suspected, host_os)``
    """
    host_os = platform.system() or "unknown"
    enriched: dict[str, CheckResult] = dict(checks)

    # 1. 安裝路徑偵測（不論 tier）— 給 display_router / probe 使用
    install_path = detect_install_path(software_name)

    # 2. CLI alias 補救：check_cli 原本只查一次 name + name.exe；若失敗則
    #    嘗試 cli_alias_candidates 其他變體
    cli = enriched.get("cli_support")
    if cli is not None and not cli.passed and platform.system() == "Windows":
        for alias in cli_alias_candidates(software_name):
            if alias in {software_name, f"{software_name}.exe"}:
                continue  # 已被 check_cli 試過
            via = shutil.which(alias)
            if via:
                enriched["cli_support"] = CheckResult(
                    passed=True,
                    detail=f"{via} (via alias '{alias}')",
                )
                # T2B → T2A 升級（有 source 且找到 alias 版 CLI）
                source = enriched.get("source_code")
                if tier == Tier.T2B and source is not None and source.passed:
                    tier = Tier.T2A
                break

    # 3. OS guard：Linux/macOS 上 UIA 無效，標記為 skipped
    if host_os in {"Linux", "Darwin"}:
        uia = enriched.get("uia_quality")
        if uia is not None and not uia.passed and uia.value in (0.0, None):
            enriched["uia_quality"] = CheckResult(
                passed=False,
                detail=f"UIA unavailable on {host_os} — skipped",
                value=0.0,
            )

    # 4. Electron / CEF 指紋判斷
    pypi = enriched.get("python_binding")
    source = enriched.get("source_code")
    cli_after = enriched.get("cli_support")
    electron_suspected = False
    if (
        pypi is not None
        and pypi.passed
        and (source is None or not source.passed)
        and (cli_after is None or not cli_after.passed)
    ) and _looks_like_electron(install_path, software_name):
        electron_suspected = True

    # 5. Electron 指紋記入 checks dict，供報表顯示
    if electron_suspected:
        enriched["electron_fingerprint"] = CheckResult(
            passed=False,
            detail=(
                "Electron/CEF/WebView2 shell suspected — "
                "consider runtime_probe=True to verify"
            ),
        )

    return enriched, tier, install_path, electron_suspected, host_os


def _determine_tier(
    pypi: CheckResult,
    source: CheckResult,
    cli: CheckResult,
    uia: CheckResult,
) -> Tier:
    """Determine the tier from individual check results."""
    if pypi.passed:
        return Tier.T1

    if source.passed:
        if cli.passed:
            return Tier.T2A
        return Tier.T2B

    # No source — classify by UIA quality.
    uia_ratio = uia.value if uia.value is not None else 0.0
    if uia_ratio >= 0.70:
        return Tier.T3A
    if uia_ratio >= 0.30:
        return Tier.T3B
    if uia.passed or uia_ratio > 0.0:
        return Tier.T3C

    return Tier.T4


def detect_tier(
    software_name: str,
    source_path: str | None = None,
    github_url: str | None = None,
    *,
    runtime_probe: bool = False,
) -> TierResult:
    """Run all detection checks and return a complete ``TierResult``.

    Parameters
    ----------
    software_name:
        Name of the target software (used for PyPI and CLI lookups).
    source_path:
        Optional local filesystem path to the source code.
    github_url:
        Optional GitHub repository URL.
    runtime_probe:
        When ``True`` and the static path lands on Tier 3/4 (or returned
        Tier 1 solely via a same-name PyPI package while no CLI/source
        exists), launch the app, walk its UIA tree, and refine the tier.
        Defaults to ``False`` to preserve fast, side-effect-free detection.
    """
    pypi = check_pypi(software_name)
    source = check_source(path=source_path, url=github_url)
    cli = check_cli(software_name)
    uia = check_uia(software_name)

    tier = _determine_tier(pypi, source, cli, uia)

    # Extract version from PyPI if available.
    version = "unknown"
    if pypi.passed and pypi.detail.startswith("v"):
        version = pypi.detail.split(" ")[0]  # e.g. "v1.2.3"

    checks: dict[str, CheckResult] = {
        "python_binding": pypi,
        "source_code": source,
        "cli_support": cli,
        "uia_quality": uia,
    }
    runtime_probed = False

    # B 項 enrich：OS / Electron / CLI alias 後處理（純函式，不啟動進程）
    checks, tier, install_path, electron_suspected, host_os = _enrich_checks(
        software_name, checks, tier,
    )

    if runtime_probe:
        # Probe when static verdict is Tier 3/4, OR when Tier 1 was reached
        # only because a *same-name* PyPI package exists while no source
        # and no real CLI are present — the classic baidupan / random-shell
        # mis-classification. Tier 2A/2B have solid evidence, skip probe.
        weak_tier1 = tier == Tier.T1 and not source.passed and not cli.passed
        # B 項：electron_suspected 亦觸發 probe（強指紋時主動驗證）
        needs_probe = (
            tier in {Tier.T3A, Tier.T3B, Tier.T3C, Tier.T4}
            or weak_tier1
            or electron_suspected
        )
        if needs_probe:
            probe = runtime_probe_target(software_name)
            checks["runtime_probe"] = CheckResult(
                passed=probe.launched and probe.total_controls > 0,
                detail=probe.detail,
                value=probe.named_ratio,
            )
            # Weak T1 / Electron-suspected T1 → treat as T4 for refinement
            # so the probe evidence governs the final verdict.
            refine_base = (
                Tier.T4 if (weak_tier1 or electron_suspected) else tier
            )
            tier = _refine_tier_from_probe(refine_base, probe)
            runtime_probed = True

    return TierResult(
        software=software_name,
        version=version,
        tier=tier,
        checks=checks,
        runtime_probed=runtime_probed,
        install_path=install_path,
        electron_suspected=electron_suspected,
        host_os=host_os,
    )



# ---------------------------------------------------------------------------
# Rich Report
# ---------------------------------------------------------------------------


def _bar(value: float, width: int = 20) -> Text:
    """Render a coloured progress bar as Rich Text."""
    filled = int(value * width)
    empty = width - filled

    if value >= 0.7:
        colour = "green"
    elif value >= 0.3:
        colour = "yellow"
    else:
        colour = "red"

    bar = Text()
    bar.append("█" * filled, style=colour)
    bar.append("░" * empty, style="dim")
    return bar


def _check_icon(passed: bool) -> str:
    """Return a pass/fail icon."""
    return "OK" if passed else "--"


def print_report(result: TierResult, console: Console | None = None) -> None:
    """Print a beautiful Rich-formatted tier detection report.

    Parameters
    ----------
    result:
        The ``TierResult`` to display.
    console:
        Optional Rich ``Console`` instance (defaults to a new one).
    """
    if console is None:
        console = Console(force_terminal=True)

    # Header
    header = Text()
    header.append("[*] API-Anything Tier Detection\n", style="bold cyan")
    header.append("   Software: ", style="dim")
    header.append(f"{result.software}", style="bold white")
    header.append(f" {result.version}", style="dim")

    # Tier display
    tier_line = Text()
    tier_line.append("   Tier: ", style="dim")
    tier_line.append(f"{result.tier.value} ", style="bold magenta")
    tier_line.append(result.stars, style="yellow")

    # Checks table
    table = Table(show_header=False, box=None, padding=(0, 1), expand=True)
    table.add_column("icon", width=4, justify="center")
    table.add_column("label", width=16)
    table.add_column("bar", width=22)
    table.add_column("detail", ratio=1)

    check_labels = {
        "python_binding": "Python binding",
        "source_code": "Source code",
        "cli_support": "CLI support",
        "uia_quality": "UIA quality",
    }

    for key in ["source_code", "cli_support", "uia_quality", "python_binding"]:
        check = result.checks.get(key)
        if check is None:
            continue

        bar_value = 1.0 if check.passed else (check.value if check.value else 0.0)
        icon = _check_icon(check.passed)
        label = check_labels.get(key, key)
        detail = check.detail

        table.add_row(icon, label, _bar(bar_value), Text(detail, style="dim"))

    # Footer
    footer = Text()
    footer.append("\n   Confidence: ", style="dim")
    conf_style = "bold green" if result.confidence >= 70 else "bold yellow"
    footer.append(f"{result.confidence}%", style=conf_style)
    footer.append("  |  Est. tokens: ", style="dim")
    footer.append(f"~{result.est_tokens_k}K", style="bold cyan")

    verdict_icon = ">>" if result.confidence >= 70 else (
        "??" if result.confidence >= 30 else "!!"
    )
    verdict_line = Text()
    verdict_line.append(f"   Verdict: {verdict_icon} ", style="dim")
    verdict_line.append(result.verdict, style="bold white")

    # Assemble panel content
    content = Text()
    content.append_text(header)
    content.append("\n")
    content.append_text(tier_line)
    content.append("\n")

    panel = Panel(
        content,
        title="[bold cyan]api-anything[/bold cyan]",
        border_style="cyan",
        padding=(1, 2),
    )
    console.print(panel)

    # Print checks table separately inside a sub-panel for clean layout
    console.print(
        Panel(
            table,
            title="[bold]Detection Checks[/bold]",
            border_style="blue",
            padding=(0, 2),
        )
    )

    console.print(
        Panel(
            footer + Text("\n") + verdict_line,
            border_style="green" if result.confidence >= 70 else "yellow",
            padding=(0, 2),
        )
    )
