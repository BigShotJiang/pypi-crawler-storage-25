"""Pre-built Python APIs for common software.

Usage:
    from api_anything.apis import FFmpeg, Git, Docker, SQLite
    from api_anything.apis import LibreOfficeWriter, Pandoc, ImageMagick, Notepad
    from api_anything.apis import Blender, GIMP, Inkscape, Audacity, OBS
    from api_anything.apis import Kdenlive, Krita, FreeCAD, QGIS, Godot, MuseScore
    from api_anything.apis import Ollama, ComfyUI, Curl, Wget, Tar, SevenZip, Jq, Rsync
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from api_anything.apis.audacity import Audacity as Audacity
    from api_anything.apis.blender import Blender as Blender
    from api_anything.apis.comfyui import ComfyUI as ComfyUI
    from api_anything.apis.curl import Curl as Curl
    from api_anything.apis.docker import Docker as Docker
    from api_anything.apis.ffmpeg import FFmpeg as FFmpeg
    from api_anything.apis.freecad import FreeCAD as FreeCAD
    from api_anything.apis.gimp import GIMP as GIMP
    from api_anything.apis.git import Git as Git
    from api_anything.apis.godot import Godot as Godot
    from api_anything.apis.imagemagick import ImageMagick as ImageMagick
    from api_anything.apis.inkscape import Inkscape as Inkscape
    from api_anything.apis.jq import Jq as Jq
    from api_anything.apis.kdenlive import Kdenlive as Kdenlive
    from api_anything.apis.krita import Krita as Krita
    from api_anything.apis.libreoffice import LibreOfficeWriter as LibreOfficeWriter
    from api_anything.apis.musescore import MuseScore as MuseScore
    from api_anything.apis.notepad import Notepad as Notepad
    from api_anything.apis.obs import OBS as OBS
    from api_anything.apis.ollama import Ollama as Ollama
    from api_anything.apis.pandoc import Pandoc as Pandoc
    from api_anything.apis.qgis import QGIS as QGIS
    from api_anything.apis.rsync import Rsync as Rsync
    from api_anything.apis.sevenzip import SevenZip as SevenZip
    from api_anything.apis.sqlite import SQLite as SQLite
    from api_anything.apis.tar import Tar as Tar
    from api_anything.apis.wget import Wget as Wget

# Lazy imports: each API is only loaded when accessed.
# This avoids ImportError when a binary (ffmpeg, docker, etc.) or
# platform (Windows-only Notepad) is unavailable.

__all__: list[str] = []

# Registry: public name -> (module_path, class_name)
_REGISTRY: dict[str, tuple[str, str]] = {
    "FFmpeg": ("api_anything.apis.ffmpeg", "FFmpeg"),
    "Git": ("api_anything.apis.git", "Git"),
    "Docker": ("api_anything.apis.docker", "Docker"),
    "SQLite": ("api_anything.apis.sqlite", "SQLite"),
    "ImageMagick": ("api_anything.apis.imagemagick", "ImageMagick"),
    "Pandoc": ("api_anything.apis.pandoc", "Pandoc"),
    "LibreOfficeWriter": ("api_anything.apis.libreoffice", "LibreOfficeWriter"),
    "Notepad": ("api_anything.apis.notepad", "Notepad"),
    # --- v0.1 expansion: +19 APIs (total 27) ---
    "Blender": ("api_anything.apis.blender", "Blender"),
    "GIMP": ("api_anything.apis.gimp", "GIMP"),
    "Inkscape": ("api_anything.apis.inkscape", "Inkscape"),
    "Audacity": ("api_anything.apis.audacity", "Audacity"),
    "OBS": ("api_anything.apis.obs", "OBS"),
    "Kdenlive": ("api_anything.apis.kdenlive", "Kdenlive"),
    "Krita": ("api_anything.apis.krita", "Krita"),
    "FreeCAD": ("api_anything.apis.freecad", "FreeCAD"),
    "QGIS": ("api_anything.apis.qgis", "QGIS"),
    "Ollama": ("api_anything.apis.ollama", "Ollama"),
    "ComfyUI": ("api_anything.apis.comfyui", "ComfyUI"),
    "Godot": ("api_anything.apis.godot", "Godot"),
    "MuseScore": ("api_anything.apis.musescore", "MuseScore"),
    "Curl": ("api_anything.apis.curl", "Curl"),
    "Wget": ("api_anything.apis.wget", "Wget"),
    "Tar": ("api_anything.apis.tar", "Tar"),
    "SevenZip": ("api_anything.apis.sevenzip", "SevenZip"),
    "Jq": ("api_anything.apis.jq", "Jq"),
    "Rsync": ("api_anything.apis.rsync", "Rsync"),
}

# Eagerly populate __all__ with importable names
for _name, (_mod, _cls) in _REGISTRY.items():
    try:
        __import__(_mod)
        __all__.append(_name)
    except Exception:
        pass


def __getattr__(name: str) -> type:
    """Lazy-load API classes on first access."""
    if name in _REGISTRY:
        mod_path, cls_name = _REGISTRY[name]
        import importlib

        mod = importlib.import_module(mod_path)
        cls = getattr(mod, cls_name)
        # Cache on the module so __getattr__ isn't called again
        globals()[name] = cls
        return cls
    raise AttributeError(f"module 'api_anything.apis' has no attribute {name!r}")
