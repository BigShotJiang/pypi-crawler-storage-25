"""API-Anything Interactive REPL — brand-aware stateful shell.

Usage:
    api-anything repl examples/ffmpeg_api.py
    api-anything repl examples/ffmpeg_api.py --json
    api-anything repl examples/ffmpeg_api.py --resume

REPL Commands:
    .help          Show all available methods
    .json          Toggle JSON output mode
    .undo          Undo last operation (up to 50 levels)
    .redo          Redo undone operation (up to 50 levels)
    .history       Show undo/redo stack position
    .export FILE   Export session as Python script
    .replay        Replay all commands from current session
    .tier          Show Tier detection info
    .load FILE     Load another API module
    .quit          Exit REPL

Brand-aware UX:
    * Banner shows loaded API name, method count, tier, accent color.
    * Prompt format: ``<short_name>[<state>]>`` (e.g. ``ffmpeg[input.mp4]>``).
    * Dirty flag ``*`` appended after destructive unsaved calls
      (e.g. ``ffmpeg[input.mp4]*>``).
"""

from __future__ import annotations

import copy
import importlib.util
import inspect
import json
import pickle
import re
import sys
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, ClassVar

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

# v0.2.1 B: DisplayRouter unified exit (repl channel)
from api_anything.display_router import (
    DisplayRouter,
    OutputChannel,
    UnsupportedPayloadError,
)

# ---------------------------------------------------------------------------
# Optional prompt_toolkit — graceful fallback to stdlib input()
# ---------------------------------------------------------------------------

try:
    from prompt_toolkit import PromptSession
    from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
    from prompt_toolkit.completion import Completer, Completion
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.history import FileHistory

    _HAS_PROMPT_TOOLKIT = True
except ImportError:
    _HAS_PROMPT_TOOLKIT = False


# ---------------------------------------------------------------------------
# Branding tables
# ---------------------------------------------------------------------------

#: Map from short software name → rich accent color.
_ACCENT_MAP: dict[str, str] = {
    "ffmpeg": "magenta",
    "git": "dark_orange",
    "docker": "bright_blue",
    "sqlite": "cyan",
    "imagemagick": "red",
    "pandoc": "yellow",
    "libreoffice": "blue",
    "writer": "blue",
    "calc": "blue",
    "impress": "blue",
    "notepad": "green",
    "ollama": "bright_green",
    "blender": "bright_magenta",
    "gimp": "purple",
    "default": "bright_white",
}

#: Substrings that indicate a *mutating* (dirty-making) method.
_DIRTY_VERBS: tuple[str, ...] = (
    "add", "insert", "update", "set", "modify", "edit", "delete",
    "drop", "create", "append", "remove", "write", "put",
)

#: Substrings that indicate a *flush* (cleaning) method.
_CLEAN_VERBS: tuple[str, ...] = (
    "save", "commit", "flush", "export", "close", "persist", "sync",
)

#: Method-parameter names that look like the "primary subject" of a call.
_SUBJECT_PARAMS: tuple[str, ...] = (
    "file", "path", "filename", "filepath", "input", "output",
    "db", "database", "container", "image", "repo", "repository",
    "url", "target", "src", "dst", "source",
)

#: Max depth of the undo / redo snapshot stacks.
_UNDO_LIMIT: int = 50


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class HistoryEntry:
    """Single REPL command with its result."""

    command: str
    result: Any
    timestamp: float
    error: str | None = None


@dataclass
class LoadedAPI:
    """A loaded API module with its class instance and metadata."""

    name: str
    instance: Any
    cls: type
    methods: dict[str, inspect.Signature]
    module_path: str


@dataclass
class ReplSnapshot:
    """Frozen copy of the REPL state at one point in time.

    Snapshots are used by the 50-level undo / redo stacks. They capture the
    *command* that produced the state, plus best-effort deep copies of each
    API instance and the history list length at that moment.
    """

    command: str
    instance_blobs: list[bytes | Any]
    history_len: int
    dirty: bool


@dataclass
class ReplState:
    """Mutable REPL session state."""

    apis: list[LoadedAPI] = field(default_factory=list)
    active_api_index: int = 0
    json_mode: bool = False
    history: list[HistoryEntry] = field(default_factory=list)
    #: Undo stack of legacy ``HistoryEntry`` objects (kept for back-compat
    #: with ``.undo`` that simply pops the last history item). New code uses
    #: :pyattr:`undo_snapshots` / :pyattr:`redo_snapshots` instead.
    undo_stack: list[HistoryEntry] = field(default_factory=list)
    undo_snapshots: deque[ReplSnapshot] = field(
        default_factory=lambda: deque(maxlen=_UNDO_LIMIT),
    )
    redo_snapshots: deque[ReplSnapshot] = field(
        default_factory=lambda: deque(maxlen=_UNDO_LIMIT),
    )
    dirty: bool = False
    last_subject: str | None = None
    last_method: str | None = None
    running: bool = True
    session_start: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    auto_save: bool = True


# ---------------------------------------------------------------------------
# Branding helpers
# ---------------------------------------------------------------------------

def short_name(api: LoadedAPI) -> str:
    """Derive a short, lower-case brand name for *api*.

    Resolution order:
        1. Any accent-map brand found as a substring of the module stem or
           the class name (gives ``ffmpeg`` for ``demo_ffmpeg_api`` etc.).
        2. ``LibreOffice*`` variants collapse to ``writer`` / ``calc`` /
           ``impress``.
        3. Module filename stem minus ``_api`` suffix.
        4. Class name lower-cased minus trailing ``api``.
    """
    stem = Path(api.module_path).stem.lower()
    if stem.endswith("_api"):
        stem = stem[:-4]
    cls_name = api.name.lower()
    if cls_name.endswith("api"):
        cls_name = cls_name[:-3]

    # Priority 1: accent-map brand appearing as a substring.
    haystack = f"{stem} {cls_name}"
    for brand in _ACCENT_MAP:
        if brand == "default":
            continue
        if brand in haystack:
            return brand

    # Priority 2: LibreOffice sub-apps already handled above via accent map;
    # keep explicit fallbacks for any oddly named modules.
    for keyword in ("writer", "calc", "impress"):
        if keyword in stem or keyword in cls_name:
            return keyword

    # Priority 3 / 4: stem or class name.
    if stem:
        return stem.replace("_", "")
    return cls_name or "api"


def accent_color(name: str) -> str:
    """Return the rich accent color for brand *name* (``default`` if unknown)."""
    key = name.lower()
    if key in _ACCENT_MAP:
        return _ACCENT_MAP[key]
    # Secondary match on substrings (e.g. ``ffmpeg_av1`` → ``ffmpeg``).
    for brand, color in _ACCENT_MAP.items():
        if brand == "default":
            continue
        if brand in key:
            return color
    return _ACCENT_MAP["default"]


def _extract_subject(method_name: str, args_raw: str, sig: inspect.Signature | None) -> str | None:
    """Guess the "primary subject" of a call for prompt state display.

    Heuristics:
        * If *sig* has a parameter named like ``file`` / ``path`` / ``db`` /
          ``container``, extract that positional or keyword argument.
        * Otherwise return ``None`` so the caller can keep the previous
          subject (e.g. the loaded filename) visible in the prompt.

    Returning ``None`` (rather than ``method_name``) preserves the
    "I'm still inside ``input.mp4``" mental model when the user runs
    helper calls like ``trim(0, 10)`` that don't operate on a new subject.
    """
    if sig is None:
        return None
    params = list(sig.parameters.values())
    subject_idx: int | None = None
    subject_param: str | None = None
    for idx, p in enumerate(params):
        if p.name.lower() in _SUBJECT_PARAMS:
            subject_idx = idx
            subject_param = p.name
            break

    if subject_idx is None:
        return None

    # Try kwargs first.
    kw_match = re.search(
        rf"{re.escape(subject_param or '')}\s*=\s*(['\"])(.*?)\1",
        args_raw,
    )
    if kw_match:
        return Path(kw_match.group(2)).name

    # Fall back to positional: naive comma-split respecting quotes.
    positional = _split_top_level_args(args_raw)
    if subject_idx < len(positional):
        raw = positional[subject_idx].strip()
        # Strip surrounding quotes if literal string.
        m = re.match(r"""^(['"])(.*)\1$""", raw)
        if m:
            return Path(m.group(2)).name
        return raw or None

    return None


def _split_top_level_args(args_raw: str) -> list[str]:
    """Split ``"a, 'x,y', 3"`` → ``['a', "'x,y'", '3']``."""
    out: list[str] = []
    depth = 0
    buf: list[str] = []
    in_str: str | None = None
    for ch in args_raw:
        if in_str:
            buf.append(ch)
            if ch == in_str and (len(buf) < 2 or buf[-2] != "\\"):
                in_str = None
            continue
        if ch in ("'", '"'):
            in_str = ch
            buf.append(ch)
            continue
        if ch in "([{":
            depth += 1
            buf.append(ch)
            continue
        if ch in ")]}":
            depth -= 1
            buf.append(ch)
            continue
        if ch == "," and depth == 0:
            out.append("".join(buf).strip())
            buf = []
            continue
        buf.append(ch)
    tail = "".join(buf).strip()
    if tail:
        out.append(tail)
    return out


def _is_dirty_call(method_name: str) -> bool:
    """True if *method_name* looks like a mutation that leaves unsaved state."""
    lower = method_name.lower()
    if any(v in lower for v in _CLEAN_VERBS):
        return False
    return any(v in lower for v in _DIRTY_VERBS)


def _is_clean_call(method_name: str) -> bool:
    """True if *method_name* looks like a flush (save / commit / export)."""
    lower = method_name.lower()
    return any(v in lower for v in _CLEAN_VERBS)


# ---------------------------------------------------------------------------
# Snapshot helpers (50-level undo / redo)
# ---------------------------------------------------------------------------

def _freeze_instance(instance: Any) -> bytes | Any:
    """Best-effort deep snapshot of *instance*.

    Tries ``pickle`` first for a true deep clone; falls back to
    :pyfunc:`copy.copy` on pickling failure (e.g. unpicklable C extensions).
    """
    try:
        return pickle.dumps(instance)
    except (pickle.PicklingError, TypeError, AttributeError):
        try:
            return copy.copy(instance)
        except Exception:
            return instance


def _thaw_instance(blob: bytes | Any, fallback: Any) -> Any:
    """Inverse of :func:`_freeze_instance`."""
    if isinstance(blob, (bytes, bytearray)):
        try:
            return pickle.loads(blob)
        except (pickle.UnpicklingError, TypeError, AttributeError, EOFError):
            return fallback
    return blob


def _take_snapshot(state: ReplState, command: str) -> ReplSnapshot:
    """Capture a :class:`ReplSnapshot` of *state* after running *command*."""
    blobs = [_freeze_instance(api.instance) for api in state.apis]
    return ReplSnapshot(
        command=command,
        instance_blobs=blobs,
        history_len=len(state.history),
        dirty=state.dirty,
    )


def _restore_snapshot(state: ReplState, snap: ReplSnapshot) -> None:
    """Restore *state* in place from *snap*."""
    for api, blob in zip(state.apis, snap.instance_blobs, strict=False):
        api.instance = _thaw_instance(blob, api.instance)
    # Trim history back to the snapshot point.
    if snap.history_len < len(state.history):
        state.history[:] = state.history[: snap.history_len]
    state.dirty = snap.dirty


# ---------------------------------------------------------------------------
# Session persistence & config
# ---------------------------------------------------------------------------

def _get_data_dir() -> Path:
    """Return ``~/.api-anything/``, creating it if needed."""
    d = Path.home() / ".api-anything"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _get_sessions_dir() -> Path:
    d = _get_data_dir() / "sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d


def load_config(config_path: Path | None = None) -> dict[str, Any]:
    """Load REPL config from ``~/.api-anything/config.json``.

    Returns default config if the file doesn't exist.
    """
    defaults: dict[str, Any] = {
        "json_output": False,
        "history_file": str(Path.home() / ".api-anything" / "history"),
        "auto_save": True,
        "theme": "dark",
    }
    path = config_path or (_get_data_dir() / "config.json")
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                user = json.load(f)
            defaults.update(user)
        except (json.JSONDecodeError, OSError):
            pass
    return defaults


def save_config(config: dict[str, Any], config_path: Path | None = None) -> None:
    """Write config to ``~/.api-anything/config.json``."""
    path = config_path or (_get_data_dir() / "config.json")
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def _session_to_dict(state: ReplState) -> dict[str, Any]:
    """Serialize current session state to a JSON-serializable dict."""
    api = state.apis[state.active_api_index] if state.apis else None
    commands = []
    for entry in state.history:
        if entry.command.startswith("."):
            continue
        commands.append({
            "input": entry.command,
            "output": _safe_serialize(entry.result) if not entry.error else f"ERROR: {entry.error}",
            "time": datetime.fromtimestamp(entry.timestamp, tz=timezone.utc).isoformat(),
        })
    return {
        "module": api.module_path if api else "",
        "class": api.name if api else "",
        "started": state.session_start,
        "commands": commands,
    }


def _safe_serialize(obj: Any) -> Any:
    """Best-effort JSON-safe conversion."""
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        return repr(obj)


def save_session(state: ReplState, session_dir: Path | None = None) -> Path:
    """Write current session to ``sessions/{timestamp}.json``.

    Returns the path of the saved file.
    """
    d = session_dir or _get_sessions_dir()
    d.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S")
    path = d / f"{ts}.json"
    data = _session_to_dict(state)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return path


def load_session(session_dir: Path | None = None) -> dict[str, Any] | None:
    """Load the most recent session file, or *None* if none exist."""
    d = session_dir or _get_sessions_dir()
    if not d.exists():
        return None
    files = sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not files:
        return None
    with open(files[0], encoding="utf-8") as f:
        return json.load(f)


def replay_session(state: ReplState, console: Console) -> None:
    """Replay all non-dot commands from current session history."""
    api = state.apis[state.active_api_index] if state.apis else None
    if api is None:
        console.print("[red]No API loaded.[/red]")
        return
    replayed = 0
    for entry in list(state.history):
        if entry.command.startswith("."):
            continue
        console.print(f"[dim]>> {entry.command}[/dim]")
        parsed = parse_method_call(entry.command)
        if parsed is None:
            console.print("[yellow]  (skipped — invalid syntax)[/yellow]")
            continue
        method_name = parsed[0]
        paren_idx = entry.command.index("(")
        args_raw = entry.command[paren_idx + 1 : -1].strip()
        try:
            result = execute_method(api, method_name, args_raw)
            format_result(result, state.json_mode, console)
            replayed += 1
        except Exception as exc:
            console.print(f"[red]  Error: {exc}[/red]")
    console.print(f"[green]Replayed {replayed} command(s).[/green]")


# ---------------------------------------------------------------------------
# Module loading & introspection
# ---------------------------------------------------------------------------

def load_module_from_path(file_path: str) -> Any:
    """Dynamically load a Python module from a file path.

    Parameters
    ----------
    file_path:
        Absolute or relative path to a ``.py`` file.

    Returns
    -------
    module
        The imported module object.

    Raises
    ------
    FileNotFoundError
        If *file_path* does not exist.
    ImportError
        If the module cannot be loaded.
    """
    path = Path(file_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Module not found: {path}")
    if not path.suffix == ".py":
        raise ImportError(f"Not a Python file: {path}")

    module_name = path.stem
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec for {path}")

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def discover_classes(module: Any) -> list[type]:
    """Find all user-defined classes in a module.

    Filters out private classes (starting with ``_``) and classes imported
    from other packages.
    """
    classes: list[type] = []
    for name, obj in inspect.getmembers(module, inspect.isclass):
        if name.startswith("_"):
            continue
        # Only include classes actually defined in this module
        if getattr(obj, "__module__", None) == module.__name__:
            classes.append(obj)
    return classes


def get_public_methods(cls: type) -> dict[str, inspect.Signature]:
    """Return ``{name: signature}`` for all public methods of *cls*."""
    methods: dict[str, inspect.Signature] = {}
    for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
        if name.startswith("_"):
            continue
        try:
            sig = inspect.signature(method)
            # Strip 'self' parameter for display
            params = {
                k: v for k, v in sig.parameters.items() if k != "self"
            }
            methods[name] = sig.replace(parameters=list(params.values()))
        except (ValueError, TypeError):
            methods[name] = inspect.Signature()
    return methods


def build_loaded_api(module: Any, module_path: str) -> LoadedAPI:
    """Instantiate the first class in *module* and wrap it as a ``LoadedAPI``.

    Raises
    ------
    RuntimeError
        If no suitable class is found or instantiation fails.
    """
    classes = discover_classes(module)
    if not classes:
        raise RuntimeError(f"No public classes found in {module_path}")

    cls = classes[0]
    try:
        instance = cls()
    except TypeError as exc:
        raise RuntimeError(
            f"Cannot instantiate {cls.__name__}() — constructor requires arguments: {exc}"
        ) from exc

    methods = get_public_methods(cls)
    name = cls.__name__
    return LoadedAPI(
        name=name,
        instance=instance,
        cls=cls,
        methods=methods,
        module_path=module_path,
    )


# ---------------------------------------------------------------------------
# Prompt-toolkit completer (only when available)
# ---------------------------------------------------------------------------

if _HAS_PROMPT_TOOLKIT:

    class _ApiCompleter(Completer):
        """Tab-complete method names and dot-commands."""

        _DOT_COMMANDS: ClassVar[list[str]] = [
            ".help", ".json", ".undo", ".redo", ".history", ".export",
            ".replay", ".tier", ".load", ".quit",
        ]

        def __init__(self, state: ReplState) -> None:
            self._state = state

        def get_completions(self, document, complete_event):  # type: ignore[override]
            text = document.text_before_cursor.lstrip()
            # Dot-commands
            if text.startswith("."):
                for cmd in self._DOT_COMMANDS:
                    if cmd.startswith(text):
                        yield Completion(cmd, start_position=-len(text))
                return
            # Method names
            if not self._state.apis:
                return
            api = self._state.apis[self._state.active_api_index]
            word = document.get_word_before_cursor()
            for method_name in api.methods:
                if method_name.startswith(word):
                    sig = api.methods[method_name]
                    display_meta = str(sig)
                    yield Completion(
                        method_name,
                        start_position=-len(word),
                        display_meta=display_meta,
                    )


# ---------------------------------------------------------------------------
# Banner & display helpers
# ---------------------------------------------------------------------------

def _tier_info_line(module_path: str) -> str:
    """Try to detect tier for the module's target software. Best-effort."""
    try:
        from api_anything.tier_detect import detect_tier
        name = Path(module_path).stem.replace("_api", "").replace("_", " ")
        result = detect_tier(software_name=name)
        tier = result.tier.value if hasattr(result.tier, "value") else str(result.tier)
        stars_map = {
            "1": "★★★★★", "2A": "★★★★", "2B": "★★★☆",
            "3A": "★★★", "3B": "★★☆", "3C": "★☆", "4": "★",
        }
        stars = stars_map.get(tier, "?")
        mode = getattr(result, "mode", "unknown")
        return f"Tier: {tier} {stars}  |  Mode: {mode}"
    except Exception:
        return "Tier: (detection skipped)"


def _short_tier(module_path: str) -> str:
    """Return just the tier token (e.g. ``"Tier 2A"``) for banner display."""
    try:
        from api_anything.tier_detect import detect_tier
        name = Path(module_path).stem.replace("_api", "").replace("_", " ")
        result = detect_tier(software_name=name)
        tier = result.tier.value if hasattr(result.tier, "value") else str(result.tier)
        return f"Tier {tier}"
    except Exception:
        return "Tier ?"


def _count_tests_for(api: LoadedAPI) -> int | None:
    """Best-effort: count ``def test_`` occurrences in ``tests/test_<name>*``.

    Returns ``None`` if no test file is discoverable.
    """
    try:
        module_dir = Path(api.module_path).resolve().parent
        # Walk up a few levels to find a sibling ``tests`` directory.
        for base in [module_dir, *module_dir.parents][:4]:
            tests_dir = base / "tests"
            if tests_dir.exists():
                stem = Path(api.module_path).stem
                patterns = (f"test_{stem}*.py", f"test_{api.name.lower()}*.py")
                total = 0
                for pat in patterns:
                    for f in tests_dir.glob(pat):
                        text = f.read_text(encoding="utf-8", errors="ignore")
                        total += text.count("def test_")
                return total if total > 0 else None
    except OSError:
        return None
    return None


def _build_banner_panel(state: ReplState) -> Panel:
    """Construct the startup :class:`rich.panel.Panel` for *state*.

    Factored out for testability — the caller prints the returned panel.
    """
    if not state.apis:
        return Panel(Text("No APIs loaded.", style="yellow"), expand=False)

    api = state.apis[state.active_api_index]
    brand = short_name(api)
    color = accent_color(brand)
    method_count = len(api.methods)
    tier_tag = _short_tier(api.module_path)
    test_count = _count_tests_for(api)
    tests_txt = f"{test_count} tests" if test_count is not None else "tests: n/a"

    if len(state.apis) == 1:
        title = f"api-anything-{brand} v0.1.0"
        subtitle = f"Python API wrapper for {api.name}"
        stats = f"{method_count} methods · {tests_txt} · {tier_tag}"
        body = Text()
        body.append(f"{title}\n", style=f"bold {color}")
        body.append(f"{subtitle}\n", style="dim")
        body.append(stats, style=color)
        return Panel(body, border_style=color, expand=False, padding=(0, 2))

    # Multi-module layout: list all loaded APIs.
    body = Text()
    body.append("api-anything multi-module REPL\n", style="bold bright_white")
    for idx, loaded in enumerate(state.apis):
        brand_i = short_name(loaded)
        color_i = accent_color(brand_i)
        marker = "►" if idx == state.active_api_index else " "
        body.append(f"  {marker} ", style="bright_white")
        body.append(f"{brand_i}", style=f"bold {color_i}")
        body.append(f"  {len(loaded.methods)} methods  ", style="dim")
        body.append(f"({loaded.name})\n", style="dim")
    body.append("\nType .help for commands", style="dim")
    return Panel(body, border_style="bright_white", expand=False, padding=(0, 2))


def print_banner(state: ReplState, console: Console) -> None:
    """Print the startup banner showing loaded APIs and tier info."""
    console.print(_build_banner_panel(state))


def print_help(state: ReplState, console: Console) -> None:
    """Show available dot-commands and API methods."""
    # Dot-commands table
    cmd_table = Table(title="REPL Commands", show_header=True, header_style="bold magenta")
    cmd_table.add_column("Command", style="green")
    cmd_table.add_column("Description")
    for cmd, desc in [
        (".help", "Show this help"),
        (".json", "Toggle JSON output mode"),
        (".undo", "Undo last operation (up to 50 levels)"),
        (".redo", "Redo undone operation (up to 50 levels)"),
        (".history", "Show undo / redo stack position"),
        (".export FILE", "Export session as Python script"),
        (".replay", "Replay all commands from current session"),
        (".tier", "Show Tier detection info"),
        (".load FILE", "Load another API module"),
        (".quit", "Exit REPL"),
    ]:
        cmd_table.add_row(cmd, desc)
    console.print(cmd_table)

    # Methods table
    if not state.apis:
        return
    api = state.apis[state.active_api_index]
    method_table = Table(
        title=f"Methods — {api.name}", show_header=True, header_style="bold blue",
    )
    method_table.add_column("Method", style="cyan")
    method_table.add_column("Signature")
    method_table.add_column("Docstring", max_width=50)
    for name, sig in sorted(api.methods.items()):
        method_obj = getattr(api.cls, name, None)
        doc = ""
        if method_obj and method_obj.__doc__:
            doc = method_obj.__doc__.strip().split("\n")[0]
        method_table.add_row(name, str(sig), doc)
    console.print(method_table)


def format_result(result: Any, json_mode: bool, console: Console) -> None:
    """Display a method call result, optionally as JSON.

    v0.2.1 B: routes through :class:`DisplayRouter` for a single exit.
        * ``json_mode=True``  -> JSON channel (str) + rich ``Syntax`` highlight
        * ``json_mode=False`` -> REPL channel (str, no border box)

    If the router cannot render a user-returned payload (custom class,
    dataclass, numpy array, DataFrame), fall back to ``console.print(result)``
    so rich's native formatting is preserved (avoid lossy str coercion).
    """
    channel = OutputChannel.JSON if json_mode else OutputChannel.REPL
    router = DisplayRouter(channel)
    try:
        rendered = router.render(result)
    except UnsupportedPayloadError:
        # User custom class: let rich handle repr / __rich__ protocol.
        console.print(result)
        return

    if json_mode:
        # JSON channel returns str -> wrap in Syntax for monokai highlight.
        console.print(Syntax(str(rendered), "json", theme="monokai"))
    else:
        # REPL channel returns str -> print directly.
        console.print(rendered)


# ---------------------------------------------------------------------------
# Command parsing & execution
# ---------------------------------------------------------------------------

def parse_method_call(line: str) -> tuple[str, list[str], dict[str, str]] | None:
    """Parse ``method_name(arg1, arg2, key=val)`` into parts.

    Returns
    -------
    tuple or None
        ``(method_name, positional_args_raw, keyword_args_raw)`` on success,
        ``None`` if the line doesn't look like a method call.

    Note: arguments are returned as raw strings and evaluated via ``eval()``
    in a controlled scope.
    """
    line = line.strip()
    if "(" not in line:
        return None
    paren_idx = line.index("(")
    method_name = line[:paren_idx].strip()
    if not method_name.isidentifier():
        return None
    # Extract everything inside outer parens
    if not line.rstrip().endswith(")"):
        return None
    args_str = line[paren_idx + 1 : -1].strip()
    return method_name, [args_str], {}


def execute_method(
    api: LoadedAPI,
    method_name: str,
    args_raw: str,
) -> Any:
    """Call ``api.instance.<method_name>(<args_raw>)`` and return the result.

    Uses ``eval()`` to parse the arguments string in a safe-ish scope.
    """
    method = getattr(api.instance, method_name, None)
    if method is None:
        raise AttributeError(f"No method '{method_name}' on {api.name}")

    if not args_raw.strip():
        return method()

    # Build a call expression and eval it
    # This is intentional — the REPL is a developer tool, not a sandbox.
    call_expr = f"__method__({args_raw})"
    result = eval(
        call_expr, {"__builtins__": __builtins__, "__method__": method},
    )
    return result


def export_session(state: ReplState, filepath: str, console: Console) -> None:
    """Write session history as an executable Python script."""
    if not state.apis:
        console.print("[red]No APIs loaded.[/red]")
        return

    api = state.apis[state.active_api_index]
    lines = [
        f'"""Auto-generated by API-Anything REPL — {time.strftime("%Y-%m-%d %H:%M:%S")}"""',
        "",
        f"# Source module: {api.module_path}",
        f"from {Path(api.module_path).stem} import {api.name}",
        "",
        f"api = {api.name}()",
        "",
    ]
    cmd_count = 0
    for entry in state.history:
        if entry.command.startswith("."):
            continue
        lines.append(f"# [{time.strftime('%H:%M:%S', time.localtime(entry.timestamp))}]")
        if entry.error:
            lines.append(f"# ERROR: {entry.error}")
            lines.append(f"# {entry.command}")
        else:
            # Rewrite method(args) as api.method(args)
            cmd = entry.command
            lines.append(f"result = api.{cmd}")
            lines.append("print(result)")
        lines.append("")
        cmd_count += 1

    out = Path(filepath)
    out.write_text("\n".join(lines), encoding="utf-8")
    console.print(f"[green]Exported {cmd_count} commands to {out}[/green]")


def _do_undo(state: ReplState, console: Console) -> None:
    """Handle ``.undo`` — snapshot stack first, legacy history fallback."""
    if state.undo_snapshots:
        snap = state.undo_snapshots.pop()
        state.redo_snapshots.append(_take_snapshot(state, snap.command))
        _restore_snapshot(state, snap)
        console.print(f"[cyan]Undone: {snap.command}[/cyan]")
        return
    if not state.history:
        console.print("[yellow]Nothing to undo.[/yellow]")
        return
    entry = state.history.pop()
    state.undo_stack.append(entry)
    console.print(f"[cyan]Undone: {entry.command}[/cyan]")


def _do_redo(state: ReplState, console: Console) -> None:
    """Handle ``.redo`` — snapshot stack first, legacy history fallback."""
    if state.redo_snapshots:
        snap = state.redo_snapshots.pop()
        state.undo_snapshots.append(_take_snapshot(state, snap.command))
        _restore_snapshot(state, snap)
        console.print(f"[cyan]Redone: {snap.command}[/cyan]")
        return
    if not state.undo_stack:
        console.print("[yellow]Nothing to redo.[/yellow]")
        return
    entry = state.undo_stack.pop()
    state.history.append(entry)
    console.print(f"[cyan]Redone: {entry.command}[/cyan]")


def _do_history(state: ReplState, console: Console) -> None:
    """Handle ``.history`` — report undo / redo stack depth."""
    undo_n = len(state.undo_snapshots)
    redo_n = len(state.redo_snapshots)
    total = len(state.history)
    console.print(
        f"[cyan]History: {total} entries  |  undo stack: {undo_n}/{_UNDO_LIMIT}  "
        f"|  redo stack: {redo_n}/{_UNDO_LIMIT}[/cyan]"
    )


def _do_load(arg: str, state: ReplState, console: Console) -> None:
    """Handle ``.load MODULE_PATH`` — append a new API to the state."""
    if not arg:
        console.print("[red]Usage: .load MODULE_PATH[/red]")
        return
    try:
        module = load_module_from_path(arg)
        loaded = build_loaded_api(module, arg)
    except Exception as exc:
        console.print(f"[red]Failed to load {arg}: {exc}[/red]")
        return
    state.apis.append(loaded)
    state.active_api_index = len(state.apis) - 1
    console.print(
        f"[green]Loaded {loaded.name} ({len(loaded.methods)} methods) "
        f"from {arg}[/green]"
    )


def _do_tier(state: ReplState, console: Console) -> None:
    """Handle ``.tier`` — print detection info for the active API."""
    if not state.apis:
        console.print("[yellow]No API loaded.[/yellow]")
        return
    api = state.apis[state.active_api_index]
    console.print(f"[cyan]{_tier_info_line(api.module_path)}[/cyan]")


def _do_json(state: ReplState, console: Console) -> None:
    """Handle ``.json`` — toggle JSON output mode."""
    state.json_mode = not state.json_mode
    status = "ON" if state.json_mode else "OFF"
    console.print(f"[cyan]JSON output: {status}[/cyan]")


def _do_export(arg: str, state: ReplState, console: Console) -> None:
    """Handle ``.export FILE`` — write the session as a Python script."""
    if not arg:
        console.print("[red]Usage: .export FILENAME[/red]")
        return
    export_session(state, arg, console)


#: Dispatch table: dot-command name → handler taking ``(state, console)``.
_DOT_HANDLERS: dict[str, Any] = {
    ".help": lambda arg, st, co: print_help(st, co),
    ".json": lambda arg, st, co: _do_json(st, co),
    ".undo": lambda arg, st, co: _do_undo(st, co),
    ".redo": lambda arg, st, co: _do_redo(st, co),
    ".history": lambda arg, st, co: _do_history(st, co),
    ".export": lambda arg, st, co: _do_export(arg, st, co),
    ".replay": lambda arg, st, co: replay_session(st, co),
    ".tier": lambda arg, st, co: _do_tier(st, co),
    ".load": lambda arg, st, co: _do_load(arg, st, co),
}


def handle_dot_command(line: str, state: ReplState, console: Console) -> None:
    """Process dot-commands (``.help``, ``.json``, etc.).

    Dispatches to a handler in :pydata:`_DOT_HANDLERS`; ``.quit`` / ``.exit``
    / ``.q`` are handled inline since they only flip a flag.
    """
    parts = line.strip().split(maxsplit=1)
    cmd = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    handler = _DOT_HANDLERS.get(cmd)
    if handler is not None:
        handler(arg, state, console)
        return

    if cmd in (".quit", ".exit", ".q"):
        state.running = False
        return

    console.print(f"[red]Unknown command: {cmd}. Type .help[/red]")


# ---------------------------------------------------------------------------
# Main REPL loop
# ---------------------------------------------------------------------------

def build_prompt_text(state: ReplState) -> str:
    """Build the brand-aware prompt string.

    Format: ``<short>[<subject>]<dirty>> `` (with trailing space).
    If no API is loaded, returns ``"api> "`` as a safe fallback.
    """
    if not state.apis:
        return "api> "
    api = state.apis[state.active_api_index]
    brand = short_name(api)
    parts = [brand]
    subject = state.last_subject or state.last_method
    if subject:
        parts.append(f"[{subject}]")
    dirty_marker = "*" if state.dirty else ""
    return f"{''.join(parts)}{dirty_marker}> "


# Back-compat private alias kept for any callers.
def _get_prompt_text(state: ReplState) -> str:
    """Deprecated: use :func:`build_prompt_text`."""
    return build_prompt_text(state)


def _create_prompt_session(state: ReplState) -> Any | None:
    """Create a ``prompt_toolkit.PromptSession`` if available.

    Falls back to ``None`` (stdlib ``input()``) when stdin/stdout is not a
    TTY (pipes, subprocess, CI) or when prompt_toolkit fails to initialise a
    console buffer (e.g. Windows under xterm emulators like git-bash).
    """
    if not _HAS_PROMPT_TOOLKIT:
        return None
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return None

    history_path = Path.home() / ".api_anything_history"
    completer = _ApiCompleter(state)

    try:
        return PromptSession(
            history=FileHistory(str(history_path)),
            auto_suggest=AutoSuggestFromHistory(),
            completer=completer,
            complete_while_typing=False,
        )
    except Exception:
        return None


def _init_state(
    module_paths: list[str],
    *,
    json_mode: bool,
    resume: bool,
    console: Console,
    session_dir: Path | None,
    config_path: Path | None,
) -> ReplState | None:
    """Load config + modules + optional resume. Returns ``None`` on failure."""
    config = load_config(config_path)
    if json_mode is False and config.get("json_output"):
        json_mode = True
    auto_save = config.get("auto_save", True)

    state = ReplState(json_mode=json_mode, auto_save=auto_save)

    for mp in module_paths:
        try:
            module = load_module_from_path(mp)
            loaded = build_loaded_api(module, mp)
            state.apis.append(loaded)
        except Exception as exc:
            console.print(f"[red]Error loading {mp}: {exc}[/red]")

    if not state.apis:
        console.print("[red]No APIs loaded. Exiting.[/red]")
        return None

    if resume:
        _apply_resume(state, session_dir, console)
    return state


def _apply_resume(
    state: ReplState,
    session_dir: Path | None,
    console: Console,
) -> None:
    """If ``--resume``, replay command history from the most recent session."""
    prev = load_session(session_dir)
    if not (prev and prev.get("commands")):
        console.print("[yellow]No previous session found.[/yellow]")
        return
    console.print(
        f"[cyan]Resuming session from {prev.get('started', '?')} "
        f"({len(prev['commands'])} commands)[/cyan]"
    )
    for cmd_entry in prev["commands"]:
        inp = cmd_entry.get("input", "")
        if not inp:
            continue
        state.history.append(HistoryEntry(
            command=inp,
            result=cmd_entry.get("output"),
            timestamp=time.time(),
        ))


def _read_line(state: ReplState, session: Any | None) -> str | None:
    """Prompt the user for a single line. Returns ``None`` on EOF/^C."""
    prompt_str = build_prompt_text(state)
    api_for_color = state.apis[state.active_api_index] if state.apis else None
    color = accent_color(short_name(api_for_color)) if api_for_color else "bright_white"
    try:
        if session is not None:
            pt_color = _rich_to_pt_color(color)
            return session.prompt(HTML(f"<{pt_color}>{prompt_str}</{pt_color}>"))
        return input(prompt_str)
    except (EOFError, KeyboardInterrupt):
        return None


def _update_prompt_hints(
    state: ReplState,
    method_name: str,
    args_raw: str,
    sig: inspect.Signature | None,
) -> None:
    """Update ``last_method`` / ``last_subject`` / ``dirty`` on *state*."""
    state.last_method = method_name
    subject = _extract_subject(method_name, args_raw, sig)
    if subject:
        state.last_subject = subject
    if _is_clean_call(method_name):
        state.dirty = False
    elif _is_dirty_call(method_name):
        state.dirty = True


def _run_method_call(line: str, state: ReplState, console: Console) -> None:
    """Parse + dispatch a single ``method(args)`` line with snapshot + history."""
    parsed = parse_method_call(line)
    if parsed is None:
        console.print("[red]Invalid syntax. Expected: method(args) or .command[/red]")
        return

    method_name, _, _ = parsed
    api = state.apis[state.active_api_index]
    sig: inspect.Signature | None = api.methods.get(method_name)
    if sig is not None:
        console.print(f"[dim]{method_name}{sig}[/dim]")

    paren_idx = line.index("(")
    args_raw = line[paren_idx + 1 : -1].strip()

    t0 = time.monotonic()
    state.undo_snapshots.append(_take_snapshot(state, line))
    state.redo_snapshots.clear()
    try:
        result = execute_method(api, method_name, args_raw)
    except Exception as exc:
        state.history.append(HistoryEntry(
            command=line, result=None, timestamp=time.time(), error=str(exc),
        ))
        state.undo_stack.clear()
        if state.undo_snapshots:
            state.undo_snapshots.pop()
        console.print(f"[red]Error: {exc}[/red]")
        return

    elapsed = time.monotonic() - t0
    state.history.append(HistoryEntry(
        command=line, result=result, timestamp=time.time(),
    ))
    state.undo_stack.clear()
    _update_prompt_hints(state, method_name, args_raw, sig)
    format_result(result, state.json_mode, console)
    if elapsed > 0.5:
        console.print(f"[dim]({elapsed:.1f}s)[/dim]")


def run_repl(
    module_paths: list[str],
    *,
    json_mode: bool = False,
    resume: bool = False,
    console: Console | None = None,
    session_dir: Path | None = None,
    config_path: Path | None = None,
) -> int:
    """Launch the interactive REPL.

    Parameters
    ----------
    module_paths:
        One or more paths to Python API modules to load.
    json_mode:
        Start with JSON output enabled.
    resume:
        If *True*, load the most recent session and replay its commands.
    console:
        Rich console for output (created if not supplied).
    session_dir:
        Override session storage directory (for testing).
    config_path:
        Override config file path (for testing).

    Returns
    -------
    int
        Exit code (0 = clean exit).
    """
    if console is None:
        console = Console()

    state = _init_state(
        module_paths,
        json_mode=json_mode,
        resume=resume,
        console=console,
        session_dir=session_dir,
        config_path=config_path,
    )
    if state is None:
        return 1

    print_banner(state, console)
    session = _create_prompt_session(state)

    while state.running:
        raw = _read_line(state, session)
        if raw is None:
            console.print("\n[dim]Bye![/dim]")
            break
        line = raw.strip()
        if not line:
            continue
        if line.startswith("."):
            handle_dot_command(line, state, console)
            continue
        _run_method_call(line, state, console)

    if state.auto_save and state.history:
        try:
            saved = save_session(state, session_dir)
            console.print(f"[dim]Session saved: {saved}[/dim]")
        except OSError as exc:
            console.print(f"[yellow]Could not save session: {exc}[/yellow]")

    return 0


# ---------------------------------------------------------------------------
# Misc helpers
# ---------------------------------------------------------------------------

def _rich_to_pt_color(rich_color: str) -> str:
    """Map a rich accent-color name to a ``prompt_toolkit`` HTML tag.

    ``prompt_toolkit`` only understands ``ansi*`` tags, so we collapse the
    rich palette down to its nearest ANSI equivalent.
    """
    mapping = {
        "magenta": "ansimagenta",
        "bright_magenta": "ansibrightmagenta",
        "dark_orange": "ansiyellow",
        "yellow": "ansiyellow",
        "bright_blue": "ansibrightblue",
        "blue": "ansiblue",
        "cyan": "ansicyan",
        "bright_cyan": "ansibrightcyan",
        "red": "ansired",
        "bright_red": "ansibrightred",
        "green": "ansigreen",
        "bright_green": "ansibrightgreen",
        "purple": "ansimagenta",
        "bright_white": "ansiwhite",
        "default": "ansigreen",
    }
    return mapping.get(rich_color, "ansigreen")
