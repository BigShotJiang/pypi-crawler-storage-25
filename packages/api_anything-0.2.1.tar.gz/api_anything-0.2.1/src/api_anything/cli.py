"""CLI entry point for api-anything.

Subcommand dispatch uses a dict so each handler stays ≤40 lines and
``_build_parser`` stays thin (loops over subparser builders).
"""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Callable

from rich.console import Console

from api_anything.display_router import DisplayRouter, OutputChannel
from api_anything.skill_gen import generate_skill_md
from api_anything.tier_detect import detect_tier, print_report

# ---------------------------------------------------------------------------
# Subparser builders
# ---------------------------------------------------------------------------


def _add_detect(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("detect", help="Detect the tier of a target software")
    p.add_argument("software", help="Name of the target software (e.g. notepad, ffmpeg)")
    p.add_argument("--source", default=None, help="Local path to source code")
    p.add_argument("--github", default=None, help="GitHub repository URL")
    p.add_argument(
        "--json", dest="json_output", action="store_true", default=False,
        help="Output result as JSON instead of Rich report",
    )
    p.add_argument(
        "--probe", dest="runtime_probe", action="store_true", default=False,
        help=(
            "Runtime coverage audit — launch the app, walk its UIA tree, then "
            "refine the tier. Slower, but avoids same-name PyPI mis-classification."
        ),
    )


def _add_skill(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("skill", help="Generate SKILL.md from a Python API module")
    p.add_argument("module", help="Path to .py file or dotted module name")
    p.add_argument("-o", "--output", default=None, help="Output file path (default: stdout)")
    p.add_argument(
        "--json", dest="json_output", action="store_true", default=False,
        help="Output generation metadata as JSON",
    )


def _add_repl(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("repl", help="Launch interactive REPL with a generated API")
    p.add_argument("module", nargs="+", help="Path(s) to Python API module(s)")
    p.add_argument(
        "--json", dest="json_mode", action="store_true", default=False,
        help="Start in JSON output mode",
    )
    p.add_argument(
        "--resume", action="store_true", default=False,
        help="Resume the most recent session",
    )


def _add_run(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("run", help="One-shot: run a method on an API without entering REPL")
    p.add_argument("module", help="Path to Python API module (.py) or built-in name")
    p.add_argument("method", help="Method name to call")
    p.add_argument("args", nargs="*", help="Positional arguments for the method")
    p.add_argument(
        "--json", dest="json_output", action="store_true", default=False,
        help="Output result as JSON",
    )


def _add_list(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("list", help="Show all available built-in APIs")
    p.add_argument(
        "--detail", action="store_true", default=False,
        help="Show method counts and descriptions",
    )


def _add_generate(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("generate", help="Generate a Python API (v0.2)")
    p.add_argument("module", help="Target module or software name")
    p.add_argument(
        "--json", dest="json_output", action="store_true", default=False,
        help="Output GenerationResult as JSON",
    )


def _add_web(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("web", help="Launch the Gradio web UI (demo/onboarding)")
    p.add_argument("--port", type=int, default=7860, help="HTTP port (default: 7860)")
    p.add_argument(
        "--share", action="store_true", default=False,
        help="Create a public Gradio share link",
    )


def _add_refine(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("refine", help="Iteratively expand an API module's coverage")
    p.add_argument("api_path", help="Path to Python API module to refine")
    p.add_argument("--max-iter", type=int, default=3, help="Max refinement iterations")
    p.add_argument(
        "--json", dest="json_output", action="store_true", default=False,
        help="Output result as JSON",
    )


def _add_test(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("test", help="Run pytest tests for an API module")
    p.add_argument("api_path", help="Path to Python API module (.py)")
    p.add_argument(
        "--no-coverage", dest="coverage", action="store_false", default=True,
        help="Disable coverage report",
    )
    p.add_argument(
        "--json", dest="json_output", action="store_true", default=False,
        help="Output result as JSON",
    )


def _add_validate(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "validate", help="Run property-based validation (schemathesis/hypothesis)",
    )
    p.add_argument("api_path", help="Path to Python API module (.py)")
    p.add_argument(
        "--json", dest="json_output", action="store_true", default=False,
        help="Output result as JSON",
    )


def _add_mcp(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser(
        "mcp-serve", help="Run MCP server exposing all built-in APIs as tools",
    )
    p.add_argument("--host", default="127.0.0.1", help="Host (sse/http only)")
    p.add_argument("--port", type=int, default=8765, help="Port (sse/http only)")
    p.add_argument(
        "--transport", choices=["stdio", "sse", "http"], default="stdio",
        help="MCP transport (default: stdio)",
    )


def _add_completions(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("completions", help="Generate shell completion script")
    p.add_argument("shell", choices=["bash", "zsh", "fish"], help="Target shell")


def _add_init(sub: argparse._SubParsersAction) -> None:
    p = sub.add_parser("init", help="First-run interactive setup wizard")
    p.add_argument(
        "--force", action="store_true", default=False,
        help="Re-run wizard even if config already exists",
    )
    p.add_argument(
        "--yes", "-y", dest="non_interactive", action="store_true", default=False,
        help="Accept all defaults (non-interactive mode)",
    )


_SUBPARSER_BUILDERS: list[Callable[[argparse._SubParsersAction], None]] = [
    _add_detect, _add_skill, _add_repl, _add_run, _add_list,
    _add_generate, _add_web, _add_refine, _add_test, _add_validate,
    _add_mcp, _add_completions, _add_init,
]


def _build_parser() -> argparse.ArgumentParser:
    """Build the top-level argument parser."""
    parser = argparse.ArgumentParser(
        prog="api-anything",
        description="Auto-generate Python APIs from any software.",
    )
    sub = parser.add_subparsers(dest="command", required=True)
    for add_fn in _SUBPARSER_BUILDERS:
        add_fn(sub)
    return parser


# ---------------------------------------------------------------------------
# Shared helpers -- registry + rich table
# ---------------------------------------------------------------------------


_API_META: dict[str, dict[str, str]] = {
    "FFmpeg": {"tier": "2A", "desc": "Video/audio conversion, trimming, compression"},
    "Git": {"tier": "2A", "desc": "Git version control operations"},
    "Docker": {"tier": "2A", "desc": "Container management"},
    "SQLite": {"tier": "1", "desc": "Database operations (stdlib)"},
    "ImageMagick": {"tier": "2A", "desc": "Image processing and conversion"},
    "Pandoc": {"tier": "2A", "desc": "Document format conversion"},
    "LibreOfficeWriter": {"tier": "2A", "desc": "Document creation and export"},
    "Notepad": {"tier": "3A", "desc": "Windows Notepad control (UIA)"},
    "Blender": {"tier": "2A", "desc": "3D modelling and rendering"},
    "GIMP": {"tier": "2A", "desc": "Raster image editing via Script-Fu"},
    "Inkscape": {"tier": "2A", "desc": "SVG vector graphics conversion"},
    "Audacity": {"tier": "3B", "desc": "Audio editing via mod-script-pipe"},
    "OBS": {"tier": "2B", "desc": "Streaming/recording via obs-websocket v5"},
    "Kdenlive": {"tier": "3B", "desc": "Video editing (MLT render + XML project)"},
    "Krita": {"tier": "3B", "desc": "Digital painting, batch export"},
    "FreeCAD": {"tier": "2A", "desc": "Parametric CAD + STEP/STL/IGES export"},
    "QGIS": {"tier": "2A", "desc": "GIS processing via qgis_process"},
    "Ollama": {"tier": "1", "desc": "Local LLM runtime (REST API)"},
    "ComfyUI": {"tier": "1", "desc": "Stable Diffusion workflows (REST API)"},
    "Godot": {"tier": "2A", "desc": "Game engine export + headless scripts"},
    "MuseScore": {"tier": "2A", "desc": "Music notation convert/export"},
    "Curl": {"tier": "2A", "desc": "HTTP client (GET/POST/download/upload)"},
    "Wget": {"tier": "2A", "desc": "Download, mirror, resume"},
    "Tar": {"tier": "1", "desc": "Tar archive create/extract (stdlib)"},
    "SevenZip": {"tier": "2A", "desc": "Multi-format archive compression"},
    "Jq": {"tier": "2A", "desc": "JSON query and transformation"},
    "Rsync": {"tier": "2A", "desc": "Fast file sync and mirror"},
}


def _count_public_methods(cls: type) -> int:
    """Count public methods (not dunder, not private) on a class."""
    return sum(
        1
        for name in dir(cls)
        if not name.startswith("_") and callable(getattr(cls, name, None))
    )


def _list_apis(
    console: Console,
    registry: dict[str, tuple[str, str]],
    available: list[str],
    *,
    detail: bool = False,
) -> None:
    """Print a table of available built-in APIs."""
    import importlib

    from rich.table import Table

    table = Table(title=f"Available APIs ({len(available)} built-in)", show_header=detail)
    table.add_column("Name", style="cyan", min_width=18)
    table.add_column("Tier", justify="center")
    if detail:
        table.add_column("Methods", justify="right")
        table.add_column("Description")

    total_methods = 0
    for name in registry:
        meta = _API_META.get(name, {"tier": "?", "desc": ""})
        dimmed = name not in available
        display_name = f"[dim]{name}[/dim]" if dimmed else name
        row = [display_name, meta["tier"]]
        if detail:
            if dimmed:
                row += ["-", "[dim]not available[/dim]"]
            else:
                mod_path, cls_name = registry[name]
                cls = getattr(importlib.import_module(mod_path), cls_name)
                n = _count_public_methods(cls)
                total_methods += n
                row += [str(n), meta["desc"]]
        table.add_row(*row)

    console.print(table)
    if detail:
        console.print(f"\n  Total: {len(available)} APIs, {total_methods} methods")


# ---------------------------------------------------------------------------
# Command handlers -- one function per subcommand, return exit code
# ---------------------------------------------------------------------------


def _cmd_detect(args: argparse.Namespace, console: Console) -> int:
    result = detect_tier(
        software_name=args.software,
        source_path=args.source,
        github_url=args.github,
        runtime_probe=args.runtime_probe,
    )
    if args.json_output:
        print(result.model_dump_json(indent=2))
    else:
        print_report(result, console=console)
    return 0


def _cmd_skill(args: argparse.Namespace, console: Console) -> int:
    try:
        content = generate_skill_md(module_path=args.module, output_path=args.output)
    except (ImportError, ValueError) as exc:
        if args.json_output:
            print(json.dumps({"error": str(exc)}, indent=2))
        else:
            console.print(f"[red]Error:[/red] {exc}")
        return 1

    if args.json_output:
        print(json.dumps({"output_path": args.output, "content": content}, indent=2))
    elif args.output:
        console.print(f"[green]SKILL.md written to {args.output}[/green]")
    else:
        print(content)
    return 0


def _cmd_repl(args: argparse.Namespace, console: Console) -> int:
    from api_anything.repl import run_repl
    return run_repl(
        args.module, json_mode=args.json_mode, resume=args.resume, console=console,
    )


def _load_builtin_as_api(name: str):
    """Instantiate a built-in API and wrap it in a LoadedAPI."""
    import importlib
    import inspect

    from api_anything.apis import _REGISTRY
    from api_anything.repl import LoadedAPI

    match = next(k for k in _REGISTRY if k.lower() == name.lower())
    mod_path, cls_name = _REGISTRY[match]
    cls = getattr(importlib.import_module(mod_path), cls_name)
    instance = cls()
    methods = {
        n: inspect.signature(m)
        for n, m in inspect.getmembers(instance, inspect.ismethod)
        if not n.startswith("_")
    }
    return LoadedAPI(
        name=match, instance=instance, cls=cls, methods=methods, module_path=mod_path,
    )


def _cmd_run(args: argparse.Namespace, console: Console) -> int:
    from api_anything.apis import _REGISTRY
    from api_anything.repl import (
        build_loaded_api,
        execute_method,
        format_result,
        load_module_from_path,
    )

    try:
        if args.module.lower() in {k.lower() for k in _REGISTRY}:
            api = _load_builtin_as_api(args.module)
        else:
            module = load_module_from_path(args.module)
            api = build_loaded_api(module, args.module)
    except Exception as exc:
        console.print(f"[red]Error loading {args.module}: {exc}[/red]")
        return 1

    args_raw = ", ".join(args.args) if args.args else ""
    try:
        result = execute_method(api, args.method, args_raw)
        format_result(result, args.json_output, console)
        return 0
    except Exception as exc:
        console.print(f"[red]Error: {exc}[/red]")
        return 1


def _cmd_list(args: argparse.Namespace, console: Console) -> int:
    from api_anything.apis import _REGISTRY
    from api_anything.apis import __all__ as available_apis

    _list_apis(console, _REGISTRY, available_apis, detail=args.detail)
    return 0


def _cmd_generate(args: argparse.Namespace, console: Console) -> int:
    # v0.2 C: generate 走 display_router，統一出口（D 項才會填真實 payload）
    channel = OutputChannel.JSON if args.json_output else OutputChannel.CLI
    router = DisplayRouter(channel)
    stub_payload = {
        "status": "not_implemented",
        "module": args.module,
        "hint": "LLM-driven generate lands in v0.2 D",
    }
    out = router.render(stub_payload, title="Generate (stub)")
    if isinstance(out, str):
        print(out)
    else:
        console.print(out)
    return 0


def _cmd_web(args: argparse.Namespace, console: Console) -> int:
    try:
        from api_anything.web import main as web_main
    except ImportError:
        console.print(
            "[red]gradio is required for the web UI.[/red]\n"
            "  pip install api-anything[web]"
        )
        return 1
    web_main(port=args.port, share=args.share)
    return 0


def _cmd_refine(args: argparse.Namespace, console: Console) -> int:
    from pathlib import Path

    from api_anything.refine_pipeline import refine
    result = refine(Path(args.api_path), max_iterations=args.max_iter)
    if args.json_output:
        print(json.dumps(result, indent=2, default=str))
    else:
        console.print(result)
    return 0 if result.get("status") != "error" else 1


def _cmd_test(args: argparse.Namespace, console: Console) -> int:
    from pathlib import Path

    from api_anything.refine_pipeline import test as run_test
    result = run_test(Path(args.api_path), coverage=args.coverage)
    if args.json_output:
        print(json.dumps(result, indent=2, default=str))
    else:
        console.print(result)
    return 0 if result.get("status") not in {"error", "failed"} else 1


def _cmd_validate(args: argparse.Namespace, console: Console) -> int:
    from pathlib import Path

    from api_anything.refine_pipeline import validate
    result = validate(Path(args.api_path))
    if args.json_output:
        print(json.dumps(result, indent=2, default=str))
    else:
        console.print(result)
    return 0 if result.get("status") not in {"error", "failed"} else 1


def _cmd_mcp_serve(args: argparse.Namespace, console: Console) -> int:
    from api_anything.mcp_server import run_server
    return run_server(host=args.host, port=args.port, transport=args.transport)


def _cmd_completions(args: argparse.Namespace, console: Console) -> int:
    from api_anything.shell_complete import generate
    print(generate(args.shell, parser=_build_parser()))
    return 0


def _cmd_init(args: argparse.Namespace, console: Console) -> int:
    from api_anything.init_wizard import run_wizard
    run_wizard(
        console=console, force=args.force, non_interactive=args.non_interactive,
    )
    return 0


_CMD_HANDLERS: dict[str, Callable[[argparse.Namespace, Console], int]] = {
    "detect": _cmd_detect,
    "skill": _cmd_skill,
    "repl": _cmd_repl,
    "run": _cmd_run,
    "list": _cmd_list,
    "generate": _cmd_generate,
    "web": _cmd_web,
    "refine": _cmd_refine,
    "test": _cmd_test,
    "validate": _cmd_validate,
    "mcp-serve": _cmd_mcp_serve,
    "completions": _cmd_completions,
    "init": _cmd_init,
}


def main(argv: list[str] | None = None) -> int:
    """CLI entry point.

    Parameters
    ----------
    argv:
        Command-line arguments (defaults to ``sys.argv[1:]``).

    Returns
    -------
    int
        Exit code (0 = success).
    """
    parser = _build_parser()
    args = parser.parse_args(argv)
    console = Console()
    handler = _CMD_HANDLERS.get(args.command)
    if handler is None:
        parser.print_help()
        return 1
    return handler(args, console)


if __name__ == "__main__":
    sys.exit(main())
