"""MCP server — expose every api-anything registry API as MCP tools.

Starts an `mcp <https://pypi.org/project/mcp/>`_ server and dynamically
registers one tool per public method on every class in
:data:`api_anything.apis._REGISTRY`.

Transports
----------
- ``stdio`` (default) — Claude Desktop / Cursor MCP client.
- ``sse``             — HTTP Server-Sent Events for web agents.
- ``http``            — plain HTTP streamable transport (newer mcp SDK).

Failure modes
-------------
The server is designed not to crash when a backing binary is missing. Each
tool invocation is wrapped: import failures, binary-not-found errors, and
unhandled exceptions are converted into structured responses like::

    {"error": "ffmpeg not found", "install_hint": "https://ffmpeg.org/..."}

so clients can surface a helpful message without the whole server dying.
"""

from __future__ import annotations

import importlib
import inspect
import logging
import shutil
from typing import Any

logger = logging.getLogger(__name__)

try:  # pragma: no cover - trivial import guard
    from mcp.server.fastmcp import FastMCP  # type: ignore[import-not-found]

    _HAS_MCP = True
except ModuleNotFoundError:  # pragma: no cover
    _HAS_MCP = False
    FastMCP = None  # type: ignore[assignment,misc]


# ---------------------------------------------------------------------------
# Probes & helpers
# ---------------------------------------------------------------------------


_INSTALL_HINTS: dict[str, str] = {
    "FFmpeg": "https://ffmpeg.org/download.html",
    "Git": "https://git-scm.com/downloads",
    "Docker": "https://www.docker.com/products/docker-desktop",
    "ImageMagick": "https://imagemagick.org/script/download.php",
    "Pandoc": "https://pandoc.org/installing.html",
    "LibreOfficeWriter": "https://www.libreoffice.org/download/",
    "SQLite": "bundled with Python stdlib",
    "Notepad": "bundled with Windows",
}

_BINARY_PROBES: dict[str, str] = {
    "FFmpeg": "ffmpeg",
    "Git": "git",
    "Docker": "docker",
    "ImageMagick": "magick",
    "Pandoc": "pandoc",
    "LibreOfficeWriter": "soffice",
}


def _binary_available(api_name: str) -> bool:
    probe = _BINARY_PROBES.get(api_name)
    if probe is None:
        return True
    return shutil.which(probe) is not None


def _jsonable(value: Any) -> Any:
    """Coerce arbitrary return values into something JSON-serialisable."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, bytes):
        return {"__bytes__": True, "length": len(value)}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if hasattr(value, "model_dump"):
        try:
            return value.model_dump()
        except Exception:
            pass
    return repr(value)


# ---------------------------------------------------------------------------
# Tool registration
# ---------------------------------------------------------------------------


def _build_tool(
    api_name: str,
    mod_path: str,
    cls_name: str,
    method_name: str,
    signature: inspect.Signature,
) -> Any:
    """Construct a closure that lazily instantiates the API and calls method."""
    hint = _INSTALL_HINTS.get(api_name, "")

    def _tool(**kwargs: Any) -> dict[str, Any]:
        if not _binary_available(api_name):
            return {
                "error": f"{api_name} binary not found on PATH",
                "install_hint": hint,
            }
        try:
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, cls_name)
            instance = cls()
            func = getattr(instance, method_name)
            result = func(**kwargs)
        except FileNotFoundError as exc:
            return {"error": f"{exc}", "install_hint": hint}
        except Exception as exc:
            return {"error": f"{type(exc).__name__}: {exc}"}
        return {"result": _jsonable(result)}

    _tool.__name__ = f"{api_name}_{method_name}"
    _tool.__doc__ = (
        f"Call {api_name}.{method_name}. "
        f"Signature: {signature}. "
        f"Returns {{'result': ...}} on success, {{'error': ...}} on failure."
    )
    # Copy the original signature so FastMCP can generate a tool schema.
    try:
        params = [
            p for p in signature.parameters.values()
            if p.name != "self"
        ]
        _tool.__signature__ = inspect.Signature(parameters=params)  # type: ignore[attr-defined]
    except (TypeError, ValueError):
        pass
    return _tool


def _iter_registered_tools() -> list[tuple[str, Any, inspect.Signature]]:
    """Yield ``(tool_name, closure, signature)`` for every public method."""
    from api_anything.apis import _REGISTRY

    out: list[tuple[str, Any, inspect.Signature]] = []
    for api_name, (mod_path, cls_name) in _REGISTRY.items():
        try:
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, cls_name)
        except Exception as exc:
            logger.info("Skipping %s (import failed: %s)", api_name, exc)
            continue

        for method_name, method_obj in inspect.getmembers(
            cls, predicate=inspect.isfunction
        ):
            if method_name.startswith("_"):
                continue
            try:
                sig = inspect.signature(method_obj)
            except (TypeError, ValueError):
                continue
            tool = _build_tool(api_name, mod_path, cls_name, method_name, sig)
            out.append((f"{api_name}_{method_name}", tool, sig))
    return out


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def run_server(
    host: str = "127.0.0.1",
    port: int = 8765,
    transport: str = "stdio",
) -> int:
    """Launch the MCP server.

    Parameters
    ----------
    host, port:
        Bind address for ``sse`` / ``http`` transports (ignored for stdio).
    transport:
        One of ``"stdio"``, ``"sse"``, ``"http"``.

    Returns
    -------
    int
        Shell exit code (0 on clean shutdown, 1 on missing optional dep).
    """
    if not _HAS_MCP:
        _print_missing_dep()
        return 1

    mcp = FastMCP(
        name="api-anything",
        instructions=(
            "Auto-generated Python API tools for common software "
            "(FFmpeg, Git, Docker, SQLite, ImageMagick, Pandoc, LibreOffice, "
            "Notepad). Each tool returns {'result': ...} or {'error': ...}."
        ),
    )

    registered = 0
    for tool_name, fn, _sig in _iter_registered_tools():
        try:
            mcp.tool(name=tool_name)(fn)
            registered += 1
        except Exception as exc:  # pragma: no cover - SDK variance
            logger.warning("Failed to register %s: %s", tool_name, exc)

    logger.info("MCP server ready (%d tools, transport=%s)", registered, transport)

    try:
        if transport == "stdio":
            mcp.run(transport="stdio")
        elif transport == "sse":
            mcp.run(transport="sse", host=host, port=port)
        elif transport == "http":
            mcp.run(transport="streamable-http", host=host, port=port)
        else:
            raise ValueError(
                f"Unsupported transport {transport!r}. "
                "Choose stdio, sse, or http."
            )
    except KeyboardInterrupt:
        logger.info("MCP server interrupted by user.")
        return 0
    except TypeError as exc:
        # FastMCP API varies by version; fall back to positional form.
        logger.warning("mcp.run positional fallback: %s", exc)
        try:
            mcp.run(transport)
        except Exception as exc2:  # pragma: no cover
            logger.error("MCP server failed: %s", exc2)
            return 1
    return 0


def _print_missing_dep() -> None:
    msg = (
        "[api-anything] the 'mcp' package is required for mcp-serve.\n"
        "  pip install mcp\n"
        "  # or:  pip install 'api-anything[mcp]'\n"
    )
    try:
        from rich.console import Console

        Console(stderr=True).print(f"[red]{msg}[/red]")
    except ModuleNotFoundError:
        import sys as _sys

        _sys.stderr.write(msg)


def available() -> bool:
    """Return True iff the ``mcp`` SDK is importable."""
    return _HAS_MCP


__all__ = ["available", "run_server"]
