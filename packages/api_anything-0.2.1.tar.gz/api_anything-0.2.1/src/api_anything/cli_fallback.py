"""CLI-Anything fallback layer (Hybrid Dual-Mode per RFC 0.1 §3 方案 C).

This module provides a runtime bridge from API-Anything's primary
code-generated / UIA-based / subprocess methods to CLI-Anything binaries
on PATH, so that pipelines degrade gracefully instead of hard-failing.

Public surface:
    - CliFallbackError: single exception class for fallback-layer failures
    - is_cli_available(name): probe PATH for ``cli-anything-<name>``
    - invoke_cli(binary, subcmd, args, *, json_output, timeout): subprocess runner
    - with_cli_fallback(cli_binary, subcmd, json_output, fallback_on): decorator
    - load_schema(software): load YAML schema from :mod:`cli_fallback_schemas`

Design tenets (RFC §3):
    * Primary method runs first, fallback triggers only on opt-in exceptions.
    * Fallback is **per-method** opt-in (decorator), not class-wide.
    * CLI-Anything is **not bundled** — users install ``pip install cli-anything-<sw>``.
    * Observable: every fallback invocation is logged with binary/duration/exit.
    * Version pin is a *soft* warning, never blocks execution.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import time
from collections.abc import Callable, Iterable
from functools import wraps
from pathlib import Path
from typing import Any, TypeVar

__all__ = [
    "CLI_BINARY_PREFIX",
    "DEFAULT_FALLBACK_EXCEPTIONS",
    "CliFallbackError",
    "invoke_cli",
    "is_cli_available",
    "load_schema",
    "with_cli_fallback",
]

logger = logging.getLogger("api_anything.cli_fallback")

CLI_BINARY_PREFIX = "cli-anything-"

# Default exceptions that trigger fallback. Imported by exception-name string
# to avoid hard coupling to optional modules (UIACoverageError may not exist yet,
# NotepadError lives in apis.notepad). Decorators can extend/override via
# ``fallback_on=`` kwarg.
DEFAULT_FALLBACK_EXCEPTION_NAMES: tuple[str, ...] = (
    "NotImplementedError",
    "NotepadError",
    "UIACoverageError",
    "CliFallbackError",
)

# Runtime-resolved exception tuple. NotImplementedError is a builtin so always
# available; other names resolve to ``Exception`` as a safety net (decorator
# still discriminates by name at catch-time).
DEFAULT_FALLBACK_EXCEPTIONS: tuple[type[BaseException], ...] = (NotImplementedError,)


class CliFallbackError(RuntimeError):
    """Raised when CLI-Anything fallback itself fails.

    Includes binary name, subcommand, stderr tail, and exit code for UX.
    """

    def __init__(
        self,
        message: str,
        *,
        binary: str | None = None,
        subcmd: str | None = None,
        exit_code: int | None = None,
        stderr: str | None = None,
    ) -> None:
        super().__init__(message)
        self.binary = binary
        self.subcmd = subcmd
        self.exit_code = exit_code
        self.stderr = stderr

    def __str__(self) -> str:  # pragma: no cover - trivial formatting
        base = super().__str__()
        parts = [base]
        if self.binary:
            parts.append(f"binary={self.binary}")
        if self.subcmd:
            parts.append(f"subcmd={self.subcmd}")
        if self.exit_code is not None:
            parts.append(f"exit={self.exit_code}")
        return " | ".join(parts)


def _install_hint(binary: str) -> str:
    """Return a ``pip install`` hint for a missing CLI-Anything binary."""
    # binary = "cli-anything-ffmpeg" -> software = "ffmpeg"
    software = (
        binary[len(CLI_BINARY_PREFIX) :]
        if binary.startswith(CLI_BINARY_PREFIX)
        else binary
    )
    return (
        f"CLI-Anything binary '{binary}' not found on PATH. "
        f"Install with:  pip install cli-anything-{software}"
    )


def is_cli_available(name: str) -> bool:
    """Return True if the CLI-Anything binary for *name* is on PATH.

    *name* can be either the short software name (``"ffmpeg"``) or the full
    binary name (``"cli-anything-ffmpeg"``). Uses :func:`shutil.which`, which
    respects Windows PATHEXT (``.exe`` / ``.bat`` / ``.cmd``).
    """
    if not name:
        return False
    binary = name if name.startswith(CLI_BINARY_PREFIX) else f"{CLI_BINARY_PREFIX}{name}"
    return shutil.which(binary) is not None


def invoke_cli(
    binary: str,
    subcmd: str,
    args: Iterable[str | os.PathLike[str]] | None = None,
    *,
    json_output: bool = True,
    timeout: float = 30.0,
    env: dict[str, str] | None = None,
    check: bool = True,
) -> Any:
    """Run a CLI-Anything binary and return parsed stdout.

    Args:
        binary: Full binary name (``cli-anything-ffmpeg``) or short name (``ffmpeg``).
        subcmd: Subcommand passed as first positional arg.
        args: Additional positional / flag args. Coerced to ``str``.
        json_output: If True, append ``--json`` and try ``json.loads`` on stdout.
            If parsing fails, raw stdout is returned.
        timeout: Wall-clock timeout in seconds. Subprocess is killed on expiry.
        env: Optional environment overrides (merged on top of ``os.environ``).
        check: If True, raise :class:`CliFallbackError` on non-zero exit.

    Returns:
        Parsed JSON (dict / list / scalar) if *json_output* and parse succeeds,
        else raw stdout string.

    Raises:
        CliFallbackError: Binary missing, timeout, or non-zero exit (when
            ``check=True``).
    """
    full_binary = binary if binary.startswith(CLI_BINARY_PREFIX) else f"{CLI_BINARY_PREFIX}{binary}"

    if shutil.which(full_binary) is None:
        raise CliFallbackError(_install_hint(full_binary), binary=full_binary, subcmd=subcmd)

    cmd: list[str] = [full_binary, subcmd]
    if args:
        cmd.extend(str(a) for a in args)
    if json_output and "--json" not in cmd:
        cmd.append("--json")

    merged_env = None
    if env:
        merged_env = os.environ.copy()
        merged_env.update(env)

    logger.info(
        "cli_fallback.invoke start binary=%s subcmd=%s argc=%d json=%s timeout=%s",
        full_binary,
        subcmd,
        len(cmd) - 2,
        json_output,
        timeout,
    )
    start = time.monotonic()
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=merged_env,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        duration = time.monotonic() - start
        logger.warning(
            "cli_fallback.invoke timeout binary=%s subcmd=%s duration=%.2fs",
            full_binary,
            subcmd,
            duration,
        )
        raise CliFallbackError(
            f"CLI-Anything call timed out after {timeout}s",
            binary=full_binary,
            subcmd=subcmd,
        ) from exc

    duration = time.monotonic() - start
    logger.info(
        "cli_fallback.invoke done binary=%s subcmd=%s duration=%.2fs exit=%d",
        full_binary,
        subcmd,
        duration,
        proc.returncode,
    )

    if check and proc.returncode != 0:
        stderr_tail = (proc.stderr or "").strip().splitlines()[-5:]
        raise CliFallbackError(
            f"CLI-Anything exited with {proc.returncode}",
            binary=full_binary,
            subcmd=subcmd,
            exit_code=proc.returncode,
            stderr="\n".join(stderr_tail),
        )

    stdout = proc.stdout or ""
    if json_output and stdout.strip():
        try:
            return json.loads(stdout)
        except json.JSONDecodeError:
            logger.debug(
                "cli_fallback.invoke json parse fail binary=%s — returning raw",
                full_binary,
            )
            return stdout
    return stdout


F = TypeVar("F", bound=Callable[..., Any])


def _resolve_exception_names(names: Iterable[str]) -> tuple[type[BaseException], ...]:
    """Resolve exception name strings to concrete classes at runtime.

    Lookup order:
        1. Python builtins (``NotImplementedError`` etc.)
        2. ``api_anything.apis.notepad.NotepadError`` (if module importable)
        3. Fallback to :class:`Exception` as sentinel (we still filter by
           ``type(exc).__name__`` in the catch block)
    """
    resolved: list[type[BaseException]] = []
    import builtins

    for name in names:
        cls = getattr(builtins, name, None)
        if isinstance(cls, type) and issubclass(cls, BaseException):
            resolved.append(cls)
            continue
        if name == "NotepadError":
            try:
                from api_anything.apis.notepad import NotepadError
                resolved.append(NotepadError)
                continue
            except Exception:
                pass
        if name == "CliFallbackError":
            resolved.append(CliFallbackError)
            continue
        # Unknown name — we keep it in name-match set via closure below.
    # Dedup while preserving order
    seen: set[type[BaseException]] = set()
    out: list[type[BaseException]] = []
    for cls in resolved:
        if cls not in seen:
            out.append(cls)
            seen.add(cls)
    return tuple(out) if out else (Exception,)


def with_cli_fallback(
    cli_binary: str,
    subcmd: str,
    *,
    json_output: bool = True,
    fallback_on: Iterable[str] | None = None,
    timeout: float = 30.0,
    arg_builder: Callable[..., list[str]] | None = None,
) -> Callable[[F], F]:
    """Decorator: wrap a method so that on failure it falls back to CLI-Anything.

    Args:
        cli_binary: CLI-Anything binary (short or full name).
        subcmd: Subcommand to call when primary fails.
        json_output: Pass ``--json`` to CLI and parse JSON response.
        fallback_on: Exception name whitelist triggering fallback. Defaults to
            :data:`DEFAULT_FALLBACK_EXCEPTION_NAMES`.
        timeout: CLI timeout seconds.
        arg_builder: Optional callable ``(*args, **kwargs) -> list[str]`` that
            constructs the CLI positional args. Defaults to passing positional
            args as strings (skipping ``self``).

    Example:
        >>> class MyApi:
        ...     @with_cli_fallback("ffmpeg", "convert")
        ...     def convert(self, src, dst):
        ...         raise NotImplementedError("primary not ready")
    """
    trigger_names = tuple(fallback_on) if fallback_on else DEFAULT_FALLBACK_EXCEPTION_NAMES
    trigger_classes = _resolve_exception_names(trigger_names)
    name_set = set(trigger_names)

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return func(*args, **kwargs)
            except trigger_classes as exc:
                exc_name = type(exc).__name__
                if exc_name not in name_set and not isinstance(exc, trigger_classes):
                    raise
                logger.info(
                    "cli_fallback.trigger method=%s exc=%s — falling back to %s %s",
                    func.__qualname__,
                    exc_name,
                    cli_binary,
                    subcmd,
                )
                # Build args: prefer user builder, else pass positional args minus self
                if arg_builder is not None:
                    cli_args = arg_builder(*args, **kwargs)
                else:
                    # Heuristic: if first arg looks like ``self``, drop it
                    payload = list(args)
                    is_method = func.__qualname__ != func.__name__
                    if payload and is_method and hasattr(payload[0], "__class__"):
                        payload = payload[1:]
                    cli_args = [str(a) for a in payload]
                try:
                    return invoke_cli(
                        cli_binary,
                        subcmd,
                        cli_args,
                        json_output=json_output,
                        timeout=timeout,
                    )
                except CliFallbackError:
                    # Re-raise as-is; caller decides how to surface.
                    raise
            except Exception as exc:
                # Name-match path for exceptions we could not resolve to class
                if type(exc).__name__ in name_set:
                    logger.info(
                        "cli_fallback.trigger_by_name method=%s exc=%s",
                        func.__qualname__,
                        type(exc).__name__,
                    )
                    if arg_builder is not None:
                        cli_args = arg_builder(*args, **kwargs)
                    else:
                        payload = list(args)
                        if payload and func.__qualname__ != func.__name__:
                            payload = payload[1:]
                        cli_args = [str(a) for a in payload]
                    return invoke_cli(
                        cli_binary,
                        subcmd,
                        cli_args,
                        json_output=json_output,
                        timeout=timeout,
                    )
                raise

        return wrapper  # type: ignore[return-value]

    return decorator


# ---------------------------------------------------------------------------
# Schema loading (YAML)
# ---------------------------------------------------------------------------

_SCHEMA_DIR = Path(__file__).parent / "cli_fallback_schemas"


def load_schema(software: str) -> dict[str, Any]:
    """Load a YAML schema mapping primary methods to CLI subcommands.

    Schema shape (see :mod:`cli_fallback_schemas` for examples)::

        cli_binary: cli-anything-ffmpeg
        version_pin: ">=1.0,<2.0"
        methods:
          convert:
            subcmd: convert
            args: [input_path, output_path]
            options: [--codec, --bitrate]

    Args:
        software: Short software name (``"ffmpeg"``).

    Returns:
        Parsed schema dict.

    Raises:
        CliFallbackError: Schema file missing or malformed.
    """
    path = _SCHEMA_DIR / f"{software}.yaml"
    if not path.exists():
        raise CliFallbackError(
            f"Schema file not found: {path}",
            binary=f"{CLI_BINARY_PREFIX}{software}",
        )
    try:
        import yaml  # type: ignore[import-untyped]
    except ImportError as exc:  # pragma: no cover - env guard
        raise CliFallbackError(
            "PyYAML not installed. Install with: pip install pyyaml"
        ) from exc

    try:
        with path.open("r", encoding="utf-8") as fp:
            data = yaml.safe_load(fp)
    except yaml.YAMLError as exc:
        raise CliFallbackError(f"Malformed YAML schema: {path}") from exc

    if not isinstance(data, dict):
        raise CliFallbackError(f"Schema root must be a mapping: {path}")

    # Minimal validation: required keys
    missing = {"cli_binary", "methods"} - set(data.keys())
    if missing:
        raise CliFallbackError(
            f"Schema {path} missing required keys: {sorted(missing)}"
        )
    if not isinstance(data["methods"], dict):
        raise CliFallbackError(f"Schema 'methods' must be a mapping in {path}")

    # Soft version pin check — warn only, never block
    pin = data.get("version_pin")
    if pin and not isinstance(pin, str):
        logger.warning("Schema %s: version_pin should be str, got %s", path, type(pin))

    return data
