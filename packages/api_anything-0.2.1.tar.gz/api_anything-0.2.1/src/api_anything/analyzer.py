"""Three-source analyzer — extract UI structure from UIA, screenshots, and source code.

Each analyzer function is designed to fail gracefully: missing dependencies or
unreachable targets return empty/None results, never raise.
"""

from __future__ import annotations

import logging
import textwrap
from pathlib import Path

import httpx

from .models import UIControl
from .uia_patterns import SUPPORTED_PATTERNS

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 1. UIA accessibility tree
# ---------------------------------------------------------------------------

_MAX_CONTROLS = 500  # cap to avoid performance issues


def _probe_supported_patterns(ctrl: object) -> list[str] | None:
    """Probe which UIA patterns are supported by a uiautomation Control.

    RFC v0.3 M0: returns a list like ``["InvokePattern", "ValuePattern"]`` or
    ``None`` if probing is impossible (e.g. uiautomation not installed,
    control wrapper missing ``Get*Pattern`` methods). Empty list means
    probed-but-none-supported.

    The probe uses duck-typing: for each supported pattern name, call
    ``ctrl.GetXxxPattern()`` and check truthiness. Individual failures are
    silently skipped so one misbehaving control cannot break analysis.
    """
    if ctrl is None:
        return None

    discovered: list[str] = []
    for pattern_name in SUPPORTED_PATTERNS:
        getter_name = f"Get{pattern_name}"
        getter = getattr(ctrl, getter_name, None)
        if getter is None or not callable(getter):
            continue
        try:
            pattern_obj = getter()
        except Exception:
            continue
        if pattern_obj:
            discovered.append(pattern_name)
    return discovered


def _walk_uia_control(ctrl: object, depth: int = 0, max_depth: int = 8) -> UIControl | None:
    """Recursively convert a uiautomation control into a UIControl model."""
    if depth > max_depth:
        return None

    try:
        name: str = getattr(ctrl, "Name", "") or ""
        control_type: str = getattr(ctrl, "ControlTypeName", "Unknown") or "Unknown"
        automation_id: str = getattr(ctrl, "AutomationId", "") or ""
    except Exception:
        return None

    # RFC v0.3 M0: probe supported patterns, silent on failure
    patterns: list[str] | None
    try:
        patterns = _probe_supported_patterns(ctrl)
    except Exception:
        patterns = None

    children: list[UIControl] = []
    try:
        for child in ctrl.GetChildren():  # type: ignore[union-attr]
            child_model = _walk_uia_control(child, depth + 1, max_depth)
            if child_model is not None:
                children.append(child_model)
    except Exception:
        pass

    return UIControl(
        name=name,
        control_type=control_type,
        automation_id=automation_id,
        children=children,
        patterns=patterns,
    )


def analyze_uia(window_title: str) -> list[UIControl]:
    """Analyze running software via UIA accessibility tree.

    Returns a structured list of controls found in the window.
    Gracefully returns an empty list if ``uiautomation`` is not installed
    or the window is not found.
    """
    try:
        import uiautomation as uia  # type: ignore[import-untyped]
    except ImportError:
        logger.warning("uiautomation not installed — UIA analysis skipped")
        return []

    try:
        window = uia.WindowControl(searchDepth=1, Name=window_title)
        if not window.Exists(maxSearchSeconds=3):
            logger.warning("Window '%s' not found for UIA analysis", window_title)
            return []

        results: list[UIControl] = []
        for child in window.GetChildren():
            model = _walk_uia_control(child)
            if model is not None:
                results.append(model)
            if len(results) >= _MAX_CONTROLS:
                break
        return results

    except Exception as exc:
        logger.error("UIA analysis failed: %s", exc)
        return []


# ---------------------------------------------------------------------------
# 2. Screenshot capture
# ---------------------------------------------------------------------------


def analyze_screenshot(window_title: str) -> str | None:
    """Capture a screenshot of the target window.

    Returns the file path to the saved screenshot, or ``None`` if capture
    fails or ``mss`` is not installed.
    """
    try:
        import mss  # type: ignore[import-untyped]
    except ImportError:
        logger.warning("mss not installed — screenshot analysis skipped")
        return None

    try:
        import tempfile as _tmpmod

        output_dir = Path(_tmpmod.mkdtemp(prefix="api_anything_screenshots_"))


        safe_name = "".join(c if c.isalnum() or c in "-_ " else "_" for c in window_title)
        output_path = output_dir / f"{safe_name}.png"

        # Capture primary monitor (full-screen fallback — per-window capture
        # would need win32gui which may not be available).
        with mss.mss() as sct:
            monitor = sct.monitors[1]  # primary monitor
            screenshot = sct.grab(monitor)
            mss.tools.to_png(screenshot.rgb, screenshot.size, output=str(output_path))

        logger.info("Screenshot saved to %s", output_path)
        return str(output_path)

    except Exception as exc:
        logger.error("Screenshot capture failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# 3. Source code extraction
# ---------------------------------------------------------------------------

_MAX_SOURCE_CHARS = 10_000
_KEY_FILENAMES = [
    "setup.py",
    "pyproject.toml",
    "setup.cfg",
    "README.md",
    "__main__.py",
    "cli.py",
    "main.py",
    "app.py",
]


def _read_local_source(source_path: str) -> str:
    """Read key files from a local source directory."""
    root = Path(source_path)
    if not root.is_dir():
        return ""

    parts: list[str] = []
    total_chars = 0

    # Collect key files first
    for name in _KEY_FILENAMES:
        fpath = root / name
        if not fpath.is_file():
            # Also try src/<pkg>/<name>
            for candidate in root.glob(f"src/*/{name}"):
                fpath = candidate
                break
            else:
                continue

        try:
            text = fpath.read_text(encoding="utf-8", errors="replace")
            # Truncate individual files to keep total reasonable
            if len(text) > 3000:
                text = text[:3000] + "\n... (truncated)"
            parts.append(f"# === {fpath.relative_to(root)} ===\n{text}")
            total_chars += len(text)
            if total_chars >= _MAX_SOURCE_CHARS:
                break
        except Exception:
            continue

    # If we didn't find key files, grab first few .py files
    if not parts:
        for py_file in sorted(root.rglob("*.py"))[:5]:
            try:
                text = py_file.read_text(encoding="utf-8", errors="replace")[:2000]
                parts.append(f"# === {py_file.relative_to(root)} ===\n{text}")
                total_chars += len(text)
                if total_chars >= _MAX_SOURCE_CHARS:
                    break
            except Exception:
                continue

    return "\n\n".join(parts)


def _fetch_github_source(github_url: str) -> str:
    """Fetch README and key info from a GitHub repo."""
    # Normalize URL to API format
    url = github_url.rstrip("/")
    if "github.com" in url:
        # https://github.com/owner/repo -> https://api.github.com/repos/owner/repo
        parts = url.split("github.com/")
        if len(parts) == 2:
            api_url = f"https://api.github.com/repos/{parts[1]}"
        else:
            return ""
    else:
        return ""

    sections: list[str] = []
    try:
        # Fetch repo info
        resp = httpx.get(api_url, timeout=10.0, follow_redirects=True)
        if resp.status_code == 200:
            data = resp.json()
            desc = data.get("description", "")
            lang = data.get("language", "")
            sections.append(f"# Repository: {data.get('full_name', '')}")
            sections.append(f"# Description: {desc}")
            sections.append(f"# Language: {lang}")

        # Fetch README
        readme_resp = httpx.get(
            f"{api_url}/readme",
            timeout=10.0,
            follow_redirects=True,
            headers={"Accept": "application/vnd.github.raw"},
        )
        if readme_resp.status_code == 200:
            readme_text = readme_resp.text[:5000]
            sections.append(f"\n# === README ===\n{readme_text}")

    except httpx.HTTPError as exc:
        logger.warning("GitHub fetch failed: %s", exc)

    return "\n".join(sections)


def analyze_source(
    source_path: str | None = None,
    github_url: str | None = None,
) -> str:
    """Extract relevant source code snippets for LLM analysis.

    Reads key files from a local path or fetches README + metadata from GitHub.
    Returns concatenated text capped at ~10K characters.
    """
    _placeholder = "\n... (truncated)"

    if source_path:
        result = _read_local_source(source_path)
        if result:
            return textwrap.shorten(
                result, width=_MAX_SOURCE_CHARS, placeholder=_placeholder
            )

    if github_url:
        result = _fetch_github_source(github_url)
        if result:
            return textwrap.shorten(
                result, width=_MAX_SOURCE_CHARS, placeholder=_placeholder
            )

    return ""
