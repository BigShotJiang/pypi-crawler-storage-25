# ruff: noqa: RUF002, RUF003
"""Core code generator — turns analyzed software into Python API classes.

Uses Instructor + Pydantic for structured LLM output. Supports a mock mode
for testing without an API key.
"""

from __future__ import annotations

import logging
import textwrap
import time
from typing import Any

from .models import APIClass, APIMethod, APIParam, GenerationResult, UIControl
from .uia_patterns import (
    UIA_PATTERN_METHOD_TEMPLATES,
    infer_pattern_from_control_type,
    list_patterns_for_control,
    select_primary_pattern,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prompt building
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = textwrap.dedent("""\
    You are an expert Python API designer. Given information about a software
    application (UI controls, source code, screenshots), design a clean Python
    API class that wraps the software's functionality.

    Rules:
    - Method names must be snake_case and self-explanatory
    - Each method should map to one logical user action
    - Group related actions (e.g. file operations, edit operations)
    - Include type hints and docstrings
    - Choose operation_mode "subprocess" for CLI-accessible actions,
      "uia" for GUI-only actions
    - The class should feel natural to a Python developer
""")


# Tier levels 3B/3C/4 have no stable official CLI and UIA coverage may drop,
# making them the primary customers of RFC v0.2 A (Fallback P2/P3).
_FALLBACK_TIERS: frozenset[str] = frozenset({"3B", "3C", "4"})

# Mirrors cli_fallback.CLI_BINARY_PREFIX. Kept as a local string constant so
# rendered code does not need to import the fallback module just to see it.
_CLI_BINARY_PREFIX = "cli-anything-"


def _build_prompt(
    software_name: str,
    controls: list[UIControl],
    screenshot_path: str | None = None,
    source_text: str | None = None,
    tier: str = "2A",
    fallback_enabled: bool = False,
) -> str:
    """Build the LLM prompt from available analysis data.

    Args:
        software_name: target software name.
        controls: UI controls discovered via UIA.
        screenshot_path: optional window screenshot path (vision route).
        source_text: optional source-code excerpts.
        tier: detected tier string (e.g. "2A" / "3B").
        fallback_enabled: True for tier 3B/3C/4; hints the LLM to tolerate
            UIA coverage gaps because a CLI fallback will wrap the method.
    """
    sections: list[str] = []

    sections.append(f"# Target Software: {software_name}")
    sections.append(f"# Detected Tier: {tier}")

    if controls:
        sections.append("\n## Discovered UI Controls")
        for ctrl in controls[:50]:  # cap to avoid prompt bloat
            _fmt_control(ctrl, sections, indent=0)

    if source_text:
        sections.append(f"\n## Source Code Excerpts\n{source_text[:5000]}")

    if screenshot_path:
        sections.append(f"\n## Screenshot available at: {screenshot_path}")

    # Fallback hint: tiers 3B/3C/4 lack a stable official CLI and UIA coverage
    # may be incomplete. Tell the LLM that generated methods are allowed to
    # raise NotImplementedError on coverage gaps - the runtime fallback layer
    # will catch it and degrade to CLI-Anything.
    if fallback_enabled:
        sections.append(
            "\n## Fallback Hint (Tier 3B/3C/4)\n"
            "Primary UIA/subprocess paths may fail on unknown versions. "
            "When generating UIA methods, it is safe to raise "
            "NotImplementedError on detected coverage gaps — the runtime "
            "will degrade to `cli-anything-<software>` via the "
            "@with_cli_fallback decorator layer."
        )

    sections.append(
        "\n## Task\n"
        f"Design a Python API class named `{_to_class_name(software_name)}` "
        f"that wraps {software_name}. "
        "Return the complete APIClass specification."
    )

    return "\n".join(sections)


def _fmt_control(ctrl: UIControl, lines: list[str], indent: int) -> None:
    """Format a UIControl tree into readable lines."""
    prefix = "  " * indent
    aid_str = f" (id={ctrl.automation_id})" if ctrl.automation_id else ""
    lines.append(f"{prefix}- [{ctrl.control_type}] {ctrl.name}{aid_str}")
    for child in ctrl.children[:10]:
        _fmt_control(child, lines, indent + 1)


def _to_class_name(software_name: str) -> str:
    """Convert software name to PascalCase class name."""
    cleaned = "".join(c if c.isalnum() or c == " " else " " for c in software_name)
    return "".join(word.capitalize() for word in cleaned.split()) + "API"


def _to_module_name(software_name: str) -> str:
    """Convert software name to snake_case module name."""
    cleaned = "".join(c if c.isalnum() or c == " " else " " for c in software_name)
    return "_".join(word.lower() for word in cleaned.split()) + "_api"


# ---------------------------------------------------------------------------
# Mock client for testing
# ---------------------------------------------------------------------------


def _mock_generate(software_name: str, controls: list[UIControl], tier: str) -> APIClass:
    """Generate a mock APIClass for testing without an LLM API key."""
    class_name = _to_class_name(software_name)
    module_name = _to_module_name(software_name)

    methods: list[APIMethod] = []
    # control_index 對應 method <-> 生它的 control，pattern enrichment pass 會用。
    # None 代表 lifecycle method（launch / close），不綁 control。
    control_index: list[UIControl | None] = []

    # Generate methods from controls (v0.2 behavior, method names/count 不動)
    for ctrl in controls:
        if ctrl.control_type == "Button":
            method_name = _to_method_name(ctrl.name, "click")
            methods.append(
                APIMethod(
                    name=method_name,
                    docstring=f"Click the '{ctrl.name}' button.",
                    params=[],
                    return_type="None",
                    operation_mode="uia",
                    implementation_hint=f"Find and click button with name='{ctrl.name}'",
                )
            )
            control_index.append(ctrl)
        elif ctrl.control_type == "TextBox":
            method_name = _to_method_name(ctrl.name, "set")
            methods.append(
                APIMethod(
                    name=method_name,
                    docstring=f"Set the value of '{ctrl.name}' text field.",
                    params=[
                        APIParam(
                            name="value",
                            type_hint="str",
                            description=f"Value to set in {ctrl.name}",
                        )
                    ],
                    return_type="None",
                    operation_mode="uia",
                    implementation_hint=f"Find TextBox '{ctrl.name}' and set value",
                )
            )
            control_index.append(ctrl)
        elif ctrl.control_type == "Menu":
            method_name = _to_method_name(ctrl.name, "open")
            methods.append(
                APIMethod(
                    name=method_name,
                    docstring=f"Open the '{ctrl.name}' menu.",
                    params=[],
                    return_type="None",
                    operation_mode="uia",
                    implementation_hint=f"Click menu item '{ctrl.name}'",
                )
            )
            control_index.append(ctrl)
        elif ctrl.control_type == "Slider":
            method_name = _to_method_name(ctrl.name, "set")
            methods.append(
                APIMethod(
                    name=method_name,
                    docstring=f"Set the '{ctrl.name}' slider value.",
                    params=[
                        APIParam(
                            name="value",
                            type_hint="float",
                            description=f"Value for {ctrl.name}",
                        )
                    ],
                    return_type="None",
                    operation_mode="uia",
                    implementation_hint=f"Set slider '{ctrl.name}' to value",
                )
            )
            control_index.append(ctrl)
        elif ctrl.control_type == "CheckBox":
            method_name = _to_method_name(ctrl.name, "toggle")
            methods.append(
                APIMethod(
                    name=method_name,
                    docstring=f"Toggle the '{ctrl.name}' checkbox.",
                    params=[
                        APIParam(
                            name="checked",
                            type_hint="bool",
                            default="True",
                            description=f"Whether {ctrl.name} should be checked",
                        )
                    ],
                    return_type="None",
                    operation_mode="uia",
                    implementation_hint=f"Set checkbox '{ctrl.name}' state",
                )
            )
            control_index.append(ctrl)

    # Always add basic lifecycle methods
    if not any(m.name == "launch" for m in methods):
        methods.insert(
            0,
            APIMethod(
                name="launch",
                docstring=f"Launch {software_name}.",
                params=[],
                return_type="None",
                operation_mode="subprocess",
                implementation_hint=f"Start {software_name} process",
            ),
        )
        control_index.insert(0, None)
    if not any(m.name == "close" for m in methods):
        methods.append(
            APIMethod(
                name="close",
                docstring=f"Close {software_name}.",
                params=[],
                return_type="None",
                operation_mode="subprocess" if tier.startswith(("1", "2")) else "uia",
                implementation_hint=f"Terminate {software_name} process",
            ),
        )
        control_index.append(None)

    # --- RFC v0.3 M0: pattern enrichment pass ---------------------------
    # 對每個由 control 生成的 UIA method 填 uia_pattern / internal_mode /
    # generation_confidence；若 control.patterns 明確多個支援 (e.g. ValuePattern
    # 的 setter+getter)，再**追加** getter/state-query method。
    # 此 pass **不移除** 既有 method、**不改** 既有 method name，100% 向下相容。
    extra_methods: list[APIMethod] = []
    for method, ctrl in zip(methods, control_index, strict=False):
        if ctrl is None:
            # lifecycle method (launch/close): subprocess → internal_mode 標註
            if method.operation_mode == "subprocess":
                method.internal_mode = method.internal_mode or "subprocess"
            continue
        if method.operation_mode != "uia":
            continue
        extra = _enrich_method_with_pattern(method, ctrl)
        extra_methods.extend(extra)
    methods.extend(extra_methods)

    return APIClass(
        class_name=class_name,
        module_name=module_name,
        docstring=f"Python API wrapper for {software_name}.",
        software_name=software_name,
        tier=tier,
        methods=methods,
        imports=["subprocess", "time"],
        setup_code=f'self._process = None\nself._software = "{software_name}"',
    )


def _enrich_method_with_pattern(
    method: APIMethod, control: UIControl
) -> list[APIMethod]:
    """填 pattern 元資料到既有 UIA method，並回傳新增的衍生 method list。

    - 主 pattern 由 `control.patterns` (v0.3 新) 或 `infer_pattern_from_control_type`
      (v0.2 legacy fallback) 決定。
    - method.uia_pattern / internal_mode / generation_confidence 被 **原地更新**。
    - 若 pattern template 有多個 verb (e.g. ValuePattern 的 set + get)，只有
      **control.patterns 明確給** 才追加；純 infer 路徑不追加以免爆量。

    Args:
        method: 已建好的 UIA method（需改欄位）。
        control: 產生它的 UIControl。

    Returns:
        要追加到 class 的額外 method（可能為空 list）。
    """
    # 優先走 control.patterns，退到 infer
    primary: str | None = None
    explicit_patterns = control.patterns is not None and len(control.patterns) > 0
    if explicit_patterns:
        primary = select_primary_pattern(control.patterns)
    if primary is None:
        primary = infer_pattern_from_control_type(control.control_type)

    if primary is None or primary not in UIA_PATTERN_METHOD_TEMPLATES:
        # 無法對應 pattern → 保持 v0.2 legacy 行為，只打標
        method.internal_mode = "uia_legacy"
        return []

    template = UIA_PATTERN_METHOD_TEMPLATES[primary]
    primary_confidence = template["methods"][0].get("confidence", 70)

    method.uia_pattern = primary
    method.internal_mode = "uia_pattern"
    method.generation_confidence = int(primary_confidence)

    # 只有 explicit patterns 才生衍生 method（避免舊 mock control 因 infer 而意外加 getter）
    if not explicit_patterns:
        return []

    extras: list[APIMethod] = []
    # 第 0 個 verb 已被 method 使用，1+ 才是衍生
    for tmpl_method in template["methods"][1:]:
        verb = tmpl_method["verb"]
        extra_name = _to_method_name(control.name, verb)
        # 避免名稱撞（可能 infer 已產同名）
        if extra_name == method.name:
            continue
        params = [
            APIParam(
                name=p["name"],
                type_hint=p["type_hint"],
                default=p.get("default"),
                description=p.get("description", p["name"]),
            )
            for p in tmpl_method.get("params", [])
        ]
        extras.append(
            APIMethod(
                name=extra_name,
                docstring=(
                    f"{verb.replace('_', ' ').capitalize()} '{control.name}' "
                    f"via {primary}."
                ),
                params=params,
                return_type=tmpl_method.get("return_type", "None"),
                operation_mode="uia",
                implementation_hint=f"{primary}: {verb} on '{control.name}'",
                uia_pattern=primary,
                internal_mode="uia_pattern",
                generation_confidence=int(tmpl_method.get("confidence", 70)),
            )
        )
    return extras


def _to_method_name(control_name: str, prefix: str) -> str:
    """Convert a control name to a snake_case method name with prefix."""
    cleaned = "".join(c if c.isalnum() or c == " " else "" for c in control_name)
    snake = "_".join(word.lower() for word in cleaned.split())
    if not snake:
        snake = "control"
    return f"{prefix}_{snake}"


# ---------------------------------------------------------------------------
# LLM-based generation (Instructor)
# ---------------------------------------------------------------------------


def _instructor_generate(
    software_name: str,
    controls: list[UIControl],
    screenshot_path: str | None,
    source_text: str | None,
    tier: str,
    client: Any,
    fallback_enabled: bool = False,
) -> APIClass:
    """Use Instructor to get structured APIClass from LLM."""
    import instructor

    prompt = _build_prompt(
        software_name,
        controls,
        screenshot_path,
        source_text,
        tier,
        fallback_enabled=fallback_enabled,
    )

    patched = instructor.from_openai(client)
    api_class: APIClass = patched.chat.completions.create(
        model="gpt-4o-mini",
        response_model=APIClass,
        messages=[
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        max_retries=2,
    )
    return api_class


# ---------------------------------------------------------------------------
# Code sanitization
# ---------------------------------------------------------------------------

# Patterns that are dangerous in LLM-generated setup_code
_DANGEROUS_PATTERNS = [
    "import os",
    "import subprocess",
    "import shutil",
    "from os",
    "from subprocess",
    "from shutil",
    "exec(",
    "eval(",
    "__import__(",
    "compile(",
    "globals(",
    "locals(",
    "getattr(",
    "setattr(",
    "delattr(",
    "open(",
]


def _sanitize_setup_code(setup_code: str) -> str:
    """Sanitize LLM-generated setup_code by removing dangerous patterns.

    WARNING: This is a best-effort filter. Generated code should always be
    reviewed by a human before production use.
    """
    lines: list[str] = []
    for line in setup_code.split("\n"):
        stripped = line.strip()
        if any(pat in stripped for pat in _DANGEROUS_PATTERNS):
            lines.append(f"# REMOVED (unsafe): {stripped}")
        else:
            lines.append(line)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Code rendering
# ---------------------------------------------------------------------------


def render_api_code(
    api_class: APIClass,
    fallback_enabled: bool = False,
    controls: list[UIControl] | None = None,
) -> str:
    """Render an APIClass specification into actual Python source code.

    Generates a proper Python module with:
    - Import statements
    - Type-hinted methods with docstrings
    - __init__ with connection setup
    - subprocess or UIA dispatch per method
    - Error handling

    Args:
        api_class: the structured spec to render.
        fallback_enabled: True for tiers 3B/3C/4. When set, UIA methods are
            rendered as try/except that call ``cli_fallback.invoke_cli`` on
            failure, giving callers a CLI degradation path.
        controls: optional list of source UIControl objects (RFC v0.3 M0). When
            provided, `_render_method` can look up pattern templates for each
            UIA method and emit real `uiautomation` calls. Omitted → legacy
            `raise NotImplementedError` body (v0.2 behavior).
    """
    # 建 name -> control 索引（method name 逆推 control.name 做比對）
    control_lookup: dict[str, UIControl] = {}
    if controls:
        for c in controls:
            # 以 snake_case name 做索引 key
            key = "_".join(
                w.lower()
                for w in "".join(
                    ch if ch.isalnum() or ch == " " else "" for ch in c.name
                ).split()
            )
            if key:
                control_lookup[key] = c
    lines: list[str] = []

    # Module docstring
    lines.append(f'"""Auto-generated API for {api_class.software_name}.')
    lines.append("")
    lines.append(f"Generated by API-Anything | Tier: {api_class.tier}")
    if fallback_enabled:
        lines.append("Fallback: cli-anything-<software> (RFC v0.2 A)")
    lines.append("")
    lines.append("WARNING: This code was generated with LLM assistance.")
    lines.append("Review all logic before production use.")
    lines.append('"""')
    lines.append("")
    lines.append("from __future__ import annotations")
    lines.append("")

    # Imports
    standard_imports = {"subprocess", "logging"}
    for imp in api_class.imports:
        standard_imports.add(imp)
    for imp in sorted(standard_imports):
        lines.append(f"import {imp}")
    lines.append("")
    lines.append('logger = logging.getLogger(__name__)')
    lines.append("")

    # When fallback is on, import invoke_cli at module level so static
    # analyzers see the symbol. A try/except guard keeps generated modules
    # usable even if the fallback package is missing at runtime.
    if fallback_enabled:
        lines.append("try:")
        lines.append(
            "    from api_anything.cli_fallback import invoke_cli, CliFallbackError"
        )
        lines.append("except ImportError:  # pragma: no cover - runtime guard")
        lines.append("    invoke_cli = None  # type: ignore[assignment]")
        lines.append("    CliFallbackError = Exception  # type: ignore[assignment,misc]")
        lines.append("")
    lines.append("")

    # Class definition
    lines.append(f"class {api_class.class_name}:")
    lines.append(f'    """{api_class.docstring}"""')
    lines.append("")

    # __init__
    lines.append("    def __init__(self) -> None:")
    lines.append(f'        """Initialize {api_class.class_name}."""')
    if api_class.setup_code:
        sanitized_setup = _sanitize_setup_code(api_class.setup_code)
        for setup_line in sanitized_setup.split("\n"):
            lines.append(f"        {setup_line}")
    else:
        lines.append(f'        self._software = "{api_class.software_name}"')
        lines.append("        self._process = None")
    lines.append("")

    # Methods
    for method in api_class.methods:
        # 從 method name 的後綴推回可能的 control key
        # e.g. "click_save" -> "save"；"set_file_name" -> "file_name"
        ctrl: UIControl | None = None
        if control_lookup:
            parts = method.name.split("_", 1)
            if len(parts) == 2:
                ctrl = control_lookup.get(parts[1])
        lines.append(
            _render_method(
                method,
                software_name=api_class.software_name,
                fallback_enabled=fallback_enabled,
                control=ctrl,
            )
        )
        lines.append("")

    return "\n".join(lines)


def _render_method(
    method: APIMethod,
    software_name: str = "",
    fallback_enabled: bool = False,
    control: UIControl | None = None,
) -> str:
    """Render a single APIMethod into Python source.

    Args:
        method: the method spec.
        software_name: short name mapped onto ``cli-anything-<software_name>``
            when a CLI fallback is rendered.
        fallback_enabled: if True and ``method.operation_mode == "uia"``,
            render a try/except that degrades to ``invoke_cli`` on failure.
        control: optional source UIControl (RFC v0.3 M0). When provided and
            ``method.uia_pattern`` resolves to a known template, the UIA body
            is rendered from the pattern template instead of a generic
            ``raise NotImplementedError``.
    """
    lines: list[str] = []

    # Signature
    param_strs = ["self"]
    for p in method.params:
        if p.default is not None:
            param_strs.append(f"{p.name}: {p.type_hint} = {p.default!r}")
        else:
            param_strs.append(f"{p.name}: {p.type_hint}")

    sig = ", ".join(param_strs)
    lines.append(f"    def {method.name}({sig}) -> {method.return_type}:")

    # Docstring — 含 v0.3 M0 元資料（internal_mode / pattern_used /
    # generation_confidence），供 diagnose() 自省與 QA 追蹤。
    lines.append(f'        """{method.docstring}')
    if method.params:
        lines.append("")
        lines.append("        Args:")
        for p in method.params:
            desc = p.description or p.name
            lines.append(f"            {p.name}: {desc}")

    # Pattern 元資料段（只有 UIA method 列完整；subprocess 列 internal_mode 即可）
    internal_mode = method.internal_mode or (
        "subprocess" if method.operation_mode == "subprocess" else "uia_legacy"
    )
    lines.append("")
    lines.append(f"        internal_mode: {internal_mode}")
    if method.uia_pattern:
        lines.append(f"        pattern_used: {method.uia_pattern}")
    if method.operation_mode == "uia" and control is not None:
        # 列出 control 已知的全部 pattern（供後續 drift 重生路由）
        known_patterns = list_patterns_for_control(control.patterns)
        if known_patterns:
            lines.append(
                f"        available_patterns: {', '.join(known_patterns)}"
            )
    lines.append(f"        generation_confidence: {method.generation_confidence}")
    lines.append('        """')

    # Body
    if method.operation_mode == "subprocess":
        lines.append("        try:")
        lines.append(f'            # {method.implementation_hint}')
        lines.append('            subprocess.run(')
        lines.append(f'                [self._software, "{method.name}"],')
        lines.append("                check=True,")
        lines.append("                capture_output=True,")
        lines.append("            )")
        lines.append("        except subprocess.CalledProcessError as exc:")
        lines.append(f'            logger.error("{method.name} failed: %s", exc)')
        lines.append("            raise")
    else:  # uia
        # UIA method body. When fallback is enabled we try the UIA path
        # first, then catch NotImplementedError/ImportError and degrade
        # to the CLI-Anything binary.
        lines.append(f'        # {method.implementation_hint}')
        lines.append("        try:")
        lines.append(
            "            import uiautomation as uia  # type: ignore[import-untyped]  # noqa: F401"
        )
        if method.params:
            first_param = method.params[0].name
            lines.append(f'            logger.info("{method.name}: %s", {first_param})')
        else:
            lines.append(f'            logger.info("{method.name}")')

        # RFC v0.3 M0：若有 uia_pattern 且 template 已定義 → render pattern body。
        # 否則保留 v0.2 原行為（`raise NotImplementedError`），向下相容。
        pattern_body = _render_pattern_body(method, control)
        if pattern_body is not None:
            for body_line in pattern_body:
                lines.append(f"            {body_line}")
        else:
            lines.append("            # TODO: implement UIA interaction")
            lines.append("            raise NotImplementedError(")
            lines.append(f'                "{method.name}: UIA implementation pending"')
            lines.append("            )")
        lines.append("        except ImportError:")
        if fallback_enabled:
            # uiautomation not installed -> attempt CLI degradation
            lines.append(
                '            logger.info("uiautomation missing, attempting CLI fallback")'
            )
            _append_cli_fallback_invocation(lines, method, software_name)
        else:
            lines.append(
                '            raise RuntimeError('
                f'"uiautomation required for {method.name}")'
            )
        if fallback_enabled:
            # NotImplementedError / other UIA failures -> CLI degradation
            lines.append("        except NotImplementedError:")
            lines.append(
                f'            logger.info("UIA not covered for {method.name}, '
                'falling back to cli-anything")'
            )
            _append_cli_fallback_invocation(lines, method, software_name)

    return "\n".join(lines)


def _primary_pattern_of_class(api_class: APIClass) -> str | None:
    """回傳 `APIClass.methods` 中最常使用的 UIA pattern。

    用於 `GenerationResult.pattern_used` 元資料。若多個 method 帶不同 pattern，
    取出現次數最多者；tie 時取 priority 最高者（透過 select_primary_pattern
    的 tie-break）。全部 method 無 pattern → None。
    """
    counts: dict[str, int] = {}
    for m in api_class.methods:
        if m.uia_pattern:
            counts[m.uia_pattern] = counts.get(m.uia_pattern, 0) + 1
    if not counts:
        return None
    # 先以次數排 desc，tie 時丟給 select_primary_pattern
    max_count = max(counts.values())
    top = [p for p, c in counts.items() if c == max_count]
    if len(top) == 1:
        return top[0]
    return select_primary_pattern(top)


def _render_pattern_body(
    method: APIMethod, control: UIControl | None
) -> list[str] | None:
    """把 pattern template 的 body 字串展成已縮排的源碼行。

    回傳 None 代表 caller 應走 legacy `raise NotImplementedError` 路徑。
    所有 template body 裡的 `{locator!r}` 會被 control.name（或 method.name
    的後綴）替換。

    向下相容：`method.uia_pattern` 為 None → 回 None（走舊路徑）。
    """
    if not method.uia_pattern:
        return None
    template = UIA_PATTERN_METHOD_TEMPLATES.get(method.uia_pattern)
    if template is None:
        return None

    # 決定對應 template 內哪個 verb（依 method name 前綴對齊）
    chosen_method: dict | None = None
    method_prefix = method.name.split("_", 1)[0]
    for tmpl_m in template["methods"]:
        if tmpl_m.get("verb") == method_prefix:
            chosen_method = tmpl_m
            break
    if chosen_method is None:
        # 退而選 template 第一個（主 method）
        chosen_method = template["methods"][0]

    raw_body = chosen_method.get("body", "")
    locator = control.name if control is not None else method.name
    try:
        rendered = raw_body.format(locator=locator)
    except (KeyError, IndexError):
        # 如果 template body 用了未知 placeholder，退回 legacy path
        return None
    return rendered.splitlines()


def _append_cli_fallback_invocation(
    lines: list[str],
    method: APIMethod,
    software_name: str,
) -> None:
    """Append the CLI-Anything fallback invocation block to a method body.

    Generates code like::

        if invoke_cli is None:
            raise RuntimeError("CLI fallback not available")
        return invoke_cli("cli-anything-notepad", "<method_name>",
                          [str(arg1), str(arg2)], json_output=True)
    """
    # Default subcmd derives from the method name (matching the yaml schema
    # convention where snake_case method names map to hyphenated subcommands).
    subcmd = method.name.replace("_", "-")
    binary_hint = f"{_CLI_BINARY_PREFIX}{software_name.lower()}" if software_name else ""

    lines.append("            if invoke_cli is None:")
    lines.append(
        '                raise RuntimeError('
        '"CLI fallback unavailable: api_anything.cli_fallback missing")'
    )
    # Stringify every parameter for the CLI positional arg list.
    if method.params:
        args_expr = "[" + ", ".join(f"str({p.name})" for p in method.params) + "]"
    else:
        args_expr = "[]"
    lines.append("            try:")
    lines.append(
        f'                return invoke_cli("{binary_hint}", "{subcmd}", '
        f"{args_expr}, json_output=True)"
    )
    lines.append("            except CliFallbackError as cli_exc:")
    lines.append(
        f'                logger.error("{method.name} CLI fallback failed: %s", cli_exc)'
    )
    lines.append("                raise")


# ---------------------------------------------------------------------------
# Test rendering
# ---------------------------------------------------------------------------


def render_test_code(api_class: APIClass) -> str:
    """Render pytest test code for the generated API class.

    Generates a test module with:
    - Fixture for API instance
    - One test per method (at minimum)
    - Skip markers for tests needing actual software
    """
    lines: list[str] = []

    lines.append(f'"""Tests for {api_class.class_name}.')
    lines.append("")
    lines.append("Auto-generated by API-Anything.")
    lines.append('"""')
    lines.append("")
    lines.append("import pytest")
    lines.append("")
    lines.append(f"from {api_class.module_name} import {api_class.class_name}")
    lines.append("")
    lines.append("")
    lines.append("@pytest.fixture")
    lines.append(f"def api() -> {api_class.class_name}:")
    lines.append(f'    """Create {api_class.class_name} instance."""')
    lines.append(f"    return {api_class.class_name}()")
    lines.append("")

    for method in api_class.methods:
        lines.append("")
        lines.append(f'@pytest.mark.skipif(True, reason="{api_class.software_name} not available")')
        lines.append(f"def test_{method.name}(api: {api_class.class_name}) -> None:")
        lines.append(f'    """Test {method.name} method exists and is callable."""')

        if method.params:
            # Build sample call with placeholder args
            args: list[str] = []
            for p in method.params:
                if p.default is not None:
                    continue
                if p.type_hint == "str":
                    args.append(f'{p.name}="test"')
                elif p.type_hint == "int":
                    args.append(f"{p.name}=0")
                elif p.type_hint == "float":
                    args.append(f"{p.name}=0.0")
                elif p.type_hint == "bool":
                    args.append(f"{p.name}=True")
                else:
                    args.append(f"{p.name}=None")
            arg_str = ", ".join(args)
            lines.append(f"    api.{method.name}({arg_str})")
        else:
            lines.append(f"    api.{method.name}()")

    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def _resolve_fallback_enabled(
    tier: str, confidence: int | None, explicit: bool | None
) -> bool:
    """Decide whether to wrap generated methods with CLI-Anything fallback.

    Precedence:
        1. explicit argument (True / False) overrides everything.
        2. Tier 3B / 3C / 4 always enable fallback (no stable official CLI).
        3. Confidence < 70 enables fallback (low certainty about primary path).
        4. Tier 1 / 2A never enable (they have strong native paths).
    """
    if explicit is not None:
        return explicit
    if tier in _FALLBACK_TIERS:
        return True
    return bool(confidence is not None and confidence < 70)


# RFC v0.2 D 項：走 LLM-driven 的 tier 集合。Tier 3A 以上 UIA-heavy，schema
# 模板覆蓋率差；Tier 1/2A/2B 的 PyPI/subprocess 模式很規則，schema-driven 就夠好。
_LLM_DRIVEN_TIERS: frozenset[str] = frozenset({"3A", "3B", "3C", "4"})

# confidence 門檻：schema-driven 信心低於此值時啟用 LLM-driven。
# RFC D 項原文「<0.6」對應 60（scale 0-100）。
_LLM_DRIVEN_CONFIDENCE_THRESHOLD = 60


def _resolve_llm_driven(
    tier: str,
    confidence: int | None,
    explicit: bool | None,
    client: Any,
) -> bool:
    """決定是否走 LLM-driven（整段 Python 生成）路徑。

    優先序 (RFC v0.2 D)：

        0. ``client is None``：必走 mock，LLM-driven 沒意義 → 回 False。
        1. ``explicit`` (True/False)：caller 顯式指定，覆寫一切。
        2. Tier 3A/3B/3C/4：UIA-heavy，schema 模板太機械 → True。
        3. ``confidence < 60``：schema 信心低 → True。
        4. 其餘 (Tier 1/2A/2B 高信心)：schema-driven 就夠 → False。
    """
    if client is None:
        return False
    if explicit is not None:
        return explicit
    if tier in _LLM_DRIVEN_TIERS:
        return True
    return bool(
        confidence is not None and confidence < _LLM_DRIVEN_CONFIDENCE_THRESHOLD
    )


def generate_api(
    software_name: str,
    controls: list[UIControl],
    screenshot_path: str | None = None,
    source_text: str | None = None,
    tier: str = "2A",
    client: Any = None,
    fallback_enabled: bool | None = None,
    confidence: int | None = None,
    llm_driven: bool | None = None,
    llm_client: Any = None,
) -> GenerationResult:
    """Generate a complete Python API class from analyzed software.

    Four generation modes (RFC v0.2 D):

    - **mock**: no ``client`` / ``llm_client`` given, uses `_mock_generate`
    - **schema**: Instructor + Pydantic schema fill (``client`` + schema path)
    - **llm_driven**: LLM emits full Python body (``llm_client`` path). Subject
      to AST + structure + safety gates. On validation failure, falls back
      to schema (or mock if ``client`` is None).

    Args:
        software_name: Name of the target software.
        controls: UI controls discovered by the analyzer.
        screenshot_path: Optional path to a window screenshot.
        source_text: Optional extracted source code text.
        tier: Detected software tier (e.g. "2A", "3B").
        client: Optional OpenAI-compatible client for Instructor (schema path).
                If None, uses mock generation (no API key needed).
        fallback_enabled: Optional explicit override. When None, the
            decision is derived from ``tier`` / ``confidence`` via
            :func:`_resolve_fallback_enabled`. Tier 3B/3C/4 auto-enable.
        confidence: Optional tier-detection confidence (0-100). Values
            below 70 auto-enable fallback even on tier 2A.
        llm_driven: Optional explicit override for LLM-driven path. When
            None, routed by :func:`_resolve_llm_driven` (Tier 3A+ or
            confidence < 60 auto-enable).
        llm_client: anthropic-compatible client for LLM-driven generation
            (has ``.messages.create(...)``). If None and ``llm_driven`` is
            True, the LLM-driven path is skipped.

    Returns:
        A GenerationResult with source code, test code, and metadata. The
        ``generation_mode`` field records which path produced the result.
    """
    t0 = time.monotonic()
    resolved_fallback = _resolve_fallback_enabled(tier, confidence, fallback_enabled)
    resolved_llm_driven = _resolve_llm_driven(tier, confidence, llm_driven, llm_client)

    generation_mode = "mock"
    validation_dict: dict[str, Any] | None = None

    # Path 1: LLM-driven (RFC D 項的主角)。失敗時 fall back 到 schema/mock。
    if resolved_llm_driven and llm_client is not None:
        from .llm_generator import llm_driven_generate

        outcome = llm_driven_generate(
            software_name=software_name,
            controls=controls,
            client=llm_client,
            screenshot_path=screenshot_path,
            source_text=source_text,
            tier=tier,
            fallback_enabled=resolved_fallback,
        )
        validation_dict = outcome.validation.to_dict()

        if outcome.validation.passed:
            # LLM 輸出合法：直接用。仍需產 APIClass stub 供 GenerationResult
            # 結構相容（下游 repl/display_router 可能 introspect）。
            api_class = _mock_generate(software_name, controls, tier)
            source_code = outcome.source_code
            test_code = render_test_code(api_class)
            elapsed = time.monotonic() - t0
            return GenerationResult(
                api_class=api_class,
                source_code=source_code,
                test_code=test_code,
                generation_time_seconds=round(elapsed, 3),
                generation_mode="llm_driven",
                validation=validation_dict,
                pattern_used=_primary_pattern_of_class(api_class),
            )

        # 驗證失敗：logger 已由 llm_generator 印出，這裡記 mode 以利觀測
        logger.info(
            "LLM-driven validation failed, falling back to schema/mock: %s",
            "; ".join(outcome.validation.failures),
        )
        generation_mode = "llm_driven_fallback_to_schema"

    # Path 2/3: schema-driven (client) 或 mock (no client)
    if client is not None:
        api_class = _instructor_generate(
            software_name,
            controls,
            screenshot_path,
            source_text,
            tier,
            client,
            fallback_enabled=resolved_fallback,
        )
        if generation_mode == "mock":
            generation_mode = "schema"
    else:
        api_class = _mock_generate(software_name, controls, tier)
        # generation_mode 保持 "mock" 或 "llm_driven_fallback_to_schema"

    source_code = render_api_code(
        api_class, fallback_enabled=resolved_fallback, controls=controls
    )
    test_code = render_test_code(api_class)

    elapsed = time.monotonic() - t0

    return GenerationResult(
        api_class=api_class,
        source_code=source_code,
        test_code=test_code,
        generation_time_seconds=round(elapsed, 3),
        generation_mode=generation_mode,
        validation=validation_dict,
        pattern_used=_primary_pattern_of_class(api_class),
    )
