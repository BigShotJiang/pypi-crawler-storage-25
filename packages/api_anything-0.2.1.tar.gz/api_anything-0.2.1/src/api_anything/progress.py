"""Unified progress bar helpers built on ``rich.progress``.

This module centralises the visual style used across api-anything
(refinement pipeline, bulk detection, pipe helpers, etc.) so every
long-running command emits the same spinner + bar + elapsed layout.

Usage
-----
Determinate iterable (known length)::

    from api_anything.progress import progress_bar

    with progress_bar(items, description="Refining") as it:
        for item in it:
            do_work(item)

Indeterminate spinner (unknown duration)::

    from api_anything.progress import indeterminate

    with indeterminate("Connecting to MCP client..."):
        connect()

Custom layout::

    from api_anything.progress import ApiAnythingProgress

    with ApiAnythingProgress() as progress:
        task = progress.add_task("Working", total=100)
        for i in range(100):
            step()
            progress.advance(task)
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from typing import TypeVar

from rich.console import Console
from rich.progress import (
    BarColumn,
    MofNCompleteColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeElapsedColumn,
)

T = TypeVar("T")

# ---------------------------------------------------------------------------
# Standard progress class
# ---------------------------------------------------------------------------


class ApiAnythingProgress(Progress):
    """Shared ``rich.progress.Progress`` preset for api-anything commands.

    Columns: spinner + description + bar + M/N + elapsed time.
    Pass any extra ``Progress`` kwargs (``console``, ``transient``,
    ``refresh_per_second`` ...) through the constructor.
    """

    def __init__(
        self,
        *,
        console: Console | None = None,
        transient: bool = False,
        refresh_per_second: float = 10.0,
    ) -> None:
        super().__init__(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(bar_width=None),
            MofNCompleteColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
            transient=transient,
            refresh_per_second=refresh_per_second,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@contextmanager
def progress_bar(
    iterable: Iterable[T],
    description: str = "Working",
    *,
    total: int | None = None,
    console: Console | None = None,
    transient: bool = False,
) -> Iterator[Iterator[T]]:
    """Wrap an iterable with a shared-style progress bar.

    Parameters
    ----------
    iterable:
        Any iterable; if it has ``__len__`` the length is used as ``total``.
    description:
        Short label shown next to the bar.
    total:
        Explicit total (overrides inferred length).
    console:
        Optional Rich console.
    transient:
        If True, the bar disappears after completion.

    Yields
    ------
    Iterator[T]
        A fresh iterator that advances the progress bar on every ``next()``.
    """
    resolved_total: int | None = total
    if resolved_total is None:
        try:
            resolved_total = len(iterable)  # type: ignore[arg-type]
        except TypeError:
            resolved_total = None

    progress = ApiAnythingProgress(console=console, transient=transient)

    def _iter() -> Iterator[T]:
        task_id = progress.add_task(description, total=resolved_total)
        for item in iterable:
            yield item
            progress.advance(task_id)

    with progress:
        yield _iter()


@contextmanager
def indeterminate(
    description: str = "Working",
    *,
    console: Console | None = None,
) -> Iterator[None]:
    """Spinner-only context for tasks of unknown duration.

    Example::

        with indeterminate("Booting MCP server"):
            start_server()
    """
    progress = ApiAnythingProgress(console=console, transient=True)
    progress.start()
    try:
        progress.add_task(description, total=None)
        yield
    finally:
        progress.stop()


__all__ = [
    "ApiAnythingProgress",
    "indeterminate",
    "progress_bar",
]
