"""API-Anything: Auto-generate Python APIs from any software."""

__version__ = "0.2.1"
