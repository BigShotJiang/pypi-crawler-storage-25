"""YAML schemas mapping primary API methods to CLI-Anything subcommands.

Each ``<software>.yaml`` describes:
    cli_binary: cli-anything-<software>
    version_pin: <semver range>   # soft warning only
    methods:
      <primary_method_name>:
        subcmd: <cli subcommand>
        args:    [positional arg names]
        options: [optional flag list]

Loaded by :func:`api_anything.cli_fallback.load_schema`.
"""
