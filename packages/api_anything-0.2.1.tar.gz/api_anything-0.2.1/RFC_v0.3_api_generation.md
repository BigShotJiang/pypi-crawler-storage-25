# RFC v0.3 — API-Anything API Generation（Vision + Record-Replay）

**狀態**：草案（2026-04-17）
**作者**：AI King
**基準版本**：v0.2（RFC_v0.2.md，UIA / CLI fallback / display_router / LLM-driven generate）
**目標版本**：v0.3.0
**平台**：**Windows-first**（Mac 降到 v0.4+）

## 替代舊檔 RFC_v0.3_computer_use.md（2026-04-17 砍除，原方向為 Operator agent 偏離 api-anything 定位）

---

## A. 總論

### A.1 定位聲明（ONE SENTENCE）

> **api-anything v0.3 = 加彈藥 2（Vision）與彈藥 3（Record-Replay），讓 Tier 3-4（Electron / Canvas / 閉源 / 自繪）也能生出可 `from api_anything.apis import X; x = X(); x.method(...)` 的可 import Python class，API 表面一致，內部實作因 tier 而異。**

### A.2 非目標（明確列出）

- ❌ **不做 Operator**（user says X → agent does X once）
- ❌ **不做 runtime agent loop**（observe→plan→act→verify 不屬 api-anything 範疇）
- ❌ **不做自然語言 runtime**（v0.3 不提供 `api-anything operator "指令"` 這種入口）
- ❌ **不做 Mac / Linux**（v0.4+ 才考慮）
- ❌ **不做 GPT / Gemini computer use**（只做 Claude；Claude 是**生成期工具**，不是執行期 agent）
- ❌ **不做協議 sniff**（彈藥 4 灰區 EULA，KILL）
- ❌ **不做 DLL / memory inject**（彈藥 5 紅區法律，KILL）
- ❌ **不做 OSWorld 跑分**（那是 Sancio G6 賽道線）
- ❌ **不做 Sancio 整合**（Sancio 若需呼叫 api-anything 是單向依賴，api-anything 不反向）
- ❌ **不做桌面產品 UI**（record CLI 入口 + Python lib）

### A.3 用戶糾正（原話保留）

**2026-04-17 用戶糾正**（`feedback_api_anything_is_api_not_agent.md` / `feedback_ammo_thinking_cli_parity.md`）：

> 「你搞錯了 我是要讓你做出 API 來 我以為你是看螢幕截圖自己做出來 但如果他沒有接口你能否破解進去 不過這可能侵犯隱私 如果你做不出 API 純滑鼠操控 那就不是 API 範圍 識別的工具功能了 API anything 主打就是 API 就是要做出 API 做不出來 那就是將定位轉變」

> 「就是要做出 API 做不出來 那就是將定位轉變 彈藥思考 CLI 能做到的 API 也要能做到 不然天生就輸她一大截」

**核心差異**：

| 維度 | Operator（錯方向）| API-Anything（對方向）|
|---|---|---|
| 單次 vs 永久 | 每次講話 agent runtime 現場做 | 一次生出 Python class，之後任何 script import 重用 |
| 輸出形態 | 一次性執行結果 | 可重用 `.py` artifact（Pydantic-grade API surface）|
| Claude CU 角色 | runtime agent brain | **生成期工具**（探索軟體 → 產出 method schema）|
| Vision 角色 | 即時點擊 | 生成的 method **內部實作**（一次性訂好，執行期不 LLM）|

---

## B. 三彈藥整合架構

### B.1 五彈藥採納決策（一次列全，避免再走回頭路）

| # | 彈藥 | 決策 | 理由 |
|---|---|---|---|
| 1 | UIA / CLI | ✅ v0.2 已做，v0.3 **改造為 pattern-based dispatch** | 基礎盤，ship-ready |
| 2 | Vision → click | ✅ v0.3 M1 | Tier 3-4 核心彈藥 |
| 3 | Record → Replay | ✅ v0.3 M2 | 用戶教一次即可解鎖 Tier 4 |
| 4 | Protocol sniff（DevTools / 本地 HTTP/IPC）| ❌ | EULA 灰區 + 用戶明說隱私顧慮 |
| 5 | DLL / memory inject | ❌ | 法律紅區 |

### B.2 Tier ↔ 彈藥對應表

| Tier | 描述 | 主彈藥 | Fallback 鏈 | 預估 confidence |
|---|---|---|---|---|
| 1 | PyPI 直包 | 直接 wrap | — | 95% |
| 2A | Source + CLI | subprocess | UIA | 88% |
| 2B | Source only | subprocess / UIA | — | 80% |
| 3A | UIA-rich（≥70% named）| **UIA pattern** | Vision | 85% |
| 3B | UIA-partial（30-70%）| UIA pattern | **Vision** → Record-Replay | 72% |
| 3C | UIA-sparse（<30%）| **Vision** | Record-Replay | 65% |
| 4 | Canvas / Electron / 自繪 | **Record-Replay**（首選）+ Vision | Claude CU 遠端 fallback | 55% |

**設計哲學**：越低 tier，Record-Replay 權重越高（靠用戶親自示範換取 schema 準度）。Vision 為中間層彈藥（VLM 看截圖生 bbox → 生的 method 內嵌 bbox + verify）。

### B.3 `generator.py` 新分支邏輯（偽碼）

```python
def generate_api(
    software_name: str,
    *,
    controls: list[UIControl],
    screenshot_path: str | None = None,
    source_text: str | None = None,
    tier: str = "2A",
    vision_candidates: list[VisionElement] | None = None,   # v0.3 新
    record_trace: RecordTrace | None = None,                # v0.3 新
    client: Any = None,
) -> GenerationResult:
    # 1) 三源彈藥優先序（以 tier 為路由）
    if record_trace is not None:
        # 彈藥 3 最強：用戶手動示範過一次 → LLM 推 schema
        return _generate_from_record(record_trace, software_name, client)

    if tier in {"3C", "4"} or vision_candidates:
        # 彈藥 2：Vision 生成 pseudo-UIControl → 走 UIA-like 路徑
        pseudo_controls = _vision_to_pseudo_controls(
            vision_candidates or []
        )
        controls = (controls or []) + pseudo_controls
        return _generate_with_vision_methods(
            software_name, controls, screenshot_path,
            tier=tier, client=client,
        )

    # 彈藥 1：UIA pattern-based dispatch（v0.3 改造）
    return _generate_pattern_based(
        software_name, controls, source_text,
        tier=tier, client=client,
    )
```

### B.4 API 表面一致性保證

**生的 class 不因內部實作變動而改 user-facing signature**。

```python
# Tier 1（PyPI binding）
class FFmpeg:
    def convert(self, input: str, output: str, *, codec: str = "h264") -> Path: ...

# Tier 3B（UIA + Vision fallback）
class Audacity:
    def export_wav(self, path: str) -> Path: ...   # 內部：UIA → Vision → Claude CU

# Tier 4（Record-Replay）
class BaiduNetdisk:
    def upload(self, local_path: str, remote_path: str = "/") -> dict: ...
```

**Contract**：調用者**永遠不會看到** vision bbox、Claude prompt、UIA control path。這些全是 method body 內部。

---

## C. 彈藥 1：UIA Pattern → method_template（改造）

### C.1 根本改動：`control_type → method_prefix` 改為 `pattern → method_template`

v0.2 現狀（`generator.py:_mock_generate`）：
- `Button → click_<name>()`
- `TextBox → set_<name>(value)`
- `Menu → open_<name>()`

**問題**：`Button` 不一定支援 `InvokePattern`（可能是 toggle button）；`ComboBox` 同時支援 `ExpandCollapsePattern` + `SelectionPattern` 應生兩個 method；confidence 只有 60-70%。

**v0.3 改造**：`pattern → method_template`。Control 先問支援哪些 pattern，每 pattern 對應一個 method template。

### C.2 22 UIA Pattern → method template 對應表

| Pattern | 典型控制 | method template | body 範例 |
|---|---|---|---|
| **InvokePattern** | Button | `<verb>_<name>()` | `ctrl.GetInvokePattern().Invoke()` |
| **ValuePattern** | TextBox / Edit | `set_<name>(value: str)` + `get_<name>() -> str` | `ctrl.GetValuePattern().SetValue(value)` |
| **RangeValuePattern** | Slider / Spinner | `set_<name>(value: float)` | `ctrl.GetRangeValuePattern().SetValue(value)` |
| **TogglePattern** | CheckBox | `toggle_<name>()` + `is_<name>() -> bool` | `ctrl.GetTogglePattern().Toggle()` |
| **ExpandCollapsePattern** | Menu / TreeItem | `expand_<name>()` + `collapse_<name>()` | `ctrl.GetExpandCollapsePattern().Expand()` |
| **SelectionPattern** | ListBox container | `select_<name>(option: str)` | walk children + `GetSelectionItemPattern().Select()` |
| **SelectionItemPattern** | list item | `select_<parent>_<item>()` | `ctrl.GetSelectionItemPattern().Select()` |
| **ScrollPattern** | Scrollable | `scroll_<name>(direction: str, amount: float)` | `ctrl.GetScrollPattern().SetScrollPercent(...)` |
| **ScrollItemPattern** | list item | `scroll_into_view_<name>()` | `ctrl.GetScrollItemPattern().ScrollIntoView()` |
| **TextPattern** | RichEdit / Document | `get_text_<name>() -> str` | `ctrl.GetTextPattern().DocumentRange.GetText(-1)` |
| **GridPattern** | 表格 | `get_cell_<name>(row: int, col: int)` | `ctrl.GetGridPattern().GetItem(row, col)` |
| **TablePattern** | 含 header 表 | 同 Grid + header 查詢 | — |
| **TransformPattern** | 可拖移元素 | `move_<name>(x: float, y: float)` / `resize_<name>(w,h)` | `.GetTransformPattern().Move(x, y)` |
| **WindowPattern** | 頂層視窗 | `maximize_<name>()` / `minimize_<name>()` / `close_<name>()` | `.GetWindowPattern().SetWindowVisualState(...)` |
| **DockPattern** | toolbar | 略（罕用）| — |
| **MultipleViewPattern** | list view | `set_view_<name>(view: str)` | — |
| **VirtualizedItemPattern** | 虛擬列表項 | `realize_<name>()` | `.GetVirtualizedItemPattern().Realize()` |
| **ItemContainerPattern** | virtual container | `find_<name>(property, value)` | — |
| **LegacyIAccessiblePattern** | 舊 MSAA | fallback：`default_action_<name>()` | `.GetLegacyIAccessiblePattern().DoDefaultAction()` |

（省略 GridItem / TableItem / SynchronizedInput 等罕用 pattern，生成時如遇到再補）

### C.3 generator.py 改動點

**新增 `models.APIMethod.uia_pattern: Literal[...] | None`**：

```python
class APIMethod(BaseModel):
    name: str
    params: list[APIParam]
    return_type: str
    docstring: str
    operation_mode: Literal["subprocess", "uia", "vision", "replay"]   # v0.3 加後兩
    uia_pattern: Literal[
        "invoke", "value", "toggle", "selection", "expand_collapse",
        "scroll", "range_value", "window", "transform", "text", "grid",
    ] | None = None
    # 生成期信心 / 最後驗證時間（透明化給調用者）
    generation_confidence: int = 70
    last_verified_at: str | None = None
    internal_mode: str | None = None   # "uia" / "vision" / "replay" — __repr__ 用
```

**新增 `_get_supported_patterns(control) -> list[PatternName]`**（呼叫 `uiautomation` 反射）。

**`_render_method` 依 pattern 分派 body**：

```python
def _render_method_body(method: APIMethod, control: UIControl) -> str:
    template = _PATTERN_TEMPLATES[method.uia_pattern]
    return template.format(
        control_path=_build_control_path(control),
        params=method.params,
    )
```

### C.4 Test plan

- `test_generator_patterns.py`（新，~40 test）：
  - 每個 pattern 各 1-2 test，驗 template 輸出
  - mock `uiautomation` control，驗 dispatch 正確
  - 驗 ComboBox 產出**兩個** method（expand + select）
- `test_generator.py` 擴充：
  - pattern 對應 confidence 提升檢查（2A/3A 從 70% → 85%）

### C.5 預估 LOC + 工時

- LOC：+350（核心 dispatch +120 / pattern templates +150 / tests +80）
- 工時：**2 工作天**（1.5 天 dispatch + 0.5 天 test）
- 為什麼做：2A/3A confidence 從 60-70% 提到 85%+，直接解鎖 ~60% 現有 27 APIs 的 method body 從 `raise NotImplementedError` 變可跑。

---

## D. 彈藥 2：Vision → click

### D.1 技術 Stack

| 角色 | 首選 | 備援 | 為什麼 |
|---|---|---|---|
| **Tier 4 生成期 brain（本地）** | **Qwen2.5-VL-7B**（HF transformers / vLLM）| OS-Atlas-7B / ShowUI-2B | 單卡 4090 / 5090 可跑 16GB VRAM；cookbook 有 `computer_use.ipynb`；Apache 2.0 |
| **生成期 brain（遠端）** | **Claude CU Opus 4.7**（`computer_20251124`）| OpenAI CU gpt-5.4 | `zoom` action 省 token；長邊 2576px 1:1；動作原語完整 |
| **grounding primitive**（description → bbox）| **OS-Atlas-7B**（`model.chat("click Save → (x,y)")`）| Qwen2.5-VL 原生 grounding | 最 drop-in，單 call 回 normalized 0-1000 座標 |
| **執行期 click / type** | pywinauto 座標點擊 / `win32api.mouse_event` / SendInput | windows Skill `uia_*` / windows Skill `run_in_hidden_desktop` | 無 LLM call，生成期訂好就 replay |

**KILL**：OpenCUA-72B（租金不值）/ Gemini CU（browser-only）/ ScaleCUA（research 線）。

### D.2 API 內部實作樣式

```python
class VSCodeAPI:
    """Generated from vision introspection (Tier 4)."""

    def open_folder(self, folder_path: str) -> None:
        """
        Open a folder in VS Code.

        internal_mode: vision
        generation_confidence: 78
        last_verified_at: 2026-04-17T10:30:00Z
        """
        # 生成期訂好的 bbox（0-1000 normalized），執行期直接點
        bbox = (120, 45, 210, 75)  # "File" menu 的 normalized box
        self._backend.click_normalized_bbox(bbox)
        # 開啟 dialog → 用 UIA SetValue 填路徑（vision 生成期已驗證 dialog 可 UIA 操作）
        self._backend.wait_for_window("Open Folder")
        self._backend.set_value(automation_id="1148", value=folder_path)
        self._backend.click_button(name="選擇資料夾")

    def _fallback_record_replay(self, method_name: str, **kwargs):
        """Used when vision bbox drifts on app update."""
        raise NotImplementedError(...)  # → runtime fallback 去 record-replay
```

**關鍵設計**：method body **生成期就訂好 bbox + verify point**，執行期 **不打 LLM API**。只有 bbox 失效才會 fallback 到 record-replay（或重跑 generator）。

### D.3 Prompt 策略：Set-of-Marks (SoM)

從 SOTA 筆記 §2.7：**VLM 辨識編號比辨識座標準**。

生成期 pipeline：

```
screenshot
  ↓
bbox detector（OS-Atlas-7B 或 Qwen2.5-VL grounding）
  ↓
overlay 編號 1, 2, 3, ...（Microsoft SoM 模組）
  ↓
VLM prompt："Which numbered element is the 'Save' button?"
  ↓
VLM reply："Element 7"
  ↓
取 element 7 的 bbox + semantic label
  ↓
存為 method 內嵌 bbox
```

**Token 成本估算**（從 SOTA 筆記 §2.8）：
- Claude CU system prompt 466-499 tokens + tool def 735 tokens（每次 API call）
- Opus 4.7 長邊 2576px 1:1 無需 scale
- **生成期**一次性成本（Tier 4 App 跑 ~30 method × 2-3 call = ~150-200 API call）→ 估 $5-15 per Tier 4 API class
- **執行期**0 LLM call（bbox 訂死）

### D.4 新 module 設計（生成期 vs 執行期分離）

**生成期 `src/api_anything/vision_generator.py`**（LLM 參與）：

```python
class VisionGenerator:
    def __init__(self, backend: VLMBackend):
        """backend = Qwen25VLBackend / OSAtlasBackend / ClaudeCUBackend."""
        self.backend = backend

    def introspect(self, window_handle: int, screenshots: int = 5) -> list[VisionElement]:
        """掃 N 張螢幕 → 推 UI element bbox + label。生成期一次，之後不跑。"""

    def verify_element(self, elem: VisionElement, screenshot: bytes) -> bool:
        """驗生成期的 bbox 在後續截圖仍有效。"""
```

**執行期 `src/api_anything/vision_runtime.py`**（**無 LLM**）：

```python
class VisionRuntime:
    """Replay pre-baked vision bboxes. No LLM at runtime."""

    def click_normalized_bbox(self, bbox: tuple[int, int, int, int]) -> None:
        """座標乘回視窗實際 WxH → SendInput。"""

    def find_window_by_title(self, title: str) -> int: ...

    def verify_state_change(self, expected_screenshot_hash: str) -> bool:
        """selective 驗證：只在 method 結尾截圖比對，非 LLM call。"""
```

**設計原因**：訓 / 執行分離 = 執行期可離線 = 執行期成本 0。

### D.5 失敗 fallback 鏈

```
method call
  ↓
Vision bbox click（生成期訂好的）
  ↓ fail（verify_state_change == False）
Record-Replay event sequence（若存在）
  ↓ fail
raise APIGenerationDrift("bbox/event stale, re-run api-anything regenerate <app>")
```

**不 auto-fallback 到 Claude CU 遠端 brain**（避免用戶不小心燒 token）。用戶要主動 `api-anything regenerate --provider claude-cu`。

### D.6 Test plan

- `test_vision_generator.py`（新，~25 test）：
  - mock VLM backend 回傳固定 bbox → 驗 pseudo-UIControl 型別正確
  - 驗 method 能 import（`exec(rendered_code)`）
  - 驗 click coord 型別是 `tuple[int, int, int, int]`
- `test_vision_runtime.py`（新，~15 test）：
  - mock `win32api.mouse_event` → 驗座標 scale 正確
  - verify_state_change hash 比對邏輯
- integration：跑一次 mock screenshot → pseudo-UIControl → render → compile

### D.7 預估 LOC + 工時

- LOC：+900（vision_generator +350 / vision_runtime +200 / VLM backends 3 個 +200 / tests +150）
- 工時：**5 工作天**（2 天 VLM backend / 1.5 天 generator / 1 天 runtime / 0.5 天 test）
- 風險：Qwen2.5-VL 下載 16GB；CI 上 mock 即可，但本機實測需 GPU。無 GPU 時走 Claude CU backend。

---

## E. 彈藥 3：Record → Replay

### E.1 Recorder 是一等公民（SOTA 筆記 §3 關鍵發現）

**為什麼不用 `pywinauto_recorder`**：
1. 2024-03 停滯（~2 年未更新）
2. bare rawhook，無 screenshot diff
3. 直接輸出 Python script 難後製（無中間 JSON 可讓 LLM 分析）
4. 無 event 過濾（click 每次滑過都記）

**api-anything 自建 recorder**：從 UIA `AutomationEventHandler` 抓 event，非從 SendInput hook 抓座標。這樣 **resolution-independent + 每 event 自帶 control path**。

### E.2 Recorder 三層錄製架構

```
User presses Ctrl+Alt+R (or runs `api-anything record <app>`)
    ↓
三條 hook 並行啟動：
    ┌──────────────────────────────────────────────┐
    │ A. UIA AutomationEventHandler（主軸）           │
    │    - UIA_Invoke_InvokedEventId (button click)  │
    │    - UIA_Value_ValuePropertyId (text 變動)      │
    │    - UIA_Selection_SelectionChangedEventId     │
    │    - 產 control_path + pattern event            │
    ├──────────────────────────────────────────────┤
    │ B. mss screenshot stream（每 500ms snap）       │
    │    - 當 UIA 漏時靠截圖 diff 補                  │
    │    - 存成 thumbnail（60x60）給 LLM 看          │
    ├──────────────────────────────────────────────┤
    │ C. keyboard/mouse raw hook（pyinput / pyhook）  │
    │    - UIA 沒抓到的動作（hotkey / Canvas click）  │
    │    - 過濾：只記 discrete event，不記 mouse_move │
    └──────────────────────────────────────────────┘
    ↓
Event stream (Pydantic, JSON lines):
[
  {"ts": 0.0, "type": "uia.Invoke", "control_path": "Window[Notepad] > MenuBar > File > Open", "screenshot": "p001.png"},
  {"ts": 1.2, "type": "uia.Value", "control_path": "Dialog[Open] > Edit[File name]", "value": "C:/tmp/a.txt"},
  {"ts": 2.5, "type": "uia.Invoke", "control_path": "Dialog[Open] > Button[Open]"},
  {"ts": 3.8, "type": "uia.Value", "control_path": "Window[Notepad] > Edit", "value": "<file content loaded>"}
]
    ↓
User presses Ctrl+Alt+S (stop recording)
    ↓
LLM 推 API schema（給 event stream + 縮圖）:
  Prompt: "Infer a Python method signature that replays this sequence parametrized.
           Identify which text inputs are 'parameters' the user would want to change."
  Output: APIMethod(
      name="open_file",
      params=[APIParam(name="path", type="str")],
      operation_mode="replay",
      record_trace_id="trace_001.jsonl",
  )
    ↓
render：method body 內嵌 `self._replay_trace("trace_001", path=path)`
```

### E.3 新 module 設計

**`src/api_anything/recorder.py`**（錄製）：

```python
from pydantic import BaseModel

class RecordEvent(BaseModel):
    ts: float
    event_type: Literal["uia.Invoke", "uia.Value", "uia.Selection", "key", "mouse"]
    control_path: str | None
    value: str | None
    screenshot_ref: str | None   # 相對於 trace dir

class RecordTrace(BaseModel):
    app_name: str
    started_at: str
    events: list[RecordEvent]
    thumbnails_dir: Path
    trace_id: str

class Recorder:
    def __init__(self, app_name: str): ...
    def start(self) -> None: ...
    def stop(self) -> RecordTrace: ...
    def save(self, trace: RecordTrace, path: Path) -> None: ...
```

**`src/api_anything/replay.py`**（執行期 replay，**無 LLM**）：

```python
class Replayer:
    def __init__(self, trace: RecordTrace): ...

    def replay(self, **params: str) -> None:
        """Replay event sequence, substitute param values into Value events."""
        for event in self.trace.events:
            if event.event_type == "uia.Invoke":
                self._uia_invoke(event.control_path)
            elif event.event_type == "uia.Value":
                # 檢查該 value 是否對應 method param
                actual_value = self._substitute_params(event.value, params)
                self._uia_set_value(event.control_path, actual_value)
            elif event.event_type == "key":
                self._send_key(event.value)
```

**`generator.py` 新增 `_generate_from_record(trace, software_name, client)`**：
- LLM 對 event stream 分群（「連續 3 個 UIA event = 一個 method」）
- LLM 推 method name + params
- render：method body = `self._replayer.replay(trace="trace_001", **locals())`

### E.4 CLI 入口

```bash
# 錄製模式
api-anything record baidu-netdisk
# → 啟動 recorder，在 console 顯示「Recording... Press Ctrl+Alt+S to stop」
# → 用戶操作目標 App
# → 停止後存到 .api_anything_traces/baidu-netdisk_001.jsonl + thumbnails/

# 從 trace 生 API
api-anything generate baidu-netdisk --from-trace .api_anything_traces/baidu-netdisk_001.jsonl
# → 輸出 src/api_anything/apis/baidu_netdisk.py
```

### E.5 Test plan

- `test_recorder.py`（新，~20 test）：
  - mock `uiautomation.AddAutomationEventHandler` → 驗 event stream Pydantic valid
  - event 過濾邏輯（連續 mouse_move 被壓縮為 1 event）
- `test_replay.py`（新，~15 test）：
  - 給定 trace → mock UIA → 驗 replay 呼叫正確
  - param substitution（trace 裡的 `"C:/tmp/a.txt"` 被 `path` param 覆蓋）
- `test_generator_record.py`（新，~10 test）：
  - mock LLM → 驗 method schema 正確
  - 驗 render 的 method body 含 replay call

### E.6 預估 LOC + 工時

- LOC：+800（recorder +300 / replay +200 / generator 接線 +100 / CLI +50 / tests +150）
- 工時：**6 工作天**（2 天 recorder UIA event hook / 1 天 mss thumbnail / 1 天 replay / 1 天 LLM schema infer / 1 天 test）
- 風險：UIA event hook 在某些 Electron app 可能只抓到頂層 window event。解法：降級走 B 條線（screenshot diff + 鍵鼠 hook）。

---

## F. 實作 DAG + Milestones

### F.1 DAG

```
M0 prep（砍舊 RFC + pattern dispatch 改造 prereq）
  │
  ▼
M1 Vision generator（彈藥 2）
  │── Qwen2.5-VL local backend
  │── Claude CU remote backend
  │── VisionGenerator + VisionRuntime 分離
  │
  ▼
M2 Recorder（彈藥 3）
  │── UIA AutomationEventHandler 三層 hook
  │── Replayer param substitution
  │── CLI record subcommand
  │
  ▼
M3 百度網盤 Tier 4 實戰
  │── M1 + M2 混合
  │── 產出 BaiduNetdisk.py
  │
  ▼
M4 ship v0.3.0
```

### F.2 每 milestone 明細

| 里程碑 | LOC 增 | Tests 增 | 工時 | 主要產出 | Exit criteria（ship ready 標準）| 風險 |
|---|---|---|---|---|---|---|
| **M0 prep** | +350 | +40 | **2d** | (a) 舊 RFC 刪 (b) `generator._mock_generate` 改 pattern-based dispatch (c) `APIMethod.uia_pattern` 欄位落地 | `pytest tests/ -q` 全綠；5 既有 API（notepad/audacity/kdenlive/krita/ffmpeg）regenerate 後 method body 不是 `raise NotImplementedError`；confidence 提升記錄 | Low — 純重構既有 |
| **M1 Vision** | +900 | +70 | **5d** | `vision_generator.py` / `vision_runtime.py` / 3 個 VLM backend | 對 Discord（Tier 4）跑 `api-anything generate discord --vision` 產出 `DiscordAPI` class 能 import；至少 1 個 method 實測能送訊息；mock test 全綠 | Medium — Qwen2.5-VL 下載 16GB，本地 VLM 精度 |
| **M2 Recorder** | +800 | +60 | **6d** | `recorder.py` / `replay.py` / `cli record` | 錄一次 Notepad 開檔 → `trace_001.jsonl` + thumbnails → regenerate 產 `NotepadAPI.open_file(path)` 能 replay 成功；錄 Audacity export 同等驗證 | Medium — UIA event hook Electron 覆蓋率未知 |
| **M3 百度網盤** | +300 | +25 | **3d** | `BaiduNetdisk.py`（用 M2 錄製 + M1 vision 混合）| `from api_anything.apis import BaiduNetdisk; b = BaiduNetdisk(); b.upload(...)` 實機可跑；用戶親自錄一次 upload + download，其他 method 靠 vision 補 | **High** — Electron 反自動化 + 百度可能 update UI |
| **M4 ship** | +100 | +20 | **2d** | version bump / CHANGELOG / RELEASE_COORDINATION 更新 / tag v0.3.0 | 依 `RELEASE_COORDINATION.md` 完成 tests/lint/三版號對齊；不自動 publish PyPI | Low |

**總計**：+2450 LOC / +215 tests / **18 工作天**（~4 週 calendar）

### F.3 阻擋依賴

- M1 不依賴 M0 完成的 pattern dispatch（但 M0 先做讓 prompt hints 更好）
- M2 不依賴 M1（可並行，兩人團隊可拆）
- M3 依賴 M1 + M2 皆完成
- M4 依賴 M0-M3 皆達 exit criteria

---

## G. 百度網盤 Tier 4 testbed

### G.1 為什麼選百度網盤

- Electron App（MEMORY `_KNOWN_ELECTRON_APPS` 已標 `baidupan`）
- Tier 4（runtime probe 會 demote，UIA 只露頂層 PaneControl）
- **用戶實際在用**（已裝 + 有資料）→ 真 use case
- **沒有官方 Python SDK**（真 `cli-anything-*` gap 補洞對象）
- 中文 App（測 VLM CJK 辨識 + UIA CJK control name）

### G.2 預期生出的 API surface（4-6 個核心 method）

```python
class BaiduNetdisk:
    """Generated 2026-04-??  from record-replay + vision on 百度網盤 vX.Y.Z."""

    def __init__(self, *, instance_selector: str | None = None): ...

    # --- 核心四根（MEMORY #40 堆積木策略）---
    def upload(self, local_path: str, remote_path: str = "/") -> dict:
        """Upload a local file. Returns {'task_id': ..., 'status': 'queued'}.
        internal_mode: replay
        generation_confidence: 72
        """

    def download(self, remote_path: str, local_path: str) -> Path:
        """Download a remote file. Returns local Path.
        internal_mode: replay
        generation_confidence: 68
        """

    def list_files(self, remote_path: str = "/") -> list[dict]:
        """List files in remote dir. Returns [{'name':..., 'size':..., 'modified':...}].
        internal_mode: vision  # UIA list 結構 Electron 不穩，vision bbox 抓 row
        generation_confidence: 62
        """

    def get_transfer_status(self, task_id: str) -> dict:
        """Query transfer progress. Returns {'progress': 0.47, 'state': 'transferring'}.
        internal_mode: vision
        generation_confidence: 60
        """

    # --- 加分兩根（如時間允許）---
    def create_folder(self, remote_path: str) -> None: ...
    def delete(self, remote_path: str) -> None: ...
```

### G.3 彈藥組合策略

- **登入**：**用戶手動**（app 內掃碼 / SMS），API 不碰（反自動化 + 法律邊界）
- **upload / download**：**M2 Record-Replay 優先**（用戶親手操一次，replay 最穩）
- **list_files / get_transfer_status**：**M1 Vision 優先**（動態內容，record 難 parametrize）
- **create_folder / delete**：如 UIA 有曝光（右鍵 menu），走 M0 pattern dispatch；否則 record-replay

### G.4 法律邊界

- ✅ **純 GUI 層模擬用戶行為** = 合法（等同用戶自己點）
- ❌ **不碰協議 sniff**（百度協議逆向 = EULA 違反）
- ❌ **不 inject DLL**（法律紅區）
- ✅ **登入讓用戶手動做**，降封號風險

---

## H. API 表面 Contract（跨彈藥一致）

所有 v0.3 生的 class 都必須具備：

### H.1 `__init__(*, instance_selector=None)`

多開支援。`instance_selector` 可為 window handle / window title / process ID。None = 自動選第一個。

```python
class BaiduNetdisk:
    def __init__(self, *, instance_selector: str | int | None = None):
        self._window = _find_window(
            app_name="百度網盤",
            selector=instance_selector,
        )
```

### H.2 `methods: list[str]` property

自省可用 method（給 LLM agent 或 REPL 顯示用）：

```python
@property
def methods(self) -> list[str]:
    """List callable user-facing methods."""
    return [
        m for m in dir(self)
        if not m.startswith("_") and callable(getattr(self, m)) and m != "methods"
    ]
```

### H.3 每 method docstring 含三欄位

```
internal_mode: uia | subprocess | vision | replay
generation_confidence: 0-100
last_verified_at: ISO 8601
```

render 時由 generator 自動填入。

### H.4 `diagnose()` method

每 class 自帶自檢：

```python
def diagnose(self) -> dict:
    """Run a one-shot self-check.
    Returns {'window_found': bool, 'methods_total': int,
             'methods_by_mode': {...}, 'warnings': [...]}.
    """
```

### H.5 `__repr__`

```python
def __repr__(self) -> str:
    return (
        f"<BaiduNetdisk tier=4 modes={['replay', 'vision']} "
        f"confidence_avg=67 methods=6 generated_at=2026-04-17>"
    )
```

### H.6 Contract 落地

**新增 `src/api_anything/api_base.py`**（抽象基底 class），所有 `apis/*.py` 繼承：

```python
class GeneratedAPIBase:
    _api_meta: ClassVar[APIMeta]  # tier / generated_at / confidence_avg

    def __init__(self, *, instance_selector=None): ...
    @property
    def methods(self) -> list[str]: ...
    def diagnose(self) -> dict: ...
    def __repr__(self) -> str: ...
```

**generator.py render 階段強制繼承**。

---

## I. v0.3 → v0.4 分界

### I.1 v0.3 不做（明確剔除）

- ❌ Mac / Linux backend
- ❌ GPT computer use / Gemini computer use
- ❌ 協議 sniff / DevTools Protocol hook
- ❌ DLL / memory injection
- ❌ Agent loop / 自然語言 runtime
- ❌ OSWorld / WebArena 跑分
- ❌ Sancio 整合 bridge

### I.2 v0.4+ 考慮

- ✅ Mac backend（`pyobjc-framework-Accessibility` + AppleScript）
- ✅ 更多 VLM provider（OpenAI CU / Gemini CU 若用戶需要）
- ✅ Recorder thumbnail → diff-based parametrization（例：用戶第 1 次和第 2 次錄不同檔名 → 自動推 param）
- ✅ Cross-app API composition（`BaiduNetdisk().download(x).then(VSCode().open_folder(x))` 之類）

### I.3 永不做

- 協議 sniff（EULA 灰區）
- DLL inject（法律紅區）
- Runtime agent loop（不是 api-anything 範疇）

---

## J. 與 v0.2 的接續關係

| v0.2（既有）| v0.3 改動 | 關係 |
|---|---|---|
| `tier_detect.py` | **不動** | v0.3 tier 判斷沿用 |
| `generator.py:_mock_generate` | **改 pattern-based dispatch** | M0 核心 |
| `generator.py:generate_api` | **加 `vision_candidates` / `record_trace` 參數** | M1/M2 接線 |
| `models.APIMethod` | **加 `uia_pattern` / `internal_mode` / `generation_confidence` / `last_verified_at`** | 全向下相容（default 值）|
| `cli_fallback.py` | **不動**，保留 Tier 3B/3C/4 的 CLI 退路 | 和新彈藥併存 |
| `display_router.py` | 加 `render_record_trace` / `render_vision_candidates` | 可選，M2/M1 各加 1 method |
| `apis/*.py` 27 支 | M0 後逐步 regenerate（不強制）| 可選 |
| `cli.py` | **加 `record` subcommand** | M2 |

**無 breaking change**。所有新增參數有 default，新 field 為 Optional。

---

## K. Exit Criteria（WIREDO）

- [ ] **W** Wired：`vision_generator.py` / `recorder.py` 被 `generator.py:generate_api` dispatch（grep 確認非孤島）
- [ ] **W** Wired：`cli record` subcommand 接線到 `Recorder`
- [ ] **W** Wired：`GeneratedAPIBase` 被所有 v0.3 新生的 API class 繼承
- [ ] **I** Inherited：新模組遵循 `from __future__ import annotations` + Pydantic 慣例
- [ ] **I** Inherited：VLM backend 抽象層命名與既有 `cli_fallback_schemas` 風格對齊
- [ ] **R** Responsive：`api-anything record <app>` 啟動 <2s
- [ ] **R** Responsive：replay 單 method 執行期（無 LLM call）<3s
- [ ] **R** Responsive：vision 生成期單 app ~150 API call 總時間 <10min（Claude CU）/ <5min（本地 Qwen）
- [ ] **E** Extensible：新增 VLM provider 只需加 `VLMBackend` 子類
- [ ] **E** Extensible：新增 UIA pattern 只需加 `_PATTERN_TEMPLATES` 一條
- [ ] **D** Defended：Notepad regenerate（M0）後 `open_file(path)` 真的能開檔
- [ ] **D** Defended：Discord vision generate（M1）後 `send_message("hi")` 真的能送
- [ ] **D** Defended：百度網盤 record（M2/M3）後 `upload(local_path)` 真的上傳成功
- [ ] **D** Defended：`pytest tests/ -q` 全綠（M0 新增 ~40 / M1 ~70 / M2 ~60 / M3 ~25 = +195 test）
- [ ] **O** Observable：每 generator phase `logger.info(phase, tier, method_count, avg_confidence)`
- [ ] **O** Observable：每 replay event 有 `logger.debug(event_type, control_path, duration_ms)`
- [ ] **O** Observable：vision generator 記錄每 bbox 的 `verification_score` 存 trace

---

## L. 風險彙總

| 風險 | 等級 | 緩解 |
|---|---|---|
| Qwen2.5-VL 下載 16GB / 無 GPU 跑不動 | HIGH | Claude CU 遠端 backend 為主，本地 VLM 為選配（`pip install api-anything[vision-local]`）|
| UIA AutomationEventHandler 在 Electron 覆蓋率低 | HIGH | 三層 recorder 設計（UIA + screenshot diff + 鍵鼠 hook）三者冗餘 |
| Claude CU beta header 漂移 / rate limit | MEDIUM | adapter 封裝 + 版本 pin + 每月 re-verify（寫入 RELEASE_COORDINATION `升級前 checklist`）|
| Vision bbox 在 app 版本升級後失效 | MEDIUM | method 自帶 `last_verified_at` + `verify_state_change` runtime 偵測 + `api-anything regenerate` 重跑 |
| 百度網盤反自動化（UI 混淆 / 動態元素 ID）| MEDIUM | 登入手動 + record-replay 靠用戶手動動作重錄 + 只做 upload/download/list 等穩定操作 |
| Recorder 錄到敏感資訊（密碼）| MEDIUM | 過濾 password field（UIA `IsPassword=True` 不錄 value，只錄 "<password>"）|
| Generator LLM 幻覺 method name / param | LOW | Pydantic schema 強制 + compile check + smoke instantiate（沿用 v0.2 `_validate_generated_code`）|
| 3 個彈藥都失敗 | LOW | 降級走 `cli_fallback` (v0.2) + 文件建議用戶回報 issue |

---

## M. 決策點（等用戶確認才動）

1. **M1 vision backend 默認**：本地 Qwen2.5-VL 優先 / Claude CU 遠端優先？
   - 推薦：**Claude CU 優先**（零 GPU 門檻），Qwen 當 `[vision-local]` extra
2. **M3 百度網盤優先序**：先 M2 錄製（upload/download）/ 先 M1 vision（list_files）？
   - 推薦：**M2 先**（用戶親手教一次比 VLM 穩）
3. **Record trace 儲存位置**：`.api_anything_traces/`（專案層）/ `~/.api_anything/traces/`（全域）？
   - 推薦：**專案層**（避免跨專案污染 + git-ignore 容易）
4. **VLM 本地模型**：Qwen2.5-VL-7B / ShowUI-2B（輕）/ OS-Atlas-7B（純 grounding）？
   - 推薦：**Qwen2.5-VL-7B**（生成期 brain）+ **OS-Atlas-7B**（grounding primitive）雙用
5. **v0.3.0 tag 後是否同步 push PyPI**？
   - 推薦：**不自動 push**，依 `RELEASE_COORDINATION.md` 流程用戶點頭後手動

---

## N. 時程（保守估）

| Phase | 工時 | Calendar |
|---|---|---|
| M0 prep | 2d | W1 |
| M1 Vision | 5d | W1-W2 |
| M2 Recorder | 6d | W2-W3 |
| M3 百度網盤 | 3d | W4 |
| M4 ship | 2d | W4 |
| **合計** | **18d** | **~4 週** |

前提：用戶提供 Claude API key（含 CU beta access）+ 一台 Windows 機 + 百度網盤帳號（登入手動）。

---

## RFC 結束

下一步：等用戶選定 M 決策點（M1 backend 默認 / M3 優先序 / trace 位置 / VLM 本地 / PyPI 推送）→ 開 M0 `generator.py` pattern dispatch 改造第一刀。

**參考依據**：
- `docs/v0.3_sota_notes.md`（589 行 29 WebFetch 實證 SOTA 基座）
- `feedback_api_anything_is_api_not_agent.md`（定位糾正）
- `feedback_ammo_thinking_cli_parity.md`（彈藥思考鐵律）
- v0.2 `cli_fallback.py` + `generator.py` + `tier_detect.py`（既有骨架）
