---
description: 偵測軟體的 tier（1 stdlib / 2A CLI / 2B HTTP / 3A UIA / 3B COM / 4 IPC）
argument-hint: <software-name>
allowed-tools: Bash(api-anything detect *)
---

# /api-anything:detect

對 `$ARGUMENTS` 軟體執行 tier 偵測，回報可用的控制管道。

## 執行步驟

1. 呼叫 CLI：

   ```bash
   api-anything detect "$ARGUMENTS" --json
   ```

   可選旗標：
   - `--source <path>` 指向本機源碼
   - `--github <url>` 指向 GitHub repo

2. 解讀 JSON 輸出（`detect_tier` 回傳的 `TierDetectionResult`）：
   - `tier` — 建議的 tier 編號（1 / 2A / 2B / 3A / 3B / 4）
   - `evidence` — 為什麼選這個 tier 的具體證據
   - `probe_results` — 每個管道的 probe 結果

3. 失敗處理：
   - exit code ≠ 0 → 軟體不存在或 probe 全部失敗，回報給使用者
   - JSON parse 失敗 → 改用非 JSON 模式重跑（看 Rich report）

4. 成功 → 回報建議 tier + 下一步：
   - Tier 1/2A/2B → `/api-anything:generate` 或直接 `from api_anything.apis import <Name>`
   - Tier 3A/3B/4 → 手寫較佳（自動生成品質下降）

## 不做的事

- 不修改環境（純 probing）
- 不自動生成 API（那是 `/api-anything:generate`）
