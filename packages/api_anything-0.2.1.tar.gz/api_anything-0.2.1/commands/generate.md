---
description: (v0.2 placeholder) 對模組自動生成 GenerationResult
argument-hint: <module-or-software-name>
allowed-tools: Bash(api-anything generate *)
---

# /api-anything:generate

**v0.1 placeholder** — CLI 的 `generate` 子指令在 v0.1 僅是雛形。

## 目前行為（v0.1）

1. 呼叫 CLI：

   ```bash
   api-anything generate "$ARGUMENTS" --json
   ```

2. 預期 CLI 回傳 `GenerationResult` JSON（可能包含空 / 部分欄位）。

3. 若 CLI 拋錯或回傳 empty → 回報使用者：「generate 在 v0.1 為 placeholder，目前請走：
   1. `/api-anything:detect $ARGUMENTS` — 確認 tier
   2. 參考 `src/api_anything/apis/ffmpeg.py` 或 `notepad.py` 樣板手刻
   3. 跑 `/api-anything:skill <module>` 生 SKILL.md
   4. 等 v0.2 完整 codegen」

## 未來（v0.2+）目標

完整 pipeline：

```text
detect → tier routing → codegen → Pydantic schema → pytest stub → SKILL.md
```

## 不做的事

- v0.1 不硬塞 codegen 邏輯（那是 `generator.py` 的職責）
- 不修改既有 API 檔（用 `/api-anything:refine`）
- 不自動 commit
