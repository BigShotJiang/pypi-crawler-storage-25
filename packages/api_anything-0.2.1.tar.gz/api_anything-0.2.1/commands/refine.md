---
description: (v0.2 placeholder) 對已生成 API 迭代擴充（新增方法 / 修型別 / 補 docstring）
argument-hint: <module-path>
allowed-tools: Read Grep Edit
---

# /api-anything:refine

**[v0.2 placeholder]** v0.1 CLI 未提供 `refine` 子指令。
此指令為未來保留 — 目前用**手動流程**迭代擴充 API。

## 手動流程（v0.1 暫行做法）

1. 讀現有 API 檔：

   ```text
   src/api_anything/apis/<name>.py
   ```

   Grep 找 TODO / FIXME / NotImplementedError 標記。

2. 跑一次 `/api-anything:skill` 看目前暴露的方法，與使用者目標比對缺什麼。

3. 手動 Edit 新增方法（照該檔既有 pattern）。

4. 驗證：

   ```bash
   pytest tests/test_<name>.py -v
   ```

5. tests 綠 → 完成；fail → 再迭代，3 輪後 fail → ⏸ 延遲 + 回報卡點。

## 未來（v0.2+）

CLI 應提供：

```bash
api-anything refine <module> --goal "新增 concat 方法"
```

自動產出 diff 供主代理套用。

## 不做的事

- v0.1 不呼叫 CLI（沒實作）
- 不自動 commit（使用者顯式要求才 commit）
