---
description: 對指定 API 跑 pytest，回報 pass/fail
argument-hint: <api-name>
allowed-tools: Bash(pytest *) Bash(python -m pytest *) Glob
---

# /api-anything:test

對 `api_anything.apis.<name>` 模組跑對應測試。

## 執行步驟

1. 定位測試檔（兩種常見命名）：

   - `tests/test_<api-name>.py`
   - `tests/apis/test_<api-name>.py`

   用 Glob 找：`tests/**/test_*${ARGUMENTS}*.py`

2. 跑 pytest：

   ```bash
   pytest tests/ -v -k "${ARGUMENTS}" --tb=short
   ```

   或鎖定檔：

   ```bash
   pytest tests/test_${ARGUMENTS}.py -v --tb=short
   ```

3. 解讀輸出：
   - **全綠** → 回報 pass 數
   - **有 fail** → 列出 fail 的 test name + error 首兩行
   - **collection error** → 檢查 import（通常缺外部 binary，如 ffmpeg / docker / git）

4. 若 test 檔不存在 → 回報「該 API 沒 test 檔，需 `/api-anything:refine` 或手寫」，不自動建立。

## 不做的事

- 不修 fail 的 tests（那是 `/api-anything:refine`）
- 不跑整個 repo pytest（只跑指定 API）
- 不用 CLI 跑（`api-anything` 無 test 子指令 — 直接 pytest）
