---
description: 從 Python API 模組生成 SKILL.md（讓 Claude 知道 API 介面）
argument-hint: <module-path-or-name>
allowed-tools: Bash(api-anything skill *) Read
---

# /api-anything:skill

對指定模組執行 `api-anything skill` — 產出符合 Agent Skills 格式的 SKILL.md。

## 執行步驟

1. 呼叫 CLI：

   ```bash
   api-anything skill "$ARGUMENTS"
   ```

   參數說明：
   - `$ARGUMENTS` 可以是 `.py` 檔路徑 **或** dotted module name（例如 `api_anything.apis.ffmpeg`）
   - 加 `-o <path>` 寫檔；不加則 stdout
   - 加 `--json` 輸出 generation metadata

2. 常見使用情境：

   - 內建 API：`api-anything skill api_anything.apis.ffmpeg -o skills/ffmpeg/SKILL.md`
   - 使用者自建模組：`api-anything skill ./my_api.py`

3. 輸出解讀：
   - stdout 是完整 SKILL.md（YAML frontmatter + 方法列表）
   - `--json` 給 `{generated_path, module, class, method_count}`

4. 失敗處理：
   - `ImportError` → 模組 import 失敗（缺依賴 / 路徑錯）
   - `ValueError` → 模組內沒找到 class

## 用途

讓主代理在呼叫 API 前先看到完整介面定義，避免瞎猜方法名稱。
搭配 `/api-anything:list` 先列出可用 API，再對單一 API 跑 skill。
