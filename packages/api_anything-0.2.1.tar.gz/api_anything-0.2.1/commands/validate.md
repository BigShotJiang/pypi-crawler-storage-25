---
description: 對 tier 2B (HTTP) API 用 schemathesis 做 property-based 驗證
argument-hint: <base-url-or-openapi-path>
allowed-tools: Bash(schemathesis *) Bash(pip show schemathesis)
---

# /api-anything:validate

**僅適用 tier 2B（HTTP）API**。對 OpenAPI schema 做 property-based fuzzing，檢查 response 一致性。

> 備註：`api-anything` CLI v0.1 無 validate 子指令，此指令直接驅動 schemathesis。

## 前置條件

- `pip install schemathesis`
- 目標有可存取的 OpenAPI spec（URL 或本機 `.json` / `.yaml`）
- Server 已啟動（schemathesis 對著 live endpoint 跑）

## 執行步驟

1. 確認 schemathesis 可用：

   ```bash
   pip show schemathesis
   ```

   若未安裝 → 回報「需 `pip install schemathesis`」並停止。

2. 跑驗證：

   ```bash
   schemathesis run \
     "$ARGUMENTS" \
     --checks all \
     --hypothesis-max-examples 50
   ```

   `$ARGUMENTS` 可以是：
   - OpenAPI JSON/YAML 的本機路徑
   - OpenAPI 的 URL
   - 加 `--base-url http://localhost:<port>` 指定實際 server

3. 解讀輸出：
   - **0 failures** → PASS + 測了多少 endpoint / example
   - **N failures** → 列出失敗 endpoint + counterexample

## 範圍限制

- Tier 1（stdlib）/ 2A（CLI）/ 3A（UIA）/ 3B（COM）/ 4（IPC）不適用此指令 → 改用 `/api-anything:test`
- 不啟動 server（使用者需事先啟）
