---
description: 列出 api-anything 所有內建 API（含 tier / 方法數 / 描述）
allowed-tools: Bash(api-anything list *)
---

# /api-anything:list

顯示目前所有內建 API — tier 編號、是否可用（依賴 binary 是否安裝）、方法數。

## 執行步驟

1. 簡要列表：

   ```bash
   api-anything list
   ```

   輸出 Rich table：Name / Tier 兩欄，dim 顯示不可用的 API。

2. 詳細列表（建議）：

   ```bash
   api-anything list --detail
   ```

   多出 Methods（方法數）+ Description 欄，並在表格下方印總計。

3. 目前已知內建（驗證自 `src/api_anything/apis/__init__.py`）：

   | Name              | Tier | 說明                       |
   | ----------------- | ---- | -------------------------- |
   | FFmpeg            | 2A   | 影音轉檔、剪輯、壓縮       |
   | Git               | 2A   | Git 版本控制               |
   | Docker            | 2A   | 容器管理                   |
   | SQLite            | 1    | SQL 資料庫（stdlib）       |
   | ImageMagick       | 2A   | 圖片處理                   |
   | Pandoc            | 2A   | 文件格式轉換               |
   | LibreOfficeWriter | 2A   | 文件產製                   |
   | Notepad           | 3A   | Windows Notepad（UIA）     |

   不可用狀況：Docker 無引擎 / FFmpeg 未裝 / Notepad 非 Windows 平台。

4. 下一步建議：
   - 挑一個 API → `/api-anything:skill api_anything.apis.<lowercase-name>`
   - 新軟體 → `/api-anything:detect <name>`

## 不做的事

- 不掃描使用者自建模組（CLI 無 `--path` 參數，此功能在 v0.2+）
- 不輸出 JSON（CLI v0.1 `list` 子指令無 `--json`）
