---
description: 載入指定 API 模組進入 stateful REPL（支援 session 恢復）
argument-hint: <module-path> [more-modules...]
allowed-tools: Bash(api-anything repl *)
---

# /api-anything:repl

啟動 api-anything 的 REPL — 載入一或多個 Python API 模組，保留 session 狀態跨多次呼叫。

## 執行步驟

1. 基本啟動：

   ```bash
   api-anything repl "$ARGUMENTS"
   ```

   `$ARGUMENTS` 可以是：
   - 單一模組路徑：`src/api_anything/apis/ffmpeg.py`
   - dotted name：`api_anything.apis.ffmpeg`
   - 多個模組（空白分隔）：`path1.py path2.py`

2. 旗標：
   - `--json` 以 JSON 模式啟動（每個回應是 JSON object，供程式化解析）
   - `--resume` 恢復最近一次 session（從 `~/.api_anything/sessions/` 讀）

3. REPL 內行為：
   - 自動 import 每個模組的 class 到 local namespace
   - 使用者打方法名稱即可呼叫（例：`ffmpeg.convert(...)`）
   - session 保存在 disk，下次 `--resume` 復原

4. 結束：
   - REPL 內 `exit` 或 Ctrl+D
   - Session 自動寫入 disk（可 `--resume` 恢復）

## 使用情境

- **tier 3A UIA**：`Notepad` 保留 window handle 跨多次操作
- **tier 3B COM**：Word / Excel app instance 只開一次
- **tier 4 IPC**：長連線 pipe / socket 避免重連

## 不適合

- Tier 1 / 2A 純 stateless（每次 subprocess 獨立）— 直接 `api-anything run` 更快
- 背景長跑 — 用 `/api-anything:repl` 不該 background（會殘留）

## 相關

- 一次性呼叫（不進 REPL）：`api-anything run <module> <method> [args...]`
