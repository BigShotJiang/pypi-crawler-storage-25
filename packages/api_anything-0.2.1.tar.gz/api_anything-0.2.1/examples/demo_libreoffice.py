"""Demo: Generate a report using API-Anything's LibreOffice Writer API.

Run: python examples/demo_libreoffice.py
"""

from __future__ import annotations

from pathlib import Path

from api_anything.apis import LibreOfficeWriter


def main() -> None:
    """Generate a demo report showcasing all major API features."""
    out = Path("demo_report.odt")

    writer = LibreOfficeWriter()
    writer.create_document(str(out))

    # Title
    writer.add_heading("API-Anything Demo Report", level=1)
    writer.add_paragraph(
        "This document was generated programmatically using API-Anything."
    )

    # Features section
    writer.add_heading("Features", level=2)
    writer.add_paragraph(
        "API-Anything auto-generates Python APIs from any software."
    )
    writer.add_table(
        headers=["Feature", "Status"],
        rows=[
            ["Tier Detection", "Done"],
            ["Code Generation", "Done"],
            ["Auto Testing", "Done"],
        ],
    )

    # Architecture section
    writer.add_heading("Architecture", level=2)
    writer.add_paragraph(
        "Tier 2A uses subprocess calls to headless LibreOffice "
        "combined with direct ODF XML manipulation."
    )
    writer.add_paragraph(
        "Document creation works without LibreOffice installed. "
        "Only PDF/DOCX export requires the binary."
    )

    # Page break + second page
    writer.add_page_break()
    writer.add_heading("Appendix", level=2)
    writer.add_table(
        headers=["Tier", "Description", "Example"],
        rows=[
            ["1A", "Python library", "Pillow"],
            ["2A", "Source + CLI", "LibreOffice"],
            ["3A", "GUI only", "Photoshop"],
        ],
    )

    writer.save()
    print(f"Demo report created: {out.resolve()}")

    # Show extracted text
    print(f"\n--- Extracted text ({len(writer.get_text())} chars) ---")
    print(writer.get_text()[:300])


if __name__ == "__main__":
    main()
