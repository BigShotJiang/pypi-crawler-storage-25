"""Demo: FFmpeg API usage examples.

This script demonstrates the API-Anything generated FFmpeg Python API.
It prints what each call would do. Actual execution requires ffmpeg installed.

Run:
    python examples/demo_ffmpeg.py
"""

from __future__ import annotations

from api_anything.apis import FFmpeg
from api_anything.apis.ffmpeg import FFmpegNotFoundError


def main() -> None:
    ff = FFmpeg()

    # ── Check FFmpeg availability ────────────────────────────────
    try:
        print(f"FFmpeg version: {ff.version}")
    except FFmpegNotFoundError:
        print("FFmpeg not installed — showing API interface only.\n")
        _show_api_interface()
        return

    # ── If FFmpeg is available, run actual demos ─────────────────
    print("\n=== FFmpeg API Demo ===\n")

    # Probe media info
    print("1. Probe media file:")
    print("   info = ff.probe('input.mp4')")
    print("   -> duration, width, height, codec, fps, ...\n")

    # Convert formats
    print("2. Convert video:")
    print("   ff.convert('input.mp4', 'output.webm')")
    print("   ff.convert('in.mp4', 'out.mp4', codec='libx265')\n")

    # Extract audio
    print("3. Extract audio:")
    print("   ff.extract_audio('video.mp4', 'audio.mp3')")
    print("   ff.extract_audio('video.mp4', 'audio.flac', codec='flac')\n")

    # Trim
    print("4. Trim video:")
    print("   ff.trim('in.mp4', 'clip.mp4',")
    print("           start='00:01:00', duration='00:00:30')")
    print("   ff.trim('in.mp4', 'clip.mp4',")
    print("           start='00:01:00', end='00:01:30')\n")

    # Concatenate
    print("5. Concatenate files:")
    print("   ff.concat(['p1.mp4', 'p2.mp4', 'p3.mp4'], 'full.mp4')\n")

    # Add/replace audio
    print("6. Add audio to video:")
    print("   ff.add_audio('video.mp4', 'music.mp3', 'out.mp4')\n")

    # Thumbnail
    print("7. Extract thumbnail:")
    print("   ff.thumbnail('video.mp4', 'thumb.jpg', time='00:00:05')")
    print("   ff.thumbnail('video.mp4', 'thumb.png', size='320x240')\n")

    # GIF
    print("8. Create GIF:")
    print("   ff.gif('video.mp4', 'output.gif',")
    print("          start='00:00:05', duration='3', fps=15)\n")

    # Resize
    print("9. Resize video:")
    print("   ff.resize('in.mp4', 'small.mp4', width=640, height=360)")
    print("   ff.resize('in.mp4', 'half.mp4', scale=0.5)\n")

    # Compress
    print("10. Compress video:")
    print("   ff.compress('in.mp4', 'small.mp4', crf=28)")
    print("   ff.compress('in.mp4', 'target.mp4', target_size_mb=50)\n")

    # Watermark
    print("11. Add watermark:")
    print("   ff.watermark('in.mp4', 'out.mp4', 'logo.png',")
    print("                position='bottom-right', opacity=0.3)\n")

    # Speed
    print("12. Change speed:")
    print("   ff.speed('in.mp4', 'fast.mp4', factor=2.0)  # 2x")
    print("   ff.speed('in.mp4', 'slow.mp4', factor=0.5)  # 0.5x\n")


def _show_api_interface() -> None:
    """Print the API interface without requiring ffmpeg."""
    print("=== FFmpeg API Interface (API-Anything POC #2) ===\n")

    methods = [
        ("probe(path)", "Get media info -> dict"),
        ("convert(in, out, **opts)", "Convert format"),
        ("extract_audio(in, out)", "Extract audio track"),
        ("trim(in, out, start, ...)", "Cut segment"),
        ("concat([paths], out)", "Join multiple files"),
        ("add_audio(video, audio, out)", "Add/replace audio"),
        ("thumbnail(in, out)", "Extract single frame"),
        ("gif(in, out)", "Convert to animated GIF"),
        ("resize(in, out)", "Resize by w/h or scale"),
        ("compress(in, out)", "Compress with CRF or target size"),
        ("watermark(in, out, img)", "Add image watermark"),
        ("speed(in, out, factor)", "Change playback speed"),
        ("version", "Get FFmpeg version string"),
    ]

    for name, desc in methods:
        print(f"  ff.{name:<30s}  # {desc}")

    print("\nInstall FFmpeg to run actual operations:")
    print("  - macOS:   brew install ffmpeg")
    print("  - Ubuntu:  sudo apt install ffmpeg")
    print("  - Windows: winget install ffmpeg")


if __name__ == "__main__":
    main()
