"""Demo: Control Windows Notepad via UIA — no source code needed.

This demonstrates API-Anything's unique capability that CLI-Anything cannot do.
Run: python examples/demo_notepad.py (Windows only, opens real Notepad)

What happens:
1. Launches Notepad
2. Types a greeting message
3. Appends more text
4. Reads back the text
5. Saves to a temp file
6. Shows line count and modification status
7. Closes Notepad cleanly

No source code. No CLI. Pure UI Automation.
"""

from __future__ import annotations

import os
import sys
import tempfile


def main() -> None:
    """Run the Notepad UIA demo."""
    if sys.platform != "win32":
        print("This demo requires Windows. Skipping.")
        return

    # Import here so the module-level ctypes don't fail on non-Windows
    from api_anything.apis import Notepad as NotepadAPI

    print("=" * 60)
    print("API-Anything: Notepad UIA Demo")
    print("Tier 3A — No source code, no CLI, pure UIA control")
    print("=" * 60)
    print()

    # 1. Launch
    print("[1] Launching Notepad...")
    notepad = NotepadAPI()
    notepad.launch()
    print(f"    Window title: {notepad.title}")
    print()

    # 2. Set text
    print("[2] Setting text content...")
    notepad.set_text(
        "Hello from API-Anything!\r\n"
        "\r\n"
        "This text was typed by a Python API.\r\n"
        "No source code. No CLI. Pure UIA automation.\r\n"
    )
    print("    Text set successfully.")
    print()

    # 3. Append
    print("[3] Appending more text...")
    notepad.append_text(
        "\r\n--- Appended Section ---\r\n"
        "Line 6: API-Anything can control ANY Windows app.\r\n"
        "Line 7: CLI-Anything cannot do this.\r\n"
    )
    print("    Text appended.")
    print()

    # 4. Read back
    print("[4] Reading text back...")
    content = notepad.get_text()
    line_count = notepad.get_line_count()
    print(f"    Lines: {line_count}")
    print(f"    Characters: {len(content)}")
    print(f"    Modified: {notepad.is_modified}")
    print()

    # 5. Find
    print("[5] Searching for text...")
    found = notepad.find("API-Anything")
    print(f"    'API-Anything' found: {found}")
    not_found = notepad.find("CLI-Only-Tool")
    print(f"    'CLI-Only-Tool' found: {not_found}")
    print()

    # 6. Find & Replace
    print("[6] Find and replace...")
    notepad.find_replace("Pure UIA automation", "Pure UIA accessibility tree control")
    print("    Replaced 'Pure UIA automation' -> 'Pure UIA accessibility tree control'")
    print()

    # 7. Save to temp file
    print("[7] Saving to temp file...")
    tmp_path = os.path.join(tempfile.gettempdir(), "api_anything_demo.txt")
    notepad.save_as(tmp_path)
    print(f"    Saved to: {tmp_path}")
    print()

    # 8. Verify saved file
    print("[8] Verifying saved file...")
    if os.path.exists(tmp_path):
        with open(tmp_path, encoding="utf-8", errors="replace") as f:
            saved_content = f.read()
        print(f"    File size: {len(saved_content)} chars")
        print(f"    First line: {saved_content.splitlines()[0]!r}")
    else:
        print("    WARNING: File not found (Save As dialog may need manual confirm)")
    print()

    # 9. Close
    print("[9] Closing Notepad...")
    notepad.close(save=False)
    print("    Closed.")
    print()

    # Cleanup
    if os.path.exists(tmp_path):
        os.remove(tmp_path)
        print(f"    Cleaned up temp file: {tmp_path}")

    print()
    print("=" * 60)
    print("Demo complete. API-Anything controlled Notepad with ZERO")
    print("source code access — something CLI-Anything cannot do.")
    print("=" * 60)


if __name__ == "__main__":
    main()
