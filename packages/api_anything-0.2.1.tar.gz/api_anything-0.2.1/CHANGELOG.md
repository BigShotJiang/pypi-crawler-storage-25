# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-04-17

### Added
- **CLI fallback support** — when UIA methods fail (Electron / blocked / timeout), decorated methods fall back to `cli_anything` invocation. Adds `src/api_anything/cli_fallback.py`, extends `generator.py` with fallback decorator (+170 LOC total), wires Notepad example decorators. (Commit `c33db45` — v0.2 A)
- **Tier detection extensions** — Electron fingerprinting (executable name blacklist / `.asar` probe / CEF dll probe), install-path detection (Windows `LOCALAPPDATA` scan / Unix `shutil.which`), enrichment fields on `TierResult`: `host_os`, `electron_suspected`, `runtime_probed`, `fallback_hint` (+329 LOC `tier_detect.py`). (Commit `849ef27` — v0.2 B)
- **DisplayRouter** — unified output dispatch across `cli` / `json` / `repl` / `web` channels with type-dispatch for `TierResult`, `CheckResult`, `APIClass`, `APIMethod`, `GenerationResult` (+582 LOC `display_router.py`). (Commit `69fc05e` — v0.2 C)
- **LLM-driven generate pipeline** — three-gate validation (syntax AST parse / structure check / safety blacklist), fallback-to-schema on validation failure, triggered by explicit flag / Tier ≥3A / confidence < 60 (+390 LOC `llm_generator.py`). (Commit `69fc05e` — v0.2 D)
- `GenerationResult.generation_mode` field plus validation metadata (`validation_passed`, `validation_errors`, `llm_confidence`). (v0.2 D)
- **Hero demo v2** — split-screen Notepad automation GIF replaces the Gradio UI tour as the top-of-README hero asset. (v0.2 A)

### Changed
- `cli._cmd_generate` now routes output through `DisplayRouter` instead of direct `rich.print` calls.
- `web._format_tier_report` now routes output through `DisplayRouter` for channel-consistent rendering.

### Deferred to v0.2.1
- `cli_fallback` YAML schemas for `audacity` / `kdenlive` / `krita` (Notepad-only shipped in v0.2.0).
- `repl.py` migration to `DisplayRouter` (CLI + web migrated; REPL pending).
- LLM vision bytes input (`vision_image: bytes | None`) — structural hook present, wiring deferred.

## [0.1.0] - 2026-04-15

### Added
- Initial public release. Auto-generate Python APIs from any software via UIA inspection + LLM-driven method synthesis.
- Tier detection (native UIA / WinRT / Electron / Web / CLI-only).
- Gradio web UI, REPL, CLI frontends.
- Notepad example end-to-end working.

[0.2.0]: https://github.com/aiking931931/api-anything/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/aiking931931/api-anything/releases/tag/v0.1.0
