# RFC v0.2 — API-Anything

**狀態**：草案（2026-04-17）
**作者**：AI King
**基準版本**：v0.1.0（244 tests / 27 APIs / 295 methods）
**目標版本**：v0.2.0

---

## 1. Scope & Goals

### 總體目標

v0.2 把 v0.1「可偵測、可展示」推進到「可真實生成」。四個子項各自獨立可交付，但有 DAG 依賴關係。

| 目標 | 衡量標準 |
|------|---------|
| Fallback P2/P3 落地（方案 C Hybrid） | Tier 3B/3C/4 不 hard-fail，degraded 可用 |
| tier_detect 擴展到更多 exe | 新增 ≥10 種 exe 被正確分 tier（含 Electron/CEF） |
| display_router.py 統一輸出通道 | CLI / REPL / Web / JSON 四通道共用一個路由層 |
| LLM-driven generate 實作 | `api-anything generate <sw>` 真實生成可用 .py，非 stub |

### 非目標（明確剔除）

- 推廣、Hero GIF、社群活動（由用戶主導）
- README badge 更新（repo 現 private，shields 會壞）
- Linux AT-SPI / macOS AXUIElement（v0.3）
- Phase 4-7 pipeline 完整實作（Schemathesis 整合 = v0.3）
- PyPI publish（發布節奏由用戶決定）
- 本地視覺模型（Gelato/OmniParser — KILL，沿用 Claude API vision）

---

## 2. 子項拆解

### 子項 A：Fallback P2/P3（generator 整合）

**問題**：`cli_fallback.py` 骨架已存在（RFC 0.1 P1 完成），但：
1. `generator.py:_render_method` 生成的 UIA method stub 只有 `raise NotImplementedError`，完全沒有 fallback 路徑
2. `generator.py:generate_api` 沒有 tier/confidence 閾值觸發 fallback 的決策點
3. 27 個內建 API 中 Notepad（3A）、Audacity（3B）、Kdenlive（3B）、Krita（3B）應加 `@with_cli_fallback` decorator，目前無

**設計**：

```
Tier 閾值決策 (generator.generate_api)
  confidence < 70  →  fallback_enabled = True
  tier in {3B, 3C, 4}  →  fallback_enabled = True（覆寫 confidence）
  tier in {1, 2A}  →  fallback_enabled = False（永不加 decorator）

_render_method 新分支：
  operation_mode == "uia" AND fallback_enabled
    → 生成的 method body = try UIA → except → _cli_fallback_invoke

內建 API 加 decorator：
  @with_cli_fallback("cli-anything-notepad", subcmd="set_text")
```

**API surface 變動**：
- `generator.py:generate_api(...)` 新增 `fallback_enabled: bool = False` 參數
- `generator.py:_render_method(...)` 新增 `fallback_enabled: bool` 參數
- `generator.py:_build_prompt(...)` 新增 fallback hint section（+15 LOC）

**實作步驟（DAG）**：

```
A1. 改 _render_method → 生成 try/except fallback 分支      depends: []
A2. 改 _build_prompt → 加 fallback hint section            depends: []
A3. 改 generate_api → tier 閾值決策 + fallback_enabled 傳遞 depends: [A1, A2]
A4. 改 notepad.py → 加 @with_cli_fallback decorator       depends: [A3]
A5. 改 audacity/kdenlive/krita → 同 A4                    depends: [A3]
A6. integration test: Tier 3B soft-fail → fallback triggered depends: [A4, A5]
```

**測試計畫**：
- `test_generator.py`：mock `client` 為 None → 驗 Tier 3B 生成的 code 含 fallback pattern
- `test_cli_fallback.py`：擴充現有（mock `shutil.which` → is_available true/false）
- integration：notepad generate → render → grep `with_cli_fallback`

**預估 LOC**：generator 改動 +70、per-API decorator ~5×4 = +20、測試 +80 → 總 +170

**CP**：likelihood 0.85（邏輯直接，建在現有 cli_fallback.py 上）× ease 0.80（LOC 少，不涉新依賴）= **0.68 HIGH**

**風險**：low — cli_fallback.py 已存在，只做 generator 端接線

---

### 子項 B：tier_detect 擴展

**問題**：現有 `_determine_tier` 只有四個 check（PyPI / source / CLI / UIA）。缺陷：
1. Electron/CEF/WebView2 app 靠同名 PyPI 誤判 Tier 1（`runtime_probe` 可修正但 default=False）
2. 無 OS 偵測：同一 exe 在 Linux/macOS 行為不同（runtime_probe 只跑 Windows UIA）
3. CLI alias 偵測弱：ffprobe/ffmpeg 只查確切名字，`ffmpeg.exe` 等 Windows 副檔名已處理但 `ffmpeg-win64` 等變體沒有
4. `_resolve_exe_path` 只查 3 個 Windows 路徑，漏 `%LOCALAPPDATA%\Programs`、Scoop、Chocolatey prefix

**設計**：

新增 heuristic 層（不改 `_determine_tier` 介面，改在 `detect_tier` wrapper 加前處理）：

```python
def _enrich_checks(software_name, checks, tier) -> tuple[dict, Tier]:
    """Post-process: detect Electron/CEF, OS platform, exe aliases."""
    # 1. Electron fingerprint: pypi passed but cli not found + no source
    #    → downgrade to soft-T1, suggest runtime_probe
    # 2. CLI alias expansion: try software + .exe + software-<arch>
    # 3. LOCALAPPDATA/Scoop/Choco path scan
    # 4. OS guard: UIA checks flagged as 'skipped' on Linux/macOS
```

新增 `cli_alias_candidates(name: str) -> list[str]`：
- `name`, `name.exe`, `name-win64`, `name-win32`, 常見變體
- 沿用 `shutil.which` 每個候選查一次（單次 <1ms）

新增 `detect_install_path(name: str) -> str | None`：
- 擴充 `_resolve_exe_path`，加 `%LOCALAPPDATA%\Programs`、`C:\tools`（Choco）、`%USERPROFILE%\scoop\shims`

**API surface 變動**（全為新增，不破壞現有介面）：
- `tier_detect.cli_alias_candidates(name: str) -> list[str]`（新增 public）
- `tier_detect.detect_install_path(name: str) -> str | None`（新增 public）
- `TierResult.install_path: str | None`（新增 optional field）
- `TierResult.electron_suspected: bool`（新增 flag）

**實作步驟（DAG）**：

```
B1. 新增 cli_alias_candidates + detect_install_path          depends: []
B2. 改 _resolve_exe_path → 統一呼叫 detect_install_path     depends: [B1]
B3. 改 TierResult 加 install_path / electron_suspected       depends: []
B4. 新增 _enrich_checks → Electron 偵測 + OS 警告            depends: [B1, B3]
B5. 改 detect_tier → 呼叫 _enrich_checks                    depends: [B2, B4]
B6. 測試：10 個新 exe（vscode / slack / discord / obs 等）   depends: [B5]
```

**測試計畫**：
- `test_tier_detect.py`：mock `shutil.which`，驗 alias 展開邏輯
- `test_tier_detect.py`：mock `winreg`，驗 LOCALAPPDATA 路徑掃描
- Electron 指紋：mock PyPI OK + CLI not found + no source → electron_suspected=True

**預估 LOC**：+120 新增 heuristic、+40 TierResult 欄位+tests、test +80 → 總 +240

**CP**：likelihood 0.75（多路徑偵測，mock 難窮舉）× ease 0.60（需實測多種 exe）= **0.45 MEDIUM**

**風險**：medium — 每個 exe 的安裝路徑都不同，測試覆蓋不易窮舉；Electron 偵測規則可能誤判

---

### 子項 C：display_router.py 落地

**問題**：目前輸出邏輯分散在三處：
- `cli.py`：每個 handler 自己決定要 Rich console 或 json.dumps
- `web.py`：Gradio 格式化函數（Markdown string 返回）
- `repl.py`：`format_result()` 獨立邏輯

三者邏輯重複，未來新增輸出通道（例如 tool_use schema）需改三處。

**設計**：

```python
# src/api_anything/display_router.py
class OutputChannel(str, Enum):
    CLI_RICH = "cli_rich"    # Rich Console panel
    REPL = "repl"            # 精簡 text，REPL 友善
    WEB = "web"              # Markdown string（Gradio 用）
    JSON = "json"            # json.dumps

class DisplayRouter:
    def __init__(self, channel: OutputChannel, console: Console | None = None): ...
    def render(self, payload: Any, *, title: str = "", error: bool = False) -> str | None:
        """Route payload to correct formatter. JSON/WEB returns str; CLI_RICH/REPL prints and returns None."""
    def render_tier_result(self, result: TierResult) -> str | None: ...
    def render_generation_result(self, result: GenerationResult) -> str | None: ...
    def render_error(self, exc: Exception, context: str = "") -> str | None: ...
```

重構路徑：
- `cli.py` handler 改為 `router = DisplayRouter(channel=CLI_RICH if not args.json_output else JSON)`
- `web.py:_format_tier_report` 改為 `DisplayRouter(channel=WEB).render_tier_result(...)`
- `repl.py:format_result` 改為 `DisplayRouter(channel=REPL).render(...)`

**API surface 變動**：
- 新增 `src/api_anything/display_router.py`（全新模組）
- `cli.py` handler：接線到 router（內部改動，不改 CLI interface）
- `web.py`：改呼叫 router（Gradio API 不變）
- `repl.py:format_result`：內部改呼叫 router

**實作步驟（DAG）**：

```
C1. 新增 display_router.py：OutputChannel + DisplayRouter 骨架  depends: []
C2. 實作 render_tier_result（從 web.py _format_tier_report 提取）depends: [C1]
C3. 實作 render_generation_result                              depends: [C1]
C4. 實作 render_error                                          depends: [C1]
C5. 改 cli.py → 所有 handler 接線到 router                    depends: [C2, C3, C4]
C6. 改 web.py → _format_tier_report 等改呼叫 router           depends: [C2]
C7. 改 repl.py → format_result 接線                           depends: [C3]
C8. 測試：CLI_RICH / JSON / WEB / REPL 四通道輸出一致性        depends: [C5, C6, C7]
```

**測試計畫**：
- `test_display_router.py`：同一 TierResult 四通道都跑，JSON 通道驗 json.loads，WEB 通道驗 Markdown 格式
- regression：`cli.py` detect json output 格式不變（避免 breaking change）

**預估 LOC**：新模組 +200、cli/web/repl 改動 -80（刪重複）+ 接線 +30、測試 +80 → 淨增 +230（但可清理 -80 舊代碼）

**CP**：likelihood 0.70（純重構，邏輯不變）× ease 0.65（需改三個檔，但無新依賴）= **0.46 MEDIUM**

**風險**：medium — 重構涉及三個主要檔案，regression risk；web.py Gradio 格式字串細節可能漏

---

### 子項 D：LLM-driven generate 實作

**問題**：`_cmd_generate` 是 stub，只 return `{"status": "not_implemented"}`。`_instructor_generate` 已有但只接 OpenAI-compatible client，且：
1. 沒有觸發條件：何時用 LLM-driven vs template-based？
2. prompt 沒有 tier-aware 上下文（generator.py `_build_prompt` 沒有 tier 3 截圖 vision 路徑）
3. 生成後無驗證關卡（生成的 code 可能含語法錯誤）
4. `web.py` Generate tab 的 Button 是 `interactive=False`（hardcode 不可點）

**設計**：

觸發條件（三層優先序）：

```
if client is None:
    → template-based (_mock_generate)，適合 CI / offline 環境

elif tier in {1, 2A} and source_text:
    → LLM-driven source-only（_instructor_generate，不含截圖）

else:  # tier 3+，or 無 source
    → LLM-driven with vision（_instructor_generate + screenshot base64 注入）
```

prompt 改進（tier-aware）：
- Tier 1：「已有 PyPI binding，只需 thin wrapper，重點寫 ergonomic alias」
- Tier 2A/2B：「有原始碼，萃取 API surface，隱藏 subprocess 細節」
- Tier 3+：「無原始碼，根據截圖 + UIA tree 推測使用者意圖，防禦性設計」

驗證關卡（post-generation）：

```python
def _validate_generated_code(source_code: str) -> ValidationResult:
    """三關：syntax check / import scan / smoke instantiate."""
    # Gate 1: compile() → SyntaxError
    # Gate 2: 掃危險 import（沿用 _DANGEROUS_PATTERNS）
    # Gate 3: exec in sandbox → 類別可 instantiate（__init__ 不 throw）
```

**API surface 變動**：
- `generator.py:generate_api(...)` 新增 `vision_image: bytes | None = None`（base64 給 LLM）
- `generator.py:_build_prompt(...)` 新增 tier-aware section
- `generator.py:_validate_generated_code(source_code: str) -> ValidationResult`（新增）
- `models.py:GenerationResult` 新增 `validation: ValidationResult | None`
- `cli.py:_cmd_generate` 從 stub 改為真實呼叫（接線 detect_tier → analyze → generate_api）
- `web.py:_build_tab_generate` Button 改 `interactive=True`，加 generate 回調

**實作步驟（DAG）**：

```
D1. 改 _build_prompt → tier-aware section                        depends: []
D2. 改 generate_api → vision 參數 + 觸發條件三層優先序            depends: [D1]
D3. 新增 _validate_generated_code → 三關驗證                     depends: []
D4. 改 GenerationResult model → 加 validation field             depends: [D3]
D5. 改 _cmd_generate → 真實 pipeline（detect→analyze→generate）  depends: [D2, D4]
D6. 改 web.py Generate tab → 啟用 Button + 加回調               depends: [D2, D4]
D7. 測試：generate notepad → 驗輸出含 class + 可 compile          depends: [D5]
D8. 測試：generate ffmpeg source-only → 驗 LLM path 被選          depends: [D2]
```

**測試計畫**：
- `test_generator.py`：mock client → tier 3B → 驗 vision 路徑被觸發
- `test_generator.py`：mock compile → SyntaxError → 驗 validation.passed=False
- `test_cli_generate.py`：end-to-end mock（mock detect_tier → mock generate_api）

**預估 LOC**：generator 改動 +100、validation +60、cli/web 接線 +50、測試 +100 → 總 +310

**CP**：likelihood 0.60（LLM 輸出不確定性 + 驗證關卡需設計）× ease 0.55（跨多個模組，需 mock LLM）= **0.33 MEDIUM-LOW**

**風險**：HIGH — LLM output 不穩定（Instructor schema 可能 fail），需 max_retries + fallback to mock；OpenAI client 非必裝依賴（`[llm]` extra）

---

## 3. 實作順序（推薦 DAG）

```
        [子項 A: Fallback P2/P3]   ← CP 最高，建在已有骨架上
              |
              ↓
        [子項 B: tier_detect 擴展]  ← A 完後 tier 資訊更準，讓 C/D 受益
              |
    ┌─────────┴─────────┐
    ↓                   ↓
[子項 C: display_router]  [子項 D: LLM generate]
  (可並行，無交叉依賴)
```

**為什麼這個順序**：

| 順序 | 子項 | 理由 |
|------|------|------|
| 1st | A | CP=0.68 最高；cli_fallback.py 骨架已存在，只做 generator 接線；沒有新外部依賴；讓 Tier 3B/3C/4 不再 hard-fail，立即提升產品完成度 |
| 2nd | B | tier_detect 準確性影響 A 的 fallback 觸發精度，也影響 D 的 vision 路徑選擇；中等 CP 但是 C/D 的上游資訊品質；純偵測邏輯不影響其他模組 |
| 3rd | C | 重構型工作，不增加功能，但讓後續 D 的 web tab 接線更乾淨；可並行於 D；LOC 淨增不大（清舊代碼 -80） |
| 3rd | D | 依賴 A（fallback path）、B（tier 準確）、C（display）；CP 最低，LLM 整合複雜；若時間壓縮可先只做 cli 端，web tab 延後 |

---

## 4. 版本號 + 發布條件

**v0.2.0 ship-ready 標準**：

| 維度 | 要求 |
|------|------|
| Tests | ≥310 passed（現 244 + 新 A~D 估 +80，預留彈性） |
| APIs | ≥27（不要求增加，保持現有 27 品質） |
| Fallback | Tier 3B 產出 class 含 fallback decorator，不 raise NotImplementedError |
| Generate | `api-anything generate ffmpeg` 能產出含 class 定義的 .py，不是 stub |
| display_router | `api-anything detect notepad --json` 輸出格式不 breaking |
| WIREDO | W: cli/web/repl 三路通過 display_router；D: CLI + generate + fallback 各有 smoke test |

**示範場景（v0.2 Demo 三段）**：

```bash
# 場景 1：Fallback 不再 hard-fail
api-anything generate krita
# → 輸出含 @with_cli_fallback 的 class（Tier 3B degraded-but-usable）

# 場景 2：tier_detect 更準
api-anything detect discord --probe
# → 正確識別 Electron shell → electron_suspected=True → Tier 4

# 場景 3：LLM-driven generate 真實輸出
api-anything generate ffmpeg --source /path/to/ffmpeg-src
# → 生成 FFmpegAPI class（LLM-driven，非 mock）
```

---

## 5. 對照 v0.1 的變動表

### 新增模組

| 模組 | 路徑 | 來源 |
|------|------|------|
| `display_router.py` | `src/api_anything/display_router.py` | 全新（子項 C） |

注：`cli_fallback.py` 已在 v0.1 後段建立（P1 完成），v0.2 做 generator 端接線

### 修改模組

| 模組 | 改動 | Breaking？ |
|------|------|-----------|
| `generator.py` | `generate_api` 加 `fallback_enabled`/`vision_image`；`_render_method` 加 fallback 分支；新增 `_validate_generated_code`；`_build_prompt` tier-aware | 否（新增參數有 default） |
| `tier_detect.py` | 新增 `cli_alias_candidates`、`detect_install_path`、`_enrich_checks`；`TierResult` 新增 `install_path`/`electron_suspected` | 否（新增 field 有 default） |
| `cli.py` | `_cmd_generate` 從 stub 改真實實作；handler 接線 display_router | 否（CLI interface 不變） |
| `web.py` | Generate tab Button 啟用；`_format_tier_report` 接線 display_router | 否（Gradio API 不變） |
| `repl.py` | `format_result` 接線 display_router | 否（REPL 行為不變） |
| `models.py` | `GenerationResult` 加 `validation` field | 否（Optional field） |
| `apis/notepad.py` | 加 `@with_cli_fallback` decorator | 否 |
| `apis/audacity.py` `apis/kdenlive.py` `apis/krita.py` | 加 `@with_cli_fallback` decorator | 否 |

### Breaking Changes

**無 breaking change**。所有新增參數皆有預設值，新增 model field 皆為 Optional。`--json` 輸出格式新增 field 但不移除，向下相容。

---

## 風險彙總

| 風險 | 子項 | 等級 | 緩解 |
|------|------|------|------|
| Instructor schema retry 耗時 / fail | D | HIGH | `max_retries=2` + fallback to `_mock_generate`；LLM 依賴放 `[llm]` extra |
| Electron 偵測規則誤判（太激進） | B | MEDIUM | `electron_suspected` 只是 flag，不強制改 tier；`runtime_probe=True` 才修正 tier |
| display_router 重構漏 edge case | C | MEDIUM | 保留舊格式函數作 shim，新版並行跑 regression；`--json` 輸出 golden file 測試 |
| cli_fallback 上游 schema 漂移 | A | MEDIUM | subcmd 映射表集中在 `cli_fallback_schemas/` YAML；CI fallback-compat 測試 |
| vision 截圖 path 在 CI 無效 | D | LOW | `screenshot_path` 可 None，vision 路徑 skip；generator 有 mock 路徑 |
| `_validate_generated_code` sandbox exec 安全 | D | LOW | exec 限制 globals = `{}`，沿用 `_DANGEROUS_PATTERNS` 掃描；僅 CI 環境跑 |

---

## Exit Criteria（WIREDO）

- [ ] **W** Wired：display_router 被 cli/web/repl 三路 import 並呼叫（grep 確認無孤島）
- [ ] **W** Wired：`@with_cli_fallback` decorator 在 notepad/audacity/kdenlive/krita 被呼叫，非死代碼
- [ ] **I** Inherited：新模組遵循現有 `from __future__ import annotations` + Pydantic model 慣例
- [ ] **I** Inherited：display_router OutputChannel 命名與 cli.py 的 `--json` flag 對齊
- [ ] **R** Responsive：`api-anything detect` Rich 輸出 <500ms（tier_detect heuristic 不加同步 IO）
- [ ] **R** Responsive：`api-anything generate` 無 client 時（mock mode）<1s 回傳
- [ ] **E** Extensible：display_router 新增通道只需加 `OutputChannel` enum + `render` 一個 dispatch case
- [ ] **E** Extensible：tier_detect heuristic 集中在 `_enrich_checks`，不散落各處
- [ ] **D** Defended：`pytest tests/ -q` ≥310 passed；fallback / display_router / generate 各有 smoke test
- [ ] **D** Defended：`_validate_generated_code` Gate 1 syntax check 攔截 LLM 生成的語法錯誤
- [ ] **O** Observable：每次 fallback 觸發皆 `logger.info("fallback: primary=%s → cli=%s")`
- [ ] **O** Observable：`GenerationResult.validation` 可讀出三關結果（syntax/danger/smoke）
