# api-anything RELEASE_COORDINATION

> 所有升級此專案的 session/agent 先讀此文件。遵循 `~/.claude/rules/L1/release_coord.md`。

## 現況 snapshot（2026-04-17）

| 欄位 | 值 |
|---|---|
| Registry latest（PyPI） | 尚未 publish（v0.1.0 曾計劃公開，目前 repo private，PyPI 無 record） |
| Local version（pyproject.toml） | `0.2.0` |
| CHANGELOG 最新 | `[0.2.0] - 2026-04-17` |
| master HEAD | `69fc05e` `v0.2-CD: display_router + LLM-driven generate`（本 housekeeping commit 之前） |
| 下一 publish 目標 | `0.2.0`（未鎖定時間，等用戶指令） |
| Repo 可見性 | **private**（`aiking931931/api-anything`）— README badge 先不改 |

## WIP 變更清單

- v0.2.0 四子功能（A/B/C/D）全部已 land 在 master，但整合層收尾尚未完成：
  - `repl.py` 尚未遷移到 `DisplayRouter`（cli + web 已遷）
  - `cli_fallback` 只有 notepad schema，audacity/kdenlive/krita 待補
  - LLM vision bytes input 結構 hook 已留，wiring 待補
- 以上三項已列入 CHANGELOG `Deferred to v0.2.1`。

## ⛔ 鐵律（api-anything 專屬）

1. **Repo private 期間禁動 README badge URL** — shields.io 對 private repo 會回 404，動了等於故意壞 demo
2. **不改 dependencies 在 minor bump 內** — 0.1.x → 0.2.0 是 feature release，deps 維持與 0.1.0 相同
3. **v0.2 新模組（display_router / cli_fallback / llm_generator）視為公開 API** — 下次改 signature 必須 deprecate → 0.3 才能刪除
4. **Tier detection enrichment fields 一旦加入 `TierResult` 就不可移除** — consumer 可能已 assert 這些欄位存在
5. **hero GIF 路徑在 README hardcode** — 替換時同步更新 `README.md` + `assets/` 指針，不留 broken link
6. **發布 PyPI 前必須先把 repo 轉 public** — 否則 Homepage/Repository URL 在 PyPI 頁面會死連結
7. **本地 lint + test 全綠才能進 release checklist** — 未跑 = 未驗

## 升級前 checklist

- [ ] `pytest tests/` 全綠
- [ ] `ruff check src/ tests/` 零 warning
- [ ] CHANGELOG 目標版本 entry 存在且內容完整
- [ ] `pyproject.toml` version 對齊 CHANGELOG
- [ ] PyPI 該版號未被佔用（`pip index versions api-anything` 確認）
- [ ] Repo 已從 private 轉 public（如要 publish）
- [ ] Lock 已取（填 Session Registry / Active）
- [ ] `python -m build` 本地 build 成功
- [ ] `twine check dist/*` 全綠
- [ ] README badge URL 對得到公開 repo

## 升級步驟

1. 決定目標版本（semver）— minor=feature / patch=fix / major=break
2. 更新 `pyproject.toml` version + `CHANGELOG.md` 新 entry
3. `python -m build` 產生 sdist + wheel
4. `twine check dist/*`
5. Tag：`git tag -a vX.Y.Z -m "..."` + `git push --tags`（⛔ 不可逆點）
6. `twine upload dist/*`（⛔ 不可逆點）
7. `pip install api-anything==X.Y.Z` 在乾淨 venv 驗證
8. 更新 Session Registry / History

## Session Registry

### Active
無

### History
- 2026-04-17 / housekeeping session / target `0.2.0` / **housekeeping only**（bump + CHANGELOG + 本文件）/ 未 tag / 未 push / 未 publish

## 不可逆點

| 操作 | 為何不可逆 |
|---|---|
| `twine upload dist/*`（PyPI） | 撤不回。只能 yank，yank 後仍可 `pip install api-anything==版本` 裝到。版號被佔永遠 |
| `git push origin vX.Y.Z` tag | 本地可刪，但 clone 過的人保有。GitHub release 頁面留 trace |
| Repo 從 private 轉 public | 歷史 commit 全部公開。任何 private 時期殘留的 secret / 未發表 idea 一併曝光 |
| `gh release create` | 下載計數、討論串留 trace；刪 release 會留空紀錄 |
| README badge 改 public shields URL 後再把 repo 轉回 private | badge 404 公開可見，等於 NAK 給觀眾看 |

**Full 模式不豁免** 上述不可逆點 — 執行前必須 AskUser 確認。
