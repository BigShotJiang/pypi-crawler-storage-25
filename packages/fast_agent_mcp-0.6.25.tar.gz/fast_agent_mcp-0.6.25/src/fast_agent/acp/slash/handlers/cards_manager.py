"""Card pack slash command handlers."""

from __future__ import annotations

from typing import TYPE_CHECKING, cast

from fast_agent.commands.command_discovery import render_direct_command_help
from fast_agent.commands.handlers import cards_manager as cards_handlers

if TYPE_CHECKING:
    from fast_agent.acp.command_io import ACPCommandIO
    from fast_agent.acp.slash_commands import SlashCommandHandler


async def handle_cards(handler: "SlashCommandHandler", arguments: str | None = None) -> str:
    direct_help = render_direct_command_help("cards", arguments)
    if direct_help is not None:
        return direct_help

    tokens = (arguments or "").strip().split(maxsplit=1)
    action = tokens[0].lower() if tokens else "list"
    remainder = tokens[1] if len(tokens) > 1 else ""

    ctx = handler._build_command_context()
    io = cast("ACPCommandIO", ctx.io)
    try:
        outcome = await cards_handlers.handle_cards_command(
            ctx,
            agent_name=handler.current_agent_name,
            action=action,
            argument=remainder or None,
        )
    except Exception as exc:  # noqa: BLE001
        return f"# cards\n\nFailed to execute /cards: {exc}"

    heading = "cards" if action in {"", "list"} else f"cards {action}"
    return handler._format_outcome_as_markdown(outcome, heading, io=io)
