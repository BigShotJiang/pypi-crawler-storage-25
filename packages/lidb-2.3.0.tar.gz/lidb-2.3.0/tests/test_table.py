# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for table.py

import pytest
import polars as pl
from pathlib import Path

from lidb.table import Table, TableMode


class TestTableMode:
    """测试 TableMode 枚举"""

    def test_table_mode_full(self):
        """TableMode.F 表示全量更新"""
        assert TableMode.F.value == "full"
        assert TableMode.F.name == "F"

    def test_table_mode_increment(self):
        """TableMode.I 表示增量更新"""
        assert TableMode.I.value == "increment"
        assert TableMode.I.name == "I"

    def test_table_mode_values(self):
        """TableMode 只有两个值"""
        assert len(TableMode) == 2


class TestTable:
    """测试 Table 类"""

    def test_table_creation(self):
        """Table 可以被创建"""
        def sample_fn(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "value": [1]})

        table = Table(
            fn=sample_fn,
            tb="test/table",
            update_time="09:30"
        )

        assert table.tb == "test/table"
        assert table.update_time == "09:30"
        assert callable(table.fn)
        assert table.mode == TableMode.F  # 默认全量模式
        assert table.logger is not None  # logger 正确创建

    def test_table_default_mode(self):
        """Table 默认模式是全量更新"""
        def sample_fn(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        table = Table(
            fn=sample_fn,
            tb="test/table",
            update_time=""
        )

        assert table.mode == TableMode.F

    def test_table_increment_mode(self):
        """Table 支持增量模式"""
        def sample_fn(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        table = Table(
            fn=sample_fn,
            tb="test/table",
            update_time="",
            mode=TableMode.I
        )

        assert table.mode == TableMode.I

    def test_table_call_returns_new_table(self):
        """Table 调用返回新的 Table 实例"""
        def sample_fn(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        original = Table(
            fn=sample_fn,
            tb="test/table",
            update_time="09:30",
            mode=TableMode.I
        )

        called = original(date="2024-01-01")

        assert isinstance(called, Table)
        assert called.tb == "test/table"
        assert called.update_time == "09:30"  # 属性正确传递
        assert called.mode == TableMode.I  # 模式正确传递

    def test_table_verbose_defaults_false(self):
        """Table.verbose 默认值为 False"""
        def sample_fn(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        table = Table(
            fn=sample_fn,
            tb="test/table",
            update_time=""
        )

        assert table.verbose is False

    def test_table_data_dir(self):
        """Table._data_dir 正确指向数据目录"""
        def sample_fn(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        table = Table(
            fn=sample_fn,
            tb="my/table/path",
            update_time=""
        )

        from lidb.database import tb_path
        assert isinstance(table._data_dir, Path)
        assert table._data_dir == tb_path("my/table/path")  # 精确匹配