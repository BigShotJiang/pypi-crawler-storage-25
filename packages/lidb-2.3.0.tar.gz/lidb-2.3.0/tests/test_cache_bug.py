# -*- coding: utf-8 -*-
"""测试缓存场景"""
import polars as pl
from lidb.qdf.qdf import QDF


def test_cache_false_never_pollutes_data():
    """cache=False 的设计意图：self.data 始终只包含原始列+有持久缓存的列，中间列不留"""
    df = pl.DataFrame({
        "date": ["2024-01-01"],
        "time": ["09:00"],
        "asset": ["BTC"],
        "open": [99.0],
        "close": [100.0],
    })

    qdf = QDF(df, index=("date", "time", "asset"), align=False)
    original_cols = qdf.data.columns.copy()

    # Step 1: cache=False，close/open as ratio 加到结果，但不留 self.data
    r1 = qdf.sql("close/open as ratio", cache=False)
    assert "ratio" in r1.columns, "结果应包含 ratio 列"
    assert "ratio" not in qdf.data.columns, "cache=False 不应污染 self.data"

    # Step 2: cache=True 会持久化到 self.data
    r2 = qdf.sql("close * 2 as close_2x", cache=True)
    assert "close_2x" in r2.columns, "结果应包含 close_2x 列"
    assert "close_2x" in qdf.data.columns, "cache=True 应持久化 close_2x 到 self.data"
    assert r2["close_2x"][0] == 200.0, "close * 2 = 200.0"


def test_stale_cache_with_alias_collision():
    """两个不同表达式产生相同 alias 的场景

    注意：_expr_cache 以 alias 为 key，后续同名 alias 不会更新缓存，
    而是返回 self.data 中已存在的列值
    """
    df = pl.DataFrame({
        "date": ["2024-01-01"],
        "time": ["09:00"],
        "asset": ["BTC"],
        "close": [100.0],
    })

    qdf = QDF(df, index=("date", "time", "asset"), align=False)

    # batch1: close * 2 as mid，mid 在 data 中
    r1 = qdf.sql("close * 2 as mid", cache=True)
    assert r1["mid"][0] == 200.0, "close * 2 = 200.0"
    assert "mid" in qdf.data.columns, "cache=True 应持久化 mid"

    # batch2: close * 3 as mid（不同表达式，相同 alias）
    # 由于 self.data 中已有 mid 列，sql 解析会直接引用该列，不会重新计算
    r2 = qdf.sql("close * 3 as mid", cache=True)
    assert r2["mid"][0] == 200.0, "self.data 中已存在的 mid 列不会被覆盖"


if __name__ == "__main__":
    test_cache_false_never_pollutes_data()
    print("\n" + "="*60 + "\n")
    test_stale_cache_with_alias_collision()
