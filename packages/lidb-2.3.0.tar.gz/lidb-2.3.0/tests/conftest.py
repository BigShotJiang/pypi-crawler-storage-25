# Copyright (c) ZhangYundi
# Licensed under the MIT License
# pytest fixtures for lidb tests

import pytest
import polars as pl


@pytest.fixture
def sample_fn():
    """返回示例数据函数"""
    def fn(date: str) -> pl.DataFrame:
        return pl.DataFrame({"date": [date], "value": [1]})
    return fn


@pytest.fixture
def sample_fn_with_asset():
    """返回带 asset 参数的示例数据函数"""
    def fn(date: str, asset: str) -> pl.DataFrame:
        return pl.DataFrame({"date": [date], "asset": [asset], "value": [1]})
    return fn


@pytest.fixture
def multi_col_fn():
    """返回多列示例数据函数"""
    def fn(date: str, asset: str, value: int) -> pl.DataFrame:
        return pl.DataFrame({
            "date": [date],
            "asset": [asset],
            "value": [value]
        })
    return fn
