# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for qdf reload functionality

import importlib
import pytest
import polars as pl


class TestQDFReload:
    """测试 QDF 模块的 reload 行为"""

    def test_qdf_module_can_be_reloaded(self):
        """QDF 模块应该可以被重新加载而不报错"""
        import lidb.qdf.qdf as qdf_module

        # 第一次导入应该成功
        assert qdf_module is not None

        # reload 应该不会报错
        import lidb.qdf.qdf
        importlib.reload(lidb.qdf.qdf)

    def test_qdf_import_after_reload(self):
        """reload 后重新导入应该正常工作"""
        import lidb.qdf.qdf as qdf_module1
        from lidb.qdf.qdf import QDF

        # reload 模块
        import lidb.qdf.qdf
        importlib.reload(lidb.qdf.qdf)
        from lidb.qdf.qdf import QDF as QDF2

        # QDF 类应该仍然可用
        assert QDF2 is not None

    def test_register_udf_works_after_multiple_reloads(self):
        """多次 reload 后 register_udf 应该仍然正常工作"""
        import lidb.qdf.qdf
        importlib.reload(lidb.qdf.qdf)

        from lidb.qdf.qdf import QDF

        # 创建一个简单的测试 UDF
        def my_test_func(x):
            return x * 2

        # 创建 QDF 实例
        df = pl.DataFrame({
            "date": ["2024-01-01", "2024-01-02"],
            "time": ["09:30", "09:30"],
            "asset": ["AAPL", "AAPL"],
            "close": [100.0, 101.0],
        })

        qdf = QDF(df)

        # 注册 UDF
        qdf.register_udf(my_test_func, name="my_test_func")

        # 再次 reload
        importlib.reload(lidb.qdf.qdf)

        # 应该仍然可以创建 QDF 并注册函数
        qdf2 = QDF(df)
        qdf2.register_udf(my_test_func, name="my_test_func")
