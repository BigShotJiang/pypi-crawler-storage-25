# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for parse module

import tempfile
from pathlib import Path

import polars as pl
import pytest

from lidb.parse import (
    format_sql,
    extract_temp_tables,
    extract_table_names_from_sql,
    parse_hive_partition_structure,
)


class TestFormatSql:
    """测试 format_sql 函数"""

    def test_format_sql_removes_comments(self):
        """SQL 格式化应去除注释"""
        sql = "SELECT * FROM table -- comment\nWHERE id = 1"
        result = format_sql(sql)
        assert "--" not in result
        assert "comment" not in result

    def test_format_sql_reindents(self):
        """SQL 格式化应重新缩进"""
        sql = "SELECT a,b FROM table WHERE id=1"
        result = format_sql(sql)
        assert "SELECT" in result
        assert "FROM" in result

    def test_format_sql_preserves_content(self):
        """SQL 格式化应保留核心内容"""
        sql = "SELECT id,name FROM users WHERE active=1"
        result = format_sql(sql)
        assert "id" in result
        assert "name" in result
        assert "users" in result


class TestExtractTempTables:
    """测试 extract_temp_tables 函数"""

    def test_extract_single_temp_table(self):
        """提取单个临时表"""
        sql = "WITH temp AS (SELECT * FROM base) SELECT * FROM temp"
        result = extract_temp_tables(sql)
        assert "temp" in result

    def test_extract_multiple_temp_tables(self):
        """提取多个临时表"""
        sql = "WITH t1 AS (SELECT 1), t2 AS (SELECT 2) SELECT * FROM t1 JOIN t2"
        result = extract_temp_tables(sql)
        assert "t1" in result
        assert "t2" in result

    def test_extract_no_temp_table(self):
        """无临时表时返回空列表"""
        sql = "SELECT * FROM base"
        result = extract_temp_tables(sql)
        assert result == []

    def test_extract_case_insensitive(self):
        """WITH 大小写不敏感"""
        sql = "with temp as (select 1) select * from temp"
        result = extract_temp_tables(sql)
        assert "temp" in result


class TestExtractTableNames:
    """测试 extract_table_names_from_sql 函数"""

    def test_extract_simple_select(self):
        """提取简单 SELECT 语句的表名"""
        sql = "SELECT * FROM users"
        result = extract_table_names_from_sql(sql)
        assert "users" in result

    def test_extract_join(self):
        """提取 JOIN 语句的表名"""
        sql = "SELECT * FROM users JOIN orders ON users.id = orders.user_id"
        result = extract_table_names_from_sql(sql)
        assert "users" in result
        assert "orders" in result

    def test_extract_multiple_joins(self):
        """提取多个 JOIN"""
        sql = "SELECT * FROM a JOIN b ON a.id = b.id JOIN c ON b.id = c.id"
        result = extract_table_names_from_sql(sql)
        assert "a" in result
        assert "b" in result
        assert "c" in result

    def test_extract_with_namespace(self):
        """提取带命名空间的表名"""
        sql = "SELECT * FROM schema.users"
        result = extract_table_names_from_sql(sql)
        assert "users" in result

    def test_extract_excludes_temp_tables_from_base(self):
        """排除 WITH 语句基础表的临时表名"""
        sql = "WITH temp AS (SELECT * FROM base) SELECT * FROM base JOIN real_table"
        result = extract_table_names_from_sql(sql)
        # 注意：extract_table_names_from_sql 会提取 temp，但会排除 base（因为它是 temp 的源）
        assert "base" in result
        assert "real_table" in result

    def test_extract_subquery(self):
        """处理子查询"""
        sql = "SELECT * FROM (SELECT id FROM inner_table) AS sub"
        result = extract_table_names_from_sql(sql)
        assert "inner_table" in result

    def test_extract_with_quoted_names(self):
        """处理带引号的表名"""
        sql = 'SELECT * FROM `users` JOIN "orders" ON users.id = orders.id'
        result = extract_table_names_from_sql(sql)
        assert "users" in result
        assert "orders" in result


class TestParseHivePartition:
    """测试 parse_hive_partition_structure 函数"""

    def test_parse_with_string_path(self):
        """支持字符串路径"""
        with tempfile.TemporaryDirectory() as tmpdir:
            # 创建测试文件（需要内容否则被删除）
            test_file = Path(tmpdir) / "date=2024-01-01" / "data.parquet"
            test_file.parent.mkdir(parents=True)
            test_file.write_bytes(b"fake parquet data")

            result = parse_hive_partition_structure(tmpdir, "*.parquet")
            assert isinstance(result, pl.DataFrame)
            assert "date" in result.columns
            assert len(result) >= 1

    def test_parse_with_path_object(self):
        """支持 Path 对象"""
        with tempfile.TemporaryDirectory() as tmpdir:
            test_file = Path(tmpdir) / "asset=000001" / "date=2024-01-01" / "data.parquet"
            test_file.parent.mkdir(parents=True)
            test_file.write_bytes(b"fake parquet data")

            result = parse_hive_partition_structure(Path(tmpdir), "*.parquet")
            assert isinstance(result, pl.DataFrame)
            assert "asset" in result.columns
            assert "date" in result.columns

    def test_parse_empty_directory(self):
        """空目录返回空 DataFrame"""
        with tempfile.TemporaryDirectory() as tmpdir:
            result = parse_hive_partition_structure(tmpdir, "*.parquet")
            assert isinstance(result, pl.DataFrame)
            assert len(result) == 0

    def test_parse_multiple_partitions(self):
        """解析多级分区"""
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            # 创建多个分区组合
            f1 = base / "date=2024-01-01" / "asset=BTC" / "data.parquet"
            f1.parent.mkdir(parents=True)
            f1.write_bytes(b"data1")

            f2 = base / "date=2024-01-02" / "asset=ETH" / "data.parquet"
            f2.parent.mkdir(parents=True)
            f2.write_bytes(b"data2")

            f3 = base / "date=2024-01-03" / "asset=BTC" / "data.parquet"
            f3.parent.mkdir(parents=True)
            f3.write_bytes(b"data3")

            result = parse_hive_partition_structure(tmpdir, "*.parquet")
            assert len(result) >= 3

    def test_parse_handles_empty_files(self):
        """跳过空文件"""
        with tempfile.TemporaryDirectory() as tmpdir:
            base = Path(tmpdir)
            # 创建空文件
            empty_file = base / "date=2024-01-01" / "empty.parquet"
            empty_file.parent.mkdir(parents=True)
            empty_file.touch()  # 0 bytes

            # 创建正常文件
            normal_file = base / "date=2024-01-02" / "data.parquet"
            normal_file.parent.mkdir(parents=True)
            normal_file.write_bytes(b"data")

            result = parse_hive_partition_structure(tmpdir, "*.parquet")
            # 空文件应被删除
            assert not empty_file.exists()
