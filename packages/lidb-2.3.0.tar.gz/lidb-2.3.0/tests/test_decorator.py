# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for @dataset decorator

import pytest
import polars as pl

from lidb import dataset
from lidb.dataset import Dataset


class TestDatasetDecorator:
    """测试 @dataset 装饰器"""

    def test_decorator_creates_dataset(self):
        """装饰器应返回 Dataset 对象"""

        @dataset()
        def my_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "value": [1]})

        # 装饰器应该返回 Dataset 实例
        assert isinstance(my_data, Dataset)

    def test_decorator_with_depends(self):
        """装饰器支持 depends 参数"""

        @dataset()
        def base_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "base": [1]})

        @dataset(base_data)
        def derived_data(date: str, depend: pl.DataFrame) -> pl.DataFrame:
            return depend.with_columns(derived=pl.col("base") * 2)

        assert isinstance(base_data, Dataset)
        assert isinstance(derived_data, Dataset)

    def test_decorator_tb_parameter(self):
        """装饰器支持 tb 参数"""

        @dataset(tb="custom/table/path")
        def my_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert my_data.tb == "custom/table/path"

    def test_decorator_update_time_parameter(self):
        """装饰器支持 update_time 参数"""

        @dataset(update_time="09:30")
        def daily_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert daily_data.update_time == "09:30"

    def test_decorator_window_parameter(self):
        """装饰器支持 window 参数"""

        @dataset(window="5d")
        def windowed_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert windowed_data._window == "5d"

    def test_decorator_partitions_parameter(self):
        """装饰器支持 partitions 参数"""

        @dataset(partitions=["date"])
        def partitioned_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "value": [1]})

        assert partitioned_data.partitions == ["date"]

    def test_decorator_empty_partitions_still_gets_appended(self):
        """partitions=[] 时仍会追加 _append_partitions（如 date, asset）"""

        @dataset(partitions=[])
        def no_partition_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        # 实际行为：空列表 + _append_partitions
        assert "date" in no_partition_data.partitions

    def test_decorator_is_hft_parameter(self):
        """装饰器支持 is_hft 参数"""

        @dataset(is_hft=True)
        def hft_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        assert hft_data._is_hft is True

    def test_decorator_multiple_depends(self):
        """装饰器支持多个依赖"""

        @dataset()
        def source1(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "v1": [1]})

        @dataset()
        def source2(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "v2": [2]})

        @dataset(source1, source2)
        def combined(date: str, depend1: pl.DataFrame, depend2: pl.DataFrame) -> pl.DataFrame:
            return depend1.join(depend2, on="date")

        assert len(combined._depends) == 2

    def test_decorator_default_values(self):
        """装饰器默认参数值"""

        @dataset()
        def default_data(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        # 默认值检查（基于实际行为）
        # @dataset() 装饰器显式传入 data_name=fn.__name__，从 fn 参数推断 partitions
        assert default_data.update_time == ""  # 默认空字符串
        assert default_data._window == "1d"  # 默认 1d
        assert default_data._is_hft is False  # 默认 False
        # partitions 会被推断（包含 date）
        assert "date" in default_data.partitions

    def test_decorator_preserves_function_name(self):
        """装饰器保留原函数名"""

        @dataset()
        def my_custom_function(date: str) -> pl.DataFrame:
            return pl.DataFrame({"date": [date]})

        # data_name 在装饰器中赋值为 fn.__name__
        assert my_custom_function.data_name == "my_custom_function"

    def test_decorator_partitions_none_inference(self):
        """partitions=None 时从函数参数推断分区"""

        @dataset()
        def data_with_params(date: str, asset: str, value: int) -> pl.DataFrame:
            return pl.DataFrame({"date": [date], "asset": [asset], "value": [value]})

        # partitions=None 时，从 fn 参数推断
        # 默认会排除 'this', 'depend'，但包含其他所有参数
        assert "date" in data_with_params.partitions
        assert "asset" in data_with_params.partitions
        assert "value" in data_with_params.partitions