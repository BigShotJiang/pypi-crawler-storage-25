# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for Table class

import tempfile
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, patch

import polars as pl
import pytest

from lidb.table import Table, TableMode


class TestTableMode:
    """测试 TableMode 枚举"""

    def test_table_mode_full(self):
        """全量更新模式"""
        assert TableMode.F == TableMode("full")
        assert TableMode.F.value == "full"

    def test_table_mode_increment(self):
        """增量更新模式"""
        assert TableMode.I == TableMode("increment")
        assert TableMode.I.value == "increment"

    def test_table_mode_values(self):
        """模式值正确"""
        assert TableMode.F.value == "full"
        assert TableMode.I.value == "increment"


class TestTable:
    """测试 Table 类"""

    def test_table_creation(self):
        """创建 Table 实例"""
        def fn():
            return pl.DataFrame({"a": [1]})

        table = Table(fn, tb="test", update_time="15:00:00")
        assert table.fn is fn
        assert table.tb == "test"
        assert table.update_time == "15:00:00"
        assert table.mode == TableMode.F

    def test_table_default_mode(self):
        """默认模式为全量更新"""
        def fn():
            return pl.DataFrame()

        table = Table(fn, tb="test", update_time="15:00:00")
        assert table.mode == TableMode.F

    def test_table_increment_mode(self):
        """可设置增量模式"""
        def fn():
            return pl.DataFrame()

        table = Table(fn, tb="test", update_time="15:00:00", mode=TableMode.I)
        assert table.mode == TableMode.I

    def test_table_call_returns_new_table(self):
        """调用返回新 Table 实例"""
        def fn(date: str):
            return pl.DataFrame({"date": [date]})

        table = Table(fn, tb="test", update_time="15:00:00")
        new_table = table(date="2024-01-01")

        assert new_table is not table
        assert new_table.tb == table.tb
        assert new_table.update_time == table.update_time

    def test_table_verbose_defaults_false(self):
        """verbose 默认关闭"""
        def fn():
            return pl.DataFrame()

        table = Table(fn, tb="test", update_time="15:00:00")
        assert table.verbose is False

    def test_table_data_dir(self):
        """数据目录路径正确"""
        def fn():
            return pl.DataFrame()

        table = Table(fn, tb="test_table", update_time="15:00:00")
        # tb_path 会被调用来构建 _data_dir
        assert table._data_dir is not None


class TestTableInternalMethods:
    """测试 Table 内部方法"""

    def test_updated_logic(self):
        """测试 _updated 方法判断逻辑"""
        def fn():
            return pl.DataFrame()

        table = Table(fn, tb="test", update_time="15:00:00")

        # 测试：数据更新时间晚于更新时间的判断
        # 当 now >= update_time 时，使用 recent_tradeday
        # 当 now < update_time 时，使用 prev_tradeday
        result = table._updated(
            date="2024-01-15",
            data_date="2024-01-15",
            data_time="16:00:00"
        )
        assert isinstance(result, bool)

    def test_need_update_no_directory(self):
        """数据目录不存在时需要更新"""
        def fn():
            return pl.DataFrame()

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("lidb.table.tb_path", return_value=Path(tmpdir)):
                table = Table(fn, tb="test", update_time="15:00:00")
                # 手动设置一个不存在的路径
                table._data_dir = Path(tmpdir) / "nonexistent"

                result = table._need_update("2024-01-15")
                assert result is True

    def test_latest_file_property(self):
        """latest_file 属性返回最新文件"""
        def fn():
            return pl.DataFrame()

        import os

        with tempfile.TemporaryDirectory() as tmpdir:
            table = Table(fn, tb="test", update_time="15:00:00")
            table._data_dir = Path(tmpdir)

            # 无文件时返回 None
            assert table.latest_file is None

            # 创建测试文件
            older = Path(tmpdir) / "1.parquet"
            older.write_bytes(b"old")
            older_time = datetime.now() - timedelta(hours=1)
            os.utime(older, (older_time.timestamp(), older_time.timestamp()))

            newer = Path(tmpdir) / "2.parquet"
            newer.write_bytes(b"new")

            assert table.latest_file == newer

    def test_modified_time_property(self):
        """modified_time 属性返回文件修改时间"""
        def fn():
            return pl.DataFrame()

        with tempfile.TemporaryDirectory() as tmpdir:
            table = Table(fn, tb="test", update_time="15:00:00")
            table._data_dir = Path(tmpdir)

            # 无文件时返回 None
            assert table.modified_time is None

            # 创建测试文件
            test_file = Path(tmpdir) / "test.parquet"
            test_file.write_bytes(b"data")

            mtime = table.modified_time
            assert mtime is not None
            assert isinstance(mtime, datetime)


class TestTableLog:
    """测试日志功能"""

    def test_log_only_verbose(self):
        """只在 verbose=True 时输出日志"""
        def fn():
            return pl.DataFrame()

        table = Table(fn, tb="test", update_time="15:00:00")

        # verbose=False 时不输出
        table._log("test message")

        # verbose=True 时输出
        table.verbose = True
        table._log("test message")


class TestTableDoJob:
    """测试 _do_job 方法"""

    def test_do_job_no_data(self, tmp_path):
        """无数据时不保存"""
        def fn():
            return None

        table = Table(fn, tb="test", update_time="15:00:00")
        table._data_dir = tmp_path / "test"
        table._data_dir.mkdir(parents=True)

        table._do_job()

        # 无文件被创建
        assert len(list(table._data_dir.glob("*.parquet"))) == 0

    def test_do_job_empty_data(self, tmp_path):
        """空数据时不保存"""
        def fn():
            return pl.DataFrame()

        table = Table(fn, tb="test", update_time="15:00:00")
        table._data_dir = tmp_path / "test"
        table._data_dir.mkdir(parents=True)

        table._do_job()

        # 无文件被创建
        assert len(list(table._data_dir.glob("*.parquet"))) == 0
