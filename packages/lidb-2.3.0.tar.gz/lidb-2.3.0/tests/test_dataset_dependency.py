# Copyright (c) ZhangYundi
# Licensed under the MIT License
# Test for Dataset dependency auto-completion

import shutil

import polars as pl

from lidb import DB_PATH, dataset


@dataset()
def ds_base(date: str) -> pl.DataFrame:
    return pl.DataFrame({
        "date": [date],
        "asset": ["000001"],
        "base_value": [1.0],
    })


@dataset(ds_base)
def ds_target(date: str, depend: pl.DataFrame) -> pl.DataFrame:
    return depend.with_columns(target_value=pl.col("base_value") * 2)


class TestDatasetDependency:
    """测试 Dataset 依赖穿透补全"""

    def setup_method(self, method):
        """每个测试前清理测试数据"""
        self.test_db_path = DB_PATH / "test_dependency"
        if self.test_db_path.exists():
            shutil.rmtree(self.test_db_path)
        self.test_db_path.mkdir(parents=True, exist_ok=True)

        self.ds_base = ds_base
        self.ds_target = ds_target

        # 替换为测试路径
        self.ds_base.tb = self.test_db_path / "ds_base"
        self.ds_base.save_path = self.ds_base.tb
        self.ds_target.tb = self.test_db_path / "ds_target"
        self.ds_target.save_path = self.ds_target.tb

        # 同步更新依赖的路径
        if self.ds_target._depends:
            dep = self.ds_target._depends[0]
            dep.tb = self.ds_base.tb
            dep.save_path = self.ds_base.save_path

    def teardown_method(self, method):
        """每个测试后清理"""
        if hasattr(self, "test_db_path") and self.test_db_path.exists():
            shutil.rmtree(self.test_db_path)

    def _base_path(self, date):
        """ds_base 的存储路径"""
        return self.ds_base.save_path / f"date={date}"

    def _target_path(self):
        """ds_target 的存储根路径"""
        return self.ds_target.save_path

    def test_ds_target_get_value_auto_complete_base(self):
        """测试 get_value 会自动穿透补全 ds_base"""
        date = "2024-01-02"

        # 确认 ds_base 数据不存在
        assert self.ds_base.is_empty(self._base_path(date)), "前置条件: ds_base 应为空"

        # 调用 ds_target.get_value，ds_base 应该被自动补全
        result = self.ds_target.get_value(date)

        # 验证 ds_base 已被补全
        assert not self.ds_base.is_empty(self._base_path(date)), \
            f"ds_base {date} 应该在 ds_target.get_value 后被自动补全"

        # 验证结果正确
        assert result is not None
        df = result.collect() if hasattr(result, "collect") else result
        assert not df.is_empty()
        assert "target_value" in df.columns

    def test_ds_target_get_history_auto_complete_base(self):
        """测试 get_history 会自动穿透补全 ds_base"""
        dates = ["2024-01-02", "2024-01-03", "2024-01-04"]

        for date in dates:
            assert self.ds_base.is_empty(self._base_path(date)), \
                f"前置条件: ds_base {date} 应为空"

        # 调用 ds_target.get_history，ds_base 应该被自动补全
        result = self.ds_target.get_history(dates, eager=True)

        # 验证 ds_base 所有日期均已被补全
        for date in dates:
            assert not self.ds_base.is_empty(self._base_path(date)), \
                f"ds_base {date} 应该在 ds_target.get_history 后被自动补全"

        # 验证结果正确
        assert result is not None
        assert not result.is_empty()
        assert "target_value" in result.columns

    def test_ds_target_get_history_with_existing_data(self):
        """测试 get_history 在目标数据已存在时，仍会穿透补全依赖"""
        # 先补全 target 的部分日期
        self.ds_target.get_history(["2024-01-02"], eager=True)

        # 确认 ds_target 有数据
        assert not self.ds_target.is_empty(self._target_path()), \
            "前置条件: ds_target 应有部分数据"

        # 清空 ds_base，模拟依赖数据未补全的情况
        base_asset_path = self.ds_base.save_path / "asset=000001"
        if base_asset_path.exists():
            shutil.rmtree(base_asset_path)

        # 再次调用 get_history（包含已有日期 + 新日期）
        self.ds_target.get_history(["2024-01-02", "2024-01-03"], eager=True)

        # 关键验证: ds_base 仍应被穿透补全（即使目标数据已存在）
        for date in ["2024-01-02", "2024-01-03"]:
            assert not self.ds_base.is_empty(self._base_path(date)), \
                f"ds_base {date} 应该在穿透补全后存在"


if __name__ == "__main__":
    # import pytest

    # pytest.main([__file__, "-v"])
    test_date = "2020-01-02"
    data_base = ds_base.get_value(test_date)
    data_target = ds_target.get_value(test_date)
    print(data_base)
    print(data_target)

