
# 打包 python setup.py sdist
# 上传 twine upload dist/*


# 安装 python setup.py install
import os,sys
from setuptools import setup
from kunapi import kcwsinfo
def get_file(folder='./',lists=[]):
    lis=os.listdir(folder)
    for files in lis:
        if not os.path.isfile(folder+"/"+files):
            if files=='__pycache__' or files=='.git':
                pass
            else:
                lists.append(folder+"/"+files)
                get_file(folder+"/"+files,lists)
        else:
            pass
    return lists
def start():
    b=get_file("kunapi",['kunapi'])
    setup(
        name = kcwsinfo["name"],
        version = kcwsinfo["version"],
        keywords = "kunapi"+kcwsinfo['version'],
        description = kcwsinfo["description"],
        long_description = kcwsinfo["long_description"],
        license = kcwsinfo["license"],
        author = kcwsinfo["author"],
        author_email = kcwsinfo["author_email"],
        maintainer = kcwsinfo["maintainer"],
        maintainer_email = kcwsinfo["maintainer_email"],
        url=kcwsinfo['url'],
        packages =  b,
        install_requires = ['gunicorn==20.0.4','waitress==3.0.0','watchdog==4.0.0','filetype==1.2.0','psutil==5.9.4','requests==2.32.4','python-daemon==3.1.2'], #第三方包
        package_data = {
            '': ['*.html', '*.js','*.css','*.jpg','*.png','*.gif'],
        },
        entry_points = {
            'console_scripts':[
                'kunapi = kunapi.kunapi:cill_start'
            ]
        }
    )
start()