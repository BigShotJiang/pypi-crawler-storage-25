# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
from kunapi.config import *
app['app_debug']=False  #是否开启调试模式
app['tpl_folder']='./app'  #设置模板文件目录名 注意：所有的配置目录都是以您的运行文件所在目录开始
app['before_request']='before_request'  #设置请求前要执行的函数名
app['after_request']='after_request'    #设置请求后要执行的函数名
app['staticpath']='app/static'          #静态主要目录
app['appmode']='develop'  #produc 生产环境  develop 开发环境

#路由配置
route['default']=True #是否开启默认路由  默认路由开启后面不影响以下配置的路由，模块名/版本名/控制器文件名/方法名 作为路由地址   如：http://www.kcws.com/modular/plug/index/index/
route['modular']=[{"kcwebsapi":"official"},{"kwebs":"official"}] #指定访问配置固定模块 （如果匹配了该值，将无法通过改变url访问不同模块）
route['plug']=[{"kcwebsapi":"official"},{"kwebs":"official"}] #指定访问固定插件 （如果匹配了该值，将无法通过改变url访问不同插件）
route['defmodular']='index' #默认模块 当url不包括模块名时
route['defplug']='index' #默认插件 当url不包括插件名时
route['files']='index' #默认路由文件（控制器） 当url不包括控制器名时
route['funct']='index'  #默认路由函数 (操作方法) 当url不包括操作方法名时
route['methods']=['POST','GET','DELETE','PUT'] #默认请求方式



