"""CareerService — Phase 1 facts CRUD.

This is the foundation of the career subsystem. The user authors structured
facts (work-history, education, skills, projects, achievements,
recommendations); the agent reads them as the GROUND TRUTH for CV / cover
letter generation in Phase 3+.

Architectural invariants:
    1. ``FACT_CATEGORIES`` is a closed enum tagged ``# arch:deterministic`` in
       ``templates.py``. Path injection is impossible — every category passed
       to ``get_fact`` / ``update_fact`` is validated against the frozen set.
    2. Writes go through ``VaultWriter`` with ``trust_reason="career_facts_edit"``
       so the runtime guard accepts inline-editor saves AND the boot-time
       scaffolding without forcing every route to authorize a specific
       contract action. Same pattern as graph persistence (session 59).
    3. ``ensure_facts_scaffolded()`` is idempotent — existence check per file.
       Re-running on a fully-scaffolded vault is a fast no-op. The boot path
       can call it unconditionally.
    4. Fail-soft at every boundary. A broken activity logger, missing reader,
       or write failure NEVER raises into the chat path. The user MIGHT lose
       a save (visible via toast); they NEVER lose a chat turn or a session.

Phase 2+ (listings, applications, CV generation) will extend this service,
not replace it.
"""
from __future__ import annotations

import logging
import re
import unicodedata
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

import frontmatter

from agntspace.career.templates import (
    APPLICATION_FRONTMATTER_FIELDS,
    APPLICATION_METADATA_TEMPLATE,
    APPLICATION_STATUSES,
    DEFAULT_FACT_TEMPLATES,
    FACT_CATEGORIES,
    LISTING_FRONTMATTER_FIELDS,
    LISTING_STATUSES,
    LISTING_TEMPLATE,
    is_valid_application_status,
    is_valid_listing_status,
)
from agntspace.vault.paths import VaultPaths
from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

# Closed enum re-exported for callers that import from service directly.
__all__ = [
    "CareerService",
    "FACT_CATEGORIES",
    "FactMeta",
    "ListingMeta",
    "LISTING_STATUSES",
]


_FACTS_DIR = "career/facts"  # logical path; VaultPaths resolves to agntspace-career/facts
_LISTINGS_DIR = "career/listings"  # → agntspace-career/listings
_APPLICATIONS_DIR = "career/applications"  # → agntspace-career/applications/{slug}/{metadata.md, cv.docx, ...}


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


@dataclass(frozen=True)
class FactMeta:
    """Per-category summary returned by ``list_facts``."""
    category: str                # one of FACT_CATEGORIES
    path: str                    # logical vault path (e.g. "career/facts/skills.md")
    exists: bool                 # False before scaffolding has run for this category
    size_bytes: int              # 0 if missing
    last_updated: str            # frontmatter ``last_updated`` if non-empty, else file mtime ISO
    is_empty: bool               # True if the file body still matches the shipped template (heuristic)


@dataclass(frozen=True)
class ListingMeta:
    """Per-listing summary returned by ``list_listings``."""
    slug: str
    path: str                    # logical vault path (e.g. "career/listings/stripe-platform-eng-2026-05.md")
    company: str
    role: str
    status: str                  # one of LISTING_STATUSES
    url: str
    deadline: str                # ISO date string or empty
    posted_at: str               # ISO date string or empty
    created_at: str              # ISO timestamp


@dataclass(frozen=True)
class ApplicationMeta:
    """Per-application summary returned by ``list_applications``.

    Phase 3 — Slice A. Each application lives at
    ``agntspace-career/applications/<slug>/metadata.md`` plus sibling
    deliverable files (cv.docx, cover_letter.docx, jd_analysis.md)
    inside the same folder.
    """
    slug: str
    path: str                    # logical vault path to the metadata.md file
    folder: str                  # logical vault path to the application folder
    listing_slug: str            # linked listing
    status: str                  # one of APPLICATION_STATUSES
    created_at: str              # ISO timestamp
    generated_assets: list[str]  # relative paths inside the folder (e.g. ["cv.docx"])


# ── Pure helpers (testable without the service) ────────────────────

_SLUG_TRAILING = re.compile(r"-+$")
_SLUG_LEADING = re.compile(r"^-+")
_SLUG_BAD = re.compile(r"[^a-z0-9]+")


def derive_listing_slug(company: str, role: str, posted_at: str = "") -> str:
    """Build a deterministic, URL-safe slug from a listing's identity.

    Format: ``<company>-<role-head>-<YYYY-MM>``. Year-month suffix lets the
    same company + role be tracked across re-postings (companies frequently
    re-list the same req months apart). Falls back to current YYYY-MM when
    posted_at is empty so a slug always carries a date component.

    The slug must round-trip through pathlib + URL encoding without
    surprises — strict ASCII-lower-with-dashes only.
    """
    if not isinstance(company, str) or not company.strip():
        raise ValueError("company is required for slug derivation")
    if not isinstance(role, str) or not role.strip():
        raise ValueError("role is required for slug derivation")

    # ASCII-fold diacritics (Müller → muller) so slugs don't depend on Unicode form.
    def _ascii(s: str) -> str:
        norm = unicodedata.normalize("NFKD", s)
        ascii_only = norm.encode("ascii", "ignore").decode("ascii")
        return ascii_only.lower()

    company_slug = _SLUG_BAD.sub("-", _ascii(company)).strip("-")
    role_head = " ".join(role.split()[:3])  # cap role at first 3 words to keep slugs reasonable
    role_slug = _SLUG_BAD.sub("-", _ascii(role_head)).strip("-")

    # Year-month suffix.
    if posted_at and isinstance(posted_at, str) and len(posted_at) >= 7:
        # Accept YYYY-MM, YYYY-MM-DD, full ISO timestamp — slice the leading YYYY-MM.
        ym = posted_at[:7]
        if re.match(r"^\d{4}-\d{2}$", ym):
            date_suffix = ym
        else:
            date_suffix = datetime.now(UTC).strftime("%Y-%m")
    else:
        date_suffix = datetime.now(UTC).strftime("%Y-%m")

    parts = [p for p in (company_slug, role_slug, date_suffix) if p]
    slug = "-".join(parts)
    slug = _SLUG_LEADING.sub("", slug)
    slug = _SLUG_TRAILING.sub("", slug)
    if not slug:
        raise ValueError(
            f"derive_listing_slug produced empty slug from "
            f"company={company!r}, role={role!r}"
        )
    return slug


def normalize_tech_stack(value: object) -> list[str]:
    """Coerce a freeform tech_stack input to a clean list of strings.

    Accepts list, comma-string, or single string. Drops empty/whitespace
    entries. Preserves caller order (de-dup keeps first occurrence).
    """
    if value is None:
        return []
    if isinstance(value, str):
        items = [p.strip() for p in value.split(",")]
    elif isinstance(value, (list, tuple)):
        items = [str(p).strip() for p in value]
    else:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for it in items:
        if not it or it in seen:
            continue
        seen.add(it)
        out.append(it)
    return out


def _yaml_tech_stack(items: list[str]) -> str:
    """Render a tech_stack list as inline YAML for the listing template."""
    if not items:
        return "[]"
    # Quote each entry; escape embedded double quotes.
    quoted = ", ".join(f'"{it.replace(chr(34), chr(39))}"' for it in items)
    return f"[{quoted}]"


def derive_application_slug(listing_slug: str, attempt: int = 1) -> str:
    """Build a deterministic, URL-safe slug for an application.

    Phase 3 — Slice A. Format: ``<listing_slug>-app-<NN>`` where NN is
    zero-padded to 2 digits. First application to a listing → ``-app-01``;
    retry → ``-app-02``; etc. Numeric suffix lets the user retry an
    application (e.g. after improving facts/, regenerate the CV) without
    losing the prior application's artifacts.

    The slug must round-trip through pathlib + URL encoding without
    surprises — strict ASCII-lower-with-dashes only.

    Args:
        listing_slug: the slug of the listing this application targets.
            MUST be a valid listing slug (already passes
            ``CareerService._validate_slug``); we re-validate the shape
            defensively here so a caller can't sneak a path-injection
            string through.
        attempt: 1-based retry counter. Defaults to 1 (the first
            application against this listing).

    Raises:
        ValueError: listing_slug empty / bad shape OR attempt < 1.
    """
    if not isinstance(listing_slug, str) or not listing_slug.strip():
        raise ValueError("listing_slug is required for application slug derivation")
    # Re-validate the listing slug shape (defensive — closes path-injection class).
    if "/" in listing_slug or "\\" in listing_slug or ".." in listing_slug:
        raise ValueError(
            f"listing_slug contains forbidden chars: {listing_slug!r}"
        )
    if not re.match(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$", listing_slug):
        raise ValueError(
            f"listing_slug must be ASCII lowercase + digits + hyphens "
            f"(got {listing_slug!r})"
        )
    if not isinstance(attempt, int) or attempt < 1:
        raise ValueError(f"attempt must be a positive integer, got {attempt!r}")
    return f"{listing_slug}-app-{attempt:02d}"


class CareerService:
    """Manage the user's professional facts (Phase 1 of the career subsystem).

    Phase 2+ additions (listings, applications, CV generation) will be
    sibling methods on this same class so the activity-logger + vault-paths
    dependency wiring lives in one place.
    """

    def __init__(
        self,
        vault_paths: VaultPaths,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        activity_logger: Any | None = None,
    ) -> None:
        self._paths = vault_paths
        self._reader = vault_reader
        self._writer = vault_writer
        # Fail-soft optional dependency. None = no events emitted.
        self._activity = activity_logger

    # ------------------------------------------------------------------
    # Boot-time scaffolding
    # ------------------------------------------------------------------

    def ensure_facts_scaffolded(self) -> dict[str, str]:
        """Create the 6 default fact files in ``career/facts/`` if missing.

        Idempotent: per-file existence check; never overwrites. Safe to call
        on every boot. Returns a map of ``{category: outcome}`` where outcome
        is one of: ``"created"``, ``"already_exists"``, ``"failed:<reason>"``.

        Per Rule 18, the parent directory itself is pre-created by
        ``setup/init.py:_ROOT_DIRS`` + ``VaultPaths.all_init_dirs()`` so a
        fresh vault has the folder visible in the file explorer from day one;
        this method only ensures the TEMPLATE files exist inside it.
        """
        outcomes: dict[str, str] = {}
        facts_dir_phys = self._paths.resolve(_FACTS_DIR)
        try:
            facts_dir_phys.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            log.warning("Could not create %s: %s", facts_dir_phys, exc)
            return {cat: f"failed:mkdir:{exc}" for cat in FACT_CATEGORIES}

        for category, template in DEFAULT_FACT_TEMPLATES.items():
            rel_path = self._path_for(category)
            phys = self._paths.resolve(rel_path)
            if phys.exists():
                outcomes[category] = "already_exists"
                continue
            try:
                # Stamp last_updated to the scaffolding moment so freshness
                # heuristics work from day one. The template ships
                # last_updated: "" so the post-frontmatter render handles it.
                seeded = template.replace(
                    'last_updated: ""',
                    f'last_updated: "{_now_iso()}"',
                    1,
                )
                self._writer.write(
                    rel_path,
                    seeded,
                    versioned=False,  # scaffolding is not an edit; no .history snapshot
                    trust_reason="career_facts_scaffold",
                )
                outcomes[category] = "created"
                log.debug("Scaffolded career fact: %s", rel_path)
            except Exception as exc:  # noqa: BLE001 — fail-soft per architectural rule
                outcomes[category] = f"failed:{type(exc).__name__}:{exc}"
                log.warning("Failed to scaffold %s: %s", rel_path, exc)

        # Emit one aggregate event so the user sees scaffolding ran (low
        # importance — only first boot is interesting; re-runs report all
        # "already_exists" which is silent-noise).
        created_count = sum(1 for v in outcomes.values() if v == "created")
        if created_count:
            self._log_activity(
                action="career_facts_scaffolded",
                summary=f"Scaffolded {created_count} career fact file(s)",
                importance="low",
                details={"outcomes": outcomes},
            )
        return outcomes

    # ------------------------------------------------------------------
    # Read operations
    # ------------------------------------------------------------------

    def list_facts(self) -> list[FactMeta]:
        """Return a per-category summary (always 6 entries, in canonical order).

        Categories with no file on disk return ``exists=False`` + ``size_bytes=0``
        + ``is_empty=True`` so the UI can render an "uncreated" affordance
        consistently (covers the rare case where scaffolding failed for one
        category on first boot).
        """
        out: list[FactMeta] = []
        for category in FACT_CATEGORIES:
            rel = self._path_for(category)
            phys = self._paths.resolve(rel)
            if not phys.is_file():
                out.append(FactMeta(
                    category=category, path=rel, exists=False,
                    size_bytes=0, last_updated="", is_empty=True,
                ))
                continue
            try:
                stat = phys.stat()
                doc = self._reader.read(rel)
                body = doc.content or ""
                meta = doc.metadata or {}
                # Prefer explicit frontmatter timestamp; fall back to mtime.
                last_updated = ""
                raw_lu = meta.get("last_updated") if isinstance(meta, dict) else None
                if isinstance(raw_lu, str) and raw_lu.strip():
                    last_updated = raw_lu.strip()
                else:
                    last_updated = datetime.fromtimestamp(stat.st_mtime, UTC).isoformat(
                        timespec="seconds"
                    )
                is_empty = self._body_is_template(category, body)
                out.append(FactMeta(
                    category=category, path=rel, exists=True,
                    size_bytes=stat.st_size, last_updated=last_updated,
                    is_empty=is_empty,
                ))
            except Exception as exc:  # noqa: BLE001
                log.warning("Failed to inspect career fact %s: %s", rel, exc)
                out.append(FactMeta(
                    category=category, path=rel, exists=True,
                    size_bytes=0, last_updated="", is_empty=True,
                ))
        return out

    def get_fact(self, category: str) -> dict[str, Any]:
        """Return the full body + parsed frontmatter for one category.

        Raises:
            KeyError: when ``category`` is not in ``FACT_CATEGORIES``. The
                route layer translates this to 404.
            FileNotFoundError: when the category is valid but no file
                exists yet (route → 404, suggest running scaffolding).
        """
        self._require_valid_category(category)
        rel = self._path_for(category)
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        body = doc.content or ""
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        return {
            "category": category,
            "path": rel,
            "metadata": meta,
            "content": body,
            "is_empty": self._body_is_template(category, body),
        }

    # ------------------------------------------------------------------
    # Write operations
    # ------------------------------------------------------------------

    def update_fact(self, category: str, content: str) -> FactMeta:
        """Replace a fact file's content. Auto-stamps ``last_updated``.

        Caller passes the FULL document (frontmatter + body) as ``content``
        — the same shape ``get_fact`` returns. The service rewrites the
        ``last_updated`` frontmatter value to now and persists.

        Returns the post-write ``FactMeta`` so the route can echo back the
        new size + timestamp without a second read.

        Raises:
            KeyError: invalid category (route → 404).
            ValueError: empty content (route → 422).
        """
        self._require_valid_category(category)
        if not isinstance(content, str):
            raise ValueError(f"content must be str, got {type(content).__name__}")
        if not content.strip():
            raise ValueError("content cannot be empty")

        rel = self._path_for(category)
        stamped = self._stamp_last_updated(content)

        # versioned=True so manual edits land in .history/ for safety.
        # trust_reason carries the audit label since career facts edits don't
        # have a dedicated contract_action in Phase 1 (will revisit in Phase 5).
        self._writer.write(
            rel,
            stamped,
            versioned=True,
            trust_reason="career_facts_edit",
        )

        self._log_activity(
            action="career_fact_updated",
            summary=f"Updated career facts: {category}",
            importance="medium",
            details={"category": category, "size_bytes": len(stamped)},
        )

        # Read back via list_facts machinery so the returned meta is exact.
        # Cheap on a single category since stat + frontmatter parse are fast.
        for fm in self.list_facts():
            if fm.category == category:
                return fm
        # Defensive — should never happen, list_facts always returns all 6.
        raise RuntimeError(f"update_fact succeeded but list_facts skipped {category}")

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _path_for(category: str) -> str:
        return f"{_FACTS_DIR}/{category}.md"

    @staticmethod
    def _require_valid_category(category: str) -> None:
        if not isinstance(category, str):
            raise KeyError(f"category must be str, got {type(category).__name__}")
        if category not in FACT_CATEGORIES:
            raise KeyError(
                f"Unknown career fact category {category!r}. Valid: "
                f"{sorted(FACT_CATEGORIES)}"
            )

    @staticmethod
    def _stamp_last_updated(content: str) -> str:
        """Rewrite ``last_updated:`` in frontmatter to now, or insert it.

        Caller MAY have already updated ``last_updated`` via the editor —
        we overwrite anyway so the displayed timestamp always matches the
        actual save moment. Same idempotency model the journal uses.
        """
        try:
            post = frontmatter.loads(content)
        except Exception:  # noqa: BLE001 — malformed yaml, write through
            return content
        post.metadata["last_updated"] = _now_iso()
        return frontmatter.dumps(post)

    def _body_is_template(self, category: str, body: str) -> bool:
        """Heuristic: True if the body is still mostly the shipped template.

        Two signals:
          1. Body length is within 10% of the template length.
          2. Body contains ``[e.g.,`` placeholder markers (the template
             convention) on any line.

        Both signals together is a high-confidence "user hasn't edited
        yet". Either alone is suggestive — we use OR so the UI nudges
        more readily, matching the ProfilePage placeholder-detection
        heuristic (lesson 2026-04-27 line 1303).
        """
        if not body:
            return True
        template = DEFAULT_FACT_TEMPLATES.get(category, "")
        # Extract the template body the same way the file would render.
        try:
            template_body = frontmatter.loads(template).content or ""
        except Exception:  # noqa: BLE001
            template_body = template
        if not template_body:
            return False
        # Signal 1: any [e.g., placeholder still in the body?
        if "[e.g.," in body:
            return True
        # Signal 2: byte-length within 10% of template indicates no user content.
        body_len = len(body.strip())
        tmpl_len = len(template_body.strip())
        if tmpl_len > 0 and abs(body_len - tmpl_len) / tmpl_len < 0.10:
            return True
        return False

    def _log_activity(self, *, action: str, summary: str, importance: str,
                      details: dict[str, Any] | None = None) -> None:
        """Fail-soft activity emission."""
        logger = self._activity
        if logger is None:
            return
        try:
            log_fn = getattr(logger, "log", None)
            if log_fn is None:
                return
            log_fn(
                category="career",
                action=action,
                summary=summary,
                importance=importance,
                details=details or {},
            )
        except Exception as exc:  # noqa: BLE001
            log.debug("activity logger raised on %s: %s", action, exc)

    # ==================================================================
    # Phase 2 — Listings (job announcements) CRUD
    # ==================================================================

    @staticmethod
    def _listing_path(slug: str) -> str:
        """Logical vault path for a listing's markdown file."""
        return f"{_LISTINGS_DIR}/{slug}.md"

    @staticmethod
    def _validate_slug(slug: object) -> str:
        """Validate a slug at the boundary. Closes the path-injection class."""
        if not isinstance(slug, str):
            raise KeyError(f"listing slug must be str, got {type(slug).__name__}")
        if not slug:
            raise KeyError("listing slug cannot be empty")
        if "/" in slug or "\\" in slug or ".." in slug:
            raise KeyError(f"listing slug contains forbidden chars: {slug!r}")
        if not re.match(r"^[a-z0-9][a-z0-9-]*[a-z0-9]$|^[a-z0-9]$", slug):
            raise KeyError(
                f"listing slug must be ASCII lowercase + digits + hyphens "
                f"(got {slug!r})"
            )
        return slug

    def list_listings(
        self,
        *,
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Return a Rule-20-shaped page of listings.

        Args:
            status: optional filter by pipeline status. Invalid status →
                raises KeyError (route → 400).
            limit: max items per page. Clamped to [1, 500].
            offset: pagination offset. Clamped to >= 0.

        Returns:
            ``{"items": [ListingMeta-as-dict, ...], "total": N, "has_more": bool}``

            ``total`` is the FILTERED total (after status filter applies),
            never ``len(items)`` after slicing. Rule 20 compliant.
        """
        if status is not None and not is_valid_listing_status(status):
            raise KeyError(
                f"unknown listing status {status!r}. Valid: {sorted(LISTING_STATUSES)}"
            )
        try:
            limit = max(1, min(500, int(limit)))
        except (TypeError, ValueError):
            limit = 100
        try:
            offset = max(0, int(offset))
        except (TypeError, ValueError):
            offset = 0

        listings_dir = self._paths.resolve(_LISTINGS_DIR)
        if not listings_dir.is_dir():
            return {"items": [], "total": 0, "has_more": False}

        # Collect + sort by created_at desc (newest first). Defensive against
        # broken / missing frontmatter: a corrupt file shows up as an empty
        # ListingMeta with its slug derived from filename, so it's still
        # editable + deletable via the API.
        metas: list[ListingMeta] = []
        for path in sorted(listings_dir.glob("*.md")):
            slug = path.stem
            rel = self._listing_path(slug)
            try:
                doc = self._reader.read(rel)
                meta = doc.metadata if isinstance(doc.metadata, dict) else {}
            except Exception as exc:  # noqa: BLE001
                log.warning("Failed to read listing %s: %s", rel, exc)
                meta = {}
            metas.append(ListingMeta(
                slug=slug,
                path=rel,
                company=str(meta.get("company", "")).strip(),
                role=str(meta.get("role", "")).strip(),
                status=str(meta.get("status", "saved")).strip() or "saved",
                url=str(meta.get("url", "")).strip(),
                deadline=str(meta.get("deadline", "")).strip(),
                posted_at=str(meta.get("posted_at", "")).strip(),
                created_at=str(meta.get("created_at", "")).strip(),
            ))

        # Filter by status BEFORE the total count (Rule 20).
        if status is not None:
            metas = [m for m in metas if m.status == status]

        # Sort newest-first by created_at. Fall back to slug for ties /
        # missing timestamps.
        metas.sort(key=lambda m: (m.created_at, m.slug), reverse=True)

        total = len(metas)
        page = metas[offset : offset + limit]
        has_more = offset + len(page) < total
        return {
            "items": [
                {
                    "slug": m.slug,
                    "path": m.path,
                    "company": m.company,
                    "role": m.role,
                    "status": m.status,
                    "url": m.url,
                    "deadline": m.deadline,
                    "posted_at": m.posted_at,
                    "created_at": m.created_at,
                }
                for m in page
            ],
            "total": total,
            "has_more": has_more,
        }

    def get_listing(self, slug: str) -> dict[str, Any]:
        """Return full body + parsed frontmatter for one listing.

        Raises:
            KeyError: invalid slug shape (route → 404 / 400).
            FileNotFoundError: valid slug but no file on disk (route → 404).
        """
        slug = self._validate_slug(slug)
        rel = self._listing_path(slug)
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        body = doc.content or ""
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        return {
            "slug": slug,
            "path": rel,
            "metadata": meta,
            "content": body,
        }

    def create_listing(
        self,
        *,
        company: str,
        role: str,
        url: str = "",
        raw_jd_text: str = "",
        status: str = "saved",
        source: str = "manual",
        location: str = "",
        salary_range: str = "",
        deadline: str = "",
        tech_stack: list[str] | str | None = None,
        recruiter: str = "",
        posted_at: str = "",
    ) -> dict[str, Any]:
        """Create a new listing markdown file.

        Slug derived from ``derive_listing_slug(company, role, posted_at)``.
        Collisions get a numeric suffix (``-2``, ``-3``, ...) so re-applying
        to the same role does NOT silently overwrite a prior listing.

        Returns:
            ``{slug, path, status, created_at}`` so the caller can navigate
            to the detail view without a second round-trip.

        Raises:
            ValueError: company/role missing OR status invalid (route → 400).
        """
        if not isinstance(company, str) or not company.strip():
            raise ValueError("company is required")
        if not isinstance(role, str) or not role.strip():
            raise ValueError("role is required")
        if not is_valid_listing_status(status):
            raise ValueError(
                f"unknown status {status!r}. Valid: {sorted(LISTING_STATUSES)}"
            )

        # Slug + collision suffix.
        base_slug = derive_listing_slug(company, role, posted_at)
        listings_dir = self._paths.resolve(_LISTINGS_DIR)
        listings_dir.mkdir(parents=True, exist_ok=True)
        slug = base_slug
        suffix = 1
        while (listings_dir / f"{slug}.md").exists():
            suffix += 1
            slug = f"{base_slug}-{suffix}"

        # Normalise tech_stack to a clean list and emit valid inline YAML.
        tech_list = normalize_tech_stack(tech_stack)
        created_at = _now_iso()

        # Escape any embedded quotes / newlines that would break the
        # YAML frontmatter shape. Lightweight — full YAML round-trip via
        # python-frontmatter would be heavier but here every field is a
        # short string so simple replacement suffices.
        def _esc(v: str) -> str:
            return v.replace('"', "'").replace("\n", " ").strip()

        body = LISTING_TEMPLATE.format(
            slug=_esc(slug),
            company=_esc(company),
            role=_esc(role),
            url=_esc(url),
            status=_esc(status),
            source=_esc(source),
            location=_esc(location),
            salary_range=_esc(salary_range),
            deadline=_esc(deadline),
            tech_stack_yaml=_yaml_tech_stack(tech_list),
            recruiter=_esc(recruiter),
            posted_at=_esc(posted_at),
            created_at=created_at,
            jd_body=(raw_jd_text or "").strip()
            or "_No JD body captured. Paste the full job description here._",
        )

        rel = self._listing_path(slug)
        self._writer.write(
            rel,
            body,
            versioned=True,
            trust_reason="career_listing_edit",
        )
        self._log_activity(
            action="career_listing_created",
            summary=f"Career listing created: {company} — {role}",
            importance="medium",
            details={"slug": slug, "company": company, "role": role, "status": status},
        )
        return {"slug": slug, "path": rel, "status": status, "created_at": created_at}

    def update_listing(self, slug: str, **fields: Any) -> dict[str, Any]:
        """Patch listing frontmatter fields (status uses update_listing_status).

        Only fields in ``LISTING_FRONTMATTER_FIELDS`` are accepted — unknown
        keys raise ``KeyError`` (route → 400). Closes route-injection of
        arbitrary metadata.

        Args:
            slug: listing slug (path-injection-validated).
            **fields: subset of LISTING_FRONTMATTER_FIELDS.

        Returns:
            ``{slug, path, updated_fields}``.

        Raises:
            KeyError: invalid slug or unknown field (route → 400/404).
            FileNotFoundError: slug valid but no file (route → 404).
        """
        slug = self._validate_slug(slug)
        # Reject status updates here — they're routed through
        # update_listing_status which maintains the status_history timeline.
        bad_keys = set(fields.keys()) - LISTING_FRONTMATTER_FIELDS
        if "status" in fields:
            raise KeyError(
                "status updates must go through PATCH /api/career/listings/{slug}/status"
            )
        if bad_keys:
            raise KeyError(
                f"unknown listing fields: {sorted(bad_keys)}. "
                f"Allowed: {sorted(LISTING_FRONTMATTER_FIELDS)}"
            )

        rel = self._listing_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}

        updated: dict[str, Any] = {}
        for key, value in fields.items():
            if key == "tech_stack":
                value = normalize_tech_stack(value)
            meta[key] = value
            updated[key] = value

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_listing_edit",
        )
        self._log_activity(
            action="career_listing_updated",
            summary=f"Career listing patched: {slug}",
            importance="low",
            details={"slug": slug, "fields_changed": sorted(updated.keys())},
        )
        return {"slug": slug, "path": rel, "updated_fields": updated}

    def update_listing_status(
        self, slug: str, new_status: str, note: str = "",
    ) -> dict[str, Any]:
        """Move a listing through the pipeline + append to status timeline.

        The status_history list in frontmatter is APPEND-ONLY — every
        transition is preserved for audit (when did "applied" happen? when
        did "rejected" arrive?). Same status as current is a no-op (no
        timeline pollution from accidental re-clicks).

        Raises:
            KeyError: invalid slug / unknown status (route → 400/404).
            FileNotFoundError: slug valid but no file (route → 404).
        """
        slug = self._validate_slug(slug)
        if not is_valid_listing_status(new_status):
            raise KeyError(
                f"unknown status {new_status!r}. Valid: {sorted(LISTING_STATUSES)}"
            )

        rel = self._listing_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        prev_status = str(meta.get("status", "saved"))

        if new_status == prev_status:
            return {
                "slug": slug,
                "path": rel,
                "status": new_status,
                "changed": False,
                "previous_status": prev_status,
            }

        meta["status"] = new_status
        history = meta.get("status_history")
        if not isinstance(history, list):
            history = []
        history.append({
            "status": new_status,
            "at": _now_iso(),
            "note": (note or "").strip(),
        })
        meta["status_history"] = history

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_listing_status_change",
        )
        self._log_activity(
            action="career_listing_status_changed",
            summary=f"Career listing {slug}: {prev_status} → {new_status}",
            importance="medium",
            details={
                "slug": slug,
                "previous_status": prev_status,
                "new_status": new_status,
                "note": (note or "").strip(),
            },
        )
        return {
            "slug": slug,
            "path": rel,
            "status": new_status,
            "previous_status": prev_status,
            "changed": True,
        }

    def delete_listing(self, slug: str) -> dict[str, Any]:
        """Delete a listing by slug. Idempotent.

        Returns:
            ``{deleted: True, slug}`` on real delete.
            ``{deleted: False, slug, reason: "not_found"}`` on idempotent
            no-op (file already gone). Same shape as the wiki article
            delete pattern from CLAUDE.md Rule 18 phantom-cleanup.
        """
        slug = self._validate_slug(slug)
        rel = self._listing_path(slug)
        phys = self._paths.resolve(rel)
        if not phys.is_file():
            return {"deleted": False, "slug": slug, "reason": "not_found"}
        try:
            phys.unlink()
        except OSError as exc:
            raise RuntimeError(f"failed to delete listing {slug}: {exc}") from exc
        self._log_activity(
            action="career_listing_deleted",
            summary=f"Career listing deleted: {slug}",
            importance="medium",
            details={"slug": slug},
        )
        return {"deleted": True, "slug": slug}

    # ==================================================================
    # Applications (Phase 3 Slice B)
    # ==================================================================
    #
    # Architectural decision (locked in night-5): each application is a
    # FOLDER under agntspace-career/applications/{slug}/, NOT a single
    # markdown file. The folder carries metadata.md plus deliverables
    # (cv.docx, cover_letter.docx, jd_analysis.md) added by Phase 3
    # Slice C's CV builder + this slice's JD analyzer.
    #
    # Slug shape: <listing_slug>-app-<NN> with 2-digit zero-padded
    # attempt counter (avoids -app-1 vs -app-10 sort surprise + lets
    # users retry an application against the same listing).
    #
    # status_history is append-only — every transition preserved for
    # audit. The dedicated update_application_status route mutates it;
    # the generic update_application PATCH route refuses to mutate
    # immutable fields (slug, listing_slug, status, created_at,
    # status_history) via APPLICATION_FRONTMATTER_FIELDS allowlist.

    @staticmethod
    def _application_folder(slug: str) -> str:
        """Logical vault path to the application FOLDER."""
        return f"{_APPLICATIONS_DIR}/{slug}"

    @staticmethod
    def _application_metadata_path(slug: str) -> str:
        """Logical vault path to the application's metadata.md FILE."""
        return f"{_APPLICATIONS_DIR}/{slug}/metadata.md"

    def _existing_listing_slugs(self) -> set[str]:
        """Set of slugs that exist as valid listings on disk.

        Used to validate that create_application's listing_slug actually
        points at a real listing. Closes the "create an application
        against a typo'd listing" silent-orphan class.
        """
        listings_dir = self._paths.resolve(_LISTINGS_DIR)
        if not listings_dir.is_dir():
            return set()
        return {p.stem for p in listings_dir.glob("*.md")}

    def _next_application_attempt(self, listing_slug: str) -> int:
        """Find the next free attempt number for a listing.

        Returns 1 if no application exists for this listing; 2 if -app-01
        exists; etc. Caller passes the result to derive_application_slug.
        """
        apps_dir = self._paths.resolve(_APPLICATIONS_DIR)
        if not apps_dir.is_dir():
            return 1
        # Match folders named ``<listing_slug>-app-NN``.
        attempts: list[int] = []
        prefix = f"{listing_slug}-app-"
        for entry in apps_dir.iterdir():
            if not entry.is_dir() or not entry.name.startswith(prefix):
                continue
            suffix = entry.name[len(prefix):]
            try:
                n = int(suffix)
            except ValueError:
                continue
            if n >= 1:
                attempts.append(n)
        return (max(attempts) + 1) if attempts else 1

    def list_applications(
        self,
        *,
        status: str | None = None,
        listing_slug: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        """Return a Rule-20-shaped page of applications.

        Args:
            status: optional filter by preparation pipeline status.
                Invalid status → raises KeyError (route → 400).
            listing_slug: optional filter — return only applications
                targeting this listing. Useful for "how many CV
                versions have I made for X?" queries.
            limit: max items per page. Clamped to [1, 500].
            offset: pagination offset. Clamped to >= 0.

        Returns:
            ``{"items": [ApplicationMeta-as-dict, ...], "total": N, "has_more": bool}``

            ``total`` is the FILTERED total (after status + listing_slug
            filters apply), never ``len(items)`` after slicing.
        """
        if status is not None and not is_valid_application_status(status):
            raise KeyError(
                f"unknown application status {status!r}. "
                f"Valid: {sorted(APPLICATION_STATUSES)}"
            )
        try:
            limit = max(1, min(500, int(limit)))
        except (TypeError, ValueError):
            limit = 100
        try:
            offset = max(0, int(offset))
        except (TypeError, ValueError):
            offset = 0

        apps_dir = self._paths.resolve(_APPLICATIONS_DIR)
        if not apps_dir.is_dir():
            return {"items": [], "total": 0, "has_more": False}

        # Walk folders, read metadata.md from each.
        metas: list[ApplicationMeta] = []
        for entry in sorted(apps_dir.iterdir()):
            if not entry.is_dir():
                continue
            slug = entry.name
            md_path = entry / "metadata.md"
            if not md_path.is_file():
                # Folder exists but metadata.md missing — could be
                # half-created or user-deleted. Skip silently rather
                # than poisoning the list with a broken row.
                continue
            rel = self._application_metadata_path(slug)
            folder_rel = self._application_folder(slug)
            try:
                doc = self._reader.read(rel)
                meta = doc.metadata if isinstance(doc.metadata, dict) else {}
            except Exception as exc:  # noqa: BLE001
                log.warning("Failed to read application %s: %s", rel, exc)
                meta = {}
            assets = meta.get("generated_assets", [])
            if not isinstance(assets, list):
                assets = []
            metas.append(ApplicationMeta(
                slug=slug,
                path=rel,
                folder=folder_rel,
                listing_slug=str(meta.get("listing_slug", "")).strip(),
                status=str(meta.get("status", "draft")).strip() or "draft",
                created_at=str(meta.get("created_at", "")).strip(),
                generated_assets=[str(a) for a in assets if isinstance(a, str)],
            ))

        # Filter by status + listing_slug BEFORE the total count (Rule 20).
        if status is not None:
            metas = [m for m in metas if m.status == status]
        if listing_slug is not None:
            metas = [m for m in metas if m.listing_slug == listing_slug]

        # Sort newest-first by created_at; ties broken by slug for determinism.
        metas.sort(key=lambda m: (m.created_at, m.slug), reverse=True)

        total = len(metas)
        page = metas[offset : offset + limit]
        has_more = offset + len(page) < total
        return {
            "items": [
                {
                    "slug": m.slug,
                    "path": m.path,
                    "folder": m.folder,
                    "listing_slug": m.listing_slug,
                    "status": m.status,
                    "created_at": m.created_at,
                    "generated_assets": list(m.generated_assets),
                }
                for m in page
            ],
            "total": total,
            "has_more": has_more,
        }

    def get_application(self, slug: str) -> dict[str, Any]:
        """Return full body + parsed frontmatter for one application.

        Raises:
            KeyError: invalid slug shape (route → 400).
            FileNotFoundError: valid slug but no metadata.md on disk
                (route → 404).
        """
        slug = self._validate_slug(slug)
        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)  # raises FileNotFoundError naturally
        body = doc.content or ""
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        return {
            "slug": slug,
            "path": rel,
            "folder": self._application_folder(slug),
            "metadata": meta,
            "content": body,
        }

    def create_application(
        self,
        *,
        listing_slug: str,
        status: str = "draft",
    ) -> dict[str, Any]:
        """Create a new application folder + metadata.md for a listing.

        Slug derived from ``derive_application_slug(listing_slug,
        attempt)`` where ``attempt`` is the next free integer for this
        listing (1 if first, 2 if -app-01 exists, etc.). Multiple
        applications to the same listing get distinct folders.

        Returns:
            ``{slug, path, folder, status, created_at, listing_slug}``
            so the caller can navigate to the application detail view
            without a second round-trip.

        Raises:
            ValueError: listing_slug missing/invalid OR status invalid
                OR listing_slug doesn't point at a real listing
                (route → 400).
        """
        if not isinstance(listing_slug, str) or not listing_slug.strip():
            raise ValueError("listing_slug is required")
        listing_slug = listing_slug.strip()
        if not is_valid_application_status(status):
            raise ValueError(
                f"unknown application status {status!r}. "
                f"Valid: {sorted(APPLICATION_STATUSES)}"
            )

        # Confirm the listing actually exists — closes the silent-orphan
        # class where an application is created against a typo'd slug.
        existing = self._existing_listing_slugs()
        if listing_slug not in existing:
            raise ValueError(
                f"listing_slug {listing_slug!r} does not match any existing "
                f"listing on disk"
            )

        attempt = self._next_application_attempt(listing_slug)
        slug = derive_application_slug(listing_slug, attempt=attempt)
        created_at = _now_iso()

        # Materialise the folder + metadata.md.
        apps_dir = self._paths.resolve(_APPLICATIONS_DIR)
        apps_dir.mkdir(parents=True, exist_ok=True)
        app_folder = apps_dir / slug
        app_folder.mkdir(parents=True, exist_ok=True)

        def _esc(v: str) -> str:
            return v.replace('"', "'").replace("\n", " ").strip()

        body = APPLICATION_METADATA_TEMPLATE.format(
            slug=_esc(slug),
            listing_slug=_esc(listing_slug),
            status=_esc(status),
            created_at=created_at,
        )

        rel = self._application_metadata_path(slug)
        self._writer.write(
            rel,
            body,
            versioned=True,
            trust_reason="career_application_edit",
        )
        self._log_activity(
            action="career_application_created",
            summary=f"Career application created for listing {listing_slug}",
            importance="medium",
            details={
                "slug": slug,
                "listing_slug": listing_slug,
                "attempt": attempt,
                "status": status,
            },
        )
        return {
            "slug": slug,
            "path": rel,
            "folder": self._application_folder(slug),
            "listing_slug": listing_slug,
            "status": status,
            "created_at": created_at,
            "attempt": attempt,
        }

    def update_application(self, slug: str, **fields: Any) -> dict[str, Any]:
        """Patch application frontmatter fields (status uses
        ``update_application_status``).

        Only fields in ``APPLICATION_FRONTMATTER_FIELDS`` are accepted —
        unknown fields raise ValueError (route → 400). Immutable fields
        (slug, listing_slug, status, created_at, status_history) are
        rejected by the same allowlist — they're DELIBERATELY excluded
        from the constant so the PATCH route can never bypass the
        dedicated /status route or mutate the audit trail.

        Raises:
            KeyError: invalid slug shape OR metadata.md missing.
            ValueError: unknown / disallowed field in patch body.
        """
        slug = self._validate_slug(slug)
        if not fields:
            raise ValueError("at least one field must be provided in PATCH body")

        unknown = set(fields) - APPLICATION_FRONTMATTER_FIELDS
        if unknown:
            raise ValueError(
                f"unknown / disallowed application fields: {sorted(unknown)}. "
                f"Allowed: {sorted(APPLICATION_FRONTMATTER_FIELDS)}. "
                f"Status changes go through update_application_status; "
                f"slug / listing_slug / created_at / status_history are immutable."
            )

        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}

        # Coerce generated_assets to a clean list of strings.
        for key, value in fields.items():
            if key == "generated_assets":
                if not isinstance(value, list):
                    raise ValueError(
                        f"generated_assets must be a list, got {type(value).__name__}"
                    )
                meta[key] = [str(v) for v in value if isinstance(v, (str, int, float))]
            else:
                meta[key] = value

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_application_edit",
        )
        self._log_activity(
            action="career_application_updated",
            summary=f"Career application updated: {slug}",
            importance="low",
            details={"slug": slug, "fields": sorted(fields.keys())},
        )
        return {
            "slug": slug,
            "path": rel,
            "folder": self._application_folder(slug),
            "fields_updated": sorted(fields.keys()),
        }

    def update_application_status(
        self, slug: str, new_status: str, note: str = "",
    ) -> dict[str, Any]:
        """Move an application through the preparation pipeline + append
        to status timeline.

        The status_history list in frontmatter is APPEND-ONLY — every
        transition preserved for audit. Same-status transition is a
        no-op (no timeline pollution from accidental re-clicks).

        Raises:
            KeyError: invalid slug / unknown status (route → 400/404).
            FileNotFoundError: slug valid but no metadata.md (route → 404).
        """
        slug = self._validate_slug(slug)
        if not is_valid_application_status(new_status):
            raise KeyError(
                f"unknown application status {new_status!r}. "
                f"Valid: {sorted(APPLICATION_STATUSES)}"
            )

        rel = self._application_metadata_path(slug)
        doc = self._reader.read(rel)
        meta = dict(doc.metadata) if isinstance(doc.metadata, dict) else {}
        prev_status = str(meta.get("status", "draft"))

        if new_status == prev_status:
            return {
                "slug": slug,
                "path": rel,
                "status": new_status,
                "changed": False,
                "previous_status": prev_status,
            }

        meta["status"] = new_status
        history = meta.get("status_history")
        if not isinstance(history, list):
            history = []
        history.append({
            "status": new_status,
            "at": _now_iso(),
            "note": (note or "").strip(),
        })
        meta["status_history"] = history

        new_content = frontmatter.dumps(frontmatter.Post(doc.content or "", **meta))
        self._writer.write(
            rel,
            new_content,
            versioned=True,
            trust_reason="career_application_status_change",
        )
        self._log_activity(
            action="career_application_status_changed",
            summary=f"Career application {slug}: {prev_status} → {new_status}",
            importance="medium",
            details={
                "slug": slug,
                "previous_status": prev_status,
                "new_status": new_status,
                "note": (note or "").strip(),
            },
        )
        return {
            "slug": slug,
            "path": rel,
            "status": new_status,
            "previous_status": prev_status,
            "changed": True,
        }

    def delete_application(self, slug: str) -> dict[str, Any]:
        """Delete an application FOLDER by slug. Idempotent.

        Removes the entire ``applications/{slug}/`` directory including
        all generated deliverables (cv.docx, cover_letter.docx,
        jd_analysis.md). The user's choice to delete an application is
        a clean wipe — the deliverables are derived from the listing +
        facts, so they can always be regenerated.

        Returns:
            ``{deleted: True, slug, removed_files: [...]}`` on real delete.
            ``{deleted: False, slug, reason: "not_found"}`` on idempotent
            no-op (folder already gone). Same Rule 18 phantom-cleanup
            shape as delete_listing.
        """
        slug = self._validate_slug(slug)
        folder = self._paths.resolve(self._application_folder(slug))
        if not folder.is_dir():
            return {"deleted": False, "slug": slug, "reason": "not_found"}
        # Collect the file inventory BEFORE delete so the activity event
        # carries it (audit value — "you deleted these assets").
        removed_files: list[str] = []
        try:
            for entry in folder.rglob("*"):
                if entry.is_file():
                    removed_files.append(entry.relative_to(folder).as_posix())
        except OSError:
            pass
        try:
            import shutil
            shutil.rmtree(folder)
        except OSError as exc:
            raise RuntimeError(
                f"failed to delete application folder {slug}: {exc}"
            ) from exc
        self._log_activity(
            action="career_application_deleted",
            summary=f"Career application deleted: {slug}",
            importance="medium",
            details={"slug": slug, "removed_files": removed_files},
        )
        return {"deleted": True, "slug": slug, "removed_files": removed_files}
