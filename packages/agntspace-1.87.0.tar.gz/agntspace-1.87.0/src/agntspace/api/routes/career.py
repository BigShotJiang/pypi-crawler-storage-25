"""Career API — Phase 1: facts CRUD.

Surfaces the ``CareerService`` over HTTP. The UI's FactsPage drives every
mutating call through ``PUT /api/career/facts/{category}``; reads come
through ``GET /api/career/facts`` (list) and ``GET /api/career/facts/{category}``
(full body).

Phase 2+ will add listings + applications + CV generation routes to this
same router. Phase 1 deliberately keeps the surface small.

Activity middleware classifications live in
[api/activity_middleware.py](../activity_middleware.py). Per Rule 19 the
mutating PUT route ships with a workflow test from day one
(``tests/e2e/workflows/test_career_facts_workflow.py``).
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

log = logging.getLogger(__name__)

router = APIRouter(prefix="/career", tags=["career"])


def _service(request: Request):
    svc = getattr(request.app.state, "career", None)
    if svc is None:
        raise HTTPException(
            status_code=503,
            detail={
                "error": "career_service_not_wired",
                "message": (
                    "CareerService is not attached to the running app. "
                    "This is a server-config issue, not a user error."
                ),
            },
        )
    return svc


# ────────────────────────────────────────────────────────────────────
# Request models
# ────────────────────────────────────────────────────────────────────
class FactUpdateRequest(BaseModel):
    """Body for PUT /api/career/facts/{category}.

    The full document (frontmatter + body) is sent as ``content``.
    Server auto-stamps ``last_updated`` before persisting.
    """
    content: str = Field(..., description="Full markdown document (frontmatter + body).")


# ────────────────────────────────────────────────────────────────────
# Read routes
# ────────────────────────────────────────────────────────────────────
@router.get("/facts")
async def list_facts(request: Request) -> dict[str, Any]:
    """Return per-category summary for all 6 fact categories.

    Always returns 6 entries in canonical order regardless of scaffolding
    state — categories with no file on disk return ``exists=False`` so the
    UI can render a consistent "needs setup" affordance.
    """
    svc = _service(request)
    items = svc.list_facts()
    return {
        # Rule 20: even though this list is bounded-by-domain (6 entries
        # always), shipping a structured shape keeps future expansion
        # (e.g. multi-profile) clean.
        "items": [
            {
                "category": fm.category,
                "path": fm.path,
                "exists": fm.exists,
                "size_bytes": fm.size_bytes,
                "last_updated": fm.last_updated,
                "is_empty": fm.is_empty,
            }
            for fm in items
        ],
        "total": len(items),
        # arch:bounded-by-domain — FACT_CATEGORIES is a closed enum of 6;
        # the list is exhaustive by construction, never paginated.
        "has_more": False,
    }


@router.get("/facts/{category}")
async def get_fact(category: str, request: Request) -> dict[str, Any]:
    """Return the full body + parsed frontmatter for one category.

    404 when:
      - ``category`` is not a valid FACT_CATEGORIES slug (path injection
        guard via the service's KeyError).
      - ``category`` is valid but no file exists yet (scaffolding never
        ran for it, or the user deleted it from the file system).
    """
    svc = _service(request)
    try:
        return svc.get_fact(category)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "unknown_career_fact_category",
                "message": str(exc),
            },
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "career_fact_not_scaffolded",
                "category": category,
                "message": (
                    f"Category {category!r} is valid but no file exists at "
                    f"career/facts/{category}.md. Re-run vault init or "
                    f"recreate the file via PUT /api/career/facts/{category}."
                ),
            },
        ) from exc


# ────────────────────────────────────────────────────────────────────
# Write routes
# ────────────────────────────────────────────────────────────────────
@router.put("/facts/{category}")
async def update_fact(category: str, payload: FactUpdateRequest, request: Request) -> dict[str, Any]:
    """Replace a fact file's content.

    Returns:
        Updated FactMeta dict (category, path, exists, size_bytes,
        last_updated, is_empty) so the UI can show the new timestamp +
        size without a second round-trip.

    Errors:
        400: ``content`` is empty / whitespace-only (the FactsPage editor
             guards against this client-side, but the server enforces too).
        404: invalid category slug.
    """
    svc = _service(request)
    try:
        fm = svc.update_fact(category, payload.content)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "unknown_career_fact_category",
                "message": str(exc),
            },
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "invalid_career_fact_content",
                "message": str(exc),
            },
        ) from exc

    return {
        "category": fm.category,
        "path": fm.path,
        "exists": fm.exists,
        "size_bytes": fm.size_bytes,
        "last_updated": fm.last_updated,
        "is_empty": fm.is_empty,
    }


# ════════════════════════════════════════════════════════════════════
# Phase 2 — Listings (job announcements) routes
# ════════════════════════════════════════════════════════════════════


class ListingCreateRequest(BaseModel):
    """Body for POST /api/career/listings.

    company + role are required. Everything else is optional — paste-JD-text
    workflow fills `raw_jd_text`; URL-paste flow fills `url` + uses the
    extracted page title for `role`. Phase 2.5 will add URL fetch + parse;
    for now the user fills fields manually.
    """
    company: str = Field(..., min_length=1)
    role: str = Field(..., min_length=1)
    url: str = ""
    raw_jd_text: str = ""
    status: str = "saved"
    source: str = "manual"  # manual | linkedin | indeed | direct | referral | screenshot
    location: str = ""
    salary_range: str = ""
    deadline: str = ""
    tech_stack: list[str] | str | None = None
    recruiter: str = ""
    posted_at: str = ""


class ListingPatchRequest(BaseModel):
    """Body for PATCH /api/career/listings/{slug}.

    Subset of LISTING_FRONTMATTER_FIELDS — status MUST go through the
    dedicated /status route so the timeline log stays append-only.
    All fields optional; the route patches whatever is present.
    """
    company: str | None = None
    role: str | None = None
    url: str | None = None
    source: str | None = None
    location: str | None = None
    salary_range: str | None = None
    deadline: str | None = None
    tech_stack: list[str] | str | None = None
    recruiter: str | None = None
    posted_at: str | None = None


class ListingStatusRequest(BaseModel):
    """Body for PATCH /api/career/listings/{slug}/status."""
    new_status: str = Field(..., min_length=1)
    note: str = ""


# ── Read routes ────────────────────────────────────────────────────


@router.get("/listings")
async def list_listings(
    request: Request,
    status: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict[str, Any]:
    """List job listings. Rule 20 shape: {items, total, has_more}.

    Query params:
        status: optional filter (saved | applied | interviewing | offer |
            rejected | declined | withdrawn). 400 on unknown status.
        limit: max items per page. Clamped server-side to [1, 500].
        offset: pagination offset.
    """
    svc = _service(request)
    try:
        return svc.list_listings(status=status, limit=limit, offset=offset)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "unknown_listing_status", "message": str(exc)},
        ) from exc


@router.get("/listings/{slug}")
async def get_listing(slug: str, request: Request) -> dict[str, Any]:
    """Return full body + parsed frontmatter for one listing.

    404 on unknown slug shape (path-injection guard) OR on missing file.
    """
    svc = _service(request)
    try:
        return svc.get_listing(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "invalid_listing_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "listing_not_found",
                "slug": slug,
                "message": str(exc),
            },
        ) from exc


# ── Write routes ───────────────────────────────────────────────────


@router.post("/listings")
async def create_listing(
    payload: ListingCreateRequest, request: Request
) -> dict[str, Any]:
    """Create a new job listing. Returns slug + path for UI navigation.

    400 on invalid status / missing company / missing role.
    """
    svc = _service(request)
    try:
        return svc.create_listing(
            company=payload.company,
            role=payload.role,
            url=payload.url,
            raw_jd_text=payload.raw_jd_text,
            status=payload.status,
            source=payload.source,
            location=payload.location,
            salary_range=payload.salary_range,
            deadline=payload.deadline,
            tech_stack=payload.tech_stack,
            recruiter=payload.recruiter,
            posted_at=payload.posted_at,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_listing_input", "message": str(exc)},
        ) from exc


@router.patch("/listings/{slug}/status")
async def update_listing_status(
    slug: str, payload: ListingStatusRequest, request: Request
) -> dict[str, Any]:
    """Move a listing through the pipeline.

    Body: ``{new_status, note?}``. Appends to the status_history timeline
    so every transition is preserved for audit. Same-status transitions
    are no-ops with ``changed: false`` so accidental re-clicks don't
    pollute the timeline.

    400 on unknown status. 404 on unknown slug.
    """
    svc = _service(request)
    try:
        return svc.update_listing_status(slug, payload.new_status, payload.note)
    except KeyError as exc:
        # Two cases collapse here: invalid slug shape OR invalid status.
        # The error message distinguishes them; route returns 400 either
        # way since both are user-supplied input violations.
        msg = str(exc)
        if "slug" in msg.lower():
            raise HTTPException(
                status_code=404,
                detail={"error": "invalid_listing_slug", "message": msg},
            ) from exc
        raise HTTPException(
            status_code=400,
            detail={"error": "unknown_listing_status", "message": msg},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "listing_not_found",
                "slug": slug,
                "message": str(exc),
            },
        ) from exc


@router.patch("/listings/{slug}")
async def update_listing(
    slug: str, payload: ListingPatchRequest, request: Request
) -> dict[str, Any]:
    """Patch listing frontmatter fields. Status uses /status route.

    Only fields present in the body (non-None) are patched — undefined
    fields are preserved. 400 on unknown field keys (shouldn't reach the
    service since Pydantic validates the body shape, but the service has
    its own defence). 404 on unknown slug.
    """
    svc = _service(request)
    # Filter to only fields the user set — Pydantic returns None for
    # absent fields, but we don't want to overwrite frontmatter with None.
    fields = {
        k: v
        for k, v in payload.model_dump(exclude_unset=True).items()
        if v is not None
    }
    if not fields:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "no_fields_to_patch",
                "message": "PATCH body must include at least one non-null field.",
            },
        )
    try:
        return svc.update_listing(slug, **fields)
    except KeyError as exc:
        msg = str(exc)
        if "slug" in msg.lower():
            raise HTTPException(
                status_code=404,
                detail={"error": "invalid_listing_slug", "message": msg},
            ) from exc
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_listing_field", "message": msg},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={
                "error": "listing_not_found",
                "slug": slug,
                "message": str(exc),
            },
        ) from exc


@router.delete("/listings/{slug}")
async def delete_listing(slug: str, request: Request) -> dict[str, Any]:
    """Idempotent delete. Returns ``{deleted, slug}`` where ``deleted``
    is False if the file was already gone (Rule 18 phantom-cleanup shape)."""
    svc = _service(request)
    try:
        return svc.delete_listing(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "invalid_listing_slug", "message": str(exc)},
        ) from exc


# ── URL → listing import (Phase 2.5) ─────────────────────────────────────


class ListingFromUrlRequest(BaseModel):
    """Body for ``POST /api/career/listings/from-url``."""

    url: str = Field(..., min_length=1, description="The JD URL to fetch.")
    status: str = Field("saved", description="Initial pipeline status.")


@router.post("/listings/from-url")
async def create_listing_from_url(
    payload: ListingFromUrlRequest, request: Request,
) -> dict[str, Any]:
    """Fetch ``payload.url`` + LLM-extract a structured JD + create a listing.

    Phase 2.5 — the user-facing surface for the "I have a JD URL, save it"
    workflow. Backend chain:

    1. ``fetch_url_text`` — URL safety gate + 30s timeout + 4 MB cap +
       content-type check. Failures return empty text; route raises 502.
    2. ``extract_job_via_llm`` — capable-tier LLM extraction into a
       structured ``ExtractedJob``. JSON-output, anti-fabrication rules
       baked into the prompt.
    3. ``CareerService.create_listing`` — writes the listing markdown +
       seeds status_history.

    Returns the same shape as ``POST /api/career/listings`` so the UI
    can navigate directly to the created listing.

    HTTP codes:
    - 200: listing created. Body includes ``slug``, ``path``, ``status``,
      ``created_at``, ``extracted`` (the structured fields populated by
      the LLM — UI can render a preview of what was extracted).
    - 422 (Pydantic): ``url`` missing or empty.
    - 502: URL safety reject / unreachable / oversized / wrong content
      type / empty text after HTML strip.
    - 503: extraction insufficient (company OR role missing from LLM
      output). Returns a structured detail so the UI can offer the user
      a chance to paste the JD body manually instead.
    - 503: career service / agent / skill loader not wired.
    """
    svc = _service(request)
    agent = getattr(request.app.state, "agent", None)
    if agent is None:
        raise HTTPException(
            status_code=503,
            detail={"error": "agent_unavailable",
                    "message": "Agent service is not wired."},
        )
    skill_loader = getattr(request.app.state, "skills", None)

    try:
        from agntspace.career.jd_extract import extract_job_from_url
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail={"error": "jd_extract_unavailable",
                    "message": f"JD extractor unavailable: {exc}"},
        ) from exc

    url = payload.url.strip()
    if not url:
        raise HTTPException(
            status_code=422,
            detail={"error": "empty_url", "message": "url is required"},
        )

    try:
        job = await extract_job_from_url(
            url, agent=agent, skill_loader=skill_loader,
        )
    except Exception as exc:
        log.exception("create_listing_from_url: extraction crashed for %s", url)
        raise HTTPException(
            status_code=502,
            detail={"error": "extraction_crashed", "message": str(exc)},
        ) from exc

    if not job.has_minimum_fields:
        # Pipeline ran cleanly but produced too little to act on. Could
        # be: URL unreachable, content-type rejected, LLM returned empty
        # fields. Return what we DO have so the UI can pre-fill a manual
        # form.
        raise HTTPException(
            status_code=502,
            detail={
                "error": "extraction_insufficient",
                "message": (
                    "Could not extract company AND role from the URL. "
                    "Try pasting the JD text manually."
                ),
                "url": url,
                "extracted": {
                    "company": job.company,
                    "role": job.role,
                    "location": job.location,
                    "body_chars": len(job.body),
                },
            },
        )

    kwargs = job.to_listing_kwargs()
    # Caller-supplied status override (default `saved` is correct for
    # most imports; some flows want `applied` straight away).
    if payload.status and isinstance(payload.status, str):
        kwargs["status"] = payload.status.strip() or "saved"

    try:
        result = svc.create_listing(**kwargs)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_listing_input", "message": str(exc)},
        ) from exc

    # Augment the response with the LLM-extracted preview so the UI can
    # show what fields were captured.
    if isinstance(result, dict):
        result["extracted"] = {
            "company": job.company,
            "role": job.role,
            "location": job.location,
            "salary_range": job.salary_range,
            "deadline": job.deadline,
            "tech_stack": list(job.tech_stack),
            "recruiter": job.recruiter,
            "posted_at": job.posted_at,
            "source_url": job.source_url,
        }
    return result


# ── Applications routes (Phase 3 Slice B) ────────────────────────────────


class ApplicationCreateRequest(BaseModel):
    """Body for ``POST /api/career/applications``."""

    listing_slug: str = Field(..., min_length=1, description="The listing slug this application targets.")
    status: str = Field("draft", description="Initial preparation-pipeline status.")


class ApplicationStatusRequest(BaseModel):
    """Body for ``PATCH /api/career/applications/{slug}/status``."""

    new_status: str = Field(..., min_length=1, description="One of APPLICATION_STATUSES.")
    note: str = Field("", description="Optional note for the status_history entry.")


class ApplicationUpdateRequest(BaseModel):
    """Body for ``PATCH /api/career/applications/{slug}``.

    Free-form dict; the service validates against APPLICATION_FRONTMATTER_FIELDS
    and rejects unknown / immutable fields with 400.
    """

    generated_assets: list[str] | None = Field(
        default=None,
        description="Append to the list of generated deliverables (cv.docx, jd_analysis.md, etc.).",
    )


@router.post("/applications")
async def create_application(
    payload: ApplicationCreateRequest, request: Request,
) -> dict[str, Any]:
    """Create a new application folder + metadata.md for a listing.

    The slug is derived as ``<listing_slug>-app-<NN>`` with auto-
    incremented attempt counter so multiple applications to the same
    listing get distinct folders (retries / revisions).

    Returns the standard ``{slug, path, folder, listing_slug, status,
    created_at, attempt}`` shape so the UI can navigate to the
    application detail view without a second round-trip.

    400 codes:
    - missing listing_slug, invalid status, or listing_slug doesn't
      match an existing listing on disk.
    """
    svc = _service(request)
    try:
        return svc.create_application(
            listing_slug=payload.listing_slug,
            status=payload.status,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_input", "message": str(exc)},
        ) from exc


@router.get("/applications")
async def list_applications(
    request: Request,
    status: str | None = None,
    listing_slug: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict[str, Any]:
    """Rule-20 paged list of applications.

    Query params:
    - ``status``: optional pipeline-status filter (one of
      APPLICATION_STATUSES). Invalid → 400.
    - ``listing_slug``: optional filter — "how many CV versions have I
      made for X?" — return only applications targeting this listing.
    - ``limit``, ``offset``: pagination (limit clamped to [1, 500]).
    """
    svc = _service(request)
    try:
        return svc.list_applications(
            status=status,
            listing_slug=listing_slug,
            limit=limit,
            offset=offset,
        )
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_filter", "message": str(exc)},
        ) from exc


@router.get("/applications/{slug}")
async def get_application(slug: str, request: Request) -> dict[str, Any]:
    """Return the full application metadata + body."""
    svc = _service(request)
    try:
        return svc.get_application(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc


@router.patch("/applications/{slug}/status")
async def update_application_status(
    slug: str, payload: ApplicationStatusRequest, request: Request,
) -> dict[str, Any]:
    """Move an application through the preparation pipeline (draft →
    preparing → submitted → withdrawn). The status_history list in
    frontmatter gets a new append-only entry on every transition.
    """
    svc = _service(request)
    try:
        return svc.update_application_status(slug, payload.new_status, note=payload.note)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_status", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc


@router.patch("/applications/{slug}")
async def update_application(
    slug: str, payload: ApplicationUpdateRequest, request: Request,
) -> dict[str, Any]:
    """Patch application frontmatter fields (status uses the dedicated
    ``/status`` route — patching ``status`` here is rejected by the
    service-level allowlist with 400).

    Only fields in ``APPLICATION_FRONTMATTER_FIELDS`` are accepted —
    today that's only ``generated_assets``. Immutable fields (slug,
    listing_slug, status, created_at, status_history) are not patchable
    through this route.
    """
    svc = _service(request)
    # Build kwargs from the Pydantic body — only include explicitly-set fields.
    fields: dict[str, Any] = {}
    if payload.generated_assets is not None:
        fields["generated_assets"] = payload.generated_assets
    if not fields:
        raise HTTPException(
            status_code=400,
            detail={
                "error": "empty_application_patch",
                "message": "PATCH body must include at least one allowed field. "
                           "Use /status route for status changes.",
            },
        )
    try:
        return svc.update_application(slug, **fields)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=404,
            detail={"error": "application_not_found", "message": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_field", "message": str(exc)},
        ) from exc


@router.delete("/applications/{slug}")
async def delete_application(slug: str, request: Request) -> dict[str, Any]:
    """Idempotent delete of an application folder (Rule 18
    phantom-cleanup shape).

    Wipes the entire ``applications/{slug}/`` directory including all
    generated deliverables. Returns ``{deleted: False, slug, reason:
    "not_found"}`` for a folder that's already gone — safe to retry.
    """
    svc = _service(request)
    try:
        return svc.delete_application(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=400,
            detail={"error": "invalid_application_slug", "message": str(exc)},
        ) from exc
