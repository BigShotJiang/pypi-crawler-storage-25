"""AgntSpace CLI — full command suite.

All commands that need a running server call the REST API over HTTP.
Lifecycle commands (init, start) run directly.
"""

from __future__ import annotations

import asyncio
import json
import os
import tomllib
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="agntspace",
    help="Personal AI agent that runs your life alongside you.",
    no_args_is_help=True,
)
console = Console()


def _get_base_url() -> str:
    from agntspace.infra.config import get_settings
    s = get_settings()
    return f"http://{s.host}:{s.port}"


def _check_server(base_url: str) -> bool:
    import httpx
    try:
        httpx.get(f"{base_url}/api/health", timeout=3)
        return True
    except httpx.ConnectError:
        console.print(f"[red]Server not running at {base_url}[/red]")
        console.print("Start it with: [bold]agntspace start[/bold]")
        return False


def _get(path: str, params: dict | None = None, timeout: int = 10) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.get(f"{base}{path}", params=params, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def _post(
    path: str,
    data: dict | None = None,
    timeout: int = 30,
    *,
    params: dict | None = None,
) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.post(f"{base}{path}", json=data, params=params, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def _put(path: str, data: dict | None = None, timeout: int = 10) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.put(f"{base}{path}", json=data, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def _delete(path: str, timeout: int = 10) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.delete(f"{base}{path}", timeout=timeout)
    resp.raise_for_status()
    return resp.json()


# ═══════════════════════════════════════════
# LIFECYCLE
# ═══════════════════════════════════════════


def _should_show_ollama_install_hint(
    *,
    mode: str,
    reachable: bool,
    ollama_on_path: bool,
) -> bool:
    """Pure decision: show the "Ollama not installed" banner hint iff
    local mode is configured AND Ollama isn't reachable AND it isn't on
    PATH (so the lifespan auto-start can't help — the user genuinely
    needs to install it).

    When ``ollama`` IS on PATH but not yet running, the banner stays
    SILENT because the lifespan calls ``ensure_ollama_running()`` which
    spawns the daemon and waits up to 30s. Showing a "not reachable"
    warning here would be a lie that becomes false ~30s later — exactly
    the false-alarm UX the user reported on 2026-05-12.

    Lifted out of ``start()`` for unit-testable shape — the inlined
    socket probe + shutil.which call inside start() now feed the
    booleans into this helper.
    """
    if mode != "local":
        return False
    if reachable:
        return False
    return not ollama_on_path


def _try_reclaim_port(host: str, port: int) -> bool:
    """Refuse to kill any process holding the port.

    Architectural decision (2026-04-25): we no longer probe-then-kill.
    The previous design had three failure modes that compounded into a
    crash loop:

      1. The /api/health probe used to require a substring match on
         "agntspace" in the response body — a string that never appears
         in /api/health. EVERY healthy server failed the check and was
         taskkill'd by the next launch attempt.
      2. Even after the substring bug was fixed to look for HTTP/1.x 200,
         a server busy with the graph build (loop.run_in_executor on
         the default ThreadPoolExecutor) couldn't respond within the
         18s retry budget and was killed mid-build.
      3. The killed server's incomplete graph build never persisted
         build_index.json, so the next boot did another full rebuild
         from scratch — which got killed by the next launch attempt.

    Across one afternoon of debugging this produced 48+ Python PIDs in
    24 hours with ZERO actual crashes in errors.log. Every "death" was
    self-inflicted by the launcher's reclaim logic.

    The right behavior is what every other long-running server does:
    if the port is busy, abort the new launch with a clear message.
    The user decides whether to ``agntspace stop`` the existing one,
    open it, or pick a different port. We never destroy work that
    another process is doing.

    Returns False unconditionally.
    """
    import subprocess
    import sys

    # Identify the port holder so we can show a useful message — but
    # never act on it.
    pid: int | None = None
    try:
        if sys.platform == "win32":
            out = subprocess.check_output(
                ["netstat", "-ano"], text=True, stderr=subprocess.DEVNULL,
            )
            for line in out.splitlines():
                if f":{port}" in line and "LISTENING" in line:
                    try:
                        pid = int(line.strip().split()[-1])
                        break
                    except ValueError:
                        pass
        else:
            out = subprocess.check_output(
                ["lsof", "-ti", f"tcp:{port}", "-sTCP:LISTEN"],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
            if out:
                try:
                    pid = int(out.splitlines()[0])
                except ValueError:
                    pass
    except Exception:
        pid = None

    pid_str = f" (PID {pid})" if pid is not None else ""
    console.print(
        f"\n  [bold yellow]A server is already running on http://{host}:{port}{pid_str}.[/]\n"
        f"  [dim]This launcher will NOT kill it — running servers are off-limits to\n"
        f"  prevent the crash-loop pattern where two launchers race to take the\n"
        f"  port and each kill the other before the graph build completes.[/]\n\n"
        f"  Open it:    [bold]http://{host}:{port}[/]\n"
        f"  Stop it:    [bold]agntspace stop[/]\n"
        f"  Or pick a different port:    [bold]agntspace start --port 8001[/]\n"
    )
    return False


# arch:deterministic — supervisor crash-loop break thresholds. Tuned
# conservatively: 5 unclean exits in a 5-minute window means something
# is fundamentally broken (config, missing dep, code crash on every
# boot) and respawning would just burn CPU + log spam.
_SUPERVISOR_MAX_CRASHES_IN_WINDOW = 5
_SUPERVISOR_CRASH_WINDOW_SECONDS = 300.0
# Backoff schedule between respawns. Each crash bumps the index;
# crashes > schedule length use the last value. Total time from
# crash 1 to crash 5 = 1+2+5+10+30 = 48s — slow enough to let a
# transient cause clear, fast enough that the user notices a working
# restart on a flaky boot.
_SUPERVISOR_BACKOFF_SCHEDULE = (1, 2, 5, 10, 30)


def _supervisor_log_path() -> Path:
    """Path to the supervisor's append-only event log.

    Lives in ``app_dir/logs/supervisor.log``. Each respawn / crash /
    clean-exit appends one JSON line so ``agntspace why-down`` (chunk 5)
    can show "the launcher restarted the server N times in the last hour
    because of <reason>". Separate from agntspace.log because that's
    the SERVER's log; this is the LAUNCHER's. They live and die on
    different lifecycles.
    """
    from agntspace.infra.config import get_settings

    return get_settings().log_dir / "supervisor.log"


def _supervisor_record_event(event: dict) -> None:
    """Append a single supervisor event as a JSON line. Never raises."""
    import json as _json
    import time as _time

    try:
        path = _supervisor_log_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        line = _json.dumps({"ts": _time.time(), **event}, default=str) + "\n"
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(line)
    except Exception:  # noqa: BLE001 — logging must never break supervision
        pass


def _run_supervised(*, host: str, port: int) -> None:
    """Run the server as a child subprocess, auto-respawn on unclean exit.

    Default path for ``agntspace start``. Closes the "more down than up"
    reliability gap (2026-05-05): in-process diagnostics catch crashes
    that have a Python traceback, but external death (SIGKILL, OOM,
    Task Manager → End Task, accidental terminal close) leaves the
    server gone with no Python code to log it. The launcher is the
    external supervisor.

    Behaviour:

    * Spawn ``agntspace start --no-supervise`` as a child via
      ``subprocess.Popen``. The child runs the legacy inline path —
      uvicorn + browser thread + lifespan, exactly as before.
    * Wait for the child via ``Popen.wait()``. On clean exit (rc=0),
      the supervisor also exits cleanly.
    * On Ctrl-C in the launcher's terminal, both parent and child get
      SIGINT (POSIX process group / Windows console group). The launcher
      catches KeyboardInterrupt, breaks the loop, and exits 130. The
      child should also have exited from its own SIGINT handling.
    * On unclean exit (rc != 0): record the crash, check the budget,
      sleep backoff, respawn. After ``max_crashes`` unclean exits in
      ``crash_window`` seconds: print a clear "give up" message and
      exit 1 so external supervisors (Task Scheduler, systemd) see
      the failure and decide policy.

    NOT supervised: ``--reload`` mode (uvicorn's own reload would race),
    ``--no-supervise`` mode (legacy/debugging), and the env-var override
    ``AGNTSPACE_NO_SUPERVISE=1`` (for daemon callers that wrap their
    own external supervisor and don't want a nested one).
    """
    import os as _os
    import subprocess as _subprocess
    import sys as _sys
    import time as _time
    from collections import deque

    # Build the child invocation — same args MINUS --supervise so the
    # child runs the inline path. Use the same Python interpreter +
    # the agntspace module entrypoint so we don't depend on the
    # console_scripts shim being on PATH.
    cmd = [
        _sys.executable, "-m", "agntspace", "start",
        "--host", host, "--port", str(port),
        "--no-supervise",
    ]

    crash_times: deque[float] = deque()
    boot_count = 0

    _supervisor_record_event({
        "kind": "supervisor_start",
        "pid": _os.getpid(),
        "host": host,
        "port": port,
        "max_crashes": _SUPERVISOR_MAX_CRASHES_IN_WINDOW,
        "window_seconds": _SUPERVISOR_CRASH_WINDOW_SECONDS,
    })

    while True:
        boot_count += 1
        # Set an env var so the child knows it's a supervised child —
        # tests can inspect this; future code can branch on it.
        env = dict(_os.environ)
        env["AGNTSPACE_SUPERVISED_CHILD"] = "1"
        # Defense-in-depth: even though we pass --no-supervise, the
        # env var stops a bug where flag parsing drops the value.
        env["AGNTSPACE_NO_SUPERVISE"] = "1"

        # 2026-05-13 — supervisor crash-loop fix: when this CLI is itself
        # launched via ``pythonw.exe`` (no console — typical for scheduled
        # tasks + service installers), the parent has no console handles
        # for the child to inherit. Children inheriting stdout/stderr that
        # point at "nothing" silently fail on the first ``print(...,
        # flush=True)`` call, causing rc=1 within ~3 seconds before any
        # logging is configured. The supervisor saw repeated rc=1 crashes
        # and went into crash-loop break after 5 attempts.
        #
        # Fix: when the parent has broken stdio (sys.stdout/err is None,
        # detached, or closed — which is exactly the pythonw case), redirect
        # the child's stdio to the OS null device. The child uses structured
        # logging to ``~/.agntspace/logs/agntspace.log`` for everything that
        # matters; the missing banner / Press-Ctrl+C print is acceptable
        # cost under pythonw-without-console anyway.
        #
        # Detection is intentionally conservative: only redirect when stdio
        # is genuinely broken. In normal terminal launches (the path most
        # users hit), the child keeps inheriting stdout/err and prints the
        # banner as before.
        def _parent_has_broken_stdio() -> bool:
            for stream in (_sys.stdout, _sys.stderr):
                if stream is None:
                    return True
                try:
                    # pythonw streams typically lack a fileno() OR the
                    # fileno is invalid (-1 / negative on Windows).
                    fno = stream.fileno()
                except (AttributeError, OSError, ValueError):
                    return True
                if fno is None or fno < 0:
                    return True
            return False

        popen_kwargs: dict[str, object] = {"env": env}
        if _parent_has_broken_stdio():
            # Send child stdio to OS null so first banner print doesn't
            # raise OSError on the nul-equivalent inherited handle. The
            # child still writes structured logs to disk — full observability
            # preserved.
            popen_kwargs["stdout"] = _subprocess.DEVNULL
            popen_kwargs["stderr"] = _subprocess.DEVNULL
            popen_kwargs["stdin"] = _subprocess.DEVNULL

        try:
            proc = _subprocess.Popen(cmd, **popen_kwargs)
        except Exception as exc:  # noqa: BLE001
            _supervisor_record_event({
                "kind": "spawn_failed",
                "error": str(exc)[:500],
                "boot_count": boot_count,
            })
            console.print(f"[red]Supervisor: failed to spawn child: {exc}[/]")
            _sys.exit(1)

        _supervisor_record_event({
            "kind": "child_spawned",
            "child_pid": proc.pid,
            "boot_count": boot_count,
        })

        try:
            rc = proc.wait()
        except KeyboardInterrupt:
            # Ctrl-C in the launcher's terminal. The child should also
            # have received SIGINT (process group on POSIX, console
            # group on Windows). Wait briefly for it to clean up; then
            # exit cleanly.
            _supervisor_record_event({
                "kind": "supervisor_interrupted",
                "child_pid": proc.pid,
            })
            try:
                proc.wait(timeout=10)
            except _subprocess.TimeoutExpired:
                # Child didn't honor SIGINT — give it SIGTERM, then
                # SIGKILL if still alive.
                try:
                    proc.terminate()
                    proc.wait(timeout=3)
                except _subprocess.TimeoutExpired:
                    proc.kill()
                except Exception:  # noqa: BLE001
                    pass
            console.print("\n  [dim]Supervisor: interrupted by user, exiting.[/]")
            _sys.exit(130)

        # ── Exit-code classification ────────────────────────────────
        # rc == 0 → clean exit. Supervisor also exits.
        # rc == 2 → vault-lock-busy / port-in-use (config issue, not
        #           a crash — DON'T respawn into the same wall).
        # rc < 0  → terminated by signal (POSIX). Could be SIGTERM
        #           from an external supervisor — DON'T respawn.
        # rc otherwise → treat as a crash, count + maybe respawn.
        if rc == 0:
            _supervisor_record_event({
                "kind": "child_exited_clean",
                "child_pid": proc.pid,
                "boot_count": boot_count,
            })
            return

        if rc == 2:
            console.print(
                "\n  [yellow]Supervisor: child exited with rc=2 "
                "(config/lock issue) — NOT respawning. Resolve via "
                "'agntspace ps' / 'agntspace stop' and try again.[/]\n"
            )
            _supervisor_record_event({
                "kind": "child_config_error",
                "rc": rc,
                "boot_count": boot_count,
            })
            _sys.exit(rc)

        if rc < 0:
            console.print(
                f"\n  [yellow]Supervisor: child terminated by signal "
                f"({-rc}) — NOT respawning. Likely an external "
                f"supervisor or 'agntspace stop' issued the signal.[/]\n"
            )
            _supervisor_record_event({
                "kind": "child_signaled",
                "rc": rc,
                "boot_count": boot_count,
            })
            _sys.exit(0)

        # Unclean exit. Record + check budget.
        now = _time.time()
        crash_times.append(now)
        # Drop crashes outside the rolling window.
        while crash_times and (now - crash_times[0]) > _SUPERVISOR_CRASH_WINDOW_SECONDS:
            crash_times.popleft()

        _supervisor_record_event({
            "kind": "child_crashed",
            "rc": rc,
            "boot_count": boot_count,
            "crashes_in_window": len(crash_times),
            "max_crashes": _SUPERVISOR_MAX_CRASHES_IN_WINDOW,
        })

        if len(crash_times) >= _SUPERVISOR_MAX_CRASHES_IN_WINDOW:
            console.print(
                f"\n  [red bold]Supervisor: crash-loop break — "
                f"{len(crash_times)} unclean exits in "
                f"{_SUPERVISOR_CRASH_WINDOW_SECONDS:.0f}s. Giving up to "
                f"avoid burning CPU.[/]\n"
                f"  Inspect the latest crash via [bold]agntspace why-down[/] "
                f"(or check {_supervisor_log_path()}).\n"
            )
            _supervisor_record_event({
                "kind": "supervisor_crash_loop_break",
                "crashes_in_window": len(crash_times),
            })
            _sys.exit(1)

        # Backoff before respawn — exponential-ish from the schedule.
        idx = min(len(crash_times) - 1, len(_SUPERVISOR_BACKOFF_SCHEDULE) - 1)
        backoff = _SUPERVISOR_BACKOFF_SCHEDULE[idx]
        console.print(
            f"\n  [yellow]Supervisor: child exited with rc={rc} "
            f"(crash {len(crash_times)} of "
            f"{_SUPERVISOR_MAX_CRASHES_IN_WINDOW} budget). "
            f"Respawning in {backoff}s...[/]\n"
        )
        try:
            _time.sleep(backoff)
        except KeyboardInterrupt:
            console.print("\n  [dim]Supervisor: interrupted during backoff, exiting.[/]")
            _supervisor_record_event({"kind": "supervisor_interrupted_in_backoff"})
            _sys.exit(130)


@app.command()
def init(
    path: str | None = typer.Argument(None, help="Path to your vault folder (Obsidian vault, Dropbox, or any folder)"),
    minimal: bool = typer.Option(False, help="Non-interactive setup"),
) -> None:
    """Initialize AgntSpace in a vault folder.

    Creates agntspace-inbox/, agntspace-journal/, agntspace-knowledge/,
    agntspace-projects/ and agntspace/ (internals) inside the given folder.

    Example: agntspace init /path/to/my/vault
    """
    from agntspace.infra.logging import setup_logging
    from agntspace.setup.init import run_init
    setup_logging()

    if not path:
        console.print(
            "[red]Please specify a vault folder.[/red]\n"
            "  Usage: [bold]agntspace init /path/to/your/vault[/bold]\n"
            "  This can be an Obsidian vault, Dropbox folder, or any directory.\n"
            "  Your existing files will not be touched."
        )
        raise typer.Exit(1)

    vault_path = Path(path).expanduser().resolve()
    if not vault_path.is_dir():
        vault_path.mkdir(parents=True, exist_ok=True)

    root = run_init(vault_dir=vault_path, minimal=minimal)

    # Save root_dir to config so the server knows where the vault is
    config_dir = Path.home() / ".agntspace"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.toml"
    if config_path.exists():
        import tomli_w
        with open(config_path, "rb") as _f:
            _data = tomllib.load(_f)
        _data["root_dir"] = str(vault_path)
        config_path.write_bytes(tomli_w.dumps(_data).encode())
    else:
        import tomli_w
        config_path.write_bytes(tomli_w.dumps({
            "root_dir": str(vault_path),
            "llm": {"mode": "cloud", "cloud_provider": "anthropic", "cloud_model": "balanced"},
            "server": {"host": "127.0.0.1", "port": 8000},
        }).encode())

    console.print(f"\n[green]Initialized at {root}[/green]")
    console.print(f"  Config saved: root_dir = {vault_path}")
    console.print("Next: [bold]agntspace start[/bold]")


@app.command()
def start(
    host: str = typer.Option("127.0.0.1", help="Bind address"),
    port: int = typer.Option(8000, help="Port"),
    reload: bool = typer.Option(False, help="Auto-reload on code changes"),
    supervise: bool = typer.Option(
        True,
        "--supervise/--no-supervise",
        help=(
            "Default: supervise. Spawn the server as a subprocess and "
            "auto-respawn on unclean exit (with a crash-loop break — "
            "5 unclean exits in 5 min → give up). Pass --no-supervise "
            "to run the legacy inline behavior (no respawn, useful for "
            "debugging or when an external supervisor like systemd / "
            "Task Scheduler / NSSM owns lifecycle)."
        ),
    ),
) -> None:
    """Start the AgntSpace server."""
    # Reload mode skips supervision — uvicorn handles reload itself,
    # and supervising on top would race with uvicorn's child-restart
    # logic (the supervisor can't tell a planned reload from a crash).
    if reload:
        supervise = False

    if supervise and not os.environ.get("AGNTSPACE_NO_SUPERVISE"):
        _run_supervised(host=host, port=port)
        return

    import shutil
    import socket
    import threading
    import time
    import webbrowser

    import uvicorn

    from agntspace.infra.config import get_settings
    settings = get_settings()

    # Fatal-signal handler: writes the Python stack trace to a file when the
    # process dies from SIGSEGV / SIGABRT / SIGBUS / SIGILL — the classes of
    # hard-fault that C extensions (fastembed, ONNX Runtime, faster-whisper,
    # pdfplumber native libs, ffmpeg subprocess) cause without producing a
    # normal Python traceback on stderr. pythonw.exe has no console so stderr
    # is lost; a dedicated file handle guarantees the trace survives even
    # when the scheduled task launched us detached from any terminal.
    # Opened with line-buffering so partial frames still flush before exit.
    try:
        import faulthandler

        _fh_path = settings.log_dir / "faulthandler.log"
        _fh_path.parent.mkdir(parents=True, exist_ok=True)
        # Append mode: successive crashes accumulate for post-mortem analysis
        # without a single dump clobbering the previous one.
        _fh_file = open(_fh_path, "a", buffering=1, encoding="utf-8")  # noqa: SIM115 — file stays open for process lifetime
        _fh_file.write(f"\n--- faulthandler armed pid={os.getpid()} ts={time.strftime('%Y-%m-%dT%H:%M:%S')} ---\n")
        _fh_file.flush()
        faulthandler.enable(file=_fh_file, all_threads=True)
    except Exception:  # noqa: BLE001 — fatal-signal diagnostics are opportunistic; never let setup failure block startup
        pass

    if not settings.home_dir.exists():
        from agntspace.setup.init import run_init
        run_init(vault_dir=settings.root_dir, minimal=True)

    # Check port availability — kill stale AgntSpace process if needed
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex((host, port)) == 0:
            if not _try_reclaim_port(host, port):
                console.print(f"[bold red]Port {port} is in use by another program.[/] Use --port to pick a different one.")
                raise typer.Exit(1)

    from agntspace.api.routes.health import _get_version, _parse_version
    ver = _get_version()
    console.print(f"""
  [bold green]    _    ____ _   _ _____ [/][bold white] ____  ____   _    ____ _____ [/]
  [bold green]   / \\  / ___| \\ | |_   _|[/][bold white]/ ___||  _ \\ / \\  / ___| ____|[/]
  [bold green]  / _ \\| |  _|  \\| | | | [/][bold white] \\___ \\| |_) / _ \\| |   |  _|  [/]
  [bold green] / ___ | |_| | |\\  | | | [/][bold white]  ___) |  __/ ___ | |___| |___ [/]
  [bold green]/_/   \\_\\____|_| \\_| |_| [/][bold white] |____/|_| /_/   \\_\\____|_____|[/]  [dim]v{ver}[/]
""")

    # Quick PyPI version check (non-blocking, 3s timeout)
    try:
        import httpx
        resp = httpx.get("https://pypi.org/pypi/agntspace/json", timeout=3.0)
        if resp.status_code == 200:
            latest = resp.json().get("info", {}).get("version", "")
            if latest and ver != "dev" and _parse_version(latest) > _parse_version(ver):
                console.print(f"  [bold yellow]Update available: v{ver} -> v{latest}[/]")
                console.print("  [dim]Run:[/] pip install --upgrade agntspace")
                console.print()
    except Exception:
        pass

    console.print(f"  [dim]Server[/]  http://{host}:{port}")
    console.print(f"  [dim]Vault[/]   {settings.root_dir}")

    # Ollama reachability hint — fires when local mode is configured AND
    # Ollama isn't responding AND Ollama isn't installed on this machine.
    #
    # Two cases:
    # 1. Installed but not running (`shutil.which("ollama")` returns a path)
    #    → SILENT: the lifespan calls `ensure_ollama_running()` which spawns
    #    `ollama serve` and waits up to 30s. Showing the "isn't reachable"
    #    warning here would be a lie that becomes false ~30s later. The
    #    lifespan sanity-check (main.py) handles the genuine "still not
    #    running after auto-start" case with the correct disambiguation.
    # 2. Not installed (`shutil.which("ollama")` is None) → SHOW: the
    #    auto-start can't help; the user needs to install the package
    #    themselves. The install URL + brew/curl one-liners are the
    #    actionable signal.
    #
    # Cheap probe: socket connect to localhost:11434 with a 0.4s timeout +
    # a `shutil.which` lookup that's microseconds.
    try:
        wants_local = settings.llm.mode == "local"
        if wants_local:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as _ollama_sock:
                _ollama_sock.settimeout(0.4)
                reachable = _ollama_sock.connect_ex(("127.0.0.1", 11434)) == 0
            ollama_on_path = shutil.which("ollama") is not None
            if _should_show_ollama_install_hint(
                mode=settings.llm.mode,
                reachable=reachable,
                ollama_on_path=ollama_on_path,
            ):
                console.print()
                console.print("  [bold yellow]Local LLM mode is configured but Ollama isn't installed on this machine.[/]")
                console.print("  [dim]Install:[/] https://ollama.com/download  [dim]·[/]  macOS: [cyan]brew install ollama[/]  [dim]·[/]  Linux: [cyan]curl -fsSL https://ollama.com/install.sh | sh[/]")
                console.print("  [dim]Then start it ([/][cyan]ollama serve[/][dim]) and pull a model ([/][cyan]ollama pull qwen2.5:7b[/][dim]). Otherwise switch to Cloud or Hybrid mode at /llm.[/]")
    except Exception:  # noqa: BLE001 — startup hint is purely cosmetic; never block boot
        pass

    console.print()

    # Determine which page to open and schedule browser launch in background
    # (uvicorn.run blocks, so we launch a thread that waits for the server)
    url = f"http://{host}:{port}"
    marker = Path.home() / ".agntspace" / ".browser-opened"

    def _open_browser() -> None:
        """Wait for the server to be ready, then open the right page."""
        for _ in range(30):  # up to 15s
            time.sleep(0.5)
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    if s.connect_ex((host, port)) == 0:
                        break
            except Exception:
                pass
        else:
            return  # server never came up

        try:
            now = time.time()
            recent = marker.exists() and (now - marker.stat().st_mtime) < 86400

            # Detect state: no vault → setup, vault but not onboarded → onboarding, else dashboard
            has_vault = (
                settings.root_explicit
                or settings.root_dir != Path.home()
                or (settings.vault_dir / "system" / "identity" / "SOUL.md").exists()
            )

            if not has_vault:
                # Fresh install — always open setup
                webbrowser.open(f"{url}/setup")
            else:
                # Check onboarding status
                needs_onboarding = True
                try:
                    profile_path = settings.vault_dir / "system" / "identity" / "PROFILE.md"
                    if profile_path.exists():
                        content = profile_path.read_text(encoding="utf-8")
                        needs_onboarding = (
                            "[Your name]" in content or len(content.strip()) <= 200
                        )
                except Exception:
                    pass

                if needs_onboarding:
                    webbrowser.open(f"{url}/onboarding")
                elif not recent:
                    webbrowser.open(f"{url}/dashboard")

            marker.parent.mkdir(parents=True, exist_ok=True)
            marker.write_text(str(now))
        except Exception:
            pass

    # Phase 2 of the process split: worker / scheduler processes don't
    # serve a user-facing UI, so opening a browser is just noise. The
    # web / singleton processes still do.
    _proc_mode_env = os.environ.get("AGNTSPACE_PROCESS_MODE", "").strip().lower()
    _browser_modes = {"", "singleton", "web"}
    if _proc_mode_env in _browser_modes:
        threading.Thread(target=_open_browser, daemon=True).start()

    # Dev reload races with the vault singleton lock: when uvicorn
    # restarts the worker on file change, the new worker boots before
    # the dying one's lifespan teardown finishes — the new worker
    # would see a fresh-heartbeat lock and refuse to start. Skip the
    # lock entirely in reload mode; the dev workflow accepts the
    # one-process invariant being relaxed during iteration.
    if reload:
        import os as _os
        _os.environ["AGNTSPACE_SKIP_LOCK"] = "1"

    uvicorn.run("agntspace.main:create_app", factory=True, host=host, port=port, reload=reload, log_level="warning")


# ── Process split — Phase 2 CLI entry points ────────────────────────
#
# The three new commands below (``web`` / ``worker`` / ``scheduler``)
# are forwarders: each sets the ``AGNTSPACE_PROCESS_MODE`` env var and
# re-executes ``agntspace start`` as a child. That keeps the start
# command (with its supervisor, fault handler, browser thread, port
# reclaim) as the single canonical lifecycle path — these subcommands
# are just the ergonomic surface for the split.
#
# Default ports diverge so the three processes can coexist on one host
# (the default deployment shape for v1 of the split): web=8000 (the
# user-facing port), worker=8001, scheduler=8002. The user can
# override with --port for any.
#
# In ``singleton`` mode (the default ``agntspace start``) nothing
# changes — these new commands are additive.


def _exec_split_start(
    *,
    mode: str,
    host: str,
    port: int,
    reload: bool,
    supervise: bool,
) -> None:
    """Forward to ``agntspace start`` with ``AGNTSPACE_PROCESS_MODE`` set.

    Spawns a subprocess so the env var is captured at the canonical
    boundary — the start command's supervisor + child both inherit
    it through ``dict(os.environ)``. The launcher waits for the child
    and forwards its exit code; Ctrl-C from the user's terminal maps
    to exit 130 the same way ``start --supervise`` already handles it.
    """

    import os as _os
    import subprocess as _subprocess
    import sys as _sys

    env = dict(_os.environ)
    env["AGNTSPACE_PROCESS_MODE"] = mode

    cmd: list[str] = [
        _sys.executable, "-m", "agntspace", "start",
        "--host", host,
        "--port", str(port),
    ]
    if reload:
        cmd.append("--reload")
    cmd.append("--supervise" if supervise else "--no-supervise")

    try:
        rc = _subprocess.call(cmd, env=env)
    except KeyboardInterrupt:
        rc = 130
    raise typer.Exit(code=rc)


@app.command()
def web(
    host: str = typer.Option("127.0.0.1", help="Bind address"),
    port: int = typer.Option(8000, help="Port (default 8000 — user-facing)"),
    reload: bool = typer.Option(False, help="Auto-reload on code changes"),
    supervise: bool = typer.Option(
        True, "--supervise/--no-supervise",
        help="Auto-respawn on unclean exit. Pass --no-supervise for an "
             "external supervisor (systemd, Task Scheduler).",
    ),
) -> None:
    """Start AgntSpace in **web-only** mode (Phase 2 of the process split).

    Serves HTTP + WebSocket only. Skips background work queue dispatch,
    cron scheduler, and file watchers — those run in sibling ``worker``
    and ``scheduler`` processes. Long-running work delegates via the
    shared SQLite work queue at ``<vault>/agntspace/automation.db``.

    Pair with ``agntspace worker`` and ``agntspace scheduler`` for the
    full split deployment, OR run ``agntspace start`` for the singleton
    default.
    """

    _exec_split_start(
        mode="web",
        host=host,
        port=port,
        reload=reload,
        supervise=supervise,
    )


@app.command()
def worker(
    host: str = typer.Option("127.0.0.1", help="Bind address"),
    port: int = typer.Option(
        8001,
        help="Port (default 8001 — doesn't conflict with web on 8000)",
    ),
    reload: bool = typer.Option(False, help="Auto-reload on code changes"),
    supervise: bool = typer.Option(
        True, "--supervise/--no-supervise",
        help="Auto-respawn on unclean exit.",
    ),
) -> None:
    """Start AgntSpace in **worker-only** mode (Phase 2 of the process split).

    Drains the shared work queue: KB ingest / compile / reflect / lint /
    research / synthesize / memory consolidation / dream phases all
    run here. Skips HTTP user routes (still mounts them — for liveness
    + admin access — but nothing user-facing dispatches here), the
    cron scheduler, and file watchers.

    Pair with ``agntspace web`` and ``agntspace scheduler`` for the
    full split deployment.
    """

    _exec_split_start(
        mode="worker",
        host=host,
        port=port,
        reload=reload,
        supervise=supervise,
    )


@app.command()
def scheduler(
    host: str = typer.Option("127.0.0.1", help="Bind address"),
    port: int = typer.Option(
        8002,
        help="Port (default 8002 — doesn't conflict with web or worker)",
    ),
    reload: bool = typer.Option(False, help="Auto-reload on code changes"),
    supervise: bool = typer.Option(
        True, "--supervise/--no-supervise",
        help="Auto-respawn on unclean exit.",
    ),
) -> None:
    """Start AgntSpace in **scheduler-only** mode (Phase 2 of the process split).

    Runs cron + heartbeat + daily cycle (briefing / EOD / weekly
    compaction) + file watchers (raw inbox, finance inbox, vault edit)
    + filesystem-event bridge + channel pollers. Enqueues heavy work
    into the shared queue; the ``worker`` process dispatches.

    Pair with ``agntspace web`` and ``agntspace worker`` for the full
    split deployment.
    """

    _exec_split_start(
        mode="scheduler",
        host=host,
        port=port,
        reload=reload,
        supervise=supervise,
    )


@app.command()
def mode(
    new_mode: str = typer.Argument(
        None,
        help=(
            "New mode to persist to config.toml: singleton | web | worker | "
            "scheduler. Omit to show the current state without changing anything."
        ),
    ),
    reset: bool = typer.Option(
        False, "--reset",
        help="Reset config.toml [system].process_mode to singleton (default).",
    ),
    yes: bool = typer.Option(
        False, "--yes", "-y",
        help="Skip the confirmation prompt when changing modes.",
    ),
) -> None:
    """Show or set the process mode (Phase 2 of the process split).

    No args: print the current state (live mode + configured mode +
    where the live value came from). With ``new_mode``: persist a new
    mode to config.toml. The change takes effect on the next restart.

    The CLI routes through the REST API ``/api/settings/process-mode``
    so any contract / activity logging the server has applies
    uniformly to UI-driven and CLI-driven changes.

    Examples:
        agntspace mode                    # show
        agntspace mode worker             # set + persist
        agntspace mode --reset            # reset to singleton
    """

    base = _get_base_url()
    if not _check_server(base):
        return

    # Reset is shorthand for "set to singleton". Disallow both at once.
    if reset and new_mode is not None:
        console.print(
            "[red]Pass either a mode argument OR --reset, not both.[/red]",
        )
        raise typer.Exit(code=2)

    if reset:
        new_mode = "singleton"

    if new_mode is None:
        # Show-only path.
        try:
            state = _get("/api/settings/process-mode")
        except Exception as exc:
            console.print(f"[red]Failed to read process mode: {exc}[/red]")
            raise typer.Exit(code=1) from exc

        current = state.get("current", "?")
        configured = state.get("configured", "?")
        source = state.get("effective_source", "?")
        available = state.get("available_modes", [])
        restart_required = state.get("restart_required", False)

        console.print("\n[bold]Process mode[/bold]")
        console.print(f"  Live (this process):  [cyan]{current}[/cyan] "
                      f"[dim](from {source})[/dim]")
        console.print(f"  Configured (next boot): [cyan]{configured}[/cyan]")
        if restart_required:
            console.print(
                "  [yellow]Restart required[/yellow] — "
                "live and configured differ."
            )
        console.print(f"  Available: {', '.join(available)}\n")
        return

    # Set path.
    normalized = new_mode.strip().lower()
    valid = {"singleton", "web", "worker", "scheduler"}
    if normalized not in valid:
        console.print(
            f"[red]Invalid mode {new_mode!r}.[/red] "
            f"Must be one of: {', '.join(sorted(valid))}.",
        )
        raise typer.Exit(code=2)

    if not yes:
        confirm = typer.confirm(
            f"Persist [system].process_mode = {normalized!r} to config.toml? "
            f"(takes effect on next restart)",
            default=False,
        )
        if not confirm:
            console.print("[yellow]Cancelled.[/yellow]")
            raise typer.Exit(code=1)

    try:
        result = _put("/api/settings/process-mode", {"mode": normalized})
    except Exception as exc:
        # httpx HTTPStatusError carries the response — surface server detail
        # when available so the user sees the validation error rather than
        # a generic "request failed".
        detail = ""
        try:
            import httpx as _httpx
            if isinstance(exc, _httpx.HTTPStatusError):
                detail = exc.response.text[:300]
        except Exception:
            pass
        console.print(
            f"[red]Failed to persist process mode: {exc}[/red]"
            + (f"\n[dim]{detail}[/dim]" if detail else "")
        )
        raise typer.Exit(code=1) from exc

    console.print(
        f"[green]Persisted[/green] [system].process_mode = "
        f"[cyan]{result.get('configured', normalized)}[/cyan]"
    )
    if result.get("restart_required"):
        console.print(
            f"[yellow]Restart required[/yellow] — current process is still "
            f"[cyan]{result.get('current')}[/cyan]. Run "
            f"[cyan]agntspace {result.get('configured', normalized)}[/cyan] "
            f"or restart the server to switch."
        )


@app.command()
def status() -> None:
    """Show server status and key metrics."""
    base = _get_base_url()
    if not _check_server(base):
        return
    health = _get("/api/health")
    vault = _get("/api/vault/status")
    costs = _get("/api/costs/budget")
    agents = _get("/api/orchestrator/agents")
    projects = _get("/api/projects")

    console.print(f"\n[bold green]AgntSpace[/bold green] v{health.get('version', '?')} — {base}")
    console.print(f"  Onboarded: {'Yes' if vault.get('onboarded') else '[yellow]No[/yellow]'}")
    console.print(f"  Agents: {len(agents)}  |  Projects: {len(projects)}  |  Tasks: {vault.get('task_count', 0)}  |  Goals: {vault.get('goal_count', 0)}")
    console.print(f"  Today's cost: ${costs.get('daily_cost', 0):.2f} / ${costs.get('daily_budget', 10):.2f}")
    console.print()


@app.command()
def stop() -> None:
    """Stop the running AgntSpace server."""
    import os
    import signal
    import subprocess

    import httpx

    base = _get_base_url()
    try:
        httpx.get(f"{base}/api/health", timeout=2)
    except Exception:
        console.print("[yellow]Server not running.[/]")
        return

    from agntspace.infra.config import get_settings
    port = get_settings().port
    try:
        result = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, timeout=5)
        for line in result.stdout.splitlines():
            if f":{port}" in line and "LISTENING" in line:
                pid = int(line.strip().split()[-1])
                os.kill(pid, signal.SIGTERM)
                console.print("[bold green]Stopped.[/]")
                return
        console.print("[yellow]Could not find server process.[/]")
    except Exception as e:
        console.print(f"[red]Failed to stop: {e}[/]")


@app.command(name="why-down")
def why_down(
    json_output: bool = typer.Option(
        False, "--json", help="Print the analysis as JSON instead of human-readable",
    ),
) -> None:
    """Show why the server is down (or how it died last).

    Reads the supervisor.log + agntspace.log + crash.log + lock file
    and synthesizes a one-line verdict + structured details. The
    primary use is post-mortem after a death:

      $ agntspace why-down
      Server is down. Last recorded reason: memory_ceiling_exceeded:3501MB.

        Lock file:     pid=12345 started_at=2026-05-05T08:05:45 heartbeat=2812s ago [STALE]
        Last exit:     memory_ceiling_exceeded:3501MB (at 2026-05-05T08:37:48)
        Supervisor:    1 spawn(s), 0 clean exit(s), 0 crash(es), 0 crash-loop break(s)
        Native crash:  none recorded

        Recent launcher events (newest last):
          08:05:45  supervisor_start
          08:05:45  child_spawned
          08:37:48  child_signaled

    Pass --json to get the raw analysis dict for scripting.

    See ``infra/postmortem.py`` for the analyzer implementation.
    """
    import json as _json

    from agntspace.infra.config import get_settings
    from agntspace.infra.postmortem import analyze_post_mortem, format_human_report

    settings = get_settings()
    log_dir = settings.log_dir

    # Lock file lives in the vault — derive from settings.
    lock_file = settings.vault_dir / ".lock"

    analysis = analyze_post_mortem(
        supervisor_log=log_dir / "supervisor.log",
        agntspace_log=log_dir / "agntspace.log",
        crash_log=log_dir / "crash.log",
        lock_file=lock_file if lock_file.exists() else None,
    )

    if json_output:
        # Plain stdout, not Rich-formatted — for scripts that pipe.
        # Sanitize datetimes / Path objects via default=str.
        print(_json.dumps(analysis, default=str, indent=2))
        return

    report = format_human_report(analysis)
    console.print(report)


def _list_agntspace_processes(*, exclude_self: bool = True) -> list[dict]:
    """Return one dict per running agntspace python process.

    Cross-platform implementation — Windows uses PowerShell's CIM
    interface (wmic is deprecated); POSIX uses ``ps -eo pid,lstart,command``.
    NEVER raises — returns an empty list when the platform tools are
    unavailable. NEVER kills anything; this is a pure diagnostic.

    Each dict has: ``pid: int``, ``started: str``, ``cmdline: str``.
    Filtered to processes whose command line contains either
    ``agntspace.cli`` or ``agntspace`` (the module form when running
    via ``python -m agntspace ...``).

    ``exclude_self`` (default True) filters out our own process so
    the ``ps`` command doesn't list itself as a stale entry.
    """
    import json
    import os
    import subprocess
    import sys

    self_pid = os.getpid() if exclude_self else None
    rows: list[dict] = []
    try:
        if sys.platform == "win32":
            # PowerShell ConvertTo-Json gives us structured output we can
            # parse without playing tab-stop games. -NoProfile keeps it
            # fast even on machines with heavy PS profiles.
            ps_cmd = (
                "Get-CimInstance Win32_Process -Filter \"Name='python.exe' OR Name='pythonw.exe'\" | "
                "Select-Object ProcessId, CommandLine, CreationDate | "
                "ConvertTo-Json -Compress"
            )
            out = subprocess.check_output(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps_cmd],
                text=True, stderr=subprocess.DEVNULL, timeout=10,
            )
            if not out.strip():
                return []
            data = json.loads(out)
            # Single result is a dict, multiple is a list — normalize.
            entries = data if isinstance(data, list) else [data]
            for entry in entries:
                cmdline = entry.get("CommandLine") or ""
                if "agntspace" not in cmdline:
                    continue
                pid_val = entry.get("ProcessId")
                if pid_val is not None and self_pid is not None and int(pid_val) == self_pid:
                    continue
                created = entry.get("CreationDate") or ""
                # CIM CreationDate looks like "/Date(1714112883000)/"
                started = ""
                if isinstance(created, str) and "/Date(" in created:
                    try:
                        ts_ms = int(created.split("(")[1].split(")")[0].split("+")[0].rstrip("-"))
                        from datetime import datetime as _dt
                        started = _dt.fromtimestamp(ts_ms / 1000).strftime("%Y-%m-%d %H:%M:%S")
                    except Exception:
                        started = ""
                if pid_val is not None:
                    rows.append({"pid": int(pid_val), "started": started, "cmdline": cmdline})
        else:
            # POSIX — ps with lstart is consistent across mac+linux
            out = subprocess.check_output(
                ["ps", "-eo", "pid,lstart,command"],
                text=True, stderr=subprocess.DEVNULL, timeout=10,
            )
            for line in out.splitlines()[1:]:  # skip header
                if "agntspace" not in line:
                    continue
                # Format: PID Mon DD HH:MM:SS YYYY COMMAND...
                parts = line.strip().split(None, 6)
                if len(parts) < 7:
                    continue
                try:
                    pid_val = int(parts[0])
                except ValueError:
                    continue
                if self_pid is not None and pid_val == self_pid:
                    continue
                started = " ".join(parts[1:6])
                cmdline = parts[6]
                rows.append({"pid": pid_val, "started": started, "cmdline": cmdline})
    except Exception:
        # Diagnostic command must never raise — return what we have.
        pass
    return rows


def _pid_holding_port(port: int) -> int | None:
    """Return the PID listening on ``port``, or None. Never raises."""
    import subprocess
    import sys

    try:
        if sys.platform == "win32":
            out = subprocess.check_output(
                ["netstat", "-ano"], text=True, stderr=subprocess.DEVNULL, timeout=5,
            )
            for line in out.splitlines():
                if f":{port}" in line and "LISTENING" in line:
                    try:
                        return int(line.strip().split()[-1])
                    except ValueError:
                        continue
        else:
            out = subprocess.check_output(
                ["lsof", "-ti", f"tcp:{port}", "-sTCP:LISTEN"],
                text=True, stderr=subprocess.DEVNULL, timeout=5,
            ).strip()
            if out:
                try:
                    return int(out.splitlines()[0])
                except ValueError:
                    return None
    except Exception:
        return None
    return None


@app.command(name="ps")
def ps_cmd() -> None:
    """List running AgntSpace processes (diagnostic — never kills).

    Shows every python process whose command line references AgntSpace,
    plus which one (if any) is bound to the configured server port.
    Use this to spot orphan processes left over from crashes,
    interrupted upgrades, or `taskkill` that didn't clean up the whole
    process tree. The fix is always manual: ``taskkill /F /PID <id>``
    on Windows or ``kill <id>`` on POSIX.

    Why no auto-kill: the launcher used to do that and produced 48+
    self-inflicted Python deaths in one afternoon. See the docstring
    on ``_try_reclaim_port`` for the post-mortem.

    The table also surfaces ProcessRegistry rows from
    ``<vault>/agntspace/automation.db`` so a process registered there
    but missing from the OS scan (typically: a stale row from an
    abrupt previous death) shows up too. Same the other direction:
    OS-scanned python processes that aren't in the registry are
    flagged ``untracked`` so an external Python with ``agntspace`` in
    its cmdline is distinguishable from one of our own.
    """
    from agntspace.infra.config import get_settings

    settings = get_settings()
    port = settings.port
    procs = _list_agntspace_processes()
    bound_pid = _pid_holding_port(port)
    registry_records = _read_process_registry(settings)

    # Build a lookup by pid from the registry so we can annotate the
    # OS-scan rows + surface registry-only entries (stale rows from
    # abrupt deaths).
    registry_by_pid: dict[int, dict] = {r["pid"]: r for r in registry_records}
    os_pids: set[int] = {p["pid"] for p in procs}

    # Registry-only entries (pid not in OS scan) — ghosts.
    ghost_rows = [r for r in registry_records if r["pid"] not in os_pids]

    if not procs and not ghost_rows:
        console.print("[dim]No AgntSpace processes found.[/]")
        return

    table = Table(title=f"AgntSpace processes (port {port})", show_lines=False)
    table.add_column("PID", justify="right", style="cyan")
    table.add_column("Started", style="dim")
    table.add_column("Status", justify="center")
    table.add_column("Kind", style="dim")
    table.add_column("Heartbeat", style="dim")
    table.add_column("Command", style="white")

    # Sort: port-bound first, then by PID
    procs_sorted = sorted(procs, key=lambda p: (p["pid"] != bound_pid, p["pid"]))

    for proc in procs_sorted:
        on_port = proc["pid"] == bound_pid
        reg = registry_by_pid.get(proc["pid"])
        if on_port:
            marker = "[bold green]LIVE[/]"
        elif reg is not None:
            if reg["alive"]:
                marker = "[green]registered[/]"
            else:
                marker = "[yellow]stale-reg[/]"
        else:
            marker = "[yellow]untracked[/]"
        kind = (reg["kind"] if reg else "—")
        if reg is not None:
            age = reg["heartbeat_age_seconds"]
            if age == float("inf"):
                hb = "—"
            else:
                hb = f"{age:.0f}s"
        else:
            hb = "—"
        # Truncate cmdline so the table stays readable
        cmd = proc["cmdline"]
        if len(cmd) > 60:
            cmd = cmd[:57] + "..."
        table.add_row(
            str(proc["pid"]),
            proc["started"] or "—",
            marker,
            kind,
            hb,
            cmd,
        )

    # Ghost rows (in registry but no live OS process)
    for ghost in ghost_rows:
        age = ghost["heartbeat_age_seconds"]
        if age == float("inf"):
            hb = "—"
        else:
            hb = f"{age:.0f}s"
        marker = "[red]ghost[/]" if not ghost["alive"] else "[yellow]reg-only[/]"
        # No cmdline available for ghosts
        table.add_row(
            str(ghost["pid"]),
            ghost.get("started_at") or "—",
            marker,
            ghost["kind"],
            hb,
            f"[dim](registered as {ghost['kind']}; no OS process)[/]",
        )

    console.print(table)

    stale_count = sum(1 for p in procs if p["pid"] != bound_pid)
    ghost_count = len(ghost_rows)
    if stale_count > 0 or ghost_count > 0:
        if stale_count > 0:
            console.print(
                f"\n  [yellow]{stale_count} stale process(es) detected[/] — "
                "not bound to the configured port. They may be orphans from\n"
                "  a previous run that didn't clean up. Kill manually if needed:\n"
                "  [bold]taskkill /F /PID <id>[/] (Windows)  |  [bold]kill <id>[/] (POSIX)\n"
            )
            console.print(
                "  [dim]The launcher deliberately doesn't auto-kill — it has been\n"
                "  too dangerous in the past (see cli.py:_try_reclaim_port docstring).[/]"
            )
        if ghost_count > 0:
            console.print(
                f"\n  [yellow]{ghost_count} registry-only entry(s) detected[/] — "
                "rows in process_registry whose PID is no longer running.\n"
                "  These are typically stale rows from abrupt deaths; the next\n"
                "  AgntSpace boot's [bold]sweep_dead[/] purges them automatically."
            )


def _read_process_registry(settings) -> list[dict]:
    """Read every row from process_registry on automation.db.

    Returns a list of plain dicts: pid, kind, started_at, heartbeat_age_seconds,
    alive. Empty list if the DB doesn't exist (e.g. setup mode), if the table
    doesn't exist (pre-Phase-0 vault), or any read error. Best-effort —
    the registry is a discovery surface, not a correctness one.
    """
    automation_path = getattr(settings, "automation_db_path", None)
    if automation_path is None:
        return []
    if not Path(automation_path).exists():
        return []

    async def _do_read() -> list[dict]:
        try:
            from agntspace.infra import process_registry as _pr
            from agntspace.infra.automation_db import get_automation_db
        except Exception:
            return []
        try:
            db = await get_automation_db(Path(automation_path))
        except Exception:
            return []
        try:
            try:
                # Schema may not exist yet on a vault that has never run
                # post-Phase-0. Probe via a cheap SELECT first; if the
                # table is missing, list_all returns [] via its catch.
                records = await _pr.list_all(db)
            except Exception:
                records = []
            return [
                {
                    "pid": r.pid,
                    "kind": r.kind,
                    "started_at": r.started_at,
                    "heartbeat_at": r.heartbeat_at,
                    "heartbeat_age_seconds": r.heartbeat_age_seconds,
                    "alive": r.alive,
                    "process_id": r.process_id,
                    "metadata": r.metadata,
                }
                for r in records
            ]
        finally:
            try:
                await db.close()
            except Exception:
                pass

    try:
        import asyncio as _aio_ps
        return _aio_ps.run(_do_read())
    except Exception:
        return []


# ═══════════════════════════════════════════
# CHAT
# ═══════════════════════════════════════════


@app.command()
def chat(
    message: str | None = typer.Argument(None, help="Single message (non-interactive)"),
) -> None:
    """Chat with the agent. Interactive if no message given."""
    import httpx
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    if message:
        data = _post("/api/chat", {"message": message})
        console.print(f"\n[bold green]Agent:[/bold green] {data.get('message', '')}\n")
        return

    async def _loop() -> None:
        async with httpx.AsyncClient(base_url=base, timeout=120) as client:
            conv_id: str | None = None
            console.print("[dim]Interactive chat. Type 'exit' to quit.[/dim]\n")
            while True:
                try:
                    user_input = console.input("[bold cyan]You:[/bold cyan] ")
                except (EOFError, KeyboardInterrupt):
                    break
                if user_input.strip().lower() in ("exit", "quit", "/quit"):
                    break
                if not user_input.strip():
                    continue
                try:
                    resp = await client.post("/api/chat", json={"message": user_input, "conversation_id": conv_id})
                    resp.raise_for_status()
                    data = resp.json()
                    conv_id = data["conversation_id"]
                    console.print(f"\n[bold green]Agent:[/bold green] {data['message']}\n")
                except httpx.HTTPError as e:
                    console.print(f"[red]Error: {e}[/red]")
    asyncio.run(_loop())


# ═══════════════════════════════════════════
# TASKS
# ═══════════════════════════════════════════


@app.command()
def tasks(
    status_filter: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
) -> None:
    """List tasks."""
    base = _get_base_url()
    if not _check_server(base):
        return
    params = {"status": status_filter} if status_filter else {}
    data = _get("/api/tasks", params)
    if not data:
        console.print("[dim]No tasks.[/dim]")
        return
    table = Table(title="Tasks")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Mode")
    table.add_column("Domain")
    for t in data:
        table.add_row(t["title"], t["status"], t["mode"], t.get("domain", ""))
    console.print(table)


@app.command()
def delegate(
    description: str = typer.Argument(..., help="Task description"),
    mode: str = typer.Option("jdi", help="Mode: jdi, review, recommend, watch"),
) -> None:
    """Delegate a task to the agent."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/tasks", {"title": description[:80], "brief": description, "mode": mode})
    console.print(f"[green]Delegated:[/green] {data.get('path', '?')}")


# ═══════════════════════════════════════════
# PROJECTS
# ═══════════════════════════════════════════


@app.command()
def projects(
    status_filter: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
) -> None:
    """List projects."""
    base = _get_base_url()
    if not _check_server(base):
        return
    params = {"status": status_filter} if status_filter else {}
    data = _get("/api/projects", params)
    if not data:
        console.print("[dim]No projects.[/dim]")
        return
    table = Table(title="Projects")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Target")
    table.add_column("Goals")
    table.add_column("Agents")
    for p in data:
        table.add_row(
            p["title"], p["status"], p.get("target_date", ""),
            ", ".join(p.get("related_goals", [])),
            ", ".join(p.get("assigned_agents", [])),
        )
    console.print(table)


@app.command(name="project-create")
def project_create(
    title: str = typer.Argument(..., help="Project title"),
    description: str = typer.Option("", help="Project description"),
) -> None:
    """Create a new project."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/projects", {"title": title, "description": description})
    console.print(f"[green]Created:[/green] {data.get('path', '?')}")


# ═══════════════════════════════════════════
# GOALS
# ═══════════════════════════════════════════


@app.command()
def goals() -> None:
    """List goals."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/goals")
    if not data:
        console.print("[dim]No goals.[/dim]")
        return
    table = Table(title="Goals")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Type")
    table.add_column("Target Date")
    for g in data:
        table.add_row(g["title"], g["status"], g.get("type", ""), g.get("target_date", ""))
    console.print(table)


# ═══════════════════════════════════════════
# JOURNAL
# ═══════════════════════════════════════════


@app.command()
def journal(
    thought: str = typer.Argument(..., help="Quick thought to add"),
    section: str = typer.Option("Thoughts", help="Section: Focus, Thoughts, Decisions, Learnings, Reflections"),
) -> None:
    """Add a thought to today's journal."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    _post("/api/journal/append", {"text": thought, "section": section, "author": "HUMAN"})
    console.print(f"[green]Added to {section}.[/green]")


@app.command()
def jot(
    thought: str = typer.Argument(..., help="Quick thought to capture"),
    section: str = typer.Option("Thoughts", "--section", "-s", help="Section: Focus, Thoughts, Decisions, Learnings, Reflections"),
    tags: str = typer.Option("", "--tags", "-t", help="Comma-separated tags, inlined as #foo #bar"),
) -> None:
    """Quick-capture a thought into today's journal (defaults to Thoughts)."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    text = thought.strip()
    if tags:
        tag_str = " ".join(f"#{t.strip()}" for t in tags.split(",") if t.strip())
        if tag_str:
            text = f"{text} {tag_str}"
    _post("/api/journal/append", {"text": text, "section": section, "author": "HUMAN"})
    console.print(f"[green]Jotted to {section}.[/green]")


@app.command(name="journal-today")
def journal_today() -> None:
    """Show today's journal."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/journal/today")
    if data.get("content"):
        console.print(data["content"])
    else:
        console.print("[dim]No journal entry for today.[/dim]")


# ═══════════════════════════════════════════
# AGENTS
# ═══════════════════════════════════════════


@app.command()
def agents() -> None:
    """List subagents and their status."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/orchestrator/agents")
    table = Table(title="Subagents")
    table.add_column("Key")
    table.add_column("Name")
    table.add_column("Role")
    table.add_column("Status")
    table.add_column("Access")
    table.add_column("Skills")
    for a in data:
        table.add_row(a["key"], a["name"], a["role"], a["status"], a["access"], ", ".join(a.get("skills", [])))
    console.print(table)


@app.command(name="dispatch")
def dispatch_agent(
    agent: str = typer.Argument(..., help="Agent key (e.g. writer, researcher)"),
    task: str = typer.Argument(..., help="Task description"),
) -> None:
    """Dispatch a task to a specific subagent."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/orchestrator/dispatch", {"agent_name": agent, "task": task}, timeout=120)
    console.print(f"\n[bold green]{data.get('agent_name', agent)}:[/bold green] {data.get('content', '')}")
    console.print(f"\n[dim]{data.get('input_tokens', 0)} in + {data.get('output_tokens', 0)} out tokens[/dim]")


# ═══════════════════════════════════════════
# TRUST
# ═══════════════════════════════════════════


@app.command()
def trust(
    domain: str | None = typer.Option(None, help="Set level for this domain"),
    level: str | None = typer.Option(None, help="New level: Observer, Advisor, Assistant, Partner"),
) -> None:
    """Show or update trust levels."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if domain and level:
        _put("/api/trust/level", {"domain": domain, "level": level})
        console.print(f"[green]{domain} → {level}[/green]")
        return
    data = _get("/api/trust")
    table = Table(title="Trust Levels")
    table.add_column("Domain")
    table.add_column("Level")
    table.add_column("Tasks")
    table.add_column("Good")
    table.add_column("Redo")
    for d in data.get("domains", []):
        table.add_row(d["domain"], d["level"], str(d["completed"]), str(d["good"]), str(d["redo"]))
    console.print(table)


# ═══════════════════════════════════════════
# WIKI
# ═══════════════════════════════════════════


# ═══════════════════════════════════════════
# PERSONA — main agent personality switcher (Option A, 2026-05-06)
# ═══════════════════════════════════════════


@app.command()
def persona(
    name: str | None = typer.Argument(
        None, help="Variant name to switch to (omit + no flags shows current state)"
    ),
    list_variants: bool = typer.Option(
        False, "--list", "-l", help="List declared variants in SOUL.md"
    ),
    reset: bool = typer.Option(
        False, "--reset", help="Clear active_personality — fall back to base section"
    ),
) -> None:
    """Switch the main agent's personality variant.

    SOUL.md may declare ``## Personality (<name>)`` sections in addition to
    the base ``## Personality``. ``active_personality:`` in frontmatter
    selects which variant is active. The base section is always the
    fallback. The agent's mtime watcher rebuilds the system prompt on the
    next chat turn — no restart needed.

    Examples:
      agntspace persona              # show current state
      agntspace persona --list       # list declared variants
      agntspace persona focus        # switch to the 'focus' variant
      agntspace persona --reset      # back to base personality
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    if reset:
        data = _post("/api/persona/reset")
        console.print("[green]Reverted to base personality[/green]")
        console.print(f"[dim]{data.get('message', '')}[/dim]")
        return

    if name:
        try:
            data = _post("/api/persona/switch", {"name": name})
        except Exception as exc:
            console.print(f"[red]Switch failed:[/red] {exc}")
            raise typer.Exit(1) from exc
        console.print(f"[green]Active personality →[/green] [bold]{data.get('active', name)}[/bold]")
        console.print(f"[dim]{data.get('message', '')}[/dim]")
        return

    state = _get("/api/persona")
    active = state.get("active") or "(base)"
    available = state.get("available") or []

    if list_variants:
        if not available:
            console.print("[yellow]No variants declared in SOUL.md[/yellow]")
            console.print(
                "[dim]Add a section like ``## Personality (focus)`` to SOUL.md to "
                "declare a variant.[/dim]"
            )
            return
        console.print(f"[bold]Active:[/bold] {active}")
        console.print("[bold]Variants:[/bold]")
        for v in available:
            marker = " [green]← active[/green]" if v == state.get("active") else ""
            console.print(f"  • {v}{marker}")
        return

    # Default: show current state
    console.print(f"[bold]Active personality:[/bold] {active}")
    if available:
        console.print(f"[dim]{len(available)} variant(s) declared: {', '.join(available)}[/dim]")
        console.print("[dim]Use `agntspace persona --list` for details, `agntspace persona <name>` to switch.[/dim]")
    else:
        console.print("[dim]No variants declared. Add a ``## Personality (<name>)`` section to SOUL.md to create one.[/dim]")


@app.command()
def wiki(
    query: str | None = typer.Argument(None, help="Search query"),
) -> None:
    """Search wiki or show stats."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if query:
        data = _get("/api/wiki/search", {"q": query})
        if not data:
            console.print(f"[dim]No results for '{query}'[/dim]")
            return
        for a in data[:10]:
            console.print(f"  [bold]{a.get('title', a['slug'])}[/bold] — {a.get('snippet', '')[:80]}")
        return
    stats = _get("/api/wiki/stats")
    console.print(f"Wiki: {stats.get('total_articles', 0)} articles, {stats.get('total_kbs', 0)} KBs")


@app.command(name="wiki-job")
def wiki_job(
    kb: str | None = typer.Option(None, help="KB slug (omit for all KBs)"),
) -> None:
    """Run the wiki pipeline (ingest, compile, lint)."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    console.print("[dim]Running wiki job...[/dim]")
    if kb:
        data = _post(f"/api/kb/{kb}/job", timeout=300)
    else:
        data = _post("/api/kb/job/all", timeout=300)
    console.print(f"[green]Done.[/green] {json.dumps(data, indent=2)[:500]}")


@app.command(name="taxonomy-migrate")
def taxonomy_migrate(
    apply: bool = typer.Option(False, "--apply", help="Actually rewrite frontmatter (destructive — defaults to dry-run preview)"),
    deterministic_only: bool = typer.Option(
        False, "--deterministic-only",
        help="When applying, restrict to deterministic mappings only — leaves ambiguous/unclassified articles untouched.",
    ),
) -> None:
    """Migrate wiki articles' taxonomy_path from v1 → v2.

    Default is a read-only dry-run that prints the plan. Pass --apply to
    actually rewrite frontmatter. Idempotent — re-running on a fully-migrated
    vault is a no-op.
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    if not apply:
        console.print("[dim]Running taxonomy migration preview (read-only)...[/dim]")
        plan = _get("/api/wiki/taxonomy/migration/preview", timeout=60)
        if not isinstance(plan, dict):
            console.print(f"[red]Unexpected response shape: {plan!r}[/red]")
            raise typer.Exit(1)

        total = plan.get("total", 0)
        changed = plan.get("changed", 0)
        by_conf = plan.get("by_confidence", {})
        console.print(
            f"[bold]Total articles:[/bold] {total}  "
            f"[bold]Will change:[/bold] {changed}  "
            f"[dim]({by_conf})[/dim]",
        )
        console.print()
        for old, b in sorted(
            (plan.get("by_old_path") or {}).items(),
            key=lambda x: -(x[1].get("count", 0)),
        ):
            arrow = "->" if b.get("changed") else "=="
            new = b.get("new_path") or "(unclassified)"
            old_disp = old or "(empty)"
            confidence = b.get("confidence", "?")
            console.print(
                f"  {b.get('count', 0):3d}  [{confidence}]  {old_disp}  {arrow}  {new}",
            )
            reason = b.get("reason", "")
            if reason:
                console.print(f"        [dim]reason: {reason}[/dim]")
        console.print()
        console.print("[dim]Re-run with --apply to write the changes.[/dim]")
        return

    body: dict = {"confirm": True}
    if deterministic_only:
        body["confidence_filter"] = ["deterministic"]
    console.print("[yellow]Applying taxonomy migration (destructive)...[/yellow]")
    result = _post("/api/wiki/taxonomy/migration/apply", body, timeout=120)
    if not isinstance(result, dict):
        console.print(f"[red]Unexpected response shape: {result!r}[/red]")
        raise typer.Exit(1)
    console.print(
        f"[green]Migrated:[/green] {result.get('migrated', 0)}  "
        f"[dim]Skipped:[/dim] {result.get('skipped', 0)}  "
        f"[red]Failed:[/red] {result.get('failed', 0)}",
    )
    failures = result.get("failed_items") or []
    if failures:
        console.print()
        console.print("[red]Failures:[/red]")
        for f in failures[:10]:
            console.print(f"  {f.get('slug', '?')}: {f.get('error', '?')}")


@app.command(name="skill-import")
def skill_import(
    source: str = typer.Argument(
        ...,
        help=(
            "Local path, GitHub URL, GitHub shorthand (owner/repo), git URL, or zip URL. "
            "Examples: ./my-skill | github:goose/skill-a | https://github.com/foo/bar | "
            "https://example.com/skill.zip"
        ),
    ),
    category: str = typer.Option(
        "",
        "--category",
        "-c",
        help=(
            "Skill category (private, community, work, creative, core). "
            "Default inferred from source: URLs land in community, local paths in private."
        ),
    ),
    overwrite: bool = typer.Option(
        False, "--overwrite", help="Replace an existing skill with the same name."
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help=(
            "Bypass agentskills.io spec validation. Imports the skill even if "
            "validation fails — emits a high-importance audit event."
        ),
    ),
    no_warnings: bool = typer.Option(
        False, "--no-warnings", help="Hide validation warnings on success."
    ),
) -> None:
    """Import a skill from any agentskills.io-compatible source.

    Examples:

        # Local folder (lands in private/)
        agntspace skill-import ./my-skill

        # GitHub repo (lands in community/)
        agntspace skill-import github:goose/excel-skill

        # Specific subfolder of a repo
        agntspace skill-import https://github.com/agentskills/skills/tree/main/pdf-processing

        # Zip archive
        agntspace skill-import https://example.com/skill-pack.zip

        # Bypass validation (for skills that don't pass spec — adds an audit event)
        agntspace skill-import https://github.com/foo/bar --force
    """
    from pathlib import Path as P

    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    # Normalise local paths so the user can use `./` shortcuts; URLs
    # pass through verbatim.
    is_local_path = P(source).exists()
    payload_source = str(P(source).resolve()) if is_local_path else source

    payload = {
        "source": payload_source,
        "overwrite": overwrite,
        "force": force,
    }
    if category:
        payload["category"] = category

    try:
        data = _post("/api/skills/import", payload)
    except Exception as exc:
        console.print(f"[red]Import failed:[/red] {exc}")
        raise typer.Exit(2) from exc

    console.print(f"[green]Imported skill:[/green] {data.get('title', data.get('name'))}")
    console.print(f"  Name:     [bold]{data.get('name')}[/bold]")
    console.print(f"  Category: {data.get('category')}")
    console.print(f"  Source:   [dim]{data.get('canonical', '')}[/dim]")
    console.print(f"  Kind:     {data.get('kind', '')}")
    console.print(f"  Path:     [dim]{data.get('path', '')}[/dim]")
    console.print(f"  Files:    {data.get('files_copied', 0)}")
    if data.get("force_override"):
        console.print(
            "  [yellow]Warning:[/yellow] imported with --force; "
            "validation errors recorded in the audit event."
        )
    elif not no_warnings and data.get("validation_passed"):
        console.print("  Validation: [green]passed[/green]")


@app.command(name="skill-export")
def skill_export(
    name: str = typer.Argument(..., help="Skill name (e.g. kb-ingest, fact-checking)"),
    to: str = typer.Option(
        ".",
        "--to",
        "-o",
        help="Target directory. Skill lands at <to>/<name>/. Default: current directory.",
    ),
    strip_metadata: bool = typer.Option(
        False,
        "--strip-metadata",
        help=(
            "Emit pure-spec form: drop AgntSpace flat extras (title, category, "
            "status, author) and behavioral metadata (triggers, priority, etc.). "
            "Default keeps everything for round-trip via skill-import."
        ),
    ),
    overwrite: bool = typer.Option(
        False,
        "--overwrite",
        help="Replace <to>/<name>/ if it already exists.",
    ),
    tarball: bool = typer.Option(
        False,
        "--tarball",
        help="Write a single <name>.tar.gz instead of an unpacked folder.",
    ),
) -> None:
    """Export a vault skill as an agentskills.io spec-canonical copy.

    Examples:

        # Export a skill into the current directory (round-trip form)
        agntspace skill-export kb-ingest

        # Export to a specific path with pure-spec stripping
        agntspace skill-export fact-checking --to ./shareable --strip-metadata

        # Single tarball ready to upload to a registry
        agntspace skill-export research-scrape --tarball --to ~/Downloads

    The default form keeps every AgntSpace extension under ``metadata:``
    so a future ``skill-import`` reproduces the same Skill object byte-for-byte
    (modulo the export timestamp). ``--strip-metadata`` produces what a
    stranger consuming only agentskills.io would expect — minimal,
    behavioral fields gone, ready for ecosystem distribution.
    """
    from pathlib import Path as P

    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    qs = []
    if strip_metadata:
        qs.append("strip_metadata=true")
    query = ("?" + "&".join(qs)) if qs else ""

    # The export endpoint returns binary; we use httpx directly here
    # rather than _post which expects JSON.
    import httpx

    try:
        with httpx.Client(timeout=60.0) as client:
            response = client.post(f"{base}/api/skills/{name}/export{query}")
            if response.status_code == 404:
                console.print(f"[red]Skill not found:[/red] {name}")
                raise typer.Exit(1)
            response.raise_for_status()
            tarball_bytes = response.content
    except httpx.HTTPError as exc:
        console.print(f"[red]Export failed:[/red] {exc}")
        raise typer.Exit(2) from exc

    out_dir = P(to).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if tarball:
        target_file = out_dir / f"{name}.tar.gz"
        if target_file.exists() and not overwrite:
            console.print(
                f"[red]File exists:[/red] {target_file}. Use --overwrite to replace."
            )
            raise typer.Exit(1)
        target_file.write_bytes(tarball_bytes)
        console.print(f"[green]Exported skill:[/green] {name}")
        console.print(f"  Tarball: [bold]{target_file}[/bold]")
        console.print(f"  Size:    {len(tarball_bytes)} bytes")
        console.print(f"  Mode:    {'pure-spec' if strip_metadata else 'round-trip'}")
        return

    # Unpack the tarball into <to>/<name>/
    import io
    import tarfile

    target_dir = out_dir / name
    if target_dir.exists():
        if not overwrite:
            console.print(
                f"[red]Directory exists:[/red] {target_dir}. Use --overwrite to replace."
            )
            raise typer.Exit(1)
        import shutil

        shutil.rmtree(target_dir)

    try:
        with tarfile.open(fileobj=io.BytesIO(tarball_bytes), mode="r:gz") as tar:
            tar.extractall(out_dir)
    except Exception as exc:
        console.print(f"[red]Unpack failed:[/red] {exc}")
        raise typer.Exit(2) from exc

    # Count files we wrote
    file_count = sum(1 for p in target_dir.rglob("*") if p.is_file()) if target_dir.is_dir() else 0
    console.print(f"[green]Exported skill:[/green] {name}")
    console.print(f"  Path:  [bold]{target_dir}[/bold]")
    console.print(f"  Files: {file_count}")
    console.print(f"  Mode:  {'pure-spec' if strip_metadata else 'round-trip'}")


@app.command(name="skills-status")
def skills_status() -> None:
    """Show skill-sync status — how many skills have shipped upgrades waiting."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _get("/api/skills/sync/status")
    console.print(f"Shipped files tracked: [bold]{data.get('shipped_count', 0)}[/bold]")
    console.print(f"Accepted in vault:     [bold]{data.get('tracked', 0)}[/bold]")
    pending = data.get("pending_count", 0)
    color = "yellow" if pending else "green"
    console.print(f"Pending review:        [bold {color}]{pending}[/bold {color}]")
    for p in data.get("pending_paths", []):
        console.print(f"  - {p}")


@app.command(name="skills-sync")
def skills_sync(
    accept_all: bool = typer.Option(False, "--accept-all", help="Accept every shipped upgrade (destroys local edits)"),
    keep_mine: bool = typer.Option(False, "--keep-mine", help="Keep every local edit (dismisses pending upgrades)"),
) -> None:
    """Run a skill-sync pass. Without flags: shows what would happen.

    With --accept-all or --keep-mine: resolves every pending upgrade in bulk.
    Use the /skills/sync UI for per-file diff review.
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    if accept_all and keep_mine:
        console.print("[red]--accept-all and --keep-mine are mutually exclusive[/red]")
        raise typer.Exit(2)

    # Always run a sync pass so the pending list reflects the current state.
    report = _post("/api/skills/sync/run", {})
    summary = report.get("summary", {})
    console.print("[bold]Sync pass:[/bold]")
    for k, v in summary.items():
        if v:
            console.print(f"  {k}: {v}")

    if not (accept_all or keep_mine):
        if report.get("pending"):
            console.print(
                f"\n[yellow]{len(report['pending'])} skill(s) need review.[/yellow] "
                f"Open [bold]/skills/sync[/bold] in the UI to diff, or rerun with "
                f"--accept-all / --keep-mine."
            )
        return

    pending_paths = list(report.get("pending", []))
    if not pending_paths:
        console.print("[green]Nothing pending.[/green]")
        return

    endpoint = "/api/skills/sync/accept" if accept_all else "/api/skills/sync/keep-mine"
    label = "accepted" if accept_all else "kept local edit"
    for path in pending_paths:
        try:
            _post(endpoint, {"path": path})
            console.print(f"  [green]{label}:[/green] {path}")
        except Exception as exc:
            console.print(f"  [red]failed:[/red] {path} — {exc}")


@app.command(name="skill-validate")
def skill_validate(
    target: str = typer.Argument(
        ...,
        help="Path to a SKILL.md / skill folder, or a skills/ directory tree. Pass --by-name to resolve a vault skill via the running server.",
    ),
    by_name: bool = typer.Option(
        False,
        "--by-name",
        help="Treat target as a skill name and fetch it via the running server (requires server up).",
    ),
    show_warnings: bool = typer.Option(
        True,
        "--warnings/--no-warnings",
        help="Print warnings alongside errors. Defaults to on.",
    ),
) -> None:
    """Validate one or more SKILL.md files against the agentskills.io spec.

    Examples:

        # Validate a single shipped default
        agntspace skill-validate defaults/skills/core/kb-ingest

        # Validate every shipped default
        agntspace skill-validate defaults/skills

        # Validate a vault skill by name (server must be running)
        agntspace skill-validate kb-ingest --by-name
    """
    from pathlib import Path as P

    # ── By-name path: hit the running server's API ─────────────────────────
    if by_name:
        base = _get_base_url()
        if not _check_server(base):
            raise typer.Exit(1)
        try:
            data = _get(f"/api/skills/{target}/validate")
        except Exception as exc:
            console.print(f"[red]API request failed:[/red] {exc}")
            raise typer.Exit(2) from exc
        _print_validation_report(data, show_warnings=show_warnings)
        raise typer.Exit(0 if data.get("valid") else 1)

    # ── Local path: validate without the server ────────────────────────────
    from agntspace.skills.spec_validator import (
        summarize_reports,
        validate_skill_directory,
        validate_skill_path,
    )

    p = P(target).resolve()
    if not p.exists():
        console.print(f"[red]Not found:[/red] {p}")
        raise typer.Exit(2)

    # If pointing at a directory that contains SKILL.md, validate that
    # one skill. If it doesn't, walk the tree.
    if p.is_dir() and (p / "SKILL.md").is_file():
        report = validate_skill_path(p)
        _print_validation_report(report.to_dict(), show_warnings=show_warnings)
        raise typer.Exit(0 if report.valid else 1)

    if p.is_dir():
        reports = validate_skill_directory(p)
        if not reports:
            console.print(f"[yellow]No SKILL.md files found under {p}[/yellow]")
            raise typer.Exit(0)
        invalid_paths: list[str] = []
        for r in reports:
            if not r.valid:
                invalid_paths.append(r.path)
                _print_validation_report(r.to_dict(), show_warnings=show_warnings)
        summary = summarize_reports(reports)
        console.print()
        if summary["invalid"] == 0:
            console.print(
                f"[green]OK {summary['valid']}/{summary['total']} skills valid "
                f"({summary['warnings']} warnings)[/green]"
            )
            raise typer.Exit(0)
        console.print(
            f"[red]FAIL {summary['invalid']}/{summary['total']} skills failed[/red] "
            f"({summary['errors']} errors, {summary['warnings']} warnings)"
        )
        raise typer.Exit(1)

    # Single file path
    report = validate_skill_path(p)
    _print_validation_report(report.to_dict(), show_warnings=show_warnings)
    raise typer.Exit(0 if report.valid else 1)


def _print_validation_report(data: dict, *, show_warnings: bool) -> None:
    """Render a ValidationReport dict to the console."""
    path = data.get("path", "?")
    valid = data.get("valid", False)
    errors = data.get("errors", []) or []
    warnings = data.get("warnings", []) or []

    color = "green" if valid else "red"
    mark = "OK" if valid else "FAIL"
    console.print(f"[bold {color}]{mark}[/bold {color}] {path}")

    for e in errors:
        field_str = f" [{e.get('field')}]" if e.get("field") else ""
        console.print(f"  [red]error[/red] {e.get('code')}{field_str}: {e.get('message')}")

    if show_warnings:
        for w in warnings:
            field_str = f" [{w.get('field')}]" if w.get("field") else ""
            console.print(
                f"  [yellow]warn[/yellow] {w.get('code')}{field_str}: {w.get('message')}"
            )


@app.command(name="agents-status")
def agents_status() -> None:
    """Show agent-sync status — how many agent definitions have shipped upgrades waiting."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _get("/api/orchestrator/agents/sync/status")
    console.print(f"Shipped agents tracked: [bold]{data.get('shipped_count', 0)}[/bold]")
    console.print(f"Accepted in vault:      [bold]{data.get('tracked', 0)}[/bold]")
    pending = data.get("pending_count", 0)
    color = "yellow" if pending else "green"
    console.print(f"Pending review:         [bold {color}]{pending}[/bold {color}]")
    for p in data.get("pending_paths", []):
        console.print(f"  - {p}")


@app.command(name="agents-sync")
def agents_sync(
    accept_all: bool = typer.Option(False, "--accept-all", help="Accept every shipped agent upgrade (destroys local edits)"),
    keep_mine: bool = typer.Option(False, "--keep-mine", help="Keep every local edit (dismisses pending upgrades)"),
) -> None:
    """Run an agent-sync pass. Without flags: shows what would happen.

    With --accept-all or --keep-mine: resolves every pending upgrade in bulk.
    Use the /agents/sync UI for per-file diff review.
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    if accept_all and keep_mine:
        console.print("[red]--accept-all and --keep-mine are mutually exclusive[/red]")
        raise typer.Exit(2)

    report = _post("/api/orchestrator/agents/sync/run", {})
    summary = report.get("summary", {})
    console.print("[bold]Agent sync pass:[/bold]")
    for k, v in summary.items():
        if v:
            console.print(f"  {k}: {v}")

    if not (accept_all or keep_mine):
        if report.get("pending"):
            console.print(
                f"\n[yellow]{len(report['pending'])} agent(s) need review.[/yellow] "
                f"Open [bold]/agents/sync[/bold] in the UI to diff, or rerun with "
                f"--accept-all / --keep-mine."
            )
        return

    pending_paths = list(report.get("pending", []))
    if not pending_paths:
        console.print("[green]Nothing pending.[/green]")
        return

    endpoint = "/api/orchestrator/agents/sync/accept" if accept_all else "/api/orchestrator/agents/sync/keep-mine"
    label = "accepted" if accept_all else "kept local edit"
    for path in pending_paths:
        try:
            _post(endpoint, {"path": path})
            console.print(f"  [green]{label}:[/green] {path}")
        except Exception as exc:
            console.print(f"  [red]failed:[/red] {path} — {exc}")


@app.command(name="kb-create")
def kb_create(
    topic: str = typer.Argument(..., help="Name/topic for the knowledge base"),
    description: str = typer.Option("", help="What this KB is about"),
    questions: list[str] = typer.Option([], "--question", "-q", help="Focus questions (repeat for multiple)"),
    source_types: list[str] = typer.Option([], "--source-type", "-s", help="Expected source types (repeat for multiple)"),
    notes: str = typer.Option("", help="Agent instructions for this domain"),
) -> None:
    """Create a new dedicated knowledge base."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/kb", {
        "topic": topic,
        "description": description,
        "focus_questions": questions,
        "source_types": source_types,
        "notes": notes,
    })
    console.print(f"[green]Created KB:[/green] {data.get('topic', topic)}")
    console.print(f"  Slug: [bold]{data.get('slug')}[/bold]")
    console.print(f"  Path: [dim]{data.get('path')}[/dim]")
    slug = data.get('slug', '')
    console.print(f"\n  Drop files into the KB inbox ([bold]agntspace-knowledge/{slug}/inbox/[/bold]) and run [bold]agntspace wiki-job --kb {slug}[/bold]")


@app.command(name="kb-repair-classifications")
def kb_repair_classifications(
    slug: str = typer.Option("", "--slug", help="KB slug; omit to scan every KB"),
    apply: bool = typer.Option(False, "--apply", help="Apply fixes (default is dry-run preview)"),
    no_llm: bool = typer.Option(False, "--no-llm", help="Skip LLM reclassification — only deterministic fixes (empty paths, L1-only, normalizer)"),
    limit: int = typer.Option(0, "--limit", help="Cap LLM-requiring articles per run (0 = no cap)"),
) -> None:
    """Sweep wiki articles to fix classification bugs across 6 classes:
    empty/L1-only/mismatched taxonomy_path, person-default in entities/ for
    non-personal-name titles (LLM reclassify, capable tier), subdir/etype
    mismatch (flagged), junk titles (email, sentence — flagged).

    Default is dry-run — passes ``--apply`` to write through update_article
    (contract-gated, auto-versioned). Idempotent."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    qp = []
    if not apply:
        qp.append("dry_run=true")
    else:
        qp.append("dry_run=false")
    if no_llm:
        qp.append("use_llm=false")
    if limit > 0:
        qp.append(f"limit={limit}")
    qs = "?" + "&".join(qp)
    path = f"/api/kb/{slug}/repair-classifications{qs}" if slug else f"/api/kb/repair-classifications{qs}"
    data = _post(path, {})
    if "error" in data:
        console.print(f"[red]Error:[/red] {data['error']}")
        raise typer.Exit(1)
    console.print(f"[bold]Scanned:[/bold] {data.get('scanned', 0)}")
    if data.get("dry_run"):
        console.print(f"[yellow]Pending fixes:[/yellow] {data.get('fixes_pending', 0)}")
        for f in data.get("pending", [])[:20]:
            old = f"{f['old_entity_type']}/{f['old_taxonomy_path']}"
            new = f"{f['new_entity_type']}/{f['new_taxonomy_path']}"
            llm = " [via LLM]" if f.get("used_llm") else ""
            console.print(f"  - {f['title']:<40} {old:<35} → {new}{llm}")
        if len(data.get("pending", [])) > 20:
            console.print(f"  ...and {len(data['pending']) - 20} more")
    else:
        console.print(f"[green]Applied fixes:[/green] {data.get('fixes_applied', 0)}")
    flags = data.get("flagged", [])
    if flags:
        console.print(f"\n[yellow]Flagged for manual review:[/yellow] {len(flags)}")
        for f in flags[:20]:
            console.print(f"  - {f['title']:<40} {f['issue']}")
    errors = data.get("error_details", [])
    if errors:
        console.print(f"\n[red]Errors:[/red] {len(errors)}")


@app.command(name="kb-repair-library-paths")
def kb_repair_library_paths(
    slug: str = typer.Option("", "--slug", help="KB slug; omit to scan every KB"),
    apply: bool = typer.Option(False, "--apply", help="Apply fixes (default is dry-run preview)"),
) -> None:
    """Repair phantom or non-canonical ``library_path`` frontmatter on
    wiki source pages — Problem C from the 2026-04-27 wiki classification
    overhaul.

    Walks every ``wiki/sources/*.md`` and resolves the recorded
    ``library_path`` against the live library/ tree. Phantom paths
    (legacy type-date layout that no longer exists on disk) are
    rewritten to vault-relative absolute form pointing at the actual
    file (matched by filename). Already-canonical entries are skipped
    (idempotent).

    Default is dry-run — passes ``--apply`` to write through
    update_article (contract-gated, auto-versioned)."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    qs = f"?dry_run={'false' if apply else 'true'}"
    path = (
        f"/api/kb/{slug}/repair-library-paths{qs}"
        if slug else
        f"/api/kb/repair-library-paths{qs}"
    )
    data = _post(path, {}, timeout=600)
    if "error" in data:
        console.print(f"[red]Error:[/red] {data['error']}")
        raise typer.Exit(1)
    console.print(f"[bold]Scanned:[/bold] {data.get('scanned', 0)}")
    if data.get("dry_run"):
        console.print(f"[yellow]Pending rewrites:[/yellow] {data.get('rewrites_pending', 0)}")
        for f in data.get("pending", [])[:20]:
            console.print(
                f"  - {f['title']:<40} {f['old_library_path']:<60} → {f['new_library_path']}"
            )
        if len(data.get("pending", [])) > 20:
            console.print(f"  ...and {len(data['pending']) - 20} more")
    else:
        console.print(f"[green]Applied rewrites:[/green] {data.get('rewrites_applied', 0)}")
    unresolved = data.get("unresolved", [])
    if unresolved:
        console.print(
            f"\n[yellow]Unresolved (file no longer in library/):[/yellow] {len(unresolved)}"
        )
        for u in unresolved[:10]:
            console.print(f"  - {u['title']:<40} (searched for: {u['filename_searched']})")
    errors = data.get("error_details", [])
    if errors:
        console.print(f"\n[red]Errors:[/red] {len(errors)}")


@app.command(name="kb-migrate-wiki-articles")
def kb_migrate_wiki_articles(
    slug: str = typer.Option("", "--slug", help="KB slug; omit to scan every KB"),
    apply: bool = typer.Option(False, "--apply", help="Apply moves (default is dry-run preview)"),
) -> None:
    """Move wiki articles to ``wiki/{taxonomy_path}/{title}.md`` based on
    frontmatter — the scope-2 structure refactor from the 2026-04-27 wiki
    classification overhaul.

    Run AFTER ``kb-repair-classifications --apply`` (taxonomy_path correct),
    ``kb-reorganize --execute`` (library matches), and
    ``kb-repair-library-paths --apply`` (frontmatter library_paths correct).

    Skips synthesis/, decisions/, projects/{slug}/ flat-exception subdirs.
    Backlinks unaffected. Idempotent."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    qs = f"?dry_run={'false' if apply else 'true'}"
    path = (
        f"/api/kb/{slug}/migrate-wiki-articles{qs}"
        if slug else
        f"/api/kb/migrate-wiki-articles{qs}"
    )
    data = _post(path, {}, timeout=600)
    if "error" in data:
        console.print(f"[red]Error:[/red] {data['error']}")
        raise typer.Exit(1)
    console.print(f"[bold]Scanned:[/bold] {data.get('scanned', 0)}")
    if data.get("dry_run"):
        console.print(f"[yellow]Pending moves:[/yellow] {data.get('moves_pending', 0)}")
        for m in data.get("pending", [])[:20]:
            console.print(f"  - {m['title']:<40} {m['old_path']:<60} → {m['new_path']}")
        if len(data.get("pending", [])) > 20:
            console.print(f"  ...and {len(data['pending']) - 20} more")
    else:
        console.print(f"[green]Applied moves:[/green] {data.get('moves_applied', 0)}")
    skipped = data.get("skipped", [])
    if skipped:
        console.print(f"\n[yellow]Skipped (deliberate or no usable taxonomy):[/yellow] {len(skipped)}")
        for s in skipped[:10]:
            console.print(f"  - {s['title']:<40} reason={s['reason']}")
    collisions = data.get("collisions", [])
    if collisions:
        console.print(f"\n[red]Collisions (target already exists):[/red] {len(collisions)}")
        for c in collisions[:10]:
            console.print(f"  - target {c.get('target', '?')}")
    errors = data.get("error_details", [])
    if errors:
        console.print(f"\n[red]Errors:[/red] {len(errors)}")


@app.command(name="kb-migrate-to-taxonomy")
def kb_migrate_to_taxonomy(
    slug: str = typer.Option("", "--slug", help="KB slug; omit to scan every KB"),
    apply: bool = typer.Option(False, "--apply", help="Apply migration (default is dry-run preview)"),
    no_llm: bool = typer.Option(False, "--no-llm", help="Skip LLM reclassification — only deterministic fixes"),
    limit: int = typer.Option(0, "--limit", help="Cap LLM-requiring articles per run (0 = no cap)"),
    no_follow: bool = typer.Option(False, "--no-follow", help="With --apply: queue the job and return immediately (don't poll)"),
) -> None:
    """Run the full scope-2 taxonomy migration end-to-end.

    Single-command orchestrator that runs all four phases sequentially:

      1. ``repair_classifications`` — Problems A + B (entity_type fixes
         + LLM source-deepening for source_summary at L1).
      2. ``reorganize_library`` — physical move of library/ files to
         ``library/{taxonomy_path}/{filename}``.
      3. ``repair_library_paths`` — Problem C (rewrite phantom
         ``library_path`` frontmatter to vault-relative absolute form).
      4. ``migrate_wiki_articles`` — physical move of wiki articles to
         ``wiki/{taxonomy_path}/{title}.md`` (scope-2 structure).

    Defaults to dry-run — pass ``--apply`` to execute. Idempotent —
    re-running after fixing an issue is safe.

    **--apply runs as a background job.** The CLI fires the job and
    polls the JobRegistry for live progress. Press Ctrl-C to detach
    (the job keeps running). Reattach later with
    ``agntspace job-status <job_id>`` or cancel with
    ``agntspace job-cancel <job_id>``. ``--no-follow`` queues and exits."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    qp = []
    qp.append(f"dry_run={'false' if apply else 'true'}")
    if no_llm:
        qp.append("use_llm=false")
    if limit > 0:
        qp.append(f"limit={limit}")
    qs = "?" + "&".join(qp)
    path = (
        f"/api/kb/{slug}/migrate-to-taxonomy{qs}"
        if slug else
        f"/api/kb/migrate-to-taxonomy{qs}"
    )

    if not apply:
        # Dry-run is synchronous (fast preview). Same shape as before.
        data = _post(path, {}, timeout=300)
        _render_taxonomy_migration_report(data)
        return

    # Apply mode: kick off async job, then poll.
    queued = _post(path, {}, timeout=30)
    if "error" in queued:
        console.print(f"[red]Error:[/red] {queued['error']}")
        raise typer.Exit(1)
    job_id = queued.get("job_id")
    if not job_id:
        console.print(f"[red]Error:[/red] Server did not return a job_id: {queued}")
        raise typer.Exit(1)
    console.print(
        f"[green]Migration queued[/green] "
        f"[cyan]job_id={job_id}[/cyan] kind={queued.get('kind', 'kb_migrate_to_taxonomy')}"
    )
    if no_follow:
        console.print(
            f"[dim]Detached. Reattach with:[/dim] agntspace job-status {job_id}"
        )
        return
    try:
        _follow_job(base, job_id, render_terminal=_render_taxonomy_migration_report)
    except KeyboardInterrupt:
        console.print(
            f"\n[yellow]Detached.[/yellow] "
            f"Reattach: agntspace job-status {job_id}"
        )


def _render_taxonomy_migration_report(data: dict) -> None:
    """Pretty-print the per-phase migration report — same shape whether
    the source is a dry-run dict or the result of a completed background
    job. Tolerates partial results (cancelled / failed)."""
    if data.get("error"):
        console.print(f"[red]Error:[/red] {data['error']}")
    summary = data.get("summary") or {}
    console.print(f"[bold]Scanned:[/bold] {summary.get('scanned', 0)} articles")
    if data.get("dry_run"):
        console.print(
            f"[yellow]Total changes pending across all phases:[/yellow] "
            f"{summary.get('changes_pending', 0)}"
        )
    else:
        console.print(
            f"[green]Total changes applied across all phases:[/green] "
            f"{summary.get('changes_applied', 0)}"
        )
    if summary.get("errors"):
        console.print(f"[red]Errors:[/red] {summary['errors']}")
    if data.get("cancelled"):
        completed = summary.get("phases_completed", len(data.get("phases", [])))
        console.print(f"[yellow]Cancelled after {completed} of 5 phases.[/yellow]")
    console.print()
    for phase in data.get("phases", []):
        name = phase.get("name", "?")
        result = phase.get("result", {})
        if "error" in result:
            console.print(f"  [red]✗[/red] {name}: {result['error']}")
            continue
        if name == "rename_source_summary_to_digest":
            console.print(
                f"  [cyan]0.[/cyan] {name}: scanned {result.get('scanned', 0)}, "
                f"{'pending ' + str(result.get('renames_pending', 0)) if data.get('dry_run') else 'applied ' + str(result.get('renames_applied', 0))}"
            )
        elif name == "repair_classifications":
            console.print(
                f"  [cyan]1.[/cyan] {name}: scanned {result.get('scanned', 0)}, "
                f"{'pending ' + str(result.get('fixes_pending', 0)) if data.get('dry_run') else 'applied ' + str(result.get('fixes_applied', 0))}"
            )
        elif name == "reorganize_library":
            if "per_kb" in result:
                total_moves = sum(
                    len(k.get("moves", [])) if data.get("dry_run") else k.get("executed", 0)
                    for k in result["per_kb"]
                )
                console.print(
                    f"  [cyan]2.[/cyan] {name}: {len(result['per_kb'])} KB(s), "
                    f"{'pending ' + str(total_moves) if data.get('dry_run') else 'executed ' + str(total_moves)} file moves"
                )
            else:
                count = len(result.get("moves", [])) if data.get("dry_run") else result.get("executed", 0)
                console.print(
                    f"  [cyan]2.[/cyan] {name}: "
                    f"{'pending ' + str(count) if data.get('dry_run') else 'executed ' + str(count)} file moves"
                )
        elif name == "repair_library_paths":
            console.print(
                f"  [cyan]3.[/cyan] {name}: scanned {result.get('scanned', 0)}, "
                f"{'pending ' + str(result.get('rewrites_pending', 0)) if data.get('dry_run') else 'applied ' + str(result.get('rewrites_applied', 0))}, "
                f"unresolved {result.get('unresolved_count', 0)}"
            )
        elif name == "migrate_wiki_articles":
            console.print(
                f"  [cyan]4.[/cyan] {name}: scanned {result.get('scanned', 0)}, "
                f"{'pending ' + str(result.get('moves_pending', 0)) if data.get('dry_run') else 'applied ' + str(result.get('moves_applied', 0))}, "
                f"collisions {result.get('collisions_count', 0)}"
            )


def _follow_job(base: str, job_id: str, *, render_terminal=None) -> None:
    """Poll /api/jobs/{job_id} and print live progress until terminal.

    ``render_terminal``: optional callable invoked with the result dict
    when the job completes — used to render kind-specific summaries.

    Carriage-return line refresh, no rich progress bar (works inside
    subprocess captures, docker logs, SSH sessions).
    """
    import sys
    import time

    bar_width = 24
    while True:
        data = _get(f"/api/jobs/{job_id}")
        if not data:
            console.print(f"\n[red]Job not found:[/red] {job_id}")
            return
        if isinstance(data, dict) and data.get("detail") and "state" not in data:
            console.print(f"\n[red]{data['detail']}[/red]")
            return
        state = data.get("state", "?")
        phase = data.get("phase", "") or "—"
        processed = data.get("processed", 0)
        total = data.get("total", 0)
        ratio = data.get("progress_ratio", 0.0) or 0.0
        eta = data.get("eta_s")
        eta_s = f"ETA {int(eta)}s" if isinstance(eta, (int, float)) else "ETA —"
        filled = int(bar_width * ratio) if total else 0
        bar = "█" * filled + "░" * (bar_width - filled)
        line = (
            f"[{bar}] {processed}/{total or '?'}  "
            f"{state}  {eta_s}  [{phase[:60]}]"
        )
        sys.stdout.write("\r" + line.ljust(120))
        sys.stdout.flush()

        if state in {"completed", "failed", "cancelled"}:
            sys.stdout.write("\n")
            sys.stdout.flush()
            if state == "completed":
                console.print(f"[bold green]Completed[/bold green]  job_id={job_id}")
            elif state == "cancelled":
                console.print(f"[yellow]Cancelled[/yellow]  job_id={job_id}")
            else:
                console.print(
                    f"[red]Failed[/red]  job_id={job_id}  reason={data.get('error', 'unknown')}"
                )
            if render_terminal is not None:
                result = data.get("result") or {}
                if result:
                    console.print()
                    render_terminal(result)
            return
        time.sleep(1.0)


@app.command(name="job-status")
def job_status_cmd(
    job_id: str = typer.Argument(..., help="Job id returned by an async-job command"),
    follow: bool = typer.Option(True, "--follow/--no-follow", help="Poll until terminal (default) or print snapshot once"),
) -> None:
    """Get the status of a background job — or follow it until done."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    if not follow:
        data = _get(f"/api/jobs/{job_id}")
        if not data or (data.get("detail") and "state" not in data):
            console.print(f"[red]Job not found:[/red] {job_id}")
            raise typer.Exit(1)
        console.print(
            f"[bold]{data.get('kind', '?')}[/bold] {job_id}  "
            f"state={data.get('state', '?')}  "
            f"phase={data.get('phase') or '—'}  "
            f"{data.get('processed', 0)}/{data.get('total', 0)}"
        )
        if data.get("error"):
            console.print(f"[red]Error:[/red] {data['error']}")
        return
    try:
        _follow_job(base, job_id)
    except KeyboardInterrupt:
        console.print("\n[yellow]Detached.[/yellow]")


@app.command(name="job-cancel")
def job_cancel_cmd(
    job_id: str = typer.Argument(..., help="Job id to cancel"),
) -> None:
    """Request cooperative cancellation of a background job. The worker
    exits cleanly at its next checkpoint, leaving the vault in a
    coherent state."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _delete(f"/api/jobs/{job_id}")
    if not data or "error" in data:
        msg = (data or {}).get("error", "no response")
        console.print(f"[red]Error:[/red] {msg}")
        raise typer.Exit(1)
    if data.get("cancelled"):
        console.print(f"[yellow]Cancel requested[/yellow]  job_id={job_id}")
    else:
        console.print(
            f"[dim]Could not cancel[/dim]  job_id={job_id}  "
            f"state={data.get('state', '?')}"
        )


@app.command(name="job-list")
def job_list_cmd(
    kind: str = typer.Option("", "--kind", help="Filter by job kind (e.g. kb_migrate_to_taxonomy)"),
    active: bool = typer.Option(False, "--active", help="Only show running/pending jobs"),
    limit: int = typer.Option(20, "--limit", help="Max jobs to show"),
) -> None:
    """List recent background jobs — newest first."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    if active:
        data = _get("/api/jobs/active")
    else:
        qs = []
        if limit:
            qs.append(f"limit={limit}")
        if kind:
            qs.append(f"kind={kind}")
        path = "/api/jobs" + ("?" + "&".join(qs) if qs else "")
        data = _get(path)
    if not data:
        console.print("[red]Could not reach /api/jobs[/red]")
        raise typer.Exit(1)
    jobs = data.get("jobs", [])
    if not jobs:
        console.print("[dim]No jobs.[/dim]")
        return
    for j in jobs:
        ratio = j.get("progress_ratio", 0.0)
        pct = f"{int(ratio * 100):>3d}%"
        console.print(
            f"  {j.get('job_id', '?'):<12} "
            f"{j.get('kind', '?'):<28} "
            f"{j.get('state', '?'):<10} "
            f"{pct} "
            f"[dim]{j.get('phase') or ''}[/dim]"
        )


@app.command(name="kb-layout")
def kb_layout(
    slug: str = typer.Argument(..., help="KB slug"),
    set_to: str = typer.Option("", "--set", help="New layout: thematic | type-date | flat"),
) -> None:
    """Get or change the library layout for a KB.

    Without ``--set``, prints the current layout. With ``--set`` writes it
    to SCHEMA.md. Does NOT move existing files — run ``agntspace kb-reorganize``
    to apply the new layout to library/.
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    if not set_to:
        data = _get(f"/api/kb/{slug}/library/layout")
        console.print(f"Current layout for [cyan]{slug}[/cyan]: [bold]{data.get('layout')}[/bold]")
        return
    data = _put(f"/api/kb/{slug}/library/layout", {"layout": set_to})
    console.print(f"[green]Layout changed:[/green] {data.get('previous')} → [bold]{data.get('layout')}[/bold]")
    console.print("  Existing files were not moved. Run [bold]agntspace kb-reorganize " + slug + "[/bold] to apply.")


@app.command(name="kb-reorganize")
def kb_reorganize(
    slug: str = typer.Argument(..., help="KB slug"),
    execute: bool = typer.Option(False, "--execute", help="Execute the moves (omit for dry-run preview)"),
) -> None:
    """Reorganize a KB's library/ to match its current layout setting.

    Defaults to dry-run: shows the proposed moves without touching disk.
    Add ``--execute`` to actually move files. Per-file activity events
    are emitted; existing files are never overwritten (collisions become
    errors).
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post(f"/api/kb/{slug}/library/reorganize", {"dry_run": not execute})
    layout = data.get("layout", "?")
    moves = data.get("moves", [])
    console.print(f"Layout: [bold]{layout}[/bold]")
    if not moves:
        console.print("[green]Already organized — nothing to move.[/green]")
        return
    if not execute:
        console.print(f"\n[yellow]Dry-run:[/yellow] {len(moves)} file(s) would move")
    else:
        executed = data.get("executed", 0)
        errors = data.get("errors", [])
        console.print(f"\n[green]Executed:[/green] {executed} / {len(moves)} move(s)")
        if errors:
            console.print(f"[red]Errors ({len(errors)}):[/red]")
            for err in errors[:10]:
                console.print(f"  - {err.get('file', '?')}: {err.get('reason', '?')}")
    table = Table(title="Moves" if execute else "Proposed moves")
    table.add_column("From", style="dim")
    table.add_column("To", style="cyan")
    table.add_column("Fallback", style="yellow")
    for m in moves[:50]:
        table.add_row(m.get("from", ""), m.get("to", ""), m.get("fallback_reason", "") or "-")
    console.print(table)
    if len(moves) > 50:
        console.print(f"  … and {len(moves) - 50} more")
    if not execute and moves:
        console.print(f"\n  Run [bold]agntspace kb-reorganize {slug} --execute[/bold] to apply.")


@app.command(name="kb-language-drift")
def kb_language_drift(
    slug: str = typer.Option("", help="Restrict to one KB slug (default: all KBs)"),
    reingest: bool = typer.Option(False, "--reingest", help="Actually re-ingest drifted sources (omit for dry-run)"),
) -> None:
    """List (or re-ingest) source pages whose recorded language policy
    no longer matches the current effective policy.

    Spec §19 item 3 — after changing a language policy at any layer (config,
    skill, SCHEMA, or frontmatter), use this to find pages that were written
    under the old policy and optionally re-process them.
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    if reingest:
        params = f"?slug={slug}" if slug else ""
        data = _post(f"/api/kb/language-drift/reingest{params}", {})
        console.print(f"[green]Drifted sources:[/green] {data.get('drifted_count', 0)}")
        console.print(f"[green]Re-queued:[/green] {data.get('requeued', 0)}")
        kbs = data.get("kbs_ingested", [])
        if kbs:
            console.print(f"[green]Re-ingested KBs:[/green] {', '.join(kbs)}")
        errors = data.get("errors", [])
        if errors:
            console.print(f"[red]Errors ({len(errors)}):[/red]")
            for err in errors[:10]:
                console.print(f"  - {err}")
        return

    # Dry run — just list drifted pages
    params = {"slug": slug} if slug else None
    data = _get("/api/kb/language-drift", params=params)
    drifted = data.get("drifted", [])
    scanned = data.get("scanned", 0)
    if not drifted:
        console.print(f"[green]No drifted sources.[/green] Scanned {scanned} source page(s).")
        return
    table = Table(title=f"Language policy drift ({len(drifted)} / {scanned} scanned)")
    table.add_column("KB", style="cyan")
    table.add_column("Source")
    table.add_column("Recorded", style="dim")
    table.add_column("Current", style="green")
    for entry in drifted:
        rec = entry.get("recorded", {})
        cur = entry.get("current", {})
        table.add_row(
            entry.get("kb", ""),
            entry.get("source", ""),
            f"{rec.get('output_lang', '')}/{rec.get('policy', '')} ({rec.get('source', '')})",
            f"{cur.get('output_lang', '')}/{cur.get('policy', '')} ({cur.get('source', '')})",
        )
    console.print(table)
    console.print("\n  Run [bold]agntspace kb-language-drift --reingest[/bold] to re-process them.")


# ═══════════════════════════════════════════
# MEMORY
# ═══════════════════════════════════════════


@app.command()
def memory(
    generate: bool = typer.Option(False, help="Generate today's memory"),
    compact: bool = typer.Option(False, help="Run temporal compaction"),
    layer: str = typer.Option(
        "",
        help="With --compact, run only the named layer (week/month/quarter/year/longterm). "
             "Empty = compact all layers bottom-up.",
    ),
) -> None:
    """Show permanent memory, or generate/compact.

    ``--compact`` runs full bottom-up compaction (assembles MEMORY.md).
    ``--compact --layer week`` runs ONE layer synchronously — handy for
    debugging or for the curator workflow ("compact just this layer
    after I edited its source data").
    """
    base = _get_base_url()
    if not _check_server(base):
        return
    if generate:
        data = _post("/api/memory/generate", timeout=120)
        console.print(f"[green]Generated:[/green] {data.get('path', '?')}")
        return
    if compact:
        valid = ("week", "month", "quarter", "year", "longterm")
        if layer and layer not in valid:
            console.print(
                f"[red]Invalid layer:[/red] {layer}. Must be one of: {', '.join(valid)}"
            )
            raise typer.Exit(code=2)
        params: dict | None = {"layer": layer} if layer else None
        # Single-layer is fast (~5s); full bottom-up cascade can take 60s+.
        timeout = 60 if layer else 180
        data = _post("/api/memory/compact", params=params, timeout=timeout)
        scope = layer if layer else "all layers"
        console.print(f"[green]Compacted[/green] ({scope}). {data.get('status', '')}")
        return
    data = _get("/api/memory/permanent/read")
    if data.get("content"):
        console.print(data["content"])
    else:
        console.print("[dim]No permanent memory yet.[/dim]")


@app.command(name="memory-archives")
def memory_archives(
    layer: str = typer.Option(
        "week",
        help="Archive layer: week / month / quarter / year (longterm has no archives).",
    ),
    limit: int = typer.Option(20, help="Max archives to show, newest first."),
) -> None:
    """List archived period summaries for a memory layer.

    Memory compaction produces both a rolling summary (the current
    ``summaries/<layer>.md``) AND a dated archive file
    (``summaries/<layer>/<period>.md``). This command lists the
    archives — the permanent record of what each period contained.

    Periods: week=YYYY-Www, month=YYYY-MM, quarter=YYYY-Qn, year=YYYY.
    """
    base = _get_base_url()
    if not _check_server(base):
        return
    valid = ("week", "month", "quarter", "year")
    if layer not in valid:
        console.print(
            f"[red]Invalid layer:[/red] {layer}. Must be one of: {', '.join(valid)}. "
            f"(longterm has no archives.)"
        )
        raise typer.Exit(code=2)
    data = _get(f"/api/memory/archives/{layer}", {"limit": limit})
    items = data.get("items", []) if isinstance(data, dict) else []
    if not items:
        console.print(f"[dim]No archives yet for layer '{layer}'.[/dim]")
        return
    console.print(f"\n[bold]Memory archives — {layer} (newest first)[/bold]")
    for entry in items:
        period = entry.get("period", "?")
        date = entry.get("date", "")
        size = entry.get("size", 0)
        suffix = f" — {date}" if date else ""
        console.print(f"  {period:<14} {size:>6} bytes{suffix}")
    total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
    has_more = data.get("has_more", False) if isinstance(data, dict) else False
    if has_more:
        console.print(
            f"\n[dim]Showing {total} of more. Pass --limit N for more.[/dim]"
        )
    console.print()


@app.command(name="memory-archive-read")
def memory_archive_read(
    layer: str = typer.Argument(..., help="Layer: week / month / quarter / year."),
    period: str = typer.Argument(
        ...,
        help="Period label. week=YYYY-Www (e.g. 2026-W15), month=YYYY-MM, "
             "quarter=YYYY-Qn (e.g. 2026-Q2), year=YYYY.",
    ),
) -> None:
    """Print a specific memory archive file."""
    base = _get_base_url()
    if not _check_server(base):
        return
    valid = ("week", "month", "quarter", "year")
    if layer not in valid:
        console.print(
            f"[red]Invalid layer:[/red] {layer}. Must be one of: {', '.join(valid)}."
        )
        raise typer.Exit(code=2)
    data = _get(f"/api/memory/archives/{layer}/{period}")
    if not data.get("exists"):
        console.print(
            f"[dim]No archive at {layer}/{period}. "
            f"Run `agntspace memory-archives --layer {layer}` to see what's available.[/dim]"
        )
        raise typer.Exit(code=1)
    date = data.get("date", "")
    model = data.get("model", "")
    header = f"\n[bold]{layer} archive — {period}[/bold]"
    if date or model:
        meta = " · ".join(filter(None, [date, f"model: {model}" if model else ""]))
        header += f"\n[dim]{meta}[/dim]"
    console.print(header)
    console.print(data.get("content", ""))
    console.print()


@app.command(name="stale-claims")
def stale_claims(
    threshold_months: int = typer.Option(
        6,
        help="Minimum age in months for 'stale'. Default 6 — the "
             "knowledge-rots window. Set 0 to list every (as of YYYY-MM) "
             "marker regardless of age.",
    ),
    limit: int = typer.Option(
        50,
        help="Max claims to show, oldest first. Set 0 for unlimited.",
    ),
) -> None:
    """List wiki claims with `(as of YYYY-MM)` markers older than N months.

    Wiki articles carry inline recency markers next to date-sensitive
    claims (financials, headcount, product status, etc.). This command
    surfaces the ones that have crossed the staleness threshold so you
    can review what knowledge has gone stale.

    Future iterations will auto-re-research one per day via heartbeat
    (P3.7 in plan-performance-roadmap.md); today the action is yours.
    """
    base = _get_base_url()
    if not _check_server(base):
        return
    if threshold_months < 0:
        console.print("[red]threshold_months must be >= 0[/red]")
        raise typer.Exit(code=2)
    data = _get(
        "/api/research/stale-claims",
        {"threshold_months": threshold_months, "limit": limit},
    )
    if not isinstance(data, dict):
        console.print("[red]Unexpected response shape from /stale-claims.[/red]")
        raise typer.Exit(code=1)
    items = data.get("items", [])
    if not items:
        msg = (
            f"[dim]No stale claims at threshold {threshold_months} months.[/dim]"
            if threshold_months > 0
            else "[dim]No (as of YYYY-MM) markers found in wiki articles.[/dim]"
        )
        console.print(msg)
        return
    scope = "all markers" if threshold_months == 0 else f"≥ {threshold_months} months old"
    console.print(f"\n[bold]Stale claims ({scope})[/bold]  · {len(items)} shown")
    for claim in items:
        label = claim.get("marker_label", "?")
        age = claim.get("age_months", 0)
        path = claim.get("article_path", "?").replace("\\", "/")
        line_no = claim.get("line_number", 0)
        line = claim.get("line_text", "")
        source = claim.get("marker_source", "")
        source_suffix = f"  [dim]source: {source}[/dim]" if source else ""
        # Truncate long line text for terminal display.
        snippet = line if len(line) <= 100 else line[:97] + "..."
        console.print(
            f"  [yellow]{label}[/yellow] ({age:>2}mo)  "
            f"[dim]{path}:{line_no}[/dim]{source_suffix}"
        )
        console.print(f"    {snippet}")
    if data.get("has_more"):
        console.print(
            f"\n[dim]Showing {len(items)} oldest. Pass --limit N for more.[/dim]"
        )
    console.print()


# ═══════════════════════════════════════════
# COSTS
# ═══════════════════════════════════════════


@app.command()
def costs(
    days: int = typer.Option(7, help="Period in days"),
) -> None:
    """Show cost tracking summary."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/costs", {"days": days})
    budget = _get("/api/costs/budget")
    console.print(f"\n[bold]Cost Summary ({days} days)[/bold]")
    console.print(f"  Total: ${data.get('total_cost', 0):.2f}  |  Requests: {data.get('total_requests', 0)}")
    console.print(f"  Today: ${budget.get('daily_cost', 0):.2f} / ${budget.get('daily_budget', 10):.2f}")
    console.print(f"  Month: ${budget.get('monthly_cost', 0):.2f} / ${budget.get('monthly_budget', 100):.2f}")
    by_model = data.get("by_model", {})
    if by_model:
        console.print("\n  By model:")
        for model, info in by_model.items():
            console.print(f"    {model}: ${info['cost']:.2f} ({info['requests']} calls)")
    console.print()


# ═══════════════════════════════════════════
# CONTRACT
# ═══════════════════════════════════════════


@app.command()
def contract() -> None:
    """Show contract permissions summary."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/contract/structured")
    perms = data.get("permissions", {})
    settings = data.get("settings", {})
    console.print("\n[bold]Contract[/bold]")
    console.print(f"  Privacy: {settings.get('privacy_mode', '?')}  |  Proactivity: {settings.get('proactivity', '?')}")
    console.print(f"  Allowed: {len(perms.get('allow', []))}  |  Confirm: {len(perms.get('confirm', []))}  |  Blocked: {len(perms.get('block', []))}")
    if perms.get("block"):
        console.print(f"  Blocked: {', '.join(perms['block'])}")
    console.print()


# ═══════════════════════════════════════════
# SEARCH
# ═══════════════════════════════════════════


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(10, help="Max results"),
) -> None:
    """Search the vault."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/search", {"q": query, "limit": limit})
    if not data:
        console.print(f"[dim]No results for '{query}'[/dim]")
        return
    for r in data:
        console.print(f"  [bold]{r.get('title', r.get('path', '?'))}[/bold]")
        if r.get("snippet"):
            console.print(f"    {r['snippet'][:100]}")


# ═══════════════════════════════════════════
# EMERGENCY
# ═══════════════════════════════════════════


@app.command(name="emergency-stop")
def emergency_stop() -> None:
    """Halt all agent activity immediately."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    _post("/api/emergency-stop")
    console.print("[red bold]AGENT FROZEN — all activity halted.[/red bold]")


@app.command()
def resume() -> None:
    """Resume agent after emergency stop."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    _post("/api/resume")
    console.print("[green]Agent resumed.[/green]")


# ═══════════════════════════════════════════
# UTILITIES
# ═══════════════════════════════════════════


@app.command()
def forget(
    topic: str = typer.Argument(..., help="Topic to purge from search index"),
) -> None:
    """Purge a topic from the search index."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    results = _get("/api/search", {"q": topic, "limit": 20})
    console.print(f"Found {len(results)} matching files.")
    _post("/api/search/reindex", timeout=30)
    console.print("[green]Search index rebuilt.[/green]")


@app.command()
def reindex() -> None:
    """Rebuild the vault search index."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/search/reindex", timeout=60)
    console.print(f"[green]Reindexed {data.get('indexed', 0)} files.[/green]")


@app.command()
def export(
    output: str = typer.Option("agntspace-export.tar.gz", help="Output file"),
) -> None:
    """Export all user data as a portable archive."""
    import shutil

    from agntspace.infra.config import get_settings
    settings = get_settings()
    if not settings.home_dir.exists():
        console.print("[red]Nothing to export.[/red]")
        raise typer.Exit(1)
    output_path = Path(output).with_suffix("")
    shutil.make_archive(str(output_path), "gztar", str(settings.home_dir.parent), settings.home_dir.name)
    console.print(f"[green]Exported to {output_path.with_suffix('.tar.gz')}[/green]")


@app.command()
def audit(
    today: bool = typer.Option(False, help="Only today's entries"),
    limit: int = typer.Option(20, help="Max entries"),
) -> None:
    """Show audit log."""
    base = _get_base_url()
    if not _check_server(base):
        return
    endpoint = "/api/audit/today" if today else f"/api/audit?limit={limit}"
    entries = _get(endpoint)
    if not entries:
        console.print("[dim]No audit entries.[/dim]")
        return
    table = Table(title="Audit Trail")
    table.add_column("Time", style="dim")
    table.add_column("Action")
    table.add_column("Target")
    table.add_column("Approved")
    for e in entries:
        table.add_row(e.get("ts", "")[:19], e.get("action", ""), e.get("target", ""), e.get("approved", ""))
    console.print(table)


@app.command()
def autopilot(
    on: bool = typer.Option(False, help="Enable"),
    off: bool = typer.Option(False, help="Disable"),
) -> None:
    """Enable/disable/check autopilot."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if on:
        _post("/api/autopilot", {"enabled": True})
        console.print("[green]Autopilot ON[/green]")
    elif off:
        _post("/api/autopilot", {"enabled": False})
        console.print("[green]Autopilot OFF[/green]")
    else:
        data = _get("/api/autopilot")
        console.print(f"Autopilot: {'[green]ON[/green]' if data.get('enabled') else '[red]OFF[/red]'}")


@app.command(name="obsidian")
def obsidian_cmd(
    path: str = typer.Argument(..., help="Path to Obsidian vault"),
) -> None:
    """Connect to an Obsidian vault (direct mode).

    Prefers the REST endpoint (`POST /api/sync/adopt`) when the server is
    running so the action flows through contract enforcement and emits a
    user-activity event. Falls back to direct VaultSync when the server is
    down (first-run bootstrap).
    """
    obs_path = Path(path).expanduser().resolve()
    if not obs_path.is_dir():
        console.print(f"[red]Path does not exist: {obs_path}[/red]")
        raise typer.Exit(1)

    base = _get_base_url()
    if _check_server(base):
        # Server is up — go through the REST API so middleware logs the action
        result = _post("/api/sync/adopt", {"path": str(obs_path)})
        if isinstance(result, dict) and "error" in result:
            console.print(f"[red]{result['error']}[/red]")
            raise typer.Exit(1)
        console.print(f"[green]Connected to {obs_path} (server will restart)[/green]")
        return

    # Server down — direct mode (first-run bootstrap)
    from agntspace.infra.config import get_settings
    from agntspace.infra.settings_service import SettingsService
    from agntspace.vault.sync import VaultSync

    settings = get_settings()
    sync = VaultSync(vault_dir=settings.vault_dir)
    result = sync.adopt_obsidian_vault(str(obs_path))
    if "error" in result:
        console.print(f"[red]{result['error']}[/red]")
        raise typer.Exit(1)
    svc = SettingsService(settings.config_path)
    svc.update_section("sync", {"mode": "direct", "external_path": str(obs_path)})
    console.print(f"[green]Connected to {obs_path}[/green]")
    console.print("[dim]Start the server with: agntspace start[/dim]")


@app.command(name="mcp-serve")
def mcp_serve_cmd() -> None:
    """Run AgntSpace as an MCP server over stdio.

    Exposes vault memory, knowledge graph, tasks, projects, goals, journal
    and KB query tools to any MCP-compatible client (Claude Desktop,
    Cursor, IDE extensions).

    Not for interactive use. Wire it into your MCP client config, e.g.:

        {
          "mcpServers": {
            "agntspace": {
              "command": "agntspace",
              "args": ["mcp-serve"]
            }
          }
        }
    """
    from agntspace.mcp.__main__ import main as _mcp_main
    _mcp_main()


@app.command(name="install-daemon")
def install_daemon_cmd(
    host: str = typer.Option("127.0.0.1"),
    port: int = typer.Option(
        8000,
        help=(
            "Base port. Singleton mode: AgntSpace serves on this port. "
            "Split mode: web=port, worker=port+1, scheduler=port+2."
        ),
    ),
    mode: str = typer.Option(
        "singleton",
        "--mode",
        help=(
            "Install shape: 'singleton' (one daemon, default) or 'split' "
            "(three daemons — web/worker/scheduler — for Phase 2 process split)."
        ),
    ),
) -> None:
    """Install as per-user autostart service.

    Singleton (default) registers ONE daemon running 'agntspace start'.

    Split registers THREE daemons ('agntspace web/worker/scheduler') for
    the Phase 2 process split. After --mode split, set process_mode = "web"
    under the system block in ~/.agntspace/config.toml so the web daemon
    doesn't try to drain the work queue itself.
    """
    from agntspace.automation.daemon import install_daemon
    console.print(install_daemon(host=host, port=port, mode=mode))


@app.command(name="uninstall-daemon")
def uninstall_daemon_cmd() -> None:
    """Remove ALL AgntSpace autostart entries (singleton + any split kinds).

    Idempotent. Missing entries report cleanly. The user doesn't need to
    know which mode is currently installed.
    """
    from agntspace.automation.daemon import uninstall_daemon
    console.print(uninstall_daemon())


@app.command(name="daemon-status")
def daemon_status_cmd() -> None:
    """Check daemon status. Reports per-kind state in split mode."""
    from agntspace.automation.daemon import daemon_status
    info = daemon_status()
    mode = info.get("mode", "none")
    console.print(
        f"Mode: {mode}  |  Installed: {'Yes' if info['installed'] else 'No'}"
        f"  |  Running: {'Yes' if info['running'] else 'No'}"
    )
    entries = info.get("entries", [])
    # Show per-kind detail when in split or mixed mode (singleton-only is
    # already covered by the top line).
    if mode in ("split", "mixed"):
        for entry in entries:
            installed = "Yes" if entry["installed"] else "No"
            running = "Yes" if entry["running"] else "No"
            console.print(
                f"  - {entry['kind']:10s} ({entry['name']:25s}): "
                f"installed={installed}  running={running}"
            )


# ═══════════════════════════════════════════
# ADDITIONAL COMMANDS
# ═══════════════════════════════════════════


@app.command()
def restart(
    host: str = typer.Option("127.0.0.1", help="Bind address"),
    port: int = typer.Option(8000, help="Port"),
) -> None:
    """Stop and restart the AgntSpace server."""
    import subprocess
    import sys
    import time
    # Stop first
    stop()
    time.sleep(2)
    cmd = ["agntspace", "start", "--host", host, "--port", str(port)]
    if sys.platform == "win32":
        # Windows: spawn in a new console window so the user sees logs
        subprocess.Popen(
            cmd,
            creationflags=subprocess.CREATE_NEW_CONSOLE,  # type: ignore[attr-defined]
        )
        console.print("[green]Restarting in new window...[/green]")
    else:
        # macOS / Linux: detach from the current shell so the server keeps
        # running after this command returns. Logs go to ~/.agntspace/logs/.
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        console.print(f"[green]Restarting AgntSpace on http://{host}:{port}[/green]")
        console.print("[dim]Server detached — logs at ~/.agntspace/logs/agntspace.log[/dim]")


@app.command()
def version() -> None:
    """Show AgntSpace version."""
    from agntspace.api.routes.health import _get_version
    console.print(f"AgntSpace v{_get_version()}")


@app.command()
def graph(
    entity: str | None = typer.Argument(None, help="Entity to look up"),
    path_to: str | None = typer.Option(None, "--path-to", help="Find path to another entity"),
) -> None:
    """Query the knowledge graph."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if entity and path_to:
        data = _get(f"/api/graph/path/{entity}/{path_to}")
        paths = data.get("paths", [])
        if not paths:
            console.print(f"[dim]No path between {entity} and {path_to}[/dim]")
            return
        for p in paths:
            console.print(" -> ".join(p))
        return
    if entity:
        data = _get(f"/api/graph/entity/{entity}/triples")
        if not data.get("found"):
            console.print(f"[dim]No data for '{entity}'[/dim]")
            return
        ent = data.get("entity", {})
        console.print(f"\n[bold]{ent.get('name', entity)}[/bold] ({ent.get('type', '?')})")
        for pred, facts in data.get("facts", {}).items():
            for f in facts:
                console.print(f"  {pred}: {f.get('value', '?')}  [dim]({f.get('authority', '?')})[/dim]")
        console.print()
        return
    # No args — show stats
    stats = _get("/api/graph/stats")
    console.print("\n[bold]Knowledge Graph[/bold]")
    console.print(f"  Nodes: {stats.get('total_nodes', 0)}  |  Edges: {stats.get('total_edges', 0)}")
    console.print(f"  Wiki entities: {stats.get('wiki_entities', 0)}  |  Files: {stats.get('files', 0)}")
    console.print(f"  Wikilink edges: {stats.get('wikilink_edges', 0)}  |  SPO edges: {stats.get('spo_edges', 0)}")
    console.print()


@app.command()
def workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID (e.g. wiki-management, daily-cycle)"),
    context: str = typer.Option("", help="Additional context for the workflow"),
) -> None:
    """Run a supervisor-driven workflow."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    console.print(f"[dim]Running workflow: {workflow_id}...[/dim]")
    data = _post(f"/api/orchestrator/workflow/{workflow_id}", {"context": context} if context else None, timeout=300)
    console.print(f"[green]Done.[/green] Status: {data.get('status', '?')}")
    steps = data.get("steps_completed", [])
    if steps:
        for s in steps:
            console.print(f"  {s}")
    console.print()


@app.command()
def scrape(
    url: str = typer.Argument(..., help="URL to scrape"),
    kb: str = typer.Option("main", help="Target KB slug (default: main; legacy alias: general)"),
    filename: str | None = typer.Option(None, help="Custom filename"),
) -> None:
    """Scrape a URL into a knowledge base."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    console.print(f"[dim]Scraping {url}...[/dim]")
    payload: dict = {"url": url}
    if filename:
        payload["filename"] = filename
    data = _post(f"/api/kb/{kb}/scrape", payload, timeout=60)
    console.print(f"[green]Saved:[/green] {data.get('path', data.get('filename', '?'))}")


@app.command()
def heartbeat(
    limit: int = typer.Option(20, help="Number of recent pulses"),
) -> None:
    """Show recent heartbeat pulses."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/heartbeat/history", {"limit": limit})
    pulses = data if isinstance(data, list) else data.get("pulses", [])
    if not pulses:
        console.print("[dim]No heartbeat data.[/dim]")
        return
    table = Table(title="Heartbeat")
    table.add_column("Time", style="dim")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Tasks")
    for p in pulses[-limit:]:
        table.add_row(
            p.get("ts", "")[:19],
            p.get("pulse_type", ""),
            p.get("status", ""),
            str(p.get("active_tasks", 0)),
        )
    console.print(table)


@app.command()
def plugins() -> None:
    """List plugins and their status."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/plugins")
    items = data.get("plugins", []) if isinstance(data, dict) else data
    if not items:
        console.print("[dim]No plugins installed.[/dim]")
        return
    table = Table(title="Plugins")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Enabled")
    table.add_column("Tools")
    for p in items:
        tools = p.get("provides", {}).get("tools", [])
        table.add_row(
            p.get("title", p.get("name", "?")),
            p.get("version", "?"),
            "[green]Yes[/green]" if p.get("enabled") else "[red]No[/red]",
            str(len(tools)),
        )
    console.print(table)


@app.command(name="onenote-import")
def onenote_import_cmd(
    target_folder: str = typer.Option("OneNote", help="Vault subfolder for imports."),
    notebook: list[str] = typer.Option(
        None,
        "--notebook",
        "-n",
        help="Restrict to these notebook names (repeatable). Omit for all.",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="Force a full re-import (ignore the incremental state file).",
    ),
    follow: bool = typer.Option(
        True,
        "--follow/--no-follow",
        help="Poll /progress and print live counters until the job finishes.",
    ),
) -> None:
    """Import OneNote notebooks (Windows-only) and optionally follow progress.

    Kicks off an async import via the onenote-import plugin's /run endpoint,
    then polls /progress/{job_id} every second. Ctrl-C stops following but
    the import continues in the background — re-attach with
    ``agntspace onenote-progress <job_id>``.
    """

    base = _get_base_url()
    if not _check_server(base):
        return
    payload = {
        "target_folder": target_folder,
        "notebooks": list(notebook) if notebook else None,
        "incremental": not full,
    }
    resp = _post("/api/plugins/onenote-import/run", payload)
    job_id = resp.get("job_id") if isinstance(resp, dict) else None
    if not job_id:
        console.print(f"[red]Failed to start import:[/red] {resp}")
        return
    console.print(
        f"[bold green]Import started[/bold green]  "
        f"[dim]job_id={job_id}  target={target_folder}[/dim]"
    )
    if not follow:
        console.print(
            f"[dim]Poll with:[/dim] agntspace onenote-progress {job_id}"
        )
        return

    try:
        _follow_onenote_job(base, job_id)
    except KeyboardInterrupt:
        console.print(
            f"\n[yellow]Detached.[/yellow] Import continues in the background. "
            f"Reattach: agntspace onenote-progress {job_id}"
        )


@app.command(name="onenote-progress")
def onenote_progress_cmd(
    job_id: str = typer.Argument(..., help="Job id returned by `onenote-import`."),
) -> None:
    """Follow an already-running OneNote import job until it finishes."""
    base = _get_base_url()
    if not _check_server(base):
        return
    try:
        _follow_onenote_job(base, job_id)
    except KeyboardInterrupt:
        console.print("\n[yellow]Detached.[/yellow]")


def _follow_onenote_job(base: str, job_id: str) -> None:
    """Poll the plugin's /progress endpoint and print live counters.

    Uses carriage-return line refresh (no rich progress bar) so it works
    cleanly inside subprocess captures, docker logs, and SSH sessions
    where animated widgets render as garbage.
    """
    import sys
    import time

    last_state = ""
    while True:
        data = _get(f"/api/plugins/onenote-import/progress/{job_id}")
        if isinstance(data, dict) and "detail" in data and "state" not in data:
            console.print(f"[red]{data['detail']}[/red]")
            return
        state = data.get("state", "?")
        imported = data.get("pages_imported", 0)
        skipped = data.get("pages_skipped", 0)
        errs = data.get("errors_count", 0)
        total = data.get("pages_total", 0)
        processed = data.get("pages_processed", 0)
        current = data.get("current_page", "") or "—"
        notebook = data.get("current_notebook", "") or "—"
        eta = data.get("eta_s")
        eta_s = f"ETA {int(eta)}s" if isinstance(eta, (int, float)) else "ETA —"
        bar_width = 24
        ratio = data.get("progress_ratio", 0.0) or 0.0
        filled = int(bar_width * ratio)
        bar = "█" * filled + "░" * (bar_width - filled)
        line = (
            f"[{bar}] {processed}/{total}  "
            f"✓{imported} skip:{skipped} err:{errs}  "
            f"{eta_s}  [{notebook} / {current[:30]}]"
        )
        sys.stdout.write("\r" + line.ljust(120))
        sys.stdout.flush()

        if state in {"completed", "failed", "cancelled"}:
            sys.stdout.write("\n")
            sys.stdout.flush()
            summary = data.get("summary") or {}
            if state == "completed":
                console.print(
                    f"[bold green]Completed[/bold green]  "
                    f"imported={summary.get('pages_imported', imported)} "
                    f"skipped={summary.get('pages_skipped', skipped)} "
                    f"errors={summary.get('errors_count', errs)}"
                )
            elif state == "cancelled":
                console.print(
                    f"[yellow]Cancelled[/yellow]  "
                    f"imported={imported} skipped={skipped}"
                )
            else:
                console.print(
                    f"[red]Failed[/red]  "
                    f"reason={data.get('error', 'unknown')}"
                )
            return
        if state != last_state:
            last_state = state
        time.sleep(1.0)


@app.command()
def video(
    target: str = typer.Argument(..., help="wiki:slug | kb:slug | project:slug | journal:YYYY-MM-DD | url:https://..."),
    duration: int = typer.Option(60, "--duration", "-d", help="Target duration in seconds (5-300)"),
    voice: str = typer.Option("liam", "--voice", "-v", help="Voice: liam | ava | guy | clara | ryan | sonia"),
    style: str = typer.Option("walkthrough", "--style", "-s", help="Style: walkthrough | tutorial | promo"),
    no_follow: bool = typer.Option(False, "--no-follow", help="Return immediately after queuing; don't poll"),
) -> None:
    """Render a narrated .mp4 video from any vault artifact or URL.

    Kicks off a headless-browser recording, generates voiceover narration
    via piper-tts (fallback to pyttsx3), and composes the final file.
    Requires the [video] extra: pip install 'agntspace[video]'.
    """
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    try:
        job = _post("/api/video", {
            "target": target,
            "duration_seconds": duration,
            "voice": voice,
            "style": style,
        })
    except Exception as exc:
        console.print(f"[red]Failed to queue render:[/red] {exc}")
        raise typer.Exit(1) from exc
    job_id = job.get("job_id", "")
    console.print(f"[green]Queued[/green] job [bold]{job_id}[/bold] for [cyan]{target}[/cyan]")
    if no_follow:
        console.print(f"Poll: [bold]agntspace video-progress {job_id}[/bold]")
        return
    _follow_video_job(job_id)


@app.command(name="video-progress")
def video_progress(job_id: str = typer.Argument(..., help="Job id returned by 'agntspace video'")) -> None:
    """Reattach to a running video render and stream live progress."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    _follow_video_job(job_id)


def _follow_video_job(job_id: str) -> None:
    """Poll /api/video/jobs/{id} until terminal state; print a one-line live progress bar."""
    import time
    last_phase = ""
    while True:
        try:
            data = _get(f"/api/video/jobs/{job_id}")
        except Exception as exc:
            console.print(f"[red]Poll failed:[/red] {exc}")
            raise typer.Exit(1) from exc
        state = data.get("state", "?")
        phase = data.get("phase", "")
        ratio = float(data.get("progress_ratio", 0.0))
        bar_len = 24
        filled = int(ratio * bar_len)
        bar = "█" * filled + "░" * (bar_len - filled)
        label = phase or state
        print(f"\r[{bar}] {int(ratio*100):>3}%  {label:<14} job={job_id}", end="", flush=True)

        if state == "completed":
            print()
            path = data.get("path", "")
            dur = data.get("duration_actual", 0.0)
            words = data.get("narration_word_count", 0)
            provider = data.get("tts_provider_used", "")
            console.print(f"[green]Done.[/green] {path} ({dur:.1f}s, {words} words, TTS: {provider})")
            return
        if state in ("failed", "cancelled"):
            print()
            console.print(f"[red]{state.capitalize()}:[/red] {data.get('error', 'unknown')}")
            raise typer.Exit(1)
        if phase and phase != last_phase:
            last_phase = phase
        time.sleep(1.5)


# ═══════════════════════════════════════════
# FINANCE — Phase 1 (receipts → drafts → ledger)
# ═══════════════════════════════════════════

@app.command(name="finance-list")
def finance_list(
    status: str = typer.Option("", "--status", help="draft | verified | rejected | archived (default: visible only)"),
    since: str = typer.Option("", "--since", help="ISO YYYY-MM-DD lower bound"),
    until: str = typer.Option("", "--until", help="ISO YYYY-MM-DD upper bound"),
    merchant: str = typer.Option("", "--merchant", help="Merchant slug filter"),
    project: str = typer.Option("", "--project", help="Project slug filter"),
    limit: int = typer.Option(50, "--limit"),
) -> None:
    """List ledger transactions, newest-first."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    params = {"limit": limit}
    if status:
        params["status"] = status
    if since:
        params["since"] = since
    if until:
        params["until"] = until
    if merchant:
        params["merchant_slug"] = merchant
    if project:
        params["project_slug"] = project
    data = _get("/api/finance/transactions", params=params)
    rows = data.get("transactions", []) if isinstance(data, dict) else []
    if not rows:
        console.print("[dim]No transactions match.[/dim]")
        return
    table = Table(title=f"Transactions ({data.get('count', len(rows))})")
    table.add_column("ID")
    table.add_column("Date")
    table.add_column("Merchant")
    table.add_column("Total", justify="right")
    table.add_column("Status")
    table.add_column("Project")
    for r in rows:
        status_color = {
            "verified": "green",
            "draft": "yellow",
            "rejected": "red",
            "archived": "dim",
            "superseded": "dim",
        }.get(r.get("status", ""), "white")
        table.add_row(
            r.get("txn_id", "")[:10],
            r.get("txn_date", ""),
            r.get("merchant_slug", "") or "[dim](unresolved)[/dim]",
            f"{r.get('total', '')} {r.get('currency', '')}",
            f"[{status_color}]{r.get('status', '')}[/{status_color}]",
            r.get("project_slug", "") or "[dim]—[/dim]",
        )
    console.print(table)


@app.command(name="finance-show")
def finance_show(
    txn_id: str = typer.Argument(..., help="Transaction or draft ID"),
) -> None:
    """Show one transaction with all line items."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    txn = _get(f"/api/finance/transactions/{txn_id}")
    if not isinstance(txn, dict):
        console.print(f"[red]Unexpected response: {txn}[/red]")
        raise typer.Exit(1)
    console.print(f"\n[bold]{txn.get('merchant_slug') or '(unresolved merchant)'}[/bold]  "
                  f"— [bold]{txn.get('total')} {txn.get('currency')}[/bold]  "
                  f"on [cyan]{txn.get('txn_date')}[/cyan]")
    console.print(f"  Status: [bold]{txn.get('status')}[/bold]   "
                  f"Project: {txn.get('project_slug') or '[dim]unassigned[/dim]'}   "
                  f"Tax: {txn.get('tax')}")
    if txn.get("payment_method"):
        console.print(f"  Payment: [dim]{txn['payment_method']}[/dim]")
    items = txn.get("items", [])
    if items:
        items_table = Table(title="Line items", show_header=True)
        items_table.add_column("Description")
        items_table.add_column("Amount", justify="right")
        items_table.add_column("Category")
        items_table.add_column("Project")
        items_table.add_column("Deductible")
        for item in items:
            items_table.add_row(
                item.get("description", ""),
                item.get("amount", ""),
                item.get("category_slug", "") or "[dim]—[/dim]",
                item.get("project_slug", "") or "[dim]—[/dim]",
                "[green]✓[/green]" if item.get("tax_deductible") else "[dim]—[/dim]",
            )
        console.print(items_table)


@app.command(name="finance-pending")
def finance_pending(limit: int = typer.Option(50, "--limit")) -> None:
    """List drafts awaiting approval."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _get("/api/finance/pending", params={"limit": limit})
    rows = data.get("drafts", []) if isinstance(data, dict) else []
    if not rows:
        console.print("[green]No pending drafts.[/green]")
        return
    table = Table(title=f"Pending drafts ({data.get('count', len(rows))})")
    table.add_column("ID")
    table.add_column("Date")
    table.add_column("Merchant")
    table.add_column("Total", justify="right")
    table.add_column("Items", justify="right")
    for r in rows:
        table.add_row(
            r.get("txn_id", "")[:10],
            r.get("txn_date", ""),
            r.get("merchant_slug", "") or "[dim](unresolved)[/dim]",
            f"{r.get('total', '')} {r.get('currency', '')}",
            str(r.get("item_count", 0)),
        )
    console.print(table)
    console.print("\n[dim]Approve with[/dim] [bold]agntspace finance-approve <id>[/bold]   "
                  "[dim]or reject with[/dim] [bold]agntspace finance-reject <id> --reason '...'[/bold]")


@app.command(name="finance-ingest")
def finance_ingest(
    path: str = typer.Argument(..., help="Path to a receipt file (logical or physical)"),
) -> None:
    """Ingest a receipt and produce a draft transaction (no commit)."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/finance/ingest", {"path": path})
    if not isinstance(data, dict) or not data.get("ok", False):
        err = data.get("error", "unknown") if isinstance(data, dict) else "unknown"
        console.print(f"[red]Ingest failed:[/red] {err}")
        raise typer.Exit(1)
    if data.get("deduplicated"):
        console.print(f"[yellow]Already ingested:[/yellow] draft id [bold]{data.get('draft_id')}[/bold]")
        return
    console.print(f"[green]Drafted:[/green] [bold]{data.get('draft_id')}[/bold]")
    console.print(f"  Merchant: {data.get('merchant_raw') or '[dim](unreadable)[/dim]'}  "
                  f"({data.get('merchant_slug') or '[dim]unresolved[/dim]'})")
    console.print(f"  Total: [bold]{data.get('total')} {data.get('currency')}[/bold]")
    console.print(f"  Items: {data.get('item_count')}")
    flags = data.get("audit_flags") or []
    if flags:
        console.print(f"  [yellow]Audit flags:[/yellow] {', '.join(flags)}")
    console.print(f"\n[dim]Review with[/dim] [bold]agntspace finance-show {data.get('draft_id')}[/bold]")


@app.command(name="finance-approve")
def finance_approve(
    txn_id: str = typer.Argument(..., help="Draft ID to approve"),
) -> None:
    """Approve a draft → promote to verified ledger entry."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post(f"/api/finance/transactions/{txn_id}/approve", {})
    if isinstance(data, dict) and data.get("ok"):
        console.print(f"[green]Approved:[/green] {data.get('txn_id')} → status [bold]{data.get('status')}[/bold]")
    else:
        console.print(f"[red]Approve failed:[/red] {data}")
        raise typer.Exit(1)


@app.command(name="finance-reject")
def finance_reject(
    txn_id: str = typer.Argument(..., help="Draft ID to reject"),
    reason: str = typer.Option("", "--reason", help="Why you're rejecting (saved for audit)"),
) -> None:
    """Reject a draft → archive without committing."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post(f"/api/finance/transactions/{txn_id}/reject", {"reason": reason})
    if isinstance(data, dict) and data.get("ok"):
        console.print(f"[yellow]Rejected:[/yellow] {data.get('txn_id')} → status [bold]{data.get('status')}[/bold]")
    else:
        console.print(f"[red]Reject failed:[/red] {data}")
        raise typer.Exit(1)


@app.command(name="finance-merchants")
def finance_merchants(limit: int = typer.Option(100, "--limit")) -> None:
    """List canonical merchants in the registry."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _get("/api/finance/merchants", params={"limit": limit})
    rows = data.get("merchants", []) if isinstance(data, dict) else []
    if not rows:
        console.print("[dim]No merchants registered yet.[/dim]")
        return
    table = Table(title=f"Merchants ({data.get('count', len(rows))})")
    table.add_column("Slug")
    table.add_column("Canonical name")
    table.add_column("Aliases", justify="right")
    table.add_column("Country")
    table.add_column("Default category")
    table.add_column("Last seen")
    for m in rows:
        table.add_row(
            m.get("merchant_slug", ""),
            m.get("canonical_name", ""),
            str(len(m.get("aliases") or [])),
            m.get("country", "") or "[dim]—[/dim]",
            m.get("default_category", "") or "[dim]—[/dim]",
            m.get("last_seen", "") or "[dim]—[/dim]",
        )
    console.print(table)


@app.command()
def channels() -> None:
    """List messaging channels and connection status."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/channels")
    ch_list = data if isinstance(data, list) else data.get("channels", [])
    if not ch_list:
        console.print("[dim]No channels configured.[/dim]")
        return
    table = Table(title="Channels")
    table.add_column("Channel")
    table.add_column("Status")
    for ch in ch_list:
        name = ch.get("name", "?")
        connected = ch.get("connected", False)
        status_str = "[green]Connected[/green]" if connected else "[dim]Disconnected[/dim]"
        table.add_row(name, status_str)
    console.print(table)


@app.command()
def doctor() -> None:
    """Run a comprehensive health audit of the AgntSpace installation.

    Checks config, credentials, LLM connectivity, skills, agents, contract,
    channels, work queue, database, and vault integrity. Works both with
    a running server (via REST API) and offline (direct file checks).
    """
    from rich.panel import Panel

    base_url = _get_base_url()
    server_up = False
    try:
        import httpx
        httpx.get(f"{base_url}/api/health", timeout=3)
        server_up = True
    except Exception:
        pass

    console.print(Panel("[bold]AgntSpace Doctor[/bold]", subtitle="Health Audit"))
    checks: list[tuple[str, str, str]] = []  # (name, status, detail)

    def ok(name: str, detail: str = "") -> None:
        checks.append((name, "[green]OK[/green]", detail))

    def warn(name: str, detail: str) -> None:
        checks.append((name, "[yellow]WARN[/yellow]", detail))

    def fail(name: str, detail: str) -> None:
        checks.append((name, "[red]FAIL[/red]", detail))

    # ── 1. Config ──
    from agntspace.infra.config import get_settings
    try:
        settings = get_settings()
        config_path = Path(settings.app_dir) / "config.toml"
        if config_path.exists():
            ok("Config", str(config_path))
        else:
            warn("Config", f"config.toml not found at {config_path}")
    except Exception as exc:
        fail("Config", str(exc))
        settings = None

    # ── 2. Vault ──
    vault_dir = None
    if settings:
        vault_dir = Path(settings.root_dir) if getattr(settings, "root_dir", None) else None
    if vault_dir and vault_dir.is_dir():
        ok("Vault root", str(vault_dir))
        # Check identity files
        identity_dir = vault_dir / "agntspace" / "system" / "identity"
        for fname in ("SOUL.md", "CONTRACT.md", "USER.md"):
            fpath = identity_dir / fname
            if fpath.exists():
                size = fpath.stat().st_size
                if size > 200:
                    ok(f"  {fname}", f"{size} bytes")
                else:
                    warn(f"  {fname}", f"only {size} bytes — likely placeholder")
            else:
                fail(f"  {fname}", "missing")
    elif vault_dir:
        fail("Vault root", f"{vault_dir} does not exist")
    else:
        warn("Vault root", "not configured (setup mode)")

    # ── 3. Database ──
    if settings:
        # Per-vault DB (canonical, since 2026-04-13). The legacy shared
        # location at app_dir is checked as a one-time migration source,
        # not the source of truth.
        db_path = settings.db_path
        if db_path.exists():
            size_mb = db_path.stat().st_size / (1024 * 1024)
            ok("Database", f"{db_path.name} at {db_path.parent} ({size_mb:.1f} MB)")
        else:
            # Surface the legacy fallback if it's still present so the
            # user sees the migration is pending.
            shared = settings.shared_db_path
            if shared.exists():
                warn(
                    "Database",
                    f"per-vault DB missing — legacy shared DB still at {shared} "
                    "(will migrate on next server boot)",
                )
            else:
                warn("Database", "agntspace.db not found in vault (will be created on first boot)")

    # ── 4. Credentials ──
    if settings:
        cred_path = Path(settings.app_dir) / "credentials.json"
        if cred_path.exists():
            try:
                cred_data = json.loads(cred_path.read_text(encoding="utf-8"))
                key_count = len(cred_data) if isinstance(cred_data, dict) else 0
                ok("Credentials", f"{key_count} stored key(s)")
            except Exception:
                warn("Credentials", "file exists but unreadable")
        else:
            warn("Credentials", "no credentials.json — LLM keys may be missing")

    # ── Server-dependent checks (REST API) ──
    if server_up:
        console.print(f"\n[dim]Server running at {base_url}[/dim]\n")

        # ── 5. LLM Health ──
        try:
            llm = _get("/api/llm/status")
            if isinstance(llm, dict):
                healthy = llm.get("healthy", False)
                model = llm.get("model", "?")
                if healthy:
                    ok("LLM", f"{model} — healthy")
                else:
                    error = llm.get("last_error", "unknown")
                    fail("LLM", f"{model} — {error}")
        except Exception:
            warn("LLM", "could not check (endpoint unavailable)")

        # ── 6. Skills ──
        try:
            skills = _get("/api/skills")
            if isinstance(skills, list):
                total = len(skills)
                quarantined = [s for s in skills if s.get("status") == "quarantined"]
                if quarantined:
                    warn("Skills", f"{total} loaded, {len(quarantined)} quarantined: {', '.join(s.get('name', '?') for s in quarantined)}")
                else:
                    ok("Skills", f"{total} loaded")
        except Exception:
            warn("Skills", "could not check")

        # ── 7. Agents ──
        try:
            agents = _get("/api/orchestrator/agents")
            if isinstance(agents, list):
                total = len(agents)
                with_issues = [a for a in agents if a.get("known_issues")]
                if with_issues:
                    issue_count = sum(len(a["known_issues"]) for a in with_issues)
                    warn("Agents", f"{total} loaded, {issue_count} known issue(s) across {len(with_issues)} agent(s)")
                else:
                    ok("Agents", f"{total} loaded, no issues")
        except Exception:
            warn("Agents", "could not check")

        # ── 8. Contract ──
        try:
            contract = _get("/api/contract")
            if isinstance(contract, dict):
                actions = contract.get("actions", {})
                blocked = [k for k, v in actions.items() if v == "block"]
                ok("Contract", f"{len(actions)} actions ({len(blocked)} blocked)")
        except Exception:
            warn("Contract", "could not read")

        # ── 9. Channels ──
        try:
            channels = _get("/api/channels")
            ch_list = channels if isinstance(channels, list) else channels.get("channels", []) if isinstance(channels, dict) else []
            connected = [c for c in ch_list if c.get("connected")]
            if ch_list:
                ok("Channels", f"{len(connected)}/{len(ch_list)} connected")
            else:
                ok("Channels", "none configured")
        except Exception:
            warn("Channels", "could not check")

        # ── 10. Work Queue ──
        try:
            wq = _get("/api/work-queue")
            if isinstance(wq, dict):
                pending = wq.get("pending", 0)
                dead = wq.get("dead_letter", 0)
                if dead:
                    warn("Work Queue", f"{pending} pending, {dead} dead-letter")
                elif pending:
                    ok("Work Queue", f"{pending} pending, draining")
                else:
                    ok("Work Queue", "empty — all caught up")
        except Exception:
            warn("Work Queue", "could not check")

        # ── 11. Knowledge Bases ──
        try:
            kbs = _get("/api/kb")
            if isinstance(kbs, list):
                total_articles = sum(k.get("articles", 0) for k in kbs)
                total_sources = sum(k.get("sources", 0) for k in kbs)
                ok("Knowledge", f"{len(kbs)} KB(s), {total_articles} articles, {total_sources} sources")
        except Exception:
            warn("Knowledge", "could not check")

        # ── 12. Memory Graph ──
        try:
            graph = _get("/api/graph/stats")
            if isinstance(graph, dict):
                nodes = graph.get("total_nodes", 0)
                edges = graph.get("total_edges", 0)
                ok("Graph", f"{nodes} nodes, {edges} edges")
        except Exception:
            warn("Graph", "could not check")

    else:
        console.print("\n[dim]Server not running — skipping API checks[/dim]\n")
        warn("Server", f"not reachable at {base_url}")

    # ── Print results ──
    console.print()
    table = Table(title="Health Report", show_header=True)
    table.add_column("Check", style="bold", min_width=15)
    table.add_column("Status", min_width=8)
    table.add_column("Details")

    for name, status, detail in checks:
        table.add_row(name, status, detail)

    console.print(table)

    # Summary
    ok_count = sum(1 for _, s, _ in checks if "green" in s)
    warn_count = sum(1 for _, s, _ in checks if "yellow" in s)
    fail_count = sum(1 for _, s, _ in checks if "red" in s)
    total = len(checks)

    if fail_count:
        console.print(f"\n[red bold]{fail_count} FAILED[/red bold], {warn_count} warnings, {ok_count}/{total} healthy")
    elif warn_count:
        console.print(f"\n[yellow]{warn_count} warning(s)[/yellow], {ok_count}/{total} healthy")
    else:
        console.print(f"\n[green bold]All {total} checks passed![/green bold]")


if __name__ == "__main__":
    app()
