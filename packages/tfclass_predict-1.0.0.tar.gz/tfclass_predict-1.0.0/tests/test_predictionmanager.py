from src.tfclass_predict import PredictionManager
import numpy as np
import pandas as pd
from .constants import BED, GENOMEFILE, TFCLASSMODELPATH, RESDIR, PRECOMPILED, RESULTS, PRECOMPILEDFULL


def test_predict_TFCPmodel():
    """ Tests if the PredicitonManager returns the expected result for the classlevel model on ATAC-seq data. """

    expected = pd.read_csv(RESULTS)
    pm = PredictionManager(bed_file=BED, genome_file=GENOMEFILE, tfclass_model=TFCLASSMODELPATH, res_dir=RESDIR)

    count_df = pm.predict()
    print(count_df)
    assert np.all(count_df == expected.iloc[:,3:])


# def test_predict_TFCPprecompiled():
#     """ Tests if the PredicitonManager returns the expected result for the classlevel model on any other BED file. """

#     expected = pd.read_csv(RESULTS)
#     pm = PredictionManager(bed_file=BED, precompiled=PRECOMPILED, res_dir=RESDIR)

#     count_df = pm.predict()
#     print(count_df)
#     print(expected.iloc[:,3:])
#     assert np.all(count_df == expected.iloc[:,3:])

# def test_predict_TFCPprecompiled_full():
#     """ Tests if the PredicitonManager returns the expected result for the classlevel model on any other BED file. """

#     expected = pd.read_csv(RESULTS)
#     pm = PredictionManager(bed_file=BED, precompiled=PRECOMPILEDFULL, res_dir=RESDIR)

#     count_df = pm.predict()
#     print(count_df)
#     print(expected.iloc[:,3:])
#     assert np.all(count_df == expected.iloc[:,3:])