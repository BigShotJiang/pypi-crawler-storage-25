from src.tfclass_predict import cli_interface
import numpy as np
from os.path import join
from .constants import BED, GENOMEFILE, TFCLASSMODELPATH, RESDIR, PRECOMPILED


def test_parser_TFCPmodel():
    """ Tests if the CLI parses the input correctly. """
    parser = cli_interface.create_parser()

    args = parser.parse_args([BED, RESDIR, '--genome' , GENOMEFILE, '--model', TFCLASSMODELPATH])

    assert args.bed_file == BED
    assert args.genome == GENOMEFILE
    assert args.model == TFCLASSMODELPATH
    assert args.precompiled is None
    assert args.output_dir == RESDIR

def test_parser_TFCPprecompiled():
    """ Tests if the CLI parses the input correctly. """
    parser = cli_interface.create_parser()

    args = parser.parse_args([BED, RESDIR, '--precompiled' , PRECOMPILED])

    assert args.bed_file == BED
    assert args.genome is None
    assert args.model is None
    assert args.precompiled == PRECOMPILED
    assert args.output_dir == RESDIR