import argparse
from .prediction_manager import PredictionManager


def entry():
    """
    Commandline interface to execute the program.
    """

    parser = create_parser()
    args = parser.parse_args()
    run(args)


def create_parser():
    parser = argparse.ArgumentParser(
        prog='tfclass_predict',
        description="""tfclass_predict allows to estimate transcription factor bindingsites in the TFClass hierarchy. 
                        Please specifiy either the path to the precompiled (--precompiled) files or to the published model (--model + --genome).
                        If both are defined, the precompiled dataset is preferred!""",
    )
    parser.add_argument('bed_file', type=str, help='Path to bed file of ATAC-seq or other NGS experiment.')
    parser.add_argument('output_dir', type=str, help='Path to output directory.')
    parser.add_argument('--genome', type=str, help='Path to human genome reference (rec.: hg38) (.fa).', default=None)
    parser.add_argument('--precompiled', type=str, help='Path to precompiled hg38 predictions (unzipped folder).', default=None)
    parser.add_argument('--model', type=str, help='Path to TFClass model archive (unzipped folder).', default=None)
    parser.add_argument('--gpus', type=int, help='Number of GPUs that should be used in parallel.', default=1)
    parser.add_argument('--cpus', type=int, help='Number of CPUs that should be used at maximum in parallel.', default=1)
    return parser


def run(args):
    pm = PredictionManager(args.bed_file, args.output_dir, precompiled=args.precompiled, genome_file=args.genome, tfcp_model=args.model, ngpus=args.gpus, ncpus=args.cpus)
    pm.predict()
    pm.save_results()
