from .io_interface import IOInterface
from .predictor import PredictorTFCPModel, PredictorPrecompiled
import pandas as pd

class PredictionManager:
    """ Prediction manager class. Coordinates the prediction for a single bed file. """
    def __init__(self, bed_file:str, res_dir:str, precompiled:str = None, genome_file:str = None, tfcp_model:str = None, ngpus:int=1, ncpus=1):
        """
        :param bed_file: Path to BED file cotaining at least CHROM, START, END entries.
        :param genome_file: Path to reference genome file.
        :param res_dir: Output directory.
        :param bert_model: Path to BERT model directory.
        :param tfclass_model: Path to TFClass model tar.gz.
        :param tfargs: Directory conatining arguments for TFClass. Possible keys are: num_threads, num_gpus, num_cpus, memory_limit
        """
        self.count_df = None
        self.iointerface = IOInterface(bed_file, res_dir)
        bed = self.iointerface.read_bed()

        if precompiled: 
            self.predictor = PredictorPrecompiled(bed, precompiled)
        elif genome_file and tfcp_model: 
            self.predictor = PredictorTFCPModel(bed, tfcp_model, genome_file, ngpus=ngpus, ncpus=ncpus)
        else:
            raise ValueError("Neither the precompiled set nor the model or genome was defined!")

    def predict(self):
        """
        Start the prediction.
        :param subseq_length: Length in which a read should be split into subsequences.
        :param stride_length: Defines the number of basepairs a window will move in the next step. (=1 sliding window, =subseq_length k_mer splits)
        :param batch_size: Number of intervals that should be processed in one batch.
        :return: Count vectors and prediction dictionary.
        """

        if not self.count_df:
            print("Starting Prediction...")
            self.count_df = self.predictor.predict_bed()

        return self.count_df

    def save_results(self):
        """ Saves the prediction results to disk. """
        if self.count_df is None:
            ValueError("Predictions not initialized! Run 'predict' first.")
        else:
            return self.iointerface.write_predictions(self.count_df)
