from typing import List
import pysam 
from transformers import BertTokenizer
import numpy as np
import multiprocessing as mp
import pandas as pd
from .constants import WINDOWSIZE

def _sequence_to_kmers(sequence:str, k:int):
    """
    Splits a string into defined kmers.
    :param sequence: String to split.
    :param k: kmer size.
    :return: List of kmers.
    """
    sequence = sequence.upper()
    return [sequence[i:i + k] for i in range(len(sequence) - k + 1)]

def _tokenize_kmer(tokenizer:BertTokenizer, sequence:str, k:int):
        kmer = _sequence_to_kmers(sequence, k)
        return tokenizer.convert_tokens_to_ids(kmer)

class SequenceProcessor:
    """ Class for processing sequences. """
    def __init__(self, genome_file:str, num_cores=1, tokenizer:BertTokenizer = None):
        self.tokenizer = tokenizer
        self.genome = pysam.FastaFile(genome_file)
        self.num_cores = num_cores
        self.WINDOWSIZE = WINDOWSIZE

    def get_fasta_sequence(self, chromosome: str, start_str: str, end_str: str) -> List[int]:
        """
        The function takes the start and end positions and gets adjusted start and end positions of the
        subsequence of this sequence of length desired_length from the middle of the sequence.
        It checks that the chromosome is one of the 23 autosomal chromosomes or one of the gonosomes/allosomes.
        If the chromosome where the sequence is located is not part of these chromosomes the function returns None.
        Then the subsequence string is fetched from the reference genome.
        If the sequence can't be fetched a string with "N" times the desired length is used.
        If the sequence is shorter then the desired length it is padded at the end with "N".
        The sequence is kmerised with the sequence_to_kmers function and tokenized with kmers_to_tokens.
        If the token id list is not of desired_length it is padded with 0s at the end.

        :param chromosome: String with the chromosome the sequence is on. E.g. chr5
        :param start_str: String with integer of start position of sequence.
        :param end_str: String with integer of end position of sequence.
        :param genome:
        :return: List with the token ids.
        """

        start = int(start_str)
        end = int(end_str)
        
        desired_length = end-start

        try:
            sequence = self.genome.fetch(chromosome, start, end).upper()
        except Exception as e:
            print(e)
            return None

        if not sequence:
            return "N" * desired_length

        return sequence

    def get_sequences(self, bed:pd.DataFrame):
        seqs = []
        for _, row in bed.iterrows():
            seqs.append(self.get_fasta_sequence(row['chr'], row['start'], row['end']))

        sequences_cutted = []
        seq_belongings = []
        for i in range(len(seqs)): 
            seq = seqs[i]
            for j in range(0, len(seq)-self.WINDOWSIZE+1):
                sequences_cutted.append(seq[j:j+self.WINDOWSIZE])
                seq_belongings.append(i)

        return sequences_cutted, seq_belongings

    
    def tokenize_sequences(self, sequences: np.array, k: int) -> np.array:
        """
            sequence to kmers to tokens
            sequences must all have the same length!
        """
        pool = mp.Pool(self.num_cores)
        ids = pool.starmap(_tokenize_kmer, [(self.tokenizer, seq, k) for seq in sequences])
        pool.close()
        pool.join()

        return np.array(ids)
