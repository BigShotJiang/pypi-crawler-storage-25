import tensorflow as tf
from transformers import TFBertModel, BertTokenizer
import numpy as np
import pyBigWig as pbw
import pandas as pd
import os

from .constants import MODELNAME, THRESHOLDS, TOKENIZERFOLDERNAME, K, CLASSMAPPING, WINDOWSIZE, BATCHSIZE
from .sequence_processor import SequenceProcessor


def _summarize_predictions(y_pred, seq_belongings):
    y_preds = []
    for i in np.unique(seq_belongings):
        mask = (seq_belongings == i)
        idx = np.argwhere(mask)
        found_classes = np.sum(y_pred[idx], axis=0)
        y_preds.append(found_classes.flatten())
    return np.array(y_preds)


class Predictor:
    def _init_basics(self, bed:pd.DataFrame, mapping_path:str):
        self.bed = bed
        self.classmapping = pd.read_csv(os.path.join(mapping_path, CLASSMAPPING), dtype={"Class":str})
        self.K = K
        self.BATCHSIZE = BATCHSIZE

    def predict_bed(self) -> pd.DataFrame: 
        pass


class PredictorTFCPModel(Predictor):
    """ Predictor class takes care about the prediction / model execution. """
    def __init__(self, bed:pd.DataFrame, model_path:str, genome_file:str, ngpus:int=1, ncpus:int=1):
        self._init_basics(bed, model_path)
        self._load_model(model_path)
        self.SequenceProcessor = SequenceProcessor(genome_file, num_cores=ncpus, tokenizer=self.tokenizer)
        self.ngpus = ngpus
    
    def _get_gpus(self):
        gpus = tf.config.experimental.list_physical_devices('GPU')
        gpu_list = []
        for i in range(min(len(gpus), self.ngpus)):
            gpu = gpus[i].name
            gpu = gpu.strip("/physical_device:")
            gpu_list.append(gpu)
        return gpu_list

    def _load_model(self, model_path:str) -> None:
        self.tokenizer = BertTokenizer.from_pretrained(os.path.join(model_path, TOKENIZERFOLDERNAME), local_files_only=True)
        self.model = tf.keras.models.load_model(os.path.join(model_path, MODELNAME))
        self.thresholds = np.load(os.path.join(model_path, THRESHOLDS))
        
    def predict_bed(self) -> pd.DataFrame: 
        """
        Performs prediction on given BED file. Therefore, sequences are cutted via a 21bp window, tokenized using the BertTokenizer and finally predicted in batches.
        :return: DataFrame of predicted TFBSs per region in BED file.
        """

        print("Cut Sequences")
        sequences_cutted, seq_belongings = self.SequenceProcessor.get_sequences(self.bed)

        print("Tokenize")
        # predict classes
        tokens = self.SequenceProcessor.tokenize_sequences(sequences_cutted, self.K)

        print("Predict")
        strategy = tf.distribute.MirroredStrategy(devices=self._get_gpus())

        print("Predict")

        with strategy.scope():
            x =  tf.data.Dataset.from_tensor_slices(tokens).batch(self.BATCHSIZE) # improves gpu usage
            y_pred = self.model.predict(x)
            y_pred = (y_pred > self.thresholds).astype(int)
            
            count_mat = _summarize_predictions(y_pred, seq_belongings)

        count_df = pd.DataFrame(count_mat.astype(int), columns=self.classmapping["Class"])
        return count_df

# Currently under development 
class PredictorPrecompiled(Predictor):
    """ Predictor class takes care about the prediction / model execution using the hg38 precompiled set"""
    def __init__(self, bed:pd.DataFrame, precompiled_file_path:str):
        self._init_basics(bed, precompiled_file_path)
        self._load_precompiled_files(precompiled_file_path)

    def _load_precompiled_files(self, precompiled_file_path:str) -> None:
        files = np.array(sorted(os.listdir(precompiled_file_path)))
        self.tfbs_files = np.array([os.path.join(precompiled_file_path, f) for f in files if str(f).endswith(".bb")])

    def _predict_precompiled(self, class_index:int) -> np.array:
        bb = pbw.open(self.tfbs_files[class_index])
        count_vec = np.zeros(self.bed.shape[0])
        for idx, row in self.bed.iterrows(): 
            if row["end"] < bb.chroms(row["chr"]): # interval must be completely included
                entry = bb.entries(row["chr"], row["start"], row["end"])
                if entry: 
                    count_vec[idx] += len(entry)        
            
        return count_vec 

    def predict_bed(self) -> pd.DataFrame:
        """

        :return:
        """

        count_mat = np.zeros((self.bed.shape[0], len(self.tfbs_files)))
        for idx in range(len(self.tfbs_files)):
            print(self.tfbs_files[idx])
            count_mat[:, idx] = self._predict_precompiled(idx)
        
        count_df = pd.DataFrame(count_mat.astype(int), columns=self.classmapping["Class"])
        return count_df
        
