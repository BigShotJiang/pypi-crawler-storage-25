import csv
import os
import pysam
import numpy as np
import pandas as pd


class IOInterface:
    def __init__(self, bed_file: str, res_dir: str):
        """
        Processes and validates inputs.
        :param bed_file: Path to BED file from e.g. ATAC-seq regions or any other NGS-DNA strategy.
        :param genome_file: Path to Fasta file from a recent human genome.
        :param res_dir: Path to output directory.
        """
        self.bed = None
        self.bed_file = bed_file
        _file_name = os.path.split(bed_file)[-1]
        self.file_name = os.path.splitext(_file_name)[-2]

        # Ensure the results directory exists
        if not os.path.exists(res_dir):
            os.makedirs(res_dir)
        self.res_dir = res_dir

    def read_bed(self):
        """
        Reads ATAC-seq regions from BED file that was given in the initalizer.
        :return: BED file input as pd.DataFrame.
        """
        
        if not self.bed:
            atac_seq_columns = ["chr", "start", "end"]
            atac_seq_data = pd.read_csv(self.bed_file, sep='\t', usecols=[0, 1, 2], names=atac_seq_columns, header=None)
        
            self.bed = atac_seq_data

        return self.bed

    def write_predictions(self, counts_df: pd.DataFrame):
        """
        Writes predictions and count vectors to output files.
        :param counts_df: Count matrix as DataFrame for in shape peaks/regions x TFClasses from Predictor.predict function.
        :return:
        """
        
        save = os.path.join(self.res_dir, f"{self.file_name}_TFCP.csv")

        df = pd.concat([self.bed, counts_df], axis=1)
        print(f"Saving to {save}")
        df.to_csv(save, index=False)

        return df




