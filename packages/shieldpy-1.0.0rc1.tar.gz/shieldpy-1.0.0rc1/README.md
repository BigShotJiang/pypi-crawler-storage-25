# PromptShield

**AI-powered offline document anonymization.** CLI, Python SDK, and self-hosted API.

PromptShield detects and redacts PII (personally identifiable information) in documents — names, addresses, phone numbers, IDs, and more — using a combination of NLP models (spaCy, BERT, GLiNER) with zero data leaving your machine.

## Installation

```bash
pip install shieldpy
```

With office document support (DOCX, XLSX, PPTX):

```bash
pip install "promptshield[office]"
```

Download the required models after installing:

```bash
python -m spacy download en_core_web_trf
python -m spacy download fr_dep_news_trf
```

Verify everything is working:

```bash
promptshield doctor
```

## Quick Start

### CLI

```bash
# Check your environment
promptshield doctor

# Detect PII in a document
promptshield detect contract.pdf

# Detect with JSON output
promptshield detect contract.pdf --json

# Anonymize a document
promptshield anonymize contract.pdf -o contract-safe.pdf

# Batch-process a directory
promptshield anonymize ./documents/ -o ./redacted/ --recursive

# Reverse anonymization with the token vault
promptshield detokenize contract-safe.pdf -o contract-restored.pdf

# Start the self-hosted API server
promptshield serve --port 8000 --workers 4
```

### Python SDK

```python
from promptshield import PromptShield

ps = PromptShield(api_key="ps_live_...")

# Detect PII
result = ps.detect("contract.pdf")
for page in result.pages:
    for entity in page["entities"]:
        print(f"  [{entity['type']}] {entity['text']}")

# Anonymize a document
result = ps.anonymize("contract.pdf", output_path="contract-safe.pdf")
print(f"Tokens created: {result.tokens_created}")

# Reverse anonymization
result = ps.detokenize("contract-safe.pdf", output_path="contract-restored.pdf")
print(f"Tokens resolved: {result.tokens_resolved}")
```

Async usage:

```python
import asyncio
from promptshield import PromptShield

async def main():
    ps = PromptShield(api_key="ps_live_...")
    result = await ps.adetect("contract.pdf")
    print(result.pages)

asyncio.run(main())
```

### Self-Hosted API (Docker)

```bash
docker run -e PROMPTSHIELD_API_KEY=ps_live_... -p 8000:8000 promptshield/promptshield-api
```

```bash
curl -X POST http://localhost:8000/api/detect \
  -H "Authorization: Bearer ps_live_..." \
  -F "file=@contract.pdf"
```

Or use Docker Compose:

```yaml
services:
  promptshield:
    image: promptshield/promptshield-api:latest
    ports:
      - "8000:8000"
    environment:
      PROMPTSHIELD_API_KEY: "ps_live_..."
      # PROMPTSHIELD_CORS_ORIGINS: "https://app.example.com"
      # LOG_LEVEL: "info"
```

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PROMPTSHIELD_API_KEY` | — | API key (required for CLI & self-hosted) |
| `PROMPTSHIELD_CORS_ORIGINS` | — | Comma-separated CORS origins for the API |
| `PS_LICENSING_URL` | `https://api.promptshield.ca` | Licensing server URL |
| `LOG_LEVEL` | `info` | Log level (`debug`, `info`, `warning`, `error`) |
| `SENTRY_DSN` | — | Sentry DSN for error reporting |
| `LLM_MODEL` | — | LLM model override for entity classification |

## Exit Codes (CLI)

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | General error |
| 2 | Authentication / API key error |
| 3 | Quota exceeded |
| 4 | Model not found |
| 5 | File not found / format error |

## Requirements

- Python 3.10+
- Tesseract OCR (for scanned PDFs)
- 2 GB+ RAM recommended

## API Reference

See the full API documentation at [promptshield.ca/developers/docs](https://promptshield.ca/developers/docs).

## License

MIT
