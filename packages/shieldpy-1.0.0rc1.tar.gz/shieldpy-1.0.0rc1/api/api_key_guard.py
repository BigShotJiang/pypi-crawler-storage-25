"""API key middleware for self-hosted / Docker mode.

When PROMPTSHIELD_API_KEY is set (via `promptshield serve --api-key` or Docker
env), every incoming HTTP request must include the key in the Authorization
header:

    Authorization: Bearer ps_live_...

Exempt paths: /health, /docs, /openapi.json, /redoc

Scope enforcement: when the cached key has scopes (detect,anonymize,detokenize),
only allow requests to matching API prefixes.
"""

from __future__ import annotations

import os
import secrets

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

_API_KEY: str | None = None
_API_KEY_SCOPES: set[str] | None = None  # None = all scopes allowed

_EXEMPT_PATHS = frozenset({"/health", "/docs", "/openapi.json", "/redoc"})

# Map API route prefixes to scope names
_ROUTE_SCOPE_MAP = {
    "/api/detection": "detect",
    "/api/detect": "detect",
    "/api/anonymize": "anonymize",
    "/api/export": "anonymize",
    "/api/detokenize": "detokenize",
}


def _get_api_key() -> str | None:
    """Lazy-load the expected API key from the environment."""
    global _API_KEY
    if _API_KEY is None:
        _API_KEY = os.environ.get("PROMPTSHIELD_API_KEY", "") or ""
    return _API_KEY or None


def set_api_key_scopes(scopes: str | None) -> None:
    """Set the allowed scopes for the configured API key.

    Called during license validation / startup.
    scopes: comma-separated string like "detect,anonymize,detokenize" or None for all.
    """
    global _API_KEY_SCOPES
    if scopes:
        _API_KEY_SCOPES = {s.strip() for s in scopes.split(",") if s.strip()}
    else:
        _API_KEY_SCOPES = None  # unrestricted


class ApiKeyGuardMiddleware(BaseHTTPMiddleware):
    """Reject requests without a valid API key in self-hosted mode.

    Only active when PROMPTSHIELD_API_KEY is set. In Tauri desktop mode
    (PS_SESSION_TOKEN is set), this middleware is a no-op — the
    LicenseGuardMiddleware handles auth instead.
    """

    async def dispatch(self, request: Request, call_next):
        expected = _get_api_key()

        # No API key configured → middleware is a no-op
        if not expected:
            return await call_next(request)

        # In Tauri mode, skip — LicenseGuard handles it
        if os.environ.get("PS_SESSION_TOKEN"):
            return await call_next(request)

        # Exempt paths
        if request.url.path in _EXEMPT_PATHS:
            return await call_next(request)

        # Allow CORS preflight
        if request.method == "OPTIONS":
            return await call_next(request)

        # Extract Bearer token
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            provided = auth_header[7:]
        else:
            provided = ""

        if not provided or not secrets.compare_digest(provided, expected):
            return JSONResponse(
                status_code=401,
                content={"detail": "Invalid or missing API key. Set the Authorization header: Bearer <your-api-key>"},
            )

        # Scope enforcement — check if the route requires a specific scope
        if _API_KEY_SCOPES is not None:
            path = request.url.path
            for prefix, scope in _ROUTE_SCOPE_MAP.items():
                if path.startswith(prefix) and scope not in _API_KEY_SCOPES:
                    return JSONResponse(
                        status_code=403,
                        content={"detail": f"API key does not have the '{scope}' scope."},
                    )

        return await call_next(request)
