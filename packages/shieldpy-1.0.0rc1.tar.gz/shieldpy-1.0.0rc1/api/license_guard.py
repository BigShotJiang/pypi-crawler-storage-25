"""License enforcement middleware for the promptShield sidecar.

SECURITY CRITICAL — This module ensures the sidecar cannot operate without
a valid license, even if someone extracts the binary and runs it standalone.

Three layers of protection:
  1. Session token: Tauri passes a random token via PS_SESSION_TOKEN env var.
     Every HTTP request must include it in the X-Session-Token header.
  2. Expiry deadline: Tauri passes the license expiry via PS_LICENSE_EXPIRES.
     The sidecar self-terminates when this deadline passes.
  3. Periodic license file check: Independently reads and validates the
     Ed25519-signed license blob from disk every 30 seconds.
"""

from __future__ import annotations

import base64
import json
import logging
import os
import secrets
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

logger = logging.getLogger(__name__)

# ── Session token from Tauri (set at sidecar launch) ────────────

_SESSION_TOKEN: Optional[str] = os.environ.get("PS_SESSION_TOKEN")
_LICENSE_EXPIRES: Optional[str] = os.environ.get("PS_LICENSE_EXPIRES")

# Dev mode detection.  PS_DEV_MODE is only honored when running from source
# (i.e. `python main.py`).  In compiled/frozen builds (Nuitka, PyInstaller)
# the flag is forcibly ignored so that extracting the release sidecar binary
# and setting PS_DEV_MODE=1 cannot bypass licensing.
_DEV_MODE_RAW: bool = os.environ.get("PS_DEV_MODE", "").strip() in ("1", "true", "yes")

def _is_compiled() -> bool:
    """Return True when running as a compiled binary (Nuitka / PyInstaller)."""
    if getattr(sys, "frozen", False):
        return True
    try:
        __compiled__  # type: ignore[name-defined]  # noqa: F821 — injected by Nuitka
        return True
    except NameError:
        return False

_DEV_MODE: bool = _DEV_MODE_RAW and not _is_compiled()

# Session token TTL — tokens older than this are rejected.
# The creation timestamp is passed via PS_SESSION_TOKEN_CREATED (ISO 8601).
_SESSION_TOKEN_CREATED: Optional[str] = os.environ.get("PS_SESSION_TOKEN_CREATED")
_SESSION_TOKEN_TTL_HOURS: int = 4  # max session length before forced restart

# Flag: once set to True, ALL requests are rejected and server shuts down
_license_dead = False
_license_dead_lock = threading.Lock()


def _mark_dead(reason: str) -> None:
    """Mark the license as dead — all subsequent requests will be rejected."""
    global _license_dead
    with _license_dead_lock:
        if _license_dead:
            return
        _license_dead = True
    logger.critical("[LICENSE] Shutting down: %s", reason)
    # Give a moment for the 403 response to be sent, then exit hard
    threading.Timer(2.0, _force_exit).start()


def _force_exit() -> None:
    """Forcefully terminate the sidecar process."""
    logger.critical("[LICENSE] Force-exiting sidecar process")
    # os._exit bypasses Python cleanup and reliably terminates on all
    # platforms (os.kill + SIGTERM is a no-op on Windows).
    os._exit(1)


# ── License file path (mirrors Rust logic) ──────────────────────

def _license_file_path() -> Path:
    """Return the license file path (same as Rust's license_file_path)."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "promptshield" / "license.key"


def _check_license_expiry_from_blob() -> bool:
    """Read the license file and check if it's still valid.

    Returns True if the license exists and has not expired.
    Returns False if missing, unreadable, or expired.

    NOTE: We don't verify the Ed25519 signature here (the Rust side does that
    at launch). We DO check the expiry timestamp from the signed payload.
    A user cannot forge a later expiry without the server's private key.
    """
    try:
        path = _license_file_path()
        if not path.exists():
            return False
        blob = path.read_text(encoding="utf-8").strip()
        if not blob or "." not in blob:
            return False

        # Decode payload (first part before the dot)
        payload_b64 = blob.split(".", 1)[0]
        payload_json = base64.b64decode(payload_b64)
        payload = json.loads(payload_json)

        expires_str = payload.get("expires", "")
        if not expires_str:
            return False

        # Parse RFC 3339 expiry
        expires = datetime.fromisoformat(expires_str.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)

        return expires > now
    except (OSError, json.JSONDecodeError, KeyError, ValueError) as e:
        logger.warning("[LICENSE] Failed to check license file: %s", e)
        return False


def _check_expiry_from_env() -> bool:
    """Check if the license expiry from env var has passed."""
    if not _LICENSE_EXPIRES:
        return False  # No expiry set → treat as expired (fail closed)
    try:
        expires = datetime.fromisoformat(_LICENSE_EXPIRES.replace("Z", "+00:00"))
        return expires > datetime.now(timezone.utc)
    except ValueError:
        return False  # Can't parse → treat as expired


# ── Periodic background license checker ─────────────────────────

_RECHECK_INTERVAL = 30  # seconds


def _periodic_license_checker() -> None:
    """Background thread that checks license validity every 30 seconds.

    If the license has expired (either by env-var deadline or license file),
    the sidecar shuts itself down. This ensures that even if someone keeps
    the process running, it will stop once the billing cycle ends.
    """
    while True:
        time.sleep(_RECHECK_INTERVAL)

        if _license_dead:
            return

        # Check env-var expiry (primary — set by Tauri at launch)
        if _LICENSE_EXPIRES and not _check_expiry_from_env():
            _mark_dead("License expired (env deadline)")
            return

        # Check on-disk license file (secondary — catches file deletion/revocation)
        if not _check_license_expiry_from_blob():
            _mark_dead("License expired or removed (disk check)")
            return


def start_license_watchdog() -> None:
    """Start the background license checker thread."""
    # Dev mode — skip all license enforcement (only possible when launched by Tauri dev)
    if _DEV_MODE:
        logger.warning("[LICENSE] DEV MODE — license enforcement disabled")
        return

    # Standalone prevention: if no session token AND no license expires env var
    # AND not in dev mode (source-only), someone extracted the binary.
    if not _SESSION_TOKEN and not _LICENSE_EXPIRES and not _DEV_MODE:
        logger.critical("[LICENSE] Missing PS_SESSION_TOKEN — sidecar cannot run standalone")
        print("[LICENSE] Not launched by PromptShield. Exiting.", flush=True)
        sys.exit(1)

    # Even with a session token, verify we have a valid license on disk
    # (skip in dev mode — the developer may not have a license installed)
    if not _DEV_MODE and not _check_license_expiry_from_blob():
        logger.critical("[LICENSE] No valid license found — refusing to start")
        print("[LICENSE] No valid license. Exiting.", flush=True)
        sys.exit(1)

    t = threading.Thread(target=_periodic_license_checker, daemon=True, name="license-watchdog")
    t.start()
    logger.info("[LICENSE] License watchdog started (checking every %ds)", _RECHECK_INTERVAL)


# ── ASGI Middleware ─────────────────────────────────────────────

# Paths exempt from the session token check (health check only)
_EXEMPT_PATHS = frozenset({"/health"})


def _allows_query_token(path: str, method: str) -> bool:
    """Allow `_st` query token only for read-only bitmap endpoints.

    Browser `<img>` requests cannot attach custom headers, so bitmap routes
    accept the same session token via query string. Keep this narrowly scoped
    to avoid weakening auth on mutable or unrelated endpoints.
    """
    if method not in {"GET", "HEAD"}:
        return False
    if path.startswith("/api/documents/") and path.endswith("/bitmap"):
        return True
    if path.startswith("/bitmaps/") or path.startswith("/storage-bitmaps/"):
        return True
    return False


class LicenseGuardMiddleware(BaseHTTPMiddleware):
    """Reject all API requests if the license is invalid.

    Checks:
      1. If _license_dead is True → 403 immediately.
      2. If PS_SESSION_TOKEN is set (Tauri mode), require X-Session-Token header.
      3. If PS_LICENSE_EXPIRES is set, check deadline on every request.
    """

    async def dispatch(self, request: Request, call_next):
        # Always allow health check (for monitoring / Tauri polling)
        if request.url.path in _EXEMPT_PATHS:
            return await call_next(request)

        # Always allow CORS preflight — these never carry credentials and
        # must reach the CORSMiddleware so it can return the proper
        # Access-Control-Allow-* headers.  Blocking them here causes
        # "Failed to fetch" in the Tauri webview.
        if request.method == "OPTIONS":
            return await call_next(request)

        # Dev mode — skip all enforcement
        if _DEV_MODE:
            return await call_next(request)

        # Check if license has been killed
        if _license_dead:
            return JSONResponse(
                status_code=403,
                content={"detail": "License expired. Please renew your subscription."},
            )

        # Session token check (Tauri mode)
        if _SESSION_TOKEN:
            provided = request.headers.get("x-session-token", "")
            if not provided and _allows_query_token(request.url.path, request.method):
                provided = request.query_params.get("_st", "")
            if not provided or not secrets.compare_digest(provided, _SESSION_TOKEN):
                return JSONResponse(
                    status_code=403,
                    content={"detail": "Invalid or missing session token."},
                )

            # Session token TTL check — reject tokens older than _SESSION_TOKEN_TTL_HOURS
            if _SESSION_TOKEN_CREATED:
                try:
                    created = datetime.fromisoformat(
                        _SESSION_TOKEN_CREATED.replace("Z", "+00:00")
                    )
                    age_hours = (datetime.now(timezone.utc) - created).total_seconds() / 3600
                    if age_hours > _SESSION_TOKEN_TTL_HOURS:
                        _mark_dead(f"Session token expired (age={age_hours:.1f}h > {_SESSION_TOKEN_TTL_HOURS}h)")
                        return JSONResponse(
                            status_code=403,
                            content={"detail": "Session expired. Please restart the application."},
                        )
                except ValueError:
                    logger.warning("[LICENSE] Could not parse PS_SESSION_TOKEN_CREATED: %s", _SESSION_TOKEN_CREATED)

        # Live expiry check on every request (belt + suspenders)
        if _LICENSE_EXPIRES and not _check_expiry_from_env():
            _mark_dead("License expired (request-time check)")
            return JSONResponse(
                status_code=403,
                content={"detail": "License expired. Please renew your subscription."},
            )

        return await call_next(request)
