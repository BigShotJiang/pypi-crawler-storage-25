"""Shared state, helpers, and re-exports used by all API routers."""

from __future__ import annotations

import asyncio
import json
import logging
import threading
import time as _time
from contextlib import contextmanager
from typing import Any, Generator, Optional

from fastapi import HTTPException

from core.config import config
from core.persistence import DocumentStore
from models.schemas import BBox, DocumentInfo, DocumentListItem, DocumentStatus, RegionAction
from api.repository import DocumentRepository

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy-loading document dictionary
# ---------------------------------------------------------------------------

class LazyDocumentDict(dict):
    """A dict subclass that loads documents from disk on first access.

    At startup only the *keys* (doc_ids from filenames) are registered.
    The actual JSON parse + Pydantic validation happens lazily when a
    document is first accessed, eliminating the O(n) eager-load cost.
    """

    _store: Optional[DocumentStore] = None
    _pending: set  # doc_ids registered but not yet loaded from disk

    def __init__(self) -> None:
        super().__init__()
        self._pending = set()

    # -- lazy access ---------------------------------------------------------

    def __getitem__(self, key: str) -> DocumentInfo:
        if key in self._pending:
            self._load_one(key)
        return super().__getitem__(key)

    def __contains__(self, key: object) -> bool:
        return super().__contains__(key) or key in self._pending

    def get(self, key: str, default=None):
        if key in self._pending:
            self._load_one(key)
        return super().get(key, default)

    def __delitem__(self, key: str) -> None:
        self._pending.discard(key)
        super().__delitem__(key)

    def values(self):
        self._load_all_pending()
        return super().values()

    def items(self):
        self._load_all_pending()
        return super().items()

    def __iter__(self):
        # All known keys: loaded + pending
        seen = set(super().keys())
        yield from super().__iter__()
        for k in list(self._pending):
            if k not in seen:
                yield k

    def __len__(self):
        return super().__len__() + len(self._pending)

    # -- bulk registration (called at startup) -------------------------------

    def register_ids(self, doc_ids: list[str], doc_store: DocumentStore) -> None:
        """Register doc_ids for lazy loading without reading JSON."""
        self._store = doc_store
        for doc_id in doc_ids:
            if doc_id not in self:  # don't clobber already-loaded docs
                self._pending.add(doc_id)

    # -- internal loading ----------------------------------------------------

    def _load_one(self, doc_id: str) -> None:
        """Load a single document from disk into the dict."""
        self._pending.discard(doc_id)
        if self._store is None:
            return
        try:
            doc = self._store.load_document(doc_id)
            if doc:
                # Sanitize legacy region bounds on load (lazy per-document)
                _sanitize_doc_regions_on_load(doc, self._store)
                super().__setitem__(doc_id, doc)
            else:
                logger.warning("Document %s not found on disk", doc_id)
        except (ValueError, OSError) as e:
            logger.warning("Skipping corrupted document %s: %s", doc_id, e)

    def _load_all_pending(self) -> None:
        """Eagerly load any remaining pending documents."""
        if not self._pending:
            return
        remaining = list(self._pending)
        from concurrent.futures import ThreadPoolExecutor

        def _load(did: str) -> tuple[str, DocumentInfo | None]:
            try:
                return (did, self._store.load_document(did) if self._store else None)
            except (ValueError, OSError) as e:
                logger.warning("Skipping corrupted document %s: %s", did, e)
                return (did, None)

        with ThreadPoolExecutor(max_workers=min(8, len(remaining))) as pool:
            for did, doc in pool.map(_load, remaining):
                self._pending.discard(did)
                if doc:
                    super().__setitem__(did, doc)

    def list_summaries(self) -> list[DocumentListItem]:
        """Return DocumentListItem for every document without triggering full load.

        Already-loaded documents use in-memory data.  Pending documents are
        read via a lightweight metadata reader that skips Pydantic validation
        of regions, pages, and text_blocks — much faster for large documents.
        """
        items: list[DocumentListItem] = []

        # Already-loaded docs — use in-memory data (free)
        for doc in super().values():
            items.append(_doc_to_list_item(doc))

        # Pending (not-yet-loaded) docs — lightweight metadata read
        if self._pending and self._store:
            from concurrent.futures import ThreadPoolExecutor

            pending = list(self._pending)

            def _read_meta(did: str) -> tuple[str, dict | None]:
                try:
                    return (did, self._store.load_document_meta(did))
                except (OSError, json.JSONDecodeError, ValueError, TypeError) as e:
                    logger.warning("Skipping metadata for %s: %s", did, e)
                    return (did, None)

            with ThreadPoolExecutor(max_workers=min(8, len(pending))) as pool:
                for did, meta in pool.map(_read_meta, pending):
                    if meta:
                        items.append(_meta_to_list_item(meta))

        return items


# ---------------------------------------------------------------------------
# Singleton state  (mutated by server.startup, read everywhere)
# ---------------------------------------------------------------------------
documents: LazyDocumentDict = LazyDocumentDict()
store: Optional[DocumentStore] = None

# Repository instance for cleaner data access (wraps the documents dict)
doc_repo: DocumentRepository = DocumentRepository(documents)

# H1: asyncio lock to serialise document mutations from concurrent requests
_documents_lock = asyncio.Lock()

# In-memory detection progress tracker  (doc_id → progress dict)
detection_progress: dict[str, dict] = {}

# Set of doc_ids whose detection should be cancelled ASAP
_detection_cancelled: set[str] = set()

# In-memory upload/ingestion progress tracker (doc_id → progress dict)
# Tracks file loading, page extraction, and OCR progress
upload_progress: dict[str, dict] = {}

# In-memory export progress tracker (export_id → progress dict)
export_progress: dict[str, dict] = {}

# Maximum age (seconds) for completed/errored detection progress entries
_PROGRESS_TTL = 300  # 5 minutes
_MAX_PROGRESS_ENTRIES = 500  # Safety cap per tracker


def _cleanup_stale_entries(tracker: dict[str, dict], label: str) -> None:
    """Remove completed/errored progress entries older than TTL."""
    now = _time.time()
    stale = [
        k for k, v in tracker.items()
        if v.get("status") in ("complete", "error")
        and now - v.get("_started_at", now) > _PROGRESS_TTL
    ]
    for k in stale:
        tracker.pop(k, None)
    # Hard cap: if tracker still exceeds limit, remove oldest entries
    if len(tracker) > _MAX_PROGRESS_ENTRIES:
        sorted_keys = sorted(tracker, key=lambda k: tracker[k].get("_started_at", 0))
        for k in sorted_keys[: len(tracker) - _MAX_PROGRESS_ENTRIES]:
            tracker.pop(k, None)


def cleanup_stale_progress() -> None:
    """Remove completed/errored detection_progress entries older than TTL."""
    _cleanup_stale_entries(detection_progress, "detection")


def cleanup_stale_upload_progress() -> None:
    """Remove completed/errored upload_progress entries older than TTL."""
    _cleanup_stale_entries(upload_progress, "upload")


def cleanup_stale_export_progress() -> None:
    """Remove completed/errored export_progress entries older than TTL."""
    _cleanup_stale_entries(export_progress, "export")

# Detection lock — per-document to allow parallel detection of different docs.
# A separate config lock prevents concurrent config mutations (redetect, settings).
_doc_locks: dict[str, threading.Lock] = {}
_doc_lock_times: dict[str, float] = {}
_doc_locks_guard = threading.Lock()  # protects _doc_locks dict itself
_config_lock = threading.Lock()
_config_lock_acquired_at: float | None = None
_DETECTION_LOCK_TIMEOUT_S: float = 600.0  # 10 minutes max


# ---------------------------------------------------------------------------
# Convenience accessors
# ---------------------------------------------------------------------------

def get_store() -> DocumentStore:
    """Return the document store; raise if not initialised."""
    if store is None:
        raise RuntimeError("Document store not initialized")
    return store


def _clamp_bbox(bbox: BBox, page_w: float, page_h: float) -> BBox:
    """Clamp a bounding box so it sits within [0, page_w] × [0, page_h]."""
    return BBox(
        x0=max(0.0, min(bbox.x0, page_w)),
        y0=max(0.0, min(bbox.y0, page_h)),
        x1=max(0.0, min(bbox.x1, page_w)),
        y1=max(0.0, min(bbox.y1, page_h)),
    )


def _sanitize_doc_regions_on_load(doc: DocumentInfo, doc_store: DocumentStore) -> None:
    """Sanitize legacy region bounds when a document is lazily loaded.

    Runs the same clamping as sanitize_document_regions() but only for
    this single document, and auto-saves if any bounds changed.
    """
    page_map = {p.page_number: p for p in doc.pages}
    changed = False
    for region in doc.regions:
        pd = page_map.get(region.page_number)
        if pd is None:
            continue
        clamped = _clamp_bbox(region.bbox, pd.width, pd.height)
        if clamped != region.bbox:
            region.bbox = clamped
            changed = True
    if changed:
        try:
            doc_store.save_document(doc)
        except OSError as e:
            logger.warning("Failed to save sanitized regions for %s: %s", doc.doc_id, e)


def _doc_to_list_item(d: DocumentInfo) -> DocumentListItem:
    """Build a DocumentListItem from a fully-loaded DocumentInfo."""
    return DocumentListItem(
        doc_id=d.doc_id,
        original_filename=d.original_filename,
        filename=d.original_filename,
        file_path=d.file_path,
        mime_type=d.mime_type,
        page_count=d.page_count,
        status=d.status,
        regions_count=len(d.regions),
        is_protected=(
            len(d.regions) > 0
            and not any(r.action == RegionAction.PENDING for r in d.regions)
            and any(r.action in (RegionAction.TOKENIZE, RegionAction.REMOVE) for r in d.regions)
        ),
        cancelled_count=sum(1 for r in d.regions if r.action == RegionAction.CANCEL),
        excluded_pages_count=len(d.excluded_pages),
        group_id=d.group_id,
        group_name=d.group_name,
        created_at=d.created_at,
    )


def _meta_to_list_item(meta: dict) -> DocumentListItem:
    """Build a DocumentListItem from a lightweight metadata dict."""
    from datetime import datetime, timezone

    created = meta.get("created_at")
    if isinstance(created, str):
        try:
            created = datetime.fromisoformat(created)
        except (ValueError, TypeError):
            created = datetime.now(timezone.utc)
    elif not isinstance(created, datetime):
        created = datetime.now(timezone.utc)

    return DocumentListItem(
        doc_id=meta["doc_id"],
        original_filename=meta.get("original_filename", ""),
        filename=meta.get("original_filename", ""),
        file_path=meta.get("file_path", ""),
        mime_type=meta.get("mime_type", ""),
        page_count=meta.get("page_count", 0),
        status=DocumentStatus(meta.get("status", "EXTRACTED")),
        regions_count=meta.get("regions_count", 0),
        is_protected=meta.get("is_protected", False),
        cancelled_count=meta.get("cancelled_count", 0),
        excluded_pages_count=len(meta.get("excluded_pages", [])),
        group_id=meta.get("group_id"),
        group_name=meta.get("group_name"),
        created_at=created,
    )


def sanitize_document_regions(doc: DocumentInfo) -> bool:
    """Clamp every region's bbox to its page bounds.

    Returns True if any region was modified.
    """
    page_map = {p.page_number: p for p in doc.pages}
    changed = False
    for region in doc.regions:
        pd = page_map.get(region.page_number)
        if pd is None:
            continue
        clamped = _clamp_bbox(region.bbox, pd.width, pd.height)
        if clamped != region.bbox:
            region.bbox = clamped
            changed = True
    return changed


def get_doc(doc_id: str) -> DocumentInfo:
    """Fetch a document by id or 404."""
    if doc_id not in documents:
        raise HTTPException(status_code=404, detail=f"Document '{doc_id}' not found")
    return documents[doc_id]


def save_doc(doc: DocumentInfo) -> None:
    """Persist the document to disk and update the region cache."""
    try:
        s = get_store()
        s.save_document(doc)
        # Keep region cache in sync so re-uploads always restore regions,
        # even if the delete path doesn't run (e.g. sidecar crash).
        if doc.regions and doc.content_hash:
            s.save_region_cache(doc.content_hash, doc.regions, doc.original_filename)
        logger.debug("Auto-saved document %s", doc.doc_id)
    except (OSError, ValueError, TypeError):
        # M9: Log full traceback — callers should not silently lose data
        logger.exception("Failed to auto-save document %s", doc.doc_id)


@contextmanager
def mutate_doc(doc: DocumentInfo) -> Generator[DocumentInfo, None, None]:
    """Context manager for document mutations — auto-saves on exit.

    Usage::

        with mutate_doc(doc) as d:
            d.regions.append(new_region)
        # doc is auto-persisted here

    If the block raises, the document is still saved to avoid data loss
    from partial mutations.
    """
    try:
        yield doc
    finally:
        save_doc(doc)


def now_ts() -> float:
    """Monotonic-ish wall-clock timestamp (``time.time()``)."""
    return _time.time()


def get_active_llm_engine() -> object | None:
    """Return the currently active LLM engine (local or remote) or None.

    When the provider is "remote" but the remote engine is not configured
    (e.g. API key missing after restart), falls back to the local engine
    if it is loaded.
    """
    from core.llm.engine import llm_engine
    from core.llm.remote_engine import remote_llm_engine

    if config.llm_provider == "remote":
        if remote_llm_engine.is_loaded():
            return remote_llm_engine
        # Fallback: use local engine if available
        if llm_engine.is_loaded():
            logger.warning(
                "Remote LLM not available (missing API key?); "
                "falling back to local engine: %s",
                llm_engine.model_name,
            )
            return llm_engine
        return None
    # default: local
    if llm_engine.is_loaded():
        return llm_engine
    return None


def acquire_detection_lock(doc_id: str) -> bool:
    """Try to acquire the per-document detection lock (non-blocking).

    Returns True if acquired.  Different documents can detect in parallel;
    only the *same* document is serialised.

    If a previous lock for this doc has been held longer than
    ``_DETECTION_LOCK_TIMEOUT_S``, it is considered stale and forcibly
    released before re-acquiring.
    """
    with _doc_locks_guard:
        if doc_id not in _doc_locks:
            _doc_locks[doc_id] = threading.Lock()
        lock = _doc_locks[doc_id]

    acquired = lock.acquire(blocking=False)
    if acquired:
        with _doc_locks_guard:
            _doc_lock_times[doc_id] = _time.time()
        return True

    # Check for stale lock
    with _doc_locks_guard:
        acq_time = _doc_lock_times.get(doc_id)
    if acq_time is not None:
        held_for = _time.time() - acq_time
        if held_for > _DETECTION_LOCK_TIMEOUT_S:
            logger.warning(
                "Detection lock for doc %s held for %.0fs (>%.0fs) — forcing release (stale)",
                doc_id, held_for, _DETECTION_LOCK_TIMEOUT_S,
            )
            try:
                lock.release()
            except RuntimeError:
                pass
            acquired = lock.acquire(blocking=False)
            if acquired:
                with _doc_locks_guard:
                    _doc_lock_times[doc_id] = _time.time()
                return True

    logger.warning("Detection already running for doc %s — rejecting", doc_id)
    return False


def release_detection_lock(doc_id: str) -> None:
    """Release the per-document detection lock."""
    with _doc_locks_guard:
        _doc_lock_times.pop(doc_id, None)
        lock = _doc_locks.get(doc_id)
    if lock is None:
        return
    try:
        lock.release()
    except RuntimeError:
        logger.warning("Detection lock for doc %s was already released", doc_id)


def request_detection_cancel(doc_id: str) -> None:
    """Mark *doc_id* for cancellation.  Worker threads check this flag."""
    _detection_cancelled.add(doc_id)
    logger.info("Cancellation requested for doc %s", doc_id)


def is_detection_cancelled(doc_id: str) -> bool:
    """Return True if cancellation was requested for *doc_id*."""
    return doc_id in _detection_cancelled


def clear_detection_cancel(doc_id: str) -> None:
    """Clear the cancellation flag (called when detection finishes/aborts)."""
    _detection_cancelled.discard(doc_id)


def prune_doc_locks() -> None:
    """Remove lock entries for documents that no longer exist in memory.

    Should be called periodically (e.g. after document deletion) to prevent
    unbounded growth of ``_doc_locks`` / ``_doc_lock_times``.
    """
    with _doc_locks_guard:
        stale = [k for k in _doc_locks if k not in documents]
        for k in stale:
            _doc_locks.pop(k, None)
            _doc_lock_times.pop(k, None)
        if stale:
            logger.debug("Pruned %d stale detection lock(s)", len(stale))


def acquire_config_lock(doc_id: str) -> bool:
    """Acquire the global config lock (for redetect / settings that mutate config).

    Only one config-mutating operation can run at a time.
    """
    global _config_lock_acquired_at
    acquired = _config_lock.acquire(blocking=False)
    if acquired:
        _config_lock_acquired_at = _time.time()
        return True

    # Check for stale config lock
    if _config_lock_acquired_at is not None:
        held_for = _time.time() - _config_lock_acquired_at
        if held_for > _DETECTION_LOCK_TIMEOUT_S:
            logger.warning(
                "Config lock held for %.0fs (>%.0fs) — forcing release",
                held_for, _DETECTION_LOCK_TIMEOUT_S,
            )
            try:
                _config_lock.release()
            except RuntimeError:
                pass
            acquired = _config_lock.acquire(blocking=False)
            if acquired:
                _config_lock_acquired_at = _time.time()
                return True

    logger.warning("Config lock busy — rejecting request for %s", doc_id)
    return False


def release_config_lock() -> None:
    """Release the global config lock."""
    global _config_lock_acquired_at
    _config_lock_acquired_at = None
    try:
        _config_lock.release()
    except RuntimeError:
        logger.warning("Config lock was already released")


@contextmanager
def config_override(**overrides: Any) -> Generator[None, None, None]:
    """Temporarily override config attributes in a thread-safe manner.

    C6: This mutates a global singleton. Must ONLY be used while the
    config lock is held to prevent concurrent mutations.
    """
    originals = {}
    for key, value in overrides.items():
        if hasattr(config, key):
            originals[key] = getattr(config, key)
            setattr(config, key, value)
    try:
        yield
    finally:
        for key, value in originals.items():
            setattr(config, key, value)
