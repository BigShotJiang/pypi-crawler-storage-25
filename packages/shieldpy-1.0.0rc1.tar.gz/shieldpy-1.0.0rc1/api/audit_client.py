"""Fire-and-forget audit logging to the PromptShield licensing server.

The sidecar authenticates via X-Machine-Token (HMAC token issued at
activation) or falls back to X-Machine-Fingerprint for backward compat.
Failures are silently swallowed so audit logging never interrupts user
operations.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Strong references to in-flight audit tasks so they aren't garbage-collected
# before completion.  (Python 3.12+ event loops only keep weak refs to tasks.)
_background_tasks: set[asyncio.Task] = set()

_LICENSING_URL: str = os.environ.get(
    "PS_LICENSING_URL", "https://api.promptshield.ca"
).rstrip("/")

_DEV_MODE: bool = os.environ.get("PS_DEV_MODE", "").strip() in ("1", "true", "yes")

# App version injected by Tauri at sidecar launch (e.g. "2.3.1")
_APP_VERSION: Optional[str] = os.environ.get("PS_APP_VERSION") or None

# Machine fingerprint priority:
# 1. PS_MACHINE_FINGERPRINT — live value injected by Tauri at sidecar launch
# 2. PS_AUDIT_MACHINE_FINGERPRINT — manual dev override
# 3. On-disk license.key blob (fallback)
_ENV_FINGERPRINT: Optional[str] = (
    os.environ.get("PS_MACHINE_FINGERPRINT")
    or os.environ.get("PS_AUDIT_MACHINE_FINGERPRINT")
    or None
)

# SEC-1: HMAC machine token injected by Tauri at sidecar launch
_ENV_MACHINE_TOKEN: Optional[str] = os.environ.get("PS_MACHINE_TOKEN") or None


def _license_file_path() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "promptshield" / "license.key"


def _read_machine_fingerprint() -> Optional[str]:
    """Return the machine fingerprint for audit authentication.

    Prefers the env-var fingerprint (injected by Tauri at sidecar launch)
    over parsing the on-disk license blob, which may be stale.
    """
    if _ENV_FINGERPRINT:
        return _ENV_FINGERPRINT
    try:
        path = _license_file_path()
        if not path.exists():
            return None
        blob = path.read_text(encoding="utf-8").strip()
        if not blob or "." not in blob:
            return None
        payload_b64 = blob.split(".", 1)[0]
        payload = json.loads(base64.b64decode(payload_b64))
        return payload.get("machine_id") or None
    except Exception:
        return None


def _read_license_plan() -> Optional[str]:
    """Extract plan from the on-disk license blob payload."""
    try:
        path = _license_file_path()
        if not path.exists():
            return None
        blob = path.read_text(encoding="utf-8").strip()
        if not blob or "." not in blob:
            return None
        payload_b64 = blob.split(".", 1)[0]
        payload = json.loads(base64.b64decode(payload_b64))
        return payload.get("plan") or None
    except Exception:
        return None


async def _post_audit_async(body: dict[str, Any]) -> None:
    """Send a single audit event; swallow all errors."""
    fingerprint = _read_machine_fingerprint()
    if not fingerprint and not _ENV_MACHINE_TOKEN:
        logger.debug("[audit] No machine fingerprint or token — skipping audit event")
        return
    # SEC-1: Prefer HMAC machine token over raw fingerprint
    headers: dict[str, str] = {}
    if _ENV_MACHINE_TOKEN:
        headers["X-Machine-Token"] = _ENV_MACHINE_TOKEN
    elif fingerprint:
        headers["X-Machine-Fingerprint"] = fingerprint
    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{_LICENSING_URL}/audit",
                json=body,
                headers=headers,
            )
            if resp.status_code not in (200, 201):
                logger.warning("[audit] Server returned %d: %s", resp.status_code, resp.text[:200])
            else:
                logger.info("[audit] Event posted: %s", body.get("action"))
    except Exception as exc:
        logger.warning("[audit] Failed to post audit event: %s", exc)


def log_event(
    action: str,
    *,
    result: str = "success",
    entity_count: Optional[int] = None,
    target_ref: Optional[str] = None,
    trace_id: Optional[str] = None,
    file_type: Optional[str] = None,
    entity_types: Optional[dict] = None,
    duration_ms: Optional[int] = None,
    app_version: Optional[str] = None,
) -> None:
    """Schedule a fire-and-forget audit event on the running event loop.

    Safe to call from any async context (FastAPI route handlers).
    The server enforces plan-level access — the client only checks that a
    machine fingerprint is available (needed for authentication).
    """
    fp = _read_machine_fingerprint()
    if not fp:
        logger.warning("[audit] No fingerprint — dropping %s event", action)
        return

    logger.warning("[audit] Scheduling %s event (fp=%s...)", action, fp[:12])
    body: dict[str, Any] = {"action": action, "result": result}
    if entity_count is not None:
        body["entity_count"] = entity_count
    if target_ref is not None:
        body["target_ref"] = target_ref
    if trace_id is not None:
        body["trace_id"] = trace_id
    if file_type is not None:
        body["file_type"] = file_type
    if entity_types is not None:
        body["entity_types"] = entity_types
    if duration_ms is not None:
        body["duration_ms"] = duration_ms
    body["app_version"] = app_version or _APP_VERSION

    try:
        loop = asyncio.get_event_loop()
        task = loop.create_task(_post_audit_async(body))
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)
    except RuntimeError:
        pass  # No running loop — silently skip
