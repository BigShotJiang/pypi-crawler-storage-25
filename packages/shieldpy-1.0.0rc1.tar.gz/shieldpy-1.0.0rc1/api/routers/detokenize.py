"""Text and file de-tokenization endpoints."""

from __future__ import annotations

import asyncio
import io
import json
import logging
import shutil
import zipfile
from pathlib import Path
from typing import List

from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask

from core.config import config
from models.schemas import (
    DetokenizeRequest,
    DetokenizeResponse,
)
from api.audit_client import log_event as _audit

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["detokenize"])


@router.post("/detokenize", response_model=DetokenizeResponse)
async def detokenize(req: DetokenizeRequest) -> DetokenizeResponse:
    """Replace tokens in text with their original values."""
    from models.schemas import MAX_PASTE_CHARS
    if len(req.text) > MAX_PASTE_CHARS:
        raise HTTPException(413, f"Text too long. Maximum length is {MAX_PASTE_CHARS:,} characters.")
    from core.vault.store import vault
    vault.ensure_ready()

    result_text, count, unresolved, replacements = await asyncio.to_thread(
        vault.resolve_all_tokens, req.text
    )
    _audit("detokenize", entity_count=count)
    return DetokenizeResponse(
        original_text=result_text,
        tokens_replaced=count,
        unresolved_tokens=unresolved,
        replacements=replacements,
    )


@router.post("/detokenize/file")
async def detokenize_file_endpoint(file: UploadFile = File(...)) -> FileResponse:
    """De-tokenize tokens inside an uploaded file (.docx, .xlsx, .pdf, .txt, .csv)."""
    from core.vault.store import vault
    from core.detokenize_file import detokenize_file, SUPPORTED_EXTENSIONS

    vault.ensure_ready()

    filename = file.filename or "unknown.txt"

    # M11: Enforce max upload size (100 MB)
    _MAX_FILE_SIZE = 100 * 1024 * 1024
    data = await file.read()
    if len(data) > _MAX_FILE_SIZE:
        raise HTTPException(413, f"File too large. Maximum size is {_MAX_FILE_SIZE // (1024*1024)} MB.")

    try:
        out_bytes, out_name, count, unresolved, repl = detokenize_file(data, filename, vault)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        logger.error("File de-tokenization failed: %s", e, exc_info=True)
        raise HTTPException(500, "De-tokenization failed. Check server logs for details.")

    _audit("detokenize", entity_count=count,
           file_type=Path(filename).suffix.lstrip(".").lower() or None)

    ext = Path(out_name).suffix.lower()
    media_types = {
        ".txt": "text/plain",
        ".csv": "text/csv",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".pdf": "application/pdf",
    }
    media_type = media_types.get(ext, "application/octet-stream")

    import tempfile
    tmp = Path(tempfile.mkdtemp(dir=str(config.temp_dir)))
    out_path = tmp / out_name
    out_path.write_bytes(out_bytes)

    def _cleanup() -> None:
        try:
            shutil.rmtree(tmp, ignore_errors=True)
        except Exception:
            logger.warning("Failed to clean up temp dir %s", tmp, exc_info=True)

    headers = {
        "X-Tokens-Replaced": str(count),
        "X-Unresolved-Tokens": ",".join(unresolved) if unresolved else "",
        "X-Replacements": json.dumps(repl, ensure_ascii=True) if repl else "[]",
        "Access-Control-Expose-Headers": "X-Tokens-Replaced, X-Unresolved-Tokens, X-Replacements",
    }

    return FileResponse(
        str(out_path),
        media_type=media_type,
        filename=out_name,
        headers=headers,
        background=BackgroundTask(_cleanup),
    )


@router.post("/detokenize/files")
async def detokenize_files_endpoint(
    files: List[UploadFile] = File(...),
):
    """Batch de-tokenize multiple files. Returns a ZIP archive containing all results."""
    from core.vault.store import vault
    from core.detokenize_file import detokenize_file, SUPPORTED_EXTENSIONS

    vault.ensure_ready()

    if not files:
        raise HTTPException(400, "No files provided.")

    _MAX_FILE_SIZE = 100 * 1024 * 1024
    _MAX_TOTAL_SIZE = 500 * 1024 * 1024

    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []
    seen_tokens: set[str] = set()
    results: list[tuple[bytes, str]] = []  # (out_bytes, out_name)

    total_bytes = 0
    for file in files:
        filename = file.filename or "unknown.txt"
        data = await file.read()
        total_bytes += len(data)

        if len(data) > _MAX_FILE_SIZE:
            raise HTTPException(
                413,
                f"File '{filename}' too large ({len(data) // (1024*1024)} MB). Maximum is {_MAX_FILE_SIZE // (1024*1024)} MB.",
            )
        if total_bytes > _MAX_TOTAL_SIZE:
            raise HTTPException(
                413,
                f"Total upload size exceeds {_MAX_TOTAL_SIZE // (1024*1024)} MB limit.",
            )

        try:
            out_bytes, out_name, count, unresolved, repl = await asyncio.to_thread(
                detokenize_file, data, filename, vault,
            )
            results.append((out_bytes, out_name))
            total_replaced += count
            all_unresolved.extend(unresolved)
            for r in repl:
                if r["token"] not in seen_tokens:
                    seen_tokens.add(r["token"])
                    all_replacements.append(r)
        except ValueError as e:
            raise HTTPException(400, f"Error processing '{filename}': {e}")
        except Exception as e:
            logger.error("Batch de-tokenization failed for '%s': %s", filename, e, exc_info=True)
            raise HTTPException(500, f"De-tokenization failed for '{filename}'.")

    _audit("detokenize", entity_count=total_replaced)

    # If only one file, return it directly (same as single-file endpoint)
    if len(results) == 1:
        out_bytes, out_name = results[0]
        ext = Path(out_name).suffix.lower()
        media_types = {
            ".txt": "text/plain",
            ".csv": "text/csv",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            ".pdf": "application/pdf",
        }
        media_type = media_types.get(ext, "application/octet-stream")

        import tempfile
        tmp = Path(tempfile.mkdtemp(dir=str(config.temp_dir)))
        out_path = tmp / out_name
        out_path.write_bytes(out_bytes)

        def _cleanup_single() -> None:
            try:
                shutil.rmtree(tmp, ignore_errors=True)
            except Exception:
                logger.warning("Failed to clean up temp dir %s", tmp, exc_info=True)

        headers = {
            "X-Tokens-Replaced": str(total_replaced),
            "X-Unresolved-Tokens": ",".join(set(all_unresolved)) if all_unresolved else "",
            "X-Replacements": json.dumps(all_replacements, ensure_ascii=True) if all_replacements else "[]",
            "Access-Control-Expose-Headers": "X-Tokens-Replaced, X-Unresolved-Tokens, X-Replacements",
        }

        return FileResponse(
            str(out_path),
            media_type=media_type,
            filename=out_name,
            headers=headers,
            background=BackgroundTask(_cleanup_single),
        )

    # Multiple files → ZIP
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for out_bytes, out_name in results:
            zf.writestr(out_name, out_bytes)
    zip_buffer.seek(0)

    import tempfile
    tmp = Path(tempfile.mkdtemp(dir=str(config.temp_dir)))
    zip_path = tmp / "detokenized_files.zip"
    zip_path.write_bytes(zip_buffer.getvalue())

    def _cleanup_batch() -> None:
        try:
            shutil.rmtree(tmp, ignore_errors=True)
        except Exception:
            logger.warning("Failed to clean up temp dir %s", tmp, exc_info=True)

    headers = {
        "X-Tokens-Replaced": str(total_replaced),
        "X-Unresolved-Tokens": ",".join(set(all_unresolved)) if all_unresolved else "",
        "X-File-Count": str(len(results)),
        "X-Replacements": json.dumps(all_replacements, ensure_ascii=True) if all_replacements else "[]",
        "Access-Control-Expose-Headers": "X-Tokens-Replaced, X-Unresolved-Tokens, X-File-Count, X-Replacements",
    }

    return FileResponse(
        str(zip_path),
        media_type="application/zip",
        filename="detokenized_files.zip",
        headers=headers,
        background=BackgroundTask(_cleanup_batch),
    )


@router.post("/detokenize/files-to-downloads")
async def detokenize_files_to_downloads(
    files: List[UploadFile] = File(...),
):
    """Batch de-tokenize files and save the result directly to Downloads.

    Same logic as ``/detokenize/files`` but instead of streaming the result
    back it writes the output file to the user's Downloads folder and returns
    a JSON response with the saved path — identical to the export-to-downloads
    pattern so that the Tauri desktop app can simply open the file afterwards.
    """
    from core.vault.store import vault
    from core.detokenize_file import detokenize_file, SUPPORTED_EXTENSIONS
    from api.routers.anonymize import _get_downloads_folder

    vault.ensure_ready()

    if not files:
        raise HTTPException(400, "No files provided.")

    _MAX_FILE_SIZE = 100 * 1024 * 1024
    _MAX_TOTAL_SIZE = 500 * 1024 * 1024

    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []
    seen_tokens: set[str] = set()
    results: list[tuple[bytes, str]] = []

    total_bytes = 0
    for file in files:
        filename = file.filename or "unknown.txt"
        data = await file.read()
        total_bytes += len(data)

        if len(data) > _MAX_FILE_SIZE:
            raise HTTPException(
                413,
                f"File '{filename}' too large ({len(data) // (1024*1024)} MB). Maximum is {_MAX_FILE_SIZE // (1024*1024)} MB.",
            )
        if total_bytes > _MAX_TOTAL_SIZE:
            raise HTTPException(
                413,
                f"Total upload size exceeds {_MAX_TOTAL_SIZE // (1024*1024)} MB limit.",
            )

        try:
            out_bytes, out_name, count, unresolved, repl = await asyncio.to_thread(
                detokenize_file, data, filename, vault,
            )
            results.append((out_bytes, out_name))
            total_replaced += count
            all_unresolved.extend(unresolved)
            for r in repl:
                if r["token"] not in seen_tokens:
                    seen_tokens.add(r["token"])
                    all_replacements.append(r)
        except ValueError as e:
            raise HTTPException(400, f"Error processing '{filename}': {e}")
        except Exception as e:
            logger.error("Batch de-tokenization failed for '%s': %s", filename, e, exc_info=True)
            raise HTTPException(500, f"De-tokenization failed for '{filename}'.")

    _audit("detokenize", entity_count=total_replaced)

    downloads = _get_downloads_folder()
    downloads.mkdir(parents=True, exist_ok=True)

    if len(results) == 1:
        out_bytes, out_name = results[0]
        dest = downloads / Path(out_name).name
    else:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
            for out_bytes_i, out_name_i in results:
                zf.writestr(out_name_i, out_bytes_i)
        out_bytes = buf.getvalue()
        out_name = "detokenized_files.zip"
        dest = downloads / out_name

    # Avoid overwriting
    if dest.exists():
        stem, suffix = dest.stem, dest.suffix
        counter = 1
        while dest.exists():
            dest = downloads / f"{stem} ({counter}){suffix}"
            counter += 1

    dest.write_bytes(out_bytes)
    logger.info("Saved detokenized file to Downloads: %s (%d bytes)", dest, len(out_bytes))

    return {
        "saved_path": str(dest),
        "filename": dest.name,
        "file_count": len(results),
        "total_size": len(out_bytes),
        "tokens_replaced": total_replaced,
        "unresolved_tokens": list(set(all_unresolved)),
        "replacements": all_replacements,
    }
