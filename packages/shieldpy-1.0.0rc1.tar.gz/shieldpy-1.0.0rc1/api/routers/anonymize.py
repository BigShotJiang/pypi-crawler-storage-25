"""Region sync, anonymization, file download, and batch export."""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel as _PydanticBaseModel
from starlette.background import BackgroundTask

from core.config import config
from models.schemas import (
    AnonymizeResponse,
    DocumentStatus,
    RegionSyncItem,
)
from api.deps import documents, get_doc, save_doc, _clamp_bbox, export_progress, cleanup_stale_export_progress
from api.audit_client import log_event as _audit

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["anonymize"])


@router.put("/documents/{doc_id}/regions/sync")
async def sync_regions(doc_id: str, items: list[RegionSyncItem]) -> dict[str, Any]:
    """Bulk-sync region actions and bboxes from the frontend.

    Called right before anonymize to guarantee the backend has the latest
    user edits (moved/resized regions, changed actions) regardless of
    whether individual PUT calls have completed."""
    doc = get_doc(doc_id)
    region_map = {r.id: r for r in doc.regions}
    page_map = {p.page_number: p for p in doc.pages}
    synced = 0
    for item in items:
        r = region_map.get(item.id)
        if r:
            r.action = item.action
            # Clamp synced bbox to page bounds
            pd = page_map.get(r.page_number)
            r.bbox = _clamp_bbox(item.bbox, pd.width, pd.height) if pd else item.bbox
            synced += 1
    save_doc(doc)
    return {"status": "ok", "synced": synced}


@router.post("/documents/{doc_id}/anonymize", response_model=AnonymizeResponse)
async def anonymize(doc_id: str) -> AnonymizeResponse:
    """Apply anonymization to the document based on region actions."""
    doc = get_doc(doc_id)  # 404 before heavy imports
    from core.anonymizer.engine import anonymize_document
    import time as _time
    doc.status = DocumentStatus.ANONYMIZING

    _t0 = _time.perf_counter()
    _file_type = Path(doc.original_filename).suffix.lstrip(".").lower() or None
    try:
        result = await anonymize_document(doc)
        doc.status = DocumentStatus.COMPLETED
        save_doc(doc)
        _audit(
            "anonymize",
            entity_count=result.regions_removed,
            file_type=_file_type,
            duration_ms=int((_time.perf_counter() - _t0) * 1000),
        )
        return result
    except Exception as e:
        import traceback
        logger.error("Anonymization failed:\n%s", traceback.format_exc())
        doc.status = DocumentStatus.ERROR
        save_doc(doc)
        _audit("anonymize", result="error", file_type=_file_type,
               duration_ms=int((_time.perf_counter() - _t0) * 1000))
        raise HTTPException(500, "Anonymization failed. Check server logs for details.")


@router.get("/documents/{doc_id}/download/{file_type}")
async def download_output(doc_id: str, file_type: str) -> FileResponse:
    """Download the anonymized output file (pdf or text)."""
    doc = get_doc(doc_id)
    output_dir = config.temp_dir / doc_id / "output"

    if file_type == "pdf":
        files = list(output_dir.glob("*_anonymized_*.pdf"))
    elif file_type == "text":
        files = list(output_dir.glob("*_anonymized_*.txt"))
    else:
        raise HTTPException(400, "file_type must be 'pdf' or 'text'")

    if not files:
        raise HTTPException(404, "Output file not found. Run anonymization first.")

    latest = max(files, key=lambda f: f.stat().st_mtime)
    # S2: Ensure resolved file is within expected output directory
    if not latest.resolve().is_relative_to(output_dir.resolve()):
        raise HTTPException(403, "Access denied")
    media_type = "application/pdf" if file_type == "pdf" else "text/plain"
    return FileResponse(str(latest), media_type=media_type, filename=latest.name)


class BatchAnonymizeRequest(_PydanticBaseModel):
    doc_ids: list[str]


class BatchAnonymizeResult(_PydanticBaseModel):
    doc_id: str
    success: bool
    error: Optional[str] = None
    tokens_created: int = 0
    regions_removed: int = 0


@router.post("/documents/batch-anonymize")
async def batch_anonymize(req: BatchAnonymizeRequest) -> FileResponse:
    """Anonymize multiple documents. If >1 doc, returns a zip archive."""
    if not req.doc_ids:
        raise HTTPException(400, "No documents selected")
    if len(req.doc_ids) > 50:
        raise HTTPException(400, "Maximum 50 documents per export")

    import asyncio
    import zipfile
    import tempfile
    import time
    from collections import defaultdict
    from core.anonymizer.engine import anonymize_document, GroupTokenCache

    logger.info("Batch export starting for %s documents: %s", len(req.doc_ids), req.doc_ids)
    start_time = time.time()

    output_files: list[tuple[str, Path]] = []
    files_lock = asyncio.Lock()

    # Build per-group token caches so linked docs share tokens.
    # Docs in the same group must be processed sequentially (shared cache).
    group_caches: dict[str, GroupTokenCache] = {}
    group_doc_ids: dict[str, list[str]] = defaultdict(list)   # group_id → [doc_id, …]
    ungrouped_ids: list[str] = []
    for doc_id in req.doc_ids:
        doc = get_doc(doc_id)
        if doc.group_id:
            group_doc_ids[doc.group_id].append(doc_id)
            group_caches.setdefault(doc.group_id, {})
        else:
            ungrouped_ids.append(doc_id)

    # Limit concurrency to avoid overwhelming the system
    semaphore = asyncio.Semaphore(3)

    async def process_one(doc_id: str, cache: GroupTokenCache | None = None) -> BatchAnonymizeResult:
        async with semaphore:
            doc_start = time.time()
            _doc_file_type: str | None = None
            try:
                logger.info("[%s] Starting anonymization...", doc_id)
                doc = get_doc(doc_id)
                _doc_file_type = Path(doc.original_filename).suffix.lstrip(".").lower() or None
                doc.status = DocumentStatus.ANONYMIZING
                result = await anonymize_document(doc, group_token_cache=cache)
                doc.status = DocumentStatus.COMPLETED
                save_doc(doc)
                
                output_dir = config.temp_dir / doc_id / "output"
                pdfs = list(output_dir.glob("*_anonymized_*.pdf"))
                if pdfs:
                    latest = max(pdfs, key=lambda f: f.stat().st_mtime)
                    async with files_lock:
                        output_files.append((latest.name, latest))
                
                elapsed = time.time() - doc_start
                logger.info("[%s] Completed in %.2fs", doc_id, elapsed)
                _audit(
                    "anonymize",
                    entity_count=result.regions_removed,
                    file_type=Path(doc.original_filename).suffix.lstrip(".").lower() or None,
                    duration_ms=int(elapsed * 1000),
                )
                return BatchAnonymizeResult(
                    doc_id=doc_id, success=True,
                    tokens_created=result.tokens_created,
                    regions_removed=result.regions_removed,
                )
            except Exception as e:
                elapsed = time.time() - doc_start
                logger.error("[%s] Failed after %.2fs: %s", doc_id, elapsed, e)
                _audit("anonymize", result="error",
                       file_type=_doc_file_type,
                       duration_ms=int(elapsed * 1000))
                return BatchAnonymizeResult(
                    doc_id=doc_id, success=False, error="Anonymization failed",
                )

    all_results: list[BatchAnonymizeResult] = []

    # Process grouped docs sequentially within each group (shared cache)
    async def process_group(gid: str) -> list[BatchAnonymizeResult]:
        cache = group_caches[gid]
        results: list[BatchAnonymizeResult] = []
        for doc_id in group_doc_ids[gid]:
            results.append(await process_one(doc_id, cache=cache))
        return results

    # Groups run concurrently with each other; ungrouped docs run concurrently
    group_tasks = [process_group(gid) for gid in group_doc_ids]
    ungrouped_tasks = [process_one(d) for d in ungrouped_ids]
    gathered = await asyncio.gather(*group_tasks, *ungrouped_tasks, return_exceptions=True)

    for item in gathered:
        if isinstance(item, list):
            all_results.extend(item)
        elif isinstance(item, BatchAnonymizeResult):
            all_results.append(item)

    results = all_results
    
    total_elapsed = time.time() - start_time
    logger.info("Batch export completed in %.2fs", total_elapsed)

    successful = [r for r in results if r.success]

    if not output_files:
        raise HTTPException(500, "No files were successfully anonymized")

    _audit("export", entity_count=len(successful), duration_ms=int(total_elapsed * 1000))

    # Rename files: {index}_{keyword}.pdf for AI-friendly ordering
    output_files = _rename_output_files(output_files)

    if len(req.doc_ids) == 1 and len(output_files) == 1:
        _, path = output_files[0]
        return FileResponse(str(path), media_type="application/pdf", filename=path.name)

    zip_fd, zip_str = tempfile.mkstemp(suffix=".zip", prefix="promptshield_export_")
    zip_path = Path(zip_str)
    os.close(zip_fd)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for fname, fpath in output_files:
            zf.write(fpath, fname)

    async def _cleanup() -> None:
        zip_path.unlink(missing_ok=True)

    return FileResponse(
        str(zip_path),
        media_type="application/zip",
        filename="promptshield_export.zip",
        background=BackgroundTask(_cleanup),
    )


class ExportSaveResponse(_PydanticBaseModel):
    saved_path: str
    filename: str
    file_count: int
    total_size: int


class ExportToDownloadsRequest(_PydanticBaseModel):
    doc_ids: list[str]
    export_id: Optional[str] = None
    include_ai_prompt: bool = True
    max_files: Optional[int] = None
    max_file_size_mb: Optional[float] = None
    prompt_language: Optional[str] = None  # explicit lang for AI prompt; None / "auto" = detect


@router.get("/documents/export-progress/{export_id}")
async def get_export_progress(export_id: str) -> dict[str, Any]:
    """Return real-time export/anonymization progress."""
    cleanup_stale_export_progress()
    progress = export_progress.get(export_id)
    if progress is None:
        return {
            "export_id": export_id,
            "status": "idle",
            "phase": "idle",
            "docs_done": 0,
            "docs_total": 0,
            "current_doc_name": "",
            "message": "",
            "elapsed_seconds": 0.0,
        }
    import time
    result = {k: v for k, v in progress.items() if not k.startswith("_")}
    result["elapsed_seconds"] = time.time() - progress.get("_started_at", time.time())
    return result


@router.post("/documents/export-to-downloads")
async def export_to_downloads(req: ExportToDownloadsRequest) -> ExportSaveResponse:
    """Anonymize documents and save the result to the user's Downloads folder.

    Returns the full path so the frontend can offer Open File / Open Folder buttons.
    """
    import time

    if not req.doc_ids:
        raise HTTPException(400, "No documents selected")
    if len(req.doc_ids) > 50:
        raise HTTPException(400, "Maximum 50 documents per export")

    tracking_id = req.export_id or f"export-{int(time.time() * 1000)}"

    logger.info("Export-to-downloads starting for %s documents", len(req.doc_ids))
    start_time = time.time()

    try:
        return await _do_export_to_downloads(req, tracking_id, start_time)
    except HTTPException:
        raise
    except Exception as exc:
        import traceback
        logger.error("Export failed with unhandled error:\n%s", traceback.format_exc())
        if tracking_id in export_progress:
            export_progress[tracking_id]["status"] = "error"
            export_progress[tracking_id]["message"] = f"Export failed: {exc}"
        raise HTTPException(500, f"Export failed: {exc}") from exc


async def _do_export_to_downloads(
    req: "ExportToDownloadsRequest",
    tracking_id: str,
    start_time: float,
) -> "ExportSaveResponse":
    """Inner implementation of export_to_downloads — separated for error handling."""
    import asyncio
    import shutil
    import zipfile
    import time
    from collections import defaultdict
    from core.anonymizer.engine import anonymize_document, GroupTokenCache

    # Initialize progress tracking
    doc_names = {}
    for doc_id in req.doc_ids:
        try:
            doc_names[doc_id] = get_doc(doc_id).original_filename
        except Exception:
            logger.debug("Could not resolve filename for doc %s", doc_id)
            doc_names[doc_id] = doc_id

    export_progress[tracking_id] = {
        "export_id": tracking_id,
        "status": "processing",
        "phase": "anonymizing",
        "docs_done": 0,
        "docs_total": len(req.doc_ids),
        "docs_failed": 0,
        "current_doc_name": "",
        "message": f"Anonymizing {len(req.doc_ids)} document(s)…",
        "doc_statuses": [
            {"doc_id": d, "name": doc_names[d], "status": "pending"} for d in req.doc_ids
        ],
        "elapsed_seconds": 0.0,
        "_started_at": start_time,
    }

    output_files: list[tuple[str, Path]] = []
    files_lock = asyncio.Lock()
    docs_done = 0
    docs_failed = 0
    semaphore = asyncio.Semaphore(3)

    # Build per-group token caches so linked docs share tokens
    group_caches: dict[str, GroupTokenCache] = {}
    group_doc_ids: dict[str, list[str]] = defaultdict(list)
    ungrouped_ids: list[str] = []
    for doc_id in req.doc_ids:
        try:
            doc_obj = get_doc(doc_id)
            if doc_obj.group_id:
                group_doc_ids[doc_obj.group_id].append(doc_id)
                group_caches.setdefault(doc_obj.group_id, {})
            else:
                ungrouped_ids.append(doc_id)
        except Exception:
            logger.debug("Could not resolve group for doc %s, treating as ungrouped", doc_id)
            ungrouped_ids.append(doc_id)

    async def process_one(doc_id: str, cache: GroupTokenCache | None = None) -> None:
        nonlocal docs_done, docs_failed
        async with semaphore:
            try:
                # Update progress — mark as running
                if tracking_id in export_progress:
                    for ds in export_progress[tracking_id].get("doc_statuses", []):
                        if ds["doc_id"] == doc_id:
                            ds["status"] = "running"
                    export_progress[tracking_id]["current_doc_name"] = doc_names.get(doc_id, doc_id)
                    export_progress[tracking_id]["message"] = f"Anonymizing {doc_names.get(doc_id, doc_id)}…"

                doc = get_doc(doc_id)
                doc.status = DocumentStatus.ANONYMIZING
                await anonymize_document(doc, group_token_cache=cache)
                doc.status = DocumentStatus.COMPLETED
                save_doc(doc)

                output_dir = config.temp_dir / doc_id / "output"
                pdfs = list(output_dir.glob("*_anonymized_*.pdf"))
                if pdfs:
                    latest = max(pdfs, key=lambda f: f.stat().st_mtime)
                    async with files_lock:
                        output_files.append((latest.name, latest))

                # Update progress — mark as done
                docs_done += 1
                if tracking_id in export_progress:
                    for ds in export_progress[tracking_id].get("doc_statuses", []):
                        if ds["doc_id"] == doc_id:
                            ds["status"] = "done"
                    export_progress[tracking_id]["docs_done"] = docs_done
                    export_progress[tracking_id]["message"] = f"Anonymized {docs_done}/{len(req.doc_ids)} document(s)"
            except Exception as e:
                logger.error("[%s] Export failed: %s", doc_id, e)
                docs_failed += 1
                if tracking_id in export_progress:
                    for ds in export_progress[tracking_id].get("doc_statuses", []):
                        if ds["doc_id"] == doc_id:
                            ds["status"] = "error"
                            ds["error"] = str(e)
                    export_progress[tracking_id]["docs_done"] = docs_done
                    export_progress[tracking_id]["docs_failed"] = docs_failed

    # Process grouped documents sequentially within each group (shared cache),
    # groups run concurrently with each other and with ungrouped docs.
    async def process_group(gid: str) -> None:
        cache = group_caches[gid]
        for doc_id in group_doc_ids[gid]:
            await process_one(doc_id, cache=cache)

    group_tasks = [process_group(gid) for gid in group_doc_ids]
    ungrouped_tasks = [process_one(d) for d in ungrouped_ids]
    await asyncio.gather(*group_tasks, *ungrouped_tasks)

    if not output_files:
        if tracking_id in export_progress:
            export_progress[tracking_id]["status"] = "error"
            export_progress[tracking_id]["message"] = "No files were successfully anonymized"
        raise HTTPException(500, "No files were successfully anonymized")

    # Rename files: {index}_{keyword}.pdf for AI-friendly ordering
    output_files = _rename_output_files(output_files)

    # Update progress — saving phase
    if tracking_id in export_progress:
        export_progress[tracking_id]["phase"] = "saving"
        export_progress[tracking_id]["message"] = "Saving to Downloads folder…"

    # ── Merge / split to match AI ingestion constraints ──
    max_files = req.max_files
    max_size_bytes = int(req.max_file_size_mb * 1024 * 1024) if req.max_file_size_mb else None
    if max_files or max_size_bytes:
        if tracking_id in export_progress:
            export_progress[tracking_id]["phase"] = "chunking"
            export_progress[tracking_id]["message"] = "Adjusting files for AI ingestion limits…"
        output_files = _chunk_output_files(
            output_files,
            max_files=max_files,
            max_size_bytes=max_size_bytes,
        )

    # ── Generate AI prompt text and prepend to each PDF if requested ──
    # Done AFTER merge/split so every final file gets exactly one prompt page.
    if req.include_ai_prompt:
        try:
            from core.vault.store import vault
            from models.schemas import RegionAction
            vault.ensure_ready()
            source_filenames: set[str] = set()
            seen_groups: set[str] = set()
            has_dismissed = False
            for doc_id in req.doc_ids:
                try:
                    d = get_doc(doc_id)
                    source_filenames.add(d.original_filename)
                    if not has_dismissed and any(
                        r.action == RegionAction.CANCEL for r in d.regions
                    ):
                        has_dismissed = True
                    if d.group_id and d.group_id not in seen_groups:
                        seen_groups.add(d.group_id)
                        from api.deps import documents as doc_dict
                        for other in doc_dict.values():
                            if other.group_id == d.group_id:
                                source_filenames.add(other.original_filename)
                except Exception:
                    logger.debug("Skipping doc %s for AI prompt source filenames", doc_id)
            prefixes = vault.get_used_prefixes(
                source_documents=list(source_filenames) if source_filenames else None,
            )
            if prefixes:
                from api.routers.vault import _build_ai_prompt, _PROMPT_I18N
                # Use explicit language override, or auto-detect from document text
                if req.prompt_language and req.prompt_language != "auto":
                    doc_lang = req.prompt_language
                else:
                    from core.detection.language import detect_language
                    doc_lang = "en"
                    for doc_id in req.doc_ids:
                        try:
                            d = get_doc(doc_id)
                            if d.pages:
                                all_text = " ".join(
                                    p.full_text for p in d.pages if p.full_text
                                )
                                if all_text:
                                    doc_lang = detect_language(all_text)
                                    break
                        except Exception:
                            logger.debug("Language detection failed for doc %s", doc_id)
                ai_prompt_text = _build_ai_prompt(prefixes, locale=doc_lang, has_dismissed=has_dismissed)
                if ai_prompt_text:
                    i18n = _PROMPT_I18N.get(doc_lang, _PROMPT_I18N["en"])
                    _prepend_ai_prompt_page(output_files, ai_prompt_text, title=i18n["title"])
            else:
                logger.info("AI prompt: no prefixes found — skipping prepend")
        except Exception as exc:
            logger.warning("Failed to prepend AI prompt to export: %s", exc, exc_info=True)

    # Determine Downloads folder
    downloads_dir = _get_downloads_folder()
    downloads_dir.mkdir(parents=True, exist_ok=True)

    if len(output_files) == 1:
        # Single file → copy PDF directly
        _, src_path = output_files[0]
        dest_name = src_path.name
        dest = downloads_dir / dest_name
        # Avoid overwriting — append (1), (2), etc.
        counter = 1
        while dest.exists():
            stem = src_path.stem
            dest = downloads_dir / f"{stem} ({counter}).pdf"
            counter += 1
        shutil.copy2(str(src_path), str(dest))
        total_size = dest.stat().st_size
    else:
        # Multiple files → zip
        dest = downloads_dir / "promptshield_export.zip"
        counter = 1
        while dest.exists():
            dest = downloads_dir / f"promptshield_export ({counter}).zip"
            counter += 1
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
            for fname, fpath in output_files:
                zf.write(fpath, fname)
        total_size = dest.stat().st_size

    _audit("export", entity_count=len(output_files), duration_ms=int((time.time() - start_time) * 1000))

    elapsed = time.time() - start_time
    logger.info("Export saved to %s in %.2fs (%s bytes)", dest, elapsed, total_size)

    # Mark export progress as complete
    if tracking_id in export_progress:
        export_progress[tracking_id]["status"] = "complete"
        export_progress[tracking_id]["phase"] = "complete"
        export_progress[tracking_id]["message"] = f"Saved to {dest.name}"

    return ExportSaveResponse(
        saved_path=str(dest),
        filename=dest.name,
        file_count=len(output_files),
        total_size=total_size,
    )


def _chunk_output_files(
    output_files: list[tuple[str, Path]],
    max_files: int | None = None,
    max_size_bytes: int | None = None,
) -> list[tuple[str, Path]]:
    """Merge or split PDFs so the result respects *max_files* and *max_size_bytes*.

    Strategy:
    1. **Split** any file that exceeds *max_size_bytes* into smaller PDFs.
    2. **Merge** files together if the total count exceeds *max_files*,
       combining the smallest files first while staying under *max_size_bytes*.

    Each resulting file keeps the original page structure — we never rasterize
    or re-encode.  File names indicate processing order for AI.
    """
    import fitz  # PyMuPDF
    import tempfile

    working: list[tuple[str, Path]] = list(output_files)

    # ---- Phase 1: split oversized files ----
    if max_size_bytes:
        split_result: list[tuple[str, Path]] = []
        for fname, fpath in working:
            if fpath.stat().st_size <= max_size_bytes:
                split_result.append((fname, fpath))
                continue
            # Split this PDF by pages until each part is under the limit
            try:
                src = fitz.open(str(fpath))
                total_pages = len(src)
                if total_pages <= 1:
                    split_result.append((fname, fpath))
                    src.close()
                    continue

                stem = fpath.stem
                part_dir = fpath.parent
                part_idx = 0
                page_start = 0

                while page_start < total_pages:
                    part_idx += 1
                    # Binary-search for how many pages fit in the budget
                    lo, hi = page_start, total_pages - 1
                    best = page_start  # at least one page
                    while lo <= hi:
                        mid = (lo + hi) // 2
                        trial = fitz.open()  # empty doc
                        trial.insert_pdf(src, from_page=page_start, to_page=mid)
                        tmp_fd, tmp_path = tempfile.mkstemp(suffix=".pdf", dir=str(part_dir))
                        os.close(tmp_fd)
                        trial.save(tmp_path, deflate=True, garbage=3)
                        trial.close()
                        sz = Path(tmp_path).stat().st_size
                        if sz <= max_size_bytes:
                            best = mid
                            lo = mid + 1
                        else:
                            hi = mid - 1
                        Path(tmp_path).unlink(missing_ok=True)
                    # Write the actual part
                    part_doc = fitz.open()
                    part_doc.insert_pdf(src, from_page=page_start, to_page=best)
                    part_name = f"{stem}_part{part_idx:02d}.pdf"
                    part_path = part_dir / part_name
                    part_doc.save(str(part_path), deflate=True, garbage=3)
                    part_doc.close()
                    split_result.append((part_name, part_path))
                    page_start = best + 1

                src.close()
            except Exception as exc:
                logger.warning("Split failed for %s: %s", fname, exc)
                split_result.append((fname, fpath))
        working = split_result

    # ---- Phase 2: merge if too many files ----
    if max_files and len(working) > max_files:
        # Sort by file size ascending so we merge small files first
        sized = [(fname, fpath, fpath.stat().st_size) for fname, fpath in working]
        sized.sort(key=lambda t: t[2])

        buckets: list[list[tuple[str, Path, int]]] = []
        bucket_sizes: list[int] = []

        for fname, fpath, sz in sized:
            placed = False
            # Try to fit into the smallest existing bucket
            for i in range(len(buckets)):
                if max_size_bytes and bucket_sizes[i] + sz > max_size_bytes:
                    continue
                buckets[i].append((fname, fpath, sz))
                bucket_sizes[i] += sz
                placed = True
                break
            if not placed:
                buckets.append([(fname, fpath, sz)])
                bucket_sizes.append(sz)

        # If we still have too many buckets, force-merge the smallest
        while len(buckets) > max_files:
            buckets.sort(key=lambda b: sum(s for _, _, s in b))
            smallest = buckets.pop(0)
            # Merge into the next-smallest bucket
            buckets[0].extend(smallest)
            bucket_sizes = [sum(s for _, _, s in b) for b in buckets]

        # Now write merged PDFs
        merged: list[tuple[str, Path]] = []
        for idx, bucket in enumerate(buckets, 1):
            if len(bucket) == 1:
                merged.append((bucket[0][0], bucket[0][1]))
                continue
            try:
                combined = fitz.open()
                for _, fpath, _ in bucket:
                    src = fitz.open(str(fpath))
                    combined.insert_pdf(src)
                    src.close()
                merged_name = f"promptshield_merged_{idx:02d}.pdf"
                merged_path = bucket[0][1].parent / merged_name
                combined.save(str(merged_path), deflate=True, garbage=3)
                combined.close()
                merged.append((merged_name, merged_path))
            except Exception as exc:
                logger.warning("Merge failed for bucket %s: %s", idx, exc)
                for fname, fpath, _ in bucket:
                    merged.append((fname, fpath))
        working = merged

    return working


def _prepend_ai_prompt_page(
    output_files: list[tuple[str, Path]],
    prompt_text: str,
    title: str = "PromptShield - AI Instructions",
) -> None:
    """Insert a styled AI-instructions page at the beginning of each PDF.

    Uses PyMuPDF (fitz) which is already a project dependency.  The page
    matches the first page's dimensions and uses a clean monospace layout
    so the prompt is easy to read for both humans and AI parsers.
    """
    import fitz  # PyMuPDF

    for _fname, pdf_path in output_files:
        try:
            doc = fitz.open(str(pdf_path))

            # Match the dimensions of page 1 (or default to A4)
            if len(doc) > 0:
                ref = doc[0].rect
                width, height = ref.width, ref.height
            else:
                width, height = 595.28, 841.89  # A4 in points

            # Create a new single-page PDF for the instructions
            prompt_doc = fitz.open()
            page = prompt_doc.new_page(width=width, height=height)

            margin = 50
            usable_w = width - 2 * margin

            # ── Title ──
            title_rect = fitz.Rect(margin, margin, margin + usable_w, margin + 30)
            page.insert_textbox(
                title_rect,
                title,
                fontname="helv",
                fontsize=14,
                color=(0.25, 0.25, 0.25),
            )

            # ── Separator line ──
            y_sep = margin + 36
            page.draw_line(
                fitz.Point(margin, y_sep),
                fitz.Point(margin + usable_w, y_sep),
                color=(0.75, 0.75, 0.75),
                width=0.5,
            )

            # ── Body text ──
            body_top = y_sep + 14
            body_rect = fitz.Rect(margin, body_top, margin + usable_w, height - margin)
            page.insert_textbox(
                body_rect,
                prompt_text,
                fontname="cour",
                fontsize=9,
                color=(0.2, 0.2, 0.2),
            )

            # Insert the instructions page at position 0 of the original doc
            doc.insert_pdf(prompt_doc, from_page=0, to_page=0, start_at=0)
            prompt_doc.close()

            # PyMuPDF forbids non-incremental save to the same path, so we
            # write to a temp file first and then replace the original.
            import tempfile
            tmp_fd, tmp_path = tempfile.mkstemp(suffix=".pdf", dir=str(pdf_path.parent))
            os.close(tmp_fd)
            doc.save(tmp_path, incremental=False, deflate=True, garbage=3)
            doc.close()
            Path(tmp_path).replace(pdf_path)
        except Exception as exc:
            logger.warning("Could not prepend AI prompt to %s: %s", pdf_path.name, exc)


# ---------------------------------------------------------------------------
# Keyword extraction & file renaming for AI-friendly export names
# ---------------------------------------------------------------------------

# Vault token patterns — must match store.py resolve_all_tokens()
_TOKEN_PATTERN = re.compile(
    r"\[[A-Z][A-Z0-9]{5,}\]"
    r"|\[ANON_[A-Z_]+_[A-F0-9]{6,12}\]"
)

# Common stopwords to skip when picking a keyword
_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
    "of", "with", "by", "from", "as", "is", "was", "are", "were", "be",
    "been", "being", "have", "has", "had", "do", "does", "did", "will",
    "would", "could", "should", "may", "might", "shall", "can", "need",
    "it", "its", "this", "that", "these", "those", "i", "we", "you", "he",
    "she", "they", "me", "him", "her", "us", "them", "my", "our", "your",
    "his", "their", "not", "no", "nor", "so", "if", "then", "than",
    "too", "very", "just", "about", "also", "more", "other", "some",
    "such", "only", "over", "after", "each", "all", "any", "both",
    "into", "out", "up", "down", "own", "same", "de", "le", "la", "les",
    "des", "du", "un", "une", "et", "en", "est", "que", "qui", "dans",
    "pour", "sur", "avec", "par", "au", "aux", "son", "sa", "ses",
    "die", "der", "das", "den", "dem", "ein", "eine", "und", "ist",
    "von", "zu", "mit", "auf", "fur", "nicht", "sich", "werden",
    "page", "date", "file", "document", "pdf", "anonymized",
})


def _extract_keyword_from_pdf(pdf_path: Path) -> str:
    """Extract a single representative keyword from *pdf_path*.

    The keyword is the most-frequent non-token, non-stopword word in the
    document (>=4 chars, pure alphabetic).  Falls back to ``"doc"`` if
    nothing suitable is found.
    """
    import fitz  # PyMuPDF
    from collections import Counter

    try:
        doc = fitz.open(str(pdf_path))
        text_parts: list[str] = []
        for page in doc:
            text_parts.append(page.get_text())
        doc.close()
        full_text = " ".join(text_parts)
    except Exception as exc:
        logger.debug("Could not extract text from %s: %s", pdf_path.name, exc)
        return "doc"

    # Remove vault tokens from the text so they don't pollute word counts
    clean_text = _TOKEN_PATTERN.sub(" ", full_text)

    # Tokenize into words
    words = re.findall(r"[A-Za-z]{4,}", clean_text)

    # Count frequencies, ignoring stopwords
    freq: Counter[str] = Counter()
    for w in words:
        low = w.lower()
        if low not in _STOPWORDS:
            freq[low] += 1

    if not freq:
        return "doc"

    # Pick the most frequent word; on ties, prefer shorter words
    best = max(freq, key=lambda w: (freq[w], -len(w)))
    # Capitalise for readability in filenames
    return best.capitalize()


def _rename_output_files(
    output_files: list[tuple[str, Path]],
) -> list[tuple[str, Path]]:
    """Rename each output file to ``{index:02d}_{keyword}.pdf``.

    *index* preserves the original document order so that an AI consuming
    the files processes them in the correct sequence.  *keyword* is the
    most representative non-PII word in the document.
    """
    renamed: list[tuple[str, Path]] = []
    used_names: set[str] = set()

    for idx, (fname, fpath) in enumerate(output_files, start=1):
        keyword = _extract_keyword_from_pdf(fpath)
        new_name = f"{idx:02d}_{keyword}.pdf"

        # Ensure uniqueness — append a suffix if needed
        if new_name in used_names:
            suffix = 2
            while f"{idx:02d}_{keyword}_{suffix}.pdf" in used_names:
                suffix += 1
            new_name = f"{idx:02d}_{keyword}_{suffix}.pdf"
        used_names.add(new_name)

        new_path = fpath.parent / new_name
        try:
            fpath.rename(new_path)
        except Exception as exc:
            logger.warning("Could not rename %s -> %s: %s", fpath.name, new_name, exc)
            renamed.append((fname, fpath))  # keep original on failure
            continue
        renamed.append((new_name, new_path))

    return renamed


def _get_downloads_folder() -> Path:
    """Return the user's Downloads folder (cross-platform)."""
    import platform as _platform
    system = _platform.system()
    if system == "Windows":
        try:
            import ctypes
            from ctypes import wintypes

            class _GUID(ctypes.Structure):
                _fields_ = [
                    ("Data1", wintypes.DWORD),
                    ("Data2", wintypes.WORD),
                    ("Data3", wintypes.WORD),
                    ("Data4", ctypes.c_byte * 8),
                ]

            _SHGetKnownFolderPath = ctypes.windll.shell32.SHGetKnownFolderPath  # type: ignore[attr-defined]
            _SHGetKnownFolderPath.argtypes = [
                ctypes.POINTER(_GUID), wintypes.DWORD, wintypes.HANDLE,
                ctypes.POINTER(ctypes.c_wchar_p),
            ]
            _SHGetKnownFolderPath.restype = ctypes.HRESULT

            # FOLDERID_Downloads = {374DE290-123F-4565-9164-39C4925E467B}
            guid = _GUID()
            guid.Data1 = 0x374DE290
            guid.Data2 = 0x123F
            guid.Data3 = 0x4565
            guid.Data4 = (ctypes.c_byte * 8)(
                0x91, 0x64, 0x39, 0xC4, 0x92, 0x5E, 0x46, 0x7B  # noqa: E501
            )

            buf = ctypes.c_wchar_p()
            hr = _SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(buf))
            if hr == 0 and buf.value:
                result = Path(buf.value)
                ctypes.windll.ole32.CoTaskMemFree(buf)  # type: ignore[attr-defined]
                return result
        except Exception:
            logger.debug("SHGetKnownFolderPath failed, falling back to ~/Downloads")
    # Fallback: ~/Downloads
    return Path.home() / "Downloads"
