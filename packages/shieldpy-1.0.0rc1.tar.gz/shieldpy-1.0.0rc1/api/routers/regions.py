﻿"""PII region CRUD, batch operations, highlight-all, and reanalysis.

Architecture
~~~~~~~~~~~~
This file is the **composition root** for region routes.  Complex logic
lives in private sub-modules:

* ``_regions_helpers.py``   — normalisation, fuzzy matching, reading-order
* ``_regions_highlight.py`` — highlight-all (grouped + ungrouped)
* ``_regions_blacklist.py`` — batch blacklist application

Re-exports at the bottom guarantee backward-compatible imports.  Route
handlers here are thin wrappers that delegate to sub-module ``_*_impl``
functions.

Deduplication
~~~~~~~~~~~~~
Manual-draw dedup uses inline bbox intersection (x/y overlap test) —
purpose-specific and intentionally separate from the visual nudging in
``engine._resolve_overlapping_bboxes`` and the char-span checks in
``propagation._PageIntervals``.  Highlight-all and blacklist have their
own ``existing_spans`` dedup sets in the sub-modules (see their
docstrings).
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from typing import Any, Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel as _PydanticBaseModel

from models.schemas import (
    BatchActionRequest,
    BBox,
    DetectionSource,
    GroupRegionsRequest,
    MergeRegionsRequest,
    PIIRegion,
    RegionAction,
    RegionActionRequest,
)
from api.deps import get_doc, save_doc, _clamp_bbox

# â”€â”€ Re-export sub-module symbols for backward compatibility â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
from api.routers._regions_helpers import (                     # noqa: F401
    _CHAR_OVERLAP_MIN_RATIO,
    _FUZZY_THRESHOLD,
    _OVERLAP_COVERAGE_THRESHOLD,
    _extract_individual_text,
    _fuzzy_ratio,
    _normalize,
    _sort_by_reading_order,
)
from api.routers._regions_highlight import (                   # noqa: F401
    _highlight_all_grouped,
    _highlight_all_impl,
    _highlight_all_ungrouped,
)
from api.routers._regions_blacklist import (                   # noqa: F401
    BlacklistRequest,
    _blacklist_impl,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["regions"])


# ---------------------------------------------------------------------------
# Debug
# ---------------------------------------------------------------------------

@router.get("/documents/{doc_id}/debug-detections")
async def debug_detections(doc_id: str, page_number: Optional[int] = None) -> dict[str, Any]:
    """Debug endpoint â€” shows every detection with type, confidence, source, text."""
    doc = get_doc(doc_id)
    regions = doc.regions
    if page_number is not None:
        regions = [r for r in regions if r.page_number == page_number]
    summary = []
    for r in regions:
        summary.append({
            "page": r.page_number,
            "type": r.pii_type.value if hasattr(r.pii_type, "value") else str(r.pii_type),
            "confidence": round(r.confidence, 3),
            "source": r.source.value if hasattr(r.source, "value") else str(r.source),
            "text": r.text[:80],
        })
    summary.sort(key=lambda x: (-x["confidence"], x["type"]))
    return {"total": len(summary), "regions": summary}


@router.get("/documents/{doc_id}/debug-page-text/{page_number}")
async def debug_page_text(doc_id: str, page_number: int) -> dict[str, Any]:
    """Debug endpoint â€” shows the extracted full_text for a page."""
    doc = get_doc(doc_id)
    if page_number < 1 or page_number > doc.page_count:
        raise HTTPException(400, f"Invalid page {page_number}")
    page = doc.pages[page_number - 1]
    return {
        "page_number": page_number,
        "full_text": page.full_text,
        "text_blocks_count": len(page.text_blocks),
        "text_block_samples": [
            {"text": b.text, "bbox": [b.bbox.x0, b.bbox.y0, b.bbox.x1, b.bbox.y1]}
            for b in page.text_blocks[-20:]  # last 20 blocks (likely footer)
        ],
    }


# ---------------------------------------------------------------------------
# Single-region mutations
# ---------------------------------------------------------------------------

@router.put("/documents/{doc_id}/regions/{region_id}/action")
async def set_region_action(doc_id: str, region_id: str, req: RegionActionRequest) -> dict[str, str]:
    """Set the action for a specific PII region (and linked siblings).
    
    If the action is CANCEL, the region (and linked siblings) are fully
    removed from the document rather than being hidden.
    """
    doc = get_doc(doc_id)
    target = next((r for r in doc.regions if r.id == region_id), None)
    if target is None:
        raise HTTPException(404, f"Region '{region_id}' not found")

    if req.action == RegionAction.CANCEL:
        # True deletion â€” remove region and linked siblings
        grp = target.linked_group
        if grp:
            doc.regions = [r for r in doc.regions if r.linked_group != grp]
        else:
            doc.regions = [r for r in doc.regions if r.id != region_id]
    else:
        target.action = req.action
        # Propagate to linked siblings
        if target.linked_group:
            for region in doc.regions:
                if region.linked_group == target.linked_group:
                    region.action = req.action
    save_doc(doc)
    return {"status": "ok", "region_id": region_id, "action": req.action.value}


@router.delete("/documents/{doc_id}/regions/{region_id}")
async def delete_region(doc_id: str, region_id: str) -> dict[str, str]:
    """Delete a PII region (and linked siblings) from the document."""
    doc = get_doc(doc_id)
    # Find linked_group before deletion
    target = next((r for r in doc.regions if r.id == region_id), None)
    if target is None:
        raise HTTPException(404, f"Region '{region_id}' not found")
    grp = target.linked_group
    if grp:
        doc.regions = [r for r in doc.regions if r.linked_group != grp]
    else:
        doc.regions = [r for r in doc.regions if r.id != region_id]
    save_doc(doc)
    return {"status": "ok", "region_id": region_id}


@router.put("/documents/{doc_id}/regions/{region_id}/bbox")
async def update_region_bbox(doc_id: str, region_id: str, bbox: BBox) -> dict[str, str]:
    """Update the bounding box of a PII region (move / resize)."""
    doc = get_doc(doc_id)
    # Find the page dimensions for clamping
    page_map = {p.page_number: p for p in doc.pages}
    for region in doc.regions:
        if region.id == region_id:
            pd = page_map.get(region.page_number)
            if pd is not None:
                bbox = _clamp_bbox(bbox, pd.width, pd.height)
            region.bbox = bbox
            save_doc(doc)
            return {"status": "ok", "region_id": region_id}
    raise HTTPException(404, f"Region '{region_id}' not found")


class UpdateLabelRequest(_PydanticBaseModel):
    pii_type: str


@router.put("/documents/{doc_id}/regions/{region_id}/label")
async def update_region_label(doc_id: str, region_id: str, req: UpdateLabelRequest) -> dict[str, Any]:
    """Update the PII type label of a region and all same-text siblings."""
    doc = get_doc(doc_id)
    target = None
    for region in doc.regions:
        if region.id == region_id:
            target = region
            break
    if target is None:
        raise HTTPException(404, f"Region '{region_id}' not found")

    old_text = target.text.strip().lower()
    target.pii_type = req.pii_type
    updated: list[dict[str, str]] = [{"id": region_id, "pii_type": req.pii_type.value if hasattr(req.pii_type, 'value') else str(req.pii_type)}]

    # Propagate to all regions with the same text
    if old_text:
        for region in doc.regions:
            if region.id != region_id and region.text.strip().lower() == old_text:
                region.pii_type = req.pii_type
                updated.append({"id": region.id, "pii_type": updated[0]["pii_type"]})

    save_doc(doc)
    return {"status": "ok", "updated": updated}


class UpdateTextRequest(_PydanticBaseModel):
    text: str


@router.put("/documents/{doc_id}/regions/{region_id}/text")
async def update_region_text(
    doc_id: str,
    region_id: str,
    req: UpdateTextRequest,
    propagate: bool = True,
) -> dict[str, Any]:
    """Update the detected text content of a region and optionally all same-text siblings."""
    doc = get_doc(doc_id)
    target = None
    for region in doc.regions:
        if region.id == region_id:
            target = region
            break
    if target is None:
        raise HTTPException(404, f"Region '{region_id}' not found")

    old_text = target.text.strip().lower()
    # Preserve the original document text so export can find it for replacement
    if target.original_text is None:
        target.original_text = target.text
    target.text = req.text
    updated: list[dict] = [{"id": region_id, "text": req.text, "original_text": target.original_text}]

    # Propagate to all regions with the same text (unless caller opted out)
    if propagate and old_text:
        for region in doc.regions:
            if region.id != region_id and region.text.strip().lower() == old_text:
                if region.original_text is None:
                    region.original_text = region.text
                region.text = req.text
                updated.append({"id": region.id, "text": req.text, "original_text": region.original_text})

    save_doc(doc)
    return {"status": "ok", "updated": updated}


@router.post("/documents/{doc_id}/regions/{region_id}/reanalyze")
async def reanalyze_region(doc_id: str, region_id: str) -> dict[str, Any]:
    """Re-analyze the content under a region's bounding box."""
    from core.detection.pipeline import reanalyze_bbox
    from core.llm.engine import llm_engine

    doc = get_doc(doc_id)
    region = None
    for r in doc.regions:
        if r.id == region_id:
            region = r
            break
    if region is None:
        raise HTTPException(404, f"Region '{region_id}' not found")

    page_data = None
    for p in doc.pages:
        if p.page_number == region.page_number:
            page_data = p
            break
    if page_data is None:
        raise HTTPException(400, f"Page {region.page_number} data not available")

    engine = llm_engine if llm_engine.is_loaded() else None
    # H5: reanalyze_bbox is CPU-bound; run in a thread to avoid blocking the event loop
    try:
        result = await asyncio.to_thread(reanalyze_bbox, page_data, region.bbox, llm_engine=engine)
    except Exception as e:
        logger.exception("reanalyze_bbox failed for region %s", region_id)
        raise HTTPException(500, f"Reanalysis failed: {e}")

    region.text = result["text"] or region.text
    # Text was re-read from the document, so it matches the file again
    region.original_text = None
    if result["confidence"] > 0:
        region.pii_type = result["pii_type"]
        region.confidence = result["confidence"]
        region.source = result["source"]

    # If this region is part of a linked group, re-extract and concatenate
    # text from ALL sibling bboxes (reading order), then sync to all siblings.
    if region.linked_group:
        siblings = [r for r in doc.regions if r.linked_group == region.linked_group]
        if len(siblings) > 1:
            from core.ingestion.loader import _cluster_into_lines
            page_map = {p.page_number: p for p in doc.pages}
            # Collect text blocks under each sibling's bbox
            all_matched = []
            for sib in siblings:
                pd = page_map.get(sib.page_number)
                if pd is None:
                    continue
                sx0, sy0, sx1, sy1 = sib.bbox.x0, sib.bbox.y0, sib.bbox.x1, sib.bbox.y1
                for block in pd.text_blocks:
                    bb = block.bbox
                    cx = (bb.x0 + bb.x1) / 2
                    cy = (bb.y0 + bb.y1) / 2
                    if sx0 <= cx <= sx1 and sy0 <= cy <= sy1:
                        all_matched.append(block)
            if all_matched:
                lines = _cluster_into_lines(all_matched)
                group_text = " ".join(
                    b.text.strip() for line in lines for b in line if b.text.strip()
                )
            else:
                group_text = region.text
            for sib in siblings:
                sib.text = group_text
                sib.original_text = None  # re-read from document
                sib.pii_type = region.pii_type
                sib.confidence = region.confidence
                sib.source = region.source

    save_doc(doc)

    # Include sibling IDs so the frontend can sync grouped regions
    sibling_ids: list[str] = []
    if region.linked_group:
        sibling_ids = [r.id for r in doc.regions if r.linked_group == region.linked_group and r.id != region_id]

    return {
        "region_id": region_id,
        "text": region.text,
        "pii_type": region.pii_type if isinstance(region.pii_type, str) else region.pii_type.value,
        "confidence": float(region.confidence),
        "source": region.source if isinstance(region.source, str) else region.source.value,
        "sibling_ids": sibling_ids,
    }


# ---------------------------------------------------------------------------
# Batch operations
# ---------------------------------------------------------------------------

@router.put("/documents/{doc_id}/regions/batch-action")
async def batch_region_action(doc_id: str, req: BatchActionRequest) -> dict[str, Any]:
    """Apply an action to multiple regions at once.
    
    If the action is CANCEL, the regions are fully removed rather than hidden.
    """
    doc = get_doc(doc_id)
    if req.action == RegionAction.CANCEL:
        ids_to_delete = set(req.region_ids)
        original_len = len(doc.regions)
        doc.regions = [r for r in doc.regions if r.id not in ids_to_delete]
        save_doc(doc)
        return {"status": "ok", "updated": original_len - len(doc.regions)}
    region_map = {r.id: r for r in doc.regions}
    updated = 0
    for rid in req.region_ids:
        if rid in region_map:
            region_map[rid].action = req.action
            updated += 1
    save_doc(doc)
    return {"status": "ok", "updated": updated}


@router.put("/documents/{doc_id}/regions/replace")
async def replace_all_regions(doc_id: str, items: list[PIIRegion]) -> dict[str, Any]:
    """Replace the entire region list for a document (used by undo/redo).

    Preserves ``original_text`` from the server-side state when the
    frontend payload is missing it (the frontend may not track it).
    """
    doc = get_doc(doc_id)
    # Build a map of existing original_text values so undo/redo doesn't
    # wipe them when the frontend doesn't carry the field.
    existing_original: dict[str, str | None] = {
        r.id: r.original_text for r in doc.regions if r.original_text
    }
    for item in items:
        if item.original_text is None and item.id in existing_original:
            item.original_text = existing_original[item.id]
    doc.regions = items
    save_doc(doc)
    return {"status": "ok", "count": len(items)}


@router.post("/documents/{doc_id}/regions/batch-delete")
async def batch_delete_regions(doc_id: str, req: BatchActionRequest) -> dict[str, Any]:
    """Delete multiple regions at once."""
    doc = get_doc(doc_id)
    ids_to_delete = set(req.region_ids)
    original_len = len(doc.regions)
    doc.regions = [r for r in doc.regions if r.id not in ids_to_delete]
    deleted = original_len - len(doc.regions)
    save_doc(doc)
    return {"status": "ok", "deleted": deleted}


@router.post("/documents/{doc_id}/regions/merge")
async def merge_regions(doc_id: str, req: MergeRegionsRequest) -> dict[str, Any]:
    """Merge two or more regions into a single region.

    The merged region gets the union bounding box, concatenated text
    (sorted top-to-bottom then left-to-right), and keeps the PII type
    and action of the first region.  All source regions are removed.
    """
    if len(req.region_ids) < 2:
        raise HTTPException(status_code=400, detail="At least 2 regions required to merge")

    doc = get_doc(doc_id)
    ids = set(req.region_ids)
    targets = [r for r in doc.regions if r.id in ids]

    if len(targets) < 2:
        raise HTTPException(status_code=404, detail="Could not find enough matching regions")

    pages = {r.page_number for r in targets}
    if len(pages) > 1:
        raise HTTPException(status_code=400, detail="Can only merge regions on the same page")

    # Sort top-to-bottom, then left-to-right for text concatenation
    targets.sort(key=lambda r: (r.bbox.y0, r.bbox.x0))

    # Compute union bounding box
    merged_bbox = BBox(
        x0=min(r.bbox.x0 for r in targets),
        y0=min(r.bbox.y0 for r in targets),
        x1=max(r.bbox.x1 for r in targets),
        y1=max(r.bbox.y1 for r in targets),
    )

    # Concatenate text (space-separated, deduplicated trailing/leading whitespace)
    merged_text = " ".join(r.text.strip() for r in targets if r.text.strip())

    # Use first region's metadata as base
    first = targets[0]
    merged = PIIRegion(
        id=uuid.uuid4().hex[:16],
        page_number=first.page_number,
        bbox=merged_bbox,
        text=merged_text,
        pii_type=first.pii_type,
        confidence=max(r.confidence for r in targets),
        source=first.source,
        char_start=min(r.char_start for r in targets),
        char_end=max(r.char_end for r in targets),
        action=first.action,
        linked_group=None,
    )

    # Remove source regions and add merged one
    doc.regions = [r for r in doc.regions if r.id not in ids]
    doc.regions.append(merged)
    save_doc(doc)

    return {
        "status": "ok",
        "merged_region": merged.model_dump(),
        "removed_ids": list(ids),
    }


@router.post("/documents/{doc_id}/regions/group")
async def group_regions(doc_id: str, req: GroupRegionsRequest) -> dict[str, Any]:
    """Group two or more regions by assigning them a shared linked_group ID.

    All regions keep their individual bounding boxes and stay visible.
    They receive a common PII type (from the first region) and are
    logically treated as a single detection.
    """
    if len(req.region_ids) < 2:
        raise HTTPException(status_code=400, detail="At least 2 regions required to group")

    doc = get_doc(doc_id)
    ids = set(req.region_ids)
    targets = [r for r in doc.regions if r.id in ids]

    if len(targets) < 2:
        raise HTTPException(status_code=404, detail="Could not find enough matching regions")

    pages = {r.page_number for r in targets}
    if len(pages) > 1:
        raise HTTPException(status_code=400, detail="Can only group regions on the same page")

    # Assign a shared linked_group, unify PII type and text
    group_id = uuid.uuid4().hex[:12]
    # Cluster regions into visual lines by y-centre proximity,
    # then sort left-to-right within each line (same approach as
    # _cluster_into_lines but operating on PIIRegion objects).
    sorted_targets = _sort_by_reading_order(targets)
    first = sorted_targets[0]
    # Concatenate text from all regions (top-to-bottom, left-to-right)
    group_text = " ".join(r.text.strip() for r in sorted_targets if r.text.strip())
    for r in targets:
        r.linked_group = group_id
        r.pii_type = first.pii_type
        r.text = group_text

    save_doc(doc)

    return {
        "status": "ok",
        "linked_group": group_id,
        "updated": [r.model_dump() for r in targets],
    }


@router.post("/documents/{doc_id}/regions/ungroup")
async def ungroup_regions(doc_id: str, req: GroupRegionsRequest) -> dict[str, Any]:
    """Ungroup regions by clearing their linked_group ID.

    Each region becomes an independent detection again.
    Text is re-extracted from the text blocks under each region's
    individual bounding box.
    """
    if len(req.region_ids) < 1:
        raise HTTPException(status_code=400, detail="No region IDs provided")

    doc = get_doc(doc_id)
    ids = set(req.region_ids)
    targets = [r for r in doc.regions if r.id in ids]

    if not targets:
        raise HTTPException(status_code=404, detail="No matching regions found")

    # Build a page map to re-extract text under each region's bbox
    page_map = {p.page_number: p for p in doc.pages}

    for r in targets:
        r.linked_group = None
        # Re-extract text from text blocks under this region's bbox
        pd = page_map.get(r.page_number)
        if pd is not None:
            rx0, ry0, rx1, ry1 = r.bbox.x0, r.bbox.y0, r.bbox.x1, r.bbox.y1
            matched = []
            for block in pd.text_blocks:
                bb = block.bbox
                cx = (bb.x0 + bb.x1) / 2
                cy = (bb.y0 + bb.y1) / 2
                if rx0 <= cx <= rx1 and ry0 <= cy <= ry1:
                    matched.append(block)
            if matched:
                from core.ingestion.loader import _cluster_into_lines
                lines = _cluster_into_lines(matched)
                r.text = " ".join(
                    b.text.strip()
                    for line in lines
                    for b in line
                    if b.text.strip()
                )

    save_doc(doc)

    return {
        "status": "ok",
        "updated": [r.model_dump() for r in targets],
    }


@router.post("/documents/{doc_id}/regions/add")
async def add_manual_region(
    doc_id: str,
    region: PIIRegion,
    highlight_all: bool = True,
) -> dict[str, Any]:
    """Add a manually selected PII region, extract overlapping text, and
    optionally create sibling regions for all other occurrences of the same
    text.  Pass ``highlight_all=false`` to skip sibling creation."""
    doc = get_doc(doc_id)
    # H4: Always generate server-side ID â€” never trust client-provided IDs
    region.id = uuid.uuid4().hex[:12]
    region.source = "MANUAL"
    # Clamp to page bounds
    page_map = {p.page_number: p for p in doc.pages}
    pd = page_map.get(region.page_number)
    if pd is not None:
        region.bbox = _clamp_bbox(region.bbox, pd.width, pd.height)

    # Extract real text under the bbox from text blocks.
    # We require the centre of each word to fall inside the drawn region so
    # that a wide selection across empty space doesn't capture distant words.
    # After extraction, shrink the region bbox to tightly fit matched blocks.
    if pd is not None:
        matched_blocks: list[Any] = []
        rx0, ry0, rx1, ry1 = (
            region.bbox.x0, region.bbox.y0, region.bbox.x1, region.bbox.y1,
        )
        for block in pd.text_blocks:
            bb = block.bbox
            cx = (bb.x0 + bb.x1) / 2
            cy = (bb.y0 + bb.y1) / 2
            if rx0 <= cx <= rx1 and ry0 <= cy <= ry1:
                matched_blocks.append(block)

        # Column detection: sort blocks by horizontal centre and find
        # the largest gap.  If it exceeds a threshold we split into two
        # column groups and keep the one closest to the drawn region
        # centre.  This prevents a wide draw from merging text across
        # columns that happen to sit at the same vertical position.
        if matched_blocks:
            avg_h = sum(b.bbox.y1 - b.bbox.y0 for b in matched_blocks) / len(matched_blocks)

            cx_sorted = sorted(
                matched_blocks,
                key=lambda b: (b.bbox.x0 + b.bbox.x1) / 2,
            )

            best = cx_sorted  # default: keep all
            if len(cx_sorted) > 1:
                gaps: list[tuple[float, int]] = []
                for i in range(1, len(cx_sorted)):
                    prev_cx = (cx_sorted[i - 1].bbox.x0 + cx_sorted[i - 1].bbox.x1) / 2
                    cur_cx = (cx_sorted[i].bbox.x0 + cx_sorted[i].bbox.x1) / 2
                    gaps.append((cur_cx - prev_cx, i))

                max_gap, split_idx = max(gaps, key=lambda t: t[0])

                # Only split when the gap clearly indicates a column
                # boundary — not just normal inter-word spacing.
                # For 2 blocks we require a very large gap (15× height).
                # For 3+ blocks we additionally require the max gap to
                # dwarf the other gaps (3× the average of the rest),
                # which distinguishes a true column gap from uniform
                # word spacing.
                should_split = False
                if len(gaps) == 1:
                    should_split = max_gap > avg_h * 15
                else:
                    other_gaps = sorted(
                        [g for g, _ in gaps if (g, _) != (max_gap, split_idx)],
                    )
                    avg_other = sum(other_gaps) / len(other_gaps) if other_gaps else 0
                    should_split = (
                        max_gap > avg_h * 5
                        and avg_other > 0
                        and max_gap > avg_other * 3
                    )

                if should_split:
                    group_a = cx_sorted[:split_idx]
                    group_b = cx_sorted[split_idx:]
                    draw_cx = (rx0 + rx1) / 2
                    cx_a = sum((b.bbox.x0 + b.bbox.x1) / 2 for b in group_a) / len(group_a)
                    cx_b = sum((b.bbox.x0 + b.bbox.x1) / 2 for b in group_b) / len(group_b)
                    best = group_a if abs(cx_a - draw_cx) <= abs(cx_b - draw_cx) else group_b

            from core.ingestion.loader import _cluster_into_lines
            best_lines = _cluster_into_lines(best)
            region.text = " ".join(
                b.text for line in best_lines for b in line
            ).strip()

            # Strip surrounding parentheses â€” layout noise, not part
            # of the entity name.  Handle Unicode variants (fullwidth, etc.).
            _OPEN_PARENS = set('(\uff08\ufe59\u207d\u208d')
            _CLOSE_PARENS = set(')\uff09\ufe5a\u207e\u208e')
            if len(region.text) > 2 and region.text[0] in _OPEN_PARENS and region.text[-1] in _CLOSE_PARENS:
                region.text = region.text[1:-1].strip()

            # Snap bbox to the union of the chosen group
            region.bbox = BBox(
                x0=round(min(b.bbox.x0 for b in best), 2),
                y0=round(min(b.bbox.y0 for b in best), 2),
                x1=round(max(b.bbox.x1 for b in best), 2),
                y1=round(max(b.bbox.y1 for b in best), 2),
            )
    # â”€â”€ Dedup guard: if an existing (non-cancelled) region on the same page
    # already has the same normalised text and overlaps in both x AND y,
    # reuse it rather than creating a duplicate.  We require real bbox
    # intersection (not just y-band) so that two occurrences of the same
    # text on the same line (e.g. "9032 â€¦ 9032") can each have their own
    # region.
    #
    # We also reuse when the new text is a substring of an existing region's text
    # (or vice versa) AND the bboxes have real x+y intersection â€” e.g. the user
    # draws "A129980" inside an auto-detected "publique nÂ° A129980" region.
    region_norm = _normalize(region.text)
    existing_match: Any = None
    if region_norm:
        for er in doc.regions:
            if er.action == RegionAction.CANCEL or er.page_number != region.page_number:
                continue
            er_norm = _normalize(er.text)
            # Case 1: exact text match + real bbox intersection (x AND y)
            if er_norm == region_norm:
                ix0 = max(region.bbox.x0, er.bbox.x0)
                iy0 = max(region.bbox.y0, er.bbox.y0)
                ix1 = min(region.bbox.x1, er.bbox.x1)
                iy1 = min(region.bbox.y1, er.bbox.y1)
                if ix0 < ix1 and iy0 < iy1:
                    existing_match = er
                    break
            # Case 2: the NEW text is contained within an EXISTING region's text
            # + real bbox intersection â†’ reuse the bigger existing region.
            # We intentionally do NOT match when the existing text is a substring
            # of the new text (er_norm in region_norm), because that would
            # silently discard the user's broader selection in favour of a
            # shorter auto-detected region (e.g. user draws "Club Nautique
            # Jacques-Cartier", existing has "Nautique Jacques-Cartier" â†’
            # user would lose "Club").
            elif er_norm and region_norm in er_norm:
                ix0 = max(region.bbox.x0, er.bbox.x0)
                iy0 = max(region.bbox.y0, er.bbox.y0)
                ix1 = min(region.bbox.x1, er.bbox.x1)
                iy1 = min(region.bbox.y1, er.bbox.y1)
                if ix0 < ix1 and iy0 < iy1:
                    existing_match = er
                    break

    if existing_match is not None:
        # Reuse the existing region â€” update its pii_type if the user picked
        # a different one, then run highlight-all against it.
        if existing_match.pii_type != region.pii_type:
            existing_match.pii_type = region.pii_type
            save_doc(doc)
        new_regions_json: list[dict] = []
        all_ids: list[str] = [existing_match.id]
        cancelled_ids_list: list[str] = []
        if highlight_all and existing_match.text and existing_match.text != "[manual selection]":
            try:
                result = _highlight_all_impl(
                    doc_id, HighlightAllRequest(region_id=existing_match.id),
                )
                new_regions_json = result.get("new_regions", [])
                all_ids = result.get("all_ids", [existing_match.id])
                cancelled_ids_list = result.get("cancelled_ids", [])
            except Exception as e:
                logger.warning("Auto highlight-all after manual add (reuse) failed: %s", e)
        return {
            "status": "ok",
            "region_id": existing_match.id,
            "text": existing_match.text,
            "pii_type": existing_match.pii_type.value if hasattr(existing_match.pii_type, "value") else str(existing_match.pii_type),
            "bbox": existing_match.bbox.model_dump(mode="json"),
            "new_regions": new_regions_json,
            "all_ids": all_ids,
            "cancelled_ids": cancelled_ids_list,
        }

    # ── Remove existing regions on the same page whose text is a subset of
    # the new region's text and whose bboxes overlap.  highlight-all only
    # does this for pages where it creates *new* siblings, so the draw page
    # itself would retain the old smaller region without this step.
    region_norm = _normalize(region.text) if region.text else ""
    overlap_cancelled: list[str] = []
    if region_norm and region.text != "[manual selection]":
        rb = region.bbox
        for er in doc.regions:
            if er.id == region.id:
                continue
            if er.action == RegionAction.CANCEL or er.page_number != region.page_number:
                continue
            er_norm = _normalize(er.text)
            if not er_norm or er_norm == region_norm:
                continue
            # Cancel if the existing text is a substring of the new text
            # (e.g. "COLLEGE OF APPLIED ARTS" inside "THE SAULT COLLEGE OF APPLIED ARTS")
            # OR if the bboxes substantially overlap (≥40% of either region).
            ix0 = max(rb.x0, er.bbox.x0)
            iy0 = max(rb.y0, er.bbox.y0)
            ix1 = min(rb.x1, er.bbox.x1)
            iy1 = min(rb.y1, er.bbox.y1)
            if ix0 < ix1 and iy0 < iy1:
                inter = (ix1 - ix0) * (iy1 - iy0)
                er_area = max((er.bbox.x1 - er.bbox.x0) * (er.bbox.y1 - er.bbox.y0), 1e-6)
                if er_norm in region_norm or inter / er_area >= _OVERLAP_COVERAGE_THRESHOLD:
                    overlap_cancelled.append(er.id)
        if overlap_cancelled:
            cancel_set = set(overlap_cancelled)
            doc.regions = [r for r in doc.regions if r.id not in cancel_set]
            save_doc(doc)
            logger.info(
                "Manual draw: removed %d overlapping region(s) on page %d: %s",
                len(overlap_cancelled), region.page_number, overlap_cancelled,
            )

    doc.regions.append(region)
    save_doc(doc)

    # If meaningful text was found, highlight all occurrences across the doc
    new_regions_json: list[dict] = []
    all_ids: list[str] = [region.id]
    cancelled_ids_list: list[str] = []
    if highlight_all and region.text and region.text != "[manual selection]":
        try:
            result = _highlight_all_impl(
                doc_id, HighlightAllRequest(region_id=region.id),
            )
            new_regions_json = result.get("new_regions", [])
            all_ids = result.get("all_ids", [region.id])
            cancelled_ids_list = result.get("cancelled_ids", [])
        except Exception as e:
            logger.warning("Auto highlight-all after manual add failed: %s", e)

    # Merge overlap-cancelled IDs from draw page with highlight-all cancelled IDs
    if overlap_cancelled:
        cancelled_ids_list = list(set(cancelled_ids_list) | set(overlap_cancelled))

    return {
        "status": "ok",
        "region_id": region.id,
        "text": region.text,
        "pii_type": region.pii_type.value if hasattr(region.pii_type, "value") else str(region.pii_type),
        "bbox": region.bbox.model_dump(mode="json"),
        "new_regions": new_regions_json,
        "all_ids": all_ids,
        "cancelled_ids": cancelled_ids_list,
    }


# ---------------------------------------------------------------------------
# Blacklist â€” batch text search â†’ create/flag regions
# ---------------------------------------------------------------------------


@router.post("/documents/{doc_id}/regions/blacklist")
async def apply_blacklist(doc_id: str, req: BlacklistRequest) -> dict[str, Any]:
    """Search the document for each term and create MANUAL regions for matches.

    If a term overlaps an existing region, optionally flag that region for
    tokenization or removal instead of creating a duplicate.
    """
    import traceback
    try:
        return _blacklist_impl(doc_id, req)
    except HTTPException:
        raise
    except Exception as e:
        logger.error("blacklist error: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, detail="Internal server error")


# ---------------------------------------------------------------------------
# Highlight-all
# ---------------------------------------------------------------------------

class HighlightAllRequest(_PydanticBaseModel):
    region_id: str


@router.post("/documents/{doc_id}/regions/highlight-all")
async def highlight_all(doc_id: str, req: HighlightAllRequest) -> dict[str, Any]:
    """Find all occurrences of a region's text across every page and create
    new MANUAL regions for any that don't already have one."""
    import traceback
    try:
        return _highlight_all_impl(doc_id, req)
    except HTTPException:
        raise
    except Exception as e:
        logger.error("highlight-all error: %s\n%s", e, traceback.format_exc())
        raise HTTPException(500, detail="Internal server error")

