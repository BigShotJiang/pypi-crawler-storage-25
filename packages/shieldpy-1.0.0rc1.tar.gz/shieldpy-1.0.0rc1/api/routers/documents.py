"""Document upload, retrieval, listing, and deletion."""

from __future__ import annotations

import hashlib
import logging
import math
import os
import time as _time
import uuid
from pathlib import Path
from typing import Any, Optional, Union

import shutil

from fastapi import APIRouter, Body, File, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

from core.config import config
from models.schemas import (
    DocumentListItem,
    DocumentStatus,
    PIIRegion,
    PaginatedDocumentList,
    RegionAction,
    UploadResponse,
)
from api.deps import documents, get_doc, get_store, prune_doc_locks, save_doc, upload_progress, cleanup_stale_upload_progress
from api.audit_client import log_event as _audit

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["documents"])


def _compute_file_hash(file_path: Path) -> str:
    """Compute SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(256 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


@router.post("/documents/upload", response_model=UploadResponse)
async def upload_document(
    file: UploadFile = File(...),
    progress_id: Optional[str] = Query(None, description="Optional ID for tracking upload progress")
) -> UploadResponse:
    """Upload a document for anonymization.
    
    If progress_id is provided, progress can be tracked via GET /documents/{progress_id}/upload-progress
    """
    from core.ingestion.loader import SUPPORTED_EXTENSIONS, guess_mime

    if not file.filename:
        raise HTTPException(400, "No filename provided")

    # S3: Reject filenames with path separators to prevent traversal
    if any(c in file.filename for c in ("/", "\\", "..")):
        raise HTTPException(400, "Invalid filename")

    ext = Path(file.filename).suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            400,
            f"Unsupported file format '{ext}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}",
        )

    # Save uploaded file to temp
    upload_id = uuid.uuid4().hex[:8]
    upload_dir = config.temp_dir / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    safe_name = Path(file.filename).name  # strip directory components (path-traversal)
    upload_path = upload_dir / f"{upload_id}_{safe_name}"
    
    # Use progress_id for tracking, or generate one
    tracking_id = progress_id or upload_id

    MAX_UPLOAD_BYTES = 200 * 1024 * 1024  # 200 MB
    with open(upload_path, "wb") as f:
        total = 0
        while chunk := await file.read(256 * 1024):
            total += len(chunk)
            if total > MAX_UPLOAD_BYTES:
                f.close()
                upload_path.unlink(missing_ok=True)
                raise HTTPException(413, f"File too large (max {MAX_UPLOAD_BYTES // (1024*1024)} MB)")
            f.write(chunk)

    logger.info("Saved upload: %s (%s bytes)", upload_path, total)

    # Compute content hash for region cache lookup
    content_hash = _compute_file_hash(upload_path)

    # Initialize progress tracking
    upload_progress[tracking_id] = {
        "doc_id": tracking_id,
        "status": "processing",
        "phase": "starting",
        "current_page": 0,
        "total_pages": 0,
        "ocr_pages_done": 0,
        "ocr_pages_total": 0,
        "message": "Starting document processing...",
        "elapsed_seconds": 0.0,
        "_started_at": _time.time(),
    }
    
    def _progress_callback(phase: str, current: int, total: int, ocr_done: int, ocr_total: int, message: str):
        """Update upload progress tracking."""
        if tracking_id in upload_progress:
            upload_progress[tracking_id].update({
                "phase": phase,
                "current_page": current,
                "total_pages": total,
                "ocr_pages_done": ocr_done,
                "ocr_pages_total": ocr_total,
                "message": message,
                "status": "complete" if phase == "complete" else "processing",
            })

    # Ingest the document
    from core.ingestion.loader import ingest_document

    try:
        doc = await ingest_document(upload_path, file.filename, progress_callback=_progress_callback)
        # Update tracking to include actual doc_id
        if tracking_id in upload_progress:
            upload_progress[tracking_id]["doc_id"] = doc.doc_id
            upload_progress[tracking_id]["status"] = "complete"
    except RuntimeError as e:
        # RuntimeError is raised for missing dependencies like LibreOffice
        logger.error("Failed to process document: %s", e, exc_info=True)
        if tracking_id in upload_progress:
            upload_progress[tracking_id]["status"] = "error"
            upload_progress[tracking_id]["error"] = str(e)
        upload_path.unlink(missing_ok=True)
        raise HTTPException(400, str(e))
    except Exception as e:
        logger.error("Failed to process document: %s", e, exc_info=True)
        if tracking_id in upload_progress:
            upload_progress[tracking_id]["status"] = "error"
            upload_progress[tracking_id]["error"] = "Processing failed"
        upload_path.unlink(missing_ok=True)
        raise HTTPException(500, "Failed to process document. Check server logs for details.")

    # Store file in persistent storage
    store = get_store()

    # Set content hash and restore cached regions if available
    doc.content_hash = content_hash
    cached_regions = store.load_region_cache(content_hash)
    if cached_regions:
        try:
            doc.regions = [PIIRegion.model_validate(r) for r in cached_regions]
            doc.status = DocumentStatus.REVIEWING
            logger.info("Restored %s cached regions for %s", len(doc.regions), doc.doc_id)
        except Exception as e:
            logger.warning("Failed to restore cached regions: %s", e)

    try:
        stored_file_path = store.store_uploaded_file(doc.doc_id, upload_path, file.filename)
        doc.file_path = str(stored_file_path)
        logger.info("Stored file permanently: %s", stored_file_path)
    except Exception as e:
        logger.error("Failed to store file permanently: %s", e, exc_info=True)
    finally:
        # Clean up temporary upload file
        upload_path.unlink(missing_ok=True)

    # Copy page bitmaps to persistent storage
    try:
        store.store_page_bitmaps(doc)
        logger.info("Stored %s page bitmaps for %s", len(doc.pages), doc.doc_id)
    except Exception as e:
        logger.error("Failed to store bitmaps: %s", e, exc_info=True)

    # Save document state
    documents[doc.doc_id] = doc
    try:
        store.save_document(doc)
        logger.info("Saved document state for %s", doc.doc_id)
    except Exception as e:
        logger.error("Failed to save document state: %s", e, exc_info=True)

    _audit("load", entity_count=doc.page_count, file_type=Path(doc.original_filename).suffix.lstrip(".").lower() or None)

    return UploadResponse(
        doc_id=doc.doc_id,
        filename=doc.original_filename,
        page_count=doc.page_count,
        status=doc.status,
    )


@router.get("/documents/{doc_id}/upload-progress")
async def get_upload_progress(doc_id: str) -> dict[str, Any]:
    """Return real-time upload/ingestion progress for a document.
    
    Tracks file loading, page extraction, and OCR progress.
    """
    cleanup_stale_upload_progress()
    progress = upload_progress.get(doc_id)
    if progress is None:
        return {
            "doc_id": doc_id,
            "status": "idle",
            "phase": "idle",
            "current_page": 0,
            "total_pages": 0,
            "ocr_pages_done": 0,
            "ocr_pages_total": 0,
            "message": "",
            "elapsed_seconds": 0.0,
        }
    # Update elapsed time
    import time
    progress["elapsed_seconds"] = time.time() - progress.get("_started_at", time.time())
    # Return a clean copy (exclude internal keys)
    return {k: v for k, v in progress.items() if not k.startswith("_")}


# ---------------------------------------------------------------------------
# Folder scanning & upload-from-path (for Tauri native folder picker)
# ---------------------------------------------------------------------------

# Paths that must never be scanned or uploaded from, even when the user
# selects them through the native dialog.  Prevents accidental exposure of
# credentials, keys, and system-critical files.
_BLOCKED_PREFIXES: tuple[str, ...] = ()  # populated lazily

def _get_blocked_prefixes() -> tuple[str, ...]:
    global _BLOCKED_PREFIXES
    if _BLOCKED_PREFIXES:
        return _BLOCKED_PREFIXES
    import os, sys
    prefixes: list[str] = []
    home = Path.home().resolve()
    prefixes.append(str(home / ".ssh"))
    prefixes.append(str(home / ".gnupg"))
    prefixes.append(str(home / ".aws"))
    prefixes.append(str(home / ".config" / "gcloud"))
    if sys.platform == "win32":
        sys_root = os.environ.get("SystemRoot", r"C:\Windows")
        prefixes.append(sys_root)
    else:
        prefixes.extend(["/etc/shadow", "/etc/passwd", "/proc", "/sys"])
    _BLOCKED_PREFIXES = tuple(prefixes)
    return _BLOCKED_PREFIXES


def _check_path_allowed(p: Path) -> None:
    """Raise 403 if *p* is inside a blocked sensitive directory."""
    resolved = str(p.resolve())
    for blocked in _get_blocked_prefixes():
        if resolved == blocked or resolved.startswith(blocked + os.sep):
            raise HTTPException(403, "Access denied — path is inside a protected system directory")

class _ScanFolderRequest(BaseModel):
    folder_path: str

class _ScanFolderFile(BaseModel):
    name: str
    path: str
    size: int

class _UploadFromPathRequest(BaseModel):
    file_path: str
    progress_id: str | None = None


@router.post("/documents/scan-folder")
async def scan_folder(body: _ScanFolderRequest) -> list[_ScanFolderFile]:
    """List supported document files inside a local folder (non-recursive)."""
    from core.ingestion.loader import SUPPORTED_EXTENSIONS

    folder = Path(body.folder_path)
    if not folder.is_absolute():
        raise HTTPException(400, "Path must be absolute")
    folder = folder.resolve()
    _check_path_allowed(folder)
    if not folder.is_dir():
        raise HTTPException(400, "Not a valid directory")

    results: list[_ScanFolderFile] = []
    for entry in sorted(folder.iterdir()):
        if not entry.is_file():
            continue
        if entry.suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        results.append(_ScanFolderFile(
            name=entry.name,
            path=str(entry),
            size=entry.stat().st_size,
        ))
    return results


@router.post("/documents/upload-from-path", response_model=UploadResponse)
async def upload_from_path(body: _UploadFromPathRequest) -> UploadResponse:
    """Upload a document from a local file path (used by Tauri folder upload)."""
    from core.ingestion.loader import SUPPORTED_EXTENSIONS, ingest_document

    src = Path(body.file_path)
    if not src.is_absolute():
        raise HTTPException(400, "Path must be absolute")
    src = src.resolve()
    _check_path_allowed(src)
    if not src.is_file():
        raise HTTPException(400, "File not found")

    ext = src.suffix.lower()
    if ext not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            400,
            f"Unsupported file format '{ext}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}",
        )

    MAX_UPLOAD_BYTES = 200 * 1024 * 1024  # 200 MB
    file_size = src.stat().st_size
    if file_size > MAX_UPLOAD_BYTES:
        raise HTTPException(413, f"File too large (max {MAX_UPLOAD_BYTES // (1024*1024)} MB)")

    # Copy file to temp upload dir (same flow as regular upload)
    upload_id = uuid.uuid4().hex[:8]
    upload_dir = config.temp_dir / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)
    upload_path = upload_dir / f"{upload_id}_{src.name}"
    shutil.copy2(src, upload_path)

    tracking_id = body.progress_id or upload_id

    # Compute content hash for region cache lookup
    content_hash = _compute_file_hash(upload_path)

    logger.info("Upload from path: %s -> %s (%s bytes)", src, upload_path, file_size)

    # Progress tracking (identical to regular upload)
    upload_progress[tracking_id] = {
        "doc_id": tracking_id,
        "status": "processing",
        "phase": "starting",
        "current_page": 0,
        "total_pages": 0,
        "ocr_pages_done": 0,
        "ocr_pages_total": 0,
        "message": "Starting document processing...",
        "elapsed_seconds": 0.0,
        "_started_at": _time.time(),
    }

    def _progress_callback(phase: str, current: int, total: int, ocr_done: int, ocr_total: int, message: str):
        if tracking_id in upload_progress:
            upload_progress[tracking_id].update({
                "phase": phase,
                "current_page": current,
                "total_pages": total,
                "ocr_pages_done": ocr_done,
                "ocr_pages_total": ocr_total,
                "message": message,
                "status": "complete" if phase == "complete" else "processing",
            })

    try:
        doc = await ingest_document(upload_path, src.name, progress_callback=_progress_callback)
        if tracking_id in upload_progress:
            upload_progress[tracking_id]["doc_id"] = doc.doc_id
            upload_progress[tracking_id]["status"] = "complete"
    except RuntimeError as e:
        logger.error("Failed to process document: %s", e, exc_info=True)
        if tracking_id in upload_progress:
            upload_progress[tracking_id]["status"] = "error"
            upload_progress[tracking_id]["error"] = str(e)
        upload_path.unlink(missing_ok=True)
        raise HTTPException(400, str(e))
    except Exception as e:
        logger.error("Failed to process document: %s", e, exc_info=True)
        if tracking_id in upload_progress:
            upload_progress[tracking_id]["status"] = "error"
            upload_progress[tracking_id]["error"] = "Processing failed"
        upload_path.unlink(missing_ok=True)
        raise HTTPException(500, "Failed to process document. Check server logs for details.")

    # Store file in persistent storage
    store = get_store()

    # Set content hash and restore cached regions if available
    doc.content_hash = content_hash
    cached_regions = store.load_region_cache(content_hash)
    if cached_regions:
        try:
            doc.regions = [PIIRegion.model_validate(r) for r in cached_regions]
            doc.status = DocumentStatus.REVIEWING
            logger.info("Restored %s cached regions for %s", len(doc.regions), doc.doc_id)
        except Exception as e:
            logger.warning("Failed to restore cached regions: %s", e)

    try:
        stored_file_path = store.store_uploaded_file(doc.doc_id, upload_path, src.name)
        doc.file_path = str(stored_file_path)
        logger.info("Stored file permanently: %s", stored_file_path)
    except Exception as e:
        logger.error("Failed to store file permanently: %s", e, exc_info=True)
    finally:
        upload_path.unlink(missing_ok=True)

    try:
        store.store_page_bitmaps(doc)
        logger.info("Stored %s page bitmaps for %s", len(doc.pages), doc.doc_id)
    except Exception as e:
        logger.error("Failed to store bitmaps: %s", e, exc_info=True)

    documents[doc.doc_id] = doc
    try:
        store.save_document(doc)
        logger.info("Saved document state for %s", doc.doc_id)
    except Exception as e:
        logger.error("Failed to save document state: %s", e, exc_info=True)

    _audit("load", entity_count=doc.page_count, file_type=Path(doc.original_filename).suffix.lstrip(".").lower() or None)

    return UploadResponse(
        doc_id=doc.doc_id,
        filename=doc.original_filename,
        page_count=doc.page_count,
        status=doc.status,
    )


@router.get("/documents/groups")
async def list_groups() -> dict[str, Any]:
    """List all document groups (including empty ones).

    Returns: { "groups": [ { "group_id": "...", "group_name": "...", "doc_count": N }, ... ] }
    """
    group_map: dict[str, dict[str, Any]] = {}
    for doc in documents.values():
        if doc.group_id:
            if doc.group_id not in group_map:
                group_map[doc.group_id] = {"group_id": doc.group_id, "group_name": doc.group_name, "doc_count": 0}
            group_map[doc.group_id]["doc_count"] += 1

    store = get_store()
    empty_groups = store.load_groups()
    for gid, gname in empty_groups.items():
        if gid not in group_map:
            group_map[gid] = {"group_id": gid, "group_name": gname, "doc_count": 0}

    return {"groups": list(group_map.values())}


@router.get("/documents/{doc_id}")
async def get_document(doc_id: str) -> dict[str, Any]:
    """Get document metadata and page info."""
    doc = get_doc(doc_id)
    return doc.model_dump(mode="json")


@router.get("/documents/{doc_id}/pages/{page_number}")
async def get_page(doc_id: str, page_number: int) -> dict[str, Any]:
    """Get page data including text blocks."""
    doc = get_doc(doc_id)
    if page_number < 1 or page_number > doc.page_count:
        raise HTTPException(400, f"Invalid page number {page_number} (1-{doc.page_count})")
    page = doc.pages[page_number - 1]
    return page.model_dump(mode="json")


@router.get("/documents/{doc_id}/pages/{page_number}/bitmap")
async def get_page_bitmap(doc_id: str, page_number: int) -> FileResponse:
    """Serve the rendered page bitmap image."""
    doc = get_doc(doc_id)
    if page_number < 1 or page_number > doc.page_count:
        raise HTTPException(400, f"Invalid page number")
    page = doc.pages[page_number - 1]
    bitmap_path = Path(page.bitmap_path)
    if not bitmap_path.exists():
        raise HTTPException(404, "Bitmap not found")
    # S2: Ensure the resolved bitmap path is within the app's known directories
    # to prevent serving arbitrary files if persisted state were corrupted.
    # Bitmaps live in temp_dir (during ingestion) or data_dir (persisted).
    resolved = bitmap_path.resolve()
    allowed_dirs = (config.temp_dir.resolve(), config.data_dir.resolve())
    if not any(resolved.is_relative_to(d) for d in allowed_dirs):
        logger.warning("Blocked bitmap access outside app directories: %s", bitmap_path)
        raise HTTPException(403, "Access denied")
    return FileResponse(str(bitmap_path), media_type="image/png")


class ToggleExcludeRequest(BaseModel):
    excluded: bool


@router.put("/documents/{doc_id}/pages/{page_number}/exclude")
async def toggle_page_exclude(doc_id: str, page_number: int, req: ToggleExcludeRequest) -> dict[str, Any]:
    """Toggle exclusion status of a page. Excluded pages are skipped during export."""
    doc = get_doc(doc_id)
    if page_number < 1 or page_number > doc.page_count:
        raise HTTPException(400, f"Invalid page number {page_number} (1-{doc.page_count})")
    if req.excluded:
        if page_number not in doc.excluded_pages:
            doc.excluded_pages.append(page_number)
    else:
        doc.excluded_pages = [p for p in doc.excluded_pages if p != page_number]
    save_doc(doc)
    return {"excluded_pages": sorted(doc.excluded_pages)}


@router.get("/documents", response_model=Union[PaginatedDocumentList, list[DocumentListItem]])
async def list_documents(
    page: int = Query(1, ge=1, description="Page number (1-indexed)"),
    limit: int = Query(50, ge=1, le=500, description="Items per page"),
    paginated: bool = Query(True, description="Return paginated response"),
) -> Union[PaginatedDocumentList, list[DocumentListItem]]:
    """List all uploaded documents with optional pagination.
    
    Args:
        page: Page number (1-indexed, default: 1)
        limit: Items per page (default: 50, max: 500)
        paginated: If True, return paginated response with metadata. If False, return flat list.
    """
    # Use lightweight metadata reader — avoids full Pydantic validation
    # of every document's regions/pages/text_blocks on first call.
    items = sorted(
        documents.list_summaries(),
        key=lambda d: d.created_at,
        reverse=True,
    )
    total = len(items)

    if not paginated:
        return items
    
    # Apply pagination
    start = (page - 1) * limit
    end = start + limit
    page_items = items[start:end]
    pages = math.ceil(total / limit) if total > 0 else 1
    
    return PaginatedDocumentList(
        items=page_items,
        total=total,
        page=page,
        limit=limit,
        pages=pages,
    )


@router.delete("/documents/{doc_id}")
async def delete_document(doc_id: str) -> dict[str, str]:
    """Delete a document and all its persisted data."""
    if doc_id not in documents:
        raise HTTPException(404, f"Document '{doc_id}' not found")

    doc = documents[doc_id]

    # Cache regions before deletion so they can be restored on re-upload
    if doc.regions and doc.content_hash:
        try:
            store = get_store()
            store.save_region_cache(doc.content_hash, doc.regions, doc.original_filename)
        except Exception as e:
            logger.error("Failed to cache regions for %s: %s", doc_id, e)

    del documents[doc_id]
    prune_doc_locks()

    try:
        store = get_store()
        store.delete_document(doc_id)
    except Exception as e:
        logger.error("Failed to delete persistent data for %s: %s", doc_id, e)

    return {"status": "ok", "doc_id": doc_id}


# ---------------------------------------------------------------------------
# Document linking (groups for token consistency)
# ---------------------------------------------------------------------------

class _LinkRequest(BaseModel):
    doc_ids: list[str]
    group_id: str | None = None
    group_name: str | None = None

class _UnlinkRequest(BaseModel):
    doc_ids: list[str]

class _RenameGroupRequest(BaseModel):
    group_name: str


@router.put("/documents/link")
async def link_documents(body: _LinkRequest) -> dict[str, Any]:
    """Link selected documents so they share tokens on export.

    Body: { "doc_ids": ["id1", "id2", ...], "group_id": "<optional existing group>" }
    If group_id is omitted a new one is generated.
    """
    doc_ids = body.doc_ids
    if not doc_ids:
        raise HTTPException(400, "At least 1 document required")
    # Need 2+ docs to create a *new* group; 1 is ok when adding to existing
    if len(doc_ids) < 2 and not body.group_id:
        raise HTTPException(400, "At least 2 documents required to create a link")
    for did in doc_ids:
        if did not in documents:
            raise HTTPException(404, f"Document '{did}' not found")

    # Collect old groups that may become orphaned after relinking
    old_groups: set[str] = set()
    for did in doc_ids:
        if documents[did].group_id:
            old_groups.add(documents[did].group_id)

    # Reuse supplied group or any existing group on the selected docs, else create new
    group_id: str | None = body.group_id
    if not group_id:
        for did in doc_ids:
            if documents[did].group_id:
                group_id = documents[did].group_id
                break
    if not group_id:
        group_id = uuid.uuid4().hex[:8]

    # Don't orphan-check the target group itself
    old_groups.discard(group_id)

    # Determine group name: explicit, from an existing member, or default
    group_name: str | None = body.group_name
    if not group_name:
        for did in doc_ids:
            if documents[did].group_name:
                group_name = documents[did].group_name
                break
    # When adding to existing group, inherit name from existing members
    if not group_name and body.group_id:
        for d in documents.values():
            if d.group_id == body.group_id and d.group_name:
                group_name = d.group_name
                break

    # When docs join a group, it's no longer "empty" — remove from empty-groups store
    store = get_store()
    empty_groups = store.load_groups()
    if group_id in empty_groups:
        # Inherit name from the empty group if not explicitly provided
        if not group_name:
            group_name = empty_groups[group_id]
        del empty_groups[group_id]
        store.save_groups(empty_groups)

    for did in doc_ids:
        documents[did].group_id = group_id
        documents[did].group_name = group_name
        save_doc(documents[did])

    # Auto-unlink orphaned old groups (only 1 member remaining)
    auto_unlinked: list[str] = []
    for gid in old_groups:
        remaining = [d for d in documents.values() if d.group_id == gid]
        if len(remaining) == 1:
            remaining[0].group_id = None
            remaining[0].group_name = None
            save_doc(remaining[0])
            auto_unlinked.append(remaining[0].doc_id)

    return {"status": "ok", "group_id": group_id, "group_name": group_name, "doc_ids": doc_ids, "auto_unlinked": auto_unlinked}


@router.put("/documents/unlink")
async def unlink_documents(body: _UnlinkRequest) -> dict[str, Any]:
    """Remove documents from their linked group.

    Body: { "doc_ids": ["id1", "id2", ...] }
    If unlinking leaves a group with only 1 member, that member is auto-unlinked.
    """
    doc_ids = body.doc_ids
    # Collect affected group_ids before unlinking
    affected_groups: set[str] = set()
    for did in doc_ids:
        if did not in documents:
            raise HTTPException(404, f"Document '{did}' not found")
        if documents[did].group_id:
            affected_groups.add(documents[did].group_id)
        documents[did].group_id = None
        documents[did].group_name = None
        save_doc(documents[did])

    # Auto-unlink orphaned groups (only 1 member remaining)
    auto_unlinked: list[str] = []
    for gid in affected_groups:
        remaining = [d for d in documents.values() if d.group_id == gid]
        if len(remaining) == 1:
            remaining[0].group_id = None
            remaining[0].group_name = None
            save_doc(remaining[0])
            auto_unlinked.append(remaining[0].doc_id)

    return {"status": "ok", "doc_ids": doc_ids, "auto_unlinked": auto_unlinked}


@router.put("/documents/group/{group_id}/name")
async def rename_group(group_id: str, body: _RenameGroupRequest) -> dict[str, Any]:
    """Rename a linked document group.

    Path: group_id — the group to rename.
    Body: { "group_name": "New name" }
    """
    members = [d for d in documents.values() if d.group_id == group_id]

    # Also check the empty-groups store
    store = get_store()
    empty_groups = store.load_groups()
    is_empty = group_id in empty_groups

    if not members and not is_empty:
        raise HTTPException(404, f"Group '{group_id}' not found")

    for doc in members:
        doc.group_name = body.group_name
        save_doc(doc)

    if is_empty:
        empty_groups[group_id] = body.group_name
        store.save_groups(empty_groups)

    return {
        "status": "ok",
        "group_id": group_id,
        "group_name": body.group_name,
        "doc_ids": [d.doc_id for d in members],
    }


class _CreateGroupRequest(BaseModel):
    group_name: str


@router.post("/documents/group")
async def create_group(body: _CreateGroupRequest) -> dict[str, Any]:
    """Create an empty document group (folder).

    Body: { "group_name": "My folder" }
    Returns: { "status": "ok", "group_id": "...", "group_name": "..." }
    """
    if not body.group_name.strip():
        raise HTTPException(400, "Group name must not be empty")
    group_id = uuid.uuid4().hex[:8]
    store = get_store()
    empty_groups = store.load_groups()
    empty_groups[group_id] = body.group_name.strip()
    store.save_groups(empty_groups)
    return {"status": "ok", "group_id": group_id, "group_name": body.group_name.strip()}


@router.delete("/documents/group/{group_id}")
async def delete_group(group_id: str) -> dict[str, Any]:
    """Delete a group — unlinks all docs in it and removes it from the empty-groups store."""
    members = [d for d in documents.values() if d.group_id == group_id]
    for doc in members:
        doc.group_id = None
        doc.group_name = None
        save_doc(doc)

    store = get_store()
    empty_groups = store.load_groups()
    if group_id in empty_groups:
        del empty_groups[group_id]
        store.save_groups(empty_groups)

    return {"status": "ok", "group_id": group_id, "doc_ids": [d.doc_id for d in members]}
