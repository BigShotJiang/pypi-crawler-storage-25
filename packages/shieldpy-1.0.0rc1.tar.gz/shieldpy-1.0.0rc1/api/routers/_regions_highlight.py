"""Highlight-all logic — find and create regions for all occurrences of a
region's text across every page of the document.

Split from ``regions.py`` to keep the router under ~760 LOC.  The public
entry point is ``_highlight_all_impl``; route wiring stays in
``regions.py``.

Deduplication
~~~~~~~~~~~~~
New regions are checked against *existing* regions (same page, overlapping
bbox, matching text) so duplicates are never created.  The grouped variant
also tracks an ``existing_spans`` set to skip already-covered text spans.
"""

from __future__ import annotations

import logging
import unicodedata
import uuid
from collections import Counter
from typing import Any

from fastapi import HTTPException

from models.schemas import (
    BBox,
    DetectionSource,
    PIIRegion,
    RegionAction,
)
from api.deps import get_doc, save_doc
from api.routers._regions_helpers import (
    _CHAR_OVERLAP_MIN_RATIO,
    _FUZZY_THRESHOLD,
    _OVERLAP_COVERAGE_THRESHOLD,
    _extract_individual_text,
    _fuzzy_ratio,
    _normalize,
    _sort_by_reading_order,
)

logger = logging.getLogger(__name__)


# ── Grouped highlight-all ────────────────────────────────────────────────

def _highlight_all_grouped(doc: Any, source_region: PIIRegion) -> dict[str, Any]:
    """Highlight-all for grouped regions.

    Instead of searching for the concatenated group text, we:
    1. Re-extract each sibling's individual text from its bbox.
    2. Search the document for each individual text.
    3. When matches from different siblings appear on the same page
       with similar spatial proximity, auto-group them.
    """
    from core.detection.pipeline import _compute_block_offsets
    from core.detection.block_offsets import _char_offsets_to_line_bboxes, _char_offset_to_bbox

    group_id = source_region.linked_group
    siblings = _sort_by_reading_order(
        [r for r in doc.regions if r.linked_group == group_id]
    )
    if len(siblings) < 2:
        return _highlight_all_ungrouped(doc, source_region)

    anchor = siblings[0]
    sibling_info: list[dict] = []
    for sib in siblings:
        ind_text = _extract_individual_text(sib, doc)
        ind_norm = _normalize(ind_text)
        if not ind_norm:
            continue
        sibling_info.append({
            "region": sib,
            "text": ind_text,
            "norm": ind_norm,
            "dy": sib.bbox.y0 - anchor.bbox.y0,
            "dx": sib.bbox.x0 - anchor.bbox.x0,
        })

    if not sibling_info:
        return {"created": 0, "new_regions": [], "all_ids": [source_region.id], "cancelled_ids": []}

    existing_spans: dict[int, list[tuple[float, float, float, float, str]]] = {}
    for r in doc.regions:
        if r.action == RegionAction.CANCEL:
            continue
        existing_spans.setdefault(r.page_number, []).append(
            (r.bbox.x0, r.bbox.y0, r.bbox.x1, r.bbox.y1, r.text.strip().lower())
        )

    avg_h = sum(s["region"].bbox.y1 - s["region"].bbox.y0 for s in sibling_info) / len(sibling_info)
    proximity_tol = max(avg_h * 3.0, 20.0)

    new_regions: list[PIIRegion] = []
    grouped_existing: list[PIIRegion] = []
    cancelled_ids: set[str] = set()

    for page in doc.pages:
        full_text = page.full_text
        if not full_text:
            continue

        block_offsets = _compute_block_offsets(page.text_blocks, full_text)

        full_norm = _normalize(full_text)
        tmp = unicodedata.normalize("NFKD", full_text)
        tmp3 = "".join(c for c in tmp if not unicodedata.combining(c)).lower()

        _tmp2_to_nfkd: list[int] = []
        _nfkd_i = 0
        for _c in tmp:
            if not unicodedata.combining(_c):
                _tmp2_to_nfkd.append(_nfkd_i)
            _nfkd_i += 1

        nfkd_to_orig: list[int] = []
        for _oi, _orig_c in enumerate(full_text):
            for _ in unicodedata.normalize("NFKD", _orig_c):
                nfkd_to_orig.append(_oi)

        _norm_chars: list[int] = []
        in_space = False
        stripped_leading = False
        for ci, ch in enumerate(tmp3):
            is_ws = ch in (" ", "\t", "\n", "\r")
            if not stripped_leading and is_ws:
                continue
            if is_ws:
                if not in_space:
                    _norm_chars.append(ci)
                    in_space = True
            else:
                stripped_leading = True
                _norm_chars.append(ci)
                in_space = False

        def norm_idx_to_orig(ni_: int) -> int:
            if ni_ < len(_norm_chars):
                tmp3_idx = _norm_chars[ni_]
                if tmp3_idx < len(_tmp2_to_nfkd):
                    nfkd_idx = _tmp2_to_nfkd[tmp3_idx]
                    if nfkd_idx < len(nfkd_to_orig):
                        return nfkd_to_orig[nfkd_idx]
            return len(full_text)

        per_sib_matches: list[list[tuple[BBox, str, str | None]]] = [[] for _ in sibling_info]

        for si, sinfo in enumerate(sibling_info):
            needle_norm = sinfo["norm"]
            needle_len = len(needle_norm)

            search_start_n = 0
            matches: list[tuple[int, int]] = []
            while True:
                idx_n = full_norm.find(needle_norm, search_start_n)
                if idx_n == -1:
                    break
                search_start_n = idx_n + 1
                orig_start = norm_idx_to_orig(idx_n)
                orig_end_idx = idx_n + needle_len
                orig_end = norm_idx_to_orig(orig_end_idx) if orig_end_idx < len(full_norm) else len(full_text)
                matches.append((orig_start, orig_end))

            for idx, match_end in matches:
                line_bboxes = _char_offsets_to_line_bboxes(idx, match_end, block_offsets)
                if not line_bboxes:
                    single = _char_offset_to_bbox(idx, match_end, block_offsets)
                    if single is None:
                        continue
                    line_bboxes = [single]

                matched_text = full_text[idx:match_end]
                ux0 = min(lb.x0 for lb in line_bboxes)
                uy0 = min(lb.y0 for lb in line_bboxes)
                ux1 = max(lb.x1 for lb in line_bboxes)
                uy1 = max(lb.y1 for lb in line_bboxes)
                ux0 = max(0.0, min(ux0, page.width))
                uy0 = max(0.0, min(uy0, page.height))
                ux1 = max(0.0, min(ux1, page.width))
                uy1 = max(0.0, min(uy1, page.height))

                mbbox = BBox(x0=round(ux0, 2), y0=round(uy0, 2),
                             x1=round(ux1, 2), y1=round(uy1, 2))

                covering_region_id: str | None = None
                page_existing = existing_spans.get(page.page_number, [])
                matched_text_norm = _normalize(matched_text)

                for ex0, ey0, ex1, ey1, etxt in page_existing:
                    if _normalize(etxt) == matched_text_norm:
                        if ey0 <= uy1 and ey1 >= uy0:
                            for er in doc.regions:
                                if er.page_number != page.page_number or er.action == RegionAction.CANCEL:
                                    continue
                                if (abs(er.bbox.x0 - ex0) < 1.0 and abs(er.bbox.y0 - ey0) < 1.0
                                        and _normalize(er.text.strip()) == matched_text_norm):
                                    covering_region_id = er.id
                                    break
                            break

                if covering_region_id is None:
                    for er in doc.regions:
                        if er.page_number != page.page_number or er.action == RegionAction.CANCEL:
                            continue
                        ix0 = max(ux0, er.bbox.x0); iy0 = max(uy0, er.bbox.y0)
                        ix1 = min(ux1, er.bbox.x1); iy1 = min(uy1, er.bbox.y1)
                        if ix0 < ix1 and iy0 < iy1:
                            inter = (ix1 - ix0) * (iy1 - iy0)
                            match_area = max((ux1 - ux0) * (uy1 - uy0), 1e-6)
                            existing_area = max((er.bbox.x1 - er.bbox.x0) * (er.bbox.y1 - er.bbox.y0), 1e-6)
                            if inter / match_area > 0.5 or inter / existing_area > 0.5:
                                covering_region_id = er.id
                                break

                per_sib_matches[si].append((mbbox, matched_text, covering_region_id))

        if not per_sib_matches[0]:
            continue

        used_matches: set[tuple[int, int]] = set()

        for m0_idx, (m0_bbox, m0_text, m0_existing_id) in enumerate(per_sib_matches[0]):
            if (page.page_number == anchor.page_number
                    and abs(m0_bbox.y0 - anchor.bbox.y0) < proximity_tol
                    and abs(m0_bbox.x0 - anchor.bbox.x0) < proximity_tol):
                continue

            group_members: list[tuple[BBox, str, int, int, str | None]] = [
                (m0_bbox, m0_text, 0, m0_idx, m0_existing_id)
            ]

            for si in range(1, len(sibling_info)):
                expected_y = m0_bbox.y0 + sibling_info[si]["dy"]
                expected_x = m0_bbox.x0 + sibling_info[si]["dx"]
                best_match = None
                best_dist = float("inf")

                for mi, (m_bbox, m_text, m_existing_id) in enumerate(per_sib_matches[si]):
                    if (si, mi) in used_matches:
                        continue
                    dy = abs(m_bbox.y0 - expected_y)
                    dx = abs(m_bbox.x0 - expected_x)
                    dist = (dx ** 2 + dy ** 2) ** 0.5
                    if dist < proximity_tol and dist < best_dist:
                        best_match = (m_bbox, m_text, si, mi, m_existing_id)
                        best_dist = dist

                if best_match is not None:
                    group_members.append(best_match)

            group_members.sort(key=lambda m: (m[0].y0, m[0].x0))
            group_text = " ".join(m[1].strip() for m in group_members if m[1].strip())
            new_group_id = uuid.uuid4().hex[:12] if len(group_members) > 1 else None

            for mbbox, mtext, si, mi, existing_id in group_members:
                used_matches.add((si, mi))

                if existing_id is not None:
                    for er in doc.regions:
                        if er.id == existing_id:
                            er.linked_group = new_group_id
                            er.text = group_text if new_group_id else mtext
                            grouped_existing.append(er)
                            break
                else:
                    region = PIIRegion(
                        page_number=page.page_number,
                        bbox=mbbox,
                        text=group_text if new_group_id else mtext,
                        pii_type=source_region.pii_type,
                        confidence=source_region.confidence,
                        source=DetectionSource.MANUAL,
                        action=RegionAction.PENDING,
                        linked_group=new_group_id,
                    )
                    new_regions.append(region)
                    doc.regions.append(region)
                    existing_spans.setdefault(page.page_number, []).append(
                        (mbbox.x0, mbbox.y0, mbbox.x1, mbbox.y1, mtext.strip().lower())
                    )

    source_group_ids = [r.id for r in siblings]
    all_ids = list(source_group_ids) + [r.id for r in new_regions]
    all_ids += [r.id for r in grouped_existing]

    existing_norms = {s["norm"] for s in sibling_info}
    all_ids_set = set(all_ids)
    for r in doc.regions:
        if r.id in all_ids_set:
            continue
        r_norm = _normalize(r.text.strip())
        if r_norm and any(_fuzzy_ratio(en, r_norm) >= _FUZZY_THRESHOLD for en in existing_norms):
            all_ids.append(r.id)

    save_doc(doc)

    return {
        "created": len(new_regions),
        "new_regions": [r.model_dump(mode="json") for r in new_regions],
        "updated_regions": [r.model_dump(mode="json") for r in grouped_existing],
        "all_ids": all_ids,
        "cancelled_ids": list(cancelled_ids),
    }


# ── Ungrouped highlight-all ──────────────────────────────────────────────

def _highlight_all_ungrouped(doc: Any, source_region: PIIRegion) -> dict[str, Any]:
    """Standard highlight-all for ungrouped regions."""
    from core.detection.pipeline import _compute_block_offsets
    from core.detection.block_offsets import _char_offsets_to_line_bboxes, _char_offset_to_bbox

    needle = source_region.text.strip()
    needle_lower = needle.lower()
    needle_norm = _normalize(needle)
    if not needle_norm:
        return {"created": 0, "new_regions": [], "all_ids": [source_region.id]}

    existing_spans: dict[int, list[tuple[float, float, float, float, str, int, int]]] = {}
    for r in doc.regions:
        if r.action == RegionAction.CANCEL:
            continue
        existing_spans.setdefault(r.page_number, []).append(
            (r.bbox.x0, r.bbox.y0, r.bbox.x1, r.bbox.y1, r.text.strip().lower(),
             r.char_start, r.char_end)
        )

    new_regions: list[PIIRegion] = []
    cancelled_ids: set[str] = set()

    for page in doc.pages:
        full_text = page.full_text
        if not full_text:
            continue

        block_offsets = _compute_block_offsets(page.text_blocks, full_text)

        needle_len = len(needle_norm)
        full_norm = _normalize(full_text)

        tmp = unicodedata.normalize("NFKD", full_text)
        tmp3 = "".join(c for c in tmp if not unicodedata.combining(c)).lower()

        _tmp2_to_nfkd: list[int] = []
        _nfkd_i = 0
        for _c in tmp:
            if not unicodedata.combining(_c):
                _tmp2_to_nfkd.append(_nfkd_i)
            _nfkd_i += 1

        nfkd_to_orig: list[int] = []
        for _oi, _orig_c in enumerate(full_text):
            for _ in unicodedata.normalize("NFKD", _orig_c):
                nfkd_to_orig.append(_oi)

        _norm_chars: list[int] = []
        in_space = False
        stripped_leading = False
        for ci, ch in enumerate(tmp3):
            is_ws = ch in (" ", "\t", "\n", "\r")
            if not stripped_leading and is_ws:
                continue
            if is_ws:
                if not in_space:
                    _norm_chars.append(ci)
                    in_space = True
            else:
                stripped_leading = True
                _norm_chars.append(ci)
                in_space = False

        def norm_idx_to_orig(ni_: int) -> int:
            if ni_ < len(_norm_chars):
                tmp3_idx = _norm_chars[ni_]
                if tmp3_idx < len(_tmp2_to_nfkd):
                    nfkd_idx = _tmp2_to_nfkd[tmp3_idx]
                    if nfkd_idx < len(nfkd_to_orig):
                        return nfkd_to_orig[nfkd_idx]
            return len(full_text)

        search_start_n = 0
        matches: list[tuple[int, int]] = []

        while True:
            idx_n = full_norm.find(needle_norm, search_start_n)
            if idx_n == -1:
                break
            search_start_n = idx_n + 1
            orig_start = norm_idx_to_orig(idx_n)
            orig_end_idx = idx_n + needle_len
            orig_end = norm_idx_to_orig(orig_end_idx) if orig_end_idx < len(full_norm) else len(full_text)
            matches.append((orig_start, orig_end))

        if needle_len >= 2 and len(matches) == 0:
            window = needle_len
            needle_freq = Counter(needle_norm)
            for tol in (0, 1, 2):
                wlen = window + tol
                if wlen > len(full_norm):
                    continue
                for si in range(len(full_norm) - wlen + 1):
                    chunk = full_norm[si : si + wlen]
                    chunk_freq = Counter(chunk)
                    shared = sum((needle_freq & chunk_freq).values())
                    if shared < needle_len * _CHAR_OVERLAP_MIN_RATIO:
                        continue
                    if _fuzzy_ratio(needle_norm, chunk) >= _FUZZY_THRESHOLD:
                        orig_start = norm_idx_to_orig(si)
                        orig_end = norm_idx_to_orig(si + wlen) if si + wlen < len(full_norm) else len(full_text)
                        if any(abs(orig_start - ms) < max(needle_len // 2, 2) for ms, _ in matches):
                            continue
                        matches.append((orig_start, orig_end))
                wlen = window - tol if tol > 0 else -1
                if wlen >= 2 and wlen <= len(full_norm):
                    for si in range(len(full_norm) - wlen + 1):
                        chunk = full_norm[si : si + wlen]
                        chunk_freq = Counter(chunk)
                        shared = sum((needle_freq & chunk_freq).values())
                        if shared < needle_len * _CHAR_OVERLAP_MIN_RATIO:
                            continue
                        if _fuzzy_ratio(needle_norm, chunk) >= _FUZZY_THRESHOLD:
                            orig_start = norm_idx_to_orig(si)
                            orig_end = norm_idx_to_orig(si + wlen) if si + wlen < len(full_norm) else len(full_text)
                            if any(abs(orig_start - ms) < max(needle_len // 2, 2) for ms, _ in matches):
                                continue
                            matches.append((orig_start, orig_end))

        for idx, match_end in matches:
            line_bboxes = _char_offsets_to_line_bboxes(idx, match_end, block_offsets)
            if not line_bboxes:
                single = _char_offset_to_bbox(idx, match_end, block_offsets)
                if single is None:
                    continue
                line_bboxes = [single]

            matched_text = full_text[idx:match_end]

            for lbbox in line_bboxes:
                bx0, by0, bx1, by1 = lbbox.x0, lbbox.y0, lbbox.x1, lbbox.y1

                bx0 = max(0.0, min(bx0, page.width))
                by0 = max(0.0, min(by0, page.height))
                bx1 = max(0.0, min(bx1, page.width))
                by1 = max(0.0, min(by1, page.height))

                page_existing = existing_spans.get(page.page_number, [])
                already_covered = False
                covering_idx = -1
                matched_text_norm = _normalize(matched_text)
                for _ei, (ex0, ey0, ex1, ey1, etxt, e_cs, e_ce) in enumerate(page_existing):
                    if _normalize(etxt) == matched_text_norm:
                        if e_cs > 0 or e_ce > 0:
                            if idx < e_ce and match_end > e_cs:
                                already_covered = True
                                covering_idx = _ei
                                break
                            continue
                        ix0 = max(bx0, ex0); iy0 = max(by0, ey0)
                        ix1 = min(bx1, ex1); iy1 = min(by1, ey1)
                        if ix0 < ix1 and iy0 < iy1:
                            already_covered = True
                            covering_idx = _ei
                            break
                        continue
                    etxt_norm = _normalize(etxt)
                    # Match text is a substring of existing region — the
                    # existing region already covers this occurrence.
                    if matched_text_norm in etxt_norm:
                        if e_cs > 0 or e_ce > 0:
                            if idx < e_ce and match_end > e_cs:
                                already_covered = True
                                covering_idx = _ei
                                break
                        else:
                            ix0 = max(bx0, ex0); iy0 = max(by0, ey0)
                            ix1 = min(bx1, ex1); iy1 = min(by1, ey1)
                            if ix0 < ix1 and iy0 < iy1:
                                already_covered = True
                                covering_idx = _ei
                                break
                        continue
                    if len(etxt_norm) < len(matched_text_norm) * 0.85:
                        continue
                    if len(etxt_norm) > len(matched_text_norm) * 2.0:
                        continue
                    ix0 = max(bx0, ex0); iy0 = max(by0, ey0)
                    ix1 = min(bx1, ex1); iy1 = min(by1, ey1)
                    if ix0 < ix1 and iy0 < iy1:
                        inter_area = (ix1 - ix0) * (iy1 - iy0)
                        new_area = max((bx1 - bx0) * (by1 - by0), 1e-6)
                        if inter_area / new_area > _OVERLAP_COVERAGE_THRESHOLD:
                            already_covered = True
                            covering_idx = _ei
                            break
                if already_covered:
                    if covering_idx >= 0:
                        page_existing.pop(covering_idx)
                    continue

                for _er in list(doc.regions):
                    if _er.action == RegionAction.CANCEL or _er.page_number != page.page_number:
                        continue
                    _er_norm = _normalize(_er.text)
                    if not _er_norm or _er_norm == matched_text_norm:
                        continue
                    if _er_norm not in matched_text_norm:
                        continue
                    _ix0 = max(bx0, _er.bbox.x0); _iy0 = max(by0, _er.bbox.y0)
                    _ix1 = min(bx1, _er.bbox.x1); _iy1 = min(by1, _er.bbox.y1)
                    if _ix0 < _ix1 and _iy0 < _iy1:
                        cancelled_ids.add(_er.id)
                        existing_spans[page.page_number] = [
                            _s for _s in existing_spans.get(page.page_number, [])
                            if not (abs(_s[0] - _er.bbox.x0) < 1.0
                                    and abs(_s[1] - _er.bbox.y0) < 1.0)
                        ]

                if cancelled_ids:
                    doc.regions = [r for r in doc.regions if r.id not in cancelled_ids]

                region = PIIRegion(
                    page_number=page.page_number,
                    bbox=BBox(x0=round(bx0, 2), y0=round(by0, 2),
                              x1=round(bx1, 2), y1=round(by1, 2)),
                    text=matched_text,
                    pii_type=source_region.pii_type,
                    confidence=source_region.confidence,
                    source=DetectionSource.MANUAL,
                    action=RegionAction.PENDING,
                    char_start=idx,
                    char_end=match_end,
                )
                new_regions.append(region)
                doc.regions.append(region)
                existing_spans.setdefault(page.page_number, []).append(
                    (bx0, by0, bx1, by1, needle_lower, idx, match_end)
                )

    if cancelled_ids:
        doc.regions = [r for r in doc.regions if r.id not in cancelled_ids]

    new_ids = {r.id for r in new_regions}
    all_ids = []
    for r in doc.regions:
        r_norm = _normalize(r.text.strip())
        if not r_norm:
            continue
        if r.id == source_region.id or r.id in new_ids:
            all_ids.append(r.id)
        elif _fuzzy_ratio(needle_norm, r_norm) >= _FUZZY_THRESHOLD:
            all_ids.append(r.id)

    save_doc(doc)

    return {
        "created": len(new_regions),
        "new_regions": [r.model_dump(mode="json") for r in new_regions],
        "all_ids": all_ids,
        "cancelled_ids": list(cancelled_ids),
    }


# ── Public dispatcher ────────────────────────────────────────────────────

def _highlight_all_impl(doc_id: str, req: Any) -> dict[str, Any]:
    """Core implementation of highlight-all — find and create regions for all
    occurrences of a region's text across every page."""
    doc = get_doc(doc_id)

    source_region = next((r for r in doc.regions if r.id == req.region_id), None)
    if source_region is None:
        raise HTTPException(404, "Region not found")

    if source_region.linked_group:
        return _highlight_all_grouped(doc, source_region)

    return _highlight_all_ungrouped(doc, source_region)
