"""Shared helpers for the regions router sub-modules.

Provides normalisation, fuzzy matching, reading-order sorting, and text
extraction utilities used by highlight-all, blacklist, and manual-add.

Text normalisation delegates to ``core.text_utils.normalize_for_matching``
— the canonical normalisation implementation.  The thin ``_normalize``
wrapper here exists only for call-site brevity.
"""

from __future__ import annotations

from typing import Any

from models.schemas import BBox, PIIRegion


# ── Thresholds (used across sub-modules) ──────────────────────────────────

_FUZZY_THRESHOLD = 0.75  # 75% similarity for highlight-all matching
_OVERLAP_COVERAGE_THRESHOLD = 0.4  # 40% bbox intersection to consider "already covered"
_CHAR_OVERLAP_MIN_RATIO = 0.6  # 60% char-frequency overlap for fuzzy pre-filter


# ── Normalisation / fuzzy helpers ─────────────────────────────────────────

def _normalize(text: str) -> str:
    """Normalize for fuzzy matching: lowercase, collapse whitespace, strip accents."""
    from core.text_utils import normalize_for_matching
    return normalize_for_matching(text)


def _fuzzy_ratio(a: str, b: str) -> float:
    """Quick similarity ratio between two strings (0..1)."""
    from difflib import SequenceMatcher
    return SequenceMatcher(None, a, b).ratio()


# ── Reading-order sort ────────────────────────────────────────────────────

def _sort_by_reading_order(regions: list[PIIRegion]) -> list[PIIRegion]:
    """Sort PIIRegions by visual reading order using y-centre line clustering."""
    if not regions:
        return regions
    by_y = sorted(regions, key=lambda r: (r.bbox.y0 + r.bbox.y1) / 2)
    lines: list[list[PIIRegion]] = []
    cur: list[PIIRegion] = []
    line_yc = 0.0
    line_h = 0.0
    for r in by_y:
        rh = r.bbox.y1 - r.bbox.y0
        ryc = (r.bbox.y0 + r.bbox.y1) / 2
        if not cur:
            cur.append(r)
            line_yc = ryc
            line_h = rh
        else:
            tol = max(line_h, rh) * 0.5
            if abs(ryc - line_yc) <= tol:
                cur.append(r)
                line_h = max(line_h, rh)
                n = len(cur)
                line_yc = (line_yc * (n - 1) + ryc) / n
            else:
                lines.append(sorted(cur, key=lambda r: r.bbox.x0))
                cur = [r]
                line_yc = ryc
                line_h = rh
    if cur:
        lines.append(sorted(cur, key=lambda r: r.bbox.x0))
    return [r for line in lines for r in line]


# ── Text extraction from bbox ────────────────────────────────────────────

def _extract_individual_text(region: PIIRegion, doc: Any) -> str:
    """Re-extract text from text blocks under a single region's bbox."""
    page_map = {p.page_number: p for p in doc.pages}
    pd = page_map.get(region.page_number)
    if pd is None:
        return region.text

    rx0, ry0, rx1, ry1 = region.bbox.x0, region.bbox.y0, region.bbox.x1, region.bbox.y1
    matched = []
    for block in pd.text_blocks:
        bb = block.bbox
        cx = (bb.x0 + bb.x1) / 2
        cy = (bb.y0 + bb.y1) / 2
        if rx0 <= cx <= rx1 and ry0 <= cy <= ry1:
            matched.append(block)
    if not matched:
        return region.text
    from core.ingestion.loader import _cluster_into_lines
    lines = _cluster_into_lines(matched)
    return " ".join(b.text.strip() for line in lines for b in line if b.text.strip())
