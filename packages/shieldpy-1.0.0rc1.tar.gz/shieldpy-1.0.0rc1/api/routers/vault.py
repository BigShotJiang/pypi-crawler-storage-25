"""Token Registry: status, stats, tokens, export, import.

The token registry no longer requires a passphrase — it auto-initialises on
first access and stores token mappings in plaintext SQLite.  The ``/vault/unlock``
endpoint is kept as a no-op for backward compatibility with older frontends.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel as _PydanticBaseModel

from models.schemas import RegionAction, VaultStatsResponse, VaultUnlockResponse, VaultStatusResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["vault"])


class _PassphraseBody(_PydanticBaseModel):
    passphrase: str = ""


@router.post("/vault/unlock", response_model=VaultUnlockResponse)
async def unlock_vault(body: _PassphraseBody | None = None) -> VaultUnlockResponse:
    """No-op kept for backward compatibility — vault auto-initialises."""
    from core.vault.store import vault
    vault.ensure_ready()
    return VaultUnlockResponse(status="ok", message="Vault ready")


@router.get("/vault/status", response_model=VaultStatusResponse)
async def vault_status() -> VaultStatusResponse:
    """Check vault status (always unlocked after first access)."""
    from core.vault.store import vault
    vault.ensure_ready()
    return VaultStatusResponse(unlocked=vault.is_unlocked)


@router.get("/vault/stats", response_model=VaultStatsResponse)
async def vault_stats() -> VaultStatsResponse:
    """Get vault statistics."""
    from core.vault.store import vault
    vault.ensure_ready()
    stats = await asyncio.to_thread(vault.get_stats)
    return VaultStatsResponse(**stats)


@router.get("/vault/tokens")
async def list_vault_tokens(
    source_document: str | None = None,
    offset: int = 0,
    limit: int = 200,
) -> dict[str, Any]:
    """List tokens in the vault with pagination."""
    from core.vault.store import vault
    vault.ensure_ready()
    if limit > 1000:
        limit = 1000
    tokens = await asyncio.to_thread(vault.list_tokens, source_document=source_document)
    total = len(tokens)
    page = tokens[offset : offset + limit]
    return {
        "total": total,
        "offset": offset,
        "limit": limit,
        "tokens": [t.model_dump(mode="json") for t in page],
    }


@router.post("/vault/export")
async def export_vault() -> JSONResponse:
    """Export all vault tokens as JSON."""
    from core.vault.store import vault
    vault.ensure_ready()
    try:
        data = vault.export_vault()
        return JSONResponse(content={"export": data})
    except Exception as e:
        logger.error("Vault export failed: %s", e, exc_info=True)
        raise HTTPException(500, "Export failed. Check server logs for details.")


class _VaultImportBody(_PydanticBaseModel):
    export_data: str


@router.post("/vault/import")
async def import_vault(body: _VaultImportBody) -> JSONResponse:
    """Import tokens from a vault backup JSON."""
    from core.vault.store import vault
    vault.ensure_ready()
    try:
        result = vault.import_vault(body.export_data)
        return JSONResponse(content=result)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(500, "Import failed. Check server logs for details.")


# -----------------------------------------------------------------------
# Token CRUD
# -----------------------------------------------------------------------


class _UpdateTokenBody(_PydanticBaseModel):
    original_text: str | None = None
    pii_type: str | None = None


@router.put("/vault/tokens/{token_id}")
async def update_token(token_id: str, body: _UpdateTokenBody) -> dict[str, Any]:
    """Update a single token's editable fields."""
    from core.vault.store import vault
    vault.ensure_ready()
    updated = await asyncio.to_thread(vault.update_token, token_id, body.original_text, body.pii_type)
    if not updated:
        raise HTTPException(404, "Token not found")
    return {"status": "ok"}


@router.delete("/vault/tokens/{token_id}")
async def delete_token(token_id: str) -> dict[str, str]:
    """Delete a single token by ID."""
    from core.vault.store import vault
    vault.ensure_ready()
    deleted = await asyncio.to_thread(vault.delete_token, token_id)
    if not deleted:
        raise HTTPException(404, "Token not found")
    return {"status": "ok"}


class _BatchDeleteBody(_PydanticBaseModel):
    token_ids: list[str]


@router.post("/vault/tokens/batch-delete")
async def batch_delete_tokens(body: _BatchDeleteBody) -> dict[str, Any]:
    """Delete multiple tokens by ID."""
    from core.vault.store import vault
    vault.ensure_ready()
    if not body.token_ids:
        raise HTTPException(400, "No token IDs provided")
    if len(body.token_ids) > 5000:
        raise HTTPException(400, "Too many IDs (max 5000)")
    deleted = await asyncio.to_thread(vault.delete_tokens, body.token_ids)
    return {"status": "ok", "deleted": deleted}


# -----------------------------------------------------------------------
# AI Prompt generation
# -----------------------------------------------------------------------

class _AiPromptRequest(_PydanticBaseModel):
    doc_ids: list[str] = []
    language: str | None = None  # explicit override; None / "auto" = detect


class _AiPromptResponse(_PydanticBaseModel):
    prompt: str
    prefixes: dict[str, str]  # e.g. {"P": "Person name", "O": "Organization"}


# ── Prompt text translations (7 supported locales) ──────────────────────
# All characters stay within Latin-1 / WinAnsiEncoding so that PyMuPDF
# built-in fonts (helv, cour) can render them without replacement glyphs.

_PROMPT_I18N: dict[str, dict] = {
    "en": {
        "title": "PromptShield - AI Instructions",
        "intro": (
            "This document has been anonymized with PromptShield. "
            "Personal and sensitive information has been replaced with "
            "tokens in the format [XYYYYY], where X is a letter prefix "
            "indicating the type of information that was redacted, and "
            "Y are uppercase letters and digits. Token length matches "
            "the original text length."
        ),
        "legend_header": "Token legend:",
        "footer": (
            "Tokens with the same code (e.g. [PHKR92]) refer to the same "
            "entity throughout the document(s). Please preserve the tokens "
            "as-is in your response so that the original information can "
            "be restored later."
        ),
        "consistency": (
            "Note: Some detected entities in this document were intentionally "
            "left un-anonymized by the user. If you encounter what appears "
            "to be a real person name, organization, address, or other "
            "sensitive information alongside the tokens above, treat it as "
            "a deliberate choice. Do NOT invent new tokens or anonymize it "
            "yourself. Refer to un-tokenized entities exactly as they appear "
            "in the text."
        ),
        "labels": {
            "P": "Person name", "O": "Organization", "E": "Email address",
            "T": "Phone number", "S": "Social Security Number",
            "C": "Credit card number", "D": "Date", "A": "Address",
            "L": "Location", "I": "IP address", "B": "IBAN",
            "X": "Passport number", "R": "Driver license",
            "K": "Custom identifier", "U": "Unknown PII",
        },
    },
    "fr": {
        "title": "PromptShield - Instructions IA",
        "intro": (
            "Ce document a \u00e9t\u00e9 anonymis\u00e9 avec PromptShield. "
            "Les informations personnelles et sensibles ont \u00e9t\u00e9 "
            "remplac\u00e9es par des jetons au format [XYYYYY], o\u00f9 X "
            "est une lettre indiquant le type d'information masqu\u00e9e "
            "et Y sont des lettres majuscules et des chiffres. La longueur "
            "du jeton correspond \u00e0 la longueur du texte original."
        ),
        "legend_header": "L\u00e9gende des jetons :",
        "footer": (
            "Les jetons identiques (ex. [PHKR92]) d\u00e9signent la m\u00eame "
            "entit\u00e9 dans l'ensemble du ou des documents. Veuillez "
            "conserver les jetons tels quels dans votre r\u00e9ponse afin que "
            "les informations d'origine puissent \u00eatre restaur\u00e9es "
            "ult\u00e9rieurement."
        ),
        "consistency": (
            "Note : Certaines entit\u00e9s d\u00e9tect\u00e9es dans ce document "
            "ont \u00e9t\u00e9 volontairement laiss\u00e9es non anonymis\u00e9es "
            "par l'utilisateur. Si vous rencontrez ce qui semble \u00eatre un "
            "vrai nom de personne, une organisation, une adresse ou d'autres "
            "informations sensibles \u00e0 c\u00f4t\u00e9 des jetons ci-dessus, "
            "traitez-le comme un choix d\u00e9lib\u00e9r\u00e9. N'inventez PAS "
            "de nouveaux jetons et ne l'anonymisez pas vous-m\u00eame. "
            "R\u00e9f\u00e9rez-vous aux entit\u00e9s non anonymis\u00e9es "
            "exactement telles qu'elles apparaissent dans le texte."
        ),
        "labels": {
            "P": "Nom de personne", "O": "Organisation",
            "E": "Adresse e-mail", "T": "Num\u00e9ro de t\u00e9l\u00e9phone",
            "S": "Num\u00e9ro de s\u00e9curit\u00e9 sociale",
            "C": "Num\u00e9ro de carte de cr\u00e9dit", "D": "Date",
            "A": "Adresse", "L": "Lieu", "I": "Adresse IP", "B": "IBAN",
            "X": "Num\u00e9ro de passeport", "R": "Permis de conduire",
            "K": "Identifiant personnalis\u00e9", "U": "PII inconnue",
        },
    },
    "de": {
        "title": "PromptShield - KI-Anweisungen",
        "intro": (
            "Dieses Dokument wurde mit PromptShield anonymisiert. "
            "Pers\u00f6nliche und sensible Informationen wurden durch "
            "Tokens im Format [XYYYYY] ersetzt, wobei X ein Buchstabe ist, "
            "der die Art der geschw\u00e4rzten Information angibt, und "
            "Y Grossbuchstaben und Ziffern sind. Die Tokenl\u00e4nge "
            "entspricht der Originaltextl\u00e4nge."
        ),
        "legend_header": "Token-Legende:",
        "footer": (
            "Tokens mit demselben Code (z.B. [PHKR92]) bezeichnen dieselbe "
            "Entit\u00e4t im gesamten Dokument bzw. in allen Dokumenten. "
            "Bitte bewahren Sie die Tokens unver\u00e4ndert in Ihrer Antwort, "
            "damit die urspr\u00fcnglichen Informationen sp\u00e4ter "
            "wiederhergestellt werden k\u00f6nnen."
        ),
        "consistency": (
            "Hinweis: Einige erkannte Entit\u00e4ten in diesem Dokument wurden "
            "vom Benutzer absichtlich nicht anonymisiert. Wenn Sie auf echte "
            "Personennamen, Organisationen, Adressen oder andere sensible "
            "Informationen neben den oben genannten Tokens stossen, behandeln "
            "Sie dies als bewusste Entscheidung. Erfinden Sie KEINE neuen "
            "Tokens und anonymisieren Sie diese nicht selbst. Verwenden Sie "
            "nicht anonymisierte Entit\u00e4ten genau so, wie sie im Text "
            "erscheinen."
        ),
        "labels": {
            "P": "Personenname", "O": "Organisation",
            "E": "E-Mail-Adresse", "T": "Telefonnummer",
            "S": "Sozialversicherungsnummer", "C": "Kreditkartennummer",
            "D": "Datum", "A": "Adresse", "L": "Ort", "I": "IP-Adresse",
            "B": "IBAN", "X": "Passnummer",
            "R": "F\u00fchrerschein",
            "K": "Benutzerdefinierte Kennung", "U": "Unbekannte PII",
        },
    },
    "es": {
        "title": "PromptShield - Instrucciones de IA",
        "intro": (
            "Este documento ha sido anonimizado con PromptShield. "
            "La informaci\u00f3n personal y sensible ha sido reemplazada "
            "por tokens en el formato [XYYYYY], donde X es una letra que "
            "indica el tipo de informaci\u00f3n redactada y Y son letras "
            "may\u00fasculas y d\u00edgitos. La longitud del token coincide "
            "con la del texto original."
        ),
        "legend_header": "Leyenda de tokens:",
        "footer": (
            "Los tokens con el mismo c\u00f3digo (p. ej. [PHKR92]) se "
            "refieren a la misma entidad en todo el documento o documentos. "
            "Conserve los tokens tal cual en su respuesta para que la "
            "informaci\u00f3n original pueda ser restaurada posteriormente."
        ),
        "consistency": (
            "Nota: Algunas entidades detectadas en este documento fueron "
            "dejadas sin anonimizar intencionalmente por el usuario. Si "
            "encuentra lo que parece ser un nombre real de persona, "
            "organizaci\u00f3n, direcci\u00f3n u otra informaci\u00f3n "
            "sensible junto a los tokens anteriores, tr\u00e1telo como una "
            "elecci\u00f3n deliberada. NO invente nuevos tokens ni lo "
            "anonimice usted mismo. Ref\u00ed\u00e9rase a las entidades no "
            "anonimizadas exactamente como aparecen en el texto."
        ),
        "labels": {
            "P": "Nombre de persona", "O": "Organizaci\u00f3n",
            "E": "Direcci\u00f3n de correo electr\u00f3nico",
            "T": "N\u00famero de tel\u00e9fono",
            "S": "N\u00famero de seguridad social",
            "C": "N\u00famero de tarjeta de cr\u00e9dito", "D": "Fecha",
            "A": "Direcci\u00f3n", "L": "Ubicaci\u00f3n",
            "I": "Direcci\u00f3n IP", "B": "IBAN",
            "X": "N\u00famero de pasaporte",
            "R": "Licencia de conducir",
            "K": "Identificador personalizado", "U": "PII desconocida",
        },
    },
    "it": {
        "title": "PromptShield - Istruzioni IA",
        "intro": (
            "Questo documento \u00e8 stato anonimizzato con PromptShield. "
            "Le informazioni personali e sensibili sono state sostituite "
            "con token nel formato [XYYYYY], dove X \u00e8 una lettera che "
            "indica il tipo di informazione oscurata e Y sono lettere "
            "maiuscole e cifre. La lunghezza del token corrisponde a "
            "quella del testo originale."
        ),
        "legend_header": "Legenda dei token:",
        "footer": (
            "I token con lo stesso codice (es. [PHKR92]) si riferiscono "
            "alla stessa entit\u00e0 in tutto il documento o i documenti. "
            "Si prega di conservare i token cos\u00ec come sono nella "
            "risposta, in modo che le informazioni originali possano essere "
            "ripristinate in seguito."
        ),
        "consistency": (
            "Nota: Alcune entit\u00e0 rilevate in questo documento sono state "
            "intenzionalmente lasciate non anonimizzate dall'utente. Se "
            "incontri quello che sembra essere un vero nome di persona, "
            "organizzazione, indirizzo o altre informazioni sensibili "
            "accanto ai token sopra indicati, trattalo come una scelta "
            "deliberata. NON inventare nuovi token e non anonimizzarli "
            "tu stesso. Fai riferimento alle entit\u00e0 non anonimizzate "
            "esattamente come appaiono nel testo."
        ),
        "labels": {
            "P": "Nome di persona", "O": "Organizzazione",
            "E": "Indirizzo e-mail", "T": "Numero di telefono",
            "S": "Codice fiscale", "C": "Numero di carta di credito",
            "D": "Data", "A": "Indirizzo", "L": "Localit\u00e0",
            "I": "Indirizzo IP", "B": "IBAN",
            "X": "Numero di passaporto", "R": "Patente di guida",
            "K": "Identificatore personalizzato", "U": "PII sconosciuta",
        },
    },
    "pt": {
        "title": "PromptShield - Instru\u00e7\u00f5es de IA",
        "intro": (
            "Este documento foi anonimizado com PromptShield. "
            "As informa\u00e7\u00f5es pessoais e sens\u00edveis foram "
            "substitu\u00eddas por tokens no formato [XYYYYY], onde X "
            "\u00e9 uma letra que indica o tipo de informa\u00e7\u00e3o "
            "ocultada e Y s\u00e3o letras mai\u00fasculas e algarismos. "
            "O comprimento do token corresponde ao do texto original."
        ),
        "legend_header": "Legenda dos tokens:",
        "footer": (
            "Tokens com o mesmo c\u00f3digo (ex. [PHKR92]) referem-se "
            "\u00e0 mesma entidade em todo o documento ou documentos. "
            "Preserve os tokens tal como est\u00e3o na sua resposta para "
            "que as informa\u00e7\u00f5es originais possam ser restauradas "
            "posteriormente."
        ),
        "consistency": (
            "Nota: Algumas entidades detetadas neste documento foram "
            "intencionalmente deixadas sem anonimizar pelo utilizador. Se "
            "encontrar o que parece ser um nome real de pessoa, "
            "organiza\u00e7\u00e3o, endere\u00e7o ou outras "
            "informa\u00e7\u00f5es sens\u00edveis junto aos tokens acima, "
            "trate isso como uma escolha deliberada. N\u00c3O invente "
            "novos tokens nem os anonimize. Refira-se \u00e0s entidades "
            "n\u00e3o anonimizadas exatamente como aparecem no texto."
        ),
        "labels": {
            "P": "Nome de pessoa", "O": "Organiza\u00e7\u00e3o",
            "E": "Endere\u00e7o de e-mail",
            "T": "N\u00famero de telefone",
            "S": "N\u00famero de seguran\u00e7a social",
            "C": "N\u00famero de cart\u00e3o de cr\u00e9dito", "D": "Data",
            "A": "Endere\u00e7o", "L": "Localiza\u00e7\u00e3o",
            "I": "Endere\u00e7o IP", "B": "IBAN",
            "X": "N\u00famero de passaporte",
            "R": "Carta de condu\u00e7\u00e3o",
            "K": "Identificador personalizado", "U": "PII desconhecida",
        },
    },
    "nl": {
        "title": "PromptShield - AI-instructies",
        "intro": (
            "Dit document is geanonimiseerd met PromptShield. "
            "Persoonlijke en gevoelige informatie is vervangen door "
            "tokens in het formaat [XYYYYY], waarbij X een letter is "
            "die het type verborgen informatie aangeeft en Y "
            "hoofdletters en cijfers zijn. De tokenlengte komt overeen "
            "met de lengte van de oorspronkelijke tekst."
        ),
        "legend_header": "Tokenlegende:",
        "footer": (
            "Tokens met dezelfde code (bijv. [PHKR92]) verwijzen naar "
            "dezelfde entiteit in het gehele document of de documenten. "
            "Bewaar de tokens ongewijzigd in uw antwoord, zodat de "
            "oorspronkelijke informatie later kan worden hersteld."
        ),
        "consistency": (
            "Let op: Sommige gedetecteerde entiteiten in dit document zijn "
            "opzettelijk niet geanonimiseerd door de gebruiker. Als u "
            "echte persoonsnamen, organisaties, adressen of andere "
            "gevoelige informatie tegenkomt naast de bovenstaande tokens, "
            "behandel dit dan als een bewuste keuze. Verzin GEEN nieuwe "
            "tokens en anonimiseer ze niet zelf. Verwijs naar niet-"
            "geanonimiseerde entiteiten precies zoals ze in de tekst "
            "verschijnen."
        ),
        "labels": {
            "P": "Persoonsnaam", "O": "Organisatie",
            "E": "E-mailadres", "T": "Telefoonnummer",
            "S": "Burgerservicenummer", "C": "Creditcardnummer",
            "D": "Datum", "A": "Adres", "L": "Locatie",
            "I": "IP-adres", "B": "IBAN", "X": "Paspoortnummer",
            "R": "Rijbewijs", "K": "Aangepaste identificatie",
            "U": "Onbekende PII",
        },
    },
}


def _build_ai_prompt(
    prefixes: dict[str, str],
    locale: str = "en",
    has_dismissed: bool = False,
) -> str:
    """Build a compact AI-readable prompt explaining used token prefixes.

    *locale* selects the translation for all human-readable text.
    Falls back to English for unsupported locale codes.
    When *has_dismissed* is True an extra paragraph tells the AI not to
    invent tokens for entities the user intentionally left un-anonymized.
    """
    if not prefixes:
        return ""
    t = _PROMPT_I18N.get(locale, _PROMPT_I18N["en"])
    labels = t["labels"]
    lines = [t["intro"], "", t["legend_header"]]
    for letter in prefixes:
        label = labels.get(letter, prefixes[letter])
        lines.append(f"  [{letter}...] = {label}")
    lines.append("")
    lines.append(t["footer"])
    if has_dismissed:
        lines.append("")
        lines.append(t.get("consistency", _PROMPT_I18N["en"]["consistency"]))
    return "\n".join(lines)


@router.post("/vault/ai-prompt", response_model=_AiPromptResponse)
async def generate_ai_prompt(body: _AiPromptRequest) -> _AiPromptResponse:
    """Generate an AI-ready prompt explaining the token prefixes used in
    the selected documents (and all their linked peers)."""
    from core.vault.store import vault
    from api.deps import documents as doc_dict

    vault.ensure_ready()

    # Collect source_document filenames for requested doc_ids
    # Also resolve linked documents via group_id
    source_filenames: set[str] = set()
    seen_groups: set[str] = set()
    has_dismissed = False

    for doc_id in body.doc_ids:
        doc = doc_dict.get(doc_id)
        if not doc:
            continue
        source_filenames.add(doc.original_filename)
        if not has_dismissed and any(
            r.action == RegionAction.CANCEL for r in doc.regions
        ):
            has_dismissed = True
        if doc.group_id and doc.group_id not in seen_groups:
            seen_groups.add(doc.group_id)
            # Include all documents sharing the same group_id
            for other in doc_dict.values():
                if other.group_id == doc.group_id:
                    source_filenames.add(other.original_filename)

    prefixes = await asyncio.to_thread(
        vault.get_used_prefixes,
        source_documents=list(source_filenames) if source_filenames else None,
    )

    # Use explicit language override, or auto-detect from document text
    if body.language and body.language != "auto":
        doc_lang = body.language
    else:
        from core.detection.language import detect_language
        doc_lang = "en"
        for doc_id in body.doc_ids:
            doc = doc_dict.get(doc_id)
            if doc and doc.pages:
                all_text = " ".join(
                    p.full_text for p in doc.pages if p.full_text
                )
                if all_text:
                    doc_lang = detect_language(all_text)
                    break

    prompt = _build_ai_prompt(prefixes, locale=doc_lang, has_dismissed=has_dismissed)
    return _AiPromptResponse(prompt=prompt, prefixes=prefixes)
