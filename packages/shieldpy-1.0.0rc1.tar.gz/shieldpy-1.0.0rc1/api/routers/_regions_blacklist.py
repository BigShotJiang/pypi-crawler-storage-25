"""Blacklist logic — batch text search across pages to create/flag regions.

Split from ``regions.py`` to keep the router under ~760 LOC.  The public
entry point is ``_blacklist_impl``; route wiring stays in ``regions.py``.

Deduplication
~~~~~~~~~~~~~
Newly created blacklist regions are checked against the per-page
``existing_spans`` set (bbox + text) to avoid creating duplicates when the
same term appears in an already-detected region.
"""

from __future__ import annotations

import logging
import unicodedata
import uuid
from typing import Any, Optional

from fastapi import HTTPException
from pydantic import BaseModel as _PydanticBaseModel

from models.schemas import (
    BBox,
    DetectionSource,
    PIIRegion,
    PIIType,
    RegionAction,
)
from api.deps import get_doc, save_doc
from api.routers._regions_helpers import _OVERLAP_COVERAGE_THRESHOLD

logger = logging.getLogger(__name__)


class BlacklistRequest(_PydanticBaseModel):
    terms: list[str]
    action: str = "none"        # "none" | "tokenize" | "remove"
    page_number: Optional[int] = None  # None = all pages


def _blacklist_impl(doc_id: str, req: BlacklistRequest) -> dict[str, Any]:
    """Core implementation of the blacklist feature."""
    doc = get_doc(doc_id)

    action_map = {
        "tokenize": RegionAction.TOKENIZE,
        "remove": RegionAction.REMOVE,
    }
    target_action: RegionAction | None = action_map.get(req.action)

    pages_to_scan = doc.pages
    if req.page_number is not None:
        pages_to_scan = [p for p in doc.pages if p.page_number == req.page_number]
        if not pages_to_scan:
            raise HTTPException(404, f"Page {req.page_number} not found")

    seen: set[str] = set()
    terms: list[str] = []
    for t in req.terms:
        t_clean = t.strip()
        t_lower = t_clean.lower()
        if t_clean and t_lower not in seen:
            seen.add(t_lower)
            terms.append(t_clean)

    if not terms:
        return {"created": 0, "flagged": 0, "regions": []}

    existing_spans: dict[int, list[tuple[float, float, float, float, str, str]]] = {}
    for r in doc.regions:
        if r.action == RegionAction.CANCEL:
            continue
        existing_spans.setdefault(r.page_number, []).append(
            (r.bbox.x0, r.bbox.y0, r.bbox.x1, r.bbox.y1,
             r.text.strip().lower(), r.id)
        )

    from core.detection.pipeline import _compute_block_offsets

    created_regions: list[PIIRegion] = []
    flagged_ids: set[str] = set()

    for page in pages_to_scan:
        full_text = page.full_text
        if not full_text:
            continue

        block_offsets = _compute_block_offsets(page.text_blocks, full_text)

        _nfd = unicodedata.normalize("NFD", full_text.lower())
        _norm_chars: list[str] = []
        _n2o: list[int] = []
        _seen = 0
        for ci in range(len(full_text)):
            clen = len(unicodedata.normalize("NFD", full_text[ci]))
            for _ in range(clen):
                if _seen < len(_nfd) and unicodedata.category(_nfd[_seen]) != "Mn":
                    _norm_chars.append(_nfd[_seen])
                    _n2o.append(ci)
                _seen += 1
        _n2o.append(len(full_text))  # sentinel
        full_norm = "".join(_norm_chars)

        for needle in terms:
            needle_norm = "".join(
                ch for ch in unicodedata.normalize("NFD", needle.lower())
                if unicodedata.category(ch) != "Mn"
            )
            needle_len = len(needle_norm)
            if needle_len == 0:
                continue

            search_start = 0
            while True:
                ni = full_norm.find(needle_norm, search_start)
                if ni == -1:
                    break
                search_start = ni + 1
                idx = _n2o[ni]
                match_end = _n2o[min(ni + needle_len, len(_n2o) - 1)]

                hit_blocks = []
                for cs, ce, blk in block_offsets:
                    if ce <= idx:
                        continue
                    if cs >= match_end:
                        break
                    hit_blocks.append(blk)

                if not hit_blocks:
                    continue

                bx0 = min(b.bbox.x0 for b in hit_blocks)
                by0 = min(b.bbox.y0 for b in hit_blocks)
                bx1 = max(b.bbox.x1 for b in hit_blocks)
                by1 = max(b.bbox.y1 for b in hit_blocks)

                bx0 = max(0.0, min(bx0, page.width))
                by0 = max(0.0, min(by0, page.height))
                bx1 = max(0.0, min(bx1, page.width))
                by1 = max(0.0, min(by1, page.height))

                page_existing = existing_spans.get(page.page_number, [])
                covered_region_id: str | None = None
                for ex0, ey0, ex1, ey1, _etxt, eid in page_existing:
                    ix0 = max(bx0, ex0)
                    iy0 = max(by0, ey0)
                    ix1 = min(bx1, ex1)
                    iy1 = min(by1, ey1)
                    if ix0 < ix1 and iy0 < iy1:
                        inter_area = (ix1 - ix0) * (iy1 - iy0)
                        new_area = max((bx1 - bx0) * (by1 - by0), 1e-6)
                        if inter_area / new_area > _OVERLAP_COVERAGE_THRESHOLD:
                            covered_region_id = eid
                            break

                if covered_region_id:
                    if target_action and covered_region_id not in flagged_ids:
                        for r in doc.regions:
                            if r.id == covered_region_id:
                                r.action = target_action
                                flagged_ids.add(r.id)
                                break
                    continue

                matched_text = full_text[idx:match_end]
                region = PIIRegion(
                    page_number=page.page_number,
                    bbox=BBox(x0=round(bx0, 2), y0=round(by0, 2),
                              x1=round(bx1, 2), y1=round(by1, 2)),
                    text=matched_text,
                    pii_type=PIIType.CUSTOM,
                    confidence=1.0,
                    source=DetectionSource.MANUAL,
                    action=target_action if target_action else RegionAction.PENDING,
                    char_start=idx,
                    char_end=match_end,
                )
                region.id = uuid.uuid4().hex[:12]
                created_regions.append(region)
                doc.regions.append(region)
                needle_lower = needle.lower()
                existing_spans.setdefault(page.page_number, []).append(
                    (bx0, by0, bx1, by1, needle_lower, region.id)
                )

    save_doc(doc)

    return {
        "created": len(created_regions),
        "flagged": len(flagged_ids),
        "regions": [r.model_dump(mode="json") for r in doc.regions],
    }
