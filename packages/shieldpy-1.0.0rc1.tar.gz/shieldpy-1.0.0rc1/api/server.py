"""FastAPI application — main API for the promptShield sidecar."""

from __future__ import annotations

import logging
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from core.config import config
from core.persistence import DocumentStore
from models.schemas import DocumentStatus
from api import deps
from api.rate_limit import RateLimitMiddleware
from api.csrf import CSRFMiddleware
from api.license_guard import LicenseGuardMiddleware, start_license_watchdog
from api.api_key_guard import ApiKeyGuardMiddleware, set_api_key_scopes

# NOTE: Router imports are deferred to run_startup() to speed up the
# two-phase boot.  Importing all 9 routers at module level forces
# Pydantic model compilation for ~60 schemas during the background
# init thread, adding 2-3 s in frozen (PyInstaller) mode.

logger = logging.getLogger(__name__)

# L1: Single source of truth for the app version — read from pyproject.toml
# via importlib.metadata at runtime.
try:
    from importlib.metadata import version as _meta_version
    _VERSION = _meta_version("shieldpy")
except Exception:
    _VERSION = "1.0.0-rc.1"

# ── Sentry crash reporting (optional) ────────────────────────────────────
# Set SENTRY_DSN env var to enable. When unset, Sentry is a no-op.
_SENTRY_DSN = os.environ.get("SENTRY_DSN", "")
if _SENTRY_DSN:
    try:
        import sentry_sdk
        sentry_sdk.init(
            dsn=_SENTRY_DSN,
            release=f"promptshield-sidecar@{_VERSION}",
            environment=os.environ.get("SENTRY_ENVIRONMENT", "production"),
            traces_sample_rate=0.1,
            send_default_pii=False,
            # Integrate with FastAPI automatically
            integrations=[],
            auto_enabling_integrations=True,
        )
        logger.info("Sentry crash reporting initialized")
    except ImportError:
        logger.warning("sentry-sdk not installed — crash reporting disabled")
    except Exception as e:
        logger.warning("Failed to initialize Sentry: %s", e)


# ---------------------------------------------------------------------------
# Startup / shutdown helpers — called from lifespan (dev) or BootApp (frozen)
# ---------------------------------------------------------------------------

_startup_done = False


def _register_routers(app: FastAPI) -> None:
    """Import and register all API routers.

    Deferred from module level so the heavy Pydantic model compilation
    across all router schemas happens here (inside run_startup) rather
    than during ``from api.server import app``.
    """
    from api.routers import (
        documents,
        detection,
        regions,
        anonymize,
        detokenize,
        vault,
        llm,
        settings,
        shell,
    )
    app.include_router(documents.router)
    app.include_router(detection.router)
    app.include_router(regions.router)
    app.include_router(anonymize.router)
    app.include_router(detokenize.router)
    app.include_router(vault.router)
    app.include_router(llm.router)
    app.include_router(settings.router)
    app.include_router(shell.router)

    # Mount bundled SPA AFTER routers so the catch-all doesn't shadow API routes
    _mount_frontend(app)


def run_startup(app: FastAPI) -> None:
    """Initialise document store, bitmap mounts, license watchdog, LLM.

    This is plain synchronous code extracted from the async lifespan so it
    can also be called from the BootApp background-init thread in frozen
    mode (two-phase startup).
    """
    global _startup_done
    if _startup_done:
        return
    import time as _t
    t0 = _t.perf_counter()
    logger.info("Starting promptShield sidecar...")

    # Register routers (deferred from module level for faster boot)
    _register_routers(app)
    t_routers = _t.perf_counter()
    logger.info("[STARTUP] Router registration: %.0fms", (t_routers-t0)*1000)

    # Start the license watchdog FIRST — if no valid license, exit immediately
    start_license_watchdog()
    t1 = _t.perf_counter()
    logger.info("[STARTUP] License watchdog: %.0fms", (t1-t_routers)*1000)

    # Initialize document store
    storage_dir = config.data_dir / "storage"
    deps.store = DocumentStore(storage_dir)

    # Register document IDs for lazy loading — only reads filenames,
    # no JSON parsing or Pydantic validation.  Documents are loaded
    # on first access, so the server starts accepting requests immediately.
    try:
        doc_ids = deps.store.list_documents()
        deps.documents.register_ids(doc_ids, deps.store)
        logger.info("Registered %s documents for lazy loading", len(doc_ids))
    except Exception as e:
        logger.error("Failed to list documents: %s", e)

    t2 = _t.perf_counter()
    logger.info("[STARTUP] Document store + registration: %.0fms", (t2-t1)*1000)

    # Region sanitization is now handled lazily — each document's regions
    # are sanitized on first access in LazyDocumentDict._load_one().

    # Mount temp dir for serving page bitmaps (legacy support)
    config.temp_dir.mkdir(parents=True, exist_ok=True)
    app.mount(
        "/bitmaps",
        StaticFiles(directory=str(config.temp_dir)),
        name="bitmaps",
    )

    # Also mount persistent storage bitmaps
    app.mount(
        "/storage-bitmaps",
        StaticFiles(directory=str(deps.store.bitmaps_dir)),
        name="storage-bitmaps",
    )
    logger.info("Serving bitmaps from %s (temp) and %s (persistent)", config.temp_dir, deps.store.bitmaps_dir)

    t3 = _t.perf_counter()
    logger.info("[STARTUP] Bitmap mounts: %.0fms", (t3-t2)*1000)

    total = (_t.perf_counter() - t0) * 1000
    logger.info("[STARTUP] Total lifespan init: %.0fms — server ready", total)
    _startup_done = True


def run_shutdown() -> None:
    """Clean up resources — vault connection + temp directory."""
    logger.info("Shutting down promptShield sidecar...")

    # Close the vault SQLite connection
    try:
        from core.vault.store import vault
        vault.close()
        logger.info("Vault connection closed")
    except Exception as e:
        logger.warning("Failed to close vault: %s", e)

    # Clean up temp directory (stale bitmaps, output files)
    try:
        import shutil
        if config.temp_dir.exists():
            shutil.rmtree(config.temp_dir, ignore_errors=True)
            logger.info("Cleaned temp directory: %s", config.temp_dir)
    except Exception as e:
        logger.warning("Failed to clean temp dir: %s", e)


# ---------------------------------------------------------------------------
# Lifecycle — used in dev mode (uvicorn.run with string import)
# In frozen mode, run_startup/run_shutdown are called directly by BootApp.
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Application startup → yield → shutdown."""
    run_startup(app)
    yield
    run_shutdown()


app = FastAPI(
    title="promptShield",
    version=_VERSION,
    description="Offline document anonymizer with local LLM — promptShield",
    lifespan=lifespan,
)

# Middleware stack — order matters!
# Starlette's add_middleware() wraps the app, so the LAST call is the
# OUTERMOST middleware.  We need CORS outermost so it can:
#   1. Handle OPTIONS preflight before any other middleware sees it.
#   2. Add Access-Control-Allow-Origin to ALL responses, including
#      error responses from inner middleware (403 from LicenseGuard,
#      403 from CSRF, 429 from RateLimit).  Without this, the browser
#      sees a cross-origin response without CORS headers and throws
#      "Failed to fetch" — even if the sidecar returned a valid error.
#
# Execution order (outermost → innermost):
#   CORS → LicenseGuard → ApiKeyGuard → CSRF → RateLimit → App

_ALLOWED_ORIGINS = [
    "http://localhost:1420",
    "http://127.0.0.1:1420",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
    "tauri://localhost",          # macOS Tauri 2 webview origin
    "https://tauri.localhost",    # Windows/Linux Tauri 2 webview origin
]

# Docker / self-hosted: allow custom origins via PROMPTSHIELD_CORS_ORIGINS
# Comma-separated list, e.g. "https://app.example.com,http://localhost:3000"
_extra_origins = os.environ.get("PROMPTSHIELD_CORS_ORIGINS", "")
if _extra_origins:
    for origin in _extra_origins.split(","):
        origin = origin.strip()
        if origin and origin not in _ALLOWED_ORIGINS:
            _ALLOWED_ORIGINS.append(origin)

# 1st add_middleware → innermost
app.add_middleware(RateLimitMiddleware)

# 2nd — CSRF protection (require X-Requested-With on mutating requests)
app.add_middleware(CSRFMiddleware)

# 3rd — API key guard (self-hosted / Docker mode)
# SECURITY: When PROMPTSHIELD_API_KEY is set, require it on every request.
# In Tauri desktop mode this is a no-op (LicenseGuard handles auth).
set_api_key_scopes(os.environ.get("PROMPTSHIELD_API_KEY_SCOPES"))
app.add_middleware(ApiKeyGuardMiddleware)

# 4th — License enforcement (session token + expiry checks)
# SECURITY: This is the sidecar's own license gate — without it the sidecar
# can be extracted and used for free forever.
app.add_middleware(LicenseGuardMiddleware)

# 5th add_middleware → OUTERMOST — CORS must wrap everything so its headers
# appear on every response the browser receives.
app.add_middleware(
    CORSMiddleware,
    allow_origins=_ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-Requested-With", "X-Api-Key"],
)

# ---------------------------------------------------------------------------
# Router registration — deferred to run_startup() for faster two-phase boot.
# See _register_routers() below.
# ---------------------------------------------------------------------------


@app.get("/health")
async def health() -> dict[str, str]:
    """Return a lightweight health-check response."""
    return {"status": "ok", "version": _VERSION}


@app.post("/api/shutdown")
async def shutdown() -> dict[str, str]:
    """Trigger graceful server shutdown.

    Called by the Tauri shell on window close so uvicorn can exit
    cleanly and PyInstaller's atexit handler removes the _MEI temp dir.
    The LicenseGuardMiddleware already validates the session token.
    """
    server = getattr(app.state, "_server", None)
    if server is not None:
        server.should_exit = True
    return {"status": "shutting_down"}


# ---------------------------------------------------------------------------
# Global exception handler — sanitise error responses so internal details
# (stack traces, file paths, SQL errors) never reach the client.
# ---------------------------------------------------------------------------

@app.exception_handler(Exception)
async def _global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Catch unhandled exceptions and return a safe 500 response."""
    logger.error("Unhandled exception on %s %s: %s", request.method, request.url.path, exc, exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error"},
    )


# ---------------------------------------------------------------------------
# Model warmup — preload NLP models in background to eliminate first-request lag
# ---------------------------------------------------------------------------

_warmup_started = False
_warmup_done = False  # Set to True once warmup finishes


def _warmup_models() -> None:
    """Load all NLP models (spaCy, GLiNER, BERT) in a background thread.

    Each loader is guarded by its own try/except so one failure doesn't
    prevent the others from loading.  All loaders are idempotent — if the
    model is already loaded (e.g. from a previous warmup), they return
    instantly.
    """
    global _warmup_done
    import time as _t
    t0 = _t.perf_counter()
    loaded: list[str] = []

    # Eagerly import the pipeline module so first detection avoids import cost
    try:
        import core.detection.pipeline  # noqa: F401
        loaded.append("pipeline-import")
    except Exception as e:
        logger.warning("Warmup: pipeline import failed: %s", e)

    # spaCy English
    try:
        from core.detection.ner_detector import _load_model as load_spacy_en
        load_spacy_en()
        loaded.append("spaCy-en")
    except Exception as e:
        logger.warning("Warmup: spaCy-en failed: %s", e)

    # spaCy French
    try:
        from core.detection.ner_detector import _load_french_model as load_spacy_fr
        load_spacy_fr()
        loaded.append("spaCy-fr")
    except Exception as e:
        logger.warning("Warmup: spaCy-fr failed: %s", e)

    # spaCy Italian
    try:
        from core.detection.ner_detector import _load_italian_model as load_spacy_it
        load_spacy_it()
        loaded.append("spaCy-it")
    except Exception as e:
        logger.warning("Warmup: spaCy-it failed: %s", e)

    # GLiNER
    try:
        from core.detection.gliner_detector import _load_model as load_gliner
        load_gliner()
        loaded.append("GLiNER")
    except Exception as e:
        logger.warning("Warmup: GLiNER failed: %s", e)

    # BERT / Transformer NER (auto-mode default model)
    try:
        from core.detection.bert_detector import is_bert_ner_available, _load_pipeline
        if is_bert_ner_available():
            _load_pipeline()  # loads default model
            loaded.append("BERT")
    except Exception as e:
        logger.warning("Warmup: BERT failed: %s", e)

    elapsed = (_t.perf_counter() - t0) * 1000
    _warmup_done = True
    logger.info("Warmup complete: %s in %.0fms", ', '.join(loaded), elapsed)


@app.post("/api/warmup")
async def warmup() -> dict[str, str]:
    """Trigger background model preload.  Returns immediately."""
    import asyncio
    global _warmup_started
    if _warmup_started:
        return {"status": "already_started"}
    _warmup_started = True
    asyncio.get_running_loop().run_in_executor(None, _warmup_models)
    return {"status": "started"}


# ---------------------------------------------------------------------------
# Bundled frontend — serve the React SPA when running as a standalone exe.
# Mounted inside _register_routers() AFTER API routers so the catch-all
# /{full_path:path} doesn't shadow API routes.
# ---------------------------------------------------------------------------

def _get_frontend_dir() -> Path | None:
    """Locate the bundled frontend dist directory."""
    if getattr(sys, "frozen", False):
        # PyInstaller: data is under sys._MEIPASS
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            candidate = Path(meipass) / "frontend_dist"
            if candidate.is_dir():
                return candidate
        # Nuitka standalone: data dirs sit next to the executable
        candidate = Path(sys.executable).parent / "frontend_dist"
        if candidate.is_dir():
            return candidate
    candidate = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"
    if candidate.is_dir():
        return candidate
    return None


def _mount_frontend(app: FastAPI) -> None:
    """Mount the bundled SPA frontend.

    Must be called AFTER ``include_router()`` so the catch-all
    ``/{full_path:path}`` route doesn't shadow API endpoints.
    """
    frontend_dir = _get_frontend_dir()
    if frontend_dir is None:
        return

    app.mount(
        "/assets",
        StaticFiles(directory=str(frontend_dir / "assets")),
        name="frontend-assets",
    )

    @app.get("/")
    async def serve_index() -> HTMLResponse:
        """Serve the SPA index page."""
        return HTMLResponse((frontend_dir / "index.html").read_text(encoding="utf-8"))

    @app.get("/{full_path:path}", response_model=None)
    async def spa_fallback(full_path: str) -> HTMLResponse | FileResponse:
        if full_path.startswith(("api/", "health", "bitmaps/")):
            raise HTTPException(404)
        file_path = (frontend_dir / full_path).resolve()
        # Prevent path traversal — ensure resolved path is within frontend dir
        if not file_path.is_relative_to(frontend_dir.resolve()):
            raise HTTPException(404)
        if file_path.is_file():
            return FileResponse(str(file_path))
        return HTMLResponse((frontend_dir / "index.html").read_text(encoding="utf-8"))
