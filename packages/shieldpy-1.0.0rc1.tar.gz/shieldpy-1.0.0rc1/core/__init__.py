"""PromptShield core package — public SDK surface.

Usage::

    from promptshield import ingest_document, detect_pii_on_page, anonymize_document

All processing is local. No data leaves your machine.
"""

from core.ingestion.loader import ingest_document  # noqa: F401
from core.detection.pipeline import detect_pii_on_page  # noqa: F401
from core.detection.propagation import propagate_regions_across_pages  # noqa: F401
from core.anonymizer.engine import anonymize_document  # noqa: F401
from core.vault.store import TokenRegistry, TokenVault, vault, token_registry  # noqa: F401
from core.detokenize_file import detokenize_file  # noqa: F401
from core.config import config  # noqa: F401

__all__ = [
    "ingest_document",
    "detect_pii_on_page",
    "propagate_regions_across_pages",
    "anonymize_document",
    "detokenize_file",
    "TokenRegistry",
    "TokenVault",
    "vault",
    "token_registry",
    "config",
]
