"""Document format converters — Office to PDF conversion utilities.

Extracted from loader.py for maintainability (M8: modular architecture).
Contains pure conversion functions with no dependencies on loader.py internals.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
from pathlib import Path

logger = logging.getLogger(__name__)

def _libreoffice_convert_to_pdf(src: Path, out_dir: Path) -> Path:
    """Convert an Office document to PDF using LibreOffice headless."""
    lo_cmd = shutil.which("libreoffice") or shutil.which("soffice")
    if lo_cmd is None:
        raise RuntimeError(
            "LibreOffice is required to process Office documents but was not found on PATH. "
            "Install LibreOffice and ensure 'libreoffice' or 'soffice' is available."
        )
    run_kwargs: dict = {
        "check": True,
        "capture_output": True,
        "timeout": 120,
    }
    if sys.platform == "win32":
        run_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
    subprocess.run(
        [lo_cmd, "--headless", "--convert-to", "pdf", "--outdir", str(out_dir), str(src)],
        **run_kwargs,
    )
    pdf_path = out_dir / f"{src.stem}.pdf"
    if not pdf_path.exists():
        raise RuntimeError(f"LibreOffice conversion failed — expected output at {pdf_path}")
    return pdf_path


def _docx_to_pdf(src: Path, out_dir: Path) -> Path:
    """Convert a DOCX file to PDF using python-docx and reportlab.

    This is a pure-Python alternative to LibreOffice for docx files.
    Extracts paragraphs, tables, headers/footers, and renders them into
    a PDF preserving text content and basic formatting for accurate
    text extraction and PII detection.
    """
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    )
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from xml.sax.saxutils import escape

    out_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = out_dir / f"{src.stem}.pdf"

    docx_doc = Document(str(src))

    # ── styles ──────────────────────────────────────────────────────
    styles = getSampleStyleSheet()
    body_style = ParagraphStyle(
        "DocxBody", parent=styles["Normal"],
        fontSize=10, leading=13, spaceAfter=4,
    )
    bold_style = ParagraphStyle(
        "DocxBold", parent=body_style,
        fontName="Helvetica-Bold",
    )
    heading_styles: dict[int, ParagraphStyle] = {}
    for level, (fs, lead) in enumerate(
        [(16, 20), (14, 18), (12, 16), (11, 15), (10, 14)], start=1
    ):
        heading_styles[level] = ParagraphStyle(
            f"DocxH{level}", parent=styles["Normal"],
            fontSize=fs, leading=lead, spaceAfter=6, spaceBefore=8,
            fontName="Helvetica-Bold",
        )
    cell_style = ParagraphStyle(
        "DocxCell", parent=styles["Normal"],
        fontSize=9, leading=11, wordWrap="CJK",
    )

    # ── helper: convert a docx paragraph to reportlab Paragraph ─────
    def _para_to_flowable(para):
        """Return a reportlab Paragraph (or None for empty paragraphs)."""
        text_parts: list[str] = []
        for run in para.runs:
            t = escape(run.text) if run.text else ""
            if not t:
                continue
            # Preserve basic formatting via HTML-like tags
            if run.bold and run.italic:
                t = f"<b><i>{t}</i></b>"
            elif run.bold:
                t = f"<b>{t}</b>"
            elif run.italic:
                t = f"<i>{t}</i>"
            if run.underline:
                t = f"<u>{t}</u>"
            text_parts.append(t)

        full = "".join(text_parts).strip()
        if not full:
            return None

        # Pick style based on heading level
        style_name = para.style.name if para.style else ""
        lvl = 0
        if style_name.startswith("Heading"):
            try:
                lvl = int(style_name.split()[-1])
            except (ValueError, IndexError):
                lvl = 1
        pstyle = heading_styles.get(lvl, body_style)

        # Alignment
        align = para.alignment
        if align == WD_ALIGN_PARAGRAPH.CENTER:
            pstyle = ParagraphStyle(f"_c{id(para)}", parent=pstyle, alignment=1)
        elif align == WD_ALIGN_PARAGRAPH.RIGHT:
            pstyle = ParagraphStyle(f"_r{id(para)}", parent=pstyle, alignment=2)

        return Paragraph(full, pstyle)

    # ── helper: convert a docx table to reportlab Table ─────────────
    def _table_to_flowable(tbl):
        """Return a reportlab Table flowable."""
        data: list[list] = []
        for row in tbl.rows:
            row_data: list = []
            for cell in row.cells:
                cell_text = escape(cell.text.strip()) if cell.text else ""
                if len(cell_text) > 200:
                    cell_text = cell_text[:197] + "..."
                row_data.append(Paragraph(cell_text, cell_style))
            data.append(row_data)
        if not data:
            return None
        ncols = max(len(r) for r in data)
        available = letter[0] - 1 * inch
        col_w = min(available / max(ncols, 1), 2.5 * inch)
        t = Table(data, colWidths=[col_w] * ncols)
        t.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 3),
            ("RIGHTPADDING", (0, 0), (-1, -1), 3),
            ("TOPPADDING", (0, 0), (-1, -1), 2),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
        ]))
        return t

    # ── walk the document body in order ─────────────────────────────
    # python-docx exposes paragraphs and tables as separate lists, but
    # the underlying XML has them interleaved.  Iterate the body XML
    # children to preserve correct ordering.
    from docx.oxml.ns import qn

    elements: list = []

    # Header text (first section only, for PII detection)
    for section in docx_doc.sections:
        for hdr in (section.header,):
            if hdr and not hdr.is_linked_to_previous:
                for p in hdr.paragraphs:
                    fl = _para_to_flowable(p)
                    if fl:
                        elements.append(fl)
        break  # first section headers only

    body = docx_doc.element.body
    for child in body:
        tag = child.tag
        if tag == qn("w:p"):
            # paragraph
            para = None
            for p in docx_doc.paragraphs:
                if p._element is child:
                    para = p
                    break
            if para is None:
                continue
            # Page break detection
            if para.style and para.style.name and "page" in para.style.name.lower():
                elements.append(PageBreak())
            fl = _para_to_flowable(para)
            if fl:
                elements.append(fl)
            else:
                elements.append(Spacer(1, 4))
        elif tag == qn("w:tbl"):
            tbl = None
            for t in docx_doc.tables:
                if t._element is child:
                    tbl = t
                    break
            if tbl:
                fl = _table_to_flowable(tbl)
                if fl:
                    elements.append(Spacer(1, 4))
                    elements.append(fl)
                    elements.append(Spacer(1, 4))
        elif tag == qn("w:sectPr"):
            # Section break — treat as page break
            elements.append(PageBreak())

    # Footer text (first section only)
    for section in docx_doc.sections:
        for ftr in (section.footer,):
            if ftr and not ftr.is_linked_to_previous:
                for p in ftr.paragraphs:
                    fl = _para_to_flowable(p)
                    if fl:
                        elements.append(fl)
        break

    # ── build PDF ───────────────────────────────────────────────────
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=letter,
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
    )

    if not elements:
        elements.append(Paragraph("(Empty document)", styles["Normal"]))

    doc.build(elements)

    if not pdf_path.exists():
        raise RuntimeError(
            f"DOCX to PDF conversion failed — expected output at {pdf_path}"
        )

    logger.info("Converted DOCX to PDF: %s", pdf_path)
    return pdf_path


def _pptx_to_pdf(src: Path, out_dir: Path) -> Path:
    """Convert a PPTX file to PDF using python-pptx and reportlab.

    This is a pure-Python alternative to LibreOffice for pptx files.
    Extracts text from slides, shapes, tables, and speaker notes and
    renders them into a landscape PDF for accurate PII detection.
    """
    from pptx import Presentation
    from pptx.util import Inches
    from reportlab.lib.pagesizes import landscape, letter
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
    )
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from xml.sax.saxutils import escape

    out_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = out_dir / f"{src.stem}.pdf"

    prs = Presentation(str(src))

    styles = getSampleStyleSheet()
    slide_header_style = ParagraphStyle(
        "SlideHeader", parent=styles["Heading2"],
        fontSize=14, spaceAfter=10, spaceBefore=4,
        textColor=colors.HexColor("#333333"),
    )
    body_style = ParagraphStyle(
        "PptxBody", parent=styles["Normal"],
        fontSize=10, leading=13, spaceAfter=4,
    )
    notes_style = ParagraphStyle(
        "PptxNotes", parent=styles["Normal"],
        fontSize=9, leading=12, spaceAfter=4,
        textColor=colors.grey,
        fontName="Helvetica-Oblique",
    )
    table_cell_style = ParagraphStyle(
        "PptxCell", parent=styles["Normal"],
        fontSize=9, leading=11, wordWrap="CJK",
    )

    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=landscape(letter),
        leftMargin=0.5 * inch,
        rightMargin=0.5 * inch,
        topMargin=0.5 * inch,
        bottomMargin=0.5 * inch,
    )

    elements: list = []

    for slide_idx, slide in enumerate(prs.slides, start=1):
        elements.append(
            Paragraph(escape(f"Slide {slide_idx}"), slide_header_style)
        )
        elements.append(Spacer(1, 0.1 * inch))

        for shape in slide.shapes:
            # Text frames (titles, text boxes, placeholders)
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = para.text.strip()
                    if text:
                        elements.append(Paragraph(escape(text), body_style))

            # Tables
            if shape.has_table:
                tbl = shape.table
                table_data = []
                for row in tbl.rows:
                    row_data = []
                    for cell in row.cells:
                        cell_text = cell.text.strip() or ""
                        if len(cell_text) > 200:
                            cell_text = cell_text[:197] + "..."
                        row_data.append(
                            Paragraph(escape(cell_text), table_cell_style)
                        )
                    table_data.append(row_data)

                if table_data:
                    avail = landscape(letter)[0] - 1 * inch
                    ncols = max(len(r) for r in table_data) if table_data else 1
                    col_w = min(avail / ncols, 2.0 * inch)
                    rt = Table(table_data, colWidths=[col_w] * ncols)
                    rt.setStyle(TableStyle([
                        ("FONTSIZE", (0, 0), (-1, -1), 9),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                        ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ("LEFTPADDING", (0, 0), (-1, -1), 3),
                        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                    ]))
                    elements.append(Spacer(1, 0.05 * inch))
                    elements.append(rt)
                    elements.append(Spacer(1, 0.05 * inch))

            # Group shapes — recurse one level
            if hasattr(shape, "shapes"):
                for child in shape.shapes:
                    if child.has_text_frame:
                        for para in child.text_frame.paragraphs:
                            text = para.text.strip()
                            if text:
                                elements.append(
                                    Paragraph(escape(text), body_style)
                                )

        # Speaker notes
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
            notes_text = slide.notes_slide.notes_text_frame.text.strip()
            if notes_text:
                elements.append(Spacer(1, 0.1 * inch))
                elements.append(
                    Paragraph(escape(f"[Notes] {notes_text}"), notes_style)
                )

        # Page break between slides
        if slide_idx < len(prs.slides):
            elements.append(PageBreak())

    if not elements:
        elements.append(Paragraph("(Empty presentation)", styles["Normal"]))

    doc.build(elements)

    if not pdf_path.exists():
        raise RuntimeError(
            f"PPTX to PDF conversion failed — expected output at {pdf_path}"
        )

    logger.info("Converted PPTX to PDF: %s", pdf_path)
    return pdf_path


def _xlsx_to_pdf(src: Path, out_dir: Path) -> Path:
    """Convert an Excel xlsx file to PDF using openpyxl and reportlab.
    
    This is a pure-Python alternative to LibreOffice for xlsx files.
    Creates a PDF with each sheet as a separate page, preserving cell
    content in a tabular layout for accurate text extraction.
    """
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter
    from reportlab.lib.pagesizes import letter, landscape
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    
    out_dir.mkdir(parents=True, exist_ok=True)
    pdf_path = out_dir / f"{src.stem}.pdf"
    
    # Load workbook
    wb = load_workbook(src, data_only=True)  # data_only=True to get calculated values
    
    # Create PDF document with landscape orientation for spreadsheets
    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=landscape(letter),
        leftMargin=0.5*inch,
        rightMargin=0.5*inch,
        topMargin=0.5*inch,
        bottomMargin=0.5*inch,
    )
    
    styles = getSampleStyleSheet()
    # Create a style for cell content that handles wrapping
    cell_style = ParagraphStyle(
        'CellStyle',
        parent=styles['Normal'],
        fontSize=8,
        leading=10,
        wordWrap='CJK',  # Better wrapping for all text
    )
    header_style = ParagraphStyle(
        'HeaderStyle',
        parent=styles['Heading2'],
        fontSize=12,
        spaceAfter=12,
    )
    
    elements = []
    
    for sheet_idx, sheet_name in enumerate(wb.sheetnames):
        ws = wb[sheet_name]
        
        # Add sheet name as header
        elements.append(Paragraph(f"Sheet: {sheet_name}", header_style))
        elements.append(Spacer(1, 0.1*inch))
        
        # Find the used range
        if ws.max_row is None or ws.max_column is None:
            continue
            
        max_row = min(ws.max_row, 500)  # Limit rows to prevent huge PDFs
        max_col = min(ws.max_column, 26)  # Limit columns (A-Z)
        
        if max_row == 0 or max_col == 0:
            elements.append(Paragraph("(Empty sheet)", styles['Normal']))
            if sheet_idx < len(wb.sheetnames) - 1:
                elements.append(PageBreak())
            continue
        
        # Build table data
        table_data = []
        for row_idx in range(1, max_row + 1):
            row_data = []
            for col_idx in range(1, max_col + 1):
                cell = ws.cell(row=row_idx, column=col_idx)
                value = cell.value
                if value is None:
                    value = ""
                elif isinstance(value, (int, float)):
                    # Format numbers nicely
                    if isinstance(value, float) and value == int(value):
                        value = str(int(value))
                    else:
                        value = str(value)
                else:
                    value = str(value)
                # Truncate very long cell values
                if len(value) > 100:
                    value = value[:97] + "..."
                # Wrap text in Paragraph for proper handling
                row_data.append(Paragraph(value, cell_style))
            table_data.append(row_data)
        
        if not table_data:
            elements.append(Paragraph("(Empty sheet)", styles['Normal']))
            if sheet_idx < len(wb.sheetnames) - 1:
                elements.append(PageBreak())
            continue
        
        # Calculate column widths (distribute evenly with max width)
        available_width = landscape(letter)[0] - 1*inch  # Page width minus margins
        col_width = min(available_width / max_col, 1.5*inch)
        col_widths = [col_width] * max_col
        
        # Create table
        table = Table(table_data, colWidths=col_widths, repeatRows=1)
        table.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightgrey),  # Header row
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (0, 0), (-1, -1), 3),
            ('RIGHTPADDING', (0, 0), (-1, -1), 3),
            ('TOPPADDING', (0, 0), (-1, -1), 2),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 2),
        ]))
        
        elements.append(table)
        
        # Add page break between sheets
        if sheet_idx < len(wb.sheetnames) - 1:
            elements.append(PageBreak())
    
    # Build PDF
    if elements:
        doc.build(elements)
    else:
        # Create empty PDF with message
        elements.append(Paragraph("(Empty workbook)", styles['Normal']))
        doc.build(elements)
    
    wb.close()
    
    if not pdf_path.exists():
        raise RuntimeError(f"xlsx to PDF conversion failed — expected output at {pdf_path}")
    
    logger.info("Converted xlsx to PDF: %s", pdf_path)
    return pdf_path


def _xls_to_xlsx(src: Path, out_dir: Path) -> Path:
    """Convert a legacy .xls file to .xlsx using xlrd + openpyxl."""
    import xlrd
    from openpyxl import Workbook

    out_dir.mkdir(parents=True, exist_ok=True)
    xlsx_path = out_dir / f"{src.stem}.xlsx"

    xls_wb = xlrd.open_workbook(str(src), formatting_info=False)
    xlsx_wb = Workbook()
    # Remove the default sheet created by openpyxl
    xlsx_wb.remove(xlsx_wb.active)

    for sheet_idx in range(xls_wb.nsheets):
        xls_ws = xls_wb.sheet_by_index(sheet_idx)
        xlsx_ws = xlsx_wb.create_sheet(title=xls_ws.name)
        for row_idx in range(xls_ws.nrows):
            for col_idx in range(xls_ws.ncols):
                cell_value = xls_ws.cell_value(row_idx, col_idx)
                cell_type = xls_ws.cell_type(row_idx, col_idx)
                # xlrd types: 0=empty, 1=text, 2=number, 3=date, 4=bool, 5=error, 6=blank
                if cell_type == xlrd.XL_CELL_DATE:
                    try:
                        date_tuple = xlrd.xldate_as_tuple(cell_value, xls_wb.datemode)
                        from datetime import datetime, date, time
                        if date_tuple[3:] == (0, 0, 0):
                            cell_value = date(*date_tuple[:3])
                        elif date_tuple[:3] == (0, 0, 0):
                            cell_value = time(*date_tuple[3:])
                        else:
                            cell_value = datetime(*date_tuple)
                    except (ValueError, OverflowError):
                        pass  # Keep raw float
                elif cell_type == xlrd.XL_CELL_BOOLEAN:
                    cell_value = bool(cell_value)
                elif cell_type in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK):
                    continue
                xlsx_ws.cell(row=row_idx + 1, column=col_idx + 1, value=cell_value)

    xlsx_wb.save(str(xlsx_path))
    logger.info("Converted .xls to .xlsx: %s", xlsx_path)
    return xlsx_path


def _xls_to_pdf(src: Path, out_dir: Path) -> Path:
    """Convert a legacy .xls file to PDF.

    Converts .xls → .xlsx first (via xlrd + openpyxl), then reuses
    the existing _xlsx_to_pdf converter.
    """
    xlsx_path = _xls_to_xlsx(src, out_dir)
    return _xlsx_to_pdf(xlsx_path, out_dir)
