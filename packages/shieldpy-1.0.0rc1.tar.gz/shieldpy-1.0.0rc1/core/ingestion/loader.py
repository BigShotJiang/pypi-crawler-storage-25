"""Document ingestion — load files of various formats and convert to page bitmaps + text."""

from __future__ import annotations

import logging
import mimetypes
import ctypes
import shutil
import subprocess
import uuid
from pathlib import Path
from typing import Optional

import pypdfium2 as pdfium
from PIL import Image

from core.config import config
from core.ocr.engine import ocr_page_image
from models.schemas import BBox, DocumentInfo, DocumentStatus, PageData, TextBlock

logger = logging.getLogger(__name__)


def _cluster_into_lines(text_blocks: list[TextBlock]) -> list[list[TextBlock]]:
    """Group text blocks into visual lines by y-proximity, then sort
    left-to-right within each line.

    Plain ``sorted(blocks, key=(y0, x0))`` can mis-order words on the
    same visual line when their y0 values differ slightly (common with
    ascenders/descenders in PDF extraction and OCR noise).  Clustering
    by y-center avoids this.
    """
    if not text_blocks:
        return []

    by_y = sorted(text_blocks, key=lambda b: (b.bbox.y0 + b.bbox.y1) / 2)

    lines: list[list[TextBlock]] = []
    cur_line: list[TextBlock] = []
    line_yc: float = 0.0
    line_h: float = 0.0

    for block in by_y:
        bh = block.bbox.y1 - block.bbox.y0
        byc = (block.bbox.y0 + block.bbox.y1) / 2

        if not cur_line:
            cur_line.append(block)
            line_yc = byc
            line_h = bh
        else:
            tolerance = max(line_h, bh) * 0.5
            if abs(byc - line_yc) <= tolerance:
                cur_line.append(block)
                line_h = max(line_h, bh)
                n = len(cur_line)
                line_yc = (line_yc * (n - 1) + byc) / n
            else:
                lines.append(sorted(cur_line, key=lambda b: b.bbox.x0))
                cur_line = [block]
                line_yc = byc
                line_h = bh

    if cur_line:
        lines.append(sorted(cur_line, key=lambda b: b.bbox.x0))

    return lines


def _build_full_text(text_blocks: list[TextBlock]) -> str:
    """Build full_text from text blocks, inserting newlines between
    lines that are spatially separated (different vertical position).

    Blocks are clustered into visual lines (tolerant of minor y-position
    differences from ascenders, descenders, or OCR noise) and sorted
    left-to-right within each line, producing correct reading order.

    Within each visual line, a large horizontal gap between consecutive
    blocks (> 3× average block height) is treated as a **column
    boundary** and a newline is inserted instead of a space.  This
    prevents regex / NER from seeing text in separate columns as one
    continuous phrase (works even for single-line columns).

    This gives NER/regex much better input than a flat space-joined
    string because sentence boundaries are preserved.
    """
    if not text_blocks:
        return ""

    lines = _cluster_into_lines(text_blocks)

    parts: list[str] = []
    prev_y: float | None = None
    line_height = 0.0

    for line_blocks in lines:
        line_top = min(b.bbox.y0 for b in line_blocks)
        lh = max(b.bbox.y1 for b in line_blocks) - line_top

        # Column-gap threshold: a horizontal gap > 3× average block
        # height on this line indicates a column boundary.
        avg_h = (
            sum(b.bbox.y1 - b.bbox.y0 for b in line_blocks)
            / len(line_blocks)
        )
        col_gap_threshold = max(avg_h * 3, 15.0)

        for i, block in enumerate(line_blocks):
            if prev_y is not None or i > 0:
                if i == 0:
                    gap = line_top - prev_y if prev_y is not None else 0
                    if line_height > 0 and gap > line_height * 0.6:
                        parts.append("\n")
                    else:
                        parts.append(" ")
                else:
                    # Detect column gap within the same visual line
                    prev_block = line_blocks[i - 1]
                    h_gap = block.bbox.x0 - prev_block.bbox.x1
                    if h_gap > col_gap_threshold:
                        parts.append("\n")
                    else:
                        parts.append(" ")
            parts.append(block.text)

        prev_y = line_top
        line_height = lh

    return "".join(parts).strip()


from core.constants import (
    PDF_TYPES, IMAGE_TYPES, OFFICE_TYPES, TEXT_TYPES, SUPPORTED_EXTENSIONS,
)


def guess_mime(filepath: Path) -> str:
    """Guess MIME type from file extension."""
    mime, _ = mimetypes.guess_type(str(filepath))
    return mime or "application/octet-stream"



# Import converter functions from split module
from core.ingestion.converters import (
    _libreoffice_convert_to_pdf,
    _docx_to_pdf,
    _pptx_to_pdf,
    _xlsx_to_pdf,
    _xls_to_xlsx,
    _xls_to_pdf,
)



def _is_rotated_word(char_y_centers: list[float], char_heights: list[float]) -> bool:
    """Return True if the accumulated character positions indicate rotated text.

    For horizontal text, all characters share roughly the same y-centre.
    For rotated/diagonal text (watermarks), the y-centres of successive
    characters shift significantly — the vertical spread of centres will
    exceed a fraction of the average character height.

    Punctuation marks (periods, commas, apostrophes) and accent marks have
    much smaller bounding boxes positioned at different baselines than the
    main letter glyphs.  Without filtering them out, a word like ``B.N.``
    or ``l'exercice`` would look "rotated" even though it's perfectly
    horizontal.  We therefore exclude characters whose height is less than
    70 % of the median character height before computing the spread.
    """
    if len(char_y_centers) < 2:
        return False

    # --- filter out small characters (punctuation / accents / superscripts) ---
    sorted_h = sorted(char_heights)
    n = len(sorted_h)
    median_h = sorted_h[n // 2] if n % 2 == 1 else (sorted_h[n // 2 - 1] + sorted_h[n // 2]) / 2.0
    height_threshold = median_h * 0.70

    filtered_yc: list[float] = []
    filtered_h: list[float] = []
    for yc, h in zip(char_y_centers, char_heights):
        if h >= height_threshold:
            filtered_yc.append(yc)
            filtered_h.append(h)

    if len(filtered_yc) < 2:
        return False

    y_spread = max(filtered_yc) - min(filtered_yc)
    avg_h = sum(filtered_h) / len(filtered_h)
    # Horizontal text: y_spread ≈ 0.  45° rotated: y_spread ≈ word width.
    # Threshold raised to 0.65 to tolerate accented capitals (É, Ô, …) whose
    # taller bounding-box shifts the y-centre slightly.
    return y_spread > avg_h * 0.65


def _extract_text_blocks_from_page(pdf_page: pdfium.PdfPage, page_index: int) -> list[TextBlock]:
    """Extract word-level text blocks with bounding boxes from a PDF page.

    Rotated text (diagonal watermarks, etc.) is automatically discarded.
    Font weight and italic flags are extracted from pdfium per-character
    metadata and propagated to the resulting TextBlock.
    """
    textpage = pdf_page.get_textpage()
    full_text = textpage.get_text_range()

    blocks: list[TextBlock] = []
    if not full_text.strip():
        return blocks

    # Use character-level extraction and group into words
    n_chars = textpage.count_chars()
    if n_chars == 0:
        return blocks

    # ── Helper: query font weight / italic / name / size for a character index ───
    _raw_tp = textpage.raw  # underlying FPDF_TEXTPAGE handle
    _fw_func = pdfium.raw.FPDFText_GetFontWeight
    _fi_func = pdfium.raw.FPDFText_GetFontInfo
    _fs_func = pdfium.raw.FPDFText_GetFontSize
    _fi_buf = ctypes.create_string_buffer(256)
    _fi_flags = ctypes.c_int(0)

    def _char_font_style(idx: int) -> tuple[bool, bool, str, float]:
        """Return (is_bold, is_italic, font_name, font_size) for character *idx*."""
        weight = _fw_func(_raw_tp, idx)
        bold = weight >= 700
        _fi_flags.value = 0
        _fi_func(
            _raw_tp, idx,
            ctypes.cast(_fi_buf, ctypes.c_void_p),
            ctypes.c_ulong(256),
            ctypes.byref(_fi_flags),
        )
        italic = bool(_fi_flags.value & 0x01)
        font_name = _fi_buf.value.decode("utf-8", errors="replace").strip()
        font_size = float(_fs_func(_raw_tp, idx))
        return bold, italic, font_name, font_size

    current_word = ""
    word_x0 = word_y0 = word_x1 = word_y1 = 0.0
    word_start_idx = 0
    word_index = 0
    # Per-character tracking for rotation detection
    char_y_centers: list[float] = []
    char_heights: list[float] = []
    rotated_skipped = 0
    # Font-style accumulators for the current word
    word_bold_votes = 0
    word_italic_votes = 0
    word_char_count = 0
    # Font name / size — sampled from the first character of each word
    word_font_name: str = ""
    word_font_size: float = 0.0

    for i in range(n_chars):
        char = textpage.get_text_range(index=i, count=1)
        charbox = textpage.get_charbox(i)  # (left, bottom, right, top) in PDF coords

        if char.strip() == "":
            # End of word — flush if we have accumulated text
            if current_word:
                if _is_rotated_word(char_y_centers, char_heights):
                    rotated_skipped += 1
                else:
                    # pypdfium2 charbox is (left, bottom, right, top) in PDF coords
                    # Convert to top-left origin: y0 = page_height - top, y1 = page_height - bottom
                    page_height = pdf_page.get_height()
                    # Majority-vote for font style across characters in the word
                    w_bold = word_bold_votes > word_char_count / 2
                    w_italic = word_italic_votes > word_char_count / 2
                    blocks.append(TextBlock(
                        text=current_word,
                        bbox=BBox(
                            x0=word_x0,
                            y0=page_height - word_y1,  # top in screen coords
                            x1=word_x1,
                            y1=page_height - word_y0,  # bottom in screen coords
                        ),
                        confidence=1.0,
                        block_index=0,
                        line_index=0,
                        word_index=word_index,
                        is_ocr=False,
                        is_bold=w_bold,
                        is_italic=w_italic,
                        font_size=word_font_size,
                        font_family=word_font_name,
                    ))
                word_index += 1
                current_word = ""
                char_y_centers = []
                char_heights = []
                word_bold_votes = 0
                word_italic_votes = 0
                word_char_count = 0
                word_font_name = ""
                word_font_size = 0.0
        else:
            left, bottom, right, top = charbox
            if not current_word:
                word_x0 = left
                word_y0 = bottom
                word_x1 = right
                word_y1 = top
                word_start_idx = i
            else:
                word_x0 = min(word_x0, left)
                word_y0 = min(word_y0, bottom)
                word_x1 = max(word_x1, right)
                word_y1 = max(word_y1, top)
            current_word += char
            char_y_centers.append((bottom + top) / 2.0)
            char_heights.append(top - bottom)
            # Track font style (sample first char for name/size)
            try:
                cb, ci, fname, fsize = _char_font_style(i)
                word_bold_votes += int(cb)
                word_italic_votes += int(ci)
                if word_char_count == 0:  # first char of word
                    word_font_name = fname
                    word_font_size = fsize
            except Exception:
                pass  # pdfium may fail on some exotic fonts
            word_char_count += 1

    # Flush last word
    if current_word:
        if _is_rotated_word(char_y_centers, char_heights):
            rotated_skipped += 1
        else:
            page_height = pdf_page.get_height()
            w_bold = word_bold_votes > word_char_count / 2 if word_char_count else False
            w_italic = word_italic_votes > word_char_count / 2 if word_char_count else False
            blocks.append(TextBlock(
                text=current_word,
                bbox=BBox(
                    x0=word_x0,
                    y0=page_height - word_y1,
                    x1=word_x1,
                    y1=page_height - word_y0,
                ),
                confidence=1.0,
                block_index=0,
                line_index=0,
                word_index=word_index,
                is_ocr=False,
                is_bold=w_bold,
                is_italic=w_italic,
                font_size=word_font_size,
                font_family=word_font_name,
            ))

    if rotated_skipped:
        import logging
        logging.getLogger(__name__).info(
            f"Page {page_index + 1}: discarded {rotated_skipped} rotated "
            f"text block(s) (watermarks/diagonal text)"
        )

    return blocks


def _render_page_bitmap(pdf_page: pdfium.PdfPage, page_index: int, doc_id: str) -> Path:
    """Render a PDF page to a PNG bitmap."""
    scale = config.render_dpi / 72  # PDF default is 72 DPI
    bitmap = pdf_page.render(scale=scale)
    pil_image = bitmap.to_pil()

    out_path = config.temp_dir / doc_id / f"page_{page_index + 1:04d}.png"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    pil_image.save(str(out_path), "PNG")
    pil_image.close()
    del bitmap
    return out_path


def _has_embedded_images(pdf_page: pdfium.PdfPage, min_area_fraction: float = 0.005) -> bool:
    """Check if page has embedded images that may contain text.
    
    Returns True if the page contains image objects covering at least
    min_area_fraction of the page area. This indicates potential text-in-image
    content that requires OCR for proper extraction.
    
    Args:
        pdf_page: The PDF page to check
        min_area_fraction: Minimum fraction of page area for an image to count (default 0.5%)
    """
    page_width = pdf_page.get_width()
    page_height = pdf_page.get_height()
    page_area = page_width * page_height
    min_area = page_area * min_area_fraction
    
    try:
        for obj in pdf_page.get_objects():
            if type(obj).__name__ == 'PdfImage':
                bounds = obj.get_bounds()
                left, bottom, right, top = bounds
                img_area = (right - left) * (top - bottom)
                if img_area >= min_area:
                    return True
    except Exception as e:
        logger.debug("Error checking for images: %s", e)
    
    return False


def _merge_ocr_blocks(existing: list[TextBlock], ocr_blocks: list[TextBlock]) -> list[TextBlock]:
    """Merge OCR blocks with existing text blocks, avoiding duplicates.
    
    Only adds OCR blocks that don't significantly overlap with existing text.
    """
    if not ocr_blocks:
        return existing
    if not existing:
        return ocr_blocks
    
    def overlaps(b1: BBox, b2: BBox) -> bool:
        """Check if two bboxes overlap significantly."""
        # Compute intersection
        ix0 = max(b1.x0, b2.x0)
        iy0 = max(b1.y0, b2.y0)
        ix1 = min(b1.x1, b2.x1)
        iy1 = min(b1.y1, b2.y1)
        
        if ix1 <= ix0 or iy1 <= iy0:
            return False
        
        # Check if intersection is >50% of the smaller box
        inter_area = (ix1 - ix0) * (iy1 - iy0)
        b1_area = max((b1.x1 - b1.x0) * (b1.y1 - b1.y0), 1)
        b2_area = max((b2.x1 - b2.x0) * (b2.y1 - b2.y0), 1)
        min_area = min(b1_area, b2_area)
        
        return inter_area > 0.5 * min_area
    
    merged = list(existing)
    for ocr_b in ocr_blocks:
        # Only add if no significant overlap with existing blocks
        if not any(overlaps(ocr_b.bbox, e.bbox) for e in existing):
            merged.append(ocr_b)
    
    return merged


# Type alias for progress callbacks
ProgressCallback = Optional[callable]


def _process_pdf(
    pdf_path: Path, 
    doc_id: str, 
    progress_callback: ProgressCallback = None
) -> list[PageData]:
    """Process a PDF file into page data.

    **Phase 1 — sequential (PDFium):** render bitmaps and extract text
    for every page using a single ``PdfDocument`` handle.  PDFium's C
    library is *not* thread-safe (concurrent handles cause heap
    corruption / native breakpoint crashes on Windows).

    **Phase 2 — parallel OCR (Tesseract):** pages whose embedded text is
    too sparse are sent to OCR in parallel threads.  Tesseract is a
    separate process per invocation and fully thread-safe, so this
    recovers most of the I1 parallelism for scanned/image-based PDFs.
    
    Args:
        pdf_path: Path to the PDF file.
        doc_id: Unique document identifier.
        progress_callback: Optional callback for progress updates.
            Called with (phase, current_page, total_pages, ocr_done, ocr_total, message).
    """
    def _report(phase: str, current: int, total: int, ocr_done: int = 0, ocr_total: int = 0, message: str = ""):
        if progress_callback:
            try:
                progress_callback(phase, current, total, ocr_done, ocr_total, message)
            except Exception:
                pass  # Don't let callback errors break processing
    
    # ── Phase 1: sequential PDFium extraction ──────────────────────
    doc = pdfium.PdfDocument(str(pdf_path))
    try:
        n_pages = len(doc)
        if n_pages == 0:
            return []
        
        _report("extracting", 0, n_pages, 0, 0, f"Loading {n_pages} pages...")

        pages: list[PageData] = []
        ocr_needed: list[int] = []  # indices into *pages* that need OCR

        for page_index in range(n_pages):
            pdf_page = doc[page_index]
            width = pdf_page.get_width()
            height = pdf_page.get_height()

            bitmap_path = _render_page_bitmap(pdf_page, page_index, doc_id)
            text_blocks = _extract_text_blocks_from_page(pdf_page, page_index)
            full_text = _build_full_text(text_blocks)

            pages.append(PageData(
                page_number=page_index + 1,
                width=width,
                height=height,
                bitmap_path=str(bitmap_path),
                text_blocks=text_blocks,
                full_text=full_text,
            ))
            
            # Report extraction progress
            _report("extracting", page_index + 1, n_pages, 0, 0, f"Extracting page {page_index + 1} of {n_pages}...")

            # OCR needed if: (a) sparse text, or (b) page has embedded images
            if len(full_text.strip()) < 20:
                ocr_needed.append(page_index)
            elif _has_embedded_images(pdf_page):
                logger.info("Page %s: embedded images detected, will run hybrid OCR", page_index + 1)
                ocr_needed.append(page_index)

    finally:
        doc.close()

    # ── Phase 2: parallel OCR for sparse-text pages ────────────────
    if not ocr_needed:
        _report("complete", n_pages, n_pages, 0, 0, "Processing complete")
        return pages
    
    ocr_total = len(ocr_needed)
    ocr_done = [0]  # Use list to allow mutation in nested function
    
    _report("ocr", n_pages, n_pages, 0, ocr_total, f"Running OCR on {ocr_total} pages...")

    def _ocr_one(idx: int) -> tuple[int, list[TextBlock], bool]:
        """Returns (index, ocr_blocks, should_merge).
        
        should_merge=True when page already has content (hybrid mode).
        """
        p = pages[idx]
        has_existing_content = len(p.text_blocks) >= 10
        if has_existing_content:
            logger.info("Page %s: hybrid OCR (has %s text blocks + images)", p.page_number, len(p.text_blocks))
        else:
            logger.info("Page %s: sparse text (%s chars), running OCR", p.page_number, len(p.full_text))
        blocks = ocr_page_image(Path(p.bitmap_path), p.width, p.height)
        return idx, blocks, has_existing_content

    def _apply_ocr_result(idx: int, ocr_blocks: list[TextBlock], should_merge: bool):
        if not ocr_blocks:
            return
        if should_merge:
            # Merge OCR blocks with existing text (hybrid mode)
            merged = _merge_ocr_blocks(pages[idx].text_blocks, ocr_blocks)
            pages[idx] = pages[idx].model_copy(update={
                "text_blocks": merged,
                "full_text": _build_full_text(merged),
            })
            logger.info("Page %s: merged %s OCR blocks, now %s total", pages[idx].page_number, len(ocr_blocks), len(merged))
        else:
            # Replace entirely (sparse text case)
            pages[idx] = pages[idx].model_copy(update={
                "text_blocks": ocr_blocks,
                "full_text": _build_full_text(ocr_blocks),
            })

    if len(ocr_needed) == 1:
        # Single page — skip thread overhead
        idx, ocr_blocks, should_merge = _ocr_one(ocr_needed[0])
        _apply_ocr_result(idx, ocr_blocks, should_merge)
        ocr_done[0] = 1
        _report("ocr", n_pages, n_pages, 1, ocr_total, f"OCR complete (1/{ocr_total} pages)")
    else:
        import os
        from concurrent.futures import ThreadPoolExecutor, as_completed

        workers = min(4, os.cpu_count() or 2, len(ocr_needed))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {pool.submit(_ocr_one, i): i for i in ocr_needed}
            for fut in as_completed(futures):
                idx, ocr_blocks, should_merge = fut.result()
                _apply_ocr_result(idx, ocr_blocks, should_merge)
                ocr_done[0] += 1
                _report("ocr", n_pages, n_pages, ocr_done[0], ocr_total, 
                       f"OCR progress: {ocr_done[0]}/{ocr_total} pages")
    
    _report("complete", n_pages, n_pages, ocr_total, ocr_total, "Processing complete")
    return pages


# ---------------------------------------------------------------------------
# Plain-text rendering
# ---------------------------------------------------------------------------

def _process_txt(
    txt_path: Path,
    doc_id: str,
    progress_callback: ProgressCallback = None,
) -> list[PageData]:
    """Process a plain-text file.

    The text is rendered onto white bitmap pages using Pillow so that the
    existing page-bitmap pipeline (viewer, anonymiser, export) works
    unchanged.  Each word gets a precise TextBlock with a bounding box
    derived from font metrics — no OCR needed.
    """
    from PIL import ImageDraw, ImageFont

    def _report(phase: str, current: int, total: int, ocr_done: int = 0, ocr_total: int = 0, message: str = ""):
        if progress_callback:
            try:
                progress_callback(phase, current, total, ocr_done, ocr_total, message)
            except Exception:
                pass

    # --- read file ---
    for enc in ("utf-8", "utf-8-sig", "latin-1"):
        try:
            raw_text = txt_path.read_text(encoding=enc)
            break
        except (UnicodeDecodeError, ValueError):
            continue
    else:
        raw_text = txt_path.read_text(encoding="latin-1", errors="replace")

    # --- page dimensions (Letter @ 150 DPI) ---
    PAGE_W, PAGE_H = 1275, 1650  # 8.5"×11" @ 150 DPI
    MARGIN_X, MARGIN_Y = 75, 75
    FONT_SIZE = 18
    LINE_SPACING = 6  # extra pixels between lines

    # Pick a monospace font – use system DejaVu if available, else default
    font: ImageFont.FreeTypeFont | ImageFont.ImageFont
    for font_name in ("DejaVuSansMono.ttf", "Consolas", "Courier New", "cour.ttf"):
        try:
            font = ImageFont.truetype(font_name, FONT_SIZE)
            break
        except (OSError, IOError):
            continue
    else:
        font = ImageFont.load_default()

    # --- measure helper ---
    dummy_img = Image.new("RGB", (1, 1))
    dummy_draw = ImageDraw.Draw(dummy_img)

    def _text_width(text: str) -> float:
        bbox = dummy_draw.textbbox((0, 0), text, font=font)
        return bbox[2] - bbox[0]

    def _text_height(text: str) -> float:
        bbox = dummy_draw.textbbox((0, 0), text, font=font)
        return bbox[3] - bbox[1]

    line_h = _text_height("Ag") + LINE_SPACING
    usable_w = PAGE_W - 2 * MARGIN_X
    usable_h = PAGE_H - 2 * MARGIN_Y
    max_lines_per_page = int(usable_h / line_h)

    # --- word-wrap into visual lines ---
    src_lines = raw_text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    visual_lines: list[str] = []
    for src_line in src_lines:
        if not src_line.strip():
            visual_lines.append("")  # blank line
            continue
        words = src_line.split()
        cur = ""
        for word in words:
            candidate = f"{cur} {word}" if cur else word
            if _text_width(candidate) > usable_w and cur:
                visual_lines.append(cur)
                cur = word
            else:
                cur = candidate
        if cur:
            visual_lines.append(cur)

    # --- paginate ---
    page_line_groups: list[list[str]] = []
    for i in range(0, max(len(visual_lines), 1), max_lines_per_page):
        page_line_groups.append(visual_lines[i : i + max_lines_per_page])

    n_pages = len(page_line_groups)
    _report("extracting", 0, n_pages, 0, 0, f"Rendering {n_pages} pages...")

    out_dir = config.temp_dir / doc_id
    out_dir.mkdir(parents=True, exist_ok=True)

    pages: list[PageData] = []
    block_idx = 0

    for page_idx, lines in enumerate(page_line_groups):
        img = Image.new("RGB", (PAGE_W, PAGE_H), "white")
        draw = ImageDraw.Draw(img)

        text_blocks: list[TextBlock] = []
        y = MARGIN_Y

        for line_idx, line_text in enumerate(lines):
            if not line_text.strip():
                y += line_h
                continue

            words = line_text.split()
            x = float(MARGIN_X)

            for word_idx, word in enumerate(words):
                w = _text_width(word)
                h = _text_height(word)

                # Draw the word
                draw.text((x, y), word, fill="black", font=font)

                text_blocks.append(TextBlock(
                    text=word,
                    bbox=BBox(x0=x, y0=float(y), x1=x + w, y1=float(y) + h),
                    confidence=1.0,
                    block_index=block_idx,
                    line_index=line_idx,
                    word_index=word_idx,
                    is_ocr=False,
                ))
                block_idx += 1
                x += w + _text_width(" ")

            y += line_h

        bitmap_path = out_dir / f"page_{page_idx + 1:04d}.png"
        img.save(str(bitmap_path), "PNG")
        img.close()

        full_text = _build_full_text(text_blocks)
        pages.append(PageData(
            page_number=page_idx + 1,
            width=float(PAGE_W),
            height=float(PAGE_H),
            bitmap_path=str(bitmap_path),
            text_blocks=text_blocks,
            full_text=full_text,
        ))

        _report("extracting", page_idx + 1, n_pages, 0, 0, f"Rendering page {page_idx + 1} of {n_pages}...")

    dummy_img.close()
    _report("complete", n_pages, n_pages, 0, 0, "Processing complete")
    return pages


def _process_image(
    image_path: Path, 
    doc_id: str,
    progress_callback: ProgressCallback = None
) -> list[PageData]:
    """Process a standalone image file (always OCR)."""
    def _report(phase: str, current: int, total: int, ocr_done: int = 0, ocr_total: int = 0, message: str = ""):
        if progress_callback:
            try:
                progress_callback(phase, current, total, ocr_done, ocr_total, message)
            except Exception:
                pass
    
    _report("extracting", 0, 1, 0, 1, "Loading image...")
    
    img = Image.open(image_path)
    try:
        width, height = img.size

        # Save as PNG in temp
        out_path = config.temp_dir / doc_id / "page_0001.png"
        out_path.parent.mkdir(parents=True, exist_ok=True)

        # Upscale small images to improve OCR accuracy
        min_dim = min(width, height)
        if min_dim < 1500:
            scale = max(2, 1500 // min_dim)
            big = img.resize((width * scale, height * scale), Image.LANCZOS)
            big.save(str(out_path), "PNG")
            big.close()
            logger.info("Upscaled image %sx%s by %sx for OCR", width, height, scale)
        else:
            img.save(str(out_path), "PNG")

        _report("ocr", 1, 1, 0, 1, "Running OCR on image...")
        
        # OCR is required for images
        text_blocks = ocr_page_image(out_path, float(width), float(height))
        full_text = _build_full_text(text_blocks)
        
        _report("complete", 1, 1, 1, 1, "Processing complete")

        return [PageData(
            page_number=1,
            width=float(width),
            height=float(height),
            bitmap_path=str(out_path),
            text_blocks=text_blocks,
            full_text=full_text,
        )]
    finally:
        img.close()


async def ingest_document(
    file_path: Path,
    original_filename: str,
    mime_type: Optional[str] = None,
    progress_callback: ProgressCallback = None,
) -> DocumentInfo:
    """
    Main entry point: ingest a document file, convert to bitmaps, extract text.

    Returns a DocumentInfo with pages populated.
    
    Args:
        file_path: Path to the file to ingest.
        original_filename: Original name of the uploaded file.
        mime_type: Optional MIME type (auto-detected if not provided).
        progress_callback: Optional callback for progress updates.
            Called with (phase, current_page, total_pages, ocr_done, ocr_total, message).
    """
    import asyncio

    doc_id = uuid.uuid4().hex[:12]
    if mime_type is None:
        mime_type = guess_mime(file_path)

    logger.info("Ingesting '%s' (mime=%s, id=%s)", original_filename, mime_type, doc_id)

    doc = DocumentInfo(
        doc_id=doc_id,
        original_filename=original_filename,
        file_path=str(file_path),
        mime_type=mime_type,
        status=DocumentStatus.PROCESSING,
    )

    def _do_ingest() -> list:
        if mime_type in PDF_TYPES:
            return _process_pdf(file_path, doc_id, progress_callback)
        elif mime_type in TEXT_TYPES:
            return _process_txt(file_path, doc_id, progress_callback)
        elif mime_type in IMAGE_TYPES:
            return _process_image(file_path, doc_id, progress_callback)
        elif mime_type in OFFICE_TYPES:
            # Use native converters where possible (no LibreOffice needed)
            xlsx_mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            xls_mime = "application/vnd.ms-excel"
            docx_mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            pptx_mime = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            if mime_type == xlsx_mime:
                pdf_path = _xlsx_to_pdf(file_path, config.temp_dir / doc_id)
            elif mime_type == xls_mime:
                pdf_path = _xls_to_pdf(file_path, config.temp_dir / doc_id)
            elif mime_type == docx_mime:
                pdf_path = _docx_to_pdf(file_path, config.temp_dir / doc_id)
            elif mime_type == pptx_mime:
                pdf_path = _pptx_to_pdf(file_path, config.temp_dir / doc_id)
            else:
                pdf_path = _libreoffice_convert_to_pdf(
                    file_path,
                    config.temp_dir / doc_id,
                )
            return _process_pdf(pdf_path, doc_id, progress_callback)
        else:
            raise ValueError(f"Unsupported file type: {mime_type}")

    try:
        doc.pages = await asyncio.to_thread(_do_ingest)

        doc.page_count = len(doc.pages)
        doc.status = DocumentStatus.EXTRACTED
        logger.info("Ingested %s pages from '%s'", doc.page_count, original_filename)

    except Exception as e:
        logger.exception("Failed to ingest '%s'", original_filename)
        doc.status = DocumentStatus.ERROR
        raise

    return doc
