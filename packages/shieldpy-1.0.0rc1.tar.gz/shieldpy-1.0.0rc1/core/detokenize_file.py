"""File-based de-tokenization — replace tokens in .pdf, .docx, .xlsx, .pptx, .txt files.

Reads the file, runs vault.resolve_all_tokens() on extracted text,
writes a new file with tokens replaced, and returns its path.
"""

from __future__ import annotations

import io
import logging
from pathlib import Path

from typing import Callable

import fitz  # PyMuPDF

import re as _re
import zipfile

from core.config import config

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# OOXML chart helper — patches <c:v> values in chart XML and cells in
# embedded Excel workbooks so that chart data sources are detokenized.
# ---------------------------------------------------------------------------

def _patch_ooxml_charts(
    data: bytes,
    vault,
) -> tuple[bytes, int, list[str], list[dict]]:
    """Replace tokens inside chart XML parts and embedded xlsx workbooks.

    Works on any OOXML package (docx/xlsx/pptx).  Returns
    (patched_bytes, replaced_count, unresolved, replacements).
    """
    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []
    seen_tokens: set[str] = set()
    modified = False

    src = io.BytesIO(data)
    dst = io.BytesIO()

    try:
        with zipfile.ZipFile(src, "r") as zin, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                raw = zin.read(item.filename)
                name_lower = item.filename.lower()

                # --- Chart XML parts (e.g. ppt/charts/chart1.xml, xl/charts/chart1.xml, word/charts/chart1.xml)
                if "/charts/" in name_lower and name_lower.endswith(".xml"):
                    text = raw.decode("utf-8", errors="replace")
                    result, count, unresolved, repl = vault.resolve_all_tokens(text)
                    if count > 0 or unresolved:
                        if count > 0:
                            raw = result.encode("utf-8")
                            modified = True
                        total_replaced += count
                        all_unresolved.extend(unresolved)
                        for r in repl:
                            if r["token"] not in seen_tokens:
                                seen_tokens.add(r["token"])
                                all_replacements.append(r)

                # --- Embedded xlsx workbooks (e.g. ppt/embeddings/*.xlsx, word/embeddings/*.xlsx)
                elif "/embeddings/" in name_lower and name_lower.endswith(".xlsx"):
                    patched, cnt, unres, reps = _patch_embedded_xlsx(raw, vault)
                    if cnt > 0 or unres:
                        if cnt > 0:
                            raw = patched
                            modified = True
                        total_replaced += cnt
                        all_unresolved.extend(unres)
                        for r in reps:
                            if r["token"] not in seen_tokens:
                                seen_tokens.add(r["token"])
                                all_replacements.append(r)

                zout.writestr(item, raw)
    except zipfile.BadZipFile:
        # Not a valid ZIP — skip chart patching
        return data, 0, [], []

    if not modified:
        return data, total_replaced, all_unresolved, all_replacements

    return dst.getvalue(), total_replaced, all_unresolved, all_replacements


def _patch_embedded_xlsx(data: bytes, vault) -> tuple[bytes, int, list[str], list[dict]]:
    """Open an embedded xlsx with openpyxl and replace tokens in all cells."""
    from openpyxl import load_workbook

    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []
    seen_tokens: set[str] = set()

    try:
        wb = load_workbook(io.BytesIO(data))
    except Exception:
        return data, 0, [], []

    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value:
                    result, count, unresolved, repl = vault.resolve_all_tokens(cell.value)
                    if count > 0:
                        cell.value = result
                        total_replaced += count
                        all_unresolved.extend(unresolved)
                        for r in repl:
                            if r["token"] not in seen_tokens:
                                seen_tokens.add(r["token"])
                                all_replacements.append(r)

    if total_replaced == 0:
        return data, 0, [], []

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue(), total_replaced, all_unresolved, all_replacements


# Supported MIME → extension mapping
_MIME_MAP: dict[str, str] = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.ms-excel": ".xls",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": ".pptx",
    "application/vnd.ms-powerpoint": ".ppt",
    "text/plain": ".txt",
    "text/csv": ".csv",
}


def _suffix_from_filename(filename: str) -> str:
    return Path(filename).suffix.lower()


# ---------------------------------------------------------------------------
# Per-format handlers
# ---------------------------------------------------------------------------

def _detokenize_txt(data: bytes, vault) -> tuple[bytes, int, list[str], list[dict]]:
    """Plain text / CSV — straightforward string replace."""
    text = data.decode("utf-8", errors="replace")
    result, count, unresolved, repl = vault.resolve_all_tokens(text)
    return result.encode("utf-8"), count, unresolved, repl


def _detokenize_docx(data: bytes, vault) -> tuple[bytes, int, list[str], list[dict]]:
    """DOCX — iterate over paragraphs, tables, headers/footers."""
    from docx import Document

    doc = Document(io.BytesIO(data))
    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []
    seen_tokens: set[str] = set()

    def _process(text: str) -> str:
        nonlocal total_replaced, all_unresolved
        result, count, unresolved, repl = vault.resolve_all_tokens(text)
        total_replaced += count
        all_unresolved.extend(unresolved)
        for r in repl:
            if r["token"] not in seen_tokens:
                seen_tokens.add(r["token"])
                all_replacements.append(r)
        return result

    # Paragraphs
    for para in doc.paragraphs:
        for run in para.runs:
            if run.text:
                run.text = _process(run.text)

    # Tables
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    for run in para.runs:
                        if run.text:
                            run.text = _process(run.text)

    # Headers & footers
    for section in doc.sections:
        for header_footer in (section.header, section.footer):
            if header_footer and header_footer.is_linked_to_previous is False:
                for para in header_footer.paragraphs:
                    for run in para.runs:
                        if run.text:
                            run.text = _process(run.text)

    buf = io.BytesIO()
    doc.save(buf)

    # Patch chart XML and embedded xlsx workbooks
    patched, chart_count, chart_unresolved, chart_repl = _patch_ooxml_charts(buf.getvalue(), vault)
    total_replaced += chart_count
    all_unresolved.extend(chart_unresolved)
    for r in chart_repl:
        if r["token"] not in seen_tokens:
            seen_tokens.add(r["token"])
            all_replacements.append(r)

    # Deduplicate unresolved
    return patched, total_replaced, list(set(all_unresolved)), all_replacements


def _detokenize_xlsx(data: bytes, vault) -> tuple[bytes, int, list[str], list[dict]]:
    """XLSX — iterate over all cells in all sheets."""
    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(data))
    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []
    seen_tokens: set[str] = set()

    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if isinstance(cell.value, str) and cell.value:
                    result, count, unresolved, repl = vault.resolve_all_tokens(cell.value)
                    if count > 0:
                        cell.value = result
                        total_replaced += count
                        all_unresolved.extend(unresolved)
                        for r in repl:
                            if r["token"] not in seen_tokens:
                                seen_tokens.add(r["token"])
                                all_replacements.append(r)

    buf = io.BytesIO()
    wb.save(buf)

    # Patch chart XML caches (category labels, series names, etc.)
    patched, chart_count, chart_unresolved, chart_repl = _patch_ooxml_charts(buf.getvalue(), vault)
    total_replaced += chart_count
    all_unresolved.extend(chart_unresolved)
    for r in chart_repl:
        if r["token"] not in seen_tokens:
            seen_tokens.add(r["token"])
            all_replacements.append(r)

    return patched, total_replaced, list(set(all_unresolved)), all_replacements


def _detokenize_pptx(data: bytes, vault) -> tuple[bytes, int, list[str], list[dict]]:
    """PPTX — iterate over all slides, shapes, tables, and notes."""
    from pptx import Presentation

    prs = Presentation(io.BytesIO(data))
    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []
    seen_tokens: set[str] = set()

    def _process(text: str) -> str:
        nonlocal total_replaced, all_unresolved
        result, count, unresolved, repl = vault.resolve_all_tokens(text)
        total_replaced += count
        all_unresolved.extend(unresolved)
        for r in repl:
            if r["token"] not in seen_tokens:
                seen_tokens.add(r["token"])
                all_replacements.append(r)
        return result

    def _process_text_frame(text_frame) -> None:
        """Replace tokens in all runs of every paragraph in a text frame."""
        for para in text_frame.paragraphs:
            for run in para.runs:
                if run.text:
                    run.text = _process(run.text)

    for slide in prs.slides:
        for shape in slide.shapes:
            # Text frames (titles, text boxes, etc.)
            if shape.has_text_frame:
                _process_text_frame(shape.text_frame)

            # Tables
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        if cell.text_frame:
                            _process_text_frame(cell.text_frame)

            # Group shapes — recurse into child shapes
            if hasattr(shape, "shapes"):
                for child in shape.shapes:
                    if child.has_text_frame:
                        _process_text_frame(child.text_frame)
                    if child.has_table:
                        for row in child.table.rows:
                            for cell in row.cells:
                                if cell.text_frame:
                                    _process_text_frame(cell.text_frame)

        # Slide notes
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
            _process_text_frame(slide.notes_slide.notes_text_frame)

    buf = io.BytesIO()
    prs.save(buf)

    # Patch chart XML and embedded xlsx workbooks
    patched, chart_count, chart_unresolved, chart_repl = _patch_ooxml_charts(buf.getvalue(), vault)
    total_replaced += chart_count
    all_unresolved.extend(chart_unresolved)
    for r in chart_repl:
        if r["token"] not in seen_tokens:
            seen_tokens.add(r["token"])
            all_replacements.append(r)

    return patched, total_replaced, list(set(all_unresolved)), all_replacements


def _is_ai_prompt_page(page) -> bool:
    """Return True if *page* is the PromptShield AI Instructions page."""
    text = page.get_text()
    return "PromptShield" in text and "Token legend:" in text


def _detokenize_pdf(data: bytes, vault) -> tuple[bytes, int, list[str], list[dict]]:
    """PDF — in-place token replacement preserving original layout.

    Strategy per page:
      1. Search for each token string → get pixel rects.
      2. Extract the token's visual style (font, size, color, baseline).
      3. Add erase-only redactions (white fill, no text).
      4. apply_redactions() wipes the token text.
      5. insert_text() at the original baseline with the original value
         using the extracted style — unconstrained by rect, so the
         (usually longer) original text renders at the correct size.
    """
    import re

    pdf_doc = fitz.open(stream=data, filetype="pdf")

    total_replaced = 0
    all_unresolved: list[str] = []
    all_replacements: list[dict] = []

    # Identify AI instructions pages to skip during detokenization
    skip_pages: set[int] = set()
    for i in range(len(pdf_doc)):
        if _is_ai_prompt_page(pdf_doc[i]):
            skip_pages.add(i)

    try:
        # First pass: collect all unique token strings from the document
        full_text = ""
        for i, page in enumerate(pdf_doc):
            if i in skip_pages:
                continue
            full_text += page.get_text() + "\n"

        # Find token-shaped strings — supports both compact [P38291] and
        # legacy [ANON_TYPE_HEX] formats.
        token_pattern = re.compile(
            r"\[[A-Z][A-Z0-9]{5,}\]"
            r"|\[[A-Z][A-Z0-9_]{4,40}\]"
        )
        found_tokens = set(token_pattern.findall(full_text))

        if not found_tokens:
            # No tokens found — return as-is
            return data, 0, [], []

        # Resolve each token via the vault
        token_map: dict[str, str] = {}  # token_string → original_text
        for token_str in found_tokens:
            mapping = vault.resolve_token(token_str)
            if mapping:
                token_map[token_str] = mapping.original_text
                all_replacements.append({
                    "token": token_str,
                    "original": mapping.original_text,
                    "pii_type": mapping.pii_type.value if hasattr(mapping.pii_type, 'value') else str(mapping.pii_type),
                })
            else:
                all_unresolved.append(token_str)

        if not token_map:
            return data, 0, list(set(all_unresolved)), []

        # Second pass: erase tokens then insert original text per page
        for page_idx, page in enumerate(pdf_doc):
            if page_idx in skip_pages:
                continue
            # Collect deferred text insertions
            deferred: list[tuple[str, dict]] = []  # (original_text, style)

            for token_str, original_text in token_map.items():
                rects = page.search_for(token_str)
                if not rects:
                    continue

                for rect in rects:
                    # Extract the visual style of the token text
                    style = _extract_detok_style(page, rect)

                    # Widen erase rect to cover the original text which
                    # is usually longer than the compact token.
                    needed_width = fitz.get_text_length(
                        original_text,
                        fontname=style["fontname"],
                        fontsize=style["fontsize"],
                    )
                    erase_rect = fitz.Rect(rect)
                    if needed_width > erase_rect.width:
                        erase_rect.x1 = erase_rect.x0 + needed_width + 4

                    page.add_redact_annot(erase_rect, fill=(1, 1, 1))
                    deferred.append((original_text, style))
                    total_replaced += 1

            page.apply_redactions()

            # Insert original text at each token's baseline position
            for text, style in deferred:
                origin = style["origin"]
                page.insert_text(
                    fitz.Point(origin[0], origin[1]),
                    text,
                    fontname=style["fontname"],
                    fontsize=style["fontsize"],
                    color=style["text_color"],
                )

        output_bytes = pdf_doc.tobytes(deflate=True, clean=True)
        return output_bytes, total_replaced, list(set(all_unresolved)), all_replacements

    finally:
        pdf_doc.close()


def _extract_detok_style(page: fitz.Page, rect: fitz.Rect) -> dict:
    """Extract font properties from the dominant span overlapping *rect*.

    Returns dict with fontname (Base-14), fontsize, text_color, origin.
    Falls back to sensible defaults when no span overlaps.
    """
    from core.anonymizer.engine import _map_to_base14, _srgb_int_to_rgb

    blocks = page.get_text("dict", clip=rect.irect, flags=fitz.TEXT_PRESERVE_WHITESPACE)["blocks"]

    best_span = None
    best_overlap = 0.0

    for block in blocks:
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                sb = fitz.Rect(span["bbox"])
                overlap = abs(sb & rect)  # intersection area
                if overlap > best_overlap:
                    best_overlap = overlap
                    best_span = span

    if best_span is None:
        return {
            "fontname": "helv",
            "fontsize": 11.0,
            "text_color": (0, 0, 0),
            "origin": (rect.x0, rect.y1 - 2),
        }

    span_origin = best_span.get("origin", (rect.x0, rect.y1 - 2))
    baseline_y = span_origin[1]

    return {
        "fontname": _map_to_base14(best_span.get("font", ""), best_span.get("flags", 0)),
        "fontsize": best_span.get("size", 11.0),
        "text_color": _srgb_int_to_rgb(best_span.get("color", 0)),
        "origin": (rect.x0, baseline_y),
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

_HANDLERS: dict[str, Callable] = {
    ".txt":  _detokenize_txt,
    ".csv":  _detokenize_txt,
    ".docx": _detokenize_docx,
    ".xlsx": _detokenize_xlsx,
    ".pptx": _detokenize_pptx,
    ".pdf":  _detokenize_pdf,
}

SUPPORTED_EXTENSIONS = set(_HANDLERS.keys())


def detokenize_file(
    file_data: bytes,
    filename: str,
    vault,
) -> tuple[bytes, str, int, list[str], list[dict]]:
    """
    De-tokenize tokens inside a file.

    Args:
        file_data: Raw file bytes.
        filename: Original filename (used to detect format).
        vault: Unlocked TokenVault instance.

    Returns:
        (output_bytes, output_filename, tokens_replaced, unresolved_tokens, replacements)
    """
    ext = _suffix_from_filename(filename)

    if ext == ".doc":
        raise ValueError(
            "Legacy .doc format is not supported. "
            "Please convert to .docx first (File → Save As in Word)."
        )
    if ext == ".ppt":
        raise ValueError(
            "Legacy .ppt format is not supported. "
            "Please convert to .pptx first (File → Save As in PowerPoint)."
        )
    if ext == ".xls":
        # Convert legacy .xls → .xlsx, then detokenize as xlsx
        from core.ingestion.loader import _xls_to_xlsx
        import tempfile
        with tempfile.TemporaryDirectory() as tmp_dir:
            xls_path = Path(tmp_dir) / filename
            xls_path.write_bytes(file_data)
            xlsx_path = _xls_to_xlsx(xls_path, Path(tmp_dir))
            xlsx_data = xlsx_path.read_bytes()
        output_data, count, unresolved, repl = _detokenize_xlsx(xlsx_data, vault)
        stem = Path(filename).stem
        return output_data, f"{stem}_detokenized.xlsx", count, unresolved, repl

    handler = _HANDLERS.get(ext)
    if handler is None:
        raise ValueError(
            f"Unsupported file type '{ext}'. "
            f"Supported: {', '.join(sorted(SUPPORTED_EXTENSIONS))}"
        )

    output_data, count, unresolved, repl = handler(file_data, vault)

    stem = Path(filename).stem
    out_name = f"{stem}_detokenized{ext}"

    logger.info(
        f"File de-tokenization: {filename} → {out_name}, "
        f"{count} token(s) replaced, {len(unresolved)} unresolved"
    )
    return output_data, out_name, count, unresolved, repl
