"""Shared MIME-type and file-extension constants — **single source of truth**.

Centralised here to avoid duplicated definitions across ingestion,
anonymisation, and detokenisation modules.  All modules that need
MIME-type or extension checks should import from this file.
"""

from __future__ import annotations

# ── MIME type sets ────────────────────────────────────────────────────────

PDF_TYPES: set[str] = {"application/pdf"}

IMAGE_TYPES: set[str] = {
    "image/jpeg", "image/png", "image/tiff", "image/bmp", "image/webp",
}

OFFICE_TYPES: set[str] = {
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",   # docx
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",          # xlsx
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",  # pptx
    "application/msword",
    "application/vnd.ms-excel",
    "application/vnd.ms-powerpoint",
}

TEXT_TYPES: set[str] = {"text/plain"}

# ── Single MIME strings (used by the anonymiser dispatcher) ───────────────

DOCX_TYPE: str = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
XLSX_TYPE: str = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
XLS_TYPE: str = "application/vnd.ms-excel"
TEXT_TYPE: str = "text/plain"

# ── Supported file extensions ────────────────────────────────────────────

SUPPORTED_EXTENSIONS: set[str] = {
    ".pdf", ".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp", ".webp",
    ".docx", ".xlsx", ".pptx", ".doc", ".xls", ".ppt",
    ".txt",
}
