"""Token Registry — stores token ↔ original text mappings in SQLite (plaintext).

## Design Decision: No Encryption (Intentional)

The Token Registry stores original PII text in **plaintext** SQLite. This is a
deliberate architectural decision, NOT a security oversight:

1. The user already has full access to the **unencrypted original documents** on
   their local filesystem. Encrypting the token mappings while the source
   documents sit in the clear provides zero additional security.

2. If an attacker has access to the machine, they can read the original PDFs,
   DOCX files, etc. directly — the token registry adds no new exposure.

3. Encryption would add complexity (key management, passphrase UX, locked-state
   handling) with no tangible security benefit for a local desktop application.

4. Previous versions used PBKDF2 + Fernet field-level encryption which was
   removed after recognising it was security theater in this threat model.

Do NOT re-add encryption to this module without revisiting this rationale.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from core.config import config
from models.schemas import PIIType, TokenMapping

logger = logging.getLogger(__name__)


class TokenRegistry:
    """
    Token Registry — SQLite store for token-to-original-text mappings.

    Stores mappings in plaintext SQLite. Auto-initialises on first access.

    See module docstring for the rationale on why this is NOT encrypted.
    """

    # SQL schema — plaintext columns (no encryption)
    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS tokens (
        token_id TEXT PRIMARY KEY,
        token_string TEXT UNIQUE NOT NULL,
        original_text TEXT NOT NULL,
        pii_type TEXT NOT NULL,
        source_document TEXT DEFAULT '',
        context_snippet TEXT DEFAULT '',
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS documents (
        doc_id TEXT PRIMARY KEY,
        original_filename TEXT NOT NULL,
        anonymized_filename TEXT DEFAULT '',
        processed_at TEXT NOT NULL,
        page_count INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS vault_meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_token_string ON tokens(token_string);
    """

    def __init__(self, db_path: Optional[Path] = None):
        self._db_path = db_path or config.vault_path
        self._conn: Optional[sqlite3.Connection] = None
        self._is_unlocked = False
        self._lock = threading.RLock()  # Re-entrant: import_vault acquires then calls store_token
        self._local = threading.local()  # Per-thread connection cache

    @property
    def is_unlocked(self) -> bool:
        return self._is_unlocked

    @property
    def db_path(self) -> Path:
        return self._db_path

    # ------------------------------------------------------------------
    # Initialisation — no passphrase needed
    # ------------------------------------------------------------------

    def initialize(self, passphrase: str | None = None) -> None:
        """Open (or create) the vault.

        The *passphrase* parameter is accepted but **ignored** — it is
        kept only for backward-compatible call-sites that still pass one.
        """
        with self._lock:
            self._init_thread_id = threading.get_ident()
            self._initialize_locked()

    def _initialize_locked(self) -> None:
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path), check_same_thread=False, timeout=10)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._conn.executescript(self._SCHEMA)

        # Migrate from encrypted schema if needed
        self._migrate_if_needed()

        self._is_unlocked = True
        logger.info("Vault ready at %s", self._db_path)

    def _get_conn(self) -> sqlite3.Connection:
        """Return a per-thread SQLite connection (WAL mode allows concurrent readers).

        The primary connection (self._conn) is used for the initialising thread.
        Other threads get their own read-optimised connection via threading.local().
        """
        if self._conn is None:
            raise RuntimeError("Vault database connection not open")
        main_id = getattr(self, "_init_thread_id", None)
        if main_id is None or threading.get_ident() == main_id:
            return self._conn
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(str(self._db_path), check_same_thread=True, timeout=10)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA busy_timeout=5000")
            self._local.conn = conn
        return conn

    def ensure_ready(self) -> None:
        """Auto-initialise if not yet open.  Call from any code path that
        needs the vault without going through the unlock API."""
        if not self._is_unlocked:
            self.initialize()

    def _migrate_if_needed(self) -> None:
        """Transparently rename old encrypted columns to plaintext names.

        Previous schema had ``original_text_enc BLOB`` and
        ``context_snippet_enc BLOB``.  If the new column names don't
        exist we rename them so existing data keeps working.
        """
        if self._conn is None:
            raise RuntimeError("Vault database connection not open")
        cols = {
            row[1]
            for row in self._conn.execute("PRAGMA table_info(tokens)").fetchall()
        }
        if "original_text_enc" in cols and "original_text" not in cols:
            logger.info("Migrating vault schema: renaming encrypted columns")
            self._conn.execute(
                "ALTER TABLE tokens RENAME COLUMN original_text_enc TO original_text"
            )
            self._conn.execute(
                "ALTER TABLE tokens RENAME COLUMN context_snippet_enc TO context_snippet"
            )
            self._conn.commit()

    # ------------------------------------------------------------------
    # Metadata helpers
    # ------------------------------------------------------------------

    def _store_meta(self, key: str, value: str) -> None:
        if self._conn is None:
            raise RuntimeError("Vault database connection not open")
        self._conn.execute(
            "INSERT OR REPLACE INTO vault_meta (key, value) VALUES (?, ?)",
            (key, value),
        )
        self._conn.commit()

    def _get_meta(self, key: str) -> Optional[str]:
        if self._conn is None:
            raise RuntimeError("Vault database connection not open")
        row = self._conn.execute(
            "SELECT value FROM vault_meta WHERE key = ?", (key,)
        ).fetchone()
        return row[0] if row else None

    def _ensure_unlocked(self) -> None:
        if not self._is_unlocked:
            # Auto-initialise instead of raising
            self.initialize()

    # -----------------------------------------------------------------------
    # Token operations
    # -----------------------------------------------------------------------

    _TYPE_LETTER: dict[str, str] = {
        "PERSON": "P",
        "ORG": "O",
        "EMAIL": "E",
        "PHONE": "T",
        "SSN": "S",
        "CREDIT_CARD": "C",
        "DATE": "D",
        "ADDRESS": "A",
        "LOCATION": "L",
        "IP_ADDRESS": "I",
        "IBAN": "B",
        "PASSPORT": "X",
        "DRIVER_LICENSE": "R",
        "CUSTOM": "K",
        "UNKNOWN": "U",
    }

    # --- Width classes for proportional-font width matching ----------------
    # Characters classified by their typical glyph width so that a token
    # occupies the same visual space as the original text it replaces.
    _NARROW_CHARS = frozenset("1!|',.:;`ijlftIJ()[]{}/ ")
    _WIDE_CHARS   = frozenset("mwMW@%#&")
    # Everything else (most letters + digits) → medium

    # Filler character pools (uppercase + digits only, for regex safety)
    _NARROW_POOL  = "1IJ"
    _MEDIUM_POOL  = "023456789ABCDEFGHKLNOPQRSTUVXYZ"
    _WIDE_POOL    = "MW"

    def _build_width_matched_filler(self, original_text: str, filler_len: int) -> str:
        """Build a filler string whose per-character widths mirror *original_text*.

        Position mapping (token  ↔  original):
          token[0]  = '['          ↔  original[0]
          token[1]  = type letter  ↔  original[1]
          token[2…n-2] = filler    ↔  original[2…n-2]
          token[n-1] = ']'         ↔  original[n-1]

        For each filler position, a random character is chosen from the
        pool that matches the width class of the corresponding original
        character.  No character may appear more than twice in a row.
        """
        chars: list[str] = []
        for i in range(filler_len):
            orig_idx = i + 2  # skip '[' and type-letter positions
            if orig_idx < len(original_text) - 1:
                orig_ch = original_text[orig_idx]
            else:
                orig_ch = "a"  # default → medium

            if orig_ch in self._NARROW_CHARS:
                pool = self._NARROW_POOL
            elif orig_ch in self._WIDE_CHARS:
                pool = self._WIDE_POOL
            else:
                pool = self._MEDIUM_POOL

            ch = secrets.choice(pool)
            # Prevent 3+ consecutive identical characters
            if len(chars) >= 2 and chars[-1] == ch and chars[-2] == ch:
                alts = [c for c in pool if c != ch]
                if alts:
                    ch = secrets.choice(alts)
            chars.append(ch)
        return "".join(chars)

    def generate_token_string(self, pii_type: PIIType, original_text: str = "") -> str:
        """Generate a unique token whose length and per-character width
        match the original text it replaces.

        Format: ``[L<filler>]`` where *L* is the PII-type letter and
        each filler character is chosen from the same visual-width class
        as the corresponding character in *original_text*.
        Minimum token is 8 chars (``[X?????]``).

        Examples (original → token):
          "Mo"        → ``[P0ABCD]``  (8 — can't go shorter)
          "John Smith" → ``[PRKW1FJR]`` (width-matched per char)
        """
        type_str = pii_type.value if isinstance(pii_type, PIIType) else str(pii_type)
        letter = self._TYPE_LETTER.get(type_str, "K")

        original_length = len(original_text)
        min_total = 8        # minimum: [X?????]
        target = max(original_length, min_total)
        filler_len = target - 3  # subtract [ + letter + ]

        with self._lock:
            filler = self._build_width_matched_filler(original_text, filler_len)
            token = f"[{letter}{filler}]"
            while self._token_string_exists(token):
                filler = self._build_width_matched_filler(original_text, filler_len)
                token = f"[{letter}{filler}]"
            return token

    def _token_string_exists(self, token_string: str) -> bool:
        if self._conn is None:
            raise RuntimeError("Vault database connection not open")
        row = self._conn.execute(
            "SELECT 1 FROM tokens WHERE token_string = ?", (token_string,)
        ).fetchone()
        return row is not None

    def store_token(self, mapping: TokenMapping) -> None:
        """Store a token mapping in the vault."""
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            self._conn.execute(
                """INSERT INTO tokens
                   (token_id, token_string, original_text, pii_type,
                    source_document, context_snippet, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (
                    mapping.token_id,
                    mapping.token_string,
                    mapping.original_text,
                    mapping.pii_type.value if isinstance(mapping.pii_type, PIIType) else str(mapping.pii_type),
                    mapping.source_document,
                    mapping.context_snippet or "",
                    mapping.created_at.isoformat(),
                ),
            )
            self._conn.commit()

    def find_token_by_text(
        self,
        original_text: str,
        pii_type: PIIType,
    ) -> Optional[str]:
        """Look up an existing token string by (original_text, pii_type).

        Returns the *token_string* if found, else ``None``.
        This enables cross-document token sharing: when a linked document
        encounters the same PII text, it can reuse the existing token.
        """
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            row = self._conn.execute(
                "SELECT token_string FROM tokens WHERE original_text = ? AND pii_type = ? LIMIT 1",
                (
                    original_text,
                    pii_type.value if isinstance(pii_type, PIIType) else str(pii_type),
                ),
            ).fetchone()
        return row[0] if row else None

    def resolve_token(self, token_string: str) -> Optional[TokenMapping]:
        """Look up a token and return the mapping."""
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            row = self._conn.execute(
                """SELECT token_id, token_string, original_text, pii_type,
                          source_document, context_snippet, created_at
                   FROM tokens WHERE token_string = ?""",
                (token_string,),
            ).fetchone()

        if row is None:
            return None

        try:
            pii_type = PIIType(row[3])
        except ValueError:
            pii_type = PIIType.CUSTOM

        return TokenMapping(
            token_id=row[0],
            token_string=row[1],
            original_text=row[2],
            pii_type=pii_type,
            source_document=row[4],
            context_snippet=row[5] or "",
            created_at=datetime.fromisoformat(row[6]),
        )

    def resolve_all_tokens(self, text: str) -> tuple[str, int, list[str], list[dict]]:
        """Find and replace all tokens in *text* with their original values.

        Returns (result_text, replaced_count, unresolved, replacements)
        where replacements is a list of {token, original, pii_type} dicts.
        """
        import re

        self._ensure_unlocked()

        pattern = re.compile(
            r"\[[A-Z][A-Z0-9]{5,}\]"
            r"|\[" + re.escape(config.token_prefix) + r"_[A-Z_]+_[A-F0-9]{6,12}\]"
        )
        found_tokens = pattern.findall(text)

        if not found_tokens:
            return text, 0, [], []

        unresolved: list[str] = []
        replacements: list[dict] = []
        seen: set[str] = set()
        result = text

        for token_str in set(found_tokens):
            mapping = self.resolve_token(token_str)
            if mapping:
                result = result.replace(token_str, mapping.original_text)
                if token_str not in seen:
                    seen.add(token_str)
                    replacements.append({
                        "token": token_str,
                        "original": mapping.original_text,
                        "pii_type": mapping.pii_type.value if hasattr(mapping.pii_type, 'value') else str(mapping.pii_type),
                    })
            else:
                unresolved.append(token_str)

        replaced_count = len(found_tokens) - len(unresolved)
        return result, replaced_count, unresolved, replacements

    def list_tokens(
        self,
        source_document: Optional[str] = None,
        pii_type: Optional[PIIType] = None,
    ) -> list[TokenMapping]:
        """List tokens, optionally filtered."""
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            query = ("SELECT token_id, token_string, original_text, pii_type,"
                     "       source_document, context_snippet, created_at"
                     " FROM tokens WHERE 1=1")
            params: list = []

            if source_document:
                query += " AND source_document = ?"
                params.append(source_document)
            if pii_type:
                query += " AND pii_type = ?"
                params.append(pii_type.value if isinstance(pii_type, PIIType) else str(pii_type))

            query += " ORDER BY created_at DESC"
            rows = self._conn.execute(query, params).fetchall()

        result = []
        for row in rows:
            try:
                pii_type = PIIType(row[3])
            except ValueError:
                # Gracefully handle custom/unknown PII types not in the enum
                pii_type = PIIType.CUSTOM
            result.append(TokenMapping(
                token_id=row[0],
                token_string=row[1],
                original_text=row[2],
                pii_type=pii_type,
                source_document=row[4],
                context_snippet=row[5] or "",
                created_at=datetime.fromisoformat(row[6]),
            ))
        return result

    def delete_token(self, token_id: str) -> bool:
        """Delete a token from the vault."""
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            cursor = self._conn.execute(
                "DELETE FROM tokens WHERE token_id = ?", (token_id,)
            )
            self._conn.commit()
            return cursor.rowcount > 0

    def delete_tokens(self, token_ids: list[str]) -> int:
        """Delete multiple tokens from the vault. Returns count of deleted rows."""
        self._ensure_unlocked()
        if not token_ids:
            return 0
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            placeholders = ",".join("?" for _ in token_ids)
            cursor = self._conn.execute(
                f"DELETE FROM tokens WHERE token_id IN ({placeholders})",  # noqa: S608
                token_ids,
            )
            self._conn.commit()
            return cursor.rowcount

    def update_token(self, token_id: str, original_text: str | None = None, pii_type: str | None = None) -> bool:
        """Update editable fields of a token. Returns True if a row was updated."""
        self._ensure_unlocked()
        sets: list[str] = []
        params: list[str] = []
        if original_text is not None:
            sets.append("original_text = ?")
            params.append(original_text)
        if pii_type is not None:
            sets.append("pii_type = ?")
            params.append(pii_type)
        if not sets:
            return False
        params.append(token_id)
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            cursor = self._conn.execute(
                f"UPDATE tokens SET {', '.join(sets)} WHERE token_id = ?",  # noqa: S608
                params,
            )
            self._conn.commit()
            return cursor.rowcount > 0

    # -----------------------------------------------------------------------
    # Document tracking
    # -----------------------------------------------------------------------

    def register_document(
        self,
        doc_id: str,
        original_filename: str,
        page_count: int,
        anonymized_filename: str = "",
    ) -> None:
        """Register a processed document in the vault."""
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            self._conn.execute(
                """INSERT OR REPLACE INTO documents
                   (doc_id, original_filename, anonymized_filename, processed_at, page_count)
                   VALUES (?, ?, ?, ?, ?)""",
                (doc_id, original_filename, anonymized_filename,
                 datetime.now(timezone.utc).isoformat(), page_count),
            )
            self._conn.commit()

    # -----------------------------------------------------------------------
    # Stats
    # -----------------------------------------------------------------------

    def get_stats(self) -> dict:
        """Return vault statistics."""
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            token_count = self._conn.execute("SELECT COUNT(*) FROM tokens").fetchone()[0]
            doc_count = self._conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
            db_size = os.path.getsize(self._db_path) if self._db_path.exists() else 0

            return {
                "total_tokens": token_count,
                "total_documents": doc_count,
                "vault_size_bytes": db_size,
            }

    # -----------------------------------------------------------------------
    # Export / Import  (plaintext JSON)
    # -----------------------------------------------------------------------

    def export_vault(self) -> str:
        """Export all tokens as a JSON string."""
        self._ensure_unlocked()
        tokens = self.list_tokens()
        data = {
            "version": 2,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "tokens": [t.model_dump(mode="json") for t in tokens],
        }
        return json.dumps(data)

    def import_vault(self, export_json: str) -> dict:
        """Import tokens from an export JSON string.

        Returns dict with 'imported', 'skipped', 'errors' counts.
        """
        self._ensure_unlocked()

        data = json.loads(export_json)

        # Support both v1 (old encrypted envelope — not supported) and v2 (plaintext)
        if "tokens" in data:
            tokens_list = data["tokens"]
        else:
            raise ValueError("Unrecognised export format — missing 'tokens' key")

        imported = 0
        skipped = 0
        errors = 0

        for t in tokens_list:
            try:
                try:
                    pii_type = PIIType(t["pii_type"])
                except ValueError:
                    pii_type = PIIType.CUSTOM
                mapping = TokenMapping(
                    token_id=t["token_id"],
                    token_string=t["token_string"],
                    original_text=t["original_text"],
                    pii_type=pii_type,
                    source_document=t.get("source_document", ""),
                    context_snippet=t.get("context_snippet", ""),
                    created_at=datetime.fromisoformat(t["created_at"]),
                )
                with self._lock:
                    if self._token_string_exists(mapping.token_string):
                        skipped += 1
                        continue
                self.store_token(mapping)
                imported += 1
            except sqlite3.IntegrityError:
                skipped += 1
            except (KeyError, ValueError, TypeError) as exc:
                logger.warning("Failed to import token %s: %s", t.get("token_id", "?"), exc)
                errors += 1

        return {"imported": imported, "skipped": skipped, "errors": errors}

    # -----------------------------------------------------------------------
    # AI prompt helpers
    # -----------------------------------------------------------------------

    # Reverse mapping: letter → human-readable label
    _LETTER_LABEL: dict[str, str] = {
        "P": "Person name",
        "O": "Organization",
        "E": "Email address",
        "T": "Phone number",
        "S": "Social Security Number",
        "C": "Credit card number",
        "D": "Date",
        "A": "Address",
        "L": "Location",
        "I": "IP address",
        "B": "IBAN",
        "X": "Passport number",
        "R": "Driver license",
        "K": "Custom identifier",
        "U": "Unknown PII",
    }

    def get_used_prefixes(
        self,
        source_documents: list[str] | None = None,
    ) -> dict[str, str]:
        """Return {letter: label} for prefix letters actually used in the vault.

        If *source_documents* is given, only consider tokens whose
        ``source_document`` matches one of the provided filenames.
        """
        self._ensure_unlocked()
        with self._lock:
            if self._conn is None:
                raise RuntimeError("Vault database connection not open")
            if source_documents:
                placeholders = ",".join("?" for _ in source_documents)
                query = (
                    f"SELECT DISTINCT token_string FROM tokens "
                    f"WHERE source_document IN ({placeholders})"
                )
                rows = self._conn.execute(query, source_documents).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT DISTINCT token_string FROM tokens"
                ).fetchall()

        # Extract the letter from each token string, e.g. "[P38291]" → "P"
        letters: set[str] = set()
        for (token_string,) in rows:
            if token_string and len(token_string) >= 3 and token_string[0] == "[":
                letters.add(token_string[1])

        return {
            letter: self._LETTER_LABEL.get(letter, "Unknown")
            for letter in sorted(letters)
            if letter in self._LETTER_LABEL
        }

    def close(self) -> None:
        """Close the vault connection."""
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
            self._is_unlocked = False


# Singleton instance
vault = TokenRegistry()
token_registry = vault  # preferred alias

# Backward-compat alias — keeps existing imports working
TokenVault = TokenRegistry
