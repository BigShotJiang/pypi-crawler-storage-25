"""Global application configuration."""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import tempfile
from pathlib import Path

from typing import Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


def _default_data_dir() -> Path:
    """Return the platform-appropriate data directory."""
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif os.uname().sysname == "Darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "doc-anonymizer"


class AppConfig(BaseModel):
    """Application-wide settings — loaded once at startup."""

    # Directories
    data_dir: Path = Field(default_factory=_default_data_dir)
    models_dir: Path = Field(default=None)          # type: ignore[assignment]
    temp_dir: Path = Field(default_factory=lambda: Path(tempfile.gettempdir()) / "doc-anonymizer")
    vault_path: Path = Field(default=None)           # type: ignore[assignment]

    # LLM — local
    llm_model_path: str = ""
    llm_context_size: int = 2048
    llm_gpu_layers: int = 0                           # 0 = CPU only (avoids NaN assertions with mixed GPU/CPU)
    llm_threads: int = 0                              # 0 = auto (use all physical cores)
    llm_batch_size: int = 2048                        # token batch size for llama.cpp
    llm_flash_attn: bool = True                       # use flash attention if supported

    # LLM — remote API (OpenAI-compatible)
    llm_provider: str = "local"                       # "local" | "remote"
    llm_api_url: str = ""                              # e.g. https://api.openai.com/v1
    llm_api_key: str = Field(                          # Bearer token — prefer DOC_ANON_LLM_API_KEY env var
        default_factory=lambda: os.environ.get("DOC_ANON_LLM_API_KEY", ""),
    )
    llm_api_model: str = ""                            # e.g. gpt-4o-mini, claude-sonnet-4-20250514

    # PII Detection thresholds
    regex_enabled: bool = True
    custom_patterns_enabled: bool = True
    ner_enabled: bool = True
    llm_detection_enabled: bool = True
    regex_types: Optional[list[str]] = None   # None = all; e.g. ["EMAIL", "SSN"]
    ner_types: Optional[list[str]] = None     # None = all; e.g. ["PERSON", "ORG"]
    confidence_threshold: float = Field(default=0.55, ge=0.0, le=1.0)
    detection_fuzziness: float = Field(
        default=0.5, ge=0.0, le=1.0,
        description=(
            "Controls how aggressively neighbouring words are grouped into "
            "the same PII region. 0 = strict (only very close words merge), "
            "1 = permissive (wider gaps allowed). The actual pixel threshold "
            "scales with font size and is hard-capped at 20 PDF pts."
        ),
    )

    # Skip text whose rendered height >= this many PDF points.
    # Prevents redacting watermarks, headers, decorative text, etc.
    # 0 = disabled (redact everything regardless of size).
    max_font_size_pt: float = Field(
        default=28.0, ge=0.0,
        description=(
            "Maximum font size (in PDF points, approximated by bbox height) "
            "that the detection pipeline will consider as redactable text. "
            "Text rendered at or above this size — watermarks, large titles, "
            "decorative elements — will be excluded from auto-detection."
        ),
    )

    # NER backend: "auto" auto-selects the best model per detected language,
    # "spacy" uses spaCy models, or set to a HuggingFace model id
    # like "dslim/bert-base-NER" for BERT-based detection.
    ner_backend: str = "auto"

    # When ner_backend == "spacy": which spaCy model to prefer (trf > lg > sm)
    ner_model_preference: str = "trf"                   # trf > lg > sm

    # Language for regex pattern filtering.
    # "auto" = detect per page, specific code ("en","fr",...) = only that language.
    detection_language: str = "auto"

    # Convenience alias — when ner_backend is a HF model id this mirrors it.
    @property
    def ner_hf_model(self) -> str:
        if self.ner_backend in ("spacy", "auto"):
            return "dslim/bert-base-NER"
        return self.ner_backend

    # Auto-load the first available GGUF model at startup
    auto_load_llm: bool = True

    # OCR
    tesseract_cmd: str = ""                            # Empty = auto-detect
    ocr_language: str = "eng"
    ocr_dpi: int = Field(default=300, ge=72, le=1200)

    # Rendering
    render_dpi: int = Field(default=200, ge=72, le=1200)

    # Server
    host: str = "127.0.0.1"
    port: int = Field(default=8910, ge=0, le=65535)   # 0 = random

    # Default directories — user-configurable upload/download paths
    default_upload_dir: str = ""       # Default folder for file uploads (empty = system default)
    default_download_dir: str = ""     # Default folder for protected file downloads (empty = Downloads)
    default_token_backup_dir: str = "" # Default folder for token registry backups (empty = Downloads)
    default_token_restore_dir: str = "" # Default folder for token registry restore (empty = system default)

    # Token format — short tokens: [P38291] = letter prefix + 5 digits
    token_prefix: str = "ANON"
    token_format: str = "[{prefix}_{type}_{hex}]"

    def model_post_init(self, __context: object) -> None:
        if self.models_dir is None:
            self.models_dir = self.data_dir / "models"
        if self.vault_path is None:
            self.vault_path = self.data_dir / "vault.db"

        # Ensure directories exist
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.temp_dir.mkdir(parents=True, exist_ok=True)

        # Load any previously-saved user settings from disk
        self._load_user_settings()

    # ------------------------------------------------------------------
    # Persistence — user-editable settings are saved to a JSON sidecar
    # ------------------------------------------------------------------

    # Keys that are persisted when changed via the API
    _PERSISTABLE_KEYS: set[str] = {
        "regex_enabled", "custom_patterns_enabled", "ner_enabled", "llm_detection_enabled",
        "confidence_threshold", "detection_fuzziness", "max_font_size_pt",
        "ocr_language", "ocr_dpi",
        "render_dpi", "tesseract_cmd",
        "ner_backend", "ner_model_preference", "detection_language",
        "llm_model_path",
        "llm_provider", "llm_api_url", "llm_api_key", "llm_api_model",
        "llm_batch_size", "llm_flash_attn",
        "default_upload_dir", "default_download_dir",
        "default_token_backup_dir", "default_token_restore_dir",
    }

    # Keys containing secrets — encrypted at rest in settings.json
    _SENSITIVE_KEYS: set[str] = {"llm_api_key"}

    # ── Secret encryption helpers ─────────────────────────────

    def _get_key_material(self) -> bytes:
        """Return a 32-byte key derived from a per-install random seed.

        The seed is generated once and stored in ``data_dir/.keyfile``.
        On failure (e.g. read-only FS) the key falls back to a
        deterministic machine-derived value, which is still better
        than storing secrets in plaintext.
        """
        keyfile = self.data_dir / ".keyfile"
        try:
            if keyfile.exists():
                return keyfile.read_bytes()[:32].ljust(32, b"\x00")
            seed = os.urandom(32)
            keyfile.write_bytes(seed)
            # Restrict permissions where possible
            try:
                keyfile.chmod(0o600)
            except OSError:
                pass
            return seed
        except OSError:
            # Fallback: derive from data_dir path (deterministic but unique per install)
            return hashlib.sha256(str(self.data_dir).encode()).digest()

    @staticmethod
    def _encrypt_value(value: str, key: bytes) -> str:
        """Encrypt *value* using PBKDF2-derived XOR keystream."""
        if not value:
            return ""
        salt = os.urandom(16)
        plaintext = value.encode("utf-8")
        derived = hashlib.pbkdf2_hmac("sha256", key, salt, 100_000, dklen=len(plaintext))
        ciphertext = bytes(a ^ b for a, b in zip(plaintext, derived))
        # Prefix with "enc:" so we can distinguish encrypted from legacy plaintext
        return "enc:" + base64.b64encode(salt + ciphertext).decode("ascii")

    @staticmethod
    def _decrypt_value(token: str, key: bytes) -> str:
        """Decrypt a value produced by ``_encrypt_value``."""
        if not token:
            return ""
        if not token.startswith("enc:"):
            # Legacy plaintext — return as-is for backward compatibility
            return token
        raw = base64.b64decode(token[4:])
        salt, ciphertext = raw[:16], raw[16:]
        derived = hashlib.pbkdf2_hmac("sha256", key, salt, 100_000, dklen=len(ciphertext))
        return bytes(a ^ b for a, b in zip(ciphertext, derived)).decode("utf-8")

    @property
    def _settings_path(self) -> Path:
        return self.data_dir / "settings.json"

    def _load_user_settings(self) -> None:
        """Read persisted user settings from disk and apply them."""
        path = self._settings_path
        if not path.exists():
            return
        try:
            key_material = self._get_key_material()
            data = json.loads(path.read_text(encoding="utf-8-sig"))
            for key, value in data.items():
                if key in self._PERSISTABLE_KEYS and hasattr(self, key):
                    # Decrypt sensitive values before coercion
                    if key in self._SENSITIVE_KEYS and isinstance(value, str):
                        value = self._decrypt_value(value, key_material)
                    # Validate/coerce via the field's annotation
                    field_info = self.__class__.model_fields.get(key)
                    if field_info is not None:
                        expected = field_info.annotation
                        try:
                            # Simple type coercion without recursive model_validate
                            # (model_validate triggers model_post_init → infinite loop)
                            if expected is bool:
                                coerced = value if isinstance(value, bool) else str(value).lower() in ("true", "yes", "1")
                            elif expected is int:
                                coerced = int(value)
                            elif expected is float:
                                coerced = float(value)
                            elif expected is str:
                                coerced = str(value) if value is not None else ""
                            else:
                                coerced = value
                            setattr(self, key, coerced)
                        except (ValueError, TypeError):
                            logger.warning("Ignoring invalid setting %s=%r", key, value)
                    else:
                        setattr(self, key, value)
            logger.info("Loaded user settings from %s", path)
        except (OSError, json.JSONDecodeError, KeyError, ValueError) as exc:
            logger.warning("Failed to load settings from %s: %s", path, exc)

    def save_user_settings(self) -> None:
        """Persist current user-editable settings to disk."""
        key_material = self._get_key_material()
        data: dict[str, object] = {}
        for k in self._PERSISTABLE_KEYS:
            if not hasattr(self, k):
                continue
            val = getattr(self, k)
            if k in self._SENSITIVE_KEYS and isinstance(val, str) and val:
                val = self._encrypt_value(val, key_material)
            data[k] = val
        try:
            self._settings_path.write_text(
                json.dumps(data, indent=2, default=str),
                encoding="utf-8",
            )
            logger.info("Saved user settings to %s", self._settings_path)
        except OSError as exc:
            logger.warning("Failed to save settings: %s", exc)


# Singleton — importable from anywhere
config = AppConfig()
