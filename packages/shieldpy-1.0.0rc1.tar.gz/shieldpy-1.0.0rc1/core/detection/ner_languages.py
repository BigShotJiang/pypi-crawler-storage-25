"""Language-specific spaCy NER detection — French, Italian, German, Spanish, Dutch, Portuguese.

This module contains NER model loading and detection functions for all
non-English languages. It is imported by ner_detector.py which provides
the multilingual dispatch and shared utilities.

M8: Modular NER architecture — extracted from ner_detector.py for maintainability.
"""

from __future__ import annotations

import logging
import threading

from models.schemas import PIIType
from core.detection.ner_types import (
    NERMatch,
    LangNERConfig,
    SPACY_FR_LABEL_MAP,
    SPACY_IT_LABEL_MAP,
    SPACY_DE_LABEL_MAP,
    SPACY_ES_LABEL_MAP,
    SPACY_NL_LABEL_MAP,
    SPACY_PT_LABEL_MAP,
)
from core.detection.ner_stopwords import (
    is_french_text,
    is_italian_text,
    is_german_text,
    is_spanish_text,
    is_dutch_text,
    is_portuguese_text,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Shared state (lazy-loaded models)
# ---------------------------------------------------------------------------

# Language models (lazy-loaded)
_nlp_fr = None
_nlp_it = None
_nlp_de = None
_nlp_es = None
_nlp_nl = None
_nlp_pt = None

_active_fr_model_name: str = ""
_active_it_model_name: str = ""
_active_de_model_name: str = ""
_active_es_model_name: str = ""
_active_nl_model_name: str = ""
_active_pt_model_name: str = ""

# Lock protecting lazy model initialisation (all languages)
_model_lock = threading.Lock()

# Model cascades (best → smallest fallback)
_FR_MODEL_CASCADE: list[str] = [
    "fr_core_news_lg",
    "fr_core_news_md",
    "fr_core_news_sm",
]

_IT_MODEL_CASCADE: list[str] = [
    "it_core_news_lg",
    "it_core_news_md",
    "it_core_news_sm",
]

_DE_MODEL_CASCADE: list[str] = [
    "de_core_news_lg",
    "de_core_news_md",
    "de_core_news_sm",
]

_ES_MODEL_CASCADE: list[str] = [
    "es_core_news_lg",
    "es_core_news_md",
    "es_core_news_sm",
]

_NL_MODEL_CASCADE: list[str] = [
    "nl_core_news_lg",
    "nl_core_news_md",
    "nl_core_news_sm",
]

_PT_MODEL_CASCADE: list[str] = [
    "pt_core_news_lg",
    "pt_core_news_md",
    "pt_core_news_sm",
]

# Chunking parameters (in characters)
_CHUNK_SIZE = 100_000
_CHUNK_OVERLAP = 500


# ---------------------------------------------------------------------------
# Shared false-positive helpers (imported from ner_detector for consistency)
# These are re-implemented here since they need the generic stopwords
# ---------------------------------------------------------------------------

_GENERIC_STOPWORDS: set[str] = {
    "q1", "q2", "q3", "q4", "fy", "ytd", "mtd",
    "n/a", "na", "tbd", "tba", "etc", "pdf", "doc",
    "inc", "llc", "ltd", "corp",
    "quarterly", "annual", "monthly", "weekly", "daily",
    "next", "last", "previous", "current", "recent",
    "today", "tomorrow", "yesterday",
    "above", "below", "total", "subtotal", "grand",
}


def _is_false_positive_person_generic(text: str, stopwords: set[str]) -> bool:
    """Generic false-positive check for PERSON entities."""
    txt = text.strip()
    if len(txt) < 2:
        return True
    lower = txt.lower()
    if lower in stopwords:
        return True
    words = lower.split()
    if len(words) == 1:
        if words[0] in _GENERIC_STOPWORDS:
            return True
    return False


def _is_false_positive_org_generic(
    text: str,
    org_stopwords: set[str],
    generic_stopwords: set[str],
) -> bool:
    """Generic false-positive check for ORG entities."""
    txt = text.strip()
    if len(txt) < 2:
        return True
    lower = txt.lower()
    if lower in org_stopwords:
        return True
    words = lower.split()
    if len(words) == 1:
        if words[0] in generic_stopwords:
            return True
    return False


# ---------------------------------------------------------------------------
# Generic chunk processing (duplicated for module independence)
# ---------------------------------------------------------------------------

def _process_chunk_generic(
    nlp,
    text: str,
    global_offset: int,
    cfg: LangNERConfig,
) -> list[NERMatch]:
    """Process a text chunk through NER with configurable label map and filters."""
    doc = nlp(text)
    matches: list[NERMatch] = []

    for ent in doc.ents:
        spacy_label = ent.label_
        pii_type = cfg.label_map.get(spacy_label)
        if pii_type is None:
            continue

        ent_text = ent.text

        # Strip leading articles
        for prefix in cfg.article_prefixes:
            if ent_text.startswith(prefix):
                ent_text = ent_text[len(prefix):]
                break

        ent_text = ent_text.strip()
        if len(ent_text) < 2:
            continue

        # Apply false-positive filters
        if pii_type == PIIType.PERSON and cfg.fp_person and cfg.fp_person(ent_text):
            continue
        if pii_type == PIIType.ORG and cfg.fp_org and cfg.fp_org(ent_text):
            continue

        confidence = _estimate_confidence_generic(ent, pii_type, cfg)

        # Adjust offsets if article was stripped
        start_offset = ent.start_char
        if ent_text != ent.text.strip():
            diff = len(ent.text) - len(ent_text)
            start_offset += diff

        matches.append(NERMatch(
            start=global_offset + start_offset,
            end=global_offset + start_offset + len(ent_text),
            text=ent_text,
            pii_type=pii_type,
            confidence=confidence,
        ))

    return matches


def _estimate_confidence_generic(ent, pii_type: PIIType, cfg: LangNERConfig) -> float:
    """Estimate confidence for a NER match based on entity properties."""
    base = cfg.base_confidence.get(pii_type, 0.50)
    words = ent.text.split()
    word_count = len(words)

    if pii_type == PIIType.PERSON:
        if word_count >= 2:
            base = min(base + 0.10, cfg.person_multiword_cap)
        else:
            base = max(base - cfg.person_single_penalty, 0.40)
    elif pii_type == PIIType.ORG:
        if word_count >= 3:
            base = min(base + 0.15, cfg.org_3word_cap)
        elif word_count == 1:
            base = max(base, cfg.org_single_floor)

    # Model quality boost
    active_model = cfg.active_model_name() if callable(cfg.active_model_name) else ""
    for suffix, boost, cap in cfg.model_boost_tiers:
        if suffix in active_model:
            base = min(base + boost, cap)
            break

    return base


def _deduplicate_matches(matches: list[NERMatch]) -> list[NERMatch]:
    """Remove overlapping/duplicate matches, keeping highest confidence."""
    if not matches:
        return []

    # Sort by start position, then by length (longer first), then by confidence
    sorted_matches = sorted(
        matches,
        key=lambda m: (m.start, -(m.end - m.start), -m.confidence)
    )

    result: list[NERMatch] = []
    last_end = -1

    for m in sorted_matches:
        if m.start >= last_end:
            result.append(m)
            last_end = m.end
        elif m.confidence > result[-1].confidence and m.start == result[-1].start:
            result[-1] = m
            last_end = m.end

    return result


# ---------------------------------------------------------------------------
# French NER
# ---------------------------------------------------------------------------

_FR_PERSON_STOPWORDS: set[str] = {
    "monsieur", "madame", "mademoiselle", "m.", "mme", "mlle",
    "le", "la", "les", "l'", "un", "une", "des",
    "ce", "cette", "ces", "son", "sa", "ses", "leur", "leurs",
    "je", "tu", "il", "elle", "on", "nous", "vous", "ils", "elles",
    "page", "section", "tableau", "figure", "chapitre", "annexe",
    "total", "montant", "solde", "date", "numéro", "numero", "type",
    "janvier", "février", "fevrier", "mars", "avril", "mai", "juin",
    "juillet", "août", "aout", "septembre", "octobre", "novembre", "décembre", "decembre",
    "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche",
    # French financial terms
    "bilan", "actif", "passif", "capitaux", "propres",
    "compte", "résultat", "benefice", "perte",
    "dotation", "amortissement", "amortissements",
    "provision", "provisions",
    "créance", "creance", "créances", "creances",
    "dette", "dettes",
    "résultat", "resultat",
    "location", "acquisition",
    "location-acquisition", "lave-vaisselle",
}

_FR_ORG_STOPWORDS: set[str] = {
    "département", "departement", "service", "bureau", "direction",
    "section", "division", "commission", "comité", "comite",
    "article", "clause", "alinéa", "alinea", "annexe",
    "tableau", "figure", "graphique",
    "loi", "décret", "decret", "arrêté", "arrete", "règlement", "reglement",
    "contrat", "accord", "convention", "rapport", "résumé", "resume",
    "principales", "principaux", "général", "generale", "generaux",
    "comptables", "comptable", "financier", "financiere", "financiers", "financieres",
    "corporelles", "corporels", "corporel", "corporelle",
    "immobilisations", "immobilisation",
    "méthodes", "methodes", "méthode", "methode",
    "statuts", "statut", "nature", "activités", "activites", "activité", "activite",
    "éléments", "elements", "élément", "element",
    "société", "societe", "sociétés", "societes",
    "elles", "ils", "elle", "il", "nous", "vous",
    "je", "tu", "on",
    "excédent", "excedent", "clos", "clôt",
    "taux", "location", "acquisition", "acquisitions",
    "location-acquisition", "lave-vaisselle",
    "dotation", "dotations", "reprise", "reprises",
    "écart", "ecart", "écarts", "ecarts",
    "valeur", "valeurs", "emprunt", "emprunts",
    "titre", "titres", "fonds", "caisse",
    "trésorerie", "tresorerie",
    "recette", "recettes", "facture", "factures",
    "poste", "postes", "créance", "creance",
    "dette", "dettes", "subvention", "subventions",
    "mobilier", "immobilier",
}


def _load_french_model() -> object | None:
    """Lazy-load the best available French spaCy model."""
    global _nlp_fr, _active_fr_model_name
    if _nlp_fr is not None:
        return _nlp_fr

    with _model_lock:
        if _nlp_fr is not None:
            return _nlp_fr

        import spacy

        for model_name in _FR_MODEL_CASCADE:
            try:
                _nlp_fr = spacy.load(model_name)
                _active_fr_model_name = model_name
                logger.info("Loaded French spaCy model '%s'", model_name)
                return _nlp_fr
            except OSError:
                logger.info("French spaCy model '%s' not installed — trying next", model_name)

        logger.warning("No French spaCy model found. Install with: python -m spacy download fr_core_news_lg")
        return None


def is_french_ner_available() -> bool:
    """Check whether a French NER model can be loaded."""
    try:
        return _load_french_model() is not None
    except BaseException:
        return False


def _get_active_fr_model() -> str:
    return _active_fr_model_name


def _is_false_positive_person_fr(text: str) -> bool:
    """Return True if a French PERSON entity is likely a false positive."""
    if _is_false_positive_person_generic(text, _FR_PERSON_STOPWORDS):
        return True
    clean = text.strip()
    words = clean.split()
    if len(words) >= 2:
        first = words[0].lower().rstrip("'\u2019")
        if first in {
            "je", "tu", "il", "elle", "on", "nous", "vous", "ils", "elles",
            "ce", "c", "ça", "cela", "ceci",
        }:
            return True
    return False


def _is_false_positive_org_fr(text: str) -> bool:
    """Return True if a French ORG entity is likely a false positive."""
    if _is_false_positive_org_generic(text, _FR_ORG_STOPWORDS, _GENERIC_STOPWORDS):
        return True
    clean = text.strip()
    words = clean.split()
    if len(words) >= 2:
        first = words[0].lower().rstrip("'\u2019")
        if first in {
            "je", "tu", "il", "elle", "on", "nous", "vous", "ils", "elles",
            "ce", "c", "ça", "cela", "ceci",
        }:
            return True
    return False


_FR_CONFIG = LangNERConfig(
    label_map=SPACY_FR_LABEL_MAP,
    article_prefixes=(
        "le ", "Le ", "la ", "La ", "l'", "L'",
        "les ", "Les ", "un ", "Un ", "une ", "Une ",
    ),
    strip_title_suffixes=False,
    fp_person=_is_false_positive_person_fr,
    fp_org=_is_false_positive_org_fr,
    generic_stopwords_filter=False,
    active_model_name=_get_active_fr_model,
    org_context_prefixes=(
        "société ", "societe ", "sociétés ", "societes ",
    ),
    base_confidence={
        PIIType.PERSON: 0.78, PIIType.ORG: 0.40, PIIType.LOCATION: 0.25,
    },
    person_multiword_cap=0.92,
    org_3word_cap=0.85,
    person_single_penalty=0.18,
    org_single_floor=0.30,
    model_boost_tiers=(("_lg", 0.05, 0.95), ("_md", 0.03, 0.92)),
)


def _process_chunk_fr(nlp, text: str, global_offset: int) -> list[NERMatch]:
    return _process_chunk_generic(nlp, text, global_offset, _FR_CONFIG)


def detect_ner_french(text: str) -> list[NERMatch]:
    """Run French spaCy NER on text."""
    if not is_french_text(text):
        logger.info("Text does not appear to be French — skipping French NER")
        return []

    nlp = _load_french_model()
    if nlp is None:
        logger.info("No French spaCy model available — skipping French NER")
        return []

    if len(text) <= _CHUNK_SIZE:
        return _process_chunk_fr(nlp, text, global_offset=0)

    all_matches: list[NERMatch] = []
    offset = 0
    while offset < len(text):
        end = min(offset + _CHUNK_SIZE, len(text))
        chunk = text[offset:end]
        all_matches.extend(_process_chunk_fr(nlp, chunk, global_offset=offset))
        offset += _CHUNK_SIZE - _CHUNK_OVERLAP
        if end == len(text):
            break

    return _deduplicate_matches(all_matches)


# ---------------------------------------------------------------------------
# Italian NER
# ---------------------------------------------------------------------------

_IT_PERSON_STOPWORDS: set[str] = {
    "signor", "signore", "signora", "signorina", "sig", "dott", "avv",
    "il", "lo", "la", "le", "gli", "un", "uno", "una",
    "di", "del", "della", "dei", "delle", "dello",
    "questo", "questa", "suo", "sua", "loro", "nostro", "nostra",
    "lui", "lei", "noi", "voi", "essi", "esse",
    "pagina", "sezione", "tabella", "figura", "capitolo", "allegato",
    "totale", "importo", "saldo", "data", "numero", "tipo",
    "gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno",
    "luglio", "agosto", "settembre", "ottobre", "novembre", "dicembre",
    "lunedì", "lunedi", "martedì", "martedi", "mercoledì", "mercoledi",
    "giovedì", "giovedi", "venerdì", "venerdi", "sabato", "domenica",
}

_IT_ORG_STOPWORDS: set[str] = {
    "dipartimento", "servizio", "ufficio", "direzione",
    "sezione", "divisione", "commissione", "comitato",
    "articolo", "clausola", "allegato",
    "tabella", "figura", "grafico",
    "legge", "decreto", "ordinanza", "regolamento",
    "contratto", "accordo", "convenzione", "rapporto", "relazione",
}

_SPACY_IT_LABEL_MAP_LOCAL: dict[str, PIIType] = {
    "PER": PIIType.PERSON,
    "ORG": PIIType.ORG,
    "LOC": PIIType.LOCATION,
}


def _load_italian_model() -> object | None:
    """Lazy-load the best available Italian spaCy model."""
    global _nlp_it, _active_it_model_name
    if _nlp_it is not None:
        return _nlp_it

    with _model_lock:
        if _nlp_it is not None:
            return _nlp_it

        import spacy

        for model_name in _IT_MODEL_CASCADE:
            try:
                _nlp_it = spacy.load(model_name)
                _active_it_model_name = model_name
                logger.info("Loaded Italian spaCy model '%s'", model_name)
                return _nlp_it
            except OSError:
                logger.info("Italian spaCy model '%s' not installed — trying next", model_name)

        logger.warning("No Italian spaCy model found. Install with: python -m spacy download it_core_news_lg")
        return None


def is_italian_ner_available() -> bool:
    """Check whether an Italian NER model can be loaded."""
    try:
        return _load_italian_model() is not None
    except BaseException:
        return False


def _get_active_it_model() -> str:
    return _active_it_model_name


def _is_false_positive_person_it(text: str) -> bool:
    """Return True if an Italian PERSON entity is likely a false positive."""
    return _is_false_positive_person_generic(text, _IT_PERSON_STOPWORDS)


def _is_false_positive_org_it(text: str) -> bool:
    """Return True if an Italian ORG entity is likely a false positive."""
    return _is_false_positive_org_generic(text, _IT_ORG_STOPWORDS, _GENERIC_STOPWORDS)


_IT_CONFIG = LangNERConfig(
    label_map=SPACY_IT_LABEL_MAP,
    article_prefixes=(
        "il ", "Il ", "lo ", "Lo ", "la ", "La ", "l'", "L'",
        "le ", "Le ", "gli ", "Gli ", "i ", "I ",
        "un ", "Un ", "uno ", "Uno ", "una ", "Una ",
    ),
    strip_title_suffixes=False,
    fp_person=_is_false_positive_person_it,
    fp_org=_is_false_positive_org_it,
    generic_stopwords_filter=False,
    active_model_name=_get_active_it_model,
    org_context_prefixes=(
        "società ", "societa ",
    ),
    base_confidence={
        PIIType.PERSON: 0.78, PIIType.ORG: 0.40, PIIType.LOCATION: 0.25,
    },
    person_multiword_cap=0.92,
    org_3word_cap=0.85,
    person_single_penalty=0.18,
    org_single_floor=0.30,
    model_boost_tiers=(("_lg", 0.05, 0.95), ("_md", 0.03, 0.92)),
)


def _process_chunk_it(nlp, text: str, global_offset: int) -> list[NERMatch]:
    return _process_chunk_generic(nlp, text, global_offset, _IT_CONFIG)


def detect_ner_italian(text: str) -> list[NERMatch]:
    """Run Italian spaCy NER on text."""
    if not is_italian_text(text):
        logger.info("Text does not appear to be Italian — skipping Italian NER")
        return []

    nlp = _load_italian_model()
    if nlp is None:
        logger.info("No Italian spaCy model available — skipping Italian NER")
        return []

    if len(text) <= _CHUNK_SIZE:
        return _process_chunk_it(nlp, text, global_offset=0)

    all_matches: list[NERMatch] = []
    offset = 0
    while offset < len(text):
        end = min(offset + _CHUNK_SIZE, len(text))
        chunk = text[offset:end]
        all_matches.extend(_process_chunk_it(nlp, chunk, global_offset=offset))
        offset += _CHUNK_SIZE - _CHUNK_OVERLAP
        if end == len(text):
            break

    return _deduplicate_matches(all_matches)


# ---------------------------------------------------------------------------
# German NER
# ---------------------------------------------------------------------------

_DE_PERSON_STOPWORDS: set[str] = {
    "herr", "frau", "doktor", "professor",
    "der", "die", "das", "den", "dem", "des",
    "ein", "eine", "einer", "einem", "einen", "eines",
    "er", "sie", "es", "wir", "ihr",
    "sein", "seine", "seiner", "seinem", "seinen",
    "ihr", "ihre", "ihrem", "ihren", "ihrer",
    "mein", "meine", "meinem", "meinen", "meiner",
    "unser", "unsere", "unserem", "unseren", "unserer",
    "dieser", "diese", "dieses", "diesem", "diesen",
    "seite", "abschnitt", "tabelle", "abbildung", "kapitel", "anhang",
    "gesamt", "betrag", "saldo", "datum", "nummer", "typ",
    "januar", "februar", "märz", "maerz", "april", "mai", "juni",
    "juli", "august", "september", "oktober", "november", "dezember",
    "montag", "dienstag", "mittwoch", "donnerstag", "freitag", "samstag", "sonntag",
    "bilanz", "gewinn", "verlust", "ertrag", "aufwand",
    "abschreibung", "abschreibungen",
    "rückstellung", "rueckstellung", "rückstellungen", "rueckstellungen",
    "vermögen", "vermoegen", "kapital",
    "steuer", "steuern", "dividende", "dividenden",
    "zins", "zinsen", "saldo", "betrag",
    "konto", "konten", "kasse",
    "umsatz", "kosten",
}

_DE_ORG_STOPWORDS: set[str] = {
    "abteilung", "bereich", "referat", "amt",
    "abschnitt", "absatz", "paragraph",
    "tabelle", "abbildung", "grafik", "diagramm",
    "gesetz", "verordnung", "erlass", "satzung", "beschluss",
    "vertrag", "vereinbarung", "abkommen",
    "bericht", "zusammenfassung", "gutachten",
    "bilanz", "gewinn", "verlust", "ertrag", "erträge", "ertraege",
    "aufwand", "aufwendungen", "kosten",
    "abschreibung", "abschreibungen",
    "rückstellung", "rueckstellung",
    "vermögen", "vermoegen",
    "eigenkapital", "fremdkapital",
    "jahresabschluss", "lagebericht",
    "anlage", "anlagen", "anlagevermögen", "anlagevermoegen",
    "umlaufvermögen", "umlaufvermoegen",
    "forderungen", "forderung",
    "verbindlichkeiten", "verbindlichkeit",
    "inventar", "vorräte", "vorraete",
}


def _load_german_model() -> object | None:
    """Lazy-load the best available German spaCy model."""
    global _nlp_de, _active_de_model_name
    if _nlp_de is not None:
        return _nlp_de

    with _model_lock:
        if _nlp_de is not None:
            return _nlp_de

        import spacy

        for model_name in _DE_MODEL_CASCADE:
            try:
                _nlp_de = spacy.load(model_name)
                _active_de_model_name = model_name
                logger.info("Loaded German spaCy model '%s'", model_name)
                return _nlp_de
            except OSError:
                logger.info("German spaCy model '%s' not installed — trying next", model_name)

        logger.warning("No German spaCy model found. Install with: python -m spacy download de_core_news_lg")
        return None


def is_german_ner_available() -> bool:
    """Check whether a German NER model can be loaded."""
    try:
        return _load_german_model() is not None
    except BaseException:
        return False


def _get_active_de_model() -> str:
    return _active_de_model_name


def _is_false_positive_person_de(text: str) -> bool:
    """Return True if a German PERSON entity is likely a false positive."""
    return _is_false_positive_person_generic(text, _DE_PERSON_STOPWORDS)


def _is_false_positive_org_de(text: str) -> bool:
    """Return True if a German ORG entity is likely a false positive."""
    return _is_false_positive_org_generic(text, _DE_ORG_STOPWORDS, _GENERIC_STOPWORDS)


_DE_CONFIG = LangNERConfig(
    label_map=SPACY_DE_LABEL_MAP,
    article_prefixes=(
        "der ", "Der ", "die ", "Die ", "das ", "Das ",
        "ein ", "Ein ", "eine ", "Eine ",
    ),
    strip_title_suffixes=False,
    fp_person=_is_false_positive_person_de,
    fp_org=_is_false_positive_org_de,
    generic_stopwords_filter=False,
    active_model_name=_get_active_de_model,
    base_confidence={
        PIIType.PERSON: 0.78, PIIType.ORG: 0.40, PIIType.LOCATION: 0.25,
    },
    person_multiword_cap=0.92,
    org_3word_cap=0.85,
    person_single_penalty=0.18,
    org_single_floor=0.30,
    model_boost_tiers=(("_lg", 0.05, 0.95), ("_md", 0.03, 0.92)),
)


def _process_chunk_de(nlp, text: str, global_offset: int) -> list[NERMatch]:
    return _process_chunk_generic(nlp, text, global_offset, _DE_CONFIG)


def detect_ner_german(text: str) -> list[NERMatch]:
    """Run German spaCy NER on text."""
    if not is_german_text(text):
        logger.info("Text does not appear to be German — skipping German NER")
        return []

    nlp = _load_german_model()
    if nlp is None:
        logger.info("No German spaCy model available — skipping German NER")
        return []

    if len(text) <= _CHUNK_SIZE:
        return _process_chunk_de(nlp, text, global_offset=0)

    all_matches: list[NERMatch] = []
    offset = 0
    while offset < len(text):
        end = min(offset + _CHUNK_SIZE, len(text))
        chunk = text[offset:end]
        all_matches.extend(_process_chunk_de(nlp, chunk, global_offset=offset))
        offset += _CHUNK_SIZE - _CHUNK_OVERLAP
        if end == len(text):
            break

    return _deduplicate_matches(all_matches)


# ---------------------------------------------------------------------------
# Spanish NER
# ---------------------------------------------------------------------------

_ES_PERSON_STOPWORDS: set[str] = {
    "señor", "senor", "señora", "senora", "señorita", "senorita",
    "don", "doña", "dona",
    "el", "la", "los", "las", "un", "una",
    "él", "ella", "ellos", "ellas", "nosotros", "vosotros",
    "su", "sus", "mi", "mis", "tu", "tus",
    "este", "esta", "estos", "estas",
    "página", "sección", "tabla", "figura", "capítulo", "anexo",
    "total", "importe", "saldo", "fecha", "número", "tipo",
    "enero", "febrero", "marzo", "abril", "mayo", "junio",
    "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre",
    "lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo",
    "balance", "activo", "pasivo", "patrimonio",
    "beneficio", "pérdida", "ingreso",
    "amortización", "depreciación",
    "provisión", "provisiones",
    "deuda", "crédito", "débito",
    "capital", "impuesto", "impuestos",
    "dividendo", "dividendos", "interés", "interes",
}

_ES_ORG_STOPWORDS: set[str] = {
    "departamento", "sección", "seccion", "división", "division",
    "comité", "comite", "junta", "consejo", "comisión", "comision",
    "artículo", "articulo", "cláusula", "clausula", "anexo", "apéndice", "apendice",
    "tabla", "figura", "gráfico", "grafico", "cuadro",
    "ley", "decreto", "reglamento", "ordenanza", "estatuto",
    "contrato", "acuerdo", "convenio",
    "informe", "resumen", "memoria",
    "balance", "activo", "activos", "pasivo", "pasivos",
    "patrimonio", "capital",
    "ingresos", "gastos",
    "beneficio", "beneficios", "pérdida", "perdida", "pérdidas", "perdidas",
    "amortización", "amortizacion",
    "provisión", "provision", "provisiones",
    "ejercicio", "cierre", "consolidado",
    "cuenta", "cuentas", "partida", "partidas",
    "inversión", "inversion", "inversiones",
    "préstamo", "prestamo", "préstamos", "prestamos",
    "inventario", "existencias",
}


def _load_spanish_model() -> object | None:
    """Lazy-load the best available Spanish spaCy model."""
    global _nlp_es, _active_es_model_name
    if _nlp_es is not None:
        return _nlp_es

    with _model_lock:
        if _nlp_es is not None:
            return _nlp_es

        import spacy

        for model_name in _ES_MODEL_CASCADE:
            try:
                _nlp_es = spacy.load(model_name)
                _active_es_model_name = model_name
                logger.info("Loaded Spanish spaCy model '%s'", model_name)
                return _nlp_es
            except OSError:
                logger.info("Spanish spaCy model '%s' not installed — trying next", model_name)

        logger.warning("No Spanish spaCy model found. Install with: python -m spacy download es_core_news_lg")
        return None


def is_spanish_ner_available() -> bool:
    """Check whether a Spanish NER model can be loaded."""
    try:
        return _load_spanish_model() is not None
    except BaseException:
        return False


def _get_active_es_model() -> str:
    return _active_es_model_name


def _is_false_positive_person_es(text: str) -> bool:
    """Return True if a Spanish PERSON entity is likely a false positive."""
    return _is_false_positive_person_generic(text, _ES_PERSON_STOPWORDS)


def _is_false_positive_org_es(text: str) -> bool:
    """Return True if a Spanish ORG entity is likely a false positive."""
    return _is_false_positive_org_generic(text, _ES_ORG_STOPWORDS, _GENERIC_STOPWORDS)


_ES_CONFIG = LangNERConfig(
    label_map=SPACY_ES_LABEL_MAP,
    article_prefixes=(
        "el ", "El ", "la ", "La ", "los ", "Los ", "las ", "Las ",
        "un ", "Un ", "una ", "Una ",
    ),
    strip_title_suffixes=False,
    fp_person=_is_false_positive_person_es,
    fp_org=_is_false_positive_org_es,
    generic_stopwords_filter=False,
    active_model_name=_get_active_es_model,
    org_context_prefixes=(
        "sociedad ",
    ),
    base_confidence={
        PIIType.PERSON: 0.78, PIIType.ORG: 0.40, PIIType.LOCATION: 0.25,
    },
    person_multiword_cap=0.92,
    org_3word_cap=0.85,
    person_single_penalty=0.18,
    org_single_floor=0.30,
    model_boost_tiers=(("_lg", 0.05, 0.95), ("_md", 0.03, 0.92)),
)


def _process_chunk_es(nlp, text: str, global_offset: int) -> list[NERMatch]:
    return _process_chunk_generic(nlp, text, global_offset, _ES_CONFIG)


def detect_ner_spanish(text: str) -> list[NERMatch]:
    """Run Spanish spaCy NER on text."""
    if not is_spanish_text(text):
        logger.info("Text does not appear to be Spanish — skipping Spanish NER")
        return []

    nlp = _load_spanish_model()
    if nlp is None:
        logger.info("No Spanish spaCy model available — skipping Spanish NER")
        return []

    if len(text) <= _CHUNK_SIZE:
        return _process_chunk_es(nlp, text, global_offset=0)

    all_matches: list[NERMatch] = []
    offset = 0
    while offset < len(text):
        end = min(offset + _CHUNK_SIZE, len(text))
        chunk = text[offset:end]
        all_matches.extend(_process_chunk_es(nlp, chunk, global_offset=offset))
        offset += _CHUNK_SIZE - _CHUNK_OVERLAP
        if end == len(text):
            break

    return _deduplicate_matches(all_matches)


# ---------------------------------------------------------------------------
# Dutch NER
# ---------------------------------------------------------------------------

_NL_PERSON_STOPWORDS: set[str] = {
    "de", "het", "een",
    "meneer", "mevrouw", "mijnheer",
    "hij", "zij", "wij", "jullie", "hen", "haar",
    "zijn", "haar", "hun", "ons", "onze",
    "mijn", "jouw", "uw",
    "dit", "dat", "deze", "die",
    "pagina", "sectie", "tabel", "figuur", "hoofdstuk", "bijlage",
    "totaal", "bedrag", "saldo", "datum", "nummer", "type",
    "januari", "februari", "maart", "april", "mei", "juni",
    "juli", "augustus", "september", "oktober", "november", "december",
    "maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag", "zondag",
    "balans", "activa", "passiva", "vermogen",
    "winst", "verlies", "omzet",
    "afschrijving", "afschrijvingen",
    "voorziening", "voorzieningen",
    "schuld", "schulden", "vordering", "vorderingen",
    "kapitaal", "belasting", "belastingen",
    "dividend", "rente",
    "resultaat", "resultaten",
}

_NL_ORG_STOPWORDS: set[str] = {
    "afdeling", "sectie", "divisie",
    "commissie", "bestuur", "raad", "comité", "comite",
    "artikel", "clausule", "bijlage", "appendix",
    "tabel", "figuur", "grafiek", "diagram", "overzicht",
    "wet", "verordening", "statuut", "besluit", "reglement",
    "overeenkomst", "contract", "verdrag",
    "verslag", "samenvatting", "rapport",
    "balans", "activa", "passiva",
    "eigen", "vermogen", "vreemd",
    "winst", "verlies", "omzet",
    "afschrijving", "afschrijvingen",
    "voorziening", "voorzieningen",
    "jaarrekening", "boekjaar",
    "vordering", "vorderingen",
    "schuld", "schulden",
    "investering", "investeringen",
    "lening", "leningen",
    "voorraad", "voorraden",
}


def _load_dutch_model() -> object | None:
    """Lazy-load the best available Dutch spaCy model."""
    global _nlp_nl, _active_nl_model_name
    if _nlp_nl is not None:
        return _nlp_nl

    with _model_lock:
        if _nlp_nl is not None:
            return _nlp_nl

        import spacy

        for model_name in _NL_MODEL_CASCADE:
            try:
                _nlp_nl = spacy.load(model_name)
                _active_nl_model_name = model_name
                logger.info("Loaded Dutch spaCy model '%s'", model_name)
                return _nlp_nl
            except OSError:
                logger.info("Dutch spaCy model '%s' not installed — trying next", model_name)

        logger.warning("No Dutch spaCy model found. Install with: python -m spacy download nl_core_news_lg")
        return None


def is_dutch_ner_available() -> bool:
    """Check whether a Dutch NER model can be loaded."""
    try:
        return _load_dutch_model() is not None
    except BaseException:
        return False


def _get_active_nl_model() -> str:
    return _active_nl_model_name


def _is_false_positive_person_nl(text: str) -> bool:
    """Return True if a Dutch PERSON entity is likely a false positive."""
    return _is_false_positive_person_generic(text, _NL_PERSON_STOPWORDS)


def _is_false_positive_org_nl(text: str) -> bool:
    """Return True if a Dutch ORG entity is likely a false positive."""
    return _is_false_positive_org_generic(text, _NL_ORG_STOPWORDS, _GENERIC_STOPWORDS)


_NL_CONFIG = LangNERConfig(
    label_map=SPACY_NL_LABEL_MAP,
    article_prefixes=(
        "de ", "De ", "het ", "Het ",
        "een ", "Een ",
    ),
    strip_title_suffixes=False,
    fp_person=_is_false_positive_person_nl,
    fp_org=_is_false_positive_org_nl,
    generic_stopwords_filter=False,
    active_model_name=_get_active_nl_model,
    base_confidence={
        PIIType.PERSON: 0.78, PIIType.ORG: 0.40, PIIType.LOCATION: 0.25,
    },
    person_multiword_cap=0.92,
    org_3word_cap=0.85,
    person_single_penalty=0.18,
    org_single_floor=0.30,
    model_boost_tiers=(("_lg", 0.05, 0.95), ("_md", 0.03, 0.92)),
)


def _process_chunk_nl(nlp, text: str, global_offset: int) -> list[NERMatch]:
    return _process_chunk_generic(nlp, text, global_offset, _NL_CONFIG)


def detect_ner_dutch(text: str) -> list[NERMatch]:
    """Run Dutch spaCy NER on text."""
    if not is_dutch_text(text):
        logger.info("Text does not appear to be Dutch — skipping Dutch NER")
        return []

    nlp = _load_dutch_model()
    if nlp is None:
        logger.info("No Dutch spaCy model available — skipping Dutch NER")
        return []

    if len(text) <= _CHUNK_SIZE:
        return _process_chunk_nl(nlp, text, global_offset=0)

    all_matches: list[NERMatch] = []
    offset = 0
    while offset < len(text):
        end = min(offset + _CHUNK_SIZE, len(text))
        chunk = text[offset:end]
        all_matches.extend(_process_chunk_nl(nlp, chunk, global_offset=offset))
        offset += _CHUNK_SIZE - _CHUNK_OVERLAP
        if end == len(text):
            break

    return _deduplicate_matches(all_matches)


# ---------------------------------------------------------------------------
# Portuguese NER
# ---------------------------------------------------------------------------

_PT_PERSON_STOPWORDS: set[str] = {
    "o", "a", "os", "as",
    "senhor", "senhora", "sr", "sra", "dr", "dra",
    "ele", "ela", "eles", "elas", "nós", "vós",
    "seu", "sua", "seus", "suas",
    "meu", "minha", "meus", "minhas",
    "este", "esta", "estes", "estas",
    "isso", "isto", "aquilo",
    "página", "seção", "tabela", "figura", "capítulo", "anexo",
    "total", "valor", "saldo", "data", "número", "tipo",
    "janeiro", "fevereiro", "março", "abril", "maio", "junho",
    "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
    "segunda", "terça", "quarta", "quinta", "sexta", "sábado", "domingo",
    "balanço", "ativo", "passivo", "patrimônio",
    "lucro", "prejuízo", "receita",
    "depreciação", "amortização",
    "provisão", "provisões",
    "dívida", "crédito", "débito",
    "capital", "imposto", "impostos",
    "dividendo", "juro", "juros",
    "resultado", "resultados",
}

_PT_ORG_STOPWORDS: set[str] = {
    "departamento", "seção", "divisão",
    "comissão", "diretoria", "conselho", "comitê",
    "artigo", "cláusula", "anexo", "apêndice",
    "tabela", "figura", "gráfico", "diagrama", "resumo",
    "lei", "decreto", "estatuto", "regulamento",
    "acordo", "contrato", "tratado",
    "relatório", "sumário",
    "balanço", "ativo", "passivo",
    "patrimônio", "líquido",
    "lucro", "prejuízo", "receita",
    "depreciação", "amortização",
    "provisão", "provisões",
    "demonstração", "financeira",
    "exercício", "período",
    "crédito", "débito",
    "dívida", "dívidas",
    "investimento", "investimentos",
    "empréstimo", "empréstimos",
    "estoque", "estoques",
}


def _load_portuguese_model() -> object | None:
    """Lazy-load the best available Portuguese spaCy model."""
    global _nlp_pt, _active_pt_model_name
    if _nlp_pt is not None:
        return _nlp_pt

    with _model_lock:
        if _nlp_pt is not None:
            return _nlp_pt

        import spacy

        for model_name in _PT_MODEL_CASCADE:
            try:
                _nlp_pt = spacy.load(model_name)
                _active_pt_model_name = model_name
                logger.info("Loaded Portuguese spaCy model '%s'", model_name)
                return _nlp_pt
            except OSError:
                logger.info("Portuguese spaCy model '%s' not installed — trying next", model_name)

        logger.warning("No Portuguese spaCy model found. Install with: python -m spacy download pt_core_news_lg")
        return None


def is_portuguese_ner_available() -> bool:
    """Check whether a Portuguese NER model can be loaded."""
    try:
        return _load_portuguese_model() is not None
    except BaseException:
        return False


def _get_active_pt_model() -> str:
    return _active_pt_model_name


def _is_false_positive_person_pt(text: str) -> bool:
    """Return True if a Portuguese PERSON entity is likely a false positive."""
    return _is_false_positive_person_generic(text, _PT_PERSON_STOPWORDS)


def _is_false_positive_org_pt(text: str) -> bool:
    """Return True if a Portuguese ORG entity is likely a false positive."""
    return _is_false_positive_org_generic(text, _PT_ORG_STOPWORDS, _GENERIC_STOPWORDS)


_PT_CONFIG = LangNERConfig(
    label_map=SPACY_PT_LABEL_MAP,
    article_prefixes=(
        "o ", "O ", "a ", "A ", "os ", "Os ", "as ", "As ",
        "um ", "Um ", "uma ", "Uma ",
    ),
    strip_title_suffixes=False,
    fp_person=_is_false_positive_person_pt,
    fp_org=_is_false_positive_org_pt,
    generic_stopwords_filter=False,
    active_model_name=_get_active_pt_model,
    base_confidence={
        PIIType.PERSON: 0.78, PIIType.ORG: 0.40, PIIType.LOCATION: 0.25,
    },
    person_multiword_cap=0.92,
    org_3word_cap=0.85,
    person_single_penalty=0.18,
    org_single_floor=0.30,
    model_boost_tiers=(("_lg", 0.05, 0.95), ("_md", 0.03, 0.92)),
)


def _process_chunk_pt(nlp, text: str, global_offset: int) -> list[NERMatch]:
    return _process_chunk_generic(nlp, text, global_offset, _PT_CONFIG)


def detect_ner_portuguese(text: str) -> list[NERMatch]:
    """Run Portuguese spaCy NER on text."""
    if not is_portuguese_text(text):
        logger.info("Text does not appear to be Portuguese — skipping Portuguese NER")
        return []

    nlp = _load_portuguese_model()
    if nlp is None:
        logger.info("No Portuguese spaCy model available — skipping Portuguese NER")
        return []

    if len(text) <= _CHUNK_SIZE:
        return _process_chunk_pt(nlp, text, global_offset=0)

    all_matches: list[NERMatch] = []
    offset = 0
    while offset < len(text):
        end = min(offset + _CHUNK_SIZE, len(text))
        chunk = text[offset:end]
        all_matches.extend(_process_chunk_pt(nlp, chunk, global_offset=offset))
        offset += _CHUNK_SIZE - _CHUNK_OVERLAP
        if end == len(text):
            break

    return _deduplicate_matches(all_matches)


# ---------------------------------------------------------------------------
# Unified unload for all language models
# ---------------------------------------------------------------------------

def unload_language_models() -> None:
    """Free memory held by all loaded language-specific spaCy NER models."""
    global _nlp_fr, _active_fr_model_name
    global _nlp_it, _active_it_model_name
    global _nlp_de, _active_de_model_name
    global _nlp_es, _active_es_model_name
    global _nlp_nl, _active_nl_model_name
    global _nlp_pt, _active_pt_model_name
    with _model_lock:
        _nlp_fr = None
        _active_fr_model_name = ""
        _nlp_it = None
        _active_it_model_name = ""
        _nlp_de = None
        _active_de_model_name = ""
        _nlp_es = None
        _active_es_model_name = ""
        _nlp_nl = None
        _active_nl_model_name = ""
        _nlp_pt = None
        _active_pt_model_name = ""
    logger.info("Language-specific spaCy NER models unloaded")
