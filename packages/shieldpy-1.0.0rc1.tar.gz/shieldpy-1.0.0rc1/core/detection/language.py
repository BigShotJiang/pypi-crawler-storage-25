"""Lightweight stop-word-based language detection for PII pipeline.

Detects: English (en), Spanish (es), French (fr), German (de),
Italian (it), Dutch (nl), Portuguese (pt).  Falls back to ``"en"``
for very short texts or languages outside the supported set.
"""

from __future__ import annotations

import logging
import re

logger = logging.getLogger(__name__)

# Languages supported by the auto-switching NER backend.
SUPPORTED_LANGUAGES = ("en", "es", "fr", "de", "it", "nl", "pt")

# Model routing for auto mode
AUTO_MODEL_ENGLISH = "Isotonic/distilbert_finetuned_ai4privacy_v2"
AUTO_MODEL_MULTILINGUAL = "iiiorg/piiranha-v1-detect-personal-information"
AUTO_MODEL_PORTUGUESE = "Babelscape/wikineural-multilingual-ner"

_SAMPLE_SIZE = 10_000         # chars to sample (large enough for multi-page)
_MIN_WORDS = 12               # need this many tokens to judge
_THRESHOLD = 0.08             # 8 % stop-word ratio to claim a language
_AMBIGUITY_MARGIN = 0.02      # if gap between #1 and #2 < 2 %, flag ambiguous

# Regex to strip anonymization tokens like [P00001], [A12345], etc.
_TOKEN_RE = re.compile(r"\[[A-Z]\d{3,6}\]")

# ---------------------------------------------------------------------------
# Stop-word sets (top ~80 function words per language)
#
# Emphasis on *discriminator words* — tokens that appear in only one or two
# of the seven supported languages.  Shared Romance function words
# ("de", "en", "a", "un", …) are still included but the discriminators
# boost the correct language above its neighbours.
# ---------------------------------------------------------------------------

_STOP: dict[str, frozenset[str]] = {
    "en": frozenset({
        # Core function words
        "the", "be", "to", "of", "and", "a", "in", "that", "have", "i",
        "it", "for", "not", "on", "with", "he", "as", "you", "do", "at",
        "this", "but", "his", "by", "from", "they", "we", "her", "she",
        "or", "an", "will", "my", "one", "all", "would", "there", "their",
        "what", "so", "if", "about", "who", "which", "when", "can", "no",
        "just", "him", "know", "into", "your", "some", "could", "them",
        "than", "then", "its", "over", "also", "after", "how", "our",
        "well", "even", "because", "any", "these", "us", "out", "was",
        "were", "been", "being", "had", "has", "did", "are", "is", "am",
        # Discriminators (rarely shared with Romance / Germanic neighbours)
        "should", "shall", "might", "must", "where", "here", "while",
        "before", "again", "each", "only", "other", "those", "own",
        "through", "between", "above", "below", "such", "both", "same",
    }),
    "es": frozenset({
        "de", "la", "que", "el", "en", "y", "a", "los", "del", "se",
        "las", "por", "un", "para", "con", "no", "una", "su", "al", "lo",
        "como", "pero", "sus", "le", "ya", "o", "este", "entre", "cuando",
        "muy", "sin", "sobre", "me", "hasta", "hay", "donde", "quien",
        "desde", "todo", "nos", "durante", "todos", "uno", "les", "ni",
        "contra", "otros", "ese", "eso", "ante", "ellos", "esto", "antes",
        "algunos", "unos", "yo", "otro", "otras", "otra", "tanto", "esa",
        "estos", "esta", "fue", "son", "tiene", "ser", "han", "era",
        # Discriminators
        "puede", "sido", "cada", "parte", "gobierno", "tiempo",
        "hoy", "entonces", "sino", "siendo", "hacia", "estaba",
    }),
    "fr": frozenset({
        "de", "la", "le", "et", "les", "des", "en", "un", "du", "une",
        "que", "est", "dans", "qui", "par", "pour", "au", "il", "sur",
        "ne", "se", "pas", "plus", "son", "ce", "avec", "ou", "mais",
        "sont", "sa", "aux", "ont", "ses", "cette", "comme", "nous",
        "tout", "aussi", "elle", "fait", "ces", "entre", "dont", "leur",
        "bien", "peut", "tous", "sans", "je", "lui", "donc", "encore",
        "avant", "depuis", "nos", "deux", "fois", "avait", "sur",
        # Discriminators — uniquely or near-uniquely French
        "puis", "chez", "autres", "moins", "cela", "quand", "ainsi",
        "toujours", "jamais", "vers", "alors", "rien", "avoir",
        "tre", "soit", "peu", "mois", "doit", "celui",
    }),
    "de": frozenset({
        "der", "die", "und", "in", "den", "von", "zu", "das", "mit",
        "sich", "des", "auf", "ist", "im", "dem", "nicht", "ein",
        "eine", "als", "auch", "es", "an", "werden", "aus", "er", "hat",
        "dass", "sie", "nach", "wird", "bei", "einer", "um", "am", "sind",
        "noch", "wie", "einem", "so", "zum", "aber", "ihr", "nur",
        "oder", "mir", "war", "mich", "gegen", "vom", "wenn", "durch",
        "dann", "unter", "sehr", "selbst", "schon", "hier", "bis", "alle",
        "diese", "mehr", "da", "wo", "kann", "haben", "sein",
        # Discriminators — uniquely German
        "weil", "zwischen", "wieder", "wurde", "jedoch", "bereits",
        "muss", "immer", "keine", "seinen", "seiner", "andere",
    }),
    "it": frozenset({
        "di", "che", "la", "il", "un", "a", "per", "in", "una", "mi",
        "ma", "lo", "ha", "le", "si", "ho", "non", "con", "li", "da",
        "se", "no", "come", "io", "ci", "questo", "dei", "nel", "del",
        "al", "sono", "era", "gli", "suo", "anche", "alla", "dei",
        "tutto", "della", "fatto", "dal", "stata", "ancora", "dopo",
        "essere", "quella", "fare", "qui", "dove", "suo", "sua",
        "stato", "loro", "questa", "tra", "hai", "poi", "abbiamo",
        # Discriminators — uniquely Italian
        "perche", "quando", "sulla", "delle", "negli", "nelle",
        "ogni", "sempre", "molto", "quale", "cosa", "prima",
    }),
    "nl": frozenset({
        "de", "het", "een", "van", "en", "in", "is", "dat", "op", "te",
        "zijn", "voor", "met", "die", "niet", "er", "aan", "ook", "als",
        "maar", "om", "bij", "dan", "nog", "naar", "heeft", "ze", "uit",
        "kan", "dit", "was", "worden", "al", "wel", "over", "door", "tot",
        "veel", "meer", "had", "haar", "wat", "zou", "hun", "geen", "werd",
        "wij", "heb", "moet", "ons", "dag", "twee", "zo", "alle", "hij",
        # Discriminators — uniquely Dutch
        "wordt", "alleen", "waar", "onder", "omdat", "nieuwe", "andere",
        "tussen", "grote", "eerste", "kunnen", "goed", "mensen",
    }),
    "pt": frozenset({
        "de", "a", "o", "que", "e", "do", "da", "em", "um", "para",
        "com", "uma", "os", "no", "se", "na", "por", "mais", "as",
        "dos", "como", "mas", "foi", "ao", "ele", "das", "tem", "seu",
        "sua", "ou", "ser", "quando", "muito", "nos", "eu",
        "pelo", "pela", "ela", "entre",
        "era", "depois", "sem", "mesmo", "aos", "ter", "seus", "quem",
        "nas", "me", "esse", "eles", "foram",
        "essa", "num", "nem", "suas", "meu", "minha", "numa", "pelos",
        # Discriminators — uniquely Portuguese
        "ainda", "onde", "pode", "outro", "outra", "tinha", "aqui",
        "desde", "apenas", "sobre", "sendo", "nossa", "nosso",
    }),
}


def detect_language(text: str) -> str:
    """Return the ISO-639-1 code of the most-likely language.

    Uses stop-word frequency analysis on a sample of the text.
    Returns ``"en"`` as a safe default when the text is too short
    or no language reaches the threshold.

    Robustness measures
    -------------------
    * Strips anonymization tokens (``[X00000]``) before analysis so
      tokenised documents don't pollute the word list.
    * Samples up to 10 000 chars for multi-page documents.
    * Logs the top-2 candidates with ratios for easy debugging.
    * Flags ambiguous detections when the gap between #1 and #2 is < 2 %.
    """
    # 1. Strip anonymisation tokens that would dilute real words
    clean = _TOKEN_RE.sub(" ", text)

    sample = clean[:_SAMPLE_SIZE]
    words = [w.lower().strip(".,;:!?()[]{}\"'""''«»—–-/\\") for w in sample.split()]
    # Keep words ≥ 2 chars; discard pure numbers / numeric codes
    words = [w for w in words if len(w) >= 2 and not w.isdigit()]

    if len(words) < _MIN_WORDS:
        logger.info(
            "Language detection: defaulting to 'en' (only %d words, need %d)",
            len(words), _MIN_WORDS,
        )
        return "en"  # too short to judge — default English

    n = len(words)
    scores: list[tuple[str, float]] = []

    for lang, stops in _STOP.items():
        hits = sum(1 for w in words if w in stops)
        ratio = hits / n
        scores.append((lang, ratio))

    # Sort descending by ratio
    scores.sort(key=lambda x: x[1], reverse=True)
    best_lang, best_ratio = scores[0]
    second_lang, second_ratio = scores[1]
    margin = best_ratio - second_ratio

    # Log top-2 for debugging
    logger.info(
        "Language detection: #1 %s (%.1f%%), #2 %s (%.1f%%), margin %.1f%%, "
        "%d words sampled",
        best_lang, best_ratio * 100,
        second_lang, second_ratio * 100,
        margin * 100, n,
    )

    if best_ratio < _THRESHOLD:
        logger.warning(
            "Language detection: best score %.1f%% below threshold %.0f%% "
            "— defaulting to 'en'",
            best_ratio * 100, _THRESHOLD * 100,
        )
        return "en"

    if margin < _AMBIGUITY_MARGIN:
        logger.warning(
            "Language detection: ambiguous — %s (%.1f%%) vs %s (%.1f%%), "
            "margin only %.1f%%.  Accepting %s but confidence is low.",
            best_lang, best_ratio * 100,
            second_lang, second_ratio * 100,
            margin * 100, best_lang,
        )

    return best_lang


def resolve_auto_model(text: str) -> tuple[str, str]:
    """Pick the best NER model for *text* when ``ner_backend == "auto"``.

    Returns ``(model_id, detected_language_code)``.
    """
    lang = detect_language(text)
    if lang == "en":
        return AUTO_MODEL_ENGLISH, lang
    elif lang == "pt":
        # Piiranha was not trained on Portuguese; WikiNEural covers PT
        return AUTO_MODEL_PORTUGUESE, lang
    else:
        return AUTO_MODEL_MULTILINGUAL, lang
