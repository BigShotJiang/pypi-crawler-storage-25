"""LOC and PERSON noise filters.

Extracted from ``noise_filters.py`` to keep the parent module under ~400 LOC.
Imports shared infrastructure (stemmers, encoding fixers, dictionary loaders)
from ``noise_filters``, and noise-word data from ``_noise_data``.

Lazy globals ``_common_words`` / ``_german_words`` are bound at first call
via local assignment inside the functions that need them (not at module
level) to avoid loading 30 k-word dictionaries on import.
"""

from __future__ import annotations

import re as _re

from core.detection import detection_config as det_cfg
from core.text_utils import remove_accents as _remove_accents
from core.detection.noise_filters import (
    _get_common_words,
    _get_german_words,
    _stem_word,
    _fix_double_utf8,
    _fix_pdf_encoding,
    has_legal_suffix,
    LEGAL_SUFFIX_RE,
    _ARTICLE_PREFIX_RE,
)
from core.detection._noise_data import (
    _LOC_PIPELINE_NOISE,
    _PERSON_PIPELINE_NOISE,
)


def _is_loc_pipeline_noise(text: str) -> bool:
    """Return True if *text* looks like a noisy LOCATION false-positive.

    Uses language dictionaries for vocabulary checks — same approach as
    the ORG and PERSON filters.  Structural rules cover:
      • apostrophe contractions (l'emplacement, d'outre-mer)
      • single-word dictionary words (localement, régions)
      • hyphenated compounds (outre-mer)
      • multi-word all-dictionary phrases (Province / Territoire)
      • trailing colon form labels
    """
    _common_words = _get_common_words()
    clean = text.strip()
    low = clean.lower()
    if low in _LOC_PIPELINE_NOISE:
        return True
    if len(clean) <= det_cfg.FP_MIN_TEXT_LENGTH:
        return True
    if clean.isdigit():
        return True
    if clean and clean[0].isdigit():
        return True
    if _re.match(r"^location\s+(?:de|d[''\u2019])", low):
        return True
    # Trailing colon → form label ("Pays :", "Province :")
    if clean.rstrip().endswith(':'):
        return True
    # URL / hostname → not a location
    if _re.search(r'(?:www\.|https?://|[a-z0-9]+\.[a-z]{2,})', low):
        return True

    # ── Apostrophe contraction stripping: l'…, d'… ──────────────
    # Handled separately because there is no space after the
    # apostrophe (e.g. "l'emplacement", "d'outre-mer").
    _cont = _re.sub(r"^[LlDd][''\u2019]\s*", "", clean)
    if _cont and _cont != clean:
        _cont_low = _cont.lower()
        if _cont_low in _LOC_PIPELINE_NOISE:
            return True
        if _cont_low in _common_words:
            return True
        na = _remove_accents(_cont_low)
        if na != _cont_low and na in _common_words:
            return True
        for stem in _stem_word(_cont_low):
            if stem in _common_words:
                return True

    # ── Space-separated article/preposition stripping ────────────
    _stripped = _re.sub(
        r"^(?:[Ll][eao]s?|[Dd][eiu]s?|[Uu]n[ea]?"  # FR
        r"|[Ee]l|[Ll]os|[Ll]as"  # ES
        r"|[Ii]l|[Gg]li|[Ll][oae]|[Uu]n[oa]?"  # IT
        r"|[Dd][aeo]s?|[Oo]s?|[Aa]s?"  # PT
        r"|[Dd](?:er|ie|as|en|em|es)|[Ee]in[e]?"  # DE
        r"|[Hh]et|[Dd]e|[Ee]en"  # NL
        r")\s+", "", clean)
    if _stripped and _stripped != clean:
        _s_low = _stripped.lower()
        if _s_low in _LOC_PIPELINE_NOISE:
            return True
        # After stripping article, check dictionary for remaining word
        if len(_stripped.split()) == 1:
            if _s_low in _common_words:
                return True
            na = _remove_accents(_s_low)
            if na != _s_low and na in _common_words:
                return True
            for stem in _stem_word(_s_low):
                if stem in _common_words:
                    return True

    words = clean.split()

    # ── Single-word checks ───────────────────────────────────────
    if len(words) == 1:
        # ALL-UPPERCASE single word → header/label (e.g. "PAYS")
        if clean.isupper():
            return True
        # Lowercase single word in dictionary → common noun, never
        # a proper location (locations are always capitalised).
        if clean == clean.lower():
            if low in _common_words:
                return True
            na = _remove_accents(low)
            if na != low and na in _common_words:
                return True
            for stem in _stem_word(low):
                if stem in _common_words:
                    return True
        # Hyphenated compounds: "outre-mer" → check each part
        if '-' in clean:
            parts = [p for p in clean.split('-') if p]
            if len(parts) >= 2 and all(p.lower() in _common_words for p in parts):
                return True

    # ── Multi-word checks ──────────────────────────────────────────
    # NOTE: Unlike ORG/PERSON, location names often consist entirely
    # of common words ("New York City", "Salt Lake City", "Cape Town").
    # The all-dictionary check must therefore be more conservative.

    # Words all in the explicit noise set (with punct pass-through)
    if len(words) >= 2 and all(
        w.lower() in _LOC_PIPELINE_NOISE
        or w.isdigit()
        or all(c in "-\u2013\u2014/." for c in w)
        for w in words
    ):
        return True
    # ALL-UPPERCASE multi-word where all words are common vocabulary
    # → financial/legal headers ("PROTÉGÉ B", "BIENS IMMOBILIERS")
    if len(words) >= 2 and clean.isupper():
        if all(
            w.lower() in _common_words
            or w.isdigit()
            or len(w) == 1
            or all(c in "-\u2013\u2014/." for c in w)
            for w in words
        ):
            return True
    # Multi-word with punctuation separator (/.) where all content
    # words are common vocabulary: "Province / Territoire"
    if len(words) >= 2:
        _punct_w = [w for w in words if all(c in "/.\u2013\u2014" for c in w)]
        if _punct_w:
            _content_w = [w for w in words if w not in _punct_w]
            if _content_w and all(
                w.lower() in _common_words or w.isdigit() or len(w) == 1
                for w in _content_w
            ):
                return True
    # Multi-word (≥3 words) where ≥ half of content words start
    # lowercase → descriptive phrase, not a proper location.
    # Content words = words > 2 chars (skips articles/prepositions).
    # Covers: "Responsable local ou régional",
    #         "Installation de mouillages"
    if len(words) >= 3:
        _cw = [w for w in words if len(w) > 2]
        if _cw:
            _lc = sum(1 for w in _cw if w[0].islower())
            if _lc >= len(_cw) * 0.5:
                return True
    # All-lowercase multi-word phrase → common noun, not a proper location
    if len(words) >= 2 and clean == clean.lower():
        return True
    # Multi-word phrase starting with a lowercase word (adjective/article)
    # is almost never a proper location name.
    # E.g. "großen Stadiongelände", "deutschen Profivereine"
    if len(words) >= 2 and words[0][0].islower():
        return True
    return False


# ── PERSON noise ──────────────────────────────────────────────────────────

# Common first names (≤6 chars) ending in consonants that should NOT
# be suppressed by the short-name consonant heuristic (H10).
_PERSON_SHORT_NAME_WHITELIST: frozenset[str] = frozenset({
    # English
    "frank", "clark", "james", "david", "peter", "roger",
    "brian", "kevin", "robin", "jason", "grant", "jacob",
    "simon", "carol", "karen", "susan", "ellen", "helen",
    "janet", "sarah", "chris", "scott", "bruce", "ralph",
    # German
    "ernst", "heinz", "horst", "lukas", "niklas", "franz",
    "klaus", "armin", "bernd", "edgar", "erich", "eugen",
    "gerd", "kurt", "uwe", "lars", "sven", "hans",
    # French
    "alain", "henri", "louis", "denis", "yves",
    "jean", "marc", "paul",
    # Spanish
    "oscar", "jesus", "angel",
    # Dutch
    "ruben", "sander",
    # Portuguese
    "rui", "abel", "joel",
})




# ── German compound-word decomposition ────────────────────────────────────
# German creates compound nouns by concatenation (Haupt+Mieter → Hauptmieter).
# wordfreq dictionaries miss most compounds.  If a single word can be split
# into two known dictionary parts (with optional Fugen-element s/es/n/en/er/e)
# it is almost certainly a common noun, not a person name.

_FUGENLAUTE = det_cfg.GERMAN_FUGENLAUTE  # longest-first


def _is_german_compound_noun(word: str) -> bool:
    """Return True if *word* is a German compound of 2+ dictionary parts.

    Works by trying every split of the (lowercased, optionally inflection-
    stripped) form and checking left ∈ dict and right ∈ dict (with optional
    Fugen-element between them).

    Uses the German-only dictionary to avoid cross-language false positives
    (e.g. "Martin" → "mar" (ES) + "tin" (EN)).
    """
    _german_words = _get_german_words()
    low = word.lower()
    # Try original + forms after stripping common inflectional suffixes
    forms: list[str] = [low]
    for suffix in ("s", "es", "en", "n", "er", "e", "em"):
        if low.endswith(suffix) and len(low) - len(suffix) >= 6:
            stripped = low[: -len(suffix)]
            if stripped not in forms:
                forms.append(stripped)
    for form in forms:
        if len(form) < 7:  # need at least 4 + 3
            continue
        for i in range(4, len(form) - 2):
            left = form[:i]
            if left not in _german_words:
                continue
            right = form[i:]
            if len(right) >= 3 and right in _german_words:
                return True
            # Try stripping a Fugen-element from the start of *right*
            for fg in _FUGENLAUTE:
                if right.startswith(fg):
                    rest = right[len(fg):]
                    if len(rest) >= 3 and rest in _german_words:
                        return True
    return False


# ── Expanded multilingual first-name whitelist ────────────────────────────
# Person names that also appear in language dictionaries (e.g.
# "Pierre" = stone in FR, "Rose" = pink/flower in FR/EN).
# These are EXEMPTED from the single-word dictionary noise check
# to avoid filtering real person names.

_PERSON_FIRST_NAME_WHITELIST: frozenset[str] = _PERSON_SHORT_NAME_WHITELIST | frozenset({
    # French (names that are also common nouns/adjectives)
    "pierre", "marie", "rose", "violet", "claire", "claude",
    "pascal", "christian", "gilbert", "florence", "constant",
    "prudence", "victoire", "clément", "clement", "patrice",
    "marguerite", "solange", "aimé", "aime", "desire", "désiré",
    "dominique", "michel", "marcel", "fortune", "fortuné",
    # English
    "grace", "hope", "faith", "joy", "mark", "bill", "bob",
    "will", "nick", "amber", "crystal", "hunter", "mason",
    "robin", "august", "pearl", "violet", "dawn", "summer",
    # German
    "wolf", "ernst", "otto", "stein", "hans",
    # Spanish
    "dolores", "mercedes", "pilar", "consuelo", "santos",
    # Italian
    "bianca", "stella", "felice", "leone", "franco",
    # Dutch
    "storm",
    # Portuguese
    "clara", "aurora",
    # Cross-language
    "victoria", "martin", "roman", "roman", "max", "leon",
    "oliver", "iris", "alma", "cesar", "hugo", "felix",
    "noel", "noël", "angelo", "salvatore", "reine",
})


def _is_single_word_dict_noise(word: str) -> bool:
    """Return True if a single word is a common-noun false positive.

    Checks the multilingual language dictionaries (same infrastructure
    as the ORG filter) and returns True if the word is found — meaning
    it's a regular vocabulary word, not a proper name.

    First-name whitelist entries are exempted to avoid filtering real
    person names that happen to also be dictionary words.
    """
    _common_words = _get_common_words()
    clean = word.strip()
    if not clean or len(clean) <= det_cfg.FP_MIN_TEXT_LENGTH:
        return False
    low = clean.lower().rstrip("'\u2019")
    # Exempt known first names
    if low in _PERSON_FIRST_NAME_WHITELIST:
        return False
    # Use the same _in_dict logic as the ORG filter
    if low in _common_words:
        return True
    # Try PDF encoding fix
    fixed = _fix_pdf_encoding(low)
    if fixed != low and fixed in _common_words:
        return True
    # Try accent removal
    noaccent = _remove_accents(low)
    if noaccent != low and noaccent in _common_words:
        return True
    # Snowball stemming across all languages
    for stem in _stem_word(low):
        if stem in _common_words:
            return True
    # Handle contractions (l'Emprunteur → Emprunteur → emprunteur)
    if "'" in low or "\u2019" in low:
        parts = _re.split(r"['\u2019]", low)
        main_parts = [p for p in parts if len(p) > 2]
        if main_parts and all(_is_single_word_dict_noise(p) for p in main_parts):
            return True
    return False


def _is_person_pipeline_noise(text: str) -> bool:
    """Return True if *text* looks like a noisy PERSON false-positive."""
    clean = text.strip()
    low = clean.lower()
    if low in _PERSON_PIPELINE_NOISE:
        return True

    # Pronoun + verb patterns in FR/ES/IT/PT/DE/NL — never a person name.
    # Catches: "Nous n'avons", "nous n'exprimons", "Il est", "Wir haben", etc.
    words = clean.split()
    if len(words) >= 2:
        first = words[0].lower().rstrip("'\u2019")
        if first in {
            # French
            "je", "tu", "il", "elle", "on", "nous", "vous", "ils", "elles",
            "ce", "c", "ça", "cela", "ceci",
            # Spanish
            "yo", "él", "ella", "nosotros", "nosotras", "vosotros", "vosotras", "ellos", "ellas",
            # Italian
            "io", "lui", "lei", "noi", "voi", "loro", "esso", "essa",
            # German
            "ich", "er", "sie", "wir", "ihr",
            # Dutch
            "ik", "hij", "zij", "wij", "jullie",
            # Portuguese
            "eu", "ele", "ela", "nós", "nos", "vós", "vos", "eles", "elas",
            # English
            "we", "they", "he", "she",
        }:
            return True

    stripped = _re.sub(
        r"^(?:[Ll][ea]s?|[Dd][ue]s?|[Uu]n[e]?|[Ll][''\u2019]|[Dd][''\u2019]"  # FR
        r"|[Ee]l|[Ll]os|[Ll]as"  # ES
        r"|[Ii]l|[Gg]li|[Ll][oae]|[Uu]n[oa]?"  # IT
        r"|[Dd](?:er|ie|as|en|em|es)|[Ee]in[e]?"  # DE
        r"|[Hh]et|[Dd]e|[Ee]en"  # NL
        r"|[Oo]s?|[Aa]s?"  # PT
        r"|[Ll][Ee]|[Ll][Aa]"  # FR capitalised Le/La
        r")\s+", "", clean)
    if stripped and stripped.lower() in _PERSON_PIPELINE_NOISE:
        return True
    # After stripping article, check dictionary too — catches
    # "La compagnie", "Le Producteur", "L'Emprunteur" where the
    # remaining word is a common noun in any supported language.
    # Guard: only run when an article was actually removed.  Without that
    # guard the check fires on standalone words ("Dagmar", "Robert", …)
    # because word-frequency dictionaries include proper first names.
    if stripped and stripped != clean and _is_single_word_dict_noise(stripped):
        return True
    if len(clean) <= det_cfg.FP_MIN_TEXT_LENGTH:
        return True
    if clean.isdigit():
        return True
    if clean and clean[0].isdigit():
        return True
    # URL / hostname patterns → never a person name
    if _re.search(r'(?:www\.|https?://|[a-z0-9]+\.[a-z]{2,})', low):
        return True
    # Trailing colon → form label ("ADDITIONNELLE :", "Signature :")
    if clean.rstrip().endswith(':'):
        return True
    if _re.fullmatch(r'[A-ZÀ-Ü](?:\.[A-ZÀ-Ü])+\.?', clean):
        return True
    if len(clean) <= 4 and clean[0].isupper() and clean[-1] in 'bcdfghjklmnpqrstvwxzç':
        # Bypass for known first names ending in consonants
        # Threshold is 4, not 6: 5-6 char names ending in consonants are very
        # common (Dagmar, Stefan, Robert, Kaspar, Oskar, Viktor, Alfred…) and
        # must not be suppressed.  Short tokens ≤4 (Corp, Inc, Ltd, Jr, Sr…)
        # are still caught here; anything longer falls through to the
        # single-word dictionary check below.
        if clean.lower() not in _PERSON_SHORT_NAME_WHITELIST:
            return True
    words = clean.split()
    if len(words) == 1 and len(words[0]) <= det_cfg.FP_MIN_PERSON_WORD_LENGTH:
        return True
    if len(words) == 1 and clean.isupper():
        return True
    # ── Single-word dictionary check ──────────────────────────────
    # A single word that appears in any of the 7 language dictionaries
    # is a common noun/verb/adjective, not a person name.  Real person
    # names are proper nouns absent from standard dictionaries.
    # Uses the same _in_dict() infrastructure as the ORG filter —
    # handles accents, PDF encoding, stemming, contractions.
    #
    # Safety:  Skip the dictionary check for proper-noun-shaped words
    # (initial capital, mixed case, ≥5 chars) because word-frequency
    # dictionaries include common first names and surnames (Robert,
    # Stefan, Dagmar, Viktor, Kaspar, …) and would incorrectly filter
    # them.  Curated-set filtering (_PERSON_PIPELINE_NOISE, above)
    # already handles domain false-positives for such words.
    if len(words) == 1:
        _proper_noun_shaped = (
            len(clean) >= 5
            and clean[0].isupper()
            and not clean.isupper()   # not an ALL-CAPS abbreviation
        )
        if not _proper_noun_shaped and _is_single_word_dict_noise(clean):
            return True
    if len(words) >= 2 and all(
        w.lower() in _PERSON_PIPELINE_NOISE
        or w.isdigit()
        or all(c in "-\u2013\u2014/." for c in w)
        for w in words
    ):
        return True
    # ── Multi-word: article + common noun from dictionary ─────────
    # "Mon entreprise", "Le Producteur" — article + single dict word.
    if len(words) == 2 and not has_legal_suffix(clean):
        first_low = words[0].lower().rstrip("'\u2019")
        _LEADING_ARTICLES = {
            "le", "la", "les", "un", "une", "mon", "ma", "mes",
            "ton", "ta", "tes", "son", "sa", "ses", "ce", "cette",
            "el", "los", "las", "un", "una", "mi", "tu", "su",
            "il", "lo", "gli", "un", "una", "mio", "mia",
            "der", "die", "das", "den", "dem", "des", "ein", "eine", "mein", "sein",
            "de", "het", "een", "mijn", "zijn",
            "o", "a", "os", "as", "um", "uma", "meu", "seu",
            "the", "my", "his", "her", "our", "this", "that",
        }
        if first_low in _LEADING_ARTICLES and _is_single_word_dict_noise(words[1]):
            return True
    # German compound nouns misidentified as PERSON (e.g. Hauptmieters)
    if len(words) == 1 and len(clean) >= 8 and _is_german_compound_noun(clean):
        return True
    # All-lowercase multi-word phrase → common noun, not a person name
    if len(words) >= 2 and clean == clean.lower():
        return True
    # Multi-word phrase starting with a lowercase word (adjective/article)
    # is almost never a proper person name.
    # E.g. "notariell beurkundeten Gesellschafterbeschluss"
    if len(words) >= 2 and words[0][0].islower():
        return True
    return False


