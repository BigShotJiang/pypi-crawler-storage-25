"""ORG noise filter — dictionary-based false-positive removal.

Extracted from ``noise_filters.py`` to keep the parent module under ~400 LOC.
Imports shared infrastructure (stemmers, encoding fixers, dictionary loaders)
from ``noise_filters`` — no circular dependency because the parent does not
import back; it re-exports via a top-level ``from … import`` block.
"""

from __future__ import annotations

import re as _re

from core.detection import detection_config as det_cfg
from core.text_utils import remove_accents as _remove_accents
from core.detection.noise_filters import (
    _get_common_words,
    _get_german_words,
    _stem_word,
    _fix_double_utf8,
    _fix_pdf_encoding,
    has_legal_suffix,
    LEGAL_SUFFIX_RE,
    _ARTICLE_PREFIX_RE,
)

# Educational / institutional keywords — multi-word phrases containing
# one of these are legitimate ORG names even when every individual word
# is a common dictionary entry (e.g. "Sault College of Applied Arts
# and Technologies").  Multilingual coverage mirrors regex_patterns.py.
_INSTITUTION_KEYWORDS: frozenset[str] = frozenset({
    # EN
    "college", "university", "institute", "academy", "school",
    "polytechnic", "seminary", "conservatory",
    # FR
    "collège", "université", "institut", "académie", "école",
    "polytechnique", "séminaire", "conservatoire",
    # DE
    "universität", "hochschule", "fachhochschule", "akademie", "schule",
    # ES
    "universidad", "instituto", "academia", "escuela", "politécnico",
    # IT
    "università", "istituto", "accademia", "politecnico",
    # PT
    "universidade", "academia", "escola", "politécnico",
    # NL
    "universiteit", "hogeschool", "academie",
})


def _is_org_pipeline_noise(text: str) -> bool:
    """Return True if *text* looks like a noisy ORG false-positive.

    Uses language dictionaries for vocabulary checks rather than a
    hand-curated word list.
    """
    _common_words = _get_common_words()  # load as local for closures
    clean = text.strip()

    # ── Max word-count guard ──────────────────────────────────────────
    # Real company names rarely exceed 10 words.  Very long candidates
    # are almost certainly full sentences that happen to contain a
    # company name (possibly ending with a legal suffix like "Ltée").
    _words_quick = clean.split()
    if len(_words_quick) > 12:
        return True

    # Fix double-encoded UTF-8 (mojibake) for dictionary lookup
    clean_fixed = _fix_double_utf8(clean)
    low = clean.lower()
    low_fixed = clean_fixed.lower()
    
    def _in_dict_simple(w: str) -> bool:
        """Check if single word is in dictionary, with accent normalization and stemming."""
        # Strip trailing/leading punctuation (e.g., "pertinentes." -> "pertinentes")
        w = w.strip('.,;:!?()[]{}"\'\u2018\u2019\u201c\u201d')
        if not w:
            return True  # Empty after stripping = just punctuation, not a real word
        
        if w in _common_words:
            return True
        # Try mojibake fix
        w_fixed = _fix_double_utf8(w).lower()
        if w_fixed != w and w_fixed in _common_words:
            return True
        # Try PDF encoding fix (Ú→é, Þ→è)
        w_pdf_fixed = _fix_pdf_encoding(w).lower()
        if w_pdf_fixed != w and w_pdf_fixed in _common_words:
            return True
        # Try with accents removed (e.g., 'exhaustivite' matches 'exhaustivité')
        w_noaccent = _remove_accents(w)
        if w_noaccent != w and w_noaccent in _common_words:
            return True
        # Try adding accents — covers FR, ES, IT, PT, DE diacritics
        _ACCENT_SWAPS = [
            # French
            ('é', 'e'), ('è', 'e'), ('ê', 'e'), ('ë', 'e'),
            ('à', 'a'), ('â', 'a'),
            ('ô', 'o'), ('î', 'i'), ('û', 'u'), ('ù', 'u'),
            ('ç', 'c'),
            # Spanish
            ('á', 'a'), ('í', 'i'), ('ó', 'o'), ('ú', 'u'), ('ñ', 'n'),
            # Portuguese
            ('ã', 'a'), ('õ', 'o'),
            # German
            ('ä', 'a'), ('ö', 'o'), ('ü', 'u'), ('ß', 'ss'),
        ]
        for accented, plain in _ACCENT_SWAPS:
            if plain == 'ss':
                # ß→ss: try replacing 'ss' with 'ß'
                if 'ss' in w:
                    w_accented = w.replace('ss', 'ß', 1)
                    if w_accented in _common_words:
                        return True
            elif w.endswith(plain):
                w_accented = w[:-len(plain)] + accented
                if w_accented in _common_words:
                    return True

        # Use Snowball stemmers to find stems and check dictionary.
        # This replaces ~130 lines of hand-written suffix rules with linguistically
        # correct stemming for all 7 supported languages.
        for stem in _stem_word(w):
            if stem in _common_words:
                return True
            # Also try accent normalization on the stem
            stem_noaccent = _remove_accents(stem)
            if stem_noaccent != stem and stem_noaccent in _common_words:
                return True

        # German compound word decompounding (inline, up to 3 parts)
        # Use the German-only dictionary to avoid false positives from
        # cross-language coincidences (e.g. "gaspésiens" ≠ "gaspé"+"siens").
        _de_words = _get_german_words()
        if len(w) >= det_cfg.GERMAN_COMPOUND_MIN_LENGTH:
            for i in range(det_cfg.GERMAN_COMPOUND_MIN_PART, len(w) - 3):
                left = w[:i]
                if left not in _de_words:
                    continue
                right = w[i:]
                if right in _de_words:
                    return True
                # Try Fugen-element then direct match or recursive 2nd split
                _fuge_candidates = [('', right)]  # no Fuge
                for fg in ('s', 'es', 'n', 'en', 'e', 'er'):
                    if right.startswith(fg) and len(right) > len(fg) + 3:
                        _fuge_candidates.append((fg, right[len(fg):]))
                for _fg, remainder in _fuge_candidates:
                    if remainder in _de_words:
                        return True
                    # Try one more split (3-part compounds)
                    if len(remainder) >= 7:
                        for j in range(4, len(remainder) - 3):
                            left2 = remainder[:j]
                            if left2 not in _de_words:
                                continue
                            right2 = remainder[j:]
                            if right2 in _de_words:
                                return True
                            for fg2 in ('s', 'es', 'n', 'en', 'e', 'er'):
                                if right2.startswith(fg2) and len(right2) > len(fg2) + 3:
                                    rest2 = right2[len(fg2):]
                                    if rest2 in _de_words:
                                        return True

        return False
    
    def _in_dict(word: str) -> bool:
        """Check if word is in dictionary, trying both original and fixed encoding.
        
        Also handles:
        - Hyphenated compounds: 'sous-jacentes' -> 'sous' AND 'jacentes'
        - French contractions: "l'exhaustivité" -> just check 'exhaustivité'
        """
        w = word.lower()
        if _in_dict_simple(w):
            return True
        # Handle contractions across all supported languages:
        # FR/IT: l', d', n', s', c', j', m', t', qu', dell', nell', all', sull'
        # PT: n', d' (less common in modern PT)
        if "'" in w or "\u2019" in w:  # straight or curly apostrophe
            # Split on apostrophe and check the main part
            parts = _re.split(r"['\u2019]", w)
            # Filter out empty and very short prefixes (l, d, n, s, c, j, m, t, qu)
            main_parts = [p for p in parts if len(p) > 2]
            if main_parts and all(_in_dict_simple(p) for p in main_parts):
                return True
            # Also try: if everything after apostrophe is in dict
            # Covers FR l', d', n', s', c', j', m', t'
            # and IT l', d', un', quest'
            if len(parts) == 2 and len(parts[0]) <= 5 and _in_dict_simple(parts[1]):
                return True
        # Handle hyphenated compounds (all languages) and German-style prefixed words
        if any(c in w for c in '-\u2013\u2014'):
            parts = _re.split(r'[-\u2013\u2014]', w)
            parts = [p for p in parts if p]  # Remove empty
            if len(parts) >= 2 and all(_in_dict_simple(p) for p in parts):
                return True
        return False
    
    if low in _common_words or low_fixed in _common_words:
        return True
    _stripped = _ARTICLE_PREFIX_RE.sub("", clean)
    _stripped_fixed = _ARTICLE_PREFIX_RE.sub("", clean_fixed)
    if _stripped and (_stripped.lower() in _common_words or _stripped_fixed.lower() in _common_words):
        return True
    if len(clean) <= 2:
        return True
    if clean.isupper() and len(clean) <= det_cfg.FP_MAX_CAPS_ACRONYM_LENGTH:
        return True
    # Digit-starts → noise EXCEPT numbered companies with legal suffix
    # or pure 4+ digit company numbers (e.g. "9032")
    if clean and clean[0].isdigit():
        if not LEGAL_SUFFIX_RE.search(clean) and not (clean.isdigit() and len(clean) >= 4):
            return True
    if clean.isdigit() and len(clean) < 4:
        return True
    words = clean.split()
    if len(words) == 1 and clean.isupper():
        return True
    if clean == clean.lower() and len(words) <= 2:
        return True
    if len(words) == 1 and len(words[0]) <= det_cfg.FP_MIN_ORG_WORD_LENGTH:
        return True
    # ── Single capitalized word in dictionary → noise ─────────────
    # Real ORG names are proper nouns (Apple, Google, Desjardins) that
    # do NOT appear in language dictionaries.  Common nouns like
    # "Déboursés", "Equipements", "Processus" do.  This is a
    # multilingual structural check that works across all 7 languages.
    if len(words) == 1 and not has_legal_suffix(clean) and _in_dict(clean):
        return True
    # ── Word + bare digit → noise (without legal suffix) ──────────
    # "Choix 2", "Annexe 1", "Option 3" — a regular word followed by
    # a digit is categorisation/labelling, never a company name.
    if len(words) == 2 and not has_legal_suffix(clean):
        if words[1].isdigit() and _in_dict(words[0]):
            return True
        if words[0].isdigit() and _in_dict(words[1]):
            return True
    # ── Educational institution names → not noise ─────────────────
    # Phrases containing an institution keyword (College, University,
    # etc.) are legitimate ORGs even when every word is a dictionary
    # entry (e.g. "Sault College of Applied Arts and Technologies").
    if len(words) >= 2 and any(
        w.lower().rstrip(".,;:") in _INSTITUTION_KEYWORDS for w in words
    ):
        return False
    if len(words) >= 2 and not has_legal_suffix(clean) and all(
        _in_dict(w)
        or w.isdigit()  # treat bare digits as pass-through in dict check
        or all(c in "-\u2013\u2014/." for c in w)
        for w in words
    ):
        return True
    # ── Ambiguous-suffix header detection (case-insensitive) ────
    # Phrases ending in SE/SA/AS are often document headers like
    # "Voir Avis Au Lecteur) POUR LES EXERCICES SE" or
    # "POUR LES EXERCICES SE".  When the phrase contains structural
    # prepositions/articles that never appear in real company names,
    # treat it as noise regardless of letter casing.
    # Real companies: "SOCIÉTÉ GÉNÉRALE SE", "Airbus SE" (no prepositions).
    if len(words) >= 3:
        _tail_low_pre = words[-1].lower().rstrip(".")
        if _tail_low_pre in {"se", "sa", "as"} and has_legal_suffix(words[-1]):
            _HEADER_MARKERS_PRE = {
                "pour", "les", "des", "aux", "dans", "sur", "sous",
                "entre", "chez", "avec", "sans", "vers", "selon",
                "for", "the", "from", "with", "about", "during",
                "für", "fuer", "die", "der", "das", "den", "dem",
                "aus", "mit", "bei", "nach", "von", "zum", "zur",
                "para", "los", "las", "del", "con", "sobre",
                "per", "gli", "dei", "delle", "degli", "nella",
                "voor", "het", "van", "uit", "met",
                "dos", "das", "nos", "nas", "pelo", "pela",
                # Common French header words (mixed case)
                "voir", "avis", "non", "au",
            }
            _low_words_pre = {w.lower() for w in words[:-1]}
            if _low_words_pre & _HEADER_MARKERS_PRE:
                return True

    # ── ALL-CAPS multi-word phrases (accounting headers) ──────────
    # "BÉNÉFICES NON RÉPARTIS PRÉVISIONNELS" — all-uppercase phrases
    # with 3+ words and no legal suffix are almost always document
    # section headers, not company names.  Filter if ≥75% of words
    # are in the dictionary.
    # Only respect legal suffix if it appears at the END of the phrase
    # (real company: "SOCIÉTÉ GÉNÉRALE SE") — mid-phrase matches like
    # "SE" in "EXERCICES SE TERMINANT" are coincidental.
    if len(words) >= 3 and clean.replace('\n', ' ').replace(' ', '').isupper():
        _tail_has_suffix = has_legal_suffix(words[-1])
        if not _tail_has_suffix:
            dict_count = sum(1 for w in words if _in_dict(w) or w.isdigit())
            if dict_count >= len(words) * 0.75:
                return True
        else:
            # Ambiguous 2-letter suffixes (SE, SA, AS) are also common
            # French/Spanish/Portuguese words.  When the phrase contains
            # structural prepositions/articles (POUR, DES, LES, etc.)
            # that never appear in real company names, it's a document
            # header, not a company.
            # e.g. "POUR LES EXERCICES SE" (= "for the fiscal years ending")
            # but NOT "SOCIÉTÉ GÉNÉRALE SE" (= real Societas Europaea).
            _AMBIGUOUS_SUFFIXES = {"se", "sa", "as"}
            _tail_low = words[-1].lower().rstrip(".")
            if _tail_low in _AMBIGUOUS_SUFFIXES:
                _HEADER_MARKERS = {
                    # FR prepositions/articles that never appear in company names
                    "pour", "les", "des", "aux", "dans", "sur", "sous",
                    "entre", "chez", "avec", "sans", "vers", "selon",
                    # EN
                    "for", "the", "from", "with", "about", "during",
                    # DE
                    "für", "fuer", "die", "der", "das", "den", "dem",
                    "aus", "mit", "bei", "nach", "von", "zum", "zur",
                    # ES
                    "para", "los", "las", "del", "con", "sobre",
                    # IT
                    "per", "gli", "dei", "delle", "degli", "nella",
                    # NL
                    "voor", "het", "van", "uit", "met",
                    # PT
                    "para", "dos", "das", "nos", "nas", "pelo", "pela",
                }
                low_words = {w.lower() for w in words[:-1]}
                if low_words & _HEADER_MARKERS:
                    return True
    # Strip parenthetical codes (e.g., "(NCSC)", "(ABC)") and standalone numbers/single letters
    # then check if what remains is all dictionary words. Catches regulatory/standard names.
    if len(words) >= 3 and not has_legal_suffix(clean):
        # Remove "(XXX)" patterns, standalone numbers, and single-letter words
        _code_stripped = _re.sub(r'\([A-Z0-9]{2,10}\)', '', clean)
        _code_stripped = _re.sub(r'\b\d+\b', '', _code_stripped)  # All digits
        _code_stripped = _re.sub(r"\b[a-zA-Z]['\u2019]?\s", ' ', _code_stripped)  # Single letter (possibly with apostrophe)
        _code_stripped = _re.sub(r'\s+', ' ', _code_stripped).strip()
        stripped_words = [w for w in _code_stripped.split() if w and len(w) > 1]
        if len(stripped_words) >= 2 and all(
            _in_dict(w)
            or all(c in "-\u2013\u2014/.," for c in w)
            for w in stripped_words
        ):
            return True
    if len(words) == 2 and words[0].lower() == "portion" and words[1].isdigit():
        return True
    if len(words) == 2 and words[0].lower() in (
        "le", "la", "les", "de", "du", "des", "au", "aux", "un", "une",
        "el", "los", "las", "il", "lo", "gli", "het",  # ES, IT, NL
        "der", "die", "das", "den", "dem", "des", "ein", "eine",  # DE
        "o", "a", "os", "as",  # PT
    ) and words[1].isupper() and len(words[1]) >= 2:
        return True
    if len(words) >= 2 and words[0].lower() in (
        "société", "societe",  # FR
        "sociedad", "empresa", "compañía", "compania",  # ES
        "società", "societa", "azienda", "impresa",  # IT
        "gesellschaft", "unternehmen", "firma",  # DE
        "vennootschap", "bedrijf", "onderneming",  # NL
        "sociedade", "empresa", "companhia",  # PT
    ):
        w1 = words[1].lower()
        _sentence_verbs = {
            # French
            "et", "ou", "qui", "que", "est", "a", "sont", "ont", "peut", "doit",
            "détermine", "determine", "présente", "presente", "utilise", "applique",
            "établit", "etablit", "calcule", "comptabilise", "reconnaît", "reconnait",
            "constate", "enregistre", "amortit", "provisionne", "rembourse",
            "détient", "detient", "possède", "possede", "gère", "gere",
            "exploite", "opère", "opere", "emploie", "embauche",
            "vend", "achète", "achete", "loue", "fabrique", "produit",
            "offre", "fournit", "distribue", "exporte", "importe",
            # English
            "is", "are", "has", "have", "can", "must", "should", "will",
            "determines", "presents", "uses", "applies", "calculates",
            "holds", "owns", "manages", "operates", "employs",
            "sells", "buys", "rents", "produces", "offers", "provides",
            # German
            "ist", "hat", "sind", "haben", "kann", "muss", "soll",
            "bestimmt", "verwendet", "berechnet", "hält", "haelt",
            "besitzt", "verwaltet", "betreibt", "beschäftigt", "beschaeftigt",
            "verkauft", "kauft", "mietet", "produziert", "bietet", "liefert",
            # Spanish
            "es", "ha", "son", "han", "puede", "debe",
            "determina", "presenta", "utiliza", "aplica", "calcula",
            "posee", "gestiona", "opera", "emplea",
            "vende", "compra", "alquila", "fabrica", "produce", "ofrece",
            # Italian
            "è", "ha", "sono", "hanno", "può", "puo", "deve",
            "determina", "presenta", "utilizza", "applica", "calcola",
            "detiene", "possiede", "gestisce", "opera", "impiega",
            "vende", "compra", "affitta", "fabbrica", "produce", "offre",
            # Dutch
            "is", "heeft", "zijn", "hebben", "kan", "moet",
            "bepaalt", "presenteert", "gebruikt", "berekent",
            "bezit", "beheert", "exploiteert",
            "verkoopt", "koopt", "huurt", "produceert", "biedt", "levert",
            # Portuguese
            "é", "tem", "são", "sao", "têm", "tem", "pode", "deve",
            "determina", "apresenta", "utiliza", "aplica", "calcula",
            "detém", "detem", "possui", "gere", "opera", "emprega",
            "vende", "compra", "aluga", "fabrica", "produz", "oferece",
        }
        if w1 in _sentence_verbs:
            return True
    if len(words) >= 3 and words[1].lower() in (
        # FR
        "est", "a", "sont", "ont", "peut", "doit",
        # EN
        "is", "are", "has", "have", "can", "must",
        # DE
        "ist", "hat", "sind", "haben", "kann", "muss",
        # ES
        "es", "ha", "son", "han", "puede", "debe",
        # IT
        "è", "ha", "sono", "hanno",
        # NL
        "is", "heeft", "zijn", "hebben",
        # PT
        "é", "tem", "são", "sao",
    ):
        return True
    if any(w.lower() in ("pour", "para", "für", "fuer", "per", "voor") for w in words):
        if not has_legal_suffix(words[-1]):
            return True
    # For 3+ word phrases without legal suffix: if ALL words are dictionary
    # words, it's descriptive text, not a real organization name.
    # Real company names typically have proper nouns / non-dictionary words.
    # (With comprehensive dictionaries + stemming, we can require 100% match)
    if len(words) >= 3 and not has_legal_suffix(clean):
        if all(_in_dict(w) for w in words):
            return True
    if len(words) >= 3:
        low_words = [w.lower() for w in words]
        if any(w in low_words for w in (
            "catégorie", "categorie", "category", "kategorie",
            "categoría", "categoria",
        )):
            return True
    # Generic corporate references like "die AG", "der GmbH", "la SA":
    # text ending with article + bare legal suffix is not a real company name.
    if len(words) >= 3:
        penult = words[-2].lower()
        _articles = {
            "der", "die", "das", "den", "dem", "des", "ein", "eine",  # DE
            "le", "la", "les", "l'", "un", "une",  # FR
            "el", "la", "los", "las", "un", "una",  # ES
            "il", "lo", "la", "gli", "le", "un", "una",  # IT
            "de", "het", "een",  # NL
            "o", "a", "os", "as", "um", "uma",  # PT
            "the", "a", "an",  # EN
        }
        _bare_suffixes = {
            "ag", "gmbh", "kg", "kgaa", "ohg", "ug", "mbh", "se",
            "sa", "sarl", "sas", "srl", "spa", "snc",
            "inc", "corp", "llc", "ltd", "llp", "plc", "co", "lp",
            "bv", "nv",
        }
        if penult in _articles and words[-1].lower().rstrip(".") in _bare_suffixes:
            return True
    return False


