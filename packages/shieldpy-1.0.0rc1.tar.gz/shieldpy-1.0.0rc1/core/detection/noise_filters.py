"""Pipeline-level noise filtering using language dictionaries and pattern rules.

Centralises all noise filtering logic so that pipeline, merge, and
propagation modules share a single definition.

Architecture
~~~~~~~~~~~~
This file is the **composition root** for noise filtering.  Type-specific
filters live in private sub-modules:

* ``_noise_data.py``  — pure-data frozensets (no logic)
* ``_noise_org.py``   — ORG filter (``_is_org_pipeline_noise``)
* ``_noise_loc_person.py`` — LOC + PERSON filters + German compound check

Re-exports at the bottom of this file guarantee that external callers
(``merge.py``, ``pipeline.py``, ``propagation.py``) can still do::

    from core.detection.noise_filters import is_pipeline_noise

and the dispatcher ``is_pipeline_noise()`` delegates to the correct
sub-module function.

ORG noise filtering uses comprehensive language dictionaries (~30k words each)
for all 7 supported languages (EN, FR, DE, ES, IT, NL, PT).  A candidate ORG
match is filtered when all its words are common dictionary words and it lacks
a legal company suffix.

LOCATION and PERSON noise filtering uses domain-specific curated sets
(building/facility terms, financial terms) because proper nouns (city names,
person names) naturally appear in language dictionaries and must not be
filtered.
"""

from __future__ import annotations

import re as _re
import unicodedata as _unicodedata

import Stemmer as _Stemmer  # PyStemmer — Snowball stemmers

from core.detection import detection_config as det_cfg
from pathlib import Path
from typing import Set

from core.text_utils import remove_accents as _remove_accents
from models.schemas import PIIType

# ---------------------------------------------------------------------------
# Snowball stemmers — lazy-initialized per language
# ---------------------------------------------------------------------------

# Mapping from ISO 639-1 codes to Snowball language names
_SNOWBALL_LANG_MAP: dict[str, str] = {
    "en": "english",
    "fr": "french",
    "de": "german",
    "es": "spanish",
    "it": "italian",
    "nl": "dutch",
    "pt": "portuguese",
}

_stemmers: dict[str, _Stemmer.Stemmer] = {}


def _get_stemmer(lang: str) -> _Stemmer.Stemmer | None:
    """Get or create a Snowball stemmer for the given language code."""
    if lang in _stemmers:
        return _stemmers[lang]
    snowball_name = _SNOWBALL_LANG_MAP.get(lang)
    if not snowball_name:
        return None
    stemmer = _Stemmer.Stemmer(snowball_name)
    _stemmers[lang] = stemmer
    return stemmer


def _stem_word(word: str, langs: tuple[str, ...] = ("en", "fr", "de", "es", "it", "nl", "pt")) -> set[str]:
    """Return the set of possible stems for a word across given languages.
    
    Returns stems from all requested languages since we don't always know
    the document language when filtering noise.
    """
    stems: set[str] = set()
    for lang in langs:
        stemmer = _get_stemmer(lang)
        if stemmer:
            stems.add(stemmer.stemWord(word))
    return stems


# ---------------------------------------------------------------------------
# Legal-suffix regex — shared across all noise filters
# ---------------------------------------------------------------------------

LEGAL_SUFFIX_RE: _re.Pattern[str] = _re.compile(
    r'\b(?:inc|incorporated|corp|corporation|ltd|limited|llc|llp|plc|co|company|lp|'
    r'sas|sarl|gmbh|ag|bv|nv|'
    r'kg|kgaa|ohg|ug|mbh|e\.?k\.?|e\.?v\.?|se|'
    r'aktiengesellschaft|kommanditgesellschaft|'  # DE long forms
    r'lt[ée]e|limit[ée]e|enr|s\.?e\.?n\.?c\.?|'
    r'n\.\s*v\.?|b\.\s*v\.?|'  # NL: N.V., B.V.
    r's\.?a\.?r?\.?l?\.?|s\.?p\.?a\.?|s\.?r\.?l\.?)\b\.?',
    _re.IGNORECASE,
)


def _fix_double_utf8(text: str) -> str:
    """Fix double-encoded UTF-8 (mojibake) in text.
    
    When UTF-8 bytes are mistakenly decoded as Latin-1 and then re-encoded
    as UTF-8, common French/German characters become unreadable:
    - é → Ã© (C3 A9 → C3 83 C2 A9)
    - È → Ãˆ (C3 88 → C3 83 C2 88)
    
    This function detects and reverses that double-encoding.
    """
    try:
        # Try to fix by encoding to Latin-1 and decoding as UTF-8
        # This reverses the double-encoding
        fixed = text.encode('latin-1').decode('utf-8')
        # Only use the fixed version if it's actually different and valid
        if fixed != text:
            return fixed
    except (UnicodeDecodeError, UnicodeEncodeError):
        pass
    return text


# Character mapping for PDF encoding issues (wrong chars used in place of accents)
# Include both upper and lowercase versions since .lower() may have been called
_PDF_CHAR_MAP = str.maketrans({
    '\u00da': '\u00e9',  # Ú (218) → é (233)
    '\u00fa': '\u00e9',  # ú (250) → é (233) - lowercase version
    '\u00de': '\u00e8',  # Þ (222) → è (232)
    '\u00fe': '\u00e8',  # þ (254) → è (232) - lowercase version
    '\u00d4': '\u00f4',  # Ô (212) → ô (244)
    '\u00f4': '\u00f4',  # ô stays ô
    '\u0152': '\u0153',  # Œ → œ
})


def _fix_pdf_encoding(text: str) -> str:
    """Fix common PDF character encoding issues."""
    return text.translate(_PDF_CHAR_MAP)


def has_legal_suffix(text: str) -> bool:
    """Return True if *text* contains a legal company suffix anywhere."""
    return bool(LEGAL_SUFFIX_RE.search(text.strip()))


# ---------------------------------------------------------------------------
# Language dictionaries — lazy-loaded on first use to avoid startup cost
# ---------------------------------------------------------------------------

_DICT_DIR = Path(__file__).parent / "dictionaries"
_SUPPORTED_LANGS = ("en", "fr", "de", "es", "it", "nl", "pt")

# Sentinel used to detect uninitialized state
_UNLOADED: frozenset[str] = frozenset({"__UNLOADED__"})


def _load_dictionaries() -> frozenset[str]:
    """Load per-language dictionary files into a single lowercase word set."""
    words: set[str] = set()
    for lang in _SUPPORTED_LANGS:
        dict_path = _DICT_DIR / f"{lang}.txt"
        if dict_path.exists():
            with open(dict_path, encoding="utf-8") as f:
                words.update(line.strip() for line in f if line.strip())
    return frozenset(words)


def _load_single_dict(lang: str) -> frozenset[str]:
    """Load a single language dictionary file."""
    path = _DICT_DIR / f"{lang}.txt"
    if not path.exists():
        return frozenset()
    with open(path, encoding="utf-8") as f:
        return frozenset(line.strip() for line in f if line.strip())


# Lazy-loaded: initialised to sentinel, populated on first access
_common_words: frozenset[str] = _UNLOADED
_german_words: frozenset[str] = _UNLOADED


def _get_common_words() -> frozenset[str]:
    """Return the combined dictionary word set, loading on first call."""
    global _common_words
    if _common_words is _UNLOADED:
        _common_words = _load_dictionaries()
    return _common_words


def _get_german_words() -> frozenset[str]:
    """Return the German dictionary word set, loading on first call."""
    global _german_words
    if _german_words is _UNLOADED:
        _german_words = _load_single_dict("de")
    return _german_words


# ── ORG noise (dictionary-based) ─────────────────────────────────────────
# No hand-curated word list — uses _common_words from language dictionaries.
# A candidate is noise if all its words are ordinary dictionary words and
# it doesn't carry a legal company suffix.

# Leading-article regex shared by all three noise functions
_ARTICLE_PREFIX_RE = _re.compile(
    r"^(?:[LlDd]['\u2019]\s*"  # FR: l', d'
    r"|[Ll][eao]s?\s+|[Dd][eiu]s?\s+|[Uu]n[ea]?\s+"  # FR
    r"|[Ee]l\s+|[Ll]os\s+|[Ll]as\s+"  # ES
    r"|[Ii]l\s+|[Gg]li\s+|[Uu]n[oa]?\s+"  # IT
    r"|[Dd](?:er|ie|as|en|em|es)\s+|[Ee]in[e]?\s+"  # DE
    r"|[Hh]et\s+|[Dd]e\s+|[Ee]en\s+"  # NL
    r"|[Oo]s?\s+|[Aa]s?\s+"  # PT
    r")"
)



# ── Re-export sub-module symbols for backward compatibility ────────────
from core.detection._noise_data import (               # noqa: F401
    _COMMON_DOMAIN_NOISE,
    _LOC_ONLY_NOISE,
    _LOC_PIPELINE_NOISE,
    _PERSON_ONLY_NOISE,
    _PERSON_PIPELINE_NOISE,
)
from core.detection._noise_org import (                 # noqa: F401
    _is_org_pipeline_noise,
)
from core.detection._noise_loc_person import (          # noqa: F401
    _is_german_compound_noun,
    _is_loc_pipeline_noise,
    _is_person_pipeline_noise,
    _is_single_word_dict_noise,
)

# ── ADDRESS number-only filter ────────────────────────────────────────────

_ADDR_ALPHA_RE = _re.compile(r"[A-Za-zÀ-ÿ]")
_ADDR_DIGIT_RE = _re.compile(r"\d")

# Pre-compiled word-boundary regex for mortgage/loan terms that
# disqualify an ADDRESS region.  Uses \b to avoid substring FPs
# (e.g. "Capital Street" no longer matches "capital").
_MORTGAGE_TERM_RE = _re.compile(
    r"\b(?:"
    # French
    r"hypoth[ée]caire|hypoth[èe]que|remboursable|remboursements?"
    r"|mensuell?e?s?|trimestriell?e?s?|annuell?e?s?"
    r"|[ée]ch[ée]ances?|echeances?"
    r"|capital|int[ée]r[êe]ts?|interets?"
    r"|emprunts?|pr[êe]ts?|prets?"
    r"|cr[ée]ancier|creancier|d[ée]biteur|debiteur"
    # English
    r"|mortgages?|repayments?|repayable"
    r"|monthly|quarterly|annually"
    r"|maturity|maturities"
    r"|principal|interests?"
    r"|loans?|lender|borrower|creditor|debtor"
    # German
    r"|hypotheken?|hypothekarisch"
    r"|r[üu]ckzahlung|rueckzahlung|tilgungen?"
    r"|monatlich|viertelj[äa]hrlich|vierteljaehrlich|j[äa]hrlich|jaehrlich"
    r"|f[äa]lligkeit|faelligkeit"
    r"|darlehen|kredite?"
    r"|gl[äa]ubiger|glaeubiger|schuldner"
    # Spanish
    r"|hipotecas?|hipotecari[oa]"
    r"|reembolsos?|reembolsable"
    r"|mensual(?:es)?|trimestral(?:es)?"
    r"|anual(?:es)?"
    r"|vencimientos?"
    r"|pr[ée]stamos?|prestamos?"
    r"|acreedore?s?|deudore?s?"
    # Italian
    r"|ipoteche?|ipotecari[oa]"
    r"|rimborsi?|rimborsabile"
    r"|mensil[ei]|trimestral[ei]"
    r"|annual[ei]"
    r"|scadenze?"
    r"|mutu[oi]|prestit[oi]"
    r"|creditor[ei]|debitor[ei]"
    # Dutch
    r"|hypotheek|hypotheken"
    r"|terugbetalingen?|aflossingen?"
    r"|maandelijks|driemaandelijks|kwartaal|jaarlijks"
    r"|vervaldatum"
    r"|leningen?"
    r"|schuldeiser|schuldenaar"
    # Portuguese
    r"|hipotec[áa]ri[oa]"
    r"|reembols[áa]vel|reembolsavel"
    r"|mensai?s?|trimestrais?"
    r"|anuais?"
    r"|vencimentos?"
    r"|empr[ée]stimos?|emprestimos?"
    r"|credore?s?|devedore?s?"
    r")\b",
    _re.IGNORECASE,
)


def _is_address_number_only(text: str) -> bool:
    """Return True if an ADDRESS region is structurally invalid.

    Real addresses always contain *both* alphabetic characters (street /
    city name) **and** at least one digit (street number, postal code,
    suite, etc.).
    """
    clean = text.strip()
    if not clean:
        return True
    has_alpha = _ADDR_ALPHA_RE.search(clean) is not None
    has_digit = _ADDR_DIGIT_RE.search(clean) is not None
    if not (has_alpha and has_digit):
        return True
    low = clean.lower()
    # REMOVED: substring matching caused false negatives on real addresses
    # containing words like "capital", "interest", etc.
    # Now uses word-boundary matching via compiled regex.
    if _MORTGAGE_TERM_RE.search(low):
        return True
    return False


# ── Structured type minimum digit counts ──────────────────────────────────

_STRUCTURED_MIN_DIGITS: dict[PIIType, int] = {
    PIIType.PHONE: 7,
    PIIType.SSN: 7,
    PIIType.DRIVER_LICENSE: 6,
}


# ── Phone-label stripping for ADDRESS regions ────────────────────────────

# These labels (and their multilingual counterparts) indicate a phone/fax
# line.  They should never be part of a detected ADDRESS region.
# Anchored to start-of-line, newline, OR whitespace so it also matches
# phone labels on the same visual line as the address (OCR text uses
# spaces between blocks on the same line, not newlines).
_PHONE_LABEL_RE = _re.compile(
    r"(?:^|\n|\s+)"
    r"(?:"
    r"Phone|Tel(?:e(?:phone|fon|fax))?|T[ée]l(?:[ée]ph(?:one)?)?|"
    r"T[ée]l[ée]c(?:opieur)?|Telex|Facs(?:imile)?|"
    r"Telec[óo]p(?:ia)?|"
    r"Mob(?:ile?)?|Cell(?:ulare)?|Celular|Fax|"
    r"Port(?:able)?|Fixe|Rufn(?:ummer|r)?|Handy|"
    r"Tel[ée]fono|Telefoon|Telefone"
    r")"
    r"\.?"                         # optional abbreviation dot (Tél.)
    r"(?:\s*(?:No\.?|Number|Num[ée]ro|#|N°))?"
    r"\s*[:.]?\s*"
    r"[\d\s\+\(\)\.\-]*$",
    _re.IGNORECASE | _re.MULTILINE,
)


def _strip_phone_labels_from_address(text: str) -> str:
    """Remove trailing/leading phone label lines from address text.

    Addresses merged from NER or label-value patterns sometimes absorb
    an adjacent "Tel: 555-1234" line.  This strips it and returns the
    cleaned address text.
    """
    cleaned = _PHONE_LABEL_RE.sub("", text).strip()
    return cleaned if cleaned else text


# ── Unified noise dispatcher ─────────────────────────────────────────────


def is_pipeline_noise(text: str, pii_type: PIIType) -> bool:
    """Unified entry point – returns True if *text* is noise for *pii_type*.

    Dispatches to the type-specific ``_is_<type>_pipeline_noise`` helpers.
    Callers that need only one check can still use the individual functions
    directly; this wrapper is a convenience for generic loops.
    """
    if pii_type == PIIType.ORG:
        return _is_org_pipeline_noise(text)
    if pii_type == PIIType.LOCATION:
        return _is_loc_pipeline_noise(text)
    if pii_type == PIIType.PERSON:
        return _is_person_pipeline_noise(text)
    if pii_type == PIIType.ADDRESS:
        return _is_address_number_only(text)
    return False
