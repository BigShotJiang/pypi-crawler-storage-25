"""Cross-page PII propagation.

Ensures every detected PII text is flagged on *every* page where it
appears, not just the page where it was first detected.

Performance optimisations (X1/X2):
- Block offsets are computed once per page and cached.
- The ``covered`` overlap check uses a per-page sorted interval list
  with binary search instead of a global linear scan.

Overlap detection
~~~~~~~~~~~~~~~~~
``_PageIntervals.has_overlap`` performs **1-D char-span** overlap checks,
distinct from the **2-D bbox** nudging in ``engine._resolve_overlapping_bboxes``
and the inline bbox intersection test in ``regions.py``.  Each serves a
different purpose — do not unify.

Text normalisation
~~~~~~~~~~~~~~~~~~
The ``_neutralise_quotes`` step replaces quote chars with spaces to
**preserve string length** for offset tracking.  This is intentionally
separate from ``text_utils.normalize_for_matching`` which collapses
quotes to ASCII and may change length.
"""

from __future__ import annotations

import bisect
import logging
import re as _re
import unicodedata
import uuid
from collections import defaultdict

from core.detection.bbox_utils import _resolve_bbox_overlaps
from core.detection import detection_config as det_cfg
from core.detection.block_offsets import (
    _clamp_bbox,
    _compute_block_offsets,
    _char_offset_to_bbox,
    _char_offsets_to_line_bboxes,
)
from core.detection.noise_filters import (
    _is_loc_pipeline_noise,
    _is_org_pipeline_noise,
    _is_person_pipeline_noise,
    _is_single_word_dict_noise,
    has_legal_suffix,
    _STRUCTURED_MIN_DIGITS,
)
from core.text_utils import strip_accents as _strip_accents, ws_collapse as _ws_collapse
from models.schemas import (
    DetectionSource,
    PIIRegion,
    PIIType,
    PageData,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Accent-agnostic helpers & whitespace collapse — imported from core.text_utils
# (_strip_accents, _ws_collapse)
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Tuning constants (see detection_config.py for documentation)
# ---------------------------------------------------------------------------
_PROPAGATION_OVERLAP_RATIO = det_cfg.PROPAGATION_OVERLAP_RATIO
_PROPAGATION_CONF_FACTOR = det_cfg.PROPAGATION_CONF_FACTOR
_MIN_BBOX_DIMENSION = det_cfg.MIN_BBOX_DIMENSION


# Characters treated as transparent for entity matching —
# various quotation marks that wrap entity names in running text.
_QUOTE_CHARS = frozenset(
    '"\'\'\u2018\u2019\u201A\u201B'   # single quotes / apostrophes
    '\u201C\u201D\u201E\u201F'         # double quotes
    '\u00AB\u00BB'                     # «»
    '\u2039\u203A'                     # ‹›
    '\u300C\u300D\u300E\u300F'         # CJK brackets
)


def _strip_quotes(text: str) -> str:
    """Remove quotation mark characters from *text*."""
    return ''.join(ch for ch in text if ch not in _QUOTE_CHARS)


def _neutralise_quotes(text: str) -> str:
    """Replace quotation mark characters with spaces (preserves string length)."""
    return ''.join(' ' if ch in _QUOTE_CHARS else ch for ch in text)


def _build_flex_pattern(norm_key: str) -> _re.Pattern:
    """Build a case-insensitive, whitespace-flexible regex for *norm_key*.

    Spaces in *norm_key* become ``\\s+`` so that the pattern matches
    regardless of whether the page text uses spaces, newlines, or other
    whitespace between words.

    Boundary assertions are chosen based on the first/last character of
    the key:

    * **Word character** (letter, digit, ``_``): use ``\\b`` — the
      standard word boundary that requires a transition between word and
      non-word characters.
    * **Non-word character** (period, parenthesis, …): use
      ``(?<!\\w)`` / ``(?!\\w)`` — zero-width assertions that simply
      require the adjacent character not to be a word character.  This
      avoids the classic ``\\b`` pitfall where a trailing period (e.g.
      ``inc.``, ``S.A.``) is followed by whitespace or end-of-string
      (both non-word), causing ``\\b`` to silently fail.
    """
    escaped = _re.escape(norm_key)
    # re.escape also escapes spaces (\ + space) — replace with \s+
    pat_str = escaped.replace('\\ ', r'\s+')

    # Leading boundary
    if norm_key and norm_key[0].isalnum():
        pat_str = r'\b' + pat_str
    else:
        pat_str = r'(?<!\w)' + pat_str

    # Trailing boundary
    if norm_key and norm_key[-1].isalnum():
        pat_str = pat_str + r'\b'
    else:
        pat_str = pat_str + r'(?!\w)'

    return _re.compile(pat_str, _re.IGNORECASE)


# ---------------------------------------------------------------------------
# Per-page interval tracker — O(log n) overlap check via binary search
# ---------------------------------------------------------------------------

class _PageIntervals:
    """Maintain sorted, non-overlapping intervals per page for fast overlap checks."""

    __slots__ = ("_starts", "_ends")

    def __init__(self) -> None:
        self._starts: list[int] = []
        self._ends: list[int] = []

    def has_overlap(self, cs: int, ce: int, min_ratio: float = _PROPAGATION_OVERLAP_RATIO) -> bool:
        """Return True if an existing interval overlaps [cs, ce) by >= min_ratio.

        Uses binary search on sorted start positions — O(log n).
        """
        threshold = min_ratio * (ce - cs)
        # Find candidate intervals that could overlap [cs, ce).
        # An interval (s, e) overlaps [cs, ce) iff s < ce AND e > cs.
        # idx = first position where _starts[idx] >= ce  →  all intervals
        # with index < idx have start < ce (necessary condition for overlap).
        idx = bisect.bisect_left(self._starts, ce)
        # Walk backwards from idx to find intervals that also satisfy e > cs.
        for i in range(idx - 1, -1, -1):
            if self._ends[i] <= cs:
                # This interval ends before our query starts.
                # Since starts are sorted but ends are NOT monotone, we
                # cannot safely break early — a wider interval with an
                # earlier start could still overlap.  Continue scanning.
                continue
            ov_start = max(cs, self._starts[i])
            ov_end = min(ce, self._ends[i])
            if ov_end - ov_start >= threshold:
                return True
        return False

    def add(self, cs: int, ce: int) -> None:
        """Insert interval [cs, ce) maintaining sorted order by start."""
        idx = bisect.bisect_left(self._starts, cs)
        self._starts.insert(idx, cs)
        self._ends.insert(idx, ce)


def propagate_regions_across_pages(
    regions: list[PIIRegion],
    pages: list[PageData],
) -> list[PIIRegion]:
    """Ensure every detected PII text is flagged on *every* page.

    For each unique PII text in *regions*, search all pages for
    additional occurrences and create new regions with properly-computed
    bounding boxes.

    Returns the full region list (originals + propagated).
    """
    if not regions or not pages:
        return regions

    page_map: dict[int, PageData] = {p.page_number: p for p in pages}

    # Collect unique PII texts and their best template
    text_to_template: dict[str, PIIRegion] = {}
    for r in regions:
        key = r.text.strip()
        if not key or len(key) < 2:
            continue
        if r.pii_type == PIIType.ORG and (
            (key.isdigit() and len(key) < 4)
            or (key and key[0].isdigit() and not key.isdigit() and not has_legal_suffix(key))
            or len(key) <= 2
        ):
            continue
        # Filter obvious ORG noise from propagation — but only for
        # 3+ word phrases (short names like "Société Générale" may
        # have passed merge with visual boost and should propagate).
        if r.pii_type == PIIType.ORG and len(key.split()) >= 3 and _is_org_pipeline_noise(key):
            continue
        if r.pii_type == PIIType.LOCATION and _is_loc_pipeline_noise(key):
            continue
        if r.pii_type == PIIType.PERSON and _is_person_pipeline_noise(key):
            continue
        _min_prop = _STRUCTURED_MIN_DIGITS.get(r.pii_type)
        if _min_prop is not None:
            digs = sum(c.isdigit() for c in key)
            if digs < _min_prop:
                continue
            if r.pii_type == PIIType.SSN and any(c in key for c in '$€£'):
                continue
        # Accent-agnostic, case-insensitive, whitespace-normalised keying
        # Also neutralise quotation marks (→ spaces) so L'ESPRIT keys
        # consistently with the per-page search which also neutralises quotes.
        norm_key = _ws_collapse(_strip_accents(_neutralise_quotes(key))).lower()
        existing = text_to_template.get(norm_key)
        if existing is None or r.confidence > existing.confidence:
            text_to_template[norm_key] = r

    if not text_to_template:
        logger.debug("Propagation: no propagatable PII texts found")
        return regions

    # X2: Per-page interval index for O(log n) overlap check.
    # Keyed by (pii_type, page_number) so that a PERSON/LOCATION region
    # covering the same chars as an ORG word does NOT block ORG propagation
    # (and vice-versa).  Each type's interval set is independent.
    page_intervals: dict[tuple, _PageIntervals] = defaultdict(_PageIntervals)
    for r in regions:
        page_intervals[(r.pii_type, r.page_number)].add(r.char_start, r.char_end)

    # X1: Cache block offsets per page (computed once, reused for all texts)
    block_offsets_cache: dict[int, list] = {}
    # Cache accent-stripped full_text per page for accent-agnostic search
    norm_full_cache: dict[int, str] = {}

    propagated: list[PIIRegion] = []

    for norm_pii_text, template in text_to_template.items():
        # Whitespace-flexible, case-insensitive regex for this key
        _pat = _build_flex_pattern(norm_pii_text)

        for page_data in pages:
            full_text = page_data.full_text
            if not full_text:
                continue

            pn = page_data.page_number
            intervals = page_intervals[(template.pii_type, pn)]

            # Accent-agnostic search: compare stripped versions
            if pn not in norm_full_cache:
                norm_full_cache[pn] = _neutralise_quotes(_strip_accents(full_text))
            norm_full = norm_full_cache[pn]

            for _m in _pat.finditer(norm_full):
                char_start = _m.start()
                char_end = _m.end()

                if intervals.has_overlap(char_start, char_end, _PROPAGATION_OVERLAP_RATIO):
                    continue

                # X1: Get cached block offsets for this page
                if pn not in block_offsets_cache:
                    block_offsets_cache[pn] = _compute_block_offsets(
                        page_data.text_blocks, full_text,
                    )
                block_offsets = block_offsets_cache[pn]

                line_bboxes = _char_offsets_to_line_bboxes(
                    char_start, char_end, block_offsets,
                )
                if not line_bboxes:
                    bbox = _char_offset_to_bbox(char_start, char_end, block_offsets)
                    if bbox is None:
                        continue
                    line_bboxes = [bbox]

                for bbox in line_bboxes:
                    clamped = _clamp_bbox(bbox, page_data.width, page_data.height)
                    if clamped.x1 - clamped.x0 < _MIN_BBOX_DIMENSION or clamped.y1 - clamped.y0 < _MIN_BBOX_DIMENSION:
                        continue
                    new_region = PIIRegion(
                        id=uuid.uuid4().hex[:12],
                        page_number=page_data.page_number,
                        bbox=clamped,
                        text=full_text[char_start:char_end],
                        pii_type=template.pii_type,
                        confidence=template.confidence,
                        source=template.source,
                        char_start=char_start,
                        char_end=char_end,
                        action=template.action,
                    )
                    propagated.append(new_region)
                intervals.add(char_start, char_end)  # type-scoped: won't block other types

    if propagated:
        logger.info(
            "Propagated %d additional regions across %d pages from %d unique PII texts",
            len(propagated), len(pages), len(text_to_template),
        )

    all_regions = regions + propagated

    # Final overlap resolution per page
    result: list[PIIRegion] = []
    pages_with_regions: set[int] = {r.page_number for r in all_regions}
    for pn in sorted(pages_with_regions):
        page_regions = [r for r in all_regions if r.page_number == pn]
        result.extend(_resolve_bbox_overlaps(page_regions))

    # Char-span containment dedup: drop any region whose char span is
    # strictly contained within a same-type region on the same page with
    # equal-or-higher confidence.  This acts as a safety net for cases
    # where bbox-based dedup cannot catch sub-phrase overlaps (e.g. when
    # a partial "GASPE INC." region nestles within a full
    # "CLUB NAUTIQUE JACQUES-CARTIER DE GASPE INC." region).
    if result:
        # Group by page for efficient per-page processing
        _page_buckets: dict[int, list[PIIRegion]] = defaultdict(list)
        for r in result:
            _page_buckets[r.page_number].append(r)
        _dominated_ids: set[str] = set()
        for _regs in _page_buckets.values():
            # Sort by span length descending so longer spans come first
            _regs_sorted = sorted(_regs, key=lambda r: -(r.char_end - r.char_start))
            for i, ri in enumerate(_regs_sorted):
                if ri.id in _dominated_ids:
                    continue
                for rj in _regs_sorted[:i]:
                    if rj.id in _dominated_ids:
                        continue
                    if (rj.pii_type == ri.pii_type
                            and rj.char_start <= ri.char_start
                            and rj.char_end >= ri.char_end
                            and rj.confidence >= ri.confidence):
                        _dominated_ids.add(ri.id)
                        break
        if _dominated_ids:
            logger.info(
                "Char-span containment dedup dropped %d sub-phrase region(s)",
                len(_dominated_ids),
            )
            result = [r for r in result if r.id not in _dominated_ids]

    # Clamp every region to its page bounds 
    clamped_result: list[PIIRegion] = []
    for r in result:
        pd = page_map.get(r.page_number)
        if pd is None:
            clamped_result.append(r)
            continue
        cb = _clamp_bbox(r.bbox, pd.width, pd.height)
        if cb.x1 - cb.x0 < _MIN_BBOX_DIMENSION or cb.y1 - cb.y0 < _MIN_BBOX_DIMENSION:
            continue
        if cb != r.bbox:
            r = r.model_copy(update={"bbox": cb})
        clamped_result.append(r)

    # Safety-net: deduplicate by region ID — keep only the first occurrence
    # of each ID to prevent downstream "duplicate key" errors.
    _seen_ids: set[str] = set()
    _deduped: list[PIIRegion] = []
    for r in clamped_result:
        if r.id not in _seen_ids:
            _seen_ids.add(r.id)
            _deduped.append(r)
    if len(_deduped) < len(clamped_result):
        logger.warning(
            "Propagation dedup: removed %d duplicate-ID region(s)",
            len(clamped_result) - len(_deduped),
        )
    return _deduped


# ---------------------------------------------------------------------------
# Partial ORG name propagation
# ---------------------------------------------------------------------------

def _is_numeric_token(w: str) -> bool:
    """Return True if *w* looks like a number (digits, optional separators)."""
    stripped = w.replace(",", "").replace(".", "").replace("-", "")
    return stripped.isdigit() and len(stripped) > 0


def _is_hyphenated_token(w: str) -> bool:
    """Return True if *w* contains an internal hyphen connecting sub-words."""
    return "-" in w and not w.startswith("-") and not w.endswith("-")


def _merge_atomic_groups(words: list[str]) -> list[list[str]]:
    """Merge words into atomic groups that must never be split.

    Rules:
    * Hyphenated words (e.g. "Coca-Cola") are already single tokens from
      whitespace splitting — they stay atomic by default.
    * Numeric tokens ("360", "747", "2023") are glued to their left
      neighbour if one exists, making them inseparable.
    * A leading numeric token (no left neighbour) is glued to the next
      group on the right, so "360 Capital Group" keeps "360 Capital"
      together.
    * This prevents sub-phrases like "747 Division" from appearing when
      the full ORG name is "Boeing 747 Division".
    """
    if not words:
        return []
    groups: list[list[str]] = [[words[0]]]
    for w in words[1:]:
        if _is_numeric_token(w):
            # Glue number to previous group
            groups[-1].append(w)
        else:
            groups.append([w])
    # If the first group is purely numeric, merge it into the second group
    if (len(groups) >= 2
            and all(_is_numeric_token(w) for w in groups[0])):
        groups[1] = groups[0] + groups[1]
        groups.pop(0)
    return groups


def _generate_contiguous_subphrases(words: list[str], min_words: int = 2) -> list[str]:
    """Return all contiguous sub-phrases of *words* with >= *min_words* words.

    Excludes the full phrase itself (already handled by exact propagation).

    Split rules:
    * Only whitespace boundaries are considered split points.
    * Hyphenated tokens (e.g. "Coca-Cola") are atomic — never split.
    * Numeric tokens are glued to the preceding word and cannot form a
      sub-phrase boundary (e.g. "Boeing 747" is indivisible).
    """
    groups = _merge_atomic_groups(words)
    n = len(groups)
    if n < 2:
        return []
    subphrases: list[str] = []
    for length in range(1, n):            # skip n (the full phrase)
        for start in range(n - length + 1):
            phrase_words: list[str] = []
            for g in groups[start : start + length]:
                phrase_words.extend(g)
            if len(phrase_words) >= min_words:
                subphrases.append(" ".join(phrase_words))
    return subphrases


def propagate_partial_org_names(
    regions: list[PIIRegion],
    pages: list[PageData],
) -> list[PIIRegion]:
    """Find 2+-word sub-phrases of detected ORG names in every page.

    When "Deutsche Bank AG" has been detected, this function also flags
    occurrences of "Deutsche Bank" (2+ contiguous words from the original).

    * Only ORG regions with 3+ words are used as sources.
    * Sub-phrases that are noise (common dictionary words only, no legal
      suffix) are skipped.
    * New regions are created with confidence reduced by 15 %.
    * Existing regions are never duplicated (overlap check).
    """
    if not regions or not pages:
        return regions

    # 1. Collect unique multi-word ORG texts (accent-agnostic keying)
    org_texts: dict[str, PIIRegion] = {}
    for r in regions:
        if r.pii_type != PIIType.ORG:
            continue
        key = r.text.strip()
        words = key.split()
        if len(words) < 3:
            continue
        norm_key = _ws_collapse(_strip_accents(_neutralise_quotes(key))).lower()
        existing = org_texts.get(norm_key)
        if existing is None or r.confidence > existing.confidence:
            org_texts[norm_key] = r

    if not org_texts:
        return regions

    # 2. Build sub-phrase → template mapping (best parent confidence wins)
    #    Since these are derived from *confirmed* ORG names, we use a lighter
    #    filter than _is_org_pipeline_noise: only skip sub-phrases composed
    #    entirely of function words (articles, prepositions, conjunctions).
    _FUNCTION_WORDS: frozenset[str] = frozenset({
        # English
        "the", "a", "an", "of", "and", "or", "for", "in", "on", "at", "to",
        "by", "with", "from", "as", "is", "are", "was", "were",
        # French
        "le", "la", "les", "de", "du", "des", "et", "ou", "en", "au", "aux",
        "un", "une", "sur", "dans", "pour", "par", "avec",
        # German
        "der", "die", "das", "den", "dem", "des", "und", "oder", "für", "fuer",
        "mit", "von", "zu", "auf", "ein", "eine", "am", "im", "an", "bei",
        "aus", "nach", "über", "ueber",
        # Spanish
        "el", "los", "las", "del", "y", "o", "para", "con", "por",
        "al", "una", "uno",
        # Italian
        "il", "lo", "gli", "della", "dello", "dei", "degli", "delle", "e",
        "di", "da", "al", "alla", "alle", "ai", "nel", "nella",
        "sul", "sulla", "dal", "dalla",
        # Dutch
        "het", "een", "van", "voor", "met", "op", "te", "bij", "uit",
        # Portuguese
        "o", "os", "do", "da", "dos", "das", "com", "em", "no", "na",
        "nos", "nas", "ao", "aos", "um", "uma",
    })
    _NORM_FUNCTION_WORDS = frozenset(_strip_accents(w) for w in _FUNCTION_WORDS)

    # Known standalone legal-entity suffixes that should never be propagated alone.
    _LEGAL_STANDALONE: frozenset[str] = frozenset({
        "inc", "corp", "ltd", "llc", "lp", "gmbh", "ag", "sa", "nv",
        "bv", "plc", "spa", "srl", "oy", "ab", "aps", "as",
    })

    sub_to_template: dict[str, PIIRegion] = {}
    for org_text, template in org_texts.items():
        words = org_text.split()
        for sub in _generate_contiguous_subphrases(words, min_words=2):
            # Skip sub-phrases made entirely of function words
            sub_words = sub.split()   # already lowercased
            if all(w in _NORM_FUNCTION_WORDS for w in sub_words):
                continue
            existing = sub_to_template.get(sub)
            if existing is None or template.confidence > existing.confidence:
                sub_to_template[sub] = template

    # 2b. Single-word subsets: add individual distinctive words from any
    #     confirmed ORG name that are not common dictionary words.
    #     Example: "TELUS" from "TELUS Communications Inc"
    #              "Desjardins" from "Groupe Desjardins Financier"
    #
    #     Qualifiers for a single word to be propagated:
    #       - length >= 4 (avoids noise like "Inc", "AG", etc.)
    #       - proper-noun shaped: initial-cap OR all-caps
    #       - not a function word
    #       - not a known standalone legal-entity suffix
    #       - not found in the multilingual common-word dictionary
    for _norm_org, template in org_texts.items():
        # Use original casing from template.text for proper-noun shape test
        original_text = _ws_collapse(
            _strip_accents(_neutralise_quotes(template.text.strip()))
        )
        for word in original_text.split():
            if len(word) < 4:
                continue
            if not (word[0].isupper() or word.isupper()):
                continue
            if word.isdigit():
                continue
            norm_word = _strip_accents(word.lower())
            if norm_word in _NORM_FUNCTION_WORDS:
                continue
            if norm_word in _LEGAL_STANDALONE:
                continue
            if _is_single_word_dict_noise(word):
                continue
            existing = sub_to_template.get(norm_word)
            if existing is None or template.confidence > existing.confidence:
                sub_to_template[norm_word] = template

    # Remove sub-phrases that are already exact-match regions (any type)
    existing_texts: set[str] = {
        _ws_collapse(_strip_accents(_neutralise_quotes(r.text.strip()))).lower()
        for r in regions
    }
    for txt in list(sub_to_template):
        if txt in existing_texts:
            del sub_to_template[txt]

    if not sub_to_template:
        return regions

    # 3a. Retype existing LOCATION/PERSON regions that match an ORG sub-phrase
    #     or the full ORG name itself.
    #     NER may independently tag part of a known ORG name as LOCATION
    #     (e.g. "der Alten Försterei" from "An der Alten Försterei" Stadionbetriebs AG).
    #     Those should be ORG, not LOCATION.
    _retype_lookup: dict[str, PIIRegion] = {**sub_to_template}
    # Also include full ORG names so they get retyped too
    for k, v in org_texts.items():
        if k not in _retype_lookup:
            _retype_lookup[k] = v

    _retyped = 0
    for i, r in enumerate(regions):
        if r.pii_type not in (PIIType.LOCATION, PIIType.PERSON):
            continue
        r_norm = _ws_collapse(_strip_accents(_neutralise_quotes(r.text.strip()))).lower()
        tpl = _retype_lookup.get(r_norm)
        if tpl is not None:
            regions[i] = r.model_copy(update={
                "pii_type": PIIType.ORG,
                "confidence": max(r.confidence, round(tpl.confidence * _PROPAGATION_CONF_FACTOR, 4)),
            })
            _retyped += 1
    if _retyped:
        logger.info(
            "Partial-ORG propagation: retyped %d LOCATION/PERSON region(s) to ORG "
            "(sub-phrases of known ORG names)",
            _retyped,
        )

    # 3b. Build per-page interval index from existing regions.
    # Keyed by (pii_type, page_number) — same-type isolation as in
    # propagate_regions_across_pages.
    page_intervals: dict[tuple, _PageIntervals] = defaultdict(_PageIntervals)
    for r in regions:
        page_intervals[(r.pii_type, r.page_number)].add(r.char_start, r.char_end)

    # Block-offset cache
    block_offsets_cache: dict[int, list] = {}
    # Cache accent-stripped full_text per page
    norm_full_cache: dict[int, str] = {}

    propagated: list[PIIRegion] = []

    # Process longer sub-phrases first so they claim intervals before
    # shorter overlapping ones.
    sorted_subs = sorted(sub_to_template.items(), key=lambda kv: -len(kv[0]))

    for sub_text, template in sorted_subs:
        conf = round(template.confidence * _PROPAGATION_CONF_FACTOR, 4)
        # Whitespace-flexible, case-insensitive regex with word boundaries
        _sub_pat = _build_flex_pattern(sub_text)

        for page_data in pages:
            full_text = page_data.full_text
            if not full_text:
                continue

            pn = page_data.page_number
            intervals = page_intervals[(PIIType.ORG, pn)]

            # Accent-agnostic search
            if pn not in norm_full_cache:
                norm_full_cache[pn] = _neutralise_quotes(_strip_accents(full_text))
            norm_full = norm_full_cache[pn]

            for _m in _sub_pat.finditer(norm_full):
                char_start = _m.start()
                char_end = _m.end()

                # Require word boundaries to avoid matching inside words
                if char_start > 0 and full_text[char_start - 1].isalnum():
                    continue
                if char_end < len(full_text) and full_text[char_end].isalnum():
                    continue

                if intervals.has_overlap(char_start, char_end, _PROPAGATION_OVERLAP_RATIO):
                    continue

                # Compute bbox
                if pn not in block_offsets_cache:
                    block_offsets_cache[pn] = _compute_block_offsets(
                        page_data.text_blocks, full_text,
                    )
                block_offsets = block_offsets_cache[pn]

                line_bboxes = _char_offsets_to_line_bboxes(
                    char_start, char_end, block_offsets,
                )
                if not line_bboxes:
                    bbox = _char_offset_to_bbox(char_start, char_end, block_offsets)
                    if bbox is None:
                        continue
                    line_bboxes = [bbox]

                for bbox in line_bboxes:
                    clamped = _clamp_bbox(bbox, page_data.width, page_data.height)
                    if clamped.x1 - clamped.x0 < _MIN_BBOX_DIMENSION or clamped.y1 - clamped.y0 < _MIN_BBOX_DIMENSION:
                        continue
                    new_region = PIIRegion(
                        id=uuid.uuid4().hex[:12],
                        page_number=page_data.page_number,
                        bbox=clamped,
                        text=full_text[char_start:char_end],
                        pii_type=PIIType.ORG,
                        confidence=conf,
                        source=template.source,
                        char_start=char_start,
                        char_end=char_end,
                        action=template.action,
                    )
                    propagated.append(new_region)
                intervals.add(char_start, char_end)

    if propagated:
        logger.info(
            "Partial-ORG propagation: added %d regions from %d sub-phrases of %d ORG names",
            len(propagated), len(sub_to_template), len(org_texts),
        )

    if not propagated:
        return regions

    all_regions = regions + propagated

    # Overlap resolution + clamping (same as main propagation)
    page_map: dict[int, PageData] = {p.page_number: p for p in pages}
    result: list[PIIRegion] = []
    pages_with_regions: set[int] = {r.page_number for r in all_regions}
    for pn in sorted(pages_with_regions):
        page_regions = [r for r in all_regions if r.page_number == pn]
        result.extend(_resolve_bbox_overlaps(page_regions))

    # Char-span containment dedup: drop sub-phrase regions that are contained
    # within a longer same-type region on the same page (safety net).
    if result:
        _page_bkts: dict[int, list[PIIRegion]] = defaultdict(list)
        for r in result:
            _page_bkts[r.page_number].append(r)
        _dom_ids: set[str] = set()
        for _regs in _page_bkts.values():
            _regs_s = sorted(_regs, key=lambda r: -(r.char_end - r.char_start))
            for i, ri in enumerate(_regs_s):
                if ri.id in _dom_ids:
                    continue
                for rj in _regs_s[:i]:
                    if rj.id in _dom_ids:
                        continue
                    if (rj.pii_type == ri.pii_type
                            and rj.char_start <= ri.char_start
                            and rj.char_end >= ri.char_end
                            and rj.confidence >= ri.confidence):
                        _dom_ids.add(ri.id)
                        break
        if _dom_ids:
            logger.info(
                "Partial-ORG containment dedup dropped %d region(s)", len(_dom_ids)
            )
            result = [r for r in result if r.id not in _dom_ids]

    clamped_result: list[PIIRegion] = []
    for r in result:
        pd = page_map.get(r.page_number)
        if pd is None:
            clamped_result.append(r)
            continue
        cb = _clamp_bbox(r.bbox, pd.width, pd.height)
        if cb.x1 - cb.x0 < _MIN_BBOX_DIMENSION or cb.y1 - cb.y0 < _MIN_BBOX_DIMENSION:
            continue
        if cb != r.bbox:
            r = r.model_copy(update={"bbox": cb})
        clamped_result.append(r)

    # Safety-net: deduplicate by region ID — keep only the first occurrence
    # of each ID to prevent downstream "duplicate key" errors.
    _seen_ids2: set[str] = set()
    _deduped2: list[PIIRegion] = []
    for r in clamped_result:
        if r.id not in _seen_ids2:
            _seen_ids2.add(r.id)
            _deduped2.append(r)
    if len(_deduped2) < len(clamped_result):
        logger.warning(
            "Partial-ORG propagation dedup: removed %d duplicate-ID region(s)",
            len(clamped_result) - len(_deduped2),
        )
    return _deduped2


# ---------------------------------------------------------------------------
# Type unification — ensure same text → single type across the document
# ---------------------------------------------------------------------------

def unify_types_by_text(regions: list[PIIRegion]) -> list[PIIRegion]:
    """Ensure all regions with the same text share a single PII type.

    For each unique normalised text, the type with the highest confidence
    wins.  All regions with that text are updated to use the winning type.

    Returns a new list (regions are copied only when changed).
    """
    if not regions:
        return regions

    # Group regions by normalised text key
    groups: dict[str, list[int]] = defaultdict(list)
    for idx, r in enumerate(regions):
        key = _ws_collapse(_strip_accents(r.text.strip())).lower()
        if len(key) < 2:
            continue
        groups[key].append(idx)

    changed = False
    result = list(regions)

    for _key, indices in groups.items():
        if len(indices) < 2:
            continue

        # Find the winning type (highest confidence)
        best_idx = max(indices, key=lambda i: result[i].confidence)
        best_type = result[best_idx].pii_type

        # Check if all already agree
        if all(result[i].pii_type == best_type for i in indices):
            continue

        # Unify
        for i in indices:
            if result[i].pii_type != best_type:
                result[i] = result[i].model_copy(update={"pii_type": best_type})
                changed = True

    if changed:
        unified_count = sum(
            1 for orig, new in zip(regions, result) if orig.pii_type != new.pii_type
        )
        logger.info("Type unification: updated %d region(s) to match same-text siblings", unified_count)

    return result


# ---------------------------------------------------------------------------
# Cross-page repeated phrase discovery
# ---------------------------------------------------------------------------

def _is_all_upper_word(w: str) -> bool:
    """True if *w* contains ≥ 2 alphabetic characters and all are uppercase.

    Allows non-alpha characters (hyphens, periods, apostrophes) within the
    word — only the letter characters are tested.
    """
    alpha_count = 0
    for c in w:
        if c.isalpha():
            if not c.isupper():
                return False
            alpha_count += 1
    return alpha_count >= 2


def discover_repeated_org_phrases(
    pages: list[PageData],
    existing_regions: list[PIIRegion],
) -> list[PIIRegion]:
    """Discover ORG candidates from uppercase phrases repeating across pages.

    Scans every page for standalone all-uppercase lines (2–4 words) that
    appear **unchanged** on a majority of pages.  Such phrases are
    typically company brand names, divisions, or trade names rendered as
    running headers or watermarks in financial / legal documents.

    To minimise false positives the candidate must also appear within a
    few lines of a line bearing a legal company suffix (Inc., ENR.,
    SARL, GmbH, …) on **at least one page**.  This associates the
    phrase with a known corporate entity and is fully language-independent.

    Regions are created directly on every page where the phrase appears
    (bypassing propagation's per-word dictionary filter, which could
    reject legitimate brand names composed of common words).

    Returns ``existing_regions`` combined with any newly-discovered regions.
    """
    n_pages = len(pages)
    if n_pages < 3:
        return existing_regions

    # ------------------------------------------------------------------
    # Step 1 — Extract candidate phrases from standalone lines
    # ------------------------------------------------------------------
    phrase_pages: dict[str, set[int]] = defaultdict(set)  # norm → page numbers
    phrase_raw: dict[str, str] = {}                       # norm → first raw text

    for page in pages:
        _seen_on_page: set[str] = set()
        for line in page.full_text.split('\n'):
            stripped = line.strip()
            if not stripped:
                continue
            words = stripped.split()
            if len(words) < 2 or len(words) > 4:
                continue
            if not all(_is_all_upper_word(w) for w in words):
                continue
            norm = _ws_collapse(_strip_accents(stripped)).lower()
            if norm in _seen_on_page:
                continue
            _seen_on_page.add(norm)
            phrase_pages[norm].add(page.page_number)
            if norm not in phrase_raw:
                phrase_raw[norm] = stripped

    # ------------------------------------------------------------------
    # Step 2 — Keep only phrases on a strict majority of pages
    # ------------------------------------------------------------------
    majority = max(3, n_pages // 2 + 1)
    repeating: set[str] = {
        norm for norm, pgs in phrase_pages.items()
        if len(pgs) >= majority
    }
    if not repeating:
        return existing_regions

    # ------------------------------------------------------------------
    # Step 3 — Exclude phrases already covered by existing ORG regions
    # ------------------------------------------------------------------
    existing_org_norms: set[str] = set()
    for r in existing_regions:
        if r.pii_type == PIIType.ORG:
            existing_org_norms.add(
                _ws_collapse(_strip_accents(r.text.strip())).lower()
            )
    repeating -= existing_org_norms
    if not repeating:
        return existing_regions

    # ------------------------------------------------------------------
    # Step 4 — Legal-suffix proximity validation
    #
    # On at least one page the phrase must appear within ±N lines of a
    # line that bears a legal company suffix.  This is the key guard
    # against detecting generic section headers.
    # ------------------------------------------------------------------
    _CONTEXT_LINES = 3
    validated: set[str] = set()

    for norm in repeating:
        _found = False
        for page in pages:
            if _found:
                break
            lines = page.full_text.split('\n')
            stripped_lines = [l.strip() for l in lines]
            norm_lines = [
                _ws_collapse(_strip_accents(sl)).lower() for sl in stripped_lines
            ]
            for i, nl in enumerate(norm_lines):
                if nl != norm:
                    continue
                lo = max(0, i - _CONTEXT_LINES)
                hi = min(len(stripped_lines), i + _CONTEXT_LINES + 1)
                for j in range(lo, hi):
                    if j == i:
                        continue
                    if stripped_lines[j] and has_legal_suffix(stripped_lines[j]):
                        validated.add(norm)
                        _found = True
                        break
                if _found:
                    break

    if not validated:
        return existing_regions

    # ------------------------------------------------------------------
    # Step 5 — Create ORG regions on every page where the phrase appears
    # ------------------------------------------------------------------
    _CONFIDENCE = 0.55
    new_regions: list[PIIRegion] = []
    # Pre-compute existing region spans per page to avoid duplicates
    _existing_spans: dict[int, set[tuple[int, int]]] = defaultdict(set)
    for r in existing_regions:
        _existing_spans[r.page_number].add((r.char_start, r.char_end))

    for norm in validated:
        for page in pages:
            full_text = page.full_text
            lines = full_text.split('\n')
            offset = 0
            for line in lines:
                stripped = line.strip()
                norm_line = _ws_collapse(_strip_accents(stripped)).lower()
                if norm_line == norm:
                    leading = len(line) - len(line.lstrip())
                    char_start = offset + leading
                    char_end = char_start + len(stripped)

                    # Skip if an existing region already covers this span
                    _dominated = False
                    for (es, ee) in _existing_spans[page.page_number]:
                        if es <= char_start and ee >= char_end:
                            _dominated = True
                            break
                    if _dominated:
                        offset += len(line) + 1
                        continue

                    block_offsets = _compute_block_offsets(
                        page.text_blocks, full_text,
                    )
                    bboxes = _char_offsets_to_line_bboxes(
                        char_start, char_end, block_offsets,
                    )
                    if not bboxes:
                        bbox = _char_offset_to_bbox(
                            char_start, char_end, block_offsets,
                        )
                        if bbox is None:
                            offset += len(line) + 1
                            continue
                        bboxes = [bbox]

                    clamped = _clamp_bbox(bboxes[0], page.width, page.height)
                    new_regions.append(PIIRegion(
                        id=uuid.uuid4().hex[:16],
                        page_number=page.page_number,
                        bbox=clamped,
                        text=full_text[char_start:char_end],
                        pii_type=PIIType.ORG,
                        confidence=_CONFIDENCE,
                        source=DetectionSource.REGEX,
                        char_start=char_start,
                        char_end=char_end,
                    ))
                    break  # one region per page per phrase
                offset += len(line) + 1  # +1 for the \n separator

    if new_regions:
        logger.info(
            "Cross-page phrase discovery: found %d new ORG region(s) "
            "from %d unique phrase(s) repeating across pages",
            len(new_regions), len(validated),
        )

    return existing_regions + new_regions
