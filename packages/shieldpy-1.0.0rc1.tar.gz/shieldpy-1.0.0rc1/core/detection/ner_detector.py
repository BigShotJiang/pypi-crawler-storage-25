"""spaCy NER-based PII detector — Layer 2 of the hybrid pipeline.

Detects named entities: PERSON, ORG, GPE, DATE, LOC, MONEY, etc.
Supports transformer models (en_core_web_trf) for highest accuracy,
with automatic fallback to lg → sm.  Long texts are processed in
overlapping chunks so NER quality stays high.

When no spaCy model is available, a lightweight heuristic name
detector provides basic name coverage as a fallback.
"""

from __future__ import annotations

import logging
import re
import threading
from dataclasses import dataclass, field
from typing import Callable, NamedTuple

from models.schemas import PIIType

# Import from split-out modules (M8: modular NER architecture)
from core.detection.ner_types import (
    NERMatch,
    LangNERConfig as _LangNERConfig,
    SPACY_EN_LABEL_MAP,
    SPACY_FR_LABEL_MAP,
    SPACY_IT_LABEL_MAP,
    SPACY_DE_LABEL_MAP,
    SPACY_ES_LABEL_MAP,
    SPACY_NL_LABEL_MAP,
    SPACY_PT_LABEL_MAP,
    MIN_ENTITY_LENGTH,
)
from core.detection.ner_stopwords import (
    get_en_stop_words as _get_en_stop_words,
    get_fr_stop_words as _get_fr_stop_words,
    get_it_stop_words as _get_it_stop_words,
    get_de_stop_words as _get_de_stop_words,
    get_es_stop_words as _get_es_stop_words,
    get_nl_stop_words as _get_nl_stop_words,
    get_pt_stop_words as _get_pt_stop_words,
    get_en_stop_lower as _get_en_stop_lower,
    get_fr_stop_lower as _get_fr_stop_lower,
    get_it_stop_lower as _get_it_stop_lower,
    get_de_stop_lower as _get_de_stop_lower,
    get_es_stop_lower as _get_es_stop_lower,
    get_nl_stop_lower as _get_nl_stop_lower,
    get_pt_stop_lower as _get_pt_stop_lower,
    is_language as _is_language,
    is_english_text as _is_english_text,
    is_french_text as _is_french_text,
    is_italian_text as _is_italian_text,
    is_german_text as _is_german_text,
    is_spanish_text as _is_spanish_text,
    is_dutch_text as _is_dutch_text,
    is_portuguese_text as _is_portuguese_text,
    LANG_SAMPLE_SIZE as _LANG_SAMPLE_SIZE,
    ENGLISH_STOPWORD_THRESHOLD as _ENGLISH_STOPWORD_THRESHOLD,
    FRENCH_STOPWORD_THRESHOLD as _FRENCH_STOPWORD_THRESHOLD,
    ITALIAN_STOPWORD_THRESHOLD as _ITALIAN_STOPWORD_THRESHOLD,
)
# Import language-specific NER from split module (M8: modular NER)
from core.detection.ner_languages import (
    detect_ner_french,
    detect_ner_italian,
    detect_ner_german,
    detect_ner_spanish,
    detect_ner_dutch,
    detect_ner_portuguese,
    is_french_ner_available,
    is_italian_ner_available,
    is_german_ner_available,
    is_spanish_ner_available,
    is_dutch_ner_available,
    is_portuguese_ner_available,
    unload_language_models as _unload_language_models,
)

logger = logging.getLogger(__name__)

# Re-export label maps with original names for backward compatibility
_SPACY_LABEL_MAP = SPACY_EN_LABEL_MAP
_SPACY_FR_LABEL_MAP = SPACY_FR_LABEL_MAP
_SPACY_IT_LABEL_MAP = SPACY_IT_LABEL_MAP
_SPACY_DE_LABEL_MAP = SPACY_DE_LABEL_MAP
_SPACY_ES_LABEL_MAP = SPACY_ES_LABEL_MAP
_SPACY_NL_LABEL_MAP = SPACY_NL_LABEL_MAP
_SPACY_PT_LABEL_MAP = SPACY_PT_LABEL_MAP
_MIN_ENTITY_LENGTH = MIN_ENTITY_LENGTH

# ---------------------------------------------------------------------------
# False-positive filters and stopwords (PII detection specific)
# ---------------------------------------------------------------------------

# Common false-positive strings for PERSON type
_PERSON_STOPWORDS: set[str] = {
    "the", "a", "an", "this", "that", "it", "i", "we", "you", "he", "she",
    "my", "your", "his", "her", "our", "their", "its",
    "mr", "mrs", "ms", "dr", "prof",  # titles alone without a name
    "dear", "hi", "hello", "yes", "no", "ok", "please", "thank", "thanks",
    "january", "february", "march", "april", "may", "june",
    "july", "august", "september", "october", "november", "december",
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
    "page", "section", "table", "figure", "chapter", "appendix",
    "total", "amount", "balance", "date", "number", "type",
}

# Job titles / roles that spaCy often appends to PERSON entities
_TITLE_SUFFIXES: set[str] = {
    "chairman", "chairwoman", "chairperson", "chair",
    "president", "vice", "director", "officer", "manager",
    "chief", "executive", "ceo", "cfo", "coo", "cto", "cio",
    "secretary", "treasurer", "counsel", "attorney",
    "partner", "associate", "analyst", "consultant",
    "md", "svp", "evp", "vp",
    "head", "lead", "senior", "junior",
}

# Strings that NER models frequently misclassify for ORG/DATE/LOC
_GENERIC_STOPWORDS: set[str] = {
    "q1", "q2", "q3", "q4", "fy", "ytd", "mtd",
    "n/a", "na", "tbd", "tba", "etc", "pdf", "doc",
    "inc", "llc", "ltd", "corp",  # too short to be useful alone
    "quarterly", "annual", "monthly", "weekly", "daily",
    "next", "last", "previous", "current", "recent",
    "today", "tomorrow", "yesterday",
    "above", "below", "total", "subtotal", "grand",
}

# Common false-positive strings for ORG type
_ORG_STOPWORDS: set[str] = {
    "inc", "llc", "ltd", "corp", "co", "plc",
    "department", "section", "division", "group", "team",
    "committee", "board", "council", "commission",
    "act", "law", "regulation", "policy", "standard",
    "agreement", "contract", "report", "summary",
    "schedule", "exhibit", "annex", "appendix",
    "article", "clause", "provision", "amendment",
    "table", "figure", "chart", "graph",
}

# spaCy model (lazy-loaded)
_nlp = None
_active_model_name: str = ""

# Lock protecting lazy model initialisation (all languages)
_model_lock = threading.Lock()

# Model cascade order depending on user preference
_MODEL_CASCADE: dict[str, list[str]] = {
    "trf": ["en_core_web_trf", "en_core_web_lg", "en_core_web_sm"],
    "lg":  ["en_core_web_lg", "en_core_web_sm"],
    "sm":  ["en_core_web_sm"],
}

# Chunking parameters (in characters)
_CHUNK_SIZE = 100_000          # Process in 100k-char chunks
_CHUNK_OVERLAP = 500           # 500-char overlap so entities at boundaries aren't lost


def _load_model() -> object:
    """Lazy-load the best available spaCy model based on config preference.

    Thread-safe: uses ``_model_lock`` so concurrent requests don't race.
    Will NOT auto-download models at runtime — raises RuntimeError if
    none are installed.
    """
    global _nlp, _active_model_name
    if _nlp is not None:  # fast path — no lock needed once loaded
        return _nlp

    with _model_lock:
        # Double-check after acquiring lock
        if _nlp is not None:
            return _nlp

        import spacy
        from core.config import config

        preference = getattr(config, "ner_model_preference", "trf")
        cascade = _MODEL_CASCADE.get(preference, _MODEL_CASCADE["trf"])

        for model_name in cascade:
            try:
                _nlp = spacy.load(model_name)
                _active_model_name = model_name
                logger.info("Loaded spaCy model '%s'", model_name)
                return _nlp
            except OSError:
                logger.info("spaCy model '%s' not installed — trying next", model_name)

        raise RuntimeError(
            "No spaCy NER model available. Install one with: "
            "python -m spacy download en_core_web_lg"
        )


# ── Unified false-positive helpers (M7: dedup EN/FR/IT) ──────────

def _is_false_positive_person_generic(text: str, stopwords: set[str]) -> bool:
    """Return True if a PERSON entity is likely a false positive.

    Shared logic for all languages — only the *stopwords* set differs.
    """
    clean = text.strip().lower()
    if clean in stopwords:
        return True
    if text.isupper() and len(text) <= 5:
        return True
    if text.strip() and text.strip()[0].isdigit():
        return True
    words = text.strip().split()
    if len(words) == 1 and len(words[0]) <= 3:
        return True
    return False


def _is_false_positive_org_generic(
    text: str,
    org_stopwords: set[str],
    generic_stopwords: set[str] | None = None,
) -> bool:
    """Return True if an ORG entity is likely a false positive.

    Shared logic for all languages.  *generic_stopwords* is only used by
    English (pass ``None`` for FR/IT).
    """
    clean = text.strip()
    low = clean.lower()
    if low in org_stopwords:
        return True
    if generic_stopwords and low in generic_stopwords:
        return True
    if len(clean) <= 2:
        return True
    if clean.isupper() and len(clean) <= 4:
        return True
    # Pure digits / punctuation — except 4+ digit numbers (numbered companies, e.g. "9032")
    if clean.isdigit() and len(clean) < 4:
        return True
    if clean and clean[0].isdigit() and not clean.isdigit():
        return True
    # All-lowercase single/two-word — real org names are capitalised
    words = clean.split()
    if clean == low and len(words) <= 2:
        return True
    return False


def _is_false_positive_person(text: str) -> bool:
    return _is_false_positive_person_generic(text, _PERSON_STOPWORDS)


def _is_false_positive_org(text: str) -> bool:
    return _is_false_positive_org_generic(text, _ORG_STOPWORDS, _GENERIC_STOPWORDS)


# ── Per-language NER configuration (M7: dedup EN/FR/IT) ──────────
# _LangNERConfig is imported from ner_types module


def _get_active_en_model() -> str:
    return _active_model_name


_EN_CONFIG = _LangNERConfig(
    label_map=_SPACY_LABEL_MAP,
    article_prefixes=("the ", "The ", "a ", "A ", "an ", "An "),
    strip_title_suffixes=True,
    fp_person=_is_false_positive_person,
    fp_org=_is_false_positive_org,
    generic_stopwords_filter=True,
    active_model_name=_get_active_en_model,
    base_confidence={
        PIIType.PERSON: 0.80, PIIType.ORG: 0.40,
        PIIType.LOCATION: 0.25, PIIType.ADDRESS: 0.55,
    },
    person_multiword_cap=0.95,
    org_3word_cap=0.80,
    person_single_penalty=0.20,
    org_single_floor=0.25,
    model_boost_tiers=(("_trf", 0.08, 0.98), ("_lg", 0.03, 0.95)),
)


# ── Unified _process_chunk / _estimate_confidence (M7) ──────────

def _process_chunk_generic(
    nlp, text: str, global_offset: int, cfg: _LangNERConfig,
) -> list[NERMatch]:
    """Run NER on a single text chunk — shared logic for all languages."""
    doc = nlp(text)
    matches: list[NERMatch] = []

    for ent in doc.ents:
        pii_type = cfg.label_map.get(ent.label_)
        if pii_type is None:
            continue

        raw_text = ent.text.replace("\n", " ")
        cleaned = raw_text.strip()

        # Strip leading articles
        for prefix in cfg.article_prefixes:
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix):].strip()
                break

        # For ORG entities, strip leading company-context words
        # (e.g., FR "société X" → "X", "compagnie Y" → "Y")
        if pii_type == PIIType.ORG and cfg.org_context_prefixes:
            for ctx_prefix in cfg.org_context_prefixes:
                if cleaned.lower().startswith(ctx_prefix.lower()):
                    cleaned = cleaned[len(ctx_prefix):].strip()
                    break

        # For PERSON entities, trim trailing job titles (EN only)
        if cfg.strip_title_suffixes and pii_type == PIIType.PERSON:
            words = cleaned.split()
            while len(words) > 2 and words[-1].lower() in _TITLE_SUFFIXES:
                words.pop()
            cleaned = " ".join(words)

        min_len = _MIN_ENTITY_LENGTH.get(pii_type, 2)
        if len(cleaned) < min_len:
            continue

        if pii_type == PIIType.PERSON and cfg.fp_person(cleaned):
            continue
        if pii_type == PIIType.ORG and cfg.fp_org(cleaned):
            continue

        # Generic noise filters
        if cleaned.isupper() and len(cleaned) <= 5:
            continue
        if cleaned.isdigit() and not (pii_type == PIIType.ORG and len(cleaned) >= 4):
            continue
        if cfg.generic_stopwords_filter and cleaned.lower() in _GENERIC_STOPWORDS:
            continue

        # Compute char offsets from the original entity span but
        # advance start when article/context prefixes were stripped so
        # the bbox covers only the cleaned text.
        prefix_stripped = len(ent.text) - len(ent.text.lstrip()) + (
            len(ent.text.lstrip()) - len(raw_text)
            if len(ent.text.lstrip()) > len(raw_text) else 0
        )
        # Additionally account for article and context prefix stripping:
        # cleaned starts after those prefixes relative to raw_text.
        offset_in_raw = raw_text.find(cleaned) if cleaned in raw_text else 0
        start_char = ent.start_char + offset_in_raw
        end_char = start_char + len(cleaned)
        confidence = _estimate_confidence_generic(ent, pii_type, cfg)
        matches.append(NERMatch(
            start=global_offset + start_char,
            end=global_offset + end_char,
            text=cleaned,
            pii_type=pii_type,
            confidence=confidence,
        ))

    return matches


def _estimate_confidence_generic(ent, pii_type: PIIType, cfg: _LangNERConfig) -> float:
    """Estimate confidence for a spaCy entity — shared logic for all languages."""
    conf = cfg.base_confidence.get(pii_type, 0.40)

    text = ent.text.strip()
    word_count = len(text.split())

    if word_count >= 2 and pii_type == PIIType.PERSON:
        conf = min(conf + 0.08, cfg.person_multiword_cap)
    if word_count >= 2 and pii_type == PIIType.ORG:
        conf = min(conf + 0.15, 0.80)
    if word_count >= 3 and pii_type == PIIType.ORG:
        conf = min(conf + 0.05, cfg.org_3word_cap)

    if pii_type == PIIType.PERSON and word_count == 1:
        conf = max(conf - cfg.person_single_penalty, 0.40)
    if pii_type == PIIType.ORG and word_count == 1:
        conf = max(conf - 0.15, cfg.org_single_floor)
    if pii_type == PIIType.LOCATION and word_count == 1:
        conf = max(conf - 0.10, 0.30)

    model_name = cfg.active_model_name()
    for suffix, delta, cap in cfg.model_boost_tiers:
        if model_name.endswith(suffix):
            conf = min(conf + delta, cap)
            break

    return round(conf, 4)


def _process_chunk(nlp, text: str, global_offset: int) -> list[NERMatch]:
    return _process_chunk_generic(nlp, text, global_offset, _EN_CONFIG)


def _estimate_confidence(ent, pii_type: PIIType) -> float:
    return _estimate_confidence_generic(ent, pii_type, _EN_CONFIG)


def _deduplicate_matches(matches: list[NERMatch]) -> list[NERMatch]:
    """Remove duplicate matches from overlapping chunks.

    When two matches overlap (same span or one contains the other),
    keep the one with the higher confidence.
    """
    if not matches:
        return []

    matches = sorted(matches, key=lambda m: (m.start, -(m.end - m.start)))
    deduped: list[NERMatch] = [matches[0]]

    for m in matches[1:]:
        prev = deduped[-1]
        # Same or overlapping span
        if m.start < prev.end:
            # Keep the one with higher confidence or longer span
            if m.confidence > prev.confidence or (m.end - m.start) > (prev.end - prev.start):
                deduped[-1] = m
        else:
            deduped.append(m)

    return deduped


def detect_ner(text: str) -> list[NERMatch]:
    """
    Run spaCy NER on text and return matches for PII-relevant entity types.

    Long texts are split into overlapping chunks so NER accuracy stays high.
    Skips detection entirely if the text does not appear to be English,
    since the English NER model produces only noise on other languages.
    """
    if not _is_english_text(text):
        logger.info("Text does not appear to be English — skipping NER")
        return []

    nlp = _load_model()

    # Short texts — single pass (fast path)
    if len(text) <= _CHUNK_SIZE:
        return _process_chunk(nlp, text, global_offset=0)

    # Long texts — overlapping sliding-window
    all_matches: list[NERMatch] = []
    offset = 0
    while offset < len(text):
        end = min(offset + _CHUNK_SIZE, len(text))
        chunk = text[offset:end]
        chunk_matches = _process_chunk(nlp, chunk, global_offset=offset)
        all_matches.extend(chunk_matches)

        # Advance by (chunk_size - overlap)
        offset += _CHUNK_SIZE - _CHUNK_OVERLAP
        if end == len(text):
            break

    return _deduplicate_matches(all_matches)


# ---------------------------------------------------------------------------
# NER language registry — unified dispatch for multilingual NER
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class NERLanguageEntry:
    """Registry entry for a language-specific NER backend."""
    lang_code: str
    lang_label: str
    is_text: Callable[[str], bool]       # e.g. _is_french_text
    is_available: Callable[[], bool]     # e.g. is_french_ner_available
    detect: Callable[[str], list[NERMatch]]  # e.g. detect_ner_french


NER_LANGUAGE_REGISTRY: list[NERLanguageEntry] = [
    NERLanguageEntry("fr", "French", _is_french_text, is_french_ner_available, detect_ner_french),
    NERLanguageEntry("it", "Italian", _is_italian_text, is_italian_ner_available, detect_ner_italian),
    NERLanguageEntry("de", "German", _is_german_text, is_german_ner_available, detect_ner_german),
    NERLanguageEntry("es", "Spanish", _is_spanish_text, is_spanish_ner_available, detect_ner_spanish),
    NERLanguageEntry("nl", "Dutch", _is_dutch_text, is_dutch_ner_available, detect_ner_dutch),
    NERLanguageEntry("pt", "Portuguese", _is_portuguese_text, is_portuguese_ner_available, detect_ner_portuguese),
]


def detect_ner_multilingual(text: str) -> list[tuple[str, list[NERMatch]]]:
    """Run all applicable non-English NER models and return (lang_code, matches) pairs.

    Only runs models for languages detected in the text. Skips English text.
    """
    if _is_english_text(text):
        return []

    results: list[tuple[str, list[NERMatch]]] = []
    for entry in NER_LANGUAGE_REGISTRY:
        if entry.is_text(text) and entry.is_available():
            try:
                matches = entry.detect(text)
                if matches:
                    results.append((entry.lang_code, matches))
            except Exception as e:
                logger.error("%s NER detection failed: %s", entry.lang_label, e)
    return results


# ---------------------------------------------------------------------------
# Lightweight heuristic name detector (fallback when spaCy isn't available)
# ---------------------------------------------------------------------------

# Common first names (top ~150 English + ~80 multilingual first names)
# for heuristic matching.
# EXCLUDES names that are also common English words (Grace, Mark, Frank, etc.)
# to avoid false positives on document text.
_COMMON_FIRST_NAMES: set[str] = {
    # English
    "james", "john", "robert", "michael", "david", "william", "richard",
    "joseph", "thomas", "charles", "christopher", "daniel", "matthew",
    "anthony", "donald", "steven", "paul", "andrew", "joshua",
    "kenneth", "kevin", "brian", "george", "timothy", "ronald", "edward",
    "jason", "jeffrey", "ryan", "jacob", "nicholas", "eric",
    "jonathan", "stephen", "larry", "justin", "scott", "brandon", "benjamin",
    "samuel", "raymond", "gregory", "patrick", "alexander",
    "dennis", "jerry", "tyler", "aaron", "jose", "nathan", "henry", "peter",
    "adam", "zachary", "walter", "kyle", "harold", "carl", "jeremy", "roger",
    "keith", "gerald", "eugene", "terry", "sean", "austin", "arthur", "jesse",
    "dylan", "bryan", "jordan", "bruce", "albert", "willie",
    "gabriel", "logan", "ralph", "lawrence", "wayne", "elijah", "randy",
    "vincent", "philip", "bobby", "johnny", "bradley",
    "mary", "patricia", "jennifer", "linda", "barbara", "elizabeth", "susan",
    "jessica", "sarah", "karen", "lisa", "nancy", "betty", "margaret", "sandra",
    "ashley", "dorothy", "kimberly", "emily", "donna", "michelle", "carol",
    "amanda", "melissa", "deborah", "stephanie", "rebecca", "sharon", "laura",
    "cynthia", "kathleen", "amy", "angela", "shirley", "anna", "brenda",
    "pamela", "emma", "nicole", "helen", "samantha", "katherine", "christine",
    "debra", "rachel", "carolyn", "janet", "catherine", "maria", "heather",
    "diane", "ruth", "julie", "olivia", "joyce", "virginia", "victoria",
    "kelly", "lauren", "christina", "joan", "evelyn", "judith", "megan",
    "andrea", "cheryl", "hannah", "jacqueline", "martha", "gloria", "teresa",
    "sara", "madison", "frances", "kathryn", "janice", "jean", "abigail",
    "alice", "judy", "sophia", "denise", "doris", "marilyn",
    "danielle", "beverly", "isabella", "theresa", "diana", "natalie", "brittany",
    "charlotte", "marie", "kayla", "alexis", "lori",
    # French
    "jean", "pierre", "jacques", "philippe", "michel", "alain", "nicolas",
    "françois", "francois", "henri", "louis", "laurent", "bernard",
    "marie", "sophie", "isabelle", "nathalie", "céline", "celine",
    "valérie", "valerie", "christine", "sylvie", "véronique", "veronique",
    "monique", "brigitte", "pascal", "thierry", "yves", "denis",
    "bruno", "rené", "rene", "judes", "claude", "luc", "marc", "gilles",
    "serge", "andré", "andre", "gaston", "réal", "real", "normand",
    "lucien", "fernand", "léo", "leo", "guy", "roger", "raymond",
    "sylvain", "martin", "simon", "benoît", "benoit", "éric", "eric",
    "dominique", "frédéric", "frederic", "sébastien", "sebastien",
    "patrice", "stéphane", "stephane", "mathieu", "maxime", "hugo",
    "julien", "vincent", "gabriel", "raphaël", "raphael", "émile", "emile",
    "lucie", "julie", "anne", "manon", "josée", "josee", "hélène", "helene",
    "francine", "ginette", "denise", "jocelyne", "chantal", "mireille",
    # German
    "hans", "klaus", "wolfgang", "dieter", "jürgen", "jurgen",
    "karsten", "matthias", "stefan", "andreas", "markus", "bernd",
    "werner", "helmut", "gerhard", "rainer", "heinz", "ernst",
    "uwe", "manfred", "horst", "gerd", "ulrich", "franz",
    "sabine", "monika", "petra", "ursula", "karin", "renate",
    "ingrid", "helga", "christa", "gudrun", "elfriede",
    # Spanish
    "carlos", "miguel", "fernando", "rafael", "alejandro", "javier",
    "sergio", "jorge", "pablo", "ángel", "angel", "jesús", "jesus",
    "ramón", "ramon", "antonio", "roberto", "pedro", "alberto",
    "carmen", "marta", "pilar", "mercedes", "consuelo", "rosario",
    "dolores", "cristina", "elena", "beatriz", "lucía", "lucia",
    # Italian
    "giuseppe", "giovanni", "marco", "mario", "francesco", "antonio",
    "alessandro", "andrea", "stefano", "matteo", "lorenzo",
    "roberto", "paolo", "giorgio", "luca", "riccardo",
    "giulia", "francesca", "valentina", "chiara", "alessandra",
    "federica", "silvia", "eleonora", "claudia", "simona",
    # Dutch
    "johannes", "willem", "hendrik", "cornelis", "pieter",
    "gerrit", "jacobus", "theodorus",
    "johanna", "geertruida",
    # Portuguese
    "joão", "joao", "pedro", "fernando", "paulo", "rui",
    "ricardo", "tiago", "gonçalo", "goncalo", "nuno",
    "ana", "isabel", "beatriz", "mariana", "catarina",
}

# Patterns for the heuristic fallback — use literal space (not \s+) so
# we don't match across tab-separated columns or wide whitespace.
# Support accented capitals (À-Ü) for multilingual name matching.
# Match Title Case ("Jean Dupont") and ALL CAPS ("JEAN DUPONT").
_NAME_WORD = r"(?:[A-ZÀ-Ü][a-zà-ÿ]{1,20}|[A-ZÀ-Ü]{2,20})"
_CAPITALIZED_NAME = re.compile(
    rf"\b({_NAME_WORD}) ({_NAME_WORD}(?: {_NAME_WORD})?)\b"
)


def detect_names_heuristic(text: str) -> list[NERMatch]:
    """
    Lightweight heuristic name detection — used as a fallback when
    no spaCy or BERT model is available.

    Looks for sequences of 2-3 capitalized words where the first word
    is a known common first name. Works for all supported languages.
    """

    matches: list[NERMatch] = []

    for m in _CAPITALIZED_NAME.finditer(text):
        first_word = m.group(1).lower()
        if first_word not in _COMMON_FIRST_NAMES:
            continue

        full_match = m.group(0)

        # Trim at newline
        nl_idx = full_match.find("\n")
        if nl_idx > 0:
            full_match = full_match[:nl_idx].strip()
        if len(full_match.split()) < 2:
            continue

        # Skip if it looks like a title or header (all words capitalized
        # in a short line is suspicious)
        if _is_false_positive_person(full_match):
            continue

        # Skip if any word is in generic stopwords (catches "John Total" etc.)
        # or is a job title (catches "David Chairman" etc.)
        words = full_match.lower().split()
        if any(w in _GENERIC_STOPWORDS or w in _PERSON_STOPWORDS or w in _TITLE_SUFFIXES for w in words):
            continue

        word_count = len(full_match.split())
        # Low confidence so heuristic alone doesn't survive threshold;
        # it only shows if NER or regex also flags the same span (cross-layer boost).
        confidence = 0.50 if word_count == 2 else 0.55

        matches.append(NERMatch(
            start=m.start(),
            end=m.end(),
            text=full_match,
            pii_type=PIIType.PERSON,
            confidence=confidence,
        ))

    return _deduplicate_matches(matches)


def get_active_model_name() -> str:
    """Return the name of the currently loaded spaCy model."""
    return _active_model_name


def is_ner_available() -> bool:
    """Check if NER is available without raising."""
    try:
        _load_model()
        return True
    except Exception:
        return False


def unload_models() -> None:
    """Free memory held by all loaded spaCy NER models."""
    global _nlp, _active_model_name
    with _model_lock:
        _nlp = None
        _active_model_name = ""
    # Unload language-specific models from ner_languages module
    _unload_language_models()
    logger.info("spaCy NER models unloaded")
