"""Detection merge — combines results from all detector layers into
unified PIIRegion instances with cross-layer boosting, overlap
resolution, noise filtering, and shape enforcement.
"""

from __future__ import annotations

import logging
import re
import uuid

from core.config import config
from core.detection import detection_config as det_cfg
from core.detection.bbox_utils import _resolve_bbox_overlaps
from core.detection.block_offsets import (
    _clamp_bbox,
    _compute_block_offsets,
    _char_offset_to_bbox,
    _char_offsets_to_line_bboxes,
)
from core.detection.noise_filters import (
    _is_org_pipeline_noise,
    _is_loc_pipeline_noise,
    _is_person_pipeline_noise,
    _is_address_number_only,
    _strip_phone_labels_from_address,
    _STRUCTURED_MIN_DIGITS,
    has_legal_suffix,
)
from core.detection.region_shapes import (
    _enforce_region_shapes,
    _max_lines_for_type,
)
from core.detection.regex_detector import RegexMatch
from core.detection.ner_detector import NERMatch
from core.detection.gliner_detector import GLiNERMatch
from core.detection.llm_detector import LLMMatch
from models.schemas import (
    BBox,
    DetectionSource,
    PIIRegion,
    PIIType,
    PageData,
    TextBlock,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Spatial proximity — max gap between consecutive linked bboxes
# (see detection_config.py for documentation)
# ---------------------------------------------------------------------------

_MAX_Y_GAP_FACTOR = det_cfg.MAX_Y_GAP_FACTOR
_MIN_Y_GAP_ABS = det_cfg.MIN_Y_GAP_ABS


def _reconstruct_text_from_blocks(blocks: list[TextBlock]) -> str:
    """Join block texts respecting visual line structure.

    Blocks on the same visual line (y-centres within half a line-height)
    are joined with spaces; distinct lines are joined with newlines.
    Within each line blocks are ordered left-to-right by x0.
    """
    if not blocks:
        return ""
    # Cluster into visual lines by y-centre proximity
    sorted_blks = sorted(blocks, key=lambda b: (b.bbox.y0, b.bbox.x0))
    lines: list[list[TextBlock]] = [[sorted_blks[0]]]
    for blk in sorted_blks[1:]:
        prev_line = lines[-1]
        prev_yc = sum((b.bbox.y0 + b.bbox.y1) / 2 for b in prev_line) / len(prev_line)
        prev_h = max(b.bbox.y1 - b.bbox.y0 for b in prev_line)
        cur_yc = (blk.bbox.y0 + blk.bbox.y1) / 2
        cur_h = blk.bbox.y1 - blk.bbox.y0
        tol = max(prev_h, cur_h) * 0.6
        if abs(cur_yc - prev_yc) <= tol:
            prev_line.append(blk)
        else:
            lines.append([blk])
    # Within each line sort by x0, then join
    result_lines: list[str] = []
    for line in lines:
        line.sort(key=lambda b: b.bbox.x0)
        result_lines.append(" ".join(b.text for b in line))
    return "\n".join(result_lines)


def _split_bboxes_by_proximity(
    bboxes: list[BBox],
) -> list[list[int]]:
    """Split bbox indices into spatially contiguous groups.

    Returns a list of index-lists.  Bboxes are sorted by y0;
    a new group starts whenever the vertical gap between consecutive
    bboxes exceeds ``_MAX_Y_GAP_FACTOR × avg_line_height``.

    Additionally, within each group, bboxes are checked for large
    horizontal x-centre gaps (>5× avg line height) indicating different
    page columns.  When detected, the group is split into one sub-group
    per column.

    The column-split heuristic only fires when the two sub-groups being
    compared are on the **same visual line** (y-centre difference ≤ 0.8×
    avg line height).  When bboxes are on adjacent lines (different
    y-positions), a large x-gap is normal text wrapping — not separate
    columns — so the group is kept whole.  This prevents entities that
    wrap from the end of one line to the beginning of the next (e.g.
    ``Les entreprises de restauration\\nB.N. Ltée``) from being
    incorrectly split.
    """
    if len(bboxes) <= 1:
        return [list(range(len(bboxes)))]

    indexed = sorted(range(len(bboxes)), key=lambda i: (bboxes[i].y0, bboxes[i].x0))
    avg_h = sum(b.y1 - b.y0 for b in bboxes) / len(bboxes)
    y_threshold = max(avg_h * _MAX_Y_GAP_FACTOR, _MIN_Y_GAP_ABS)

    # Step 1: vertical proximity grouping
    v_groups: list[list[int]] = [[indexed[0]]]
    for k in range(1, len(indexed)):
        prev_y1 = bboxes[indexed[k - 1]].y1
        curr_y0 = bboxes[indexed[k]].y0
        if curr_y0 - prev_y1 > y_threshold:
            v_groups.append([])
        v_groups[-1].append(indexed[k])

    # Step 2: within each vertical group, detect column splits by
    # sorting bbox x-centres and finding a large gap.
    x_col_threshold = avg_h * det_cfg.COLUMN_SPLIT_X_GAP_FACTOR
    # Only consider it a true column split if the candidate sub-groups
    # are on the same visual line.  Adjacent lines with large x-gaps are
    # just text wrapping, not columns.
    _same_line_y_tol = avg_h * det_cfg.SAME_LINE_Y_TOLERANCE
    final_groups: list[list[int]] = []
    for grp in v_groups:
        if len(grp) <= 1:
            final_groups.append(grp)
            continue
        # Sort group members by x-centre
        cx_sorted = sorted(grp, key=lambda i: (bboxes[i].x0 + bboxes[i].x1) / 2)
        max_gap = 0.0
        split_at = 0
        for gi in range(1, len(cx_sorted)):
            prev_cx = (bboxes[cx_sorted[gi - 1]].x0 + bboxes[cx_sorted[gi - 1]].x1) / 2
            cur_cx = (bboxes[cx_sorted[gi]].x0 + bboxes[cx_sorted[gi]].x1) / 2
            gap = cur_cx - prev_cx
            if gap > max_gap:
                max_gap = gap
                split_at = gi
        if max_gap > x_col_threshold:
            # Verify the split candidates are on the same visual line.
            # Compute the average y-centre for each candidate sub-group.
            left_yc = sum(
                (bboxes[i].y0 + bboxes[i].y1) / 2 for i in cx_sorted[:split_at]
            ) / max(len(cx_sorted[:split_at]), 1)
            right_yc = sum(
                (bboxes[i].y0 + bboxes[i].y1) / 2 for i in cx_sorted[split_at:]
            ) / max(len(cx_sorted[split_at:]), 1)
            if abs(left_yc - right_yc) <= _same_line_y_tol:
                # True column split: sub-groups are on the same line.
                final_groups.append(cx_sorted[:split_at])
                final_groups.append(cx_sorted[split_at:])
            else:
                # Different lines — just text wrapping, keep together.
                final_groups.append(grp)
        else:
            final_groups.append(grp)

    return final_groups


def _merge_detections(
    regex_matches: list[RegexMatch],
    ner_matches: list[NERMatch],
    llm_matches: list[LLMMatch],
    page_data: PageData,
    gliner_matches: list[GLiNERMatch] | None = None,
) -> list[PIIRegion]:
    """Merge detection results from all layers into unified PIIRegion list.

    Pipeline stages (in order):
      S1. Convert matches → common ``{start, end, text, pii_type, confidence,
          source, priority}`` dicts. Structured types (SSN, EMAIL, …) get
          priority 3 (regex) or 1 (LLM); semi-structured (ORG, ADDRESS) get 2.
      S2. Cross-layer confidence boost: when ≥2 layers agree on the same span
          (overlap ratio ≥ ``PROPAGATION_OVERLAP_RATIO``), bump confidence by
          ``BOOST_2_LAYERS`` or ``BOOST_3_LAYERS`` (configured in
          ``detection_config.py``).
      S3. Visual-grouping boost (ORG only): +``BOOST_VISUAL`` when the text is
          (a) inside quotation marks, (b) bold/italic, (c) horizontally
          centred, or (d) title-case multi-word.
      S4. Quoted-text extension: PERSON/ORG partially inside quotes → extend
          to full quoted expression.
      S5. Overlap resolution: sort by ``(start, -priority)``, merge overlapping
          spans. Same-type → union of spans; different-type → longer span wins.
          Capped at ``MAX_MERGE_CHARS`` to prevent snowball merging.
      S6. Adjacent PERSON merge: consecutive names separated by a single space
          are joined into the full name.
      S7. Noise filter pass (``_is_candidate_noise``): structural gates (digit
          counts, min alpha chars) + type-specific heuristics with visual-boost
          exception.
      S8. Spatial coherence: truncate candidates whose underlying TextBlocks
          are vertically scattered to the first contiguous line run.
      S9. ORG/PERSON newline split: multi-line spans → per-line segments
          (unless legal suffix or two-line entity).
      S10. ADDRESS fragment merge: adjacent ADDRESS/LOCATION spans within
           ``ADDRESS_MERGE_MAX_GAP`` chars are combined.
      S11. Paren stripping and phone-label cleanup.
      S12. PIIRegion conversion: map char offsets → per-line bboxes using
           ``_char_offsets_to_line_bboxes``, split into spatially contiguous
           clusters, create linked groups for multi-line regions.
      S13. Shape enforcement + bbox overlap resolution.
      S14. Final safety-net noise pass (same filters as S7 on PIIRegion).
    """
    structured_types = {
        PIIType.SSN, PIIType.EMAIL, PIIType.PHONE,
        PIIType.CREDIT_CARD, PIIType.IBAN, PIIType.IP_ADDRESS,
        PIIType.DATE,
    }
    semi_structured_types = {PIIType.ORG, PIIType.ADDRESS}

    # ── Convert to common intermediate format ────────────────────────
    candidates: list[dict] = []

    for m in regex_matches:
        if m.pii_type in structured_types:
            prio = 3
        elif m.pii_type in semi_structured_types:
            prio = 2
        else:
            prio = 1
        cand = {
            "start": m.start, "end": m.end, "text": m.text,
            "pii_type": m.pii_type, "confidence": m.confidence,
            "source": DetectionSource.REGEX,
            "priority": prio,
        }
        if getattr(m, "is_custom_pattern", False):
            cand["is_custom_pattern"] = True
        candidates.append(cand)

    for m in ner_matches:
        if m.pii_type in (PIIType.PHONE, PIIType.SSN, PIIType.DRIVER_LICENSE):
            digits = sum(c.isdigit() for c in m.text)
            if m.pii_type == PIIType.PHONE and digits < 7:
                logger.debug("Skipping NER PHONE with too few digits: %r", m.text)
                continue
            if m.pii_type == PIIType.SSN and digits < 7:
                logger.debug("Skipping NER SSN with too few digits: %r", m.text)
                continue
            if m.pii_type == PIIType.DRIVER_LICENSE and digits < 6:
                logger.debug("Skipping NER DRIVER_LICENSE with too few digits: %r", m.text)
                continue
            if m.pii_type in (PIIType.PHONE, PIIType.SSN) and "." in m.text:
                logger.debug("Skipping NER %s with decimal point (financial): %r", m.pii_type.value, m.text)
                continue
            if m.pii_type in (PIIType.PHONE, PIIType.SSN) and "_" in m.text:
                logger.debug("Skipping NER %s with underscore (OCR artifact): %r", m.pii_type.value, m.text)
                continue
        if m.pii_type == PIIType.PASSPORT:
            if "-" in m.text or "(" in m.text or ")" in m.text:
                logger.debug("Skipping NER PASSPORT with phone formatting: %r", m.text)
                continue
        candidates.append({
            "start": m.start, "end": m.end, "text": m.text,
            "pii_type": m.pii_type, "confidence": m.confidence,
            "source": DetectionSource.NER,
            "priority": 2,
        })

    for m in (gliner_matches or []):
        if m.pii_type in (PIIType.PHONE, PIIType.SSN, PIIType.DRIVER_LICENSE):
            if "." in m.text and any(c.isdigit() for c in m.text):
                digits = sum(c.isdigit() for c in m.text)
                non_digit = len(m.text.strip()) - digits
                if "," in m.text or non_digit > 2:
                    logger.debug("Skipping GLiNER %s (looks like currency): %r", m.pii_type, m.text)
                    continue
            digits = sum(c.isdigit() for c in m.text)
            if m.pii_type == PIIType.PHONE and digits < 7:
                continue
            if m.pii_type == PIIType.SSN and digits < 7:
                continue
            if m.pii_type == PIIType.DRIVER_LICENSE and digits < 6:
                continue
        candidates.append({
            "start": m.start, "end": m.end, "text": m.text,
            "pii_type": m.pii_type, "confidence": m.confidence,
            "source": DetectionSource.GLINER,
            "priority": 2,
        })

    for m in llm_matches:
        candidates.append({
            "start": m.start, "end": m.end, "text": m.text,
            "pii_type": m.pii_type, "confidence": m.confidence,
            "source": DetectionSource.LLM,
            "priority": 1 if m.pii_type in structured_types else 3,
        })

    # ── Cross-layer confidence boost (see detection_config.py) ────────
    _BOOST_2_LAYERS = det_cfg.BOOST_2_LAYERS
    _BOOST_3_LAYERS = det_cfg.BOOST_3_LAYERS
    _CROSS_LAYER_OVERLAP_RATIO = det_cfg.PROPAGATION_OVERLAP_RATIO

    idx_sorted = sorted(range(len(candidates)), key=lambda k: candidates[k]["start"])

    for ii in range(len(idx_sorted)):
        i = idx_sorted[ii]
        c = candidates[i]
        overlapping_sources: set[str] = {c["source"]}
        c_end = c["end"]

        for jj in range(ii + 1, len(idx_sorted)):
            j = idx_sorted[jj]
            other = candidates[j]
            if other["start"] >= c_end:
                break
            overlap_start = max(c["start"], other["start"])
            overlap_end = min(c_end, other["end"])
            if overlap_end <= overlap_start:
                continue
            overlap_len = overlap_end - overlap_start
            c_len = c_end - c["start"]
            o_len = other["end"] - other["start"]
            if c_len > 0 and o_len > 0:
                ratio = overlap_len / min(c_len, o_len)
                if ratio >= _CROSS_LAYER_OVERLAP_RATIO:
                    overlapping_sources.add(other["source"])

        n_layers = len(overlapping_sources)
        if n_layers >= 3:
            c["confidence"] = min(1.0, c["confidence"] + _BOOST_3_LAYERS)
        elif n_layers == 2:
            c["confidence"] = min(1.0, c["confidence"] + _BOOST_2_LAYERS)

    # ── Visual-grouping confidence boost (ORG only) ──────────────────
    # Three heuristics that increase ORG confidence for multi-word
    # candidates when the text has strong visual or typographic
    # indicators of being an entity name:
    #   1. Enclosed in quotation marks ("...", «...», '...', etc.)
    #   2. Rendered in bold or italic font
    #   3. Horizontally centred on the page (blank margins both sides)
    _BOOST_VISUAL = det_cfg.BOOST_VISUAL

    # Pre-compute block offsets once for bold/italic + centring checks
    _vg_block_offsets = _compute_block_offsets(
        page_data.text_blocks, page_data.full_text,
    )

    # Build a set of character ranges enclosed in quotation marks
    _QUOTE_PAIRS = [('"', '"'), ("'", "'"), ('\u201c', '\u201d'),
                    ('\u201e', '\u201c'),  # German „...“
                    ('\u201e', '\u201d'),  # German „...”
                    ('\u2018', '\u2019'), ('\u00ab', '\u00bb'),
                    ('\u2039', '\u203a'),  # Single guillemets
                    ('\u300c', '\u300d'),  # CJK
                    ('\u300e', '\u300f'),  # CJK double
                    ]
    _quoted_ranges: list[tuple[int, int]] = []
    _ft = page_data.full_text
    for qopen, qclose in _QUOTE_PAIRS:
        start_search = 0
        while True:
            qi = _ft.find(qopen, start_search)
            if qi < 0:
                break
            # Skip ASCII apostrophes used as contractions (e.g., l'examen,
            # d'audit, s'applique).  A true opening quote is preceded by
            # whitespace, punctuation, or is at the start of the text.
            if qopen == "'" and qi > 0 and _ft[qi - 1].isalpha():
                start_search = qi + 1
                continue
            qj = _ft.find(qclose, qi + 1)
            if qj < 0:
                break
            # Similarly skip closing apostrophes that look like contractions
            if qclose == "'" and qj + 1 < len(_ft) and _ft[qj + 1].isalpha():
                start_search = qj + 1
                continue
            # Keep quoted fragments (single-word ORGs like "SIEMENS" are valid)
            fragment = _ft[qi + 1:qj]
            if len(fragment.strip()) >= 2:
                _quoted_ranges.append((qi, qj + 1))
            start_search = qj + 1

    page_width = page_data.width

    for c in candidates:
        if c["pii_type"] != PIIType.ORG:
            continue
        already_boosted = False

        # 1. Quoted-text boost
        for qs, qe in _quoted_ranges:
            if c["start"] >= qs and c["end"] <= qe:
                c["confidence"] = min(1.0, c["confidence"] + _BOOST_VISUAL)
                c["has_visual_boost"] = True
                already_boosted = True
                logger.debug(
                    "Page %d: ORG visual boost (quoted): %r +%.2f",
                    page_data.page_number, c["text"], _BOOST_VISUAL,
                )
                break

        # 2. Bold / italic boost — majority of underlying TextBlocks
        if not already_boosted and _vg_block_offsets:
            styled_count = 0
            total_count = 0
            for blk_start, blk_end, blk in _vg_block_offsets:
                if blk_end <= c["start"] or blk_start >= c["end"]:
                    continue
                total_count += 1
                if blk.is_bold or blk.is_italic:
                    styled_count += 1
            if total_count >= 1 and styled_count > total_count / 2:
                c["confidence"] = min(1.0, c["confidence"] + _BOOST_VISUAL)
                c["has_visual_boost"] = True
                already_boosted = True
                logger.debug(
                    "Page %d: ORG visual boost (bold/italic): %r +%.2f",
                    page_data.page_number, c["text"], _BOOST_VISUAL,
                )

        # 3. Horizontally-centred boost — the *entire line* containing
        #    the ORG has substantial blank margin on both sides (≥12 %
        #    of page width each).  We use the full line extent (all
        #    blocks sharing the same y-range) so that ORGs in the
        #    middle of a normal-width paragraph are not falsely boosted.
        if not already_boosted and _vg_block_offsets and page_width > 0:
            span_blocks = [
                (bs, be, b) for bs, be, b in _vg_block_offsets
                if be > c["start"] and bs < c["end"]
            ]
            if span_blocks:
                # Determine the y-range of the ORG's blocks
                org_y0 = min(b.bbox.y0 for _, _, b in span_blocks)
                org_y1 = max(b.bbox.y1 for _, _, b in span_blocks)
                org_h = org_y1 - org_y0 if org_y1 > org_y0 else 1.0
                # Collect ALL blocks on the same line (overlapping y)
                line_blocks = [
                    b for _, _, b in _vg_block_offsets
                    if b.bbox.y1 > org_y0 and b.bbox.y0 < org_y1
                    and abs((b.bbox.y0 + b.bbox.y1) / 2
                            - (org_y0 + org_y1) / 2) < org_h
                ]
                left_edge = min(b.bbox.x0 for b in line_blocks)
                right_edge = max(b.bbox.x1 for b in line_blocks)
                left_margin = left_edge / page_width
                right_margin = (page_width - right_edge) / page_width
                _MIN_MARGIN = det_cfg.CENTERED_MIN_MARGIN
                if left_margin >= _MIN_MARGIN and right_margin >= _MIN_MARGIN:
                    c["confidence"] = min(1.0, c["confidence"] + _BOOST_VISUAL)
                    c["has_visual_boost"] = True
                    logger.debug(
                        "Page %d: ORG visual boost (centred): %r +%.2f "
                        "(L=%.0f%% R=%.0f%%)",
                        page_data.page_number, c["text"], _BOOST_VISUAL,
                        left_margin * 100, right_margin * 100,
                    )

        # 4. Title-case boost — multi-word ORGs where each word starts with
        #    a capital letter indicate proper nouns (e.g., "Filets Sports
        #    Gaspésiens"). Only apply when there's NO legal suffix, since
        #    legal suffixes already provide strong detection signals.
        if not already_boosted and not has_legal_suffix(c["text"]):
            words = c["text"].split()
            if len(words) >= 2:
                # Check if all words start with uppercase (ignoring articles/prepositions)
                _SKIP_WORDS = {"de", "du", "des", "la", "le", "les", "l'", "d'",
                               "di", "da", "del", "della", "dei", "degli",
                               "of", "the", "and", "&", "et", "und", "e", "y"}
                title_words = [w for w in words if w.lower() not in _SKIP_WORDS]
                if len(title_words) >= 2 and all(
                    w[0].isupper() for w in title_words if len(w) > 0
                ):
                    c["confidence"] = min(1.0, c["confidence"] + _BOOST_VISUAL)
                    c["has_visual_boost"] = True
                    logger.debug(
                        "Page %d: ORG visual boost (title-case): %r +%.2f",
                        page_data.page_number, c["text"], _BOOST_VISUAL,
                    )

    # ── Extend PERSON / ORG to cover full quoted text ─────────────────
    # If a PERSON or ORG candidate is partially inside quotation marks,
    # extend it to cover the entire quoted expression (e.g., « Dixie Lee »
    # should be detected as one "Dixie Lee" even if NER only found "Dixie").
    for c in candidates:
        if c["pii_type"] not in (PIIType.PERSON, PIIType.ORG):
            continue
        for qs, qe in _quoted_ranges:
            # qs is index of opening quote, qe is index after closing quote
            # Inner text is at [qs+1, qe-1)
            inner_start = qs + 1
            inner_end = qe - 1
            # Check if candidate overlaps with the quoted range
            if c["start"] < inner_end and c["end"] > inner_start:
                # Candidate overlaps with quoted text — extend to full inner
                old_text = c["text"]
                c["start"] = inner_start
                c["end"] = inner_end
                c["text"] = _ft[inner_start:inner_end].strip()
                # Adjust start/end to match stripped text
                while c["start"] < inner_end and _ft[c["start"]] in " \t\n":
                    c["start"] += 1
                while c["end"] > c["start"] and _ft[c["end"] - 1] in " \t\n":
                    c["end"] -= 1
                c["text"] = _ft[c["start"]:c["end"]]
                if c["text"] != old_text:
                    logger.debug(
                        "Page %d: %s extended to quoted text: %r -> %r",
                        page_data.page_number, c["pii_type"].value, old_text, c["text"],
                    )
                break  # Only extend once per candidate

    # ── Sort and merge overlapping regions ────────────────────────────
    candidates.sort(key=lambda x: (x["start"], -x["priority"]))

    _MAX_PERSON_WORDS = det_cfg.MAX_PERSON_WORDS

    merged: list[dict] = []
    for cand in candidates:
        if not merged:
            merged.append(cand)
            continue

        last = merged[-1]

        # ── Adjacent PERSON merge ────────────────────────────────────
        # Two consecutive PERSON tokens separated by exactly one space
        # (e.g. "Dagmar" + "Vymetalova") are parts of the same full name.
        # Merge them so the whole name surfaces as a single region.
        if (
            cand["pii_type"] == PIIType.PERSON
            and last["pii_type"] == PIIType.PERSON
            and cand["start"] == last["end"] + 1
            and page_data.full_text[last["end"]:cand["start"]] == " "
            and len(page_data.full_text[last["start"]:cand["end"]].split()) <= _MAX_PERSON_WORDS
        ):
            last["end"] = cand["end"]
            last["text"] = page_data.full_text[last["start"]:last["end"]]
            last["confidence"] = max(last["confidence"], cand["confidence"])
            continue

        if cand["start"] < last["end"]:
            same_type = cand["pii_type"] == last["pii_type"]
            prev_start = last["start"]
            prev_end = last["end"]  # save before potential replacement

            # ── Guard: when types differ, always prefer the longer span.
            #    This prevents e.g. an LLM PERSON match on "Pierre"
            #    (prio 3) from erasing a regex ORG match on
            #    "Boulangerie Pierre Inc." (prio 2).  A longer span
            #    represents a more complete entity boundary; a shorter
            #    overlapping match of a different type is typically a
            #    partial sub-detection or misclassification.
            if not same_type:
                last_len = last["end"] - last["start"]
                cand_len = cand["end"] - cand["start"]
                if last_len >= cand_len:
                    # Existing span is longer — skip the incoming candidate.
                    logger.debug(
                        "Page %d: keeping %s (%r, %d chars) over overlapping %s (%r, %d chars) — longer span wins",
                        page_data.page_number,
                        last["pii_type"].value if hasattr(last["pii_type"], "value") else str(last["pii_type"]),
                        last["text"][:40],
                        last_len,
                        cand["pii_type"].value if hasattr(cand["pii_type"], "value") else str(cand["pii_type"]),
                        cand["text"][:40],
                        cand_len,
                    )
                    continue
                else:
                    # Incoming span is longer — replace the existing one
                    # regardless of priority so the more complete entity wins.
                    logger.debug(
                        "Page %d: replacing %s (%r, %d chars) with longer %s (%r, %d chars)",
                        page_data.page_number,
                        last["pii_type"].value if hasattr(last["pii_type"], "value") else str(last["pii_type"]),
                        last["text"][:40],
                        last_len,
                        cand["pii_type"].value if hasattr(cand["pii_type"], "value") else str(cand["pii_type"]),
                        cand["text"][:40],
                        cand_len,
                    )
                    merged[-1] = cand
                    continue

            if cand["priority"] > last["priority"]:
                merged[-1] = cand
            elif cand["priority"] == last["priority"] and cand["confidence"] > last["confidence"]:
                merged[-1] = cand

            # For same-type overlaps, always take the UNION of spans so that
            # a shorter high-confidence candidate cannot silently drop a
            # legal suffix (e.g. "INC.") that a longer lower-confidence one
            # already captured.
            if same_type and prev_start < merged[-1]["start"]:
                merged[-1]["start"] = prev_start
            if same_type and prev_end > merged[-1]["end"]:
                merged[-1]["end"] = prev_end
            # Also extend if the *incoming* candidate itself is longer.
            if same_type and cand["end"] > merged[-1]["end"]:
                merged[-1]["end"] = cand["end"]

            # L11: Max-span guard — prevent snowball merging from creating
            # unreasonably long regions.  Cap merged span at 500 chars.
            _MAX_MERGE_CHARS = det_cfg.MAX_MERGE_CHARS
            span_len = merged[-1]["end"] - merged[-1]["start"]
            if span_len > _MAX_MERGE_CHARS:
                merged[-1]["end"] = merged[-1]["start"] + _MAX_MERGE_CHARS

            # Recompute text from the (possibly extended) span
            merged[-1]["text"] = page_data.full_text[
                merged[-1]["start"]:merged[-1]["end"]
            ]
        else:
            merged.append(cand)

    # ── Apply pipeline-level noise filters (single combined pass) ────
    for item in merged:
        if item["pii_type"] == PIIType.ORG:
            logger.debug(
                "Page %d: ORG candidate: text=%r source=%s conf=%.2f noise=%s",
                page_data.page_number, item["text"], item["source"],
                item["confidence"], _is_org_pipeline_noise(item["text"]),
            )

    # Pre-compile ISO date pattern for PHONE false-positive rejection.
    _ISO_DATE_RE = re.compile(r'^\d{4}-\d{2}-\d{2}$')

    def _is_candidate_noise(item: dict) -> bool:
        """Combined noise + structured filter (M2: single pass)."""
        ptype = item["pii_type"]
        txt = item["text"]
        stripped = txt.strip()

        # ── Structural minimum-content gates ──────────────────────────
        # These apply regardless of source or visual boost — a detection
        # that doesn't meet basic structural requirements for its type
        # is always noise.

        # EMAIL must contain '@' — anything without it is a GLiNER/NER
        # hallucination (e.g. "160", "GASPÉ", "SADC").
        if ptype == PIIType.EMAIL and '@' not in stripped:
            return True

        # CREDIT_CARD must have at least 13 digits (shortest valid card).
        # Financial figures like "16 522" or text like "TVQ" are FPs.
        if ptype == PIIType.CREDIT_CARD:
            cc_digits = sum(c.isdigit() for c in stripped)
            if cc_digits < det_cfg.STRUCTURED_MIN_DIGITS["CREDIT_CARD"]:
                return True

        # PASSPORT must be at least MIN_PASSPORT_CHARS non-whitespace chars.
        # Fragments like "JR", "D", "11" are never passports.
        if ptype == PIIType.PASSPORT and len(stripped.replace(' ', '')) < det_cfg.MIN_PASSPORT_CHARS:
            return True

        # PHONE: reject ISO dates (YYYY-MM-DD) misdetected as phone
        # numbers.  The pattern "2026-08-03" has 8 digits and can slip
        # past digit-count filters but is structurally a date, not a phone.
        if ptype == PIIType.PHONE and _ISO_DATE_RE.match(stripped):
            return True

        # ORG / PERSON must have at least 3 alphabetic characters.
        # Ultra-short fragments like "de l", "à l", "JR" (2 alpha) are
        # never real entity names, even with visual-boost indicators.
        if ptype in (PIIType.ORG, PIIType.PERSON):
            alpha_count = sum(c.isalpha() for c in stripped)
            if alpha_count < det_cfg.MIN_ENTITY_ALPHA_CHARS:
                return True

        # ── Type-specific noise filters ───────────────────────────────

        # ORG noise — visual boost (bold/italic/centred/quoted) is a
        # strong signal of intentional emphasis, but its strength
        # depends on the phrase's shape.  Short phrases with
        # substantial words are very likely real company names; long
        # phrases of short words are usually document headers.
        #
        # Heuristic:
        #   word_count < 4 AND avg_alpha_per_word > 2
        #       → visual boost always wins (skip noise filter)
        #   otherwise
        #       → still run noise filter; visual boost only adds a
        #         scaled confidence bump (fewer words & longer words
        #         = stronger bump).
        if ptype == PIIType.ORG:
            _skip_noise = False
            if item.get("has_visual_boost"):
                _words_vb = [w for w in txt.split() if any(c.isalpha() for c in w)]
                _wc = len(_words_vb) if _words_vb else 1
                _avg_alpha = (sum(sum(c.isalpha() for c in w) for w in _words_vb) / _wc) if _words_vb else 0

                if _wc < 4 and _avg_alpha > 2:
                    # Short, substantial-word phrase: visual boost wins
                    _skip_noise = True
                    logger.debug(
                        "Page %d: ORG visual boost wins (wc=%d, avg=%.1f): %r",
                        page_data.page_number, _wc, _avg_alpha, txt,
                    )
                else:
                    # Long / short-word phrase: visual boost is weaker.
                    # Scale factor drops with more words and shorter words.
                    _scale = max(0.0, min(1.0, (3.0 / _wc) * (_avg_alpha / 4.0)))
                    _extra = _BOOST_VISUAL * _scale
                    if _extra > 0.01:
                        item["confidence"] = min(1.0, item["confidence"] + _extra)
                    logger.debug(
                        "Page %d: ORG visual boost scaled (wc=%d, avg=%.1f, scale=%.2f): %r",
                        page_data.page_number, _wc, _avg_alpha, _scale, txt,
                    )
            if not _skip_noise and _is_org_pipeline_noise(txt):
                return True
        # LOCATION noise
        if ptype == PIIType.LOCATION and _is_loc_pipeline_noise(txt):
            return True
        # PERSON noise
        if ptype == PIIType.PERSON and _is_person_pipeline_noise(txt):
            return True
        # Context-aware PERSON filter: page-header pattern
        if (
            ptype == PIIType.PERSON
            and item.get("source") in ("NER", "GLINER", "BERT")
            and item.get("start", 99) <= 5
            and len(txt.split()) >= 2
        ):
            return True
        # ADDRESS number-only
        if ptype == PIIType.ADDRESS and _is_address_number_only(txt):
            return True
        # Structured digit-count filter
        min_d = _STRUCTURED_MIN_DIGITS.get(ptype)
        if min_d is not None:
            digits = sum(c.isdigit() for c in txt)
            if digits < min_d:
                return True
            if ptype == PIIType.SSN and any(c in txt for c in '$€£'):
                return True
            if ptype in (PIIType.SSN, PIIType.PHONE) and '\n' in txt:
                return True
            if ptype == PIIType.SSN:
                if re.fullmatch(r'\d{1,2}\s+\d{3}\s+\d{3}', txt.strip()):
                    return True
        return False

    before_filter = len(merged)
    merged = [item for item in merged if not _is_candidate_noise(item)]
    total_dropped = before_filter - len(merged)
    if total_dropped:
        logger.info(
            "Page %d: pipeline noise filter dropped %d candidate(s)",
            page_data.page_number, total_dropped,
        )

    # ── Pre-compute block offsets (used by ADDRESS merge + bbox mapping) ──
    block_offsets = _compute_block_offsets(
        page_data.text_blocks, page_data.full_text,
    )

    # ── Spatial coherence filter ─────────────────────────────────────
    # A regex may match text that is *textually* adjacent in full_text
    # but *spatially* scattered across the page (e.g. text from a
    # header concatenated with body text).  We verify that each
    # candidate's underlying TextBlocks form a vertically contiguous
    # group; if not, the candidate is truncated to the first
    # contiguous run of lines.
    if block_offsets:
        _spatial_trimmed = 0
        for item in merged:
            cand_blocks = [
                (bs, be, blk)
                for bs, be, blk in block_offsets
                if be > item["start"] and bs < item["end"]
            ]
            if len(cand_blocks) < 2:
                continue
            # Sort blocks by visual position (top→bottom, left→right)
            cand_blocks.sort(key=lambda t: (t[2].bbox.y0, t[2].bbox.x0))
            # Cluster into visual lines (by y-center proximity)
            lines: list[list[tuple[int, int, TextBlock]]] = [[cand_blocks[0]]]
            for cb in cand_blocks[1:]:
                prev_line = lines[-1]
                prev_yc = sum(
                    (t[2].bbox.y0 + t[2].bbox.y1) / 2 for t in prev_line
                ) / len(prev_line)
                prev_h = max(t[2].bbox.y1 - t[2].bbox.y0 for t in prev_line)
                cur_yc = (cb[2].bbox.y0 + cb[2].bbox.y1) / 2
                cur_h = cb[2].bbox.y1 - cb[2].bbox.y0
                tol = max(prev_h, cur_h) * 0.5
                if abs(cur_yc - prev_yc) <= tol:
                    prev_line.append(cb)
                else:
                    lines.append([cb])

            if len(lines) <= 1:
                continue
            # Check vertical gaps between consecutive lines
            max_line_h = max(
                max(t[2].bbox.y1 - t[2].bbox.y0 for t in line)
                for line in lines
            )
            # Threshold: if gap between two consecutive lines exceeds
            # N × max line height, treat them as non-contiguous.
            # ADDRESS / LOCATION candidates legitimately span 2-3 lines
            # (street + city/postal) with potentially generous spacing,
            # so we use a looser factor for those.
            _is_addr = item["pii_type"] in {PIIType.ADDRESS, PIIType.LOCATION}
            _is_person = item["pii_type"] == PIIType.PERSON
            # ADDRESS/LOCATION: loose (3.0×), PERSON: moderate (2.0×),
            # everything else: tight (1.5×)
            if _is_addr:
                _SPATIAL_GAP_FACTOR = _MAX_Y_GAP_FACTOR
            elif _is_person:
                _SPATIAL_GAP_FACTOR = det_cfg.SPATIAL_GAP_FACTORS.get(
                    "PERSON", det_cfg.SPATIAL_GAP_FACTOR_DEFAULT)
            else:
                _SPATIAL_GAP_FACTOR = det_cfg.SPATIAL_GAP_FACTOR_DEFAULT
            contiguous_end = len(lines)
            for li in range(1, len(lines)):
                prev_y1 = max(t[2].bbox.y1 for t in lines[li - 1])
                cur_y0 = min(t[2].bbox.y0 for t in lines[li])
                gap = cur_y0 - prev_y1
                if gap > max_line_h * _SPATIAL_GAP_FACTOR:
                    contiguous_end = li
                    break
            if contiguous_end < len(lines):
                # Truncate: only keep blocks from contiguous lines
                kept = [t for line in lines[:contiguous_end] for t in line]
                new_start = min(t[0] for t in kept)
                new_end = max(t[1] for t in kept)
                new_text = page_data.full_text[new_start:new_end]
                if new_text.strip():
                    item["start"] = new_start
                    item["end"] = new_end
                    item["text"] = new_text
                    _spatial_trimmed += 1
        if _spatial_trimmed:
            logger.info(
                "Page %d: spatial coherence trimmed %d candidate(s)",
                page_data.page_number, _spatial_trimmed,
            )

    # ── ORG / PERSON newline splitting ──────────────────────────────
    # Auto-detectors (especially GLiNER) sometimes return spans that
    # start with a valid entity name but bleed into subsequent lines
    # containing descriptive text, e.g.:
    #   "L'ÉQUIPE\nL'ESPRIT DU REPRENEURIAT\n(série documentaire…)"
    # Entity names never legitimately span multiple visual lines.
    # Split at newlines, keeping each line that looks like an entity
    # (starts with an uppercase letter and is at least 2 chars long).
    #
    # EXCEPTION: When an entity spans exactly two lines and BOTH lines
    # look like valid entity fragments, keep the item whole so the
    # downstream linked-group builder creates properly linked per-line
    # regions.  This covers multi-line ORG/PERSON names like
    # "Les entreprises de restauration\nB.N. Ltée".
    _NL_TRIM_TYPES = {PIIType.ORG, PIIType.PERSON}
    _nl_split_replacements: list[tuple[int, list[dict]]] = []
    for idx, item in enumerate(merged):
        if item["pii_type"] not in _NL_TRIM_TYPES:
            continue
        txt = item["text"]
        if "\n" not in txt:
            continue
        # ORG with a legal suffix is a validated company name that
        # legitimately spans multiple lines — don't split it; the
        # linked-group logic downstream will create per-line siblings.
        if item["pii_type"] == PIIType.ORG and has_legal_suffix(txt):
            continue
        lines = txt.split("\n")
        # If the entity spans exactly two lines and both look like valid
        # entity fragments, keep it whole for linked-group creation.
        if len(lines) == 2:
            s0, s1 = lines[0].strip(), lines[1].strip()
            if (len(s0) >= 2 and s0[0].isupper()
                    and len(s1) >= 2 and s1[0].isupper()):
                continue
        # Split into per-line segments
        segments: list[dict] = []
        offset = 0
        for line in lines:
            stripped = line.strip()
            line_start = item["start"] + offset
            line_end = line_start + len(line)
            # Keep lines that look like entity names:
            # - at least 2 chars after stripping
            # - starts with uppercase letter (not parenthesis, digit, etc.)
            if len(stripped) >= 2 and stripped[0].isupper():
                seg = dict(item)  # shallow copy
                seg["text"] = stripped
                seg["start"] = line_start + (len(line) - len(line.lstrip()))
                seg["end"] = seg["start"] + len(stripped)
                segments.append(seg)
            offset += len(line) + 1  # +1 for the \n
        if segments:
            _nl_split_replacements.append((idx, segments))

    if _nl_split_replacements:
        # Rebuild merged list with split segments replacing originals
        new_merged: list[dict] = []
        replaced_indices = {idx for idx, _ in _nl_split_replacements}
        replace_map = {idx: segs for idx, segs in _nl_split_replacements}
        for idx, item in enumerate(merged):
            if idx in replaced_indices:
                new_merged.extend(replace_map[idx])
            else:
                new_merged.append(item)
        merged = new_merged
        logger.info(
            "Page %d: split %d multi-line ORG/PERSON candidate(s) into %d segment(s)",
            page_data.page_number,
            len(_nl_split_replacements),
            sum(len(segs) for _, segs in _nl_split_replacements),
        )

    # ── Merge adjacent ADDRESS fragments ──────────────────────────────
    _addr_merged: list[dict] = []
    for item in merged:
        if _addr_merged:
            prev = _addr_merged[-1]
            prev_is_addr = prev["pii_type"] == PIIType.ADDRESS
            prev_is_loc = prev["pii_type"] == PIIType.LOCATION
            cur_is_addr = item["pii_type"] == PIIType.ADDRESS
            cur_is_loc = item["pii_type"] == PIIType.LOCATION

            can_merge = False
            if prev_is_addr and (cur_is_addr or cur_is_loc):
                can_merge = True
            elif prev_is_loc and cur_is_addr:
                can_merge = True

            if can_merge:
                gap = item["start"] - prev["end"]
                if 0 <= gap <= det_cfg.ADDRESS_MERGE_MAX_GAP:
                    combined_text = page_data.full_text[prev["start"]:item["end"]]
                    newline_count = combined_text.count("\n")
                    if newline_count <= det_cfg.ADDRESS_MERGE_MAX_NEWLINES:
                        # ── spatial proximity guard ──
                        # Compute bboxes for both fragments; skip merge
                        # if they're too far apart vertically.
                        prev_bbs = _char_offsets_to_line_bboxes(
                            prev["start"], prev["end"], block_offsets,
                        ) if block_offsets else []
                        cur_bbs = _char_offsets_to_line_bboxes(
                            item["start"], item["end"], block_offsets,
                        ) if block_offsets else []
                        if prev_bbs and cur_bbs:
                            prev_y1_max = max(b.y1 for b in prev_bbs)
                            cur_y0_min = min(b.y0 for b in cur_bbs)
                            avg_h = sum(b.y1 - b.y0 for b in prev_bbs + cur_bbs) / len(prev_bbs + cur_bbs)
                            y_gap = cur_y0_min - prev_y1_max
                            if y_gap > max(avg_h * _MAX_Y_GAP_FACTOR, _MIN_Y_GAP_ABS):
                                _addr_merged.append(item)
                                continue

                        # ── Column-safe text reconstruction ──
                        # Use the merged spatial bbox to find blocks,
                        # excluding blocks from other columns whose char
                        # offsets are interleaved in full_text.
                        all_bbs = (prev_bbs or []) + (cur_bbs or [])
                        if all_bbs and block_offsets:
                            merged_x0 = min(b.x0 for b in all_bbs)
                            merged_y0 = min(b.y0 for b in all_bbs)
                            merged_x1 = max(b.x1 for b in all_bbs)
                            merged_y1 = max(b.y1 for b in all_bbs)
                            spatial_blocks = [
                                blk for bs, be, blk in block_offsets
                                if (be > prev["start"] and bs < item["end"]
                                    and blk.bbox.x1 >= merged_x0
                                    and blk.bbox.x0 <= merged_x1
                                    and blk.bbox.y1 >= merged_y0
                                    and blk.bbox.y0 <= merged_y1)
                            ]
                            if spatial_blocks:
                                combined_text = _reconstruct_text_from_blocks(
                                    spatial_blocks,
                                )

                        prev["end"] = item["end"]
                        prev["text"] = combined_text
                        prev["pii_type"] = PIIType.ADDRESS
                        prev["confidence"] = max(prev["confidence"], item["confidence"])
                        continue
        _addr_merged.append(item)
    if len(_addr_merged) < len(merged):
        logger.debug(
            "Page %d: merged %d adjacent ADDRESS fragment(s)",
            page_data.page_number, len(merged) - len(_addr_merged),
        )
    merged = _addr_merged

    # ── Strip phone/fax labels from ADDRESS text ─────────────────────
    for item in merged:
        if item["pii_type"] == PIIType.ADDRESS:
            cleaned = _strip_phone_labels_from_address(item["text"])
            if cleaned != item["text"]:
                # Adjust end offset to reflect the trimmed text
                item["text"] = cleaned
                item["end"] = item["start"] + len(cleaned)

    # ── Strip surrounding parentheses from detected text ─────────────
    # Parentheses wrapping a detected region are OCR/layout noise, not
    # part of the entity.  Strip them unless the match came from a
    # user-defined custom pattern (expressions sheet) where the user
    # explicitly included parentheses in their regex.
    _paren_stripped = 0
    _OPEN_PARENS = set('(\uff08\ufe59\u207d\u208d')
    _CLOSE_PARENS = set(')\uff09\ufe5a\u207e\u208e')
    for item in merged:
        if item.get("is_custom_pattern"):
            continue
        txt = item["text"]
        if len(txt) > 2 and txt[0] in _OPEN_PARENS and txt[-1] in _CLOSE_PARENS:
            inner = txt[1:-1]
            lstrip_n = len(inner) - len(inner.lstrip())
            rstrip_n = len(inner) - len(inner.rstrip())
            item["text"] = inner.strip()
            item["start"] += 1 + lstrip_n
            item["end"] -= 1 + rstrip_n
            _paren_stripped += 1
    if _paren_stripped:
        logger.info(
            "Page %d: stripped surrounding parentheses from %d region(s)",
            page_data.page_number, _paren_stripped,
        )

    # ── Convert to PIIRegion with per-line bboxes ─────────────────────

    _max_pt = config.max_font_size_pt

    # For OCR / image pages the bbox coordinates are in *pixels*, not PDF
    # points.  Scale the threshold so the filter still works correctly.
    # Heuristic: any page wider than 1000 units is almost certainly in
    # pixel coordinates (the widest standard PDF page — A3 landscape —
    # is ~1190 pt, but typical pages are 595–842 pt).  When detected,
    # convert the pt threshold to the equivalent pixel height using the
    # ratio of page-pixel-width to an assumed physical width of ≈8.5 in
    # (letter size), which gives a good DPI estimate.
    _is_pixel_coords = page_data.width > 1000
    if _is_pixel_coords and _max_pt > 0:
        _estimated_dpi = page_data.width / 8.5  # works for letter; A4 ≈ 8.27 in — close enough
        _max_pt = _max_pt * _estimated_dpi / 72.0
        logger.debug(
            "Page %d: pixel-coordinate page (w=%.0f) — "
            "font-size threshold scaled to %.1f px (≈%d DPI)",
            page_data.page_number, page_data.width, _max_pt,
            int(_estimated_dpi),
        )

    regions: list[PIIRegion] = []
    _large_font_skipped = 0
    for item in merged:
        if item["confidence"] < config.confidence_threshold:
            continue
        if item["pii_type"] == PIIType.CUSTOM:
            continue

        line_bboxes = _char_offsets_to_line_bboxes(
            item["start"], item["end"], block_offsets,
        )
        if not line_bboxes:
            bbox = _char_offset_to_bbox(item["start"], item["end"], block_offsets)
            if bbox is None:
                continue
            line_bboxes = [bbox]

        if _max_pt > 0:
            line_bboxes = [b for b in line_bboxes if (b.y1 - b.y0) < _max_pt]
            if not line_bboxes:
                _large_font_skipped += 1
                continue

        # ADDRESS street-number heuristic
        if (
            len(line_bboxes) > 1
            and item["pii_type"] in (PIIType.ADDRESS, "ADDRESS")
        ):
            match_text = page_data.full_text[item["start"]:item["end"]]
            first_line = match_text.split("\n")[0].strip()
            if first_line and not re.search(r"[A-Za-zÀ-ÿ]", first_line):
                continue

        max_lines = _max_lines_for_type(item["pii_type"])

        # ── Build per-line char ranges ────────────────────────────────
        match_text = page_data.full_text[item["start"]:item["end"]]
        line_parts = match_text.split("\n")
        if len(line_parts) == len(line_bboxes):
            all_char_ranges: list[tuple[int, int]] = []
            pos = item["start"]
            for part in line_parts:
                all_char_ranges.append((pos, pos + len(part)))
                pos += len(part) + 1
        else:
            # Column-gap splitting may produce more bboxes than text lines.
            # Assign each bbox a char-range from the blocks it covers
            # spatially so that downstream shape enforcement only sees
            # same-column blocks.
            all_char_ranges = []
            for lb in line_bboxes:
                ov_starts: list[int] = []
                ov_ends: list[int] = []
                for bs, be, blk in block_offsets:
                    if be <= item["start"] or bs >= item["end"]:
                        continue
                    bb = blk.bbox
                    # Check spatial overlap with this line bbox
                    if (bb.x1 < lb.x0 or bb.x0 > lb.x1
                            or bb.y1 < lb.y0 or bb.y0 > lb.y1):
                        continue
                    ov_starts.append(max(bs, item["start"]))
                    ov_ends.append(min(be, item["end"]))
                if ov_starts:
                    all_char_ranges.append((min(ov_starts), max(ov_ends)))
                else:
                    all_char_ranges.append((item["start"], item["end"]))

        # ── Split bboxes into spatially contiguous clusters ───────────
        spatial_groups = _split_bboxes_by_proximity(line_bboxes)

        for sg_indices in spatial_groups:
            sg_bboxes = [line_bboxes[i] for i in sg_indices]
            sg_ranges = [all_char_ranges[i] for i in sg_indices]

            # Compute group char range and text from it
            group_cs = min(cs for cs, _ in sg_ranges)
            group_ce = max(ce for _, ce in sg_ranges)
            if len(spatial_groups) > 1 and block_offsets:
                # Column-safe text: reconstruct from blocks that
                # spatially overlap ANY bbox in this group instead
                # of slicing full_text (which interleaves columns).
                sg_x0 = min(b.x0 for b in sg_bboxes)
                sg_y0 = min(b.y0 for b in sg_bboxes)
                sg_x1 = max(b.x1 for b in sg_bboxes)
                sg_y1 = max(b.y1 for b in sg_bboxes)
                sg_blocks = [
                    blk for bs, be, blk in block_offsets
                    if (be > item["start"] and bs < item["end"]
                        and blk.bbox.x1 >= sg_x0 and blk.bbox.x0 <= sg_x1
                        and blk.bbox.y1 >= sg_y0 and blk.bbox.y0 <= sg_y1)
                ]
                if sg_blocks:
                    group_text = _reconstruct_text_from_blocks(sg_blocks)
                else:
                    group_text = page_data.full_text[group_cs:group_ce]
            elif len(spatial_groups) > 1:
                group_text = page_data.full_text[group_cs:group_ce]
            else:
                group_text = item["text"]

            if len(sg_bboxes) == 1:
                cs, ce = sg_ranges[0]
                regions.append(PIIRegion(
                    id=uuid.uuid4().hex[:12],
                    page_number=page_data.page_number,
                    bbox=sg_bboxes[0],
                    text=group_text,
                    pii_type=item["pii_type"],
                    confidence=item["confidence"],
                    source=item["source"],
                    char_start=cs,
                    char_end=ce,
                ))
            elif len(sg_bboxes) <= max_lines:
                group_id = uuid.uuid4().hex[:12]
                for idx, lb in enumerate(sg_bboxes):
                    cs, ce = sg_ranges[idx]
                    regions.append(PIIRegion(
                        id=uuid.uuid4().hex[:12],
                        page_number=page_data.page_number,
                        bbox=lb,
                        text=group_text,
                        pii_type=item["pii_type"],
                        confidence=item["confidence"],
                        source=item["source"],
                        char_start=cs,
                        char_end=ce,
                        linked_group=group_id,
                    ))
            else:
                for i in range(0, len(sg_bboxes), max_lines):
                    chunk_bboxes = sg_bboxes[i:i + max_lines]
                    chunk_ranges = sg_ranges[i:i + max_lines]
                    group_id = uuid.uuid4().hex[:12] if len(chunk_bboxes) > 1 else None
                    for idx, lb in enumerate(chunk_bboxes):
                        cs, ce = chunk_ranges[idx]
                        regions.append(PIIRegion(
                            id=uuid.uuid4().hex[:12],
                            page_number=page_data.page_number,
                            bbox=lb,
                            text=group_text,
                            pii_type=item["pii_type"],
                            confidence=item["confidence"],
                            source=item["source"],
                            char_start=cs,
                            char_end=ce,
                            linked_group=group_id,
                        ))

    if _large_font_skipped:
        logger.info(
            "Page %d: filtered %d large-font candidate(s) (bbox height>=%dpt)",
            page_data.page_number, _large_font_skipped, _max_pt,
        )

    # ── Suppress standalone ORGs inside linked groups ─────────────────
    linked_intervals: list[tuple[int, int]] = []
    for r in regions:
        if r.linked_group is not None:
            linked_intervals.append((r.char_start, r.char_end))
    if linked_intervals:
        kept: list[PIIRegion] = []
        for r in regions:
            if (
                r.linked_group is None
                and r.pii_type == PIIType.ORG
                and any(
                    r.char_start >= gs and r.char_end <= ge
                    for gs, ge in linked_intervals
                )
            ):
                continue
            kept.append(r)
        if len(kept) < len(regions):
            logger.debug(
                "Page %d: suppressed %d standalone ORG(s) inside linked groups",
                page_data.page_number, len(regions) - len(kept),
            )
        regions = kept

    # Enforce region shape constraints
    regions = _enforce_region_shapes(regions, page_data, block_offsets)

    # Resolve remaining bbox overlaps
    regions = _resolve_bbox_overlaps(regions)

    # ── FINAL safety net (uses same combined filter as earlier pass) ──
    _before_final = len(regions)

    # Preserve the visual-boost exception from the first-pass noise filter
    # (S7).  PIIRegion objects don't carry the has_visual_boost flag, so we
    # record the candidate char_start positions here while `merged` is still
    # in scope.  ORG regions whose origin span had a visual boost are exempt
    # from the heuristic noise check (same exception applied in S7).
    # Only protect multi-word ORGs: a single-word boosted ORG (e.g. "Acme" in
    # quotes) still passes through _is_region_noise because its visual
    # evidence is too weak to override the heuristic noise filter.
    _boosted_char_starts: frozenset[int] = frozenset(
        item["start"] for item in merged
        if item.get("has_visual_boost")
        and len(item.get("text", "").split()) >= 2
    )

    def _is_region_noise(r: PIIRegion) -> bool:
        stripped = r.text.strip()

        # ── Structural gates (mirrored from _is_candidate_noise) ─────
        if r.pii_type == PIIType.EMAIL and '@' not in stripped:
            return True
        if r.pii_type == PIIType.CREDIT_CARD:
            if sum(c.isdigit() for c in stripped) < det_cfg.STRUCTURED_MIN_DIGITS["CREDIT_CARD"]:
                return True
        if r.pii_type == PIIType.PASSPORT and len(stripped.replace(' ', '')) < det_cfg.MIN_PASSPORT_CHARS:
            return True
        if r.pii_type == PIIType.PHONE and _ISO_DATE_RE.match(stripped):
            return True
        if r.pii_type in (PIIType.ORG, PIIType.PERSON):
            if sum(c.isalpha() for c in stripped) < det_cfg.MIN_ENTITY_ALPHA_CHARS:
                return True

        # ── Type-specific noise filters ──────────────────────────────
        if r.pii_type == PIIType.ORG and (
            len(stripped) <= 2
            or stripped.isdigit()
            # Heuristic noise check: skip for regions derived from visually-
            # boosted candidates (same exception as S7 _is_candidate_noise).
            or (r.char_start not in _boosted_char_starts
                and _is_org_pipeline_noise(r.text))
        ):
            return True
        if r.pii_type == PIIType.LOCATION and _is_loc_pipeline_noise(r.text):
            return True
        if r.pii_type == PIIType.PERSON and _is_person_pipeline_noise(r.text):
            return True
        if r.pii_type == PIIType.ADDRESS and _is_address_number_only(r.text):
            return True
        _min = _STRUCTURED_MIN_DIGITS.get(r.pii_type)
        if _min is not None:
            digits = sum(c.isdigit() for c in r.text)
            if digits < _min:
                return True
            if r.pii_type == PIIType.SSN and any(c in r.text for c in '$€£'):
                return True
            if r.pii_type in (PIIType.SSN, PIIType.PHONE) and '\n' in r.text:
                return True
        return False

    regions = [r for r in regions if not _is_region_noise(r)]
    _final_dropped = _before_final - len(regions)
    if _final_dropped:
        logger.info(
            "Page %d: FINAL safety net dropped %d noise region(s)",
            page_data.page_number, _final_dropped,
        )

    return regions
