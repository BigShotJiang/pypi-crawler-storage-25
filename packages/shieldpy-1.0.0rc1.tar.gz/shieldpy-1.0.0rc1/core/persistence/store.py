"""Document persistence store."""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
import tempfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from models.schemas import DocumentInfo

logger = logging.getLogger(__name__)

# Validation pattern for doc_id — alphanumeric only (hex from uuid4)
_SAFE_ID_RE = re.compile(r"^[a-zA-Z0-9]+$")


def _validate_doc_id(doc_id: str) -> str:
    """Validate that doc_id is safe for use in filesystem paths.

    Raises ValueError if the doc_id contains path traversal characters
    or other unsafe patterns.
    """
    if not doc_id or not _SAFE_ID_RE.match(doc_id):
        raise ValueError(f"Invalid doc_id: must be alphanumeric, got {doc_id!r}")
    return doc_id


def _sanitize_filename(filename: str) -> str:
    """Sanitize a filename to prevent path traversal and special chars.

    Strips directory components, null bytes, and replaces unsafe characters.
    """
    # Strip directory components
    name = Path(filename).name
    # Remove null bytes
    name = name.replace("\x00", "")
    # Replace path-traversal and unsafe characters
    name = re.sub(r'[<>:"/\\|?*]', '_', name)
    # Ensure the result is not empty
    if not name or name in ('.', '..'):
        name = 'unnamed_document'
    return name


class DocumentStore:
    """Manages persistent storage of documents and their state."""

    def __init__(self, storage_dir: Path):
        """Initialize the document store.
        
        Args:
            storage_dir: Base directory for storing documents
        """
        self.storage_dir = Path(storage_dir)
        self.docs_dir = self.storage_dir / "documents"
        self.files_dir = self.storage_dir / "files"
        self.bitmaps_dir = self.storage_dir / "bitmaps"
        self.region_cache_dir = self.storage_dir / "region_cache"
        
        # Create directories
        self.docs_dir.mkdir(parents=True, exist_ok=True)
        self.files_dir.mkdir(parents=True, exist_ok=True)
        self.bitmaps_dir.mkdir(parents=True, exist_ok=True)
        self.region_cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Settings file for label config etc.
        self._labels_file = self.storage_dir / "pii_labels.json"
        self._patterns_file = self.storage_dir / "custom_patterns.json"
        self._groups_file = self.storage_dir / "groups.json"
        
        logger.info("Document store initialized at %s", self.storage_dir)

    def save_document(self, doc: DocumentInfo) -> None:
        """Save document state to disk (atomic write via tmp + rename).

        Args:
            doc: Document to save
        """
        try:
            _validate_doc_id(doc.doc_id)
            doc_file = self.docs_dir / f"{doc.doc_id}.json"

            # Serialize document to JSON
            doc_data = doc.model_dump(mode="json")
            doc_data["saved_at"] = datetime.now(timezone.utc).isoformat()

            # Atomic write: write to temp file then rename
            fd, tmp_path = tempfile.mkstemp(
                dir=str(self.docs_dir), suffix=".tmp", prefix=f"{doc.doc_id}_"
            )
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(doc_data, f, indent=2, ensure_ascii=False)
                # Atomic rename (on Windows this replaces the target)
                os.replace(tmp_path, str(doc_file))
            except BaseException:
                # Clean up temp file on failure
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise

            logger.info("Saved document %s to %s", doc.doc_id, doc_file)

        except OSError as e:
            logger.error("Failed to save document %s: %s", doc.doc_id, e)
            raise

    def load_document(self, doc_id: str) -> Optional[DocumentInfo]:
        """Load document state from disk.

        Args:
            doc_id: Document ID to load

        Returns:
            Document info or None if not found

        Raises:
            ValueError: If doc_id is invalid or data is corrupted.
        """
        _validate_doc_id(doc_id)
        doc_file = self.docs_dir / f"{doc_id}.json"

        if not doc_file.exists():
            return None

        try:
            with open(doc_file, "r", encoding="utf-8") as f:
                doc_data = json.load(f)

            # Remove saved_at field (not part of DocumentInfo schema)
            doc_data.pop("saved_at", None)

            doc = DocumentInfo.model_validate(doc_data)
            logger.info("Loaded document %s from %s", doc_id, doc_file)
            return doc

        except json.JSONDecodeError as e:
            logger.error("Corrupted JSON for document %s: %s", doc_id, e)
            raise ValueError(f"Corrupted document data for {doc_id}") from e
        except (OSError, ValueError) as e:
            logger.error("Failed to load document %s: %s", doc_id, e)
            raise ValueError(f"Failed to load document {doc_id}: {e}") from e

    def load_document_meta(self, doc_id: str) -> Optional[dict]:
        """Load lightweight metadata for a document without Pydantic validation.

        Returns a plain dict with only the fields needed for document listing,
        avoiding the cost of fully validating regions, pages, and text_blocks.
        Returns None if the document file doesn't exist or is unreadable.
        """
        _validate_doc_id(doc_id)
        doc_file = self.docs_dir / f"{doc_id}.json"
        if not doc_file.exists():
            return None
        try:
            with open(doc_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            regions = data.get("regions", [])
            return {
                "doc_id": data.get("doc_id", doc_id),
                "original_filename": data.get("original_filename", ""),
                "file_path": data.get("file_path", ""),
                "mime_type": data.get("mime_type", ""),
                "page_count": data.get("page_count", 0),
                "status": data.get("status", "EXTRACTED"),
                "regions_count": len(regions),
                "is_protected": (
                    len(regions) > 0
                    and not any(r.get("action") == "PENDING" for r in regions)
                    and any(r.get("action") in ("TOKENIZE", "REMOVE") for r in regions)
                ),
                "cancelled_count": sum(
                    1 for r in regions if r.get("action") == "CANCEL"
                ),
                "excluded_pages": data.get("excluded_pages", []),
                "group_id": data.get("group_id"),
                "group_name": data.get("group_name"),
                "created_at": data.get("created_at"),
            }
        except (json.JSONDecodeError, OSError, KeyError) as e:
            logger.warning("Failed to read metadata for %s: %s", doc_id, e)
            return None

    def list_documents(self) -> list[str]:
        """List all stored document IDs.
        
        Returns:
            List of document IDs
        """
        try:
            doc_files = list(self.docs_dir.glob("*.json"))
            doc_ids = [f.stem for f in doc_files]
            return sorted(doc_ids)
        except OSError as e:
            logger.error("Failed to list documents: %s", e)
            return []

    def delete_document(self, doc_id: str) -> bool:
        """Delete a document and all its associated files.

        Args:
            doc_id: Document ID to delete

        Returns:
            True if deleted successfully
        """
        try:
            _validate_doc_id(doc_id)
            doc_file = self.docs_dir / f"{doc_id}.json"
            
            # Delete document state file
            if doc_file.exists():
                doc_file.unlink()
            
            # Delete associated file (if it exists in our storage)
            file_pattern = f"{doc_id}_*"
            for file in self.files_dir.glob(file_pattern):
                file.unlink()
            
            # Delete associated bitmaps
            bitmap_dir = self.bitmaps_dir / doc_id
            if bitmap_dir.exists():
                shutil.rmtree(bitmap_dir)
            
            logger.info("Deleted document %s", doc_id)
            return True
            
        except (OSError, ValueError) as e:
            logger.error("Failed to delete document %s: %s", doc_id, e)
            return False

    def store_uploaded_file(self, doc_id: str, source_path: Path, original_filename: str) -> Path:
        """Move an uploaded file to persistent storage.

        Args:
            doc_id: Document ID
            source_path: Path to the temporary uploaded file
            original_filename: Original name of the file

        Returns:
            Path to the stored file
        """
        try:
            _validate_doc_id(doc_id)
            safe_name = _sanitize_filename(original_filename)
            stored_path = self.files_dir / f"{doc_id}_{safe_name}"
            
            # Copy file to storage (keep original in temp until processing is done)
            shutil.copy2(source_path, stored_path)
            
            logger.info("Stored file %s as %s", original_filename, stored_path)
            return stored_path
            
        except OSError as e:
            logger.error("Failed to store uploaded file: %s", e)
            raise

    def get_stored_file_path(self, doc_id: str, original_filename: str) -> Optional[Path]:
        """Get the path to a stored file.

        Args:
            doc_id: Document ID
            original_filename: Original name of the file

        Returns:
            Path to stored file or None
        """
        _validate_doc_id(doc_id)
        safe_name = _sanitize_filename(original_filename)
        stored_path = self.files_dir / f"{doc_id}_{safe_name}"
        return stored_path if stored_path.exists() else None

    def ensure_bitmap_dir(self, doc_id: str) -> Path:
        """Ensure bitmap directory exists for a document.

        Args:
            doc_id: Document ID

        Returns:
            Path to bitmap directory
        """
        _validate_doc_id(doc_id)
        bitmap_dir = self.bitmaps_dir / doc_id
        bitmap_dir.mkdir(parents=True, exist_ok=True)
        return bitmap_dir

    def get_bitmap_path(self, doc_id: str, page_number: int) -> Path:
        """Get the path for a page bitmap.
        
        Args:
            doc_id: Document ID
            page_number: Page number (1-based)
            
        Returns:
            Path to bitmap file
        """
        bitmap_dir = self.ensure_bitmap_dir(doc_id)
        return bitmap_dir / f"page_{page_number:04d}.png"

    def store_page_bitmaps(self, doc: DocumentInfo) -> None:
        """Copy page bitmaps from temp to persistent storage and update paths.
        
        Args:
            doc: Document whose page bitmaps to persist
        """
        for page in doc.pages:
            src = Path(page.bitmap_path)
            if not src.exists():
                logger.warning("Bitmap not found: %s", src)
                continue
            dst = self.get_bitmap_path(doc.doc_id, page.page_number)
            if src != dst:
                shutil.copy2(src, dst)
                page.bitmap_path = str(dst)
                logger.debug("Stored bitmap page %s -> %s", page.page_number, dst)

    def load_all_documents(self) -> dict[str, DocumentInfo]:
        """Load all stored documents into memory.
        
        Uses parallel I/O to speed up loading when many documents exist.
        
        Returns:
            Dictionary mapping doc_id to DocumentInfo
        """
        documents = {}
        doc_ids = self.list_documents()

        def _load_one(doc_id: str) -> tuple[str, DocumentInfo | None]:
            try:
                return (doc_id, self.load_document(doc_id))
            except (ValueError, OSError) as e:
                logger.warning("Skipping corrupted document %s: %s", doc_id, e)
                return (doc_id, None)

        with ThreadPoolExecutor(max_workers=min(8, len(doc_ids) or 1)) as pool:
            for doc_id, doc in pool.map(_load_one, doc_ids):
                if doc:
                    documents[doc_id] = doc
        
        logger.info("Loaded %s documents from storage", len(documents))
        return documents

    # ── PII Label config persistence ──

    def load_label_config(self) -> list[dict]:
        """Load PII label config from disk.
        
        Returns:
            List of label entry dicts, or empty list if none saved.
        """
        try:
            if self._labels_file.exists():
                with open(self._labels_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    return data
        except (OSError, json.JSONDecodeError) as e:
            logger.error("Failed to load label config: %s", e)
        return []

    def save_label_config(self, labels: list[dict]) -> None:
        """Save PII label config to disk.
        
        Args:
            labels: List of label entry dicts.
        """
        try:
            with open(self._labels_file, "w", encoding="utf-8") as f:
                json.dump(labels, f, indent=2, ensure_ascii=False)
            logger.debug("Saved %s PII label entries", len(labels))
        except OSError as e:
            logger.error("Failed to save label config: %s", e)

    # ── Custom pattern persistence ──

    def load_custom_patterns(self) -> list[dict]:
        """Load custom regex patterns from disk.
        
        Returns:
            List of pattern dicts, each containing:
            - id: Unique pattern identifier
            - name: Human-readable name
            - pattern: Regex string (or None if using template mode)
            - template: Template definition (or None if using regex mode)
            - pii_type: Target PIIType label
            - enabled: Whether pattern is active
            - case_sensitive: Whether regex should be case-sensitive
            - confidence: Default confidence score (0.0-1.0)
        """
        try:
            if self._patterns_file.exists():
                with open(self._patterns_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    return data
        except (OSError, json.JSONDecodeError) as e:
            logger.error("Failed to load custom patterns: %s", e)
        return []

    def save_custom_patterns(self, patterns: list[dict]) -> None:
        """Save custom regex patterns to disk.
        
        Args:
            patterns: List of pattern dicts.
        """
        try:
            with open(self._patterns_file, "w", encoding="utf-8") as f:
                json.dump(patterns, f, indent=2, ensure_ascii=False)
            logger.debug("Saved %s custom patterns", len(patterns))
        except OSError as e:
            logger.error("Failed to save custom patterns: %s", e)

    # ── Region cache (survives document deletion) ──

    def save_region_cache(self, content_hash: str, regions: list, filename: str) -> None:
        """Cache regions for a content hash so they survive document deletion."""
        if not content_hash or not regions:
            return
        if not _SAFE_ID_RE.match(content_hash):
            logger.warning("Invalid content_hash for region cache: %r", content_hash)
            return
        cache_file = self.region_cache_dir / f"{content_hash}.json"
        try:
            data = {
                "content_hash": content_hash,
                "filename": filename,
                "regions": [r.model_dump(mode="json") if hasattr(r, "model_dump") else r for r in regions],
                "cached_at": datetime.now(timezone.utc).isoformat(),
            }
            with open(cache_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            logger.info("Cached %s regions for hash %s…", len(regions), content_hash[:8])
        except OSError as e:
            logger.error("Failed to save region cache: %s", e)

    def load_region_cache(self, content_hash: str) -> list[dict] | None:
        """Load cached regions for a content hash, or None if not found."""
        if not content_hash or not _SAFE_ID_RE.match(content_hash):
            return None
        cache_file = self.region_cache_dir / f"{content_hash}.json"
        if not cache_file.exists():
            return None
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            regions = data.get("regions", [])
            logger.info("Loaded %s cached regions for hash %s…", len(regions), content_hash[:8])
            return regions
        except (OSError, json.JSONDecodeError) as e:
            logger.error("Failed to load region cache for %s: %s", content_hash, e)
            return None

    # ── Empty groups (folders with no documents yet) ──────────────────────

    def load_groups(self) -> dict[str, str]:
        """Load empty groups from disk. Returns {group_id: group_name}."""
        if not self._groups_file.exists():
            return {}
        try:
            with open(self._groups_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            return {str(k): str(v) for k, v in data.items()}
        except (OSError, json.JSONDecodeError) as e:
            logger.error("Failed to load groups: %s", e)
            return {}

    def save_groups(self, groups: dict[str, str]) -> None:
        """Persist empty groups to disk. Overwrites existing file."""
        try:
            with open(self._groups_file, "w", encoding="utf-8") as f:
                json.dump(groups, f, indent=2, ensure_ascii=False)
        except OSError as e:
            logger.error("Failed to save groups: %s", e)
