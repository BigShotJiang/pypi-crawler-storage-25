"""Office document helper functions for anonymization.

Extracted from engine.py for maintainability (M8: modular architecture).
Contains pure helper functions with no dependencies on engine.py internals.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def strip_docx_tracked_changes(docx_doc) -> None:
    """Permanently remove tracked-change revision data from a DOCX document.

    Microsoft Word stores the *original* text of deletions in ``<w:del>``
    elements and wraps insertions in ``<w:ins>`` elements.  Both are fully
    readable in the raw XML — even content the user believes was "deleted".

    We:
      * Remove every ``<w:del>`` subtree (discarded text disappears entirely).
      * Unwrap every ``<w:ins>`` (keep the inserted run children, drop the
        tracking envelope).
      * Blank out ``w:author`` / ``w:date`` attributes on any surviving
        revision markup (e.g. format-change ``<w:rPrChange>``).
      * Strip ``rsidR`` / ``rsidRPr`` / ``rsidDel`` etc. attributes that leak
        editor session identities.
    """
    W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    body = docx_doc.element

    # 1. Remove <w:del> blocks entirely (deleted-but-preserved text).
    for del_elem in list(body.iter(f"{{{W}}}del")):
        parent = del_elem.getparent()
        if parent is not None:
            parent.remove(del_elem)

    # 2. Unwrap <w:ins> — preserve child runs, strip the tracking wrapper.
    for ins_elem in list(body.iter(f"{{{W}}}ins")):
        parent = ins_elem.getparent()
        if parent is None:
            continue
        idx = list(parent).index(ins_elem)
        for child in list(ins_elem):
            parent.insert(idx, child)
            idx += 1
        parent.remove(ins_elem)

    # 3. Blank out w:author and w:date on any remaining revision elements
    #    (e.g. <w:rPrChange w:author="John Smith" ...>).
    author_attr = f"{{{W}}}author"
    date_attr = f"{{{W}}}date"
    for elem in body.iter():
        if author_attr in elem.attrib:
            elem.attrib[author_attr] = ""
        if date_attr in elem.attrib:
            elem.attrib[date_attr] = ""

    # 4. Strip rsid* attributes (revision save IDs — encode editor session).
    rsid_attrs = {
        f"{{{W}}}rsidR", f"{{{W}}}rsidRPr", f"{{{W}}}rsidDel",
        f"{{{W}}}rsidDefault", f"{{{W}}}rsidSect", f"{{{W}}}rsidTr",
        f"{{{W}}}rsidRDel",
    }
    for elem in body.iter():
        for attr in list(rsid_attrs):
            elem.attrib.pop(attr, None)

    logger.debug("Stripped DOCX tracked changes and revision attributes")


def strip_docx_comment_annotations(docx_doc) -> None:
    """Remove all inline review-comment annotations from a DOCX document.

    Comments in Word can contain PII discussed by reviewers (names, addresses,
    personal notes).  We remove the comment reference markers from the body
    *and* clear the comments.xml part so nothing leaks from either location.
    """
    W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    COMMENTS_REL = (
        "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"
    )

    body = docx_doc.element

    # Remove comment reference elements from the document body
    for tag in ("commentRangeStart", "commentRangeEnd", "commentReference"):
        for elem in list(body.iter(f"{{{W}}}{tag}")):
            parent = elem.getparent()
            if parent is not None:
                parent.remove(elem)

    # Clear the comments.xml part (wipe all <w:comment> children)
    try:
        comments_part = docx_doc.part.part_related_by(COMMENTS_REL)
        root = comments_part._element
        for child in list(root):
            root.remove(child)
        logger.debug("Cleared DOCX comments.xml")
    except Exception:
        pass  # Document has no comments part — nothing to do


def strip_docx_app_properties(docx_doc) -> None:
    """Clear the docProps/app.xml extended properties that may expose author identity.

    Fields like Company, Manager, Template, HyperlinkBase can contain the
    original author's employer or personal file-system paths.  We parse the
    raw blob, blank the sensitive fields, and write it back.
    """
    APP_REL = (
        "http://schemas.openxmlformats.org/officeDocument/2006/"
        "relationships/extended-properties"
    )
    APP_NS = "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"

    try:
        from lxml import etree as _etree

        app_part = docx_doc.part.package.part_related_by(APP_REL)
        root = _etree.fromstring(app_part.blob)
        for tag in ("Company", "Manager", "HyperlinkBase", "Template"):
            elem = root.find(f"{{{APP_NS}}}{tag}")
            if elem is not None:
                elem.text = ""
        # Write the modified XML back into the part blob
        app_part._blob = _etree.tostring(
            root,
            xml_declaration=True,
            encoding="UTF-8",
            standalone=True,
        )
        logger.debug("Cleared DOCX app.xml extended properties")
    except Exception:
        pass  # present in most DOCX but not mandatory


def strip_xlsx_defined_names(wb) -> None:
    """Remove workbook-level defined names (named ranges) that may contain PII.

    Excel's Name Manager can store named formulas or constants with PII
    strings.  We delete all defined names that are not standard Excel
    built-ins (which start with ``_xlnm.``).
    """
    try:
        # defined_names is a dict subclass; iterate over a snapshot of keys
        names_to_remove = [
            name for name in list(wb.defined_names.keys())
            if not name.startswith("_xlnm.")
        ]
        for name in names_to_remove:
            del wb.defined_names[name]
        if names_to_remove:
            logger.debug("Removed %s XLSX defined names", len(names_to_remove))
    except Exception:
        logger.debug("Could not remove XLSX defined names")


def replace_in_paragraphs(paragraphs, replacements: dict[str, str]) -> None:
    """Replace text in DOCX paragraphs while preserving per-run formatting.

    For each paragraph:
    1. Join all run texts into a single string and build a character→run map.
    2. Apply replacements on the joined text, tracking where each
       replacement lands.
    3. Redistribute the result back into the original runs so only the
       runs that overlap a replacement are touched — all other runs keep
       their formatting and text verbatim.

    This handles PII that is split across multiple XML runs
    (e.g., "Joh" | "n S" | "mith") while preserving styles everywhere else.
    """
    for paragraph in paragraphs:
        runs = paragraph.runs
        if not runs:
            continue
        # Build original text and a list of (start, end) offsets per run
        run_texts = [r.text or "" for r in runs]
        full = "".join(run_texts)
        if not full:
            continue

        # Apply all replacements on the joined text
        replaced = full
        for original, replacement in replacements.items():
            replaced = replaced.replace(original, replacement)
        if replaced == full:
            continue

        # Build character→run_index mapping for the ORIGINAL text.
        # We process replacements one at a time, adjusting offsets.
        # The strategy: find each replacement span in `full`, note which
        # runs it overlaps, push the replacement into the first overlapping
        # run and trim text from the others.
        #
        # We work on a mutable list of run-text strings so we can do
        # multiple passes (one per replacement) without losing track.
        new_run_texts = list(run_texts)

        for original, replacement in replacements.items():
            # Repeatedly replace all occurrences in the joined run texts
            while True:
                # Re-join current state
                joined = "".join(new_run_texts)
                idx = joined.find(original)
                if idx == -1:
                    break
                end = idx + len(original)

                # Determine which runs are affected
                cursor = 0
                for ri, rt in enumerate(new_run_texts):
                    run_start = cursor
                    run_end = cursor + len(rt)

                    if run_end <= idx:
                        # Entirely before the match
                        cursor = run_end
                        continue
                    if run_start >= end:
                        # Entirely after the match — done
                        break

                    # This run overlaps the match
                    local_start = max(idx - run_start, 0)
                    local_end = min(end - run_start, len(rt))

                    if run_start <= idx < run_end:
                        # First overlapping run — insert replacement here
                        new_run_texts[ri] = rt[:local_start] + replacement + rt[local_end:]
                    else:
                        # Subsequent overlapping runs — just remove the matched portion
                        new_run_texts[ri] = rt[:local_start] + rt[local_end:]

                    cursor = run_end

        # Write back to the actual run objects
        for ri, run in enumerate(runs):
            run.text = new_run_texts[ri]


def replace_in_docx_xml_parts(docx_doc, replacements: dict[str, str]) -> None:
    """Replace PII in DOCX XML parts that python-docx doesn't expose natively.

    Covers footnotes, endnotes, and any custom XML parts that might
    contain PII text.  Works by directly manipulating the underlying
    XML of each relevant part in the OPC package.
    """
    from lxml import etree

    W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"

    # Part URIs that may contain user text with PII
    text_part_uris = [
        "/word/footnotes.xml",
        "/word/endnotes.xml",
        "/word/comments.xml",     # also nuke comments
    ]

    for part_uri in text_part_uris:
        try:
            part = docx_doc.part.package.part_related_by(part_uri)
        except Exception:
            # Part may not exist in this document
            try:
                # Fallback: iterate all parts and match by partname
                part = None
                for p in docx_doc.part.package.iter_parts():
                    if str(p.partname) == part_uri:
                        part = p
                        break
                if part is None:
                    continue
            except Exception:
                continue

        try:
            xml_bytes = part.blob
            root = etree.fromstring(xml_bytes)

            # Replace text in all <w:t> elements
            changed = False
            for t_elem in root.iter(f"{{{W_NS}}}t"):
                if t_elem.text:
                    new_text = t_elem.text
                    for original, replacement in replacements.items():
                        new_text = new_text.replace(original, replacement)
                    if new_text != t_elem.text:
                        t_elem.text = new_text
                        changed = True

            if changed:
                part._blob = etree.tostring(root, xml_declaration=True,
                                             encoding="UTF-8", standalone=True)
                logger.debug("Replaced PII in DOCX part: %s", part_uri)
        except Exception:
            logger.debug("Could not process DOCX part: %s", part_uri)
