"""PDF anonymization handler.

Extracted from ``engine.py`` to keep the main module under ~700 LOC.
Shared utilities (``_resolve_or_create_token``, ``_finalize_anonymization``,
etc.) remain in ``engine.py``; this module pulls them via **deferred
imports** inside function bodies to break the circular dependency.

``GroupTokenCache`` is duplicated as a type alias here (not imported) to
avoid importing engine.py at module level.
"""

from __future__ import annotations

import io
import logging
from datetime import datetime
from pathlib import Path

import fitz  # PyMuPDF
from PIL import Image, ImageDraw, ImageFont

from core.config import config
from core.vault.store import vault
from models.schemas import (
    AnonymizeResponse,
    DocumentInfo,
    PIIRegion,
    PIIType,
    RegionAction,
    TokenMapping,
)

logger = logging.getLogger(__name__)

# Deferred import type alias to avoid circular imports with engine.py
GroupTokenCache = dict[tuple[str, str], str]


# ---------------------------------------------------------------------------
# Text fitting — ensure replacement tokens don't overflow their bbox
# ---------------------------------------------------------------------------

def _load_font(target_size: int) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    """Load a TrueType font at *target_size*, with fallbacks."""
    try:
        return ImageFont.truetype("arial.ttf", target_size)
    except (OSError, IOError):
        try:
            return ImageFont.truetype("DejaVuSans.ttf", target_size)
        except (OSError, IOError):
            return ImageFont.load_default()


def _fit_pil_text(
    text: str,
    max_width: float,
    max_height: float,
    draw: ImageDraw.ImageDraw,
) -> tuple[ImageFont.FreeTypeFont | ImageFont.ImageFont, str]:
    """Return (font, fitted_text) that fits within *max_width* × *max_height*.

    Strategy:
    1. Start with font sized to 70% of region height (matches original logic).
    2. Shrink font in 1-pt steps until text width ≤ max_width (min 6 pt).
    3. If still too wide, truncate text and append ``]`` so the token stays
       recognisably bracketed.
    """
    padding = 4  # 2 px left + 2 px right
    avail_w = max(1, max_width - padding)

    target_size = max(6, int(max_height * 0.7))
    font = _load_font(target_size)

    # Shrink font until it fits
    while target_size > 6:
        bbox = draw.textbbox((0, 0), text, font=font)
        tw = bbox[2] - bbox[0]
        if tw <= avail_w:
            return font, text
        target_size -= 1
        font = _load_font(target_size)

    # Font is at minimum — truncate text if still too wide
    fitted = text
    while len(fitted) > 3:
        bbox = draw.textbbox((0, 0), fitted[:-1] + "]", font=font)
        tw = bbox[2] - bbox[0]
        if tw <= avail_w:
            fitted = fitted[:-1] + "]"
            break
        fitted = fitted[:-1]
    else:
        # Extreme edge case: even 3 chars don't fit — just use what we have
        pass

    return font, fitted


def _redact_scanned_page(page: fitz.Page, replacements: list[tuple["PIIRegion", str]]) -> None:
    """Redact a scanned PDF page by manipulating the page image directly.
    
    For scanned PDFs, text exists only in embedded images, so standard PDF
    redactions don't work. Instead, we:
    1. Render the page to a pixmap
    2. Draw white rectangles + replacement text via PIL
    3. Replace the page content with the modified image
    """
    import io
    
    # Render page at 2x for quality
    mat = fitz.Matrix(2, 2)
    pix = page.get_pixmap(matrix=mat, alpha=False)
    
    # Convert to PIL for drawing
    img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
    draw = ImageDraw.Draw(img)
    
    scale = 2.0
    
    for region, replacement_text in replacements:
        bbox = region.bbox
        x0, y0 = bbox.x0 * scale, bbox.y0 * scale
        x1, y1 = bbox.x1 * scale, bbox.y1 * scale
        
        # Draw white rectangle over PII
        draw.rectangle([x0, y0, x1, y1], fill=(255, 255, 255))
        
        # Draw replacement text — fit within the bbox
        region_w = x1 - x0
        region_h = y1 - y0
        font, fitted_text = _fit_pil_text(
            replacement_text, region_w, region_h, draw,
        )
        draw.text(
            (x0 + 2, y0 + (region_h - font.size) / 2 if hasattr(font, 'size') else y0 + 2),
            fitted_text,
            fill=(0, 0, 0),
            font=font,
        )
    
    # Save to PNG in memory, then insert into page
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    img.close()
    png_bytes = buf.getvalue()
    buf.close()
    
    # Clear existing page content and insert the modified image
    page.clean_contents()
    # Remove all existing images/drawings from the page
    xref_list = page.get_images(full=True)
    for img_info in xref_list:
        xref = img_info[0]
        try:
            page.delete_image(xref)
        except Exception:
            pass
    
    page_rect = page.rect
    page.insert_image(page_rect, stream=png_bytes)


# ---------------------------------------------------------------------------
# Deep metadata / revision-data scrubbers
# ---------------------------------------------------------------------------

def _strip_pdf_deep_metadata(pdf_doc: "fitz.Document") -> None:
    """Remove PDF page thumbnails and AcroForm field values.

    Page thumbnails are small images stored in each page's /Thumb entry.
    They are generated BEFORE redaction by many PDF viewers, so they can
    expose the un-redacted content to any tool that reads them (e.g. macOS
    Preview, Acrobat, exiftool).  We remove them unconditionally.

    AcroForm fields (interactive forms) may contain pre-filled default values
    with PII (names, addresses, SSNs).  We clear every field value.
    """
    # 1. Remove /Thumb from every page dictionary
    try:
        for page in pdf_doc:
            xref = page.xref
            if "Thumb" in pdf_doc.xref_get_keys(xref):
                pdf_doc.xref_set_key(xref, "Thumb", "null")
                logger.debug("Removed page thumbnail from page %s", page.number + 1)
    except Exception:
        logger.debug("Could not remove PDF page thumbnails")

    # 2. Clear AcroForm widget (form-field) values
    try:
        for page in pdf_doc:
            for widget in page.widgets():
                if widget.field_value:
                    widget.field_value = ""
                    widget.update()
    except Exception:
        logger.debug("Could not clear PDF AcroForm field values")

    # 3. Remove PDF-level JavaScript (Names/JavaScript tree)
    #    JS is rarely PII but may contain hard-coded values like employee IDs.
    try:
        catalog = pdf_doc.pdf_catalog()
        names_obj = pdf_doc.xref_get_key(catalog, "Names")
        if names_obj and names_obj[0] not in ("null", "none", ""):
            # Clear JavaScript sub-tree if it resolves to a dict
            names_xref_str = names_obj[1]
            if names_xref_str.endswith(" R"):
                names_xref = int(names_xref_str.split()[0])
                js_entry = pdf_doc.xref_get_key(names_xref, "JavaScript")
                if js_entry and js_entry[0] not in ("null", "none", ""):
                    pdf_doc.xref_set_key(names_xref, "JavaScript", "null")
                    logger.debug("Removed PDF JavaScript names tree")
    except Exception:
        logger.debug("Could not inspect/remove PDF JavaScript")






def _anonymize_pdf_sync(doc: DocumentInfo, original_path: Path, group_token_cache: GroupTokenCache | None = None) -> AnonymizeResponse:
    """Anonymize a PDF file using text-based redactions or image manipulation for scanned pages."""
    from core.anonymizer.engine import (
        _resolve_or_create_token, _resolve_overlapping_bboxes,
        _finalize_anonymization, _convert_to_pdf,
        _extract_span_style,
    )
    tokens_created = 0
    regions_removed = 0
    token_manifest: list[dict] = []

    # Open PDF with PyMuPDF
    pdf_doc = fitz.open(str(original_path))

    try:
        # Check if pages are OCR-based (scanned) by looking at text blocks
        def _page_is_ocr(page_num: int) -> bool:
            """Return True if this page's text came from OCR (scanned page)."""
            if page_num >= len(doc.pages):
                return False
            page_data = doc.pages[page_num]
            if not page_data.text_blocks:
                return False
            # If ALL text blocks are OCR, treat as scanned page
            return all(tb.is_ocr for tb in page_data.text_blocks)

        # Erase-then-insert approach for text-based PDFs:
        #   1. Extract original style (font, size, color, baseline origin)
        #   2. Add erase-only redaction over the ORIGINAL rect only
        #   3. apply_redactions() paints white over original text
        #   4. page.insert_text() at original baseline

        for page_num in range(len(pdf_doc)):
            page = pdf_doc[page_num]
            page_regions = [r for r in doc.regions if r.page_number == page_num + 1]
            
            if not page_regions:
                continue

            # Resolve overlapping bboxes so tokens never visually overlap
            page_regions = _resolve_overlapping_bboxes(page_regions)

            # Cache: linked_group → token_string (siblings share one token)
            _group_tokens: dict[str, str] = {}
            
            # Build replacement data for all regions on this page
            replacements: list[tuple[PIIRegion, str]] = []  # (region, replacement_text)
            
            for region in page_regions:
                if region.action == RegionAction.REMOVE:
                    replacement_text = "---"
                    regions_removed += 1
                elif region.action == RegionAction.TOKENIZE:
                    token_string = _resolve_or_create_token(
                        region, doc,
                        doc.pages[page_num].full_text,
                        group_token_cache,
                        _group_tokens,
                        token_manifest,
                        page_number=page_num + 1,
                    )
                    replacement_text = token_string
                    tokens_created += 1
                else:
                    continue
                    
                replacements.append((region, replacement_text))
            
            if not replacements:
                continue
            
            # Check if this is a scanned (OCR) page
            is_ocr_page = _page_is_ocr(page_num)
            
            if is_ocr_page:
                # For scanned pages: render to image, draw redactions, replace page
                _redact_scanned_page(page, replacements)
            else:
                # For text-based pages: use standard PDF redaction
                deferred: list[tuple[str, dict, fitz.Rect]] = []
                
                for region, replacement_text in replacements:
                    bbox = region.bbox
                    rect = fitz.Rect(bbox.x0, bbox.y0, bbox.x1, bbox.y1)
                    style = _extract_span_style(page, rect)
                    page.add_redact_annot(rect, fill=(1, 1, 1))
                    deferred.append((replacement_text, style, rect))
                
                page.apply_redactions()
                
                for text, style, rect in deferred:
                    origin = style["origin"]
                    fontsize = style["fontsize"]
                    # Shrink font until text fits within bbox width
                    fitted_text = text
                    avail_w = rect.width - 2  # small padding
                    if avail_w > 0:
                        while fontsize > 4:
                            tw = fitz.get_text_length(fitted_text, fontname=style["fontname"], fontsize=fontsize)
                            if tw <= avail_w:
                                break
                            fontsize -= 0.5
                        # If still too wide after shrinking, truncate
                        tw = fitz.get_text_length(fitted_text, fontname=style["fontname"], fontsize=fontsize)
                        if tw > avail_w:
                            while len(fitted_text) > 3 and fitz.get_text_length(fitted_text + "]", fontname=style["fontname"], fontsize=fontsize) > avail_w:
                                fitted_text = fitted_text[:-1]
                            fitted_text = fitted_text + "]"
                    page.insert_text(
                        fitz.Point(origin[0], origin[1]),
                        fitted_text,
                        fontname=style["fontname"],
                        fontsize=fontsize,
                        color=style["text_color"],
                    )

        # ── Metadata scrubbing ─────────────────────────────────────────
        # 1. Clear standard document metadata (Author, Title, Subject, …)
        pdf_doc.set_metadata({})

        # 2. Strip XMP (XML-based) metadata
        pdf_doc.del_xml_metadata()

        # 3. Remove table-of-contents / bookmarks (may contain PII names)
        pdf_doc.set_toc([])

        # 4. Remove all remaining annotations (comments, highlights,
        #    sticky notes, etc.) — redaction annotations were already
        #    consumed by apply_redactions(), but other kinds may survive.
        for pg_idx in range(len(pdf_doc)):
            pg = pdf_doc[pg_idx]
            annot_list = list(pg.annots()) if pg.annots() else []
            for annot in annot_list:
                pg.delete_annot(annot)

        # 5. Remove embedded file attachments (portfolio / attached docs)
        try:
            if pdf_doc.embfile_count() > 0:
                names = [pdf_doc.embfile_info(i)["name"]
                         for i in range(pdf_doc.embfile_count())]
                for name in names:
                    pdf_doc.embfile_del(name)
        except Exception:
            logger.debug("Could not enumerate/remove embedded files")

        # 6. Deep scrub: page thumbnails, AcroForm field values, JavaScript
        _strip_pdf_deep_metadata(pdf_doc)

        logger.info("Scrubbed PDF metadata, annotations, TOC, attachments, thumbnails, and form fields")

        # Delete excluded pages (reverse order to preserve indices)
        if doc.excluded_pages:
            for pg in sorted(doc.excluded_pages, reverse=True):
                zero_idx = pg - 1  # excluded_pages is 1-indexed
                if 0 <= zero_idx < len(pdf_doc):
                    pdf_doc.delete_page(zero_idx)
            logger.info("Deleted %s excluded page(s)", len(doc.excluded_pages))

        # Save anonymized PDF
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = Path(doc.original_filename).stem
        output_dir = config.temp_dir / doc.doc_id / "output"
        output_dir.mkdir(parents=True, exist_ok=True)

        pdf_path = output_dir / f"{stem}_anonymized_{timestamp}.pdf"
        # Don't use deflate=True or clean=True - they recompress all image 
        # streams which is extremely slow for scanned (image-heavy) PDFs
        pdf_doc.save(str(pdf_path), garbage=4)
        logger.info("Saved anonymized PDF: %s", pdf_path)

        return _finalize_anonymization(
            doc, pdf_path, tokens_created, regions_removed, token_manifest,
        )

    finally:
        pdf_doc.close()





