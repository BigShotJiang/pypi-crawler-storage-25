"""Office, text, and image anonymization handlers (DOCX, XLSX, XLS, TXT, Image).

Extracted from ``engine.py`` to keep the main module under ~700 LOC.
Shared utilities and ``config`` / ``vault`` are pulled from ``engine.py``
via **deferred imports** inside each handler function.  This is intentional:
test code patches ``core.anonymizer.engine.config`` / ``.vault``, so the
format handlers must resolve those names through ``engine`` — not import
them directly — for mocks to take effect.

``GroupTokenCache`` is duplicated as a type alias (not imported from
``engine``) to avoid circular-import errors at module level.
"""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageDraw

from models.schemas import (
    AnonymizeResponse,
    DocumentInfo,
    PIIRegion,
    RegionAction,
)

logger = logging.getLogger(__name__)

# Deferred import type alias to avoid circular imports with engine.py
GroupTokenCache = dict[tuple[str, str], str]

from core.anonymizer.anonymizer_helpers import (
    strip_docx_tracked_changes as _strip_docx_tracked_changes,
    strip_docx_comment_annotations as _strip_docx_comment_annotations,
    strip_docx_app_properties as _strip_docx_app_properties,
    strip_xlsx_defined_names as _strip_xlsx_defined_names,
    replace_in_paragraphs as _replace_in_paragraphs,
    replace_in_docx_xml_parts as _replace_in_docx_xml_parts,
)


import re
import unicodedata


def _normalize_for_match(text: str) -> str:
    """Normalize text for fuzzy matching: NFKC unicode, collapse whitespace, lowercase."""
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text.lower()


def _collect_docx_text(docx_doc) -> str:
    """Join all paragraph text from a python-docx Document (including tables)."""
    parts: list[str] = []
    for p in docx_doc.paragraphs:
        parts.append("".join(r.text or "" for r in p.runs))
    for table in docx_doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    parts.append("".join(r.text or "" for r in p.runs))
    for section in docx_doc.sections:
        for hf in (section.header, section.footer,
                    section.first_page_header, section.first_page_footer,
                    section.even_page_header, section.even_page_footer):
            if hf is None:
                continue
            for p in hf.paragraphs:
                parts.append("".join(r.text or "" for r in p.runs))
    return "\n".join(parts)


def _reconcile_replacements(replacements: dict[str, str], docx_text: str) -> dict[str, str]:
    """Reconcile PDF-derived region text with actual DOCX text.

    For each replacement key that doesn't appear in the DOCX text, try
    normalized matching (unicode NFKC + collapse whitespace + case-fold)
    to find the actual text that should be replaced.

    Returns a new replacements dict with corrected keys.
    """
    reconciled: dict[str, str] = {}

    for search_text, replacement in replacements.items():
        if search_text in docx_text:
            # Exact match — use as-is
            reconciled[search_text] = replacement
            continue

        # Try normalized matching against the DOCX text
        norm_search = _normalize_for_match(search_text)
        if not norm_search:
            logger.warning("Empty region text, skipping replacement")
            continue

        # Build a regex from the normalized search text that tolerates
        # whitespace differences and unicode normalization
        # Escape regex chars, then replace spaces with flexible whitespace
        escaped = re.escape(norm_search)
        pattern = re.sub(r"\\ ", r"\\s+", escaped)

        norm_docx = unicodedata.normalize("NFKC", docx_text)
        match = re.search(pattern, norm_docx, re.IGNORECASE)
        if match:
            # Found the text in DOCX with different formatting — use the
            # actual DOCX text as the search key
            actual_text = docx_text[match.start():match.end()]
            reconciled[actual_text] = replacement
            logger.info(
                "Region text reconciled: PDF-extracted %r → DOCX actual %r",
                search_text, actual_text,
            )
        else:
            # No match at all — still include it (str.replace will just be a no-op)
            # but log an error so this is visible
            reconciled[search_text] = replacement
            logger.error(
                "PROTECTION FAILURE: Region text %r not found in DOCX content. "
                "This region will NOT be anonymized in the exported file.",
                search_text,
            )

    return reconciled


def _anonymize_docx_sync(doc: DocumentInfo, original_path: Path, group_token_cache: GroupTokenCache | None = None) -> AnonymizeResponse:
    """Anonymize a DOCX file using text replacements."""
    from docx import Document
    from core.anonymizer.engine import (
        config, _resolve_or_create_token, _convert_to_pdf, _finalize_anonymization,
    )

    tokens_created = 0
    regions_removed = 0
    token_manifest: list[dict] = []

    # Open DOCX
    docx = Document(str(original_path))

    try:
        # Sort regions by char_end descending to preserve offsets during replacement
        sorted_regions = sorted(
            [r for r in doc.regions if r.action in (RegionAction.REMOVE, RegionAction.TOKENIZE)],
            key=lambda r: r.char_end,
            reverse=True,
        )

        # Build full text to find replacements
        full_text = "\n".join(p.full_text for p in doc.pages) if doc.pages else ""

        # Track replacements
        replacements: dict[str, str] = {}

        # Cache: linked_group → token_string (siblings share one token)
        _group_tokens: dict[str, str] = {}

        for region in sorted_regions:
            # Use original_text (pre-edit text) for matching in the document;
            # fall back to text if the user never edited the region.
            search_text = region.original_text or region.text

            if region.action == RegionAction.REMOVE:
                replacement = "---"
                replacements[search_text] = replacement
                regions_removed += 1

            elif region.action == RegionAction.TOKENIZE:
                token_string = _resolve_or_create_token(
                    region, doc, full_text,
                    group_token_cache, _group_tokens,
                    token_manifest,
                )
                replacements[search_text] = token_string
                tokens_created += 1

        # Apply replacements to all text in document
        # Reconcile PDF-derived region text with actual DOCX run text.
        # During ingestion, DOCX is converted to PDF and text is extracted
        # from that rendered PDF — this text can differ from the actual DOCX
        # XML run text (whitespace, unicode normalization, encoding).
        docx_text = _collect_docx_text(docx)
        replacements = _reconcile_replacements(replacements, docx_text)

        _replace_in_paragraphs(docx.paragraphs, replacements)

        # Apply to tables
        for table in docx.tables:
            for row in table.rows:
                for cell in row.cells:
                    _replace_in_paragraphs(cell.paragraphs, replacements)

        # Apply to headers and footers (PII often appears here)
        for section in docx.sections:
            for hf in (section.header, section.footer,
                        section.first_page_header, section.first_page_footer,
                        section.even_page_header, section.even_page_footer):
                if hf is None:
                    continue
                _replace_in_paragraphs(hf.paragraphs, replacements)
                for tbl in hf.tables:
                    for row in tbl.rows:
                        for cell in row.cells:
                            _replace_in_paragraphs(cell.paragraphs, replacements)

        # Apply to footnotes and endnotes via underlying XML
        _replace_in_docx_xml_parts(docx, replacements)

        # ── Post-replacement validation ────────────────────────────────
        # Verify that all PII text was actually replaced. If any search
        # text still appears in the document, log an error.
        post_text = _collect_docx_text(docx)
        for search_text in replacements:
            if search_text in post_text:
                logger.error(
                    "PROTECTION FAILURE: Text %r still present in DOCX after "
                    "anonymization — PII may leak in the exported file.",
                    search_text,
                )

        # ── Metadata scrubbing ─────────────────────────────────────────
        props = docx.core_properties
        props.author = ""
        props.last_modified_by = ""
        props.title = ""
        props.subject = ""
        props.keywords = ""
        props.comments = ""
        props.category = ""

        # Deep scrub: tracked changes (<w:del> / <w:ins>), inline comment
        # annotations, and app.xml extended properties (Company, Manager, etc.)
        _strip_docx_tracked_changes(docx)
        _strip_docx_comment_annotations(docx)
        _strip_docx_app_properties(docx)

        logger.info("Scrubbed DOCX metadata, tracked changes, comments, headers, footers, and footnotes")

        # Save anonymized DOCX
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = Path(doc.original_filename).stem
        output_dir = config.temp_dir / doc.doc_id / "output"
        output_dir.mkdir(parents=True, exist_ok=True)

        docx_path = output_dir / f"{stem}_anonymized_{timestamp}.docx"
        docx.save(str(docx_path))
        logger.info("Saved anonymized DOCX: %s", docx_path)

        # Convert anonymized DOCX → PDF for uniform AI-friendly export
        pdf_path = _convert_to_pdf(docx_path, output_dir)

        return _finalize_anonymization(
            doc, pdf_path, tokens_created, regions_removed, token_manifest,
        )

    finally:
        # python-docx doesn't have a close() but we ensure no dangling refs
        del docx


def _anonymize_xlsx_sync(doc: DocumentInfo, original_path: Path, group_token_cache: GroupTokenCache | None = None) -> AnonymizeResponse:
    """Anonymize an XLSX file using text replacements in cells."""
    from openpyxl import load_workbook
    from core.anonymizer.engine import (
        config, _resolve_or_create_token, _convert_to_pdf, _finalize_anonymization,
    )

    tokens_created = 0
    regions_removed = 0
    token_manifest: list[dict] = []

    # Open XLSX
    wb = load_workbook(str(original_path))

    try:
        # Build full text to match regions
        full_text = "\n".join(p.full_text for p in doc.pages) if doc.pages else ""

        # Sort regions by char_end descending
        sorted_regions = sorted(
            [r for r in doc.regions if r.action in (RegionAction.REMOVE, RegionAction.TOKENIZE)],
            key=lambda r: r.char_end,
            reverse=True,
        )

        # Track replacements
        replacements: dict[str, str] = {}

        # Cache: linked_group → token_string (siblings share one token)
        _group_tokens: dict[str, str] = {}

        for region in sorted_regions:
            # Use original_text (pre-edit text) for matching in the document
            search_text = region.original_text or region.text

            if region.action == RegionAction.REMOVE:
                replacement = "---"
                replacements[search_text] = replacement
                regions_removed += 1

            elif region.action == RegionAction.TOKENIZE:
                token_string = _resolve_or_create_token(
                    region, doc, full_text,
                    group_token_cache, _group_tokens,
                    token_manifest,
                )
                replacements[search_text] = token_string
                tokens_created += 1

        # Reconcile PDF-derived region text with actual XLSX cell text.
        # XLSX ingestion converts to PDF first, so text can differ.
        xlsx_text_parts: list[str] = []
        for sheet in wb.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    if isinstance(cell.value, str) and cell.value:
                        xlsx_text_parts.append(cell.value)
        xlsx_full_text = "\n".join(xlsx_text_parts)
        replacements = _reconcile_replacements(replacements, xlsx_full_text)

        # Apply replacements to all cells
        for sheet in wb.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    if isinstance(cell.value, str) and cell.value:
                        for original, replacement in replacements.items():
                            cell.value = cell.value.replace(original, replacement)

        # Also check cell comments / notes for PII
        for sheet in wb.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    if cell.comment and cell.comment.text:
                        for original, replacement in replacements.items():
                            cell.comment.text = cell.comment.text.replace(
                                original, replacement
                            )

        # ── Metadata scrubbing ─────────────────────────────────────────
        wb.properties.creator = ""
        wb.properties.lastModifiedBy = ""
        wb.properties.title = ""
        wb.properties.subject = ""
        wb.properties.description = ""
        wb.properties.keywords = ""
        wb.properties.category = ""

        # Deep scrub: defined names (named ranges/formulas) may contain PII
        _strip_xlsx_defined_names(wb)

        logger.info("Scrubbed XLSX metadata, cell comments, and defined names")

        # Save anonymized XLSX
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = Path(doc.original_filename).stem
        output_dir = config.temp_dir / doc.doc_id / "output"
        output_dir.mkdir(parents=True, exist_ok=True)

        xlsx_path = output_dir / f"{stem}_anonymized_{timestamp}.xlsx"
        wb.save(str(xlsx_path))
        logger.info("Saved anonymized XLSX: %s", xlsx_path)

        # Convert anonymized XLSX → PDF for uniform AI-friendly export
        pdf_path = _convert_to_pdf(xlsx_path, output_dir)

        return _finalize_anonymization(
            doc, pdf_path, tokens_created, regions_removed, token_manifest,
        )

    finally:
        wb.close()


def _anonymize_xls_sync(doc: DocumentInfo, original_path: Path, group_token_cache: GroupTokenCache | None = None) -> AnonymizeResponse:
    """Anonymize a legacy .xls file by converting to .xlsx first, then anonymizing.

    The output is always .xlsx since the legacy .xls format cannot be
    written reliably from pure Python.
    """
    from core.ingestion.loader import _xls_to_xlsx  # noqa: F811
    from core.anonymizer.engine import config

    # Convert .xls → .xlsx in a temp location
    convert_dir = config.temp_dir / doc.doc_id / "xls_convert"
    xlsx_path = _xls_to_xlsx(original_path, convert_dir)

    # Delegate to the xlsx anonymizer with the converted file
    return _anonymize_xlsx_sync(doc, xlsx_path, group_token_cache)


def _anonymize_txt_sync(doc: DocumentInfo, original_path: Path, group_token_cache: GroupTokenCache | None = None) -> AnonymizeResponse:
    """Anonymize a plain-text file using string replacements.

    Reads the original text, applies REMOVE / TOKENIZE replacements,
    saves an anonymized .txt file, then converts to PDF for AI export.
    """
    from core.anonymizer.engine import (
        config, _resolve_or_create_token, _convert_to_pdf, _finalize_anonymization,
    )

    tokens_created = 0
    regions_removed = 0
    token_manifest: list[dict] = []

    # Read original text (respect encoding detected during ingestion)
    try:
        text = original_path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        import chardet
        raw = original_path.read_bytes()
        detected = chardet.detect(raw)
        text = raw.decode(detected.get("encoding") or "utf-8", errors="replace")

    full_text = text

    # Sort regions by char_end descending to preserve offsets
    sorted_regions = sorted(
        [r for r in doc.regions if r.action in (RegionAction.REMOVE, RegionAction.TOKENIZE)],
        key=lambda r: r.char_end,
        reverse=True,
    )

    replacements: dict[str, str] = {}
    _group_tokens: dict[str, str] = {}

    for region in sorted_regions:
        # Use original_text (pre-edit text) for matching in the document
        search_text = region.original_text or region.text

        if region.action == RegionAction.REMOVE:
            replacements[search_text] = "---"
            regions_removed += 1

        elif region.action == RegionAction.TOKENIZE:
            token_string = _resolve_or_create_token(
                region, doc, full_text,
                group_token_cache, _group_tokens,
                token_manifest,
            )
            replacements[search_text] = token_string
            tokens_created += 1

    # Apply replacements
    anonymized = text
    for original_text, replacement in replacements.items():
        anonymized = anonymized.replace(original_text, replacement)

    # Save anonymized text
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    stem = Path(doc.original_filename).stem
    output_dir = config.temp_dir / doc.doc_id / "output"
    output_dir.mkdir(parents=True, exist_ok=True)

    txt_path = output_dir / f"{stem}_anonymized_{timestamp}.txt"
    txt_path.write_text(anonymized, encoding="utf-8")
    logger.info("Saved anonymized TXT: %s", txt_path)

    # Convert to PDF for uniform export
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from xml.sax.saxutils import escape

    pdf_path = output_dir / f"{stem}_anonymized_{timestamp}.pdf"
    styles = getSampleStyleSheet()
    body_style = ParagraphStyle(
        "TxtBody", parent=styles["Normal"],
        fontSize=10, leading=13, spaceAfter=4,
        fontName="Courier",
    )

    elements: list = []
    for line in anonymized.split("\n"):
        escaped = escape(line) if line.strip() else "&nbsp;"
        elements.append(Paragraph(escaped, body_style))

    doc_builder = SimpleDocTemplate(
        str(pdf_path),
        pagesize=letter,
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
    )
    if not elements:
        elements.append(Paragraph("(Empty document)", styles["Normal"]))
    doc_builder.build(elements)

    logger.info("Converted anonymized TXT to PDF: %s", pdf_path)

    return _finalize_anonymization(
        doc, pdf_path, tokens_created, regions_removed, token_manifest,
    )


def _anonymize_image_sync(doc: DocumentInfo, original_path: Path, group_token_cache: GroupTokenCache | None = None) -> AnonymizeResponse:
    """Anonymize an image file using bitmap manipulation."""
    from core.anonymizer.engine import (
        config, _resolve_or_create_token, _resolve_overlapping_bboxes,
        _convert_to_pdf, _finalize_anonymization,
    )
    from core.anonymizer._engine_pdf import _fit_pil_text

    tokens_created = 0
    regions_removed = 0
    token_manifest: list[dict] = []

    # Load the original image
    img = Image.open(str(original_path)).convert("RGB")

    try:
        draw = ImageDraw.Draw(img)

        # Get page dimensions
        page_data = doc.pages[0] if doc.pages else None
        if not page_data:
            raise ValueError("No page data available for image")

        full_text = page_data.full_text

        # Process all annotated regions
        # Cache: linked_group → token_string (siblings share one token)
        _group_tokens: dict[str, str] = {}

        # Resolve overlapping bboxes so tokens never visually overlap
        resolved_regions = _resolve_overlapping_bboxes(
            [r for r in doc.regions if r.action in (RegionAction.REMOVE, RegionAction.TOKENIZE)]
        )

        for region in resolved_regions:
            if region.action == RegionAction.REMOVE:
                # Draw white rectangle (clean removal)
                bbox = region.bbox
                draw.rectangle(
                    [bbox.x0, bbox.y0, bbox.x1, bbox.y1],
                    fill=(255, 255, 255),
                )
                regions_removed += 1

            elif region.action == RegionAction.TOKENIZE:
                token_string = _resolve_or_create_token(
                    region, doc, full_text,
                    group_token_cache, _group_tokens,
                    token_manifest,
                )

                # Draw white rectangle then add token text
                bbox = region.bbox
                draw.rectangle(
                    [bbox.x0, bbox.y0, bbox.x1, bbox.y1],
                    fill=(255, 255, 255),
                )
                # Draw token text — fit within the bounding box
                region_w = bbox.x1 - bbox.x0
                region_h = bbox.y1 - bbox.y0
                font, fitted_text = _fit_pil_text(
                    token_string, region_w, region_h, draw,
                )
                draw.text(
                    (bbox.x0 + 2, bbox.y0 + (region_h - font.size) / 2 if hasattr(font, 'size') else bbox.y0 + 2),
                    fitted_text,
                    fill=(0, 0, 0),
                    font=font,
                )
                tokens_created += 1

        # Save anonymized image with original extension
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        stem = Path(doc.original_filename).stem
        ext = Path(doc.original_filename).suffix.lower()
        output_dir = config.temp_dir / doc.doc_id / "output"
        output_dir.mkdir(parents=True, exist_ok=True)

        img_path = output_dir / f"{stem}_anonymized_{timestamp}{ext}"

        # ── Metadata scrubbing ─────────────────────────────────────────
        # Strip ALL metadata (EXIF, IPTC, XMP, ICC profiles, PNG text chunks)
        # that may contain PII such as GPS coords, author, camera serial, etc.
        # Create a clean pixel-only copy of the image.
        clean_img = Image.new(img.mode, img.size)
        clean_img.frombytes(img.tobytes())

        # Save with appropriate format
        try:
            if ext in [".jpg", ".jpeg"]:
                clean_img.save(str(img_path), "JPEG", quality=95)
            elif ext == ".png":
                clean_img.save(str(img_path), "PNG")
            else:
                clean_img.save(str(img_path))
        finally:
            clean_img.close()

        logger.info("Saved anonymized image (EXIF stripped): %s", img_path)

        # Convert anonymized image → PDF for uniform AI-friendly export
        pdf_path = _convert_to_pdf(img_path, output_dir)

        return _finalize_anonymization(
            doc, pdf_path, tokens_created, regions_removed, token_manifest,
        )

    finally:
        img.close()



