"""Anonymization engine — applies redaction and tokenization to documents.

Architecture
------------
This module is the composition root.  Format-specific handlers live in
private sub-modules (``_engine_pdf``, ``_engine_formats``) and are
imported + re-exported below so that external callers can still do::

    from core.anonymizer.engine import _anonymize_pdf_sync

Shared utilities (``_resolve_or_create_token``, ``_resolve_overlapping_bboxes``,
``_convert_to_pdf``, ``_finalize_anonymization``) stay here because every
format handler depends on them.  Sub-modules use **deferred imports**
(inside function bodies) to break the circular engine ↔ sub-module
reference.

Deduplication
~~~~~~~~~~~~~
Region dedup is handled at the store layer (frontend ``setRegions``
de-duplicates by ID) and at the merge layer (``merge.py`` resolves
overlapping detections before regions reach the engine).  The engine
itself intentionally does **no** dedup — it trusts upstream.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path

import fitz  # PyMuPDF
from PIL import Image

from core.config import config
from core.vault.store import vault
from models.schemas import (
    AnonymizeResponse,
    DocumentInfo,
    PIIRegion,
    PIIType,
    RegionAction,
    TokenMapping,
)

logger = logging.getLogger(__name__)


# A shared cache mapping (normalised_text, pii_type_value) → token_string.
# When documents share a group_id the same cache is passed to every call of
# anonymize_document so identical PII tokens are reused across the group.
GroupTokenCache = dict[tuple[str, str], str]


def _resolve_or_create_token(
    region: PIIRegion,
    doc: DocumentInfo,
    full_text: str,
    group_token_cache: GroupTokenCache | None,
    _group_tokens: dict[str, str],
    token_manifest: list[dict],
    page_number: int | None = None,
) -> str:
    """Return an existing or freshly generated token string for *region*.

    Resolution order:
    1. Intra-document ``linked_group`` cache (``_group_tokens``) — sibling
       regions that were split across lines share one token.
    2. Cross-document ``group_token_cache`` — linked documents reuse the
       same token for identical ``(original_text, pii_type)`` pairs.
    3. Vault lookup via ``find_token_by_text`` — catches tokens created in a
       previous (non-cached) run.
    4. Generate a brand-new token, store it in the vault, and populate all
       caches.

    Returns the *token_string* (e.g. ``[P38291]``).
    """
    text = region.text
    pii_type = region.pii_type
    pii_key = (text, pii_type.value if isinstance(pii_type, PIIType) else str(pii_type))

    # 1. Intra-document linked_group
    grp = region.linked_group
    if grp and grp in _group_tokens:
        return _group_tokens[grp]

    # 2. Cross-document group cache
    if group_token_cache is not None and pii_key in group_token_cache:
        token_string = group_token_cache[pii_key]
        if grp:
            _group_tokens[grp] = token_string
        return token_string

    # 3 & 4. Generate or reuse from vault
    token_string = vault.generate_token_string(pii_type, original_text=text)
    mapping = TokenMapping(
        token_string=token_string,
        original_text=text,
        pii_type=pii_type,
        source_document=doc.original_filename,
        context_snippet=_get_context_snippet(
            full_text,
            region.char_start,
            region.char_end,
        ),
    )
    vault.store_token(mapping)

    manifest_entry: dict = {
        "token_string": token_string,
        "original_text": text,
    }
    if page_number is not None:
        manifest_entry["page_number"] = page_number
    token_manifest.append(manifest_entry)

    # Populate caches
    if grp:
        _group_tokens[grp] = token_string
    if group_token_cache is not None:
        group_token_cache[pii_key] = token_string

    return token_string

from core.constants import PDF_TYPES, IMAGE_TYPES, DOCX_TYPE, XLSX_TYPE, XLS_TYPE, TEXT_TYPE


# ---------------------------------------------------------------------------
# Overlap resolution — prevents overlapping tokens in visual output
# ---------------------------------------------------------------------------

def _resolve_overlapping_bboxes(regions: list[PIIRegion]) -> list[PIIRegion]:
    """Nudge overlapping region bboxes apart so token text never overlaps.

    Mutates nothing — returns a new list with adjusted bbox copies.
    Regions are pushed apart along the axis with the smallest overlap
    (same algorithm as the frontend ``resolveAllOverlaps``).

    Note: this is *visual* bbox nudging for anonymization output, distinct
    from the *char-span* overlap check in ``propagation._PageIntervals``
    (1-D interval dedup) and the inline bbox intersection test in
    ``regions.py`` (hit-test for manual-draw dedup).  Each serves a
    different purpose — do not unify.
    """
    if len(regions) <= 1:
        return regions

    # Work on mutable copies so we don't mutate the originals
    adjusted: list[PIIRegion] = [r.model_copy(deep=True) for r in regions]

    MAX_PASSES = 10
    n = len(adjusted)
    for _ in range(MAX_PASSES):
        changed = False
        # Sort indices by bbox x0 for sweep-line pruning
        order = sorted(range(n), key=lambda k: adjusted[k].bbox.x0)
        for ii in range(n):
            i = order[ii]
            a = adjusted[i].bbox
            for jj in range(ii + 1, n):
                j = order[jj]
                b = adjusted[j].bbox
                # Sweep-line: if b.x0 >= a.x1, no further overlaps possible
                if b.x0 >= a.x1:
                    break
                # Check y overlap
                if a.y0 >= b.y1 or a.y1 <= b.y0:
                    continue
                # Compute overlap extents
                overlap_x = min(a.x1, b.x1) - max(a.x0, b.x0)
                overlap_y = min(a.y1, b.y1) - max(a.y0, b.y0)
                if overlap_x <= 0 or overlap_y <= 0:
                    continue
                changed = True
                cx_a = (a.x0 + a.x1) / 2
                cy_a = (a.y0 + a.y1) / 2
                cx_b = (b.x0 + b.x1) / 2
                cy_b = (b.y0 + b.y1) / 2
                if overlap_y <= overlap_x:
                    # Push apart vertically
                    shift = overlap_y / 2 + 1
                    if cy_a < cy_b:
                        a.y0 -= shift; a.y1 -= shift
                        b.y0 += shift; b.y1 += shift
                    else:
                        a.y0 += shift; a.y1 += shift
                        b.y0 -= shift; b.y1 -= shift
                else:
                    # Push apart horizontally
                    shift = overlap_x / 2 + 1
                    if cx_a < cx_b:
                        a.x0 -= shift; a.x1 -= shift
                        b.x0 += shift; b.x1 += shift
                    else:
                        a.x0 += shift; a.x1 += shift
                        b.x0 -= shift; b.x1 -= shift
        if not changed:
            break

    return adjusted


# ---------------------------------------------------------------------------
# Shared finalization helpers (eliminate duplication across handlers)
# ---------------------------------------------------------------------------

def _save_manifest(
    output_dir: Path,
    doc_id: str,
    original_filename: str,
    token_manifest: list[dict],
) -> None:
    """Save the token manifest as plaintext JSON alongside the output."""
    manifest = {
        "doc_id": doc_id,
        "original_filename": original_filename,
        "tokens": token_manifest,
    }
    manifest_path = output_dir / "token_manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    logger.info("Saved token manifest with %s entries", len(token_manifest))


def _convert_to_pdf(native_path: Path, output_dir: Path) -> Path:
    """Convert an anonymized native-format file (DOCX, XLSX, image) to PDF.

    Uses the same pure-Python converters from the ingestion pipeline
    (python-docx + reportlab, openpyxl + reportlab), so no external
    dependencies like LibreOffice are required.  Fully cross-platform.

    For images, wraps the image in a single-page PDF via PyMuPDF.
    The original native file is kept alongside the PDF.
    """
    ext = native_path.suffix.lower()
    stem = native_path.stem  # already contains _anonymized_{timestamp}
    pdf_path = output_dir / f"{stem}.pdf"

    if ext == ".docx":
        from docx import Document
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.units import inch
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
        )
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors
        from xml.sax.saxutils import escape

        docx_doc = Document(str(native_path))

        styles = getSampleStyleSheet()
        body_style = ParagraphStyle(
            "DocxBody", parent=styles["Normal"],
            fontSize=10, leading=13, spaceAfter=4,
        )
        heading_styles: dict[int, ParagraphStyle] = {}
        for level, (fs, lead) in enumerate(
            [(16, 20), (14, 18), (12, 16), (11, 15), (10, 14)], start=1
        ):
            heading_styles[level] = ParagraphStyle(
                f"DocxH{level}", parent=styles["Normal"],
                fontSize=fs, leading=lead, spaceAfter=6, spaceBefore=8,
                fontName="Helvetica-Bold",
            )
        cell_style = ParagraphStyle(
            "DocxCell", parent=styles["Normal"],
            fontSize=9, leading=11, wordWrap="CJK",
        )

        def _para_to_flowable(para):
            text_parts: list[str] = []
            for run in para.runs:
                t = escape(run.text) if run.text else ""
                if not t:
                    continue
                if run.bold and run.italic:
                    t = f"<b><i>{t}</i></b>"
                elif run.bold:
                    t = f"<b>{t}</b>"
                elif run.italic:
                    t = f"<i>{t}</i>"
                if run.underline:
                    t = f"<u>{t}</u>"
                text_parts.append(t)

            full = "".join(text_parts).strip()
            if not full:
                return None

            style_name = para.style.name if para.style else ""
            lvl = 0
            if style_name.startswith("Heading"):
                try:
                    lvl = int(style_name.split()[-1])
                except (ValueError, IndexError):
                    lvl = 1
            pstyle = heading_styles.get(lvl, body_style)

            align = para.alignment
            if align == WD_ALIGN_PARAGRAPH.CENTER:
                pstyle = ParagraphStyle(f"_c{id(para)}", parent=pstyle, alignment=1)
            elif align == WD_ALIGN_PARAGRAPH.RIGHT:
                pstyle = ParagraphStyle(f"_r{id(para)}", parent=pstyle, alignment=2)

            return Paragraph(full, pstyle)

        def _table_to_flowable(tbl):
            data: list[list] = []
            for row in tbl.rows:
                row_data: list = []
                for cell in row.cells:
                    cell_text = escape(cell.text.strip()) if cell.text else ""
                    if len(cell_text) > 200:
                        cell_text = cell_text[:197] + "..."
                    row_data.append(Paragraph(cell_text, cell_style))
                data.append(row_data)
            if not data:
                return None
            ncols = max(len(r) for r in data)
            available = letter[0] - 1 * inch
            col_w = min(available / max(ncols, 1), 2.5 * inch)
            t = Table(data, colWidths=[col_w] * ncols)
            t.setStyle(TableStyle([
                ("FONTSIZE", (0, 0), (-1, -1), 9),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 3),
                ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                ("TOPPADDING", (0, 0), (-1, -1), 2),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ]))
            return t

        from docx.oxml.ns import qn

        elements: list = []

        for section in docx_doc.sections:
            for hdr in (section.header,):
                if hdr and not hdr.is_linked_to_previous:
                    for p in hdr.paragraphs:
                        fl = _para_to_flowable(p)
                        if fl:
                            elements.append(fl)
            break

        body = docx_doc.element.body
        for child in body:
            tag = child.tag
            if tag == qn("w:p"):
                para = None
                for p in docx_doc.paragraphs:
                    if p._element is child:
                        para = p
                        break
                if para is None:
                    continue
                if para.style and para.style.name and "page" in para.style.name.lower():
                    elements.append(PageBreak())
                fl = _para_to_flowable(para)
                if fl:
                    elements.append(fl)
                else:
                    elements.append(Spacer(1, 4))
            elif tag == qn("w:tbl"):
                tbl = None
                for t in docx_doc.tables:
                    if t._element is child:
                        tbl = t
                        break
                if tbl:
                    fl = _table_to_flowable(tbl)
                    if fl:
                        elements.append(Spacer(1, 4))
                        elements.append(fl)
                        elements.append(Spacer(1, 4))
            elif tag == qn("w:sectPr"):
                elements.append(PageBreak())

        for section in docx_doc.sections:
            for ftr in (section.footer,):
                if ftr and not ftr.is_linked_to_previous:
                    for p in ftr.paragraphs:
                        fl = _para_to_flowable(p)
                        if fl:
                            elements.append(fl)
            break

        doc_builder = SimpleDocTemplate(
            str(pdf_path),
            pagesize=letter,
            leftMargin=0.75 * inch,
            rightMargin=0.75 * inch,
            topMargin=0.75 * inch,
            bottomMargin=0.75 * inch,
        )
        if not elements:
            elements.append(Paragraph("(Empty document)", styles["Normal"]))
        doc_builder.build(elements)
        del docx_doc

    elif ext == ".xlsx":
        from openpyxl import load_workbook
        from reportlab.lib.pagesizes import letter, landscape
        from reportlab.lib.units import inch
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
        )
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors

        wb = load_workbook(str(native_path), data_only=True)

        cell_style = ParagraphStyle(
            "CellStyle", parent=getSampleStyleSheet()["Normal"],
            fontSize=8, leading=10, wordWrap="CJK",
        )
        header_style = ParagraphStyle(
            "HeaderStyle", parent=getSampleStyleSheet()["Heading2"],
            fontSize=12, spaceAfter=12,
        )
        styles = getSampleStyleSheet()
        elements: list = []

        for sheet_idx, sheet_name in enumerate(wb.sheetnames):
            ws = wb[sheet_name]
            elements.append(Paragraph(f"Sheet: {sheet_name}", header_style))
            elements.append(Spacer(1, 0.1 * inch))

            if ws.max_row is None or ws.max_column is None:
                continue

            max_row = min(ws.max_row, 500)
            max_col = min(ws.max_column, 26)
            if max_row == 0 or max_col == 0:
                elements.append(Paragraph("(Empty sheet)", styles["Normal"]))
                if sheet_idx < len(wb.sheetnames) - 1:
                    elements.append(PageBreak())
                continue

            table_data: list[list] = []
            for row_idx in range(1, max_row + 1):
                row_data: list = []
                for col_idx in range(1, max_col + 1):
                    cell = ws.cell(row=row_idx, column=col_idx)
                    value = cell.value
                    if value is None:
                        value = ""
                    elif isinstance(value, (int, float)):
                        if isinstance(value, float) and value == int(value):
                            value = str(int(value))
                        else:
                            value = str(value)
                    else:
                        value = str(value)
                    if len(value) > 100:
                        value = value[:97] + "..."
                    row_data.append(Paragraph(value, cell_style))
                table_data.append(row_data)

            if not table_data:
                elements.append(Paragraph("(Empty sheet)", styles["Normal"]))
                if sheet_idx < len(wb.sheetnames) - 1:
                    elements.append(PageBreak())
                continue

            available_width = landscape(letter)[0] - 1 * inch
            col_width = min(available_width / max_col, 1.5 * inch)
            table = Table(table_data, colWidths=[col_width] * max_col, repeatRows=1)
            table.setStyle(TableStyle([
                ("FONTSIZE", (0, 0), (-1, -1), 8),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("LEFTPADDING", (0, 0), (-1, -1), 3),
                ("RIGHTPADDING", (0, 0), (-1, -1), 3),
                ("TOPPADDING", (0, 0), (-1, -1), 2),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ]))
            elements.append(table)
            if sheet_idx < len(wb.sheetnames) - 1:
                elements.append(PageBreak())

        doc_builder = SimpleDocTemplate(
            str(pdf_path),
            pagesize=landscape(letter),
            leftMargin=0.5 * inch,
            rightMargin=0.5 * inch,
            topMargin=0.5 * inch,
            bottomMargin=0.5 * inch,
        )
        if not elements:
            elements.append(Paragraph("(Empty workbook)", getSampleStyleSheet()["Normal"]))
        doc_builder.build(elements)
        wb.close()

    elif ext in (".jpg", ".jpeg", ".png", ".tiff", ".tif", ".bmp", ".webp"):
        # Wrap image in single-page PDF via PyMuPDF
        img_pil = Image.open(str(native_path))
        w_px, h_px = img_pil.size
        img_pil.close()

        pdf_doc = fitz.open()
        page = pdf_doc.new_page(width=w_px, height=h_px)
        page.insert_image(fitz.Rect(0, 0, w_px, h_px), filename=str(native_path))
        pdf_doc.save(str(pdf_path), deflate=True)
        pdf_doc.close()

    else:
        logger.warning("No PDF converter for extension %s, keeping native format", ext)
        return native_path

    if pdf_path.exists():
        logger.info("Converted anonymized output to PDF: %s", pdf_path)
        return pdf_path
    else:
        logger.warning("PDF conversion failed for %s, keeping native format", native_path)
        return native_path


def _finalize_anonymization(
    doc: DocumentInfo,
    output_path: Path,
    tokens_created: int,
    regions_removed: int,
    token_manifest: list[dict],
) -> AnonymizeResponse:
    """Common finalization: save manifest, register document, return response."""
    output_dir = output_path.parent

    # Save token manifest
    _save_manifest(output_dir, doc.doc_id, doc.original_filename, token_manifest)

    # Register in vault
    vault.register_document(
        doc_id=doc.doc_id,
        original_filename=doc.original_filename,
        page_count=doc.page_count,
        anonymized_filename=output_path.name,
    )

    logger.info(
        f"Anonymized '{doc.original_filename}': "
        f"{regions_removed} removed, {tokens_created} tokenized"
    )

    return AnonymizeResponse(
        doc_id=doc.doc_id,
        output_path=str(output_path),
        output_text_path="",
        tokens_created=tokens_created,
        regions_removed=regions_removed,
    )


async def anonymize_document(
    doc: DocumentInfo,
    group_token_cache: GroupTokenCache | None = None,
) -> AnonymizeResponse:
    """
    Apply all accepted region actions to a document and produce output files.

    Parameters
    ----------
    doc : DocumentInfo
        The document to anonymize.
    group_token_cache : GroupTokenCache | None
        Optional shared cache so linked documents (same ``group_id``) reuse
        the same token for identical PII text.  Pass the **same** dict for
        every document in the group.

    Dispatches to the appropriate handler based on file type:
    - PDF: Text-based redaction with PyMuPDF
    - DOCX: Text replacement in paragraphs/tables
    - XLSX: Text replacement in cells
    - Images: Bitmap manipulation
    """
    vault.ensure_ready()

    original_path = Path(doc.file_path)
    if not original_path.exists():
        raise RuntimeError(f"Original file not found: {original_path}")

    # Dispatch to appropriate handler based on MIME type
    if doc.mime_type in PDF_TYPES:
        return await asyncio.to_thread(_anonymize_pdf_sync, doc, original_path, group_token_cache)
    elif doc.mime_type == DOCX_TYPE:
        return await asyncio.to_thread(_anonymize_docx_sync, doc, original_path, group_token_cache)
    elif doc.mime_type == XLSX_TYPE:
        return await asyncio.to_thread(_anonymize_xlsx_sync, doc, original_path, group_token_cache)
    elif doc.mime_type == XLS_TYPE:
        return await asyncio.to_thread(_anonymize_xls_sync, doc, original_path, group_token_cache)
    elif doc.mime_type in IMAGE_TYPES:
        return await asyncio.to_thread(_anonymize_image_sync, doc, original_path, group_token_cache)
    elif doc.mime_type == TEXT_TYPE:
        return await asyncio.to_thread(_anonymize_txt_sync, doc, original_path, group_token_cache)
    else:
        raise ValueError(f"Unsupported file type for anonymization: {doc.mime_type}")



# ---------------------------------------------------------------------------
# Format-specific handlers (extracted to sub-modules)
#
# Each sub-module uses *deferred imports* (inside function bodies) to pull
# shared utilities from this file, avoiding circular-import errors.
# The re-exports here guarantee backward-compatible imports for tests and
# other consumers that do ``from core.anonymizer.engine import <symbol>``.
# ---------------------------------------------------------------------------

from core.anonymizer._engine_pdf import (  # noqa: E402, F401
    _load_font,
    _fit_pil_text,
    _redact_scanned_page,
    _strip_pdf_deep_metadata,
    _anonymize_pdf_sync,
)
from core.anonymizer._engine_formats import (  # noqa: E402, F401
    _anonymize_docx_sync,
    _anonymize_xlsx_sync,
    _anonymize_xls_sync,
    _anonymize_txt_sync,
    _anonymize_image_sync,
)

# Re-export helpers that tests import from engine
from core.anonymizer.anonymizer_helpers import (  # noqa: E402, F401
    replace_in_paragraphs as _replace_in_paragraphs,
)

def _map_to_base14(font_name: str, flags: int) -> str:
    """Map an arbitrary PDF font name + flags to the closest Base-14 font.

    ``flags`` comes from a PyMuPDF span dict (bit 1 = italic, bit 4 = bold,
    bit 2 = serif, bit 3 = monospaced).
    """
    is_bold = bool(flags & 16)
    is_italic = bool(flags & 2)
    is_serif = bool(flags & 4)
    is_mono = bool(flags & 8)

    name_lower = font_name.lower()

    # Monospace family
    if is_mono or any(k in name_lower for k in ("courier", "mono", "consol", "firacode", "source code")):
        if is_bold and is_italic:
            return "cobi"
        if is_bold:
            return "cobo"
        if is_italic:
            return "coit"
        return "cour"

    # Serif family
    if is_serif or any(k in name_lower for k in ("times", "serif", "roman", "garamond", "georgia", "cambria", "palat")):
        if is_bold and is_italic:
            return "tibi"
        if is_bold:
            return "tibo"
        if is_italic:
            return "tiit"
        return "tiro"

    # Default: Helvetica (sans-serif)
    if is_bold and is_italic:
        return "hebi"
    if is_bold:
        return "hebo"
    if is_italic:
        return "heit"
    return "helv"


def _srgb_int_to_rgb(color_int: int) -> tuple[float, float, float]:
    """Convert a span ``color`` integer (0xRRGGBB) to the (r, g, b) float
    tuple that PyMuPDF drawing/redaction methods expect (each 0.0–1.0)."""
    r = ((color_int >> 16) & 0xFF) / 255.0
    g = ((color_int >> 8) & 0xFF) / 255.0
    b = (color_int & 0xFF) / 255.0
    return (r, g, b)


def _extract_span_style(
    page: fitz.Page,
    rect: fitz.Rect,
) -> dict:
    """Return the dominant text-span style properties inside *rect*.

    Searches all text spans that overlap the redaction rectangle and picks
    the one with the largest overlap area so the replacement inherits the
    correct font size, weight, and color.

    Also returns the text *origin* (baseline insertion point) so that
    replacement text can be inserted at exactly the right position.

    Falls back to sensible defaults if the rect contains no extractable text
    (e.g. image-only area).
    """
    blocks = page.get_text("dict", flags=fitz.TEXTFLAGS_TEXT).get("blocks", [])

    best_span: dict | None = None
    best_overlap: float = 0.0

    for block in blocks:
        if block.get("type", 0) != 0:  # text blocks only
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                span_rect = fitz.Rect(span["bbox"])
                intersection = span_rect & rect
                if intersection.is_empty:
                    continue
                area = intersection.width * intersection.height
                if area > best_overlap:
                    best_overlap = area
                    best_span = span

    if best_span is None:
        return {
            "fontname": "helv",
            "fontsize": 11.0,
            "text_color": (0, 0, 0),
            "origin": (rect.x0, rect.y1 - 2),  # rough baseline fallback
        }

    # Use the PII region's left edge (rect.x0) as x — NOT the span
    # origin, which may be far to the left if PII is mid-span.
    # Keep the span's baseline y so vertical position is correct.
    span_origin = best_span.get("origin", (rect.x0, rect.y1 - 2))
    baseline_y = span_origin[1]

    return {
        "fontname": _map_to_base14(best_span.get("font", ""), best_span.get("flags", 0)),
        "fontsize": best_span.get("size", 11.0),
        "text_color": _srgb_int_to_rgb(best_span.get("color", 0)),
        "origin": (rect.x0, baseline_y),
    }


def _get_context_snippet(text: str, start: int, end: int, context_chars: int = 50) -> str:
    """Extract a text snippet around the PII for disambiguation."""
    ctx_start = max(0, start - context_chars)
    ctx_end = min(len(text), end + context_chars)
    snippet = text[ctx_start:ctx_end]
    if ctx_start > 0:
        snippet = "..." + snippet
    if ctx_end < len(text):
        snippet = snippet + "..."
    return snippet
