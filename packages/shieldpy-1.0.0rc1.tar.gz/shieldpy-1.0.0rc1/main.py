"""Main entry point for promptShield.

When run directly (or as a standalone exe), starts a FastAPI server
and opens the browser UI.
"""

from __future__ import annotations

import logging
import os
import socket
import sys
import threading


def find_free_port() -> int:
    """Find an available TCP port.

    L8: To mitigate TOCTOU, we keep SO_REUSEADDR so the port can be
    immediately rebound by uvicorn.  The window is tiny and acceptable
    for a local-only desktop app.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _open_browser_delayed(url: str, delay: float = 1.5):
    """Open the browser after a short delay to let the server start."""
    import time
    import webbrowser
    time.sleep(delay)
    webbrowser.open(url)


def _write_port_line(port: int) -> None:
    """Write PORT:<port> to stdout so the parent process can read it.

    In PyInstaller windowed mode (console=False), Python's sys.stdout
    may be None or broken, but the OS may still have a valid pipe handle
    when a parent process redirects stdout (Tauri, smoke test).
    We try multiple strategies in order of reliability:
      1. sys.stdout.write() — works when stdout is a real pipe
      2. os.write(1, ...) — raw fd write, bypasses Python IO
      3. Win32 WriteFile on STD_OUTPUT_HANDLE — bypasses CRT entirely
    """
    line = f"PORT:{port}\n"

    # Strategy 1: Python's sys.stdout (works for normal/Tauri sidecar modes)
    if sys.stdout is not None:
        try:
            sys.stdout.write(line)
            sys.stdout.flush()
            return
        except (OSError, ValueError, AttributeError):
            pass

    # Strategy 2: raw POSIX fd write
    try:
        os.write(1, line.encode())
        return
    except OSError:
        pass

    # Strategy 3: Win32 API (Windows only, console=False with redirected pipes)
    if os.name == "nt":
        try:
            import ctypes
            STD_OUTPUT_HANDLE = -11
            handle = ctypes.windll.kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
            if handle and handle not in (-1, 0):
                data = line.encode()
                written = ctypes.c_ulong()
                ctypes.windll.kernel32.WriteFile(
                    handle, data, len(data), ctypes.byref(written), None,
                )
                return
        except Exception:
            pass


def _cleanup_stale_pyinstaller_dirs() -> None:
    """Remove leftover _MEI* temp directories from previous force-killed runs.

    PyInstaller one-file mode extracts to %TEMP%\\_MEI{random}.
    If the process is force-killed, the atexit cleanup never runs and these
    ~110 MB directories pile up, degrading performance.
    """
    if os.name != "nt":
        return
    import shutil
    import tempfile

    tmpdir = tempfile.gettempdir()
    # Our own extraction directory — never delete it
    own_meipass = getattr(sys, "_MEIPASS", None)

    try:
        for entry in os.scandir(tmpdir):
            if not entry.is_dir() or not entry.name.startswith("_MEI"):
                continue
            if own_meipass and os.path.normcase(entry.path) == os.path.normcase(own_meipass):
                continue
            try:
                shutil.rmtree(entry.path)
            except (PermissionError, OSError):
                pass  # Still locked by a running process — skip
    except OSError:
        pass


def _disable_ecoqos() -> None:
    """Opt out of Windows EcoQoS / efficiency-mode CPU throttling.

    Windows 11 Power Efficiency mode applies EcoQoS to processes, reducing
    CPU frequency and I/O priority.  This devastates PyInstaller extraction
    and heavy Python imports (40 s+ startup).  We disable it for our process
    and raise priority to ABOVE_NORMAL so the sidecar boots quickly even
    when the user has selected "Max Power Efficiency".
    """
    if os.name != "nt":
        return
    try:
        import ctypes
        import ctypes.wintypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetCurrentProcess()

        # Raise process priority (ABOVE_NORMAL_PRIORITY_CLASS = 0x8000)
        kernel32.SetPriorityClass(handle, 0x00008000)

        # Disable EcoQoS / power throttling via SetProcessInformation
        # ProcessPowerThrottling = 4
        # PROCESS_POWER_THROTTLING_EXECUTION_SPEED = 0x1
        class PROCESS_POWER_THROTTLING_STATE(ctypes.Structure):
            _fields_ = [
                ("Version", ctypes.c_ulong),
                ("ControlMask", ctypes.c_ulong),
                ("StateMask", ctypes.c_ulong),
            ]

        state = PROCESS_POWER_THROTTLING_STATE()
        state.Version = 1  # PROCESS_POWER_THROTTLING_CURRENT_VERSION
        state.ControlMask = 0x1  # Execution speed
        state.StateMask = 0  # 0 = disable throttling

        kernel32.SetProcessInformation(
            handle, 4, ctypes.byref(state), ctypes.sizeof(state),
        )
    except Exception:
        pass  # Best-effort — don't crash if APIs are unavailable


def main():
    # ── Disable EcoQoS throttling immediately ────────────────────
    # Must run before anything heavy (find_free_port, imports, etc.)
    _disable_ecoqos()

    # PyInstaller with console=False / Nuitka with --windows-console-mode=disable
    # set sys.stdout/stderr to None.  Replace them with devnull so
    # print() / logging don't crash, but keep real pipes when the
    # parent (Tauri) provides them.
    # On Windows, stdout/stderr can also be non-None but point to an
    # invalid handle (EINVAL on write), so we probe them.
    is_frozen = getattr(sys, "frozen", False)          # PyInstaller
    # Nuitka injects a __compiled__ built-in in compiled code
    try:
        __compiled__  # noqa: F821
        is_nuitka = True
    except NameError:
        is_nuitka = False
    is_compiled = is_frozen or is_nuitka

    # ── Pre-load PyMuPDF (fitz) via importlib ────────────────────
    # Nuitka deployment mode blocks `import fitz` because it's excluded
    # from C compilation (--nofollow-import-to=fitz) and copied as
    # bytecode post-build.  importlib bypasses the deployment guard.
    # Once in sys.modules, normal `import fitz` everywhere just works.
    if is_nuitka:
        import importlib
        for _mod in ("fitz", "pymupdf", "pymupdf.mupdf"):
            try:
                importlib.import_module(_mod)
            except Exception:
                pass

    # ── Emit PORT line as early as possible ──────────────────────
    # In compiled mode the port is always random.  We print it BEFORE
    # heavy imports (pydantic, fastapi, core.config …) so Tauri / the
    # smoke test can read it within the 15-second timeout.
    # IMPORTANT: This must run BEFORE the stream fixup below, because
    # console=False means sys.stdout is None.  _write_port_line falls
    # through to raw os.write(1) / Win32 WriteFile which work on the
    # redirected pipe handle even when Python's stdio is not set up.
    # If we fixed up streams first, sys.stdout would point to devnull
    # and the PORT line would be silently swallowed.
    port = find_free_port()
    _write_port_line(port)

    if is_compiled:
        for _stream_name in ("stdout", "stderr"):
            _stream = getattr(sys, _stream_name)
            if _stream is None:
                # PyInstaller windowed mode sets stdout/stderr to None.
                # Redirect to devnull so print()/logging don't crash.
                # The PORT line is handled separately via _write_port_line().
                setattr(sys, _stream_name, open(os.devnull, "w"))
            else:
                try:
                    # Validate the underlying OS handle.  write("") skips
                    # the OS call entirely, so it can't detect an invalid
                    # console handle.  os.fstat() actually touches the handle.
                    os.fstat(_stream.fileno())
                except (OSError, ValueError, AttributeError):
                    setattr(sys, _stream_name, open(os.devnull, "w"))

    # Clean up stale PyInstaller temp dirs in background (legacy one-file builds)
    # (PyInstaller-only: Nuitka doesn't use _MEI temp extraction)
    if is_frozen and getattr(sys, "_MEIPASS", "").startswith(os.path.join(os.environ.get("TEMP", ""), "_MEI")):
        threading.Thread(
            target=_cleanup_stale_pyinstaller_dirs, daemon=True, name="mei-cleanup"
        ).start()

    # ── Heavy imports start here ─────────────────────────────────

    # Configure logging early so all imports can log
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        handlers=[logging.StreamHandler(sys.stderr)],
    )
    log = logging.getLogger("promptshield")

    # Detect sidecar mode: PS_SESSION_TOKEN is set by the Tauri shell
    is_sidecar = bool(os.environ.get("PS_SESSION_TOKEN"))

    if is_compiled:
        # ── Two-phase startup (frozen mode) ────────────────────────
        # PyInstaller one-file mode makes imports 3-5× slower.  We start
        # uvicorn immediately with a lightweight stub app that returns 503
        # on /health, then import the real FastAPI app + run init in a
        # background thread.  Once ready, the stub swaps to the real app
        # and /health returns 200.  This overlaps uvicorn's own startup
        # time (~1-2 s frozen) with the heavy import chain, saving the
        # user that much wall-clock wait.
        import uvicorn
        from starlette.applications import Starlette
        from starlette.responses import JSONResponse
        from starlette.routing import Route

        _VERSION = "0.1.0"

        class _BootApp:
            """ASGI wrapper: serve stub /health (503) until real app is ready."""

            __slots__ = ("_app",)

            def __init__(self) -> None:
                async def _health_stub(request):  # type: ignore[no-untyped-def]
                    return JSONResponse(
                        {"status": "loading", "version": _VERSION},
                        status_code=503,
                    )

                async def _shutdown_stub(request):  # type: ignore[no-untyped-def]
                    if server is not None:
                        server.should_exit = True
                    return JSONResponse({"status": "shutting_down"})

                self._app: object = Starlette(routes=[
                    Route("/health", _health_stub),
                    Route("/api/shutdown", _shutdown_stub, methods=["POST"]),
                ])

            def set_app(self, app: object) -> None:
                self._app = app

            async def __call__(self, scope, receive, send):  # type: ignore[no-untyped-def]
                await self._app(scope, receive, send)  # type: ignore[misc]

        boot = _BootApp()
        uvi_config = uvicorn.Config(
            boot,
            host="127.0.0.1",
            port=port,
            log_level="info",
            reload=False,
        )
        server = uvicorn.Server(uvi_config)

        def _background_init() -> None:
            """Import real app, run startup init, swap into BootApp."""
            import time as _t
            t0 = _t.perf_counter()

            # Pre-import heavy shared deps in parallel threads so they're
            # cached in sys.modules before core.config and api.server need
            # them.  Each import is GIL-bound, but bytecode decompression
            # from the PYZ archive releases the GIL, giving ~20-30% overlap.
            _preload_done = threading.Event()

            def _preload_deps() -> None:
                try:
                    import pydantic  # noqa: F401 — heaviest shared dep
                except Exception:
                    pass
                _preload_done.set()

            threading.Thread(
                target=_preload_deps, daemon=True, name="preload-deps"
            ).start()

            from core.config import config
            config.port = port
            t1 = _t.perf_counter()
            log.info(f"[BOOT] core.config: {(t1-t0)*1000:.0f}ms")

            # Wait for pre-import thread (usually already done by now)
            _preload_done.wait(timeout=10)

            from api.server import app, run_startup, run_shutdown
            t2 = _t.perf_counter()
            log.info(f"[BOOT] api.server:  {(t2-t1)*1000:.0f}ms")

            app.state._server = server
            run_startup(app)
            t3 = _t.perf_counter()
            log.info(f"[BOOT] startup init: {(t3-t2)*1000:.0f}ms")

            # Swap the real app into the ASGI wrapper — all future
            # requests (including /health) now go through FastAPI
            # with all middleware and routes.
            boot.set_app(app)
            log.info(f"[BOOT] Ready — total {(t3-t0)*1000:.0f}ms")

            import atexit
            atexit.register(run_shutdown)

        threading.Thread(
            target=_background_init, daemon=True, name="boot-init"
        ).start()

        # If running as standalone exe (not sidecar), open the browser
        if not is_sidecar:
            # Delay a bit longer since two-phase boot needs time to load
            threading.Thread(
                target=_open_browser_delayed, args=(f"http://127.0.0.1:{port}", 2.5),
                daemon=True,
            ).start()

        server.run()
    else:
        # ── Dev mode: sequential startup ───────────────────────────
        from core.config import config
        config.port = port
        log.info(f"Starting on {config.host}:{port}")

        import uvicorn
        uvicorn.run(
            "api.server:app",
            host=config.host,
            port=port,
            log_level="info",
            reload=False,
        )


if __name__ == "__main__":
    main()
