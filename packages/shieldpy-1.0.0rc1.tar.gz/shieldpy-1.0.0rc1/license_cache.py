"""Offline license cache for PromptShield CLI / self-hosted API.

Enables offline key validation and local document quota enforcement.

Flow:
  Online  → validate against licensing server, cache result, sync pending usage.
  Offline → validate from local cache, enforce quota locally, accumulate pending delta.

Cache file:  %APPDATA%/promptshield/api_license.json  (Win)
             ~/Library/Application Support/promptshield/api_license.json (macOS)
             ~/.local/share/promptshield/api_license.json (Linux)

The raw API key is NEVER stored — only its SHA-256 hash is persisted.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

# How long a cached license stays valid without re-validation (days).
_CACHE_TTL_DAYS = 35


# ── Cache file location ────────────────────────────────────────

def _cache_dir() -> Path:
    """Application data directory (same as desktop license_guard)."""
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "promptshield"


def _cache_path() -> Path:
    return _cache_dir() / "api_license.json"


def _hash_key(api_key: str) -> str:
    return hashlib.sha256(api_key.encode()).hexdigest()


# ── Cache read / write ──────────────────────────────────────────

def _read_cache() -> Optional[dict]:
    """Read the cache file, return None if missing or unreadable."""
    path = _cache_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        return data
    except (OSError, json.JSONDecodeError, ValueError):
        return None


def _write_cache(data: dict) -> None:
    """Write the cache file atomically (write-then-rename)."""
    path = _cache_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    tmp.replace(path)


# ── Public API ──────────────────────────────────────────────────

def cache_validation(api_key: str, server_response: dict) -> None:
    """Cache a successful online validation response.

    Merges with existing local usage delta (if any) so pending_sync is preserved.
    """
    key_hash = _hash_key(api_key)
    now = datetime.now(timezone.utc).isoformat()

    # Preserve pending_sync from previous cache if same key
    existing = _read_cache()
    pending = 0
    if existing and existing.get("key_hash") == key_hash:
        pending = existing.get("pending_sync", 0)

    cache = {
        "key_hash": key_hash,
        "plan": server_response.get("plan", ""),
        "scopes": server_response.get("scopes", ""),
        "doc_count": server_response.get("doc_count", 0),
        "doc_limit": server_response.get("doc_limit"),
        "remaining": server_response.get("remaining"),
        "pending_sync": pending,
        "validated_at": now,
        "cache_expires_at": (
            datetime.now(timezone.utc) + timedelta(days=_CACHE_TTL_DAYS)
        ).isoformat(),
    }
    _write_cache(cache)


def validate_offline(api_key: str) -> Optional[dict]:
    """Validate an API key from the local cache.

    Returns the cached plan info dict if the key matches and cache is valid.
    Returns None if no cache, wrong key, or cache expired.
    """
    cache = _read_cache()
    if cache is None:
        return None

    key_hash = _hash_key(api_key)
    if cache.get("key_hash") != key_hash:
        return None

    # Check cache expiry
    expires_str = cache.get("cache_expires_at", "")
    if not expires_str:
        return None
    try:
        expires = datetime.fromisoformat(expires_str)
        if expires <= datetime.now(timezone.utc):
            return None
    except ValueError:
        return None

    # Compute effective remaining from server_doc_count + pending_sync
    server_doc_count = cache.get("doc_count", 0)
    pending = cache.get("pending_sync", 0)
    doc_limit = cache.get("doc_limit")

    effective_count = server_doc_count + pending
    if doc_limit is not None and doc_limit > 0:
        remaining = max(0, doc_limit - effective_count)
    else:
        remaining = cache.get("remaining")

    return {
        "valid": True,
        "plan": cache.get("plan", ""),
        "scopes": cache.get("scopes", ""),
        "doc_count": effective_count,
        "doc_limit": doc_limit,
        "remaining": remaining,
        "offline": True,
    }


def record_usage_offline(api_key: str, doc_count: int = 1) -> dict:
    """Record document usage locally when offline.

    Increments the pending_sync counter and enforces quota locally.
    Returns a usage result dict with remaining count.

    Raises:
        RuntimeError: if no valid cache exists for this key.
        OverflowError: if the local quota would be exceeded.
    """
    cache = _read_cache()
    if cache is None or cache.get("key_hash") != _hash_key(api_key):
        raise RuntimeError("No valid offline license cache")

    server_doc_count = cache.get("doc_count", 0)
    pending = cache.get("pending_sync", 0)
    doc_limit = cache.get("doc_limit")

    effective_count = server_doc_count + pending

    # Enforce quota locally
    if doc_limit is not None and doc_limit > 0:
        if effective_count + doc_count > doc_limit:
            raise OverflowError(
                f"Monthly document quota exceeded ({doc_limit} docs/month). "
                f"Used: {effective_count}, requested: {doc_count}."
            )

    # Update pending_sync
    cache["pending_sync"] = pending + doc_count
    _write_cache(cache)

    new_count = effective_count + doc_count
    if doc_limit is not None and doc_limit > 0:
        remaining = max(0, doc_limit - new_count)
    else:
        remaining = None

    return {
        "ok": True,
        "doc_count": new_count,
        "doc_limit": doc_limit,
        "remaining": remaining,
        "offline": True,
    }


def get_pending_sync(api_key: str) -> int:
    """Return the number of documents pending sync to the server."""
    cache = _read_cache()
    if cache is None or cache.get("key_hash") != _hash_key(api_key):
        return 0
    return cache.get("pending_sync", 0)


def clear_pending_sync(api_key: str, server_response: dict) -> None:
    """Clear pending_sync after a successful online sync.

    Updates the cached doc_count/remaining from the server response.
    """
    cache = _read_cache()
    if cache is None or cache.get("key_hash") != _hash_key(api_key):
        return

    cache["pending_sync"] = 0
    cache["doc_count"] = server_response.get("doc_count", cache.get("doc_count", 0))
    doc_limit = server_response.get("doc_limit", cache.get("doc_limit"))
    cache["doc_limit"] = doc_limit
    if doc_limit is not None and doc_limit > 0:
        cache["remaining"] = max(0, doc_limit - cache["doc_count"])
    else:
        cache["remaining"] = server_response.get("remaining")
    _write_cache(cache)
