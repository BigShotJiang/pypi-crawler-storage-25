"""Pydantic data models for promptShield."""

from __future__ import annotations

import enum
import uuid
from datetime import datetime, timezone
from typing import Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class PIIType(str, enum.Enum):
    """Categories of personally identifiable information."""
    PERSON = "PERSON"
    ORG = "ORG"
    EMAIL = "EMAIL"
    PHONE = "PHONE"
    SSN = "SSN"
    CREDIT_CARD = "CREDIT_CARD"
    DATE = "DATE"
    ADDRESS = "ADDRESS"
    LOCATION = "LOCATION"
    IP_ADDRESS = "IP_ADDRESS"
    IBAN = "IBAN"
    PASSPORT = "PASSPORT"
    DRIVER_LICENSE = "DRIVER_LICENSE"
    CUSTOM = "CUSTOM"
    UNKNOWN = "UNKNOWN"


class DetectionSource(str, enum.Enum):
    """Which detection layer produced the match."""
    REGEX = "REGEX"
    NER = "NER"
    GLINER = "GLINER"
    LLM = "LLM"
    MANUAL = "MANUAL"


class RegionAction(str, enum.Enum):
    """What the user decided to do with a detected region."""
    PENDING = "PENDING"       # Awaiting user decision
    CANCEL = "CANCEL"         # Dismiss highlight, keep content
    REMOVE = "REMOVE"         # Permanently redact
    TOKENIZE = "TOKENIZE"     # Replace with reversible token


class DocumentStatus(str, enum.Enum):
    UPLOADING = "UPLOADING"
    PROCESSING = "PROCESSING"
    EXTRACTED = "EXTRACTED"
    DETECTING = "DETECTING"
    REVIEWING = "REVIEWING"
    ANONYMIZING = "ANONYMIZING"
    COMPLETED = "COMPLETED"
    ERROR = "ERROR"


# ---------------------------------------------------------------------------
# Geometry
# ---------------------------------------------------------------------------

class BBox(BaseModel):
    """Bounding box in page coordinates (points from top-left)."""
    x0: float
    y0: float
    x1: float
    y1: float

    @property
    def width(self) -> float:
        return self.x1 - self.x0

    @property
    def height(self) -> float:
        return self.y1 - self.y0


# ---------------------------------------------------------------------------
# Text extraction
# ---------------------------------------------------------------------------

class TextBlock(BaseModel):
    """A block of text with its spatial position on the page."""
    text: str
    bbox: BBox
    confidence: float = 1.0          # 1.0 for native PDF text, <1 for OCR
    block_index: int = 0
    line_index: int = 0
    word_index: int = 0
    is_ocr: bool = False
    is_bold: bool = False            # True when font weight ≥ 700
    is_italic: bool = False           # True when font has italic flag
    font_size: float = 0.0           # Font size in points (0 = unknown)
    font_family: str = ""            # Raw font family name from PDF


class PageData(BaseModel):
    """Extracted data for a single document page."""
    page_number: int
    width: float                      # Page width in points
    height: float                     # Page height in points
    bitmap_path: str                  # Path to rendered bitmap file
    text_blocks: list[TextBlock] = []
    full_text: str = ""               # Concatenated text of all blocks


# ---------------------------------------------------------------------------
# PII Detection
# ---------------------------------------------------------------------------

class PIIRegion(BaseModel):
    """A detected PII region on a document page."""
    # L2: Use 16 hex chars (64 bits) instead of 12 (48 bits) for better collision resistance
    id: str = Field(default_factory=lambda: uuid.uuid4().hex[:16])
    page_number: int
    bbox: BBox
    text: str
    pii_type: str  # PIIType enum value or user-defined custom label
    confidence: float                  # 0.0 – 1.0
    source: DetectionSource
    char_start: int = 0
    char_end: int = 0
    action: RegionAction = RegionAction.PENDING
    linked_group: str | None = None    # shared ID linking multi-line sibling regions
    original_text: str | None = None   # text as it appears in the document file; set when user edits region.text


# ---------------------------------------------------------------------------
# Token / Vault
# ---------------------------------------------------------------------------

class TokenMapping(BaseModel):
    """Maps an anonymization token to its original content."""
    token_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    token_string: str                  # e.g. [ANON_PERSON_A3F2B1]
    original_text: str
    pii_type: str  # PIIType enum value or user-defined custom label
    source_document: str = ""
    context_snippet: str = ""          # Surrounding text for disambiguation
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# Document
# ---------------------------------------------------------------------------

class DocumentInfo(BaseModel):
    """Metadata for an uploaded document."""
    doc_id: str = Field(default_factory=lambda: uuid.uuid4().hex[:12])
    original_filename: str = Field(max_length=1024)
    file_path: str = Field(max_length=4096)
    mime_type: str = Field(default="", max_length=256)
    page_count: int = 0
    status: DocumentStatus = DocumentStatus.UPLOADING
    pages: list[PageData] = []
    regions: list[PIIRegion] = []
    excluded_pages: list[int] = []      # pages excluded from export (1-indexed)
    group_id: str | None = None        # linked-document group for token consistency
    group_name: str | None = None      # user-defined name for the link group
    content_hash: str | None = None    # SHA-256 of original file for region cache
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# API Request / Response schemas
# ---------------------------------------------------------------------------

class UploadResponse(BaseModel):
    doc_id: str
    filename: str
    page_count: int
    status: DocumentStatus


class DetectionProgress(BaseModel):
    doc_id: str
    page_number: int
    total_pages: int
    layer: str                         # "REGEX", "NER", "LLM"
    regions_found: int


class RegionActionRequest(BaseModel):
    region_id: str
    action: RegionAction


class BatchActionRequest(BaseModel):
    region_ids: list[str]
    action: RegionAction


class MergeRegionsRequest(BaseModel):
    region_ids: list[str]


class GroupRegionsRequest(BaseModel):
    region_ids: list[str]


class RegionSyncItem(BaseModel):
    """Minimal region state sent from the frontend before anonymize."""
    id: str
    action: RegionAction
    bbox: BBox


class AnonymizeRequest(BaseModel):
    doc_id: str
    output_format: str = "pdf"         # "pdf" or "text" or "both"


class AnonymizeResponse(BaseModel):
    doc_id: str
    output_path: Optional[str] = None
    output_text_path: Optional[str] = None
    tokens_created: int = 0
    regions_removed: int = 0


MAX_PASTE_CHARS = 500_000


class DetokenizeRequest(BaseModel):
    text: str = Field(..., max_length=MAX_PASTE_CHARS)


class DetokenizeReplacement(BaseModel):
    token: str
    original: str
    pii_type: str


class DetokenizeResponse(BaseModel):
    original_text: str
    tokens_replaced: int
    unresolved_tokens: list[str] = []
    replacements: list[DetokenizeReplacement] = []


class LLMStatusResponse(BaseModel):
    loaded: bool
    model_name: str = ""
    model_path: str = ""
    gpu_enabled: bool = False
    context_size: int = 0
    provider: str = "local"                  # "local" | "remote"
    remote_api_url: str = ""
    remote_model: str = ""


class VaultStatsResponse(BaseModel):
    total_tokens: int
    total_documents: int
    vault_size_bytes: int


class PIILabelEntry(BaseModel):
    """Configuration for a single PII label in the type picker."""
    label: str
    frequent: bool = False
    hidden: bool = False
    user_added: bool = False
    color: str = "#888"


# ---------------------------------------------------------------------------
# Document List Response (Paginated)
# ---------------------------------------------------------------------------

class DocumentListItem(BaseModel):
    """Summary of a document for list views."""
    doc_id: str
    original_filename: str = Field(max_length=1024)
    filename: str = Field(max_length=1024)
    file_path: str = Field(max_length=4096)
    mime_type: str = Field(max_length=256)
    page_count: int
    status: DocumentStatus
    regions_count: int
    is_protected: bool
    cancelled_count: int = 0
    excluded_pages_count: int = 0
    group_id: str | None = None
    group_name: str | None = None
    created_at: datetime


class PaginatedDocumentList(BaseModel):
    """Paginated list of documents."""
    items: list[DocumentListItem]
    total: int
    page: int
    limit: int
    pages: int


# ---------------------------------------------------------------------------
# Additional Typed API Responses
# ---------------------------------------------------------------------------

class StatusResponse(BaseModel):
    """Generic status response."""
    status: str
    message: str = ""


class VaultUnlockResponse(BaseModel):
    """Response from vault unlock."""
    status: str  # "ok" | "error"
    message: str = ""


class VaultStatusResponse(BaseModel):
    """Response from vault status check."""
    unlocked: bool


class DetectionProgressResponse(BaseModel):
    """Progress of PII detection."""
    doc_id: str
    status: str  # "idle" | "running" | "completed" | "error"
    current_page: int = 0
    total_pages: int = 0
    phase: str = ""  # "regex" | "ner" | "llm" | "merging"
    regions_found: int = 0
    error: Optional[str] = None


class ExportProgressResponse(BaseModel):
    """Progress of document export/anonymization."""
    export_id: str
    status: str  # "processing" | "completed" | "error"
    phase: str = ""
    current_page: int = 0
    total_pages: int = 0
    output_path: Optional[str] = None
    output_text_path: Optional[str] = None
    tokens_created: int = 0
    error: Optional[str] = None


class RegionSyncResponse(BaseModel):
    """Response from region sync operation."""
    status: str
    synced: int


class LLMModelInfo(BaseModel):
    """Information about an available LLM model."""
    name: str
    path: str
    size_bytes: int
    size_human: str


class RemoteLLMTestResponse(BaseModel):
    """Response from remote LLM connection test."""
    status: str  # "ok" | "error"
    message: str = ""
    model: str = ""
    latency_ms: float = 0


class DetectionSettingsResponse(BaseModel):
    """Current detection settings."""
    confidence_threshold: float
    use_llm: bool
    llm_provider: str
    enabled_types: list[str]
    disabled_types: list[str]


class ResetDetectionResponse(BaseModel):
    """Response from reset detection."""
    status: str
    regions_removed: int
