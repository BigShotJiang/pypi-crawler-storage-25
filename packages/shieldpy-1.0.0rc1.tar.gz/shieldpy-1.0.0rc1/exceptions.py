"""PromptShield exception hierarchy for SDK and CLI consumers."""

from __future__ import annotations


class PromptShieldError(Exception):
    """Base exception for all PromptShield errors."""


class AuthenticationError(PromptShieldError):
    """API key is invalid, revoked, or expired."""


class QuotaExceededError(PromptShieldError):
    """Monthly document processing quota exceeded."""


class PlanRequiredError(PromptShieldError):
    """Current plan does not include the requested feature."""


class ModelNotFoundError(PromptShieldError):
    """A required ML model (spaCy, GLiNER, etc.) is not installed."""


class TesseractNotFoundError(PromptShieldError):
    """Tesseract OCR is not installed or not on PATH."""


class FileFormatError(PromptShieldError):
    """Input file format is unsupported or corrupted."""
