"""
PromptShield CLI — local command-line interface for document anonymization.

Usage:
    promptshield detect     <input> [options]
    promptshield anonymize  <input> -o <output> [options]
    promptshield detokenize <input> -o <output> [options]
    promptshield serve      [options]
    promptshield doctor
    promptshield --version

All processing happens locally. No data ever leaves your machine.
Requires a valid API key (Business or Enterprise plan).
"""

from __future__ import annotations

import argparse
import asyncio
import glob
import json
import os
import sys
import time
from pathlib import Path

# ── Exit codes ──────────────────────────────────────────────────────────────
EXIT_OK = 0
EXIT_GENERAL = 1
EXIT_AUTH = 2
EXIT_QUOTA = 3
EXIT_MODEL = 4
EXIT_FILE = 5

_LICENSING_URL = os.environ.get("PS_LICENSING_URL", "https://api.promptshield.ca")
_API_KEY_ENV = "PROMPTSHIELD_API_KEY"

# Global flags set by argument parsing
_quiet = False
_json_output = False


def _get_version() -> str:
    """Read version from importlib.metadata (installed) or fallback."""
    try:
        from importlib.metadata import version
        return version("promptshield")
    except Exception:
        return "1.0.0-rc.1"


def _log(msg: str, **kwargs) -> None:
    """Print to stderr unless --quiet."""
    if not _quiet:
        print(msg, file=sys.stderr, **kwargs)


def _get_api_key(args: argparse.Namespace) -> str:
    """Get API key from --api-key flag or PROMPTSHIELD_API_KEY env var."""
    key = getattr(args, "api_key", None) or os.environ.get(_API_KEY_ENV, "")
    if not key:
        _log(
            "Error: API key required. Provide via --api-key flag or "
            f"set the {_API_KEY_ENV} environment variable.\n"
            "Generate an API key at https://promptshield.ca/developers/api-keys",
        )
        sys.exit(EXIT_AUTH)
    return key


def _validate_api_key(api_key: str) -> dict:
    """Validate the API key — online first, falls back to offline cache.

    Online:  POST to licensing server → cache result → sync pending usage.
    Offline: validate from local cache (valid for 35 days after last check).
    """
    import urllib.request
    import urllib.error
    from license_cache import (
        cache_validation,
        validate_offline,
        get_pending_sync,
        clear_pending_sync,
    )

    url = f"{_LICENSING_URL}/api-keys/validate"
    data = json.dumps({"api_key": api_key}).encode()
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())

        # Cache successful validation for offline use
        cache_validation(api_key, result)

        # Sync any pending offline usage
        _sync_pending_usage(api_key)

        return result

    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        try:
            detail = json.loads(body).get("detail", body)
        except Exception:
            detail = body
        _log(f"Error: License validation failed — {detail}")
        sys.exit(EXIT_AUTH)

    except urllib.error.URLError:
        # Server unreachable — try offline validation
        cached = validate_offline(api_key)
        if cached:
            _log("  Using cached license (offline mode).")
            return cached

        _log(
            f"Error: Could not reach licensing server at {_LICENSING_URL}\n"
            "No valid cached license found. Connect to the internet at least\n"
            "once to cache your license for offline use.",
        )
        sys.exit(EXIT_AUTH)


def _check_scope(validation: dict, required_scope: str) -> None:
    """Ensure the API key has the required scope (detect/anonymize/detokenize).

    If scopes is empty or None, all scopes are allowed (backwards compat).
    """
    scopes_raw = validation.get("scopes") or ""
    if not scopes_raw:
        return  # unrestricted key
    allowed = {s.strip() for s in scopes_raw.split(",") if s.strip()}
    if required_scope not in allowed:
        _log(
            f"Error: your API key does not have the '{required_scope}' scope.\n"
            f"Allowed scopes: {', '.join(sorted(allowed))}\n"
            "Generate a new key with the required scope at "
            "https://promptshield.ca/developers/api-keys"
        )
        sys.exit(EXIT_AUTH)


def _sync_pending_usage(api_key: str) -> None:
    """Sync any pending offline usage to the licensing server (best-effort)."""
    import urllib.request
    import urllib.error
    from license_cache import get_pending_sync, clear_pending_sync

    pending = get_pending_sync(api_key)
    if pending <= 0:
        return

    url = f"{_LICENSING_URL}/usage/record"
    data = json.dumps({"api_key": api_key, "doc_count": pending}).encode()
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
        clear_pending_sync(api_key, result)
        _log(f"  Synced {pending} offline document(s) to server.")
    except Exception:
        pass  # sync failure is non-fatal; will retry next time online


def _record_usage(api_key: str, doc_count: int = 1) -> None:
    """Report document processing usage — online first, falls back to offline."""
    import urllib.request
    import urllib.error
    from license_cache import record_usage_offline, clear_pending_sync

    url = f"{_LICENSING_URL}/usage/record"
    data = json.dumps({"api_key": api_key, "doc_count": doc_count}).encode()
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read())
            # Update local cache with server state
            clear_pending_sync(api_key, result)
            remaining = result.get("remaining")
            if remaining is not None and remaining < 50:
                _log(f"  Note: {remaining} documents remaining in your monthly quota.")
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        try:
            detail = json.loads(body).get("detail", body)
        except Exception:
            detail = body
        if e.code == 429:
            _log(f"Error: Monthly document quota exceeded — {detail}")
            sys.exit(EXIT_QUOTA)
        # Non-fatal for other errors — log but continue
        _log(f"  Warning: Usage recording failed — {detail}")
    except (urllib.error.URLError, OSError):
        # Offline — record locally
        try:
            result = record_usage_offline(api_key, doc_count)
            remaining = result.get("remaining")
            if remaining is not None and remaining < 50:
                _log(f"  Note: {remaining} documents remaining (offline quota).")
        except OverflowError as e:
            _log(f"Error: {e}")
            sys.exit(EXIT_QUOTA)
        except RuntimeError:
            # No cache — non-fatal, just warn
            _log("  Warning: Usage recording failed — no offline cache.")
    except Exception:
        pass  # usage recording failure is non-fatal


def _ensure_core_imports():
    """Lazy-import heavy core modules only when needed."""
    # Add src-python to path if running from repo root
    here = Path(__file__).resolve().parent
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))


# ── Input file resolution (supports globs + directories) ────────────────────

def _resolve_inputs(raw_input: str, recursive: bool = False) -> list[Path]:
    """Expand a raw input argument to a list of resolved file paths.

    Supports:
      - Single file path
      - Glob patterns (*.pdf, docs/*.docx)
      - Directory (all supported files inside)
      - Recursive directory with --recursive
    """
    _SUPPORTED_EXTS = {
        ".pdf", ".docx", ".doc", ".xlsx", ".xls", ".pptx",
        ".txt", ".csv", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp",
    }

    path = Path(raw_input)

    # 1. Exact file
    if path.is_file():
        return [path.resolve()]

    # 2. Directory
    if path.is_dir():
        pattern = "**/*" if recursive else "*"
        files = sorted(
            f.resolve()
            for f in path.glob(pattern)
            if f.is_file() and f.suffix.lower() in _SUPPORTED_EXTS
        )
        if not files:
            _log(f"Error: no supported files found in {path}")
            sys.exit(EXIT_FILE)
        return files

    # 3. Glob pattern
    matches = sorted(Path(p).resolve() for p in glob.glob(raw_input, recursive=recursive))
    matches = [m for m in matches if m.is_file()]
    if not matches:
        _log(f"Error: no files matched: {raw_input}")
        sys.exit(EXIT_FILE)
    return matches


# ── Detect command ──────────────────────────────────────────────────────────

async def _cmd_detect(args: argparse.Namespace) -> None:
    api_key = _get_api_key(args)
    result = _validate_api_key(api_key)
    _check_scope(result, "detect")

    _ensure_core_imports()
    from core.ingestion.loader import ingest_document
    from core.detection.pipeline import detect_pii_on_page
    from core.detection.propagation import propagate_regions_across_pages

    files = _resolve_inputs(args.input, getattr(args, "recursive", False))
    all_results = []

    for file_idx, input_path in enumerate(files):
        if not input_path.exists():
            _log(f"Error: file not found: {input_path}")
            sys.exit(EXIT_FILE)

        if len(files) > 1:
            _log(f"\n[{file_idx + 1}/{len(files)}] {input_path.name}")
        else:
            _log(f"Ingesting {input_path.name}...")

        t0 = time.perf_counter()
        doc = await ingest_document(input_path, input_path.name)

        all_regions: list[list] = []
        for i, page in enumerate(doc.pages):
            _log(f"  Detecting PII on page {i + 1}/{len(doc.pages)}...")
            regions = detect_pii_on_page(page)
            all_regions.append(regions)

        propagate_regions_across_pages(doc.pages, all_regions)
        elapsed_ms = int((time.perf_counter() - t0) * 1000)

        total = sum(len(r) for r in all_regions)
        _log(f"  Detected {total} PII region(s) across {len(doc.pages)} page(s) in {elapsed_ms}ms.")

        file_result = {
            "file": input_path.name,
            "pages": len(doc.pages),
            "total_regions": total,
            "duration_ms": elapsed_ms,
            "regions_per_page": [
                {
                    "page": i + 1,
                    "count": len(regions),
                    "entities": [
                        {
                            "type": r.pii_type if isinstance(r.pii_type, str) else r.pii_type.value,
                            "text": r.text,
                            "confidence": round(r.confidence, 3) if hasattr(r, "confidence") else None,
                        }
                        for r in regions
                    ],
                }
                for i, regions in enumerate(all_regions)
            ],
        }
        all_results.append(file_result)

    # Output
    if _json_output:
        output = all_results if len(all_results) > 1 else all_results[0]
        print(json.dumps(output, indent=2, ensure_ascii=False))
    elif args.output:
        output = all_results if len(all_results) > 1 else all_results[0]
        out = Path(args.output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(output, indent=2, ensure_ascii=False), encoding="utf-8")
        _log(f"Detection report saved to {out}")
    elif not _quiet:
        for result in all_results:
            for page in result["regions_per_page"]:
                if page["entities"]:
                    print(f"\n  Page {page['page']}:")
                    for e in page["entities"]:
                        score = f" ({e['confidence']:.0%})" if e.get("confidence") else ""
                        print(f"    [{e['type']}] {e['text']!r}{score}")


# ── Anonymize command ───────────────────────────────────────────────────────

async def _cmd_anonymize(args: argparse.Namespace) -> None:
    api_key = _get_api_key(args)
    result = _validate_api_key(api_key)
    _check_scope(result, "anonymize")

    _ensure_core_imports()
    from core.ingestion.loader import ingest_document
    from core.detection.pipeline import detect_pii_on_page
    from core.detection.propagation import propagate_regions_across_pages
    from core.anonymizer.engine import anonymize_document
    from models.schemas import RegionAction

    files = _resolve_inputs(args.input, getattr(args, "recursive", False))
    output_path = Path(args.output).resolve()

    # For batch: output must be a directory
    if len(files) > 1:
        output_path.mkdir(parents=True, exist_ok=True)

    all_results = []

    for file_idx, input_path in enumerate(files):
        if not input_path.exists():
            _log(f"Error: file not found: {input_path}")
            sys.exit(EXIT_FILE)

        if len(files) > 1:
            out_file = output_path / input_path.name
            _log(f"\n[{file_idx + 1}/{len(files)}] {input_path.name}")
        else:
            out_file = output_path
            _log(f"Ingesting {input_path.name}...")

        t0 = time.perf_counter()
        doc = await ingest_document(input_path, input_path.name)

        all_regions: list[list] = []
        for i, page in enumerate(doc.pages):
            _log(f"  Detecting PII on page {i + 1}/{len(doc.pages)}...")
            regions = detect_pii_on_page(page)
            all_regions.append(regions)

        propagate_regions_across_pages(doc.pages, all_regions)

        total = sum(len(r) for r in all_regions)
        _log(f"  Found {total} PII region(s). Anonymizing...")

        # Accept all detections as TOKENIZE by default
        flat = [r for page_regions in all_regions for r in page_regions]
        for r in flat:
            if hasattr(r, "action"):
                r.action = RegionAction.TOKENIZE
        doc.regions = flat

        result = await anonymize_document(doc)

        out_file.parent.mkdir(parents=True, exist_ok=True)
        if hasattr(result, "data") and result.data:
            out_file.write_bytes(result.data)
        elif hasattr(result, "path") and result.path:
            import shutil
            shutil.copy2(result.path, out_file)

        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        _log(f"  Saved to {out_file} ({elapsed_ms}ms)")
        _record_usage(api_key)

        all_results.append({
            "input": str(input_path),
            "output": str(out_file),
            "regions": total,
            "duration_ms": elapsed_ms,
        })

    if _json_output:
        output = all_results if len(all_results) > 1 else all_results[0]
        print(json.dumps(output, indent=2, ensure_ascii=False))


# ── Detokenize command ──────────────────────────────────────────────────────

async def _cmd_detokenize(args: argparse.Namespace) -> None:
    api_key = _get_api_key(args)
    result = _validate_api_key(api_key)
    _check_scope(result, "detokenize")

    _ensure_core_imports()
    from core.detokenize_file import detokenize_file
    from core.vault.store import vault

    files = _resolve_inputs(args.input, getattr(args, "recursive", False))
    output_path = Path(args.output).resolve()

    if len(files) > 1:
        output_path.mkdir(parents=True, exist_ok=True)

    all_results = []

    for file_idx, input_path in enumerate(files):
        if not input_path.exists():
            _log(f"Error: file not found: {input_path}")
            sys.exit(EXIT_FILE)

        if len(files) > 1:
            out_file = output_path / input_path.name
            _log(f"\n[{file_idx + 1}/{len(files)}] {input_path.name}")
        else:
            out_file = output_path
            _log(f"Detokenizing {input_path.name}...")

        t0 = time.perf_counter()
        file_data = input_path.read_bytes()
        output_bytes, output_filename, tokens_replaced, unresolved, replacements = \
            detokenize_file(file_data, input_path.name, vault)

        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_bytes(output_bytes)
        elapsed_ms = int((time.perf_counter() - t0) * 1000)

        _log(f"  Saved to {out_file} ({tokens_replaced} tokens replaced, {elapsed_ms}ms)")
        if unresolved:
            _log(f"  Warning: {len(unresolved)} unresolved token(s)")

        all_results.append({
            "input": str(input_path),
            "output": str(out_file),
            "tokens_replaced": tokens_replaced,
            "unresolved": len(unresolved),
            "duration_ms": elapsed_ms,
        })

    if _json_output:
        output = all_results if len(all_results) > 1 else all_results[0]
        print(json.dumps(output, indent=2, ensure_ascii=False))


# ── Serve command ───────────────────────────────────────────────────────────

def _cmd_serve(args: argparse.Namespace) -> None:
    api_key = _get_api_key(args)
    result = _validate_api_key(api_key)

    _ensure_core_imports()
    import uvicorn

    host = args.host or "127.0.0.1"
    port = args.port or 8000
    workers = getattr(args, "workers", 1) or 1

    # Pass API key and scopes to the server process via environment
    os.environ[_API_KEY_ENV] = api_key
    scopes_raw = result.get("scopes") or ""
    if scopes_raw:
        os.environ["PROMPTSHIELD_API_KEY_SCOPES"] = scopes_raw

    _log(f"Starting PromptShield API server on {host}:{port}")
    _log(f"API docs available at http://{host}:{port}/docs")

    uvicorn.run(
        "api.server:app",
        host=host,
        port=port,
        workers=workers,
        log_level=os.environ.get("LOG_LEVEL", "info").lower(),
    )


# ── Doctor command ──────────────────────────────────────────────────────────

def _cmd_doctor(args: argparse.Namespace) -> None:
    """Check system prerequisites and report status."""
    import shutil

    print(f"PromptShield {_get_version()}")
    print(f"Python {sys.version}")
    print()

    ok_count = 0
    warn_count = 0

    def _check(name: str, fn) -> bool:
        nonlocal ok_count, warn_count
        try:
            result = fn()
            if result:
                print(f"  \u2713  {name}")
                ok_count += 1
                return True
            else:
                print(f"  \u2717  {name}")
                warn_count += 1
                return False
        except Exception as e:
            print(f"  \u2717  {name} — {e}")
            warn_count += 1
            return False

    # Tesseract
    def _check_tesseract():
        return shutil.which("tesseract") is not None
    _check("Tesseract OCR", _check_tesseract)

    # spaCy English model
    def _check_spacy_en():
        import spacy
        spacy.load("en_core_web_sm")
        return True
    _check("spaCy English model (en_core_web_sm)", _check_spacy_en)

    # spaCy French model
    def _check_spacy_fr():
        import spacy
        spacy.load("fr_core_news_sm")
        return True
    _check("spaCy French model (fr_core_news_sm)", _check_spacy_fr)

    # GLiNER model
    def _check_gliner():
        try:
            from gliner import GLiNER  # noqa: F401
            return True
        except ImportError:
            return False
    _check("GLiNER library", _check_gliner)

    # PyMuPDF
    def _check_pymupdf():
        import fitz  # noqa: F401
        return True
    _check("PyMuPDF (fitz)", _check_pymupdf)

    # torch
    def _check_torch():
        import torch
        return True
    gpu_label = "PyTorch"
    try:
        import torch
        if torch.cuda.is_available():
            gpu_label = f"PyTorch (CUDA {torch.version.cuda})"
        elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
            gpu_label = "PyTorch (MPS)"
    except Exception:
        pass
    _check(gpu_label, _check_torch)

    # Office formats
    def _check_office():
        import docx, openpyxl, pptx  # noqa: F401
        return True
    _check("Office formats (docx/xlsx/pptx)", _check_office)

    # API key
    api_key = os.environ.get(_API_KEY_ENV, "")
    if api_key:
        print()
        try:
            result = _validate_api_key(api_key)
            plan = result.get("plan", "unknown")
            remaining = result.get("remaining", "unlimited")
            print(f"  \u2713  API key valid — plan: {plan}, remaining: {remaining}")
            ok_count += 1
        except SystemExit:
            print(f"  \u2717  API key validation failed")
            warn_count += 1
    else:
        print(f"\n  -  {_API_KEY_ENV} not set (skip license check)")

    print(f"\n{ok_count} passed, {warn_count} issue(s)")
    if warn_count:
        print("\nTo fix missing models:")
        print("  python -m spacy download en_core_web_sm")
        print("  python -m spacy download fr_core_news_sm")
        print("\nTo install Tesseract: https://github.com/tesseract-ocr/tesseract")


# ── Main entry point ───────────────────────────────────────────────────────

def main() -> None:
    global _quiet, _json_output

    parser = argparse.ArgumentParser(
        prog="promptshield",
        description="PromptShield — AI-powered document anonymization. "
                    "All processing happens locally on your machine.",
    )
    parser.add_argument(
        "-V", "--version", action="version",
        version=f"promptshield {_get_version()}",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # ── Shared arguments ────────────────────────────────────────────────
    _common = argparse.ArgumentParser(add_help=False)
    _common.add_argument("--api-key", help="PromptShield API key (or set PROMPTSHIELD_API_KEY)")
    _common.add_argument("--json", action="store_true", dest="json_output", help="Output results as JSON to stdout")
    _common.add_argument("-q", "--quiet", action="store_true", help="Suppress progress output")
    _common.add_argument("-r", "--recursive", action="store_true", help="Recurse into subdirectories")

    # detect
    p_detect = sub.add_parser("detect", parents=[_common], help="Detect PII in document(s)")
    p_detect.add_argument("input", help="File, directory, or glob pattern")
    p_detect.add_argument("-o", "--output", help="Save detection report as JSON file")

    # anonymize
    p_anon = sub.add_parser("anonymize", parents=[_common], help="Detect and anonymize document(s)")
    p_anon.add_argument("input", help="File, directory, or glob pattern")
    p_anon.add_argument("-o", "--output", required=True, help="Output file or directory")

    # detokenize
    p_detok = sub.add_parser("detokenize", parents=[_common], help="Restore tokens in document(s)")
    p_detok.add_argument("input", help="File, directory, or glob pattern")
    p_detok.add_argument("-o", "--output", required=True, help="Output file or directory")

    # serve
    p_serve = sub.add_parser("serve", help="Start the API server for self-hosted use")
    p_serve.add_argument("--host", default="127.0.0.1", help="Bind host (default: 127.0.0.1)")
    p_serve.add_argument("--port", type=int, default=8000, help="Bind port (default: 8000)")
    p_serve.add_argument("--workers", type=int, default=1, help="Number of worker processes (default: 1)")
    p_serve.add_argument("--api-key", help="PromptShield API key (or set PROMPTSHIELD_API_KEY)")

    # doctor
    sub.add_parser("doctor", help="Check system prerequisites and model availability")

    args = parser.parse_args()

    # Apply global flags
    _quiet = getattr(args, "quiet", False)
    _json_output = getattr(args, "json_output", False)
    if _json_output:
        _quiet = True  # --json implies --quiet (no progress mixed with JSON)

    if args.command == "doctor":
        _cmd_doctor(args)
    elif args.command == "serve":
        _cmd_serve(args)
    elif args.command == "detect":
        asyncio.run(_cmd_detect(args))
    elif args.command == "anonymize":
        asyncio.run(_cmd_anonymize(args))
    elif args.command == "detokenize":
        asyncio.run(_cmd_detokenize(args))


if __name__ == "__main__":
    main()
