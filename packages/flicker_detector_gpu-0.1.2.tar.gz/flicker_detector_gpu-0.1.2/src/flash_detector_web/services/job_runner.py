"""Prepare uploads, run gpu-flicker-detector (or configured exe), parse JSON, update DB."""

from __future__ import annotations

import asyncio
import json
import math
import shutil
import time
import uuid
from collections import Counter
from pathlib import Path
from typing import Any

from .. import config, db
from ..utils import natural_sort


def _flatten_upload_relative_path(name: str) -> str | None:
    """Turn multipart filename (possibly `subdir/a.png` from folder upload) into a single flat basename."""
    name = name.replace("\\", "/").strip().lstrip("/")
    if not name:
        return None
    parts = [p for p in name.split("/") if p not in ("", ".")]
    if not parts or any(p == ".." for p in parts):
        return None
    flat = "__".join(parts)
    for ch in '<>:"|?*':
        flat = flat.replace(ch, "_")
    flat = flat.strip(". ")
    if not flat:
        return None
    if len(flat) > 220:
        pth = Path(flat)
        flat = pth.stem[:180] + pth.suffix
    return flat


def _allocate_unique_name(flat: str, taken: set[str]) -> str:
    if flat not in taken:
        taken.add(flat)
        return flat
    pth = Path(flat)
    stem, suf = pth.stem, pth.suffix
    i = 2
    while True:
        cand = f"{stem}__dup{i}{suf}"
        if cand not in taken:
            taken.add(cand)
            return cand
        i += 1


def job_root(job_id: str) -> Path:
    return config.uploads_dir() / job_id


def _read_detect_threshold(root: Path) -> float | None:
    jp = root / "job.json"
    if not jp.is_file():
        return None
    try:
        meta = json.loads(jp.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    v = meta.get("detect_threshold")
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        f = float(v)
        return f if math.isfinite(f) and f >= 0 else None
    return None


async def prepare_and_queue(
    *,
    input_kind: str,
    client_ip: str | None,
    files: list[tuple[str, bytes]],
    detect_threshold: float | None = None,
) -> str:
    """Create job folder, materialize inputs, insert DB row. Does not run detector."""
    job_id = str(uuid.uuid4())
    root = job_root(job_id)
    root.mkdir(parents=True, exist_ok=True)
    frames_dir = root / "frames"
    manifest: dict[str, Any] = {"kind": input_kind, "frames": []}
    video_rel: str | None = None
    frame_count = 0

    if input_kind == "video":
        if len(files) != 1:
            raise ValueError("video mode requires exactly one file")
        name, data = files[0]
        base = Path(name).name
        if not natural_sort.is_video_file(Path(base)):
            raise ValueError("video mode requires a video file (.mp4, .webm, .mov, .mkv, .avi, .m4v)")
        ext = Path(name).suffix or ".mp4"
        dest = root / f"input{ext}"
        dest.write_bytes(data)
        video_rel = dest.name
        manifest["kind"] = "video"
        manifest["video_rel"] = video_rel
        frame_count = 0

    elif input_kind in ("dir_files", "images", "dir_folder"):
        frames_dir.mkdir(parents=True, exist_ok=True)
        taken: set[str] = set()
        for name, data in files:
            flat = _flatten_upload_relative_path(name)
            if flat is None:
                raise ValueError("invalid or unsafe upload path")
            if not natural_sort.is_image_file(Path(flat)):
                raise ValueError(f"not an image file: {name}")
            disk_name = _allocate_unique_name(flat, taken)
            (frames_dir / disk_name).write_bytes(data)
        imgs = [p for p in frames_dir.iterdir() if p.is_file() and natural_sort.is_image_file(p)]
        imgs = natural_sort.sort_image_paths(imgs)
        frame_count = len(imgs)
        manifest["frames"] = [
            {
                "rel": str(Path("frames") / p.name),
                "index": i,
                "time_ms": natural_sort.stem_leading_int(p.stem),
            }
            for i, p in enumerate(imgs)
        ]

    else:
        raise ValueError(f"unknown input_kind {input_kind}")

    if input_kind != "video" and frame_count < 4:
        shutil.rmtree(root, ignore_errors=True)
        raise ValueError("Need at least 4 image frames for GPU PredNet detection")

    if detect_threshold is not None:
        manifest["detect_threshold"] = float(detect_threshold)
    job_payload = {"id": job_id, "input_kind": input_kind, **manifest}
    (root / "job.json").write_text(json.dumps(job_payload, indent=2, ensure_ascii=False), encoding="utf-8")

    db.insert_job(
        job_id,
        client_ip,
        input_kind,
        manifest,
        video_rel,
        frame_count,
    )
    return job_id


def _cli_type_for_job(input_kind: str) -> str:
    if input_kind == "video":
        return "video"
    if input_kind in ("dir_files", "images"):
        return "sequence"
    if input_kind == "dir_folder":
        return "dir"
    # Legacy DB rows only.
    if input_kind == "image_pair":
        return "sequence"
    return "dir"


def _build_cmd(root: Path, input_kind: str) -> list[str]:
    try:
        prefix = config.resolve_detector_argv()
    except RuntimeError as e:
        raise RuntimeError(str(e)) from e
    if not prefix:
        raise RuntimeError("detector argv is empty")

    out_json = root / "result.json"
    t = _cli_type_for_job(input_kind)
    cmd = list(prefix) + ["--type", t, "--output", str(out_json)]
    if t != "video":
        cmd += ["--write-pred-frames", str((root / "pred_frames").resolve())]

    if t == "video":
        meta = json.loads((root / "job.json").read_text(encoding="utf-8"))
        rel = meta.get("video_rel") or "input.mp4"
        cmd += ["--input", str((root / rel).resolve())]
    elif t == "sequence":
        meta = json.loads((root / "job.json").read_text(encoding="utf-8"))
        frame_rows = list(meta.get("frames") or [])
        frame_rows.sort(key=lambda f: int(f.get("index", 0)))
        rels = [str(f["rel"]) for f in frame_rows if isinstance(f.get("rel"), str)]
        if len(rels) < 4:
            raise RuntimeError("sequence job needs at least 4 frames")
        for rel in rels:
            cmd += ["--input", str((root / rel).resolve())]
    else:
        cmd += ["--input", str((root / "frames").resolve())]

    thr_job = _read_detect_threshold(root)
    cmd.extend(config.detector_job_extra_argv(threshold_override=thr_job))
    return cmd


_job_slot = asyncio.Semaphore(max(1, config.max_concurrent_jobs()))


async def run_job(job_id: str) -> None:
    root = job_root(job_id)
    t0 = time.perf_counter()
    async with _job_slot:
        try:
            row = await asyncio.to_thread(db.get_job, job_id)
            if not row:
                return
            input_kind = str(row.get("input_kind") or "dir")

            await asyncio.to_thread(
                db.update_job_progress,
                job_id,
                status="running",
                progress=25.0,
                stage="prepare",
                indeterminate=False,
            )
            await asyncio.to_thread(
                db.update_job_progress,
                job_id,
                progress=40.0,
                stage="detect",
                indeterminate=True,
            )

            cmd = _build_cmd(root, input_kind)
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                cwd=str(root),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            timeout = max(1, config.detector_timeout_sec())
            try:
                out_b, err_b = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                raise RuntimeError(f"detector timed out after {timeout}s") from None

            if proc.returncode != 0:
                err = (err_b or b"").decode("utf-8", errors="replace").strip()
                out = (out_b or b"").decode("utf-8", errors="replace").strip()
                msg = err or out or f"exit {proc.returncode}"
                raise RuntimeError(msg)

            result_path = root / "result.json"
            if not result_path.is_file():
                raise RuntimeError("result.json missing after detector run")

            data = json.loads(result_path.read_text(encoding="utf-8"))
            findings = list(data.get("findings") or [])
            input_type_cli = str(data.get("input_type") or _cli_type_for_job(input_kind))
            counts: dict[str, int] = dict(Counter(str(f.get("flash_type") or "unknown") for f in findings))
            duration_ms = int((time.perf_counter() - t0) * 1000)

            if input_kind != "video":
                row_m = await asyncio.to_thread(db.get_job, job_id)
                manifest = dict(row_m.get("manifest") or {}) if row_m else {}
                pf = data.get("pred_frames")
                if isinstance(pf, list) and pf:
                    manifest["pred_frames"] = pf
                fs = data.get("frame_scores")
                if isinstance(fs, dict) and isinstance(fs.get("values"), list):
                    manifest["frame_scores"] = fs
                if (isinstance(pf, list) and pf) or (isinstance(fs, dict) and isinstance(fs.get("values"), list)):
                    job_json = root / "job.json"
                    if job_json.is_file():
                        try:
                            jp = json.loads(job_json.read_text(encoding="utf-8"))
                            if isinstance(jp, dict):
                                if isinstance(pf, list) and pf:
                                    jp["pred_frames"] = pf
                                if isinstance(fs, dict) and isinstance(fs.get("values"), list):
                                    jp["frame_scores"] = fs
                                job_json.write_text(json.dumps(jp, indent=2, ensure_ascii=False), encoding="utf-8")
                        except (json.JSONDecodeError, OSError):
                            pass
                    await asyncio.to_thread(db.update_job_manifest, job_id, manifest)

            await asyncio.to_thread(
                db.complete_job_success,
                job_id,
                input_type_cli=input_type_cli,
                findings=findings,
                counts=counts,
                duration_ms=duration_ms,
            )
        except Exception as e:  # noqa: BLE001
            duration_ms = int((time.perf_counter() - t0) * 1000)
            await asyncio.to_thread(db.complete_job_failure, job_id, str(e), duration_ms)
