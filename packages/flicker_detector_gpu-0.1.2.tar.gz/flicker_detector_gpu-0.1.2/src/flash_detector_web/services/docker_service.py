"""Start the stack with Docker Compose (GPU image) instead of local uvicorn."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path


def docker_available() -> bool:
    return shutil.which("docker") is not None


def compose_v2_ok() -> bool:
    if not docker_available():
        return False
    try:
        r = subprocess.run(
            ["docker", "compose", "version"],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
        return r.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False


def port_publish_spec(bind_host: str, host_port: int) -> str:
    """Value for ``FLICKER_DETECTOR_PORT_PUBLISH``; compose file uses ``${VAR}:8765``."""
    if bind_host in ("0.0.0.0", "::", "[::]"):
        return str(host_port)
    return f"{bind_host}:{host_port}"


def run_compose_up_foreground(compose_dir: Path, *, build: bool, port_publish: str) -> int:
    env = os.environ.copy()
    env["FLICKER_DETECTOR_PORT_PUBLISH"] = port_publish

    cmd = ["docker", "compose", "up"]
    if build:
        cmd.append("--build")

    print(f"docker compose cwd: {compose_dir}", file=sys.stderr)
    print(f"docker compose publish: {port_publish} -> container :8765", file=sys.stderr)

    try:
        proc = subprocess.run(cmd, cwd=str(compose_dir), env=env, check=False)
    except OSError as e:
        print(f"ERROR: failed to run docker compose: {e}", file=sys.stderr)
        return 1
    return int(proc.returncode)
