"""FastAPI application: REST API + optional static SPA."""

from __future__ import annotations

import asyncio
import math
import time
from typing import Any

from fastapi import FastAPI, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .. import config, db
from ..services import job_runner


def _client_ip(request: Request) -> str | None:
    if config.trust_proxy():
        xff = request.headers.get("x-forwarded-for")
        if xff:
            return xff.split(",")[0].strip()
    if request.client:
        return request.client.host
    return None


def _strip_opt(s: str | None) -> str | None:
    if s is None:
        return None
    t = s.strip()
    return t or None


def _report_detection_meta(manifest: Any) -> dict[str, Any]:
    """Threshold / metric / max score for report rows (manifest from DB)."""
    out: dict[str, Any] = {"detection_threshold": None, "frame_scores_max": None, "frame_scores_metric": None}
    if not isinstance(manifest, dict):
        return out
    fs = manifest.get("frame_scores")
    if isinstance(fs, dict):
        t = fs.get("threshold")
        if isinstance(t, (int, float)) and math.isfinite(float(t)):
            out["detection_threshold"] = float(t)
        mv = fs.get("max_value")
        if isinstance(mv, (int, float)) and math.isfinite(float(mv)):
            out["frame_scores_max"] = float(mv)
        m = fs.get("metric")
        if isinstance(m, str) and m.strip():
            out["frame_scores_metric"] = m.strip()
    if out["detection_threshold"] is None:
        dt = manifest.get("detect_threshold")
        if isinstance(dt, (int, float)) and math.isfinite(float(dt)):
            out["detection_threshold"] = float(dt)
    if out["frame_scores_metric"] is None:
        dm = manifest.get("detect_metric")
        if isinstance(dm, str) and dm.strip():
            out["frame_scores_metric"] = dm.strip()
    return out


def _allowed_rels(manifest: dict[str, Any] | None) -> set[str]:
    if not manifest:
        return set()
    out: set[str] = set()
    vr = manifest.get("video_rel")
    if isinstance(vr, str) and vr:
        out.add(vr.replace("\\", "/"))
    for fr in manifest.get("frames") or []:
        rel = fr.get("rel")
        if isinstance(rel, str) and rel:
            out.add(rel.replace("\\", "/"))
    for fr in manifest.get("pred_frames") or []:
        rel = fr.get("rel")
        if isinstance(rel, str) and rel:
            out.add(rel.replace("\\", "/"))
    return out


class FeedbackBody(BaseModel):
    correct: bool = Field(..., description="True if detection is correct, False if false positive")


def create_app() -> FastAPI:
    app = FastAPI(title="flicker-detector-web", version="0.1.0")

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.on_event("startup")
    def _startup() -> None:  # noqa: ANN202
        config.data_dir().mkdir(parents=True, exist_ok=True)
        config.uploads_dir().mkdir(parents=True, exist_ok=True)
        db.init_schema()

    @app.get("/api/health")
    def health() -> dict[str, Any]:
        try:
            argv = config.resolve_detector_argv()
        except RuntimeError as e:
            argv = []
            err = str(e)
        else:
            err = None
        exe = config.resolve_detector_exe()
        return {
            "ok": True,
            "detector_argv": argv,
            "detector_cmd": " ".join(argv) if argv else None,
            "detector_exe": str(exe) if exe else (argv[0] if argv else None),
            "detector_config_error": err,
            "data_dir": str(config.data_dir()),
        }

    @app.post("/api/jobs")
    async def create_job(
        request: Request,
        input_kind: str = Form(..., description="video|dir_files|dir_folder|images"),
        files: list[UploadFile] = File(default_factory=list),
        threshold: str | None = Form(
            default=None,
            description="Optional anomaly threshold (non-negative float); omit for server/env default",
        ),
    ) -> dict[str, str]:
        if input_kind not in ("video", "dir_files", "dir_folder", "images"):
            raise HTTPException(400, "invalid input_kind")
        max_bytes = max(1, config.max_upload_mb()) * 1024 * 1024
        pairs: list[tuple[str, bytes]] = []
        total = 0
        for uf in files:
            raw = await uf.read()
            total += len(raw)
            if total > max_bytes:
                raise HTTPException(413, "upload too large")
            name = uf.filename or "file"
            pairs.append((name, raw))

        ip = _client_ip(request)
        detect_threshold: float | None = None
        if threshold is not None and str(threshold).strip() != "":
            try:
                detect_threshold = float(str(threshold).strip())
            except ValueError as e:
                raise HTTPException(400, "invalid threshold") from e
            if not math.isfinite(detect_threshold) or detect_threshold < 0:
                raise HTTPException(400, "threshold must be a non-negative finite number")

        try:
            job_id = await job_runner.prepare_and_queue(
                input_kind=input_kind,
                client_ip=ip,
                files=pairs,
                detect_threshold=detect_threshold,
            )
        except ValueError as e:
            raise HTTPException(400, str(e)) from e

        asyncio.create_task(job_runner.run_job(job_id))
        return {"job_id": job_id}

    @app.get("/api/jobs/{job_id}")
    async def get_job(job_id: str) -> dict[str, Any]:
        row = await asyncio.to_thread(db.get_job, job_id)
        if not row:
            raise HTTPException(404, "job not found")
        return row

    @app.get("/api/jobs/{job_id}/asset")
    async def get_asset(job_id: str, rel: str) -> FileResponse:
        row = await asyncio.to_thread(db.get_job, job_id)
        if not row:
            raise HTTPException(404, "job not found")
        manifest = row.get("manifest") or {}
        rel_n = rel.replace("\\", "/").lstrip("/")
        if ".." in rel_n or rel_n.startswith("/"):
            raise HTTPException(400, "invalid rel")
        allowed = _allowed_rels(manifest if isinstance(manifest, dict) else None)
        if rel_n not in allowed:
            raise HTTPException(404, "not found")
        path = job_runner.job_root(job_id) / rel_n
        if not path.is_file():
            raise HTTPException(404, "missing file")
        return FileResponse(str(path))

    @app.post("/api/jobs/{job_id}/findings/{finding_index}/feedback")
    async def post_feedback(job_id: str, finding_index: int, payload: FeedbackBody) -> JSONResponse:
        row = await asyncio.to_thread(db.get_job, job_id)
        if not row:
            raise HTTPException(404, "job not found")
        if row.get("status") != "done":
            raise HTTPException(409, "job not completed")
        findings = row.get("findings") or []
        if finding_index < 0 or finding_index >= len(findings):
            raise HTTPException(400, "finding_index out of range")
        await asyncio.to_thread(db.upsert_feedback, job_id, finding_index, payload.correct)
        return JSONResponse({"ok": True})

    @app.get("/api/reports/jobs")
    async def reports_jobs(
        limit: int = 50,
        offset: int = 0,
        since: float | None = None,
        until: float | None = None,
        status: str | None = None,
        input_kind: str | None = None,
        input_type_cli: str | None = None,
        client_ip: str | None = None,
        min_findings: int | None = None,
        max_findings: int | None = None,
        flash_type: str | None = None,
        has_feedback: bool | None = Query(default=None),
    ) -> dict[str, Any]:
        limit = max(1, min(200, limit))
        offset = max(0, offset)
        st = _strip_opt(status)
        ik = _strip_opt(input_kind)
        itc = _strip_opt(input_type_cli)
        cip = _strip_opt(client_ip)
        ft = _strip_opt(flash_type)
        if min_findings is not None and min_findings < 0:
            raise HTTPException(400, "min_findings must be >= 0")
        if max_findings is not None and max_findings < 0:
            raise HTTPException(400, "max_findings must be >= 0")
        if min_findings is not None and max_findings is not None and min_findings > max_findings:
            raise HTTPException(400, "min_findings must be <= max_findings")
        rows, total = await asyncio.to_thread(
            db.list_jobs_report,
            limit=limit,
            offset=offset,
            since_ts=since,
            until_ts=until,
            status=st,
            input_kind=ik,
            input_type_cli=itc,
            client_ip=cip,
            min_findings=min_findings,
            max_findings=max_findings,
            flash_type=ft,
            has_feedback=has_feedback,
        )
        slim = []
        for r in rows:
            counts = r.get("counts") or {}
            fb = r.get("feedback") or {}
            n_fb = len(fb)
            n_wrong = sum(1 for v in fb.values() if v == "incorrect")
            n_right = sum(1 for v in fb.values() if v == "correct")
            det_meta = _report_detection_meta(r.get("manifest"))
            slim.append(
                {
                    "id": r["id"],
                    "created_at": r["created_at"],
                    "client_ip": r.get("client_ip"),
                    "input_kind": r.get("input_kind"),
                    "input_type_cli": r.get("input_type_cli"),
                    "status": r.get("status"),
                    "total_findings": r.get("total_findings"),
                    "counts": counts,
                    "duration_ms": r.get("duration_ms"),
                    "error_message": r.get("error_message"),
                    "feedback_submitted": n_fb,
                    "feedback_marked_correct": n_right,
                    "feedback_marked_incorrect": n_wrong,
                    **det_meta,
                }
            )
        return {"items": slim, "total": total, "limit": limit, "offset": offset}

    _TREND_DEFAULT_SPAN: dict[str, float] = {
        "minute": 6 * 3600,
        "hour": 14 * 86400,
        "day": 120 * 86400,
        "week": 104 * 7 * 86400,
        "month": 36 * 30 * 86400,
    }
    _TREND_MAX_SPAN: dict[str, float] = {
        "minute": 48 * 3600,
        "hour": 90 * 86400,
        "day": 800 * 86400,
        "week": 520 * 86400,
        "month": 120 * 30 * 86400,
    }

    def _trend_window(
        granularity: str,
        since: float | None,
        until: float | None,
    ) -> tuple[float, float]:
        now = time.time()
        span_default = _TREND_DEFAULT_SPAN[granularity]
        span_max = _TREND_MAX_SPAN[granularity]
        until_f = float(until) if until is not None else now
        since_f = float(since) if since is not None else until_f - span_default
        if since_f >= until_f:
            raise HTTPException(400, "since must be less than until")
        if until_f - since_f > span_max:
            since_f = until_f - span_max
        return since_f, until_f

    @app.get("/api/reports/trends")
    async def reports_trends(
        granularity: str = Query(..., description="minute|hour|day|week|month"),
        since: float | None = None,
        until: float | None = None,
    ) -> dict[str, Any]:
        if granularity not in ("minute", "hour", "day", "week", "month"):
            raise HTTPException(400, "invalid granularity")
        since_f, until_f = _trend_window(granularity, since, until)
        try:
            points = await asyncio.to_thread(db.list_job_trends, granularity, since_f, until_f)
        except ValueError as e:
            raise HTTPException(400, str(e)) from e
        return {
            "granularity": granularity,
            "since": since_f,
            "until": until_f,
            "points": points,
        }

    @app.get("/api/reports/feedback-trends")
    async def reports_feedback_trends(
        granularity: str = Query(..., description="minute|hour|day|week|month"),
        since: float | None = None,
        until: float | None = None,
        flash_type: str | None = Query(None, description="omit or empty for all flash types"),
    ) -> dict[str, Any]:
        if granularity not in ("minute", "hour", "day", "week", "month"):
            raise HTTPException(400, "invalid granularity")
        since_f, until_f = _trend_window(granularity, since, until)
        ft = (flash_type or "").strip() or None
        try:
            points = await asyncio.to_thread(db.list_feedback_trends, granularity, since_f, until_f, ft)
        except ValueError as e:
            raise HTTPException(400, str(e)) from e
        return {
            "granularity": granularity,
            "since": since_f,
            "until": until_f,
            "flash_type": ft,
            "points": points,
        }

    dist = config.static_dist_dir()
    if dist and dist.is_dir():
        assets_dir = dist / "assets"
        if assets_dir.is_dir():
            app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="assets")

        index_html = dist / "index.html"

        @app.get("/")
        def spa_index() -> FileResponse:
            return FileResponse(str(index_html))

        @app.get("/{full_path:path}", response_model=None)
        def spa_fallback(full_path: str) -> FileResponse:
            if full_path.startswith("api"):
                raise HTTPException(404)
            p = (dist / full_path).resolve()
            root = dist.resolve()
            try:
                p.relative_to(root)
            except ValueError:
                return FileResponse(str(index_html))
            if p.is_file():
                return FileResponse(str(p))
            return FileResponse(str(index_html))

    return app


app = create_app()
