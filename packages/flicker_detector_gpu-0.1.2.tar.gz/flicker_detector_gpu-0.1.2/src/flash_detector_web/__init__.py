"""HTTP server UI for flicker-detector (calls bundled/native detector exe)."""

__all__ = ["__version__"]

__version__ = "0.1.0"
