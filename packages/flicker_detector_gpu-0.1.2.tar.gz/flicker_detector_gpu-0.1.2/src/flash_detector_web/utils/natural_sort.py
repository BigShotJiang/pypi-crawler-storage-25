"""Match `frame_io.cpp` directory ordering: underscore segments, numeric segments compared as int."""

from __future__ import annotations

from functools import cmp_to_key
from pathlib import Path


def _split_underscore(s: str) -> list[str]:
    if not s:
        return [""]
    return s.split("_")


def _token_all_digits(s: str) -> bool:
    return bool(s) and all(c.isdigit() for c in s)


def cmp_natural_stem(a: str, b: str) -> int:
    pa = _split_underscore(a)
    pb = _split_underscore(b)
    n = max(len(pa), len(pb))
    for i in range(n):
        sa = pa[i] if i < len(pa) else ""
        sb = pb[i] if i < len(pb) else ""
        da = _token_all_digits(sa)
        db = _token_all_digits(sb)
        if da and db:
            na = int(sa)
            nb = int(sb)
            if na < nb:
                return -1
            if na > nb:
                return 1
        else:
            if sa < sb:
                return -1
            if sa > sb:
                return 1
    return 0


def stem_leading_int(stem: str) -> int:
    digits = []
    for c in stem:
        if c.isdigit():
            digits.append(c)
        elif digits:
            break
    if not digits:
        return 0
    try:
        return int("".join(digits))
    except ValueError:
        return 0


_IMAGE_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".webp", ".tif", ".tiff"}

VIDEO_EXT = frozenset({".mp4", ".webm", ".mov", ".mkv", ".avi", ".m4v"})


def is_image_file(path: Path) -> bool:
    return path.suffix.lower() in _IMAGE_EXT


def is_video_file(path: Path) -> bool:
    return path.suffix.lower() in VIDEO_EXT


def sort_image_paths(paths: list[Path]) -> list[Path]:
    def cmp_path(a: Path, b: Path) -> int:
        c = cmp_natural_stem(a.stem, b.stem)
        if c != 0:
            return c
        if a.name < b.name:
            return -1
        if a.name > b.name:
            return 1
        return 0

    return sorted(paths, key=cmp_to_key(cmp_path))
