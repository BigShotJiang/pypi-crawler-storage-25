"""CLI entry: `gpu-flicker-detector-server` or `python -m flash_detector_web`."""

from __future__ import annotations

import argparse
import os
import sys

import uvicorn

from flash_detector_web import config
from flash_detector_web.services import docker_service


def _env_wants_docker_off() -> bool:
    v = os.environ.get("FLICKER_DETECTOR_USE_DOCKER", "").strip().lower()
    return v in ("0", "false", "no", "off")


def _use_docker_mode() -> bool:
    """Prefer Docker Compose GPU stack when compose file and `docker compose` are available."""
    if _env_wants_docker_off():
        return False
    if not docker_service.compose_v2_ok():
        return False
    if config.compose_project_dir() is None:
        return False
    return True


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="gpu-flicker-detector-server")
    p.add_argument(
        "--docker-build",
        action="store_true",
        help="With Docker mode: rebuild image before up (`docker compose up --build`).",
    )
    p.add_argument(
        "--host",
        default=None,
        help="Bind host (default: env FLICKER_DETECTOR_BIND or FLASH_DETECTOR_BIND or 127.0.0.1)",
    )
    p.add_argument(
        "--port",
        type=int,
        default=None,
        help="Port (default: env FLICKER_DETECTOR_PORT or FLASH_DETECTOR_PORT or 8765)",
    )
    ns = p.parse_args(argv)

    host = ns.host or config.default_bind_host()
    port = int(ns.port if ns.port is not None else config.default_port())

    if _use_docker_mode():
        reload_on = os.environ.get("FLICKER_DETECTOR_RELOAD", "").strip() == "1" or os.environ.get(
            "FLASH_DETECTOR_RELOAD", ""
        ).strip() == "1"
        if reload_on:
            print("WARNING: reload is ignored in Docker mode", file=sys.stderr)
        cdir = config.compose_project_dir()
        if cdir is None:
            print(
                "ERROR: Docker mode but no docker-compose.yml found. Set FLICKER_DETECTOR_COMPOSE_DIR "
                "or use the compose file under flash_detector_web/deploy (or repo root / cwd).",
                file=sys.stderr,
            )
            sys.exit(2)
        if not docker_service.compose_v2_ok():
            print(
                "ERROR: Docker mode requires `docker compose` (Docker CLI + Compose v2 plugin).",
                file=sys.stderr,
            )
            sys.exit(2)
        print("Using detector: Docker GPU image (see flash_detector_web/deploy/)", file=sys.stderr)
        pub = docker_service.port_publish_spec(host, port)
        print(f"Serving via Docker at http://{host if host not in ('0.0.0.0', '::') else '127.0.0.1'}:{port}", file=sys.stderr)
        rc = docker_service.run_compose_up_foreground(cdir, build=ns.docker_build, port_publish=pub)
        raise SystemExit(rc)

    if not _env_wants_docker_off():
        cdir = config.compose_project_dir()
        if cdir is not None and not docker_service.compose_v2_ok():
            print(
                f"NOTE: Found compose project at {cdir} but `docker compose` is unavailable; "
                "running local Uvicorn. Install Docker Compose v2 or set FLICKER_DETECTOR_USE_DOCKER=0 to silence this.",
                file=sys.stderr,
            )

    try:
        det_argv = config.resolve_detector_argv()
        print(f"Using detector: {' '.join(det_argv)}", file=sys.stderr)
    except RuntimeError as e:
        print(f"WARNING: {e}", file=sys.stderr)

    print(f"Serving on http://{host}:{port}", file=sys.stderr)
    uvicorn.run(
        "flash_detector_web.api.app:app",
        host=host,
        port=port,
        reload=os.environ.get("FLICKER_DETECTOR_RELOAD", "").strip() == "1"
        or os.environ.get("FLASH_DETECTOR_RELOAD", "").strip() == "1",
        factory=False,
    )


if __name__ == "__main__":
    main()
