"""SQLite persistence for jobs and per-finding feedback."""

from __future__ import annotations

import json
import sqlite3
import time
from typing import Any

from ..config import sqlite_path


def _connect() -> sqlite3.Connection:
    path = sqlite_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_schema() -> None:
    conn = _connect()
    try:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS jobs (
              id TEXT PRIMARY KEY,
              created_at REAL NOT NULL,
              client_ip TEXT,
              input_kind TEXT NOT NULL,
              input_type_cli TEXT,
              status TEXT NOT NULL,
              progress REAL NOT NULL DEFAULT 0,
              stage TEXT,
              indeterminate INTEGER NOT NULL DEFAULT 0,
              total_findings INTEGER,
              counts_json TEXT,
              findings_json TEXT,
              manifest_json TEXT,
              error_message TEXT,
              duration_ms INTEGER,
              video_rel TEXT,
              frame_count INTEGER
            );

            CREATE TABLE IF NOT EXISTS finding_feedback (
              job_id TEXT NOT NULL,
              finding_index INTEGER NOT NULL,
              is_correct INTEGER,
              updated_at REAL NOT NULL,
              PRIMARY KEY (job_id, finding_index),
              FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE
            );

            CREATE INDEX IF NOT EXISTS idx_jobs_created ON jobs(created_at DESC);
            """
        )
        conn.commit()
    finally:
        conn.close()


def insert_job(
    job_id: str,
    client_ip: str | None,
    input_kind: str,
    manifest: dict[str, Any],
    video_rel: str | None,
    frame_count: int,
) -> None:
    conn = _connect()
    try:
        conn.execute(
            """
            INSERT INTO jobs (
              id, created_at, client_ip, input_kind, status, progress, stage, indeterminate,
              manifest_json, video_rel, frame_count
            ) VALUES (?, ?, ?, ?, 'queued', 0, 'queued', 0, ?, ?, ?)
            """,
            (
                job_id,
                time.time(),
                client_ip,
                input_kind,
                json.dumps(manifest, ensure_ascii=False),
                video_rel,
                frame_count,
            ),
        )
        conn.commit()
    finally:
        conn.close()


def update_job_progress(
    job_id: str,
    *,
    status: str | None = None,
    progress: float | None = None,
    stage: str | None = None,
    indeterminate: bool | None = None,
) -> None:
    conn = _connect()
    try:
        fields: list[str] = []
        vals: list[Any] = []
        if status is not None:
            fields.append("status=?")
            vals.append(status)
        if progress is not None:
            fields.append("progress=?")
            vals.append(progress)
        if stage is not None:
            fields.append("stage=?")
            vals.append(stage)
        if indeterminate is not None:
            fields.append("indeterminate=?")
            vals.append(1 if indeterminate else 0)
        if not fields:
            return
        vals.append(job_id)
        conn.execute(f"UPDATE jobs SET {', '.join(fields)} WHERE id=?", vals)
        conn.commit()
    finally:
        conn.close()


def update_job_manifest(job_id: str, manifest: dict[str, Any]) -> None:
    conn = _connect()
    try:
        conn.execute(
            "UPDATE jobs SET manifest_json=? WHERE id=?",
            (json.dumps(manifest, ensure_ascii=False), job_id),
        )
        conn.commit()
    finally:
        conn.close()


def complete_job_success(
    job_id: str,
    *,
    input_type_cli: str,
    findings: list[dict[str, Any]],
    counts: dict[str, int],
    duration_ms: int,
) -> None:
    conn = _connect()
    try:
        conn.execute(
            """
            UPDATE jobs SET
              status='done',
              progress=100,
              stage='done',
              indeterminate=0,
              input_type_cli=?,
              total_findings=?,
              counts_json=?,
              findings_json=?,
              duration_ms=?,
              error_message=NULL
            WHERE id=?
            """,
            (
                input_type_cli,
                len(findings),
                json.dumps(counts, ensure_ascii=False),
                json.dumps(findings, ensure_ascii=False),
                duration_ms,
                job_id,
            ),
        )
        conn.commit()
    finally:
        conn.close()


def complete_job_failure(job_id: str, message: str, duration_ms: int | None = None) -> None:
    conn = _connect()
    try:
        conn.execute(
            """
            UPDATE jobs SET
              status='failed',
              progress=100,
              stage='failed',
              indeterminate=0,
              error_message=?,
              duration_ms=COALESCE(?, duration_ms)
            WHERE id=?
            """,
            (message, duration_ms, job_id),
        )
        conn.commit()
    finally:
        conn.close()


def get_job(job_id: str) -> dict[str, Any] | None:
    conn = _connect()
    try:
        row = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not row:
            return None
        return _job_row_to_dict(conn, row)
    finally:
        conn.close()


def _parse_json(s: str | None) -> Any:
    if not s:
        return None
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        return None


def _job_row_to_dict(conn: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
    d = dict(row)
    jid = str(d["id"])
    manifest = _parse_json(d.get("manifest_json"))
    counts = _parse_json(d.get("counts_json"))
    findings = _parse_json(d.get("findings_json"))
    frows = conn.execute(
        "SELECT finding_index, is_correct FROM finding_feedback WHERE job_id=? ORDER BY finding_index",
        (jid,),
    ).fetchall()
    feedback: dict[str, str] = {}
    for fr in frows:
        idx = int(fr["finding_index"])
        v = fr["is_correct"]
        if v is None:
            feedback[str(idx)] = "unset"
        elif v:
            feedback[str(idx)] = "correct"
        else:
            feedback[str(idx)] = "incorrect"
    return {
        "id": jid,
        "created_at": float(d["created_at"]),
        "client_ip": d.get("client_ip"),
        "input_kind": d.get("input_kind"),
        "input_type_cli": d.get("input_type_cli"),
        "status": d.get("status"),
        "progress": float(d["progress"] or 0),
        "stage": d.get("stage"),
        "indeterminate": bool(d.get("indeterminate")),
        "total_findings": d.get("total_findings"),
        "counts": counts,
        "findings": findings,
        "manifest": manifest,
        "error_message": d.get("error_message"),
        "duration_ms": d.get("duration_ms"),
        "video_rel": d.get("video_rel"),
        "frame_count": d.get("frame_count"),
        "feedback": feedback,
    }


def _like_substring(pat: str) -> str:
    esc = pat.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{esc}%"


def list_jobs_report(
    *,
    limit: int = 50,
    offset: int = 0,
    since_ts: float | None = None,
    until_ts: float | None = None,
    status: str | None = None,
    input_kind: str | None = None,
    input_type_cli: str | None = None,
    client_ip: str | None = None,
    min_findings: int | None = None,
    max_findings: int | None = None,
    flash_type: str | None = None,
    has_feedback: bool | None = None,
) -> tuple[list[dict[str, Any]], int]:
    conn = _connect()
    try:
        conds: list[str] = []
        args: list[Any] = []
        if since_ts is not None:
            conds.append("created_at >= ?")
            args.append(since_ts)
        if until_ts is not None:
            conds.append("created_at <= ?")
            args.append(until_ts)
        if status:
            conds.append("status = ?")
            args.append(status)
        if input_kind:
            conds.append("input_kind = ?")
            args.append(input_kind)
        if input_type_cli:
            conds.append("input_type_cli LIKE ? ESCAPE '\\'")
            args.append(_like_substring(input_type_cli))
        if client_ip:
            conds.append("client_ip LIKE ? ESCAPE '\\'")
            args.append(_like_substring(client_ip))
        if min_findings is not None:
            conds.append("COALESCE(total_findings, 0) >= ?")
            args.append(min_findings)
        if max_findings is not None:
            conds.append("COALESCE(total_findings, 0) <= ?")
            args.append(max_findings)
        if flash_type:
            conds.append(
                "(json_valid(counts_json) = 1 AND EXISTS ("
                "SELECT 1 FROM json_each(counts_json) AS e "
                "WHERE e.key = ? AND CAST(e.value AS REAL) > 0))"
            )
            args.append(flash_type)
        if has_feedback is True:
            conds.append("EXISTS (SELECT 1 FROM finding_feedback ff WHERE ff.job_id = jobs.id)")
        elif has_feedback is False:
            conds.append("NOT EXISTS (SELECT 1 FROM finding_feedback ff WHERE ff.job_id = jobs.id)")

        where = (" WHERE " + " AND ".join(conds)) if conds else ""
        total = conn.execute(f"SELECT COUNT(*) AS c FROM jobs{where}", args).fetchone()["c"]
        rows = conn.execute(
            f"""
            SELECT * FROM jobs{where}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
            """,
            [*args, limit, offset],
        ).fetchall()
        out = []
        for r in rows:
            out.append(_job_row_to_dict(conn, r))
        return out, int(total)
    finally:
        conn.close()


_TREND_BUCKET_SQL: dict[str, str] = {
    "minute": "strftime('%Y-%m-%d %H:%M', datetime(created_at, 'unixepoch', 'localtime'))",
    "hour": "strftime('%Y-%m-%d %H', datetime(created_at, 'unixepoch', 'localtime')) || ':00'",
    "day": "date(created_at, 'unixepoch', 'localtime')",
    "week": "strftime('%Y', datetime(created_at, 'unixepoch', 'localtime')) || '-W' || strftime('%W', datetime(created_at, 'unixepoch', 'localtime'))",
    "month": "strftime('%Y-%m', datetime(created_at, 'unixepoch', 'localtime'))",
}


def list_job_trends(
    granularity: str,
    since_ts: float,
    until_ts: float,
) -> list[dict[str, Any]]:
    """Aggregate jobs by local-time bucket: request count and sum of total_findings."""
    bucket_expr = _TREND_BUCKET_SQL.get(granularity)
    if bucket_expr is None:
        raise ValueError("invalid granularity")
    conn = _connect()
    try:
        rows = conn.execute(
            f"""
            SELECT {bucket_expr} AS bucket,
                   COUNT(*) AS requests,
                   SUM(COALESCE(total_findings, 0)) AS findings
            FROM jobs
            WHERE created_at >= ? AND created_at <= ?
            GROUP BY 1
            ORDER BY MIN(created_at)
            """,
            (since_ts, until_ts),
        ).fetchall()
        out: list[dict[str, Any]] = []
        for r in rows:
            b = r["bucket"]
            if b is None:
                continue
            out.append(
                {
                    "bucket": str(b),
                    "requests": int(r["requests"] or 0),
                    "findings": int(r["findings"] or 0),
                }
            )
        return out
    finally:
        conn.close()


def list_feedback_trends(
    granularity: str,
    since_ts: float,
    until_ts: float,
    flash_type: str | None = None,
) -> list[dict[str, Any]]:
    """Per bucket (job created_at, local): feedback coverage & accuracy among done jobs.

    - findings_scope: findings matching flash_type filter (or all) in done jobs.
    - feedback_n / correct_n: rows in finding_feedback for those findings.
    - feedback_rate = feedback_n / findings_scope (0 if scope 0).
    - accuracy_rate = correct_n / feedback_n, or None if feedback_n == 0.
    """
    bucket_expr = _TREND_BUCKET_SQL.get(granularity)
    if bucket_expr is None:
        raise ValueError("invalid granularity")
    ft_filter = (flash_type or "").strip() or None
    conn = _connect()
    try:
        bj = bucket_expr.replace("created_at", "j.created_at")
        jrows = conn.execute(
            f"""
            SELECT j.id, j.status, j.findings_json,
                   ({bj}) AS bucket,
                   j.created_at AS ts
            FROM jobs j
            WHERE j.created_at >= ? AND j.created_at <= ?
            """,
            (since_ts, until_ts),
        ).fetchall()
        frows = conn.execute(
            """
            SELECT ff.job_id, ff.finding_index, ff.is_correct
            FROM finding_feedback ff
            INNER JOIN jobs j ON j.id = ff.job_id
            WHERE j.created_at >= ? AND j.created_at <= ?
            """,
            (since_ts, until_ts),
        ).fetchall()

        job_meta: dict[str, dict[str, Any]] = {}
        for jr in jrows:
            jid = str(jr["id"])
            bucket = str(jr["bucket"] or "")
            if not bucket:
                continue
            ts = float(jr["ts"])
            raw = jr["findings_json"]
            try:
                findings_list = list(json.loads(raw or "[]") or [])
            except json.JSONDecodeError:
                findings_list = []
            if not isinstance(findings_list, list):
                findings_list = []
            findings: list[dict[str, Any]] = [x if isinstance(x, dict) else {} for x in findings_list]
            job_meta[jid] = {
                "bucket": bucket,
                "ts": ts,
                "status": str(jr["status"] or ""),
                "findings": findings,
            }

        acc: dict[str, dict[str, int]] = {}
        bucket_min_ts: dict[str, float] = {}

        def touch_bucket(b: str, t: float) -> dict[str, int]:
            if b not in acc:
                acc[b] = {"findings_scope": 0, "feedback_n": 0, "correct_n": 0}
                bucket_min_ts[b] = t
            else:
                if t < bucket_min_ts[b]:
                    bucket_min_ts[b] = t
            return acc[b]

        for meta in job_meta.values():
            if meta["status"] != "done":
                continue
            b = meta["bucket"]
            t = float(meta["ts"])
            cell = touch_bucket(b, t)
            for f in meta["findings"]:
                ft = str(f.get("flash_type") or "")
                if ft_filter and ft != ft_filter:
                    continue
                cell["findings_scope"] += 1

        for fr in frows:
            jid = str(fr["job_id"])
            meta = job_meta.get(jid)
            if not meta or meta["status"] != "done":
                continue
            findings = meta["findings"]
            idx = int(fr["finding_index"])
            if idx < 0 or idx >= len(findings):
                continue
            ft = str(findings[idx].get("flash_type") or "")
            if ft_filter and ft != ft_filter:
                continue
            b = meta["bucket"]
            cell = touch_bucket(b, float(meta["ts"]))
            cell["feedback_n"] += 1
            ic = fr["is_correct"]
            if ic == 1 or ic is True:
                cell["correct_n"] += 1

        out: list[dict[str, Any]] = []
        for bucket in sorted(acc.keys(), key=lambda bk: bucket_min_ts.get(bk, 0.0)):
            fs_ = int(acc[bucket]["findings_scope"])
            fb_ = int(acc[bucket]["feedback_n"])
            cr_ = int(acc[bucket]["correct_n"])
            frate = (fb_ / fs_) if fs_ > 0 else 0.0
            arate: float | None
            if fb_ > 0:
                arate = float(cr_) / float(fb_)
            else:
                arate = None
            out.append(
                {
                    "bucket": bucket,
                    "findings_scope": fs_,
                    "feedback_n": fb_,
                    "correct_n": cr_,
                    "feedback_rate": round(frate, 6),
                    "accuracy_rate": None if arate is None else round(arate, 6),
                }
            )
        return out
    finally:
        conn.close()


def upsert_feedback(job_id: str, finding_index: int, correct: bool) -> None:
    conn = _connect()
    try:
        conn.execute(
            """
            INSERT INTO finding_feedback (job_id, finding_index, is_correct, updated_at)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(job_id, finding_index) DO UPDATE SET
              is_correct=excluded.is_correct,
              updated_at=excluded.updated_at
            """,
            (job_id, finding_index, 1 if correct else 0, time.time()),
        )
        conn.commit()
    finally:
        conn.close()
