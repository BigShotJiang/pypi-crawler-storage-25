"""Load ordered frame sequences for dir / sequence / video (aligned with CPU ordering for dirs)."""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from . import natural_sort


def _match_hw_rgb(arr: np.ndarray, hw: tuple[int, int]) -> np.ndarray:
    """Resize RGB uint8 [H,W,3] to target (height, width) if needed (PIL bilinear)."""
    h, w = hw
    if arr.ndim == 3 and arr.shape[2] == 3 and arr.shape[0] == h and arr.shape[1] == w:
        return arr
    im = Image.fromarray(arr, mode="RGB")
    im = im.resize((w, h), Image.BILINEAR)
    return np.asarray(im, dtype=np.uint8)


def load_dir_frames(frames_dir: Path) -> tuple[np.ndarray, list[str], list[int]]:
    paths = [p for p in frames_dir.iterdir() if p.is_file() and natural_sort.is_image_file(p)]
    paths = natural_sort.sort_image_paths(paths)
    if not paths:
        raise ValueError(f"No image frames in {frames_dir}")
    arrs: list[np.ndarray] = []
    labels: list[str] = []
    times: list[int] = []
    target_hw: tuple[int, int] | None = None
    for p in paths:
        im = Image.open(p).convert("RGB")
        arr = np.asarray(im, dtype=np.uint8)
        if target_hw is None:
            target_hw = (arr.shape[0], arr.shape[1])
        else:
            arr = _match_hw_rgb(arr, target_hw)
        arrs.append(arr)
        labels.append(str(p.resolve()))
        times.append(natural_sort.stem_leading_int(p.stem))
    return np.stack(arrs, axis=0), labels, times


def load_paths_frames(image_paths: list[Path]) -> tuple[np.ndarray, list[str], list[int]]:
    """Load images in **caller order** (matches CPU `--type sequence` argv order)."""
    if not image_paths:
        raise ValueError("sequence: no image paths")
    arrs: list[np.ndarray] = []
    labels: list[str] = []
    times: list[int] = []
    target_hw: tuple[int, int] | None = None
    for p in image_paths:
        rp = p.resolve()
        if not rp.is_file():
            raise FileNotFoundError(f"sequence: not a file: {p}")
        if not natural_sort.is_image_file(rp):
            raise ValueError(f"sequence: not an image file: {p}")
        im = Image.open(rp).convert("RGB")
        arr = np.asarray(im, dtype=np.uint8)
        if target_hw is None:
            target_hw = (arr.shape[0], arr.shape[1])
        else:
            arr = _match_hw_rgb(arr, target_hw)
        arrs.append(arr)
        labels.append(str(rp))
        times.append(natural_sort.stem_leading_int(rp.stem))
    return np.stack(arrs, axis=0), labels, times


def load_video_frames(
    video_path: Path,
    fps_override: float,
) -> tuple[np.ndarray, list[str], list[int], float]:
    cap = cv2.VideoCapture(str(video_path))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")
    fps = float(fps_override) if fps_override > 0 else float(cap.get(cv2.CAP_PROP_FPS) or 0.0)
    if fps <= 0:
        fps = 30.0
    frames: list[np.ndarray] = []
    labels: list[str] = []
    times: list[int] = []
    target_hw: tuple[int, int] | None = None
    i = 0
    while True:
        ok, bgr = cap.read()
        if not ok:
            break
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB).astype(np.uint8)
        if target_hw is None:
            target_hw = (rgb.shape[0], rgb.shape[1])
        else:
            rgb = _match_hw_rgb(rgb, target_hw)
        frames.append(rgb)
        labels.append(f"video:frame={i}")
        times.append(int(round(i * 1000.0 / fps)))
        i += 1
    cap.release()
    if not frames:
        raise ValueError(f"No frames decoded from {video_path}")
    return np.stack(frames, axis=0), labels, times, fps
