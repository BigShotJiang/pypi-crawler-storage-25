"""Sliding 4-frame PredNet anomaly -> CPU-shaped JSON findings."""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Literal, Sequence

import numpy as np
from PIL import Image

from . import natural_sort
from .frames_io import load_dir_frames, load_paths_frames, load_video_frames
from .infer.anomaly import compute_prednet_frame_score
from .infer.predictor import Predictor
from .model_resolve import resolve_savedmodel_dir

# Stored in JSON; matches denoising_prednet ``prednet_loss`` total (val_loss).
SCORE_METRIC = "prednet_total"

FLASH_TYPE = "prednet_anomaly"
SCENE = "STABLE"
JSON_VERSION = 1


def _apply_frame_interval(times: list[int], interval_ms: int) -> list[int]:
    if interval_ms <= 0:
        return times
    return [i * interval_ms for i in range(len(times))]


def _padded_window_4(frames: np.ndarray, t: int) -> np.ndarray:
    """frames [T,H,W,C] uint8. Return [4,H,W,C] aligned to predict appearance at index t.

    For t < 3, missing past timesteps are zero-padded (not first-frame repeat). After
    normalization in the model, those slots are 0.0. Chronological order is kept:
    t=0 -> [0,0,0,a], t=1 -> [0,0,a,b], t=2 -> [0,a,b,c]; t>=3 -> frames[t-3:t+1].
    """
    if frames.ndim != 4:
        raise ValueError(f"expected frames [T,H,W,C], got shape={frames.shape}")
    start = t - 3
    if start >= 0:
        return np.asarray(frames[start : t + 1], dtype=np.uint8)
    need = 4 - (t + 1)
    h, w, c = int(frames.shape[1]), int(frames.shape[2]), int(frames.shape[3])
    pad = np.zeros((need, h, w, c), dtype=np.uint8)
    return np.concatenate([pad, frames[0 : t + 1]], axis=0)


def _save_pred_png(pred01: np.ndarray, out_path: Path, size_hw: tuple[int, int]) -> None:
    """pred01 [H,W,C] float 0..1, size_hw (height, width) of target RGB."""
    h, w = size_hw
    x = np.clip(pred01, 0.0, 1.0)
    rgb = (x * 255.0).astype(np.uint8)
    im = Image.fromarray(rgb, mode="RGB")
    if im.size != (w, h):
        im = im.resize((w, h), Image.BILINEAR)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    im.save(out_path, format="PNG")


def _merge_runs(indices: list[int]) -> list[tuple[int, int]]:
    if not indices:
        return []
    indices = sorted(set(indices))
    out: list[tuple[int, int]] = []
    a = b = indices[0]
    for x in indices[1:]:
        if x == b + 1:
            b = x
        else:
            out.append((a, b))
            a = b = x
    out.append((a, b))
    return out


def run_detect(
    *,
    input_type: Literal["dir", "video", "sequence"],
    inputs: list[Path],
    model_dir: str | None,
    threshold: float,
    fps: float,
    frame_interval_ms: int,
    pred_frames_dir: Path | None = None,
    layer_loss_weights: Sequence[float] | None = None,
) -> dict[str, Any]:
    if input_type == "dir":
        if len(inputs) != 1:
            raise ValueError("dir mode requires exactly one --input (directory)")
        d = inputs[0].expanduser().resolve()
        if not d.is_dir():
            raise ValueError(f"dir mode requires a directory: {inputs[0]}")
        frames, labels, times = load_dir_frames(d)
        times = _apply_frame_interval(times, frame_interval_ms)
    elif input_type == "sequence":
        if len(inputs) < 4:
            raise ValueError("sequence mode requires at least four --input image paths (GPU PredNet)")
        resolved: list[Path] = []
        for p in inputs:
            rp = p.expanduser().resolve()
            if not rp.is_file():
                raise ValueError(f"sequence: not a file: {p}")
            if not natural_sort.is_image_file(rp):
                raise ValueError(f"sequence: not an image file: {p}")
            resolved.append(rp)
        frames, labels, times = load_paths_frames(resolved)
        times = _apply_frame_interval(times, frame_interval_ms)
    elif input_type == "video":
        if len(inputs) != 1:
            raise ValueError("video mode requires exactly one --input (video file)")
        vp = inputs[0].expanduser().resolve()
        if not vp.is_file():
            raise ValueError(f"video: not a file: {inputs[0]}")
        if not natural_sort.is_video_file(vp):
            raise ValueError(f"video: unsupported extension (use e.g. .mp4): {vp.name}")
        frames, labels, times, _fps = load_video_frames(vp, fps)
    else:
        raise ValueError(f"unsupported input_type: {input_type}")

    t_count = int(frames.shape[0])
    if t_count < 4:
        raise ValueError(f"Need at least 4 frames, got {t_count}")

    origin_ms = int(times[0])
    sm_path = resolve_savedmodel_dir(model_dir)
    pred = Predictor(sm_path)
    if pred.sequence_len is not None and pred.sequence_len != 4:
        raise RuntimeError(f"Expected model sequence_len=4, got {pred.sequence_len}")

    llw: tuple[float, ...] = (
        tuple(float(x) for x in layer_loss_weights)
        if layer_loss_weights is not None
        else (1.0, 0.1, 0.1, 0.1)
    )

    frame_scores: list[float] = []
    for t in range(t_count):
        win4 = _padded_window_4(frames, t)
        frame_scores.append(
            compute_prednet_frame_score(pred, win4, layer_loss_weights=llw),
        )

    anomaly_indices: list[int] = []
    peak_scores: dict[int, float] = {}
    for t in range(3, t_count):
        s = frame_scores[t]
        if s > threshold:
            anomaly_indices.append(t)
            peak_scores[t] = s

    pred_frames_meta: list[dict[str, Any]] | None = None
    if pred_frames_dir is not None:
        pdir = pred_frames_dir.resolve()
        rel_prefix = (pdir.name or "pred_frames").replace("\\", "/")
        pred_frames_meta = []
        for t in range(t_count):
            win4 = _padded_window_4(frames, t)
            pr = pred.predict_last_frame(win4, pad_last_frame="none")
            pimg = np.squeeze(np.asarray(pr, dtype=np.float32), axis=0)
            name = f"pred_{t:05d}.png"
            rel = f"{rel_prefix}/{name}"
            _save_pred_png(pimg, pdir / name, (int(frames[t].shape[0]), int(frames[t].shape[1])))
            pred_frames_meta.append({"rel": rel, "index": t, "time_ms": int(times[t])})

    findings: list[dict[str, Any]] = []
    for a, b in _merge_runs(anomaly_indices):
        st = int(times[a])
        en = int(times[b])
        findings.append(
            {
                "flash_type": FLASH_TYPE,
                "scene": SCENE,
                "start_time_ms": st,
                "end_time_ms": en,
                "during_time_ms": max(0, en - st),
                "video_start_time_ms": st - origin_ms,
                "video_end_time_ms": en - origin_ms,
                "start_frame": a,
                "end_frame": b,
                "path_start": labels[a],
                "path_end": labels[b],
                "score_peak": max(peak_scores.get(i, 0.0) for i in range(a, b + 1)),
                "metric": SCORE_METRIC,
            }
        )

    finite_scores = [float(x) for x in frame_scores if isinstance(x, (int, float)) and math.isfinite(float(x))]
    score_max = max(finite_scores) if finite_scores else None

    out: dict[str, Any] = {
        "version": JSON_VERSION,
        "input_type": input_type,
        "findings": findings,
        "frame_scores": {
            "values": frame_scores,
            "metric": SCORE_METRIC,
            "threshold": float(threshold),
            "max_value": score_max,
        },
    }
    if pred_frames_meta is not None:
        out["pred_frames"] = pred_frames_meta
    return out
