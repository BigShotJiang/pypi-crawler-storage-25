"""Vendored inference helpers for dvdface/next-frame-predict SavedModel."""
