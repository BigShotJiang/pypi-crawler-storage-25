from __future__ import annotations

import numpy as np

from .predictor import Predictor


def compute_prednet_total_loss(
    tf,
    out_np: dict[str, np.ndarray],
    target_seq: np.ndarray,
    *,
    layer_loss_weights: tuple[float, ...],
) -> float:
    """
    Match ``prednet_loss`` in video-prediction-research/denoising_prednet.ipynb:
    pred_loss = mean(Huber(target[:,1:], preds[:,1:]))
    layer_loss = mean(sum(layer_errors[:,1:] * w, axis=-1))
    total = pred_loss + 0.1 * layer_loss
    """
    if "layer_errors" not in out_np:
        raise RuntimeError(
            "SavedModel must export tensor 'layer_errors' (training val_loss / prednet_loss total formula)."
        )
    preds = tf.convert_to_tensor(out_np["predictions"], dtype=tf.float32)
    target = tf.convert_to_tensor(target_seq, dtype=tf.float32)
    pred_loss = tf.reduce_mean(tf.keras.losses.huber(target[:, 1:], preds[:, 1:]))
    layer_errors = tf.convert_to_tensor(out_np["layer_errors"], dtype=tf.float32)
    if layer_errors.shape[-1] != len(layer_loss_weights):
        raise ValueError(
            f"layer_errors last dim {layer_errors.shape[-1]} != len(layer_loss_weights)={len(layer_loss_weights)}"
        )
    w = tf.constant(layer_loss_weights, dtype=layer_errors.dtype)
    w = w[tf.newaxis, tf.newaxis, :]
    layer_loss = tf.reduce_mean(tf.reduce_sum(layer_errors[:, 1:] * w, axis=-1))
    total = pred_loss + 0.1 * layer_loss
    return float(total.numpy())


def compute_prednet_frame_score(
    predictor: Predictor,
    frames4: np.ndarray,
    *,
    layer_loss_weights: tuple[float, ...],
) -> float:
    """Single-window scalar score: same as training ``prednet_loss`` total for this 4-frame input."""
    outs = predictor.predict_outputs(frames4, pad_last_frame="none")
    if "predictions" not in outs:
        raise RuntimeError("SavedModel did not return 'predictions'.")
    x = predictor._prep(frames4, pad_last_frame="none")
    x = np.asarray(x, dtype=np.float32)
    return compute_prednet_total_loss(
        predictor._tf, outs, x, layer_loss_weights=layer_loss_weights
    )
