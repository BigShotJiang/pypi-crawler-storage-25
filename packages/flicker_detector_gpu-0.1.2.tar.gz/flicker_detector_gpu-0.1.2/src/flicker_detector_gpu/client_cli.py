"""HTTP client for flicker-detector-server (Python; mirrors CPU C++ client)."""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import httpx

from .natural_sort import is_image_file, is_video_file


def _trim_base(url: str) -> str:
    return url.rstrip("/\\")


def _walk_folder_images(root: Path) -> list[tuple[Path, str]]:
    root = root.resolve()
    if not root.is_dir():
        raise ValueError("folder: not a directory")
    out: list[tuple[Path, str]] = []
    for p in root.rglob("*"):
        if p.is_file() and is_image_file(p):
            rel = p.relative_to(root).as_posix()
            out.append((p, rel))
    out.sort(key=lambda x: x[1])
    return out


def _resolve_job(mode: str, paths: list[str]) -> tuple[str, list[tuple[Path, str]]]:
    if mode == "video":
        if len(paths) != 1:
            raise ValueError("video: exactly one video file path required")
        p = Path(paths[0]).expanduser().resolve()
        if not p.is_file():
            raise ValueError("video: not a regular file")
        if not is_video_file(p):
            raise ValueError("video: need a video extension (e.g. .mp4)")
        return "video", [(p, p.name)]

    if mode == "sequence":
        if len(paths) < 4:
            raise ValueError("sequence: at least four image paths required (GPU PredNet)")
        parts: list[tuple[Path, str]] = []
        for s in paths:
            p = Path(s).expanduser().resolve()
            if not p.is_file():
                raise ValueError(f"sequence: not a file: {s}")
            if not is_image_file(p):
                raise ValueError(f"sequence: not an image: {p.name}")
            parts.append((p, p.name))
        return "dir_files", parts

    if mode == "folder":
        if len(paths) != 1:
            raise ValueError("folder: exactly one directory path required")
        parts = _walk_folder_images(Path(paths[0]))
        if len(parts) < 4:
            raise ValueError("folder: need at least four images under directory (recursive)")
        return "dir_folder", parts

    raise ValueError("mode must be video | sequence | folder")


def main(argv: list[str] | None = None) -> None:
    p = argparse.ArgumentParser(prog="gpu-flicker-detector-client")
    p.add_argument("--url", default="http://127.0.0.1:8765", help="Server base URL")
    p.add_argument(
        "--mode",
        required=True,
        choices=("video", "sequence", "folder"),
        help="video | sequence | folder (sequence: ≥4 images on GPU vs 2 on CPU)",
    )
    p.add_argument("--poll", type=float, default=0.5, help="Poll interval (seconds)")
    p.add_argument("--timeout", type=float, default=7200.0, help="Max wait for job (seconds)")
    p.add_argument("--http-timeout", type=float, default=60.0, help="Per-request timeout (seconds)")
    p.add_argument("--upload-timeout", type=float, default=3600.0, help="POST /api/jobs timeout (seconds)")
    p.add_argument("-o", "--output", help="Write final job JSON to file")
    p.add_argument("-q", "--quiet", action="store_true", help="Less output")
    p.add_argument("--skip-health", action="store_true", help="Skip GET /api/health")
    p.add_argument("paths", nargs="*", help="Paths (see mode)")
    ns = p.parse_args(argv)

    base = _trim_base(ns.url)
    http_timeout = max(1.0, ns.http_timeout)
    upload_timeout = max(1.0, ns.upload_timeout)
    poll = max(0.05, ns.poll)

    try:
        input_kind, parts = _resolve_job(ns.mode, list(ns.paths))
    except ValueError as e:
        print(str(e), file=sys.stderr)
        raise SystemExit(3) from e

    try:
        with httpx.Client(timeout=http_timeout) as client:
            if not ns.skip_health:
                h = client.get(f"{base}/api/health")
                if h.status_code < 200 or h.status_code >= 300:
                    print(f"GET /api/health HTTP {h.status_code}\n{h.text}", file=sys.stderr)
                    raise SystemExit(2)
                if not ns.quiet:
                    try:
                        print(json.dumps(h.json(), ensure_ascii=False, indent=2))
                    except Exception:
                        print(h.text)

            file_handles: list[object] = []
            try:
                file_fields: list[tuple[str, tuple[str, object, str]]] = []
                for path, remote in parts:
                    fh = path.open("rb")
                    file_handles.append(fh)
                    file_fields.append(("files", (remote, fh, "application/octet-stream")))
                post = client.post(
                    f"{base}/api/jobs",
                    data={"input_kind": input_kind},
                    files=file_fields,
                    timeout=upload_timeout,
                )
            finally:
                for fh in file_handles:
                    try:
                        fh.close()
                    except Exception:
                        pass

            if post.status_code < 200 or post.status_code >= 300:
                print(f"POST /api/jobs HTTP {post.status_code}\n{post.text}", file=sys.stderr)
                raise SystemExit(2)
            try:
                created = post.json()
            except Exception:
                print("Invalid JSON in create-job response", file=sys.stderr)
                raise SystemExit(2) from None
            job_id = created.get("job_id")
            if not job_id:
                print(f"Invalid response: {post.text}", file=sys.stderr)
                raise SystemExit(2)
            if not ns.quiet:
                print(f"job_id={job_id} input_kind={input_kind}")

            deadline = time.monotonic() + float(ns.timeout)
            last_line = ""
            final_row: dict | None = None
            while True:
                if time.monotonic() > deadline:
                    print("Timeout waiting for job", file=sys.stderr)
                    raise SystemExit(4)
                row = client.get(f"{base}/api/jobs/{job_id}")
                if row.status_code < 200 or row.status_code >= 300:
                    print(f"GET job HTTP {row.status_code}\n{row.text}", file=sys.stderr)
                    raise SystemExit(2)
                try:
                    j = row.json()
                except Exception:
                    print("Invalid job JSON", file=sys.stderr)
                    raise SystemExit(2) from None
                status = str(j.get("status") or "")
                stage = str(j.get("stage") or "")
                line = f"[{status}] {stage}"
                if line != last_line and not ns.quiet:
                    print(line)
                    last_line = line
                if status in ("done", "failed"):
                    final_row = j
                    break
                time.sleep(poll)

            assert final_row is not None
            out_text = json.dumps(final_row, ensure_ascii=False, indent=2)
            if ns.output:
                Path(ns.output).write_text(out_text, encoding="utf-8")
                if not ns.quiet:
                    print(f"Wrote {ns.output}")
            else:
                print(out_text)

            if final_row.get("status") != "done":
                raise SystemExit(1)
    except httpx.HTTPError as e:
        print(str(e), file=sys.stderr)
        raise SystemExit(2) from e


if __name__ == "__main__":
    main()
