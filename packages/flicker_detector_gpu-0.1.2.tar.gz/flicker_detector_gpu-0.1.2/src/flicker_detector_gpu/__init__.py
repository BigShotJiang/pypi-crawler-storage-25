"""PredNet-based flicker / anomaly detection (GPU-capable TensorFlow)."""

__version__ = "0.1.0"
