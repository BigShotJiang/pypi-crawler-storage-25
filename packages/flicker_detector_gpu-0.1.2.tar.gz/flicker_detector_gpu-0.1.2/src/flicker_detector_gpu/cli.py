"""CLI compatible with CPU flicker-detector (--type dir | video | sequence)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .detect import run_detect


def _parse_layer_loss_weights(s: str) -> tuple[float, ...]:
    parts = [p.strip() for p in s.split(",") if p.strip()]
    if not parts:
        raise argparse.ArgumentTypeError("expected comma-separated floats, e.g. 1,0.1,0.1,0.1")
    try:
        return tuple(float(p) for p in parts)
    except ValueError as e:
        raise argparse.ArgumentTypeError(str(e)) from e


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="gpu-flicker-detector", description="GPU PredNet flicker / anomaly detection")
    p.add_argument(
        "--type",
        required=True,
        choices=("dir", "video", "sequence"),
        help="dir=image directory; video=single file; sequence=multiple images (≥4, repeat --input)",
    )
    p.add_argument("--input", action="append", required=True, help="Input path (repeat for sequence mode)")
    p.add_argument("--output", required=True, help="Output JSON path")
    p.add_argument("--fps", type=float, default=0.0, help="Video: override FPS (0 = from container)")
    p.add_argument("--frame-interval-ms", type=int, default=0, help="dir/sequence: use index*ms as timestamps when >0")
    p.add_argument("--model-dir", default=None, help="SavedModel directory (default: env or Hub download)")
    p.add_argument(
        "--threshold",
        type=float,
        default=0.025,
        help="Anomaly threshold vs prednet_total (training loss scale); retune for your model",
    )
    p.add_argument(
        "--layer-loss-weights",
        type=_parse_layer_loss_weights,
        default=None,
        metavar="W,W,...",
        help="Layer weights for prednet loss (must match model); default 1,0.1,0.1,0.1 (denoising_prednet TrainConfig)",
    )
    p.add_argument(
        "--write-pred-frames",
        default=None,
        metavar="DIR",
        help="If set, write one PredNet predicted RGB PNG per input frame under DIR (relative to cwd unless absolute)",
    )
    return p


def main(argv: list[str] | None = None) -> None:
    args = build_parser().parse_args(argv)
    input_type: str = args.type
    paths = [Path(x) for x in args.input]
    pred_dir = Path(args.write_pred_frames).resolve() if args.write_pred_frames else None
    try:
        out = run_detect(
            input_type=input_type,
            inputs=paths,
            model_dir=args.model_dir,
            threshold=float(args.threshold),
            fps=float(args.fps),
            frame_interval_ms=int(args.frame_interval_ms),
            pred_frames_dir=pred_dir,
            layer_loss_weights=args.layer_loss_weights,
        )
    except (FileNotFoundError, ValueError, RuntimeError) as e:
        print(str(e), file=sys.stderr)
        raise SystemExit(2) from e

    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
