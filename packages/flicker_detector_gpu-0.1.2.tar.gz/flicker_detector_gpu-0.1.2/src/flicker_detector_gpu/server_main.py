"""Entry: gpu-flicker-detector-server -> uvicorn + flash_detector_web."""

from __future__ import annotations

import sys

from flash_detector_web.cli import main


if __name__ == "__main__":
    main(sys.argv[1:])
