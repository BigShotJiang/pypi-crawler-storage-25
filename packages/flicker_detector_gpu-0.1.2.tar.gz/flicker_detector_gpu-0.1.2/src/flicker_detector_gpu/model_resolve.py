"""Resolve SavedModel directory (env or Hugging Face Hub cache)."""

from __future__ import annotations

import os
from pathlib import Path

REPO_ID = "dvdface/next-frame-predict"


def resolve_savedmodel_dir(explicit: str | None = None) -> Path:
    if explicit:
        p = Path(explicit).expanduser().resolve()
        if not p.is_dir():
            raise FileNotFoundError(f"--model-dir is not a directory: {p}")
        return p

    for key in ("FLICKER_GPU_MODEL_DIR", "NEXT_FRAME_PREDICT_MODEL_DIR"):
        v = os.environ.get(key, "").strip()
        if v:
            p = Path(v).expanduser().resolve()
            if p.is_dir():
                return p
            raise FileNotFoundError(f"{key} is not a directory: {p}")

    from huggingface_hub import snapshot_download

    root = Path(
        snapshot_download(
            repo_id=REPO_ID,
            allow_patterns=["savedmodel/**"],
        )
    )
    sm = root / "savedmodel"
    if not sm.is_dir():
        raise FileNotFoundError(f"Downloaded repo missing savedmodel/: {root}")
    return sm.resolve()
