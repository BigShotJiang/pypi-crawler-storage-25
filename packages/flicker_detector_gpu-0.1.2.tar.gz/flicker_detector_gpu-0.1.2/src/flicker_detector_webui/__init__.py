"""Vite/React SPA for flash_detector_web; built assets live in ``dist/`` (see package-data)."""
