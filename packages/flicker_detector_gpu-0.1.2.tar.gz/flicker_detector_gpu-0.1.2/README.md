# flicker-detector-gpu

基于 TensorFlow **SavedModel**（下一帧预测）的 GPU 闪烁 / 异常检测：本地 CLI、带 Web 界面的 HTTP 服务、以及与服务端交互的 Python 客户端。

## 环境要求

- Python **3.10+**（跑 CLI、本机 HTTP 服务或客户端时）
- 依赖见仓库根目录 [`pyproject.toml`](pyproject.toml)（含 TensorFlow 2.14+、OpenCV、FastAPI 等）
- **本机 Uvicorn 模式**：是否用到 NVIDIA GPU 取决于当前 Python 环境里的 TensorFlow 与 CUDA
- **Docker 模式**（推荐用于服务端 GPU）：主机需安装 [NVIDIA Container Toolkit](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html)；Windows 上通常使用 Docker Desktop 的 **WSL2** 后端

## 安装与命令一览

在仓库根目录执行可编辑安装后，会注册三个控制台命令：

```bash
pip install -e .
```

| 命令 | 作用 |
|------|------|
| `gpu-flicker-detector` | 本地直接跑检测，输出 JSON 文件 |
| `gpu-flicker-detector-server` | 启动 Web API + 可选前端静态资源 |
| `gpu-flicker-detector-client` | 向已启动的服务提交任务并轮询结果 |

安装后（Windows 为 `Scripts` 下的 `.exe`）三个命令各司其职：检测、起服务、连服务，无需记子命令，也与 CPU 版 `flicker-detector*.exe` 并存时不重名。

开发依赖（可选）：`pip install -e ".[dev]"`。

单元测试在各包的 `src/<包名>/tests/` 下；在仓库根执行（需将 `src` 加入模块搜索路径）：

```bash
PYTHONPATH=src python -m unittest discover -s src -p "test_*.py"
```

PowerShell：`$env:PYTHONPATH="src"; python -m unittest discover -s src -p "test_*.py"`。

等价的模块方式（未安装包、但 `src` 在 `PYTHONPATH` 上时也可用）：

- `python -m flicker_detector_gpu.cli`（同 `gpu-flicker-detector`）
- `python -m flash_detector_web`（同 `gpu-flicker-detector-server`）

---

## `gpu-flicker-detector`（本地 CLI）

与 CPU 版 **`--type` 命名**一致：**`dir` \| `video` \| `sequence`**。多图请使用 **`sequence`** 并多次传入 **`--input`**（与 CPU 相同），不再支持单独的「路径列表文本文件」模式。

**与 CPU 的差异（实现限制）**：本 GPU 版使用 PredNet **4 帧滑动窗**，因此 **`sequence` 至少需要 4 张图**、目录任务也至少需要 **4** 张可识别图片；CPU 版 `sequence` 最少为 **2** 张。视频扩展名需为：`.mp4`、`.webm`、`.mov`、`.mkv`、`.avi`、`.m4v`（与 CPU 客户端一致）。

### 与 CPU 对齐的常用参数

- `--type`：`dir`（**单层**目录内图片，按自然序排序）、`video`（单个视频文件）、`sequence`（多张图片，每个文件一次 `--input`，**至少四个**）
- `--input`：`dir` / `video` 各一个路径；`sequence` 为多个路径（顺序即时间序，与 CPU 一致）
- `--output`：输出 JSON 路径（父目录不存在时会创建）
- `--fps`：视频：覆盖容器 FPS（`0` 表示从文件读取）
- `--frame-interval-ms`：`dir` / `sequence`：大于 0 时，用 `索引 × 毫秒` 作为时间戳

### GPU 专有参数（CPU 版无对应项）

- `--model-dir`：SavedModel 目录；省略时见下文「模型路径」
- `--threshold`：异常阈值，默认 `0.025`（量纲为训练时 **多层预测误差加权损失**；请按验证集自行标定）
- `--layer-loss-weights`：逗号分隔浮点，须与模型层数一致；默认 `1,0.1,0.1,0.1`
- `--write-pred-frames`：将每帧预测图写入指定目录

得分为各层误差的加权总和（与训练时验证损失 **`val_loss`** 同量纲）；SavedModel 必须导出 **`layer_errors`**。

### 示例

目录内图片（仅该目录**直接**下的文件，常见图片扩展名，自然排序）：

```bash
gpu-flicker-detector --type dir --input ./frames/ --output ./out.json
```

单个视频：

```bash
gpu-flicker-detector --type video --input ./clip.mp4 --output ./out.json
```

多张图片（至少四张，`--input` 顺序即帧序）：

```bash
gpu-flicker-detector --type sequence --input ./a.png --input ./b.png --input ./c.png --input ./d.png --output ./out.json
```

指定本地 SavedModel：

```bash
gpu-flicker-detector --type video --input ./clip.mp4 --output ./out.json --model-dir D:/models/my_savedmodel
```

至少需要 **4 帧** 才会开始推理；不满足时进程会以非零退出码结束并在 stderr 打印原因。

### 模型路径（未传 `--model-dir` 时）

按顺序尝试：

1. 环境变量 **`FLICKER_GPU_MODEL_DIR`** 或 **`NEXT_FRAME_PREDICT_MODEL_DIR`**（须为已存在的目录）
2. 否则由程序将默认 SavedModel 下载到本地缓存（需可访问外网；若默认源需要认证，请按项目依赖中模型下载库的说明配置令牌与环境变量）

---

## `gpu-flicker-detector-server`（HTTP 服务）

在仓库内执行时，**默认优先用 Docker Compose** 拉起带 GPU 的镜像（Compose 与 [`Dockerfile`](src/flash_detector_web/deploy/Dockerfile) 位于 [`src/flash_detector_web/deploy/`](src/flash_detector_web/deploy/)）。若未安装 `docker compose`、找不到 compose 文件，或显式关闭 Docker，则退回到**本机 Uvicorn** 跑 FastAPI。

监听地址默认 **`127.0.0.1:8765`**（Docker 模式下会映射到宿主机的 `--host` / `--port`）。

### 命令行参数

```bash
# 默认：在可用时执行 docker compose up（前台附加日志）
gpu-flicker-detector-server

# 绑定与端口（Docker 模式下写入 FLICKER_DETECTOR_PORT_PUBLISH，如 8765 或 127.0.0.1:8765）
gpu-flicker-detector-server --host 0.0.0.0 --port 8765

# Docker 模式下构建镜像后再启动
gpu-flicker-detector-server --docker-build
```

- `--host`：省略时使用 **`FLICKER_DETECTOR_BIND`** 或 **`FLASH_DETECTOR_BIND`**，再否则 `127.0.0.1`（仅本机 Uvicorn；Docker 时用于端口发布侧的主机地址）
- `--port`：省略时使用 **`FLICKER_DETECTOR_PORT`** 或 **`FLASH_DETECTOR_PORT`**，再否则 `8765`
- `--docker-build`：仅在 **Docker 模式**下生效，等价于 `docker compose up --build`

### Docker 与本机 Uvicorn 切换

| 变量 | 说明 |
|------|------|
| `FLICKER_DETECTOR_USE_DOCKER` | 设为 `0` / `false` / `no` / `off` 时**强制本机 Uvicorn**，不尝试 Docker |
| `FLICKER_DETECTOR_COMPOSE_DIR` | 显式指定包含 `docker-compose.yml` 的目录（否则优先 `flash_detector_web/deploy`，再尝试仓库根、`cwd` 等） |

也可不经过 CLI，在仓库根执行：

```bash
docker compose -f src/flash_detector_web/deploy/docker-compose.yml up --build
```

或在 `src/flash_detector_web/deploy` 下执行 `docker compose up --build`。

Compose 里容器内固定监听 `8765`；宿主机端口由环境变量 **`FLICKER_DETECTOR_PORT_PUBLISH`** 控制（默认 `8765`，或 `127.0.0.1:8765` 仅本机回环）。由 `gpu-flicker-detector-server` 启动时会根据 `--host` / `--port` 自动设置该变量。

**注意**：`FLICKER_DETECTOR_RELOAD` / `FLASH_DETECTOR_RELOAD` 仅在本机 Uvicorn 模式下生效；Docker 模式下会被忽略。

### 与检测后端相关的环境变量

服务会通过子进程或指定可执行文件调用「与 `gpu-flicker-detector` 相同参数风格」的检测命令，解析逻辑在 `flash_detector_web.config`：

| 变量 | 含义 |
|------|------|
| `FLICKER_DETECTOR_ARGV_JSON` | JSON 字符串数组，整条 argv 前缀（优先级最高） |
| `FLICKER_DETECTOR_EXE` / `IMAGE_FLASH_DETECTOR_EXE` | 检测可执行文件路径 |
| （均未设置） | 默认 `python -m flicker_detector_gpu.cli`（即用当前环境的 Python 跑 CLI） |

### 数据目录与其它常用变量

| 变量 | 默认 / 说明 |
|------|----------------|
| `FLICKER_DETECTOR_WEB_DATA` / `FLASH_DETECTOR_WEB_DATA` | 数据根目录；默认当前工作目录下 `flicker_detector_web_data` |
| `FLICKER_DETECTOR_MAX_UPLOAD_MB` / `FLASH_DETECTOR_MAX_UPLOAD_MB` | 上传大小上限（MB），默认 2048 |
| `FLICKER_DETECTOR_MAX_CONCURRENT_JOBS` / `FLASH_DETECTOR_MAX_CONCURRENT_JOBS` | 并发任务数，默认 1 |
| `FLICKER_DETECTOR_JOB_TIMEOUT_SEC` / `FLASH_DETECTOR_JOB_TIMEOUT_SEC` | 单任务超时（秒），默认 7200 |
| `FLICKER_DETECTOR_THRESHOLD` / `FLASH_DETECTOR_JOB_THRESHOLD` | Web 任务的 `--threshold`（不设则用 CLI 默认 `0.025`） |
| `FLICKER_DETECTOR_LAYER_LOSS_WEIGHTS` / `FLASH_DETECTOR_LAYER_LOSS_WEIGHTS` | 逗号分隔层权重，如 `1,0.1,0.1,0.1` |
| `FLICKER_DETECTOR_TRUST_PROXY` / `FLASH_DETECTOR_TRUST_PROXY` | 反向代理信任（`1`/`true`/`yes`） |
| `FLICKER_DETECTOR_RELOAD` / `FLASH_DETECTOR_RELOAD` | 设为 `1` 时 **仅本机 Uvicorn** 开启 reload（开发用） |

静态站点：若已构建前端，仓库内 `src/flicker_detector_webui/dist/index.html` 存在时（或安装包中的 `flicker_detector_webui` 资源），**本机 Uvicorn** 会挂载该 SPA；官方 Docker 镜像在构建阶段已打入同一 `dist`，无需在容器外再执行 `npm run build`。

### `POST /api/jobs`（与 CPU 版服务对齐）

- **`input_kind`**：`video` | `dir_files` | `dir_folder` | `images`（`images` 与 `dir_files` 同义，与 CPU 版 `flicker-detector-server` 一致）。
- **`files`**：`video` 仅允许一个文件且扩展名须为 `.mp4` / `.webm` / `.mov` / `.mkv` / `.avi` / `.m4v`；图片类任务中**每个**文件均须为受支持的图片扩展名，混入其它类型会整单 400。图片任务至少 **4** 帧（GPU PredNet；CPU 服务为至少 2 帧）。
- **`threshold`**（可选）：GPU 版扩展表单字段；CPU 版服务无此项，按 CPU 契约集成的客户端省略即可。

---

## `gpu-flicker-detector-client`（调用服务端）

向运行中的 `gpu-flicker-detector-server` 创建任务、轮询状态，并在结束时打印或写入完整任务 JSON。

### 常用参数

- `--url`：服务根地址，默认 `http://127.0.0.1:8765`
- `--mode`：**`video`** | **`sequence`** | **`folder`**（非法拼写会被 argparse 拒绝；与 CPU C++ 客户端一致）
- `--poll`：轮询间隔（秒），默认 `0.5`
- `--timeout`：等待任务结束的最长时间（秒），默认 `7200`
- `--http-timeout`：单次 HTTP 超时（秒），默认 `60`
- `--upload-timeout`：`POST /api/jobs` 超时（秒），默认 `3600`
- `-o` / `--output`：将最终 JSON 写入文件
- `-q` / `--quiet`：减少输出
- `--skip-health`：跳过启动时的 `GET /api/health`

### 模式与路径要求

- **`video`**：恰好 **1** 个视频路径（扩展名需为客户端识别的视频类型，如 `.mp4` 等）
- **`sequence`**：至少 **4** 个图片路径（按顺序作为帧序列；CPU 客户端为至少 **2** 张，GPU 服务端与 PredNet 要求 **4** 张）
- **`folder`**：恰好 **1** 个目录，递归收集其下图片，至少 **4** 张

### 示例

上传视频并等待结果：

```bash
gpu-flicker-detector-client --mode video -o result.json ./clip.mp4
```

指定远程服务：

```bash
gpu-flicker-detector-client --url http://192.168.1.10:8765 --mode folder -o out.json ./frames_dir
```

### 退出码（便于脚本）

- **`0`**：任务成功完成
- **`1`**：任务结束但状态为失败
- **`2`**：HTTP 错误或响应异常
- **`3`**：命令行路径 / 模式校验失败
- **`4`**：等待结果超时

---

## Web 前端（可选）

前端源码在 [`src/flicker_detector_webui/`](src/flicker_detector_webui/)（与 Python 包 `flash_detector_web` 并列，各自占一个 `src/` 子目录）。本地改 UI 时：

```bash
cd src/flicker_detector_webui
npm install
npm run build
```

生成的 `dist/` 由 `flicker_detector_webui` 的 `package-data` 打入 wheel；在项目根执行 **`FLICKER_DETECTOR_USE_DOCKER=0`** 下的 `gpu-flicker-detector-server` 即可用浏览器打开服务根地址。开发中也可在该目录运行 `npm run dev`（Vite 默认把 `/api` 代理到 `http://127.0.0.1:8765`，需另起后端）。

---

## 许可证与模型

你所使用的 SavedModel 权重与授权以该模型的发布方或许可条款为准；本仓库仅提供推理与工具代码。
