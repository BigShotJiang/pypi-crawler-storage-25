"""py6g - A 6G implementation for Python."""

__version__ = "0.0.1"
