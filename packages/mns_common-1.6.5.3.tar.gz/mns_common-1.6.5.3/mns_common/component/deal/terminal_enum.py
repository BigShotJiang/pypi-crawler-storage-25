from enum import Enum


class TerminalEnum(Enum):
    EASY_TRADER = ('easy_trader', 'easy_trader')
    THS = ('ths', 'ths')
    EM = ('em', '东财')
    QMT = ('qmt', 'qmt')
    TX = ('tx', '腾讯')

    def __init__(self, terminal_code, terminal_name):
        self.terminal_code = terminal_code
        self.terminal_name = terminal_name
