import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)

from loguru import logger
from mns_common.db.MongodbUtil import MongodbUtil
import mns_common.component.common_service_fun_api as common_service_fun_api
import mns_common.utils.data_frame_util as data_frame_util
import mns_common.utils.date_handle_util as date_handle_util

mongodb_util = MongodbUtil('27017')
import mns_common.constant.db_name_constant as db_name_constant


# 获取公司信息
def find_company(symbol_list):
    if len(symbol_list) == 0:
        query = {"deal_days": {"$gte": 60}}
    else:
        query = {
            'symbol': {"$in": symbol_list}}
    query_field = {'symbol': 1, 'name': 1, 'deal_days': 1, 'industry': 1}
    company_info = mongodb_util.find_query_data_choose_field('company_info', query, query_field)
    company_info = common_service_fun_api.exclude_st_symbol(company_info)
    company_info = common_service_fun_api.exclude_change_bjs_code(company_info)
    return company_info


# 获取 k线数据
def get_qfq_k_line_data(symbol, deal_days, end_day):
    query = {'symbol': symbol,
             'date': {"$lte": end_day}
             }
    return mongodb_util.descend_query(query, db_name_constant.STOCK_QFQ_DAILY, 'date', deal_days)


# A字形态判断 前期大涨,现在是下降通道,呈现A字形态,这样的股票 至少60日内排除

#  low_to_high_chg    低点 → 高点涨幅 ≥50%
#  after_peak_days     # 见顶后至少跌3天（形成右腿）
#  high_to_now_limit_chg   # 现价低于高点的15%

def judge_a_shape_stock(symbol,
                        name,
                        stock_qfq_daily_df,
                        deal_days,
                        low_to_high_chg,
                        after_peak_days,
                        high_to_now_limit_chg):
    judge_result_dict = {'symbol': symbol,
                         'name': name,
                         'low_to_high_chg': 0,
                         'high_to_now_chg': 0,
                         'low_to_now_chg': 0,
                         'now_price': 0,
                         'high_price': 0,
                         'low_price': 0,
                         'now_to_peak_days': 0,
                         'low_to_peak_days': 0,
                         'now_to_low_days': 0,

                         'peak_date': '19890604',
                         'low_date': '19890604',
                         'now_date': '19890604',
                         'is_a_shape': False}
    try:
        if data_frame_util.is_empty(stock_qfq_daily_df):
            return judge_result_dict

        stock_qfq_daily_df = stock_qfq_daily_df.sort_values(by=['date'], ascending=True)

        # 获取 前复权 日K线
        df = stock_qfq_daily_df.copy()
        df = df.tail(deal_days).copy()  # 取最近60日
        # 刚上市的股票
        if len(df) < deal_days:
            return judge_result_dict

        stock_qfq_daily_descend_df = stock_qfq_daily_df.sort_values(by=['date'], ascending=False)
        now_data_df = stock_qfq_daily_descend_df.iloc[0]
        # 当前收盘价格
        now_close_price = now_data_df["close"].min()
        now_date = now_data_df['date']

        # ==============================================
        # 【核心修复】严格 A 字逻辑
        # ==============================================
        # 1. 找到60日内最高点 & 位置
        high_price = df["high"].max()
        peak_row = df[df["high"] == high_price].iloc[0]
        peak_date = peak_row["date"]  # 最高点日期
        peak_pos = df.index.get_loc(peak_row.name)

        # ========== 2. 只在最高点左侧找最低点 & 日期 ==========
        df_before = df.iloc[:peak_pos + 1]
        low_price = df_before["low"].min()
        low_row = df_before[df_before["low"] == low_price].iloc[0]
        low_date = low_row["date"]  # 左侧最低点日期

        # ========== 3. 计算涨幅 ========== 左侧涨幅
        # 左侧最低点到最高点涨幅
        rise_rate = float((high_price / low_price) - 1)
        # 右侧最高点到现在涨幅
        high_to_now_chg = float((high_price / now_close_price) - 1)
        # 最低点到现在价格涨幅
        low_to_now_chg = float((now_close_price / low_price) - 1)

        # 左侧最低点到最高点涨幅
        judge_result_dict['low_to_high_chg'] = round(rise_rate * 100, 0)
        judge_result_dict['high_to_now_chg'] = round(-high_to_now_chg * 100, 0)
        judge_result_dict['low_to_now_chg'] = round(low_to_now_chg * 100, 0)
        # 日期设置
        judge_result_dict['peak_date'] = peak_date
        judge_result_dict['low_date'] = low_date
        judge_result_dict['now_date'] = now_date

        judge_result_dict['now_price'] = round(float(now_close_price), 2)
        judge_result_dict['low_price'] = round(float(low_price), 2)
        judge_result_dict['high_price'] = round(float(high_price), 2)

        df_low_index = stock_qfq_daily_df[stock_qfq_daily_df['date'] == low_date].index[0]

        df_now_index = stock_qfq_daily_df[stock_qfq_daily_df['date'] == now_date].index[0]

        df_peak_index = stock_qfq_daily_df[stock_qfq_daily_df['date'] == peak_date].index[0]

        # 计算相隔行数（绝对值，不管顺序）
        now_to_peak_days = int(abs(df_now_index - df_peak_index))
        low_to_peak_days = int(abs(df_peak_index - df_low_index))
        now_to_low_days = int(abs(df_now_index - df_low_index))

        judge_result_dict['now_to_peak_days'] = now_to_peak_days
        judge_result_dict['low_to_peak_days'] = low_to_peak_days
        judge_result_dict['now_to_low_days'] = now_to_low_days

        # 2. 最高点必须出现在“后半段之前”，保证有足够下跌空间
        if peak_pos > deal_days * 0.8:
            return judge_result_dict
        if rise_rate < low_to_high_chg:
            return judge_result_dict

        # 5. 见顶后必须下跌（形成A字右边）
        df_after_peak = df.iloc[peak_pos + 1:]
        if len(df_after_peak) < after_peak_days:
            return judge_result_dict
        current_close = df["close"].iloc[-1]
        if current_close / high_price > high_to_now_limit_chg:
            return judge_result_dict

        judge_result_dict['is_a_shape'] = True

        # logger.info("出现A形状股票:{},{},最高点:{},左侧最低点:{}", symbol, name, peak_date, low_date)
        return judge_result_dict
    except BaseException as e:
        logger.error("计算形状出现异常:{},{},{}", symbol, name, e)


# 分析成交量变化
def analyze_changes_exchange(qfq_k_line_df):
    trading_volume_doubled_df = qfq_k_line_df.loc[qfq_k_line_df['exchange_difference'] >= 2]
    if trading_volume_doubled_df.shape[0] >= 1:
        return True

    else:
        return False


if __name__ == '__main__':
    company_base_info_df = mongodb_util.find_all_data('company_base_info')
    company_base_info_df = company_base_info_df.loc[company_base_info_df['number_workers'] != '--']
    company_base_info_df['number_workers'] = company_base_info_df['number_workers'].astype(float)
    company_base_info_df = company_base_info_df.sort_values(by=['number_workers'], ascending=False)

    # test_now_day()
    end_date_test = '2026-04-03'
    symbol_test = '300302'
    name_test = 'TEST'
    deal_days_test = 60

    qfq_k_line_df_test = get_qfq_k_line_data(symbol_test, deal_days_test,
                                             date_handle_util.no_slash_date(end_date_test))

    qfq_k_line_df_test_exchange = qfq_k_line_df_test[['symbol', 'chg', 'max_chg', 'pct_chg', 'pct_chg_mean',
                                                      'exchange', 'exchange_mean', 'exchange_mean_yesterday',
                                                      'exchange_difference', 'exchange_chg_percent']]
    analyze_changes_exchange(qfq_k_line_df_test_exchange)

    judge_result_dict_test = judge_a_shape_stock(symbol_test,
                                                 name_test,
                                                 qfq_k_line_df_test,
                                                 deal_days_test,
                                                 0.5,
                                                 3,
                                                 0.85)
    print(judge_result_dict_test)
