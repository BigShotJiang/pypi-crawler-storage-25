import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)

import requests
import pandas as pd
from mns_common.constant.price_enum import PriceEnum


def get_tencent_quote_df(stock_code: str) -> pd.DataFrame:
    """
    腾讯免费行情接口 → 返回规整 DataFrame（含五档盘口）
    stock_code 示例：
        深市：sz301531（春光集团）
        沪市：sh600000（浦发银行）
    """
    url = f"http://qt.gtimg.cn/q={stock_code}"
    resp = requests.get(url)
    resp.encoding = "gbk"
    data = resp.text.strip()

    # 解析字符串
    if "~" not in data:
        return pd.DataFrame()

    items = data.split("~")
    result = {
        "symbol": items[2],
        "name": items[1],
        "now_price": float(items[3]),
        "last_close_price": float(items[4]),
        "open": float(items[5]),
        "high": float(items[33]),
        "low": float(items[34]),
        "volume": round(float(items[6]) * 100, 0),
        "outer_disk": round(float(items[7]) * 100, 0),
        "inner_disk": round(float(items[8]) * 100, 0),
        "change_price": float(items[31]),
        "chg": float(items[32]),
        "trade_info": items[35],

        # 买盘五档
        "buy_1": float(items[9]) if items[9] else None,
        "buy_1_vol": float(items[10]) if items[10] else 0,
        "buy_2": float(items[11]) if items[11] else None,
        "buy_2_vol": float(items[12]) if items[12] else 0,
        "buy_3": float(items[13]) if items[13] else None,
        "buy_3_vol": float(items[14]) if items[14] else 0,
        "buy_4": float(items[15]) if items[15] else None,
        "buy_4_vol": float(items[16]) if items[16] else 0,
        "buy_5": float(items[17]) if items[17] else None,
        "buy_5_vol": float(items[18]) if items[18] else 0,

        # 卖盘五档
        "sell_1": float(items[19]) if items[19] else None,
        "sell_1_vol": float(items[20]) if items[20] else 0,
        "sell_2": float(items[21]) if items[21] else None,
        "sell_2_vol": float(items[22]) if items[22] else 0,
        "sell_3": float(items[23]) if items[23] else None,
        "sell_3_vol": float(items[24]) if items[24] else 0,
        "sell_4": float(items[25]) if items[25] else None,
        "sell_4_vol": float(items[26]) if items[26] else 0,
        "sell_5": float(items[27]) if items[27] else None,
        "sell_5_vol": float(items[28]) if items[28] else 0,
    }

    result_df = pd.DataFrame([result])

    result_df['amount'] = round(result_df['trade_info'].str.split('/').str[-1], 2)
    result_df['buy_1_vol'] = round(result_df['buy_1_vol'] * 100, 0)
    result_df['buy_1_amount'] = round(result_df['buy_1_vol'] * result_df['buy_1'], 0)

    result_df['buy_2_vol'] = round(result_df['buy_2_vol'] * 100, 0)
    result_df['buy_2_amount'] = round(result_df['buy_2_vol'] * result_df['buy_2'], 0)

    result_df['buy_3_vol'] = round(result_df['buy_3_vol'] * 100, 0)
    result_df['buy_3_amount'] = round(result_df['buy_3_vol'] * result_df['buy_3'], 0)

    result_df['buy_4_vol'] = round(result_df['buy_4_vol'] * 100, 0)
    result_df['buy_4_amount'] = round(result_df['buy_4_vol'] * result_df['buy_4'], 0)

    result_df['buy_5_vol'] = round(result_df['buy_5_vol'] * 100, 0)
    result_df['buy_5_amount'] = round(result_df['buy_5_vol'] * result_df['buy_5'], 0)

    result_df['sell_1_vol'] = round(result_df['sell_1_vol'] * 100, 0)
    result_df['sell_1_amount'] = round(result_df['sell_1_vol'] * result_df['sell_1'], 0)

    result_df['sell_2_vol'] = round(result_df['sell_2_vol'] * 100, 0)
    result_df['sell_2_amount'] = round(result_df['sell_2_vol'] * result_df['sell_2'], 0)

    result_df['sell_3_vol'] = round(result_df['sell_3_vol'] * 100, 0)
    result_df['sell_3_amount'] = round(result_df['sell_3_vol'] * result_df['sell_3'], 0)

    result_df['sell_4_vol'] = round(result_df['sell_4_vol'] * 100, 0)
    result_df['sell_4_amount'] = round(result_df['sell_4_vol'] * result_df['sell_4'], 0)

    result_df['sell_5_vol'] = round(result_df['sell_5_vol'] * 100, 0)
    result_df['sell_5_amount'] = round(result_df['sell_5_vol'] * result_df['sell_5'], 0)

    result_df["wei_bi"] = round(100 * (
            (result_df["buy_1_vol"] + result_df["buy_2_vol"] + result_df["buy_3_vol"] +
             result_df[
                 "buy_4_vol"] + result_df["buy_5_vol"]) - (
                    result_df["sell_1_vol"] + result_df["sell_2_vol"] + result_df["sell_3_vol"] +
                    result_df[
                        "sell_4_vol"] + result_df["sell_5_vol"])) / (
                                        (result_df["buy_1_vol"] + result_df["buy_2_vol"] +
                                         result_df["buy_3_vol"] +
                                         result_df[
                                             "buy_4_vol"] + result_df["buy_5_vol"]) + (
                                                result_df["sell_1_vol"] + result_df["sell_2_vol"] +
                                                result_df["sell_3_vol"] +
                                                result_df[
                                                    "sell_4_vol"] + result_df["sell_5_vol"])), 0)

    return result_df


def get_tx_trade_price(symbol, price_code, limit_chg):
    result_df = get_tencent_quote_df(symbol)
    wei_bi = list(result_df['wei_bi'])[0]
    now_price = list(result_df['now_price'])[0]
    if wei_bi == PriceEnum.ZT_WEI_BI.price_name:
        trade_price = list(result_df['buy_1'])[0]
    elif wei_bi == PriceEnum.DT_WEI_BI.price_name:
        trade_price = list(result_df['sell_1'])[0]
    elif price_code == PriceEnum.BUY_1.price_code:
        trade_price = list(result_df['buy_1'])[0]
    elif price_code == PriceEnum.BUY_2.price_code:
        trade_price = list(result_df['buy_2'])[0]
    elif price_code == PriceEnum.BUY_3.price_code:
        trade_price = list(result_df['buy_3'])[0]
    elif price_code == PriceEnum.BUY_4.price_code:
        trade_price = list(result_df['buy_4'])[0]
    elif price_code == PriceEnum.BUY_5.price_code:
        trade_price = list(result_df['buy_5'])[0]

    elif price_code == PriceEnum.SELL_1.price_code:
        trade_price = list(result_df['sell_1'])[0]
    elif price_code == PriceEnum.SELL_2.price_code:
        trade_price = list(result_df['sell_2'])[0]
    elif price_code == PriceEnum.SELL_3.price_code:
        trade_price = list(result_df['sell_3'])[0]
    elif price_code == PriceEnum.SELL_4.price_code:
        trade_price = list(result_df['sell_4'])[0]
    elif price_code == PriceEnum.SELL_5.price_code:
        trade_price = list(result_df['sell_5'])[0]

    elif price_code == PriceEnum.BUY_PRICE_LIMIT.price_code:
        trade_price = round(now_price * (1 + limit_chg), 2)
    elif price_code == PriceEnum.SEll_PRICE_LIMIT.price_code:
        trade_price = round(now_price * (1 - limit_chg), 2)

    elif price_code == PriceEnum.ZT_PRICE.price_code:
        trade_price = list(result_df['buy_1'])[0]

    elif price_code == PriceEnum.DT_PRICE.price_code:
        trade_price = list(result_df['sell_1'])[0]
    else:
        trade_price = list(result_df['now_price'])[0]

    trade_price = round(trade_price, 2)
    return trade_price


import time

# ------------------- 测试调用 -------------------
if __name__ == "__main__":
    # 深市：sz + 代码
    # 沪市：sh + 代码
    while True:
        time.sleep(1)
        df = get_tencent_quote_df("sz301310")
        print(df.T)  # 转置打印更清晰
