"""@trace_agent decorator — the primary SDK interface."""
import functools
import traceback
from typing import Optional, Callable
from agent_trace.tracer import AgentTracer
from agent_trace.cost_tracker import estimate_llm_cost


def trace_agent(
    project_id: Optional[str] = None,
    api_key: Optional[str] = None,
    name: Optional[str] = None,
    kind: str = "agent",
    capture_input: bool = True,
    capture_output: bool = True,
):
    """
    Decorator to instrument agent functions with tracing.

    Usage:
        from agent_trace import trace_agent

        @trace_agent(project_id="my-project", api_key="agt_xxxx_yyyy")
        def my_agent(input_text):
            # Your LangChain/LlamaIndex code here
            return result
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            tracer = AgentTracer(project_id=project_id, api_key=api_key)
            span_name = name or func.__name__

            # Capture input
            input_data = {}
            if capture_input:
                if args:
                    input_data["args"] = [str(a)[:500] for a in args]
                if kwargs:
                    input_data["kwargs"] = {k: str(v)[:500] for k, v in kwargs.items()}

            span = tracer.start_span(
                name=span_name,
                kind=kind,
                input_data=input_data,
            )

            try:
                result = func(*args, **kwargs)

                output_data = {}
                if capture_output and result is not None:
                    output_data["result"] = str(result)[:1000]

                tracer.end_span(span, output_data=output_data, status="ok")
                tracer.flush()
                return result

            except Exception as e:
                tracer.end_span(
                    span,
                    status="error",
                    error_message=str(e),
                )
                tracer.flush()
                raise

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            tracer = AgentTracer(project_id=project_id, api_key=api_key)
            span_name = name or func.__name__

            input_data = {}
            if capture_input:
                if args:
                    input_data["args"] = [str(a)[:500] for a in args]
                if kwargs:
                    input_data["kwargs"] = {k: str(v)[:500] for k, v in kwargs.items()}

            span = tracer.start_span(
                name=span_name,
                kind=kind,
                input_data=input_data,
            )

            try:
                result = await func(*args, **kwargs)

                output_data = {}
                if capture_output and result is not None:
                    output_data["result"] = str(result)[:1000]

                tracer.end_span(span, output_data=output_data, status="ok")
                tracer.flush()
                return result

            except Exception as e:
                tracer.end_span(
                    span,
                    status="error",
                    error_message=str(e),
                )
                tracer.flush()
                raise

        import asyncio
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper

    return decorator
