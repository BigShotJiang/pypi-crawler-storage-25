"""HTTP exporter — sends traces to the Agent Obs backend."""
import httpx
from typing import Dict, Any
from agent_trace.config import get_config


class TraceExporter:
    """Exports traces to the Agent Observability backend via HTTP."""

    def __init__(self, api_endpoint: str = "", api_key: str = ""):
        config = get_config()
        self.api_endpoint = api_endpoint or config.api_endpoint
        self.api_key = api_key or config.api_key

    def export(self, trace_data: Dict[str, Any]) -> Dict[str, Any]:
        """Send trace data to the backend /ingest/trace endpoint."""
        try:
            resp = httpx.post(
                f"{self.api_endpoint}/ingest/trace",
                json=trace_data,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=10.0,
            )
            resp.raise_for_status()
            return resp.json()
        except httpx.HTTPStatusError as e:
            return {
                "success": False,
                "message": f"HTTP {e.response.status_code}: {e.response.text}",
            }
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def export_async(self, trace_data: Dict[str, Any]) -> Dict[str, Any]:
        """Async version of export."""
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.post(
                    f"{self.api_endpoint}/ingest/trace",
                    json=trace_data,
                    headers={"Authorization": f"Bearer {self.api_key}"},
                    timeout=10.0,
                )
                resp.raise_for_status()
                return resp.json()
        except Exception as e:
            return {"success": False, "message": str(e)}
