"""SDK Configuration."""
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class TraceConfig:
    """Configuration for the Agent Trace SDK."""
    api_endpoint: str = "http://localhost:8000"
    api_key: str = ""
    project_id: str = ""
    auto_flush: bool = True
    flush_interval_seconds: float = 5.0
    max_batch_size: int = 100
    redact_pii: bool = True
    capture_inputs: bool = True
    capture_outputs: bool = True
    enabled: bool = True

    def validate(self):
        if not self.api_key:
            raise ValueError("api_key is required. Generate one at /auth/api-keys")
        if not self.project_id:
            raise ValueError("project_id is required. Create a project first.")


# Global config singleton
_config: Optional[TraceConfig] = None


def configure(**kwargs) -> TraceConfig:
    """Configure the SDK globally."""
    global _config
    _config = TraceConfig(**kwargs)
    return _config


def get_config() -> TraceConfig:
    global _config
    if _config is None:
        _config = TraceConfig()
    return _config
