"""LLM cost estimation for common providers."""

# Cost per 1K tokens (USD) — approximate as of 2024
LLM_PRICING = {
    "gpt-4": {"input": 0.03, "output": 0.06},
    "gpt-4-turbo": {"input": 0.01, "output": 0.03},
    "gpt-4o": {"input": 0.005, "output": 0.015},
    "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
    "claude-3-opus": {"input": 0.015, "output": 0.075},
    "claude-3-sonnet": {"input": 0.003, "output": 0.015},
    "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
    "claude-3.5-sonnet": {"input": 0.003, "output": 0.015},
    "gemini-pro": {"input": 0.0005, "output": 0.0015},
    "gemini-1.5-pro": {"input": 0.00125, "output": 0.005},
    "llama-3-70b": {"input": 0.00059, "output": 0.00079},
    "llama-3-8b": {"input": 0.00005, "output": 0.00008},
    "mixtral-8x7b": {"input": 0.00024, "output": 0.00024},
}


def estimate_llm_cost(
    model: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
) -> float:
    """Estimate cost for an LLM call in USD."""
    # Normalize model name
    model_lower = model.lower()
    pricing = None

    for key in LLM_PRICING:
        if key in model_lower:
            pricing = LLM_PRICING[key]
            break

    if not pricing:
        # Default fallback — assume GPT-4o-mini pricing
        pricing = LLM_PRICING["gpt-4o-mini"]

    cost = (input_tokens / 1000 * pricing["input"]) + (output_tokens / 1000 * pricing["output"])
    return round(cost, 6)


def estimate_cost_from_text(model: str, input_text: str = "", output_text: str = "") -> float:
    """Estimate cost from text (rough token approximation: 1 token ≈ 4 chars)."""
    input_tokens = len(input_text) // 4
    output_tokens = len(output_text) // 4
    return estimate_llm_cost(model, input_tokens, output_tokens)
