"""Core tracer — collects spans and builds traces."""
import uuid
import time
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from agent_trace.config import get_config


@dataclass
class SpanData:
    """Represents a single span in a trace."""
    span_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    parent_span_id: Optional[str] = None
    name: str = ""
    kind: str = "custom"
    status: str = "ok"
    latency_ms: float = 0.0
    cost_usd: float = 0.0
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    attributes: Dict[str, Any] = field(default_factory=dict)
    error_message: Optional[str] = None
    started_at: Optional[str] = None
    ended_at: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
            "name": self.name,
            "kind": self.kind,
            "status": self.status,
            "latency_ms": self.latency_ms,
            "cost_usd": self.cost_usd,
            "input": self.input_data,
            "output": self.output_data,
            "attributes": self.attributes,
            "error_message": self.error_message,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
        }


class AgentTracer:
    """Collects spans and sends trace data to the backend."""

    def __init__(self, project_id: Optional[str] = None, api_key: Optional[str] = None):
        self.config = get_config()
        self.project_id = project_id or self.config.project_id
        self.api_key = api_key or self.config.api_key
        self.trace_id = uuid.uuid4().hex[:32]
        self.spans: List[SpanData] = []
        self._current_span: Optional[SpanData] = None
        self._span_stack: List[SpanData] = []

    def start_span(
        self,
        name: str,
        kind: str = "custom",
        input_data: Optional[Dict] = None,
        attributes: Optional[Dict] = None,
    ) -> SpanData:
        """Start a new span."""
        parent_id = self._span_stack[-1].span_id if self._span_stack else None
        span = SpanData(
            name=name,
            kind=kind,
            parent_span_id=parent_id,
            input_data=input_data or {},
            attributes=attributes or {},
            started_at=datetime.now(timezone.utc).isoformat(),
        )
        self._span_stack.append(span)
        self._current_span = span
        return span

    def end_span(
        self,
        span: SpanData,
        output_data: Optional[Dict] = None,
        status: str = "ok",
        error_message: Optional[str] = None,
        cost_usd: float = 0.0,
    ):
        """End a span and record its data."""
        span.ended_at = datetime.now(timezone.utc).isoformat()
        span.status = status
        span.output_data = output_data or {}
        span.error_message = error_message
        span.cost_usd = cost_usd

        if span.started_at:
            start = datetime.fromisoformat(span.started_at)
            end = datetime.fromisoformat(span.ended_at)
            span.latency_ms = (end - start).total_seconds() * 1000

        self.spans.append(span)
        if self._span_stack and self._span_stack[-1] == span:
            self._span_stack.pop()
        self._current_span = self._span_stack[-1] if self._span_stack else None

    def flush(self) -> dict:
        """Send the collected trace to the backend."""
        if not self.spans:
            return {"success": False, "message": "No spans to flush"}

        payload = {
            "trace_id": self.trace_id,
            "project_id": self.project_id,
            "name": self.spans[0].name if self.spans else "unnamed-trace",
            "status": "failed" if any(s.status == "error" for s in self.spans) else "completed",
            "spans": [s.to_dict() for s in self.spans],
            "started_at": self.spans[0].started_at,
            "ended_at": self.spans[-1].ended_at,
            "metadata": {},
        }

        try:
            import httpx
            headers = {"Authorization": f"Bearer {self.api_key}"}
            resp = httpx.post(
                f"{self.config.api_endpoint}/ingest/trace",
                json=payload,
                headers=headers,
                timeout=10.0,
            )
            return resp.json()
        except Exception as e:
            return {"success": False, "message": str(e)}
