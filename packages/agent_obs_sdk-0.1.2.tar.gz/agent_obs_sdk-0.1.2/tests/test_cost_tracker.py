"""SDK tests."""
from agent_trace.cost_tracker import estimate_llm_cost, estimate_cost_from_text


def test_gpt4_cost():
    cost = estimate_llm_cost("gpt-4", input_tokens=1000, output_tokens=500)
    assert cost > 0
    assert cost == round(1000 / 1000 * 0.03 + 500 / 1000 * 0.06, 6)


def test_gpt4o_mini_cost():
    cost = estimate_llm_cost("gpt-4o-mini", input_tokens=1000, output_tokens=1000)
    assert cost > 0
    assert cost < 0.01  # Very cheap


def test_unknown_model_fallback():
    cost = estimate_llm_cost("unknown-model-xyz", input_tokens=1000, output_tokens=1000)
    assert cost > 0  # Falls back to GPT-4o-mini pricing


def test_estimate_from_text():
    cost = estimate_cost_from_text("gpt-4", input_text="Hello " * 100, output_text="World " * 50)
    assert cost > 0


def test_zero_tokens():
    cost = estimate_llm_cost("gpt-4", input_tokens=0, output_tokens=0)
    assert cost == 0
