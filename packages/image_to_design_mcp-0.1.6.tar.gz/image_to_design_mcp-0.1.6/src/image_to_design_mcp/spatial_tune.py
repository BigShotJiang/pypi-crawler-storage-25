from __future__ import annotations

from typing import Any

from image_to_design_mcp.client import IMPORT_STATUS_LABELS, ApiClient, status_label
from image_to_design_mcp.config import Settings, get_settings
from image_to_design_mcp.errors import ImageToDesignError
from image_to_design_mcp.models import ImageToDesignJob


class SpatialTuneApi:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

    async def start(self, job: ImageToDesignJob) -> str:
        point_cloud_url = job.artifacts.pointCloudPlyUrl
        if not point_cloud_url:
            raise ImageToDesignError("missing_point_cloud", "缺少点云 PLY，无法执行空间调整")

        async with ApiClient(settings=self.settings) as client:
            task_id = await client.post("/kam/api/spatial-tune/import", json={"pointCloudUrl": point_cloud_url})
        if not isinstance(task_id, str) or not task_id.strip():
            raise ImageToDesignError(
                "spatial_tune_submit_error",
                "提交空间调整任务失败，未返回 task_id",
                details={"response": task_id, "point_cloud_url": point_cloud_url},
            )
        return task_id.strip()

    async def get_status(self, task_id: str) -> dict[str, Any]:
        data = await self._get_status(task_id)
        status = _coerce_int(data.get("status"))
        if status == 0:
            return {"done": False, "message": data.get("message") or status_label(IMPORT_STATUS_LABELS, status)}
        if status != 1:
            raise self._status_error(task_id=task_id, status=status, data=data)

        return {
            "done": True,
            "message": data.get("message") or "空间调整完成",
            "rotate": _require_float(data, "rotate", task_id=task_id),
            "bottom_position": _require_point(data, "bottomPosition", task_id=task_id),
            "top_position": _require_point(data, "topPosition", task_id=task_id),
        }

    async def _get_status(self, task_id: str) -> dict[str, Any]:
        async with ApiClient(settings=self.settings) as client:
            data = await client.get("/kam/api/spatial-tune/status", params={"taskId": task_id})
        if not isinstance(data, dict):
            raise ImageToDesignError(
                "spatial_tune_status_error",
                "查询空间调整状态失败，返回结构异常",
                details={"task_id": task_id, "response": data},
            )
        return data

    def _status_error(self, *, task_id: str, status: int | None, data: dict[str, Any]) -> ImageToDesignError:
        return ImageToDesignError(
            "spatial_tune_failed",
            f"spatial_tune 任务失败，状态: {status_label(IMPORT_STATUS_LABELS, status)}",
            details={"task_id": task_id, "status": status, "response": data},
        )


def _coerce_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _require_float(payload: dict[str, Any], key: str, *, task_id: str) -> float:
    value = payload.get(key)
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ImageToDesignError(
            "invalid_result_field",
            f"spatial_tune 返回字段 {key} 不是数字",
            details={"task_id": task_id, "key": key, "value": value, "response": payload},
        ) from exc


def _require_point(payload: dict[str, Any], key: str, *, task_id: str) -> dict[str, float]:
    value = payload.get(key)
    if not isinstance(value, dict):
        raise ImageToDesignError(
            "missing_result_field",
            f"spatial_tune 返回字段 {key} 为空",
            details={"task_id": task_id, "key": key, "response": payload},
        )
    return {
        "x": _require_float(value, "x", task_id=task_id),
        "y": _require_float(value, "y", task_id=task_id),
        "z": _require_float(value, "z", task_id=task_id),
    }
