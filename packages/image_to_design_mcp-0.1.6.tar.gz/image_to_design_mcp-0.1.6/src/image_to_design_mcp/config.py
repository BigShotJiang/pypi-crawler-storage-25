from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from dotenv import dotenv_values

from image_to_design_mcp.errors import ImageToDesignError


PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_ENV_FILE = PROJECT_ROOT / ".env"
ENV_PREFIX = "IMAGE_TO_DESIGN_"


@dataclass(frozen=True)
class Settings:
    base_url: str
    cookie_file: Path
    upload_guid: str
    http_timeout_seconds: float
    max_poll_seconds: float
    upload_poll_interval_seconds: float
    job_state_dir: Path
    job_retention_hours: int


_env_loaded = False


def _load_env_once() -> None:
    global _env_loaded
    if _env_loaded:
        return

    protected_keys = set(os.environ)
    candidates: list[Path] = [DEFAULT_ENV_FILE]

    explicit = os.getenv(f"{ENV_PREFIX}ENV_FILE")
    if explicit:
        candidates.append(Path(explicit).expanduser())

    for env_file in candidates:
        if not env_file.is_file():
            continue
        for key, value in dotenv_values(env_file).items():
            if value is None or key in protected_keys:
                continue
            os.environ[key] = value

    _env_loaded = True


def _get_env(name: str, default: str | None = None) -> str | None:
    _load_env_once()
    value = os.getenv(f"{ENV_PREFIX}{name}")
    if value is None:
        return default
    value = value.strip()
    return value or default


def _get_required_path(name: str) -> Path:
    value = _get_env(name)
    if not value:
        raise ImageToDesignError(
            "missing_config",
            f"缺少配置项: {ENV_PREFIX}{name}",
            details={"config": f"{ENV_PREFIX}{name}"},
            recoverable=False,
        )
    return Path(value).expanduser()


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    base_url = (_get_env("BASE_URL", "https://beta.kujiale.com") or "https://beta.kujiale.com").rstrip("/")
    job_state_dir = Path(
        _get_env("JOB_STATE_DIR", "~/.image-to-design-mcp/jobs") or "~/.image-to-design-mcp/jobs"
    ).expanduser()

    return Settings(
        base_url=base_url,
        cookie_file=_get_required_path("COOKIE_FILE"),
        upload_guid=_get_env("UPLOAD_GUID", "bim-floorplan-upload-image") or "bim-floorplan-upload-image",
        http_timeout_seconds=float(_get_env("HTTP_TIMEOUT_SECONDS", "30") or "30"),
        max_poll_seconds=float(_get_env("MAX_POLL_SECONDS", "120") or "120"),
        upload_poll_interval_seconds=float(_get_env("UPLOAD_POLL_INTERVAL_SECONDS", "1") or "1"),
        job_state_dir=job_state_dir,
        job_retention_hours=int(_get_env("JOB_RETENTION_HOURS", "72") or "72"),
    )
