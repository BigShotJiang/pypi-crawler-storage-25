from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from pydantic import ValidationError

from image_to_design_mcp.config import Settings, get_settings
from image_to_design_mcp.errors import ImageToDesignError
from image_to_design_mcp.models import ImageToDesignJob


class JobStore:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.root = self.settings.job_state_dir.expanduser()
        self.root.mkdir(parents=True, exist_ok=True)

    def create(self, job: ImageToDesignJob) -> ImageToDesignJob:
        self.save(job)
        return job

    def save(self, job: ImageToDesignJob) -> ImageToDesignJob:
        file_path = self._file_path(job.id)
        temp_path = file_path.with_suffix(".json.tmp")
        temp_path.write_text(job.model_dump_json(indent=2), encoding="utf-8")
        temp_path.replace(file_path)
        return job

    def get(self, job_id: str) -> ImageToDesignJob:
        file_path = self._file_path(job_id)
        if not file_path.is_file():
            raise ImageToDesignError(
                "job_not_found",
                f"未找到 job: {job_id}",
                details={"job_id": job_id},
                recoverable=False,
            )

        try:
            return ImageToDesignJob.model_validate_json(file_path.read_text(encoding="utf-8"))
        except ValidationError as exc:
            raise ImageToDesignError(
                "job_state_corrupted",
                f"job 状态文件损坏: {job_id}",
                details={"job_id": job_id, "reason": str(exc)},
                recoverable=False,
            ) from exc

    def list(self, *, limit: int = 20) -> list[ImageToDesignJob]:
        self.cleanup_expired()
        jobs: list[tuple[float, ImageToDesignJob]] = []
        for file_path in self.root.glob("*.json"):
            try:
                job = ImageToDesignJob.model_validate_json(file_path.read_text(encoding="utf-8"))
            except ValidationError:
                continue
            jobs.append((file_path.stat().st_mtime, job))

        jobs.sort(key=lambda item: item[0], reverse=True)
        return [job for _, job in jobs[:limit]]

    def cleanup_expired(self) -> None:
        retention = timedelta(hours=self.settings.job_retention_hours)
        deadline = datetime.now(timezone.utc) - retention
        for file_path in self.root.glob("*.json"):
            try:
                job = ImageToDesignJob.model_validate_json(file_path.read_text(encoding="utf-8"))
            except ValidationError:
                continue
            if job.updated_at < deadline:
                file_path.unlink(missing_ok=True)

    def _file_path(self, job_id: str) -> Path:
        return self.root / f"{job_id}.json"
