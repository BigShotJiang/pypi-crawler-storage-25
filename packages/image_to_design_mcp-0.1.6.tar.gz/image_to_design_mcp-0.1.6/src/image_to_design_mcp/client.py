from __future__ import annotations

import http.cookiejar
from pathlib import Path
from typing import Any

import httpx

from image_to_design_mcp.config import Settings, get_settings
from image_to_design_mcp.errors import ImageToDesignError


IMPORT_STATUS_LABELS = {
    0: "PROCESSING",
    1: "SUCCESS",
    2: "FAILURE",
    3: "ACCEPTABLEFAILURE",
    4: "TIMEOUT",
}

MAAS_STATUS_LABELS = {
    0: "PROCESSING",
    1: "SUCCESS",
    2: "FAILURE",
    3: "TIMEOUT",
}

GAUSS_SHOW_STATUS_LABELS = {
    0: "NOT_EXIST",
    1: "GENERATING",
    2: "DONE",
    3: "FAILED",
}


def load_cookie_header(cookie_path: Path) -> str:
    if not cookie_path.exists():
        raise ImageToDesignError(
            "missing_cookie_file",
            f"Cookie 文件不存在: {cookie_path}",
            details={"cookie_file": str(cookie_path)},
            recoverable=False,
        )

    jar = http.cookiejar.MozillaCookieJar(str(cookie_path))
    jar.load(ignore_discard=True, ignore_expires=True)
    cookies = [f"{cookie.name}={cookie.value}" for cookie in jar if "kujiale.com" in cookie.domain]
    if not cookies:
        raise ImageToDesignError(
            "empty_cookie",
            "Cookie 文件中没有可用于 kujiale.com 的 cookie",
            details={"cookie_file": str(cookie_path)},
            recoverable=False,
        )
    return "; ".join(cookies)


def is_result_success(flag: Any) -> bool:
    return flag in (True, "0", 0, "true")


def status_label(labels: dict[int, str], status: int | None) -> str:
    if status is None:
        return "UNKNOWN"
    return labels.get(status, f"UNKNOWN_{status}")


class ApiClient:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.cookie_header = load_cookie_header(self.settings.cookie_file)
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "ApiClient":
        self._client = httpx.AsyncClient(
            timeout=self.settings.http_timeout_seconds,
            follow_redirects=False,
            headers={
                "accept": "application/json, text/plain, */*",
                "cookie": self.cookie_header,
            },
        )
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("ApiClient 未初始化，请使用 async with")
        return self._client

    async def get(self, path: str, *, params: dict[str, Any] | None = None, headers: dict[str, str] | None = None) -> Any:
        return await self._request("GET", path, params=params, headers=headers)

    async def post(
        self,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        return await self._request("POST", path, json=json, params=params, headers=headers)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        url = f"{self.settings.base_url}{path}"
        try:
            response = await self.client.request(method, url, json=json, params=params, headers=headers)
        except httpx.TimeoutException as exc:
            raise ImageToDesignError("network_timeout", f"请求超时: {path}", details={"path": path}) from exc
        except httpx.HTTPError as exc:
            raise ImageToDesignError("network_error", f"网络请求失败: {path}", details={"path": path, "reason": str(exc)}) from exc

        if response.status_code in (301, 302, 303, 307, 308):
            raise ImageToDesignError(
                "auth_redirect",
                "请求被重定向，请检查 cookie 或站点环境",
                details={"path": path, "location": response.headers.get("location", "")},
                recoverable=False,
            )
        if response.status_code in (401, 403):
            raise ImageToDesignError(
                "auth_failed",
                "请求被拒绝，请检查 cookie 是否有效",
                details={"path": path, "status_code": response.status_code},
                recoverable=False,
            )
        if response.status_code >= 400:
            raise ImageToDesignError(
                "http_error",
                f"HTTP 请求失败: {response.status_code}",
                details={"path": path, "status_code": response.status_code, "body": response.text[:1000]},
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise ImageToDesignError(
                "invalid_json",
                f"接口返回了不可解析的 JSON: {path}",
                details={"path": path, "body": response.text[:1000]},
            ) from exc

        if not is_result_success(payload.get("c")):
            raise ImageToDesignError(
                "api_error",
                payload.get("m") or "接口返回失败",
                details={"path": path, "response": payload},
            )
        return payload.get("d")
