from mcp.server.fastmcp import FastMCP

from image_to_design_mcp.toolset import register_tools


def create_server() -> FastMCP:
    mcp = FastMCP("gauss-mcp")
    register_tools(mcp)
    return mcp


def main() -> None:
    create_server().run()


if __name__ == "__main__":
    main()
