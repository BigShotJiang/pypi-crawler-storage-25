from __future__ import annotations

import asyncio
import hashlib
import mimetypes
import time
from pathlib import Path
from typing import Any

import httpx

from image_to_design_mcp.client import is_result_success, load_cookie_header
from image_to_design_mcp.config import Settings, get_settings
from image_to_design_mcp.errors import ImageToDesignError


def file_md5(file_path: Path) -> str:
    digest = hashlib.md5()
    with file_path.open("rb") as file_obj:
        for chunk in iter(lambda: file_obj.read(8192), b""):
            digest.update(chunk)
    return digest.hexdigest()


class ImageUploader:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()
        self.cookie_header = load_cookie_header(self.settings.cookie_file)
        self._client: httpx.AsyncClient | None = None
        self._token: str | None = None
        self._domain: str | None = None

    async def __aenter__(self) -> "ImageUploader":
        self._client = httpx.AsyncClient(timeout=max(self.settings.http_timeout_seconds, 120.0), follow_redirects=False)
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("ImageUploader 未初始化，请使用 async with")
        return self._client

    async def upload(self, local_path: str | Path) -> dict[str, Any]:
        file_path = Path(local_path).expanduser().resolve()
        if not file_path.exists() or not file_path.is_file():
            raise ImageToDesignError(
                "missing_local_file",
                f"本地文件不存在: {file_path}",
                details={"local_path": str(file_path)},
                recoverable=False,
            )

        token, domain = await self._ensure_token()
        obs_task_id = await self._upload_file(file_path, token, domain)
        image_url = await self._poll_upload_status(obs_task_id, token, domain)
        return {
            "local_path": str(file_path),
            "task_id": obs_task_id,
            "image_url": image_url,
            "domain": domain,
        }

    async def _ensure_token(self) -> tuple[str, str]:
        if self._token and self._domain:
            return self._token, self._domain

        response = await self.client.post(
            f"{self.settings.base_url}/ous/api/token/generate",
            content=b"",
            headers={
                "content-type": "application/json",
                "accept": "*/*",
                "origin": self.settings.base_url,
                "referer": f"{self.settings.base_url}/cloud/tool/h5/bim",
                "cookie": self.cookie_header,
            },
        )
        if response.status_code in (301, 302, 303, 307, 308):
            raise ImageToDesignError("auth_redirect", "上传 token 请求被重定向，请检查 cookie 或站点环境", details={"location": response.headers.get("location", "")}, recoverable=False)
        if response.status_code in (401, 403):
            raise ImageToDesignError("auth_failed", "上传 token 请求被拒绝，请检查 cookie 是否有效", details={"status_code": response.status_code}, recoverable=False)
        response.raise_for_status()

        payload = response.json()
        if not is_result_success(payload.get("c")):
            raise ImageToDesignError("upload_token_error", payload.get("m") or "获取上传 token 失败", details={"response": payload})

        data = payload.get("d") or {}
        token = data.get("ousToken")
        domain = (data.get("globalDomain") or "").rstrip("/")
        if not token or not domain:
            raise ImageToDesignError("upload_token_error", "上传 token 返回缺少 ousToken 或 globalDomain", details={"response": payload})

        self._token = token
        self._domain = domain
        return token, domain

    async def _upload_file(self, file_path: Path, token: str, domain: str) -> str:
        mime_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        with file_path.open("rb") as file_obj:
            response = await self.client.post(
                f"{domain}/ous/api/single/upload",
                data={"guid": self.settings.upload_guid, "md5": file_md5(file_path)},
                files={"file": (file_path.name, file_obj, mime_type)},
                headers={
                    "accept": "*/*",
                    "origin": self.settings.base_url,
                    "referer": f"{self.settings.base_url}/",
                    "ous-token": token,
                },
            )
        response.raise_for_status()
        payload = response.json()
        if not is_result_success(payload.get("c")):
            raise ImageToDesignError("upload_error", payload.get("m") or "上传文件失败", details={"response": payload, "local_path": str(file_path)})

        task_id = (payload.get("d") or {}).get("obsTaskId")
        if not task_id:
            raise ImageToDesignError("upload_error", "上传成功但未返回 obsTaskId", details={"response": payload, "local_path": str(file_path)})
        return task_id

    async def _poll_upload_status(self, obs_task_id: str, token: str, domain: str) -> str:
        started_at = time.monotonic()
        while True:
            if time.monotonic() - started_at > self.settings.max_poll_seconds:
                raise ImageToDesignError("upload_timeout", "上传状态轮询超时", details={"task_id": obs_task_id})

            response = await self.client.get(
                f"{domain}/ous/api/upload/status",
                params={"obstaskid": obs_task_id},
                headers={
                    "accept": "*/*",
                    "content-type": "application/json",
                    "origin": self.settings.base_url,
                    "referer": f"{self.settings.base_url}/",
                    "ous-token": token,
                },
            )
            response.raise_for_status()
            payload = response.json()
            if not is_result_success(payload.get("c")):
                raise ImageToDesignError("upload_status_error", payload.get("m") or "查询上传状态失败", details={"response": payload, "task_id": obs_task_id})

            data = payload.get("d") or {}
            status = data.get("status")
            if status == 5:
                image_url = data.get("url")
                if not image_url:
                    raise ImageToDesignError("upload_status_error", "上传任务成功但未返回 URL", details={"response": payload, "task_id": obs_task_id})
                return image_url
            if status not in (0, 1, 2, 3, 4):
                raise ImageToDesignError("upload_failed", f"上传任务失败，状态码: {status}", details={"response": payload, "task_id": obs_task_id})

            await asyncio.sleep(self.settings.upload_poll_interval_seconds)


async def upload_local_image(local_path: str, *, settings: Settings | None = None) -> dict[str, Any]:
    async with ImageUploader(settings=settings) as uploader:
        return await uploader.upload(local_path)
