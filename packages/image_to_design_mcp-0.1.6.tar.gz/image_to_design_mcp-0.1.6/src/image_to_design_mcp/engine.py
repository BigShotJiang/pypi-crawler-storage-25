from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Awaitable, Callable, Protocol

from image_to_design_mcp.errors import ImageToDesignError
from image_to_design_mcp.models import (
    EventType,
    ImageToDesignJob,
    JobErrorState,
    JobEvent,
    JobStatus,
    StageName,
    StageState,
    StageStatus,
    STAGE_SEQUENCE,
)
from image_to_design_mcp.store import JobStore


class MaasService(Protocol):
    async def start_image_type(self, *, image_url: str) -> str: ...

    async def get_image_type(self, task_id: str) -> dict[str, Any]: ...

    async def start_img2pano(self, *, image_url: str) -> str: ...

    async def get_img2pano(self, task_id: str) -> dict[str, Any]: ...

    async def start_pano_clear(self, *, image_url: str) -> str: ...

    async def get_pano_clear(self, task_id: str) -> dict[str, Any]: ...

    async def start_pano2pointcloud(self, *, image_url: str) -> str: ...

    async def get_pano2pointcloud(self, task_id: str) -> dict[str, Any]: ...


class SpatialTuneService(Protocol):
    async def start(self, job: ImageToDesignJob) -> str: ...

    async def get_status(self, task_id: str) -> dict[str, Any]: ...


class GaussImportService(Protocol):
    async def start(self, job: ImageToDesignJob) -> str: ...

    async def get_status(self, task_id: str) -> dict[str, Any]: ...

    async def get_show_info(self, job: ImageToDesignJob) -> dict[str, Any]: ...


UploadFunc = Callable[[str], Awaitable[dict[str, Any]]]


DEFAULT_POLL_INTERVALS = {
    StageName.upload: 3,
    StageName.image_type: 3,
    StageName.img2pano: 15,
    StageName.pano_clear: 15,
    StageName.pano2pointcloud: 30,
    StageName.spatial_tune: 30,
    StageName.gauss_import: 30,
    StageName.gauss_show_info: 30,
}


@dataclass(slots=True)
class PollResult:
    job: ImageToDesignJob
    events: list[JobEvent]
    next_poll_after_sec: int | None


@dataclass(slots=True)
class StageAction:
    continue_now: bool
    next_poll_after_sec: int | None = None

    @classmethod
    def advance(cls) -> "StageAction":
        return cls(continue_now=True)

    @classmethod
    def wait(cls, next_poll_after_sec: int | None) -> "StageAction":
        return cls(continue_now=False, next_poll_after_sec=next_poll_after_sec)


class JobEngine:
    def __init__(
        self,
        *,
        store: JobStore,
        uploader: UploadFunc,
        maas: MaasService,
        spatial_tune: SpatialTuneService,
        gauss_import: GaussImportService,
    ) -> None:
        self.store = store
        self.uploader = uploader
        self.maas = maas
        self.spatial_tune = spatial_tune
        self.gauss_import = gauss_import

    def create_job(
        self,
        *,
        local_path: str,
        clear_furniture: bool | None = True,
        floor_plan_name: str | None = None,
        level_height_mm: float | None = 2800.0,
    ) -> ImageToDesignJob:
        resolved = Path(local_path).expanduser().resolve()
        if not resolved.exists() or not resolved.is_file():
            raise ImageToDesignError(
                "missing_local_file",
                f"本地文件不存在: {resolved}",
                details={"local_path": str(resolved)},
                recoverable=False,
            )

        job = ImageToDesignJob.new(
            local_path=str(resolved),
            clear_furniture=clear_furniture,
            floor_plan_name=floor_plan_name,
            level_height_mm=level_height_mm,
        )
        job.add_event(EventType.job_started, "job 已创建，等待开始处理")
        self.store.create(job)
        return job

    def get_job(self, job_id: str) -> ImageToDesignJob:
        return self.store.get(job_id)

    def list_jobs(self, *, limit: int = 20) -> list[ImageToDesignJob]:
        return self.store.list(limit=limit)

    def update_job_inputs(
        self,
        job_id: str,
        *,
        clear_furniture: bool | None = None,
        level_height_mm: float | None = None,
    ) -> ImageToDesignJob:
        if clear_furniture is None and level_height_mm is None:
            raise ImageToDesignError(
                "missing_job_inputs",
                "至少提供一个待更新的输入参数",
                recoverable=False,
            )

        job = self.store.get(job_id)
        if clear_furniture is not None:
            self._update_clear_furniture(job, clear_furniture)
        if level_height_mm is not None:
            self._update_level_height(job, level_height_mm)
        self.store.save(job)
        return job

    async def poll_job(self, job_id: str) -> PollResult:
        job = self.store.get(job_id)
        events: list[JobEvent] = []

        if job.status == JobStatus.succeeded:
            return PollResult(job=job, events=events, next_poll_after_sec=None)
        if job.status == JobStatus.failed:
            return PollResult(job=job, events=events, next_poll_after_sec=None)

        job.status = JobStatus.running
        self._touch_job(job)
        self.store.save(job)

        for _ in range(len(STAGE_SEQUENCE) + 1):
            stage = job.stage(job.current_stage)
            action = await self._handle_stage(job, stage, events)
            self.store.save(job)

            if job.status in (JobStatus.failed, JobStatus.succeeded):
                return PollResult(job=job, events=events, next_poll_after_sec=None)
            if not action.continue_now:
                return PollResult(job=job, events=events, next_poll_after_sec=action.next_poll_after_sec)

        return PollResult(job=job, events=events, next_poll_after_sec=self._next_poll_interval(job.current_stage))

    async def resume_job(self, job_id: str) -> PollResult:
        job = self.store.get(job_id)
        if job.status != JobStatus.failed:
            return await self.poll_job(job_id)

        if job.error is not None and not job.error.recoverable:
            raise ImageToDesignError(
                "job_not_recoverable",
                "当前 job 不可恢复，请修正配置或输入后重试",
                details={"job_id": job.id, "error": job.error.model_dump()},
                recoverable=False,
            )

        stage = job.stage(job.current_stage)
        job.status = JobStatus.running
        job.error = None
        stage.message = None
        stage.completed_at = None
        if stage.backend_task_id:
            stage.status = StageStatus.running
        else:
            stage.status = StageStatus.pending
        self._touch_stage(job, stage)
        self.store.save(job)
        return await self.poll_job(job_id)

    async def _handle_stage(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        try:
            if stage.name == StageName.upload:
                return await self._handle_upload(job, stage, events)
            if stage.name == StageName.image_type:
                return await self._handle_image_type(job, stage, events)
            if stage.name == StageName.img2pano:
                return await self._handle_img2pano(job, stage, events)
            if stage.name == StageName.pano_clear:
                return await self._handle_pano_clear(job, stage, events)
            if stage.name == StageName.pano2pointcloud:
                return await self._handle_pano2pointcloud(job, stage, events)
            if stage.name == StageName.spatial_tune:
                return await self._handle_spatial_tune(job, stage, events)
            if stage.name == StageName.gauss_import:
                return await self._handle_gauss_import(job, stage, events)
            if stage.name == StageName.gauss_show_info:
                return await self._handle_gauss_show_info(job, stage, events)
        except ImageToDesignError as exc:
            self._fail_stage(job, stage, events, exc)
            return StageAction.wait(next_poll_after_sec=0)
        except Exception as exc:  # pragma: no cover - defensive fallback
            self._fail_stage(
                job,
                stage,
                events,
                ImageToDesignError(
                    "internal_error",
                    f"阶段执行异常: {stage.name}",
                    details={"stage": stage.name, "reason": str(exc)},
                ),
            )
            return StageAction.wait(next_poll_after_sec=0)

        raise ImageToDesignError(
            "unknown_stage",
            f"未知阶段: {stage.name}",
            details={"stage": stage.name},
            recoverable=False,
        )

    async def _handle_upload(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        self._start_stage(job, stage, events, "开始上传本地图片")
        result = await self.uploader(job.local_path)
        job.artifacts.originImgUrl = result["image_url"]
        stage.backend_task_id = result.get("task_id")
        self._succeed_stage(job, stage, events, "图片上传完成")
        self._advance_to_next_stage(job, stage.name)
        return StageAction.advance()

    async def _handle_image_type(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        image_url = job.artifacts.originImgUrl
        if not image_url:
            raise ImageToDesignError("missing_origin_image", "缺少 originImgUrl，无法判断图片类型")

        async def submit() -> str:
            return await self.maas.start_image_type(image_url=image_url)

        def apply(result: dict[str, Any]) -> None:
            is_pano = bool(result["is_pano"])
            job.artifacts.isOriginImgPano = is_pano
            if is_pano:
                job.artifacts.panoImgUrl = image_url

        return await self._run_remote_stage(
            job,
            stage,
            events,
            submit=submit,
            check=self.maas.get_image_type,
            apply=apply,
            stage_start_message="开始判断图片是否为全景图",
            stage_success_message="图片类型判断完成",
        )

    async def _handle_img2pano(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        if job.artifacts.isOriginImgPano:
            if not job.artifacts.panoImgUrl:
                job.artifacts.panoImgUrl = job.artifacts.originImgUrl
            self._skip_stage(job, stage, events, "原图已是全景图，跳过 Img2Pano")
            self._advance_to_next_stage(job, stage.name)
            return StageAction.advance()

        image_url = job.artifacts.originImgUrl
        if not image_url:
            raise ImageToDesignError("missing_origin_image", "缺少 originImgUrl，无法执行 Img2Pano")

        async def submit() -> str:
            return await self.maas.start_img2pano(image_url=image_url)

        def apply(result: dict[str, Any]) -> None:
            job.artifacts.panoImgUrl = result["pano_image_url"]

        return await self._run_remote_stage(
            job,
            stage,
            events,
            submit=submit,
            check=self.maas.get_img2pano,
            apply=apply,
            stage_start_message="开始生成全景图",
            stage_success_message="全景图生成完成",
        )

    async def _handle_pano_clear(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        if job.clear_furniture is None:
            return self._wait_for_stage_input(job, stage, events, "等待用户确认是否清家具")

        if not job.clear_furniture:
            self._skip_stage(job, stage, events, "clear_furniture=false，跳过清家具")
            self._advance_to_next_stage(job, stage.name)
            return StageAction.advance()

        image_url = self._effective_pano_url(job)
        if not image_url:
            raise ImageToDesignError("missing_pano_image", "缺少全景图，无法执行 PanoClear")

        async def submit() -> str:
            return await self.maas.start_pano_clear(image_url=image_url)

        def apply(result: dict[str, Any]) -> None:
            job.artifacts.panoClearImgUrl = result["pano_clear_image_url"]
            if result.get("pano_mask_url"):
                job.artifacts.panoMaskUrl = result["pano_mask_url"]

        return await self._run_remote_stage(
            job,
            stage,
            events,
            submit=submit,
            check=self.maas.get_pano_clear,
            apply=apply,
            stage_start_message="开始清理家具",
            stage_success_message="清家具完成",
        )

    async def _handle_pano2pointcloud(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        image_url = self._effective_pano_url(job)
        if not image_url:
            raise ImageToDesignError("missing_pano_image", "缺少全景图，无法执行 Pano2PointCloud")

        async def submit() -> str:
            return await self.maas.start_pano2pointcloud(image_url=image_url)

        def apply(result: dict[str, Any]) -> None:
            job.artifacts.pointCloudPlyUrl = result["point_cloud_ply_url"]
            job.artifacts.pointCloudDrcUrl = result["point_cloud_drc_url"]
            job.artifacts.panoDepthUrl = result["pano_depth_url"]
            if result.get("gs_scale") is not None:
                job.artifacts.gsScale = result["gs_scale"]
            if result.get("pano_mask_url"):
                job.artifacts.panoMaskUrl = result["pano_mask_url"]

        return await self._run_remote_stage(
            job,
            stage,
            events,
            submit=submit,
            check=self.maas.get_pano2pointcloud,
            apply=apply,
            stage_start_message="开始生成点云",
            stage_success_message="点云生成完成",
        )

    async def _handle_spatial_tune(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        def apply(result: dict[str, Any]) -> None:
            job.artifacts.floorplanTuneRotate = result["rotate"]
            job.artifacts.floorplanBottomPosition = result["bottom_position"]
            job.artifacts.floorplanTopPosition = result["top_position"]
            if result.get("gs_scale") is not None:
                job.artifacts.gsScale = result["gs_scale"]

        return await self._run_remote_stage(
            job,
            stage,
            events,
            submit=lambda: self.spatial_tune.start(job),
            check=self.spatial_tune.get_status,
            apply=apply,
            stage_start_message="开始空间调整",
            stage_success_message="空间调整完成",
        )

    async def _handle_gauss_import(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        if job.level_height_mm is None:
            return self._wait_for_stage_input(job, stage, events, "等待用户输入层高（mm）")

        def apply(result: dict[str, Any]) -> None:
            if result.get("obs_design_id"):
                job.result.obsDesignId = result["obs_design_id"]
            if result.get("obs_plan_id"):
                job.result.obsPlanId = result["obs_plan_id"]
            if result.get("level_id"):
                job.result.levelId = result["level_id"]
            if result.get("design_url"):
                job.result.designUrl = result["design_url"]

        return await self._run_remote_stage(
            job,
            stage,
            events,
            submit=lambda: self.gauss_import.start(job),
            check=self.gauss_import.get_status,
            apply=apply,
            stage_start_message="开始导入方案",
            stage_success_message="导入方案完成",
        )

    async def _handle_gauss_show_info(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent]) -> StageAction:
        if stage.status == StageStatus.pending:
            self._start_stage(job, stage, events, "开始查询方案信息")

        result = await self.gauss_import.get_show_info(job)
        if not result.get("done"):
            self._record_waiting(job, stage, events, result.get("message") or "方案信息生成中")
            return StageAction.wait(self._next_poll_interval(stage.name))

        if result.get("design_url"):
            job.result.designUrl = result["design_url"]
        if result.get("splat_url"):
            job.result.splatUrl = result["splat_url"]
        if result.get("drc_url"):
            job.result.drcUrl = result["drc_url"]

        self._succeed_stage(job, stage, events, result.get("message") or "方案信息查询完成")
        self._finish_job(job, events)
        return StageAction.advance()

    def _wait_for_stage_input(
        self,
        job: ImageToDesignJob,
        stage: StageState,
        events: list[JobEvent],
        message: str,
    ) -> StageAction:
        stage.message = message
        self._touch_stage(job, stage)
        self._record_waiting(job, stage, events, message)
        return StageAction.wait(None)

    def _update_clear_furniture(self, job: ImageToDesignJob, value: bool) -> None:
        stage = job.stage(StageName.pano_clear)
        self._assert_input_mutable(job, stage=stage, field_name="clear_furniture")
        job.clear_furniture = value
        if job.current_stage == StageName.pano_clear and stage.backend_task_id is None:
            stage.message = None
            self._touch_stage(job, stage)
        else:
            self._touch_job(job)

    def _update_level_height(self, job: ImageToDesignJob, value: float) -> None:
        stage = job.stage(StageName.gauss_import)
        self._assert_input_mutable(job, stage=stage, field_name="level_height_mm")
        job.level_height_mm = value
        if job.current_stage == StageName.gauss_import and stage.backend_task_id is None:
            stage.message = None
            self._touch_stage(job, stage)
        else:
            self._touch_job(job)

    def _assert_input_mutable(self, job: ImageToDesignJob, *, stage: StageState, field_name: str) -> None:
        if stage.status != StageStatus.pending:
            raise ImageToDesignError(
                "job_input_locked",
                f"{field_name} 已在 {stage.name} 阶段生效，当前不能再修改",
                details={"job_id": job.id, "field": field_name, "stage": stage.name, "stage_status": stage.status},
                recoverable=False,
            )

    async def _run_remote_stage(
        self,
        job: ImageToDesignJob,
        stage: StageState,
        events: list[JobEvent],
        *,
        submit: Callable[[], Awaitable[str]],
        check: Callable[[str], Awaitable[dict[str, Any]]],
        apply: Callable[[dict[str, Any]], None],
        stage_start_message: str,
        stage_success_message: str,
    ) -> StageAction:
        if stage.backend_task_id is None:
            self._start_stage(job, stage, events, stage_start_message)
            stage.backend_task_id = await submit()
            stage.message = "已提交后端任务"
            self._touch_stage(job, stage)

        result = await check(stage.backend_task_id)
        if not result.get("done"):
            self._record_waiting(job, stage, events, result.get("message") or "后端处理中")
            return StageAction.wait(self._next_poll_interval(stage.name))

        apply(result)
        self._succeed_stage(job, stage, events, result.get("message") or stage_success_message)
        self._advance_to_next_stage(job, stage.name)
        return StageAction.advance()

    def _advance_to_next_stage(self, job: ImageToDesignJob, current_stage: StageName | str) -> None:
        normalized_stage = StageName(current_stage)
        current_index = STAGE_SEQUENCE.index(normalized_stage)
        if current_index >= len(STAGE_SEQUENCE) - 1:
            return
        job.current_stage = STAGE_SEQUENCE[current_index + 1]
        self._touch_job(job)

    def _finish_job(self, job: ImageToDesignJob, events: list[JobEvent]) -> None:
        job.status = JobStatus.succeeded
        job.error = None
        self._touch_job(job)
        events.append(job.add_event(EventType.job_succeeded, "job 执行成功，已返回方案链接", stage=StageName.gauss_show_info))

    def _start_stage(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent], message: str) -> None:
        if stage.status == StageStatus.running:
            return
        stage.status = StageStatus.running
        stage.attempts += 1
        now = datetime.now(timezone.utc)
        if stage.started_at is None:
            stage.started_at = now
        stage.updated_at = now
        stage.message = message
        job.status = JobStatus.running
        self._touch_job(job, now)
        events.append(job.add_event(EventType.stage_started, message, stage=stage.name))

    def _succeed_stage(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent], message: str) -> None:
        now = datetime.now(timezone.utc)
        stage.status = StageStatus.succeeded
        stage.message = message
        stage.updated_at = now
        stage.completed_at = now
        self._touch_job(job, now)
        events.append(job.add_event(EventType.stage_succeeded, message, stage=stage.name))

    def _skip_stage(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent], message: str) -> None:
        now = datetime.now(timezone.utc)
        stage.status = StageStatus.skipped
        stage.message = message
        stage.updated_at = now
        stage.completed_at = now
        self._touch_job(job, now)
        events.append(job.add_event(EventType.stage_skipped, message, stage=stage.name))

    def _fail_stage(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent], error: ImageToDesignError) -> None:
        now = datetime.now(timezone.utc)
        stage.status = StageStatus.failed
        stage.message = error.message
        stage.updated_at = now
        stage.completed_at = now
        job.status = JobStatus.failed
        job.error = JobErrorState(
            code=error.code,
            message=error.message,
            recoverable=error.recoverable,
            details=error.details,
        )
        self._touch_job(job, now)
        events.append(job.add_event(EventType.job_failed, error.message, stage=stage.name, data=error.details))

    def _record_waiting(self, job: ImageToDesignJob, stage: StageState, events: list[JobEvent], message: str) -> None:
        stage.message = message
        self._touch_stage(job, stage)
        last_event = job.history[-1] if job.history else None
        if (
            last_event is not None
            and last_event.type == EventType.waiting
            and last_event.stage == stage.name
            and (datetime.now(timezone.utc) - last_event.at).total_seconds() < 30
        ):
            return
        events.append(job.add_event(EventType.waiting, message, stage=stage.name, data={"task_id": stage.backend_task_id or ""}))

    def _effective_pano_url(self, job: ImageToDesignJob) -> str | None:
        return job.artifacts.panoClearImgUrl or job.artifacts.panoImgUrl or job.artifacts.originImgUrl

    def _next_poll_interval(self, stage_name: StageName | str) -> int:
        return DEFAULT_POLL_INTERVALS.get(StageName(stage_name), 10)

    def _touch_stage(self, job: ImageToDesignJob, stage: StageState, now: datetime | None = None) -> None:
        now = now or datetime.now(timezone.utc)
        stage.updated_at = now
        self._touch_job(job, now)

    def _touch_job(self, job: ImageToDesignJob, now: datetime | None = None) -> None:
        job.updated_at = now or datetime.now(timezone.utc)
