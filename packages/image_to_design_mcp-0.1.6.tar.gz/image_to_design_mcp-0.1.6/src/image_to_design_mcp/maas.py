from __future__ import annotations

from enum import StrEnum
from typing import Any

from image_to_design_mcp.client import MAAS_STATUS_LABELS, ApiClient, status_label
from image_to_design_mcp.config import Settings, get_settings
from image_to_design_mcp.errors import ImageToDesignError


class MaasBiz(StrEnum):
    image_type = "ImageType"
    img2pano = "Img2Pano"
    pano_clear = "PanoClear"
    pano2pointcloud = "Pano2PointCloud"


class MaasApi:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or get_settings()

    async def start_image_type(self, *, image_url: str) -> str:
        return await self._submit_url_task(biz=MaasBiz.image_type, image_url=image_url)

    async def get_image_type(self, task_id: str) -> dict[str, Any]:
        data = await self._get_status(task_id=task_id, biz=MaasBiz.image_type)
        status = data.get("status")
        if status == 0:
            return {"done": False, "message": data.get("message") or status_label(MAAS_STATUS_LABELS, status)}

        if status != 1:
            raise self._status_error(stage="image_type", task_id=task_id, status=status, data=data)

        result = data.get("result") or {}
        return {
            "done": True,
            "message": data.get("message") or "图片类型判断完成",
            "is_pano": _truthy(result.get("output_img_type")),
        }

    async def start_img2pano(self, *, image_url: str) -> str:
        return await self._submit_url_task(biz=MaasBiz.img2pano, image_url=image_url)

    async def get_img2pano(self, task_id: str) -> dict[str, Any]:
        data = await self._get_status(task_id=task_id, biz=MaasBiz.img2pano)
        status = data.get("status")
        if status == 0:
            return {"done": False, "message": data.get("message") or status_label(MAAS_STATUS_LABELS, status)}
        if status != 1:
            raise self._status_error(stage="img2pano", task_id=task_id, status=status, data=data)

        result = data.get("result") or {}
        return {
            "done": True,
            "message": data.get("message") or "全景图生成完成",
            "pano_image_url": _require_string(result, "uploadPanoImagePath", stage="img2pano", task_id=task_id),
        }

    async def start_pano_clear(self, *, image_url: str) -> str:
        return await self._submit_url_task(biz=MaasBiz.pano_clear, image_url=image_url)

    async def get_pano_clear(self, task_id: str) -> dict[str, Any]:
        data = await self._get_status(task_id=task_id, biz=MaasBiz.pano_clear)
        status = data.get("status")
        if status == 0:
            return {"done": False, "message": data.get("message") or status_label(MAAS_STATUS_LABELS, status)}
        if status != 1:
            raise self._status_error(stage="pano_clear", task_id=task_id, status=status, data=data)

        result = data.get("result") or {}
        return {
            "done": True,
            "message": data.get("message") or "清家具完成",
            "pano_clear_image_url": _require_string(result, "uploadPanoImagePath", stage="pano_clear", task_id=task_id),
            "pano_mask_url": result.get("result_mask"),
        }

    async def start_pano2pointcloud(self, *, image_url: str) -> str:
        return await self._submit_url_task(biz=MaasBiz.pano2pointcloud, image_url=image_url)

    async def get_pano2pointcloud(self, task_id: str) -> dict[str, Any]:
        data = await self._get_status(task_id=task_id, biz=MaasBiz.pano2pointcloud)
        status = data.get("status")
        if status == 0:
            return {"done": False, "message": data.get("message") or status_label(MAAS_STATUS_LABELS, status)}
        if status != 1:
            raise self._status_error(stage="pano2pointcloud", task_id=task_id, status=status, data=data)

        result = data.get("result") or {}
        return {
            "done": True,
            "message": data.get("message") or "点云生成完成",
            "point_cloud_ply_url": _require_string(result, "result_ply", stage="pano2pointcloud", task_id=task_id),
            "point_cloud_drc_url": _require_string(result, "result_drc", stage="pano2pointcloud", task_id=task_id),
            "pano_depth_url": _require_string(result, "result_depth", stage="pano2pointcloud", task_id=task_id),
            "pano_mask_url": _require_string(result, "result_mask", stage="pano2pointcloud", task_id=task_id),
            "gs_scale": _require_float(result, "result_gs_scale", stage="pano2pointcloud", task_id=task_id),
        }

    async def _submit_url_task(self, *, biz: MaasBiz, image_url: str) -> str:
        async with ApiClient(settings=self.settings) as client:
            task_id = await client.post("/kam/api/maas/task/submit", json={"biz": biz.value, "url": image_url})
        if not task_id or not isinstance(task_id, str):
            raise ImageToDesignError(
                "maas_submit_error",
                f"提交 {biz.value} 任务失败，未返回 task_id",
                details={"biz": biz.value, "response": task_id},
            )
        return task_id

    async def _get_status(self, *, task_id: str, biz: MaasBiz) -> dict[str, Any]:
        async with ApiClient(settings=self.settings) as client:
            data = await client.get("/kam/api/maas/task/status", params={"taskId": task_id, "biz": biz.value})
        if not isinstance(data, dict):
            raise ImageToDesignError(
                "maas_status_error",
                f"查询 {biz.value} 状态失败，返回结构异常",
                details={"biz": biz.value, "task_id": task_id, "response": data},
            )
        return data

    def _status_error(self, *, stage: str, task_id: str, status: Any, data: dict[str, Any]) -> ImageToDesignError:
        return ImageToDesignError(
            "maas_task_failed",
            f"{stage} 任务失败，状态: {status_label(MAAS_STATUS_LABELS, status if isinstance(status, int) else None)}",
            details={"stage": stage, "task_id": task_id, "status": status, "response": data},
        )



def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0
    return str(value).strip().lower() in {"1", "true", "yes"}



def _require_string(payload: dict[str, Any], key: str, *, stage: str, task_id: str) -> str:
    value = payload.get(key)
    if isinstance(value, str) and value.strip():
        return value.strip()
    raise ImageToDesignError(
        "missing_result_field",
        f"{stage} 返回字段 {key} 为空",
        details={"stage": stage, "task_id": task_id, "key": key, "response": payload},
    )



def _require_float(payload: dict[str, Any], key: str, *, stage: str, task_id: str) -> float:
    value = payload.get(key)
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ImageToDesignError(
            "invalid_result_field",
            f"{stage} 返回字段 {key} 不是数字",
            details={"stage": stage, "task_id": task_id, "key": key, "value": value, "response": payload},
        ) from exc
