from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, ConfigDict, Field


class StageName(str, Enum):
    upload = "upload"
    image_type = "image_type"
    img2pano = "img2pano"
    pano_clear = "pano_clear"
    pano2pointcloud = "pano2pointcloud"
    spatial_tune = "spatial_tune"
    gauss_import = "gauss_import"
    gauss_show_info = "gauss_show_info"


class StageStatus(str, Enum):
    pending = "pending"
    running = "running"
    succeeded = "succeeded"
    failed = "failed"
    skipped = "skipped"


class JobStatus(str, Enum):
    pending = "pending"
    running = "running"
    succeeded = "succeeded"
    failed = "failed"


class EventType(str, Enum):
    job_started = "job_started"
    stage_started = "stage_started"
    stage_succeeded = "stage_succeeded"
    stage_skipped = "stage_skipped"
    waiting = "waiting"
    job_succeeded = "job_succeeded"
    job_failed = "job_failed"


class ModelBase(BaseModel):
    model_config = ConfigDict(use_enum_values=True)


class JobEvent(ModelBase):
    type: EventType
    stage: StageName | None = None
    message: str
    at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    data: dict[str, Any] = Field(default_factory=dict)


class StageState(ModelBase):
    name: StageName
    status: StageStatus = StageStatus.pending
    message: str | None = None
    backend_task_id: str | None = None
    attempts: int = 0
    started_at: datetime | None = None
    updated_at: datetime | None = None
    completed_at: datetime | None = None


class JobArtifacts(ModelBase):
    originImgUrl: str | None = None
    isOriginImgPano: bool | None = None
    panoImgUrl: str | None = None
    panoClearImgUrl: str | None = None
    pointCloudPlyUrl: str | None = None
    pointCloudDrcUrl: str | None = None
    panoDepthUrl: str | None = None
    gsScale: float | None = None
    panoMaskUrl: str | None = None
    floorplanTuneRotate: float | None = None
    floorplanBottomPosition: dict[str, float] | None = None
    floorplanTopPosition: dict[str, float] | None = None


class JobResult(ModelBase):
    obsDesignId: str | None = None
    obsPlanId: str | None = None
    levelId: str | None = None
    designUrl: str | None = None
    splatUrl: str | None = None
    drcUrl: str | None = None


class JobErrorState(ModelBase):
    code: str
    message: str
    recoverable: bool = True
    details: dict[str, Any] = Field(default_factory=dict)


class ImageToDesignJob(ModelBase):
    id: str
    local_path: str
    clear_furniture: bool | None = True
    floor_plan_name: str | None = None
    level_height_mm: float | None = 2800.0
    status: JobStatus = JobStatus.pending
    current_stage: StageName = StageName.upload
    stages: dict[str, StageState]
    artifacts: JobArtifacts = Field(default_factory=JobArtifacts)
    result: JobResult = Field(default_factory=JobResult)
    error: JobErrorState | None = None
    history: list[JobEvent] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def new(
        cls,
        *,
        local_path: str,
        clear_furniture: bool | None,
        floor_plan_name: str | None,
        level_height_mm: float | None,
    ) -> "ImageToDesignJob":
        stages = {stage.value: StageState(name=stage) for stage in STAGE_SEQUENCE}
        return cls(
            id=f"i2d_{uuid4().hex[:12]}",
            local_path=str(Path(local_path).expanduser()),
            clear_furniture=clear_furniture,
            floor_plan_name=floor_plan_name,
            level_height_mm=level_height_mm,
            status=JobStatus.pending,
            current_stage=StageName.upload,
            stages=stages,
        )

    def stage(self, name: StageName | str) -> StageState:
        stage_name = StageName(name)
        return self.stages[stage_name.value]

    def add_event(self, event_type: EventType, message: str, *, stage: StageName | None = None, data: dict[str, Any] | None = None) -> JobEvent:
        event = JobEvent(type=event_type, stage=stage, message=message, data=data or {})
        self.history.append(event)
        self.updated_at = datetime.now(timezone.utc)
        return event


STAGE_SEQUENCE = [
    StageName.upload,
    StageName.image_type,
    StageName.img2pano,
    StageName.pano_clear,
    StageName.pano2pointcloud,
    StageName.spatial_tune,
    StageName.gauss_import,
    StageName.gauss_show_info,
]
