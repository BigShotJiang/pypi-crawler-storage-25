"""Helpers for working with bundled SOR data files."""

from __future__ import annotations

import lzma
import shutil
from importlib.resources import as_file, files
from pathlib import Path


def extract_sor_trimmed(
    destination_dir: Path | None = None,
    output_name: str = "sor_trimmed.csv",
    overwrite: bool = False,
) -> Path:
    """Extract the bundled ``sor_trimmed.csv.xz`` into a directory."""
    target_dir = destination_dir or Path.cwd()
    target_dir.mkdir(parents=True, exist_ok=True)

    output_path = target_dir / output_name
    if output_path.exists() and not overwrite:
        raise FileExistsError(f"File already exists: {output_path}")

    resource = files(__package__).joinpath("data/sor_trimmed.csv.xz")
    with as_file(resource) as compressed_path:
        with lzma.open(compressed_path, "rb") as source:
            with output_path.open("wb") as destination:
                shutil.copyfileobj(source, destination)

    return output_path
