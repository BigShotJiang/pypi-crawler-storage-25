
"""
Filter events
"""
allowed_events = ["MUSCULOSKELETAL", "CARDIOVASCULAR", "CANCER", "Death", "BURST"]
pattern = "^" + "|".join(allowed_events)
lf_allowed = lf.filter(
    (
        pl.col("TDiag").str.contains(pattern) & ~pl.col("TDiag").str.contains("SENSORY")
    )  # An activity is called `MUSCULOSKELETAL, SENSORY ORGANS` and we want to exclude it
    .all()
    .over("case:PNR")
)
lf = lf.filter(
    pl.col("TDiag").str.contains(pattern) & ~pl.col("TDiag").str.contains("SENSORY")
)
lf_strict = lf_allowed.filter(
    pl.all_horizontal(
        [
            pl.col("TDiag").str.contains(ev).any().over("case:PNR")
            for ev in allowed_events[:-1]
        ]
    )
)
