import polars as pl

lf: pl.LazyFrame = None
lf_allowed: pl.LazyFrame = None
lf_strict: pl.LazyFrame = None
# {{paste:begin}}

# {{paste:DIAG_initial_sorting_all}}

# {{paste:DIAG_stats}}

lf = lf.filter((pl.col("TDiag") == "Death").last().over("case:PNR"))

"""
Converts into counts
"""
lf = lf.with_columns(
    (
        pl.col("TDiag") + pl.int_range(1, pl.len() + 1).over("TDiag").cast(pl.String)
    ).over("case:PNR")
)

lf = lf.with_columns(
    pl.when(pl.col("TDiag").str.starts_with("CANCER"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CANCER3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("CARDIOVASCULAR"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 3)
        .then(pl.lit("CARDIOVASCULAR3+"))
        .otherwise(pl.col("TDiag"))
    )
    .when(pl.col("TDiag").str.starts_with("MUSCULOSKELETAL"))
    .then(
        pl.when(pl.col("TDiag").str.extract(r"(\d+)$").cast(pl.Int32) > 2)
        .then(pl.lit("MUSCULOSKELETAL2+"))
        .otherwise(pl.col("TDiag"))
    )
    .otherwise(pl.col("TDiag"))
    .alias("TDiag")
)

# {{paste:burst}}
# {{paste:DIAG_filter}}
df, df_allowed, df_strict = pl.collect_all([lf, lf_allowed, lf_strict])
# {{paste:DIAG_df_stats}}
