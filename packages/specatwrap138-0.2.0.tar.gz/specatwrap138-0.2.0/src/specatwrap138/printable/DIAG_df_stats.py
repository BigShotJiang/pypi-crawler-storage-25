"""
Stats
"""


def print_stats(df: pl.DataFrame):
    total_cases = df["case:PNR"].n_unique()

    stats = (
        df.group_by("TDiag")
        .agg((pl.len() / total_cases).alias("stat"))
        .sort("stat", descending=True)
    )

    print(f"{'-' * 10} All events {'-' * 10}")
    for row in stats.iter_rows(named=True):
        print(f"{row['TDiag']:.<18}: {row['stat']:.2%}")


print("DF")
print_stats(df)
print("\nDF Allowed")
print_stats(df_allowed)
print("\nDF Strict")
print_stats(df_strict)
