from __future__ import annotations

import colorsys
import re
from collections.abc import Callable, Mapping, Sequence
from datetime import timedelta
from typing import Any

import plotly.graph_objects as go
import polars as pl
from plotly.colors import qualitative
import plotly.io as pio

pio.renderers.default = "notebook"


Predicate = Callable[[pl.LazyFrame], pl.Expr]
NamedPredicate = tuple[str, Predicate]
PredicateLike = Predicate | NamedPredicate

_PREFIX_RE = re.compile(r"^_(\d+)_(.*)$")
_MUTED_LINK_COLOR = "rgba(180, 180, 180, 0.18)"
_DEFAULT_NODE_COLOR = "rgba(120, 120, 120, 0.45)"
_DEFAULT_PALETTE = (
    qualitative.Plotly
    + qualitative.D3
    + qualitative.G10
    + qualitative.T10
    + qualitative.Alphabet
)


def _parse_event_position(activity: str) -> tuple[int, str]:
    match = _PREFIX_RE.match(activity)
    if match is None:
        return (10**9, activity)
    return (int(match.group(1)), match.group(2))


def _compute_node_positions(
    activities: Sequence[str],
    node_total_flow: dict[str, int],
    edge_weights: dict[tuple[str, str], int] | None = None,
    x_positions: dict[str, float] | None = None,
) -> tuple[list[float], list[float]]:
    top_margin = 0.001
    bottom_margin = 0.001
    preferred_gap = 0.012

    columns: dict[int, list[str]] = {}
    for activity in activities:
        column_index, _ = _parse_event_position(activity)
        columns.setdefault(column_index, []).append(activity)

    incoming_edges, outgoing_edges = _build_activity_adjacency(edge_weights or {})
    columns = _optimise_column_orderings(columns, node_total_flow, incoming_edges, outgoing_edges)

    ordered_columns = sorted(columns)
    if not ordered_columns:
        return [], []

    max_column_index = max(1, len(ordered_columns) - 1)
    x_by_activity: dict[str, float] = {}
    y_by_activity: dict[str, float] = {}

    for column_offset, column_index in enumerate(ordered_columns):
        column_activities = sorted(
            columns[column_index],
            key=lambda activity: (
                -node_total_flow.get(activity, 0),
                _parse_event_position(activity),
            ),
        )
        x_position = 0.001 if len(ordered_columns) == 1 else column_offset / max_column_index

        if len(column_activities) == 1:
            y_positions = [top_margin]
        else:
            total_column_flow = sum(
                max(1, node_total_flow.get(activity, 0))
                for activity in column_activities
            )
            max_total_gap = max(0.0, 1.0 - top_margin - bottom_margin)
            gap = min(
                preferred_gap,
                max_total_gap / max(1, len(column_activities) - 1),
            )
            usable_height = max(
                0.0,
                1.0 - top_margin - bottom_margin - gap * (len(column_activities) - 1),
            )
            flow_scale = usable_height / total_column_flow if total_column_flow else 0.0

            y_positions = []
            cursor = top_margin
            for activity in column_activities:
                y_positions.append(cursor)
                cursor += max(1, node_total_flow.get(activity, 0)) * flow_scale + gap

        for activity, y_position in zip(column_activities, y_positions, strict=True):
            x_by_activity[activity] = x_positions.get(activity, x_position) if x_positions is not None else x_position
            y_by_activity[activity] = y_position

    return (
        [x_by_activity[activity] for activity in activities],
        [y_by_activity[activity] for activity in activities],
    )


def _build_activity_adjacency(
    edge_weights: dict[tuple[str, str], int],
) -> tuple[dict[str, list[tuple[str, int]]], dict[str, list[tuple[str, int]]]]:
    incoming_edges: dict[str, list[tuple[str, int]]] = {}
    outgoing_edges: dict[str, list[tuple[str, int]]] = {}
    for (source, target), weight in edge_weights.items():
        outgoing_edges.setdefault(source, []).append((target, weight))
        incoming_edges.setdefault(target, []).append((source, weight))
    return incoming_edges, outgoing_edges


def _initial_column_order(
    activities: Sequence[str],
    node_total_flow: dict[str, int],
) -> list[str]:
    return sorted(
        activities,
        key=lambda activity: (
            -node_total_flow.get(activity, 0),
            _parse_event_position(activity),
        ),
    )


def _weighted_neighbor_center(
    activity: str,
    neighbor_edges: dict[str, list[tuple[str, int]]],
    neighbor_positions: Mapping[str, float],
) -> float | None:
    weighted_sum = 0.0
    total_weight = 0
    for neighbor, weight in neighbor_edges.get(activity, []):
        if neighbor not in neighbor_positions:
            continue
        weighted_sum += neighbor_positions[neighbor] * weight
        total_weight += weight
    if total_weight == 0:
        return None
    return weighted_sum / total_weight


def _reorder_column_by_neighbor_positions(
    column_activities: Sequence[str],
    node_total_flow: dict[str, int],
    neighbor_edges: dict[str, list[tuple[str, int]]],
    neighbor_positions: Mapping[str, float],
) -> list[str]:
    return sorted(
        column_activities,
        key=lambda activity: (
            _weighted_neighbor_center(activity, neighbor_edges, neighbor_positions)
            is None,
            _weighted_neighbor_center(activity, neighbor_edges, neighbor_positions)
            if _weighted_neighbor_center(activity, neighbor_edges, neighbor_positions)
            is not None
            else 0.0,
            -node_total_flow.get(activity, 0),
            _parse_event_position(activity),
        ),
    )


def _optimise_column_orderings(
    columns: dict[int, list[str]],
    node_total_flow: dict[str, int],
    incoming_edges: dict[str, list[tuple[str, int]]],
    outgoing_edges: dict[str, list[tuple[str, int]]],
    iterations: int = 6,
) -> dict[int, list[str]]:
    ordered_columns = sorted(columns)
    if len(ordered_columns) <= 1:
        return {
            column_index: _initial_column_order(columns[column_index], node_total_flow)
            for column_index in ordered_columns
        }

    column_orders = {
        column_index: _initial_column_order(columns[column_index], node_total_flow)
        for column_index in ordered_columns
    }

    for _ in range(iterations):
        for offset in range(1, len(ordered_columns)):
            current_index = ordered_columns[offset]
            previous_index = ordered_columns[offset - 1]
            neighbor_positions = {
                activity: float(position)
                for position, activity in enumerate(column_orders[previous_index])
            }
            column_orders[current_index] = _reorder_column_by_neighbor_positions(
                column_orders[current_index],
                node_total_flow,
                incoming_edges,
                neighbor_positions,
            )

        for reverse_offset in range(len(ordered_columns) - 2, -1, -1):
            current_index = ordered_columns[reverse_offset]
            next_index = ordered_columns[reverse_offset + 1]
            neighbor_positions = {
                activity: float(position)
                for position, activity in enumerate(column_orders[next_index])
            }
            column_orders[current_index] = _reorder_column_by_neighbor_positions(
                column_orders[current_index],
                node_total_flow,
                outgoing_edges,
                neighbor_positions,
            )

    return column_orders


def _hex_to_rgb(color: str) -> tuple[int, int, int]:
    value = color.lstrip("#")
    if len(value) != 6:
        raise ValueError(f"Expected a 6-digit hex color, got {color!r}.")
    return (
        int(value[0:2], 16),
        int(value[2:4], 16),
        int(value[4:6], 16),
    )


def _blend_hex_colors(colors: Sequence[str]) -> tuple[int, int, int]:
    rgbs = [_hex_to_rgb(color) for color in colors]
    red_values, green_values, blue_values = zip(*rgbs, strict=True)
    return (
        round(sum(red_values) / len(rgbs)),
        round(sum(green_values) / len(rgbs)),
        round(sum(blue_values) / len(rgbs)),
    )


def _rgb_to_rgba(color: tuple[int, int, int], alpha: float) -> str:
    red, green, blue = color
    return f"rgba({red}, {green}, {blue}, {alpha:.3f})"


def _generate_palette(size: int) -> list[str]:
    if size <= len(_DEFAULT_PALETTE):
        return list(_DEFAULT_PALETTE[:size])

    colors = list(_DEFAULT_PALETTE)
    missing = size - len(colors)
    for index in range(missing):
        hue = index / max(missing, 1)
        red, green, blue = colorsys.hsv_to_rgb(hue, 0.65, 0.95)
        colors.append(
            f"#{int(red * 255):02X}{int(green * 255):02X}{int(blue * 255):02X}"
        )
    return colors


def _normalise_predicate_result(result: Any, variants: pl.LazyFrame) -> pl.Expr:
    if isinstance(result, pl.Expr):
        return result
    if callable(result):
        resolved = result(variants)
        if isinstance(resolved, pl.Expr):
            return resolved
    raise TypeError("Each predicate must resolve to a Polars expression.")


def _build_variant_table(
    event_log: pl.DataFrame,
    case_col: str,
    activity_col: str,
) -> pl.DataFrame:
    per_case = (
        event_log.lazy()
        .with_row_index("__event_order")
        .group_by(case_col, maintain_order=True)
        .agg(pl.col(activity_col).sort_by("__event_order").alias("variant"))
    )

    variants = (
        per_case.group_by("variant", maintain_order=True)
        .agg(pl.len().alias("case_count"))
        .with_columns(pl.col("variant").list.len().alias("variant_length"))
        .collect()
    )

    max_length = variants.get_column("variant_length").max() if variants.height else 0
    if not max_length:
        return variants

    return variants.with_columns(
        [
            pl.col("variant")
            .list.get(index, null_on_oob=True)
            .alias(f"event_{index + 1}")
            for index in range(max_length)
        ]
    )


def _build_per_case_table(
    event_log: pl.DataFrame,
    case_col: str,
    activity_col: str,
    case_attribute_cols: str | None,
    start_time_col: str,
) -> pl.DataFrame:
    attribute_columns = [
        column
        for column in event_log.columns
        if column not in {case_col, activity_col}
        and (case_attribute_cols is not None and column.startswith(case_attribute_cols))
    ]

    aggregations: list[pl.Expr] = [
        pl.col(activity_col).sort_by("__event_order").alias("variant")
    ]
    if start_time_col in event_log.columns:
        aggregations.append(
            pl.col(start_time_col).sort_by("__event_order").alias("__event_start_times")
        )
    aggregations.extend(
        pl.col(column).drop_nulls().first().alias(column)
        for column in attribute_columns
    )

    per_case = (
        event_log.lazy()
        .with_row_index("__event_order")
        .group_by(case_col, maintain_order=True)
        .agg(aggregations)
        .with_columns(pl.col("variant").list.len().alias("variant_length"))
        .collect()
    )

    max_length = per_case.get_column("variant_length").max() if per_case.height else 0
    if max_length:
        per_case = per_case.with_columns(
            [
                pl.col("variant")
                .list.get(index, null_on_oob=True)
                .alias(f"event_{index + 1}")
                for index in range(max_length)
            ]
        )

    return per_case


def _build_variant_counts(per_case: pl.DataFrame) -> pl.DataFrame:
    variants = (
        per_case.group_by("variant", maintain_order=True)
        .agg(pl.len().alias("case_count"))
        .with_columns(pl.col("variant").list.len().alias("variant_length"))
    )

    max_length = variants.get_column("variant_length").max() if variants.height else 0
    if not max_length:
        return variants

    return variants.with_columns(
        [
            pl.col("variant")
            .list.get(index, null_on_oob=True)
            .alias(f"event_{index + 1}")
            for index in range(max_length)
        ]
    )


def _normalise_predicates(
    predicates: Sequence[PredicateLike],
) -> list[tuple[str, Predicate]]:
    named_predicates: list[tuple[str, Predicate]] = []
    for index, predicate_like in enumerate(predicates, start=1):
        if callable(predicate_like):
            candidate = getattr(predicate_like, "__name__", None)
            if candidate and candidate != "<lambda>":
                name = candidate
            else:
                name = f"predicate_{index}"
            named_predicates.append((name, predicate_like))
            continue

        if (
            isinstance(predicate_like, tuple)
            and len(predicate_like) == 2
            and isinstance(predicate_like[0], str)
            and callable(predicate_like[1])
        ):
            named_predicates.append((predicate_like[0], predicate_like[1]))
            continue

        raise TypeError(
            "Each predicate must be either a callable or a (name, callable) tuple."
        )

    return named_predicates


def _predicate_names(predicates: Sequence[PredicateLike]) -> list[str]:
    names: list[str] = []
    for index, predicate_like in enumerate(predicates, start=1):
        if callable(predicate_like):
            candidate = getattr(predicate_like, "__name__", None)
        else:
            candidate = None
        if candidate and candidate != "<lambda>":
            names.append(candidate)
        elif isinstance(predicate_like, tuple) and len(predicate_like) == 2:
            names.append(predicate_like[0])
        else:
            names.append(f"predicate_{index}")
    return names


def _normalise_x_positions(values_by_activity: dict[str, float]) -> dict[str, float]:
    if not values_by_activity:
        return {}

    ordered_values = sorted(values_by_activity.values())
    min_value = ordered_values[0]
    max_value = ordered_values[-1]
    if min_value == max_value:
        return {}

    span = max_value - min_value
    if span <= 0:
        return {}

    return {
        activity: (value - min_value) / span
        for activity, value in values_by_activity.items()
    }


def _time_aggregation_expr(column_name: str, time_agg_type: str) -> pl.Expr:
    if time_agg_type == "median":
        return pl.col(column_name).median()
    if time_agg_type == "avg":
        return pl.col(column_name).mean()
    raise ValueError("time_agg_type must be either 'median' or 'avg'.")


def _build_abs_time_event_rows(per_case: pl.DataFrame) -> list[dict[str, Any]]:
    if "__event_start_times" not in per_case.columns:
        return []

    event_rows: list[dict[str, Any]] = []
    for variant, start_times in per_case.select("variant", "__event_start_times").iter_rows():
        for activity, start_time in zip(variant, start_times, strict=False):
            if start_time is not None:
                event_rows.append({"activity": activity, "start_time": start_time})
    return event_rows


def _build_delta_time_event_rows(per_case: pl.DataFrame) -> list[dict[str, Any]]:
    if "__event_start_times" not in per_case.columns:
        return []

    event_rows: list[dict[str, Any]] = []
    for variant, start_times in per_case.select("variant", "__event_start_times").iter_rows():
        first_start_time = None
        for activity, start_time in zip(variant, start_times, strict=False):
            if first_start_time is None:
                first_start_time = start_time
            elapsed_seconds = (start_time - first_start_time).total_seconds()
            event_rows.append({"activity": activity, "elapsed_seconds": elapsed_seconds})
    return event_rows


def _compute_activity_time_values(
    per_case: pl.DataFrame,
    align_time: str | None,
    time_agg_type: str,
) -> dict[str, Any]:
    if align_time == "abs":
        event_rows = _build_abs_time_event_rows(per_case)
        if not event_rows:
            return {}
        aggregated_times = (
            pl.DataFrame(event_rows)
            .group_by("activity", maintain_order=True)
            .agg(_time_aggregation_expr("start_time", time_agg_type).alias("time_value"))
        )
    elif align_time == "delta":
        event_rows = _build_delta_time_event_rows(per_case)
        if not event_rows:
            return {}
        aggregated_times = (
            pl.DataFrame(event_rows)
            .group_by("activity", maintain_order=True)
            .agg(
                _time_aggregation_expr("elapsed_seconds", time_agg_type).alias(
                    "time_value"
                )
            )
        )
    else:
        return {}

    return {
        activity: time_value for activity, time_value in aggregated_times.iter_rows()
    }


def _compute_abs_time_aligned_x_positions(
    per_case: pl.DataFrame,
    activities: Sequence[str],
    time_agg_type: str,
) -> dict[str, float]:
    activity_time_values = _compute_activity_time_values(
        per_case, align_time="abs", time_agg_type=time_agg_type
    )
    if not activity_time_values:
        return {}

    x_values: dict[str, float] = {}
    for activity, aggregated_start_time in activity_time_values.items():
        x_values[activity] = aggregated_start_time.timestamp()

    x_positions = _normalise_x_positions(x_values)
    return {activity: x_positions[activity] for activity in activities if activity in x_positions}


def _compute_delta_time_aligned_x_positions(
    per_case: pl.DataFrame,
    activities: Sequence[str],
    time_agg_type: str,
) -> dict[str, float]:
    activity_time_values = _compute_activity_time_values(
        per_case, align_time="delta", time_agg_type=time_agg_type
    )
    if not activity_time_values:
        return {}

    x_values = {
        activity: float(aggregated_elapsed_seconds)
        for activity, aggregated_elapsed_seconds in activity_time_values.items()
    }
    x_positions = _normalise_x_positions(x_values)
    return {activity: x_positions[activity] for activity in activities if activity in x_positions}


def _format_node_time_value(value: Any, align_time: str | None) -> str:
    if value is None:
        return "N/A"
    if align_time == "delta":
        return str(timedelta(seconds=float(value)))
    return str(value)


def _compute_node_time_labels(
    per_case: pl.DataFrame,
    activities: Sequence[str],
    align_time: str | None,
    time_agg_type: str,
) -> list[str]:
    activity_time_values = _compute_activity_time_values(
        per_case, align_time=align_time, time_agg_type=time_agg_type
    )
    if not activity_time_values:
        return ["N/A"] * len(activities)

    time_by_activity = {
        activity: _format_node_time_value(aggregated_time, align_time)
        for activity, aggregated_time in activity_time_values.items()
    }
    return [time_by_activity.get(activity, "N/A") for activity in activities]


def _build_time_axis(
    activity_time_values: dict[str, Any],
    align_time: str | None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    if not activity_time_values or align_time is None:
        return [], []

    ordered_values = sorted(activity_time_values.values())
    min_value = ordered_values[0]
    max_value = ordered_values[-1]
    if min_value == max_value:
        return [], []

    tick_count = min(5, max(2, len(ordered_values)))
    axis_y = -0.08
    tick_top = -0.03
    tick_bottom = -0.045

    shapes: list[dict[str, Any]] = [
        {
            "type": "line",
            "xref": "paper",
            "yref": "paper",
            "x0": 0.0,
            "x1": 1.0,
            "y0": tick_top,
            "y1": tick_top,
            "line": {"color": "rgba(80, 80, 80, 0.6)", "width": 1},
        }
    ]
    annotations: list[dict[str, Any]] = []

    for index in range(tick_count):
        fraction = index / (tick_count - 1) if tick_count > 1 else 0.0
        if align_time == "abs":
            tick_value = min_value + (max_value - min_value) * fraction
        else:
            tick_value = float(min_value) + (float(max_value) - float(min_value)) * fraction

        shapes.append(
            {
                "type": "line",
                "xref": "paper",
                "yref": "paper",
                "x0": fraction,
                "x1": fraction,
                "y0": tick_top,
                "y1": tick_bottom,
                "line": {"color": "rgba(80, 80, 80, 0.6)", "width": 1},
            }
        )
        annotations.append(
            {
                "xref": "paper",
                "yref": "paper",
                "x": fraction,
                "y": axis_y,
                "text": _format_node_time_value(tick_value, align_time),
                "showarrow": False,
                "xanchor": "center",
                "yanchor": "top",
                "font": {"size": 10, "color": "rgba(80, 80, 80, 0.9)"},
            }
        )

    return annotations, shapes


def _build_highlight_legend(
    used_masks: Sequence[int],
    mask_to_color: dict[int, str],
    mask_to_label: dict[int, str],
    mask_to_fraction: dict[int, float],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], int]:
    if not used_masks:
        return [], [], 0

    legend_masks = [0] + [mask for mask in used_masks if mask != 0]
    bottom_padding = 0.04
    title_gap = 0.035
    row_height = min(0.05, (0.92 - bottom_padding) / max(1, len(legend_masks) + 1))
    bottom_row_bottom = bottom_padding
    base_box_left = 1.01
    box_width = 0.025
    text_offset = 0.03
    column_count = 1
    top_row_top = bottom_row_bottom + len(legend_masks) * row_height
    title_y = top_row_top + title_gap

    annotations: list[dict[str, Any]] = [
        {
            "xref": "paper",
            "yref": "paper",
            "x": base_box_left,
            "y": title_y,
            "text": "Legend",
            "showarrow": False,
            "xanchor": "left",
            "yanchor": "top",
            "font": {"size": 11, "color": "rgba(60, 60, 60, 0.95)"},
        }
    ]
    shapes: list[dict[str, Any]] = []

    for index, mask in enumerate(legend_masks):
        box_left = base_box_left
        box_right = box_left + box_width
        text_x = box_left + text_offset
        reverse_index = len(legend_masks) - 1 - index
        y_top = bottom_row_bottom + (reverse_index + 1) * row_height
        y_bottom = y_top - min(0.025, row_height * 0.6)
        shapes.append(
            {
                "type": "rect",
                "xref": "paper",
                "yref": "paper",
                "x0": box_left,
                "x1": box_right,
                "y0": y_bottom,
                "y1": y_top,
                "line": {"color": "rgba(80, 80, 80, 0.4)", "width": 0.5},
                "fillcolor": mask_to_color[mask],
            }
        )
        annotations.append(
            {
                "xref": "paper",
                "yref": "paper",
                "x": text_x,
                "y": (y_top + y_bottom) / 2,
                "text": f"{mask_to_label[mask]} ({mask_to_fraction.get(mask, 0.0):.1%})",
                "showarrow": False,
                "xanchor": "left",
                "yanchor": "middle",
                "align": "left",
                "font": {"size": 10, "color": "rgba(80, 80, 80, 0.95)"},
            }
        )

    return annotations, shapes, len(legend_masks)


def _compute_node_trace_counts(
    per_case: pl.DataFrame,
    activities: Sequence[str],
) -> list[int]:
    trace_count_by_activity: dict[str, int] = {activity: 0 for activity in activities}
    for variant in per_case.get_column("variant").to_list():
        for activity in set(variant):
            if activity in trace_count_by_activity:
                trace_count_by_activity[activity] += 1
    return [trace_count_by_activity[activity] for activity in activities]


def sankey(
    event_log: pl.DataFrame,
    predicates: Sequence[PredicateLike] | None = None,
    *,
    case_col: str = "case:concept:name",
    activity_col: str = "concept:name",
    case_attribute_cols: str | None = "case:",
    title: str = "Trace-highlighted Sankey diagram",
    height: int | None = None,
    align_time: str | None = None,
    start_time_col: str = "startTime",
    time_agg_type: str = "median",
    filter_out: float | int = 0.0,
    filter_out_top: float | int | None = None,
    show: bool = True,
) -> tuple[go.Figure, pl.DataFrame, pl.DataFrame]:
    """Render a Sankey diagram where trace variants are highlighted by predicate matches.

    Predicate API
    -------------
    ``predicates`` may be ``None`` or a sequence containing callables and/or
    ``(name, callable)`` tuples. If it is omitted or empty, no highlighting is
    applied and all links are rendered in muted colors.

    When predicates are provided, each callable is evaluated against an
    aggregated per-case trace table and must resolve to a Polars boolean
    expression. Conceptually, predicates do not operate on individual event-log
    rows; they operate on one row per case, where each row contains the full
    ordered trace for that case.

    A predicate callable is called like this::

        predicate(per_case_lazyframe) -> pl.Expr

    The ``variants_lazyframe`` argument exists so the predicate signature is
    explicit and future-proof, but in most cases you will simply build and
    return a Polars expression with ``pl.col(...)``. The function does not need
    to read from the lazy frame directly.

    Each row of that per-case table includes at least these columns:

    - ``variant``: ``list[str]`` containing the full ordered trace, for example
      ``["_1_CANCER", "_2_TUMOR", "_3_DEATH"]``.
    - ``variant_length``: length of the trace.
    - ``event_1``, ``event_2``, ...: positional convenience columns extracted
      from ``variant``. If a variant is shorter than a position, that column is
      null for that row.
    - ``case_col``: the case identifier column.
    - any case attribute columns whose names start with ``case_attribute_cols``;
      for each case, the first non-null value is used.

    Predicates should therefore express conditions on whole variants, for
    example:

    - first event is ``"_1_CANCER"``
    - trace contains ``"_3_DEATH"``
    - second event is in a set of diagnoses
    - trace length is exactly 3

    Example predicates::

        def starts_with_cancer(_: pl.LazyFrame) -> pl.Expr:
            return pl.col("event_1") == "_1_CANCER"

        def contains_death(_: pl.LazyFrame) -> pl.Expr:
            return pl.col("variant").list.contains("_3_DEATH")

        def is_female(_: pl.LazyFrame) -> pl.Expr:
            return pl.col("case:gender") == "female"

        def short_tumor_path(_: pl.LazyFrame) -> pl.Expr:
            return (
                (pl.col("variant_length") == 3)
                & (pl.col("event_2") == "_2_TUMOR")
            )

    Predicates may also be passed with explicit display names::

        predicates = [
            ("Starts with cancer", starts_with_cancer),
            contains_death,
        ]

    Explicit names are used in highlight labels, hover text, and the legend.

    Predicate results are normalized as follows:

    - the returned expression is cast to boolean
    - null values are treated as ``False``
    - each predicate gets its own highlight color
    - if multiple predicates match the same variant, their colors are blended

    This means a predicate should describe membership in a highlighted subset
    of variants. Variants matching no predicate are rendered with muted links.

    Parameters
    ----------
    event_log
        Polars dataframe with one row per event.
    predicates
        Optional predicate definitions following the Predicate API described
        above. Each item may be either a predicate callable or a
        ``(name, predicate_callable)`` tuple. If omitted or empty, all traces
        are shown with muted colors.
    case_col
        Trace identifier column.
    activity_col
        Activity column.
    case_attribute_cols
        Prefix used to select case-level attribute columns that should be
        preserved for predicates, for example ``"case:"``. For each selected
        column, the first non-null value within each case is retained. If
        ``None``, no case attribute columns are included.
    title
        Plot title.
    height
        Optional figure height in pixels. If omitted, a larger height is chosen
        automatically based on the number of nodes.
    align_time
        X-axis alignment mode. Use ``"abs"`` to align activities by the median
        absolute value of ``start_time_col`` across all event rows for each
        activity, ``"delta"`` to align by the median cumulative elapsed time
        from trace start, or ``None`` to use the original positional layout.
    start_time_col
        Event-level timestamp column used for time alignment. Defaults to
        ``"startTime"``. When ``align_time`` is ``"abs"`` or ``"delta"``, this column must exist and
        contain no null values.
    time_agg_type
        Time aggregation used when ``align_time`` is ``"abs"`` or ``"delta"``.
        Use ``"median"`` to keep the current behavior or ``"avg"`` to use the
        arithmetic mean instead.
    filter_out
        Filter out infrequent trace variants.

        - If ``filter_out`` is a float, it is interpreted as a fraction of all
          traces. For example, ``0.01`` removes variants representing less than
          1% of all traces. Float values must be between 0.0 and 1.0.
        - If ``filter_out`` is an integer, it is interpreted as an absolute
          count threshold. A variant is kept only if its ``case_count`` is
          greater than or equal to ``filter_out``.
    filter_out_top
        Upper-bound variant filter.

        - If ``filter_out_top`` is a float, it is interpreted as a fraction of
          all traces. Variants whose fraction is greater than ``filter_out_top``
          are excluded. Float values must be between 0.0 and 1.0.
        - If ``filter_out_top`` is an integer, it is interpreted as an absolute
          count threshold. Variants with ``case_count`` greater than
          ``filter_out_top`` are excluded.
        - If ``None``, no upper-bound filtering is applied.
    show
        Whether to call ``fig.show()``.

    Returns
    -------
    fig, variants_plain, links
        The Plotly figure, the filtered pre-predicate variant table, and the
        aggregated link table.
    """
    required_columns = {case_col, activity_col}
    missing_columns = required_columns.difference(event_log.columns)
    if missing_columns:
        missing = ", ".join(sorted(missing_columns))
        raise ValueError(f"Missing required columns: {missing}.")
    if align_time not in {"abs", "delta", None}:
        raise ValueError("align_time must be one of 'abs', 'delta', or None.")
    if time_agg_type not in {"median", "avg"}:
        raise ValueError("time_agg_type must be either 'median' or 'avg'.")
    if align_time in {"abs", "delta"}:
        if start_time_col not in event_log.columns:
            raise ValueError(
                f"Time alignment requires start_time_col {start_time_col!r} to be present."
            )
        if event_log.get_column(start_time_col).null_count() > 0:
            raise ValueError(
                f"Time alignment requires start_time_col {start_time_col!r} to contain no null values."
            )
    if isinstance(filter_out, bool):
        raise ValueError("filter_out must be an int or float, not bool.")
    if isinstance(filter_out, int):
        if filter_out < 0:
            raise ValueError("Integer filter_out must be non-negative.")
    elif isinstance(filter_out, float):
        if not 0.0 <= filter_out <= 1.0:
            raise ValueError("Float filter_out must be between 0.0 and 1.0.")
    else:
        raise ValueError("filter_out must be an int or float.")
    if filter_out_top is not None:
        if isinstance(filter_out_top, bool):
            raise ValueError("filter_out_top must be an int, float, or None, not bool.")
        if isinstance(filter_out_top, int):
            if filter_out_top < 0:
                raise ValueError("Integer filter_out_top must be non-negative.")
        elif isinstance(filter_out_top, float):
            if not 0.0 <= filter_out_top <= 1.0:
                raise ValueError("Float filter_out_top must be between 0.0 and 1.0.")
        else:
            raise ValueError("filter_out_top must be an int, float, or None.")

    per_case = _build_per_case_table(
        event_log,
        case_col=case_col,
        activity_col=activity_col,
        case_attribute_cols=case_attribute_cols,
        start_time_col=start_time_col,
    )
    if per_case.is_empty():
        raise ValueError("The event log is empty.")

    variants_plain = _build_variant_counts(per_case)
    total_cases = int(variants_plain.get_column("case_count").sum())

    if isinstance(filter_out, int) and filter_out > 0:
        variants_plain = variants_plain.filter(
            pl.col("case_count") >= pl.lit(filter_out)
        )
        if variants_plain.is_empty():
            raise ValueError(
                "No trace variants remain after applying the filter_out threshold."
            )
    elif isinstance(filter_out, float) and filter_out > 0.0:
        variants_plain = variants_plain.filter(
            (pl.col("case_count") / pl.lit(total_cases)) >= pl.lit(filter_out)
        )
        if variants_plain.is_empty():
            raise ValueError(
                "No trace variants remain after applying the filter_out threshold."
            )

    if isinstance(filter_out_top, int):
        variants_plain = variants_plain.filter(
            pl.col("case_count") <= pl.lit(filter_out_top)
        )
        if variants_plain.is_empty():
            raise ValueError(
                "No trace variants remain after applying the filter_out_top threshold."
            )
    elif isinstance(filter_out_top, float):
        variants_plain = variants_plain.filter(
            (pl.col("case_count") / pl.lit(total_cases)) <= pl.lit(filter_out_top)
        )
        if variants_plain.is_empty():
            raise ValueError(
                "No trace variants remain after applying the filter_out_top threshold."
            )

    allowed_variants = set(
        tuple(variant) for variant in variants_plain.get_column("variant").to_list()
    )
    per_case = per_case.filter(
        pl.col("variant").map_elements(
            lambda variant: tuple(variant) in allowed_variants,
            return_dtype=pl.Boolean,
        )
    )

    predicates = list(predicates or [])
    named_predicates = _normalise_predicates(predicates)
    predicate_names = [name for name, _ in named_predicates]
    predicate_palette = _generate_palette(len(named_predicates))
    per_case_lf = per_case.lazy()

    predicate_columns: list[str] = []
    for index, (_, predicate) in enumerate(named_predicates):
        column_name = f"__predicate_{index}"
        predicate_columns.append(column_name)
        predicate_expr = (
            _normalise_predicate_result(predicate, per_case_lf)
            .fill_null(False)
            .cast(pl.Boolean)
        )
        per_case_lf = per_case_lf.with_columns(predicate_expr.alias(column_name))

    if predicate_columns:
        mask_expr = pl.lit(0, dtype=pl.UInt32)
        for index, name in enumerate(predicate_columns):
            mask_expr = mask_expr + pl.col(name).cast(pl.UInt32) * (1 << index)
        per_case = per_case_lf.with_columns(mask_expr.alias("highlight_mask")).collect()
    else:
        per_case = per_case.with_columns(
            pl.lit(0, dtype=pl.UInt32).alias("highlight_mask")
        )

    variants = (
        per_case.group_by(["variant", "highlight_mask"], maintain_order=True)
        .agg(pl.len().alias("case_count"))
        .with_columns(pl.col("variant").list.len().alias("variant_length"))
    )

    max_length = variants.get_column("variant_length").max() if variants.height else 0
    if max_length:
        variants = variants.with_columns(
            [
                pl.col("variant")
                .list.get(index, null_on_oob=True)
                .alias(f"event_{index + 1}")
                for index in range(max_length)
            ]
        )

    unique_activities = sorted(
        {
            activity
            for variant in variants.get_column("variant").to_list()
            for activity in variant
        },
        key=_parse_event_position,
    )

    node_total_flow: dict[str, int] = {}
    edge_weights: dict[tuple[str, str], int] = {}
    for variant, case_count in variants.select("variant", "case_count").iter_rows():
        for activity in variant:
            node_total_flow[activity] = node_total_flow.get(activity, 0) + int(
                case_count
            )
        for source, target in zip(variant, variant[1:], strict=False):
            edge_weights[(source, target)] = edge_weights.get((source, target), 0) + int(
                case_count
            )

    if align_time == "abs":
        time_aligned_x_positions = _compute_abs_time_aligned_x_positions(
            per_case, unique_activities, time_agg_type
        )
    elif align_time == "delta":
        time_aligned_x_positions = _compute_delta_time_aligned_x_positions(
            per_case, unique_activities, time_agg_type
        )
    else:
        time_aligned_x_positions = {}
    node_x, node_y = _compute_node_positions(
        unique_activities,
        node_total_flow,
        edge_weights=edge_weights,
        x_positions=time_aligned_x_positions or None,
    )
    activity_time_values = _compute_activity_time_values(
        per_case, align_time=align_time, time_agg_type=time_agg_type
    )
    node_time_labels = _compute_node_time_labels(
        per_case,
        unique_activities,
        align_time,
        time_agg_type,
    )
    node_trace_counts = _compute_node_trace_counts(per_case, unique_activities)
    node_customdata = [
        [time_label, trace_count]
        for time_label, trace_count in zip(
            node_time_labels, node_trace_counts, strict=True
        )
    ]
    node_indices = {activity: index for index, activity in enumerate(unique_activities)}

    edge_rows: list[dict[str, Any]] = []
    for variant, case_count, highlight_mask in variants.select(
        "variant", "case_count", "highlight_mask"
    ).iter_rows():
        for source, target in zip(variant, variant[1:], strict=False):
            edge_rows.append(
                {
                    "source": source,
                    "target": target,
                    "source_idx": node_indices[source],
                    "target_idx": node_indices[target],
                    "case_count": case_count,
                    "highlight_mask": int(highlight_mask),
                }
            )

    if edge_rows:
        links = (
            pl.DataFrame(edge_rows)
            .group_by(
                ["source", "target", "source_idx", "target_idx", "highlight_mask"],
                maintain_order=True,
            )
            .agg(pl.col("case_count").sum().alias("value"))
            .sort(["source_idx", "target_idx", "highlight_mask"])
        )
    else:
        links = pl.DataFrame(
            schema={
                "source": pl.String,
                "target": pl.String,
                "source_idx": pl.UInt32,
                "target_idx": pl.UInt32,
                "highlight_mask": pl.UInt32,
                "value": pl.UInt32,
            }
        )

    mask_to_color: dict[int, str] = {0: _MUTED_LINK_COLOR}
    mask_to_label: dict[int, str] = {0: "No predicate matched"}
    for mask in sorted(
        links.get_column("highlight_mask").unique().to_list() if links.height else [0]
    ):
        if mask == 0:
            continue
        active_indices = [
            index for index in range(len(named_predicates)) if mask & (1 << index)
        ]
        blended_color = _blend_hex_colors(
            [predicate_palette[index] for index in active_indices]
        )
        mask_to_color[mask] = _rgb_to_rgba(blended_color, 0.82)
        mask_to_label[mask] = " + ".join(
            predicate_names[index] for index in active_indices
        )

    link_colors = (
        [
            mask_to_color[int(mask)]
            for mask in links.get_column("highlight_mask").to_list()
        ]
        if links.height
        else []
    )
    link_labels = (
        [
            mask_to_label[int(mask)]
            for mask in links.get_column("highlight_mask").to_list()
        ]
        if links.height
        else []
    )
    used_masks = sorted(
        {0, *(int(mask) for mask in links.get_column("highlight_mask").to_list())}
        if links.height
        else {0}
    )
    total_traces = per_case.height
    if total_traces:
        mask_counts = {
            int(highlight_mask): int(case_count)
            for highlight_mask, case_count in per_case.group_by(
                "highlight_mask", maintain_order=True
            )
            .agg(pl.len().alias("case_count"))
            .iter_rows()
        }
        mask_to_fraction = {
            mask: mask_counts.get(mask, 0) / total_traces for mask in used_masks
        }
    else:
        mask_to_fraction = {mask: 0.0 for mask in used_masks}

    figure = go.Figure(
        data=[
            go.Sankey(
                arrangement="fixed",
                node=dict(
                    pad=15,
                    thickness=20,
                    line=dict(color="rgba(80, 80, 80, 0.35)", width=0.5),
                    label=unique_activities,
                    color=[_DEFAULT_NODE_COLOR] * len(unique_activities),
                    customdata=node_customdata,
                    hovertemplate=(
                        "%{label}<br>"
                        "time: '%{customdata[0]}'<br>"
                        "count: %{customdata[1]}<extra></extra>"
                    ),
                    x=node_x,
                    y=node_y,
                ),
                link=dict(
                    source=links.get_column("source_idx").to_list()
                    if links.height
                    else [],
                    target=links.get_column("target_idx").to_list()
                    if links.height
                    else [],
                    value=links.get_column("value").to_list() if links.height else [],
                    color=link_colors,
                    customdata=link_labels,
                    hovertemplate=(
                        "%{source.label} → %{target.label}<br>"
                        "Cases: %{value}<br>"
                        "Highlight: %{customdata}<extra></extra>"
                    ),
                ),
            )
        ]
    )
    axis_annotations, axis_shapes = _build_time_axis(activity_time_values, align_time)
    legend_annotations, legend_shapes, legend_entry_count = _build_highlight_legend(
        used_masks,
        mask_to_color,
        mask_to_label,
        mask_to_fraction,
    )
    right_margin = 360
    computed_height = max(
        700,
        min(3600, max(24 * len(unique_activities), 52 * legend_entry_count + 120)),
    )
    figure.update_layout(
        title_text=title,
        font_size=11,
        height=height if height is not None else computed_height,
        annotations=axis_annotations + legend_annotations,
        shapes=axis_shapes + legend_shapes,
        margin=dict(b=120 if axis_annotations else 40, r=right_margin),
    )

    if show:
        figure.show()

    return figure, variants_plain, links
