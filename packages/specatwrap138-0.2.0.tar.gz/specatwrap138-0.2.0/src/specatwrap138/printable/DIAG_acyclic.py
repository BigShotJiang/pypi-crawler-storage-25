import polars as pl

lf: pl.LazyFrame = None
lf_allowed: pl.LazyFrame = None
lf_strict: pl.LazyFrame = None
# {{paste:begin}}

# {{paste:DIAG_initial_sorting_all}}

# {{paste:DIAG_stats}}

lf = lf.filter((pl.col("TDiag") == "Death").last().over("case:PNR"))

# {{paste:DIAG_filter}}

lazyframes = [lf, lf_allowed, lf_strict]
def add_diag_index(lazy_df: pl.LazyFrame) -> pl.LazyFrame:
    return lazy_df.with_columns(
        TDiag=pl.concat_str(
            [
                pl.lit("_"),
                pl.int_range(1, pl.len() + 1).over("case:PNR"),
                pl.lit("_"),
                pl.col("TDiag"),
            ]
        )
    )


lf, lf_allowed, lf_strict = [add_diag_index(frame) for frame in lazyframes]
df, df_allowed, df_strict = pl.collect_all([lf, lf_allowed, lf_strict])
# 404261000016009
