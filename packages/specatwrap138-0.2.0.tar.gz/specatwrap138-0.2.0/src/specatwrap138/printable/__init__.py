"""
CLI command to copy Python files from the printable folder to clipboard.

This allows easy transfer of scripts on the remote protected machine.
"""

import subprocess
from pathlib import Path
import tempfile
import re

import click


PASTE_PATTERN = re.compile(
    r"(?m)^[ \t]*#[ \t]*\{\{\s*paste:(?P<target>[^}]+)\s*\}\}[ \t]*$"
)
BEGIN_PATTERN = re.compile(r"(?m)^[ \t]*(?:#|//)[ \t]*\{\{\s*paste:begin\s*\}\}[ \t]*$")


def _format_subprocess_error(label: str, error: subprocess.CalledProcessError) -> str:
    stdout = (error.stdout or "").strip()
    stderr = (error.stderr or "").strip()
    details = [f"{label} failed with exit code {error.returncode}."]

    if stdout:
        details.append(f"stdout: {stdout}")
    if stderr:
        details.append(f"stderr: {stderr}")

    return " ".join(details)


def _copy_to_clipboard(content: str) -> None:
    with tempfile.NamedTemporaryFile(
        "w", encoding="utf-8", delete=False, suffix=".txt"
    ) as tmp:
        tmp.write(content)
        temp_path = Path(tmp.name)
    try:
        subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-Command",
                f"Set-Clipboard -Value (Get-Content -Raw -Encoding UTF8 '{temp_path}')",
            ],
            text=True,
            check=True,
            capture_output=True,
        )
        return
    except FileNotFoundError:
        pass
    except subprocess.CalledProcessError as error:
        raise RuntimeError(_format_subprocess_error("powershell.exe", error)) from error
    finally:
        temp_path.unlink(missing_ok=True)

    try:
        subprocess.run(
            ["clip.exe"],
            input=content,
            text=True,
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as error:
        raise RuntimeError(_format_subprocess_error("clip.exe", error)) from error


def _exclude_prelude(content: str) -> str:
    begin_match = BEGIN_PATTERN.search(content)
    if not begin_match:
        return content
    return content[begin_match.end() :].lstrip("\n")


def _expand_paste_markers(
    content: str, printable_dir: Path, include_stack: set[Path] | None = None
) -> str:
    content = _exclude_prelude(content)
    stack = include_stack or set()

    def _replace(match: re.Match[str]) -> str:
        raw_target = match.group("target").strip()
        target_name = raw_target if raw_target.endswith(".py") else f"{raw_target}.py"
        target_path = (printable_dir / target_name).resolve()

        if target_path in stack:
            raise ValueError(f"Circular paste include detected for '{target_name}'.")
        if not target_path.exists():
            raise ValueError(f"Paste include file '{target_name}' not found.")

        stack.add(target_path)
        target_content = _exclude_prelude(target_path.read_text(encoding="utf-8"))
        expanded = _expand_paste_markers(target_content, printable_dir, stack)
        stack.remove(target_path)
        return expanded

    return PASTE_PATTERN.sub(_replace, content)


@click.command("print")
@click.argument("filename", required=False)
@click.option("--list", "-l", is_flag=True, help="List all available printable files")
@click.option("--imports", "-i", is_flag=True, help="Include import statements")
def print_file(filename: str | None, list: bool, imports: bool) -> None:
    """
    Copy Python files from the printable folder to clipboard.

    This command helps transfer code to the restricted environment by copying
    file contents directly to the Windows clipboard.

    By default, import statements are excluded. Use -i to include them.

    Usage:

        specatwrap print diagnosis_kpi

        specatwrap print diagnosis_kpi -i

        specatwrap print --list

    \b
    Arguments:
        FILENAME: Name of the file to copy (without .py extension)
    """
    printable_dir = Path(__file__).parent

    # List available files
    if list:
        python_files = sorted(printable_dir.glob("*.py"))
        python_files = [f for f in python_files if f.name != "__init__.py"]

        if not python_files:
            click.echo("No printable files available.")
            return

        click.echo("Available printable files:")
        for file in python_files:
            click.echo(f"  - {file.stem}")
        return

    # Print specific file
    if not filename:
        click.echo(
            "Error: Please provide a filename or use --list to see available files."
        )
        click.echo("Usage: specatwrap print <filename>")
        click.echo("       specatwrap print --list")
        raise click.Abort()

    # Add .py extension if not present
    if not filename.endswith(".py"):
        filename = f"{filename}.py"

    file_path = printable_dir / filename

    if not file_path.exists():
        click.echo(f"Error: File '{filename}' not found in printable folder.")
        click.echo("\nUse 'specatwrap print --list' to see available files.")
        raise click.Abort()

    # Read and copy to clipboard
    try:
        content = file_path.read_text(encoding="utf-8")
        content = _expand_paste_markers(content, printable_dir)

        # Filter out import statements if -i flag is not set
        if not imports:
            lines = content.split("\n")
            filtered_lines = []

            for line in lines:
                stripped = line.strip()
                # Skip import and from...import statements
                if stripped.startswith("import ") or stripped.startswith("from "):
                    continue
                filtered_lines.append(line)

            content = "\n".join(filtered_lines)

        _copy_to_clipboard(content)

        import_status = "with imports" if imports else "without imports"
        click.echo(f"✓ Content of '{filename}' copied to clipboard ({import_status})!")

    except ValueError as e:
        click.echo(f"Error processing paste markers: {e}")
        raise click.Abort()
    except RuntimeError as e:
        click.echo(f"Error copying to clipboard: {e}")
        click.echo(f"Debug content preview: {content[:120]!r}")
        raise click.Abort()
    except Exception as e:
        click.echo(f"Error reading file: {e}")
        raise click.Abort()
