import polars as pl

lf: pl.LazyFrame = None  # pyright: ignore[reportAssignmentType]
# {{paste:begin}}
# {{paste:PW_base}}

lf = lf.with_columns(
    ansSpec=pl.concat_str(
        [
            pl.lit("_"),
            pl.int_range(1, pl.len() + 1).over("c:id"),
            pl.lit("_"),
            pl.col("ansSpec"),
        ]
    )
)
