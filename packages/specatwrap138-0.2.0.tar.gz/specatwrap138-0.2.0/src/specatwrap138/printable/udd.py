import polars as pl

lf_edu = (
    pl.scan_parquet("./UDD.parquet")
    .unique("PNR")
    .with_columns(
        pl.when(
            pl.col("HFAUDD").is_between(100, 299)
            | pl.col("HFAUDD").is_between(1000, 2999)
        )
        .then(pl.lit("GRUND"))
        .when(
            pl.col("HFAUDD").is_between(300, 399)
            | pl.col("HFAUDD").is_between(3000, 3999)
        )
        .then(pl.lit("GYM"))
        .when(
            pl.col("HFAUDD").is_between(400, 599)
            | pl.col("HFAUDD").is_between(4000, 5999)
        )
        .then(pl.lit("EUD"))
        .when((pl.col("HFAUDD") == 600) | pl.col("HFAUDD").is_between(6000, 6999))
        .then(pl.lit("MVU"))
        .when((pl.col("HFAUDD") == 700) | pl.col("HFAUDD").is_between(7000, 7999))
        .then(pl.lit("LVU"))
        .when((pl.col("HFAUDD") == 800) | pl.col("HFAUDD").is_between(8000, 9999))
        .then(pl.lit("PHD"))
        .otherwise(pl.lit("UKENDT"))
        .alias("HFAUDD")
    )
)
