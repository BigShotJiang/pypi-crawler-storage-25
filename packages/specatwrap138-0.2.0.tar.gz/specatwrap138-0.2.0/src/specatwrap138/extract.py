"""CLI command for extracting bundled SOR data."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from .sor_data import extract_sor_trimmed


@click.command()
def extract() -> None:
    """Extract the bundled SOR CSV into the working directory as sor.csv."""
    try:
        output_path = extract_sor_trimmed(Path.cwd(), output_name="sor.csv")
        click.secho(f"✓ Extracted to {output_path}", fg="green")
    except FileExistsError as error:
        click.secho(f"✗ Error: {error}", fg="red", err=True)
        sys.exit(1)
    except Exception as error:
        click.secho(f"✗ Error: {error}", fg="red", err=True)
        sys.exit(1)
