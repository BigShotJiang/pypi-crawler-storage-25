import polars as pl

from .base_filter import BaseFilter


class PathwaysFilter(BaseFilter):
    CASE_ATTR = {
        k: f"c:{v}"
        for k, v in {
            "PNR": "PNR",
            "DW_EK_BORGER": "patientId",
            "DW_EK_HELBREDSFORLOEB": "id",
            "HELBREDSFORL_STARTTIDSPUNKT": "pathStartTime",
            "HELBREDSFORL_SLUTTIDSPUNKT": "pathEndTime",
            "BORGER_KOEN": "gender",
            "BORGER_FOEDSELSDATO": "birthDate",
            "WEALTH": "wealth",
            "HFAUDD": "udd"
        }.items()
    }

    EVENT_ATTR = {
        "DW_EK_FORLOEB": "id",
        "FORL_AFSLUT_MAADE_TEKST": "endReason",
        "FORL_HENV_AARSAG": "diagnosis",
        "FORL_HENV_MAADE_TEKST": "referralReason",
        "FORL_LABEL": "label",
        "FORL_LABEL_TEKST": "labelText",
        "FORL_ANS": "ans",
        "FORL_ANS_TEKST": "ansText",
        "FORL_ANS_INST": "ansInst",
        "FORL_ANS_SPEC": "ansSpec",
        "FORL_ANS_INST_TEKST": "ansInstText",
        "FORL_STARTTIDSPUNKT": "startTime",
        "FORL_SLUTTIDSPUNKT": "endTime",
        "FORL_ANS_GEO_REG_TEKST": "region"
    }

    def apply(self, lf: pl.LazyFrame) -> pl.LazyFrame:
        sor_lf = pl.scan_csv("./sor.csv").select(
            [
                pl.col("SOR-kode").cast(pl.String).alias("SOR_ID"),
                pl.col("Enhedsnavn").cast(pl.String),
                pl.col("Hovedspeciale").cast(pl.String).alias("FORL_ANS_SPEC"),
            ]
        )

        for key, name in [
            ("FORL_ANS", "FORL_ANS_TEKST"),
            ("FORL_ANS_INST", "FORL_ANS_INST_TEKST"),
        ]:
            cols_to_select = ["SOR_ID", "Enhedsnavn"]
            if key == "FORL_ANS":
                cols_to_select.append("FORL_ANS_SPEC")
            lf = lf.join(
                sor_lf.rename({"Enhedsnavn": name}),
                left_on=key,
                right_on="SOR_ID",
                how="left",
            )

        lf_contacts = (
            pl.scan_parquet(r".\combined_diag_death.parquet")
            .select("case:PNR", "case:BDay", "case:gender")
            .unique(subset=["case:PNR"])
        )
        lf_bef = (
            pl.scan_parquet(r".\bef.parquet")
            .select("PNR", "FOED_DAG", "KOEN")
            .unique(subset=["PNR"])
        )

        lf = lf.join(
            lf_contacts.rename(
                {
                    "case:PNR": "PNR",
                    "case:BDay": "CONTACT_BDAY",
                    "case:gender": "CONTACT_GENDER",
                }
            ),
            on="PNR",
            how="left",
        )
        lf = lf.join(
            lf_bef.rename({"FOED_DAG": "BEF_BDAY", "KOEN": "BEF_GENDER"}),
            on="PNR",
            how="left",
        )

        lf_income = pl.scan_parquet("./IND.parquet").unique("PNR")
        lf = lf.join(
            lf_income,
            on="PNR",
            how="left",
        )

        lf_edu = (
            pl.scan_parquet("./UDD.parquet")
            .unique("PNR")
            .with_columns(
                pl.when(
                    pl.col("HFAUDD").is_between(100, 299)
                    | pl.col("HFAUDD").is_between(1000, 2999)
                )
                .then(pl.lit("GRUND"))
                .when(
                    pl.col("HFAUDD").is_between(300, 399)
                    | pl.col("HFAUDD").is_between(3000, 3999)
                )
                .then(pl.lit("GYM"))
                .when(
                    pl.col("HFAUDD").is_between(400, 599)
                    | pl.col("HFAUDD").is_between(4000, 5999)
                )
                .then(pl.lit("EUD"))
                .when(
                    (pl.col("HFAUDD") == 600) | pl.col("HFAUDD").is_between(6000, 6999)
                )
                .then(pl.lit("MVU"))
                .when(
                    (pl.col("HFAUDD") == 700) | pl.col("HFAUDD").is_between(7000, 7999)
                )
                .then(pl.lit("LVU"))
                .when(
                    (pl.col("HFAUDD") == 800) | pl.col("HFAUDD").is_between(8000, 9999)
                )
                .then(pl.lit("PHD"))
                .otherwise(pl.lit("UKENDT"))
                .alias("HFAUDD")
            )
        )
        lf = lf.join(
            lf_edu,
            on="PNR",
            how="left",
        )

        lf = lf.with_columns(
            BORGER_FOEDSELSDATO=pl.coalesce("BEF_BDAY", "CONTACT_BDAY"),
            BORGER_KOEN=pl.coalesce("BEF_GENDER", "CONTACT_GENDER"),
        ).drop("BEF_BDAY", "CONTACT_BDAY", "BEF_GENDER", "CONTACT_GENDER")

        return (
            lf.select(list((self.CASE_ATTR | self.EVENT_ATTR).keys()))
            .rename(self.CASE_ATTR | self.EVENT_ATTR)
            .sort(["c:id", "startTime"])
        )
