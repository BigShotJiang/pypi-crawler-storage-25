"""
I/O handler for parquet file processing.

This module provides generic I/O functionality for reading, filtering,
and writing parquet files. It uses a filter registry pattern to support
different filter types (diagnosis, procedure, medication, etc.).
"""

from pathlib import Path
from typing import Type
import polars as pl

from .base_filter import BaseFilter
from .diagnosis import DiagnosisFilter
from .pathways import PathwaysFilter


# Registry mapping filter type strings to filter classes
FILTER_REGISTRY: dict[str, Type[BaseFilter]] = {
    "diagnosis": DiagnosisFilter,
    "pathways": PathwaysFilter,
    # Future additions:
    # "procedure": ProcedureFilter,
    # "medication": MedicationFilter,
}


def process_parquet_files(
    input_dir: Path,
    output_file: Path,
    filter_type: str,
    verbose: bool = False,
):
    """
    Process parquet files with a specified filter type.

    This function handles all I/O operations:
    - Discovers parquet files in the input directory
    - Lazily loads them using Polars
    - Applies the specified filter transformation
    - Collects the results and writes to output file

    Args:
        input_dir: Directory containing input parquet files
        output_file: Path to output parquet file
        filter_type: Type of filter to apply (e.g., "diagnosis", "procedure")
        verbose: Whether to include verbose processing (currently unused in I/O layer)

    Returns:
        Tuple of (row_count, column_count, column_names)

    Raises:
        FileNotFoundError: If no parquet files found in input directory
        ValueError: If filter_type is not registered
        PermissionError: If unable to read/write files
        MemoryError: If insufficient memory to process data
    """
    # Validate filter type
    if filter_type not in FILTER_REGISTRY:
        available_filters = ", ".join(FILTER_REGISTRY.keys())
        raise ValueError(
            f"Unknown filter type '{filter_type}'. "
            f"Available filters: {available_filters}"
        )

    # Check if input directory contains parquet files
    parquet_files = list(input_dir.glob("*.parquet"))
    if not parquet_files:
        raise FileNotFoundError(f"No parquet files found in {input_dir}")

    # Create parquet file pattern for lazy loading
    parquet_pattern = str(input_dir / "*.parquet")

    # Lazy load all parquet files
    lazy_frame = pl.scan_parquet(parquet_pattern)

    # Instantiate the appropriate filter
    filter_class = FILTER_REGISTRY[filter_type]
    filter_instance = filter_class()

    # Apply the filter transformation
    filtered_lazy_frame = filter_instance.apply(lazy_frame)

    # Collect the lazy frame (materialize the data)

    # Ensure output directory exists
    output_file.parent.mkdir(parents=True, exist_ok=True)

    filtered_lazy_frame.sink_parquet(output_file)
