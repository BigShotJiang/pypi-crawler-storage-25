"""
Base filter class for parquet preprocessing.
"""

from abc import ABC, abstractmethod

import polars as pl


class BaseFilter(ABC):
    """
    Abstract base class for parquet file filters.

    Each filter type (diagnosis, procedure, medication, etc.) should inherit
    from this class and implement the apply() method with their specific
    filtering and transformation logic.
    """

    @abstractmethod
    def apply(self, lf: pl.LazyFrame) -> pl.LazyFrame:
        """
        Apply filtering and preprocessing logic to a LazyFrame.

        Args:
            lazy_frame: Input Polars LazyFrame to filter/transform

        Returns:
            Transformed Polars LazyFrame
        """
        pass

    def get_name(self) -> str:
        """
        Get the name of this filter type.

        Returns:
            Filter type name (defaults to class name without 'Filter' suffix)
        """
        class_name = self.__class__.__name__
        if class_name.endswith("Filter"):
            return class_name[:-6].lower()
        return class_name.lower()
