# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/).



## [0.3.0](https://github.com/rvben/n8nc/compare/v0.2.1...v0.3.0) - 2026-03-28

### Added

- add search, runs stats, and lint commands ([f587d5e](https://github.com/rvben/n8nc/commit/f587d5e05a3f87c0d8e95d5c6af59f4f23fbcac0))

## [0.2.1](https://github.com/rvben/n8nc/compare/v0.2.0...v0.2.1) - 2026-03-28

### Added

- batch 2 improvements ([f66fcbb](https://github.com/rvben/n8nc/commit/f66fcbb6bcb3601a251899cdbbd8095e6fc4e104))

## [0.2.0](https://github.com/rvben/n8nc/compare/v0.1.0...v0.2.0) - 2026-03-28

### Added

- add archive and unarchive commands ([19856d9](https://github.com/rvben/n8nc/commit/19856d9f97afa39096da6f53cfd0a4d702ace00b))
- **show**: add --tree flag for execution flow visualization ([5c86fa3](https://github.com/rvben/n8nc/commit/5c86fa3c8f41f99a2748f002c1b2f3a0cd69b507))
