"""Skill template for creating ToothFairyAI agents.

This skill guides AI assistants through the agent creation process
with validation rules and example payloads.
"""

CREATE_AGENT_SKILL = {
    "name": "create-agent",
    "description": "Create a new ToothFairyAI agent with proper validation",
    "steps": [
        {
            "step": 1,
            "title": "Determine agent mode",
            "description": "Choose the appropriate agent mode based on use case",
            "options": {
                "retriever": "RAG-based agent with knowledge search (can enable agenticRAG, hasCode, charting)",
                "coder": "Code generation agent (REQUIRES has_code=True, CANNOT have agenticRAG)",
                "chatter": "Creative conversational agent (agenticRAG must be false)",
                "planner": "Planning and orchestration agent",
                "voice": "Voice-enabled agent (latency-sensitive, NEVER enable agenticRAG)",
                "accuracy": "High-accuracy mode for complex reasoning",
            },
        },
        {
            "step": 2,
            "title": "Validate mode-specific constraints",
            "description": "CRITICAL: These constraints are validated BEFORE API call",
            "constraints": {
                "coder_mode": {
                    "requires": "has_code=True",
                    "forbids": "agenticRAG=True",
                    "error": "Coder agents cannot have agenticRAG enabled",
                },
                "voice_mode": {
                    "forbids": "agenticRAG=True",
                    "reason": "Voice agents are latency-sensitive, agenticRAG adds overhead",
                },
                "retriever_mode": {
                    "allows": ["agenticRAG=True", "hasCode=True", "charting=True"],
                    "note": "Most flexible mode for knowledge-based agents",
                },
            },
        },
        {
            "step": 3,
            "title": "Set required parameters",
            "required": ["label", "mode", "interpolation_string", "goals", "api_key", "workspace_id"],
            "descriptions": {
                "label": "Human-readable agent name (string)",
                "mode": "Agent mode from: retriever, coder, chatter, planner, voice, accuracy",
                "interpolation_string": "System prompt/instructions for the agent (string)",
                "goals": "Agent's purpose and objectives (string)",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 4,
            "title": "Set optional parameters with validation",
            "optional": {
                "temperature": {
                    "type": "float",
                    "range": "0.001 to 1.0",
                    "default": 0.3,
                    "error": "Temperature must be between 0.001 and 1.0",
                },
                "max_tokens": {
                    "type": "integer",
                    "range": "positive integer",
                    "default": 4096,
                    "error": "max_tokens must be a positive integer",
                },
                "agentic_rag": {
                    "type": "boolean",
                    "constraint": "Mode-dependent (see step 2)",
                },
                "has_code": {
                    "type": "boolean",
                    "constraint": "REQUIRED for coder mode",
                },
                "charting": {
                    "type": "boolean",
                    "description": "Enable chart generation capabilities",
                },
                "parent_agent_id": {
                    "type": "string",
                    "api_field": "parentAgentID",
                    "description": "Parent agent ID for hierarchical agents",
                },
                "enable_json_output": {
                    "type": "boolean",
                    "default": False,
                    "description": "Enable structured JSON output mode",
                    "requires": "json_output_structure",
                },
                "json_output_structure": {
                    "type": "dict",
                    "description": "JSON schema defining the output structure (required if enable_json_output=True)",
                    "example": {
                        "type": "object",
                        "properties": {
                            "answer": {"type": "string"},
                            "confidence": {"type": "number"},
                            "sources": {"type": "array", "items": {"type": "string"}},
                        },
                    },
                },
            },
        },
        {
            "step": 5,
            "title": "Build API payload with correct field mappings",
            "description": "SDK automatically converts snake_case to camelCase with exceptions",
            "field_mappings": {
                "parent_agent_id": "parentAgentID",
                "agentic_rag": "agenticRAG",
                "has_ner": "hasNER",
                "has_code": "hasCode",
                "allow_external_api": "allowExternalAPI",
                "code_execution_environment_id": "codeExecutionEnvironmentID",
            },
        },
    ],
    "examples": {
        "minimal_retriever": {
            "description": "Minimal retriever agent with knowledge search",
            "payload": {
                "label": "Knowledge Assistant",
                "mode": "retriever",
                "interpolation_string": "You are a helpful knowledge assistant. Search the knowledge base to answer questions accurately.",
                "goals": "Help users find information from the knowledge base",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "coder_agent": {
            "description": "Code generation agent (NOTE: has_code=True is REQUIRED)",
            "payload": {
                "label": "Python Developer",
                "mode": "coder",
                "interpolation_string": "You are an expert Python developer. Write clean, efficient, well-documented code.",
                "goals": "Help users write and debug Python code",
                "has_code": True,
                "temperature": 0.2,
                "max_tokens": 8192,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
            "validation_note": "has_code MUST be True. agenticRAG MUST NOT be True.",
        },
        "advanced_retriever": {
            "description": "Advanced retriever with agenticRAG and charting",
            "payload": {
                "label": "Analytics Assistant",
                "mode": "retriever",
                "interpolation_string": "You are an analytics assistant. Search knowledge, analyze data, and create visualizations.",
                "goals": "Provide data insights with charts and visualizations",
                "agentic_rag": True,
                "charting": True,
                "temperature": 0.3,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "structured_output_retriever": {
            "description": "Retriever with structured JSON output for reliable parsing",
            "payload": {
                "label": "FAQ Bot",
                "mode": "retriever",
                "interpolation_string": "You are an FAQ assistant. Answer questions from the knowledge base. Always respond in structured JSON format.",
                "goals": "Provide structured answers to frequently asked questions",
                "enable_json_output": True,
                "json_output_structure": {
                    "type": "object",
                    "properties": {
                        "answer": {"type": "string"},
                        "confidence": {"type": "number"},
                        "sources": {"type": "array", "items": {"type": "string"}},
                    },
                },
                "temperature": 0.2,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "structured_output_chatter": {
            "description": "Chatter with structured JSON output for content generation",
            "payload": {
                "label": "Content Generator",
                "mode": "chatter",
                "interpolation_string": "You are a content generation assistant. Generate marketing copy in structured JSON format.",
                "goals": "Generate structured marketing content",
                "enable_json_output": True,
                "json_output_structure": {
                    "type": "object",
                    "properties": {
                        "headline": {"type": "string"},
                        "body": {"type": "string"},
                        "cta": {"type": "string"},
                        "tone": {"type": "string"},
                    },
                },
                "temperature": 0.7,
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "temperature_out_of_range": {
            "cause": "temperature value outside 0.001-1.0 range",
            "solution": "Use a value between 0.001 and 1.0 (e.g., 0.3)",
        },
        "coder_without_has_code": {
            "cause": "Coder mode requires has_code=True",
            "solution": "Set has_code=True when mode='coder'",
        },
        "coder_with_agentic_rag": {
            "cause": "Coder mode cannot have agenticRAG enabled",
            "solution": "Remove agentic_rag=True or use retriever mode instead",
        },
        "voice_with_agentic_rag": {
            "cause": "Voice mode cannot have agenticRAG (latency impact)",
            "solution": "Remove agentic_rag=True for voice agents",
        },
        "json_output_without_structure": {
            "cause": "enable_json_output=True requires json_output_structure",
            "solution": "Provide a JSON schema in json_output_structure",
        },
        "invalid_json_structure": {
            "cause": "json_output_structure is not a valid JSON Schema",
            "solution": "Use proper JSON Schema format with type, properties, etc.",
        },
    },
}