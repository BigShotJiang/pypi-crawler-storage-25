"""Skill template for creating ToothFairyAI agent functions (tools).

This skill guides AI assistants through function creation with JSON Schema validation.
"""

CREATE_FUNCTION_SKILL = {
    "name": "create-function",
    "description": "Create a new agent function (tool) for external API calls",
    "steps": [
        {
            "step": 1,
            "title": "Set required parameters",
            "required": ["name", "description", "url", "api_key", "workspace_id"],
            "descriptions": {
                "name": "Function name (e.g., 'get_weather')",
                "description": "Clear description of what the function does",
                "url": "API endpoint URL",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 2,
            "title": "Set request type",
            "description": "HTTP method for the API call",
            "options": ["get", "post", "put", "delete", "patch", "custom", "graphql_query", "graphql_mutation"],
            "default": "get",
        },
        {
            "step": 3,
            "title": "Define parameters in JSON Schema format",
            "description": "CRITICAL: Parameters MUST be in JSON Schema format, NOT deprecated array format",
            "validation": {
                "format": "JSON Schema object",
                "error": "Parameters must be a valid JSON Schema object with 'type', 'properties', and 'required'",
            },
            "correct_format": {
                "type": "object",
                "properties": {
                    "location": {"type": "string", "description": "City name"},
                    "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
                },
                "required": ["location"],
            },
            "deprecated_format": "DO NOT USE: [{'name': 'location', 'type': 'string'}]",
        },
        {
            "step": 4,
            "title": "Set authentication (optional)",
            "description": "Two-step process: 1) Create authorisation, 2) Use authorisation_id",
            "auth_types": {
                "none": "No authentication",
                "bearer": "Static bearer token (requires token_secret)",
                "apikey": "API key (requires token_secret)",
                "oauth": "OAuth2 client credentials (requires client_id, client_secret, authorization_base_url, grant_type)",
            },
            "field_mapping": {
                "authorisation_id": "authorisationID",
                "code_execution_environment_id": "codeExecutionEnvironmentID",
                "is_mcp_server": "isMCPServer",
            },
        },
    ],
    "examples": {
        "simple_get_function": {
            "description": "Simple GET function without authentication",
            "payload": {
                "name": "get_weather",
                "description": "Get current weather for a location",
                "url": "https://api.weather.com/current",
                "request_type": "get",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "location": {"type": "string", "description": "City name"},
                        "unit": {"type": "string", "enum": ["celsius", "fahrenheit"]},
                    },
                    "required": ["location"],
                },
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "authenticated_post_function": {
            "description": "POST function with bearer auth (requires authorisation_id first)",
            "payload": {
                "name": "create_record",
                "description": "Create a new record in the database",
                "url": "https://api.example.com/records",
                "request_type": "post",
                "authorisation_id": "auth-123",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Record name"},
                        "value": {"type": "number", "description": "Record value"},
                    },
                    "required": ["name"],
                },
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "deprecated_parameters_format": {
            "cause": "Using array format for parameters",
            "solution": "Use JSON Schema object format: {\"type\": \"object\", \"properties\": {...}, \"required\": [...]}",
        },
        "missing_authorisation": {
            "cause": "Function needs auth but no authorisation_id provided",
            "solution": "Create authorisation first, then use authorisation_id in function",
        },
    },
}