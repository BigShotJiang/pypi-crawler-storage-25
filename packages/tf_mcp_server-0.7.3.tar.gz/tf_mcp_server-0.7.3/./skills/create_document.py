"""Skill template for creating ToothFairyAI documents.

This skill guides AI assistants through document creation for the knowledge base.
"""

CREATE_DOCUMENT_SKILL = {
    "name": "create-document",
    "description": "Create a new document in the ToothFairyAI knowledge base",
    "steps": [
        {
            "step": 1,
            "title": "Set required parameters",
            "required": ["user_id", "title", "api_key", "workspace_id"],
            "descriptions": {
                "user_id": "User ID creating the document",
                "title": "Document title (1-500 characters)",
                "api_key": "ToothFairyAI API key",
                "workspace_id": "Workspace ID",
            },
        },
        {
            "step": 2,
            "title": "Choose document type",
            "description": "Type determines how content is provided",
            "doc_types": {
                "readComprehensionFile": "Upload file content directly (default)",
                "readComprehensionUrl": "Fetch content from URL (requires external_path as URL)",
                "readComprehensionText": "Plain text content provided directly",
            },
            "default": "readComprehensionFile",
        },
        {
            "step": 3,
            "title": "Set optional parameters",
            "optional": {
                "folder_id": {"default": "mrcRoot", "description": "Folder ID for organization"},
                "topics": {"type": "array of strings", "description": "Topic tags for the document"},
                "external_path": {"type": "string", "description": "URL for readComprehensionUrl type"},
                "source": {"type": "string", "description": "Source attribution"},
                "status": {"default": "published", "options": ["published", "draft", "archived"]},
                "scope": {"type": "string", "description": "Access scope"},
            },
        },
        {
            "step": 4,
            "title": "Build API payload",
            "description": "Document is wrapped in a data array",
            "payload_structure": {
                "data": [{"userid", "title", "type", "topics", "folderid", "external_path", "source", "status"}],
            },
            "field_mappings": {
                "user_id": "userid",
                "folder_id": "folderid",
                "doc_type": "type",
                "external_path": "external_path",
            },
        },
    ],
    "examples": {
        "basic_document": {
            "description": "Simple document with title",
            "payload": {
                "user_id": "user-123",
                "title": "Product Documentation",
                "topics": ["product", "documentation"],
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "url_document": {
            "description": "Document from URL (readComprehensionUrl)",
            "payload": {
                "user_id": "user-123",
                "title": "External Guide",
                "doc_type": "readComprehensionUrl",
                "external_path": "https://example.com/guide.html",
                "topics": ["external", "guide"],
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
        "folder_organized": {
            "description": "Document in specific folder",
            "payload": {
                "user_id": "user-123",
                "title": "API Reference",
                "folder_id": "folder-456",
                "topics": ["api", "reference"],
                "status": "published",
                "api_key": "YOUR_API_KEY",
                "workspace_id": "YOUR_WORKSPACE_ID",
            },
        },
    },
    "common_errors": {
        "invalid_url": {
            "cause": "external_path not a valid URL for readComprehensionUrl type",
            "solution": "Provide a valid http:// or https:// URL when doc_type is readComprehensionUrl",
        },
        "title_too_long": {
            "cause": "Title exceeds 500 characters",
            "solution": "Keep title under 500 characters",
        },
        "missing_user_id": {
            "cause": "user_id not provided",
            "solution": "Always provide user_id (required field)",
        },
    },
    "related_operations": {
        "search": {
            "tool": "search_toothfairy_documents",
            "params": ["text", "top_k (1-50)"],
        },
        "update": {
            "tool": "update_toothfairy_document",
            "params": ["document_id", "fields to update"],
        },
        "delete": {
            "tool": "delete_toothfairy_document",
            "params": ["document_id"],
        },
    },
}