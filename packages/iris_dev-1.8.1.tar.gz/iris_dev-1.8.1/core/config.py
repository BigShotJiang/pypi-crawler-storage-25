import json
import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    CONFIG_FILE = Path(sys.executable).parent / "iris.config.json"
else:
    CONFIG_FILE = Path(__file__).parent.parent / "iris.config.json"

PROFILES = {
    "unity": {
        "ignore_dirs": ["Library", "Temp", "Logs", "obj", "Build", ".git", "__pycache__"],
        "description": "Unity game projects"
    },
    "web": {
        "ignore_dirs": ["node_modules", "dist", ".next", "build", ".cache", ".git", "__pycache__"],
        "description": "Web projects (HTML/CSS/JS)"
    },
    "python": {
        "ignore_dirs": ["__pycache__", ".venv", "dist", "build", ".egg-info", ".git"],
        "description": "Python libraries and scripts"
    },
    "cli": {
        "ignore_dirs": ["__pycache__", ".venv", "dist", "build", ".git"],
        "description": "CLI tools"
    },
    "custom": {
        "ignore_dirs": [".git"],
        "description": "Manual configuration"
    }
}


def save_config(project_path, profile="custom"):
    config = {
        "project_path": str(project_path),
        "profile": profile,
        "ignore_dirs": PROFILES[profile]["ignore_dirs"]
    }
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)


def load_config():
    if not CONFIG_FILE.exists():
        return None
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def get_ignore_dirs():
    config = load_config()
    if not config:
        return [".git", "node_modules", "__pycache__", "dist", ".venv"]
    return config.get("ignore_dirs", [".git", "node_modules", "__pycache__", "dist", ".venv"])


def init():
    print("\niris — setup\n")

    print("Select a profile:")
    profile_names = list(PROFILES.keys())
    for i, name in enumerate(profile_names):
        print("  [" + str(i + 1) + "] " + name + " — " + PROFILES[name]["description"])

    print()
    choice = input("Profile (1-" + str(len(profile_names)) + "): ").strip()

    try:
        index = int(choice) - 1
        if index < 0 or index >= len(profile_names):
            raise ValueError
        profile = profile_names[index]
    except ValueError:
        print("[ERROR] Invalid choice, using 'custom'")
        profile = "custom"

    project_path = input("Enter project path: ").strip()
    path = Path(project_path)

    if not path.exists():
        print("[ERROR] Path does not exist: " + project_path)
        return

    save_config(path, profile)
    print("\nProject saved: " + str(path))
    print("Profile:       " + profile)
    print("Now run: iris run <file.yaml>\n")


def get_project_path():
    config = load_config()
    if not config:
        print("[ERROR] Project not initialized. Run: iris init")
        return None
    return Path(config["project_path"])


def get_profile():
    config = load_config()
    if not config:
        return "custom"
    return config.get("profile", "custom")