import yaml
from pathlib import Path


def collect_backup(base_path, write_list):
    backup = {}
    for item in write_list:
        if isinstance(item, dict):
            rel = list(item.keys())[0]
        else:
            rel = item
        filepath = Path(base_path) / rel
        if filepath.exists():
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    backup[rel] = f.read()
            except Exception:
                pass
    return backup


def extract_tips(raw_response):
    tips = []
    in_tips = False

    for line in raw_response.split("\n"):
        if line.strip().upper().startswith("TIPS"):
            in_tips = True
            continue
        if in_tips and line.strip():
            if line.startswith("FILE:") or line.startswith("---"):
                break
            tips.append(line.strip("- ").strip())

    return tips


def save_feedback(task, changed_files, raw_response, base_path, backup):
    tips = extract_tips(raw_response)

    report = {
        "task_completed": task,
        "changed_files": changed_files,
        "tips": tips if tips else "none",
    }

    if backup:
        report["backup"] = backup

    feedback_path = Path(base_path) / "iris_report.yaml"

    with open(feedback_path, "w", encoding="utf-8") as f:
        yaml.dump(report, f, allow_unicode=True, default_flow_style=False)

    print("  [REPORT]   iris_report.yaml")

    if tips:
        print("\n  [TIPS]")
        for tip in tips:
            print("  > " + tip)