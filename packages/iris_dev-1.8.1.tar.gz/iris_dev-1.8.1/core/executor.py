import sys
import ollama

DEFAULT_MODEL = "qwen2.5-coder:7b"

STRICT_FORMAT_REMINDER = """
IMPORTANT: You MUST respond using ONLY this exact format for every file:

FILE: path/to/file
```
full file content here
```

Rules:
- Start your response immediately with FILE:
- Do NOT write any explanation, comments or text outside of FILE: blocks
- Do NOT skip any file from the write list
- Always output the COMPLETE file content inside the code block
- Follow the instructions in the exact order they are given
"""

STRICT_FORMAT_FUNCTIONS_REMINDER = """
IMPORTANT: You MUST respond using ONLY this exact format for every function:

FILE: path/to/file
FUNCTION: FunctionName
```
full function content here
```

Rules:
- Start your response immediately with FILE:
- Do NOT write any explanation, comments or text outside of FILE:/FUNCTION: blocks
- Do NOT skip any function from the list
- Always output the COMPLETE function content inside the code block
- Do NOT modify anything outside the given functions
- Follow the instructions in the exact order they are given
"""

TIPS_REMINDER = """
After the FILE: blocks, add a TIPS block if you notice any of these:
- The task would be better solved by editing a different file than the ones in the write list
- There is a missing import or connection between files
- A change in another file is required for this to work
Format:
TIPS
- short advice here (mention exact file if relevant)
"""


def build_prompt(task, instructions, error, reference, read_context, write_files, tips):
    prompt = "Task: " + task + "\n\n"

    if error:
        prompt += "Error to fix:\n" + error + "\n\n"

    if read_context:
        prompt += "Project context (read-only, do not modify these files):\n"
        for path, content in read_context.items():
            prompt += "\n--- " + path + " ---\n" + content + "\n"

    if reference:
        prompt += "\nReference files (use these as examples for style and structure):\n"
        for path, content in reference.items():
            prompt += "\n--- " + path + " ---\n" + content + "\n"

    has_functions = any(
        isinstance(v, dict) and v.get("mode") == "functions"
        for v in write_files.values()
    )

    if has_functions:
        prompt += "\nFiles and functions you are allowed to modify:\n"
        for path, data in write_files.items():
            if isinstance(data, dict) and data.get("mode") == "functions":
                prompt += "\n--- " + path + " ---\n"
                prompt += "Modify ONLY these functions:\n"
                for func_name, func_text in data["functions"].items():
                    prompt += "\nFUNCTION: " + func_name + "\n```\n" + func_text + "\n```\n"
                if data.get("forbidden_functions"):
                    prompt += "\nNEVER touch these functions: " + ", ".join(data["forbidden_functions"]) + "\n"
            else:
                content = data.get("content", "") if isinstance(data, dict) else data
                if content:
                    prompt += "\n--- " + path + " ---\n" + content + "\n"
                else:
                    prompt += "\n--- " + path + " --- (does not exist, create it)\n"

        prompt += "\nInstructions:\n" + instructions + "\n"
        prompt += STRICT_FORMAT_FUNCTIONS_REMINDER
    else:
        prompt += "\nFiles you are allowed to modify or create:\n"
        for path, data in write_files.items():
            content = data.get("content", "") if isinstance(data, dict) else data
            if content:
                prompt += "\n--- " + path + " ---\n" + content + "\n"
            else:
                prompt += "\n--- " + path + " --- (does not exist, create it)\n"

        prompt += "\nInstructions:\n" + instructions + "\n"
        prompt += STRICT_FORMAT_REMINDER

    if tips:
        prompt += TIPS_REMINDER

    return prompt


def parse_response(response_text):
    results = {}
    current_file = None
    current_function = None
    in_block = False
    block_lines = []

    for line in response_text.split("\n"):
        if line.startswith("FILE:"):
            if current_file and block_lines:
                if current_function:
                    if current_file not in results:
                        results[current_file] = {}
                    if isinstance(results[current_file], dict):
                        results[current_file][current_function] = "\n".join(block_lines)
                else:
                    results[current_file] = "\n".join(block_lines)
            current_file = line.replace("FILE:", "").strip()
            current_function = None
            in_block = False
            block_lines = []

        elif line.startswith("FUNCTION:") and current_file:
            if current_function and block_lines:
                if current_file not in results:
                    results[current_file] = {}
                if isinstance(results[current_file], dict):
                    results[current_file][current_function] = "\n".join(block_lines)
            current_function = line.replace("FUNCTION:", "").strip()
            in_block = False
            block_lines = []

        elif line.startswith("```") and current_file:
            in_block = not in_block

        elif in_block and current_file:
            block_lines.append(line)

    if current_file and block_lines:
        if current_function:
            if current_file not in results:
                results[current_file] = {}
            if isinstance(results[current_file], dict):
                results[current_file][current_function] = "\n".join(block_lines)
        else:
            results[current_file] = "\n".join(block_lines)

    return results


def call_ollama(prompt, model):
    try:
        response = ollama.chat(
            model=model,
            messages=[{"role": "user", "content": prompt}]
        )
        return response["message"]["content"]
    except Exception as e:
        print("[ERROR] Ollama failed: " + str(e))
        print("[HINT] Make sure Ollama is running: ollama serve")
        print("[HINT] Make sure model is pulled: ollama pull " + model)
        sys.exit(1)


def execute(task, instructions, error, reference, read_context, write_files, tips, model):
    active_model = model if model else DEFAULT_MODEL
    print("  [MODEL]    " + active_model)

    prompt = build_prompt(task, instructions, error, reference, read_context, write_files, tips)
    response_text = call_ollama(prompt, active_model)
    changes = parse_response(response_text)

    if not changes:
        print("  [WARN] No FILE: blocks found in response")

    return changes, response_text