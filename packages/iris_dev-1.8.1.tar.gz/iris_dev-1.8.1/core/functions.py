import re
from pathlib import Path

BRACE_LANGUAGES = [".cs", ".js", ".ts", ".java", ".go", ".c", ".cpp", ".kt"]
INDENT_LANGUAGES = [".py"]


def get_language(filepath):
    ext = Path(filepath).suffix.lower()
    if ext in BRACE_LANGUAGES:
        return "brace"
    if ext in INDENT_LANGUAGES:
        return "indent"
    return "brace"  # default


def extract_function_brace(source, func_name):
    pattern = re.compile(
        r'((?:(?:public|private|protected|static|async|override|virtual|abstract|internal|readonly|func|fun)\s+)*'
        r'[\w<>\[\]]+\s+' + re.escape(func_name) + r'\s*\([^)]*\)\s*\{)',
        re.MULTILINE
    )

    match = pattern.search(source)
    if not match:
        return None, None, None

    start = match.start()
    brace_pos = source.index("{", match.start())
    depth = 0
    i = brace_pos

    while i < len(source):
        if source[i] == "{":
            depth += 1
        elif source[i] == "}":
            depth -= 1
            if depth == 0:
                end = i + 1
                return source[start:end], start, end
        i += 1

    return None, None, None


def extract_function_indent(source, func_name):
    lines = source.split("\n")
    start_line = None
    base_indent = None

    for i, line in enumerate(lines):
        stripped = line.lstrip()
        if stripped.startswith("def " + func_name + "(") or stripped.startswith("async def " + func_name + "("):
            start_line = i
            base_indent = len(line) - len(stripped)
            break

    if start_line is None:
        return None, None, None

    end_line = start_line + 1
    while end_line < len(lines):
        line = lines[end_line]
        if line.strip() == "":
            end_line += 1
            continue
        current_indent = len(line) - len(line.lstrip())
        if current_indent <= base_indent and end_line > start_line + 1:
            break
        end_line += 1

    func_text = "\n".join(lines[start_line:end_line])
    char_start = sum(len(l) + 1 for l in lines[:start_line])
    char_end = char_start + len(func_text)

    return func_text, char_start, char_end


def extract_function(source, func_name, lang):
    if lang == "indent":
        return extract_function_indent(source, func_name)
    return extract_function_brace(source, func_name)


def extract_functions_from_file(source, func_names, filepath):
    lang = get_language(filepath)
    result = {}

    for name in func_names:
        text, start, end = extract_function(source, name, lang)
        if text:
            result[name] = {"text": text, "start": start, "end": end}
        else:
            print("  [WARN] Function not found: " + name + " in " + filepath)

    return result


def inject_functions(original_source, updated_functions, filepath):
    lang = get_language(filepath)
    source = original_source

    for func_name, new_text in updated_functions.items():
        _, start, end = extract_function(source, func_name, lang)
        if start is None:
            print("  [WARN] Could not inject: " + func_name + " — not found in original")
            continue
        source = source[:start] + new_text + source[end:]

    return source


def build_functions_context(source, func_names, forbidden_funcs, filepath):
    allowed = [f for f in func_names if f not in forbidden_funcs]
    extracted = extract_functions_from_file(source, allowed, filepath)
    return {name: data["text"] for name, data in extracted.items()}