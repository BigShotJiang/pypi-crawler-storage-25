"""CLI Interface for Tengingarstjóri SSH Connection Manager.

Provides 'tg' commands for managing SSH connections.
"""

import json
import os
import shutil
import subprocess
from datetime import datetime
from importlib.metadata import version as _pkg_version
from pathlib import Path
from typing import Any, Dict, List, Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

try:
    __version__ = _pkg_version("tengingarstjori")
except Exception:
    __version__ = "0.0.0"

from .config_manager import SSHConfigManager
from .models import SSHConnection
from .setup import run_initial_setup

console = Console()


@click.group()
@click.version_option(version=__version__)
def cli() -> None:
    """Tengingarstjóri - SSH Connection Manager.

    A TUI-based SSH connection manager with smart config integration.
    """
    pass


@cli.command()
def init() -> None:
    """Initialize Tengingarstjóri and set up SSH config integration."""
    console.print(
        Panel("🔧 [bold blue]Tengingarstjóri Setup[/bold blue]", style="blue")
    )

    config_manager = SSHConfigManager()

    if config_manager.is_initialized():
        console.print(
            "[yellow]Already initialized. Use 'tg config' to modify settings.[/yellow]"
        )
        return

    # Check if SSH config file exists and create it if it doesn't
    ssh_config_path = config_manager.main_ssh_config
    if not ssh_config_path.exists():
        console.print(
            "[yellow]SSH config file does not exist. Creating it now...[/yellow]"
        )
        try:
            # Ensure the .ssh directory exists
            ssh_config_path.parent.mkdir(mode=0o700, exist_ok=True)

            # Create the config file with restricted permissions atomically
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            fd = os.open(ssh_config_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(
                    f"# SSH config file created by Tengingarstjóri on {timestamp}\n\n"
                )

            console.print(
                "[green]✓[/green] Created SSH config file with proper permissions"
            )

            # Since we just created the file, make a backup of this empty file
            # This ensures reset command will work later
            backup_path = ssh_config_path.with_suffix(".backup")
            shutil.copy2(ssh_config_path, backup_path)

        except Exception as e:
            console.print(f"[red]Error creating SSH config file: {e}[/red]")
            console.print(
                "[yellow]You may need to create it manually before continuing.[/yellow]"
            )
            return

    run_initial_setup(config_manager)


def _get_required_field(
    field_name: str,
    value: Optional[str],
    interactive: bool,
    prompt_text: str,
    error_msg: str,
) -> Optional[str]:
    """Get required fields for connection."""
    if not value or not value.strip():
        if interactive:
            result = Prompt.ask(prompt_text)
            if not result or not result.strip():
                console.print(f"[red]{error_msg}[/red]")
                return None
            return result
        else:
            console.print(f"[red]{error_msg}[/red]")
            return None
    return value


def _handle_ssh_key_selection(
    config_manager: SSHConfigManager, key: Optional[str], interactive: bool
) -> Optional[str]:
    """Handle SSH key selection logic."""
    if key:
        return key

    available_keys = config_manager.discover_ssh_keys()
    default_key = config_manager.get_setting("default_identity_file")

    if interactive and available_keys:
        console.print("\n[yellow]Available SSH keys:[/yellow]")
        for i, found_key in enumerate(available_keys, 1):
            marker = " (default)" if found_key == default_key else ""
            console.print(f"  {i}. {found_key}{marker}")

        key_choice = Prompt.ask(
            "[cyan]Select key (number) or enter custom path[/cyan]",
            default="default" if default_key else "",
        )

        if key_choice == "default" and default_key:
            return str(default_key)
        elif key_choice.isdigit() and 1 <= int(key_choice) <= len(available_keys):
            return available_keys[int(key_choice) - 1]
        elif key_choice:
            return key_choice
    elif not interactive and default_key:
        return str(default_key)
    elif interactive:
        user_key = Prompt.ask("[cyan]SSH key path (optional)[/cyan]", default="")
        return user_key if user_key else None

    return None


def _get_advanced_options(
    interactive: bool,
    proxy_jump: Optional[str],
    local_forward: Optional[str],
    remote_forward: Optional[str],
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """Get advanced SSH options if in interactive mode."""
    if not interactive or any([proxy_jump, local_forward, remote_forward]):
        return proxy_jump, local_forward, remote_forward

    if Confirm.ask("[cyan]Add advanced options?[/cyan]", default=False):
        if not proxy_jump:
            proxy_jump = Prompt.ask("[cyan]ProxyJump (optional)[/cyan]", default="")
        if not local_forward:
            local_forward = Prompt.ask(
                "[cyan]LocalForward (optional)[/cyan]\n"
                "[dim]Examples: 3306:localhost:3306, 8080:localhost:80,9000:localhost:9000[/dim]\n"
                "[cyan]Enter port forwards[/cyan]",
                default="",
            )
        if not remote_forward:
            remote_forward = Prompt.ask(
                "[cyan]RemoteForward (optional)[/cyan]\n"
                "[dim]Examples: 8080:localhost:80, 3000:localhost:3000[/dim]\n"
                "[cyan]Enter remote forwards[/cyan]",
                default="",
            )

    return proxy_jump, local_forward, remote_forward


@cli.command()
@click.option("--name", "-n", help="Connection name")
@click.option("--host", "-h", help="Host/IP address")
@click.option("--user", "-u", help="Username")
@click.option("--port", "-p", type=int, help="SSH port (default: 22)")
@click.option("--hostname", help="SSH HostName (if different from host)")
@click.option("--key", "-k", help="SSH private key path")
@click.option("--proxy-jump", help="ProxyJump configuration")
@click.option("--local-forward", help="LocalForward configuration")
@click.option("--remote-forward", help="RemoteForward configuration")
@click.option("--notes", help="Connection notes")
@click.option(
    "--non-interactive",
    is_flag=True,
    default=False,
    help="Use non-interactive mode (requires all options via flags)",
)
def add(
    name: Optional[str],
    host: Optional[str],
    user: Optional[str],
    port: Optional[int],
    hostname: Optional[str],
    key: Optional[str],
    proxy_jump: Optional[str],
    local_forward: Optional[str],
    remote_forward: Optional[str],
    notes: Optional[str],
    non_interactive: bool,
) -> None:
    """Add a new SSH connection.

    \b
    Basic connections:
      tg add -n server1 -h 192.168.1.10 -u admin
      tg add --name myserver --host example.com --user deploy --port 2222

    \b
    ProxyJump:
      tg add -n internal --host 10.0.1.100 -u admin --proxy-jump bastion.company.com
      tg add -n db-server --host 192.168.10.50 -u dbadmin --proxy-jump "jumpuser@bastion.company.com:2222"

    \b
    Port forwarding (auto-corrected to proper SSH syntax):
      tg add -n db-tunnel --host db.company.com -u dbuser --local-forward "3306:localhost:3306"
      tg add -n dev-server --host dev.company.com -u dev --local-forward "8080:localhost:80,3306:db:3306"
      tg add -n redis-tunnel --host redis.company.com -u admin --local-forward "6379:localhost:6379"

    \b
    Complex example with multiple options:
      tg add -n prod-db --host prod-db.internal -u produser \\
             --proxy-jump bastion.company.com \\
             --local-forward "5432:localhost:5432" \\
             --key ~/.ssh/prod_key \\
             --notes "Production database via bastion"

    \b
    Interactive mode:
      tg add
    """
    config_manager = SSHConfigManager()

    if not config_manager.is_initialized():
        console.print("[red]Please run 'tg init' first[/red]")
        return

    console.print(
        Panel("➕ [bold green]Add SSH Connection[/bold green]", style="green")
    )

    interactive = not non_interactive

    # Get required fields
    name = _get_required_field(
        "name",
        name,
        interactive,
        "[cyan]Connection name[/cyan]",
        "Connection name is required (use --name or -n)",
    )
    if not name:
        return

    # Check for duplicates
    if config_manager.get_connection_by_name(name):
        console.print(f"[red]Connection '{name}' already exists[/red]")
        return

    host = _get_required_field(
        "host",
        host,
        interactive,
        "[cyan]Host/IP address[/cyan]",
        "Host is required (use --host or -h)",
    )
    if not host:
        return

    user = _get_required_field(
        "user",
        user,
        interactive,
        "[cyan]Username[/cyan]",
        "Username is required (use --user or -u)",
    )
    if not user:
        return

    # Port handling
    if port is None:
        if interactive:
            port_input = Prompt.ask("[cyan]Port[/cyan]", default="22")
            try:
                port = int(port_input)
            except ValueError:
                console.print(
                    f"[red]Invalid port '{port_input}': must be a number[/red]"
                )
                return
        else:
            port = 22

    # Optional hostname
    if not hostname and interactive:
        hostname = Prompt.ask(
            "[cyan]SSH HostName (if different from host)[/cyan]", default=""
        )
        hostname = hostname if hostname else None

    # SSH key selection
    key = _handle_ssh_key_selection(config_manager, key, interactive)

    # FIXED: Ensure key is either a valid string path or None
    # Pydantic validation requires None or valid string, not empty string
    if key == "":
        key = None

    # Advanced options
    proxy_jump, local_forward, remote_forward = _get_advanced_options(
        interactive, proxy_jump, local_forward, remote_forward
    )

    # Notes
    if not notes and interactive:
        notes = Prompt.ask("[cyan]Notes (optional)[/cyan]", default="")

    # Clean up empty strings to None
    def clean_option(value: Optional[str]) -> Optional[str]:
        return value if value and value.strip() else None

    # Create connection with validation
    try:
        connection = SSHConnection(
            name=name,
            host=host,
            hostname=clean_option(hostname),
            port=port,
            user=user,
            identity_file=clean_option(key),
            proxy_jump=clean_option(proxy_jump),
            local_forward=clean_option(local_forward),
            remote_forward=clean_option(remote_forward),
            notes=clean_option(notes),
            last_used=None,
        )
    except ValueError as e:
        console.print(f"[red]Configuration error: {e}[/red]")
        console.print(
            "[yellow]Tip: LocalForward format should be 'local_port:remote_host:remote_port'[/yellow]"
        )
        console.print(
            "[yellow]Examples: '3306:localhost:3306' or '8080:localhost:80,3000:localhost:3000'[/yellow]"
        )
        return

    if config_manager.add_connection(connection):
        console.print(f"[green]✓[/green] Added connection '{name}'")
        console.print(f"[dim]Connect with: ssh {name}[/dim]")
    else:
        console.print(f"[red]Failed to add connection '{name}'[/red]")


def _get_field_selection_menu(connection: SSHConnection) -> List[str]:
    """Display interactive menu for selecting fields to update.

    Returns list of field keys selected for update.
    """
    console.print("\n[bold cyan]Select fields to update:[/bold cyan]")
    console.print("[dim]Enter field numbers separated by commas (e.g., 1,3,5)[/dim]")
    console.print("[dim]Or press Enter to cancel[/dim]\n")

    fields = {
        "1": ("name", "Connection name", connection.name),
        "2": ("host", "Host/IP address", connection.host),
        "3": ("user", "Username", connection.user),
        "4": ("port", "SSH port", str(connection.port)),
        "5": ("hostname", "SSH HostName", connection.hostname or "(not set)"),
        "6": (
            "identity_file",
            "SSH key path",
            connection.identity_file or "(default)",
        ),
        "7": ("proxy_jump", "ProxyJump", connection.proxy_jump or "(none)"),
        "8": ("local_forward", "LocalForward", connection.local_forward or "(none)"),
        "9": (
            "remote_forward",
            "RemoteForward",
            connection.remote_forward or "(none)",
        ),
        "10": ("notes", "Notes", connection.notes or "(none)"),
        "11": (
            "tags",
            "Tags",
            ", ".join(connection.tags) if connection.tags else "(none)",
        ),
    }

    # Display menu table
    table = Table(show_header=True)
    table.add_column("#", style="cyan", width=3)
    table.add_column("Field", style="yellow")
    table.add_column("Current Value", style="dim")

    for num, (_field_key, field_name, current_value) in fields.items():
        table.add_row(num, field_name, str(current_value))

    console.print(table)

    # Get selection
    selection = Prompt.ask(
        "[cyan]Select fields to update (comma-separated)[/cyan]", default=""
    )

    if not selection.strip():
        return []

    # Parse selection
    selected_fields = []
    for num in selection.split(","):
        num = num.strip()
        if num in fields:
            selected_fields.append(fields[num][0])  # field_key

    return selected_fields


def _update_field_interactive(
    connection: SSHConnection, field_name: str, config_manager: SSHConfigManager
) -> Any:
    """Interactively update a single field.

    Shows current value as default and prompts for new value.
    """
    current_value = getattr(connection, field_name)

    # Special handling for specific fields
    if field_name == "port":
        new_value = Prompt.ask("[cyan]New port[/cyan]", default=str(current_value))
        try:
            return int(new_value)
        except ValueError:
            console.print(f"[red]Invalid port '{new_value}': must be a number[/red]")
            return current_value

    elif field_name == "identity_file":
        # Reuse SSH key selection logic from add command
        return _handle_ssh_key_selection(config_manager, None, interactive=True)

    elif field_name == "tags":
        current_tags = ", ".join(current_value) if current_value else ""
        new_tags = Prompt.ask(
            "[cyan]New tags (comma-separated)[/cyan]", default=current_tags
        )
        return [t.strip() for t in new_tags.split(",") if t.strip()]

    elif field_name == "proxy_jump":
        return Prompt.ask("[cyan]New ProxyJump[/cyan]", default=current_value or "")

    elif field_name == "local_forward":
        return Prompt.ask(
            "[cyan]New LocalForward[/cyan]\n"
            "[dim]Format: 3306:localhost:3306 or 8080:localhost:80,3000:localhost:3000[/dim]\n"
            "[cyan]Enter port forwards[/cyan]",
            default=current_value or "",
        )

    elif field_name == "remote_forward":
        return Prompt.ask(
            "[cyan]New RemoteForward[/cyan]\n"
            "[dim]Format: 8080:localhost:80[/dim]\n"
            "[cyan]Enter remote forwards[/cyan]",
            default=current_value or "",
        )

    else:
        # Generic text field
        return Prompt.ask(
            f"[cyan]New {field_name}[/cyan]",
            default=str(current_value) if current_value else "",
        )


def _display_update_comparison(
    old_connection: SSHConnection,
    new_connection: SSHConnection,
    updated_fields: List[str],
) -> None:
    """Display before/after comparison for updated fields."""
    console.print("\n[bold yellow]Proposed Changes:[/bold yellow]\n")

    table = Table(show_header=True)
    table.add_column("Field", style="cyan")
    table.add_column("Old Value", style="red")
    table.add_column("New Value", style="green")

    for field in updated_fields:
        old_value = getattr(old_connection, field)
        new_value = getattr(new_connection, field)

        # Format values for display
        old_display = str(old_value) if old_value else "(not set)"
        new_display = str(new_value) if new_value else "(not set)"

        # Special formatting for lists (tags)
        if type(old_value).__name__ == "list":
            old_display = ", ".join(old_value) if old_value else "(none)"
        if type(new_value).__name__ == "list":
            new_display = ", ".join(new_value) if new_value else "(none)"

        table.add_row(field, old_display, new_display)

    console.print(table)


@cli.command()
@click.argument("connection_ref")
@click.option("--name", "-n", help="New connection name")
@click.option("--host", "-h", help="New host/IP address")
@click.option("--user", "-u", help="New username")
@click.option("--port", "-p", type=int, help="New SSH port")
@click.option("--hostname", help="New SSH HostName")
@click.option("--key", "-k", help="New SSH private key path")
@click.option("--proxy-jump", help="New ProxyJump configuration")
@click.option("--local-forward", help="New LocalForward configuration")
@click.option("--remote-forward", help="New RemoteForward configuration")
@click.option("--notes", help="New connection notes")
@click.option("--tags", help="New tags (comma-separated)")
@click.option(
    "--non-interactive",
    is_flag=True,
    default=False,
    help="Use non-interactive mode (update only specified fields)",
)
def update(
    connection_ref: str,
    name: Optional[str],
    host: Optional[str],
    user: Optional[str],
    port: Optional[int],
    hostname: Optional[str],
    key: Optional[str],
    proxy_jump: Optional[str],
    local_forward: Optional[str],
    remote_forward: Optional[str],
    notes: Optional[str],
    tags: Optional[str],
    non_interactive: bool,
) -> None:
    """Update an existing SSH connection.

    \b
    Non-interactive examples:
      tg update myserver --host 192.168.1.100 --non-interactive
      tg update myserver --host 10.0.1.50 --port 2222 --user admin --non-interactive
      tg update 1 --host newhost.com --non-interactive

    \b
    Update connection name:
      tg update old-name --name new-name --non-interactive

    \b
    Update port forwarding:
      tg update db-server --local-forward "3306:localhost:3306" --non-interactive
      tg update app-server --local-forward "8080:localhost:80,3000:localhost:3000" --non-interactive

    \b
    Update tags:
      tg update prod-web --tags "production,web,critical" --non-interactive

    \b
    Interactive mode (field selection menu):
      tg update myserver
      tg update 1

    \b
    Notes:
      - Connection can be referenced by name or number (from 'tg list')
      - In non-interactive mode, only specified fields are updated
      - In interactive mode, you select which fields to update from a menu
      - Name updates are allowed but must not conflict with existing connections
      - All updates trigger SSH config file regeneration
    """
    config_manager = SSHConfigManager()

    if not config_manager.is_initialized():
        console.print("[red]Please run 'tg init' first[/red]")
        return

    console.print(
        Panel("✏️  [bold blue]Update SSH Connection[/bold blue]", style="blue")
    )

    # Find the connection
    connection = _find_connection_by_ref(config_manager, connection_ref)
    if not connection:
        return

    if non_interactive:
        # Non-interactive mode: update only specified fields
        updates: Dict[str, Any] = {}

        if name is not None:
            updates["name"] = name
        if host is not None:
            updates["host"] = host
        if user is not None:
            updates["user"] = user
        if port is not None:
            updates["port"] = port
        if hostname is not None:
            updates["hostname"] = hostname
        if key is not None:
            updates["identity_file"] = key
        if proxy_jump is not None:
            updates["proxy_jump"] = proxy_jump
        if local_forward is not None:
            updates["local_forward"] = local_forward
        if remote_forward is not None:
            updates["remote_forward"] = remote_forward
        if notes is not None:
            updates["notes"] = notes
        if tags is not None:
            updates["tags"] = [t.strip() for t in tags.split(",") if t.strip()]

        if not updates:
            console.print("[yellow]No fields specified for update[/yellow]")
            console.print("[dim]Use --help to see available options[/dim]")
            return

        # Check for name conflicts
        if "name" in updates:
            new_name = updates["name"]
            existing = config_manager.get_connection_by_name(new_name)
            if existing and existing.id != connection.id:
                console.print(f"[red]Connection name '{new_name}' already exists[/red]")
                return

        # Clean up empty strings to None for optional fields
        def clean_option(value: Optional[str]) -> Optional[str]:
            return value if value and value.strip() else None

        for field in [
            "hostname",
            "identity_file",
            "proxy_jump",
            "local_forward",
            "remote_forward",
            "notes",
        ]:
            if field in updates and isinstance(updates[field], str):
                updates[field] = clean_option(updates[field])

        # Apply updates to connection
        connection_data = connection.model_dump()
        connection_data.update(updates)

        # Create updated connection with validation
        try:
            updated_connection = SSHConnection.model_validate(connection_data)
        except ValueError as e:
            console.print(f"[red]Validation error: {e}[/red]")
            if "LocalForward" in str(e) or "RemoteForward" in str(e):
                console.print(
                    "[yellow]Tip: LocalForward format should be 'local_port:remote_host:remote_port'[/yellow]"
                )
                console.print(
                    "[yellow]Examples: '3306:localhost:3306' or '8080:localhost:80,3000:localhost:3000'[/yellow]"
                )
            return

        # Save
        if config_manager.update_connection(updated_connection):
            console.print(
                f"[green]✓[/green] Updated connection '{updated_connection.name}'"
            )
            # Show what was updated
            for field, value in updates.items():
                console.print(f"  [dim]{field}: {value}[/dim]")
        else:
            console.print("[red]Failed to update connection[/red]")

    else:
        # Interactive mode: field selection menu
        console.print(f"\n[bold]Current connection: {connection.name}[/bold]")

        # Get field selection
        selected_fields = _get_field_selection_menu(connection)

        if not selected_fields:
            console.print("[yellow]No fields selected. Update cancelled.[/yellow]")
            return

        # Collect updates
        updates_dict: Dict[str, Any] = {}
        for field in selected_fields:
            try:
                new_value = _update_field_interactive(connection, field, config_manager)
                updates_dict[field] = new_value
            except KeyboardInterrupt:
                console.print("\n[yellow]Update cancelled by user[/yellow]")
                return
            except EOFError:
                console.print("\n[yellow]Update cancelled[/yellow]")
                return

        # Check for name conflicts
        if "name" in updates_dict:
            new_name = updates_dict["name"]
            existing = config_manager.get_connection_by_name(new_name)
            if existing and existing.id != connection.id:
                console.print(f"[red]Connection name '{new_name}' already exists[/red]")
                return

        # Clean up empty strings to None for optional fields
        def clean_option(value: Optional[str]) -> Optional[str]:
            return value if value and value.strip() else None

        for field in [
            "hostname",
            "identity_file",
            "proxy_jump",
            "local_forward",
            "remote_forward",
            "notes",
        ]:
            if field in updates_dict and isinstance(updates_dict[field], str):
                updates_dict[field] = clean_option(updates_dict[field])

        # Create updated connection with validation
        connection_data = connection.model_dump()
        connection_data.update(updates_dict)

        try:
            updated_connection = SSHConnection.model_validate(connection_data)
        except ValueError as e:
            console.print(f"[red]Validation error: {e}[/red]")
            if "LocalForward" in str(e) or "RemoteForward" in str(e):
                console.print(
                    "[yellow]Tip: LocalForward format should be 'local_port:remote_host:remote_port'[/yellow]"
                )
                console.print(
                    "[yellow]Examples: '3306:localhost:3306' or '8080:localhost:80,3000:localhost:3000'[/yellow]"
                )
            return

        # Display comparison
        _display_update_comparison(
            connection, updated_connection, list(updates_dict.keys())
        )

        # Confirm
        if not Confirm.ask("\n[cyan]Apply these changes?[/cyan]", default=False):
            console.print("[yellow]Update cancelled[/yellow]")
            return

        # Save
        if config_manager.update_connection(updated_connection):
            console.print(
                f"\n[green]✓[/green] Updated connection '{updated_connection.name}'"
            )
        else:
            console.print("[red]Failed to update connection[/red]")


@cli.command()
@click.option(
    "--detailed",
    "-d",
    is_flag=True,
    help="Show detailed information including notes, proxy settings, and port forwarding",
)
@click.option(
    "--format",
    "-f",
    type=click.Choice(["table", "compact", "json"]),
    default="table",
    help="Output format: table (default), compact, or json",
)
@click.option("--tag", "-t", help="Filter by tag")
@click.option("--search", "-s", help="Search across name, host, user, and notes")
@click.option(
    "--sort",
    type=click.Choice(["name", "last-used", "created", "use-count"]),
    default=None,
    help="Sort connections",
)
@click.option("--unused", is_flag=True, help="Show only unused connections")
def list(
    detailed: bool,
    format: str,
    tag: Optional[str],
    search: Optional[str],
    sort: Optional[str],
    unused: bool,
) -> None:
    """List all SSH connections.

    \b
    Basic usage:
      tg list                    # Basic list
      tg list --detailed         # Show all details
      tg list -d                 # Short form for detailed

    \b
    Format options:
      tg list -f compact         # Compact format
      tg list -d -f compact      # Detailed compact format
      tg list -f json            # JSON output
      tg list -d -f json         # Detailed JSON output

    \b
    Filter and sort:
      tg list --tag production   # Filter by tag
      tg list -s webserver       # Search name, host, user, notes
      tg list --sort last-used   # Sort by last used
      tg list --unused           # Show only unused connections
      tg list -t prod -s web     # Combine filters
    """
    config_manager = SSHConfigManager()
    connections = config_manager.list_connections()

    # Apply filters
    if tag:
        connections = [c for c in connections if tag in c.tags]
    if search:
        search_lower = search.lower()
        connections = [
            c
            for c in connections
            if search_lower in c.name.lower()
            or search_lower in c.host.lower()
            or search_lower in c.user.lower()
            or (c.notes and search_lower in c.notes.lower())
            or (c.hostname and search_lower in c.hostname.lower())
        ]
    if unused:
        connections = [c for c in connections if c.use_count == 0]

    # Apply sorting
    if sort:
        sort_keys = {
            "name": lambda c: c.name.lower(),
            "last-used": lambda c: (c.last_used or datetime.min),
            "created": lambda c: c.created_at,
            "use-count": lambda c: c.use_count,
        }
        reverse = sort in ("last-used", "use-count", "created")
        connections = sorted(connections, key=sort_keys[sort], reverse=reverse)

    if not connections:
        console.print(
            "[yellow]No connections configured. Use 'tg add' to create one.[/yellow]"
        )
        return

    if format == "json":
        _display_connections_json(connections, detailed)
    elif format == "compact":
        _display_connections_compact(connections, detailed)
    else:
        _display_connections_table(connections, detailed)

    # Don't show total count for JSON format
    if format != "json":
        console.print(f"\n[dim]Total: {len(connections)} connections[/dim]")


def _display_connections_table(
    connections: List[SSHConnection], detailed: bool = False
) -> None:
    """Display connections in table format."""
    if detailed:
        # Detailed table with all information
        table = Table(title="SSH Connections (Detailed)", show_lines=True)
        table.add_column("#", style="dim", width=3)
        table.add_column("Name", style="cyan", no_wrap=True)
        table.add_column("Connection", style="blue")
        table.add_column("Advanced", style="magenta")
        table.add_column("Notes", style="yellow")
        table.add_column("Last Used", style="dim")

        for i, conn in enumerate(connections, 1):
            # Build connection string
            connection_str = f"{conn.user}@{conn.host}"
            if conn.port != 22:
                connection_str += f":{conn.port}"
            if conn.hostname and conn.hostname != conn.host:
                connection_str += f"\n[dim]SSH: {conn.hostname}[/dim]"
            if conn.identity_file:
                key_name = Path(conn.identity_file).name
                connection_str += f"\n[dim]Key: {key_name}[/dim]"

            # Build advanced options string
            advanced_options = []
            if conn.proxy_jump:
                advanced_options.append(f"[green]ProxyJump:[/green] {conn.proxy_jump}")
            if conn.local_forward:
                advanced_options.append(
                    f"[blue]LocalForward:[/blue] {conn.local_forward}"
                )
            if conn.remote_forward:
                advanced_options.append(
                    f"[red]RemoteForward:[/red] {conn.remote_forward}"
                )

            advanced_str = (
                "\n".join(advanced_options) if advanced_options else "[dim]None[/dim]"
            )

            # Format notes
            notes_str = conn.notes if conn.notes else "[dim]None[/dim]"
            if conn.notes and len(conn.notes) > 30:
                notes_str = conn.notes[:27] + "..."

            # Format last used
            last_used = (
                conn.last_used.strftime("%Y-%m-%d") if conn.last_used else "Never"
            )

            table.add_row(
                str(i),
                conn.name,
                connection_str,
                advanced_str,
                notes_str,
                last_used,
            )
    else:
        # Standard table (existing format)
        table = Table(title="SSH Connections")
        table.add_column("#", style="dim", width=3)
        table.add_column("Name", style="cyan", no_wrap=True)
        table.add_column("Host", style="blue")
        table.add_column("User", style="green")
        table.add_column("Port", style="yellow", width=5)
        table.add_column("Key", style="magenta")
        table.add_column("Last Used", style="dim")

        for i, conn in enumerate(connections, 1):
            key_display = (
                Path(conn.identity_file).name if conn.identity_file else "default"
            )
            last_used = (
                conn.last_used.strftime("%Y-%m-%d") if conn.last_used else "Never"
            )

            table.add_row(
                str(i),
                conn.name,
                conn.host,
                conn.user,
                str(conn.port),
                key_display,
                last_used,
            )

    console.print(table)


def _display_connections_compact(
    connections: List[SSHConnection], detailed: bool = False
) -> None:
    """Display connections in compact format."""
    console.print("[bold]SSH Connections:[/bold]\n")

    for i, conn in enumerate(connections, 1):
        # Basic connection info
        console.print(
            f"[cyan]{i:2}. {conn.name}[/cyan] - {conn.user}@{conn.host}:{conn.port}"
        )

        if detailed:
            details = []

            # SSH hostname if different
            if conn.hostname and conn.hostname != conn.host:
                details.append(f"SSH: {conn.hostname}")

            # SSH key
            if conn.identity_file:
                key_name = Path(conn.identity_file).name
                details.append(f"Key: {key_name}")

            # Advanced options
            if conn.proxy_jump:
                details.append(f"ProxyJump: {conn.proxy_jump}")
            if conn.local_forward:
                details.append(f"LocalForward: {conn.local_forward}")
            if conn.remote_forward:
                details.append(f"RemoteForward: {conn.remote_forward}")

            # Notes
            if conn.notes:
                details.append(f"Notes: {conn.notes}")

            # Last used
            last_used = (
                conn.last_used.strftime("%Y-%m-%d") if conn.last_used else "Never"
            )
            details.append(f"Last used: {last_used}")

            if details:
                for detail in details:
                    console.print(f"     [dim]{detail}[/dim]")

        console.print()  # Empty line between connections


def _display_connections_json(
    connections: List[SSHConnection], detailed: bool = False
) -> None:
    """Display connections in JSON format."""

    def _serialize_connection(conn: SSHConnection) -> Dict[str, Any]:
        """Convert SSHConnection object to JSON-serializable dictionary."""
        # Base connection data that's always included
        data = {
            "id": conn.id,
            "name": conn.name,
            "host": conn.host,
            "user": conn.user,
            "port": conn.port,
        }

        # Add optional fields if they exist
        if conn.hostname and conn.hostname != conn.host:
            data["hostname"] = conn.hostname

        if conn.identity_file:
            data["identity_file"] = conn.identity_file

        # Always include tags if present
        if conn.tags:
            data["tags"] = conn.tags

        # Include detailed information if requested
        if detailed:
            # Advanced SSH options
            if conn.proxy_jump:
                data["proxy_jump"] = conn.proxy_jump
            if conn.local_forward:
                data["local_forward"] = conn.local_forward
            if conn.remote_forward:
                data["remote_forward"] = conn.remote_forward
            if conn.extra_options:
                data["extra_options"] = conn.extra_options

            # Metadata
            if conn.notes:
                data["notes"] = conn.notes

            # Timestamps (convert to ISO format for JSON compatibility)
            data["created_at"] = (
                conn.created_at.isoformat() if conn.created_at else None
            )
            data["last_used"] = conn.last_used.isoformat() if conn.last_used else None
            data["use_count"] = conn.use_count

        return data

    # FIXED: Return just the list of connections for compatibility with tests
    # The test expects a simple list, not a metadata object
    json_data = [_serialize_connection(conn) for conn in connections]

    # Output formatted JSON to console
    print(json.dumps(json_data, indent=2, ensure_ascii=False))


def _find_connection_by_ref(
    config_manager: SSHConfigManager, connection_ref: str
) -> Optional[SSHConnection]:
    """Find connection by reference (number or name)."""
    if connection_ref.isdigit():
        connections = config_manager.list_connections()
        index = int(connection_ref) - 1
        if 0 <= index < len(connections):
            return connections[index]
        else:
            console.print(f"[red]Invalid connection number: {connection_ref}[/red]")
            return None
    else:
        connection = config_manager.get_connection_by_name(connection_ref)
        if not connection:
            console.print(f"[red]Connection '{connection_ref}' not found[/red]")
            return None
        return connection


@cli.command()
@click.argument("connection_ref")
@click.option(
    "--format",
    "-f",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format: table (default) or json",
)
def show(connection_ref: str, format: str) -> None:
    """Show detailed information about a connection.

    \b
    Examples:
      tg show myserver           # Table format
      tg show myserver --format json    # JSON format
      tg show 1 -f json          # JSON by connection number
    """
    config_manager = SSHConfigManager()

    connection = _find_connection_by_ref(config_manager, connection_ref)
    if not connection:
        return

    # Handle JSON output
    if format == "json":
        connection_data = {
            "id": connection.id,
            "name": connection.name,
            "host": connection.host,
            "user": connection.user,
            "port": connection.port,
        }

        # Optional fields
        if connection.hostname and connection.hostname != connection.host:
            connection_data["hostname"] = connection.hostname
        if connection.identity_file:
            connection_data["identity_file"] = connection.identity_file
        if connection.proxy_jump:
            connection_data["proxy_jump"] = connection.proxy_jump
        if connection.local_forward:
            connection_data["local_forward"] = connection.local_forward
        if connection.remote_forward:
            connection_data["remote_forward"] = connection.remote_forward
        if connection.extra_options:
            connection_data["extra_options"] = connection.extra_options
        if connection.notes:
            connection_data["notes"] = connection.notes
        if connection.tags:
            connection_data["tags"] = connection.tags

        # Metadata
        connection_data["created_at"] = (
            connection.created_at.isoformat() if connection.created_at else None
        )
        connection_data["last_used"] = (
            connection.last_used.isoformat() if connection.last_used else None
        )
        connection_data["use_count"] = connection.use_count

        print(json.dumps(connection_data, indent=2, ensure_ascii=False))
        return

    # Display detailed info in table format
    console.print(Panel(f"🔗 [bold]{connection.name}[/bold]", style="blue"))

    info_table = Table(show_header=False)
    info_table.add_column("Field", style="cyan", width=15)
    info_table.add_column("Value", style="white")

    info_table.add_row("Host", connection.host)
    if connection.hostname and connection.hostname != connection.host:
        info_table.add_row("SSH HostName", connection.hostname)
    info_table.add_row("User", connection.user)
    info_table.add_row("Port", str(connection.port))

    if connection.identity_file:
        info_table.add_row("SSH Key", connection.identity_file)

    if connection.proxy_jump:
        info_table.add_row("ProxyJump", connection.proxy_jump)

    if connection.local_forward:
        info_table.add_row("LocalForward", connection.local_forward)

    if connection.remote_forward:
        info_table.add_row("RemoteForward", connection.remote_forward)

    if connection.notes:
        info_table.add_row("Notes", connection.notes)

    info_table.add_row("Created", connection.created_at.strftime("%Y-%m-%d %H:%M"))

    if connection.last_used:
        info_table.add_row("Last Used", connection.last_used.strftime("%Y-%m-%d %H:%M"))

    info_table.add_row("Use Count", str(connection.use_count))

    console.print(info_table)

    # Show SSH config block
    console.print("\n[bold]SSH Config Block:[/bold]")
    console.print(Panel(connection.to_ssh_config_block(), style="dim"))


@cli.command()
@click.argument("connection_ref")
@click.option(
    "--force",
    "-f",
    is_flag=True,
    help="Skip confirmation prompt",
)
def remove(connection_ref: str, force: bool) -> None:
    """Remove an SSH connection."""
    config_manager = SSHConfigManager()

    connection = _find_connection_by_ref(config_manager, connection_ref)
    if not connection:
        return

    # Confirm deletion
    if not force and not Confirm.ask(
        f"[red]Remove connection '{connection.name}'?[/red]"
    ):
        console.print("[yellow]Cancelled[/yellow]")
        return

    if config_manager.remove_connection(connection.id):
        console.print(f"[green]✓[/green] Removed connection '{connection.name}'")
    else:
        console.print(f"[red]Failed to remove connection '{connection.name}'[/red]")


@cli.command()
def config() -> None:
    """Configure Tengingarstjóri settings."""
    config_manager = SSHConfigManager()

    console.print(Panel("⚙️  [bold blue]Configuration[/bold blue]", style="blue"))

    # Show current settings
    console.print("[bold]Current Settings:[/bold]")
    settings_table = Table(show_header=False)
    settings_table.add_column("Setting", style="cyan")
    settings_table.add_column("Value", style="white")

    default_key = config_manager.get_setting("default_identity_file", "None")
    settings_table.add_row("Default SSH Key", default_key)

    console.print(settings_table)

    # FIXED: Handle EOF gracefully for test environments
    try:
        # Option to change default key
        if Confirm.ask("\n[cyan]Update default SSH key?[/cyan]"):
            available_keys = config_manager.discover_ssh_keys()

            if available_keys:
                console.print("\n[yellow]Available SSH keys:[/yellow]")
                for i, key in enumerate(available_keys, 1):
                    console.print(f"  {i}. {key}")

                choice = Prompt.ask(
                    "[cyan]Select key (number) or enter custom path[/cyan]"
                )

                if choice.isdigit() and 1 <= int(choice) <= len(available_keys):
                    new_key = available_keys[int(choice) - 1]
                else:
                    new_key = choice

                config_manager.update_setting("default_identity_file", new_key)
                console.print(f"[green]✓[/green] Updated default SSH key to: {new_key}")
            else:
                new_key = Prompt.ask("[cyan]Enter SSH key path[/cyan]")
                config_manager.update_setting("default_identity_file", new_key)
                console.print(f"[green]✓[/green] Updated default SSH key to: {new_key}")
    except EOFError:
        # FIXED: Handle EOF gracefully - common in test environments
        console.print(
            "[yellow]Configuration display completed (non-interactive mode)[/yellow]"
        )


@cli.command()
def fix_config() -> None:
    """Fix corrupted SSH configuration."""
    config_manager = SSHConfigManager()

    console.print("[yellow]Fixing SSH configuration...[/yellow]")

    try:
        # Read current SSH config
        ssh_config_path = Path.home() / ".ssh" / "config"

        if ssh_config_path.exists():
            with open(ssh_config_path, "r") as f:
                content = f.read()

            # Show current problematic content
            console.print("[dim]Current SSH config content:[/dim]")
            console.print(f"[dim]{content[:200]}...[/dim]")

            # Fix the content by removing literal \\n sequences
            managed_config_path = config_manager.managed_config

            # Remove all variations of corrupted include lines
            corrupted_patterns = [
                f"Include {managed_config_path}\\n\\n",
                f"Include {managed_config_path}\\n",
            ]

            original_content = content
            for pattern in corrupted_patterns:
                content = content.replace(pattern, "")

            # Clean up any duplicate empty lines
            lines = content.split("\n")
            cleaned_lines = []
            prev_empty = False

            for line in lines:
                if line.strip() == "":
                    if not prev_empty:
                        cleaned_lines.append(line)
                    prev_empty = True
                else:
                    cleaned_lines.append(line)
                    prev_empty = False

            cleaned_content = "\n".join(cleaned_lines).strip()

            if cleaned_content != original_content:
                # Backup
                backup_path = ssh_config_path.with_suffix(".backup-fix")
                with open(backup_path, "w") as f:
                    f.write(original_content)
                console.print(f"[green]✓[/green] Backup saved to: {backup_path}")

                # Write cleaned content
                with open(ssh_config_path, "w") as f:
                    f.write(cleaned_content)

                console.print("[green]✓[/green] Removed corrupted include lines")
            else:
                console.print("[yellow]No corrupted lines found[/yellow]")

        # Now add the correct include line
        config_manager._ensure_include_line()
        console.print("[green]✓[/green] SSH configuration fixed")

        # Show final config
        console.print("\n[bold]Fixed SSH config:[/bold]")
        with open(ssh_config_path, "r") as f:
            console.print(f.read()[:300] + "...")

    except Exception as e:
        console.print(f"[red]Error fixing SSH config: {e}[/red]")


@cli.command()
def refresh() -> None:
    """Regenerate SSH configuration file."""
    config_manager = SSHConfigManager()

    console.print("[blue]Regenerating SSH configuration...[/blue]")

    try:
        config_manager._update_ssh_config()
        console.print("[green]✓[/green] SSH configuration refreshed")
        console.print(f"[dim]Config file: {config_manager.managed_config}[/dim]")
    except Exception as e:
        console.print(f"[red]Error refreshing config: {e}[/red]")


@cli.command()
def validate() -> None:
    """Validate SSH configuration syntax for all connections."""
    config_manager = SSHConfigManager()
    connections = config_manager.list_connections()

    if not connections:
        console.print("[yellow]No connections to validate.[/yellow]")
        return

    console.print(
        Panel("🔍 [bold blue]SSH Configuration Validation[/bold blue]", style="blue")
    )

    issues_found = False

    for connection in connections:
        conn_issues = []

        # Check name has no spaces (breaks SSH config Host matching)
        if " " in connection.name:
            conn_issues.append("name contains spaces")

        # Check host is not blank
        if not connection.host.strip():
            conn_issues.append("host is empty")

        # Check identity file exists on disk if specified
        if connection.identity_file:
            key_path = Path(connection.identity_file).expanduser()
            if not key_path.exists():
                conn_issues.append(
                    f"identity file not found: {connection.identity_file}"
                )

        # Verify SSH config block can be generated cleanly
        try:
            block = connection.to_ssh_config_block()
            if not block.strip():
                conn_issues.append("generated SSH config block is empty")
        except Exception as e:
            conn_issues.append(f"config block generation failed: {e}")

        if conn_issues:
            for issue in conn_issues:
                console.print(f"[red]✗[/red] {connection.name}: {issue}")
            issues_found = True
        else:
            console.print(f"[green]✓[/green] {connection.name}: OK")

    if not issues_found:
        console.print("\n[green]All configurations are valid![/green]")
    else:
        console.print(
            "\n[yellow]Found configuration issues. Use 'tg fix-forwards' to automatically correct them.[/yellow]"
        )


@cli.command()
def fix_forwards() -> None:
    """Fix LocalForward and RemoteForward syntax in existing connections."""
    config_manager = SSHConfigManager()
    connections = config_manager.list_connections()

    if not connections:
        console.print("[yellow]No connections to fix.[/yellow]")
        return

    console.print(
        Panel("🔧 [bold blue]Fix Port Forwarding Syntax[/bold blue]", style="blue")
    )

    fixed_count = 0

    for connection in connections:
        original_local = connection.local_forward
        original_remote = connection.remote_forward
        needs_fix = False

        # Check if LocalForward needs fixing (has old colon syntax)
        if original_local and ":" in original_local and " " not in original_local:
            needs_fix = True

        # Check if RemoteForward needs fixing
        if original_remote and ":" in original_remote and " " not in original_remote:
            needs_fix = True

        if needs_fix:
            try:
                # Create new connection data which will auto-fix the syntax
                fixed_data = connection.model_dump()
                fixed_connection = SSHConnection.model_validate(fixed_data)

                # Update the connection in the database
                if config_manager.update_connection(fixed_connection):
                    console.print(f"[green]✓[/green] Fixed {connection.name}")
                    if original_local != fixed_connection.local_forward:
                        console.print(
                            f"  [dim]LocalForward: {original_local} → {fixed_connection.local_forward}[/dim]"
                        )
                    if original_remote != fixed_connection.remote_forward:
                        console.print(
                            f"  [dim]RemoteForward: {original_remote} → {fixed_connection.remote_forward}[/dim]"
                        )
                    fixed_count += 1
                else:
                    console.print(f"[red]✗[/red] Failed to update {connection.name}")

            except Exception as e:
                console.print(f"[red]✗[/red] Could not fix {connection.name}: {e}")

    if fixed_count > 0:
        console.print(
            f"\n[green]Fixed {fixed_count} connections. Regenerating SSH config...[/green]"
        )
        config_manager._update_ssh_config()
        console.print("[green]✓[/green] SSH configuration updated")
    else:
        console.print("\n[yellow]No connections needed fixing.[/yellow]")


@cli.command()
def reset() -> None:
    """Reset SSH configuration to the original state before Tengingarstjóri was installed."""
    config_manager = SSHConfigManager()

    console.print("[yellow]Preparing to reset SSH configuration...[/yellow]")

    # Check if the backup exists
    backup_path = config_manager.main_ssh_config.with_suffix(".backup")
    if not backup_path.exists():
        console.print(
            "[red]Cannot reset: Original backup not found.[/red]\n"
            "[yellow]This might mean that:\n"
            "1. You haven't run 'tg init' yet\n"
            "2. The backup file was deleted\n"
            "3. You're using a custom SSH config location[/yellow]"
        )
        return

    # Confirm with the user
    if not Confirm.ask(
        "[red]This will remove all Tengingarstjóri configuration and restore your original SSH config.[/red]\n"
        "[red]All your connections will remain in the database but won't be available in SSH config.[/red]\n"
        "Continue?",
        default=False,
    ):
        console.print("[yellow]Reset cancelled.[/yellow]")
        return

    try:
        # Make a backup of the current state just in case
        current_config_backup = config_manager.main_ssh_config.with_suffix(
            ".tengingarstjori-backup"
        )
        if config_manager.main_ssh_config.exists():
            shutil.copy2(config_manager.main_ssh_config, current_config_backup)
            console.print(
                f"[dim]Current config backed up to: {current_config_backup}[/dim]"
            )

        # Restore the original backup
        shutil.copy2(backup_path, config_manager.main_ssh_config)

        # Remove the managed config file
        if config_manager.managed_config.exists():
            config_manager.managed_config.unlink()
            console.print(
                f"[green]✓[/green] Removed managed config: {config_manager.managed_config}"
            )

        console.print(
            "[green]✓[/green] SSH configuration has been reset to its original state"
        )
        console.print(
            "[yellow]Note: Your connection database is still intact.[/yellow]"
        )
        console.print(
            "[yellow]To completely remove Tengingarstjóri, you can delete:[/yellow]"
        )
        console.print(
            f"[dim]- Configuration directory: {config_manager.config_dir}[/dim]"
        )

    except Exception as e:
        console.print(f"[red]Error resetting SSH configuration: {e}[/red]")
        console.print("[yellow]If you need to manually reset:[/yellow]")
        console.print(
            f"[dim]1. Copy {backup_path} to {config_manager.main_ssh_config}[/dim]"
        )
        console.print(f"[dim]2. Delete {config_manager.managed_config}[/dim]")


@cli.command()
@click.argument("connection_ref")
@click.option("--dry-run", is_flag=True, help="Print the SSH command without executing")
def connect(connection_ref: str, dry_run: bool) -> None:
    """Connect to an SSH server.

    \b
    Examples:
      tg connect myserver          # Connect by name
      tg connect 1                 # Connect by number
      tg connect myserver --dry-run  # Show SSH command without connecting
    """
    config_manager = SSHConfigManager()

    if not config_manager.is_initialized():
        console.print("[red]Please run 'tg init' first[/red]")
        return

    connection = _find_connection_by_ref(config_manager, connection_ref)
    if not connection:
        return

    # Update usage statistics
    connection.update_usage()
    config_manager.update_connection(connection)

    if dry_run:
        console.print(f"[dim]ssh {connection.name}[/dim]")
        return

    console.print(f"[green]Connecting to {connection.name}...[/green]")
    os.execvp("ssh", ["ssh", connection.name])


@cli.command(name="export")
@click.option("--output", "-o", help="Output file path (default: stdout)")
@click.option(
    "--format",
    "-f",
    "export_format",
    type=click.Choice(["json", "ssh-config"]),
    default="json",
    help="Export format",
)
@click.option("--strip-keys", is_flag=True, help="Omit SSH key paths from export")
def export_cmd(output: Optional[str], export_format: str, strip_keys: bool) -> None:
    """Export connections for backup or sharing.

    \b
    Examples:
      tg export                          # JSON to stdout
      tg export -o backup.json           # JSON to file
      tg export -f ssh-config            # SSH config format to stdout
      tg export --strip-keys -o safe.json  # Export without key paths
    """
    config_manager = SSHConfigManager()
    connections = config_manager.list_connections()

    if not connections:
        console.print("[yellow]No connections to export.[/yellow]")
        return

    if export_format == "ssh-config":
        result = ""
        for conn in connections:
            if strip_keys:
                conn = conn.model_copy(update={"identity_file": None})
            result += conn.to_ssh_config_block() + "\n"
    else:
        data = []
        for conn in connections:
            conn_data = conn.model_dump(mode="json")
            if strip_keys:
                conn_data.pop("identity_file", None)
            data.append(conn_data)
        result = json.dumps(data, indent=2, ensure_ascii=False)

    if output:
        path = Path(output)
        path.write_text(result)
        console.print(
            f"[green]✓[/green] Exported {len(connections)} connections to {output}"
        )
    else:
        print(result)


@cli.command(name="import")
@click.argument("filepath")
@click.option(
    "--strategy",
    type=click.Choice(["skip", "overwrite", "rename"]),
    default="skip",
    help="Conflict resolution: skip (default), overwrite, or rename",
)
def import_cmd(filepath: str, strategy: str) -> None:
    """Import connections from a JSON file.

    \b
    Examples:
      tg import backup.json                    # Skip existing
      tg import backup.json --strategy overwrite  # Overwrite conflicts
      tg import backup.json --strategy rename     # Rename conflicts
    """
    config_manager = SSHConfigManager()

    if not config_manager.is_initialized():
        console.print("[red]Please run 'tg init' first[/red]")
        return

    path = Path(filepath)
    if not path.exists():
        console.print(f"[red]File not found: {filepath}[/red]")
        return

    try:
        data = json.loads(path.read_text())
    except json.JSONDecodeError as e:
        console.print(f"[red]Invalid JSON: {e}[/red]")
        return

    if isinstance(data, dict) or not hasattr(data, "__iter__"):
        console.print("[red]Expected a JSON array of connections[/red]")
        return

    imported = 0
    skipped = 0
    errors = 0

    for item in data:
        try:
            # Remove id so a new one is generated
            item.pop("id", None)
            conn = SSHConnection(**item)
        except Exception as e:
            console.print(f"[red]✗[/red] Invalid connection data: {e}")
            errors += 1
            continue

        existing = config_manager.get_connection_by_name(conn.name)
        if existing:
            if strategy == "skip":
                console.print(
                    f"[yellow]Skipped '{conn.name}' (already exists)[/yellow]"
                )
                skipped += 1
                continue
            elif strategy == "overwrite":
                config_manager.remove_connection(existing.id)
            elif strategy == "rename":
                original_name = conn.name
                counter = 2
                while config_manager.get_connection_by_name(conn.name):
                    conn = conn.model_copy(
                        update={"name": f"{original_name}-{counter}"}
                    )
                    counter += 1
                console.print(f"[dim]Renamed '{original_name}' to '{conn.name}'[/dim]")

        if config_manager.add_connection(conn):
            imported += 1
        else:
            console.print(f"[red]✗[/red] Failed to add '{conn.name}'")
            errors += 1

    console.print(
        f"\n[green]✓[/green] Imported: {imported}, Skipped: {skipped}, Errors: {errors}"
    )


@cli.command()
@click.argument("source_ref")
@click.argument("new_name")
def clone(source_ref: str, new_name: str) -> None:
    """Clone an existing connection with a new name.

    \b
    Examples:
      tg clone prod-web staging-web
      tg clone 1 prod-web-2
    """
    config_manager = SSHConfigManager()

    if not config_manager.is_initialized():
        console.print("[red]Please run 'tg init' first[/red]")
        return

    source = _find_connection_by_ref(config_manager, source_ref)
    if not source:
        return

    if config_manager.get_connection_by_name(new_name):
        console.print(f"[red]Connection '{new_name}' already exists[/red]")
        return

    clone_data = source.model_dump()
    clone_data.pop("id", None)
    clone_data["name"] = new_name
    clone_data["created_at"] = datetime.now()
    clone_data["last_used"] = None
    clone_data["use_count"] = 0

    try:
        new_conn = SSHConnection(**clone_data)
    except ValueError as e:
        console.print(f"[red]Validation error: {e}[/red]")
        return

    if config_manager.add_connection(new_conn):
        console.print(f"[green]✓[/green] Cloned '{source.name}' as '{new_name}'")
    else:
        console.print("[red]Failed to clone connection[/red]")


@cli.command()
@click.argument("connection_ref", required=False)
@click.option("--all", "test_all", is_flag=True, help="Test all connections")
@click.option(
    "--timeout",
    "-t",
    default=5,
    type=int,
    help="Connection timeout in seconds (default: 5)",
)
def test(connection_ref: Optional[str], test_all: bool, timeout: int) -> None:
    """Test SSH connection health.

    \b
    Examples:
      tg test myserver           # Test single connection
      tg test --all              # Test all connections
      tg test myserver -t 10     # Custom timeout
    """
    config_manager = SSHConfigManager()

    if not config_manager.is_initialized():
        console.print("[red]Please run 'tg init' first[/red]")
        return

    if test_all:
        connections = config_manager.list_connections()
        if not connections:
            console.print("[yellow]No connections to test.[/yellow]")
            return
    elif connection_ref:
        conn = _find_connection_by_ref(config_manager, connection_ref)
        if not conn:
            return
        connections = [conn]
    else:
        console.print("[red]Provide a connection name or use --all[/red]")
        return

    console.print(
        Panel("🔍 [bold blue]Connection Health Check[/bold blue]", style="blue")
    )

    for conn in connections:
        try:
            result = subprocess.run(
                [
                    "ssh",
                    "-o",
                    f"ConnectTimeout={timeout}",
                    "-o",
                    "BatchMode=yes",
                    conn.name,
                    "exit",
                ],
                capture_output=True,
                timeout=timeout + 5,
            )
            if result.returncode == 0:
                console.print(f"[green]✓[/green] {conn.name}: OK")
            else:
                stderr = result.stderr.decode().strip()
                console.print(
                    f"[red]✗[/red] {conn.name}: Failed ({stderr or 'unknown error'})"
                )
        except subprocess.TimeoutExpired:
            console.print(f"[yellow]⏱[/yellow] {conn.name}: Timeout ({timeout}s)")
        except FileNotFoundError:
            console.print("[red]SSH client not found[/red]")
            return
        except Exception as e:
            console.print(f"[red]✗[/red] {conn.name}: Error ({e})")


@cli.command()
@click.option(
    "--all",
    "show_all",
    is_flag=True,
    help="Show full history",
)
@click.option(
    "--limit",
    "-n",
    default=10,
    type=int,
    help="Number of recent connections to show (default: 10)",
)
def history(show_all: bool, limit: int) -> None:
    """Show recent connection history.

    \b
    Examples:
      tg history              # Last 10 connections
      tg history --all        # Full history
      tg history -n 5         # Last 5 connections
    """
    config_manager = SSHConfigManager()
    connections = config_manager.list_connections()

    used = [c for c in connections if c.last_used is not None]
    used.sort(key=lambda c: c.last_used, reverse=True)  # type: ignore[arg-type]

    if not used:
        console.print("[yellow]No connection history yet.[/yellow]")
        return

    if not show_all:
        used = used[:limit]

    table = Table(title="Connection History")
    table.add_column("#", style="dim", width=3)
    table.add_column("Name", style="cyan")
    table.add_column("Last Used", style="green")
    table.add_column("Use Count", style="yellow", justify="right")
    table.add_column("Connection", style="blue")

    for i, conn in enumerate(used, 1):
        last_used = (
            conn.last_used.strftime("%Y-%m-%d %H:%M") if conn.last_used else "Never"
        )
        table.add_row(
            str(i),
            conn.name,
            last_used,
            str(conn.use_count),
            f"{conn.user}@{conn.host}",
        )

    console.print(table)


@cli.command()
@click.argument("connection_ref")
@click.option(
    "--config",
    "show_config",
    is_flag=True,
    help="Show SSH config block instead of command",
)
def snippet(connection_ref: str, show_config: bool) -> None:
    """Show the SSH command or config block for a connection.

    \b
    Examples:
      tg snippet myserver            # SSH command
      tg snippet myserver --config   # SSH config block
      tg snippet myserver | pbcopy   # Copy to clipboard (macOS)
    """
    config_manager = SSHConfigManager()

    connection = _find_connection_by_ref(config_manager, connection_ref)
    if not connection:
        return

    if show_config:
        print(connection.to_ssh_config_block())
    else:
        parts = ["ssh"]
        if connection.identity_file:
            parts.extend(["-i", connection.identity_file])
        if connection.port != 22:
            parts.extend(["-p", str(connection.port)])
        if connection.proxy_jump:
            parts.extend(["-J", connection.proxy_jump])
        if connection.local_forward:
            for fwd in connection.local_forward.split(","):
                fwd = fwd.strip()
                if fwd:
                    parts.extend(["-L", fwd])
        if connection.remote_forward:
            for fwd in connection.remote_forward.split(","):
                fwd = fwd.strip()
                if fwd:
                    parts.extend(["-R", fwd])

        host = connection.hostname or connection.host
        parts.append(f"{connection.user}@{host}")

        print(" ".join(parts))


if __name__ == "__main__":
    cli()
