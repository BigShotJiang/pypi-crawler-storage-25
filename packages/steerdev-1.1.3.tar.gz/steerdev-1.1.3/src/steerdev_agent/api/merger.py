"""Merger API client for merger agent operations."""

from typing import Any

from pydantic import BaseModel

from steerdev_agent.api.client import SteerDevClient


class MergerRunResponse(BaseModel):
    id: str
    status: str
    wave_ids: list[str] = []
    task_ids: list[str] = []
    pr_ids: list[str] = []
    evidence_report_ids: list[str] = []
    summary: str | None = None
    merged_branches: list[str] | None = None
    error_message: str | None = None
    started_at: str | None = None
    completed_at: str | None = None


class GateResponse(BaseModel):
    id: str
    merger_run_id: str
    canal_id: str
    gate_number: int
    status: str
    started_at: str | None = None
    completed_at: str | None = None
    details: dict[str, Any] | None = None
    error_message: str | None = None


class MergerClient(SteerDevClient):
    """Client for merger agent API operations."""

    def execute_merger_run(self, merger_run_id: str) -> dict[str, Any] | None:
        """Trigger execution of a full merger run."""
        response = self.post(f"/merger-runs/{merger_run_id}/execute")
        if response and response.status_code == 200:
            return response.json()
        return None

    def get_merger_run(self, merger_run_id: str) -> MergerRunResponse | None:
        """Get merger run status."""
        response = self.get(f"/merger-runs/{merger_run_id}")
        if response and response.status_code == 200:
            return MergerRunResponse(**response.json())
        return None

    def get_merger_gates(self, merger_run_id: str) -> list[GateResponse]:
        """Get gate statuses for a merger run."""
        response = self.get(f"/merger-runs/{merger_run_id}/gates")
        if response and response.status_code == 200:
            data = response.json()
            return [GateResponse(**g) for g in data.get("gates", [])]
        return []

    def execute_gate(
        self, canal_id: str, gate_number: int, merger_run_id: str, merge_id: str | None = None
    ) -> dict[str, Any] | None:
        """Trigger execution of a specific gate."""
        payload: dict[str, Any] = {"merger_run_id": merger_run_id}
        if merge_id:
            payload["merge_id"] = merge_id
        response = self.post(f"/canals/{canal_id}/gates/{gate_number}", json=payload)
        if response and response.status_code == 200:
            return response.json()
        return None
