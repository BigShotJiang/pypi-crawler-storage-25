"""Evidence reports API client for SteerDev Agent.

Submits evidence reports to the platform after task/workflow completion,
making work visible on the project review dashboard.
"""

from __future__ import annotations

from typing import Any

from loguru import logger
from rich.console import Console

from steerdev_agent.api.client import SteerDevClient

console = Console()


class ReportsClient(SteerDevClient):
    """Client for submitting evidence reports to the platform.

    Evidence reports capture task completion summaries, making agent work
    visible on the project review page (/projects/[id]/review).
    """

    def submit(
        self,
        *,
        project_id: str,
        summary: str,
        blocks: list[dict[str, Any]],
        artifacts: list[dict[str, Any]] | None = None,
        task_id: str | None = None,
        wave_id: str | None = None,
        agent_id: str | None = None,
        evaluation_steps: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any] | None:
        """Submit an evidence report for a completed task or workflow.

        Args:
                project_id: SteerDev project ID.
                summary: Report title/summary (required for reviewability).
                blocks: List of report blocks (type, content, order).
                artifacts: Optional list of file artifacts (filename, mime_type, size, content_base64/url).
                task_id: Associated task ID.
                wave_id: Associated wave ID.
                agent_id: Associated agent ID.
                evaluation_steps: Optional evaluation steps (title, result, order).

        Returns:
                Response dict with report_id and is_reviewable, or None on failure.
        """
        payload: dict[str, Any] = {
            "project_id": project_id,
            "summary": summary,
            "blocks": blocks,
        }
        if artifacts:
            payload["artifacts"] = artifacts
        if task_id:
            payload["task_id"] = task_id
        if wave_id:
            payload["wave_id"] = wave_id
        if agent_id:
            payload["agent_id"] = agent_id
        if evaluation_steps:
            payload["evaluation_steps"] = evaluation_steps

        try:
            response = self.post("/reports", json=payload)
            if response.status_code in (200, 201):
                data = response.json()
                report_id = data.get("report_id", "unknown")
                is_reviewable = data.get("is_reviewable", False)
                console.print(
                    f"[dim]Evidence report submitted: {report_id} "
                    f"(reviewable: {is_reviewable})[/dim]"
                )
                return data
            logger.warning(
                f"Evidence report submission failed: {response.status_code} - {response.text}"
            )
            return None
        except Exception:
            logger.debug("Evidence report submission error", exc_info=True)
            return None
