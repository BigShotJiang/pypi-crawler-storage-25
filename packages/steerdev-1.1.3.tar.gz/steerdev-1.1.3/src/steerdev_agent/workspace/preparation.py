"""Deterministic workspace preparation for task execution.

Handles git operations (fetch, checkout, branch creation) before handing
off to the coding agent. Replaces the non-deterministic LLM-driven
pre-flight sync with reliable Python code.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from loguru import logger

if TYPE_CHECKING:
    from pathlib import Path

    from steerdev_agent.config.models import BranchConfig, WorktreeConfig
    from steerdev_agent.prompt.builder import WaveContext


class PreparationError(Exception):
    """Error during workspace preparation."""


@dataclass
class PreparationResult:
    """Result of workspace preparation."""

    success: bool
    branch_name: str
    working_directory: Path
    default_branch: str
    is_worktree: bool
    error: str | None = None
    warnings: list[str] = field(default_factory=list)
    repo_directories: list[Path] = field(default_factory=list)
    """For multi-repo workspaces, the list of prepared git repositories."""


async def _run_git(
    *args: str,
    cwd: Path,
    check: bool = True,
) -> tuple[int, str, str]:
    """Run a git command and return (returncode, stdout, stderr).

    Args:
        args: Git subcommand and arguments.
        cwd: Working directory for the command.
        check: If True, raise on non-zero exit code.

    Returns:
        Tuple of (return code, stdout, stderr).

    Raises:
        PreparationError: If check is True and the command fails.
    """
    cmd = ["git", *args]
    logger.debug(f"git: {' '.join(cmd)} (cwd={cwd})")

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        cwd=str(cwd),
    )
    stdout_bytes, stderr_bytes = await proc.communicate()
    stdout = stdout_bytes.decode("utf-8", errors="replace").strip()
    stderr = stderr_bytes.decode("utf-8", errors="replace").strip()

    if check and proc.returncode != 0:
        raise PreparationError(
            f"git {' '.join(args)} failed (exit {proc.returncode}): {stderr or stdout}"
        )

    return proc.returncode or 0, stdout, stderr


class WorkspacePreparation:
    """Prepares the git workspace before task execution.

    Handles:
    - Worktree mode: delegates to WorktrunkClient
    - Non-worktree mode: fetch, checkout default branch, create task branch
    """

    def __init__(
        self,
        working_directory: Path,
        worktree_config: WorktreeConfig,
        branch_config: BranchConfig,
    ) -> None:
        self.working_directory = working_directory
        self._worktree_config = worktree_config
        self._branch_config = branch_config

    async def prepare(
        self,
        task: dict[str, Any],
        wave_context: WaveContext | None = None,
    ) -> PreparationResult:
        """Prepare the workspace for task execution.

        Args:
            task: Task data from the API.
            wave_context: Wave metadata, if this task is part of a wave.

        Returns:
            PreparationResult with workspace state.
        """
        from steerdev_agent.worktree import compute_branch_name

        default_branch = self._branch_config.default_branch
        target_branch = compute_branch_name(task, wave_context)

        # Worktree mode: delegate to WorktrunkClient
        if self._worktree_config.enabled and self._worktree_config.provider == "worktrunk":
            return await self._prepare_worktree(target_branch, default_branch)

        # Non-worktree mode: prepare in-place
        return await self._prepare_in_place(target_branch, default_branch, wave_context)

    async def _prepare_worktree(
        self,
        target_branch: str,
        default_branch: str,
    ) -> PreparationResult:
        """Prepare workspace using worktrunk worktrees."""
        from steerdev_agent.worktree import WorktrunkClient

        wt_client = WorktrunkClient(self.working_directory)
        worktree_path = await wt_client.switch(target_branch, create=True)

        return PreparationResult(
            success=True,
            branch_name=target_branch,
            working_directory=worktree_path,
            default_branch=default_branch,
            is_worktree=True,
        )

    async def _prepare_in_place(
        self,
        target_branch: str,
        default_branch: str,
        wave_context: WaveContext | None,
    ) -> PreparationResult:
        """Prepare workspace in the main repository directory.

        If the working directory is not itself a git repository, discovers
        git repos in immediate subdirectories (multi-repo layout) and
        prepares each one.
        """
        cwd = self.working_directory

        # 1. Check if working directory is a git repo
        rc, _, _ = await _run_git("rev-parse", "--is-inside-work-tree", cwd=cwd, check=False)
        if rc == 0:
            # Single-repo layout: prepare in place
            return await self._prepare_single_repo(cwd, target_branch, default_branch, wave_context)

        # Not a git repo — check for multi-repo layout (subdirectories that are git repos)
        repos = await self._discover_git_repos(cwd)
        if not repos:
            return PreparationResult(
                success=False,
                branch_name=target_branch,
                working_directory=cwd,
                default_branch=default_branch,
                is_worktree=False,
                error=f"Not a git repository: {cwd}",
            )

        # Multi-repo layout: prepare each discovered repo
        return await self._prepare_multi_repo(repos, target_branch, default_branch, wave_context)

    async def _discover_git_repos(self, directory: Path) -> list[Path]:
        """Discover git repositories in immediate subdirectories.

        Args:
            directory: Parent directory to scan.

        Returns:
            Sorted list of paths that are git repositories.
        """
        repos: list[Path] = []
        try:
            for entry in sorted(directory.iterdir()):
                if entry.is_dir() and not entry.name.startswith("."):
                    rc, _, _ = await _run_git(
                        "rev-parse", "--is-inside-work-tree", cwd=entry, check=False
                    )
                    if rc == 0:
                        repos.append(entry)
        except OSError as exc:
            logger.warning(f"Failed to scan directory {directory}: {exc}")
        return repos

    async def _prepare_multi_repo(
        self,
        repos: list[Path],
        target_branch: str,
        default_branch: str,
        wave_context: WaveContext | None,
    ) -> PreparationResult:
        """Prepare multiple git repositories in a workspace directory.

        Applies the same branch preparation to each discovered repo.
        Returns success only if all repos are prepared successfully.

        Args:
            repos: List of git repository paths to prepare.
            target_branch: Target branch name for the task.
            default_branch: Default branch to sync from.
            wave_context: Optional wave context.

        Returns:
            PreparationResult with the parent directory as working_directory.
        """
        parent_dir = self.working_directory
        all_warnings: list[str] = []
        prepared_repos: list[Path] = []

        logger.info(
            f"Multi-repo workspace detected at {parent_dir}: preparing {len(repos)} repositories"
        )

        for repo_path in repos:
            repo_name = repo_path.name
            logger.info(f"Preparing repository: {repo_name}")

            result = await self._prepare_single_repo(
                repo_path, target_branch, default_branch, wave_context
            )

            if not result.success:
                return PreparationResult(
                    success=False,
                    branch_name=target_branch,
                    working_directory=parent_dir,
                    default_branch=default_branch,
                    is_worktree=False,
                    error=f"Failed to prepare repo {repo_name}: {result.error}",
                    repo_directories=prepared_repos,
                )

            prepared_repos.append(repo_path)
            # Prefix per-repo warnings with the repo name for clarity
            for warning in result.warnings:
                all_warnings.append(f"[{repo_name}] {warning}")

        logger.info(f"Multi-repo workspace ready: {len(prepared_repos)} repositories prepared")

        return PreparationResult(
            success=True,
            branch_name=target_branch,
            working_directory=parent_dir,
            default_branch=default_branch,
            is_worktree=False,
            warnings=all_warnings,
            repo_directories=prepared_repos,
        )

    async def _prepare_single_repo(
        self,
        cwd: Path,
        target_branch: str,
        default_branch: str,
        wave_context: WaveContext | None,
    ) -> PreparationResult:
        """Prepare a single git repository directory.

        Args:
            cwd: Path to the git repository.
            target_branch: Target branch name for the task.
            default_branch: Default branch to sync from.
            wave_context: Optional wave context.

        Returns:
            PreparationResult for this repository.
        """
        warnings: list[str] = []

        # 1. Check current branch
        _, current_branch, _ = await _run_git("branch", "--show-current", cwd=cwd, check=False)

        # 2. If continuing a wave on the same branch, just fetch
        if wave_context and current_branch == target_branch:
            logger.info(f"Continuing wave on branch {target_branch}, fetching only")
            await _run_git("fetch", "origin", cwd=cwd, check=False)
            return PreparationResult(
                success=True,
                branch_name=target_branch,
                working_directory=cwd,
                default_branch=default_branch,
                is_worktree=False,
            )

        # 3. Stash if dirty
        rc, status_output, _ = await _run_git("status", "--porcelain", cwd=cwd, check=False)
        if status_output:
            logger.info("Working directory dirty, stashing changes")
            await _run_git("stash", "push", "-m", "steerdev-preflight", cwd=cwd, check=False)
            warnings.append("Stashed uncommitted changes (steerdev-preflight)")

        # 4. Fetch from origin
        await _run_git("fetch", "origin", cwd=cwd, check=False)

        # 5. Sync to default branch
        rc, _, _ = await _run_git("checkout", default_branch, cwd=cwd, check=False)
        if rc != 0:
            return PreparationResult(
                success=False,
                branch_name=target_branch,
                working_directory=cwd,
                default_branch=default_branch,
                is_worktree=False,
                error=f"Failed to checkout {default_branch}. Does the branch exist?",
            )

        # Try fast-forward merge
        rc, _, _ = await _run_git(
            "merge", "--ff-only", f"origin/{default_branch}", cwd=cwd, check=False
        )
        if rc != 0:
            # Fallback: hard reset to origin
            logger.warning(f"Fast-forward merge failed for {default_branch}, resetting to origin")
            await _run_git("reset", "--hard", f"origin/{default_branch}", cwd=cwd, check=False)
            warnings.append(
                f"Fast-forward failed, reset {default_branch} to origin/{default_branch}"
            )

        # 6. Create or checkout target branch
        rc, _, _ = await _run_git("rev-parse", "--verify", target_branch, cwd=cwd, check=False)
        branch_exists = rc == 0

        if branch_exists:
            await _run_git("checkout", target_branch, cwd=cwd)
            logger.info(f"Switched to existing branch: {target_branch}")
        else:
            await _run_git("checkout", "-b", target_branch, cwd=cwd)
            logger.info(f"Created new branch: {target_branch}")

        # 7. Validate current branch
        _, actual_branch, _ = await _run_git("branch", "--show-current", cwd=cwd, check=False)
        if actual_branch != target_branch:
            return PreparationResult(
                success=False,
                branch_name=target_branch,
                working_directory=cwd,
                default_branch=default_branch,
                is_worktree=False,
                error=f"Branch mismatch: expected {target_branch}, got {actual_branch}",
            )

        return PreparationResult(
            success=True,
            branch_name=target_branch,
            working_directory=cwd,
            default_branch=default_branch,
            is_worktree=False,
            warnings=warnings,
        )
