"""Evidence asset scanning and upload.

Scans a directory for evidence files (screenshots, logs) produced during
evidence collection, then uploads them to the platform via multipart upload
and returns metadata with CDN URLs.
"""

from __future__ import annotations

import mimetypes
from dataclasses import dataclass
from pathlib import Path

import httpx
from loguru import logger

from steerdev_agent.api.client import get_api_endpoint

# File extensions we recognise as evidence assets.
ASSET_EXTENSIONS: set[str] = {
    ".png",
    ".jpg",
    ".jpeg",
    ".webp",
    ".gif",  # images
    ".pdf",  # documents
    ".webm",
    ".mp4",  # video
    ".log",
    ".txt",  # logs / text
}

# Hard limits to avoid uploading too much data.
MAX_ASSETS = 10
DEFAULT_MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB


@dataclass(frozen=True)
class EvidenceAsset:
    """A file found in the evidence assets directory, optionally uploaded."""

    filepath: Path
    filename: str
    mime_type: str
    size: int
    # Populated after upload — proxy URL that serves the file through app auth
    url: str | None = None


def scan_evidence_assets(
    assets_dir: str | Path,
    *,
    max_file_size: int = DEFAULT_MAX_FILE_SIZE,
    max_assets: int = MAX_ASSETS,
) -> list[EvidenceAsset]:
    """Scan *assets_dir* and return evidence assets found on disk.

    Best-effort: logs warnings for unreadable files, never raises.
    """
    dir_path = Path(assets_dir)
    if not dir_path.is_dir():
        return []

    assets: list[EvidenceAsset] = []

    try:
        # Sort by name for deterministic ordering.
        for entry in sorted(dir_path.iterdir(), key=lambda p: p.name):
            if len(assets) >= max_assets:
                logger.debug(f"Evidence assets capped at {max_assets}")
                break

            if not entry.is_file():
                continue

            suffix = entry.suffix.lower()
            if suffix not in ASSET_EXTENSIONS:
                continue

            try:
                size = entry.stat().st_size
                if size == 0:
                    continue
                if size > max_file_size:
                    logger.warning(
                        f"Evidence asset too large, skipping: {entry.name} ({size} bytes)"
                    )
                    continue

                mime_type = mimetypes.guess_type(entry.name)[0] or "application/octet-stream"

                assets.append(
                    EvidenceAsset(
                        filepath=entry,
                        filename=entry.name,
                        mime_type=mime_type,
                        size=size,
                    )
                )
            except Exception:
                logger.warning(f"Failed to read evidence asset: {entry.name}", exc_info=True)

    except Exception:
        logger.warning("Failed to scan evidence assets directory", exc_info=True)

    return assets


def upload_evidence_assets(
    assets: list[EvidenceAsset],
    *,
    api_key: str | None,
    folder: str = "evidence",
    timeout: float = 60.0,
) -> list[EvidenceAsset]:
    """Upload evidence assets to the platform via multipart upload.

    Returns a new list of ``EvidenceAsset`` with ``url`` and ``download_url``
    populated for successfully uploaded files.  Assets that fail to upload are
    returned unchanged (url=None).

    Best-effort: individual upload failures are logged, never raised.
    """
    if not assets or not api_key:
        return assets

    api_base = get_api_endpoint()
    upload_url = f"{api_base}/upload"
    headers = {"Authorization": f"Bearer {api_key}"}

    uploaded: list[EvidenceAsset] = []

    with httpx.Client(timeout=timeout, follow_redirects=True) as client:
        for asset in assets:
            try:
                with asset.filepath.open("rb") as f:
                    files = {
                        "file": (asset.filename, f, asset.mime_type),
                    }
                    data = {
                        "filename": asset.filename,
                        "folder": folder,
                    }
                    response = client.post(
                        upload_url,
                        headers=headers,
                        files=files,
                        data=data,
                    )

                if response.status_code in (200, 201):
                    result = response.json()
                    uploaded.append(
                        EvidenceAsset(
                            filepath=asset.filepath,
                            filename=asset.filename,
                            mime_type=asset.mime_type,
                            size=asset.size,
                            url=result.get("url"),
                        )
                    )
                    logger.debug(f"Uploaded evidence asset: {asset.filename}")
                else:
                    logger.warning(
                        f"Evidence asset upload failed ({response.status_code}): "
                        f"{asset.filename} - {response.text[:200]}"
                    )
                    uploaded.append(asset)

            except Exception:
                logger.warning(
                    f"Failed to upload evidence asset: {asset.filename}",
                    exc_info=True,
                )
                uploaded.append(asset)

    return uploaded
