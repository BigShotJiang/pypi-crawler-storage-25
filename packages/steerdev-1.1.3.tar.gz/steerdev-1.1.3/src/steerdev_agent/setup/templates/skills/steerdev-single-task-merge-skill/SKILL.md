# Single Task Merge Skill

Use this skill when a workflow phase tells you to complete **one task on one branch with one pull request**.

## When to Use

- The workflow prompt explicitly references `single-task-merge`
- `--no-waves` is active, or no wave context is present
- Canals are not explicitly enabled for this project (canal mode requires `--canals` flag and explicit setup)

## Expected Outcome

- One task branch
- One pull request
- One task result update that includes the PR URL

## Workspace Ready

The CLI has already prepared your workspace: fetched the latest changes, synced to the default branch, and created or checked out your task branch. **Do not run pre-flight sync steps** — proceed directly to implementation.

Refer to the **Git Branch Configuration** section in your prompt for the project's default branch name.

## Workflow

1. Ensure the task is already marked `started`
2. Create or switch to the task branch (if not already on it):

```bash
steerdev git branch TASK_ID [--name NAME]
```

This fetches the task from the API and builds the branch name automatically:
- If the task has an external ticket ID (e.g. Linear `PROJ-123`): `task/PROJ-123-<slug-from-title>`
- If no external ID exists: `task/<short-uuid>-<slug-from-title>`
- Use `--name` to override the auto-generated slug

3. Implement the requested changes
4. Commit with a conventional commit message that explains why the change exists
5. Rebase onto the latest default branch before pushing:

```bash
git fetch origin <default-branch>
```

Dry-run merge check (requires git 2.38+):
```bash
git merge-tree --write-tree origin/<default-branch> HEAD
```

- **If exit code 0** (clean merge): Rebase and push:
  ```bash
  git rebase origin/<default-branch>
  git push -u origin HEAD
  ```

- **If exit code non-zero** (conflicts detected): Attempt rebase:
  ```bash
  git rebase origin/<default-branch>
  ```
  - If rebase succeeds after resolving conflicts in files you modified: `git push --force-with-lease origin HEAD`
  - If conflicts are in files you did NOT modify: abort the rebase (`git rebase --abort`) and re-queue the task for a fresh attempt:
    ```bash
    steerdev tasks requeue TASK_ID --files "path/to/file1.ts,path/to/file2.ts" --branch "$(git branch --show-current)"
    ```
    If re-queue fails (max retries exceeded), report as a blocker using `steerdev activity report`.

**Fallback** (if `git merge-tree` is unavailable): Skip the dry-run and rebase directly. If rebase fails, abort and re-queue as above.

6. Create the pull request:

```bash
steerdev git pr --title "TITLE" --task-id TASK_ID [--body "BODY"]
```

7. Update the task result with the PR URL
8. Log completion in the root `docs/` progress files

## Conventions

- Always use `steerdev git branch` to create branches (it resolves the external ticket ID automatically)
- Create exactly one PR for the task
- Include the PR URL in the task result summary
- Replace `<default-branch>` in commands above with the actual branch name from the Git Branch Configuration section

## Example

```bash
steerdev tasks update abc12345... --status started
steerdev git branch abc12345...
# → Creates: task/PROJ-123-add-user-authentication (if Linear ID exists)
# → Creates: task/abc12345-add-user-authentication (fallback)
# ... implement changes ...
git add .
git commit -m "feat: add user authentication"
git push -u origin HEAD
steerdev git pr --title "PROJ-123: Add user authentication" --task-id abc12345...
steerdev tasks update abc12345... --result "PR: https://github.com/org/repo/pull/42"
```
