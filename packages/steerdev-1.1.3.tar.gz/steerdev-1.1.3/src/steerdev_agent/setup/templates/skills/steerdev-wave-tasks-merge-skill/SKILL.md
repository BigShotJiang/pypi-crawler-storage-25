# Wave Tasks Merge Skill

Use this skill when a workflow phase tells you to complete **multiple related tasks on one wave branch with one pull request**.

## When to Use

- The workflow prompt explicitly references `wave-tasks-merge`
- `--waves` is active and wave context is present
- Canals are not explicitly enabled for this project (canal mode requires `--canals` flag and explicit setup)

## Expected Outcome

- One shared wave branch
- One shared pull request for the wave
- All related tasks updated with the same PR URL

## Workspace Ready

The CLI has already prepared your workspace: fetched the latest changes, synced to the default branch (for new waves), or stayed on the current wave branch (for continuing waves). **Do not run pre-flight sync steps** — proceed directly to implementation.

Refer to the **Git Branch Configuration** section in your prompt for the project's default branch name.

## Workflow

1. Create or switch to the shared wave branch (if not already on it):

```bash
git checkout -b wave/<wave-number>
```

2. For each task in the wave:
- Mark the task `started`
- Implement the requested change
- Commit with a task-prefixed conventional commit. **Use the external ticket ID when available** (e.g. Linear ID), falling back to the internal short ID:

```bash
# With external ticket ID (preferred):
git commit -m "[PROJ-123] feat: add user endpoint"

# Fallback (no external ID):
git commit -m "[task:abc12345] feat: add user endpoint"
```

3. After the wave work is ready for review, rebase onto the latest default branch:

```bash
git fetch origin <default-branch>
```

Dry-run merge check (requires git 2.38+):
```bash
git merge-tree --write-tree origin/<default-branch> HEAD
```

- **If exit code 0** (clean merge): Rebase and push:
  ```bash
  git rebase origin/<default-branch>
  git push -u origin HEAD
  ```

- **If exit code non-zero** (conflicts detected): Attempt rebase:
  ```bash
  git rebase origin/<default-branch>
  ```
  - If rebase succeeds after resolving conflicts in files you modified: `git push --force-with-lease origin HEAD`
  - If conflicts are in files you did NOT modify: abort the rebase (`git rebase --abort`) and re-queue the current task:
    ```bash
    steerdev tasks requeue TASK_ID --files "path/to/file1.ts,path/to/file2.ts" --branch "$(git branch --show-current)"
    ```
    If re-queue fails (max retries exceeded), report as a blocker using `steerdev activity report`.

**Fallback** (if `git merge-tree` is unavailable): Skip the dry-run and rebase directly. If rebase fails, abort and re-queue as above.

4. Create one pull request for the wave:

```bash
steerdev git pr --title "Wave <N>: <description>" --body "..."
```

5. Update all related tasks with the shared PR URL
6. Log progress and completion in the root `docs/` progress files

## Commit Prefix Convention

Use external ticket IDs in commits so GitHub integrations can link commits to issues:

| Has External ID? | Commit Prefix | Example |
|---|---|---|
| Yes | `[<TICKET-ID>]` | `[PROJ-123] feat: add user endpoint` |
| No  | `[task:<short-uuid>]` | `[task:abc12345] feat: add user endpoint` |

Run `steerdev tasks get TASK_ID` to find the task's `linear_identifier` before committing.

## Conventions

- Use one branch per wave: `wave/<wave-number>`
- Do not create per-task PRs inside the wave
- Keep commits traceable by including the external ticket ID (or internal ID fallback) in each commit
- Include the shared PR URL in every related task result
- Replace `<default-branch>` in commands above with the actual branch name from the Git Branch Configuration section

## Example

```bash
git checkout -b wave/3

steerdev tasks update task-aaa... --status started
# Check: steerdev tasks get task-aaa... → Linear ID: PROJ-123
# ... implement task 1 ...
git add .
git commit -m "[PROJ-123] feat: add user endpoint"

steerdev tasks update task-bbb... --status started
# Check: steerdev tasks get task-bbb... → Linear ID: PROJ-124
# ... implement task 2 ...
git add .
git commit -m "[PROJ-124] fix: validate email format"

git push -u origin HEAD
steerdev git pr --title "Wave 3: User management improvements" --body "..."
steerdev tasks update task-aaa... --result "PR: https://github.com/org/repo/pull/42"
steerdev tasks update task-bbb... --result "PR: https://github.com/org/repo/pull/42"
```
