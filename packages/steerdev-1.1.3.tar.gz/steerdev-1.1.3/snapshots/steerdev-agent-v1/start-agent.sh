#!/usr/bin/env bash
# Startup script for steerdev-agent-v1 Daytona sandbox.
#
# Environment variables consumed:
#   STEERDEV_PROJECT_ID  (required) — project ID passed to the agent
#   STEERDEV_AGENT_NAME  (required) — name used to register the agent
#   STEERDEV_API_KEY     (required) — API key read natively by the steerdev CLI
#   GIT_REPO_URL         (optional) — if set, clone this repo before starting
#   GIT_BRANCH           (optional) — branch to checkout (default: main)
#   GIT_WORKSPACE_DIR    (optional) — clone destination (default: /home/daytona/workspace)

# Disable trace mode so shell expansion never prints secret values to stdout.
set +x
set -euo pipefail

: "${STEERDEV_PROJECT_ID:?STEERDEV_PROJECT_ID is required}"
: "${STEERDEV_AGENT_NAME:?STEERDEV_AGENT_NAME is required}"
: "${STEERDEV_API_KEY:?STEERDEV_API_KEY is required}"

GIT_BRANCH="${GIT_BRANCH:-main}"
GIT_WORKSPACE_DIR="${GIT_WORKSPACE_DIR:-/home/daytona/workspace}"

# ── Optional repository clone ─────────────────────────────────────────────────
if [ -n "${GIT_REPO_URL:-}" ]; then
    # Configure git to authenticate via GITHUB_TOKEN for private repos.
    # URL rewriting keeps the token out of process arguments and clone logs.
    if [ -n "${GITHUB_TOKEN:-}" ]; then
        git config --global url."https://x-access-token:${GITHUB_TOKEN}@github.com/".insteadOf "https://github.com/"
    fi

    mkdir -p "${GIT_WORKSPACE_DIR}"
    git clone --branch "${GIT_BRANCH}" -- "${GIT_REPO_URL}" "${GIT_WORKSPACE_DIR}"
fi

cd "${GIT_WORKSPACE_DIR}"

# Replace this shell process with the agent so signals (SIGTERM/SIGINT) are
# delivered directly to the agent. Credentials are passed only via environment
# variables — never as CLI flags (which would appear in `ps aux`).
exec steerdev agent \
    --project-id "${STEERDEV_PROJECT_ID}" \
    --agent-name "${STEERDEV_AGENT_NAME}"
