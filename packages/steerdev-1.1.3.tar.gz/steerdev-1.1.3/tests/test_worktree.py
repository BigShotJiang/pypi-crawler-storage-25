"""Tests for the WorktrunkClient and branch name computation."""

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from steerdev_agent.worktree import (
    WorktrunkClient,
    WorktrunkError,
    _slugify,
    compute_branch_name,
)


class TestSlugify:
    def test_basic(self):
        assert _slugify("Add User Auth") == "add-user-auth"

    def test_special_chars(self):
        assert _slugify("Fix: OAuth 2.0 & JWT") == "fix-oauth-2-0-jwt"

    def test_truncation(self):
        result = _slugify("A very long title " * 10, max_length=20)
        assert len(result) <= 20

    def test_no_trailing_hyphens(self):
        result = _slugify("hello---world---", max_length=11)
        assert not result.endswith("-")

    def test_empty(self):
        assert _slugify("") == ""


class TestComputeBranchName:
    def test_wave_context(self):
        from steerdev_agent.prompt.builder import WaveContext

        task = {"id": "abc", "title": "test"}
        wave = WaveContext(wave_number=5, total_waves=10, wave_name="wave-d4e5f6")
        assert compute_branch_name(task, wave) == "wave-d4e5f6"

    def test_task_with_linear_id(self):
        task = {"id": "abc12345xyz", "title": "Add auth", "linear_identifier": "PROJ-42"}
        assert compute_branch_name(task) == "task/PROJ-42-add-auth"

    def test_task_with_external_id(self):
        task = {"id": "abc12345xyz", "title": "Fix bug", "external_id": "JIRA-99"}
        assert compute_branch_name(task) == "task/JIRA-99-fix-bug"

    def test_linear_id_takes_precedence_over_external_id(self):
        task = {
            "id": "abc12345xyz",
            "title": "Fix",
            "linear_identifier": "LIN-1",
            "external_id": "EXT-2",
        }
        assert compute_branch_name(task) == "task/LIN-1-fix"

    def test_task_without_external_id(self):
        task = {"id": "abc12345xyz", "title": "Fix login"}
        assert compute_branch_name(task) == "task/abc12345-fix-login"

    def test_task_no_title(self):
        task = {"id": "abc12345xyz"}
        assert compute_branch_name(task) == "task/abc12345"

    def test_empty_task(self):
        task = {}
        result = compute_branch_name(task)
        assert result.startswith("task/")


class TestWorktrunkClient:
    def test_ensure_installed_found(self):
        with patch("shutil.which", return_value="/usr/local/bin/wt"):
            client = WorktrunkClient("/repo")
            assert client.ensure_installed() == "/usr/local/bin/wt"

    def test_ensure_installed_not_found(self):
        with patch("shutil.which", return_value=None):
            client = WorktrunkClient("/repo")
            with pytest.raises(WorktrunkError, match="not found"):
                client.ensure_installed()

    @pytest.mark.asyncio
    async def test_switch_calls_wt(self):
        client = WorktrunkClient("/repo")

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))
        mock_proc.returncode = 0

        # Mock list output for path resolution
        list_output = b'[{"branch": "task/PROJ-1-fix", "path": "/worktrees/task-PROJ-1-fix"}]'
        mock_list_proc = AsyncMock()
        mock_list_proc.communicate = AsyncMock(return_value=(list_output, b""))
        mock_list_proc.returncode = 0

        with (
            patch("shutil.which", return_value="/usr/local/bin/wt"),
            patch("asyncio.create_subprocess_exec", side_effect=[mock_proc, mock_list_proc]),
        ):
            path = await client.switch("task/PROJ-1-fix", create=True)
            assert path == Path("/worktrees/task-PROJ-1-fix")

    @pytest.mark.asyncio
    async def test_remove_calls_wt(self):
        client = WorktrunkClient("/repo")

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))
        mock_proc.returncode = 0

        with (
            patch("shutil.which", return_value="/usr/local/bin/wt"),
            patch("asyncio.create_subprocess_exec", return_value=mock_proc),
        ):
            await client.remove("task/PROJ-1-fix")

    @pytest.mark.asyncio
    async def test_list_worktrees_parses_json(self):
        client = WorktrunkClient("/repo")

        output = b'[{"branch": "main", "path": "/repo", "is_main": true}, {"branch": "task/fix", "path": "/wt/fix", "is_main": false, "marker": "\\ud83e\\udd16"}]'
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(output, b""))
        mock_proc.returncode = 0

        with (
            patch("shutil.which", return_value="/usr/local/bin/wt"),
            patch("asyncio.create_subprocess_exec", return_value=mock_proc),
        ):
            worktrees = await client.list_worktrees()
            assert len(worktrees) == 2
            assert worktrees[0].branch == "main"
            assert worktrees[0].is_main is True
            assert worktrees[1].branch == "task/fix"

    @pytest.mark.asyncio
    async def test_run_raises_on_failure(self):
        client = WorktrunkClient("/repo")

        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b"branch not found"))
        mock_proc.returncode = 1

        with (
            patch("shutil.which", return_value="/usr/local/bin/wt"),
            patch("asyncio.create_subprocess_exec", return_value=mock_proc),
            pytest.raises(WorktrunkError, match="branch not found"),
        ):
            await client._run("switch", "nonexistent")
