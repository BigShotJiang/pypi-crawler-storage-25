"""Tests for multi-agent conflict mitigation features.

Covers:
- TasksClient.report_files() — reporting actual/predicted files to the API
- TasksClient.requeue_task() — re-queuing tasks due to merge conflicts
- _get_modified_files() — git diff helper for file reporting
- Runner agent_id passthrough — conflict-aware scheduling integration
- CommandExecutor agent_id propagation — agent loop to runner wiring
- CLI requeue command — steerdev tasks requeue
"""

import asyncio
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from steerdev_agent.api.tasks import TasksClient
from steerdev_agent.runner import _get_modified_files

# ============================================================================
# Helpers
# ============================================================================


def _make_response(
    status_code: int,
    json_body: dict[str, Any] | None = None,
    text: str = "",
) -> MagicMock:
    """Build a fake httpx.Response-like mock."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.text = text or (str(json_body) if json_body else "")
    if json_body is not None:
        resp.json.return_value = json_body
    return resp


# ============================================================================
# TasksClient.report_files
# ============================================================================


class TestReportFiles:
    """Tests for TasksClient.report_files()."""

    def test_report_actual_files_success(self):
        """Reports actual files and returns True on 200."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "patch", return_value=mock_resp) as mock_patch:
                result = client.report_files(
                    "task-1",
                    actual_files=["src/auth.ts", "src/types.ts"],
                )

                assert result is True
                mock_patch.assert_called_once_with(
                    "/tasks/task-1/files",
                    json={
                        "actual_files": ["src/auth.ts", "src/types.ts"],
                        "source": "agent_reported",
                    },
                )

    def test_report_predicted_files_success(self):
        """Reports predicted files and returns True on 200."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "patch", return_value=mock_resp) as mock_patch:
                result = client.report_files(
                    "task-1",
                    predicted_files=["src/new-feature.ts"],
                )

                assert result is True
                call_json = mock_patch.call_args.kwargs["json"]
                assert call_json["predicted_files"] == ["src/new-feature.ts"]
                assert "actual_files" not in call_json

    def test_report_both_file_types(self):
        """Reports both actual and predicted files."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "patch", return_value=mock_resp) as mock_patch:
                result = client.report_files(
                    "task-1",
                    actual_files=["src/auth.ts"],
                    predicted_files=["src/auth.ts", "src/middleware.ts"],
                )

                assert result is True
                call_json = mock_patch.call_args.kwargs["json"]
                assert call_json["actual_files"] == ["src/auth.ts"]
                assert call_json["predicted_files"] == ["src/auth.ts", "src/middleware.ts"]

    def test_report_files_no_args_returns_false(self):
        """Returns False when neither actual_files nor predicted_files provided."""
        with TasksClient(api_key="test-key") as client:
            result = client.report_files("task-1")
            assert result is False

    def test_report_files_api_error(self):
        """Returns False on non-200 response."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(500, text="Internal Server Error")
            with patch.object(client, "patch", return_value=mock_resp):
                result = client.report_files("task-1", actual_files=["a.ts"])
                assert result is False

    def test_report_files_404(self):
        """Returns False when task not found."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(404, text="Not Found")
            with patch.object(client, "patch", return_value=mock_resp):
                result = client.report_files("task-1", actual_files=["a.ts"])
                assert result is False

    def test_report_empty_file_list(self):
        """Reports empty actual_files list (valid — clears files)."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "patch", return_value=mock_resp) as mock_patch:
                result = client.report_files("task-1", actual_files=[])
                assert result is True
                call_json = mock_patch.call_args.kwargs["json"]
                assert call_json["actual_files"] == []


# ============================================================================
# TasksClient.requeue_task
# ============================================================================


class TestRequeueTask:
    """Tests for TasksClient.requeue_task()."""

    def test_requeue_success(self):
        """Re-queues task and returns True on 200."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1", "status": "unstarted"})
            with patch.object(client, "post", return_value=mock_resp) as mock_post:
                result = client.requeue_task(
                    "task-1",
                    conflict_files=["src/auth.ts"],
                    previous_branch="task/PROJ-123-add-auth",
                )

                assert result is True
                mock_post.assert_called_once_with(
                    "/tasks/task-1/requeue",
                    json={
                        "conflict_files": ["src/auth.ts"],
                        "previous_branch": "task/PROJ-123-add-auth",
                    },
                )

    def test_requeue_with_conflicting_task_id(self):
        """Includes conflicting_task_id in the request."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "post", return_value=mock_resp) as mock_post:
                result = client.requeue_task(
                    "task-1",
                    conflict_files=["src/auth.ts"],
                    conflicting_task_id="task-2",
                )

                assert result is True
                call_json = mock_post.call_args.kwargs["json"]
                assert call_json["conflicting_task_id"] == "task-2"

    def test_requeue_max_retries_exceeded(self):
        """Returns False when server returns 409 (max retries exceeded)."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(409, text="Max conflict retries exceeded")
            with patch.object(client, "post", return_value=mock_resp):
                result = client.requeue_task(
                    "task-1",
                    conflict_files=["src/auth.ts"],
                )

                assert result is False

    def test_requeue_server_error(self):
        """Returns False on 500."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(500, text="Internal Server Error")
            with patch.object(client, "post", return_value=mock_resp):
                result = client.requeue_task(
                    "task-1",
                    conflict_files=["src/auth.ts"],
                )

                assert result is False

    def test_requeue_minimal_args(self):
        """Works with only required args (conflict_files)."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "post", return_value=mock_resp) as mock_post:
                result = client.requeue_task(
                    "task-1",
                    conflict_files=["a.ts", "b.ts"],
                )

                assert result is True
                call_json = mock_post.call_args.kwargs["json"]
                assert call_json["conflict_files"] == ["a.ts", "b.ts"]
                assert "conflicting_task_id" not in call_json
                assert "previous_branch" not in call_json


# ============================================================================
# _get_modified_files
# ============================================================================


class TestGetModifiedFiles:
    """Tests for _get_modified_files() git diff helper."""

    @pytest.mark.asyncio
    async def test_returns_modified_files(self):
        """Parses git diff output into list of file paths."""
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(
            return_value=(b"src/auth.ts\nsrc/types.ts\nREADME.md\n", b"")
        )
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            files = await _get_modified_files("/repo")

        assert files == ["src/auth.ts", "src/types.ts", "README.md"]

    @pytest.mark.asyncio
    async def test_empty_diff(self):
        """Returns empty list when no files modified."""
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            files = await _get_modified_files("/repo")

        assert files == []

    @pytest.mark.asyncio
    async def test_filters_empty_lines(self):
        """Filters out blank lines from git output."""
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"src/auth.ts\n\n\nsrc/types.ts\n", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc):
            files = await _get_modified_files("/repo")

        assert files == ["src/auth.ts", "src/types.ts"]

    @pytest.mark.asyncio
    async def test_subprocess_failure_returns_empty(self):
        """Returns empty list when git command fails."""
        with patch(
            "asyncio.create_subprocess_exec",
            side_effect=OSError("git not found"),
        ):
            files = await _get_modified_files("/repo")

        assert files == []

    @pytest.mark.asyncio
    async def test_passes_correct_working_directory(self):
        """Passes working directory to subprocess."""
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"a.ts\n", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            await _get_modified_files("/my/project")

        mock_exec.assert_called_once_with(
            "git",
            "diff",
            "--name-only",
            "HEAD",
            cwd="/my/project",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

    @pytest.mark.asyncio
    async def test_accepts_path_object(self):
        """Works with Path objects."""
        mock_proc = AsyncMock()
        mock_proc.communicate = AsyncMock(return_value=(b"a.ts\n", b""))
        mock_proc.returncode = 0

        with patch("asyncio.create_subprocess_exec", return_value=mock_proc) as mock_exec:
            files = await _get_modified_files(Path("/my/project"))

        assert files == ["a.ts"]
        # Verify cwd was converted to string
        assert mock_exec.call_args.kwargs["cwd"] == "/my/project"


# ============================================================================
# Runner agent_id passthrough
# ============================================================================


class TestRunnerAgentIdPassthrough:
    """Tests that Runner stores and uses agent_id for conflict-aware scheduling."""

    def test_runner_stores_agent_id(self):
        """Runner stores agent_id from constructor."""
        from steerdev_agent.runner import Runner

        runner = Runner(
            project_id="proj-1",
            working_directory="/tmp/test",
            api_key="test-key",
            agent_id="agent-abc123",
        )

        assert runner._agent_id == "agent-abc123"

    def test_runner_agent_id_defaults_to_none(self):
        """Runner agent_id defaults to None when not provided."""
        from steerdev_agent.runner import Runner

        runner = Runner(
            project_id="proj-1",
            working_directory="/tmp/test",
            api_key="test-key",
        )

        assert runner._agent_id is None


class TestCommandExecutorAgentId:
    """Tests that CommandExecutor propagates agent_id to Runner."""

    @pytest.mark.asyncio
    async def test_agent_id_passed_to_runner(self):
        """CommandExecutor passes _agent_id to Runner when executing task commands."""
        from steerdev_agent.agent_loop import CommandExecutor
        from steerdev_agent.api.commands import CommandResponse
        from steerdev_agent.config.models import (
            AgentLoopConfig,
            BranchConfig,
            EvidenceConfig,
            ExecutorConfig,
            RetryConfig,
            WorktreeConfig,
        )

        class TestExecutor(CommandExecutor):
            def __init__(self) -> None:
                self._api_key = "test-key"
                self.agent_type = "claude"
                self.agent_name = "test-agent"
                self.model = None
                self.max_turns = None
                self._executor_config = ExecutorConfig()
                self._retry_config = RetryConfig()
                self._branch_config = BranchConfig()
                self._workflow_id = None
                self._enable_waves = True
                self._enable_canals = False
                self._worktree_config = WorktreeConfig()
                self._evidence_config = EvidenceConfig()
                self._agent_loop_config = AgentLoopConfig()
                self._commands_client = AsyncMock()  # pyright: ignore[reportIncompatibleVariableOverride]
                self._sessions_client = AsyncMock()  # pyright: ignore[reportIncompatibleVariableOverride]
                self._shutdown_event = asyncio.Event()
                self._agent_id = "agent-xyz789"
                self._current_task = None
                self._signal_count = 0
                self._commands_executed = 0
                self._commands_succeeded = 0
                self._commands_failed = 0
                self._is_busy = False

        executor = TestExecutor()

        cmd = CommandResponse(
            id="cmd-1",
            agent_id="agent-xyz789",
            project_id="proj-1",
            command_type="task",
            task_id="task-1",
            status="claimed",
            created_at="2025-01-01T00:00:00Z",
            updated_at="2025-01-01T00:00:00Z",
        )

        # Mock TasksClient.get_task to return a task
        mock_task = {
            "id": "task-1",
            "title": "Test Task",
            "prompt": "Do something",
            "status": "unstarted",
            "priority": 3,
        }

        # Capture the Runner constructor call
        # Runner and TasksClient are lazily imported inside _execute_task_command
        with (
            patch("steerdev_agent.api.tasks.TasksClient") as mock_tasks_client_cls,
            patch("steerdev_agent.runner.Runner") as mock_runner_cls,
        ):
            # Set up task client mock
            mock_client_instance = MagicMock()
            mock_client_instance.__enter__ = MagicMock(return_value=mock_client_instance)
            mock_client_instance.__exit__ = MagicMock(return_value=False)
            mock_client_instance.get_task.return_value = mock_task
            mock_tasks_client_cls.return_value = mock_client_instance

            # Set up runner mock
            mock_runner = mock_runner_cls.return_value
            mock_runner.execute_task = AsyncMock(return_value={"success": True})

            await executor._execute_task_command(cmd, "proj-1", Path("/code"))

            # Verify Runner was created with agent_id
            runner_call = mock_runner_cls.call_args
            assert runner_call.kwargs["agent_id"] == "agent-xyz789"


# ============================================================================
# TasksClient get_next_wave / get_next_task with agent_id
# ============================================================================


class TestTasksClientAgentId:
    """Tests that TasksClient passes agent_id to API requests."""

    def test_get_next_wave_with_agent_id(self):
        """get_next_wave includes agent_id in query params."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"wave": {}, "tasks": []})
            with patch.object(client, "get", return_value=mock_resp) as mock_get:
                client.get_next_wave(project_id="proj-1", agent_id="agent-abc")

                call_args = mock_get.call_args
                params = call_args.kwargs.get("params") or call_args.args[1]
                assert params["agent_id"] == "agent-abc"
                assert params["waves"] == "true"
                assert params["project_id"] == "proj-1"

    def test_get_next_wave_without_agent_id(self):
        """get_next_wave omits agent_id when not provided."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"wave": {}, "tasks": []})
            with patch.object(client, "get", return_value=mock_resp) as mock_get:
                client.get_next_wave(project_id="proj-1")

                call_args = mock_get.call_args
                params = call_args.kwargs.get("params") or call_args.args[1]
                assert "agent_id" not in params

    def test_get_next_task_with_agent_id(self):
        """get_next_task includes agent_id in query params."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "get", return_value=mock_resp) as mock_get:
                client.get_next_task(project_id="proj-1", agent_id="agent-abc")

                call_args = mock_get.call_args
                params = call_args.kwargs.get("params") or call_args.args[1]
                assert params["agent_id"] == "agent-abc"

    def test_get_next_task_without_agent_id(self):
        """get_next_task omits agent_id when not provided."""
        with TasksClient(api_key="test-key") as client:
            mock_resp = _make_response(200, {"id": "task-1"})
            with patch.object(client, "get", return_value=mock_resp) as mock_get:
                client.get_next_task(project_id="proj-1")

                call_args = mock_get.call_args
                params = call_args.kwargs.get("params") or call_args.args[1]
                assert "agent_id" not in params


# ============================================================================
# CLI requeue command
# ============================================================================


class TestCLIRequeueCommand:
    """Tests for steerdev tasks requeue CLI command."""

    def test_requeue_invokes_client(self):
        """CLI calls requeue_task with parsed args."""
        from typer.testing import CliRunner

        from steerdev_agent.cli import app

        runner = CliRunner()

        with patch("steerdev_agent.api.tasks.TasksClient") as mock_client_cls:
            mock_instance = MagicMock()
            mock_instance.__enter__ = MagicMock(return_value=mock_instance)
            mock_instance.__exit__ = MagicMock(return_value=False)
            mock_instance.check_api_key.return_value = True
            mock_instance.requeue_task.return_value = True
            mock_client_cls.return_value = mock_instance

            result = runner.invoke(
                app,
                [
                    "tasks",
                    "requeue",
                    "task-abc123",
                    "--files",
                    "src/auth.ts,src/types.ts",
                    "--branch",
                    "task/PROJ-123-fix",
                ],
            )

            assert result.exit_code == 0
            mock_instance.requeue_task.assert_called_once_with(
                task_id="task-abc123",
                conflict_files=["src/auth.ts", "src/types.ts"],
                conflicting_task_id=None,
                previous_branch="task/PROJ-123-fix",
            )

    def test_requeue_failure_exits_nonzero(self):
        """CLI exits with code 1 when requeue fails."""
        from typer.testing import CliRunner

        from steerdev_agent.cli import app

        runner = CliRunner()

        with patch("steerdev_agent.api.tasks.TasksClient") as mock_client_cls:
            mock_instance = MagicMock()
            mock_instance.__enter__ = MagicMock(return_value=mock_instance)
            mock_instance.__exit__ = MagicMock(return_value=False)
            mock_instance.check_api_key.return_value = True
            mock_instance.requeue_task.return_value = False
            mock_client_cls.return_value = mock_instance

            result = runner.invoke(
                app,
                [
                    "tasks",
                    "requeue",
                    "task-abc123",
                    "--files",
                    "src/auth.ts",
                ],
            )

            assert result.exit_code == 1

    def test_requeue_with_conflicting_task_id(self):
        """CLI passes conflicting-task-id to client."""
        from typer.testing import CliRunner

        from steerdev_agent.cli import app

        runner = CliRunner()

        with patch("steerdev_agent.api.tasks.TasksClient") as mock_client_cls:
            mock_instance = MagicMock()
            mock_instance.__enter__ = MagicMock(return_value=mock_instance)
            mock_instance.__exit__ = MagicMock(return_value=False)
            mock_instance.check_api_key.return_value = True
            mock_instance.requeue_task.return_value = True
            mock_client_cls.return_value = mock_instance

            result = runner.invoke(
                app,
                [
                    "tasks",
                    "requeue",
                    "task-abc123",
                    "--files",
                    "src/auth.ts",
                    "--conflicting-task-id",
                    "task-def456",
                ],
            )

            assert result.exit_code == 0
            call_kwargs = mock_instance.requeue_task.call_args.kwargs
            assert call_kwargs["conflicting_task_id"] == "task-def456"

    def test_requeue_splits_comma_separated_files(self):
        """CLI correctly splits comma-separated file list."""
        from typer.testing import CliRunner

        from steerdev_agent.cli import app

        runner = CliRunner()

        with patch("steerdev_agent.api.tasks.TasksClient") as mock_client_cls:
            mock_instance = MagicMock()
            mock_instance.__enter__ = MagicMock(return_value=mock_instance)
            mock_instance.__exit__ = MagicMock(return_value=False)
            mock_instance.check_api_key.return_value = True
            mock_instance.requeue_task.return_value = True
            mock_client_cls.return_value = mock_instance

            result = runner.invoke(
                app,
                [
                    "tasks",
                    "requeue",
                    "task-1",
                    "--files",
                    "a.ts, b.ts , c.ts",
                ],
            )

            assert result.exit_code == 0
            call_kwargs = mock_instance.requeue_task.call_args.kwargs
            assert call_kwargs["conflict_files"] == ["a.ts", "b.ts", "c.ts"]
