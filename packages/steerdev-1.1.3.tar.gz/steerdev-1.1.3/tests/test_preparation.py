"""Tests for workspace preparation module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from steerdev_agent.config.models import BranchConfig, WorktreeConfig
from steerdev_agent.workspace.preparation import (
    PreparationResult,
    WorkspacePreparation,
)


@pytest.fixture
def default_config():
    return BranchConfig(default_branch="main")


@pytest.fixture
def dev_config():
    return BranchConfig(default_branch="dev")


@pytest.fixture
def worktree_disabled():
    return WorktreeConfig(enabled=False)


@pytest.fixture
def worktree_enabled():
    return WorktreeConfig(enabled=True, provider="worktrunk")


@pytest.fixture
def sample_task():
    return {
        "id": "abc12345-6789-0000-0000-000000000000",
        "title": "Add user authentication",
        "prompt": "Implement user auth",
        "status": "started",
    }


@pytest.fixture
def sample_task_with_linear():
    return {
        "id": "abc12345-6789-0000-0000-000000000000",
        "title": "Add user authentication",
        "prompt": "Implement user auth",
        "status": "started",
        "linear_identifier": "PROJ-123",
    }


class TestPreparationResult:
    """Tests for PreparationResult dataclass."""

    def test_success_result(self):
        result = PreparationResult(
            success=True,
            branch_name="task/abc12345-add-auth",
            working_directory=Path("/tmp/repo"),
            default_branch="main",
            is_worktree=False,
        )
        assert result.success is True
        assert result.error is None
        assert result.warnings == []

    def test_failure_result(self):
        result = PreparationResult(
            success=False,
            branch_name="task/abc12345-add-auth",
            working_directory=Path("/tmp/repo"),
            default_branch="main",
            is_worktree=False,
            error="Not a git repository",
        )
        assert result.success is False
        assert result.error == "Not a git repository"


class TestWorkspacePreparationWorktree:
    """Tests for worktree mode preparation."""

    @pytest.mark.asyncio
    async def test_worktree_delegates_to_worktrunk(
        self, worktree_enabled, default_config, sample_task
    ):
        """Worktree mode delegates to WorktrunkClient.switch()."""
        prep = WorkspacePreparation(
            working_directory=Path("/tmp/repo"),
            worktree_config=worktree_enabled,
            branch_config=default_config,
        )

        mock_switch = AsyncMock(
            return_value=Path("/tmp/worktrees/task/abc12345-add-user-authentication")
        )

        with patch("steerdev_agent.worktree.WorktrunkClient") as mock_client:
            mock_client.return_value.switch = mock_switch
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert result.is_worktree is True
        assert "task/" in result.branch_name
        mock_switch.assert_called_once()


class TestWorkspacePreparationInPlace:
    """Tests for non-worktree (in-place) preparation."""

    @pytest.mark.asyncio
    async def test_single_task_creates_branch(self, worktree_disabled, default_config, sample_task):
        """Single task: fetches, syncs default branch, creates task branch."""
        prep = WorkspacePreparation(
            working_directory=Path("/tmp/repo"),
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        calls = []

        async def mock_run_git(*args, cwd, check=True):
            calls.append(args)
            cmd = " ".join(args)
            if "rev-parse --is-inside-work-tree" in cmd:
                return (0, "true", "")
            if "branch --show-current" in cmd:
                # First call: on main, second: on target branch
                if len([c for c in calls if "branch --show-current" in " ".join(c)]) <= 1:
                    return (0, "main", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "", "")  # clean
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")  # branch doesn't exist
            if "checkout -b" in cmd:
                return (0, "", "")
            if "checkout" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert result.is_worktree is False
        assert "task/" in result.branch_name
        assert result.default_branch == "main"

    @pytest.mark.asyncio
    async def test_custom_default_branch(self, worktree_disabled, dev_config, sample_task):
        """Uses configured default branch (dev) instead of main."""
        prep = WorkspacePreparation(
            working_directory=Path("/tmp/repo"),
            worktree_config=worktree_disabled,
            branch_config=dev_config,
        )

        checkout_args = []

        async def mock_run_git(*args, cwd, check=True):
            checkout_args.append(args)
            cmd = " ".join(args)
            if "rev-parse --is-inside-work-tree" in cmd:
                return (0, "true", "")
            if "branch --show-current" in cmd:
                if len([c for c in checkout_args if "branch --show-current" in " ".join(c)]) <= 1:
                    return (0, "dev", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout dev" in cmd:
                return (0, "", "")
            if "merge --ff-only origin/dev" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")
            if "checkout -b" in cmd:
                return (0, "", "")
            if "checkout" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert result.default_branch == "dev"
        # Verify checkout was to "dev" not "main"
        checkout_cmds = [c for c in checkout_args if c == ("checkout", "dev")]
        assert len(checkout_cmds) > 0

    @pytest.mark.asyncio
    async def test_continuing_wave_stays_on_branch(
        self, worktree_disabled, default_config, sample_task
    ):
        """Continuing a wave stays on the wave branch, only fetches."""
        from steerdev_agent.prompt.builder import WaveContext

        wave_ctx = WaveContext(wave_number=3, total_waves=5, wave_name="wave-a1b2c3")

        prep = WorkspacePreparation(
            working_directory=Path("/tmp/repo"),
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        calls = []

        async def mock_run_git(*args, cwd, check=True):
            calls.append(args)
            cmd = " ".join(args)
            if "rev-parse --is-inside-work-tree" in cmd:
                return (0, "true", "")
            if "branch --show-current" in cmd:
                return (0, "wave-a1b2c3", "")  # Already on wave branch
            if "fetch origin" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task, wave_ctx)

        assert result.success is True
        assert result.branch_name == "wave-a1b2c3"
        # Should NOT have checkout commands (stayed on branch)
        checkout_cmds = [c for c in calls if c[0] == "checkout"]
        assert len(checkout_cmds) == 0

    @pytest.mark.asyncio
    async def test_dirty_repo_stashes(self, worktree_disabled, default_config, sample_task):
        """Dirty working directory triggers stash before sync."""
        prep = WorkspacePreparation(
            working_directory=Path("/tmp/repo"),
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        calls = []

        async def mock_run_git(*args, cwd, check=True):
            calls.append(args)
            cmd = " ".join(args)
            if "rev-parse --is-inside-work-tree" in cmd:
                return (0, "true", "")
            if "branch --show-current" in cmd:
                if len([c for c in calls if "branch --show-current" in " ".join(c)]) <= 1:
                    return (0, "main", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "M  dirty_file.py", "")  # dirty
            if "stash push" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")
            if "checkout -b" in cmd:
                return (0, "", "")
            if "checkout" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert len(result.warnings) > 0
        assert "stash" in result.warnings[0].lower()
        # Verify stash was called
        stash_cmds = [c for c in calls if "stash" in " ".join(c)]
        assert len(stash_cmds) > 0

    @pytest.mark.asyncio
    async def test_not_git_repo_no_subrepos_fails(
        self, worktree_disabled, default_config, sample_task, tmp_path
    ):
        """Non-git directory with no sub-repos returns failure."""
        prep = WorkspacePreparation(
            working_directory=tmp_path,
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        async def mock_run_git(*args, cwd, check=True):
            cmd = " ".join(args)
            if "rev-parse --is-inside-work-tree" in cmd:
                return (128, "", "fatal: not a git repository")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is False
        assert "Not a git repository" in (result.error or "")

    @pytest.mark.asyncio
    async def test_ff_only_fallback_resets(self, worktree_disabled, default_config, sample_task):
        """When ff-only merge fails, falls back to hard reset."""
        prep = WorkspacePreparation(
            working_directory=Path("/tmp/repo"),
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        calls = []

        async def mock_run_git(*args, cwd, check=True):
            calls.append(args)
            cmd = " ".join(args)
            if "rev-parse --is-inside-work-tree" in cmd:
                return (0, "true", "")
            if "branch --show-current" in cmd:
                if len([c for c in calls if "branch --show-current" in " ".join(c)]) <= 1:
                    return (0, "main", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (1, "", "fatal: Not possible to fast-forward")  # ff fails
            if "reset --hard" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")
            if "checkout -b" in cmd:
                return (0, "", "")
            if "checkout" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        # Verify reset was called
        reset_cmds = [c for c in calls if "reset" in " ".join(c)]
        assert len(reset_cmds) > 0
        assert any("fast-forward" in w.lower() or "reset" in w.lower() for w in result.warnings)


class TestWorkspacePreparationMultiRepo:
    """Tests for multi-repo workspace preparation."""

    @pytest.fixture
    def worktree_disabled(self):
        return WorktreeConfig(enabled=False)

    @pytest.fixture
    def default_config(self):
        return BranchConfig(default_branch="main")

    @pytest.fixture
    def sample_task(self):
        return {
            "id": "abc12345-6789-0000-0000-000000000000",
            "title": "Add user authentication",
            "prompt": "Implement user auth",
            "status": "started",
        }

    @pytest.mark.asyncio
    async def test_multi_repo_discovers_and_prepares_all(
        self, worktree_disabled, default_config, sample_task, tmp_path
    ):
        """Multi-repo layout: discovers sub-repos and prepares each one."""
        # Create subdirectories to simulate multi-repo layout
        (tmp_path / "repo_a").mkdir()
        (tmp_path / "repo_b").mkdir()
        (tmp_path / ".hidden").mkdir()  # should be skipped

        prep = WorkspacePreparation(
            working_directory=tmp_path,
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        calls: list[tuple[tuple[str, ...], Path]] = []

        async def mock_run_git(*args, cwd, check=True):
            calls.append((args, Path(cwd)))
            cmd = " ".join(args)
            cwd_path = Path(cwd)

            if "rev-parse --is-inside-work-tree" in cmd:
                # Parent dir is NOT a repo; subdirs ARE repos
                if cwd_path == tmp_path:
                    return (128, "", "fatal: not a git repository")
                if cwd_path.name in ("repo_a", "repo_b"):
                    return (0, "true", "")
                return (128, "", "fatal: not a git repository")
            if "branch --show-current" in cmd:
                # Track per-repo calls to return correct branch after checkout
                show_current_calls = [
                    c
                    for c in calls
                    if "branch --show-current" in " ".join(c[0]) and c[1] == cwd_path
                ]
                if len(show_current_calls) <= 1:
                    return (0, "main", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")  # branch doesn't exist
            if "checkout -b" in cmd:
                return (0, "", "")
            if "checkout" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert result.working_directory == tmp_path  # parent dir preserved
        assert len(result.repo_directories) == 2
        assert tmp_path / "repo_a" in result.repo_directories
        assert tmp_path / "repo_b" in result.repo_directories
        # Verify git operations ran against both repos
        repo_a_checkouts = [
            c for c in calls if c[1] == tmp_path / "repo_a" and "checkout -b" in " ".join(c[0])
        ]
        repo_b_checkouts = [
            c for c in calls if c[1] == tmp_path / "repo_b" and "checkout -b" in " ".join(c[0])
        ]
        assert len(repo_a_checkouts) == 1
        assert len(repo_b_checkouts) == 1

    @pytest.mark.asyncio
    async def test_multi_repo_fails_if_one_repo_fails(
        self, worktree_disabled, default_config, sample_task, tmp_path
    ):
        """Multi-repo: failure in one repo fails the whole preparation."""
        (tmp_path / "repo_a").mkdir()
        (tmp_path / "repo_b").mkdir()

        prep = WorkspacePreparation(
            working_directory=tmp_path,
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        # Track per-repo branch --show-current calls
        branch_calls_per_repo: dict[str, int] = {}

        async def mock_run_git(*args, cwd, check=True):
            cmd = " ".join(args)
            cwd_path = Path(cwd)
            repo_name = cwd_path.name

            if "rev-parse --is-inside-work-tree" in cmd:
                if cwd_path == tmp_path:
                    return (128, "", "fatal: not a git repository")
                if repo_name in ("repo_a", "repo_b"):
                    return (0, "true", "")
                return (128, "", "")
            if "branch --show-current" in cmd:
                branch_calls_per_repo[repo_name] = branch_calls_per_repo.get(repo_name, 0) + 1
                if branch_calls_per_repo[repo_name] <= 1:
                    return (0, "main", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                # repo_b fails to checkout default branch
                if repo_name == "repo_b":
                    return (1, "", "error: pathspec 'main' did not match")
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")
            if "checkout -b" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is False
        assert "repo_b" in (result.error or "")
        # repo_a was prepared before repo_b failed
        assert len(result.repo_directories) == 1
        assert tmp_path / "repo_a" in result.repo_directories

    @pytest.mark.asyncio
    async def test_multi_repo_collects_warnings_with_prefix(
        self, worktree_disabled, default_config, sample_task, tmp_path
    ):
        """Multi-repo: warnings are prefixed with repo name."""
        (tmp_path / "repo_a").mkdir()

        prep = WorkspacePreparation(
            working_directory=tmp_path,
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        branch_call_count = [0]

        async def mock_run_git(*args, cwd, check=True):
            cmd = " ".join(args)
            cwd_path = Path(cwd)

            if "rev-parse --is-inside-work-tree" in cmd:
                if cwd_path == tmp_path:
                    return (128, "", "fatal: not a git repository")
                return (0, "true", "")
            if "branch --show-current" in cmd:
                # Return target branch on validation check
                branch_call_count[0] += 1
                if branch_call_count[0] > 1:
                    return (0, "task/abc12345-add-user-authentication", "")
                return (0, "main", "")
            if "status --porcelain" in cmd:
                return (0, "M  dirty.py", "")  # dirty repo
            if "stash push" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")
            if "checkout -b" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert any("[repo_a]" in w for w in result.warnings)

    @pytest.mark.asyncio
    async def test_multi_repo_skips_hidden_and_non_repo_dirs(
        self, worktree_disabled, default_config, sample_task, tmp_path
    ):
        """Multi-repo: hidden dirs and non-repo dirs are skipped."""
        (tmp_path / ".hidden_repo").mkdir()
        (tmp_path / "not_a_repo").mkdir()
        (tmp_path / "actual_repo").mkdir()

        prep = WorkspacePreparation(
            working_directory=tmp_path,
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        calls_by_cwd: dict[str, list[str]] = {}

        async def mock_run_git(*args, cwd, check=True):
            cmd = " ".join(args)
            cwd_path = Path(cwd)
            calls_by_cwd.setdefault(cwd_path.name, []).append(cmd)

            if "rev-parse --is-inside-work-tree" in cmd:
                if cwd_path == tmp_path:
                    return (128, "", "fatal: not a git repository")
                if cwd_path.name == "actual_repo":
                    return (0, "true", "")
                return (128, "", "fatal: not a git repository")
            if "branch --show-current" in cmd:
                branch_calls = [
                    c for c in calls_by_cwd.get(cwd_path.name, []) if "branch --show-current" in c
                ]
                if len(branch_calls) <= 1:
                    return (0, "main", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")
            if "checkout -b" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert len(result.repo_directories) == 1
        assert tmp_path / "actual_repo" in result.repo_directories
        # Hidden dir should never have been checked
        assert ".hidden_repo" not in calls_by_cwd

    @pytest.mark.asyncio
    async def test_single_repo_still_works(self, worktree_disabled, default_config, sample_task):
        """Single-repo layout still works as before (no regressions)."""
        prep = WorkspacePreparation(
            working_directory=Path("/tmp/repo"),
            worktree_config=worktree_disabled,
            branch_config=default_config,
        )

        calls = []

        async def mock_run_git(*args, cwd, check=True):
            calls.append(args)
            cmd = " ".join(args)
            if "rev-parse --is-inside-work-tree" in cmd:
                return (0, "true", "")
            if "branch --show-current" in cmd:
                if len([c for c in calls if "branch --show-current" in " ".join(c)]) <= 1:
                    return (0, "main", "")
                return (0, "task/abc12345-add-user-authentication", "")
            if "status --porcelain" in cmd:
                return (0, "", "")
            if "fetch origin" in cmd:
                return (0, "", "")
            if "checkout main" in cmd:
                return (0, "", "")
            if "merge --ff-only" in cmd:
                return (0, "", "")
            if "rev-parse --verify" in cmd:
                return (1, "", "")
            if "checkout -b" in cmd:
                return (0, "", "")
            return (0, "", "")

        with patch("steerdev_agent.workspace.preparation._run_git", side_effect=mock_run_git):
            result = await prep.prepare(sample_task)

        assert result.success is True
        assert result.repo_directories == []  # single-repo: no repo_directories
        assert result.working_directory == Path("/tmp/repo")
