"""Tests for workflow runs API client — models, start_workflow, and disabled-workflow handling."""

import os
from typing import Any
from unittest.mock import AsyncMock, patch

import httpx
import pytest

from steerdev_agent.api.workflow_runs import (
    PhaseRunResponse,
    WorkflowRunResponse,
    WorkflowRunsClient,
)

# ── Shared fixtures ───────────────────────────────────────────────────────

NOW = "2026-01-01T00:00:00Z"


def _make_workflow_run_json(
    *,
    workflow_id: str = "wf-1",
    workflow_name: str = "Feature Dev",
    status: str = "running",
    total_phases: int = 3,
    **extra: Any,
) -> dict[str, Any]:
    return {
        "id": "wr-1",
        "workflow_id": workflow_id,
        "workflow_name": workflow_name,
        "status": status,
        "total_phases": total_phases,
        "created_at": NOW,
        "updated_at": NOW,
        **extra,
    }


# ── Model tests ───────────────────────────────────────────────────────────


class TestWorkflowRunModels:
    """Tests for Pydantic models in workflow_runs.py."""

    def test_workflow_run_response_minimal(self):
        resp = WorkflowRunResponse(
            id="wr-1",
            workflow_id="wf-1",
            workflow_name="Test",
            status="running",
            created_at=NOW,
            updated_at=NOW,
        )
        assert resp.id == "wr-1"
        assert resp.project_id is None
        assert resp.phase_runs is None
        assert resp.phases_completed == 0
        assert resp.total_phases == 0

    def test_workflow_run_response_full(self):
        resp = WorkflowRunResponse(
            id="wr-1",
            workflow_id="wf-1",
            workflow_name="Feature Dev",
            project_id="proj-1",
            run_id="run-1",
            linear_issue_id="LIN-123",
            status="completed",
            current_phase_id="p3",
            current_phase_name="Verify",
            context={"key": "value"},
            phases_completed=3,
            total_phases=3,
            started_at=NOW,
            completed_at=NOW,
            created_at=NOW,
            updated_at=NOW,
        )
        assert resp.phases_completed == 3
        assert resp.context == {"key": "value"}
        assert resp.linear_issue_id == "LIN-123"

    def test_phase_run_response_minimal(self):
        resp = PhaseRunResponse(
            id="pr-1",
            workflow_run_id="wr-1",
            phase_id="p-1",
            phase_name="Plan",
            phase_type="plan",
            status="pending",
            created_at=NOW,
            updated_at=NOW,
        )
        assert resp.attempt_number == 1
        assert resp.input_context == {}
        assert resp.result_summary is None

    def test_phase_run_response_full(self):
        resp = PhaseRunResponse(
            id="pr-1",
            workflow_run_id="wr-1",
            phase_id="p-1",
            phase_name="Implement",
            phase_type="implement",
            status="completed",
            attempt_number=2,
            input_context={"spec": "build API"},
            output_context={"files": ["main.py"]},
            result_summary="Implementation complete",
            started_at=NOW,
            completed_at=NOW,
            created_at=NOW,
            updated_at=NOW,
        )
        assert resp.attempt_number == 2
        assert resp.output_context["files"] == ["main.py"]


# ── Client tests ──────────────────────────────────────────────────────────


class TestWorkflowRunsClient:
    """Tests for WorkflowRunsClient."""

    def test_init_with_api_key(self):
        client = WorkflowRunsClient(api_key="test-key")
        assert client.api_key == "test-key"

    def test_init_from_env(self):
        with patch.dict(os.environ, {"STEERDEV_API_KEY": "env-key"}):
            client = WorkflowRunsClient()
            assert client.api_key == "env-key"

    def test_headers(self):
        client = WorkflowRunsClient(api_key="test-key")
        assert client.headers["Authorization"] == "Bearer test-key"

    @pytest.mark.asyncio
    async def test_context_manager(self):
        async with WorkflowRunsClient(api_key="key") as client:
            assert client.api_key == "key"
        assert client._client is None

    @pytest.mark.asyncio
    async def test_close_without_client(self):
        client = WorkflowRunsClient(api_key="key")
        await client.close()  # Should not raise


class TestStartWorkflow:
    """Tests for start_workflow — including disabled-workflow (409) handling."""

    @pytest.mark.asyncio
    async def test_start_workflow_success(self):
        """201 → returns WorkflowRunResponse."""
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(201, json=_make_workflow_run_json())
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.start_workflow("wf-1", run_id="run-1")
        assert result is not None
        assert result.id == "wr-1"
        assert result.workflow_id == "wf-1"

    @pytest.mark.asyncio
    async def test_start_workflow_with_initial_context(self):
        """Initial context is passed in the payload."""
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(201, json=_make_workflow_run_json())
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.start_workflow(
            "wf-1",
            initial_context={"task_title": "Fix login bug"},
        )
        assert result is not None
        # Verify payload included initial_context
        call_kwargs = mock_http.post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
        assert payload["initial_context"] == {"task_title": "Fix login bug"}

    @pytest.mark.asyncio
    async def test_start_workflow_server_error(self):
        """500 → returns None."""
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(500, text="Internal Server Error")
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.start_workflow("wf-1")
        assert result is None

    @pytest.mark.asyncio
    async def test_start_workflow_not_found(self):
        """404 → returns None."""
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(
            404,
            json={"error": "Not Found", "message": "Workflow not found"},
        )
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.start_workflow("wf-nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_start_workflow_request_error(self):
        """Network error → returns None."""
        client = WorkflowRunsClient(api_key="key")
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(side_effect=httpx.RequestError("connection refused"))
        client._client = mock_http

        result = await client.start_workflow("wf-1")
        assert result is None

    @pytest.mark.asyncio
    async def test_start_workflow_disabled_409_returns_none(self):
        """409 with NO_ACTIVE_WORKFLOW → returns None (agent should proceed without workflow)."""
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(
            409,
            json={
                "error": "Workflow disabled",
                "message": "The requested workflow is disabled and no suitable active workflow was found.",
                "code": "NO_ACTIVE_WORKFLOW",
            },
        )
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.start_workflow("wf-disabled")
        assert result is None

    @pytest.mark.asyncio
    async def test_start_workflow_disabled_409_reassigned(self):
        """409 that re-triaged to a different workflow → 201 with new workflow_id.

        This tests the server-side behavior: the API transparently re-assigns
        to the best active workflow. The client receives a normal 201 with the
        new workflow's run.
        """
        client = WorkflowRunsClient(api_key="key")
        # Server re-triaged to a different workflow
        mock_response = httpx.Response(
            201,
            json=_make_workflow_run_json(
                workflow_id="wf-fallback",
                workflow_name="Bug Fix Workflow",
            ),
        )
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.start_workflow("wf-disabled-original")
        assert result is not None
        # The returned workflow_id is the re-assigned one, not the original
        assert result.workflow_id == "wf-fallback"
        assert result.workflow_name == "Bug Fix Workflow"


class TestAdvancePhase:
    """Tests for advance_phase."""

    @pytest.mark.asyncio
    async def test_advance_success(self):
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(
            200,
            json=_make_workflow_run_json(status="running"),
        )
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.advance_phase("wr-1", output_context={"files": ["a.py"]})
        assert result is not None
        assert result.status == "running"

    @pytest.mark.asyncio
    async def test_advance_failure(self):
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(500, text="error")
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.advance_phase("wr-1")
        assert result is None


class TestFailPhase:
    """Tests for fail_phase."""

    @pytest.mark.asyncio
    async def test_fail_phase_success(self):
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(
            200,
            json=_make_workflow_run_json(status="running"),
        )
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.fail_phase("wr-1", error_message="compilation failed")
        assert result is not None

    @pytest.mark.asyncio
    async def test_fail_phase_network_error(self):
        client = WorkflowRunsClient(api_key="key")
        mock_http = AsyncMock()
        mock_http.post = AsyncMock(side_effect=httpx.RequestError("timeout"))
        client._client = mock_http

        result = await client.fail_phase("wr-1", error_message="oops")
        assert result is None


class TestCancelWorkflowRun:
    """Tests for cancel_workflow_run."""

    @pytest.mark.asyncio
    async def test_cancel_success(self):
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(
            200,
            json=_make_workflow_run_json(status="cancelled"),
        )
        mock_http = AsyncMock()
        mock_http.delete = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.cancel_workflow_run("wr-1")
        assert result is not None
        assert result.status == "cancelled"

    @pytest.mark.asyncio
    async def test_cancel_failure(self):
        client = WorkflowRunsClient(api_key="key")
        mock_response = httpx.Response(404, text="Not found")
        mock_http = AsyncMock()
        mock_http.delete = AsyncMock(return_value=mock_response)
        client._client = mock_http

        result = await client.cancel_workflow_run("wr-nonexistent")
        assert result is None
