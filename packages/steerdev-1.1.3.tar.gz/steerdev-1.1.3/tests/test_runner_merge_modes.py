"""Tests for runner merge-flow resolution."""

from steerdev_agent.prompt.builder import WaveContext
from steerdev_agent.runner import (
    build_workflow_task_context,
    extract_task_and_wave_context,
    resolve_merge_flow,
)


def _make_wave_context() -> WaveContext:
    return WaveContext(
        wave_number=3,
        total_waves=5,
        wave_name="wave-a1b2c3",
        wave_description="User management improvements",
        wave_tasks_summary="  [todo] Add user endpoint",
        completed_waves_summary="  - Wave 2: Auth cleanup",
    )


def _make_wave_response(task_id: str = "task-123") -> dict:
    return {
        "wave": {
            "wave_number": 3,
            "total_waves": 5,
            "name": "wave-a1b2c3",
            "description": "User management improvements",
        },
        "context": {
            "next_task": {
                "id": task_id,
                "title": "Add auth",
                "prompt": "Implement OAuth",
            },
            "completed_waves": [
                {"wave_number": 2, "description": "Auth cleanup"},
            ],
        },
        "tasks": [
            {"title": "Add user endpoint", "status": "unstarted"},
        ],
    }


class TestResolveMergeFlow:
    """Tests for merge mode selection."""

    def test_single_task_when_waves_disabled(self):
        assert resolve_merge_flow(False, False, None) == (
            "single_task",
            "single-task-merge",
        )

    def test_single_task_when_wave_context_missing(self):
        assert resolve_merge_flow(True, False, None) == (
            "single_task",
            "single-task-merge",
        )

    def test_wave_when_wave_context_present(self):
        assert resolve_merge_flow(True, False, _make_wave_context()) == (
            "wave",
            "wave-tasks-merge",
        )

    def test_canal_overrides_wave_mode(self):
        assert resolve_merge_flow(True, True, _make_wave_context()) == (
            "canal",
            "merge-into-canal",
        )


class TestBuildWorkflowTaskContext:
    """Tests for workflow prompt context generation."""

    def test_includes_merge_and_wave_metadata(self):
        context = build_workflow_task_context(
            {
                "id": "task-123",
                "title": "Add auth",
                "prompt": "Implement OAuth",
                "status": "started",
                "priority": 2,
            },
            _make_wave_context(),
            waves_enabled=True,
            canals_enabled=False,
        )

        assert context["task_id"] == "task-123"
        assert context["task_title"] == "Add auth"
        assert context["task_prompt"] == "Implement OAuth"
        assert context["task_description"] == "Implement OAuth"
        assert context["merge_mode"] == "wave"
        assert context["merge_skill"] == "wave-tasks-merge"
        assert context["waves_enabled"] is True
        assert context["canals_enabled"] is False
        assert context["has_wave_context"] is True
        assert context["wave_number"] == 3
        assert "Add user endpoint" in context["wave_tasks_summary"]

    def test_includes_canal_mode_without_wave_context(self):
        context = build_workflow_task_context(
            {"id": "task-123", "title": "Add auth", "prompt": "Implement OAuth"},
            None,
            waves_enabled=False,
            canals_enabled=True,
        )

        assert context["merge_mode"] == "canal"
        assert context["merge_skill"] == "merge-into-canal"
        assert context["has_wave_context"] is False


class TestWaveResponseHelpers:
    """Tests for shared wave-response parsing helpers."""

    def test_extract_task_and_wave_context_from_wave_response(self):
        task, wave_context, suggested_wf = extract_task_and_wave_context(_make_wave_response())

        assert task is not None
        assert task["id"] == "task-123"
        assert wave_context is not None
        assert wave_context.wave_number == 3
        assert suggested_wf is None

    def test_extract_task_and_wave_context_from_plain_task(self):
        task, wave_context, suggested_wf = extract_task_and_wave_context(
            {"id": "task-plain", "title": "Plain task"}
        )

        assert task == {"id": "task-plain", "title": "Plain task"}
        assert wave_context is None
        assert suggested_wf is None

    def test_extract_task_and_wave_context_returns_suggested_workflow_id(self):
        response = _make_wave_response()
        response["suggested_workflow_id"] = "wf-abc123"
        task, wave_context, suggested_wf = extract_task_and_wave_context(response)

        assert task is not None
        assert wave_context is not None
        assert suggested_wf == "wf-abc123"

    def test_extract_task_and_wave_context_from_none(self):
        task, wave_context, suggested_wf = extract_task_and_wave_context(None)

        assert task is None
        assert wave_context is None
        assert suggested_wf is None
