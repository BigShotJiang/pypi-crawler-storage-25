# -*- coding: utf-8 -*-
# Copyright (c) 2003, Taro Ogawa.  All Rights Reserved.
# Copyright (c) 2013, Savoir-faire Linux inc.  All Rights Reserved.

# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2.1 of the License, or (at your option) any later version.
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# Lesser General Public License for more details.
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
# MA 02110-1301 USA

from __future__ import unicode_literals

from .lang_EN import Num2Word_EN


class Num2Word_EN_IN(Num2Word_EN):
    def __init__(self):
        super(Num2Word_EN_IN, self).__init__()
        self.CURRENCY_FORMS["INR"] = (("rupee", "rupees"), ("paisa", "paise"))

    def set_high_numwords(self, high):
        # Indian numbering scale (Vedic). Issue #72 ports
        # savoirfairelinux/num2words#414. Each step is 10^2 once past lakh.
        self.cards[10 ** 19] = "mahashankh"
        self.cards[10 ** 17] = "shankh"
        self.cards[10 ** 15] = "padma"
        self.cards[10 ** 13] = "neel"
        self.cards[10 ** 11] = "kharab"
        self.cards[10 ** 9] = "arab"
        self.cards[10 ** 7] = "crore"
        self.cards[10 ** 5] = "lakh"

    def to_currency(self, val, currency="INR", **kwargs):
        # Indian English defaults to INR (rupees/paise) instead of EUR.
        return super(Num2Word_EN_IN, self).to_currency(
            val, currency=currency, **kwargs
        )
