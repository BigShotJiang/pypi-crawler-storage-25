"""Tests for Karnosky-Singer currency attribution."""

from __future__ import annotations

import pytest

from pybrinson import (
    AttributionError,
    Segment,
    bhb,
    currency_attribution,
    fachler,
)
from pybrinson.fixtures import (
    bacon_2008_ch5_bhb,
    karnosky_singer_3segment,
)


def test_karnosky_singer_pinned_fixture() -> None:
    segments, expected = karnosky_singer_3segment()
    result = currency_attribution(segments, period="2024-Q1")

    assert result.method == "Karnosky-Singer"
    assert result.period == "2024-Q1"
    assert result.portfolio_return == pytest.approx(expected["portfolio_return"])
    assert result.benchmark_return == pytest.approx(expected["benchmark_return"])
    assert result.excess_return == pytest.approx(expected["excess_return"])
    assert result.market_allocation == pytest.approx(expected["market_allocation"])
    assert result.security_selection == pytest.approx(expected["security_selection"])
    assert result.currency_allocation == pytest.approx(expected["currency_allocation"])
    assert result.interaction == pytest.approx(expected["interaction"])


def test_identity_closes_to_1e9() -> None:
    segments, _ = karnosky_singer_3segment()
    r = currency_attribution(segments)
    residual = (
        r.market_allocation
        + r.security_selection
        + r.currency_allocation
        + r.interaction
        - r.excess_return
    )
    assert abs(residual) < 1e-9


def test_zero_currency_collapses_to_local_bhb() -> None:
    """When every c_i = 0, local == base and the market+selection+interaction
    triple must coincide with a BHB run on the same returns."""
    segs = (
        Segment(
            "A",
            0.6,
            0.5,
            0.10,
            0.05,
            local_return=0.10,
            currency_return=0.0,
        ),
        Segment(
            "B",
            0.4,
            0.5,
            0.05,
            0.10,
            local_return=0.05,
            currency_return=0.0,
        ),
    )
    cur = currency_attribution(segs)
    # Drop the currency fields for BHB comparison.
    plain = tuple(
        Segment(
            s.name,
            s.portfolio_weight,
            s.benchmark_weight,
            s.portfolio_return,
            s.benchmark_return,
        )
        for s in segs
    )
    b = bhb(plain)
    # KS market_allocation uses BF form (R_L_b - R_L_b_total), so it
    # matches fachler() rather than bhb() for allocation. Check the sums.
    f = fachler(plain)
    assert cur.currency_allocation == pytest.approx(0.0, abs=1e-12)
    assert cur.market_allocation == pytest.approx(f.allocation)
    assert cur.security_selection == pytest.approx(f.selection)
    assert cur.interaction == pytest.approx(b.interaction)


def test_missing_fields_raises() -> None:
    segs = (
        Segment("A", 0.5, 0.5, 0.10, 0.05),
        Segment("B", 0.5, 0.5, 0.05, 0.10),
    )
    with pytest.raises(AttributionError, match="missing local_return"):
        currency_attribution(segs)


def test_additive_inconsistency_raises() -> None:
    segs = (
        Segment(
            "A",
            0.5,
            0.5,
            0.10,
            0.05,
            local_return=0.09,  # + 0.0 != 0.10
            currency_return=0.0,
        ),
        Segment(
            "B",
            0.5,
            0.5,
            0.05,
            0.10,
            local_return=0.05,
            currency_return=0.0,
        ),
    )
    with pytest.raises(AttributionError, match="additive consistency"):
        currency_attribution(segs)


def test_empty_raises() -> None:
    with pytest.raises(AttributionError, match="at least one Segment"):
        currency_attribution(())


def test_bhb_backward_compat_unchanged() -> None:
    """Adding the optional fields must not perturb BHB on the canonical
    Bacon-2008 fixture."""
    segments, expected = bacon_2008_ch5_bhb()
    r = bhb(segments)
    assert r.excess_return == pytest.approx(expected["excess_return"])
    assert r.allocation == pytest.approx(expected["allocation"])
    assert r.selection == pytest.approx(expected["selection"])
    assert r.interaction == pytest.approx(expected["interaction"])
