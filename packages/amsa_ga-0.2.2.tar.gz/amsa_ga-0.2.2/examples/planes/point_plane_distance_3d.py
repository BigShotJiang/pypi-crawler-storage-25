# Copyright 2026 Surya Sunkara
# SPDX-License-Identifier: Apache-2.0

"""
AMSA Example

Topic: Distance from a point to a plane using geometric algebra
Algebra: 3D Vector Geometric Algebra (VGA)

A plane can be defined by two spanning vectors:

    u, v

The wedge product produces the plane bivector:

    B = u ∧ v

The dual of the bivector gives the plane normal:

    n = dual(B)

For a point p and a point p0 on the plane, the signed distance is:

    distance = ( (p − p0) · n ) / ||n||

This example shows how geometric algebra represents planes and
computes point-to-plane distance using multivector operations.
"""

import numpy as np

from amsa import Algebra

print("\n=== Point to Plane Distance ===")

alg = Algebra.vga3d()

# plane origin
p0 = alg.vector([0.0, 0.0, 0.0])

# plane spanning vectors
u = alg.vector([1.0, 0.0, 0.0])
v = alg.vector([0.0, 1.0, 0.0])

# plane bivector
B = u ^ v

n = B.dual()

# point above the plane
p = alg.vector([0.5, 0.5, 2.0])

# displacement
d = p - p0

# signed distance
distance = (d | n).component("e") / np.linalg.norm(n.values)

print("Plane bivector:", B.values)
print("Plane normal:", n.values)
print("Point:", p.values)

print(f"\nSigned distance to plane: {distance}")
