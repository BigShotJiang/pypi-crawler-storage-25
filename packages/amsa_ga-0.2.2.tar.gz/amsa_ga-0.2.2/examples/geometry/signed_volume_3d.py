# Copyright 2026 Surya Sunkara
# SPDX-License-Identifier: Apache-2.0

"""
AMSA Example

Topic: Signed volume of a parallelepiped using the outer product
Algebra: 3D Vector Geometric Algebra (VGA)

Given three vectors u, v, w in 3D space we compute the trivector:

    T = u ∧ v ∧ w

In 3D VGA the highest grade basis element is e123, so:

    T = V * e123

where V is the signed volume coefficient.

Thus the signed volume is:

    Volume = (u ∧ v ∧ w)_{e123}

Interpretation:

    Volume > 0  → right-handed orientation
    Volume < 0  → left-handed orientation
    Volume = 0  → coplanar vectors

This example demonstrates the relationship between the GA trivector
and the classical determinant.
"""

from amsa import Algebra

print("\n=== Signed Volume Example ===")

alg = Algebra.vga3d()

# example vectors
u = alg.vector([1.0, 0.0, 0.0])
v = alg.vector([0.0, 2.0, 0.0])
w = alg.vector([0.0, 0.0, 3.0])

trivector = u ^ v ^ w
volume = trivector.component("e123")

print("u:", u.values)
print("v:", v.values)
print("w:", w.values)

print("\nTrivector:", trivector.values)
print(f"Signed volume: {volume}")
