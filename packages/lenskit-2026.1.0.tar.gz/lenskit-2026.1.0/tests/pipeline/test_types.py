# This file is part of LensKit.
# Copyright (C) 2018-2023 Boise State University.
# Copyright (C) 2023-2026 Drexel University.
# Licensed under the MIT license, see LICENSE.md for details.
# SPDX-License-Identifier: MIT

"""
Tests for the pipeline type-checking functions.
"""

import typing
import warnings
from collections.abc import Iterable, Sequence
from pathlib import Path
from types import NoneType
from typing import Any, TypeVar
from uuid import UUID

import numpy as np
import pandas as pd
from numpy.typing import ArrayLike, NDArray

from pytest import mark, warns

from lenskit.data import MatrixRelationshipSet, QueryInput, RecQuery, RelationshipSet
from lenskit.pipeline._types import (
    TypecheckWarning,
    import_path_string,
    is_compatible_data,
    is_compatible_type,
    is_instance_or_subclass,
    make_importable_path,
)

T = TypeVar("T")
Tstr = TypeVar("Tstr", bound=str)


def test_type_compat_identical():
    assert is_compatible_type(int, int)
    assert is_compatible_type(str, str)


def test_type_compat_subclass():
    assert is_compatible_type(MatrixRelationshipSet, RelationshipSet)


def test_type_compat_assignable():
    assert is_compatible_type(int, float)


def test_type_raw_compat_with_generic():
    assert is_compatible_type(list, list[int])
    assert not is_compatible_type(set, list[int])


def test_type_compat_protocol():
    assert is_compatible_type(list, Sequence)
    assert is_compatible_type(list, typing.Sequence)
    assert not is_compatible_type(set, Sequence)
    assert not is_compatible_type(set, typing.Sequence)
    assert is_compatible_type(set, Iterable)


def test_type_compat_protocol_generic():
    assert is_compatible_type(list, Sequence[int])
    assert is_compatible_type(list, typing.Sequence[int])


def test_type_compat_generics_with_protocol():
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", r"cannot type-check generic", TypecheckWarning)
        assert is_compatible_type(list[int], Sequence[int])


def test_type_incompat_generics():
    with warns(TypecheckWarning):
        assert is_compatible_type(list[int], list[str])
    with warns(TypecheckWarning):
        assert is_compatible_type(list[int], Sequence[str])


def test_data_compat_basic():
    assert is_compatible_data(72, int)
    assert is_compatible_data("hello", str)
    assert not is_compatible_data(72, str)


def test_data_compat_float_assignabile():
    assert is_compatible_data(72, float)


def test_data_compat_generic():
    assert is_compatible_data(["foo"], list[str])
    # this is compatible because we can't check generics
    # with warns(TypecheckWarning):
    assert is_compatible_data([72], list[str])


def test_numpy_typecheck():
    assert is_compatible_data(np.arange(10, dtype="i8"), NDArray[np.int64])
    assert is_compatible_data(np.arange(10, dtype="i4"), NDArray[np.int32])
    # assert is_compatible_data(np.arange(10), ArrayLike)
    assert is_compatible_data(np.arange(10), NDArray[np.integer])
    # numpy types can be checked
    assert not is_compatible_data(np.arange(10), NDArray[np.float64])


def test_numpy_scalar_typecheck():
    assert is_compatible_data(np.int32(4270), np.integer[Any])


def test_numpy_scalar_typecheck2():
    assert is_compatible_data(np.int32(4270), np.integer[Any] | int)


def test_compatible_any():
    assert is_compatible_data(50, Any)


def test_compatible_type_any():
    assert is_compatible_type(int, Any)


@mark.skip("broke with NumPy 2.4")
def test_pandas_typecheck():
    assert is_compatible_data(pd.Series(["a", "b"]), ArrayLike)


def test_compat_with_typevar():
    assert is_compatible_data(100, T)


def test_not_compat_with_typevar():
    assert not is_compatible_data(100, Tstr)


def test_importable_string_none():
    assert make_importable_path(None) == "None"


def test_importable_string_str():
    assert make_importable_path(str) == "str"


def test_importable_string_generic():
    assert make_importable_path(list[str]) == "list"


def test_importable_string_class():
    assert make_importable_path(UUID) == "uuid.UUID"


def test_importable_string_function():
    from lenskit.config import configure

    path = make_importable_path(configure)
    assert path == "lenskit.config.configure"

    func = import_path_string(path)
    assert func is configure


def test_importable_string_private_module():
    from lenskit.pipeline import Pipeline

    path = make_importable_path(Pipeline)
    assert path == "lenskit.pipeline.Pipeline"

    cls = import_path_string(path)
    assert cls is Pipeline


def test_importable_string_private_function():
    from lenskit.logging import stdout_console

    path = make_importable_path(stdout_console)
    assert path == "lenskit.logging.stdout_console"

    func = import_path_string(path)
    assert func is stdout_console


def test_parse_string_None():
    assert import_path_string("None") == NoneType


def test_parse_string_int():
    assert import_path_string("int") is int


def test_parse_string_class():
    assert import_path_string("pathlib.Path") is Path


def test_parse_string_mod_class():
    assert import_path_string("pathlib:Path") is Path


def test_is_not_instance():
    assert not is_instance_or_subclass(10, str)


def test_is_not_subclass():
    assert not is_instance_or_subclass(int, str)


def test_is_instance():
    assert is_instance_or_subclass("foo", str)


def test_is_instance_proto():
    assert is_instance_or_subclass([], Sequence)
    assert not is_instance_or_subclass(10, Sequence)


def test_is_subclass_proto():
    assert is_instance_or_subclass(list, Sequence)


def test_query_subtype():
    assert is_compatible_type(RecQuery, QueryInput)


def test_query_valid():
    query = RecQuery(user_id=47)
    assert is_compatible_data(query, RecQuery)
    assert is_compatible_data(query, QueryInput)
