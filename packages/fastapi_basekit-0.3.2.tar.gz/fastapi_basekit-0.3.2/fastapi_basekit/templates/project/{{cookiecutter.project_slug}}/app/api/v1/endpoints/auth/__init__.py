from app.api.v1.endpoints.auth.auth import router as auth_router

__all__ = ["auth_router"]
