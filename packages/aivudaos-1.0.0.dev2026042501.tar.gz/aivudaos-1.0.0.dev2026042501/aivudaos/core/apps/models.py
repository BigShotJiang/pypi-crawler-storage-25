from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional

UI_MOUNT_TYPE_QIANKUN = "qiankun"


@dataclass
class AppManifest:
    app_id: str
    name: str
    description: str
    version: str
    run: Dict[str, Any]
    icon: Optional[str] = None
    pre_install: Optional[str] = None
    pre_uninstall: Optional[str] = None
    update_this_version: Optional[str] = None
    ui_index_path: str = ""
    ui_mount_type: str = ""
    caddyfile_config_path: str = ""
    default_config_path: str = ""
    config_schema_path: str = ""
    default_config: Dict[str, Any] = field(default_factory=dict)
    config_schema: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, app_id: str, raw: Dict[str, Any]) -> AppManifest:
        ui_mount_type = str(raw.get("ui_mount_type") or "").strip()
        if ui_mount_type and ui_mount_type != UI_MOUNT_TYPE_QIANKUN:
            raise ValueError(
                f"manifest.ui_mount_type must be '{UI_MOUNT_TYPE_QIANKUN}' when set"
            )

        return cls(
            app_id=app_id,
            name=raw.get("name", app_id),
            description=raw.get("description", ""),
            version=raw.get("version", "0.0.0"),
            run=raw.get("run", {}),
            icon=raw.get("icon"),
            pre_install=raw.get("pre_install"),
            pre_uninstall=raw.get("pre_uninstall"),
            update_this_version=raw.get("update_this_version"),
            ui_index_path=str(raw.get("ui_index_path") or ""),
            ui_mount_type=ui_mount_type,
            caddyfile_config_path=str(raw.get("caddyfile_config_path") or ""),
            default_config_path=str(raw.get("default_config_path") or ""),
            config_schema_path=str(raw.get("config_schema_path") or ""),
            default_config=raw.get("default_config") or {},
            config_schema=raw.get("config_schema") or {},
        )

    def is_panelhub_mountable(self, has_builtin_ui: bool) -> bool:
        return bool(has_builtin_ui) and self.ui_mount_type == UI_MOUNT_TYPE_QIANKUN

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "app_id": self.app_id,
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "run": self.run,
            "default_config_path": self.default_config_path,
            "config_schema_path": self.config_schema_path,
            "default_config": self.default_config,
            "config_schema": self.config_schema,
        }
        if self.pre_install is not None:
            d["pre_install"] = self.pre_install
        if self.icon is not None:
            d["icon"] = self.icon
        if self.pre_uninstall is not None:
            d["pre_uninstall"] = self.pre_uninstall
        if self.update_this_version is not None:
            d["update_this_version"] = self.update_this_version
        if self.ui_index_path:
            d["ui_index_path"] = self.ui_index_path
        if self.ui_mount_type:
            d["ui_mount_type"] = self.ui_mount_type
        if self.caddyfile_config_path:
            d["caddyfile_config_path"] = self.caddyfile_config_path
        return d


@dataclass
class InstalledVersion:
    app_id: str
    version: str
    install_path: str
    status: str
    installed_at: int


@dataclass
class AppRuntimeState:
    app_id: str
    running: bool
    autostart: bool
    pid: Optional[int]
    last_started_at: Optional[int]
    last_stopped_at: Optional[int]
