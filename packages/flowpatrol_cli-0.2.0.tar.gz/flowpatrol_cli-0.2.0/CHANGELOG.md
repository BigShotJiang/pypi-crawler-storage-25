# Changelog

## [0.2.0](https://github.com/flowpatrol/vibecheck/compare/cli-python/v0.1.0...cli-python/v0.2.0) (2026-04-06)


### Features

* add Python CLI, publish workflows, and automated secret setup ([ca7fa0c](https://github.com/flowpatrol/vibecheck/commit/ca7fa0c860cdd319a3665ff264d538f8e370d1e8))
* **fort:** add CLI and GitHub Action marketing pages, docs, and blog content ([c57998a](https://github.com/flowpatrol/vibecheck/commit/c57998a9854f86ba4596fa4cd452f9685ca91301))
