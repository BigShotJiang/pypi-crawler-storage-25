from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from click.testing import CliRunner

from flowpatrol_cli.cli import main

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

SCAN_PENDING = {
    "id": "scan-abc-123",
    "status": "pending",
    "target_url": "https://example.com",
    "config": {"scan_mode": "standard"},
    "created_at": "2024-01-01T00:00:00Z",
}

SCAN_COMPLETE = {
    **SCAN_PENDING,
    "status": "complete",
    "duration_seconds": 42,
}

REPORT = {
    "scan_id": "scan-abc-123",
    "target_url": "https://example.com",
    "created_at": "2024-01-01T00:00:00Z",
    "duration_seconds": 42,
    "summary": {"total": 1, "critical": 1, "high": 0, "medium": 0, "low": 0, "info": 0},
    "findings": [
        {
            "severity": "critical",
            "type": "SQL Injection",
            "title": "SQL injection in login",
            "description": "Vulnerable login endpoint.",
            "endpoint": "POST /api/login",
            "evidence": "' OR '1'='1",
            "remediation": "Use parameterized queries.",
            "confirmed": True,
        }
    ],
}

CLEAN_REPORT = {
    **REPORT,
    "summary": {"total": 0, "critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0},
    "findings": [],
}


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture()
def tmp_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    config_dir = tmp_path / ".config" / "flowpatrol"
    config_file = config_dir / "config.json"
    monkeypatch.setattr("flowpatrol_cli.config._CONFIG_DIR", config_dir)
    monkeypatch.setattr("flowpatrol_cli.config.CONFIG_FILE", config_file)
    monkeypatch.setattr("flowpatrol_cli.cli.CONFIG_FILE", config_file)
    return config_file


# ---------------------------------------------------------------------------
# auth set-key
# ---------------------------------------------------------------------------


def test_auth_set_key_saves_key(runner: CliRunner, tmp_config: Path) -> None:
    result = runner.invoke(main, ["auth", "set-key", "fp_live_test123"])
    assert result.exit_code == 0
    assert "API key saved" in result.output
    data = json.loads(tmp_config.read_text())
    assert data["apiKey"] == "fp_live_test123"


def test_auth_set_key_rejects_empty(runner: CliRunner, tmp_config: Path) -> None:
    result = runner.invoke(main, ["auth", "set-key", "   "])
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# auth whoami
# ---------------------------------------------------------------------------


def test_auth_whoami_shows_redacted_key(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(
        json.dumps({"apiKey": "fp_live_abc123xyz", "apiUrl": "https://api.example.com"})
    )
    result = runner.invoke(main, ["auth", "whoami"])
    assert result.exit_code == 0
    assert "fp_live_abc123xyz" not in result.output
    assert "https://api.example.com" in result.output


def test_auth_whoami_no_key_exits_2(runner: CliRunner, tmp_config: Path) -> None:
    result = runner.invoke(main, ["auth", "whoami"])
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# surface
# ---------------------------------------------------------------------------


def _mock_client_for_scan(scan_result: dict, report_result: dict) -> MagicMock:
    """Build a mock ApiClient context manager that returns given scan and report."""
    client = AsyncMock()
    client.create_scan = AsyncMock(return_value=scan_result)
    client.get_scan = AsyncMock(return_value=scan_result)
    client.get_report = AsyncMock(return_value=report_result)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)
    return client


def test_surface_exits_1_on_critical_findings(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    mock_client = _mock_client_for_scan(SCAN_COMPLETE, REPORT)
    with patch("flowpatrol_cli.cli.ApiClient", return_value=mock_client):
        result = runner.invoke(main, ["surface", "https://example.com"])
    assert result.exit_code == 1


def test_surface_exits_0_on_clean(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    mock_client = _mock_client_for_scan(SCAN_COMPLETE, CLEAN_REPORT)
    with patch("flowpatrol_cli.cli.ApiClient", return_value=mock_client):
        result = runner.invoke(main, ["surface", "https://example.com"])
    assert result.exit_code == 0


def test_surface_rejects_invalid_url(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test"}))
    result = runner.invoke(main, ["surface", "not-a-url"])
    assert result.exit_code == 2


def test_surface_no_api_key_exits_2(runner: CliRunner, tmp_config: Path) -> None:
    result = runner.invoke(main, ["surface", "https://example.com"])
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# scan
# ---------------------------------------------------------------------------


def test_scan_no_wait_exits_0(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    mock_client = _mock_client_for_scan(SCAN_PENDING, REPORT)
    with patch("flowpatrol_cli.cli.ApiClient", return_value=mock_client):
        result = runner.invoke(main, ["scan", "https://example.com", "--no-wait"])
    assert result.exit_code == 0
    assert "scan-abc-123" in result.output


def test_scan_no_wait_json_format(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    mock_client = _mock_client_for_scan(SCAN_PENDING, REPORT)
    with patch("flowpatrol_cli.cli.ApiClient", return_value=mock_client):
        result = runner.invoke(main, ["scan", "https://example.com", "--no-wait", "--format", "json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["id"] == "scan-abc-123"


def test_scan_exits_1_on_critical(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    mock_client = _mock_client_for_scan(SCAN_COMPLETE, REPORT)
    with patch("flowpatrol_cli.cli.ApiClient", return_value=mock_client):
        result = runner.invoke(main, ["scan", "https://example.com"])
    assert result.exit_code == 1


def test_scan_invalid_mode_exits_2(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test"}))
    result = runner.invoke(main, ["scan", "https://example.com", "--mode", "turbo"])
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# report
# ---------------------------------------------------------------------------


def test_report_human_output(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    client = AsyncMock()
    client.get_report = AsyncMock(return_value=REPORT)
    client.export_sarif = AsyncMock(side_effect=Exception("not available"))
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["report", "scan-abc-123"])
    assert result.exit_code == 1  # critical finding
    assert "SQL injection in login" in result.output


def test_report_json_format(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    client = AsyncMock()
    client.get_report = AsyncMock(return_value=REPORT)
    client.export_sarif = AsyncMock(side_effect=Exception("not available"))
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["report", "scan-abc-123", "--format", "json"])
    assert result.exit_code == 1
    data = json.loads(result.output)
    assert data["scan_id"] == "scan-abc-123"


def test_report_severity_filter(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    client = AsyncMock()
    client.get_report = AsyncMock(return_value=REPORT)
    client.export_sarif = AsyncMock(side_effect=Exception("not available"))
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    # Filter to only "high" — should get clean exit since no high findings
    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["report", "scan-abc-123", "--severity", "high"])
    assert result.exit_code == 0


def test_report_invalid_severity_exits_2(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test"}))

    client = AsyncMock()
    client.get_report = AsyncMock(return_value=REPORT)
    client.export_sarif = AsyncMock(side_effect=Exception())
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["report", "scan-abc-123", "--severity", "extreme"])
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


def test_status_complete_exits_0(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=SCAN_COMPLETE)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["status", "scan-abc-123"])
    assert result.exit_code == 0
    assert "complete" in result.output


def test_status_pending_exits_1(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=SCAN_PENDING)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["status", "scan-abc-123"])
    assert result.exit_code == 1


def test_status_failed_exits_2(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    failed_scan = {**SCAN_COMPLETE, "status": "failed"}
    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=failed_scan)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["status", "scan-abc-123"])
    assert result.exit_code == 2


def test_status_quiet_prints_only_status(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test", "apiUrl": "https://api.example.com"}))

    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=SCAN_COMPLETE)
    client.__aenter__ = AsyncMock(return_value=client)
    client.__aexit__ = AsyncMock(return_value=None)

    with patch("flowpatrol_cli.cli.ApiClient", return_value=client):
        result = runner.invoke(main, ["-q", "status", "scan-abc-123"])
    assert result.exit_code == 0
    assert result.output.strip() == "complete"


# ---------------------------------------------------------------------------
# Global options
# ---------------------------------------------------------------------------


def test_version_flag() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_invalid_format_exits_2(runner: CliRunner, tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text(json.dumps({"apiKey": "fp_test"}))
    result = runner.invoke(main, ["--format", "xml", "surface", "https://example.com"])
    assert result.exit_code == 2
