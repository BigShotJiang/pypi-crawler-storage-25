from __future__ import annotations

import json
from unittest.mock import patch

from flowpatrol_cli.formatters.human import (
    format_report,
    format_scan_started,
    format_status,
    format_whoami,
)
from flowpatrol_cli.formatters.json_fmt import format_report_json, format_scan_json
from flowpatrol_cli.formatters.sarif import format_report_sarif, report_to_sarif

# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

SCAN = {
    "id": "scan-abc-123",
    "status": "complete",
    "target_url": "https://example.com",
    "config": {"scan_mode": "standard"},
    "created_at": "2024-01-01T00:00:00Z",
    "duration_seconds": 42,
}

FINDING = {
    "severity": "critical",
    "type": "SQL Injection",
    "title": "SQL injection in login",
    "description": "The login endpoint is vulnerable to SQL injection.",
    "endpoint": "POST /api/login",
    "evidence": "payload: ' OR '1'='1",
    "remediation": "Use parameterized queries.",
    "owasp": "OWASP A03:2021",
    "cwe": "CWE-89",
    "confirmed": True,
}

REPORT = {
    "scan_id": "scan-abc-123",
    "target_url": "https://example.com",
    "created_at": "2024-01-01T00:00:00Z",
    "duration_seconds": 42,
    "summary": {"total": 1, "critical": 1, "high": 0, "medium": 0, "low": 0, "info": 0},
    "findings": [FINDING],
}

EMPTY_REPORT = {
    "scan_id": "scan-abc-123",
    "target_url": "https://example.com",
    "created_at": "2024-01-01T00:00:00Z",
    "summary": {"total": 0, "critical": 0, "high": 0, "medium": 0, "low": 0, "info": 0},
    "findings": [],
}


# ---------------------------------------------------------------------------
# Human formatter tests
# ---------------------------------------------------------------------------


def test_format_report_contains_title() -> None:
    # Disable TTY so ANSI codes are stripped
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_report(REPORT, SCAN)
    assert "Flowpatrol" in output
    assert "https://example.com" in output


def test_format_report_contains_finding_title() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_report(REPORT, SCAN)
    assert "SQL injection in login" in output
    assert "POST /api/login" in output
    assert "Use parameterized queries." in output


def test_format_report_contains_refs() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_report(REPORT, SCAN)
    assert "OWASP A03:2021" in output
    assert "CWE-89" in output


def test_format_report_empty_shows_clean() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_report(EMPTY_REPORT)
    assert "No findings" in output


def test_format_report_summary_line() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_report(REPORT, SCAN)
    assert "1 critical" in output
    assert "Duration: 42s" in output
    assert "scan-abc-123" in output


def test_format_scan_started() -> None:
    pending_scan = {**SCAN, "status": "pending"}
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_scan_started(pending_scan)
    assert "scan-abc-123" in output
    assert "standard" in output
    assert "flowpatrol status" in output


def test_format_status_complete() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_status(SCAN)
    assert "complete" in output
    assert "scan-abc-123" in output


def test_format_whoami_redacts_key() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_whoami("fp_live_abc123xyz", "https://api.example.com")
    assert "fp_" in output
    # The full key should not appear
    assert "fp_live_abc123xyz" not in output
    assert "https://api.example.com" in output


def test_format_whoami_short_key() -> None:
    with patch("sys.stdout") as mock_stdout:
        mock_stdout.isatty.return_value = False
        output = format_whoami("short", "https://api.example.com")
    # Short key gets fully redacted
    assert "short" not in output


# ---------------------------------------------------------------------------
# JSON formatter tests
# ---------------------------------------------------------------------------


def test_format_report_json_is_valid_json() -> None:
    output = format_report_json(REPORT, SCAN)
    data = json.loads(output)
    assert data["scan_id"] == "scan-abc-123"
    assert data["status"] == "complete"
    assert data["mode"] == "standard"
    assert len(data["findings"]) == 1


def test_format_report_json_without_scan() -> None:
    output = format_report_json(REPORT)
    data = json.loads(output)
    assert data["status"] == "complete"
    assert data["mode"] is None


def test_format_scan_json() -> None:
    output = format_scan_json(SCAN)
    data = json.loads(output)
    assert data["id"] == "scan-abc-123"


# ---------------------------------------------------------------------------
# SARIF formatter tests
# ---------------------------------------------------------------------------


def test_sarif_structure() -> None:
    sarif = report_to_sarif(REPORT)
    assert sarif["version"] == "2.1.0"
    assert len(sarif["runs"]) == 1
    run = sarif["runs"][0]
    assert run["tool"]["driver"]["name"] == "Flowpatrol"
    assert len(run["results"]) == 1
    assert len(run["tool"]["driver"]["rules"]) == 1


def test_sarif_rule_id_derived_from_type() -> None:
    sarif = report_to_sarif(REPORT)
    rule = sarif["runs"][0]["tool"]["driver"]["rules"][0]
    assert rule["id"] == "FP-SQL-INJECTION"


def test_sarif_level_mapping() -> None:
    sarif = report_to_sarif(REPORT)
    result = sarif["runs"][0]["results"][0]
    assert result["level"] == "error"  # critical → error


def test_sarif_tags_included() -> None:
    sarif = report_to_sarif(REPORT)
    rule = sarif["runs"][0]["tool"]["driver"]["rules"][0]
    assert "OWASP A03:2021" in rule["properties"]["tags"]
    assert "CWE-89" in rule["properties"]["tags"]


def test_sarif_deduplicates_rules() -> None:
    """Two findings of the same type should produce one rule."""
    report_with_two = {
        **REPORT,
        "findings": [FINDING, {**FINDING, "title": "Another SQL injection"}],
        "summary": {**REPORT["summary"], "total": 2, "critical": 2},
    }
    sarif = report_to_sarif(report_with_two)
    assert len(sarif["runs"][0]["tool"]["driver"]["rules"]) == 1
    assert len(sarif["runs"][0]["results"]) == 2


def test_sarif_url_root_has_trailing_slash() -> None:
    sarif = report_to_sarif(REPORT)
    uri_root = sarif["runs"][0]["originalUriBaseIds"]["URLROOT"]["uri"]
    assert uri_root.endswith("/")


def test_format_report_sarif_is_valid_json() -> None:
    output = format_report_sarif(REPORT)
    data = json.loads(output)
    assert data["version"] == "2.1.0"
