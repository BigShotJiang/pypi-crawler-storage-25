from __future__ import annotations

from unittest.mock import AsyncMock, call

import pytest

from flowpatrol_cli.poll import poll_until_done

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_scan(status: str) -> dict:
    return {
        "id": "scan-abc",
        "status": status,
        "target_url": "https://example.com",
        "config": {"scan_mode": "standard"},
        "created_at": "2024-01-01T00:00:00Z",
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_poll_returns_immediately_when_complete() -> None:
    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=_make_scan("complete"))

    result = await poll_until_done(client, "scan-abc", timeout=30.0, verbose=False)
    assert result["status"] == "complete"
    client.get_scan.assert_called_once_with("scan-abc")


@pytest.mark.asyncio
async def test_poll_returns_on_failed() -> None:
    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=_make_scan("failed"))

    result = await poll_until_done(client, "scan-abc", timeout=30.0, verbose=False)
    assert result["status"] == "failed"


@pytest.mark.asyncio
async def test_poll_returns_on_cancelled() -> None:
    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=_make_scan("cancelled"))

    result = await poll_until_done(client, "scan-abc", timeout=30.0, verbose=False)
    assert result["status"] == "cancelled"


@pytest.mark.asyncio
async def test_poll_waits_through_intermediate_statuses(monkeypatch: pytest.MonkeyPatch) -> None:
    # Patch asyncio.sleep to avoid actual waiting
    sleep_calls: list[float] = []

    async def fake_sleep(duration: float) -> None:
        sleep_calls.append(duration)

    monkeypatch.setattr("flowpatrol_cli.poll.asyncio.sleep", fake_sleep)

    client = AsyncMock()
    client.get_scan = AsyncMock(
        side_effect=[
            _make_scan("pending"),
            _make_scan("recon"),
            _make_scan("attacking"),
            _make_scan("complete"),
        ]
    )

    result = await poll_until_done(client, "scan-abc", timeout=60.0, verbose=False)
    assert result["status"] == "complete"
    assert client.get_scan.call_count == 4
    # Should have slept 3 times (before polls 2, 3, 4)
    assert len(sleep_calls) == 3


@pytest.mark.asyncio
async def test_poll_raises_on_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_sleep(_: float) -> None:
        pass

    monkeypatch.setattr("flowpatrol_cli.poll.asyncio.sleep", fake_sleep)

    # Simulate time advancing past the deadline after the first check
    call_count = 0
    original_monotonic = __import__("time").monotonic
    start = original_monotonic()

    def fake_monotonic() -> float:
        nonlocal call_count
        call_count += 1
        # First call sets the deadline, second call triggers the timeout
        if call_count <= 2:
            return start
        return start + 1000.0  # Way past any timeout

    monkeypatch.setattr("flowpatrol_cli.poll.time.monotonic", fake_monotonic)

    client = AsyncMock()
    client.get_scan = AsyncMock(return_value=_make_scan("recon"))

    with pytest.raises(RuntimeError, match="Timed out"):
        await poll_until_done(client, "scan-abc", timeout=1.0, verbose=False)
