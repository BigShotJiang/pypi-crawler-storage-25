from __future__ import annotations

import json

import httpx
import pytest

from flowpatrol_cli.api import ApiClient, ApiError

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SCAN_FIXTURE = {
    "id": "scan-abc-123",
    "status": "complete",
    "target_url": "https://example.com",
    "config": {"scan_mode": "standard"},
    "created_at": "2024-01-01T00:00:00Z",
    "duration_seconds": 42,
}

REPORT_FIXTURE = {
    "scan_id": "scan-abc-123",
    "target_url": "https://example.com",
    "created_at": "2024-01-01T00:00:00Z",
    "duration_seconds": 42,
    "summary": {"total": 1, "critical": 1, "high": 0, "medium": 0, "low": 0, "info": 0},
    "findings": [
        {
            "severity": "critical",
            "type": "Exposed Secret",
            "title": "API key in source",
            "description": "An API key was found.",
            "endpoint": "GET /",
            "evidence": "found in bundle.js",
            "remediation": "Rotate the key.",
            "confirmed": True,
        }
    ],
}


def _make_transport(routes: dict[str, tuple[int, dict]]) -> httpx.MockTransport:
    """Build an httpx mock transport from a {path: (status, body)} mapping.

    Routes are matched against path alone, or path?query if a query string is present.
    httpx encodes query params, so we compare against the raw URL string after the host.
    """

    def handler(request: httpx.Request) -> httpx.Response:
        # Build the path+query string the same way the route keys are specified
        raw = request.url.raw_path.decode()
        if raw in routes:
            status, body = routes[raw]
            return httpx.Response(status, json=body)
        # Fallback: match on path only
        path = request.url.path
        if path in routes:
            status, body = routes[path]
            return httpx.Response(status, json=body)
        return httpx.Response(404, json={"detail": "not found"})

    return httpx.MockTransport(handler)


@pytest.fixture()
def client() -> ApiClient:
    transport = _make_transport(
        {
            "/scans": (201, SCAN_FIXTURE),
            "/scans/scan-abc-123": (200, SCAN_FIXTURE),
            "/reports/scan-abc-123": (200, REPORT_FIXTURE),
            "/reports/scan-abc-123/export?format=sarif": (
                200,
                {"$schema": "...", "version": "2.1.0", "runs": []},
            ),
        }
    )
    c = ApiClient(api_key="fp_test", api_url="https://api.example.com")
    c._client = httpx.AsyncClient(transport=transport, base_url="https://api.example.com")
    return c


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_scan(client: ApiClient) -> None:
    scan = await client.create_scan("https://example.com", "standard")
    assert scan["id"] == "scan-abc-123"
    assert scan["status"] == "complete"


@pytest.mark.asyncio
async def test_get_scan(client: ApiClient) -> None:
    scan = await client.get_scan("scan-abc-123")
    assert scan["id"] == "scan-abc-123"


@pytest.mark.asyncio
async def test_get_report(client: ApiClient) -> None:
    report = await client.get_report("scan-abc-123")
    assert report["scan_id"] == "scan-abc-123"
    assert len(report["findings"]) == 1
    assert report["findings"][0]["severity"] == "critical"


@pytest.mark.asyncio
async def test_export_sarif(client: ApiClient) -> None:
    sarif = await client.export_sarif("scan-abc-123")
    assert sarif["version"] == "2.1.0"


@pytest.mark.asyncio
async def test_api_error_on_404(client: ApiClient) -> None:
    with pytest.raises(ApiError) as exc_info:
        await client.get_scan("nonexistent-id")
    assert exc_info.value.status == 404


@pytest.mark.asyncio
async def test_api_error_on_401() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"detail": "Unauthorized"})

    c = ApiClient(api_key="bad_key", api_url="https://api.example.com")
    c._client = httpx.AsyncClient(
        transport=httpx.MockTransport(handler), base_url="https://api.example.com"
    )
    with pytest.raises(ApiError) as exc_info:
        await c.get_scan("any-id")
    assert exc_info.value.status == 401
    assert "Unauthorized" in exc_info.value.detail


@pytest.mark.asyncio
async def test_network_error_raises_runtime_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused")

    c = ApiClient(api_key="fp_test", api_url="https://api.example.com")
    c._client = httpx.AsyncClient(
        transport=httpx.MockTransport(handler), base_url="https://api.example.com"
    )
    with pytest.raises(RuntimeError, match="Network error"):
        await c.get_scan("any-id")
