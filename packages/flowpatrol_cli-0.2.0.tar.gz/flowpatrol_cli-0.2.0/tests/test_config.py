from __future__ import annotations

import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from flowpatrol_cli.config import (
    DEFAULT_API_URL,
    get_config,
    require_api_key,
    update_config,
    write_config,
)


@pytest.fixture()
def tmp_config(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """Redirect config file to a temporary directory."""
    config_dir = tmp_path / ".config" / "flowpatrol"
    config_file = config_dir / "config.json"
    monkeypatch.setattr("flowpatrol_cli.config._CONFIG_DIR", config_dir)
    monkeypatch.setattr("flowpatrol_cli.config.CONFIG_FILE", config_file)
    return config_file


def test_write_and_read_config(tmp_config: Path) -> None:
    write_config({"apiKey": "fp_test_123", "apiUrl": "https://example.com"})
    assert tmp_config.exists()
    data = json.loads(tmp_config.read_text())
    assert data["apiKey"] == "fp_test_123"
    assert data["apiUrl"] == "https://example.com"


def test_update_config_merges(tmp_config: Path) -> None:
    write_config({"apiKey": "old_key", "apiUrl": "https://old.example.com"})
    update_config({"apiKey": "new_key"})
    data = json.loads(tmp_config.read_text())
    assert data["apiKey"] == "new_key"
    assert data["apiUrl"] == "https://old.example.com"


def test_get_config_defaults_when_no_file(tmp_config: Path) -> None:
    config = get_config()
    assert config["apiKey"] == ""
    assert config["apiUrl"] == DEFAULT_API_URL


def test_get_config_reads_file(tmp_config: Path) -> None:
    write_config({"apiKey": "fp_from_file", "apiUrl": "https://file.example.com"})
    config = get_config()
    assert config["apiKey"] == "fp_from_file"
    assert config["apiUrl"] == "https://file.example.com"


def test_env_vars_override_file(tmp_config: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    write_config({"apiKey": "fp_from_file", "apiUrl": "https://file.example.com"})
    monkeypatch.setenv("FLOWPATROL_API_KEY", "fp_from_env")
    monkeypatch.setenv("FLOWPATROL_API_URL", "https://env.example.com")
    config = get_config()
    assert config["apiKey"] == "fp_from_env"
    assert config["apiUrl"] == "https://env.example.com"


def test_require_api_key_raises_when_missing(tmp_config: Path) -> None:
    with pytest.raises(RuntimeError, match="No API key"):
        require_api_key()


def test_require_api_key_returns_key(tmp_config: Path) -> None:
    write_config({"apiKey": "fp_valid_key"})
    key = require_api_key()
    assert key == "fp_valid_key"


def test_get_config_handles_corrupt_file(tmp_config: Path) -> None:
    tmp_config.parent.mkdir(parents=True, exist_ok=True)
    tmp_config.write_text("not valid json")
    config = get_config()
    assert config["apiKey"] == ""
    assert config["apiUrl"] == DEFAULT_API_URL
