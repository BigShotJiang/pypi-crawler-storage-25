from __future__ import annotations

import asyncio
import random
import sys
import time

from flowpatrol_cli.api import ApiClient
from flowpatrol_cli.types import TERMINAL_STATUSES, Scan


def _print_progress(scan: Scan) -> None:
    status = scan["status"].capitalize()
    line = f"  ... {status:<12} {scan['id']}"
    if sys.stdout.isatty():
        sys.stdout.write(f"\r{line}")
        sys.stdout.flush()
    else:
        print(line)


def _clear_progress() -> None:
    if sys.stdout.isatty():
        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.flush()


async def poll_until_done(
    client: ApiClient,
    scan_id: str,
    *,
    timeout: float = 900.0,
    verbose: bool = True,
) -> Scan:
    """Poll a scan until it reaches a terminal status or the timeout elapses.

    Uses exponential backoff with 10% jitter: starts at 2s, caps at 15s.

    Raises RuntimeError if the timeout is exceeded. The caller should inspect
    scan.status when the scan ends in failed/cancelled.
    """
    deadline = time.monotonic() + timeout
    interval = 2.0

    while True:
        scan: Scan = await client.get_scan(scan_id)

        if verbose:
            _print_progress(scan)

        if scan["status"] in TERMINAL_STATUSES:
            if verbose:
                _clear_progress()
            return scan

        if time.monotonic() >= deadline:
            if verbose:
                _clear_progress()
            raise RuntimeError(
                f"Timed out waiting for scan {scan_id} to complete "
                f"(status: {scan['status']}).\n"
                f"Check status later with: flowpatrol status {scan_id}"
            )

        # Exponential backoff with 10% jitter, capped at 15s
        jitter = interval * 0.1 * random.random()
        await asyncio.sleep(interval + jitter)
        interval = min(interval * 2, 15.0)
