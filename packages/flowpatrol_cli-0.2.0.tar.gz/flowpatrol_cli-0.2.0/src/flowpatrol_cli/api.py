from __future__ import annotations

from typing import Any

import httpx

from flowpatrol_cli.__init__ import __version__
from flowpatrol_cli.types import Report, Scan, ScanMode, SarifLog


class ApiError(Exception):
    """Raised when the Flowpatrol API returns a non-2xx response."""

    def __init__(self, status: int, detail: str, url: str) -> None:
        self.status = status
        self.detail = detail
        self.url = url
        super().__init__(f"API error {status}: {detail} ({url})")


class ApiClient:
    """Minimal async HTTP client wrapping the Flowpatrol REST API."""

    def __init__(self, api_key: str, api_url: str) -> None:
        self._api_key = api_key
        # Strip trailing slash so every path concat is uniform
        self._base_url = api_url.rstrip("/")
        self._client = httpx.AsyncClient(
            headers=self._base_headers(),
            timeout=30.0,
        )

    def _base_headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "User-Agent": f"flowpatrol-cli/{__version__}",
        }

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self._base_url}{path}"
        try:
            response = await self._client.request(method, url, **kwargs)
        except httpx.RequestError as exc:
            raise RuntimeError(
                f"Network error reaching {self._base_url} — is the API URL correct?\n{exc}"
            ) from exc

        if response.is_error:
            detail = ""
            try:
                body = response.json()
                if isinstance(body, dict):
                    detail = (
                        body.get("detail")
                        or body.get("error")
                        or response.text
                    )
                    if not isinstance(detail, str):
                        detail = response.text
            except Exception:
                detail = response.text
            raise ApiError(response.status_code, detail or response.reason_phrase, url)

        return response.json()

    async def create_scan(self, target_url: str, mode: ScanMode) -> Scan:
        """Create a new scan and return the initial scan object (status will be 'pending')."""
        return await self._request(
            "POST",
            "/scans",
            json={"target_url": target_url, "config": {"scan_mode": mode}},
        )

    async def get_scan(self, scan_id: str) -> Scan:
        """Fetch the current status and metadata of a scan."""
        return await self._request("GET", f"/scans/{scan_id}")

    async def get_report(self, scan_id: str) -> Report:
        """Fetch the full report for a completed scan."""
        return await self._request("GET", f"/reports/{scan_id}")

    async def export_sarif(self, scan_id: str) -> SarifLog:
        """Export the report in SARIF format via the server-side export endpoint."""
        return await self._request("GET", f"/reports/{scan_id}/export?format=sarif")

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "ApiClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()
