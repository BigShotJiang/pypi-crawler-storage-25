from __future__ import annotations

import json
import sys
from typing import Optional
from urllib.parse import urlparse

import click

from flowpatrol_cli.__init__ import __version__
from flowpatrol_cli.api import ApiClient, ApiError
from flowpatrol_cli.config import CONFIG_FILE, get_config, require_api_key, update_config
from flowpatrol_cli.formatters.human import (
    format_report,
    format_scan_started,
    format_status,
    format_whoami,
)
from flowpatrol_cli.formatters.json_fmt import format_report_json, format_scan_json
from flowpatrol_cli.formatters.sarif import format_report_sarif
from flowpatrol_cli.poll import poll_until_done
from flowpatrol_cli.types import (
    FindingSeverity,
    OutputFormat,
    Report,
    Scan,
    ScanMode,
    SummaryDict,
    VALID_FORMATS,
    VALID_MODES,
    VALID_SEVERITIES,
)


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------


def _validate_url(url: str) -> None:
    try:
        result = urlparse(url)
        if result.scheme not in ("http", "https") or not result.netloc:
            raise ValueError
    except ValueError:
        click.echo(f'Invalid URL: "{url}"', err=True)
        sys.exit(2)


def _validate_format(fmt: str) -> OutputFormat:
    if fmt not in VALID_FORMATS:
        click.echo(f'Invalid format "{fmt}". Must be one of: human, json, sarif', err=True)
        sys.exit(2)
    return fmt  # type: ignore[return-value]


def _validate_mode(mode: str) -> ScanMode:
    if mode not in VALID_MODES:
        click.echo(f'Invalid mode "{mode}". Must be one of: surface, deep, quick, standard', err=True)
        sys.exit(2)
    return mode  # type: ignore[return-value]


def _resolve_mode(mode: str) -> ScanMode:
    aliases: dict[str, ScanMode] = {"quick": "surface", "standard": "deep", "lightweight": "surface"}
    if mode in aliases:
        click.echo(f"Warning: scan mode '{mode}' is deprecated. Use '{aliases[mode]}' instead.", err=True)
        return aliases[mode]
    return mode  # type: ignore[return-value]


def _has_critical_or_high(report: Report) -> bool:
    return report["summary"]["critical"] > 0 or report["summary"]["high"] > 0


def _parse_severity_filter(raw: Optional[str]) -> Optional[set[FindingSeverity]]:
    if not raw:
        return None
    parts = [s.strip().lower() for s in raw.split(",")]
    for p in parts:
        if p not in VALID_SEVERITIES:
            click.echo(
                f'Invalid severity "{p}". Must be one of: critical, high, medium, low, info',
                err=True,
            )
            sys.exit(2)
    return set(parts)  # type: ignore[return-value]


def _recalc_summary(findings: list, filter_set: set[FindingSeverity]) -> SummaryDict:
    filtered = [f for f in findings if f["severity"] in filter_set]
    return {
        "total": len(filtered),
        "critical": sum(1 for f in filtered if f["severity"] == "critical"),
        "high": sum(1 for f in filtered if f["severity"] == "high"),
        "medium": sum(1 for f in filtered if f["severity"] == "medium"),
        "low": sum(1 for f in filtered if f["severity"] == "low"),
        "info": sum(1 for f in filtered if f["severity"] == "info"),
    }


# ---------------------------------------------------------------------------
# Root group
# ---------------------------------------------------------------------------


@click.group()
@click.version_option(__version__, "-v", "--version")
@click.option("-q", "--quiet", is_flag=True, default=False, help="Suppress human output; rely on exit codes only.")
@click.option("-f", "--format", "fmt", default="human", metavar="FORMAT", help="Output format: human | json | sarif  [default: human]")
@click.option("--api-url", default=None, metavar="URL", help="Override the API base URL.")
@click.option("--api-key", "api_key_opt", default=None, metavar="KEY", help="Override the API key.")
@click.pass_context
def main(
    ctx: click.Context,
    quiet: bool,
    fmt: str,
    api_url: Optional[str],
    api_key_opt: Optional[str],
) -> None:
    """Flowpatrol CLI — run security scans from your terminal."""
    ctx.ensure_object(dict)
    ctx.obj["quiet"] = quiet
    ctx.obj["fmt"] = fmt
    ctx.obj["api_url_opt"] = api_url
    ctx.obj["api_key_opt"] = api_key_opt


# ---------------------------------------------------------------------------
# auth group
# ---------------------------------------------------------------------------


@main.group()
def auth() -> None:
    """Manage authentication credentials."""


@auth.command("set-key")
@click.argument("key")
def auth_set_key(key: str) -> None:
    """Store an API key in the local config file."""
    if not key.strip():
        click.echo("Error: API key cannot be empty.", err=True)
        sys.exit(2)
    update_config({"apiKey": key.strip()})
    click.echo(f"API key saved to {CONFIG_FILE}")


@auth.command("whoami")
@click.option("--verify", is_flag=True, default=False, help="Verify the key is accepted by the API.")
@click.pass_context
def auth_whoami(ctx: click.Context, verify: bool) -> None:
    """Show the currently configured API key and endpoint."""
    import asyncio

    config = get_config()
    api_key = ctx.obj.get("api_key_opt") or config["apiKey"]
    api_url = ctx.obj.get("api_url_opt") or config["apiUrl"]

    if not api_key:
        click.echo(
            "No API key configured.\n"
            "Run: flowpatrol auth set-key <key>\n"
            "Or set the FLOWPATROL_API_KEY environment variable.",
            err=True,
        )
        sys.exit(2)

    click.echo(format_whoami(api_key, api_url))

    if verify:
        async def _verify() -> None:
            async with ApiClient(api_key, api_url) as client:
                try:
                    await client.get_scan("__verify__")
                except ApiError as e:
                    if e.status == 404:
                        click.echo("  Key verified.")
                        return
                    if e.status in (401, 403):
                        click.echo("  Key rejected by the API (401/403).", err=True)
                        sys.exit(1)
                    click.echo(f"  Could not verify key: {e}", err=True)
                except Exception as e:
                    click.echo(f"  Could not verify key: {e}", err=True)

        asyncio.run(_verify())


# ---------------------------------------------------------------------------
# surface command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("url")
@click.option("-f", "--format", "fmt", default=None, metavar="FORMAT", help="Output format: human | json | sarif")
@click.option("--timeout", default=600, show_default=True, metavar="SECONDS", help="Maximum wait time in seconds.")
@click.pass_context
def surface(ctx: click.Context, url: str, fmt: Optional[str], timeout: int) -> None:
    """Run a Surface scan and wait for results."""
    import asyncio

    quiet: bool = ctx.obj["quiet"]
    format_: OutputFormat = _validate_format(fmt or ctx.obj["fmt"])
    _validate_url(url)

    config = get_config()
    api_key = ctx.obj.get("api_key_opt") or config["apiKey"]
    api_url = ctx.obj.get("api_url_opt") or config["apiUrl"]

    try:
        api_key = api_key or require_api_key()
    except RuntimeError as e:
        click.echo(str(e), err=True)
        sys.exit(2)

    async def _run() -> None:
        async with ApiClient(api_key, api_url) as client:
            try:
                scan: Scan = await client.create_scan(url, "surface")
            except Exception as e:
                click.echo(f"Failed to start surface scan: {e}", err=True)
                sys.exit(2)

            if not quiet:
                click.echo(f"Surface scan started — {scan['id']}", err=True)

            try:
                scan = await poll_until_done(
                    client,
                    scan["id"],
                    timeout=float(timeout),
                    verbose=not quiet and format_ == "human",
                )
            except RuntimeError as e:
                click.echo(str(e), err=True)
                sys.exit(2)

            if scan["status"] != "complete":
                if not quiet:
                    click.echo(format_status(scan))
                sys.exit(2)

            try:
                report: Report = await client.get_report(scan["id"])
            except Exception as e:
                click.echo(f"Failed to fetch report: {e}", err=True)
                sys.exit(2)

            _output_report(report, scan, format_, quiet)

        if _has_critical_or_high(report):
            sys.exit(1)

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# scan command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("url")
@click.option("-m", "--mode", default="deep", show_default=True, metavar="MODE", help="Scan mode: surface | deep (default: deep)")
@click.option("-f", "--format", "fmt", default=None, metavar="FORMAT", help="Output format: human | json | sarif")
@click.option("--no-wait", "no_wait", is_flag=True, default=False, help="Start the scan and return immediately without waiting.")
@click.option("--timeout", default=3600, show_default=True, metavar="SECONDS", help="Maximum wait time in seconds.")
@click.pass_context
def scan(
    ctx: click.Context,
    url: str,
    mode: str,
    fmt: Optional[str],
    no_wait: bool,
    timeout: int,
) -> None:
    """Run a security scan (waits for completion by default)."""
    import asyncio

    quiet: bool = ctx.obj["quiet"]
    format_: OutputFormat = _validate_format(fmt or ctx.obj["fmt"])
    scan_mode: ScanMode = _validate_mode(mode)
    scan_mode = _resolve_mode(scan_mode)
    _validate_url(url)

    config = get_config()
    api_key = ctx.obj.get("api_key_opt") or config["apiKey"]
    api_url = ctx.obj.get("api_url_opt") or config["apiUrl"]

    if not api_key:
        try:
            api_key = require_api_key()
        except RuntimeError as e:
            click.echo(str(e), err=True)
            sys.exit(2)

    report: Optional[Report] = None

    async def _run() -> None:
        nonlocal report
        async with ApiClient(api_key, api_url) as client:
            try:
                started_scan: Scan = await client.create_scan(url, scan_mode)
            except Exception as e:
                click.echo(f"Failed to start scan: {e}", err=True)
                sys.exit(2)

            # No-wait path: print scan info and exit
            if no_wait:
                if format_ == "json":
                    click.echo(format_scan_json(started_scan))
                elif not quiet:
                    click.echo(format_scan_started(started_scan))
                else:
                    click.echo(started_scan["id"])
                sys.exit(0)

            if not quiet:
                click.echo(f"Scan started — {started_scan['id']} ({scan_mode} mode)", err=True)

            try:
                finished_scan: Scan = await poll_until_done(
                    client,
                    started_scan["id"],
                    timeout=float(timeout),
                    verbose=not quiet and format_ == "human",
                )
            except RuntimeError as e:
                click.echo(str(e), err=True)
                sys.exit(2)

            if finished_scan["status"] != "complete":
                if not quiet:
                    click.echo(format_status(finished_scan))
                sys.exit(2)

            try:
                report = await client.get_report(finished_scan["id"])
            except Exception as e:
                click.echo(f"Failed to fetch report: {e}", err=True)
                sys.exit(2)

            _output_report(report, finished_scan, format_, quiet)

    asyncio.run(_run())

    if report is not None and _has_critical_or_high(report):
        sys.exit(1)


# ---------------------------------------------------------------------------
# report command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("scan_id")
@click.option("-f", "--format", "fmt", default=None, metavar="FORMAT", help="Output format: human | json | sarif")
@click.option("--severity", default=None, metavar="LEVELS", help="Filter by severity: critical,high,medium,low,info")
@click.pass_context
def report(ctx: click.Context, scan_id: str, fmt: Optional[str], severity: Optional[str]) -> None:
    """Fetch the report for a completed scan."""
    import asyncio

    quiet: bool = ctx.obj["quiet"]
    format_: OutputFormat = _validate_format(fmt or ctx.obj["fmt"])
    severity_filter = _parse_severity_filter(severity)

    config = get_config()
    api_key = ctx.obj.get("api_key_opt") or config["apiKey"]
    api_url = ctx.obj.get("api_url_opt") or config["apiUrl"]

    if not api_key:
        try:
            api_key = require_api_key()
        except RuntimeError as e:
            click.echo(str(e), err=True)
            sys.exit(2)

    fetched_report: Optional[Report] = None

    async def _run() -> None:
        nonlocal fetched_report
        async with ApiClient(api_key, api_url) as client:
            # For SARIF, try the server-side export endpoint first
            if format_ == "sarif":
                try:
                    sarif_data = await client.export_sarif(scan_id)
                    click.echo(json.dumps(sarif_data, indent=2))
                    sys.exit(0)
                except Exception:
                    pass  # Fall through to client-side SARIF conversion

            try:
                fetched_report = await client.get_report(scan_id)
            except Exception as e:
                click.echo(f"Failed to fetch report: {e}", err=True)
                sys.exit(2)

            # Apply severity filter if requested
            if severity_filter is not None:
                filtered_findings = [
                    f for f in fetched_report["findings"] if f["severity"] in severity_filter
                ]
                fetched_report = {
                    **fetched_report,
                    "findings": filtered_findings,
                    "summary": _recalc_summary(fetched_report["findings"], severity_filter),
                }

            _output_report(fetched_report, None, format_, quiet)

    asyncio.run(_run())

    if fetched_report is not None and _has_critical_or_high(fetched_report):
        sys.exit(1)


# ---------------------------------------------------------------------------
# status command
# ---------------------------------------------------------------------------


@main.command()
@click.argument("scan_id")
@click.pass_context
def status(ctx: click.Context, scan_id: str) -> None:
    """Check the status of a scan.

    Exit codes: 0 = complete, 1 = still running, 2 = failed/cancelled.
    """
    import asyncio

    quiet: bool = ctx.obj["quiet"]

    config = get_config()
    api_key = ctx.obj.get("api_key_opt") or config["apiKey"]
    api_url = ctx.obj.get("api_url_opt") or config["apiUrl"]

    if not api_key:
        try:
            api_key = require_api_key()
        except RuntimeError as e:
            click.echo(str(e), err=True)
            sys.exit(2)

    fetched_scan: Optional[Scan] = None

    async def _run() -> None:
        nonlocal fetched_scan
        async with ApiClient(api_key, api_url) as client:
            try:
                fetched_scan = await client.get_scan(scan_id)
            except Exception as e:
                click.echo(f"Failed to fetch scan: {e}", err=True)
                sys.exit(2)

        if quiet:
            click.echo(fetched_scan["status"])
        else:
            click.echo(format_status(fetched_scan))

    asyncio.run(_run())

    if fetched_scan is None:
        sys.exit(2)

    # Exit code semantics for CI / scripting:
    #   0 = complete (get the report with `flowpatrol report <id>`)
    #   1 = still running — try again later
    #   2 = failed or cancelled
    match fetched_scan["status"]:
        case "complete":
            sys.exit(0)
        case "failed" | "cancelled":
            sys.exit(2)
        case _:
            sys.exit(1)


# ---------------------------------------------------------------------------
# Shared output helper
# ---------------------------------------------------------------------------


def _output_report(
    rep: Report,
    sc: Optional[Scan],
    format_: OutputFormat,
    quiet: bool,
) -> None:
    if format_ == "sarif":
        click.echo(format_report_sarif(rep))
    elif format_ == "json":
        click.echo(format_report_json(rep, sc))
    elif not quiet:
        click.echo(format_report(rep, sc))
