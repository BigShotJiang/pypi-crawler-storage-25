from __future__ import annotations

from typing import Literal, NotRequired, TypedDict

ScanMode = Literal["surface", "deep", "quick", "standard"]

ScanStatus = Literal[
    "pending",
    "recon",
    "planning",
    "attacking",
    "confirming",
    "complete",
    "failed",
    "cancelled",
]

FindingSeverity = Literal["critical", "high", "medium", "low", "info"]

OutputFormat = Literal["human", "json", "sarif"]

TERMINAL_STATUSES: frozenset[ScanStatus] = frozenset({"complete", "failed", "cancelled"})
VALID_SEVERITIES: frozenset[FindingSeverity] = frozenset(
    {"critical", "high", "medium", "low", "info"}
)
VALID_FORMATS: frozenset[OutputFormat] = frozenset({"human", "json", "sarif"})
VALID_MODES: frozenset[ScanMode] = frozenset({"surface", "deep", "quick", "standard"})


class Finding(TypedDict):
    severity: FindingSeverity
    type: str
    title: str
    description: str
    endpoint: str
    evidence: str
    remediation: str
    owasp: NotRequired[str]
    cwe: NotRequired[str]
    confirmed: bool


class ScanConfig(TypedDict):
    scan_mode: ScanMode


class Scan(TypedDict):
    id: str
    status: ScanStatus
    target_url: str
    config: ScanConfig
    created_at: str
    completed_at: NotRequired[str]
    duration_seconds: NotRequired[int]


class SummaryDict(TypedDict):
    total: int
    critical: int
    high: int
    medium: int
    low: int
    info: int


class Report(TypedDict):
    scan_id: str
    target_url: str
    created_at: str
    duration_seconds: NotRequired[int]
    summary: SummaryDict
    findings: list[Finding]
    report_url: NotRequired[str]


# --- SARIF 2.1.0 types (subset) ---


class SarifArtifactLocation(TypedDict):
    uri: str


class SarifRegion(TypedDict, total=False):
    startLine: int


class SarifPhysicalLocation(TypedDict):
    artifactLocation: SarifArtifactLocation
    region: NotRequired[SarifRegion]


class SarifPhysicalLocationOuter(TypedDict):
    physicalLocation: SarifPhysicalLocation


class SarifMessage(TypedDict):
    text: str


class SarifShortDescription(TypedDict):
    text: str


class SarifRuleProperties(TypedDict, total=False):
    tags: list[str]
    precision: str


class SarifRule(TypedDict, total=False):
    id: str
    name: str
    shortDescription: SarifShortDescription
    fullDescription: SarifShortDescription
    helpUri: str
    properties: SarifRuleProperties


class SarifResultProperties(TypedDict, total=False):
    tags: list[str]


class SarifResult(TypedDict, total=False):
    ruleId: str
    level: Literal["error", "warning", "note", "none"]
    message: SarifMessage
    locations: list[SarifPhysicalLocationOuter]
    properties: SarifResultProperties


class SarifDriver(TypedDict):
    name: str
    version: str
    informationUri: str
    rules: list[SarifRule]


class SarifTool(TypedDict):
    driver: SarifDriver


class SarifUriBase(TypedDict):
    uri: str


class SarifRun(TypedDict, total=False):
    tool: SarifTool
    results: list[SarifResult]
    originalUriBaseIds: dict[str, SarifUriBase]


class SarifLog(TypedDict):
    schema: str  # mapped from $schema
    version: Literal["2.1.0"]
    runs: list[SarifRun]
