from __future__ import annotations

import json
import re

from flowpatrol_cli.__init__ import __version__
from flowpatrol_cli.types import Finding, FindingSeverity, Report, SarifLog

_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json"
_TOOL_INFO_URI = "https://flowpatrol.ai"


def _to_sarif_level(severity: FindingSeverity) -> str:
    match severity:
        case "critical" | "high":
            return "error"
        case "medium":
            return "warning"
        case "low" | "info":
            return "note"


def _rule_id(finding: Finding) -> str:
    """Derive a stable, slug-like rule ID from the finding type string.

    e.g. "SQL Injection" -> "FP-SQL-INJECTION"
    """
    base = re.sub(r"[^A-Z0-9]+", "-", finding["type"].upper()).strip("-")
    return f"FP-{base}"


def report_to_sarif(report: Report) -> dict:
    """Convert a Flowpatrol report to a SARIF 2.1.0 dict."""
    rules_map: dict[str, dict] = {}

    for finding in report["findings"]:
        rid = _rule_id(finding)
        if rid not in rules_map:
            tags: list[str] = []
            if finding.get("owasp"):
                tags.append(finding["owasp"])
            if finding.get("cwe"):
                tags.append(finding["cwe"])

            rule: dict = {
                "id": rid,
                "name": finding["type"],
                "shortDescription": {"text": finding["title"]},
                "fullDescription": {"text": finding["description"]},
                "helpUri": _TOOL_INFO_URI,
                "properties": {
                    "precision": "high" if finding["confirmed"] else "medium",
                    "problem.severity": finding["severity"],
                },
            }
            if tags:
                rule["properties"]["tags"] = tags
            rules_map[rid] = rule

    results: list[dict] = []
    for finding in report["findings"]:
        rid = _rule_id(finding)
        tags = []
        if finding.get("owasp"):
            tags.append(finding["owasp"])
        if finding.get("cwe"):
            tags.append(finding["cwe"])

        result: dict = {
            "ruleId": rid,
            "level": _to_sarif_level(finding["severity"]),
            "message": {
                "text": "\n".join(
                    [
                        finding["description"],
                        "",
                        f"Evidence: {finding['evidence']}",
                        "",
                        f"Remediation: {finding['remediation']}",
                    ]
                )
            },
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": finding["endpoint"],
                        }
                    }
                }
            ],
        }
        if tags:
            result["properties"] = {"tags": tags}
        results.append(result)

    target_url = report["target_url"]
    url_root = target_url if target_url.endswith("/") else f"{target_url}/"

    return {
        "$schema": _SCHEMA,
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "Flowpatrol",
                        "version": __version__,
                        "informationUri": _TOOL_INFO_URI,
                        "rules": list(rules_map.values()),
                    }
                },
                "results": results,
                "originalUriBaseIds": {
                    "URLROOT": {"uri": url_root},
                },
            }
        ],
    }


def format_report_sarif(report: Report) -> str:
    """Serialize a Flowpatrol report to a SARIF 2.1.0 JSON string."""
    return json.dumps(report_to_sarif(report), indent=2)
