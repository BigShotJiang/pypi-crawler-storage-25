from __future__ import annotations

import json

from flowpatrol_cli.types import Report, Scan


def format_report_json(report: Report, scan: Scan | None = None) -> str:
    """Serialize a report to pretty-printed JSON."""
    output: dict = {
        "scan_id": report["scan_id"],
        "target_url": report["target_url"],
        "status": scan["status"] if scan else "complete",
        "mode": scan["config"]["scan_mode"] if scan else None,
        "created_at": report["created_at"],
        "duration_seconds": (
            scan.get("duration_seconds") if scan else None
        ) or report.get("duration_seconds"),
        "summary": report["summary"],
        "findings": report["findings"],
        "report_url": report.get("report_url"),
    }
    return json.dumps(output, indent=2)


def format_scan_json(scan: Scan) -> str:
    """Serialize a scan object to pretty-printed JSON."""
    return json.dumps(scan, indent=2)
