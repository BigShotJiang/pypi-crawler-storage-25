from __future__ import annotations

import sys

from flowpatrol_cli.types import FindingSeverity, Report, Scan

# ---------------------------------------------------------------------------
# ANSI color helpers — only applied when stdout is a TTY
# ---------------------------------------------------------------------------

_RESET = "\x1b[0m"


def _ansi(code: str, text: str) -> str:
    if not sys.stdout.isatty():
        return text
    return f"{code}{text}{_RESET}"


def _red(t: str) -> str:
    return _ansi("\x1b[31m", t)


def _yellow(t: str) -> str:
    return _ansi("\x1b[33m", t)


def _cyan(t: str) -> str:
    return _ansi("\x1b[36m", t)


def _dim(t: str) -> str:
    return _ansi("\x1b[2m", t)


def _bold(t: str) -> str:
    return _ansi("\x1b[1m", t)


def _green(t: str) -> str:
    return _ansi("\x1b[32m", t)


# ---------------------------------------------------------------------------
# Severity styling
# ---------------------------------------------------------------------------


def _color_severity(severity: FindingSeverity) -> str:
    label = severity.upper().ljust(8)
    match severity:
        case "critical":
            return _red(_bold(label))
        case "high":
            return _yellow(_bold(label))
        case "medium":
            return _cyan(label)
        case "low" | "info":
            return _dim(label)


def _divider(width: int = 45) -> str:
    return _dim("\u2500" * width)


# ---------------------------------------------------------------------------
# Public formatters
# ---------------------------------------------------------------------------


def print_progress(scan: Scan) -> None:
    """Print a scan-in-progress status line, overwriting the current line on TTY."""
    status = scan["status"].capitalize()
    line = f"  {_dim('...')} {status:<12} {_dim(scan['id'])}"
    if sys.stdout.isatty():
        sys.stdout.write(f"\r{line}")
        sys.stdout.flush()
    else:
        print(line)


def clear_progress() -> None:
    """Clear the progress line once polling completes."""
    if sys.stdout.isatty():
        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.flush()


def format_report(report: Report, scan: Scan | None = None) -> str:
    """Render a completed report in human-readable form."""
    lines: list[str] = []

    lines.append("")
    lines.append(f"  {_bold('Flowpatrol')} \u2014 {report['target_url']}")
    lines.append(f"  {_divider()}")
    lines.append("")

    if not report["findings"]:
        lines.append(f"  {_green('No findings.')} Clean scan.")
    else:
        for finding in report["findings"]:
            lines.append(f"  {_color_severity(finding['severity'])} {_bold(finding['title'])}")
            lines.append(f"  {' ' * 10}{_dim(finding['endpoint'])}")
            lines.append(f"  {' ' * 10}Fix: {finding['remediation']}")
            refs: list[str] = []
            if finding.get("owasp"):
                refs.append(finding["owasp"])
            if finding.get("cwe"):
                refs.append(finding["cwe"])
            if refs:
                ref_str = " \u00b7 ".join(refs)
                lines.append(f"  {' ' * 10}{_dim(ref_str)}")
            lines.append("")

    lines.append(f"  {_divider()}")

    summary = report["summary"]
    counts: list[str] = []
    if summary["critical"] > 0:
        counts.append(_red(f"{summary['critical']} critical"))
    if summary["high"] > 0:
        counts.append(_yellow(f"{summary['high']} high"))
    if summary["medium"] > 0:
        counts.append(_cyan(f"{summary['medium']} medium"))
    if summary["low"] > 0:
        counts.append(_dim(f"{summary['low']} low"))
    if summary["info"] > 0:
        counts.append(_dim(f"{summary['info']} info"))
    if not counts:
        counts.append(_green("0 findings"))

    duration = scan.get("duration_seconds") if scan else None
    if duration is None:
        duration = report.get("duration_seconds")
    duration_str = f"  |  Duration: {duration}s" if duration is not None else ""

    counts_str = " \u00b7 ".join(counts)
    scan_id_line = _dim(f"Scan ID: {report['scan_id']}{duration_str}")
    lines.append(f"  {counts_str}")
    lines.append(f"  {scan_id_line}")
    lines.append("")

    return "\n".join(lines)


def format_scan_started(scan: Scan) -> str:
    """Print a summary for a scan that was started without waiting."""
    lines: list[str] = []
    lines.append("")
    lines.append(f"  Scan started \u2014 {_bold(scan['id'])}")
    lines.append(f"  Target:  {scan['target_url']}")
    lines.append(f"  Mode:    {scan['config']['scan_mode']}")
    lines.append(f"  Status:  {scan['status']}")
    lines.append("")
    lines.append(f"  Poll:   flowpatrol status {scan['id']}")
    lines.append(f"  Report: flowpatrol report {scan['id']}")
    lines.append("")
    return "\n".join(lines)


def format_status(scan: Scan) -> str:
    """Format a scan status response."""
    match scan["status"]:
        case "complete":
            status_colored = _green(scan["status"])
        case "failed" | "cancelled":
            status_colored = _red(scan["status"])
        case _:
            status_colored = _cyan(scan["status"])

    lines: list[str] = []
    lines.append("")
    lines.append(f"  {_bold('Scan')} {_dim(scan['id'])}")
    lines.append(f"  Target: {scan['target_url']}")
    lines.append(f"  Mode:   {scan['config']['scan_mode']}")
    lines.append(f"  Status: {status_colored}")
    if scan.get("completed_at"):
        from datetime import datetime, timezone

        try:
            completed = datetime.fromisoformat(scan["completed_at"].replace("Z", "+00:00"))
            lines.append(f"  Completed: {completed.astimezone().strftime('%c')}")
        except ValueError:
            lines.append(f"  Completed: {scan['completed_at']}")
    lines.append("")
    return "\n".join(lines)


def format_whoami(api_key: str, api_url: str) -> str:
    """Format auth whoami output with a redacted API key."""
    if len(api_key) > 8:
        redacted = api_key[:3] + "\u2022" * (len(api_key) - 7) + api_key[-4:]
    else:
        redacted = "\u2022" * len(api_key)

    lines: list[str] = []
    lines.append("")
    lines.append(f"  API key: {_bold(redacted)}")
    lines.append(f"  API URL: {api_url}")
    lines.append("")
    return "\n".join(lines)
