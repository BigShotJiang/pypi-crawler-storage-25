from __future__ import annotations

import json
import os
from pathlib import Path

DEFAULT_API_URL = "https://api.flowpatrol.ai"

_CONFIG_DIR = Path.home() / ".config" / "flowpatrol"
CONFIG_FILE = _CONFIG_DIR / "config.json"


def _read_config_file() -> dict[str, str]:
    """Read the on-disk config file. Returns an empty dict if absent or unparseable."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        raw = CONFIG_FILE.read_text(encoding="utf-8")
        parsed = json.loads(raw)
        if not isinstance(parsed, dict):
            return {}
        result: dict[str, str] = {}
        if isinstance(parsed.get("apiKey"), str):
            result["apiKey"] = parsed["apiKey"]
        if isinstance(parsed.get("apiUrl"), str):
            result["apiUrl"] = parsed["apiUrl"]
        return result
    except (json.JSONDecodeError, OSError):
        return {}


def write_config(config: dict[str, str]) -> None:
    """Persist a full config dict to disk, creating the config directory if needed."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")


def update_config(partial: dict[str, str]) -> None:
    """Merge a partial update into the existing on-disk config and persist it."""
    existing = _read_config_file()
    write_config({**existing, **partial})


def get_config() -> dict[str, str]:
    """Return the resolved configuration.

    Environment variables take precedence over the config file.
    """
    file_config = _read_config_file()
    api_key = os.environ.get("FLOWPATROL_API_KEY") or file_config.get("apiKey", "")
    api_url = (
        os.environ.get("FLOWPATROL_API_URL") or file_config.get("apiUrl", "") or DEFAULT_API_URL
    )
    return {"apiKey": api_key, "apiUrl": api_url}


def require_api_key() -> str:
    """Return the resolved API key or raise a descriptive RuntimeError if none is set."""
    api_key = get_config()["apiKey"]
    if not api_key:
        raise RuntimeError(
            "No API key configured.\n"
            "Run: flowpatrol auth set-key <key>\n"
            "Or set the FLOWPATROL_API_KEY environment variable."
        )
    return api_key
