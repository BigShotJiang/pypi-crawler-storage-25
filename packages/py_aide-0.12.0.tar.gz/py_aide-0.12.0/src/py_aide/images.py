import base64
import os
from typing import Any
from .storage import Path

try:
    from fastapi import UploadFile
except ImportError:
    UploadFile = Any

class ImageHandler:
    @staticmethod
    def save_base64_images(image_data_list: list[dict[str, str]], target_folder: str, overwrite: bool = False) -> list[str]:
        """
        Saves images from [{'img': 'base64...', 'name': 'filename_without_ext'}]
        """
        saved_paths = []
        for item in image_data_list:
            b64str = item['img']
            base_filename = item['name'] # e.g., "profile_pic"

            try:
                encoded = b64str.split(",", 1)[1] if "," in b64str else b64str
                image_binary = base64.b64decode(encoded)
                
                final_path = ImageHandler._save_to_disk(image_binary, base_filename, target_folder, overwrite)
                saved_paths.append(final_path)
            except Exception as e:
                print(f"Failed to save {base_filename}: {e}")
                continue

        return saved_paths

    @staticmethod
    def save_images(image_data_list: list[dict[str, str]], target_folder: str, overwrite: bool = False) -> list[str]:
        """
        Deprecated: Use save_base64_images instead.
        Saves images from [{'img': 'base64...', 'name': 'filename_without_ext'}]
        """
        return ImageHandler.save_base64_images(image_data_list, target_folder, overwrite)

    @staticmethod
    def save_binary_images(image_data_list: list[dict[str, Any]], target_folder: str, overwrite: bool = False) -> list[str]:
        """
        Saves images from raw bytes or FastAPI UploadFile objects.
        Input: [{'data': bytes | UploadFile, 'name': str}]
        """
        saved_paths = []
        for item in image_data_list:
            data = item['data']
            base_filename = item['name']

            try:
                # Handle FastAPI UploadFile or file-like objects
                if hasattr(data, 'file') and hasattr(data.file, 'read'):
                    # UploadFile provides a sync file pointer
                    image_binary = data.file.read()
                elif hasattr(data, 'read'):
                    image_binary = data.read()
                else:
                    # Assume raw bytes
                    image_binary = data

                final_path = ImageHandler._save_to_disk(image_binary, base_filename, target_folder, overwrite)
                saved_paths.append(final_path)
                
            except Exception as e:
                print(f"Failed to save {base_filename}: {e}")
                continue

        return saved_paths

    @staticmethod
    def _save_to_disk(image_binary: bytes, base_filename: str, target_folder: str, overwrite: bool = False) -> str:
        """Shared internal logic for writing image bytes to disk with collision handling."""
        abs_target = Path.get_absolute_path(target_folder)
        ext = ImageHandler.detect_ext(image_binary)
        filename_with_ext = f"{base_filename}.{ext}"
        
        initial_path = os.path.join(abs_target, filename_with_ext)
        
        if overwrite:
            final_path = initial_path
        else:
            final_path = ImageHandler.get_collision_free_path(initial_path)

        os.makedirs(os.path.dirname(final_path), exist_ok=True)
        with open(final_path, "wb") as f:
            f.write(image_binary)
        
        return final_path

    @staticmethod
    def detect_ext(data: bytes) -> str:
        """Determines extension by checking magic numbers."""
        if data.startswith(b"\xff\xd8\xff"): return "jpg"
        if data.startswith(b"\x89PNG\r\n\x1a\n"): return "png"
        if data.startswith(b"GIF8"): return "gif"
        if data.startswith(b"RIFF"): return "webp"
        if data.startswith(b"BM"): return "bmp"
        return "png" # Default fallback

    @staticmethod
    def is_base64_image(base64str: str) -> bool:
        """Validates via magic numbers."""
        try:
            encoded = base64str.split(",", 1)[1] if "," in base64str else base64str
            image_data = base64.b64decode(encoded, validate=True)
            signatures = [b"\xff\xd8\xff", b"\x89PNG\r\n\x1a\n", b"GIF8", b"RIFF", b"BM"]
            return any(image_data.startswith(sig) for sig in signatures)
        except Exception:
            return False

    @staticmethod
    def get_collision_free_path(target_path: str) -> str:
        """Handles naming: name.ext -> name_copy.ext -> name_copy_1.ext"""
        if not os.path.exists(target_path):
            return target_path
            
        base, ext = os.path.splitext(target_path)
        candidate = f"{base}_copy{ext}"
        if not os.path.exists(candidate):
            return candidate
            
        counter = 1
        while os.path.exists(candidate):
            candidate = f"{base}_copy_{counter}{ext}"
            counter += 1
        return candidate
