import threading
import queue
import random
import sys
import time
from typing import Callable, Any, Type, Tuple, List, Optional

class TaskFuture:
    """A proxy object to track the state and result of a background task."""

    # A private class-level constant
    # _PRIVATE_KEY = object()

    def __init__(self,*, executor:'ThreadPoolExecutor' = None) -> None:
        # if key is not TaskFuture._PRIVATE_KEY:
        #     raise RuntimeError(
        #        "Access Denied: TaskFuture is an internal result object "
        #         "and cannot be instantiated manually."
        #     )
        self._result: Any = None
        self.executor = executor
        self._exception: Optional[Exception] = None
        self._event = threading.Event()
        self._callbacks: List[Callable[['TaskFuture'], None]] = []

    def add_done_callback(self, fn: Callable[['TaskFuture'], None]) -> None:
        if self._event.is_set():
            fn(self)
        else:
            self._callbacks.append(fn)

    def set_result(self, result: Any) -> None:
        self._result = result
        self._event.set()
        for cb in self._callbacks:
            try: cb(self)
            except: pass

    def set_exception(self, exception: Exception) -> None:
        self._exception = exception
        self._event.set()
        for cb in self._callbacks:
            try: cb(self)
            except: pass

    def result(self, timeout: Optional[float] = None) -> Any:
        if not self._event.wait(timeout):
            raise TimeoutError("Task timed out.")
        if self._exception:
            raise self._exception
        return self._result

class ThreadPoolExecutor:
    def __init__(
        self,
        *, 
        min_workers: int = 2, 
        max_workers: int = 5, 
        max_retries: int = 3,
        retryable_exceptions: Tuple[Type[Exception], ...] = (IOError, ConnectionError, TimeoutError)
    ) -> None:
        self.tasks: queue.Queue = queue.Queue()
        self.workers: List[threading.Thread] = []
        self.min_workers = min_workers
        self.max_workers = max_workers
        self.max_retries = max_retries
        self.retryable_exceptions = retryable_exceptions
        
        self.is_shutdown = False
        self.in_with_context = False
        
        self.total_submitted = 0
        self.completed_count = 0
        self.pending_retries = 0  # Tracks tasks currently waiting in a Timer
        
        self._stats_lock = threading.Lock()
        self._KILL_WORKER = object()

    def _spawn_worker(self) -> None:
        t = threading.Thread(
            target=self._worker_loop, 
            name=f"Worker-{len(self.workers)}", 
            daemon=True
        )
        t.start()
        self.workers.append(t)

    def _worker_loop(self) -> None:
        while True:
            try:
                task_item = self.tasks.get(timeout=1)
            except queue.Empty:
                if self.is_shutdown:
                    break
                continue

            try:
                # 1. Check if the pool is closing
                if task_item is self._KILL_WORKER:
                    break

                func, args, kwargs, future, attempt = task_item
                
                try:
                    result = func(*args, **kwargs)
                    future.set_result(result)
                    
                    with self._stats_lock:
                        self.completed_count += 1
                        # If this was a retry that just finished, decrement the pending count
                        if attempt > 1:
                            self.pending_retries -= 1
                
                except Exception as e:
                    # 2. Handle Retries
                    if isinstance(e, self.retryable_exceptions) and attempt < self.max_retries:
                        with self._stats_lock:
                            # If this is the first failure, mark it as a pending retry
                            if attempt == 1:
                                self.pending_retries += 1
                        
                        wait_time = (2 ** attempt) + random.random()
                        # Move task to background Timer (off the queue)
                        threading.Timer(
                            wait_time, 
                            self.tasks.put, 
                            args=[(func, args, kwargs, future, attempt + 1)]
                        ).start()
                    else:
                        # 3. Permanent Failure
                        future.set_exception(e)
                        with self._stats_lock:
                            self.completed_count += 1
                            if attempt > 1:
                                self.pending_retries -= 1
                
                # self._update_progress()

            finally:
                # 4. Critical: Always signal task_done to unblock .join()
                self.tasks.task_done()

    # def _update_progress(self) -> None:
    #     with self._stats_lock:
    #         if self.total_submitted == 0: return
    #         percent = (self.completed_count / self.total_submitted) * 100
    #         filled = int(percent / 5)
    #         bar = "█" * filled + "-" * (20 - filled)
    #         sys.stdout.write(f"\rBatch Progress: |{bar}| {percent:.1f}% ({self.completed_count}/{self.total_submitted})")
    #         sys.stdout.flush()

    def __enter__(self) -> 'ThreadPoolExecutor':
        self.in_with_context = True
        for _ in range(self.min_workers):
            self._spawn_worker()
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        # The shutdown handles the wait logic
        self.shutdown(wait=True)
        self.in_with_context = False
        print("\n") 

    def submit(self, func: Callable, *args: Any, **kwargs: Any) -> TaskFuture:
        if not self.in_with_context:
            raise RuntimeError("Executor must be used within a 'with' block.")
        
        if self.is_shutdown:
            raise RuntimeError("Cannot submit tasks to a closed executor.")

        with self._stats_lock:
            self.total_submitted += 1

        future = TaskFuture(executor=self)
        
        if self.tasks.qsize() > 2 and len(self.workers) < self.max_workers:
            self._spawn_worker()

        self.tasks.put((func, args, kwargs, future, 1))
        return future

    def shutdown(self, *, wait: bool = True) -> None:
        if wait:
            # Stage A: Wait for the physical queue to be empty
            self.tasks.join()
            
            # Stage B: Check if there are invisible retries counting down in Timers
            while True:
                with self._stats_lock:
                    if self.pending_retries <= 0:
                        break
                # If retries are pending, we sleep and then re-join the queue
                # to catch the reappearing tasks.
                time.sleep(0.1)
                self.tasks.join()

        # Stage C: All real work and retries are done. Send the kill signals.
        for _ in range(len(self.workers)):
            self.tasks.put(self._KILL_WORKER)

        if wait:
            # Final join to wait for workers to swallow sentinels
            self.tasks.join()
        
        self.is_shutdown = True

