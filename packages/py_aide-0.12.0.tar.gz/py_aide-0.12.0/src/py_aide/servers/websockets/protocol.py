"""
WebSocket Protocol Module - Message Structure, Patterns, and Client Communication with Runtime Updates

This module defines the standard message format and communication patterns for
WebSocket interactions. It provides:

1. Standardized message envelope with metadata
2. Acknowledgment patterns (message confirmation)
3. Error handling and reporting
4. Heartbeat/ping-pong for connection health
5. Reconnection and resumption logic
6. Client capability negotiation
7. Versioning for API evolution
8. Runtime updates to protocol settings

The protocol ensures that all WebSocket communication follows consistent patterns,
making it easier to build robust clients and servers.
"""

import time
import uuid
import json
import enum
import logging
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass, field, asdict
import threading
from collections import defaultdict

from flask_socketio import emit

from .engine import WebSocketEngine, ConnectionInfo


# ============================================================================
# ENUMS - Core Protocol Constants
# ============================================================================

class MessageType(str, enum.Enum):
    """All possible message types in the protocol."""
    
    # Standard messages
    REQUEST = "request"           # Client -> Server request
    RESPONSE = "response"         # Server -> Client response
    EVENT = "event"               # One-way event (no response expected)
    
    # Control messages
    ACK = "ack"                    # Acknowledgment of receipt
    NACK = "nack"                  # Negative acknowledgment (error)
    
    # System messages
    PING = "ping"                  # Client ping
    PONG = "pong"                  # Server pong
    HEARTBEAT = "heartbeat"        # Regular keepalive
    
    # Connection management
    CONNECT = "connect"            # Client connection request
    CONNECTED = "connected"        # Server confirms connection
    DISCONNECT = "disconnect"      # Graceful disconnect
    RECONNECT = "reconnect"        # Client reconnecting
    
    # Error messages
    ERROR = "error"                 # Error notification
    WARNING = "warning"             # Warning notification
    
    # Protocol negotiation
    CAPABILITIES = "capabilities"   # Feature negotiation
    PROTOCOL_VERSION = "version"    # Protocol version exchange


class MessagePriority(str, enum.Enum):
    """Message priority levels for QoS."""
    HIGH = "high"          # Critical messages (process immediately)
    NORMAL = "normal"      # Standard messages
    LOW = "low"           # Background messages (can be delayed)
    BULK = "bulk"         # Large data transfers (can be throttled)


class MessageStatus(str, enum.Enum):
    """Status of a message response."""
    SUCCESS = "success"
    FAILURE = "failure"
    PENDING = "pending"
    TIMEOUT = "timeout"
    REJECTED = "rejected"


class ProtocolVersion(str, enum.Enum):
    """Supported protocol versions."""
    V1_0 = "1.0"
    V1_1 = "1.1"
    LATEST = "1.1"


# ============================================================================
# PROTOCOL CONFIGURATION
# ============================================================================

@dataclass
class ProtocolConfig:
    """
    Protocol configuration for WebSocket connections.
    
    All protocol-specific settings are defined here with validation methods
    to support runtime updates through the WebSocketConfigManager.
    
    Each setting can have:
    - A validate_<setting> method for runtime updates
    - An on_<setting>_updated hook to react to changes
    """
    
    # ========================================================================
    # VERSION SETTINGS
    # ========================================================================
    
    protocol_version: str = ProtocolVersion.LATEST.value
    """Protocol version to use for new connections."""
    
    supported_versions: List[str] = field(default_factory=lambda: ['1.0', '1.1'])
    """All protocol versions the server supports."""
    
    # ========================================================================
    # MESSAGE FORMAT SETTINGS
    # ========================================================================
    
    require_message_id: bool = True
    """Whether every message must include a unique ID."""
    
    require_timestamp: bool = True
    """Whether every message must include a timestamp."""
    
    max_message_id_length: int = 64
    """Maximum length of message IDs."""
    
    default_encoding: str = "json"
    """Default encoding for messages (json, msgpack, etc.)."""
    
    # ========================================================================
    # ACKNOWLEDGMENT SETTINGS
    # ========================================================================
    
    require_ack: bool = False
    """Whether messages require acknowledgment by default."""
    
    ack_timeout: float = 10.0
    """Seconds to wait for acknowledgment before timing out."""
    
    ack_retries: int = 3
    """Number of times to retry sending if no acknowledgment."""
    
    # ========================================================================
    # SESSION SETTINGS
    # ========================================================================
    
    session_timeout: int = 3600  # 1 hour
    """How long to keep session data after disconnect (seconds)."""
    
    enable_reconnection: bool = True
    """Whether clients can reconnect and resume sessions."""
    
    message_history_size: int = 100
    """Number of past messages to keep for replay on reconnection."""
    
    # ========================================================================
    # HEARTBEAT SETTINGS
    # ========================================================================
    
    heartbeat_enabled: bool = True
    """Whether to enable heartbeat (ping/pong)."""
    
    heartbeat_interval: int = 30
    """Seconds between heartbeats."""
    
    heartbeat_timeout: int = 10
    """Seconds to wait for heartbeat response before disconnecting."""
    
    # ========================================================================
    # FEATURE SETTINGS
    # ========================================================================
    
    enable_compression: bool = True
    """Whether to compress messages."""
    
    enable_binary: bool = False
    """Whether to support binary messages (vs only JSON)."""
    
    enable_batching: bool = False
    """Whether to batch multiple messages together."""
    
    max_batch_size: int = 10
    """Maximum messages in a batch."""
    
    # ========================================================================
    # VALIDATION METHODS (for runtime updates)
    # ========================================================================
    
    def validate_protocol_version(self, value: str) -> None:
        """Validate protocol version before runtime update."""
        if value not in self.supported_versions:
            raise ValueError(
                f"Protocol version '{value}' not in supported versions: "
                f"{self.supported_versions}"
            )
    
    def validate_supported_versions(self, value: List[str]) -> None:
        """Validate supported versions before runtime update."""
        if not value:
            raise ValueError("supported_versions cannot be empty")
        
        if self.protocol_version not in value:
            logging.warning(
                f"Current protocol version '{self.protocol_version}' "
                f"not in new supported versions {value}"
            )
    
    def validate_require_message_id(self, value: bool) -> None:
        """Validate require_message_id before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"require_message_id must be boolean, got {type(value)}")
    
    def validate_require_timestamp(self, value: bool) -> None:
        """Validate require_timestamp before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"require_timestamp must be boolean, got {type(value)}")
    
    def validate_max_message_id_length(self, value: int) -> None:
        """Validate max_message_id_length before runtime update."""
        if value < 8:
            raise ValueError(f"max_message_id_length too short: {value} (minimum 8)")
        if value > 256:
            logging.warning(f"Very long message ID length: {value}")
    
    def validate_default_encoding(self, value: str) -> None:
        """Validate default_encoding before runtime update."""
        valid_encodings = ['json', 'msgpack', 'cbor']
        if value not in valid_encodings:
            raise ValueError(
                f"Invalid encoding '{value}'. Must be one of {valid_encodings}"
            )
    
    def validate_require_ack(self, value: bool) -> None:
        """Validate require_ack before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"require_ack must be boolean, got {type(value)}")
    
    def validate_ack_timeout(self, value: float) -> None:
        """Validate ack_timeout before runtime update."""
        if value < 0.1:
            raise ValueError(f"ack_timeout too short: {value}s (minimum 0.1)")
        if value > 60:
            logging.warning(f"Very long ack_timeout: {value}s")
    
    def validate_ack_retries(self, value: int) -> None:
        """Validate ack_retries before runtime update."""
        if value < 0:
            raise ValueError(f"ack_retries cannot be negative, got {value}")
        if value > 10:
            logging.warning(f"High number of ack_retries: {value}")
    
    def validate_session_timeout(self, value: int) -> None:
        """Validate session_timeout before runtime update."""
        if value < 60:
            raise ValueError(f"session_timeout too short: {value}s (minimum 60)")
        if value > 7 * 86400:  # 7 days
            logging.warning(f"Very long session_timeout: {value}s")
    
    def validate_enable_reconnection(self, value: bool) -> None:
        """Validate enable_reconnection before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"enable_reconnection must be boolean, got {type(value)}")
    
    def validate_message_history_size(self, value: int) -> None:
        """Validate message_history_size before runtime update."""
        if value < 0:
            raise ValueError(f"message_history_size cannot be negative, got {value}")
        if value > 10000:
            logging.warning(f"Very large message_history_size: {value}")
    
    def validate_heartbeat_enabled(self, value: bool) -> None:
        """Validate heartbeat_enabled before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"heartbeat_enabled must be boolean, got {type(value)}")
    
    def validate_heartbeat_interval(self, value: int) -> None:
        """Validate heartbeat_interval before runtime update."""
        if value < 5:
            raise ValueError(f"heartbeat_interval too short: {value}s (minimum 5)")
        if value > 300:
            logging.warning(f"Very long heartbeat_interval: {value}s")
        
        # Check against timeout
        if value <= self.heartbeat_timeout:
            logging.warning(
                f"heartbeat_interval ({value}s) should be greater than "
                f"heartbeat_timeout ({self.heartbeat_timeout}s)"
            )
    
    def validate_heartbeat_timeout(self, value: int) -> None:
        """Validate heartbeat_timeout before runtime update."""
        if value < 2:
            raise ValueError(f"heartbeat_timeout too short: {value}s (minimum 2)")
        if value > 60:
            logging.warning(f"Very long heartbeat_timeout: {value}s")
        
        # Check against interval
        if value >= self.heartbeat_interval:
            logging.warning(
                f"heartbeat_timeout ({value}s) should be less than "
                f"heartbeat_interval ({self.heartbeat_interval}s)"
            )
    
    def validate_enable_compression(self, value: bool) -> None:
        """Validate enable_compression before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"enable_compression must be boolean, got {type(value)}")
    
    def validate_enable_binary(self, value: bool) -> None:
        """Validate enable_binary before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"enable_binary must be boolean, got {type(value)}")
    
    def validate_enable_batching(self, value: bool) -> None:
        """Validate enable_batching before runtime update."""
        if not isinstance(value, bool):
            raise ValueError(f"enable_batching must be boolean, got {type(value)}")
    
    def validate_max_batch_size(self, value: int) -> None:
        """Validate max_batch_size before runtime update."""
        if value < 1:
            raise ValueError(f"max_batch_size must be at least 1, got {value}")
        if value > 1000:
            logging.warning(f"Very large max_batch_size: {value}")
    
    # ========================================================================
    # UPDATE HOOKS (called after successful runtime updates)
    # ========================================================================
    
    def on_protocol_version_updated(self, value: str) -> None:
        """Hook called after protocol version is updated."""
        logging.info(f"Protocol: version updated to {value}")
    
    def on_require_ack_updated(self, value: bool) -> None:
        """Hook called after require_ack is updated."""
        logging.info(f"Protocol: require_ack updated to {value}")
    
    def on_ack_timeout_updated(self, value: float) -> None:
        """Hook called after ack_timeout is updated."""
        logging.info(f"Protocol: ack_timeout updated to {value}s")
    
    def on_heartbeat_interval_updated(self, value: int) -> None:
        """Hook called after heartbeat_interval is updated."""
        logging.info(f"Protocol: heartbeat_interval updated to {value}s")
    
    def on_session_timeout_updated(self, value: int) -> None:
        """Hook called after session_timeout is updated."""
        logging.info(f"Protocol: session_timeout updated to {value}s")
    
    # ========================================================================
    # INITIAL VALIDATION (called at startup)
    # ========================================================================
    
    def __post_init__(self):
        """Validate configuration at startup."""
        self._validate_versions()
        self._validate_heartbeat()
        self._validate_ack_settings()
    
    def _validate_versions(self):
        """Validate protocol version settings."""
        if self.protocol_version not in self.supported_versions:
            raise ValueError(
                f"Protocol version '{self.protocol_version}' not in "
                f"supported versions: {self.supported_versions}"
            )
    
    def _validate_heartbeat(self):
        """Validate heartbeat settings."""
        if self.heartbeat_enabled:
            if self.heartbeat_timeout >= self.heartbeat_interval:
                raise ValueError(
                    f"heartbeat_timeout ({self.heartbeat_timeout}) must be less than "
                    f"heartbeat_interval ({self.heartbeat_interval})"
                )
    
    def _validate_ack_settings(self):
        """Validate acknowledgment settings."""
        if self.ack_timeout <= 0:
            raise ValueError(f"ack_timeout must be positive, got {self.ack_timeout}")
        
        if self.ack_retries < 0:
            raise ValueError(f"ack_retries cannot be negative, got {self.ack_retries}")
    
    # ========================================================================
    # HELPER METHODS
    # ========================================================================
    
    def get_server_capabilities(self) -> Dict[str, Any]:
        """Get server capabilities dictionary for negotiation."""
        return {
            'protocol_versions': self.supported_versions,
            'compression': ['gzip'] if self.enable_compression else [],
            'encoding': [self.default_encoding],
            'max_message_size': 1024 * 1024,  # This would come from engine config
            'supports_ack': True,
            'supports_reconnection': self.enable_reconnection,
            'heartbeat_interval': self.heartbeat_interval if self.heartbeat_enabled else None,
            'features': {
                'binary': self.enable_binary,
                'batching': self.enable_batching,
                'compression': self.enable_compression
            }
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            'protocol_version': self.protocol_version,
            'supported_versions': self.supported_versions,
            'require_ack': self.require_ack,
            'ack_timeout': self.ack_timeout,
            'ack_retries': self.ack_retries,
            'session_timeout': self.session_timeout,
            'enable_reconnection': self.enable_reconnection,
            'message_history_size': self.message_history_size,
            'heartbeat_enabled': self.heartbeat_enabled,
            'heartbeat_interval': self.heartbeat_interval,
            'heartbeat_timeout': self.heartbeat_timeout,
            'enable_compression': self.enable_compression,
            'enable_binary': self.enable_binary,
            'enable_batching': self.enable_batching
        }


# ============================================================================
# MESSAGE ENVELOPE (Unchanged)
# ============================================================================

@dataclass
class MessageEnvelope:
    """
    Standard wrapper for all WebSocket messages.
    
    (Implementation unchanged from original)
    """
    
    # Core fields (always present)
    id: str
    type: MessageType
    event: str
    payload: Any
    timestamp: float
    
    # Optional fields
    correlation_id: Optional[str] = None
    client_id: Optional[str] = None
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    
    # Quality of service
    priority: MessagePriority = MessagePriority.NORMAL
    ttl: Optional[int] = None
    persistent: bool = False
    
    # Protocol metadata
    version: str = ProtocolVersion.LATEST.value
    encoding: str = "json"
    compression: Optional[str] = None
    
    # Security
    signature: Optional[str] = None
    
    @classmethod
    def create_request(cls, event: str, payload: Any, **kwargs) -> 'MessageEnvelope':
        """Create a request message."""
        return cls(
            id=cls.generate_id(),
            type=MessageType.REQUEST,
            event=event,
            payload=payload,
            timestamp=time.time(),
            **kwargs
        )
    
    @classmethod
    def create_response(cls, request: 'MessageEnvelope', payload: Any, 
                        status: MessageStatus = MessageStatus.SUCCESS) -> 'MessageEnvelope':
        """Create a response to a request."""
        return cls(
            id=cls.generate_id(),
            type=MessageType.RESPONSE,
            event=request.event,
            payload={
                "status": status.value,
                "data": payload
            },
            timestamp=time.time(),
            correlation_id=request.id,
            client_id=request.client_id,
            priority=request.priority
        )
    
    @classmethod
    def create_event(cls, event: str, payload: Any, **kwargs) -> 'MessageEnvelope':
        """Create a one-way event message."""
        return cls(
            id=cls.generate_id(),
            type=MessageType.EVENT,
            event=event,
            payload=payload,
            timestamp=time.time(),
            **kwargs
        )
    
    @classmethod
    def create_ack(cls, message_id: str, status: str = "received") -> 'MessageEnvelope':
        """Create an acknowledgment for a message."""
        return cls(
            id=cls.generate_id(),
            type=MessageType.ACK,
            event="system.ack",
            payload={"status": status, "ack_for": message_id},
            timestamp=time.time(),
            correlation_id=message_id
        )
    
    @classmethod
    def create_error(cls, message_id: str, error_code: str, 
                     error_message: str, details: Optional[Dict] = None) -> 'MessageEnvelope':
        """Create an error response."""
        return cls(
            id=cls.generate_id(),
            type=MessageType.ERROR,
            event="system.error",
            payload={
                "code": error_code,
                "message": error_message,
                "details": details or {},
                "in_response_to": message_id
            },
            timestamp=time.time(),
            correlation_id=message_id
        )
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MessageEnvelope':
        """Create envelope from dictionary (parsed JSON)."""
        # Convert type string to enum
        if 'type' in data and isinstance(data['type'], str):
            try:
                data['type'] = MessageType(data['type'])
            except ValueError:
                data['type'] = MessageType.EVENT
        
        # Convert priority string to enum
        if 'priority' in data and isinstance(data['priority'], str):
            try:
                data['priority'] = MessagePriority(data['priority'])
            except ValueError:
                data['priority'] = MessagePriority.NORMAL
        
        return cls(**data)
    
    @staticmethod
    def generate_id() -> str:
        """Generate a unique message ID."""
        return f"msg_{uuid.uuid4().hex[:16]}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = asdict(self)
        # Convert enums to strings
        result['type'] = self.type.value
        result['priority'] = self.priority.value
        return result
    
    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict())
    
    def is_expired(self) -> bool:
        """Check if message has expired."""
        if self.ttl:
            return time.time() > (self.timestamp + self.ttl)
        return False
    
    def requires_ack(self) -> bool:
        """Check if this message type requires acknowledgment."""
        return self.type in [MessageType.REQUEST, MessageType.EVENT]
    
    @property
    def is_control_message(self) -> bool:
        """Check if this is a system control message."""
        return self.type in [
            MessageType.PING, MessageType.PONG, MessageType.HEARTBEAT,
            MessageType.ACK, MessageType.NACK, MessageType.ERROR
        ]


# ============================================================================
# ACKNOWLEDGMENT MANAGER (Updated for runtime config)
# ============================================================================

class AcknowledgmentManager:
    """
    Manages message acknowledgments and retries.
    
    Tracks which messages need acknowledgment and retries if not received.
    Supports runtime updates to timeout and retry settings.
    """
    
    def __init__(self, config: ProtocolConfig):
        """
        Args:
            config: Protocol configuration
        """
        self.config = config
        
        # Pending acknowledgments
        self._pending: Dict[str, Dict[str, Any]] = {}
        
        # Retry counters
        self._retries: Dict[str, int] = {}
        
        # Callbacks for when ack received or timeout
        self._callbacks: Dict[str, Dict[str, Callable]] = {}
        
        self._lock = threading.RLock()
        self._running = True
        self._check_thread = threading.Thread(target=self._check_timeouts, daemon=True)
        self._check_thread.start()
    
    def update_config(self, new_config: ProtocolConfig) -> None:
        """Update configuration at runtime."""
        with self._lock:
            self.config = new_config
            logging.info("[AckManager] Configuration updated at runtime")
    
    def expect_ack(self, message_id: str, on_ack: Optional[Callable] = None,
                   on_timeout: Optional[Callable] = None):
        """
        Register that we expect an acknowledgment for a message.
        
        Args:
            message_id: Message ID to track
            on_ack: Callback when ack received
            on_timeout: Callback if ack times out
        """
        with self._lock:
            self._pending[message_id] = {
                'sent_at': time.time(),
                'timeout': self.config.ack_timeout,
                'retries': 0
            }
            self._callbacks[message_id] = {
                'on_ack': on_ack,
                'on_timeout': on_timeout
            }
    
    def receive_ack(self, message_id: str) -> bool:
        """
        Record receipt of an acknowledgment.
        
        Args:
            message_id: Message being acknowledged
            
        Returns:
            True if message was pending, False otherwise
        """
        with self._lock:
            if message_id in self._pending:
                # Call success callback
                if message_id in self._callbacks:
                    cb = self._callbacks[message_id].get('on_ack')
                    if cb:
                        try:
                            cb()
                        except Exception as e:
                            logging.error(f"Ack callback error: {e}")
                
                # Clean up
                self._pending.pop(message_id, None)
                self._callbacks.pop(message_id, None)
                self._retries.pop(message_id, None)
                return True
            return False
    
    def should_retry(self, message_id: str) -> bool:
        """
        Check if a message should be retried.
        
        Returns:
            True if under max retries, False otherwise
        """
        with self._lock:
            retries = self._retries.get(message_id, 0)
            return retries < self.config.ack_retries
    
    def mark_retry(self, message_id: str):
        """Increment retry count for a message."""
        with self._lock:
            self._retries[message_id] = self._retries.get(message_id, 0) + 1
    
    def _check_timeouts(self):
        """Background thread to check for timed-out acknowledgments."""
        while self._running:
            time.sleep(1)
            self._process_timeouts()
    
    def _process_timeouts(self):
        """Check for and handle timed-out messages."""
        now = time.time()
        timed_out = []
        
        with self._lock:
            for msg_id, data in list(self._pending.items()):
                if now - data['sent_at'] > data['timeout']:
                    timed_out.append(msg_id)
            
            for msg_id in timed_out:
                # Call timeout callback
                if msg_id in self._callbacks:
                    cb = self._callbacks[msg_id].get('on_timeout')
                    if cb:
                        try:
                            cb()
                        except Exception as e:
                            logging.error(f"Ack timeout callback error: {e}")
                
                # Clean up
                self._pending.pop(msg_id, None)
                self._callbacks.pop(msg_id, None)
    
    def shutdown(self):
        """Stop the timeout checker thread."""
        self._running = False
        self._check_thread.join(timeout=5)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get acknowledgment manager statistics."""
        with self._lock:
            return {
                'pending_acks': len(self._pending),
                'config': {
                    'timeout': self.config.ack_timeout,
                    'max_retries': self.config.ack_retries
                }
            }


# ============================================================================
# SESSION MANAGER (Updated for runtime config)
# ============================================================================

class SessionManager:
    """
    Manages client sessions for reconnection support.
    
    Stores session state so clients can reconnect and resume.
    Supports runtime updates to session timeout.
    """
    
    def __init__(self, config: ProtocolConfig):
        """
        Args:
            config: Protocol configuration
        """
        self.config = config
        
        # Active sessions: session_id -> session_data
        self._sessions: Dict[str, Dict[str, Any]] = {}
        
        # Map client_id to current session
        self._client_sessions: Dict[str, str] = {}
        
        # Map user_id to sessions
        self._user_sessions: Dict[str, List[str]] = defaultdict(list)
        
        self._lock = threading.RLock()
        
        # Start cleanup thread
        self._running = True
        self._cleanup_thread = threading.Thread(target=self._cleanup_expired, daemon=True)
        self._cleanup_thread.start()
    
    def update_config(self, new_config: ProtocolConfig) -> None:
        """Update configuration at runtime."""
        with self._lock:
            old_timeout = self.config.session_timeout
            self.config = new_config
            
            # If timeout decreased, we may need to expire sessions sooner
            if new_config.session_timeout < old_timeout:
                self._cleanup_expired(force=True)
            
            logging.info(f"[SessionManager] Configuration updated, session_timeout={new_config.session_timeout}s")
    
    def create_session(self, client_id: str, user_id: Optional[str] = None,
                       metadata: Optional[Dict] = None) -> str:
        """
        Create a new session for a client.
        
        Args:
            client_id: Client identifier
            user_id: Authenticated user ID (if any)
            metadata: Additional session data
            
        Returns:
            Session ID
        """
        session_id = f"sess_{uuid.uuid4().hex[:16]}"
        
        with self._lock:
            # Store session
            self._sessions[session_id] = {
                'session_id': session_id,
                'client_id': client_id,
                'user_id': user_id,
                'created_at': time.time(),
                'last_active': time.time(),
                'expires_at': time.time() + self.config.session_timeout,
                'metadata': metadata or {},
                'message_history': [],  # Last N messages (for replay)
                'subscriptions': set(),  # Active subscriptions
                'state': {}  # Application state
            }
            
            # Track by client
            self._client_sessions[client_id] = session_id
            
            # Track by user
            if user_id:
                self._user_sessions[user_id].append(session_id)
        
        return session_id
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session data by ID."""
        with self._lock:
            session = self._sessions.get(session_id)
            if session:
                session['last_active'] = time.time()
            return session
    
    def get_session_by_client(self, client_id: str) -> Optional[Dict[str, Any]]:
        """Get current session for a client."""
        with self._lock:
            session_id = self._client_sessions.get(client_id)
            if session_id:
                return self.get_session(session_id)
            return None
    
    def restore_session(self, session_id: str, connection_info: ConnectionInfo) -> bool:
        """
        Restore a session for a reconnecting client.
        
        Args:
            session_id: Session to restore
            connection_info: New connection info
            
        Returns:
            True if session restored, False if expired/invalid
        """
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return False
            
            if time.time() > session['expires_at']:
                # Session expired
                self.delete_session(session_id)
                return False
            
            # Update with new connection
            session['last_active'] = time.time()
            session['connection_info'] = {
                'sid': connection_info.sid,
                'ip': connection_info.client_ip,
                'reconnected_at': time.time()
            }
            
            return True
    
    def delete_session(self, session_id: str):
        """Delete a session."""
        with self._lock:
            session = self._sessions.pop(session_id, None)
            if session:
                # Remove from client mapping
                client_id = session.get('client_id')
                if client_id and client_id in self._client_sessions:
                    if self._client_sessions[client_id] == session_id:
                        del self._client_sessions[client_id]
                
                # Remove from user mapping
                user_id = session.get('user_id')
                if user_id and user_id in self._user_sessions:
                    if session_id in self._user_sessions[user_id]:
                        self._user_sessions[user_id].remove(session_id)
    
    def add_to_history(self, session_id: str, message: MessageEnvelope):
        """Add a message to session history (for replay)."""
        with self._lock:
            session = self._sessions.get(session_id)
            if session:
                history = session.setdefault('message_history', [])
                history.append({
                    'id': message.id,
                    'type': message.type.value,
                    'event': message.event,
                    'timestamp': message.timestamp,
                    'correlation_id': message.correlation_id
                })
                # Keep only last N messages
                max_history = self.config.message_history_size
                if len(history) > max_history:
                    history.pop(0)
    
    def get_missed_messages(self, session_id: str, last_message_id: str) -> List[Dict]:
        """
        Get messages the client missed since last_message_id.
        
        Used for reconnection - client provides last message they received,
        server sends anything they missed.
        """
        with self._lock:
            session = self._sessions.get(session_id)
            if not session:
                return []
            
            history = session.get('message_history', [])
            
            # Find index of last_message_id
            start_idx = -1
            for i, msg in enumerate(history):
                if msg['id'] == last_message_id:
                    start_idx = i
                    break
            
            if start_idx == -1:
                # Message not found - send last few messages
                return history[-10:]
            
            # Send messages after that index
            return history[start_idx + 1:]
    
    def _cleanup_expired(self, force: bool = False):
        """Background thread to clean up expired sessions."""
        while self._running or force:
            if not force:
                time.sleep(60)  # Check every minute
            
            now = time.time()
            
            with self._lock:
                expired = []
                for session_id, session in self._sessions.items():
                    if now > session['expires_at']:
                        expired.append(session_id)
                
                for session_id in expired:
                    self.delete_session(session_id)
            
            if force:
                break
    
    def shutdown(self):
        """Stop cleanup thread."""
        self._running = False
        self._cleanup_thread.join(timeout=5)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get session manager statistics."""
        with self._lock:
            return {
                'active_sessions': len(self._sessions),
                'active_users': len(self._user_sessions),
                'session_timeout': self.config.session_timeout
            }


# ============================================================================
# HEARTBEAT MANAGER (Updated for runtime config)
# ============================================================================

class HeartbeatManager:
    """
    Manages heartbeat/ping-pong for connection health.
    
    Regularly pings clients to ensure they're still alive.
    Supports runtime updates to interval and timeout.
    """
    
    def __init__(self, engine: WebSocketEngine, config: ProtocolConfig):
        """
        Args:
            engine: WebSocket engine
            config: Protocol configuration
        """
        self.engine = engine
        self.config = config
        
        # Track last pong received
        self._last_pong: Dict[str, float] = {}
        
        self._lock = threading.RLock()
        self._running = True
        
        if config.heartbeat_enabled:
            self._thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
            self._thread.start()
    
    def update_config(self, new_config: ProtocolConfig) -> None:
        """Update configuration at runtime."""
        with self._lock:
            was_enabled = self.config.heartbeat_enabled
            self.config = new_config
            
            # Start thread if newly enabled
            if not was_enabled and new_config.heartbeat_enabled:
                self._running = True
                self._thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
                self._thread.start()
                logging.info("[Heartbeat] Heartbeat enabled at runtime")
            
            logging.info(f"[Heartbeat] Configuration updated: interval={new_config.heartbeat_interval}s")
    
    def _heartbeat_loop(self):
        """Background thread sending heartbeats."""
        while self._running and self.config.heartbeat_enabled:
            time.sleep(self.config.heartbeat_interval)
            self._send_heartbeats()
            self._check_dead_connections()
    
    def _send_heartbeats(self):
        """Send ping to all connections."""
        # This would need access to all connections
        # For now, just log
        logging.debug(f"[Heartbeat] Sending heartbeats (interval={self.config.heartbeat_interval}s)")
    
    def _check_dead_connections(self):
        """Check for connections that didn't respond to heartbeat."""
        now = time.time()
        dead = []
        
        with self._lock:
            for sid, last_pong in self._last_pong.items():
                if now - last_pong > self.config.heartbeat_timeout:
                    dead.append(sid)
        
        for sid in dead:
            logging.info(f"[Heartbeat] Client {sid} timed out, disconnecting")
            self.engine.disconnect_client(sid)
            with self._lock:
                self._last_pong.pop(sid, None)
    
    def record_pong(self, sid: str):
        """Record that we received a pong from a client."""
        with self._lock:
            self._last_pong[sid] = time.time()
    
    def shutdown(self):
        """Stop heartbeat thread."""
        self._running = False
        if hasattr(self, '_thread'):
            self._thread.join(timeout=5)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get heartbeat statistics."""
        with self._lock:
            return {
                'enabled': self.config.heartbeat_enabled,
                'interval': self.config.heartbeat_interval,
                'timeout': self.config.heartbeat_timeout,
                'active_clients': len(self._last_pong)
            }


# ============================================================================
# CAPABILITIES NEGOTIATION (Updated for runtime config)
# ============================================================================

@dataclass
class ClientCapabilities:
    """
    Features a client supports.
    
    Used during connection to negotiate protocol features.
    """
    protocol_versions: List[str]
    compression: List[str]
    encoding: List[str]
    max_message_size: int
    supports_ack: bool = True
    supports_reconnection: bool = True
    supports_binary: bool = False
    heartbeat_interval: Optional[int] = None
    features: Dict[str, bool] = field(default_factory=dict)
    client_type: str = "web"
    client_version: str = "unknown"
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'ClientCapabilities':
        """Create from dictionary."""
        return cls(
            protocol_versions=data.get('protocol_versions', ['1.0']),
            compression=data.get('compression', []),
            encoding=data.get('encoding', ['json']),
            max_message_size=data.get('max_message_size', 1024 * 1024),
            supports_ack=data.get('supports_ack', True),
            supports_reconnection=data.get('supports_reconnection', True),
            supports_binary=data.get('supports_binary', False),
            heartbeat_interval=data.get('heartbeat_interval'),
            features=data.get('features', {}),
            client_type=data.get('client_type', 'web'),
            client_version=data.get('client_version', 'unknown')
        )


class CapabilitiesNegotiator:
    """
    Negotiates protocol capabilities between client and server.
    Supports runtime updates to server capabilities.
    """
    
    def __init__(self, config: ProtocolConfig):
        """
        Args:
            config: Protocol configuration
        """
        self.config = config
    
    def update_config(self, new_config: ProtocolConfig) -> None:
        """Update configuration at runtime."""
        self.config = new_config
        logging.info("[CapabilitiesNegotiator] Configuration updated")
    
    def negotiate(self, client: ClientCapabilities) -> Dict[str, Any]:
        """
        Negotiate common capabilities.
        
        Returns:
            Agreed-upon capabilities
        """
        server_caps = self.config.get_server_capabilities()
        
        result = {
            'protocol_version': self._negotiate_protocol(client.protocol_versions),
            'compression': self._negotiate_compression(client.compression),
            'encoding': self._negotiate_encoding(client.encoding),
            'max_message_size': min(client.max_message_size, 
                                    server_caps.get('max_message_size', 256*1024)),
            'use_ack': client.supports_ack and server_caps.get('supports_ack', True),
            'use_reconnection': (client.supports_reconnection and 
                                 server_caps.get('supports_reconnection', True)),
            'heartbeat_interval': self._negotiate_heartbeat(client.heartbeat_interval),
            'features': self._negotiate_features(client.features)
        }
        
        return result
    
    def _negotiate_protocol(self, client_versions: List[str]) -> str:
        """Choose highest common protocol version."""
        server_versions = self.config.supported_versions
        
        for v in ['1.1', '1.0']:  # Highest first
            if v in client_versions and v in server_versions:
                return v
        
        return '1.0'  # Fallback
    
    def _negotiate_compression(self, client_compression: List[str]) -> Optional[str]:
        """Choose compression algorithm both support."""
        if not self.config.enable_compression:
            return None
        
        server_compression = ['gzip'] if self.config.enable_compression else []
        
        for algo in ['gzip', 'deflate']:
            if algo in client_compression and algo in server_compression:
                return algo
        
        return None
    
    def _negotiate_encoding(self, client_encoding: List[str]) -> str:
        """Choose encoding both support."""
        server_encoding = [self.config.default_encoding]
        
        for enc in ['msgpack', 'json']:
            if enc in client_encoding and enc in server_encoding:
                return enc
        
        return 'json'
    
    def _negotiate_heartbeat(self, client_interval: Optional[int]) -> Optional[int]:
        """Agree on heartbeat interval."""
        if not self.config.heartbeat_enabled:
            return None
        
        server_interval = self.config.heartbeat_interval
        
        if client_interval:
            return max(client_interval, server_interval)
        return server_interval
    
    def _negotiate_features(self, client_features: Dict[str, bool]) -> Dict[str, bool]:
        """Agree on optional features."""
        result = {}
        server_features = self.config.get_server_capabilities().get('features', {})
        
        for feature, supported in client_features.items():
            if supported and server_features.get(feature, False):
                result[feature] = True
        
        return result


# ============================================================================
# PROTOCOL MANAGER (Main Integration Point)
# ============================================================================

class WebSocketProtocolManager:
    """
    Main manager for WebSocket protocol features.
    
    Integrates with the engine to provide:
    - Standardized message format
    - Acknowledgment tracking
    - Session management
    - Heartbeat
    - Capabilities negotiation
    - Runtime updates to protocol settings
    """
    
    def __init__(
        self,
        engine: WebSocketEngine,
        config: ProtocolConfig
    ):
        """
        Initialize protocol manager.
        
        Args:
            engine: WebSocket engine
            config: Protocol configuration
        """
        self.engine = engine
        self.config = config
        
        # Sub-managers (pass config to each)
        self.ack_manager = AcknowledgmentManager(config)
        self.session_manager = SessionManager(config)
        self.heartbeat = HeartbeatManager(engine, config)
        self.capabilities = CapabilitiesNegotiator(config)
        
        # Statistics
        self.stats = {
            'messages_sent': 0,
            'messages_received': 0,
            'acks_sent': 0,
            'acks_received': 0,
            'sessions_created': 0,
            'sessions_restored': 0,
            'heartbeats_sent': 0
        }
        
        # Locks for thread safety
        self._lock = threading.RLock()
        
        # Register hooks
        self._register_hooks()
        
        logging.info("[WebSocketProtocol] Protocol manager initialized")
        logging.info(f"  - Protocol version: {config.protocol_version}")
        logging.info(f"  - Session timeout: {config.session_timeout}s")
        logging.info(f"  - Heartbeat: {config.heartbeat_interval}s interval")
        logging.info(f"  - Acknowledgments: {config.require_ack}")
        logging.info(f"  - Reconnection: {config.enable_reconnection}")
    
    # ========================================================================
    # RUNTIME UPDATE METHODS
    # ========================================================================
    
    def update_config(self, new_config: ProtocolConfig) -> None:
        """
        Update protocol configuration at runtime.
        
        This method is called by the WebSocketConfigManager when
        protocol settings are updated.
        
        Args:
            new_config: Updated protocol configuration
        """
        with self._lock:
            old_config = self.config
            self.config = new_config
            
            # Update sub-managers
            self.ack_manager.update_config(new_config)
            self.session_manager.update_config(new_config)
            self.heartbeat.update_config(new_config)
            self.capabilities.update_config(new_config)
            
            logging.info("[WebSocketProtocol] Configuration updated at runtime")
    
    def _register_hooks(self):
        """Register hooks with the engine."""
        
        @self.engine.before_connect
        def handle_connect(conn_info: ConnectionInfo) -> bool:
            """Handle new connection - negotiate protocol."""
            return True
        
        @self.engine.after_connect
        def send_welcome(conn_info: ConnectionInfo):
            """Send welcome message with protocol info."""
            welcome = MessageEnvelope.create_event(
                event="system.welcome",
                payload={
                    "server_time": time.time(),
                    "protocol_version": self.config.protocol_version,
                    "session_id": conn_info.sid,
                    "heartbeat_interval": self.config.heartbeat_interval if self.config.heartbeat_enabled else None
                }
            )
            self.send_message(conn_info.sid, welcome)
        
        @self.engine.before_event
        def process_message(event: str, data: Any, conn_info: ConnectionInfo) -> bool:
            """Process incoming message through protocol layer."""
            return self._process_incoming(event, data, conn_info)
    
    def _process_incoming(self, event: str, data: Any, conn_info: ConnectionInfo) -> bool:
        """
        Process an incoming message.
        
        Returns:
            True if message should continue to handler, False if handled here
        """
        self.stats['messages_received'] += 1
        
        # Try to parse as envelope
        try:
            if isinstance(data, dict):
                envelope = MessageEnvelope.from_dict(data)
            else:
                # Raw message - wrap it
                envelope = MessageEnvelope.create_event(event, data)
                envelope.client_id = conn_info.sid
        except Exception as e:
            # Malformed message
            self._send_error(conn_info.sid, "malformed_message", str(e))
            return False
        
        # Check expiration
        if envelope.is_expired():
            self._send_error(conn_info.sid, "message_expired", 
                            f"Message {envelope.id} expired")
            return False
        
        # Handle acknowledgments
        if envelope.requires_ack() and self.config.require_ack:
            # Send acknowledgment
            ack = MessageEnvelope.create_ack(envelope.id)
            self.send_message(conn_info.sid, ack)
            self.stats['acks_sent'] += 1
        
        # Handle control messages
        if envelope.is_control_message:
            return self._handle_control_message(envelope, conn_info)
        
        # For regular messages, continue to handler
        return True
    
    def _handle_control_message(self, envelope: MessageEnvelope, 
                                conn_info: ConnectionInfo) -> bool:
        """
        Handle control messages internally.
        
        Returns:
            False (message handled, don't pass to handler)
        """
        if envelope.type == MessageType.PING:
            # Respond with pong
            pong = MessageEnvelope.create_event("system.pong", {
                "timestamp": time.time(),
                "in_response_to": envelope.id
            })
            self.send_message(conn_info.sid, pong)
            self.stats['heartbeats_sent'] += 1
            
        elif envelope.type == MessageType.PONG:
            # Record pong
            self.heartbeat.record_pong(conn_info.sid)
            
        elif envelope.type == MessageType.ACK:
            # Process acknowledgment
            message_id = envelope.payload.get('ack_for') if isinstance(envelope.payload, dict) else None
            if message_id:
                self.ack_manager.receive_ack(message_id)
                self.stats['acks_received'] += 1
                
        elif envelope.type == MessageType.CAPABILITIES:
            # Handle capabilities negotiation
            client_caps = ClientCapabilities.from_dict(envelope.payload)
            negotiated = self.capabilities.negotiate(client_caps)
            
            response = MessageEnvelope.create_response(
                envelope,
                payload=negotiated
            )
            self.send_message(conn_info.sid, response)
            
        elif envelope.type == MessageType.RECONNECT:
            # Handle reconnection
            session_id = envelope.payload.get('session_id') if isinstance(envelope.payload, dict) else None
            last_message_id = envelope.payload.get('last_message_id')
            
            if session_id and self.session_manager.restore_session(session_id, conn_info):
                # Session restored - send missed messages
                missed = self.session_manager.get_missed_messages(session_id, last_message_id)
                if missed:
                    replay = MessageEnvelope.create_event(
                        "system.replay",
                        {"messages": missed}
                    )
                    self.send_message(conn_info.sid, replay)
                self.stats['sessions_restored'] += 1
            else:
                # Create new session
                session_id = self.session_manager.create_session(
                    client_id=envelope.client_id or conn_info.sid,
                    user_id=conn_info.user_id
                )
                self.stats['sessions_created'] += 1
                
                response = MessageEnvelope.create_response(
                    envelope,
                    payload={"session_id": session_id}
                )
                self.send_message(conn_info.sid, response)
        
        return False  # Don't pass to regular handlers
    
    def send_message(self, sid: str, envelope: MessageEnvelope):
        """
        Send a message to a client.
        
        Args:
            sid: Session ID
            envelope: Message envelope to send
        """
        # Add server timestamp
        envelope.timestamp = time.time()
        
        # Convert to dict and send
        self.engine.emit(envelope.event, envelope.to_dict(), room=sid)
        self.stats['messages_sent'] += 1
        
        # Track for acknowledgment if needed
        if envelope.requires_ack() and self.config.require_ack:
            self.ack_manager.expect_ack(
                envelope.id,
                on_ack=lambda: self._on_ack_received(envelope.id),
                on_timeout=lambda: self._on_ack_timeout(envelope.id)
            )
        
        # Add to session history
        session = self.session_manager.get_session_by_client(sid)
        if session:
            self.session_manager.add_to_history(session['session_id'], envelope)
    
    def broadcast(self, envelope: MessageEnvelope, skip_sid: Optional[str] = None):
        """Broadcast a message to all connected clients."""
        envelope.timestamp = time.time()
        self.engine.broadcast(envelope.event, envelope.to_dict(), skip_sid=skip_sid)
        self.stats['messages_sent'] += 1
    
    def _send_error(self, sid: str, code: str, message: str, details: Optional[Dict] = None):
        """Send an error message."""
        error = MessageEnvelope.create_error("", code, message, details)
        self.send_message(sid, error)
    
    def _on_ack_received(self, message_id: str):
        """Callback when acknowledgment received."""
        pass
    
    def _on_ack_timeout(self, message_id: str):
        """Callback when acknowledgment times out."""
        if self.ack_manager.should_retry(message_id):
            self.ack_manager.mark_retry(message_id)
            # Retry logic would go here
    
    def get_stats(self) -> Dict[str, Any]:
        """Get protocol statistics."""
        with self._lock:
            return {
                **self.stats,
                'ack_manager': self.ack_manager.get_stats(),
                'session_manager': self.session_manager.get_stats(),
                'heartbeat': self.heartbeat.get_stats(),
                'config': self.config.to_dict()
            }
    
    def shutdown(self):
        """Gracefully shut down protocol manager."""
        self.ack_manager.shutdown()
        self.session_manager.shutdown()
        self.heartbeat.shutdown()
        logging.info("[WebSocketProtocol] Protocol manager shut down")


# ============================================================================
# FACTORY FUNCTION
# ============================================================================

def setup_websocket_protocol(
    engine: WebSocketEngine,
    config: ProtocolConfig
) -> WebSocketProtocolManager:
    """
    Set up WebSocket protocol management.
    
    Args:
        engine: WebSocket engine instance
        config: Protocol configuration
        
    Returns:
        Configured WebSocketProtocolManager
    """
    manager = WebSocketProtocolManager(engine, config)
    return manager