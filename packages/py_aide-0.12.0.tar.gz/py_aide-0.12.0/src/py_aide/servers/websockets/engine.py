"""
WebSocket Engine Module - Core WebSocket Server Implementation

This module provides the central WebSocket engine that:
1. Defines EngineConfig with all engine-specific settings
2. Provides validation methods for runtime updates
3. Manages connection lifecycle (connect, disconnect, errors)
4. Tracks connections and statistics
5. Handles graceful shutdown and cleanup

The engine is designed to work with the WebSocketConfigManager for runtime updates.
"""

import time
import uuid
import logging
import traceback
import threading
from typing import Dict, List, Any, Optional, Callable, Set, Union
from dataclasses import dataclass, field
from functools import wraps
from enum import Enum

from flask import Flask, request
from flask_socketio import SocketIO, emit, join_room, leave_room, disconnect


# ============================================================================
# ENUMS
# ============================================================================

class LogLevel(str, Enum):
    """Logging verbosity levels"""
    NONE = "none"
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"
    DEBUG = "debug"


# ============================================================================
# ENGINE CONFIGURATION
# ============================================================================

@dataclass
class EngineConfig:
    """
    Configuration for WebSocket Engine.
    
    All engine-specific settings are defined here with validation methods
    to support runtime updates through the WebSocketConfigManager.
    
    Each setting can have:
    - A validate_<setting> method for runtime updates
    - An on_<setting>_updated hook to react to changes
    """
    
    # ========================================================================
    # CONNECTION LIFECYCLE SETTINGS
    # ========================================================================
    
    ping_interval: int = 30
    """
    How often the server sends ping frames to clients (seconds).
    
    Trade-offs:
        - Lower values: Faster dead connection detection, more network traffic
        - Higher values: Less overhead, slower detection of disconnected clients
    """
    
    ping_timeout: int = 10
    """
    How long to wait for a pong response before closing connection (seconds).
    Must be less than ping_interval.
    """
    
    disconnect_timeout: int = 60
    """
    Maximum time a client can take to disconnect gracefully (seconds).
    After this, the server forcibly closes the connection.
    """
    
    # ========================================================================
    # CONNECTION LIMITS
    # ========================================================================
    
    max_connections_per_ip: int = 100
    """
    Maximum concurrent connections from a single IP address.
    Set to 0 for unlimited (not recommended in production).
    """
    
    max_connections_per_user: int = 5
    """
    Maximum concurrent connections per authenticated user.
    Set to 0 for unlimited.
    """
    
    max_message_size: int = 256 * 1024  # 256KB
    """
    Maximum allowed message size in bytes.
    Critical for preventing memory exhaustion attacks.
    """
    
    # ========================================================================
    # CORS SETTINGS
    # ========================================================================
    
    cors_allowed_origins: Union[List[str], str] = field(default_factory=list)
    """
    Allowed origins for WebSocket connections.
    
    Formats:
        - List of strings: ["https://example.com", "https://app.example.com"]
        - "*" : Allow all origins (development only!)
        - [] : Allow same-origin only (most secure)
    """
    
    # ========================================================================
    # PERFORMANCE SETTINGS
    # ========================================================================
    
    async_mode: str = "eventlet"
    """
    Async worker mode for Socket.IO.
    
    Only "eventlet" is supported. gevent and threading have known
    compatibility issues with newer Python versions and are not permitted.
    Changing this value will raise a ValueError at startup.
    """
    
    # ========================================================================
    # LOGGING SETTINGS
    # ========================================================================
    
    log_level: LogLevel = LogLevel.INFO
    """
    Verbosity of WebSocket-related logging.
    """
    
    log_messages: bool = False
    """
    Whether to log individual messages (very verbose, debug only).
    """
    
    # ========================================================================
    # ADVANCED OPTIONS
    # ========================================================================
    
    engineio_options: Dict[str, Any] = field(default_factory=dict)
    """
    Raw Engine.IO options for advanced users.
    These override any settings above.
    """
    
    # ========================================================================
    # VALIDATION METHODS (for runtime updates)
    # ========================================================================
    
    def validate_ping_interval(self, value: int) -> None:
        """
        Validate ping_interval before runtime update.
        
        Args:
            value: New ping_interval value
            
        Raises:
            ValueError: If validation fails
        """
        if value < 1:
            raise ValueError(f"ping_interval must be at least 1 second, got {value}")
        if value <= self.ping_timeout:
            raise ValueError(
                f"ping_interval ({value}) must be greater than "
                f"ping_timeout ({self.ping_timeout})"
            )
    
    def validate_ping_timeout(self, value: int) -> None:
        """
        Validate ping_timeout before runtime update.
        
        Args:
            value: New ping_timeout value
            
        Raises:
            ValueError: If validation fails
        """
        if value < 1:
            raise ValueError(f"ping_timeout must be at least 1 second, got {value}")
        if value >= self.ping_interval:
            raise ValueError(
                f"ping_timeout ({value}) must be less than "
                f"ping_interval ({self.ping_interval})"
            )
    
    def validate_max_connections_per_ip(self, value: int) -> None:
        """
        Validate max_connections_per_ip before runtime update.
        
        Args:
            value: New max_connections_per_ip value
            
        Raises:
            ValueError: If validation fails
        """
        if value < 0:
            raise ValueError(f"max_connections_per_ip cannot be negative, got {value}")
        if value > 10000:
            # Warn but don't block - just log a warning
            logging.warning(f"Very high max_connections_per_ip: {value}")
    
    def validate_max_connections_per_user(self, value: int) -> None:
        """
        Validate max_connections_per_user before runtime update.
        
        Args:
            value: New max_connections_per_user value
            
        Raises:
            ValueError: If validation fails
        """
        if value < 0:
            raise ValueError(f"max_connections_per_user cannot be negative, got {value}")
    
    def validate_max_message_size(self, value: int) -> None:
        """
        Validate max_message_size before runtime update.
        
        Args:
            value: New max_message_size value in bytes
            
        Raises:
            ValueError: If validation fails
        """
        if value < 1024:  # 1KB
            raise ValueError(f"max_message_size too low ({value} bytes). Minimum 1024 bytes.")
        if value > 100 * 1024 * 1024:  # 100MB
            raise ValueError(f"max_message_size too high ({value} bytes). Maximum 100MB.")
    
    def validate_cors_allowed_origins(self, value: Union[List[str], str]) -> None:
        """
        Validate cors_allowed_origins before runtime update.
        
        Args:
            value: New cors_allowed_origins value
            
        Raises:
            ValueError: If validation fails
        """
        if value == "*":
            logging.warning("CORS allowed_origins='*' allows any origin. Not recommended for production.")
        elif isinstance(value, list):
            for origin in value:
                if not isinstance(origin, str):
                    raise ValueError(f"Invalid origin type in list: {type(origin)}")
        elif not isinstance(value, str):
            raise ValueError(f"cors_allowed_origins must be list, string, or '*', got {type(value)}")
    
    def validate_async_mode(self, value: str) -> None:
        """
        Validate async_mode before runtime update.
        
        Args:
            value: New async_mode value
            
        Raises:
            ValueError: Always — async_mode is fixed to 'eventlet'.
        """
        if value != "eventlet":
            raise ValueError(
                f"async_mode '{value}' is not supported. "
                "Only 'eventlet' is permitted. gevent and threading have "
                "known compatibility issues with newer Python versions."
            )
    
    def validate_log_level(self, value: LogLevel) -> None:
        """
        Validate log_level before runtime update.
        
        Args:
            value: New log_level value
            
        Raises:
            ValueError: If validation fails
        """
        if not isinstance(value, LogLevel):
            try:
                # Try to convert from string
                LogLevel(value)
            except ValueError:
                valid = [lvl.value for lvl in LogLevel]
                raise ValueError(f"log_level must be one of {valid}, got '{value}'")
    
    # ========================================================================
    # UPDATE HOOKS (called after successful runtime updates)
    # ========================================================================
    
    def on_ping_interval_updated(self, value: int) -> None:
        """
        Hook called after ping_interval is updated at runtime.
        Override in subclass if needed.
        
        Args:
            value: New ping_interval value
        """
        logging.info(f"ping_interval updated to {value}s")
    
    def on_ping_timeout_updated(self, value: int) -> None:
        """
        Hook called after ping_timeout is updated at runtime.
        
        Args:
            value: New ping_timeout value
        """
        logging.info(f"ping_timeout updated to {value}s")
    
    def on_max_connections_per_ip_updated(self, value: int) -> None:
        """
        Hook called after max_connections_per_ip is updated at runtime.
        
        Args:
            value: New max_connections_per_ip value
        """
        logging.info(f"max_connections_per_ip updated to {value}")
    
    def on_max_message_size_updated(self, value: int) -> None:
        """
        Hook called after max_message_size is updated at runtime.
        
        Args:
            value: New max_message_size value in bytes
        """
        logging.info(f"max_message_size updated to {value} bytes")
    
    # ========================================================================
    # INITIAL VALIDATION (called at startup)
    # ========================================================================
    
    def __post_init__(self):
        """Validate configuration at startup."""
        self._validate_async_mode()
        self._validate_ping_settings()
        self._validate_limits()
        self._validate_cors()
    
    def _validate_async_mode(self):
        """Enforce eventlet-only restriction."""
        if self.async_mode != "eventlet":
            raise ValueError(
                f"async_mode='{self.async_mode}' is not supported. "
                "Only 'eventlet' is permitted. gevent and threading have "
                "known compatibility issues with newer Python versions."
            )
    
    def _validate_ping_settings(self):
        """Ensure ping settings are consistent."""
        if self.ping_timeout >= self.ping_interval:
            raise ValueError(
                f"ping_timeout ({self.ping_timeout}) must be less than "
                f"ping_interval ({self.ping_interval})"
            )
        
        if self.ping_interval < 5:
            logging.warning(
                f"Very low ping_interval ({self.ping_interval}s) may cause "
                "excessive network traffic"
            )
    
    def _validate_limits(self):
        """Ensure numeric limits are reasonable."""
        if self.max_message_size < 1024:
            logging.warning(
                f"Very low max_message_size ({self.max_message_size} bytes) "
                "may reject legitimate messages"
            )
        
        if self.max_message_size > 10 * 1024 * 1024:
            logging.warning(
                f"Very high max_message_size ({self.max_message_size} bytes) "
                "may expose server to memory exhaustion attacks"
            )
    
    def _validate_cors(self):
        """Validate CORS configuration."""
        if self.cors_allowed_origins == "*":
            logging.warning(
                "CORS allowed_origins='*' in engine config! "
                "This allows ANY website to connect to your WebSocket."
            )


# ============================================================================
# DATA CLASSES (Connection tracking)
# ============================================================================

@dataclass
class ConnectionInfo:
    """
    Tracks information about an active WebSocket connection.
    
    Used for:
    - Connection monitoring and debugging
    - Enforcing per-user connection limits
    - Audit logging
    - Graceful disconnection
    """
    connection_id: str
    """Unique identifier for this connection"""
    
    sid: str
    """Socket.IO session ID"""
    
    client_ip: str
    """Client IP address"""
    
    user_agent: str
    """User agent string"""
    
    connected_at: float
    """Timestamp when connection was established"""
    
    user_id: Optional[str] = None
    """Authenticated user ID (if authenticated)"""
    
    last_activity: float = field(default_factory=time.time)
    """Timestamp of last message/activity"""
    
    message_count: int = 0
    """Number of messages received on this connection"""
    
    error_count: int = 0
    """Number of errors on this connection"""
    
    rooms: Set[str] = field(default_factory=set)
    """Rooms/channels this connection has joined"""
    
    metadata: Dict[str, Any] = field(default_factory=dict)
    """Additional application-specific data"""
    
    @property
    def connection_duration(self) -> float:
        """How long this connection has been active (seconds)"""
        return time.time() - self.connected_at
    
    @property
    def is_authenticated(self) -> bool:
        """Whether this connection is authenticated"""
        return self.user_id is not None
    
    @property
    def is_idle(self) -> bool:
        """Whether connection is idle (no activity for >5 minutes)"""
        return (time.time() - self.last_activity) > 300


@dataclass
class ConnectionStats:
    """
    Aggregated connection statistics.
    
    Used for monitoring, alerting, and capacity planning.
    """
    total_connections: int = 0
    """Total connections ever established"""
    
    active_connections: int = 0
    """Currently active connections"""
    
    authenticated_connections: int = 0
    """Currently authenticated connections"""
    
    connections_by_ip: Dict[str, int] = field(default_factory=dict)
    """Connections per IP address"""
    
    connections_by_user: Dict[str, int] = field(default_factory=dict)
    """Connections per user ID"""
    
    messages_received: int = 0
    """Total messages received"""
    
    messages_sent: int = 0
    """Total messages sent"""
    
    errors: int = 0
    """Total errors encountered"""
    
    rejected_connections: int = 0
    """Connections rejected due to limits"""
    
    peak_connections: int = 0
    """Peak concurrent connections"""
    
    peak_timestamp: float = field(default_factory=time.time)
    """When peak connections occurred"""
    
    start_time: float = field(default_factory=time.time)
    """When this stats collection started"""
    
    @property
    def uptime(self) -> float:
        """How long stats have been collected (seconds)"""
        return time.time() - self.start_time


# ============================================================================
# ENGINE CLASS
# ============================================================================

class WebSocketEngine:
    """
    Core WebSocket engine that manages all real-time connections.
    
    This is the heart of the WebSocket system. It:
    - Initializes and configures Socket.IO
    - Manages connection lifecycle
    - Tracks connections and statistics
    - Provides event registration and dispatching
    - Handles errors and graceful shutdown
    
    The engine uses EngineConfig for all settings and supports runtime updates
    through the WebSocketConfigManager.
    
    Usage:
        >>> config = EngineConfig(ping_interval=30)
        >>> engine = WebSocketEngine(app, config)
        >>> engine.init_app()
        >>> 
        >>> @engine.on('chat_message')
        >>> def handle_chat(data):
        >>>     print(f"Message: {data}")
        >>> 
        >>> engine.run(host='0.0.0.0', port=5000)
    """
    
    def __init__(self, app: Flask, config: EngineConfig):
        """
        Initialize the WebSocket engine.
        
        Args:
            app: Flask application instance
            config: Engine configuration
        """
        self.app = app
        self.config = config
        self.socketio: Optional[SocketIO] = None
        self._initialized = False
        self._running = False
        
        # Connection tracking
        self._connections: Dict[str, ConnectionInfo] = {}
        """Maps Socket.IO session IDs to connection info"""
        
        self._connections_by_ip: Dict[str, Set[str]] = {}
        """Maps IP addresses to sets of session IDs"""
        
        self._connections_by_user: Dict[str, Set[str]] = {}
        """Maps user IDs to sets of session IDs"""
        
        # Statistics
        self.stats = ConnectionStats()
        
        # Event handlers
        self._event_handlers: Dict[str, List[Callable]] = {}
        """Maps event names to lists of handler functions"""
        
        # Middleware hooks
        self._before_connect_hooks: List[Callable] = []
        self._after_connect_hooks: List[Callable] = []
        self._before_disconnect_hooks: List[Callable] = []
        self._after_disconnect_hooks: List[Callable] = []
        self._before_event_hooks: List[Callable] = []
        self._after_event_hooks: List[Callable] = []
        
        # Setup logging
        self._setup_logging()
        
        # Lock for thread safety
        self._lock = threading.RLock()
        
        logging.info(f"[WebSocketEngine] Initialized with config: ping={config.ping_interval}s, timeout={config.ping_timeout}s")
    
    def _setup_logging(self):
        """Configure logging based on config."""
        log_levels = {
            LogLevel.NONE: logging.CRITICAL + 1,
            LogLevel.ERROR: logging.ERROR,
            LogLevel.WARNING: logging.WARNING,
            LogLevel.INFO: logging.INFO,
            LogLevel.DEBUG: logging.DEBUG,
        }
        
        level = log_levels.get(self.config.log_level, logging.INFO)
        logging.getLogger('socketio').setLevel(level)
        logging.getLogger('engineio').setLevel(level)
    
    # ========================================================================
    # RUNTIME UPDATE METHODS (called by ConfigManager)
    # ========================================================================
    
    def update_config(self, new_config: EngineConfig) -> None:
        """
        Update engine configuration at runtime.
        
        This method is called by the WebSocketConfigManager when
        engine settings are updated. It applies the new configuration
        and updates Socket.IO if necessary.
        
        Args:
            new_config: Updated engine configuration
        """
        with self._lock:
            old_config = self.config
            self.config = new_config
            
            # Update Socket.IO if needed
            if self.socketio and self._needs_reinit(old_config, new_config):
                self._reinit_socketio()
            
            logging.info("[WebSocketEngine] Configuration updated at runtime")
    
    def _needs_reinit(self, old: EngineConfig, new: EngineConfig) -> bool:
        """
        Check if Socket.IO needs to be reinitialized due to config changes.
        
        Some settings (like ping_interval) require Socket.IO reinit.
        """
        # Settings that require Socket.IO reinitialization
        critical_settings = [
            'ping_interval',
            'ping_timeout',
            'max_message_size',
            'cors_allowed_origins',
            'async_mode'
        ]
        
        for setting in critical_settings:
            if getattr(old, setting) != getattr(new, setting):
                return True
        
        return False
    
    def _reinit_socketio(self):
        """Reinitialize Socket.IO with new configuration."""
        if not self.socketio:
            return
        
        # Store current connections
        current_connections = list(self._connections.keys())
        
        # Create new Socket.IO instance
        options = self._build_socketio_options()
        self.socketio = SocketIO(self.app, **options)
        
        # Re-register core handlers
        self._register_core_handlers()
        
        # Re-register event handlers
        for event, handlers in self._event_handlers.items():
            for handler in handlers:
                self.socketio.on(event)(handler)
        
        logging.info(f"[WebSocketEngine] Socket.IO reinitialized with new config")
    
    # ========================================================================
    # INITIALIZATION
    # ========================================================================
    
    def init_app(self) -> None:
        """
        Initialize Socket.IO with the Flask app.
        
        This must be called before any connections are accepted.
        
        Raises:
            RuntimeError: If eventlet is not installed or has not been
                         monkey-patched before this call.
        """
        if self._initialized:
            return
        
        # ── Eventlet guard ──────────────────────────────────────────────────
        # eventlet must be installed AND monkey-patched.  Skipping the patch
        # causes Socket.IO to silently fall back to blocking I/O, which will
        # deadlock under any real concurrent load.
        try:
            import eventlet
        except ImportError:
            raise RuntimeError(
                "eventlet is not installed. "
                "Install it with: pip install eventlet"
            )
        
        if not getattr(eventlet, '_monkey_patched', False):
            raise RuntimeError(
                "eventlet.monkey_patch() has not been called. "
                "Add the following lines at the very top of your entry-point "
                "script, before any other imports:\n\n"
                "    import eventlet\n"
                "    eventlet.monkey_patch()\n"
            )
        # ────────────────────────────────────────────────────────────────────
        
        # Build Socket.IO options from config
        socketio_options = self._build_socketio_options()
        
        # Create Socket.IO instance
        self.socketio = SocketIO(
            self.app,
            **socketio_options
        )
        
        # Register core event handlers
        self._register_core_handlers()
        
        self._initialized = True
        logging.info("[WebSocketEngine] Initialization complete")
    
    def _build_socketio_options(self) -> Dict[str, Any]:
        """
        Build Socket.IO options dictionary from configuration.
        """
        options = {
            'ping_interval': self.config.ping_interval,
            'ping_timeout': self.config.ping_timeout,
            'max_http_buffer_size': self.config.max_message_size,
            'cors_allowed_origins': self.config.cors_allowed_origins,
            'async_mode': self.config.async_mode,
            'engineio_logger': self.config.log_level == LogLevel.DEBUG,
            'logger': self.config.log_level == LogLevel.DEBUG,
            'cors_credentials': True,
        }
        
        # Add engineio_options if provided (overrides defaults)
        if self.config.engineio_options:
            options.update(self.config.engineio_options)
        
        return options
    
    # ========================================================================
    # CORE HANDLERS
    # ========================================================================
    
    def _register_core_handlers(self):
        """Register the fundamental Socket.IO event handlers."""
        
        @self.socketio.on('connect')
        def handle_connect():
            self._handle_connect()
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            self._handle_disconnect()
        
        @self.socketio.on_error()
        def handle_error(e):
            self._handle_error(e)
        
        @self.socketio.on_error_default
        def handle_default_error(e):
            self._handle_error(e, is_default=True)
    
    def _handle_connect(self):
        """
        Process a new connection request.
        """
        connection_id = str(uuid.uuid4())
        client_ip = request.remote_addr or 'unknown'
        user_agent = request.headers.get('User-Agent', 'unknown')
        
        conn_info = ConnectionInfo(
            connection_id=connection_id,
            sid=request.sid,
            client_ip=client_ip,
            user_agent=user_agent,
            connected_at=time.time()
        )
        
        # Run before_connect hooks
        if not self._run_before_connect_hooks(conn_info):
            return False
        
        # Enforce IP-based connection limits
        if not self._check_ip_limits(client_ip):
            self.stats.rejected_connections += 1
            if self.config.log_level != LogLevel.NONE:
                logging.info(f"[WebSocket] Rejected connection from {client_ip}: too many connections")
            return False
        
        # Store connection info
        with self._lock:
            self._connections[request.sid] = conn_info
            
            # Update IP tracking
            if client_ip not in self._connections_by_ip:
                self._connections_by_ip[client_ip] = set()
            self._connections_by_ip[client_ip].add(request.sid)
        
        # Update statistics
        self.stats.total_connections += 1
        self.stats.active_connections = len(self._connections)
        self.stats.connections_by_ip[client_ip] = len(self._connections_by_ip.get(client_ip, set()))
        
        # Track peak connections
        if self.stats.active_connections > self.stats.peak_connections:
            self.stats.peak_connections = self.stats.active_connections
            self.stats.peak_timestamp = time.time()
        
        # Log connection
        if self.config.log_level in (LogLevel.INFO, LogLevel.DEBUG):
            logging.info(f"[WebSocket] Client connected: {request.sid} from {client_ip} "
                         f"(total: {self.stats.active_connections})")
        
        # Run after_connect hooks
        self._run_after_connect_hooks(conn_info)
        
        return True
    
    def _handle_disconnect(self):
        """Process a disconnection."""
        sid = request.sid
        
        with self._lock:
            if sid not in self._connections:
                if self.config.log_level != LogLevel.NONE:
                    logging.info(f"[WebSocket] Unknown client disconnected: {sid}")
                return
            
            conn_info = self._connections[sid]
            client_ip = conn_info.client_ip
            user_id = conn_info.user_id
            
            # Run before_disconnect hooks
            self._run_before_disconnect_hooks(conn_info)
            
            # Remove from tracking
            del self._connections[sid]
            
            # Update IP tracking
            if client_ip in self._connections_by_ip:
                self._connections_by_ip[client_ip].discard(sid)
                if not self._connections_by_ip[client_ip]:
                    del self._connections_by_ip[client_ip]
            
            # Update user tracking
            if user_id and user_id in self._connections_by_user:
                self._connections_by_user[user_id].discard(sid)
                if not self._connections_by_user[user_id]:
                    del self._connections_by_user[user_id]
        
        # Update statistics
        self.stats.active_connections = len(self._connections)
        self.stats.connections_by_ip[client_ip] = len(self._connections_by_ip.get(client_ip, set()))
        
        # Log disconnection
        if self.config.log_level in (LogLevel.INFO, LogLevel.DEBUG):
            duration = time.time() - conn_info.connected_at
            logging.info(f"[WebSocket] Client disconnected: {sid} from {client_ip} "
                         f"(duration: {duration:.1f}s, total: {self.stats.active_connections})")
        
        # Run after_disconnect hooks
        self._run_after_disconnect_hooks(conn_info)
    
    def _handle_error(self, error: Exception, is_default: bool = False):
        """
        Handle errors in WebSocket operations.
        """
        sid = getattr(request, 'sid', 'unknown')
        error_type = type(error).__name__
        error_msg = str(error)
        
        # Update statistics
        self.stats.errors += 1
        
        # Update connection error count if we know the connection
        if sid in self._connections:
            self._connections[sid].error_count += 1
        
        # Log error
        if self.config.log_level != LogLevel.NONE:
            logging.error(f"[WebSocket] Error on {sid}: {error_type} - {error_msg}")
            
            if self.config.log_level == LogLevel.DEBUG:
                traceback.print_exc()
        
        # In debug mode, send error back to client
        if self.config.log_level == LogLevel.DEBUG and sid != 'unknown':
            try:
                emit('error', {
                    'type': error_type,
                    'message': error_msg,
                    'sid': sid
                })
            except:
                pass
    
    def _check_ip_limits(self, ip: str) -> bool:
        """
        Check if IP has exceeded connection limits.
        """
        if self.config.max_connections_per_ip <= 0:
            return True
        
        current = len(self._connections_by_ip.get(ip, set()))
        return current < self.config.max_connections_per_ip
    
    def _check_user_limits(self, user_id: str) -> bool:
        """
        Check if user has exceeded connection limits.
        """
        if self.config.max_connections_per_user <= 0:
            return True
        
        current = len(self._connections_by_user.get(user_id, set()))
        return current < self.config.max_connections_per_user
    
    # ========================================================================
    # HOOK MANAGEMENT
    # ========================================================================
    
    def before_connect(self, func: Callable) -> Callable:
        """Register a hook to run before accepting a connection."""
        self._before_connect_hooks.append(func)
        return func
    
    def after_connect(self, func: Callable) -> Callable:
        """Register a hook to run after connection is established."""
        self._after_connect_hooks.append(func)
        return func
    
    def before_disconnect(self, func: Callable) -> Callable:
        """Register a hook to run before disconnection."""
        self._before_disconnect_hooks.append(func)
        return func
    
    def after_disconnect(self, func: Callable) -> Callable:
        """Register a hook to run after disconnection."""
        self._after_disconnect_hooks.append(func)
        return func
    
    def before_event(self, func: Callable) -> Callable:
        """
        Register a hook to run before each event handler.
        
        The hook receives (event_name, data, connection_info).
        """
        self._before_event_hooks.append(func)
        return func
    
    def after_event(self, func: Callable) -> Callable:
        """
        Register a hook to run after each event handler.
        
        The hook receives (event_name, data, connection_info, result).
        """
        self._after_event_hooks.append(func)
        return func
    
    def _run_before_connect_hooks(self, conn_info: ConnectionInfo) -> bool:
        """Run all before_connect hooks."""
        for hook in self._before_connect_hooks:
            try:
                if hook(conn_info) is False:
                    return False
            except Exception as e:
                logging.error(f"[WebSocket] Before-connect hook failed: {e}")
        return True
    
    def _run_after_connect_hooks(self, conn_info: ConnectionInfo):
        """Run all after_connect hooks."""
        for hook in self._after_connect_hooks:
            try:
                hook(conn_info)
            except Exception as e:
                logging.error(f"[WebSocket] After-connect hook failed: {e}")
    
    def _run_before_disconnect_hooks(self, conn_info: ConnectionInfo):
        """Run all before_disconnect hooks."""
        for hook in self._before_disconnect_hooks:
            try:
                hook(conn_info)
            except Exception as e:
                logging.error(f"[WebSocket] Before-disconnect hook failed: {e}")
    
    def _run_after_disconnect_hooks(self, conn_info: ConnectionInfo):
        """Run all after_disconnect hooks."""
        for hook in self._after_disconnect_hooks:
            try:
                hook(conn_info)
            except Exception as e:
                logging.error(f"[WebSocket] After-disconnect hook failed: {e}")
    
    def _run_before_event_hooks(self, event: str, data: Any, conn_info: ConnectionInfo) -> bool:
        """Run all before_event hooks."""
        for hook in self._before_event_hooks:
            try:
                if hook(event, data, conn_info) is False:
                    return False
            except Exception as e:
                logging.error(f"[WebSocket] Before-event hook failed: {e}")
        return True
    
    def _run_after_event_hooks(self, event: str, data: Any, conn_info: ConnectionInfo, result: Any):
        """Run all after_event hooks."""
        for hook in self._after_event_hooks:
            try:
                hook(event, data, conn_info, result)
            except Exception as e:
                logging.error(f"[WebSocket] After-event hook failed: {e}")
    
    # ========================================================================
    # EVENT HANDLING
    # ========================================================================
    
    def on(self, event: str):
        """
        Decorator to register a WebSocket event handler.
        
        Example:
            >>> @engine.on('chat_message')
            >>> def handle_chat(data):
            >>>     return {'status': 'received'}
        """
        def decorator(func: Callable):
            if event not in self._event_handlers:
                self._event_handlers[event] = []
            
            @wraps(func)
            def wrapped_handler(*args, **kwargs):
                sid = request.sid
                conn_info = self._connections.get(sid)
                
                if not conn_info:
                    if self.config.log_level != LogLevel.NONE:
                        logging.warning(f"[WebSocket] Event from unknown connection: {sid}")
                    return
                
                # Update activity timestamp
                conn_info.last_activity = time.time()
                conn_info.message_count += 1
                
                # Update statistics
                self.stats.messages_received += 1
                
                # Parse data
                data = args[0] if args else kwargs
                
                # Run before_event hooks
                if not self._run_before_event_hooks(event, data, conn_info):
                    return
                
                # Process event
                try:
                    result = func(data)
                    
                    # Run after_event hooks
                    self._run_after_event_hooks(event, data, conn_info, result)
                    
                    # Send response if handler returned something
                    if result is not None:
                        emit(f'{event}_response', result)
                        self.stats.messages_sent += 1
                    
                except Exception as e:
                    self._handle_error(e)
                    emit('error', {'event': event, 'error': str(e)})
                    raise
            
            self._event_handlers[event].append(wrapped_handler)
            
            if self.socketio:
                self.socketio.on(event)(wrapped_handler)
            
            return wrapped_handler
        return decorator
    
    # ========================================================================
    # EMIT METHODS
    # ========================================================================
    
    def emit(self, event: str, data: Any, room: Optional[str] = None, 
             skip_sid: Optional[str] = None, callback: Optional[Callable] = None):
        """Emit an event to connected clients."""
        if not self.socketio:
            raise RuntimeError("Socket.IO not initialized")
        
        self.socketio.emit(event, data, room=room, skip_sid=skip_sid, callback=callback)
        self.stats.messages_sent += 1
    
    def emit_to_user(self, user_id: str, event: str, data: Any):
        """Emit an event to all connections of a specific user."""
        if user_id not in self._connections_by_user:
            return
        
        for sid in self._connections_by_user[user_id]:
            self.emit(event, data, room=sid)
    
    def emit_to_room(self, room: str, event: str, data: Any, skip_sid: Optional[str] = None):
        """Emit an event to all clients in a room."""
        self.emit(event, data, room=room, skip_sid=skip_sid)
    
    def broadcast(self, event: str, data: Any, skip_sid: Optional[str] = None):
        """Broadcast an event to all connected clients."""
        self.emit(event, data, room=None, skip_sid=skip_sid)
    
    # ========================================================================
    # ROOM MANAGEMENT
    # ========================================================================
    
    def join_room(self, room: str, sid: Optional[str] = None):
        """Make a client join a room."""
        sid = sid or request.sid
        join_room(room, sid=sid)
        
        if sid in self._connections:
            self._connections[sid].rooms.add(room)
    
    def leave_room(self, room: str, sid: Optional[str] = None):
        """Make a client leave a room."""
        sid = sid or request.sid
        leave_room(room, sid=sid)
        
        if sid in self._connections:
            self._connections[sid].rooms.discard(room)
    
    def get_room_clients(self, room: str) -> List[str]:
        """Get all client SIDs in a room."""
        if not self.socketio:
            return []
        return self.socketio.server.manager.get_participants('/', room)
    
    # ========================================================================
    # CONNECTION MANAGEMENT
    # ========================================================================
    
    def disconnect_client(self, sid: Optional[str] = None, silent: bool = False):
        """Forcefully disconnect a client."""
        sid = sid or request.sid
        disconnect(sid, silent=silent)
    
    def get_connection_info(self, sid: Optional[str] = None) -> Optional[ConnectionInfo]:
        """Get information about a connection."""
        sid = sid or request.sid
        return self._connections.get(sid)
    
    def get_connections_by_user(self, user_id: str) -> List[ConnectionInfo]:
        """Get all connections for a user."""
        sids = self._connections_by_user.get(user_id, set())
        return [self._connections[sid] for sid in sids if sid in self._connections]
    
    def get_connections_by_ip(self, ip: str) -> List[ConnectionInfo]:
        """Get all connections from an IP address."""
        sids = self._connections_by_ip.get(ip, set())
        return [self._connections[sid] for sid in sids if sid in self._connections]
    
    # ========================================================================
    # AUTHENTICATION (BRIDGE TO GATE PIPELINE)
    # ========================================================================
    
    def authenticate_connection(self, user_id: str, sid: Optional[str] = None, 
                                metadata: Optional[Dict] = None):
        """Mark a connection as authenticated."""
        sid = sid or request.sid
        
        if sid not in self._connections:
            return
        
        with self._lock:
            conn_info = self._connections[sid]
            old_user_id = conn_info.user_id
            
            # Update connection info
            conn_info.user_id = user_id
            if metadata:
                conn_info.metadata.update(metadata)
            
            # Update user tracking
            if old_user_id and old_user_id in self._connections_by_user:
                self._connections_by_user[old_user_id].discard(sid)
            
            if user_id not in self._connections_by_user:
                self._connections_by_user[user_id] = set()
            self._connections_by_user[user_id].add(sid)
        
        # Update statistics
        self.stats.authenticated_connections = len([
            c for c in self._connections.values() if c.is_authenticated
        ])
        self.stats.connections_by_user[user_id] = len(self._connections_by_user[user_id])
        
        if self.config.log_level != LogLevel.NONE:
            logging.info(f"[WebSocket] Connection {sid} authenticated as user {user_id}")
    
    # ========================================================================
    # STATISTICS
    # ========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get comprehensive engine statistics."""
        self.stats.authenticated_connections = len([
            c for c in self._connections.values() if c.is_authenticated
        ])
        
        stats_dict = {
            'connections': {
                'active': self.stats.active_connections,
                'total_ever': self.stats.total_connections,
                'authenticated': self.stats.authenticated_connections,
                'peak': self.stats.peak_connections,
                'peak_timestamp': self.stats.peak_timestamp,
                'rejected': self.stats.rejected_connections,
            },
            'messages': {
                'received': self.stats.messages_received,
                'sent': self.stats.messages_sent,
            },
            'errors': self.stats.errors,
            'uptime': self.stats.uptime,
            'config': {
                'ping_interval': self.config.ping_interval,
                'ping_timeout': self.config.ping_timeout,
                'max_connections_per_ip': self.config.max_connections_per_ip,
                'max_connections_per_user': self.config.max_connections_per_user,
                'max_message_size': self.config.max_message_size,
            }
        }
        
        if self.config.log_level == LogLevel.DEBUG:
            stats_dict['connections']['by_ip'] = {
                ip: len(sids) for ip, sids in self._connections_by_ip.items()
            }
            stats_dict['connections']['by_user'] = {
                user_id: len(sids) for user_id, sids in self._connections_by_user.items()
            }
        
        return stats_dict
    
    def get_connection_list(self, authenticated_only: bool = False) -> List[Dict]:
        """Get list of all connections (for debugging)."""
        connections = []
        
        for sid, info in self._connections.items():
            if authenticated_only and not info.is_authenticated:
                continue
            
            connections.append({
                'sid': sid,
                'connection_id': info.connection_id,
                'client_ip': info.client_ip,
                'user_agent': info.user_agent,
                'user_id': info.user_id,
                'connected_at': info.connected_at,
                'duration': info.connection_duration,
                'messages': info.message_count,
                'errors': info.error_count,
                'rooms': list(info.rooms),
                'is_authenticated': info.is_authenticated,
                'is_idle': info.is_idle,
            })
        
        return connections
    
    @property
    def active_connections(self) -> int:
        """Number of currently active connections."""
        return len(self._connections)
    
    # ========================================================================
    # LIFECYCLE MANAGEMENT
    # ========================================================================
    
    def run(self, host: str = '0.0.0.0', port: int = 5000, debug: bool = False):
        """Start the WebSocket server."""
        if not self._initialized:
            self.init_app()
        
        self._running = True

        logging.info(
            "WebSocket Engine Starting | host=%s port=%d mode=%s cors=%s "
            "limits=%d/IP %d/user log_level=%s",
            host, port, self.config.async_mode, self.config.cors_allowed_origins,
            self.config.max_connections_per_ip, self.config.max_connections_per_user,
            self.config.log_level
        )
        
        try:
            self.socketio.run(
                self.app,
                host=host,
                port=port,
                debug=debug,
                use_reloader=False
            )
        except KeyboardInterrupt:
            self.shutdown()
        except Exception as e:
            logging.error(f"[WebSocketEngine] Fatal error: {e}")
            traceback.print_exc()
            self.shutdown()
    
    def shutdown(self):
        """Gracefully shut down the WebSocket engine."""
        logging.info("WebSocketEngine shutting down...")
        
        self._running = False
        
        # Notify all connected clients
        if self.socketio and self.config.log_level != LogLevel.NONE:
            try:
                self.broadcast('server_shutdown', {
                    'message': 'Server is shutting down',
                    'grace_period': 5
                })
            except:
                pass
        
        # Give clients time to receive message
        time.sleep(1)
        
        # Disconnect all clients
        active = len(self._connections)
        if active > 0:
            logging.info("WebSocketEngine disconnecting %d clients...", active)
            for sid in list(self._connections.keys()):
                try:
                    self.disconnect_client(sid, silent=True)
                except:
                    pass
        
        # Log final stats
        logging.info(
            "WebSocketEngine shutdown complete | total_connections=%d messages=%d errors=%d uptime=%.1fs",
            self.stats.total_connections, self.stats.messages_received,
            self.stats.errors, self.stats.uptime
        )