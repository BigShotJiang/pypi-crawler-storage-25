"""
py_aide - Main package
This framework uses EVENTLET for WebSocket support.
Eventlet monkey patching happens IMMEDIATELY when this package is imported.
"""

import logging
import sys

logger = logging.getLogger(__name__)

def monkey_patch(all=True, os=True, select=True, socket=True, thread=True, time=True):
    """
    Safely monkey-patches the environment using Eventlet.
    
    This function adds safety guards for Werkzeug 3.0+ proxies and checks 
    for problematic import orders.
    
    Args:
        all: Patch all standard libraries (default)
        ... individual flags for eventlet.monkey_patch ...
    """
    try:
        import eventlet
        import eventlet.patcher
    except ImportError:
        logger.error("Eventlet is not installed. WebSockets will not function.")
        return False

    # 1. Check if already patched to avoid redundant work
    if eventlet.patcher.is_monkey_patched('socket'):
        return True

    # 2. Early Detection: Check for problematic late imports
    problematic = ['flask', 'werkzeug', 'requests', 'urllib3']
    loaded = [mod for mod in problematic if mod in sys.modules]
    
    if loaded:
        logger.warning(
            "\n" + "!"*80 + "\n"
            "LATE MONKEY-PATCH DETECTED:\n"
            f"The following modules were already imported: {', '.join(loaded)}\n"
            "By monkey-patching late, you may experience unexpected 'Hangs' or 'Deadlocks'.\n"
            "BEST PRACTICE: Call py_aide.monkey_patch() at the very top of your entry script.\n"
            "!"*80 + "\n"
        )

    # 3. Execution with Werkzeug 3.0+ Shielding
    try:
        # We pass arguments through to the underlying eventlet call
        eventlet.monkey_patch(
            all=all, os=os, select=select, socket=socket, 
            thread=thread, time=time
        )
        return True
    except RuntimeError as e:
        # This occurs specifically with Werkzeug 3.0+ LocalProxies 
        # during recursive module traversal.
        if "Working outside of" in str(e) or "request context" in str(e):
            logger.debug("Werkzeug proxy encountered during patching; skipping shield.")
            return True
        raise
    except Exception as e:
        logger.error(f"Eventlet monkey-patch failed: {e}")
        return False

from .response import Response, ok, error
from . import structures
from . import codes
from . import database
from . import enforcer
from . import encryption
from . import dates
from . import servers
from . import threading
from . import images
from . import tokens

from .customTypes import Definition, Options
from . import auth

