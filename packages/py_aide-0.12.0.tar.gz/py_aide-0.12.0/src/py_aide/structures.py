import types
from typing import get_origin, get_args, Union, Any, Sequence, Annotated
from .response import Response, error, ok

class Validator:
    @classmethod
    def validate(cls, instance: Any, expected_schema: Any) -> Response:
        # Determine if we start with a name or the literal value
        start_path = "data" if isinstance(instance, (dict, list, tuple)) else str(instance)
        return cls._run(instance, expected_schema, path=start_path)

    @classmethod
    def _run(cls, instance: Any, schema: Any, path: str) -> Response:
        origin = get_origin(schema)
        args = get_args(schema)

        # 1. Handle Annotated types (Definition and Options)
        if origin is Annotated:
            # Extract base type and metadata
            base_type = args[0]
            metadata = args[1:]
            
            # Check for Definition (has _SchemaDescriptor in metadata)
            for meta in metadata:
                if hasattr(meta, 'schema') and isinstance(meta.schema, dict):
                    # This is a Definition[dict_schema]
                    # First validate it's a dict
                    if not isinstance(instance, dict):
                        return error(message=f"Value: '{instance}' at {path} is not a dict for Definition")
                    
                    # Validate against the embedded schema
                    dict_schema = meta.schema
                    for key, expected_type in dict_schema.items():
                        current_path = f"{path}::{key}"
                        if key not in instance:
                            return error(message=f"Missing key '{key}' at {path} in Definition")
                        res = cls._run(instance[key], expected_type, current_path)
                        if not res: return res
                    return ok()
                
                # Check for Options (has string metadata starting with "Options: ")
                if isinstance(meta, str) and meta.startswith("Options: "):
                    # Extract choices from metadata string
                    try:
                        import ast
                        choices_str = meta.replace("Options: ", "", 1)
                        choices = ast.literal_eval(choices_str)
                    except:
                        return error(message=f"Invalid Options metadata at {path}")
                    
                    # First validate base type
                    base_res = cls._run(instance, base_type, path)
                    if not base_res:
                        return base_res
                    
                    # Then validate value is in choices
                    if instance not in choices:
                        allowed = ", ".join(repr(c) for c in choices)
                        return error(message=f"Value '{instance}' not in expected options: [{allowed}]")
                    
                    return ok()
            
            # If it's Annotated but not Definition/Options we recognize, validate base type
            return cls._run(instance, base_type, path)

        # 2. Handle Dictionary Structures (dict, Dict, dict[k, v], or {k: v})
        if schema is dict or origin is dict or isinstance(schema, dict):
            if not isinstance(instance, dict):
                return error(message=f"Value: '{instance}' at {path} is not a dict")
            
            # If it's a literal dict schema: {"key": type}
            if isinstance(schema, dict):
                for key, expected_type in schema.items():
                    current_path = f"{path}::{key}"
                    if key not in instance:
                        return error(message=f"Missing key '{key}' at {path}")
                    res = cls._run(instance[key], expected_type, current_path)
                    if not res: return res
            
            # If it's a generic dict schema: dict[str, int]
            elif args:
                key_type, val_type = args
                for key, value in instance.items():
                    # Validate keys
                    if not isinstance(key, key_type):
                        return error(message=f"Key '{key}' at {path} expected {key_type.__name__}")
                    # Validate values
                    res = cls._run(value, val_type, f"{path}::{key}")
                    if not res: return res
            
            return ok()

        # 3. Handle Sequences (list, List, tuple, Tuple, [type])
        if schema in (list, tuple) or origin in (list, tuple, Sequence) or isinstance(schema, list):
            if not isinstance(instance, (list, tuple)):
                return error(message=f"Value: '{instance}' at {path} is not a sequence")
            
            # Determine item type
            if isinstance(schema, list): # handle [str]
                expected_item_type = schema[0] if schema else Any
            elif args: # handle list[str] or List[str]
                # For Tuples with specific lengths: Tuple[str, int]
                if origin in (tuple, tuple) and len(args) > 1 and len(args) == len(instance):
                    for i, (item, itype) in enumerate(zip(instance, args)):
                        res = cls._run(item, itype, f"{path}[{i}]")
                        if not res: return res
                    return ok()
                expected_item_type = args[0]
            else:
                expected_item_type = Any

            for i, item in enumerate(instance):
                res = cls._run(item, expected_item_type, f"{path}[{i}]")
                if not res: return res
            return ok()

        # 4. Handle Unions & Optionals (| or Union[] or Optional[])
        if origin is Union or (hasattr(types, "UnionType") and isinstance(schema, types.UnionType)):
            # Extract raw types for the instance check
            check_types = tuple(
                get_origin(t) if get_origin(t) is not None else t 
                for t in args
            )

            if not isinstance(instance, check_types):
                names = [getattr(t, '__name__', str(t)) for t in args]
                names = ['None' if 'NoneType' in n else n for n in names]
                return error(message=f"Value '{instance}' at {path} expected {' or '.join(names)} but got {type(instance).__name__}")
            
            # Find which union type matches and continue recursion
            for t in args:
                t_origin = get_origin(t) or t
                if isinstance(instance, t_origin):
                    # Continue recursion with the specific matched type
                    return cls._run(instance, t, path)
            
            return ok(instance)
        
        # 5. Simple Type Catch-all
        actual_schema = origin if origin is not None else schema
        # print("actual schema====>", actual_schema, instance)
        if actual_schema and (actual_schema is not Any ) and (not isinstance(instance, actual_schema)):
            name = getattr(schema, '__name__', str(schema))
            return error(message=f"Value: '{instance}' at {path} expected {name} but got {type(instance).__name__}")

        return ok()

validate = Validator.validate