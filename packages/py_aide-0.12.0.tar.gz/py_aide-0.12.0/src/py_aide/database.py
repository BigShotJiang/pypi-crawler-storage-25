"""
Database Manager Module - SQLite Multiton API with JSON Support

This module provides a thread-safe, multiton database manager for SQLite databases
with built-in JSON support, transaction management, and automatic resource cleanup.

Key Features:
- Thread-local multiton pattern: One instance per database path per thread
- Automatic JSON serialization/deserialization
- Transaction management with error tracking
- Automatic attachment/detachment of multiple databases
- Context-aware operations with nested support
- Read-only mode protection
- WAL mode configuration for better concurrency

Classes:
    Api: Main database manager class implementing thread-local multiton pattern

Exceptions:
    All errors are returned as Response objects rather than raised exceptions

Usage:
    >>> from db import Api
    >>> with Api(db_path="data.db", readonly=True) as db:
    >>>     result = db.fetch(table="users", columns=["id", "name"])
    >>>     if result:
    >>>         print(result.data)
"""

import sqlite3
import os
import json
import threading
from functools import wraps
from typing import Any, Optional
from contextlib import ExitStack
from weakref import WeakKeyDictionary

from .response import ok, error, Response
from .enforcer import enforce_requirements
from .sqlite import JSONParser

FETCH_LIMIT: int = 90 * 1024  # Maximum number of records to fetch in one query

# --- GLOBAL JSON TYPE REGISTRATION ---
# These ensure seamless communication between Python dicts and SQLite JSON types

# Direction: Python -> DB (Adapter)
# Automatically converts any Python 'dict' passed to a query into a JSON string
sqlite3.register_adapter(dict, lambda d: json.dumps(d, ensure_ascii=False))

# Direction: DB -> Python (Converter)
# Automatically parses columns declared as 'JSON' back into Python dictionaries
sqlite3.register_converter("JSON", lambda b: json.loads(b.decode("utf-8")))


class Api:
    """
    A Thread-Local Multiton Database Manager.
    
    This class manages SQLite database connections with support for:
    - Thread-local instances: Each thread gets its own instance per database path
    - Nested context management with automatic reference counting
    - Transaction reporting and error tracking
    - Schema initialization on first use
    - Thread-safe instance creation per thread
    - Automatic attachment/detachment of multiple databases
    
    The class ensures that:
    - Same thread requesting same database path gets same instance
    - Different threads get different instances (thread isolation)
    - Threads don't share SQLite connections (prevents threading issues)
    - Automatic cleanup when threads die
    
    Attributes:
        _thread_registries (WeakKeyDictionary): Thread-local registry tracking 
            instances by thread object
        _lock (threading.Lock): Thread lock protecting access to thread registries
    """

    _lock: threading.Lock = threading.Lock()
    _thread_registries = WeakKeyDictionary()  # Thread object -> {db_key: instance_data}
    
    # Format of instance_data in thread registry:
    # {
    #     "instance": Api instance,
    #     "reference_count": int  # Number of active contexts in this thread
    # }

    def __new__(cls, *args, **kwargs) -> "Api":
        """
        Thread-local multiton constructor.
        
        Returns existing instance for the given database path in current thread
        or creates a new one for this thread. Different threads get different
        instances even for the same database path.
        
        This method implements thread-local multiton by:
        1. Getting current thread object
        2. Looking up thread's personal registry
        3. Checking if instance exists for db_path+config in this thread's registry
        4. Returning thread's instance or creating new one for this thread
        
        Args:
            *args: Positional arguments (not used, but required for compatibility)
            **kwargs: Keyword arguments including 'db_path' and other configurations
            
        Returns:
            Api: Existing instance for current thread, or new instance for this thread
            
        Raises:
            TypeError: If db_path is not provided in kwargs
        """
        # Extract db_path from kwargs
        db_path = kwargs.get("db_path")
        if db_path is None:
            raise TypeError("db_path is required as a keyword argument")

        # Create configuration hash
        config_hash = hash(
            (
                kwargs.get("readonly"),
                kwargs.get("transactionMode"),
                kwargs.get("wal_mode"),
                tuple(
                    tuple(sorted(item.items())) if isinstance(item, dict) else item
                    for item in (kwargs.get("attachments", []) or [])
                ),
            )
        )
        
        db_key = f"{db_path}:{config_hash}"
        current_thread = threading.current_thread()

        with cls._lock:
            # Get or create this thread's personal registry
            if current_thread not in cls._thread_registries:
                cls._thread_registries[current_thread] = {}
            
            thread_registry = cls._thread_registries[current_thread]
            
            # Check if instance exists in this thread's registry
            if db_key in thread_registry:
                return thread_registry[db_key]["instance"]
            
            # Create new instance for this thread
            instance = super().__new__(cls)
            thread_registry[db_key] = {
                "instance": instance,
                "reference_count": 0,
            }
            
            return instance

    def __init__(
        self,
        /,
        *,
        db_path: str,
        tables: Optional[dict[str, str]] = None,
        readonly: bool = True,
        transactionMode: bool = False,
        wal_mode: bool = True,
        attachments: Optional[list[dict]] = None,
    ) -> None:
        """
        Initialize the database instance configuration for current thread.
        
        Args:
            db_path: Path to the SQLite database file
            tables: Optional dictionary mapping table names to their 
                   CREATE TABLE definitions.
            readonly: If True, only read operations are allowed. Defaults to True.
            transactionMode: If True, enables manual transaction control.
                           Defaults to False.
            wal_mode: If True, enables Write-Ahead Logging for better concurrency.
                     Defaults to True.
            attachments: Optional list of databases to attach automatically.
                       Each item should be a dict with 'path' and 'alias' keys.
        
        Note:
            - Each thread initializes its own instance separately
            - Connection is established lazily in __enter__
        """
        # Guard: Prevent re-initialization
        if getattr(self, "_initialized", False):
            return

        # Store configuration
        self.db_path = os.path.abspath(db_path)
        db_dir = os.path.dirname(self.db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)

        self.tables = tables or {}
        self.readonly = readonly if not transactionMode else False
        self.transactionMode = transactionMode
        self.wal_mode = wal_mode
        self._wal_configured = False

        # Thread-local tracking
        self.withCounts = 0
        self._errors: list[dict[str, Any]] = []

        # Attachment management
        self.requested_attachments = attachments or []
        self._manual_attachments: set[str] = set()
        self._stack: Optional[ExitStack] = None

        # Connection state
        self.conn: Optional[sqlite3.Connection] = None
        self.cursor: Optional[sqlite3.Cursor] = None

        # Thread tracking for debugging/cleanup
        self._thread_id = threading.get_ident()
        self._initialized = True

    @property
    def inTopLevelContext(self) -> bool:
        """
        Check if we are in the outermost 'with' block in current thread.
        
        Returns:
            bool: True if this is the first context in current thread's nesting chain
        """
        return self.withCounts == 1

    def __enter__(self) -> "Api":
        """
        Enter the database context manager for current thread.
        
        Returns:
            Api: The instance itself for use in the with block
            
        Note:
            - Each thread manages its own connection independently
            - Reference counting is thread-local
        """
        current_thread = threading.current_thread()
        
        with self._lock:
            # Find this instance in current thread's registry
            for db_key, data in self._thread_registries.get(current_thread, {}).items():
                if data["instance"] is self:
                    data["reference_count"] += 1
                    break

        # Track nesting within this thread
        self.withCounts += 1

        # Open connection if first use in this thread
        if self.conn is None:
            self.conn = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
                detect_types=sqlite3.PARSE_DECLTYPES,
            )
            self.conn.row_factory = sqlite3.Row
            self.cursor = self.conn.cursor()

            if self.wal_mode and not self.readonly and not self._wal_configured:
                self._configure_wal_once()

        # Only perform these heavy setup operations on the outermost context block
        if self.inTopLevelContext:
            if self.requested_attachments or not self._stack:
                self._stack = ExitStack()

            # Attach pre-configured databases
            for item in self.requested_attachments:
                path, alias = item["path"], item["alias"]
                abs_path = os.path.abspath(path)
                
                current_attached = self._get_attached_databases()
                if not any(db["name"] == alias for db in current_attached):
                    self.conn.execute(f"ATTACH DATABASE '{abs_path}' AS {alias}")
                    self._stack.callback(self._safe_detach, alias)

            # Create tables if needed
            if self.tables:
                self._create_tables()

            # Start transaction if needed
            if self.transactionMode:
                self.conn.execute("BEGIN")
                self._errors = []

        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        """
        Exit the database context manager for current thread.
        
        Args:
            exc_type: Exception type if an exception occurred
            exc_value: Exception value if an exception occurred
            traceback: Exception traceback if an exception occurred
            
        Note:
            - Cleanup is thread-local
            - Connection only closes when all contexts in this thread exit
        """
        is_top_level = (self.withCounts == 1)

        # Handle transaction rollback (immediately on first error, even if nested)
        if self.conn and self.transactionMode and exc_type is not None:
            try:
                self.conn.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            self._log_error("CRASH", "SYSTEM", str(exc_value))

        # Close ExitStack (detaches databases) ONLY when completely exiting
        if is_top_level and self._stack:
            self._stack.close()
            self._stack = None
            self._manual_attachments.clear()

        # Decrement nesting counter
        self.withCounts -= 1

        # Decrement thread-local reference count
        current_thread = threading.current_thread()
        
        with self._lock:
            if current_thread in self._thread_registries:
                for db_key, data in self._thread_registries[current_thread].items():
                    if data["instance"] is self:
                        data["reference_count"] -= 1
                        
                        # Close connection if no active contexts in this thread
                        if data["reference_count"] <= 0 and self.conn:
                            self.cursor.close()
                            self.conn.close()
                            self.conn = None
                            self.cursor = None
                        break

    def _get_attached_databases(self) -> list[dict]:
        """
        Internal method to get list of currently attached databases.
        
        Returns:
            list[dict]: List of attached databases in current thread's connection
        """
        if not self.conn:
            return []
        
        cursor = self.conn.execute("PRAGMA database_list")
        return [
            {"seq": row[0], "name": row[1], "file": row[2]}
            for row in cursor.fetchall()
        ]

    def _safe_detach(self, alias: str) -> None:
        """
        Safely detach a database without raising errors.
        
        Args:
            alias: The alias of the database to detach
        """
        try:
            if self.conn:
                self.conn.execute(f"DETACH DATABASE {alias}")
        except (sqlite3.Error, AttributeError):
            pass
        finally:
            if alias in self._manual_attachments:
                self._manual_attachments.remove(alias)

    def _configure_wal_once(self) -> None:
        """
        Configure WAL mode once per connection in current thread.
        """
        try:
            cursor = self.conn.execute("PRAGMA journal_mode;")
            current_mode = cursor.fetchone()[0]

            if current_mode.upper() != "WAL":
                self.conn.executescript(
                    """
                    PRAGMA journal_mode = WAL;
                    PRAGMA synchronous = FULL;
                    """
                )

            self._wal_configured = True
        except (sqlite3.OperationalError, sqlite3.Error):
            self._wal_configured = True

    def _log_error(self, op: str, target: str, message: str) -> None:
        """
        Log operation failures for transaction reporting in current thread.
        
        Args:
            op: Operation type
            target: Target of the operation
            message: Error message
        """
        self._errors.append({"type": op, "target": target, "error": message})

    # --- Core Database Operations ---

    def commit_transaction(self) -> Response:
        """
        Manually commit the current transaction in current thread.
        
        Returns:
            Response: OK if commit succeeds, error if failures occurred
        """
        if not self.transactionMode:
            return error(
                message="commit_transaction() requires database kwarg transactionMode set to True"
            )

        if not self.inTopLevelContext:
            return error(
                message="Error::cannot commit in a non Top-Level with (Mother) context."
            )

        if len(self._errors) > 0:
            try:
                self.conn.execute("ROLLBACK")
            except sqlite3.Error:
                pass
            failure_count = len(self._errors)
            return error(
                message=f"Transaction Rollback: {failure_count} operations failed.",
                errorLogs={"failures": self._errors},
            )

        try:
            self.conn.execute("COMMIT")
            return ok()
        except Exception as e:
            self.conn.execute("ROLLBACK")
            return error(message=f"Final database commit failed: {str(e)}")

    def ensure_with_context(method):
        """
        Decorator ensuring methods are only called within an active 'with' context.
        """
        @wraps(method)
        def wrapper(self, *args, **kwargs):
            if self.conn is None:
                return error(
                    message=f"Method '{method.__name__}' called outside 'with' context."
                )
            return method(self, *args, **kwargs)
        return wrapper

    @ensure_with_context
    def _create_tables(self) -> None:
        """
        Create tables based on configured schema in current thread.
        """
        for tableName, columnsDefinition in self.tables.items():
            query = f'CREATE TABLE IF NOT EXISTS "{tableName}" ({columnsDefinition})'
            try:
                self.cursor.execute(query)
                if not self.transactionMode and self.inTopLevelContext:
                    self.conn.commit()
            except sqlite3.Error as e:
                self._log_error("create_table", tableName, str(e))

    @ensure_with_context
    @enforce_requirements
    def insert(self, /, *, table: str, data: list) -> Response:
        """
        Insert records into a table in current thread's connection.
        """
        if self.readonly:
            return error(
                message="Read-only mode active. Insert operations are not allowed."
            )

        if not data:
            return error(message="No data provided for insertion.")

        try:
            placeholders = ", ".join(["?" for _ in range(len(data[0]))])
            query = f'INSERT INTO "{table}" VALUES ({placeholders})'
            self.cursor.executemany(query, data)

            if not self.transactionMode and self.inTopLevelContext:
                self.conn.commit()

            return ok()
        except Exception as e:
            self._log_error("insert", table, str(e))
            return error(message=str(e))

    @ensure_with_context
    @enforce_requirements
    def update(
        self,
        /,
        *,
        table: str,
        columns: list,
        column_data: list,
        condition: str,
        condition_data: list,
    ) -> Response:
        """
        Update records in a table in current thread's connection.
        """
        if self.readonly:
            return error(
                message="Read-only mode active. Update operations are not allowed."
            )

        try:
            parsed_cols, new_values = JSONParser.parse_write_columns(
                columns=columns, values=column_data
            )
            set_clause = ", ".join(parsed_cols)
            parsed_condition = JSONParser.parse_condition(condition)
            
            query = f'UPDATE "{table}" SET {set_clause} WHERE {parsed_condition}'
            self.cursor.execute(query, new_values + condition_data)

            if not self.transactionMode and self.inTopLevelContext:
                self.conn.commit()

            return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            self._log_error("update", table, str(e))
            return error(message=str(e), errorLogs={"failed": self._errors})

    @ensure_with_context
    @enforce_requirements
    def delete(self, /, *, table: str, condition: str, condition_data: list) -> Response:
        """
        Delete records from a table in current thread's connection.
        """
        if self.readonly:
            return error(
                message="Read-only mode active. Delete operations are not allowed."
            )

        try:
            parsed_condition = JSONParser.parse_condition(condition)
            query = f'DELETE FROM "{table}" WHERE {parsed_condition}'
            self.cursor.execute(query, condition_data)

            if not self.transactionMode and self.inTopLevelContext:
                self.conn.commit()

            return ok(data={"deleted_rows": self.cursor.rowcount})
        except Exception as e:
            self._log_error("delete", table, str(e))
            return error(message=str(e))

    @ensure_with_context
    @enforce_requirements
    def fetch(
        self,
        /,
        *,
        table: str,
        columns: list,
        condition: Optional[str] = None,
        condition_data: Optional[list] = None,
        limit: int = FETCH_LIMIT,
        offset: int = 0,
    ) -> Response:
        """
        Fetch records from a table in current thread's connection.
        """
        try:
            if not isinstance(limit, int) or not (0 < limit <= FETCH_LIMIT):
                return error(
                    message=f"Limit must be an integer between 1 and {FETCH_LIMIT}",
                    errorLogs={"invalid_limit": limit, "max_allowed": FETCH_LIMIT},
                )

            if not isinstance(offset, int) or offset < 0:
                return error(
                    message="Offset must be a non-negative integer",
                    errorLogs={"invalid_offset": offset},
                )

            parsed_columns = [
                JSONParser.parse_read_column(column_string=c) for c in columns
            ]
            cols = ", ".join(parsed_columns)
            query = f'SELECT {cols} FROM "{table}"'

            if condition:
                parsed_condition = JSONParser.parse_condition(condition)
                query += f" WHERE {parsed_condition}"

            query += " LIMIT ? OFFSET ?"
            params = []
            if condition_data is not None:
                params.extend(condition_data)
            params.extend([limit, offset])

            self.cursor.execute(query, params)
            rows = self.cursor.fetchall()
            data = [dict(row) for row in rows]

            return ok(data=data)
        except Exception as e:
            self._log_error("fetch", table, str(e))
            return error(message=str(e), errorLogs={"failed": self._errors})

    @ensure_with_context
    @enforce_requirements
    def execute(self, /, *, query: str, data: Optional[list] = None) -> Response:
        """
        Execute custom SQL in current thread's connection.
        """
        is_select = query.strip().lower().startswith("select")

        if not is_select and self.readonly:
            return error(
                message="Read-only mode active. Data modification queries are not allowed."
            )

        try:
            parsed_query = JSONParser.parse_condition(query)
            self.cursor.execute(parsed_query, data or [])

            if is_select:
                rows = self.cursor.fetchall()
                return ok(data=[dict(row) for row in rows])
            else:
                if not self.transactionMode and self.inTopLevelContext:
                    self.conn.commit()
                return ok(data={"affected_rows": self.cursor.rowcount})
        except Exception as e:
            self._log_error("execute", "custom_query", str(e))
            return error(message=str(e), errorLogs={"failed": self._errors})

    @ensure_with_context
    def attach(self, /, *, db_path: str, alias: str) -> Response:
        """
        Attach a database to current thread's connection.
        
        The attachment will be automatically detached when context exits.
        """
        if not os.path.exists(db_path):
            return error(message=f"Database file not found at {db_path}")

        abs_path = os.path.abspath(db_path)
        current_attached = self._get_attached_databases()
        
        if any(db["name"] == alias for db in current_attached):
            return ok()

        try:
            self.conn.execute(f"ATTACH DATABASE '{abs_path}' AS {alias}")
            
            if self._stack is None:
                self._stack = ExitStack()
            
            self._stack.callback(self._safe_detach, alias)
            self._manual_attachments.add(alias)
            
            return ok()
        except Exception as e:
            return error(message=f"Failed to attach database: {str(e)}")

    @ensure_with_context
    def detach(self, /, *, alias: str) -> Response:
        """
        Manually detach a database from current thread's connection.
        """
        try:
            self.conn.execute(f"DETACH DATABASE {alias}")
            if alias in self._manual_attachments:
                self._manual_attachments.remove(alias)
            return ok()
        except Exception as e:
            return error(message=f"Failed to detach database '{alias}': {str(e)}")

    @ensure_with_context
    def vacuum(self, /, *, force: bool = False) -> Response:
        """
        Reclaim unused space in current thread's connection.
        """
        if self.transactionMode:
            return error(
                message="VACUUM cannot be performed within a transaction block."
            )

        if not force:
            file_size_mb = os.path.getsize(self.db_path) / (1024 * 1024)
            if file_size_mb < 50:
                return ok()

        try:
            self.conn.execute("VACUUM")
            return ok()
        except Exception as e:
            self._log_error("vacuum", "N/A", str(e))
            return error(message=str(e))

    @classmethod
    def get_open_databases(cls) -> dict[str, dict[str, int]]:
        """
        Get snapshot of open database instances across all threads.
        
        Returns:
            dict: Thread ID -> {db_key: reference_count} mapping
            
        Note:
            Useful for debugging thread-local connection management
        """
        with cls._lock:
            result = {}
            for thread, registry in cls._thread_registries.items():
                thread_id = thread.ident if hasattr(thread, 'ident') else id(thread)
                result[str(thread_id)] = {
                    db_key: data["reference_count"]
                    for db_key, data in registry.items()
                }
            return result

    @classmethod
    def cleanup_thread(cls, thread_id: int|None = None) -> None:
        """
        Clean up database connections for a specific thread or current thread.
        
        Args:
            thread_id: Optional thread ID to clean up. If None, cleans current thread.
            
        Note:
            Useful when threads are manually managed or for testing
        """
        with cls._lock:
            target_thread = None
            if thread_id is None:
                current_thread = threading.current_thread()
                if current_thread in cls._thread_registries:
                    target_thread = current_thread
            else:
                # Find thread by ID
                for thread in list(cls._thread_registries.keys()):
                    if getattr(thread, 'ident', id(thread)) == thread_id:
                        target_thread = thread
                        break
            
            if target_thread and target_thread in cls._thread_registries:
                # Safely close all instances for this thread to prevent fd leaks
                registry = cls._thread_registries[target_thread]
                for db_key, data in registry.items():
                    instance = data["instance"]
                    if instance.conn:
                        try:
                            instance.cursor.close()
                            instance.conn.close()
                        except sqlite3.Error:
                            pass
                        instance.conn = None
                        instance.cursor = None
                        instance._initialized = False
                
                del cls._thread_registries[target_thread]

    @classmethod
    def cleanup_all(cls) -> None:
        """
        Force close all database connections across all threads.
        
        Warning:
            - This will close connections even if they're still in use
            - Only use during application shutdown
        """
        with cls._lock:
            for thread, registry in cls._thread_registries.items():
                for db_key, data in registry.items():
                    instance = data["instance"]
                    if instance.conn:
                        instance.cursor.close()
                        instance.conn.close()
                        instance.conn = None
                        instance.cursor = None
                        instance._initialized = False
            
            cls._thread_registries.clear()