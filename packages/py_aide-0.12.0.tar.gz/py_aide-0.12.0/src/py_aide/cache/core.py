"""
Core cache orchestration layer with intelligent queue management.

This module provides a simple boolean interface (disk_write_wait) while internally
managing queue health, automatic consistency promotion, and fail-fast behavior.

The system automatically:
    - Monitors queue health in real-time
    - Promotes to CRITICAL mode when queue approaches capacity
    - Fails fast when system is overwhelmed
    - Provides clear feedback about write status
"""

import threading
import copy
import time
import logging
from typing import Any, List, Callable, Dict, Union, Optional, Tuple
import queue

from .cacheConfig import (
    PATH_SEP,
    DEFAULT_HOT_BUFFER_SIZE,
    DirectMutation,
    FollowUpMutation,
    CacheError
)
from .memory import HybridMemory
from .persistence import PersistenceManager, WritePriority, WriteStatus, ConsistencyLevel
from .cacheTransaction import TransactionManager
from ..response import Response, ok, error

# Set up logging
logger = logging.getLogger(__name__)


class Cache:
    """
    Thread-safe cache orchestrator with intelligent queue management.
    
    This is the main entry point for all cache operations. It provides a simple
    boolean interface (disk_write_wait) while internally managing queue health,
    automatic consistency promotion, and fail-fast behavior.
    
    Usage:
        # Initialize once at application startup
        cache = Cache(
            storage_path="/data/cache",
            hot_buffer_size=200,
            max_queue_size=2000,
            critical_threshold=85  # Promote at 85% queue full
        )
        
        # Non-critical data (fast, may lose on crash)
        response = cache.write(
            shelf_path="/data/cache",
            scope="analytics",
            category="page_views",
            data={"count": 1000},
            disk_write_wait=False
        )
        
        # Critical data (waits for disk, handles queue pressure)
        response = cache.write(
            shelf_path="/data/cache",
            scope="users",
            category="profile", 
            data={"name": "John"},
            disk_write_wait=True
        )
        
        # Transactional patch with disk guarantee
        response = cache.patch(
            shelf_path="/data/cache",
            scope="orders",
            category="order_123",
            direct_mutations=[...],
            disk_write_wait=True
        )
    """
    
    _instances = {}
    _class_lock = threading.Lock()

    def __new__(cls, storage_path: str, *args, **kwargs):
        """Multiton pattern: maintains a single global state per storage path."""
        with cls._class_lock:
            if storage_path not in cls._instances:
                cls._instances[storage_path] = super(Cache, cls).__new__(cls)
            return cls._instances[storage_path]

    def __init__(
        self,
        storage_path: str,
        hot_buffer_size: int = DEFAULT_HOT_BUFFER_SIZE,
        max_queue_size: int = 1000,
        critical_threshold: int = 80,  # Percentage
        warning_threshold: int = 60,    # Percentage
        enable_auto_promotion: bool = True,
        default_write_timeout: float = 5.0
    ):
        """
        Initialize the cache orchestrator.
        
        Args:
            storage_path: Base directory for all persistence files
            hot_buffer_size: Number of items to keep strongly referenced in memory
            max_queue_size: Maximum number of pending write operations
            critical_threshold: Queue size % that triggers CRITICAL promotion
                               (e.g., 80 means promote when queue > 80% full)
            warning_threshold: Queue size % that triggers warning logs
            enable_auto_promotion: Whether to automatically promote to CRITICAL
            default_write_timeout: Default timeout for write operations (seconds)
        """
        if hasattr(self, "_initialized") and self._initialized:
            return
        
        # Validate thresholds
        if critical_threshold <= warning_threshold:
            raise ValueError("critical_threshold must be > warning_threshold")
        if critical_threshold > 100 or warning_threshold > 100:
            raise ValueError("Thresholds must be percentages (0-100)")
        
        self.storage_path = storage_path
        self.hot_buffer_size = hot_buffer_size
        self.max_queue_size = max_queue_size
        self.critical_threshold = critical_threshold
        self.warning_threshold = warning_threshold
        self.enable_auto_promotion = enable_auto_promotion
        self.default_write_timeout = default_write_timeout
        
        # Core components
        self.memory = HybridMemory(buffer_size=hot_buffer_size)
        self._storage: Dict[str, Dict[str, Any]] = {}  # scope -> category -> data
        
        # Single persistence manager for the storage path
        self.persistence = PersistenceManager(
            storage_path=storage_path,
            queue_size=max_queue_size
        )
        
        # Thread safety
        self._lock = threading.RLock()
        self._initialized = True
        
        logger.info(f"Cache initialized with storage_path={storage_path}, "
                   f"max_queue={max_queue_size}, "
                   f"critical_threshold={critical_threshold}%")

    def _get_queue_health(self, shelf_path: str) -> Dict[str, Any]:
        """
        Get current queue health metrics for a specific shelf.
        
        Args:
            shelf_path: Path to the shelf directory
            
        Returns:
            Dictionary with queue stats and health status
        """
        # Get or create persistence manager for this shelf
        persistor = self._get_persistence_manager(shelf_path)
        stats = persistor.get_queue_stats()
        
        queue_size = stats["queue_size"]
        max_size = stats["queue_max"]
        
        if max_size == 0:
            fill_percentage = 0
        else:
            fill_percentage = (queue_size / max_size) * 100
        
        return {
            "queue_size": queue_size,
            "max_size": max_size,
            "fill_percentage": fill_percentage,
            "free_slots": max_size - queue_size,
            "is_critical": fill_percentage >= self.critical_threshold,
            "is_warning": fill_percentage >= self.warning_threshold,
            "status": self._get_health_status(fill_percentage)
        }

    def _get_health_status(self, fill_percentage: float) -> str:
        """Get human-readable health status."""
        if fill_percentage >= self.critical_threshold:
            return "CRITICAL"
        elif fill_percentage >= self.warning_threshold:
            return "WARNING"
        else:
            return "HEALTHY"

    def _determine_consistency(
        self, 
        shelf_path: str, 
        disk_write_wait: bool
    ) -> Tuple[ConsistencyLevel, bool]:
        """
        Determine the actual consistency level based on user preference and queue health.
        
        Args:
            shelf_path: Path to the shelf directory
            disk_write_wait: User's preference (True = wait for disk)
            
        Returns:
            Tuple of (consistency_level, was_promoted)
        """
        if not disk_write_wait:
            # User doesn't care about disk persistence
            return ConsistencyLevel.BACKGROUND, False
        
        # User wants disk persistence - check queue health
        health = self._get_queue_health(shelf_path)
        
        if not self.enable_auto_promotion:
            # Auto-promotion disabled - use DURABLE regardless
            return ConsistencyLevel.DURABLE, False
        
        if health["is_critical"]:
            # Queue is critically full - use CRITICAL (fail-fast)
            logger.warning(f"Queue at {health['fill_percentage']:.1f}% - "
                          f"promoting to CRITICAL mode")
            return ConsistencyLevel.CRITICAL, True
        elif health["is_warning"]:
            # Queue is warning - use CRITICAL but log less aggressively
            logger.info(f"Queue at {health['fill_percentage']:.1f}% - "
                       f"using CRITICAL mode as precaution")
            return ConsistencyLevel.CRITICAL, True
        else:
            # Queue is healthy - use DURABLE
            return ConsistencyLevel.DURABLE, False

    def _get_persistence_manager(self, shelf_path: str) -> PersistenceManager:
        """
        Get or create a persistence manager for a shelf path.
        
        Args:
            shelf_path: Path to the shelf directory
            
        Returns:
            PersistenceManager instance
        """
        # Note: In this simplified version, we're using a single persistence manager
        # created at init. If you need multiple shelves, you'd need a dictionary here.
        return self.persistence

    def _get_composite_key(self, scope: str, category: str) -> str:
        """Create composite key for memory storage."""
        return f"{scope}{PATH_SEP}{category}"

    def read(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        path: Optional[str] = None, 
        format_callback: Optional[Callable] = None,
        bypass_memory: bool = False
    ) -> Response:
        """
        Read data from cache with automatic disk fallback.
        
        Args:
            shelf_path: Directory path for persistence
            scope: The scope/namespace
            category: Category to read from
            path: Optional nested path within the category
            format_callback: Optional function to transform retrieved data
            bypass_memory: If True, read directly from disk (skip cache)
            
        Returns:
            Ok with data if found, Error otherwise
        """
        cat_val = category if isinstance(category, str) else category.value
        comp_key = self._get_composite_key(scope, cat_val)
        
        # Try memory first (unless bypass requested)
        data = None
        if not bypass_memory:
            data = self.memory.get(comp_key)
        
        # Cold load from disk if not in memory
        if data is None:
            persistor = self._get_persistence_manager(shelf_path)
            scope_data = persistor.load_shard(scope)
            data = scope_data.get(cat_val)
            
            if data is not None:
                # Cache in memory and storage tracker
                with self._lock:
                    if scope not in self._storage:
                        self._storage[scope] = {}
                    self._storage[scope][cat_val] = data
                    self.memory.set(comp_key, data)

        if data is None:
            return error(message=f"Not found: {scope}::{cat_val}")

        # Navigate nested path if requested
        result = data
        if path:
            try:
                for key in path.split(PATH_SEP):
                    if key:  # Skip empty segments
                        result = result[key]
            except (KeyError, TypeError) as e:
                return error(message=f"Path error at '{path}': {str(e)}")

        # Apply formatting if provided
        if format_callback:
            try:
                result = format_callback(copy.deepcopy(result))
            except Exception as e:
                return error(message=f"Format callback error: {str(e)}")

        return ok(data=result)

    def write(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        data: Any, 
        format_callback: Optional[Callable] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: WritePriority = WritePriority.NORMAL
    ) -> Response:
        """
        Write data to cache with intelligent persistence handling.
        
        This method provides a simple boolean interface while internally
        managing queue health and consistency levels.
        
        Args:
            shelf_path: Directory path for persistence
            scope: The scope/namespace
            category: Category to write to
            data: Data to store
            format_callback: Optional function to transform data before storage
            disk_write_wait: If True, guarantees data is on disk before returning.
                            May be slower but survives crashes.
                            If False, returns immediately (fastest).
                            Data may be lost if process crashes before disk write.
            timeout: Maximum time to wait for disk write (if disk_write_wait=True)
            priority: Write priority for queueing
            
        Returns:
            Ok with write details if successful, Error otherwise
            
        Example:
            # Fast, non-critical write
            cache.write(
                shelf_path="/analytics",
                scope="page_views",
                category="homepage",
                data={"count": 100},
                disk_write_wait=False
            )
            
            # Critical write that must persist
            response = cache.write(
                shelf_path="/users",
                scope="user_123",
                category="profile",
                data={"email": "user@example.com"},
                disk_write_wait=True
            )
            if response.is_ok():
                return "Profile saved"  # Really is on disk
        """
        cat_val = category if isinstance(category, str) else category.value
        comp_key = self._get_composite_key(scope, cat_val)
        
        # Transform data if callback provided
        try:
            processed_data = format_callback(copy.deepcopy(data)) if format_callback else data
        except Exception as e:
            return error(message=f"Format callback error: {str(e)}")

        # Determine actual consistency level based on queue health
        consistency, was_promoted = self._determine_consistency(shelf_path, disk_write_wait)
        
        # Use timeout if provided, otherwise default
        write_timeout = timeout if timeout is not None else self.default_write_timeout

        with self._lock:
            # Ensure scope exists in storage tracker
            if scope not in self._storage:
                persistor = self._get_persistence_manager(shelf_path)
                self._storage[scope] = persistor.load_shard(scope)
            
            # Update memory and storage
            self._storage[scope][cat_val] = processed_data
            self.memory.set(comp_key, processed_data)

        # Queue for persistence
        persistor = self._get_persistence_manager(shelf_path)
        
        # Prepare data for persistence (entire scope)
        scope_data = self._storage[scope]
        
        try:
            # Determine if we should block for queue admission
            block_for_queue = (consistency == ConsistencyLevel.CRITICAL)
            
            # Queue the write
            write_id = persistor.queue_write(
                scope=scope,
                data=scope_data,
                priority=priority,
                block=block_for_queue,
                timeout=write_timeout if block_for_queue else None
            )
            
            # Handle queue full for CRITICAL writes
            if write_id is None and consistency == ConsistencyLevel.CRITICAL:
                health = self._get_queue_health(shelf_path)
                return error(
                    message=f"Write failed: Queue is full ({health['fill_percentage']:.1f}% full). "
                    f"Try again later or reduce load."
                )
            
            # For BACKGROUND or DURABLE, write_id might be None (queue full)
            # But we don't fail - just return warning
            if write_id is None:
                logger.warning(f"Write queued for {scope} but queue is full - data may not persist")
                return ok(data={
                    "write_id": None,
                    "scope": scope,
                    "category": cat_val,
                    "consistency": consistency.name,
                    "was_promoted": was_promoted,
                    "warning": "Queue full - data may not persist immediately"
                })
            
            # Wait for completion if needed
            if consistency in (ConsistencyLevel.DURABLE, ConsistencyLevel.CRITICAL):
                success = persistor.wait_for_write(
                    write_id, 
                    timeout=write_timeout
                )
                
                if not success:
                    return error(message=f"Write timed out after {write_timeout}s - data may not be persisted")
            
            return ok(data={
                "write_id": write_id,
                "scope": scope,
                "category": cat_val,
                "consistency": consistency.name,
                "was_promoted": was_promoted,
                "disk_write_wait": disk_write_wait
            })
            
        except queue.Full:
            # This only happens for CRITICAL writes when queue is full
            health = self._get_queue_health(shelf_path)
            return error(
                message=f"Write failed: Queue is full ({health['fill_percentage']:.1f}% full). "
                f"This is a critical write that couldn't be queued."
            )
        except Exception as e:
            return error(message=f"Write failed: {str(e)}")

    def patch(
        self, 
        *, 
        shelf_path: str, 
        scope: str, 
        category: Union[str, Any], 
        direct_mutations: List[DirectMutation],
        follow_up_mutations: Optional[List[FollowUpMutation]] = None,
        disk_write_wait: bool = False,
        timeout: Optional[float] = None,
        priority: WritePriority = WritePriority.CRITICAL
    ) -> Response:
        """
        Perform a transactional patch operation with intelligent persistence.
        
        Args:
            shelf_path: Directory path for persistence
            scope: The scope/namespace
            category: Primary category for mutations
            direct_mutations: List of mutations for primary category
            follow_up_mutations: Optional mutations for other categories
            disk_write_wait: If True, guarantees all changes are on disk before returning
            timeout: Maximum time to wait for disk write (if disk_write_wait=True)
            priority: Write priority for queueing
            
        Returns:
            Ok with details if successful, Error otherwise
        """
        cat_val = category if isinstance(category, str) else category.value
        
        # Determine actual consistency level
        consistency, was_promoted = self._determine_consistency(shelf_path, disk_write_wait)
        write_timeout = timeout if timeout is not None else self.default_write_timeout
        
        with self._lock:
            # Ensure scope exists
            if scope not in self._storage:
                persistor = self._get_persistence_manager(shelf_path)
                self._storage[scope] = persistor.load_shard(scope)

            try:
                # Execute transaction on memory snapshot
                success = TransactionManager.execute_patch(
                    storage=self._storage,
                    scope=scope,
                    mutations=direct_mutations,
                    follow_ups=follow_up_mutations
                )

                if not success:
                    return error(message="Patch transaction failed")

                # Update hot buffer with modified categories
                affected_categories = {cat_val}
                if follow_up_mutations:
                    for f_up in follow_up_mutations:
                        f_cat = f_up['category']
                        affected_categories.add(f_cat)
                        comp_key = self._get_composite_key(scope, f_cat)
                        self.memory.set(comp_key, self._storage[scope].get(f_cat))
                
                # Ensure primary category is in hot buffer
                primary_key = self._get_composite_key(scope, cat_val)
                self.memory.set(primary_key, self._storage[scope].get(cat_val))

                # Queue for persistence
                persistor = self._get_persistence_manager(shelf_path)
                scope_data = self._storage[scope]
                
                # Determine if we should block for queue admission
                block_for_queue = (consistency == ConsistencyLevel.CRITICAL)
                
                # Queue the write
                write_id = persistor.queue_write(
                    scope=scope,
                    data=scope_data,
                    priority=priority,
                    block=block_for_queue,
                    timeout=write_timeout if block_for_queue else None
                )
                
                # Handle queue full for CRITICAL patches
                if write_id is None and consistency == ConsistencyLevel.CRITICAL:
                    health = self._get_queue_health(shelf_path)
                    return error(
                        message=f"Patch failed: Queue is full ({health['fill_percentage']:.1f}% full). "
                        f"Changes rolled back."
                    )
                
                # For BACKGROUND or DURABLE, warn but don't fail
                if write_id is None:
                    logger.warning(f"Patch for {scope} completed in memory but queue is full")
                    return ok(data={
                        "write_id": None,
                        "scope": scope,
                        "affected_categories": list(affected_categories),
                        "consistency": consistency.name,
                        "was_promoted": was_promoted,
                        "warning": "Changes applied to memory but queue full - may not persist"
                    })
                
                # Wait for completion if needed
                if consistency in (ConsistencyLevel.DURABLE, ConsistencyLevel.CRITICAL):
                    success = persistor.wait_for_write(
                        write_id,
                        timeout=write_timeout
                    )
                    
                    if not success:
                        return error(message=f"Patch timed out after {write_timeout}s - changes in memory but may not be persisted")
                
                return ok(data={
                    "write_id": write_id,
                    "scope": scope,
                    "affected_categories": list(affected_categories),
                    "consistency": consistency.name,
                    "was_promoted": was_promoted,
                    "disk_write_wait": disk_write_wait
                })
                
            except queue.Full:
                # This only happens for CRITICAL patches
                health = self._get_queue_health(shelf_path)
                return error(
                    message=f"Patch failed: Queue is full ({health['fill_percentage']:.1f}% full). "
                    f"Changes rolled back."
                )
            except Exception as e:
                return error(message=f"Patch failed: {str(e)}")

    def get_queue_health_report(self, shelf_path: str) -> Dict[str, Any]:
        """
        Get a human-readable queue health report.
        
        Args:
            shelf_path: Path to the shelf directory
            
        Returns:
            Dictionary with health metrics and recommendations
        """
        health = self._get_queue_health(shelf_path)
        
        # Generate recommendations
        if health["is_critical"]:
            recommendation = "URGENT: Queue critically full. Consider:"
            recommendation += " 1) Increasing queue size, 2) Scaling write capacity, 3) Throttling writes"
        elif health["is_warning"]:
            recommendation = "Warning: Queue filling up. Monitor closely."
        else:
            recommendation = "Queue healthy. No action needed."
        
        return {
            **health,
            "recommendation": recommendation,
            "thresholds": {
                "warning": self.warning_threshold,
                "critical": self.critical_threshold
            }
        }

    def wait_for_pending_writes(
        self, 
        scope: Optional[str] = None,
        timeout: Optional[float] = None
    ) -> bool:
        """
        Wait for all pending writes to complete.
        
        Args:
            scope: Optional specific scope to wait for
            timeout: Maximum time to wait
            
        Returns:
            True if all writes completed, False on timeout
        """
        if scope:
            return self.persistence.wait_for_scope(scope, timeout)
        return self.persistence.wait_all(timeout)

    def shutdown(self, wait_for_queue: bool = True, timeout: Optional[float] = None) -> None:
        """
        Gracefully shut down the cache.
        
        Args:
            wait_for_queue: If True, wait for pending writes to complete
            timeout: Maximum time to wait
        """
        if wait_for_queue:
            self.wait_for_pending_writes(timeout=timeout)
        
        # Shutdown persistence manager
        self.persistence.shutdown(wait_for_queue=False)
        logger.info("Cache shut down")