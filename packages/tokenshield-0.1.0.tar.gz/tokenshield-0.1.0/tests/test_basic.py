"""
TokenShield 基本テスト

外部API呼び出しなしで動作確認するため、
モック（ダミー）クライアントを使ってテストする。
"""

import sys
import os
import time
import unittest
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock

# テスト対象のパッケージをインポートパスに追加
sys.path.insert(
    0, os.path.join(os.path.dirname(__file__), "..")
)

from tokenshield.config import ShieldConfig
from tokenshield.cache import Cache
from tokenshield.router import Router
from tokenshield.tracker import Tracker
from tokenshield.shield import shield


# ---------------------------------------------------------------------------
# テスト用モッククライアント
# ---------------------------------------------------------------------------


class _MockUsage:
    def __init__(self, input_tokens: int = 100, output_tokens: int = 50):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class _MockContentBlock:
    def __init__(self, text: str = "Hello from mock"):
        self.type = "text"
        self.text = text


class _MockMessage:
    def __init__(self, text: str = "Hello from mock"):
        self.id = "msg_mock_123"
        self.type = "message"
        self.role = "assistant"
        self.model = "claude-sonnet-4-20250514"
        self.stop_reason = "end_turn"
        self.content = [_MockContentBlock(text)]
        self.usage = _MockUsage()


class _MockMessages:
    def __init__(self):
        self.call_count = 0

    def create(self, **kwargs) -> _MockMessage:
        self.call_count += 1
        return _MockMessage("Response #{}".format(self.call_count))


class _MockAnthropicClient:
    """Anthropicクライアントのモック。"""

    def __init__(self):
        self.messages = _MockMessages()


class _MockOpenAIChoice:
    def __init__(self, text: str = "Hello from OpenAI mock"):
        self.message = MagicMock()
        self.message.content = text
        self.finish_reason = "stop"


class _MockOpenAIUsage:
    def __init__(self):
        self.prompt_tokens = 100
        self.completion_tokens = 50


class _MockOpenAIResponse:
    def __init__(self, text: str = "Hello from OpenAI mock"):
        self.id = "chatcmpl_mock_123"
        self.choices = [_MockOpenAIChoice(text)]
        self.usage = _MockOpenAIUsage()
        self.model = "gpt-4o"


class _MockCompletions:
    def __init__(self):
        self.call_count = 0

    def create(self, **kwargs) -> _MockOpenAIResponse:
        self.call_count += 1
        return _MockOpenAIResponse("Response #{}".format(self.call_count))


class _MockChat:
    def __init__(self):
        self.completions = _MockCompletions()


class _MockOpenAIClient:
    """OpenAIクライアントのモック。"""

    def __init__(self):
        self.chat = _MockChat()


# ---------------------------------------------------------------------------
# テストケース
# ---------------------------------------------------------------------------


class TestCache(unittest.TestCase):
    """キャッシュの基本テスト。"""

    def test_set_and_get(self):
        cache = Cache(ttl=60)
        messages = [{"role": "user", "content": "hello"}]
        model = "test-model"
        response = {"text": "world"}

        cache.set(messages, model, response)
        result = cache.get(messages, model)
        self.assertEqual(result, response)

    def test_cache_miss(self):
        cache = Cache(ttl=60)
        result = cache.get([{"role": "user", "content": "hello"}], "test-model")
        self.assertIsNone(result)

    def test_ttl_expiry(self):
        cache = Cache(ttl=1)  # 1秒
        messages = [{"role": "user", "content": "hello"}]
        cache.set(messages, "model", {"text": "world"})

        # 即座にはヒットする
        self.assertIsNotNone(cache.get(messages, "model"))

        # 2秒待ってTTL切れ
        time.sleep(1.5)
        self.assertIsNone(cache.get(messages, "model"))

    def test_different_models_different_cache(self):
        cache = Cache(ttl=60)
        messages = [{"role": "user", "content": "hello"}]

        cache.set(messages, "model-a", {"text": "from A"})
        cache.set(messages, "model-b", {"text": "from B"})

        self.assertEqual(cache.get(messages, "model-a"), {"text": "from A"})
        self.assertEqual(cache.get(messages, "model-b"), {"text": "from B"})

    def test_clear(self):
        cache = Cache(ttl=60)
        cache.set([{"role": "user", "content": "hello"}], "model", "resp")
        self.assertEqual(cache.size, 1)
        cache.clear()
        self.assertEqual(cache.size, 0)


class TestRouter(unittest.TestCase):
    """ルーティングの基本テスト。"""

    def setUp(self):
        self.config = ShieldConfig(
            enable_routing=True,
            deepseek_api_key="test-key",
            routing_threshold=0.5,
        )
        self.router = Router(self.config)

    def test_easy_query_routes_to_deepseek(self):
        messages = [{"role": "user", "content": "この文章を翻訳してください"}]
        provider, model = self.router.route(messages, "claude-sonnet-4-20250514")
        self.assertEqual(provider, "deepseek")

    def test_hard_query_stays_original(self):
        messages = [
            {
                "role": "user",
                "content": (
                    "この複雑なシステムのアーキテクチャを設計して、"
                    "戦略的な分析をしてください。推論を段階的に進めてください。"
                ),
            }
        ]
        provider, model = self.router.route(messages, "claude-sonnet-4-20250514")
        self.assertEqual(provider, "original")

    def test_tool_use_stays_original(self):
        messages = [{"role": "user", "content": "翻訳してください"}]
        tools = [{"name": "some_tool", "description": "test"}]
        provider, model = self.router.route(
            messages, "claude-sonnet-4-20250514", tools=tools
        )
        self.assertEqual(provider, "original")

    def test_force_original_keyword(self):
        messages = [{"role": "user", "content": "この機密文書を要約して"}]
        provider, model = self.router.route(messages, "claude-sonnet-4-20250514")
        self.assertEqual(provider, "original")

    def test_routing_disabled(self):
        config = ShieldConfig(enable_routing=False)
        router = Router(config)
        messages = [{"role": "user", "content": "翻訳して"}]
        provider, model = router.route(messages, "claude-sonnet-4-20250514")
        self.assertEqual(provider, "original")

    def test_no_api_key_stays_original(self):
        config = ShieldConfig(enable_routing=True, deepseek_api_key="")
        router = Router(config)
        messages = [{"role": "user", "content": "翻訳して"}]
        provider, model = router.route(messages, "claude-sonnet-4-20250514")
        self.assertEqual(provider, "original")


class TestTracker(unittest.TestCase):
    """トラッカーの基本テスト。"""

    def setUp(self):
        # テスト用に一時ディレクトリを使用
        import tempfile
        self.tmpdir = tempfile.mkdtemp()
        self.tracker = Tracker(tracking_dir=self.tmpdir)

    def test_record(self):
        entry = self.tracker.record(
            original_model="claude-sonnet-4-20250514",
            actual_model="deepseek-chat",
            input_tokens=1000,
            output_tokens=500,
            cache_hit=False,
            route_reason="difficulty_score=0.2",
        )
        self.assertEqual(entry["original_model"], "claude-sonnet-4-20250514")
        self.assertEqual(entry["actual_model"], "deepseek-chat")
        self.assertGreater(entry["savings_usd"], 0)

    def test_savings_total(self):
        self.tracker.record(
            original_model="claude-sonnet-4-20250514",
            actual_model="deepseek-chat",
            input_tokens=1000,
            output_tokens=500,
            cache_hit=False,
            route_reason="test",
        )
        self.tracker.record(
            original_model="claude-sonnet-4-20250514",
            actual_model="deepseek-chat",
            input_tokens=2000,
            output_tokens=1000,
            cache_hit=False,
            route_reason="test",
        )
        summary = self.tracker.get_savings_total()
        self.assertEqual(summary["total_requests"], 2)
        self.assertGreater(summary["total_savings_usd"], 0)
        self.assertGreater(summary["savings_pct"], 0)

    def test_cache_hit_zero_cost(self):
        entry = self.tracker.record(
            original_model="claude-sonnet-4-20250514",
            actual_model="claude-sonnet-4-20250514",
            input_tokens=1000,
            output_tokens=500,
            cache_hit=True,
            route_reason="cache_hit",
        )
        self.assertEqual(entry["actual_cost_usd"], 0.0)

    def test_summary_period(self):
        self.tracker.record(
            original_model="gpt-4o",
            actual_model="deepseek-chat",
            input_tokens=500,
            output_tokens=200,
            cache_hit=False,
            route_reason="test",
        )
        summary = self.tracker.get_summary(hours=1)
        self.assertEqual(summary["total_requests"], 1)
        self.assertEqual(summary["routed_to_deepseek"], 1)


class TestShieldAnthropic(unittest.TestCase):
    """Anthropicクライアントのshield()テスト。"""

    def test_shield_wraps_client(self):
        """shield()でラップしたクライアントが通常通り動くこと。"""
        mock_client = _MockAnthropicClient()
        config = ShieldConfig(
            enable_routing=False,
            enable_cache=False,
            enable_tracking=False,
        )
        wrapped = shield(mock_client, config)

        response = wrapped.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        self.assertEqual(response.content[0].text, "Response #1")
        self.assertEqual(mock_client.messages.call_count, 1)

    def test_cache_prevents_second_call(self):
        """キャッシュが効くこと（同じリクエスト2回目はAPI呼ばない）。"""
        mock_client = _MockAnthropicClient()
        config = ShieldConfig(
            enable_routing=False,
            enable_cache=True,
            cache_ttl=60,
            enable_tracking=False,
        )
        wrapped = shield(mock_client, config)

        kwargs = {
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 1024,
            "messages": [{"role": "user", "content": "Hello"}],
        }

        # 1回目
        resp1 = wrapped.messages.create(**kwargs)
        # 2回目（キャッシュヒット）
        resp2 = wrapped.messages.create(**kwargs)

        # APIは1回しか呼ばれていない
        self.assertEqual(mock_client.messages.call_count, 1)
        # 同じレスポンスが返る
        self.assertEqual(resp1.content[0].text, resp2.content[0].text)

    def test_tracker_records_calls(self):
        """トラッカーが記録すること。"""
        mock_client = _MockAnthropicClient()
        import tempfile
        tmpdir = tempfile.mkdtemp()
        config = ShieldConfig(
            enable_routing=False,
            enable_cache=False,
            enable_tracking=True,
            tracking_dir=tmpdir,
        )
        wrapped = shield(mock_client, config)

        wrapped.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1024,
            messages=[{"role": "user", "content": "Hello"}],
        )

        summary = wrapped._tokenshield_tracker.get_savings_total()
        self.assertEqual(summary["total_requests"], 1)


class TestShieldOpenAI(unittest.TestCase):
    """OpenAIクライアントのshield()テスト。"""

    def test_shield_wraps_openai_client(self):
        mock_client = _MockOpenAIClient()
        config = ShieldConfig(
            enable_routing=False,
            enable_cache=False,
            enable_tracking=False,
        )
        wrapped = shield(mock_client, config)

        response = wrapped.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )

        self.assertEqual(mock_client.chat.completions.call_count, 1)

    def test_openai_cache_works(self):
        mock_client = _MockOpenAIClient()
        config = ShieldConfig(
            enable_routing=False,
            enable_cache=True,
            cache_ttl=60,
            enable_tracking=False,
        )
        wrapped = shield(mock_client, config)

        kwargs = {
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Hello"}],
        }

        wrapped.chat.completions.create(**kwargs)
        wrapped.chat.completions.create(**kwargs)

        self.assertEqual(mock_client.chat.completions.call_count, 1)


if __name__ == "__main__":
    unittest.main()
