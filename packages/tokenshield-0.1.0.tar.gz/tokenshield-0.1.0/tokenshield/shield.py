"""
TokenShield メインラッパー

既存のAnthropic/OpenAIクライアントをラップして、
キャッシュ・ルーティング・トラッキングを透過的に注入する。

Usage:
    import anthropic
    from tokenshield import shield

    client = shield(anthropic.Client())
    # 以降は通常通り使える
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        messages=[{"role": "user", "content": "Hello"}],
    )
"""

import copy
from typing import Any, Dict, List, Optional

from tokenshield.cache import Cache
from tokenshield.config import ShieldConfig
from tokenshield.providers import DeepSeekProvider
from tokenshield.router import Router
from tokenshield.tracker import Tracker


def shield(client: Any, config: Optional[ShieldConfig] = None) -> Any:
    """
    Anthropic/OpenAIクライアントをラップして最適化を注入する。

    ラップ後もclient.messages.create()やclient.chat.completions.create()の
    引数・戻り値は完全に同じ。既存コードの変更は不要。

    Args:
        client: anthropic.Client() or openai.OpenAI()
        config: ShieldConfig（省略時はデフォルト設定）

    Returns:
        ラップされたクライアント（既存APIと100%互換）
    """
    if config is None:
        config = ShieldConfig()

    provider_type = _detect_provider(client)

    if provider_type == "anthropic":
        return _wrap_anthropic(client, config)
    elif provider_type == "openai":
        return _wrap_openai(client, config)
    else:
        raise ValueError(
            "サポートされていないクライアントです。"
            "anthropic.Anthropic() または openai.OpenAI() を渡してください。"
        )


def _detect_provider(client: Any) -> str:
    """クライアントの型からプロバイダーを判定。"""
    client_type = type(client).__name__
    module = type(client).__module__ or ""

    if "anthropic" in module.lower() or client_type in ("Anthropic", "Client"):
        # anthropic SDK のクラス名を確認
        if hasattr(client, "messages"):
            return "anthropic"
    if "openai" in module.lower() or client_type == "OpenAI":
        if hasattr(client, "chat"):
            return "openai"

    # フォールバック: 属性ベースで判定
    if hasattr(client, "messages") and hasattr(client.messages, "create"):
        return "anthropic"
    if hasattr(client, "chat") and hasattr(client.chat, "completions"):
        return "openai"

    return "unknown"


# ---------------------------------------------------------------------------
# Anthropic ラッパー
# ---------------------------------------------------------------------------


class _AnthropicMessagesProxy:
    """client.messages をラップするプロキシ。"""

    def __init__(
        self,
        original_messages: Any,
        cache: Cache,
        router: Router,
        tracker: Tracker,
        config: ShieldConfig,
        deepseek: Optional[DeepSeekProvider],
    ):
        self._original = original_messages
        self._cache = cache
        self._router = router
        self._tracker = tracker
        self._config = config
        self._deepseek = deepseek

    def create(self, **kwargs) -> Any:
        """messages.create() のインターセプト。"""
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "")
        tools = kwargs.get("tools", None)
        system = kwargs.get("system", None)
        stream = kwargs.get("stream", False)

        # system がリスト形式の場合、テキストに変換
        system_text = None
        if isinstance(system, str):
            system_text = system
        elif isinstance(system, list):
            parts = []
            for block in system:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
            system_text = "\n".join(parts) if parts else None

        # ストリーミングの場合はキャッシュ・ルーティングをスキップ
        if stream:
            return self._original.create(**kwargs)

        # メッセージをシリアライズ可能な形式に変換（キャッシュ用）
        serializable_messages = _serialize_messages(messages)

        # 1. キャッシュチェック
        if self._config.enable_cache:
            cached = self._cache.get(serializable_messages, model)
            if cached is not None:
                # トラッキング
                if self._config.enable_tracking:
                    self._tracker.record(
                        original_model=model,
                        actual_model=model,
                        input_tokens=0,
                        output_tokens=0,
                        cache_hit=True,
                        route_reason="cache_hit",
                    )
                return cached

        # 2. ルーティング判定
        provider, routed_model = self._router.route(
            serializable_messages, model, tools, system_text
        )
        route_reason = self._router.get_route_reason(
            serializable_messages, model, tools, system_text
        )

        # 3. API呼び出し
        response = None
        if provider == "deepseek" and self._deepseek is not None:
            try:
                response_dict = self._deepseek.create_message_anthropic_format(
                    messages=serializable_messages,
                    max_tokens=kwargs.get("max_tokens", 1024),
                    system=system_text,
                    temperature=kwargs.get("temperature"),
                )
                response = _AnthropicResponseProxy(response_dict)
            except Exception:
                # DeepSeek失敗 → 元モデルにフォールバック
                provider = "original"
                routed_model = model
                route_reason = "deepseek_fallback"
                response = None

        if response is None:
            response = self._original.create(**kwargs)
            routed_model = model

        # 4. キャッシュ保存
        if self._config.enable_cache:
            self._cache.set(serializable_messages, model, response)

        # 5. トラッキング
        if self._config.enable_tracking:
            usage = _extract_usage_anthropic(response)
            self._tracker.record(
                original_model=model,
                actual_model=routed_model,
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                cache_hit=False,
                route_reason=route_reason,
            )

        return response

    def __getattr__(self, name: str) -> Any:
        """create以外のメソッドは元のオブジェクトに委譲。"""
        return getattr(self._original, name)


class _AnthropicResponseProxy:
    """
    DeepSeekからのdict応答をAnthropic Messageオブジェクトのように振る舞わせるプロキシ。

    response.content[0].text のようなアクセスパターンをサポートする。
    """

    def __init__(self, data: Dict[str, Any]):
        self._data = data
        self.id = data.get("id", "")
        self.type = data.get("type", "message")
        self.role = data.get("role", "assistant")
        self.model = data.get("model", "")
        self.stop_reason = data.get("stop_reason", "end_turn")
        self.usage = _UsageProxy(data.get("usage", {}))
        self.content = [
            _ContentBlockProxy(block) for block in data.get("content", [])
        ]

    def __repr__(self) -> str:
        return "AnthropicResponseProxy(model={}, content_blocks={})".format(
            self.model, len(self.content)
        )


class _ContentBlockProxy:
    """content[i] のプロキシ。.type と .text をサポート。"""

    def __init__(self, block: Dict[str, Any]):
        self.type = block.get("type", "text")
        self.text = block.get("text", "")

    def __repr__(self) -> str:
        return "ContentBlock(type={}, text={})".format(
            self.type, self.text[:50] + "..." if len(self.text) > 50 else self.text
        )


class _UsageProxy:
    """usage のプロキシ。.input_tokens と .output_tokens をサポート。"""

    def __init__(self, usage: Dict[str, Any]):
        self.input_tokens = usage.get("input_tokens", 0)
        self.output_tokens = usage.get("output_tokens", 0)


class _AnthropicClientProxy:
    """Anthropicクライアント全体のプロキシ。"""

    def __init__(self, original_client: Any, messages_proxy: _AnthropicMessagesProxy):
        self._original = original_client
        self.messages = messages_proxy

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


def _wrap_anthropic(client: Any, config: ShieldConfig) -> Any:
    """Anthropicクライアントをラップ。"""
    cache = Cache(backend=config.cache_backend, ttl=config.cache_ttl)
    router = Router(config)
    tracker = Tracker(tracking_dir=config.tracking_dir)
    deepseek = (
        DeepSeekProvider(config.deepseek_api_key)
        if config.deepseek_api_key
        else None
    )

    messages_proxy = _AnthropicMessagesProxy(
        original_messages=client.messages,
        cache=cache,
        router=router,
        tracker=tracker,
        config=config,
        deepseek=deepseek,
    )

    proxy = _AnthropicClientProxy(client, messages_proxy)

    # ユーティリティアクセス
    proxy._tokenshield_cache = cache
    proxy._tokenshield_router = router
    proxy._tokenshield_tracker = tracker
    proxy._tokenshield_config = config

    return proxy


# ---------------------------------------------------------------------------
# OpenAI ラッパー
# ---------------------------------------------------------------------------


class _OpenAICompletionsProxy:
    """client.chat.completions をラップするプロキシ。"""

    def __init__(
        self,
        original_completions: Any,
        cache: Cache,
        router: Router,
        tracker: Tracker,
        config: ShieldConfig,
        deepseek: Optional[DeepSeekProvider],
    ):
        self._original = original_completions
        self._cache = cache
        self._router = router
        self._tracker = tracker
        self._config = config
        self._deepseek = deepseek

    def create(self, **kwargs) -> Any:
        """chat.completions.create() のインターセプト。"""
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "")
        tools = kwargs.get("tools", None)
        stream = kwargs.get("stream", False)

        # system promptを抽出
        system_text = None
        for msg in messages:
            if msg.get("role") == "system":
                system_text = msg.get("content", "")
                break

        # ストリーミングの場合はスキップ
        if stream:
            return self._original.create(**kwargs)

        # メッセージをシリアライズ
        serializable_messages = _serialize_messages(messages)

        # 1. キャッシュチェック
        if self._config.enable_cache:
            cached = self._cache.get(serializable_messages, model)
            if cached is not None:
                if self._config.enable_tracking:
                    self._tracker.record(
                        original_model=model,
                        actual_model=model,
                        input_tokens=0,
                        output_tokens=0,
                        cache_hit=True,
                        route_reason="cache_hit",
                    )
                return cached

        # 2. ルーティング
        provider, routed_model = self._router.route(
            serializable_messages, model, tools, system_text
        )
        route_reason = self._router.get_route_reason(
            serializable_messages, model, tools, system_text
        )

        # 3. API呼び出し
        response = None
        if provider == "deepseek" and self._deepseek is not None:
            try:
                response = self._deepseek.create_message_openai_format(
                    messages=serializable_messages,
                    max_tokens=kwargs.get("max_tokens"),
                    temperature=kwargs.get("temperature"),
                )
            except Exception:
                provider = "original"
                routed_model = model
                route_reason = "deepseek_fallback"
                response = None

        if response is None:
            response = self._original.create(**kwargs)
            routed_model = model

        # 4. キャッシュ保存
        if self._config.enable_cache:
            self._cache.set(serializable_messages, model, response)

        # 5. トラッキング
        if self._config.enable_tracking:
            usage = _extract_usage_openai(response)
            self._tracker.record(
                original_model=model,
                actual_model=routed_model,
                input_tokens=usage.get("input_tokens", 0),
                output_tokens=usage.get("output_tokens", 0),
                cache_hit=False,
                route_reason=route_reason,
            )

        return response

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _OpenAIChatProxy:
    """client.chat のプロキシ。"""

    def __init__(self, original_chat: Any, completions_proxy: _OpenAICompletionsProxy):
        self._original = original_chat
        self.completions = completions_proxy

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


class _OpenAIClientProxy:
    """OpenAIクライアント全体のプロキシ。"""

    def __init__(self, original_client: Any, chat_proxy: _OpenAIChatProxy):
        self._original = original_client
        self.chat = chat_proxy

    def __getattr__(self, name: str) -> Any:
        return getattr(self._original, name)


def _wrap_openai(client: Any, config: ShieldConfig) -> Any:
    """OpenAIクライアントをラップ。"""
    cache = Cache(backend=config.cache_backend, ttl=config.cache_ttl)
    router = Router(config)
    tracker = Tracker(tracking_dir=config.tracking_dir)
    deepseek = (
        DeepSeekProvider(config.deepseek_api_key)
        if config.deepseek_api_key
        else None
    )

    completions_proxy = _OpenAICompletionsProxy(
        original_completions=client.chat.completions,
        cache=cache,
        router=router,
        tracker=tracker,
        config=config,
        deepseek=deepseek,
    )

    chat_proxy = _OpenAIChatProxy(client.chat, completions_proxy)
    proxy = _OpenAIClientProxy(client, chat_proxy)

    proxy._tokenshield_cache = cache
    proxy._tokenshield_router = router
    proxy._tokenshield_tracker = tracker
    proxy._tokenshield_config = config

    return proxy


# ---------------------------------------------------------------------------
# ヘルパー
# ---------------------------------------------------------------------------


def _serialize_messages(messages: Any) -> List[Dict[str, Any]]:
    """
    メッセージリストをdictのリストに正規化する。
    Anthropic SDKのMessageオブジェクト等もdictに変換。
    """
    result = []
    for msg in messages:
        if isinstance(msg, dict):
            result.append(msg)
        else:
            # SDKオブジェクトの場合
            entry = {}
            if hasattr(msg, "role"):
                entry["role"] = msg.role
            if hasattr(msg, "content"):
                content = msg.content
                if isinstance(content, str):
                    entry["content"] = content
                elif isinstance(content, list):
                    entry["content"] = [
                        {"type": b.type, "text": getattr(b, "text", "")}
                        if hasattr(b, "type") else str(b)
                        for b in content
                    ]
                else:
                    entry["content"] = str(content)
            result.append(entry)
    return result


def _extract_usage_anthropic(response: Any) -> Dict[str, int]:
    """Anthropicレスポンスからusageを抽出。"""
    if hasattr(response, "usage"):
        usage = response.usage
        return {
            "input_tokens": getattr(usage, "input_tokens", 0),
            "output_tokens": getattr(usage, "output_tokens", 0),
        }
    return {"input_tokens": 0, "output_tokens": 0}


def _extract_usage_openai(response: Any) -> Dict[str, int]:
    """OpenAIレスポンスからusageを抽出。"""
    if hasattr(response, "usage") and response.usage is not None:
        return {
            "input_tokens": getattr(response.usage, "prompt_tokens", 0),
            "output_tokens": getattr(response.usage, "completion_tokens", 0),
        }
    return {"input_tokens": 0, "output_tokens": 0}
