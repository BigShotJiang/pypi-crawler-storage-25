"""
TokenShield キャッシュレイヤー

同一リクエストの再呼び出しをインターセプトしてAPI呼び出しを削減する。
"""

import hashlib
import json
import time
from typing import Any, Dict, List, Optional


class Cache:
    """
    リクエスト/レスポンスのキャッシュ。

    初期実装はインメモリdict。Redis対応は後のフェーズで追加。
    """

    def __init__(self, backend: str = "memory", ttl: int = 300):
        """
        Args:
            backend: "memory"（デフォルト）or "redis"（未実装）
            ttl: キャッシュ有効期間（秒）
        """
        self.backend = backend
        self.ttl = ttl
        self._store: Dict[str, Dict[str, Any]] = {}

        if backend == "redis":
            raise NotImplementedError(
                "Redisバックエンドは Phase 2 で対応予定です。"
                "現在は backend='memory' を使用してください。"
            )

    def get(self, messages: List[Dict], model: str) -> Optional[Any]:
        """
        キャッシュヒットなら応答オブジェクトを返す。
        ミスまたは期限切れならNone。

        Args:
            messages: メッセージリスト
            model: モデル名

        Returns:
            キャッシュされたレスポンスまたはNone
        """
        key = self._hash_request(messages, model)
        entry = self._store.get(key)

        if entry is None:
            return None

        # TTLチェック
        if time.time() - entry["timestamp"] > self.ttl:
            del self._store[key]
            return None

        return entry["response"]

    def set(self, messages: List[Dict], model: str, response: Any) -> None:
        """
        応答をキャッシュに保存。

        Args:
            messages: メッセージリスト
            model: モデル名
            response: レスポンスオブジェクト
        """
        key = self._hash_request(messages, model)
        self._store[key] = {
            "response": response,
            "timestamp": time.time(),
        }

    def _hash_request(self, messages: List[Dict], model: str) -> str:
        """
        リクエストのハッシュを計算。
        メッセージ内容とモデル名を結合してSHA256ハッシュを生成する。

        Args:
            messages: メッセージリスト
            model: モデル名

        Returns:
            ハッシュ文字列
        """
        # メッセージを正規化してJSON化
        payload = json.dumps(
            {"messages": messages, "model": model},
            sort_keys=True,
            ensure_ascii=False,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def clear(self) -> None:
        """キャッシュを全クリア。"""
        self._store.clear()

    @property
    def size(self) -> int:
        """現在のキャッシュエントリ数。"""
        return len(self._store)
