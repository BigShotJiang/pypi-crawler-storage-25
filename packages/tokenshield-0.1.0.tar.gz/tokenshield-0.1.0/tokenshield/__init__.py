"""
TokenShield - LLMコスト最適化SDKラッパー

既存のAnthropic/OpenAI SDKコードを1行変更するだけで
キャッシュ・スマートルーティング・コスト追跡が自動で効く。

Usage:
    from tokenshield import shield
    client = shield(anthropic.Client())
"""

from tokenshield.shield import shield
from tokenshield.config import ShieldConfig

__version__ = "0.1.0"
__all__ = ["shield", "ShieldConfig"]
