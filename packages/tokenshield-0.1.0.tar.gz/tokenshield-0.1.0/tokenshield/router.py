"""
TokenShield スマートルーティングエンジン

クエリの難易度を軽量に判定し、最適なモデル/プロバイダーに振り分ける。
API呼び出し不要のキーワード＋ヒューリスティクスベース。
"""

import re
from typing import Dict, List, Optional, Tuple

from tokenshield.config import ShieldConfig


# 難易度判定用キーワード
_EASY_KEYWORDS = [
    # 日本語
    "翻訳", "翻訳して", "要約", "要約して", "まとめて",
    "リスト化", "箇条書き", "定型文", "テンプレ",
    "挨拶文", "お礼", "返信文",
    # 英語
    "translate", "summarize", "summary", "list",
    "template", "boilerplate", "rewrite", "rephrase",
    # 中国語
    "翻译", "总结", "摘要",
]

_HARD_KEYWORDS = [
    # 日本語
    "戦略", "分析", "設計", "アーキテクチャ", "デバッグ",
    "リファクタ", "最適化", "推論", "論理", "証明",
    "比較検討", "意思決定", "創造", "企画",
    # 英語
    "strategy", "analyze", "analysis", "architect", "debug",
    "refactor", "optimize", "reason", "prove", "design",
    "decision", "creative", "brainstorm", "complex",
    # 中国語
    "战略", "分析", "设计", "优化",
]


class Router:
    """
    メッセージの難易度を判定して最適なモデルとプロバイダーを返す。

    判定基準（軽量・API不要）:
    - メッセージの長さ
    - system promptの有無と複雑さ
    - キーワードベース
    - tool_useの有無
    """

    def __init__(self, config: Optional[ShieldConfig] = None):
        self.config = config or ShieldConfig()

    def route(
        self,
        messages: List[Dict],
        model: str,
        tools: Optional[List] = None,
        system: Optional[str] = None,
        **kwargs,
    ) -> Tuple[str, str]:
        """
        メッセージの難易度を判定して最適なモデルとプロバイダーを返す。

        Args:
            messages: メッセージリスト
            model: ユーザーが指定した元のモデル名
            tools: ツール定義リスト（Anthropic tool_use）
            system: system prompt文字列
            **kwargs: その他のパラメータ

        Returns:
            (provider, model) のタプル。
            例: ("deepseek", "deepseek-chat") or ("original", "claude-sonnet-4-20250514")
        """
        # ルーティング無効ならそのまま
        if not self.config.enable_routing:
            return ("original", model)

        # DeepSeek APIキーがなければルーティング不可
        if not self.config.deepseek_api_key:
            return ("original", model)

        # ツール使用がある場合は元モデル維持（品質が落ちるため）
        if tools:
            return ("original", model)

        # force_original_keywords に該当するか
        text = self._extract_text(messages, system)
        if self.config.force_original_keywords:
            for kw in self.config.force_original_keywords:
                if kw.lower() in text.lower():
                    return ("original", model)

        # 難易度スコアを計算
        score = self._compute_difficulty(messages, text, system)

        # thresholdと比較
        if score < self.config.routing_threshold:
            return ("deepseek", "deepseek-chat")
        else:
            return ("original", model)

    def _extract_text(
        self,
        messages: List[Dict],
        system: Optional[str] = None,
    ) -> str:
        """メッセージとsystemプロンプトからテキストを抽出。"""
        parts = []
        if system:
            parts.append(system)
        for msg in messages:
            content = msg.get("content", "")
            if isinstance(content, str):
                parts.append(content)
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        parts.append(block.get("text", ""))
        return "\n".join(parts)

    def _compute_difficulty(
        self,
        messages: List[Dict],
        text: str,
        system: Optional[str] = None,
    ) -> float:
        """
        難易度スコアを 0.0（簡単）〜 1.0（難しい）で返す。

        判定要素:
        1. キーワードマッチ
        2. メッセージの長さ
        3. system promptの複雑さ
        4. 会話ターン数
        """
        score = 0.5  # ベースライン

        text_lower = text.lower()

        # 1. キーワードマッチ
        easy_count = sum(1 for kw in _EASY_KEYWORDS if kw.lower() in text_lower)
        hard_count = sum(1 for kw in _HARD_KEYWORDS if kw.lower() in text_lower)

        if easy_count > 0 and hard_count == 0:
            score -= 0.3
        elif hard_count > easy_count:
            score += 0.2
        elif easy_count > hard_count:
            score -= 0.2

        # 2. テキスト長（長い=複雑な傾向）
        total_len = len(text)
        if total_len < 100:
            score -= 0.1  # 短い=簡単な可能性
        elif total_len > 2000:
            score += 0.1  # 長い=複雑な可能性

        # 3. system promptの複雑さ
        if system:
            sys_len = len(system)
            if sys_len > 500:
                score += 0.1  # 複雑なsystem prompt
            if sys_len > 2000:
                score += 0.1

        # 4. 会話ターン数
        user_turns = sum(1 for m in messages if m.get("role") == "user")
        if user_turns > 5:
            score += 0.1  # 長い会話=文脈依存で複雑

        # 5. コードブロックの有無
        if "```" in text:
            score += 0.1

        # クランプ
        return max(0.0, min(1.0, score))

    def get_route_reason(
        self,
        messages: List[Dict],
        model: str,
        tools: Optional[List] = None,
        system: Optional[str] = None,
    ) -> str:
        """ルーティング判定理由を人間が読める文字列で返す（デバッグ用）。"""
        if not self.config.enable_routing:
            return "routing_disabled"
        if not self.config.deepseek_api_key:
            return "no_deepseek_api_key"
        if tools:
            return "tool_use_detected"

        text = self._extract_text(messages, system)

        if self.config.force_original_keywords:
            for kw in self.config.force_original_keywords:
                if kw.lower() in text.lower():
                    return "force_original_keyword: {}".format(kw)

        score = self._compute_difficulty(messages, text, system)
        provider, routed_model = self.route(messages, model, tools, system)

        return "difficulty_score={:.2f}, threshold={:.2f} -> {}:{}".format(
            score, self.config.routing_threshold, provider, routed_model
        )
