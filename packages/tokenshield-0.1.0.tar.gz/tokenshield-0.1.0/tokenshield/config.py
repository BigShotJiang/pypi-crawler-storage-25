"""
TokenShield 設定モジュール
"""

import os
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class ShieldConfig:
    """TokenShieldの設定。shield()に渡すか、デフォルトで使用。"""

    # ルーティング
    enable_routing: bool = True
    deepseek_api_key: str = ""
    routing_threshold: float = 0.5  # 0=全部DeepSeek、1=全部元モデル

    # キャッシュ
    enable_cache: bool = True
    cache_backend: str = "memory"  # "memory" or "redis"
    cache_ttl: int = 300  # 秒

    # トラッキング
    enable_tracking: bool = True
    tracking_dir: str = "~/.tokenshield"

    # セキュリティ
    enable_pii_removal: bool = False  # Phase 2

    # ルーティング対象外（常に元モデルを使う）のキーワード
    force_original_keywords: Optional[List[str]] = None

    def __post_init__(self):
        # 環境変数からDeepSeek APIキーを読む
        if not self.deepseek_api_key:
            self.deepseek_api_key = os.environ.get("DEEPSEEK_API_KEY", "")

        # tracking_dirのチルダ展開
        self.tracking_dir = os.path.expanduser(self.tracking_dir)

        if self.force_original_keywords is None:
            self.force_original_keywords = ["機密", "confidential", "secret"]
