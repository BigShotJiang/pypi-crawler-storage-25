"""
TokenShield プロバイダーレイヤー

DeepSeek等の代替プロバイダーを呼び出し、
元のSDK（Anthropic/OpenAI）のレスポンス形式に変換して返す。
"""

from typing import Any, Dict, List, Optional


class DeepSeekProvider:
    """
    DeepSeek APIプロバイダー。

    OpenAI互換APIを使ってDeepSeekを呼び出し、
    Anthropic形式またはOpenAI形式のレスポンスに変換して返す。
    """

    def __init__(self, api_key: str):
        self.api_key = api_key
        self._client = None

    def _get_client(self) -> Any:
        """OpenAIクライアント（DeepSeek互換）を遅延初期化。"""
        if self._client is None:
            try:
                from openai import OpenAI
            except ImportError:
                raise ImportError(
                    "DeepSeekルーティングには openai パッケージが必要です: "
                    "pip install openai"
                )
            self._client = OpenAI(
                base_url="https://api.deepseek.com/v1",
                api_key=self.api_key,
            )
        return self._client

    def create_message_anthropic_format(
        self,
        messages: List[Dict],
        max_tokens: int = 1024,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        DeepSeekでメッセージ生成し、Anthropic Messages APIのレスポンス形式で返す。

        Args:
            messages: Anthropic形式のメッセージリスト
            max_tokens: 最大出力トークン数
            system: system prompt
            temperature: 温度パラメータ
            **kwargs: その他（無視される）

        Returns:
            Anthropic Messages API互換のレスポンスdict
        """
        client = self._get_client()

        # Anthropic形式 → OpenAI形式に変換
        openai_messages = self._convert_messages_to_openai(messages, system)

        call_kwargs = {
            "model": "deepseek-chat",
            "messages": openai_messages,
            "max_tokens": max_tokens,
        }
        if temperature is not None:
            call_kwargs["temperature"] = temperature

        response = client.chat.completions.create(**call_kwargs)

        # OpenAI形式 → Anthropic形式に変換
        return self._convert_response_to_anthropic(response)

    def create_message_openai_format(
        self,
        messages: List[Dict],
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        **kwargs,
    ) -> Any:
        """
        DeepSeekでメッセージ生成し、OpenAI Chat Completions APIのレスポンスをそのまま返す。

        Args:
            messages: OpenAI形式のメッセージリスト
            max_tokens: 最大出力トークン数
            temperature: 温度パラメータ

        Returns:
            OpenAI ChatCompletion互換レスポンス
        """
        client = self._get_client()

        call_kwargs = {
            "model": "deepseek-chat",
            "messages": messages,
        }
        if max_tokens is not None:
            call_kwargs["max_tokens"] = max_tokens
        if temperature is not None:
            call_kwargs["temperature"] = temperature

        return client.chat.completions.create(**call_kwargs)

    def _convert_messages_to_openai(
        self,
        messages: List[Dict],
        system: Optional[str] = None,
    ) -> List[Dict[str, str]]:
        """Anthropic形式のメッセージをOpenAI形式に変換。"""
        openai_messages = []

        # system prompt → OpenAI形式の system role
        if system:
            openai_messages.append({"role": "system", "content": system})

        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")

            # Anthropic形式ではcontentがリスト（content blocks）の場合がある
            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                content = "\n".join(text_parts)

            # Anthropicの role "assistant" はそのまま
            openai_messages.append({"role": role, "content": content})

        return openai_messages

    def _convert_response_to_anthropic(self, openai_response: Any) -> Dict[str, Any]:
        """
        OpenAI ChatCompletion レスポンスを Anthropic Messages API 形式のdictに変換。

        注意: これは簡易変換。実際のAnthropic SDKのMessageオブジェクトとは
        型が異なるが、.content[0].text 等のアクセスパターンは
        shield.py側でプロキシオブジェクトとして対応する。
        """
        choice = openai_response.choices[0]
        usage = openai_response.usage

        return {
            "id": openai_response.id or "msg_deepseek",
            "type": "message",
            "role": "assistant",
            "content": [
                {
                    "type": "text",
                    "text": choice.message.content or "",
                }
            ],
            "model": "deepseek-chat",
            "stop_reason": self._map_finish_reason(choice.finish_reason),
            "usage": {
                "input_tokens": usage.prompt_tokens if usage else 0,
                "output_tokens": usage.completion_tokens if usage else 0,
            },
        }

    @staticmethod
    def _map_finish_reason(finish_reason: Optional[str]) -> str:
        """OpenAIのfinish_reasonをAnthropicのstop_reasonにマッピング。"""
        mapping = {
            "stop": "end_turn",
            "length": "max_tokens",
            "content_filter": "end_turn",
        }
        return mapping.get(finish_reason or "stop", "end_turn")
