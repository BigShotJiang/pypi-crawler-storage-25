"""
TokenShield 使用量トラッキング

API呼び出しごとのコスト・トークン数・ルーティング情報を記録し、
節約額のサマリーを提供する。
"""

import json
import os
import time
from datetime import datetime
from typing import Any, Dict, List, Optional


# モデル別料金テーブル（$/1M tokens）
# 2026-04時点の概算。新モデル追加時はここに追記する。
PRICING = {
    # Anthropic
    "claude-sonnet-4-20250514": {"input": 3.0, "output": 15.0},
    "claude-opus-4-20250514": {"input": 15.0, "output": 75.0},
    "claude-3-5-sonnet-20241022": {"input": 3.0, "output": 15.0},
    "claude-3-5-haiku-20241022": {"input": 0.80, "output": 4.0},
    "claude-3-opus-20240229": {"input": 15.0, "output": 75.0},
    "claude-3-sonnet-20240229": {"input": 3.0, "output": 15.0},
    "claude-3-haiku-20240307": {"input": 0.25, "output": 1.25},
    # OpenAI
    "gpt-4o": {"input": 2.50, "output": 10.0},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "gpt-4-turbo": {"input": 10.0, "output": 30.0},
    "gpt-4": {"input": 30.0, "output": 60.0},
    "gpt-3.5-turbo": {"input": 0.50, "output": 1.50},
    "o1": {"input": 15.0, "output": 60.0},
    "o1-mini": {"input": 3.0, "output": 12.0},
    # DeepSeek
    "deepseek-chat": {"input": 0.14, "output": 0.28},
    "deepseek-reasoner": {"input": 0.55, "output": 2.19},
}


def _calculate_cost(model: str, input_tokens: int, output_tokens: int) -> float:
    """モデルとトークン数からコスト（USD）を計算。"""
    pricing = PRICING.get(model)
    if pricing is None:
        # 未知のモデルは中間的な価格を仮定
        pricing = {"input": 3.0, "output": 15.0}
    return (
        input_tokens * pricing["input"] / 1_000_000
        + output_tokens * pricing["output"] / 1_000_000
    )


class Tracker:
    """
    API呼び出しのコスト・使用量を記録し、節約サマリーを提供する。

    データは ~/.tokenshield/usage.jsonl にJSONL形式で永続化する。
    """

    def __init__(self, tracking_dir: str = "~/.tokenshield"):
        self.tracking_dir = os.path.expanduser(tracking_dir)
        self._records: List[Dict[str, Any]] = []
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        """トラッキングディレクトリを作成。"""
        os.makedirs(self.tracking_dir, exist_ok=True)

    @property
    def _log_path(self) -> str:
        return os.path.join(self.tracking_dir, "usage.jsonl")

    def record(
        self,
        original_model: str,
        actual_model: str,
        input_tokens: int,
        output_tokens: int,
        cache_hit: bool,
        route_reason: str,
    ) -> Dict[str, Any]:
        """
        APIリクエストの使用量を記録する。

        Args:
            original_model: ユーザーが指定したモデル
            actual_model: 実際に使われたモデル
            input_tokens: 入力トークン数
            output_tokens: 出力トークン数
            cache_hit: キャッシュヒットしたか
            route_reason: ルーティング判定理由

        Returns:
            記録されたレコードのdict
        """
        original_cost = _calculate_cost(original_model, input_tokens, output_tokens)
        actual_cost = (
            0.0 if cache_hit
            else _calculate_cost(actual_model, input_tokens, output_tokens)
        )
        savings = original_cost - actual_cost

        entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "epoch": time.time(),
            "original_model": original_model,
            "actual_model": actual_model,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "original_cost_usd": round(original_cost, 6),
            "actual_cost_usd": round(actual_cost, 6),
            "savings_usd": round(savings, 6),
            "cache_hit": cache_hit,
            "route_reason": route_reason,
        }

        self._records.append(entry)
        self._persist(entry)
        return entry

    def _persist(self, entry: Dict[str, Any]) -> None:
        """レコードをJSONLファイルに追記。"""
        try:
            with open(self._log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError:
            pass  # ファイル書き込み失敗は静かに無視（MVP）

    def get_summary(self, hours: int = 24) -> Dict[str, Any]:
        """
        直近N時間の使用量サマリーを返す。

        Args:
            hours: 集計対象の時間（デフォルト24時間）

        Returns:
            サマリーdict
        """
        cutoff = time.time() - hours * 3600
        recent = [r for r in self._records if r["epoch"] > cutoff]

        if not recent:
            return {
                "period_hours": hours,
                "total_requests": 0,
                "cache_hits": 0,
                "routed_to_deepseek": 0,
                "total_original_cost_usd": 0.0,
                "total_actual_cost_usd": 0.0,
                "total_savings_usd": 0.0,
                "savings_pct": 0.0,
            }

        total_original = sum(r["original_cost_usd"] for r in recent)
        total_actual = sum(r["actual_cost_usd"] for r in recent)
        total_savings = sum(r["savings_usd"] for r in recent)
        savings_pct = (total_savings / total_original * 100) if total_original > 0 else 0.0

        return {
            "period_hours": hours,
            "total_requests": len(recent),
            "cache_hits": sum(1 for r in recent if r["cache_hit"]),
            "routed_to_deepseek": sum(
                1 for r in recent if r["actual_model"] == "deepseek-chat"
            ),
            "total_original_cost_usd": round(total_original, 6),
            "total_actual_cost_usd": round(total_actual, 6),
            "total_savings_usd": round(total_savings, 6),
            "savings_pct": round(savings_pct, 2),
        }

    def get_savings_total(self) -> Dict[str, Any]:
        """
        累計の節約サマリーを返す。

        Returns:
            累計サマリーdict
        """
        if not self._records:
            return {
                "total_requests": 0,
                "total_original_cost_usd": 0.0,
                "total_actual_cost_usd": 0.0,
                "total_savings_usd": 0.0,
                "savings_pct": 0.0,
            }

        total_original = sum(r["original_cost_usd"] for r in self._records)
        total_actual = sum(r["actual_cost_usd"] for r in self._records)
        total_savings = sum(r["savings_usd"] for r in self._records)
        savings_pct = (total_savings / total_original * 100) if total_original > 0 else 0.0

        return {
            "total_requests": len(self._records),
            "total_original_cost_usd": round(total_original, 6),
            "total_actual_cost_usd": round(total_actual, 6),
            "total_savings_usd": round(total_savings, 6),
            "savings_pct": round(savings_pct, 2),
        }
