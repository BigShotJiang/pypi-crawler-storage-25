"""
TokenShield — Smart Dashboard v4
デモモード + 時系列グラフ + 余白改善
"""

import streamlit as st
import random
from datetime import datetime, timedelta
from tokenshield.dashboard import get_dashboard_data, USD_TO_JPY


CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

    .stApp {
        background: #fff;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        color: #111;
    }

    .ts-nav {
        display: flex; align-items: center; justify-content: space-between;
        padding: 16px 0; border-bottom: 1px solid #f0f0f0; margin-bottom: 48px;
    }
    .ts-nav-left { display: flex; align-items: center; gap: 10px; }
    .ts-nav-logo {
        width: 28px; height: 28px; background: #111; border-radius: 7px;
        display: flex; align-items: center; justify-content: center;
        color: #fff; font-weight: 800; font-size: 0.75rem;
    }
    .ts-nav-name { font-size: 0.95rem; font-weight: 600; color: #111; }
    .ts-nav-right { display: flex; align-items: center; gap: 12px; }
    .ts-badge {
        font-size: 0.65rem; font-weight: 600; padding: 3px 8px;
        border-radius: 20px; letter-spacing: 0.02em;
    }
    .badge-active { background: #f0fdfa; color: #0D9488; }
    .badge-demo { background: #fef3c7; color: #d97706; }
    .badge-period { background: #f5f5f5; color: #666; }

    .ts-hero {
        text-align: center; padding: 48px 0 24px 0;
    }
    .ts-hero-eyebrow {
        font-size: 0.7rem; font-weight: 600; color: #999;
        text-transform: uppercase; letter-spacing: 0.12em;
    }
    .ts-hero-amount {
        font-size: 4.5rem; font-weight: 800; color: #111;
        letter-spacing: -0.04em; line-height: 1; margin: 10px 0;
    }
    .ts-hero-delta {
        display: inline-block; font-size: 0.85rem; font-weight: 600;
        color: #0D9488; background: #f0fdfa; padding: 4px 14px;
        border-radius: 20px;
    }

    .ts-routing-bar {
        display: flex; gap: 2px; border-radius: 8px; overflow: hidden;
        height: 28px; margin: 40px 0 10px 0;
    }
    .ts-rb-seg {
        height: 100%; display: flex; align-items: center; justify-content: center;
        font-size: 0.7rem; font-weight: 600; letter-spacing: 0.02em;
        min-width: 40px;
    }
    .rb-cache { background: #0D9488; color: #fff; }
    .rb-ds { background: #1E293B; color: #fff; }
    .rb-orig { background: #E5E7EB; color: #666; }

    .ts-routing-legend {
        display: flex; gap: 20px; justify-content: center; margin-bottom: 8px;
    }
    .ts-rl-item { display: flex; align-items: center; gap: 5px; font-size: 0.75rem; color: #888; }
    .ts-rl-dot { width: 6px; height: 6px; border-radius: 50%; }

    .ts-kpi-grid {
        display: grid; grid-template-columns: repeat(4, 1fr);
        gap: 12px; margin: 40px 0;
    }
    .ts-kpi {
        background: #fff; border: 1px solid #eee; border-radius: 12px; padding: 22px;
    }
    .ts-kpi-label {
        font-size: 0.68rem; font-weight: 500; color: #999;
        text-transform: uppercase; letter-spacing: 0.06em;
    }
    .ts-kpi-row { display: flex; align-items: baseline; gap: 8px; margin-top: 8px; }
    .ts-kpi-val { font-size: 1.6rem; font-weight: 700; color: #111; }
    .ts-kpi-change {
        font-size: 0.72rem; font-weight: 600; padding: 2px 7px; border-radius: 4px;
    }
    .change-up { color: #0D9488; background: #f0fdfa; }
    .change-neutral { color: #888; background: #f5f5f5; }

    .ts-section-label {
        font-size: 0.68rem; font-weight: 600; color: #bbb;
        text-transform: uppercase; letter-spacing: 0.1em;
        margin: 48px 0 16px 0;
    }

    /* ビフォーアフター比較バー */
    .ts-compare {
        background: #fff; border: 1px solid #eee; border-radius: 12px; padding: 28px;
    }
    .ts-compare-row { margin: 16px 0; }
    .ts-compare-header {
        display: flex; justify-content: space-between; margin-bottom: 6px;
    }
    .ts-compare-name { font-size: 0.82rem; color: #888; }
    .ts-compare-val { font-size: 0.85rem; font-weight: 600; color: #111; }
    .ts-compare-bar {
        height: 8px; border-radius: 4px; background: #f0f0f0; overflow: hidden;
    }
    .ts-compare-fill { height: 100%; border-radius: 4px; }
    .fill-orig { background: #e0e0e0; }
    .fill-actual { background: #111; }
    .fill-saved { background: #0D9488; }
    .ts-compare-divider {
        border: none; border-top: 1px dashed #eee; margin: 20px 0;
    }
    .ts-compare-total {
        display: flex; justify-content: space-between; align-items: center;
    }
    .ts-compare-total-label { font-size: 0.85rem; color: #888; }
    .ts-compare-total-val { font-size: 1.3rem; font-weight: 700; color: #0D9488; }

    /* モデルリスト */
    .ts-model-card {
        background: #fff; border: 1px solid #eee; border-radius: 12px; padding: 28px;
    }
    .ts-model-item {
        display: flex; align-items: center; justify-content: space-between;
        padding: 14px 0; border-bottom: 1px solid #f8f8f8;
    }
    .ts-model-item:last-child { border-bottom: none; }
    .ts-model-left { display: flex; align-items: center; gap: 12px; }
    .ts-model-icon {
        width: 34px; height: 34px; border-radius: 9px;
        display: flex; align-items: center; justify-content: center;
        font-size: 0.72rem; font-weight: 700;
    }
    .mi-ds { background: #f5f5f5; color: #333; }
    .mi-cl { background: #faf5ff; color: #7c3aed; }
    .mi-ca { background: #f0fdfa; color: #0D9488; }
    .ts-model-name { font-size: 0.85rem; font-weight: 500; color: #333; }
    .ts-model-pct { font-size: 0.75rem; color: #aaa; }
    .ts-model-right { text-align: right; }
    .ts-model-count { font-size: 0.9rem; font-weight: 600; color: #111; }
    .ts-model-cost { font-size: 0.75rem; color: #999; }

    /* 時系列グラフ */
    .ts-chart-card {
        background: #fff; border: 1px solid #eee; border-radius: 12px;
        padding: 28px; margin-top: 12px;
    }
    .ts-chart-svg { width: 100%; }
    .ts-chart-axis { font-size: 0.7rem; fill: #bbb; font-family: Inter, sans-serif; }
    .ts-chart-grid { stroke: #f0f0f0; stroke-width: 1; }
    .ts-chart-line { fill: none; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round; }
    .ts-chart-area { opacity: 0.08; }
    .ts-chart-dot { stroke-width: 2; }
    .ts-chart-legend {
        display: flex; gap: 20px; justify-content: center; margin-top: 16px;
    }
    .ts-cl-item { display: flex; align-items: center; gap: 6px; font-size: 0.75rem; color: #888; }
    .ts-cl-line { width: 16px; height: 2px; border-radius: 1px; }

    /* インサイト */
    .ts-insight {
        background: #fafafa; border-radius: 12px; padding: 20px 24px;
        margin-top: 48px; display: flex; align-items: flex-start; gap: 12px;
        border: 1px solid #f0f0f0;
    }
    .ts-insight-icon { font-size: 1.1rem; margin-top: 1px; }
    .ts-insight-text { font-size: 0.85rem; color: #555; line-height: 1.6; }
    .ts-insight-bold { font-weight: 600; color: #111; }

    /* 予測 */
    .ts-forecast-grid {
        display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-top: 48px;
    }
    .ts-fc {
        background: #fafafa; border-radius: 12px; padding: 32px; text-align: center;
    }
    .ts-fc-label {
        font-size: 0.68rem; font-weight: 600; color: #bbb;
        text-transform: uppercase; letter-spacing: 0.08em;
    }
    .ts-fc-val {
        font-size: 2.2rem; font-weight: 800; color: #111;
        margin: 8px 0 4px 0; letter-spacing: -0.02em;
    }
    .ts-fc-sub { font-size: 0.85rem; color: #999; }

    div[data-testid="stSidebar"] { background: #fafafa; border-right: 1px solid #f0f0f0; }
</style>
"""


def _generate_demo_data():
    """デモ用のリアルなサンプルデータ"""
    now = datetime.now()
    days = 14
    daily = {}
    for i in range(days):
        d = now - timedelta(days=days - 1 - i)
        key = d.strftime("%m/%d")
        base_reqs = random.randint(80, 200)
        ds_ratio = random.uniform(0.45, 0.65)
        cache_ratio = random.uniform(0.08, 0.20)
        orig_ratio = 1 - ds_ratio - cache_ratio

        orig_cost = base_reqs * random.uniform(0.08, 0.15)
        actual_cost = base_reqs * (ds_ratio * 0.008 + orig_ratio * 0.10)
        daily[key] = {
            "requests": base_reqs,
            "original_cost": round(orig_cost, 2),
            "actual_cost": round(actual_cost, 2),
            "savings": round(orig_cost - actual_cost, 2),
        }

    total_reqs = sum(d["requests"] for d in daily.values())
    total_orig = sum(d["original_cost"] for d in daily.values())
    total_actual = sum(d["actual_cost"] for d in daily.values())
    total_savings = total_orig - total_actual
    savings_pct = (total_savings / total_orig * 100) if total_orig > 0 else 0

    cache_hits = int(total_reqs * 0.14)
    ds_routes = int(total_reqs * 0.54)
    orig_kept = total_reqs - cache_hits - ds_routes

    return {
        "total_requests": total_reqs,
        "total_original_cost": round(total_orig, 4),
        "total_actual_cost": round(total_actual, 4),
        "total_savings": round(total_savings, 4),
        "savings_pct": round(savings_pct, 1),
        "cache_hits": cache_hits,
        "deepseek_routes": ds_routes,
        "original_kept": orig_kept,
        "model_stats": {
            "deepseek-chat": {"count": ds_routes, "cost": round(ds_routes * 0.008, 4)},
            "claude-sonnet-4-6": {"count": orig_kept, "cost": round(orig_kept * 0.10, 4)},
            "cache": {"count": cache_hits, "cost": 0.0},
        },
        "daily": daily,
        "monthly_projection_usd": round(total_savings / days * 30, 2),
        "monthly_projection_jpy": round(total_savings / days * 30 * USD_TO_JPY, 0),
        "yearly_projection_usd": round(total_savings / days * 365, 2),
        "yearly_projection_jpy": round(total_savings / days * 365 * USD_TO_JPY, 0),
    }


def _build_chart_svg(daily_data, width=700, height=200):
    """日別推移の時系列グラフSVG"""
    days = list(daily_data.keys())
    if len(days) < 2:
        return ""

    savings = [daily_data[d]["savings"] for d in days]
    orig = [daily_data[d]["original_cost"] for d in days]

    pad_l, pad_r, pad_t, pad_b = 40, 20, 20, 30
    w = width - pad_l - pad_r
    h = height - pad_t - pad_b

    all_vals = savings + orig
    mn = 0
    mx = max(all_vals) if all_vals else 1
    if mx == mn:
        mx = mn + 1

    def to_xy(i, v):
        x = pad_l + (i / (len(days) - 1)) * w
        y = pad_t + h - ((v - mn) / (mx - mn)) * h
        return x, y

    # グリッドライン
    grid = ""
    for j in range(5):
        gy = pad_t + h * j / 4
        gv = mx - (mx - mn) * j / 4
        grid += '<line x1="{}" y1="{}" x2="{}" y2="{}" class="ts-chart-grid"/>'.format(pad_l, gy, width - pad_r, gy)
        grid += '<text x="{}" y="{}" class="ts-chart-axis" text-anchor="end">${:.1f}</text>'.format(pad_l - 6, gy + 4, gv)

    # X軸ラベル（間引き）
    x_labels = ""
    step = max(1, len(days) // 7)
    for i in range(0, len(days), step):
        x, _ = to_xy(i, 0)
        x_labels += '<text x="{}" y="{}" class="ts-chart-axis" text-anchor="middle">{}</text>'.format(x, height - 4, days[i])

    # 節約額ライン + エリア
    savings_points = " ".join("{:.1f},{:.1f}".format(*to_xy(i, v)) for i, v in enumerate(savings))
    area_points = savings_points
    last_x, _ = to_xy(len(days) - 1, 0)
    first_x, _ = to_xy(0, 0)
    bottom_y = pad_t + h
    area_points += " {:.1f},{:.1f} {:.1f},{:.1f}".format(last_x, bottom_y, first_x, bottom_y)

    # 元コストライン
    orig_points = " ".join("{:.1f},{:.1f}".format(*to_xy(i, v)) for i, v in enumerate(orig))

    # ドット
    dots = ""
    for i, v in enumerate(savings):
        x, y = to_xy(i, v)
        dots += '<circle cx="{:.1f}" cy="{:.1f}" r="3" fill="#0D9488" stroke="#fff" class="ts-chart-dot"/>'.format(x, y)

    svg = """
    <svg viewBox="0 0 {w} {h}" class="ts-chart-svg">
        {grid}
        {xlabels}
        <polygon points="{area}" fill="#0D9488" class="ts-chart-area"/>
        <polyline points="{orig}" class="ts-chart-line" stroke="#e0e0e0"/>
        <polyline points="{savings}" class="ts-chart-line" stroke="#0D9488"/>
        {dots}
    </svg>
    """.format(w=width, h=height, grid=grid, xlabels=x_labels,
               area=area_points, orig=orig_points, savings=savings_points, dots=dots)
    return svg


def main():
    st.set_page_config(page_title="TokenShield", page_icon="🛡️", layout="wide")
    st.markdown(CSS, unsafe_allow_html=True)

    with st.sidebar:
        st.markdown("**TokenShield**")
        st.caption("v0.1.0 — LLM Cost Optimizer")
        hours = st.selectbox("Period", [24, 168, 720],
                             format_func=lambda h: {24: "24h", 168: "7 days", 720: "30 days"}[h])
        demo_mode = st.toggle("Demo Mode", value=True)

    if demo_mode:
        data = _generate_demo_data()
        mode_badge = '<span class="ts-badge badge-demo">Demo</span>'
    else:
        data = get_dashboard_data(hours=hours)
        mode_badge = '<span class="ts-badge badge-active">Active</span>'

    total_req = data["total_requests"]
    period_label = {24: "24h", 168: "7d", 720: "30d"}[hours]

    # ナビ
    st.markdown("""
    <div class="ts-nav">
        <div class="ts-nav-left">
            <div class="ts-nav-logo">TS</div>
            <span class="ts-nav-name">TokenShield</span>
        </div>
        <div class="ts-nav-right">
            <span class="ts-badge badge-period">{period}</span>
            {mode}
        </div>
    </div>
    """.format(period=period_label, mode=mode_badge), unsafe_allow_html=True)

    # ヒーロー
    st.markdown("""
    <div class="ts-hero">
        <div class="ts-hero-eyebrow">Total Savings</div>
        <div class="ts-hero-amount">${s:,.2f}</div>
        {delta}
    </div>
    """.format(
        s=data["total_savings"],
        delta='<span class="ts-hero-delta">{:.0f}% cost reduction</span>'.format(data["savings_pct"]) if data["savings_pct"] > 0 else "",
    ), unsafe_allow_html=True)

    if total_req == 0:
        st.info("Send requests through TokenShield to start tracking savings.")
        return

    # ルーティングバー
    c_pct = data["cache_hits"] / total_req * 100
    d_pct = data["deepseek_routes"] / total_req * 100
    o_pct = data["original_kept"] / total_req * 100

    # ルーティングバー（直接ラベル: 凡例分離より認知負荷低い — Few原則）
    cache_label = "Cache {:.0f}%".format(c_pct) if c_pct >= 5 else ""
    ds_label = "DeepSeek {:.0f}%".format(d_pct) if d_pct >= 5 else ""
    orig_label = "Original {:.0f}%".format(o_pct) if o_pct >= 5 else ""

    st.markdown("""
    <div class="ts-routing-bar">
        <div class="ts-rb-seg rb-cache" style="width:{c}%">{cl}</div>
        <div class="ts-rb-seg rb-ds" style="width:{d}%">{dl}</div>
        <div class="ts-rb-seg rb-orig" style="width:{o}%">{ol}</div>
    </div>
    """.format(c=c_pct, d=d_pct, o=o_pct, cl=cache_label, dl=ds_label, ol=orig_label),
    unsafe_allow_html=True)

    # KPIカード
    st.markdown("""
    <div class="ts-kpi-grid">
        <div class="ts-kpi">
            <div class="ts-kpi-label">Requests</div>
            <div class="ts-kpi-row">
                <span class="ts-kpi-val">{reqs:,}</span>
                <span class="ts-kpi-change change-neutral">total</span>
            </div>
        </div>
        <div class="ts-kpi">
            <div class="ts-kpi-label">Original Cost</div>
            <div class="ts-kpi-row">
                <span class="ts-kpi-val">${orig:,.2f}</span>
            </div>
        </div>
        <div class="ts-kpi">
            <div class="ts-kpi-label">Actual Cost</div>
            <div class="ts-kpi-row">
                <span class="ts-kpi-val">${actual:,.2f}</span>
                <span class="ts-kpi-change change-up">-{pct:.0f}%</span>
            </div>
        </div>
        <div class="ts-kpi">
            <div class="ts-kpi-label">Cache Hit Rate</div>
            <div class="ts-kpi-row">
                <span class="ts-kpi-val">{cache:.1f}%</span>
            </div>
        </div>
    </div>
    """.format(reqs=total_req, orig=data["total_original_cost"],
               actual=data["total_actual_cost"], pct=data["savings_pct"],
               cache=c_pct), unsafe_allow_html=True)

    # 時系列グラフ（Plotly）
    daily = data.get("daily", {})
    if daily and len(daily) >= 2:
        st.markdown('<div class="ts-section-label">Daily Savings Trend</div>', unsafe_allow_html=True)

        import plotly.graph_objects as go

        days_list = list(daily.keys())
        savings_vals = [daily[d]["savings"] for d in days_list]
        orig_vals = [daily[d]["original_cost"] for d in days_list]
        actual_vals = [daily[d]["actual_cost"] for d in days_list]

        fig = go.Figure()

        # 元コスト（ライトグレーの棒）
        fig.add_trace(go.Bar(
            x=days_list, y=orig_vals,
            name="Original",
            marker=dict(color="#D1D5DB"),
        ))

        # 実コスト（ダークネイビーの棒・横並び）
        fig.add_trace(go.Bar(
            x=days_list, y=actual_vals,
            name="Actual",
            marker=dict(color="#1E293B"),
        ))

        # 節約額（ティールの線・エリアなし）
        fig.add_trace(go.Scatter(
            x=days_list, y=savings_vals,
            name="Savings",
            line=dict(color="#0D9488", width=2.5),
            mode="lines+markers",
            marker=dict(size=4, color="#0D9488"),
            yaxis="y2",
        ))

        fig.update_layout(
            height=300,
            margin=dict(l=0, r=40, t=10, b=0),
            paper_bgcolor="white",
            plot_bgcolor="white",
            font=dict(family="Inter, sans-serif", size=12, color="#999"),
            barmode="group",
            bargap=0.3,
            bargroupgap=0.05,
            legend=dict(
                orientation="h",
                yanchor="bottom", y=1.02,
                xanchor="center", x=0.5,
                font=dict(size=11, color="#888"),
                bgcolor="rgba(0,0,0,0)",
            ),
            xaxis=dict(
                showgrid=False,
                showline=False,
                tickfont=dict(size=11, color="#bbb"),
            ),
            yaxis=dict(
                showgrid=True,
                gridcolor="#f5f5f5",
                gridwidth=1,
                showline=False,
                tickfont=dict(size=11, color="#bbb"),
                tickprefix="$",
                title=None,
            ),
            yaxis2=dict(
                showgrid=False,
                showline=False,
                tickfont=dict(size=11, color="#0D9488"),
                tickprefix="$",
                overlaying="y",
                side="right",
                title=None,
            ),
            hovermode="x unified",
            hoverlabel=dict(
                bgcolor="white",
                bordercolor="#eee",
                font=dict(size=12, color="#333"),
            ),
        )

        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    # 2カラム: ビフォーアフター比較 & モデル別
    left, right = st.columns(2)

    with left:
        st.markdown('<div class="ts-section-label">Cost Comparison</div>', unsafe_allow_html=True)
        orig_val = data["total_original_cost"]
        actual_val = data["total_actual_cost"]
        saved_val = data["total_savings"]
        max_val = max(orig_val, 0.01)

        st.markdown("""
        <div class="ts-compare">
            <div class="ts-compare-row">
                <div class="ts-compare-header">
                    <span class="ts-compare-name">Without optimization</span>
                    <span class="ts-compare-val">${orig:.2f}</span>
                </div>
                <div class="ts-compare-bar">
                    <div class="ts-compare-fill fill-orig" style="width:100%"></div>
                </div>
            </div>
            <div class="ts-compare-row">
                <div class="ts-compare-header">
                    <span class="ts-compare-name">With TokenShield</span>
                    <span class="ts-compare-val">${actual:.2f}</span>
                </div>
                <div class="ts-compare-bar">
                    <div class="ts-compare-fill fill-actual" style="width:{actual_pct}%"></div>
                </div>
            </div>
            <hr class="ts-compare-divider">
            <div class="ts-compare-total">
                <span class="ts-compare-total-label">You saved</span>
                <span class="ts-compare-total-val">${saved:.2f}</span>
            </div>
        </div>
        """.format(orig=orig_val, actual=actual_val, actual_pct=actual_val / max_val * 100, saved=saved_val),
        unsafe_allow_html=True)

    with right:
        st.markdown('<div class="ts-section-label">Model Usage</div>', unsafe_allow_html=True)

        model_info = {
            "deepseek-chat": ("DS", "DeepSeek V3", "mi-ds"),
            "claude-sonnet-4-6": ("CL", "Claude Sonnet", "mi-cl"),
            "claude-haiku-4-5-20251001": ("HA", "Claude Haiku", "mi-cl"),
            "cache": ("CA", "Cache Hit", "mi-ca"),
            "gpt-4o": ("GP", "GPT-4o", "mi-ds"),
        }

        items = ""
        for key, stats in sorted(data["model_stats"].items(), key=lambda x: -x[1]["count"]):
            ab, name, ic = model_info.get(key, ("??", key, "mi-ds"))
            pct = stats["count"] / total_req * 100
            items += """
            <div class="ts-model-item">
                <div class="ts-model-left">
                    <div class="ts-model-icon {ic}">{ab}</div>
                    <div>
                        <div class="ts-model-name">{name}</div>
                        <div class="ts-model-pct">{pct:.0f}% of requests</div>
                    </div>
                </div>
                <div class="ts-model-right">
                    <div class="ts-model-count">{count:,}</div>
                    <div class="ts-model-cost">${cost:.2f}</div>
                </div>
            </div>
            """.format(ic=ic, ab=ab, name=name, pct=pct, count=stats["count"], cost=stats["cost"])

        st.markdown('<div class="ts-model-card">{}</div>'.format(items), unsafe_allow_html=True)

    # インサイト
    if d_pct > 40:
        insight = '<span class="ts-insight-bold">{:.0f}%</span> of requests routed to DeepSeek V3 with equivalent quality, saving <span class="ts-insight-bold">${:.2f}</span>.'.format(d_pct, saved_val)
    elif c_pct > 15:
        insight = '<span class="ts-insight-bold">{:.0f}%</span> cache hit rate. Repeated queries served instantly at zero cost.'.format(c_pct)
    else:
        insight = 'TokenShield is actively optimizing your LLM costs. More data will unlock deeper insights.'

    st.markdown("""
    <div class="ts-insight">
        <span class="ts-insight-icon">💡</span>
        <span class="ts-insight-text">{}</span>
    </div>
    """.format(insight), unsafe_allow_html=True)

    # 予測
    st.markdown("""
    <div class="ts-forecast-grid">
        <div class="ts-fc">
            <div class="ts-fc-label">Monthly Projection</div>
            <div class="ts-fc-val">${m:,.2f}</div>
            <div class="ts-fc-sub">¥{mj:,.0f}</div>
        </div>
        <div class="ts-fc">
            <div class="ts-fc-label">Annual Projection</div>
            <div class="ts-fc-val">${y:,.2f}</div>
            <div class="ts-fc-sub">¥{yj:,.0f}</div>
        </div>
    </div>
    """.format(
        m=data["monthly_projection_usd"], mj=data["monthly_projection_jpy"],
        y=data["yearly_projection_usd"], yj=data["yearly_projection_jpy"],
    ), unsafe_allow_html=True)


if __name__ == "__main__":
    main()
