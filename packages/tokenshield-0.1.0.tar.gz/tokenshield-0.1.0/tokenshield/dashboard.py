"""
TokenShield コスト節約ダッシュボード

CLIおよびStreamlit Webダッシュボードで節約額を可視化する。

Usage:
    python -m tokenshield.dashboard          # CLIダッシュボード表示
    python -m tokenshield.dashboard --web    # Streamlit Webダッシュボード起動
    python -m tokenshield.dashboard --json   # JSON出力
    python -m tokenshield.dashboard --hours 168  # 直近7日間
"""

import argparse
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

# 料金データ（$/1M tokens）
PRICING = {
    "claude-sonnet-4-6": {"input": 3.00, "output": 15.00},
    "claude-haiku-4-5-20251001": {"input": 0.80, "output": 4.00},
    "gpt-4o": {"input": 2.50, "output": 10.00},
    "gpt-4o-mini": {"input": 0.15, "output": 0.60},
    "deepseek-chat": {"input": 0.28, "output": 1.10},
}

# 為替レート（概算）
USD_TO_JPY = 150.0

DEFAULT_USAGE_FILE = os.path.expanduser("~/.tokenshield/usage.jsonl")


def _load_records(
    filepath: str = DEFAULT_USAGE_FILE,
    hours: int = 24,
) -> List[Dict[str, Any]]:
    """usage.jsonl から指定時間内のレコードを読み込む。"""
    if not os.path.exists(filepath):
        return []

    cutoff = datetime.now(timezone.utc) - timedelta(hours=hours)
    records = []  # type: List[Dict[str, Any]]

    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue

            ts_str = record.get("timestamp", "")
            try:
                ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
            except (ValueError, AttributeError):
                continue

            if ts >= cutoff:
                records.append(record)

    return records


def get_dashboard_data(hours: int = 24) -> Dict[str, Any]:
    """ダッシュボードデータをdictで返す。"""
    records = _load_records(hours=hours)

    total_original_cost = 0.0
    total_actual_cost = 0.0
    total_savings = 0.0
    cache_hits = 0
    deepseek_routes = 0
    original_kept = 0

    # モデル別集計
    model_stats = defaultdict(lambda: {"count": 0, "cost": 0.0})  # type: Dict[str, Dict[str, Any]]

    # 日別集計
    daily_savings = defaultdict(float)  # type: Dict[str, float]
    daily_cost_original = defaultdict(float)  # type: Dict[str, float]
    daily_cost_actual = defaultdict(float)  # type: Dict[str, float]

    for r in records:
        orig_cost = r.get("original_cost", 0.0)
        act_cost = r.get("actual_cost", 0.0)
        saving = r.get("savings", orig_cost - act_cost)

        total_original_cost += orig_cost
        total_actual_cost += act_cost
        total_savings += saving

        # リクエスト種別
        if r.get("cache_hit", False):
            cache_hits += 1
            model_label = "cache"
        elif r.get("actual_model", "") == "deepseek-chat":
            deepseek_routes += 1
            model_label = r.get("actual_model", "unknown")
        else:
            original_kept += 1
            model_label = r.get("actual_model", r.get("original_model", "unknown"))

        model_stats[model_label]["count"] += 1
        model_stats[model_label]["cost"] += act_cost

        # 日別
        ts_str = r.get("timestamp", "")
        try:
            ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
            day_key = ts.strftime("%m/%d")
        except (ValueError, AttributeError):
            day_key = "unknown"

        daily_savings[day_key] += saving
        daily_cost_original[day_key] += orig_cost
        daily_cost_actual[day_key] += act_cost

    total_requests = len(records)
    savings_pct = (total_savings / total_original_cost * 100) if total_original_cost > 0 else 0.0

    # 月間・年間予測
    if hours > 0 and total_savings > 0:
        hours_in_month = 24 * 30
        hours_in_year = 24 * 365
        monthly_projection = total_savings * (hours_in_month / hours)
        yearly_projection = total_savings * (hours_in_year / hours)
    else:
        monthly_projection = 0.0
        yearly_projection = 0.0

    return {
        "period_hours": hours,
        "total_requests": total_requests,
        "total_original_cost": total_original_cost,
        "total_actual_cost": total_actual_cost,
        "total_savings": total_savings,
        "savings_pct": savings_pct,
        "cache_hits": cache_hits,
        "deepseek_routes": deepseek_routes,
        "original_kept": original_kept,
        "model_stats": dict(model_stats),
        "daily_savings": dict(daily_savings),
        "daily_cost_original": dict(daily_cost_original),
        "daily_cost_actual": dict(daily_cost_actual),
        "monthly_projection_usd": monthly_projection,
        "yearly_projection_usd": yearly_projection,
        "monthly_projection_jpy": monthly_projection * USD_TO_JPY,
        "yearly_projection_jpy": yearly_projection * USD_TO_JPY,
    }


def _bar(value: float, max_value: float, width: int = 30) -> str:
    """簡易バーチャート文字列を生成。"""
    if max_value <= 0:
        return ""
    filled = int(value / max_value * width)
    filled = min(filled, width)
    return "\u2588" * filled


def _fmt_pct(count: int, total: int) -> str:
    """パーセント文字列を返す。"""
    if total <= 0:
        return "0.0%"
    return "{:.1f}%".format(count / total * 100)


def show_cli_dashboard(hours: int = 24) -> None:
    """CLIダッシュボードを表示する。"""
    data = get_dashboard_data(hours=hours)

    total_req = data["total_requests"]

    # ヘッダー
    print()
    print("\u2554" + "\u2550" * 46 + "\u2557")
    print("\u2551" + "TokenShield  節約レポート".center(38) + "\u2551")
    print("\u255a" + "\u2550" * 46 + "\u255d")
    print()

    # 期間
    if hours <= 24:
        period_label = "直近{}時間".format(hours)
    else:
        period_label = "直近{}日間".format(hours // 24)
    print("  期間: {}".format(period_label))

    if total_req == 0:
        print()
        print("  データがありません。")
        print("  usage.jsonl にレコードが記録されると、ここに表示されます。")
        print()
        return

    # 節約サマリー
    print()
    print("  -- 節約サマリー --")
    print("  最適化なしのコスト:  ${:.2f}".format(data["total_original_cost"]))
    print("  実際のコスト:        ${:.2f}".format(data["total_actual_cost"]))
    print("  節約額:             ${:.2f} ({:.1f}%)".format(
        data["total_savings"], data["savings_pct"]
    ))

    # リクエスト統計
    print()
    print("  -- リクエスト統計 --")
    print("  総リクエスト数:      {:,}".format(total_req))
    print("  キャッシュヒット:    {:,} ({})".format(
        data["cache_hits"], _fmt_pct(data["cache_hits"], total_req)
    ))
    print("  DeepSeekルーティング: {:,} ({})".format(
        data["deepseek_routes"], _fmt_pct(data["deepseek_routes"], total_req)
    ))
    print("  元モデル維持:        {:,} ({})".format(
        data["original_kept"], _fmt_pct(data["original_kept"], total_req)
    ))

    # モデル別
    print()
    print("  -- モデル別 --")
    model_display = {
        "cache": "キャッシュ",
        "deepseek-chat": "DeepSeek V3",
        "claude-sonnet-4-6": "Claude Sonnet",
        "claude-haiku-4-5-20251001": "Claude Haiku",
        "gpt-4o": "GPT-4o",
        "gpt-4o-mini": "GPT-4o mini",
    }
    for model_key, stats in sorted(
        data["model_stats"].items(), key=lambda x: -x[1]["count"]
    ):
        label = model_display.get(model_key, model_key)
        print("  {:<16s} {:>4}回  ${:.2f}".format(
            label, stats["count"], stats["cost"]
        ))

    # 日別推移
    print()
    print("  -- 日別推移（直近7日） --")
    today = datetime.now(timezone.utc)
    max_saving = max(data["daily_savings"].values()) if data["daily_savings"] else 0.0

    for i in range(6, -1, -1):
        day = today - timedelta(days=i)
        day_key = day.strftime("%m/%d")
        saving = data["daily_savings"].get(day_key, 0.0)
        bar = _bar(saving, max_saving)
        print("  {}  ${:<6.2f} {}".format(day_key, saving, bar))

    # コスト削減予測
    print()
    print("  -- コスト削減予測 --")
    print("  月間予測節約額: ${:,.2f} (¥{:,.0f})".format(
        data["monthly_projection_usd"], data["monthly_projection_jpy"]
    ))
    print("  年間予測節約額: ${:,.2f} (¥{:,.0f})".format(
        data["yearly_projection_usd"], data["yearly_projection_jpy"]
    ))
    print()


def show_web_dashboard() -> None:
    """Streamlitダッシュボードを起動する。"""
    dashboard_web_path = os.path.join(
        os.path.dirname(__file__), "dashboard_web.py"
    )
    if not os.path.exists(dashboard_web_path):
        print("エラー: dashboard_web.py が見つかりません。")
        sys.exit(1)

    try:
        import streamlit.web.cli as stcli
    except ImportError:
        print("エラー: Streamlit がインストールされていません。")
        print("  pip install streamlit")
        sys.exit(1)

    sys.argv = ["streamlit", "run", dashboard_web_path]
    stcli.main()


def main() -> None:
    parser = argparse.ArgumentParser(
        description="TokenShield コスト節約ダッシュボード"
    )
    parser.add_argument(
        "--web", action="store_true",
        help="Streamlit Webダッシュボードを起動"
    )
    parser.add_argument(
        "--json", action="store_true", dest="json_output",
        help="JSON形式で出力"
    )
    parser.add_argument(
        "--hours", type=int, default=24,
        help="集計対象の時間数（デフォルト: 24）"
    )
    args = parser.parse_args()

    if args.web:
        show_web_dashboard()
    elif args.json_output:
        data = get_dashboard_data(hours=args.hours)
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        show_cli_dashboard(hours=args.hours)


if __name__ == "__main__":
    main()
