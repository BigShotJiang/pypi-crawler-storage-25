[![Documentation](https://img.shields.io/badge/docs-live-brightgreen)](https://www.thomaspeoples.com/gitea-repos/wraith-cli/)
![PyPI - Version](https://img.shields.io/pypi/v/wraith-cli)
![PyPI - License](https://img.shields.io/pypi/l/wraith-cli)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/wraith-cli)


# 👻 Wraith-CLI
### *Sovereign Orchestration for the Ghost Stack*

**Wraith-CLI** is the nervous system of the Ghost Stack. It bridges the gap between high-level containers and bare-metal reality.

---

## 🚀 Installation

**Wraith-CLI** can be installed via `uv` (recommended) or `pip`:

```bash
# Recommended for CLI tools
uv tool install wraith-cli

# Standard pip
pip install wraith-cli
```

> **Note:** Ensure ~/.local/bin is in your $PATH.

---

## 🛠️ Operational Manual

| Command | Description |
| :--- | :--- |
| wraith ps | Shows all Docker processes in a neat table |
| wraith status | Heartbeat check for OpenViking (Port 1933). |
| wraith runner-reset | Wipes and re-registers the Gitea Action Runner. |
| wraith --help | View the full manifest of available commands. |

---

## 🏗️ Developer Workspace

We use uv for hermetic environment management.

```bash
### 1. Initialise the Environment
uv sync --all-extras
uv run pre-commit install

### 2. The Quality Gate
uv run pytest

### 3. Sovereign Deployment
chmod +x bin/build.sh
./bin/build.sh
```

---

## 🔐 Environment Configuration

Defined in `~/.bashrc` or `.env.private`:

| Variable | Purpose | Default |
| :--- | :--- | :--- |
| VIKING_BASE_URL | The API endpoint for the heartbeat check. | http://127.0.0.1:1933/api/v1 |
| GITEA_COMPOSE_PATH | Path to your Gitea Docker Compose directory. | Required for runner-reset |

---

## 📜 Sovereign Principles
1. **Distributed Sovereignty:** Available on PyPI for the world, but optimised for local-first, private-registry mirrors
2. **Atomic Execution:** Use uv run to ensure consistency.
3. **Hardware First:** Prioritise bare-metal health and container stability.
