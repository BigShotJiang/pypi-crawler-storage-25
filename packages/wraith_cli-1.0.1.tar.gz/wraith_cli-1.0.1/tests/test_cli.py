from unittest.mock import patch

from typer.testing import CliRunner

from wraith_cli.main import app

runner = CliRunner()

# --- 1. Status Command Tests ---


def test_status_online(monkeypatch):
    """Test status when OpenViking is 200 OK."""
    with patch("requests.get") as mock_get:
        mock_get.return_value.status_code = 200
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "🟢 OpenViking: Online" in result.stdout


def test_status_offline():
    """Test status when OpenViking connection fails."""
    with patch("requests.get") as mock_get:
        mock_get.side_effect = Exception("Connection Refused")
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "🔴 OpenViking: Offline" in result.stdout


# --- 2. PS Command Tests ---


@patch("subprocess.run")
def test_ps_standard(mock_run):
    """Test the standard ps output format."""
    result = runner.invoke(app, ["ps"])
    assert result.exit_code == 0

    # Get the actual list of arguments passed to subprocess.run
    args = mock_run.call_args[0][0]

    # Join them into one string so we can check for substrings
    full_command = " ".join(args)

    assert "docker" in full_command
    assert "{{.Ports}}" in full_command


@patch("subprocess.run")
def test_ps_simple(mock_run):
    """Test the simple/project ps output format."""
    result = runner.invoke(app, ["ps", "--simple"])
    assert result.exit_code == 0

    args = mock_run.call_args[0][0]
    full_command = " ".join(args)

    assert "com.docker.compose.project" in full_command


# --- 3. Runner Reset Tests ---


def test_runner_reset_no_env(monkeypatch):
    """Test safety check when env var is missing."""
    # We patch the global GITEA_PATH in the module
    with patch("wraith_cli.main.GITEA_PATH", None):
        result = runner.invoke(app, ["runner-reset"])
        assert result.exit_code == 1
        assert "GITEA_COMPOSE_PATH not set" in result.stdout


@patch("wraith_cli.main.Path.exists")
def test_runner_reset_no_compose(mock_exists):
    """Test failure when directory exists but docker-compose.yml doesn't."""
    with patch("wraith_cli.main.GITEA_PATH", "/tmp/fake-path"):
        # First check (docker_file.exists) returns False
        mock_exists.return_value = False
        result = runner.invoke(app, ["runner-reset"])
        assert result.exit_code == 1
        assert "❌ Compose file not found" in result.stdout


@patch("subprocess.run")
@patch("wraith_cli.main.Path.exists")
def test_runner_reset_success(mock_exists, mock_run):
    """Test full successful reset flow."""
    with patch("wraith_cli.main.GITEA_PATH", "/tmp/fake-path"):
        # Mocking Path.exists to return True for both the yaml and .runner file
        mock_exists.return_value = True

        result = runner.invoke(app, ["runner-reset"])

        assert result.exit_code == 0
        assert "🚀 Restarting Runner..." in result.stdout
        # Verify subprocess was called for stop, rm, and up
        assert mock_run.call_count >= 2
