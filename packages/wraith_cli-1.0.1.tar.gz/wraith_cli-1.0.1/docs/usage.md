# Usage Guide

Wraith CLI is designed to be intuitive and fast. Here is how to get started. Make a coffee, grab a Hob-Nob, and put down your glass rectangle block, it's time to put attention!

## Basic Commands

### Help
To see all available commands and options:
```bash
wraith-cli --help
```

### Initialising a Project
To start a new "Wraith" project in the current directory:

```bash
wraith-cli init my-new-project
```

### Configuration
Wraith CLI looks for a wraith.toml or .wraith.yaml in your root directory.

| Option | Description | Default |
| --- | --- | --- |
| verbose | Enables detailed logging | false |
| remote | The Gitea URL for syncing | localhost |
