# Technical Reference

## Architecture
Wraith CLI is built using **Python 3.12+** and leverages `typer` for the interface and `rich` for terminal formatting. Like a Rolls Royce Wraith, she be smooth.

## API Logic
The core logic resides in the `src/wraith_cli/core.py` module.

### Error Codes
| Code | Meaning | Resolution |
| :--- | :--- | :--- |
| `1` | General Error | Check your `app.ini` connection. |
| `128` | Git Auth Error | Verify your `GITEATOKEN` environment variable. |

## Test Suite
We maintain a strict testing policy. All pull requests must maintain our current coverage.
- **Current Coverage:** ![Coverage](coverage.svg)
- **Engine:** Pytest + Coverage.py
