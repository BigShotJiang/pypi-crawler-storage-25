# Wraith CLI

![Coverage](coverage.svg)
![Version](https://img.shields.io/badge/version-1.0.1-blue)

---

--8<-- "README.md"
