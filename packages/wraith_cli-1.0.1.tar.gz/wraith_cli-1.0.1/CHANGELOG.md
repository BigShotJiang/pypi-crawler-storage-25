## v0.15.0 (2026-03-31)

## v0.14.0 (2026-03-31)

## v0.13.0 (2026-03-31)

## v0.12.0 (2026-03-31)
* 👻 **feature/TJP-20002:** Changed name from ghost-cli to wraith-cli (fd2cb84)

## v0.11.0 (2026-03-31)
* 👻 **chore:** release v0.10.0 -> v0.11.0 [skip ci] (b79bcbd)
* 🎉 **feature/TJP-20002:** Changes to www serve location (80fe628)

## v0.10.0 (2026-03-31)
* 👻 **chore:** release v0.9.0 -> v0.10.0 [skip ci] (d628b95)
* 📚 **feature/TJP-10001:** Added mkdocs and pages for docs (c639fa8)

## v0.9.0 (2026-03-31)
* 👻 **chore:** release v0.8.0 -> v0.9.0 [skip ci] (8529ed5)
* 📚 **feature/TJP-10001:** Added mkdocs and pages for docs (da6b1d8)

## v0.8.0 (2026-03-31)
* 👻 **chore:** release v0.7.0 -> v0.8.0 [skip ci] (526eb86)
* 📚 **feature/TJP-10001:** Added mkdocs and pages for docs (ada6802)

## v0.7.0 (2026-03-31)
* 👻 **chore:** release v0.6.0 -> v0.7.0 [skip ci] (5441a53)
* 📚 **feature/TJP-10001:** Added mkdocs and pages for docs (783254d)

## v0.6.0 (2026-03-31)
* 👻 **chore:** release v0.5.0 -> v0.6.0 [skip ci] (c31ca55)
* 📚 **feature/TJP-10001:** Added mkdocs and pages for docs (a1ad4f2)

## v0.5.0 (2026-03-31)
* 👻 **chore:** release v0.4.0 -> v0.5.0 [skip ci] (a174f9c)
* 📚 **feature/TJP-10001:** Added mkdocs and pages for docs (a2ea788)

## v0.4.0 (2026-03-31)
* 👻 **chore:** release v0.3.0 -> v0.4.0 [skip ci] (480d3c4)
* 🎉 **feature/TJP-10001:** Improvements and a poor commit message (d415400)

## v0.3.0 (2026-03-30)
* 👻 **chore:** release v0.2.0 -> v0.3.0 [skip ci] (ea0ef47)
* 🎉 **feature/TJP-10001:** Skipping PRs (d076eeb)

## v0.2.0 (2026-03-30)
* 👻 **chore:** release v0.1.2 -> v0.2.0 [skip ci] (c135463)
* 🎉 **feature/TJP-10001:** Updated docs (03089ca)
* 🎉 **feature/TJP-10001:** Updated docs (56c076c)
* 🎉 **feature/TJP-10001:** Added a custom CLI (c43513b)
* ⚡ **chore:** Everytbing is a chore (ff91d9e)
* Initial commit (10dccaa)
