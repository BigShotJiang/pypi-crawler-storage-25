import os
import subprocess
from pathlib import Path

import requests
import typer
from dotenv import load_dotenv

load_dotenv()

app = typer.Typer(help="Wraith Sovereign CLI", rich_markup_mode="rich")

# --- Sanitised Configuration ---
VIKING_URL = os.getenv("VIKING_BASE_URL", "http://127.0.0.1:1933/api/v1")
VIKING_URL = VIKING_URL.rstrip("/")
GITEA_PATH = os.getenv("GITEA_COMPOSE_PATH")


@app.command()
def status():
    """Check the heartbeat of the OpenViking Stack."""
    url = f"{VIKING_URL}/health"
    try:
        response = requests.get(url, timeout=3)
        if response.status_code == 200:
            typer.secho("🟢 OpenViking: Online", fg=typer.colors.GREEN)
        else:
            typer.secho(
                f"🟡 OpenViking: Warning ({response.status_code})",
                fg=typer.colors.YELLOW,
            )
    except Exception:
        # Reverted to match your test expectations: " OpenViking: Offline"
        typer.secho("🔴 OpenViking: Offline", fg=typer.colors.RED)


@app.command()
def ps(
    simple: bool = typer.Option(False, "--simple", "-s"),
    all: bool = typer.Option(False, "--all", "-a"),
):
    """View Docker process list."""
    cmd = ["docker", "ps"]
    if all:
        cmd.append("-a")

    if simple:
        # Multi-line string to satisfy Ruff E501
        fmt = (
            "table {{.Names}}\t{{.Status}}\t"
            '{{.Label "com.docker.compose.project"}}'
        )
    else:
        fmt = "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}"

    cmd.extend(["--format", fmt])
    subprocess.run(cmd)


@app.command()
def runner_reset():
    """Resets the Gitea Action Runner."""
    if not GITEA_PATH:
        msg = "❌ Error: GITEA_COMPOSE_PATH not set in .env"
        typer.secho(msg, fg=typer.colors.RED)
        raise typer.Exit(1)

    compose_path = Path(GITEA_PATH)
    docker_file = compose_path / "docker-compose.yml"
    runner_data = compose_path / "data/act_runner/.runner"

    if not docker_file.exists():
        typer.secho(f"❌ Compose file not found at: {docker_file}", fg="red")
        raise typer.Exit(1)

    typer.echo("👻 Wraith-CLI: Killing Gitea Runner...")
    subprocess.run(["docker", "compose", "-f", str(docker_file), "stop"])

    if runner_data.exists():
        typer.echo(f"🧹 Wiping registration: {runner_data}")
        subprocess.run(["sudo", "rm", "-f", str(runner_data)])

    typer.echo("🚀 Restarting Runner...")
    subprocess.run(["docker", "compose", "-f", str(docker_file), "up", "-d"])
    typer.secho("✅ Runner state reset.", fg=typer.colors.GREEN, bold=True)


if __name__ == "__main__":
    app()
