# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: jsonrpc.py — odoom/clients/jsonrpc.py

from __future__ import annotations

import itertools
from typing import Any

import requests


class OdooJsonRpcClient:
    _ids = itertools.count(1)

    def __init__(
        self, url: str, db: str, username: str, password: str, timeout: float = 60.0
    ):
        self.url = url.rstrip("/")
        self.db = db
        self.username = username
        self.password = password
        self.timeout = timeout
        self.session = requests.Session()
        self.uid = self._authenticate()

    def _call(self, service: str, method: str, *args: Any) -> Any:
        payload = {
            "jsonrpc": "2.0",
            "method": "call",
            "params": {
                "service": service,
                "method": method,
                "args": list(args),
            },
            "id": next(self._ids),
        }
        response = self.session.post(
            f"{self.url}/jsonrpc", json=payload, timeout=self.timeout
        )
        response.raise_for_status()
        body = response.json()
        if body.get("error"):
            data = body["error"].get("data") or {}
            message = (
                data.get("message")
                or body["error"].get("message")
                or "Odoo JSON-RPC error"
            )
            raise RuntimeError(message)
        return body.get("result")

    def _authenticate(self) -> int:
        uid = self._call(
            "common", "authenticate", self.db, self.username, self.password, {}
        )
        if not uid:
            raise RuntimeError("Odoo authentication failed")
        return int(uid)

    def execute_kw(self, model: str, method: str, *args: Any, **kwargs: Any) -> Any:
        return self._call(
            "object",
            "execute_kw",
            self.db,
            self.uid,
            self.password,
            model,
            method,
            list(args),
            kwargs or {},
        )

    def execute(self, model: str, method: str, *args: Any) -> Any:
        return self._call(
            "object",
            "execute",
            self.db,
            self.uid,
            self.password,
            model,
            method,
            *args,
        )
