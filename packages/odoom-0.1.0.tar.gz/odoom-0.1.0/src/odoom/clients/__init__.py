# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: __init__.py — odoom/clients/__init__.py

from .jsonrpc import OdooJsonRpcClient
from .xmlrpc import OdooXmlRpcClient

__all__ = ["OdooXmlRpcClient", "OdooJsonRpcClient"]
