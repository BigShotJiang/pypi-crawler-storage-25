# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: xmlrpc.py — odoom/clients/xmlrpc.py

from __future__ import annotations

import xmlrpc.client
from typing import Any


class OdooXmlRpcClient:
    def __init__(self, url: str, db: str, username: str, password: str):
        self.url = url.rstrip("/")
        self.db = db
        self.username = username
        self.password = password

        common = xmlrpc.client.ServerProxy(f"{self.url}/xmlrpc/2/common")
        self.uid = common.authenticate(self.db, self.username, self.password, {})
        if not self.uid:
            raise RuntimeError("Odoo authentication failed")

        self.models = xmlrpc.client.ServerProxy(f"{self.url}/xmlrpc/2/object")

    def execute_kw(self, model: str, method: str, *args: Any, **kwargs: Any) -> Any:
        return self.models.execute_kw(
            self.db,
            self.uid,
            self.password,
            model,
            method,
            list(args),
            kwargs or {},
        )

    def execute(self, model: str, method: str, *args: Any) -> Any:
        return self.models.execute(
            self.db,
            self.uid,
            self.password,
            model,
            method,
            *args,
        )
