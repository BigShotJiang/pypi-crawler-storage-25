# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: __init__.py — odoom/__init__.py

from .locust import OdooJsonRpcUser, OdooXmlRpcUser, sequential_task

__all__ = ["OdooXmlRpcUser", "OdooJsonRpcUser", "sequential_task"]
