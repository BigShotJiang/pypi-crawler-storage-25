# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: sequence.py — odoom/locust/sequence.py

from __future__ import annotations

from collections.abc import Callable


def sequential_task(order: int) -> Callable:
    def decorator(func: Callable) -> Callable:
        setattr(func, "_odoom_task_order", order)
        return func

    return decorator


def ordered_tasks_for(user: object) -> list[Callable[[], object]]:
    tasks: list[tuple[int, str, Callable[[], object]]] = []
    for name in dir(user):
        attr = getattr(user, name)
        if callable(attr) and hasattr(attr, "_odoom_task_order"):
            tasks.append((getattr(attr, "_odoom_task_order"), name, attr))
    tasks.sort(key=lambda item: (item[0], item[1]))
    return [task for _, _, task in tasks]
