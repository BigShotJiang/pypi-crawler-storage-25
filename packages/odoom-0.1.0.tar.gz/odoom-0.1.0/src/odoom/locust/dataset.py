# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: dataset.py — odoom/locust/dataset.py

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class Dataset:
    path: Path

    @property
    def name(self) -> str:
        return self.path.name

    def file_for(self, task_name: str) -> Path:
        return self.path / f"{task_name}.json"

    def json_for(self, task_name: str) -> Any:
        file_path = self.file_for(task_name)
        if not file_path.exists():
            raise FileNotFoundError(f"Dataset file not found: {file_path}")
        with file_path.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def rows_for(self, task_name: str) -> list[list[Any]]:
        data = self.json_for(task_name)
        if not isinstance(data, list):
            raise TypeError(f"Expected list in {self.file_for(task_name)}")
        return data
