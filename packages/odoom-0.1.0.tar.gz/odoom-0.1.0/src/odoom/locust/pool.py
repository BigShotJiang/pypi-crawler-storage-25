# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: pool.py — odoom/locust/pool.py

from __future__ import annotations

import random
from pathlib import Path
from threading import Lock

from .dataset import Dataset


class DatasetPool:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self._lock = Lock()
        self._datasets = self._discover()

    def _discover(self) -> list[Dataset]:
        if not self.root.exists():
            raise RuntimeError(f"Dataset root not found: {self.root}")

        datasets: list[Dataset] = []
        for candidate in sorted(self.root.rglob("*")):
            if candidate.is_dir() and any(
                child.suffix == ".json"
                for child in candidate.iterdir()
                if child.is_file()
            ):
                datasets.append(Dataset(candidate))

        if not datasets:
            raise RuntimeError(f"No dataset directories found under: {self.root}")
        return datasets

    def acquire(self) -> Dataset:
        with self._lock:
            return random.choice(self._datasets)
