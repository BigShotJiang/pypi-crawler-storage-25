# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: users.py — odoom/locust/users.py

from __future__ import annotations

import time
from typing import Any

from locust import User, constant, events, task
from locust.exception import StopUser

from .config import OdooLocustConfig, load_config
from .pool import DatasetPool
from .sequence import ordered_tasks_for


class OdooSession:
    def __init__(self, client: Any, request_event: Any, dataset_name: str):
        self.client = client
        self.request_event = request_event
        self.dataset_name = dataset_name

    def _measure(self, name: str, func, response_length: int = 0):
        started = time.perf_counter()
        try:
            result = func()
        except Exception as exc:
            self.request_event.fire(
                request_type="odoo",
                name=name,
                response_time=(time.perf_counter() - started) * 1000.0,
                response_length=response_length,
                exception=exc,
                context={"dataset": self.dataset_name},
            )
            raise
        self.request_event.fire(
            request_type="odoo",
            name=name,
            response_time=(time.perf_counter() - started) * 1000.0,
            response_length=response_length,
            exception=None,
            context={"dataset": self.dataset_name},
        )
        return result

    def execute_kw(
        self,
        model: str,
        method: str,
        *args: Any,
        request_name: str | None = None,
        **kwargs: Any,
    ) -> Any:
        name = request_name or f"{model}.{method}"
        return self._measure(
            name, lambda: self.client.execute_kw(model, method, *args, **kwargs)
        )

    def execute(
        self, model: str, method: str, *args: Any, request_name: str | None = None
    ) -> Any:
        name = request_name or f"{model}.{method}"
        return self._measure(name, lambda: self.client.execute(model, method, *args))

    def load(
        self,
        model: str,
        fields: list[str],
        rows: list[list[Any]],
        request_name: str | None = None,
    ) -> Any:
        name = request_name or f"{model}.load"
        return self._measure(
            name,
            lambda: self.client.execute_kw(model, "load", fields, rows),
            response_length=len(rows),
        )


class OdooBaseUser(User):
    abstract = True
    wait_time = constant(0)
    dataset_root: str | None = None
    config: OdooLocustConfig
    dataset: Any
    odoo: OdooSession
    loop: str = False
    _task_sequence: list[Any]
    _task_index: int

    def on_start(self):
        if not hasattr(self.environment, "odoom_config"):
            self.environment.odoom_config = load_config(
                self.environment, self.dataset_root
            )
        if not hasattr(self.environment, "odoom_dataset_pool"):
            self.environment.odoom_dataset_pool = DatasetPool(
                self.environment.odoom_config.dataset_root
            )

        self.config = self.environment.odoom_config
        self.dataset = self.environment.odoom_dataset_pool.acquire()
        client = self.build_client(self.config)
        self.odoo = OdooSession(
            client, self.environment.events.request, self.dataset.name
        )
        self._task_sequence = ordered_tasks_for(self)
        self._task_index = 0

        if not self._task_sequence:
            raise RuntimeError(
                f"No sequential tasks found on {self.__class__.__name__}"
            )

    def build_client(self, config: OdooLocustConfig):
        raise NotImplementedError

    @task
    def run_next(self):
        if self._task_index >= len(self._task_sequence):
            if self.loop:
                self._task_index = 0  # loop instead of stop
            else:
                raise StopUser()
        current = self._task_sequence[self._task_index]
        self._task_index += 1
        current()


class OdooXmlRpcUser(OdooBaseUser):
    abstract = True

    def build_client(self, config: OdooLocustConfig):
        from ..clients.xmlrpc import OdooXmlRpcClient

        return OdooXmlRpcClient(
            url=config.url,
            db=config.db,
            username=config.username,
            password=config.password,
        )


class OdooJsonRpcUser(OdooBaseUser):
    abstract = True

    def build_client(self, config: OdooLocustConfig):
        from ..clients.jsonrpc import OdooJsonRpcClient

        return OdooJsonRpcClient(
            url=config.url,
            db=config.db,
            username=config.username,
            password=config.password,
            timeout=config.timeout,
        )


@events.init_command_line_parser.add_listener
def _(parser):
    parser.add_argument(
        "--odoo-url",
        type=str,
        env_var="LOCUST_ODOO_URL",
        default="",
        help="Odoo base URL",
        include_in_web_ui=True,
    )
    parser.add_argument(
        "--odoo-db",
        type=str,
        env_var="LOCUST_ODOO_DB",
        default="",
        help="Odoo database",
        include_in_web_ui=True,
    )
    parser.add_argument(
        "--odoo-username",
        type=str,
        env_var="LOCUST_ODOO_USERNAME",
        default="",
        help="Odoo username",
        include_in_web_ui=True,
    )
    parser.add_argument(
        "--odoo-password",
        type=str,
        env_var="LOCUST_ODOO_PASSWORD",
        default="",
        help="Odoo password",
        include_in_web_ui=True,
        is_secret=True,
    )
    parser.add_argument(
        "--odoo-dataset-root",
        type=str,
        env_var="LOCUST_ODOO_DATASET_ROOT",
        default="",
        help="Root directory that contains dataset folders",
        include_in_web_ui=True,
    )
    parser.add_argument(
        "--odoo-timeout",
        type=float,
        env_var="LOCUST_ODOO_TIMEOUT",
        default=60.0,
        help="JSON-RPC HTTP timeout in seconds",
        include_in_web_ui=False,
    )
