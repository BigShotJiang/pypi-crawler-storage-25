# Copyright 2026 Apik (https://apik.cloud).
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).
#
# File: __init__.py — odoom/locust/__init__.py

from .sequence import sequential_task
from .users import OdooJsonRpcUser, OdooXmlRpcUser

__all__ = ["OdooXmlRpcUser", "OdooJsonRpcUser", "sequential_task"]
