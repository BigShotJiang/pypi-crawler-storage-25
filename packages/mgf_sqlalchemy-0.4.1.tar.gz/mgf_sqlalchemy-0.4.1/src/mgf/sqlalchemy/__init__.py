"""``mgf.sqlalchemy`` — async SQLAlchemy helpers for mgf-common consumers.

Sibling of :mod:`mgf.common` under the ``mgf.*`` namespace. Houses the
async-engine factory + sessionmaker + tenant-RLS helper that previously
lived under ``mgf.common.db.*`` — extracted at mgf-common v0.30 /
mgf-sqlalchemy v0.1 per the federation split plan.

Every async-SQLAlchemy consumer needs the same three things:

  - An :class:`AsyncEngine` factory with sane defaults (pool sizing,
    ``pool_pre_ping``, ``pool_recycle``, ``echo`` from settings).
  - An :func:`async_sessionmaker` factory wired to that engine.
  - A per-request tenant-scoping context manager
    (``SET LOCAL app.current_tenant = '<uuid>'`` for Postgres RLS).

This sibling is **framework-agnostic**: no FastAPI, no Starlette, no
Django imports. The FastAPI-Depends-shaped ``get_session`` and the
``setup_db`` lifespan helper that previously lived under
``mgf.common.db`` were moved to the :mod:`mgf.fastapi.db` submodule
in mgf-fastapi v0.2.0 (which depends on mgf-sqlalchemy via the
``[sqlalchemy]`` extra). See ``mgf-sqlalchemy/docs/cutover/v0.1.0.md``
for the full migration map.

Install: ``pip install mgf-sqlalchemy`` (pulls
``sqlalchemy[asyncio]>=2.0``). For tests against an in-memory SQLite
database: ``pip install 'mgf-sqlalchemy[test]'`` (adds ``aiosqlite``).

The integration is **adapter-shaped, not framework-shaped**. Nothing
here re-exports SQLAlchemy primitives or hides them. The consumer's
ORM is still vanilla SQLAlchemy 2; these helpers plug into the seams
(engine factory, sessionmaker).

Closed-box invariant: ``mgf-sqlalchemy`` depends on ``mgf-common`` +
``sqlalchemy`` only. Consumers MUST import from ``mgf.sqlalchemy``,
never reach into ``mgf.sqlalchemy._engine`` / ``mgf.sqlalchemy._session``.
"""

from __future__ import annotations

from mgf.sqlalchemy._engine import create_engine, make_safe_url
from mgf.sqlalchemy._mixins import (
    AuditTrailMixin,
    SoftDeleteMixin,
    current_audit_user,
    set_audit_user,
    uuid7,
    uuid7_pk_column,
)
from mgf.sqlalchemy._session import create_sessionmaker, tenant_session

__all__ = [
    "AuditTrailMixin",
    "SoftDeleteMixin",
    "create_engine",
    "create_sessionmaker",
    "current_audit_user",
    "make_safe_url",
    "set_audit_user",
    "tenant_session",
    "uuid7",
    "uuid7_pk_column",
]
