# Engineering Standards

This folder is **NOT a duplicate** of `mgf-common/docs/standards/`.
The cross-project engineering standards live in `mgf-common`.
This project depends on those — pinned via
`mgf-common>=0.33,<0.34`. Read them directly at
[`mgf-common/docs/standards/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/).

**Project shape:** **Federation sibling** of `mgf-common`
(per [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0).

**Conformance target:** L2 — Observability-Native (Tier C).
Inherited via the `mgf-common>=0.33,<0.34` dependency.

---

## What lives in mgf-common (do not duplicate here)

The full standards set in `mgf-common/docs/standards/`:

- [`DESIGN_PRINCIPLES.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DESIGN_PRINCIPLES.md) — DP-01..DP-13
- [`ERROR_HANDLING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/ERROR_HANDLING.md) — EH-01..EH-13
- [`LOGGING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/LOGGING.md) — LG-01..LG-17
- [`CONFIGURATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/CONFIGURATION.md) — CF-01..CF-12
- [`SECURITY_STANDARD.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/SECURITY_STANDARD.md) — SC-01..SC-18
- [`TESTING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/TESTING.md) — TS-01..TS-21
- [`API_DESIGN.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/API_DESIGN.md) — AP-01..AP-15
- [`RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md) — REL-01..REL-09
- [`WORKFLOWS.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/WORKFLOWS.md) — WF-01..WF-12
- [`SCOPE.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/SCOPE.md)
- [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) — DOC-01..DOC-12
- [`OPERABILITY.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/OPERABILITY.md) — OP-01..OP-12
- [`DEPLOYMENT.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DEPLOYMENT.md) — DEP-01..DEP-11

---

## Project-specific standards

None. `mgf-sqlalchemy` is a thin async-SQLAlchemy-helpers sibling;
its public surface (see [`PUBLIC_API.md`](../../PUBLIC_API.md))
is three names (`create_engine`, `create_sessionmaker`,
`tenant_session`). The runtime dep is `sqlalchemy[asyncio]` only —
no FastAPI / Starlette / Django leakage.

The Postgres-RLS pattern (one of the load-bearing security
boundaries this library exposes) is documented in
[`mgf-common/docs/design/multi_tenancy.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/design/multi_tenancy.md)
— consult that paper for the consumer-side RLS-policy contract
that `tenant_session` depends on.
