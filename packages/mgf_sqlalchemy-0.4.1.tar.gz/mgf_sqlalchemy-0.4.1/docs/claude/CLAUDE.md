# mgf-sqlalchemy — Claude Reference

Dense lookup document. No prose. Facts only.

> **See also:** [`mgf-common/docs/claude/CLAUDE.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/claude/CLAUDE.md)
> — cornerstone reference shared across the federation. THIS
> file is the mgf-sqlalchemy-specific addenda.

---

## Project shape

- **Federation sibling** of `mgf-common` (per
  [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0).
- **Conformance target:** L2 — inherited via
  `mgf-common>=0.33,<0.34`.
- **PyPI:** `mgf-sqlalchemy`; first published at v0.1.0;
  current v0.2.0 (this release adds the v2.6/v2.7 compliance
  shape).
- **Codeberg:** `magogi-admin/mgf-sqlalchemy`; default branch
  `main`.

## File map (where things live)

| Path | Purpose |
|---|---|
| `src/mgf/sqlalchemy/__init__.py` | Re-exports `create_engine`, `create_sessionmaker`, `tenant_session`. PEP 420 namespace package. |
| `src/mgf/sqlalchemy/_engine.py` | `create_engine()` — async engine factory with production-leaning pool defaults (`pool_pre_ping=True`, `pool_recycle=3600`); SQLite-aware (skips pool kwargs that StaticPool/NullPool reject). |
| `src/mgf/sqlalchemy/_session.py` | `create_sessionmaker()` (defaults `expire_on_commit=False` per SQLA 2.x) + `tenant_session()` async context manager (RLS GUC setter with `SET LOCAL app.current_tenant`). |
| `PUBLIC_API.md` | Contract list — three public names. |
| `CHANGELOG.md` | Per-release record. |
| `SECURITY.md` | Vuln-reporting policy. |
| `docs/standards/README.md` | Pointer-only stub. |
| `docs/cutover/v*.md` | Per-release migration guides. |
| `docs/recipes/*.md` | Task-shaped how-tos. |

## Cross-cutting patterns

1. **`tenant_session` UUID validation BEFORE SQL.** The GUC
   setter runs `SET LOCAL app.current_tenant = '<uuid>'`. If
   `tenant_id` is not a valid UUID, `ValueError` is raised
   BEFORE any SQL is executed. This is the SQL-injection
   defence — even though `SET LOCAL` is parameter-bound, the
   defensive validation makes the security claim grep-able.

2. **`LOCAL` qualifier scopes to the current transaction.**
   `SET LOCAL …` auto-resets on commit/rollback — there's no
   leak across connection-pool checkouts. Without `LOCAL` the
   GUC persists for the connection's lifetime; checkouts of
   the same connection by a different tenant would inherit
   the previous tenant's value. Don't drop the `LOCAL`.

3. **`expire_on_commit=False` is the SQLA 2.x default.**
   Async sessions whose objects expire on commit force a
   re-load (extra DB round trip) the next time an attribute
   is accessed. The SQLA 2.x recommendation is to opt out;
   `create_sessionmaker` honours that. Setting it back to
   `True` is a legacy-shim foot-gun.

4. **SQLite gets a different pool.** `create_engine` detects
   `sqlite://` URLs and skips `pool_size` / `max_overflow` /
   `pool_recycle` / `pool_pre_ping` kwargs — those don't
   apply to `StaticPool` (file-based) or `NullPool`
   (memory). SQLite tests get a working engine without
   "Pool argument not supported" errors.

5. **No FastAPI / Starlette / Django leakage.** The runtime
   graph is `mgf-common` + `sqlalchemy[asyncio]` only. The
   `get_session` + `setup_db` FastAPI-Depends-shaped helpers
   live in `mgf-fastapi.db` (sibling), NOT here. Keeps
   `mgf-sqlalchemy` usable from non-web contexts (CLI tools,
   workers, scheduled jobs).

6. **The RLS pattern requires consumer-side policies.**
   `tenant_session` sets the GUC; the actual row-level
   isolation comes from `CREATE POLICY ON <table> FOR ALL TO
   <role> USING (tenant_id = current_setting('app.current_tenant')::uuid)`
   policies on every tenant-scoped table. Without those
   policies, the GUC is just a value queries ignore. See
   `mgf-common/docs/design/multi_tenancy.md` for the worked
   example.

## Build and release

The canonical sequence per
[`mgf-common/docs/standards/RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md):

1. Bump `version` in `pyproject.toml`.
2. Add the `[X.Y.Z] — YYYY-MM-DD` entry in `CHANGELOG.md`.
3. Update `PUBLIC_API.md` if the public surface changed.
4. Run the full test suite (`pytest`).
5. Run `mypy --strict src/mgf/sqlalchemy/`.
6. Build: `uv build`.
7. `twine check dist/*` — both wheel and sdist MUST pass.
8. Commit + annotated tag.
9. Push commit + tag.
10. `twine upload dist/*`.
11. Post-publish smoke: `pip install --upgrade mgf-sqlalchemy==X.Y.Z`.

## Common pitfalls

- **Forgetting RLS policies on a tenant-scoped table.** The
  GUC setter runs every request; if the table has no
  policy, the query returns rows for ALL tenants. Symptom
  doesn't surface in dev (single-tenant test DB) — only in
  prod after onboarding tenant #2.
- **Setting the GUC outside a transaction.** A bare
  `await session.execute(text("SET app.current_tenant = ..."))`
  (without `LOCAL`) leaks the value to whoever next checks
  out that connection. Always use `tenant_session` (which
  uses `SET LOCAL`).
- **Constructing a UUID from user input without validating.**
  `tenant_session(tenant_id=request.json["tenant_id"])` with
  no upstream validation is fine BECAUSE `tenant_session`
  validates — but defence-in-depth says the request-parsing
  layer should also enforce.
- **Forgetting to dispose the engine on shutdown.** The
  engine owns the connection pool; not disposing leaks
  connections. The `mgf.fastapi.db.setup_db` lifespan
  handles this; non-FastAPI callers MUST call
  `await engine.dispose()` themselves at shutdown.

## Recently-touched areas

- **v0.2.0 prep (2026-05-15)** — added v2.6/v2.7 compliance
  files; no code changes.
- **v0.1.1** — walked mgf-common pin.
- **v0.1.0** — maiden release: engine factory, sessionmaker,
  tenant_session with Postgres-RLS GUC pattern.

---

*Last updated: 2026-05-15.*
