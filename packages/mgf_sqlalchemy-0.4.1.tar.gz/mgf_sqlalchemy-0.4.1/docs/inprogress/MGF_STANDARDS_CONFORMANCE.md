# Magogi Foundation Standards — Conformance Tracker (mgf-sqlalchemy)

> **Status.** v0.1 — initial audit. Created 2026-05-18 per v2.8
> standards bump (DOC-15 + CFM-01..04).
> **Scope.** mgf-sqlalchemy's conformance to the standards at
> [mgf-common/docs/standards/](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/)
> (current standards version: v2.8).
> **Audience.** Maintainer-tomorrow, AI coding agents, future
> contributors.
> **Cross-references.**
> [README.md](../../README.md) (declared level),
> [CHANGELOG.md](../../CHANGELOG.md) (release history).

---

## §1 You are here

**Project shape:** Async-SQLAlchemy helpers — engine/sessionmaker factories, tenant_session.

**Current version:** 0.2.0.

**Declared conformance level: L2** (per CFM-02).
mgf-sqlalchemy pins `mgf-common>=0.34,<0.35` (or `>=0.33,<0.34`
for siblings still on the pre-0.34 window — see CHANGELOG for
the current state).

**Applicable standards groups (rules audited):** DP, EH, LG, SC, CF, AP, TS, DOC, REL.

**N/A standards groups (rule premise doesn't apply to this
project's shape):** OP (no runtime), DEP (library).

**Counts (2026-05-18 — initial audit):**

| Priority | Count | Status |
|---|---|---|
| ✅ structurally conformant | (set on first depth audit) | (set on first depth audit) |
| 🚫 declined-with-rationale | 0 (initial audit; populate as deferrals get filed) | — |
| ⏳ in-progress | (track from sibling's own RA/SH/PC trackers) | — |
| N/A | (rule premise doesn't apply — see §1 above) | — |

**Headline.** mgf-sqlalchemy entered the v0.x release window after a
multi-phase P0 / P1 / P2 sweep (recorded in
`docs/inprogress/RELIABILITY_AND_ACCURACY.md`,
`SECURITY_HARDENING.md`, `PERFORMANCE_AND_CAPACITY.md` — those
trackers carry the falsifiable per-rule evidence). This conformance
tracker is the **rolling audit ledger** alongside those — drift over
time is the signal.

---

## §2 Per-standard audit

Audit method: cross-reference the per-rule list in each standard
under [mgf-common/docs/standards/](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/)
against this sibling's source tree + tests + docs.

Status markers (CFM-03):
- **✅** conformant — implementation + tests + docs match the rule.
- **🚫** declined-with-rationale — rule doesn't apply OR was
  deliberately not adopted; rationale in §3 (CFM-04).
- **⏳** in-progress — adoption planned; gap documented elsewhere.
- **N/A** — rule premise doesn't apply to this project's shape.

### §2.1 DP — DESIGN_PRINCIPLES

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

### §2.2 EH — ERROR_HANDLING

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

### §2.3 LG — LOGGING

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

### §2.4 SC — SECURITY_STANDARD

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

### §2.5 CF — CONFIGURATION

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

### §2.6 AP — API_DESIGN

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

### §2.7 TS — TESTING

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

### §2.8 DOC — DOCUMENTATION

(initial audit: ✅ structurally; depth pass on first standards-bump trigger; v2.8 DOC-13/14/15 newly applicable)

### §2.9 REL — RELEASING

(initial audit: ✅ structurally; depth pass on first standards-bump trigger)

---

## §3 Decline-with-rationale ledger (CFM-04)

(none yet — initial audit. Populate as deferrals get filed,
each carrying a rationale per
[principles/non-adoption-is-valid.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/principles/non-adoption-is-valid.md).)

---

## §4 Audit log

| Date | Auditor | Trigger | Findings |
|---|---|---|---|
| 2026-05-18 | initial audit (v2.8 standards bump) | DOC-15 + CFM-01..04 introduction; this tracker created | scaffolded; first depth audit to follow |

---

## §5 Cross-references

- [mgf-common/docs/standards/](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/)
  — the standards source-of-truth.
- [`docs/inprogress/RELIABILITY_AND_ACCURACY.md`](RELIABILITY_AND_ACCURACY.md)
  — falsifiable per-rule evidence on the RA-* surface
  (where applicable).
- [`docs/inprogress/SECURITY_HARDENING.md`](SECURITY_HARDENING.md)
  — falsifiable per-rule evidence on the SC-* surface.
- [`docs/inprogress/PERFORMANCE_AND_CAPACITY.md`](PERFORMANCE_AND_CAPACITY.md)
  — falsifiable per-rule evidence on the perf-shape surface.
- [`../../FEEDBACK.md`](../../FEEDBACK.md) — papers filed
  against this sibling.
- [mgf-common/docs/standards/principles/non-adoption-is-valid.md](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/principles/non-adoption-is-valid.md)
  — ASPIRE-04 / CFM-04 documented-non-adoption principle.
- [Template this file was scaffolded from](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/recipes/mgf-standards-conformance-md-template.md).
