# `docs/inprogress/` — the maintainer's workspace

**Per `DOC-02` + `DOC-11`** in `mgf-common`'s [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md):
this directory is the **workspace** where the maintainer's
internal-posture docs live while they're active. It is **not a
graveyard** — closed trackers SHOULD move to `docs/archive/<year>/`
within one release cycle.

## What goes here

- **Living priority trackers** (per `DOC-06`): one per concern
  area. Each follows the §1..§6 canonical shape; each work unit
  carries verified `file:line` evidence and a falsifiable concrete
  output.
- **One-shot audit passes**. Finite scope; move to archive when
  complete.

## What does NOT go here

- **Consumer-reported papercuts** — `mgf-sqlalchemy` has no
  consumer-facing `FEEDBACK.md` of its own; consumer signal lands
  in [`mgf-common/FEEDBACK.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/FEEDBACK.md)
  under a `[mgf-sqlalchemy]` prefix.
- **Per-release breaking-change guides** — those go to
  `docs/cutover/`.
- **Permanent rules / standards** — those live in
  `mgf-common/docs/standards/` (this sibling inherits them; see
  [`docs/standards/README.md`](../standards/README.md)).

## Index

| File | Status | What |
|---|---|---|
| [`RELIABILITY_AND_ACCURACY.md`](RELIABILITY_AND_ACCURACY.md) | v0.1 — active | RA-* items: tenant_session transaction-state contract clarity, create_engine **extra override behaviour, create_sessionmaker kwargs ergonomics, NIL UUID acceptance, SQLite-detection shape. |
| [`SECURITY_HARDENING.md`](SECURITY_HARDENING.md) | v0.1 — active | SH-* items: tenant_session SQL-injection property test, connection-string credential redaction (make_safe_url), NIL UUID security framing (twin RA-04), RLS-policy-presence audit helper, sibling SBOM + vuln-scan. |
| [`PERFORMANCE_AND_CAPACITY.md`](PERFORMANCE_AND_CAPACITY.md) | v0.1 — active | PC-* items: tenant_session Python overhead pin, pool_pre_ping tradeoff documentation, engine construction cost, sessionmaker construction cost, RLS audit helper cost. |
