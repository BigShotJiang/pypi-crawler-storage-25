# USERS — who depends on mgf-sqlalchemy

> **Purpose:** mgf-sqlalchemy's user roll. Lists every consumer project and
> federation sibling that imports `mgf.sqlalchemy.*`.
> **Maintained by:** the mgf-common owner (Bassam — mgf-common owns the
> federation per the one-big-library mindset).
> **Per standard DOC-16** (v2.9): every `mgf-*` library MUST maintain a
> `USERS.md` at repo root.

Last verified: 2026-05-18 (post-mgf-sqlalchemy v0.4.0 release with
AuditTrailMixin + UUID v7).

---

## §1 Consumer projects (external users)

| Project           | Location                                      | Import sites | Status                                         | Surfaces used                                |
|-------------------|-----------------------------------------------|-------------:|------------------------------------------------|----------------------------------------------|
| **PlasmaMapper**  | `/home/bassam/PycharmProjects/PlasmaMapper`   | 2            | Active — multi-tenant FastAPI SaaS              | Session helpers + (planned) `AuditTrailMixin` |

**Single-consumer reality.** Only PlasmaMapper imports `mgf.sqlalchemy`
directly today, and only at two call sites. The v0.4.0 audit-trail mixin
+ UUID v7 surface is shipped ahead of broad adoption — PlasmaMapper will
pick them up in its next mgf-* refresh.

---

## §2 Federation siblings (`mgf-*` libraries)

| Sibling          | Import sites | Surfaces used                                  |
|------------------|-------------:|------------------------------------------------|
| **mgf-fastapi**  | 1 *(via the `[sqlalchemy]` extra)* | Audit-trail integration glue                    |

mgf-fastapi declares `mgf-sqlalchemy>=0.4,<0.5` under the `[sqlalchemy]`
extra so FastAPI + SQLAlchemy + audit-trail compose without consumers
having to manage three pins manually.

---

## §3 What a "user" change MUST trigger

See [`../mgf_common/USERS.md`](../mgf_common/USERS.md) §3.

For mgf-sqlalchemy specifically: the `AuditTrailMixin` adds **four
columns** to any table that mixes it in (`created_at`, `created_by`,
`updated_at`, `updated_by`). Renaming or changing the type of those
columns post-v1.0 would force PlasmaMapper to write a migration. Treat
any change to the mixin column shape as a major-version bump candidate
even before v1.0 stabilises that surface.

---

## §4 How this list is maintained

```sh
for proj in VManager inthewords PlasmaMapper iosRecovery; do
  grep -rE "(from|import) +mgf\.sqlalchemy" "/home/bassam/PycharmProjects/$proj" \
    --include='*.py' | wc -l
done
```

Re-run before each MINOR release. Update the table when the count moves.
