# levelwright-system

Hermes-Agent plugin providing handheld system-telemetry tools for [Levelwright](https://github.com/levelwright/levelwright).

**Status:** Placeholder release. Real implementation coming in v0.1.0.

## Scope (planned)

Tools exposed to the Hermes agent:

- `sys_get_temps` — CPU / GPU temperatures
- `sys_get_battery` — percentage, charging state, time remaining
- `sys_get_performance` — TDP, clocks, fan RPM
- `sys_get_storage` — disk usage per partition / SD card

Hardware access is abstracted behind `HardwareAdapter`, with `SteamDeckAdapter` shipping first and future adapters for ROG Ally, Legion Go, MSI Claw. See [ADR-0003](https://github.com/levelwright/levelwright/blob/main/docs/adr/ADR-0003-hardware-adapter-abstraction.md).

## License

MIT.
