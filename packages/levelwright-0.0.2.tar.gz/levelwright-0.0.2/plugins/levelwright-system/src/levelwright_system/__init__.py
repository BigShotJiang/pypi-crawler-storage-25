"""Levelwright system plugin — handheld hardware telemetry.

Placeholder release. Real implementation exposes Hermes-Agent tools for
reading CPU/GPU temperature, battery, TDP, fan speed, and storage through
a HardwareAdapter abstraction. See ADR-0002 and ADR-0003 at
https://github.com/levelwright/levelwright.
"""

__version__ = "0.0.2"
