# GameDweeb — Session Handoff

> Use this prompt to resume work in a new session from a new project directory.

---

## Resume Prompt

Copy everything below the line into your new session:

---

I'm building **GameDweeb** — an open-source, handheld-native, system-level AI gaming assistant, starting with Steam Deck.

### What It Is
Inspired by TechDweeb's April Fools "PocketDweeb" concept (https://www.youtube.com/watch?v=JLG4d5Opo14), I'm building the real thing. Think NVIDIA G-Assist but open-source, for handhelds, running on AMD hardware.

### Tech Stack
- **Base:** Hermes-Agent (https://github.com/NousResearch/hermes-agent) — Python-based AI agent with plugin system, MCP support, memory (MEMORY.md + Honcho), headless gateway, OpenAI-compatible API at :8642/v1, and a self-improving learning loop
- **UI:** Decky Loader plugin (Steam Deck's homebrew plugin system)
- **Platform:** Steam Deck (SteamOS / Arch Linux), expanding to other handhelds later

### Current State
- Research and design phase complete
- Full design document at `DESIGN.md` in this directory
- No code written yet — ready to start Phase 1

### Phase 1 Tasks (Next Step)
Install Hermes-Agent on Steam Deck, then build two Hermes plugins:
1. **gamedweeb-system** — hardware telemetry tools (CPU/GPU temps from /sys/class/hwmon, battery from /sys/class/power_supply/BAT0, performance data, storage info)
2. **gamedweeb-steam** — Steam Web API tools (owned games, playtime, achievements) + ProtonDB compatibility checking

Read `DESIGN.md` for full architecture, feature tiers, technical capability map, and roadmap. Start with Phase 1 implementation.

### Key Design Decisions Already Made
- Hermes-Agent over OpenClaw/NanoClaw (plugin system, Python, memory, MCP, lighter on Deck)
- Two Hermes plugins (system + steam) rather than one monolith
- Decky plugin for UI in Game Mode, talking to Hermes via OpenAI-compatible API
- Local terminal backend (not Docker) for minimal overhead during gameplay
- Optional Honcho for cross-session deep gaming memory
- Working title: GameDweeb

### Key Files
- `DESIGN.md` — Complete design document with architecture, features, API map, competitor analysis, roadmap
