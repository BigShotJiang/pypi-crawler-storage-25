# Levelwright — AI Gaming Assistant for Handhelds

> Open-source, handheld-native, system-level AI gaming assistant. Starting with Steam Deck.

**Status:** Design Phase v0.1  
**Date:** April 19, 2026  
**Base Framework:** [Hermes-Agent](https://github.com/NousResearch/hermes-agent) by Nous Research  

---

## I. Origin Story

Inspired by **PocketDweeb** by TechDweeb (YouTube: https://www.youtube.com/watch?v=JLG4d5Opo14) — an April Fools concept for a gaming AI assistant on handhelds. The download page (techdweeb.straw.page/pocketdweeb) confirmed it wasn't real, but community reactions showed genuine demand.

**NVIDIA already proved this concept works.** Their **Project G-Assist** started as an April Fools joke in 2018 and became a real product in March 2025. It optimizes game settings, measures frame rates, controls RGB, provides diagnostics, and integrates with Logitech/Corsair/Nanoleaf. But it's **RTX desktop-only, closed-source, and doesn't run on handhelds.**

**No one has built an open-source, handheld-native, system-level AI gaming assistant.** That's our opening.

---

## II. Competitive Landscape

| Product | What It Does | Platform | Open Source | Gap We Fill |
|---|---|---|---|---|
| **NVIDIA G-Assist** | Settings optimization, FPS, diagnostics, RGB control | RTX Desktop only | No | Handheld + AMD support |
| **Xbox Gaming Copilot** | Game recommendations, tips, coaching | Xbox/Windows | No | Not on Steam Deck/Linux |
| **Razer Game Co-AI** | Real-time esports coaching | Windows/Razer | No | Not handheld-focused |
| **Questie AI** | Screen-watching companion, voice tips (https://www.questie.ai/gaming-ai) | Browser/Mobile | No | Not system-level |
| **GAMEBORO** | Overlay assistant, mid-game Q&A (https://gameboro.net/) | Windows | No | Not on Linux/handhelds |
| **Tryll Assistant** | On-device LLM, game prompts | Steam (Early Access) | No | Limited to Windows |
| **LudereAI** | Screenshot analysis, context-aware chat (https://github.com/0xRoco/LudereAI) | Windows | Yes | Not handheld-aware |
| **Project Aegis** | Air-gapped companion, multi-model (https://github.com/ninja-otaku/Project_Aegis) | Cross-device | Yes | Not system-integrated |
| **AiGameCompanion** | In-game overlay, multi-model support (https://github.com/Wintersta7e/AiGameCompanion) | Windows | Yes | Not on Linux |
| **grok-the-gamer** | Voice assistant overlay using Grok (https://github.com/davelalande/grok-the-gamer) | Windows | Yes | Not handheld |
| **AI Game Coach** | Real-time coaching tool (https://github.com/zeenden69ilikelife/ai-game-coach) | Windows | Yes | Not handheld |
| **OpenRA-RL** | AI agents for classic RTS games (https://github.com/yxc20089/OpenRA-RL) | PC | Yes | Research/specific game |
| **GamingAgent** | LLM/VLM gaming agent framework (https://github.com/lmgame-org/GamingAgent) | Python | Yes | Research/benchmarking |

---

## III. Architecture

### Why Hermes-Agent as Base

| Criterion | Hermes-Agent | OpenClaw | NanoClaw | From Scratch |
|---|---|---|---|---|
| Plugin system | Full (YAML + Python) | Skills only | Limited | Build everything |
| Memory system | 3-layer + Honcho | Session-based | Per-group | Build everything |
| MCP support | Yes | Via skills | No | Build everything |
| Headless gateway | PID-managed | systemd | Docker only | Build everything |
| OpenAI-compatible API | :8642/v1 | Port 18789 | No | Build everything |
| Learning loop | Self-improving | No | No | Build everything |
| Terminal backends | 6 options (local/Docker/SSH/Singularity/Modal/Daytona) | Node only | Docker only | Build everything |
| Runtime | Python 3.11 | Node.js 24 | Node.js/Docker | N/A |
| Install on Linux | One-liner | Node required | Docker required | N/A |

Hermes wins because:
- Plugin system lets us add gaming tools without forking core
- Memory system (MEMORY.md + USER.md + Honcho) stores gaming context across sessions
- MCP connects to external Steam/game APIs
- Headless gateway runs in background during gameplay
- Python is lighter on Deck than Node.js or Docker
- Learning loop means assistant gets better at optimizing over time
- OpenAI-compatible API at `localhost:8642/v1` enables Decky UI integration

### Architectural Principles

These principles keep the PoC codebase reusable as we expand to other handhelds and to commercial distribution targets (§XI). They are binding; deviations must be justified in an ADR.

1. **Plugins are handheld-agnostic.** `levelwright-system` tools must not hardcode Steam Deck sysfs paths. Hardware access goes through a `HardwareAdapter` interface with per-device implementations (`SteamDeckAdapter`, `LegionGoAdapter`, `ROGAllyAdapter`, `WindowsAdapter`). Adding a new handheld = implementing one adapter, not rewriting tools.

2. **Frontends are swappable.** Decky plugin, Telegram bot, desktop app, and CLI are all *clients* of the Hermes API at `localhost:8642/v1`. No frontend-specific logic leaks into plugins. A desktop Steam-store app (§XI, Path B) must be possible without changing a single line of plugin code.

3. **Tools are tagged by privilege tier.** Every tool declares one of: `public` (no special privileges), `elevated` (needs sudo or polkit — e.g. TDP/fan control), or `homebrew` (requires Decky + developer mode). Frontends query available tools and degrade gracefully — a sandboxed Steam-store build simply hides elevated/homebrew features rather than crashing.

4. **State is portable.** Memory, preferences, and per-game profiles live in platform-agnostic formats (Hermes `MEMORY.md`, SQLite, optional Honcho). A user moving from Deck to ROG Ally must be able to bring their Levelwright profile with them.

5. **OSS first, commercial second.** Everything built in the PoC ships under the project's OSS license. Commercial variants layer on top (bundled installer, polished UI, premium features) — never fork or close-source PoC code. See §XI for the full open-core strategy.

### System Architecture Diagram

```
+-------------------------------------------------------------+
|                      Levelwright Stack                         |
+-------------------------------------------------------------+
|                                                             |
|  +-------------+  +---------------+  +------------------+   |
|  |  Decky UI   |  |  Telegram/    |  |  Web UI          |   |
|  |  Plugin     |  |  Discord      |  |  (Open WebUI)    |   |
|  |  (Frontend) |  |  (Remote)     |  |  (Desktop Mode)  |   |
|  +------+------+  +-------+-------+  +--------+---------+   |
|         |                  |                    |             |
|         +----------+-------+--------------------+             |
|                    |                                        |
|         +----------v-----------+                            |
|         |  Hermes-Agent        |                            |
|         |  (Local Backend)     |                            |
|         |  +- OpenAI API       |  <- External apps talk     |
|         |  |  :8642/v1/...     |    via standard API         |
|         |  +- Plugin System    |                            |
|         |  +- Memory (Local +  |                            |
|         |  |  Honcho optional) |                            |
|         |  +- Skills System    |                            |
|         |  +- Cron Scheduler   |                            |
|         |  +- MCP Client       |                            |
|         +----------+-----------+                            |
|                    |                                        |
|    +---------------+---------------+                        |
|    |               |               |                        |
|  +-v---------+ +-+-v--------+ +--v----------+              |
|  | Steam     | | System     | | Game Data   |              |
|  | Tools     | | Tools      | | Tools       |              |
|  | (Plugin)  | | (Plugin)   | | (Plugin)    |              |
|  +-----------+ +------------+ +-------------+              |
|                                                             |
|  +-----------+ +------------+ +-------------+              |
|  | Decky     | | Linux      | | MangoHUD /  |              |
|  | Loader    | | sysfs/     | | Perf Overlay |              |
|  | API       | | procfs     | |              |              |
|  +-----------+ +------------+ +-------------+              |
+-------------------------------------------------------------+
```

### Data Flow

```
User asks "What should I play?"
  -> Decky UI / Telegram / CLI
    -> Hermes API (:8642/v1/chat/completions)
      -> Prompt assembly (memory + context + skills)
        -> Tool dispatch:
          -> steam_get_library (owned games)
          -> steam_get_playtime (hours per game)
          -> protondb_check_compat (ratings)
          -> sys_get_battery (battery state)
        -> Memory lookup (past preferences, genres)
      -> LLM generates recommendation
    -> Response delivered to user
```

---

## IV. Feature Design

### Tier 1: Core System Intelligence (MVP)

| Feature | How It Works | Data Source |
|---|---|---|
| "What should I play?" | Analyzes library, playtime, last played, mood/genre prefs, ProtonDB compat | Steam Web API + ProtonDB + memory |
| System Health Monitor | Battery life, CPU/GPU temps, fan speed, throttling alerts, storage space | `/sys/class/hwmon`, `/sys/class/power_supply/BAT0`, `lm-sensors` |
| Performance Advisor | "Your temps are high - drop TDP to 8W for this game" | Real-time sensor data + game-specific profiles |
| Game Compatibility Check | ProtonDB rating, Deck verified status, proton version recommendations | ProtonDB API + Steam API |
| Storage Manager | "You have 12GB free. Here are least-played games to consider removing." | Steam library + filesystem |
| Update Watchdog | System updates, game patches, Proton updates available | SteamOS + Steam API |

### Tier 2: Gaming Intelligence (v1.0)

| Feature | How It Works | Data Source |
|---|---|---|
| Per-Game Performance Profiles | Auto-apply TDP, refresh rate, FSR settings per game. Learns optimal from telemetry. | MangoHUD + game history + memory |
| Achievement Tracker | Track progress, suggest next game based on achievement goals | Steam Web API `ISteamUserStats` |
| Play Session Analytics | "You played 3h this week, mostly indie. Battery efficiency improved 15%." | Session logging + hardware telemetry |
| Game Launch Optimization | Pre-game: close background processes, set performance profile, check compat | System APIs + Decky hooks |
| Retro Gaming Assistant | Emulator setup help, ROM organization, controller mapping, save-state management | EmuDeck integration + memory |
| Cron Automations | "Update game lists every Monday at 3am", "Back up saves daily" | Hermes cron + filesystem tools |

### Tier 3: Advanced Intelligence (v2.0)

| Feature | How It Works |
|---|---|
| Voice Control (Wake Word) | "Hey Levelwright, what's my battery?" - hands-free during gameplay |
| Screen Analysis | See game screen, provide contextual tips ("boss weak point is glowing red") |
| Multi-Handheld Sync | Settings/profiles sync across Deck, Legion Go, ROG Ally |
| Community Intelligence | Anonymous telemetry: "95% of players use 10W TDP for this game" |
| Decky Plugin Store | Publish gaming plugins to Decky ecosystem |

---

## V. Technical Implementation Details

### 5.1 Hermes Plugin: `levelwright-steam`

```yaml
# ~/.hermes/plugins/levelwright-steam/plugin.yaml
name: levelwright-steam
version: 0.1.0
description: "Steam Deck gaming intelligence - library, performance, compatibility"
hooks:
  - post_session_start
tools:
  - steam_get_library        # Fetch owned games via Steam Web API
  - steam_get_playtime       # Get hours played per game
  - steam_get_achievements   # Achievement progress per game
  - steam_get_game_details   # Store page, tags, screenshots
  - steam_get_recent         # Recently played games
  - protondb_check_compat    # ProtonDB rating for a game
  - protondb_get_reports     # User reports for a game/proton version
```

### 5.2 Hermes Plugin: `levelwright-system`

```yaml
# ~/.hermes/plugins/levelwright-system/plugin.yaml
name: levelwright-system
version: 0.1.0
description: "Steam Deck system monitoring and optimization"
tools:
  - sys_get_temps            # CPU/GPU temps from /sys/class/hwmon
  - sys_get_battery          # Battery %, charging state, time remaining
  - sys_get_performance      # Current TDP, clocks, fan speed, GPU load
  - sys_get_storage          # Disk usage, game sizes, SD card status
  - sys_set_perf_profile     # Apply performance profile (TDP, FSR, refresh)
  - sys_get_processes        # Running processes, memory usage
  - sys_check_updates        # SteamOS/system updates available
  - sys_optimize_for_game    # One-command game-specific optimization
```

### 5.3 MCP Server: `steam-deck-mcp` (alternative integration path)

```yaml
# ~/.hermes/config.yaml - MCP servers section
mcp_servers:
  - name: steam-deck
    transport: stdio
    command: python
    args: ["~/.hermes/mcp/steam-deck-mcp/server.py"]
    tools:
      - get_library
      - get_game_performance_history
      - check_proton_compat
      - get_hardware_telemetry
      - apply_game_profile
      - search_game_guides
```

### 5.4 Memory Strategy

```
MEMORY.md (2,200 chars - built-in Hermes)
+-- Player profile: preferred genres, play style, session length preferences
+-- Hardware profile: Steam Deck model, storage config, accessories
+-- Quick preferences: always-on TDP limit, preferred FSR mode, notification prefs

USER.md (1,375 chars - built-in Hermes)
+-- Name/handle, communication style, gaming identity

Session Storage (SQLite + FTS5 - built-in Hermes)
+-- Full conversation history, searchable
+-- Game-specific discussions, optimization attempts

Honcho (optional - cross-session deep memory)
+-- Per-game performance history (what settings worked)
+-- Play session patterns (when, how long, battery drain rates)
+-- Achievement pursuit goals and progress
+-- Evolving recommendations based on play history
+-- Dialectic user modeling: learns your playstyle over time
```

### 5.5 Decky Plugin — UI Layer

```
Levelwright Decky Plugin
+-- Quick Panel (overlay in-game)
|   +-- Battery: 67% (~1h 23m remaining)
|   +-- CPU: 72C | GPU: 68C | Fan: 2400 RPM
|   +-- TDP: 10W | Refresh: 40Hz
|   +-- [Ask Levelwright] <- voice/text input to Hermes API
+-- Library View
|   +-- "Play Next" recommendations (AI-ranked)
|   +-- Compatibility badges (ProtonDB + Deck Verified)
|   +-- Unplayed games with time investment estimates
+-- Performance Profiles
|   +-- Per-game saved profiles
|   +-- Community-recommended profiles
|   +-- Auto-optimize button
+-- Settings
    +-- Notification preferences
    +-- Cron job management
    +-- Memory/privacy controls
```

**Integration path:** Decky plugin frontend -> `serverAPI.callPluginMethod()` -> Python backend -> Hermes API Server (`localhost:8642/v1/chat/completions`) -> Hermes processes with gaming tools

---

## VI. Steam Deck Technical Capability Map

### APIs and Data Sources Available

| Capability | Source | Integration Method |
|---|---|---|
| Decky Plugin System | [decky-loader](https://github.com/SteamDeckHomebrew/decky-loader) | Plugin via `serverAPI.callPluginMethod()` |
| Decky API Library | [loader-api](https://github.com/SteamDeckHomebrew/loader-api) | npm: `@decky/api` |
| Plugin Dev Template | [decky-plugin-template](https://github.com/EmuDeck/decky-plugin-template) | Fork and modify |
| Plugin Dev Docs | [Deckbrew Wiki](https://wiki.deckbrew.xyz/en/plugin-dev/getting-started) | Reference |
| CPU/GPU Temps | `/sys/class/hwmon/` | Python `open()` or `lm-sensors` |
| Battery Status | `/sys/class/power_supply/BAT0/` | Read `capacity`, `status`, `charge_control_end_threshold` |
| System Info | `/proc/`, `/sys/`, `uname` | Standard Linux interfaces |
| Performance Overlay | Steam built-in (Level 1-4) | User-facing; MangoHUD for programmatic |
| Hardware Telemetry | [MangoHUD](https://github.com/flightlessmango/MangoHud) | Config file + log output |
| Steam Library | Steam Web API `IPlayerService/GetOwnedGames` | HTTP with API key |
| Play Time | Steam Web API `IPlayerService/GetRecentlyPlayedGames` | HTTP with API key |
| Achievements | Steam Web API `ISteamUserStats/GetPlayerAchievements` | HTTP with API key |
| Game Details | Steam Web API `ISteamUserStats/GetSchemaForGame` | HTTP with API key |
| ProtonDB Ratings | [ProtonDB API](https://www.protondb.com/) + [CLI](https://github.com/hypeedev/protondb-cli) | HTTP or CLI |
| Steam App ID Data | Steam store API / local manifest files | Parse local files or HTTP |
| Fan Control | `/sys/class/hwmon/*/pwm*` | Write to sysfs (may need permissions) |
| TDP Control | SteamOS system tools / `ryzenadj` | CLI tool call |

### Key Reference Repos

- Decky Loader: https://github.com/SteamDeckHomebrew/decky-loader
- Decky Loader API: https://github.com/SteamDeckHomebrew/loader-api
- Decky Plugin Template: https://github.com/EmuDeck/decky-plugin-template
- MangoHUD: https://github.com/flightlessmango/MangoHud
- ProtonDB CLI: https://github.com/hypeedev/protondb-cli
- Steam Web API wrappers: https://github.com/cambsull/SteamWebAPILibrary
- Steam Deck Sysinfo Gist: https://gist.github.com/Patola/d29b74a9d55dde17d3c652302c182780

---

## VII. Hermes-Agent Architecture Reference

### Extension Points We Use

| Extension Point | What We Build | Documentation |
|---|---|---|
| **Plugins** | `levelwright-steam`, `levelwright-system` | [Plugins docs](https://github.com/NousResearch/hermes-agent/blob/fb903b8f08c8c9df2b4d8e0175d50eb888de62f8/website/docs/user-guide/features/plugins.md) |
| **Skills** | Game-specific knowledge (retro guides, achievement strategies) | [Skills docs](https://github.com/NousResearch/hermes-agent/blob/10edd288c3ef2bac3c11d70b3bf204e87ea9e698/website/docs/user-guide/features/skills.md) |
| **MCP** | Steam Deck MCP server for external tool access | [MCP docs](https://github.com/NousResearch/hermes-agent/blob/5b0243e6ad8002a6e8e129b5e2295cd01849b9d7/website/docs/user-guide/features/mcp.md) |
| **Memory** | Gaming preferences, session history, playstyle | [Memory docs](https://hermes-agent.nousresearch.com/docs/user-guide/features/memory) |
| **Honcho** | Cross-session deep gaming memory (optional) | [Honcho docs](https://github.com/NousResearch/hermes-agent/blob/21d5ef2f1742b4a8bd5fb69c07eda79cefdc57ab/website/docs/user-guide/features/honcho.md) |
| **API Server** | OpenAI-compatible HTTP for Decky UI integration | [API Server docs](https://github.com/NousResearch/hermes-agent/blob/24fa05576366564479e0b0e7ee37d34a28506cc3/website/docs/user-guide/features/api-server.md) |
| **Gateway** | Headless background service during gameplay | [Gateway docs](https://github.com/NousResearch/hermes-agent/blob/24fa05576366564479e0b0e7ee37d34a28506cc3/website/docs/developer-guide/gateway-internals.md) |
| **Cron** | Scheduled tasks (save backups, library sync) | Built-in Hermes feature |

### Hermes Key Facts

- **Terminal backends**: local, Docker, SSH, Singularity, Modal, Daytona (use `local` for Deck)
- **Memory layers**: MEMORY.md (2,200 chars) + USER.md (1,375 chars) + Session Search (SQLite + FTS5) + Honcho (optional external)
- **Tool registry**: 47 built-in tools, 19 toolsets
- **Plugin discovery**: `~/.hermes/plugins/`, `.hermes/plugins/`, pip entry_points
- **Plugin types**: General (tools/hooks/CLI), Memory Provider, Context Engine
- **API endpoints**: `/v1/models`, `/v1/chat/completions`, `/v1/responses`, `/health`
- **Gateway PID**: `~/.hermes/gateway.pid` with systemd support
- **Install**: `curl -fsSL https://raw.githubusercontent.com/NousResearch/hermes-agent/main/scripts/install.sh | bash`
- **License**: MIT
- **Latest**: v0.9.0 (April 16, 2026)

---

## VIII. Development Roadmap

### Phase 1: Foundation (2-3 weeks)
- [ ] Install Hermes-Agent on Steam Deck (local backend)
- [ ] Create project repo structure
- [ ] Build `levelwright-system` plugin (hardware telemetry tools)
  - [ ] `sys_get_temps` - read CPU/GPU from `/sys/class/hwmon`
  - [ ] `sys_get_battery` - read from `/sys/class/power_supply/BAT0`
  - [ ] `sys_get_performance` - current TDP, clocks, fan
  - [ ] `sys_get_storage` - disk usage
- [ ] Build `levelwright-steam` plugin (Steam Web API tools)
  - [ ] `steam_get_library` - owned games
  - [ ] `steam_get_playtime` - hours per game
  - [ ] `steam_get_achievements` - achievement progress
  - [ ] `protondb_check_compat` - ProtonDB ratings
- [ ] Test via Hermes CLI: "What's my battery?" -> response with telemetry
- [ ] Verify headless gateway runs during gameplay without performance impact

### Phase 2: Intelligence (3-4 weeks)
- [ ] Build "What should I play?" recommendation engine
- [ ] Implement per-game performance profiles (TDP + FSR + refresh per game)
- [ ] Add play session tracking and analytics
- [ ] Create game-specific skills (retro gaming guide, achievement hunting)
- [ ] Set up cron automations (save backups, library sync, update checks)
- [ ] Tune memory strategy for gaming context

### Phase 3: UI (4-6 weeks)
- [ ] Build Decky Loader plugin frontend
- [ ] Wire Decky frontend -> Hermes API Server communication
- [ ] Implement in-game quick panel overlay (battery, temps, TDP)
- [ ] Add "Ask Levelwright" text/voice input
- [ ] Build library view with AI recommendations
- [ ] Add notification system (battery alerts, temp warnings, update available)
- [ ] Test in Game Mode during actual gameplay
- [ ] Publish to Decky Plugin Store

### Phase 4: Advanced (ongoing)
- [ ] Voice wake word integration
- [ ] Screen analysis via vision model (contextual tips)
- [ ] Community telemetry aggregation (opt-in anonymous data)
- [ ] Multi-handheld support (ROG Ally, Legion Go, MSI Claw)
- [ ] Mobile companion app (control via Telegram/Discord remotely)
- [ ] Local LLM option for fully offline operation

---

## IX. Project Naming

**Chosen name: Levelwright.**

"Wright" is a craftsperson suffix (playwright, shipwright, wheelwright, millwright). "Level" is universal gaming vocabulary. Together: *one who crafts your gaming experience, one who helps you level up.* Clean single word, two syllables, brandable.

Availability verified on 2026-04-19:
- `github.com/levelwright` — not registered
- `pip install levelwright` — not registered
- `levelwright.com` — available
- `levelwright.dev` — available
- `levelwright.gg` — **taken** (acceptable; .com + .dev cover primary web presence)
- USPTO trademark search — no hits

**Alternatives considered (rejected):**

| Name | Why rejected |
|---|---|
| GameDweeb | Original working title (tribute to TechDweeb's PocketDweeb). Playful, but "Dweeb" carries a commercial ceiling — cannot ship in a paid Steam store listing without rebranding later (§XI). Replacing early avoids sunk-cost identity. |
| Gamewright | Craftsman vibe was right, but conflicts with *Gamewright Games* (active tabletop publisher since 1994, gaming-category trademark). |
| Playsmith | Trademark (KEFI Holdings, 2018) was abandoned in 2021, but `github.com/playsmith` and `playsmith.com` were both taken. |
| Hench | Short, punchy, fully available. Rejected: tone leaned too casual/irreverent to scale into a future commercial brand. |
| Gearmate | Clean and literal ("partner for your gear"). Rejected: slightly generic, less memorable than Levelwright. |
| Playforge, Questkeeper, Cairn, Familiar, Vanguard, Stalwart, Squire | All ruled out by direct semantic collisions with existing AI/gaming/tech projects on GitHub. |

The PocketDweeb lineage is preserved as an origin story (§I), not as the product name.

---

## X. Key Links and Resources

### Hermes-Agent
- GitHub: https://github.com/NousResearch/hermes-agent
- Docs: https://hermes-agent.nousresearch.com/docs
- Install: https://hermes-agent.nousresearch.com/docs/getting-started/installation

### Steam Deck / Decky
- Decky Loader: https://github.com/SteamDeckHomebrew/decky-loader
- Decky API: https://github.com/SteamDeckHomebrew/loader-api
- Decky Plugin Template: https://github.com/EmuDeck/decky-plugin-template
- Decky Plugin Dev Docs: https://wiki.deckbrew.xyz/en/plugin-dev/getting-started
- Decky Frontend Lib: https://wiki.deckbrew.xyz/en/api-docs/decky-frontend-lib/README.md

### Steam / Gaming APIs
- Steam Web API: https://developer.valvesoftware.com/wiki/Steam_Web_API
- Steamworks Web API: https://partner.steamgames.com/doc/webapi_overview
- ProtonDB: https://www.protondb.com/
- ProtonDB CLI: https://github.com/hypeedev/protondb-cli
- MangoHUD: https://github.com/flightlessmango/MangoHud

### Inspiration
- PocketDweeb (April Fools): https://www.youtube.com/watch?v=JLG4d5Opo14
- NVIDIA G-Assist (real product): https://www.nvidia.com/en-us/geforce/g-assist/
- Xbox Gaming Copilot: https://www.xbox.com/en-US/gaming-copilot

### Competitors (for reference)
- Questie AI: https://www.questie.ai/gaming-ai
- GAMEBORO: https://gameboro.net/
- Razer Game Co-AI: https://www.razer.com/game-co-ai/
- LudereAI: https://github.com/0xRoco/LudereAI
- Project Aegis: https://github.com/ninja-otaku/Project_Aegis
- AiGameCompanion: https://github.com/Wintersta7e/AiGameCompanion

---

## XI. Distribution Strategy

### PoC → Product Path

The design in this document is **Phase A: a proof-of-concept**. It validates feature demand, builds a community, and produces a portfolio of working code *before* any commercial distribution attempt. Phase B is a commercial offering built on top of the PoC — we do not build the commercial product first.

```
+---------------------------+
|  Phase A: PoC (this doc)  |
|  - Open source            |
|  - Decky Plugin Store     |
|  - Steam Deck first       |
|  - "Levelwright" branding   |
+------------+--------------+
             |
             | validates: feature demand, technical approach,
             | community interest, real-world performance
             v
    +--------+----------+
    |                   |
    v                   v
+---+---------+   +-----+----------+
| Path B1:    |   | Path B2:       |
| Pitch Valve |   | Steam Store    |
| - SteamOS   |   | - Desktop app  |
|   feature   |   | - Cross-       |
| - Absorbed  |   |   handheld     |
|   into OS   |   | - Paid or F2P  |
+-------------+   +----------------+

(Paths B1 and B2 are not mutually exclusive.)
```

### Why the Design in This Doc Cannot Ship Directly to the Steam Store

- **Decky dependency.** Decky Loader is unofficial homebrew requiring SteamOS developer mode. Valve will not approve a store app that requires a modified OS.
- **Sysfs writes.** Setting TDP, fan speeds, or refresh rate requires privileges a Steam-distributed, sandboxed app cannot hold.
- **API key distribution.** Shipping a single Steam Web API key inside a paid app conflicts with Steamworks' terms; per-user keys need a setup flow.

The PoC accepts all of these because it's homebrew. The commercial product must work around them.

### Path B1: Pitch to Valve

**Hypothesis:** if Levelwright reaches meaningful adoption on Decky, Valve absorbs the concept into SteamOS directly — similar to how KDE Plasma features and Proton tooling have graduated from community projects to first-party support.

**What we need for a credible pitch:**
- Published Decky plugin with documented install base
- Measurable user engagement (DAU, feature usage — opt-in telemetry)
- Clear data on hardware impact (no performance regression during gameplay)
- Reference architecture that Valve engineers can ingest without forking

**Risks:**
- Valve clones the concept and ships their own implementation
- Valve declines (AI is contentious; system-level access is risky)

**Mitigation:** ship prior art first. Open source + public community = harder to quietly copy without credit, and creates a hiring/acquisition incentive instead.

### Path B2: Sell on Steam (Desktop Companion)

**Hypothesis:** a polished **desktop-mode companion app** can ship on the Steam store as non-game software (precedents: Wallpaper Engine, Aseprite, Virtual Desktop, RPG Maker). The commercial version targets the *full handheld market*, not just Steam Deck — ROG Ally, Legion Go, MSI Claw, and any future Windows-based handheld are a larger TAM than the Deck alone.

**Feature split across distribution targets:**

| Feature | Decky plugin (PoC, free/OSS) | Desktop app (Steam store, paid) |
|---|---|---|
| In-game overlay quick panel | Yes (homebrew only) | No (sandboxed) |
| TDP / fan control | Yes | No |
| Battery/temp reading | Yes | Yes (read-only) |
| Library recommendations | Yes | Yes |
| ProtonDB compatibility | Yes | Yes (Linux targets only) |
| Screen analysis / chat | Yes | Yes |
| Per-game profile sync | Yes | Yes |
| Cross-handheld profile portability | Yes | Yes (selling point) |
| Voice wake word | Yes | Yes |
| Retro / emulator tooling | Yes | Platform-dependent |

Rule of thumb: anything that needs sysfs writes, `ryzenadj`, or Decky hooks stays on the Decky (free) side. Everything else can ship commercial. The §III privilege-tier tagging is what makes this split automatic at build time.

**What we need for a Steam store submission:**
- Steamworks Partner account + $100 Steam Direct fee
- Brand separate from "Levelwright" may be warranted for the store listing depending on marketing positioning (see Branding below)
- AI disclosure per Valve's content policy
- No homebrew dependencies in the store build
- Windows build parity (Tauri or Qt for cross-platform desktop)

### Branding

| Surface | Name | Role |
|---|---|---|
| PoC, open source | **Levelwright** | Community-facing; permanent; craftsman-of-your-gaming-experience positioning |
| Commercial product | **TBD** — may reuse Levelwright, or layer a new brand | Decided later when commercial path (B1 vs B2) is chosen |

Unlike the original GameDweeb working title (which could not ship commercially without rebrand), Levelwright is cleared for commercial use if desired. The commercial name decision is deferred to Phase B rather than forced now.

### Licensing — Open-Core Model

- **Core (Hermes plugins, Decky plugin, MCP servers):** permissive OSS license (MIT or Apache 2.0), matching Hermes-Agent's license.
- **Commercial desktop app:** proprietary wrapper built on the open core.
- Precedents: GitLab, Supabase, Sentry, Elastic (pre-license-change).

A **Contributor License Agreement (CLA)** for OSS contributors preserves our right to relicense parts of the codebase into a proprietary product later. Without a CLA, a single strict-copyleft contribution could block commercial distribution.

### Decision Dependencies

This strategy requires early commitments captured in the PRD and ADRs:

- License choice (MIT + CLA vs Apache 2.0 vs copyleft) — **ADR**
- Hardware abstraction layer up front, not retrofit — **ADR**
- Privilege-tier tagging on every tool — **ADR**
- LLM backend strategy (local / cloud / user-choice) — **ADR**
- Steam Web API key strategy (per-user vs app-wide) — **ADR**
- Brand separation agreed before first public release — **PRD**
