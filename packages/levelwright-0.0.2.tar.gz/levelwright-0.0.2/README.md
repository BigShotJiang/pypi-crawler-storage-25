# Levelwright

> Open-source, handheld-native, system-level AI gaming assistant. Starting with Steam Deck.

**Status:** Design phase complete; Phase 1 implementation starting.

Inspired by TechDweeb's April Fools "PocketDweeb" concept, built for real. Think NVIDIA's Project G-Assist, but open-source, handheld-first, AMD-compatible.

## What it is

A locally-running AI agent on your Steam Deck (and eventually other handhelds) that can:

- Answer "what's my battery / CPU temp / TDP?" without tabbing out of a game
- Check ProtonDB compatibility and Deck Verified status before you buy or launch
- Recommend games from your library based on playtime, compat, and session context
- Scale to ROG Ally, Legion Go, and MSI Claw via a pluggable `HardwareAdapter`

Built on [Hermes-Agent](https://github.com/NousResearch/hermes-agent) (Python, MIT). UI via [Decky Loader](https://github.com/SteamDeckHomebrew/decky-loader).

## Status

This PyPI package is a **placeholder** while the real implementation is built. The actual Hermes plugins ship as:

- `levelwright-system` — hardware telemetry (CPU/GPU temps, battery, TDP)
- `levelwright-steam` — Steam Web API + ProtonDB compatibility

See:

- [`DESIGN.md`](./DESIGN.md) — full technical design
- [`docs/prd/levelwright-poc-prd.md`](./docs/prd/levelwright-poc-prd.md) — product requirements
- [`docs/adr/`](./docs/adr/) — architecture decision records

## License

MIT — see [`LICENSE`](./LICENSE).
