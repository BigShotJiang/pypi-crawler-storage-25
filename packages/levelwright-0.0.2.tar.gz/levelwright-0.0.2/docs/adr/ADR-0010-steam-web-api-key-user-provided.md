# ADR-0010: Steam Web API Key — User-Provided

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

Levelwright's `levelwright-steam` plugin (ADR-0002) reads the user's owned games, playtime, achievements, and recently-played data from the Steam Web API. Every Steam Web API call requires a key.

Valve's Steamworks Web API Terms of Use explicitly prohibit embedding and distributing an API key inside client applications ([Steamworks Web API Usage](https://steamcommunity.com/dev/apiterms)). Concretely:

> "You agree that you will not reveal your Steam Web API Key to any third party."

An API key shipped inside a binary — even obfuscated — is revealed to every user, which violates the terms. Any serious distribution (Decky Plugin Store, Steam Direct submission, AUR) would treat this as a critical issue.

Three shipping patterns exist:

| Pattern | ToS safety | UX friction | Infra cost | Privacy |
|---|---|---|---|---|
| User provides own key | ✅ Safe | Moderate (one-time setup) | None | User's data stays between them and Valve |
| App-wide key in binary | ❌ Violates ToS | None | None | Shared rate limit; app can see user data |
| Backend proxy holds key | ✅ Safe | None after setup | Hosted service | User data passes through operator |

## Decision

**Each Levelwright user provides their own Steam Web API key. Levelwright stores it encrypted at rest and uses it only for calls made on behalf of that user.**

Install flow:

1. During first-run setup (or when `levelwright-steam` is first enabled), Levelwright opens a browser to https://steamcommunity.com/dev/apikey
2. User fills in their domain (localhost is accepted), accepts the Steamworks agreement, and receives a 32-char key
3. User pastes the key into the Levelwright setup UI
4. Key is encrypted with a per-device key (derived from user login + a hardware-bound salt) and stored in `~/.levelwright/secrets/steam.enc`
5. The key is never logged, never printed, never sent off-device

Key rotation:

- `levelwright steam rotate-key` clears the stored key and re-triggers the setup flow
- On auth failure (401/403 from Steam), the agent surfaces a clear message pointing to rotation

This is formalized in PRD §3.2 FR-2.6.

## Consequences

### Positive

- **ToS-compliant.** Safe for public distribution, including Decky Plugin Store, AUR, Flathub, and any future Steam-store submission.
- **Zero infrastructure.** No backend proxy to run, pay for, secure, or scale.
- **Per-user rate limits.** Steam's 100,000 requests/day limit applies per key, not to a shared Levelwright key, so no one user can exhaust it for everyone.
- **Privacy-respecting.** The user's Steam library contents never pass through a Levelwright-operated service. User → Valve directly; Levelwright is a client library.
- **Key revocation under user control.** If a user wants out, they revoke their own key; we can't "turn them off" because we never had access.

### Negative

- **Install friction.** A brand-new user must navigate to the Steam developer portal, accept an agreement, and paste a 32-char key. This will turn away a non-trivial slice of the target audience. Mitigation: the setup UI is heavily annotated with screenshots; the step is a one-time tax.
- **Casual users might abandon setup** when confronted with "paste an API key." Measurable risk against PRD success metric M2 (100+ installs).
- **No automatic recovery** from a revoked or expired key — the user must redo setup.

### Neutral

- Encryption at rest must be real (not just base64). We use `cryptography.fernet` seeded with a key derived via `scrypt` from user's system UUID + a fixed salt. Not NSA-grade, but prevents casual exfiltration from a backup.

## Alternatives Considered

### Alternative A: App-wide API key embedded in the Levelwright binary

Ship one key for all users.

**Pros:** zero install friction; app "just works" on first launch.
**Cons:** **violates Steam Web API ToS.** Single-user rate-limit shared across the entire install base would quickly exhaust. Revocation of the single key bricks the product for everyone simultaneously. Key extraction from the binary is trivial.

**Why not chosen:** illegal per ToS and operationally fragile.

### Alternative B: Backend proxy holding the key

Run `api.levelwright.dev` which owns a key and authenticates Levelwright clients.

**Pros:** zero install friction for the user.
**Cons:**
- Requires running (and paying for) an always-on backend service — out of scope for a hobby-pace PoC
- Still exhausts a shared rate limit if the user base grows
- User's entire Steam library flows through the operator, creating a real privacy liability and potential legal exposure (GDPR data-processor obligations)
- Single point of failure: proxy down → everyone down
- Raises Valve's eyebrows (single key doing disproportionate traffic)

**Why not chosen:** adds cost, risk, and complexity for a marginal UX win the PoC doesn't need.

### Alternative C: OpenID + user-tokened OAuth flow

Use Steam Open ID (Valve's OAuth-lite) where the user signs in with their Steam credentials and Levelwright gets a limited token.

**Pros:** no key-pasting.
**Cons:** Steam OpenID gives you a Steam ID, not an API key; you still need the key to actually read library data. OpenID solves identity, not authorization.

**Why not chosen:** doesn't solve the actual problem.

### Alternative D: Skip Steam API; parse local Steam client files directly

Steam client stores owned games, playtime, etc., in local files (`~/.local/share/Steam/appcache/`, `config/loginusers.vdf`, etc.).

**Pros:** no API key at all.
**Cons:** file formats are undocumented and change between Steam updates; no access to achievements (those are server-side); no ProtonDB data. Cannot support users who use multiple accounts or family-sharing scenarios cleanly.

**Why not chosen:** brittle and incomplete. Might revisit as a *fallback* when the API key isn't set, but not as the primary path.

## References

- Steam Web API Terms of Use: https://steamcommunity.com/dev/apiterms
- Steam Web API key registration: https://steamcommunity.com/dev/apikey
- Steamworks Web API overview: https://partner.steamgames.com/doc/webapi_overview
- `DESIGN.md` §V.1 (levelwright-steam plugin), §XI (distribution strategy — ToS constraints)
- PRD §3.2 FR-2.6 (API key handling requirement)
- Related: ADR-0002 (steam plugin), ADR-0004 (Decky frontend hosts setup UI)
