# ADR-0006: Memory Strategy — Hermes Built-ins + Honcho Deferred

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

Levelwright needs persistent memory across sessions for features like:

- "What should I play?" — needs to know what you've recommended before, what you liked, your preferred genres / session lengths
- Hardware profile — your Deck's model, storage setup, accessories
- Play session history — when, how long, battery efficiency, thermals
- User communication preferences

Hermes-Agent (ADR-0001) ships with a layered memory system:

| Layer | Size | Purpose |
|---|---|---|
| `MEMORY.md` | 2,200 chars | Always-in-context structured summary |
| `USER.md` | 1,375 chars | Always-in-context user identity and style |
| Session storage (SQLite + FTS5) | Unbounded | Full conversation history, full-text searchable |
| Honcho (optional, external) | Unbounded | Dialectic user model; cross-session deep memory |

Honcho is a separate project (also by Nous Research / Plastic Labs) that runs as an external service and implements "theory-of-mind"-style user modeling. It is optional and off by default in Hermes.

## Decision

**Use Hermes built-in memory layers (MEMORY.md + USER.md + SQLite session storage) for the PoC. Do not integrate Honcho in v0.1.0. Design so Honcho can be added later without migration.**

Specifically:

- `MEMORY.md` tracks: player profile (preferred genres, session-length habits, hardware), running preferences (default TDP cap, FSR preferences), and sticky context the agent needs every session
- `USER.md` tracks: handle, communication style, accessibility preferences
- Session SQLite retains full chat transcripts; the agent's `search_sessions` tool can recall prior conversations when relevant
- Per-game performance profiles and play session analytics (Tier 2 features, out of v0.1.0 scope per PRD §5.2) will be structured JSON under `~/.levelwright/profiles/` rather than stuffed into MEMORY.md
- Honcho integration is **revisited at v0.2 or later** based on concrete pain points ("MEMORY.md is too small for what we need to remember")

## Consequences

### Positive

- **Zero new infrastructure** — memory "just works" once Hermes is installed
- **Zero new runtime cost** — no second service, no network call
- **No cloud dependency** — all memory stays on-device, matching PoC privacy posture
- **Deferring Honcho matches YAGNI** — we do not yet know what gaming memory needs we cannot meet with the built-ins

### Negative

- **MEMORY.md is small** — 2,200 characters is tight once you list genres, hardware, and preferences. We will hit the ceiling eventually.
- **No dialectic user modeling** — the agent won't build a rich theory-of-mind about the user automatically; it only remembers what we explicitly write
- **Per-game profiles handled outside Hermes memory** — adds a small ad-hoc storage layer (flat JSON files) that Hermes's memory tools don't see natively

### Neutral

- When we do integrate Honcho later, existing MEMORY.md content can be seeded into Honcho's initial representation — no data migration required
- `~/.levelwright/profiles/` schema is pre-1.0 internal; can change freely

## Alternatives Considered

### Alternative A: Honcho from day one

Run Honcho as a local service and put all gaming memory through it.

**Pros:** richer user modeling; scales beyond 2,200 chars natively.
**Cons:** adds an external dependency (Honcho service) to the install UX for the PoC; configuration overhead; unclear what gaming-specific value we'd extract before we know the product's memory needs.

**Why not chosen:** the cost adds up before any observed benefit at MVP scope. Revisit when MEMORY.md hits its limit or when a real use case demands dialectic modeling.

### Alternative B: Roll our own SQLite schema for gaming memory

Ignore Hermes memory layers and store everything in a custom Levelwright database.

**Pros:** full control over schema.
**Cons:** duplicates work Hermes already does; agent loses the automatic "put MEMORY.md in every prompt" behavior; we now maintain two memory systems.

**Why not chosen:** it throws away value Hermes gives for free.

### Alternative C: Hybrid — Hermes memory for conversational context, Honcho for persistent gaming-behavior model only

Scope Honcho narrowly to gaming-behavior user modeling and use Hermes built-ins for everything else.

**Pros:** targeted use of Honcho where it shines.
**Cons:** still adds Honcho install/config to the PoC; the "sweet spot" for this split isn't obvious until we've lived with the product.

**Why not chosen:** worth exploring post-v0.1.0, not before.

## References

- `DESIGN.md` §V.4 (Memory Strategy)
- `DESIGN.md` §VII (Hermes key facts — memory layers)
- Honcho: https://github.com/NousResearch/hermes-agent (Honcho integration docs linked)
- PRD §3.2 FR-3 (recommendation engine inputs)
- Related: ADR-0001 (Hermes as base)
