# ADR-0005: Local Terminal Backend on Steam Deck

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

Hermes-Agent (ADR-0001) supports six terminal/execution backends for running tool code:

| Backend | How it works | Typical overhead |
|---|---|---|
| `local` | Runs in the same process / host | Minimal |
| `docker` | Containerized per-session | Container runtime + image |
| `ssh` | Remote host via SSH | Network latency |
| `singularity` | Singularity/Apptainer container | HPC-style isolation |
| `modal` | Modal.com cloud execution | Network + cloud billing |
| `daytona` | Daytona sandbox | Cloud dev env |

The Steam Deck is a constrained device (16GB RAM, 6W–15W TDP budget, integrated GPU sharing RAM with the CPU) where a game can easily consume 10–12GB RAM. Every megabyte and every percent of CPU that Levelwright burns *while a game is running* is a megabyte/percent that the game doesn't get.

PRD NFR targets:

- <150MB RAM idle
- <2% CPU averaged over 5-minute windows
- ≤1% frame-pacing regression

## Decision

**Configure Hermes-Agent to use the `local` terminal backend on the Steam Deck. No Docker, no remote execution.**

Specifically:

- Hermes is installed on the Deck's root filesystem (via the official install script, per `DESIGN.md` §VII)
- The gateway runs as a user systemd service, unprivileged
- Tool execution happens in the same Python process as Hermes itself — no container, no subprocess-per-call

## Consequences

### Positive

- **Minimum possible overhead** — no container runtime, no network hop, no second Python interpreter
- **Trivial install** — `curl | bash` per Hermes docs; no Docker Desktop / Podman / containerd requirement on the Deck
- **Fast tool dispatch** — zero setup latency per tool call. Critical for the PRD's sub-5-second response target on recommendation queries
- **Works offline** — no cloud dependency; user's data never leaves the device unless they opted into a cloud LLM backend (ADR-0009)

### Negative

- **Less isolation between tools and agent process** — a buggy tool can crash the Hermes process. Mitigated by: (a) our tools are first-party code we control, (b) Hermes has internal try/except boundaries, (c) systemd restarts the service on crash.
- **No multi-tenant story** — `local` is fine for one user on their Deck, would not work for a hypothetical multi-user deployment. Acceptable — PoC is single-user on-device.
- **Security posture relies on unprivileged systemd user unit** — tools cannot escalate on their own, but elevated tools (TDP/fan control, ADR-0007) will require separate polkit/sudoers configuration.

### Neutral

- Decision is per-platform; Docker backend could still be used in a hypothetical cloud deployment (not planned)

## Alternatives Considered

### Alternative A: Docker backend

Run Hermes tools inside a container per session.

**Pros:** stronger isolation; reproducible environment; container image can pin every dependency.
**Cons:** Docker Desktop / Podman consumes significant RAM *idle*; image pulls are slow over home internet; subprocess-per-tool-call adds 100ms+ startup overhead; complicates sysfs access (ADR-0003's adapter would need `--privileged` flag or host bind mounts, defeating isolation).

**Why not chosen:** the isolation benefit does not justify the performance and install-UX cost on a 16GB handheld.

### Alternative B: SSH to the Deck from a companion machine

Run Hermes elsewhere (a home server, developer laptop) and SSH into the Deck for hardware reads.

**Pros:** heavy lifting off-device.
**Cons:** requires always-on second machine; introduces network latency; defeats the point of a device-local assistant; means the Deck must be online and reachable for every query.

**Why not chosen:** product-concept mismatch. The assistant should *be* on the Deck.

### Alternative C: Modal / Daytona cloud backend

Run tools in cloud-hosted sandboxes.

**Pros:** maximum isolation; no local compute.
**Cons:** cloud bills; requires internet; latency; privacy implications (user's Steam library and hardware data leaves the device); incompatible with the MVP privacy posture (PRD §3.3 NFR).

**Why not chosen:** every downside.

## References

- `DESIGN.md` §III (Why Hermes-Agent — Terminal backends row) and §VII (Hermes key facts)
- PRD §3.3 Non-Functional Requirements (Performance)
- Hermes terminal backends docs: https://github.com/NousResearch/hermes-agent
- Related: ADR-0001 (Hermes as base), ADR-0007 (elevated tools need separate privilege path)
