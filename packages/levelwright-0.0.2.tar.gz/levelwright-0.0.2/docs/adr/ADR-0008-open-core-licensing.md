# ADR-0008: Open-Core Licensing — MIT + Contributor License Agreement

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

`DESIGN.md` §XI commits to an open-core distribution strategy:

- **Core** (Hermes plugins, Decky plugin, MCP servers) ships under a permissive OSS license
- **Commercial desktop app** (Phase B2) is proprietary, built on top of the open core
- The core must accept outside contributions while keeping the commercial path viable

Two separable decisions are embedded here:

1. **Which OSS license?** — The permissive-vs-copyleft choice affects commercial path viability
2. **Contributor License Agreement or not?** — Without a CLA, contributed code is licensed only under the OSS license; the project cannot relicense that code into a proprietary offering. With a CLA, contributors grant the project a license broad enough to support the commercial path.

Hermes-Agent (our base runtime per ADR-0001) is MIT-licensed, so anything we pick must be compatible with MIT.

## Decision

**License: MIT. Contributor model: CLA signed via a GitHub Action on every pull request.**

Specifics:

- All Levelwright source code, configs, and documentation in the public repo ship under the MIT license
- `LICENSE` at repo root is the [SPDX MIT text](https://spdx.org/licenses/MIT.html)
- A `CLA.md` at repo root defines the contributor grant, modeled on the [Apache Individual CLA](https://www.apache.org/licenses/icla.pdf) and the [Sentry CLA](https://github.com/getsentry/sentry/blob/master/cla.md) for individual and corporate contributors
- A [CLA Assistant](https://cla-assistant.io/) GitHub App (or equivalent) blocks PR merge until all authors have signed
- The CLA grants the project owner a broad license to use the contribution under any license, including commercial — which enables Phase B2 without rewriting contributions

## Consequences

### Positive

- **Maximum permissive reuse** — MIT is the least-friction OSS license; integrators, packagers (AUR, Flathub), and corporate users can include Levelwright without lawyer-triggering clauses
- **Matches Hermes-Agent's license** — zero compatibility risk
- **Commercial path B2 preserved** — with CLAs in place, the project owner can produce a proprietary desktop app that includes contributed code
- **Clear to contributors** — CLA is a single, signed-once grant; not per-commit friction after first contribution

### Negative

- **CLA friction** — a one-time-per-contributor step that filters out casual drive-by contributions. Some contributors have ideological objections to CLAs (preferring the Developer Certificate of Origin model).
- **MIT does not require derivatives to stay open** — a Steam-store proprietary fork by a third party is legally possible. Mitigated by: trademark on the name (post-PoC), brand reputation, the community's preference for the upstream.
- **Dual-license dynamics** — once Phase B ships, the commercial product contains code not every contributor realizes they enabled. CLA language must make this explicit.

### Neutral

- Third-party dependencies retain their own licenses; `THIRD_PARTY_LICENSES.md` is generated at build time
- The CLA is revisable by the project owner for future contributors; existing contributors' grants remain per the version they signed

## Alternatives Considered

### Alternative A: Apache 2.0 + CLA

Also permissive; includes explicit patent grant and contributor-patent-retaliation clause.

**Pros:** slightly better patent story; still permissive enough for commercial distribution.
**Cons:** marginally more complex license text; differs from Hermes-Agent's MIT. No concrete advantage at PoC scope.

**Why not chosen:** MIT matches Hermes and is simpler. We accept the marginally weaker patent story given PoC scope and no known patent exposure.

### Alternative B: MIT, no CLA (DCO only)

Use the Developer Certificate of Origin (sign-off in commit messages) instead of a CLA.

**Pros:** less friction; aligned with Linux Foundation norms; some contributors prefer it.
**Cons:** DCO only asserts the contributor has the right to contribute under the license — it does *not* grant the project the right to relicense. Under MIT without CLA, commercial relicensing is technically possible for the owner's own code but contributed code would be stuck under MIT. This is survivable (the commercial app could just be MIT too), but it removes flexibility — a future SaaS offering, private deployment, or closed-source extension could hit license boundaries.

**Why not chosen:** optionality on the commercial path is worth the CLA friction at PoC stage. The decision is reversible: we can drop the CLA later and lose only forward flexibility, not existing rights (existing CLA grants persist).

### Alternative C: GPLv3 / AGPLv3

Copyleft; derivatives must open-source.

**Pros:** strongest protection against proprietary forks; forces a hypothetical competitor to open their derived work.
**Cons:** blocks our *own* commercial path — we could not ship a proprietary desktop app that links this code. Also incompatible with Hermes-Agent (MIT code importable into GPL, but the reverse isn't clean); and with most corporate deployment policies.

**Why not chosen:** directly defeats Phase B2 of the distribution strategy.

### Alternative D: Business Source License (BSL)

Source-available; non-production use free; relicenses to Apache 2.0 after N years.

**Pros:** prevents competitors from hosting as a commercial service.
**Cons:** not a real open-source license (fails OSI definition); repels OSS community contributors; overkill for a handheld gaming assistant with no SaaS component.

**Why not chosen:** community cost outweighs protection we don't need.

## References

- MIT license: https://spdx.org/licenses/MIT.html
- Apache ICLA template: https://www.apache.org/licenses/icla.pdf
- Sentry CLA (a well-worn individual + corporate model): https://github.com/getsentry/sentry/blob/master/cla.md
- CLA Assistant: https://cla-assistant.io/
- `DESIGN.md` §XI — Licensing (Open-Core Model) section
- Related: ADR-0001 (Hermes is MIT → compatible), ADR-0011 (brand separation allows commercial product to layer on top)
