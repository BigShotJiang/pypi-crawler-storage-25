# ADR-0003: `HardwareAdapter` Abstraction for Handheld Portability

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

`DESIGN.md` §XI makes explicit that Levelwright's commercial path (Phase B2 — Steam store desktop companion) targets the *full handheld market* — Steam Deck, ROG Ally, Legion Go, MSI Claw, and future devices — not Deck exclusively. This is a strategic decision: the cross-handheld TAM is several times larger than the Deck-only market and is the primary reason the commercial case closes.

But every handheld exposes hardware data differently:

| Device | CPU temp | Battery | TDP control |
|---|---|---|---|
| Steam Deck (Linux) | `/sys/class/hwmon/hwmon4/temp1_input` | `/sys/class/power_supply/BAT1/capacity` | `ryzenadj` CLI |
| ROG Ally (Windows) | WMI / LibreHardwareMonitor | WMI | Asus Armoury Crate SDK |
| Legion Go (Windows) | WMI / LibreHardwareMonitor | WMI | Lenovo Legion Space API |
| MSI Claw (Windows) | WMI / LibreHardwareMonitor | WMI | MSI Center SDK |

If `levelwright-system` tools read directly from `/sys/class/hwmon/...`, porting to ROG Ally means rewriting every tool. Every feature built now that hardcodes Deck paths becomes a future porting debt.

This is precisely the risk flagged in `DESIGN.md` §III Architectural Principle #1.

## Decision

**Introduce a `HardwareAdapter` interface that abstracts hardware access. Ship `SteamDeckAdapter` as the only implementation in v0.1.0. Future handhelds each get their own adapter.**

Interface sketch (Python, illustrative):

```python
from typing import Protocol
from dataclasses import dataclass

@dataclass
class Temps:
    cpu_c: float
    gpu_c: float | None

@dataclass
class Battery:
    percent: float
    charging: bool
    minutes_remaining: int | None

@dataclass
class Performance:
    tdp_w: float | None
    cpu_mhz: int | None
    gpu_mhz: int | None
    fan_rpm: int | None

class HardwareAdapter(Protocol):
    name: str                            # "steam-deck", "rog-ally", ...
    def read_temps(self) -> Temps: ...
    def read_battery(self) -> Battery: ...
    def read_performance(self) -> Performance: ...
    def read_storage(self) -> list[StoragePartition]: ...

    # Elevated operations — may raise PermissionError
    def set_tdp(self, watts: int) -> None: ...
    def set_fan_curve(self, curve: FanCurve) -> None: ...
```

Adapter selection:

- At plugin load time, `levelwright-system` detects the device via `/sys/class/dmi/id/product_name` on Linux or WMI on Windows
- Falls back to an explicit `LEVELWRIGHT_ADAPTER=steam-deck` environment variable
- Exposes a `MockAdapter` for unit tests that returns fixed or recorded values

All tools (FR-1.1 through FR-1.5 in the PRD) call the adapter; none reach into sysfs directly.

## Consequences

### Positive

- **New handheld = new adapter, not rewrite.** Adding ROG Ally support is implementing one class, not forking the plugin.
- **Testable:** `MockAdapter` gives unit tests deterministic inputs without touching real hardware.
- **CI on non-Deck machines works:** developers without a Steam Deck can still run the full test suite against the mock.
- **Honest error surface:** methods that require elevated privileges (`set_tdp`, `set_fan_curve`) declare their privilege tier (ADR-0007) and raise `PermissionError` explicitly when the adapter lacks rights — rather than silently failing in sysfs.

### Negative

- **Indirection tax:** every hardware read is one extra method call. Performance impact is negligible but code reads with one more layer.
- **Over-design risk at PoC stage:** we are building the interface with zero non-Deck adapters to validate its shape. The interface may need breaking changes as real adapters materialize. Mitigation: interface is internal (not a public API contract), `levelwright-system` is a pre-1.0 package, and breaking changes are cheap until v1.0.

### Neutral

- Adds ~150 lines of adapter + mock + tests to v0.1.0. Well within the PRD scope budget.

## Alternatives Considered

### Alternative A: Deck-only, rewrite later

Read sysfs directly; add an adapter interface only when the second handheld ships.

**Pros:** minimal code now.
**Cons:** every tool written in v0.1.0 must be touched when we port, which means more total work and more churn risk. Also makes testing without real hardware painful.

**Why not chosen:** the interface cost now is less than the retrofit cost later, and retrofit has compounding risk (every new tool added before adapter extraction adds more rewrite).

### Alternative B: Runtime `if PLATFORM == ...` conditionals inside each tool

Branch on platform inside each tool's body.

**Pros:** no new types.
**Cons:** branches multiply per tool per platform (N*M complexity); no shared testability; violates separation of concerns.

**Why not chosen:** the cleaner abstraction is strictly better along every axis.

### Alternative C: External `psutil`-style library

Use an existing cross-platform Python hardware library.

**Pros:** battle-tested code we don't maintain.
**Cons:** `psutil` doesn't expose TDP or fan controls; handheld-specific SDKs (Armoury Crate, Legion Space) aren't wrapped anywhere comprehensive. We would still need per-device code — just wrapped in an inconsistent layer we don't control.

**Why not chosen:** no existing library covers the capability matrix we actually need.

## References

- `DESIGN.md` §III Architectural Principle #1 ("Plugins are handheld-agnostic")
- `DESIGN.md` §VI (Steam Deck Technical Capability Map)
- PRD §3.2 FR-1.5 (hardware abstraction requirement)
- Related: ADR-0002 (plugin split), ADR-0007 (privilege tiers)
