# ADR-0002: Two-Plugin Split — `levelwright-system` and `levelwright-steam`

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

Levelwright's MVP scope (PRD §3.2) defines two distinct tool families:

- **Hardware telemetry tools** (FR-1): read CPU/GPU temps, battery, TDP, storage from Linux sysfs. No network. No external accounts. Must work on any Linux handheld via the `HardwareAdapter` interface (ADR-0003).
- **Steam integration tools** (FR-2): call Steam Web API and ProtonDB over HTTPS. Requires a user-provided API key (ADR-0010). Steam Deck specific only by coincidence — same code works on any device with a Steam account.

These two families have different:

- Dependency graphs (system has no network; steam has `httpx` + Steam API client)
- Failure modes (system: sysfs read errors; steam: API rate limits, auth failures)
- Test strategies (system: mock adapter + recorded sysfs files; steam: recorded HTTP fixtures)
- Privilege requirements (system: some tools `elevated` per ADR-0007; steam: all `public`)
- Relevance on future platforms (system: must be rewritten per handheld; steam: works unchanged on any platform)

Hermes-Agent supports arbitrary plugin granularity: one big plugin, many small plugins, or anything in between (see §VII of `DESIGN.md`).

## Decision

**Ship two separate Hermes plugins: `levelwright-system` and `levelwright-steam`.**

Each plugin is:

- Its own directory under `plugins/` in the mono-repo
- Its own `pyproject.toml` and test suite
- Its own `plugin.yaml` manifest registered with Hermes
- Published as a separately-installable unit (a user could install only one)

A third shared package `levelwright-core` may emerge for cross-cutting concerns (shared types, logging config, the `HardwareAdapter` interface), but only if duplication proves costly — no pre-emptive shared package.

## Consequences

### Positive

- **Testable in isolation:** system plugin tests don't need Steam API fixtures, steam plugin tests don't need sysfs mocks
- **Selective install:** a user on a non-Steam handheld (or without a Steam account) can install `levelwright-system` alone and get value
- **Clearer failure boundaries:** Steam API outage does not degrade hardware monitoring
- **Privilege isolation:** elevated tools (potential future TDP/fan control) are all in `levelwright-system`, making sandboxed-build exclusion trivial per ADR-0007
- **Portability:** `levelwright-steam` has no Deck-specific code, so it is reusable verbatim on any future handheld

### Negative

- Two plugins to maintain, document, version, and release instead of one
- Cross-plugin features (like "What should I play?" which needs BOTH families) must orchestrate at the agent layer, not in a single plugin — this is handled natively by Hermes's tool-dispatch model, so the cost is minimal
- Users need to know they should install both for the full experience; install docs must make this explicit

### Neutral

- Repo structure (mono-repo at `github.com/levelwright/levelwright`) stays simple; each plugin is a sibling directory
- CLA workflow (ADR-0008) applies to both plugins identically

## Alternatives Considered

### Alternative A: Single monolithic `levelwright` plugin

One Hermes plugin containing all tools.

**Pros:** one install step for users; simpler CI.
**Cons:** sysfs access and HTTP requests share a test and dependency graph for no reason; `levelwright-steam` cannot be reused cleanly on future handhelds that don't ship `levelwright-system`; privilege separation (ADR-0007) requires file-level tagging rather than plugin-level scoping.

**Why not chosen:** the forced coupling creates more friction than one install step saves.

### Alternative B: Many small plugins (one per tool or tool family)

Five or more plugins: `levelwright-hwmon`, `levelwright-battery`, `levelwright-steam-library`, `levelwright-protondb`, etc.

**Pros:** maximum modularity.
**Cons:** every plugin has boilerplate (`plugin.yaml`, tests, release metadata) that multiplies. Users have to remember N install steps. Plugin discovery UX in Decky degrades.

**Why not chosen:** modularity tax not justified at PoC scope. Revisit if a family grows beyond ~10 tools.

### Alternative C: One plugin + one MCP server

Put system tools in a Hermes plugin and Steam tools behind an MCP server.

**Pros:** MCP is fashionable; would let Steam tools be reused by any MCP-aware client (Claude Desktop, etc.) outside Hermes.
**Cons:** introduces a second runtime (MCP server process) for no PoC-stage benefit; Hermes plugins can already be exposed via MCP later if wanted.

**Why not chosen:** premature abstraction. MCP server can wrap `levelwright-steam` post-PoC if demand exists.

## References

- `DESIGN.md` §V.1 (`levelwright-steam` spec) and §V.2 (`levelwright-system` spec)
- PRD §3.2 (functional requirements FR-1, FR-2)
- Related: ADR-0001 (Hermes as base), ADR-0003 (HardwareAdapter), ADR-0007 (privilege tiers)
