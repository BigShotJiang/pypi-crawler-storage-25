# Architecture Decision Records

This directory contains ADRs for the Levelwright project, following the [Nygard format](https://cognitect.com/blog/2011/11/15/documenting-architecture-decisions).

## Index

| # | Title | Status |
|---|---|---|
| [0001](ADR-0001-hermes-agent-as-base-framework.md) | Hermes-Agent as Base Framework | Accepted |
| [0002](ADR-0002-two-plugin-split.md) | Two-Plugin Split — `levelwright-system` and `levelwright-steam` | Accepted |
| [0003](ADR-0003-hardware-adapter-abstraction.md) | `HardwareAdapter` Abstraction for Handheld Portability | Accepted |
| [0004](ADR-0004-decky-loader-as-first-frontend.md) | Decky Loader as First Frontend | Accepted |
| [0005](ADR-0005-local-terminal-backend.md) | Local Terminal Backend on Steam Deck | Accepted |
| [0006](ADR-0006-memory-strategy.md) | Memory Strategy — Hermes Built-ins + Honcho Deferred | Accepted |
| [0007](ADR-0007-privilege-tier-tagging.md) | Privilege-Tier Tagging on Tools | Accepted |
| [0008](ADR-0008-open-core-licensing.md) | Open-Core Licensing — MIT + Contributor License Agreement | Accepted |
| [0009](ADR-0009-llm-backend-user-choice.md) | LLM Backend — User Choice at Install Time | Accepted |
| [0010](ADR-0010-steam-web-api-key-user-provided.md) | Steam Web API Key — User-Provided | Accepted |
| [0011](ADR-0011-brand-levelwright-commercial-deferred.md) | Brand — Levelwright for PoC; Commercial Name Deferred | Accepted |

## Process

- **Proposing a new ADR:** copy the Nygard sections from an existing file. Use the next sequential number. Status starts at `Proposed`.
- **Changing a decision:** create a new ADR that `Supersedes` the old one. Do not edit accepted ADRs.
- **Status values:** `Proposed`, `Accepted`, `Superseded by ADR-NNNN`, `Deprecated`, `Rejected`.
- **Scope:** record decisions that are non-obvious, costly to reverse, or load-bearing for other decisions. Skip for trivial choices.
