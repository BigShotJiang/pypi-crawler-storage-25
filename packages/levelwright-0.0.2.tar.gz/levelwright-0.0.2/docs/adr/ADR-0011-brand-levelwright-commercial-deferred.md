# ADR-0011: Brand — Levelwright for PoC; Commercial Name Deferred

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none (original working title "GameDweeb" was never formalized in an ADR)

---

## Context

The project began April 19, 2026 under the working title **GameDweeb** — a direct tribute to TechDweeb's PocketDweeb April Fools concept (`DESIGN.md` §I). During the design phase, two problems with that name surfaced:

1. **"Dweeb" blocks the commercial path.** `DESIGN.md` §XI identifies selling a desktop companion app on Steam (Path B2) as a strategic option. Valve's marketing and storefront standards will reasonably reject a paid product named "GameDweeb." Even if accepted, the word's connotation caps the brand's professional ceiling.
2. **Renaming is cheaper at PoC stage than post-launch.** Every day of public use under a name is a day of SEO, community recognition, URL links, and screenshot captures that a future rebrand would have to migrate. The cost curve is steep and increasing.

A rename was explored collaboratively on 2026-04-19. The brief:

- Preserve PocketDweeb lineage as an origin story, not as the product name
- Fuse gaming/handheld culture with a helper/companion connotation
- Must be clean on GitHub, PyPI, primary domains, and against USPTO trademark registrations in classes 009 (software) and 028 (games)

Several candidates were rejected for various combinations of: direct semantic collision (Familiar = an AI-screen-watching tool; Cairn = an AI agent framework; Questkeeper = a Steam library wishlist tool), active trademark (Gamewright Games, a 30-year tabletop publisher), or crowded namespaces (Squire, Wayfinder, Vanguard, Sentinel).

## Decision

**The PoC ships as `Levelwright`. The commercial product's brand is deferred until Phase B (commercial distribution).**

Name rationale:

- **"Wright"** is a craftsperson suffix — playwright, shipwright, wheelwright, millwright, cartwright. Encodes "one who builds / crafts."
- **"Level"** is universal gaming vocabulary — game levels, level up, leveling, level design.
- Together: *one who helps you craft your gaming experience, one who helps you level up.*
- Single word, two syllables, unambiguously gaming-adjacent, commercially viable.

Availability verified 2026-04-19:

- `github.com/levelwright` — unregistered
- `pip install levelwright` — 404 on PyPI
- `levelwright.com` — available
- `levelwright.dev` — available
- `levelwright.gg` — **taken** (initial ECONNREFUSED misread as unregistered; user confirmed registered on 2026-04-19). Accepted: `.com` + `.dev` cover primary branding needs, and `.gg` ownership is not in the AI-assistant / handheld-gaming space based on available evidence.
- USPTO trademark search — no hits in classes 009 or 028

Commercial brand decision:

- Defer until the commercial path is selected (Path B1 = pitch Valve; Path B2 = Steam store)
- If Path B1 is chosen, the commercial brand may be irrelevant (Valve would brand the feature themselves)
- If Path B2 is chosen, either reuse Levelwright as the commercial brand, or layer a new store-facing brand over the Levelwright engine
- Tracked as PRD open question OQ-4

Implementation actions already taken:

- `DESIGN.md` updated — all "GameDweeb" / "gamedweeb" references replaced with "Levelwright" / "levelwright"
- `DESIGN.md` §IX rewritten to document this decision
- Plugin names changed from `gamedweeb-system` / `gamedweeb-steam` to `levelwright-system` / `levelwright-steam`
- Repo target renamed from `gamedweeb/` to `levelwright/` in all planning

Actions remaining:

- Register `github.com/levelwright` (org) — owner action
- Claim `levelwright` on PyPI with a placeholder release — owner action
- Register `levelwright.com` and `levelwright.dev` domains — owner action (`.gg` is taken)
- Directory `/mnt/data/Dev/projects/gamedweeb/` rename — owner may defer to a convenient checkpoint

## Consequences

### Positive

- **Clean commercial path.** No forced rebrand during or after a Steam submission.
- **Clean trademark footprint.** No active USPTO registration in adjacent classes at decision time.
- **Brandable for long-term use.** Single word, pronounceable, evocative, not a joke that ages poorly.
- **Clean namespace.** All four reserved properties (GitHub, PyPI, .com, .dev) are currently claimable simultaneously — rare.

### Negative

- **Loses direct PocketDweeb tribute in the product name.** The homage survives in `DESIGN.md` §I as the origin story but is no longer on the wordmark. This is an intentional trade.
- **Migration cost.** Minor at PoC stage (zero code written yet), nontrivial psychologically ("I liked GameDweeb"). Sunk cost is near zero; forward cost is what matters.
- **Namespace squatting risk.** Until the owner registers GitHub/PyPI/domains, a bad actor could squat. **This is a time-sensitive action item.**

### Neutral

- PocketDweeb still credited in the origin story and README
- Commercial brand remains undecided — deferring is a choice, not an oversight

## Alternatives Considered

### Alternative A: Keep `GameDweeb`

**Pros:** preserves the homage directly; no migration cost; no new branding exercise.
**Cons:** blocks Phase B2 commercial path unless rebranded later; caps professional perception; increases sunk-cost pain of any future rename.

**Why not chosen:** trades a small homage win now for a large commercial-path tax later. The homage survives through §I.

### Alternative B: Pick the commercial name now (e.g., a brandable abstract like `Hench`)

Choose one name that works for both PoC and commercial.

**Pros:** one brand, one identity, no future rename.
**Cons:** premature — the right name for a polished commercial product depends on the commercial product's positioning, which depends on which commercial path (B1/B2) is chosen, which depends on PoC data. Picking now is a guess. Also, committing a casual name (like `Hench`) to a future paid product may cap its ceiling too.

**Why not chosen:** the commercial brand decision is better made with PoC telemetry in hand.

### Alternative C: Use Levelwright for PoC and pre-reserve a second commercial brand now

Register a second set of namespaces for a speculative commercial brand (e.g., `pockethero.ai`, `deckcopilot.com`) to hedge.

**Pros:** preserves future optionality at low cost.
**Cons:** encourages branding decisions before they're ready; risks emotional lock-in to a speculative name; registrations decay without use.

**Why not chosen:** YAGNI. Revisit in Phase B planning when the commercial brand is actually being chosen.

## References

- Name research sessions — GitHub namespace searches and trademark checks conducted 2026-04-19 via `mcp__github__search_repositories` and WebSearch
- `DESIGN.md` §IX (Project Naming — rewritten to document this decision)
- `DESIGN.md` §XI (Distribution Strategy — Branding subsection)
- PRD §2.1 (Background), PRD OQ-4 (commercial brand open question)
- PocketDweeb concept video: https://www.youtube.com/watch?v=JLG4d5Opo14
- Related: ADR-0008 (open-core licensing — brand independence supports the dual-license story)
