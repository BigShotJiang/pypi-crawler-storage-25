# ADR-0001: Hermes-Agent as Base Framework

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

Levelwright needs an AI-agent runtime that provides at minimum:

- A plugin system that lets us add gaming-specific tools without forking the core
- A memory system for cross-session gaming context
- MCP client support for external service integration (Steam, ProtonDB, future services)
- A headless gateway that runs as a background service during gameplay
- An OpenAI-compatible HTTP API so multiple frontends (Decky, Telegram, CLI, future desktop app) can share the same backend
- A Python-friendly runtime light enough for the Steam Deck's 16GB RAM while a AAA game is also running

Building this from scratch as part of the PoC would balloon scope by roughly an order of magnitude and delay every user-visible feature. Using a heavy runtime (Docker-required frameworks, Node + Electron stacks) would compete with games for RAM and CPU.

Constraints at decision time:

- Solo developer, 3-month hobby-pace timeline (see PRD §6.1)
- Must run alongside games without measurable frame pacing regression (PRD NFR)
- Must be open source to match the project's license strategy (ADR-0008)
- The owner has prior Python experience; Node/TypeScript is a secondary skill

## Decision

**Use Hermes-Agent (https://github.com/NousResearch/hermes-agent, MIT-licensed, Python 3.11, v0.9.0 or later) as the runtime foundation for Levelwright.**

Specifically:

- Levelwright's tools ship as **Hermes plugins** (see ADR-0002 for the split)
- The Hermes **gateway** runs as a systemd-managed background service on the Steam Deck
- The Hermes **OpenAI-compatible API** at `localhost:8642/v1` is the contract between frontends and backend
- The Hermes **MEMORY.md / USER.md / SQLite session storage** are the PoC's memory layers (ADR-0006)
- The Hermes **local terminal backend** is the only backend we configure for the Deck (ADR-0005)

Hermes version is pinned in the install script; upgrades are deliberate, tested against the full tool suite before adoption.

## Consequences

### Positive

- Plugin system, memory, MCP, gateway, API server, cron, and terminal management are all solved problems — zero work to build
- Python 3.11 is well-supported on SteamOS via `pyenv` / uv; no Docker dependency
- OpenAI-compatible API means any frontend that speaks that protocol (including almost every LLM UI on the market) can talk to Levelwright
- Hermes has a learning loop and cross-session search out of the box — valuable for the "What should I play?" feature over time
- MIT license matches our intended license (ADR-0008); no license incompatibility

### Negative

- Dependency on an external project's roadmap and maintenance. If Nous Research deprecates Hermes-Agent, Levelwright is stranded.
- Hermes is relatively young (v0.9.0 at decision time); breaking changes between minor versions are plausible. We mitigate by pinning.
- Any bug in Hermes surfaces as a bug in Levelwright from the user's perspective — we inherit their support surface.

### Neutral

- Python 3.11 runtime requirement is a hard floor for all contributors
- Plugin discovery paths (`~/.hermes/plugins/`, pip entry_points) become installation-UX considerations

## Alternatives Considered

### Alternative A: OpenClaw

Node.js 24 runtime. Skills-based extension model. Plugin system is less mature; no MCP support outside skills. Memory system is session-scoped only. Port 18789 instead of standard OpenAI port. Node on the Deck is heavier than Python and would compete with the game for RAM.

**Why not chosen:** weaker plugin/memory/MCP story; heavier runtime for a handheld.

### Alternative B: NanoClaw

Docker-only deployment. No headless gateway on bare metal. Limited plugin system.

**Why not chosen:** Docker on a gaming handheld is a non-starter for performance and install UX reasons.

### Alternative C: Build from scratch (FastAPI + custom agent loop)

Full control, zero dependencies outside the standard Python ecosystem. Would give us a purpose-built runtime with no bloat.

**Why not chosen:** estimated 4-6 weeks of runtime infrastructure work before any gaming-specific feature could be built. Kills the 12-week PoC timeline (PRD §6.1) and adds risk of re-implementing bugs that Hermes has already solved.

### Alternative D: LangChain / LangGraph + custom API shim

Mature LLM-orchestration ecosystem. Plugin concept via tools/chains. Would provide LLM glue but not memory, gateway, API server, or cron — those would still need to be built.

**Why not chosen:** solves the smallest part of the problem. Hermes bundles more of what we need in a single MIT-licensed package.

## References

- Hermes-Agent: https://github.com/NousResearch/hermes-agent
- Hermes docs: https://hermes-agent.nousresearch.com/docs
- `DESIGN.md` §III — Why Hermes-Agent as Base (decision rationale table)
- Related: ADR-0002 (plugin split), ADR-0005 (local terminal backend), ADR-0006 (memory)
