# ADR-0004: Decky Loader as First Frontend

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

Levelwright's MVP needs a user interface reachable **inside Game Mode** on the Steam Deck. The whole point of asking "what's my battery?" or "what should I play?" is that the user is *playing* (or about to), not tabbed out to a desktop window.

The options for Game Mode UI on Steam Deck are narrow:

1. **Steam overlay** — official, but adding custom panels requires Valve-level integration (not available to third parties)
2. **Gamescope overlay** — possible but requires low-level Wayland compositor work and has no plugin story
3. **Decky Loader plugin** — homebrew-community plugin framework with an established ecosystem, React-based frontend, and stable Python backend
4. **Steam Input "chord → script" hacks** — extremely limited; shows nothing

Decky Loader is the dominant community solution and has been stable since 2022. It is what every noteworthy Game Mode enhancement (PowerTools, CSSLoader, AudioLoader, EmuDecky, etc.) is built on.

The cost of Decky: it requires Steam Deck **developer mode**, which in turn means:

- Cannot ship in the Steam store (see `DESIGN.md` §XI)
- User must opt in to a homebrew environment
- Cannot reach users who are uncomfortable with developer mode

None of these are blocking for the PoC — the PoC's audience (owner + Decky power users + public Decky Plugin Store release per PRD §2.2) already lives in that ecosystem.

## Decision

**Use Decky Loader as the first and only frontend for Levelwright v0.1.0.**

Specifically:

- Levelwright ships a Decky plugin (`decky-plugin/` in the mono-repo) built from the [EmuDeck plugin template](https://github.com/EmuDeck/decky-plugin-template) fork
- The Decky plugin **does not** contain gaming logic or agent reasoning — it is a thin frontend that calls the Hermes API at `http://127.0.0.1:8642/v1/chat/completions`
- The Decky plugin uses `@decky/api` for plugin-system integration (quick access menu, routes, notifications)
- Published to the Decky Plugin Store at milestone M6 (PRD §6.1)

Additional frontends (Telegram bot, web UI, desktop app) are possible post-PoC **without** modifying the plugins, because the Hermes API at port 8642 is the stable contract (Architectural Principle #2 from `DESIGN.md` §III).

## Consequences

### Positive

- **Game Mode integration out of the box** — Decky lives in Steam's quick access menu with no custom Wayland work
- **Community distribution channel ready** — the Decky Plugin Store is a real marketplace with thousands of users; critical for PRD success metric M2 (100+ installs)
- **React frontend ecosystem** — `@decky/api`, `decky-frontend-lib`, and established UI components accelerate development
- **No frontend logic coupling** — per Architectural Principle #2, all gaming logic stays in Hermes plugins; the Decky plugin is replaceable

### Negative

- **Locks PoC to Steam Deck + developer mode.** Users not on Deck (or on Deck without Decky) cannot run the PoC. This is *accepted* because §XI explicitly frames the PoC as Deck-first with the commercial product expanding later.
- **Decky is community-maintained; SteamOS updates occasionally break it** — though the community is responsive, we inherit that friction
- **Cannot ship to the Steam store as a Decky plugin** — by design (§XI Path B2 is the commercial path)

### Neutral

- Install UX requires Decky Loader first, then Levelwright — documented in the quickstart
- Decky provides minimal persistence for frontend state; actual state lives in Hermes memory layers (ADR-0006)

## Alternatives Considered

### Alternative A: Gamescope overlay (custom)

Build a Wayland compositor overlay that renders directly under Steam Deck's Gamescope layer.

**Pros:** no developer-mode requirement for users; could theoretically ship broader.
**Cons:** zero ecosystem; every feature (quick access menu integration, notifications, route system) must be built from scratch; compositor work is exceptionally difficult to debug on a handheld.

**Why not chosen:** ~6x the work for lesser UX at PoC scope.

### Alternative B: Desktop-mode-only Web UI

Ship only a web interface accessible from Desktop Mode. No Game Mode integration.

**Pros:** simplest frontend; no Decky dependency.
**Cons:** defeats the entire product concept. A user cannot ask "what's my battery?" *during* gameplay from Desktop Mode — they would have to exit the game.

**Why not chosen:** breaks the core use case.

### Alternative C: Telegram / Discord bot as primary frontend

Hermes already supports Telegram out of the box. User could control Levelwright by texting their phone.

**Pros:** zero Deck-side UI work; works remotely.
**Cons:** still doesn't solve the in-game overlay problem; requires phone at hand; most telemetry requests are less useful when not on the Deck itself.

**Why not chosen:** valid *additional* frontend (enabled post-PoC for free, since Hermes already supports it), but not a replacement for in-Game-Mode UI.

### Alternative D: Native Steam overlay integration

Would require cooperation from Valve.

**Why not chosen:** not available to third-party developers. This is, however, exactly what Path B1 (pitch to Valve) from §XI is for — if the PoC succeeds, absorbing Levelwright into the Steam overlay becomes Valve's decision.

## References

- Decky Loader: https://github.com/SteamDeckHomebrew/decky-loader
- Decky plugin template (EmuDeck fork): https://github.com/EmuDeck/decky-plugin-template
- Decky Plugin Dev docs: https://wiki.deckbrew.xyz/en/plugin-dev/getting-started
- `DESIGN.md` §V.5 (Decky UI layer) and §XI (distribution)
- PRD §3.2 FR-4 (Decky UI requirements)
- Related: ADR-0001 (Hermes as backend), ADR-0007 (privilege tiers → elevated tools hidden in future non-Decky frontends)
