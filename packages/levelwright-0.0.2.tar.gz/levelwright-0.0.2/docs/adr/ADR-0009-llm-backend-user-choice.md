# ADR-0009: LLM Backend — User Choice at Install Time

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

Levelwright uses an LLM to interpret user questions, orchestrate tool calls, and narrate responses. The PoC must pick where the LLM actually runs. The options cluster into three models, each with a distinct user experience:

| Model | Quality | Latency | Privacy | Cost | RAM on Deck |
|---|---|---|---|---|---|
| Cloud API (Anthropic Claude, OpenAI GPT, OpenRouter) | Excellent | 0.5–3s | Prompts leave device | Per-token billing | Near zero |
| Local via Ollama (Llama 3.x 8B, Qwen 2.5, etc.) | Good for 8B; weaker for tool use | 3–10s (first token slow) | Stays on device | Free | 5–10 GB while loaded |
| Hybrid with fallback | Mixed | Mixed | Mixed | Mixed | Mixed |

Constraints specific to the Steam Deck:

- 16 GB shared RAM (CPU + GPU). A AAA game can use 10–12 GB.
- A locally-hosted 8 B parameter model in 4-bit quantization needs ~5 GB RAM + VRAM pressure. Running it *while* a game runs is often infeasible.
- A cloud call can return while the user is still in a loading screen — local may not.

User preferences are not uniform:

- A privacy-conscious tinkerer will refuse cloud on principle
- A pragmatic gamer will happily pay $1/month of API costs for snappier answers
- A user without an API key and without the patience to set one up will want zero-config

Hermes-Agent (ADR-0001) supports both local and cloud backends via its OpenAI-compatible API client — both are already plumbed at the runtime level.

## Decision

**Support both local (Ollama) and cloud (Anthropic / OpenAI / OpenRouter) LLM backends. Ask the user at install time. Allow change at runtime.**

Install flow:

1. Levelwright installer asks: *"Do you want Levelwright to use a cloud AI (fast, needs an API key, minimal RAM) or a local AI (private, free, uses RAM)?"*
2. If cloud: ask for provider (Anthropic, OpenAI, OpenRouter, "other OpenAI-compatible") and API key. Recommend Claude Haiku 4.5 as default for best latency/quality/price.
3. If local: detect if Ollama is installed; install if not; pull a default small model (Qwen 2.5 7B or Llama 3.1 8B, final choice deferred per PRD OQ-1).
4. Store the choice in `~/.levelwright/config.toml`.

Runtime flow:

- Hermes `config.yaml` references Levelwright's config for the backend selection
- User can run `levelwright switch-llm` to change anytime; no reinstall needed
- A single `LLMBackend` interface wraps both — plugin tools never see backend-specific code (Architectural Principle #2 from `DESIGN.md` §III)

Plugin tools (`levelwright-system`, `levelwright-steam`) must work **identically** against either backend. If a tool's behavior depends on the LLM backend, that is a bug.

## Consequences

### Positive

- **Respects user values across the spectrum** — privacy-first users get local; convenience-first users get cloud
- **Acceptable performance on both paths** — cloud gives best-in-class latency; local gives free-forever and on-device privacy
- **No vendor lock-in** — OpenAI-compatible abstraction means switching providers (or running the user's own LLM server) is a config change, not a refactor
- **Matches Hermes-Agent's own model** — zero runtime work to support both

### Negative

- **Doubled test surface** — every feature must be validated against both backends because quality, tool-calling reliability, and latency differ
- **Doubled failure modes** — "it's slow" could mean network (cloud) or GPU pressure (local); diagnostics must distinguish
- **Install UX is one step more complex** — we add a choice and possibly a model download (local path can be multi-GB and slow over home internet)
- **Default-provider decision is its own trap** — picking Anthropic as default for cloud is an endorsement; picking Qwen 2.5 7B as default for local similarly. Tracked in PRD OQ-1.

### Neutral

- Config file under `~/.levelwright/config.toml` joins several others likely to accumulate there
- Switching backend invalidates cached prompts; no correctness impact, only recomputation

## Alternatives Considered

### Alternative A: Cloud-only

Ship with cloud backend only; require API key at install.

**Pros:** best default quality; simplest code; smallest RAM footprint; fastest latency.
**Cons:** excludes users without API keys (real user segment in gaming forums); forces data-leaves-device posture that some handheld users actively reject; incurs ongoing cost even for light usage.

**Why not chosen:** alienates a visible segment of the target audience. Fine default *within* cloud path, but not the only path.

### Alternative B: Local-only

Ship with Ollama required; no cloud option.

**Pros:** maximum privacy; zero running cost; zero API-key friction.
**Cons:** 8 B model on the Deck competes with games for RAM and often loses; first-token latency for Ollama cold-start is seconds; tool-call reliability of small local models is materially lower than Claude Haiku 4.5 / GPT-4o-mini. Worse product for most users.

**Why not chosen:** ships a worse default product to almost everyone.

### Alternative C: Hybrid auto-fallback (local primary, cloud fallback)

Always start local; if local fails / is too slow / runs out of RAM, fall back to cloud.

**Pros:** seems clever.
**Cons:** non-deterministic performance (hard for users to debug); requires BOTH paths to be configured; double the install friction; unclear where conversation history lives across fallbacks.

**Why not chosen:** the compound failure surface is worse than letting the user decide which model to use.

### Alternative D: Defer — ship local-only v0.1.0 and add cloud in v0.2

Half the work now, double the user base later.

**Pros:** fastest v0.1.0.
**Cons:** the cloud path is the *better default* for most users; shipping local-only for the public release means a bad first impression for the largest audience segment. Also, adding cloud later is a breaking change to install UX.

**Why not chosen:** worse value proposition for the broader Decky Plugin Store release at M6.

## References

- Ollama: https://ollama.ai/
- Anthropic API: https://docs.anthropic.com/
- OpenRouter (unified OpenAI-compatible gateway to many models): https://openrouter.ai/
- `DESIGN.md` §III Architectural Principle #2 (frontends swappable — extends to LLM backends)
- PRD §3.2 FR-5 (LLM backend), PRD OQ-1 (default cloud provider)
- Related: ADR-0001 (Hermes as base supports both)
