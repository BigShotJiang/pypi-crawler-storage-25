# ADR-0007: Privilege-Tier Tagging on Tools

**Status:** Accepted
**Date:** 2026-04-19
**Deciders:** Project owner
**Supersedes:** none

---

## Context

`DESIGN.md` §XI defines two commercial distribution paths for Levelwright beyond the PoC:

- **Path B1** — pitch Valve to absorb the project into SteamOS (same privileges as the PoC, homebrew)
- **Path B2** — sell a desktop companion app on the Steam store (sandboxed, no homebrew, no sysfs writes)

Path B2 specifically requires Levelwright to work inside Valve's sandbox, which means several tools simply *cannot* function there:

- Cannot call `ryzenadj` to set TDP
- Cannot write to `/sys/class/hwmon/*/pwm*` for fan control
- Cannot hook Decky-specific APIs

If we do not design for this split now, we will have two painful outcomes:

1. Every feature added to the PoC might or might not be portable to the Steam store build — we find out per feature, reactively
2. A sandboxed build either crashes when it tries to call an unavailable tool, or worse, silently fails

The split exists even inside the PoC: some system tools (sysfs read) are `public` and work unprivileged; some (TDP set, fan curve) need `elevated` privileges (sudo / polkit) even on the Deck.

## Decision

**Every Hermes tool in Levelwright declares a `privilege_tier` as part of its metadata. Frontends and build profiles query this metadata and degrade gracefully.**

Three tiers:

| Tier | Definition | Example tools |
|---|---|---|
| `public` | No special OS privileges required; works inside a sandboxed Steam-store build | `sys_get_battery`, `sys_get_temps`, `steam_get_library`, `protondb_check_compat` |
| `elevated` | Requires sudo/polkit authorization (writes to sysfs, runs privileged CLIs) | `sys_set_tdp`, `sys_set_fan_curve`, `sys_set_perf_profile` |
| `homebrew` | Requires Decky Loader / SteamOS developer mode hooks | `decky_show_notification`, `decky_get_running_app`, `steam_overlay_toggle` |

Implementation:

- Add `privilege_tier: Literal["public", "elevated", "homebrew"]` to the plugin tool decorator metadata
- Hermes plugin loader reads this at registration
- Frontend queries `GET /v1/tools?tier=public` to enumerate tools available under its build profile
- Build profiles (`LEVELWRIGHT_PROFILE=poc|sandboxed`) filter which tools are registered at all — `sandboxed` excludes `elevated` and `homebrew`
- Tools that attempt to run despite insufficient privileges raise `PermissionError` with a clear message directing the user to the install-profile docs

This aligns with Architectural Principle #3 in `DESIGN.md` §III.

## Consequences

### Positive

- **Commercial path B2 stays viable with no re-architecture** — a `sandboxed` build is `LEVELWRIGHT_PROFILE=sandboxed`, not a fork
- **Frontends degrade gracefully** — a Decky UI that lost homebrew access would hide the "Set TDP" button rather than crash on click
- **Build-time split** — `pip install levelwright[sandboxed]` never even loads elevated-tier tool code, so attack surface is smaller in the Steam-store build
- **Tool documentation clarity** — every tool's required privileges are visible in one place

### Negative

- **Small metadata tax on every tool** — one extra line per tool declaration; developers must remember to tag correctly
- **Misclassification risk** — a tool tagged `public` that actually uses privileged sysfs will crash in sandboxed mode. Mitigated by: static analysis that flags sysfs writes in `public` tools; integration test that runs the `public` subset in a sandbox-like environment.
- **Cross-tier features are awkward** — "What should I play?" calls `public` tools (library, battery, compat); a v2 might want to factor in `elevated` data (current TDP setting). The engine must tolerate missing elevated inputs.

### Neutral

- Tier naming (`public` vs `elevated` vs `homebrew`) is a convention, not an OS-enforced boundary — the OS still enforces actual privileges; tiers just encode our policy

## Alternatives Considered

### Alternative A: No tagging; fork the codebase for the sandboxed build

Maintain two branches: PoC branch (everything) and sandboxed branch (subset).

**Pros:** no metadata overhead in code.
**Cons:** every feature shipped in the PoC creates a merge/cherry-pick decision for the sandboxed branch. Fork divergence is inevitable and expensive.

**Why not chosen:** structurally worse than a single codebase with build profiles.

### Alternative B: Runtime-only detection

Every tool tries its operation; catches `PermissionError` / `FileNotFoundError` / whatever and falls back.

**Pros:** no metadata.
**Cons:** fragile (errors are non-uniform across platforms); user sees cryptic failure messages; frontends cannot pre-hide UI for unavailable features; opens attack surface in sandboxed builds because elevated tool code still ships.

**Why not chosen:** the "let it fail" pattern becomes "let the user be confused."

### Alternative C: Fine-grained capabilities (read/write sysfs, network, subprocess) instead of three tiers

Declare each tool's exact system capabilities.

**Pros:** more precise.
**Cons:** over-engineered for PoC-stage decisions. We have two deployment contexts (homebrew PoC, sandboxed commercial); three coarse tiers map cleanly to them.

**Why not chosen:** YAGNI. Revisit if we add a third deployment context that needs finer control (e.g., a Flatpak profile with a different capability set).

## References

- `DESIGN.md` §III Architectural Principle #3 ("Tools are tagged by privilege tier")
- `DESIGN.md` §XI (Distribution Strategy — Path B2 sandbox requirements)
- PRD §5.2 (out-of-scope items that become relevant in sandboxed build)
- Related: ADR-0002 (plugin split), ADR-0004 (Decky is a `homebrew`-tier frontend)
