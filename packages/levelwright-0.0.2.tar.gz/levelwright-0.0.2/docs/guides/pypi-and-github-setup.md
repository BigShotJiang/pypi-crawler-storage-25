# Publishing a Python project to PyPI and GitHub — end-to-end setup

> A reusable, copy-paste-ready guide to: scaffolding a Python package, claiming its PyPI name, creating a GitHub organization, pushing the repo, and configuring PyPI Trusted Publishing via GitHub Actions so you never carry a long-lived API token again.

This document is written with **Levelwright** as the running example, but every step is general. Substitute your project name wherever `levelwright` appears.

**Table of contents:**

- [0. What you'll end up with](#0-what-youll-end-up-with)
- [1. Prerequisites](#1-prerequisites)
- [2. Scaffold the Python package locally](#2-scaffold-the-python-package-locally)
- [3. Claim the name on PyPI (initial upload with a token)](#3-claim-the-name-on-pypi-initial-upload-with-a-token)
- [4. Create the GitHub organization](#4-create-the-github-organization)
- [5. Create the flagship repo and the `.github` org repo](#5-create-the-flagship-repo-and-the-github-org-repo)
- [6. Push your local repo to GitHub](#6-push-your-local-repo-to-github)
- [7. Set up PyPI Trusted Publishing (OIDC)](#7-set-up-pypi-trusted-publishing-oidc)
- [8. Verify everything and tear down tokens](#8-verify-everything-and-tear-down-tokens)
- [Appendix A — File templates](#appendix-a--file-templates)
- [Appendix B — Multi-package repos](#appendix-b--multi-package-repos)
- [Appendix C — Common errors](#appendix-c--common-errors)

---

## 0. What you'll end up with

When you finish:

- Your project lives at `github.com/<org>/<project>` — clean public OSS repo
- Your org landing page at `github.com/<org>` shows a polished README
- Your package installs with `pip install <project>`
- **New releases are published by a tagged Git release** — GitHub Actions builds and uploads to PyPI automatically via short-lived OIDC credentials
- **No API tokens live on your laptop.** If your laptop is ever compromised, no one can push a malicious release in your name.

Rough time: 60–90 minutes first time, 15 minutes when you repeat it for another project.

---

## 1. Prerequisites

### Accounts

- **GitHub personal account** with **2FA enabled**. If you don't have 2FA on, enable it before starting — GitHub now requires 2FA for org owners, and PyPI requires it for all maintainers.
- **PyPI account** — you'll create this in Step 3.

### Local tools

Verify with:

```bash
python3 --version      # 3.11+
pip --version
git --version
```

If `python3` is missing, install it first (`brew install python` on macOS, `apt install python3 python3-venv python3-pip` on Debian/Ubuntu, etc.).

### Git identity

One-time setup on your machine:

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

**Privacy tip for OSS contributors:** GitHub provides a "noreply" email that keeps your real address out of public commit logs forever. Find it at **GitHub → Settings → Emails → "Keep my email addresses private"**. It looks like `12345678+yourusername@users.noreply.github.com`. Use that as your `user.email` for public OSS work.

### Name availability — check *before* anything else

Rename cost scales with public exposure. Verify all five namespaces before committing to a name:

| Namespace | How to check |
|---|---|
| GitHub org `github.com/<name>` | Visit the URL — 404 means available |
| PyPI project `pypi.org/project/<name>/` | Visit the URL — 404 means available |
| Primary domain `<name>.com` | Registrar search (Porkbun, Squarespace, Namecheap) |
| Dev domain `<name>.dev` | Same |
| USPTO trademark | https://tmsearch.uspto.gov/ in classes 009 (software) and 028 (games) |

If any of these return "taken" and the occupant is in your space (same or adjacent category), pick a different name before writing any code. Renaming later is expensive in sunk identity; renaming before anything public is free.

---

## 2. Scaffold the Python package locally

### Minimum viable layout

```
<project>/
├── LICENSE                         # MIT (or your chosen license)
├── README.md                       # shown on GitHub + PyPI listing
├── pyproject.toml                  # package metadata and build config
├── .gitignore                      # Python-standard
└── src/
    └── <project>/
        └── __init__.py             # contains __version__
```

Notes on structure:

- Use `src/` layout, not flat. Avoids editable-install confusion where tests import the source dir instead of the installed package.
- PyPI package names use **hyphens** (`levelwright-system`). Python import names use **underscores** (`levelwright_system`). In `pyproject.toml` the name uses hyphens; the directory under `src/` uses underscores. This is a standard Python packaging convention.
- Keep the initial version at `0.0.1`. Bump with real releases.

### pyproject.toml template

Use `hatchling` as the build backend — modern, fast, zero-config. Copy this template, substitute your project name in the three marked places:

```toml
[build-system]
requires = ["hatchling>=1.25"]
build-backend = "hatchling.build"

[project]
name = "<project>"                             # <-- PyPI name (hyphenated)
version = "0.0.1"
description = "One-line description of the project."
readme = "README.md"
requires-python = ">=3.11"
license = { file = "LICENSE" }
authors = [{ name = "<Your or Org Name>" }]
keywords = ["keyword1", "keyword2"]
classifiers = [
    "Development Status :: 1 - Planning",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]
dependencies = []

[project.urls]
Homepage = "https://github.com/<org>/<project>"
Repository = "https://github.com/<org>/<project>"
Issues = "https://github.com/<org>/<project>/issues"

[tool.hatch.build.targets.wheel]
packages = ["src/<project_with_underscores>"]  # <-- directory under src/
```

Full list of PyPI trove classifiers: https://pypi.org/classifiers/

### Build and verify locally

```bash
cd <project>
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip build twine
python -m build
twine check dist/*
```

`twine check` should print `PASSED` for both files. If it flags a README problem, fix it and rebuild before going any further.

---

## 3. Claim the name on PyPI (initial upload with a token)

PyPI doesn't have a "reserve this name" button. You reserve a name by uploading a real package at that name. For the initial upload we use an API token because OIDC/Trusted Publishing requires the project to already exist (chicken-and-egg; we'll convert after).

### 3.1 Create the PyPI account

1. Register at https://pypi.org/account/register/
2. Verify email
3. **Enable 2FA immediately** (required for all maintainers): Account settings → Two factor authentication → pick a TOTP app (1Password, Authy, Google Authenticator) and scan the QR. Save the recovery codes in your password manager.

### 3.2 Generate an API token

1. Account settings → **API tokens** → **Add API token**
2. Name: `<project>-initial-upload`
3. **Scope: Entire account.** You must use account-scope for the first upload because project-scoped tokens can't create a new project.
4. Click **Create token**. The token (starts with `pypi-...`) is shown **once only**. Paste it somewhere safe for 2 minutes — you'll use it immediately.

### 3.3 Upload

With the virtualenv activated and `dist/` already built:

```bash
twine upload dist/*
```

- Username: `__token__` (literally: two underscores, the word `token`, two more underscores)
- Password: the `pypi-...` token from step 3.2

On success: `https://pypi.org/project/<project>/` is now live and yours.

### 3.4 Verify

```bash
pip install <project>
python -c "import <project_with_underscores>; print(<project_with_underscores>.__version__)"
```

Should print `0.0.1`. You own the namespace.

**Leave the account-scoped token alive for now.** You'll need it if you're claiming additional package names (common in multi-package repos — see Appendix B). Once everything is uploaded, revoke it in Step 8.

---

## 4. Create the GitHub organization

An organization is a namespace wrapper around repos — it does **not** require a new GitHub user account. You use your existing personal account to create and own the org.

Why use an org instead of your personal namespace:

- Clean public identity (`github.com/<project>` vs `github.com/<yourname>/<project>`)
- Required for the PyPI Trusted Publishing config if you want the trust tied to an org, not a person
- Easier to transfer or add collaborators later

### 4.1 Create

1. Visit https://github.com/organizations/plan → pick **Free**
2. **Organization account name:** `<org>` (lowercase)
3. **Contact email:** any email you control. Used for billing + security alerts. Not shown publicly. Changeable later.
4. **This organization belongs to:** **My personal account** — not "A business or institution" (that option is for EIN/tax orgs).
5. Accept ToS → **Create organization**.
6. Skip "invite members" and the "tell us about you" survey.

### 4.2 Lock down immediately

From the new org's page:

1. **Settings → Authentication security** → check **"Require two-factor authentication for everyone in this organization"** → **Save**.
2. **Settings → Member privileges** → confirm **Base permissions** is **Read**. Optionally uncheck "Allow forking of private repositories" (no-op now but removes a future foot-gun).

---

## 5. Create the flagship repo and the `.github` org repo

Two repos, both under the org you just created.

### 5.1 Flagship repo — the project itself

1. Top-right **+** → **New repository** (or go to `https://github.com/organizations/<org>/repositories/new`)
2. **Owner:** pick the org (not your personal account)
3. **Repository name:** `<project>`
4. **Description:** one-line project summary
5. **Visibility:** **Public**
6. **Initialize with:** **leave all three unchecked** — no README, no `.gitignore`, no license. Your local repo already has these and initializing here creates first-push conflicts.
7. **Create repository**

You now have an empty repo at `https://github.com/<org>/<project>`. Keep this tab open; the quick-setup page shows the exact `git remote add origin` URL you'll need.

### 5.2 The `.github` repo — org landing page

GitHub looks for `<org>/.github/profile/README.md` and renders it on the org's public page at `github.com/<org>`.

1. **+** → **New repository**
2. **Owner:** the org
3. **Repository name:** `.github` (literally, with the leading dot)
4. **Description:** `Default community health files and org landing page for <project>.`
5. **Visibility:** **Public** — required. Private `.github` repos do not render the landing page.
6. **Initialize with README:** ✅ yes (single-file repo, safe to initialize)
7. **Create repository**

Then on the freshly-created repo:

1. **Add file → Create new file**
2. In the filename box, type `profile/README.md` — the `/` auto-creates the `profile/` folder.
3. Paste your org-landing-page content.
4. **Commit changes → Commit directly to main**.

Optionally, replace the repo's root `README.md` with a short note explaining what the `.github` repo is for (see the example in the Levelwright docs).

Visit `github.com/<org>` — the landing page should render within seconds.

---

## 6. Push your local repo to GitHub

Your local folder is not yet a git repo. The flow is: init → configure → first commit → add remote → push.

From the project root:

```bash
cd <project>

# One-time: initialize git, set the default branch name
git init
git branch -M main

# Stage and commit everything currently in the folder
git add .
git status                 # quickly verify what's staged
git commit -m "initial commit: design docs, PRD, ADRs, package scaffolds"

# Point this repo at the GitHub remote you created in 5.1
git remote add origin https://github.com/<org>/<project>.git

# Push
git push -u origin main
```

The `-u` flag sets the upstream, so future `git push` and `git pull` don't need arguments.

### Authentication

First push will prompt for GitHub credentials. Two options:

- **HTTPS + Personal Access Token** (easier): when prompted for a password, paste a PAT, not your GitHub password. Create one at GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens. Scope: the org, with "Contents: read and write" permission.
- **SSH** (preferable long-term): `ssh-keygen -t ed25519 -C "your_email@example.com"`, add the public key to GitHub → Settings → SSH and GPG keys, then use `git@github.com:<org>/<project>.git` as the remote instead of the `https://` URL.

If you've pushed to GitHub before on this machine, Git's credential helper has already cached credentials; the push should be silent.

### Verify

Visit `https://github.com/<org>/<project>` — all files you committed should be visible. The `README.md` renders on the repo home page.

---

## 7. Set up PyPI Trusted Publishing (OIDC)

Now we eliminate long-lived tokens. From here on, only GitHub Actions (triggered by your release events) can publish to PyPI, and only from a specific workflow on a specific branch of a specific repo.

### 7.1 Create the `pypi` environment on GitHub

1. In your flagship repo → **Settings → Environments → New environment**
2. Name: `pypi` (case-sensitive; must match the PyPI config exactly)
3. Configure:
   - **Deployment branches and tags** → restrict to `main` (prevents a feature branch from triggering a publish)
   - Optionally: **Required reviewers** → add yourself (every publish then needs your click to proceed — recommended)
4. **Save protection rules**

### 7.2 Configure Trusted Publisher on PyPI — repeat for each package

For **each** PyPI project you own:

1. Go to `https://pypi.org/manage/project/<project>/settings/publishing/`
2. Click **Add a new publisher** → **GitHub**
3. Fill in:
   - **PyPI Project Name:** prefilled
   - **Owner:** `<org>`
   - **Repository name:** `<repo-name>` (the flagship repo)
   - **Workflow name:** `publish.yml` (the filename in `.github/workflows/`)
   - **Environment name:** `pypi` (must match what you named it on GitHub)
4. **Save**

Same (org, repo, workflow, environment) combo can publish to multiple PyPI projects from one workflow — that's how a multi-package repo (see Appendix B) works.

### 7.3 The GitHub Actions workflow

Create `.github/workflows/publish.yml` in your flagship repo. A minimal one for a single package:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]
  workflow_dispatch:

jobs:
  publish:
    runs-on: ubuntu-latest
    environment:
      name: pypi
      url: https://pypi.org/p/<project>
    permissions:
      id-token: write   # required for OIDC
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"
      - run: python -m pip install --upgrade pip build
      - run: python -m build
      - uses: pypa/gh-action-pypi-publish@release/v1
        with:
          print-hash: true
```

For multi-package repos, see Appendix B.

Commit and push this file so it lives on `main`:

```bash
git add .github/workflows/publish.yml
git commit -m "ci: add PyPI Trusted Publishing workflow"
git push
```

### 7.4 First release via Trusted Publishing — smoke test

**Manual dispatch (first try, lowest risk):**

1. Bump `version` in `pyproject.toml` — `0.0.1` → `0.0.2` (PyPI rejects re-uploads of the same version)
2. Commit and push
3. GitHub repo → **Actions** tab → **Publish to PyPI** workflow → **Run workflow**
4. If "Required reviewers" is on, approve the deployment when prompted
5. Watch the job. On success, `https://pypi.org/project/<project>/` shows `0.0.2`

**Release-triggered (normal operation from here on):**

```bash
# Bump version in pyproject.toml, commit, push, then:
git tag v0.1.0
git push origin v0.1.0
```

On GitHub: **Releases → Draft a new release → Choose tag v0.1.0 → Generate release notes → Publish release** → the `release: published` event fires, the workflow runs, OIDC exchanges a short-lived credential with PyPI, the package uploads.

---

## 8. Verify everything and tear down tokens

### 8.1 Confirm Trusted Publishing works

After a successful workflow run:

- The job log shows `Issued sigstore bundle` or the hashes of uploaded files (from `print-hash: true`)
- `pip install --upgrade <project>` pulls the new version

### 8.2 Revoke API tokens — important

1. PyPI → Account settings → **API tokens**
2. **Revoke every token.** If you need one for emergencies, leave one project-scoped token and store it encrypted in a password manager. Never leave an account-scoped token alive after the initial setup.

From here on, you publish by creating a Git release. Nothing else.

### 8.3 Enable PyPI 2FA recovery codes

Account settings → recovery codes → download and store offline. Without them you lose access if your TOTP device dies.

---

## Appendix A — File templates

### A.1 Minimum `.gitignore` for Python

```
__pycache__/
*.py[cod]
*$py.class
*.so
*.egg-info/
dist/
build/
.venv/
venv/
.env
.env.*
!.env.example
.pytest_cache/
.coverage
.mypy_cache/
.ruff_cache/
.tox/
.idea/
.vscode/
.DS_Store
```

### A.2 Minimum `LICENSE` (MIT)

```
MIT License

Copyright (c) <year> <your name or org>

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### A.3 Minimum `src/<project>/__init__.py`

```python
"""<Project> — <one-line description>."""

__version__ = "0.0.1"
```

---

## Appendix B — Multi-package repos

Some projects (Levelwright included) ship as several related PyPI packages from a single repo — an umbrella + plugins pattern.

Layout:

```
<repo>/
├── pyproject.toml                          # umbrella package
├── src/<project>/__init__.py
├── plugins/
│   ├── <project>-plugin-a/
│   │   ├── pyproject.toml
│   │   └── src/<project>_plugin_a/__init__.py
│   └── <project>-plugin-b/
│       ├── pyproject.toml
│       └── src/<project>_plugin_b/__init__.py
└── .github/workflows/publish.yml
```

Each package has its own `pyproject.toml` and builds independently. Each is a separate PyPI project that must be claimed separately (Section 3 repeated) and configured separately in Trusted Publishing (Section 7.2 repeated).

### Matrix workflow for multi-package publishing

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]
  workflow_dispatch:
    inputs:
      package:
        description: "Which package to publish"
        required: true
        default: "all"
        type: choice
        options: [all, <project>, <project>-plugin-a, <project>-plugin-b]

jobs:
  publish:
    name: Build & publish ${{ matrix.name }}
    runs-on: ubuntu-latest
    environment:
      name: pypi
      url: https://pypi.org/p/${{ matrix.name }}
    permissions:
      id-token: write
    strategy:
      fail-fast: false
      matrix:
        include:
          - name: <project>
            path: .
          - name: <project>-plugin-a
            path: plugins/<project>-plugin-a
          - name: <project>-plugin-b
            path: plugins/<project>-plugin-b
    steps:
      - name: Decide whether to publish this package
        id: decide
        env:
          REQUESTED: ${{ inputs.package }}
          CURRENT: ${{ matrix.name }}
          EVENT: ${{ github.event_name }}
        run: |
          if [ "$EVENT" = "workflow_dispatch" ] && [ "$REQUESTED" != "all" ] && [ "$REQUESTED" != "$CURRENT" ]; then
            echo "skip=true" >> "$GITHUB_OUTPUT"
          else
            echo "skip=false" >> "$GITHUB_OUTPUT"
          fi
      - uses: actions/checkout@v4
        if: steps.decide.outputs.skip != 'true'
      - uses: actions/setup-python@v5
        if: steps.decide.outputs.skip != 'true'
        with:
          python-version: "3.11"
      - if: steps.decide.outputs.skip != 'true'
        run: python -m pip install --upgrade pip build
      - if: steps.decide.outputs.skip != 'true'
        working-directory: ${{ matrix.path }}
        run: python -m build
      - if: steps.decide.outputs.skip != 'true'
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: ${{ matrix.path }}/dist
          print-hash: true
```

Key points:

- All three packages share one `pypi` environment and one workflow, just different `path` values
- All three need their own Trusted Publisher config on PyPI pointing at the same (org, repo, workflow, environment) tuple
- `workflow_dispatch` input lets you publish one at a time for testing

### Shell-expression hygiene in workflows

GitHub Actions has a well-known command-injection risk when untrusted inputs flow into `run:` blocks via `${{ expr }}`. For workflow `inputs` constrained by `type: choice`, this isn't exploitable, but it's still good hygiene to route values through `env:` rather than interpolating directly. The workflow above does this.

---

## Appendix C — Common errors

| Symptom | Cause | Fix |
|---|---|---|
| `twine upload` → `400 Filename has already been used` | You're trying to re-upload the same version. PyPI is write-once per version. | Bump `version` in `pyproject.toml`, rebuild, re-upload. |
| `twine upload` → `403 Invalid or non-existent authentication` | Username is wrong. | Username must be literal `__token__` (two underscores each side), not your PyPI username. |
| Trusted Publishing → `invalid-publisher` error | Environment name mismatch between GitHub and PyPI, or the workflow hasn't run yet so PyPI can't see it. | Case-sensitive check on env name. Run the workflow once from `main` before configuring the publisher if you're using the strictest PyPI validation. |
| First `git push` → `error: src refspec main does not match any` | Your initial commit hasn't been created yet, or the branch is named `master`. | `git branch -M main` then `git commit` before pushing. |
| GitHub push → authentication prompt loop | Git password authentication was deprecated in 2021. | Use a Personal Access Token or SSH key. See Section 6. |
| Org README doesn't render on `github.com/<org>` | File in wrong place, or `.github` repo is private. | Must be at `<org>/.github/profile/README.md` in a **public** repo. |
| `pip install <project>` returns old version after trusted publishing release | PyPI CDN cache. | Wait a minute or run `pip install --upgrade <project>`. |
| `twine check` → "README.md is not valid" | Syntax error in README (unclosed code fence, malformed link). | Preview the README on GitHub first; fix and rebuild. |

---

## Canonical references

These pages are maintained by the relevant projects and supersede this guide if they change:

- PyPI trusted publishing guide: https://docs.pypi.org/trusted-publishers/
- Python Packaging User Guide: https://packaging.python.org/
- `pypa/gh-action-pypi-publish`: https://github.com/pypa/gh-action-pypi-publish
- GitHub Actions docs (OIDC): https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/about-security-hardening-with-openid-connect
- GitHub org profile README: https://docs.github.com/en/organizations/collaborating-with-groups-in-organizations/customizing-your-organizations-profile
