# Levelwright — Proof-of-Concept PRD

**Author:** Project owner (solo)
**Status:** Draft
**Last Updated:** 2026-04-19
**Target release:** v0.1.0 (MVP), public by ~2026-07-19 (12 weeks)
**Complexity tier:** Tier 3 (major initiative)
**Reference design:** [`DESIGN.md`](../../DESIGN.md) — full technical design
**ADRs:** [`../adr/`](../adr/)

---

## 1. Overview

### 1.1 Problem Statement

Handheld PC gaming (Steam Deck, ROG Ally, Legion Go, MSI Claw) has exploded, but **no open-source, system-level AI gaming assistant exists for these devices.** NVIDIA's Project G-Assist proved the concept viable (April-Fools-joke-turned-real-product, March 2025) but is RTX desktop-only and closed-source. Xbox Gaming Copilot and Razer Game Co-AI are Windows/vendor-locked. Open-source alternatives are either Windows-only, screenshot-based add-ons, or research prototypes.

Handheld users specifically need help with decisions their desktop counterparts don't face: *"which of my 400 Steam games is worth playing on this hardware in 45 minutes on battery?"*, *"why are my frames dropping and my fan screaming?"*, *"is this game Deck Verified, and does Proton X work for it?"* — questions where a handheld-aware AI assistant with access to live system telemetry and Steam library data outperforms both static documentation and generic chatbots.

### 1.2 Proposed Solution

**Levelwright** is an open-source AI gaming assistant that runs locally on the Steam Deck (and eventually other handhelds). It consists of:

1. Two **Hermes-Agent plugins** (`levelwright-system`, `levelwright-steam`) providing tools for hardware telemetry and Steam library access.
2. A **Decky Loader plugin** as the in-Game-Mode UI.
3. A **`HardwareAdapter` abstraction** so the same tools work on future handhelds with new adapter implementations.

The PoC validates product-market fit and technical feasibility before any commercial distribution attempt. Commercial paths (pitch to Valve; Steam-store desktop companion app) are deferred to Phase B, informed by PoC data.

### 1.3 Success Metrics

The PoC succeeds if **all three** of the following are true at the 3-month mark:

| # | Metric | Target | Why it matters |
|---|---|---|---|
| M1 | Daily use by owner | Project owner uses Levelwright daily on their own Steam Deck for ≥14 consecutive days without gameplay regressions | Validates actual utility (dogfood test); if it doesn't survive real use, nothing else matters |
| M2 | Community traction | ≥100 installs from the Decky Plugin Store within 3 months of public release | Validates demand beyond one user; distinguishes "cool for me" from "useful for the segment" |
| M3 | Commercial-path decision readiness | A written decision doc comparing §XI Path B1 (pitch Valve) vs Path B2 (Steam store), backed by telemetry and community feedback collected during the PoC | Ensures the PoC produces an input to the commercial decision, not just code |

Non-targets: revenue, press coverage, investor interest, trademark filings. Those belong to Phase B.

---

## 2. Context

### 2.1 Background

Inspired by TechDweeb's PocketDweeb April Fools concept (2024) and NVIDIA Project G-Assist (2025). See `DESIGN.md` §I for the full origin story and §II for competitive landscape. Design phase began and completed April 19, 2026.

Original working title "GameDweeb" was replaced with **Levelwright** on 2026-04-19 for brandability and commercial-path reasons — see `DESIGN.md` §IX and `ADR-0011`.

### 2.2 User Segments

The PoC targets three audiences in sequence ("all of the above, staged"):

| Stage | Audience | Volume | Goal |
|---|---|---|---|
| S1 (weeks 1–4) | Owner only | 1 | Dogfood validation — does it run? Does it help? |
| S2 (weeks 5–8) | Invited beta — friends, Decky power users, small Discord community | 5–15 | Find crashes, workflow bugs, obvious missing features |
| S3 (weeks 9–12) | Public Decky Plugin Store release | Unbounded | Collect real install count, usage telemetry, feedback |

### 2.3 Competitive Analysis

See `DESIGN.md` §II for the full table. Key positioning claim:

> *Levelwright is the first open-source, handheld-native, system-level AI gaming assistant.*

Every current product either (a) requires RTX desktop / Windows, (b) is closed-source, (c) is screenshot-analysis only with no system access, or (d) is a research prototype not shipping to end users. Levelwright sits in the gap across all four axes simultaneously.

---

## 3. Requirements

### 3.1 User Stories

**US-1 — System telemetry on demand**

```
As a Steam Deck user
I want to ask "what's my battery / CPU temp / GPU temp / fan speed?"
So that I can monitor hardware without tabbing into the Steam overlay mid-game

Acceptance Criteria:
- Given I have Levelwright running and open the Decky quick panel
- When I tap the "System" card
- Then I see battery %, estimated time remaining, CPU temp, GPU temp, fan RPM, current TDP
- And values refresh within 2 seconds of being visible
- And no reading blocks on a sysfs call longer than 200ms
```

**US-2 — Compatibility check before buying/launching**

```
As a Steam Deck user
I want to ask "is [game X] Deck Verified and what's its ProtonDB rating?"
So that I know whether it will work before investing time in downloading it

Acceptance Criteria:
- Given I have Levelwright running
- When I ask "is <game name> going to work on my Deck?"
- Then I get: ProtonDB rating (Platinum/Gold/Silver/Bronze/Borked), Deck Verified status, recommended Proton version if applicable, top 1-2 common issues from recent reports
- And results return in <5 seconds
- And the response cites the source (ProtonDB, Steam)
```

**US-3 — "What should I play?"**

```
As a Steam Deck user with a large backlog
I want Levelwright to recommend a game from my library
So that I don't waste 10 minutes of a 45-minute session choosing what to play

Acceptance Criteria:
- Given I have Levelwright running and have linked my Steam profile (via user-provided API key)
- When I ask "what should I play?" with optional context ("something short", "something relaxing", "something I haven't touched in a while")
- Then I get 1–3 game recommendations from my owned library
- And each recommendation includes: title, hours played (if any), last played date (if any), ProtonDB rating, and one-sentence reason tailored to my context
- And the engine does not recommend games that are unplayable (ProtonDB Borked, or Deck Unsupported) unless I explicitly override
```

**US-4 — Ask-anything natural language interface**

```
As a Steam Deck user
I want to ask Levelwright any gaming or system question in natural language
So that I don't have to remember specific command syntax or menu paths

Acceptance Criteria:
- Given Levelwright has an LLM backend configured (local or cloud)
- When I type a free-form question
- Then the agent dispatches the appropriate tools and returns a natural-language answer
- And if no tool applies, the agent says so rather than hallucinating
- And tool invocations are visible in a log for debugging
```

### 3.2 Functional Requirements

**FR-1 (Core — `levelwright-system` plugin):**

| ID | Tool | Requirement |
|---|---|---|
| FR-1.1 | `sys_get_temps` | Shall return CPU package temp and GPU temp from `/sys/class/hwmon/*` in Celsius, within 200ms |
| FR-1.2 | `sys_get_battery` | Shall return percentage (0–100), charging state, estimated minutes remaining, from `/sys/class/power_supply/BAT*` |
| FR-1.3 | `sys_get_performance` | Shall return current TDP (W), CPU/GPU clock (MHz), fan speed (RPM), and process count |
| FR-1.4 | `sys_get_storage` | Shall return free/used bytes for `/home`, the primary game library, and any mounted SD card |
| FR-1.5 | Hardware abstraction | All FR-1.x tools shall route hardware access through a `HardwareAdapter` interface (`SteamDeckAdapter` as first impl) per `ADR-0003` |

**FR-2 (Core — `levelwright-steam` plugin):**

| ID | Tool | Requirement |
|---|---|---|
| FR-2.1 | `steam_get_library` | Shall fetch the user's owned games via `IPlayerService/GetOwnedGames`, cached locally with a configurable TTL (default 6h) |
| FR-2.2 | `steam_get_playtime` | Shall return hours played per game (total + 2-week window) |
| FR-2.3 | `steam_get_achievements` | Shall return achievement counts per game for the current user |
| FR-2.4 | `steam_get_recent` | Shall return games played in the last N days (default 14) |
| FR-2.5 | `protondb_check_compat` | Shall return ProtonDB rating and Deck Verified status for a given AppID |
| FR-2.6 | API key handling | Shall never ship or log an API key; shall store the user-provided key encrypted at rest per `ADR-0010` |

**FR-3 ("What should I play?" recommendation engine):**

| ID | Requirement |
|---|---|
| FR-3.1 | Shall take owned games, playtime, recent play, compat ratings, and current battery state as inputs |
| FR-3.2 | Shall filter out games incompatible with the current Deck/session context (Borked on ProtonDB, Deck Unsupported, install missing) |
| FR-3.3 | Shall return 1–3 recommendations ranked by a transparent rule set (documented in-repo) that the LLM can narrate |
| FR-3.4 | Shall accept optional user context ("short session", "relaxing", "co-op", "new to me") and weight accordingly |

**FR-4 (Decky plugin UI):**

| ID | Requirement |
|---|---|
| FR-4.1 | Shall expose a Quick Panel card accessible from Game Mode with at minimum: battery %, CPU/GPU temp, TDP, and an "Ask Levelwright" button |
| FR-4.2 | "Ask Levelwright" shall open a text input that posts to the local Hermes API at `http://127.0.0.1:8642/v1/chat/completions` and streams the response |
| FR-4.3 | Shall expose a "What should I play?" button that triggers FR-3 and renders results as cards |
| FR-4.4 | Shall not block the Steam overlay or degrade frame pacing by >1% average during typical use |

**FR-5 (LLM backend):**

| ID | Requirement |
|---|---|
| FR-5.1 | User shall choose between local (Ollama) and cloud (Anthropic / OpenAI / OpenRouter) backend at install time per `ADR-0009` |
| FR-5.2 | Both backend paths shall work with the same plugin tools (no backend-specific tool code) |
| FR-5.3 | User shall be able to change backends without reinstalling |

### 3.3 Non-Functional Requirements

| Category | Requirement |
|---|---|
| Performance | Levelwright gateway (idle) shall consume <150MB RAM and <2% CPU averaged over 5-minute windows while a game is running |
| Performance | Game frame pacing regression shall be ≤1% median, measured by MangoHUD log diff between Levelwright-off and Levelwright-on runs of the same 10-minute gameplay session |
| Security | API keys (Steam, LLM providers) shall be stored encrypted at rest and never logged in plaintext |
| Privacy | No telemetry shall be sent off-device without explicit user opt-in; opt-in telemetry shall be anonymous and documented |
| Install experience | First-time install shall complete in <10 minutes for a user already running Decky Loader, via a single install command or Decky Store entry |
| Portability | No tool shall hardcode Steam Deck sysfs paths; all hardware access routed through `HardwareAdapter` per `ADR-0003` |
| Licensing | All PoC code shall be MIT-licensed; contributors shall sign the CLA per `ADR-0008` |

---

## 4. Design

### 4.1 High-Level Architecture

```
+--------------------------+
|  Decky Plugin (Frontend) |
|  - Quick Panel           |
|  - Ask Levelwright       |
|  - Play Next             |
+------------+-------------+
             |
             | HTTP / OpenAI-compatible
             v
+--------------------------+
|  Hermes-Agent gateway    |
|  localhost:8642/v1       |
|  - /chat/completions     |
|  - /models               |
+------------+-------------+
             |
    +--------+---------+
    |                  |
    v                  v
+---+-------+    +-----+---------+
| system    |    | steam         |
| plugin    |    | plugin        |
| (FR-1)    |    | (FR-2)        |
+-----+-----+    +-----+---------+
      |                |
+-----v-------+   +----v---------+
| Hardware    |   | Steam Web    |
| Adapter     |   | API          |
| (Deck       |   |              |
|  first)     |   | ProtonDB API |
+-------------+   +--------------+
```

See `DESIGN.md` §III for the full architecture diagram including future expansion surfaces.

### 4.2 User Flow — "What should I play?"

```
User (Game Mode)
  -> Opens Decky quick panel
  -> Taps "Play Next"
     -> Decky frontend POSTs to localhost:8642/v1/chat/completions
        with system prompt including "recommend a game from my library"
        -> Hermes dispatches tools:
           -> steam_get_library (cached)
           -> steam_get_recent (cached)
           -> sys_get_battery
           -> protondb_check_compat (for candidate games)
        -> LLM ranks candidates using transparent rules
        -> Returns 1-3 recommendations + reasons
     -> Decky renders cards
  -> User taps a card to launch the game
```

### 4.3 Technical Considerations

- **Cache discipline:** Steam API calls are expensive and rate-limited. Plugin shall cache owned games for 6h, recent games for 1h, achievements on-demand. Cache invalidation via a user-facing "Refresh Steam data" action.
- **Proton compat lookup:** ProtonDB has no public documented API contract; rely on their JSON endpoints with graceful fallback to the CLI (`protondb-cli`) if web API fails.
- **Streaming responses:** Decky UI shall render streamed responses to avoid dead-air during LLM generation. Hermes supports SSE on `/chat/completions`.
- **LLM cost/latency tradeoff:** Cloud backend (Claude Haiku 4.5, GPT-4o-mini, or similar) will dominate on quality and latency; local Ollama with a 4–8B model is supported but positioned as the "private" option, not "fast" option.

---

## 5. Scope

### 5.1 In Scope (v0.1.0 — MVP)

- Both Hermes plugins (`levelwright-system`, `levelwright-steam`) with tools listed in FR-1 and FR-2
- `HardwareAdapter` interface + `SteamDeckAdapter` implementation
- "What should I play?" recommendation engine (FR-3)
- Decky plugin with Quick Panel + Play Next + Ask Levelwright (FR-4)
- LLM backend selection at install (FR-5)
- Install script (Steam Deck only)
- README, install docs, CLA
- MIT license + CLA signing workflow (GitHub Action)
- Public repo at `github.com/levelwright/levelwright`

### 5.2 Out of Scope for v0.1.0 (deferred to v0.2+)

- Per-game performance profiles (TDP/FSR/refresh auto-apply) — Tier 2 in `DESIGN.md` §IV
- Storage manager ("games to remove")
- Update watchdog
- Screen analysis / vision models
- Voice / wake word
- Adapters for ROG Ally, Legion Go, MSI Claw (interface designed for future, not implemented)
- Telegram / Discord frontends
- Commercial desktop app (§XI Path B2)
- Honcho integration
- Community telemetry aggregation

### 5.3 Future Considerations (v1.0+)

See `DESIGN.md` §IV Tiers 2–3 and §VIII Roadmap Phases 2–4.

Commercial distribution decision is tracked in success metric M3 above and is **not a deliverable of the PoC**.

---

## 6. Timeline

### 6.1 Milestones

Tentative. Hobby pace (evenings + weekends). 12 weeks ≈ 2026-04-19 → 2026-07-19.

| Milestone | Target week | Exit criteria |
|---|---|---|
| M0 — Foundation | Week 1 | Repo scaffolded, Hermes installed on Deck, hello-world plugin loads, CLA workflow green |
| M1 — System telemetry | Week 3 | FR-1.1 through FR-1.5 shipped, tested on Deck, covered by unit tests against mock adapter |
| M2 — Steam integration | Week 5 | FR-2.1 through FR-2.6 shipped, user-provided API key flow works end-to-end |
| M3 — Recommendation engine | Week 7 | FR-3.1 through FR-3.4 shipped, returns coherent recommendations for the owner's 400-game library |
| M4 — Decky UI | Week 10 | FR-4.1 through FR-4.4 shipped; public owner dogfood begins |
| M5 — Beta | Week 11 | 5–15 invited users installed; feedback collected in a structured form |
| M6 — Public release | Week 12 | Published to Decky Plugin Store; README + quickstart + troubleshooting live; first-week installs tracked |
| M7 — Success review | Week 12 + 3 months | Success metrics M1/M2/M3 evaluated; commercial-path decision doc produced |

### 6.2 Dependencies

- Hermes-Agent v0.9.0+ remains available and API-stable (external — monitored, no control)
- Decky Loader continues to function on current SteamOS (external — stable community maintenance)
- Steam Web API endpoints used in FR-2 remain available (external — stable)
- ProtonDB endpoints remain available (external — fragile; fallback CLI planned per §4.3)

### 6.3 Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Hermes-Agent breaking change in minor release | Medium | High | Pin a Hermes version in install script; upgrade deliberately |
| ProtonDB API changes/rate-limits | Medium | Medium | Graceful fallback to `protondb-cli`; cache aggressively |
| Decky plugin API changes | Low | High | Pin a Decky loader-api version; monitor release notes |
| Steam Web API terms change affecting user-provided-key pattern | Low | Critical | User-provided keys are already the ToS-safest pattern (ADR-0010); re-evaluate if Valve policy shifts |
| Gameplay performance regression (frame pacing) | Medium | Critical | Enforce NFR perf budget; automated before/after MangoHUD comparison in CI where possible |
| Solo-dev burnout at hobby pace | Medium | Critical | 12-week timeline is soft; scope cut (§5.2) is generous; defer freely rather than ship broken |
| Trademark challenge on "Levelwright" despite clean availability check | Low | High | Filed availability evidence on 2026-04-19; if challenged, rename (low sunk cost at PoC stage) |

---

## 7. Appendix

### 7.1 Open Questions

None blocking v0.1.0 start. The following remain to be decided during implementation:

| # | Question | Decide by |
|---|---|---|
| OQ-1 | Default cloud LLM provider and model if user picks "cloud" without specifying | Week 3 |
| OQ-2 | Telemetry opt-in schema for M3 metric collection (what do we record, where does it go?) | Week 8 |
| OQ-3 | Recommendation-engine scoring weights — hard-coded v1 vs learned from user feedback | Week 6 |
| OQ-4 | Commercial brand decision (reuse Levelwright or create new brand for Steam store) | Phase B |

### 7.2 Research References

- `DESIGN.md` §II (Competitive Landscape) — 13 comparable products surveyed
- `DESIGN.md` §VI (Steam Deck Technical Capability Map) — 15 sysfs/API integration points
- `DESIGN.md` §VII (Hermes-Agent Architecture Reference) — extension points and versions
- PocketDweeb concept video: https://www.youtube.com/watch?v=JLG4d5Opo14
- NVIDIA Project G-Assist: https://www.nvidia.com/en-us/geforce/g-assist/

### 7.3 Decision Record

This PRD is anchored on the following ADRs. Changes to any of these trigger a PRD review:

| ADR | Decision |
|---|---|
| ADR-0001 | Hermes-Agent as base framework |
| ADR-0002 | Two-plugin split (`levelwright-system` + `levelwright-steam`) |
| ADR-0003 | `HardwareAdapter` abstraction |
| ADR-0004 | Decky Loader as first frontend |
| ADR-0005 | Local terminal backend |
| ADR-0006 | Memory strategy (Hermes built-ins; Honcho deferred) |
| ADR-0007 | Privilege-tier tagging on tools |
| ADR-0008 | Open-core licensing (MIT + CLA) |
| ADR-0009 | LLM backend — user choice at install |
| ADR-0010 | Steam Web API key — user-provided |
| ADR-0011 | Brand: Levelwright (commercial brand deferred) |

### 7.4 Sign-off

| Role | Name | Status |
|---|---|---|
| Product | Owner | Self |
| Engineering | Owner | Self |
| Design | Owner | Self (with AI-assistant collaboration) |
| Legal | Not engaged at PoC stage | N/A until Phase B |
