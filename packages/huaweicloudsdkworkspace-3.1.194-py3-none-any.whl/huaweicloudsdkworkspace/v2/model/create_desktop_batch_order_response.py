# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateDesktopBatchOrderResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'orders': 'list[OrderV5]'
    }

    attribute_map = {
        'orders': 'orders'
    }

    def __init__(self, orders=None):
        r"""CreateDesktopBatchOrderResponse

        The model defined in huaweicloud sdk

        :param orders: 批量生成订单结果。
        :type orders: list[:class:`huaweicloudsdkworkspace.v2.OrderV5`]
        """
        
        super().__init__()

        self._orders = None
        self.discriminator = None

        if orders is not None:
            self.orders = orders

    @property
    def orders(self):
        r"""Gets the orders of this CreateDesktopBatchOrderResponse.

        批量生成订单结果。

        :return: The orders of this CreateDesktopBatchOrderResponse.
        :rtype: list[:class:`huaweicloudsdkworkspace.v2.OrderV5`]
        """
        return self._orders

    @orders.setter
    def orders(self, orders):
        r"""Sets the orders of this CreateDesktopBatchOrderResponse.

        批量生成订单结果。

        :param orders: The orders of this CreateDesktopBatchOrderResponse.
        :type orders: list[:class:`huaweicloudsdkworkspace.v2.OrderV5`]
        """
        self._orders = orders

    def to_dict(self):
        import warnings
        warnings.warn("CreateDesktopBatchOrderResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateDesktopBatchOrderResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
