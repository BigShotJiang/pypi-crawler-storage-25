"""Tests for hierarchical_detrend_batch (variable-length batched processing)."""

import math

import numpy as np
import torch
import pytest

from torchflat.hierarchical import (
    hierarchical_detrend,
    hierarchical_detrend_batch,
)


CADENCE = 2.0 / 1440.0  # 2-min cadence in days
CADENCE_MIN = 2.0


requires_cuda = pytest.mark.skipif(
    not torch.cuda.is_available(),
    reason="CUDA/HIP not available",
)


def _make_star(n_points: int, noise_std: float = 0.0001, seed: int = 42):
    """Create a single-star (time, flux) numpy pair."""
    rng = np.random.default_rng(seed)
    time = np.arange(n_points, dtype=np.float64) * CADENCE
    flux = np.ones(n_points, dtype=np.float32)
    if noise_std > 0:
        flux = flux + rng.normal(0, noise_std, n_points).astype(np.float32)
    return time, flux


# ===================================================================
# Basic batching contract
# ===================================================================


class TestBatchContract:
    """Tests on shapes, ordering, and basic correctness."""

    def test_empty_input(self):
        """Empty input -> empty output."""
        out = hierarchical_detrend_batch([], [], cadence_minutes=2.0, device="cpu")
        assert out == []

    def test_mismatched_lengths(self):
        """Mismatched input list lengths raises."""
        with pytest.raises(ValueError):
            hierarchical_detrend_batch(
                [_make_star(1000)[0]],
                [_make_star(1000)[1], _make_star(1000)[1]],
                cadence_minutes=2.0,
                device="cpu",
            )

    def test_output_keys(self):
        """Each per-star result has detrended/trend/uncertainty keys."""
        t, f = _make_star(1500)
        out = hierarchical_detrend_batch(
            [t], [f], cadence_minutes=2.0, device="cpu",
        )
        assert len(out) == 1
        assert out[0] is not None
        assert "detrended" in out[0]
        assert "trend" in out[0]
        assert "uncertainty" in out[0]

    def test_per_star_lengths_preserved(self):
        """Output arrays match input lengths exactly."""
        stars = [(_make_star(1200), _make_star(1500), _make_star(1800))]
        ts = [s[0] for s in stars[0]]
        fs = [s[1] for s in stars[0]]
        out = hierarchical_detrend_batch(ts, fs, cadence_minutes=2.0, device="cpu")
        assert len(out) == len(ts)
        for i, r in enumerate(out):
            assert r is not None
            assert r["detrended"].shape == (len(ts[i]),)
            assert r["trend"].shape == (len(ts[i]),)
            assert r["uncertainty"].shape == (len(ts[i]),)


# ===================================================================
# Numerical correctness vs per-star calls
# ===================================================================


@requires_cuda
class TestBatchedMatchesPerStarGPU:
    """Batched results must match per-star results within tight tolerance."""

    def _per_star(self, t, f):
        """Reference per-star call to hierarchical_detrend."""
        L = len(f)
        ft = torch.tensor(f, dtype=torch.float32, device="cuda").unsqueeze(0)
        tt = torch.tensor(t, dtype=torch.float64, device="cuda").unsqueeze(0)
        vt = torch.ones(1, L, dtype=torch.bool, device="cuda")
        st = torch.zeros(1, L, dtype=torch.int32, device="cuda")
        det, trend, unc = hierarchical_detrend(
            ft, tt, vt, st, cadence_minutes=2.0,
        )
        return (
            det[0].cpu().numpy(),
            trend[0].cpu().numpy(),
            unc[0].cpu().numpy(),
        )

    def test_same_length_batch(self):
        """B=5 stars of identical length: batched == per-star."""
        ts, fs = zip(*(_make_star(2000, seed=s) for s in range(5)))
        ref = [self._per_star(t, f) for t, f in zip(ts, fs)]
        out = hierarchical_detrend_batch(
            list(ts), list(fs), cadence_minutes=2.0, device="cuda",
        )
        for i, r in enumerate(out):
            assert r is not None
            ref_det, ref_trend, ref_unc = ref[i]
            # Tolerance: per-position differences are dominated by float32
            # round-off in batched matmul; allow 100 ppm.
            assert np.allclose(r["detrended"], ref_det, atol=1e-4, equal_nan=True)
            assert np.allclose(r["trend"], ref_trend, atol=1e-4, equal_nan=True)

    def test_variable_length_batch(self):
        """Mixed lengths in same bucket: batched padded == per-star unpadded."""
        ts, fs = [], []
        for i, n in enumerate([1500, 1700, 1900, 2000]):
            t, f = _make_star(n, seed=i + 10)
            ts.append(t)
            fs.append(f)

        ref = [self._per_star(t, f) for t, f in zip(ts, fs)]
        out = hierarchical_detrend_batch(
            ts, fs, cadence_minutes=2.0, device="cuda",
        )
        for i, r in enumerate(out):
            assert r is not None
            ref_det, ref_trend, ref_unc = ref[i]
            # Unpadded slices should match
            assert r["detrended"].shape == ref_det.shape
            # Note: padding can leak slightly into the last few points of
            # a star within a batch because the L2 polynomial chunks see
            # zero-padded neighbours. Allow 200 ppm and trim edges in
            # the comparison.
            n = len(ts[i])
            edge = 50
            interior = slice(edge, n - edge)
            mask = np.isfinite(r["detrended"][interior]) & np.isfinite(ref_det[interior])
            assert mask.sum() > 0
            diff = np.abs(r["detrended"][interior][mask] - ref_det[interior][mask])
            assert diff.max() < 5e-3, f"max diff {diff.max():.6f}"

    def test_multi_bucket(self):
        """Stars in different buckets are processed separately but order preserved."""
        ts, fs = [], []
        # bucket 1000, 2000, 3000
        for n in [800, 1500, 2500, 900, 2300]:
            t, f = _make_star(n, seed=n)
            ts.append(t)
            fs.append(f)

        out = hierarchical_detrend_batch(
            ts, fs, cadence_minutes=2.0, device="cuda",
        )
        assert len(out) == len(ts)
        for i, r in enumerate(out):
            assert r is not None
            assert r["detrended"].shape == (len(ts[i]),)


# ===================================================================
# CPU path (no kernel needed)
# ===================================================================


class TestBatchedCPU:
    """Smoke tests on CPU so the wrapper is portable."""

    def test_cpu_constant_flux(self):
        """Constant flux on CPU: detrended ~1.0."""
        ts, fs = zip(*(_make_star(800, noise_std=0.0, seed=s) for s in range(3)))
        out = hierarchical_detrend_batch(
            list(ts), list(fs), cadence_minutes=2.0, device="cpu",
        )
        for r in out:
            assert r is not None
            finite = np.isfinite(r["detrended"])
            assert finite.any()
            assert np.allclose(r["detrended"][finite], 1.0, atol=1e-4)

    def test_too_short_skipped(self):
        """Stars shorter than 10 points are skipped (None in output)."""
        ts, fs = [], []
        # Two valid + one too-short
        for n in [800, 5, 1000]:
            t, f = _make_star(n)
            ts.append(t)
            fs.append(f)

        out = hierarchical_detrend_batch(
            ts, fs, cadence_minutes=2.0, device="cpu",
        )
        assert out[0] is not None
        assert out[1] is None  # too short
        assert out[2] is not None


# ===================================================================
# Speed (informational, not strict)
# ===================================================================


@requires_cuda
class TestBatchedSpeed:
    def test_speedup_vs_per_star(self):
        """Batched should be at least 1.5x faster than per-star on B=20."""
        import time as time_mod

        n_stars = 20
        L = 5000
        ts, fs = zip(*(_make_star(L, seed=s) for s in range(n_stars)))

        # Warmup
        _ = hierarchical_detrend_batch(
            list(ts), list(fs), cadence_minutes=2.0, device="cuda",
        )
        torch.cuda.synchronize()

        # Per-star reference
        torch.cuda.synchronize()
        t0 = time_mod.perf_counter()
        for t, f in zip(ts, fs):
            ft = torch.tensor(f, dtype=torch.float32, device="cuda").unsqueeze(0)
            tt = torch.tensor(t, dtype=torch.float64, device="cuda").unsqueeze(0)
            vt = torch.ones(1, L, dtype=torch.bool, device="cuda")
            st = torch.zeros(1, L, dtype=torch.int32, device="cuda")
            _ = hierarchical_detrend(ft, tt, vt, st, cadence_minutes=2.0)
        torch.cuda.synchronize()
        per_star_time = time_mod.perf_counter() - t0

        # Batched
        torch.cuda.synchronize()
        t0 = time_mod.perf_counter()
        _ = hierarchical_detrend_batch(
            list(ts), list(fs), cadence_minutes=2.0, device="cuda",
        )
        torch.cuda.synchronize()
        batched_time = time_mod.perf_counter() - t0

        speedup = per_star_time / batched_time
        print(
            f"\nB={n_stars}, L={L}: per-star {per_star_time*1000:.0f} ms, "
            f"batched {batched_time*1000:.0f} ms, speedup {speedup:.1f}x"
        )
        # Batched must be at least somewhat faster (lenient lower bound)
        assert speedup > 1.2, f"speedup {speedup:.1f}x not > 1.2x"
