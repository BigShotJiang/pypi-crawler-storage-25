"""Tests for hierarchical GPU kernel (Phase 2).

Test IDs map to docs/phases/PHASE-2-GPU-KERNEL.md.
Tests are skipped when no GPU is available.
"""

import math

import numpy as np
import torch
import pytest

from torchflat.hierarchical import layer1_local, _layer1_local_cpu, hierarchical_detrend

CADENCE = 2.0 / 1440.0
CADENCE_MIN = 2.0

requires_cuda = pytest.mark.skipif(
    not torch.cuda.is_available(),
    reason="CUDA/HIP not available",
)


def _has_hierarchical_kernel() -> bool:
    """Check if the hierarchical GPU kernel is loadable."""
    if not torch.cuda.is_available():
        return False
    try:
        from torchflat._kernel_loader import _get_hierarchical_kernel
        kern = _get_hierarchical_kernel()
        return kern is not None and hasattr(kern, "hierarchical_layer1")
    except Exception:
        return False


requires_kernel = pytest.mark.skipif(
    not _has_hierarchical_kernel(),
    reason="Hierarchical GPU kernel not compiled",
)


def _window_size(cadence: float = CADENCE, window_days: float = 0.5):
    W = max(3, round(window_days / cadence))
    return W | 1


def _make_lc_gpu(
    n_points: int = 5000,
    noise_std: float = 0.001,
    seed: int = 42,
    dtype: torch.dtype = torch.float32,
):
    """Create light curve on GPU."""
    rng = np.random.default_rng(seed)
    time = torch.arange(n_points, dtype=torch.float64, device="cuda").unsqueeze(0) * CADENCE
    flux = torch.ones(1, n_points, dtype=dtype, device="cuda")
    if noise_std > 0:
        noise = torch.tensor(
            rng.normal(0, noise_std, (1, n_points)), dtype=dtype, device="cuda"
        )
        flux = flux + noise
    valid = torch.ones(1, n_points, dtype=torch.bool, device="cuda")
    seg = torch.zeros(1, n_points, dtype=torch.int32, device="cuda")
    return time, flux, valid, seg


# ===================================================================
# 2.2 Layer 1 GPU kernel
# ===================================================================


@requires_kernel
class TestLayer1Kernel:
    """Tests T2.2.1 - T2.2.6."""

    W = _window_size()

    def test_numerical_agreement_with_cpu(self):
        """T2.2.1: GPU output matches CPU within tolerance."""
        n = 3000
        rng = np.random.default_rng(42)
        # Create on CPU first
        time_cpu = torch.arange(n, dtype=torch.float64).unsqueeze(0) * CADENCE
        flux_cpu = torch.ones(1, n, dtype=torch.float64) + torch.tensor(
            rng.normal(0, 0.001, (1, n)), dtype=torch.float64
        )
        valid_cpu = torch.ones(1, n, dtype=torch.bool)
        seg_cpu = torch.zeros(1, n, dtype=torch.int32)

        # CPU reference
        trend_cpu, scale_cpu, unc_cpu = _layer1_local_cpu(
            flux_cpu, time_cpu, valid_cpu, seg_cpu, self.W, 5, 5.0, 2.0
        )

        # GPU path
        flux_gpu = flux_cpu.float().cuda()
        time_gpu = time_cpu.cuda()
        valid_gpu = valid_cpu.cuda()
        seg_gpu = seg_cpu.cuda()

        trend_gpu, scale_gpu, unc_gpu = layer1_local(
            flux_gpu, time_gpu, valid_gpu, seg_gpu, window_size=self.W
        )

        # Compare (float32 GPU vs float64 CPU — allow ~100 ppm tolerance)
        trend_g = trend_gpu[0].double().cpu()
        trend_c = trend_cpu[0]
        both_finite = torch.isfinite(trend_g) & torch.isfinite(trend_c)
        if both_finite.any():
            diff_ppm = ((trend_g[both_finite] - trend_c[both_finite]) /
                        trend_c[both_finite].clamp(min=1e-10)).abs() * 1e6
            assert diff_ppm.median().item() < 100, f"median diff {diff_ppm.median():.1f} ppm"

    def test_no_nan_outputs(self):
        """T2.2.2: zero NaNs for valid input on GPU."""
        time, flux, valid, seg = _make_lc_gpu(5000)
        trend, scale, unc = layer1_local(flux, time, valid, seg, window_size=self.W)
        assert torch.isfinite(trend).all(), "trend has NaN/inf"
        assert torch.isfinite(scale).all(), "scale has NaN/inf"
        assert torch.isfinite(unc).all(), "uncertainty has NaN/inf"

    def test_edge_correctness(self):
        """T2.2.3: edge points valid with higher uncertainty."""
        time, flux, valid, seg = _make_lc_gpu(5000)
        trend, scale, unc = layer1_local(flux, time, valid, seg, window_size=self.W)

        half_w = self.W // 2
        edge_unc = unc[0, :half_w].mean().item()
        interior_unc = unc[0, half_w: -half_w].mean().item()
        assert edge_unc > interior_unc
        assert torch.isfinite(trend[0, 0])
        assert torch.isfinite(trend[0, -1])

    def test_batch_correctness(self):
        """T2.2.4: B=50 stars processed independently."""
        B, n = 50, 2000
        time = torch.arange(n, dtype=torch.float64, device="cuda").unsqueeze(0).expand(B, -1) * CADENCE
        valid = torch.ones(B, n, dtype=torch.bool, device="cuda")
        seg = torch.zeros(B, n, dtype=torch.int32, device="cuda")

        # Each star has a different flux level
        flux = torch.zeros(B, n, dtype=torch.float32, device="cuda")
        for i in range(B):
            flux[i] = 0.5 + i * 0.05  # 0.5 to 2.95

        trend, _, _ = layer1_local(flux, time, valid, seg, window_size=self.W)

        for i in range(B):
            expected = 0.5 + i * 0.05
            assert (trend[i] - expected).abs().max().item() < 0.01, (
                f"star {i}: trend {trend[i].mean():.4f} vs expected {expected:.4f}"
            )

    def test_speed(self):
        """T2.2.5: Layer 1 kernel completes in <2ms for B=50, L=14000."""
        B, L = 50, 14000
        time = torch.arange(L, dtype=torch.float64, device="cuda").unsqueeze(0).expand(B, -1) * CADENCE
        flux = torch.ones(B, L, dtype=torch.float32, device="cuda")
        valid = torch.ones(B, L, dtype=torch.bool, device="cuda")
        seg = torch.zeros(B, L, dtype=torch.int32, device="cuda")

        # Warmup
        _ = layer1_local(flux, time, valid, seg, window_size=self.W)
        torch.cuda.synchronize()

        # Timed run
        import time as time_mod
        torch.cuda.synchronize()
        t0 = time_mod.perf_counter()
        _ = layer1_local(flux, time, valid, seg, window_size=self.W)
        torch.cuda.synchronize()
        elapsed_ms = (time_mod.perf_counter() - t0) * 1000

        per_star_ms = elapsed_ms / B
        print(f"\nLayer 1 kernel: {elapsed_ms:.1f} ms total, {per_star_ms:.2f} ms/star")
        # Target: <2ms per star (generous for different GPUs)
        assert per_star_ms < 10, f"too slow: {per_star_ms:.2f} ms/star"

    def test_constant_input(self):
        """T2.2.6: constant flux -> trend=1.0 on GPU."""
        time, flux, valid, seg = _make_lc_gpu(3000, noise_std=0.0, dtype=torch.float32)
        flux[:] = 1.0
        trend, _, unc = layer1_local(flux, time, valid, seg, window_size=self.W)
        assert torch.allclose(trend, torch.ones_like(trend), atol=1e-5)


# ===================================================================
# 2.4 Full GPU pipeline
# ===================================================================


@requires_cuda
class TestFullGPUPipeline:
    """Tests T2.4.1 - T2.4.5 (runs on GPU even without custom kernel,
    using CPU fallback for Layer 1 if needed)."""

    def test_end_to_end_gpu(self):
        """T2.4.1 (adapted): end-to-end on GPU produces valid output."""
        n = 3000
        time = torch.arange(n, dtype=torch.float64, device="cuda").unsqueeze(0) * CADENCE
        flux = torch.ones(1, n, dtype=torch.float64, device="cuda")
        valid = torch.ones(1, n, dtype=torch.bool, device="cuda")
        seg = torch.zeros(1, n, dtype=torch.int32, device="cuda")

        det, trend, unc = hierarchical_detrend(flux, time, valid, seg)
        assert det.device.type == "cuda"
        finite = torch.isfinite(det)
        assert finite.any()
        assert torch.allclose(det[finite], torch.ones_like(det[finite]), atol=1e-5)

    def test_vram_usage(self):
        """T2.4.4: VRAM usage <500 MB for B=50."""
        B, L = 50, 14000
        time = torch.arange(L, dtype=torch.float64, device="cuda").unsqueeze(0).expand(B, -1) * CADENCE
        flux = torch.ones(B, L, dtype=torch.float32, device="cuda")
        valid = torch.ones(B, L, dtype=torch.bool, device="cuda")
        seg = torch.zeros(B, L, dtype=torch.int32, device="cuda")

        torch.cuda.reset_peak_memory_stats()
        _ = hierarchical_detrend(flux, time, valid, seg)
        peak_mb = torch.cuda.max_memory_allocated() / 1024**2
        print(f"\nVRAM peak: {peak_mb:.0f} MB")
        assert peak_mb < 500, f"VRAM {peak_mb:.0f} MB exceeds 500 MB"

    def test_no_memory_leak(self):
        """T2.4.5: run 20 batches, VRAM stays stable."""
        B, L = 5, 3000
        time = torch.arange(L, dtype=torch.float64, device="cuda").unsqueeze(0).expand(B, -1) * CADENCE
        flux = torch.ones(B, L, dtype=torch.float32, device="cuda")
        valid = torch.ones(B, L, dtype=torch.bool, device="cuda")
        seg = torch.zeros(B, L, dtype=torch.int32, device="cuda")

        # Warmup
        _ = hierarchical_detrend(flux, time, valid, seg)
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()

        baseline = torch.cuda.memory_allocated()
        for _ in range(20):
            _ = hierarchical_detrend(flux, time, valid, seg)
        torch.cuda.synchronize()
        final = torch.cuda.memory_allocated()

        growth_mb = (final - baseline) / 1024**2
        assert growth_mb < 50, f"VRAM grew by {growth_mb:.1f} MB over 20 batches"


# ===================================================================
# 2.5 JIT compilation and loader
# ===================================================================


class TestKernelLoader:
    """Tests T2.5.4, T2.5.5."""

    def test_fallback_on_cpu(self):
        """T2.5.4: CPU input uses fallback without error."""
        n = 2000
        time = torch.arange(n, dtype=torch.float64).unsqueeze(0) * CADENCE
        flux = torch.ones(1, n, dtype=torch.float64)
        valid = torch.ones(1, n, dtype=torch.bool)
        seg = torch.zeros(1, n, dtype=torch.int32)

        det, trend, unc = hierarchical_detrend(flux, time, valid, seg)
        assert det.device.type == "cpu"
        assert torch.isfinite(det).any()

    def test_import(self):
        """T2.5.5: hierarchical_detrend importable."""
        from torchflat import hierarchical_detrend as hd
        assert callable(hd)


# ===================================================================
# 2.6 Speed benchmarking (informational, not strict pass/fail)
# ===================================================================


@requires_kernel
class TestSpeedBenchmark:
    """Tests T2.6.1 - T2.6.3."""

    def test_tess_speed(self):
        """T2.6.1: <5ms per star on TESS (B=50, L=14000)."""
        import time as time_mod

        B, L = 50, 14000
        W = _window_size()
        time_t = torch.arange(L, dtype=torch.float64, device="cuda").unsqueeze(0).expand(B, -1) * CADENCE
        flux = torch.ones(B, L, dtype=torch.float32, device="cuda") + 0.001 * torch.randn(B, L, device="cuda")
        valid = torch.ones(B, L, dtype=torch.bool, device="cuda")
        seg = torch.zeros(B, L, dtype=torch.int32, device="cuda")

        # Warmup
        _ = hierarchical_detrend(flux, time_t, valid, seg)
        torch.cuda.synchronize()

        # Timed
        torch.cuda.synchronize()
        t0 = time_mod.perf_counter()
        _ = hierarchical_detrend(flux, time_t, valid, seg)
        torch.cuda.synchronize()
        elapsed_ms = (time_mod.perf_counter() - t0) * 1000

        per_star = elapsed_ms / B
        print(f"\nTESS full pipeline: {elapsed_ms:.1f} ms, {per_star:.2f} ms/star")
        assert per_star < 20, f"too slow: {per_star:.2f} ms/star"

    def test_kepler_speed(self):
        """T2.6.2: <2ms per star on Kepler (B=50, L=4000)."""
        import time as time_mod

        B, L = 50, 4000
        kepler_cadence = 30.0 / 1440.0
        time_t = torch.arange(L, dtype=torch.float64, device="cuda").unsqueeze(0).expand(B, -1) * kepler_cadence
        flux = torch.ones(B, L, dtype=torch.float32, device="cuda") + 0.001 * torch.randn(B, L, device="cuda")
        valid = torch.ones(B, L, dtype=torch.bool, device="cuda")
        seg = torch.zeros(B, L, dtype=torch.int32, device="cuda")

        # Warmup
        _ = hierarchical_detrend(flux, time_t, valid, seg, cadence_minutes=30.0)
        torch.cuda.synchronize()

        torch.cuda.synchronize()
        t0 = time_mod.perf_counter()
        _ = hierarchical_detrend(flux, time_t, valid, seg, cadence_minutes=30.0)
        torch.cuda.synchronize()
        elapsed_ms = (time_mod.perf_counter() - t0) * 1000

        per_star = elapsed_ms / B
        print(f"\nKepler full pipeline: {elapsed_ms:.1f} ms, {per_star:.2f} ms/star")
        assert per_star < 10, f"too slow: {per_star:.2f} ms/star"

    def test_vs_umi_speed(self):
        """T2.6.3: hierarchical <10x slower than UMI."""
        import time as time_mod
        from torchflat.umi import umi_detrend

        B, L = 50, 14000
        time_t = torch.arange(L, dtype=torch.float64, device="cuda").unsqueeze(0).expand(B, -1) * CADENCE
        flux = torch.ones(B, L, dtype=torch.float32, device="cuda") + 0.001 * torch.randn(B, L, device="cuda")
        valid = torch.ones(B, L, dtype=torch.bool, device="cuda")
        seg = torch.zeros(B, L, dtype=torch.int32, device="cuda")

        # UMI
        _ = umi_detrend(flux, time_t, valid, seg)
        torch.cuda.synchronize()
        t0 = time_mod.perf_counter()
        _ = umi_detrend(flux, time_t, valid, seg)
        torch.cuda.synchronize()
        umi_ms = (time_mod.perf_counter() - t0) * 1000

        # Hierarchical
        _ = hierarchical_detrend(flux, time_t, valid, seg)
        torch.cuda.synchronize()
        t0 = time_mod.perf_counter()
        _ = hierarchical_detrend(flux, time_t, valid, seg)
        torch.cuda.synchronize()
        hier_ms = (time_mod.perf_counter() - t0) * 1000

        ratio = hier_ms / max(umi_ms, 0.01)
        print(f"\nUMI: {umi_ms:.1f} ms, Hierarchical: {hier_ms:.1f} ms, ratio: {ratio:.1f}x")
        assert ratio < 10, f"hierarchical is {ratio:.1f}x slower than UMI (limit: 10x)"
