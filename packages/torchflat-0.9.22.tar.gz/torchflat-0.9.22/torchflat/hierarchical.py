"""Hierarchical Multi-Scale Asymmetric Detrending.

Three-layer hierarchy:
  Layer 1 (workers):     Per-data-point local asymmetric estimation
  Layer 2 (supervisors): IRLS polynomial chunk fitting with overlap blending
  Layer 3 (global):      Variability model + per-star bias correction
  Layer 1 (informed):    Second pass on residuals with global context

Two execution paths for Layer 1 (identical algorithm):
  - GPU kernel (HIP/CUDA): one thread per data point, quickselect + bisquare
  - CPU fallback: per-position loop with PyTorch (no compilation needed)
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass

import torch

from torchflat._utils import masked_median

logger = logging.getLogger("torchflat")


# ---------------------------------------------------------------------------
# Factored correlation structure (Track C)
# ---------------------------------------------------------------------------

@dataclass
class CorrelationStructure:
    """Factored approximation of the noise covariance from hierarchical detrending.

    The full noise covariance Σ ∈ ℝ^{L×L} is impractical to store
    (~1.5 GB for one TESS sector).  Instead we approximate it as the
    product of three small components, each derived from one layer of
    the hierarchy:

        Σ(i, j) ≈ s² · σ(i) · σ(j) · ρ_local(|i-j|) · ρ_chunk(i, j) · ρ_global(i, j)

    Where:

      ρ_local(d) = max(0, 1 − d/W)
        — windowed Layer 1 estimates at distance d share (W − d) of the
          same input points, so they are linearly correlated through that
          shared data.

      ρ_chunk(i, j) = 1 if same Layer 2 chunk
                     ≈ 0.3 if adjacent chunks (overlap-blending region)
                     0 otherwise
        — points within one polynomial chunk share its coefficients.

      ρ_global(i, j) = (1 + cos(2π Δt / P)) / 2 if rotation period P detected
                      = 1 otherwise
        — when Layer 3 subtracted a sinusoid, points at the same rotation
          phase share that subtraction and are correlated through it.
          When no rotation was extracted this layer adds no extra
          correlation (factor of 1).

      s = ``sigma_calibration``
        — empirical scale factor applied to all sigmas.  Defaults to 1.0
          but a Monte-Carlo validation
          (``benchmarks/hierarchical/correlation_mc.py``) on synthetic
          TESS-like noise found that the analytical per-point ``σ`` from
          ``hierarchical_detrend`` underestimates the true trend
          standard error by ~1.7× on flat stars and ~2.1× on rotators.
          Set ``sigma_calibration`` ≈ 2.0 to apply this correction;
          downstream users requiring well-calibrated absolute
          uncertainties (transit depth fits, BLS SDE) should do so.

    Total storage: a handful of scalars + one tensor of length B.  No
    matrix is ever materialised; correlation blocks are computed on
    demand for any subset of indices the caller cares about
    (e.g. an in-transit window).

    Notes:
      • This is an approximation, not a full GP covariance.  It is good
        enough for transit depth uncertainty propagation and BLS
        false-alarm rate corrections, but not for full Bayesian
        inference.

      • Per-point variance σ(i)² is the ``uncertainty`` output of
        :func:`hierarchical_detrend`.  This dataclass adds the
        off-diagonal *correlation* structure plus an optional scalar
        recalibration of the diagonal.

      • The factored correlation values are biased toward over-estimating
        small-distance correlations (analytical 0.99 vs empirical 0.85
        at d=1) because the bisquare iterations and polynomial refits
        weaken the linear coupling assumed by the simple shared-data
        analysis.  This bias is small in absolute terms (~0.05–0.15 in
        ρ) and acceptable for the intended use cases.
    """

    window_size: int                  # Layer 1 window width (samples)
    chunk_size: int                   # Layer 2 chunk width (samples)
    chunk_overlap: int                # Layer 2 overlap region width (samples)
    cadence_days: float
    rotation_period_days: torch.Tensor  # [B]; NaN where no rotation detected
    sigma_calibration: float = 1.0      # multiplicative scale on per-point sigmas

    def correlation_block(
        self,
        uncertainty: torch.Tensor,    # [L] per-point sigma for one star
        indices: torch.Tensor,        # [k] long tensor of point indices
        star: int = 0,
    ) -> torch.Tensor:
        """Build a [k, k] noise covariance matrix for the given indices.

        Args:
            uncertainty: 1-D tensor of length L with per-point sigmas
                (the ``uncertainty`` output of hierarchical_detrend).
            indices: 1-D long tensor of point indices to include.
            star: which star in the batch the rotation parameters refer to.

        Returns:
            ``[k, k]`` covariance matrix as a tensor on the same device
            and dtype as ``uncertainty``.  Symmetric, positive
            semi-definite by construction (each correlation factor is
            non-negative).
        """
        if indices.dim() != 1:
            raise ValueError("indices must be 1-D")
        device = uncertainty.device
        dtype = uncertainty.dtype
        idx = indices.to(device=device, dtype=torch.long)

        # Pairwise distances [k, k]
        i_grid = idx.unsqueeze(0)
        j_grid = idx.unsqueeze(1)
        d = (i_grid - j_grid).abs().to(dtype)

        # ρ_local — triangular kernel from window overlap
        local = (1.0 - d / float(self.window_size)).clamp(min=0.0)

        # ρ_chunk — same chunk: 1, adjacent chunks: 0.3, else 0
        chunk_i = i_grid // self.chunk_size
        chunk_j = j_grid // self.chunk_size
        chunk_d = (chunk_i - chunk_j).abs()
        chunk = torch.where(
            chunk_d == 0,
            torch.ones_like(d),
            torch.where(
                chunk_d == 1,
                torch.full_like(d, 0.3),
                torch.zeros_like(d),
            ),
        )

        # ρ_global — rotation phase correlation if rotation was detected.
        # When no rotation was extracted, this layer adds no extra
        # correlation: ρ_global ≡ 1 everywhere (so local × chunk × global
        # reduces to local × chunk).  When rotation is detected, the
        # subtracted sinusoid couples points at the same phase.
        rp = float(self.rotation_period_days[star].item())
        if rp != rp or rp <= 0:  # NaN or invalid → no extra coupling
            global_corr = torch.ones_like(d)
        else:
            n_cad_per_period = rp / max(self.cadence_days, 1e-10)
            phase_diff = (d / n_cad_per_period) * (2.0 * math.pi)
            global_corr = (1.0 + torch.cos(phase_diff)) / 2.0

        rho = local * chunk * global_corr

        sigma = uncertainty[idx] * float(self.sigma_calibration)  # [k]
        cov = sigma.unsqueeze(0) * sigma.unsqueeze(1) * rho  # [k, k]
        return cov

    def transit_depth_uncertainty(
        self,
        uncertainty: torch.Tensor,
        in_transit_indices: torch.Tensor,
        out_transit_indices: torch.Tensor,
        star: int = 0,
    ) -> float:
        """Properly correlated standard error on a measured transit depth.

        Computes the uncertainty on::

            depth = mean(out_of_transit) − mean(in_transit)

        accounting for correlations within and between the in-transit
        and out-of-transit point sets.  The naive (independent) version
        underestimates this when neighbouring points are correlated.

        Returns the depth uncertainty as a Python float.
        """
        n_in = int(in_transit_indices.numel())
        n_out = int(out_transit_indices.numel())
        if n_in == 0 or n_out == 0:
            return float("nan")

        all_idx = torch.cat([in_transit_indices, out_transit_indices])
        cov = self.correlation_block(uncertainty, all_idx, star=star)

        # Linear contrast c = -1/n_in for in-transit, +1/n_out for out
        c = torch.cat([
            torch.full((n_in,), -1.0 / n_in, device=cov.device, dtype=cov.dtype),
            torch.full((n_out,), 1.0 / n_out, device=cov.device, dtype=cov.dtype),
        ])
        var = (c.unsqueeze(0) @ cov @ c.unsqueeze(1)).item()
        return float(max(var, 0.0) ** 0.5)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_MIN_WINDOW_VALID = 10       # Minimum valid points in a partial window
_LARGE_UNCERTAINTY = 1.0     # Uncertainty assigned to degenerate windows

# NOTE on bias correction:
#   Earlier versions scaled an additive `bias_correction` into the final
#   trend (trend = expected_flux + local_corr - bias).  Empirical testing
#   (benchmarks/hierarchical/calibrate_bias_slope.py) showed this is
#   architecturally a no-op: a uniform additive shift to the trend has
#   zero effect on relative transit depth (out_median - in_median).
#   The `bias_correction` output is therefore always zero; we keep it in
#   the API for backwards compatibility.  The residual per-star bias
#   on random TESS stars at 0.1% depth is ~166 ppm (below UMI's 182 ppm
#   and well within the T3.6.1 gate of 200 ppm).  Reducing it further
#   would require a multiplicative depth-scaling correction, which needs
#   to be depth-dependent and is deferred to future work.


# ---------------------------------------------------------------------------
# Layer 1: Per-data-point local asymmetric estimation
# ---------------------------------------------------------------------------

def layer1_local(
    flux: torch.Tensor,
    time: torch.Tensor,
    valid_mask: torch.Tensor,
    segment_id: torch.Tensor,
    window_size: int = 361,
    n_iter: int = 5,
    cval: float = 5.0,
    asymmetry: float = 2.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Per-data-point local trend estimation with partial-window edge handling.

    Unlike UMI which maps one thread per window *position* and produces NaN
    at edges, this maps one computation per data *point*.  Edge points use
    partial (smaller) windows and still produce a trend estimate.

    Two paths (identical algorithm, identical results):
      - GPU kernel: one thread per (star, data_point), quickselect + bisquare
      - CPU fallback: per-position loop with PyTorch (no compilation needed)

    Args:
        flux:        ``[B, L]`` flux values.
        time:        ``[B, L]`` timestamps.
        valid_mask:  ``[B, L]`` boolean (True = valid).
        segment_id:  ``[B, L]`` int32 segment labels.
        window_size: Full window width (samples).  Must be odd.
        n_iter:      Number of asymmetric bisquare iterations.
        cval:        Rejection threshold in scale units.
        asymmetry:   Downward-deviation penalty (2.0 = default UMI).

    Returns:
        trend:       ``[B, L]`` local trend estimate per point.
        scale:       ``[B, L]`` upper-RMS noise scale per point.
        uncertainty: ``[B, L]`` weighted standard error per point.
    """
    W = window_size

    # Try GPU kernel path
    _use_kernel = False
    _why_no_kernel = ""
    if not flux.is_cuda:
        _why_no_kernel = "not on cuda"
    elif W > 512:
        _why_no_kernel = f"W={W} > 512"
    else:
        from torchflat._kernel_loader import _get_hierarchical_kernel
        _kern = _get_hierarchical_kernel()
        if _kern is None:
            _why_no_kernel = "kernel module is None"
        elif not hasattr(_kern, "hierarchical_layer1"):
            _why_no_kernel = "kernel module missing hierarchical_layer1"
        else:
            _use_kernel = True

    if not _use_kernel and flux.is_cuda and not getattr(layer1_local, "_warned", False):
        logger.warning(
            f"Hierarchical kernel not available ({_why_no_kernel}), using CPU fallback. "
            f"Install ROCm/CUDA toolkit to enable the fused kernel."
        )
        layer1_local._warned = True

    if _use_kernel:
        seg32 = segment_id.to(torch.int32) if segment_id.dtype != torch.int32 else segment_id
        results = _kern.hierarchical_layer1(
            flux, valid_mask, seg32,
            int(W), float(cval), float(asymmetry), int(n_iter),
        )
        return results[0], results[1], results[2]

    # CPU fallback: per-position loop
    return _layer1_local_cpu(flux, time, valid_mask, segment_id, W, n_iter, cval, asymmetry)


def _layer1_local_cpu(
    flux: torch.Tensor,
    time: torch.Tensor,
    valid_mask: torch.Tensor,
    segment_id: torch.Tensor,
    window_size: int,
    n_iter: int,
    cval: float,
    asymmetry: float,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """CPU fallback for Layer 1 (per-position loop)."""
    B, L = flux.shape
    device = flux.device
    dtype = flux.dtype

    W = window_size
    half_w = W // 2

    trend = torch.zeros(B, L, dtype=dtype, device=device)
    scale = torch.zeros(B, L, dtype=dtype, device=device)
    uncertainty = torch.full((B, L), _LARGE_UNCERTAINTY, dtype=dtype, device=device)

    for i in range(L):
        w_start = max(0, i - half_w)
        w_end = min(L, i + half_w + 1)

        win_flux = flux[:, w_start:w_end]
        win_valid = valid_mask[:, w_start:w_end]
        win_seg = segment_id[:, w_start:w_end]

        center_seg = segment_id[:, i : i + 1]
        seg_match = win_seg == center_seg
        win_valid = win_valid & seg_match

        n_valid = win_valid.sum(dim=-1)
        degenerate = n_valid < _MIN_WINDOW_VALID

        loc = masked_median(win_flux, win_valid)

        residuals = win_flux - loc.unsqueeze(-1)
        above = (residuals > 0) & win_valid
        n_above = above.sum(dim=-1).clamp(min=1).to(dtype)
        upper_sq = ((residuals ** 2) * above.to(dtype)).sum(dim=-1)
        upper_rms = (upper_sq / n_above).sqrt()
        sc = upper_rms * 0.6745

        safe_scale = (cval * sc.clamp(min=1e-10)).unsqueeze(-1)
        valid_f = win_valid.to(dtype)

        for _ in range(n_iter):
            u = (win_flux - loc.unsqueeze(-1)) / safe_scale
            u_eff = torch.where(u < 0, u * asymmetry, u)
            u_abs = u_eff.abs()
            weights = ((1.0 - u_abs ** 2) ** 2) * (u_abs < 1.0).to(dtype) * valid_f
            w_sum = weights.sum(dim=-1).clamp(min=1e-10)
            loc = (win_flux * weights).sum(dim=-1) / w_sum

        res = win_flux - loc.unsqueeze(-1)
        w_var = (weights * res ** 2).sum(dim=-1) / w_sum
        unc = w_var.sqrt() / w_sum.sqrt()

        loc = torch.where(degenerate, masked_median(win_flux, win_valid), loc)
        sc = torch.where(degenerate, torch.full_like(sc, _LARGE_UNCERTAINTY), sc)
        unc = torch.where(degenerate, torch.full_like(unc, _LARGE_UNCERTAINTY), unc)

        trend[:, i] = loc
        scale[:, i] = sc
        uncertainty[:, i] = unc

    return trend, scale, uncertainty


# ---------------------------------------------------------------------------
# Layer 2: Supervisor chunk modelling (IRLS polynomial)
# ---------------------------------------------------------------------------

def _compute_chunk_params(cadence_minutes: float, L: int):
    """Return (chunk_size_points, overlap, poly_degree) for a given cadence."""
    chunk_hours = max(5.0, 15.0 * cadence_minutes / 60.0)
    chunk_points = max(15, round(chunk_hours * 60.0 / cadence_minutes))
    # Overlap: 10 for TESS-like, 5 for Kepler-like
    overlap = 10 if chunk_points >= 50 else 5
    return chunk_points, overlap


def _select_poly_degree(n_points: int) -> int:
    if n_points >= 50:
        return 2
    elif n_points >= 15:
        return 1
    else:
        return -1  # sentinel: use robust median


def _irls_poly_fit(
    t: torch.Tensor,
    y: torch.Tensor,
    w0: torch.Tensor,
    degree: int,
    n_iter: int = 5,
    asymmetry: float = 2.0,
    cval: float = 5.0,
) -> torch.Tensor:
    """IRLS polynomial fit with asymmetric bisquare weights.

    Args:
        t: [N] normalised time coordinates (centered, scaled to ~[-1, 1]).
        y: [N] values to fit (Layer 1 trends for one chunk of one star).
        w0: [N] initial weights (e.g. 1/scale^2 from Layer 1).
        degree: Polynomial degree (1 or 2).
        n_iter: IRLS iterations.
        asymmetry: Downward penalty.
        cval: Rejection threshold in scale units.

    Returns:
        coeffs: [degree+1] polynomial coefficients (constant first).
    """
    N = t.shape[0]
    dtype = t.dtype
    device = t.device

    # Vandermonde matrix [N, degree+1]
    cols = [torch.ones(N, dtype=dtype, device=device)]
    for d in range(1, degree + 1):
        cols.append(t ** d)
    X = torch.stack(cols, dim=-1)  # [N, degree+1]

    weights = w0.clone()

    coeffs = torch.zeros(degree + 1, dtype=dtype, device=device)
    for _ in range(n_iter):
        # Weighted least squares: (X^T W X) c = X^T W y
        W = torch.diag(weights)          # [N, N]
        XtW = X.T @ W                    # [D+1, N]
        A = XtW @ X                      # [D+1, D+1]
        b = XtW @ y                      # [D+1]
        try:
            coeffs = torch.linalg.solve(A, b)
        except torch.linalg.LinAlgError:
            # Singular — fall back to lstsq
            coeffs = torch.linalg.lstsq(A, b.unsqueeze(-1)).solution.squeeze(-1)

        # Residuals and asymmetric bisquare weights
        fitted = X @ coeffs
        res = y - fitted
        sc = res[res > 0].abs()
        if sc.numel() < 2:
            break
        mad_scale = sc.median() / 0.6745
        safe = (cval * mad_scale).clamp(min=1e-10)
        u = res / safe
        u_eff = torch.where(u < 0, u * asymmetry, u)
        u_abs = u_eff.abs()
        weights = ((1.0 - u_abs ** 2) ** 2) * (u_abs < 1.0).to(dtype) * w0

    return coeffs


def _batched_irls(
    X: torch.Tensor,        # [BC, K, D+1]
    y: torch.Tensor,        # [BC, K]
    w0: torch.Tensor,       # [BC, K]
    valid: torch.Tensor,    # [BC, K] bool
    n_iter: int,
    asymmetry: float,
    cval: float,
) -> torch.Tensor:
    """Batched IRLS polynomial fit.

    Solves BC independent weighted-least-squares systems with bisquare
    asymmetric reweighting.  Uses torch.linalg.solve with a small ridge
    so it never fails on singular chunks (returns near-zero coeffs).
    Returns coeffs ``[BC, D+1]``.
    """
    BC, K, D1 = X.shape
    dtype = X.dtype
    device = X.device

    valid_f = valid.to(dtype)
    weights = w0 * valid_f  # [BC, K]

    # Tiny absolute ridge — only stabilises true zero matrices.
    eye = torch.eye(D1, dtype=dtype, device=device).unsqueeze(0)
    ridge = 1e-10 * eye

    # Initial fallback coeffs: constant = weighted mean of y.
    # This ensures singular chunks behave like a no-op (return median).
    w_total = weights.sum(dim=-1, keepdim=True).clamp(min=1e-10)
    y_mean = (y * weights).sum(dim=-1, keepdim=True) / w_total
    fallback = torch.zeros(BC, D1, dtype=dtype, device=device)
    fallback[:, 0:1] = y_mean

    coeffs = fallback.clone()
    last_good = fallback.clone()
    for _ in range(n_iter):
        # X^T W X = X.transpose @ (X * w[..., None])
        Xw = X * weights.unsqueeze(-1)              # [BC, K, D+1]
        XtWX = X.transpose(-1, -2) @ Xw + ridge      # [BC, D+1, D+1]
        XtWy = (Xw * y.unsqueeze(-1)).sum(dim=1)     # [BC, D+1]
        # Per-chunk safe solve: solve_ex returns info[i] != 0 for singular.
        coeffs_new, info = torch.linalg.solve_ex(XtWX, XtWy.unsqueeze(-1))
        coeffs_new = coeffs_new.squeeze(-1)
        # For chunks that failed, fall back to last good coeffs (or constant fit).
        ok = (info == 0).unsqueeze(-1)
        coeffs = torch.where(ok, coeffs_new, last_good)
        last_good = coeffs

        # Residuals
        fitted = (X * coeffs.unsqueeze(1)).sum(dim=-1)  # [BC, K]
        res = (y - fitted) * valid_f                    # zero invalid
        # Robust scale: MAD of positive residuals (per chunk)
        pos = res.clamp(min=0)
        # Use mean of positive values as a cheap scale estimate
        # (avoids per-row median which is slow)
        n_pos = (pos > 0).to(dtype).sum(dim=-1).clamp(min=1)
        scale = (pos.sum(dim=-1) / n_pos) / 0.6745
        scale = scale.clamp(min=1e-10)
        safe = (cval * scale).unsqueeze(-1)             # [BC, 1]
        u = res / safe
        u_eff = torch.where(u < 0, u * asymmetry, u)
        u_abs = u_eff.abs()
        bisq = (1.0 - u_abs ** 2) ** 2
        bisq = bisq * (u_abs < 1.0).to(dtype)
        weights = bisq * w0 * valid_f

    return coeffs


def layer2_supervisor(
    trend_l1: torch.Tensor,
    scale_l1: torch.Tensor,
    time: torch.Tensor,
    valid_mask: torch.Tensor,
    segment_id: torch.Tensor,
    cadence_minutes: float = 2.0,
    n_irls_iter: int = 5,
    asymmetry: float = 2.0,
    flux: torch.Tensor | None = None,
    flag_sigma: float = 3.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Vectorised supervisor: IRLS polynomial fit per time-based chunk.

    All ``B*C`` chunks are processed in a single batched IRLS over
    ``[B*C, K, 3]`` design matrices.  Roughly 100x faster than the
    per-chunk Python loop on GPU.

    Args:
        trend_l1:     ``[B, L]`` Layer 1 trend.
        scale_l1:     ``[B, L]`` Layer 1 scale.
        time:         ``[B, L]`` timestamps.
        valid_mask:   ``[B, L]`` boolean.
        segment_id:   ``[B, L]`` segment labels.
        cadence_minutes: Observation cadence.
        n_irls_iter:  IRLS iterations per chunk.
        asymmetry:    Downward penalty.
        flux:         ``[B, L]`` original flux for transit flagging.

    Returns:
        poly_trend:    ``[B, L]`` polynomial trend at each point.
        transit_flags: ``[B, L]`` bool — suspected transit locations.
        chunk_noise:   ``[B, C]`` per-chunk noise.
    """
    flag_source = flux if flux is not None else trend_l1
    B, L = trend_l1.shape
    device = trend_l1.device
    dtype = trend_l1.dtype

    chunk_size, overlap = _compute_chunk_params(cadence_minutes, L)
    chunk_len = chunk_size + 2 * overlap     # extended chunk width K
    # Number of chunks needed to cover L (with last chunk possibly partial)
    C = (L + chunk_size - 1) // chunk_size

    # Pad inputs by `overlap` on each side and an extra (chunk_size*C - L)
    # at the right so unfold can produce exactly C chunks.
    pad_right = max(0, chunk_size * C + overlap - L) + overlap
    pad_left = overlap

    def _pad(t, fill):
        return torch.nn.functional.pad(t.unsqueeze(0), (pad_left, pad_right),
                                       mode="constant", value=fill).squeeze(0)

    trend_pad = _pad(trend_l1, 0.0)
    scale_pad = _pad(scale_l1, 1.0)
    valid_pad = torch.nn.functional.pad(
        valid_mask.unsqueeze(0), (pad_left, pad_right), value=False
    ).squeeze(0)
    seg_pad = torch.nn.functional.pad(
        segment_id.unsqueeze(0), (pad_left, pad_right), value=-1
    ).squeeze(0)
    time_pad = _pad(time, 0.0)
    flag_pad = _pad(flag_source, 0.0)

    # Unfold into [B, C, K] chunks (step=chunk_size, size=chunk_len)
    # K = chunk_size + 2*overlap covers core + overlap on both sides.
    trend_chunks = trend_pad.unfold(1, chunk_len, chunk_size)  # [B, C', K]
    scale_chunks = scale_pad.unfold(1, chunk_len, chunk_size)
    valid_chunks = valid_pad.unfold(1, chunk_len, chunk_size)
    seg_chunks = seg_pad.unfold(1, chunk_len, chunk_size)
    time_chunks = time_pad.unfold(1, chunk_len, chunk_size)
    flag_chunks = flag_pad.unfold(1, chunk_len, chunk_size)

    # Crop to exactly C chunks
    C_actual = trend_chunks.size(1)
    if C_actual > C:
        trend_chunks = trend_chunks[:, :C]
        scale_chunks = scale_chunks[:, :C]
        valid_chunks = valid_chunks[:, :C]
        seg_chunks = seg_chunks[:, :C]
        time_chunks = time_chunks[:, :C]
        flag_chunks = flag_chunks[:, :C]
    else:
        C = C_actual

    # Dominant segment per chunk: take the segment of the FIRST valid
    # point in each chunk.  This is robust to chunks that extend past L
    # (last chunk) where the center falls in the padding region.
    valid_int = valid_chunks.to(torch.int8)
    first_valid_idx = valid_int.argmax(dim=-1, keepdim=True)  # [B, C, 1]
    center_seg = seg_chunks.gather(-1, first_valid_idx)  # [B, C, 1]
    chunk_valid = valid_chunks & (seg_chunks == center_seg)

    # Flatten star and chunk dims for batched IRLS
    BC = B * C
    K = chunk_len
    trend_flat = trend_chunks.reshape(BC, K)
    scale_flat = scale_chunks.reshape(BC, K).clamp(min=1e-10)
    valid_flat = chunk_valid.reshape(BC, K)
    time_flat = time_chunks.reshape(BC, K)
    flag_flat = flag_chunks.reshape(BC, K)
    valid_orig_flat = valid_chunks.reshape(BC, K)  # for transit-flag output

    valid_f = valid_flat.to(dtype)
    n_valid_per_chunk = valid_f.sum(dim=-1)  # [BC]

    # Normalise time to [-1, 1] per chunk (centered on chunk middle)
    # Use only valid points for centering, but evaluate at all K positions.
    t_sum = (time_flat * valid_f).sum(dim=-1)
    t_center = t_sum / n_valid_per_chunk.clamp(min=1)
    t_centered = (time_flat - t_center.unsqueeze(-1))
    # Span: max - min of valid points
    t_masked_high = torch.where(valid_flat, t_centered, torch.full_like(t_centered, -1e30))
    t_masked_low = torch.where(valid_flat, t_centered, torch.full_like(t_centered, 1e30))
    t_max = t_masked_high.max(dim=-1).values
    t_min = t_masked_low.min(dim=-1).values
    t_span = (t_max - t_min).clamp(min=1e-10)
    t_norm = (t_centered / (t_span.unsqueeze(-1) / 2.0)).to(dtype)  # [BC, K]

    # Build Vandermonde [BC, K, 3] for degree 2.
    # Degree 3 was tried with BIC model selection; it regressed on both
    # random and variable star tests (noise in the cubic term dominates
    # any signal gain).  Sticking with deg 2.
    ones = torch.ones_like(t_norm)
    X = torch.stack([ones, t_norm, t_norm ** 2], dim=-1)  # [BC, K, 3]

    # Initial weights: 1/scale^2 normalised, masked
    w0 = 1.0 / (scale_flat ** 2)
    w0 = w0 * valid_f
    w0_sum = w0.sum(dim=-1, keepdim=True).clamp(min=1e-10)
    w0 = w0 / w0_sum

    # Initial IRLS pass on Layer 1 trends (no transit mask yet)
    coeffs = _batched_irls(X, trend_flat, w0, valid_flat, n_irls_iter, asymmetry, 5.0)

    # -------------------------------------------------------------
    # Iterative transit-masked refit with frozen noise threshold.
    #
    # Problem: Layer 1's asymmetric bisquare isn't perfect — the trend
    # gets slightly pulled into the transit dip.  A single flag-and-refit
    # pass removes most of it, but the refit polynomial still absorbs
    # some residual, and a second refit recovers more.
    #
    # Subtlety: if we recompute the noise threshold on every iteration,
    # it *shrinks* (because residuals get smaller after refit) → the
    # flag set grows by sweeping in noise points → bias polluted by
    # over-flagging.  This is the classic "mask-shrinking" failure mode.
    #
    # Solution: compute the noise threshold ONCE from the initial
    # (transit-contaminated) fit, then iterate only the flag set using
    # that fixed threshold.  Each iteration can only add points that
    # are *further* below the continuum than the fixed 3-sigma cut,
    # which is exactly what real transit points look like.
    # -------------------------------------------------------------

    # Initial polynomial evaluation
    poly_init = (X * coeffs.unsqueeze(1)).sum(dim=-1)  # [BC, K]

    # Freeze noise from the initial (all-valid) residuals.  This is
    # slightly inflated by transit contamination, which makes the
    # threshold *conservative* (under-flags noise spikes) — exactly
    # what we want.
    res_init = (trend_flat - poly_init) * valid_f
    n_v = valid_f.sum(dim=-1).clamp(min=1)
    noise_per_chunk = (res_init.abs().sum(dim=-1) / n_v) / 0.6745
    noise_thresh = noise_per_chunk.clamp(min=1e-10).unsqueeze(-1)  # fixed

    transit_mask = torch.zeros_like(valid_flat)
    poly_cur = poly_init
    for flag_iter in range(3):  # 3 iterations is enough in practice
        # Transit flags from raw flux vs current polynomial, fixed threshold
        flag_res = flag_flat - poly_cur
        new_transit_mask = (flag_res < -float(flag_sigma) * noise_thresh) & valid_orig_flat

        # Converged?
        if flag_iter > 0 and torch.equal(new_transit_mask, transit_mask):
            break
        transit_mask = new_transit_mask

        # Refit with transit-flagged points masked out
        valid_clean = valid_flat & ~transit_mask
        n_clean = valid_clean.to(dtype).sum(dim=-1)
        has_enough_clean = (n_clean >= 3) & transit_mask.any(dim=-1)
        if not has_enough_clean.any():
            break

        w0_clean = w0 * (~transit_mask).to(dtype)
        w0_clean_sum = w0_clean.sum(dim=-1, keepdim=True).clamp(min=1e-10)
        w0_clean = w0_clean / w0_clean_sum
        coeffs_refit = _batched_irls(
            X, trend_flat, w0_clean, valid_clean,
            n_irls_iter, asymmetry, 5.0,
        )
        mask_sel = has_enough_clean.unsqueeze(-1).to(dtype)
        coeffs = coeffs_refit * mask_sel + coeffs * (1 - mask_sel)

        # Update polynomial for next iteration's flag check
        poly_cur = (X * coeffs.unsqueeze(1)).sum(dim=-1)

    # Final polynomial (from last iteration of the refit loop)
    poly_final = poly_cur

    # Reshape back to [B, C, K]
    poly_chunks = poly_final.reshape(B, C, K)
    transit_chunks = transit_mask.reshape(B, C, K)
    noise_chunks = noise_per_chunk.reshape(B, C)

    # --- Build blending weights [K] for each chunk ---
    # Linear ramp on left overlap, flat in core, ramp on right overlap.
    bw_template = torch.ones(K, dtype=dtype, device=device)
    if overlap > 0:
        ramp_up = torch.linspace(0.0, 1.0, overlap + 1, dtype=dtype, device=device)[:-1]
        ramp_down = torch.linspace(1.0, 0.0, overlap + 1, dtype=dtype, device=device)[:-1]
        bw_template[:overlap] = ramp_up
        bw_template[K - overlap:] = ramp_down

    # Scatter chunks back into [B, L] with overlap blending.
    # Vectorised over chunks: build a [B, C, K] index tensor giving the
    # padded position for each (chunk, k), then scatter_add into [B, L_padded].
    L_pad = L + pad_left + pad_right
    poly_trend_padded = torch.zeros(B, L_pad, dtype=dtype, device=device)
    blend_padded = torch.zeros(B, L_pad, dtype=dtype, device=device)
    transit_padded = torch.zeros(B, L_pad, dtype=torch.bool, device=device)

    # Index for chunk c, position k = c*chunk_size + k
    c_idx = torch.arange(C, device=device, dtype=torch.long).unsqueeze(-1)  # [C, 1]
    k_idx = torch.arange(K, device=device, dtype=torch.long).unsqueeze(0)   # [1, K]
    pad_idx = (c_idx * chunk_size + k_idx).unsqueeze(0).expand(B, -1, -1)  # [B, C, K]

    # Weighted poly contributions [B, C, K]
    weighted_poly = poly_chunks * bw_template.view(1, 1, K)
    weighted_bw = bw_template.view(1, 1, K).expand(B, C, K)

    # Scatter-add into padded buffers
    poly_trend_padded.scatter_add_(1, pad_idx.reshape(B, -1),
                                   weighted_poly.reshape(B, -1))
    blend_padded.scatter_add_(1, pad_idx.reshape(B, -1),
                              weighted_bw.reshape(B, -1))
    # For transit flags use scatter (OR) — promote to int, scatter_add, then >0
    transit_int = torch.zeros(B, L_pad, dtype=torch.int8, device=device)
    transit_int.scatter_add_(1, pad_idx.reshape(B, -1),
                             transit_chunks.to(torch.int8).reshape(B, -1))
    transit_padded = transit_int > 0

    # Crop back to [B, L]
    poly_trend = poly_trend_padded[:, pad_left:pad_left + L]
    blend_weight = blend_padded[:, pad_left:pad_left + L]
    transit_flags = transit_padded[:, pad_left:pad_left + L]

    safe_bw = blend_weight.clamp(min=1e-10)
    poly_trend = poly_trend / safe_bw
    # Mask invalid points (no blending coverage) to identity behaviour
    no_coverage = blend_weight < 1e-10
    if no_coverage.any():
        poly_trend = torch.where(no_coverage, trend_l1, poly_trend)

    transit_flags = transit_flags & valid_mask

    return poly_trend, transit_flags, noise_chunks


# ---------------------------------------------------------------------------
# Rotation detection (Layer 3 enhancement)
# ---------------------------------------------------------------------------

def _batched_lomb_scargle_peak(
    time: torch.Tensor,      # [B, L]
    y: torch.Tensor,         # [B, L]
    valid: torch.Tensor,     # [B, L] bool
    period_min: float = 1.0,
    period_max: float = 15.0,
    n_freq: int = 120,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Simplified batched Lomb-Scargle periodogram, returns only the peak.

    Projects the centered signal onto sin/cos at a log-spaced frequency
    grid.  This is the power-only form (no chi-squared normalisation),
    enough to find the strongest peak and compare it to the periodogram
    median for a simple SNR test.

    Memory: Computing ``[B, L, F]`` sin/cos matrices would need ~700 MB
    for B=50, L=14000, F=120.  We avoid this by processing frequencies
    in small chunks and accumulating only the ``[B, F]`` power array.

    Args:
        time, y, valid: ``[B, L]`` input arrays.
        period_min, period_max: trial period range (days).
        n_freq: number of log-spaced trial frequencies.

    Returns:
        best_period:   ``[B]`` period (days) at the max-power frequency.
        best_power:    ``[B]`` peak power.
        snr:           ``[B]`` peak power / median power (per star).
    """
    B, L = y.shape
    device = y.device
    dtype = y.dtype

    # Replace any NaN/Inf in y with 0 at invalid positions to avoid NaN
    # contamination.  0 * NaN = NaN, so masking alone isn't enough —
    # we must zero the values themselves.
    y_clean = torch.where(
        valid & torch.isfinite(y),
        y,
        torch.zeros_like(y),
    )
    valid_f = (valid & torch.isfinite(y)).to(dtype)

    # Log-spaced periods
    log_pmin = torch.log(torch.tensor(period_min, dtype=dtype, device=device))
    log_pmax = torch.log(torch.tensor(period_max, dtype=dtype, device=device))
    log_periods = torch.linspace(log_pmin, log_pmax, n_freq, dtype=dtype, device=device)
    periods = torch.exp(log_periods)  # [F]
    freqs = 1.0 / periods              # [F]

    # Center y per-star over valid points
    n_valid = valid_f.sum(dim=-1, keepdim=True).clamp(min=1)
    y_mean = (y_clean * valid_f).sum(dim=-1, keepdim=True) / n_valid
    y_centered = (y_clean - y_mean) * valid_f  # [B, L]

    # Use time relative to each star's mean to keep sin/cos args small
    t0 = (time * valid_f).sum(dim=-1, keepdim=True) / n_valid  # [B, 1]
    t_rel = (time - t0).to(dtype)                               # [B, L]

    # Process frequencies in chunks to keep memory bounded.
    # Chunk size ~16: materialises [B, L, 16] ≈ 45 MB at B=50, L=14000.
    freq_chunk = 16
    power_parts = []
    for start in range(0, n_freq, freq_chunk):
        end = min(start + freq_chunk, n_freq)
        freqs_c = freqs[start:end]  # [Fc]

        two_pi_ft = (2.0 * torch.pi * t_rel).unsqueeze(-1) * freqs_c.view(1, 1, -1)
        sin_mat = torch.sin(two_pi_ft)          # [B, L, Fc]
        cos_mat = torch.cos(two_pi_ft)          # [B, L, Fc]

        # S(f) = Σ y_centered * sin, C(f) = Σ y_centered * cos
        yc = y_centered.unsqueeze(-1)            # [B, L, 1]
        S = (yc * sin_mat).sum(dim=1)            # [B, Fc]
        C = (yc * cos_mat).sum(dim=1)            # [B, Fc]
        power_parts.append((S ** 2 + C ** 2) / n_valid)

    power = torch.cat(power_parts, dim=-1)  # [B, F]

    # Peak per star
    best_idx = power.argmax(dim=-1)         # [B]
    best_period = periods[best_idx]         # [B]
    best_power = power.gather(-1, best_idx.unsqueeze(-1)).squeeze(-1)

    # SNR = peak / median (robust to overall power level)
    median_power = power.median(dim=-1).values.clamp(min=1e-20)
    snr = best_power / median_power

    return best_period, best_power, snr


def _fit_sinusoid(
    time: torch.Tensor,      # [B, L]
    y: torch.Tensor,         # [B, L]
    valid: torch.Tensor,     # [B, L] bool
    period: torch.Tensor,    # [B]
) -> torch.Tensor:
    """Batched least-squares fit of ``y ≈ A cos(2π t/P) + B sin(2π t/P) + c``.

    Returns the reconstructed sinusoid evaluated at *time* (shape ``[B, L]``).
    Invalid / non-finite input points are masked in the fit but still get
    the evaluated sinusoid in the output.
    """
    B, L = y.shape
    dtype = y.dtype
    device = y.device

    # Replace NaN/Inf in y with 0 at invalid positions.
    y_clean = torch.where(
        valid & torch.isfinite(y),
        y,
        torch.zeros_like(y),
    )
    valid_f = (valid & torch.isfinite(y)).to(dtype)

    # Center time the same way as the LS peak detector so the phase
    # is consistent.
    n_valid = valid_f.sum(dim=-1, keepdim=True).clamp(min=1)
    t0 = (time * valid_f).sum(dim=-1, keepdim=True) / n_valid
    t_rel = (time - t0).to(dtype)

    phase = 2.0 * torch.pi * t_rel / period.unsqueeze(-1).clamp(min=1e-10)
    cos_p = torch.cos(phase)
    sin_p = torch.sin(phase)
    ones = torch.ones_like(phase)

    X = torch.stack([cos_p, sin_p, ones], dim=-1)  # [B, L, 3]
    w = valid_f.unsqueeze(-1)                       # [B, L, 1]

    Xw = X * w
    XtWX = X.transpose(-1, -2) @ Xw                 # [B, 3, 3]
    XtWy = (Xw * y_clean.unsqueeze(-1)).sum(dim=1)  # [B, 3]

    # Ridge for stability
    eye = torch.eye(3, dtype=dtype, device=device).unsqueeze(0)
    XtWX = XtWX + 1e-10 * eye

    # Safe solve (constant stars produce degenerate systems)
    coeffs, info = torch.linalg.solve_ex(XtWX, XtWy.unsqueeze(-1))
    coeffs = coeffs.squeeze(-1)  # [B, 3]
    failed = info != 0
    if failed.any():
        coeffs = torch.where(
            failed.unsqueeze(-1),
            torch.zeros_like(coeffs),
            coeffs,
        )

    sinusoid = (X * coeffs.unsqueeze(1)).sum(dim=-1)  # [B, L]
    return sinusoid


def _detect_and_fit_rotation(
    time: torch.Tensor,
    trend_l1: torch.Tensor,
    valid_mask: torch.Tensor,
    period_min: float = 1.0,
    period_max: float = 15.0,
    snr_threshold: float = 6.0,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Detect dominant rotational signal per star and return a sinusoid.

    Stars with SNR below *snr_threshold* OR a sinusoid whose amplitude
    exceeds half the raw IQR (overshoot) get a zero-valued sinusoid,
    i.e. no subtraction applied.  Batched: works correctly when the
    input has variable-length stars padded to a common length.

    Returns:
        sinusoid: ``[B, L]`` tensor (zero for stars without rotation
            and at padded/invalid positions).
        period_days: ``[B]`` tensor of detected periods (NaN where no
            rotation was extracted).  Used by ``CorrelationStructure``
            to compute the global correlation component.
    """
    B, L = trend_l1.shape
    dtype = trend_l1.dtype
    device = trend_l1.device

    # Effective valid mask: must also be finite (Layer 1 emits NaN at
    # padded positions and for windows with too few valid points).
    eff_valid = valid_mask & torch.isfinite(trend_l1)

    # Require at least 2 * period_min span to detect anything.
    # Compute span from valid points only.
    big = torch.full_like(time, 1e30)
    small = torch.full_like(time, -1e30)
    t_lo = torch.where(eff_valid, time, big).min(dim=-1).values
    t_hi = torch.where(eff_valid, time, small).max(dim=-1).values
    span = t_hi - t_lo
    has_span = span > 2.0 * period_min  # [B]

    nan_period = torch.full((B,), float("nan"), dtype=dtype, device=device)
    if not has_span.any():
        return torch.zeros_like(trend_l1), nan_period

    best_period, best_power, snr = _batched_lomb_scargle_peak(
        time, trend_l1, eff_valid,
        period_min=period_min, period_max=period_max,
    )

    # Fit sinusoid at the detected period for all stars (cheap; gate later)
    sinusoid = _fit_sinusoid(time, trend_l1, eff_valid, best_period)

    # Safety gate: compute trend IQR only over valid+finite points.
    working = torch.where(eff_valid, trend_l1, torch.full_like(trend_l1, float("inf")))
    sorted_trend, _ = torch.sort(working, dim=-1)
    n_v = eff_valid.sum(dim=-1).clamp(min=1).to(torch.long)
    idx_25 = ((n_v.to(dtype) - 1) * 0.25).long()
    idx_75 = ((n_v.to(dtype) - 1) * 0.75).long()
    q25 = sorted_trend.gather(-1, idx_25.unsqueeze(-1)).squeeze(-1)
    q75 = sorted_trend.gather(-1, idx_75.unsqueeze(-1)).squeeze(-1)
    trend_iqr = (q75 - q25).clamp(min=1e-10)

    # Sinusoid amplitude over *valid* positions only (padded positions
    # can have huge spurious values even with the LSQ gate).
    sin_over_valid = torch.where(
        eff_valid, sinusoid, torch.full_like(sinusoid, float("nan")),
    )
    sin_q95 = torch.nanquantile(sin_over_valid, 0.95, dim=-1)
    sin_q05 = torch.nanquantile(sin_over_valid, 0.05, dim=-1)
    sin_amp = (sin_q95 - sin_q05) / 2.0  # ppm-like, absolute flux units

    # Get per-star median flux to convert to a relative amplitude.
    working = torch.where(eff_valid, trend_l1, torch.full_like(trend_l1, float("inf")))
    sorted_trend2, _ = torch.sort(working, dim=-1)
    idx_50 = ((n_v.to(dtype) - 1) * 0.50).long()
    trend_med = sorted_trend2.gather(-1, idx_50.unsqueeze(-1)).squeeze(-1).clamp(min=1e-10)
    sin_amp_rel = sin_amp / trend_med  # relative amplitude (e.g. 0.005 = 0.5%)

    # Gate: accept when the sinusoid amplitude is:
    #   (a) significant in RELATIVE terms (>= 0.1% of flux) — rejects
    #       quiet-star noise-level "rotations" that don't matter
    #   (b) not obviously a blown-up LSQ (amp < 1.2 × trend IQR)
    #   (c) span long enough to see multiple periods
    #   (d) LS peak above SNR threshold
    rel_iqr = trend_iqr / trend_med
    has_signal = (
        has_span
        & (snr >= snr_threshold)
        & torch.isfinite(sin_amp)
        & (sin_amp < 1.2 * trend_iqr)
        & (sin_amp_rel > 0.001)  # 0.1% relative amplitude minimum
    )

    # Zero out sinusoid for stars without rotation AND at padded positions
    # so it never contaminates downstream layers.
    mask_star = has_signal.unsqueeze(-1).to(dtype)
    mask_pos = eff_valid.to(dtype)
    sinusoid_out = sinusoid * mask_star * mask_pos

    # Period output: NaN for stars where rotation was not extracted
    period_out = torch.where(
        has_signal,
        best_period,
        torch.full_like(best_period, float("nan")),
    )
    return sinusoid_out, period_out


# ---------------------------------------------------------------------------
# Layer 3: Global variability model + bias correction
# ---------------------------------------------------------------------------

def layer3_global(
    poly_trend: torch.Tensor,
    chunk_noise: torch.Tensor,
    transit_flags: torch.Tensor,
    time: torch.Tensor,
    valid_mask: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Global variability model and per-star bias correction.

    The global model is the blended polynomial trend from Layer 2.
    Bias correction is estimated from per-star variability amplitude.

    Args:
        poly_trend:    ``[B, L]`` polynomial trend from Layer 2.
        chunk_noise:   ``[B, C]`` per-chunk noise from Layer 2.
        transit_flags: ``[B, L]`` transit flags from Layer 2.
        time:          ``[B, L]`` timestamps.
        valid_mask:    ``[B, L]`` boolean.

    Returns:
        expected_flux:   ``[B, L]`` global model prediction.
        bias_correction: ``[B]`` per-star bias (in flux units).
        variability_amp: ``[B]`` detected variability amplitude.
    """
    B, L = poly_trend.shape
    dtype = poly_trend.dtype
    device = poly_trend.device

    # Expected flux = blended polynomial trend (already computed in Layer 2)
    expected_flux = poly_trend.clone()

    # Per-star variability amplitude via batched quantiles.
    # Sort each star's poly_trend with invalid/flagged points pushed to +inf
    # so they sort to the end and don't affect the quantile computation.
    clean_mask = valid_mask & ~transit_flags  # [B, L]
    n_clean = clean_mask.sum(dim=-1)  # [B]
    use_clean = n_clean >= 4

    # Fall back to valid_mask for stars with too few clean points
    use_mask = torch.where(use_clean.unsqueeze(-1), clean_mask, valid_mask)
    n_used = use_mask.sum(dim=-1).clamp(min=1)  # [B]

    # Push invalid/excluded values to +inf so torch.sort puts them last
    working = torch.where(use_mask, poly_trend, torch.full_like(poly_trend, float("inf")))
    sorted_vals, _ = torch.sort(working, dim=-1)  # [B, L], invalid at end

    # Indices for q25, q50 (median), q75 within the valid range per star
    n_used_f = n_used.to(dtype)
    idx_q25 = ((n_used_f - 1) * 0.25).long()
    idx_q50 = ((n_used_f - 1) * 0.50).long()
    idx_q75 = ((n_used_f - 1) * 0.75).long()

    q25 = sorted_vals.gather(-1, idx_q25.unsqueeze(-1)).squeeze(-1)
    q50 = sorted_vals.gather(-1, idx_q50.unsqueeze(-1)).squeeze(-1)
    q75 = sorted_vals.gather(-1, idx_q75.unsqueeze(-1)).squeeze(-1)

    variability_amp = q75 - q25

    # Zero variability for stars with too few valid points.
    too_few = n_clean < 4
    variability_amp = torch.where(too_few, torch.zeros_like(variability_amp), variability_amp)

    # bias_correction is kept as a zero-valued [B] tensor for API
    # compatibility.  See the note at the top of this file on why the
    # earlier additive mechanism was architecturally a no-op.
    bias_correction = torch.zeros(B, dtype=dtype, device=device)

    return expected_flux, bias_correction, variability_amp


# ---------------------------------------------------------------------------
# Layer 1 (informed): Second pass on residuals
# ---------------------------------------------------------------------------

def layer1_informed(
    flux: torch.Tensor,
    expected_flux: torch.Tensor,
    bias_correction: torch.Tensor,
    time: torch.Tensor,
    valid_mask: torch.Tensor,
    segment_id: torch.Tensor,
    transit_flags: torch.Tensor | None = None,
    window_size: int = 361,
    n_iter: int = 5,
    cval: float = 5.0,
    asymmetry: float = 2.0,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """Informed detrending: Layer 1 on residuals with global context.

    At transit-flagged positions the local correction is zeroed so the
    trend stays at the expected_flux level (the continuum polynomial).
    This prevents the second bisquare pass from further absorbing the
    transit signal.

    Args:
        flux:            ``[B, L]`` raw flux.
        expected_flux:   ``[B, L]`` global model from Layer 3.
        bias_correction: ``[B]`` per-star bias.
        time:            ``[B, L]`` timestamps.
        valid_mask:      ``[B, L]`` boolean.
        segment_id:      ``[B, L]`` segment labels.
        transit_flags:   ``[B, L]`` bool from Layer 2.  If given, local
            correction is zeroed at flagged positions to protect transit
            depth.
        window_size:     Full window width (samples).
        n_iter:          Bisquare iterations.
        cval:            Rejection threshold.
        asymmetry:       Downward penalty.

    Returns:
        detrended:   ``[B, L]`` final detrended flux.
        trend:       ``[B, L]`` final trend estimate.
        uncertainty: ``[B, L]`` per-point uncertainty.
    """
    B, L = flux.shape
    dtype = flux.dtype
    device = flux.device

    # Compute residuals (remove known global variability)
    residuals = flux - expected_flux  # [B, L]

    # Run Layer 1 on residuals
    local_corr, _, unc = layer1_local(
        residuals, time, valid_mask, segment_id,
        window_size=window_size, n_iter=n_iter, cval=cval, asymmetry=asymmetry,
    )

    # Zero out local correction at transit-flagged points so the trend
    # stays at the expected_flux (continuum) level and doesn't further
    # absorb the transit dip.
    if transit_flags is not None:
        local_corr = torch.where(transit_flags, torch.zeros_like(local_corr), local_corr)

    # Final trend = global + local correction - bias
    bias = bias_correction.unsqueeze(-1)  # [B, 1]
    trend = expected_flux + local_corr - bias

    # Detrended flux = flux / trend
    detrended = torch.where(
        (trend > 0) & valid_mask & torch.isfinite(trend),
        flux / trend,
        torch.tensor(float("nan"), dtype=dtype, device=device),
    )

    return detrended, trend, unc


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def hierarchical_detrend(
    flux: torch.Tensor,
    time: torch.Tensor,
    valid_mask: torch.Tensor,
    segment_id: torch.Tensor,
    window_length_days: float = 0.65,
    cadence_minutes: float | None = None,
    n_iter: int = 5,
    cval: float = 5.0,
    asymmetry: float = 2.0,
    layer2_flag_sigma: float = 3.0,
    return_correlation: bool = False,
):
    """Hierarchical multi-scale asymmetric detrending.

    Three-layer hierarchy:
      Layer 1 → local per-point estimation
      Layer 2 → IRLS polynomial chunk fitting
      Layer 3 → global variability model + bias correction
      Layer 1 → informed pass on residuals

    Args:
        flux:         ``[B, L]`` flux values.
        time:         ``[B, L]`` timestamps (BJD or similar).
        valid_mask:   ``[B, L]`` boolean (True = valid).
        segment_id:   ``[B, L]`` int32 segment labels from gap detection.
        window_length_days: Sliding window width in days (default 0.65).
            Tuned via ``benchmarks/hierarchical/fine_window_sweep.py`` and
            ``benchmarks/hierarchical/window_variable_regression.py``: 0.65d
            closes ~30% of the oracle headroom on shallow injections
            (0.05-0.1% depths) vs the previous 0.5d, with no measurable
            residual-RMS regression on either quiet or variable stars.
        cadence_minutes: Observation cadence in minutes.  Auto-detected from
            *time* if ``None``.
        n_iter:       Number of asymmetric bisquare iterations per layer.
        cval:         Rejection threshold in scale units.
        asymmetry:    Downward-deviation penalty factor.
        layer2_flag_sigma: Layer-2 transit-flag threshold in robust-sigma
            units (default 3.0).  Lower = catches shallower dips in the
            iterative refit but also more false positives from noise spikes;
            sweep at ``benchmarks/hierarchical/variant_sweep.py`` showed
            no measurable benefit from lowering past 3.0 because the noise
            scale itself is computed from contaminated residuals.
        return_correlation: If True, also return a :class:`CorrelationStructure`
            describing the off-diagonal noise correlation across the
            hierarchy's three scales (Layer 1 window, Layer 2 chunk,
            Layer 3 rotation).  Useful for downstream depth fits and
            BLS false-alarm rate corrections.

    Returns:
        If ``return_correlation`` is False (default):

            (detrended, trend, uncertainty)
                — each ``[B, L]`` tensors.

        If ``return_correlation`` is True:

            (detrended, trend, uncertainty, correlation_structure)
                — same three tensors plus a :class:`CorrelationStructure`.
    """
    B, L = flux.shape

    # Auto-detect cadence if not provided
    if cadence_minutes is None:
        dt = time[:, 1:] - time[:, :-1]
        dt_valid = valid_mask[:, 1:] & valid_mask[:, :-1]
        median_cad = masked_median(dt, dt_valid)  # [B] in days
        cadence_minutes = float(median_cad.median().item() * 1440.0)
        cadence_minutes = max(cadence_minutes, 0.1)  # safety floor

    # Compute window size in samples
    cadence_days = cadence_minutes / 1440.0
    W = max(3, round(window_length_days / cadence_days))
    W = W | 1  # ensure odd

    # Chunk parameters (matches layer2_supervisor)
    chunk_size, overlap = _compute_chunk_params(cadence_minutes, L)

    # --- Layer 1: local estimation ---
    trend_l1, scale_l1, unc_l1 = layer1_local(
        flux, time, valid_mask, segment_id,
        window_size=W, n_iter=n_iter, cval=cval, asymmetry=asymmetry,
    )

    # --- Layer 3a: rotation detection + subtraction ---
    # Detect a dominant periodic signal in the Layer 1 trend.  For stars
    # with a clean rotational modulation this lets Layer 2 fit polynomials
    # to a flatter residual, which gives more reliable transit flagging
    # and tighter trend recovery near rotation minima.  For quiet stars
    # or those without a clear periodicity, the sinusoid is skipped
    # (zero-valued) so this is a no-op.
    sinusoid, rotation_period = _detect_and_fit_rotation(time, trend_l1, valid_mask)
    flux_derot = flux - sinusoid
    trend_l1_derot = trend_l1 - sinusoid

    # --- Layer 2: supervisor chunks on the de-rotated signal ---
    poly_trend, transit_flags, chunk_noise = layer2_supervisor(
        trend_l1_derot, scale_l1, time, valid_mask, segment_id,
        cadence_minutes=cadence_minutes, n_irls_iter=n_iter, asymmetry=asymmetry,
        flux=flux_derot, flag_sigma=layer2_flag_sigma,
    )

    # --- Layer 3: global model + bias correction ---
    expected_flux, bias_correction, var_amp = layer3_global(
        poly_trend, chunk_noise, transit_flags, time, valid_mask,
    )

    # Add rotation signal back into the expected flux baseline
    expected_flux = expected_flux + sinusoid

    # --- Layer 1 (informed): second pass on residuals ---
    detrended, trend, uncertainty = layer1_informed(
        flux, expected_flux, bias_correction, time, valid_mask, segment_id,
        transit_flags=transit_flags,
        window_size=W, n_iter=n_iter, cval=cval, asymmetry=asymmetry,
    )

    if return_correlation:
        corr = CorrelationStructure(
            window_size=int(W),
            chunk_size=int(chunk_size),
            chunk_overlap=int(overlap),
            cadence_days=float(cadence_days),
            rotation_period_days=rotation_period.detach(),
        )
        return detrended, trend, uncertainty, corr

    return detrended, trend, uncertainty


# ---------------------------------------------------------------------------
# Batched entry point for variable-length light curves
# ---------------------------------------------------------------------------

def hierarchical_detrend_batch(
    times: list,
    fluxes: list,
    cadence_minutes: float,
    device: str | torch.device = "cuda",
    bucket_width: int = 1000,
    max_batch: int | None = None,
    window_length_days: float = 0.65,
    n_iter: int = 5,
    cval: float = 5.0,
    asymmetry: float = 2.0,
) -> list[dict]:
    """Run hierarchical detrending on a list of variable-length light curves.

    Stars are grouped into length buckets, padded to a common length within
    each bucket, and processed in batches on the GPU.  This is dramatically
    faster than calling :func:`hierarchical_detrend` per-star because the
    GPU kernel runs at full occupancy and Python overhead is amortised.

    Args:
        times:   list of ``[L_i]`` numpy arrays (timestamps in days).
        fluxes:  list of ``[L_i]`` numpy arrays (already quality-filtered).
        cadence_minutes: Observation cadence (must be the same for all stars).
            Required because hierarchical chunk sizing depends on cadence.
        device:  Torch device.
        bucket_width: Length-bucket granularity in samples.
        max_batch: Override max stars per batch.  If ``None`` defaults to 100.
        window_length_days: Sliding window in days.
        n_iter: Bisquare iterations per layer.
        cval: Rejection threshold.
        asymmetry: Downward-deviation penalty.

    Returns:
        List of per-star dicts: ``[{"detrended", "trend", "uncertainty"}, ...]``
        in the same order as the input lists.  All values are numpy arrays
        of length matching the input star.
    """
    import numpy as np
    from collections import defaultdict

    if isinstance(device, str):
        device = torch.device(device)

    n_stars = len(times)
    if n_stars == 0:
        return []
    if len(fluxes) != n_stars:
        raise ValueError(f"len(fluxes)={len(fluxes)} != len(times)={n_stars}")

    # Initialise output slots (None for any star that fails)
    results: list[dict | None] = [None] * n_stars

    # Bucket stars by length
    buckets: dict[int, list[int]] = defaultdict(list)
    for i, f in enumerate(fluxes):
        L = len(f)
        if L < 10:
            continue
        bucket_key = ((L - 1) // bucket_width + 1) * bucket_width
        buckets[bucket_key].append(i)

    if max_batch is None:
        max_batch = 100

    for pad_length, indices in sorted(buckets.items()):
        # Process each bucket in sub-batches of max_batch
        for batch_start in range(0, len(indices), max_batch):
            batch_indices = indices[batch_start : batch_start + max_batch]
            B = len(batch_indices)

            # Allocate padded tensors on CPU first (faster than per-row GPU writes)
            time_batch = torch.zeros(B, pad_length, dtype=torch.float64)
            flux_batch = torch.zeros(B, pad_length, dtype=torch.float32)
            valid_batch = torch.zeros(B, pad_length, dtype=torch.bool)
            seg_batch = torch.zeros(B, pad_length, dtype=torch.int32)
            lengths = []

            for j, idx in enumerate(batch_indices):
                t = times[idx]
                f = fluxes[idx].astype(np.float32)
                L = len(t)
                n = min(L, pad_length)
                time_batch[j, :n] = torch.from_numpy(t[:n].astype(np.float64))
                flux_batch[j, :n] = torch.from_numpy(f[:n])
                valid_batch[j, :n] = True
                lengths.append(n)

            # Transfer to device once
            flux_t = flux_batch.to(device)
            time_t = time_batch.to(device)
            valid_t = valid_batch.to(device)
            seg_t = seg_batch.to(device)

            # Single hierarchical_detrend call processes the whole batch
            try:
                det, trend, unc = hierarchical_detrend(
                    flux_t, time_t, valid_t, seg_t,
                    window_length_days=window_length_days,
                    cadence_minutes=cadence_minutes,
                    n_iter=n_iter, cval=cval, asymmetry=asymmetry,
                )
            except Exception as e:
                logger.warning(
                    "Batch (pad_length=%d, B=%d) failed: %s. Falling back to per-star.",
                    pad_length, B, e,
                )
                # Per-star fallback
                for j, idx in enumerate(batch_indices):
                    n = lengths[j]
                    try:
                        det1, trend1, unc1 = hierarchical_detrend(
                            flux_t[j : j + 1, :n],
                            time_t[j : j + 1, :n],
                            valid_t[j : j + 1, :n],
                            seg_t[j : j + 1, :n],
                            cadence_minutes=cadence_minutes,
                            window_length_days=window_length_days,
                            n_iter=n_iter, cval=cval, asymmetry=asymmetry,
                        )
                        results[idx] = {
                            "detrended": det1[0].cpu().numpy(),
                            "trend": trend1[0].cpu().numpy(),
                            "uncertainty": unc1[0].cpu().numpy(),
                        }
                    except Exception:
                        results[idx] = None
                continue

            # Transfer once back to CPU and slice per-star
            det_cpu = det.cpu().numpy()
            trend_cpu = trend.cpu().numpy()
            unc_cpu = unc.cpu().numpy()

            for j, idx in enumerate(batch_indices):
                n = lengths[j]
                results[idx] = {
                    "detrended": det_cpu[j, :n].copy(),
                    "trend": trend_cpu[j, :n].copy(),
                    "uncertainty": unc_cpu[j, :n].copy(),
                }

    return results
