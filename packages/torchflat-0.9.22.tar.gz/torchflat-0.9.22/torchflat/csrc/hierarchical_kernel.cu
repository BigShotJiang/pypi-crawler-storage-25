/*
 * hierarchical_kernel.cu - Hierarchical detrending Layer 1 GPU kernel
 *
 * Per-data-point local asymmetric estimation with edge handling.
 * Unlike UMI (one thread per window position, NaN edges), this assigns
 * one thread per data point and uses partial windows at edges.
 *
 * Outputs: trend, scale, uncertainty per point (3 arrays).
 *
 * Compiles on both AMD ROCm (via hipify) and NVIDIA CUDA.
 */

#include <torch/types.h>
#include <c10/cuda/CUDAStream.h>

constexpr int MAX_LOCAL_SIZE = 512;
constexpr int MIN_WINDOW_VALID = 10;
constexpr float LARGE_UNCERTAINTY = 1.0f;

// ---------------------------------------------------------------------------
// Device helpers (same quickselect as UMI kernel)
// ---------------------------------------------------------------------------
template <typename scalar_t>
__device__ __forceinline__ void swap_vals(scalar_t& a, scalar_t& b) {
    scalar_t tmp = a;
    a = b;
    b = tmp;
}

template <typename scalar_t>
__device__ __forceinline__ scalar_t median_of_3(
    scalar_t* buf, int lo, int mid, int hi
) {
    if (buf[mid] < buf[lo]) swap_vals(buf[lo], buf[mid]);
    if (buf[hi]  < buf[lo]) swap_vals(buf[lo], buf[hi]);
    if (buf[hi]  < buf[mid]) swap_vals(buf[mid], buf[hi]);
    return buf[mid];
}

template <typename scalar_t>
__device__ void nth_element(scalar_t* buf, int lo, int hi, int k) {
    while (lo < hi) {
        if (hi - lo < 3) {
            for (int i = lo + 1; i <= hi; i++) {
                scalar_t val = buf[i];
                int j = i;
                while (j > lo && buf[j - 1] > val) {
                    buf[j] = buf[j - 1];
                    j--;
                }
                buf[j] = val;
            }
            return;
        }

        int mid = lo + (hi - lo) / 2;
        scalar_t pivot = median_of_3(buf, lo, mid, hi);

        swap_vals(buf[mid], buf[hi - 1]);

        int i = lo;
        int j = hi - 1;
        while (true) {
            while (buf[++i] < pivot);
            while (buf[--j] > pivot);
            if (i >= j) break;
            swap_vals(buf[i], buf[j]);
        }
        swap_vals(buf[i], buf[hi - 1]);

        if (k < i) {
            hi = i - 1;
        } else if (k > i) {
            lo = i + 1;
        } else {
            return;
        }
    }
}

template <typename scalar_t>
__device__ scalar_t compute_median(scalar_t* buf, int n) {
    if (n == 1) return buf[0];
    if (n == 2) return (buf[0] + buf[1]) / static_cast<scalar_t>(2);

    const int k_hi = n / 2;
    const int k_lo = (n - 1) / 2;

    nth_element(buf, 0, n - 1, k_hi);
    scalar_t val_hi = buf[k_hi];

    if (k_lo == k_hi) {
        return val_hi;
    } else {
        scalar_t val_lo = buf[0];
        for (int i = 1; i < k_hi; i++) {
            if (buf[i] > val_lo) val_lo = buf[i];
        }
        return (val_lo + val_hi) / static_cast<scalar_t>(2);
    }
}

// ---------------------------------------------------------------------------
// Kernel: per-data-point Layer 1
// ---------------------------------------------------------------------------
// Each thread processes one (star, data_point) pair.
// Reads a window centered on the data point, handles partial windows at edges.
// Outputs trend, scale, uncertainty.
// ---------------------------------------------------------------------------
template <typename scalar_t>
__global__ void hierarchical_layer1_kernel(
    const scalar_t* __restrict__ flux,       // [B, L]
    const bool*     __restrict__ valid,      // [B, L]
    const int*      __restrict__ seg,        // [B, L]
    scalar_t*       __restrict__ out_trend,  // [B, L]
    scalar_t*       __restrict__ out_scale,  // [B, L]
    scalar_t*       __restrict__ out_unc,    // [B, L]
    const int B,
    const int L,
    const int W,
    const scalar_t cval,
    const scalar_t asymmetry,
    const int n_iter
) {
    const int64_t tid = static_cast<int64_t>(blockIdx.x) * blockDim.x + threadIdx.x;
    const int64_t total = static_cast<int64_t>(B) * L;
    if (tid >= total) return;

    const int star = static_cast<int>(tid / L);
    const int pos = static_cast<int>(tid % L);
    const int half_w = W / 2;

    const scalar_t* f = flux + static_cast<int64_t>(star) * L;
    const bool* v = valid + static_cast<int64_t>(star) * L;
    const int* s = seg + static_cast<int64_t>(star) * L;

    const int center_seg = s[pos];

    // Window bounds (handles edges with partial windows)
    int w_start = pos - half_w;
    if (w_start < 0) w_start = 0;
    int w_end = pos + half_w + 1;
    if (w_end > L) w_end = L;

    // Gather valid elements in same segment
    scalar_t buf[MAX_LOCAL_SIZE];
    int n = 0;
    for (int i = w_start; i < w_end && n < MAX_LOCAL_SIZE; i++) {
        if (v[i] && s[i] == center_seg) {
            buf[n++] = f[i];
        }
    }

    const int64_t out_idx = tid;

    // Degenerate: too few valid points
    if (n < MIN_WINDOW_VALID) {
        if (n > 0) {
            out_trend[out_idx] = compute_median(buf, n);
        } else {
            out_trend[out_idx] = static_cast<scalar_t>(NAN);
        }
        out_scale[out_idx] = static_cast<scalar_t>(LARGE_UNCERTAINTY);
        out_unc[out_idx] = static_cast<scalar_t>(LARGE_UNCERTAINTY);
        return;
    }

    // Quickselect for median
    scalar_t location = compute_median(buf, n);

    // Upper-RMS scale (above-median points only)
    scalar_t upper_sq_sum = 0;
    int n_above = 0;
    for (int i = 0; i < n; i++) {
        scalar_t d = buf[i] - location;
        if (d > 0) {
            upper_sq_sum += d * d;
            n_above++;
        }
    }
    scalar_t scale;
    if (n_above > 0) {
        scalar_t upper_rms = sqrt(upper_sq_sum / static_cast<scalar_t>(n_above));
        scale = upper_rms * static_cast<scalar_t>(0.6745);
    } else {
        scale = static_cast<scalar_t>(1e-10);
    }
    if (scale < static_cast<scalar_t>(1e-10))
        scale = static_cast<scalar_t>(1e-10);
    scalar_t safe_scale = cval * scale;

    // Asymmetric bisquare iterations
    scalar_t w_sum_final = 0;
    for (int iter = 0; iter < n_iter; iter++) {
        scalar_t w_sum = 0, wx_sum = 0;
        for (int j = 0; j < n; j++) {
            scalar_t u = (buf[j] - location) / safe_scale;
            scalar_t u_abs = u < 0 ? -u * asymmetry : u;
            if (u_abs < static_cast<scalar_t>(1)) {
                scalar_t u2 = u_abs * u_abs;
                scalar_t w = (static_cast<scalar_t>(1) - u2);
                w = w * w;
                w_sum += w;
                wx_sum += w * buf[j];
            }
        }
        if (w_sum > static_cast<scalar_t>(1e-10))
            location = wx_sum / w_sum;
        w_sum_final = w_sum;
    }

    // Weighted standard error: sqrt(sum(w*(x-loc)^2)/sum(w)) / sqrt(sum(w))
    scalar_t w_var_sum = 0;
    scalar_t w_total = 0;
    for (int j = 0; j < n; j++) {
        scalar_t u = (buf[j] - location) / safe_scale;
        scalar_t u_abs = u < 0 ? -u * asymmetry : u;
        if (u_abs < static_cast<scalar_t>(1)) {
            scalar_t u2 = u_abs * u_abs;
            scalar_t w = (static_cast<scalar_t>(1) - u2);
            w = w * w;
            scalar_t r = buf[j] - location;
            w_var_sum += w * r * r;
            w_total += w;
        }
    }
    scalar_t unc;
    if (w_total > static_cast<scalar_t>(1e-10)) {
        scalar_t variance = w_var_sum / w_total;
        unc = sqrt(variance) / sqrt(w_total);
    } else {
        unc = static_cast<scalar_t>(LARGE_UNCERTAINTY);
    }

    out_trend[out_idx] = location;
    out_scale[out_idx] = scale;
    out_unc[out_idx] = unc;
}

// ---------------------------------------------------------------------------
// C++ launch wrapper
// ---------------------------------------------------------------------------
std::vector<torch::Tensor> hierarchical_layer1_cuda(
    torch::Tensor flux,
    torch::Tensor valid_mask,
    torch::Tensor segment_id,
    int64_t W,
    double cval,
    double asymmetry,
    int64_t n_iter
) {
    TORCH_CHECK(flux.is_cuda(), "flux must be a CUDA/HIP tensor");
    TORCH_CHECK(flux.dim() == 2, "flux must be [B, L]");
    TORCH_CHECK(W <= MAX_LOCAL_SIZE,
                "Window size ", W, " exceeds kernel limit of ", MAX_LOCAL_SIZE);

    auto f = flux.contiguous();
    auto v = valid_mask.contiguous();
    auto s = segment_id.contiguous().to(torch::kInt32);

    const int B = f.size(0);
    const int L = f.size(1);

    auto out_trend = torch::empty({B, L}, f.options());
    auto out_scale = torch::empty({B, L}, f.options());
    auto out_unc   = torch::empty({B, L}, f.options());

    const int64_t total = static_cast<int64_t>(B) * L;
    if (total == 0) return {out_trend, out_scale, out_unc};

    const int threads = 256;
    const int blocks = static_cast<int>((total + threads - 1) / threads);

    AT_DISPATCH_FLOATING_TYPES(f.scalar_type(), "hierarchical_layer1_cuda", [&] {
        hierarchical_layer1_kernel<scalar_t><<<blocks, threads, 0,
            c10::cuda::getCurrentCUDAStream()>>>(
            f.data_ptr<scalar_t>(),
            v.data_ptr<bool>(),
            s.data_ptr<int>(),
            out_trend.data_ptr<scalar_t>(),
            out_scale.data_ptr<scalar_t>(),
            out_unc.data_ptr<scalar_t>(),
            B, L, static_cast<int>(W),
            static_cast<scalar_t>(cval),
            static_cast<scalar_t>(asymmetry),
            static_cast<int>(n_iter)
        );
    });

    return {out_trend, out_scale, out_unc};
}
