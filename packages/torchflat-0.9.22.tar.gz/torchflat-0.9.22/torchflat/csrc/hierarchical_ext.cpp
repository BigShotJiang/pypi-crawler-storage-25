/*
 * hierarchical_ext.cpp - Pybind11 binding for hierarchical Layer 1 kernel.
 */

#include <torch/extension.h>
#include <vector>

std::vector<torch::Tensor> hierarchical_layer1_cuda(
    torch::Tensor flux, torch::Tensor valid_mask, torch::Tensor segment_id,
    int64_t W, double cval, double asymmetry, int64_t n_iter);

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("hierarchical_layer1", &hierarchical_layer1_cuda,
          "Hierarchical Layer 1: per-data-point local asymmetric estimation (GPU)");
}
