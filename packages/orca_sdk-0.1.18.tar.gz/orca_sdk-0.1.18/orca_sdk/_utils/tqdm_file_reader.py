class TqdmFileReader:
    """File-like wrapper that updates a tqdm progress bar on read.

    Implements the iterator protocol so it can be passed as ``content=``
    to ``httpx.put`` / ``httpx.post`` (which requires ``Iterable[bytes]``).
    File-like methods (``fileno``, ``seek``, ``tell``, …) are forwarded to
    the underlying file object so that ``httpx`` can detect the content
    length and avoid chunked transfer encoding.
    """

    CHUNK_SIZE = 64 * 1024

    def __init__(self, file_obj, pbar):
        self.file_obj = file_obj
        self.pbar = pbar

    def read(self, size=-1):
        data = self.file_obj.read(size)
        self.pbar.update(len(data))
        return data

    def __iter__(self):
        return self

    def __next__(self) -> bytes:
        chunk = self.read(self.CHUNK_SIZE)
        if not chunk:
            raise StopIteration
        return chunk

    def __getattr__(self, attr):
        return getattr(self.file_obj, attr)
