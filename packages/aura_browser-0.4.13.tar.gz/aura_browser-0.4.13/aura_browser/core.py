from DrissionPage import ChromiumPage, ChromiumOptions
from typing import List, Dict, Any

import time
import os
import urllib.request
import zipfile
import io

def _get_ad_blocklist() -> list:
    """Downloads and caches a global, up-to-date ad server database."""
    import time
    home = os.path.expanduser("~")
    cache_file = os.path.join(home, ".aura_browser", "ad_blocklist.txt")
    os.makedirs(os.path.dirname(cache_file), exist_ok=True)
    
    # Base robust wildcards for anime/streaming sites
    block_wildcards = [
        '*doubleclick.net*', '*googleadservices.com*', '*googlesyndication.com*', 
        '*popunder*', '*criteo.com*', '*taboola.com*', '*outbrain.com*', 
        '*popads.net*', '*popcash.net*', '*adsterra.com*', '*propellerads.com*',
        '*yllix.com*', '*adbull.com*', '*onclickads.net*', '*revenuehits.com*',
        '*witanime.life/wp-content/plugins/ads*', '*/ads/*', '*/ad/*', '*banner*', '*popup*'
    ]
    
    # Fetch Peter Lowe's massive AdServer list if cache is missing or older than 7 days
    if not os.path.exists(cache_file) or (time.time() - os.path.getmtime(cache_file)) > 7 * 86400:
        try:
            if not os.path.exists(cache_file):
                print("[Aura-Browser] Downloading latest global AdBlock database (this happens once)...")
            url = "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext"
            req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            resp = urllib.request.urlopen(req, timeout=10)
            data = resp.read().decode('utf-8')
            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(data)
            print("[Aura-Browser] AdBlock database updated successfully.")
        except Exception as e:
            pass # Silently fallback to base wildcards if offline
            
    if os.path.exists(cache_file):
        with open(cache_file, 'r', encoding='utf-8') as f:
            for line in f:
                domain = line.strip()
                if domain and not domain.startswith('#'):
                    block_wildcards.append(f"*{domain}*")
                    
    return block_wildcards

class AIBrowser:
    def __init__(self, headless: bool = False, mute: bool = True, debug: bool = False):
        self.debug = debug
        co = ChromiumOptions()
        
        if headless:
            co.set_argument('--headless=new')
            
        if mute:
            co.mute(True)
            
        # 🛡️ ORIGINAL STEALTH SETTINGS
        co.set_argument('--no-sandbox')
        co.set_argument('--disable-gpu')
        co.set_argument('--disable-blink-features=AutomationControlled')

        self.page = ChromiumPage(addr_or_opts=co)
        
        # 🚫 DYNAMIC GLOBAL AD & POPUP BLOCKER
        # Merges base wildcards with thousands of dynamically fetched global ad domains
        ad_wildcards = _get_ad_blocklist()
        self.page.set.blocked_urls(ad_wildcards)
        self.page.set.auto_handle_alert() # Accept any annoying JS alerts
            
        self.interactive_elements = {}
        if self.debug:
            print("[Aura-Browser] Initialized in DEBUG mode.")
        
        # Automatically close any new tabs that open unexpectedly (Pop-ups)
        self.page.set.auto_handle_alert() # Accept any annoying JS alerts
        
    def go_to(self, url: str):
        """Navigate to a URL and wait for it to load completely."""
        if self.debug:
            print(f"[Aura-Browser] Navigating to: {url}")
        self.page.get(url)
        self.page.wait.doc_loaded() # Wait for the document
        time.sleep(3) # Extra wait for dynamic JavaScript frameworks (React/Vue) to render
        try:
            self.page.close_other_tabs()
        except:
            pass
        if self.debug:
            print(f"[Aura-Browser] Page fully loaded.")
        
    def get_interactive_elements(self) -> List[Dict[str, str]]:
        """
        Scans the page for interactive elements (buttons, links, inputs).
        Returns them as a list of dictionaries with unique IDs for AI to control.
        """
        self.interactive_elements.clear()
        elements_data = []
        
        # Selectors that an AI might want to interact with (DrissionPage syntax requires tag: or css:)
        selectors = ['tag:a', 'tag:button', 'tag:input', 'tag:textarea', 'tag:select', 'css:[role="button"]']
        
        element_counter = 1
        for selector in selectors:
            for ele in self.page.eles(selector):
                try:
                    # Exclude hidden or non-interactive elements
                    if ele.states.is_displayed and not ele.attr('hidden') and ele.states.is_enabled:
                        tag = ele.tag
                        # Filter out inputs that are likely not useful
                        if tag == 'input' and ele.attr('type') in ['hidden', 'checkbox', 'radio']:
                            continue
                            
                        eid = f"ID_{element_counter}"
                        self.interactive_elements[eid] = ele
                        
                        text_val = (ele.text or ele.attr('aria-label') or ele.attr('placeholder') or ele.attr('name') or '').strip()
                        elements_data.append({
                            "id": eid,
                            "tag": tag,
                            "text": text_val,
                            "type": ele.attr('type') if tag == 'input' else None
                        })
                        element_counter += 1
                except Exception:
                    pass
                    
        if self.debug:
            print(f"[Aura-Browser] Extracted {len(elements_data)} visible interactive elements.")
        return elements_data
        
    def _find_element_intelligently(self, identifier: str):
        """Finds an element by AI ID, fuzzy text match, or standard developer CSS/XPath locator."""
        # 1. Direct exact ID match (For AI)
        if identifier in self.interactive_elements:
            return self.interactive_elements[identifier]
            
        # 2. Intelligent fallback match (If AI hallucinates something like 'ID_SEARCH' or 'search')
        # We remove 'id_' just in case the AI made up a fake ID name.
        identifier_clean = identifier.lower().replace("id_", "").strip()
        if identifier_clean:
            for eid, ele in self.interactive_elements.items():
                text = ele.text or ele.attr('aria-label') or ele.attr('placeholder') or ele.attr('name') or ''
                if text and identifier_clean in text.lower():
                    return ele
                    
        # 3. For General Programmers! Treat identifier as a CSS/XPath or DrissionPage locator
        try:
            ele = self.page.ele(identifier, timeout=1)
            if ele:
                return ele
        except Exception:
            pass
            
        return None
        
    def click(self, element_id: str) -> bool:
        """Click an element intelligently."""
        ele = self._find_element_intelligently(element_id)
        if ele:
            try:
                # by_js=True helps bypass some tricky interceptors
                ele.click(by_js=True) 
                self.page.wait.doc_loaded()
                time.sleep(2)
                
                # Kill any popunders that opened after clicking
                try:
                    self.page.close_other_tabs()
                except:
                    pass
                    
                return True
            except Exception as e:
                print(f"Failed to click {element_id}: {e}")
                return False
        return False
        
    def type_text(self, element_id: str, text: str, press_enter: bool = False) -> bool:
        """Type text into an input intelligently."""
        ele = self._find_element_intelligently(element_id)
        if ele:
            try:
                ele.input(text, clear=True)
                if press_enter:
                    # Press enter key
                    self.page.actions.type('\n')
                self.page.wait.doc_loaded()
                time.sleep(2)
                
                # Kill any popunders
                try:
                    self.page.close_other_tabs()
                except:
                    pass
                    
                return True
            except Exception as e:
                print(f"Failed to type in {element_id}: {e}")
                return False
        return False
        
    def take_screenshot(self, save_path: str = "screenshot.jpg"):
        """Take a screenshot of the current page and save it locally."""
        try:
            self.page.get_screenshot(path=save_path)
            return True
        except Exception as e:
            print(f"Failed to take screenshot: {e}")
            return False
        
    def get_page_text(self) -> str:
        """Extract clean, readable text from the current page."""
        return self.page.body.text
        
    def close(self):
        """Quit the browser."""
        self.page.quit()
