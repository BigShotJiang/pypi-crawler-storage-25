"""OpenSearch integration utilities and client wrapper.

Provides OpenSearch client configuration, connection management,
health monitoring, and blue-green index lifecycle management
for search and analytics workloads.
"""

from ..core.require_extra import require_extra

__all__ = (
    "BlueGreenManager",
    "IndexState",
    "OpenSearchConfig",
    "OpenSearchClient",
    "is_opensearch_connected",
)

require_extra("opensearch", "opensearchpy")

from .blue_green import BlueGreenManager, IndexState
from .client import OpenSearchClient
from .config import OpenSearchConfig
from .health import is_opensearch_connected
