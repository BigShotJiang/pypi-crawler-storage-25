"""MCP server exposing applyClangFormat for C/C++ source files."""

from __future__ import annotations

import asyncio
import glob as glob_module
import logging
import os
import shutil
import subprocess
import sys
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

SERVER_NAME = "cpp-format"
SERVER_VERSION = "0.2.1"

CPP_EXTENSIONS = frozenset(
    {
        ".c",
        ".cc",
        ".cpp",
        ".cxx",
        ".c++",
        ".h",
        ".hh",
        ".hpp",
        ".hxx",
        ".h++",
        ".ipp",
        ".tpp",
        ".inl",
    }
)

logger = logging.getLogger(SERVER_NAME)


def _resolve_binary() -> str:
    explicit = os.environ.get("CLANG_FORMAT_BIN", "").strip()
    if explicit:
        return explicit
    return "clang-format"


def _resolve_style(style_arg: str | None) -> str:
    if style_arg:
        return style_arg
    config_path = os.environ.get("CLANG_FORMAT_CONFIG", "").strip()
    if config_path:
        return f"file:{config_path}"
    fallback = os.environ.get("CLANG_FORMAT_STYLE", "").strip()
    if fallback:
        return fallback
    return "file"


def _expand_inputs(files: list[str]) -> list[str]:
    expanded: list[str] = []
    for raw in files:
        item = raw.strip()
        if not item:
            continue
        if not os.path.isabs(item):
            logger.warning(
                "received relative path '%s'; resolving against cwd '%s'",
                item,
                os.getcwd(),
            )
            item = os.path.abspath(item)
        item = item.replace("\\", "/")
        if glob_module.has_magic(item):
            matched = glob_module.glob(item, recursive=True)
            if not matched:
                logger.warning("glob pattern '%s' matched no files", item)
                continue
            expanded.extend(os.path.abspath(p) for p in matched)
            continue
        path = Path(item)
        if not path.exists():
            logger.warning("path '%s' does not exist; skipping", item)
            continue
        if path.is_dir():
            logger.warning(
                "path '%s' is a directory; use an explicit glob pattern",
                item,
            )
            continue
        if path.is_file():
            expanded.append(str(path.resolve()))
    deduped: list[str] = []
    seen: set[str] = set()
    for p in expanded:
        norm = os.path.normcase(os.path.normpath(p))
        if norm in seen:
            continue
        seen.add(norm)
        deduped.append(p)
    return deduped


def _filter_cpp(paths: list[str]) -> list[str]:
    return [p for p in paths if Path(p).suffix.lower() in CPP_EXTENSIONS]


def _run_clang_format(binary: str, style: str, files: list[str]) -> tuple[int, str, str]:
    cmd = [binary, "-i", f"--style={style}", *files]
    proc = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        check=False,
    )
    return proc.returncode, proc.stdout, proc.stderr


def _format_files(files: list[str], style: str | None) -> str:
    candidates = _expand_inputs(files)
    if not candidates:
        return (
            f"[{SERVER_NAME}] no valid files matched. "
            "ensure absolute paths and use explicit glob patterns for directories."
        )
    targets = _filter_cpp(candidates)
    if not targets:
        return (
            f"[{SERVER_NAME}] no C/C++ files among inputs "
            f"(allowed extensions: {', '.join(sorted(CPP_EXTENSIONS))})."
        )
    binary = _resolve_binary()
    if shutil.which(binary) is None and not Path(binary).is_file():
        raise RuntimeError(
            f"[{SERVER_NAME}] clang-format binary not found: '{binary}'. "
            "set CLANG_FORMAT_BIN or ensure clang-format is on PATH."
        )
    resolved_style = _resolve_style(style)
    code, stdout, stderr = _run_clang_format(binary, resolved_style, targets)
    if code != 0:
        detail = (stderr or stdout or "").strip()
        raise RuntimeError(
            f"[{SERVER_NAME}] clang-format exited with code {code}: {detail}"
        )
    summary = (
        f"[{SERVER_NAME}] formatted {len(targets)} file(s) with style={resolved_style}"
    )
    body = "\n".join(f"  - {p}" for p in targets)
    return f"{summary}\n{body}"


def build_server() -> Server:
    server: Server = Server(SERVER_NAME)

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="applyClangFormat",
                description=(
                    "Format C/C++ source files in-place using clang-format. "
                    "Provide ABSOLUTE paths via `files` (array of paths/globs) or a "
                    "single ABSOLUTE path via `file_path` (string, hook-friendly). "
                    "At least one of `files` or `file_path` is required; both may be "
                    "given and are merged. Directory paths without a glob are "
                    "rejected. Non-C/C++ files are silently skipped. Style "
                    "resolution: explicit `style` arg > CLANG_FORMAT_CONFIG (file) "
                    "> CLANG_FORMAT_STYLE > clang-format auto-detection."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "files": {
                            "type": "array",
                            "items": {"type": "string"},
                            "minItems": 1,
                            "description": (
                                "Absolute file paths or absolute glob patterns. "
                                "Relative paths are resolved against cwd with a warning."
                            ),
                        },
                        "file_path": {
                            "type": "string",
                            "description": (
                                "Single absolute file path. Convenience field for "
                                "hook definitions where ${tool_input.file_path} "
                                "substitution is only applied to flat string values, "
                                "not array elements. At least one of `files` or "
                                "`file_path` must be provided."
                            ),
                        },
                        "style": {
                            "type": "string",
                            "description": (
                                "Optional explicit style (LLVM, Google, file, "
                                "file:<path>, ...). Overrides environment defaults."
                            ),
                        },
                    },
                },
            )
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        if name != "applyClangFormat":
            raise ValueError(f"unknown tool: {name}")
        files_arg = arguments.get("files")
        if files_arg is not None and not isinstance(files_arg, list):
            raise ValueError("'files' must be an array of strings when provided")
        files: list[str] = list(files_arg) if files_arg else []
        file_path = arguments.get("file_path")
        if file_path is not None:
            if not isinstance(file_path, str) or not file_path.strip():
                raise ValueError(
                    "'file_path' must be a non-empty string when provided"
                )
            files.append(file_path)
        if not files:
            raise ValueError(
                "provide at least one of 'files' (array) or 'file_path' (string)"
            )
        style = arguments.get("style")
        if style is not None and not isinstance(style, str):
            raise ValueError("'style' must be a string when provided")
        message = _format_files(files, style)
        return [TextContent(type="text", text=message)]

    return server


async def _async_main() -> None:
    logging.basicConfig(
        level=os.environ.get("CPP_FORMAT_LOG_LEVEL", "INFO").upper(),
        format="[%(name)s] %(levelname)s: %(message)s",
        stream=sys.stderr,
    )
    server = build_server()
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def main() -> None:
    asyncio.run(_async_main())


if __name__ == "__main__":
    main()
