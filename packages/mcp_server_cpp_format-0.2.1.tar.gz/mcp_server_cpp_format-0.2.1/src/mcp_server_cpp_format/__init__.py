"""MCP server that formats C/C++ files with clang-format."""

from .server import main

__all__ = ["main"]
__version__ = "0.1.0"
