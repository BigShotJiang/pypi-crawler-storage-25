# mcp-server-cpp-format

Model Context Protocol (MCP) server that formats C/C++ source files in-place using `clang-format`.

Designed to back the [`cpp-format` Claude Code plugin](https://github.com/tomo-jyjo/tomo-claude-plugins),
but usable as a standalone MCP server in any MCP-compatible client.

## Install

The server is published on PyPI and intended to be invoked via `uvx`:

```bash
uvx mcp-server-cpp-format
```

Or install into a regular environment:

```bash
pip install mcp-server-cpp-format
mcp-server-cpp-format
```

Requires Python 3.10+ and `clang-format` available on PATH (or via `CLANG_FORMAT_BIN`).

## Tools

### `applyClangFormat`

Formats C/C++ source files in-place.

**Arguments**

At least one of `files` or `file_path` is required; both may be supplied and are merged.

| Name | Type | Required | Description |
|------|------|----------|-------------|
| `files` | `string[]` | one of | Absolute file paths or absolute glob patterns (`/path/**/*.cpp`). Directory paths without a glob are rejected. |
| `file_path` | `string` | one of | Single absolute file path. Convenience field for hook definitions where `${tool_input.file_path}` substitution is only applied to flat string values, not array elements. |
| `style` | `string` | no | Explicit style (`LLVM`, `Google`, `file`, `file:<path>`, ...). Overrides environment defaults. |

**Allowed extensions** (others are silently skipped):

```
.c .cc .cpp .cxx .c++ .h .hh .hpp .hxx .h++ .ipp .tpp .inl
```

## Style resolution priority

1. `style` argument when explicitly provided
2. `CLANG_FORMAT_CONFIG` env (path to a `.clang-format`) → `--style=file:<path>`
3. `CLANG_FORMAT_STYLE` env (e.g. `LLVM`, `Google`) → `--style=<style>`
4. Default → `--style=file` (clang-format auto-discovers `.clang-format` upward; falls back to LLVM)

## Environment variables

| Variable | Effect |
|----------|--------|
| `CLANG_FORMAT_BIN` | Absolute path to a `clang-format` binary. Default: `clang-format` from PATH. |
| `CLANG_FORMAT_CONFIG` | Absolute path to a `.clang-format` file to enforce. |
| `CLANG_FORMAT_STYLE` | Fallback style name when no `.clang-format` is provided/found. |
| `CPP_FORMAT_LOG_LEVEL` | Logging verbosity for the server (default `INFO`). |

## License

MIT
