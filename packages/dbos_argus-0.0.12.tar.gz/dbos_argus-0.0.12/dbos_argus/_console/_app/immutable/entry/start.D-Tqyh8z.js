import{l as o,a as r}from"../chunks/BZFzL47i.js";export{o as load_css,r as start};
