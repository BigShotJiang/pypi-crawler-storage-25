# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
# Patent pending: PCT/IB2026/053378, PCT/IB2026/053405
# See NOTICE and LICENSE files for details.

"""
CipherExplain HTTP client.

Usage:
    from cipherexplain_sdk import CipherExplainClient, extract_spec

    spec   = extract_spec(model, "my_model", feature_names)
    client = CipherExplainClient(api_key="vb_...")
    client.register(spec)

    result = client.explain_raw("my_model", x_raw)
    print(result["shap_values"])

Error handling — all methods raise httpx.HTTPStatusError on failure:
    401  missing X-API-Key
    403  invalid/inactive key, or tier restriction (e.g. /report needs Developer+)
    404  model not found
    409  model ID already registered (delete first or use a different ID)
    422  validation error — malformed spec or features list
    429  quota exceeded — model slot limit or monthly call limit
"""
from __future__ import annotations

import io
from typing import Any

import httpx


_DEFAULT_BASE_URL = "https://cipherexplain.vaultbytes.com"


class CipherExplainClient:
    """
    Synchronous HTTP client for the CipherExplain API.

    All authenticated requests include ``X-API-Key`` automatically.
    All methods raise :class:`httpx.HTTPStatusError` on non-2xx responses
    — check ``exc.response.status_code`` to handle specific errors.
    """

    def __init__(self, api_key: str, base_url: str = _DEFAULT_BASE_URL, timeout: float = 30.0):
        self._headers = {"X-API-Key": api_key, "Content-Type": "application/json"}
        self._base = base_url.rstrip("/")
        self._timeout = timeout

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _post(self, path: str, body: dict) -> dict:
        with httpx.Client(headers=self._headers, timeout=self._timeout) as http:
            resp = http.post(f"{self._base}{path}", json=body)
        resp.raise_for_status()
        return resp.json()

    def _post_raw(self, path: str, body: dict) -> bytes:
        """POST and return raw bytes (used for PDF responses)."""
        with httpx.Client(headers=self._headers, timeout=self._timeout) as http:
            resp = http.post(f"{self._base}{path}", json=body)
        resp.raise_for_status()
        return resp.content

    def _get(self, path: str, auth: bool = True) -> dict:
        headers = self._headers if auth else {"Content-Type": "application/json"}
        with httpx.Client(headers=headers, timeout=self._timeout) as http:
            resp = http.get(f"{self._base}{path}")
        resp.raise_for_status()
        return resp.json()

    def _delete(self, path: str) -> dict:
        with httpx.Client(headers=self._headers, timeout=self._timeout) as http:
            resp = http.delete(f"{self._base}{path}")
        resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def health(self) -> dict:
        """
        Check API health. No API key required.

        Returns ``{"status": "ok"}`` when the service is up.
        Use this as a liveness check before making explain calls.

        Raises:
            httpx.HTTPStatusError: if the service is unavailable.
        """
        return self._get("/health", auth=False)

    # ------------------------------------------------------------------
    # Model management
    # ------------------------------------------------------------------

    def load_demo_model(self) -> dict:
        """
        Load the shared demo credit model (``credit_model``).

        Downloads the UCI Adult dataset, trains a logistic regression,
        and registers it as ``credit_model`` — ready for ``/explain`` calls.
        Safe to call multiple times.

        Returns model metadata with ``model_id``, ``feature_count``,
        ``coalition_count``, ``feature_names``.

        Raises:
            httpx.HTTPStatusError: 401/403 for auth errors, 429 for rate limit
                (capped at 2 calls/hour).
        """
        return self._post("/startup", {})

    def register(self, spec: dict, x_ref: list[list[float]] | None = None) -> dict:
        """
        Register a model using your own pre-trained weights.

        ``spec`` is the dict returned by :func:`~cipherexplain_sdk.extract_spec`
        or :func:`~cipherexplain_sdk.from_weights`. No training data is sent —
        only coefficient and intercept arrays.

        Args:
            spec: Model spec dict from ``extract_spec`` or ``from_weights``.
            x_ref: Optional representative sample, shape (n_samples, n_features),
                used for FHE quantization calibration. 50–200 rows is sufficient.
                When omitted the server falls back to a zero vector (fast but
                produces all-zero SHAP values in FHE mode).

        Returns:
            dict with ``model_id``, ``feature_count``, ``coalition_count``,
            ``n_classes``, ``is_binary``, ``model_type``.

        Raises:
            httpx.HTTPStatusError:
                401 — missing API key
                403 — invalid key
                409 — model_id already registered; call ``delete(model_id)`` first
                422 — invalid spec (shape mismatch, non-finite values, etc.)
                429 — model slot limit reached for your tier
        """
        body = dict(spec)
        if x_ref is not None:
            body["x_ref"] = x_ref
        return self._post("/models/register", body)

    def delete(self, model_id: str) -> dict:
        """
        Delete a registered model and free its slot.

        Raises:
            httpx.HTTPStatusError:
                401 — missing key
                403 — invalid key
                404 — model not found under your key
        """
        return self._delete(f"/models/{model_id}")

    def list_models(self) -> list[dict]:
        """
        Return metadata for all models available to your key.

        Includes your own registered models (``namespace="yours"``) and
        global demo models (``namespace="global"``).

        Each entry contains: ``model_id``, ``feature_count``,
        ``coalition_count``, ``feature_names``, ``namespace``.

        Raises:
            httpx.HTTPStatusError: 401/403 for auth errors.
        """
        return self._get("/models")["models"]

    # ------------------------------------------------------------------
    # Explanations
    # ------------------------------------------------------------------

    def explain(self, model_id: str, features: list[float], fhe_mode: str = "disable") -> dict:
        """
        Run an encrypted SHAP explanation with pre-scaled features.

        Args:
            model_id: ID of a registered model.
            features: Input vector — values must be pre-scaled if your model
                was trained on scaled data. Use :meth:`explain_raw` to let
                the API apply the embedded scaler automatically.
            fhe_mode: ``"disable"`` (default, plaintext), ``"simulate"``
                (quantization-correct FHE simulation), or ``"execute"``
                (real FHE encryption). Only supported for logistic_regression
                models.

        Returns:
            dict with keys:
                ``prediction`` (float 0–1), ``base_rate`` (float 0–1),
                ``shap_values`` (list[float]), ``feature_names`` (list[str]),
                ``metadata`` (dict with coalition count, latency, axiom error).

        Raises:
            httpx.HTTPStatusError:
                401/403 — auth errors
                404 — model not found
                429 — monthly explain quota exceeded
        """
        return self._post("/explain", {"model_id": model_id, "features": features, "fhe_mode": fhe_mode})

    def explain_raw(self, model_id: str, features: list[float], fhe_mode: str = "disable") -> dict:
        """
        Same as :meth:`explain` but applies the model's built-in scaler first.

        Use this when passing raw (unscaled) feature values. The API applies
        the ``StandardScaler`` that was embedded in the model spec at
        registration time. If no scaler was embedded, values are passed
        through unchanged.

        Args:
            model_id: ID of a registered model.
            features: Raw input values (e.g. ``[38, 13, 0, 0, 40]``).
            fhe_mode: ``"disable"`` (default, plaintext), ``"simulate"``
                (quantization-correct FHE simulation), or ``"execute"``
                (real FHE encryption). Only supported for logistic_regression
                models.

        Returns:
            Same structure as :meth:`explain`.

        Raises:
            httpx.HTTPStatusError:
                401/403 — auth errors
                404 — model not found
                429 — monthly explain quota exceeded
        """
        return self._post("/explain_raw", {"model_id": model_id, "features": features, "fhe_mode": fhe_mode})

    # ------------------------------------------------------------------
    # Reports
    # ------------------------------------------------------------------

    def report(self, benchmark_data: dict) -> bytes:
        """
        Generate a PDF audit report from FHE oracle benchmark results.

        Requires **Developer** or **Enterprise** tier.

        Args:
            benchmark_data: JSON object returned by the FHE Testing Oracle,
                typically loaded from ``oracle_benchmark.json``. Must contain
                ``config``, ``random_search``, ``cma_es_search``,
                and ``comparison`` keys.

        Returns:
            Raw PDF bytes. Save with::

                with open("audit_report.pdf", "wb") as f:
                    f.write(client.report(benchmark_data))

        Raises:
            httpx.HTTPStatusError:
                401/403 — auth errors or free tier (upgrade required)
                422 — malformed benchmark payload
        """
        return self._post_raw("/report", benchmark_data)

    # ------------------------------------------------------------------
    # Account
    # ------------------------------------------------------------------

    def usage(self) -> dict:
        """
        Return monthly quota usage for the current key.

        Returns:
            dict with ``month`` (YYYY-MM), ``tier``, and nested dicts
            ``explain`` and ``oracle``, each with ``used``, ``limit``,
            ``remaining``.

        Raises:
            httpx.HTTPStatusError: 401/403 for auth errors.
        """
        return self._get("/usage")

    def rotate_key(self) -> dict:
        """
        Rotate the current API key.

        Issues a new ``vb_...`` key with the same tier and migrates all
        registered models automatically. The current key is deactivated
        **immediately** — update all callers before the response leaves
        your terminal.

        Returns:
            dict with ``new_key`` (str), ``models_migrated`` (int),
            ``note`` (str reminder).

        After rotating, create a new client::

            result = client.rotate_key()
            client = CipherExplainClient(api_key=result["new_key"])

        Raises:
            httpx.HTTPStatusError: 401/403 for auth errors.
        """
        return self._post("/keys/rotate", {})