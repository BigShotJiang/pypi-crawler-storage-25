# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
# Patent pending: PCT/IB2026/053378, PCT/IB2026/053405
# See NOTICE and LICENSE files for details.

"""Client-side FHE key management and encrypt/decrypt for CipherExplain CKKS path.

The client holds the CKKS secret key. The server receives only the public key
and evaluation keys. The secret key never leaves the client.

Patent: PCT/IB2026/053405 (Homomorphic Encrypted SHAP Values)
"""
import os
import numpy as np
import openfhe
from pathlib import Path

_KEY_DIR = Path.home() / ".cipherexplain"
_D = 50

# tau is set to 1e-6, consistent with CKKS approximate arithmetic at
# L=10, N=2^15. The paper reports post-redistribution axiom error of
# 1.16e-16 (machine epsilon) in the plaintext path and 1.65e-5 in
# the FHE path before redistribution. tau=1e-6 is between these,
# catching FHE arithmetic failures while tolerating normal CKKS noise.
DEFAULT_AXIOM_TAU = 1e-6


class EfficiencyAxiomViolationError(Exception):
    """Raised when the Shapley efficiency axiom check fails after decryption.

    This may indicate numerical failure during ciphertext transport,
    rescaling, or modulus switching — or a tampered server response.
    See paper Appendix B for limitations against a malicious server.
    """
    pass


def _get_context():
    """Returns a fresh CKKS context with the standard parameters."""
    import sys
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))
    from cipherexplain.core.fhe_params import get_ckks_context
    return get_ckks_context()


class FHEClient:
    """Manages client-side CKKS keys and encrypts/decrypts CipherExplain payloads.

    On first instantiation for a model_id, generates a fresh keypair and
    persists it to ~/.cipherexplain/{model_id}/. On subsequent instantiation,
    loads the existing keypair from disk.

    The server NEVER receives the secret key. Only the public key and
    evaluation keys are sent to the server via get_public_key_bundle().
    """

    def __init__(self, model_id: str, key_dir: Path | None = None):
        self._model_id = model_id
        self._key_dir = (key_dir or _KEY_DIR) / model_id
        self._key_dir.mkdir(parents=True, exist_ok=True)

        pk_path = self._key_dir / "public_key.bin"
        sk_path = self._key_dir / "secret_key.bin"
        emk_path = self._key_dir / "eval_mult_key.bin"
        eak_path = self._key_dir / "eval_automorphism_key.bin"
        cc_path = self._key_dir / "crypto_context.bin"

        if pk_path.exists() and sk_path.exists() and cc_path.exists():
            # Load existing keypair from disk — no keygen, no _get_context().
            self._cc = openfhe.DeserializeCryptoContextString(
                cc_path.read_bytes(), openfhe.BINARY)
            self._pk = openfhe.DeserializePublicKeyString(
                pk_path.read_bytes(), openfhe.BINARY)
            self._sk = openfhe.DeserializePrivateKeyString(
                sk_path.read_bytes(), openfhe.BINARY)
            # Eval keys live in a global store keyed by keyTag.
            # If this process already loaded them (e.g. second FHEClient
            # for the same model), the insert raises — safe to skip.
            try:
                openfhe.DeserializeEvalMultKeyString(
                    emk_path.read_bytes(), openfhe.BINARY)
            except RuntimeError:
                pass
            try:
                openfhe.DeserializeEvalAutomorphismKeyString(
                    eak_path.read_bytes(), openfhe.BINARY)
            except RuntimeError:
                pass
        else:
            # Generate new keypair and persist
            self._cc, keys = _get_context()
            self._pk = keys.publicKey
            self._sk = keys.secretKey

            pk_path.write_bytes(
                openfhe.Serialize(self._pk, openfhe.BINARY))
            sk_path.write_bytes(
                openfhe.Serialize(self._sk, openfhe.BINARY))
            emk_path.write_bytes(
                openfhe.SerializeEvalMultKeyString(openfhe.BINARY))
            eak_path.write_bytes(
                openfhe.SerializeEvalAutomorphismKeyString(
                    openfhe.BINARY))
            cc_path.write_bytes(
                openfhe.Serialize(self._cc, openfhe.BINARY))

    def get_public_key_bytes(self) -> bytes:
        """Returns serialized public key for sending to server."""
        return openfhe.Serialize(self._pk, openfhe.BINARY)

    def get_eval_key_bytes(self) -> dict[str, bytes]:
        """Returns serialized evaluation keys for sending to server.

        Server needs these to perform homomorphic operations on
        ciphertexts encrypted under this client's public key.
        """
        return {
            "eval_mult_key": openfhe.SerializeEvalMultKeyString(
                openfhe.BINARY),
            "eval_automorphism_key":
                openfhe.SerializeEvalAutomorphismKeyString(
                    openfhe.BINARY),
        }

    def get_public_key_bundle(self) -> dict[str, bytes]:
        """Returns all key material needed by the server: pk + eval keys.

        Send this to the server's register_client_keys() endpoint.
        """
        eval_keys = self.get_eval_key_bytes()
        return {
            "public_key": self.get_public_key_bytes(),
            "eval_mult_key": eval_keys["eval_mult_key"],
            "eval_automorphism_key": eval_keys["eval_automorphism_key"],
        }

    def encrypt(self, x: np.ndarray) -> bytes:
        """Encrypts feature vector x of length d=50.

        Pads to full batch size (16384 slots) with zeros.
        Returns serialized ciphertext bytes.
        """
        if len(x) != _D:
            raise ValueError(
                f"Expected {_D} features, got {len(x)}")
        padded = np.zeros(16384, dtype=np.float64)
        padded[:_D] = x
        pt = self._cc.MakeCKKSPackedPlaintext(padded.tolist())
        ct = self._cc.Encrypt(self._pk, pt)
        return openfhe.Serialize(ct, openfhe.BINARY)

    def encrypt_baseline(self, b: np.ndarray) -> bytes:
        """Encrypts a personalized baseline vector (paper §3.2).

        Client-supplied Enc(b) for interventional counterfactual
        explanations. Send to the server's explain_encrypted() as enc_b_bytes.
        """
        if len(b) != _D:
            raise ValueError(
                f"Expected {_D} baseline features, got {len(b)}")
        padded = np.zeros(16384, dtype=np.float64)
        padded[:_D] = b
        pt = self._cc.MakeCKKSPackedPlaintext(padded.tolist())
        ct = self._cc.Encrypt(self._pk, pt)
        return openfhe.Serialize(ct, openfhe.BINARY)

    def decrypt(self, ciphertext_bytes: bytes,
                n_values: int) -> np.ndarray:
        """Decrypts a received ciphertext.

        Returns first n_values slots as a numpy array.
        Used to decrypt the encrypted SHAP vector from the server.
        """
        ct = openfhe.DeserializeCiphertextString(
            ciphertext_bytes, openfhe.BINARY)
        result = self._cc.Decrypt(self._sk, ct)
        result.SetLength(n_values)
        return np.array(result.GetRealPackedValue()[:n_values])

    def decrypt_result(
        self,
        enc_pred_bytes: bytes,
        enc_shap_bytes: bytes,
        base_rate: float,
        d: int = _D,
        tau: float | None = None,
        apply_redistribution: bool = True,
    ) -> dict:
        """Decrypt server response and verify the Shapley efficiency axiom.

        This is the client-side post-decryption verification described in
        paper Appendix B.

        Args:
            enc_pred_bytes: serialized Enc(ŷ) from server
            enc_shap_bytes: serialized Enc(ϕ̂) from server
            base_rate: public base rate (returned by server in metadata)
            d: feature dimensionality
            tau: axiom check tolerance (default: 1e-6)
            apply_redistribution: apply efficiency axiom redistribution

        Returns:
            dict with prediction, shap_values, base_rate, axiom_error

        Raises:
            EfficiencyAxiomViolationError: if axiom check fails
        """
        if tau is None:
            tau = DEFAULT_AXIOM_TAU

        # Decrypt prediction
        y_hat = float(self.decrypt(enc_pred_bytes, 1)[0])

        # Decrypt SHAP values
        phi = self.decrypt(enc_shap_bytes, d)

        # Pre-redistribution axiom error (for diagnostics)
        pre_residual = float(abs(phi.sum() + base_rate - y_hat))

        # Apply efficiency axiom redistribution (Claim 11, Equation 5)
        if apply_redistribution:
            target_sum = y_hat - base_rate
            residual = target_sum - phi.sum()
            abs_sum = float(np.abs(phi).sum())
            if abs_sum > 1e-12:
                phi = phi + residual * (np.abs(phi) / abs_sum)
            else:
                phi = phi + residual / d

        # Post-redistribution axiom error
        axiom_err = float(abs(phi.sum() + base_rate - y_hat))

        # Axiom check (Appendix B) — only meaningful after redistribution.
        # Without redistribution the sampling approximation error dominates.
        if apply_redistribution and axiom_err > tau:
            raise EfficiencyAxiomViolationError(
                f"Axiom check failed: residual {axiom_err:.2e} > tau {tau:.2e}. "
                "This may indicate numerical failure or a tampered server response."
            )

        return {
            "prediction": y_hat,
            "base_rate": base_rate,
            "shap_values": [float(v) for v in phi],
            "axiom_error": axiom_err,
            "pre_redistribution_residual": pre_residual,
        }


if __name__ == "__main__":
    import tempfile, time
    import numpy as np
    from pathlib import Path

    with tempfile.TemporaryDirectory() as tmp:
        t0 = time.time()
        client = FHEClient("test-model", key_dir=Path(tmp))
        t1 = time.time()
        print(f"Keygen: {t1-t0:.1f}s")

        x = np.random.rand(50).astype(np.float64)
        ct_bytes = client.encrypt(x)
        print(f"Ciphertext size: {len(ct_bytes)/1024:.0f} KB")

        recovered = client.decrypt(ct_bytes, 50)
        max_err = np.max(np.abs(recovered - x))
        print(f"Roundtrip max error: {max_err:.2e}")
        assert max_err < 1e-4, f"roundtrip error too large: {max_err}"

        # Test keypair persistence
        client2 = FHEClient("test-model", key_dir=Path(tmp))
        ct_bytes2 = client2.encrypt(x)
        recovered2 = client.decrypt(ct_bytes2, 50)
        max_err2 = np.max(np.abs(recovered2 - x))
        print(f"Persistence roundtrip max error: {max_err2:.2e}")
        assert max_err2 < 1e-4, f"persistence error: {max_err2}"

        # Test key bundle for server
        bundle = client.get_public_key_bundle()
        print(f"Public key size: {len(bundle['public_key'])/1024:.0f} KB")
        print(f"EvalMult key size: "
              f"{len(bundle['eval_mult_key'])/1024:.0f} KB")
        print(f"EvalAutomorphism key size: "
              f"{len(bundle['eval_automorphism_key'])/1024/1024:.1f} MB")

        # Test personalized baseline encryption
        baseline = np.random.rand(50).astype(np.float64)
        enc_b = client.encrypt_baseline(baseline)
        recovered_b = client.decrypt(enc_b, 50)
        assert np.max(np.abs(recovered_b - baseline)) < 1e-4

        print("ALL PASS")