# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
# Patent pending: PCT/IB2026/053378, PCT/IB2026/053405
# See NOTICE and LICENSE files for details.

"""CipherExplain SDK — register and explain models via the CipherExplain API."""

from .client import CipherExplainClient
from .cluster_a import (
    ClusterAVerificationResult,
    ComponentVerdict,
    verify_cluster_a_response,
)
from .extractors import (
    extract_spec, from_weights, from_sklearn_tree, from_sklearn_ensemble,
)

__all__ = [
    "CipherExplainClient",
    "ClusterAVerificationResult",
    "ComponentVerdict",
    "extract_spec",
    "from_weights",
    "from_sklearn_tree",
    "from_sklearn_ensemble",
    "verify_cluster_a_response",
]
__version__ = "0.3.0"
