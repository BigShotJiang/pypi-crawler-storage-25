# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
# Patent pending: PCT/IB2026/053378, PCT/IB2026/053405
# See NOTICE and LICENSE files for details.

"""
Extract a JSON-serialisable ModelSpec dict from a trained model.

No pickle is ever sent to the API. Only weight arrays (or tree structures)
are extracted and transmitted over HTTPS.

Supported model types
---------------------
Tree ensembles  — RandomForestClassifier/Regressor, GradientBoostingClassifier/Regressor,
                  DecisionTreeClassifier/Regressor → use from_sklearn_ensemble() / from_sklearn_tree()
Linear sklearn  — LogisticRegression, LinearSVC, any object with coef_ / intercept_
                  → use extract_spec()
PyTorch linear  — nn.Linear, pure-linear nn.Sequential (no activations) → use extract_spec()
TensorFlow      — use from_weights(): layer.get_weights() gives [W, b]
JAX             — use from_weights() with your parameter arrays
statsmodels     — use from_weights() with model.params
R glm           — export coef() to CSV, load in Python, use from_weights()
Any other       — use from_weights() and pass coef/intercept directly

Note: extract_spec() handles linear models only. Non-linear PyTorch models
(ReLU, BatchNorm, etc.) are not supported. MLPs with activations are not
supported. Tree ensembles must use from_sklearn_tree() / from_sklearn_ensemble().
"""
from __future__ import annotations

from typing import Optional

import numpy as np


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_spec(
    model,
    model_id: str,
    feature_names: list[str],
    scaler=None,
    baseline: Optional[list[float]] = None,
    classes: Optional[list[int]] = None,
) -> dict:
    """
    Convert a trained model into a CipherExplain-compatible ModelSpec dict.

    Supports:
    - sklearn ``LogisticRegression``, ``LinearSVC``
    - Any sklearn-compatible object exposing ``coef_`` / ``intercept_`` / ``classes_``
    - PyTorch ``nn.Linear`` or ``nn.Sequential`` ending in ``nn.Linear``
    - Pass ``classes`` explicitly if your object doesn't carry ``classes_``

    Args:
        model: Trained model instance (see above).
        model_id: Unique name for this model (``^[A-Za-z0-9_\\-.]+$``, max 128 chars).
        feature_names: Feature name strings matching the column order at predict time.
        scaler: Optional sklearn ``StandardScaler``. Embedded in the spec so the API
            auto-scales raw inputs on ``/explain_raw``.
        baseline: Optional per-feature baseline. Defaults to scaler mean or zeros.
        classes: Class label list (e.g. ``[0, 1]``). Required for PyTorch models and
            any object that lacks a ``classes_`` attribute.

    Returns:
        dict conforming to the ``ModelSpec`` schema accepted by ``POST /models/register``.

    Raises:
        TypeError: Unsupported model type.
        ValueError: Model is not fitted, or shapes are inconsistent.
    """
    # --- Try sklearn-style duck typing first (covers sklearn + any compat object) ---
    if hasattr(model, "coef_") and hasattr(model, "intercept_"):
        return _from_sklearn_like(model, model_id, feature_names, scaler, baseline, classes)

    # --- PyTorch ---
    try:
        import torch.nn as nn
        if isinstance(model, (nn.Linear, nn.Sequential)):
            return _from_pytorch(model, model_id, feature_names, scaler, baseline, classes)
    except ImportError:
        pass

    raise TypeError(
        f"Unsupported model: {type(model).__name__}.\n"
        f"  Linear models: sklearn LogisticRegression / LinearSVC, PyTorch nn.Linear / nn.Sequential,\n"
        f"    or any object with coef_ / intercept_ attributes.\n"
        f"  Tree ensembles: use from_sklearn_ensemble() for RandomForest / GradientBoosting,\n"
        f"    or from_sklearn_tree() for DecisionTree.\n"
        f"  Other frameworks: use from_weights() and pass coef/intercept directly."
    )


def from_weights(
    coef: list | np.ndarray,
    intercept: list | np.ndarray,
    model_id: str,
    feature_names: list[str],
    model_type: str = "logistic_regression",
    classes: Optional[list[int]] = None,
    scaler_mean: Optional[list[float]] = None,
    scaler_scale: Optional[list[float]] = None,
    baseline: Optional[list[float]] = None,
) -> dict:
    """
    Build a ModelSpec dict directly from raw weight arrays.

    Use this for any framework not covered by ``extract_spec``:
    TensorFlow/Keras ``Dense`` layer, JAX ``stax.Dense``, XGBoost linear,
    LightGBM linear, statsmodels logit, R glm exported weights, etc.

    Args:
        coef: 2-D weight matrix, shape ``(n_classes_or_1, n_features)``.
              Binary classification: shape ``(1, n_features)``.
              Multi-class: shape ``(n_classes, n_features)``.
        intercept: 1-D bias vector, shape ``(n_classes_or_1,)``.
        model_id: Unique model name.
        feature_names: Feature name strings.
        model_type: ``"logistic_regression"`` (default) or ``"linear_svc"``.
        classes: Class labels, e.g. ``[0, 1]``. Defaults to ``[0, ..., n_classes-1]``.
        scaler_mean: Per-feature mean for auto-scaling. Required if using ``/explain_raw``.
        scaler_scale: Per-feature std for auto-scaling.
        baseline: Per-feature SHAP baseline. Defaults to scaler_mean or zeros.

    Returns:
        ModelSpec dict ready for ``POST /models/register``.

    Examples:
        TensorFlow / Keras ``Dense`` layer (no activation)::

            w, b = model.layers[-1].get_weights()
            # Keras weight shape: (n_features, n_classes) — transpose to (n_classes, n_features)
            spec = from_weights(w.T, b, "keras_lr", feature_names, classes=[0, 1])

        JAX / Flax linear parameters::

            params = state.params["Dense_0"]
            spec = from_weights(params["kernel"].T, params["bias"],
                                "jax_model", feature_names, classes=[0, 1])

        statsmodels Logit::

            import numpy as np
            # params includes intercept at index 0 for statsmodels
            coef = result.params[1:].reshape(1, -1)
            intercept = result.params[:1]
            spec = from_weights(coef, intercept, "sm_logit", feature_names, classes=[0, 1])

        R glm (export with write.csv(coef(model), "coef.csv"))::

            import pandas as pd, numpy as np
            coef_df = pd.read_csv("coef.csv", index_col=0)
            coef = coef_df.values[1:].reshape(1, -1)   # drop intercept row
            intercept = coef_df.values[:1].flatten()
            spec = from_weights(coef, intercept, "r_glm", feature_names, classes=[0, 1])
    """
    coef_arr = np.asarray(coef, dtype=np.float64)
    intercept_arr = np.asarray(intercept, dtype=np.float64)

    if coef_arr.ndim == 1:
        coef_arr = coef_arr.reshape(1, -1)
    if intercept_arr.ndim == 0:
        intercept_arr = intercept_arr.reshape(1)

    n_rows = coef_arr.shape[0]
    if classes is None:
        classes = list(range(n_rows if n_rows > 1 else 2))

    spec: dict = {
        "model_id": model_id,
        "model_type": model_type,
        "feature_names": list(feature_names),
        "spec": {
            "coef": coef_arr.tolist(),
            "intercept": intercept_arr.tolist(),
            "classes": classes,
        },
    }

    if scaler_mean is not None and scaler_scale is not None:
        spec["scaler"] = {
            "type": "standard",
            "mean": [float(v) for v in scaler_mean],
            "scale": [float(v) for v in scaler_scale],
        }

    if baseline is not None:
        spec["baseline"] = [float(v) for v in baseline]

    return spec


# ---------------------------------------------------------------------------
# Framework-specific helpers
# ---------------------------------------------------------------------------

def from_sklearn_tree(
    model,
    model_id: str,
    feature_names: list[str],
    *,
    classes: Optional[list] = None,
) -> dict:
    """
    Serialize a fitted DecisionTree{Classifier,Regressor} into a CipherExplain ModelSpec dict.

    Args:
        model: Fitted ``DecisionTreeClassifier`` or ``DecisionTreeRegressor``.
        model_id: Unique model name.
        feature_names: Feature name strings matching the column order at predict time.
        classes: Class labels (e.g. ``[0, 1]``). Inferred from the model if omitted.

    Returns:
        dict conforming to the ``ModelSpec`` schema accepted by ``POST /models/register``.

    Raises:
        ValueError: Model is not a supported tree type.
    """
    try:
        from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
    except ImportError as e:
        raise ImportError("scikit-learn is required for from_sklearn_tree()") from e

    if not isinstance(model, (DecisionTreeClassifier, DecisionTreeRegressor)):
        raise ValueError(
            f"from_sklearn_tree() requires DecisionTreeClassifier or DecisionTreeRegressor, "
            f"got {type(model).__name__!r}."
        )

    from cipherexplain.core.model_spec import tree_spec_from_estimator

    ts = tree_spec_from_estimator(model)
    spec_dict = ts.model_dump()

    return {
        "model_id": model_id,
        "model_type": "decision_tree",
        "feature_names": list(feature_names),
        "spec": spec_dict,
    }


def from_sklearn_ensemble(
    model,
    model_id: str,
    feature_names: list[str],
    *,
    classes: Optional[list] = None,
) -> dict:
    """
    Serialize a fitted RandomForest or GradientBoosting estimator into a CipherExplain ModelSpec dict.

    Args:
        model: Fitted ``RandomForestClassifier``, ``RandomForestRegressor``,
               ``GradientBoostingClassifier``, or ``GradientBoostingRegressor``.
        model_id: Unique model name.
        feature_names: Feature name strings matching the column order at predict time.
        classes: Class labels (e.g. ``[0, 1]``). Inferred from the model if omitted.

    Returns:
        dict conforming to the ``ModelSpec`` schema accepted by ``POST /models/register``.

    Raises:
        ValueError: Model is not a supported ensemble type.
    """
    try:
        from sklearn.ensemble import (
            RandomForestClassifier, RandomForestRegressor,
            GradientBoostingClassifier, GradientBoostingRegressor,
        )
    except ImportError as e:
        raise ImportError("scikit-learn is required for from_sklearn_ensemble()") from e

    supported = (
        RandomForestClassifier, RandomForestRegressor,
        GradientBoostingClassifier, GradientBoostingRegressor,
    )
    if not isinstance(model, supported):
        raise ValueError(
            f"from_sklearn_ensemble() requires RandomForest{{Classifier,Regressor}} or "
            f"GradientBoosting{{Classifier,Regressor}}, got {type(model).__name__!r}."
        )

    from cipherexplain.core.model_spec import forest_spec_from_estimator

    model_type = "random_forest" if isinstance(model, (RandomForestClassifier, RandomForestRegressor)) else "gradient_boosting"

    forest_spec = forest_spec_from_estimator(model)  # full ForestSpec dict

    return {
        "model_id": model_id,
        "model_type": model_type,
        "feature_names": list(feature_names),
        "spec": forest_spec,
    }


# ---------------------------------------------------------------------------
# Framework-specific helpers
# ---------------------------------------------------------------------------

def _from_sklearn_like(model, model_id, feature_names, scaler, baseline, classes_override):
    """Handle sklearn LogisticRegression, LinearSVC, and duck-typed equivalents."""
    if not hasattr(model, "coef_"):
        raise ValueError("Model is not fitted — call model.fit() before extract_spec().")

    coef = np.asarray(model.coef_, dtype=np.float64)
    intercept = np.asarray(model.intercept_, dtype=np.float64)

    if coef.ndim == 1:
        coef = coef.reshape(1, -1)

    # Detect model_type from class name, default to logistic_regression
    cls_name = type(model).__name__
    if "SVC" in cls_name or "SVM" in cls_name:
        model_type = "linear_svc"
    else:
        model_type = "logistic_regression"

    # Classes
    if classes_override is not None:
        classes = [int(c) for c in classes_override]
    elif hasattr(model, "classes_"):
        classes = [int(c) for c in model.classes_]
    else:
        n = coef.shape[0]
        classes = list(range(n if n > 1 else 2))

    return from_weights(
        coef, intercept, model_id, feature_names,
        model_type=model_type,
        classes=classes,
        scaler_mean=list(np.asarray(scaler.mean_, dtype=np.float64)) if scaler is not None else None,
        scaler_scale=list(np.asarray(scaler.scale_, dtype=np.float64)) if scaler is not None else None,
        baseline=baseline,
    )


def _from_pytorch(model, model_id, feature_names, scaler, baseline, classes_override):
    """
    Handle PyTorch nn.Linear or nn.Sequential containing ONLY nn.Linear layers.

    CipherExplain requires a linear classifier — a model is only valid if it
    is entirely linear (no activations, no non-linear transforms). If your
    model has ReLU or other activations, use from_weights() and pass the
    effective weights of the equivalent linear model, or export to sklearn.

    Supported:
      nn.Linear(n_features, out)
      nn.Sequential(nn.Linear(a, b), nn.Linear(b, out), ...)  — composed into one

    Not supported (raises TypeError):
      nn.Sequential with any non-linear layer (ReLU, Sigmoid, BatchNorm, etc.)
    """
    import torch
    import torch.nn as nn

    linear_layer = None
    if isinstance(model, nn.Linear):
        linear_layer = model
    elif isinstance(model, nn.Sequential):
        layers = list(model.children())
        non_linear = [l for l in layers if not isinstance(l, nn.Linear)]
        if non_linear:
            raise TypeError(
                f"nn.Sequential contains non-linear layers: "
                f"{[type(l).__name__ for l in non_linear]}. "
                f"extract_spec() only supports fully linear PyTorch models. "
                f"Use from_weights() to pass the final linear layer's weights directly, "
                f"or use from_sklearn_ensemble() for tree models."
            )
        # Compose all Linear layers into one: W_eff = W_n @ ... @ W_1
        w_eff = np.eye(layers[0].in_features, dtype=np.float64)
        b_eff = np.zeros(layers[0].in_features, dtype=np.float64)
        for layer in layers:
            with torch.no_grad():
                w = layer.weight.detach().cpu().numpy().astype(np.float64)
                b = layer.bias.detach().cpu().numpy().astype(np.float64) if layer.bias is not None else np.zeros(layer.out_features, dtype=np.float64)
            b_eff = w @ b_eff + b
            w_eff = w @ w_eff

        out = layers[-1].out_features
        coef = w_eff
        bias = b_eff
        if out == 2:
            coef = coef[1:2]
            bias = bias[1:2]

        classes = [int(c) for c in classes_override] if classes_override else ([0, 1] if out <= 2 else list(range(out)))
        return from_weights(
            coef, bias, model_id, feature_names,
            model_type="logistic_regression",
            classes=classes,
            scaler_mean=list(np.asarray(scaler.mean_, dtype=np.float64)) if scaler is not None else None,
            scaler_scale=list(np.asarray(scaler.scale_, dtype=np.float64)) if scaler is not None else None,
            baseline=baseline,
        )
    else:
        raise TypeError(f"Expected nn.Linear or nn.Sequential, got {type(model).__name__}")

    # nn.Linear branch
    with torch.no_grad():
        coef = linear_layer.weight.detach().cpu().numpy().astype(np.float64)
        bias = (linear_layer.bias.detach().cpu().numpy().astype(np.float64)
                if linear_layer.bias is not None
                else np.zeros(linear_layer.out_features, dtype=np.float64))

    out = linear_layer.out_features
    if out == 2:
        coef = coef[1:2]
        bias = bias[1:2]

    classes = [int(c) for c in classes_override] if classes_override else ([0, 1] if out <= 2 else list(range(out)))
    return from_weights(
        coef, bias, model_id, feature_names,
        model_type="logistic_regression",
        classes=classes,
        scaler_mean=list(np.asarray(scaler.mean_, dtype=np.float64)) if scaler is not None else None,
        scaler_scale=list(np.asarray(scaler.scale_, dtype=np.float64)) if scaler is not None else None,
        baseline=baseline,
    )