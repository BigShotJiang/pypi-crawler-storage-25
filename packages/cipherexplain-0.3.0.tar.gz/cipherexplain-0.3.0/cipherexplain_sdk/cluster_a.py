# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
# Patent pending: PCT/IB2026/053378, PCT/IB2026/053405
# See NOTICE and LICENSE files for details.

"""Client-side verifier for the cluster-A integrity stack.

Verifies the metadata blocks attached to a CipherExplain `/explain`
response when the server runs with cluster-A flags enabled
(`CE_EDAW_ENABLED`, `CE_CRDC_ENABLED`, `CE_STACK_COMPOSITION`):

  * Composition β (paper §7) — re-derive from public composition
    inputs + check equality against published ``beta_hex`` and the
    component-specific domain-separated labels.
  * CRDC (paper §6) — re-derive ``nu = HMAC(k_T, SHA-256(canon(x)))``
    from the input vector and tenant key (when the SDK holds it)
    and check that ``leaf_hash(nu, C_phi, C_x, ts) == announced leaf``.

Out of scope for this module:
  * EDAW Bulletproofs range proof on the decrypted residual ``c``.
    Requires the CKKS secret key + OpenFHE decrypt on the client. The
    raw materials are surfaced via ``response['metadata']
    ['enc_residual_bytes_hex']`` so callers with a CKKS context can
    feed it into ``cipherexplain.core.edaw_bp_range`` separately.
  * R_vdec verifiable-decryption-equivalence proof (paper §4.5) —
    pluggable adapter, currently a flag-gated stub.
  * Server-side root inclusion (paper §6 Merkle path) — requires the
    SDK to fetch ``/audit/crdc/root`` separately and run
    ``crdc.verify_inclusion``; sketched as a follow-up.

The verifier returns a :class:`ClusterAVerificationResult` with
per-component verdicts so callers can treat each independently
(e.g. accept the response when CRDC verifies but skip EDAW until they
wire decryption)."""
from __future__ import annotations

import hashlib
import hmac
import struct
from dataclasses import dataclass, field
from typing import Iterable, Optional

import numpy as np


# Domain tags must match the server-side derivations in
# ``cipherexplain.core.{crdc, stack_composition}``. Keep these strings
# in lockstep — any tweak on the server side requires a matching tweak
# here and a fresh SDK release.
_CRDC_DOMAIN_TAG = b"crdc/v1"
_STACK_DOMAIN_TAG = b"stack/v1"
_STACK_LABEL = b"Stack"
DEFAULT_CANON_DIGITS = 12


# ---------------------------------------------------------------------------
# Re-implementations (shared with core.crdc / core.stack_composition)
# ---------------------------------------------------------------------------
#
# The SDK ships standalone on PyPI without bundling cipherexplain.core,
# so we duplicate the canonicalisation + leaf-hash + β derivation here.
# Test parity against the server's implementations is enforced via a
# round-trip test in test_cluster_a.py.

def _canonicalize(x: np.ndarray, ndigits: int = DEFAULT_CANON_DIGITS) -> bytes:
    arr = np.asarray(x, dtype=np.float64).ravel()
    rounded = np.round(arr, decimals=ndigits) + 0.0  # neg-zero hygiene
    buf = bytearray()
    buf.extend(_CRDC_DOMAIN_TAG)
    buf.extend(b"|canon|")
    buf.extend(struct.pack(">I", len(rounded)))
    for v in rounded.tolist():
        buf.extend(struct.pack(">d", float(v)))
    return bytes(buf)


def _nullifier(tenant_key: bytes, x: np.ndarray) -> bytes:
    if not isinstance(tenant_key, (bytes, bytearray)) or len(tenant_key) < 16:
        raise ValueError("tenant_key must be >= 16 bytes")
    canon = _canonicalize(x)
    inner = hashlib.sha256(canon).digest()
    return hmac.new(bytes(tenant_key), inner, hashlib.sha256).digest()


def _leaf_hash(nu: bytes, c_phi: bytes, c_x: bytes, ts_ms: int) -> bytes:
    h = hashlib.sha256()
    h.update(_CRDC_DOMAIN_TAG)
    h.update(b"|leaf|")
    h.update(bytes(nu))
    h.update(struct.pack(">I", len(c_phi)))
    h.update(bytes(c_phi))
    h.update(struct.pack(">I", len(c_x)))
    h.update(bytes(c_x))
    h.update(struct.pack(">Q", int(ts_ms)))
    return h.digest()


def _commit_value_bytes(value, *, domain: bytes) -> bytes:
    """Mirror of ``core.crdc_store.commit_value_bytes``. Compact 32-byte
    SHA-256 commitment with domain separation. Used here to recompute
    ``C_phi`` and ``C_x`` from the response's plaintext shap_values +
    canonical input."""
    h = hashlib.sha256()
    h.update(b"crdc-store/v1|")
    h.update(domain)
    h.update(b"|")
    if isinstance(value, (bytes, bytearray, memoryview)):
        h.update(bytes(value))
    elif isinstance(value, str):
        h.update(value.encode("utf-8"))
    elif isinstance(value, np.ndarray):
        h.update(value.tobytes(order="C"))
    elif isinstance(value, list):
        for v in value:
            h.update(repr(v).encode("utf-8"))
            h.update(b"|")
    else:
        h.update(repr(value).encode("utf-8"))
    return h.digest()


def _derive_beta(
    model_commitment: bytes,
    input_ciphertext: bytes,
    tenant_root: bytes,
    timestamp: int,
) -> bytes:
    h = hashlib.sha3_256()
    h.update(_STACK_DOMAIN_TAG)
    h.update(b"|beta|")
    h.update(struct.pack(">I", len(model_commitment)))
    h.update(bytes(model_commitment))
    h.update(struct.pack(">I", len(input_ciphertext)))
    h.update(bytes(input_ciphertext))
    h.update(struct.pack(">I", len(tenant_root)))
    h.update(bytes(tenant_root))
    h.update(struct.pack(">Q", int(timestamp)))
    h.update(b"|label|")
    h.update(_STACK_LABEL)
    return h.digest()


def _component_label(beta: bytes, sub_label: bytes) -> bytes:
    h = hashlib.sha3_256()
    h.update(_STACK_DOMAIN_TAG)
    h.update(b"|component|")
    h.update(beta)
    h.update(b"|")
    h.update(sub_label)
    return h.digest()


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ComponentVerdict:
    """Outcome of one cluster-A component check."""

    name: str
    verified: bool
    reason: str = ""
    detail: dict = field(default_factory=dict)


@dataclass(frozen=True)
class ClusterAVerificationResult:
    """Aggregate verdict for the cluster-A response.

    ``verified`` is True iff every component the SDK could check
    passed. Components the SDK skipped (no input known, no tenant key,
    feature not enabled in response) are recorded under ``skipped``
    and do NOT count against ``verified``."""

    verified: bool
    components: list[ComponentVerdict] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)

    @property
    def issues(self) -> list[str]:
        return [
            f"{c.name}: {c.reason}"
            for c in self.components if not c.verified
        ]


# ---------------------------------------------------------------------------
# Per-component verifiers
# ---------------------------------------------------------------------------

def _verify_composition(meta: dict, ts_ms: int, ct_digest_hex: str,
                        cache_key: str, tenant_root_hex: str) -> ComponentVerdict:
    comp = meta.get("composition")
    if not isinstance(comp, dict) or not comp.get("enabled"):
        return ComponentVerdict(
            name="composition", verified=False,
            reason="composition block absent",
        )
    try:
        model_commit = (cache_key or "").encode("utf-8")[:64]
        input_ct = bytes.fromhex(ct_digest_hex) if ct_digest_hex else b""
        tenant_root = (
            bytes.fromhex(tenant_root_hex) if tenant_root_hex else b""
        )
        beta = _derive_beta(model_commit, input_ct, tenant_root, ts_ms)
        recomputed = beta.hex()
        published = comp.get("beta_hex", "")
        if recomputed != published:
            return ComponentVerdict(
                name="composition", verified=False,
                reason="β re-derivation does not match published beta_hex",
                detail={"published": published, "recomputed": recomputed},
            )
        # Per-component labels
        for sub_label, key in (
            (b"EDAW", "edaw_label_hex"),
            (b"FCRAS-B", "fcras_b_label_hex"),
            (b"CRDC", "crdc_label_hex"),
        ):
            expected = _component_label(beta, sub_label).hex()
            if comp.get(key, "") != expected:
                return ComponentVerdict(
                    name="composition", verified=False,
                    reason=f"sub-label {sub_label!r} mismatch",
                    detail={"key": key},
                )
        return ComponentVerdict(
            name="composition", verified=True,
            detail={"beta_hex": recomputed},
        )
    except Exception as exc:  # noqa: BLE001
        return ComponentVerdict(
            name="composition", verified=False,
            reason=f"exception: {exc}",
        )


def _verify_crdc_leaf(meta: dict, response: dict,
                      input_x: Optional[np.ndarray],
                      tenant_key: Optional[bytes]) -> ComponentVerdict:
    crdc_meta = meta.get("crdc")
    if not isinstance(crdc_meta, dict) or not crdc_meta.get("enabled"):
        return ComponentVerdict(
            name="crdc_leaf", verified=False,
            reason="crdc block absent",
        )
    try:
        announced_nu_hex = crdc_meta.get("nullifier_hex", "")
        announced_leaf_hex = crdc_meta.get("leaf_hex", "")
        ts_ms = int(crdc_meta.get("timestamp_ms", 0))

        # Re-derive C_phi and C_x from the public response material.
        c_phi = _commit_value_bytes(
            response.get("shap_values", []), domain=b"shap_values",
        )
        if input_x is not None:
            canonical_x = np.asarray(input_x, dtype=np.float64).ravel()
            c_x = _commit_value_bytes(canonical_x, domain=b"input")
        else:
            c_x = None

        # Re-derive the announced leaf hash from announced nu + commitments.
        nu_announced = bytes.fromhex(announced_nu_hex)
        if c_x is not None:
            leaf_recomputed = _leaf_hash(nu_announced, c_phi, c_x, ts_ms)
            if leaf_recomputed.hex() != announced_leaf_hex:
                return ComponentVerdict(
                    name="crdc_leaf", verified=False,
                    reason="leaf hash mismatch",
                    detail={
                        "announced": announced_leaf_hex,
                        "recomputed": leaf_recomputed.hex(),
                    },
                )

        # Re-derive nu from input + tenant key when the SDK holds them.
        if input_x is not None and tenant_key is not None:
            nu_recomputed = _nullifier(tenant_key, np.asarray(input_x))
            if nu_recomputed.hex() != announced_nu_hex:
                return ComponentVerdict(
                    name="crdc_leaf", verified=False,
                    reason="nullifier mismatch (tenant key or canonical x)",
                    detail={
                        "announced": announced_nu_hex,
                        "recomputed": nu_recomputed.hex(),
                    },
                )

        return ComponentVerdict(
            name="crdc_leaf", verified=True,
            detail={"nu_hex": announced_nu_hex},
        )
    except Exception as exc:  # noqa: BLE001
        return ComponentVerdict(
            name="crdc_leaf", verified=False,
            reason=f"exception: {exc}",
        )


# ---------------------------------------------------------------------------
# Top-level entry point
# ---------------------------------------------------------------------------

def verify_cluster_a_response(
    response: dict,
    *,
    input_x: Optional[np.ndarray] = None,
    tenant_key: Optional[bytes] = None,
) -> ClusterAVerificationResult:
    """Check the cluster-A metadata blocks attached to a /explain
    response.

    Parameters
    ----------
    response
        The /explain response JSON dict (decoded already).
    input_x
        Optional client-side copy of the input vector. Required to
        verify ``C_x`` and re-derive ``nu`` when ``tenant_key`` is
        also supplied. When absent, those checks are skipped.
    tenant_key
        Optional 32-byte HMAC key for the caller's tenant. When the
        SDK holds it (HSM, KMS, or shared-secret bootstrap), the
        verifier confirms ``nu == HMAC(k_T, SHA-256(canon(x)))``.
        Without it, the verifier only checks the leaf-hash
        re-derivation against the announced nu.

    Returns
    -------
    :class:`ClusterAVerificationResult`
        Per-component verdicts plus an aggregate ``verified`` flag.
    """
    components: list[ComponentVerdict] = []
    skipped: list[str] = []

    meta = response.get("metadata") if isinstance(response, dict) else None
    if not isinstance(meta, dict):
        return ClusterAVerificationResult(verified=False, components=[
            ComponentVerdict(
                name="response_shape", verified=False,
                reason="response.metadata absent or not a dict",
            ),
        ])

    # Composition β
    if isinstance(meta.get("composition"), dict):
        ts_ms = int(meta.get("crdc", {}).get("timestamp_ms", 0)) \
            if isinstance(meta.get("crdc"), dict) else 0
        ct_digest_hex = response.get("ciphertext_digest_hex", "") or ""
        cache_key = response.get("cache_key", "") or ""
        tenant_root_hex = (
            meta.get("crdc", {}).get("tenant_root_hex", "")
            if isinstance(meta.get("crdc"), dict) else ""
        )
        components.append(_verify_composition(
            meta, ts_ms, ct_digest_hex, cache_key, tenant_root_hex,
        ))
    else:
        skipped.append("composition")

    # CRDC leaf re-derivation
    if isinstance(meta.get("crdc"), dict):
        components.append(_verify_crdc_leaf(meta, response, input_x, tenant_key))
    else:
        skipped.append("crdc_leaf")

    # EDAW / R_vdec — flag presence only; full client-side check
    # requires a CKKS secret key + OpenFHE Decrypt, out of scope.
    if "enc_residual_bytes_hex" in meta:
        skipped.append("edaw_bp_range")
    if response.get("vdec_proof"):
        skipped.append("r_vdec")

    verified = bool(components) and all(c.verified for c in components)
    return ClusterAVerificationResult(
        verified=verified,
        components=components,
        skipped=skipped,
    )


__all__ = [
    "ClusterAVerificationResult",
    "ComponentVerdict",
    "verify_cluster_a_response",
]
