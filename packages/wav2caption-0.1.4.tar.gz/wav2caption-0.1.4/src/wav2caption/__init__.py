"""wav2caption — audio → instrument-aware caption for AI music generation.

Public API:
    analyze(audio_path, *, section_seconds=10) -> AnalysisResult
    build_caption(result) -> str
    AnalysisResult, Section
"""

from wav2caption.analyzer import (
    DEFAULT_CAPTION_TAGS,
    AnalysisResult,
    CaptionTag,
    Section,
    analyze,
    build_caption,
)
from wav2caption.constants import INSTRUMENTS, ROLE_MAP
from wav2caption.models import (
    EFFNET_SHA256,
    INSTRUMENT_SHA256,
    ModelPaths,
    resolve_models,
    verify_digests,
)

__all__ = [
    "DEFAULT_CAPTION_TAGS",
    "EFFNET_SHA256",
    "INSTRUMENTS",
    "INSTRUMENT_SHA256",
    "ROLE_MAP",
    "AnalysisResult",
    "CaptionTag",
    "ModelPaths",
    "Section",
    "analyze",
    "build_caption",
    "resolve_models",
    "verify_digests",
]

__version__ = "0.1.2"
