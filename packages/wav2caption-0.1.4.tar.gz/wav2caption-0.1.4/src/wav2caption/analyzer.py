"""Core analysis pipeline: audio → per-section instrument roles → caption.

Heavy dependencies (``essentia``, ``numpy``) are imported lazily so that
utility sub-modules (``constants``, ``models``) stay importable in minimal
environments, e.g. CI without TensorFlow.
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from wav2caption.constants import INSTRUMENTS, get_role
from wav2caption.models import ModelPaths, resolve_models

if TYPE_CHECKING:
    import numpy as np
    from numpy.typing import NDArray

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Section:
    """A fixed-length window of audio with its aggregate features."""

    start: float
    end: float
    loudness: float
    centroid_hz: float
    key: str
    scale: str
    roles: dict[str, tuple[str, float]]
    top_instruments: list[tuple[str, float]]
    features: list[str]


@dataclass
class AnalysisResult:
    """Everything the analyzer produces about one audio file."""

    path: Path
    duration_sec: float
    bpm: float
    key: str
    scale: str
    key_confidence: float
    danceability: float
    detected_instruments: list[tuple[str, float]] = field(default_factory=list)
    role_scores: dict[str, float] = field(default_factory=dict)
    sections: list[Section] = field(default_factory=list)


def _import_essentia() -> Any:
    try:
        from essentia import standard as es
    except ImportError as err:
        raise ImportError(
            "essentia-tensorflow is required for audio analysis.\n"
            'Install with: pip install "wav2caption[essentia]"\n'
            "Note: Essentia is licensed under AGPLv3 (or commercial)."
        ) from err
    return es


def _detect_section_features(
    top: list[tuple[str, float]],
    loudness: float,
    centroid_hz: float,
    pitch_range_hz: float,
) -> list[str]:
    """Heuristic human-readable tags from per-section aggregates."""
    out: list[str] = []
    if centroid_hz > 2000:
        out.append("bright / bell-like highs")
    if centroid_hz < 800:
        out.append("low-end focused")
    if loudness < 500:
        out.append("quiet (breakdown/interlude)")
    if loudness > 1500:
        out.append("peak energy (chorus/climax)")

    top_names_high = {n for n, v in top if v > 0.15}
    top_names_mid = {n for n, v in top if v > 0.08}
    top_names_low = {n for n, v in top if v > 0.05}

    if {"bell", "percussion"} & top_names_low:
        out.append("metallic percussion accents")
    if {"violin", "strings", "viola", "cello"} & top_names_high:
        out.append("string harmonies")
    if {"brass", "trumpet", "saxophone", "trombone"} & top_names_mid:
        out.append("brass accents")
    if pitch_range_hz > 800 and ({"synthesizer", "piano"} & top_names_high):
        out.append("staccato stabs")
    return out


_MIN_PITCH_FRAMES = 8
"""Minimum number of high-confidence frames required for a pitch-range estimate."""


def _compute_pitch_range(es: Any, segment_audio: NDArray[np.float32]) -> float:
    """Return the 10-90 percentile pitch span in Hz (0.0 if too little data).

    ``hopSize=1024`` is a middle ground: ~43 Hz frame rate is enough for the
    "staccato stabs" heuristic, ~2x faster than 512-sample hop, and still
    dense enough that short windows collect enough high-confidence frames.
    Sections with fewer than ``_MIN_PITCH_FRAMES`` usable frames fall back
    to 0.0 so the heuristic never runs on noisy estimates.
    """
    import numpy as np

    pitches: list[float] = []
    frame_gen = es.FrameGenerator(segment_audio, frameSize=2048, hopSize=1024)
    windowing = es.Windowing(type="hann")
    spectrum = es.Spectrum()
    yin = es.PitchYinFFT()
    for frame in frame_gen:
        p, pc = yin(spectrum(windowing(frame)))
        if pc > 0.5 and 50.0 < p < 4000.0:
            pitches.append(float(p))
    if len(pitches) < _MIN_PITCH_FRAMES:
        return 0.0
    return float(np.percentile(pitches, 90) - np.percentile(pitches, 10))


def _load_audio(es: Any, audio_path: Path) -> tuple[NDArray[np.float32], NDArray[np.float32], float]:
    """Load the file once at 44.1 kHz and resample in-memory for the NN.

    Decoding a 5-minute file twice roughly doubled I/O and CPU in early
    profiling — a single decode plus a 44.1→16 kHz ``Resample`` pass is
    measurably faster and gives bit-identical embeddings in practice.

    Essentia raises ``RuntimeError`` on corrupt / unsupported codecs; we
    wrap it in ``ValueError`` so the CLI can surface a friendly error
    without the user needing to know Essentia's exception hierarchy.
    """
    try:
        audio44 = es.MonoLoader(filename=str(audio_path), sampleRate=44100)()
    except RuntimeError as err:
        raise ValueError(f"Could not decode audio {audio_path}: {err}") from err
    duration = float(len(audio44)) / 44100.0
    if duration < 1.0:
        raise ValueError(f"Audio too short for analysis ({duration:.2f}s < 1.0s)")
    audio16 = es.Resample(
        inputSampleRate=44100, outputSampleRate=16000, quality=4
    )(audio44)
    return audio44, audio16, duration


def _global_features(
    es: Any, audio44: NDArray[np.float32]
) -> tuple[float, str, str, float, float]:
    """Return (bpm, key, scale, key_confidence, danceability) for the whole file."""
    bpm, _beats, _beats_conf, _, _ = es.RhythmExtractor2013(method="multifeature")(audio44)
    key, scale, key_confidence = es.KeyExtractor()(audio44)
    danceability, _ = es.Danceability()(audio44)
    return float(bpm), key, scale, float(key_confidence), float(danceability)


def _run_instrument_head(
    es: Any, audio16: NDArray[np.float32], paths: ModelPaths, duration: float
) -> tuple[NDArray[np.float32], float]:
    """Run the two-stage (embedding + head) instrument model. Returns (preds, fps)."""
    emb_model = es.TensorflowPredictEffnetDiscogs(
        graphFilename=str(paths.effnet), output="PartitionedCall:1"
    )
    embeddings = emb_model(audio16)
    inst_model = es.TensorflowPredict2D(graphFilename=str(paths.instrument))
    preds = inst_model(embeddings)
    fps = preds.shape[0] / duration
    return preds, fps


def _aggregate_global(
    preds: NDArray[np.float32], min_instrument_score: float
) -> tuple[list[tuple[str, float]], dict[str, float]]:
    """Aggregate frame-level predictions into (detected_instruments, role_scores)."""
    import numpy as np

    avg = np.mean(preds, axis=0)
    detected: list[tuple[str, float]] = [
        (INSTRUMENTS[i], float(avg[i]))
        for i in np.argsort(avg)[::-1]
        if avg[i] > min_instrument_score
    ]
    role_scores: dict[str, float] = {}
    for name, score in detected:
        r = get_role(name)
        role_scores[r] = role_scores.get(r, 0.0) + score
    return detected, role_scores


def _build_section(
    es: Any,
    audio44: NDArray[np.float32],
    preds: NDArray[np.float32],
    fps: float,
    start: float,
    end: float,
    min_section_score: float,
    global_key: str,
    global_scale: str,
) -> Section | None:
    """Analyze a single time window. Returns ``None`` if the window is unusable.

    Section key/scale reuses the globally-computed value rather than running
    the full ``KeyExtractor`` spectral pipeline for every window; most pop /
    rock tracks don't modulate, and callers that need local-key tracking
    can slice the raw audio and call the analyzer per region themselves.
    """
    import numpy as np

    seg44 = audio44[int(start * 44100) : int(end * 44100)]
    if len(seg44) < 44100:  # <1 s tail — skip
        return None

    f_start = int(start * fps)
    f_end = min(int(end * fps), preds.shape[0])
    if f_start >= preds.shape[0]:
        return None

    seg_pred = np.mean(preds[f_start:f_end], axis=0)
    loudness = float(es.Loudness()(seg44))
    centroid = float(es.SpectralCentroidTime()(seg44))

    top: list[tuple[str, float]] = [
        (INSTRUMENTS[i], float(seg_pred[i]))
        for i in np.argsort(seg_pred)[::-1]
        if seg_pred[i] > min_section_score
    ]

    roles: dict[str, tuple[str, float]] = {}
    for name, score in top:
        r = get_role(name)
        cur = roles.get(r)
        if cur is None or score > cur[1]:
            roles[r] = (name, score)

    pitch_range = _compute_pitch_range(es, seg44)
    features = _detect_section_features(top, loudness, centroid, pitch_range)

    return Section(
        start=start,
        end=end,
        loudness=loudness,
        centroid_hz=centroid,
        key=global_key,
        scale=global_scale,
        roles=roles,
        top_instruments=top,
        features=features,
    )


def _process_sections(
    es: Any,
    audio44: NDArray[np.float32],
    preds: NDArray[np.float32],
    fps: float,
    duration: float,
    section_seconds: float,
    min_section_score: float,
    global_key: str,
    global_scale: str,
) -> list[Section]:
    """Slice the audio into fixed windows and analyze each one."""
    sections: list[Section] = []
    n_windows = max(1, math.ceil(duration / section_seconds))
    for w in range(n_windows):
        start = w * section_seconds
        if start >= duration:
            break
        end = min(start + section_seconds, duration)
        sec = _build_section(
            es, audio44, preds, fps, start, end, min_section_score,
            global_key, global_scale,
        )
        if sec is not None:
            sections.append(sec)
    return sections


def analyze(
    audio_path: str | Path,
    *,
    section_seconds: float = 10.0,
    models_dir: str | Path | None = None,
    min_instrument_score: float = 0.04,
    min_section_score: float = 0.05,
    model_paths: ModelPaths | None = None,
) -> AnalysisResult:
    """Analyze an audio file and return a structured :class:`AnalysisResult`.

    Parameters
    ----------
    audio_path:
        Path to a WAV/MP3/FLAC file readable by Essentia's ``MonoLoader``.
    section_seconds:
        Window length for per-section analysis (default 10 s).
    models_dir:
        Directory containing the two ``.pb`` files. Falls back to
        ``WAV2CAPTION_MODELS_DIR`` or ``~/.cache/wav2caption/models``.
    min_instrument_score:
        Probability threshold for the global instrument summary.
    min_section_score:
        Probability threshold for per-section top instruments.
    model_paths:
        Explicit paths (bypasses ``models_dir`` resolution). Useful for tests.
    """
    audio_path = Path(audio_path).expanduser().resolve()
    if not audio_path.is_file():
        raise FileNotFoundError(f"Audio file not found: {audio_path}")
    if section_seconds <= 0:
        raise ValueError("section_seconds must be positive")

    paths = model_paths or resolve_models(models_dir)
    paths.validate()

    es = _import_essentia()
    audio44, audio16, duration = _load_audio(es, audio_path)
    bpm, key, scale, key_confidence, danceability = _global_features(es, audio44)
    preds, fps = _run_instrument_head(es, audio16, paths, duration)
    detected, role_scores = _aggregate_global(preds, min_instrument_score)
    sections = _process_sections(
        es, audio44, preds, fps, duration, section_seconds, min_section_score,
        key, scale,
    )

    return AnalysisResult(
        path=audio_path,
        duration_sec=duration,
        bpm=bpm,
        key=key,
        scale=scale,
        key_confidence=key_confidence,
        danceability=danceability,
        detected_instruments=detected,
        role_scores=role_scores,
        sections=sections,
    )


_MatchMode = Literal["exact", "substr"]


@dataclass(frozen=True)
class CaptionTag:
    """Declarative rule: emit ``phrase`` when any of ``labels`` appears in the
    top-``top_k`` detected instruments.

    ``match`` = ``"exact"`` compares the full instrument label; ``"substr"``
    matches if any listed string is a substring of the instrument label (used
    for the ``acoustic*`` / ``electric*`` families).
    """

    phrase: str
    top_k: int
    labels: frozenset[str]
    match: _MatchMode = "exact"


#: Default tag rules used by :func:`build_caption`. Ordered — output follows
#: this order verbatim. Override by passing ``rules=...`` to customise.
DEFAULT_CAPTION_TAGS: tuple[CaptionTag, ...] = (
    CaptionTag("live drums", 3, frozenset({"drums"}), "substr"),
    CaptionTag("electric guitar", 5, frozenset({"electric"}), "substr"),
    CaptionTag("piano", 5, frozenset({"piano"}), "substr"),
    CaptionTag("bass", 5, frozenset({"bass"}), "substr"),
    CaptionTag("string section", 8, frozenset({"violin", "strings", "viola", "cello"})),
    CaptionTag("brass section", 10, frozenset({"brass", "trumpet", "saxophone", "trombone"})),
    CaptionTag("synth pads", 5, frozenset({"synthesizer", "pad"})),
    CaptionTag("bell accents", 10, frozenset({"bell"})),
    CaptionTag("acoustic guitar", 8, frozenset({"acoustic"}), "substr"),
)


def _rule_fires(rule: CaptionTag, top_names: list[str]) -> bool:
    window = top_names[: rule.top_k]
    if rule.match == "substr":
        return any(any(needle in name for needle in rule.labels) for name in window)
    return bool(rule.labels & set(window))


def build_caption(
    result: AnalysisResult,
    *,
    rules: tuple[CaptionTag, ...] = DEFAULT_CAPTION_TAGS,
) -> str:
    """Compose a compact English caption suitable for ACE-Step / Suno prompts.

    The instrument-phrase mapping is driven by ``rules`` (see
    :data:`DEFAULT_CAPTION_TAGS`) so downstream projects can inject their own
    vocabulary without forking the analyzer.
    """
    top_names = [n for n, _ in result.detected_instruments]
    style_words = [rule.phrase for rule in rules if _rule_fires(rule, top_names)]

    loud_values = [s.loudness for s in result.sections]
    dynamics: list[str] = []
    # Essentia's Loudness() returns a (non-normalised) energy-like number.
    # We declare a build-up when the peak section is >= 3x the quietest one
    # *in relative terms* and the absolute span is also large enough that a
    # handful of near-silent samples can't push us over the threshold on
    # their own.
    if loud_values:
        lo = max(min(loud_values), 1.0)
        hi = max(loud_values)
        if hi / lo > 3.0 and (hi - lo) > 300.0:
            dynamics.append("dynamic build-up")
    if any("quiet" in f for s in result.sections for f in s.features):
        dynamics.append("breakdown section")

    # Compose as a list-of-tokens and join with a single separator so that
    # zero-detection tracks don't produce a leading ", C major, …".
    #
    # Note: time signature is intentionally *not* emitted. Hard-coding
    # "4/4" would lie on waltz / 3-4 / 6-8 tracks; honest detection would
    # need a BeatTracker + downbeat inference pass that the current
    # pipeline doesn't run. Callers who need it can append their own
    # estimate to the returned string.
    parts: list[str] = list(style_words)
    parts.append(f"{result.key} {result.scale}")
    parts.append(f"{round(result.bpm)} BPM")
    parts.extend(dynamics)
    return ", ".join(parts)
