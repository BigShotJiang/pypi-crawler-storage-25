from phcl.syntax import hcl
from phcl.terraform import TerraformPHCL as PHCL
from phcl.terraform import Data, Output, Provider, Resource, Variable


class DatabricksHost(Variable):
    type = "string"


class DatabricksToken(Variable):
    type = "string"
    sensitive = True


class TeamName(Variable):
    type = "string"
    default = "data-platform"


class Databricks(Provider["databricks"]):
    host = DatabricksHost._
    token = DatabricksToken._


class WorkspaceGroup(Data["databricks_group"]):
    display_name = TeamName._


class WorkspaceClusterPolicy(Resource["databricks_cluster_policy"]):
    name = "shared-jobs"
    definition = hcl(
        """
jsonencode({
  "dbus_per_hour" = {
    "type"  = "range"
    "maxValue" = 10
  }
})
""".strip()
    )


class TeamEntitlements(Resource["databricks_group_role"]):
    group_id = WorkspaceGroup._.id
    role = "users"


class GroupId(Output):
    value = WorkspaceGroup._.id
