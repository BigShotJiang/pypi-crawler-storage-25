"""
QuestraAuthentication - Simplified interface for Questra API authentication
"""

import os
from pathlib import Path

from .authentication import (
    OAuth2Authentication,
    OAuth2ClientAssertionCredential,
    OAuth2Credential,
    OAuth2InteractiveUserCredential,
    OAuth2ServiceCredential,
    OidcConfig,
    OidcDiscoveryClient,
)

_DEFAULT_ASSERTION_PATHS: list[str] = [
    "/var/run/secrets/kubernetes.io/serviceaccount/token",  # Kubernetes SA token
]


class QuestraAuthentication:
    """
    Main client for Questra API access with automatic OAuth2 authentication.

    Credential resolution uses a 3-tier priority model — higher tiers win,
    conflicts within the same tier raise a ``ValueError``:

    **Tier 1 — explicit constructor parameters (highest priority):**
    At most one of the following may be specified:

    - ``client_assertion_path``: JWT token file path
    - ``username`` + ``password``: Service Account credentials
    - ``interactive=True``: Device Code Flow

    **Tier 2 — environment variables:**
    At most one pair may be set:

    - ``QUESTRA_CLIENT_ASSERTION_PATH``: JWT token file path
    - ``QUESTRA_USERNAME`` + ``QUESTRA_PASSWORD``: Service Account credentials

    **Tier 3 — auto-detection (opt-in, lowest priority):**
    Only active when ``use_default_assertion=True`` or
    ``QUESTRA_USE_DEFAULT_ASSERTION=true``:

    - Kubernetes Service Account token at well-known default paths

    The access token is automatically renewed when it expires.
    """

    def __init__(
        self,
        url: str | list[str] | None = None,
        client_id: str = "Questra",
        username: str | None = None,
        password: str | None = None,
        interactive: bool = False,
        scope: str | None = None,
        oidc_discovery_paths: list[str] | None = None,
        client_assertion_path: str | Path | None = None,
        use_default_assertion: bool = False,
    ):
        """
        Initialize the QuestraAuthentication.

        Args:
            url: Base URL of the Identity Provider or List of URLs
            client_id: OAuth2 Client ID (default: "Questra")
            username: Username for Service Account authentication
            password: Password for Service Account authentication
            interactive: True for interactive Device Code Flow,
                False for Service Account
            scope: Optional OAuth2 Scopes
            oidc_discovery_paths: Optional List of discovery paths
                (e.g. ['/application/o/techstack', '/application/o/questra'])
            client_assertion_path: Explicit path to a JWT client assertion token file
                (RFC 7521 / RFC 7523). Tier 1: takes priority when provided.
            use_default_assertion: Enable Kubernetes Service Account token
                auto-detection (Tier 3 fallback). When ``True``, well-known SA token
                paths are probed if no Tier 1 or Tier 2 credentials are found. Also
                enabled via ``QUESTRA_USE_DEFAULT_ASSERTION=true``. Defaults to
                ``False`` to avoid accidental use of unpermissioned SA tokens.

        Environment Variables:
            QUESTRA_AUTH_URL: Fallback for ``url`` if not passed explicitly.
            QUESTRA_USERNAME: Tier 2 fallback for ``username``.
            QUESTRA_PASSWORD: Tier 2 fallback for ``password``.
            QUESTRA_CLIENT_ASSERTION_PATH: Tier 2 fallback assertion file path.
            QUESTRA_USE_DEFAULT_ASSERTION: Set to ``true`` / ``1`` / ``yes`` to enable
                Kubernetes SA token auto-detection (equivalent to
                ``use_default_assertion=True``).

        Raises:
            ValueError: If conflicting credentials are provided within the same tier,
                if an explicit credential file path does not exist, or if no
                credentials can be resolved from any tier.

        Example:
            Service Account:

            ```python
            client = QuestraAuthentication(
                url="https://authentik.example.com",
                username="ServiceUser",
                password="secret_password",
                oidc_discovery_paths=[
                    "/application/o/techstack",
                    "/application/o/questra",
                ],
            )
            ```

        Example:
            Interactive:

            ```python
            client = QuestraAuthentication(
                url="https://authentik.example.com",
                interactive=True,
                oidc_discovery_paths=[
                    "/application/o/techstack",
                    "/application/o/questra",
                ],
            )
            ```

        Example:
            Kubernetes Service Account (opt-in):

            ```python
            client = QuestraAuthentication(
                url="https://authentik.example.com",
                use_default_assertion=True,
            )
            ```
        """
        _url = url if url is not None else os.getenv("QUESTRA_AUTH_URL")
        if _url is None:
            raise ValueError("url is required. Pass url= or set QUESTRA_AUTH_URL.")
        self.url = _url
        self.client_id = client_id
        # Store raw params for tier-1 credential resolution (before env var merge)
        self._username_param = username
        self._password_param = password
        # Merged values for attribute access (backward compatible)
        self.username = username or os.getenv("QUESTRA_USERNAME")
        self.password = password or os.getenv("QUESTRA_PASSWORD")
        self.interactive = interactive
        self.scope = scope or "offline_access"
        self.oidc_discovery_paths = oidc_discovery_paths or ["/application/o/questra"]
        self.client_assertion_path = client_assertion_path
        # use_default_assertion: opt-in via param or QUESTRA_USE_DEFAULT_ASSERTION env var
        _use_default_env = os.getenv("QUESTRA_USE_DEFAULT_ASSERTION", "").lower() in (
            "true",
            "1",
            "yes",
        )
        self.use_default_assertion = use_default_assertion or _use_default_env

        self._oauth_client: OAuth2Authentication | None = None
        self._oidc_config: OidcConfig | None = None

        # Initialize OIDC Discovery and OAuth Client
        self._initialize()

    @staticmethod
    def _resolve_assertion_path(path: str | Path | None) -> Path | None:
        """Resolve an explicit or env-var client assertion path (Tier 1/2 only).

        Checks Tier 1 (explicit ``path`` argument) then Tier 2
        (``QUESTRA_CLIENT_ASSERTION_PATH`` env var). Does **not** probe
        auto-detect default locations — use ``use_default_assertion=True`` for that.

        Args:
            path: Explicit token file path, or ``None`` to check the env var.

        Returns:
            Path | None: Resolved path, or ``None`` if neither is configured.

        Raises:
            ValueError: If an explicit path or env-var path was provided but the
                file does not exist.
        """
        if path is not None:
            p = Path(path)
            if not p.exists():
                raise ValueError(f"Client assertion token file not found: '{path}'")
            return p
        env_path = os.getenv("QUESTRA_CLIENT_ASSERTION_PATH")
        if env_path is not None:
            p = Path(env_path)
            if not p.exists():
                raise ValueError(
                    f"Client assertion token file from QUESTRA_CLIENT_ASSERTION_PATH "
                    f"not found: '{env_path}'"
                )
            return p
        return None

    @staticmethod
    def _resolve_credentials(
        username_param: str | None,
        password_param: str | None,
        client_assertion_path_param: str | Path | None,
        interactive: bool,
        use_default_assertion: bool,
    ) -> OAuth2Credential:
        """Resolve OAuth2 credentials using a 3-tier priority model.

        **Tier 1** (explicit constructor params) wins over **Tier 2** (env vars)
        wins over **Tier 3** (auto-detect, opt-in). At most one credential type
        may be configured per tier; mixing types within a tier raises ``ValueError``.

        Args:
            username_param: Raw ``username`` constructor argument (before env var merge).
            password_param: Raw ``password`` constructor argument (before env var merge).
            client_assertion_path_param: Raw ``client_assertion_path`` constructor arg.
            interactive: Value of the ``interactive`` constructor argument.
            use_default_assertion: Whether Tier 3 K8s SA token auto-detect is enabled.

        Returns:
            OAuth2Credential: Resolved credential strategy.

        Raises:
            ValueError: If conflicting credentials are found within a tier, a specified
                file does not exist, or no credentials are available from any tier.
        """
        # --- Tier 1: explicit constructor params ---
        has_assertion_param = client_assertion_path_param is not None
        has_upw_param = bool(username_param) and bool(password_param)
        tier1_count = sum([has_assertion_param, has_upw_param, interactive])
        if tier1_count > 1:
            kinds = []
            if has_upw_param:
                kinds.append("username/password")
            if has_assertion_param:
                kinds.append("client_assertion_path")
            if interactive:
                kinds.append("interactive=True")
            raise ValueError(
                f"Conflicting credentials in parameters: {' and '.join(kinds)}. "
                "Specify only one of: username/password, client_assertion_path, "
                "or interactive=True."
            )

        if client_assertion_path_param is not None:
            p = Path(client_assertion_path_param)
            if not p.exists():
                raise ValueError(
                    f"Client assertion token file not found: '{client_assertion_path_param}'"
                )
            return OAuth2ClientAssertionCredential(assertion_path=p)

        if username_param and password_param:
            return OAuth2ServiceCredential(
                username=username_param, password=password_param
            )

        if interactive:
            return OAuth2InteractiveUserCredential()

        # --- Tier 2: environment variables ---
        env_assertion = os.getenv("QUESTRA_CLIENT_ASSERTION_PATH")
        env_username = os.getenv("QUESTRA_USERNAME")
        env_password = os.getenv("QUESTRA_PASSWORD")

        has_env_assertion = env_assertion is not None
        has_env_upw = bool(env_username) and bool(env_password)

        if has_env_assertion and has_env_upw:
            raise ValueError(
                "Conflicting credentials in environment variables: "
                "set only one of QUESTRA_CLIENT_ASSERTION_PATH or "
                "QUESTRA_USERNAME/QUESTRA_PASSWORD."
            )

        if env_assertion is not None:
            p = Path(env_assertion)
            if not p.exists():
                raise ValueError(
                    f"Client assertion token file from QUESTRA_CLIENT_ASSERTION_PATH "
                    f"not found: '{env_assertion}'"
                )
            return OAuth2ClientAssertionCredential(assertion_path=p)

        if env_username and env_password:
            return OAuth2ServiceCredential(username=env_username, password=env_password)

        # --- Tier 3: K8s SA token auto-detect (opt-in) ---
        if use_default_assertion:
            for default in _DEFAULT_ASSERTION_PATHS:
                p = Path(default)
                if p.exists():
                    return OAuth2ClientAssertionCredential(assertion_path=p)

        raise ValueError(
            "No authentication credentials found. "
            "Provide username/password, a client assertion file "
            "(client_assertion_path or QUESTRA_CLIENT_ASSERTION_PATH), "
            "set interactive=True, or enable Kubernetes service account "
            "auto-detection with use_default_assertion=True "
            "(or QUESTRA_USE_DEFAULT_ASSERTION=true)."
        )

    def _initialize(self):
        """Initialize OIDC Discovery and OAuth2 Client."""
        # OIDC Discovery
        discovery_urls = self._build_discovery_urls()
        oidc_discovery_client = OidcDiscoveryClient(discovery_urls)
        self._oidc_config = oidc_discovery_client.discover()

        credentials = self._resolve_credentials(
            username_param=self._username_param,
            password_param=self._password_param,
            client_assertion_path_param=self.client_assertion_path,
            interactive=self.interactive,
            use_default_assertion=self.use_default_assertion,
        )

        self._oauth_client = OAuth2Authentication(
            client_id=self.client_id,
            credentials=credentials,
            oidc_config=self._oidc_config,
            scope=self.scope,
        )

        self._oauth_client.authenticate()

    def _build_discovery_urls(self) -> str | list[str]:
        """
        Creates Discovery URLs based on Base-URL and discovery paths.

        Returns:
            str | list[str]: String or List of Discovery URLs
        """
        if isinstance(self.url, list):
            # Multiple URLs were passed
            if self.oidc_discovery_paths:
                # Combine all URLs with all discovery paths
                urls = []
                for base_url in self.url:
                    for path in self.oidc_discovery_paths:
                        urls.append(f"{base_url.rstrip('/')}{path}")
                return urls
            else:
                return self.url
        else:
            # Single URL
            if self.oidc_discovery_paths:
                return [
                    f"{self.url.rstrip('/')}{path}"
                    for path in self.oidc_discovery_paths
                ]
            else:
                return self.url

    def get_access_token(self) -> str:
        """
        Returns a valid access token.

        The token is automatically renewed if it has expired.
        This method should be called before each API request.

        Returns:
            str: Valid access token

        Raises:
            Exception: If authentication has failed
        """
        if not self._oauth_client:
            raise Exception("OAuth Client not initialized")

        return self._oauth_client.get_access_token()

    def get_oidc_config(self) -> OidcConfig:
        """
        Returns the OIDC configuration.

        Returns:
            OidcConfig: Object with all endpoints
        """
        if not self._oidc_config:
            raise Exception("OIDC Config not initialized")

        return self._oidc_config

    def is_authenticated(self) -> bool:
        """
        Checks if the client is authenticated.

        Returns:
            True if authenticated, otherwise False
        """
        return self._oauth_client is not None and self._oauth_client.authenticated

    def reauthenticate(self):
        """
        Forces a re-authentication.

        This can be useful if the credentials have changed
        or in case of authentication problems.
        """
        if self._oauth_client:
            self._oauth_client.authenticate()
        else:
            self._initialize()
