# Questra Authentication

Python OAuth2 Authentication Client für die Questra API mit Unterstützung für Service-Account- und interaktive Benutzer-Authentifizierung.

## Features

- **Service Account & Interaktive Authentifizierung**: Username/Password oder OAuth2 Device Code Flow
- **Automatisches Token-Management**: Automatische Token-Refresh-Mechanismen
- **OIDC Discovery**: Automatische Erkennung von OAuth2 Endpoints
- **Type-Safe**: Vollständig typisierte API mit Dataclasses

## Installation

```bash
pip install seven2one-questra-authentication
```

## Requirements

- Python >= 3.10
- requests-oauthlib >= 2.0.0

## Schnellstart

### Service Account

```python
from seven2one.questra.authentication import QuestraAuthentication

client = QuestraAuthentication(
    url="https://auth.example.com",
    username="ServiceUser",
    password="secret_password"
)

access_token = client.get_access_token()
```

### Interaktiver Benutzer

```python
client = QuestraAuthentication(
    url="https://auth.example.com",
    interactive=True
)

access_token = client.get_access_token()
```

## Erweiterte Verwendung

```python
# Mehrere Discovery-Pfade
client = QuestraAuthentication(
    url="https://auth.example.com",
    username="ServiceUser",
    password="secret",
    oidc_discovery_paths=["/app/o/techstack", "/app/o/questra"]
)

# Benutzerdefinierte Scopes
client = QuestraAuthentication(
    url="https://auth.example.com",
    username="ServiceUser",
    password="secret",
    scope="openid profile email"
)
```

## Weitere Informationen

- **Vollständige Dokumentation:** <https://pydocs.[questra-host.domain]>
- **Support:** <support@seven2one.de>

## License

Proprietary - Seven2one Informationssysteme GmbH
