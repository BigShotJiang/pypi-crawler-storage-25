"""T7 — perplexity-based LLM-text signal (opt-in, costs an API call).

**Empirical scope (2.2.7).** T7 is validated on **non-reasoning** LMs
that return real per-token logprobs (e.g. OpenAI `gpt-4o-mini`,
self-hosted vLLM Llama-3.x). On reasoning models the perplexity
contrast collapses (the LM rates everything as low-surprisal because
it has already "thought through" the continuation) and on chat-only
proxies that drop logprobs (cliproxy, several team pools) the
detector silently no-ops. The free-tier Groq path
`qwen/qwen3-32b` returns real logprobs but the signal is weak
(LR+ = 1.69, p = 0.11 at N=17 — directionally correct but underpowered).
See `docs/llm_detection_real_endpoints.md` for the per-endpoint
compatibility matrix.

Where T6 looks for *dictionary tics* — phrases over-represented in LLM
output — T7 measures the **information-theoretic surprisal** of the
manuscript prose under a reference language model. Human academic
writing has a typical perplexity around 25-80 for technical English;
unedited LLM output sits much lower (5-15) because the model is
emitting the very next token it would have predicted.

This is **paraphrase-resistant** in a way T6 is not. A determined
LLM user can swap out every "delve into" / "tapestry of" by hand,
but reducing perplexity back to human levels requires substantive
rewriting.

Trade-offs you should know:

  - Perplexity is **noisy at short lengths** — we require ≥ 500 words
    before running. Even then the signal is weak.
  - Heavily polished prose by a non-native English author can also
    sit low (~10-15) because professional editing reduces surprisal.
  - Domain-specific boilerplate ("Materials and Methods", "Statistical
    Analysis") is inherently low-perplexity even when human-written.
  - The reference LM matters. A small, weak model assigns lower
    likelihood to all text and inflates perplexity; switch models and
    the threshold has to move with it. For that reason, default
    thresholds below are conservative and the detector always emits
    a NOTE-level disclaimer about model dependence.

Severity tiers (default thresholds):

  perplexity > 20  → no finding (normal human academic English)
  10 ≤ ppl ≤ 20    → NOTE         (low, weakly indicative)
  5  ≤ ppl < 10    → SUSPICIOUS   (very low for academic prose)
       ppl < 5     → CRITICAL     (LM is essentially predicting it
                                   exactly — characteristic of
                                   unedited LLM output)

Failure modes (always silent, never raise):

  - API unreachable → no finding, log a warning
  - API returns no logprobs → no finding
  - Text too short → check_applicability returns False with reason
  - Network timeout → no finding
"""
from __future__ import annotations

import logging
import math
import os
import re
from typing import Any, ClassVar

from paperguard.core.base_detector import BaseDetector
from paperguard.core.types import Finding, Severity

logger = logging.getLogger(__name__)


# Tiers — exposed as class attributes so callers / tests can override.
#
# Two threshold modes:
#
# - **Classical (default).** Low continuation-perplexity is the signal.
#   Matches the original DetectGPT-literature framing. Use on
#   self-hosted Llama-3.x, vLLM-style endpoints, or any reference LM
#   that has NOT been RLHF-trained to suppress LLM-style markers.
# - **Inverted** (2.4.2, opt-in via PAPERGUARD_T7_INVERT_THRESHOLD=1).
#   HIGH continuation-perplexity is the signal. Use on OpenAI
#   gpt-4o / gpt-4o-mini and similar RLHF-heavy endpoints: the
#   2.4.1 study showed AI samples score systematically HIGHER ppl
#   than human academic prose on these reference LMs because the
#   model itself was trained to avoid LLM-style markers and therefore
#   finds them surprising on input. LR+ measured at 8.0 on gpt-4o
#   with the inverted threshold at 1.463 (TPR 80 % / FPR 10 %); see
#   docs/llm_detection_real_endpoints.md.
_DEFAULT_NOTE = 20.0
_DEFAULT_SUSPICIOUS = 10.0
_DEFAULT_CRITICAL = 5.0

# Inverted-mode thresholds, calibrated against the 2.4.1 gpt-4o run:
#   human  median 1.282  max 1.561
#   ai     min    1.366  median 1.565  max 1.833
# 1.46 = midpoint(min(AI), max(human)) = LR+ 8.0 calibration point.
# Above 1.56 = max(human) → LR+ ∞ on the v2.4.1 corpus.
_DEFAULT_INVERTED_NOTE = 1.46
_DEFAULT_INVERTED_SUSPICIOUS = 1.56
_DEFAULT_INVERTED_CRITICAL = 1.70


def _opt_in_enabled() -> bool:
    """T7 is gated by an env var the CLI flag flips on."""
    return os.environ.get("PAPERGUARD_PERPLEXITY_CHECK", "").lower() in {
        "1",
        "true",
        "yes",
    }


_OPENAI_INVERT_MODEL_PREFIXES: tuple[str, ...] = (
    # Empirically validated in 2.5.1 — all four show inverted direction.
    "gpt-3.5", "gpt-4",  # matches gpt-4, gpt-4o, gpt-4o-mini, gpt-4-turbo
    # gpt-5.x via cliproxy / responses API: not validated; left out of
    # auto-detect. Operator can still force-set the env var.
)


def _invert_enabled() -> bool:
    """Whether to use the inverted threshold direction.

    Three modes:

    1. **Explicit user override** (highest priority): set
       ``PAPERGUARD_T7_INVERT_THRESHOLD=1`` to force inverted,
       or ``=0``/``=false``/``=no`` to force classical. Use ``=0``
       to disable auto-detect when running against an OpenAI
       endpoint where you suspect direction has flipped back (e.g.
       a future model release).
    2. **Endpoint-based auto-detect (new in 2.6.0)**: if
       ``PAPERGUARD_LLM_BASE_URL`` contains ``api.openai.com`` AND
       ``PAPERGUARD_LLM_MODEL`` starts with one of the empirically-
       validated inverted-direction prefixes (gpt-3.5 / gpt-4), use
       inverted thresholds. This matches the 2.5.1 four-model study
       result without requiring the operator to remember to set the
       env var.
    3. **Default**: classical "low ppl = signal" direction.

    Decision history per endpoint is in
    `docs/llm_detection_real_endpoints.md`.
    """
    forced = os.environ.get("PAPERGUARD_T7_INVERT_THRESHOLD", "").strip().lower()
    if forced in {"1", "true", "yes"}:
        return True
    if forced in {"0", "false", "no"}:
        return False
    # Auto-detect.
    base_url = os.environ.get("PAPERGUARD_LLM_BASE_URL", "").lower()
    model = os.environ.get("PAPERGUARD_LLM_MODEL", "").lower()
    if "api.openai.com" in base_url and any(
        model.startswith(p) for p in _OPENAI_INVERT_MODEL_PREFIXES
    ):
        return True
    return False


def _segment_text(text: str, max_chars_per_segment: int = 2400) -> list[str]:
    """Split text into ~equal sentence-aligned segments under the char cap.

    We split on sentence boundaries (period+space) so that the LM doesn't
    score a partial sentence — that would unfairly inflate perplexity.
    """
    if not text:
        return []
    # split into sentences
    sentences = re.split(r"(?<=[.!?])\s+", text.strip())
    segments: list[str] = []
    buf = ""
    for s in sentences:
        if not s:
            continue
        if len(buf) + len(s) + 1 > max_chars_per_segment and buf:
            segments.append(buf.strip())
            buf = s
        else:
            buf = (buf + " " + s) if buf else s
    if buf:
        segments.append(buf.strip())
    return segments


def _call_openai_logprobs(
    text: str, model: str, base_url: str, api_key: str, timeout: float
) -> list[float] | None:
    """Return per-token logprobs by asking the API to score a continuation.

    Implementation strategy
    -----------------------
    The chat-completions API doesn't directly expose "perplexity of an
    input string". The workaround we use:

      1. Send the text as the *user* message and ask the assistant to
         echo back a one-token confirmation ("OK"). The completion is
         tiny — we don't care about that response.
      2. Pass ``logprobs=true`` and ``top_logprobs=5``. The OpenAI-shape
         response then returns logprobs *for the completion tokens*,
         not the prompt — so this only measures the assistant's reply,
         not the manuscript.

    That doesn't give us prompt-token perplexity. For a true prompt
    perplexity we'd need the legacy /v1/completions endpoint with
    ``echo=true logprobs=N`` — but the major proxies (cliproxy
    included) don't expose that. **So this implementation uses a
    practical proxy**: we instruct the model to *continue* the
    manuscript text. Specifically:

      - System: "Continue the following academic text exactly as it
        would be written. Respond with the next 32 tokens only."
      - User: text[:N]
      - Then we read the logprobs of the *completion*. The intuition:
        if the manuscript truly is LLM-written, the model will be
        very confident about how to continue (low entropy → low
        perplexity). If human-written, the continuation is
        comparatively uncertain.

    This is a *continuation-perplexity* proxy, NOT the literature's
    classical input-perplexity. We document this clearly in the
    Finding's `applicability_notes`.

    Returns None on any failure (network, missing logprobs field, etc.)
    """
    import httpx

    payload: dict[str, Any] = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "Continue the following academic text exactly as it would "
                    "be written in the same source. Output only the next "
                    "few tokens — no commentary, no header, no quotes."
                ),
            },
            {"role": "user", "content": text},
        ],
        # max_tokens=256 covers reasoning-model thinking budgets (Qwen3,
        # DeepSeek-v4) + the actual continuation. Non-reasoning models
        # ignore the extra ceiling.
        "max_tokens": 256,
        "temperature": 0,
        "logprobs": True,
        "top_logprobs": 5,
    }
    # Proxies that 400 on response_format also tend to 400 on logprobs.
    # Caller catches and returns None — that's fine.
    try:
        r = httpx.post(
            f"{base_url.rstrip('/')}/chat/completions",
            headers={"Authorization": f"Bearer {api_key}"},
            json=payload,
            timeout=timeout,
        )
        r.raise_for_status()
        data = r.json()
    except httpx.HTTPError as e:
        logger.warning("T7 LLM call failed: %s", e)
        return None
    except ValueError as e:
        logger.warning("T7 LLM response not JSON: %s", e)
        return None

    try:
        choice = data["choices"][0]
        lp = choice.get("logprobs") or {}
        content = lp.get("content") or []
        out: list[float] = []
        for tok in content:
            v = tok.get("logprob")
            if isinstance(v, (int, float)):
                out.append(float(v))
        if not out:
            return None
        return out
    except (KeyError, IndexError, TypeError) as e:
        logger.warning("T7 LLM logprobs missing/malformed: %s", e)
        return None


def _logprobs_to_perplexity(logprobs: list[float]) -> float:
    """Perplexity = exp(-mean(logprob)). logprob is natural log."""
    if not logprobs:
        return float("inf")
    return math.exp(-sum(logprobs) / len(logprobs))


def compute_perplexity(
    text: str,
    *,
    model: str | None = None,
    max_segments: int = 3,
    timeout: float = 60.0,
) -> float | None:
    """Public helper: compute perplexity for a piece of text or None on failure.

    Strategy:
      1. Try the logprobs route first (works when the API returns token
         logprobs).
      2. If that fails for every segment, fall back to the
         generation-divergence proxy (works on any chat-completion endpoint).

    The two routes return slightly different absolute numbers, but both
    sit in the same range and share the same severity thresholds.
    """
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        logger.warning("T7: OPENAI_API_KEY not set")
        return None
    base_url = os.environ.get(
        "PAPERGUARD_LLM_BASE_URL", "https://api.openai.com/v1"
    )
    model_name = (
        model or os.environ.get("PAPERGUARD_LLM_MODEL") or "gpt-4o-mini"
    )
    segments = _segment_text(text)[:max_segments]
    if not segments:
        return None

    # Classical logprobs perplexity. If the proxy doesn't return logprobs
    # we return None — the detector then emits a NOTE-level "inconclusive"
    # finding rather than fabricating a number. T8 (DetectGPT-style
    # perturbation) is the proper alternative when logprobs aren't
    # available; see ``paperguard.detectors.t8_detectgpt``.
    perps: list[float] = []
    for seg in segments:
        lp = _call_openai_logprobs(seg, model_name, base_url, api_key, timeout)
        if lp is None:
            continue
        perps.append(_logprobs_to_perplexity(lp))
    if not perps:
        return None
    return math.exp(sum(math.log(p) for p in perps) / len(perps))


class T7PerplexityDetector(BaseDetector):
    """Continuation-perplexity proxy for LLM-generated manuscript text.

    See module docstring for the methodology + caveats. The detector is
    opt-in via the ``PAPERGUARD_PERPLEXITY_CHECK=1`` env var, which the
    CLI ``--perplexity-check`` flag sets automatically.
    """

    id: ClassVar[str] = "T7"
    name: ClassVar[str] = "LLM Perplexity (continuation proxy)"
    description: ClassVar[str] = (
        "Measures how confidently a reference LM continues the manuscript "
        "text. Low continuation-perplexity is weakly indicative of LLM "
        "authorship. Opt-in; requires an LLM API."
    )
    academic_basis: ClassVar[str] = (
        "Gehrmann et al. (2019) GLTR; Mitchell et al. (2023) DetectGPT; "
        "Bao et al. (2023) Fast-DetectGPT. PaperGuard adapts the idea as "
        "a continuation-perplexity proxy compatible with chat-completion "
        "APIs (the OSS literature mostly used /v1/completions logprobs)."
    )
    data_requirements: ClassVar[list[str]] = ["manuscript_text"]
    assumption_cluster: ClassVar[str] = "paper_mill_signature"

    MIN_WORDS: ClassVar[int] = 500
    THRESHOLD_NOTE: ClassVar[float] = _DEFAULT_NOTE
    THRESHOLD_SUSPICIOUS: ClassVar[float] = _DEFAULT_SUSPICIOUS
    THRESHOLD_CRITICAL: ClassVar[float] = _DEFAULT_CRITICAL
    # Inverted-mode thresholds (used when PAPERGUARD_T7_INVERT_THRESHOLD=1).
    INVERTED_THRESHOLD_NOTE: ClassVar[float] = _DEFAULT_INVERTED_NOTE
    INVERTED_THRESHOLD_SUSPICIOUS: ClassVar[float] = _DEFAULT_INVERTED_SUSPICIOUS
    INVERTED_THRESHOLD_CRITICAL: ClassVar[float] = _DEFAULT_INVERTED_CRITICAL

    def check_applicability(self, data: Any) -> tuple[bool, str]:
        if not _opt_in_enabled():
            return False, (
                "T7 is opt-in; set PAPERGUARD_PERPLEXITY_CHECK=1 "
                "(or pass --perplexity-check)."
            )
        if not isinstance(data, str):
            return False, "Expected text string"
        n_words = len(re.findall(r"\b[a-zA-Z]+\b", data))
        if n_words < self.MIN_WORDS:
            return False, (
                f"Text too short for stable perplexity estimate "
                f"({n_words} < {self.MIN_WORDS})"
            )
        if not os.environ.get("OPENAI_API_KEY"):
            return False, "OPENAI_API_KEY not set; T7 requires an LLM API."
        return True, ""

    def _detect(self, data: str, seed: int) -> list[Finding]:
        perplexity = compute_perplexity(data)
        if perplexity is None or not math.isfinite(perplexity):
            # API failed — emit a NOTE so the user knows we tried.
            return [
                Finding(
                    detector_id=self.id,
                    detector_name=self.name,
                    severity=Severity.NOTE,
                    summary=(
                        "T7 perplexity check requested but the LLM API "
                        "call did not return usable logprobs"
                    ),
                    detail=(
                        "We attempted a continuation-perplexity probe but "
                        "the response contained no logprobs (proxy may not "
                        "support logprobs=true). T7 is reported as "
                        "inconclusive — this is NOT evidence of LLM "
                        "authorship, only that the check could not run."
                    ),
                    evidence={"perplexity": None, "outcome": "api_no_logprobs"},
                    innocent_explanations=[
                        "The configured LLM proxy may not expose token "
                        "logprobs; switch to an endpoint that does.",
                        "Transient network failure — retry the scan.",
                        "Rate-limit response from the proxy.",
                    ],
                    academic_reference=self.academic_basis,
                    applicability_notes=(
                        "Inconclusive — no logprobs in the API response."
                    ),
                )
            ]

        inverted = _invert_enabled()
        severity: Severity | None = None
        if inverted:
            # HIGH perplexity = signal (RLHF-heavy reference LM, e.g.
            # OpenAI gpt-4o). See module docstring + 2.4.1 study.
            if perplexity > self.INVERTED_THRESHOLD_CRITICAL:
                severity = Severity.CRITICAL
            elif perplexity > self.INVERTED_THRESHOLD_SUSPICIOUS:
                severity = Severity.SUSPICIOUS
            elif perplexity > self.INVERTED_THRESHOLD_NOTE:
                severity = Severity.NOTE
        else:
            # LOW perplexity = signal (classical DetectGPT-direction;
            # self-hosted Llama-3, vLLM, etc.).
            if perplexity < self.THRESHOLD_CRITICAL:
                severity = Severity.CRITICAL
            elif perplexity < self.THRESHOLD_SUSPICIOUS:
                severity = Severity.SUSPICIOUS
            elif perplexity < self.THRESHOLD_NOTE:
                severity = Severity.NOTE

        if severity is None:
            # Perplexity is in the normal human-academic range → no finding.
            return []

        if inverted:
            summary = (
                f"Continuation perplexity {perplexity:.2f} "
                f"(> {self.INVERTED_THRESHOLD_NOTE:.2f}, inverted-mode); "
                "weak LLM-authorship signal"
            )
            detail = (
                f"Reference LM produces a continuation of the manuscript "
                f"with perplexity {perplexity:.2f}. T7 is running in "
                f"**inverted** threshold mode "
                f"(PAPERGUARD_T7_INVERT_THRESHOLD=1) where HIGH perplexity "
                f"is the signal. On RLHF-heavy reference LMs (OpenAI "
                f"gpt-4o family) LLM-style markers themselves are "
                f"low-probability for the reference LM, so AI-authored "
                f"text scores HIGHER perplexity than human academic "
                f"prose. Empirical anchor: 2.4.1 gpt-4o study, LR+ = 8.0 "
                f"at threshold 1.46 (TPR 80 % / FPR 10 %). High "
                f"perplexity in this mode is consistent with — but not "
                f"proof of — LLM authorship."
            )
        else:
            summary = (
                f"Continuation perplexity {perplexity:.2f} "
                f"(< {self.THRESHOLD_NOTE:.1f}); weak LLM-authorship signal"
            )
            detail = (
                f"Reference LM produces a continuation of the manuscript "
                f"with perplexity {perplexity:.2f}. Normal academic "
                f"English typically sits above {self.THRESHOLD_NOTE:.0f}. "
                "Lower perplexity is consistent with — but not proof "
                "of — LLM authorship.\n\n"
                "Methodology: continuation-perplexity proxy (NOT classical "
                "input perplexity). The LM is asked to continue the text; "
                "the per-token logprobs of its completion are aggregated. "
                "This is a published-literature-inspired approximation "
                "compatible with chat-completion APIs."
            )
        return [
            Finding(
                detector_id=self.id,
                detector_name=self.name,
                severity=severity,
                summary=summary,
                detail=detail,
                test_statistic=perplexity,
                test_name="continuation perplexity",
                evidence={
                    "perplexity": perplexity,
                    "inverted_threshold_mode": inverted,
                    "threshold_note": (
                        self.INVERTED_THRESHOLD_NOTE if inverted
                        else self.THRESHOLD_NOTE
                    ),
                    "threshold_suspicious": (
                        self.INVERTED_THRESHOLD_SUSPICIOUS if inverted
                        else self.THRESHOLD_SUSPICIOUS
                    ),
                    "threshold_critical": (
                        self.INVERTED_THRESHOLD_CRITICAL if inverted
                        else self.THRESHOLD_CRITICAL
                    ),
                    "model": (
                        os.environ.get("PAPERGUARD_LLM_MODEL") or "default"
                    ),
                },
                innocent_explanations=[
                    "Professional English editing (common for non-native "
                    "authors) reduces continuation perplexity by polishing "
                    "the prose into more predictable phrasing.",
                    "Technical boilerplate sections (Methods, Statistical "
                    "Analysis) inherently sit at low perplexity even when "
                    "human-written.",
                    "The reference LM may be biased toward the manuscript's "
                    "domain (e.g., trained heavily on biomedical literature) "
                    "— it will find such text predictable regardless of "
                    "authorship.",
                    "Perplexity is a *statistical* signal; the absolute "
                    "value depends on the reference model. Do not treat "
                    "a single low value as a verdict — corroborate with "
                    "T6 phrase signal and editorial review.",
                ],
                academic_reference=self.academic_basis,
                applicability_notes=(
                    "Continuation-perplexity proxy. Output depends on the "
                    "reference model; thresholds are conservative defaults "
                    "for GPT-4-class models. Re-tune via T7's THRESHOLD_* "
                    "class attributes for other LMs."
                ),
            )
        ]
