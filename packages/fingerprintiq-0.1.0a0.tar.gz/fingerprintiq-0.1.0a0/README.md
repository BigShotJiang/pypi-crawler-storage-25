# fingerprintiq

Official Python SDK for [FingerprintIQ](https://fingerprintiq.com) — browser and API-caller fingerprinting with three products:

- **Identify** — server-side visitor lookup by visitor ID
- **Sentinel** — FastAPI/ASGI middleware to classify API callers (browsers, AI agents, CLI tools, bots)
- **Pulse** — CLI usage analytics and machine fingerprinting

> **Status:** Placeholder release. The full implementation ships in `0.1.0`. Follow progress at https://github.com/seangeng/fingerprintiq.

## Installation

```bash
pip install fingerprintiq
```

## License

MIT
