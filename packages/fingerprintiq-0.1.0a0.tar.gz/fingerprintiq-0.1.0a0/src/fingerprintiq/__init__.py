"""FingerprintIQ Python SDK — placeholder release.

The full implementation ships in 0.1.0. See https://github.com/seangeng/fingerprintiq.
"""

from fingerprintiq._version import __version__

__all__ = ["__version__"]
