"""
1. Go to the ComfyUI app.
2. Choose a specific workflow.
3. Do right click on the name of the work flow and clic 'Export (API)'*.
    *Remember, the 'Dev mode' must be activated in 'Settings'.
4. Save the file with the filename you want.
5. Provide that filename to this app.
"""