from yta_comfyui_api.workflow.abstract import Workflow

import random


class Text2ImageZTurboWorkflow(Workflow):
    """
    A workflow using the Z-Turbo model to generate an
    image from a text prompt.
    """

    def __init__(
        self,
        prompt: str,
        width: int = 1920,
        height: int = 1080
    ):
        super().__init__(
            filename = 'test_files/image_z_image_turbo.json'
        )

        self.prepare(
            prompt = prompt,
            width = width,
            height = height
        )
    
    def prepare(
        self,
        prompt: str,
        width: int = 1920,
        height: int = 1080
    ) -> None:
        prompt_node = self.prompt['57:27']
        ksampler_node = self.prompt['57:3']
        latent_node = self.prompt['57:13']
        save_node = self.prompt['9']

        latent_node['inputs']['width'] = width
        latent_node['inputs']['height'] = height
        latent_node['inputs']['batch_size'] = 1

        # Random seed
        ksampler_node['inputs']['seed'] = random.randint(1, 2**64 - 1)

        # Actual prompt
        prompt_node['inputs']['text'] = prompt

        # Output filename
        fileprefix = prompt[:80].replace(' ', '_')
        save_node['inputs']['filename_prefix'] = fileprefix

        self._is_prepared = True