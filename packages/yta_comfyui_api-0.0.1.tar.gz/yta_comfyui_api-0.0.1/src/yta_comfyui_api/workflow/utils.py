import json


def open_workflow(
    filename: str
) -> dict:
    """
    Open the workflow with the given `filename` and
    return it as a dict that can be modified to adjust
    the parameters we need.
    """
    with open(filename, 'r', encoding = 'utf-8') as file:
        prompt_workflow = json.load(file)

    return prompt_workflow