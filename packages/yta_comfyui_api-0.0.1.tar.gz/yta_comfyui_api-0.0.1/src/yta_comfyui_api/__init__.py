"""
A library to have access to the ComfyUI models through
its API using the workflows by code directly.

This needs ComfyUI running.
"""
from urllib import request, parse

import json
import random
import time
import shutil


BASE_URL = 'http://127.0.0.1:8000'
PROMPT_ENDPOINT_URL = f'{BASE_URL}/prompt'
HISTORY_ENDPOINT_URL = f'{BASE_URL}/history'
OUTPUT_PATH = 'C:/ComfyUI/output/'
"""
The endpoint of the ComfyUI server
"""
def queue_prompt(
    prompt_workflow
):
    p = {"prompt": prompt_workflow}
    data = json.dumps(p).encode("utf-8")
    req = request.Request(PROMPT_ENDPOINT_URL, data = data)
    res = json.loads(request.urlopen(req).read())
    return res['prompt_id']

def wait_for_completion(
    prompt_id,
    poll_interval = 0.5
):
    while True:
        try:
            with request.urlopen(f'{HISTORY_ENDPOINT_URL}/{prompt_id}') as res:
                history = json.loads(res.read())

            if prompt_id in history:
                return history[prompt_id]

        except Exception:
            pass

        time.sleep(poll_interval)

def get_images(
    result_json
):
    outputs = result_json['outputs']
    images = []

    for node_id in outputs:
        node_output = outputs[node_id]

        if 'images' in node_output:
            for img in node_output['images']:
                images.append(img)  # contiene filename, subfolder, type

    return images

WORKFLOW_FILENAME = 'test_files/image_z_image_turbo.json'

"""
Read workflow API data from file and turn into a
dict to assign the variables
"""
# read workflow api data from file and convert it into dictionary 
# assign to var prompt_workflow
with open(WORKFLOW_FILENAME, 'r', encoding = 'utf-8') as file:
    prompt_workflow = json.load(file)
# prompt_workflow = json.load(open('workflow_api.json'))

prompt_list = [
    'A full-body portrait of Mario (the character of the video game Mario Bros, but as a person) standing and facing forward, centered in the frame. Realistic but slightly caricatured style suitable for historical explainer videos, with subtle exaggeration of facial features while maintaining recognizability. Neutral, confident posture, arms relaxed at sides. Clean studio lighting, even illumination, soft shadows, sharp focus, high detail. Solid bright green background (pure chroma key green), completely uniform, no gradients, no texture, no objects. Cinematic composition, subject fully visible head-to-toe, no cropping, 4k detail.',
    # "A dramatic battlefield with tanks in the distance, cloudy sky, no characters",
    # "War environment, ruined city, atmospheric haze, empty scene",
]

# Nodes references to update the flow
"""
This is based on the workflow that is exported
to the API and is different for any new workflow
we create.
"""
prompt_node = prompt_workflow['57:27']
ksampler_node = prompt_workflow['57:3']
latent_node = prompt_workflow['57:13']
save_node = prompt_workflow['9']

latent_node['inputs']['width'] = 1920
latent_node['inputs']['height'] = 1080
latent_node['inputs']['batch_size'] = 1

for i, prompt in enumerate(prompt_list):
    # Update data in the workflow

    # Random seed
    ksampler_node['inputs']['seed'] = random.randint(1, 2**64 - 1)

    # Set prompt
    prompt_node['inputs']['text'] = prompt

    # Output filename
    fileprefix = prompt[:80].replace(' ', '_')
    save_node['inputs']['filename_prefix'] = fileprefix

    # Send to be processed
    prompt_id = queue_prompt(prompt_workflow)
    print(f'Queued prompt_id: {prompt_id}')

    result = wait_for_completion(prompt_id)
    print('Done')

    images = get_images(result)

    for img in images:
        print(img)
        extension = img['filename'].split('.')[-1]
        shutil.copy(f'{OUTPUT_PATH}/{img["filename"]}', f'./test_files/{prompt_id}_{str(i)}.{extension}')