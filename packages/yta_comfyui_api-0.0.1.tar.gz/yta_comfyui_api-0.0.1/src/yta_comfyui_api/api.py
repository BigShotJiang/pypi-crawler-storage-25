from urllib import request

import json
import time


BASE_URL = 'http://127.0.0.1:8000'
PROMPT_ENDPOINT_URL = f'{BASE_URL}/prompt'
HISTORY_ENDPOINT_URL = f'{BASE_URL}/history'
OUTPUT_PATH = 'C:/ComfyUI/output/'

# TODO: Maybe singleton (?)
class ComfyUIAPI:
    """
    Class to represent the connection with the ComfyUI API.
    """

    def __init__(
        self,
        base_url: str = BASE_URL,
        output_path: str = OUTPUT_PATH
    ):
        self.base_url: str = base_url
        """
        The base url of the ComfyUI server.
        """
        self._output_path: str = output_path
        """
        *For internal use only*

        The output path of the ComfyUI server, which is set
        when the app is installed.
        """

    def queue_workflow(
        workflow: 'Workflow'
    ) -> str:
        """
        Send the `workflow` provided to the queue to be processed
        and get the `prompt_id` that can be used to receive the
        result when finished.
        """
        if not workflow._is_prepared:
            raise Exception('The workflow has not been prepared yet.')
        
        p = {'prompt': workflow.prompt}
        data = json.dumps(p).encode('utf-8')
        req = request.Request(PROMPT_ENDPOINT_URL, data = data)
        res = json.loads(request.urlopen(req).read())

        return res['prompt_id']
    
    def _wait_for_completion(
        prompt_id: str,
        timeout: float = 180.0
    ) -> dict:
        """
        *For internal use only*

        Wait for the completion of the `prompt_id` provided,
        waiting a maximum time of `timeout` seconds.
        """
        TIME_IN_BETWEEN_CHECKS: float = 1.0
        start_time = time.monotonic()

        while True:
            if time.monotonic() - start_time >= timeout:
                # TODO: Maybe return None instead (?)
                raise TimeoutError(f'Timeout waiting for prompt_id={prompt_id}')

            try:
                with request.urlopen(f'{HISTORY_ENDPOINT_URL}/{prompt_id}') as res:
                    history = json.loads(res.read())

                if prompt_id in history:
                    return history[prompt_id]

            except Exception:
                pass

            time.sleep(TIME_IN_BETWEEN_CHECKS)

    def _get_images(
        result_json
    ) -> list[dict]:
        """
        *For internal use only*

        Get the images from the `result_json` provided, that
        must be the result of a task queued that has been
        completed.
        """
        outputs = result_json['outputs']
        images = []

        for node_id in outputs:
            node_output = outputs[node_id]

            if 'images' in node_output:
                for img in node_output['images']:
                    images.append(img)

        return images