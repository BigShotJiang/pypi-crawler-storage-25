from __future__ import annotations

import argparse

from ssot_registry.api import export_registry, repair_document_hashes, sync_automated_statuses


def register_registry(subparsers: argparse._SubParsersAction) -> None:
    registry = subparsers.add_parser(
        "registry",
        help="Export the full registry in operator-friendly formats.",
        description="Render the complete SSOT registry for interchange, audits, or downstream analysis.",
    )
    registry_sub = registry.add_subparsers(dest="registry_command", required=True)

    export = registry_sub.add_parser(
        "export",
        help="Serialize the entire registry document.",
        description="Export the full registry into a machine-readable or operator-readable format.",
    )
    export.add_argument("path", nargs="?", default=".", help="Repository root or registry file to export from.")
    export.add_argument("--format", required=True, choices=["json", "csv", "df", "yaml", "toml"], help="Output format to write.")
    export.add_argument("--output", default=None, help="Destination file path. Defaults under `.ssot/exports`.")
    export.set_defaults(func=run_export)

    sync_statuses = registry_sub.add_parser(
        "sync-statuses",
        help="Derive and persist automated statuses.",
        description="Recompute profile, feature, test, claim, and evidence statuses from registry links and local artifact paths.",
    )
    sync_statuses.add_argument("path", nargs="?", default=".", help="Repository root or registry file to update.")
    sync_statuses.add_argument("--dry-run", action="store_true", help="Report proposed status changes without saving them.")
    sync_statuses.set_defaults(func=run_sync_statuses)

    repair_doc_hashes = registry_sub.add_parser(
        "repair-doc-hashes",
        help="Refresh mutable repo-local ADR/SPEC content hashes.",
        description=(
            "Repair explicitly selected repo-local ADR and SPEC content_sha256 values after validating each "
            "document at its registered path, then run full registry validation before saving."
        ),
    )
    repair_doc_hashes.add_argument("path", nargs="?", default=".", help="Repository root or registry file to repair.")
    repair_doc_hashes.add_argument("--ids", nargs="+", required=True, help="ADR and SPEC ids whose document hashes should be repaired.")
    repair_doc_hashes.set_defaults(func=run_repair_doc_hashes)


def run_export(args: argparse.Namespace) -> dict[str, object]:
    return export_registry(path=args.path, output_format=args.format, output=args.output)


def run_sync_statuses(args: argparse.Namespace) -> dict[str, object]:
    return sync_automated_statuses(path=args.path, dry_run=args.dry_run)


def run_repair_doc_hashes(args: argparse.Namespace) -> dict[str, object]:
    return repair_document_hashes(path=args.path, ids=args.ids)
