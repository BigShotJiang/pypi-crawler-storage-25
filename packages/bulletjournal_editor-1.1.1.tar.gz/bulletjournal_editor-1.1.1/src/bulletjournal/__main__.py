from bulletjournal.cli.app import app

if __name__ == '__main__':
    app()
