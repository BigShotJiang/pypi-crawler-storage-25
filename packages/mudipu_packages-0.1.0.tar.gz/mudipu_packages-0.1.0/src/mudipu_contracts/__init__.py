"""
mudipu-contracts: Shared Pydantic schema definitions for the Mudipu platform.
"""
from importlib.metadata import version, PackageNotFoundError

from mudipu_contracts.schemas import Turn, ToolCall, TraceEvent

try:
    __version__ = version("mudipu-packages")
except PackageNotFoundError:  # running from source without install
    __version__ = "0.0.0.dev0"

__all__ = ["Turn", "ToolCall", "TraceEvent", "__version__"]
