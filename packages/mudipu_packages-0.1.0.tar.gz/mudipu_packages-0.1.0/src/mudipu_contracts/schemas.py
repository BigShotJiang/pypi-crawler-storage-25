"""
Shared Pydantic schema definitions used across the Mudipu platform.
"""
from typing import Optional, Any
from uuid import UUID, uuid4
from datetime import datetime

from pydantic import BaseModel, Field


class ToolCall(BaseModel):
    """Represents a tool/function call detected in an LLM response."""

    id: str
    type: str = "function"
    function_name: Optional[str] = None
    function_arguments: Optional[str] = None


class Turn(BaseModel):
    """Represents a single request/response turn in a traced conversation."""

    id: UUID
    turn_number: int
    timestamp: str
    request_messages: list[dict[str, Any]] = Field(default_factory=list)
    request_tools: list[dict[str, Any]] = Field(default_factory=list)
    model: Optional[str] = None
    response_message: Optional[dict[str, Any]] = None
    duration_ms: Optional[float] = None
    usage: Optional[dict[str, Any]] = None
    tool_calls_detected: list[ToolCall] = Field(default_factory=list)
    has_tool_calls: bool = False


class TraceEvent(BaseModel):
    """Event published when a trace turn is captured and sent to the platform."""

    event_type: str
    session_id: UUID
    trace_id: UUID
    turn_data: Turn
    timestamp: str = Field(
        default_factory=lambda: datetime.utcnow().isoformat()
    )
