# mudipu-packages

Shared Pydantic schema contracts for the [Mudipu SDK](https://github.com/santnayak/mudipu-python) and platform.

This package defines the core data models used across the Mudipu ecosystem:

| Schema | Description |
|---|---|
| `Turn` | A single request/response turn in a traced conversation |
| `ToolCall` | A tool/function call detected in an LLM response |
| `TraceEvent` | Event emitted when a traced turn is captured |

## Installation

```bash
pip install mudipu-packages
```

Or install as part of the Mudipu SDK platform extra:

```bash
pip install mudipu[platform]
```

## Usage

```python
from mudipu_contracts.schemas import Turn, ToolCall, TraceEvent
from mudipu_contracts import __version__

print(__version__)
```


`mudipu-packages` sits at the boundary — it defines the shapes that the SDK produces and the platform consumes.

## Requirements

- Python ≥ 3.11
- pydantic ≥ 2.0

## License

MIT
