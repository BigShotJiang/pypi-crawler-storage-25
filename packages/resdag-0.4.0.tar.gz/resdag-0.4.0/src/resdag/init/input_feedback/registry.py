"""Registry for input/feedback weight initializers.

This module provides a registry of initializers for rectangular weight matrices
used in reservoir input and feedback connections.
"""

import inspect
from typing import Any, Callable, Type, get_args, get_origin

from .base import InputFeedbackInitializer

# Registry of initializer names to (class, default_kwargs)
_INPUT_FEEDBACK_REGISTRY: dict[str, tuple[Type[InputFeedbackInitializer], dict[str, Any]]] = {}


def register_input_feedback(
    name: str,
    **default_kwargs: Any,
) -> Callable[[Type[InputFeedbackInitializer]], Type[InputFeedbackInitializer]]:
    """Decorator to register an input/feedback initializer class.

    This decorator registers an initializer class in the registry at definition time,
    making it available for use with ESNLayer and other components.

    Parameters
    ----------
    name : str
        Name for the initializer (must be unique)
    **default_kwargs
        Default keyword arguments for the initializer constructor

    Returns
    -------
    callable
        Decorator function

    Examples
    --------
    >>> @register_input_feedback("my_init", scaling=0.5)
    ... class MyInitializer(InputFeedbackInitializer):
    ...     def __init__(self, scaling=1.0):
    ...         self.scaling = scaling
    ...
    ...     def initialize(self, weight, **kwargs):
    ...         # ... initialization logic
    ...         return weight

    Notes
    -----
    - Initializer classes must inherit from ``InputFeedbackInitializer``
    - Initializer classes must implement ``initialize(weight, **kwargs)`` method
    - Registered initializers can be accessed via ``get_input_feedback(name)``
    """

    def decorator(init_class: Type[InputFeedbackInitializer]) -> Type[InputFeedbackInitializer]:
        if name in _INPUT_FEEDBACK_REGISTRY:
            raise ValueError(f"Input/feedback initializer '{name}' is already registered")
        _INPUT_FEEDBACK_REGISTRY[name] = (init_class, default_kwargs)
        return init_class

    return decorator


def get_input_feedback(
    name: str,
    **override_kwargs: Any,
) -> InputFeedbackInitializer:
    """Get a pre-configured input/feedback initializer by name.

    Parameters
    ----------
    name : str
        Name of the initializer (e.g., "random", "binary_balanced")
    **override_kwargs
        Keyword arguments to override default initializer parameters

    Returns
    -------
    InputFeedbackInitializer
        Initializer instance

    Raises
    ------
    ValueError
        If initializer name is not registered

    Examples
    --------
    >>> initializer = get_input_feedback("binary_balanced", input_scaling=0.5)
    >>> weight = torch.empty(100, 10)
    >>> initializer.initialize(weight)
    """
    if name not in _INPUT_FEEDBACK_REGISTRY:
        available = ", ".join(_INPUT_FEEDBACK_REGISTRY.keys())
        raise ValueError(f"Unknown initializer '{name}'. Available initializers: {available}")

    init_class, default_kwargs = _INPUT_FEEDBACK_REGISTRY[name]

    # Merge default kwargs with overrides
    kwargs = {**default_kwargs, **override_kwargs}

    return init_class(**kwargs)


def show_input_initializers(name: str | None = None) -> list[str] | None:
    """Show available input/feedback initializers or details for a specific one.

    Parameters
    ----------
    name : str, optional
        Name of initializer to inspect. If None, prints all initializers
        *and* returns them as a list.

    Returns
    -------
    list of str or None
        When ``name is None``, returns the sorted list of registered
        initializer names (in addition to printing them).  When ``name``
        is provided, returns ``None`` after printing the parameter table.

    Raises
    ------
    ValueError
        If the specified initializer name is not registered.

    Examples
    --------
    >>> show_input_initializers()
    ['binary_balanced', 'chebyshev', 'chessboard', ...]
    """
    if name is None:
        names = sorted(_INPUT_FEEDBACK_REGISTRY)
        print("\nAvailable input/feedback initializers:\n")
        for n in names:
            print(f"  - {n}")
        print(f"\nTotal: {len(names)}\n")
        return names

    if name not in _INPUT_FEEDBACK_REGISTRY:
        available = "\n".join(sorted(_INPUT_FEEDBACK_REGISTRY.keys()))
        raise ValueError(f"Unknown initializer '{name}'.\nAvailable:\n{available}")

    init_class, default_kwargs = _INPUT_FEEDBACK_REGISTRY[name]
    sig = inspect.signature(init_class.__init__)

    print(f"\nInitializer: {name}\n")
    print("Parameters:\n")

    for param_name, param in sig.parameters.items():
        if param_name == "self":
            continue

        # Type extraction
        if param.annotation is not inspect.Parameter.empty:
            origin = get_origin(param.annotation)
            if origin is None:
                type_str = param.annotation.__name__
            else:
                args = get_args(param.annotation)
                type_str = " | ".join(a.__name__ for a in args)
        else:
            type_str = "Any"

        # Default resolution
        if param.default is not inspect.Parameter.empty:
            default = param.default
        else:
            default = default_kwargs.get(param_name, "<required>")

        print(f"  - {param_name}")
        print(f"      type:    {type_str}")
        print(f"      default: {default}\n")

    return None
