from setuptools import setup, find_packages

setup(
    name='spokest-langchain',
    version='1.0.0',
    description='LangChain integration for Spokest Brain memory',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Spokest',
    author_email='hello@spokest.com',
    url='https://github.com/spokest/spokest-langchain',
    packages=find_packages(),
    python_requires='>=3.9',
    install_requires=[
        'spokest>=1.0.0',
        'langchain-core>=0.2.0',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
