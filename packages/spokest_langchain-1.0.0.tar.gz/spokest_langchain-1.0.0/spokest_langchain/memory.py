"""Spokest Brain memory integration for LangChain."""

import logging
from typing import Any, Dict, List

import httpx
from langchain_core.memory import BaseMemory

logger = logging.getLogger(__name__)


class SpokestMemory(BaseMemory):
    """LangChain memory backed by Spokest Brain.

    Stores and retrieves memories via the Spokest Brain API,
    giving your LangChain chains persistent, associative memory.

    Example:
        >>> from spokest_langchain import SpokestMemory
        >>> memory = SpokestMemory(api_key="sk-...")
        >>> chain = ConversationChain(llm=llm, memory=memory)
    """

    api_key: str
    base_url: str = "https://brain-api.spokest.com"
    memory_key: str = "memories"

    class Config:
        arbitrary_types_allowed = True

    @property
    def memory_variables(self) -> List[str]:
        """Return the list of memory variable keys."""
        return [self.memory_key]

    async def load_memory_variables(
        self, inputs: Dict[str, Any]
    ) -> Dict[str, str]:
        """Recall relevant memories based on the current input.

        Args:
            inputs: The current chain inputs. Looks for 'input' or
                    'human_input' keys to form the recall query.

        Returns:
            A dict with the memory_key mapped to formatted memory text.
        """
        query = inputs.get("input", inputs.get("human_input", ""))
        if not query:
            return {self.memory_key: ""}

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}/v1/memory/recall",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={"query": query},
            )
            response.raise_for_status()
            data = response.json()

        memories = data.get("memories", [])
        if not memories:
            return {self.memory_key: ""}

        formatted = "\n".join(
            f"- {m.get('text', m.get('memory', ''))}" for m in memories
        )
        return {self.memory_key: formatted}

    async def save_context(
        self, inputs: Dict[str, Any], outputs: Dict[str, str]
    ) -> None:
        """Store the conversation turn as a memory.

        Args:
            inputs: The chain inputs (user message).
            outputs: The chain outputs (assistant response).
        """
        input_text = inputs.get("input", inputs.get("human_input", ""))
        output_text = outputs.get("output", outputs.get("response", ""))
        text = f"User: {input_text}\nAssistant: {output_text}"

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f"{self.base_url}/v1/memory/store",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={"text": text},
            )
            response.raise_for_status()

    async def clear(self) -> None:
        """Clear is not supported -- memories are permanent.

        Spokest Brain follows the principle that memories are never deleted.
        This method logs a warning and does nothing.
        """
        logger.warning(
            "clear() not supported -- Spokest memories are permanent. "
            "Memories are never deleted, only new ones are added."
        )
