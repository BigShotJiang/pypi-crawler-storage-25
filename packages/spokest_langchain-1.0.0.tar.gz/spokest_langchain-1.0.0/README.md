# spokest-langchain

LangChain memory integration for [Spokest Brain](https://spokest.com). Give your LangChain chains persistent, associative memory powered by the Spokest Brain API.

## Install

```bash
pip install spokest-langchain
```

## Usage

```python
from langchain_openai import ChatOpenAI
from langchain.chains import ConversationChain
from spokest_langchain import SpokestMemory

memory = SpokestMemory(
    api_key="sk-your-spokest-api-key",
    base_url="https://brain-api.spokest.com",  # optional, this is the default
)

llm = ChatOpenAI(model="gpt-4o")
chain = ConversationChain(llm=llm, memory=memory)

response = chain.invoke({"input": "What did we discuss about the product launch?"})
print(response["response"])
```

## Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `api_key` | (required) | Your Spokest Brain API key |
| `base_url` | `https://brain-api.spokest.com` | Brain API base URL |
| `memory_key` | `memories` | Key used in the chain's memory variables |

## How it works

- **`load_memory_variables`** -- Calls `/v1/memory/recall` with the current user input to retrieve relevant memories. Returns them formatted as a bulleted list under the configured `memory_key`.
- **`save_context`** -- Calls `/v1/memory/store` with the full conversation turn (user input + assistant output) after each chain invocation.
- **`clear`** -- Logs a warning. Spokest Brain memories are permanent by design and cannot be deleted.

## License

MIT
