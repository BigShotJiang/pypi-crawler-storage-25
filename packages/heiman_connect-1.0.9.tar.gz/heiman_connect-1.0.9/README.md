# Heiman Connect Library

Python library for communicating with Heiman smart home devices.

## Installation

```bash
pip install heiman-connect
```

## Usage

```python
import asyncio
from heimanconnect import HeimanHttpClient, HeimanCloudClient

async def main():
    # Initialize HTTP client with access token
    http_client = HeimanHttpClient(
        api_url="https://api.heiman.cn",
        access_token="your_access_token",
    )
    
    # Create cloud client
    cloud_client = HeimanCloudClient(http_client)
    
    # Get homes
    homes = await cloud_client.async_get_homes()
    
    # Get devices
    devices = await cloud_client.async_get_devices(home_id=homes[0].home_id)
    
    # Control device
    await cloud_client.async_control_device(
        device_id=device_id,
        property_identifier="Switch",
        value=True,
    )

asyncio.run(main())
```

## Features

- HTTP API client
- MQTT real-time communication
- Device management
- Property control
- Simplified authentication (bring your own token)

## License

MIT License
