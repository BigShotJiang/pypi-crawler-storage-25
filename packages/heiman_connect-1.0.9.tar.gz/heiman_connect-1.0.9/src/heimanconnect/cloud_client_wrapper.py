"""Cloud client wrapper with automatic token management.

This module provides a high-level wrapper around HeimanCloudClient that handles
OAuth2 token lifecycle, automatic token refresh, and connection management.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime, timedelta
from typing import Any, Awaitable, Callable

from .exceptions import (
    HeimanAuthError,
    HeimanConnectionError,
)
from .http_client import HeimanCloudClient, HeimanHttpClient
from .models import HeimanDevice
from .utils import process_device_detail

_LOGGER = logging.getLogger(__name__)


class HeimanCloudClientWrapper:
    """Heiman cloud client wrapper with automatic token management.
    
    This wrapper automatically handles OAuth2 token validation and refresh
    before each API call, eliminating the need for manual token management
    in the integration layer.
    
    Example usage:
        async def token_refresh_callback() -> str:
            # Your token refresh logic here
            return new_access_token
        
        wrapper = HeimanCloudClientWrapper(
            api_url="https://api.heiman.cn",
            initial_access_token="your_token",
            token_refresh_callback=token_refresh_callback,
        )
        
        # Token is automatically validated/refreshed before each call
        user_info = await wrapper.async_get_user_info()
    """

    def __init__(
        self,
        api_url: str,
        initial_access_token: str,
        token_refresh_callback: Callable[[], Awaitable[str]] | None = None,
        timeout: int = 30,
    ) -> None:
        """Initialize the cloud client wrapper.
        
        Args:
            api_url: Base API URL
            initial_access_token: Initial access token
            token_refresh_callback: Optional callback to refresh token when expired.
                                   Should return the new access token string.
            timeout: Request timeout in seconds (default: 30)
        """
        self._api_url = api_url
        self._access_token = initial_access_token
        self._token_refresh_callback = token_refresh_callback

        # Initialize HTTP and cloud clients
        self._http_client = HeimanHttpClient(
            api_url=api_url,
            access_token=initial_access_token,
            timeout=timeout,
        )
        self._cloud_client = HeimanCloudClient(http_client=self._http_client)

        self._closed = False
        _LOGGER.debug("Initialized HeimanCloudClientWrapper")

    @property
    def cloud_client(self) -> HeimanCloudClient:
        """Get the underlying cloud client.
        
        Returns:
            HeimanCloudClient instance
            
        Raises:
            HeimanConnectionError: If client is closed
        """
        if self._closed:
            raise HeimanConnectionError("Client has been closed")
        return self._cloud_client

    @property
    def http_client(self) -> HeimanHttpClient:
        """Get the underlying HTTP client.
        
        Returns:
            HeimanHttpClient instance
            
        Raises:
            HeimanConnectionError: If client is closed
        """
        if self._closed:
            raise HeimanConnectionError("Client has been closed")
        return self._http_client

    async def _ensure_token_valid(self) -> None:
        """Ensure access token is valid, refreshing if necessary.
        
        This method is called automatically before each API request.
        
        Raises:
            HeimanAuthError: If token refresh fails or no refresh callback available
        """
        if self._closed:
            raise HeimanConnectionError("Client has been closed")

        # If we have a refresh callback, use it to validate/refresh token
        if self._token_refresh_callback:
            try:
                new_token = await self._token_refresh_callback()
                if new_token and new_token != self._access_token:
                    # Update token in HTTP client
                    self._access_token = new_token
                    self._http_client.update_access_token(new_token)
                    _LOGGER.debug("Access token refreshed successfully")
            except Exception as err:
                _LOGGER.error("Failed to refresh token: %s", err)
                raise HeimanAuthError(
                    message=f"Token refresh failed: {err}",
                ) from err
        else:
            # No refresh callback, just verify token exists
            if not self._access_token:
                raise HeimanAuthError(message="No access token available")

    async def async_get_user_info(self):
        """Get current user information.
        
        Automatically ensures token is valid before making the request.
        
        Returns:
            HeimanUser object with user details
            
        Raises:
            HeimanAuthError: If authentication fails
            HeimanConnectionError: If network request fails
            HeimanApiError: If API request fails
        """
        await self._ensure_token_valid()
        return await self._cloud_client.async_get_user_info()

    async def async_get_homes(self):
        """Get list of homes for current user.
        
        Automatically ensures token is valid before making the request.
        
        Returns:
            List of HeimanHome objects
            
        Raises:
            HeimanAuthError: If authentication fails
            HeimanConnectionError: If network request fails
            HeimanApiError: If API request fails
        """
        await self._ensure_token_valid()
        return await self._cloud_client.async_get_homes()

    async def async_get_devices(
        self,
        home_id: str | None = None,
        page_number: int = 1,
        page_size: int = 100,
    ):
        """Get list of devices in specified home.
        
        Automatically ensures token is valid before making the request.
        
        Args:
            home_id: Home ID (uses current home_id if not specified)
            page_number: Page number for pagination
            page_size: Number of devices per page
            
        Returns:
            Dictionary mapping device_id to HeimanDevice objects
            
        Raises:
            HeimanAuthError: If authentication fails
            HeimanConnectionError: If network request fails
            HeimanApiError: If API request fails
        """
        await self._ensure_token_valid()
        return await self._cloud_client.async_get_devices(
            home_id=home_id,
            page_number=page_number,
            page_size=page_size,
        )

    async def async_get_device_properties(self, device_id: str):
        """Get device properties.
        
        Automatically ensures token is valid before making the request.
        
        Args:
            device_id: Device ID
            
        Returns:
            Device properties dictionary
            
        Raises:
            HeimanAuthError: If authentication fails
            HeimanConnectionError: If network request fails
            HeimanApiError: If API request fails
        """
        await self._ensure_token_valid()
        return await self._cloud_client.async_get_device_properties(device_id)

    async def _async_get_device_detail(self, device_id: str):
        """Get detailed device information including deriveMetadata.
        
        Automatically ensures token is valid before making the request.
        
        Args:
            device_id: Device ID
            
        Returns:
            Detailed device information dictionary or None if failed
            
        Raises:
            HeimanAuthError: If authentication fails
            HeimanConnectionError: If network request fails
            HeimanApiError: If API request fails
        """
        await self._ensure_token_valid()
        try:
            return await self._cloud_client._async_get_device_detail(device_id)  # noqa: SLF001
        except Exception:  # noqa: BLE001
            return None

    async def async_fetch_and_process_device_details(
        self,
        devices: dict[str, HeimanDevice],
        cache: dict[str, dict[str, Any] | None] | None = None,
        cache_ttl: int = 300,
        max_concurrent: int = 5,
    ) -> None:
        """Fetch and process device details with caching and concurrency control.
        
        This method handles:
        - Cache management (TTL-based invalidation)
        - Concurrent API requests with semaphore control
        - Processing of deriveMetadata to update device properties
        
        Args:
            devices: Dictionary of device_id to HeimanDevice objects
            cache: Optional cache dictionary for storing device details.
                  If None, no caching is used.
            cache_ttl: Cache time-to-live in seconds (default: 300 = 5 minutes)
            max_concurrent: Maximum concurrent API requests (default: 5)
        """
        if not devices:
            return
        
        now = datetime.now(UTC)
        cache_timestamp_attr = "_cache_timestamp"
        
        # Check if cache needs refresh
        cache_expired = False
        if cache is not None:
            cache_timestamp = getattr(cache, cache_timestamp_attr, None)
            cache_expired = (
                cache_timestamp is None
                or (now - cache_timestamp).total_seconds() > cache_ttl
            )
            
            # If cache expired, clear it
            if cache_expired:
                cache.clear()
                setattr(cache, cache_timestamp_attr, now)
        
        # Process cached device details first
        if cache is not None:
            for device_id, device in devices.items():
                device_detail = cache.get(device_id)
                if device_detail is not None:
                    process_device_detail(device, device_detail)
        
        # Identify devices that need detail fetching (not in cache)
        devices_to_fetch = [
            device_id
            for device_id in devices
            if cache is None or device_id not in cache
        ]
        
        if not devices_to_fetch:
            return
        
        # Create a semaphore to limit concurrent requests
        semaphore = asyncio.Semaphore(max_concurrent)
        
        async def fetch_device_detail(
            device_id: str,
        ) -> tuple[str, dict[str, Any] | None]:
            """Fetch device detail with concurrency control."""
            async with semaphore:
                try:
                    device_detail = await self._async_get_device_detail(device_id)
                except Exception as err:  # noqa: BLE001
                    _LOGGER.debug(
                        "Failed to get device details for %s: %s",
                        device_id,
                        err,
                    )
                    return device_id, None
                else:
                    return device_id, device_detail
        
        # Fetch all device details concurrently
        results = await asyncio.gather(
            *[fetch_device_detail(device_id) for device_id in devices_to_fetch],
            return_exceptions=False,
        )
        
        # Process results and update cache
        for device_id, device_detail in results:
            # Cache the result (including None for failed requests)
            if cache is not None:
                cache[device_id] = device_detail
            
            # Process the detail if available
            if device_detail is not None and device_id in devices:
                process_device_detail(devices[device_id], device_detail)

    async def async_control_device(self, device_id: str, property_id: str, value):
        """Control device via cloud API.
        
        Automatically ensures token is valid before making the request.
        
        Args:
            device_id: Device ID
            property_id: Property identifier
            value: New property value
            
        Returns:
            Control result
            
        Raises:
            HeimanAuthError: If authentication fails
            HeimanConnectionError: If network request fails
            HeimanApiError: If API request fails
        """
        await self._ensure_token_valid()
        return await self._cloud_client.async_control_device(
            device_id, property_id, value
        )

    async def close(self) -> None:
        """Close the client and release resources.
        
        This method should be called when the client is no longer needed
        to properly clean up HTTP sessions and other resources.
        """
        if self._closed:
            return

        _LOGGER.debug("Closing HeimanCloudClientWrapper")
        self._closed = True

        try:
            await self._http_client.close()
            _LOGGER.debug("HTTP client closed successfully")
        except Exception as err:  # noqa: BLE001
            _LOGGER.warning("Error closing HTTP client: %s", err)

    async def __aenter__(self) -> HeimanCloudClientWrapper:
        """Async context manager entry."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit."""
        await self.close()
