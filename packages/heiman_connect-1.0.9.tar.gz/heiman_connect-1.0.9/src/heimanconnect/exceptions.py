"""Exceptions for Heiman Connect library."""

from typing import Any, Optional


class HeimanException(Exception):
    """Base exception for all Heiman exceptions."""

    def __init__(
        self,
        message: str,
        error_code: Optional[str | int] = None,
        raw_response: Optional[dict] = None,
    ) -> None:
        """Initialize the exception."""
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.raw_response = raw_response

    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary."""
        return {
            "message": self.message,
            "error_code": self.error_code,
            "raw_response": self.raw_response,
        }


class HeimanAuthError(HeimanException):
    """Authentication error - maps to Home Assistant ConfigEntryAuthFailed."""

    pass


class HeimanConnectionError(HeimanException):
    """Network connection error - maps to Home Assistant UpdateFailed."""

    pass


class HeimanApiError(HeimanException):
    """API request error - maps to Home Assistant UpdateFailed."""

    pass


class HeimanMQTTError(HeimanException):
    """MQTT client error."""

    pass


class HeimanDeviceNotFoundError(HeimanException):
    """Device not found error."""

    pass


class HeimanTokenExpiredError(HeimanAuthError):
    """Token expired error - requires re-authentication."""

    pass


class HeimanInvalidCredentialsError(HeimanAuthError):
    """Invalid credentials error - requires re-authentication."""

    pass


class HeimanServerBusyError(HeimanApiError):
    """Server busy error - should retry."""

    pass
