"""Utility functions for Heiman Connect library."""

from __future__ import annotations

from typing import Any

from .models import DeviceProperty, HeimanDevice


def convert_dbm_to_level(dbm_value: float) -> str:
    """Convert numeric DBM value to signal strength level string.

    Args:
        dbm_value: Signal strength in dBm (negative number)

    Returns:
        Signal level string: "strong", "medium", "weak", or "very_weak"
    """
    # DBM values are typically negative numbers
    # Closer to 0 = stronger signal
    if dbm_value >= -50:
        return "strong"
    if dbm_value >= -65:
        return "medium"
    if dbm_value >= -75:
        return "weak"
    return "very_weak"


def process_device_info(device: HeimanDevice, device_info: dict[str, Any]) -> None:
    """Process DeviceINFO nested structure and update device properties.

    This function extracts MAC address, DBM (signal strength), DBM_Level,
    and IP address from the DeviceINFO object and updates the corresponding
    device properties.

    Args:
        device: HeimanDevice object to update
        device_info: DeviceINFO dictionary containing MAC, DBM, DBM_Level, IP
    """
    # Extract MAC address
    mac_value = device_info.get("MAC")
    if mac_value and "DeviceINFO_MAC" in device.properties:
        device.properties["DeviceINFO_MAC"].value = mac_value

    # Extract DBM (signal strength in dBm)
    dbm_value = device_info.get("DBM")
    if dbm_value is not None and "DeviceINFO_DBM" in device.properties:
        device.properties["DeviceINFO_DBM"].value = dbm_value

    # Extract DBM_Level (signal strength level)
    dbm_level_value = device_info.get("DBM_Level")
    numeric_dbm_value: float | int | None = None
    if isinstance(dbm_value, (int, float)) and not isinstance(dbm_value, bool):
        numeric_dbm_value = dbm_value

    # Convert numeric DBM to level string if DBM_Level not provided
    if dbm_level_value is None and numeric_dbm_value is not None:
        dbm_level_value = convert_dbm_to_level(numeric_dbm_value)

    if dbm_level_value is not None:
        # Update existing property or create if it doesn't exist
        if "DeviceINFO_DBM_Level" in device.properties:
            device.properties["DeviceINFO_DBM_Level"].value = dbm_level_value
        else:
            # Create the property if it doesn't exist
            dbm_property = device.properties.get("DeviceINFO_DBM")
            device.properties["DeviceINFO_DBM_Level"] = DeviceProperty(
                identifier="DeviceINFO_DBM_Level",
                name="DBM Level",
                value=dbm_level_value,
                readable=getattr(dbm_property, "readable", True),
                entity=getattr(dbm_property, "entity", "sensor"),
            )

    # Extract IP address
    ip_value = device_info.get("IP")
    if ip_value and "DeviceINFO_IP" in device.properties:
        device.properties["DeviceINFO_IP"].value = ip_value


def extract_firmware_version(device: HeimanDevice, device_detail: dict[str, Any] | None = None) -> None:
    """Extract firmware version from device data.

    This function checks multiple sources for firmware version information:
    1. Device raw_data firmwareInfo
    2. Device firmware_info attribute
    3. Device detail firmwareInfo (if provided)

    Args:
        device: HeimanDevice object to update
        device_detail: Optional device detail dictionary from API
    """
    # First check if device raw_data has firmwareInfo
    if hasattr(device, "raw_data") and device.raw_data:
        firmware_info = device.raw_data.get("firmwareInfo", {})
        if isinstance(firmware_info, dict) and "version" in firmware_info:
            device.firmware_version = firmware_info.get("version")
            return

    # Try to get firmware version from device's firmware_info attribute
    if hasattr(device, "firmware_info") and device.firmware_info:
        if (
            isinstance(device.firmware_info, dict)
            and "version" in device.firmware_info
        ):
            device.firmware_version = device.firmware_info.get("version")
            return

    # Try to get from device_detail if provided
    if device_detail:
        firmware_info = device_detail.get("firmwareInfo", {})
        if isinstance(firmware_info, dict) and "version" in firmware_info:
            device.firmware_version = firmware_info.get("version")


def process_device_detail(
    device: HeimanDevice, device_detail: dict[str, Any]
) -> None:
    """Process device detail and update properties.

    This function extracts firmware version and processes deriveMetadata
    to update device properties.

    Args:
        device: HeimanDevice object to update
        device_detail: Device detail dictionary from API
    """
    # Extract firmware version from firmwareInfo (if not retrieved earlier)
    if not device.firmware_version:
        extract_firmware_version(device, device_detail)

    # Extract property values from deriveMetadata and update device object
    if "deriveMetadata" in device_detail:
        try:
            metadata_str = device_detail.get("deriveMetadata", "")
            if metadata_str:
                # deriveMetadata is a JSON string that parses to a list of property objects
                import json

                metadata_list = json.loads(metadata_str)

                # Iterate through the list and update properties
                if isinstance(metadata_list, list):
                    for prop_item in metadata_list:
                        update_device_property_from_metadata(device, prop_item)
        except Exception:
            # Log error but don't raise - device should still be usable
            pass


def update_device_property_from_metadata(
    device: HeimanDevice, prop_item: dict[str, Any]
) -> None:
    """Update a single device property from deriveMetadata.

    This function handles special cases like DeviceINFO objects and RSSI
    signal strength conversion.

    Args:
        device: HeimanDevice object to update
        prop_item: Property item dictionary with 'property'/'id' and 'value' keys
    """
    prop_id = prop_item.get("property", "") or prop_item.get("id", "")
    prop_value = prop_item.get("value")

    if not prop_id or prop_value is None:
        return

    # Special handling for DeviceINFO object
    if prop_id == "DeviceINFO" and isinstance(prop_value, dict):
        process_device_info(device, prop_value)
    elif prop_id in device.properties:
        if prop_id == "RSSI":
            # Keep RSSI as numeric dBm value for sensor compatibility
            # Also create a separate DBM_Level property for signal strength display
            # Validate numeric type to avoid TypeError from string values
            numeric_prop_value: float | int | None = None
            if isinstance(prop_value, (int, float)) and not isinstance(
                prop_value, bool
            ):
                numeric_prop_value = prop_value

            device.properties[prop_id].value = (
                numeric_prop_value if numeric_prop_value is not None else prop_value
            )
            if numeric_prop_value is not None:
                dbm_level_value = convert_dbm_to_level(numeric_prop_value)
                if dbm_level_value is not None:
                    if "DeviceINFO_DBM_Level" in device.properties:
                        device.properties["DeviceINFO_DBM_Level"].value = dbm_level_value
        else:
            # Update regular property
            device.properties[prop_id].value = prop_value
