from __future__ import annotations

"""Simple end-to-end sailbox smoke test.

Usage:
    cd sdk/python
    export SAIL_MODE=prod  # optional; prod is also the default
    export SAIL_API_KEY=your_api_key_here
    uv run python examples/sailbox_smoke.py

You can generate a SAIL_API_KEY here: https://app.unkey.com/sail-research/apis/api_5XuHxk82XDqMSPAa/keys/ks_5XuHxpQQYsLp3omz
"""

import os
import sys

import sail
from sail._config import Config


def main() -> int:
    api_key = os.environ.get("SAIL_API_KEY", "")
    if not api_key:
        print("Set SAIL_API_KEY before running this script.", file=sys.stderr)
        return 2

    cfg = Config.from_env()

    print(f"Finding or minting app via API {cfg.api_url}...")
    app = sail.App.find(name="sailbox-smoke", mint_if_missing=True)

    print(f"Creating sailbox via scheduler {cfg.scheduler_url}...")
    sb = sail.Sailbox.create(
        app=app,
        image=sail.Image.debian_arm64,
        name="smoke-test",
        cpu=1,
        memory_mib=1024,
    )

    print("Sailbox ready:")
    print(f"  sailbox_id: {sb.sailbox_id}")
    print(f"  worker:     {sb.worker_address}")

    print("Running `echo hi`...")
    result = sb.exec("echo hi", timeout=5).wait()
    print(f"  stdout: {result.stdout!r}")
    print(f"  stderr: {result.stderr!r}")
    print(f"  code:   {result.returncode}")

    print("Running a failing command...")
    failed = sb.exec("echo boom >&2; exit 7", timeout=5).wait()
    print(f"  stdout: {failed.stdout!r}")
    print(f"  stderr: {failed.stderr!r}")
    print(f"  code:   {failed.returncode}")

    print("Running another successful command after failure...")
    recovered = sb.exec("echo still-ok", timeout=5).wait()
    print(f"  stdout: {recovered.stdout!r}")
    print(f"  stderr: {recovered.stderr!r}")
    print(f"  code:   {recovered.returncode}")

    print("Terminating sailbox...")
    sb.terminate()
    print("Terminated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
