from __future__ import annotations

from typing import List, Optional, Tuple

import grpc

from sail._config import Config
from sail.pb.imagebuilder.v1 import imagebuilder_pb2_grpc
from sail.pb.scheduler.v1 import scheduler_pb2_grpc


def open_grpc_channel(target: str) -> grpc.Channel:
    normalized = target.strip().lower()
    if normalized.startswith(("localhost:", "127.0.0.1:", "[::1]:")):
        return grpc.insecure_channel(target)
    return grpc.secure_channel(target, grpc.ssl_channel_credentials())


class Client:
    """Manages gRPC channels to the sailbox scheduler and imagebuilder."""

    _instance: Optional["Client"] = None

    def __init__(self, config: Optional[Config] = None) -> None:
        self._config = config or Config.from_env()
        self._scheduler_channel = open_grpc_channel(self._config.scheduler_url)
        self._scheduler_stub = scheduler_pb2_grpc.SchedulerServiceStub(
            self._scheduler_channel
        )
        self._imagebuilder_channel = open_grpc_channel(self._config.imagebuilder_url)
        self._imagebuilder_stub = imagebuilder_pb2_grpc.ImageBuilderStub(
            self._imagebuilder_channel
        )

    @classmethod
    def get(cls) -> "Client":
        """Return the singleton client, creating it on first call."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Close and discard the singleton (useful for tests)."""
        if cls._instance is not None:
            cls._instance.close()
            cls._instance = None

    @property
    def scheduler_stub(self) -> scheduler_pb2_grpc.SchedulerServiceStub:
        return self._scheduler_stub

    @property
    def imagebuilder_stub(self) -> imagebuilder_pb2_grpc.ImageBuilderStub:
        return self._imagebuilder_stub

    def metadata(self) -> List[Tuple[str, str]]:
        """Return gRPC call metadata with the authorization header."""
        return [("authorization", f"Bearer {self._config.api_key}")]

    def close(self) -> None:
        self._scheduler_channel.close()
        self._imagebuilder_channel.close()
