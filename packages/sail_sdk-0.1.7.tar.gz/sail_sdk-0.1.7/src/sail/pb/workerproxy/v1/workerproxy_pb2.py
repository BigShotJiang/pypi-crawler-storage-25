"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 31, 1, "", "workerproxy/v1/workerproxy.proto"
)
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n workerproxy/v1/workerproxy.proto\x12\x0eworkerproxy.v1"h\n\x12ExecSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x0c\n\x04argv\x18\x02 \x03(\t\x12\x17\n\x0ftimeout_seconds\x18\x03 \x01(\r\x12\x17\n\x0fidempotency_key\x18\x04 \x01(\t".\n\x13ExecSailboxResponse\x12\x17\n\x0fexec_request_id\x18\x01 \x01(\t"E\n\x16WaitSailboxExecRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x17\n\x0fexec_request_id\x18\x02 \x01(\t"\xe1\x01\n\x17WaitSailboxExecResponse\x12\x17\n\x0fexec_request_id\x18\x01 \x01(\t\x121\n\x06status\x18\x02 \x01(\x0e2!.workerproxy.v1.SailboxExecStatus\x12\x0e\n\x06stdout\x18\x03 \x01(\t\x12\x0e\n\x06stderr\x18\x04 \x01(\t\x12\x13\n\x0breturn_code\x18\x05 \x01(\x05\x12\x18\n\x10stdout_truncated\x18\x06 \x01(\x08\x12\x18\n\x10stderr_truncated\x18\x07 \x01(\x08\x12\x11\n\ttimed_out\x18\x08 \x01(\x08")\n\nHTTPHeader\x12\x0c\n\x04name\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t")\n\nQueryParam\x12\x0c\n\x04name\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t"\x7f\n\x08Listener\x12\x12\n\nguest_port\x18\x01 \x01(\r\x12\x12\n\npublic_url\x18\x02 \x01(\t\x12\x10\n\x08protocol\x18\x03 \x01(\t\x129\n\x0croute_status\x18\x04 \x01(\x0e2#.workerproxy.v1.ListenerRouteStatus"<\n\x12GetListenerRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nguest_port\x18\x02 \x01(\r"A\n\x13GetListenerResponse\x12*\n\x08listener\x18\x01 \x01(\x0b2\x18.workerproxy.v1.Listener"*\n\x14ListListenersRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"D\n\x15ListListenersResponse\x12+\n\tlisteners\x18\x01 \x03(\x0b2\x18.workerproxy.v1.Listener"\xc7\x03\n\x0eNetworkRequest\x12\x12\n\nrequest_id\x18\x01 \x01(\t\x12\x12\n\nsailbox_id\x18\x02 \x01(\t\x12\x0e\n\x06method\x18\x03 \x01(\t\x12\x0b\n\x03url\x18\x04 \x01(\t\x12*\n\x06params\x18\x05 \x03(\x0b2\x1a.workerproxy.v1.QueryParam\x12+\n\x07headers\x18\x06 \x03(\x0b2\x1a.workerproxy.v1.HTTPHeader\x12\x14\n\x0crequest_body\x18\x07 \x01(\x0c\x12\x17\n\x0ftimeout_seconds\x18\x08 \x01(\r\x12\x17\n\x0fdurability_mode\x18\t \x01(\t\x12\x17\n\x0fidempotency_key\x18\n \x01(\t\x124\n\x06status\x18\x0b \x01(\x0e2$.workerproxy.v1.NetworkRequestStatus\x12\x1c\n\x14response_status_code\x18\x0c \x01(\x05\x124\n\x10response_headers\x18\r \x03(\x0b2\x1a.workerproxy.v1.HTTPHeader\x12\x15\n\rresponse_body\x18\x0e \x01(\x0c\x12\x15\n\rerror_message\x18\x0f \x01(\t"\x88\x02\n\x1bCreateNetworkRequestRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x0e\n\x06method\x18\x02 \x01(\t\x12\x0b\n\x03url\x18\x03 \x01(\t\x12*\n\x06params\x18\x04 \x03(\x0b2\x1a.workerproxy.v1.QueryParam\x12+\n\x07headers\x18\x05 \x03(\x0b2\x1a.workerproxy.v1.HTTPHeader\x12\x14\n\x0crequest_body\x18\x06 \x01(\x0c\x12\x17\n\x0ftimeout_seconds\x18\x07 \x01(\r\x12\x17\n\x0fdurability_mode\x18\x08 \x01(\t\x12\x17\n\x0fidempotency_key\x18\t \x01(\t"O\n\x1cCreateNetworkRequestResponse\x12/\n\x07request\x18\x01 \x01(\x0b2\x1e.workerproxy.v1.NetworkRequest"B\n\x18GetNetworkRequestRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nrequest_id\x18\x02 \x01(\t"L\n\x19GetNetworkRequestResponse\x12/\n\x07request\x18\x01 \x01(\x0b2\x1e.workerproxy.v1.NetworkRequest"C\n\x19WaitNetworkRequestRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nrequest_id\x18\x02 \x01(\t"M\n\x1aWaitNetworkRequestResponse\x12/\n\x07request\x18\x01 \x01(\x0b2\x1e.workerproxy.v1.NetworkRequest"D\n\x1aRetryNetworkRequestRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nrequest_id\x18\x02 \x01(\t"N\n\x1bRetryNetworkRequestResponse\x12/\n\x07request\x18\x01 \x01(\x0b2\x1e.workerproxy.v1.NetworkRequest"E\n\x1bCancelNetworkRequestRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nrequest_id\x18\x02 \x01(\t"O\n\x1cCancelNetworkRequestResponse\x12/\n\x07request\x18\x01 \x01(\x0b2\x1e.workerproxy.v1.NetworkRequest")\n\x13CreateStreamRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"\x16\n\x14CreateStreamResponse"9\n\x10GetStreamRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x11\n\tstream_id\x18\x02 \x01(\t"\x13\n\x11GetStreamResponse"*\n\x14CreateWebhookRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"\x17\n\x15CreateWebhookResponse";\n\x11GetWebhookRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nwebhook_id\x18\x02 \x01(\t"\x14\n\x12GetWebhookResponse*\xe9\x02\n\x11SailboxExecStatus\x12#\n\x1fSAILBOX_EXEC_STATUS_UNSPECIFIED\x10\x00\x12\x1f\n\x1bSAILBOX_EXEC_STATUS_PENDING\x10\x01\x12\x1f\n\x1bSAILBOX_EXEC_STATUS_RUNNING\x10\x02\x12!\n\x1dSAILBOX_EXEC_STATUS_SUCCEEDED\x10\x03\x12\x1e\n\x1aSAILBOX_EXEC_STATUS_FAILED\x10\x04\x12!\n\x1dSAILBOX_EXEC_STATUS_TIMED_OUT\x10\x05\x12-\n)SAILBOX_EXEC_STATUS_INTERRUPTED_RETRYABLE\x10\x06\x123\n/SAILBOX_EXEC_STATUS_INTERRUPTED_UNSAFE_TO_RETRY\x10\x07\x12#\n\x1fSAILBOX_EXEC_STATUS_WORKER_LOST\x10\x08*\xcd\x01\n\x13ListenerRouteStatus\x12%\n!LISTENER_ROUTE_STATUS_UNSPECIFIED\x10\x00\x12!\n\x1dLISTENER_ROUTE_STATUS_PENDING\x10\x01\x12 \n\x1cLISTENER_ROUTE_STATUS_ACTIVE\x10\x02\x12#\n\x1fLISTENER_ROUTE_STATUS_RESTORING\x10\x03\x12%\n!LISTENER_ROUTE_STATUS_UNAVAILABLE\x10\x04*\xad\x02\n\x14NetworkRequestStatus\x12&\n"NETWORK_REQUEST_STATUS_UNSPECIFIED\x10\x00\x12"\n\x1eNETWORK_REQUEST_STATUS_PENDING\x10\x01\x12$\n NETWORK_REQUEST_STATUS_IN_FLIGHT\x10\x02\x12$\n NETWORK_REQUEST_STATUS_COMPLETED\x10\x03\x12,\n(NETWORK_REQUEST_STATUS_FAILED_DEFINITIVE\x10\x04\x12*\n&NETWORK_REQUEST_STATUS_OUTCOME_UNKNOWN\x10\x05\x12#\n\x1fNETWORK_REQUEST_STATUS_CANCELED\x10\x062\x93\n\n\x12WorkerProxyService\x12V\n\x0bExecSailbox\x12".workerproxy.v1.ExecSailboxRequest\x1a#.workerproxy.v1.ExecSailboxResponse\x12b\n\x0fWaitSailboxExec\x12&.workerproxy.v1.WaitSailboxExecRequest\x1a\'.workerproxy.v1.WaitSailboxExecResponse\x12q\n\x14CreateNetworkRequest\x12+.workerproxy.v1.CreateNetworkRequestRequest\x1a,.workerproxy.v1.CreateNetworkRequestResponse\x12h\n\x11GetNetworkRequest\x12(.workerproxy.v1.GetNetworkRequestRequest\x1a).workerproxy.v1.GetNetworkRequestResponse\x12k\n\x12WaitNetworkRequest\x12).workerproxy.v1.WaitNetworkRequestRequest\x1a*.workerproxy.v1.WaitNetworkRequestResponse\x12n\n\x13RetryNetworkRequest\x12*.workerproxy.v1.RetryNetworkRequestRequest\x1a+.workerproxy.v1.RetryNetworkRequestResponse\x12q\n\x14CancelNetworkRequest\x12+.workerproxy.v1.CancelNetworkRequestRequest\x1a,.workerproxy.v1.CancelNetworkRequestResponse\x12V\n\x0bGetListener\x12".workerproxy.v1.GetListenerRequest\x1a#.workerproxy.v1.GetListenerResponse\x12\\\n\rListListeners\x12$.workerproxy.v1.ListListenersRequest\x1a%.workerproxy.v1.ListListenersResponse\x12Y\n\x0cCreateStream\x12#.workerproxy.v1.CreateStreamRequest\x1a$.workerproxy.v1.CreateStreamResponse\x12P\n\tGetStream\x12 .workerproxy.v1.GetStreamRequest\x1a!.workerproxy.v1.GetStreamResponse\x12\\\n\rCreateWebhook\x12$.workerproxy.v1.CreateWebhookRequest\x1a%.workerproxy.v1.CreateWebhookResponse\x12S\n\nGetWebhook\x12!.workerproxy.v1.GetWebhookRequest\x1a".workerproxy.v1.GetWebhookResponseBKZIgithub.com/sailresearchco/sail/backend/internal/sailbox/workerproxy/pb;pbb\x06proto3'
)
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(
    DESCRIPTOR, "workerproxy.v1.workerproxy_pb2", _globals
)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals["DESCRIPTOR"]._loaded_options = None
    _globals["DESCRIPTOR"]._serialized_options = (
        b"ZIgithub.com/sailresearchco/sail/backend/internal/sailbox/workerproxy/pb;pb"
    )
    _globals["_SAILBOXEXECSTATUS"]._serialized_start = 2665
    _globals["_SAILBOXEXECSTATUS"]._serialized_end = 3026
    _globals["_LISTENERROUTESTATUS"]._serialized_start = 3029
    _globals["_LISTENERROUTESTATUS"]._serialized_end = 3234
    _globals["_NETWORKREQUESTSTATUS"]._serialized_start = 3237
    _globals["_NETWORKREQUESTSTATUS"]._serialized_end = 3538
    _globals["_EXECSAILBOXREQUEST"]._serialized_start = 52
    _globals["_EXECSAILBOXREQUEST"]._serialized_end = 156
    _globals["_EXECSAILBOXRESPONSE"]._serialized_start = 158
    _globals["_EXECSAILBOXRESPONSE"]._serialized_end = 204
    _globals["_WAITSAILBOXEXECREQUEST"]._serialized_start = 206
    _globals["_WAITSAILBOXEXECREQUEST"]._serialized_end = 275
    _globals["_WAITSAILBOXEXECRESPONSE"]._serialized_start = 278
    _globals["_WAITSAILBOXEXECRESPONSE"]._serialized_end = 503
    _globals["_HTTPHEADER"]._serialized_start = 505
    _globals["_HTTPHEADER"]._serialized_end = 546
    _globals["_QUERYPARAM"]._serialized_start = 548
    _globals["_QUERYPARAM"]._serialized_end = 589
    _globals["_LISTENER"]._serialized_start = 591
    _globals["_LISTENER"]._serialized_end = 718
    _globals["_GETLISTENERREQUEST"]._serialized_start = 720
    _globals["_GETLISTENERREQUEST"]._serialized_end = 780
    _globals["_GETLISTENERRESPONSE"]._serialized_start = 782
    _globals["_GETLISTENERRESPONSE"]._serialized_end = 847
    _globals["_LISTLISTENERSREQUEST"]._serialized_start = 849
    _globals["_LISTLISTENERSREQUEST"]._serialized_end = 891
    _globals["_LISTLISTENERSRESPONSE"]._serialized_start = 893
    _globals["_LISTLISTENERSRESPONSE"]._serialized_end = 961
    _globals["_NETWORKREQUEST"]._serialized_start = 964
    _globals["_NETWORKREQUEST"]._serialized_end = 1419
    _globals["_CREATENETWORKREQUESTREQUEST"]._serialized_start = 1422
    _globals["_CREATENETWORKREQUESTREQUEST"]._serialized_end = 1686
    _globals["_CREATENETWORKREQUESTRESPONSE"]._serialized_start = 1688
    _globals["_CREATENETWORKREQUESTRESPONSE"]._serialized_end = 1767
    _globals["_GETNETWORKREQUESTREQUEST"]._serialized_start = 1769
    _globals["_GETNETWORKREQUESTREQUEST"]._serialized_end = 1835
    _globals["_GETNETWORKREQUESTRESPONSE"]._serialized_start = 1837
    _globals["_GETNETWORKREQUESTRESPONSE"]._serialized_end = 1913
    _globals["_WAITNETWORKREQUESTREQUEST"]._serialized_start = 1915
    _globals["_WAITNETWORKREQUESTREQUEST"]._serialized_end = 1982
    _globals["_WAITNETWORKREQUESTRESPONSE"]._serialized_start = 1984
    _globals["_WAITNETWORKREQUESTRESPONSE"]._serialized_end = 2061
    _globals["_RETRYNETWORKREQUESTREQUEST"]._serialized_start = 2063
    _globals["_RETRYNETWORKREQUESTREQUEST"]._serialized_end = 2131
    _globals["_RETRYNETWORKREQUESTRESPONSE"]._serialized_start = 2133
    _globals["_RETRYNETWORKREQUESTRESPONSE"]._serialized_end = 2211
    _globals["_CANCELNETWORKREQUESTREQUEST"]._serialized_start = 2213
    _globals["_CANCELNETWORKREQUESTREQUEST"]._serialized_end = 2282
    _globals["_CANCELNETWORKREQUESTRESPONSE"]._serialized_start = 2284
    _globals["_CANCELNETWORKREQUESTRESPONSE"]._serialized_end = 2363
    _globals["_CREATESTREAMREQUEST"]._serialized_start = 2365
    _globals["_CREATESTREAMREQUEST"]._serialized_end = 2406
    _globals["_CREATESTREAMRESPONSE"]._serialized_start = 2408
    _globals["_CREATESTREAMRESPONSE"]._serialized_end = 2430
    _globals["_GETSTREAMREQUEST"]._serialized_start = 2432
    _globals["_GETSTREAMREQUEST"]._serialized_end = 2489
    _globals["_GETSTREAMRESPONSE"]._serialized_start = 2491
    _globals["_GETSTREAMRESPONSE"]._serialized_end = 2510
    _globals["_CREATEWEBHOOKREQUEST"]._serialized_start = 2512
    _globals["_CREATEWEBHOOKREQUEST"]._serialized_end = 2554
    _globals["_CREATEWEBHOOKRESPONSE"]._serialized_start = 2556
    _globals["_CREATEWEBHOOKRESPONSE"]._serialized_end = 2579
    _globals["_GETWEBHOOKREQUEST"]._serialized_start = 2581
    _globals["_GETWEBHOOKREQUEST"]._serialized_end = 2640
    _globals["_GETWEBHOOKRESPONSE"]._serialized_start = 2642
    _globals["_GETWEBHOOKRESPONSE"]._serialized_end = 2662
    _globals["_WORKERPROXYSERVICE"]._serialized_start = 3541
    _globals["_WORKERPROXYSERVICE"]._serialized_end = 4840
