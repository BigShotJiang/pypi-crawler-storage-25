"""Client and server classes corresponding to protobuf-defined services."""

import grpc
import warnings
from ...imagebuilder.v1 import (
    imagebuilder_pb2 as imagebuilder_dot_v1_dot_imagebuilder__pb2,
)

GRPC_GENERATED_VERSION = "1.80.0"
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower

    _version_not_supported = first_version_is_lower(
        GRPC_VERSION, GRPC_GENERATED_VERSION
    )
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(
        f"The grpc package installed is at version {GRPC_VERSION},"
        + " but the generated code in imagebuilder/v1/imagebuilder_pb2_grpc.py depends on"
        + f" grpcio>={GRPC_GENERATED_VERSION}."
        + f" Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}"
        + f" or downgrade your generated code using grpcio-tools<={GRPC_VERSION}."
    )


class ImageBuilderStub(object):
    """ImageBuilder is the customer-visible imagebuilder API for sailbox custom
    images. It is served by the imagebuilder-dispatcher.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.BuildImage = channel.unary_unary(
            "/imagebuilder.v1.ImageBuilder/BuildImage",
            request_serializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.BuildImageRequest.SerializeToString,
            response_deserializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.BuildImageResponse.FromString,
            _registered_method=True,
        )
        self.GetImageBuildStatus = channel.unary_unary(
            "/imagebuilder.v1.ImageBuilder/GetImageBuildStatus",
            request_serializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.GetImageBuildStatusRequest.SerializeToString,
            response_deserializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.GetImageBuildStatusResponse.FromString,
            _registered_method=True,
        )


class ImageBuilderServicer(object):
    """ImageBuilder is the customer-visible imagebuilder API for sailbox custom
    images. It is served by the imagebuilder-dispatcher.
    """

    def BuildImage(self, request, context):
        """BuildImage submits or resumes a custom image build and returns the current
        build state. Callers poll GetImageBuildStatus until the status reaches
        READY or FAILED.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def GetImageBuildStatus(self, request, context):
        """GetImageBuildStatus returns the latest build state for one image ID."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")


def add_ImageBuilderServicer_to_server(servicer, server):
    rpc_method_handlers = {
        "BuildImage": grpc.unary_unary_rpc_method_handler(
            servicer.BuildImage,
            request_deserializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.BuildImageRequest.FromString,
            response_serializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.BuildImageResponse.SerializeToString,
        ),
        "GetImageBuildStatus": grpc.unary_unary_rpc_method_handler(
            servicer.GetImageBuildStatus,
            request_deserializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.GetImageBuildStatusRequest.FromString,
            response_serializer=imagebuilder_dot_v1_dot_imagebuilder__pb2.GetImageBuildStatusResponse.SerializeToString,
        ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
        "imagebuilder.v1.ImageBuilder", rpc_method_handlers
    )
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers(
        "imagebuilder.v1.ImageBuilder", rpc_method_handlers
    )


class ImageBuilder(object):
    """ImageBuilder is the customer-visible imagebuilder API for sailbox custom
    images. It is served by the imagebuilder-dispatcher.
    """

    @staticmethod
    def BuildImage(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/imagebuilder.v1.ImageBuilder/BuildImage",
            imagebuilder_dot_v1_dot_imagebuilder__pb2.BuildImageRequest.SerializeToString,
            imagebuilder_dot_v1_dot_imagebuilder__pb2.BuildImageResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def GetImageBuildStatus(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/imagebuilder.v1.ImageBuilder/GetImageBuildStatus",
            imagebuilder_dot_v1_dot_imagebuilder__pb2.GetImageBuildStatusRequest.SerializeToString,
            imagebuilder_dot_v1_dot_imagebuilder__pb2.GetImageBuildStatusResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )
