"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 31, 1, "", "scheduler/v1/scheduler.proto"
)
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x1cscheduler/v1/scheduler.proto\x12\x0cscheduler.v1"\xca\x01\n\x14CreateSailboxRequest\x12\x0c\n\x04name\x18\x01 \x01(\t\x12\x0b\n\x03cpu\x18\x02 \x01(\r\x12\x12\n\nmemory_mib\x18\x03 \x01(\r\x12\x17\n\x0ftimeout_seconds\x18\x04 \x01(\r\x12\x0e\n\x06app_id\x18\x05 \x01(\t\x12&\n\x05image\x18\x06 \x01(\x0b2\x17.scheduler.v1.ImageSpec\x12\x15\n\ringress_ports\x18\x07 \x03(\r\x12\x1b\n\x13state_disk_size_gib\x18\x08 \x01(\r"?\n\x11BuildImageRequest\x12&\n\x05image\x18\x01 \x01(\x0b2\x17.scheduler.v1.ImageSpec:\x02\x18\x01"q\n\x12BuildImageResponse\x12\x10\n\x08image_id\x18\x01 \x01(\t\x12.\n\x06status\x18\x02 \x01(\x0e2\x1e.scheduler.v1.ImageBuildStatus\x12\x15\n\rerror_message\x18\x03 \x01(\t:\x02\x18\x01"2\n\x1aGetImageBuildStatusRequest\x12\x10\n\x08image_id\x18\x01 \x01(\t:\x02\x18\x01"z\n\x1bGetImageBuildStatusResponse\x12\x10\n\x08image_id\x18\x01 \x01(\t\x12.\n\x06status\x18\x02 \x01(\x0e2\x1e.scheduler.v1.ImageBuildStatus\x12\x15\n\rerror_message\x18\x03 \x01(\t:\x02\x18\x01"\xb3\x01\n\x15CreateSailboxResponse\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12+\n\x06status\x18\x02 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\r\n\x05vm_id\x18\x04 \x01(\t\x12\x15\n\rerror_message\x18\x05 \x01(\t\x12\x1b\n\x13exec_proxy_endpoint\x18\x06 \x01(\t"\xc3\x01\n\x1aCreateDaemonSailboxRequest\x123\n\x07sailbox\x18\x01 \x01(\x0b2".scheduler.v1.CreateSailboxRequest\x12\x0f\n\x07command\x18\x02 \x01(\t\x12\x0b\n\x03cwd\x18\x03 \x01(\t\x12)\n!checkpoint_poll_frequency_seconds\x18\x05 \x01(\r\x12\'\n\x1fmin_checkpoint_cooldown_seconds\x18\x06 \x01(\r"a\n\x1bCreateDaemonSailboxResponse\x124\n\x07sailbox\x18\x01 \x01(\x0b2#.scheduler.v1.CreateSailboxResponse\x12\x0c\n\x04pgid\x18\x03 \x01(\x05"-\n\x17GetSailboxStatusRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"\xb2\x01\n\x18GetSailboxStatusResponse\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12+\n\x06status\x18\x02 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\r\n\x05vm_id\x18\x04 \x01(\t\x12\x15\n\rerror_message\x18\x05 \x01(\t\x12\x17\n\x0fcreated_at_unix\x18\x06 \x01(\x03"-\n\x17TerminateSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"G\n\x18TerminateSailboxResponse\x12+\n\x06status\x18\x01 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus"A\n\x12StopSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x17\n\x0fwake_on_traffic\x18\x02 \x01(\x08"B\n\x13StopSailboxResponse\x12+\n\x06status\x18\x01 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus".\n\x18CheckpointSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"g\n\x19CheckpointSailboxResponse\x12+\n\x06status\x18\x01 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x1d\n\x15checkpoint_generation\x18\x02 \x01(\x03"*\n\x14ResumeSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t"\xdb\x01\n\x15ResumeSailboxResponse\x126\n\x0cresume_state\x18\x01 \x01(\x0e2 .scheduler.v1.SailboxResumeState\x12+\n\x06status\x18\x02 \x01(\x0e2\x1b.scheduler.v1.SailboxStatus\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\x1f\n\x17worker_internal_address\x18\x04 \x01(\t\x12\r\n\x05vm_id\x18\x05 \x01(\t\x12\x15\n\rerror_message\x18\x06 \x01(\t"\xf0\x01\n\x15RegisterWorkerRequest\x12\x11\n\tworker_id\x18\x01 \x01(\t\x12\x1f\n\x17worker_internal_address\x18\x02 \x01(\t\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\x13\n\x0btotal_vcpus\x18\x04 \x01(\r\x12\x18\n\x10total_memory_mib\x18\x05 \x01(\r\x125\n\x0carchitecture\x18\x06 \x01(\x0e2\x1f.scheduler.v1.ImageArchitecture\x12\x15\n\rinstance_type\x18\x07 \x01(\t\x12\x0e\n\x06region\x18\x08 \x01(\t"+\n\x16RegisterWorkerResponse\x12\x11\n\tworker_id\x18\x01 \x01(\t"+\n\x16HeartbeatWorkerRequest\x12\x11\n\tworker_id\x18\x01 \x01(\t"\x19\n\x17HeartbeatWorkerResponse",\n\x17DeregisterWorkerRequest\x12\x11\n\tworker_id\x18\x01 \x01(\t"\x1a\n\x18DeregisterWorkerResponse"\x83\x02\n\tImageSpec\x12\'\n\x04base\x18\x01 \x01(\x0e2\x17.scheduler.v1.BaseImageH\x00\x121\n\x0bbuild_steps\x18\x02 \x03(\x0b2\x1c.scheduler.v1.ImageBuildStep\x12-\n\x03env\x18\x03 \x03(\x0b2 .scheduler.v1.ImageSpec.EnvEntry\x125\n\x0carchitecture\x18\x04 \x01(\x0e2\x1f.scheduler.v1.ImageArchitecture\x1a*\n\x08EnvEntry\x12\x0b\n\x03key\x18\x01 \x01(\t\x12\r\n\x05value\x18\x02 \x01(\t:\x028\x01B\x08\n\x06source"\xb3\x01\n\x0eImageBuildStep\x123\n\x0bapt_install\x18\x01 \x01(\x0b2\x1c.scheduler.v1.PackageInstallH\x00\x123\n\x0bpip_install\x18\x02 \x01(\x0b2\x1c.scheduler.v1.PackageInstallH\x00\x12/\n\x0brun_command\x18\x03 \x01(\x0b2\x18.scheduler.v1.RunCommandH\x00B\x06\n\x04step""\n\x0ePackageInstall\x12\x10\n\x08packages\x18\x01 \x03(\t"\x1d\n\nRunCommand\x12\x0f\n\x07command\x18\x01 \x01(\t"\x13\n\x11GetVMStatsRequest"=\n\x12GetVMStatsResponse\x12\'\n\x08vm_stats\x18\x01 \x03(\x0b2\x15.scheduler.v1.VMStats"\xa2\x02\n\x07VMStats\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\r\n\x05vm_id\x18\x02 \x01(\t\x12\x16\n\x0eworker_address\x18\x03 \x01(\t\x12\x13\n\x0bcpu_time_ns\x18\x04 \x01(\x04\x12\x19\n\x11memory_used_bytes\x18\x05 \x01(\x04\x12\x1a\n\x12memory_total_bytes\x18\x06 \x01(\x04\x12\x17\n\x0frequested_vcpus\x18\x07 \x01(\r\x12\x1e\n\x16requested_memory_bytes\x18\x08 \x01(\x04\x12\x14\n\x0ctimestamp_ns\x18\t \x01(\x03\x12\x1d\n\x15state_disk_used_bytes\x18\n \x01(\x04\x12"\n\x1arequested_state_disk_bytes\x18\x0b \x01(\x04*\x8d\x03\n\rSailboxStatus\x12\x1e\n\x1aSAILBOX_STATUS_UNSPECIFIED\x10\x00\x12\x1a\n\x16SAILBOX_STATUS_PENDING\x10\x01\x12\x1b\n\x17SAILBOX_STATUS_STARTING\x10\x02\x12\x1a\n\x16SAILBOX_STATUS_RUNNING\x10\x03\x12\x1b\n\x17SAILBOX_STATUS_STOPPING\x10\x04\x12\x1a\n\x16SAILBOX_STATUS_STOPPED\x10\x05\x12\x19\n\x15SAILBOX_STATUS_FAILED\x10\x06\x12)\n%SAILBOX_STATUS_INTERRUPTED_RESTORABLE\x10\x07\x12\x1c\n\x18SAILBOX_STATUS_RESTORING\x10\x08\x12.\n*SAILBOX_STATUS_INTERRUPTED_UNSAFE_TO_RETRY\x10\t\x12\x1d\n\x19SAILBOX_STATUS_TERMINATED\x10\n\x12\x1b\n\x17SAILBOX_STATUS_SLEEPING\x10\x0b*\x81\x02\n\x12SailboxResumeState\x12$\n SAILBOX_RESUME_STATE_UNSPECIFIED\x10\x00\x12(\n$SAILBOX_RESUME_STATE_ALREADY_RUNNING\x10\x01\x12\'\n#SAILBOX_RESUME_STATE_RESUME_STARTED\x10\x02\x12!\n\x1dSAILBOX_RESUME_STATE_RESUMING\x10\x03\x12 \n\x1cSAILBOX_RESUME_STATE_RUNNING\x10\x04\x12-\n)SAILBOX_RESUME_STATE_TERMINAL_UNAVAILABLE\x10\x05*s\n\x11ImageArchitecture\x12"\n\x1eIMAGE_ARCHITECTURE_UNSPECIFIED\x10\x00\x12\x1c\n\x18IMAGE_ARCHITECTURE_AMD64\x10\x01\x12\x1c\n\x18IMAGE_ARCHITECTURE_ARM64\x10\x02*>\n\tBaseImage\x12\x1a\n\x16BASE_IMAGE_UNSPECIFIED\x10\x00\x12\x15\n\x11BASE_IMAGE_DEBIAN\x10\x01*\xb3\x01\n\x10ImageBuildStatus\x12"\n\x1eIMAGE_BUILD_STATUS_UNSPECIFIED\x10\x00\x12\x1d\n\x19IMAGE_BUILD_STATUS_QUEUED\x10\x01\x12\x1f\n\x1bIMAGE_BUILD_STATUS_BUILDING\x10\x02\x12\x1c\n\x18IMAGE_BUILD_STATUS_READY\x10\x03\x12\x1d\n\x19IMAGE_BUILD_STATUS_FAILED\x10\x042\xea\t\n\x10SchedulerService\x12O\n\nGetVMStats\x12\x1f.scheduler.v1.GetVMStatsRequest\x1a .scheduler.v1.GetVMStatsResponse\x12T\n\nBuildImage\x12\x1f.scheduler.v1.BuildImageRequest\x1a .scheduler.v1.BuildImageResponse"\x03\x88\x02\x01\x12o\n\x13GetImageBuildStatus\x12(.scheduler.v1.GetImageBuildStatusRequest\x1a).scheduler.v1.GetImageBuildStatusResponse"\x03\x88\x02\x01\x12X\n\rCreateSailbox\x12".scheduler.v1.CreateSailboxRequest\x1a#.scheduler.v1.CreateSailboxResponse\x12j\n\x13CreateDaemonSailbox\x12(.scheduler.v1.CreateDaemonSailboxRequest\x1a).scheduler.v1.CreateDaemonSailboxResponse\x12a\n\x10GetSailboxStatus\x12%.scheduler.v1.GetSailboxStatusRequest\x1a&.scheduler.v1.GetSailboxStatusResponse\x12a\n\x10TerminateSailbox\x12%.scheduler.v1.TerminateSailboxRequest\x1a&.scheduler.v1.TerminateSailboxResponse\x12R\n\x0bStopSailbox\x12 .scheduler.v1.StopSailboxRequest\x1a!.scheduler.v1.StopSailboxResponse\x12d\n\x11CheckpointSailbox\x12&.scheduler.v1.CheckpointSailboxRequest\x1a\'.scheduler.v1.CheckpointSailboxResponse\x12X\n\rResumeSailbox\x12".scheduler.v1.ResumeSailboxRequest\x1a#.scheduler.v1.ResumeSailboxResponse\x12[\n\x0eRegisterWorker\x12#.scheduler.v1.RegisterWorkerRequest\x1a$.scheduler.v1.RegisterWorkerResponse\x12^\n\x0fHeartbeatWorker\x12$.scheduler.v1.HeartbeatWorkerRequest\x1a%.scheduler.v1.HeartbeatWorkerResponse\x12a\n\x10DeregisterWorker\x12%.scheduler.v1.DeregisterWorkerRequest\x1a&.scheduler.v1.DeregisterWorkerResponseBIZGgithub.com/sailresearchco/sail/backend/internal/sailbox/scheduler/pb;pbb\x06proto3'
)
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(
    DESCRIPTOR, "scheduler.v1.scheduler_pb2", _globals
)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals["DESCRIPTOR"]._loaded_options = None
    _globals["DESCRIPTOR"]._serialized_options = (
        b"ZGgithub.com/sailresearchco/sail/backend/internal/sailbox/scheduler/pb;pb"
    )
    _globals["_BUILDIMAGEREQUEST"]._loaded_options = None
    _globals["_BUILDIMAGEREQUEST"]._serialized_options = b"\x18\x01"
    _globals["_BUILDIMAGERESPONSE"]._loaded_options = None
    _globals["_BUILDIMAGERESPONSE"]._serialized_options = b"\x18\x01"
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._loaded_options = None
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._serialized_options = b"\x18\x01"
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._loaded_options = None
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._serialized_options = b"\x18\x01"
    _globals["_IMAGESPEC_ENVENTRY"]._loaded_options = None
    _globals["_IMAGESPEC_ENVENTRY"]._serialized_options = b"8\x01"
    _globals["_SCHEDULERSERVICE"].methods_by_name["BuildImage"]._loaded_options = None
    _globals["_SCHEDULERSERVICE"].methods_by_name[
        "BuildImage"
    ]._serialized_options = b"\x88\x02\x01"
    _globals["_SCHEDULERSERVICE"].methods_by_name[
        "GetImageBuildStatus"
    ]._loaded_options = None
    _globals["_SCHEDULERSERVICE"].methods_by_name[
        "GetImageBuildStatus"
    ]._serialized_options = b"\x88\x02\x01"
    _globals["_SAILBOXSTATUS"]._serialized_start = 3311
    _globals["_SAILBOXSTATUS"]._serialized_end = 3708
    _globals["_SAILBOXRESUMESTATE"]._serialized_start = 3711
    _globals["_SAILBOXRESUMESTATE"]._serialized_end = 3968
    _globals["_IMAGEARCHITECTURE"]._serialized_start = 3970
    _globals["_IMAGEARCHITECTURE"]._serialized_end = 4085
    _globals["_BASEIMAGE"]._serialized_start = 4087
    _globals["_BASEIMAGE"]._serialized_end = 4149
    _globals["_IMAGEBUILDSTATUS"]._serialized_start = 4152
    _globals["_IMAGEBUILDSTATUS"]._serialized_end = 4331
    _globals["_CREATESAILBOXREQUEST"]._serialized_start = 47
    _globals["_CREATESAILBOXREQUEST"]._serialized_end = 249
    _globals["_BUILDIMAGEREQUEST"]._serialized_start = 251
    _globals["_BUILDIMAGEREQUEST"]._serialized_end = 314
    _globals["_BUILDIMAGERESPONSE"]._serialized_start = 316
    _globals["_BUILDIMAGERESPONSE"]._serialized_end = 429
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._serialized_start = 431
    _globals["_GETIMAGEBUILDSTATUSREQUEST"]._serialized_end = 481
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._serialized_start = 483
    _globals["_GETIMAGEBUILDSTATUSRESPONSE"]._serialized_end = 605
    _globals["_CREATESAILBOXRESPONSE"]._serialized_start = 608
    _globals["_CREATESAILBOXRESPONSE"]._serialized_end = 787
    _globals["_CREATEDAEMONSAILBOXREQUEST"]._serialized_start = 790
    _globals["_CREATEDAEMONSAILBOXREQUEST"]._serialized_end = 985
    _globals["_CREATEDAEMONSAILBOXRESPONSE"]._serialized_start = 987
    _globals["_CREATEDAEMONSAILBOXRESPONSE"]._serialized_end = 1084
    _globals["_GETSAILBOXSTATUSREQUEST"]._serialized_start = 1086
    _globals["_GETSAILBOXSTATUSREQUEST"]._serialized_end = 1131
    _globals["_GETSAILBOXSTATUSRESPONSE"]._serialized_start = 1134
    _globals["_GETSAILBOXSTATUSRESPONSE"]._serialized_end = 1312
    _globals["_TERMINATESAILBOXREQUEST"]._serialized_start = 1314
    _globals["_TERMINATESAILBOXREQUEST"]._serialized_end = 1359
    _globals["_TERMINATESAILBOXRESPONSE"]._serialized_start = 1361
    _globals["_TERMINATESAILBOXRESPONSE"]._serialized_end = 1432
    _globals["_STOPSAILBOXREQUEST"]._serialized_start = 1434
    _globals["_STOPSAILBOXREQUEST"]._serialized_end = 1499
    _globals["_STOPSAILBOXRESPONSE"]._serialized_start = 1501
    _globals["_STOPSAILBOXRESPONSE"]._serialized_end = 1567
    _globals["_CHECKPOINTSAILBOXREQUEST"]._serialized_start = 1569
    _globals["_CHECKPOINTSAILBOXREQUEST"]._serialized_end = 1615
    _globals["_CHECKPOINTSAILBOXRESPONSE"]._serialized_start = 1617
    _globals["_CHECKPOINTSAILBOXRESPONSE"]._serialized_end = 1720
    _globals["_RESUMESAILBOXREQUEST"]._serialized_start = 1722
    _globals["_RESUMESAILBOXREQUEST"]._serialized_end = 1764
    _globals["_RESUMESAILBOXRESPONSE"]._serialized_start = 1767
    _globals["_RESUMESAILBOXRESPONSE"]._serialized_end = 1986
    _globals["_REGISTERWORKERREQUEST"]._serialized_start = 1989
    _globals["_REGISTERWORKERREQUEST"]._serialized_end = 2229
    _globals["_REGISTERWORKERRESPONSE"]._serialized_start = 2231
    _globals["_REGISTERWORKERRESPONSE"]._serialized_end = 2274
    _globals["_HEARTBEATWORKERREQUEST"]._serialized_start = 2276
    _globals["_HEARTBEATWORKERREQUEST"]._serialized_end = 2319
    _globals["_HEARTBEATWORKERRESPONSE"]._serialized_start = 2321
    _globals["_HEARTBEATWORKERRESPONSE"]._serialized_end = 2346
    _globals["_DEREGISTERWORKERREQUEST"]._serialized_start = 2348
    _globals["_DEREGISTERWORKERREQUEST"]._serialized_end = 2392
    _globals["_DEREGISTERWORKERRESPONSE"]._serialized_start = 2394
    _globals["_DEREGISTERWORKERRESPONSE"]._serialized_end = 2420
    _globals["_IMAGESPEC"]._serialized_start = 2423
    _globals["_IMAGESPEC"]._serialized_end = 2682
    _globals["_IMAGESPEC_ENVENTRY"]._serialized_start = 2630
    _globals["_IMAGESPEC_ENVENTRY"]._serialized_end = 2672
    _globals["_IMAGEBUILDSTEP"]._serialized_start = 2685
    _globals["_IMAGEBUILDSTEP"]._serialized_end = 2864
    _globals["_PACKAGEINSTALL"]._serialized_start = 2866
    _globals["_PACKAGEINSTALL"]._serialized_end = 2900
    _globals["_RUNCOMMAND"]._serialized_start = 2902
    _globals["_RUNCOMMAND"]._serialized_end = 2931
    _globals["_GETVMSTATSREQUEST"]._serialized_start = 2933
    _globals["_GETVMSTATSREQUEST"]._serialized_end = 2952
    _globals["_GETVMSTATSRESPONSE"]._serialized_start = 2954
    _globals["_GETVMSTATSRESPONSE"]._serialized_end = 3015
    _globals["_VMSTATS"]._serialized_start = 3018
    _globals["_VMSTATS"]._serialized_end = 3308
    _globals["_SCHEDULERSERVICE"]._serialized_start = 4334
    _globals["_SCHEDULERSERVICE"]._serialized_end = 5592
