"""Client and server classes corresponding to protobuf-defined services."""

import grpc
import warnings
from ...scheduler.v1 import scheduler_pb2 as scheduler_dot_v1_dot_scheduler__pb2

GRPC_GENERATED_VERSION = "1.80.0"
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower

    _version_not_supported = first_version_is_lower(
        GRPC_VERSION, GRPC_GENERATED_VERSION
    )
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(
        f"The grpc package installed is at version {GRPC_VERSION},"
        + " but the generated code in scheduler/v1/scheduler_pb2_grpc.py depends on"
        + f" grpcio>={GRPC_GENERATED_VERSION}."
        + f" Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}"
        + f" or downgrade your generated code using grpcio-tools<={GRPC_VERSION}."
    )


class SchedulerServiceStub(object):
    """SchedulerService exposes cluster-level queries over the fleet of saild workers."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.GetVMStats = channel.unary_unary(
            "/scheduler.v1.SchedulerService/GetVMStats",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.GetVMStatsRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.GetVMStatsResponse.FromString,
            _registered_method=True,
        )
        self.BuildImage = channel.unary_unary(
            "/scheduler.v1.SchedulerService/BuildImage",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.BuildImageRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.BuildImageResponse.FromString,
            _registered_method=True,
        )
        self.GetImageBuildStatus = channel.unary_unary(
            "/scheduler.v1.SchedulerService/GetImageBuildStatus",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.GetImageBuildStatusRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.GetImageBuildStatusResponse.FromString,
            _registered_method=True,
        )
        self.CreateSailbox = channel.unary_unary(
            "/scheduler.v1.SchedulerService/CreateSailbox",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.CreateSailboxRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.CreateSailboxResponse.FromString,
            _registered_method=True,
        )
        self.CreateDaemonSailbox = channel.unary_unary(
            "/scheduler.v1.SchedulerService/CreateDaemonSailbox",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.CreateDaemonSailboxRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.CreateDaemonSailboxResponse.FromString,
            _registered_method=True,
        )
        self.GetSailboxStatus = channel.unary_unary(
            "/scheduler.v1.SchedulerService/GetSailboxStatus",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.GetSailboxStatusRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.GetSailboxStatusResponse.FromString,
            _registered_method=True,
        )
        self.TerminateSailbox = channel.unary_unary(
            "/scheduler.v1.SchedulerService/TerminateSailbox",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.TerminateSailboxRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.TerminateSailboxResponse.FromString,
            _registered_method=True,
        )
        self.StopSailbox = channel.unary_unary(
            "/scheduler.v1.SchedulerService/StopSailbox",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.StopSailboxRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.StopSailboxResponse.FromString,
            _registered_method=True,
        )
        self.CheckpointSailbox = channel.unary_unary(
            "/scheduler.v1.SchedulerService/CheckpointSailbox",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.CheckpointSailboxRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.CheckpointSailboxResponse.FromString,
            _registered_method=True,
        )
        self.ResumeSailbox = channel.unary_unary(
            "/scheduler.v1.SchedulerService/ResumeSailbox",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.ResumeSailboxRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.ResumeSailboxResponse.FromString,
            _registered_method=True,
        )
        self.RegisterWorker = channel.unary_unary(
            "/scheduler.v1.SchedulerService/RegisterWorker",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.RegisterWorkerRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.RegisterWorkerResponse.FromString,
            _registered_method=True,
        )
        self.HeartbeatWorker = channel.unary_unary(
            "/scheduler.v1.SchedulerService/HeartbeatWorker",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.HeartbeatWorkerRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.HeartbeatWorkerResponse.FromString,
            _registered_method=True,
        )
        self.DeregisterWorker = channel.unary_unary(
            "/scheduler.v1.SchedulerService/DeregisterWorker",
            request_serializer=scheduler_dot_v1_dot_scheduler__pb2.DeregisterWorkerRequest.SerializeToString,
            response_deserializer=scheduler_dot_v1_dot_scheduler__pb2.DeregisterWorkerResponse.FromString,
            _registered_method=True,
        )


class SchedulerServiceServicer(object):
    """SchedulerService exposes cluster-level queries over the fleet of saild workers."""

    def GetVMStats(self, request, context):
        """GetVMStats returns aggregated VM stats from all discovered workers."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def BuildImage(self, request, context):
        """Deprecated: use imagebuilder.v1.ImageBuilder.BuildImage."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def GetImageBuildStatus(self, request, context):
        """Deprecated: use imagebuilder.v1.ImageBuilder.GetImageBuildStatus."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def CreateSailbox(self, request, context):
        """CreateSailbox creates a VM on a suitable worker and returns once the
        sailbox is running or creation has failed.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def CreateDaemonSailbox(self, request, context):
        """CreateDaemonSailbox creates a sailbox and starts one managed long-running
        process before returning it to the caller.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def GetSailboxStatus(self, request, context):
        """GetSailboxStatus returns the current state of a sailbox."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def TerminateSailbox(self, request, context):
        """TerminateSailbox permanently destroys a sailbox so it cannot be restarted."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def StopSailbox(self, request, context):
        """StopSailbox checkpoints a running sailbox and powers it down so it can be
        resumed later. When wake_on_traffic is set, traffic-triggered ResumeSailbox
        calls may wake it; otherwise only explicit resume calls may restore it.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def CheckpointSailbox(self, request, context):
        """CheckpointSailbox durably snapshots a running sailbox without stopping it."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def ResumeSailbox(self, request, context):
        """ResumeSailbox ensures a restorable sailbox is runnable again and returns
        the active placement once it is available.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def RegisterWorker(self, request, context):
        """RegisterWorker registers or refreshes one saild worker in the scheduler's
        active worker registry.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def HeartbeatWorker(self, request, context):
        """HeartbeatWorker renews one already-registered saild worker lease."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def DeregisterWorker(self, request, context):
        """DeregisterWorker removes one saild worker from the scheduler's active
        worker registry.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")


def add_SchedulerServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
        "GetVMStats": grpc.unary_unary_rpc_method_handler(
            servicer.GetVMStats,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.GetVMStatsRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.GetVMStatsResponse.SerializeToString,
        ),
        "BuildImage": grpc.unary_unary_rpc_method_handler(
            servicer.BuildImage,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.BuildImageRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.BuildImageResponse.SerializeToString,
        ),
        "GetImageBuildStatus": grpc.unary_unary_rpc_method_handler(
            servicer.GetImageBuildStatus,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.GetImageBuildStatusRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.GetImageBuildStatusResponse.SerializeToString,
        ),
        "CreateSailbox": grpc.unary_unary_rpc_method_handler(
            servicer.CreateSailbox,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.CreateSailboxRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.CreateSailboxResponse.SerializeToString,
        ),
        "CreateDaemonSailbox": grpc.unary_unary_rpc_method_handler(
            servicer.CreateDaemonSailbox,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.CreateDaemonSailboxRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.CreateDaemonSailboxResponse.SerializeToString,
        ),
        "GetSailboxStatus": grpc.unary_unary_rpc_method_handler(
            servicer.GetSailboxStatus,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.GetSailboxStatusRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.GetSailboxStatusResponse.SerializeToString,
        ),
        "TerminateSailbox": grpc.unary_unary_rpc_method_handler(
            servicer.TerminateSailbox,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.TerminateSailboxRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.TerminateSailboxResponse.SerializeToString,
        ),
        "StopSailbox": grpc.unary_unary_rpc_method_handler(
            servicer.StopSailbox,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.StopSailboxRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.StopSailboxResponse.SerializeToString,
        ),
        "CheckpointSailbox": grpc.unary_unary_rpc_method_handler(
            servicer.CheckpointSailbox,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.CheckpointSailboxRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.CheckpointSailboxResponse.SerializeToString,
        ),
        "ResumeSailbox": grpc.unary_unary_rpc_method_handler(
            servicer.ResumeSailbox,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.ResumeSailboxRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.ResumeSailboxResponse.SerializeToString,
        ),
        "RegisterWorker": grpc.unary_unary_rpc_method_handler(
            servicer.RegisterWorker,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.RegisterWorkerRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.RegisterWorkerResponse.SerializeToString,
        ),
        "HeartbeatWorker": grpc.unary_unary_rpc_method_handler(
            servicer.HeartbeatWorker,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.HeartbeatWorkerRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.HeartbeatWorkerResponse.SerializeToString,
        ),
        "DeregisterWorker": grpc.unary_unary_rpc_method_handler(
            servicer.DeregisterWorker,
            request_deserializer=scheduler_dot_v1_dot_scheduler__pb2.DeregisterWorkerRequest.FromString,
            response_serializer=scheduler_dot_v1_dot_scheduler__pb2.DeregisterWorkerResponse.SerializeToString,
        ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
        "scheduler.v1.SchedulerService", rpc_method_handlers
    )
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers(
        "scheduler.v1.SchedulerService", rpc_method_handlers
    )


class SchedulerService(object):
    """SchedulerService exposes cluster-level queries over the fleet of saild workers."""

    @staticmethod
    def GetVMStats(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/GetVMStats",
            scheduler_dot_v1_dot_scheduler__pb2.GetVMStatsRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.GetVMStatsResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def BuildImage(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/BuildImage",
            scheduler_dot_v1_dot_scheduler__pb2.BuildImageRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.BuildImageResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def GetImageBuildStatus(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/GetImageBuildStatus",
            scheduler_dot_v1_dot_scheduler__pb2.GetImageBuildStatusRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.GetImageBuildStatusResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def CreateSailbox(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/CreateSailbox",
            scheduler_dot_v1_dot_scheduler__pb2.CreateSailboxRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.CreateSailboxResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def CreateDaemonSailbox(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/CreateDaemonSailbox",
            scheduler_dot_v1_dot_scheduler__pb2.CreateDaemonSailboxRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.CreateDaemonSailboxResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def GetSailboxStatus(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/GetSailboxStatus",
            scheduler_dot_v1_dot_scheduler__pb2.GetSailboxStatusRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.GetSailboxStatusResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def TerminateSailbox(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/TerminateSailbox",
            scheduler_dot_v1_dot_scheduler__pb2.TerminateSailboxRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.TerminateSailboxResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def StopSailbox(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/StopSailbox",
            scheduler_dot_v1_dot_scheduler__pb2.StopSailboxRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.StopSailboxResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def CheckpointSailbox(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/CheckpointSailbox",
            scheduler_dot_v1_dot_scheduler__pb2.CheckpointSailboxRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.CheckpointSailboxResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def ResumeSailbox(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/ResumeSailbox",
            scheduler_dot_v1_dot_scheduler__pb2.ResumeSailboxRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.ResumeSailboxResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def RegisterWorker(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/RegisterWorker",
            scheduler_dot_v1_dot_scheduler__pb2.RegisterWorkerRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.RegisterWorkerResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def HeartbeatWorker(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/HeartbeatWorker",
            scheduler_dot_v1_dot_scheduler__pb2.HeartbeatWorkerRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.HeartbeatWorkerResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def DeregisterWorker(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/scheduler.v1.SchedulerService/DeregisterWorker",
            scheduler_dot_v1_dot_scheduler__pb2.DeregisterWorkerRequest.SerializeToString,
            scheduler_dot_v1_dot_scheduler__pb2.DeregisterWorkerResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )
