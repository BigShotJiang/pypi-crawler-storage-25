"""Generated protocol buffer code."""

from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder

_runtime_version.ValidateProtobufRuntimeVersion(
    _runtime_version.Domain.PUBLIC, 6, 31, 1, "", "saild/v1/control.proto"
)
_sym_db = _symbol_database.Default()
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(
    b'\n\x16saild/v1/control.proto\x12\x08saild.v1"\x82\x01\n\x19StartFirecrackerVMRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nvcpu_count\x18\x02 \x01(\r\x12\x14\n\x0cmem_size_mib\x18\x03 \x01(\r\x12\x10\n\x08image_id\x18\x04 \x01(\t\x12\x15\n\rrootfs_s3_uri\x18\x05 \x01(\t"+\n\x1aStartFirecrackerVMResponse\x12\r\n\x05vm_id\x18\x01 \x01(\t")\n\x18StopFirecrackerVMRequest\x12\r\n\x05vm_id\x18\x01 \x01(\t"\x1b\n\x19StopFirecrackerVMResponse"\x9f\x01\n\x1eCheckpointFirecrackerVMRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x15\n\rcheckpoint_id\x18\x02 \x01(\t\x12\x1a\n\x12disk_upload_s3_uri\x18\x03 \x01(\t\x12\x19\n\x11mem_upload_s3_uri\x18\x04 \x01(\t\x12\x1b\n\x13state_upload_s3_uri\x18\x05 \x01(\t"{\n\x1fCheckpointFirecrackerVMResponse\x12\r\n\x05vm_id\x18\x01 \x01(\t\x12\x17\n\x0fdisk_size_bytes\x18\x02 \x01(\x04\x12\x16\n\x0emem_size_bytes\x18\x03 \x01(\x04\x12\x18\n\x10state_size_bytes\x18\x04 \x01(\x04"\xd1\x01\n)RestoreFirecrackerVMFromCheckpointRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x12\n\nvcpu_count\x18\x02 \x01(\r\x12\x14\n\x0cmem_size_mib\x18\x03 \x01(\r\x12\x10\n\x08image_id\x18\x04 \x01(\t\x12\x15\n\rrootfs_s3_uri\x18\x05 \x01(\t\x12\x13\n\x0bdisk_s3_uri\x18\x06 \x01(\t\x12\x12\n\nmem_s3_uri\x18\x07 \x01(\t\x12\x14\n\x0cstate_s3_uri\x18\x08 \x01(\t";\n*RestoreFirecrackerVMFromCheckpointResponse\x12\r\n\x05vm_id\x18\x01 \x01(\t"\x17\n\x15GetWorkerStateRequest"\xbd\x01\n\x16GetWorkerStateResponse\x12\x13\n\x0btotal_vcpus\x18\x01 \x01(\r\x12\x18\n\x10total_memory_mib\x18\x02 \x01(\r\x12\x17\n\x0fallocated_vcpus\x18\x03 \x01(\r\x12\x1c\n\x14allocated_memory_mib\x18\x04 \x01(\r\x12\x18\n\x10running_vm_count\x18\x05 \x01(\r\x12#\n\x08vm_stats\x18\x06 \x03(\x0b2\x11.saild.v1.VMStats"O\n\x12ExecSailboxRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x0c\n\x04argv\x18\x02 \x03(\t\x12\x17\n\x0ftimeout_seconds\x18\x03 \x01(\r".\n\x13ExecSailboxResponse\x12\x17\n\x0fexec_request_id\x18\x01 \x01(\t"E\n\x16WaitSailboxExecRequest\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\x17\n\x0fexec_request_id\x18\x02 \x01(\t"\xc8\x01\n\x17WaitSailboxExecResponse\x12\x17\n\x0fexec_request_id\x18\x01 \x01(\t\x12+\n\x06status\x18\x02 \x01(\x0e2\x1b.saild.v1.SailboxExecStatus\x12\x0e\n\x06stdout\x18\x03 \x01(\t\x12\x0e\n\x06stderr\x18\x04 \x01(\t\x12\x13\n\x0breturn_code\x18\x05 \x01(\x05\x12\x18\n\x10stdout_truncated\x18\x06 \x01(\x08\x12\x18\n\x10stderr_truncated\x18\x07 \x01(\x08"\x8c\x01\n\x07VMStats\x12\x12\n\nsailbox_id\x18\x01 \x01(\t\x12\r\n\x05vm_id\x18\x02 \x01(\t\x12\x11\n\tcpu_usage\x18\x03 \x01(\x01\x12\x19\n\x11memory_used_bytes\x18\x04 \x01(\x04\x12\x1a\n\x12memory_total_bytes\x18\x05 \x01(\x04\x12\x14\n\x0ctimestamp_ns\x18\x06 \x01(\x03*\xbf\x01\n\x11SailboxExecStatus\x12#\n\x1fSAILBOX_EXEC_STATUS_UNSPECIFIED\x10\x00\x12\x1f\n\x1bSAILBOX_EXEC_STATUS_RUNNING\x10\x01\x12!\n\x1dSAILBOX_EXEC_STATUS_SUCCEEDED\x10\x02\x12\x1e\n\x1aSAILBOX_EXEC_STATUS_FAILED\x10\x03\x12!\n\x1dSAILBOX_EXEC_STATUS_TIMED_OUT\x10\x042\xb1\x04\n\x19FirecrackerControlService\x12_\n\x12StartFirecrackerVM\x12#.saild.v1.StartFirecrackerVMRequest\x1a$.saild.v1.StartFirecrackerVMResponse\x12\\\n\x11StopFirecrackerVM\x12".saild.v1.StopFirecrackerVMRequest\x1a#.saild.v1.StopFirecrackerVMResponse\x12n\n\x17CheckpointFirecrackerVM\x12(.saild.v1.CheckpointFirecrackerVMRequest\x1a).saild.v1.CheckpointFirecrackerVMResponse\x12\x8f\x01\n"RestoreFirecrackerVMFromCheckpoint\x123.saild.v1.RestoreFirecrackerVMFromCheckpointRequest\x1a4.saild.v1.RestoreFirecrackerVMFromCheckpointResponse\x12S\n\x0eGetWorkerState\x12\x1f.saild.v1.GetWorkerStateRequest\x1a .saild.v1.GetWorkerStateResponse2\xb8\x01\n\x12SailboxExecService\x12J\n\x0bExecSailbox\x12\x1c.saild.v1.ExecSailboxRequest\x1a\x1d.saild.v1.ExecSailboxResponse\x12V\n\x0fWaitSailboxExec\x12 .saild.v1.WaitSailboxExecRequest\x1a!.saild.v1.WaitSailboxExecResponseBEZCgithub.com/sailresearchco/sail/backend/internal/sailbox/saild/pb;pbb\x06proto3'
)
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, "saild.v1.control_pb2", _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals["DESCRIPTOR"]._loaded_options = None
    _globals["DESCRIPTOR"]._serialized_options = (
        b"ZCgithub.com/sailresearchco/sail/backend/internal/sailbox/saild/pb;pb"
    )
    _globals["_SAILBOXEXECSTATUS"]._serialized_start = 1610
    _globals["_SAILBOXEXECSTATUS"]._serialized_end = 1801
    _globals["_STARTFIRECRACKERVMREQUEST"]._serialized_start = 37
    _globals["_STARTFIRECRACKERVMREQUEST"]._serialized_end = 167
    _globals["_STARTFIRECRACKERVMRESPONSE"]._serialized_start = 169
    _globals["_STARTFIRECRACKERVMRESPONSE"]._serialized_end = 212
    _globals["_STOPFIRECRACKERVMREQUEST"]._serialized_start = 214
    _globals["_STOPFIRECRACKERVMREQUEST"]._serialized_end = 255
    _globals["_STOPFIRECRACKERVMRESPONSE"]._serialized_start = 257
    _globals["_STOPFIRECRACKERVMRESPONSE"]._serialized_end = 284
    _globals["_CHECKPOINTFIRECRACKERVMREQUEST"]._serialized_start = 287
    _globals["_CHECKPOINTFIRECRACKERVMREQUEST"]._serialized_end = 446
    _globals["_CHECKPOINTFIRECRACKERVMRESPONSE"]._serialized_start = 448
    _globals["_CHECKPOINTFIRECRACKERVMRESPONSE"]._serialized_end = 571
    _globals["_RESTOREFIRECRACKERVMFROMCHECKPOINTREQUEST"]._serialized_start = 574
    _globals["_RESTOREFIRECRACKERVMFROMCHECKPOINTREQUEST"]._serialized_end = 783
    _globals["_RESTOREFIRECRACKERVMFROMCHECKPOINTRESPONSE"]._serialized_start = 785
    _globals["_RESTOREFIRECRACKERVMFROMCHECKPOINTRESPONSE"]._serialized_end = 844
    _globals["_GETWORKERSTATEREQUEST"]._serialized_start = 846
    _globals["_GETWORKERSTATEREQUEST"]._serialized_end = 869
    _globals["_GETWORKERSTATERESPONSE"]._serialized_start = 872
    _globals["_GETWORKERSTATERESPONSE"]._serialized_end = 1061
    _globals["_EXECSAILBOXREQUEST"]._serialized_start = 1063
    _globals["_EXECSAILBOXREQUEST"]._serialized_end = 1142
    _globals["_EXECSAILBOXRESPONSE"]._serialized_start = 1144
    _globals["_EXECSAILBOXRESPONSE"]._serialized_end = 1190
    _globals["_WAITSAILBOXEXECREQUEST"]._serialized_start = 1192
    _globals["_WAITSAILBOXEXECREQUEST"]._serialized_end = 1261
    _globals["_WAITSAILBOXEXECRESPONSE"]._serialized_start = 1264
    _globals["_WAITSAILBOXEXECRESPONSE"]._serialized_end = 1464
    _globals["_VMSTATS"]._serialized_start = 1467
    _globals["_VMSTATS"]._serialized_end = 1607
    _globals["_FIRECRACKERCONTROLSERVICE"]._serialized_start = 1804
    _globals["_FIRECRACKERCONTROLSERVICE"]._serialized_end = 2365
    _globals["_SAILBOXEXECSERVICE"]._serialized_start = 2368
    _globals["_SAILBOXEXECSERVICE"]._serialized_end = 2552
