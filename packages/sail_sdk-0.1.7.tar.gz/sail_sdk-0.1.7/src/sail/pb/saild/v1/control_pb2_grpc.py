"""Client and server classes corresponding to protobuf-defined services."""

import grpc
import warnings
from ...saild.v1 import control_pb2 as saild_dot_v1_dot_control__pb2

GRPC_GENERATED_VERSION = "1.80.0"
GRPC_VERSION = grpc.__version__
_version_not_supported = False
try:
    from grpc._utilities import first_version_is_lower

    _version_not_supported = first_version_is_lower(
        GRPC_VERSION, GRPC_GENERATED_VERSION
    )
except ImportError:
    _version_not_supported = True
if _version_not_supported:
    raise RuntimeError(
        f"The grpc package installed is at version {GRPC_VERSION},"
        + " but the generated code in saild/v1/control_pb2_grpc.py depends on"
        + f" grpcio>={GRPC_GENERATED_VERSION}."
        + f" Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}"
        + f" or downgrade your generated code using grpcio-tools<={GRPC_VERSION}."
    )


class FirecrackerControlServiceStub(object):
    """FirecrackerControlService exposes host-local Firecracker lifecycle hooks.
    This service is a skeleton; implementations will start/stop real VMs later.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.StartFirecrackerVM = channel.unary_unary(
            "/saild.v1.FirecrackerControlService/StartFirecrackerVM",
            request_serializer=saild_dot_v1_dot_control__pb2.StartFirecrackerVMRequest.SerializeToString,
            response_deserializer=saild_dot_v1_dot_control__pb2.StartFirecrackerVMResponse.FromString,
            _registered_method=True,
        )
        self.StopFirecrackerVM = channel.unary_unary(
            "/saild.v1.FirecrackerControlService/StopFirecrackerVM",
            request_serializer=saild_dot_v1_dot_control__pb2.StopFirecrackerVMRequest.SerializeToString,
            response_deserializer=saild_dot_v1_dot_control__pb2.StopFirecrackerVMResponse.FromString,
            _registered_method=True,
        )
        self.CheckpointFirecrackerVM = channel.unary_unary(
            "/saild.v1.FirecrackerControlService/CheckpointFirecrackerVM",
            request_serializer=saild_dot_v1_dot_control__pb2.CheckpointFirecrackerVMRequest.SerializeToString,
            response_deserializer=saild_dot_v1_dot_control__pb2.CheckpointFirecrackerVMResponse.FromString,
            _registered_method=True,
        )
        self.RestoreFirecrackerVMFromCheckpoint = channel.unary_unary(
            "/saild.v1.FirecrackerControlService/RestoreFirecrackerVMFromCheckpoint",
            request_serializer=saild_dot_v1_dot_control__pb2.RestoreFirecrackerVMFromCheckpointRequest.SerializeToString,
            response_deserializer=saild_dot_v1_dot_control__pb2.RestoreFirecrackerVMFromCheckpointResponse.FromString,
            _registered_method=True,
        )
        self.GetWorkerState = channel.unary_unary(
            "/saild.v1.FirecrackerControlService/GetWorkerState",
            request_serializer=saild_dot_v1_dot_control__pb2.GetWorkerStateRequest.SerializeToString,
            response_deserializer=saild_dot_v1_dot_control__pb2.GetWorkerStateResponse.FromString,
            _registered_method=True,
        )


class FirecrackerControlServiceServicer(object):
    """FirecrackerControlService exposes host-local Firecracker lifecycle hooks.
    This service is a skeleton; implementations will start/stop real VMs later.
    """

    def StartFirecrackerVM(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def StopFirecrackerVM(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def CheckpointFirecrackerVM(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def RestoreFirecrackerVMFromCheckpoint(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def GetWorkerState(self, request, context):
        """GetWorkerState returns the scheduler-facing host snapshot plus per-VM
        resource usage for all VMs on this host. Called by the scheduler every second.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")


def add_FirecrackerControlServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
        "StartFirecrackerVM": grpc.unary_unary_rpc_method_handler(
            servicer.StartFirecrackerVM,
            request_deserializer=saild_dot_v1_dot_control__pb2.StartFirecrackerVMRequest.FromString,
            response_serializer=saild_dot_v1_dot_control__pb2.StartFirecrackerVMResponse.SerializeToString,
        ),
        "StopFirecrackerVM": grpc.unary_unary_rpc_method_handler(
            servicer.StopFirecrackerVM,
            request_deserializer=saild_dot_v1_dot_control__pb2.StopFirecrackerVMRequest.FromString,
            response_serializer=saild_dot_v1_dot_control__pb2.StopFirecrackerVMResponse.SerializeToString,
        ),
        "CheckpointFirecrackerVM": grpc.unary_unary_rpc_method_handler(
            servicer.CheckpointFirecrackerVM,
            request_deserializer=saild_dot_v1_dot_control__pb2.CheckpointFirecrackerVMRequest.FromString,
            response_serializer=saild_dot_v1_dot_control__pb2.CheckpointFirecrackerVMResponse.SerializeToString,
        ),
        "RestoreFirecrackerVMFromCheckpoint": grpc.unary_unary_rpc_method_handler(
            servicer.RestoreFirecrackerVMFromCheckpoint,
            request_deserializer=saild_dot_v1_dot_control__pb2.RestoreFirecrackerVMFromCheckpointRequest.FromString,
            response_serializer=saild_dot_v1_dot_control__pb2.RestoreFirecrackerVMFromCheckpointResponse.SerializeToString,
        ),
        "GetWorkerState": grpc.unary_unary_rpc_method_handler(
            servicer.GetWorkerState,
            request_deserializer=saild_dot_v1_dot_control__pb2.GetWorkerStateRequest.FromString,
            response_serializer=saild_dot_v1_dot_control__pb2.GetWorkerStateResponse.SerializeToString,
        ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
        "saild.v1.FirecrackerControlService", rpc_method_handlers
    )
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers(
        "saild.v1.FirecrackerControlService", rpc_method_handlers
    )


class FirecrackerControlService(object):
    """FirecrackerControlService exposes host-local Firecracker lifecycle hooks.
    This service is a skeleton; implementations will start/stop real VMs later.
    """

    @staticmethod
    def StartFirecrackerVM(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/saild.v1.FirecrackerControlService/StartFirecrackerVM",
            saild_dot_v1_dot_control__pb2.StartFirecrackerVMRequest.SerializeToString,
            saild_dot_v1_dot_control__pb2.StartFirecrackerVMResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def StopFirecrackerVM(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/saild.v1.FirecrackerControlService/StopFirecrackerVM",
            saild_dot_v1_dot_control__pb2.StopFirecrackerVMRequest.SerializeToString,
            saild_dot_v1_dot_control__pb2.StopFirecrackerVMResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def CheckpointFirecrackerVM(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/saild.v1.FirecrackerControlService/CheckpointFirecrackerVM",
            saild_dot_v1_dot_control__pb2.CheckpointFirecrackerVMRequest.SerializeToString,
            saild_dot_v1_dot_control__pb2.CheckpointFirecrackerVMResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def RestoreFirecrackerVMFromCheckpoint(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/saild.v1.FirecrackerControlService/RestoreFirecrackerVMFromCheckpoint",
            saild_dot_v1_dot_control__pb2.RestoreFirecrackerVMFromCheckpointRequest.SerializeToString,
            saild_dot_v1_dot_control__pb2.RestoreFirecrackerVMFromCheckpointResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def GetWorkerState(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/saild.v1.FirecrackerControlService/GetWorkerState",
            saild_dot_v1_dot_control__pb2.GetWorkerStateRequest.SerializeToString,
            saild_dot_v1_dot_control__pb2.GetWorkerStateResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )


class SailboxExecServiceStub(object):
    """SailboxExecService exposes direct client->worker command execution for
    sailboxes already assigned to this worker.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.ExecSailbox = channel.unary_unary(
            "/saild.v1.SailboxExecService/ExecSailbox",
            request_serializer=saild_dot_v1_dot_control__pb2.ExecSailboxRequest.SerializeToString,
            response_deserializer=saild_dot_v1_dot_control__pb2.ExecSailboxResponse.FromString,
            _registered_method=True,
        )
        self.WaitSailboxExec = channel.unary_unary(
            "/saild.v1.SailboxExecService/WaitSailboxExec",
            request_serializer=saild_dot_v1_dot_control__pb2.WaitSailboxExecRequest.SerializeToString,
            response_deserializer=saild_dot_v1_dot_control__pb2.WaitSailboxExecResponse.FromString,
            _registered_method=True,
        )


class SailboxExecServiceServicer(object):
    """SailboxExecService exposes direct client->worker command execution for
    sailboxes already assigned to this worker.
    """

    def ExecSailbox(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")

    def WaitSailboxExec(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details("Method not implemented!")
        raise NotImplementedError("Method not implemented!")


def add_SailboxExecServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
        "ExecSailbox": grpc.unary_unary_rpc_method_handler(
            servicer.ExecSailbox,
            request_deserializer=saild_dot_v1_dot_control__pb2.ExecSailboxRequest.FromString,
            response_serializer=saild_dot_v1_dot_control__pb2.ExecSailboxResponse.SerializeToString,
        ),
        "WaitSailboxExec": grpc.unary_unary_rpc_method_handler(
            servicer.WaitSailboxExec,
            request_deserializer=saild_dot_v1_dot_control__pb2.WaitSailboxExecRequest.FromString,
            response_serializer=saild_dot_v1_dot_control__pb2.WaitSailboxExecResponse.SerializeToString,
        ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
        "saild.v1.SailboxExecService", rpc_method_handlers
    )
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers(
        "saild.v1.SailboxExecService", rpc_method_handlers
    )


class SailboxExecService(object):
    """SailboxExecService exposes direct client->worker command execution for
    sailboxes already assigned to this worker.
    """

    @staticmethod
    def ExecSailbox(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/saild.v1.SailboxExecService/ExecSailbox",
            saild_dot_v1_dot_control__pb2.ExecSailboxRequest.SerializeToString,
            saild_dot_v1_dot_control__pb2.ExecSailboxResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )

    @staticmethod
    def WaitSailboxExec(
        request,
        target,
        options=(),
        channel_credentials=None,
        call_credentials=None,
        insecure=False,
        compression=None,
        wait_for_ready=None,
        timeout=None,
        metadata=None,
    ):
        return grpc.experimental.unary_unary(
            request,
            target,
            "/saild.v1.SailboxExecService/WaitSailboxExec",
            saild_dot_v1_dot_control__pb2.WaitSailboxExecRequest.SerializeToString,
            saild_dot_v1_dot_control__pb2.WaitSailboxExecResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True,
        )
