from __future__ import annotations

import json
import shlex
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import grpc

from sail._client import Client, open_grpc_channel
from sail.errors import (
    SailboxCreationError,
    SailboxExecAlreadyRunningError,
    SailboxExecutionError,
    SailboxExecRequestNotFoundError,
    SailboxTerminatedError,
    SailboxWorkerLostError,
)
from sail.image import ImageDefinition
from sail.pb.scheduler.v1 import scheduler_pb2
from sail.pb.workerproxy.v1 import workerproxy_pb2, workerproxy_pb2_grpc

MIN_SAILBOX_MEMORY_MIB = 1024
MAX_SAILBOX_MEMORY_MIB = 64 * 1024
DEFAULT_SAILBOX_DISK_GIB = 8
MAX_SAILBOX_DISK_GIB = 64
# 22 = ssh; 10000 = guest agent
RESERVED_INGRESS_PORTS = {22, 10000}
EXEC_TRANSIENT_RETRY_TIMEOUT_SECONDS = 30.0
EXEC_TRANSIENT_RETRY_INITIAL_DELAY_SECONDS = 0.2
EXEC_TRANSIENT_RETRY_MAX_DELAY_SECONDS = 2.0


@dataclass(frozen=True)
class SailboxExecResult:
    stdout: str
    stderr: str
    returncode: int


@dataclass(frozen=True)
class SailboxResponse:
    status_code: int
    headers: Dict[str, str]
    content: bytes

    @property
    def text(self) -> str:
        return self.content.decode("utf-8", errors="replace")

    def json(self) -> Any:
        return json.loads(self.text)


@dataclass(frozen=True)
class SailboxRequest:
    sailbox_id: str
    request_id: str
    exec_endpoint: str
    status: str
    response: Optional["SailboxResponse"] = None
    error_message: str = ""

    @property
    def id(self) -> str:
        return self.request_id

    def _apply_update(self, updated: SailboxRequest) -> SailboxRequest:
        object.__setattr__(self, "status", updated.status)
        object.__setattr__(self, "response", updated.response)
        object.__setattr__(self, "error_message", updated.error_message)
        return self

    def refresh(self) -> SailboxRequest:
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.GetNetworkRequest(
                    workerproxy_pb2.GetNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )

    def wait(self, timeout: Optional[float] = None) -> SailboxRequest:
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.WaitNetworkRequest(
                    workerproxy_pb2.WaitNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                    timeout=timeout,
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )

    def cancel(self) -> SailboxRequest:
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.CancelNetworkRequest(
                    workerproxy_pb2.CancelNetworkRequestRequest(
                        sailbox_id=self.sailbox_id,
                        request_id=self.request_id,
                    ),
                    metadata=Client.get().metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return self._apply_update(
            _sailbox_request_from_proto(
                resp.request,
                exec_endpoint=self.exec_endpoint,
            )
        )


@dataclass(frozen=True)
class SailboxListener:
    sailbox_id: str
    port: int
    url: str
    protocol: str
    route_status: str
    _exec_endpoint: str = field(default="", repr=False, compare=False)

    def status(self) -> "SailboxListener":
        if not self._exec_endpoint:
            raise SailboxExecutionError("listener status cannot be fetched")
        client = Client.get()
        try:
            with open_grpc_channel(self._exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.GetListener(
                    workerproxy_pb2.GetListenerRequest(
                        sailbox_id=self.sailbox_id,
                        guest_port=self.port,
                    ),
                    metadata=client.metadata(),
                )
        except grpc.RpcError as exc:
            raise _map_listener_rpc_error(self.sailbox_id, self.port, exc) from exc
        return _listener_from_proto(
            client,
            self.sailbox_id,
            self._exec_endpoint,
            resp.listener,
        )

    def wait(
        self,
        timeout: float = 60.0,
        poll_interval: float = 1.0,
    ) -> "SailboxListener":
        if timeout <= 0:
            raise ValueError("timeout must be positive")
        if poll_interval <= 0:
            raise ValueError("poll_interval must be positive")

        deadline = time.monotonic() + timeout
        listener = self
        last_error = ""
        while True:
            if listener.route_status == "LISTENER_ROUTE_STATUS_ACTIVE":
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(
                        "listener "
                        f"{listener.sailbox_id}:{listener.port} did not become "
                        "reachable "
                        f"within {timeout} seconds; last status was "
                        f"{listener.route_status}"
                    )
                is_open, last_error = _listener_url_is_open(
                    listener.url,
                    timeout=remaining,
                )
                if is_open:
                    return listener
            else:
                last_error = listener.route_status

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                detail = f"; last error was {last_error}" if last_error else ""
                raise TimeoutError(
                    "listener "
                    f"{listener.sailbox_id}:{listener.port} did not become "
                    "reachable "
                    f"within {timeout} seconds; last status was "
                    f"{listener.route_status}"
                    f"{detail}"
                )
            time.sleep(min(poll_interval, remaining))
            listener = listener.status()


@dataclass(frozen=True)
class SailboxExecRequest:
    sailbox_id: str
    exec_request_id: str
    exec_endpoint: str
    background: bool = False
    idempotency_key: str = ""

    def wait(
        self, *, retry_timeout: float = EXEC_TRANSIENT_RETRY_TIMEOUT_SECONDS
    ) -> SailboxExecResult:
        """Wait for the exec request to complete.

        For foreground execs this waits for the command itself to finish.
        For background execs this waits only for the detached launcher shell to
        succeed or fail; it does not wait for the long-lived background process.

        Retrying wait is safe because the request already has a durable
        exec_request_id. Retrying initial exec submission is only safe when the
        request has an idempotency key, which Sailbox.exec adds by default.
        """
        deadline: Optional[float] = None
        delay = EXEC_TRANSIENT_RETRY_INITIAL_DELAY_SECONDS
        while True:
            try:
                with open_grpc_channel(self.exec_endpoint) as channel:
                    stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                    resp = stub.WaitSailboxExec(
                        workerproxy_pb2.WaitSailboxExecRequest(
                            sailbox_id=self.sailbox_id,
                            exec_request_id=self.exec_request_id,
                        ),
                        metadata=Client.get().metadata(),
                    )
                break
            except grpc.RpcError as exc:
                if deadline is None:
                    deadline = _retry_deadline(retry_timeout)
                if not _should_retry_transient_exec_rpc(exc, deadline):
                    raise _map_exec_rpc_error(exc) from exc
                delay = _sleep_before_retry(delay, deadline)
        if resp.status == workerproxy_pb2.SAILBOX_EXEC_STATUS_WORKER_LOST:
            raise SailboxWorkerLostError(
                resp.stderr or "assigned worker was lost; call resume() and retry"
            )
        return SailboxExecResult(
            stdout=resp.stdout,
            stderr=resp.stderr,
            returncode=resp.return_code,
        )


from sail.app import App  # noqa: E402


@dataclass(frozen=True)
class Sailbox:
    """A sandbox instance on the Sail platform.

    Identifiers on this type:

    - ``sailbox_id`` is the stable Sail control-plane identifier for the
      sandbox. This is the main external ID and the one used for follow-up
      operations like terminate/status lookup.
    - ``worker_address`` is the scheduler's internal address for the worker
      currently hosting the sailbox. It is operational metadata, not a
      client-facing endpoint.
    - ``exec_endpoint`` is the client-reachable worker-proxy endpoint for exec
      requests.

    In practice, callers should treat ``sailbox_id`` as the primary ID. The
    other fields are useful to surface for debugging, but they are not the
    durable external handle for the resource.
    """

    sailbox_id: str
    name: str
    status: str
    worker_address: str
    exec_endpoint: str

    @classmethod
    def create(
        cls,
        *,
        image: ImageDefinition,
        app: App,
        name: str,
        memory_mib: int = 1024,
        cpu: int = 1,
        ingress_ports: Optional[List[int]] = None,
        disk_gib: int = DEFAULT_SAILBOX_DISK_GIB,
    ) -> Sailbox:
        """Create a new sailbox.

        Sends a synchronous CreateSailbox RPC that returns once the VM is
        running or creation has failed.
        """
        if not isinstance(image, ImageDefinition):
            raise TypeError("image must be a sail.Image value")
        _validate_sailbox_size(memory_mib=memory_mib, cpu=cpu, disk_gib=disk_gib)
        _validate_ingress_ports(ingress_ports or [])

        client = Client.get()
        try:
            resp = client.scheduler_stub.CreateSailbox(
                scheduler_pb2.CreateSailboxRequest(
                    app_id=app.id,
                    name=name,
                    cpu=cpu,
                    memory_mib=memory_mib,
                    image=image.to_proto(),
                    ingress_ports=ingress_ports or [],
                    state_disk_size_gib=disk_gib,
                ),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc

        if resp.status == scheduler_pb2.SAILBOX_STATUS_FAILED:
            raise SailboxCreationError(f"Sailbox creation failed: {resp.error_message}")
        if resp.status != scheduler_pb2.SAILBOX_STATUS_RUNNING:
            raise SailboxCreationError(
                f"Sailbox creation returned unexpected status: {resp.status}"
            )

        return cls(
            sailbox_id=resp.sailbox_id,
            name=name,
            status="running",
            worker_address=resp.worker_address,
            exec_endpoint=resp.exec_proxy_endpoint,
        )

    @classmethod
    def create_daemon(
        cls,
        *,
        image: ImageDefinition,
        app: App,
        name: str,
        command: str,
        checkpoint_poll_frequency_s: int = 5,
        min_checkpoint_cooldown_s: int = 30,
        cwd: str = "/",
        memory_mib: int = 1024,
        cpu: int = 1,
        ingress_ports: Optional[List[int]] = None,
        disk_gib: int = DEFAULT_SAILBOX_DISK_GIB,
    ) -> DaemonSailbox:
        """Create a sailbox with one managed long-running process.

        Daemon sailboxes intentionally disable public exec after the daemon is
        registered. The platform still treats the VM as a normal sailbox, but
        checkpoint/restore lifecycle hooks know how to pause, resume, and clean
        daemon-owned sockets around VM snapshots.
        """
        if not command or not command.strip():
            raise ValueError("command must be non-empty")
        if checkpoint_poll_frequency_s <= 0:
            raise ValueError("checkpoint_poll_frequency_s must be greater than 0")
        if min_checkpoint_cooldown_s <= 0:
            raise ValueError("min_checkpoint_cooldown_s must be greater than 0")
        _validate_sailbox_size(memory_mib=memory_mib, cpu=cpu, disk_gib=disk_gib)
        _validate_ingress_ports(ingress_ports or [])

        client = Client.get()
        try:
            resp = client.scheduler_stub.CreateDaemonSailbox(
                scheduler_pb2.CreateDaemonSailboxRequest(
                    sailbox=scheduler_pb2.CreateSailboxRequest(
                        app_id=app.id,
                        name=name,
                        cpu=cpu,
                        memory_mib=memory_mib,
                        image=image.to_proto(),
                        ingress_ports=ingress_ports or [],
                        state_disk_size_gib=disk_gib,
                    ),
                    command=command,
                    cwd=cwd or "/",
                    checkpoint_poll_frequency_seconds=checkpoint_poll_frequency_s,
                    min_checkpoint_cooldown_seconds=min_checkpoint_cooldown_s,
                ),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc
        if resp.sailbox.status == scheduler_pb2.SAILBOX_STATUS_FAILED:
            raise SailboxCreationError(
                f"Sailbox creation failed: {resp.sailbox.error_message}"
            )
        if resp.sailbox.status != scheduler_pb2.SAILBOX_STATUS_RUNNING:
            raise SailboxCreationError(
                f"CreateDaemonSailbox returned unexpected status: {resp.sailbox.status}"
            )

        return DaemonSailbox(
            sailbox_id=resp.sailbox.sailbox_id,
            name=name,
            status="running",
            worker_address=resp.sailbox.worker_address,
            exec_endpoint=resp.sailbox.exec_proxy_endpoint,
            daemon_command=command,
            daemon_pgid=resp.pgid,
        )

    def terminate(self) -> None:
        """Permanently terminate this sailbox."""
        client = Client.get()
        try:
            resp = client.scheduler_stub.TerminateSailbox(
                scheduler_pb2.TerminateSailboxRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            code = exc.code()
            details = exc.details() or ""
            if code == grpc.StatusCode.NOT_FOUND:
                return
            if code == grpc.StatusCode.FAILED_PRECONDITION and "TERMINATED" in details:
                return
            raise
        if resp.status == scheduler_pb2.SAILBOX_STATUS_TERMINATED:
            return

    def pause(self) -> None:
        """Checkpoint and pause this sailbox until it is explicitly resumed."""
        self._stop(
            wake_on_traffic=False,
            expected_status=scheduler_pb2.SAILBOX_STATUS_STOPPED,
        )

    def sleep(self) -> None:
        """Checkpoint and sleep this sailbox until traffic or explicit resume wakes it."""
        self._stop(
            wake_on_traffic=True,
            expected_status=scheduler_pb2.SAILBOX_STATUS_SLEEPING,
        )

    def _stop(self, *, wake_on_traffic: bool, expected_status: int) -> None:
        client = Client.get()
        try:
            resp = client.scheduler_stub.StopSailbox(
                scheduler_pb2.StopSailboxRequest(
                    sailbox_id=self.sailbox_id,
                    wake_on_traffic=wake_on_traffic,
                ),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc
        if resp.status != expected_status:
            raise SailboxCreationError(
                f"StopSailbox returned unexpected status: {resp.status}"
            )
        object.__setattr__(self, "status", _local_status_from_proto(expected_status))
        object.__setattr__(self, "worker_address", "")

    def checkpoint(self) -> None:
        """Durably checkpoint this running sailbox without stopping it."""
        client = Client.get()
        try:
            resp = client.scheduler_stub.CheckpointSailbox(
                scheduler_pb2.CheckpointSailboxRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc
        if resp.status != scheduler_pb2.SAILBOX_STATUS_RUNNING:
            raise SailboxCreationError(
                f"CheckpointSailbox returned unexpected status: {resp.status}"
            )

    def resume(self) -> Sailbox:
        """Resume this sailbox through scheduler."""
        client = Client.get()
        try:
            resp = client.scheduler_stub.ResumeSailbox(
                scheduler_pb2.ResumeSailboxRequest(sailbox_id=self.sailbox_id),
                metadata=client.metadata(),
            )
        except grpc.RpcError as exc:
            raise SailboxCreationError(exc.details() or exc.code().name) from exc
        if resp.resume_state == scheduler_pb2.SAILBOX_RESUME_STATE_TERMINAL_UNAVAILABLE:
            raise SailboxCreationError(
                resp.error_message or "sailbox cannot be resumed"
            )
        if resp.status != scheduler_pb2.SAILBOX_STATUS_RUNNING:
            raise SailboxCreationError(
                f"ResumeSailbox returned unexpected status: {resp.status}"
            )
        # Sailbox is a frozen dataclass, so in-place refreshes must bypass normal
        # attribute assignment.
        object.__setattr__(self, "status", "running")
        object.__setattr__(
            self,
            "worker_address",
            resp.worker_internal_address or resp.worker_address,
        )
        return self

    def request(
        self,
        method: str,
        url: str,
        *,
        params: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        data: Optional[Union[bytes, str]] = None,
        json: Optional[Any] = None,
        timeout: Optional[int] = None,
        durability: str = "tracked",
        idempotency_key: Optional[str] = None,
    ) -> SailboxRequest:
        if not method:
            raise ValueError("method must be non-empty")
        if not url:
            raise ValueError("url must be non-empty")
        if not idempotency_key or not idempotency_key.strip():
            raise ValueError("idempotency_key must be non-empty")
        if data is not None and json is not None:
            raise ValueError("data and json are mutually exclusive")

        body = b""
        request_headers = dict(headers or {})
        if json is not None:
            body = _json_dumps_bytes(json)
            request_headers.setdefault("Content-Type", "application/json")
        elif isinstance(data, str):
            body = data.encode("utf-8")
        elif data is not None:
            body = data

        client = Client.get()
        with open_grpc_channel(self.exec_endpoint) as channel:
            stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
            resp = stub.CreateNetworkRequest(
                workerproxy_pb2.CreateNetworkRequestRequest(
                    sailbox_id=self.sailbox_id,
                    method=method,
                    url=url,
                    params=[
                        workerproxy_pb2.QueryParam(name=name, value=value)
                        for name, value in (params or {}).items()
                    ],
                    headers=[
                        workerproxy_pb2.HTTPHeader(name=name, value=value)
                        for name, value in request_headers.items()
                    ],
                    request_body=body,
                    timeout_seconds=timeout or 30,
                    durability_mode=durability,
                    idempotency_key=idempotency_key or "",
                ),
                metadata=client.metadata(),
            )
        return _sailbox_request_from_proto(
            resp.request,
            exec_endpoint=self.exec_endpoint,
        )

    def listener(self, port: int) -> SailboxListener:
        client = Client.get()
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.GetListener(
                    workerproxy_pb2.GetListenerRequest(
                        sailbox_id=self.sailbox_id,
                        guest_port=port,
                    ),
                    metadata=client.metadata(),
                )
        except grpc.RpcError as exc:
            raise _map_listener_rpc_error(self.sailbox_id, port, exc) from exc
        return _listener_from_proto(
            client,
            self.sailbox_id,
            self.exec_endpoint,
            resp.listener,
        )

    def listeners(self) -> list[SailboxListener]:
        client = Client.get()
        try:
            with open_grpc_channel(self.exec_endpoint) as channel:
                stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                resp = stub.ListListeners(
                    workerproxy_pb2.ListListenersRequest(sailbox_id=self.sailbox_id),
                    metadata=client.metadata(),
                )
        except grpc.RpcError as exc:
            raise SailboxExecutionError(exc.details() or exc.code().name) from exc
        return [
            _listener_from_proto(
                client,
                self.sailbox_id,
                self.exec_endpoint,
                listener,
            )
            for listener in resp.listeners
        ]

    def stream(self, *args, **kwargs):
        raise NotImplementedError(
            "stream support is reserved for a future resumable session API"
        )

    def webhook(self, *args, **kwargs):
        raise NotImplementedError(
            "webhook support is reserved for a future stable inbound delivery API"
        )

    def exec(
        self,
        command: str,
        *,
        timeout: Optional[int] = None,
        background: bool = False,
        idempotency_key: Optional[str] = None,
        retry_timeout: float = EXEC_TRANSIENT_RETRY_TIMEOUT_SECONDS,
    ) -> SailboxExecRequest:
        """Run a shell command directly on the owning worker."""
        if not command:
            raise ValueError("command must be non-empty")
        if timeout is not None and timeout <= 0:
            raise ValueError("timeout must be greater than 0")
        if self.status == "paused":
            raise SailboxExecutionError("sailbox is paused. call resume() before exec")

        if background:
            command = (
                f"nohup /bin/sh -lc {shlex.quote(command)} "
                "</dev/null >/dev/null 2>&1 &"
            )
        idempotency_key = _exec_idempotency_key(idempotency_key)

        # TODO: Consider renaming timeout to expected_runtime if we later need
        # a separate transport timeout distinct from the command runtime budget.
        deadline = _retry_deadline(retry_timeout)
        delay = EXEC_TRANSIENT_RETRY_INITIAL_DELAY_SECONDS
        while True:
            try:
                with open_grpc_channel(self.exec_endpoint) as channel:
                    stub = workerproxy_pb2_grpc.WorkerProxyServiceStub(channel)
                    resp = stub.ExecSailbox(
                        workerproxy_pb2.ExecSailboxRequest(
                            sailbox_id=self.sailbox_id,
                            argv=["/bin/sh", "-lc", command],
                            timeout_seconds=timeout or 0,
                            idempotency_key=idempotency_key,
                        ),
                        metadata=Client.get().metadata(),
                    )
                break
            except grpc.RpcError as exc:
                if not _should_retry_transient_exec_rpc(exc, deadline):
                    raise _map_exec_rpc_error(exc) from exc
                delay = _sleep_before_retry(delay, deadline)
        return SailboxExecRequest(
            sailbox_id=self.sailbox_id,
            exec_request_id=resp.exec_request_id,
            exec_endpoint=self.exec_endpoint,
            background=background,
            idempotency_key=idempotency_key,
        )


@dataclass(frozen=True)
class DaemonSailbox(Sailbox):
    daemon_command: str = ""
    daemon_pgid: int = 0

    def exec(
        self,
        command: str,
        *,
        timeout: Optional[int] = None,
        background: bool = False,
    ) -> SailboxExecRequest:
        raise SailboxExecutionError(
            "daemon sailboxes do not allow exec after the daemon is created"
        )


def _map_exec_rpc_error(exc: grpc.RpcError) -> SailboxExecutionError:
    details = exc.details() or "unknown sailbox exec error"
    code = exc.code()

    if code == grpc.StatusCode.FAILED_PRECONDITION and "already running" in details:
        return SailboxExecAlreadyRunningError(details)
    if code == grpc.StatusCode.NOT_FOUND:
        if "exec request" in details:
            return SailboxExecRequestNotFoundError(details)
        return SailboxTerminatedError(
            f"{details}; this is likely because this Sailbox is no longer running"
        )
    return SailboxExecutionError(f"{code.name}: {details}")


def _map_listener_rpc_error(
    sailbox_id: str, port: int, exc: grpc.RpcError
) -> SailboxExecutionError:
    if exc.code() == grpc.StatusCode.NOT_FOUND:
        return SailboxExecutionError(
            f"listener {sailbox_id}:{port} not found; pass ingress_ports=[{port}] "
            "when creating the Sailbox to expose this port"
        )
    return SailboxExecutionError(exc.details() or exc.code().name)


def _exec_idempotency_key(value: Optional[str]) -> str:
    if value is None:
        return f"exec_{uuid.uuid4()}"
    if not value.strip():
        raise ValueError("idempotency_key must be non-empty")
    return value.strip()


def _retry_deadline(retry_timeout: Optional[float]) -> Optional[float]:
    if retry_timeout is None:
        return None
    if retry_timeout <= 0:
        return time.monotonic()
    return time.monotonic() + retry_timeout


def _should_retry_transient_exec_rpc(
    exc: grpc.RpcError, deadline: Optional[float]
) -> bool:
    if deadline is not None and time.monotonic() >= deadline:
        return False
    code = exc.code()
    if code in (grpc.StatusCode.UNAVAILABLE, grpc.StatusCode.DEADLINE_EXCEEDED):
        return True
    details = (exc.details() or "").lower()
    if code == grpc.StatusCode.UNKNOWN and any(
        fragment in details
        for fragment in (
            "endpoint closing",
            "connection reset",
            "socket closed",
            "transport is closing",
        )
    ):
        return True
    return False


def _sleep_before_retry(delay: float, deadline: Optional[float]) -> float:
    sleep_for = min(delay, EXEC_TRANSIENT_RETRY_MAX_DELAY_SECONDS)
    if deadline is not None:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return delay
        sleep_for = min(sleep_for, remaining)
    time.sleep(max(0.0, sleep_for))
    return min(delay * 2, EXEC_TRANSIENT_RETRY_MAX_DELAY_SECONDS)


def _json_dumps_bytes(value: Any) -> bytes:
    return json.dumps(value, separators=(",", ":"), sort_keys=True).encode("utf-8")


def _validate_sailbox_size(*, memory_mib: int, cpu: int, disk_gib: int) -> None:
    if cpu <= 0:
        raise ValueError("cpu must be greater than 0")
    if memory_mib < MIN_SAILBOX_MEMORY_MIB:
        raise ValueError(f"memory_mib must be at least {MIN_SAILBOX_MEMORY_MIB}")
    if memory_mib > MAX_SAILBOX_MEMORY_MIB:
        raise ValueError(f"memory_mib must be at most {MAX_SAILBOX_MEMORY_MIB}")
    if disk_gib <= 0:
        raise ValueError("disk_gib must be greater than 0")
    if disk_gib > MAX_SAILBOX_DISK_GIB:
        raise ValueError(f"disk_gib must be at most {MAX_SAILBOX_DISK_GIB}")


def _validate_ingress_ports(ports: List[int]) -> None:
    seen = set()
    for port in ports:
        if port <= 0 or port > 65535:
            raise ValueError("ingress_ports must be between 1 and 65535")
        if port in RESERVED_INGRESS_PORTS:
            raise ValueError(f"ingress_ports contains reserved port {port}")
        if port in seen:
            raise ValueError("ingress_ports must be unique")
        seen.add(port)


def _sailbox_request_from_proto(
    request: workerproxy_pb2.NetworkRequest,
    *,
    exec_endpoint: str,
) -> SailboxRequest:
    response = None
    if request.status == workerproxy_pb2.NETWORK_REQUEST_STATUS_COMPLETED:
        response = SailboxResponse(
            status_code=request.response_status_code,
            headers={header.name: header.value for header in request.response_headers},
            content=request.response_body,
        )
    return SailboxRequest(
        sailbox_id=request.sailbox_id,
        request_id=request.request_id,
        exec_endpoint=exec_endpoint,
        status=workerproxy_pb2.NetworkRequestStatus.Name(request.status),
        response=response,
        error_message=request.error_message,
    )


def _listener_url(client: Client, sailbox_id: str, port: int, public_url: str) -> str:
    if public_url:
        return public_url
    ingress_url = client._config.sailbox_ingress_url.rstrip("/")
    if not ingress_url:
        return ""
    return f"{ingress_url}/_sailbox/{sailbox_id}/{port}"


def _local_status_from_proto(status: int) -> str:
    if status == scheduler_pb2.SAILBOX_STATUS_RUNNING:
        return "running"
    if status == scheduler_pb2.SAILBOX_STATUS_STOPPED:
        return "paused"
    if status == scheduler_pb2.SAILBOX_STATUS_SLEEPING:
        return "sleeping"
    if status == scheduler_pb2.SAILBOX_STATUS_TERMINATED:
        return "terminated"
    return (
        scheduler_pb2.SailboxStatus.Name(status).removeprefix("SAILBOX_STATUS_").lower()
    )


def _listener_from_proto(
    client: Client,
    sailbox_id: str,
    exec_endpoint: str,
    listener,
) -> SailboxListener:
    return SailboxListener(
        sailbox_id=sailbox_id,
        port=listener.guest_port,
        url=_listener_url(client, sailbox_id, listener.guest_port, listener.public_url),
        protocol=listener.protocol,
        route_status=workerproxy_pb2.ListenerRouteStatus.Name(listener.route_status),
        _exec_endpoint=exec_endpoint,
    )


def _listener_url_is_open(url: str, *, timeout: float) -> tuple[bool, str]:
    if not url:
        return False, "listener URL is empty"
    req = Request(url, method="GET")
    try:
        with urlopen(req, timeout=timeout):
            return True, ""
    except HTTPError as exc:
        body = exc.read(512).decode("utf-8", errors="replace").strip()
        if exc.code in (502, 503) and body.lower() == "upstream unavailable":
            return False, f"HTTP {exc.code}: {body}"
        return True, ""
    except (TimeoutError, URLError, OSError) as exc:
        return False, f"{type(exc).__name__}: {exc}"
