"""Package metadata for the Sail Python SDK."""

__version__ = "0.1.7"
