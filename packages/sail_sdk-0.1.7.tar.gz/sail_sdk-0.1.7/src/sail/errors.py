from __future__ import annotations


class SailError(Exception):
    """Base class for Sail SDK errors."""


class SailboxError(SailError):
    """Base class for sailbox-specific SDK errors."""


class SailboxCreationError(SailboxError):
    """Raised when sailbox creation fails."""


class ImageBuildError(SailboxError):
    """Raised when a custom image build fails."""


class SailboxExecutionError(SailboxError):
    """Base class for sailbox exec-related SDK errors."""


class SailboxTerminatedError(SailboxExecutionError):
    """Raised when a sailbox no longer exists on the worker."""


class SailboxExecAlreadyRunningError(SailboxExecutionError):
    """Raised when another exec request is already active for the sailbox."""


class SailboxExecRequestNotFoundError(SailboxExecutionError):
    """Raised when a wait references an unknown exec request."""


class SailboxWorkerLostError(SailboxExecutionError):
    """Raised when the assigned worker became unreachable and recovery is required."""
