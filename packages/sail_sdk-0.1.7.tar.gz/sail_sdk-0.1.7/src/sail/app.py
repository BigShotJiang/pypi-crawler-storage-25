from __future__ import annotations

from dataclasses import dataclass

from sail._http_client import HTTPClient


@dataclass(frozen=True)
class App:
    """A Sail application."""

    id: str
    name: str
    created_at: int

    @classmethod
    def find(cls, *, name: str, mint_if_missing: bool = False) -> App:
        """Find an app by name, optionally creating it if it doesn't exist."""
        client = HTTPClient.get()
        status, data = client.post(
            "/v1/apps/find",
            {"name": name, "mint_if_missing": mint_if_missing},
        )

        if status == 404:
            raise LookupError(f"App {name!r} not found")
        if status >= 400:
            msg = data.get("error", {}).get("message", "unknown error")
            raise RuntimeError(f"Failed to find app: {msg}")

        return cls(id=data["id"], name=data["name"], created_at=data["created_at"])
