from typing import Any, Dict, Optional
import asyncio
from .routers import strategy_router, account_router, market_router, system_router


class FuWenAPI:
    def __init__(self):
        self.strategy = strategy_router.StrategyRouter()
        self.account = account_router.AccountRouter()
        self.market = market_router.MarketRouter()
        self.system = system_router.SystemRouter()

    async def call(self, module: str, action: str, **kwargs) -> Dict[str, Any]:
        routers = {
            'strategy': self.strategy,
            'account': self.account,
            'market': self.market,
            'system': self.system
        }
        
        if module not in routers:
            return {'success': False, 'error': f"Unknown module: {module}"}
        
        router = routers[module]
        if not hasattr(router, action):
            return {'success': False, 'error': f"Unknown action: {action}"}
        
        method = getattr(router, action)
        try:
            if asyncio.iscoroutinefunction(method):
                result = await method(**kwargs)
            else:
                result = method(**kwargs)
            return {'success': True, 'data': result}
        except Exception as e:
            return {'success': False, 'error': str(e)}

    def sync_call(self, module: str, action: str, **kwargs) -> Dict[str, Any]:
        return asyncio.run(self.call(module, action, **kwargs))