class ErrorCode:
    SUCCESS = 0
    UNKNOWN_ERROR = -1
    INVALID_PARAMETER = 1001
    STRATEGY_NOT_FOUND = 2001
    STRATEGY_ALREADY_RUNNING = 2002
    STRATEGY_NOT_RUNNING = 2003
    ACCOUNT_NOT_FOUND = 3001
    INSUFFICIENT_FUNDS = 3002
    MARKET_DATA_ERROR = 4001
    SYSTEM_ERROR = 5001


class APIException(Exception):
    def __init__(self, code: int, message: str):
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")

    def to_dict(self) -> dict:
        return {'code': self.code, 'message': self.message}