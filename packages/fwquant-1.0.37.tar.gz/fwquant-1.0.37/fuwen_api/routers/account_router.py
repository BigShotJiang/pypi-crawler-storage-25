from typing import Any, Dict, List, Optional
from ..exceptions import APIException, ErrorCode


class AccountRouter:
    def __init__(self):
        self.accounts = {}

    def list_accounts(self) -> List[Dict[str, Any]]:
        return list(self.accounts.values())

    def get_account(self, account_id: str) -> Optional[Dict[str, Any]]:
        return self.accounts.get(account_id)

    def get_balance(self, account_id: str) -> Dict[str, Any]:
        if account_id not in self.accounts:
            raise APIException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found")
        
        return {
            'account_id': account_id,
            'balance': self.accounts[account_id].get('balance', 0.0),
            'currency': self.accounts[account_id].get('currency', 'USDT')
        }

    def get_positions(self, account_id: str) -> List[Dict[str, Any]]:
        if account_id not in self.accounts:
            raise APIException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found")
        
        return self.accounts[account_id].get('positions', [])

    def get_trade_history(self, account_id: str, limit: int = 100) -> List[Dict[str, Any]]:
        if account_id not in self.accounts:
            raise APIException(ErrorCode.ACCOUNT_NOT_FOUND, "Account not found")
        
        return self.accounts[account_id].get('trade_history', [])[:limit]