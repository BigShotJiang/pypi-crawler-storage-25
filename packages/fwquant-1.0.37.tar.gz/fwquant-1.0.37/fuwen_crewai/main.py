#!/usr/bin/env python
from crewai import Agent, Task, Crew  # 导入CrewAI核心组件


def main():
    # 输入
    agent = Agent(role="你好世界智能体", goal="向世界问好",
                  backstory="一个友好的智能体，负责向世界问好")  # 定义智能体角色、目标和背景
    task = Task(description="说'你好世界！'", agent=agent, expected_output="问候语")  # 创建任务并分配给智能体

    # 运行
    crew = Crew(agents=[agent], tasks=[task])  # 组建智能体团队
    result = crew.kickoff()  # 启动团队执行任务

    # 输出
    print(f"Crew 执行结果: {result}")  # 打印执行结果


if __name__ == "__main__":
    main()
