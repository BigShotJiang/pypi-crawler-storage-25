"""
CSV Datafeed for fuquant.

This module provides a simple datafeed that reads historical data from CSV files.
"""

import csv
from datetime import datetime
from typing import List, Callable

from fuwen_adaptor.trader.object import HistoryRequest, TickData, BarData
from fuwen_adaptor.trader.constant import Exchange, Interval


class Datafeed:
    """
    CSV datafeed implementation.
    """
    
    def __init__(self):
        """Initialize datafeed."""
        self.data_path = None
        
    def init(self, output: Callable = print) -> bool:
        """
        Initialize datafeed service connection.
        """
        output("CSV数据服务初始化完成")
        return True
    
    def query_bar_history(self, req: HistoryRequest, output: Callable = print) -> List[BarData]:
        """
        Query history bar data from CSV files.
        """
        output(f"查询K线数据: {req.symbol}.{req.exchange} {req.interval}")
        
        bars = []
        
        try:
            import os
            data_dir = os.path.join(os.path.dirname(__file__), "data")
            
            if not os.path.exists(data_dir):
                os.makedirs(data_dir)
            
            filename = f"{req.symbol}_{req.exchange.value}_{req.interval.value}.csv"
            filepath = os.path.join(data_dir, filename)
            
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        dt = datetime.fromisoformat(row['datetime'])
                        bar = BarData(
                            symbol=req.symbol,
                            exchange=req.exchange,
                            datetime=dt,
                            interval=req.interval,
                            open_price=float(row['open']),
                            high_price=float(row['high']),
                            low_price=float(row['low']),
                            close_price=float(row['close']),
                            volume=float(row['volume']),
                            turnover=float(row.get('turnover', 0)),
                            open_interest=float(row.get('open_interest', 0)),
                            gateway_name="CSV"
                        )
                        if req.start <= dt <= req.end:
                            bars.append(bar)
                output(f"从CSV文件加载了 {len(bars)} 条K线数据")
            else:
                output(f"CSV文件不存在: {filepath}")
                
        except Exception as e:
            output(f"从CSV加载数据失败: {str(e)}")
        
        return bars
    
    def query_tick_history(self, req: HistoryRequest, output: Callable = print) -> List[TickData]:
        """
        Query history tick data from CSV files.
        """
        output(f"查询Tick数据: {req.symbol}.{req.exchange}")
        return []