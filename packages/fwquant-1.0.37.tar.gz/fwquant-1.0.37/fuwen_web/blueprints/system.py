from flask import Blueprint, request, jsonify
from fuwen_api import FuWenAPI

system_bp = Blueprint('system', __name__)
api = FuWenAPI()


@system_bp.route('/status', methods=['GET'])
def get_status():
    result = api.sync_call('system', 'get_status')
    return jsonify(result)


@system_bp.route('/logs', methods=['GET'])
def get_logs():
    limit = request.args.get('limit', 100, type=int)
    result = api.sync_call('system', 'get_logs', limit=limit)
    return jsonify(result)


@system_bp.route('/performance', methods=['GET'])
def get_performance():
    result = api.sync_call('system', 'get_performance')
    return jsonify(result)


@system_bp.route('/shutdown', methods=['POST'])
def shutdown():
    result = api.sync_call('system', 'shutdown')
    return jsonify(result)