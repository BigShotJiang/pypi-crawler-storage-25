from .strategy import strategy_bp
from .account import account_bp
from .market import market_bp
from .system import system_bp


def register_blueprints(app):
    app.register_blueprint(strategy_bp, url_prefix='/api/strategy')
    app.register_blueprint(account_bp, url_prefix='/api/account')
    app.register_blueprint(market_bp, url_prefix='/api/market')
    app.register_blueprint(system_bp, url_prefix='/api/system')