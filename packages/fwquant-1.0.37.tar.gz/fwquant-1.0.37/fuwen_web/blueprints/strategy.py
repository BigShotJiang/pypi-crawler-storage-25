from flask import Blueprint, request, jsonify
from fuwen_api import FuWenAPI

strategy_bp = Blueprint('strategy', __name__)
api = FuWenAPI()


@strategy_bp.route('/', methods=['GET'])
def list_strategies():
    result = api.sync_call('strategy', 'list_strategies')
    return jsonify(result)


@strategy_bp.route('/<strategy_id>', methods=['GET'])
def get_strategy(strategy_id):
    result = api.sync_call('strategy', 'get_strategy', strategy_id=strategy_id)
    return jsonify(result)


@strategy_bp.route('/<strategy_id>/start', methods=['POST'])
def start_strategy(strategy_id):
    params = request.json or {}
    result = api.sync_call('strategy', 'start_strategy', strategy_id=strategy_id, params=params)
    return jsonify(result)


@strategy_bp.route('/<strategy_id>/stop', methods=['POST'])
def stop_strategy(strategy_id):
    result = api.sync_call('strategy', 'stop_strategy', strategy_id=strategy_id)
    return jsonify(result)


@strategy_bp.route('/<strategy_id>/params', methods=['PUT'])
def update_params(strategy_id):
    params = request.json or {}
    result = api.sync_call('strategy', 'update_strategy_params', strategy_id=strategy_id, params=params)
    return jsonify(result)