from flask import Blueprint, request, jsonify
from fuwen_api import FuWenAPI

account_bp = Blueprint('account', __name__)
api = FuWenAPI()


@account_bp.route('/', methods=['GET'])
def list_accounts():
    result = api.sync_call('account', 'list_accounts')
    return jsonify(result)


@account_bp.route('/<account_id>', methods=['GET'])
def get_account(account_id):
    result = api.sync_call('account', 'get_account', account_id=account_id)
    return jsonify(result)


@account_bp.route('/<account_id>/balance', methods=['GET'])
def get_balance(account_id):
    result = api.sync_call('account', 'get_balance', account_id=account_id)
    return jsonify(result)


@account_bp.route('/<account_id>/positions', methods=['GET'])
def get_positions(account_id):
    result = api.sync_call('account', 'get_positions', account_id=account_id)
    return jsonify(result)


@account_bp.route('/<account_id>/trades', methods=['GET'])
def get_trade_history(account_id):
    limit = request.args.get('limit', 100, type=int)
    result = api.sync_call('account', 'get_trade_history', account_id=account_id, limit=limit)
    return jsonify(result)