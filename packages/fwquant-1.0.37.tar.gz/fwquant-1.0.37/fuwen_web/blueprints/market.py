from flask import Blueprint, request, jsonify
from fuwen_api import FuWenAPI

market_bp = Blueprint('market', __name__)
api = FuWenAPI()


@market_bp.route('/symbols', methods=['GET'])
def list_symbols():
    result = api.sync_call('market', 'list_symbols')
    return jsonify(result)


@market_bp.route('/ticker/<symbol>', methods=['GET'])
def get_ticker(symbol):
    result = api.sync_call('market', 'get_ticker', symbol=symbol)
    return jsonify(result)


@market_bp.route('/orderbook/<symbol>', methods=['GET'])
def get_order_book(symbol):
    depth = request.args.get('depth', 10, type=int)
    result = api.sync_call('market', 'get_order_book', symbol=symbol, depth=depth)
    return jsonify(result)


@market_bp.route('/kline/<symbol>', methods=['GET'])
def get_kline(symbol):
    interval = request.args.get('interval', '1m')
    limit = request.args.get('limit', 100, type=int)
    result = api.sync_call('market', 'get_kline', symbol=symbol, interval=interval, limit=limit)
    return jsonify(result)


@market_bp.route('/summary', methods=['GET'])
def get_market_summary():
    result = api.sync_call('market', 'get_market_summary')
    return jsonify(result)