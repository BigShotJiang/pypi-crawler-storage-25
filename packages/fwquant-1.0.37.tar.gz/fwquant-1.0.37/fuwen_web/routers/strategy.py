from fastapi import APIRouter, HTTPException
from typing import List, Dict, Optional, Any
from fuwen_api import FuWenAPI

router = APIRouter()
api = FuWenAPI()


@router.get("/", summary="获取策略列表")
async def list_strategies() -> Dict[str, Any]:
    result = api.sync_call('strategy', 'list_strategies')
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/{strategy_id}", summary="获取策略详情")
async def get_strategy(strategy_id: str) -> Dict[str, Any]:
    result = api.sync_call('strategy', 'get_strategy', strategy_id=strategy_id)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.post("/{strategy_id}/start", summary="启动策略")
async def start_strategy(strategy_id: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    result = api.sync_call('strategy', 'start_strategy', strategy_id=strategy_id, params=params or {})
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.post("/{strategy_id}/stop", summary="停止策略")
async def stop_strategy(strategy_id: str) -> Dict[str, Any]:
    result = api.sync_call('strategy', 'stop_strategy', strategy_id=strategy_id)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.put("/{strategy_id}/params", summary="更新策略参数")
async def update_params(strategy_id: str, params: Dict[str, Any]) -> Dict[str, Any]:
    result = api.sync_call('strategy', 'update_strategy_params', strategy_id=strategy_id, params=params)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result