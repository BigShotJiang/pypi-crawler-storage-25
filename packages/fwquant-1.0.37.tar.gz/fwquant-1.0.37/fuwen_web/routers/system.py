from fastapi import APIRouter, HTTPException, Query
from typing import Dict, Any
from fuwen_api import FuWenAPI

router = APIRouter()
api = FuWenAPI()


@router.get("/status", summary="获取系统状态")
async def get_status() -> Dict[str, Any]:
    result = api.sync_call('system', 'get_status')
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/logs", summary="获取日志")
async def get_logs(limit: int = Query(100, ge=1, le=1000)) -> Dict[str, Any]:
    result = api.sync_call('system', 'get_logs', limit=limit)
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.get("/performance", summary="获取性能指标")
async def get_performance() -> Dict[str, Any]:
    result = api.sync_call('system', 'get_performance')
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result


@router.post("/shutdown", summary="关闭系统")
async def shutdown() -> Dict[str, Any]:
    result = api.sync_call('system', 'shutdown')
    if not result.get('success'):
        raise HTTPException(status_code=400, detail=result.get('error'))
    return result