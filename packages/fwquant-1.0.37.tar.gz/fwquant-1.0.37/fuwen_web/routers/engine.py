from fastapi import APIRouter, Body
from typing import Dict, Any, List
from ..engine_manager import engine_manager

router = APIRouter()


@router.post("/init", summary="初始化引擎")
async def init_engine():
    try:
        result = engine_manager.initialize()
        if result["success"]:
            return {"success": True, "msg": "✅ 引擎初始化成功"}
        else:
            return {"success": False, "msg": f"❌ 初始化失败: {result['msg']}"}
    except Exception as e:
        return {"success": False, "msg": f"❌ 初始化失败: {str(e)}"}


@router.get("/status", summary="获取引擎状态")
async def get_engine_status():
    try:
        return {"success": True, "data": engine_manager.get_status()}
    except Exception as e:
        return {"success": False, "msg": f"获取状态失败: {str(e)}", "data": {}}


@router.get("/gateways", summary="获取网关列表")
async def get_gateways():
    try:
        return {"success": True, "data": engine_manager.get_gateways_info()}
    except Exception as e:
        return {"success": False, "msg": f"获取网关列表失败: {str(e)}", "data": {}}


@router.post("/gateway/{gateway_name}/add", summary="添加网关")
async def add_gateway(gateway_name: str):
    result = engine_manager.add_gateway(gateway_name)
    if result["success"]:
        return {"success": True, "msg": f"✅ 网关 {gateway_name} 添加成功"}
    else:
        return {"success": False, "msg": f"❌ 添加网关失败: {result['msg']}"}


@router.get("/gateway/{gateway_name}/config", summary="获取网关配置")
async def get_gateway_config(gateway_name: str):
    try:
        config = engine_manager._load_gateway_config(gateway_name)
        return {"success": True, "data": config}
    except Exception as e:
        return {"success": False, "msg": f"获取配置失败: {str(e)}", "data": {}}


@router.post("/gateway/{gateway_name}/connect", summary="连接网关")
async def connect_gateway(gateway_name: str, config: Dict[str, Any] = Body(...)):
    result = engine_manager.connect_gateway(gateway_name, config)
    if result["success"]:
        return {"success": True, "msg": f"✅ 网关 {gateway_name} 连接成功"}
    else:
        return {"success": False, "msg": f"❌ 连接网关失败: {result['msg']}"}


@router.post("/gateway/{gateway_name}/disconnect", summary="断开网关")
async def disconnect_gateway(gateway_name: str):
    result = engine_manager.disconnect_gateway(gateway_name)
    if result["success"]:
        return {"success": True, "msg": f"✅ 网关 {gateway_name} 断开成功"}
    else:
        return {"success": False, "msg": f"❌ 断开网关失败: {result['msg']}"}


@router.get("/apps", summary="获取应用列表")
async def get_apps():
    try:
        return {"success": True, "data": engine_manager.get_apps_info()}
    except Exception as e:
        return {"success": False, "msg": f"获取应用列表失败: {str(e)}", "data": {}}


@router.post("/app/{app_name}/start", summary="启动应用")
async def start_app(app_name: str):
    result = engine_manager.start_app(app_name)
    if result["success"]:
        return {"success": True, "msg": f"✅ 应用 {app_name} 启动成功"}
    else:
        return {"success": False, "msg": f"❌ 启动应用失败: {result['msg']}"}


@router.post("/app/{app_name}/stop", summary="停止应用")
async def stop_app(app_name: str):
    result = engine_manager.stop_app(app_name)
    if result["success"]:
        return {"success": True, "msg": f"✅ 应用 {app_name} 停止成功"}
    else:
        return {"success": False, "msg": f"❌ 停止应用失败: {result['msg']}"}


@router.get("/accounts", summary="获取账户列表")
async def get_accounts():
    try:
        return {"success": True, "data": engine_manager.get_accounts()}
    except Exception as e:
        return {"success": False, "msg": f"获取账户列表失败: {str(e)}", "data": []}


@router.get("/positions", summary="获取持仓列表")
async def get_positions():
    try:
        return {"success": True, "data": engine_manager.get_positions()}
    except Exception as e:
        return {"success": False, "msg": f"获取持仓列表失败: {str(e)}", "data": []}


@router.get("/orders", summary="获取委托列表")
async def get_orders():
    try:
        return {"success": True, "data": engine_manager.get_orders()}
    except Exception as e:
        return {"success": False, "msg": f"获取委托列表失败: {str(e)}", "data": []}
