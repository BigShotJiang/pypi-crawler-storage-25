from PySide6 import QtCore, QtWidgets

from fuwen_frame.gateway.fw_adaptor.trader.engine import fw_MainEngine
from fuwen_adaptor.event import EventEngine

from fuwen_adaptor.trader.ui.widget import TradingWidget

from fuwen_adaptor.trader.object import Offset, Direction

from fuwen_frame.公共库.打印日志_福纹框架 import logger

from fuwen_frame.公共库.语言 import _

class fw_TradingWidget(TradingWidget):
    main_engine: fw_MainEngine = None
    close_all_button: QtWidgets.QPushButton = None

    def __init__(self, main_engine: fw_MainEngine, event_engine: EventEngine):
        super().__init__(main_engine, event_engine)
        self.main_engine = main_engine

    def init_ui1(self) -> None:
        # 1. 先执行父类原来的UI（生成所有控件）
        super().init_ui()

        # 2. 创建【一键全平】按钮
        self.close_all_button: QtWidgets.QPushButton = QtWidgets.QPushButton(_("一键全平"))
        self.close_all_button.clicked.connect(self.close_all_positions)  # 绑定功能

        # 3. 获取最外层布局，把按钮追加到最后面（自动放在 全撤 下面）
        vbox = self.layout()  # 父类已经设置了 vbox 布局
        vbox.addWidget(self.close_all_button)

    def init_ui(self) -> None:
        # 1. 先执行父类原来的UI
        super().init_ui()

        # ===================== 并排按钮布局 =====================
        # 创建水平布局，让两个按钮并排
        button_layout = QtWidgets.QHBoxLayout()

        # 按钮1：一键全平（50%宽度）
        self.close_all_button = QtWidgets.QPushButton(_("一键全平"))
        self.close_all_button.clicked.connect(self.close_all_positions)

        # 按钮2：断开当前账号（50%宽度）
        self.断开接口_按钮 = QtWidgets.QPushButton(_("断开接口"))
        self.断开接口_按钮.clicked.connect(self.断开接口_当前)

        # 加入布局，设置比例 1:1（各占50%）
        button_layout.addWidget(self.close_all_button, 1)
        button_layout.addWidget(self.断开接口_按钮, 1)

        # 追加到界面最底部
        vbox = self.layout()
        vbox.addLayout(button_layout)

    # D:\Git\github\FwQuant\fuwen_fuwen\fuwen_frame\gateway\fuwen_adaptor\trader\ui\widget.py
    def 断开接口_当前(self):
        """
        断开当前账号功能（修复版：处理返回值、异常捕获）
        """
        # 获取当前选中的网关名称
        gateway_name = self.gateway_combo.currentText()
        msg = ""
        if not gateway_name:
            msg = f"💡 提示：请先选择要断开的接口！"
        else:
            # 调用主引擎断开方法，并处理返回结果
            result = self.main_engine.断开网关(gateway_name=gateway_name)
            if result is not None:
                if result.get("success"):
                    if result.get("code") in [2, 3]:
                        msg = f"💡 {result['msg']}"
                    else:
                        msg = f"✅ {result['msg']}"
                else:
                    msg = f"❌ {result['msg']}"
            else:
                msg = "❌断开失败：主引擎返回空结果"
        logger.info(msg=msg, gateway_name=gateway_name)

    def close_all_positions(self):
        """
        一键全平功能（核心逻辑）
        """
        self.main_engine.close_all_positions()
        QtWidgets.QMessageBox.information(self, "提示", f"已触发一键全平指令！")  # 提示用户 弹窗，弹框效果。
