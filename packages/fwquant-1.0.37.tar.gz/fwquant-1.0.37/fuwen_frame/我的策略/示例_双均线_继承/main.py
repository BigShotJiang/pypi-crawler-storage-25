from typing import Any, Optional, Dict
from fuwen_frame.我的策略.信号来源_适配器.main import 双均线金叉死叉_信号引擎_适配器
from fuwen_frame.公共库.打印日志_福纹框架 import logger
from fuwen_frame.我的策略.基类.策略 import 策略_基类

class 示例_双均线_继承(策略_基类):
    """整合版：示例模板策略 + 模板信号引擎"""
    author = "示例_双均线金叉死叉策略"
    快线周期 = 10
    慢线周期 = 30
    显示列表 = ['author', '下单数量', '最大持仓量', '快线周期', '慢线周期']
    parameters = 显示列表

    def __init__(self, cta_engine: Any, strategy_name: str, vt_symbol: str, setting: dict):
        super().__init__(cta_engine, strategy_name, vt_symbol, setting)
        self.最大持仓量 = 3
        self._标的代码 = None
        # 优化点1：从setting加载周期参数（支持外部配置，避免硬编码）
        self.快线周期 = setting.get("快线周期", 10)
        self.慢线周期 = setting.get("慢线周期", 30)
        self._信号参数.update({"快线周期": self.快线周期, "慢线周期": self.慢线周期})
        self.parameters = self.显示列表

    def 初始化信号引擎(self, 参数=None):
        """初始化信号引擎（自身即为信号引擎）"""
        if 参数 is None:
            参数 = self._信号参数

        # 优化点2：强制更新周期参数（确保与策略参数一致）
        参数['快线周期'] = self.快线周期
        参数['慢线周期'] = self.慢线周期
        # 优化点3：增加信号引擎实例判空（避免重复创建）
        if not hasattr(self, '信号引擎实例') or self.信号引擎实例 is None:
            self.信号引擎实例 = 双均线金叉死叉_信号引擎_适配器(请求参数=参数)
        else:
            # 复用实例，更新参数（减少对象创建开销）
            self.信号引擎实例._参数 = 参数
            self.信号引擎实例.快线周期 = 参数['快线周期']
            self.信号引擎实例.慢线周期 = 参数['慢线周期']

        logger.debug(f"初始化整合版信号引擎，信号参数：{参数}")