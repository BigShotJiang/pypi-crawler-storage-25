import random

from fuwen_signal.fw_signal.信号工厂.七福 import 七福信号
from fuwen_signal.fw_signal.信号工厂.七福.配置.默认 import 七福默认参数配置
from fuwen_signal.fw_signal.公共库.福纹信号适配器 import 信号结果_枚举
from fuwen_signal.fw_signal.信号工厂.双均线.main import 双均线信号
from fuwen_signal.fw_signal.信号工厂.随机.main import 随机信号
from fuwen_frame.我的策略.基类.策略 import 信号_基类


class 随机_信号引擎_适配器(信号_基类):
    def 信号算法(self) -> 信号结果_枚举:
        result = 随机信号(信号列表=["上涨", "下跌", "震荡"])
        if result == "上涨":
            result = 信号结果_枚举.看多
        elif result == "下跌":
            result = 信号结果_枚举.看空
        else:
            result = 信号结果_枚举.无信号
        return result

    def __init__(self, 请求参数=None):
        super().__init__()


class 双均线金叉死叉_信号引擎_适配器(信号_基类):
    def __init__(self, 请求参数=None):
        super().__init__(请求参数)
        # 初始化周期参数（从请求参数获取，无则用默认值）
        self.快线周期 = self.信号参数.get("快线周期", 10) if self.信号参数 else 10
        self.慢线周期 = self.信号参数.get("慢线周期", 30) if self.信号参数 else 30

    def 信号算法(self) -> 信号结果_枚举:
        # 优化点1：直接从DataFrame提取收盘价序列，避免遍历列表
        if self.历史k线.empty:
            return 信号结果_枚举.无信号

        # 优化点2：提取收盘价数组，限制长度（仅保留需要的部分）
        价格数组 = self.历史k线['收盘价'].values
        # 优化点3：复用双均线信号函数，传递周期参数
        result = 双均线信号(
            价格列表=价格数组,
            快线周期=self.快线周期,
            慢线周期=self.慢线周期
        )
        return result


class 七福_信号引擎_适配器(信号_基类):
    def 信号算法(self) -> 信号结果_枚举:
        返回信号 = 七福信号(参数=七福默认参数配置)
        return 返回信号

    def __init__(self, 请求参数=None):
        super().__init__()
