# FWQuant

一个从 0 到 1 完全自建的量化交易平台。

## 功能特性

- **fwquant**: 量化平台主框架，包含以下模块：
  - **fwdata**: 量化数据框架，用于处理量化数据并提供数据接口
  - **fwweb**: 量化 Web 框架，用于提供量化平台的 Web 界面
  - **fwengine**: 量化引擎，负责执行量化策略
  - **fuwen_adaptor**: 量化交易框架，用于连接交易接口、处理交易数据并执行交易指令

## 安装方法

```bash
# 使用 uv 安装（推荐）
uv pip install fwquant -U

# 开发模式安装
git clone https://github.com/fwquant/fwquant.git
cd fwquant
uv pip install -e .
```

## 快速开始

```bash
# 启动 Web 服务
fwquant web run

# 查看可用命令
fwquant --help
```

## 致谢

特别感谢 [VN.PY](https://github.com/vnpy) 项目，为我们提供了量化交易框架。