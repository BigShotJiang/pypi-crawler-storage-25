import click
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@click.group()
@click.version_option(version="1.0.0", prog_name="fwquant")
def cli():
    """FWQuant - 量化交易框架命令行工具"""
    pass


@cli.group()
def web():
    """Web服务管理"""
    pass


@web.command("run")
@click.option("--host", default="0.0.0.0", help="绑定地址")
@click.option("--port", default=8888, help="监听端口")
@click.option("--reload", is_flag=True, help="自动重载")
def web_run(host, port, reload):
    """启动Web API服务"""
    try:
        import uvicorn
        from fuwen_web.app import app
        
        click.secho(f"🚀 启动 FWQuant Web API 服务", fg="green")
        click.secho(f"📡 绑定地址: {host}", fg="cyan")
        click.secho(f"🔌 监听端口: {port}", fg="cyan")
        click.secho(f"📖 Swagger文档: http://127.0.0.1:{port}/docs", fg="yellow")
        click.secho(f"📚 ReDoc文档: http://127.0.0.1:{port}/redoc", fg="yellow")
        
        uvicorn.run(app, host=host, port=port, reload=reload)
    except ImportError as e:
        click.secho(f"❌ 导入错误: {e}", fg="red")
        sys.exit(1)


@web.command("stop")
def web_stop():
    """停止Web API服务"""
    click.secho("⏹️ 停止Web API服务", fg="yellow")
    click.secho("提示: 请使用 Ctrl+C 停止运行中的服务", fg="blue")


@cli.group()
def strategy():
    """策略管理"""
    pass


@strategy.command("list")
def strategy_list():
    """列出所有策略"""
    click.secho("📋 策略列表:", fg="green")
    click.echo("  • 网格策略")
    click.echo("  • 趋势策略")
    click.echo("  • 套利策略")


@strategy.command("start")
@click.argument("name")
def strategy_start(name):
    """启动指定策略"""
    click.secho(f"▶️ 启动策略: {name}", fg="green")


@strategy.command("stop")
@click.argument("name")
def strategy_stop(name):
    """停止指定策略"""
    click.secho(f"⏹️ 停止策略: {name}", fg="yellow")


@cli.group()
def account():
    """账户管理"""
    pass


@account.command("info")
def account_info():
    """查看账户信息"""
    click.secho("👤 账户信息:", fg="green")
    click.echo("  • 账户余额: **** USDT")
    click.echo("  • 可用资金: **** USDT")
    click.echo("  • 持仓市值: **** USDT")


@cli.command()
def version():
    """显示版本信息"""
    click.secho("FWQuant v1.0.0", fg="green")
    click.echo("量化交易框架统一接口服务")


if __name__ == "__main__":
    cli()