from pathlib import Path
import gettext

localedir = Path(__file__).parent
translations = gettext.translation('fuwen_singlebacktest', localedir=localedir, fallback=True)

_ = translations.gettext
