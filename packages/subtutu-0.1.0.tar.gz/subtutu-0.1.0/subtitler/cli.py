from __future__ import annotations

import argparse
import os
import sys

# Fix SSL certificate verification on macOS Python.org installs
try:
    import certifi
    os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    os.environ.setdefault("REQUESTS_CA_BUNDLE", certifi.where())
except ImportError:
    pass
from pathlib import Path

from . import __version__
from .errors import SubtitlerError


def _resolve_srt_path(filepath: Path, output: str | None) -> Path:
    if output is None:
        return filepath.with_suffix(".srt")
    out = Path(output)
    if out.is_dir():
        return out / filepath.with_suffix(".srt").name
    return out


def _unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    stem = path.stem
    parent = path.parent
    counter = 1
    while True:
        candidate = parent / f"{stem}_{counter}.srt"
        if not candidate.exists():
            return candidate
        counter += 1


def _parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="subtutu",
        description="Generate SRT subtitles from a video or audio file using Whisper.",
    )
    parser.add_argument("filepath", help="Path to the video or audio file")
    parser.add_argument(
        "--model", default="auto",
        help="Whisper model to use, or 'auto' to pick based on available memory (default: auto)",
    )
    parser.add_argument(
        "--language", default="en",
        metavar="LANG",
        help="Language code, e.g. en, fr, ja. Use 'auto' to detect (default: en)",
    )
    parser.add_argument(
        "--output", default=None,
        metavar="PATH",
        help="Output .srt path or directory (default: alongside input file)",
    )
    parser.add_argument(
        "--device", default=None,
        choices=["cpu", "mps", "cuda"],
        help="Compute device (default: auto-detect)",
    )
    parser.add_argument(
        "--verbose", action="store_true",
        help="Print each decoded segment as it is transcribed",
    )
    parser.add_argument("--version", action="version", version=f"subtitler {__version__}")
    return parser.parse_args(argv)


def main(argv=None) -> None:
    args = _parse_args(argv)
    debug = os.environ.get("SUBTITLER_DEBUG", "").strip() not in ("", "0")

    try:
        _run(args)
    except SubtitlerError as e:
        print(f"Error: {e}", file=sys.stderr)
        if debug:
            raise
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(130)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        if debug:
            raise
        sys.exit(1)


def _print(msg: str) -> None:
    """Print a permanent status line."""
    sys.stderr.write(f"{msg}\n")
    sys.stderr.flush()


def _progress(msg: str) -> None:
    """Update the current line in place (for percentage counters)."""
    sys.stderr.write(f"\r\033[K  {msg}")
    sys.stderr.flush()


def _ask_model(recommended: str, table: str) -> str:
    """Show model table and prompt user to confirm or switch. Returns chosen model name."""
    import whisper
    valid = set(whisper.available_models())

    sys.stderr.write(table)
    sys.stderr.write(f"  Recommended: {recommended}\n")
    sys.stderr.write(f"  Press Enter to use '{recommended}', or type a model name: ")
    sys.stderr.flush()

    try:
        choice = input().strip()
    except EOFError:
        return recommended  # non-interactive (piped/scripted), use recommendation silently

    if not choice:
        return recommended
    if choice in valid:
        return choice

    sys.stderr.write(f"  Unknown model '{choice}', using '{recommended}'\n")
    return recommended


def _run(args: argparse.Namespace) -> None:
    from . import preflight, transcriber
    from .device import select_device
    from .model_selector import suggest_model, build_model_table

    filepath = Path(args.filepath).expanduser().resolve()
    srt_path = _resolve_srt_path(filepath, args.output)
    if args.output is None:
        srt_path = _unique_path(srt_path)

    # --- preflight ---
    duration_s = preflight.run_all(filepath, srt_path)

    # --- device ---
    device = select_device(args.device)

    # --- model selection ---
    if args.model == "auto":
        _print("Auto-picking model...")
        recommended = suggest_model(device=device, duration_s=duration_s, progress_fn=_progress)
        sys.stderr.write("\n")
        table = build_model_table(device, duration_s, recommended)
        model_name = _ask_model(recommended, table)
    else:
        model_name = args.model

    # --- load model ---
    _print(f"Loading: {model_name}")
    model = transcriber.load_model(model_name, device, progress_fn=_progress)
    sys.stderr.write("\n")

    # --- transcribe ---
    _print(f"Transcribing: {filepath.name}")
    result = transcriber.transcribe(
        model, filepath, args.language, device,
        duration_s=duration_s,
        progress_fn=_progress,
    )
    sys.stderr.write("\n")

    # --- write SRT ---
    transcriber.write_srt(result, filepath, srt_path)

    _print(f"Done: {srt_path}")
