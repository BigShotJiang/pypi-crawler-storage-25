from __future__ import annotations

import platform
import sys


def select_device(force: str | None) -> str:
    valid = {"cpu", "cuda"}

    if force is not None:
        if force == "mps":
            # faster-whisper uses CTranslate2 which doesn't support MPS — use CPU instead
            print("Note: MPS is not supported by faster-whisper. Using CPU with int8.", file=sys.stderr)
            return "cpu"
        if force not in valid:
            from .errors import PreflightError
            raise PreflightError(f"Invalid device '{force}'. Choose from: cpu, cuda")
        return force

    # Auto-detect: check for CUDA, otherwise CPU
    # (Apple Silicon still benefits from int8 on CPU via Accelerate framework)
    try:
        import ctranslate2
        if "cuda" in ctranslate2.get_supported_compute_types("cuda"):
            return "cuda"
    except Exception:
        pass

    return "cpu"
