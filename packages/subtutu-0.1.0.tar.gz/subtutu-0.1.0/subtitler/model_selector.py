from __future__ import annotations

import platform
import subprocess
import sys

# (accuracy_pct, speed_multiplier_cpu_int8, speed_multiplier_cuda_fp16)
# faster-whisper with int8 is ~4x faster than openai-whisper on CPU
MODELS: dict[str, tuple[int, float, float]] = {
    "tiny":     (60, 120.0, 400.0),
    "base":     (75,  60.0, 400.0),
    "small":    (85,  24.0, 240.0),
    "medium":   (93,   8.0,  80.0),
    "turbo":    (90,  30.0, 160.0),
    "large-v3": (97,   4.0,  40.0),
}


def _ram_gb() -> float:
    try:
        if platform.system() == "Darwin":
            out = subprocess.check_output(["sysctl", "-n", "hw.memsize"], text=True)
            return int(out.strip()) / (1024 ** 3)
        elif platform.system() == "Linux":
            import os
            pages = os.sysconf("SC_PHYS_PAGES")
            page_size = os.sysconf("SC_PAGE_SIZE")
            return (pages * page_size) / (1024 ** 3)
    except Exception:
        pass
    return 8.0


def _cuda_vram_gb() -> float | None:
    try:
        import torch
        if torch.cuda.is_available():
            return torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
    except Exception:
        pass
    return None


def _fmt_duration(seconds: float) -> str:
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    h = seconds // 3600
    m = (seconds % 3600) // 60
    return f"{h}h {m}m"


def _speed_index(device: str) -> int:
    return {"cpu": 1, "cuda": 2}.get(device, 1)


def suggest_model(device: str, duration_s: float = 0.0, progress_fn=None) -> str:
    def status(msg: str) -> None:
        if progress_fn:
            progress_fn(msg)

    status("Checking GPU...")
    vram = _cuda_vram_gb()

    if vram is not None:
        status(f"Found GPU: {vram:.1f} GB VRAM")
        if vram >= 10:
            recommended = "large-v3"
        elif vram >= 5:
            recommended = "medium"
        elif vram >= 2:
            recommended = "small"
        else:
            recommended = "base"
    else:
        status("Checking RAM...")
        ram = _ram_gb()
        status(f"Found {ram:.1f} GB RAM")
        if ram >= 16:
            recommended = "medium"
        elif ram >= 8:
            recommended = "small"
        elif ram >= 4:
            recommended = "base"
        else:
            recommended = "tiny"

    return recommended


def build_model_table(device: str, duration_s: float, recommended: str) -> str:
    speed_idx = _speed_index(device)
    lines = []
    lines.append(f"\n  {'Model':<12} {'Accuracy':>8}   {'Est. time':>10}")
    lines.append(f"  {'─' * 12}   {'─' * 8}   {'─' * 10}")

    for name, (accuracy, *speeds) in MODELS.items():
        speed = speeds[speed_idx - 1]
        if duration_s > 0:
            est_s = duration_s / speed
            time_str = _fmt_duration(est_s)
        else:
            time_str = "unknown"

        marker = "▶" if name == recommended else " "
        lines.append(f"  {marker} {name:<10} {accuracy:>7}%   {time_str:>10}")

    lines.append("")
    return "\n".join(lines)
