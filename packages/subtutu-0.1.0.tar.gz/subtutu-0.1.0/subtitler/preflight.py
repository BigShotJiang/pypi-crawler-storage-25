import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from .errors import PreflightError


def check_ffmpeg() -> None:
    if shutil.which("ffmpeg") is None:
        raise PreflightError(
            "ffmpeg not found in PATH.\n"
            "Install it with:  brew install ffmpeg"
        )
    if shutil.which("ffprobe") is None:
        raise PreflightError(
            "ffprobe not found in PATH (should come with ffmpeg).\n"
            "Reinstall with:  brew install ffmpeg"
        )


def check_file(path: Path) -> None:
    if not path.exists():
        raise PreflightError(f"File not found: {path}")
    if path.is_dir():
        raise PreflightError(f"{path} is a directory, not a file")
    if path.stat().st_size == 0:
        raise PreflightError(f"File appears to be empty: {path}")
    try:
        path.open("rb").close()
    except PermissionError:
        msg = f"Cannot read {path}: permission denied."
        if platform.system() == "Darwin":
            msg += (
                "\nTip: Terminal may need Full Disk Access — "
                "System Settings > Privacy & Security > Full Disk Access"
            )
        raise PreflightError(msg)


def check_audio_stream(path: Path) -> float:
    """Validate audio stream exists and return duration in seconds (0.0 if unknown)."""
    cmd = [
        "ffprobe", "-v", "quiet",
        "-print_format", "json",
        "-show_streams", "-show_format",
        str(path),
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
    except subprocess.TimeoutExpired:
        raise PreflightError(f"Timed out inspecting file: {path}")
    except OSError as e:
        raise PreflightError(f"Could not run ffprobe: {e}")

    if result.returncode != 0:
        raise PreflightError(
            f"Could not inspect file (ffprobe failed):\n{result.stderr.strip()}"
        )

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        raise PreflightError("ffprobe returned unexpected output")

    streams = data.get("streams", [])
    has_audio = any(s.get("codec_type") == "audio" for s in streams)
    if not has_audio:
        raise PreflightError(
            f"No audio stream found in {path}.\n"
            "Make sure this is a video or audio file."
        )

    try:
        return float(data.get("format", {}).get("duration", 0))
    except (TypeError, ValueError):
        return 0.0


def check_output_writable(srt_path: Path) -> None:
    parent = srt_path.parent
    if not parent.exists():
        raise PreflightError(f"Output directory does not exist: {parent}")
    if not os.access(parent, os.W_OK):
        raise PreflightError(f"Cannot write to {parent}: permission denied")


def check_disk_space(directory: Path) -> None:
    try:
        stat = shutil.disk_usage(directory)
        free_mb = stat.free // (1024 * 1024)
        if free_mb < 50:
            raise PreflightError(
                f"Disk nearly full ({free_mb} MB free). "
                "Free up space and retry."
            )
    except OSError:
        pass  # non-fatal if we can't check


def run_all(filepath: Path, srt_path: Path) -> float:
    """Run all preflight checks. Returns video duration in seconds."""
    check_ffmpeg()
    check_file(filepath)
    duration = check_audio_stream(filepath)
    check_output_writable(srt_path)
    check_disk_space(srt_path.parent)
    return duration
