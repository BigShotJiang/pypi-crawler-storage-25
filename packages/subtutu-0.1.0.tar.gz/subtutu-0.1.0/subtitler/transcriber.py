from __future__ import annotations

import os
from pathlib import Path

from .errors import ModelError, OutputError, TranscriptionError

VALID_MODELS = {
    "tiny", "tiny.en", "base", "base.en", "small", "small.en",
    "medium", "medium.en", "large-v1", "large-v2", "large-v3", "turbo",
    "distil-large-v2", "distil-medium.en", "distil-small.en",
}

_HF_CACHE = os.path.expanduser("~/.cache/huggingface/hub")


def _model_cached(model_name: str) -> bool:
    model_dir = os.path.join(_HF_CACHE, f"models--Systran--faster-whisper-{model_name}")
    return os.path.isdir(model_dir)


def _compute_type(device: str) -> str:
    return "float16" if device == "cuda" else "int8"


def load_model(model_name: str, device: str, progress_fn=None):
    from faster_whisper import WhisperModel

    if model_name not in VALID_MODELS:
        raise ModelError(
            f"Unknown model '{model_name}'.\n"
            f"Valid models: {', '.join(sorted(VALID_MODELS))}"
        )

    if not _model_cached(model_name):
        size_hints = {
            "tiny": "~150 MB", "base": "~290 MB", "small": "~970 MB",
            "medium": "~3 GB", "large-v2": "~6 GB", "large-v3": "~6 GB",
            "turbo": "~1.6 GB",
        }
        hint = size_hints.get(model_name, "")
        if progress_fn:
            progress_fn(f"Downloading {model_name} {hint} from Hugging Face...")

    try:
        model = WhisperModel(model_name, device=device, compute_type=_compute_type(device))
    except ValueError as e:
        raise ModelError(f"Failed to load model: {e}")
    except Exception as e:
        msg = str(e).lower()
        if "out of memory" in msg or "oom" in msg:
            raise ModelError(
                f"Not enough memory to load '{model_name}'.\n"
                "Try a smaller model with --model small"
            )
        raise ModelError(
            f"Could not load model '{model_name}': {e}\n"
            "Check your network connection or try again."
        )

    return model


def transcribe(model, filepath: Path, language: str, device: str,
               duration_s: float = 0.0, progress_fn=None) -> dict:
    whisper_language = None if language == "auto" else language

    try:
        segments_gen, info = model.transcribe(
            str(filepath),
            language=whisper_language,
            beam_size=5,
        )
    except Exception as e:
        msg = str(e).lower()
        if "audio" in msg or "ffmpeg" in msg or "decode" in msg:
            raise TranscriptionError(
                f"Could not decode audio from {filepath}.\n"
                "The file may be corrupt or use an unsupported codec."
            )
        raise TranscriptionError(f"Transcription failed: {e}")

    # Consume the generator — this is where actual work happens.
    # We get real progress because segments arrive sequentially.
    total = duration_s or info.duration or 0.0
    segments: list[dict] = []
    try:
        for seg in segments_gen:
            segments.append({"start": seg.start, "end": seg.end, "text": seg.text})
            if progress_fn and total > 0:
                pct = min(100, int(seg.end / total * 100))
                progress_fn(f"Transcribing... {pct}%")
    except Exception as e:
        raise TranscriptionError(f"Transcription failed mid-way: {e}")

    if not segments:
        lang_tip = "" if language == "auto" else "\nTry --language auto to let Whisper detect the language."
        raise TranscriptionError(f"No speech detected in {filepath}.{lang_tip}")

    return {"segments": segments, "language": info.language}


def write_srt(result: dict, filepath: Path, srt_path: Path) -> None:
    try:
        _write_srt_manual(result["segments"], srt_path)
    except OSError as e:
        raise OutputError(f"Could not write SRT file: {e}")


def _write_srt_manual(segments: list, srt_path: Path) -> None:
    def fmt_time(seconds: float) -> str:
        ms = int(round(seconds * 1000))
        h, ms = divmod(ms, 3_600_000)
        m, ms = divmod(ms, 60_000)
        s, ms = divmod(ms, 1_000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    with srt_path.open("w", encoding="utf-8") as f:
        for i, seg in enumerate(segments, start=1):
            f.write(f"{i}\n")
            f.write(f"{fmt_time(seg['start'])} --> {fmt_time(seg['end'])}\n")
            f.write(f"{seg['text'].strip()}\n\n")
