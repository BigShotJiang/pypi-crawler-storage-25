class SubtitlerError(Exception):
    pass


class PreflightError(SubtitlerError):
    pass


class ModelError(SubtitlerError):
    pass


class TranscriptionError(SubtitlerError):
    pass


class OutputError(SubtitlerError):
    pass
