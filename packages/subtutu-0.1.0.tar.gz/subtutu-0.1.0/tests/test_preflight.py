import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from subtitler.errors import PreflightError
from subtitler import preflight


def test_check_ffmpeg_missing():
    with patch("shutil.which", return_value=None):
        with pytest.raises(PreflightError, match="ffmpeg not found"):
            preflight.check_ffmpeg()


def test_check_ffmpeg_ffprobe_missing():
    with patch("shutil.which", side_effect=lambda x: "/usr/bin/ffmpeg" if x == "ffmpeg" else None):
        with pytest.raises(PreflightError, match="ffprobe not found"):
            preflight.check_ffmpeg()


def test_check_file_not_found(tmp_path):
    with pytest.raises(PreflightError, match="File not found"):
        preflight.check_file(tmp_path / "nonexistent.mp4")


def test_check_file_is_directory(tmp_path):
    with pytest.raises(PreflightError, match="is a directory"):
        preflight.check_file(tmp_path)


def test_check_file_empty(tmp_path):
    f = tmp_path / "empty.mp4"
    f.write_bytes(b"")
    with pytest.raises(PreflightError, match="empty"):
        preflight.check_file(f)


def test_check_file_ok(tmp_path):
    f = tmp_path / "video.mp4"
    f.write_bytes(b"fake data")
    preflight.check_file(f)  # should not raise


def test_check_audio_stream_ok(tmp_path):
    f = tmp_path / "video.mp4"
    f.write_bytes(b"fake")
    payload = json.dumps({"streams": [{"codec_type": "audio"}]})
    mock_result = MagicMock(returncode=0, stdout=payload, stderr="")
    with patch("subprocess.run", return_value=mock_result):
        preflight.check_audio_stream(f)  # should not raise


def test_check_audio_stream_no_audio(tmp_path):
    f = tmp_path / "video.mp4"
    f.write_bytes(b"fake")
    payload = json.dumps({"streams": [{"codec_type": "video"}]})
    mock_result = MagicMock(returncode=0, stdout=payload, stderr="")
    with patch("subprocess.run", return_value=mock_result):
        with pytest.raises(PreflightError, match="No audio stream"):
            preflight.check_audio_stream(f)


def test_check_audio_stream_ffprobe_fails(tmp_path):
    f = tmp_path / "video.mp4"
    f.write_bytes(b"fake")
    mock_result = MagicMock(returncode=1, stdout="", stderr="some error")
    with patch("subprocess.run", return_value=mock_result):
        with pytest.raises(PreflightError, match="ffprobe failed"):
            preflight.check_audio_stream(f)


def test_check_output_writable_ok(tmp_path):
    srt = tmp_path / "output.srt"
    preflight.check_output_writable(srt)  # should not raise


def test_check_output_writable_missing_parent(tmp_path):
    srt = tmp_path / "nonexistent_dir" / "output.srt"
    with pytest.raises(PreflightError, match="does not exist"):
        preflight.check_output_writable(srt)
