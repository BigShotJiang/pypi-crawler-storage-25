from pathlib import Path

import pytest

from subtitler.cli import _resolve_srt_path, _parse_args


def test_resolve_srt_default():
    result = _resolve_srt_path(Path("/videos/movie.mp4"), None)
    assert result == Path("/videos/movie.srt")


def test_resolve_srt_explicit_file():
    result = _resolve_srt_path(Path("/videos/movie.mp4"), "/out/sub.srt")
    assert result == Path("/out/sub.srt")


def test_resolve_srt_directory(tmp_path):
    result = _resolve_srt_path(Path("/videos/movie.mp4"), str(tmp_path))
    assert result == tmp_path / "movie.srt"


def test_parse_args_defaults():
    args = _parse_args(["video.mp4"])
    assert args.filepath == "video.mp4"
    assert args.model == "auto"
    assert args.language == "en"
    assert args.output is None
    assert args.device is None
    assert args.verbose is False


def test_parse_args_custom():
    args = _parse_args(["video.mp4", "--model", "medium", "--language", "fr", "--device", "cpu"])
    assert args.model == "medium"
    assert args.language == "fr"
    assert args.device == "cpu"


def test_parse_args_missing_filepath():
    with pytest.raises(SystemExit):
        _parse_args([])
