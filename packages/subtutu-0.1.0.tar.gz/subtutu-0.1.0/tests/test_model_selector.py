from unittest.mock import patch

from subtitler.model_selector import suggest_model


def _suggest_with_ram(ram_gb, vram_gb=None):
    with patch("subtitler.model_selector._ram_gb", return_value=ram_gb), \
         patch("subtitler.model_selector._cuda_vram_gb", return_value=vram_gb):
        return suggest_model(device="cpu")


def test_low_ram_picks_tiny():
    assert _suggest_with_ram(2.0) == "tiny"


def test_4gb_ram_picks_base():
    assert _suggest_with_ram(4.0) == "base"


def test_8gb_ram_picks_small():
    assert _suggest_with_ram(8.0) == "small"


def test_16gb_ram_picks_medium():
    assert _suggest_with_ram(16.0) == "medium"


def test_cuda_vram_10gb_picks_large():
    with patch("subtitler.model_selector._ram_gb", return_value=32.0), \
         patch("subtitler.model_selector._cuda_vram_gb", return_value=10.0):
        assert suggest_model(device="cuda") == "large-v3"


def test_cuda_vram_5gb_picks_medium():
    with patch("subtitler.model_selector._cuda_vram_gb", return_value=5.0):
        assert suggest_model(device="cuda") == "medium"


def test_cuda_vram_2gb_picks_small():
    with patch("subtitler.model_selector._cuda_vram_gb", return_value=2.0):
        assert suggest_model(device="cuda") == "small"


def test_cuda_vram_1gb_picks_base():
    with patch("subtitler.model_selector._cuda_vram_gb", return_value=1.0):
        assert suggest_model(device="cuda") == "base"
