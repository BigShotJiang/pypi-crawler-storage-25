from pathlib import Path

import pytest

from subtitler.transcriber import _write_srt_manual


def test_write_srt_manual(tmp_path):
    segments = [
        {"start": 0.0, "end": 3.5, "text": " Hello world"},
        {"start": 4.0, "end": 7.2, "text": " How are you"},
    ]
    srt_path = tmp_path / "output.srt"
    _write_srt_manual(segments, srt_path)

    content = srt_path.read_text(encoding="utf-8")
    assert "1\n" in content
    assert "00:00:00,000 --> 00:00:03,500" in content
    assert "Hello world" in content
    assert "2\n" in content
    assert "00:00:04,000 --> 00:00:07,200" in content
    assert "How are you" in content


def test_write_srt_manual_timestamp_format(tmp_path):
    segments = [{"start": 3661.123, "end": 3665.0, "text": " Test"}]
    srt_path = tmp_path / "output.srt"
    _write_srt_manual(segments, srt_path)

    content = srt_path.read_text()
    # 3661.123s = 1h 1m 1s 123ms
    assert "01:01:01,123" in content


def test_write_srt_manual_empty(tmp_path):
    srt_path = tmp_path / "output.srt"
    _write_srt_manual([], srt_path)
    assert srt_path.read_text() == ""
