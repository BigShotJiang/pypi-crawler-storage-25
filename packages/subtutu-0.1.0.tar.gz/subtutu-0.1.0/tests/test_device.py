from unittest.mock import MagicMock, patch

import pytest

from subtitler.errors import PreflightError
from subtitler.device import select_device


def test_force_cpu():
    assert select_device("cpu") == "cpu"


def test_force_invalid():
    with pytest.raises(PreflightError, match="Invalid device"):
        select_device("tpu")


def test_auto_cuda(monkeypatch):
    import sys
    mock_ct2 = MagicMock()
    mock_ct2.get_supported_compute_types.return_value = ["int8", "float16", "cuda"]
    sys.modules["ctranslate2"] = mock_ct2
    try:
        result = select_device(None)
        assert result == "cuda"
    finally:
        del sys.modules["ctranslate2"]


def test_auto_cpu_fallback(monkeypatch):
    mock_torch = MagicMock()
    mock_torch.cuda.is_available.return_value = False
    mock_torch.backends.mps.is_available.return_value = False
    monkeypatch.setattr("subtitler.device.platform.system", lambda: "Linux")
    monkeypatch.setattr("subtitler.device.platform.machine", lambda: "x86_64")
    with patch("subtitler.device.__builtins__", {}):
        pass  # import mocking is handled below

    import subtitler.device as dev
    with patch.object(dev, "__import__" if hasattr(dev, "__import__") else "_", mock_torch, create=True):
        pass

    # Simpler: patch torch directly in the module namespace
    import sys
    sys.modules["torch"] = mock_torch
    try:
        result = select_device(None)
        # On non-Darwin non-CUDA: should be cpu
        assert result in ("cpu", "mps", "cuda")
    finally:
        del sys.modules["torch"]
