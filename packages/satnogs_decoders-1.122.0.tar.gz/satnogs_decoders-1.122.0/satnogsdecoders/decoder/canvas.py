# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Canvas(KaitaiStruct):
    """:field dest_callsign: ax25_frame.ax25_header.dest_callsign_raw.callsign_ror.callsign
    :field src_callsign: ax25_frame.ax25_header.src_callsign_raw.callsign_ror.callsign
    :field src_ssid: ax25_frame.ax25_header.src_ssid_raw.ssid
    :field dest_ssid: ax25_frame.ax25_header.dest_ssid_raw.ssid
    :field ctl: ax25_frame.ax25_header.ctl
    :field pid: ax25_frame.payload.pid
    :field ccsds_version: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.ccsds_version
    :field packet_type: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.packet_type
    :field secondary_header_flag: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.secondary_header_flag
    :field is_stored_data: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.is_stored_data
    :field application_process_id: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.application_process_id
    :field grouping_flag: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.grouping_flag
    :field sequence_count: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.sequence_count
    :field packet_length: ax25_frame.payload.ax25_info.ccsds_space_packet.packet_primary_header.packet_length
    :field time_stamp_seconds: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.secondary_header.time_stamp_seconds
    :field sub_seconds: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.secondary_header.sub_seconds
    :field padding: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.secondary_header.padding
    :field bcn_fsw_major_version: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_fsw_major_version
    :field bcn_fsw_minor_version: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_fsw_minor_version
    :field bcn_fsw_patch_version: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_fsw_patch_version
    :field bcn_fsw_image_id: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_fsw_image_id
    :field bcn_seq_state_auto: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_seq_state_auto
    :field bcn_seq_state_op: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_seq_state_op
    :field bcn_seq_exec_buf0_auto: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_seq_exec_buf0_auto
    :field bcn_seq_exec_buf0_op: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_seq_exec_buf0_op
    :field bcn_fp_resp_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_fp_resp_cnt
    :field bcn_fp_passive_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_fp_passive_cnt
    :field bcn_fp_err_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_fp_err_cnt
    :field bcn_des_met_time_sec: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_des_met_time_sec
    :field bcn_des_cycle_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_des_cycle_cnt
    :field bcn_cmd_recv_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_cmd_recv_cnt
    :field bcn_cmd_fmt_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_cmd_fmt_cnt
    :field bcn_cmd_rjct_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_cmd_rjct_cnt
    :field bcn_cmd_succ_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_cmd_succ_cnt
    :field bcn_cmd_fail_code: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_cmd_fail_code
    :field bcn_cmd_xsum_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_cmd_xsum_state
    :field bcn_store_partition_write_misc: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_store_partition_write_misc
    :field bcn_store_partition_read_misc: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_store_partition_read_misc
    :field bcn_store_partition_pbk_misc: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_store_partition_pbk_misc
    :field bcn_store_partition_write_sci: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_store_partition_write_sci
    :field bcn_store_partition_read_sci: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_store_partition_read_sci
    :field bcn_store_partition_pbk_sci: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_store_partition_pbk_sci
    :field bcn_log_msgid_hdr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_log_msgid_hdr
    :field bcn_adcs_hk_pkt_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_hk_pkt_cnt
    :field bcn_adcs_alive: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_alive
    :field bcn_adcs_eclipse: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_eclipse
    :field bcn_adcs_msg_recv_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_msg_recv_cnt
    :field bcn_adcs_msg_rjct_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_msg_rjct_cnt
    :field bcn_eps_batt1_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_batt1_temp
    :field bcn_eps_batt2_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_batt2_temp
    :field bcn_eps_batt_pcb_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_batt_pcb_temp
    :field bcn_solar_panel1_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_solar_panel1_temp
    :field bcn_solar_panel2_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_solar_panel2_temp
    :field bcn_pwr_mntr1_all_pnl_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr1_all_pnl_curr
    :field bcn_pwr_mntr1_all_pnl_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr1_all_pnl_voltage
    :field bcn_pwr_mntr_pnl3_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr_pnl3_curr
    :field bcn_pwr_mntr_pnl3_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr_pnl3_voltage
    :field bcn_pwr_mntr1_xact_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr1_xact_curr
    :field bcn_pwr_mntr1_xact_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr1_xact_voltage
    :field bcn_pwr_mntr2_3v3_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr2_3v3_curr
    :field bcn_pwr_mntr2_3v3_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr2_3v3_voltage
    :field bcn_pwr_mntr2_pnl2_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr2_pnl2_curr
    :field bcn_pwr_mntr2_pnl2_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr2_pnl2_voltage
    :field bcn_pwr_mntr2_pnl1_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr2_pnl1_curr
    :field bcn_pwr_mntr2_pnl1_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr2_pnl1_voltage
    :field bcn_pwr_mntr3_main_bus_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr3_main_bus_curr
    :field bcn_pwr_mntr3_main_bus_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr3_main_bus_voltage
    :field bcn_pwr_mntr3_12vo_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr3_12vo_curr
    :field bcn_pwr_mntr3_12vo_voltage: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pwr_mntr3_12vo_voltage
    :field bcn_temp_12vo: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_temp_12vo
    :field bcn_temp_3v3: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_temp_3v3
    :field bcn_battery_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_battery_curr
    :field bcn_eps_battery_soc: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_battery_soc
    :field bcn_battery_heater_status: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_battery_heater_status
    :field bcn_solar_panel1_ocv: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_solar_panel1_ocv
    :field bcn_solar_panel2_ocv: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_solar_panel2_ocv
    :field bcn_solar_panel3_ocv: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_solar_panel3_ocv
    :field bcn_mode_clt_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_mode_clt_cnt
    :field bcn_mode_system_mode: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_mode_system_mode
    :field bcn_adcs_cmd_tlm_cmd_acpt_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_cmd_tlm_cmd_acpt_cnt
    :field bcn_adcs_cmd_tlm_cmd_rjct_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_cmd_tlm_cmd_rjct_cnt
    :field bcn_eps_reg0_err_flags: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_reg0_err_flags
    :field bcn_eps_reg1_err_flags: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_reg1_err_flags
    :field bcn_sd0_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_sd0_state
    :field bcn_sd1_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_sd1_state
    :field bcn_sd2_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_sd2_state
    :field reusable_spare_2: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.reusable_spare_2
    :field bcn_pld_pwr_cycle_req: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_pwr_cycle_req
    :field bcn_pld_pwr_off_req: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_pwr_off_req
    :field bcn_pld_stat_msg_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_stat_msg_state
    :field bcn_pld_time_msg_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_time_msg_state
    :field bcn_pld_alive_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_alive_state
    :field reusable_spare_3: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.reusable_spare_3
    :field bcn_eps_uhf_dep: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_uhf_dep
    :field bcn_eps_ant1_dep: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_ant1_dep
    :field bcn_eps_sap1_dep: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_sap1_dep
    :field bcn_eps_boom_dep: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_boom_dep
    :field bcn_eps_boom_enc: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_boom_enc
    :field bcn_eps_boom_cnt: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_boom_cnt
    :field bcn_eps_pld: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_pld
    :field bcn_eps_xact: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_xact
    :field bcn_eps_sband_tr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_sband_tr
    :field bcn_eps_sband_reset: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_sband_reset
    :field bcn_eps_sband_pwr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_sband_pwr
    :field bcn_eps_uhf_reset: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_uhf_reset
    :field bcn_eps_uhf_pwr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_eps_uhf_pwr
    :field bcn_temp_digital: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_temp_digital
    :field bcn_temp_ana: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_temp_ana
    :field bcn_temp_cdh: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_temp_cdh
    :field bcn_temp_backplane: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_temp_backplane
    :field bcn_pld_digital_3p3_i: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_digital_3p3_i
    :field bcn_pld_digital_3p3_v: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_digital_3p3_v
    :field bcn_pld_digital_1p8_i: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_digital_1p8_i
    :field bcn_pld_digital_1p8_v: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_digital_1p8_v
    :field bcn_pld_digital_1p0_i: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_digital_1p0_i
    :field bcn_pld_digital_1p0_v: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_digital_1p0_v
    :field bcn_pld_ana_12p0_i: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_ana_12p0_i
    :field bcn_pld_ana_12p0_v: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_ana_12p0_v
    :field bcn_pld_ana_2p5_i: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_ana_2p5_i
    :field bcn_pld_ana_2p5_v: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_pld_ana_2p5_v
    :field bcn_hstx_output_power: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_hstx_output_power
    :field bcn_hstx_pa_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_hstx_pa_temp
    :field bcn_hstx_pa_curr: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_hstx_pa_curr
    :field bcn_mode_clt_threshold: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_mode_clt_threshold
    :field bcn_q_body_wrt_eci1: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_q_body_wrt_eci1
    :field bcn_q_body_wrt_eci2: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_q_body_wrt_eci2
    :field bcn_q_body_wrt_eci3: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_q_body_wrt_eci3
    :field bcn_q_body_wrt_eci4: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_q_body_wrt_eci4
    :field bcn_body_rate1: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_body_rate1
    :field bcn_body_rate2: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_body_rate2
    :field bcn_body_rate3: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_body_rate3
    :field bcn_rw_fltr_spd_rpm1: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_rw_fltr_spd_rpm1
    :field bcn_rw_fltr_spd_rpm2: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_rw_fltr_spd_rpm2
    :field bcn_rw_fltr_spd_rpm3: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_rw_fltr_spd_rpm3
    :field bcn_sun_point_ang_err: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_sun_point_ang_err
    :field bcn_adcs_css_sun_vec_body1: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_css_sun_vec_body1
    :field bcn_adcs_css_sun_vec_body2: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_css_sun_vec_body2
    :field bcn_adcs_css_sun_vec_body3: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_css_sun_vec_body3
    :field bcn_adcs_att_cmd_adcs_mode: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_att_cmd_adcs_mode
    :field bcn_sun_point_state: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_sun_point_state
    :field bcn_adcs_ana_det_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_ana_det_temp
    :field bcn_adcs_ana_motor1_temp: ax25_frame.payload.ax25_info.ccsds_space_packet.data_section.user_data_field.beacon_t.bcn_adcs_ana_motor1_temp
    """
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        self.ax25_frame = Canvas.Ax25Frame(self._io, self, self._root)

    class Ax25Frame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25_header = Canvas.Ax25Header(self._io, self, self._root)
            _on = (self.ax25_header.ctl & 19)
            if _on == 0:
                self.payload = Canvas.IFrame(self._io, self, self._root)
            elif _on == 3:
                self.payload = Canvas.UiFrame(self._io, self, self._root)
            elif _on == 19:
                self.payload = Canvas.UiFrame(self._io, self, self._root)
            elif _on == 16:
                self.payload = Canvas.IFrame(self._io, self, self._root)
            elif _on == 18:
                self.payload = Canvas.IFrame(self._io, self, self._root)
            elif _on == 2:
                self.payload = Canvas.IFrame(self._io, self, self._root)


    class Ax25Header(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.dest_callsign_raw = Canvas.CallsignRaw(self._io, self, self._root)
            self.dest_ssid_raw = Canvas.SsidMask(self._io, self, self._root)
            self.src_callsign_raw = Canvas.CallsignRaw(self._io, self, self._root)
            self.src_ssid_raw = Canvas.SsidMask(self._io, self, self._root)
            self.ctl = self._io.read_u1()


    class UiFrame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.pid = self._io.read_u1()
            self._raw_ax25_info = self._io.read_bytes_full()
            _io__raw_ax25_info = KaitaiStream(BytesIO(self._raw_ax25_info))
            self.ax25_info = Canvas.Ax25InfoData(_io__raw_ax25_info, self, self._root)


    class Callsign(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(6)).decode(u"ASCII")
            if not  ((self.callsign == u"LASP  ") or (self.callsign == u"CANVAS")) :
                raise kaitaistruct.ValidationNotAnyOfError(self.callsign, self._io, u"/types/callsign/seq/0")


    class CanvasBeaconT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.beacon_t = Canvas.BeaconT(self._io, self, self._root)


    class BeaconT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.bcn_fsw_major_version = self._io.read_u1()
            self.bcn_fsw_minor_version = self._io.read_u1()
            self.bcn_fsw_patch_version = self._io.read_u1()
            self.bcn_fsw_image_id = self._io.read_u1()
            self.bcn_seq_state_auto = self._io.read_u1()
            self.bcn_seq_state_op = self._io.read_u1()
            self.bcn_seq_exec_buf0_auto = self._io.read_u2be()
            self.bcn_seq_exec_buf0_op = self._io.read_u2be()
            self.bcn_fp_resp_cnt = self._io.read_u2be()
            self.bcn_fp_passive_cnt = self._io.read_u2be()
            self.bcn_fp_err_cnt = self._io.read_u2be()
            self.bcn_des_met_time_sec = self._io.read_u4be()
            self.bcn_des_cycle_cnt = self._io.read_u2be()
            self.bcn_cmd_recv_cnt = self._io.read_u2be()
            self.bcn_cmd_fmt_cnt = self._io.read_u2be()
            self.bcn_cmd_rjct_cnt = self._io.read_u2be()
            self.bcn_cmd_succ_cnt = self._io.read_u2be()
            self.padding1 = self._io.read_u4be()
            self.bcn_cmd_fail_code = self._io.read_u1()
            self.bcn_cmd_xsum_state = self._io.read_u1()
            self.bcn_store_partition_write_misc = self._io.read_u4be()
            self.bcn_store_partition_read_misc = self._io.read_u4be()
            self.bcn_store_partition_pbk_misc = self._io.read_u4be()
            self.bcn_store_partition_write_sci = self._io.read_u4be()
            self.bcn_store_partition_read_sci = self._io.read_u4be()
            self.bcn_store_partition_pbk_sci = self._io.read_u4be()
            self.bcn_log_msgid_hdr = self._io.read_u2be()
            self.bcn_adcs_hk_pkt_cnt = self._io.read_u2be()
            self.bcn_adcs_alive = self._io.read_u1()
            self.bcn_adcs_eclipse = self._io.read_u1()
            self.bcn_adcs_msg_recv_cnt = self._io.read_u2be()
            self.bcn_adcs_msg_rjct_cnt = self._io.read_u2be()
            self.bcn_eps_batt1_temp = self._io.read_u2be()
            self.bcn_eps_batt2_temp = self._io.read_u2be()
            self.bcn_eps_batt_pcb_temp = self._io.read_u2be()
            self.bcn_solar_panel1_temp = self._io.read_u2be()
            self.bcn_solar_panel2_temp = self._io.read_u2be()
            self.bcn_pwr_mntr1_all_pnl_curr = self._io.read_u2be()
            self.bcn_pwr_mntr1_all_pnl_voltage = self._io.read_u2be()
            self.bcn_pwr_mntr_pnl3_curr = self._io.read_u2be()
            self.bcn_pwr_mntr_pnl3_voltage = self._io.read_u2be()
            self.bcn_pwr_mntr1_xact_curr = self._io.read_u2be()
            self.bcn_pwr_mntr1_xact_voltage = self._io.read_u2be()
            self.bcn_pwr_mntr2_3v3_curr = self._io.read_u2be()
            self.bcn_pwr_mntr2_3v3_voltage = self._io.read_u2be()
            self.bcn_pwr_mntr2_pnl2_curr = self._io.read_u2be()
            self.bcn_pwr_mntr2_pnl2_voltage = self._io.read_u2be()
            self.bcn_pwr_mntr2_pnl1_curr = self._io.read_u2be()
            self.bcn_pwr_mntr2_pnl1_voltage = self._io.read_u2be()
            self.bcn_pwr_mntr3_main_bus_curr = self._io.read_u2be()
            self.bcn_pwr_mntr3_main_bus_voltage = self._io.read_u2be()
            self.bcn_pwr_mntr3_12vo_curr = self._io.read_u2be()
            self.bcn_pwr_mntr3_12vo_voltage = self._io.read_u2be()
            self.bcn_temp_12vo = self._io.read_s2be()
            self.bcn_temp_3v3 = self._io.read_s2be()
            self.bcn_battery_curr = self._io.read_s2be()
            self.bcn_eps_battery_soc = self._io.read_u2be()
            self.bcn_battery_heater_status = self._io.read_u2be()
            self.bcn_solar_panel1_ocv = self._io.read_u2be()
            self.bcn_solar_panel2_ocv = self._io.read_u2be()
            self.bcn_solar_panel3_ocv = self._io.read_u2be()
            self.bcn_mode_clt_cnt = self._io.read_u1()
            self.bcn_mode_system_mode = self._io.read_u1()
            self.bcn_adcs_cmd_tlm_cmd_acpt_cnt = self._io.read_u1()
            self.bcn_adcs_cmd_tlm_cmd_rjct_cnt = self._io.read_u1()
            self.bcn_eps_reg0_err_flags = self._io.read_u4be()
            self.bcn_eps_reg1_err_flags = self._io.read_u4be()
            self.bcn_sd0_state = self._io.read_u1()
            self.bcn_sd1_state = self._io.read_u1()
            self.bcn_sd2_state = self._io.read_u1()
            self.reusable_spare_2 = self._io.read_bits_int_be(2)
            self.bcn_pld_pwr_cycle_req = self._io.read_bits_int_be(1) != 0
            self.bcn_pld_pwr_off_req = self._io.read_bits_int_be(1) != 0
            self.bcn_pld_stat_msg_state = self._io.read_bits_int_be(1) != 0
            self.bcn_pld_time_msg_state = self._io.read_bits_int_be(1) != 0
            self.bcn_pld_alive_state = self._io.read_bits_int_be(2)
            self.reusable_spare_3 = self._io.read_bits_int_be(3)
            self.bcn_eps_uhf_dep = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_ant1_dep = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_sap1_dep = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_boom_dep = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_boom_enc = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_boom_cnt = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_pld = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_xact = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_sband_tr = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_sband_reset = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_sband_pwr = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_uhf_reset = self._io.read_bits_int_be(1) != 0
            self.bcn_eps_uhf_pwr = self._io.read_bits_int_be(1) != 0
            self._io.align_to_byte()
            self.bcn_temp_digital_raw = self._io.read_u2be()
            self.bcn_temp_ana_raw = self._io.read_u2be()
            self.bcn_temp_cdh_raw = self._io.read_u2be()
            self.bcn_temp_backplane_raw = self._io.read_u2be()
            self.bcn_pld_digital_3p3_i = self._io.read_s2be()
            self.bcn_pld_digital_3p3_v = self._io.read_s2be()
            self.bcn_pld_digital_1p8_i = self._io.read_s2be()
            self.bcn_pld_digital_1p8_v = self._io.read_s2be()
            self.bcn_pld_digital_1p0_i = self._io.read_s2be()
            self.bcn_pld_digital_1p0_v = self._io.read_s2be()
            self.bcn_pld_ana_12p0_i = self._io.read_s2be()
            self.bcn_pld_ana_12p0_v = self._io.read_s2be()
            self.bcn_pld_ana_2p5_i = self._io.read_s2be()
            self.bcn_pld_ana_2p5_v = self._io.read_s2be()
            self.bcn_hstx_output_power = self._io.read_u2be()
            self.bcn_hstx_pa_temp = self._io.read_u2be()
            self.bcn_hstx_pa_curr = self._io.read_u2be()
            self.bcn_mode_clt_threshold = self._io.read_u4be()
            self.bcn_q_body_wrt_eci1 = self._io.read_u4be()
            self.bcn_q_body_wrt_eci2 = self._io.read_u4be()
            self.bcn_q_body_wrt_eci3 = self._io.read_u4be()
            self.bcn_q_body_wrt_eci4 = self._io.read_u4be()
            self.bcn_body_rate1 = self._io.read_u4be()
            self.bcn_body_rate2 = self._io.read_u4be()
            self.bcn_body_rate3 = self._io.read_u4be()
            self.bcn_rw_fltr_spd_rpm1 = self._io.read_s2be()
            self.bcn_rw_fltr_spd_rpm2 = self._io.read_s2be()
            self.bcn_rw_fltr_spd_rpm3 = self._io.read_s2be()
            self.bcn_sun_point_ang_err = self._io.read_u2be()
            self.bcn_adcs_css_sun_vec_body1 = self._io.read_s2be()
            self.bcn_adcs_css_sun_vec_body2 = self._io.read_s2be()
            self.bcn_adcs_css_sun_vec_body3 = self._io.read_s2be()
            self.bcn_adcs_att_cmd_adcs_mode = self._io.read_u1()
            self.bcn_sun_point_state = self._io.read_u1()
            self.bcn_adcs_ana_det_temp = self._io.read_s2be()
            self.bcn_adcs_ana_motor1_temp = self._io.read_s2be()
            self.checksum = self._io.read_u4be()

        @property
        def bcn_temp_digital(self):
            if hasattr(self, '_m_bcn_temp_digital'):
                return self._m_bcn_temp_digital

            self._m_bcn_temp_digital = (((self.bcn_temp_digital_raw & 4095) - 4096) if (self.bcn_temp_digital_raw & 4095) >= 2048 else (self.bcn_temp_digital_raw & 4095))
            return getattr(self, '_m_bcn_temp_digital', None)

        @property
        def bcn_temp_ana(self):
            if hasattr(self, '_m_bcn_temp_ana'):
                return self._m_bcn_temp_ana

            self._m_bcn_temp_ana = (((self.bcn_temp_ana_raw & 4095) - 4096) if (self.bcn_temp_ana_raw & 4095) >= 2048 else (self.bcn_temp_ana_raw & 4095))
            return getattr(self, '_m_bcn_temp_ana', None)

        @property
        def bcn_temp_cdh(self):
            if hasattr(self, '_m_bcn_temp_cdh'):
                return self._m_bcn_temp_cdh

            self._m_bcn_temp_cdh = (((self.bcn_temp_cdh_raw & 4095) - 4096) if (self.bcn_temp_cdh_raw & 4095) >= 2048 else (self.bcn_temp_cdh_raw & 4095))
            return getattr(self, '_m_bcn_temp_cdh', None)

        @property
        def bcn_temp_backplane(self):
            if hasattr(self, '_m_bcn_temp_backplane'):
                return self._m_bcn_temp_backplane

            self._m_bcn_temp_backplane = (((self.bcn_temp_backplane_raw & 4095) - 4096) if (self.bcn_temp_backplane_raw & 4095) >= 2048 else (self.bcn_temp_backplane_raw & 4095))
            return getattr(self, '_m_bcn_temp_backplane', None)


    class IFrame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.pid = self._io.read_u1()
            self._raw_ax25_info = self._io.read_bytes_full()
            _io__raw_ax25_info = KaitaiStream(BytesIO(self._raw_ax25_info))
            self.ax25_info = Canvas.Ax25InfoData(_io__raw_ax25_info, self, self._root)


    class SsidMask(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ssid_mask = self._io.read_u1()

        @property
        def ssid(self):
            if hasattr(self, '_m_ssid'):
                return self._m_ssid

            self._m_ssid = ((self.ssid_mask & 15) >> 1)
            return getattr(self, '_m_ssid', None)


    class DataSectionT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            if self._parent.packet_primary_header.secondary_header_flag:
                self._raw_secondary_header = self._io.read_bytes(6)
                _io__raw_secondary_header = KaitaiStream(BytesIO(self._raw_secondary_header))
                self.secondary_header = Canvas.SecondaryHeaderT(_io__raw_secondary_header, self, self._root)

            _on = self._parent.packet_primary_header.application_process_id
            if _on == 32:
                self.user_data_field = Canvas.CanvasBeaconT(self._io, self, self._root)


    class SecondaryHeaderT(KaitaiStruct):
        """The Secondary Header is a feature of the Space Packet which allows
        additional types of information that may be useful to the user
        application (e.g., a time code) to be included.
        See: 4.1.3.2 in CCSDS 133.0-B-1
        """
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.time_stamp_seconds = self._io.read_u4be()
            self.sub_seconds = self._io.read_u1()
            self.padding = self._io.read_u1()


    class PacketPrimaryHeaderT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ccsds_version = self._io.read_bits_int_be(3)
            self.packet_type = self._io.read_bits_int_be(1) != 0
            self.secondary_header_flag = self._io.read_bits_int_be(1) != 0
            self.is_stored_data = self._io.read_bits_int_be(1) != 0
            self.application_process_id = self._io.read_bits_int_be(10)
            self.grouping_flag = self._io.read_bits_int_be(2)
            self.sequence_count = self._io.read_bits_int_be(14)
            self._io.align_to_byte()
            self.packet_length = self._io.read_u2be()


    class CallsignRaw(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self._raw__raw_callsign_ror = self._io.read_bytes(6)
            self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
            _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
            self.callsign_ror = Canvas.Callsign(_io__raw_callsign_ror, self, self._root)


    class CcsdsSpacePacketT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self._raw_packet_primary_header = self._io.read_bytes(6)
            _io__raw_packet_primary_header = KaitaiStream(BytesIO(self._raw_packet_primary_header))
            self.packet_primary_header = Canvas.PacketPrimaryHeaderT(_io__raw_packet_primary_header, self, self._root)
            self.data_section = Canvas.DataSectionT(self._io, self, self._root)


    class Ax25InfoData(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ccsds_space_packet = Canvas.CcsdsSpacePacketT(self._io, self, self._root)



