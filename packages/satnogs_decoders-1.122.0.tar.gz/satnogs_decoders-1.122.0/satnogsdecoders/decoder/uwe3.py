# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Uwe3(KaitaiStruct):
    """:field dest_callsign: ax25_frame.ax25_header.dest_callsign_raw.callsign_ror.callsign
    :field src_callsign: ax25_frame.ax25_header.src_callsign_raw.callsign_ror.callsign
    :field src_ssid: ax25_frame.ax25_header.src_ssid_raw.ssid
    :field dest_ssid: ax25_frame.ax25_header.dest_ssid_raw.ssid
    :field ctl: ax25_frame.ax25_header.ctl
    :field pid: ax25_frame.payload.pid
    :field beacon_header_flags1: ax25_frame.payload.ax25_info.beacon_header.beacon_header_flags1
    :field beacon_header_flags2: ax25_frame.payload.ax25_info.beacon_header.beacon_header_flags2
    :field beacon_header_packet_id: ax25_frame.payload.ax25_info.beacon_header.beacon_header_packet_id
    :field beacon_header_fm_system_id: ax25_frame.payload.ax25_info.beacon_header.beacon_header_fm_system_id
    :field beacon_header_fm_subsystem_id: ax25_frame.payload.ax25_info.beacon_header.beacon_header_fm_subsystem_id
    :field beacon_header_to_system_id: ax25_frame.payload.ax25_info.beacon_header.beacon_header_to_system_id
    :field beacon_header_to_subsystem_id: ax25_frame.payload.ax25_info.beacon_header.beacon_header_to_subsystem_id
    :field beacon_header_api: ax25_frame.payload.ax25_info.beacon_header.beacon_header_api
    :field beacon_payload_command: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_command
    :field beacon_payload_vals_out_of_range: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_vals_out_of_range
    :field beacon_payload_beacon_rate: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_beacon_rate
    :field beacon_payload_uptime: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_uptime
    :field beacon_payload_rtc: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_rtc
    :field beacon_payload_rtc_unix: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_rtc_unix
    :field beacon_payload_state_raw: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_state_raw
    :field beacon_payload_batt_a_state_of_charge: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_a_state_of_charge
    :field beacon_payload_batt_b_state_of_charge: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_b_state_of_charge
    :field beacon_payload_batt_a_voltage: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_a_voltage
    :field beacon_payload_batt_a_current: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_a_current
    :field beacon_payload_batt_a_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_a_temp
    :field beacon_payload_batt_b_voltage: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_b_voltage
    :field beacon_payload_batt_b_current: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_b_current
    :field beacon_payload_batt_b_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_batt_b_temp
    :field beacon_payload_power_consumption: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_power_consumption
    :field beacon_payload_obc_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_obc_temp
    :field beacon_payload_panel_neg_x_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_panel_neg_x_temp
    :field beacon_payload_panel_pos_x_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_panel_pos_x_temp
    :field beacon_payload_panel_neg_y_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_panel_neg_y_temp
    :field beacon_payload_panel_pos_y_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_panel_pos_y_temp
    :field beacon_payload_panel_neg_z_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_panel_neg_z_temp
    :field beacon_payload_panel_pos_z_temp: ax25_frame.payload.ax25_info.beacon_payload.beacon_payload_panel_pos_z_temp
    
    .. seealso::
       'https://db.satnogs.org/satellite/GGFD-1283-2408-9916-0714/'
       'https://www.informatik.uni-wuerzburg.de/en/aerospaceinfo/missions/uwe-3/'
    """
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        self.ax25_frame = Uwe3.Ax25Frame(self._io, self, self._root)

    class Ax25Frame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25_header = Uwe3.Ax25Header(self._io, self, self._root)
            _on = (self.ax25_header.ctl & 19)
            if _on == 0:
                self.payload = Uwe3.IFrame(self._io, self, self._root)
            elif _on == 3:
                self.payload = Uwe3.UiFrame(self._io, self, self._root)
            elif _on == 19:
                self.payload = Uwe3.UiFrame(self._io, self, self._root)
            elif _on == 16:
                self.payload = Uwe3.IFrame(self._io, self, self._root)
            elif _on == 18:
                self.payload = Uwe3.IFrame(self._io, self, self._root)
            elif _on == 2:
                self.payload = Uwe3.IFrame(self._io, self, self._root)


    class Ax25Header(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.dest_callsign_raw = Uwe3.CallsignRaw(self._io, self, self._root)
            self.dest_ssid_raw = Uwe3.SsidMask(self._io, self, self._root)
            self.src_callsign_raw = Uwe3.CallsignRaw(self._io, self, self._root)
            self.src_ssid_raw = Uwe3.SsidMask(self._io, self, self._root)
            self.ctl = self._io.read_u1()


    class HskpPayload(KaitaiStruct):
        """33-byte UWE-3 housekeeping payload. Field layout empirically confirmed
        from 270 real SatNOGS frames (NORAD 39446, 2013-2016) and cross-validated
        against the DK3WN reference decoder. Byte offsets are relative to the
        start of this payload (ax25_info byte 8).
        
        RTC field (bytes 7-10): 4-byte little-endian NTP timestamp, seconds since
        1900-01-01 00:00:00 UTC. Confirmed by community member dl7ndr on the
        SatNOGS forum: bytes 33-35 (1-indexed from frame start) carry the
        satellite RTC and give 0.25-minute resolution in the upper byte.
        Verified on the JA0CAW frame (2020-04-29T20:20:10Z): NTP value
        3797180836 decodes to 2020-04-29 20:27:16 UTC, matching DK3WN display.
        """
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.beacon_payload_command = self._io.read_u1()
            self.beacon_payload_vals_out_of_range = self._io.read_u1()
            self.beacon_payload_beacon_rate = self._io.read_u1()
            self.beacon_payload_uptime_raw = []
            for i in range(3):
                self.beacon_payload_uptime_raw.append(self._io.read_u1())

            self.beacon_payload_uptime_pad = self._io.read_u1()
            self.beacon_payload_rtc = self._io.read_u4le()
            self.beacon_payload_state_raw = self._io.read_u1()
            self.beacon_payload_batt_a_state_of_charge = self._io.read_u1()
            self.beacon_payload_batt_b_state_of_charge = self._io.read_u1()
            self.beacon_payload_batt_a_voltage = self._io.read_u2le()
            self.beacon_payload_batt_a_current = self._io.read_s2le()
            self.beacon_payload_batt_a_temp = self._io.read_s1()
            self.beacon_payload_batt_b_voltage = self._io.read_u2le()
            self.beacon_payload_batt_b_current = self._io.read_s2le()
            self.beacon_payload_batt_b_temp = self._io.read_s1()
            self.beacon_payload_power_consumption = self._io.read_u2le()
            self.beacon_payload_obc_temp = self._io.read_s1()
            self.beacon_payload_panel_neg_x_temp = self._io.read_s1()
            self.beacon_payload_panel_pos_x_temp = self._io.read_s1()
            self.beacon_payload_panel_neg_y_temp = self._io.read_s1()
            self.beacon_payload_panel_pos_y_temp = self._io.read_s1()
            self.beacon_payload_panel_neg_z_temp = self._io.read_s1()
            self.beacon_payload_panel_pos_z_temp = self._io.read_s1()

        @property
        def beacon_payload_rtc_unix(self):
            """[s] RTC as Unix timestamp (seconds since 1970-01-01 00:00:00 UTC; NTP epoch offset = 2208988800)."""
            if hasattr(self, '_m_beacon_payload_rtc_unix'):
                return self._m_beacon_payload_rtc_unix

            self._m_beacon_payload_rtc_unix = (self.beacon_payload_rtc - 2208988800)
            return getattr(self, '_m_beacon_payload_rtc_unix', None)

        @property
        def beacon_payload_panel_neg_x_temp_degc(self):
            """[degC] -X panel temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_panel_neg_x_temp_degc'):
                return self._m_beacon_payload_panel_neg_x_temp_degc

            self._m_beacon_payload_panel_neg_x_temp_degc = (self.beacon_payload_panel_neg_x_temp / 2.0)
            return getattr(self, '_m_beacon_payload_panel_neg_x_temp_degc', None)

        @property
        def beacon_payload_uptime(self):
            """[s] Uptime in seconds (computed from 3-byte little-endian field)."""
            if hasattr(self, '_m_beacon_payload_uptime'):
                return self._m_beacon_payload_uptime

            self._m_beacon_payload_uptime = ((self.beacon_payload_uptime_raw[0] + (self.beacon_payload_uptime_raw[1] << 8)) + (self.beacon_payload_uptime_raw[2] << 16))
            return getattr(self, '_m_beacon_payload_uptime', None)

        @property
        def beacon_payload_panel_neg_y_temp_degc(self):
            """[degC] -Y panel temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_panel_neg_y_temp_degc'):
                return self._m_beacon_payload_panel_neg_y_temp_degc

            self._m_beacon_payload_panel_neg_y_temp_degc = (self.beacon_payload_panel_neg_y_temp / 2.0)
            return getattr(self, '_m_beacon_payload_panel_neg_y_temp_degc', None)

        @property
        def beacon_payload_panel_pos_z_temp_degc(self):
            """[degC] +Z panel temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_panel_pos_z_temp_degc'):
                return self._m_beacon_payload_panel_pos_z_temp_degc

            self._m_beacon_payload_panel_pos_z_temp_degc = (self.beacon_payload_panel_pos_z_temp / 2.0)
            return getattr(self, '_m_beacon_payload_panel_pos_z_temp_degc', None)

        @property
        def beacon_payload_batt_b_temp_degc(self):
            """[degC] Battery B temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_batt_b_temp_degc'):
                return self._m_beacon_payload_batt_b_temp_degc

            self._m_beacon_payload_batt_b_temp_degc = (self.beacon_payload_batt_b_temp / 2.0)
            return getattr(self, '_m_beacon_payload_batt_b_temp_degc', None)

        @property
        def beacon_payload_panel_neg_z_temp_degc(self):
            """[degC] -Z panel temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_panel_neg_z_temp_degc'):
                return self._m_beacon_payload_panel_neg_z_temp_degc

            self._m_beacon_payload_panel_neg_z_temp_degc = (self.beacon_payload_panel_neg_z_temp / 2.0)
            return getattr(self, '_m_beacon_payload_panel_neg_z_temp_degc', None)

        @property
        def beacon_payload_batt_a_temp_degc(self):
            """[degC] Battery A temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_batt_a_temp_degc'):
                return self._m_beacon_payload_batt_a_temp_degc

            self._m_beacon_payload_batt_a_temp_degc = (self.beacon_payload_batt_a_temp / 2.0)
            return getattr(self, '_m_beacon_payload_batt_a_temp_degc', None)

        @property
        def beacon_payload_panel_pos_y_temp_degc(self):
            """[degC] +Y panel temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_panel_pos_y_temp_degc'):
                return self._m_beacon_payload_panel_pos_y_temp_degc

            self._m_beacon_payload_panel_pos_y_temp_degc = (self.beacon_payload_panel_pos_y_temp / 2.0)
            return getattr(self, '_m_beacon_payload_panel_pos_y_temp_degc', None)

        @property
        def beacon_payload_panel_pos_x_temp_degc(self):
            """[degC] +X panel temperature (physical, raw / 2.0)."""
            if hasattr(self, '_m_beacon_payload_panel_pos_x_temp_degc'):
                return self._m_beacon_payload_panel_pos_x_temp_degc

            self._m_beacon_payload_panel_pos_x_temp_degc = (self.beacon_payload_panel_pos_x_temp / 2.0)
            return getattr(self, '_m_beacon_payload_panel_pos_x_temp_degc', None)


    class UiFrame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.pid = self._io.read_u1()
            self._raw_ax25_info = self._io.read_bytes_full()
            _io__raw_ax25_info = KaitaiStream(BytesIO(self._raw_ax25_info))
            self.ax25_info = Uwe3.Beacon(_io__raw_ax25_info, self, self._root)


    class Callsign(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(6)).decode(u"ASCII")
            if not  ((self.callsign == u"DP0UWG") or (self.callsign == u"DD0UWE")) :
                raise kaitaistruct.ValidationNotAnyOfError(self.callsign, self._io, u"/types/callsign/seq/0")


    class IFrame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.pid = self._io.read_u1()
            self.ax25_info = self._io.read_bytes_full()


    class SsidMask(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ssid_mask = self._io.read_u1()

        @property
        def ssid(self):
            if hasattr(self, '_m_ssid'):
                return self._m_ssid

            self._m_ssid = ((self.ssid_mask & 15) >> 1)
            return getattr(self, '_m_ssid', None)


    class Beacon(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.beacon_header = Uwe3.BeaconHeader(self._io, self, self._root)
            if self.is_valid_payload:
                self.beacon_payload = Uwe3.HskpPayload(self._io, self, self._root)


        @property
        def is_valid_payload(self):
            """Validates UWE-3 housekeeping frames: fm_system_id=100 (0x64),
            fm_subsystem_id=100 (0x64), api=33 (0x21).
            """
            if hasattr(self, '_m_is_valid_payload'):
                return self._m_is_valid_payload

            self._m_is_valid_payload =  ((self.beacon_header.beacon_header_fm_system_id == 100) and (self.beacon_header.beacon_header_fm_subsystem_id == 100) and (self.beacon_header.beacon_header_api == 33)) 
            return getattr(self, '_m_is_valid_payload', None)


    class BeaconHeader(KaitaiStruct):
        """8-byte beacon header preceding the 33-byte housekeeping payload.
        """
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.beacon_header_flags1 = self._io.read_u1()
            self.beacon_header_flags2 = self._io.read_u1()
            self.beacon_header_packet_id = self._io.read_u1()
            self.beacon_header_fm_system_id = self._io.read_u1()
            self.beacon_header_fm_subsystem_id = self._io.read_u1()
            self.beacon_header_to_system_id = self._io.read_u1()
            self.beacon_header_to_subsystem_id = self._io.read_u1()
            self.beacon_header_api = self._io.read_u1()


    class CallsignRaw(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self._raw__raw_callsign_ror = self._io.read_bytes(6)
            self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
            _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
            self.callsign_ror = Uwe3.Callsign(_io__raw_callsign_ror, self, self._root)



