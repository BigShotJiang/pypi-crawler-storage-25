# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Arica2(KaitaiStruct):
    """:field command_id: id1.id2.command_id
    :field setup_mode_completed: id1.id2.setup_mode_completed
    :field antenna_deployed: id1.id2.antenna_deployed
    :field spresense1_subcore_status_sub1: id1.id2.spresense1_subcore_status_sub1
    :field spresense1_subcore_status_sub2: id1.id2.spresense1_subcore_status_sub2
    :field spresense1_subcore_status_sub3: id1.id2.spresense1_subcore_status_sub3
    :field spresense1_subcore_status_sub4: id1.id2.spresense1_subcore_status_sub4
    :field spresense1_subcore_status_sub5: id1.id2.spresense1_subcore_status_sub5
    :field spresense2_subcore_status_sub1: id1.id2.spresense2_subcore_status_sub1
    :field spresense2_subcore_status_sub2: id1.id2.spresense2_subcore_status_sub2
    :field spresense2_subcore_status_sub3: id1.id2.spresense2_subcore_status_sub3
    :field spresense2_subcore_status_sub5: id1.id2.spresense2_subcore_status_sub5
    :field device_error_eps: id1.id2.device_error_eps
    :field device_error_sbd: id1.id2.device_error_sbd
    :field device_error_stx3: id1.id2.device_error_stx3
    :field device_error_uhf: id1.id2.device_error_uhf
    :field device_error_spr2: id1.id2.device_error_spr2
    :field ir_sensor_1_sleep_mode: id1.id2.ir_sensor_1_sleep_mode
    :field ir_sensor_2_power_on: id1.id2.ir_sensor_2_power_on
    :field adc_possible: id1.id2.adc_possible
    :field motor_driver_power_on: id1.id2.motor_driver_power_on
    :field imu_power_on: id1.id2.imu_power_on
    :field count_of_mode_change_to_power_saving_mode: id1.id2.count_of_mode_change_to_power_saving_mode
    :field reboot_count_of_spresense_1: id1.id2.reboot_count_of_spresense_1
    :field reboot_count_of_spresense_2: id1.id2.reboot_count_of_spresense_2
    :field communication_to_another_spresense: id1.id2.communication_to_another_spresense
    :field angular_velocity_x: id1.id2.angular_velocity_x
    :field angular_velocity_y: id1.id2.angular_velocity_y
    :field angular_velocity_z: id1.id2.angular_velocity_z
    :field ir_sensor_2_checks_the_earth: id1.id2.ir_sensor_2_checks_the_earth
    :field ir_sensor_1_checks_the_earth: id1.id2.ir_sensor_1_checks_the_earth
    :field count_of_attitude_control: id1.id2.count_of_attitude_control
    :field mode_spresense_1: id1.id2.mode_spresense_1
    :field mode_spresense_2: id1.id2.mode_spresense_2
    :field beacon_type: id1.id2.beacon_type
    
    :field thumbnail_preparation: id1.id2.thumbnail_preparation
    :field jpeg_image_preparation: id1.id2.jpeg_image_preparation
    :field gps_update: id1.id2.gps_update
    :field latitude_deg_only: id1.id2.latitude_deg_only
    :field longitude_deg_only: id1.id2.longitude_deg_only
    :field altitude_km: id1.id2.altitude_km
    :field gps_time: id1.id2.gps_time
    :field beacon_type: id1.id2.beacon_type
    
    :field battery_daughter_board_1_temp: id1.id2.battery_daughter_board_1_temp
    :field battery_heater: id1.id2.battery_heater
    :field power_flow_status: id1.id2.power_flow_status
    :field pdm_status_icm20948_2: id1.id2.pdm_status_icm20948_2
    :field pdm_status_icm20948_1: id1.id2.pdm_status_icm20948_1
    :field pdm_status_stx3: id1.id2.pdm_status_stx3
    :field pdm_status_spresense2: id1.id2.pdm_status_spresense2
    :field pdm_status_spresense1: id1.id2.pdm_status_spresense1
    :field pdm_status_gamma_ray_detector: id1.id2.pdm_status_gamma_ray_detector
    :field pdm_status_sbd: id1.id2.pdm_status_sbd
    :field pdm_status_nchrome_wire_cutter: id1.id2.pdm_status_nchrome_wire_cutter
    :field last_command_id_sbd: id1.id2.last_command_id_sbd
    :field uhf_communication_device_temp: id1.id2.uhf_communication_device_temp
    :field count_of_uplink_uhf: id1.id2.count_of_uplink_uhf
    :field voltage_of_received_radio: id1.id2.voltage_of_received_radio
    :field battery_voltage: id1.id2.battery_voltage
    :field beacon_type: id1.id2.beacon_type
    
    :field dest_callsign: id1.id2.ax25_frame.ax25_header.dest_callsign_raw.callsign_ror.callsign
    :field src_callsign: id1.id2.ax25_frame.ax25_header.src_callsign_raw.callsign_ror.callsign
    :field message: id1.id2.ax25_frame.ax25_info.message
    
    
    :field no_form_command_id: id1.id2.no_form_command_id
    :field no_form_setup_mode_completed: id1.id2.no_form_setup_mode_completed
    :field no_form_antenna_deployed: id1.id2.no_form_antenna_deployed
    :field no_form_spresense1_subcore_status_sub1: id1.id2.no_form_spresense1_subcore_status_sub1
    :field no_form_spresense1_subcore_status_sub2: id1.id2.no_form_spresense1_subcore_status_sub2
    :field no_form_spresense1_subcore_status_sub3: id1.id2.no_form_spresense1_subcore_status_sub3
    :field no_form_spresense1_subcore_status_sub4: id1.id2.no_form_spresense1_subcore_status_sub4
    :field no_form_spresense1_subcore_status_sub5: id1.id2.no_form_spresense1_subcore_status_sub5
    :field no_form_spresense2_subcore_status_sub1: id1.id2.no_form_spresense2_subcore_status_sub1
    :field no_form_spresense2_subcore_status_sub2: id1.id2.no_form_spresense2_subcore_status_sub2
    :field no_form_spresense2_subcore_status_sub3: id1.id2.no_form_spresense2_subcore_status_sub3
    :field no_form_spresense2_subcore_status_sub5: id1.id2.no_form_spresense2_subcore_status_sub5
    :field no_form_device_error_eps: id1.id2.no_form_device_error_eps
    :field no_form_device_error_sbd: id1.id2.no_form_device_error_sbd
    :field no_form_device_error_stx3: id1.id2.no_form_device_error_stx3
    :field no_form_device_error_uhf: id1.id2.no_form_device_error_uhf
    :field no_form_device_error_spr2: id1.id2.no_form_device_error_spr2
    :field no_form_ir_sensor_1_sleep_mode: id1.id2.no_form_ir_sensor_1_sleep_mode
    :field no_form_ir_sensor_2_power_on: id1.id2.no_form_ir_sensor_2_power_on
    :field no_form_adc_possible: id1.id2.no_form_adc_possible
    :field no_form_motor_driver_power_on: id1.id2.no_form_motor_driver_power_on
    :field no_form_imu_power_on: id1.id2.no_form_imu_power_on
    :field no_form_count_of_mode_change_to_power_saving_mode: id1.id2.no_form_count_of_mode_change_to_power_saving_mode
    :field no_form_reboot_count_of_spresense_1: id1.id2.no_form_reboot_count_of_spresense_1
    :field no_form_reboot_count_of_spresense_2: id1.id2.no_form_reboot_count_of_spresense_2
    :field no_form_communication_to_another_spresense: id1.id2.no_form_communication_to_another_spresense
    :field no_form_angular_velocity_x: id1.id2.no_form_angular_velocity_x
    :field no_form_angular_velocity_y: id1.id2.no_form_angular_velocity_y
    :field no_form_angular_velocity_z: id1.id2.no_form_angular_velocity_z
    :field no_form_ir_sensor_2_checks_the_earth: id1.id2.no_form_ir_sensor_2_checks_the_earth
    :field no_form_ir_sensor_1_checks_the_earth: id1.id2.no_form_ir_sensor_1_checks_the_earth
    :field no_form_count_of_attitude_control: id1.id2.no_form_count_of_attitude_control
    :field no_form_mode_spresense_1: id1.id2.no_form_mode_spresense_1
    :field no_form_mode_spresense_2: id1.id2.no_form_mode_spresense_2
    :field no_form_beacon_type: id1.id2.no_form_beacon_type
    
    :field no_form_thumbnail_preparation: id1.id2.no_form_thumbnail_preparation
    :field no_form_jpeg_image_preparation: id1.id2.no_form_jpeg_image_preparation
    :field no_form_gps_update: id1.id2.no_form_gps_update
    :field no_form_latitude_deg_only: id1.id2.no_form_latitude_deg_only
    :field no_form_longitude_deg_only: id1.id2.no_form_longitude_deg_only
    :field no_form_altitude_km: id1.id2.no_form_altitude_km
    :field no_form_gps_time: id1.id2.no_form_gps_time
    :field no_form_beacon_type: id1.id2.no_form_beacon_type
    
    :field no_form_battery_daughter_board_1_temp: id1.id2.no_form_battery_daughter_board_1_temp
    :field no_form_battery_heater: id1.id2.no_form_battery_heater
    :field no_form_power_flow_status: id1.id2.no_form_power_flow_status
    :field no_form_pdm_status_icm20948_2: id1.id2.no_form_pdm_status_icm20948_2
    :field no_form_pdm_status_icm20948_1: id1.id2.no_form_pdm_status_icm20948_1
    :field no_form_pdm_status_stx3: id1.id2.no_form_pdm_status_stx3
    :field no_form_pdm_status_spresense2: id1.id2.no_form_pdm_status_spresense2
    :field no_form_pdm_status_spresense1: id1.id2.no_form_pdm_status_spresense1
    :field no_form_pdm_status_gamma_ray_detector: id1.id2.no_form_pdm_status_gamma_ray_detector
    :field no_form_pdm_status_sbd: id1.id2.no_form_pdm_status_sbd
    :field no_form_pdm_status_nchrome_wire_cutter: id1.id2.no_form_pdm_status_nchrome_wire_cutter
    :field no_form_last_command_id_sbd: id1.id2.no_form_last_command_id_sbd
    :field no_form_uhf_communication_device_temp: id1.id2.no_form_uhf_communication_device_temp
    :field no_form_count_of_uplink_uhf: id1.id2.no_form_count_of_uplink_uhf
    :field no_form_voltage_of_received_radio: id1.id2.no_form_voltage_of_received_radio
    :field no_form_battery_voltage: id1.id2.no_form_battery_voltage
    :field no_form_beacon_type: id1.id2.no_form_beacon_type
    
    .. seealso::
       Source - https://sakamotolab.phys.aoyama.ac.jp/research/future_space/ARICA-2_en/cw_beacon
    """
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        self.id1 = Arica2.TypeT(self._io, self, self._root)

    class TypeT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            _on = self.cw_beacon_length
            if _on == 14:
                self.id2 = Arica2.Cw2Form(self._io, self, self._root)
            elif _on == 6:
                self.id2 = Arica2.Cw2(self._io, self, self._root)
            elif _on == 7:
                self.id2 = Arica2.Cw3(self._io, self, self._root)
            elif _on == 15:
                self.id2 = Arica2.Cw3Form(self._io, self, self._root)
            elif _on == 8:
                self.id2 = Arica2.Cw1(self._io, self, self._root)
            elif _on == 16:
                self.id2 = Arica2.Cw1Form(self._io, self, self._root)
            else:
                self.id2 = Arica2.Message(self._io, self, self._root)

        @property
        def cw_beacon(self):
            if hasattr(self, '_m_cw_beacon'):
                return self._m_cw_beacon

            _pos = self._io.pos()
            self._io.seek(0)
            self._m_cw_beacon = []
            i = 0
            while not self._io.is_eof():
                self._m_cw_beacon.append(self._io.read_u1())
                i += 1

            self._io.seek(_pos)
            return getattr(self, '_m_cw_beacon', None)

        @property
        def cw_beacon_length(self):
            if hasattr(self, '_m_cw_beacon_length'):
                return self._m_cw_beacon_length

            self._m_cw_beacon_length = len(self.cw_beacon)
            return getattr(self, '_m_cw_beacon_length', None)


    class Cw1(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.no_form_command_id = self._io.read_bits_int_be(4)
            self.no_form_setup_mode_completed = self._io.read_bits_int_be(1) != 0
            self.no_form_antenna_deployed = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense1_subcore_status_sub1 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense1_subcore_status_sub2 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense1_subcore_status_sub3 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense1_subcore_status_sub4 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense1_subcore_status_sub5 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense2_subcore_status_sub1 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense2_subcore_status_sub2 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense2_subcore_status_sub3 = self._io.read_bits_int_be(1) != 0
            self.no_form_spresense2_subcore_status_sub5 = self._io.read_bits_int_be(1) != 0
            self.no_form_device_error_eps = self._io.read_bits_int_be(1) != 0
            self.no_form_device_error_sbd = self._io.read_bits_int_be(1) != 0
            self.no_form_device_error_stx3 = self._io.read_bits_int_be(1) != 0
            self.no_form_device_error_uhf = self._io.read_bits_int_be(1) != 0
            self.no_form_device_error_spr2 = self._io.read_bits_int_be(1) != 0
            self.no_form_ir_sensor_1_sleep_mode = self._io.read_bits_int_be(1) != 0
            self.no_form_ir_sensor_2_power_on = self._io.read_bits_int_be(1) != 0
            self.no_form_adc_possible = self._io.read_bits_int_be(1) != 0
            self.no_form_motor_driver_power_on = self._io.read_bits_int_be(1) != 0
            self.no_form_imu_power_on = self._io.read_bits_int_be(1) != 0
            self.no_form_count_of_mode_change_to_power_saving_mode = self._io.read_bits_int_be(4)
            self.no_form_reboot_count_of_spresense_1 = self._io.read_bits_int_be(3)
            self.no_form_reboot_count_of_spresense_2 = self._io.read_bits_int_be(3)
            self.no_form_communication_to_another_spresense = self._io.read_bits_int_be(1) != 0
            self.no_form_angular_velocity_x = self._io.read_bits_int_be(5)
            self.no_form_angular_velocity_y = self._io.read_bits_int_be(5)
            self.no_form_angular_velocity_z = self._io.read_bits_int_be(5)
            self.no_form_ir_sensor_2_checks_the_earth = self._io.read_bits_int_be(1) != 0
            self.no_form_ir_sensor_1_checks_the_earth = self._io.read_bits_int_be(1) != 0
            self.not_used = self._io.read_bits_int_be(2)
            self.no_form_count_of_attitude_control = self._io.read_bits_int_be(3)
            self.no_form_mode_spresense_1 = self._io.read_bits_int_be(3)
            self.no_form_mode_spresense_2 = self._io.read_bits_int_be(3)

        @property
        def no_form_beacon_type(self):
            if hasattr(self, '_m_no_form_beacon_type'):
                return self._m_no_form_beacon_type

            self._m_no_form_beacon_type = 1
            return getattr(self, '_m_no_form_beacon_type', None)


    class Cw2Form(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(7)).decode(u"UTF-8")
            if not self.callsign == u"arica-2":
                raise kaitaistruct.ValidationNotEqualError(u"arica-2", self.callsign, self._io, u"/types/cw2_form/seq/0")
            self.beacon_type = self._io.read_u1()
            self.not_used = self._io.read_bits_int_be(4)
            self.thumbnail_preparation = self._io.read_bits_int_be(1) != 0
            self.jpeg_image_preparation = self._io.read_bits_int_be(1) != 0
            self.gps_update = self._io.read_bits_int_be(1) != 0
            self.gps_time_hour = self._io.read_bits_int_be(5)
            if not self.gps_time_hour >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.gps_time_hour, self._io, u"/types/cw2_form/seq/6")
            if not self.gps_time_hour <= 23:
                raise kaitaistruct.ValidationGreaterThanError(23, self.gps_time_hour, self._io, u"/types/cw2_form/seq/6")
            self.gps_time_minute = self._io.read_bits_int_be(6)
            if not self.gps_time_minute >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.gps_time_minute, self._io, u"/types/cw2_form/seq/7")
            if not self.gps_time_minute <= 59:
                raise kaitaistruct.ValidationGreaterThanError(59, self.gps_time_minute, self._io, u"/types/cw2_form/seq/7")
            self.gps_time_second = self._io.read_bits_int_be(6)
            if not self.gps_time_second >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.gps_time_second, self._io, u"/types/cw2_form/seq/8")
            if not self.gps_time_second <= 59:
                raise kaitaistruct.ValidationGreaterThanError(59, self.gps_time_second, self._io, u"/types/cw2_form/seq/8")
            self.gps_add_info_1 = self._io.read_bits_int_be(1) != 0
            self.latitude_raw = self._io.read_bits_int_be(7)
            if not self.latitude_raw >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.latitude_raw, self._io, u"/types/cw2_form/seq/10")
            if not self.latitude_raw <= 90:
                raise kaitaistruct.ValidationGreaterThanError(90, self.latitude_raw, self._io, u"/types/cw2_form/seq/10")
            self.gps_add_info_2 = self._io.read_bits_int_be(1) != 0
            self.longitude_raw = self._io.read_bits_int_be(8)
            if not self.longitude_raw >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.longitude_raw, self._io, u"/types/cw2_form/seq/12")
            if not self.longitude_raw <= 180:
                raise kaitaistruct.ValidationGreaterThanError(180, self.longitude_raw, self._io, u"/types/cw2_form/seq/12")
            self.altitude_km = self._io.read_bits_int_be(7)

        @property
        def gps_time_second_processed(self):
            if hasattr(self, '_m_gps_time_second_processed'):
                return self._m_gps_time_second_processed

            self._m_gps_time_second_processed = (u"0" + str(self.gps_time_second) if len(str(self.gps_time_second)) == 1 else str(self.gps_time_second))
            return getattr(self, '_m_gps_time_second_processed', None)

        @property
        def gps_time_minute_processed(self):
            if hasattr(self, '_m_gps_time_minute_processed'):
                return self._m_gps_time_minute_processed

            self._m_gps_time_minute_processed = (u"0" + str(self.gps_time_minute) if len(str(self.gps_time_minute)) == 1 else str(self.gps_time_minute))
            return getattr(self, '_m_gps_time_minute_processed', None)

        @property
        def gps_time(self):
            if hasattr(self, '_m_gps_time'):
                return self._m_gps_time

            self._m_gps_time = self.gps_time_hour_processed + u":" + self.gps_time_minute_processed + u":" + self.gps_time_second_processed
            return getattr(self, '_m_gps_time', None)

        @property
        def longitude_deg_only(self):
            if hasattr(self, '_m_longitude_deg_only'):
                return self._m_longitude_deg_only

            self._m_longitude_deg_only = (self.longitude_raw * ((2 * int(self.gps_add_info_2)) - 1))
            return getattr(self, '_m_longitude_deg_only', None)

        @property
        def gps_time_hour_processed(self):
            if hasattr(self, '_m_gps_time_hour_processed'):
                return self._m_gps_time_hour_processed

            self._m_gps_time_hour_processed = (u"0" + str(self.gps_time_hour) if len(str(self.gps_time_hour)) == 1 else str(self.gps_time_hour))
            return getattr(self, '_m_gps_time_hour_processed', None)

        @property
        def latitude_deg_only(self):
            if hasattr(self, '_m_latitude_deg_only'):
                return self._m_latitude_deg_only

            self._m_latitude_deg_only = (self.latitude_raw * ((2 * int(self.gps_add_info_1)) - 1))
            return getattr(self, '_m_latitude_deg_only', None)


    class Cw2(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.not_used = self._io.read_bits_int_be(4)
            self.no_form_thumbnail_preparation = self._io.read_bits_int_be(1) != 0
            self.no_form_jpeg_image_preparation = self._io.read_bits_int_be(1) != 0
            self.no_form_gps_update = self._io.read_bits_int_be(1) != 0
            self.gps_time_hour = self._io.read_bits_int_be(5)
            if not self.gps_time_hour >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.gps_time_hour, self._io, u"/types/cw2/seq/4")
            if not self.gps_time_hour <= 23:
                raise kaitaistruct.ValidationGreaterThanError(23, self.gps_time_hour, self._io, u"/types/cw2/seq/4")
            self.gps_time_minute = self._io.read_bits_int_be(6)
            if not self.gps_time_minute >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.gps_time_minute, self._io, u"/types/cw2/seq/5")
            if not self.gps_time_minute <= 59:
                raise kaitaistruct.ValidationGreaterThanError(59, self.gps_time_minute, self._io, u"/types/cw2/seq/5")
            self.gps_time_second = self._io.read_bits_int_be(6)
            if not self.gps_time_second >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.gps_time_second, self._io, u"/types/cw2/seq/6")
            if not self.gps_time_second <= 59:
                raise kaitaistruct.ValidationGreaterThanError(59, self.gps_time_second, self._io, u"/types/cw2/seq/6")
            self.gps_add_info_1 = self._io.read_bits_int_be(1) != 0
            self.latitude_raw = self._io.read_bits_int_be(7)
            if not self.latitude_raw >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.latitude_raw, self._io, u"/types/cw2/seq/8")
            if not self.latitude_raw <= 90:
                raise kaitaistruct.ValidationGreaterThanError(90, self.latitude_raw, self._io, u"/types/cw2/seq/8")
            self.gps_add_info_2 = self._io.read_bits_int_be(1) != 0
            self.longitude_raw = self._io.read_bits_int_be(8)
            if not self.longitude_raw >= 0:
                raise kaitaistruct.ValidationLessThanError(0, self.longitude_raw, self._io, u"/types/cw2/seq/10")
            if not self.longitude_raw <= 180:
                raise kaitaistruct.ValidationGreaterThanError(180, self.longitude_raw, self._io, u"/types/cw2/seq/10")
            self.no_form_altitude_km = self._io.read_bits_int_be(7)

        @property
        def gps_time_second_processed(self):
            if hasattr(self, '_m_gps_time_second_processed'):
                return self._m_gps_time_second_processed

            self._m_gps_time_second_processed = (u"0" + str(self.gps_time_second) if len(str(self.gps_time_second)) == 1 else str(self.gps_time_second))
            return getattr(self, '_m_gps_time_second_processed', None)

        @property
        def no_form_longitude_deg_only(self):
            if hasattr(self, '_m_no_form_longitude_deg_only'):
                return self._m_no_form_longitude_deg_only

            self._m_no_form_longitude_deg_only = (self.longitude_raw * ((2 * int(self.gps_add_info_2)) - 1))
            return getattr(self, '_m_no_form_longitude_deg_only', None)

        @property
        def gps_time_minute_processed(self):
            if hasattr(self, '_m_gps_time_minute_processed'):
                return self._m_gps_time_minute_processed

            self._m_gps_time_minute_processed = (u"0" + str(self.gps_time_minute) if len(str(self.gps_time_minute)) == 1 else str(self.gps_time_minute))
            return getattr(self, '_m_gps_time_minute_processed', None)

        @property
        def gps_time_hour_processed(self):
            if hasattr(self, '_m_gps_time_hour_processed'):
                return self._m_gps_time_hour_processed

            self._m_gps_time_hour_processed = (u"0" + str(self.gps_time_hour) if len(str(self.gps_time_hour)) == 1 else str(self.gps_time_hour))
            return getattr(self, '_m_gps_time_hour_processed', None)

        @property
        def no_form_latitude_deg_only(self):
            if hasattr(self, '_m_no_form_latitude_deg_only'):
                return self._m_no_form_latitude_deg_only

            self._m_no_form_latitude_deg_only = (self.latitude_raw * ((2 * int(self.gps_add_info_1)) - 1))
            return getattr(self, '_m_no_form_latitude_deg_only', None)

        @property
        def no_form_gps_time(self):
            if hasattr(self, '_m_no_form_gps_time'):
                return self._m_no_form_gps_time

            self._m_no_form_gps_time = self.gps_time_hour_processed + u":" + self.gps_time_minute_processed + u":" + self.gps_time_second_processed
            return getattr(self, '_m_no_form_gps_time', None)

        @property
        def no_form_beacon_type(self):
            if hasattr(self, '_m_no_form_beacon_type'):
                return self._m_no_form_beacon_type

            self._m_no_form_beacon_type = 2
            return getattr(self, '_m_no_form_beacon_type', None)


    class Cw3Form(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(7)).decode(u"UTF-8")
            if not self.callsign == u"arica-2":
                raise kaitaistruct.ValidationNotEqualError(u"arica-2", self.callsign, self._io, u"/types/cw3_form/seq/0")
            self.beacon_type = self._io.read_u1()
            self.battery_daughter_board_1_temp_raw = self._io.read_bits_int_be(9)
            self.battery_heater = self._io.read_bits_int_be(1) != 0
            self.power_flow_status = self._io.read_bits_int_be(1) != 0
            self.pdm_status_icm20948_2 = self._io.read_bits_int_be(1) != 0
            self.pdm_status_icm20948_1 = self._io.read_bits_int_be(1) != 0
            self.pdm_status_stx3 = self._io.read_bits_int_be(1) != 0
            self.pdm_status_spresense2 = self._io.read_bits_int_be(1) != 0
            self.pdm_status_spresense1 = self._io.read_bits_int_be(1) != 0
            self.pdm_status_gamma_ray_detector = self._io.read_bits_int_be(1) != 0
            self.pdm_status_sbd = self._io.read_bits_int_be(1) != 0
            self.pdm_status_nchrome_wire_cutter = self._io.read_bits_int_be(1) != 0
            self.last_command_id_sbd = self._io.read_bits_int_be(4)
            self.uhf_communication_device_temp_raw = self._io.read_bits_int_be(9)
            self.count_of_uplink_uhf = self._io.read_bits_int_be(4)
            self.voltage_of_received_radio_raw = self._io.read_bits_int_be(9)
            self.not_used = self._io.read_bits_int_be(3)
            self.battery_voltage_raw = self._io.read_bits_int_be(8)

        @property
        def battery_daughter_board_1_temp(self):
            if hasattr(self, '_m_battery_daughter_board_1_temp'):
                return self._m_battery_daughter_board_1_temp

            self._m_battery_daughter_board_1_temp = ((((self.battery_daughter_board_1_temp_raw * 2) * 0.3976) - 238.57) + (0.3976 / 2))
            return getattr(self, '_m_battery_daughter_board_1_temp', None)

        @property
        def uhf_communication_device_temp(self):
            if hasattr(self, '_m_uhf_communication_device_temp'):
                return self._m_uhf_communication_device_temp

            self._m_uhf_communication_device_temp = ((1.0331 - ((self.uhf_communication_device_temp_raw * 5.04) / 1023)) / 0.0056)
            return getattr(self, '_m_uhf_communication_device_temp', None)

        @property
        def voltage_of_received_radio(self):
            if hasattr(self, '_m_voltage_of_received_radio'):
                return self._m_voltage_of_received_radio

            self._m_voltage_of_received_radio = ((self.voltage_of_received_radio_raw * 5.04) / 1023)
            return getattr(self, '_m_voltage_of_received_radio', None)

        @property
        def battery_voltage(self):
            if hasattr(self, '_m_battery_voltage'):
                return self._m_battery_voltage

            self._m_battery_voltage = ((self.battery_voltage_raw * 0.008978) + 6.1)
            return getattr(self, '_m_battery_voltage', None)


    class Cw1Form(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(7)).decode(u"UTF-8")
            if not self.callsign == u"arica-2":
                raise kaitaistruct.ValidationNotEqualError(u"arica-2", self.callsign, self._io, u"/types/cw1_form/seq/0")
            self.beacon_type = self._io.read_u1()
            self.command_id = self._io.read_bits_int_be(4)
            self.setup_mode_completed = self._io.read_bits_int_be(1) != 0
            self.antenna_deployed = self._io.read_bits_int_be(1) != 0
            self.spresense1_subcore_status_sub1 = self._io.read_bits_int_be(1) != 0
            self.spresense1_subcore_status_sub2 = self._io.read_bits_int_be(1) != 0
            self.spresense1_subcore_status_sub3 = self._io.read_bits_int_be(1) != 0
            self.spresense1_subcore_status_sub4 = self._io.read_bits_int_be(1) != 0
            self.spresense1_subcore_status_sub5 = self._io.read_bits_int_be(1) != 0
            self.spresense2_subcore_status_sub1 = self._io.read_bits_int_be(1) != 0
            self.spresense2_subcore_status_sub2 = self._io.read_bits_int_be(1) != 0
            self.spresense2_subcore_status_sub3 = self._io.read_bits_int_be(1) != 0
            self.spresense2_subcore_status_sub5 = self._io.read_bits_int_be(1) != 0
            self.device_error_eps = self._io.read_bits_int_be(1) != 0
            self.device_error_sbd = self._io.read_bits_int_be(1) != 0
            self.device_error_stx3 = self._io.read_bits_int_be(1) != 0
            self.device_error_uhf = self._io.read_bits_int_be(1) != 0
            self.device_error_spr2 = self._io.read_bits_int_be(1) != 0
            self.ir_sensor_1_sleep_mode = self._io.read_bits_int_be(1) != 0
            self.ir_sensor_2_power_on = self._io.read_bits_int_be(1) != 0
            self.adc_possible = self._io.read_bits_int_be(1) != 0
            self.motor_driver_power_on = self._io.read_bits_int_be(1) != 0
            self.imu_power_on = self._io.read_bits_int_be(1) != 0
            self.count_of_mode_change_to_power_saving_mode = self._io.read_bits_int_be(4)
            self.reboot_count_of_spresense_1 = self._io.read_bits_int_be(3)
            self.reboot_count_of_spresense_2 = self._io.read_bits_int_be(3)
            self.communication_to_another_spresense = self._io.read_bits_int_be(1) != 0
            self.angular_velocity_x = self._io.read_bits_int_be(5)
            self.angular_velocity_y = self._io.read_bits_int_be(5)
            self.angular_velocity_z = self._io.read_bits_int_be(5)
            self.ir_sensor_2_checks_the_earth = self._io.read_bits_int_be(1) != 0
            self.ir_sensor_1_checks_the_earth = self._io.read_bits_int_be(1) != 0
            self.not_used = self._io.read_bits_int_be(2)
            self.count_of_attitude_control = self._io.read_bits_int_be(3)
            self.mode_spresense_1 = self._io.read_bits_int_be(3)
            self.mode_spresense_2 = self._io.read_bits_int_be(3)


    class Cw3(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.battery_daughter_board_1_temp_raw = self._io.read_bits_int_be(9)
            self.no_form_battery_heater = self._io.read_bits_int_be(1) != 0
            self.no_form_power_flow_status = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_icm20948_2 = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_icm20948_1 = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_stx3 = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_spresense2 = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_spresense1 = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_gamma_ray_detector = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_sbd = self._io.read_bits_int_be(1) != 0
            self.no_form_pdm_status_nchrome_wire_cutter = self._io.read_bits_int_be(1) != 0
            self.no_form_last_command_id_sbd = self._io.read_bits_int_be(4)
            self.uhf_communication_device_temp_raw = self._io.read_bits_int_be(9)
            self.no_form_count_of_uplink_uhf = self._io.read_bits_int_be(4)
            self.voltage_of_received_radio_raw = self._io.read_bits_int_be(9)
            self.not_used = self._io.read_bits_int_be(3)
            self.battery_voltage_raw = self._io.read_bits_int_be(8)

        @property
        def no_form_voltage_of_received_radio(self):
            if hasattr(self, '_m_no_form_voltage_of_received_radio'):
                return self._m_no_form_voltage_of_received_radio

            self._m_no_form_voltage_of_received_radio = ((self.voltage_of_received_radio_raw * 5.04) / 1023)
            return getattr(self, '_m_no_form_voltage_of_received_radio', None)

        @property
        def no_form_battery_voltage(self):
            if hasattr(self, '_m_no_form_battery_voltage'):
                return self._m_no_form_battery_voltage

            self._m_no_form_battery_voltage = ((self.battery_voltage_raw * 0.008978) + 6.1)
            return getattr(self, '_m_no_form_battery_voltage', None)

        @property
        def no_form_battery_daughter_board_1_temp(self):
            if hasattr(self, '_m_no_form_battery_daughter_board_1_temp'):
                return self._m_no_form_battery_daughter_board_1_temp

            self._m_no_form_battery_daughter_board_1_temp = ((((self.battery_daughter_board_1_temp_raw * 2) * 0.3976) - 238.57) + (0.3976 / 2))
            return getattr(self, '_m_no_form_battery_daughter_board_1_temp', None)

        @property
        def no_form_uhf_communication_device_temp(self):
            if hasattr(self, '_m_no_form_uhf_communication_device_temp'):
                return self._m_no_form_uhf_communication_device_temp

            self._m_no_form_uhf_communication_device_temp = ((1.0331 - ((self.uhf_communication_device_temp_raw * 5.04) / 1023)) / 0.0056)
            return getattr(self, '_m_no_form_uhf_communication_device_temp', None)

        @property
        def no_form_beacon_type(self):
            if hasattr(self, '_m_no_form_beacon_type'):
                return self._m_no_form_beacon_type

            self._m_no_form_beacon_type = 3
            return getattr(self, '_m_no_form_beacon_type', None)


    class Message(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25_frame = Arica2.Message.Ax25Frame(self._io, self, self._root)

        class Ax25Frame(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.ax25_header = Arica2.Message.Ax25Header(self._io, self, self._root)
                self._raw_ax25_info = self._io.read_bytes_full()
                _io__raw_ax25_info = KaitaiStream(BytesIO(self._raw_ax25_info))
                self.ax25_info = Arica2.Message.Ax25InfoData(_io__raw_ax25_info, self, self._root)


        class Ax25Header(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.dest_callsign_raw = Arica2.Message.CallsignRaw(self._io, self, self._root)
                self.dest_ssid = self._io.read_u1()
                self.src_callsign_raw = Arica2.Message.CallsignRaw(self._io, self, self._root)
                self.src_ssid = self._io.read_u1()
                self.ctl_pid = self._io.read_u2be()


        class Callsign(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.callsign = (self._io.read_bytes(6)).decode(u"UTF-8")


        class CallsignRaw(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self._raw__raw_callsign_ror = self._io.read_bytes(6)
                self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
                _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
                self.callsign_ror = Arica2.Message.Callsign(_io__raw_callsign_ror, self, self._root)


        class Ax25InfoData(KaitaiStruct):
            def __init__(self, _io, _parent=None, _root=None):
                self._io = _io
                self._parent = _parent
                self._root = _root if _root else self
                self._read()

            def _read(self):
                self.message = (self._io.read_bytes_full()).decode(u"UTF-8")




