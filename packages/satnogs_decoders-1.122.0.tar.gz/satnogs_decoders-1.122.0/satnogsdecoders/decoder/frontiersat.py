# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO
from enum import Enum


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Frontiersat(KaitaiStruct):
    """Decoder for CalgaryToSpace's FrontierSat (CTS-SAT-1) downlink beacon packets,
    
    Each frame consists of:
      - 4 bytes CSP header (big-endian, parsed separately)
      - 130 bytes COMMS_beacon_basic_packet_t (little-endian)
      - 4 bytes CRC32 trailer
    
    Sample frame (hex):
      C2A28A00  01 43545331 01 00 30C6AA01 30C6AA01 B28DEC479D010000
      05 01 0000 0000 4D050000 01 00 1C6C0000 0000 733E 63 FF7F B003
      C60E0000 A3000000 18010000 4F010000 C8000000 00010000
      C9040000 06 02 01 02 00 00 00 02
      48656C6C6F2066726F6D2043616C67617279546F53706163652046726F6E74696572536174
      0000000000 454E4400 CB7CB19B
    
    Field path reference:
      :field packet_type: frame.beacon.packet_type
      :field satellite_name: frame.beacon.satellite_name
      :field active_rf_switch_antenna: frame.beacon.active_rf_switch_antenna
      :field active_rf_switch_control_mode: frame.beacon.active_rf_switch_control_mode
      :field uptime_ms: frame.beacon.uptime_ms
      :field duration_since_last_uplink_ms: frame.beacon.duration_since_last_uplink_ms
      :field unix_epoch_time_ms: frame.beacon.unix_epoch_time_ms
      :field last_time_sync_source_enum: frame.beacon.last_time_sync_source_enum
      :field is_fs_mounted: frame.beacon.is_fs_mounted
      :field total_tcmd_queued_count: frame.beacon.total_tcmd_queued_count
      :field pending_queued_tcmd_count: frame.beacon.pending_queued_tcmd_count
      :field total_beacon_count_since_boot: frame.beacon.total_beacon_count_since_boot
      :field eps_mode_enum: frame.beacon.eps_mode_enum
      :field eps_reset_cause_enum: frame.beacon.eps_reset_cause_enum
      :field eps_uptime_sec: frame.beacon.eps_uptime_sec
      :field eps_error_code: frame.beacon.eps_error_code
      :field eps_battery_voltage_mv: frame.beacon.eps_battery_voltage_mv
      :field eps_battery_percent: frame.beacon.eps_battery_percent
      :field eps_battery_temperature_0_cc: frame.beacon.eps_battery_temperature_0_cc
      :field eps_battery_temperature_1_cc: frame.beacon.eps_battery_temperature_1_cc
      :field eps_total_fault_count: frame.beacon.eps_total_fault_count
      :field eps_enabled_channels_bitfield: frame.beacon.eps_enabled_channels_bitfield
      :field eps_total_pcu_power_input_cw: frame.beacon.eps_total_pcu_power_input_cw
      :field eps_total_pcu_power_output_cw: frame.beacon.eps_total_pcu_power_output_cw
      :field eps_total_avg_pcu_power_input_cw: frame.beacon.eps_total_avg_pcu_power_input_cw
      :field eps_total_avg_pcu_power_output_cw: frame.beacon.eps_total_avg_pcu_power_output_cw
      :field obc_temperature_cc: frame.beacon.obc_temperature_cc
      :field reboot_reason: frame.beacon.reboot_reason
      :field cts1_operation_state: frame.beacon.cts1_operation_state
      :field rbf_pin_state: frame.beacon.rbf_pin_state
      :field mpi_rx_mode_enum: frame.beacon.mpi_rx_mode_enum
      :field mpi_transceiver_state_enum: frame.beacon.mpi_transceiver_state_enum
      :field mpi_last_reason_for_stopping_enum: frame.beacon.mpi_last_reason_for_stopping_enum
      :field gnss_uart_interrupt_enabled: frame.beacon.gnss_uart_interrupt_enabled
      :field gnss_rx_mode_enum: frame.beacon.gnss_rx_mode_enum
      :field friendly_message: frame.beacon.friendly_message
      :field end_message: frame.beacon.end_message
      :field crc32: frame.crc32
    
    .. seealso::
       Source - https://github.com/CalgaryToSpace/CTS-SAT-1-OBC-Firmware/blob/main/docs/Non-Critical_Notes/Radio_Packet_Format.md
    """

    class ObcRbfStateEnum(Enum):
        bench = 0
        flying = 1

    class EpsModeEnum(Enum):
        startup = 0
        nominal = 1
        safety = 2
        emergency_low_power = 3

    class EpsResetCauseEnum(Enum):
        power_on = 0
        watchdog = 1
        commanded = 2
        control_system_reset = 3
        emergency_low_power = 4

    class TimeSyncSourceEnum(Enum):
        none = 0
        gnss_uart = 1
        gnss_pps = 2
        telecommand_absolute = 3
        telecommand_correction = 4
        eps_rtc = 5

    class CommsPacketTypeEnum(Enum):
        beacon_basic = 1
        beacon_peripheral = 2
        log_message = 3
        tcmd_response = 4
        bulk_file_downlink = 16

    class CommsRfSwitchControlModeEnum(Enum):
        toggle_before_every_beacon = 0
        force_ant1 = 1
        force_ant2 = 2
        use_adcs_normal = 3
        use_adcs_flipped = 4
        unknown = 255

    class MpiRxModeEnum(Enum):
        command_mode = 0
        sensing_mode = 1
        not_listening_to_mpi = 2

    class Stm32ResetCauseEnum(Enum):
        unknown = 0
        low_power_reset = 1
        window_watchdog_reset = 2
        independent_watchdog_reset = 3
        software_reset = 4
        external_reset_pin_reset = 5
        brownout_reset = 6
        option_byte_loader_reset = 7
        firewall_reset = 8

    class MpiTransceiverStateEnum(Enum):
        inactive = 0
        mosi = 1
        miso = 2
        duplex = 3

    class GnssRxModeEnum(Enum):
        command_mode = 0
        firehose_mode = 1
        disabled = 2

    class MpiReasonForStoppingEnum(Enum):
        not_set = 0
        temperature_exceeded = 1
        telecommand = 2
        max_time_exceeded = 3
        self_check_done = 4

    class Cts1OperationStateEnum(Enum):
        booted_and_waiting = 0
        deploying = 1
        nominal_with_radio_tx = 2
        nominal_without_radio_tx = 3
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        self.frame = Frontiersat.FrontiersatFrameT(self._io, self, self._root)

    class FrontiersatFrameT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.csp_header = self._io.read_u4be()
            if not self.csp_header == 3265432064:
                raise kaitaistruct.ValidationNotEqualError(3265432064, self.csp_header, self._io, u"/types/frontiersat_frame_t/seq/0")
            self.beacon = Frontiersat.BeaconBasicPacketT(self._io, self, self._root)
            self.crc32 = self._io.read_u4le()


    class BeaconBasicPacketT(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.packet_type = KaitaiStream.resolve_enum(Frontiersat.CommsPacketTypeEnum, self._io.read_u1())
            self.satellite_name = (self._io.read_bytes(4)).decode(u"ASCII")
            if not self.satellite_name == u"CTS1":
                raise kaitaistruct.ValidationNotEqualError(u"CTS1", self.satellite_name, self._io, u"/types/beacon_basic_packet_t/seq/1")
            self.active_rf_switch_antenna = self._io.read_u1()
            self.active_rf_switch_control_mode = KaitaiStream.resolve_enum(Frontiersat.CommsRfSwitchControlModeEnum, self._io.read_u1())
            self.uptime_ms = self._io.read_u4le()
            self.duration_since_last_uplink_ms = self._io.read_u4le()
            self.unix_epoch_time_ms = self._io.read_u8le()
            self.last_time_sync_source_enum = KaitaiStream.resolve_enum(Frontiersat.TimeSyncSourceEnum, self._io.read_u1())
            self.is_fs_mounted = self._io.read_u1()
            self.total_tcmd_queued_count = self._io.read_u2le()
            self.pending_queued_tcmd_count = self._io.read_u2le()
            self.total_beacon_count_since_boot = self._io.read_u4le()
            self.eps_mode_enum = KaitaiStream.resolve_enum(Frontiersat.EpsModeEnum, self._io.read_u1())
            self.eps_reset_cause_enum = KaitaiStream.resolve_enum(Frontiersat.EpsResetCauseEnum, self._io.read_u1())
            self.eps_uptime_sec = self._io.read_u4le()
            self.eps_error_code = self._io.read_u2le()
            self.eps_battery_voltage_mv = self._io.read_u2le()
            self.eps_battery_percent = self._io.read_u1()
            self.eps_battery_temperature_0_cc = self._io.read_s2le()
            self.eps_battery_temperature_1_cc = self._io.read_s2le()
            self.eps_total_fault_count = self._io.read_s4le()
            self.eps_enabled_channels_bitfield = self._io.read_u4le()
            self.eps_total_pcu_power_input_cw = self._io.read_s4le()
            self.eps_total_pcu_power_output_cw = self._io.read_s4le()
            self.eps_total_avg_pcu_power_input_cw = self._io.read_s4le()
            self.eps_total_avg_pcu_power_output_cw = self._io.read_s4le()
            self.obc_temperature_cc = self._io.read_s4le()
            self.reboot_reason = KaitaiStream.resolve_enum(Frontiersat.Stm32ResetCauseEnum, self._io.read_u1())
            self.cts1_operation_state = KaitaiStream.resolve_enum(Frontiersat.Cts1OperationStateEnum, self._io.read_u1())
            self.rbf_pin_state = KaitaiStream.resolve_enum(Frontiersat.ObcRbfStateEnum, self._io.read_u1())
            self.mpi_rx_mode_enum = KaitaiStream.resolve_enum(Frontiersat.MpiRxModeEnum, self._io.read_u1())
            self.mpi_transceiver_state_enum = KaitaiStream.resolve_enum(Frontiersat.MpiTransceiverStateEnum, self._io.read_u1())
            self.mpi_last_reason_for_stopping_enum = KaitaiStream.resolve_enum(Frontiersat.MpiReasonForStoppingEnum, self._io.read_u1())
            self.gnss_uart_interrupt_enabled = self._io.read_u1()
            self.gnss_rx_mode_enum = KaitaiStream.resolve_enum(Frontiersat.GnssRxModeEnum, self._io.read_u1())
            self.friendly_message = (self._io.read_bytes(42)).decode(u"ASCII")
            self.end_message = (self._io.read_bytes(4)).decode(u"ASCII")
            if not self.end_message == u"END\000":
                raise kaitaistruct.ValidationNotEqualError(u"END\000", self.end_message, self._io, u"/types/beacon_basic_packet_t/seq/36")



