# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Geoscan16u(KaitaiStruct):
    """:field callsign_start_str: data.ax25_header.dest_callsign_raw.callsign_ror.callsign_start.callsign_start_str
    :field callsign_end_str: data.ax25_header.dest_callsign_raw.callsign_ror.callsign_end.callsign_end_str
    :field ssid_mask: data.ax25_header.dest_ssid_raw.ssid_mask
    :field ssid: data.ax25_header.dest_ssid_raw.ssid
    :field src_callsign_raw_callsign_start_str: data.ax25_header.src_callsign_raw.callsign_ror.callsign_start.callsign_start_str
    :field src_callsign_raw_callsign_end_str: data.ax25_header.src_callsign_raw.callsign_ror.callsign_end.callsign_end_str
    :field src_ssid_raw_ssid_mask: data.ax25_header.src_ssid_raw.ssid_mask
    :field src_ssid_raw_ssid: data.ax25_header.src_ssid_raw.ssid
    :field ctl: data.ax25_header.ctl
    :field pid: data.ax25_header.pid
    :field beacon_id: data.payload.beacon_id
    :field eps_1_mode: data.payload.eps_1_mode
    :field eps_1_consumption_current: data.payload.eps_1_consumption_current
    :field eps_1_solar_cells_current: data.payload.eps_1_solar_cells_current
    :field eps_1_cell_voltage_full: data.payload.eps_1_cell_voltage_full
    :field eps_1_battery_temperature: data.payload.eps_1_battery_temperature
    :field eps_1_temperature_sp_y_pos: data.payload.eps_1_temperature_sp_y_pos
    :field eps_1_temperature_sp_y_neg: data.payload.eps_1_temperature_sp_y_neg
    :field eps_1_temperature_sp_x_pos: data.payload.eps_1_temperature_sp_x_pos
    :field eps_1_temperature_sp_x_neg: data.payload.eps_1_temperature_sp_x_neg
    :field eps_1_systems_status: data.payload.eps_1_systems_status
    :field eps_1_boot_count: data.payload.eps_1_boot_count
    :field eps_2_mode: data.payload.eps_2_mode
    :field eps_2_consumption_current: data.payload.eps_2_consumption_current
    :field eps_2_solar_cells_current: data.payload.eps_2_solar_cells_current
    :field eps_2_cell_voltage_full: data.payload.eps_2_cell_voltage_full
    :field eps_2_battery_temperature: data.payload.eps_2_battery_temperature
    :field eps_2_temperature_sp_y_pos: data.payload.eps_2_temperature_sp_y_pos
    :field eps_2_temperature_sp_y_neg: data.payload.eps_2_temperature_sp_y_neg
    :field eps_2_temperature_sp_x_pos: data.payload.eps_2_temperature_sp_x_pos
    :field eps_2_temperature_sp_x_neg: data.payload.eps_2_temperature_sp_x_neg
    :field eps_2_systems_status: data.payload.eps_2_systems_status
    :field eps_2_boot_count: data.payload.eps_2_boot_count
    :field adcs_mt_mode: data.payload.adcs_mt_mode
    :field adcs_rm_mode: data.payload.adcs_rm_mode
    :field adcs_kf_mode: data.payload.adcs_kf_mode
    :field adcs_filter_reset_count: data.payload.adcs_filter_reset_count
    :field adcs_sensors_state: data.payload.adcs_sensors_state
    :field adcs_flywheel_state: data.payload.adcs_flywheel_state
    :field comm_type: data.payload.comm_type
    :field comm_vbus_voltage: data.payload.comm_vbus_voltage
    :field comm_boot_count: data.payload.comm_boot_count
    :field comm_rssi: data.payload.comm_rssi
    :field comm_rssi_minimal: data.payload.comm_rssi_minimal
    :field comm_received_valid_packets: data.payload.comm_received_valid_packets
    :field comm_received_invalid_packets: data.payload.comm_received_invalid_packets
    :field comm_sent_packets: data.payload.comm_sent_packets
    :field comm_status: data.payload.comm_status
    :field comm_mode: data.payload.comm_mode
    :field comm_amp_temperature: data.payload.comm_amp_temperature
    :field comm_reserved_1: data.payload.comm_reserved_1
    :field comm_reserved_2: data.payload.comm_reserved_2
    :field eps_1_mcu1ch1_obc: data.payload.eps_1_mcu1ch1_obc
    :field eps_1_mcu1ch2_commu1: data.payload.eps_1_mcu1ch2_commu1
    :field eps_1_mcu2ch1_comms_plasgu: data.payload.eps_1_mcu2ch1_comms_plasgu
    :field eps_1_mcu2ch2_commu2: data.payload.eps_1_mcu2ch2_commu2
    :field eps_1_mcu3ch1_adcs1: data.payload.eps_1_mcu3ch1_adcs1
    :field eps_1_mcu3ch2_starsns1: data.payload.eps_1_mcu3ch2_starsns1
    :field eps_1_mcu4ch1_payload3_lepton_bridge: data.payload.eps_1_mcu4ch1_payload3_lepton_bridge
    :field eps_1_mcu4ch2_commx: data.payload.eps_1_mcu4ch2_commx
    :field eps_1_mcu5ch1_gyro1: data.payload.eps_1_mcu5ch1_gyro1
    :field eps_1_mcu6ch1_adcs2: data.payload.eps_1_mcu6ch1_adcs2
    :field eps_1_mcu6ch2_starsns2: data.payload.eps_1_mcu6ch2_starsns2
    :field eps_1_mcu7ch1_rws: data.payload.eps_1_mcu7ch1_rws
    :field eps_1_mcu7ch2_fecu_rtr: data.payload.eps_1_mcu7ch2_fecu_rtr
    :field eps_1_mcu8ch1_payload1_heater: data.payload.eps_1_mcu8ch1_payload1_heater
    :field eps_1_mcu8ch2_payload2_camera_heater: data.payload.eps_1_mcu8ch2_payload2_camera_heater
    :field eps_1_timekeeper: data.payload.eps_1_timekeeper
    :field eps_2_mcu1ch1_obc: data.payload.eps_2_mcu1ch1_obc
    :field eps_2_mcu1ch2_commu1: data.payload.eps_2_mcu1ch2_commu1
    :field eps_2_mcu2ch1_comms_plasgu: data.payload.eps_2_mcu2ch1_comms_plasgu
    :field eps_2_mcu2ch2_commu2: data.payload.eps_2_mcu2ch2_commu2
    :field eps_2_mcu3ch1_adcs1: data.payload.eps_2_mcu3ch1_adcs1
    :field eps_2_mcu3ch2_starsns1: data.payload.eps_2_mcu3ch2_starsns1
    :field eps_2_mcu4ch1_payload3_lepton_bridge: data.payload.eps_2_mcu4ch1_payload3_lepton_bridge
    :field eps_2_mcu4ch2_commx: data.payload.eps_2_mcu4ch2_commx
    :field eps_2_mcu5ch1_gyro1: data.payload.eps_2_mcu5ch1_gyro1
    :field eps_2_mcu6ch1_adcs2: data.payload.eps_2_mcu6ch1_adcs2
    :field eps_2_mcu6ch2_starsns2: data.payload.eps_2_mcu6ch2_starsns2
    :field eps_2_mcu7ch1_rws: data.payload.eps_2_mcu7ch1_rws
    :field eps_2_mcu7ch2_fecu_rtr: data.payload.eps_2_mcu7ch2_fecu_rtr
    :field eps_2_mcu8ch1_payload1_heater: data.payload.eps_2_mcu8ch1_payload1_heater
    :field eps_2_mcu8ch2_payload2_camera_heater: data.payload.eps_2_mcu8ch2_payload2_camera_heater
    :field eps_2_timekeeper: data.payload.eps_2_timekeeper
    :field comm_antenna_detector: data.payload.comm_antenna_detector
    :field comm_mode_correct: data.payload.comm_mode_correct
    :field comm_fec_on: data.payload.comm_fec_on
    :field packet_id: data.data_header.packet_id
    :field packet_size: data.data_header.packet_size
    :field system: data.data_payload.system
    :field gnss_type_byte: data.data_payload.payload.gnss_type_byte
    :field posix_time_ms: data.data_payload.payload.gnss_payload.posix_time_ms
    :field coord_x: data.data_payload.payload.gnss_payload.coord_x
    :field coord_y: data.data_payload.payload.gnss_payload.coord_y
    :field coord_z: data.data_payload.payload.gnss_payload.coord_z
    :field velocity_x: data.data_payload.payload.gnss_payload.velocity_x
    :field velocity_y: data.data_payload.payload.gnss_payload.velocity_y
    :field velocity_z: data.data_payload.payload.gnss_payload.velocity_z
    :field quaternion_q0: data.data_payload.payload.gnss_payload.quaternion_q0
    :field quaternion_q1: data.data_payload.payload.gnss_payload.quaternion_q1
    :field quaternion_q2: data.data_payload.payload.gnss_payload.quaternion_q2
    :field quaternion_q3: data.data_payload.payload.gnss_payload.quaternion_q3
    :field ref_motion_mode: data.data_payload.payload.gnss_payload.ref_motion_mode
    :field mag_torquer_mode: data.data_payload.payload.gnss_payload.mag_torquer_mode
    :field filter_type: data.data_payload.payload.gnss_payload.filter_type
    :field orientation_system_status: data.data_payload.payload.gnss_payload.orientation_system_status
    :field reserved: data.data_payload.payload.gnss_payload.reserved
    :field azdk_quaternion_q1: data.data_payload.payload.gnss_payload.azdk_quaternion_q1
    :field azdk_quaternion_q2: data.data_payload.payload.gnss_payload.azdk_quaternion_q2
    :field azdk_quaternion_q3: data.data_payload.payload.gnss_payload.azdk_quaternion_q3
    :field posix_time_s: data.data_payload.payload.gnss_payload.posix_time_s
    :field angular_velocity_x: data.data_payload.payload.gnss_payload.angular_velocity_x
    :field angular_velocity_y: data.data_payload.payload.gnss_payload.angular_velocity_y
    :field angular_velocity_z: data.data_payload.payload.gnss_payload.angular_velocity_z
    :field reserved0: data.data_payload.payload.gnss_payload.reserved0
    :field reserved1: data.data_payload.payload.gnss_payload.reserved1
    :field num: data.data_payload.payload.gnss_payload.num
    :field posix_time_s_1: data.data_payload.payload.gnss_payload.posix_time_s_1
    :field coord_x_1: data.data_payload.payload.gnss_payload.coord_x_1
    :field coord_y_1: data.data_payload.payload.gnss_payload.coord_y_1
    :field coord_z_1: data.data_payload.payload.gnss_payload.coord_z_1
    :field velocity_x_1: data.data_payload.payload.gnss_payload.velocity_x_1
    :field velocity_y_1: data.data_payload.payload.gnss_payload.velocity_y_1
    :field velocity_z_1: data.data_payload.payload.gnss_payload.velocity_z_1
    :field posix_time_s_2: data.data_payload.payload.gnss_payload.posix_time_s_2
    :field coord_x_2: data.data_payload.payload.gnss_payload.coord_x_2
    :field coord_y_2: data.data_payload.payload.gnss_payload.coord_y_2
    :field coord_z_2: data.data_payload.payload.gnss_payload.coord_z_2
    :field velocity_x_2: data.data_payload.payload.gnss_payload.velocity_x_2
    :field velocity_y_2: data.data_payload.payload.gnss_payload.velocity_y_2
    :field velocity_z_2: data.data_payload.payload.gnss_payload.velocity_z_2
    :field eps_beacon_base_info_raw: data.data_payload.payload.eps_beacon_base_info_raw
    :field eps_beacon_reboot_count: data.data_payload.payload.eps_beacon_reboot_count
    :field eps_beacon_firmware_image: data.data_payload.payload.eps_beacon_firmware_image
    :field eps_beacon_switcher_info_raw: data.data_payload.payload.eps_beacon_switcher_info_raw
    :field eps_beacon_balancer_info_raw: data.data_payload.payload.eps_beacon_balancer_info_raw
    :field eps_beacon_deployer_info_raw: data.data_payload.payload.eps_beacon_deployer_info_raw
    :field eps_beacon_heater_info_raw_1: data.data_payload.payload.eps_beacon_heater_info_raw_1
    :field eps_beacon_heater_info_raw_2: data.data_payload.payload.eps_beacon_heater_info_raw_2
    :field eps_beacon_error_mask_raw_1: data.data_payload.payload.eps_beacon_error_mask_raw_1
    :field eps_beacon_error_mask_raw_2: data.data_payload.payload.eps_beacon_error_mask_raw_2
    :field eps_beacon_load_current: data.data_payload.payload.eps_beacon_load_current
    :field eps_beacon_solar_current: data.data_payload.payload.eps_beacon_solar_current
    :field eps_beacon_cell1_voltage: data.data_payload.payload.eps_beacon_cell1_voltage
    :field eps_beacon_cell2_voltage: data.data_payload.payload.eps_beacon_cell2_voltage
    :field eps_beacon_cell3_voltage: data.data_payload.payload.eps_beacon_cell3_voltage
    :field eps_beacon_coulomb_counter: data.data_payload.payload.eps_beacon_coulomb_counter
    :field eps_beacon_mask_enabled_ext_devices_raw: data.data_payload.payload.eps_beacon_mask_enabled_ext_devices_raw
    :field eps_beacon_mask_enabled_int_devices_raw: data.data_payload.payload.eps_beacon_mask_enabled_int_devices_raw
    :field eps_beacon_temp_eps_battery: data.data_payload.payload.eps_beacon_temp_eps_battery
    :field eps_beacon_temp_eps_main: data.data_payload.payload.eps_beacon_temp_eps_main
    :field eps_beacon_temp_commu: data.data_payload.payload.eps_beacon_temp_commu
    :field eps_beacon_temp_commx: data.data_payload.payload.eps_beacon_temp_commx
    :field eps_beacon_temp_plasgu: data.data_payload.payload.eps_beacon_temp_plasgu
    :field eps_beacon_temp_rws0: data.data_payload.payload.eps_beacon_temp_rws0
    :field eps_beacon_temp_rws1: data.data_payload.payload.eps_beacon_temp_rws1
    :field eps_beacon_temp_rws2: data.data_payload.payload.eps_beacon_temp_rws2
    :field eps_beacon_temp_rws3: data.data_payload.payload.eps_beacon_temp_rws3
    :field eps_beacon_temp_solar_wing_y_pos: data.data_payload.payload.eps_beacon_temp_solar_wing_y_pos
    :field eps_beacon_temp_solar_wing_y_neg: data.data_payload.payload.eps_beacon_temp_solar_wing_y_neg
    :field eps_beacon_temp_camera_internal: data.data_payload.payload.eps_beacon_temp_camera_internal
    :field eps_beacon_temp_camera_heater_plate: data.data_payload.payload.eps_beacon_temp_camera_heater_plate
    :field eps_beacon_base_info_eps_mod: data.data_payload.payload.eps_beacon_base_info_eps_mod
    :field eps_beacon_base_info_self_addr: data.data_payload.payload.eps_beacon_base_info_self_addr
    :field eps_beacon_switcher_current_commu: data.data_payload.payload.eps_beacon_switcher_current_commu
    :field eps_beacon_switcher_state: data.data_payload.payload.eps_beacon_switcher_state
    :field eps_beacon_switcher_switching_state: data.data_payload.payload.eps_beacon_switcher_switching_state
    :field eps_beacon_switcher_relay_switch_error: data.data_payload.payload.eps_beacon_switcher_relay_switch_error
    :field eps_beacon_switcher_read_data_error: data.data_payload.payload.eps_beacon_switcher_read_data_error
    :field eps_beacon_balancer_state: data.data_payload.payload.eps_beacon_balancer_state
    :field eps_beacon_balancer_error: data.data_payload.payload.eps_beacon_balancer_error
    :field eps_beacon_balancer_is_balancing: data.data_payload.payload.eps_beacon_balancer_is_balancing
    :field eps_beacon_balancer_active_balancer: data.data_payload.payload.eps_beacon_balancer_active_balancer
    :field eps_beacon_balancer_ind_balancing_cell: data.data_payload.payload.eps_beacon_balancer_ind_balancing_cell
    :field eps_beacon_deployer_state: data.data_payload.payload.eps_beacon_deployer_state
    :field eps_beacon_deployer_storage_error: data.data_payload.payload.eps_beacon_deployer_storage_error
    :field eps_beacon_deployer_deployed_channels_mask: data.data_payload.payload.eps_beacon_deployer_deployed_channels_mask
    :field eps_beacon_heater_mode: data.data_payload.payload.eps_beacon_heater_mode
    :field eps_beacon_heater_active_heater_mask: data.data_payload.payload.eps_beacon_heater_active_heater_mask
    :field eps_beacon_heater_mask_tmp_src: data.data_payload.payload.eps_beacon_heater_mask_tmp_src
    :field eps_beacon_error_i2c_bat_monitor: data.data_payload.payload.eps_beacon_error_i2c_bat_monitor
    :field eps_beacon_error_spi_bat_monitor: data.data_payload.payload.eps_beacon_error_spi_bat_monitor
    :field eps_beacon_error_spi_fram: data.data_payload.payload.eps_beacon_error_spi_fram
    :field eps_beacon_error_i2c_fram1: data.data_payload.payload.eps_beacon_error_i2c_fram1
    :field eps_beacon_error_i2c_fram2: data.data_payload.payload.eps_beacon_error_i2c_fram2
    :field eps_beacon_error_mcu1_i2c: data.data_payload.payload.eps_beacon_error_mcu1_i2c
    :field eps_beacon_error_mcu2_i2c: data.data_payload.payload.eps_beacon_error_mcu2_i2c
    :field eps_beacon_error_mcu3_i2c: data.data_payload.payload.eps_beacon_error_mcu3_i2c
    :field eps_beacon_error_mcu4_i2c: data.data_payload.payload.eps_beacon_error_mcu4_i2c
    :field eps_beacon_error_mcu5_i2c: data.data_payload.payload.eps_beacon_error_mcu5_i2c
    :field eps_beacon_error_mcu6_i2c: data.data_payload.payload.eps_beacon_error_mcu6_i2c
    :field eps_beacon_error_mcu7_i2c: data.data_payload.payload.eps_beacon_error_mcu7_i2c
    :field eps_beacon_error_mcu8_i2c: data.data_payload.payload.eps_beacon_error_mcu8_i2c
    :field eps_beacon_ext_mcu1ch1: data.data_payload.payload.eps_beacon_ext_mcu1ch1
    :field eps_beacon_ext_mcu1ch2: data.data_payload.payload.eps_beacon_ext_mcu1ch2
    :field eps_beacon_ext_mcu2ch1: data.data_payload.payload.eps_beacon_ext_mcu2ch1
    :field eps_beacon_ext_mcu2ch2: data.data_payload.payload.eps_beacon_ext_mcu2ch2
    :field eps_beacon_ext_mcu3ch1: data.data_payload.payload.eps_beacon_ext_mcu3ch1
    :field eps_beacon_ext_mcu3ch2: data.data_payload.payload.eps_beacon_ext_mcu3ch2
    :field eps_beacon_ext_mcu4ch1: data.data_payload.payload.eps_beacon_ext_mcu4ch1
    :field eps_beacon_ext_mcu4ch2: data.data_payload.payload.eps_beacon_ext_mcu4ch2
    :field eps_beacon_ext_mcu5ch1: data.data_payload.payload.eps_beacon_ext_mcu5ch1
    :field eps_beacon_ext_mcu6ch1: data.data_payload.payload.eps_beacon_ext_mcu6ch1
    :field eps_beacon_ext_mcu6ch2: data.data_payload.payload.eps_beacon_ext_mcu6ch2
    :field eps_beacon_ext_mcu7ch1: data.data_payload.payload.eps_beacon_ext_mcu7ch1
    :field eps_beacon_ext_mcu7ch2: data.data_payload.payload.eps_beacon_ext_mcu7ch2
    :field eps_beacon_ext_mcu8ch1: data.data_payload.payload.eps_beacon_ext_mcu8ch1
    :field eps_beacon_ext_mcu8ch2: data.data_payload.payload.eps_beacon_ext_mcu8ch2
    :field eps_beacon_ext_timekeeper: data.data_payload.payload.eps_beacon_ext_timekeeper
    :field eps_beacon_int_mcu_pwr1: data.data_payload.payload.eps_beacon_int_mcu_pwr1
    :field eps_beacon_int_mcu_pwr2: data.data_payload.payload.eps_beacon_int_mcu_pwr2
    :field eps_beacon_int_ds_bus1: data.data_payload.payload.eps_beacon_int_ds_bus1
    :field eps_beacon_int_ds_bus2: data.data_payload.payload.eps_beacon_int_ds_bus2
    :field eps_beacon_int_can1: data.data_payload.payload.eps_beacon_int_can1
    :field eps_beacon_int_can2: data.data_payload.payload.eps_beacon_int_can2
    :field eps_beacon_int_timebus: data.data_payload.payload.eps_beacon_int_timebus
    :field eps_beacon_int_buxbus: data.data_payload.payload.eps_beacon_int_buxbus
    :field eps_beacon_int_fram1: data.data_payload.payload.eps_beacon_int_fram1
    :field eps_beacon_int_fram2: data.data_payload.payload.eps_beacon_int_fram2
    :field eps_beacon_int_bat_balancer1: data.data_payload.payload.eps_beacon_int_bat_balancer1
    :field eps_beacon_int_bat_balancer2: data.data_payload.payload.eps_beacon_int_bat_balancer2
    :field len: len
    :field type: type
    """
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        _on = self.type
        if _on == 33930:
            self.data = Geoscan16u.Ax25Frame(self._io, self, self._root)
        else:
            self.data = Geoscan16u.DataFrame(self._io, self, self._root)

    class Ax25Frame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25_header = Geoscan16u.Ax25Header(self._io, self, self._root)
            self.payload = Geoscan16u.GeoscanBeaconTlm(self._io, self, self._root)


    class Ax25Header(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.dest_callsign_raw = Geoscan16u.CallsignRaw(self._io, self, self._root)
            self.dest_ssid_raw = Geoscan16u.SsidMask(self._io, self, self._root)
            self.src_callsign_raw = Geoscan16u.CallsignRaw(self._io, self, self._root)
            self.src_ssid_raw = Geoscan16u.SsidMask(self._io, self, self._root)
            self.ctl = self._io.read_u1()
            self.pid = self._io.read_u1()


    class Callsign(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign_start = Geoscan16u.CallsignStartRaw(self._io, self, self._root)
            self.callsign_end = Geoscan16u.CallsignEndRaw(self._io, self, self._root)


    class GnssTlm70(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.num = self._io.read_u4le()
            self.posix_time_s_1 = self._io.read_u4le()
            self.coord_x_1 = self._io.read_s4le()
            self.coord_y_1 = self._io.read_s4le()
            self.coord_z_1 = self._io.read_s4le()
            self.velocity_x_1 = self._io.read_s4le()
            self.velocity_y_1 = self._io.read_s4le()
            self.velocity_z_1 = self._io.read_s4le()
            self.posix_time_s_2 = self._io.read_u4le()
            self.coord_x_2 = self._io.read_s4le()
            self.coord_y_2 = self._io.read_s4le()
            self.coord_z_2 = self._io.read_s4le()
            self.velocity_x_2 = self._io.read_s4le()
            self.velocity_y_2 = self._io.read_s4le()
            self.velocity_z_2 = self._io.read_s4le()
            self.reserved0 = self._io.read_u4le()
            self.reserved1 = self._io.read_u2le()


    class SsidMask(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ssid_mask = self._io.read_u1()

        @property
        def ssid(self):
            if hasattr(self, '_m_ssid'):
                return self._m_ssid

            self._m_ssid = ((self.ssid_mask & 15) >> 1)
            return getattr(self, '_m_ssid', None)


    class DataHeader(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.packet_id = self._io.read_u2le()
            self.packet_size = self._io.read_u1()


    class CallsignStartRaw(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign_start_str = (self._io.read_bytes(2)).decode(u"ASCII")
            if not  ((self.callsign_start_str == u"BE") or (self.callsign_start_str == u"RS")) :
                raise kaitaistruct.ValidationNotAnyOfError(self.callsign_start_str, self._io, u"/types/callsign_start_raw/seq/0")


    class DataTlm(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.system = self._io.read_u2le()
            if not  ((self.system == 48437) or (self.system == 48425)) :
                raise kaitaistruct.ValidationNotAnyOfError(self.system, self._io, u"/types/data_tlm/seq/0")
            _on = self.system
            if _on == 48437:
                self.payload = Geoscan16u.GnssTlm(self._io, self, self._root)
            elif _on == 48425:
                self.payload = Geoscan16u.EpsBeaconTlm(self._io, self, self._root)


    class EpsBeaconTlm(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.eps_beacon_base_info_raw = self._io.read_u1()
            self.eps_beacon_reboot_count = self._io.read_u2le()
            self.eps_beacon_firmware_image = self._io.read_u1()
            self.eps_beacon_switcher_info_raw = self._io.read_u1()
            self.eps_beacon_balancer_info_raw = self._io.read_u1()
            self.eps_beacon_deployer_info_raw = self._io.read_u1()
            self.eps_beacon_heater_info_raw_1 = self._io.read_u1()
            self.eps_beacon_heater_info_raw_2 = self._io.read_u1()
            self.eps_beacon_error_mask_raw_1 = self._io.read_u1()
            self.eps_beacon_error_mask_raw_2 = self._io.read_u1()
            self.eps_beacon_load_current = self._io.read_u2le()
            self.eps_beacon_solar_current = self._io.read_u2le()
            self.eps_beacon_cell1_voltage = self._io.read_u2le()
            self.eps_beacon_cell2_voltage = self._io.read_u2le()
            self.eps_beacon_cell3_voltage = self._io.read_u2le()
            self.eps_beacon_coulomb_counter = self._io.read_s4le()
            self.eps_beacon_mask_enabled_ext_devices_raw = self._io.read_u2le()
            self.eps_beacon_mask_enabled_int_devices_raw = self._io.read_u2le()
            self.eps_beacon_temp_eps_battery = self._io.read_s1()
            self.eps_beacon_temp_eps_main = self._io.read_s1()
            self.eps_beacon_temp_commu = self._io.read_s1()
            self.eps_beacon_temp_commx = self._io.read_s1()
            self.eps_beacon_temp_plasgu = self._io.read_s1()
            self.eps_beacon_temp_rws0 = self._io.read_s1()
            self.eps_beacon_temp_rws1 = self._io.read_s1()
            self.eps_beacon_temp_rws2 = self._io.read_s1()
            self.eps_beacon_temp_rws3 = self._io.read_s1()
            self.eps_beacon_temp_solar_wing_y_pos = self._io.read_s1()
            self.eps_beacon_temp_solar_wing_y_neg = self._io.read_s1()
            self.eps_beacon_temp_camera_internal = self._io.read_s1()
            self.eps_beacon_temp_camera_heater_plate = self._io.read_s1()

        @property
        def eps_beacon_ext_mcu2ch2(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu2ch2'):
                return self._m_eps_beacon_ext_mcu2ch2

            self._m_eps_beacon_ext_mcu2ch2 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 3) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu2ch2', None)

        @property
        def eps_beacon_switcher_switching_state(self):
            if hasattr(self, '_m_eps_beacon_switcher_switching_state'):
                return self._m_eps_beacon_switcher_switching_state

            self._m_eps_beacon_switcher_switching_state = ((self.eps_beacon_switcher_info_raw >> 3) & 3)
            return getattr(self, '_m_eps_beacon_switcher_switching_state', None)

        @property
        def eps_beacon_base_info_self_addr(self):
            if hasattr(self, '_m_eps_beacon_base_info_self_addr'):
                return self._m_eps_beacon_base_info_self_addr

            self._m_eps_beacon_base_info_self_addr = ((self.eps_beacon_base_info_raw >> 3) & 31)
            return getattr(self, '_m_eps_beacon_base_info_self_addr', None)

        @property
        def eps_beacon_ext_mcu4ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu4ch1'):
                return self._m_eps_beacon_ext_mcu4ch1

            self._m_eps_beacon_ext_mcu4ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 6) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu4ch1', None)

        @property
        def eps_beacon_ext_mcu1ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu1ch1'):
                return self._m_eps_beacon_ext_mcu1ch1

            self._m_eps_beacon_ext_mcu1ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 0) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu1ch1', None)

        @property
        def eps_beacon_error_mcu1_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu1_i2c'):
                return self._m_eps_beacon_error_mcu1_i2c

            self._m_eps_beacon_error_mcu1_i2c = ((self.eps_beacon_error_mask_raw_1 >> 5) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu1_i2c', None)

        @property
        def eps_beacon_int_bat_balancer1(self):
            if hasattr(self, '_m_eps_beacon_int_bat_balancer1'):
                return self._m_eps_beacon_int_bat_balancer1

            self._m_eps_beacon_int_bat_balancer1 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 10) & 1)
            return getattr(self, '_m_eps_beacon_int_bat_balancer1', None)

        @property
        def eps_beacon_ext_mcu6ch2(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu6ch2'):
                return self._m_eps_beacon_ext_mcu6ch2

            self._m_eps_beacon_ext_mcu6ch2 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 10) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu6ch2', None)

        @property
        def eps_beacon_heater_mode(self):
            if hasattr(self, '_m_eps_beacon_heater_mode'):
                return self._m_eps_beacon_heater_mode

            self._m_eps_beacon_heater_mode = ((self.eps_beacon_heater_info_raw_1 >> 0) & 3)
            return getattr(self, '_m_eps_beacon_heater_mode', None)

        @property
        def eps_beacon_balancer_error(self):
            if hasattr(self, '_m_eps_beacon_balancer_error'):
                return self._m_eps_beacon_balancer_error

            self._m_eps_beacon_balancer_error = ((self.eps_beacon_balancer_info_raw >> 2) & 1)
            return getattr(self, '_m_eps_beacon_balancer_error', None)

        @property
        def eps_beacon_heater_active_heater_mask(self):
            if hasattr(self, '_m_eps_beacon_heater_active_heater_mask'):
                return self._m_eps_beacon_heater_active_heater_mask

            self._m_eps_beacon_heater_active_heater_mask = ((self.eps_beacon_heater_info_raw_1 >> 2) & 3)
            return getattr(self, '_m_eps_beacon_heater_active_heater_mask', None)

        @property
        def eps_beacon_int_fram1(self):
            if hasattr(self, '_m_eps_beacon_int_fram1'):
                return self._m_eps_beacon_int_fram1

            self._m_eps_beacon_int_fram1 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 8) & 1)
            return getattr(self, '_m_eps_beacon_int_fram1', None)

        @property
        def eps_beacon_int_timebus(self):
            if hasattr(self, '_m_eps_beacon_int_timebus'):
                return self._m_eps_beacon_int_timebus

            self._m_eps_beacon_int_timebus = ((self.eps_beacon_mask_enabled_int_devices_raw >> 6) & 1)
            return getattr(self, '_m_eps_beacon_int_timebus', None)

        @property
        def eps_beacon_ext_mcu4ch2(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu4ch2'):
                return self._m_eps_beacon_ext_mcu4ch2

            self._m_eps_beacon_ext_mcu4ch2 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 7) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu4ch2', None)

        @property
        def eps_beacon_error_mcu7_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu7_i2c'):
                return self._m_eps_beacon_error_mcu7_i2c

            self._m_eps_beacon_error_mcu7_i2c = ((self.eps_beacon_error_mask_raw_2 >> 3) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu7_i2c', None)

        @property
        def eps_beacon_deployer_state(self):
            if hasattr(self, '_m_eps_beacon_deployer_state'):
                return self._m_eps_beacon_deployer_state

            self._m_eps_beacon_deployer_state = ((self.eps_beacon_deployer_info_raw >> 0) & 3)
            return getattr(self, '_m_eps_beacon_deployer_state', None)

        @property
        def eps_beacon_int_bat_balancer2(self):
            if hasattr(self, '_m_eps_beacon_int_bat_balancer2'):
                return self._m_eps_beacon_int_bat_balancer2

            self._m_eps_beacon_int_bat_balancer2 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 11) & 1)
            return getattr(self, '_m_eps_beacon_int_bat_balancer2', None)

        @property
        def eps_beacon_error_mcu3_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu3_i2c'):
                return self._m_eps_beacon_error_mcu3_i2c

            self._m_eps_beacon_error_mcu3_i2c = ((self.eps_beacon_error_mask_raw_1 >> 7) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu3_i2c', None)

        @property
        def eps_beacon_int_fram2(self):
            if hasattr(self, '_m_eps_beacon_int_fram2'):
                return self._m_eps_beacon_int_fram2

            self._m_eps_beacon_int_fram2 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 9) & 1)
            return getattr(self, '_m_eps_beacon_int_fram2', None)

        @property
        def eps_beacon_int_can1(self):
            if hasattr(self, '_m_eps_beacon_int_can1'):
                return self._m_eps_beacon_int_can1

            self._m_eps_beacon_int_can1 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 4) & 1)
            return getattr(self, '_m_eps_beacon_int_can1', None)

        @property
        def eps_beacon_deployer_storage_error(self):
            if hasattr(self, '_m_eps_beacon_deployer_storage_error'):
                return self._m_eps_beacon_deployer_storage_error

            self._m_eps_beacon_deployer_storage_error = ((self.eps_beacon_deployer_info_raw >> 2) & 1)
            return getattr(self, '_m_eps_beacon_deployer_storage_error', None)

        @property
        def eps_beacon_ext_mcu3ch2(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu3ch2'):
                return self._m_eps_beacon_ext_mcu3ch2

            self._m_eps_beacon_ext_mcu3ch2 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 5) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu3ch2', None)

        @property
        def eps_beacon_int_can2(self):
            if hasattr(self, '_m_eps_beacon_int_can2'):
                return self._m_eps_beacon_int_can2

            self._m_eps_beacon_int_can2 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 5) & 1)
            return getattr(self, '_m_eps_beacon_int_can2', None)

        @property
        def eps_beacon_error_mcu4_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu4_i2c'):
                return self._m_eps_beacon_error_mcu4_i2c

            self._m_eps_beacon_error_mcu4_i2c = ((self.eps_beacon_error_mask_raw_2 >> 0) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu4_i2c', None)

        @property
        def eps_beacon_error_i2c_fram2(self):
            if hasattr(self, '_m_eps_beacon_error_i2c_fram2'):
                return self._m_eps_beacon_error_i2c_fram2

            self._m_eps_beacon_error_i2c_fram2 = ((self.eps_beacon_error_mask_raw_1 >> 4) & 1)
            return getattr(self, '_m_eps_beacon_error_i2c_fram2', None)

        @property
        def eps_beacon_ext_mcu2ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu2ch1'):
                return self._m_eps_beacon_ext_mcu2ch1

            self._m_eps_beacon_ext_mcu2ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 2) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu2ch1', None)

        @property
        def eps_beacon_ext_mcu5ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu5ch1'):
                return self._m_eps_beacon_ext_mcu5ch1

            self._m_eps_beacon_ext_mcu5ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 8) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu5ch1', None)

        @property
        def eps_beacon_heater_mask_tmp_src(self):
            if hasattr(self, '_m_eps_beacon_heater_mask_tmp_src'):
                return self._m_eps_beacon_heater_mask_tmp_src

            self._m_eps_beacon_heater_mask_tmp_src = ((self.eps_beacon_heater_info_raw_1 >> 4) & 15)
            return getattr(self, '_m_eps_beacon_heater_mask_tmp_src', None)

        @property
        def eps_beacon_ext_mcu7ch2(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu7ch2'):
                return self._m_eps_beacon_ext_mcu7ch2

            self._m_eps_beacon_ext_mcu7ch2 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 12) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu7ch2', None)

        @property
        def eps_beacon_base_info_eps_mod(self):
            if hasattr(self, '_m_eps_beacon_base_info_eps_mod'):
                return self._m_eps_beacon_base_info_eps_mod

            self._m_eps_beacon_base_info_eps_mod = ((self.eps_beacon_base_info_raw >> 0) & 7)
            return getattr(self, '_m_eps_beacon_base_info_eps_mod', None)

        @property
        def eps_beacon_switcher_read_data_error(self):
            if hasattr(self, '_m_eps_beacon_switcher_read_data_error'):
                return self._m_eps_beacon_switcher_read_data_error

            self._m_eps_beacon_switcher_read_data_error = ((self.eps_beacon_switcher_info_raw >> 6) & 1)
            return getattr(self, '_m_eps_beacon_switcher_read_data_error', None)

        @property
        def eps_beacon_ext_timekeeper(self):
            if hasattr(self, '_m_eps_beacon_ext_timekeeper'):
                return self._m_eps_beacon_ext_timekeeper

            self._m_eps_beacon_ext_timekeeper = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 15) & 1)
            return getattr(self, '_m_eps_beacon_ext_timekeeper', None)

        @property
        def eps_beacon_switcher_current_commu(self):
            if hasattr(self, '_m_eps_beacon_switcher_current_commu'):
                return self._m_eps_beacon_switcher_current_commu

            self._m_eps_beacon_switcher_current_commu = ((self.eps_beacon_switcher_info_raw >> 0) & 1)
            return getattr(self, '_m_eps_beacon_switcher_current_commu', None)

        @property
        def eps_beacon_error_mcu2_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu2_i2c'):
                return self._m_eps_beacon_error_mcu2_i2c

            self._m_eps_beacon_error_mcu2_i2c = ((self.eps_beacon_error_mask_raw_1 >> 6) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu2_i2c', None)

        @property
        def eps_beacon_ext_mcu1ch2(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu1ch2'):
                return self._m_eps_beacon_ext_mcu1ch2

            self._m_eps_beacon_ext_mcu1ch2 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 1) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu1ch2', None)

        @property
        def eps_beacon_int_mcu_pwr2(self):
            if hasattr(self, '_m_eps_beacon_int_mcu_pwr2'):
                return self._m_eps_beacon_int_mcu_pwr2

            self._m_eps_beacon_int_mcu_pwr2 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 1) & 1)
            return getattr(self, '_m_eps_beacon_int_mcu_pwr2', None)

        @property
        def eps_beacon_int_ds_bus1(self):
            if hasattr(self, '_m_eps_beacon_int_ds_bus1'):
                return self._m_eps_beacon_int_ds_bus1

            self._m_eps_beacon_int_ds_bus1 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 2) & 1)
            return getattr(self, '_m_eps_beacon_int_ds_bus1', None)

        @property
        def eps_beacon_error_spi_fram(self):
            if hasattr(self, '_m_eps_beacon_error_spi_fram'):
                return self._m_eps_beacon_error_spi_fram

            self._m_eps_beacon_error_spi_fram = ((self.eps_beacon_error_mask_raw_1 >> 2) & 1)
            return getattr(self, '_m_eps_beacon_error_spi_fram', None)

        @property
        def eps_beacon_ext_mcu3ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu3ch1'):
                return self._m_eps_beacon_ext_mcu3ch1

            self._m_eps_beacon_ext_mcu3ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 4) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu3ch1', None)

        @property
        def eps_beacon_deployer_deployed_channels_mask(self):
            if hasattr(self, '_m_eps_beacon_deployer_deployed_channels_mask'):
                return self._m_eps_beacon_deployer_deployed_channels_mask

            self._m_eps_beacon_deployer_deployed_channels_mask = ((self.eps_beacon_deployer_info_raw >> 4) & 15)
            return getattr(self, '_m_eps_beacon_deployer_deployed_channels_mask', None)

        @property
        def eps_beacon_balancer_ind_balancing_cell(self):
            if hasattr(self, '_m_eps_beacon_balancer_ind_balancing_cell'):
                return self._m_eps_beacon_balancer_ind_balancing_cell

            self._m_eps_beacon_balancer_ind_balancing_cell = ((self.eps_beacon_balancer_info_raw >> 6) & 3)
            return getattr(self, '_m_eps_beacon_balancer_ind_balancing_cell', None)

        @property
        def eps_beacon_int_mcu_pwr1(self):
            if hasattr(self, '_m_eps_beacon_int_mcu_pwr1'):
                return self._m_eps_beacon_int_mcu_pwr1

            self._m_eps_beacon_int_mcu_pwr1 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 0) & 1)
            return getattr(self, '_m_eps_beacon_int_mcu_pwr1', None)

        @property
        def eps_beacon_switcher_relay_switch_error(self):
            if hasattr(self, '_m_eps_beacon_switcher_relay_switch_error'):
                return self._m_eps_beacon_switcher_relay_switch_error

            self._m_eps_beacon_switcher_relay_switch_error = ((self.eps_beacon_switcher_info_raw >> 5) & 1)
            return getattr(self, '_m_eps_beacon_switcher_relay_switch_error', None)

        @property
        def eps_beacon_ext_mcu8ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu8ch1'):
                return self._m_eps_beacon_ext_mcu8ch1

            self._m_eps_beacon_ext_mcu8ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 13) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu8ch1', None)

        @property
        def eps_beacon_int_buxbus(self):
            if hasattr(self, '_m_eps_beacon_int_buxbus'):
                return self._m_eps_beacon_int_buxbus

            self._m_eps_beacon_int_buxbus = ((self.eps_beacon_mask_enabled_int_devices_raw >> 7) & 1)
            return getattr(self, '_m_eps_beacon_int_buxbus', None)

        @property
        def eps_beacon_switcher_state(self):
            if hasattr(self, '_m_eps_beacon_switcher_state'):
                return self._m_eps_beacon_switcher_state

            self._m_eps_beacon_switcher_state = ((self.eps_beacon_switcher_info_raw >> 1) & 3)
            return getattr(self, '_m_eps_beacon_switcher_state', None)

        @property
        def eps_beacon_ext_mcu8ch2(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu8ch2'):
                return self._m_eps_beacon_ext_mcu8ch2

            self._m_eps_beacon_ext_mcu8ch2 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 14) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu8ch2', None)

        @property
        def eps_beacon_error_mcu6_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu6_i2c'):
                return self._m_eps_beacon_error_mcu6_i2c

            self._m_eps_beacon_error_mcu6_i2c = ((self.eps_beacon_error_mask_raw_2 >> 2) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu6_i2c', None)

        @property
        def eps_beacon_int_ds_bus2(self):
            if hasattr(self, '_m_eps_beacon_int_ds_bus2'):
                return self._m_eps_beacon_int_ds_bus2

            self._m_eps_beacon_int_ds_bus2 = ((self.eps_beacon_mask_enabled_int_devices_raw >> 3) & 1)
            return getattr(self, '_m_eps_beacon_int_ds_bus2', None)

        @property
        def eps_beacon_error_i2c_fram1(self):
            if hasattr(self, '_m_eps_beacon_error_i2c_fram1'):
                return self._m_eps_beacon_error_i2c_fram1

            self._m_eps_beacon_error_i2c_fram1 = ((self.eps_beacon_error_mask_raw_1 >> 3) & 1)
            return getattr(self, '_m_eps_beacon_error_i2c_fram1', None)

        @property
        def eps_beacon_error_mcu5_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu5_i2c'):
                return self._m_eps_beacon_error_mcu5_i2c

            self._m_eps_beacon_error_mcu5_i2c = ((self.eps_beacon_error_mask_raw_2 >> 1) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu5_i2c', None)

        @property
        def eps_beacon_balancer_is_balancing(self):
            if hasattr(self, '_m_eps_beacon_balancer_is_balancing'):
                return self._m_eps_beacon_balancer_is_balancing

            self._m_eps_beacon_balancer_is_balancing = ((self.eps_beacon_balancer_info_raw >> 3) & 1)
            return getattr(self, '_m_eps_beacon_balancer_is_balancing', None)

        @property
        def eps_beacon_error_i2c_bat_monitor(self):
            if hasattr(self, '_m_eps_beacon_error_i2c_bat_monitor'):
                return self._m_eps_beacon_error_i2c_bat_monitor

            self._m_eps_beacon_error_i2c_bat_monitor = ((self.eps_beacon_error_mask_raw_1 >> 0) & 1)
            return getattr(self, '_m_eps_beacon_error_i2c_bat_monitor', None)

        @property
        def eps_beacon_balancer_active_balancer(self):
            if hasattr(self, '_m_eps_beacon_balancer_active_balancer'):
                return self._m_eps_beacon_balancer_active_balancer

            self._m_eps_beacon_balancer_active_balancer = ((self.eps_beacon_balancer_info_raw >> 4) & 3)
            return getattr(self, '_m_eps_beacon_balancer_active_balancer', None)

        @property
        def eps_beacon_ext_mcu6ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu6ch1'):
                return self._m_eps_beacon_ext_mcu6ch1

            self._m_eps_beacon_ext_mcu6ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 9) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu6ch1', None)

        @property
        def eps_beacon_ext_mcu7ch1(self):
            if hasattr(self, '_m_eps_beacon_ext_mcu7ch1'):
                return self._m_eps_beacon_ext_mcu7ch1

            self._m_eps_beacon_ext_mcu7ch1 = ((self.eps_beacon_mask_enabled_ext_devices_raw >> 11) & 1)
            return getattr(self, '_m_eps_beacon_ext_mcu7ch1', None)

        @property
        def eps_beacon_balancer_state(self):
            if hasattr(self, '_m_eps_beacon_balancer_state'):
                return self._m_eps_beacon_balancer_state

            self._m_eps_beacon_balancer_state = ((self.eps_beacon_balancer_info_raw >> 0) & 3)
            return getattr(self, '_m_eps_beacon_balancer_state', None)

        @property
        def eps_beacon_error_spi_bat_monitor(self):
            if hasattr(self, '_m_eps_beacon_error_spi_bat_monitor'):
                return self._m_eps_beacon_error_spi_bat_monitor

            self._m_eps_beacon_error_spi_bat_monitor = ((self.eps_beacon_error_mask_raw_1 >> 1) & 1)
            return getattr(self, '_m_eps_beacon_error_spi_bat_monitor', None)

        @property
        def eps_beacon_error_mcu8_i2c(self):
            if hasattr(self, '_m_eps_beacon_error_mcu8_i2c'):
                return self._m_eps_beacon_error_mcu8_i2c

            self._m_eps_beacon_error_mcu8_i2c = ((self.eps_beacon_error_mask_raw_2 >> 4) & 1)
            return getattr(self, '_m_eps_beacon_error_mcu8_i2c', None)


    class GnssTlm(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.gnss_type_byte = self._io.read_u1()
            _on = self.gnss_type_byte
            if _on == 66:
                self.gnss_payload = Geoscan16u.GnssTlm66(self._io, self, self._root)
            elif _on == 67:
                self.gnss_payload = Geoscan16u.GnssTlm67(self._io, self, self._root)
            elif _on == 70:
                self.gnss_payload = Geoscan16u.GnssTlm70(self._io, self, self._root)


    class GnssTlm67(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.posix_time_s = self._io.read_u4le()
            self.coord_x = self._io.read_f4le()
            self.coord_y = self._io.read_f4le()
            self.coord_z = self._io.read_f4le()
            self.velocity_x = self._io.read_f4le()
            self.velocity_y = self._io.read_f4le()
            self.velocity_z = self._io.read_f4le()
            self.quaternion_q0 = self._io.read_f4le()
            self.quaternion_q1 = self._io.read_f4le()
            self.quaternion_q2 = self._io.read_f4le()
            self.quaternion_q3 = self._io.read_f4le()
            self.angular_velocity_x = self._io.read_f4le()
            self.angular_velocity_y = self._io.read_f4le()
            self.angular_velocity_z = self._io.read_f4le()
            self.reserved0 = self._io.read_u2le()
            self.reserved1 = self._io.read_u8le()


    class GnssTlm66(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.posix_time_ms = self._io.read_u8le()
            self.coord_x = self._io.read_f4le()
            self.coord_y = self._io.read_f4le()
            self.coord_z = self._io.read_f4le()
            self.velocity_x = self._io.read_f4le()
            self.velocity_y = self._io.read_f4le()
            self.velocity_z = self._io.read_f4le()
            self.quaternion_q0 = self._io.read_f4le()
            self.quaternion_q1 = self._io.read_f4le()
            self.quaternion_q2 = self._io.read_f4le()
            self.quaternion_q3 = self._io.read_f4le()
            self.ref_motion_mode = self._io.read_u1()
            self.mag_torquer_mode = self._io.read_u1()
            self.filter_type = self._io.read_u1()
            self.orientation_system_status = self._io.read_u1()
            self.reserved = self._io.read_u2le()
            self.azdk_quaternion_q1 = self._io.read_f4le()
            self.azdk_quaternion_q2 = self._io.read_f4le()
            self.azdk_quaternion_q3 = self._io.read_f4le()


    class GeoscanBeaconTlm(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.beacon_id = self._io.read_u1()
            self.eps_1_mode = self._io.read_u1()
            self.eps_1_consumption_current = self._io.read_u2le()
            self.eps_1_solar_cells_current = self._io.read_u2le()
            self.eps_1_cell_voltage_full = self._io.read_u2le()
            self.eps_1_battery_temperature = self._io.read_s1()
            self.eps_1_temperature_sp_y_pos = self._io.read_s1()
            self.eps_1_temperature_sp_y_neg = self._io.read_s1()
            self.eps_1_temperature_sp_x_pos = self._io.read_s1()
            self.eps_1_temperature_sp_x_neg = self._io.read_s1()
            self.eps_1_systems_status = self._io.read_u2le()
            self.eps_1_boot_count = self._io.read_u2le()
            self.eps_2_mode = self._io.read_u1()
            self.eps_2_consumption_current = self._io.read_u2le()
            self.eps_2_solar_cells_current = self._io.read_u2le()
            self.eps_2_cell_voltage_full = self._io.read_u2le()
            self.eps_2_battery_temperature = self._io.read_s1()
            self.eps_2_temperature_sp_y_pos = self._io.read_s1()
            self.eps_2_temperature_sp_y_neg = self._io.read_s1()
            self.eps_2_temperature_sp_x_pos = self._io.read_s1()
            self.eps_2_temperature_sp_x_neg = self._io.read_s1()
            self.eps_2_systems_status = self._io.read_u2le()
            self.eps_2_boot_count = self._io.read_u2le()
            self.adcs_mt_mode = self._io.read_u1()
            self.adcs_rm_mode = self._io.read_u1()
            self.adcs_kf_mode = self._io.read_u1()
            self.adcs_filter_reset_count = self._io.read_u1()
            self.adcs_sensors_state = self._io.read_u2le()
            self.adcs_flywheel_state = self._io.read_u1()
            self.comm_type = self._io.read_u1()
            self.comm_vbus_voltage = self._io.read_u2le()
            self.comm_boot_count = self._io.read_u2le()
            self.comm_rssi = self._io.read_s1()
            self.comm_rssi_minimal = self._io.read_s1()
            self.comm_received_valid_packets = self._io.read_u1()
            self.comm_received_invalid_packets = self._io.read_u1()
            self.comm_sent_packets = self._io.read_u1()
            self.comm_status = self._io.read_u1()
            self.comm_mode = self._io.read_u1()
            self.comm_amp_temperature = self._io.read_s1()
            self.comm_reserved_1 = self._io.read_u2le()
            self.comm_reserved_2 = self._io.read_u1()

        @property
        def eps_2_mcu7ch2_fecu_rtr(self):
            if hasattr(self, '_m_eps_2_mcu7ch2_fecu_rtr'):
                return self._m_eps_2_mcu7ch2_fecu_rtr

            self._m_eps_2_mcu7ch2_fecu_rtr = ((self.eps_2_systems_status >> 12) & 1)
            return getattr(self, '_m_eps_2_mcu7ch2_fecu_rtr', None)

        @property
        def eps_2_mcu8ch2_payload2_camera_heater(self):
            if hasattr(self, '_m_eps_2_mcu8ch2_payload2_camera_heater'):
                return self._m_eps_2_mcu8ch2_payload2_camera_heater

            self._m_eps_2_mcu8ch2_payload2_camera_heater = ((self.eps_2_systems_status >> 14) & 1)
            return getattr(self, '_m_eps_2_mcu8ch2_payload2_camera_heater', None)

        @property
        def eps_2_mcu1ch2_commu1(self):
            if hasattr(self, '_m_eps_2_mcu1ch2_commu1'):
                return self._m_eps_2_mcu1ch2_commu1

            self._m_eps_2_mcu1ch2_commu1 = ((self.eps_2_systems_status >> 1) & 1)
            return getattr(self, '_m_eps_2_mcu1ch2_commu1', None)

        @property
        def eps_1_mcu1ch2_commu1(self):
            if hasattr(self, '_m_eps_1_mcu1ch2_commu1'):
                return self._m_eps_1_mcu1ch2_commu1

            self._m_eps_1_mcu1ch2_commu1 = ((self.eps_1_systems_status >> 1) & 1)
            return getattr(self, '_m_eps_1_mcu1ch2_commu1', None)

        @property
        def eps_1_mcu6ch2_starsns2(self):
            if hasattr(self, '_m_eps_1_mcu6ch2_starsns2'):
                return self._m_eps_1_mcu6ch2_starsns2

            self._m_eps_1_mcu6ch2_starsns2 = ((self.eps_1_systems_status >> 10) & 1)
            return getattr(self, '_m_eps_1_mcu6ch2_starsns2', None)

        @property
        def comm_antenna_detector(self):
            if hasattr(self, '_m_comm_antenna_detector'):
                return self._m_comm_antenna_detector

            self._m_comm_antenna_detector = ((self.comm_status >> 0) & 1)
            return getattr(self, '_m_comm_antenna_detector', None)

        @property
        def eps_1_mcu4ch1_payload3_lepton_bridge(self):
            if hasattr(self, '_m_eps_1_mcu4ch1_payload3_lepton_bridge'):
                return self._m_eps_1_mcu4ch1_payload3_lepton_bridge

            self._m_eps_1_mcu4ch1_payload3_lepton_bridge = ((self.eps_1_systems_status >> 6) & 1)
            return getattr(self, '_m_eps_1_mcu4ch1_payload3_lepton_bridge', None)

        @property
        def eps_2_mcu6ch1_adcs2(self):
            if hasattr(self, '_m_eps_2_mcu6ch1_adcs2'):
                return self._m_eps_2_mcu6ch1_adcs2

            self._m_eps_2_mcu6ch1_adcs2 = ((self.eps_2_systems_status >> 9) & 1)
            return getattr(self, '_m_eps_2_mcu6ch1_adcs2', None)

        @property
        def eps_1_mcu7ch1_rws(self):
            if hasattr(self, '_m_eps_1_mcu7ch1_rws'):
                return self._m_eps_1_mcu7ch1_rws

            self._m_eps_1_mcu7ch1_rws = ((self.eps_1_systems_status >> 11) & 1)
            return getattr(self, '_m_eps_1_mcu7ch1_rws', None)

        @property
        def eps_1_mcu8ch1_payload1_heater(self):
            if hasattr(self, '_m_eps_1_mcu8ch1_payload1_heater'):
                return self._m_eps_1_mcu8ch1_payload1_heater

            self._m_eps_1_mcu8ch1_payload1_heater = ((self.eps_1_systems_status >> 13) & 1)
            return getattr(self, '_m_eps_1_mcu8ch1_payload1_heater', None)

        @property
        def eps_1_mcu5ch1_gyro1(self):
            if hasattr(self, '_m_eps_1_mcu5ch1_gyro1'):
                return self._m_eps_1_mcu5ch1_gyro1

            self._m_eps_1_mcu5ch1_gyro1 = ((self.eps_1_systems_status >> 8) & 1)
            return getattr(self, '_m_eps_1_mcu5ch1_gyro1', None)

        @property
        def eps_1_mcu1ch1_obc(self):
            if hasattr(self, '_m_eps_1_mcu1ch1_obc'):
                return self._m_eps_1_mcu1ch1_obc

            self._m_eps_1_mcu1ch1_obc = ((self.eps_1_systems_status >> 0) & 1)
            return getattr(self, '_m_eps_1_mcu1ch1_obc', None)

        @property
        def eps_2_timekeeper(self):
            if hasattr(self, '_m_eps_2_timekeeper'):
                return self._m_eps_2_timekeeper

            self._m_eps_2_timekeeper = ((self.eps_2_systems_status >> 15) & 1)
            return getattr(self, '_m_eps_2_timekeeper', None)

        @property
        def eps_2_mcu2ch1_comms_plasgu(self):
            if hasattr(self, '_m_eps_2_mcu2ch1_comms_plasgu'):
                return self._m_eps_2_mcu2ch1_comms_plasgu

            self._m_eps_2_mcu2ch1_comms_plasgu = ((self.eps_2_systems_status >> 2) & 1)
            return getattr(self, '_m_eps_2_mcu2ch1_comms_plasgu', None)

        @property
        def eps_2_mcu1ch1_obc(self):
            if hasattr(self, '_m_eps_2_mcu1ch1_obc'):
                return self._m_eps_2_mcu1ch1_obc

            self._m_eps_2_mcu1ch1_obc = ((self.eps_2_systems_status >> 0) & 1)
            return getattr(self, '_m_eps_2_mcu1ch1_obc', None)

        @property
        def eps_2_mcu3ch1_adcs1(self):
            if hasattr(self, '_m_eps_2_mcu3ch1_adcs1'):
                return self._m_eps_2_mcu3ch1_adcs1

            self._m_eps_2_mcu3ch1_adcs1 = ((self.eps_2_systems_status >> 4) & 1)
            return getattr(self, '_m_eps_2_mcu3ch1_adcs1', None)

        @property
        def eps_2_mcu6ch2_starsns2(self):
            if hasattr(self, '_m_eps_2_mcu6ch2_starsns2'):
                return self._m_eps_2_mcu6ch2_starsns2

            self._m_eps_2_mcu6ch2_starsns2 = ((self.eps_2_systems_status >> 10) & 1)
            return getattr(self, '_m_eps_2_mcu6ch2_starsns2', None)

        @property
        def eps_2_mcu8ch1_payload1_heater(self):
            if hasattr(self, '_m_eps_2_mcu8ch1_payload1_heater'):
                return self._m_eps_2_mcu8ch1_payload1_heater

            self._m_eps_2_mcu8ch1_payload1_heater = ((self.eps_2_systems_status >> 13) & 1)
            return getattr(self, '_m_eps_2_mcu8ch1_payload1_heater', None)

        @property
        def eps_2_mcu4ch2_commx(self):
            if hasattr(self, '_m_eps_2_mcu4ch2_commx'):
                return self._m_eps_2_mcu4ch2_commx

            self._m_eps_2_mcu4ch2_commx = ((self.eps_2_systems_status >> 7) & 1)
            return getattr(self, '_m_eps_2_mcu4ch2_commx', None)

        @property
        def comm_fec_on(self):
            if hasattr(self, '_m_comm_fec_on'):
                return self._m_comm_fec_on

            self._m_comm_fec_on = ((self.comm_status >> 2) & 1)
            return getattr(self, '_m_comm_fec_on', None)

        @property
        def eps_1_timekeeper(self):
            if hasattr(self, '_m_eps_1_timekeeper'):
                return self._m_eps_1_timekeeper

            self._m_eps_1_timekeeper = ((self.eps_1_systems_status >> 15) & 1)
            return getattr(self, '_m_eps_1_timekeeper', None)

        @property
        def eps_1_mcu3ch2_starsns1(self):
            if hasattr(self, '_m_eps_1_mcu3ch2_starsns1'):
                return self._m_eps_1_mcu3ch2_starsns1

            self._m_eps_1_mcu3ch2_starsns1 = ((self.eps_1_systems_status >> 5) & 1)
            return getattr(self, '_m_eps_1_mcu3ch2_starsns1', None)

        @property
        def eps_1_mcu4ch2_commx(self):
            if hasattr(self, '_m_eps_1_mcu4ch2_commx'):
                return self._m_eps_1_mcu4ch2_commx

            self._m_eps_1_mcu4ch2_commx = ((self.eps_1_systems_status >> 7) & 1)
            return getattr(self, '_m_eps_1_mcu4ch2_commx', None)

        @property
        def eps_2_mcu2ch2_commu2(self):
            if hasattr(self, '_m_eps_2_mcu2ch2_commu2'):
                return self._m_eps_2_mcu2ch2_commu2

            self._m_eps_2_mcu2ch2_commu2 = ((self.eps_2_systems_status >> 3) & 1)
            return getattr(self, '_m_eps_2_mcu2ch2_commu2', None)

        @property
        def eps_1_mcu2ch2_commu2(self):
            if hasattr(self, '_m_eps_1_mcu2ch2_commu2'):
                return self._m_eps_1_mcu2ch2_commu2

            self._m_eps_1_mcu2ch2_commu2 = ((self.eps_1_systems_status >> 3) & 1)
            return getattr(self, '_m_eps_1_mcu2ch2_commu2', None)

        @property
        def eps_1_mcu2ch1_comms_plasgu(self):
            if hasattr(self, '_m_eps_1_mcu2ch1_comms_plasgu'):
                return self._m_eps_1_mcu2ch1_comms_plasgu

            self._m_eps_1_mcu2ch1_comms_plasgu = ((self.eps_1_systems_status >> 2) & 1)
            return getattr(self, '_m_eps_1_mcu2ch1_comms_plasgu', None)

        @property
        def comm_mode_correct(self):
            if hasattr(self, '_m_comm_mode_correct'):
                return self._m_comm_mode_correct

            self._m_comm_mode_correct = ((self.comm_status >> 1) & 1)
            return getattr(self, '_m_comm_mode_correct', None)

        @property
        def eps_1_mcu3ch1_adcs1(self):
            if hasattr(self, '_m_eps_1_mcu3ch1_adcs1'):
                return self._m_eps_1_mcu3ch1_adcs1

            self._m_eps_1_mcu3ch1_adcs1 = ((self.eps_1_systems_status >> 4) & 1)
            return getattr(self, '_m_eps_1_mcu3ch1_adcs1', None)

        @property
        def eps_2_mcu7ch1_rws(self):
            if hasattr(self, '_m_eps_2_mcu7ch1_rws'):
                return self._m_eps_2_mcu7ch1_rws

            self._m_eps_2_mcu7ch1_rws = ((self.eps_2_systems_status >> 11) & 1)
            return getattr(self, '_m_eps_2_mcu7ch1_rws', None)

        @property
        def eps_2_mcu3ch2_starsns1(self):
            if hasattr(self, '_m_eps_2_mcu3ch2_starsns1'):
                return self._m_eps_2_mcu3ch2_starsns1

            self._m_eps_2_mcu3ch2_starsns1 = ((self.eps_2_systems_status >> 5) & 1)
            return getattr(self, '_m_eps_2_mcu3ch2_starsns1', None)

        @property
        def eps_1_mcu6ch1_adcs2(self):
            if hasattr(self, '_m_eps_1_mcu6ch1_adcs2'):
                return self._m_eps_1_mcu6ch1_adcs2

            self._m_eps_1_mcu6ch1_adcs2 = ((self.eps_1_systems_status >> 9) & 1)
            return getattr(self, '_m_eps_1_mcu6ch1_adcs2', None)

        @property
        def eps_2_mcu4ch1_payload3_lepton_bridge(self):
            if hasattr(self, '_m_eps_2_mcu4ch1_payload3_lepton_bridge'):
                return self._m_eps_2_mcu4ch1_payload3_lepton_bridge

            self._m_eps_2_mcu4ch1_payload3_lepton_bridge = ((self.eps_2_systems_status >> 6) & 1)
            return getattr(self, '_m_eps_2_mcu4ch1_payload3_lepton_bridge', None)

        @property
        def eps_2_mcu5ch1_gyro1(self):
            if hasattr(self, '_m_eps_2_mcu5ch1_gyro1'):
                return self._m_eps_2_mcu5ch1_gyro1

            self._m_eps_2_mcu5ch1_gyro1 = ((self.eps_2_systems_status >> 8) & 1)
            return getattr(self, '_m_eps_2_mcu5ch1_gyro1', None)

        @property
        def eps_1_mcu8ch2_payload2_camera_heater(self):
            if hasattr(self, '_m_eps_1_mcu8ch2_payload2_camera_heater'):
                return self._m_eps_1_mcu8ch2_payload2_camera_heater

            self._m_eps_1_mcu8ch2_payload2_camera_heater = ((self.eps_1_systems_status >> 14) & 1)
            return getattr(self, '_m_eps_1_mcu8ch2_payload2_camera_heater', None)

        @property
        def eps_1_mcu7ch2_fecu_rtr(self):
            if hasattr(self, '_m_eps_1_mcu7ch2_fecu_rtr'):
                return self._m_eps_1_mcu7ch2_fecu_rtr

            self._m_eps_1_mcu7ch2_fecu_rtr = ((self.eps_1_systems_status >> 12) & 1)
            return getattr(self, '_m_eps_1_mcu7ch2_fecu_rtr', None)


    class CallsignRaw(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self._raw__raw_callsign_ror = self._io.read_bytes(6)
            self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
            _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
            self.callsign_ror = Geoscan16u.Callsign(_io__raw_callsign_ror, self, self._root)


    class CallsignEndRaw(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign_end_str = (self._io.read_bytes(4)).decode(u"ASCII")


    class DataFrame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.data_header = Geoscan16u.DataHeader(self._io, self, self._root)
            self.data_payload = Geoscan16u.DataTlm(self._io, self, self._root)


    @property
    def len(self):
        if hasattr(self, '_m_len'):
            return self._m_len

        self._m_len = self._io.size()
        return getattr(self, '_m_len', None)

    @property
    def type(self):
        if hasattr(self, '_m_type'):
            return self._m_type

        _pos = self._io.pos()
        self._io.seek(0)
        self._m_type = self._io.read_u2be()
        self._io.seek(_pos)
        return getattr(self, '_m_type', None)


