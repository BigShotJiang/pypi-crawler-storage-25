# This is a generated file! Please edit source .ksy file and use kaitai-struct-compiler to rebuild

import kaitaistruct
from kaitaistruct import KaitaiStruct, KaitaiStream, BytesIO


if getattr(kaitaistruct, 'API_VERSION', (0, 9)) < (0, 9):
    raise Exception("Incompatible Kaitai Struct Python API: 0.9 or later is required, but you have %s" % (kaitaistruct.__version__))

class Cp16(KaitaiStruct):
    """:field cp16_dest_callsign: ax25_frame.ax25_header.dest_callsign_raw.callsign_ror.callsign
    :field cp16_dest_ssid_mask: ax25_frame.ax25_header.dest_ssid_raw.ssid_mask
    :field cp16_dest_ssid: ax25_frame.ax25_header.dest_ssid_raw.ssid
    :field cp16_src_callsign: ax25_frame.ax25_header.src_callsign_raw.callsign_ror.callsign
    :field cp16_src_ssid_mask: ax25_frame.ax25_header.src_ssid_raw.ssid_mask
    :field cp16_src_ssid: ax25_frame.ax25_header.src_ssid_raw.ssid
    :field cp16_ctl: ax25_frame.ax25_header.ctl
    :field cp16_pid: ax25_frame.payload.pid
    :field cp16_daughter_a_temp: ax25_frame.payload.ax25_info.contents.various_temp.daughter_a_temp
    :field cp16_payload_3v3_temp: ax25_frame.payload.ax25_info.contents.various_temp.payload_3v3_temp
    :field cp16_rf_amp_temp: ax25_frame.payload.ax25_info.contents.various_temp.rf_amp_temp
    :field cp16_atmel_pwr_curr: ax25_frame.payload.ax25_info.contents.various_power.atmel_pwr_curr
    :field cp16_atmel_pwr_volt: ax25_frame.payload.ax25_info.contents.various_power.atmel_pwr_volt
    :field cp16_bus_3v3_curr: ax25_frame.payload.ax25_info.contents.various_power.bus_3v3_curr
    :field cp16_bus_3v3_volt: ax25_frame.payload.ax25_info.contents.various_power.bus_3v3_volt
    :field cp16_payload_3v3_curr: ax25_frame.payload.ax25_info.contents.various_power.payload_3v3_curr
    :field cp16_payload_3v3_volt: ax25_frame.payload.ax25_info.contents.various_power.payload_3v3_volt
    :field cp16_payload_5v0_curr: ax25_frame.payload.ax25_info.contents.various_power.payload_5v0_curr
    :field cp16_payload_5v0_volt: ax25_frame.payload.ax25_info.contents.various_power.payload_5v0_volt
    :field cp16_rf_amp_curr: ax25_frame.payload.ax25_info.contents.various_power.rf_amp_curr
    :field cp16_rf_amp_volt: ax25_frame.payload.ax25_info.contents.various_power.rf_amp_volt
    :field cp16_neg_x_solar1_volt: ax25_frame.payload.ax25_info.contents.neg_x.solar1_volt
    :field cp16_neg_x_solar1_curr: ax25_frame.payload.ax25_info.contents.neg_x.solar1_curr
    :field cp16_neg_x_solar2_volt: ax25_frame.payload.ax25_info.contents.neg_x.solar2_volt
    :field cp16_neg_x_solar2_curr: ax25_frame.payload.ax25_info.contents.neg_x.solar2_curr
    :field cp16_neg_x_solar3_volt: ax25_frame.payload.ax25_info.contents.neg_x.solar3_volt
    :field cp16_neg_x_solar3_curr: ax25_frame.payload.ax25_info.contents.neg_x.solar3_curr
    :field cp16_neg_x_side_temp: ax25_frame.payload.ax25_info.contents.neg_x.side_temp
    :field cp16_pos_x_solar1_volt: ax25_frame.payload.ax25_info.contents.pos_x.solar1_volt
    :field cp16_pos_x_solar1_curr: ax25_frame.payload.ax25_info.contents.pos_x.solar1_curr
    :field cp16_pos_x_solar2_volt: ax25_frame.payload.ax25_info.contents.pos_x.solar2_volt
    :field cp16_pos_x_solar2_curr: ax25_frame.payload.ax25_info.contents.pos_x.solar2_curr
    :field cp16_pos_x_solar3_volt: ax25_frame.payload.ax25_info.contents.pos_x.solar3_volt
    :field cp16_pos_x_solar3_curr: ax25_frame.payload.ax25_info.contents.pos_x.solar3_curr
    :field cp16_pos_x_side_temp: ax25_frame.payload.ax25_info.contents.pos_x.side_temp
    :field cp16_neg_y_solar1_volt: ax25_frame.payload.ax25_info.contents.neg_y.solar1_volt
    :field cp16_neg_y_solar1_curr: ax25_frame.payload.ax25_info.contents.neg_y.solar1_curr
    :field cp16_neg_y_solar2_volt: ax25_frame.payload.ax25_info.contents.neg_y.solar2_volt
    :field cp16_neg_y_solar2_curr: ax25_frame.payload.ax25_info.contents.neg_y.solar2_curr
    :field cp16_neg_y_solar3_volt: ax25_frame.payload.ax25_info.contents.neg_y.solar3_volt
    :field cp16_neg_y_solar3_curr: ax25_frame.payload.ax25_info.contents.neg_y.solar3_curr
    :field cp16_neg_y_side_temp: ax25_frame.payload.ax25_info.contents.neg_y.side_temp
    :field cp16_pos_y_solar1_volt: ax25_frame.payload.ax25_info.contents.pos_y.solar1_volt
    :field cp16_pos_y_solar1_curr: ax25_frame.payload.ax25_info.contents.pos_y.solar1_curr
    :field cp16_pos_y_solar2_volt: ax25_frame.payload.ax25_info.contents.pos_y.solar2_volt
    :field cp16_pos_y_solar2_curr: ax25_frame.payload.ax25_info.contents.pos_y.solar2_curr
    :field cp16_pos_y_solar3_volt: ax25_frame.payload.ax25_info.contents.pos_y.solar3_volt
    :field cp16_pos_y_solar3_curr: ax25_frame.payload.ax25_info.contents.pos_y.solar3_curr
    :field cp16_pos_y_side_temp: ax25_frame.payload.ax25_info.contents.pos_y.side_temp
    :field cp16_neg_z_temp: ax25_frame.payload.ax25_info.contents.neg_z_temp
    :field cp16_user_cpu_time: ax25_frame.payload.ax25_info.contents.flight_software_telem.user_cpu_time
    :field cp16_nice_cpu_time: ax25_frame.payload.ax25_info.contents.flight_software_telem.nice_cpu_time
    :field cp16_sys_cpu_time: ax25_frame.payload.ax25_info.contents.flight_software_telem.sys_cpu_time
    :field cp16_idle_cpu_time: ax25_frame.payload.ax25_info.contents.flight_software_telem.idle_cpu_time
    :field cp16_processes: ax25_frame.payload.ax25_info.contents.flight_software_telem.processes
    :field cp16_procs_running: ax25_frame.payload.ax25_info.contents.flight_software_telem.procs_running
    :field cp16_procs_blocked: ax25_frame.payload.ax25_info.contents.flight_software_telem.procs_blocked
    :field cp16_mem_free: ax25_frame.payload.ax25_info.contents.flight_software_telem.mem_free
    :field cp16_mem_buffered: ax25_frame.payload.ax25_info.contents.flight_software_telem.mem_buffered
    :field cp16_mem_cached: ax25_frame.payload.ax25_info.contents.flight_software_telem.mem_cached
    :field cp16_vmalloc_total: ax25_frame.payload.ax25_info.contents.flight_software_telem.vmalloc_total
    :field cp16_vmalloc_used: ax25_frame.payload.ax25_info.contents.flight_software_telem.vmalloc_used
    :field cp16_dir_data_free_is_kb: ax25_frame.payload.ax25_info.contents.flight_software_telem.dir_data_free.is_kb
    :field cp16_dir_data_free_value: ax25_frame.payload.ax25_info.contents.flight_software_telem.dir_data_free.value
    :field cp16_dir_sdcard_free_is_kb: ax25_frame.payload.ax25_info.contents.flight_software_telem.dir_sdcard_free.is_kb
    :field cp16_dir_sdcard_free_value: ax25_frame.payload.ax25_info.contents.flight_software_telem.dir_sdcard_free.value
    :field cp16_lo_bytes: ax25_frame.payload.ax25_info.contents.flight_software_telem.lo_bytes
    :field cp16_lo_packets: ax25_frame.payload.ax25_info.contents.flight_software_telem.lo_packets
    :field cp16_nand_erasures: ax25_frame.payload.ax25_info.contents.flight_software_telem.nand_erasures
    :field cp16_load_1min: ax25_frame.payload.ax25_info.contents.flight_software_telem.load_1min
    :field cp16_load_5min: ax25_frame.payload.ax25_info.contents.flight_software_telem.load_5min
    :field cp16_load_15min: ax25_frame.payload.ax25_info.contents.flight_software_telem.load_15min
    :field cp16_beacon_count: ax25_frame.payload.ax25_info.contents.flight_software_telem.beacon_count
    :field cp16_rtc: ax25_frame.payload.ax25_info.contents.flight_software_telem.rtc
    :field cp16_boot_time: ax25_frame.payload.ax25_info.contents.flight_software_telem.boot_time
    :field cp16_long_dur_counter: ax25_frame.payload.ax25_info.contents.flight_software_telem.long_dur_counter
    :field cp16_rx_packets_raw: ax25_frame.payload.ax25_info.contents.comms_parameters.rx_packets_raw
    :field cp16_tx_packets_raw: ax25_frame.payload.ax25_info.contents.comms_parameters.tx_packets_raw
    :field cp16_rx_bytes_raw: ax25_frame.payload.ax25_info.contents.comms_parameters.rx_bytes_raw
    :field cp16_tx_bytes_raw: ax25_frame.payload.ax25_info.contents.comms_parameters.tx_bytes_raw
    :field cp16_comms_parameters_callsign0_callsign: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign0.callsign
    :field cp16_comms_parameters_callsign0_ssid_char_raw: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign0.ssid_char_raw
    :field cp16_comms_parameters_callsign0_last_rx: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign0.last_rx
    :field cp16_comms_parameters_callsign0_ssid_num: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign0.ssid_num
    :field cp16_comms_parameters_callsign1_callsign: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign1.callsign
    :field cp16_comms_parameters_callsign1_ssid_char_raw: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign1.ssid_char_raw
    :field cp16_comms_parameters_callsign1_last_rx: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign1.last_rx
    :field cp16_comms_parameters_callsign1_ssid_num: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign1.ssid_num
    :field cp16_comms_parameters_callsign2_callsign: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign2.callsign
    :field cp16_comms_parameters_callsign2_ssid_char_raw: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign2.ssid_char_raw
    :field cp16_comms_parameters_callsign2_last_rx: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign2.last_rx
    :field cp16_comms_parameters_callsign2_ssid_num: ax25_frame.payload.ax25_info.contents.comms_parameters.callsign2.ssid_num
    :field cp16_rx_packets: ax25_frame.payload.ax25_info.contents.comms_parameters.rx_packets
    :field cp16_tx_packets: ax25_frame.payload.ax25_info.contents.comms_parameters.tx_packets
    :field cp16_rx_bytes: ax25_frame.payload.ax25_info.contents.comms_parameters.rx_bytes
    :field cp16_tx_bytes: ax25_frame.payload.ax25_info.contents.comms_parameters.tx_bytes
    :field cp16_carp_b_3v3_volt: ax25_frame.payload.ax25_info.contents.carp.carp_b_3v3_volt
    :field cp16_carp_b_3v3_curr: ax25_frame.payload.ax25_info.contents.carp.carp_b_3v3_curr
    :field cp16_carp_b_1v8_volt: ax25_frame.payload.ax25_info.contents.carp.carp_b_1v8_volt
    :field cp16_carp_b_1v8_curr: ax25_frame.payload.ax25_info.contents.carp.carp_b_1v8_curr
    :field cp16_carp_b_event_count: ax25_frame.payload.ax25_info.contents.carp.carp_b_event_count
    :field cp16_carp_b_latch_count: ax25_frame.payload.ax25_info.contents.carp.carp_b_latch_count
    :field cp16_pib_temp_intern: ax25_frame.payload.ax25_info.contents.carp.pib_temp_intern
    :field cp16_pib_temp_extern: ax25_frame.payload.ax25_info.contents.carp.pib_temp_extern
    :field cp16_owl_latest_radio_cfg: ax25_frame.payload.ax25_info.contents.owl.owl_latest_radio_cfg
    :field cp16_owl_last_rx_action_cmd: ax25_frame.payload.ax25_info.contents.owl.owl_last_rx_action_cmd
    :field cp16_owl_rssi_latest: ax25_frame.payload.ax25_info.contents.owl.owl_rssi_latest
    :field cp16_owl_snr_latest: ax25_frame.payload.ax25_info.contents.owl.owl_snr_latest
    :field cp16_owl_var_byte1: ax25_frame.payload.ax25_info.contents.owl.owl_var_byte1
    :field cp16_owl_var_byte2: ax25_frame.payload.ax25_info.contents.owl.owl_var_byte2
    :field cp16_owl_var_byte3: ax25_frame.payload.ax25_info.contents.owl.owl_var_byte3
    :field cp16_owl_var_byte4: ax25_frame.payload.ax25_info.contents.owl.owl_var_byte4
    :field cp16_accel_x: ax25_frame.payload.ax25_info.contents.imu_data.accel_x
    :field cp16_accel_y: ax25_frame.payload.ax25_info.contents.imu_data.accel_y
    :field cp16_accel_z: ax25_frame.payload.ax25_info.contents.imu_data.accel_z
    :field cp16_gyro_x: ax25_frame.payload.ax25_info.contents.imu_data.gyro_x
    :field cp16_gyro_y: ax25_frame.payload.ax25_info.contents.imu_data.gyro_y
    :field cp16_gyro_z: ax25_frame.payload.ax25_info.contents.imu_data.gyro_z
    :field cp16_mag_x: ax25_frame.payload.ax25_info.contents.imu_data.mag_x
    :field cp16_mag_y: ax25_frame.payload.ax25_info.contents.imu_data.mag_y
    :field cp16_mag_z: ax25_frame.payload.ax25_info.contents.imu_data.mag_z
    :field cp16_picture_count: ax25_frame.payload.ax25_info.contents.camera.picture_count
    :field cp16_thumbnail_count: ax25_frame.payload.ax25_info.contents.camera.thumbnail_count
    """
    def __init__(self, _io, _parent=None, _root=None):
        self._io = _io
        self._parent = _parent
        self._root = _root if _root else self
        self._read()

    def _read(self):
        self.ax25_frame = Cp16.Ax25Frame(self._io, self, self._root)

    class Ax25Frame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ax25_header = Cp16.Ax25Header(self._io, self, self._root)
            _on = (self.ax25_header.ctl & 19)
            if _on == 0:
                self.payload = Cp16.IFrame(self._io, self, self._root)
            elif _on == 3:
                self.payload = Cp16.UiFrame(self._io, self, self._root)
            elif _on == 19:
                self.payload = Cp16.UiFrame(self._io, self, self._root)
            elif _on == 16:
                self.payload = Cp16.IFrame(self._io, self, self._root)
            elif _on == 18:
                self.payload = Cp16.IFrame(self._io, self, self._root)
            elif _on == 2:
                self.payload = Cp16.IFrame(self._io, self, self._root)


    class Ax25Header(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.dest_callsign_raw = Cp16.CallsignRaw(self._io, self, self._root)
            self.dest_ssid_raw = Cp16.SsidMask(self._io, self, self._root)
            self.src_callsign_raw = Cp16.CallsignRaw(self._io, self, self._root)
            _ = self.src_callsign_raw
            if not _.callsign_ror.callsign == u"KK6HIT":
                raise kaitaistruct.ValidationExprError(self.src_callsign_raw, self._io, u"/types/ax25_header/seq/2")
            self.src_ssid_raw = Cp16.SsidMask(self._io, self, self._root)
            _ = self.src_ssid_raw
            if not _.ssid == 6:
                raise kaitaistruct.ValidationExprError(self.src_ssid_raw, self._io, u"/types/ax25_header/seq/3")
            if (self.src_ssid_raw.ssid_mask & 1) == 0:
                self.repeater = Cp16.Repeater(self._io, self, self._root)

            self.ctl = self._io.read_u1()


    class UiFrame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.pid = self._io.read_u1()
            if not self.pid == 204:
                raise kaitaistruct.ValidationNotEqualError(204, self.pid, self._io, u"/types/ui_frame/seq/0")
            self.ax25_info = Cp16.Ipv4Packet(self._io, self, self._root)


    class OwlVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.owl_latest_radio_cfg = self._io.read_u1()
            self.owl_last_rx_action_cmd = self._io.read_u1()
            self.owl_rssi_latest = self._io.read_u1()
            self.owl_snr_latest = self._io.read_s1()
            self.owl_var_byte1 = self._io.read_u1()
            self.owl_var_byte2 = self._io.read_u1()
            self.owl_var_byte3 = self._io.read_u1()
            self.owl_var_byte4 = self._io.read_u1()


    class Callsign(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(6)).decode(u"ASCII")


    class Cp16Data(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.various_temp = Cp16.VariousTempVals(self._io, self, self._root)
            self.various_power = Cp16.VariousPowerVals(self._io, self, self._root)
            self.neg_x = Cp16.SidePanelVals(self._io, self, self._root)
            self.pos_x = Cp16.SidePanelVals(self._io, self, self._root)
            self.neg_y = Cp16.SidePanelVals(self._io, self, self._root)
            self.pos_y = Cp16.SidePanelVals(self._io, self, self._root)
            self.neg_z_temp = self._io.read_u1()
            self.flight_software_telem = Cp16.FlightSoftwareTelemVals(self._io, self, self._root)
            self.comms_parameters = Cp16.CommsParametersVals(self._io, self, self._root)
            self.carp = Cp16.CarpVals(self._io, self, self._root)
            self.owl = Cp16.OwlVals(self._io, self, self._root)
            self.imu_data = Cp16.ImuDataVals(self._io, self, self._root)
            self.camera = Cp16.CameraVals(self._io, self, self._root)


    class VariousTempVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.daughter_a_temp = self._io.read_u1()
            self.payload_3v3_temp = self._io.read_u1()
            self.rf_amp_temp = self._io.read_u1()


    class CommsParametersVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.rx_packets_raw = self._io.read_u2be()
            self.tx_packets_raw = self._io.read_u2be()
            self.rx_bytes_raw = self._io.read_u2be()
            self.tx_bytes_raw = self._io.read_u2be()
            self.callsign0 = Cp16.CallsignVal(self._io, self, self._root)
            self.callsign1 = Cp16.CallsignVal(self._io, self, self._root)
            self.callsign2 = Cp16.CallsignVal(self._io, self, self._root)

        @property
        def rx_packets(self):
            """lossy reconstruction due to bug."""
            if hasattr(self, '_m_rx_packets'):
                return self._m_rx_packets

            self._m_rx_packets = (self.rx_packets_raw << 16)
            return getattr(self, '_m_rx_packets', None)

        @property
        def tx_packets(self):
            """lossy reconstruction due to bug."""
            if hasattr(self, '_m_tx_packets'):
                return self._m_tx_packets

            self._m_tx_packets = (self.tx_packets_raw << 16)
            return getattr(self, '_m_tx_packets', None)

        @property
        def rx_bytes(self):
            """lossy reconstruction due to bug."""
            if hasattr(self, '_m_rx_bytes'):
                return self._m_rx_bytes

            self._m_rx_bytes = (self.rx_bytes_raw << 16)
            return getattr(self, '_m_rx_bytes', None)

        @property
        def tx_bytes(self):
            """lossy reconstruction due to bug."""
            if hasattr(self, '_m_tx_bytes'):
                return self._m_tx_bytes

            self._m_tx_bytes = (self.tx_bytes_raw << 16)
            return getattr(self, '_m_tx_bytes', None)


    class VariousPowerVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.atmel_pwr_curr = self._io.read_u1()
            self.atmel_pwr_volt = self._io.read_u1()
            self.bus_3v3_curr = self._io.read_u1()
            self.bus_3v3_volt = self._io.read_u1()
            self.payload_3v3_curr = self._io.read_u1()
            self.payload_3v3_volt = self._io.read_u1()
            self.payload_5v0_curr = self._io.read_u1()
            self.payload_5v0_volt = self._io.read_u1()
            self.rf_amp_curr = self._io.read_u1()
            self.rf_amp_volt = self._io.read_u1()


    class BytesVal(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.raw = self._io.read_u4be()

        @property
        def is_kb(self):
            if hasattr(self, '_m_is_kb'):
                return self._m_is_kb

            self._m_is_kb = (self.raw & 2147483648) != 0
            return getattr(self, '_m_is_kb', None)

        @property
        def value(self):
            if hasattr(self, '_m_value'):
                return self._m_value

            self._m_value = (self.raw & 2147483647)
            return getattr(self, '_m_value', None)


    class FlightSoftwareTelemVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.user_cpu_time = self._io.read_u4be()
            self.nice_cpu_time = self._io.read_u4be()
            self.sys_cpu_time = self._io.read_u4be()
            self.idle_cpu_time = self._io.read_u4be()
            self.processes = self._io.read_u2be()
            self.procs_running = self._io.read_u2be()
            self.procs_blocked = self._io.read_u2be()
            self.mem_free = self._io.read_u4be()
            self.mem_buffered = self._io.read_u4be()
            self.mem_cached = self._io.read_u4be()
            self.vmalloc_total = self._io.read_u4be()
            self.vmalloc_used = self._io.read_u4be()
            self.dir_data_free = Cp16.BytesVal(self._io, self, self._root)
            self.dir_sdcard_free = Cp16.BytesVal(self._io, self, self._root)
            self.lo_bytes = self._io.read_u4be()
            self.lo_packets = self._io.read_u2be()
            self.nand_erasures = self._io.read_u4be()
            self.load_1min = self._io.read_u2be()
            self.load_5min = self._io.read_u2be()
            self.load_15min = self._io.read_u2be()
            self.beacon_count = self._io.read_u2be()
            self.rtc = self._io.read_u4be()
            self.boot_time = self._io.read_u4be()
            self.long_dur_counter = self._io.read_u2be()


    class CameraVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.picture_count = self._io.read_u2be()
            self.thumbnail_count = self._io.read_u1()


    class IFrame(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.pid = self._io.read_u1()
            self.ax25_info = self._io.read_bytes_full()


    class SsidMask(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ssid_mask = self._io.read_u1()

        @property
        def ssid(self):
            if hasattr(self, '_m_ssid'):
                return self._m_ssid

            self._m_ssid = ((self.ssid_mask >> 1) & 15)
            return getattr(self, '_m_ssid', None)


    class Ipv4Packet(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.ipv4_and_udp_header = self._io.read_bytes(29)
            self.contents = Cp16.Cp16Data(self._io, self, self._root)


    class ImuDataVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.accel_x = self._io.read_s1()
            self.accel_y = self._io.read_s1()
            self.accel_z = self._io.read_s1()
            self.gyro_x = self._io.read_s1()
            self.gyro_y = self._io.read_s1()
            self.gyro_z = self._io.read_s1()
            self.mag_x = self._io.read_s1()
            self.mag_y = self._io.read_s1()
            self.mag_z = self._io.read_s1()


    class Repeaters(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.rpt_callsign_raw = Cp16.CallsignRaw(self._io, self, self._root)
            self.rpt_ssid_raw = Cp16.SsidMask(self._io, self, self._root)


    class Repeater(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.rpt_instance = []
            i = 0
            while True:
                _ = Cp16.Repeaters(self._io, self, self._root)
                self.rpt_instance.append(_)
                if (_.rpt_ssid_raw.ssid_mask & 1) == 1:
                    break
                i += 1


    class CallsignVal(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.callsign = (self._io.read_bytes(6)).decode(u"ASCII")
            self.ssid_char_raw = self._io.read_u1()
            self.padding = self._io.read_u1()
            self.last_rx = self._io.read_u4be()

        @property
        def ssid_num(self):
            """workaround bug in our ax25 code."""
            if hasattr(self, '_m_ssid_num'):
                return self._m_ssid_num

            self._m_ssid_num = (0 if self.ssid_char_raw == 0 else ((self.ssid_char_raw - 65) if self.ssid_char_raw >= 65 else (self.ssid_char_raw - 48)))
            return getattr(self, '_m_ssid_num', None)


    class SidePanelVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.solar1_volt = self._io.read_u1()
            self.solar1_curr = self._io.read_s1()
            self.solar2_volt = self._io.read_u1()
            self.solar2_curr = self._io.read_s1()
            self.solar3_volt = self._io.read_u1()
            self.solar3_curr = self._io.read_s1()
            self.side_temp = self._io.read_u1()


    class CallsignRaw(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self._raw__raw_callsign_ror = self._io.read_bytes(6)
            self._raw_callsign_ror = KaitaiStream.process_rotate_left(self._raw__raw_callsign_ror, 8 - (1), 1)
            _io__raw_callsign_ror = KaitaiStream(BytesIO(self._raw_callsign_ror))
            self.callsign_ror = Cp16.Callsign(_io__raw_callsign_ror, self, self._root)


    class CarpVals(KaitaiStruct):
        def __init__(self, _io, _parent=None, _root=None):
            self._io = _io
            self._parent = _parent
            self._root = _root if _root else self
            self._read()

        def _read(self):
            self.carp_b_3v3_volt = self._io.read_u1()
            self.carp_b_3v3_curr = self._io.read_u1()
            self.carp_b_1v8_volt = self._io.read_u1()
            self.carp_b_1v8_curr = self._io.read_u1()
            self.carp_b_event_count = self._io.read_u2be()
            self.carp_b_latch_count = self._io.read_u2be()
            self.pib_temp_intern = self._io.read_u1()
            self.pib_temp_extern = self._io.read_u1()



