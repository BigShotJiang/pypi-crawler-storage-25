"""Headless MCP wrapper for VDL.

This module is intentionally a thin transport adapter. The reusable
tool-shaped functions live in :mod:`vdl.tools`; this module only binds them to
an MCP server on stdio.
"""

from __future__ import annotations

from typing import Any

from vdl.client import VDLClient
from vdl.errors import VDLError
from vdl.tools import (
    doctor,
    download_video,
    get_status,
    plan_download,
    resolve_playlist,
)


def _build_default_client() -> VDLClient:
    """Construct a VDLClient with the same wiring as ``vdl`` CLI commands."""
    import argparse

    from vdl.cli import _create_client

    return _create_client(argparse.Namespace())


def serve() -> None:
    """Run the MCP server on stdio. Raises if ``mcp`` is not installed."""
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as e:
        raise VDLError(
            "MCP support requires the 'mcp' package. Install it with: pip install mcp"
        ) from e

    client = _build_default_client()
    server = FastMCP("vdl")

    @server.tool()
    async def vdl_download_video(
        url: str,
        quality: str | None = None,
        output_dir: str | None = None,
        force: bool = False,
        write_thumbnail: bool | None = None,
        write_subtitles: bool | None = None,
        subtitle_langs: str | None = None,
    ) -> dict[str, Any]:
        """Download a single video URL and return the structured result."""
        return await download_video(
            url,
            quality=quality,
            output_dir=output_dir,
            force=force,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
            client=client,
        )

    @server.tool()
    async def vdl_plan_download(
        url: str,
        quality: str | None = None,
        output_dir: str | None = None,
        write_thumbnail: bool | None = None,
        write_subtitles: bool | None = None,
        subtitle_langs: str | None = None,
    ) -> dict[str, Any]:
        """Plan a download without executing it."""
        return await plan_download(
            url,
            quality=quality,
            output_dir=output_dir,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
            client=client,
        )

    @server.tool()
    async def vdl_resolve_playlist(url: str) -> dict[str, Any]:
        """List all items in a playlist URL."""
        return await resolve_playlist(url, client=client)

    @server.tool()
    async def vdl_get_status(id: str | None = None) -> Any:
        """Return the most recent status records, or one record by id."""
        return await get_status(id=id, client=client)

    @server.tool()
    async def vdl_doctor() -> dict[str, Any]:
        """Run a dependency / config health check."""
        return await doctor(client=client)

    server.run()


def main() -> int:
    try:
        serve()
        return 0
    except KeyboardInterrupt:
        return 0
    except VDLError as e:
        import sys

        print(f"vdl-mcp: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
