"""Command-line interface for VDL.

Provides headless CLI commands for downloads, playlists, configuration, and status checking.
"""

from __future__ import annotations

import argparse
import asyncio
from dataclasses import replace
import json
import sys
from typing import Sequence

from vdl.client import VDLClient
from vdl.config import TomlConfigStore
from vdl.paths import get_default_paths
from vdl.serialization import (
    config_to_dict,
    doctor_report_to_dict,
    download_result_to_dict,
    download_results_to_list,
    playlist_info_to_dict,
    status_record_to_dict,
    status_records_to_list,
)


def build_parser() -> argparse.ArgumentParser:
    """Build command-line argument parser.

    Constructs parser with subcommands for download, playlist, resolve, status,
    doctor, config, and interactive modes.

    Returns:
        ArgumentParser configured with all VDL CLI commands and options.
    """
    from vdl.doctor import _vdl_version

    parser = argparse.ArgumentParser(
        prog="vdl", description="VDL — Lightweight video downloader"
    )
    parser.add_argument(
        "--version", "-V", action="version", version=f"vdl {_vdl_version()}"
    )
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--output", "-o", metavar="DIR", help="Output directory")
    parser.add_argument(
        "--quality",
        "-q",
        default="best",
        choices=[
            "best",
            "2160p",
            "1440p",
            "1080p",
            "720p",
            "480p",
            "medium",
            "low",
            "audio",
        ],
        help="Video quality (default: best)",
    )

    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # download
    dl = sub.add_parser("download", help="Download a video, playlist, or link file")
    dl.add_argument("url", help="URL or local link file path")
    dl.add_argument(
        "--force", action="store_true", help="Re-download even if already completed"
    )
    dl.add_argument("--playlist", action="store_true", help="Treat URL as a playlist")

    # playlist
    pl = sub.add_parser("playlist", help="Download all items in a playlist")
    pl.add_argument("url", help="Playlist URL")
    pl.add_argument("--force", action="store_true")

    # resolve
    rv = sub.add_parser("resolve", help="List playlist items without downloading")
    rv.add_argument("url", help="Playlist URL")

    # status
    st = sub.add_parser("status", help="Show recent download status")
    st.add_argument("id", nargs="?", help="Specific download ID (omit for recent list)")

    # doctor
    sub.add_parser("doctor", help="Check dependencies and environment")

    # config
    cfg = sub.add_parser("config", help="Manage configuration")
    cfg_sub = cfg.add_subparsers(dest="config_command", metavar="ACTION")
    cfg_sub.add_parser("show", help="Show current configuration")
    cfg_get = cfg_sub.add_parser("get", help="Get a single config value")
    cfg_get.add_argument("key")
    cfg_set = cfg_sub.add_parser("set", help="Set a config value")
    cfg_set.add_argument("key")
    cfg_set.add_argument("value")

    # interactive
    sub.add_parser("interactive", help="Launch interactive mode")

    # help
    help_cmd = sub.add_parser("help", help="Show top-level or command-specific help")
    help_cmd.add_argument("topic", nargs="?", help="Command to show help for")

    # mcp
    mcp = sub.add_parser("mcp", help="Manage the VDL MCP server")
    mcp_sub = mcp.add_subparsers(dest="mcp_command", metavar="ACTION")
    mcp_sub.add_parser(
        "setup",
        help="Print MCP client config snippets tailored to this machine",
    )

    return parser


def _create_client(args: argparse.Namespace) -> VDLClient:
    """Create a fully initialized VDLClient from parsed CLI arguments.

    Loads configuration, initializes state store, downloader, resolvers, and doctor service.
    Respects --output override if provided.

    Args:
        args: Parsed command-line arguments from ArgumentParser.

    Returns:
        Configured VDLClient ready for operations.
    """
    from vdl.crawler import SiteRuleDiscoveryResolver
    from vdl.doctor import Doctor
    from vdl.downloader import DownloadOptions, YtDlpDownloader
    from vdl.paths import (
        bundled_site_rules_path,
        find_default_cookie_file,
        resolve_output_dir,
        resolve_site_rules_path,
    )
    from vdl.playlist import YtDlpPlaylistResolver
    from vdl.site_rules import load_site_rules
    from vdl.state import SQLiteStateStore

    paths = get_default_paths()
    config_store = TomlConfigStore()
    config = config_store.load()
    output_res = resolve_output_dir(
        getattr(args, "output", None) or str(config.output_dir)
    )
    config = replace(config, output_dir=output_res.active_path)

    state_store = SQLiteStateStore(db_path=paths.state_db)
    cookie_file = find_default_cookie_file(paths)
    options = DownloadOptions(
        output_dir=config.output_dir,
        cookies=cookie_file,
        write_thumbnail=config.write_thumbnail,
        write_subtitles=config.write_subtitles,
        subtitle_langs=config.subtitle_langs,
    )
    downloader = YtDlpDownloader(options=options)
    resolver = YtDlpPlaylistResolver()
    doctor = Doctor()
    discovery_resolver = None
    rules_path = (
        resolve_site_rules_path(config.site_rules_path, paths)
        or bundled_site_rules_path()
    )
    if rules_path is not None and rules_path.exists():
        rules = load_site_rules(rules_path)
        discovery_resolver = SiteRuleDiscoveryResolver(
            site_rules=rules,
            cookie_file=cookie_file,
        )

    return VDLClient(
        config=config,
        config_store=config_store,
        downloader=downloader,
        playlist_resolver=resolver,
        state_store=state_store,
        doctor_service=doctor,
        discovery_resolver=discovery_resolver,
    )


async def handle_download(
    args: argparse.Namespace, client: VDLClient | None = None
) -> int:
    """Handle download command.

    Downloads a video, playlist, or items from a link file. Supports --playlist flag to treat URL as playlist.
    Outputs results as JSON (--json) or human-readable format.

    Args:
        args: Parsed arguments with url, force, playlist, output, quality, json flags.
        client: Optional VDLClient instance (creates one if not provided).

    Returns:
        Exit code (0 if all completed/skipped, 1 if any failed).
    """
    if client is None:
        client = _create_client(args)

    json_mode = getattr(args, "json", False)
    force = getattr(args, "force", False)

    if getattr(args, "playlist", False):
        results = await client.download_playlist(args.url, force=force)
        if json_mode:
            print(json.dumps(download_results_to_list(results)))
        else:
            for r in results:
                print(f"[{r.status.value}] {r.source_url}")
        return (
            0 if all(r.status.value in ("completed", "skipped") for r in results) else 1
        )

    plan = await client.plan(args.url, force=force)
    results = await client.download_plan(plan)

    if json_mode:
        if plan.total == 1 and len(results) == 1:
            print(json.dumps(download_result_to_dict(results[0])))
        else:
            print(json.dumps(download_results_to_list(results)))
    else:
        for r in results:
            print(f"[{r.status.value}] {r.source_url}")
            if r.output_path:
                print(f"  → {r.output_path}")
            if r.error:
                print(f"  Error: {r.error}", file=sys.stderr)

    return 0 if all(r.status.value in ("completed", "skipped") for r in results) else 1


async def handle_playlist(
    args: argparse.Namespace, client: VDLClient | None = None
) -> int:
    """Handle playlist command.

    Downloads all items from a playlist URL. Outputs results as JSON or human-readable format.

    Args:
        args: Parsed arguments with url, force, output, quality, json flags.
        client: Optional VDLClient instance (creates one if not provided).

    Returns:
        Exit code (0 if all completed/skipped, 1 if any failed).
    """
    if client is None:
        client = _create_client(args)
    results = await client.download_playlist(args.url)
    if getattr(args, "json", False):
        print(json.dumps(download_results_to_list(results)))
    else:
        for r in results:
            print(f"[{r.status.value}] {r.source_url}")
    return 0 if all(r.status.value in ("completed", "skipped") for r in results) else 1


async def handle_resolve(
    args: argparse.Namespace, client: VDLClient | None = None
) -> int:
    """Handle resolve command.

    Lists all items in a playlist without downloading. Shows index, title, and URL for each item.

    Args:
        args: Parsed arguments with url, json flags.
        client: Optional VDLClient instance (creates one if not provided).

    Returns:
        Exit code (always 0).
    """
    if client is None:
        client = _create_client(args)
    playlist = await client.resolve_playlist(args.url)
    if getattr(args, "json", False):
        print(json.dumps(playlist_info_to_dict(playlist)))
    else:
        print(
            f"Playlist: {playlist.title or '(untitled)'} ({len(playlist.items)} items)"
        )
        for item in playlist.items:
            print(f"  [{item.index}] {item.title or item.url}")
    return 0


async def handle_status(
    args: argparse.Namespace, client: VDLClient | None = None
) -> int:
    """Handle status command.

    Shows download status for a specific ID or lists recent downloads.

    Args:
        args: Parsed arguments with optional id, json flags.
        client: Optional VDLClient instance (creates one if not provided).

    Returns:
        Exit code (always 0).
    """
    if client is None:
        client = _create_client(args)
    result = await client.status(getattr(args, "id", None))
    if getattr(args, "json", False):
        if isinstance(result, list):
            print(json.dumps(status_records_to_list(result)))
        elif result:
            print(json.dumps(status_record_to_dict(result)))
        else:
            print(json.dumps(None))
    else:
        if isinstance(result, list):
            if not result:
                print("No downloads recorded.")
            for r in result:
                print(f"[{r.status.value}] {r.source_url}")
        elif result:
            print(f"[{result.status.value}] {result.source_url}")
        else:
            print("Not found.")
    return 0


async def handle_doctor(
    args: argparse.Namespace, client: VDLClient | None = None
) -> int:
    """Handle doctor command.

    Checks dependencies (ffmpeg, yt-dlp) and environment (config, state, output directory).

    Args:
        args: Parsed arguments with json flag.
        client: Optional VDLClient instance (creates one if not provided).

    Returns:
        Exit code (0 if ffmpeg and yt-dlp available, 1 otherwise).
    """
    if client is None:
        client = _create_client(args)
    report = await client.doctor()
    if getattr(args, "json", False):
        print(json.dumps(doctor_report_to_dict(report)))
    else:
        paths = (
            report.details.get("paths", {}) if isinstance(report.details, dict) else {}
        )
        ffmpeg_path = (report.details.get("ffmpeg", {}) or {}).get("path") or ""
        ffprobe_path = (report.details.get("ffprobe", {}) or {}).get("path") or ""
        ytdlp_ver = (report.details.get("ytdlp", {}) or {}).get("version") or ""
        mcp_path = (report.details.get("mcp", {}) or {}).get("path") or ""

        def _row(label: str, ok: bool, hint: str = "") -> None:
            status = "ok " if ok else "FAIL"
            print(f"  {label:<11} {status}   {hint}")

        print(f"VDL doctor (v{report.version})")
        _row("vdl:", True, report.version)
        _row("ffmpeg:", report.ffmpeg_available, ffmpeg_path)
        _row("ffprobe:", report.ffprobe_available, ffprobe_path)
        _row("yt-dlp:", report.ytdlp_available, ytdlp_ver)
        _row(
            "config:",
            report.config_ok and report.config_dir_ok,
            paths.get("config_file", ""),
        )
        _row("state:", report.state_dir_ok, paths.get("state_dir", ""))
        _row("cache:", report.cache_dir_ok, paths.get("cache_dir", ""))
        _row("downloads:", report.output_dir_ok, paths.get("downloads_dir", ""))
        _row("mcp:", report.mcp_available, mcp_path or "vdl-mcp not on PATH")
        print()
        print(
            "MCP client setup: run `vdl mcp setup` for copy-pasteable config snippets."
        )
        if report.repairs:
            print()
            print("Repair:")
            for r in report.repairs:
                print(f"  - {r}")
    required_ok = (
        report.ffmpeg_available and report.ffprobe_available and report.ytdlp_available
    )
    return 0 if required_ok else 1


def handle_config(args: argparse.Namespace, client: VDLClient | None = None) -> int:
    """Handle config command.

    Manages configuration: show current config, get a value, or set a value.
    Supports config show|get <key>|set <key> <value>.

    Args:
        args: Parsed arguments with config_command (show/get/set), key, value.
        client: Unused (for handler interface consistency).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    config_path = get_default_paths().config_file
    cmd = getattr(args, "config_command", None)
    store = TomlConfigStore(config_path)

    if cmd == "show" or cmd is None:
        config = store.load()
        data = config_to_dict(config)
        if getattr(args, "json", False):
            print(json.dumps(data, default=str))
        else:
            for k, v in data.items():
                print(f"{k} = {v}")
        return 0

    if cmd == "get":
        try:
            value = store.get(args.key)
            if getattr(args, "json", False):
                print(json.dumps({args.key: value}, default=str))
            else:
                print(f"{args.key} = {value}")
            return 0
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

    if cmd == "set":
        try:
            value: object = args.value
            if args.value.lower() in ("true", "false"):
                value = args.value.lower() == "true"
            else:
                try:
                    value = int(args.value)
                except ValueError:
                    pass
            store.set(args.key, value)
            print(f"Set {args.key} = {value}")
            return 0
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1

    print(f"Unknown config command: {cmd}", file=sys.stderr)
    return 1


async def handle_mcp(args: argparse.Namespace, client: VDLClient | None = None) -> int:
    """Handle ``vdl mcp <action>`` commands.

    Currently supports ``setup``, which prints copy-pasteable config
    snippets so users can wire ``vdl-mcp`` into Claude Desktop, Codex,
    or any generic stdio MCP client without guessing the binary path.
    """
    from vdl.mcp_setup import render_setup_dict, render_setup_text

    action = getattr(args, "mcp_command", None)
    if action in (None, "setup"):
        if getattr(args, "json", False):
            print(json.dumps(render_setup_dict()))
        else:
            print(render_setup_text())
        return 0
    print(f"Unknown mcp action: {action}", file=sys.stderr)
    return 1


async def handle_interactive(
    args: argparse.Namespace, client: VDLClient | None = None
) -> int:
    """Handle interactive command.

    Launches the Rich-based interactive mode.

    Args:
        args: Parsed arguments (unused).
        client: Optional VDLClient instance (creates one if not provided).

    Returns:
        Exit code from interactive mode.
    """
    if client is None:
        client = _create_client(args)
    from vdl.interactive import run_interactive

    return await run_interactive(client)


async def handle_help(args: argparse.Namespace, client: VDLClient | None = None) -> int:
    """Handle help command.

    Shows top-level CLI help or help for a specific subcommand.

    Args:
        args: Parsed arguments with optional topic.
        client: Unused (for handler interface consistency).

    Returns:
        Exit code (0 for success, 1 if the topic is unknown).
    """
    parser = build_parser()
    topic = getattr(args, "topic", None)
    if not topic:
        parser.print_help()
        return 0

    for action in parser._actions:
        if isinstance(action, argparse._SubParsersAction):
            subparser = action.choices.get(topic)
            if subparser is not None:
                subparser.print_help()
                return 0
            break

    print(f"Unknown help topic: {topic}", file=sys.stderr)
    return 1


async def _main_async(argv: Sequence[str] | None = None) -> int:
    """Async CLI handler.

    Parses arguments, routes to appropriate command handler, and returns exit code.

    Args:
        argv: Command-line arguments (uses sys.argv if None).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    from vdl.bootstrap import ensure_app_ready

    ensure_app_ready()

    raw_argv = list(sys.argv[1:] if argv is None else argv)
    parser = build_parser()
    args = parser.parse_args(raw_argv)

    dispatch = {
        "download": handle_download,
        "playlist": handle_playlist,
        "resolve": handle_resolve,
        "status": handle_status,
        "doctor": handle_doctor,
        "config": handle_config,
        "interactive": handle_interactive,
        "help": handle_help,
        "mcp": handle_mcp,
    }

    handler = dispatch.get(args.command)
    if handler is None:
        if not raw_argv:
            handler = handle_interactive
        else:
            parser.print_help()
            return 1

    try:
        return await handler(args)
    except Exception as e:
        if getattr(args, "json", False):
            print(json.dumps({"error": str(e)}))
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1


def main(argv: Sequence[str] | None = None) -> int:
    """Entry point for VDL CLI.

    Args:
        argv: Command-line arguments (uses sys.argv if None).

    Returns:
        Exit code (0 for success, 1 for error).
    """
    return asyncio.run(_main_async(argv))


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
