"""Transport-agnostic tool facade for VDL.

These helpers expose VDL workflows as plain Python functions with simple
parameters and JSON-serializable outputs. They are suitable for non-MCP tool
calling runtimes, scripts, and service adapters.
"""

from __future__ import annotations

import argparse
import asyncio
from pathlib import Path
from typing import Any

from vdl.client import VDLClient
from vdl.errors import VDLError
from vdl.models import Quality
from vdl.serialization import (
    doctor_report_to_dict,
    download_result_to_dict,
    playlist_info_to_dict,
    status_record_to_dict,
    status_records_to_list,
)


def _quality(value: str | None) -> Quality:
    """Normalize a quality string into a `Quality` enum value."""
    if not value:
        return Quality.BEST
    try:
        return Quality(value)
    except ValueError as e:
        raise VDLError(f"Unknown quality {value!r}") from e


def _build_default_client() -> VDLClient:
    """Construct a VDLClient with the same wiring as ``vdl`` CLI commands."""
    from vdl.cli import _create_client

    return _create_client(argparse.Namespace())


def _resolve_client(client: VDLClient | None) -> VDLClient:
    """Return the provided client or build the default one on demand."""
    return client if client is not None else _build_default_client()


def _ensure_sync_context() -> None:
    """Raise if a sync wrapper is called from an active event loop."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return
    raise VDLError(
        "Sync tool wrappers cannot run inside an active event loop; use the async "
        "functions from vdl.tools instead."
    )


async def download_video(
    url: str,
    quality: str | None = None,
    output_dir: str | None = None,
    force: bool = False,
    write_thumbnail: bool | None = None,
    write_subtitles: bool | None = None,
    subtitle_langs: str | None = None,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Download one video and return a JSON-serializable result."""
    resolved_client = _resolve_client(client)
    result = await resolved_client.download(
        url,
        output_dir=Path(output_dir) if output_dir else None,
        quality=_quality(quality),
        force=force,
        write_thumbnail=write_thumbnail,
        write_subtitles=write_subtitles,
        subtitle_langs=subtitle_langs,
    )
    return download_result_to_dict(result)


def download_video_sync(
    url: str,
    quality: str | None = None,
    output_dir: str | None = None,
    force: bool = False,
    write_thumbnail: bool | None = None,
    write_subtitles: bool | None = None,
    subtitle_langs: str | None = None,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Synchronous wrapper around `download_video`."""
    _ensure_sync_context()
    return asyncio.run(
        download_video(
            url,
            quality=quality,
            output_dir=output_dir,
            force=force,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
            client=client,
        )
    )


async def plan_download(
    url: str,
    quality: str | None = None,
    output_dir: str | None = None,
    write_thumbnail: bool | None = None,
    write_subtitles: bool | None = None,
    subtitle_langs: str | None = None,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Plan a download without executing it and return plain data."""
    resolved_client = _resolve_client(client)
    plan = await resolved_client.plan(
        url,
        output_dir=Path(output_dir) if output_dir else None,
        quality=_quality(quality),
    )
    out = {
        "source_kind": plan.source_kind.value,
        "total": plan.total,
        "items": [
            {
                "url": item.source_url,
                "quality": item.quality.value,
                "is_playlist": item.is_playlist,
                "output_dir": str(item.output_dir) if item.output_dir else None,
            }
            for item in plan.items
        ],
        "metadata": dict(plan.metadata),
    }
    request_options = {
        "write_thumbnail": write_thumbnail,
        "write_subtitles": write_subtitles,
        "subtitle_langs": subtitle_langs,
    }
    if any(value is not None for value in request_options.values()):
        out["request_options"] = request_options
    return out


def plan_download_sync(
    url: str,
    quality: str | None = None,
    output_dir: str | None = None,
    write_thumbnail: bool | None = None,
    write_subtitles: bool | None = None,
    subtitle_langs: str | None = None,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Synchronous wrapper around `plan_download`."""
    _ensure_sync_context()
    return asyncio.run(
        plan_download(
            url,
            quality=quality,
            output_dir=output_dir,
            write_thumbnail=write_thumbnail,
            write_subtitles=write_subtitles,
            subtitle_langs=subtitle_langs,
            client=client,
        )
    )


async def resolve_playlist(
    url: str,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Resolve a playlist URL into a plain dictionary payload."""
    resolved_client = _resolve_client(client)
    info = await resolved_client.resolve_playlist(url)
    return playlist_info_to_dict(info)


def resolve_playlist_sync(
    url: str,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Synchronous wrapper around `resolve_playlist`."""
    _ensure_sync_context()
    return asyncio.run(resolve_playlist(url, client=client))


async def get_status(
    id: str | None = None,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any] | list[dict[str, Any]] | None:
    """Return one status record, many records, or `None` if empty."""
    resolved_client = _resolve_client(client)
    result = await resolved_client.status(id)
    if result is None:
        return None
    if isinstance(result, list):
        return status_records_to_list(result)
    return status_record_to_dict(result)


def get_status_sync(
    id: str | None = None,
    *,
    client: VDLClient | None = None,
) -> dict[str, Any] | list[dict[str, Any]] | None:
    """Synchronous wrapper around `get_status`."""
    _ensure_sync_context()
    return asyncio.run(get_status(id=id, client=client))


async def doctor(
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Run the health check workflow and return a plain dictionary."""
    resolved_client = _resolve_client(client)
    report = await resolved_client.doctor()
    return doctor_report_to_dict(report)


def doctor_sync(
    *,
    client: VDLClient | None = None,
) -> dict[str, Any]:
    """Synchronous wrapper around `doctor`."""
    _ensure_sync_context()
    return asyncio.run(doctor(client=client))


__all__ = [
    "download_video",
    "download_video_sync",
    "plan_download",
    "plan_download_sync",
    "resolve_playlist",
    "resolve_playlist_sync",
    "get_status",
    "get_status_sync",
    "doctor",
    "doctor_sync",
]
