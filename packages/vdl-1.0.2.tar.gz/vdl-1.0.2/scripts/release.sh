#!/usr/bin/env bash

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

AUTO_YES=0
RUN_SMOKE_INSTALL=0

while [ "$#" -gt 0 ]; do
  case "$1" in
    --yes|-y)
      AUTO_YES=1
      ;;
    --smoke-install)
      RUN_SMOKE_INSTALL=1
      ;;
    --help|-h)
      cat <<'EOF'
Usage: ./scripts/release.sh [--yes] [--smoke-install]

End-to-end VDL release flow for the current macOS-first deployment path:
  1. preflight checks
  2. local macOS binary build
  3. tag + push (with same-tag retry cleanup if needed)
  4. upload macOS assets to the GitLab Release
  5. wait for the tag pipeline
  6. trigger and wait for the manual vdl-publish-pages job

Options:
  --yes            Run non-interactively and accept confirmations.
  --smoke-install  Run task release:smoke-install after Pages publish succeeds.
EOF
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      exit 1
      ;;
  esac
  shift
done

log() {
  printf '[release] %s\n' "$*"
}

die() {
  printf '[release] ERROR: %s\n' "$*" >&2
  exit 1
}

confirm() {
  local prompt="$1"
  if [ "$AUTO_YES" -eq 1 ]; then
    return 0
  fi

  printf '%s [y/N] ' "$prompt"
  read -r reply
  case "$reply" in
    y|Y|yes|YES)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || die "missing required command: $1"
}

load_dotenv_if_present() {
  if [ -f .env ]; then
    log "Loading environment from .env"
    set -a
    # shellcheck disable=SC1091
    . ./.env
    set +a
  fi
}

require_glab_api_auth() {
  local encoded="$1"
  glab api "projects/${encoded}" >/dev/null 2>&1 || die "glab cannot access projects/${encoded}. Export GITLAB_TOKEN (for example via .env) or run 'glab auth login' before releasing."
}

current_branch() {
  git rev-parse --abbrev-ref HEAD
}

version() {
  awk -F'"' '/^version/ {print $2; exit}' pyproject.toml
}

project_path() {
  local remote
  remote="$(git remote get-url origin)"
  remote="${remote%.git}"
  remote="${remote#git@gitlab.com:}"
  remote="${remote#https://gitlab.com/}"
  remote="${remote#http://gitlab.com/}"
  printf '%s' "$remote"
}

urlencode_project_path() {
  printf '%s' "$1" | sed 's/\//%2F/g'
}

tag_ref() {
  printf 'refs/tags/%s' "$1"
}

local_tag_exists() {
  git rev-parse -q --verify "$(tag_ref "$1")" >/dev/null 2>&1
}

remote_tag_exists() {
  git ls-remote --tags origin "$(tag_ref "$1")" | grep -q "$(tag_ref "$1")"
}

release_exists() {
  local encoded="$1"
  local tag="$2"
  glab api "projects/${encoded}/releases/${tag}" >/dev/null 2>&1
}

delete_release_if_present() {
  local encoded="$1"
  local tag="$2"
  if release_exists "$encoded" "$tag"; then
    log "Deleting existing GitLab release ${tag}"
    glab api -X DELETE "projects/${encoded}/releases/${tag}" >/dev/null
  fi
}

delete_remote_tag_if_present() {
  local tag="$1"
  if remote_tag_exists "$tag"; then
    log "Deleting remote tag ${tag}"
    git push --delete origin "${tag}"
  fi
}

delete_local_tag_if_present() {
  local tag="$1"
  if local_tag_exists "$tag"; then
    log "Deleting local tag ${tag}"
    git tag -d "${tag}" >/dev/null
  fi
}

prepare_retry_for_tag() {
  local encoded="$1"
  local tag="$2"
  local has_local=0
  local has_remote=0
  local has_release=0

  if local_tag_exists "$tag"; then
    has_local=1
  fi
  if remote_tag_exists "$tag"; then
    has_remote=1
  fi
  if release_exists "$encoded" "$tag"; then
    has_release=1
  fi

  if [ "$has_local" -eq 0 ] && [ "$has_remote" -eq 0 ] && [ "$has_release" -eq 0 ]; then
    return 0
  fi

  log "Existing release state detected for ${tag}: local_tag=${has_local} remote_tag=${has_remote} gitlab_release=${has_release}"
  if ! confirm "Delete any existing ${tag} tag/release state and recreate it at the current commit?"; then
    die "release cancelled because ${tag} already exists"
  fi

  delete_release_if_present "$encoded" "$tag"
  delete_remote_tag_if_present "$tag"
  delete_local_tag_if_present "$tag"
}

pipeline_id_for_ref() {
  local encoded="$1"
  local ref="$2"
  local response

  response="$(glab api "projects/${encoded}/pipelines?ref=${ref}&per_page=20&order_by=id&sort=desc")"
  RESPONSE_JSON="$response" python3 - "$ref" <<'PY'
import json
import os
import sys

ref = sys.argv[1]
items = json.loads(os.environ["RESPONSE_JSON"])
for item in items:
    if item.get("ref") == ref:
        print(item["id"])
        break
PY
}

pipeline_status() {
  local encoded="$1"
  local pipeline_id="$2"
  local response
  response="$(glab api "projects/${encoded}/pipelines/${pipeline_id}")"
  RESPONSE_JSON="$response" python3 - <<'PY'
import json
import os

print(json.loads(os.environ["RESPONSE_JSON"])["status"])
PY
}

job_info() {
  local encoded="$1"
  local pipeline_id="$2"
  local job_name="$3"
  local response

  response="$(glab api "projects/${encoded}/pipelines/${pipeline_id}/jobs?per_page=100&include_retried=true")"
  RESPONSE_JSON="$response" python3 - "$job_name" <<'PY'
import json
import os
import sys

name = sys.argv[1]
jobs = json.loads(os.environ["RESPONSE_JSON"])
matches = [job for job in jobs if job.get("name") == name]
if not matches:
    sys.exit(1)
job = max(matches, key=lambda item: item["id"])
print(job["id"])
print(job["status"])
PY
}

job_status() {
  local encoded="$1"
  local job_id="$2"
  local response
  response="$(glab api "projects/${encoded}/jobs/${job_id}")"
  RESPONSE_JSON="$response" python3 - <<'PY'
import json
import os

print(json.loads(os.environ["RESPONSE_JSON"])["status"])
PY
}

trigger_job() {
  local encoded="$1"
  local job_id="$2"
  glab api -X POST "projects/${encoded}/jobs/${job_id}/play" >/dev/null
}

wait_for_pipeline() {
  local encoded="$1"
  local pipeline_id="$2"
  local status

  while true; do
    status="$(pipeline_status "$encoded" "$pipeline_id")"
    log "Pipeline ${pipeline_id} status: ${status}"
    case "$status" in
      success)
        return 0
        ;;
      failed|canceled|skipped)
        die "pipeline ${pipeline_id} ended with status: ${status}"
        ;;
    esac
    sleep 10
  done
}

wait_for_job() {
  local encoded="$1"
  local job_id="$2"
  local status

  while true; do
    status="$(job_status "$encoded" "$job_id")"
    log "Job ${job_id} status: ${status}"
    case "$status" in
      success)
        return 0
        ;;
      failed|canceled|skipped)
        die "job ${job_id} ended with status: ${status}"
        ;;
    esac
    sleep 10
  done
}

upload_release_assets() {
  local tag="$1"
  local version="$2"
  local asset="$3"
  local sums="$4"
  local attempt
  local max_attempts=4

  glab release create "${tag}" "${asset}" "${sums}" --notes "VDL ${version} macOS arm64" && return 0

  for attempt in 1 2 3 4; do
    log "Release asset upload attempt ${attempt}/${max_attempts}"
    if glab release upload "${tag}" "${asset}" "${sums}"; then
      return 0
    fi
    if [ "$attempt" -lt "$max_attempts" ]; then
      sleep $((attempt * 5))
    fi
  done

  die "failed to upload release assets for ${tag} after ${max_attempts} attempts"
}

require_cmd task
require_cmd git
require_cmd glab
require_cmd python3

load_dotenv_if_present

[ "$(uname -s)" = "Darwin" ] || die "this release flow currently supports macOS only"
[ "$(uname -m)" = "arm64" ] || die "this release flow currently supports macOS arm64 only"

git diff --quiet || die "working tree has unstaged changes"
git diff --cached --quiet || die "index has staged but uncommitted changes"

VERSION="$(version)"
TAG="vdl-v${VERSION}"
MAC_ASSET="out/vdl-${VERSION}-aarch64-apple-darwin.tar.gz"
PROJECT_PATH="$(project_path)"
PROJECT_ENCODED="$(urlencode_project_path "$PROJECT_PATH")"
BRANCH="$(current_branch)"

log "Version: ${VERSION}"
log "Tag: ${TAG}"
log "Branch: ${BRANCH}"
log "Project: ${PROJECT_PATH}"

log "Checking GitLab API access"
require_glab_api_auth "$PROJECT_ENCODED"

log "Running release preflight"
task release:preflight

prepare_retry_for_tag "$PROJECT_ENCODED" "$TAG"

log "Building macOS release artifact"
task build:macos

git tag "${TAG}"
git push origin "${TAG}"

log "Uploading release assets to GitLab Release"
upload_release_assets "${TAG}" "${VERSION}" "${MAC_ASSET}" out/SHA256SUMS

log "Waiting for GitLab to create the tag pipeline"
PIPELINE_ID=""
for _ in 1 2 3 4 5 6 7 8 9 10 11 12; do
  PIPELINE_ID="$(pipeline_id_for_ref "$PROJECT_ENCODED" "$TAG" || true)"
  if [ -n "$PIPELINE_ID" ]; then
    break
  fi
  sleep 5
done
[ -n "$PIPELINE_ID" ] || die "could not find a pipeline for ref ${TAG}"

wait_for_pipeline "$PROJECT_ENCODED" "$PIPELINE_ID"

log "Locating manual Pages job"
JOB_INFO="$(job_info "$PROJECT_ENCODED" "$PIPELINE_ID" "vdl-publish-pages" || true)"
[ -n "$JOB_INFO" ] || die "could not find job vdl-publish-pages in pipeline ${PIPELINE_ID}"
PAGES_JOB_ID="$(printf '%s\n' "$JOB_INFO" | sed -n '1p')"
PAGES_JOB_STATUS="$(printf '%s\n' "$JOB_INFO" | sed -n '2p')"
log "Pages job ${PAGES_JOB_ID} status: ${PAGES_JOB_STATUS}"

case "$PAGES_JOB_STATUS" in
  manual)
    log "Triggering vdl-publish-pages"
    trigger_job "$PROJECT_ENCODED" "$PAGES_JOB_ID"
    ;;
  success)
    log "Pages job already succeeded"
    ;;
  pending|running|created|preparing|waiting_for_resource)
    log "Pages job already in progress"
    ;;
  *)
    die "unexpected Pages job status: ${PAGES_JOB_STATUS}"
    ;;
esac

wait_for_job "$PROJECT_ENCODED" "$PAGES_JOB_ID"

if [ "$RUN_SMOKE_INSTALL" -eq 1 ]; then
  log "Running installer smoke test"
  task release:smoke-install
elif confirm "Run installer smoke test now?"; then
  log "Running installer smoke test"
  task release:smoke-install
fi

log "Release completed successfully"
log "PyPI package: https://pypi.org/project/vdl/"
log "Installer: https://bildcraft.gitlab.io/products/video-downloader/vdl/install.sh"
