from __future__ import annotations

from pathlib import Path

import pytest

from vdl.client import VDLClient
from vdl.config import TomlConfigStore, VDLConfig
from support.fake_downloader import FakeDownloader
from support.fake_playlist_resolver import FakePlaylistResolver
from support.fake_state_store import InMemoryStateStore
from vdl.errors import VDLError
from vdl.models import DownloadResult, DownloadStatus, InputKind, PlaylistItem, Quality
from vdl.playlist import PlaylistInspection

URL = "https://youtube.com/watch?v=abc123"
PLAYLIST_URL = "https://youtube.com/playlist?list=PL123"


class RecordingLogger:
    def __init__(self) -> None:
        self.events: list[tuple[str, str, dict[str, object]]] = []

    def debug(self, event: str, **fields: object) -> None:
        self.events.append(("debug", event, fields))

    def info(self, event: str, **fields: object) -> None:
        self.events.append(("info", event, fields))

    def warning(self, event: str, **fields: object) -> None:
        self.events.append(("warning", event, fields))

    def error(self, event: str, **fields: object) -> None:
        self.events.append(("error", event, fields))


def _config(tmp_path: Path) -> VDLConfig:
    return VDLConfig(output_dir=tmp_path)


def _client(
    tmp_path: Path,
    dl: FakeDownloader | None = None,
    resolver: FakePlaylistResolver | None = None,
    store: InMemoryStateStore | None = None,
) -> VDLClient:
    return VDLClient(
        config=_config(tmp_path),
        downloader=dl or FakeDownloader(),
        playlist_resolver=resolver or FakePlaylistResolver(),
        state_store=store or InMemoryStateStore(),
    )


class TestDownload:
    async def test_returns_completed_result(self, tmp_path):
        client = _client(tmp_path)
        result = await client.download(URL)
        assert result.status == DownloadStatus.COMPLETED

    async def test_no_downloader_raises(self, tmp_path):
        client = VDLClient(config=_config(tmp_path))
        with pytest.raises(VDLError):
            await client.download(URL)

    async def test_records_in_state_store(self, tmp_path):
        store = InMemoryStateStore()
        client = _client(tmp_path, store=store)
        result = await client.download(URL)
        assert store.find_by_url(URL) is not None

    async def test_idempotency_skips_completed(self, tmp_path):
        existing_path = tmp_path / "video.mp4"
        existing_path.write_text("ok", encoding="utf-8")
        dl = FakeDownloader(results={URL: (DownloadStatus.COMPLETED, existing_path)})
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        await client.download(URL)
        first_call_count = len(dl.calls)
        result2 = await client.download(URL)
        assert result2.status == DownloadStatus.SKIPPED
        assert len(dl.calls) == first_call_count

    async def test_force_bypasses_idempotency(self, tmp_path):
        dl = FakeDownloader()
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        await client.download(URL)
        await client.download(URL, force=True)
        assert len(dl.calls) == 2

    async def test_different_quality_is_a_distinct_request(self, tmp_path):
        dl = FakeDownloader()
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        await client.download(URL, quality=Quality.BEST)
        result = await client.download(URL, quality=Quality.P720)
        assert result.status == DownloadStatus.COMPLETED
        assert len(dl.calls) == 2

    async def test_skipped_result_carries_output_path(self, tmp_path):
        fake_path = tmp_path / "video.mp4"
        fake_path.write_text("ok", encoding="utf-8")
        dl = FakeDownloader(results={URL: (DownloadStatus.COMPLETED, fake_path)})
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        r1 = await client.download(URL)
        r2 = await client.download(URL)
        assert r2.status == DownloadStatus.SKIPPED

    async def test_missing_completed_output_is_retried(self, tmp_path):
        missing_path = tmp_path / "missing.mp4"
        dl = FakeDownloader(results={URL: (DownloadStatus.COMPLETED, missing_path)})
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        await client.download(URL)
        result = await client.download(URL)
        assert result.status == DownloadStatus.COMPLETED
        assert len(dl.calls) == 2

    async def test_failed_download_recorded(self, tmp_path):
        dl = FakeDownloader(results={URL: (DownloadStatus.FAILED, None)})
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        result = await client.download(URL)
        assert result.status == DownloadStatus.FAILED
        rec = store.find_by_url(URL)
        assert rec is not None
        assert rec.status == DownloadStatus.FAILED


class TestResolvePlaylist:
    async def test_returns_playlist_info(self, tmp_path):
        client = _client(tmp_path)
        info = await client.resolve_playlist(PLAYLIST_URL)
        assert info.url == PLAYLIST_URL

    async def test_no_resolver_raises(self, tmp_path):
        client = VDLClient(config=_config(tmp_path))
        with pytest.raises(VDLError):
            await client.resolve_playlist(PLAYLIST_URL)


class TestDownloadPlaylist:
    async def test_downloads_all(self, tmp_path):
        client = _client(tmp_path)
        results = await client.download_playlist(PLAYLIST_URL)
        assert len(results) == 2

    async def test_no_resolver_raises(self, tmp_path):
        client = VDLClient(config=_config(tmp_path), downloader=FakeDownloader())
        with pytest.raises(VDLError):
            await client.download_playlist(PLAYLIST_URL)

    async def test_no_downloader_raises(self, tmp_path):
        client = VDLClient(
            config=_config(tmp_path), playlist_resolver=FakePlaylistResolver()
        )
        with pytest.raises(VDLError):
            await client.download_playlist(PLAYLIST_URL)

    async def test_playlist_items_recorded_in_state_store(self, tmp_path):
        store = InMemoryStateStore()
        client = _client(tmp_path, store=store)
        results = await client.download_playlist(PLAYLIST_URL)
        assert len(results) == 2
        for r in results:
            rec = store.find_by_url(r.source_url)
            assert rec is not None, f"URL not tracked in state: {r.source_url}"

    async def test_output_dir_applied_to_playlist_items(self, tmp_path):
        downloader = FakeDownloader()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=downloader,
            playlist_resolver=FakePlaylistResolver(),
            state_store=InMemoryStateStore(),
        )
        target_dir = tmp_path / "playlist-out"
        await client.download_playlist(PLAYLIST_URL, output_dir=target_dir)
        assert downloader.calls
        assert all(call.output_dir == target_dir for call in downloader.calls)


class TestAutoSiteRules:
    def test_auto_loads_discovery_resolver_when_site_rules_path_set(self, tmp_path):
        rules_file = tmp_path / "rules.yaml"
        rules_file.write_text("- domain: example.com\n  video_patterns: [/watch]\n")
        config = VDLConfig(output_dir=tmp_path, site_rules_path=rules_file)
        client = VDLClient(
            config=config, downloader=FakeDownloader(), state_store=InMemoryStateStore()
        )
        assert client.discovery_resolver is not None

    def test_loads_bundled_site_rules_when_explicit_path_not_set(self, tmp_path):
        from vdl.paths import bundled_site_rules_path

        config = VDLConfig(output_dir=tmp_path)
        client = VDLClient(
            config=config, downloader=FakeDownloader(), state_store=InMemoryStateStore()
        )
        if bundled_site_rules_path() is None:
            assert client.discovery_resolver is None
        else:
            assert client.discovery_resolver is not None

    def test_auto_loads_from_default_xdg_path(self, tmp_path, monkeypatch):
        cfg_home = tmp_path / "xdg-config"
        cfg_home.mkdir()
        rules = cfg_home / "vdl" / "websites.yaml"
        rules.parent.mkdir()
        rules.write_text("- domain: example.com\n")
        monkeypatch.setenv("XDG_CONFIG_HOME", str(cfg_home))
        config = VDLConfig(output_dir=tmp_path)
        client = VDLClient(
            config=config, downloader=FakeDownloader(), state_store=InMemoryStateStore()
        )
        assert client.discovery_resolver is not None

    def test_auto_loads_from_bootstrapped_installed_file(self, tmp_path, monkeypatch):
        from vdl.bootstrap import ensure_app_ready
        from vdl.paths import bundled_site_rules_path, get_default_paths

        if bundled_site_rules_path() is None:
            pytest.skip("bundled websites.yaml not present")
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
        monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
        monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "cache"))
        paths = get_default_paths()
        ensure_app_ready(paths)
        config = VDLConfig(output_dir=tmp_path)
        client = VDLClient(
            config=config, downloader=FakeDownloader(), state_store=InMemoryStateStore()
        )
        assert client.discovery_resolver is not None

    def test_explicit_resolver_takes_priority_over_auto_load(self, tmp_path):
        from unittest.mock import AsyncMock

        rules_file = tmp_path / "rules.yaml"
        rules_file.write_text("- domain: example.com\n")
        config = VDLConfig(output_dir=tmp_path, site_rules_path=rules_file)
        explicit_resolver = AsyncMock()
        client = VDLClient(config=config, discovery_resolver=explicit_resolver)
        assert client.discovery_resolver is explicit_resolver


class TestStatus:
    async def test_no_state_store_returns_empty_list(self, tmp_path):
        client = VDLClient(config=_config(tmp_path))
        assert await client.status() == []

    async def test_no_state_store_returns_none_for_id(self, tmp_path):
        client = VDLClient(config=_config(tmp_path))
        assert await client.status("some-id") is None

    async def test_list_recent_after_download(self, tmp_path):
        store = InMemoryStateStore()
        client = _client(tmp_path, store=store)
        await client.download(URL)
        records = await client.status()
        assert isinstance(records, list)
        assert len(records) >= 1

    async def test_get_by_id(self, tmp_path):
        store = InMemoryStateStore()
        client = _client(tmp_path, store=store)
        result = await client.download(URL)
        rec = await client.status(result.id)
        assert rec is not None

    async def test_reconcile_status_reports_missing_file(self, tmp_path):
        fake_path = tmp_path / "missing.mp4"
        dl = FakeDownloader(results={URL: (DownloadStatus.COMPLETED, fake_path)})
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        await client.download(URL)
        report = await client.reconcile_status()
        assert report.entries[0].status == "missing"


class TestDoctor:
    async def test_returns_doctor_report(self, tmp_path):
        client = _client(tmp_path)
        report = await client.doctor()
        assert hasattr(report, "ffmpeg_available")
        assert hasattr(report, "ytdlp_available")


class TestPlan:
    async def test_single_url_plan(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan("https://youtube.com/watch?v=xyz")
        assert plan.total == 1
        assert len(plan.items) == 1
        assert plan.items[0].is_playlist is False

    async def test_link_file_plan(self, tmp_path):
        f = tmp_path / "links.txt"
        f.write_text("https://youtube.com/watch?v=1\nhttps://youtube.com/watch?v=2\n")
        client = _client(tmp_path)
        plan = await client.plan(str(f))
        assert plan.total == 2
        assert len(plan.items) == 2

    async def test_playlist_url_plan(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan("https://youtube.com/playlist?list=PL123")
        assert plan.total == 1
        assert plan.items[0].is_playlist is True

    async def test_comma_separated_urls(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(
            "https://youtube.com/watch?v=abc,https://youtube.com/watch?v=def"
        )
        assert plan.total == 2
        assert len(plan.items) == 2

    async def test_space_separated_urls(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(
            "https://youtube.com/watch?v=abc https://youtube.com/watch?v=def"
        )
        assert plan.total == 2
        assert len(plan.items) == 2

    async def test_unsupported_input_returns_empty_plan(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan("not-a-url")
        assert plan.total == 0
        assert plan.metadata.get("is_supported") is False

    async def test_ambiguous_url_metadata(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan("https://youtube.com/watch?v=abc&list=PL123")
        assert plan.metadata.get("is_ambiguous") is True

    async def test_generic_collection_hint_is_ambiguous(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan("https://example.com/watch/abc?playlist=my-mix")
        assert plan.metadata.get("is_ambiguous") is True

    async def test_plan_treats_unknown_url_as_video_by_default(self, tmp_path):
        """Unknown URLs are now planned as direct videos. Crawling is opt-in
        via :func:`VDLClient.discover` (used as a fallback when the direct
        download fails)."""
        from unittest.mock import AsyncMock

        resolver = AsyncMock()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
            discovery_resolver=resolver,
        )
        plan = await client.plan("https://example.com/videos")
        assert plan.total == 1
        assert plan.metadata.get("discovered") is not True
        resolver.resolve.assert_not_called()

    async def test_discover_uses_discovery_resolver(self, tmp_path):
        from unittest.mock import AsyncMock

        resolver = AsyncMock()
        resolver.resolve.return_value = [
            "https://example.com/vid1",
            "https://example.com/vid2",
        ]
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
            discovery_resolver=resolver,
        )
        plan = await client.discover("https://example.com/videos")
        assert plan.total == 2
        assert plan.metadata.get("discovered") is True
        assert plan.metadata.get("selection_kind") == "candidate_list"
        resolver.resolve.assert_called_once_with("https://example.com/videos")

    async def test_discovery_plan_includes_rich_metadata_for_site_rule_resolver(
        self, tmp_path
    ):
        from vdl.crawler import CrawlResult, SiteRuleDiscoveryResolver
        from vdl.site_rules import SiteRule

        class _FakeCrawler:
            def crawl(self, url, cookie_file=None):
                return CrawlResult(
                    all_links=[
                        {
                            "url": "https://example.com/watch/1",
                            "text": "video here",
                            "index": 0,
                        },
                    ],
                    pagination_links=[],
                    non_pagination_links=[
                        {
                            "url": "https://example.com/watch/1",
                            "text": "video here",
                            "index": 0,
                        },
                    ],
                    method="http",
                )

        resolver = SiteRuleDiscoveryResolver(
            site_rules=[SiteRule(domain="example.com", video_patterns=[r"/watch/\d"])],
            crawler=_FakeCrawler(),
        )
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
            discovery_resolver=resolver,
        )
        plan = await client.discover("https://example.com/videos")
        assert plan.total == 1
        info = plan.metadata.get("discovery")
        assert info is not None
        assert info["matched_rule"] == "example.com"
        assert info["rule_filter_applied"] is True
        assert info["crawler_method"] == "http"

    async def test_inspect_url_detects_playlist_member_via_resolver(self, tmp_path):
        resolver = FakePlaylistResolver(
            inspections={
                URL: PlaylistInspection(
                    kind="playlist_member",
                    playlist_url="https://example.com/playlist/123",
                    entry_url=URL,
                )
            }
        )
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        inspection = await client.inspect_url_for_interactive(URL)
        assert inspection.kind == "playlist_member"
        assert inspection.playlist_url == "https://example.com/playlist/123"


class TestChoiceHelpers:
    async def test_plan_requires_no_choice_for_single_url(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(URL)
        assert client.plan_requires_choice(plan) == "none"

    async def test_plan_requires_choice_for_playlist(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(PLAYLIST_URL)
        assert client.plan_requires_choice(plan) == "playlist_selection"

    async def test_plan_requires_choice_for_ambiguous_input(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan("https://youtube.com/watch?v=abc&list=PL123")
        assert client.plan_requires_choice(plan) == "ambiguous_playlist"

    async def test_plan_requires_choice_for_discovery(self, tmp_path):
        from unittest.mock import AsyncMock

        resolver = AsyncMock()
        resolver.resolve.return_value = ["https://example.com/vid1"]
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
            discovery_resolver=resolver,
        )
        plan = await client.discover("https://example.com/videos")
        assert client.plan_requires_choice(plan) == "discovered_selection"


class TestRemoteInspection:
    async def test_inspect_url_alias_uses_remote_probe(self, tmp_path):
        resolver = FakePlaylistResolver(
            inspections={
                URL: PlaylistInspection(
                    kind="playlist",
                    playlist_url="https://example.com/playlist/123",
                )
            }
        )
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        inspection = await client.inspect_url(URL)
        assert inspection.kind == "playlist"
        assert inspection.playlist_url == "https://example.com/playlist/123"

    async def test_plan_with_probe_promotes_remote_playlist(self, tmp_path):
        url = "https://example.com/series/123"
        resolver = FakePlaylistResolver(
            inspections={
                url: PlaylistInspection(
                    kind="playlist",
                    playlist_url="https://example.com/series/123",
                )
            }
        )
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan_with_probe(url)
        assert plan.source_kind == InputKind.PLAYLIST_URL
        assert plan.total == 1
        assert plan.items[0].is_playlist is True
        assert plan.metadata["resolved_remotely"] is True

    async def test_plan_with_probe_preserves_entry_url_for_playlist_member(
        self, tmp_path
    ):
        url = "https://example.com/watch/abc"
        resolver = FakePlaylistResolver(
            inspections={
                url: PlaylistInspection(
                    kind="playlist_member",
                    playlist_url="https://example.com/series/123",
                    entry_url=url,
                )
            }
        )
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan_with_probe(url)
        assert plan.source_kind == InputKind.VIDEO_URL
        assert plan.items[0].source_url == url
        assert plan.metadata["is_ambiguous"] is True
        assert plan.metadata["playlist_url"] == "https://example.com/series/123"
        assert plan.metadata["resolved_remotely"] is True

    async def test_plan_with_probe_falls_back_for_multi_url_input(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan_with_probe(
            "https://youtube.com/watch?v=abc https://youtube.com/watch?v=def"
        )
        assert plan.total == 2


class TestLogging:
    async def test_plan_creation_emits_log(self, tmp_path):
        logger = RecordingLogger()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
            logger=logger,
        )
        await client.plan(URL)
        assert any(event == "plan.created" for _, event, _ in logger.events)

    async def test_idempotency_skip_emits_log(self, tmp_path):
        logger = RecordingLogger()
        existing_path = tmp_path / "video.mp4"
        existing_path.write_text("ok", encoding="utf-8")
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(
                results={URL: (DownloadStatus.COMPLETED, existing_path)}
            ),
            state_store=InMemoryStateStore(),
            logger=logger,
        )
        await client.download(URL)
        await client.download(URL)
        assert any(event == "download.skipped" for _, event, _ in logger.events)

    async def test_download_completion_emits_log(self, tmp_path):
        logger = RecordingLogger()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
            logger=logger,
        )
        await client.download(URL)
        assert any(event == "download.completed" for _, event, _ in logger.events)

    async def test_execute_plan_emits_log(self, tmp_path):
        logger = RecordingLogger()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
            logger=logger,
        )
        plan = await client.plan(URL)
        await client.execute_plan(plan)
        assert any(event == "plan.executed" for _, event, _ in logger.events)


class TestExpansionPolicy:
    async def test_max_playlist_items_caps_downloads(self, tmp_path):
        from vdl.models import PlaylistItem

        items = [
            PlaylistItem(url=f"https://youtube.com/watch?v={i}", index=i)
            for i in range(10)
        ]
        resolver = FakePlaylistResolver(items=items)
        config = VDLConfig(output_dir=tmp_path, max_playlist_items=3)
        client = VDLClient(
            config=config,
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        results = await client.download_playlist(PLAYLIST_URL)
        assert len(results) == 3


class TestDownloadPlan:
    async def test_single_item_plan(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(URL)
        results = await client.download_plan(plan)
        assert len(results) == 1
        assert results[0].status.value in ("completed", "skipped")

    async def test_multi_item_plan(self, tmp_path):
        f = tmp_path / "links.txt"
        f.write_text("https://youtube.com/watch?v=1\nhttps://youtube.com/watch?v=2\n")
        client = _client(tmp_path)
        plan = await client.plan(str(f))
        results = await client.download_plan(plan)
        assert len(results) == 2

    async def test_resubmitting_link_file_skips_completed_items(self, tmp_path):
        class SequencedDownloader(FakeDownloader):
            def __init__(self) -> None:
                super().__init__()
                self._attempts: dict[str, int] = {}
                self._existing_path = tmp_path / "video-1.mp4"
                self._existing_path.write_text("ok", encoding="utf-8")

            async def download(self, request, *, on_progress=None, cancel_token=None):
                self._attempts[request.source.raw] = (
                    self._attempts.get(request.source.raw, 0) + 1
                )
                if (
                    request.source.raw.endswith("v=2")
                    and self._attempts[request.source.raw] == 1
                ):
                    self.calls.append(request)
                    if on_progress:
                        from vdl.progress import DownloadProgress
                        import uuid

                        on_progress(
                            DownloadProgress(
                                id=str(uuid.uuid4()), status=DownloadStatus.FAILED
                            )
                        )
                    return DownloadResult(
                        id="fail-1",
                        source_url=request.source.raw,
                        status=DownloadStatus.FAILED,
                        quality=request.quality,
                    )
                if request.source.raw.endswith("v=1"):
                    self.calls.append(request)
                    return DownloadResult(
                        id=f"ok-{self._attempts[request.source.raw]}",
                        source_url=request.source.raw,
                        status=DownloadStatus.COMPLETED,
                        quality=request.quality,
                        output_path=self._existing_path,
                    )
                return await super().download(request, on_progress=on_progress)

        f = tmp_path / "links.txt"
        f.write_text("https://youtube.com/watch?v=1\nhttps://youtube.com/watch?v=2\n")
        downloader = SequencedDownloader()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=downloader,
            playlist_resolver=FakePlaylistResolver(),
            state_store=InMemoryStateStore(),
        )
        first_plan = await client.plan(str(f))
        first_results = await client.download_plan(first_plan)
        assert [r.status for r in first_results] == [
            DownloadStatus.COMPLETED,
            DownloadStatus.FAILED,
        ]

        second_plan = await client.plan(str(f))
        second_results = await client.download_plan(second_plan)
        assert [r.status for r in second_results] == [
            DownloadStatus.SKIPPED,
            DownloadStatus.COMPLETED,
        ]
        url1_calls = [
            call for call in downloader.calls if call.source.raw.endswith("v=1")
        ]
        url2_calls = [
            call for call in downloader.calls if call.source.raw.endswith("v=2")
        ]
        assert len(url1_calls) == 1
        assert len(url2_calls) == 2


class TestExecutePlan:
    async def test_ambiguous_plan_defaults_to_single_download(self, tmp_path):
        downloader = FakeDownloader()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=downloader,
            playlist_resolver=FakePlaylistResolver(),
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan("https://youtube.com/watch?v=abc&list=PL123")
        results = await client.execute_plan(plan)
        assert len(results) == 1
        assert len(downloader.calls) == 1

    async def test_ambiguous_plan_can_download_playlist(self, tmp_path):
        downloader = FakeDownloader()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=downloader,
            playlist_resolver=FakePlaylistResolver(),
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan("https://youtube.com/watch?v=abc&list=PL123")
        results = await client.execute_plan(plan, prefer_playlist=True)
        assert len(results) == 2
        assert len(downloader.calls) == 2

    async def test_remote_ambiguous_plan_uses_playlist_url_for_playlist_download(
        self, tmp_path
    ):
        url = "https://example.com/watch/abc"
        downloader = FakeDownloader()
        resolver = FakePlaylistResolver(
            items=[
                PlaylistItem(url="https://example.com/watch/1", index=0),
                PlaylistItem(url="https://example.com/watch/2", index=1),
            ],
            inspections={
                url: PlaylistInspection(
                    kind="playlist_member",
                    playlist_url="https://example.com/series/123",
                    entry_url=url,
                )
            },
        )
        client = VDLClient(
            config=_config(tmp_path),
            downloader=downloader,
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan_with_probe(url)
        results = await client.execute_plan(plan, prefer_playlist=True)
        assert len(results) == 2
        assert "https://example.com/series/123" in resolver.calls

    async def test_playlist_plan_executes_with_selection(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(PLAYLIST_URL)
        results = await client.execute_plan(plan, selection=[0])
        assert len(results) == 1
        assert results[0].source_url == "https://youtube.com/watch?v=fake1"

    async def test_discovered_plan_executes_selected_items(self, tmp_path):
        from unittest.mock import AsyncMock

        resolver = AsyncMock()
        resolver.resolve.return_value = [
            "https://example.com/vid1",
            "https://example.com/vid2",
        ]
        downloader = FakeDownloader()
        client = VDLClient(
            config=_config(tmp_path),
            downloader=downloader,
            state_store=InMemoryStateStore(),
            discovery_resolver=resolver,
        )
        plan = await client.discover("https://example.com/videos")
        results = await client.execute_plan(plan, selection=[1])
        assert len(results) == 1
        assert len(downloader.calls) == 1
        assert downloader.calls[0].source.raw == "https://example.com/vid2"


class TestNestedPlaylistExpansion:
    async def test_no_expansion_by_default(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(
            "https://youtube.com/watch?v=a https://youtube.com/playlist?list=PL1"
        )
        assert plan.total == 2
        # second item is the playlist URL kept as-is
        assert plan.items[1].is_playlist is True
        assert "expansions" not in plan.metadata

    async def test_expansion_when_enabled(self, tmp_path):
        config = VDLConfig(output_dir=tmp_path, expand_nested_playlists=True)
        resolver = FakePlaylistResolver(
            items=[
                PlaylistItem(url="https://youtube.com/watch?v=p1", index=0),
                PlaylistItem(url="https://youtube.com/watch?v=p2", index=1),
            ]
        )
        client = VDLClient(
            config=config,
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan(
            "https://youtube.com/watch?v=a https://youtube.com/playlist?list=PL1"
        )
        # 1 direct + 2 expanded = 3
        assert plan.total == 3
        assert plan.items[0].source_url == "https://youtube.com/watch?v=a"
        assert plan.items[1].source_url == "https://youtube.com/watch?v=p1"
        assert plan.items[2].source_url == "https://youtube.com/watch?v=p2"
        # all items resolved to non-playlist
        assert all(not i.is_playlist for i in plan.items)
        expansions = plan.metadata["expansions"]
        assert len(expansions) == 1
        assert expansions[0]["origin_url"] == "https://youtube.com/playlist?list=PL1"
        assert expansions[0]["expanded_count"] == 2
        assert expansions[0]["start_index"] == 1
        assert expansions[0]["end_index"] == 3

    async def test_expansion_bounded_by_max_playlist_items(self, tmp_path):
        config = VDLConfig(
            output_dir=tmp_path,
            expand_nested_playlists=True,
            max_playlist_items=2,
        )
        resolver = FakePlaylistResolver(
            items=[
                PlaylistItem(url=f"https://youtube.com/watch?v=p{i}", index=i)
                for i in range(5)
            ]
        )
        client = VDLClient(
            config=config,
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan(
            "https://youtube.com/playlist?list=PL1 https://youtube.com/watch?v=z"
        )
        # 2 (capped) + 1 = 3, plus z at end (source order)
        assert plan.total == 3
        assert plan.items[2].source_url == "https://youtube.com/watch?v=z"
        assert plan.metadata["expansions"][0]["truncated"] is True

    async def test_link_file_expansion(self, tmp_path):
        config = VDLConfig(output_dir=tmp_path, expand_nested_playlists=True)
        resolver = FakePlaylistResolver(
            items=[
                PlaylistItem(url="https://youtube.com/watch?v=p1", index=0),
            ]
        )
        f = tmp_path / "links.txt"
        f.write_text(
            "https://youtube.com/watch?v=a\nhttps://youtube.com/playlist?list=PL1\n"
        )
        client = VDLClient(
            config=config,
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan(str(f))
        assert plan.total == 2
        assert plan.metadata.get("expansions") is not None

    async def test_expansion_failure_falls_back_to_playlist_item(self, tmp_path):
        config = VDLConfig(output_dir=tmp_path, expand_nested_playlists=True)
        resolver = FakePlaylistResolver(error=RuntimeError("boom"))
        client = VDLClient(
            config=config,
            downloader=FakeDownloader(),
            playlist_resolver=resolver,
            state_store=InMemoryStateStore(),
        )
        plan = await client.plan(
            "https://youtube.com/watch?v=a https://youtube.com/playlist?list=PL1"
        )
        assert plan.total == 2
        assert plan.items[1].is_playlist is True


class TestBatchSummary:
    async def test_link_file_returns_structured_summary(self, tmp_path):
        f = tmp_path / "links.txt"
        f.write_text("https://youtube.com/watch?v=1\nhttps://youtube.com/watch?v=2\n")
        client = _client(tmp_path)
        plan = await client.plan(str(f))
        summary = await client.execute_batch(plan)
        assert summary.total == 2
        assert len(summary.completed) + len(summary.skipped) + len(summary.failed) == 2

    async def test_summary_partitions_completed_skipped_failed(self, tmp_path):
        from support.fake_downloader import FakeDownloader

        existing = tmp_path / "v1.mp4"
        existing.write_text("ok")
        url1 = "https://youtube.com/watch?v=ok1"
        url2 = "https://youtube.com/watch?v=ok2"
        url3 = "https://youtube.com/watch?v=fail"
        dl = FakeDownloader(
            results={
                url1: (DownloadStatus.COMPLETED, existing),
                url2: (DownloadStatus.COMPLETED, existing),
                url3: (DownloadStatus.FAILED, None),
            }
        )
        store = InMemoryStateStore()
        client = _client(tmp_path, dl=dl, store=store)
        # First pass: url1 completes, url3 fails
        plan1 = await client.plan(f"{url1} {url3}")
        await client.execute_batch(plan1)
        # Second pass: url1 should skip, url2 completes, url3 retries (still fails)
        plan2 = await client.plan(f"{url1} {url2} {url3}")
        summary = await client.execute_batch(plan2)
        assert summary.total == 3
        assert len(summary.skipped) == 1
        assert len(summary.completed) == 1
        assert len(summary.failed) == 1

    async def test_raw_url_list_returns_summary(self, tmp_path):
        client = _client(tmp_path)
        plan = await client.plan(
            "https://youtube.com/watch?v=a https://youtube.com/watch?v=b"
        )
        summary = await client.execute_batch(plan)
        assert summary.total == 2


class TestConfigStore:
    def test_config_store_used_when_no_config(self, tmp_path):
        config_path = tmp_path / "config.toml"
        config_path.write_text(f'output_dir = "{tmp_path}"\n', encoding="utf-8")
        store = TomlConfigStore(path=config_path)
        client = VDLClient(
            config_store=store,
            downloader=FakeDownloader(),
            state_store=InMemoryStateStore(),
        )
        assert client.config.output_dir == tmp_path

    def test_explicit_config_takes_priority_over_store(self, tmp_path):
        explicit = VDLConfig(output_dir=tmp_path / "explicit")
        store = TomlConfigStore()
        client = VDLClient(config=explicit, config_store=store)
        assert client.config.output_dir == tmp_path / "explicit"
