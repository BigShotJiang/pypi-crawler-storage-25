from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from vdl.cli import (
    _create_client,
    build_parser,
    handle_config,
    handle_doctor,
    handle_download,
    handle_interactive,
    handle_playlist,
    handle_resolve,
    handle_status,
    main,
)
from vdl.client import VDLClient
from vdl.config import VDLConfig
from vdl.doctor import Doctor
from support.fake_downloader import FakeDownloader
from support.fake_playlist_resolver import FakePlaylistResolver
from support.fake_state_store import InMemoryStateStore
from vdl.models import (
    DoctorReport,
    DownloadResult,
    DownloadStatus,
    PlaylistInfo,
    PlaylistItem,
    StatusRecord,
)

URL = "https://youtube.com/watch?v=abc"
PLAYLIST_URL = "https://youtube.com/playlist?list=PL123"


def _config(tmp_path: Path) -> VDLConfig:
    return VDLConfig(output_dir=tmp_path)


def _client(tmp_path: Path) -> VDLClient:
    return VDLClient(
        config=_config(tmp_path),
        downloader=FakeDownloader(),
        playlist_resolver=FakePlaylistResolver(),
        state_store=InMemoryStateStore(),
    )


class TestBuildParser:
    def test_download_command(self):
        parser = build_parser()
        args = parser.parse_args(["download", URL])
        assert args.command == "download"
        assert args.url == URL

    def test_playlist_command(self):
        parser = build_parser()
        args = parser.parse_args(["playlist", PLAYLIST_URL])
        assert args.command == "playlist"

    def test_resolve_command(self):
        args = build_parser().parse_args(["resolve", PLAYLIST_URL])
        assert args.command == "resolve"

    def test_status_command_no_id(self):
        args = build_parser().parse_args(["status"])
        assert args.command == "status"
        assert args.id is None

    def test_status_command_with_id(self):
        args = build_parser().parse_args(["status", "some-id"])
        assert args.id == "some-id"

    def test_doctor_command(self):
        args = build_parser().parse_args(["doctor"])
        assert args.command == "doctor"

    def test_interactive_command(self):
        args = build_parser().parse_args(["interactive"])
        assert args.command == "interactive"

    def test_help_command(self):
        args = build_parser().parse_args(["help"])
        assert args.command == "help"

    def test_help_topic_argument(self):
        args = build_parser().parse_args(["help", "download"])
        assert args.command == "help"
        assert args.topic == "download"

    def test_config_show(self):
        args = build_parser().parse_args(["config", "show"])
        assert args.command == "config"
        assert args.config_command == "show"

    def test_config_get(self):
        args = build_parser().parse_args(["config", "get", "default_quality"])
        assert args.key == "default_quality"

    def test_config_set(self):
        args = build_parser().parse_args(["config", "set", "default_quality", "720p"])
        assert args.key == "default_quality"
        assert args.value == "720p"

    def test_json_flag(self):
        args = build_parser().parse_args(["--json", "download", URL])
        assert args.json is True

    def test_quality_flag(self):
        args = build_parser().parse_args(["--quality", "720p", "download", URL])
        assert args.quality == "720p"

    def test_no_command_returns_none(self):
        args = build_parser().parse_args([])
        assert args.command is None


class TestHandleDownload:
    async def test_success_returns_zero(self, tmp_path):
        args = build_parser().parse_args(["download", URL])
        assert await handle_download(args, _client(tmp_path)) == 0

    async def test_failed_returns_nonzero(self, tmp_path):
        dl = FakeDownloader(results={URL: (DownloadStatus.FAILED, None)})
        client = VDLClient(
            config=_config(tmp_path), downloader=dl, state_store=InMemoryStateStore()
        )
        args = build_parser().parse_args(["download", URL])
        assert await handle_download(args, client) != 0

    async def test_json_output(self, tmp_path, capsys):
        args = build_parser().parse_args(["--json", "download", URL])
        await handle_download(args, _client(tmp_path))
        out = capsys.readouterr().out
        data = json.loads(out)
        assert "status" in data
        assert "url" in data


class TestHandlePlaylist:
    async def test_returns_zero_on_success(self, tmp_path):
        args = build_parser().parse_args(["playlist", PLAYLIST_URL])
        assert await handle_playlist(args, _client(tmp_path)) == 0

    async def test_json_output(self, tmp_path, capsys):
        args = build_parser().parse_args(["--json", "playlist", PLAYLIST_URL])
        await handle_playlist(args, _client(tmp_path))
        data = json.loads(capsys.readouterr().out)
        assert isinstance(data, list)


class TestHandleResolve:
    async def test_returns_zero(self, tmp_path):
        args = build_parser().parse_args(["resolve", PLAYLIST_URL])
        assert await handle_resolve(args, _client(tmp_path)) == 0

    async def test_json_output(self, tmp_path, capsys):
        args = build_parser().parse_args(["--json", "resolve", PLAYLIST_URL])
        await handle_resolve(args, _client(tmp_path))
        data = json.loads(capsys.readouterr().out)
        assert "items" in data
        assert "count" in data


class TestHandleStatus:
    async def test_no_records(self, tmp_path, capsys):
        args = build_parser().parse_args(["status"])
        await handle_status(args, _client(tmp_path))
        assert "No downloads" in capsys.readouterr().out

    async def test_unknown_id(self, tmp_path, capsys):
        args = build_parser().parse_args(["status", "nonexistent"])
        await handle_status(args, _client(tmp_path))
        assert "Not found" in capsys.readouterr().out

    async def test_json_empty_list(self, tmp_path, capsys):
        args = build_parser().parse_args(["--json", "status"])
        await handle_status(args, _client(tmp_path))
        data = json.loads(capsys.readouterr().out)
        assert data == []


class TestHandleDoctor:
    async def test_returns_zero_if_tools_available(self, tmp_path, capsys):
        mock_report = DoctorReport(
            version="0.1.0",
            ffmpeg_available=True,
            ffprobe_available=True,
            ytdlp_available=True,
            config_ok=True,
            state_ok=True,
            output_dir_ok=True,
        )
        client = _client(tmp_path)
        with patch.object(client, "doctor", new=AsyncMock(return_value=mock_report)):
            args = build_parser().parse_args(["doctor"])
            rc = await handle_doctor(args, client)
        assert rc == 0

    async def test_returns_nonzero_if_missing(self, tmp_path):
        mock_report = DoctorReport(
            version="0.1.0",
            ffmpeg_available=False,
            ytdlp_available=False,
            config_ok=True,
            state_ok=True,
            output_dir_ok=True,
        )
        client = _client(tmp_path)
        with patch.object(client, "doctor", new=AsyncMock(return_value=mock_report)):
            args = build_parser().parse_args(["doctor"])
            rc = await handle_doctor(args, client)
        assert rc != 0


class TestHandleConfig:
    def test_show_returns_zero(self, tmp_path, capsys):
        args = build_parser().parse_args(["config", "show"])
        rc = handle_config(args)
        assert rc == 0

    def test_get_known_key(self, tmp_path, capsys):
        args = build_parser().parse_args(["config", "get", "default_quality"])
        rc = handle_config(args)
        assert rc == 0

    def test_get_unknown_key_returns_one(self, tmp_path):
        args = build_parser().parse_args(["config", "get", "nonexistent_field"])
        rc = handle_config(args)
        assert rc == 1


class TestCreateClient:
    def test_preserves_extended_config_fields(self, tmp_path):
        rules_file = tmp_path / "rules.yaml"
        rules_file.write_text(
            "- domain: example.com\n  selectors: [.video]\n", encoding="utf-8"
        )
        loaded = VDLConfig(
            output_dir=tmp_path / "downloads",
            site_rules_path=rules_file,
            max_playlist_items=4,
        )
        args = build_parser().parse_args(["download", URL])
        with patch("vdl.cli.TomlConfigStore") as store_cls:
            store = MagicMock()
            store.load.return_value = loaded
            store_cls.return_value = store
            with patch(
                "vdl.cli.get_default_paths",
                return_value=SimpleNamespace(state_db=tmp_path / "state.db"),
            ):
                client = _create_client(args)
        assert client.config.max_playlist_items == 4
        assert client.config.site_rules_path == rules_file
        assert client.discovery_resolver is not None


class TestMain:
    def test_no_command_launches_interactive(self):
        with patch("vdl.cli.handle_interactive", AsyncMock(return_value=0)) as handler:
            assert main([]) == 0
        handler.assert_awaited_once()

    def test_help_returns_zero(self, capsys):
        assert main(["help"]) == 0
        captured = capsys.readouterr()
        assert "VDL" in captured.out

    def test_help_topic_returns_zero(self, capsys):
        assert main(["help", "download"]) == 0
        captured = capsys.readouterr()
        assert "usage: vdl download" in captured.out

    def test_unknown_command_returns_one(self):
        # argparse will raise SystemExit for unrecognized commands,
        # but the dispatch dict returns None for unknown, returning 1
        # We test via dispatch path
        with pytest.raises(SystemExit):
            main(["unknowncmd"])
