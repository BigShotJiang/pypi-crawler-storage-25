import asyncio
import inspect
import logging

from collections import deque
from functools import wraps
from importlib.metadata import version

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.schedulers.base import STATE_STOPPED, STATE_RUNNING, STATE_PAUSED
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse

__version__ = version("kicker")

def _wrap_job(func):
    if inspect.iscoroutinefunction(func):
        return func

    @wraps(func)
    async def wrapper(*args):
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, func, *args)

    return wrapper

class ExecutionLogHandler(logging.Handler):
    def __init__(self, fast_api: FastAPI) -> None:
        super().__init__()
        self.app = fast_api

    def emit(self, record):
        msg = self.format(record)
        self.app.state.execution_log.append(msg)

class Kicker(FastAPI):
    def __init__(self, verbose: bool, **kwargs):
        self._jobs = []

        def setup_logging(verbose: bool, fast_api: FastAPI):
            logger = logging.getLogger("kicker")
            logger.setLevel(logging.DEBUG if verbose else logging.INFO)

            handler = ExecutionLogHandler(fast_api)
            formatter = logging.Formatter("[%(levelname)s] %(message)s")
            handler.setFormatter(formatter)

            logger.addHandler(handler)
            logger.propagate = False

        @asynccontextmanager
        async def lifespan(fast_api: FastAPI):
            fast_api.state.scheduler = AsyncIOScheduler()
            fast_api.state.scheduler.start(paused=True)
            for func, schedule in self._jobs:
                fast_api.state.scheduler.add_job(_wrap_job(func), 'cron', **schedule)

            fast_api.state.execution_log = deque(maxlen=1000)
            setup_logging(verbose, fast_api)
            yield
            fast_api.state.scheduler.shutdown(wait=False)

        super().__init__(
            title="kicker", version=__version__, lifespan=lifespan, **kwargs,
        )

        self._register_routes()

    def job(self, **schedule):
        def decorator(func):
            self._jobs.append((func, schedule))
            return func
        return decorator

    def _register_routes(self):
        @self.get("/", name="index", response_class=HTMLResponse)
        async def index(request: Request):
            scheduler = request.app.state.scheduler
            execution_log = request.app.state.execution_log

            scheduler_is_running = scheduler.state == STATE_RUNNING
            scheduler_is_paused = scheduler.state == STATE_PAUSED

            list_execution_logs_html = []
            for log in reversed(execution_log):
                list_execution_logs_html.append(f"<li>{log}</li>")

            table_rows_html: list[str] = []
            for job in scheduler.get_jobs():
                table_rows_html.append(f"""
        <tr>
            <td>{job.name}</td>
            <td><form action="{request.url_for('run_job', job_id=job.id)}" id="btn_run_{job.id}" method="get" style="display: inline;">
                <input type="submit" value="run" {'disabled' if scheduler_is_paused else ''}>
            </form></td>
            <td><form action="{request.url_for('pause_job', job_id=job.id)}" id="btn_pause_{job.id}" method="get" style="display: inline;">
                <input type="submit" value="pause" {'disabled' if scheduler_is_paused else ''}>
            </form></td>
            <td><form action="{request.url_for('resume_job', job_id=job.id)}" id="btn_resume_{job.id}" method="get" style="display: inline;">
                <input type="submit" value="resume" {'disabled' if scheduler_is_paused else ''}>
            </form></td>
            <td>{job.next_run_time}</td>
        </tr>""")

            content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Scheduler {__version__}</title>
        </head>
        <body>
            <h1>Scheduler Status: {'Running' if scheduler_is_running else 'Paused'}</h1>
        
            <form action="{request.url_for('start_scheduler')}" id="btn_start_sched" method="get" style="display: inline;">
                <input type="submit" value="Start Scheduler" {'disabled' if scheduler_is_running else ''}>
            </form><br><br>
        
            <table>
                {'\n'.join(table_rows_html)}
            </table>
            <br>
        
            <form action="{request.url_for('pause_scheduler')}" id="btn_pause_sched" method="get" style="display: inline;">
                <input type="submit" value="Pause Scheduler" {'disabled' if scheduler_is_paused else ''}>
            </form>
            <h2>Job Executions:</h2>
            <ul>
                {'\n'.join(list_execution_logs_html) if list_execution_logs_html else '<li>No executions yet.</li>'}
            </ul>
        
            <script>
                document.addEventListener('DOMContentLoaded', function() {{
        
                }});
            </script>
        </body>
        </html>"""
            return HTMLResponse(content=content, status_code=status.HTTP_200_OK)

        @self.get("/run/{job_id}", name="run_job")
        async def run_job(request: Request, job_id):
            scheduler = request.app.state.scheduler

            job = scheduler.get_job(job_id)
            if job:
                await job.func()
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/pause/{job_id}', name="pause_job")
        async def pause_job(request: Request, job_id):
            scheduler = request.app.state.scheduler

            scheduler.pause_job(job_id)
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/resume/{job_id}', name="resume_job")
        async def resume_job(request: Request, job_id):
            scheduler = request.app.state.scheduler

            scheduler.resume_job(job_id)
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/start_scheduler', name="start_scheduler")
        async def start_scheduler(request: Request):
            scheduler = request.app.state.scheduler

            if scheduler.state == STATE_STOPPED:
                scheduler.start()
            else:
                scheduler.resume()
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )

        @self.get('/pause_scheduler', name="pause_scheduler")
        async def pause_scheduler(request: Request):
            scheduler = request.app.state.scheduler

            if scheduler.state == STATE_RUNNING:
                scheduler.pause()
            return RedirectResponse(
                url=request.url_for("index"), status_code=status.HTTP_302_FOUND
            )