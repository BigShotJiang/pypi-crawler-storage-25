# upvertex-intel

Namespace reservation for UpVertex Inc. (www.upvertex.com)