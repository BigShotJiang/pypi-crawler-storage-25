"""URL helpers shared across Prodigy Teams packages."""

from __future__ import annotations


def ensure_url(host_or_url: str, default_scheme: str = "https") -> str:
    """Ensure *host_or_url* has a scheme, adding *default_scheme* if missing.

    Many config values and env-vars store a bare hostname
    (``broker.example.com``) but some contexts pass a full URL
    (``http://broker.internal:8080``).  Using ``f"https://{value}"``
    directly doubles the scheme in the latter case.  This helper
    normalises both forms to a usable base URL.

    >>> ensure_url("broker.example.com")
    'https://broker.example.com'
    >>> ensure_url("http://broker.internal:8080")
    'http://broker.internal:8080'
    """
    host_or_url = host_or_url.strip().rstrip("/")
    if "://" in host_or_url:
        return host_or_url
    return f"{default_scheme}://{host_or_url}"
