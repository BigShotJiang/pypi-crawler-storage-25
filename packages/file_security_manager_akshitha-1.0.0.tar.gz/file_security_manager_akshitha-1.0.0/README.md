# file-security-manager-akshitha

A Python security utility library developed for cloud-based file storage applications.
Built as part of the Cloud Platform Programming module at NCI Dublin.

## Installation

```bash
pip install file-security-manager-akshitha
```

## Features

- Generate unique file IDs using UUID
- Hash file names using SHA-256
- Get upload timestamps in ISO 8601 format
- Validate file extensions against an allowed list
- Validate file size (max 10MB)
- Sanitize file names by removing unsafe characters
- Build metadata dictionaries for DynamoDB storage

## Usage

```python
from file_security_manager import FileSecurityManager

# Generate a unique file ID
file_id = FileSecurityManager.generate_file_id()

# Validate file extension
is_valid = FileSecurityManager.is_valid_extension("report.pdf")  # True

# Sanitize a file name
safe_name = FileSecurityManager.sanitize_file_name("my file (1).pdf")  # my_file_1.pdf

# Build metadata for DynamoDB
metadata = FileSecurityManager.build_metadata(
    user_id="user-123",
    file_name="report.pdf",
    file_id=file_id,
    file_size=204800
)
```

## Allowed File Types

`.txt`, `.pdf`, `.png`, `.jpg`, `.jpeg`, `.gif`, `.csv`, `.docx`, `.xlsx`, `.mp4`

## Author

Akshitha Katakomula — NCI Dublin, MSc Cloud Computing 2026
