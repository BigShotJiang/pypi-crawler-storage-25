"""
file_security_manager.py
------------------------
Custom library for the Secure Cloud File Storage application.
Provides security, validation, and metadata utilities for file operations.

Author: Akshitha Katakomula
Module: Cloud Platform Programming - NCI
"""

import uuid
import hashlib
import datetime


class FileSecurityManager:
    """
    A utility library that provides security and validation
    functions for cloud-based file storage operations.
    """

    # Allowed file types for upload
    ALLOWED_EXTENSIONS = [
        ".txt", ".pdf", ".png", ".jpg", ".jpeg",
        ".gif", ".csv", ".docx", ".xlsx", ".mp4"
    ]

    # Max file size: 10MB in bytes
    MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024

    @staticmethod
    def generate_file_id():
        """
        Generates a unique UUID for each uploaded file.
        Used as a unique identifier in DynamoDB records.
        Returns a string UUID e.g. '3f2a1b4c-...'
        """
        return str(uuid.uuid4())

    @staticmethod
    def hash_file_name(file_name):
        """
        Hashes a file name using SHA-256 for secure storage key generation.
        Prevents exposing original file names in S3 paths if needed.
        Returns a hex string of the SHA-256 hash.
        """
        return hashlib.sha256(file_name.encode()).hexdigest()

    @staticmethod
    def get_upload_timestamp():
        """
        Returns the current UTC time in ISO 8601 format.
        Used to record when a file was uploaded in DynamoDB.
        Example: '2026-04-03T10:30:00.123456'
        """
        return datetime.datetime.utcnow().isoformat()

    @staticmethod
    def is_valid_extension(file_name):
        """
        Validates that the uploaded file has an allowed extension.
        Prevents upload of dangerous file types (e.g. .exe, .sh).
        Returns True if the extension is in the allowed list, False otherwise.
        """
        # Extract the extension from the file name in lowercase
        dot_index = file_name.rfind(".")
        if dot_index == -1:
            return False  # No extension found
        extension = file_name[dot_index:].lower()
        return extension in FileSecurityManager.ALLOWED_EXTENSIONS

    @staticmethod
    def is_valid_file_size(file_bytes):
        """
        Checks that the file size does not exceed the 10MB limit.
        Prevents large files from overloading S3 storage.
        Returns True if within limit, False if too large.
        """
        return len(file_bytes) <= FileSecurityManager.MAX_FILE_SIZE_BYTES

    @staticmethod
    def sanitize_file_name(file_name):
        """
        Removes unsafe characters from file names before storing in S3.
        Replaces spaces with underscores and strips special characters.
        Returns a safe, clean file name string.
        """
        # Replace spaces with underscores
        safe_name = file_name.replace(" ", "_")
        # Keep only alphanumeric chars, dots, dashes, underscores
        allowed_chars = (
            "abcdefghijklmnopqrstuvwxyz"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "0123456789.-_"
        )
        safe_name = "".join(c for c in safe_name if c in allowed_chars)
        return safe_name

    @staticmethod
    def build_metadata(user_id, file_name, file_id, file_size):
        """
        Builds a metadata dictionary for storing in DynamoDB.
        Combines all file details into a single structured record.
        Returns a dict with userId, fileId, fileName, uploadedAt, fileSize.
        """
        return {
            "userId": user_id,
            "fileId": file_id,
            "fileName": file_name,
            "uploadedAt": FileSecurityManager.get_upload_timestamp(),
            "fileSize": str(file_size)
        }
