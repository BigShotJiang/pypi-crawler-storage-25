from __future__ import annotations

import asyncio
from dataclasses import dataclass
import json
from typing import Any
import urllib.error
import urllib.request


@dataclass(slots=True)
class OfferSession:
    offers: list[dict[str, Any]]
    index: int = 0


class PRocketIntegrationClient:
    def __init__(self, api_key: str, base_url: str, timeout: int = 12):
        self.api_key = api_key.strip()
        self.base_url = base_url.rstrip("/")
        self.timeout = max(3, int(timeout))

    def _post_sync(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "X-API-Key": self.api_key,
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw_body = response.read().decode("utf-8", errors="replace")
                status_code = getattr(response, "status", 200)
        except urllib.error.HTTPError as exc:
            raw_body = exc.read().decode("utf-8", errors="replace")
            status_code = exc.code
        except urllib.error.URLError as exc:
            raise RuntimeError(f"connection_failed: {exc.reason}") from exc

        try:
            data = json.loads(raw_body) if raw_body else {}
        except json.JSONDecodeError:
            data = {"message": raw_body}

        if status_code >= 400:
            raise RuntimeError(str(data.get("message") or data.get("error") or "request_failed"))
        return data

    async def _post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await asyncio.to_thread(self._post_sync, path, payload)

    async def get_bot_info(self) -> dict[str, Any]:
        return await self._post("/api/v1/bot", {})

    async def get_tasks(
        self,
        *,
        user_id: int,
        username: str | None = None,
        language_code: str | None = "ru",
        is_premium: bool = False,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        data = await self._post(
            "/api/v1/tasks",
            {
                "user": {
                    "id": user_id,
                    "username": username,
                    "language_code": language_code,
                    "is_premium": is_premium,
                },
                "limit": limit,
            },
        )
        return data.get("tasks", [])

    async def check_task(
        self,
        *,
        user_id: int,
        offer_id: int = 0,
        session_token: str = "",
        username: str | None = None,
        language_code: str | None = "ru",
        is_premium: bool = False,
    ) -> dict[str, Any]:
        return await self._post(
            "/api/v1/tasks/check",
            {
                "offer_id": offer_id,
                "session_token": session_token,
                "user": {
                    "id": user_id,
                    "username": username,
                    "language_code": language_code,
                    "is_premium": is_premium,
                },
            },
        )


def format_offer_text(offer: dict[str, Any], currency: str = "RUB") -> str:
    resource_type = str(offer.get("resource_type") or "").strip() or "task"
    type_titles = {
        "channel": "Подписка на канал",
        "group": "Вступление в группу",
        "bot": "Переход в бота",
    }
    reward = float(offer.get("executor_reward") or 0)
    hold_days = int(offer.get("required_days") or 0)
    title = str(offer.get("title") or "").strip() or type_titles.get(resource_type, "Задание")
    description = str(offer.get("description") or "").strip()

    lines = [
        "Задание от спонсора",
        "",
        title,
    ]
    if description:
        lines.extend(["", description])
    lines.extend(
        [
            "",
            f"Тип: {type_titles.get(resource_type, resource_type)}",
            f"Награда: {reward:.2f} {currency}",
        ]
    )
    if hold_days > 0:
        lines.append(f"Удержание: {hold_days} дн.")
    lines.append(f"ID: {offer.get('id')}")
    return "\n".join(lines)


def build_offer_keyboard(
    offer: dict[str, Any],
    *,
    check_callback_data: str,
    next_callback_data: str | None = None,
    open_label: str = "Открыть",
    check_label: str = "Проверить",
    next_label: str = "Следующее",
):
    try:
        from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
    except Exception as exc:
        raise RuntimeError("aiogram is required for build_offer_keyboard") from exc

    rows = [
        [InlineKeyboardButton(text=open_label, url=str(offer.get("open_url") or offer.get("resource_link") or ""))],
        [InlineKeyboardButton(text=check_label, callback_data=check_callback_data)],
    ]
    if next_callback_data:
        rows.append([InlineKeyboardButton(text=next_label, callback_data=next_callback_data)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


class PRocketAiogramIntegration:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        callback_prefix: str = "prkt",
        currency: str = "RUB",
        limit: int = 10,
        empty_text: str = "Сейчас нет доступных заданий от спонсоров.",
        open_label: str = "Открыть",
        check_label: str = "Проверить",
        next_label: str = "Следующее",
        refresh_label: str = "Обновить",
    ):
        self.client = PRocketIntegrationClient(api_key=api_key, base_url=base_url)
        self.callback_prefix = callback_prefix
        self.currency = currency
        self.limit = max(1, min(limit, 25))
        self.empty_text = empty_text
        self.open_label = open_label
        self.check_label = check_label
        self.next_label = next_label
        self.refresh_label = refresh_label
        self._sessions: dict[int, OfferSession] = {}

    def _cb(self, action: str, offer_id: int | None = None) -> str:
        if offer_id is None:
            return f"{self.callback_prefix}:{action}"
        return f"{self.callback_prefix}:{action}:{offer_id}"

    async def _answer_call(self, call: Any, text: str | None = None, *, show_alert: bool = False) -> None:
        try:
            await call.answer(text or "", show_alert=show_alert)
        except Exception:
            return

    async def _load_session(self, user: Any) -> OfferSession:
        offers = await self.client.get_tasks(
            user_id=int(user.id),
            username=getattr(user, "username", None),
            language_code=getattr(user, "language_code", None) or "ru",
            is_premium=bool(getattr(user, "is_premium", False)),
            limit=self.limit,
        )
        session = OfferSession(offers=offers, index=0)
        self._sessions[int(user.id)] = session
        return session

    async def _get_session(self, user: Any, *, force_refresh: bool = False) -> OfferSession:
        user_id = int(user.id)
        session = self._sessions.get(user_id)
        if force_refresh or session is None or not session.offers:
            session = await self._load_session(user)
        return session

    def _current_offer(self, session: OfferSession) -> dict[str, Any] | None:
        if not session.offers:
            return None
        session.index %= len(session.offers)
        return session.offers[session.index]

    def _find_offer(self, session: OfferSession, offer_id: int | None) -> dict[str, Any] | None:
        if offer_id is None:
            return self._current_offer(session)
        for item in session.offers:
            if int(item.get("id") or 0) == int(offer_id):
                return item
        return None

    async def _respond(self, target: Any, text: str, reply_markup: Any) -> None:
        if hasattr(target, "edit_text"):
            try:
                await target.edit_text(text, reply_markup=reply_markup)
                return
            except Exception:
                pass
        await target.answer(text, reply_markup=reply_markup)

    async def _render_offer(self, target: Any, user: Any, *, force_refresh: bool = False) -> None:
        session = await self._get_session(user, force_refresh=force_refresh)
        offer = self._current_offer(session)
        try:
            from aiogram.utils.keyboard import InlineKeyboardBuilder
        except Exception as exc:
            raise RuntimeError("aiogram is required for PRocketAiogramIntegration") from exc

        if offer is None:
            kb = InlineKeyboardBuilder()
            kb.button(text=self.refresh_label, callback_data=self._cb("refresh"))
            await self._respond(target, self.empty_text, kb.as_markup())
            return

        text = format_offer_text(offer, currency=self.currency)
        markup = build_offer_keyboard(
            offer,
            check_callback_data=self._cb("check", int(offer["id"])),
            next_callback_data=self._cb("next", int(offer["id"])),
            open_label=self.open_label,
            check_label=self.check_label,
            next_label=self.next_label,
        )
        await self._respond(target, text, markup)

    async def show_tasks(self, target: Any) -> None:
        user = target.from_user
        if hasattr(target, "answer") and hasattr(target, "message"):
            await self._answer_call(target)
            await self._render_offer(target.message, user, force_refresh=True)
            return
        await self._render_offer(target, user, force_refresh=True)

    async def handle_callback(self, call: Any) -> bool:
        data = str(getattr(call, "data", "") or "")
        prefix = f"{self.callback_prefix}:"
        if not data.startswith(prefix):
            return False

        user = call.from_user
        parts = data.split(":")
        action = parts[1] if len(parts) > 1 else ""
        offer_id = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None

        if action == "refresh":
            await self._answer_call(call)
            await self._render_offer(call.message, user, force_refresh=True)
            return True

        session = await self._get_session(user)
        current = self._current_offer(session)

        if action == "next":
            await self._answer_call(call)
            if session.offers:
                session.index = (session.index + 1) % len(session.offers)
            await self._render_offer(call.message, user)
            return True

        if action == "check":
            if offer_id is None:
                await self._answer_call(call, "Некорректный ID задания.", show_alert=True)
                return True
            offer = self._find_offer(session, offer_id)
            if offer is None:
                await self._answer_call(call, "Задание устарело, обновляю список.", show_alert=True)
                await self._render_offer(call.message, user, force_refresh=True)
                return True

            session_token = str(offer.get("session_token") or "").strip()
            if not session_token:
                await self._answer_call(call, "У задания нет session_token. Обновляю список.", show_alert=True)
                await self._render_offer(call.message, user, force_refresh=True)
                return True

            result = await self.client.check_task(
                user_id=int(user.id),
                offer_id=offer_id,
                session_token=session_token,
                username=getattr(user, "username", None),
                language_code=getattr(user, "language_code", None) or "ru",
                is_premium=bool(getattr(user, "is_premium", False)),
            )
            await self._answer_call(call, str(result.get("message") or "Проверено"), show_alert=True)
            await self._render_offer(call.message, user, force_refresh=True)
            return True

        await self._answer_call(call)
        if current and offer_id and int(current.get("id") or 0) != offer_id:
            await self._render_offer(call.message, user, force_refresh=True)
        return True
