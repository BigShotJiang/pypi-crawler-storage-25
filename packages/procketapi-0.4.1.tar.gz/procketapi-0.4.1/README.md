# PRocket API Library

This package is prepared for simple installation as:

```bash
python -m pip install procketapi
```

The library already handles PRocket task sessions for you: it opens sponsor links through the PRocket redirect URL and sends the matching `session_token` during verification.

## For the service owner

You run the PRocket backend on your own server:

1. `python main.py`
2. `python -m integration_service.api_server`

The connected bot owner does not run your backend.
They only:

1. get an approved API key
2. get your public `base_url`
3. install your library
4. add the integration into their own bot

## Recommended import

```python
from procketapi import PRocketAiogramIntegration
```

Compatibility imports also work:

```python
from procket_integration import PRocketAiogramIntegration
from procket_integration_sdk import PRocketAiogramIntegration
```

## Easy aiogram integration

```python
from aiogram import F, Router
from aiogram.types import CallbackQuery, Message
from procketapi import PRocketAiogramIntegration

router = Router()
integration = PRocketAiogramIntegration(
    api_key="YOUR_API_KEY",
    base_url="https://your-public-api.example.com",
    callback_prefix="sponsor",
    currency="RUB",
)


@router.message(F.text == "📢 Задания от спонсоров")
async def sponsor_tasks(message: Message):
    await integration.show_tasks(message)


@router.callback_query(F.data.startswith("sponsor:"))
async def sponsor_callbacks(call: CallbackQuery):
    await integration.handle_callback(call)
```
