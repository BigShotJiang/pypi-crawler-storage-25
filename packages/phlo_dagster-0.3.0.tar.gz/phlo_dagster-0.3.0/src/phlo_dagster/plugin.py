"""Dagster service plugins for Phlo infrastructure management.

This module provides ServicePlugin implementations that register Dagster
services with Phlo's infrastructure management system. It handles service
definition loading from YAML files and provides metadata for the
Dagster webserver and daemon components.

Service Components:
    - DagsterServicePlugin: Main webserver service
    - DagsterDaemonServicePlugin: Background scheduler/sensor daemon

Service Definitions:
    Services are defined in YAML files (service.yaml, dagster-daemon.yaml)
    that specify Docker Compose configuration, ports, dependencies, and
    startup behavior. These files are loaded from the package resources.

Plugin Registration:
    Plugins are auto-discovered via entry_points (group: phlo.plugins.services)
    and contribute service definitions to the infrastructure orchestrator.

Service Responsibilities:
    - Dagster Webserver: Serves UI, handles GraphQL queries, executes runs
    - Dagster Daemon: Runs schedules, sensors, and daemon loops

Example:
    Service definition structure (service.yaml)::

        service:
          name: dagster
          description: Data orchestration platform
          ports:
            - "3000:3000"
          depends_on:
            - postgres
            - trino

"""

from __future__ import annotations

from phlo.plugins import PackageYamlServicePlugin, PluginMetadata


class DagsterServicePlugin(PackageYamlServicePlugin):
    """Service plugin for Dagster."""

    @property
    def metadata(self) -> PluginMetadata:
        """Return metadata describing the Dagster service plugin.

        Returns:
            PluginMetadata: Plugin identity and display metadata.

        """
        return PluginMetadata(
            name="dagster",
            version="0.1.0",
            description="Data orchestration platform for workflows and pipelines",
            author="Phlo Team",
            tags=["orchestration", "core"],
        )


class DagsterDaemonServicePlugin(PackageYamlServicePlugin):
    """Service plugin for Dagster daemon."""

    _service_definition_file = "dagster-daemon.yaml"

    @property
    def metadata(self) -> PluginMetadata:
        """Return metadata describing the Dagster daemon plugin.

        Returns:
            PluginMetadata: Plugin identity and display metadata.

        """
        return PluginMetadata(
            name="dagster-daemon",
            version="0.1.0",
            description="Dagster daemon for background scheduling and sensors",
            author="Phlo Team",
            tags=["orchestration", "core"],
        )
