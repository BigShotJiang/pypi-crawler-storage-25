"""IPC transport for subprocess-backed gateway sessions.

Uses TCP on localhost for cross-platform compatibility (Linux, macOS,
Windows).  The server binds to an ephemeral port on 127.0.0.1 and
writes the assigned port number to a file so the worker can connect.
"""

from __future__ import annotations

import asyncio
import json
import logging
import socket
import sys
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# Guard against unbounded buffering from malformed or runaway writers.
# 16 MiB accommodates large plan contexts while preventing OOM.
_MAX_LINE_BYTES = 16 * 1024 * 1024


def _encode_event(event: dict[str, Any]) -> bytes:
    return (json.dumps(event, ensure_ascii=False, default=str) + "\n").encode("utf-8")


class IPCServer:
    """Accept one bidirectional IPC connection from a session worker."""

    def __init__(self, socket_path: str) -> None:
        # socket_path is kept as an identifier / port-file location.
        # On all platforms we use TCP localhost with an ephemeral port.
        self.socket_path = Path(socket_path)
        self.socket_path.parent.mkdir(parents=True, exist_ok=True)
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind(("127.0.0.1", 0))
        self._port = self._server.getsockname()[1]
        # Write the assigned port so the worker can discover it.
        self.socket_path.write_text(str(self._port), encoding="utf-8")
        self._server.listen(1)
        self._connection: socket.socket | None = None
        self._recv_buffer = bytearray()
        self._conn_lock = threading.Lock()
        self._read_lock = threading.Lock()
        self._write_lock = threading.Lock()

    @property
    def port(self) -> int:
        return self._port

    async def wait_for_connection(self, timeout_s: float) -> None:
        """Wait asynchronously for a worker connection."""
        await asyncio.to_thread(self._accept_connection, timeout_s)

    def _accept_connection(self, timeout_s: float) -> None:
        self._server.settimeout(timeout_s)
        try:
            connection, _ = self._server.accept()
        finally:
            self._server.settimeout(None)
        with self._conn_lock:
            self._connection = connection

    def _require_connection(self) -> socket.socket:
        with self._conn_lock:
            if self._connection is None:
                raise RuntimeError(f"IPC socket {self.socket_path} is not connected")
            return self._connection

    def _read_line_blocking(self, timeout: float | None) -> bytes | None:
        connection = self._require_connection()
        with self._read_lock:
            prior_timeout = connection.gettimeout()
            connection.settimeout(timeout)
            try:
                while True:
                    newline_index = self._recv_buffer.find(b"\n")
                    if newline_index != -1:
                        line = bytes(self._recv_buffer[:newline_index])
                        del self._recv_buffer[: newline_index + 1]
                        return line
                    if len(self._recv_buffer) > _MAX_LINE_BYTES:
                        logger.error(
                            "IPC read buffer exceeded %d bytes without newline; dropping",
                            _MAX_LINE_BYTES,
                        )
                        self._recv_buffer.clear()
                        return None
                    chunk = connection.recv(65536)
                    if not chunk:
                        self._recv_buffer.clear()
                        return None
                    self._recv_buffer.extend(chunk)
            except (ConnectionResetError, socket.timeout, OSError):
                return None
            finally:
                connection.settimeout(prior_timeout)

    async def read_event(self) -> dict[str, Any] | None:
        """Read one newline-delimited JSON event from the worker."""
        line = await asyncio.to_thread(self._read_line_blocking, None)
        if line is None:
            return None
        if not line:
            return None
        return json.loads(line.decode("utf-8"))

    def write_event(self, event: dict[str, Any]) -> None:
        """Write one newline-delimited JSON event to the worker."""
        connection = self._require_connection()
        payload = _encode_event(event)
        with self._write_lock:
            try:
                connection.sendall(payload)
            except (BrokenPipeError, ConnectionResetError):
                logger.debug(
                    "IPC server write suppressed after disconnect for %s",
                    self.socket_path,
                    exc_info=True,
                )

    def close(self) -> None:
        """Close the accepted connection and remove the port file."""
        with self._conn_lock:
            connection = self._connection
            self._connection = None
        if connection is not None:
            try:
                connection.close()
            except OSError:
                logger.debug("Failed closing IPC connection %s", self.socket_path, exc_info=True)
        try:
            self._server.close()
        except OSError:
            logger.debug("Failed closing IPC server %s", self.socket_path, exc_info=True)
        try:
            self.socket_path.unlink(missing_ok=True)
        except OSError:
            logger.debug("Failed removing IPC port file %s", self.socket_path, exc_info=True)


class IPCWriter:
    """Connect to one bidirectional IPC server owned by the gateway."""

    def __init__(self, socket_path: str) -> None:
        self.socket_path = Path(socket_path)
        # Read the port number written by IPCServer.
        port = int(self.socket_path.read_text(encoding="utf-8").strip())
        self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._socket.connect(("127.0.0.1", port))
        self._recv_buffer = bytearray()
        self._read_lock = threading.Lock()
        self._write_lock = threading.Lock()

    def send_event(self, event: dict[str, Any]) -> None:
        """Send one newline-delimited JSON event to the gateway."""
        payload = _encode_event(event)
        with self._write_lock:
            try:
                self._socket.sendall(payload)
            except (BrokenPipeError, ConnectionResetError):
                logger.debug(
                    "IPC writer suppressed send failure for %s",
                    self.socket_path,
                    exc_info=True,
                )

    def read_event_blocking(self, timeout: float) -> dict[str, Any] | None:
        """Read one newline-delimited JSON event from the gateway."""
        with self._read_lock:
            prior_timeout = self._socket.gettimeout()
            self._socket.settimeout(timeout)
            try:
                while True:
                    newline_index = self._recv_buffer.find(b"\n")
                    if newline_index != -1:
                        line = bytes(self._recv_buffer[:newline_index])
                        del self._recv_buffer[: newline_index + 1]
                        if not line:
                            return None
                        return json.loads(line.decode("utf-8"))
                    if len(self._recv_buffer) > _MAX_LINE_BYTES:
                        logger.error(
                            "IPC read buffer exceeded %d bytes without newline; dropping",
                            _MAX_LINE_BYTES,
                        )
                        self._recv_buffer.clear()
                        return None
                    chunk = self._socket.recv(65536)
                    if not chunk:
                        self._recv_buffer.clear()
                        return None
                    self._recv_buffer.extend(chunk)
            except (BrokenPipeError, ConnectionResetError, socket.timeout, OSError):
                return None
            finally:
                self._socket.settimeout(prior_timeout)

    def close(self) -> None:
        """Close the client socket."""
        try:
            self._socket.close()
        except OSError:
            logger.debug("Failed closing IPC writer %s", self.socket_path, exc_info=True)
