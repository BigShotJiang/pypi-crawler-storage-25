"""Monitor subprocess-backed gateway sessions and mirror events into the event bus."""

from __future__ import annotations

import asyncio
import logging
import subprocess
from typing import Any

from obra.api.protocol import CompletionNotice, EscalationNotice
from obra.config.loaders import get_timeout

logger = logging.getLogger(__name__)


async def _terminate_process(proc: subprocess.Popen[Any], timeout_s: float) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        await asyncio.to_thread(proc.wait, timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()
        await asyncio.to_thread(proc.wait, timeout=timeout_s)


async def monitor_session_process(
    proc: subprocess.Popen[Any],
    ipc_server: Any,
    session_manager: Any,
    session_id: str,
    record: Any,
    cancel_event: Any,
    socket_connect_timeout_s: float,
) -> None:
    """Mirror worker IPC events into the existing SessionManager surfaces."""
    terminal_emitted = False
    process_wait_timeout_s = float(get_timeout("subprocess_runner", "process_wait_s"))
    try:
        await ipc_server.wait_for_connection(timeout_s=socket_connect_timeout_s)
        while True:
            read_task = asyncio.create_task(ipc_server.read_event())
            cancel_task = asyncio.create_task(asyncio.to_thread(cancel_event.wait))
            done, pending = await asyncio.wait(
                {read_task, cancel_task},
                return_when=asyncio.FIRST_COMPLETED,
            )
            for task in pending:
                task.cancel()
            if cancel_task in done and cancel_task.result():
                await _terminate_process(proc, timeout_s=process_wait_timeout_s)
                if not terminal_emitted:
                    session_manager._finalize_session_outcome(
                        record,
                        session_id,
                        "cancelled",
                        event_session_ref=session_id,
                        log_message="Session %s cancelled via process monitor",
                    )
                    terminal_emitted = True
                break

            event = read_task.result()
            if event is None:
                if cancel_event.is_set():
                    await _terminate_process(proc, timeout_s=process_wait_timeout_s)
                    if not terminal_emitted:
                        session_manager._finalize_session_outcome(
                            record,
                            session_id,
                            "cancelled",
                            event_session_ref=session_id,
                            log_message="Session %s cancelled via process monitor",
                        )
                        terminal_emitted = True
                    break
                exit_code = proc.poll()
                if exit_code in (None, 0) and not terminal_emitted:
                    session_manager._finalize_session_outcome(
                        record,
                        session_id,
                        "failed",
                        error_name_override="SessionWorkerProtocolError",
                        extra_events=[
                            (
                                "session_error",
                                {
                                    "session_id": session_id,
                                    "error": "SessionWorkerProtocolError",
                                    "message": "Worker exited without terminal event",
                                },
                            )
                        ],
                        log_message="Session %s worker exited without terminal event",
                    )
                elif exit_code not in (None, 0) and not terminal_emitted:
                    session_manager._finalize_session_outcome(
                        record,
                        session_id,
                        "failed",
                        error_name_override="SessionWorkerProcessError",
                        extra_events=[
                            (
                                "session_error",
                                {
                                    "session_id": session_id,
                                    "error": "SessionWorkerProcessError",
                                    "exit_code": exit_code,
                                },
                            )
                        ],
                        log_message="Session %s worker exited with a non-zero status",
                    )
                break

            event_type = str(event.get("type") or "").strip().lower()
            if event_type == "progress":
                action = str(event.get("action") or "").strip()
                payload = dict(event.get("payload") or {})
                session_manager._update_record_from_progress(session_id, action, payload)
                if action in {"stage_completed", "stage_failed"}:
                    session_manager._enrich_stage_progress_payload(session_id, action, payload)
                record.event_bus.push_event("progress", {"action": action, **payload})
                continue
            if event_type == "stream":
                record.event_bus.push_event(
                    "stream",
                    {
                        "event_type": str(event.get("event_type") or ""),
                        "content": event.get("content"),
                    },
                )
                continue
            if event_type == "escalation":
                notice = EscalationNotice.from_payload(dict(event.get("notice") or {}))
                decision = await asyncio.to_thread(record.event_bus.push_escalation, notice)
                ipc_server.write_event(
                    {
                        "type": "escalation_response",
                        "choice": decision.choice.value,
                    }
                )
                continue
            if event_type == "completed":
                session_manager._sync_hybrid_session_id(
                    session_id,
                    str(event.get("hybrid_session_id"))
                    if isinstance(event.get("hybrid_session_id"), str)
                    and event.get("hybrid_session_id")
                    else None,
                )
                summary = str(event.get("summary") or "")
                session_manager._finalize_session_completion(
                    record,
                    session_id,
                    summary=summary,
                    completion_notice=CompletionNotice(session_summary=summary),
                    event_session_ref=session_id,
                )
                terminal_emitted = True
                break
            if event_type == "failed":
                session_manager._sync_hybrid_session_id(
                    session_id,
                    str(event.get("hybrid_session_id"))
                    if isinstance(event.get("hybrid_session_id"), str)
                    and event.get("hybrid_session_id")
                    else None,
                )
                error_type = str(event.get("error_type") or "SessionWorkerError")
                error_message = str(event.get("error") or "")
                session_manager._finalize_session_outcome(
                    record,
                    session_id,
                    "failed",
                    error_name_override=error_type,
                    extra_events=[
                        (
                            "session_error",
                            {
                                "session_id": session_id,
                                "error": error_type,
                                "message": error_message,
                            },
                        )
                    ],
                    log_message="Session %s failed in worker",
                )
                terminal_emitted = True
                break
            logger.warning(
                "Ignoring unknown session worker event %r for %s", event_type, session_id
            )
    except TimeoutError:
        session_manager._finalize_session_outcome(
            record,
            session_id,
            "failed",
            error_name_override="SessionWorkerConnectionTimeout",
            extra_events=[
                (
                    "session_error",
                    {
                        "session_id": session_id,
                        "error": "SessionWorkerConnectionTimeout",
                    },
                )
            ],
            log_message="Session %s worker failed to connect to the IPC socket",
        )
    except Exception:
        if not terminal_emitted:
            session_manager._finalize_session_outcome(
                record,
                session_id,
                "failed",
                error_name_override="SessionWorkerMonitorError",
                extra_events=[
                    (
                        "session_error",
                        {
                            "session_id": session_id,
                            "error": "SessionWorkerMonitorError",
                        },
                    )
                ],
                log_message="Session %s process monitor failed",
            )
    finally:
        session_manager._cleanup_process_artifacts(record)
        try:
            ipc_server.close()
        except Exception:
            logger.debug("Failed to close IPC server for session %s", session_id, exc_info=True)
