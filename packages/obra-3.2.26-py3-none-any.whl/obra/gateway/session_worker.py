"""Subprocess worker entry point for gateway-owned orchestration sessions."""

from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Any

from obra.api.protocol import EscalationDecision, EscalationNotice, UserDecisionChoice
from obra.config import resolve_llm_config
from obra.core.interrupts import clear_interrupt_request
from obra.gateway.ipc import IPCWriter
from obra.gateway.plan_context import _install_gateway_imported_plan_handler
from obra.hybrid.interaction_mode import InteractionMode, set_current_mode
from obra.hybrid.orchestrator import HybridOrchestrator

logger = logging.getLogger(__name__)


def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--launch-spec", required=True)
    parser.add_argument("--ipc-socket", required=True)
    parser.add_argument("--interaction-mode", default="HEADLESS")
    return parser.parse_args(argv)


def _load_launch_spec(path: str) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _resolve_skip_git_check() -> bool | None:
    llm_config = resolve_llm_config(role="implementation")
    git_config = llm_config.get("git") if isinstance(llm_config, dict) else {}
    if isinstance(git_config, dict) and "skip_check" in git_config:
        return bool(git_config.get("skip_check"))
    return None


def _serialize_escalation_notice(notice: EscalationNotice) -> dict[str, Any]:
    return {
        "escalation_id": notice.escalation_id,
        "reason": notice.reason.value if hasattr(notice.reason, "value") else str(notice.reason),
        "reason_text": notice.reason_text,
        "reason_code": notice.reason_code,
        "invariant_errors": list(notice.invariant_errors),
        "repair_attempt_history": list(notice.repair_attempt_history),
        "blocking_issues": list(notice.blocking_issues),
        "escalation_context": dict(notice.escalation_context),
        "iteration_history": list(notice.iteration_history),
        "options": list(notice.options),
        "convergence_diagnostic": dict(notice.convergence_diagnostic),
        "metadata": dict(notice.metadata),
        **dict(notice.extra),
    }


def _read_escalation_decision(
    writer: IPCWriter,
    timeout_s: float,
) -> EscalationDecision:
    response = writer.read_event_blocking(timeout_s)
    if not isinstance(response, dict) or response.get("type") != "escalation_response":
        return EscalationDecision(
            choice=UserDecisionChoice.FORCE_COMPLETE,
            was_timeout=True,
        )
    raw_choice = response.get("choice")
    try:
        choice = UserDecisionChoice(str(raw_choice))
    except ValueError:
        logger.warning("Invalid escalation response choice: %s", raw_choice)
        return EscalationDecision(
            choice=UserDecisionChoice.FORCE_COMPLETE,
            was_timeout=True,
        )
    return EscalationDecision(choice=choice, was_timeout=False)


def main(argv: list[str] | None = None) -> int:
    args = _parse_args(argv)
    spec = _load_launch_spec(args.launch_spec)
    writer = IPCWriter(args.ipc_socket)
    orchestrator: HybridOrchestrator | None = None
    try:
        clear_interrupt_request()
        set_current_mode(InteractionMode[str(args.interaction_mode).upper()])

        def progress_callback(action: str, payload: dict[str, Any]) -> None:
            writer.send_event(
                {
                    "type": "progress",
                    "action": action,
                    "payload": payload,
                }
            )

        def stream_callback(event_type: str, content: str | None = None) -> None:
            if content is None:
                writer.send_event(
                    {
                        "type": "stream",
                        "event_type": "llm_streaming",
                        "content": event_type,
                    }
                )
                return
            writer.send_event(
                {
                    "type": "stream",
                    "event_type": event_type,
                    "content": content,
                }
            )

        def escalation_callback(notice: EscalationNotice) -> EscalationDecision:
            writer.send_event(
                {
                    "type": "escalation",
                    "notice": _serialize_escalation_notice(notice),
                }
            )
            return _read_escalation_decision(
                writer,
                timeout_s=float(spec.get("escalation_timeout_s", 300.0)),
            )

        # FIX-GW-STREAM-001: Disable on_stream to match the CLI default.
        # Anthropic CLI in "execute" mode is silent on stdout, causing
        # streaming idle timeouts and Windows pipe deadlocks.  Progress
        # is delivered through the IPC progress_callback, not stdout.
        orchestrator = HybridOrchestrator.from_config(
            working_dir=Path(str(spec["working_dir"])),
            on_progress=progress_callback,
            on_stream=None,
            on_escalation=escalation_callback,
            domain=(
                str(spec.get("domain_id"))
                if isinstance(spec.get("domain_id"), str) and spec.get("domain_id")
                else None
            ),
            domain_resolution=(
                dict(spec.get("domain_resolution_state") or {})
                if isinstance(spec.get("domain_resolution_state"), dict)
                and spec.get("domain_resolution_state")
                else None
            ),
            skip_git_check=_resolve_skip_git_check(),
        )
        plan_context = spec.get("plan_context")
        if isinstance(plan_context, dict) and plan_context:
            _install_gateway_imported_plan_handler(orchestrator, dict(plan_context))

        completion = orchestrator.derive(
            objective=str(spec["objective"]),
            project_id=str(spec["project_id"]),
            userplan_id=(
                str(spec.get("userplan_id"))
                if isinstance(spec.get("userplan_id"), str) and spec.get("userplan_id")
                else None
            ),
            workflow_derivation_request=(
                dict(spec.get("workflow_derivation_request") or {})
                if isinstance(spec.get("workflow_derivation_request"), dict)
                and spec.get("workflow_derivation_request")
                else None
            ),
        )
        writer.send_event(
            {
                "type": "completed",
                "summary": completion.session_summary if completion else "",
                "hybrid_session_id": getattr(orchestrator, "session_id", None),
            }
        )
        return 0
    except Exception as exc:
        writer.send_event(
            {
                "type": "failed",
                "error": str(exc),
                "error_type": type(exc).__name__,
                "hybrid_session_id": getattr(orchestrator, "session_id", None),
            }
        )
        return 1
    finally:
        writer.close()


if __name__ == "__main__":
    sys.exit(main())
