---
title: Configuration
description: All SDK configuration options.
---

# Configuration

Everything goes through `st.init()`.

## Minimal

```python
st.init(api_key="ak_...", agent_id="my-agent")
```

## All Options

```python
st.init(
    api_key="ak_...",                     # Required — your Staso API key
    agent_id="my-agent",                  # Required — name for this agent
    base_url="https://api.staso.ai",      # Staso backend URL (default)
    environment="production",              # Tag traces by environment
    workspace_slug="my-workspace",         # Workspace identifier
    batch_size=100,                        # Spans buffered before sending
    flush_interval=5.0,                    # Max seconds between sends
    max_queue_size=10_000,                 # Max buffered spans
    enabled=True,                          # False to disable without removing code
    debug=False,                           # SDK debug logs
    capture_messages=True,                 # Capture LLM message content in integrations
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `api_key` | `str` | *required* | Your Staso API key |
| `agent_id` | `str` | *required* | Agent name, shown on dashboard |
| `base_url` | `str` | `https://api.staso.ai` | Backend URL |
| `environment` | `str` | `"default"` | Environment tag (`"staging"`, `"production"`) |
| `workspace_slug` | `str` | `""` | Workspace identifier |
| `batch_size` | `int` | `100` | Flush after this many spans |
| `flush_interval` | `float` | `5.0` | Flush after this many seconds |
| `max_queue_size` | `int` | `10_000` | Drops new spans when full |
| `enabled` | `bool` | `True` | Kill switch — decorators stay, no data sent |
| `debug` | `bool` | `False` | Debug logging on `staso` logger |
| `capture_messages` | `bool` | `True` | Include LLM message content (e.g. user/assistant messages) in integration spans. Set to `False` to disable. |

## Environment Variables

The SDK automatically reads these environment variables. Arguments passed to `st.init()` take priority.

| Variable | Maps to |
|----------|---------|
| `STASO_API_KEY` | `api_key` |
| `STASO_AGENT_ID` | `agent_id` |
| `STASO_BASE_URL` | `base_url` |
| `STASO_ENVIRONMENT` | `environment` |
| `STASO_WORKSPACE_SLUG` | `workspace_slug` |
| `STASO_DEBUG` | `debug` (`"1"` or `"true"` to enable) |

```python
# Minimal — everything from env vars
st.init()

# Override specific values
st.init(environment="staging")
```

## Disabling

Keep all decorators in your code, send nothing:

```python
st.init(api_key="ak_...", agent_id="my-agent", enabled=False)
```

## Shutdown

Always call before exit:

```python
st.shutdown()
```

There's an `atexit` hook as a fallback, but explicit is better.
