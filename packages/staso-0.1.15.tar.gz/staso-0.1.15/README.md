# Staso Python SDK

You're shipping AI agents to production. You need to know what they're actually doing — which tools they called, what the LLM returned, where they failed, and how much it cost. Staso gives you that.

```bash
pip install staso
```

```python
import staso as st

st.init(api_key="ak_...", agent_id="my-agent")

@st.agent(name="support-agent")
def handle_request(message: str) -> str:
    context = search_kb(message)
    return call_llm(context, message)

@st.tool(name="search_kb")
def search_kb(query: str) -> str:
    return db.search(query)

with st.conversation("conversation-123"):
    handle_request("How do I reset my password?")

st.shutdown()
```

That's it. Open your [Staso dashboard](https://staso.ai) and you'll see the full execution tree — every agent run, tool call, LLM interaction, token count, latency, and error.

### Auto-Instrument LLM Calls

```bash
pip install "staso[anthropic]"  # or "staso[openai]"
```

```python
st.integrations.patch_anthropic()
# Every Anthropic API call is now traced automatically.

st.integrations.patch_openai()
# Every OpenAI API call is now traced automatically.
```

### Claude Code Integration

Trace Claude Code CLI sessions — tool calls, LLM token usage, turn timing — automatically.

```bash
pip install staso  # or: uv pip install staso
staso setup-claude-code \
  --api-key ak_... \
  --workspace my-workspace \
  --environment production \
  --agent-id my-agent
```

Start a Claude Code session and every turn, tool call, and LLM interaction is captured in your Staso dashboard.

### Docs

- [Quickstart](./documentation/getting-started/quickstart.md)
- [Tracing your code](./documentation/guides/tracing.md)
- [Conversations](./documentation/guides/conversations.md)
- [LLM integrations](./documentation/integrations/overview.md)
- [Configuration](./documentation/configuration/options.md)
- [Claude Code](./documentation/integrations/claude-code.md)
- [Troubleshooting](./documentation/troubleshooting.md)

Python 3.11+ &middot; [Apache 2.0](LICENSE)
