from setuptools import setup, find_packages

setup(
    name="svtp",
    version="1.1.0",
    description="Sovereign AG Master CLI & Institutional SDK",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Sovereign AG",
    url="https://github.com/sovereign-ag/sdk",
    packages=find_packages(),
    install_requires=[
        "requests>=2.31.0",
        "cryptography>=41.0.0",
        "pydantic>=2.0.0"
    ],
    entry_points={
        "console_scripts": [
            "svtp=svtp_sdk.cli:main",
        ],
    },
    # REMOVED CLASSIFIERS TO FIX BUILD ERROR
    python_requires='>=3.8',
)
