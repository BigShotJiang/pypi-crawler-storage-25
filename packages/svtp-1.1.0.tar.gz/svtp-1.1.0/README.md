# Sovereign AG: The Invisible Rail

Institutional-grade AI fleet governance and non-custodial identity protocol.

## Quickstart (The 5-Second Onboarding)

To initialize your terminal as a Sovereign Architect, run:

```bash
pip install svtp && svtp
```

## Commands
- `svtp init` - Anchor your hardware identity.
- `svtp login` - Bridge to the global dashboard.
- `svtp mint-passport` - Provision a new autonomous agent.
- `svtp pulse` - Real-time fleet health monitoring.

---
🔱 **Sovereign AG** | Institutional AI Infrastructure.