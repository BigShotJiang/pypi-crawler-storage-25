"""Tests for peek_bio.utils — pure functions with known inputs/outputs."""

import pytest
from peek_bio.utils import (
    fmt_int,
    fmt_float,
    smart_type,
    summarize_column,
    sparkline,
    sparkbar,
    file_size_str,
)


# ── fmt_int ──────────────────────────────────────────────────────────

class TestFmtInt:
    def test_small(self):
        assert fmt_int(42) == "42"

    def test_thousands(self):
        assert fmt_int(1234) == "1,234"

    def test_millions(self):
        assert fmt_int(1234567) == "1,234,567"

    def test_zero(self):
        assert fmt_int(0) == "0"


# ── fmt_float ────────────────────────────────────────────────────────

class TestFmtFloat:
    def test_normal(self):
        assert fmt_float(3.14) == "3.14"

    def test_zero(self):
        assert fmt_float(0) == "0"

    def test_small_scientific(self):
        # Values < 0.001 should use scientific notation
        result = fmt_float(0.0001)
        assert "e" in result

    def test_large_scientific(self):
        # Values >= 1e6 should use scientific notation
        result = fmt_float(2000000.0)
        assert "e" in result

    def test_negative(self):
        result = fmt_float(-0.5)
        assert result == "-0.50"


# ── smart_type ───────────────────────────────────────────────────────

class TestSmartType:
    def test_all_ints(self):
        assert smart_type(["1", "2", "3", "4"]) == "int"

    def test_all_floats(self):
        assert smart_type(["1.1", "2.2", "3.3"]) == "float"

    def test_mixed_int_float(self):
        # Ints + floats → float
        assert smart_type(["1", "2.5", "3"]) == "float"

    def test_has_strings(self):
        assert smart_type(["abc", "def", "ghi"]) == "str"

    def test_na_ignored(self):
        # NA values should be skipped, leaving ints
        assert smart_type(["1", "NA", "3", "nan"]) == "int"

    def test_all_na(self):
        # All NA → str (fallback)
        assert smart_type(["NA", "nan", "."]) == "str"

    def test_one_string_makes_str(self):
        # Even one real string overrides numeric
        assert smart_type(["1", "2", "hello", "4"]) == "str"


# ── summarize_column ─────────────────────────────────────────────────

class TestSummarizeColumn:
    def test_int_range(self):
        result = summarize_column(["10", "20", "30", "40", "50",
                                   "60", "70", "80", "90", "100",
                                   "110"], "int")
        assert "10" in result
        assert "110" in result
        assert "mean" in result

    def test_all_missing(self):
        result = summarize_column(["NA", "", "nan"], "str")
        assert result == "all missing"

    def test_string_unique_count(self):
        result = summarize_column(["a", "b", "c", "d", "e", "f", "g",
                                   "h", "i", "j"], "str")
        assert "10 unique" in result

    def test_long_strings_truncated(self):
        long_val = "A" * 50
        result = summarize_column([long_val], "str")
        # Should be truncated to 30 chars + ellipsis
        assert "…" in result
        assert long_val not in result

    def test_float_range(self):
        result = summarize_column(["0.1", "0.5", "0.9"], "float")
        assert "0.10" in result
        assert "0.90" in result


# ── sparkline ────────────────────────────────────────────────────────

class TestSparkline:
    def test_empty(self):
        assert sparkline([]) == ""

    def test_constant(self):
        # All same value → no histogram
        assert sparkline([5, 5, 5, 5]) == ""

    def test_returns_braille(self):
        result = sparkline([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        assert len(result) > 0
        # Should contain braille characters
        for ch in result:
            assert ch in "⡀⡄⡆⡇"

    def test_two_values(self):
        result = sparkline([0, 100])
        assert len(result) > 0


# ── sparkbar ─────────────────────────────────────────────────────────

class TestSparkbar:
    def test_empty(self):
        assert sparkbar([]) == ""

    def test_all_zero(self):
        assert sparkbar([0, 0, 0]) == ""

    def test_length_matches_input(self):
        result = sparkbar([100, 200, 300])
        assert len(result) == 3

    def test_all_equal(self):
        result = sparkbar([50, 50, 50])
        assert len(result) == 3
        # All equal → all same char
        assert len(set(result)) == 1

    def test_contains_braille(self):
        result = sparkbar([10, 50, 100, 50, 10])
        for ch in result:
            assert ch in "⡀⡄⡆⡇"

    def test_zero_gets_lowest(self):
        result = sparkbar([0, 100, 200])
        # Zero count should get the lowest bar (⡀)
        assert result[0] == "⡀"


# ── summarize_column median ─────────────────────────────────────────

class TestSummarizeColumnMedian:
    """summarize_column now shows median alongside mean for numeric columns."""

    def test_int_median_shown(self):
        """Integer column with >10 unique values shows median."""
        values = [str(x) for x in range(1, 12)]  # 1..11
        result = summarize_column(values, "int")
        assert "median" in result

    def test_int_median_value(self):
        """Median of [1..11] = sorted[5] = 6."""
        values = [str(x) for x in range(1, 12)]
        result = summarize_column(values, "int")
        import re
        m = re.search(r"median:\s*([\d,]+)", result)
        assert m is not None
        assert int(m.group(1).replace(",", "")) == 6

    def test_int_mean_still_shown(self):
        """Mean should still appear alongside median."""
        values = [str(x) for x in range(1, 12)]
        result = summarize_column(values, "int")
        assert "mean" in result

    def test_float_median_shown(self):
        """Float column shows median."""
        values = ["0.5", "1.5", "2.5", "3.5", "4.5"]
        result = summarize_column(values, "float")
        assert "median" in result

    def test_float_median_value(self):
        """Median of [0.5, 1.5, 2.5, 3.5, 4.5] = 2.5."""
        values = ["0.5", "1.5", "2.5", "3.5", "4.5"]
        result = summarize_column(values, "float")
        import re
        m = re.search(r"median:\s*([\d.]+)", result)
        assert m is not None
        assert abs(float(m.group(1)) - 2.5) < 0.01

    def test_float_both_median_and_mean(self):
        """Both median and mean in output."""
        values = ["0.5", "1.5", "2.5", "3.5", "4.5"]
        result = summarize_column(values, "float")
        assert "median:" in result
        assert "mean:" in result

    def test_few_unique_ints_no_median(self):
        """Integer column with <=10 unique values shows unique list, not median."""
        values = ["1", "2", "3"]
        result = summarize_column(values, "int")
        assert "unique" in result
        assert "median" not in result
