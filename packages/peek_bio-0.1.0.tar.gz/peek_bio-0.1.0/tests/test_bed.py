"""Tests for BED handler — ground truth from fixture contents.

test_simple.bed contains 5 features:
  chr1  100  200  peak1  500  +    width=100
  chr1  300  500  peak2  800  -    width=200
  chr2  150  350  peak3  600  +    width=200
  chr2  400  900  peak4  950  -    width=500
  chr3  100  150  peak5  300  +    width=50

Feature count: 5
Widths: [100, 200, 200, 500, 50]
  min=50, max=500, mean=210, median=200
Chromosomes: chr1 (2), chr2 (2), chr3 (1)
Strand: + (3), - (2)
Total coverage: 100+200+200+500+50 = 1,050 bp
"""

import re
from conftest import extract_header, extract_section, fixture_path, run_handler
from peek_bio.formats.bed import peek_bed


class TestSimpleBed:
    """test_simple.bed: 5 features across 3 chromosomes."""

    def setup_method(self):
        self.output = run_handler(peek_bed, fixture_path("test_simple.bed"))

    def test_feature_count(self):
        header = extract_header(self.output)
        assert "5" in header

    def test_width_stats(self):
        width = extract_section(self.output, "Width")
        assert width is not None
        assert "50" in width    # min
        assert "500" in width   # max
        assert "200" in width   # median

    def test_chromosomes(self):
        chroms = extract_section(self.output, "Chroms")
        assert chroms is not None
        assert "3" in chroms

    def test_strand_info(self):
        strands = extract_section(self.output, "Strands")
        assert strands is not None
        # 3 forward, 2 reverse
        assert "3" in strands
        assert "2" in strands
        assert "+" in strands
        assert "-" in strands


class TestBedEmpty:
    """empty.bed: 0 bytes. Should not crash."""

    def setup_method(self):
        self.output = run_handler(peek_bed, fixture_path("empty.bed"))

    def test_no_crash(self):
        assert True
