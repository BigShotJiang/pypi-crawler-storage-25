"""Tests for VCF handler — ground truth from fixture contents.

test_simple.vcf contains 7 variants:
  chr1:100  A→G   SNP, transition (purine→purine: A→G)
  chr1:200  C→T   SNP, transition (pyrimidine→pyrimidine: C→T)
  chr1:300  G→A   SNP, transition (purine→purine: G→A)
  chr1:400  T→C   SNP, transition (pyrimidine→pyrimidine: T→C)
  chr2:100  A→T   SNP, transversion (purine→pyrimidine)
  chr2:200  AA→A  deletion (REF longer than ALT)
  chr2:300  A→AG  insertion (ALT longer than REF)

Variant types: 5 SNPs, 1 deletion, 1 insertion
Ts/Tv: 4 transitions / 1 transversion = 4.00
FILTER: all 7 PASS
Chromosomes: chr1 (4 variants), chr2 (3 variants)
"""

import re
from conftest import extract_header, extract_section, fixture_path, has_qc_warning, run_handler
from peek_bio.formats.vcf import peek_vcf, _collect_stats, _classify_variant


class TestSimpleVcf:
    """test_simple.vcf: 7 variants, Ts/Tv=4.0."""

    def setup_method(self):
        self.output = run_handler(peek_vcf, fixture_path("test_simple.vcf"))

    def test_variant_count(self):
        header = extract_header(self.output)
        assert "7 variants" in header

    def test_variant_types(self):
        var_line = extract_section(self.output, "Variants")
        assert var_line is not None
        assert "5 snps" in var_line
        assert "1 insertion" in var_line
        assert "1 deletion" in var_line

    def test_ts_tv_ratio(self):
        tstv_line = extract_section(self.output, "Ts/Tv")
        assert tstv_line is not None
        tstv_val = float(tstv_line)
        # 4 transitions / 1 transversion = 4.00
        assert abs(tstv_val - 4.0) < 0.01

    def test_all_pass(self):
        filt_line = extract_section(self.output, "FILTER")
        assert filt_line is not None
        assert "7 PASS" in filt_line

    def test_chrom_counts(self):
        chrom_line = extract_section(self.output, "Chroms")
        assert chrom_line is not None
        assert "2 total" in chrom_line


class TestVcfRawCounts:
    """Test _collect_stats directly for raw transition/transversion counts.

    test_simple.vcf: 4 transitions (A>G, C>T, G>A, T>C), 1 transversion (A>T).
    Testing the raw counts prevents a double-counting bug from hiding
    behind a correct-looking ratio.
    """

    def setup_method(self):
        self.stats = _collect_stats(fixture_path("test_simple.vcf"), False)

    def test_transition_count(self):
        assert self.stats["transitions"] == 4

    def test_transversion_count(self):
        assert self.stats["transversions"] == 1

    def test_total_variants(self):
        assert self.stats["n_variants"] == 7

    def test_snp_count(self):
        assert self.stats["variant_types"]["SNP"] == 5

    def test_insertion_count(self):
        assert self.stats["variant_types"]["Insertion"] == 1

    def test_deletion_count(self):
        assert self.stats["variant_types"]["Deletion"] == 1


class TestVcfAllTsTv:
    """test_all_tstv.vcf: All 12 possible single-base substitutions.

    Transitions (purine↔purine or pyrimidine↔pyrimidine):
      A>G, G>A, C>T, T>C → 4 transitions

    Transversions (purine↔pyrimidine):
      A>C, A>T, C>A, C>G, G>C, G>T, T>A, T>G → 8 transversions

    Ts/Tv = 4/8 = 0.50
    """

    def setup_method(self):
        self.stats = _collect_stats(fixture_path("test_all_tstv.vcf"), False)

    def test_transitions(self):
        assert self.stats["transitions"] == 4

    def test_transversions(self):
        assert self.stats["transversions"] == 8

    def test_ratio(self):
        ratio = self.stats["transitions"] / self.stats["transversions"]
        assert abs(ratio - 0.5) < 0.01


class TestVcfClassifyVariant:
    """Unit tests for _classify_variant — no file I/O needed."""

    def test_snp(self):
        assert _classify_variant("A", "G") == "SNP"

    def test_insertion(self):
        assert _classify_variant("A", "AG") == "Insertion"

    def test_deletion(self):
        assert _classify_variant("AG", "A") == "Deletion"

    def test_complex(self):
        assert _classify_variant("AC", "GT") == "Complex"

    def test_multi_allelic(self):
        assert _classify_variant("A", "G,T") == "Multi-allelic"


class TestVcfEmpty:
    """empty.vcf: header only, no data rows."""

    def setup_method(self):
        self.output = run_handler(peek_vcf, fixture_path("empty.vcf"))

    def test_no_crash(self):
        # Should produce output or handle gracefully
        assert True

    def test_zero_variants(self):
        # Should report 0 variants
        header = extract_header(self.output)
        assert header is not None
        assert "0" in header


class TestMultisampleVcfStats:
    """test_multisample.vcf: 3 samples, 6 variants.

    Genotypes (GT field):
      chr1:100  SAMPLE1=0/1  SAMPLE2=1/1  SAMPLE3=0/0
      chr1:200  SAMPLE1=0/0  SAMPLE2=0/1  SAMPLE3=./.
      chr1:300  SAMPLE1=0/1  SAMPLE2=0/1  SAMPLE3=0/1
      chr1:400  SAMPLE1=1/1  SAMPLE2=./.  SAMPLE3=0/1
      chr2:100  SAMPLE1=0/0  SAMPLE2=0/1  SAMPLE3=0/0
      chr2:200  SAMPLE1=0/1  SAMPLE2=0/0  SAMPLE3=./.

    Per-sample stats:
      SAMPLE1: 6 called, 0 missing → 100% genotyped
               3 het (0/1), 1 hom-alt (1/1), 2 hom-ref (0/0)
               het/hom = 3/1 = 3.0
      SAMPLE2: 5 called, 1 missing → 83.3% genotyped
               3 het, 1 hom-alt, 1 hom-ref
               het/hom = 3/1 = 3.0
      SAMPLE3: 4 called, 2 missing → 66.7% genotyped
               2 het, 0 hom-alt, 2 hom-ref
               het/hom = n/a (no hom-alt)

    Mean genotype rate: (100 + 83.3 + 66.7) / 3 = 83.3%
    Should trigger low genotype rate warning (<90%).
    """

    def setup_method(self):
        self.stats = _collect_stats(fixture_path("test_multisample.vcf"), False)

    def test_sample_count(self):
        assert len(self.stats["samples"]) == 3

    def test_sample_names(self):
        assert self.stats["samples"] == ["SAMPLE1", "SAMPLE2", "SAMPLE3"]

    def test_sample1_called(self):
        s1 = self.stats["sample_gt_stats"]["SAMPLE1"]
        assert s1["called"] == 6
        assert s1["missing"] == 0

    def test_sample1_het(self):
        s1 = self.stats["sample_gt_stats"]["SAMPLE1"]
        assert s1["het"] == 3

    def test_sample1_hom_alt(self):
        s1 = self.stats["sample_gt_stats"]["SAMPLE1"]
        assert s1["hom_alt"] == 1

    def test_sample2_missing(self):
        s2 = self.stats["sample_gt_stats"]["SAMPLE2"]
        assert s2["missing"] == 1
        assert s2["called"] == 5

    def test_sample3_missing(self):
        s3 = self.stats["sample_gt_stats"]["SAMPLE3"]
        assert s3["missing"] == 2
        assert s3["called"] == 4

    def test_sample3_no_hom_alt(self):
        s3 = self.stats["sample_gt_stats"]["SAMPLE3"]
        assert s3["hom_alt"] == 0


class TestMultisampleVcfDisplay:
    """test_multisample.vcf display: 3 samples shown individually."""

    def setup_method(self):
        self.output = run_handler(peek_vcf, fixture_path("test_multisample.vcf"))

    def test_header_mentions_samples(self):
        assert "3 samples" in self.output

    def test_sample1_displayed(self):
        s1 = extract_section(self.output, "SAMPLE1")
        assert s1 is not None
        assert "100.0% genotyped" in s1

    def test_sample2_displayed(self):
        s2 = extract_section(self.output, "SAMPLE2")
        assert s2 is not None
        assert "83.3% genotyped" in s2

    def test_sample3_displayed(self):
        s3 = extract_section(self.output, "SAMPLE3")
        assert s3 is not None
        assert "66.7% genotyped" in s3

    def test_low_genotype_rate_warning(self):
        assert has_qc_warning(self.output, "Low genotype rate")


class TestSimpleVcfNoSamples:
    """test_simple.vcf has no sample columns, so no per-sample stats."""

    def setup_method(self):
        self.stats = _collect_stats(fixture_path("test_simple.vcf"), False)

    def test_no_samples(self):
        assert self.stats["samples"] == []

    def test_no_sample_gt_stats(self):
        assert self.stats["sample_gt_stats"] is None
