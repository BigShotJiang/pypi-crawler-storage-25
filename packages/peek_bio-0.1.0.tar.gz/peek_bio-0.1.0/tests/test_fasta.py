"""Tests for FASTA handler — ground truth calculated by hand.

test_3seq.fa contains:
  >seq1: ACGTACGTAC         → 10 bp, GC=5 (C,G,C,G,C), N=0
  >seq2: GGCCGGCCGGCCGGCCGGCC → 20 bp, GC=20, N=0
  >seq3: AANNTTNNCC         → 10 bp, GC=2 (CC), N=4

Totals:
  3 sequences
  40 bp total
  GC = 5+20+2 = 27  → 27/40 = 67.5%
  N  = 4            → 4/40  = 10.0%
  Lengths: [10, 20, 10]
  N50: sorted desc = [20, 10, 10], cumsum: 20 >= 40/2=20 → N50 = 20
  Min length: 10, Max: 20, Median: 10

test_high_n.fa contains:
  >scaffold_1: NNNNNNNNNNNNNNNNNNNN + NNNNNNNNNNACGTACGTAC
  = 40 bp total, N=30, GC=5
  N% = 30/40 = 75.0%  → should trigger "High N content" QC warning
"""

import re
from conftest import extract_header, extract_section, fixture_path, has_qc_warning, run_handler
from peek_bio.formats.fasta import peek_fasta


class TestFasta3Seq:
    """Tests against test_3seq.fa with hand-calculated ground truth."""

    def setup_method(self):
        self.output = run_handler(peek_fasta, fixture_path("test_3seq.fa"))

    def test_sequence_count(self):
        header = extract_header(self.output)
        assert "3 sequences" in header

    def test_total_bp(self):
        header = extract_header(self.output)
        # 40 bp total
        assert "40" in header

    def test_gc_content(self):
        gc_line = extract_section(self.output, "GC content")
        assert gc_line is not None
        # GC = 27/40 = 67.5%
        gc_val = float(re.search(r"([\d.]+)%", gc_line).group(1))
        assert abs(gc_val - 67.5) < 0.1

    def test_n_bases(self):
        n_line = extract_section(self.output, "N bases")
        assert n_line is not None
        assert "4" in n_line
        # 4/40 = 10.0%
        assert "10.0%" in n_line

    def test_n50(self):
        n50_line = extract_section(self.output, "N50")
        assert n50_line is not None
        assert "20" in n50_line

    def test_length_stats(self):
        length_line = extract_section(self.output, "Length")
        assert length_line is not None
        assert "10" in length_line  # min
        assert "20" in length_line  # max

    def test_gc_qc_warning(self):
        # 67.5% GC triggers warning (threshold is >65%)
        assert has_qc_warning(self.output, "GC content")
        assert has_qc_warning(self.output, "25")  # "expected 25–65%"


class TestFastaHighN:
    """test_high_n.fa: 40bp, 30 N bases = 75% N."""

    def setup_method(self):
        self.output = run_handler(peek_fasta, fixture_path("test_high_n.fa"))

    def test_n_warning(self):
        # 75% N should trigger "High N content" warning
        assert has_qc_warning(self.output, "High N content")

    def test_sequence_count(self):
        header = extract_header(self.output)
        assert "1 sequence" in header


class TestFasta4Seq:
    """test_4seq.fa: 4 sequences of known lengths to test even-count median.

    Lengths: 10, 30, 40, 60 (all A bases, GC=0%)
    Total: 140 bp
    Sorted: [10, 30, 40, 60]
    Mean: 140 / 4 = 35
    Median: index 4//2 = 2 → sorted[2] = 40 (upper-middle, not average)
    N50: sorted desc = [60, 40, 30, 10], cumsum: 60 >= 70 → no,
         60+40=100 >= 70 → yes, N50 = 40
    GC = 0% → should trigger low GC warning
    """

    def setup_method(self):
        self.output = run_handler(peek_fasta, fixture_path("test_4seq.fa"))

    def test_sequence_count(self):
        header = extract_header(self.output)
        assert "4 sequences" in header

    def test_total_bp(self):
        header = extract_header(self.output)
        assert "140" in header

    def test_mean_length(self):
        length_line = extract_section(self.output, "Length")
        assert length_line is not None
        assert "mean 35" in length_line

    def test_min_max(self):
        length_line = extract_section(self.output, "Length")
        assert "10" in length_line   # min
        assert "60" in length_line   # max

    def test_n50(self):
        n50 = extract_section(self.output, "N50")
        assert n50 is not None
        assert "40" in n50

    def test_low_gc_warning(self):
        # 0% GC should trigger unusual GC warning
        assert has_qc_warning(self.output, "GC content")


class TestFastaMultiline:
    """test_multiline.fa: 1 sequence split across 3 lines of 10bp each.

    Total: 30 bp (ACGTACGTAC × 3)
    GC = 15/30 = 50.0%
    """

    def setup_method(self):
        self.output = run_handler(peek_fasta, fixture_path("test_multiline.fa"))

    def test_single_sequence(self):
        header = extract_header(self.output)
        assert "1 sequence" in header

    def test_total_bp(self):
        header = extract_header(self.output)
        assert "30" in header

    def test_gc_content(self):
        gc = extract_section(self.output, "GC content")
        gc_val = float(re.search(r"([\d.]+)%", gc).group(1))
        assert abs(gc_val - 50.0) < 0.1


class TestFastaEmpty:
    """empty.fa: 0 bytes. Should not crash."""

    def setup_method(self):
        self.output = run_handler(peek_fasta, fixture_path("empty.fa"))

    def test_no_crash(self):
        # May print something or nothing, but should not raise
        assert True
