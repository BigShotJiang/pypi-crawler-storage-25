"""Tests for FASTQ handler — ground truth calculated by hand.

test_4reads.fq contains 4 reads, each 8 bp:
  read1: ACGTACGT  qual: IIIIIIII   (I=73, Q=73-33=40)
  read2: GGCCGGCC  qual: FFFFFFFF   (F=70, Q=70-33=37)
  read3: AATTAATT  qual: BBBBBBBB   (B=66, Q=66-33=33)
  read4: GCGCGCGC  qual: DDDDDDDD   (D=68, Q=68-33=35)

Totals:
  4 reads, 32 bp total
  All reads 8 bp → "all 8 bp"
  GC counts: read1=4, read2=8, read3=0, read4=8 → total GC=20
  GC% = 20/32 = 62.5%
  Per-read mean Q: 40, 37, 33, 35
  Overall mean Q = (40+37+33+35)/4 = 36.25
  Median Q = sorted [33,35,37,40] → index 2 = 37
  Min Q ord = 66 (B), Q=33
  Max Q ord = 73 (I), Q=40
  Encoding: min ord 66 ≥ 64? Yes → but 66 < 64 is false... wait:
    Actually B=66 which is ≥ 64, so encoding_offset could be 64.
    But the detection checks: if lo < 64 → Phred+33, else Phred+64.
    B=66, so lo=66, 66 < 64 is False → Phred+64.
    With offset 64: Q values = 73-64=9, 70-64=6, 66-64=2, 68-64=4
    Mean Q = (9+6+2+4)/4 = 5.25

    Actually let's re-check. The detection uses the FIRST quality line
    only. First line is IIIIIIII, lo = ord('I') = 73. 73 < 64? No → Phred+64.

    So with Phred+64: all Q values shift down by 64 instead of 33.
    read1: Q = 73-64 = 9 for all 8 bases → mean 9
    read2: Q = 70-64 = 6 for all 8 bases → mean 6
    read3: Q = 66-64 = 2 for all 8 bases → mean 2
    read4: Q = 68-64 = 4 for all 8 bases → mean 4

    Overall mean Q = (9+6+2+4)/4 = 5.25
    Median Q = sorted [2,4,6,9] → index 2 = 6

    Hmm, that means all-uppercase quality with no low chars gets detected
    as Phred+64. We need a fixture with low-quality chars to trigger Phred+33.

test_lowqual.fq contains 4 reads, each 8 bp:
  read1: ACGTACGT  qual: ########   (#=35, Q=35-33=2)
  read2: GGCCGGCC  qual: $$$$$$$$   ($=36, Q=36-33=3)
  read3: AATTAATT  qual: !!!!!!!!   (!=33, Q=33-33=0)
  read4: GCGCGCGC  qual: &&&&&&&&   (&=38, Q=38-33=5)

  First quality line: ########, lo = 35. 35 < 64 → Phred+33. ✓
  Per-read mean Q: 2, 3, 0, 5
  Overall mean Q = (2+3+0+5)/4 = 2.5
  This should trigger "Low mean quality" QC warning (threshold < 20)
  GC: read1=4, read2=8, read3=0, read4=8 → 20/32 = 62.5%
"""

import re
from conftest import extract_header, extract_section, fixture_path, has_qc_warning, run_handler
from peek_bio.formats.fastq import peek_fastq


class TestFastq4Reads:
    """test_4reads.fq — 4 reads, 8bp each, moderate quality.

    NOTE: Due to all quality chars being ≥64, this gets detected as
    Phred+64. Quality values are shifted accordingly.
    """

    def setup_method(self):
        self.output = run_handler(peek_fastq, fixture_path("test_4reads.fq"))

    def test_read_count(self):
        header = extract_header(self.output)
        assert "4 reads" in header

    def test_total_bp(self):
        header = extract_header(self.output)
        assert "32" in header

    def test_all_same_length(self):
        rl = extract_section(self.output, "Read length")
        assert rl is not None
        assert "8" in rl
        assert "all" in rl.lower()

    def test_gc_content(self):
        gc = extract_section(self.output, "GC content")
        assert gc is not None
        gc_val = float(re.search(r"([\d.]+)%", gc).group(1))
        # 20/32 = 62.5%
        assert abs(gc_val - 62.5) < 0.1


class TestFastqLowQual:
    """test_lowqual.fq — 4 reads with very low quality (Phred+33).

    Per-read mean Q: 2, 3, 0, 5 → overall mean = 2.5
    Should trigger low quality QC warning.
    """

    def setup_method(self):
        self.output = run_handler(peek_fastq, fixture_path("test_lowqual.fq"))

    def test_phred33_detected(self):
        header = extract_header(self.output)
        # Should not contain Phred+64 in output
        assert "Phred+33" in self.output

    def test_low_quality_warning(self):
        assert has_qc_warning(self.output, "Low mean quality")

    def test_mean_quality(self):
        q_line = extract_section(self.output, "Quality")
        assert q_line is not None
        # Extract mean Q value
        m = re.search(r"mean Q([\d.]+)", q_line)
        assert m is not None
        mean_q = float(m.group(1))
        # Should be 2.5
        assert abs(mean_q - 2.5) < 0.1

    def test_read_count_lowqual(self):
        header = extract_header(self.output)
        assert "4 reads" in header


class TestFastqVarLen:
    """test_varlen.fq: 4 reads of different lengths (4, 8, 12, 16 bp).

    Total bp = 4 + 8 + 12 + 16 = 40
    Sequences: ACGT, ACGTACGT, ACGTACGTACGT, ACGTACGTACGTACGT
    GC: each has 50% GC (C + G = half of each read)
      read1: 2/4, read2: 4/8, read3: 6/12, read4: 8/16 → total GC = 20/40 = 50%
    All quality chars are 'I' (ord 73). 73 >= 64 → Phred+64, Q = 73-64 = 9 for all.
    """

    def setup_method(self):
        self.output = run_handler(peek_fastq, fixture_path("test_varlen.fq"))

    def test_read_count(self):
        header = extract_header(self.output)
        assert "4 reads" in header

    def test_total_bp(self):
        header = extract_header(self.output)
        assert "40" in header

    def test_variable_lengths(self):
        rl = extract_section(self.output, "Read length")
        assert rl is not None
        # Should show a range, not "all X bp"
        assert "4" in rl
        assert "16" in rl

    def test_gc_content(self):
        gc = extract_section(self.output, "GC content")
        assert gc is not None
        gc_val = float(re.search(r"([\d.]+)%", gc).group(1))
        assert abs(gc_val - 50.0) < 0.1


class TestFastqAdapterDetection:
    """test_adapter.fq: 10 reads, 4 contain Illumina adapter (AGATCGGAAGAG).

    Reads 2, 4, 6, 8 have AGATCGGAAGAG in the last 20bp of sequence.
    Reads 1, 3, 5, 7, 9, 10 are clean.
    Adapter rate = 4/10 = 40%.
    Should show Adapters section (>=1%) and trigger adapter QC warning (>5%).
    """

    def setup_method(self):
        self.output = run_handler(peek_fastq, fixture_path("test_adapter.fq"))

    def test_read_count(self):
        header = extract_header(self.output)
        assert "10 reads" in header

    def test_adapter_section_shown(self):
        adapter = extract_section(self.output, "Adapters")
        assert adapter is not None
        assert "adapter" in adapter.lower()

    def test_adapter_percentage(self):
        adapter = extract_section(self.output, "Adapters")
        assert adapter is not None
        m = re.search(r"([\d.]+)%", adapter)
        assert m is not None
        pct = float(m.group(1))
        assert abs(pct - 40.0) < 1.0

    def test_adapter_qc_warning(self):
        assert has_qc_warning(self.output, "Adapter contamination")

    def test_adapter_warning_mentions_trimming(self):
        assert has_qc_warning(self.output, "fastp") or has_qc_warning(self.output, "Trim Galore")


class TestFastq4ReadsNoAdapter:
    """test_4reads.fq: 8bp reads, too short for adapter. No adapter section."""

    def setup_method(self):
        self.output = run_handler(peek_fastq, fixture_path("test_4reads.fq"))

    def test_no_adapter_section(self):
        adapter = extract_section(self.output, "Adapters")
        assert adapter is None

    def test_no_adapter_warning(self):
        assert not has_qc_warning(self.output, "Adapter contamination")


class TestFastqEmpty:
    """empty.fq: 0 bytes. Should not crash."""

    def setup_method(self):
        self.output = run_handler(peek_fastq, fixture_path("empty.fq"))

    def test_no_crash(self):
        assert True
