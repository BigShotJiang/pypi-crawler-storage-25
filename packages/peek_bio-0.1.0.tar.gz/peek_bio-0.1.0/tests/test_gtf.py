"""Tests for GTF handler — ground truth from fixture contents.

test_simple.gtf contains 8 features:
  chr1  gene        100-500   gene_id GENE1, gene_name TP53
  chr1  transcript  100-500   gene_id GENE1, transcript_id TX1
  chr1  exon        100-200   gene_id GENE1, transcript_id TX1
  chr1  exon        300-500   gene_id GENE1, transcript_id TX1
  chr2  gene        1000-2000 gene_id GENE2, gene_name BRCA1
  chr2  transcript  1000-2000 gene_id GENE2, transcript_id TX2
  chr2  exon        1000-1500 gene_id GENE2, transcript_id TX2
  chr2  exon        1700-2000 gene_id GENE2, transcript_id TX2

Feature types: 2 genes, 2 transcripts, 4 exons
Genes: 2 (TP53, BRCA1)
Chromosomes: chr1 (4 features), chr2 (4 features)
Source: all "test"
"""

from conftest import extract_header, extract_section, fixture_path, has_qc_warning, run_handler
from peek_bio.formats.gtf import peek_gtf


class TestSimpleGtf:
    """test_simple.gtf: 8 features, 2 genes, 2 chromosomes."""

    def setup_method(self):
        self.output = run_handler(peek_gtf, fixture_path("test_simple.gtf"))

    def test_feature_count(self):
        header = extract_header(self.output)
        assert "8" in header

    def test_feature_types(self):
        feat_line = extract_section(self.output, "Features")
        assert feat_line is not None
        assert "gene" in feat_line.lower()
        assert "exon" in feat_line.lower()

    def test_gene_count(self):
        genes = extract_section(self.output, "Genes")
        assert genes is not None
        assert "2" in genes

    def test_gene_ids(self):
        # Gene section shows unique gene IDs
        genes = extract_section(self.output, "Genes")
        assert genes is not None
        assert "unique gene ID" in genes

    def test_chromosomes(self):
        chroms = extract_section(self.output, "Chroms")
        assert chroms is not None
        assert "2" in chroms


class TestSimpleGtfNoWarnings:
    """test_simple.gtf should NOT trigger any QC warnings.

    It has 2 genes on 2 chromosomes with gene_ids, so none of the
    three warning conditions apply.
    """

    def setup_method(self):
        self.output = run_handler(peek_gtf, fixture_path("test_simple.gtf"))

    def test_no_single_chrom_warning(self):
        assert not has_qc_warning(self.output, "may be a subset")

    def test_no_missing_geneid_warning(self):
        assert not has_qc_warning(self.output, "lack gene_id")

    def test_no_no_genes_warning(self):
        assert not has_qc_warning(self.output, "No gene-level features")


class TestGtfSingleChrom:
    """single_chr.gtf: 7 features, all on chr7.

    Should trigger "All features on chr7; may be a subset" warning.
    """

    def setup_method(self):
        self.output = run_handler(peek_gtf, fixture_path("single_chr.gtf"))

    def test_feature_count(self):
        header = extract_header(self.output)
        assert "7" in header

    def test_single_chrom_warning(self):
        assert has_qc_warning(self.output, "All features on chr7")
        assert has_qc_warning(self.output, "may be a subset")


class TestGtfNoGenes:
    """no_genes.gtf: 5 features (4 exons + 1 CDS), no gene features.

    Should trigger "No gene-level features found" warning.
    """

    def setup_method(self):
        self.output = run_handler(peek_gtf, fixture_path("no_genes.gtf"))

    def test_feature_count(self):
        header = extract_header(self.output)
        assert "5" in header

    def test_no_genes_warning(self):
        assert has_qc_warning(self.output, "No gene-level features")

    def test_warning_mentions_types(self):
        assert has_qc_warning(self.output, "exon")


class TestGtfMissingGeneId:
    """missing_gene_id.gtf: 5 gene features, only 1 has gene_id.

    4/5 = 80% missing gene_id → should trigger warning (threshold >20%).
    """

    def setup_method(self):
        self.output = run_handler(peek_gtf, fixture_path("missing_gene_id.gtf"))

    def test_feature_count(self):
        header = extract_header(self.output)
        assert "5" in header

    def test_missing_geneid_warning(self):
        assert has_qc_warning(self.output, "lack gene_id")

    def test_warning_shows_percentage(self):
        assert has_qc_warning(self.output, "80%")


class TestGtfEmpty:
    """empty.gtf: 0 bytes. Should not crash."""

    def setup_method(self):
        self.output = run_handler(peek_gtf, fixture_path("empty.gtf"))

    def test_no_crash(self):
        assert True
