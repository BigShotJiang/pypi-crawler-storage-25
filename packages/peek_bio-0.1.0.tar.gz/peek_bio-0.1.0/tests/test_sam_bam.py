"""Tests for SAM handler — ground truth from fixture contents.

test_simple.sam contains:
  @HD  VN:1.6  SO:coordinate
  @SQ  SN:chr1 LN:1000
  @SQ  SN:chr2 LN:2000

  read1  0   chr1  100  60  8M  → mapped, MAPQ=60
  read2  0   chr1  200  60  8M  → mapped, MAPQ=60
  read3  0   chr2  100  30  8M  → mapped, MAPQ=30
  read4  4   *     0    0   *   → unmapped (FLAG=4)
  read5  0   chr2  200  60  8M  → mapped, MAPQ=60

Totals:
  5 reads total
  4 mapped, 1 unmapped → 80% mapped
  All mapped reads are 8 bp
  MAPQ values (mapped only): [60, 60, 30, 60]
    mean MAPQ = (60+60+30+60)/4 = 52.5
    sorted: [30, 60, 60, 60], median = sorted[2] = 60
  Sort order: coordinate
  Reference: 2 sequences, 3000 bp total (chr1:1000, chr2:2000)
  Not paired (all FLAG bits for paired are 0)
"""

import pytest
import re
from conftest import extract_header, extract_section, fixture_path, has_qc_warning, run_handler

try:
    import pysam
    _HAS_PYSAM = True
except ImportError:
    _HAS_PYSAM = False

if _HAS_PYSAM:
    from peek_bio.formats.sam_bam import peek_sam_bam


@pytest.mark.skipif(not _HAS_PYSAM, reason="pysam not installed")
class TestSimpleSam:
    """test_simple.sam: 5 reads, 4 mapped, 1 unmapped, plain text SAM."""

    def setup_method(self):
        self.output = run_handler(peek_sam_bam, fixture_path("test_simple.sam"))

    def test_read_count(self):
        header = extract_header(self.output)
        assert header is not None
        assert "5" in header
        assert "read" in header.lower()

    def test_mapping_rate(self):
        reads_line = extract_section(self.output, "Reads")
        assert reads_line is not None
        # 4 out of 5 mapped = 80%
        assert "80" in reads_line

    def test_read_length(self):
        # All mapped reads are 8 bp, single-end
        rl = extract_section(self.output, "Read length")
        assert rl is not None
        assert "8" in rl

    def test_sort_order(self):
        so = extract_section(self.output, "Sort order")
        assert so is not None
        assert "coordinate" in so.lower()

    def test_reference(self):
        ref = extract_section(self.output, "Reference")
        assert ref is not None
        assert "2" in ref  # 2 sequences

    def test_mapq(self):
        mapq = extract_section(self.output, "MAPQ")
        assert mapq is not None
        # Mean MAPQ = 52.5
        m = re.search(r"mean\s+([\d.]+)", mapq)
        assert m is not None
        mean_mapq = float(m.group(1))
        assert abs(mean_mapq - 52.5) < 0.1
        # Median MAPQ = 60
        m2 = re.search(r"median\s+(\d+)", mapq)
        assert m2 is not None
        assert int(m2.group(1)) == 60

    def test_not_paired(self):
        # No paired section (or if Paired section exists, it should say "no")
        paired = extract_section(self.output, "Paired")
        if paired is not None:
            assert "no" in paired.lower()

    def test_no_low_mapping_warning(self):
        # 80% is exactly at the threshold — should NOT warn (threshold is < 80)
        assert not has_qc_warning(self.output, "Low mapping rate")


@pytest.mark.skipif(not _HAS_PYSAM, reason="pysam not installed")
class TestLowMapqSam:
    """test_lowmapq.sam: 6 mapped reads with very low MAPQ values.

    MAPQ values: 5, 3, 10, 2, 8, 5
    Mean MAPQ = (5+3+10+2+8+5)/6 = 33/6 = 5.5
    Sorted: [2, 3, 5, 5, 8, 10], median = sorted[3] = 5
    Should trigger "Low MAPQ" QC warning (threshold: mean < 20).
    """

    def setup_method(self):
        self.output = run_handler(peek_sam_bam, fixture_path("test_lowmapq.sam"))

    def test_read_count(self):
        header = extract_header(self.output)
        assert header is not None
        assert "6" in header

    def test_mapq_mean(self):
        mapq = extract_section(self.output, "MAPQ")
        assert mapq is not None
        m = re.search(r"mean\s+([\d.]+)", mapq)
        assert m is not None
        mean_mapq = float(m.group(1))
        assert abs(mean_mapq - 5.5) < 0.1

    def test_mapq_median(self):
        mapq = extract_section(self.output, "MAPQ")
        m = re.search(r"median\s+(\d+)", mapq)
        assert m is not None
        assert int(m.group(1)) == 5

    def test_low_mapq_warning(self):
        assert has_qc_warning(self.output, "Low MAPQ")


@pytest.mark.skipif(not _HAS_PYSAM, reason="pysam not installed")
class TestPairedSam:
    """test_paired.sam: 3 proper pairs (6 reads), all paired-end.

    FLAG 99  = paired + proper_pair + mate_reverse + first_in_pair
    FLAG 147 = paired + proper_pair + read_reverse + second_in_pair
    All reads 8 bp, MAPQ=60, 1 reference sequence (chr1:5000).
    >90% of reads have paired flag → is_paired should be True.
    """

    def setup_method(self):
        self.output = run_handler(peek_sam_bam, fixture_path("test_paired.sam"))

    def test_read_count(self):
        header = extract_header(self.output)
        assert header is not None
        assert "6" in header

    def test_paired_detected(self):
        # Should show "Paired" section with "yes"
        paired = extract_section(self.output, "Paired")
        assert paired is not None
        assert "yes" in paired.lower()

    def test_paired_read_length(self):
        # Paired section should mention read length: "yes (2×8 bp)"
        paired = extract_section(self.output, "Paired")
        assert paired is not None
        assert "8" in paired

    def test_reference_single_chrom(self):
        ref = extract_section(self.output, "Reference")
        assert ref is not None
        assert "1" in ref  # 1 sequence


@pytest.mark.skipif(not _HAS_PYSAM, reason="pysam not installed")
class TestLowMapping150Sam:
    """test_lowmap_150.sam: 150 reads, only 40 mapped → 26.7% mapping rate.

    40 mapped (FLAG=0, MAPQ=30) + 110 unmapped (FLAG=4)
    Sort order: unsorted
    No index → uses sampled mapping rate for QC warning.
    n_sampled=150 > 100, so the low-mapping warning should fire.
    Mapping rate = 40/150 = 26.7%
    """

    def setup_method(self):
        self.output = run_handler(peek_sam_bam, fixture_path("test_lowmap_150.sam"))

    def test_read_count(self):
        header = extract_header(self.output)
        assert header is not None
        assert "150" in header

    def test_mapping_rate_approx(self):
        reads_line = extract_section(self.output, "Reads")
        assert reads_line is not None
        # ~27% mapped from sampled reads
        assert "27" in reads_line or "26" in reads_line

    def test_low_mapping_warning(self):
        assert has_qc_warning(self.output, "Low mapping rate")

    def test_sort_order_unsorted(self):
        so = extract_section(self.output, "Sort order")
        assert so is not None
        assert "unsorted" in so.lower()


@pytest.mark.skipif(not _HAS_PYSAM, reason="pysam not installed")
class TestInsertSizeSam:
    """test_insert_size.sam: 5 proper pairs (10 reads), 50bp reads.

    Template lengths (positive TLEN only, from first-in-pair reads):
      pair1: TLEN=300
      pair2: TLEN=250
      pair3: TLEN=400
      pair4: TLEN=250
      pair5: TLEN=350

    Sorted: [250, 250, 300, 350, 400]
    Mean = (300+250+400+250+350)/5 = 1550/5 = 310
    Median = sorted[2] = 300
    Min = 250, Max = 400
    """

    def setup_method(self):
        self.output = run_handler(peek_sam_bam, fixture_path("test_insert_size.sam"))

    def test_paired_detected(self):
        paired = extract_section(self.output, "Paired")
        assert paired is not None
        assert "yes" in paired.lower()

    def test_insert_size_shown(self):
        isize = extract_section(self.output, "Insert size")
        assert isize is not None

    def test_insert_size_mean(self):
        isize = extract_section(self.output, "Insert size")
        assert isize is not None
        m = re.search(r"mean\s+([\d,]+)", isize)
        assert m is not None
        mean_val = int(m.group(1).replace(",", ""))
        assert abs(mean_val - 310) < 2

    def test_insert_size_median(self):
        isize = extract_section(self.output, "Insert size")
        assert isize is not None
        m = re.search(r"median\s+([\d,]+)", isize)
        assert m is not None
        median_val = int(m.group(1).replace(",", ""))
        assert median_val == 300

    def test_insert_size_range(self):
        isize = extract_section(self.output, "Insert size")
        assert isize is not None
        assert "250" in isize
        assert "400" in isize


@pytest.mark.skipif(not _HAS_PYSAM, reason="pysam not installed")
class TestPairedSamInsertSize:
    """test_paired.sam: 3 pairs, all TLEN=208 (positive) or -208 (negative).

    Positive TLENs only: [208, 208, 208]
    Mean = 208, Median = 208, Min = 208, Max = 208
    """

    def setup_method(self):
        self.output = run_handler(peek_sam_bam, fixture_path("test_paired.sam"))

    def test_insert_size_shown(self):
        isize = extract_section(self.output, "Insert size")
        assert isize is not None

    def test_insert_size_value(self):
        isize = extract_section(self.output, "Insert size")
        assert isize is not None
        assert "208" in isize


@pytest.mark.skipif(not _HAS_PYSAM, reason="pysam not installed")
class TestSimpleSamNoInsertSize:
    """test_simple.sam: single-end reads. No insert size section."""

    def setup_method(self):
        self.output = run_handler(peek_sam_bam, fixture_path("test_simple.sam"))

    def test_no_insert_size(self):
        isize = extract_section(self.output, "Insert size")
        assert isize is None
