"""Tests for CSV/TSV handler — ground truth from fixture contents.

test_simple.csv:
  gene,score,category
  TP53,0.95,oncogene
  BRCA1,0.87,tumor_suppressor
  EGFR,NA,oncogene
  MYC,0.91,oncogene
  PTEN,0.72,tumor_suppressor

  → 5 rows, 3 columns
  → gene: str, score: float, category: str
  → 1 NA value in score column

test_simple.tsv:
  chrom  start  end  name
  chr1   100    200  peak_A
  chr1   300    400  peak_B
  chr2   500    600  peak_C

  → 3 rows, 4 columns, tab-separated

test_mixed_types.csv:
  id,value,notes
  12 rows, value column has 10 numeric + 2 string values ("abc", "def")
  → value should be detected as str type (has strings)
  → But if the numeric proportion is 20-95%, should trigger mixed-type warning
  → value has: 9 numeric out of 11 non-NA = 81.8% numeric
"""

import re
from conftest import extract_header, extract_section, fixture_path, has_qc_warning, run_handler
from peek_bio.formats.csv_tsv import peek_csv, peek_tsv


class TestSimpleCsv:
    """test_simple.csv: 5 rows, 3 columns, 1 NA.

    score column (float): 0.95, 0.87, NA, 0.91, 0.72
    Clean sorted: [0.72, 0.87, 0.91, 0.95]
    Median = sorted[2] = 0.91
    Mean = (0.72+0.87+0.91+0.95)/4 = 0.8625
    """

    def setup_method(self):
        self.output = run_handler(peek_csv, fixture_path("test_simple.csv"))

    def test_row_count(self):
        header = extract_header(self.output)
        assert "5" in header

    def test_col_count(self):
        header = extract_header(self.output)
        assert "3" in header

    def test_csv_format(self):
        assert "CSV" in self.output or "comma" in self.output.lower()

    def test_missing_data(self):
        assert "Missing" in self.output
        assert "score" in self.output

    def test_gene_column_is_str(self):
        assert "gene" in self.output
        assert "str" in self.output

    def test_score_column_is_float(self):
        # score has: 0.95, 0.87, NA, 0.91, 0.72
        # After removing NA: all floats
        assert "score" in self.output
        assert "float" in self.output

    def test_median_shown(self):
        # Score summary should include median
        assert "median" in self.output.lower()

    def test_median_value(self):
        # Median of [0.72, 0.87, 0.91, 0.95] = 0.91
        assert "0.91" in self.output

    def test_mean_value(self):
        # Mean of [0.72, 0.87, 0.91, 0.95] = 0.8625 → displayed as 0.86
        assert "0.86" in self.output


class TestSimpleTsv:
    """test_simple.tsv: 3 rows, 4 columns, tab-separated."""

    def setup_method(self):
        self.output = run_handler(peek_tsv, fixture_path("test_simple.tsv"))

    def test_row_count(self):
        header = extract_header(self.output)
        assert "3" in header

    def test_col_count(self):
        header = extract_header(self.output)
        assert "4" in header

    def test_tsv_format(self):
        assert "TSV" in self.output or "tab" in self.output.lower()


class TestMixedTypesCsv:
    """test_mixed_types.csv: value column is 82% numeric → mixed-type warning."""

    def setup_method(self):
        self.output = run_handler(peek_csv, fixture_path("test_mixed_types.csv"))

    def test_row_count(self):
        header = extract_header(self.output)
        assert "12" in header

    def test_missing_data(self):
        # value column has 1 NA
        assert "Missing" in self.output


class TestAllMissingCsv:
    """all_missing.csv: empty_col1 and empty_col2 are 100% missing.

    20 rows, 6 columns. empty_col1 has ., None, null, NA, empty strings.
    empty_col2 is entirely empty. Both should trigger >50% missing QC warning.
    """

    def setup_method(self):
        self.output = run_handler(peek_csv, fixture_path("all_missing.csv"))

    def test_no_crash(self):
        assert len(self.output) > 0

    def test_heavy_missing_warning(self):
        assert has_qc_warning(self.output, ">50% missing")

    def test_identifies_missing_columns(self):
        assert "empty_col1" in self.output
        assert "empty_col2" in self.output


class TestHeaderOnlyCsv:
    """just_header.csv: header row only, no data rows."""

    def setup_method(self):
        self.output = run_handler(peek_csv, fixture_path("just_header.csv"))

    def test_no_crash(self):
        assert len(self.output) > 0

    def test_zero_rows(self):
        header = extract_header(self.output)
        assert "0" in header
