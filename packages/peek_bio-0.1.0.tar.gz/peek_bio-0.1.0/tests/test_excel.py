"""Tests for Excel handler — corrupt file error handling.

test_corrupt.xlsx is actually an HTML file with .xlsx extension.
This is common when journal download walls serve HTML instead of
the actual spreadsheet. openpyxl throws "File is not a zip file".

We test that peek shows a friendly error message instead of crashing.
"""

from conftest import fixture_path, run_handler

try:
    from peek_bio.formats.excel import peek_excel
    _HAS_HANDLER = True
except ImportError:
    _HAS_HANDLER = False

import pytest


@pytest.mark.skipif(not _HAS_HANDLER, reason="openpyxl not installed")
class TestCorruptExcel:
    """test_corrupt.xlsx: HTML masquerading as Excel."""

    def setup_method(self):
        self.output = run_handler(peek_excel, fixture_path("test_corrupt.xlsx"))

    def test_no_crash(self):
        # Should produce output, not crash
        assert len(self.output) > 0

    def test_friendly_error(self):
        # Should mention it's not a valid Excel file
        assert "Not a valid Excel file" in self.output or "Could not open" in self.output

    def test_mentions_html(self):
        # Should hint that it might be an HTML download page
        assert "HTML" in self.output or "corrupted" in self.output
