"""VCF format handler."""

import os
from collections import Counter

from peek_bio.detect import FormatType
from peek_bio.display import Style, header_line, qc_warn, section, separator
from peek_bio.formats import register
from peek_bio.utils import fmt_int, fmt_float, open_maybe_gzip, sparkbar, sparkline


def _classify_variant(ref, alt):
    """Classify a variant from REF and ALT alleles."""
    if "," in alt:
        return "Multi-allelic"
    if len(ref) == 1 and len(alt) == 1:
        return "SNP"
    if len(ref) < len(alt):
        return "Insertion"
    if len(ref) > len(alt):
        return "Deletion"
    return "Complex"


def _natural_chr_sort(name):
    """Sort chromosomes naturally: 1,2,...22,X,Y,MT."""
    s = name.replace("chr", "")
    if s.isdigit():
        return (0, int(s), "")
    order = {"X": 1, "Y": 2, "M": 3, "MT": 3}
    return (1, order.get(s, 99), s)


def _collect_stats(path, is_compressed):
    """Single-pass VCF parsing — returns stats dict."""
    n_variants = 0
    samples = []
    chr_counts = Counter()
    variant_types = Counter()
    filter_counts = Counter()
    qual_values = []
    transitions = 0
    transversions = 0
    # Per-sample genotype tracking (first 10k variants only)
    sample_gt_stats = None  # initialized after header is parsed

    with open_maybe_gzip(path, is_compressed) as f:
        for line in f:
            line = line.rstrip("\n\r")

            # Meta-information lines
            if line.startswith("##"):
                continue

            # Header line
            if line.startswith("#CHROM"):
                cols = line.split("\t")
                if len(cols) > 9:
                    samples = cols[9:]
                    sample_gt_stats = {
                        s: {"called": 0, "het": 0, "hom_alt": 0, "missing": 0}
                        for s in samples
                    }
                continue

            # Data line
            fields = line.split("\t")
            if len(fields) < 8:
                continue

            n_variants += 1
            chrom = fields[0]
            ref = fields[3]
            alt = fields[4]
            qual = fields[5]
            filt = fields[6]

            chr_counts[chrom] += 1
            vtype = _classify_variant(ref, alt)
            variant_types[vtype] += 1
            filter_counts[filt] += 1

            # Ts/Tv classification for SNPs
            if vtype == "SNP":
                pair = ref.upper() + alt.upper()
                if pair in ("AG", "GA", "CT", "TC"):
                    transitions += 1
                else:
                    transversions += 1

            if qual != ".":
                try:
                    qual_values.append(float(qual))
                except ValueError:
                    pass

            # Parse genotypes (first 10k variants, multi-sample only)
            if sample_gt_stats and n_variants <= 10000 and len(fields) > 9:
                fmt_fields = fields[8].split(":")
                gt_idx = fmt_fields.index("GT") if "GT" in fmt_fields else -1
                if gt_idx >= 0:
                    for si, sname in enumerate(samples):
                        if 9 + si < len(fields):
                            gt_raw = fields[9 + si].split(":")[gt_idx] if gt_idx < len(fields[9 + si].split(":")) else "."
                            gt = gt_raw.replace("|", "/")
                            if gt in ("./.", ".", "."):
                                sample_gt_stats[sname]["missing"] += 1
                            else:
                                sample_gt_stats[sname]["called"] += 1
                                alleles = gt.split("/")
                                if len(alleles) == 2:
                                    if alleles[0] != alleles[1]:
                                        sample_gt_stats[sname]["het"] += 1
                                    elif alleles[0] != "0":
                                        sample_gt_stats[sname]["hom_alt"] += 1

    return {
        "n_variants": n_variants,
        "samples": samples,
        "chr_counts": chr_counts,
        "variant_types": variant_types,
        "filter_counts": filter_counts,
        "qual_values": qual_values,
        "transitions": transitions,
        "transversions": transversions,
        "sample_gt_stats": sample_gt_stats,
    }


def peek_vcf(path, is_compressed, opts):
    """Preview a VCF file."""
    stats = _collect_stats(path, is_compressed)

    n_variants = stats["n_variants"]
    samples = stats["samples"]
    chr_counts = stats["chr_counts"]
    variant_types = stats["variant_types"]
    filter_counts = stats["filter_counts"]
    qual_values = stats["qual_values"]

    # Display
    n_samples = len(samples)
    sample_note = f", {fmt_int(n_samples)} sample{'s' if n_samples != 1 else ''}" if n_samples else ""
    filename = os.path.basename(path)

    header_line(filename, f"{fmt_int(n_variants)} variant{'s' if n_variants != 1 else ''}", f"VCF{sample_note}")
    separator()

    # Variant types
    type_order = ["SNP", "Insertion", "Deletion", "Multi-allelic", "Complex"]
    type_parts = []
    for t in type_order:
        count = variant_types.get(t, 0)
        if count > 0:
            base = t.lower()
            if count != 1:
                label = base + "es" if base.endswith("x") else base + "s"
            else:
                label = base
            type_parts.append(f"{fmt_int(count)} {label}")
    if type_parts:
        section("Variants", ", ".join(type_parts))

    # Ts/Tv ratio (key QC metric — belongs in default)
    ts = stats["transitions"]
    tv = stats["transversions"]
    if ts or tv:
        ratio = f"{ts / tv:.2f}" if tv > 0 else "inf"
        section("Ts/Tv", ratio)

    # FILTER stats
    pass_count = filter_counts.pop("PASS", 0)
    pass_count += filter_counts.pop(".", 0)
    filtered_count = sum(filter_counts.values())
    if pass_count or filtered_count:
        filt_str = f"{fmt_int(pass_count)} PASS"
        if filtered_count:
            filter_names = sorted(filter_counts.keys())
            if len(filter_names) <= 3:
                names_str = ", ".join(filter_names)
            else:
                names_str = ", ".join(filter_names[:3]) + ", ..."
            filt_str += f", {fmt_int(filtered_count)} filtered ({names_str})"
        section("FILTER", filt_str)

    # QUAL stats
    if qual_values:
        qual_sorted = sorted(qual_values)
        q_min = min(qual_values)
        q_max = max(qual_values)
        q_mean = sum(qual_values) / len(qual_values)
        mid = len(qual_sorted) // 2
        q_median = qual_sorted[mid] if len(qual_sorted) % 2 else (qual_sorted[mid - 1] + qual_sorted[mid]) / 2
        spark = sparkline(qual_values)
        qual_str = f"min {fmt_float(q_min)}  median {fmt_float(q_median)}  mean {fmt_float(q_mean)}  max {fmt_float(q_max)}"
        if spark:
            qual_str += f"  {Style.CYAN}{spark}{Style.RESET}"
        section("QUAL", qual_str)

    # Chromosome distribution
    n_chroms = len(chr_counts)
    if n_chroms:
        sorted_chroms = sorted(chr_counts.keys(), key=_natural_chr_sort)
        top3 = sorted(chr_counts.items(), key=lambda x: -x[1])[:3]
        top3_str = ", ".join(f"{c} ({fmt_int(n)})" for c, n in top3)
        section("Chroms", f"{n_chroms} total — top: {top3_str}")

        if n_chroms <= 50:
            counts = [chr_counts[c] for c in sorted_chroms]
            labels = [c.replace("chr", "") or c for c in sorted_chroms]
            # Truncate long contig names (e.g. NT_113889.1 → NT_11…)
            labels = [l[:5] + "…" if len(l) > 6 else l for l in labels]
            bar = sparkbar(counts)

            if bar:
                bar_chars = list(bar)
                spaced_bar = ""
                spaced_labels = ""
                for i, (ch, label) in enumerate(zip(bar_chars, labels)):
                    w = max(len(label), 1)
                    if i < len(labels) - 1:
                        spaced_bar += ch + " " * w
                        spaced_labels += f"{label:<{w + 1}}"
                    else:
                        spaced_bar += ch
                        spaced_labels += label
                print(f"          {Style.CYAN}{spaced_bar}{Style.RESET}")
                print(f"          {Style.DIM}{spaced_labels}{Style.RESET}")

    # Per-sample genotype stats (multi-sample VCFs)
    sample_gt_stats = stats.get("sample_gt_stats")
    if sample_gt_stats and n_samples > 0:
        # Compute per-sample metrics
        gt_rates = []
        het_hom_ratios = []
        for sname in samples:
            sg = sample_gt_stats[sname]
            total = sg["called"] + sg["missing"]
            if total > 0:
                rate = sg["called"] / total * 100
                gt_rates.append(rate)
            if sg["hom_alt"] > 0:
                het_hom_ratios.append(sg["het"] / sg["hom_alt"])

        if n_samples <= 3:
            for sname in samples:
                sg = sample_gt_stats[sname]
                total = sg["called"] + sg["missing"]
                rate = sg["called"] / total * 100 if total > 0 else 0
                hh = f"{sg['het'] / sg['hom_alt']:.1f}" if sg["hom_alt"] > 0 else "n/a"
                section(sname, f"{rate:.1f}% genotyped, {fmt_int(sg['het'])} het, {fmt_int(sg['hom_alt'])} hom-alt (het/hom {hh})")
        else:
            if gt_rates:
                mean_rate = sum(gt_rates) / len(gt_rates)
                section("Genotype rate", f"mean {mean_rate:.1f}% across {n_samples} samples")
            if het_hom_ratios:
                mean_hh = sum(het_hom_ratios) / len(het_hom_ratios)
                section("Het/Hom ratio", f"mean {mean_hh:.2f} across {len(het_hom_ratios)} samples")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []

    # Ts/Tv ratio checks
    ts = stats["transitions"]
    tv = stats["transversions"]
    if tv > 0 and ts > 0:
        tstv = ts / tv
        if tstv < 1.0:
            warns.append(f"Ts/Tv ratio {tstv:.2f} is very low — possible artifact or enrichment bias")
        elif tstv < 1.5 and n_variants > 100:
            warns.append(f"Ts/Tv ratio {tstv:.2f} is below expected (~2.0 WGS, ~2.8 WES)")

    # High filter-fail rate
    total_calls = pass_count + filtered_count
    if total_calls > 0 and filtered_count > 0:
        fail_pct = filtered_count / total_calls * 100
        if fail_pct > 50:
            warns.append(f"{fail_pct:.0f}% of variants fail FILTER — heavy filtering applied")

    # Low genotype rate
    if sample_gt_stats and gt_rates:
        mean_gt_rate = sum(gt_rates) / len(gt_rates)
        if mean_gt_rate < 90:
            warns.append(f"Low genotype rate ({mean_gt_rate:.0f}%). Many missing genotypes.")

    # Multiallelic fraction
    multi = variant_types.get("Multi-allelic", 0)
    if n_variants > 100 and multi > 0:
        multi_pct = multi / n_variants * 100
        if multi_pct > 20:
            warns.append(f"{multi_pct:.0f}% multiallelic sites — consider splitting before analysis")

    if warns:
        print()
        for w in warns:
            qc_warn(w)


register(FormatType.VCF, peek_vcf)
