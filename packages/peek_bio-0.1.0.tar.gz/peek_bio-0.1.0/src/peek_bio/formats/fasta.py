"""FASTA file preview."""

import os

from peek_bio.detect import FormatType
from peek_bio.display import (
    Style,
    header_line,
    qc_warn,
    section,
    separator,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_int, open_maybe_gzip, sparkline


def peek_fasta(path, is_compressed, opts):
    """Preview a FASTA file.

    Shows: sequence count, total bp, N50, length distribution,
    GC content, N base count.
    """
    # Stream through collecting stats
    lengths = []
    current_len = 0
    current_name = None
    n_count = 0  # total N bases
    gc_count = 0  # G + C bases
    non_dna_chars = 0  # chars outside ACGTNacgtn — signals protein
    sample_chars = 0  # only sample first ~10k chars for protein detection
    n_seqs_seen = 0

    with open_maybe_gzip(path, is_compressed) as f:
        for line in f:
            line = line.rstrip("\n\r")
            if line.startswith(">"):
                # Save previous sequence
                if current_name is not None:
                    lengths.append(current_len)
                # Start new sequence
                current_name = line[1:].strip()
                current_len = 0
                n_seqs_seen += 1
            else:
                seq = line.strip()
                current_len += len(seq)
                upper_seq = seq.upper()
                n_count += upper_seq.count("N")
                gc_count += upper_seq.count("G") + upper_seq.count("C")
                # Sample chars for protein detection
                if sample_chars < 10000:
                    for ch in seq.upper():
                        if ch.isalpha() and ch not in "ACGTN":
                            non_dna_chars += 1
                        sample_chars += 1

        # Don't forget the last sequence
        if current_name is not None:
            lengths.append(current_len)

    n_seqs = len(lengths)
    if n_seqs == 0:
        header_line(os.path.basename(path), "empty file")
        return

    total_bp = sum(lengths)
    lengths_sorted = sorted(lengths, reverse=True)

    # Detect if this looks like protein (amino acid) vs nucleotide
    is_protein = sample_chars > 0 and (non_dna_chars / max(sample_chars, 1)) > 0.05

    # N50 calculation
    cumsum = 0
    n50 = 0
    for l in lengths_sorted:
        cumsum += l
        if cumsum >= total_bp / 2:
            n50 = l
            break

    # Header — singular/plural
    seq_word = "sequence" if n_seqs == 1 else "sequences"
    header_line(
        os.path.basename(path),
        f"{fmt_int(n_seqs)} {seq_word}, {_fmt_bp(total_bp)}",
        "FASTA",
    )
    separator()

    # Length stats — simplified when uniform or single sequence
    all_same_len = lengths_sorted[0] == lengths_sorted[-1]
    if n_seqs == 1 or all_same_len:
        length_str = _fmt_bp(lengths[0])
        if all_same_len and n_seqs > 1:
            length_str += f" {Style.DIM}(all equal){Style.RESET}"
        section("Length", length_str)
    else:
        mean_len = total_bp // n_seqs
        median_idx = n_seqs // 2
        median_len = sorted(lengths)[median_idx]

        spark = sparkline(lengths)
        spark_str = f"  {Style.CYAN}{spark}{Style.RESET}" if spark else ""

        section(
            "Length",
            f"min {fmt_int(lengths_sorted[-1])}  "
            f"median {fmt_int(median_len)}  "
            f"mean {fmt_int(mean_len)}  "
            f"max {fmt_int(lengths_sorted[0])}"
            f"{spark_str}",
        )

    # N50 (only meaningful with multiple sequences of varying length)
    if n_seqs > 1 and not all_same_len:
        section("N50", fmt_int(n50))

    # GC content (nucleotide only)
    if not is_protein and total_bp > 0:
        gc_pct = gc_count / total_bp * 100
        section("GC content", f"{gc_pct:.1f}%")

    # N content (only for nucleotide sequences with non-zero N count)
    if n_count > 0 and not is_protein:
        pct = n_count / total_bp * 100
        section("N bases", f"{fmt_int(n_count)} ({pct:.1f}%)")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    if not is_protein and total_bp > 0:
        n_pct = n_count / total_bp * 100
        if n_pct > 10:
            warns.append(f"High N content ({n_pct:.1f}%) — possible assembly gaps or low-quality regions")
        elif n_pct > 5:
            warns.append(f"Notable N content ({n_pct:.1f}%)")

    if not is_protein and total_bp > 0:
        gc_pct = gc_count / total_bp * 100
        if gc_pct > 65:
            warns.append(f"Unusual GC content ({gc_pct:.1f}%) — expected 25–65% for most genomes")
        elif gc_pct < 25:
            warns.append(f"Unusual GC content ({gc_pct:.1f}%) — expected 25–65% for most genomes")

    if n_seqs > 1 and not all_same_len:
        # Check for very short sequences that might be contaminants
        short_count = sum(1 for l in lengths if l < 100)
        if short_count > 0:
            short_pct = short_count / n_seqs * 100
            if short_pct > 20:
                warns.append(f"{short_pct:.0f}% of sequences are <100 bp — possible fragments or contaminants")

    if warns:
        print()
        for w in warns:
            qc_warn(w)


def _fmt_bp(bp):
    """Format base pair count: 3.1 Gb, 24.5 Mb, 8,412 bp."""
    if bp >= 1e9:
        return f"{bp / 1e9:.1f} Gb"
    if bp >= 1e6:
        return f"{bp / 1e6:.1f} Mb"
    if bp >= 1e3:
        return f"{bp / 1e3:.1f} kb"
    return f"{fmt_int(bp)} bp"


register(FormatType.FASTA, peek_fasta)
