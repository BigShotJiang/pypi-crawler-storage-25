"""FASTQ file preview."""

import os

from peek_bio.detect import FormatType
from peek_bio.display import (
    Style,
    header_line,
    qc_warn,
    section,
    separator,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_int, open_maybe_gzip, sparkline


def peek_fastq(path, is_compressed, opts):
    """Preview a FASTQ file.

    Shows: read count, total bp, read length distribution,
    quality score summary, GC content, encoding detection.
    """
    # Stats accumulators
    lengths = []
    read_mean_quals = []  # one float per read: mean quality of that read
    gc_count = 0
    total_bp = 0
    encoding_offset = 33  # default Phred+33
    encoding_detected = False
    min_qual_ord = 999
    max_qual_ord = 0

    # Per-position quality for first/last 10bp (for 3' drop detection)
    # Keys: position index → (sum_of_quals, count)
    pos_qual_first10 = {}  # positions 0-9
    pos_qual_last10 = {}   # positions -10 to -1

    # Adapter detection — common 12bp prefixes
    _ADAPTERS = ("AGATCGGAAGAG", "CTGTCTCTTATA")  # Illumina, Nextera
    n_adapter_reads = 0

    # State machine: 0=@header, 1=sequence, 2=+line, 3=quality
    state = 0
    current_seq_len = 0
    current_seq_gc = 0

    with open_maybe_gzip(path, is_compressed) as f:
        for line in f:
            line = line.rstrip("\n\r")

            if state == 0:
                # @header line
                if line.startswith("@"):
                    current_seq_len = 0
                    current_seq_gc = 0
                state = 1

            elif state == 1:
                # Sequence line
                seq = line.strip()
                current_seq_len += len(seq)
                upper = seq.upper()
                current_seq_gc += upper.count("G") + upper.count("C")
                # Check for adapter in last 20bp
                tail = upper[-20:] if len(upper) >= 20 else upper
                for adpt in _ADAPTERS:
                    if adpt in tail:
                        n_adapter_reads += 1
                        break
                state = 2

            elif state == 2:
                # + line (separator), skip
                state = 3

            elif state == 3:
                # Quality line
                qual = line.strip()

                # Detect encoding from first quality line
                if not encoding_detected and qual:
                    lo = min(ord(c) for c in qual)
                    if lo < 64:
                        encoding_offset = 33
                    else:
                        encoding_offset = 64
                    encoding_detected = True

                # Track min/max quality ASCII ordinals
                if qual:
                    for c in qual:
                        o = ord(c)
                        if o < min_qual_ord:
                            min_qual_ord = o
                        if o > max_qual_ord:
                            max_qual_ord = o

                # Per-read mean quality
                if qual:
                    q_sum = sum(ord(c) - encoding_offset for c in qual)
                    q_mean = q_sum / len(qual)
                    read_mean_quals.append(q_mean)

                    # Track quality at first 10 and last 10 positions
                    qlen = len(qual)
                    for p in range(min(10, qlen)):
                        q = ord(qual[p]) - encoding_offset
                        s, c = pos_qual_first10.get(p, (0, 0))
                        pos_qual_first10[p] = (s + q, c + 1)
                    for p in range(max(0, qlen - 10), qlen):
                        rp = p - qlen  # negative index
                        q = ord(qual[p]) - encoding_offset
                        s, c = pos_qual_last10.get(rp, (0, 0))
                        pos_qual_last10[rp] = (s + q, c + 1)

                # Record stats
                lengths.append(current_seq_len)
                total_bp += current_seq_len
                gc_count += current_seq_gc
                state = 0

    n_reads = len(lengths)
    if n_reads == 0:
        header_line(os.path.basename(path), "empty file")
        return

    # Compute stats
    lengths_sorted = sorted(lengths)
    len_min = lengths_sorted[0]
    len_max = lengths_sorted[-1]
    len_mean = total_bp // n_reads
    len_median = lengths_sorted[n_reads // 2]
    all_same_len = len_min == len_max

    gc_pct = (gc_count / total_bp * 100) if total_bp > 0 else 0.0

    encoding_name = "Phred+33" if encoding_offset == 33 else "Phred+64"

    qual_min = min_qual_ord - encoding_offset if min_qual_ord < 999 else 0
    qual_max = max_qual_ord - encoding_offset if max_qual_ord > 0 else 0

    if read_mean_quals:
        quals_sorted = sorted(read_mean_quals)
        q_mean = sum(read_mean_quals) / len(read_mean_quals)
        q_median = quals_sorted[len(quals_sorted) // 2]
    else:
        q_mean = 0
        q_median = 0

    # Display
    header_line(
        os.path.basename(path),
        f"{fmt_int(n_reads)} reads, {_fmt_bp(total_bp)}",
        f"FASTQ, {encoding_name}",
    )
    separator()

    # Read length
    if all_same_len:
        section("Read length", f"all {fmt_int(len_min)} bp")
    else:
        spark = sparkline(lengths)
        spark_str = f"  {Style.CYAN}{spark}{Style.RESET}" if spark else ""
        section(
            "Read length",
            f"min {fmt_int(len_min)}  median {fmt_int(len_median)}  "
            f"mean {fmt_int(len_mean)}  max {fmt_int(len_max)}{spark_str}",
        )

    # Quality
    if read_mean_quals:
        q_spark = sparkline(read_mean_quals)
        q_spark_str = f"  {Style.CYAN}{q_spark}{Style.RESET}" if q_spark else ""
        section(
            "Quality",
            f"mean Q{q_mean:.1f}  median Q{q_median:.0f}  "
            f"range Q{qual_min}–Q{qual_max}{q_spark_str}",
        )

    # GC content
    section("GC content", f"{gc_pct:.1f}%")

    # Adapter content
    if n_reads > 0 and n_adapter_reads > 0:
        adapter_pct = n_adapter_reads / n_reads * 100
        if adapter_pct >= 1:
            section("Adapters", f"~{adapter_pct:.1f}% reads with adapter sequence")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    if q_mean < 20 and read_mean_quals:
        warns.append(f"Low mean quality (Q{q_mean:.1f}) — consider quality trimming")
    if q_mean > 0 and q_mean < 28 and read_mean_quals:
        if f"Low mean quality" not in (warns[0] if warns else ""):
            warns.append(f"Below-average quality (Q{q_mean:.1f}) — check FastQC report")

    # 3' quality drop: compare mean Q at positions 0-4 vs last 5 positions
    if pos_qual_first10 and pos_qual_last10:
        first5_quals = [pos_qual_first10[p][0] / pos_qual_first10[p][1]
                        for p in range(min(5, len(pos_qual_first10)))]
        last5_quals = [pos_qual_last10[p][0] / pos_qual_last10[p][1]
                       for p in range(-min(5, len(pos_qual_last10)), 0)]
        if first5_quals and last5_quals:
            first5_mean = sum(first5_quals) / len(first5_quals)
            last5_mean = sum(last5_quals) / len(last5_quals)
            drop = first5_mean - last5_mean
            if drop > 10:
                warns.append(f"Quality drops {drop:.0f} points at 3' end (Q{first5_mean:.0f} → Q{last5_mean:.0f}) — adapter contamination or sequencing decay")
            elif drop > 5:
                warns.append(f"Moderate quality drop at 3' end (Q{first5_mean:.0f} → Q{last5_mean:.0f})")

    if gc_pct < 25 or gc_pct > 65:
        warns.append(f"Unusual GC content ({gc_pct:.1f}%) — expected 25–65% for most organisms")

    if n_reads > 0 and n_adapter_reads > 0:
        adapter_pct = n_adapter_reads / n_reads * 100
        if adapter_pct > 5:
            warns.append(f"Adapter contamination detected ({adapter_pct:.1f}%). Consider trimming with fastp or Trim Galore.")

    if warns:
        print()
        for w in warns:
            qc_warn(w)


def _fmt_bp(bp):
    """Format base pair count: 3.1 Gb, 24.5 Mb, 8,412 bp."""
    if bp >= 1e9:
        return f"{bp / 1e9:.1f} Gb"
    if bp >= 1e6:
        return f"{bp / 1e6:.1f} Mb"
    if bp >= 1e3:
        return f"{bp / 1e3:.1f} kb"
    return f"{fmt_int(bp)} bp"


register(FormatType.FASTQ, peek_fastq)
