"""H5AD (anndata) file preview."""

import os

try:
    import anndata

    _HAS_ANNDATA = True
except ImportError:
    _HAS_ANNDATA = False

from peek_bio.detect import FormatType
from peek_bio.display import (
    Style,
    header_line,
    qc_warn,
    section,
    separator,
    warning,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_int


def peek_h5ad(path, is_compressed, opts):
    """Preview an H5AD file."""
    if not _HAS_ANNDATA:
        header_line(os.path.basename(path), "H5AD file")
        separator()
        warning("anndata not installed. Run: pip install peek-bio[h5ad]")
        return

    adata = anndata.read_h5ad(path, backed="r")

    n_obs, n_var = adata.shape

    # Collect structural info
    obs_cols = list(adata.obs.columns)
    var_cols = list(adata.var.columns)
    layers = list(adata.layers.keys()) if adata.layers else []
    obsm_keys = list(adata.obsm.keys()) if adata.obsm else []
    obsp_keys = list(adata.obsp.keys()) if adata.obsp else []
    uns_keys = list(adata.uns.keys()) if adata.uns else []

    header_line(
        os.path.basename(path),
        f"{fmt_int(n_obs)} obs x {fmt_int(n_var)} var",
        "H5AD / anndata",
    )
    separator()

    # obs columns
    if obs_cols:
        n = len(obs_cols)
        preview = ", ".join(obs_cols[:6])
        suffix = ", ..." if n > 6 else ""
        section("obs columns", f"({n})  {preview}{suffix}")

    # var columns
    if var_cols:
        n = len(var_cols)
        preview = ", ".join(var_cols[:6])
        suffix = ", ..." if n > 6 else ""
        section("var columns", f"({n})  {preview}{suffix}")

    # Layers
    if layers:
        section("Layers", f"({len(layers)})  {', '.join(layers)}")

    # obsm
    if obsm_keys:
        parts = []
        for k in obsm_keys:
            try:
                shape = adata.obsm[k].shape
                parts.append(f"{k} ({shape[1]}d)")
            except (AttributeError, IndexError):
                parts.append(k)
        section("obsm", f"({len(obsm_keys)})  {', '.join(parts)}")

    # obsp
    if obsp_keys:
        section("obsp", f"({len(obsp_keys)})  {', '.join(obsp_keys)}")

    # uns
    if uns_keys:
        preview = ", ".join(uns_keys[:8])
        suffix = ", ..." if len(uns_keys) > 8 else ""
        section("uns keys", f"{preview}{suffix}")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    if n_obs < 100:
        warns.append(f"Very few observations ({fmt_int(n_obs)})")
    if n_var < 100:
        warns.append(f"Very few variables ({fmt_int(n_var)})")
    if not obs_cols:
        warns.append("No observation metadata (obs is empty)")
    if not obsm_keys:
        warns.append("No embeddings found (obsm is empty), dimensionality reduction may not have been run")
    if warns:
        print()
        for w in warns:
            qc_warn(w)

    adata.file.close()


register(FormatType.H5AD, peek_h5ad)
