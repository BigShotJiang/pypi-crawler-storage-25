"""BigWig file preview."""

import os

try:
    import pyBigWig

    _HAS_PYBIGWIG = True
except ImportError:
    _HAS_PYBIGWIG = False

from peek_bio.detect import FormatType
from peek_bio.display import (
    Style,
    header_line,
    qc_warn,
    section,
    separator,
    warning,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_float, fmt_int, sparkbar


def _natural_chr_sort(chrom):
    """Sort chromosomes naturally: chr1, chr2, ..., chr10, chrX, chrY."""
    name = chrom.replace("chr", "")
    try:
        return (0, int(name), "")
    except ValueError:
        return (1, 0, name)


def peek_bigwig(path, is_compressed, opts):
    """Preview a BigWig file."""
    if not _HAS_PYBIGWIG:
        header_line(os.path.basename(path), "BigWig file")
        separator()
        warning("pyBigWig not installed. Run: pip install peek-bio[bigwig]")
        return

    bw = pyBigWig.open(path)

    chroms = bw.chroms()
    n_chroms = len(chroms)
    total_bp = sum(chroms.values())

    # Get header info
    is_bigbed = bw.isBigBed() if hasattr(bw, "isBigBed") else False
    file_type = "BigBed" if is_bigbed else "BigWig"

    # Sample stats from a few large chromosomes
    sorted_chroms = sorted(chroms.keys(), key=_natural_chr_sort)

    # Get global stats if available
    global_min = None
    global_max = None
    global_mean = None
    weighted_sum = 0.0
    weighted_total = 0
    total_intervals = 0
    chr_intervals = {}

    for chrom in sorted_chroms:
        chrom_len = chroms[chrom]
        try:
            stats_min = bw.stats(chrom, 0, chrom_len, type="min")
            stats_max = bw.stats(chrom, 0, chrom_len, type="max")
            stats_mean = bw.stats(chrom, 0, chrom_len, type="mean")

            if stats_min and stats_min[0] is not None:
                val = stats_min[0]
                if global_min is None or val < global_min:
                    global_min = val
            if stats_max and stats_max[0] is not None:
                val = stats_max[0]
                if global_max is None or val > global_max:
                    global_max = val
            if stats_mean and stats_mean[0] is not None:
                weighted_sum += stats_mean[0] * chrom_len
                weighted_total += chrom_len

            # Count intervals by querying
            try:
                intervals = bw.intervals(chrom, 0, min(chrom_len, 1000000))
                if intervals:
                    # Estimate total intervals from first 1MB
                    est = int(len(intervals) * (chrom_len / min(chrom_len, 1000000)))
                    chr_intervals[chrom] = est
                    total_intervals += est
            except Exception:
                pass

        except Exception:
            pass

    # Compute size-weighted global mean
    global_mean = weighted_sum / weighted_total if weighted_total > 0 else None

    # Default display
    header_line(
        os.path.basename(path),
        f"{n_chroms} chromosomes, {fmt_int(total_bp)} bp",
        file_type,
    )
    separator()

    # Signal range
    if global_min is not None and global_max is not None:
        signal_parts = [f"min {fmt_float(global_min)}", f"max {fmt_float(global_max)}"]
        if global_mean is not None:
            signal_parts.append(f"mean {fmt_float(global_mean)}")
        section("Signal", "  ".join(signal_parts))

    # Estimated intervals
    if total_intervals > 0:
        section("Intervals", f"~{fmt_int(total_intervals)} (estimated)")

    # Chromosome sizes sparkbar
    chr_sizes = [chroms[c] for c in sorted_chroms]
    bar = sparkbar(chr_sizes)

    labels = []
    for c in sorted_chroms:
        label = c.replace("chr", "") or c
        # Truncate long contig names (e.g. NT_113889.1 → NT_11…)
        if len(label) > 6:
            label = label[:5] + "…"
        labels.append(label)

    top3 = sorted(chroms.items(), key=lambda x: -x[1])[:3]
    top3_str = ", ".join(f"{c} ({fmt_int(s)} bp)" for c, s in top3)
    section("Chroms", f"{n_chroms} total — largest: {top3_str}")

    if bar and n_chroms <= 50:
        bar_chars = list(bar)
        spaced_bar = ""
        spaced_labels = ""
        for i, (ch, label) in enumerate(zip(bar_chars, labels)):
            w = max(len(label), 1)
            if i < len(labels) - 1:
                spaced_bar += ch + " " * w
                spaced_labels += f"{label:<{w + 1}}"
            else:
                spaced_bar += ch
                spaced_labels += label
        print(f"          {Style.CYAN}{spaced_bar}{Style.RESET}")
        print(f"          {Style.DIM}{spaced_labels}{Style.RESET}")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    if global_min is not None and global_max is not None:
        if global_min == 0 and global_max == 0:
            warns.append("Signal is all zeros")
    if total_intervals == 0:
        warns.append("No signal intervals detected")
    if warns:
        print()
        for w in warns:
            qc_warn(w)

    bw.close()


register(FormatType.BIGWIG, peek_bigwig)
