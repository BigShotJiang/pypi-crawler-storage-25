"""Format handler registry."""

from peek_bio.detect import FormatType

# Handler map: FormatType → module.peek_file(path, is_compressed, opts)
# Populated lazily — only the needed handler is imported.
_HANDLERS = {}

# Map FormatType → (module name, is_optional)
_FORMAT_MODULES = {
    FormatType.CSV: ("csv_tsv", False),
    FormatType.TSV: ("csv_tsv", False),
    FormatType.BED: ("bed", False),
    FormatType.NARROWPEAK: ("bed", False),
    FormatType.BROADPEAK: ("bed", False),
    FormatType.BEDGRAPH: ("bed", False),
    FormatType.FASTA: ("fasta", False),
    FormatType.FASTQ: ("fastq", False),
    FormatType.GTF: ("gtf", False),
    FormatType.GFF: ("gtf", False),
    FormatType.VCF: ("vcf", False),
    FormatType.EXCEL: ("excel", True),
    FormatType.H5AD: ("h5ad", True),
    FormatType.BIGWIG: ("bigwig", True),
    FormatType.SAM: ("sam_bam", True),
    FormatType.BAM: ("sam_bam", True),
    FormatType.CRAM: ("sam_bam", True),
}


def register(fmt, handler_func):
    """Register a handler function for a format type."""
    _HANDLERS[fmt] = handler_func


def get_handler(fmt):
    """Get the handler function for a format type, or None."""
    if fmt in _HANDLERS:
        return _HANDLERS[fmt]

    # Lazy-import only the module needed for this format
    entry = _FORMAT_MODULES.get(fmt)
    if entry is None:
        return None

    mod_name, is_optional = entry
    try:
        __import__(f"peek_bio.formats.{mod_name}")
    except ImportError:
        if is_optional:
            return None
        raise

    return _HANDLERS.get(fmt)
