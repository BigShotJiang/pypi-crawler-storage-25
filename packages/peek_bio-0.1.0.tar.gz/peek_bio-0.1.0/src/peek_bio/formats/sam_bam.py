"""SAM/BAM/CRAM file preview."""

import os
import sys

try:
    import pysam

    _HAS_PYSAM = True
except ImportError:
    _HAS_PYSAM = False

from peek_bio.detect import FormatType
from peek_bio.display import (
    Style,
    header_line,
    qc_warn,
    section,
    separator,
    warning,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_int, sparkbar, sparkline


def _natural_chr_sort(name):
    """Sort chromosomes naturally: chr1, chr2, ..., chrX, chrY."""
    stripped = name.replace("chr", "")
    try:
        return (0, int(stripped), "")
    except ValueError:
        return (1, 0, stripped)


def _fmt_bp(bp):
    """Format base pair count."""
    if bp >= 1e9:
        return f"{bp / 1e9:.1f} Gb"
    if bp >= 1e6:
        return f"{bp / 1e6:.1f} Mb"
    if bp >= 1e3:
        return f"{bp / 1e3:.1f} kb"
    return f"{fmt_int(bp)} bp"


def _open_mode(fmt):
    """Get pysam open mode for a format type."""
    if fmt == FormatType.SAM:
        return "r"
    if fmt == FormatType.CRAM:
        return "rc"
    return "rb"  # BAM


def _format_name(fmt):
    """Human label for format."""
    return {FormatType.SAM: "SAM", FormatType.BAM: "BAM", FormatType.CRAM: "CRAM"}.get(fmt, "BAM")


def _detect_genome(refs, n_refs, total_ref_bp):
    """Infer reference genome build from sequence names and lengths.

    Uses a combination of: chr prefix style, key chromosome lengths,
    total reference size, and number of sequences (alt contigs).
    Returns a short label like 'GRCh38', 'hg19', 'GRCm39', or None.
    """
    if not refs:
        return None

    ref_dict = {name: length for name, length in refs}
    has_chr = any(name.startswith("chr") for name, _ in refs[:30])

    # Key chromosome lengths for identification (chr1 or 1)
    chr1_name = "chr1" if has_chr else "1"
    chr1_len = ref_dict.get(chr1_name, 0)

    # GRCh38 / hg38: chr1 = 248,956,422
    if 248_900_000 < chr1_len < 249_000_000:
        # Distinguish hg38 (with alts, >3000 seqs) vs minimal
        if n_refs > 500:
            return "GRCh38 (with alts)"
        return "GRCh38"

    # GRCh37 / hg19: chr1 = 249,250,621
    if 249_200_000 < chr1_len < 249_300_000:
        if has_chr:
            return "hg19"
        return "GRCh37 (b37)"

    # T2T-CHM13: chr1 = 248,387,328
    if 248_300_000 < chr1_len < 248_400_000:
        return "T2T-CHM13"

    # Mouse — GRCm39: chr1 = 195,154,279; GRCm38/mm10: chr1 = 195,471,971
    if 195_100_000 < chr1_len < 195_200_000:
        return "GRCm39 (mm39)"
    if 195_400_000 < chr1_len < 195_500_000:
        return "GRCm38 (mm10)"

    return None


def peek_sam_bam(path, is_compressed, opts, fmt=None):
    """Preview a SAM/BAM/CRAM file."""
    if not _HAS_PYSAM:
        header_line(os.path.basename(path), "alignment file")
        separator()
        warning("pysam not installed. Run: pip install peek-bio[bam]")
        return

    # Determine format from extension if not passed
    if fmt is None:
        ext = os.path.splitext(path)[1].lower()
        if ext == ".sam":
            fmt = FormatType.SAM
        elif ext == ".cram":
            fmt = FormatType.CRAM
        else:
            fmt = FormatType.BAM

    mode = _open_mode(fmt)
    label = _format_name(fmt)

    # Suppress htslib stderr noise (e.g. CRAM missing reference warnings)
    _devnull = os.open(os.devnull, os.O_WRONLY)
    _old_stderr = os.dup(2)
    os.dup2(_devnull, 2)

    try:
        af = pysam.AlignmentFile(path, mode, check_sq=False)
    except Exception as exc:
        os.dup2(_old_stderr, 2)
        os.close(_devnull)
        os.close(_old_stderr)
        header_line(os.path.basename(path), f"{label} file")
        separator()
        warning(f"Could not open: {exc}")
        return

    # ── Parse header ──────────────────────────────────────────────────
    hdr = af.header.as_dict() if hasattr(af.header, "as_dict") else {}

    # References
    refs = list(zip(af.references, af.lengths)) if af.references else []
    n_refs = len(refs)
    total_ref_bp = sum(length for _, length in refs)

    # Sort order
    hd = hdr.get("HD", {})
    sort_order = hd.get("SO", "unknown")

    # Read groups — just count + names for small sets
    rg_list = hdr.get("RG", [])
    n_read_groups = len(rg_list)

    # Programs — names only, no versions
    pg_list = hdr.get("PG", [])
    pg_names = [pg.get("PN", pg.get("ID", "?")) for pg in pg_list]

    # ── Index stats (fast, if available) ──────────────────────────────
    has_index = False
    total_mapped = 0
    total_unmapped = 0
    total_reads = 0
    per_ref_counts = {}

    try:
        idx_stats = af.get_index_statistics()
        if idx_stats:
            has_index = True
            for stat in idx_stats:
                per_ref_counts[stat.contig] = stat.mapped
                total_mapped += stat.mapped
                total_unmapped += stat.unmapped
            try:
                total_unmapped += af.nocoordinate
            except (AttributeError, ValueError):
                pass
            total_reads = total_mapped + total_unmapped
    except (ValueError, AttributeError):
        pass

    # ── Sample reads for MAPQ + read length + paired + flags ─────────
    # If indexed, we already have total counts — sample first N for quality stats.
    # If NOT indexed, count every read (so we can report total) but only
    # record detailed stats from the first N.
    max_sample = 10000
    mapqs = []
    read_lengths = []
    insert_sizes = []
    n_paired = 0
    n_duplicate = 0
    n_secondary = 0
    n_supplementary = 0
    n_sampled = 0
    n_counted = 0  # total reads iterated (may exceed max_sample for unindexed)
    n_mapped_sample = 0
    n_unmapped_sample = 0

    try:
        for read in af.fetch(until_eof=True):
            n_counted += 1
            if n_sampled < max_sample:
                if not read.is_unmapped:
                    mapqs.append(read.mapping_quality)
                    n_mapped_sample += 1
                else:
                    n_unmapped_sample += 1
                if read.query_length and read.query_length > 0:
                    read_lengths.append(read.query_length)
                if read.is_paired:
                    n_paired += 1
                    tlen = read.template_length
                    if tlen and 0 < tlen < 10000:
                        insert_sizes.append(tlen)
                if read.is_duplicate:
                    n_duplicate += 1
                if read.is_secondary:
                    n_secondary += 1
                if read.is_supplementary:
                    n_supplementary += 1
                n_sampled += 1
            elif has_index:
                # Already have total from index, no need to count all
                break
    except (ValueError, StopIteration, OSError):
        pass
    except Exception:
        pass

    af.close()

    # Restore stderr
    os.dup2(_old_stderr, 2)
    os.close(_devnull)
    os.close(_old_stderr)

    # ── Derived stats ─────────────────────────────────────────────────
    is_paired = n_sampled > 0 and (n_paired / n_sampled) > 0.9
    mapping_rate = (total_mapped / total_reads * 100) if total_reads > 0 else None

    # Read length summary
    if read_lengths:
        rl_sorted = sorted(read_lengths)
        rl_min = rl_sorted[0]
        rl_max = rl_sorted[-1]
        rl_median = rl_sorted[len(rl_sorted) // 2]
        all_same_rl = rl_min == rl_max
    else:
        rl_min = rl_max = rl_median = 0
        all_same_rl = True

    # MAPQ summary
    if mapqs:
        mapq_mean = sum(mapqs) / len(mapqs)
        mapq_sorted = sorted(mapqs)
        mapq_median = mapq_sorted[len(mapq_sorted) // 2]
    else:
        mapq_mean = mapq_median = 0

    # ── Display ───────────────────────────────────────────────────────
    parts = []
    if has_index:
        parts.append(f"{fmt_int(total_reads)} reads")
    elif n_counted > 0:
        parts.append(f"{fmt_int(n_counted)} reads")
    idx_str = ", indexed" if has_index else ""
    summary = ", ".join(parts) if parts else f"{label} file"

    header_line(os.path.basename(path), summary, f"{label}{idx_str}")
    separator()

    # Reference genome + build detection
    if refs:
        genome = _detect_genome(refs, n_refs, total_ref_bp)
        ref_str = f"{n_refs} sequences, {_fmt_bp(total_ref_bp)}"
        if genome:
            ref_str += f"  [{genome}]"
        section("Reference", ref_str)

    # Read counts + mapping rate
    if has_index and total_reads > 0:
        map_str = f"{fmt_int(total_mapped)} mapped"
        if mapping_rate is not None:
            map_str += f" ({mapping_rate:.1f}%)"
        map_str += f", {fmt_int(total_unmapped)} unmapped"
        section("Reads", map_str)
    elif not has_index and n_sampled > 0:
        # Estimate from sampled reads
        samp_mapped_pct = n_mapped_sample / n_sampled * 100
        map_str = f"~{samp_mapped_pct:.0f}% mapped"
        map_str += f" {Style.DIM}(from {fmt_int(n_sampled)} sampled){Style.RESET}"
        section("Reads", map_str)

    # Flag stats (from sampled reads)
    if n_sampled > 0:
        flag_parts = []
        if n_duplicate > 0:
            dup_pct = n_duplicate / n_sampled * 100
            flag_parts.append(f"{dup_pct:.1f}% duplicates")
        if n_secondary > 0:
            sec_pct = n_secondary / n_sampled * 100
            flag_parts.append(f"{sec_pct:.1f}% secondary")
        if n_supplementary > 0:
            sup_pct = n_supplementary / n_sampled * 100
            flag_parts.append(f"{sup_pct:.1f}% supplementary")
        if flag_parts:
            section("Flags", ", ".join(flag_parts))

    # Paired-end + read length
    if n_sampled > 0:
        if is_paired:
            if all_same_rl:
                section("Paired", f"yes (2×{fmt_int(rl_median)} bp)")
            else:
                section("Paired", f"yes ({fmt_int(rl_min)}–{fmt_int(rl_max)} bp)")
        else:
            if all_same_rl and rl_median > 0:
                section("Read length", f"{fmt_int(rl_median)} bp")
            elif read_lengths:
                section("Read length", f"{fmt_int(rl_min)}–{fmt_int(rl_max)} bp (median {fmt_int(rl_median)})")

    # Insert size (paired-end only)
    if is_paired and insert_sizes:
        is_sorted = sorted(insert_sizes)
        is_mean = sum(insert_sizes) / len(insert_sizes)
        is_median = is_sorted[len(is_sorted) // 2]
        is_min = is_sorted[0]
        is_max = is_sorted[-1]
        spark = sparkline(insert_sizes)
        spark_str = f"  {Style.CYAN}{spark}{Style.RESET}" if spark else ""
        section(
            "Insert size",
            f"mean {fmt_int(int(is_mean))}  median {fmt_int(is_median)}  "
            f"range {fmt_int(is_min)}–{fmt_int(is_max)}{spark_str}",
        )

    # Read groups — count only, names if ≤3
    if n_read_groups > 0:
        if n_read_groups <= 3:
            rg_names = [rg.get("SM", rg.get("ID", "?")) for rg in rg_list]
            section("Read groups", f"{n_read_groups}  ({', '.join(rg_names)})")
        else:
            section("Read groups", fmt_int(n_read_groups))

    # Sort order
    section("Sort order", sort_order)

    # Programs — names only (no versions)
    if pg_names:
        section("Programs", ", ".join(pg_names))

    # MAPQ distribution
    if mapqs:
        spark = sparkline(mapqs)
        spark_str = f"  {Style.CYAN}{spark}{Style.RESET}" if spark else ""
        section("MAPQ", f"mean {mapq_mean:.1f}  median {mapq_median}{spark_str}")

    # Chromosome sparkbar (from index stats)
    if per_ref_counts and n_refs <= 50:
        sorted_refs = sorted(refs, key=lambda x: _natural_chr_sort(x[0]))
        ref_names = [r[0] for r in sorted_refs]
        ref_read_counts = [per_ref_counts.get(r, 0) for r in ref_names]

        top3 = sorted(per_ref_counts.items(), key=lambda x: -x[1])[:3]
        top3_str = ", ".join(f"{n} ({fmt_int(c)})" for n, c in top3)
        section("Chroms", f"{n_refs} total — top: {top3_str}")

        bar = sparkbar(ref_read_counts)
        if bar:
            labels = []
            for name in ref_names:
                short = name.replace("chr", "") or name
                # Truncate long contig names (e.g. NT_113889.1 → NT_11…)
                if len(short) > 6:
                    short = short[:5] + "…"
                labels.append(short)

            spaced_bar = ""
            spaced_labels = ""
            for i, (ch, lbl) in enumerate(zip(bar, labels)):
                w = max(len(lbl), 1)
                if i < len(labels) - 1:
                    spaced_bar += ch + " " * w
                    spaced_labels += f"{lbl:<{w + 1}}"
                else:
                    spaced_bar += ch
                    spaced_labels += lbl
            print(f"          {Style.CYAN}{spaced_bar}{Style.RESET}")
            print(f"          {Style.DIM}{spaced_labels}{Style.RESET}")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    if mapping_rate is not None and mapping_rate < 80:
        warns.append(f"Low mapping rate ({mapping_rate:.1f}%) — possible contamination, wrong reference, or adapter issues")
    elif not has_index and n_sampled > 100:
        samp_map_pct = n_mapped_sample / n_sampled * 100
        if samp_map_pct < 80:
            warns.append(f"Low mapping rate (~{samp_map_pct:.0f}%) — possible contamination, wrong reference, or adapter issues (from {fmt_int(n_sampled)} sampled)")
    if n_sampled > 100:
        dup_pct = n_duplicate / n_sampled * 100
        if dup_pct > 30:
            warns.append(f"High duplicate rate ({dup_pct:.0f}%) — low library complexity or over-sequencing")
    if mapqs and mapq_mean < 20:
        warns.append(f"Low MAPQ (mean {mapq_mean:.1f}) — many ambiguously mapped reads")
    if sort_order == "unsorted" and has_index:
        warns.append("File is indexed but header says unsorted — header may be wrong")
    if warns:
        print()
        for w in warns:
            qc_warn(w)


# Register for all three format types
def _register_if_available(path, is_compressed, opts):
    """Wrapper that determines format from path extension."""
    return peek_sam_bam(path, is_compressed, opts)


register(FormatType.SAM, _register_if_available)
register(FormatType.BAM, _register_if_available)
register(FormatType.CRAM, _register_if_available)
