"""CSV and TSV file preview."""

import csv
import os

from peek_bio.detect import FormatType, format_label
from peek_bio.display import (
    Style,
    columns_section,
    header_line,
    qc_warn,
    separator,
    table,
)
from peek_bio.formats import register
from peek_bio.utils import (
    count_lines,
    fmt_int,
    open_maybe_gzip,
    smart_type,
    summarize_column,
)


def _detect_delimiter(path, is_compressed):
    """Detect delimiter from first few lines."""
    with open_maybe_gzip(path, is_compressed) as f:
        sample = ""
        for i, line in enumerate(f):
            sample += line
            if i >= 10:
                break

    # Try csv.Sniffer
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters="\t,;|")
        return dialect.delimiter
    except csv.Error:
        pass

    # Fallback: count delimiters
    tab_count = sample.count("\t")
    comma_count = sample.count(",")
    if tab_count > comma_count:
        return "\t"
    return ","


def _delimiter_name(delim):
    names = {"\t": "tab-separated", ",": "comma-separated", ";": "semicolon-separated", "|": "pipe-separated"}
    return names.get(delim, f"'{delim}'-separated")


def _has_header(first_line_cells, second_line_cells):
    """Heuristic: if first line looks like strings and second looks more numeric, it's a header."""
    if not second_line_cells:
        return True

    first_numeric = 0
    second_numeric = 0
    for cell in first_line_cells:
        try:
            float(cell.strip())
            first_numeric += 1
        except ValueError:
            pass
    for cell in second_line_cells:
        try:
            float(cell.strip())
            second_numeric += 1
        except ValueError:
            pass

    # If first row is less numeric than second row, probably a header
    return first_numeric < second_numeric


def peek_csv(path, is_compressed, opts):
    """Preview a CSV/TSV file."""
    n_head = opts.get("head", 5)
    delim = _detect_delimiter(path, is_compressed)
    fmt = FormatType.TSV if delim == "\t" else FormatType.CSV

    # Read all rows (for column stats) — but cap at 10k for speed
    rows = []
    skip_initial = 0
    seen_comment_header = False
    with open_maybe_gzip(path, is_compressed) as f:
        for line in f:
            line = line.strip()
            # Skip BOM
            if not rows and line.startswith("\ufeff"):
                line = line[1:]
            if not line:
                skip_initial += 1
                continue
            # Handle # lines: skip pure comment lines (## or # followed by
            # non-tabular text), but keep header lines like "#sample_id\tcol2"
            if line.startswith("#"):
                if line.startswith("##"):
                    # Metadata comment (e.g., VCF/GFF header) — always skip
                    skip_initial += 1
                    continue
                # Single # — could be a header row. If it contains the
                # delimiter and we haven't seen data yet, treat as header.
                if not rows and not seen_comment_header:
                    if delim in line:
                        # Looks like a header: #sample_id\tcol2\t...
                        # Strip the leading # and use as data
                        line = line[1:]
                        seen_comment_header = True
                    else:
                        skip_initial += 1
                        continue
                elif not rows:
                    skip_initial += 1
                    continue
            cells = line.split(delim) if delim == "\t" else next(csv.reader([line], delimiter=delim))
            rows.append(list(cells))
            if len(rows) > 10000:
                break

    if not rows:
        header_line(os.path.basename(path), "empty file")
        return

    # Detect header
    has_hdr = _has_header(rows[0], rows[1] if len(rows) > 1 else [])
    if has_hdr:
        headers = rows[0]
        data_rows = rows[1:]
    else:
        headers = [f"col{i+1}" for i in range(len(rows[0]))]
        data_rows = rows

    n_cols = len(headers)

    # Get total line count
    if len(rows) <= 10000:
        n_rows = len(data_rows)
        exact_count = True
    else:
        n_rows = count_lines(path, is_compressed) - skip_initial - (1 if has_hdr else 0)
        exact_count = False

    # Header
    count_str = fmt_int(n_rows) if exact_count else f">{fmt_int(n_rows)}"
    header_line(
        os.path.basename(path),
        f"{count_str} x {n_cols}",
        f"{format_label(fmt)}, {_delimiter_name(delim)}",
    )
    separator()

    # Column summaries (cap at 15 to avoid flooding terminal)
    max_show = 15
    col_infos = []
    for i, name in enumerate(headers[:max_show]):
        col_values = [row[i] for row in data_rows[:1000] if i < len(row)]
        dtype = smart_type(col_values)
        summary = summarize_column(col_values, dtype)
        col_infos.append((name, dtype, summary))
    columns_section(col_infos)
    if n_cols > max_show:
        print(f"   {Style.DIM}... and {n_cols - max_show} more columns{Style.RESET}")

    # Missing data summary
    _NA_VALUES = {"", "NA", "N/A", "na", "n/a", "NaN", "nan", ".", "None", "none", "NULL", "null", "-"}
    na_cols = []
    for i, name in enumerate(headers):
        na_count = sum(1 for row in data_rows if i < len(row) and row[i].strip() in _NA_VALUES)
        if na_count > 0:
            na_cols.append((name, na_count))
    if na_cols:
        print()
        if len(na_cols) <= 5:
            parts = [f"{name} ({fmt_int(n)})" for name, n in na_cols]
            print(f" {Style.BOLD}Missing:{Style.RESET}  {', '.join(parts)}")
        else:
            parts = [f"{name} ({fmt_int(n)})" for name, n in na_cols[:4]]
            print(f" {Style.BOLD}Missing:{Style.RESET}  {', '.join(parts)}, ...  ({len(na_cols)} cols with NAs)")

    # Preview rows
    print()
    print(f" {Style.BOLD}Head:{Style.RESET}")
    preview_rows = data_rows[:n_head]
    display_rows = []
    for row in preview_rows:
        # Truncate long cells
        display_rows.append([cell[:40] for cell in row[:n_cols]])
    table(headers[:n_cols], display_rows)

    if n_rows > n_head:
        count_note = fmt_int(n_rows) if exact_count else f">{fmt_int(10000)}"
        print(f"   {Style.DIM}({count_note} rows total){Style.RESET}")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    n_data = len(data_rows)
    if n_data > 0 and na_cols:
        # Heavy missingness warning
        heavy = [(name, cnt) for name, cnt in na_cols if cnt / n_data > 0.5]
        if heavy:
            names = ", ".join(name for name, _ in heavy[:4])
            if len(heavy) > 4:
                names += f", ... ({len(heavy)} total)"
            warns.append(f"{len(heavy)} column{'s' if len(heavy) > 1 else ''} >50% missing: {names}")

    # Mixed-type detection: columns typed as str that contain many numeric values
    for i, (name, dtype, _summary) in enumerate(col_infos):
        if dtype == "str":
            col_values = [row[i] for row in data_rows[:1000] if i < len(row) and row[i].strip() not in _NA_VALUES]
            if len(col_values) > 10:
                n_numeric = sum(1 for v in col_values if _is_numeric(v))
                pct_numeric = n_numeric / len(col_values) * 100
                if 20 < pct_numeric < 95:
                    warns.append(f"Column '{name}' is mixed type — {pct_numeric:.0f}% numeric, rest strings")

    if warns:
        print()
        for w in warns:
            qc_warn(w)


def _is_numeric(s):
    """Check if a string looks numeric."""
    try:
        float(s.strip())
        return True
    except (ValueError, AttributeError):
        return False


def peek_tsv(path, is_compressed, opts):
    """TSV is handled by the same function as CSV."""
    return peek_csv(path, is_compressed, opts)


# Register handlers
register(FormatType.CSV, peek_csv)
register(FormatType.TSV, peek_tsv)
