"""GTF/GFF file preview."""

import os
from collections import Counter

from peek_bio.detect import FormatType
from peek_bio.display import (
    Style,
    header_line,
    qc_warn,
    section,
    separator,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_int, open_maybe_gzip, sparkbar


def _natural_chr_sort(chrom):
    """Sort chromosomes naturally: chr1, chr2, ..., chr10, chrX, chrY."""
    name = chrom.replace("chr", "")
    try:
        return (0, int(name), "")
    except ValueError:
        return (1, 0, name)


def peek_gtf(path, is_compressed, opts):
    """Preview a GTF or GFF file.

    Shows: total features, feature type breakdown, gene/transcript counts,
    source programs, chromosome distribution.
    """
    fmt_type = opts.get("format_type", FormatType.GTF)

    n_features = 0
    feature_counts = Counter()
    source_counts = Counter()
    chr_counts = Counter()
    gene_names = set()
    gene_ids = set()
    n_gene_features = 0
    n_gene_no_id = 0
    n_comments = 0

    with open_maybe_gzip(path, is_compressed) as f:
        for line in f:
            line = line.rstrip("\n\r")

            if not line or line.startswith("#"):
                n_comments += 1
                continue

            cols = line.split("\t")
            if len(cols) < 8:
                continue

            n_features += 1
            chrom = cols[0]
            source = cols[1]
            feature_type = cols[2]

            chr_counts[chrom] += 1
            feature_counts[feature_type] += 1
            source_counts[source] += 1

            # Extract gene names/IDs from attributes (col 9)
            if len(cols) >= 9 and feature_type in ("gene", "nucleotide_motif"):
                attrs = cols[8]
                # GTF style: gene_name "TP53";
                gn = _extract_attr(attrs, "gene_name")
                if gn:
                    gene_names.add(gn)
                gi = _extract_attr(attrs, "gene_id")
                if gi:
                    gene_ids.add(gi)
                # GFF/FIMO style: Alias=FOXA1;
                alias = _extract_gff_attr(attrs, "Alias")
                if alias:
                    gene_names.add(alias)
                name = _extract_gff_attr(attrs, "Name")
                if name and not gn and not alias:
                    gene_names.add(name)

                # Track gene_id coverage for QC
                if feature_type == "gene":
                    n_gene_features += 1
                    if not gi:
                        n_gene_no_id += 1

    if n_features == 0:
        header_line(os.path.basename(path), "empty file")
        return

    # Format label
    fmt_name = "GTF" if fmt_type == FormatType.GTF else "GFF"

    header_line(
        os.path.basename(path),
        f"{fmt_int(n_features)} features",
        fmt_name,
    )
    separator()

    # Feature type breakdown — sorted by count, show top types
    sorted_features = sorted(feature_counts.items(), key=lambda x: -x[1])
    if len(sorted_features) == 1:
        ft, count = sorted_features[0]
        section("Features", f"{fmt_int(count)} {ft}")
    else:
        parts = []
        for ft, count in sorted_features[:8]:
            parts.append(f"{fmt_int(count)} {ft}")
        remaining = len(sorted_features) - 8
        summary = ", ".join(parts)
        if remaining > 0:
            summary += f", ...  ({remaining} more types)"
        section("Features", summary)

    # Source(s)
    if source_counts:
        sorted_sources = sorted(source_counts.items(), key=lambda x: -x[1])
        if len(sorted_sources) == 1:
            section("Source", sorted_sources[0][0])
        elif len(sorted_sources) <= 5:
            parts = [f"{s} ({fmt_int(c)})" for s, c in sorted_sources]
            section("Source", ", ".join(parts))
        else:
            parts = [f"{s} ({fmt_int(c)})" for s, c in sorted_sources[:3]]
            section("Source", f"{', '.join(parts)}, ...  ({len(sorted_sources)} total)")

    # Gene count (from attributes)
    if gene_ids:
        section("Genes", f"{fmt_int(len(gene_ids))} unique gene IDs")
    elif gene_names:
        section("Genes", f"{fmt_int(len(gene_names))} unique names")

    # Motif names (for FIMO GFF)
    if gene_names and "nucleotide_motif" in feature_counts:
        sorted_names = sorted(gene_names)
        if len(sorted_names) <= 6:
            section("Motifs", ", ".join(sorted_names))
        else:
            section(
                "Motifs",
                f"{', '.join(sorted_names[:4])}, ...  ({len(sorted_names)} unique)",
            )

    # Chromosome distribution
    if chr_counts:
        top_chroms = sorted(chr_counts.keys(), key=_natural_chr_sort)
        n_chroms = len(chr_counts)
        chr_values = [chr_counts[c] for c in top_chroms]
        bar = sparkbar(chr_values)

        labels = []
        for c in top_chroms:
            label = c.replace("chr", "") or c
            # Truncate long contig names (e.g. NT_113889.1 → NT_11…)
            if len(label) > 6:
                label = label[:5] + "…"
            labels.append(label)

        top3 = sorted(chr_counts.items(), key=lambda x: -x[1])[:3]
        top3_str = ", ".join(f"{c} ({fmt_int(n)})" for c, n in top3)
        section("Chroms", f"{n_chroms} total — top: {top3_str}")

        if bar and n_chroms <= 50:
            bar_chars = list(bar)
            spaced_bar = ""
            spaced_labels = ""
            for i, (ch, label) in enumerate(zip(bar_chars, labels)):
                w = max(len(label), 1)
                if i < len(labels) - 1:
                    spaced_bar += ch + " " * w
                    spaced_labels += f"{label:<{w + 1}}"
                else:
                    spaced_bar += ch
                    spaced_labels += label
            print(f"          {Style.CYAN}{spaced_bar}{Style.RESET}")
            print(f"          {Style.DIM}{spaced_labels}{Style.RESET}")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    if "gene" not in feature_counts and "nucleotide_motif" not in feature_counts:
        top_types = ", ".join(ft for ft, _ in sorted_features[:3])
        warns.append(f"No gene-level features found, file contains only {top_types}")
    if n_gene_features > 0 and n_gene_no_id > 0:
        pct = n_gene_no_id / n_gene_features * 100
        if pct > 20:
            warns.append(f"Many gene features lack gene_id attribute ({pct:.0f}%)")
    if len(chr_counts) == 1:
        only_chr = list(chr_counts.keys())[0]
        warns.append(f"All features on {only_chr}; may be a subset")
    if warns:
        print()
        for w in warns:
            qc_warn(w)


def _extract_attr(attrs_str, key):
    """Extract a GTF attribute value: gene_name "TP53"; → TP53."""
    target = f'{key} "'
    idx = attrs_str.find(target)
    if idx == -1:
        return None
    start = idx + len(target)
    end = attrs_str.find('"', start)
    if end == -1:
        return None
    return attrs_str[start:end]


def _extract_gff_attr(attrs_str, key):
    """Extract a GFF3 attribute value: Alias=FOXA1; → FOXA1."""
    for part in attrs_str.split(";"):
        part = part.strip()
        if part.startswith(f"{key}="):
            return part[len(key) + 1:]
    return None


register(FormatType.GTF, peek_gtf)
register(FormatType.GFF, lambda p, c, o: peek_gtf(p, c, {**o, "format_type": FormatType.GFF}))
