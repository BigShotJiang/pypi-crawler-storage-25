"""Excel (.xlsx) file preview."""

import os

try:
    import openpyxl

    _HAS_OPENPYXL = True
except ImportError:
    _HAS_OPENPYXL = False

from peek_bio.detect import FormatType
from peek_bio.display import (
    Style,
    columns_section,
    header_line,
    qc_warn,
    section,
    separator,
    table,
    warning,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_int, smart_type, summarize_column


def _find_header_row(rows, max_scan=5):
    """Find the real header row, skipping description/title rows.

    Common in journal supplementary tables: row 1 is a long description
    string in one cell with the rest empty, real headers are in row 2+.

    Heuristics (checked for each of the first *max_scan* rows):
    - A "description row" has one cell with >80 chars and most others empty.
    - A "header row" has multiple non-empty cells that look like short labels.
    We pick the first row that looks like headers.
    """
    n_cols = max(len(r) for r in rows) if rows else 0
    if n_cols == 0:
        return 0

    for idx in range(min(max_scan, len(rows))):
        row = rows[idx]
        non_empty = [c for c in row if c.strip()]
        if not non_empty:
            continue  # blank row — skip

        # If only 1 cell is filled and it's long, this is a description row
        long_cells = [c for c in row if len(c) > 80]
        if len(non_empty) <= 2 and long_cells:
            continue

        # Multiple non-empty short cells → likely the header row
        if len(non_empty) >= min(n_cols * 0.5, 3):
            return idx

    return 0  # fallback: use first row


def peek_excel(path, is_compressed, opts):
    """Preview an Excel file."""
    if not _HAS_OPENPYXL:
        header_line(os.path.basename(path), "Excel file")
        separator()
        warning("openpyxl not installed. Run: pip install peek-bio[excel]")
        return

    n_head = opts.get("head", 5)

    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        header_line(os.path.basename(path), "Excel file")
        separator()
        if "zip" in str(exc).lower():
            warning("Not a valid Excel file (may be an HTML download page or corrupted)")
        else:
            warning(f"Could not open: {exc}")
        return

    # Show sheet summary
    sheet_names = wb.sheetnames
    n_sheets = len(sheet_names)

    if n_sheets == 0:
        header_line(os.path.basename(path), "empty workbook", "Excel")
        separator()
        warning("No sheets found in workbook")
        wb.close()
        return

    # Get dimensions for each sheet
    sheet_infos = []
    for name in sheet_names:
        ws = wb[name]
        if ws.max_row and ws.max_column:
            sheet_infos.append((name, ws.max_row, ws.max_column))
        else:
            sheet_infos.append((name, 0, 0))

    # Use first sheet for detail
    ws = wb[sheet_names[0]]
    n_rows = sheet_infos[0][1] if sheet_infos else 0
    n_cols = sheet_infos[0][2] if sheet_infos else 0

    sheet_note = f"{n_sheets} sheet{'s' if n_sheets > 1 else ''}"

    # Read data from first sheet
    all_rows = []
    for row in ws.iter_rows(max_row=min(n_rows, 1001), values_only=True):
        all_rows.append([str(cell) if cell is not None else "" for cell in row])

    wb.close()

    if not all_rows:
        return

    # Trim empty trailing columns — openpyxl sometimes includes phantom columns
    if all_rows:
        max_col = len(all_rows[0])
        while max_col > 0:
            col_idx = max_col - 1
            if all(col_idx >= len(row) or row[col_idx].strip() == "" for row in all_rows):
                max_col -= 1
            else:
                break
        if max_col < len(all_rows[0]):
            all_rows = [row[:max_col] for row in all_rows]
            n_cols = max_col

    # Smart header detection — skip description/title rows
    header_idx = _find_header_row(all_rows)
    headers = all_rows[header_idx]
    data_rows = all_rows[header_idx + 1:]
    skipped = header_idx  # number of description rows skipped

    # Adjust row count for skipped description rows
    actual_data_rows = max(n_rows - 1 - skipped, 0)

    header_line(
        os.path.basename(path),
        f"{fmt_int(actual_data_rows)} x {n_cols}",
        f"Excel, {sheet_note}",
    )
    separator()

    # Sheet listing (if multiple)
    if n_sheets > 1:
        sheet_parts = []
        for name, rows, cols in sheet_infos:
            sheet_parts.append(f"{name} ({fmt_int(rows)} x {cols})")
        section("Sheets", "  ".join(sheet_parts))
        print()

    if skipped > 0:
        section("Note", f"skipped {skipped} description row{'s' if skipped > 1 else ''} before headers")

    # Column summaries (cap at 15)
    max_show = 15
    col_infos = []
    for i, name in enumerate(headers[:max_show]):
        if not name:
            name = f"col{i+1}"
        col_values = [row[i] for row in data_rows[:1000] if i < len(row)]
        dtype = smart_type(col_values)
        summary = summarize_column(col_values, dtype)
        col_infos.append((name, dtype, summary))
    columns_section(col_infos)
    if n_cols > max_show:
        print(f"   {Style.DIM}... and {n_cols - max_show} more columns{Style.RESET}")

    # Missing data summary
    _NA_VALUES = {"", "NA", "N/A", "na", "n/a", "NaN", "nan", ".", "None", "none", "NULL", "null", "-"}
    na_cols = []
    for i in range(len(headers)):
        na_count = sum(1 for row in data_rows if i < len(row) and row[i].strip() in _NA_VALUES)
        if na_count > 0:
            col_name = headers[i] if headers[i] else f"col{i+1}"
            na_cols.append((col_name, na_count))
    if na_cols:
        print()
        if len(na_cols) <= 5:
            parts = [f"{name} ({fmt_int(n)})" for name, n in na_cols]
            print(f" {Style.BOLD}Missing:{Style.RESET}  {', '.join(parts)}")
        else:
            parts = [f"{name} ({fmt_int(n)})" for name, n in na_cols[:4]]
            print(f" {Style.BOLD}Missing:{Style.RESET}  {', '.join(parts)}, ...  ({len(na_cols)} cols with NAs)")

    # Preview rows
    print()
    print(f" {Style.BOLD}Head:{Style.RESET}")
    preview_rows = data_rows[:n_head]
    display_rows = []
    for row in preview_rows:
        display_rows.append([cell[:40] for cell in row[:n_cols]])
    clean_headers = [h if h else f"col{i+1}" for i, h in enumerate(headers)]
    table(clean_headers[:n_cols], display_rows)

    if actual_data_rows > n_head:
        print(f"   {Style.DIM}({fmt_int(actual_data_rows)} rows total){Style.RESET}")

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []
    n_data = len(data_rows)
    if n_data > 0 and na_cols:
        heavy = [(name, cnt) for name, cnt in na_cols if cnt / n_data > 0.5]
        if heavy:
            names = ", ".join(name for name, _ in heavy[:4])
            if len(heavy) > 4:
                names += f", ... ({len(heavy)} total)"
            warns.append(f"{len(heavy)} column{'s' if len(heavy) > 1 else ''} >50% missing: {names}")

    # Mixed-type detection
    for i, (name, dtype, _summary) in enumerate(col_infos):
        if dtype == "str":
            col_values = [row[i] for row in data_rows[:1000] if i < len(row) and row[i].strip() not in _NA_VALUES]
            if len(col_values) > 10:
                n_numeric = sum(1 for v in col_values if _is_numeric(v))
                pct_numeric = n_numeric / len(col_values) * 100
                if 20 < pct_numeric < 95:
                    warns.append(f"Column '{name}' is mixed type — {pct_numeric:.0f}% numeric, rest strings")

    if warns:
        print()
        for w in warns:
            qc_warn(w)


def _is_numeric(s):
    """Check if a string looks numeric."""
    try:
        float(s.strip())
        return True
    except (ValueError, AttributeError):
        return False


register(FormatType.EXCEL, peek_excel)
