"""BED, narrowPeak, broadPeak, and bedGraph file preview."""

import os
from collections import Counter

from peek_bio.detect import FormatType, format_label
from peek_bio.display import (
    Style,
    header_line,
    qc_warn,
    section,
    separator,
)
from peek_bio.formats import register
from peek_bio.utils import fmt_float, fmt_int, open_maybe_gzip, sparkbar, sparkline

def _natural_chr_sort(chrom):
    """Sort chromosomes naturally: chr1, chr2, ..., chr10, chrX, chrY."""
    name = chrom.replace("chr", "")
    try:
        return (0, int(name), "")
    except ValueError:
        return (1, 0, name)

def _detect_bed_cols(first_data_line):
    """Detect number of standard BED columns."""
    cols = first_data_line.split("\t")
    return len(cols)

def _stat_line(label, values, precision=2):
    """Print a min/median/mean/max stats section with sparkline.

    Shows constant value when all identical. Suppresses if empty.
    Returns True if printed.
    """
    if not values:
        return False
    vs = sorted(values)
    if vs[0] == vs[-1]:
        # All identical — show the single value instead of redundant stats
        section(label, f"{fmt_float(vs[0], precision)} {Style.DIM}(all equal){Style.RESET}")
        return True
    n = len(vs)
    median = vs[n // 2]
    mean = sum(values) / n
    spark = sparkline(values)
    spark_str = f"  {Style.CYAN}{spark}{Style.RESET}" if spark else ""
    section(
        label,
        f"min {fmt_float(vs[0], precision)}  "
        f"median {fmt_float(median, precision)}  "
        f"mean {fmt_float(mean, precision)}  "
        f"max {fmt_float(vs[-1], precision)}"
        f"{spark_str}",
    )
    return True

def peek_bed(path, is_compressed, opts):
    """Preview a BED-family file."""
    fmt_type = opts.get("format_type", FormatType.BED)

    # Stream through the file to collect stats
    n_peaks = 0
    widths = []
    scores = []
    signal_values = []
    p_values = []
    q_values = []
    bedgraph_values = []
    chr_counts = Counter()
    strand_counts = Counter()
    prev_chrom = None
    prev_start = -1
    is_sorted = True
    ncols_seen = 0

    with open_maybe_gzip(path, is_compressed) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("track") or line.startswith("browser"):
                continue

            cols = line.split("\t")
            if len(cols) < 3:
                continue

            n_peaks += 1
            chrom = cols[0]
            try:
                start = int(cols[1])
                end = int(cols[2])
            except ValueError:
                continue

            ncols_seen = max(ncols_seen, len(cols))
            widths.append(end - start)
            chr_counts[chrom] += 1

            # Check sorted
            if is_sorted:
                if chrom == prev_chrom and start < prev_start:
                    is_sorted = False
                prev_chrom = chrom
                prev_start = start

            # bedGraph value (col 4, 0-indexed col 3)
            if fmt_type == FormatType.BEDGRAPH and len(cols) >= 4:
                try:
                    bedgraph_values.append(float(cols[3]))
                except ValueError:
                    pass

            # Score (col 5, 0-indexed col 4)
            if len(cols) >= 5 and cols[4] != ".":
                try:
                    scores.append(float(cols[4]))
                except ValueError:
                    pass

            # Strand (col 6, 0-indexed col 5)
            if len(cols) >= 6 and cols[5] in ("+", "-", "."):
                strand_counts[cols[5]] += 1

            # narrowPeak / broadPeak extended columns (0-indexed 6, 7, 8)
            # Col 6 = signalValue, Col 7 = pValue (-log10), Col 8 = qValue (-log10)
            if len(cols) >= 7 and cols[6] not in (".", "-1", ""):
                try:
                    signal_values.append(float(cols[6]))
                except ValueError:
                    pass
            if len(cols) >= 8 and cols[7] not in (".", "-1", ""):
                try:
                    p_values.append(float(cols[7]))
                except ValueError:
                    pass
            if len(cols) >= 9 and cols[8] not in (".", "-1", ""):
                try:
                    q_values.append(float(cols[8]))
                except ValueError:
                    pass

    if n_peaks == 0:
        header_line(os.path.basename(path), "empty file")
        return

    # Determine format label
    sorted_str = "sorted" if is_sorted else "unsorted"
    if fmt_type == FormatType.NARROWPEAK:
        fmt_label = f"narrowPeak format, {ncols_seen} cols, {sorted_str}"
    elif fmt_type == FormatType.BROADPEAK:
        fmt_label = f"broadPeak format, {ncols_seen} cols, {sorted_str}"
    elif fmt_type == FormatType.BEDGRAPH:
        fmt_label = f"bedGraph format, {sorted_str}"
    else:
        fmt_label = f"BED{min(ncols_seen, 12)} format, {sorted_str}"

    # Header — use "intervals" for bedGraph, "peaks" for everything else
    count_word = "intervals" if fmt_type == FormatType.BEDGRAPH else "peaks"
    header_line(
        os.path.basename(path),
        f"{fmt_int(n_peaks)} {count_word}",
        fmt_label,
    )
    separator()

    # Width stats
    if widths:
        widths_sorted = sorted(widths)
        n = len(widths_sorted)
        if widths_sorted[0] == widths_sorted[-1]:
            section("Width", f"{fmt_int(widths_sorted[0])} {Style.DIM}(all equal){Style.RESET}")
        else:
            median = widths_sorted[n // 2] if n % 2 else (widths_sorted[n // 2 - 1] + widths_sorted[n // 2]) // 2
            mean = sum(widths) // n
            spark = sparkline(widths)
            spark_str = f"  {Style.CYAN}{spark}{Style.RESET}" if spark else ""
            section(
                "Width",
                f"min {fmt_int(widths_sorted[0])}  "
                f"median {fmt_int(median)}  "
                f"mean {fmt_int(mean)}  "
                f"max {fmt_int(widths_sorted[-1])}"
                f"{spark_str}",
            )

    # Score stats (suppress if all values are identical — means scores weren't set)
    _stat_line("Score", scores, precision=0)

    # narrowPeak / broadPeak signal stats
    if fmt_type in (FormatType.NARROWPEAK, FormatType.BROADPEAK):
        _stat_line("Signal", signal_values, precision=2)
        _stat_line("-log₁₀(p)", p_values, precision=2)
        _stat_line("-log₁₀(q)", q_values, precision=2)

    # bedGraph value stats
    if fmt_type == FormatType.BEDGRAPH:
        _stat_line("Value", bedgraph_values, precision=4)

    # Chromosome distribution — sparkline bar with labels
    top_chroms = sorted(chr_counts.keys(), key=_natural_chr_sort)
    n_chroms = len(chr_counts)
    chr_values = [chr_counts[c] for c in top_chroms]
    bar = sparkbar(chr_values)

    # Build compact labels: strip "chr" prefix
    labels = []
    for c in top_chroms:
        label = c.replace("chr", "") or c
        # Truncate long contig names (e.g. NT_113889.1 → NT_11…)
        if len(label) > 6:
            label = label[:5] + "…"
        labels.append(label)

    # Top line: count + top 3 with numbers
    top3 = sorted(chr_counts.items(), key=lambda x: -x[1])[:3]
    top3_str = ", ".join(f"{c} ({fmt_int(n)})" for c, n in top3)
    section("Chroms", f"{n_chroms} total — top: {top3_str}")

    # Sparkline bar + labels underneath, spaced to align
    if bar:
        bar_chars = list(bar)
        spaced_bar = ""
        spaced_labels = ""
        for i, (ch, label) in enumerate(zip(bar_chars, labels)):
            w = max(len(label), 1)
            if i < len(labels) - 1:
                spaced_bar += ch + " " * w
                spaced_labels += f"{label:<{w + 1}}"
            else:
                spaced_bar += ch
                spaced_labels += label
        print(f"          {Style.CYAN}{spaced_bar}{Style.RESET}")
        print(f"          {Style.DIM}{spaced_labels}{Style.RESET}")

    # Strand distribution
    if strand_counts:
        # Check if all unstranded
        total_stranded = strand_counts.get("+", 0) + strand_counts.get("-", 0)
        total_unstranded = strand_counts.get(".", 0)

        if total_stranded == 0 and total_unstranded > 0:
            section("Strands", "unstranded")
        else:
            strand_parts = []
            for s in ("+", "-"):
                if s in strand_counts:
                    strand_parts.append(f"{fmt_int(strand_counts[s])} ({s})")
            if strand_counts.get(".", 0) > 0:
                strand_parts.append(f"{fmt_int(strand_counts['.'])} (unstranded)")
            if strand_parts:
                section("Strands", "  ".join(strand_parts))

    # ── QC warnings ──────────────────────────────────────────────────
    warns = []

    # Zero-width intervals
    if widths:
        n_zero = sum(1 for w in widths if w == 0)
        if n_zero > 0:
            pct = n_zero / len(widths) * 100
            warns.append(f"{fmt_int(n_zero)} zero-width intervals ({pct:.1f}%) — start == end")

    # Negative-width intervals (end < start)
    if widths:
        n_neg = sum(1 for w in widths if w < 0)
        if n_neg > 0:
            warns.append(f"{fmt_int(n_neg)} intervals have end < start — malformed coordinates")

    # Very wide intervals (possible whole-chromosome entries)
    if widths and n_peaks > 10:
        n_wide = sum(1 for w in widths if w > 1_000_000)
        if n_wide > 0:
            wide_pct = n_wide / len(widths) * 100
            if wide_pct > 10:
                warns.append(f"{wide_pct:.0f}% intervals wider than 1 Mb — possible whole-chromosome entries")

    # Heavy strand imbalance (for stranded data)
    if strand_counts:
        plus_n = strand_counts.get("+", 0)
        minus_n = strand_counts.get("-", 0)
        total_stranded = plus_n + minus_n
        if total_stranded > 100:
            ratio = min(plus_n, minus_n) / max(plus_n, minus_n) if max(plus_n, minus_n) > 0 else 1
            if ratio < 0.1:
                warns.append(f"Heavy strand bias — {fmt_int(plus_n)}(+) vs {fmt_int(minus_n)}(-)")

    if warns:
        print()
        for w in warns:
            qc_warn(w)

# Register for all BED variants
register(FormatType.BED, peek_bed)
register(FormatType.NARROWPEAK, lambda p, c, o: peek_bed(p, c, {**o, "format_type": FormatType.NARROWPEAK}))
register(FormatType.BROADPEAK, lambda p, c, o: peek_bed(p, c, {**o, "format_type": FormatType.BROADPEAK}))
register(FormatType.BEDGRAPH, lambda p, c, o: peek_bed(p, c, {**o, "format_type": FormatType.BEDGRAPH}))
