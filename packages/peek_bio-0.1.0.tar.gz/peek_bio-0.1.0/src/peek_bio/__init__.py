"""peek-bio: Universal file preview for genomics data."""

__version__ = "0.1.0"
