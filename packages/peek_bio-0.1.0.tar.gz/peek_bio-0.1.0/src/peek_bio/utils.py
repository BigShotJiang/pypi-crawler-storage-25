"""Utility functions: gzip detection, number formatting, line counting."""

import gzip
import os


def fmt_int(n):
    """Format integer with commas: 43217 → '43,217'."""
    return f"{n:,}"


def fmt_float(x, precision=2):
    """Format float sensibly: small values in scientific notation."""
    if x == 0:
        return "0"
    abs_x = abs(x)
    if abs_x < 0.001 or abs_x >= 1e6:
        return f"{x:.{precision}e}"
    return f"{x:.{precision}f}"


def open_maybe_gzip(path, is_compressed=False, mode="r"):
    """Open a file, transparently handling gzip.

    Returns a context manager (file handle).
    """
    if is_compressed:
        return gzip.open(path, "rt", encoding="utf-8", errors="replace")
    return open(path, mode, encoding="utf-8", errors="replace")


def count_lines(path, is_compressed=False):
    """Count lines in a text file efficiently.

    For large files, reads in 64KB chunks for speed.
    """
    count = 0
    if is_compressed:
        with gzip.open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                count += chunk.count(b"\n")
    else:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                count += chunk.count(b"\n")
    return count


def file_size_str(path):
    """Human-readable file size."""
    size = os.path.getsize(path)
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    elif size < 1024 * 1024 * 1024:
        return f"{size / (1024 * 1024):.1f} MB"
    else:
        return f"{size / (1024 * 1024 * 1024):.1f} GB"


def head_and_tail(path, is_compressed=False, n_head=5, n_tail=0):
    """Read first n_head and last n_tail lines from a text file.

    Returns (head_lines, tail_lines, total_lines).
    For small files, just reads everything.
    """
    lines = []
    with open_maybe_gzip(path, is_compressed) as f:
        for line in f:
            lines.append(line.rstrip("\n\r"))

    total = len(lines)
    head = lines[:n_head]
    tail = lines[-n_tail:] if n_tail and total > n_head + n_tail else []

    return head, tail, total


def smart_type(values):
    """Infer column type from a list of string values.

    Returns one of: 'int', 'float', 'str'
    """
    int_count = 0
    float_count = 0
    str_count = 0

    for v in values:
        v = v.strip()
        if not v or v in ("NA", "NaN", "nan", "null", "None", ".", ""):
            continue
        try:
            int(v)
            int_count += 1
            continue
        except ValueError:
            pass
        try:
            float(v)
            float_count += 1
            continue
        except ValueError:
            pass
        str_count += 1

    if str_count > 0:
        return "str"
    if float_count > 0:
        return "float"
    if int_count > 0:
        return "int"
    return "str"


def summarize_column(values, dtype):
    """Generate a brief summary of column values.

    Returns a summary string like: '1.2e-45 … 0.98  (mean: 0.31)'
    or: 'TP53, PTEN, EGFR  (1,432 unique)'
    """
    clean = [v.strip() for v in values if v.strip() and v.strip() not in ("NA", "NaN", "nan", "null", "None", ".")]

    if not clean:
        return "all missing"

    if dtype == "int":
        nums = [int(v) for v in clean]
        nums_s = sorted(nums)
        if nums_s[0] == nums_s[-1]:
            return f"{fmt_int(nums_s[0])} (all equal)"
        if len(set(nums)) <= 10:
            unique = sorted(set(nums))
            return f"{', '.join(str(u) for u in unique)}  ({len(set(nums))} unique)"
        median = nums_s[len(nums_s) // 2]
        mean = int(sum(nums) / len(nums))
        spark = sparkline(nums, bins=12)
        spark_str = f"  {_spark_color()}{spark}{_spark_reset()}" if spark else ""
        return f"{fmt_int(nums_s[0])} … {fmt_int(nums_s[-1])}  (median: {fmt_int(median)}, mean: {fmt_int(mean)}){spark_str}"

    if dtype == "float":
        nums = [float(v) for v in clean]
        nums_s = sorted(nums)
        if nums_s[0] == nums_s[-1]:
            return f"{fmt_float(nums_s[0])} (all equal)"
        median = nums_s[len(nums_s) // 2]
        mean = sum(nums) / len(nums)
        spark = sparkline(nums, bins=12)
        spark_str = f"  {_spark_color()}{spark}{_spark_reset()}" if spark else ""
        return f"{fmt_float(nums_s[0])} … {fmt_float(nums_s[-1])}  (median: {fmt_float(median)}, mean: {fmt_float(mean)}){spark_str}"

    # String type
    unique = list(dict.fromkeys(clean))  # preserve order, deduplicate
    n_unique = len(unique)
    # Truncate long values so column summaries don't wrap
    trunc = [v[:30] + "…" if len(v) > 30 else v for v in unique]
    if n_unique <= 6:
        return f"{', '.join(trunc[:6])}  ({n_unique} unique)"
    return f"{', '.join(trunc[:3])}, ...  ({fmt_int(n_unique)} unique)"


# ── Sparkline histograms ──────────────────────────────────────────────


def _spark_color():
    """Get ANSI cyan for sparklines (lazy import to avoid circular dep)."""
    from peek_bio.display import Style
    return Style.CYAN


def _spark_reset():
    """Get ANSI reset."""
    from peek_bio.display import Style
    return Style.RESET


_SPARK_CHARS = " ⡀⡄⡆⡇"


def sparkline(values, bins=20):
    """Generate a Unicode sparkline histogram from numeric values.

    Returns a string like: ▁▄▇█▇▄▁
    Uses 4 height levels (▁▄▇█) that render cleanly across terminal fonts.
    Adapts bin count to data size so small datasets don't look sparse.
    """
    if not values:
        return ""

    lo = min(values)
    hi = max(values)

    if lo == hi:
        return ""  # constant values don't need a histogram

    # Adapt bins to data size — need enough values per bin to avoid
    # sparse histograms where empty bins create confusing gaps
    n = len(values)
    # Target: at least ~2 values per bin on average
    max_useful_bins = max(n // 2, 3)
    bins = min(bins, max_useful_bins)

    # Bin the values
    bin_width = (hi - lo) / bins
    counts = [0] * bins
    for v in values:
        idx = int((v - lo) / bin_width)
        idx = min(idx, bins - 1)
        counts[idx] += 1

    # Trim leading/trailing empty bins
    while counts and counts[0] == 0:
        counts.pop(0)
    while counts and counts[-1] == 0:
        counts.pop()

    if not counts:
        return ""

    # Scale to spark characters (4 levels: ▁▄▇█)
    # Empty bins (0 count) are omitted — they just mean "no data here"
    max_count = max(counts)
    if max_count == 0:
        return ""

    n_levels = len(_SPARK_CHARS) - 1  # exclude space
    chars = []
    for c in counts:
        if c == 0:
            continue  # skip empty bins — no data to show
        level = int(c / max_count * (n_levels - 1)) + 1
        level = min(level, n_levels)
        chars.append(_SPARK_CHARS[level])

    return "".join(chars)


def sparkbar(counts):
    """Generate a sparkline from pre-binned counts (e.g., per-chromosome).

    counts: list of ints (already binned, one per category)
    Returns a string like: ▇▅▄▃▃▅▄▃▂▂▃

    Uses proportional scaling: when values are tightly clustered,
    bars look similar (reflecting reality). When spread wide, bars
    vary dramatically.
    """
    if not counts:
        return ""

    max_count = max(counts)
    if max_count == 0:
        return ""

    # Find min of nonzero values for range calculation
    nonzero = [c for c in counts if c > 0]
    min_nonzero = min(nonzero) if nonzero else 0

    n_levels = len(_SPARK_CHARS) - 1  # exclude space
    chars = []
    for c in counts:
        if c == 0:
            chars.append(_SPARK_CHARS[1])
        else:
            if max_count == min_nonzero:
                level = n_levels - 1  # all equal — near-max height
            else:
                frac = (c - min_nonzero) / (max_count - min_nonzero)
                level = int(frac * (n_levels - 2)) + 2  # range 2..n_levels
                level = min(level, n_levels)
            chars.append(_SPARK_CHARS[level])

    return "".join(chars)
