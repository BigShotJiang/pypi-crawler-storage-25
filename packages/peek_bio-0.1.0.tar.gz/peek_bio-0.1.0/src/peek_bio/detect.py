"""Format detection from file extension and magic bytes."""

import os
from enum import Enum, auto


class FormatType(Enum):
    CSV = auto()
    TSV = auto()
    BED = auto()
    NARROWPEAK = auto()
    BROADPEAK = auto()
    BEDGRAPH = auto()
    EXCEL = auto()
    H5AD = auto()
    BIGWIG = auto()
    GTF = auto()
    GFF = auto()
    FASTA = auto()
    FASTQ = auto()
    VCF = auto()
    SAM = auto()
    BAM = auto()
    CRAM = auto()
    UNKNOWN = auto()


# Extension → FormatType mapping (after stripping .gz/.bz2)
_EXT_MAP = {
    ".csv": FormatType.CSV,
    ".tsv": FormatType.TSV,
    ".bed": FormatType.BED,
    ".narrowpeak": FormatType.NARROWPEAK,
    ".broadpeak": FormatType.BROADPEAK,
    ".bedgraph": FormatType.BEDGRAPH,
    ".xlsx": FormatType.EXCEL,
    ".xls": FormatType.EXCEL,
    ".h5ad": FormatType.H5AD,
    ".bw": FormatType.BIGWIG,
    ".bigwig": FormatType.BIGWIG,
    ".gtf": FormatType.GTF,
    ".gff": FormatType.GFF,
    ".gff3": FormatType.GFF,
    ".fa": FormatType.FASTA,
    ".fasta": FormatType.FASTA,
    ".fq": FormatType.FASTQ,
    ".fastq": FormatType.FASTQ,
    ".vcf": FormatType.VCF,
    ".sam": FormatType.SAM,
    ".bam": FormatType.BAM,
    ".cram": FormatType.CRAM,
}

# Index / auxiliary files that we recognize but don't preview
_INDEX_EXTS = {
    ".bai", ".csi",   # BAM/CRAM indexes
    ".tbi",           # tabix index (VCF, BED, etc.)
    ".fai",           # FASTA index
    ".idx",           # generic index
    ".gzi",           # bgzip index
}

# Formats that support gzip/bz2 transparent decompression
_COMPRESSIBLE = {
    FormatType.CSV, FormatType.TSV, FormatType.BED,
    FormatType.NARROWPEAK, FormatType.BROADPEAK, FormatType.BEDGRAPH,
    FormatType.GTF, FormatType.GFF, FormatType.FASTA, FormatType.FASTQ,
    FormatType.VCF,
}

# Excel magic bytes (ZIP header for .xlsx, OLE for .xls)
_XLSX_MAGIC = b"PK\x03\x04"
_XLS_MAGIC = b"\xd0\xcf\x11\xe0"
# HDF5 magic (for .h5ad)
_HDF5_MAGIC = b"\x89HDF\r\n\x1a\n"
# BigWig magic
_BIGWIG_MAGIC_LE = b"\x26\xfc\x8f\x88"
_BIGWIG_MAGIC_BE = b"\x88\x8f\xfc\x26"
# BAM/CRAM magic
_BAM_MAGIC = b"BAM\x01"
_CRAM_MAGIC = b"CRAM"
# Gzip magic
_GZIP_MAGIC = b"\x1f\x8b"


def _strip_compression(filename):
    """Strip .gz or .bz2 from filename, return (inner_name, is_compressed)."""
    lower = filename.lower()
    if lower.endswith(".gz"):
        return filename[:-3], True
    if lower.endswith(".bz2"):
        return filename[:-4], True
    return filename, False


def _sniff_bed_variant(path, is_compressed):
    """Sniff first non-comment lines to detect BED subformat for .bed extension."""
    import gzip

    opener = gzip.open if is_compressed else open
    mode = "rt" if is_compressed else "r"
    try:
        with opener(path, mode) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("track") or line.startswith("browser"):
                    continue
                cols = line.split("\t")
                ncols = len(cols)
                if ncols >= 10:
                    # narrowPeak has 10 cols, last is peak offset
                    # broadPeak has 9 cols
                    # Check if col 5 (score) looks numeric and col 7+ look like floats
                    try:
                        float(cols[6])  # signalValue
                        float(cols[7])  # pValue
                        if ncols == 10:
                            return FormatType.NARROWPEAK
                        elif ncols == 9:
                            return FormatType.BROADPEAK
                    except (ValueError, IndexError):
                        pass
                return FormatType.BED
    except Exception:
        return FormatType.BED
    return FormatType.BED


def _sniff_delimited(path, is_compressed):
    """For .txt files or unknown extensions, try to detect CSV vs TSV vs BED."""
    import gzip

    opener = gzip.open if is_compressed else open
    mode = "rt" if is_compressed else "r"
    try:
        with opener(path, mode) as f:
            lines = []
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                lines.append(line)
                if len(lines) >= 10:
                    break

            if not lines:
                return FormatType.UNKNOWN

            # Check for BED-like pattern: chr\t\d+\t\d+
            bed_count = 0
            for line in lines:
                cols = line.split("\t")
                if len(cols) >= 3:
                    try:
                        int(cols[1])
                        int(cols[2])
                        if cols[0].startswith("chr") or cols[0].isdigit() or cols[0] in ("X", "Y", "MT"):
                            bed_count += 1
                    except ValueError:
                        pass

            if bed_count >= len(lines) * 0.8:
                return FormatType.BED

            # Count delimiters
            tab_counts = [line.count("\t") for line in lines]
            comma_counts = [line.count(",") for line in lines]

            avg_tabs = sum(tab_counts) / len(tab_counts)
            avg_commas = sum(comma_counts) / len(comma_counts)

            if avg_tabs > 0 and avg_tabs >= avg_commas:
                return FormatType.TSV
            if avg_commas > 0:
                return FormatType.CSV

            return FormatType.TSV  # default for tab-like
    except Exception:
        return FormatType.UNKNOWN


def detect_format(path):
    """Detect file format. Returns (FormatType, is_compressed)."""
    basename = os.path.basename(path)
    inner_name, is_compressed = _strip_compression(basename)

    # Try extension-based detection
    _, ext = os.path.splitext(inner_name.lower())

    # Skip index / auxiliary files (e.g. .bai, .tbi, .fai)
    if ext in _INDEX_EXTS:
        return FormatType.UNKNOWN, is_compressed
    # Also catch compound index extensions like .bam.bai
    if basename.lower().endswith((".bam.bai", ".cram.crai")):
        return FormatType.UNKNOWN, is_compressed

    if ext in _EXT_MAP:
        fmt = _EXT_MAP[ext]
        # For .bed files, sniff to detect narrowPeak/broadPeak
        if fmt == FormatType.BED:
            fmt = _sniff_bed_variant(path, is_compressed)
        return fmt, is_compressed

    # For .txt or unknown extension, try magic bytes first
    if os.path.exists(path):
        try:
            with open(path, "rb") as f:
                header = f.read(8)
            if header[:4] == _XLSX_MAGIC:
                return FormatType.EXCEL, False
            if header[:4] == _XLS_MAGIC:
                return FormatType.EXCEL, False
            if header[:8] == _HDF5_MAGIC:
                return FormatType.H5AD, False
            if header[:4] in (_BIGWIG_MAGIC_LE, _BIGWIG_MAGIC_BE):
                return FormatType.BIGWIG, False
            if header[:4] == _CRAM_MAGIC:
                return FormatType.CRAM, False
            # BAM files are bgzf-compressed — check for gzip magic then
            # decompress first block to look for BAM\1 signature
            if header[:2] == _GZIP_MAGIC:
                try:
                    import gzip
                    with gzip.open(path, "rb") as gz:
                        inner = gz.read(4)
                    if inner == _BAM_MAGIC:
                        return FormatType.BAM, False
                except Exception:
                    pass
                if is_compressed:
                    pass  # Already handled by extension stripping
        except Exception:
            pass

        # Sniff content for delimited / BED
        if ext in (".txt", ""):
            return _sniff_delimited(path, is_compressed), is_compressed

    return FormatType.UNKNOWN, is_compressed


def format_label(fmt):
    """Human-readable label for a format type."""
    labels = {
        FormatType.CSV: "CSV",
        FormatType.TSV: "TSV",
        FormatType.BED: "BED",
        FormatType.NARROWPEAK: "narrowPeak",
        FormatType.BROADPEAK: "broadPeak",
        FormatType.BEDGRAPH: "bedGraph",
        FormatType.EXCEL: "Excel",
        FormatType.H5AD: "H5AD",
        FormatType.BIGWIG: "BigWig",
        FormatType.GTF: "GTF",
        FormatType.GFF: "GFF",
        FormatType.FASTA: "FASTA",
        FormatType.FASTQ: "FASTQ",
        FormatType.VCF: "VCF",
        FormatType.SAM: "SAM",
        FormatType.BAM: "BAM",
        FormatType.CRAM: "CRAM",
        FormatType.UNKNOWN: "Unknown",
    }
    return labels.get(fmt, "Unknown")
