"""Allow running as `python -m peek_bio`."""
from peek_bio.cli import main

main()
