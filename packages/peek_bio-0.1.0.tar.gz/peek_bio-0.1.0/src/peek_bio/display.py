"""ANSI terminal output formatting."""

import os
import sys


def _is_color_enabled():
    """Check if color output should be used."""
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty()


_COLOR = _is_color_enabled()


class Style:
    """ANSI escape codes for terminal styling."""
    BOLD = "\033[1m" if _COLOR else ""
    DIM = "\033[2m" if _COLOR else ""
    RESET = "\033[0m" if _COLOR else ""
    CYAN = "\033[36m" if _COLOR else ""
    GREEN = "\033[32m" if _COLOR else ""
    YELLOW = "\033[33m" if _COLOR else ""
    MAGENTA = "\033[35m" if _COLOR else ""
    WHITE = "\033[37m" if _COLOR else ""
    BLUE = "\033[34m" if _COLOR else ""


def set_color(enabled):
    """Override color detection (for --no-color flag)."""
    global _COLOR
    _COLOR = enabled
    # Rebuild style constants
    for attr in ("BOLD", "DIM", "CYAN", "GREEN", "YELLOW", "MAGENTA", "WHITE", "BLUE"):
        setattr(Style, attr, f"\033[{_CODE_MAP[attr]}m" if enabled else "")
    Style.RESET = "\033[0m" if enabled else ""


_CODE_MAP = {
    "BOLD": "1", "DIM": "2", "CYAN": "36", "GREEN": "32",
    "YELLOW": "33", "MAGENTA": "35", "WHITE": "37", "BLUE": "34",
}


def terminal_width():
    """Get terminal width, defaulting to 80."""
    try:
        return os.get_terminal_size().columns
    except (AttributeError, ValueError, OSError):
        # Fallback: check COLUMNS env var, then default to 80
        try:
            return int(os.environ.get("COLUMNS", 80))
        except (TypeError, ValueError):
            return 80


def header_line(filename, summary, detail=None):
    """Print the header: filename — summary.

    Example: peaks.narrowPeak — 43,217 peaks (narrowPeak format, sorted)
    """
    parts = [
        f" {Style.BOLD}{Style.CYAN}{filename}{Style.RESET}",
        f" {Style.DIM}—{Style.RESET} ",
        summary,
    ]
    if detail:
        parts.append(f" {Style.DIM}({detail}){Style.RESET}")
    print("".join(parts))


def separator():
    """Print a horizontal rule."""
    width = min(terminal_width(), 72)
    print(f" {Style.DIM}{'─' * width}{Style.RESET}")


def section(label, value):
    """Print a labeled section line.

    Example:  Width:   min 150  median 487  mean 512  max 8,241
    """
    print(f" {Style.BOLD}{label}:{Style.RESET}  {value}")


def kvline(key, value, indent=1):
    """Print a key-value line with indent."""
    pad = "  " * indent
    print(f"{pad}{Style.DIM}{key}{Style.RESET}  {value}")


def columns_section(col_infos):
    """Print column info for tabular data.

    col_infos: list of (name, dtype_str, summary_str)
    """
    if not col_infos:
        return
    # Align column names
    max_name = max(len(c[0]) for c in col_infos)
    max_dtype = max(len(c[1]) for c in col_infos)

    print(f" {Style.BOLD}Columns:{Style.RESET}")
    for name, dtype, summary in col_infos:
        print(
            f"   {Style.GREEN}{name:<{max_name}}{Style.RESET}"
            f"  {Style.DIM}{dtype:<{max_dtype}}{Style.RESET}"
            f"  {summary}"
        )


def table(headers, rows, max_rows=None):
    """Print a simple aligned table.

    headers: list of str
    rows: list of list of str

    Automatically truncates columns to fit terminal width.
    """
    if max_rows and len(rows) > max_rows:
        display_rows = rows[:max_rows]
        truncated = len(rows) - max_rows
    else:
        display_rows = rows
        truncated = 0

    # Calculate column widths, capping individual columns at 30 chars
    max_cell = 30
    all_rows = [headers] + display_rows
    widths = [0] * len(headers)
    for row in all_rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], min(len(str(cell)), max_cell))

    # Determine how many columns fit in the terminal
    term_w = terminal_width()
    margin = 3  # left indent
    col_gap = 3  # space between columns
    n_show = len(headers)
    dropped = 0

    # Progressively drop rightmost columns until it fits
    while n_show > 1:
        total_w = margin + sum(widths[:n_show]) + col_gap * (n_show - 1)
        if total_w <= term_w:
            break
        n_show -= 1
        dropped = len(headers) - n_show

    # Helper to truncate a cell string to fit its column width
    def _trunc(s, w):
        s = str(s)
        if len(s) <= w:
            return f"{s:<{w}}"
        return f"{s[:w - 1]}…"

    # Print header
    hdr_parts = [
        f"{Style.BOLD}{_trunc(h, widths[i])}{Style.RESET}"
        for i, h in enumerate(headers[:n_show])
    ]
    if dropped:
        hdr_parts.append(f"{Style.DIM}... +{dropped} cols{Style.RESET}")
    print(f"   {'   '.join(hdr_parts)}")

    # Print rows
    for row in display_rows:
        cells = [
            _trunc(cell, widths[i])
            for i, cell in enumerate(row[:n_show])
        ]
        print(f"   {'   '.join(cells)}")

    if truncated:
        print(f"   {Style.DIM}... ({truncated:,} more rows){Style.RESET}")


def warning(msg):
    """Print a warning message (for errors like missing dependencies)."""
    print(f" {Style.YELLOW}!{Style.RESET} {msg}")


def qc_warn(msg):
    """Print a QC warning — only shown when something looks off."""
    print(f" {Style.YELLOW}⚠ {msg}{Style.RESET}")


def error(msg):
    """Print an error message."""
    print(f" {Style.YELLOW}Error:{Style.RESET} {msg}", file=sys.stderr)
