"""CLI entry point for peek."""

import argparse
import os
import sys

from peek_bio import __version__
from peek_bio.detect import FormatType, detect_format, format_label
from peek_bio.display import Style, error, set_color
from peek_bio.formats import get_handler


def _supported_formats():
    """List all supported formats and their install status."""
    from peek_bio.display import separator

    print(f" {Style.BOLD}peek-bio{Style.RESET} v{__version__} — supported formats:\n")

    # Core (always available)
    core = [
        ("CSV/TSV", ".csv, .tsv, .txt", "built-in"),
        ("BED", ".bed, .narrowPeak, .broadPeak, .bedGraph", "built-in"),
        ("FASTA", ".fa, .fasta", "built-in"),
        ("GTF/GFF", ".gtf, .gff, .gff3", "built-in"),
        ("VCF", ".vcf, .vcf.gz", "built-in"),
        ("FASTQ", ".fq, .fastq", "built-in"),
    ]

    # Optional
    optional = []

    try:
        import openpyxl  # noqa: F401
        optional.append(("Excel", ".xlsx, .xls", f"{Style.GREEN}installed{Style.RESET}"))
    except ImportError:
        optional.append(("Excel", ".xlsx, .xls", f"{Style.YELLOW}pip install peek-bio[excel]{Style.RESET}"))

    try:
        import anndata  # noqa: F401
        optional.append(("H5AD", ".h5ad", f"{Style.GREEN}installed{Style.RESET}"))
    except ImportError:
        optional.append(("H5AD", ".h5ad", f"{Style.YELLOW}pip install peek-bio[h5ad]{Style.RESET}"))

    try:
        import pyBigWig  # noqa: F401
        optional.append(("BigWig", ".bw, .bigwig", f"{Style.GREEN}installed{Style.RESET}"))
    except ImportError:
        optional.append(("BigWig", ".bw, .bigwig", f"{Style.YELLOW}pip install peek-bio[bigwig]{Style.RESET}"))

    try:
        import pysam  # noqa: F401
        optional.append(("SAM/BAM", ".sam, .bam, .cram", f"{Style.GREEN}installed{Style.RESET}"))
    except ImportError:
        optional.append(("SAM/BAM", ".sam, .bam, .cram", f"{Style.YELLOW}pip install peek-bio[bam]{Style.RESET}"))

    # Print
    max_name = max(len(f[0]) for f in core + optional)
    max_ext = max(len(f[1]) for f in core + optional)

    for name, ext, status in core:
        print(f"   {Style.BOLD}{name:<{max_name}}{Style.RESET}  {Style.DIM}{ext:<{max_ext}}{Style.RESET}  {status}")
    print()
    for name, ext, status in optional:
        print(f"   {Style.BOLD}{name:<{max_name}}{Style.RESET}  {Style.DIM}{ext:<{max_ext}}{Style.RESET}  {status}")

    # Coming soon (placeholder for future formats)
    # print(f"\n {Style.DIM}Coming soon: ...{Style.RESET}")


def _peek_one(path, opts):
    """Preview a single file."""
    if not os.path.exists(path):
        error(f"file not found: {path}")
        return False

    if os.path.isdir(path):
        error(f"is a directory: {path}")
        return False

    # Skip index / auxiliary files with a friendly message
    lower = os.path.basename(path).lower()
    _index_labels = {
        ".bai": "BAM index", ".csi": "CSI index", ".tbi": "tabix index",
        ".fai": "FASTA index", ".idx": "index", ".gzi": "bgzip index",
    }
    for iext, ilabel in _index_labels.items():
        if lower.endswith(iext):
            # Silently skip — these are companion files, not data
            return True

    fmt, is_compressed = detect_format(path)

    if fmt == FormatType.UNKNOWN:
        error(f"unrecognized format: {path}")
        return False

    handler = get_handler(fmt)
    if handler is None:
        # Format recognized but handler not available (missing optional dep)
        label = format_label(fmt)
        error(f"{label} format detected but handler not available")
        dep_hints = {
            FormatType.EXCEL: "pip install peek-bio[excel]",
            FormatType.H5AD: "pip install peek-bio[h5ad]",
            FormatType.BIGWIG: "pip install peek-bio[bigwig]",
            FormatType.SAM: "pip install peek-bio[bam]",
            FormatType.BAM: "pip install peek-bio[bam]",
            FormatType.CRAM: "pip install peek-bio[bam]",
        }
        hint = dep_hints.get(fmt)
        if hint:
            print(f"   Run: {hint}", file=sys.stderr)
        return False

    try:
        handler(path, is_compressed, opts)
    except Exception as exc:
        error(f"failed to read {path}: {exc}")
        return False

    return True


def main(argv=None):
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="peek",
        description="Universal file preview for genomics data",
    )
    parser.add_argument(
        "files",
        nargs="*",
        help="file(s) to preview",
    )
    parser.add_argument(
        "--head", "-n",
        type=int,
        default=5,
        help="number of preview rows to show (default: 5)",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="disable colored output",
    )
    parser.add_argument(
        "--formats",
        action="store_true",
        help="list supported file formats",
    )
    parser.add_argument(
        "--version", "-v",
        action="version",
        version=f"peek-bio {__version__}",
    )

    args = parser.parse_args(argv)

    if args.no_color:
        set_color(False)

    if args.formats:
        _supported_formats()
        return

    if not args.files:
        parser.print_help()
        sys.exit(1)

    opts = {
        "head": args.head,
    }
    success = True

    for i, path in enumerate(args.files):
        if i > 0:
            print()  # Blank line between files
        if not _peek_one(path, opts):
            success = False

    if not success:
        sys.exit(1)


if __name__ == "__main__":
    main()
