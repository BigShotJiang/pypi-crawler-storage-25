"""Keenetic Router MCP Server."""

import asyncio
import hashlib
import os
import re
import time
from typing import Any

import httpx
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("keenetic")

# ─── Configuration ────────────────────────────────────────────────────────────

# None = not explicitly set (fall back to env var); True/False = explicit override
_config: dict[str, bool | None] = {"safe_mode": None}


def configure(*, safe_mode: bool | None = None) -> None:
    """Configure the MCP server programmatically.

    Explicit values set here take priority over environment variables.

    Args:
        safe_mode: If True, all write operations (reboot, interface changes) are
                   disabled. If None (default), defers to KEENETIC_SAFE_MODE env var.
    """
    _config["safe_mode"] = safe_mode


# ─── Keenetic HTTP client ─────────────────────────────────────────────────────

class KeeneticClient:
    """Async context manager that authenticates and wraps the Keenetic RCI API."""

    def __init__(self, host: str, user: str, password: str) -> None:
        self._host = host
        self._user = user
        self._password = password
        self._http: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "KeeneticClient":
        self._http = httpx.AsyncClient(
            base_url=f"http://{self._host}",
            timeout=15.0,
        )
        await self._auth()
        return self

    async def __aexit__(self, *_: Any) -> None:
        if self._http is not None:
            await self._http.aclose()

    async def _auth(self) -> None:
        """Perform Keenetic challenge-response authentication."""
        assert self._http is not None
        resp = await self._http.get("/auth")
        if resp.status_code == 200:
            return  # session already valid
        # 401 — server sends realm and challenge
        realm = resp.headers.get("X-NDM-Realm", "")
        challenge = resp.headers.get("X-NDM-Challenge", "")
        md5 = hashlib.md5(
            f"{self._user}:{realm}:{self._password}".encode()
        ).hexdigest()
        sha256 = hashlib.sha256(
            f"{challenge}{md5}".encode()
        ).hexdigest()
        auth_resp = await self._http.post(
            "/auth", json={"login": self._user, "password": sha256}
        )
        auth_resp.raise_for_status()

    async def rci(self, payload: dict | list) -> Any:
        """Send an RCI command (POST /rci/) and return the response.

        Accepts a single command dict or a batch list of commands.
        """
        assert self._http is not None
        resp = await self._http.post("/rci/", json=payload)
        resp.raise_for_status()
        return resp.json()

    async def rci_get(self, path: str) -> Any:
        """Send a single RCI GET query (GET /rci/<path>)."""
        assert self._http is not None
        resp = await self._http.get(f"/rci/{path}")
        resp.raise_for_status()
        return resp.json()


# ─── Credential helpers ───────────────────────────────────────────────────────

def _get_client() -> KeeneticClient:
    # M1: read credentials lazily — picks up rotations, avoids globals in memory
    host = os.environ.get("KEENETIC_HOST", "")
    user = os.environ.get("KEENETIC_USER", "admin")
    password = os.environ.get("KEENETIC_PASS", "")
    if not host:
        raise RuntimeError(
            "KEENETIC_HOST environment variable is not set. "
            "Example: KEENETIC_HOST=192.168.1.1"
        )
    if not password:
        raise RuntimeError(
            "KEENETIC_PASS environment variable is not set."
        )
    return KeeneticClient(host=host, user=user, password=password)


def _assert_writable() -> None:
    """Raise PermissionError when running in safe mode.

    Priority: configure(safe_mode=...) > --safe-mode CLI flag > KEENETIC_SAFE_MODE env var.
    """
    explicit = _config["safe_mode"]
    if explicit is not None:
        safe = explicit
    else:
        safe = os.environ.get("KEENETIC_SAFE_MODE", "").lower() in ("1", "true", "yes")
    if safe:
        raise PermissionError(
            "The server is running in safe mode. Write operations are not allowed."
        )


def _sanitize_error(e: Exception) -> str:
    """Return error message with passwords and tokens redacted."""
    # M2: strip KEENETIC_PASS / password= / token= patterns
    msg = str(e)
    msg = re.sub(
        r'(?i)(password|token|pass)[=:\s]+\S+',
        r'\1=<redacted>',
        msg,
    )
    return msg


# ─── System ───────────────────────────────────────────────────────────────────

@mcp.tool()
async def get_system_info() -> dict:
    """Get router model, firmware version, uptime and system summary."""
    async with _get_client() as client:
        data = await client.rci({"show": {"version": {}, "system": {}}})
        version = data.get("show", {}).get("version", {})
        system = data.get("show", {}).get("system", {})
        return {k: v for k, v in {
            "model": version.get("model"),
            "firmware": version.get("release"),
            "arch": version.get("arch"),
            "uptime": system.get("uptime"),
            "memory_total": system.get("memory"),
            "memory_free": system.get("memory-free"),
            "cpu_load": system.get("load"),
        }.items() if v is not None}


# ─── Interfaces ───────────────────────────────────────────────────────────────

@mcp.tool()
async def get_interfaces() -> list[dict]:
    """List all network interfaces with their state, IP address and traffic stats."""
    async with _get_client() as client:
        data = await client.rci_get("show/interface")
        # response is a dict {name: iface_obj, ...}; numeric keys are switch ports — skip
        if isinstance(data, dict):
            ifaces = [v for k, v in data.items() if isinstance(v, dict)]
        elif isinstance(data, list):
            ifaces = data
        else:
            ifaces = [data]
        return [_interface_to_dict(iface) for iface in ifaces]


@mcp.tool()
async def get_interface(name: str) -> dict:
    """Get detailed info for a single interface.

    Args:
        name: Interface name, e.g. "GigabitEthernet0/0" or "Wireguard0".
    """
    async with _get_client() as client:
        data = await client.rci_get(f"show/interface/{name}")
        return _interface_to_dict(data)


# ─── Connected clients ────────────────────────────────────────────────────────

@mcp.tool()
async def get_connected_clients() -> list[dict]:
    """List devices currently connected to the router with traffic stats (rx/tx bytes)."""
    async with _get_client() as client:
        hosts = await client.rci_get("show/ip/hotspot/host")
        if not isinstance(hosts, list):
            hosts = [hosts] if hosts else []
        return [_host_to_dict(h) for h in hosts]


@mcp.tool()
async def get_speed(interval: float = 3.0) -> dict:
    """Measure current download/upload speed by sampling all client traffic counters.

    Args:
        interval: Sampling interval in seconds (1–10). Default 3.
    """
    interval = max(1.0, min(interval, 10.0))
    async with _get_client() as client:
        hosts1 = await client.rci_get("show/ip/hotspot/host")
        t1 = time.monotonic()

        await asyncio.sleep(interval)

        hosts2 = await client.rci_get("show/ip/hotspot/host")
        t2 = time.monotonic()

    dt = t2 - t1

    def _sum_bytes(hosts: list) -> tuple[int, int]:
        rx = sum((h.get("rxbytes") or 0) for h in hosts if h.get("active"))
        tx = sum((h.get("txbytes") or 0) for h in hosts if h.get("active"))
        return rx, tx

    rx1, tx1 = _sum_bytes(hosts1)
    rx2, tx2 = _sum_bytes(hosts2)

    dl_mbps = round((rx2 - rx1) / dt * 8 / 1_000_000, 2)
    ul_mbps = round((tx2 - tx1) / dt * 8 / 1_000_000, 2)

    # top active clients by current download
    by_mac2 = {h["mac"]: h for h in hosts2 if "mac" in h}
    by_mac1 = {h["mac"]: h for h in hosts1 if "mac" in h}
    top = []
    for mac, h2 in by_mac2.items():
        if not h2.get("active"):
            continue
        h1 = by_mac1.get(mac)
        if not h1:
            continue
        d_rx = ((h2.get("rxbytes") or 0) - (h1.get("rxbytes") or 0)) / dt * 8 / 1_000_000
        d_tx = ((h2.get("txbytes") or 0) - (h1.get("txbytes") or 0)) / dt * 8 / 1_000_000
        if d_rx + d_tx > 0.01:
            name = h2.get("hostname") or h2.get("name") or mac
            top.append({"name": name, "dl_mbps": round(d_rx, 2), "ul_mbps": round(d_tx, 2)})
    top.sort(key=lambda x: x["dl_mbps"] + x["ul_mbps"], reverse=True)

    return {
        "download_mbps": dl_mbps,
        "upload_mbps": ul_mbps,
        "interval_sec": round(dt, 1),
        "top_clients": top[:10],
    }


@mcp.tool()
async def get_wifi_associations() -> list[dict]:
    """List Wi-Fi client associations with signal strength (RSSI/SNR)."""
    async with _get_client() as client:
        data = await client.rci_get("show/associations")
        stations = data if isinstance(data, list) else data.get("station", [])
        if not isinstance(stations, list):
            stations = [stations] if stations else []
        return [_station_to_dict(s) for s in stations]


# ─── Routing ──────────────────────────────────────────────────────────────────

@mcp.tool()
async def get_routes() -> list[dict]:
    """Get the current IP routing table."""
    async with _get_client() as client:
        data = await client.rci_get("show/ip/route")
        routes = data if isinstance(data, list) else data.get("route", [])
        if not isinstance(routes, list):
            routes = [routes] if routes else []
        return [_route_to_dict(r) for r in routes]


# ─── WAN / internet ───────────────────────────────────────────────────────────

# Interface types that represent WAN or VPN uplinks (not LAN/bridge/AP/port).
# GigabitEthernet is handled separately: counted as WAN only when it has an IP.
_WAN_TYPES = frozenset({"UsbQmi", "CdcEthernet", "WifiStation", "Wireguard", "PPTP", "PPPoE", "L2TP"})


def _is_wan_interface(iface: dict) -> bool:
    """Return True if the interface is an active WAN or VPN uplink."""
    if iface.get("link") != "up":
        return False
    iface_type = iface.get("type", "")
    if iface_type in _WAN_TYPES:
        return True
    # A GigabitEthernet port acting as WAN has an IP assigned directly to it
    if iface_type == "GigabitEthernet" and iface.get("address"):
        return True
    return False


@mcp.tool()
async def get_wan_status() -> dict:
    """Get internet connection status for all WAN providers."""
    async with _get_client() as client:
        data = await client.rci_get("show/internet/status")
        return data if isinstance(data, dict) else {"raw": data}


@mcp.tool()
async def get_wan_speed() -> list[dict]:
    """Get current download/upload speed per WAN/VPN interface.

    Uses the router's built-in real-time speed counters (rxspeed/txspeed from
    show/interface/stat) — returns instantly without any sampling delay.
    """
    async with _get_client() as client:
        # Step 1: identify active WAN interfaces
        ifaces_raw = await client.rci_get("show/interface")
        if isinstance(ifaces_raw, dict):
            ifaces = {k: v for k, v in ifaces_raw.items() if isinstance(v, dict)}
        elif isinstance(ifaces_raw, list):
            ifaces = {i.get("id", str(idx)): i for idx, i in enumerate(ifaces_raw) if isinstance(i, dict)}
        else:
            ifaces = {}

        wan_names = [name for name, iface in ifaces.items() if _is_wan_interface(iface)]
        if not wan_names:
            return []

        # Step 2: fetch live speed stats (rxspeed/txspeed in bytes/sec)
        data = await client.rci({"show": {"interface": {"stat": [{"name": n} for n in wan_names]}}})
        stats = data.get("show", {}).get("interface", {}).get("stat", [])
        if not isinstance(stats, list):
            stats = [stats] if stats else []

    result = []
    for name, stat in zip(wan_names, stats):
        if not isinstance(stat, dict):
            continue
        iface = ifaces.get(name, {})
        dl_mbps = round((stat.get("rxspeed") or 0) * 8 / 1_000_000, 2)
        ul_mbps = round((stat.get("txspeed") or 0) * 8 / 1_000_000, 2)
        entry: dict[str, Any] = {
            "interface": name,
            "type": iface.get("type"),
            "dl_mbps": dl_mbps,
            "ul_mbps": ul_mbps,
        }
        if iface.get("description"):
            entry["description"] = iface["description"]
        result.append(entry)
    result.sort(key=lambda x: x["dl_mbps"] + x["ul_mbps"], reverse=True)
    return result


# ─── DNS routing ──────────────────────────────────────────────────────────────

async def _fetch_fqdn_groups(client: KeeneticClient) -> dict[str, dict]:
    """Return {internal_key: obj} for all FQDN object groups."""
    data = await client.rci({"show": {"sc": {"object-group": {"fqdn": {}}}}})
    return data.get("show", {}).get("sc", {}).get("object-group", {}).get("fqdn", {})


async def _resolve_list_key(client: KeeneticClient, name: str, groups: dict | None = None) -> str:
    """Resolve display name or internal key to internal key. Raises ValueError if not found."""
    if groups is None:
        groups = await _fetch_fqdn_groups(client)
    if name in groups:
        return name
    for key, obj in groups.items():
        if isinstance(obj, dict) and obj.get("description") == name:
            return key
    available = [obj.get("description", k) for k, obj in groups.items() if isinstance(obj, dict)]
    raise ValueError(f"Domain list '{name}' not found. Available: {available}")


async def _read_list_entries(client: KeeneticClient, key: str, groups: dict | None = None) -> tuple[str, list[str]]:
    """Return (description, [address, ...]) for a domain list key."""
    if groups is None:
        groups = await _fetch_fqdn_groups(client)
    obj = groups.get(key, {})
    description = obj.get("description", key) if isinstance(obj, dict) else key
    raw = obj.get("include", []) if isinstance(obj, dict) else []
    if not isinstance(raw, list):
        raw = [raw] if raw else []
    return description, [e["address"] for e in raw if isinstance(e, dict) and e.get("address")]


async def _write_list_entries(client: KeeneticClient, key: str, description: str, entries: list[str]) -> None:
    """Replace domain list entries atomically and save config."""
    await client.rci([
        {"object-group": {"fqdn": {key: {"include": {"no": True}}}}},
        {"object-group": {"fqdn": {key: {
            "description": description,
            "include": [{"address": e} for e in entries],
        }}}},
        {"system": {"configuration": {"save": {}}}},
    ])


@mcp.tool()
async def get_domain_lists() -> list[dict]:
    """List all domain name lists with their names and entry counts."""
    async with _get_client() as client:
        groups = await _fetch_fqdn_groups(client)
        result = []
        for key, obj in groups.items():
            if not isinstance(obj, dict):
                continue
            raw = obj.get("include", [])
            if not isinstance(raw, list):
                raw = [raw] if raw else []
            result.append({
                "name": obj.get("description", key),
                "key": key,
                "count": len(raw),
            })
        return result


@mcp.tool()
async def get_domain_list(name: str) -> dict:
    """Get all entries (domains/IPs) in a domain list.

    Args:
        name: List display name (e.g. "steam") or internal key (e.g. "domain-list1").
    """
    async with _get_client() as client:
        key = await _resolve_list_key(client, name)
        description, entries = await _read_list_entries(client, key)
        return {"name": description, "key": key, "entries": entries}


@mcp.tool()
async def get_dns_routes() -> list[dict]:
    """List DNS routing rules: which domain list routes through which interface."""
    async with _get_client() as client:
        data = await client.rci({"show": {"sc": {
            "dns-proxy": {"route": {}},
            "object-group": {"fqdn": {}},
        }}})
        sc = data.get("show", {}).get("sc", {})
        routes = sc.get("dns-proxy", {}).get("route", [])
        if not isinstance(routes, list):
            routes = [routes] if routes else []
        fqdn = sc.get("object-group", {}).get("fqdn", {})
        key_to_name = {k: v.get("description", k) for k, v in fqdn.items() if isinstance(v, dict)}
        return [{k: v for k, v in {
            "index": r.get("index"),
            "list_name": key_to_name.get(r.get("group", ""), r.get("group")),
            "list_key": r.get("group"),
            "interface": r.get("interface"),
            "gateway": r.get("gateway") or None,
            "auto": r.get("auto"),
            "enabled": not r.get("disable", False),
            "comment": r.get("comment") or None,
        }.items() if v is not None} for r in routes]


@mcp.tool()
async def add_dns_route(
    list_name: str,
    interface: str,
    gateway: str = "",
    auto: bool = True,
    enabled: bool = True,
) -> dict:
    """Add a DNS routing rule (domain list → interface/gateway).

    Args:
        list_name: Domain list display name (e.g. "steam") or internal key.
        interface: Interface name, e.g. "Wireguard0" or "GigabitEthernet1".
        gateway: Optional gateway IP. Leave empty to use the interface default.
        auto: Apply route only when the interface is available. Default True.
        enabled: Whether the rule is active. Default True.
    """
    _assert_writable()
    async with _get_client() as client:
        key = await _resolve_list_key(client, list_name)
        await client.rci([
            {"dns-proxy": {"route": {
                "group": key,
                "interface": interface,
                "gateway": gateway,
                "auto": auto,
                "disable": not enabled,
            }}},
            {"system": {"configuration": {"save": {}}}},
        ])
        # read back to find the created rule's index
        routes_data = await client.rci({"show": {"sc": {"dns-proxy": {"route": {}}}}})
        routes = routes_data.get("show", {}).get("sc", {}).get("dns-proxy", {}).get("route", [])
        if not isinstance(routes, list):
            routes = [routes] if routes else []
        for r in reversed(routes):
            if r.get("group") == key and r.get("interface") == interface:
                return {"created": True, "index": r.get("index"), "list_name": list_name, "interface": interface}
        return {"created": True, "list_name": list_name, "interface": interface}


@mcp.tool()
async def delete_dns_route(index: str) -> dict:
    """Delete a DNS routing rule by its index hash.

    Use get_dns_routes() to find the index of the rule to delete.

    Args:
        index: Rule index hash from get_dns_routes().
    """
    _assert_writable()
    async with _get_client() as client:
        await client.rci([
            {"dns-proxy": {"route": {"index": index, "no": True}}},
            {"system": {"configuration": {"save": {}}}},
        ])
        return {"deleted": True, "index": index}


@mcp.tool()
async def set_domain_list(name: str, entries: list[str]) -> dict:
    """Replace all entries in a domain list (full overwrite).

    Args:
        name: List display name (e.g. "steam") or internal key.
        entries: New list of domain names or IP addresses.
    """
    _assert_writable()
    async with _get_client() as client:
        groups = await _fetch_fqdn_groups(client)
        key = await _resolve_list_key(client, name, groups)
        description, _ = await _read_list_entries(client, key, groups)
        await _write_list_entries(client, key, description, entries)
        return {"updated": description, "key": key, "count": len(entries)}


@mcp.tool()
async def add_domains(name: str, domains: list[str]) -> dict:
    """Add domains or IPs to an existing domain list (preserves existing entries).

    Args:
        name: List display name (e.g. "steam") or internal key.
        domains: Domain names or IPs to add (duplicates are ignored).
    """
    _assert_writable()
    async with _get_client() as client:
        groups = await _fetch_fqdn_groups(client)
        key = await _resolve_list_key(client, name, groups)
        description, existing = await _read_list_entries(client, key, groups)
        merged = list(dict.fromkeys(existing + [d for d in domains if d not in existing]))
        await _write_list_entries(client, key, description, merged)
        return {"updated": description, "key": key, "added": len(merged) - len(existing), "total": len(merged)}


@mcp.tool()
async def remove_domains(name: str, domains: list[str]) -> dict:
    """Remove specific domains or IPs from a domain list.

    Args:
        name: List display name (e.g. "steam") or internal key.
        domains: Domain names or IPs to remove.
    """
    _assert_writable()
    async with _get_client() as client:
        groups = await _fetch_fqdn_groups(client)
        key = await _resolve_list_key(client, name, groups)
        description, existing = await _read_list_entries(client, key, groups)
        remove_set = set(domains)
        filtered = [e for e in existing if e not in remove_set]
        await _write_list_entries(client, key, description, filtered)
        return {"updated": description, "key": key, "removed": len(existing) - len(filtered), "total": len(filtered)}


@mcp.tool()
async def create_domain_list(name: str, entries: list[str] | None = None) -> dict:
    """Create a new domain name list.

    Args:
        name: Display name for the new list.
        entries: Optional initial list of domain names or IPs.
    """
    _assert_writable()
    async with _get_client() as client:
        groups = await _fetch_fqdn_groups(client)
        # find unused key: domain-listN
        used = {k for k in groups if k.startswith("domain-list")}
        n = 0
        while f"domain-list{n}" in used:
            n += 1
        key = f"domain-list{n}"
        await client.rci([
            {"object-group": {"fqdn": {key: {
                "description": name,
                "include": [{"address": e} for e in (entries or [])],
            }}}},
            {"system": {"configuration": {"save": {}}}},
        ])
        return {"created": name, "key": key, "count": len(entries or [])}


@mcp.tool()
async def delete_domain_list(name: str) -> dict:
    """Delete a domain name list. Also removes any routing rules that use it.

    Args:
        name: List display name (e.g. "steam") or internal key.
    """
    _assert_writable()
    async with _get_client() as client:
        key = await _resolve_list_key(client, name)
        await client.rci([
            {"object-group": {"fqdn": {key: {"no": True}}}},
            {"system": {"configuration": {"save": {}}}},
        ])
        return {"deleted": name, "key": key}


# ─── Write operations ─────────────────────────────────────────────────────────

@mcp.tool()
async def set_interface_state(name: str, up: bool) -> dict:
    """Bring a network interface up or down.

    Args:
        name: Interface name, e.g. "GigabitEthernet0/1" or "Wireguard0".
        up: True to bring the interface up, False to bring it down.
    """
    _assert_writable()
    action = "up" if up else "down"
    async with _get_client() as client:
        await client.rci({"interface": {name: {action: True}}})
        return {"interface": name, "state": action}


@mcp.tool()
async def reboot() -> dict:
    """Reboot the router. The router will be unreachable for ~30–60 seconds."""
    _assert_writable()
    async with _get_client() as client:
        await client.rci({"system": {"reboot": {}}})
        return {"status": "reboot initiated"}


# ─── Response helpers ─────────────────────────────────────────────────────────

def _interface_to_dict(iface: Any) -> dict:
    if not isinstance(iface, dict):
        return {"raw": iface}
    return {k: v for k, v in {
        "id": iface.get("id"),
        "description": iface.get("description"),
        "type": iface.get("type"),
        "state": iface.get("state"),
        "link": iface.get("link"),
        "mtu": iface.get("mtu"),
        "mac": iface.get("mac"),
        "address": iface.get("address"),
        "mask": iface.get("mask"),
        "rx_bytes": iface.get("rxbytes"),
        "tx_bytes": iface.get("txbytes"),
        "rx_packets": iface.get("rxpackets"),
        "tx_packets": iface.get("txpackets"),
    }.items() if v is not None}


def _host_to_dict(host: Any) -> dict:
    if not isinstance(host, dict):
        return {"raw": host}
    return {k: v for k, v in {
        "mac": host.get("mac"),
        "ip": host.get("ip"),
        "hostname": host.get("name") or host.get("hostname"),
        "interface": host.get("interface", {}).get("name") or host.get("interface") if isinstance(host.get("interface"), dict) else host.get("interface"),
        "active": host.get("active"),
        "registered": host.get("registered"),
        "rx_bytes": host.get("rxbytes"),
        "tx_bytes": host.get("txbytes"),
        "uptime": host.get("uptime"),
    }.items() if v is not None}


def _station_to_dict(station: Any) -> dict:
    if not isinstance(station, dict):
        return {"raw": station}
    return {k: v for k, v in {
        "mac": station.get("mac"),
        "ssid": station.get("ssid"),
        "interface": station.get("ap"),
        "rssi": station.get("rssi"),
        "snr": station.get("snr"),
        "rate_tx": station.get("txrate"),
        "rate_rx": station.get("rxrate"),
        "band": station.get("band"),
    }.items() if v is not None}


def _route_to_dict(route: Any) -> dict:
    if not isinstance(route, dict):
        return {"raw": route}
    return {k: v for k, v in {
        "destination": route.get("destination"),  # CIDR e.g. "0.0.0.0/0"
        "gateway": route.get("gateway"),
        "interface": route.get("interface"),
        "metric": route.get("metric"),
        "proto": route.get("proto"),
        "flags": route.get("flags"),
    }.items() if v is not None}


# ─── Entry point ──────────────────────────────────────────────────────────────

def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description="Keenetic Router MCP Server")
    parser.add_argument(
        "--safe-mode",
        action="store_true",
        default=False,
        help="Disable all write operations: reboot, interface state changes (overrides KEENETIC_SAFE_MODE env var)",
    )
    args = parser.parse_args()
    if args.safe_mode:
        configure(safe_mode=True)
    mcp.run()


if __name__ == "__main__":
    main()
