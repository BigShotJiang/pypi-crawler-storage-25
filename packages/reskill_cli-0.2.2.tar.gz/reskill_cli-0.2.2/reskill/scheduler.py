"""Question scheduler -- chooses what to ask and when.

Current strategy (will be refined by the research pass):

  1. CONTEXT FILTER: look at live Claude transcript text and detect
     concepts that match. These are the "relevant now" pool.
  2. URGENCY RANK within the pool:
       a. overdue: concepts whose SM-2 `last + interval*86400 < now`
       b. new: concepts never answered
       c. not-due: everything else (avoided unless pool is empty)
  3. INTERLEAVE: never pick the same concept twice in a row if
     there's an alternative (interleaving > blocking for retention).
  4. FRESHNESS: never pick a question already in seen_questions
     unless all other options are exhausted.
  5. FALLBACKS (in order): git commit concepts -> cumulative cache
     -> global template bank.

SM-2 is per-concept (not per-question); rationale: questions in a
concept teach the same idea, so scheduling at concept granularity
gives room to show DIFFERENT questions of the same concept on
successive reviews (an implicit interleaving win).
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass

from . import state as state_mod
from .question import TEMPLATE_BANK, Question, detect_concepts


@dataclass(frozen=True)
class Pick:
    """A chosen question plus the reasoning the picker used.

    `source` values:
      - 'live'       -- matched the current Claude transcript
      - 'commit'     -- matched a recent git commit
      - 'due'        -- SM-2 said this concept is overdue
      - 'new'        -- concept never answered before
      - 'fallback'   -- nothing else matched; random pick
    """

    question: Question
    concept: str
    source: str


_SECONDS_PER_DAY = 86400


# Interleaving only helps across CONFUSABLE concepts (Brunmair & Richter
# 2021: the discriminative-contrast mechanism). Interleaving async with
# bash buys nothing. We group semantically-near concepts so the scheduler
# can prefer cross-cluster variety without shuffling unrelated topics.
CONFUSABLE_CLUSTERS: dict[str, set[str]] = {
    "auth-and-sessions": {"jwt", "constant_time_compare", "cors_preflight"},
    "python-iterators": {"generator_yield", "list_comprehension", "walrus"},
    "python-gotchas": {
        "mutable_default", "late_binding_closure", "is_vs_eq",
        "copy_vs_deepcopy", "dict_order",
    },
    "python-concurrency": {
        "async_def", "asyncio_taskgroup", "gil_decision", "race_condition",
    },
    "python-typing": {"typeddict", "protocol_vs_abc"},
    "python-data-model": {"slots", "dataclass_frozen"},
    "python-stdlib": {
        "pathlib_path", "datetime_tz", "subprocess_shell", "logging_lazy",
        "f_string_debug",
    },
    "scientific-python": {
        "numpy_view_copy", "numpy_broadcasting", "pandas_settingwithcopy",
        "torch_detach", "matplotlib_close",
    },
    "testing": {"pytest_fixture", "pytest_parametrize", "mock_patch_target"},
    "sql": {
        "n_plus_one", "sql_null_semantics", "window_function",
        "sql_functional_index", "explain_analyze_nested_loop",
    },
    "frontend": {
        "useeffect_deps", "react_keys", "ts_unknown_vs_any", "eq_eq_eq",
    },
    "shell-and-git": {
        "rebase_vs_merge", "set_pipefail", "find_xargs",
        "git_reset_hard_vs_revert", "git_bisect_flake",
        "shell_ifs_filename_spaces", "shell_at_vs_star_forwarding",
    },
    "web-patterns": {
        "http_status_created", "retry_jitter", "depends",
        "cache_control_user_data", "cors_wildcard_credentials",
    },
    "python-error-handling": {"try_except", "context_manager_with"},
    "caching": {"lru_cache"},
    "ops": {
        "docker_layer_cache_copy_order", "pg_pool_exhaustion_pgbouncer",
    },
}


def _cluster_of(key: str) -> str | None:
    for cluster, members in CONFUSABLE_CLUSTERS.items():
        if key in members:
            return cluster
    return None


def _is_overdue(concept_state: dict, now: float) -> bool:
    last = concept_state.get("last", 0.0)
    interval_days = concept_state.get("interval", 1)
    return (now - last) >= interval_days * _SECONDS_PER_DAY


def _concept_label_for_key(key: str) -> str:
    """Map a detect_concepts() pattern key ('lru_cache') to the semantic
    concept label Question.concept uses ('caching').

    The mapping comes from the first question in the bank for that key.
    """
    bank = TEMPLATE_BANK.get(key, [])
    return bank[0].concept if bank else key


def _bucketize(
    pattern_keys: list[str],
    state: state_mod.State,
    now: float,
) -> tuple[list[str], list[str], list[str]]:
    """Split candidate pattern keys into (overdue, new, not_yet_due).

    We look up state via the SEMANTIC concept label (Question.concept,
    how record_answer keys its SM-2 dict), not the pattern key.

    Within each bucket, concepts are ordered by the 85% rule (Wilson
    et al. 2019, Nature Communications): the user learns fastest when
    ~15% of questions are errors. Concepts with accuracy too high
    (already mastered) or too low (clearly too hard right now) are
    deprioritized within their bucket toward concepts in the sweet
    spot. Implemented as a stable sort by distance-from-15%-error,
    so the algorithm still feels deterministic to the user.
    """
    overdue: list[str] = []
    new: list[str] = []
    not_due: list[str] = []
    for key in pattern_keys:
        label = _concept_label_for_key(key)
        cs = state.concepts.get(label)
        if cs is None or cs.get("total", 0) == 0:
            new.append(key)
        elif _is_overdue(cs, now):
            overdue.append(key)
        else:
            not_due.append(key)

    def _distance_from_sweet_spot(key: str) -> float:
        label = _concept_label_for_key(key)
        cs = state.concepts.get(label, {})
        total = cs.get("total", 0)
        if total < 2:
            return 0.0  # not enough signal, keep neutral
        error_rate = 1.0 - (cs.get("correct", 0) / max(1, total))
        return abs(error_rate - 0.15)

    overdue.sort(key=_distance_from_sweet_spot)
    not_due.sort(key=_distance_from_sweet_spot)
    return overdue, new, not_due


def _fresh_questions(concept: str, seen_ids: set[str]) -> list[Question]:
    bank = TEMPLATE_BANK.get(concept, [])
    return [q for q in bank if q.id not in seen_ids]


def _pick_from_concepts(
    pattern_keys: list[str],
    seen_ids: set[str],
    avoid_concept: str | None = None,
    recent_formats: list[str] | None = None,
    excluded_concepts: set[str] | None = None,
) -> tuple[Question, str] | None:
    """Pick a fresh question from the caller-ordered pattern_keys.

    The caller (`_bucketize`) pre-orders concepts by sweet-spot
    distance (Wilson 2019 85% rule). We preserve that order so
    near-sweet-spot concepts come first. Within the resulting pool we:
      1. Push `avoid_concept` to the end (interleave).
      2. Pick the first key with fresh questions.
      3. Among that concept's fresh questions, prefer formats not in
         the last 2 served (Roediger & Karpicke 2006).
      4. Break format-mix ties by random choice so individual
         questions within a concept still rotate.
    """
    recent_set = set((recent_formats or [])[-2:])
    excluded = excluded_concepts or set()
    preferred: list[str] = []
    deprioritized: list[str] = []
    for key in pattern_keys:
        label = _concept_label_for_key(key)
        if label in excluded:
            continue
        if avoid_concept and label == avoid_concept:
            deprioritized.append(key)
        else:
            preferred.append(key)

    for key in preferred + deprioritized:
        fresh = _fresh_questions(key, seen_ids)
        if not fresh:
            continue
        novel = [q for q in fresh if q.format not in recent_set]
        pool = novel or fresh
        q = random.choice(pool)
        return q, q.concept
    return None


def choose(
    live_text: str,
    commit_text: str,
    state: state_mod.State,
    seen_ids: set[str],
    last_concept: str | None = None,
    recent_formats: list[str] | None = None,
    excluded_concepts: set[str] | None = None,
) -> Pick | None:
    """Return the next question to show, or None if nothing fits.

    Parameters
    ----------
    live_text : str
        Recent Claude transcript content.
    commit_text : str
        Concatenated recent commit diffs (optional context).
    state : state_mod.State
        User state with SM-2 per-concept data.
    seen_ids : set[str]
        Question IDs the user has already answered; we avoid these.
    last_concept : str or None
        The concept of the most recently-asked question; used to
        interleave (Rohrer & Taylor 2007).
    recent_formats : list[str] or None
        Formats from the last 2-4 served questions. We prefer a
        different format to avoid MC monotony (Roediger & Karpicke
        2006 fluency-illusion research; target 50/30/20 mix).
    """
    now = time.time()

    live_concepts = list(dict.fromkeys(detect_concepts(live_text))) if live_text else []
    commit_concepts = list(dict.fromkeys(detect_concepts(commit_text))) if commit_text else []

    def _try(keys: list[str], source: str) -> Pick | None:
        overdue, new, not_due = _bucketize(keys, state, now)
        for bucket, tag in ((overdue, "due"), (new, "new"), (not_due, source)):
            picked = _pick_from_concepts(
                bucket, seen_ids,
                avoid_concept=last_concept,
                recent_formats=recent_formats,
                excluded_concepts=excluded_concepts,
            )
            if picked:
                q, concept = picked
                return Pick(question=q, concept=concept, source=tag)
        return None

    # Tier 1: live context
    if live_concepts:
        p = _try(live_concepts, "live")
        if p:
            return p

    # Tier 2: commit context
    if commit_concepts:
        p = _try(commit_concepts, "commit")
        if p:
            return p

    # Tier 3: whole bank, SM-2 aware (no not-due fallback here)
    all_concepts = list(TEMPLATE_BANK.keys())
    overdue, new, _ = _bucketize(all_concepts, state, now)
    for bucket, tag in ((overdue, "due"), (new, "new")):
        picked = _pick_from_concepts(
            bucket, seen_ids,
            avoid_concept=last_concept,
            recent_formats=recent_formats,
            excluded_concepts=excluded_concepts,
        )
        if picked:
            q, concept = picked
            return Pick(question=q, concept=concept, source=tag)

    # Tier 4: last resort -- accept a previously-seen question.
    excluded = excluded_concepts or set()
    fallback_concepts = [
        key for key in all_concepts
        if _concept_label_for_key(key) not in excluded
    ]
    for concept in random.sample(fallback_concepts, k=len(fallback_concepts)):
        bank = TEMPLATE_BANK.get(concept, [])
        if bank:
            q = random.choice(bank)
            return Pick(
                question=q,
                concept=q.concept,
                source="fallback",
            )

    return None


def concepts_ready(
    live_text: str,
    state: state_mod.State,
    seen_ids: set[str],
) -> tuple[int, int]:
    """Quick count of (due, new) concepts relevant to the current context.

    Used by the idle card to surface "3 due, 12 new" so the user has a
    sense of what's in the queue.
    """
    now = time.time()
    concepts = list(dict.fromkeys(detect_concepts(live_text))) if live_text else list(TEMPLATE_BANK.keys())
    overdue, new, _ = _bucketize(concepts, state, now)
    # Only count as "available" if there's at least one fresh question.
    due_n = sum(1 for c in overdue if _fresh_questions(c, seen_ids))
    new_n = sum(1 for c in new if _fresh_questions(c, seen_ids))
    return due_n, new_n
