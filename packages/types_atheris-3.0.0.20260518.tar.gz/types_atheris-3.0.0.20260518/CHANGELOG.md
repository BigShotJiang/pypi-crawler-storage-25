## 3.0.0.20260518 (2026-05-18)

Upgrade black to 26.5.0 ([#15801](https://github.com/python/typeshed/pull/15801))

## 3.0.0.20260408 (2026-04-08)

Use dashes instead of underscores for METADATA.toml field names ([#15614](https://github.com/python/typeshed/pull/15614))

## 3.0.0.20251219 (2025-12-19)

[atheris] Update to 3.0.* ([#15141](https://github.com/python/typeshed/pull/15141))

Restore atheris stubs ([#15140](https://github.com/python/typeshed/pull/15140))

## 2.3.0.20250306 (2025-03-06)

Update tools versions in `stubtest` workflow ([#13582](https://github.com/python/typeshed/pull/13582))

## 2.3.0.20240831 (2024-08-31)

Added types for atheris ([#12462](https://github.com/python/typeshed/pull/12462))

