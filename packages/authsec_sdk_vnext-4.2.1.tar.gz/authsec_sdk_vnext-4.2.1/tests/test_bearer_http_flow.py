import json
import os
import sys

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from authsec_sdk.core import (  # noqa: E402
    MCPServer,
    _clear_authenticated_session_id,
    _clear_current_session_id,
    configure_auth,
    protected_by_AuthSec,
)


@pytest.fixture(autouse=True)
def reset_sdk_state():
    _clear_current_session_id()
    _clear_authenticated_session_id()
    yield
    _clear_current_session_id()
    _clear_authenticated_session_id()


class BearerProtectedModule:
    @protected_by_AuthSec(
        "delete_export",
        permissions=["breachbox.export:delete"],
        description="Delete a customer export.",
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    )
    async def delete_export(arguments: dict) -> list:
        return [{"type": "text", "text": json.dumps({"deleted": True})}]


def _build_server() -> MCPServer:
    configure_auth(
        client_id="test-client",
        app_name="Bearer First MCP",
        auth_service_url="https://auth.example/sdkmgr/mcp-auth",
        services_base_url="https://auth.example/sdkmgr/services",
        authorization_server_url="https://auth.example/authmgr",
        oauth_browser_url="https://oauth.example",
    )
    server = MCPServer("test-client", "Bearer First MCP")
    server.set_user_module(BearerProtectedModule)
    return server


def test_metadata_endpoints_advertise_protected_resource():
    server = _build_server()
    client = TestClient(server.app)

    protected = client.get("/.well-known/oauth-protected-resource")
    assert protected.status_code == 200
    payload = protected.json()
    assert payload["authorization_servers"] == ["https://auth.example/authmgr"]
    assert "breachbox.export:delete" in payload["scopes_supported"]

    auth_server = client.get("/.well-known/oauth-authorization-server")
    assert auth_server.status_code == 200
    meta = auth_server.json()
    assert meta["issuer"] == "https://auth.example/authmgr"
    assert meta["authorization_endpoint"] == "https://oauth.example/oauth2/auth"
    assert meta["token_endpoint"] == "https://oauth.example/oauth2/token"
    assert meta["registration_endpoint"] == "https://auth.example/authmgr/oauth/register"
    assert meta["introspection_endpoint"] == "https://auth.example/authmgr/oauth/introspect"
    assert "revocation_endpoint" not in meta


def test_protected_tool_without_auth_returns_401_challenge():
    server = _build_server()
    client = TestClient(server.app)

    response = client.post(
        "/",
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": "delete_export",
                "arguments": {},
            },
        },
    )

    assert response.status_code == 401
    assert "WWW-Authenticate" in response.headers
    assert "resource_metadata=" in response.headers["WWW-Authenticate"]

    body = response.json()
    assert body["error"]["code"] == -32001
    assert body["error"]["data"]["status_code"] == 401
    assert "resource_metadata" in body["error"]["data"]


def test_tools_list_forwards_bearer_and_allows_authorized_tools(monkeypatch):
    server = _build_server()
    client = TestClient(server.app)
    captured = {}

    async def fake_auth_request(endpoint, payload=None, method="POST", extra_headers=None):
        captured["endpoint"] = endpoint
        captured["payload"] = payload
        captured["headers"] = extra_headers or {}
        return {
            "tools": [
                {
                    "name": "oauth_start",
                    "description": "Legacy compatibility: start OAuth authentication flow",
                    "inputSchema": {"type": "object", "properties": {}, "required": []},
                },
                {
                    "name": "delete_export",
                    "description": "Delete a customer export.",
                    "inputSchema": {"type": "object", "properties": {}, "required": []},
                },
            ],
            "_status": 200,
        }

    monkeypatch.setattr("authsec_sdk.core._make_auth_request_with_headers", fake_auth_request)

    response = client.post(
        "/",
        json={"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
        headers={"Authorization": "Bearer demo-token"},
    )

    assert response.status_code == 200
    tool_names = [tool["name"] for tool in response.json()["result"]["tools"]]
    assert "delete_export" in tool_names
    assert captured["endpoint"] == "tools/list"
    assert captured["headers"]["Authorization"] == "Bearer demo-token"
    assert captured["payload"]["session_id"] is None


def test_protected_tool_with_insufficient_scope_returns_403(monkeypatch):
    server = _build_server()
    client = TestClient(server.app)

    async def fake_auth_request(endpoint, payload=None, method="POST", extra_headers=None):
        assert endpoint == "protect-tool"
        return {
            "allowed": True,
            "user_info": {
                "scope": ["breachbox.state:read"],
                "permissions": ["breachbox.state:read"],
            },
            "_status": 200,
        }

    monkeypatch.setattr("authsec_sdk.core._make_auth_request_with_headers", fake_auth_request)

    response = client.post(
        "/",
        json={
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "delete_export",
                "arguments": {},
            },
        },
        headers={"Authorization": "Bearer demo-token"},
    )

    assert response.status_code == 403
    assert response.headers["WWW-Authenticate"].startswith('Bearer error="insufficient_scope"')
    body = response.json()
    assert body["error"]["code"] == -32003
    assert body["error"]["data"]["required_scopes"] == ["breachbox.export:delete"]
