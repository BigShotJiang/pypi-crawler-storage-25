"""
AuthSec CLI — interactive setup for .authsec.json configuration.

Usage:
    authsec init          Interactive URL + client_id setup
    authsec config show   Display current saved configuration
    authsec mcp login     Start a local browser-owned MCP login flow
"""

import json
import os
import sys
import time
import urllib.error
import urllib.request
import webbrowser

CONFIG_FILE = ".authsec.json"

DEFAULTS = {
    "auth_service_url": "https://prod.api.authsec.ai/sdkmgr/mcp-auth",
    "services_base_url": "https://prod.api.authsec.ai/sdkmgr/services",
    "ciba_base_url": "https://prod.api.authsec.ai",
    "authorization_server_url": "https://prod.api.authsec.ai/authmgr",
    "oauth_browser_url": "https://oauth.prod.authsec.ai",
}


def _prompt(message, default=None):
    """Prompt user for input with an optional default."""
    if default:
        raw = input(f"{message} [{default}]: ").strip()
        return raw if raw else default
    while True:
        raw = input(f"{message}: ").strip()
        if raw:
            return raw
        print("  This field is required.")


def _config_path():
    return os.path.join(os.getcwd(), CONFIG_FILE)


def cmd_init():
    """Interactive setup that writes .authsec.json to the current directory."""
    print("AuthSec SDK — interactive setup\n")

    choice = _prompt("Use default AuthSec URLs or custom? (default/custom)", "default")

    if choice.lower().startswith("c"):
        auth_service_url = _prompt("Auth Service URL", DEFAULTS["auth_service_url"])
        services_base_url = _prompt("Services Base URL", DEFAULTS["services_base_url"])
        ciba_base_url = _prompt("CIBA Base URL", DEFAULTS["ciba_base_url"])
        authorization_server_url = _prompt("Authorization Server URL", DEFAULTS["authorization_server_url"])
        oauth_browser_url = _prompt("OAuth Browser URL", DEFAULTS["oauth_browser_url"])
    else:
        auth_service_url = DEFAULTS["auth_service_url"]
        services_base_url = DEFAULTS["services_base_url"]
        ciba_base_url = DEFAULTS["ciba_base_url"]
        authorization_server_url = DEFAULTS["authorization_server_url"]
        oauth_browser_url = DEFAULTS["oauth_browser_url"]

    client_id = _prompt("client_id (required)")

    config = {
        "client_id": client_id,
        "auth_service_url": auth_service_url,
        "services_base_url": services_base_url,
        "ciba_base_url": ciba_base_url,
        "authorization_server_url": authorization_server_url,
        "oauth_browser_url": oauth_browser_url,
    }

    path = _config_path()
    with open(path, "w") as f:
        json.dump(config, f, indent=2)

    print(f"\nConfig saved to {path}\n")
    _print_config(config)


def cmd_config_show():
    """Display the current .authsec.json configuration."""
    path = _config_path()
    if not os.path.isfile(path):
        print(f"No config file found at {path}")
        print("Run 'authsec init' to create one.")
        sys.exit(1)

    with open(path) as f:
        config = json.load(f)

    _print_config(config)


def _print_config(config):
    print("Current AuthSec configuration:")
    for key, value in config.items():
        print(f"  {key}: {value}")


def _resolve_cli_config():
    config = {}
    path = _config_path()
    if os.path.isfile(path):
        with open(path) as f:
            loaded = json.load(f)
            if isinstance(loaded, dict):
                config.update(loaded)

    return {
        "client_id": os.getenv("AUTHSEC_CLIENT_ID") or config.get("client_id"),
        "auth_service_url": os.getenv("AUTHSEC_AUTH_SERVICE_URL") or config.get("auth_service_url") or DEFAULTS["auth_service_url"],
        "authorization_server_url": os.getenv("AUTHSEC_AUTHORIZATION_SERVER_URL") or config.get("authorization_server_url") or DEFAULTS["authorization_server_url"],
    }


def _request_json(url, method="GET", payload=None):
    body = None
    headers = {}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    with urllib.request.urlopen(request) as response:
        return json.loads(response.read().decode("utf-8"))


def cmd_mcp_login(args):
    """Start a local browser-owned MCP login flow and poll for completion."""
    config = _resolve_cli_config()
    client_id = config.get("client_id")
    auth_service_url = str(config.get("auth_service_url") or "").rstrip("/")

    if not client_id:
        print("Missing client_id. Run 'authsec init' or set AUTHSEC_CLIENT_ID.")
        sys.exit(1)

    if not auth_service_url:
        print("Missing auth_service_url. Run 'authsec init' or set AUTHSEC_AUTH_SERVICE_URL.")
        sys.exit(1)

    app_name = os.getenv("AUTHSEC_APP_NAME") or (args[0] if args else "AuthSec MCP CLI")
    timeout_seconds = int(os.getenv("AUTHSEC_LOGIN_TIMEOUT_SECONDS", "180"))
    poll_interval = float(os.getenv("AUTHSEC_LOGIN_POLL_SECONDS", "2"))

    try:
        start = _request_json(
            f"{auth_service_url}/start",
            method="POST",
            payload={"client_id": client_id, "app_name": app_name},
        )
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        print(f"Failed to start login flow: HTTP {exc.code} {body}")
        sys.exit(1)
    except Exception as exc:
        print(f"Failed to start login flow: {exc}")
        sys.exit(1)

    authorization_url = start.get("authorization_url")
    session_id = start.get("session_id")
    if not authorization_url or not session_id:
        print(f"Unexpected login response: {json.dumps(start, indent=2)}")
        sys.exit(1)

    print(f"Client ID: {client_id}")
    print(f"Authorization server: {config.get('authorization_server_url')}")
    print(f"Session ID: {session_id}")
    print(f"Authorization URL: {authorization_url}")

    opened = False
    try:
        opened = bool(webbrowser.open(authorization_url, new=2))
    except Exception:
        opened = False

    if opened:
        print("Opened the browser locally. Complete the login there.")
    else:
        print("Open the authorization URL in your browser to continue.")

    deadline = time.time() + timeout_seconds
    status_url = f"{auth_service_url}/status/{session_id}"

    while time.time() < deadline:
        try:
            status = _request_json(status_url)
        except Exception as exc:
            print(f"Status check failed: {exc}")
            sys.exit(1)

        state = status.get("status")
        if state == "authenticated":
            print("Authentication complete.")
            print(json.dumps(status, indent=2))
            return
        if state in {"expired", "logged_out", "not_found"}:
            print(json.dumps(status, indent=2))
            sys.exit(1)
        time.sleep(poll_interval)

    print("Timed out waiting for browser login to complete.")
    print("You can continue polling with:")
    print(f"  curl {status_url}")
    sys.exit(1)


def main():
    args = sys.argv[1:]

    if not args or args == ["--help"] or args == ["-h"]:
        print(__doc__.strip())
        sys.exit(0)

    command = args[0]

    if command == "init":
        cmd_init()
    elif command == "config" and len(args) > 1 and args[1] == "show":
        cmd_config_show()
    elif command == "mcp" and len(args) > 1 and args[1] == "login":
        cmd_mcp_login(args[2:])
    else:
        print(f"Unknown command: {' '.join(args)}")
        print(__doc__.strip())
        sys.exit(1)


if __name__ == "__main__":
    main()
