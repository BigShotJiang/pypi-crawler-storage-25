"""Ollama local provider: detection and auth handlers for desktop onboarding.

Ollama uses the Codex CLI binary with ``--oss --local-provider ollama`` but
requires no cloud authentication. Detection checks both the ``codex`` binary
and the Ollama endpoint reachability.
"""

from __future__ import annotations

import urllib.request
from typing import Any

from obra.config.cli_resolution import resolve_cli_path
from obra.config.loaders import get_gateway_onboarding_config


def _check_ollama_endpoint(timeout: int | float = 5) -> dict[str, Any]:
    """Check whether the Ollama endpoint is reachable.

    Returns dict with ``reachable``, ``endpoint``, and optional ``issue``.
    """
    try:
        from obra.llm.ollama_endpoint import resolve_ollama_endpoint

        endpoint = resolve_ollama_endpoint()
    except Exception:
        endpoint = "http://localhost:11434"

    tags_url = f"{endpoint.rstrip('/')}/api/tags"
    try:
        request = urllib.request.Request(tags_url, method="GET")
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = getattr(response, "status", None)
            if status == 200:
                return {"reachable": True, "endpoint": endpoint}
            return {
                "reachable": False,
                "endpoint": endpoint,
                "issue": f"HTTP {status}",
            }
    except Exception:
        return {
            "reachable": False,
            "endpoint": endpoint,
            "issue": "not_reachable",
        }


def detect_ollama_local() -> dict[str, Any]:
    """Detect whether Codex CLI and Ollama endpoint are available.

    Returns a composite dict:
    - ``installed``: True only when both codex binary exists AND Ollama is reachable
    - ``codex_installed``, ``codex_path``: Codex CLI detection
    - ``ollama_reachable``, ``ollama_endpoint``: Ollama endpoint status
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    # Check codex binary.
    codex_path = resolve_cli_path("codex")
    codex_installed = codex_path is not None

    # Check Ollama endpoint.
    ollama_status = _check_ollama_endpoint(timeout=timeout)
    ollama_reachable = ollama_status["reachable"]

    result: dict[str, Any] = {
        "installed": codex_installed and ollama_reachable,
        "codex_installed": codex_installed,
        "codex_path": codex_path,
        "ollama_reachable": ollama_reachable,
        "ollama_endpoint": ollama_status.get("endpoint", ""),
    }

    if not codex_installed:
        result["install_url"] = "https://ollama.com/download"
        result["install_command"] = "npm install -g @openai/codex"

    if not ollama_reachable:
        result["ollama_issue"] = ollama_status.get("issue", "not_reachable")
        result["ollama_hint"] = "Start Ollama with: ollama serve"

    return result


def check_ollama_auth() -> dict[str, Any]:
    """Check Ollama 'auth' — endpoint reachability (no cloud auth needed).

    Function named ``check_ollama_auth`` to match the onboarding.py
    resolution convention ``check_{provider_id}_auth`` where provider_id
    is ``ollama``.

    Returns ``authenticated: True`` when the Ollama endpoint is reachable.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    status = _check_ollama_endpoint(timeout=timeout)
    if status["reachable"]:
        return {"authenticated": True, "auth_issue": None}
    return {"authenticated": False, "auth_issue": "ollama_unreachable"}


def authenticate_ollama_local() -> dict[str, Any]:
    """No-op auth for Ollama — local provider, no cloud auth flow.

    Returns ``skipped: True`` to signal the UI should auto-advance.
    """
    return {
        "triggered": False,
        "error": None,
        "skipped": True,
        "reason": "local_provider",
    }
