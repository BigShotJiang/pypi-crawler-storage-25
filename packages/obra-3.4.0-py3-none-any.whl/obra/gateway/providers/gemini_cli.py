"""Google Gemini CLI provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import subprocess
from typing import Any

from obra.config.cli_resolution import resolve_cli_path
from obra.config.loaders import get_gateway_onboarding_config


def detect_gemini_cli() -> dict[str, Any]:
    """Detect whether the Gemini CLI binary is installed.

    Returns dict with ``installed``, and either ``path``/``version``
    or ``install_url``/``install_command``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://ai.google.dev/gemini-api/docs/gemini-cli",
            "install_command": "npm install -g @google/gemini-cli",
        }

    try:
        result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        version = result.stdout.strip() if result.returncode == 0 else "unknown"
    except (subprocess.TimeoutExpired, OSError):
        version = "unknown"

    return {
        "installed": True,
        "path": binary_path,
        "version": version,
    }


def check_google_auth() -> dict[str, Any]:
    """Check whether Gemini CLI is authenticated with Google.

    Function named ``check_google_auth`` to match the onboarding.py
    resolution convention ``check_{provider_id}_auth`` where provider_id
    is ``google``.

    Uses ``gemini --list-sessions`` (not ``gemini auth status`` which does
    not exist in the Gemini CLI — the CLI would interpret it as a prompt).

    Returns dict with ``authenticated`` and optional ``auth_issue``.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        result = subprocess.run(
            [binary_path, "--list-sessions"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if result.returncode == 0:
            combined = result.stdout.lower() + result.stderr.lower()
            if "expired" in combined:
                return {"authenticated": False, "auth_issue": "expired"}
            # The CLI loads cached credentials during --list-sessions.
            # Exit code 0 means credentials were loaded successfully.
            return {"authenticated": True, "auth_issue": None}
        # Non-zero exit: check stderr/stdout for clues.
        combined = result.stdout.lower() + result.stderr.lower()
        if "expired" in combined:
            return {"authenticated": False, "auth_issue": "expired"}
        return {"authenticated": False, "auth_issue": "not_authenticated"}
    except subprocess.TimeoutExpired:
        return {"authenticated": False, "auth_issue": "connection_failed"}
    except OSError:
        return {"authenticated": False, "auth_issue": "not_installed"}


def authenticate_gemini_cli() -> dict[str, Any]:
    """Return manual auth instructions for Gemini CLI.

    Gemini CLI has no dedicated ``auth login`` command — authentication
    is triggered on first interactive use via Google OAuth in the
    browser.  Spawning the CLI programmatically would burn API quota
    without reliably surfacing the OAuth flow to the user.
    """
    binary_path = resolve_cli_path("gemini")
    if not binary_path:
        return {"triggered": False, "error": "Gemini CLI is not installed"}

    return {
        "triggered": False,
        "manual_action_required": True,
        "instructions": (
            "Run 'gemini' in your terminal to authenticate with Google. "
            "The CLI will open a browser window for OAuth sign-in on first use."
        ),
    }
