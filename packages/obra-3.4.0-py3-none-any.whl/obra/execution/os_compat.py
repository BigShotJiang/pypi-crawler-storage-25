"""OS compatibility layer for Obra's execution pipeline.

Consolidates all platform-specific logic (path formats, subprocess environment,
process death signals) into a single module. Other modules should import from
here rather than using platform.system(), sys.platform, or os.name directly.

This module intentionally avoids imports from obra.config or obra.core to
prevent circular dependencies.

Related:
    - docs/design/briefs/ECL_PHASE1_OS_CONSOLIDATION_BRIEF.md
    - docs/design/prds/EXECUTION_ENVIRONMENT_COMPATIBILITY_PRD.md
"""

from __future__ import annotations

import ctypes
import functools
import logging
import os
import platform
import signal
import sys
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Literal

logger = logging.getLogger(__name__)

try:
    import resource
except ImportError:  # pragma: no cover - Windows only
    resource = None

# Linux prctl constants
PR_SET_PDEATHSIG = 1


@dataclass(frozen=True)
class EnvironmentProfile:
    """Resolved OS environment profile for the execution pipeline.

    Fields:
        path_format: 'posix' on Linux/macOS, 'windows' only when
            platform.system() == 'Windows'.
        use_absolute_paths: True when the LLM provider requires absolute
            paths (e.g. OpenAI Codex). Provider-aware resolution is handled
            in resolve_profile(provider=...).
        encoding: Default 'utf-8'; detected from sys.stdout.encoding on
            Windows when available.
    """

    path_format: Literal["posix", "windows"]
    use_absolute_paths: bool
    encoding: str


@functools.lru_cache(maxsize=32)
def resolve_profile(provider: str | None = None) -> EnvironmentProfile:
    """Resolve the current OS environment profile.

    Caches the result so repeated calls return the same frozen instance.

    Returns:
        EnvironmentProfile with fields resolved from the current platform.
    """
    system = platform.system()
    path_format: Literal["posix", "windows"] = "windows" if system == "Windows" else "posix"

    # Detect encoding on Windows; default to utf-8 elsewhere
    if system == "Windows":
        encoding = getattr(sys.stdout, "encoding", None) or "utf-8"
    else:
        encoding = "utf-8"

    use_absolute_paths = provider == "openai"

    runtime_platform_config = None
    try:
        from obra.config.loaders import get_runtime_platform_config

        runtime_platform_config = get_runtime_platform_config()
    except Exception:
        logger.debug("Runtime platform config unavailable during profile resolution", exc_info=True)

    if runtime_platform_config is not None:
        ensure_fd_limit(int(runtime_platform_config["fd_soft_limit_minimum"]))

    return EnvironmentProfile(
        path_format=path_format,
        use_absolute_paths=use_absolute_paths,
        encoding=encoding,
    )


def get_prctl_death_signal_fn() -> Callable[[], None] | None:
    """Get a preexec_fn that sets PR_SET_PDEATHSIG on Linux.

    On Linux, this returns a function that can be passed to subprocess.Popen's
    preexec_fn parameter. When called, it sets PR_SET_PDEATHSIG to SIGTERM,
    causing the child process to receive SIGTERM when the parent dies
    (including on SIGKILL).

    On non-Linux systems (macOS, Windows), returns None.

    Returns:
        A callable for preexec_fn on Linux, None on other platforms.

    Usage:
        >>> preexec = get_prctl_death_signal_fn()
        >>> if preexec:
        ...     proc = subprocess.Popen(cmd, preexec_fn=preexec)
        ... else:
        ...     proc = subprocess.Popen(cmd)
    """
    if platform.system() != "Linux":
        return None

    def set_pdeathsig() -> None:
        """Set PR_SET_PDEATHSIG to SIGTERM."""
        try:
            libc = ctypes.CDLL("libc.so.6", use_errno=True)
            # prctl(PR_SET_PDEATHSIG, SIGTERM)
            result = libc.prctl(PR_SET_PDEATHSIG, signal.SIGTERM)
            if result != 0:
                logger.warning(f"prctl(PR_SET_PDEATHSIG) failed with result {result}")
        except Exception as e:
            logger.warning(f"Failed to set PR_SET_PDEATHSIG: {e}")

    return set_pdeathsig


# API key environment variable names for each provider
# Used by build_subprocess_env() to strip keys when OAuth is configured
PROVIDER_API_KEY_ENV_VARS = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "google": "GOOGLE_API_KEY",
}


def build_popen_kwargs() -> dict[str, Any]:
    """Build kwargs dict for subprocess.Popen with platform-specific settings.

    Returns a dict containing preexec_fn (Linux only) that can be unpacked
    into subprocess.Popen(**kwargs). Centralizes the preexec_fn resolution
    so callers don't need to import or call get_prctl_death_signal_fn() directly.

    Returns:
        Dict with 'preexec_fn' key. Value is a callable on Linux, None on
        other platforms.

    Usage:
        >>> popen_kwargs = build_popen_kwargs()
        >>> proc = subprocess.Popen(cmd, **popen_kwargs)
    """
    return {"preexec_fn": get_prctl_death_signal_fn()}


def is_interactive_context() -> bool:
    """Return True when the current process has an interactive TTY available."""
    try:
        return bool(sys.stdin is not None and sys.stdin.isatty())
    except Exception:
        return False


def ensure_fd_limit(minimum: int) -> None:
    """Raise the soft RLIMIT_NOFILE value up to the configured minimum when possible."""
    if sys.platform == "win32":
        return
    if resource is None:
        return

    try:
        soft_limit, hard_limit = resource.getrlimit(resource.RLIMIT_NOFILE)
    except (OSError, ValueError):
        logger.debug("Unable to read RLIMIT_NOFILE", exc_info=True)
        return

    if soft_limit >= minimum:
        return

    target_limit = min(minimum, hard_limit)
    try:
        resource.setrlimit(resource.RLIMIT_NOFILE, (target_limit, hard_limit))
    except (OSError, ValueError):
        logger.warning(
            "File descriptor limit is %s, recommended minimum is %s. Consider: ulimit -n %s",
            soft_limit,
            minimum,
            minimum,
        )


def build_subprocess_env(
    auth_method: str,
    base_env: dict[str, str] | None = None,
    extra_env: dict[str, str] | None = None,
) -> dict[str, str]:
    """Build subprocess environment with auth-aware API key handling.

    When auth_method is "oauth", API key environment variables are stripped
    to ensure the CLI uses OAuth authentication instead of API key billing.
    This prevents unexpected billing when a user has both OAuth configured
    in Obra and API keys set in their shell environment.

    Provider CLI auth priority (applies to all providers):
    1. API key environment variable (highest - API billing)
    2. OAuth token
    3. Subscription (lowest)

    By stripping API keys when OAuth is configured, we ensure Obra respects
    the user's auth_method configuration.

    Args:
        auth_method: Authentication method ("oauth" or "api_key")
        base_env: Base environment dict (defaults to os.environ.copy())
        extra_env: Additional environment variables to add

    Returns:
        Environment dict suitable for subprocess.run(env=...)

    Example:
        >>> # OAuth mode - API keys stripped
        >>> env = build_subprocess_env("oauth")
        >>> "ANTHROPIC_API_KEY" in env
        False

        >>> # API key mode - API keys preserved
        >>> env = build_subprocess_env("api_key")
        >>> "ANTHROPIC_API_KEY" in env  # if set in os.environ
        True

    Note:
        This is NON-DESTRUCTIVE. The original os.environ is never modified.
        Only the returned copy has API keys removed when auth_method is "oauth".
        Other processes (parallel Obra runs, direct API calls) are unaffected.
    """
    # Start with base environment (copy to avoid modifying original)
    env = os.environ.copy() if base_env is None else base_env.copy()

    # When OAuth is configured, strip API keys to prevent CLI from using them
    if auth_method == "oauth":
        stripped_keys = []
        for key_var in PROVIDER_API_KEY_ENV_VARS.values():
            if key_var in env:
                env.pop(key_var)
                stripped_keys.append(key_var)

        if stripped_keys:
            logger.info(
                "OAuth mode: Stripped API key env vars from subprocess environment: %s. "
                "CLI will use OAuth authentication.",
                ", ".join(stripped_keys),
            )
    else:
        # API key mode - log if API keys are present
        present_keys = [key_var for key_var in PROVIDER_API_KEY_ENV_VARS.values() if key_var in env]
        if present_keys:
            logger.debug(
                "API key mode: Using API key authentication. Present: %s",
                ", ".join(present_keys),
            )

    # Add extra environment variables
    if extra_env:
        env.update(extra_env)

    return env
