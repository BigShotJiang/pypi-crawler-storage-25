# mlpilot 🚀

[![PyPI version](https://badge.fury.io/py/mlplt.svg)](https://badge.fury.io/py/mlplt)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://github.com/yourusername/mlpilot/actions/workflows/test.yml/badge.svg)](https://github.com/yourusername/mlpilot/actions)
[![Downloads](https://pepy.tech/badge/mlplt/month)](https://pepy.tech/project/mlplt)

**mlpilot** is the complete Python ML toolkit — what currently takes 30–40 hours of repetitive boilerplate takes **5–10 minutes**. One import. Every tool you need. Full explainability.

```python
import mlpilot as ml

eda    = ml.analyze(df, target='churn')          # 12-section EDA report
clean  = ml.clean(df, target='churn')            # auto null/outlier/dtype fixing
feats  = ml.features(clean.df, target='churn')  # leakage-safe feature pipeline
board  = ml.baseline(X_train, y_train)           # 15+ model leaderboard in 2 min
tuned  = ml.tune('lgbm', X_train, y_train)       # Bayesian hyperparameter search
exp    = ml.explain(tuned.best_model, X_train)   # SHAP global + local explanations
api    = ml.deploy(tuned.best_model)             # FastAPI + Docker in 5 minutes
api.serve(port=8000)                              # → localhost:8000/predict
```

## Why mlpilot?

| Feature | mlpilot | ydata-profiling | sweetviz | PyCaret | SHAP |
|---|---|---|---|---|---|
| Smart EDA report | ✅ | ✅ | ✅ | ❌ | ❌ |
| Auto data cleaning | ✅ | ❌ | ❌ | Partial | ❌ |
| Multi-model baseline | ✅ | ❌ | ❌ | ✅ | ❌ |
| Hyperparameter tuning | ✅ | ❌ | ❌ | ✅ | ❌ |
| Model explainability | ✅ | ❌ | ❌ | ❌ | ✅ |
| Time series | ✅ | ❌ | ❌ | ✅ | ❌ |
| NLP pipeline | ✅ | ❌ | ❌ | ✅ | ❌ |
| API deployment | ✅ | ❌ | ❌ | ❌ | ❌ |
| AI data analyst | ✅ | ❌ | ❌ | ❌ | ❌ |
| Undo / diff reports | ✅ | ❌ | ❌ | ❌ | ❌ |

## Installation

```bash
# Core (EDA, cleaning, validation, features, training)
pip install mlplt

# With specific extras
pip install mlplt[xgb,lgbm,shap,optuna]

# Everything
pip install mlplt[full]
```

**Available extras:** `xgb`, `lgbm`, `shap`, `optuna`, `prophet`, `nlp`, `imb`, `deploy`, `ai`, `full`

## Modules

| Module | Function | Description |
|---|---|---|
| SmartEDA | `ml.analyze(df)` | 12-section EDA report with plots |
| AutoCleaner | `ml.clean(df)` | Auto null/outlier/dtype fixing with undo |
| DataValidator | `ml.validate(df)` | Schema, leakage, drift detection |
| FeatureForge | `ml.features(df)` | Leakage-safe encoding + scaling pipeline |
| BaselineBlitz | `ml.baseline(X, y)` | 15+ model comparison leaderboard |
| EvalSuite | `ml.evaluate(model, X, y)` | All metrics + diagnostic plots |
| HyperX | `ml.tune(model, X, y)` | Bayesian hyperparameter optimization |
| Explainer | `ml.explain(model, X)` | SHAP global + local + what-if |
| BalanceKit | `ml.balance(X, y)` | Auto SMOTE/ADASYN/class_weight |
| TimeSense | `ml.forecast(df)` | Multi-model time series forecasting |
| TextML | `ml.text_classify(df)` | NLP classification + embeddings |
| LaunchPad | `ml.deploy(model)` | FastAPI + Docker generation |
| AIAnalyst | `ml.analyst(df)` | Ask questions in plain English |

## Quick Start — Churn Prediction

```python
import mlpilot as ml
import pandas as pd

df = pd.read_csv('churn.csv')

# 1. Understand your data
eda = ml.analyze(df, target='Churn', report_format='html')

# 2. Clean it
df_clean = ml.clean(df, target='Churn').df

# 3. Engineer features (leakage-safe)
feats = ml.features(df_clean, target='Churn')
X_train, X_test, y_train, y_test = ml.split(feats, test_size=0.2, stratify=True)

# 4. Handle imbalance
bal = ml.balance(X_train, y_train)

# 5. Find the best model
board = ml.baseline(bal.X_resampled, bal.y_resampled, X_test=X_test, y_test=y_test)
board.leaderboard.print()

# 6. Tune + evaluate
tuned = ml.tune('lgbm', bal.X_resampled, bal.y_resampled, time_budget=300)
eval_r = ml.evaluate(tuned.best_model, X_test, y_test, optimize_threshold=True)

# 7. Explain
exp = ml.explain(tuned.best_model, X_train, X_test)
exp.feature_importance()

# 8. Deploy
ml.deploy(tuned.best_model, X_sample=X_test.iloc[:10]).serve(port=8000)
```

## Documentation

Full API reference: [mlpilot.readthedocs.io](https://mlpilot.readthedocs.io)

## Contributing

1. Fork the repo
2. `pip install -e ".[dev]"`
3. `pre-commit install`
4. Make your changes + add tests
5. `pytest tests/ --cov=mlpilot`
6. Open a pull request

## License

MIT — see [LICENSE](LICENSE).
