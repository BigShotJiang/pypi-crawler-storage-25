"""
mlpilot/utils/colab.py
Google Colab specific utilities (Ollama setup, etc.)
"""

from __future__ import annotations

import os
import subprocess
import time
from mlpilot.utils.display import print_step, print_success, print_error, print_warning


def setup_ollama(model_to_pull: str = "llama3"):
    """
    Automates the installation and background-startup of Ollama in Google Colab.
    
    Parameters
    ----------
    model_to_pull : str
        The model to pull once Ollama is running (e.g. 'llama3', 'mistral').
    """
    print_step("Installing Ollama (this may take a minute)...", "🌐")
    
    try:
        # 1. Run official install script
        subprocess.run(
            "curl -fsSL https://ollama.com/install.sh | sh",
            shell=True,
            check=True,
            capture_output=True
        )
        print_success("Ollama installed successfully.")
        
        # 2. Start server in background
        print_step("Starting Ollama server in background...", "⚡")
        subprocess.Popen(
            ["ollama", "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        # 3. Wait for initialization
        time.sleep(5)
        
        # 4. Pull the model
        print_step(f"Pulling model '{model_to_pull}'...", "📥")
        subprocess.run(["ollama", "pull", model_to_pull], check=True)
        
        print_success(f"Ollama is ready! Model '{model_to_pull}' is loaded.")
        
    except Exception as e:
        print_error(f"Failed to setup Ollama: {e}")
        print_warning("Make sure you are running in a GPU-enabled runtime in Colab.")


def install_dependencies():
    """Install all optional dependencies needed for AI features."""
    print_step("Installing mlpilot[ai] dependencies...", "📦")
    subprocess.run(["pip", "install", "mlpilot[ai]"], check=True)
    print_success("Dependencies installed.")
