"""SQLite-backed session store for persisting session metadata."""

from __future__ import annotations

import json
import os
import sqlite3
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SESSION_DB_PATH_ENV = "PBI_AGENT_SESSION_DB_PATH"
DEFAULT_SESSION_DB_PATH = Path.home() / ".pbi-agent" / "sessions.db"

KANBAN_STAGE_BACKLOG = "backlog"
KANBAN_STAGE_PLAN = "plan"
KANBAN_STAGE_REVIEW = "review"
KANBAN_STAGE_DONE = "done"
KANBAN_DEFAULT_STAGE_SPECS = (
    {
        "stage_id": KANBAN_STAGE_BACKLOG,
        "name": "Backlog",
        "command_id": None,
        "auto_start": False,
    },
    {
        "stage_id": KANBAN_STAGE_DONE,
        "name": "Done",
        "command_id": None,
        "auto_start": False,
    },
)

KANBAN_RUN_STATUS_IDLE = "idle"
KANBAN_RUN_STATUS_RUNNING = "running"
KANBAN_RUN_STATUS_COMPLETED = "completed"
KANBAN_RUN_STATUS_FAILED = "failed"

_SCHEMA = """\
CREATE TABLE IF NOT EXISTS sessions (
    session_id    TEXT PRIMARY KEY,
    directory     TEXT NOT NULL,
    provider      TEXT NOT NULL,
    provider_id   TEXT,
    model         TEXT NOT NULL DEFAULT '',
    profile_id    TEXT,
    previous_id   TEXT,
    title         TEXT NOT NULL DEFAULT '',
    total_tokens  INTEGER NOT NULL DEFAULT 0,
    input_tokens  INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    cost_usd      REAL NOT NULL DEFAULT 0.0,
    is_fork       INTEGER NOT NULL DEFAULT 0,
    forked_from_session_id TEXT,
    forked_from_message_id INTEGER,
    fork_created_at TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_directory ON sessions(directory);
CREATE INDEX IF NOT EXISTS idx_sessions_updated_at ON sessions(updated_at DESC);

CREATE TABLE IF NOT EXISTS messages (
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id             TEXT NOT NULL REFERENCES sessions(session_id),
    role                   TEXT NOT NULL,
    content                TEXT NOT NULL DEFAULT '',
    provider_id            TEXT,
    profile_id             TEXT,
    file_paths_json        TEXT NOT NULL DEFAULT '[]',
    image_attachments_json TEXT NOT NULL DEFAULT '[]',
    created_at             TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_session_id ON messages(session_id, id);

CREATE TABLE IF NOT EXISTS run_sessions (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    run_session_id          TEXT NOT NULL UNIQUE,
    session_id              TEXT REFERENCES sessions(session_id),
    parent_run_session_id   TEXT,
    agent_name              TEXT,
    agent_type              TEXT,
    provider                TEXT,
    provider_id             TEXT,
    profile_id              TEXT,
    model                   TEXT,
    status                  TEXT NOT NULL,
    started_at              TEXT NOT NULL,
    ended_at                TEXT,
    total_duration_ms       INTEGER,
    input_tokens            INTEGER NOT NULL DEFAULT 0,
    cached_input_tokens     INTEGER NOT NULL DEFAULT 0,
    cache_write_tokens      INTEGER NOT NULL DEFAULT 0,
    cache_write_1h_tokens   INTEGER NOT NULL DEFAULT 0,
    output_tokens           INTEGER NOT NULL DEFAULT 0,
    reasoning_tokens        INTEGER NOT NULL DEFAULT 0,
    tool_use_tokens         INTEGER NOT NULL DEFAULT 0,
    provider_total_tokens   INTEGER NOT NULL DEFAULT 0,
    estimated_cost_usd      REAL NOT NULL DEFAULT 0.0,
    total_tool_calls        INTEGER NOT NULL DEFAULT 0,
    total_api_calls         INTEGER NOT NULL DEFAULT 0,
    error_count             INTEGER NOT NULL DEFAULT 0,
    kind                    TEXT NOT NULL DEFAULT 'cli',
    task_id                 TEXT,
    project_dir             TEXT,
    last_event_seq          INTEGER NOT NULL DEFAULT 0,
    snapshot_json           TEXT NOT NULL DEFAULT '{}',
    exit_code               INTEGER,
    fatal_error             TEXT,
    metadata_json           TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_run_sessions_session_id
    ON run_sessions(session_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_run_sessions_parent_run_session_id
    ON run_sessions(parent_run_session_id);
CREATE INDEX IF NOT EXISTS idx_run_sessions_started_at
    ON run_sessions(started_at DESC);

CREATE TABLE IF NOT EXISTS observability_events (
    id                    INTEGER PRIMARY KEY AUTOINCREMENT,
    run_session_id        TEXT NOT NULL,
    session_id            TEXT,
    step_index            INTEGER NOT NULL,
    event_type            TEXT NOT NULL,
    timestamp             TEXT NOT NULL,
    duration_ms           INTEGER,
    provider              TEXT,
    model                 TEXT,
    url                   TEXT,
    request_config_json   TEXT,
    request_payload_json  TEXT,
    response_payload_json TEXT,
    tool_name             TEXT,
    tool_call_id          TEXT,
    tool_input_json       TEXT,
    tool_output_json      TEXT,
    tool_duration_ms      INTEGER,
    prompt_tokens         INTEGER,
    completion_tokens     INTEGER,
    total_tokens          INTEGER,
    status_code           INTEGER,
    success               INTEGER,
    error_message         TEXT,
    metadata_json         TEXT NOT NULL DEFAULT '{}'
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_observability_events_run_step
    ON observability_events(run_session_id, step_index);
CREATE INDEX IF NOT EXISTS idx_observability_events_session_id
    ON observability_events(session_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_observability_events_run_session_id
    ON observability_events(run_session_id, timestamp);
CREATE INDEX IF NOT EXISTS idx_observability_events_event_type
    ON observability_events(event_type, timestamp);
CREATE INDEX IF NOT EXISTS idx_observability_events_timestamp
    ON observability_events(timestamp);

CREATE TABLE IF NOT EXISTS kanban_tasks (
    task_id               TEXT PRIMARY KEY,
    directory             TEXT NOT NULL,
    title                 TEXT NOT NULL,
    prompt                TEXT NOT NULL DEFAULT '',
    stage                 TEXT NOT NULL,
    position              INTEGER NOT NULL DEFAULT 0,
    project_dir           TEXT NOT NULL DEFAULT '.',
    session_id            TEXT,
    model_profile_id      TEXT,
    run_status            TEXT NOT NULL DEFAULT 'idle',
    last_result_summary   TEXT NOT NULL DEFAULT '',
    created_at            TEXT NOT NULL,
    updated_at            TEXT NOT NULL,
    last_run_started_at   TEXT,
    last_run_finished_at  TEXT,
    image_attachments_json TEXT NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_kanban_tasks_directory
    ON kanban_tasks(directory, stage, position, updated_at DESC);

CREATE TABLE IF NOT EXISTS kanban_stage_configs (
    directory         TEXT NOT NULL,
    stage_id          TEXT NOT NULL,
    name              TEXT NOT NULL,
    position          INTEGER NOT NULL,
    model_profile_id  TEXT,
    command_id           TEXT,
    auto_start        INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL,
    PRIMARY KEY (directory, stage_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_kanban_stage_configs_position
    ON kanban_stage_configs(directory, position);

CREATE TABLE IF NOT EXISTS web_manager_leases (
    directory     TEXT PRIMARY KEY,
    owner_id      TEXT NOT NULL,
    heartbeat_at  TEXT NOT NULL,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS maintenance_state (
    name             TEXT PRIMARY KEY,
    last_run_date    TEXT NOT NULL,
    last_started_at  TEXT NOT NULL,
    last_finished_at TEXT,
    status           TEXT NOT NULL DEFAULT 'started'
);
"""


@dataclass(slots=True)
class SessionRecord:
    session_id: str
    directory: str
    provider: str
    provider_id: str | None
    model: str
    profile_id: str | None
    previous_id: str | None
    title: str
    total_tokens: int
    input_tokens: int
    output_tokens: int
    cost_usd: float
    is_fork: int
    forked_from_session_id: str | None
    forked_from_message_id: int | None
    fork_created_at: str | None
    created_at: str
    updated_at: str


@dataclass(slots=True)
class MessageRecord:
    id: int
    session_id: str
    role: str
    content: str
    created_at: str
    provider_id: str | None = None
    profile_id: str | None = None
    file_paths: list[str] = field(default_factory=list)
    image_attachments: list["MessageImageAttachment"] = field(default_factory=list)


@dataclass(slots=True)
class MessageImageAttachment:
    upload_id: str
    name: str
    mime_type: str
    byte_count: int
    preview_url: str


@dataclass(slots=True)
class RunSessionRecord:
    id: int
    run_session_id: str
    session_id: str | None
    parent_run_session_id: str | None
    agent_name: str | None
    agent_type: str | None
    provider: str | None
    provider_id: str | None
    profile_id: str | None
    model: str | None
    status: str
    started_at: str
    ended_at: str | None
    total_duration_ms: int | None
    input_tokens: int
    cached_input_tokens: int
    cache_write_tokens: int
    cache_write_1h_tokens: int
    output_tokens: int
    reasoning_tokens: int
    tool_use_tokens: int
    provider_total_tokens: int
    estimated_cost_usd: float
    total_tool_calls: int
    total_api_calls: int
    error_count: int
    kind: str
    task_id: str | None
    project_dir: str | None
    last_event_seq: int
    snapshot_json: str
    exit_code: int | None
    fatal_error: str | None
    metadata_json: str


@dataclass(slots=True)
class ObservabilityEventRecord:
    id: int
    run_session_id: str
    session_id: str | None
    step_index: int
    event_type: str
    timestamp: str
    duration_ms: int | None
    provider: str | None
    model: str | None
    url: str | None
    request_config_json: str | None
    request_payload_json: str | None
    response_payload_json: str | None
    tool_name: str | None
    tool_call_id: str | None
    tool_input_json: str | None
    tool_output_json: str | None
    tool_duration_ms: int | None
    prompt_tokens: int | None
    completion_tokens: int | None
    total_tokens: int | None
    status_code: int | None
    success: int | None
    error_message: str | None
    metadata_json: str


@dataclass(slots=True)
class KanbanTaskRecord:
    task_id: str
    directory: str
    title: str
    prompt: str
    stage: str
    position: int
    project_dir: str
    session_id: str | None
    model_profile_id: str | None
    run_status: str
    last_result_summary: str
    created_at: str
    updated_at: str
    last_run_started_at: str | None
    last_run_finished_at: str | None
    image_attachments: list[MessageImageAttachment] = field(default_factory=list)


@dataclass(slots=True)
class KanbanStageConfigSpec:
    stage_id: str
    name: str
    model_profile_id: str | None = None
    command_id: str | None = None
    auto_start: bool = False


@dataclass(slots=True)
class KanbanStageConfigRecord:
    directory: str
    stage_id: str
    name: str
    position: int
    model_profile_id: str | None
    command_id: str | None
    auto_start: bool
    created_at: str
    updated_at: str


_KANBAN_FIXED_STAGE_NAMES = {
    KANBAN_STAGE_BACKLOG: "Backlog",
    KANBAN_STAGE_DONE: "Done",
}


def _normalize_kanban_stage_specs(
    stages: list[KanbanStageConfigSpec],
) -> list[KanbanStageConfigSpec]:
    fixed_ids = set(_KANBAN_FIXED_STAGE_NAMES)
    stage_map = {item.stage_id: item for item in stages}
    middle_stages = [item for item in stages if item.stage_id not in fixed_ids]
    normalized: list[KanbanStageConfigSpec] = [
        KanbanStageConfigSpec(
            stage_id=KANBAN_STAGE_BACKLOG,
            name=_KANBAN_FIXED_STAGE_NAMES[KANBAN_STAGE_BACKLOG],
            model_profile_id=None,
            command_id=None,
            auto_start=False,
        )
    ]
    normalized.extend(middle_stages)
    normalized.append(
        KanbanStageConfigSpec(
            stage_id=KANBAN_STAGE_DONE,
            name=_KANBAN_FIXED_STAGE_NAMES[KANBAN_STAGE_DONE],
            model_profile_id=None,
            command_id=None,
            auto_start=False,
        )
    )
    for stage_id in (KANBAN_STAGE_BACKLOG, KANBAN_STAGE_DONE):
        existing = stage_map.get(stage_id)
        if existing is None:
            continue
        if stage_id == KANBAN_STAGE_BACKLOG:
            normalized[0] = KanbanStageConfigSpec(
                stage_id=stage_id,
                name=_KANBAN_FIXED_STAGE_NAMES[stage_id],
                model_profile_id=None,
                command_id=None,
                auto_start=False,
            )
        else:
            normalized[-1] = KanbanStageConfigSpec(
                stage_id=stage_id,
                name=_KANBAN_FIXED_STAGE_NAMES[stage_id],
                model_profile_id=None,
                command_id=None,
                auto_start=False,
            )
    return normalized


def _default_kanban_stage_specs() -> list[KanbanStageConfigSpec]:
    return [
        KanbanStageConfigSpec(
            stage_id=str(spec["stage_id"]),
            name=str(spec["name"]),
            model_profile_id=None,
            command_id=(
                str(spec["command_id"])
                if isinstance(spec.get("command_id"), str) and spec.get("command_id")
                else None
            ),
            auto_start=bool(spec["auto_start"]),
        )
        for spec in KANBAN_DEFAULT_STAGE_SPECS
    ]


def _db_path() -> Path:
    configured = os.getenv(SESSION_DB_PATH_ENV)
    if configured:
        return Path(configured).expanduser().resolve()
    return DEFAULT_SESSION_DB_PATH


def _normalize_directory_key(directory: str) -> str:
    return directory.lower()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _storage_statuses_for_run_status(status: str) -> tuple[str, ...]:
    return (status,)


def _is_stale_timestamp(timestamp: str, *, stale_after_seconds: float) -> bool:
    try:
        observed = datetime.fromisoformat(timestamp)
    except ValueError:
        return True
    if observed.tzinfo is None:
        observed = observed.replace(tzinfo=timezone.utc)
    age_seconds = (datetime.now(timezone.utc) - observed).total_seconds()
    return age_seconds > stale_after_seconds


class WebManagerLeaseBusyError(RuntimeError):
    """Raised when lease acquisition cannot proceed due to transient DB contention."""


def _serialize_image_attachments(
    image_attachments: list[MessageImageAttachment] | None,
) -> str:
    if not image_attachments:
        return "[]"
    return json.dumps(
        [
            {
                "upload_id": attachment.upload_id,
                "name": attachment.name,
                "mime_type": attachment.mime_type,
                "byte_count": attachment.byte_count,
                "preview_url": attachment.preview_url,
            }
            for attachment in image_attachments
        ]
    )


def _serialize_file_paths(file_paths: list[str] | None) -> str:
    if not file_paths:
        return "[]"
    return json.dumps([path for path in file_paths if isinstance(path, str)])


def _serialize_json(value: object, *, default: str = "{}") -> str:
    if value is None:
        return default
    return json.dumps(value, sort_keys=True)


def _set_snapshot_value(
    snapshot: dict[str, Any],
    key: str,
    value: Any,
) -> bool:
    if snapshot.get(key) == value:
        return False
    snapshot[key] = value
    return True


def _clear_snapshot_value(snapshot: dict[str, Any], key: str) -> bool:
    if snapshot.get(key) is None:
        return False
    snapshot[key] = None
    return True


def _sanitize_stale_web_snapshot(snapshot: dict[str, Any]) -> bool:
    changed = False
    changed = _set_snapshot_value(snapshot, "input_enabled", False) or changed
    changed = _clear_snapshot_value(snapshot, "wait_message") or changed
    changed = _clear_snapshot_value(snapshot, "processing") or changed
    changed = _clear_snapshot_value(snapshot, "pending_user_questions") or changed
    changed = _set_snapshot_value(snapshot, "session_ended", True) or changed

    sub_agents = snapshot.get("sub_agents")
    if isinstance(sub_agents, dict):
        for raw_sub_agent in sub_agents.values():
            if not isinstance(raw_sub_agent, dict):
                continue
            sub_agent = raw_sub_agent
            if sub_agent.get("status") in {
                "starting",
                "running",
                "waiting_for_input",
            }:
                sub_agent["status"] = "stale"
                changed = True
            changed = _clear_snapshot_value(sub_agent, "wait_message") or changed
            changed = _clear_snapshot_value(sub_agent, "waitMessage") or changed
            changed = _clear_snapshot_value(sub_agent, "processing") or changed
            changed = (
                _clear_snapshot_value(sub_agent, "pending_user_questions") or changed
            )

    items = snapshot.get("items")
    if isinstance(items, list):
        for raw_item in items:
            if not isinstance(raw_item, dict):
                continue
            item = raw_item
            if item.get("kind") != "tool_group":
                continue
            if item.get("status") == "running":
                item["status"] = "completed"
                changed = True
            entries = item.get("items")
            if not isinstance(entries, list):
                continue
            for raw_entry in entries:
                if not isinstance(raw_entry, dict):
                    continue
                metadata = raw_entry.get("metadata")
                if not isinstance(metadata, dict):
                    continue
                if metadata.get("status") != "running":
                    continue
                metadata["status"] = "failed"
                if metadata.get("success") is not False:
                    metadata["success"] = False
                metadata.setdefault(
                    "detail",
                    "Interrupted because the server stopped before this tool call finished.",
                )
                changed = True
    return changed


def _stale_web_snapshot_json(raw_value: object) -> str | None:
    if not isinstance(raw_value, str) or not raw_value.strip():
        return None
    try:
        snapshot = json.loads(raw_value)
    except json.JSONDecodeError:
        return None
    if not isinstance(snapshot, dict):
        return None
    if not _sanitize_stale_web_snapshot(snapshot):
        return None
    return _serialize_json(snapshot)


def _deserialize_file_paths(raw_value: object) -> list[str]:
    if not isinstance(raw_value, str) or not raw_value.strip():
        return []
    try:
        payload = json.loads(raw_value)
    except json.JSONDecodeError:
        return []
    if not isinstance(payload, list):
        return []
    return [item for item in payload if isinstance(item, str)]


def _deserialize_image_attachments(raw_value: object) -> list[MessageImageAttachment]:
    if not isinstance(raw_value, str) or not raw_value.strip():
        return []
    try:
        payload = json.loads(raw_value)
    except json.JSONDecodeError:
        return []
    if not isinstance(payload, list):
        return []
    attachments: list[MessageImageAttachment] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        upload_id = item.get("upload_id")
        name = item.get("name")
        mime_type = item.get("mime_type")
        preview_url = item.get("preview_url")
        byte_count = item.get("byte_count")
        if not isinstance(upload_id, str) or not upload_id:
            continue
        if not isinstance(name, str) or not name:
            continue
        if not isinstance(mime_type, str) or not mime_type:
            continue
        if not isinstance(preview_url, str):
            continue
        if not isinstance(byte_count, int):
            byte_count = 0
        attachments.append(
            MessageImageAttachment(
                upload_id=upload_id,
                name=name,
                mime_type=mime_type,
                byte_count=byte_count,
                preview_url=preview_url,
            )
        )
    return attachments


def _upload_ids_from_attachments_json(raw_value: object) -> set[str]:
    if not isinstance(raw_value, str) or not raw_value.strip():
        return set()
    try:
        payload = json.loads(raw_value)
    except json.JSONDecodeError:
        return set()
    if not isinstance(payload, list):
        return set()
    upload_ids: set[str] = set()
    for item in payload:
        if isinstance(item, dict) and isinstance(item.get("upload_id"), str):
            upload_ids.add(item["upload_id"])
    return upload_ids


def _duplicate_image_attachments_for_fork(
    raw_value: object,
    duplicated_upload_ids: list[str],
) -> str:
    attachments = _deserialize_image_attachments(raw_value)
    if not attachments:
        return "[]"

    from pbi_agent.web.uploads import duplicate_uploaded_image

    forked_attachments: list[MessageImageAttachment] = []
    for attachment in attachments:
        duplicated = duplicate_uploaded_image(attachment.upload_id)
        duplicated_upload_ids.append(duplicated.upload_id)
        forked_attachments.append(
            MessageImageAttachment(
                upload_id=duplicated.upload_id,
                name=duplicated.name,
                mime_type=duplicated.mime_type,
                byte_count=duplicated.byte_count,
                preview_url=f"/api/uploads/{duplicated.upload_id}",
            )
        )
    return _serialize_image_attachments(forked_attachments)


def _message_record_from_row(row: sqlite3.Row) -> MessageRecord:
    data = dict(row)
    return MessageRecord(
        id=data["id"],
        session_id=data["session_id"],
        role=data["role"],
        content=data["content"],
        provider_id=data.get("provider_id"),
        profile_id=data.get("profile_id"),
        file_paths=_deserialize_file_paths(data.get("file_paths_json")),
        image_attachments=_deserialize_image_attachments(
            data.get("image_attachments_json")
        ),
        created_at=data["created_at"],
    )


def _kanban_task_record(row: sqlite3.Row) -> KanbanTaskRecord:
    data = dict(row)
    image_attachments = _deserialize_image_attachments(
        data.pop("image_attachments_json", None)
    )
    return KanbanTaskRecord(
        task_id=str(data["task_id"]),
        directory=str(data["directory"]),
        title=str(data["title"]),
        prompt=str(data["prompt"]),
        stage=str(data["stage"]),
        position=int(data["position"]),
        project_dir=str(data["project_dir"]),
        session_id=data.get("session_id"),
        model_profile_id=data.get("model_profile_id"),
        run_status=str(data["run_status"]),
        last_result_summary=str(data["last_result_summary"]),
        created_at=str(data["created_at"]),
        updated_at=str(data["updated_at"]),
        last_run_started_at=data.get("last_run_started_at"),
        last_run_finished_at=data.get("last_run_finished_at"),
        image_attachments=image_attachments,
    )


def _kanban_stage_config_record(row: sqlite3.Row) -> KanbanStageConfigRecord:
    data = dict(row)
    return KanbanStageConfigRecord(
        directory=str(data["directory"]),
        stage_id=str(data["stage_id"]),
        name=str(data["name"]),
        position=int(data["position"]),
        model_profile_id=data.get("model_profile_id"),
        command_id=data.get("command_id"),
        auto_start=bool(data.get("auto_start")),
        created_at=str(data["created_at"]),
        updated_at=str(data["updated_at"]),
    )


class SessionStore:
    """Thread-safe SQLite session store."""

    def __init__(self, db_path: Path | None = None) -> None:
        self._path = db_path or _db_path()
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(self._path),
            check_same_thread=False,
        )
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        self._conn.execute("PRAGMA busy_timeout = 5000")
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_SCHEMA)
        self._ensure_schema()
        self._normalize_directory_keys()

    def __enter__(self) -> SessionStore:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        self._conn.close()

    def _ensure_schema(self) -> None:
        session_columns = {
            row["name"]
            for row in self._conn.execute("PRAGMA table_info(sessions)").fetchall()
        }
        if "provider_id" not in session_columns:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN provider_id TEXT")
        if "profile_id" not in session_columns:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN profile_id TEXT")
        if "is_fork" not in session_columns:
            self._conn.execute(
                "ALTER TABLE sessions ADD COLUMN is_fork INTEGER NOT NULL DEFAULT 0"
            )
        if "forked_from_session_id" not in session_columns:
            self._conn.execute(
                "ALTER TABLE sessions ADD COLUMN forked_from_session_id TEXT"
            )
        if "forked_from_message_id" not in session_columns:
            self._conn.execute(
                "ALTER TABLE sessions ADD COLUMN forked_from_message_id INTEGER"
            )
        if "fork_created_at" not in session_columns:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN fork_created_at TEXT")

        message_columns = {
            row["name"]
            for row in self._conn.execute("PRAGMA table_info(messages)").fetchall()
        }
        if "provider_id" not in message_columns:
            self._conn.execute("ALTER TABLE messages ADD COLUMN provider_id TEXT")
        if "profile_id" not in message_columns:
            self._conn.execute("ALTER TABLE messages ADD COLUMN profile_id TEXT")
        if "file_paths_json" not in message_columns:
            self._conn.execute(
                "ALTER TABLE messages "
                "ADD COLUMN file_paths_json TEXT NOT NULL DEFAULT '[]'"
            )
        if "image_attachments_json" not in message_columns:
            self._conn.execute(
                "ALTER TABLE messages "
                "ADD COLUMN image_attachments_json TEXT NOT NULL DEFAULT '[]'"
            )

        run_session_columns = {
            row["name"]
            for row in self._conn.execute("PRAGMA table_info(run_sessions)").fetchall()
        }
        for column_name, column_sql in (
            ("kind", "TEXT NOT NULL DEFAULT 'cli'"),
            ("task_id", "TEXT"),
            ("project_dir", "TEXT"),
            ("last_event_seq", "INTEGER NOT NULL DEFAULT 0"),
            ("snapshot_json", "TEXT NOT NULL DEFAULT '{}'"),
            ("exit_code", "INTEGER"),
            ("fatal_error", "TEXT"),
        ):
            if column_name not in run_session_columns:
                self._conn.execute(
                    f"ALTER TABLE run_sessions ADD COLUMN {column_name} {column_sql}"
                )

        kanban_task_columns = {
            row["name"]
            for row in self._conn.execute("PRAGMA table_info(kanban_tasks)").fetchall()
        }
        if "image_attachments_json" not in kanban_task_columns:
            self._conn.execute(
                "ALTER TABLE kanban_tasks "
                "ADD COLUMN image_attachments_json TEXT NOT NULL DEFAULT '[]'"
            )
        self._conn.commit()

    def _normalize_directory_keys(self) -> None:
        self._conn.execute(
            "UPDATE sessions SET directory = LOWER(directory) "
            "WHERE directory != LOWER(directory)"
        )
        self._conn.execute(
            "UPDATE kanban_tasks SET directory = LOWER(directory) "
            "WHERE directory != LOWER(directory)"
        )
        self._conn.execute(
            "UPDATE kanban_stage_configs SET directory = LOWER(directory) "
            "WHERE directory != LOWER(directory)"
        )
        self._conn.execute(
            "UPDATE web_manager_leases SET directory = LOWER(directory) "
            "WHERE directory != LOWER(directory)"
        )
        self._conn.commit()

    def claim_daily_maintenance(self, run_date: str) -> bool:
        now = _now_iso()
        with self._lock:
            try:
                self._conn.execute("BEGIN IMMEDIATE")
                row = self._conn.execute(
                    "SELECT last_run_date FROM maintenance_state WHERE name = ?",
                    ("daily",),
                ).fetchone()
                if row is not None and row["last_run_date"] == run_date:
                    self._conn.rollback()
                    return False
                self._conn.execute(
                    "INSERT INTO maintenance_state "
                    "(name, last_run_date, last_started_at, last_finished_at, status) "
                    "VALUES (?, ?, ?, NULL, 'started') "
                    "ON CONFLICT(name) DO UPDATE SET "
                    "last_run_date = excluded.last_run_date, "
                    "last_started_at = excluded.last_started_at, "
                    "last_finished_at = NULL, status = 'started'",
                    ("daily", run_date, now),
                )
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                raise
        return True

    def finish_daily_maintenance(self, *, success: bool) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE maintenance_state SET last_finished_at = ?, status = ? "
                "WHERE name = ?",
                (_now_iso(), "completed" if success else "failed", "daily"),
            )
            self._conn.commit()

    def purge_old_data(self, cutoff_iso: str) -> dict[str, int]:
        with self._lock:
            old_session_ids = [
                str(row["session_id"])
                for row in self._conn.execute(
                    "SELECT session_id FROM sessions WHERE updated_at < ?",
                    (cutoff_iso,),
                ).fetchall()
            ]
            old_run_ids = [
                str(row["run_session_id"])
                for row in self._conn.execute(
                    "SELECT rs.run_session_id FROM run_sessions rs "
                    "LEFT JOIN sessions s ON rs.session_id = s.session_id "
                    "WHERE rs.started_at < ? "
                    "OR (rs.session_id IS NOT NULL AND s.session_id IS NULL) "
                    "OR rs.session_id IN "
                    "(SELECT session_id FROM sessions WHERE updated_at < ?)",
                    (cutoff_iso, cutoff_iso),
                ).fetchall()
            ]
            old_event_ids = [
                int(row["id"])
                for row in self._conn.execute(
                    "SELECT id FROM observability_events WHERE timestamp < ?",
                    (cutoff_iso,),
                ).fetchall()
            ]

            deleted_messages = self._delete_where_in(
                "messages", "session_id", old_session_ids
            )
            deleted_events = self._delete_where_in(
                "observability_events", "session_id", old_session_ids
            )
            deleted_events += self._delete_where_in(
                "observability_events", "run_session_id", old_run_ids
            )
            deleted_events += self._delete_where_in(
                "observability_events", "id", old_event_ids
            )
            deleted_runs = self._delete_where_in(
                "run_sessions", "run_session_id", old_run_ids
            )
            self._clear_where_in("kanban_tasks", "session_id", old_session_ids)
            deleted_sessions = self._delete_where_in(
                "sessions", "session_id", old_session_ids
            )
            deleted_leases = self._conn.execute(
                "DELETE FROM web_manager_leases WHERE heartbeat_at < ?",
                (cutoff_iso,),
            ).rowcount
            self._conn.commit()
        return {
            "sessions": deleted_sessions,
            "messages": deleted_messages,
            "run_sessions": deleted_runs,
            "observability_events": deleted_events,
            "web_manager_leases": deleted_leases,
        }

    def referenced_upload_ids(self) -> set[str]:
        upload_ids: set[str] = set()
        with self._lock:
            rows = self._conn.execute(
                "SELECT image_attachments_json FROM messages "
                "UNION ALL SELECT image_attachments_json FROM kanban_tasks"
            ).fetchall()
        for row in rows:
            upload_ids.update(_upload_ids_from_attachments_json(row[0]))
        return upload_ids

    def _delete_where_in(
        self,
        table: str,
        column: str,
        values: list[str] | list[int],
    ) -> int:
        if not values:
            return 0
        placeholders = ",".join("?" for _ in values)
        cursor = self._conn.execute(
            f"DELETE FROM {table} WHERE {column} IN ({placeholders})",
            values,
        )
        return cursor.rowcount

    def _clear_where_in(
        self,
        table: str,
        column: str,
        values: list[str] | list[int],
    ) -> int:
        if not values:
            return 0
        placeholders = ",".join("?" for _ in values)
        cursor = self._conn.execute(
            f"UPDATE {table} SET {column} = NULL WHERE {column} IN ({placeholders})",
            values,
        )
        return cursor.rowcount

    def acquire_web_manager_lease(
        self,
        directory: str,
        *,
        owner_id: str,
        stale_after_seconds: float,
    ) -> bool:
        normalized_directory = _normalize_directory_key(directory)
        now = _now_iso()
        with self._lock:
            try:
                self._conn.execute("BEGIN IMMEDIATE")
                row = self._conn.execute(
                    "SELECT owner_id, heartbeat_at FROM web_manager_leases "
                    "WHERE directory = ?",
                    (normalized_directory,),
                ).fetchone()
                if row is None:
                    self._conn.execute(
                        "INSERT INTO web_manager_leases "
                        "(directory, owner_id, heartbeat_at, created_at, updated_at) "
                        "VALUES (?, ?, ?, ?, ?)",
                        (normalized_directory, owner_id, now, now, now),
                    )
                    self._conn.commit()
                    return True

                current_owner = str(row["owner_id"])
                if current_owner == owner_id:
                    self._conn.execute(
                        "UPDATE web_manager_leases "
                        "SET heartbeat_at = ?, updated_at = ? "
                        "WHERE directory = ?",
                        (now, now, normalized_directory),
                    )
                    self._conn.commit()
                    return True

                heartbeat_at = str(row["heartbeat_at"])
                if not _is_stale_timestamp(
                    heartbeat_at,
                    stale_after_seconds=stale_after_seconds,
                ):
                    self._conn.rollback()
                    return False

                self._conn.execute(
                    "UPDATE web_manager_leases "
                    "SET owner_id = ?, heartbeat_at = ?, created_at = ?, updated_at = ? "
                    "WHERE directory = ?",
                    (owner_id, now, now, now, normalized_directory),
                )
                self._conn.commit()
                return True
            except sqlite3.OperationalError as exc:
                if self._conn.in_transaction:
                    self._conn.rollback()
                if "database is locked" in str(exc).lower():
                    raise WebManagerLeaseBusyError(
                        "Session database is busy while acquiring the web-manager lease."
                    ) from exc
                raise
            except Exception:
                if self._conn.in_transaction:
                    self._conn.rollback()
                raise

    def has_active_web_manager_lease(
        self,
        directory: str,
        *,
        stale_after_seconds: float,
    ) -> bool:
        normalized_directory = _normalize_directory_key(directory)
        with self._lock:
            row = self._conn.execute(
                "SELECT heartbeat_at FROM web_manager_leases WHERE directory = ?",
                (normalized_directory,),
            ).fetchone()
        if row is None:
            return False
        return not _is_stale_timestamp(
            str(row["heartbeat_at"]),
            stale_after_seconds=stale_after_seconds,
        )

    def renew_web_manager_lease(self, directory: str, *, owner_id: str) -> bool:
        normalized_directory = _normalize_directory_key(directory)
        now = _now_iso()
        with self._lock:
            cursor = self._conn.execute(
                "UPDATE web_manager_leases "
                "SET heartbeat_at = ?, updated_at = ? "
                "WHERE directory = ? AND owner_id = ?",
                (now, now, normalized_directory, owner_id),
            )
            self._conn.commit()
            return bool(cursor.rowcount)

    def release_web_manager_lease(self, directory: str, *, owner_id: str) -> bool:
        normalized_directory = _normalize_directory_key(directory)
        with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM web_manager_leases WHERE directory = ? AND owner_id = ?",
                (normalized_directory, owner_id),
            )
            self._conn.commit()
            return bool(cursor.rowcount)

    def create_session(
        self,
        directory: str,
        provider: str,
        model: str,
        title: str = "",
        *,
        provider_id: str | None = None,
        profile_id: str | None = None,
    ) -> str:
        session_id = uuid.uuid4().hex
        now = _now_iso()
        normalized_directory = _normalize_directory_key(directory)
        with self._lock:
            self._conn.execute(
                "INSERT INTO sessions "
                "(session_id, directory, provider, provider_id, model, profile_id, previous_id, title, "
                "total_tokens, input_tokens, output_tokens, cost_usd, is_fork, "
                "forked_from_session_id, forked_from_message_id, fork_created_at, "
                "created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, NULL, ?, 0, 0, 0, 0.0, 0, NULL, NULL, NULL, ?, ?)",
                (
                    session_id,
                    normalized_directory,
                    provider,
                    provider_id,
                    model,
                    profile_id,
                    title,
                    now,
                    now,
                ),
            )
            self._conn.commit()
        return session_id

    def fork_session(self, session_id: str, fork_message_id: int) -> str:
        """Create a new session containing messages through ``fork_message_id``."""
        new_session_id = uuid.uuid4().hex
        now = _now_iso()
        duplicated_upload_ids: list[str] = []
        with self._lock:
            try:
                self._conn.execute("BEGIN IMMEDIATE")
                session_row = self._conn.execute(
                    "SELECT * FROM sessions WHERE session_id = ?",
                    (session_id,),
                ).fetchone()
                if session_row is None:
                    self._conn.rollback()
                    raise KeyError(session_id)
                message_row = self._conn.execute(
                    "SELECT * FROM messages WHERE id = ? AND session_id = ?",
                    (fork_message_id, session_id),
                ).fetchone()
                if message_row is None:
                    self._conn.rollback()
                    raise KeyError(f"msg-{fork_message_id}")

                self._conn.execute(
                    "INSERT INTO sessions "
                    "(session_id, directory, provider, provider_id, model, profile_id, previous_id, title, "
                    "total_tokens, input_tokens, output_tokens, cost_usd, is_fork, "
                    "forked_from_session_id, forked_from_message_id, fork_created_at, "
                    "created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, NULL, ?, 0, 0, 0, 0.0, 1, ?, ?, ?, ?, ?)",
                    (
                        new_session_id,
                        session_row["directory"],
                        session_row["provider"],
                        session_row["provider_id"],
                        session_row["model"],
                        session_row["profile_id"],
                        f"Fork-{session_row['title']}",
                        session_id,
                        fork_message_id,
                        now,
                        now,
                        now,
                    ),
                )
                rows = self._conn.execute(
                    "SELECT * FROM messages "
                    "WHERE session_id = ? AND id <= ? ORDER BY id ASC",
                    (session_id, fork_message_id),
                ).fetchall()
                for row in rows:
                    image_attachments_json = _duplicate_image_attachments_for_fork(
                        row["image_attachments_json"],
                        duplicated_upload_ids,
                    )
                    self._conn.execute(
                        "INSERT INTO messages "
                        "(session_id, role, content, provider_id, profile_id, "
                        "file_paths_json, image_attachments_json, created_at) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        (
                            new_session_id,
                            row["role"],
                            row["content"],
                            row["provider_id"],
                            row["profile_id"],
                            row["file_paths_json"],
                            image_attachments_json,
                            row["created_at"],
                        ),
                    )
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                if duplicated_upload_ids:
                    from pbi_agent.web.uploads import delete_uploaded_images

                    delete_uploaded_images(duplicated_upload_ids)
                raise
        return new_session_id

    def update_session(
        self,
        session_id: str,
        *,
        previous_id: str | None = None,
        clear_previous_id: bool = False,
        title: str | None = None,
        provider: str | None = None,
        provider_id: str | None = None,
        total_tokens: int | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        cost_usd: float | None = None,
        model: str | None = None,
        profile_id: str | None = None,
    ) -> None:
        clauses: list[str] = []
        params: list[object] = []
        if clear_previous_id:
            clauses.append("previous_id = NULL")
        elif previous_id is not None:
            clauses.append("previous_id = ?")
            params.append(previous_id)
        if title is not None:
            clauses.append("title = ?")
            params.append(title)
        if provider is not None:
            clauses.append("provider = ?")
            params.append(provider)
        if provider_id is not None:
            clauses.append("provider_id = ?")
            params.append(provider_id)
        if model is not None:
            clauses.append("model = ?")
            params.append(model)
        if profile_id is not None:
            clauses.append("profile_id = ?")
            params.append(profile_id)
        if total_tokens is not None:
            clauses += [
                "total_tokens = ?",
                "input_tokens = ?",
                "output_tokens = ?",
                "cost_usd = ?",
            ]
            params += [
                total_tokens,
                input_tokens or 0,
                output_tokens or 0,
                cost_usd or 0.0,
            ]
        if not clauses:
            return
        clauses.append("updated_at = ?")
        params.append(_now_iso())
        params.append(session_id)
        sql = f"UPDATE sessions SET {', '.join(clauses)} WHERE session_id = ?"
        with self._lock:
            self._conn.execute(sql, params)
            self._conn.commit()

    def get_session(self, session_id: str) -> SessionRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
            ).fetchone()
        if row is None:
            return None
        return SessionRecord(**dict(row))

    def list_sessions(
        self,
        directory: str,
        limit: int = 20,
        provider: str | None = None,
    ) -> list[SessionRecord]:
        normalized_directory = _normalize_directory_key(directory)
        if provider:
            sql = "SELECT * FROM sessions WHERE directory = ? AND provider = ? ORDER BY updated_at DESC LIMIT ?"
            params: tuple[object, ...] = (normalized_directory, provider, limit)
        else:
            sql = "SELECT * FROM sessions WHERE directory = ? ORDER BY updated_at DESC LIMIT ?"
            params = (normalized_directory, limit)
        with self._lock:
            rows = self._conn.execute(sql, params).fetchall()
        return [SessionRecord(**dict(r)) for r in rows]

    def list_all_sessions(self, limit: int = 20) -> list[SessionRecord]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM sessions ORDER BY updated_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [SessionRecord(**dict(r)) for r in rows]

    def delete_session(self, session_id: str) -> bool:
        with self._lock:
            row = self._conn.execute(
                "SELECT 1 FROM sessions WHERE session_id = ?",
                (session_id,),
            ).fetchone()
            if row is None:
                return False
            self._conn.execute(
                "DELETE FROM messages WHERE session_id = ?",
                (session_id,),
            )
            self._conn.execute(
                "DELETE FROM observability_events WHERE session_id = ?",
                (session_id,),
            )
            self._conn.execute(
                "DELETE FROM run_sessions WHERE session_id = ?",
                (session_id,),
            )
            self._conn.execute(
                "DELETE FROM sessions WHERE session_id = ?",
                (session_id,),
            )
            self._conn.commit()
        return True

    def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        file_paths: list[str] | None = None,
        provider_id: str | None = None,
        profile_id: str | None = None,
        image_attachments: list[MessageImageAttachment] | None = None,
    ) -> int:
        now = _now_iso()
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO messages "
                "(session_id, role, content, provider_id, profile_id, file_paths_json, image_attachments_json, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    session_id,
                    role,
                    content,
                    provider_id,
                    profile_id,
                    _serialize_file_paths(file_paths),
                    _serialize_image_attachments(image_attachments),
                    now,
                ),
            )
            self._conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def delete_message(self, message_id: int) -> bool:
        with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM messages WHERE id = ?",
                (message_id,),
            )
            self._conn.commit()
        return cursor.rowcount > 0

    def get_message(self, message_id: int) -> MessageRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM messages WHERE id = ?",
                (message_id,),
            ).fetchone()
        return _message_record_from_row(row) if row is not None else None

    def list_messages(self, session_id: str) -> list[MessageRecord]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM messages WHERE session_id = ? ORDER BY id ASC",
                (session_id,),
            ).fetchall()
        return [_message_record_from_row(row) for row in rows]

    def create_run_session(
        self,
        *,
        run_session_id: str | None = None,
        session_id: str | None,
        agent_name: str | None,
        agent_type: str | None,
        provider: str | None,
        provider_id: str | None,
        profile_id: str | None,
        model: str | None,
        status: str = "started",
        parent_run_session_id: str | None = None,
        kind: str = "cli",
        task_id: str | None = None,
        project_dir: str | None = None,
        last_event_seq: int = 0,
        snapshot: dict[str, object] | None = None,
        exit_code: int | None = None,
        fatal_error: str | None = None,
        metadata: dict[str, object] | None = None,
    ) -> str:
        run_session_id = run_session_id or uuid.uuid4().hex
        now = _now_iso()
        with self._lock:
            self._conn.execute(
                "INSERT INTO run_sessions "
                "(run_session_id, session_id, parent_run_session_id, agent_name, "
                "agent_type, provider, provider_id, profile_id, model, status, "
                "started_at, kind, task_id, project_dir, last_event_seq, "
                "snapshot_json, exit_code, fatal_error, metadata_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    run_session_id,
                    session_id,
                    parent_run_session_id,
                    agent_name,
                    agent_type,
                    provider,
                    provider_id,
                    profile_id,
                    model,
                    status,
                    now,
                    kind,
                    task_id,
                    project_dir,
                    last_event_seq,
                    _serialize_json(snapshot, default="{}"),
                    exit_code,
                    fatal_error,
                    _serialize_json(metadata, default="{}"),
                ),
            )
            self._conn.commit()
        return run_session_id

    def update_run_session(
        self,
        run_session_id: str,
        *,
        session_id: str | None = None,
        status: str | None = None,
        ended_at: str | None = None,
        total_duration_ms: int | None = None,
        input_tokens: int | None = None,
        cached_input_tokens: int | None = None,
        cache_write_tokens: int | None = None,
        cache_write_1h_tokens: int | None = None,
        output_tokens: int | None = None,
        reasoning_tokens: int | None = None,
        tool_use_tokens: int | None = None,
        provider_total_tokens: int | None = None,
        estimated_cost_usd: float | None = None,
        total_tool_calls: int | None = None,
        total_api_calls: int | None = None,
        error_count: int | None = None,
        kind: str | None = None,
        task_id: str | None = None,
        project_dir: str | None = None,
        last_event_seq: int | None = None,
        snapshot: dict[str, object] | None = None,
        exit_code: int | None = None,
        fatal_error: str | None = None,
        metadata: dict[str, object] | None = None,
        clear_session_id: bool = False,
    ) -> None:
        clauses: list[str] = []
        params: list[object] = []
        if clear_session_id:
            clauses.append("session_id = NULL")
        scalar_values = {
            "session_id": session_id,
            "status": status,
            "ended_at": ended_at,
            "total_duration_ms": total_duration_ms,
            "input_tokens": input_tokens,
            "cached_input_tokens": cached_input_tokens,
            "cache_write_tokens": cache_write_tokens,
            "cache_write_1h_tokens": cache_write_1h_tokens,
            "output_tokens": output_tokens,
            "reasoning_tokens": reasoning_tokens,
            "tool_use_tokens": tool_use_tokens,
            "provider_total_tokens": provider_total_tokens,
            "estimated_cost_usd": estimated_cost_usd,
            "total_tool_calls": total_tool_calls,
            "total_api_calls": total_api_calls,
            "error_count": error_count,
            "kind": kind,
            "task_id": task_id,
            "project_dir": project_dir,
            "last_event_seq": last_event_seq,
            "exit_code": exit_code,
            "fatal_error": fatal_error,
        }
        for key, value in scalar_values.items():
            if clear_session_id and key == "session_id":
                continue
            if value is None:
                continue
            clauses.append(f"{key} = ?")
            params.append(value)
        if metadata is not None:
            clauses.append("metadata_json = ?")
            params.append(_serialize_json(metadata, default="{}"))
        if snapshot is not None:
            clauses.append("snapshot_json = ?")
            params.append(_serialize_json(snapshot, default="{}"))
        if not clauses:
            return
        params.append(run_session_id)
        with self._lock:
            self._conn.execute(
                f"UPDATE run_sessions SET {', '.join(clauses)} "
                "WHERE run_session_id = ?",
                params,
            )
            self._conn.commit()

    def add_web_observability_event_and_update_run_session(
        self,
        *,
        run_session_id: str,
        session_id: str | None,
        step_index: int,
        metadata: dict[str, object],
        status: str,
        ended_at: str | None,
        last_event_seq: int,
        snapshot: dict[str, object],
        exit_code: int | None,
        fatal_error: str | None,
    ) -> int:
        with self._lock:
            try:
                self._conn.execute("BEGIN IMMEDIATE")
                cursor = self._conn.execute(
                    "INSERT INTO observability_events "
                    "(run_session_id, session_id, step_index, event_type, "
                    "timestamp, metadata_json) VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        run_session_id,
                        session_id,
                        step_index,
                        "web_event",
                        _now_iso(),
                        _serialize_json(metadata, default="{}"),
                    ),
                )
                update_cursor = self._conn.execute(
                    "UPDATE run_sessions SET session_id = ?, status = ?, "
                    "ended_at = ?, last_event_seq = ?, snapshot_json = ?, "
                    "exit_code = ?, fatal_error = ? WHERE run_session_id = ?",
                    (
                        session_id,
                        status,
                        ended_at,
                        last_event_seq,
                        _serialize_json(snapshot, default="{}"),
                        exit_code,
                        fatal_error,
                        run_session_id,
                    ),
                )
                if update_cursor.rowcount != 1:
                    raise KeyError(run_session_id)
                self._conn.commit()
            except Exception:
                self._conn.rollback()
                raise
        return cursor.lastrowid  # type: ignore[return-value]

    def get_run_session(self, run_session_id: str) -> RunSessionRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM run_sessions WHERE run_session_id = ?",
                (run_session_id,),
            ).fetchone()
        if row is None:
            return None
        return RunSessionRecord(**dict(row))

    def get_next_observability_step_index(self, run_session_id: str) -> int:
        with self._lock:
            row = self._conn.execute(
                "SELECT MAX(step_index) AS max_step FROM observability_events "
                "WHERE run_session_id = ? AND step_index >= 0",
                (run_session_id,),
            ).fetchone()
        max_step = row["max_step"] if row is not None else None
        return int(max_step) + 1 if max_step is not None else 0

    def list_run_sessions(self, session_id: str) -> list[RunSessionRecord]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM run_sessions WHERE session_id = ? "
                "AND agent_type != 'web_session' "
                "ORDER BY started_at ASC, id ASC",
                (session_id,),
            ).fetchall()
        return [RunSessionRecord(**dict(row)) for row in rows]

    def get_latest_session_run(
        self,
        session_id: str,
        *,
        include_ended: bool = True,
    ) -> RunSessionRecord | None:
        where = "session_id = ?"
        params: list[object] = [session_id]
        if not include_ended:
            where += (
                " AND status NOT IN "
                "('ended', 'failed', 'completed', 'interrupted', 'stale')"
            )
        where += " AND agent_type != 'web_session'"
        with self._lock:
            row = self._conn.execute(
                f"SELECT * FROM run_sessions WHERE {where} "
                "ORDER BY started_at DESC, id DESC LIMIT 1",
                params,
            ).fetchone()
        return RunSessionRecord(**dict(row)) if row is not None else None

    def get_latest_web_session_run(
        self,
        session_id: str,
    ) -> RunSessionRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM run_sessions WHERE session_id = ? "
                "AND agent_type = 'web_session' "
                "ORDER BY started_at DESC, id DESC LIMIT 1",
                (session_id,),
            ).fetchone()
        return RunSessionRecord(**dict(row)) if row is not None else None

    def list_web_session_runs(self, session_id: str) -> list[RunSessionRecord]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM run_sessions WHERE session_id = ? "
                "AND agent_type = 'web_session' "
                "ORDER BY started_at ASC, id ASC",
                (session_id,),
            ).fetchall()
        return [RunSessionRecord(**dict(row)) for row in rows]

    def _sanitize_stale_web_snapshots(self, run_ids: list[int]) -> None:
        if not run_ids:
            return
        unique_ids = sorted(set(run_ids))
        placeholders = ", ".join("?" for _ in unique_ids)
        rows = self._conn.execute(
            f"SELECT id, snapshot_json FROM run_sessions WHERE id IN ({placeholders})",
            unique_ids,
        ).fetchall()
        for row in rows:
            snapshot_json = _stale_web_snapshot_json(row["snapshot_json"])
            if snapshot_json is None:
                continue
            self._conn.execute(
                "UPDATE run_sessions SET snapshot_json = ? WHERE id = ?",
                (snapshot_json, int(row["id"])),
            )

    def mark_web_runs_stale(self, directory: str) -> int:
        normalized_directory = _normalize_directory_key(directory)
        now = _now_iso()
        with self._lock:
            bound_rows = self._conn.execute(
                "SELECT rs.id, rs.session_id FROM run_sessions AS rs "
                "JOIN sessions AS s ON s.session_id = rs.session_id "
                "WHERE rs.kind IN ('session', 'task') "
                "AND rs.agent_type = 'web_session' "
                "AND rs.status IN ('starting', 'running', 'waiting_for_input') "
                "AND s.directory = ?",
                (normalized_directory,),
            ).fetchall()
            bound_ids = [int(row["id"]) for row in bound_rows]
            stale_count = 0
            if bound_ids:
                placeholders = ", ".join("?" for _ in bound_ids)
                cursor = self._conn.execute(
                    f"UPDATE run_sessions SET status = 'stale', ended_at = ? "
                    f"WHERE id IN ({placeholders})",
                    (now, *bound_ids),
                )
                stale_count = cursor.rowcount
            rows = self._conn.execute(
                "SELECT id, project_dir, metadata_json FROM run_sessions "
                "WHERE kind IN ('session', 'task') "
                "AND agent_type = 'web_session' "
                "AND session_id IS NULL "
                "AND status IN ('starting', 'running', 'waiting_for_input')"
            ).fetchall()
            unbound_ids: list[int] = []
            for row in rows:
                should_fallback_to_project_dir = False
                try:
                    metadata = json.loads(row["metadata_json"])
                except json.JSONDecodeError:
                    should_fallback_to_project_dir = True
                else:
                    if not isinstance(metadata, dict):
                        should_fallback_to_project_dir = True
                    else:
                        metadata_source = metadata.get("source")
                        metadata_directory = metadata.get("directory")
                        if metadata_source == "web" and isinstance(
                            metadata_directory, str
                        ):
                            if (
                                _normalize_directory_key(metadata_directory)
                                == normalized_directory
                            ):
                                unbound_ids.append(int(row["id"]))
                            continue
                        should_fallback_to_project_dir = (
                            metadata_source is None and metadata_directory is None
                        )
                if (
                    should_fallback_to_project_dir
                    and isinstance(row["project_dir"], str)
                    and _normalize_directory_key(row["project_dir"])
                    == normalized_directory
                ):
                    unbound_ids.append(int(row["id"]))
            if unbound_ids:
                placeholders = ", ".join("?" for _ in unbound_ids)
                cursor = self._conn.execute(
                    f"UPDATE run_sessions SET status = 'stale', ended_at = ? "
                    f"WHERE id IN ({placeholders})",
                    (now, *unbound_ids),
                )
                stale_count += cursor.rowcount
            stale_web_snapshot_rows = self._conn.execute(
                "SELECT rs.id FROM run_sessions AS rs "
                "JOIN sessions AS s ON s.session_id = rs.session_id "
                "WHERE rs.kind IN ('session', 'task') "
                "AND rs.agent_type = 'web_session' "
                "AND rs.status = 'stale' "
                "AND s.directory = ?",
                (normalized_directory,),
            ).fetchall()
            self._sanitize_stale_web_snapshots(
                [int(row["id"]) for row in stale_web_snapshot_rows] + unbound_ids
            )
            cursor = self._conn.execute(
                "UPDATE run_sessions SET status = 'stale', ended_at = ? "
                "WHERE (agent_type IS NULL OR agent_type != 'web_session') "
                "AND status IN ('started', 'starting', 'running', 'waiting_for_input') "
                "AND session_id IN "
                "(SELECT session_id FROM sessions WHERE directory = ?) "
                "AND EXISTS ("
                "SELECT 1 FROM run_sessions AS web "
                "WHERE web.session_id = run_sessions.session_id "
                "AND web.kind IN ('session', 'task') "
                "AND web.agent_type = 'web_session' "
                "AND web.status = 'stale' "
                "AND web.ended_at IS NOT NULL "
                "AND web.started_at <= run_sessions.started_at "
                "AND run_sessions.started_at <= web.ended_at"
                ")",
                (now, normalized_directory),
            )
            stale_count += cursor.rowcount
            self._conn.commit()
        return stale_count

    def add_observability_event(
        self,
        *,
        run_session_id: str,
        session_id: str | None,
        step_index: int,
        event_type: str,
        timestamp: str | None = None,
        duration_ms: int | None = None,
        provider: str | None = None,
        model: str | None = None,
        url: str | None = None,
        request_config: object | None = None,
        request_payload: object | None = None,
        response_payload: object | None = None,
        tool_name: str | None = None,
        tool_call_id: str | None = None,
        tool_input: object | None = None,
        tool_output: object | None = None,
        tool_duration_ms: int | None = None,
        prompt_tokens: int | None = None,
        completion_tokens: int | None = None,
        total_tokens: int | None = None,
        status_code: int | None = None,
        success: bool | None = None,
        error_message: str | None = None,
        metadata: dict[str, object] | None = None,
    ) -> int:
        with self._lock:
            cursor = self._conn.execute(
                "INSERT INTO observability_events "
                "(run_session_id, session_id, step_index, event_type, timestamp, "
                "duration_ms, provider, model, url, request_config_json, "
                "request_payload_json, response_payload_json, tool_name, "
                "tool_call_id, tool_input_json, tool_output_json, tool_duration_ms, "
                "prompt_tokens, completion_tokens, total_tokens, status_code, "
                "success, error_message, metadata_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "
                "?, ?, ?, ?, ?)",
                (
                    run_session_id,
                    session_id,
                    step_index,
                    event_type,
                    timestamp or _now_iso(),
                    duration_ms,
                    provider,
                    model,
                    url,
                    _serialize_json(request_config, default="null"),
                    _serialize_json(request_payload, default="null"),
                    _serialize_json(response_payload, default="null"),
                    tool_name,
                    tool_call_id,
                    _serialize_json(tool_input, default="null"),
                    _serialize_json(tool_output, default="null"),
                    tool_duration_ms,
                    prompt_tokens,
                    completion_tokens,
                    total_tokens,
                    status_code,
                    None if success is None else int(success),
                    error_message,
                    _serialize_json(metadata, default="{}"),
                ),
            )
            self._conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def list_observability_events(
        self,
        *,
        run_session_id: str,
    ) -> list[ObservabilityEventRecord]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM observability_events WHERE run_session_id = ? "
                "ORDER BY step_index ASC, id ASC",
                (run_session_id,),
            ).fetchall()
        return [ObservabilityEventRecord(**dict(row)) for row in rows]

    # -- dashboard / observability aggregation ----------------------------

    def get_dashboard_stats(
        self,
        *,
        directory: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
    ) -> dict[str, object]:
        """Return aggregated overview, provider/model breakdown, and daily buckets."""
        normalized_dir = _normalize_directory_key(directory) if directory else None

        base_where = "WHERE 1=1"
        params: list[object] = []
        base_where += " AND rs.agent_type != 'web_session'"
        if normalized_dir is not None:
            base_where += " AND s.directory = ?"
            params.append(normalized_dir)
        if start_date is not None:
            base_where += " AND rs.started_at >= ?"
            params.append(start_date)
        if end_date is not None:
            base_where += " AND rs.started_at <= ?"
            params.append(end_date)

        join_clause = (
            "FROM run_sessions rs JOIN sessions s ON rs.session_id = s.session_id"
        )

        with self._lock:
            # -- overview --
            overview_row = self._conn.execute(
                f"SELECT "
                "COUNT(DISTINCT rs.session_id) AS total_sessions, "
                "COUNT(*) AS total_runs, "
                "COALESCE(SUM(rs.input_tokens), 0) AS total_input_tokens, "
                "COALESCE(SUM(rs.cached_input_tokens), 0) AS total_cached_tokens, "
                "COALESCE(SUM(rs.output_tokens), 0) AS total_output_tokens, "
                "COALESCE(SUM(rs.reasoning_tokens), 0) AS total_reasoning_tokens, "
                "COALESCE(SUM(rs.estimated_cost_usd), 0.0) AS total_cost, "
                "COALESCE(SUM(rs.total_api_calls), 0) AS total_api_calls, "
                "COALESCE(SUM(rs.total_tool_calls), 0) AS total_tool_calls, "
                "COALESCE(SUM(rs.error_count), 0) AS total_errors, "
                "AVG(rs.total_duration_ms) AS avg_duration_ms, "
                "COUNT(CASE WHEN rs.status = 'completed' THEN 1 END) AS completed_runs, "
                "COUNT(CASE WHEN rs.status = 'failed' THEN 1 END) AS failed_runs "
                f"{join_clause} {base_where}",
                params,
            ).fetchone()

            overview = (
                dict(overview_row)
                if overview_row
                else {
                    "total_sessions": 0,
                    "total_runs": 0,
                    "total_input_tokens": 0,
                    "total_cached_tokens": 0,
                    "total_output_tokens": 0,
                    "total_reasoning_tokens": 0,
                    "total_cost": 0.0,
                    "total_api_calls": 0,
                    "total_tool_calls": 0,
                    "total_errors": 0,
                    "avg_duration_ms": None,
                    "completed_runs": 0,
                    "failed_runs": 0,
                }
            )

            # -- provider/model breakdown --
            breakdown_rows = self._conn.execute(
                f"SELECT "
                "rs.provider, rs.model, "
                "COUNT(*) AS run_count, "
                "COALESCE(SUM(rs.input_tokens + rs.output_tokens), 0) AS total_tokens, "
                "COALESCE(SUM(rs.estimated_cost_usd), 0.0) AS total_cost, "
                "AVG(rs.total_duration_ms) AS avg_duration_ms, "
                "COALESCE(SUM(rs.error_count), 0) AS error_count, "
                "COALESCE(SUM(rs.total_api_calls), 0) AS total_api_calls, "
                "COALESCE(SUM(rs.total_tool_calls), 0) AS total_tool_calls "
                f"{join_clause} {base_where} "
                "GROUP BY rs.provider, rs.model "
                "ORDER BY total_tokens DESC",
                params,
            ).fetchall()
            breakdown = [dict(row) for row in breakdown_rows]

            # -- daily time-series buckets --
            daily_rows = self._conn.execute(
                f"SELECT "
                "DATE(rs.started_at) AS date, "
                "COUNT(*) AS runs, "
                "COALESCE(SUM(rs.input_tokens + rs.output_tokens), 0) AS tokens, "
                "COALESCE(SUM(rs.estimated_cost_usd), 0.0) AS cost, "
                "COALESCE(SUM(rs.error_count), 0) AS errors "
                f"{join_clause} {base_where} "
                "GROUP BY DATE(rs.started_at) "
                "ORDER BY date ASC",
                params,
            ).fetchall()
            daily = [dict(row) for row in daily_rows]

        return {
            "overview": overview,
            "breakdown": breakdown,
            "daily": daily,
        }

    _ALLOWED_RUN_SORT_COLUMNS = frozenset(
        {
            "started_at",
            "ended_at",
            "total_duration_ms",
            "estimated_cost_usd",
            "input_tokens",
            "output_tokens",
            "error_count",
            "total_tool_calls",
            "total_api_calls",
        }
    )

    def list_all_run_sessions(
        self,
        *,
        directory: str | None = None,
        limit: int = 50,
        offset: int = 0,
        status: str | None = None,
        provider: str | None = None,
        model: str | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        sort_by: str = "started_at",
        sort_dir: str = "desc",
    ) -> tuple[list[dict[str, object]], int]:
        """Return a page of run_sessions with optional filters + total count.

        Each dict in the returned list has all run_sessions columns plus
        ``session_title`` (from the joined sessions table).
        """
        normalized_dir = _normalize_directory_key(directory) if directory else None

        where_clauses = ["1=1"]
        params: list[object] = []
        where_clauses.append("rs.agent_type != 'web_session'")
        if normalized_dir is not None:
            where_clauses.append("s.directory = ?")
            params.append(normalized_dir)
        if status is not None:
            statuses = _storage_statuses_for_run_status(status)
            placeholders = ", ".join("?" for _ in statuses)
            where_clauses.append(f"rs.status IN ({placeholders})")
            params.extend(statuses)
        if provider is not None:
            where_clauses.append("rs.provider = ?")
            params.append(provider)
        if model is not None:
            where_clauses.append("rs.model = ?")
            params.append(model)
        if start_date is not None:
            where_clauses.append("rs.started_at >= ?")
            params.append(start_date)
        if end_date is not None:
            where_clauses.append("rs.started_at <= ?")
            params.append(end_date)

        where = " AND ".join(where_clauses)
        join = (
            "FROM run_sessions rs LEFT JOIN sessions s ON rs.session_id = s.session_id"
        )

        # Sanitise sort column to prevent injection.
        if sort_by not in self._ALLOWED_RUN_SORT_COLUMNS:
            sort_by = "started_at"
        direction = "ASC" if sort_dir.upper() == "ASC" else "DESC"

        with self._lock:
            total_row = self._conn.execute(
                f"SELECT COUNT(*) AS cnt {join} WHERE {where}",
                params,
            ).fetchone()
            total_count: int = total_row["cnt"] if total_row else 0

            rows = self._conn.execute(
                f"SELECT rs.*, s.title AS session_title {join} "
                f"WHERE {where} "
                f"ORDER BY rs.{sort_by} {direction}, rs.id DESC "
                "LIMIT ? OFFSET ?",
                [*params, limit, offset],
            ).fetchall()

        results: list[dict[str, object]] = [dict(row) for row in rows]
        return results, total_count

    # -- kanban tasks -----------------------------------------------------

    def list_kanban_stage_configs(
        self, directory: str
    ) -> list[KanbanStageConfigRecord]:
        normalized_directory = _normalize_directory_key(directory)
        with self._lock:
            self._ensure_canonical_kanban_stages_locked(normalized_directory)
            rows = self._conn.execute(
                "SELECT * FROM kanban_stage_configs "
                "WHERE directory = ? ORDER BY position ASC, stage_id ASC",
                (normalized_directory,),
            ).fetchall()
        return [_kanban_stage_config_record(row) for row in rows]

    def get_kanban_stage_config(
        self, directory: str, stage_id: str
    ) -> KanbanStageConfigRecord | None:
        normalized_directory = _normalize_directory_key(directory)
        with self._lock:
            self._ensure_canonical_kanban_stages_locked(normalized_directory)
            row = self._conn.execute(
                "SELECT * FROM kanban_stage_configs "
                "WHERE directory = ? AND stage_id = ?",
                (normalized_directory, stage_id),
            ).fetchone()
        if row is None:
            return None
        return _kanban_stage_config_record(row)

    def replace_kanban_stage_configs(
        self,
        directory: str,
        *,
        stages: list[KanbanStageConfigSpec],
    ) -> list[KanbanStageConfigRecord]:
        normalized_directory = _normalize_directory_key(directory)
        if not stages:
            raise ValueError("board must contain at least one stage")
        normalized: list[KanbanStageConfigSpec] = []
        seen_stage_ids: set[str] = set()
        for item in stages:
            stage_id = item.stage_id.strip()
            name = item.name.strip()
            if not stage_id:
                raise ValueError("stage ID cannot be empty")
            if not name:
                raise ValueError("stage name cannot be empty")
            if stage_id in seen_stage_ids:
                raise ValueError(f"duplicate stage ID: {stage_id}")
            seen_stage_ids.add(stage_id)
            normalized.append(
                KanbanStageConfigSpec(
                    stage_id=stage_id,
                    name=name,
                    model_profile_id=(
                        item.model_profile_id.strip()
                        if isinstance(item.model_profile_id, str)
                        and item.model_profile_id.strip()
                        else None
                    ),
                    command_id=(
                        item.command_id.strip()
                        if isinstance(item.command_id, str) and item.command_id.strip()
                        else None
                    ),
                    auto_start=bool(item.auto_start),
                )
            )
        normalized = _normalize_kanban_stage_specs(normalized)
        seen_stage_ids = {item.stage_id for item in normalized}
        with self._lock:
            existing = {
                row["stage_id"]: row
                for row in self._conn.execute(
                    "SELECT * FROM kanban_stage_configs WHERE directory = ?",
                    (normalized_directory,),
                ).fetchall()
            }
            task_rows = self._conn.execute(
                "SELECT DISTINCT stage FROM kanban_tasks WHERE directory = ?",
                (normalized_directory,),
            ).fetchall()
            missing_task_stages = sorted(
                {
                    str(row["stage"])
                    for row in task_rows
                    if str(row["stage"]) not in seen_stage_ids
                }
            )
            if missing_task_stages:
                raise ValueError(
                    "cannot remove stages that still contain tasks: "
                    + ", ".join(missing_task_stages)
                )
            now = _now_iso()
            self._conn.execute(
                "DELETE FROM kanban_stage_configs WHERE directory = ?",
                (normalized_directory,),
            )
            for position, item in enumerate(normalized):
                created_at = (
                    str(existing[item.stage_id]["created_at"])
                    if item.stage_id in existing
                    else now
                )
                self._conn.execute(
                    "INSERT INTO kanban_stage_configs "
                    "(directory, stage_id, name, position, model_profile_id, command_id, "
                    "auto_start, created_at, updated_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        normalized_directory,
                        item.stage_id,
                        item.name,
                        position,
                        item.model_profile_id,
                        item.command_id,
                        1 if item.auto_start else 0,
                        created_at,
                        now,
                    ),
                )
            self._conn.commit()
            rows = self._conn.execute(
                "SELECT * FROM kanban_stage_configs "
                "WHERE directory = ? ORDER BY position ASC, stage_id ASC",
                (normalized_directory,),
            ).fetchall()
        return [_kanban_stage_config_record(row) for row in rows]

    def create_kanban_task(
        self,
        *,
        directory: str,
        title: str,
        prompt: str,
        stage: str = KANBAN_STAGE_BACKLOG,
        project_dir: str = ".",
        session_id: str | None = None,
        model_profile_id: str | None = None,
        image_attachments: list[MessageImageAttachment] | None = None,
    ) -> KanbanTaskRecord:
        task_id = uuid.uuid4().hex
        now = _now_iso()
        project_dir_value = project_dir.strip() or "."
        normalized_directory = _normalize_directory_key(directory)
        with self._lock:
            self._require_kanban_stage_locked(normalized_directory, stage)
            position = self._next_kanban_position_locked(normalized_directory, stage)
            self._conn.execute(
                "INSERT INTO kanban_tasks "
                "(task_id, directory, title, prompt, stage, position, project_dir, "
                "session_id, model_profile_id, run_status, last_result_summary, created_at, updated_at, "
                "last_run_started_at, last_run_finished_at, image_attachments_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?)",
                (
                    task_id,
                    normalized_directory,
                    title,
                    prompt,
                    stage,
                    position,
                    project_dir_value,
                    session_id,
                    model_profile_id,
                    KANBAN_RUN_STATUS_IDLE,
                    "",
                    now,
                    now,
                    _serialize_image_attachments(image_attachments),
                ),
            )
            self._conn.commit()
            row = self._conn.execute(
                "SELECT * FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
        assert row is not None
        return _kanban_task_record(row)

    def get_kanban_task(self, task_id: str) -> KanbanTaskRecord | None:
        with self._lock:
            row = self._conn.execute(
                "SELECT * FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
        if row is None:
            return None
        return _kanban_task_record(row)

    def list_kanban_tasks(self, directory: str) -> list[KanbanTaskRecord]:
        normalized_directory = _normalize_directory_key(directory)
        with self._lock:
            self._ensure_canonical_kanban_stages_locked(normalized_directory)
            rows = self._conn.execute(
                "SELECT task.* FROM kanban_tasks AS task "
                "LEFT JOIN kanban_stage_configs AS stage_cfg "
                "ON stage_cfg.directory = task.directory AND stage_cfg.stage_id = task.stage "
                "WHERE task.directory = ? "
                "ORDER BY "
                "CASE WHEN stage_cfg.position IS NULL THEN 1 ELSE 0 END ASC, "
                "stage_cfg.position ASC, "
                "CASE WHEN task.stage = ? THEN task.created_at END DESC, "
                "CASE WHEN task.stage != ? THEN task.position END ASC, "
                "CASE WHEN task.stage != ? THEN task.updated_at END DESC",
                (
                    normalized_directory,
                    KANBAN_STAGE_DONE,
                    KANBAN_STAGE_DONE,
                    KANBAN_STAGE_DONE,
                ),
            ).fetchall()
        return [_kanban_task_record(row) for row in rows]

    def update_kanban_task(
        self,
        task_id: str,
        *,
        title: str | None = None,
        prompt: str | None = None,
        stage: str | None = None,
        project_dir: str | None = None,
        session_id: str | None = None,
        clear_session_id: bool = False,
        model_profile_id: str | None = None,
        clear_model_profile_id: bool = False,
        image_attachments: list[MessageImageAttachment] | None = None,
        image_attachments_present: bool = False,
        run_status: str | None = None,
        last_result_summary: str | None = None,
        last_run_started_at: str | None = None,
        last_run_finished_at: str | None = None,
        clear_last_run_started_at: bool = False,
        clear_last_run_finished_at: bool = False,
    ) -> KanbanTaskRecord | None:
        with self._lock:
            current_row = self._conn.execute(
                "SELECT directory FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
        if current_row is None:
            return None
        current_directory = str(current_row["directory"])
        clauses: list[str] = []
        params: list[object] = []
        if title is not None:
            clauses.append("title = ?")
            params.append(title)
        if prompt is not None:
            clauses.append("prompt = ?")
            params.append(prompt)
        if stage is not None:
            self._require_kanban_stage_locked(current_directory, stage)
            clauses.append("stage = ?")
            params.append(stage)
        if project_dir is not None:
            clauses.append("project_dir = ?")
            params.append(project_dir.strip() or ".")
        if clear_session_id:
            clauses.append("session_id = NULL")
        elif session_id is not None:
            clauses.append("session_id = ?")
            params.append(session_id)
        if clear_model_profile_id:
            clauses.append("model_profile_id = NULL")
        elif model_profile_id is not None:
            clauses.append("model_profile_id = ?")
            params.append(model_profile_id)
        if image_attachments_present:
            clauses.append("image_attachments_json = ?")
            params.append(_serialize_image_attachments(image_attachments))
        if run_status is not None:
            clauses.append("run_status = ?")
            params.append(run_status)
        if last_result_summary is not None:
            clauses.append("last_result_summary = ?")
            params.append(last_result_summary)
        if last_run_started_at is not None:
            clauses.append("last_run_started_at = ?")
            params.append(last_run_started_at)
        elif clear_last_run_started_at:
            clauses.append("last_run_started_at = NULL")
        if last_run_finished_at is not None:
            clauses.append("last_run_finished_at = ?")
            params.append(last_run_finished_at)
        elif clear_last_run_finished_at:
            clauses.append("last_run_finished_at = NULL")
        if not clauses:
            return self.get_kanban_task(task_id)
        clauses.append("updated_at = ?")
        params.append(_now_iso())
        params.append(task_id)
        with self._lock:
            self._conn.execute(
                f"UPDATE kanban_tasks SET {', '.join(clauses)} WHERE task_id = ?",
                params,
            )
            self._conn.commit()
            row = self._conn.execute(
                "SELECT * FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
        if row is None:
            return None
        return _kanban_task_record(row)

    def move_kanban_task(
        self,
        task_id: str,
        *,
        stage: str,
        position: int | None = None,
    ) -> KanbanTaskRecord | None:
        with self._lock:
            current = self._conn.execute(
                "SELECT * FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
            if current is None:
                return None
            record = _kanban_task_record(current)
            self._require_kanban_stage_locked(record.directory, stage)
            old_stage = record.stage
            old_position = record.position
            target_position = position
            if old_stage == stage:
                max_position = max(
                    self._next_kanban_position_locked(record.directory, stage) - 1,
                    0,
                )
                if target_position is None:
                    target_position = old_position
                target_position = min(max(target_position, 0), max_position)
                if target_position > old_position:
                    self._conn.execute(
                        "UPDATE kanban_tasks "
                        "SET position = position - 1, updated_at = ? "
                        "WHERE directory = ? AND stage = ? "
                        "AND position > ? AND position <= ?",
                        (
                            _now_iso(),
                            record.directory,
                            stage,
                            old_position,
                            target_position,
                        ),
                    )
                elif target_position < old_position:
                    self._conn.execute(
                        "UPDATE kanban_tasks "
                        "SET position = position + 1, updated_at = ? "
                        "WHERE directory = ? AND stage = ? "
                        "AND position >= ? AND position < ?",
                        (
                            _now_iso(),
                            record.directory,
                            stage,
                            target_position,
                            old_position,
                        ),
                    )
            else:
                if target_position is None:
                    target_position = self._next_kanban_position_locked(
                        record.directory, stage
                    )
                else:
                    self._shift_kanban_positions_locked(
                        record.directory,
                        stage,
                        start=max(target_position, 0),
                        delta=1,
                    )
            self._conn.execute(
                "UPDATE kanban_tasks "
                "SET stage = ?, position = ?, updated_at = ? "
                "WHERE task_id = ?",
                (stage, max(target_position, 0), _now_iso(), task_id),
            )
            if old_stage != stage:
                self._shift_kanban_positions_locked(
                    record.directory,
                    old_stage,
                    start=old_position + 1,
                    delta=-1,
                )
            self._conn.commit()
            row = self._conn.execute(
                "SELECT * FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
        assert row is not None
        return _kanban_task_record(row)

    def delete_kanban_task(self, task_id: str) -> bool:
        with self._lock:
            current = self._conn.execute(
                "SELECT directory, stage, position FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            ).fetchone()
            if current is None:
                return False
            self._conn.execute(
                "DELETE FROM kanban_tasks WHERE task_id = ?",
                (task_id,),
            )
            self._shift_kanban_positions_locked(
                str(current["directory"]),
                str(current["stage"]),
                start=int(current["position"]) + 1,
                delta=-1,
            )
            self._conn.commit()
        return True

    def set_kanban_task_running(self, task_id: str) -> KanbanTaskRecord | None:
        now = _now_iso()
        return self.update_kanban_task(
            task_id,
            run_status=KANBAN_RUN_STATUS_RUNNING,
            last_run_started_at=now,
            clear_last_run_finished_at=True,
            last_result_summary="Running...",
        )

    def set_kanban_task_result(
        self,
        task_id: str,
        *,
        run_status: str,
        summary: str,
        session_id: str | None = None,
    ) -> KanbanTaskRecord | None:
        if run_status not in {
            KANBAN_RUN_STATUS_COMPLETED,
            KANBAN_RUN_STATUS_FAILED,
            KANBAN_RUN_STATUS_IDLE,
            KANBAN_RUN_STATUS_RUNNING,
        }:
            raise ValueError(f"unsupported kanban run status: {run_status}")
        return self.update_kanban_task(
            task_id,
            run_status=run_status,
            last_result_summary=summary,
            session_id=session_id,
            last_run_finished_at=_now_iso(),
        )

    def normalize_kanban_running_tasks(self, *, directory: str | None = None) -> int:
        clauses = [
            "run_status = ?",
            "last_result_summary = ?",
            "updated_at = ?",
            "last_run_finished_at = ?",
        ]
        params: list[object] = [
            KANBAN_RUN_STATUS_FAILED,
            "Interrupted while the app was not running.",
            _now_iso(),
            _now_iso(),
        ]
        where = "WHERE run_status = ?"
        params.append(KANBAN_RUN_STATUS_RUNNING)
        if directory is not None:
            where += " AND directory = ?"
            params.append(_normalize_directory_key(directory))
        with self._lock:
            cursor = self._conn.execute(
                f"UPDATE kanban_tasks SET {', '.join(clauses)} {where}",
                params,
            )
            self._conn.commit()
            return int(cursor.rowcount or 0)

    def _next_kanban_position_locked(self, directory: str, stage: str) -> int:
        row = self._conn.execute(
            "SELECT COALESCE(MAX(position), -1) AS max_position "
            "FROM kanban_tasks WHERE directory = ? AND stage = ?",
            (directory, stage),
        ).fetchone()
        max_position = int(row["max_position"]) if row is not None else -1
        return max_position + 1

    def _shift_kanban_positions_locked(
        self,
        directory: str,
        stage: str,
        *,
        start: int,
        delta: int,
    ) -> None:
        if delta == 0:
            return
        comparator = ">=" if delta > 0 else ">="
        self._conn.execute(
            f"UPDATE kanban_tasks "
            f"SET position = position + ?, updated_at = ? "
            f"WHERE directory = ? AND stage = ? AND position {comparator} ?",
            (delta, _now_iso(), directory, stage, start),
        )

    def _ensure_canonical_kanban_stages_locked(self, directory: str) -> None:
        rows = self._conn.execute(
            "SELECT * FROM kanban_stage_configs "
            "WHERE directory = ? ORDER BY position ASC, stage_id ASC",
            (directory,),
        ).fetchall()
        if rows:
            existing_records = [_kanban_stage_config_record(row) for row in rows]
            desired_specs = _normalize_kanban_stage_specs(
                [
                    KanbanStageConfigSpec(
                        stage_id=record.stage_id,
                        name=record.name,
                        model_profile_id=record.model_profile_id,
                        command_id=record.command_id,
                        auto_start=record.auto_start,
                    )
                    for record in existing_records
                ]
            )
            records_match = len(existing_records) == len(desired_specs) and all(
                record.stage_id == spec.stage_id
                and record.position == position
                and record.name == spec.name
                and record.model_profile_id == spec.model_profile_id
                and record.command_id == spec.command_id
                and record.auto_start == spec.auto_start
                for position, (record, spec) in enumerate(
                    zip(existing_records, desired_specs, strict=False)
                )
            )
            if records_match:
                return
            existing_by_id = {record.stage_id: record for record in existing_records}
        else:
            desired_specs = _default_kanban_stage_specs()
            existing_by_id = {}
        now = _now_iso()
        self._conn.execute(
            "DELETE FROM kanban_stage_configs WHERE directory = ?",
            (directory,),
        )
        for position, spec in enumerate(desired_specs):
            existing = existing_by_id.get(spec.stage_id)
            self._conn.execute(
                "INSERT INTO kanban_stage_configs "
                "(directory, stage_id, name, position, model_profile_id, command_id, "
                "auto_start, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    directory,
                    spec.stage_id,
                    spec.name,
                    position,
                    spec.model_profile_id,
                    spec.command_id,
                    1 if spec.auto_start else 0,
                    existing.created_at if existing is not None else now,
                    now,
                ),
            )
        self._conn.commit()

    def _require_kanban_stage_locked(self, directory: str, stage: str) -> None:
        self._ensure_canonical_kanban_stages_locked(directory)
        row = self._conn.execute(
            "SELECT 1 FROM kanban_stage_configs "
            "WHERE directory = ? AND stage_id = ? LIMIT 1",
            (directory, stage),
        ).fetchone()
        if row is None:
            raise ValueError(f"unsupported kanban stage: {stage}")
