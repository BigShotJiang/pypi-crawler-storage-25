from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
import json
import logging
import time
from pathlib import Path
from typing import Any, Callable

from pbi_agent.agent.compaction_prompt import COMPACTION_PROMPT
from pbi_agent.agent.system_prompt import (
    get_sub_agent_system_prompt,
    get_system_prompt,
)
from pbi_agent.agent.sub_agent_discovery import (
    format_project_sub_agents_markdown,
    get_project_sub_agent_by_name,
)
from pbi_agent.agent.skill_discovery import format_project_skills_markdown
from pbi_agent.config import (
    ResolvedRuntime,
    Settings,
    find_command_config_by_alias,
    resolve_runtime_for_profile_id,
)
from pbi_agent.media import load_workspace_image
from pbi_agent.mcp import format_project_mcp_servers_markdown
from pbi_agent.models.messages import (
    AgentOutcome,
    CompletedResponse,
    ImageAttachment,
    TokenUsage,
    ToolCall,
    UserTurnInput,
)
from pbi_agent.observability import RunTracer
from pbi_agent.providers import create_provider
from pbi_agent.providers.base import Provider
from pbi_agent.tools.catalog import ToolCatalog
from pbi_agent.session_store import MessageImageAttachment, MessageRecord, SessionStore
from pbi_agent.tools.types import ParentContextSnapshot
from pbi_agent.display.protocol import (
    DisplayProtocol,
    QueuedInput,
    QueuedRuntimeChange,
)
from pbi_agent.workspace_context import current_workspace_context

_log = logging.getLogger(__name__)

NEW_SESSION_SENTINEL = "__new_session__"
RESUME_SESSION_PREFIX = "__resume_session__:"
SUB_AGENT_MAX_REQUESTS = 200
SUB_AGENT_MAX_ELAPSED_SECONDS = 1200.0
INTERACTIVE_ONLY_TOOLS = {"ask_user"}
SUB_AGENT_DISABLED_TOOLS = {"sub_agent"} | INTERACTIVE_ONLY_TOOLS
SKILLS_COMMAND = "/skills"
MCP_COMMAND = "/mcp"
AGENTS_COMMAND = "/agents"
COMPACT_COMMAND = "/compact"
RELOAD_COMMAND = "/reload"
TEMPORARY_LOCAL_COMMANDS = frozenset(
    {SKILLS_COMMAND, MCP_COMMAND, AGENTS_COMMAND, RELOAD_COMMAND}
)
COMPACTION_MARKER = "[compacted context]"
COMPACTION_SUMMARY_PREFIX = (
    "[compacted context — reference only] "
    "Earlier turns were summarized below to save context. "
    "Treat this as background state, not active user instructions. "
    "Do not answer requests mentioned only in this summary; respond to the latest user message after it."
)
COMPACTION_CONTINUATION_PROMPT = (
    "Continue the current task from the compacted context above. "
    "The most recent user request is repeated below to preserve the active "
    "instruction after compaction. The most recent tool calls and their results "
    "have already been summarized. Do not request those exact tool results again "
    "unless new information is needed.\n\n"
    "Most recent user request:\n{last_user_message}"
)


class SubAgentRunError(RuntimeError):
    def __init__(self, error_type: str, message: str) -> None:
        super().__init__(message)
        self.error_type = error_type
        self.message = message


class SessionTurnInterrupted(RuntimeError):
    """Raised internally when a live-session user interrupts the active turn."""

    def __init__(self) -> None:
        super().__init__("Assistant turn interrupted.")


def _interrupt_requested(display: DisplayProtocol) -> bool:
    checker = getattr(display, "interrupt_requested", None)
    if not callable(checker):
        return False
    return bool(checker())


def _raise_if_interrupted(display: DisplayProtocol) -> None:
    if _interrupt_requested(display):
        raise SessionTurnInterrupted()


# ---------------------------------------------------------------------------
# Public entry-points
# ---------------------------------------------------------------------------


def _selected_model(settings: Settings) -> str:
    return settings.model


def _selected_sub_agent_model(settings: Settings) -> str:
    return settings.sub_agent_model or settings.model


def _bind_session(display: DisplayProtocol, session_id: str | None) -> None:
    binder = getattr(display, "bind_session", None)
    if callable(binder):
        binder(session_id)


def _coerce_runtime(value: Settings | ResolvedRuntime) -> ResolvedRuntime:
    if isinstance(value, ResolvedRuntime):
        return value
    return _runtime_from_settings(value)


def _runtime_from_settings(settings: Settings) -> ResolvedRuntime:
    return ResolvedRuntime(
        settings=settings,
        provider_id="",
        profile_id="",
    )


def _runtime_from_provider(provider: Provider) -> ResolvedRuntime:
    return _runtime_from_settings(provider.settings)


def _extract_active_command_instructions(value: str) -> str | None:
    stripped = value.strip()
    if not stripped.startswith("/"):
        return None
    head = stripped.split(maxsplit=1)[0]
    try:
        command = find_command_config_by_alias(head)
    except Exception:
        return None
    if command is None:
        return None
    return command.instructions


def _turn_instructions(active_command_instructions: str | None) -> str | None:
    if active_command_instructions is None:
        return None
    return get_system_prompt(active_command_instructions=active_command_instructions)


def run_single_turn(
    prompt: str,
    settings: Settings | ResolvedRuntime,
    display: DisplayProtocol,
    *,
    single_turn_hint: str | None = None,
    resume_session_id: str | None = None,
    image_paths: list[str] | None = None,
    images: list[ImageAttachment] | None = None,
    persisted_user_message_id: int | None = None,
    replay_history: bool = True,
) -> AgentOutcome:
    runtime = _coerce_runtime(settings)
    store = _open_store(runtime.settings)
    settings = runtime.settings
    display.welcome(
        interactive=False,
        model=_selected_model(settings),
        reasoning_effort=settings.reasoning_effort,
        single_turn_hint=single_turn_hint,
    )
    model = _selected_model(settings)
    _tier = settings.service_tier or ""
    session_usage = TokenUsage(model=model, service_tier=_tier)
    display.session_usage(session_usage)
    session_start = time.monotonic()
    turn_usage = TokenUsage(model=model, service_tier=_tier)
    prompt_text = prompt
    active_command_instructions = _extract_active_command_instructions(prompt)
    turn_instructions = _turn_instructions(active_command_instructions)

    user_input = _build_user_turn_input(
        text=prompt_text,
        image_paths=image_paths or [],
        images=images,
        settings=settings,
    )
    user_turn_history_text = _user_turn_history_text(user_input)
    session_id = resume_session_id or _create_session(
        store,
        runtime,
        title=_session_title_for_user_turn(user_input),
    )
    tracer = RunTracer.start(
        store=store,
        session_id=session_id,
        agent_name="main",
        agent_type="single_turn",
        provider=settings.provider,
        provider_id=runtime.provider_id,
        profile_id=runtime.profile_id,
        model=model,
        metadata={
            "single_turn_hint": single_turn_hint,
            "resumed": resume_session_id is not None,
        },
    )

    try:
        with _open_runtime_provider(
            settings,
            excluded_tools=INTERACTIVE_ONLY_TOOLS,
        ) as provider:
            display.assistant_start()
            _resume_session(
                provider=provider,
                store=store,
                session_id=resume_session_id,
                session_usage=session_usage,
                display=display,
                before_message_id=persisted_user_message_id,
                replay_history=replay_history,
            )
            if persisted_user_message_id is None:
                user_message_id = _add_message(
                    store,
                    session_id,
                    runtime,
                    "user",
                    user_turn_history_text,
                )
                _publish_persisted_message(display, store, user_message_id)
            tracer.log_event(
                "agent_step_start",
                metadata={"step": "initial_model_request"},
            )
            response = _request_user_turn(
                provider=provider,
                user_input=user_input,
                session_id=session_id,
                instructions=turn_instructions,
                display=display,
                session_usage=session_usage,
                turn_usage=turn_usage,
                tracer=tracer,
            )
            tracer.log_event(
                "agent_step_end",
                metadata={"step": "initial_model_request"},
            )
            response, had_tool_errors, _ = _run_tool_iterations(
                provider=provider,
                response=response,
                max_workers=settings.max_tool_workers,
                display=display,
                session_usage=session_usage,
                turn_usage=turn_usage,
                store=store,
                session_id=session_id,
                current_user_turn_text=user_turn_history_text,
                instructions=turn_instructions,
                tracer=tracer,
                current_turn_tool_exchanges=[],
            )
            assistant_message_id = _add_message(
                store,
                session_id,
                runtime,
                "assistant",
                response.text,
            )
            _publish_persisted_message(display, store, assistant_message_id)
            _update_session_after_turn(
                store,
                session_id,
                runtime,
                session_usage,
            )
            _refresh_provider_history_from_store(
                provider,
                store,
                session_id,
                reason="turn",
            )
            display.assistant_stop()
            elapsed = time.monotonic() - session_start
            display.turn_usage(turn_usage, elapsed)
            display.session_usage(session_usage)
            tracer.finish(
                status="completed",
                usage=turn_usage,
                metadata={"tool_errors": had_tool_errors},
            )
            return AgentOutcome(
                response_id=response.response_id,
                text=response.text,
                tool_errors=had_tool_errors,
                session_id=session_id,
            )
    except Exception as exc:
        display.assistant_stop()
        tracer.log_error(str(exc), metadata={"phase": "run_single_turn"})
        tracer.finish(
            status="failed",
            usage=turn_usage,
            metadata={"error_message": str(exc)},
        )
        raise
    finally:
        _close_store(store)


def run_session_loop(
    settings: Settings | ResolvedRuntime,
    display: DisplayProtocol,
    *,
    resume_session_id: str | None = None,
    run_session_id: str | None = None,
    on_reload: Callable[[], None] | None = None,
    excluded_tools: set[str] | None = None,
) -> int:
    current_runtime = _coerce_runtime(settings)
    saved_session_runtime = current_runtime
    store = _open_store(current_runtime.settings)
    session_id: str | None = resume_session_id
    title_set = bool(resume_session_id)
    resume_session_to_restore = resume_session_id
    replay_history_on_restore = resume_session_id is not None
    should_exit = False
    base_excluded_tools = set(excluded_tools) if excluded_tools is not None else set()

    def _render_temporary_command_markdown(text: str) -> None:
        render_transient = getattr(display, "render_transient_markdown", None)
        if callable(render_transient):
            render_transient(text)
        else:
            display.render_markdown(text)

    def _turn_excluded_tools(*, interactive_mode: bool = False) -> set[str]:
        return base_excluded_tools | (
            set()
            if interactive_mode and excluded_tools is None
            else INTERACTIVE_ONLY_TOOLS
        )

    def _reset_session(
        active_runtime: ResolvedRuntime, *, clear_display: bool = False
    ) -> TokenUsage:
        if clear_display:
            display.reset_session()
        active_settings = active_runtime.settings
        display.welcome(
            model=_selected_model(active_settings),
            reasoning_effort=active_settings.reasoning_effort,
        )
        new_usage = TokenUsage(
            model=_selected_model(active_settings),
            service_tier=active_settings.service_tier or "",
        )
        display.session_usage(new_usage)
        return new_usage

    session_usage = _reset_session(current_runtime)
    _bind_session(display, session_id)
    had_tool_errors = False
    while not should_exit:
        with _open_runtime_provider(
            current_runtime.settings,
            excluded_tools=_turn_excluded_tools(interactive_mode=False),
        ) as provider:
            if resume_session_to_restore is not None:
                _resume_session(
                    provider=provider,
                    store=store,
                    session_id=resume_session_to_restore,
                    session_usage=session_usage,
                    display=display,
                    replay_history=replay_history_on_restore,
                )
                resume_session_to_restore = None
                replay_history_on_restore = False
            while True:
                queued_input = display.user_prompt()
                file_paths: list[str] = []
                image_paths: list[str] = []
                queued_images: list[ImageAttachment] = []
                message_image_attachments: list[MessageImageAttachment] = []
                if isinstance(queued_input, QueuedRuntimeChange):
                    current_runtime = queued_input.runtime
                    if queued_input.persist:
                        saved_session_runtime = current_runtime
                        _persist_runtime_change(
                            store,
                            session_id,
                            saved_session_runtime,
                        )
                    elif queued_input.saved_runtime is not None:
                        saved_session_runtime = queued_input.saved_runtime
                    session_usage = _reset_session(
                        current_runtime,
                    )
                    if session_id is not None:
                        resume_session_to_restore = session_id
                        replay_history_on_restore = False
                        _bind_session(display, session_id)
                    break
                if isinstance(queued_input, QueuedInput):
                    user_input = queued_input.text.strip()
                    file_paths = queued_input.file_paths
                    image_paths = queued_input.image_paths
                    queued_images = queued_input.images
                    message_image_attachments = queued_input.image_attachments
                    turn_interactive_mode = queued_input.interactive_mode
                    queued_item_id = queued_input.item_id
                else:
                    user_input = queued_input.strip()
                    turn_interactive_mode = False
                    queued_item_id = None
                if user_input == NEW_SESSION_SENTINEL:
                    provider.reset_conversation()
                    session_usage = _reset_session(
                        current_runtime,
                        clear_display=True,
                    )
                    had_tool_errors = False
                    session_id = None
                    title_set = False
                    _bind_session(display, session_id)
                    continue
                if user_input.startswith(RESUME_SESSION_PREFIX):
                    resume_id = user_input[len(RESUME_SESSION_PREFIX) :]
                    provider.reset_conversation()
                    session_usage = _reset_session(
                        current_runtime,
                        clear_display=True,
                    )
                    had_tool_errors = False
                    session_id = None
                    title_set = False
                    if store:
                        session_id = resume_id
                        title_set = True
                        _bind_session(display, session_id)
                        resume_session_to_restore = resume_id
                        replay_history_on_restore = True
                        break
                    else:
                        _bind_session(display, session_id)
                    continue
                if user_input.lower() in {"exit", "quit"}:
                    should_exit = True
                    break
                normalized_command = _normalize_user_command(user_input)
                if normalized_command == SKILLS_COMMAND:
                    _render_temporary_command_markdown(format_project_skills_markdown())
                    continue
                if normalized_command == MCP_COMMAND:
                    _render_temporary_command_markdown(
                        format_project_mcp_servers_markdown()
                    )
                    continue
                if normalized_command == AGENTS_COMMAND:
                    _render_temporary_command_markdown(
                        format_project_sub_agents_markdown()
                    )
                    continue
                if normalized_command == RELOAD_COMMAND:
                    _reload_provider_initialization(provider)
                    if on_reload is not None:
                        on_reload()
                    _render_temporary_command_markdown(
                        "Reloaded workspace instructions, project rules, skills, "
                        "sub-agents, tool definitions, and file mention cache. "
                        "MCP servers are not reloaded; restart the session after "
                        "changing MCP config."
                    )
                    continue
                if normalized_command == COMPACT_COMMAND:
                    if session_id is None:
                        display.render_markdown(
                            "No active session context to compact yet."
                        )
                        continue
                    session_usage.context_tokens = _compact_live_session(
                        provider=provider,
                        store=store,
                        session_id=session_id,
                        runtime=current_runtime,
                        display=display,
                        session_usage=session_usage,
                        reason="manual",
                    )
                    display.session_usage(session_usage)
                    continue
                active_command_instructions = _extract_active_command_instructions(
                    user_input
                )
                turn_instructions = _turn_instructions(active_command_instructions)
                if (
                    not user_input
                    and not image_paths
                    and not queued_images
                    and turn_instructions is None
                ):
                    continue

                turn_input = _build_user_turn_input(
                    text=user_input,
                    image_paths=image_paths,
                    images=queued_images,
                    settings=current_runtime.settings,
                )
                turn_history_text = _user_turn_history_text(turn_input)

                if session_id is None:
                    session_id = _create_session(
                        store,
                        saved_session_runtime,
                        title=_session_title_for_user_turn(turn_input),
                    )
                    title_set = True
                    _bind_session(display, session_id)
                elif not title_set:
                    _update_session_title(
                        store,
                        session_id,
                        _session_title_for_user_turn(turn_input),
                    )
                    title_set = True

                turn_start = time.monotonic()
                turn_usage = TokenUsage(
                    model=_selected_model(current_runtime.settings),
                    service_tier=current_runtime.settings.service_tier or "",
                )
                turn_tracer = RunTracer.start(
                    store=store,
                    run_session_id=run_session_id,
                    session_id=session_id,
                    agent_name="main",
                    agent_type="session_turn",
                    provider=current_runtime.settings.provider,
                    provider_id=current_runtime.provider_id,
                    profile_id=current_runtime.profile_id,
                    model=_selected_model(current_runtime.settings),
                    metadata={"resumed": resume_session_id is not None},
                )
                display.assistant_start()
                user_message_id: int | None = None
                try:
                    _raise_if_interrupted(display)
                    provider.set_excluded_tools(
                        _turn_excluded_tools(interactive_mode=turn_interactive_mode)
                    )
                    user_message_id = _add_message(
                        store,
                        session_id,
                        current_runtime,
                        "user",
                        turn_history_text,
                        file_paths=file_paths,
                        image_attachments=message_image_attachments,
                    )
                    _publish_persisted_message(
                        display,
                        store,
                        user_message_id,
                        previous_item_id=queued_item_id,
                    )
                    turn_tracer.log_event(
                        "agent_step_start",
                        metadata={"step": "initial_model_request"},
                    )
                    response = _request_user_turn(
                        provider=provider,
                        user_input=turn_input,
                        session_id=session_id,
                        instructions=turn_instructions,
                        display=display,
                        session_usage=session_usage,
                        turn_usage=turn_usage,
                        tracer=turn_tracer,
                    )
                    _raise_if_interrupted(display)
                    turn_tracer.log_event(
                        "agent_step_end",
                        metadata={"step": "initial_model_request"},
                    )
                    response, loop_had_errors, _ = _run_tool_iterations(
                        provider=provider,
                        response=response,
                        max_workers=current_runtime.settings.max_tool_workers,
                        display=display,
                        session_usage=session_usage,
                        turn_usage=turn_usage,
                        store=store,
                        session_id=session_id,
                        current_user_turn_text=turn_history_text,
                        instructions=turn_instructions,
                        tracer=turn_tracer,
                        current_turn_tool_exchanges=[],
                    )
                    _raise_if_interrupted(display)

                    assistant_message_id = _add_message(
                        store,
                        session_id,
                        current_runtime,
                        "assistant",
                        response.text,
                    )
                    _publish_persisted_message(
                        display,
                        store,
                        assistant_message_id,
                    )
                    _update_session_after_turn(
                        store,
                        session_id,
                        saved_session_runtime,
                        session_usage,
                    )
                    _refresh_provider_history_from_store(
                        provider,
                        store,
                        session_id,
                        reason="turn",
                    )
                    had_tool_errors = had_tool_errors or loop_had_errors
                    display.assistant_stop()
                    elapsed = time.monotonic() - turn_start
                    display.turn_usage(turn_usage, elapsed)
                    display.session_usage(session_usage)
                    turn_tracer.finish(
                        status="completed",
                        usage=turn_usage,
                        metadata={"tool_errors": loop_had_errors},
                    )
                except SessionTurnInterrupted:
                    display.assistant_stop()
                    turn_tracer.log_event(
                        "turn_interrupted",
                        metadata={"phase": "run_session_loop"},
                    )
                    turn_tracer.finish(
                        status="interrupted",
                        usage=turn_usage,
                    )
                    _discard_interrupted_turn(
                        provider=provider,
                        store=store,
                        session_id=session_id,
                        user_message_id=user_message_id,
                    )
                    clear_interrupt = getattr(display, "clear_interrupt", None)
                    if callable(clear_interrupt):
                        clear_interrupt()
                    continue
                except Exception as exc:
                    display.assistant_stop()
                    turn_tracer.log_error(
                        str(exc), metadata={"phase": "run_session_loop"}
                    )
                    turn_tracer.finish(
                        status="failed",
                        usage=turn_usage,
                        metadata={"error_message": str(exc)},
                    )
                    if user_message_id is not None:
                        _delete_message(store, user_message_id)
                    raise

    _close_store(store)
    return 4 if had_tool_errors else 0


def run_sub_agent_task(
    task_instruction: str,
    settings: Settings,
    display: DisplayProtocol,
    *,
    parent_session_usage: TokenUsage,
    parent_turn_usage: TokenUsage,
    sub_agent_depth: int = 0,
    tool_catalog: "ToolCatalog | None" = None,
    agent_type: str | None = None,
    include_context: bool = False,
    parent_context: ParentContextSnapshot | None = None,
    parent_tracer: RunTracer | None = None,
) -> dict[str, Any]:
    agent_definition = None
    if agent_type is not None:
        agent_definition = get_project_sub_agent_by_name(agent_type)
        if agent_definition is None:
            return {
                "status": "failed",
                "error": {
                    "type": "unknown_agent_type",
                    "message": f"No project sub-agent named '{agent_type}' is loaded.",
                },
            }

    agent_model_profile_id = (
        getattr(agent_definition, "model_profile_id", None)
        if agent_definition is not None
        else None
    )
    from pbi_agent.agent.names import pick_deity_name

    child_name = (
        agent_definition.name if agent_definition is not None else pick_deity_name()
    )
    child_display: DisplayProtocol | None = None
    child_tracer: RunTracer | None = None
    child_session_usage: TokenUsage | None = None
    child_turn_usage: TokenUsage | None = None
    started_at = time.monotonic()
    request_count = 0

    try:
        child_provider_id: str | None = None
        child_profile_id: str | None = None
        if agent_model_profile_id:
            child_runtime = resolve_runtime_for_profile_id(
                agent_model_profile_id,
                verbose=settings.verbose,
            )
            child_settings = child_runtime.settings
            child_provider_id = child_runtime.provider_id
            child_profile_id = child_runtime.profile_id
        else:
            child_settings = replace(
                settings,
                model=_selected_sub_agent_model(settings),
            )
        child_display = display.begin_sub_agent(
            task_instruction=task_instruction,
            reasoning_effort=child_settings.reasoning_effort,
            name=child_name,
        )
        _child_tier = child_settings.service_tier or ""
        child_session_usage = TokenUsage(
            model=_selected_model(child_settings), service_tier=_child_tier
        )
        child_turn_usage = TokenUsage(
            model=_selected_model(child_settings), service_tier=_child_tier
        )
        child_tracer = (
            parent_tracer.child(
                agent_name=child_name,
                agent_type=agent_type or "default",
                provider=child_settings.provider,
                provider_id=child_provider_id,
                profile_id=child_profile_id,
                model=_selected_model(child_settings),
                metadata={"include_context": include_context},
            )
            if parent_tracer is not None
            else RunTracer.start(
                store=None,
                session_id=None,
                agent_name=child_name,
                agent_type=agent_type or "default",
                provider=child_settings.provider,
                provider_id=child_provider_id,
                profile_id=child_profile_id,
                model=_selected_model(child_settings),
                metadata={"include_context": include_context},
            )
        )
        child_display.session_usage(child_session_usage)
        with _open_runtime_provider(
            child_settings,
            system_prompt=get_sub_agent_system_prompt(
                agent_prompt_override=(
                    agent_definition.system_prompt
                    if agent_definition is not None
                    else None
                )
            ),
            excluded_tools=SUB_AGENT_DISABLED_TOOLS,
            tool_catalog=tool_catalog,
        ) as provider:
            _apply_sub_agent_parent_context(
                provider=provider,
                provider_name=child_settings.provider,
                include_context=include_context,
                parent_context=parent_context,
            )
            child_user_message = _build_sub_agent_initial_message(
                task_instruction,
                provider_name=child_settings.provider,
                include_context=include_context,
                parent_context=parent_context,
            )
            child_display.render_user_message(child_user_message)
            _raise_if_sub_agent_timed_out(started_at)
            response = provider.request_turn(
                user_message=child_user_message,
                display=child_display,
                session_usage=child_session_usage,
                turn_usage=child_turn_usage,
                tracer=child_tracer,
            )
            request_count += 1
            response, had_tool_errors, request_count = _run_tool_iterations(
                provider=provider,
                response=response,
                max_workers=child_settings.max_tool_workers,
                display=child_display,
                session_usage=child_session_usage,
                turn_usage=child_turn_usage,
                sub_agent_depth=sub_agent_depth + 1,
                max_requests=SUB_AGENT_MAX_REQUESTS,
                request_count=request_count,
                started_at=started_at,
                max_elapsed_seconds=SUB_AGENT_MAX_ELAPSED_SECONDS,
                tracer=child_tracer,
            )
            elapsed = time.monotonic() - started_at
            child_display.turn_usage(child_turn_usage, elapsed)
            child_display.finish_sub_agent(status="completed")
            child_tracer.finish(
                status="completed",
                usage=child_session_usage,
                metadata={"tool_errors": had_tool_errors},
            )
            return {
                "status": "completed",
                "final_output": response.text,
            }
    except SubAgentRunError as exc:
        child_display = child_display or display.begin_sub_agent(
            task_instruction=task_instruction,
            reasoning_effort=settings.reasoning_effort,
            name=child_name,
        )
        _fallback_tier = settings.service_tier or ""
        child_session_usage = child_session_usage or TokenUsage(
            model=_selected_model(settings), service_tier=_fallback_tier
        )
        child_turn_usage = child_turn_usage or TokenUsage(
            model=_selected_model(settings), service_tier=_fallback_tier
        )
        child_tracer = child_tracer or RunTracer.start(
            store=None,
            session_id=None,
            agent_name=child_name,
            agent_type=agent_type or "default",
            provider=settings.provider,
            provider_id=None,
            profile_id=None,
            model=_selected_model(settings),
            metadata={"include_context": include_context},
        )
        child_display.error(exc.message)
        child_display.finish_sub_agent(status="failed")
        child_tracer.log_error(exc.message, metadata={"phase": "run_sub_agent_task"})
        child_tracer.finish(
            status="failed",
            usage=child_session_usage,
            metadata={"error_message": exc.message},
        )
        return {
            "status": "failed",
            "error": {"type": exc.error_type, "message": exc.message},
        }
    except Exception as exc:
        message = str(exc) or exc.__class__.__name__
        child_display = child_display or display.begin_sub_agent(
            task_instruction=task_instruction,
            reasoning_effort=settings.reasoning_effort,
            name=child_name,
        )
        _fallback_tier = settings.service_tier or ""
        child_session_usage = child_session_usage or TokenUsage(
            model=_selected_model(settings), service_tier=_fallback_tier
        )
        child_turn_usage = child_turn_usage or TokenUsage(
            model=_selected_model(settings), service_tier=_fallback_tier
        )
        child_tracer = child_tracer or RunTracer.start(
            store=None,
            session_id=None,
            agent_name=child_name,
            agent_type=agent_type or "default",
            provider=settings.provider,
            provider_id=None,
            profile_id=None,
            model=_selected_model(settings),
            metadata={"include_context": include_context},
        )
        child_display.error(message)
        child_display.finish_sub_agent(status="failed")
        child_tracer.log_error(message, metadata={"phase": "run_sub_agent_task"})
        child_tracer.finish(
            status="failed",
            usage=child_session_usage,
            metadata={"error_message": message},
        )
        return {
            "status": "failed",
            "error": {"type": "sub_agent_failed", "message": message},
        }
    finally:
        if child_session_usage is not None:
            parent_session_usage.add_sub_agent(child_session_usage)
        if child_turn_usage is not None:
            parent_turn_usage.add_sub_agent(child_turn_usage)
        if child_session_usage is not None or child_turn_usage is not None:
            display.session_usage(parent_session_usage)


@contextmanager
def _open_runtime_provider(
    settings: Settings,
    *,
    system_prompt: str | None = None,
    excluded_tools: set[str] | None = None,
    tool_catalog: "ToolCatalog | None" = None,
):
    from pbi_agent.mcp import McpServerPool

    if tool_catalog is not None:
        provider = create_provider(
            settings,
            system_prompt=system_prompt,
            excluded_tools=excluded_tools,
            tool_catalog=tool_catalog,
        )
        with provider:
            yield provider
    else:
        with McpServerPool(Path.cwd()) as mcp_pool:
            provider = create_provider(
                settings,
                system_prompt=system_prompt,
                excluded_tools=excluded_tools,
                tool_catalog=mcp_pool.to_tool_catalog(),
            )
            with provider:
                yield provider


@contextmanager
def _open_compaction_provider(settings: Settings):
    compact_settings = replace(settings, web_search=False)
    with _open_runtime_provider(
        compact_settings,
        system_prompt=COMPACTION_PROMPT,
        tool_catalog=ToolCatalog(),
    ) as provider:
        yield provider


# ---------------------------------------------------------------------------
# Tool iteration loop
# ---------------------------------------------------------------------------


def _run_tool_iterations(
    *,
    provider,
    response,
    max_workers: int,
    display: DisplayProtocol,
    session_usage: TokenUsage,
    turn_usage: TokenUsage,
    sub_agent_depth: int = 0,
    max_requests: int | None = None,
    request_count: int = 0,
    started_at: float | None = None,
    max_elapsed_seconds: float | None = None,
    store: SessionStore | None = None,
    session_id: str | None = None,
    current_user_turn_text: str | None = None,
    instructions: str | None = None,
    tracer: RunTracer | None = None,
    current_turn_tool_exchanges: (
        list[tuple[list[ToolCall], list[dict[str, Any]]]] | None
    ) = None,
) -> tuple[CompletedResponse, bool, int]:
    had_errors = False
    tool_exchanges = current_turn_tool_exchanges
    if tool_exchanges is None:
        tool_exchanges = []

    while response.has_tool_calls:
        _raise_if_interrupted(display)
        if started_at is not None and max_elapsed_seconds is not None:
            _raise_if_sub_agent_timed_out(
                started_at,
                max_elapsed_seconds=max_elapsed_seconds,
            )
        display.debug("model requested tool execution")
        _log.debug(
            "Executing tool iteration: %d function call(s)",
            len(response.function_calls),
        )

        try:
            parent_context = None
            if any(call.name == "sub_agent" for call in response.function_calls):
                parent_context = _build_parent_context_snapshot(
                    provider=provider,
                    store=store,
                    session_id=session_id,
                    current_user_turn_text=current_user_turn_text,
                )
            if tracer is not None:
                tracer.log_event(
                    "agent_step_start",
                    metadata={
                        "step": "tool_iteration",
                        "tool_count": len(response.function_calls),
                    },
                )
            effective_max_workers = (
                1
                if any(call.name == "ask_user" for call in response.function_calls)
                else max_workers
            )
            tool_result_items, loop_errors = provider.execute_tool_calls(
                response,
                max_workers=effective_max_workers,
                display=display,
                session_usage=session_usage,
                turn_usage=turn_usage,
                sub_agent_depth=sub_agent_depth,
                parent_context=parent_context,
                tracer=tracer,
            )
            _raise_if_interrupted(display)
        except SessionTurnInterrupted:
            raise
        except Exception:
            _log.exception("Tool execution failed inside provider.execute_tool_calls")
            raise
        had_errors = had_errors or loop_errors
        if response.function_calls or tool_result_items:
            tool_exchanges.append(
                (list(response.function_calls), list(tool_result_items))
            )

        compacted_after_tools = False
        if (
            bool(tool_result_items)
            and store is not None
            and session_id is not None
            and _should_auto_compact(
                session_usage=session_usage,
                settings=provider.settings,
                store=store,
                session_id=session_id,
            )
        ):
            if _provider_has_server_side_compaction(provider):
                display.render_markdown(
                    "Context compaction is handled by the provider; "
                    "continuing with native tool results."
                )
            else:
                session_usage.context_tokens = _compact_live_session(
                    provider=provider,
                    store=store,
                    session_id=session_id,
                    runtime=_runtime_from_provider(provider),
                    display=display,
                    session_usage=session_usage,
                    reason="auto",
                    pending_tool_exchanges=tool_exchanges,
                )
                tool_exchanges.clear()
                display.session_usage(session_usage)
                compacted_after_tools = True

        if not tool_result_items:
            _log.debug("No tool_result_items returned; stopping tool loop")
            if tracer is not None:
                tracer.log_event(
                    "agent_step_end",
                    metadata={"step": "tool_iteration", "empty_result": True},
                )
            break

        if max_requests is not None and request_count >= max_requests:
            raise SubAgentRunError(
                "request_limit_exceeded",
                (
                    "Sub-agent exceeded the maximum provider request limit "
                    f"({max_requests})."
                ),
            )

        try:
            if compacted_after_tools:
                response = provider.request_turn(
                    user_message=_compaction_continuation_prompt(
                        current_user_turn_text
                    ),
                    instructions=instructions,
                    session_id=session_id,
                    display=display,
                    session_usage=session_usage,
                    turn_usage=turn_usage,
                    tracer=tracer,
                )
            else:
                response = provider.request_turn(
                    tool_result_items=tool_result_items,
                    instructions=instructions,
                    session_id=session_id,
                    display=display,
                    session_usage=session_usage,
                    turn_usage=turn_usage,
                    tracer=tracer,
                )
            _raise_if_interrupted(display)
            if tracer is not None:
                tracer.log_event(
                    "agent_step_end",
                    metadata={"step": "tool_iteration"},
                )
            request_count += 1
        except SessionTurnInterrupted:
            raise
        except Exception:
            _log.exception("Follow-up request after tool execution failed")
            raise

    return response, had_errors, request_count


def _raise_if_sub_agent_timed_out(
    started_at: float,
    *,
    max_elapsed_seconds: float = SUB_AGENT_MAX_ELAPSED_SECONDS,
) -> None:
    elapsed = time.monotonic() - started_at
    if elapsed > max_elapsed_seconds:
        raise SubAgentRunError(
            "timeout",
            (f"Sub-agent exceeded the wall-clock limit ({int(max_elapsed_seconds)}s)."),
        )


# ---------------------------------------------------------------------------
# Session store helpers (fail-safe: never crash the main loop)
# ---------------------------------------------------------------------------


def _open_store(settings: Settings) -> SessionStore | None:
    try:
        return SessionStore()
    except Exception:
        _log.warning("Failed to open session store", exc_info=True)
        return None


def _persist_runtime_change(
    store: SessionStore | None,
    session_id: str | None,
    runtime: ResolvedRuntime,
) -> None:
    if store is None or session_id is None:
        return
    try:
        store.update_session(
            session_id,
            provider=runtime.settings.provider,
            provider_id=runtime.provider_id or None,
            model=runtime.settings.model,
            profile_id=runtime.profile_id or None,
            clear_previous_id=True,
        )
    except Exception:
        _log.warning("Failed to persist runtime change", exc_info=True)


def _create_session(
    store: SessionStore | None,
    runtime: ResolvedRuntime,
    *,
    title: str = "",
) -> str | None:
    if store is None:
        return None
    try:
        settings = runtime.settings
        return store.create_session(
            directory=current_workspace_context().directory_key,
            provider=settings.provider,
            provider_id=runtime.provider_id or None,
            model=settings.model,
            profile_id=runtime.profile_id or None,
            title=title,
        )
    except Exception:
        _log.warning("Failed to create session", exc_info=True)
        return None


def _update_session_after_turn(
    store: SessionStore | None,
    session_id: str | None,
    runtime: ResolvedRuntime,
    session_usage: TokenUsage,
) -> None:
    if store is None or session_id is None:
        return
    try:
        snap = session_usage.snapshot()
        store.update_session(
            session_id,
            provider=runtime.settings.provider,
            provider_id=runtime.provider_id or None,
            model=runtime.settings.model,
            profile_id=runtime.profile_id or None,
            clear_previous_id=True,
            total_tokens=snap.total_tokens,
            input_tokens=snap.input_tokens,
            output_tokens=snap.output_tokens,
            cost_usd=snap.estimated_cost_usd,
        )
    except Exception:
        _log.warning("Failed to update session after turn", exc_info=True)


def _refresh_provider_history_from_store(
    provider: Provider,
    store: SessionStore | None,
    session_id: str | None,
    *,
    reason: str,
) -> None:
    reset_conversation = getattr(provider, "reset_conversation", None)
    restore_messages = getattr(provider, "restore_messages", None)
    if not callable(reset_conversation) or not callable(restore_messages):
        return
    try:
        messages = []
        if store is not None and session_id is not None:
            messages = _messages_for_provider_restore(store.list_messages(session_id))
    except Exception:
        _log.warning(
            "Failed to load provider history after %s",
            reason,
            exc_info=True,
        )
        return
    try:
        reset_conversation()
        restore_messages(messages)
    except Exception:
        _log.warning(
            "Failed to refresh provider history after %s",
            reason,
            exc_info=True,
        )


def _update_session_title(
    store: SessionStore | None,
    session_id: str | None,
    title: str,
) -> None:
    if store is None or session_id is None:
        return
    try:
        store.update_session(session_id, title=title)
    except Exception:
        _log.warning("Failed to update session title", exc_info=True)


def _add_message(
    store: SessionStore | None,
    session_id: str | None,
    runtime: ResolvedRuntime,
    role: str,
    content: str,
    *,
    file_paths: list[str] | None = None,
    image_attachments: list[MessageImageAttachment] | None = None,
) -> int | None:
    if store is None or session_id is None:
        return None
    try:
        return store.add_message(
            session_id,
            role,
            content,
            file_paths=file_paths,
            provider_id=runtime.provider_id or None,
            profile_id=runtime.profile_id or None,
            image_attachments=image_attachments,
        )
    except Exception:
        _log.warning("Failed to add message to session store", exc_info=True)
        return None


def _publish_persisted_message(
    display: DisplayProtocol,
    store: SessionStore | None,
    message_id: int | None,
    *,
    previous_item_id: str | None = None,
) -> None:
    handler = getattr(display, "persisted_message", None)
    if store is None or message_id is None or not callable(handler):
        return
    try:
        message = store.get_message(message_id)
    except Exception:
        _log.warning("Failed to load persisted message for display", exc_info=True)
        return
    if message is None:
        return
    try:
        handler(message, previous_item_id=previous_item_id)
    except Exception:
        _log.warning("Failed to publish persisted message to display", exc_info=True)


def _delete_message(store: SessionStore | None, message_id: int | None) -> None:
    if store is None or message_id is None:
        return
    try:
        store.delete_message(message_id)
    except Exception:
        _log.warning("Failed to delete message from session store", exc_info=True)


def _discard_interrupted_turn(
    *,
    provider: Provider,
    store: SessionStore | None,
    session_id: str | None,
    user_message_id: int | None,
) -> None:
    _delete_message(store, user_message_id)
    _refresh_provider_history_from_store(
        provider,
        store,
        session_id,
        reason="interrupt",
    )


def _resume_session(
    *,
    provider: Any,
    store: SessionStore | None,
    session_id: str | None,
    session_usage: TokenUsage,
    display: DisplayProtocol,
    replay_history: bool = True,
    before_message_id: int | None = None,
) -> None:
    if store is None or session_id is None:
        return
    rec = None
    messages = []
    try:
        messages = store.list_messages(session_id)
        if before_message_id is not None:
            messages = [
                message for message in messages if message.id < before_message_id
            ]
    except Exception:
        _log.warning("Failed to restore session history", exc_info=True)

    try:
        rec = store.get_session(session_id)
        if rec and (rec.input_tokens or rec.output_tokens):
            provider_name = provider.settings.provider
            restored_usage = TokenUsage(
                input_tokens=rec.input_tokens,
                output_tokens=rec.output_tokens,
                model=session_usage.model,
            )
            if provider_name == "google":
                restored_usage.provider_total_tokens = rec.total_tokens
            session_usage.add(restored_usage)
            display.session_usage(session_usage)
    except Exception:
        _log.warning("Failed to restore session state", exc_info=True)
    if messages:
        provider_messages = _messages_for_provider_restore(messages)
        try:
            if provider_messages:
                provider.restore_messages(provider_messages)
            if replay_history:
                display.replay_history(messages)
        except Exception:
            _log.warning("Failed to apply restored session history", exc_info=True)


def _messages_for_provider_restore(
    messages: list[MessageRecord],
) -> list[MessageRecord]:
    restored = _active_context_messages(messages)
    summary_indexes = [
        index
        for index, message in enumerate(restored)
        if _is_compaction_summary(message)
    ]
    if summary_indexes:
        latest_summary_index = summary_indexes[-1]
        restored = [
            restored[latest_summary_index],
            *restored[:latest_summary_index],
            *restored[latest_summary_index + 1 :],
        ]
    while restored and restored[-1].role == "user":
        restored.pop()
    return restored


def _active_context_messages(
    messages: list[MessageRecord] | tuple[MessageRecord, ...],
) -> list[MessageRecord]:
    marker_index = _latest_compaction_marker_index(messages)
    if marker_index is None:
        return list(messages)
    return list(messages[marker_index + 1 :])


def _latest_compaction_marker_index(
    messages: list[MessageRecord] | tuple[MessageRecord, ...],
) -> int | None:
    for index in range(len(messages) - 1, -1, -1):
        if _is_compaction_marker(messages[index]):
            return index
    return None


def _is_compaction_marker(message: MessageRecord) -> bool:
    return message.role == "assistant" and message.content.strip() == COMPACTION_MARKER


def _is_compaction_summary(message: MessageRecord) -> bool:
    return message.role == "assistant" and message.content.strip().startswith(
        COMPACTION_SUMMARY_PREFIX
    )


def _strip_compaction_summary_prefix(content: str) -> str:
    stripped = content.strip()
    if stripped.startswith(COMPACTION_SUMMARY_PREFIX):
        return stripped[len(COMPACTION_SUMMARY_PREFIX) :].strip()
    return stripped


def _latest_compaction_summary(messages: list[MessageRecord]) -> str | None:
    marker_index = _latest_compaction_marker_index(messages)
    if marker_index is None:
        return None
    for message in messages[marker_index + 1 :]:
        if _is_compaction_summary(message):
            return _strip_compaction_summary_prefix(message.content)
    return None


def _provider_has_server_side_compaction(provider: Provider) -> bool:
    request_options = getattr(provider, "_responses_request_options", None)
    if not callable(request_options):
        return False
    try:
        options = request_options()
    except Exception:
        _log.debug(
            "Failed to inspect provider context-management support",
            exc_info=True,
        )
        return False
    return bool(getattr(options, "include_context_management", False))


def _compaction_continuation_prompt(last_user_message: str | None) -> str:
    return COMPACTION_CONTINUATION_PROMPT.format(
        last_user_message=(last_user_message or "").strip() or "(not available)"
    )


def _should_auto_compact(
    *,
    session_usage: TokenUsage,
    settings: Settings,
    store: SessionStore | None,
    session_id: str | None,
) -> bool:
    threshold = max(settings.compact_threshold, 0)
    if threshold <= 0:
        return False
    context_tokens = session_usage.snapshot().context_tokens
    if context_tokens <= 0:
        context_tokens = _estimate_active_context_tokens(store, session_id)
    return context_tokens >= threshold


def _estimate_active_context_tokens(
    store: SessionStore | None,
    session_id: str | None,
) -> int:
    if store is None or session_id is None:
        return 0
    try:
        messages = _active_context_messages(store.list_messages(session_id))
    except Exception:
        _log.warning("Failed to estimate active context size", exc_info=True)
        return 0
    chars = sum(len(message.role) + len(message.content) + 8 for message in messages)
    return max(1, chars // 4) if chars else 0


@dataclass(slots=True)
class _CompactionContext:
    previous_summary: str | None
    head_messages: list[MessageRecord]
    tail_messages: list[MessageRecord]


def _split_messages_for_compaction(
    messages: list[MessageRecord],
    settings: Settings,
) -> _CompactionContext:
    previous_summary = _latest_compaction_summary(messages)
    active_messages = _active_context_messages(messages)
    candidates = [
        message
        for message in active_messages
        if message.role in {"user", "assistant"}
        and not _is_compaction_marker(message)
        and not _is_compaction_summary(message)
    ]
    tail_start = _compaction_tail_start_index(candidates, settings)
    if tail_start is None:
        return _CompactionContext(
            previous_summary=previous_summary,
            head_messages=candidates,
            tail_messages=[],
        )
    return _CompactionContext(
        previous_summary=previous_summary,
        head_messages=candidates[:tail_start],
        tail_messages=candidates[tail_start:],
    )


def _compaction_tail_start_index(
    messages: list[MessageRecord],
    settings: Settings,
) -> int | None:
    tail_turns = max(settings.compact_tail_turns, 0)
    budget = max(settings.compact_preserve_recent_tokens, 0)
    if tail_turns <= 0 or budget <= 0:
        return None
    user_indexes = [
        index for index, message in enumerate(messages) if message.role == "user"
    ]
    if not user_indexes:
        return None
    selected = user_indexes[-tail_turns:]
    while len(selected) > 1:
        estimated = _estimate_messages_tokens(messages[selected[0] :])
        if estimated <= budget:
            break
        selected.pop(0)
    return selected[0]


def _estimate_messages_tokens(messages: list[MessageRecord]) -> int:
    chars = sum(len(message.role) + len(message.content) + 8 for message in messages)
    return max(1, chars // 4) if chars else 0


def _rewrite_compacted_context(
    store: SessionStore,
    session_id: str,
    runtime: ResolvedRuntime,
    *,
    compaction_context: _CompactionContext,
    summary_content: str,
) -> None:
    for message in [
        *compaction_context.head_messages,
        *compaction_context.tail_messages,
    ]:
        _delete_message(store, message.id)
    _add_message(store, session_id, runtime, "assistant", COMPACTION_MARKER)
    _add_message(store, session_id, runtime, "assistant", summary_content)
    for message in compaction_context.tail_messages:
        _add_message(
            store,
            session_id,
            runtime,
            message.role,
            message.content,
            file_paths=message.file_paths,
            image_attachments=message.image_attachments,
        )


def _compact_live_session(
    *,
    provider: Provider,
    store: SessionStore | None,
    session_id: str | None,
    runtime: ResolvedRuntime,
    display: DisplayProtocol,
    session_usage: TokenUsage,
    reason: str,
    pending_tool_calls: list[ToolCall] | None = None,
    pending_tool_result_items: list[dict[str, Any]] | None = None,
    pending_tool_exchanges: (
        list[tuple[list[ToolCall], list[dict[str, Any]]]] | None
    ) = None,
) -> int:
    if store is None or session_id is None:
        return session_usage.snapshot().context_tokens
    try:
        messages = store.list_messages(session_id)
    except Exception:
        _log.warning("Failed to load session context for compaction", exc_info=True)
        return session_usage.snapshot().context_tokens
    compaction_context = _split_messages_for_compaction(messages, runtime.settings)
    tool_exchanges = _normalize_tool_exchanges_for_compaction(
        pending_tool_exchanges=pending_tool_exchanges,
        pending_tool_calls=pending_tool_calls,
        pending_tool_result_items=pending_tool_result_items,
    )
    has_pending_tool_exchange = bool(tool_exchanges)
    summary_input_messages = (
        compaction_context.head_messages or compaction_context.tail_messages
    )
    if (
        not summary_input_messages
        and not compaction_context.previous_summary
        and not has_pending_tool_exchange
    ):
        display.render_markdown("No completed session context to compact yet.")
        return 0

    compaction_usage = TokenUsage(
        model=_selected_model(runtime.settings),
        service_tier=runtime.settings.service_tier or "",
    )
    tracer = RunTracer.start(
        store=store,
        session_id=session_id,
        agent_name="main",
        agent_type="compaction",
        provider=runtime.settings.provider,
        provider_id=runtime.provider_id,
        profile_id=runtime.profile_id,
        model=_selected_model(runtime.settings),
        metadata={
            "reason": reason,
            "input_message_count": len(summary_input_messages),
            "tail_message_count": len(compaction_context.tail_messages),
            "pending_tool_exchange": has_pending_tool_exchange,
        },
    )
    display.render_markdown("Compacting live session context...")
    try:
        tracer.log_event(
            "agent_step_start",
            metadata={"step": "compaction_summary"},
        )
        summary = _summarize_session_context(
            messages=summary_input_messages,
            runtime=runtime,
            display=display,
            session_usage=session_usage,
            turn_usage=compaction_usage,
            tracer=tracer,
            previous_summary=compaction_context.previous_summary,
            pending_tool_exchanges=tool_exchanges,
        )
        tracer.log_event(
            "agent_step_end",
            metadata={"step": "compaction_summary"},
        )
    except Exception as exc:
        tracer.log_error(str(exc), metadata={"phase": "compaction"})
        tracer.finish(
            status="failed",
            usage=compaction_usage,
            metadata={"reason": reason, "error_message": str(exc)},
        )
        raise
    finally:
        display.wait_stop()
    if not summary:
        display.render_markdown("Context compaction did not produce a summary.")
        tracer.finish(
            status="failed",
            usage=compaction_usage,
            metadata={"reason": reason, "empty_summary": True},
        )
        return session_usage.snapshot().context_tokens

    summary_content = f"{COMPACTION_SUMMARY_PREFIX}\n\n{summary}"
    _rewrite_compacted_context(
        store,
        session_id,
        runtime,
        compaction_context=compaction_context,
        summary_content=summary_content,
    )
    _refresh_provider_history_from_store(
        provider,
        store,
        session_id,
        reason="compaction",
    )
    _update_session_after_turn(
        store,
        session_id,
        runtime,
        session_usage,
    )
    estimated_context_tokens = max(1, len(summary_content) // 4)
    display.render_markdown(
        f"Context compacted ({reason}); future turns will use the summary."
    )
    tracer.finish(
        status="completed",
        usage=compaction_usage,
        metadata={
            "reason": reason,
            "summary_chars": len(summary_content),
            "estimated_context_tokens": estimated_context_tokens,
            "pending_tool_exchange": has_pending_tool_exchange,
        },
    )
    return estimated_context_tokens


def _summarize_session_context(
    *,
    messages: list[MessageRecord],
    runtime: ResolvedRuntime,
    display: DisplayProtocol,
    session_usage: TokenUsage,
    turn_usage: TokenUsage,
    tracer: RunTracer | None = None,
    previous_summary: str | None = None,
    pending_tool_calls: list[ToolCall] | None = None,
    pending_tool_result_items: list[dict[str, Any]] | None = None,
    pending_tool_exchanges: (
        list[tuple[list[ToolCall], list[dict[str, Any]]]] | None
    ) = None,
) -> str:
    transcript = _format_messages_for_compaction(
        messages,
        tool_output_max_chars=runtime.settings.compact_tool_output_max_chars,
        pending_tool_calls=pending_tool_calls,
        pending_tool_result_items=pending_tool_result_items,
        pending_tool_exchanges=pending_tool_exchanges,
    )
    previous_summary = (previous_summary or "").strip() or None
    if not transcript and previous_summary is None:
        return ""
    user_message = _build_compaction_request(
        transcript=transcript,
        previous_summary=previous_summary,
    )
    with _open_compaction_provider(runtime.settings) as compact_provider:
        response = compact_provider.request_turn(
            user_message=user_message,
            display=display,
            session_usage=session_usage,
            turn_usage=turn_usage,
            tracer=tracer,
        )
    return response.text.strip()


def _build_compaction_request(
    *,
    transcript: str,
    previous_summary: str | None,
) -> str:
    if previous_summary:
        sections = [
            "Update the anchored compacted summary using the new context below. ",
            "Preserve still-true details, remove stale details, and merge new facts.",
            "<previous_summary>",
            previous_summary,
            "</previous_summary>",
            "<new_context_to_merge>",
            transcript,
            "</new_context_to_merge>",
        ]
        return "\n".join(sections)
    return f"<session_transcript>\n{transcript}\n</session_transcript>"


def _format_messages_for_compaction(
    messages: list[MessageRecord],
    *,
    tool_output_max_chars: int = 2000,
    pending_tool_calls: list[ToolCall] | None = None,
    pending_tool_result_items: list[dict[str, Any]] | None = None,
    pending_tool_exchanges: (
        list[tuple[list[ToolCall], list[dict[str, Any]]]] | None
    ) = None,
) -> str:
    chunks: list[str] = []
    for message in messages:
        if message.role not in {"user", "assistant"}:
            continue
        if _is_compaction_marker(message):
            continue
        content = message.content.strip()
        if not content:
            continue
        chunks.extend([f"<{message.role}>", content, f"</{message.role}>"])
    tool_exchange = _format_tool_exchanges_for_compaction(
        _normalize_tool_exchanges_for_compaction(
            pending_tool_exchanges=pending_tool_exchanges,
            pending_tool_calls=pending_tool_calls,
            pending_tool_result_items=pending_tool_result_items,
        ),
        tool_output_max_chars=tool_output_max_chars,
    )
    if tool_exchange:
        chunks.append(tool_exchange)
    return "\n".join(chunks)


def _normalize_tool_exchanges_for_compaction(
    *,
    pending_tool_exchanges: (
        list[tuple[list[ToolCall], list[dict[str, Any]]]] | None
    ) = None,
    pending_tool_calls: list[ToolCall] | None = None,
    pending_tool_result_items: list[dict[str, Any]] | None = None,
) -> list[tuple[list[ToolCall], list[dict[str, Any]]]]:
    exchanges: list[tuple[list[ToolCall], list[dict[str, Any]]]] = []
    for calls, results in pending_tool_exchanges or []:
        normalized_calls = list(calls or [])
        normalized_results = list(results or [])
        if normalized_calls or normalized_results:
            exchanges.append((normalized_calls, normalized_results))
    if not exchanges and (pending_tool_calls or pending_tool_result_items):
        exchanges.append(
            (list(pending_tool_calls or []), list(pending_tool_result_items or []))
        )
    return exchanges


def _format_tool_exchanges_for_compaction(
    tool_exchanges: list[tuple[list[ToolCall], list[dict[str, Any]]]],
    *,
    tool_output_max_chars: int = 2000,
) -> str:
    if not tool_exchanges:
        return ""
    if len(tool_exchanges) == 1:
        return _format_one_tool_exchange_for_compaction(
            "pending_tool_exchange",
            tool_exchanges[0][0],
            tool_exchanges[0][1],
            tool_output_max_chars=tool_output_max_chars,
        )
    chunks = ["<current_turn_tool_exchanges>"]
    for index, (calls, results) in enumerate(tool_exchanges, start=1):
        chunks.append(
            _format_one_tool_exchange_for_compaction(
                f'tool_exchange index="{index}"',
                calls,
                results,
                tool_output_max_chars=tool_output_max_chars,
            )
        )
    chunks.append("</current_turn_tool_exchanges>")
    return "\n".join(chunks)


def _format_one_tool_exchange_for_compaction(
    tag: str,
    calls: list[ToolCall],
    results: list[dict[str, Any]],
    *,
    tool_output_max_chars: int = 2000,
) -> str:
    if not calls and not results:
        return ""
    chunks = [f"<{tag}>"]
    if calls:
        chunks.append("<tool_calls>")
        for call in calls:
            chunks.append(
                _safe_json_dumps(
                    {
                        "call_id": call.call_id,
                        "name": call.name,
                        "arguments": call.arguments,
                    }
                )
            )
        chunks.append("</tool_calls>")
    if results:
        chunks.append("<tool_results>")
        for item in results:
            chunks.append(
                _safe_json_dumps(
                    _truncate_for_compaction(item, max_chars=tool_output_max_chars)
                )
            )
        chunks.append("</tool_results>")
    tag_name = tag.split(maxsplit=1)[0]
    chunks.append(f"</{tag_name}>")
    return "\n".join(chunks)


def _safe_json_dumps(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    except TypeError:
        return repr(value)


def _truncate_for_compaction(value: Any, *, max_chars: int) -> Any:
    if max_chars <= 0:
        if isinstance(value, str):
            return _compaction_truncation_notice(value, kept_chars=0)
        if isinstance(value, dict):
            return {
                key: _truncate_for_compaction(item, max_chars=max_chars)
                for key, item in value.items()
            }
        if isinstance(value, list):
            return [
                _truncate_for_compaction(item, max_chars=max_chars) for item in value
            ]
        return value
    if isinstance(value, str):
        if len(value) <= max_chars:
            return value
        return (
            value[:max_chars]
            + "\n"
            + _compaction_truncation_notice(value, kept_chars=max_chars)
        )
    if isinstance(value, dict):
        return {
            key: (
                item
                if _is_tool_result_metadata_key(key)
                else _truncate_for_compaction(item, max_chars=max_chars)
            )
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_truncate_for_compaction(item, max_chars=max_chars) for item in value]
    return value


def _compaction_truncation_notice(value: str, *, kept_chars: int) -> str:
    return (
        "[truncated for compaction: "
        f"original_chars={len(value)}, kept_chars={kept_chars}]"
    )


def _is_tool_result_metadata_key(key: object) -> bool:
    return key in {
        "type",
        "call_id",
        "id",
        "name",
        "status",
        "exit_code",
        "returncode",
        "path",
        "file_path",
    }


def _build_parent_context_snapshot(
    *,
    provider: Provider,
    store: SessionStore | None,
    session_id: str | None,
    current_user_turn_text: str | None,
) -> ParentContextSnapshot | None:
    messages: tuple = ()
    if store is not None and session_id is not None:
        try:
            messages = tuple(_active_context_messages(store.list_messages(session_id)))
        except Exception:
            _log.warning("Failed to capture parent session history", exc_info=True)

    current_turn = (current_user_turn_text or "").strip() or None
    if current_turn and messages:
        last_message = messages[-1]
        if last_message.role == "user" and last_message.content.strip() == current_turn:
            messages = messages[:-1]

    continuation_id: str | None = None
    try:
        continuation_id = provider.get_conversation_checkpoint()
    except Exception:
        _log.warning(
            "Failed to capture provider conversation checkpoint", exc_info=True
        )

    if not messages and current_turn is None and continuation_id is None:
        return None

    provider_name = getattr(provider.settings, "provider", "")
    return ParentContextSnapshot(
        provider=provider_name,
        continuation_id=continuation_id,
        messages=messages,
        current_user_turn=current_turn,
    )


def _apply_sub_agent_parent_context(
    *,
    provider: Provider,
    provider_name: str,
    include_context: bool,
    parent_context: ParentContextSnapshot | None,
) -> None:
    if not include_context or parent_context is None:
        return

    if provider_name not in {"openai", "azure", "google"}:
        return

    continuation_id = (parent_context.continuation_id or "").strip()
    if continuation_id:
        provider.set_previous_response_id(continuation_id)


def _build_sub_agent_initial_message(
    task_instruction: str,
    *,
    provider_name: str,
    include_context: bool,
    parent_context: ParentContextSnapshot | None,
) -> str:
    if not include_context or parent_context is None:
        return task_instruction

    if provider_name in {"openai", "azure", "google"}:
        if (parent_context.continuation_id or "").strip():
            return task_instruction

    transcript_lines: list[str] = []
    for message in parent_context.messages:
        if message.role not in {"user", "assistant"}:
            continue
        content = message.content.strip()
        if not content:
            continue
        transcript_lines.extend(
            [
                f"<{message.role}>",
                content,
                f"</{message.role}>",
            ]
        )

    current_user_turn = (parent_context.current_user_turn or "").strip()
    if current_user_turn:
        last_message = parent_context.messages[-1] if parent_context.messages else None
        if not (
            last_message
            and last_message.role == "user"
            and last_message.content.strip() == current_user_turn
        ):
            transcript_lines.extend(
                [
                    "<user>",
                    current_user_turn,
                    "</user>",
                ]
            )

    if not transcript_lines:
        return task_instruction

    sections = [
        "Use the parent conversation below as context for the delegated task.",
        "",
        "<parent_conversation>",
        *transcript_lines,
        "</parent_conversation>",
        "",
        "<delegated_task>",
        task_instruction,
        "</delegated_task>",
    ]
    return "\n".join(sections)


def _close_store(store: SessionStore | None) -> None:
    if store is None:
        return
    try:
        store.close()
    except Exception:
        _log.warning("Failed to close session store", exc_info=True)


def _build_user_turn_input(
    *,
    text: str,
    image_paths: list[str],
    images: list[ImageAttachment] | None,
    settings: Settings,
) -> UserTurnInput:
    resolved_images = list(images or [])
    if image_paths:
        root = Path.cwd().resolve()
        resolved_images.extend(load_workspace_image(root, path) for path in image_paths)
    return UserTurnInput(text=text, images=resolved_images)


def _normalize_user_command(value: str) -> str:
    return " ".join(value.strip().lower().split())


def _reload_provider_initialization(provider: Provider) -> None:
    provider.set_system_prompt(get_system_prompt())
    provider.refresh_tools()


def _request_user_turn(
    *,
    provider: Any,
    user_input: UserTurnInput,
    session_id: str | None,
    instructions: str | None,
    display: DisplayProtocol,
    session_usage: TokenUsage,
    turn_usage: TokenUsage,
    tracer: RunTracer | None = None,
) -> CompletedResponse:
    return provider.request_turn(
        user_input=user_input,
        instructions=instructions,
        session_id=session_id,
        display=display,
        session_usage=session_usage,
        turn_usage=turn_usage,
        tracer=tracer,
    )


def _user_turn_history_text(user_input: UserTurnInput) -> str:
    text = user_input.text.strip()
    if not user_input.images:
        return text

    attachment_label = ", ".join(image.path for image in user_input.images)
    if text:
        return f"{text}\n\n[attached images: {attachment_label}]"
    return f"[attached images: {attachment_label}]"


def _session_title_for_user_turn(user_input: UserTurnInput) -> str:
    return _user_turn_history_text(user_input)[:80]
