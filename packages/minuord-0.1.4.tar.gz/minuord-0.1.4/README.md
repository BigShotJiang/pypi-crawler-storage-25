# minuord

`minuord` is a minimal Python library for building Discord bots from scratch, without `discord.py` and other Discord SDKs.

## Features

- Direct integration with Discord REST API (HTTP)
- Direct integration with Discord Gateway (WebSocket)
- Async architecture (`asyncio` + `aiohttp`)
- Automatic heartbeat handling
- Reconnection loop with backoff
- Event decorators:
  - `@bot.event()`
  - `@bot.on_ready()`
  - `@bot.command()`
- Basic events support:
  - `READY`
  - `MESSAGE_CREATE`
- Simple prefix commands parser
- Sending messages to channels via REST
- Command aliases and descriptions
- Built-in `!help` command
- Sync and async handlers (events and commands)
- `ctx.reply(...)` support
- `Embed` model for rich messages

## Project structure

```text
minuord/
├─ minuord/
│  ├─ __init__.py
│  ├─ bot.py
│  ├─ constants.py
│  ├─ errors.py
│  ├─ gateway.py
│  ├─ http.py
│  ├─ logger.py
│  └─ models.py
├─ examples/
│  └─ minimal_bot.py
├─ pyproject.toml
└─ README.md
```

## Installation

### Local (development)

```bash
pip install -e .
```

### From PyPI (after publication)

```bash
pip install minuord
```

## Minimal usage

```python
import os
from minuord import Bot, setup_logging

setup_logging()

bot = Bot(token=os.environ["DISCORD_TOKEN"], command_prefix="!")

@bot.on_ready()
async def ready(payload: dict):
    print("Bot is ready:", payload["user"]["username"])

@bot.command()
async def ping(ctx):
    await ctx.send("pong")

bot.run()
```

## Status and embed example

```python
from minuord import Bot

bot = Bot(
    token="YOUR_TOKEN",
    command_prefix="!",
    status="dnd",  # online | idle | dnd
    status_text="watching commands",
)

@bot.command(name="hello")
def hello_command():
    print("Команда hello вызвана!")

@bot.command(name="embed")
async def embed_command(ctx):
    from minuord import Embed
    await bot.send_embed(
        ctx.message.channel_id,
        embed=Embed(title="Hello from minuord", description="Embed message example", color=0x00B0F4),
    )

if __name__ == "__main__":
    bot.run()
```

You can also define commands with aliases and descriptions:

```python
@bot.command(name="ping", aliases=["p"], description="Ping command")
async def ping(ctx):
    await ctx.reply("pong")
```

## How it works

- `bot.py`: high-level bot API, decorators, command parsing, event dispatch
- `gateway.py`: low-level Gateway connection, heartbeat, identify/resume, reconnect
- `http.py`: low-level REST client for Discord API requests
- `models.py`: lightweight domain models (`Message`, `User`, `Context`)
- `errors.py`: custom exceptions

## Discord intents

By default, `Bot` enables:

- `GUILDS`
- `GUILD_MESSAGES`
- `MESSAGE_CONTENT`

You can override intents manually:

```python
from minuord import Bot, INTENTS

bot = Bot(
    token="YOUR_TOKEN",
    intents=INTENTS["GUILDS"] | INTENTS["GUILD_MESSAGES"] | INTENTS["MESSAGE_CONTENT"],
)
```

## Build and publish to PyPI

1. Update version in `pyproject.toml`.
2. Install build tools:

   ```bash
   python -m pip install --upgrade build twine
   ```

3. Build distribution:

   ```bash
   python -m build
   ```

4. Check artifacts:

   ```bash
   python -m twine check dist/*
   ```

5. Publish to TestPyPI (recommended first):

   ```bash
   python -m twine upload --repository testpypi dist/*
   ```

6. Publish to PyPI:

   ```bash
   python -m twine upload dist/*
   ```

## Security notes

- Never hardcode your Discord token in source code.
- Use environment variables for secrets.
- Enable only the intents your bot actually needs.
