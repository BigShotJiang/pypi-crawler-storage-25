from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

import aiohttp

from .constants import GATEWAY_URL, OPCODES
from .errors import GatewayError

DispatchHandler = Callable[[str, dict[str, Any]], Awaitable[None]]

_log = logging.getLogger("minuord.gateway")


class GatewayClient:
    def __init__(
        self,
        token: str,
        intents: int,
        session: aiohttp.ClientSession,
        dispatch_handler: DispatchHandler,
        status: str = "online",
        activity_text: str | None = None,
        activity_type: int = 0,
        gateway_url: str = GATEWAY_URL,
    ) -> None:
        self.token = token
        self.intents = intents
        self.session = session
        self.dispatch_handler = dispatch_handler
        self.gateway_url = gateway_url
        self.status = status
        self.activity_text = activity_text
        self.activity_type = activity_type

        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._heartbeat_interval: float | None = None
        self._sequence: int | None = None
        self._session_id: str | None = None
        self._last_heartbeat_ack = True
        self._closed = False

    async def connect_forever(self) -> None:
        backoff = 1
        while not self._closed:
            try:
                await self._connect_once()
                backoff = 1
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                _log.warning("Gateway disconnected (%s). Reconnecting in %ss...", exc, backoff)
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30)

    async def close(self) -> None:
        self._closed = True
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
        if self._ws and not self._ws.closed:
            await self._ws.close()

    async def _connect_once(self) -> None:
        _log.info("Connecting to Discord Gateway...")
        self._ws = await self.session.ws_connect(self.gateway_url, heartbeat=None)
        await self._receive_loop()

    async def _receive_loop(self) -> None:
        assert self._ws is not None
        async for msg in self._ws:
            if msg.type == aiohttp.WSMsgType.TEXT:
                payload = json.loads(msg.data)
                await self._handle_payload(payload)
            elif msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.CLOSED):
                raise GatewayError("Gateway closed connection.")
            elif msg.type == aiohttp.WSMsgType.ERROR:
                raise GatewayError("Gateway websocket error.")

    async def _handle_payload(self, payload: dict[str, Any]) -> None:
        op = payload.get("op")
        t = payload.get("t")
        d = payload.get("d")
        s = payload.get("s")
        if s is not None:
            self._sequence = s

        if op == OPCODES["HELLO"]:
            await self._start_heartbeat(d["heartbeat_interval"] / 1000.0)
            if self._session_id:
                await self._send_resume()
            else:
                await self._send_identify()
            return

        if op == OPCODES["HEARTBEAT_ACK"]:
            self._last_heartbeat_ack = True
            return

        if op == OPCODES["RECONNECT"]:
            raise GatewayError("Discord requested reconnect.")

        if op == OPCODES["INVALID_SESSION"]:
            self._session_id = None
            await asyncio.sleep(1)
            await self._send_identify()
            return

        if op == OPCODES["DISPATCH"]:
            if t == "READY":
                self._session_id = d.get("session_id")
            await self.dispatch_handler(t, d)

    async def _start_heartbeat(self, interval: float) -> None:
        self._heartbeat_interval = interval
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def _heartbeat_loop(self) -> None:
        while not self._closed:
            if not self._last_heartbeat_ack:
                raise GatewayError("Missed heartbeat ACK from Discord.")
            self._last_heartbeat_ack = False
            await self._send_json({"op": OPCODES["HEARTBEAT"], "d": self._sequence})
            await asyncio.sleep(self._heartbeat_interval or 30.0)

    async def _send_identify(self) -> None:
        activities: list[dict[str, Any]] = []
        if self.activity_text:
            activities.append({"name": self.activity_text, "type": self.activity_type})

        payload = {
            "op": OPCODES["IDENTIFY"],
            "d": {
                "token": self.token,
                "intents": self.intents,
                "properties": {
                    "os": "linux",
                    "browser": "minuord",
                    "device": "minuord",
                },
                "presence": {
                    "since": None,
                    "activities": activities,
                    "status": self.status,
                    "afk": False,
                },
            },
        }
        await self._send_json(payload)
        _log.info("IDENTIFY payload sent.")

    async def _send_resume(self) -> None:
        payload = {
            "op": OPCODES["RESUME"],
            "d": {
                "token": self.token,
                "session_id": self._session_id,
                "seq": self._sequence,
            },
        }
        await self._send_json(payload)
        _log.info("RESUME payload sent.")

    async def _send_json(self, payload: dict[str, Any]) -> None:
        if not self._ws:
            raise GatewayError("Websocket is not connected.")
        await self._ws.send_json(payload)
