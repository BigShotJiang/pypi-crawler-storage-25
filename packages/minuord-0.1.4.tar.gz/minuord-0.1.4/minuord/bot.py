from __future__ import annotations

import asyncio
import inspect
import logging
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

import aiohttp

from .constants import INTENTS
from .gateway import GatewayClient
from .http import DiscordHTTPClient
from .models import Context, Embed, Message

EventHandler = Callable[..., Awaitable[None]]
CommandHandler = Callable[..., Any]

_log = logging.getLogger("minuord.bot")


@dataclass(slots=True)
class RegisteredCommand:
    name: str
    handler: CommandHandler
    description: str | None = None


class Bot:
    def __init__(
        self,
        token: str,
        command_prefix: str = "!",
        intents: int | None = None,
        status: str = "online",
        status_text: str | None = None,
        activity_type: int = 0,
        enable_default_help: bool = True,
    ) -> None:
        self.token = token
        self.command_prefix = command_prefix
        self.intents = intents if intents is not None else (
            INTENTS["GUILDS"] | INTENTS["GUILD_MESSAGES"] | INTENTS["MESSAGE_CONTENT"]
        )
        self.status = status
        self.status_text = status_text
        self.activity_type = activity_type
        self._validate_status(status)

        self._event_handlers: dict[str, list[EventHandler]] = defaultdict(list)
        self._commands: dict[str, RegisteredCommand] = {}
        self._session: aiohttp.ClientSession | None = None
        self._http: DiscordHTTPClient | None = None
        self._gateway: GatewayClient | None = None
        self.user: dict[str, Any] | None = None
        self._ready_event = asyncio.Event()

        if enable_default_help:
            self._register_default_help()

    def event(self, name: str | None = None) -> Callable[[EventHandler], EventHandler]:
        def decorator(coro: EventHandler) -> EventHandler:
            event_name = name or coro.__name__
            if event_name.startswith("on_"):
                event_name = event_name[3:]
            self._event_handlers[event_name.upper()].append(coro)
            return coro

        return decorator

    def on_ready(self) -> Callable[[EventHandler], EventHandler]:
        return self.event("READY")

    def on_message_create(self) -> Callable[[EventHandler], EventHandler]:
        return self.event("MESSAGE_CREATE")

    def command(
        self,
        name: str | None = None,
        *,
        aliases: list[str] | None = None,
        description: str | None = None,
    ) -> Callable[[CommandHandler], CommandHandler]:
        def decorator(coro: CommandHandler) -> CommandHandler:
            command_name = (name or coro.__name__).lower()
            registered = RegisteredCommand(name=command_name, handler=coro, description=description)
            self._commands[command_name] = registered
            for alias in aliases or []:
                self._commands[alias.lower()] = registered
            return coro

        return decorator

    async def send_message(
        self,
        channel_id: str,
        content: str,
        *,
        reply_to_message_id: str | None = None,
    ) -> dict[str, Any]:
        if not self._http:
            raise RuntimeError("HTTP client is not initialized.")
        payload: dict[str, Any] = {"content": content}
        if reply_to_message_id:
            payload["message_reference"] = {"message_id": reply_to_message_id}
        return await self._http.send_message_payload(channel_id, payload)

    async def send_embed(
        self,
        channel_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        color: int = 0x5865F2,
        embed: Embed | None = None,
        reply_to_message_id: str | None = None,
    ) -> dict[str, Any]:
        if not self._http:
            raise RuntimeError("HTTP client is not initialized.")
        if embed is not None:
            payload: dict[str, Any] = {"embeds": [embed.to_dict()]}
            if reply_to_message_id:
                payload["message_reference"] = {"message_id": reply_to_message_id}
            return await self._http.send_message_payload(channel_id, payload)
        return await self._http.send_embed(
            channel_id,
            title=title,
            description=description,
            color=color,
            reply_to_message_id=reply_to_message_id,
        )

    async def _dispatch_event(self, event_name: str, data: dict[str, Any]) -> None:
        if event_name == "READY":
            self.user = data.get("user")
            self._ready_event.set()
        handlers = self._event_handlers.get(event_name, [])
        for handler in handlers:
            try:
                result = handler(data)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                _log.exception("Unhandled exception in %s handler", event_name)

        if event_name == "MESSAGE_CREATE":
            await self._process_commands(data)

    async def _process_commands(self, data: dict[str, Any]) -> None:
        message = Message.from_payload(data)
        if message.author.bot:
            return
        if not message.content.startswith(self.command_prefix):
            return

        raw = message.content[len(self.command_prefix):].strip()
        if not raw:
            return

        parts = raw.split()
        command_name = parts[0].lower()
        args = parts[1:]

        command = self._commands.get(command_name)
        if not command:
            return

        ctx = Context(bot=self, message=message, command=command_name, args=args)
        try:
            result = self._invoke_command_handler(command.handler, ctx)
            if inspect.isawaitable(result):
                await result
        except Exception:
            _log.exception("Unhandled exception in command '%s'", command_name)

    def _invoke_command_handler(self, handler: Callable[..., Any], ctx: Context) -> Any:
        signature = inspect.signature(handler)
        if len(signature.parameters) == 0:
            return handler()
        return handler(ctx)

    @staticmethod
    def _validate_status(status: str) -> None:
        allowed = {"online", "idle", "dnd"}
        if status not in allowed:
            raise ValueError(f"Invalid status '{status}'. Allowed: {', '.join(sorted(allowed))}")

    def _register_default_help(self) -> None:
        async def default_help(ctx: Context) -> None:
            unique_commands: dict[str, RegisteredCommand] = {}
            for command in self._commands.values():
                unique_commands[command.name] = command
            lines = []
            for command_name in sorted(unique_commands):
                description = unique_commands[command_name].description or "No description"
                lines.append(f"{self.command_prefix}{command_name} - {description}")
            await ctx.send("\n".join(lines) if lines else "No commands registered.")

        self._commands["help"] = RegisteredCommand(
            name="help",
            handler=default_help,
            description="Show available commands",
        )

    async def wait_until_ready(self) -> None:
        await self._ready_event.wait()

    async def start(self) -> None:
        self._session = aiohttp.ClientSession()
        self._http = DiscordHTTPClient(self.token, self._session)

        self._gateway = GatewayClient(
            token=self.token,
            intents=self.intents,
            session=self._session,
            dispatch_handler=self._dispatch_event,
            status=self.status,
            activity_text=self.status_text,
            activity_type=self.activity_type,
        )
        await self._gateway.connect_forever()

    async def close(self) -> None:
        if self._gateway:
            await self._gateway.close()
        if self._session and not self._session.closed:
            await self._session.close()

    def run(self) -> None:
        try:
            asyncio.run(self.start())
        except KeyboardInterrupt:
            _log.info("Bot stopped by user.")
