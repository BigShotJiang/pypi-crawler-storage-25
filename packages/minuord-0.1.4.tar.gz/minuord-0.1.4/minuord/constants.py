API_BASE_URL = "https://discord.com/api/v10"
GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"

INTENTS = {
    "GUILDS": 1 << 0,
    "GUILD_MESSAGES": 1 << 9,
    "MESSAGE_CONTENT": 1 << 15,
}

OPCODES = {
    "DISPATCH": 0,
    "HEARTBEAT": 1,
    "IDENTIFY": 2,
    "RESUME": 6,
    "RECONNECT": 7,
    "INVALID_SESSION": 9,
    "HELLO": 10,
    "HEARTBEAT_ACK": 11,
}
