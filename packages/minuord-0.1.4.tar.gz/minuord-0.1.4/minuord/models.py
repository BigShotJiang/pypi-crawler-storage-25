from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class User:
    id: str
    username: str
    bot: bool = False

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "User":
        return cls(
            id=payload["id"],
            username=payload.get("username", "unknown"),
            bot=payload.get("bot", False),
        )


@dataclass(slots=True)
class Message:
    id: str
    channel_id: str
    content: str
    author: User

    @classmethod
    def from_payload(cls, payload: dict[str, Any]) -> "Message":
        return cls(
            id=payload["id"],
            channel_id=payload["channel_id"],
            content=payload.get("content", ""),
            author=User.from_payload(payload["author"]),
        )


@dataclass(slots=True)
class Embed:
    title: str | None = None
    description: str | None = None
    color: int = 0x5865F2

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"color": self.color}
        if self.title is not None:
            payload["title"] = self.title
        if self.description is not None:
            payload["description"] = self.description
        return payload


@dataclass(slots=True)
class Context:
    bot: Any
    message: Message
    command: str
    args: list[str]

    async def send(self, content: str) -> dict[str, Any]:
        return await self.bot.send_message(self.message.channel_id, content)

    async def reply(self, content: str) -> dict[str, Any]:
        return await self.bot.send_message(
            self.message.channel_id,
            content,
            reply_to_message_id=self.message.id,
        )

    async def send_embed(
        self,
        *,
        title: str | None = None,
        description: str | None = None,
        color: int = 0x5865F2,
    ) -> dict[str, Any]:
        return await self.bot.send_embed(
            self.message.channel_id,
            title=title,
            description=description,
            color=color,
        )
