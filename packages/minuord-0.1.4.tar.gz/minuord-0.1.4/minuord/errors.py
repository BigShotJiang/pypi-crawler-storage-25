class MinuordError(Exception):
    """Base exception for minuord."""


class HTTPRequestError(MinuordError):
    """Raised when Discord REST API returns an error."""

    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message
        super().__init__(f"HTTP {status}: {message}")


class GatewayError(MinuordError):
    """Raised for unrecoverable Gateway issues."""
