from __future__ import annotations

import logging
from typing import Any

import aiohttp

from .constants import API_BASE_URL
from .errors import HTTPRequestError

_log = logging.getLogger("minuord.http")


class DiscordHTTPClient:
    def __init__(self, token: str, session: aiohttp.ClientSession):
        self._token = token
        self._session = session

    @property
    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bot {self._token}",
            "Content-Type": "application/json",
        }

    async def request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{API_BASE_URL}{path}"
        async with self._session.request(
            method=method,
            url=url,
            headers=self._headers,
            json=json,
        ) as response:
            text = await response.text()
            if response.status >= 400:
                _log.error("REST request failed: %s %s -> %s", method, path, response.status)
                raise HTTPRequestError(response.status, text)
            if not text:
                return {}
            return await response.json()

    async def send_message(self, channel_id: str, content: str) -> dict[str, Any]:
        return await self.send_message_payload(channel_id, {"content": content})

    async def send_message_payload(
        self,
        channel_id: str,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        return await self.request(
            "POST",
            f"/channels/{channel_id}/messages",
            json=payload,
        )

    async def send_embed(
        self,
        channel_id: str,
        *,
        title: str | None = None,
        description: str | None = None,
        color: int = 0x5865F2,
        reply_to_message_id: str | None = None,
    ) -> dict[str, Any]:
        embed: dict[str, Any] = {"color": color}
        if title is not None:
            embed["title"] = title
        if description is not None:
            embed["description"] = description
        payload: dict[str, Any] = {"embeds": [embed]}
        if reply_to_message_id:
            payload["message_reference"] = {"message_id": reply_to_message_id}
        return await self.request(
            "POST",
            f"/channels/{channel_id}/messages",
            json=payload,
        )

    async def get_gateway_bot(self) -> dict[str, Any]:
        return await self.request("GET", "/gateway/bot")
