"""Standalone architecture metamodel package."""

from architecture_metamodel.api import *  # noqa: F401,F403
