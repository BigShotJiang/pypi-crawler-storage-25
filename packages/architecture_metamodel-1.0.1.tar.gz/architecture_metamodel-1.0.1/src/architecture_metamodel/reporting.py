"""Structured validation reporting for external consumers of the metamodel API.

This module provides API-facing result objects for consumers that need more than
raw issue lists. It belongs at the package surface because downstream
repositories need a stable, testable summary contract for pass/fail outcomes and
for successful versus failed validation checks.
"""

from __future__ import annotations

from dataclasses import dataclass
import json

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue


@dataclass(frozen=True)
class ValidationCheckResult:
    """Outcome for a single validation check family."""

    check_id: str
    check_name: str
    issues: tuple[ValidationIssue, ...]

    @property
    def passed(self) -> bool:
        return self.error_count == 0 and self.warning_count == 0

    @property
    def failed(self) -> bool:
        return not self.passed

    @property
    def error_count(self) -> int:
        return sum(1 for issue in self.issues if issue.severity == IssueSeverity.ERROR)

    @property
    def warning_count(self) -> int:
        return sum(1 for issue in self.issues if issue.severity == IssueSeverity.WARNING)

    @property
    def status(self) -> str:
        return "PASS" if self.passed else "FAIL"

    @property
    def summary(self) -> str:
        return (
            f"{self.status}: {self.check_name} "
            f"({self.error_count} error(s), {self.warning_count} warning(s))"
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "check_id": self.check_id,
            "check_name": self.check_name,
            "status": self.status,
            "passed": self.passed,
            "failed": self.failed,
            "error_count": self.error_count,
            "warning_count": self.warning_count,
            "issues": [issue.to_dict() for issue in self.issues],
            "summary": self.summary,
        }


@dataclass(frozen=True)
class ValidationReport:
    """Structured validation summary for downstream API consumers."""

    checks: tuple[ValidationCheckResult, ...]
    source_path: str | None = None
    element_count: int = 0

    @property
    def issues(self) -> list[ValidationIssue]:
        aggregated: list[ValidationIssue] = []
        for check in self.checks:
            aggregated.extend(check.issues)
        return aggregated

    @property
    def passed(self) -> bool:
        return self.error_count == 0

    @property
    def failed(self) -> bool:
        return not self.passed

    @property
    def error_count(self) -> int:
        return sum(check.error_count for check in self.checks)

    @property
    def warning_count(self) -> int:
        return sum(check.warning_count for check in self.checks)

    @property
    def successful_checks(self) -> list[ValidationCheckResult]:
        return [check for check in self.checks if check.passed]

    @property
    def failed_checks(self) -> list[ValidationCheckResult]:
        return [check for check in self.checks if check.failed]

    @property
    def overall_status(self) -> str:
        return "PASS" if self.passed else "FAIL"

    def to_dict(self) -> dict[str, object]:
        return {
            "status": self.overall_status,
            "passed": self.passed,
            "failed": self.failed,
            "source_path": self.source_path,
            "element_count": self.element_count,
            "error_count": self.error_count,
            "warning_count": self.warning_count,
            "successful_check_count": len(self.successful_checks),
            "failed_check_count": len(self.failed_checks),
            "checks": [check.to_dict() for check in self.checks],
            "issues": [issue.to_dict() for issue in self.issues],
        }

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)

    def to_lines(self) -> list[str]:
        """Render a stable text summary suitable for CLI output and logs."""

        lines = [
            f"Overall: {self.overall_status}",
            f"Source: {self.source_path or '<in-memory>'}",
            f"Elements: {self.element_count}",
            f"Issues: {self.error_count} error(s), {self.warning_count} warning(s)",
            f"Successful validations ({len(self.successful_checks)}):",
        ]

        if self.successful_checks:
            lines.extend(f"  - {check.summary}" for check in self.successful_checks)
        else:
            lines.append("  - None")

        lines.append(f"Failed validations ({len(self.failed_checks)}):")
        if self.failed_checks:
            for check in self.failed_checks:
                lines.append(f"  - {check.summary}")
                lines.extend(f"    * {issue}" for issue in check.issues)
        else:
            lines.append("  - None")

        return lines
