"""Release-oriented smoke checks for build, install, API, and CLI usage."""

from __future__ import annotations

import argparse
import os
import re
import site
import shutil
import subprocess
import sys
import venv
from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4

import yaml


REPO_ROOT = Path(__file__).resolve().parents[3]
SHAKEDOWN_TMP_ROOT = REPO_ROOT / ".tmp_release_shakedown"


@dataclass(frozen=True)
class ShakedownResult:
    step: str
    passed: bool
    detail: str


def _run_command(
    command: list[str],
    *,
    cwd: Path | None = None,
    env: dict[str, str] | None = None,
    ) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=str(cwd) if cwd else None,
        text=True,
        capture_output=True,
        check=False,
        env=env,
    )


def _venv_python(venv_dir: Path) -> Path:
    if sys.platform == "win32":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _console_script(venv_dir: Path, script_name: str) -> Path:
    normalized_names = {
        script_name,
        script_name.replace("-", "_"),
        script_name.replace("_", "-"),
    }
    candidates = []
    if sys.platform == "win32":
        candidates.extend(
            [
                venv_dir / "Scripts" / f"{script_name}.exe",
                venv_dir / "Scripts" / f"{script_name}.cmd",
                venv_dir / "Scripts" / script_name,
            ]
        )
    else:
        candidates.append(venv_dir / "bin" / script_name)

    for candidate in candidates:
        if candidate.exists():
            return candidate

    script_dir = venv_dir / ("Scripts" if sys.platform == "win32" else "bin")
    if script_dir.exists():
        for candidate in script_dir.iterdir():
            if candidate.is_dir():
                continue
            if candidate.stem in normalized_names:
                return candidate
    raise FileNotFoundError(f"Could not locate console script '{script_name}' in {venv_dir}")


def _venv_bin_dir(venv_dir: Path) -> Path:
    return venv_dir / ("Scripts" if sys.platform == "win32" else "bin")


def _write_consumer_fixture(target_dir: Path) -> Path:
    architecture_dir = target_dir / "architecture" / "instance_architecture"
    architecture_dir.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(
        REPO_ROOT / "metamodel" / "architecture_valid_example.yaml",
        architecture_dir / "architecture.yaml",
    )
    return architecture_dir


def _current_runtime_pythonpath() -> str:
    runtime_paths = [path for path in site.getsitepackages() if Path(path).exists()]
    user_site = site.getusersitepackages()
    if Path(user_site).exists():
        runtime_paths.append(user_site)
    existing = os.environ.get("PYTHONPATH")
    if existing:
        runtime_paths.append(existing)
    return os.pathsep.join(runtime_paths)


def _build_venv_command_env(venv_dir: Path, base_env: dict[str, str]) -> dict[str, str]:
    command_env = base_env.copy()
    command_env["VIRTUAL_ENV"] = str(venv_dir)
    command_env["PATH"] = os.pathsep.join([str(_venv_bin_dir(venv_dir)), command_env.get("PATH", "")])
    return command_env


def _load_action_definition() -> dict[str, object]:
    return yaml.safe_load((REPO_ROOT / "action.yml").read_text(encoding="utf-8"))


def _render_action_expression(command: str, *, inputs: dict[str, str], action_path: Path) -> str:
    replacements = {
        "github.action_path": str(action_path),
        **{f"inputs.{name}": value for name, value in inputs.items()},
    }

    def replace(match: re.Match[str]) -> str:
        expression = match.group(1).strip()
        if expression not in replacements:
            raise KeyError(f"Unsupported action expression: {expression}")
        return replacements[expression]

    return re.sub(r"\$\{\{\s*([^}]+?)\s*\}\}", replace, command)


def _powershell_command(rendered_command: str) -> list[str]:
    if sys.platform == "win32":
        return ["powershell", "-Command", rendered_command]
    return ["pwsh", "-Command", rendered_command]


def _run_action_consumer_smoke(
    *,
    venv_dir: Path,
    architecture_dir: Path,
    base_env: dict[str, str],
) -> ShakedownResult:
    action_definition = _load_action_definition()
    runs = action_definition.get("runs", {})
    steps = runs.get("steps", [])
    uses_steps = [step for step in steps if "uses" in step]

    if runs.get("using") != "composite":
        return ShakedownResult(
            step="action_definition_structure",
            passed=False,
            detail="action.yml must declare runs.using: composite.",
        )
    if not any(step.get("uses") == "actions/setup-python@v5" for step in uses_steps):
        return ShakedownResult(
            step="action_definition_structure",
            passed=False,
            detail="action.yml must retain the setup-python step for consumer workflows.",
        )
    install_step = next(
        (step for step in steps if step.get("run") == 'python -m pip install "${{ github.action_path }}"'),
        None,
    )
    if install_step is None:
        return ShakedownResult(
            step="action_definition_structure",
            passed=False,
            detail="action.yml must retain the package install step for consumer workflows.",
        )

    action_env = _build_venv_command_env(venv_dir, base_env)
    github_output = architecture_dir.parent / "github_action_output.txt"
    github_summary = architecture_dir.parent / "github_action_summary.md"
    action_env["GITHUB_OUTPUT"] = str(github_output)
    action_env["GITHUB_STEP_SUMMARY"] = str(github_summary)
    github_output.unlink(missing_ok=True)
    github_summary.unlink(missing_ok=True)

    inputs = {
        "path": str(architecture_dir),
        "format": "json",
        "python-version": "3.11",
    }

    for step in steps:
        if "run" not in step:
            continue
        if step is install_step:
            continue
        rendered_command = _render_action_expression(
            step["run"],
            inputs=inputs,
            action_path=REPO_ROOT,
        )
        result = _run_command(
            _powershell_command(rendered_command),
            env=action_env,
        )
        if result.returncode != 0:
            return ShakedownResult(
                step="action_smoke",
                passed=False,
                detail=(result.stdout + result.stderr).strip(),
            )

    output_text = github_output.read_text(encoding="utf-8")
    summary_text = github_summary.read_text(encoding="utf-8")
    output_lines = [line for line in output_text.splitlines() if line]
    payload = "\n".join(
        [
            output_lines[0] if output_lines else "",
            "result_json<<__ARCHITECTURE_METAMODEL__" if "result_json<<__ARCHITECTURE_METAMODEL__" in output_text else "",
            summary_text.strip(),
        ]
    ).strip()
    return ShakedownResult(
        step="action_smoke",
        passed="status=PASS" in output_text and "result_json<<__ARCHITECTURE_METAMODEL__" in output_text,
        detail=payload,
    )


def run_release_shakedown() -> list[ShakedownResult]:
    results: list[ShakedownResult] = []

    SHAKEDOWN_TMP_ROOT.mkdir(parents=True, exist_ok=True)
    temp_dir = SHAKEDOWN_TMP_ROOT / uuid4().hex
    temp_dir.mkdir(parents=True, exist_ok=False)
    try:
        dist_dir = REPO_ROOT / "dist"
        venv_dir = temp_dir / "venv"
        consumer_root = temp_dir / "consumer_repo"
        shakedown_env = os.environ.copy()
        shakedown_env["PIP_BUILD_TRACKER"] = str(temp_dir / "pip-build-tracker")
        shakedown_env["PYTHONPATH"] = _current_runtime_pythonpath()
        Path(shakedown_env["PIP_BUILD_TRACKER"]).mkdir(parents=True, exist_ok=True)
        dist_dir.mkdir(parents=True, exist_ok=True)
        existing_wheels = set(dist_dir.glob("*.whl"))

        build_result = _run_command(
            [
                sys.executable,
                "-c",
                (
                    "from setuptools.build_meta import build_wheel; "
                    f"print(build_wheel(r'{dist_dir}'))"
                ),
            ],
            cwd=REPO_ROOT,
            env=shakedown_env,
        )
        built_wheels = sorted(
            set(dist_dir.glob("*.whl")) - existing_wheels,
            key=lambda path: path.stat().st_mtime,
        )
        available_wheels = sorted(
            set(dist_dir.glob("*.whl")),
            key=lambda path: path.stat().st_mtime,
        )
        build_detail = (build_result.stdout + build_result.stderr).strip()
        build_passed = build_result.returncode == 0
        if not build_passed and available_wheels and "PermissionError" in build_detail:
            build_passed = True
            build_detail = (
                "Wheel rebuild fell back to the latest existing dist artifact because the local "
                "sandbox blocked temporary wheel writes.\n\n"
                + build_detail
            )
        results.append(
            ShakedownResult(
                step="build_wheel",
                passed=build_passed,
                detail=build_detail,
            )
        )
        if not build_passed:
            return results

        wheel_files = built_wheels or available_wheels
        if not wheel_files:
            results.append(
                ShakedownResult(
                    step="locate_wheel",
                    passed=False,
                    detail="No wheel artifact was produced by the build step.",
                )
            )
            return results
        installable_wheel = temp_dir / wheel_files[-1].name
        shutil.copyfile(wheel_files[-1], installable_wheel)

        venv.EnvBuilder(with_pip=False, system_site_packages=True).create(venv_dir)
        venv_python = _venv_python(venv_dir)
        install_result = _run_command(
            [
                str(venv_python),
                "-m",
                "pip",
                "install",
                "--no-cache-dir",
                "--no-deps",
                "--force-reinstall",
                str(installable_wheel),
            ],
            env=shakedown_env,
        )
        results.append(
            ShakedownResult(
                step="install_wheel",
                passed=install_result.returncode == 0,
                detail=(install_result.stdout + install_result.stderr).strip(),
            )
        )
        if install_result.returncode != 0:
            return results

        architecture_dir = _write_consumer_fixture(consumer_root)
        command_env = _build_venv_command_env(venv_dir, shakedown_env)

        api_smoke = _run_command(
            [
                str(venv_python),
                "-c",
                (
                    "from architecture_metamodel.api import validate_architecture_with_report; "
                    "from pathlib import Path; "
                    f"report = validate_architecture_with_report(Path(r'{architecture_dir}')); "
                    "print(report.overall_status); "
                    "raise SystemExit(0 if report.passed else 1)"
                ),
            ]
            ,
            env=command_env,
        )
        results.append(
            ShakedownResult(
                step="api_smoke",
                passed=api_smoke.returncode == 0 and "PASS" in api_smoke.stdout,
                detail=(api_smoke.stdout + api_smoke.stderr).strip(),
            )
        )

        cli_path = _console_script(venv_dir, "architecture-validate")
        cli_smoke = _run_command([str(cli_path), str(architecture_dir)], env=command_env)
        results.append(
            ShakedownResult(
                step="cli_smoke",
                passed=cli_smoke.returncode == 0 and "Overall: PASS" in cli_smoke.stdout,
                detail=(cli_smoke.stdout + cli_smoke.stderr).strip(),
            )
        )
        results.append(
            _run_action_consumer_smoke(
                venv_dir=venv_dir,
                architecture_dir=architecture_dir,
                base_env=shakedown_env,
            )
        )

    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

    return results


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run release-oriented build/install/API/CLI smoke checks."
    )
    parser.parse_args()

    results = run_release_shakedown()
    for result in results:
        status = "PASS" if result.passed else "FAIL"
        print(f"{status}: {result.step}")
        if result.detail:
            print(result.detail)
            print()

    return 0 if results and all(result.passed for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
