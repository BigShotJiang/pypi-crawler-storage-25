"""Run categorized system tests and generate a markdown release-readiness report."""

from __future__ import annotations

import argparse
import io
import json
import sys
import traceback
import unittest
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_CATEGORIES = (
    ("unit", REPO_ROOT / "tests" / "unit"),
    ("integration", REPO_ROOT / "tests" / "integration"),
    ("api_contract", REPO_ROOT / "tests" / "api_contract"),
    ("architecture_boundaries", REPO_ROOT / "tests" / "architecture_boundaries"),
    ("surface_consistency", REPO_ROOT / "tests" / "surface_consistency"),
)
CATEGORY_LABELS = {
    "unit": "Unit Tests",
    "integration": "Integration Tests",
    "api_contract": "API Tests",
    "architecture_boundaries": "Architectural Boundary Tests",
    "surface_consistency": "Surface Consistency Tests",
}


@dataclass(frozen=True)
class RecordedTestResult:
    test_id: str
    status: str
    detail: str = ""

    def to_dict(self) -> dict[str, str]:
        return {
            "test_id": self.test_id,
            "status": self.status,
            "detail": self.detail,
        }


class RecordingTextTestResult(unittest.TextTestResult):
    """`unittest` result that keeps structured per-test outcomes for reporting."""

    def __init__(self, stream, descriptions, verbosity) -> None:
        super().__init__(stream, descriptions, verbosity)
        self.recorded: list[RecordedTestResult] = []

    def addSuccess(self, test) -> None:  # noqa: N802
        super().addSuccess(test)
        self.recorded.append(RecordedTestResult(test.id(), "passed"))

    def addFailure(self, test, err) -> None:  # noqa: N802
        super().addFailure(test, err)
        self.recorded.append(
            RecordedTestResult(test.id(), "failed", self._exc_info_to_string(err, test))
        )

    def addError(self, test, err) -> None:  # noqa: N802
        super().addError(test, err)
        self.recorded.append(
            RecordedTestResult(test.id(), "error", self._exc_info_to_string(err, test))
        )

    def addSkip(self, test, reason) -> None:  # noqa: N802
        super().addSkip(test, reason)
        self.recorded.append(RecordedTestResult(test.id(), "skipped", reason))


def _category_path(category: str) -> Path:
    for category_name, category_path in DEFAULT_CATEGORIES:
        if category_name == category:
            return category_path
    raise KeyError(f"Unknown test category: {category}")


def run_category(category: str) -> dict[str, object]:
    start_dir = _category_path(category)
    stream = io.StringIO()
    loader = unittest.defaultTestLoader
    suite = loader.discover(str(start_dir), top_level_dir=str(REPO_ROOT))
    runner = unittest.TextTestRunner(
        stream=stream,
        verbosity=2,
        resultclass=RecordingTextTestResult,
    )
    result: RecordingTextTestResult = runner.run(suite)
    recorded = [entry.to_dict() for entry in sorted(result.recorded, key=lambda item: item.test_id)]
    return {
        "category": category,
        "label": CATEGORY_LABELS[category],
        "status": "passed" if result.wasSuccessful() else "failed",
        "total": result.testsRun,
        "passed": sum(1 for entry in result.recorded if entry.status == "passed"),
        "failed": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "results": recorded,
        "runner_output": stream.getvalue().strip(),
    }


def render_markdown_report(summaries: list[dict[str, object]]) -> str:
    timestamp = datetime.now().isoformat(timespec="seconds")
    total_tests = sum(int(summary["total"]) for summary in summaries)
    total_passed = sum(int(summary["passed"]) for summary in summaries)
    total_failed = sum(int(summary["failed"]) + int(summary["errors"]) for summary in summaries)

    lines = [
        "# System Test Report",
        "",
        f"- Generated: `{timestamp}`",
        f"- Categories: `{len(summaries)}`",
        f"- Total tests: `{total_tests}`",
        f"- Passed: `{total_passed}/{total_tests}`",
        f"- Failed: `{total_failed}/{total_tests}`",
        "",
        "## Category Summary",
        "",
    ]

    for summary in summaries:
        failed_count = int(summary["failed"]) + int(summary["errors"])
        lines.append(
            "- "
            f"{summary['label']}: {summary['passed']}/{summary['total']} passed, "
            f"{failed_count}/{summary['total']} failed, "
            f"{summary['skipped']}/{summary['total']} skipped"
        )

    for summary in summaries:
        lines.extend(
            [
                "",
                f"## {summary['label']}",
                "",
                f"- Status: `{summary['status'].upper()}`",
                f"- Totals: `{summary['passed']}/{summary['total']} passed`, "
                f"`{int(summary['failed']) + int(summary['errors'])}/{summary['total']} failed`, "
                f"`{summary['skipped']}/{summary['total']} skipped`",
                "",
                "### Test Results",
                "",
            ]
        )
        for result in summary["results"]:
            lines.append(f"- `{result['status']}` {result['test_id']}")

        failures = [
            result for result in summary["results"] if result["status"] in {"failed", "error"}
        ]
        lines.extend(["", "### Failure Details", ""])
        if failures:
            for failure in failures:
                lines.append(f"- `{failure['test_id']}`")
                lines.append("")
                lines.append("```text")
                lines.append(failure["detail"].rstrip())
                lines.append("```")
        else:
            lines.append("- None")

    return "\n".join(lines) + "\n"


def write_markdown_report(summaries: list[dict[str, object]], output_dir: Path | None = None) -> Path:
    target_dir = output_dir or (REPO_ROOT / "test_reports")
    target_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = target_dir / f"{timestamp}_system-test.md"
    report_path.write_text(render_markdown_report(summaries), encoding="utf-8")
    return report_path


def write_json_summary(summary: dict[str, object], target_path: Path) -> None:
    target_path.parent.mkdir(parents=True, exist_ok=True)
    target_path.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")


def load_json_summaries(paths: list[Path]) -> list[dict[str, object]]:
    summaries = [json.loads(path.read_text(encoding="utf-8")) for path in paths]
    return sorted(summaries, key=lambda summary: list(CATEGORY_LABELS).index(summary["category"]))


def _run_category_command(args: argparse.Namespace) -> int:
    summary = run_category(args.category)
    if args.json_output:
        write_json_summary(summary, Path(args.json_output))
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if summary["status"] == "passed" else 1


def _aggregate_command(args: argparse.Namespace) -> int:
    input_paths = [Path(path) for path in args.json_inputs]
    summaries = load_json_summaries(input_paths)
    report_path = write_markdown_report(summaries, Path(args.output_dir) if args.output_dir else None)
    print(report_path)
    return 0


def _run_all_command(args: argparse.Namespace) -> int:
    summaries: list[dict[str, object]] = []
    exit_code = 0
    for category, _ in DEFAULT_CATEGORIES:
        summary = run_category(category)
        summaries.append(summary)
        if args.json_dir:
            write_json_summary(summary, Path(args.json_dir) / f"{category}.json")
        if summary["status"] != "passed":
            exit_code = 1
    report_path = write_markdown_report(summaries, Path(args.output_dir) if args.output_dir else None)
    print(report_path)
    return exit_code


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Run categorized system tests and generate markdown reports."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    category_parser = subparsers.add_parser("category", help="Run a single test category.")
    category_parser.add_argument("--category", choices=[category for category, _ in DEFAULT_CATEGORIES], required=True)
    category_parser.add_argument("--json-output", help="Path to write the category JSON summary.")
    category_parser.set_defaults(handler=_run_category_command)

    aggregate_parser = subparsers.add_parser("aggregate", help="Aggregate category JSON summaries into markdown.")
    aggregate_parser.add_argument("--json-inputs", nargs="+", required=True, help="JSON summary files to aggregate.")
    aggregate_parser.add_argument("--output-dir", help="Directory for the markdown report artifact.")
    aggregate_parser.set_defaults(handler=_aggregate_command)

    run_all_parser = subparsers.add_parser("run-all", help="Run all categories and generate one markdown report.")
    run_all_parser.add_argument("--json-dir", help="Optional directory to write per-category JSON summaries.")
    run_all_parser.add_argument("--output-dir", help="Directory for the markdown report artifact.")
    run_all_parser.set_defaults(handler=_run_all_command)

    args = parser.parse_args(argv)
    try:
        return args.handler(args)
    except Exception:  # pragma: no cover - defensive CLI wrapper
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
