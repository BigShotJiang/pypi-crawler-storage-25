"""Tooling entrypoints built on the canonical package API."""
