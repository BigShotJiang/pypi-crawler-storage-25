"""Shared presentation helpers for CLI and GitHub Action validation surfaces."""

from __future__ import annotations

import json

from architecture_metamodel.exceptions import ArchitectureLoadError
from architecture_metamodel.reporting import ValidationReport


SUCCESS_EXIT_CODE = 0
VALIDATION_FAILURE_EXIT_CODE = 1
LOAD_FAILURE_EXIT_CODE = 2
UNEXPECTED_FAILURE_EXIT_CODE = 3


def build_load_error_payload(error: ArchitectureLoadError) -> dict[str, object]:
    return {
        "status": "LOAD_ERROR",
        "passed": False,
        "failed": True,
        "error": error.to_dict(),
    }


def render_validation_report(report: ValidationReport, output_format: str) -> str:
    if output_format == "json":
        return report.to_json()
    if output_format == "text":
        return "\n".join(report.to_lines())
    raise ValueError(f"Unsupported output format: {output_format}")


def render_load_error(error: ArchitectureLoadError, output_format: str) -> str:
    if output_format == "json":
        return json.dumps(build_load_error_payload(error), indent=2, sort_keys=True)
    if output_format == "text":
        return "\n".join(
            [
                "Overall: LOAD_ERROR",
                f"Code: {error.error_code}",
                f"Path: {error.path}",
                f"Message: {error.detail}",
            ]
        )
    raise ValueError(f"Unsupported output format: {output_format}")


def validation_exit_code(report: ValidationReport) -> int:
    return SUCCESS_EXIT_CODE if report.passed else VALIDATION_FAILURE_EXIT_CODE
