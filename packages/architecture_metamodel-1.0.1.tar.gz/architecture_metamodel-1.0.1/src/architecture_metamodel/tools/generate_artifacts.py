"""CLI entrypoint for deterministic derived-artifact generation."""

from __future__ import annotations

import argparse
import sys

from architecture_metamodel.generation import check_generated_artifacts, write_generated_artifacts


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Generate or check derived metamodel artifacts."
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Fail if generated artifacts are stale instead of writing them.",
    )
    args = parser.parse_args()

    if args.check:
        stale = check_generated_artifacts()
        if stale:
            print("Generated artifacts are stale:")
            for path in stale:
                print(f"- {path}")
            print("Run `architecture-generate` to refresh them.")
            return 1
        print("Generated artifacts are current.")
        return 0

    written = write_generated_artifacts()
    if written:
        print("Generated artifacts updated:")
        for path in written:
            print(f"- {path}")
    else:
        print("Generated artifacts already current.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
