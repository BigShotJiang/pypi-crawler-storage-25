"""Validation runner for architecture YAML instances."""

from __future__ import annotations

import argparse
import sys

from architecture_metamodel.api import ArchitectureLoadError, validate_architecture_with_report
from architecture_metamodel.tools.validation_surface import (
    LOAD_FAILURE_EXIT_CODE,
    UNEXPECTED_FAILURE_EXIT_CODE,
    render_load_error,
    render_validation_report,
    validation_exit_code,
)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Validate architecture YAML files against the architecture metamodel."
    )
    parser.add_argument(
        "path",
        help="Path to a YAML file or a directory containing YAML architecture elements.",
    )
    parser.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="Output format for validation results.",
    )
    args = parser.parse_args(argv)

    try:
        report = validate_architecture_with_report(args.path)
    except ArchitectureLoadError as exc:
        print(render_load_error(exc, args.format))
        return LOAD_FAILURE_EXIT_CODE
    except Exception as exc:  # pragma: no cover - defensive adapter fallback
        print(f"Overall: INTERNAL_ERROR\nMessage: {exc}")
        return UNEXPECTED_FAILURE_EXIT_CODE

    print(render_validation_report(report, args.format))
    return validation_exit_code(report)


if __name__ == "__main__":
    sys.exit(main())
