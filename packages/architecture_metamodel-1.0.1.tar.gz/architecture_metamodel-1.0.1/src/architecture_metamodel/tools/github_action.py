"""GitHub Action wrapper over the canonical public validation API."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from architecture_metamodel.api import ArchitectureLoadError, validate_architecture_with_report
from architecture_metamodel.tools.validation_surface import (
    LOAD_FAILURE_EXIT_CODE,
    UNEXPECTED_FAILURE_EXIT_CODE,
    build_load_error_payload,
    render_load_error,
    render_validation_report,
    validation_exit_code,
)


def _write_github_output(name: str, value: str, output_path: Path) -> None:
    with output_path.open("a", encoding="utf-8") as handle:
        if "\n" in value:
            handle.write(f"{name}<<__ARCHITECTURE_METAMODEL__\n{value}\n__ARCHITECTURE_METAMODEL__\n")
        else:
            handle.write(f"{name}={value}\n")


def _publish_report_outputs(output_path: Path, rendered_output: str, report) -> None:
    payload = report.to_json()
    _write_github_output("status", report.overall_status, output_path)
    _write_github_output("passed", str(report.passed).lower(), output_path)
    _write_github_output("failed", str(report.failed).lower(), output_path)
    _write_github_output("error_count", str(report.error_count), output_path)
    _write_github_output("warning_count", str(report.warning_count), output_path)
    _write_github_output("source_path", report.source_path or "", output_path)
    _write_github_output("result_json", payload, output_path)
    _write_github_output("rendered_output", rendered_output, output_path)


def _publish_load_error_outputs(output_path: Path, rendered_output: str, error: ArchitectureLoadError) -> None:
    payload = build_load_error_payload(error)
    payload_json = render_load_error(error, "json")
    _write_github_output("status", "LOAD_ERROR", output_path)
    _write_github_output("passed", "false", output_path)
    _write_github_output("failed", "true", output_path)
    _write_github_output("error_count", "0", output_path)
    _write_github_output("warning_count", "0", output_path)
    _write_github_output("source_path", payload["error"]["path"], output_path)
    _write_github_output("error_code", payload["error"]["code"], output_path)
    _write_github_output("error_message", payload["error"]["message"], output_path)
    _write_github_output("result_json", payload_json, output_path)
    _write_github_output("rendered_output", rendered_output, output_path)


def _write_step_summary(content: str) -> None:
    summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    if not summary_path:
        return
    Path(summary_path).write_text(f"```text\n{content}\n```\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Validate an architecture from a reusable GitHub Action wrapper."
    )
    parser.add_argument("--path", required=True, help="Path to a YAML file or directory to validate.")
    parser.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help="Output format to print to stdout.",
    )
    args = parser.parse_args(argv)

    output_path_value = os.environ.get("GITHUB_OUTPUT")
    output_path = Path(output_path_value) if output_path_value else None

    try:
        report = validate_architecture_with_report(args.path)
    except ArchitectureLoadError as exc:
        rendered_output = render_load_error(exc, args.format)
        print(rendered_output)
        _write_step_summary(rendered_output)
        if output_path:
            _publish_load_error_outputs(output_path, rendered_output, exc)
        return LOAD_FAILURE_EXIT_CODE
    except Exception as exc:  # pragma: no cover - defensive adapter fallback
        rendered_output = f"Overall: INTERNAL_ERROR\nMessage: {exc}"
        print(rendered_output)
        _write_step_summary(rendered_output)
        return UNEXPECTED_FAILURE_EXIT_CODE

    rendered_output = render_validation_report(report, args.format)
    print(rendered_output)
    _write_step_summary(rendered_output)
    if output_path:
        _publish_report_outputs(output_path, rendered_output, report)
    return validation_exit_code(report)


if __name__ == "__main__":
    sys.exit(main())
