"""YAML loading helpers for architecture graphs."""

from __future__ import annotations

from pathlib import Path
from typing import Union

import yaml

from architecture_metamodel.aliases import ArchitectureElement
from architecture_metamodel.exceptions import (
    ArchitectureParseError,
    ArchitecturePathNotFoundError,
    ArchitecturePathTypeError,
    EmptyArchitectureError,
    NoArchitectureInputsError,
)
from architecture_metamodel.parsing.element_parser import parse_element


def _coerce_raw_items(data: object, source: Path) -> list[dict]:
    if isinstance(data, dict) and "elements" in data:
        raw_items = data["elements"]
    elif isinstance(data, list):
        raw_items = data
    elif isinstance(data, dict):
        raw_items = [data]
    else:
        raise ArchitectureParseError(source, "Unsupported YAML structure.")

    return list(raw_items)


def _ensure_supported_path(target: Union[str, Path]) -> Path:
    path = Path(target)
    if not path.exists():
        raise ArchitecturePathNotFoundError(path, "Architecture path does not exist.")
    if path.is_file():
        if path.suffix.lower() not in {".yaml", ".yml"}:
            raise ArchitecturePathTypeError(path, "Architecture file must be a YAML file.")
        return path
    if path.is_dir():
        return path
    raise ArchitecturePathTypeError(path, "Architecture path must be a YAML file or directory.")


def _load_yaml_document(path: Path) -> object:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle)
    except yaml.YAMLError as exc:
        raise ArchitectureParseError(path, f"YAML parsing failed: {exc}") from exc
    except OSError as exc:
        raise ArchitectureParseError(path, f"Architecture input could not be read: {exc}") from exc


def _parse_items(raw_items: list[dict], source: Path) -> list[ArchitectureElement]:
    parsed: list[ArchitectureElement] = []
    for index, item in enumerate(raw_items, start=1):
        if not isinstance(item, dict):
            raise ArchitectureParseError(source, f"Element #{index} is not a mapping payload.")
        try:
            parsed.append(parse_element(item))
        except Exception as exc:
            raise ArchitectureParseError(
                source,
                "Element "
                f"#{index} could not be loaded because the YAML content is structurally invalid "
                "for the expected element schema/model (malformed or incomplete metadata): "
                f"{exc}",
            ) from exc
    return parsed


def load_elements_from_yaml_file(file_path: Union[str, Path]) -> list[ArchitectureElement]:
    path = _ensure_supported_path(file_path)
    if not path.is_file():
        raise ArchitecturePathTypeError(path, "Expected a YAML file path.")
    data = _load_yaml_document(path)

    if data is None:
        raise EmptyArchitectureError(path, "Architecture YAML file is empty.")

    return _parse_items(_coerce_raw_items(data, path), path)


def load_elements_from_directory(directory: Union[str, Path]) -> list[ArchitectureElement]:
    path = _ensure_supported_path(directory)
    if not path.is_dir():
        raise ArchitecturePathTypeError(path, "Expected a directory containing YAML architecture input.")
    parsed: list[ArchitectureElement] = []
    yaml_paths = sorted(list(path.rglob("*.yaml")) + list(path.rglob("*.yml")))
    if not yaml_paths:
        if not any(path.iterdir()):
            raise EmptyArchitectureError(path, "Architecture directory is empty.")
        raise NoArchitectureInputsError(path, "Architecture directory contains no YAML inputs.")
    for yaml_path in yaml_paths:
        data = _load_yaml_document(yaml_path)
        if data is None:
            continue
        parsed.extend(_parse_items(_coerce_raw_items(data, yaml_path), yaml_path))
    if not parsed:
        raise EmptyArchitectureError(path, "Architecture YAML inputs contained no elements.")
    return parsed
