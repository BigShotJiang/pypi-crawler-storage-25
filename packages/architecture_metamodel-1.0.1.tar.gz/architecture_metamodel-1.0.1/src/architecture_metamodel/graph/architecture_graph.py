"""Canonical architecture graph container and traversal helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Union

from architecture_metamodel.aliases import ArchitectureElement
from architecture_metamodel.exceptions import ArchitectureParseError
from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.reporting import ValidationReport
from architecture_metamodel.validation.engine import build_validation_report, validate_graph


class ArchitectureGraph:
    """In-memory graph of architecture elements loaded through the public API."""

    def __init__(self, elements: Iterable[ArchitectureElement]) -> None:
        self.elements: dict[str, ArchitectureElement] = {}
        self.name_index: dict[str, str] = {}

        for element in elements:
            if element.id in self.elements:
                raise ValueError(f"Duplicate element id detected: {element.id}")
            if element.name in self.name_index:
                raise ValueError(
                    f"Duplicate element name detected: '{element.name}' "
                    f"(existing id={self.name_index[element.name]}, new id={element.id})"
                )
            self.elements[element.id] = element
            self.name_index[element.name] = element.id

    @classmethod
    def from_yaml_file(cls, file_path: Union[str, Path]) -> "ArchitectureGraph":
        from architecture_metamodel.graph.loading import load_elements_from_yaml_file

        try:
            return cls(load_elements_from_yaml_file(file_path))
        except ValueError as exc:
            raise ArchitectureParseError(Path(file_path), str(exc)) from exc

    @classmethod
    def from_directory(cls, directory: Union[str, Path]) -> "ArchitectureGraph":
        from architecture_metamodel.graph.loading import load_elements_from_directory

        try:
            return cls(load_elements_from_directory(directory))
        except ValueError as exc:
            raise ArchitectureParseError(Path(directory), str(exc)) from exc

    def iter_relationship_edges(self) -> Iterable[tuple[str, str, str]]:
        for source_id, element in self.elements.items():
            relationship_data = element.relationships.model_dump()
            for relationship_name, targets in relationship_data.items():
                for target_id in targets:
                    yield source_id, relationship_name, target_id

    def validate(self) -> list[ValidationIssue]:
        """Run validation and return the aggregated raw issue list."""

        return validate_graph(self)

    def validation_report(self, *, source_path: str | None = None) -> ValidationReport:
        """Run validation and return a structured report grouped by check family."""

        return build_validation_report(self, source_path=source_path)
