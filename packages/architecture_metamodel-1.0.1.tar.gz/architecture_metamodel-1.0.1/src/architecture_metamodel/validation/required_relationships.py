"""Validation for required relationships that are presently empty."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.rules import REQUIRED_RELATIONSHIPS

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_required_relationships(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        required = REQUIRED_RELATIONSHIPS[element.type]
        relationship_data = element.relationships.model_dump()
        for relation_name in required:
            if not relationship_data.get(relation_name, []):
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        element_id=element.id,
                        message=f"Required relationship '{relation_name}' is empty for type '{element.type.value}'.",
                    )
                )
    return issues
