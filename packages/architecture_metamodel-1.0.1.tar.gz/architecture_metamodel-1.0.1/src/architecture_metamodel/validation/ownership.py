"""Validation for ownership and realization semantics."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import ElementType, IssueSeverity
from architecture_metamodel.issues import ValidationIssue

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_single_logical_owner_for_functions(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        if element.type != ElementType.FCN:
            continue

        owners = [
            target_id
            for target_id in element.relationships.performed_by
            if target_id in graph.elements and graph.elements[target_id].type == ElementType.LSYS
        ]

        if len(owners) != 1:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=element.id,
                    message="Function must be allocated to exactly one logical system.",
                )
            )
    return issues


def validate_single_realization_for_swa(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        if element.type != ElementType.SWA:
            continue

        upward_targets = [
            target_id
            for target_id in element.relationships.realizes
            if target_id in graph.elements
            and graph.elements[target_id].type in {ElementType.LSYS, ElementType.INT}
        ]

        if len(upward_targets) != 1:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=element.id,
                    message="Software assembly must realize exactly one logical system or interface.",
                )
            )
    return issues


def validate_single_sw_owner_for_swf(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        if element.type != ElementType.SWF:
            continue

        owners = [
            target_id
            for target_id in element.relationships.performed_by
            if target_id in graph.elements and graph.elements[target_id].type == ElementType.SW
        ]

        if len(owners) != 1:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=element.id,
                    message="Software function must be performed by exactly one software element.",
                )
            )
    return issues


def validate_single_parent_function_for_swf(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        if element.type != ElementType.SWF:
            continue

        parents = [
            target_id
            for target_id in element.relationships.part_of
            if target_id in graph.elements and graph.elements[target_id].type == ElementType.FCN
        ]

        if len(parents) != 1:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=element.id,
                    message="Software function must decompose exactly one architecture function.",
                )
            )
    return issues
