"""Validation for cybersecurity metadata completeness."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_cybersecurity_metadata(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        cyber = element.cybersecurity
        if cyber is None:
            continue

        if cyber.is_security_relevant:
            lacks_signal = (
                len(cyber.security_markings) == 0
                and len(cyber.controls) == 0
                and len(cyber.notes) == 0
                and cyber.trust_boundary_type is None
                and cyber.data_classification is None
                and cyber.secrets_handling is None
                and cyber.hardening_level is None
                and cyber.security_review_required is None
                and cyber.threat_model_required is None
                and cyber.security_test_required is None
            )
            if lacks_signal:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        element_id=element.id,
                        message=(
                            "Cybersecurity block is marked security-relevant but lacks "
                            "security markings, controls, trust-boundary typing, or hardening intent."
                        ),
                    )
                )
    return issues
