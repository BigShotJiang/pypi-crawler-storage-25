"""Validation for allowed target types by relationship."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.rules import ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_target_types(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for source_id, relationship_name, target_id in graph.iter_relationship_edges():
        source = graph.elements[source_id]
        target = graph.elements.get(target_id)
        if target is None:
            continue
        relationship_map = ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION[source.type]
        if relationship_name not in relationship_map:
            continue
        allowed_target_types = relationship_map[relationship_name]
        if target.type not in allowed_target_types:
            allowed = [t.value for t in sorted(allowed_target_types, key=lambda value: value.value)]
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=source_id,
                    message=(
                        f"Relationship '{relationship_name}' cannot target '{target_id}' "
                        f"of type '{target.type.value}' from source type '{source.type.value}'. "
                        f"Allowed target types: {allowed}"
                    ),
                )
            )
    return issues
