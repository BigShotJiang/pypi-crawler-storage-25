"""Validation for recommended metadata population."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.rules import RECOMMENDED_METADATA_FIELDS

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_recommended_metadata(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        for field_name in RECOMMENDED_METADATA_FIELDS[element.type]:
            value = getattr(element, field_name, None)
            is_missing = value is None
            is_empty_list = isinstance(value, list) and len(value) == 0
            is_empty_dict = isinstance(value, dict) and len(value) == 0
            is_empty_string = isinstance(value, str) and not value.strip()
            if is_missing or is_empty_list or is_empty_dict or is_empty_string:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.WARNING,
                        element_id=element.id,
                        message=f"Recommended metadata field '{field_name}' is not populated.",
                    )
                )
    return issues
