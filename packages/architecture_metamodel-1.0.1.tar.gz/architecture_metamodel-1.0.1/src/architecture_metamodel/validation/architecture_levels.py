"""Validation for architecture-level parent-child consistency."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def _level_to_int(level) -> int:
    return int(level.value.removeprefix("Level"))


def validate_architecture_levels(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    for element in graph.elements.values():
        if not hasattr(element, "architecture_level"):
            continue

        current_level = getattr(element, "architecture_level")
        current_level_num = _level_to_int(current_level)

        parent_ids = element.relationships.part_of
        same_type_parents = [
            graph.elements[parent_id]
            for parent_id in parent_ids
            if parent_id in graph.elements and graph.elements[parent_id].type == element.type
        ]

        if current_level_num == 1:
            if same_type_parents:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        element_id=element.id,
                        message="Level1 element must not have a same-type parent.",
                    )
                )
            continue

        if len(same_type_parents) != 1:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=element.id,
                    message=(
                        "Element with architecture_level must have exactly one "
                        "same-type parent in 'part_of'."
                    ),
                )
            )
            continue

        parent = same_type_parents[0]
        parent_level = getattr(parent, "architecture_level", None)
        if parent_level is None:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=element.id,
                    message="Same-type parent is missing architecture_level.",
                )
            )
            continue

        parent_level_num = _level_to_int(parent_level)
        if parent_level_num != current_level_num - 1:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=element.id,
                    message=(
                        f"Element level '{current_level.value}' must trace to a parent "
                        f"at exactly one level above, but parent '{parent.id}' is '{parent_level.value}'."
                    ),
                )
            )

    return issues
