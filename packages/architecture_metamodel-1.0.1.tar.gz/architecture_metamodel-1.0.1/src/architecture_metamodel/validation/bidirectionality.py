"""Validation for reciprocal relationship declarations."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.rules import INVERSE_RELATIONSHIPS

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_bidirectionality(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for source_id, relationship_name, target_id in graph.iter_relationship_edges():
        inverse_name = INVERSE_RELATIONSHIPS[relationship_name]
        target = graph.elements.get(target_id)
        if target is None:
            continue
        inverse_targets = getattr(target.relationships, inverse_name)
        if source_id not in inverse_targets:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=source_id,
                    message=(
                        f"Relationship '{relationship_name}' -> '{target_id}' is missing "
                        f"reciprocal '{inverse_name}' back to '{source_id}'."
                    ),
                )
            )
    return issues
