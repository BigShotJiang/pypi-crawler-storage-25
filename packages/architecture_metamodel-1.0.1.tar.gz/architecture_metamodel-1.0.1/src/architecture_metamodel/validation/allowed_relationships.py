"""Validation for allowed relationship names by source element type."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.rules import ALLOWED_RELATIONSHIPS

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_allowed_relationships(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for element in graph.elements.values():
        allowed = ALLOWED_RELATIONSHIPS[element.type]
        relationship_data = element.relationships.model_dump()
        for relation_name, targets in relationship_data.items():
            if targets and relation_name not in allowed:
                issues.append(
                    ValidationIssue(
                        severity=IssueSeverity.ERROR,
                        element_id=element.id,
                        message=f"Relationship '{relation_name}' is not allowed for type '{element.type.value}'.",
                    )
                )
    return issues
