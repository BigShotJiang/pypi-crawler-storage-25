"""Validation orchestration for architecture graphs."""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable

from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.reporting import ValidationCheckResult, ValidationReport
from architecture_metamodel.validation.allowed_relationships import validate_allowed_relationships
from architecture_metamodel.validation.architecture_levels import validate_architecture_levels
from architecture_metamodel.validation.bidirectionality import validate_bidirectionality
from architecture_metamodel.validation.cybersecurity import validate_cybersecurity_metadata
from architecture_metamodel.validation.metadata_completeness import validate_recommended_metadata
from architecture_metamodel.validation.ownership import (
    validate_single_logical_owner_for_functions,
    validate_single_parent_function_for_swf,
    validate_single_realization_for_swa,
    validate_single_sw_owner_for_swf,
)
from architecture_metamodel.validation.references import validate_references_exist
from architecture_metamodel.validation.required_relationships import validate_required_relationships
from architecture_metamodel.validation.target_types import validate_target_types

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


ValidationCallable = Callable[["ArchitectureGraph"], list[ValidationIssue]]

VALIDATION_CHECKS: tuple[tuple[str, str, ValidationCallable], ...] = (
    ("allowed_relationships", "Allowed relationships", validate_allowed_relationships),
    ("required_relationships", "Required relationships", validate_required_relationships),
    ("recommended_metadata", "Recommended metadata", validate_recommended_metadata),
    ("references_exist", "Reference existence", validate_references_exist),
    ("target_types", "Relationship target types", validate_target_types),
    ("bidirectionality", "Bidirectional relationships", validate_bidirectionality),
    ("cybersecurity_metadata", "Cybersecurity metadata", validate_cybersecurity_metadata),
    ("architecture_levels", "Architecture levels", validate_architecture_levels),
    (
        "single_logical_owner_for_functions",
        "Single logical owner for functions",
        validate_single_logical_owner_for_functions,
    ),
    ("single_realization_for_swa", "Single realization for SWA", validate_single_realization_for_swa),
    ("single_sw_owner_for_swf", "Single software owner for SWF", validate_single_sw_owner_for_swf),
    ("single_parent_function_for_swf", "Single parent function for SWF", validate_single_parent_function_for_swf),
)


def build_validation_report(
    graph: "ArchitectureGraph",
    *,
    source_path: str | None = None,
) -> ValidationReport:
    """Run every validation check and return a structured per-check report."""

    checks: list[ValidationCheckResult] = []
    for check_id, check_name, validator in VALIDATION_CHECKS:
        issues = tuple(validator(graph))
        checks.append(ValidationCheckResult(check_id=check_id, check_name=check_name, issues=issues))
    return ValidationReport(
        checks=tuple(checks),
        source_path=source_path,
        element_count=len(graph.elements),
    )


def validate_graph(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    """Run every validation check and return the flattened issue list."""

    return build_validation_report(graph).issues
