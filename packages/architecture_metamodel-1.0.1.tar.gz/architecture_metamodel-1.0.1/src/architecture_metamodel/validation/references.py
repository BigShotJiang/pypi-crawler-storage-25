"""Validation for relationship target existence."""

from __future__ import annotations

from typing import TYPE_CHECKING

from architecture_metamodel.enums import IssueSeverity
from architecture_metamodel.issues import ValidationIssue

if TYPE_CHECKING:
    from architecture_metamodel.graph.architecture_graph import ArchitectureGraph


def validate_references_exist(graph: "ArchitectureGraph") -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    for source_id, relationship_name, target_id in graph.iter_relationship_edges():
        if target_id not in graph.elements:
            issues.append(
                ValidationIssue(
                    severity=IssueSeverity.ERROR,
                    element_id=source_id,
                    message=f"Relationship '{relationship_name}' references unknown target id '{target_id}'.",
                )
            )
    return issues
