"""Allowed relationship target policy by source element type."""

from __future__ import annotations

from architecture_metamodel.enums import ElementType


ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION: dict[ElementType, dict[str, set[ElementType]]] = {
    ElementType.OA: {
        "implemented_by": {ElementType.FCN},
        "performed_by": {ElementType.ACT},
    },
    ElementType.FCN: {
        "implements": {ElementType.OA},
        "is_composed_of": {ElementType.FCN, ElementType.SWF},
        "part_of": {ElementType.FCN},
        "aggregates": {ElementType.GSWF},
        "performed_by": {ElementType.LSYS},
        "invokes": {ElementType.INT},
        "verified_by": {ElementType.TC},
    },
    ElementType.INT: {
        "exposed_by": {ElementType.LSYS},
        "consumed_by": {ElementType.LSYS},
        "traversed_by": {ElementType.DOBJ},
        "invoked_by": {ElementType.FCN},
        "realized_by": {ElementType.SWA},
        "verified_by": {ElementType.TC},
        "interacted_through_by": {ElementType.ACT},
    },
    ElementType.DOBJ: {
        "traverses": {ElementType.INT},
        "stored_by": {ElementType.LSYS},
    },
    ElementType.LSYS: {
        "performs": {ElementType.FCN},
        "is_composed_of": {ElementType.LSYS},
        "part_of": {ElementType.LSYS},
        "exposes": {ElementType.INT},
        "consumes": {ElementType.INT},
        "stores": {ElementType.DOBJ},
        "verified_by": {ElementType.TC},
        "realized_by": {ElementType.PSYS, ElementType.SWA},
    },
    ElementType.ACT: {
        "performs": {ElementType.OA},
        "interacts_through": {ElementType.INT},
    },
    ElementType.PSYS: {
        "realizes": {ElementType.LSYS},
    },
    ElementType.TC: {
        "verifies": {
            ElementType.FCN,
            ElementType.LSYS,
            ElementType.INT,
            ElementType.SWA,
            ElementType.SWF,
            ElementType.GSWF,
            ElementType.SW,
        },
    },
    ElementType.SWA: {
        "realizes": {ElementType.LSYS, ElementType.INT},
        "is_composed_of": {ElementType.SW},
        "verified_by": {ElementType.TC},
    },
    ElementType.SW: {
        "part_of": {ElementType.SWA},
        "performs": {ElementType.SWF, ElementType.GSWF},
        "verified_by": {ElementType.TC},
    },
    ElementType.SWF: {
        "part_of": {ElementType.FCN},
        "performed_by": {ElementType.SW},
        "invokes": {ElementType.SWF},
        "invoked_by": {ElementType.SWF},
        "verified_by": {ElementType.TC},
    },
    ElementType.GSWF: {
        "aggregated_by": {ElementType.FCN},
        "performed_by": {ElementType.SW},
        "verified_by": {ElementType.TC},
    },
    ElementType.HW: {
        "verified_by": {ElementType.TC},
    },
}
