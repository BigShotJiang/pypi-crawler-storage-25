"""Allowed relationship names derived from target-type policy."""

from __future__ import annotations

from architecture_metamodel.enums import ElementType
from architecture_metamodel.rules.target_types import ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION


ALLOWED_RELATIONSHIPS: dict[ElementType, set[str]] = {
    element_type: set(relationship_map.keys())
    for element_type, relationship_map in ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION.items()
}
