"""Inverse relationship declarations for the metamodel."""

from __future__ import annotations


INVERSE_RELATIONSHIPS: dict[str, str] = {
    "implements": "implemented_by",
    "implemented_by": "implements",
    "aggregates": "aggregated_by",
    "aggregated_by": "aggregates",
    "is_composed_of": "part_of",
    "part_of": "is_composed_of",
    "performs": "performed_by",
    "performed_by": "performs",
    "exposes": "exposed_by",
    "exposed_by": "exposes",
    "consumes": "consumed_by",
    "consumed_by": "consumes",
    "traverses": "traversed_by",
    "traversed_by": "traverses",
    "invokes": "invoked_by",
    "invoked_by": "invokes",
    "realizes": "realized_by",
    "realized_by": "realizes",
    "stores": "stored_by",
    "stored_by": "stores",
    "verifies": "verified_by",
    "verified_by": "verifies",
    "interacts_through": "interacted_through_by",
    "interacted_through_by": "interacts_through",
}
