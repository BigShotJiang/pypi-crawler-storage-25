"""Required relationship policy by element type."""

from __future__ import annotations

from architecture_metamodel.enums import ElementType


REQUIRED_RELATIONSHIPS: dict[ElementType, set[str]] = {
    ElementType.OA: {"implemented_by", "performed_by"},
    ElementType.FCN: {"implements", "performed_by"},
    ElementType.INT: {"exposed_by"},
    ElementType.DOBJ: {"traverses"},
    ElementType.LSYS: {"performs"},
    ElementType.ACT: set(),
    ElementType.PSYS: {"realizes"},
    ElementType.TC: {"verifies"},
    ElementType.SWA: {"realizes", "is_composed_of"},
    ElementType.SW: {"part_of", "performs"},
    ElementType.SWF: {"part_of", "performed_by"},
    ElementType.GSWF: {"aggregated_by", "performed_by"},
    ElementType.HW: set(),
}
