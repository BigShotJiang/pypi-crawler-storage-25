"""Recommended metadata policy by element type."""

from __future__ import annotations

from architecture_metamodel.enums import ElementType


RECOMMENDED_METADATA_FIELDS: dict[ElementType, set[str]] = {
    ElementType.OA: {"release", "status", "design_constraints", "cybersecurity"},
    ElementType.FCN: {"release", "status", "design_constraints", "budgeted_activity", "verification_ref", "cybersecurity"},
    ElementType.INT: {"release", "status", "design_constraints", "cybersecurity"},
    ElementType.DOBJ: {"release", "status", "design_constraints", "budgeted_size", "multiplicity", "cybersecurity"},
    ElementType.LSYS: {"release", "status", "design_constraints", "budgeted_compute", "budgeted_storage", "cybersecurity"},
    ElementType.ACT: {"release", "status", "design_constraints", "cybersecurity"},
    ElementType.PSYS: {
        "release",
        "status",
        "design_constraints",
        "deployment_environment",
        "actual_compute",
        "actual_storage",
        "cybersecurity",
    },
    ElementType.TC: {"release", "status", "design_constraints", "test_implementation_reference", "cybersecurity"},
    ElementType.SWA: {"release", "status", "design_constraints", "cybersecurity"},
    ElementType.SW: {"release", "status", "design_constraints", "cybersecurity", "arguments"},
    ElementType.SWF: {"release", "status", "design_constraints", "cybersecurity"},
    ElementType.GSWF: {"release", "status", "design_constraints", "cybersecurity"},
    ElementType.HW: {"release", "status", "design_constraints", "cybersecurity"},
}
