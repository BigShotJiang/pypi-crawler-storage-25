"""Declarative metamodel policy layer."""

from .allowed_relationships import ALLOWED_RELATIONSHIPS
from .inverse_relationships import INVERSE_RELATIONSHIPS
from .recommended_metadata import RECOMMENDED_METADATA_FIELDS
from .required_relationships import REQUIRED_RELATIONSHIPS
from .target_types import ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION

__all__ = [
    "ALLOWED_RELATIONSHIPS",
    "ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION",
    "INVERSE_RELATIONSHIPS",
    "RECOMMENDED_METADATA_FIELDS",
    "REQUIRED_RELATIONSHIPS",
]
