"""Parsing entrypoints for canonical metamodel payloads."""

from .element_parser import parse_element
from .registry import ELEMENT_MODEL_BY_TYPE, get_model_for_type

__all__ = [
    "ELEMENT_MODEL_BY_TYPE",
    "get_model_for_type",
    "parse_element",
]
