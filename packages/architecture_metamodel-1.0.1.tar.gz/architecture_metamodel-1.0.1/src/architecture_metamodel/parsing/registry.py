"""Canonical registry mapping element types to model classes."""

from __future__ import annotations

from architecture_metamodel.elements import (
    ActorMetadata,
    DataObjectMetadata,
    FunctionMetadata,
    GlobalSoftwareFunctionMetadata,
    HardwareMetadata,
    InterfaceMetadata,
    LogicalSystemMetadata,
    OperationalActivityMetadata,
    PhysicalSystemMetadata,
    SoftwareAssemblyMetadata,
    SoftwareFunctionMetadata,
    SoftwareMetadata,
    TestCaseMetadata,
)
from architecture_metamodel.enums import ElementType


ELEMENT_MODEL_BY_TYPE = {
    ElementType.OA: OperationalActivityMetadata,
    ElementType.FCN: FunctionMetadata,
    ElementType.INT: InterfaceMetadata,
    ElementType.DOBJ: DataObjectMetadata,
    ElementType.LSYS: LogicalSystemMetadata,
    ElementType.ACT: ActorMetadata,
    ElementType.PSYS: PhysicalSystemMetadata,
    ElementType.TC: TestCaseMetadata,
    ElementType.SWA: SoftwareAssemblyMetadata,
    ElementType.SW: SoftwareMetadata,
    ElementType.SWF: SoftwareFunctionMetadata,
    ElementType.GSWF: GlobalSoftwareFunctionMetadata,
    ElementType.HW: HardwareMetadata,
}


def get_model_for_type(element_type: ElementType):
    """Return the canonical Pydantic model class for an element type."""

    return ELEMENT_MODEL_BY_TYPE[element_type]
