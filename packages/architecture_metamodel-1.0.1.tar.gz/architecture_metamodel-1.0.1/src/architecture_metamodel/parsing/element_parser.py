"""Element parsing helpers for raw architecture payloads."""

from __future__ import annotations

from typing import Any

from architecture_metamodel.aliases import ArchitectureElement
from architecture_metamodel.enums import ElementType
from architecture_metamodel.parsing.registry import get_model_for_type


def parse_element(data: dict[str, Any]) -> ArchitectureElement:
    """Parse a raw YAML payload into the canonical element model for its type."""

    raw_type = data.get("type")
    if raw_type is None:
        raise ValueError("Element payload is missing required field 'type'.")

    resolved_type = ElementType(raw_type)
    return get_model_for_type(resolved_type).model_validate(data)
