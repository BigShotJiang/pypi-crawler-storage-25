"""Shared aliases for the canonical metamodel package."""

from __future__ import annotations

from typing import Union

from architecture_metamodel.elements import (
    ActorMetadata,
    DataObjectMetadata,
    FunctionMetadata,
    GlobalSoftwareFunctionMetadata,
    HardwareMetadata,
    InterfaceMetadata,
    LogicalSystemMetadata,
    OperationalActivityMetadata,
    PhysicalSystemMetadata,
    SoftwareAssemblyMetadata,
    SoftwareFunctionMetadata,
    SoftwareMetadata,
    TestCaseMetadata,
)


ArchitectureElement = Union[
    OperationalActivityMetadata,
    FunctionMetadata,
    InterfaceMetadata,
    DataObjectMetadata,
    LogicalSystemMetadata,
    ActorMetadata,
    PhysicalSystemMetadata,
    TestCaseMetadata,
    SoftwareAssemblyMetadata,
    SoftwareMetadata,
    SoftwareFunctionMetadata,
    GlobalSoftwareFunctionMetadata,
    HardwareMetadata,
]
