"""Canonical enum definitions for the architecture metamodel."""

from __future__ import annotations

from enum import Enum


class ElementType(str, Enum):
    OA = "OA"
    FCN = "FCN"
    INT = "INT"
    DOBJ = "DOBJ"
    LSYS = "LSYS"
    ACT = "ACT"
    PSYS = "PSYS"
    TC = "TC"
    SWA = "SWA"
    SWF = "SWF"
    GSWF = "GSWF"
    SW = "SW"
    HW = "HW"


class ArchitectureStatus(str, Enum):
    DRAFT = "DRAFT"
    BASELINED = "BASELINED"
    UPDATED = "UPDATED"
    IMPLEMENTED = "IMPLEMENTED"
    DEPRECATED = "DEPRECATED"


class ArchitectureLevel(str, Enum):
    Level1 = "Level1"
    Level2 = "Level2"
    Level3 = "Level3"
    Level4 = "Level4"


class InterfaceDirectionality(str, Enum):
    INPUT = "INPUT"
    OUTPUT = "OUTPUT"


class ActorKind(str, Enum):
    HUMAN = "HUMAN"
    MACHINE = "MACHINE"


class VerificationType(str, Enum):
    UNIT = "UNIT"
    INTEGRATION = "INTEGRATION"
    REGRESSION = "REGRESSION"
    SCENARIO = "SCENARIO"
    MANUAL = "MANUAL"


class IssueSeverity(str, Enum):
    ERROR = "ERROR"
    WARNING = "WARNING"


class SecurityMarking(str, Enum):
    ASSET = "ASSET"
    BOUNDARY = "BOUNDARY"
    INPUT = "INPUT"
    VALIDATION = "VALIDATION"
    OUTPUT = "OUTPUT"
    PERSISTENCE = "PERSISTENCE"
    DEPENDENCY = "DEPENDENCY"
    INTEGRATION = "INTEGRATION"
    SECRET = "SECRET"
    TODO = "TODO"


class TrustBoundaryType(str, Enum):
    NONE = "NONE"
    INTERNAL = "INTERNAL"
    EXTERNAL = "EXTERNAL"
    MIXED = "MIXED"


class DataClassification(str, Enum):
    PUBLIC = "PUBLIC"
    INTERNAL = "INTERNAL"
    SENSITIVE = "SENSITIVE"
    SECRET = "SECRET"


class SecretsHandling(str, Enum):
    NONE = "NONE"
    INDIRECT = "INDIRECT"
    DIRECT = "DIRECT"


class HardeningLevel(str, Enum):
    NONE = "NONE"
    BASIC = "BASIC"
    ELEVATED = "ELEVATED"
    HIGH = "HIGH"


class SecurityControl(str, Enum):
    INPUT_VALIDATION = "INPUT_VALIDATION"
    OUTPUT_FILTERING = "OUTPUT_FILTERING"
    OUTPUT_ENCODING = "OUTPUT_ENCODING"
    AUTHENTICATION = "AUTHENTICATION"
    AUTHORIZATION = "AUTHORIZATION"
    LEAST_PRIVILEGE = "LEAST_PRIVILEGE"
    ENCRYPTION_AT_REST = "ENCRYPTION_AT_REST"
    ENCRYPTION_IN_TRANSIT = "ENCRYPTION_IN_TRANSIT"
    AUDIT_LOGGING = "AUDIT_LOGGING"
    RATE_LIMITING = "RATE_LIMITING"
    DEPENDENCY_REVIEW = "DEPENDENCY_REVIEW"
    SECRET_ISOLATION = "SECRET_ISOLATION"
    INTEGRITY_PROTECTION = "INTEGRITY_PROTECTION"
