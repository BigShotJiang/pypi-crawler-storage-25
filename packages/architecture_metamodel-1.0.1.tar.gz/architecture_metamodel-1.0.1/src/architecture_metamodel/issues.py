"""Issue objects emitted by metamodel validation."""

from __future__ import annotations

from dataclasses import dataclass

from .enums import IssueSeverity


@dataclass(frozen=True)
class ValidationIssue:
    """Single validation issue emitted by the metamodel validators."""

    severity: IssueSeverity
    element_id: str
    message: str

    def __str__(self) -> str:
        return f"[{self.severity.value}] {self.element_id}: {self.message}"

    def to_dict(self) -> dict[str, str]:
        return {
            "severity": self.severity.value,
            "element_id": self.element_id,
            "message": self.message,
        }
