"""PlantUML overview generation from the authoritative Python metamodel."""

from __future__ import annotations

from pydantic import BaseModel

from architecture_metamodel.generation.introspection import (
    ENUM_TYPES,
    class_description,
    element_models,
    enum_targets,
    enum_values,
    format_type,
    generated_comment,
    metamodel_models,
    relationship_targets,
)


def _field_marker(field_info) -> str:
    return "*" if field_info.is_required() else "o"


def render_plantuml_reference() -> str:
    element_model_set = set(element_models())
    lines = [
        generated_comment("'"),
        "@startuml",
        "hide empty members",
        "skinparam classAttributeIconSize 0",
        "",
    ]

    for enum_cls in ENUM_TYPES:
        lines.append(f"enum {enum_cls.__name__} {{")
        for value in enum_values(enum_cls):
            lines.append(f"  {value}")
        lines.append("}")
        lines.append("")

    for model_cls in metamodel_models():
        stereotype = "element" if model_cls in element_model_set else "metadata"
        lines.append(f'class {model_cls.__name__} <<{stereotype}>> {{')
        description = class_description(model_cls)
        if description:
            lines.append(f"  .. {description.replace(chr(10), ' ')} ..")
        for field_name, field_info in model_cls.model_fields.items():
            lines.append(
                f"  {_field_marker(field_info)} {field_name}: {format_type(field_info.annotation)}"
            )
        lines.append("}")
        lines.append("")

    for model_cls in metamodel_models():
        for base_cls in model_cls.__bases__:
            if issubclass(base_cls, BaseModel) and base_cls is not BaseModel and hasattr(base_cls, "model_fields"):
                lines.append(f"{base_cls.__name__} <|-- {model_cls.__name__}")

        for field_name, field_info in model_cls.model_fields.items():
            for target_model in sorted(relationship_targets(field_info.annotation), key=lambda cls: cls.__name__):
                lines.append(f"{model_cls.__name__} --> {target_model.__name__} : {field_name}")
            for target_enum in sorted(enum_targets(field_info.annotation), key=lambda cls: cls.__name__):
                lines.append(f"{model_cls.__name__} ..> {target_enum.__name__} : {field_name}")

    lines.append("@enduml")
    return "\n".join(lines).rstrip() + "\n"
