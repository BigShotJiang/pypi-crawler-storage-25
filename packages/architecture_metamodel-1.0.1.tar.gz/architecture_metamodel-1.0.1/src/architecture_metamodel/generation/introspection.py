"""Shared introspection helpers for deterministic derived-artifact generation."""

from __future__ import annotations

import inspect
from enum import Enum
from pathlib import Path
from typing import Any, Optional, Union, get_args, get_origin

from pydantic import BaseModel
from pydantic.fields import PydanticUndefined

from architecture_metamodel.api import (
    ActorKind,
    ArchitectureLevel,
    ArchitectureStatus,
    CommonMetadata,
    CybersecurityMetadata,
    DataClassification,
    ElementType,
    HardeningLevel,
    InterfaceDirectionality,
    RelationshipSet,
    SecretsHandling,
    SecurityControl,
    SecurityMarking,
    TrustBoundaryType,
    VerificationType,
)
from architecture_metamodel.parsing import ELEMENT_MODEL_BY_TYPE


REPO_ROOT = Path(__file__).resolve().parents[3]
METAMODEL_DIR = REPO_ROOT / "metamodel"
DOCS_DIR = REPO_ROOT / "docs"
GENERATED_HEADER_LINES = [
    "Generated from the authoritative Python metamodel package.",
    "Do not edit by hand.",
    "Regenerate with: architecture-generate",
]

ENUM_TYPES = [
    ElementType,
    ArchitectureStatus,
    ArchitectureLevel,
    InterfaceDirectionality,
    ActorKind,
    VerificationType,
    SecurityMarking,
    TrustBoundaryType,
    DataClassification,
    SecretsHandling,
    HardeningLevel,
    SecurityControl,
]

METADATA_MODELS = [
    CybersecurityMetadata,
    RelationshipSet,
    CommonMetadata,
]


def element_models() -> list[type[BaseModel]]:
    return [ELEMENT_MODEL_BY_TYPE[element_type] for element_type in ELEMENT_MODEL_BY_TYPE]


def metamodel_models() -> list[type[BaseModel]]:
    return METADATA_MODELS + element_models()


def generated_comment(prefix: str) -> str:
    return "\n".join(f"{prefix} {line}" for line in GENERATED_HEADER_LINES)


def class_description(model_cls: type[Any]) -> str:
    own_doc = model_cls.__dict__.get("__doc__")
    if not own_doc:
        return ""
    return inspect.cleandoc(own_doc)


def field_description(field_name: str, field_info: Any) -> str:
    if field_info.description:
        return field_info.description
    return field_name.replace("_", " ").capitalize() + "."


def unwrap_optional(annotation: Any) -> tuple[Any, bool]:
    origin = get_origin(annotation)
    if origin is Union:
        args = [arg for arg in get_args(annotation) if arg is not type(None)]
        if len(args) == 1 and len(args) != len(get_args(annotation)):
            return args[0], True
    return annotation, False


def format_type(annotation: Any) -> str:
    annotation, is_optional = unwrap_optional(annotation)
    origin = get_origin(annotation)

    if origin in {list, set, tuple}:
        args = get_args(annotation)
        inner = format_type(args[0]) if args else "Any"
        text = f"list[{inner}]"
    elif origin is dict:
        args = get_args(annotation)
        key_text = format_type(args[0]) if args else "Any"
        value_text = format_type(args[1]) if len(args) > 1 else "Any"
        text = f"dict[{key_text}, {value_text}]"
    elif inspect.isclass(annotation) and issubclass(annotation, Enum):
        text = annotation.__name__
    elif inspect.isclass(annotation) and issubclass(annotation, BaseModel):
        text = annotation.__name__
    elif hasattr(annotation, "__name__"):
        text = annotation.__name__
    else:
        text = str(annotation).replace("typing.", "")

    if is_optional:
        return f"Optional[{text}]"
    return text


def default_text(field_info: Any) -> str:
    if field_info.is_required():
        return "required"
    if field_info.default_factory is not None:
        produced = field_info.default_factory()
        return repr(produced)
    if field_info.default is PydanticUndefined:
        return "required"
    return repr(field_info.default)


def enum_values(enum_cls: type[Enum]) -> list[str]:
    return [member.value for member in enum_cls]


def relationship_targets(annotation: Any) -> set[type[BaseModel]]:
    annotation, _ = unwrap_optional(annotation)
    origin = get_origin(annotation)

    if origin in {list, set, tuple}:
        args = get_args(annotation)
        return relationship_targets(args[0]) if args else set()
    if origin is dict:
        args = get_args(annotation)
        if len(args) == 2:
            return relationship_targets(args[1])
        return set()
    if inspect.isclass(annotation) and issubclass(annotation, BaseModel):
        return {annotation}
    return set()


def enum_targets(annotation: Any) -> set[type[Enum]]:
    annotation, _ = unwrap_optional(annotation)
    origin = get_origin(annotation)

    if origin in {list, set, tuple, dict}:
        result: set[type[Enum]] = set()
        for arg in get_args(annotation):
            result.update(enum_targets(arg))
        return result
    if inspect.isclass(annotation) and issubclass(annotation, Enum):
        return {annotation}
    return set()


def placeholder_scalar(field_name: str, annotation: Any, model_cls: type[BaseModel]) -> Any:
    annotation, _ = unwrap_optional(annotation)
    origin = get_origin(annotation)

    if field_name == "id":
        element_type = model_cls.model_fields["type"].default
        return f"{element_type.value}_001"
    if field_name == "name":
        return f"Example {model_cls.__name__.removesuffix('Metadata')}"
    if field_name == "documentation":
        return f"Example documentation for {model_cls.__name__.removesuffix('Metadata')}."
    if field_name == "release":
        return "0.1.0"
    if field_name == "status":
        return "DRAFT"
    if field_name == "objective":
        return "Example objective."
    if field_name == "budgeted_activity":
        return "Low"
    if field_name in {"budgeted_size", "budgeted_compute", "budgeted_storage", "actual_compute", "actual_storage"}:
        return "TBD"
    if field_name == "multiplicity":
        return "1..n"
    if field_name == "verification_description":
        return "Example verification coverage."
    if field_name == "realization_kind":
        return "ExampleRuntime"
    if field_name == "deployment_environment":
        return "Local"

    if inspect.isclass(annotation) and issubclass(annotation, Enum):
        return annotation(list(annotation)[0]).value
    if annotation is bool:
        return False
    if annotation is int:
        return 1
    if annotation is float:
        return 1.0
    if annotation is str:
        return f"Example {field_name.replace('_', ' ')}."
    if origin in {list, set, tuple}:
        return []
    if origin is dict:
        return {}
    return None
