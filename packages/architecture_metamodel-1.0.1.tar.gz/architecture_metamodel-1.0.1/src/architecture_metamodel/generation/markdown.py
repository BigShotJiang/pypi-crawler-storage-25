"""Markdown reference generation from the authoritative Python metamodel."""

from __future__ import annotations

from pydantic import BaseModel

from architecture_metamodel.generation.introspection import (
    ENUM_TYPES,
    class_description,
    default_text,
    enum_values,
    field_description,
    format_type,
    generated_comment,
    metamodel_models,
)
from architecture_metamodel.rules import (
    ALLOWED_RELATIONSHIPS,
    RECOMMENDED_METADATA_FIELDS,
    REQUIRED_RELATIONSHIPS,
)


def _render_enum_section() -> list[str]:
    lines = ["## Enumerations", ""]
    for enum_cls in ENUM_TYPES:
        lines.append(f"### `{enum_cls.__name__}`")
        values = ", ".join(f"`{value}`" for value in enum_values(enum_cls))
        lines.append(f"Values: {values}")
        lines.append("")
    return lines


def _render_model_section(model_cls: type[BaseModel]) -> list[str]:
    lines = [f"## `{model_cls.__name__}`", ""]
    description = class_description(model_cls)
    if description:
        lines.append(description)
        lines.append("")

    lines.extend(
        [
            "| Field | Type | Required | Default | Description | Alias |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
    )

    for field_name, field_info in model_cls.model_fields.items():
        alias = field_info.alias or ""
        lines.append(
            "| "
            + " | ".join(
                [
                    f"`{field_name}`",
                    f"`{format_type(field_info.annotation)}`",
                    "yes" if field_info.is_required() else "no",
                    f"`{default_text(field_info)}`",
                    field_description(field_name, field_info).replace("\n", " "),
                    f"`{alias}`" if alias else "",
                ]
            )
            + " |"
        )
    lines.append("")
    return lines


def _render_policy_section() -> list[str]:
    lines = ["## Declarative Policy", ""]
    lines.extend(
        [
            "| Element Type | Allowed Relationships | Required Relationships | Recommended Metadata |",
            "| --- | --- | --- | --- |",
        ]
    )
    for element_type in ALLOWED_RELATIONSHIPS:
        lines.append(
            "| "
            + " | ".join(
                [
                    f"`{element_type.value}`",
                    ", ".join(f"`{name}`" for name in sorted(ALLOWED_RELATIONSHIPS[element_type])),
                    ", ".join(f"`{name}`" for name in sorted(REQUIRED_RELATIONSHIPS[element_type])) or "-",
                    ", ".join(f"`{name}`" for name in sorted(RECOMMENDED_METADATA_FIELDS[element_type])) or "-",
                ]
            )
            + " |"
        )
    lines.append("")
    return lines


def render_markdown_reference() -> str:
    lines = [
        "<!-- Generated from the authoritative Python metamodel package. -->",
        "<!-- Do not edit by hand. -->",
        "<!-- Regenerate with: architecture-generate -->",
        "# Architecture Metamodel Reference",
        "",
        "This document is generated from the authoritative Python metamodel package.",
        "",
    ]
    lines.extend(_render_enum_section())
    lines.extend(_render_policy_section())
    for model_cls in metamodel_models():
        lines.extend(_render_model_section(model_cls))
    return "\n".join(lines).rstrip() + "\n"
