"""Generated documentation for the supported public API surface."""

from __future__ import annotations

import inspect
from enum import Enum
from typing import Any

from pydantic import BaseModel

import architecture_metamodel.api as public_api
from architecture_metamodel.generation.introspection import GENERATED_HEADER_LINES, format_type


def _public_members() -> list[tuple[str, Any]]:
    return [(name, getattr(public_api, name)) for name in public_api.__all__]


def _section_name(name: str, member: Any) -> str:
    if inspect.isfunction(member):
        return "Functions"
    if inspect.isclass(member) and issubclass(member, Enum):
        return "Enums"
    if inspect.isclass(member) and issubclass(member, BaseModel):
        return "Pydantic Models"
    if inspect.isclass(member):
        return "Core Types"
    return "Constants and Registries"


def _signature_text(member: Any) -> str:
    if not inspect.isfunction(member):
        return ""
    return str(inspect.signature(member))


def _doc_summary(member: Any) -> str:
    doc = inspect.getdoc(member)
    if not doc:
        return "No public docstring is currently defined."
    return doc.splitlines()[0]


def _enum_values_text(enum_cls: type[Enum]) -> str:
    return ", ".join(f"`{item.value}`" for item in enum_cls)


def _model_fields_text(model_cls: type[BaseModel]) -> list[str]:
    lines: list[str] = []
    for field_name, field_info in model_cls.model_fields.items():
        required_text = "required" if field_info.is_required() else "optional"
        type_name = format_type(field_info.annotation)
        lines.append(f"- `{field_name}`: `{type_name}` ({required_text})")
    return lines


def _constant_summary(member: Any) -> str:
    if isinstance(member, dict):
        return f"Mapping with `{len(member)}` entries."
    return f"Public constant of type `{type(member).__name__}`."


def render_public_api_reference() -> str:
    sections: dict[str, list[tuple[str, Any]]] = {
        "Functions": [],
        "Core Types": [],
        "Enums": [],
        "Pydantic Models": [],
        "Constants and Registries": [],
    }

    for name, member in _public_members():
        sections[_section_name(name, member)].append((name, member))

    lines = ["# Public API Reference", ""]
    lines.extend(f"> {line}" for line in GENERATED_HEADER_LINES)
    lines.extend(
        [
            "",
            "This reference documents the supported exports from `architecture_metamodel.api`.",
            "It is the consumer-facing API contract for downstream repositories.",
            "",
        ]
    )

    for section_name, members in sections.items():
        lines.append(f"## {section_name}")
        lines.append("")
        if not members:
            lines.append("No exports in this section.")
            lines.append("")
            continue

        for name, member in members:
            lines.append(f"### `{name}`")
            lines.append("")

            if inspect.isfunction(member):
                lines.append(f"- Signature: `{name}{_signature_text(member)}`")
                lines.append(f"- Summary: {_doc_summary(member)}")
            elif inspect.isclass(member) and issubclass(member, Enum):
                lines.append(f"- Summary: {_doc_summary(member)}")
                lines.append(f"- Values: {_enum_values_text(member)}")
            elif inspect.isclass(member) and issubclass(member, BaseModel):
                lines.append(f"- Summary: {_doc_summary(member)}")
                field_lines = _model_fields_text(member)
                if field_lines:
                    lines.append("- Fields:")
                    lines.extend(field_lines)
            elif inspect.isclass(member):
                lines.append(f"- Summary: {_doc_summary(member)}")
            else:
                lines.append(f"- Summary: {_constant_summary(member)}")

            lines.append(f"- Source module: `{getattr(member, '__module__', 'architecture_metamodel.api')}`")
            lines.append("")

    return "\n".join(lines) + "\n"
