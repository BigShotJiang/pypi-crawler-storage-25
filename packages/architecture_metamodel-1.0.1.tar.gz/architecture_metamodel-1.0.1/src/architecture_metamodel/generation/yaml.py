"""YAML template and reference-example generation from the authoritative metamodel."""

from __future__ import annotations

from typing import Any

import yaml

from architecture_metamodel.generation.introspection import (
    GENERATED_HEADER_LINES,
    element_models,
    placeholder_scalar,
)


class _NoAliasDumper(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


def _cybersecurity_example() -> dict[str, Any]:
    return {
        "is_security_relevant": False,
        "security_markings": ["ASSET"],
        "trust_boundary_type": "NONE",
        "data_classification": "INTERNAL",
        "secrets_handling": "NONE",
        "hardening_level": "BASIC",
        "security_review_required": False,
        "threat_model_required": False,
        "security_test_required": False,
        "controls": ["INPUT_VALIDATION"],
        "notes": ["Example cybersecurity note."],
    }


def _template_for_model(model_cls) -> dict[str, Any]:
    template: dict[str, Any] = {}
    for field_name, field_info in model_cls.model_fields.items():
        if field_name == "type":
            template[field_name] = field_info.default.value
            continue
        if field_name == "relationships":
            template[field_name] = {
                relationship_name: []
                for relationship_name in field_info.annotation.model_fields
            }
            continue
        if field_name == "cybersecurity":
            template[field_name] = _cybersecurity_example()
            continue
        if field_name == "design_constraints":
            template[field_name] = ["Example design constraint."]
            continue
        if field_name == "verification_ref":
            template[field_name] = ["TC_001"]
            continue
        if field_name == "verification_success_criteria":
            template[field_name] = ["Example success criteria."]
            continue
        if field_name == "test_implementation_reference":
            template[field_name] = ["tests/test_example.py"]
            continue
        template[field_name] = placeholder_scalar(field_name, field_info.annotation, model_cls)
    return template


def render_yaml_template() -> str:
    payload = {"templates": {}}
    for model_cls in element_models():
        element_type = model_cls.model_fields["type"].default.value
        payload["templates"][element_type] = _template_for_model(model_cls)

    header = "\n".join(f"# {line}" for line in GENERATED_HEADER_LINES)
    body = yaml.dump(payload, Dumper=_NoAliasDumper, sort_keys=False, allow_unicode=False)
    return header + "\n" + body


def _full_example_elements() -> list[dict[str, Any]]:
    shared = {
        "release": "0.1.0",
        "status": "DRAFT",
        "design_constraints": ["Example constraint."],
        "cybersecurity": _cybersecurity_example(),
    }
    return [
        {
            **shared,
            "id": "OA_001",
            "name": "Manage Spending",
            "type": "OA",
            "documentation": "Mission-facing spending activity.",
            "objective": "Manage discretionary spending deliberately.",
            "operational_performer": ["ACT_001"],
            "preconditions": ["A spending candidate exists."],
            "postconditions": ["A spending decision is available."],
            "relationships": {
                "implemented_by": ["FCN_001"],
                "performed_by": ["ACT_001"],
            },
        },
        {
            **shared,
            "id": "FCN_001",
            "name": "Evaluate Candidate",
            "type": "FCN",
            "documentation": "Evaluate a spending candidate.",
            "architecture_level": "Level1",
            "objective": "Evaluate a candidate impulse.",
            "budgeted_activity": "Low",
            "verification_ref": ["TC_001"],
            "relationships": {
                "implements": ["OA_001"],
                "performed_by": ["LSYS_001"],
                "invokes": ["INT_001"],
                "aggregates": ["GSWF_001"],
                "is_composed_of": ["SWF_001"],
                "verified_by": ["TC_001"],
            },
        },
        {
            **shared,
            "id": "INT_001",
            "name": "Evaluation Interface",
            "type": "INT",
            "documentation": "Boundary for evaluation work.",
            "interface_directionality": "INPUT",
            "relationships": {
                "exposed_by": ["LSYS_001"],
                "consumed_by": ["LSYS_001"],
                "traversed_by": ["DOBJ_001"],
                "invoked_by": ["FCN_001"],
                "realized_by": ["SWA_001"],
                "verified_by": ["TC_001"],
                "interacted_through_by": ["ACT_001"],
            },
        },
        {
            **shared,
            "id": "DOBJ_001",
            "name": "Candidate Record",
            "type": "DOBJ",
            "documentation": "Candidate data object.",
            "budgeted_size": "Small",
            "multiplicity": "1..n",
            "relationships": {
                "traverses": ["INT_001"],
                "stored_by": ["LSYS_001"],
            },
        },
        {
            **shared,
            "id": "LSYS_001",
            "name": "Evaluation Engine",
            "type": "LSYS",
            "documentation": "Logical evaluation engine.",
            "architecture_level": "Level1",
            "budgeted_compute": "Medium",
            "budgeted_storage": "Small",
            "relationships": {
                "performs": ["FCN_001"],
                "exposes": ["INT_001"],
                "consumes": ["INT_001"],
                "stores": ["DOBJ_001"],
                "realized_by": ["PSYS_001"],
                "verified_by": ["TC_001"],
            },
        },
        {
            **shared,
            "id": "ACT_001",
            "name": "User",
            "type": "ACT",
            "documentation": "Human operator.",
            "actor_kind": "HUMAN",
            "relationships": {
                "performs": ["OA_001"],
                "interacts_through": ["INT_001"],
            },
        },
        {
            **shared,
            "id": "PSYS_001",
            "name": "Local Runtime",
            "type": "PSYS",
            "documentation": "Local runtime environment.",
            "realization_kind": "LocalProcess",
            "deployment_environment": "Laptop",
            "actual_compute": "Medium",
            "actual_storage": "Small",
            "relationships": {
                "realizes": ["LSYS_001"],
            },
        },
        {
            **shared,
            "id": "TC_001",
            "name": "Metamodel Baseline Validation",
            "type": "TC",
            "documentation": "Representative baseline validation case.",
            "verification_type": "INTEGRATION",
            "verification_description": "Checks the representative reference architecture.",
            "verification_success_criteria": ["The representative example validates with no errors."],
            "test_implementation_reference": ["tests/test_generation.py"],
            "relationships": {
                "verifies": ["FCN_001", "INT_001", "LSYS_001", "SWA_001", "SW_001", "SWF_001", "GSWF_001"],
            },
        },
        {
            **shared,
            "id": "SWA_001",
            "name": "Evaluation Service Bundle",
            "type": "SWA",
            "documentation": "Software assembly that realizes the interface boundary.",
            "relationships": {
                "realizes": ["INT_001"],
                "is_composed_of": ["SW_001"],
                "verified_by": ["TC_001"],
            },
        },
        {
            **shared,
            "id": "SW_001",
            "name": "Evaluation Module",
            "type": "SW",
            "documentation": "Software element that performs software functions.",
            "arguments": {"candidate_id": "str"},
            "relationships": {
                "part_of": ["SWA_001"],
                "performs": ["SWF_001", "GSWF_001"],
                "verified_by": ["TC_001"],
            },
        },
        {
            **shared,
            "id": "SWF_001",
            "name": "Evaluate Function Implementation",
            "type": "SWF",
            "documentation": "Software implementation of the architecture function.",
            "relationships": {
                "part_of": ["FCN_001"],
                "performed_by": ["SW_001"],
                "invokes": ["SWF_001"],
                "invoked_by": ["SWF_001"],
                "verified_by": ["TC_001"],
            },
        },
        {
            **shared,
            "id": "GSWF_001",
            "name": "Shared Evaluation Helper",
            "type": "GSWF",
            "documentation": "Reusable helper for evaluation logic.",
            "relationships": {
                "aggregated_by": ["FCN_001"],
                "performed_by": ["SW_001"],
                "verified_by": ["TC_001"],
            },
        },
        {
            **shared,
            "id": "HW_001",
            "name": "Laptop Hardware",
            "type": "HW",
            "documentation": "Representative hardware substrate.",
            "relationships": {},
        },
    ]


def render_yaml_valid_example() -> str:
    header = "\n".join(f"# {line}" for line in GENERATED_HEADER_LINES)
    body = yaml.dump({"elements": _full_example_elements()}, Dumper=_NoAliasDumper, sort_keys=False, allow_unicode=False)
    return header + "\n" + body
