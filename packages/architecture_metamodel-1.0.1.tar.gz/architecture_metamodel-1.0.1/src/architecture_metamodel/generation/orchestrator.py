"""Unified generation and stale-artifact checking workflow."""

from __future__ import annotations

from pathlib import Path

from architecture_metamodel.generation.api_docs import render_public_api_reference
from architecture_metamodel.generation.introspection import DOCS_DIR, METAMODEL_DIR
from architecture_metamodel.generation.markdown import render_markdown_reference
from architecture_metamodel.generation.plantuml import render_plantuml_reference
from architecture_metamodel.generation.yaml import render_yaml_template, render_yaml_valid_example


GENERATED_ARTIFACTS = {
    DOCS_DIR / "public_api.md": render_public_api_reference,
    METAMODEL_DIR / "architecture_metamodel.md": render_markdown_reference,
    METAMODEL_DIR / "architecture_metamodel_overview.puml": render_plantuml_reference,
    METAMODEL_DIR / "architecture_element_template.yaml": render_yaml_template,
    METAMODEL_DIR / "architecture_valid_example.yaml": render_yaml_valid_example,
}


def render_generated_artifacts() -> dict[Path, str]:
    return {
        path: render_function()
        for path, render_function in GENERATED_ARTIFACTS.items()
    }


def write_generated_artifacts() -> list[Path]:
    written: list[Path] = []
    for path, content in render_generated_artifacts().items():
        path.parent.mkdir(parents=True, exist_ok=True)
        if not path.exists() or path.read_text(encoding="utf-8") != content:
            path.write_text(content, encoding="utf-8")
            written.append(path)
    return written


def check_generated_artifacts() -> list[Path]:
    stale: list[Path] = []
    for path, content in render_generated_artifacts().items():
        if not path.exists() or path.read_text(encoding="utf-8") != content:
            stale.append(path)
    return stale
