"""Relationship schema shared by all architecture elements."""

from __future__ import annotations

from typing import Any, List, Sequence, Set

from pydantic import BaseModel, ConfigDict, Field, field_validator


class RelationshipSet(BaseModel):
    """All reciprocal relationship fields recognized by the metamodel."""

    model_config = ConfigDict(extra="forbid")

    implements: List[str] = Field(default_factory=list)
    implemented_by: List[str] = Field(default_factory=list)

    aggregates: List[str] = Field(default_factory=list)
    aggregated_by: List[str] = Field(default_factory=list)

    is_composed_of: List[str] = Field(default_factory=list)
    part_of: List[str] = Field(default_factory=list)

    performs: List[str] = Field(default_factory=list)
    performed_by: List[str] = Field(default_factory=list)

    exposes: List[str] = Field(default_factory=list)
    exposed_by: List[str] = Field(default_factory=list)

    consumes: List[str] = Field(default_factory=list)
    consumed_by: List[str] = Field(default_factory=list)

    traverses: List[str] = Field(default_factory=list)
    traversed_by: List[str] = Field(default_factory=list)

    invokes: List[str] = Field(default_factory=list)
    invoked_by: List[str] = Field(default_factory=list)

    realizes: List[str] = Field(default_factory=list)
    realized_by: List[str] = Field(default_factory=list)

    stores: List[str] = Field(default_factory=list)
    stored_by: List[str] = Field(default_factory=list)

    verifies: List[str] = Field(default_factory=list)
    verified_by: List[str] = Field(default_factory=list)

    interacts_through: List[str] = Field(default_factory=list)
    interacted_through_by: List[str] = Field(default_factory=list)

    @field_validator("*", mode="before")
    @classmethod
    def _coerce_list(cls, value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return list(value)
        raise TypeError("Relationship values must be a string, list of strings, or null.")

    @field_validator("*")
    @classmethod
    def _normalize_list(cls, value: List[str]) -> List[str]:
        deduped: List[str] = []
        seen: Set[str] = set()
        for entry in value:
            if not isinstance(entry, str):
                raise TypeError("Relationship entries must be strings.")
            normalized = entry.strip()
            if not normalized:
                raise ValueError("Relationship entries must not be empty.")
            if normalized not in seen:
                deduped.append(normalized)
                seen.add(normalized)
        return deduped
