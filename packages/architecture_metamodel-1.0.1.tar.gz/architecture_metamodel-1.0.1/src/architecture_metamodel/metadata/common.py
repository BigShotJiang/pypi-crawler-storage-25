"""Common metadata shared across all architecture element models."""

from __future__ import annotations

import re
from typing import Any, List, Optional, Sequence

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from architecture_metamodel.enums import ArchitectureStatus, ElementType
from architecture_metamodel.metadata.cybersecurity import CybersecurityMetadata
from architecture_metamodel.metadata.relationships import RelationshipSet


class CommonMetadata(BaseModel):
    """Base metadata shared by all governed architecture elements."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str
    type: ElementType
    documentation: str
    relationships: RelationshipSet = Field(default_factory=RelationshipSet)

    release: Optional[str] = None
    status: Optional[ArchitectureStatus] = None
    design_constraints: List[str] = Field(default_factory=list)
    cybersecurity: Optional[CybersecurityMetadata] = None

    @field_validator("id")
    @classmethod
    def validate_id_format(cls, value: str) -> str:
        pattern = r"^(OA|FCN|INT|DOBJ|LSYS|ACT|PSYS|TC|SWA|SWF|GSWF|SW|HW)_[0-9]{3}$"
        if not re.fullmatch(pattern, value):
            raise ValueError("ID must match '[ELEMENT_ENUM]_[NNN]', e.g. FCN_001.")
        return value

    @model_validator(mode="after")
    def validate_id_matches_type(self) -> "CommonMetadata":
        prefix = self.id.split("_", 1)[0]
        if prefix != self.type.value:
            raise ValueError(
                f"Element id '{self.id}' does not match type '{self.type.value}'."
            )
        return self

    @field_validator("name", "documentation")
    @classmethod
    def non_empty_strings(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Field must not be empty.")
        return normalized

    @field_validator("release")
    @classmethod
    def validate_release_semver(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        pattern = r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$"
        if not re.fullmatch(pattern, value):
            raise ValueError("Release must use semantic versioning, e.g. 1.1.0.")
        return value

    @field_validator("design_constraints", mode="before")
    @classmethod
    def coerce_design_constraints(cls, value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return list(value)
        raise TypeError("design_constraints must be a string, list of strings, or null.")

    @field_validator("design_constraints")
    @classmethod
    def normalize_design_constraints(cls, value: List[str]) -> List[str]:
        return [entry.strip() for entry in value if isinstance(entry, str) and entry.strip()]
