"""Reusable cybersecurity metadata carried by architecture elements."""

from __future__ import annotations

from typing import Any, List, Optional, Sequence

from pydantic import BaseModel, ConfigDict, Field, field_validator

from architecture_metamodel.enums import (
    DataClassification,
    HardeningLevel,
    SecretsHandling,
    SecurityControl,
    SecurityMarking,
    TrustBoundaryType,
)


class CybersecurityMetadata(BaseModel):
    """Security metadata attached to architecture elements."""

    model_config = ConfigDict(extra="forbid")

    is_security_relevant: bool
    security_markings: List[SecurityMarking] = Field(default_factory=list)
    trust_boundary_type: Optional[TrustBoundaryType] = None
    data_classification: Optional[DataClassification] = None
    secrets_handling: Optional[SecretsHandling] = None
    hardening_level: Optional[HardeningLevel] = None
    security_review_required: Optional[bool] = None
    threat_model_required: Optional[bool] = None
    security_test_required: Optional[bool] = None
    controls: List[SecurityControl] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)

    @field_validator("notes", mode="before")
    @classmethod
    def _coerce_notes(cls, value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return list(value)
        raise TypeError("notes must be a string, list of strings, or null.")

    @field_validator("notes")
    @classmethod
    def _normalize_notes(cls, value: List[str]) -> List[str]:
        normalized: List[str] = []
        for entry in value:
            if not isinstance(entry, str):
                raise TypeError("Each cybersecurity note must be a string.")
            item = entry.strip()
            if item:
                normalized.append(item)
        return normalized
