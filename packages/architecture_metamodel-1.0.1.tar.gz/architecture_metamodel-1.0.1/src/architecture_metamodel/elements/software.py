"""Software architecture element models."""

from __future__ import annotations

from typing import Any, Dict

from pydantic import Field, field_validator

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class SoftwareMetadata(CommonMetadata):
    """Concrete software element that performs software or shared software functions."""

    type: ElementType = Field(default=ElementType.SW)
    arguments: Dict[str, str] = Field(default_factory=dict)

    @field_validator("arguments", mode="before")
    @classmethod
    def coerce_arguments(cls, value: Any) -> Dict[str, str]:
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise TypeError("arguments must be a dictionary of 'arg_name: data_type'.")
        return value

    @field_validator("arguments")
    @classmethod
    def normalize_arguments(cls, value: Dict[str, str]) -> Dict[str, str]:
        normalized: Dict[str, str] = {}
        for arg_name, data_type in value.items():
            if not isinstance(arg_name, str) or not arg_name.strip():
                raise ValueError("Software argument names must be non-empty strings.")
            if not isinstance(data_type, str) or not data_type.strip():
                raise ValueError(
                    f"Software argument '{arg_name}' must have a non-empty string data type."
                )
            normalized[arg_name.strip()] = data_type.strip()
        return normalized
