"""Operational architecture element models."""

from __future__ import annotations

from typing import Any, List, Sequence

from pydantic import Field, field_validator

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class OperationalActivityMetadata(CommonMetadata):
    """Mission-facing operational activity implemented by architecture functions."""

    type: ElementType = Field(default=ElementType.OA)
    objective: str
    operational_performer: List[str] = Field(default_factory=list)
    preconditions: List[str] = Field(default_factory=list)
    postconditions: List[str] = Field(default_factory=list)

    @field_validator("objective")
    @classmethod
    def validate_required_text(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Field must not be empty.")
        return normalized

    @field_validator("operational_performer", "preconditions", "postconditions", mode="before")
    @classmethod
    def coerce_condition_lists(cls, value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return list(value)
        raise TypeError("Field must be a string, list, or null.")

    @field_validator("operational_performer", "preconditions", "postconditions")
    @classmethod
    def normalize_list_text(cls, value: List[str]) -> List[str]:
        return [entry.strip() for entry in value if isinstance(entry, str) and entry.strip()]
