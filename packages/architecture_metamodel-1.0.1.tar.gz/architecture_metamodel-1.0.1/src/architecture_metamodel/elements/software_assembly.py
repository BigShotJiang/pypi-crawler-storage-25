"""Software-assembly architecture element models."""

from __future__ import annotations

from pydantic import Field

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class SoftwareAssemblyMetadata(CommonMetadata):
    """Packaged software assembly that realizes a logical system or interface."""

    type: ElementType = Field(default=ElementType.SWA)
