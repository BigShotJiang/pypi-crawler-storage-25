"""Global software-function architecture element models."""

from __future__ import annotations

from pydantic import Field

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class GlobalSoftwareFunctionMetadata(CommonMetadata):
    """Reusable software function aggregated into one or more architecture functions."""

    type: ElementType = Field(default=ElementType.GSWF)
