"""Actor architecture element models."""

from __future__ import annotations

from pydantic import Field

from architecture_metamodel.enums import ActorKind, ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class ActorMetadata(CommonMetadata):
    """External participant that performs operational work or crosses an interface boundary."""

    type: ElementType = Field(default=ElementType.ACT)
    actor_kind: ActorKind
