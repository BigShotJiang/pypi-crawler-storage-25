"""Functional architecture element models."""

from __future__ import annotations

from typing import Any, List, Optional, Sequence

from pydantic import Field, field_validator

from architecture_metamodel.enums import ArchitectureLevel, ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class FunctionMetadata(CommonMetadata):
    """Architecture function that contributes behavior toward an operational activity."""

    type: ElementType = Field(default=ElementType.FCN)
    architecture_level: ArchitectureLevel
    objective: str
    budgeted_activity: Optional[str] = None
    verification_ref: List[str] = Field(default_factory=list)

    @field_validator("objective")
    @classmethod
    def validate_objective(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("objective must not be empty.")
        return normalized

    @field_validator("budgeted_activity")
    @classmethod
    def normalize_optional_text(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        normalized = value.strip()
        return normalized or None

    @field_validator("verification_ref", mode="before")
    @classmethod
    def coerce_verification_ref(cls, value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return list(value)
        raise TypeError("verification_ref must be a string, list of strings, or null.")

    @field_validator("verification_ref")
    @classmethod
    def normalize_verification_ref(cls, value: List[str]) -> List[str]:
        return [entry.strip() for entry in value if isinstance(entry, str) and entry.strip()]
