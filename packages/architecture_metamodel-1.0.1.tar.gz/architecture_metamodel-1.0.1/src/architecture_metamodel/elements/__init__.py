"""Architecture element models, one module per metamodel element."""

from .actor import ActorMetadata
from .data_object import DataObjectMetadata
from .functional import FunctionMetadata
from .global_software_function import GlobalSoftwareFunctionMetadata
from .hardware import HardwareMetadata
from .interface import InterfaceMetadata
from .logical import LogicalSystemMetadata
from .operational import OperationalActivityMetadata
from .physical_system import PhysicalSystemMetadata
from .software import SoftwareMetadata
from .software_assembly import SoftwareAssemblyMetadata
from .software_function import SoftwareFunctionMetadata
from .test_case import TestCaseMetadata

__all__ = [
    "ActorMetadata",
    "DataObjectMetadata",
    "FunctionMetadata",
    "GlobalSoftwareFunctionMetadata",
    "HardwareMetadata",
    "InterfaceMetadata",
    "LogicalSystemMetadata",
    "OperationalActivityMetadata",
    "PhysicalSystemMetadata",
    "SoftwareAssemblyMetadata",
    "SoftwareFunctionMetadata",
    "SoftwareMetadata",
    "TestCaseMetadata",
]
