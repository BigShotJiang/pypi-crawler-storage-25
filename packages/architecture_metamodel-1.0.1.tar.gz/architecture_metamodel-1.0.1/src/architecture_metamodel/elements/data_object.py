"""Data-object architecture element models."""

from __future__ import annotations

from typing import Optional

from pydantic import Field, field_validator

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class DataObjectMetadata(CommonMetadata):
    """Logical data object that traverses interfaces and may be stored."""

    type: ElementType = Field(default=ElementType.DOBJ)
    budgeted_size: Optional[str] = None
    multiplicity: Optional[str] = None

    @field_validator("budgeted_size", "multiplicity")
    @classmethod
    def normalize_budgeted_values(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        normalized = value.strip()
        return normalized or None
