"""Logical architecture element models."""

from __future__ import annotations

from typing import Optional

from pydantic import Field, field_validator

from architecture_metamodel.enums import ArchitectureLevel, ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class LogicalSystemMetadata(CommonMetadata):
    """Logical subsystem that performs functions and owns interfaces or storage."""

    type: ElementType = Field(default=ElementType.LSYS)
    architecture_level: ArchitectureLevel
    budgeted_compute: Optional[str] = None
    budgeted_storage: Optional[str] = None

    @field_validator("budgeted_compute", "budgeted_storage")
    @classmethod
    def normalize_budget_fields(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        normalized = value.strip()
        return normalized or None
