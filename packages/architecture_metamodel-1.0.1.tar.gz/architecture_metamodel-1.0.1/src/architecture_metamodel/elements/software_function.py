"""Software-function architecture element models."""

from __future__ import annotations

from pydantic import Field

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class SoftwareFunctionMetadata(CommonMetadata):
    """Software-level function allocated beneath an architecture function."""

    type: ElementType = Field(default=ElementType.SWF)
