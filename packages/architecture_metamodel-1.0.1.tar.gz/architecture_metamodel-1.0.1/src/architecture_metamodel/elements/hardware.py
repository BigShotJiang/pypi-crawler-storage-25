"""Hardware architecture element models."""

from __future__ import annotations

from pydantic import Field

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class HardwareMetadata(CommonMetadata):
    """Hardware element relevant to verification or realization context."""

    type: ElementType = Field(default=ElementType.HW)
