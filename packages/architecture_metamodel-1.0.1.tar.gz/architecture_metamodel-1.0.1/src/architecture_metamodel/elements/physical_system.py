"""Physical-system architecture element models."""

from __future__ import annotations

from typing import Optional

from pydantic import Field, field_validator

from architecture_metamodel.enums import ElementType
from architecture_metamodel.metadata.common import CommonMetadata


class PhysicalSystemMetadata(CommonMetadata):
    """Concrete physical realization of a logical system."""

    type: ElementType = Field(default=ElementType.PSYS)
    realization_kind: str
    deployment_environment: Optional[str] = None
    actual_compute: Optional[str] = None
    actual_storage: Optional[str] = None

    @field_validator("realization_kind")
    @classmethod
    def validate_realization_kind(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("realization_kind must not be empty.")
        return normalized

    @field_validator("deployment_environment", "actual_compute", "actual_storage")
    @classmethod
    def normalize_optional_fields(cls, value: Optional[str]) -> Optional[str]:
        if value is None:
            return value
        normalized = value.strip()
        return normalized or None
