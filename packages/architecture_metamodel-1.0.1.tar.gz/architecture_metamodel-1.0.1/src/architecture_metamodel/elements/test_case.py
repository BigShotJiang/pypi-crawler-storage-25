"""Verification test-case element models."""

from __future__ import annotations

from typing import Any, List, Sequence

from pydantic import Field, field_validator

from architecture_metamodel.enums import ElementType, VerificationType
from architecture_metamodel.metadata.common import CommonMetadata


class TestCaseMetadata(CommonMetadata):
    """Verification artifact that proves behavior or structure across the architecture."""

    type: ElementType = Field(default=ElementType.TC)
    verification_type: VerificationType
    verification_description: str
    verification_success_criteria: List[str] = Field(default_factory=list)
    test_implementation_reference: List[str] = Field(default_factory=list)

    @field_validator("verification_description")
    @classmethod
    def validate_verification_description(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("verification_description must not be empty.")
        return normalized

    @field_validator("verification_success_criteria", mode="before")
    @classmethod
    def coerce_verification_success_criteria(cls, value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return list(value)
        raise TypeError("verification_success_criteria must be a string, list, or null.")

    @field_validator("verification_success_criteria")
    @classmethod
    def normalize_verification_success_criteria(cls, value: List[str]) -> List[str]:
        normalized = [entry.strip() for entry in value if isinstance(entry, str) and entry.strip()]
        if not normalized:
            raise ValueError("verification_success_criteria must not be empty.")
        return normalized

    @field_validator("test_implementation_reference", mode="before")
    @classmethod
    def coerce_test_reference(cls, value: Any) -> List[str]:
        if value is None:
            return []
        if isinstance(value, str):
            return [value]
        if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray)):
            return list(value)
        raise TypeError("test_implementation_reference must be a string, list of strings, or null.")

    @field_validator("test_implementation_reference")
    @classmethod
    def normalize_test_reference(cls, value: List[str]) -> List[str]:
        return [entry.strip() for entry in value if isinstance(entry, str) and entry.strip()]
