"""Interface architecture element models."""

from __future__ import annotations

from pydantic import Field

from architecture_metamodel.enums import ElementType, InterfaceDirectionality
from architecture_metamodel.metadata.common import CommonMetadata


class InterfaceMetadata(CommonMetadata):
    """Explicit boundary interface exposed and consumed by architecture elements."""

    type: ElementType = Field(default=ElementType.INT)
    interface_directionality: InterfaceDirectionality
