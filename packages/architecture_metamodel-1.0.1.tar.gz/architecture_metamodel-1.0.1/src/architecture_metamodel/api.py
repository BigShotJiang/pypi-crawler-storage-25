"""Single supported public API surface for the metamodel package."""

from __future__ import annotations

from pathlib import Path
from typing import Union

from architecture_metamodel.aliases import ArchitectureElement
from architecture_metamodel.elements import (
    ActorMetadata,
    DataObjectMetadata,
    FunctionMetadata,
    GlobalSoftwareFunctionMetadata,
    HardwareMetadata,
    InterfaceMetadata,
    LogicalSystemMetadata,
    OperationalActivityMetadata,
    PhysicalSystemMetadata,
    SoftwareAssemblyMetadata,
    SoftwareFunctionMetadata,
    SoftwareMetadata,
    TestCaseMetadata,
)
from architecture_metamodel.enums import (
    ActorKind,
    ArchitectureLevel,
    ArchitectureStatus,
    DataClassification,
    ElementType,
    HardeningLevel,
    InterfaceDirectionality,
    IssueSeverity,
    SecretsHandling,
    SecurityControl,
    SecurityMarking,
    TrustBoundaryType,
    VerificationType,
)
from architecture_metamodel.exceptions import (
    ArchitectureLoadError,
    ArchitectureParseError,
    ArchitecturePathNotFoundError,
    ArchitecturePathTypeError,
    EmptyArchitectureError,
    NoArchitectureInputsError,
)
from architecture_metamodel.graph.architecture_graph import ArchitectureGraph
from architecture_metamodel.issues import ValidationIssue
from architecture_metamodel.metadata import CommonMetadata, CybersecurityMetadata, RelationshipSet
from architecture_metamodel.parsing import ELEMENT_MODEL_BY_TYPE, get_model_for_type, parse_element
from architecture_metamodel.reporting import ValidationCheckResult, ValidationReport
from architecture_metamodel.rules import (
    ALLOWED_RELATIONSHIPS,
    ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION,
    INVERSE_RELATIONSHIPS,
    RECOMMENDED_METADATA_FIELDS,
    REQUIRED_RELATIONSHIPS,
)
from architecture_metamodel.validation import build_validation_report, validate_graph


def load_architecture(directory: Union[str, Path]) -> ArchitectureGraph:
    """Load an architecture graph from a YAML file or a directory of YAML files."""

    target_path = Path(directory)
    if target_path.is_file():
        return ArchitectureGraph.from_yaml_file(target_path)
    return ArchitectureGraph.from_directory(target_path)


def validate_architecture(directory: Union[str, Path]) -> list[ValidationIssue]:
    """Validate a YAML file or directory and return the raw issue list."""

    return load_architecture(directory).validate()


def validate_architecture_with_report(directory: Union[str, Path]) -> ValidationReport:
    """Validate a YAML file or directory and return a structured consumer report."""

    target_path = Path(directory)
    return load_architecture(target_path).validation_report(source_path=str(target_path))


__all__ = [
    "ALLOWED_RELATIONSHIPS",
    "ALLOWED_TARGET_TYPES_BY_SOURCE_RELATION",
    "ActorKind",
    "ActorMetadata",
    "ArchitectureElement",
    "ArchitectureGraph",
    "ArchitectureLoadError",
    "ArchitectureParseError",
    "ArchitecturePathNotFoundError",
    "ArchitecturePathTypeError",
    "ArchitectureLevel",
    "ArchitectureStatus",
    "CommonMetadata",
    "CybersecurityMetadata",
    "DataClassification",
    "DataObjectMetadata",
    "ElementType",
    "ELEMENT_MODEL_BY_TYPE",
    "EmptyArchitectureError",
    "FunctionMetadata",
    "get_model_for_type",
    "GlobalSoftwareFunctionMetadata",
    "HardwareMetadata",
    "HardeningLevel",
    "INVERSE_RELATIONSHIPS",
    "InterfaceDirectionality",
    "InterfaceMetadata",
    "IssueSeverity",
    "load_architecture",
    "LogicalSystemMetadata",
    "NoArchitectureInputsError",
    "OperationalActivityMetadata",
    "parse_element",
    "PhysicalSystemMetadata",
    "RECOMMENDED_METADATA_FIELDS",
    "REQUIRED_RELATIONSHIPS",
    "RelationshipSet",
    "SecretsHandling",
    "SecurityControl",
    "SecurityMarking",
    "SoftwareAssemblyMetadata",
    "SoftwareFunctionMetadata",
    "SoftwareMetadata",
    "TestCaseMetadata",
    "TrustBoundaryType",
    "validate_architecture",
    "validate_architecture_with_report",
    "ValidationCheckResult",
    "ValidationReport",
    "build_validation_report",
    "validate_graph",
    "ValidationIssue",
    "VerificationType",
]
