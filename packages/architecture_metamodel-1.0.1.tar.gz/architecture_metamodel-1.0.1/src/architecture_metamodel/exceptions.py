"""Explicit exception types for architecture input and loading failures."""

from __future__ import annotations

from pathlib import Path


class ArchitectureLoadError(Exception):
    """Base exception for failures that occur before validation can run."""

    error_code = "architecture_load_error"

    def __init__(self, path: Path | str, detail: str) -> None:
        self.path = Path(path)
        self.detail = detail
        super().__init__(detail)

    def __str__(self) -> str:
        return f"{self.error_code}: {self.detail} ({self.path})"

    def to_dict(self) -> dict[str, str]:
        return {
            "code": self.error_code,
            "path": str(self.path),
            "message": self.detail,
        }


class ArchitecturePathNotFoundError(ArchitectureLoadError):
    """Raised when the requested architecture path does not exist."""

    error_code = "path_not_found"


class ArchitecturePathTypeError(ArchitectureLoadError):
    """Raised when the requested path is not a YAML file or directory."""

    error_code = "invalid_path_type"


class EmptyArchitectureError(ArchitectureLoadError):
    """Raised when an architecture input exists but contains no elements."""

    error_code = "empty_architecture"


class NoArchitectureInputsError(ArchitectureLoadError):
    """Raised when a directory contains no YAML architecture inputs."""

    error_code = "no_architecture_inputs"


class ArchitectureParseError(ArchitectureLoadError):
    """Raised when architecture input cannot be parsed into governed models."""

    error_code = "parse_error"
