"""Tests for SSE event models and parsing."""

import json

import pytest

from waveium.models.events import (
    ErrorEvent,
    ExecutionProgress,
    StatusEvent,
    TimeoutEvent,
    parse_server_event,
)


class TestParseServerEvent:
    """Tests for parse_server_event."""

    def test_status_event_basic(self) -> None:
        data = json.dumps(
            {
                "execution_id": "exe_123",
                "status": "running",
                "started_at": "2026-01-01T00:00:00Z",
                "completed_at": None,
                "error_message": None,
            }
        )
        event = parse_server_event("status", data)
        assert isinstance(event, StatusEvent)
        assert event.event_type == "status"
        assert event.resource_id == "exe_123"
        assert event.status == "running"
        assert event.progress is None

    def test_status_event_with_progress(self) -> None:
        data = json.dumps(
            {
                "execution_id": "exe_456",
                "status": "running",
                "progress": {
                    "overall_percent": "40.0%",
                    "overall_waypoints": "4586/11466",
                    "entities_completed": "0/1",
                    "entity": "ue_0",
                    "entity_progress": "40%",
                    "entity_waypoint": "4587/11467",
                },
            }
        )
        event = parse_server_event("status", data)
        assert isinstance(event, StatusEvent)
        assert event.progress is not None
        assert isinstance(event.progress, ExecutionProgress)
        assert event.progress.overall_percent == "40.0%"
        assert event.progress.overall_waypoints == "4586/11466"
        assert event.progress.entities_completed == "0/1"
        assert event.progress.entity == "ue_0"

    def test_status_event_environment(self) -> None:
        data = json.dumps(
            {
                "environment_id": "env_789",
                "status": "completed",
            }
        )
        event = parse_server_event("status", data)
        assert isinstance(event, StatusEvent)
        assert event.resource_id == "env_789"
        assert event.status == "completed"

    def test_status_event_scene(self) -> None:
        data = json.dumps(
            {
                "scene_id": "scn_abc",
                "status": "queued",
            }
        )
        event = parse_server_event("status", data)
        assert isinstance(event, StatusEvent)
        assert event.resource_id == "scn_abc"

    def test_timeout_event(self) -> None:
        data = json.dumps({"message": "Connection timeout"})
        event = parse_server_event("timeout", data)
        assert isinstance(event, TimeoutEvent)
        assert event.event_type == "timeout"
        assert event.message == "Connection timeout"

    def test_timeout_event_no_message(self) -> None:
        event = parse_server_event("timeout", "{}")
        assert isinstance(event, TimeoutEvent)
        assert event.message is None

    def test_error_event(self) -> None:
        data = json.dumps(
            {
                "message": "Not found",
                "code": "resource_not_found",
            }
        )
        event = parse_server_event("error", data)
        assert isinstance(event, ErrorEvent)
        assert event.event_type == "error"
        assert event.message == "Not found"
        assert event.code == "resource_not_found"

    def test_error_event_no_code(self) -> None:
        data = json.dumps({"message": "Something broke"})
        event = parse_server_event("error", data)
        assert isinstance(event, ErrorEvent)
        assert event.code is None

    def test_unknown_event_type_raises(self) -> None:
        with pytest.raises(ValueError, match="Unknown SSE event type"):
            parse_server_event("unknown", "{}")

    def test_invalid_json_raises(self) -> None:
        with pytest.raises(ValueError, match="Invalid SSE event data"):
            parse_server_event("status", "not json")

    def test_status_completed_with_error_message(self) -> None:
        data = json.dumps(
            {
                "execution_id": "exe_fail",
                "status": "failed",
                "error_message": "Out of memory",
            }
        )
        event = parse_server_event("status", data)
        assert isinstance(event, StatusEvent)
        assert event.status == "failed"
        assert event.error_message == "Out of memory"

    def test_progress_with_partial_fields(self) -> None:
        data = json.dumps(
            {
                "execution_id": "exe_p",
                "status": "running",
                "progress": {
                    "overall_percent": "10%",
                },
            }
        )
        event = parse_server_event("status", data)
        assert isinstance(event, StatusEvent)
        assert event.progress is not None
        assert event.progress.overall_percent == "10%"
        assert event.progress.overall_waypoints is None
        assert event.progress.entity is None
