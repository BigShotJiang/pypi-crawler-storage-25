"""Tests for the SSE line parser."""

from waveium._sse import RawSSEEvent, _parse_sse_lines


def _parse(text: str) -> list[RawSSEEvent]:
    """Helper: parse a multiline SSE text block."""
    lines = text.split("\n")
    return list(_parse_sse_lines(iter(lines)))


class TestSSEParser:
    """Tests for _parse_sse_lines."""

    def test_simple_event(self) -> None:
        events = _parse("data: hello\n\n")
        assert len(events) == 1
        assert events[0].event == "message"
        assert events[0].data == "hello"

    def test_named_event(self) -> None:
        events = _parse("event: status\ndata: {}\n\n")
        assert len(events) == 1
        assert events[0].event == "status"
        assert events[0].data == "{}"

    def test_multiline_data(self) -> None:
        events = _parse("data: line1\ndata: line2\ndata: line3\n\n")
        assert len(events) == 1
        assert events[0].data == "line1\nline2\nline3"

    def test_event_id(self) -> None:
        events = _parse("id: 42\ndata: test\n\n")
        assert len(events) == 1
        assert events[0].id == "42"

    def test_retry_field(self) -> None:
        events = _parse("retry: 5000\ndata: test\n\n")
        assert len(events) == 1
        assert events[0].retry == 5000

    def test_retry_non_numeric_ignored(self) -> None:
        events = _parse("retry: abc\ndata: test\n\n")
        assert len(events) == 1
        assert events[0].retry is None

    def test_comment_ignored(self) -> None:
        events = _parse(": keepalive\ndata: hello\n\n")
        assert len(events) == 1
        assert events[0].data == "hello"

    def test_comment_only_no_event(self) -> None:
        events = _parse(": keepalive\n\n")
        assert len(events) == 0

    def test_multiple_events(self) -> None:
        text = "data: first\n\ndata: second\n\n"
        events = _parse(text)
        assert len(events) == 2
        assert events[0].data == "first"
        assert events[1].data == "second"

    def test_empty_data_field(self) -> None:
        events = _parse("data:\n\n")
        assert len(events) == 1
        assert events[0].data == ""

    def test_no_colon_field(self) -> None:
        # "data" alone with no colon means field="data", value=""
        events = _parse("data\n\n")
        assert len(events) == 1
        assert events[0].data == ""

    def test_leading_space_stripped(self) -> None:
        # Per spec, one leading space after colon is stripped
        events = _parse("data:  two spaces\n\n")
        assert len(events) == 1
        assert events[0].data == " two spaces"

    def test_unknown_field_ignored(self) -> None:
        events = _parse("foo: bar\ndata: test\n\n")
        assert len(events) == 1
        assert events[0].data == "test"

    def test_empty_lines_between_events(self) -> None:
        # Multiple empty lines should not produce extra events
        events = _parse("data: a\n\n\n\ndata: b\n\n")
        assert len(events) == 2

    def test_event_type_resets_between_events(self) -> None:
        text = "event: status\ndata: first\n\ndata: second\n\n"
        events = _parse(text)
        assert events[0].event == "status"
        assert events[1].event == "message"  # reset to default

    def test_timeout_event(self) -> None:
        text = 'event: timeout\ndata: {"message":"timeout"}\n\n'
        events = _parse(text)
        assert len(events) == 1
        assert events[0].event == "timeout"

    def test_no_trailing_newline(self) -> None:
        # Stream that ends without a final empty line
        events = _parse("data: incomplete")
        assert len(events) == 0  # not dispatched without empty line

    def test_carriage_return_stripped(self) -> None:
        events = _parse("data: hello\r\n\r\n")
        assert len(events) == 1
        assert events[0].data == "hello"
