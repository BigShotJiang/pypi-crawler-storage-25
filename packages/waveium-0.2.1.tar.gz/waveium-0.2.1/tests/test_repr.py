"""Tests for clean repr output on response models."""

from datetime import datetime, timezone

from waveium.models.common import _fmt_dt, _tabulate
from waveium.models.executions import (
    ExecutionListItem,
    PaginatedExecutionResponse,
)
from waveium.models.environments import (
    EnvironmentListItem,
    PaginatedEnvironmentResponse,
)
from waveium.models.files import (
    ExecutionFilesResponse,
    EnvironmentFilesResponse,
    FileInfo,
    SceneFilesResponse,
    _fmt_size,
)
from waveium.models.scenes import (
    PaginatedSceneResponse,
    SceneListItem,
)


class TestFmtSize:
    """Tests for _fmt_size helper."""

    def test_bytes(self) -> None:
        assert _fmt_size(0) == "0 B"
        assert _fmt_size(512) == "512 B"
        assert _fmt_size(1023) == "1023 B"

    def test_kilobytes(self) -> None:
        assert _fmt_size(1024) == "1.0 KB"
        assert _fmt_size(1536) == "1.5 KB"

    def test_megabytes(self) -> None:
        assert _fmt_size(1048576) == "1.0 MB"
        assert _fmt_size(194024967) == "185.0 MB"

    def test_gigabytes(self) -> None:
        assert _fmt_size(1073741824) == "1.00 GB"
        assert _fmt_size(2684354560) == "2.50 GB"


class TestFmtDt:
    """Tests for _fmt_dt helper."""

    def test_none(self) -> None:
        assert _fmt_dt(None) == "-"

    def test_datetime(self) -> None:
        dt = datetime(2026, 4, 5, 16, 18, tzinfo=timezone.utc)
        assert _fmt_dt(dt) == "2026-04-05 16:18"


class TestTabulate:
    """Tests for _tabulate helper."""

    def test_empty_rows(self) -> None:
        result = _tabulate(("A", "B"), [])
        lines = result.strip().split("\n")
        assert len(lines) == 2  # header + separator

    def test_alignment(self) -> None:
        result = _tabulate(
            ("Name", "Value"),
            [("short", "1"), ("much longer name", "22")],
        )
        lines = result.split("\n")
        assert len(lines) == 4  # header + separator + 2 rows
        # All lines should have consistent column positions
        assert "Name" in lines[0]
        assert "----" in lines[1]


class TestPaginatedExecutionRepr:
    """Tests for PaginatedExecutionResponse.__repr__."""

    def test_empty(self) -> None:
        resp = PaginatedExecutionResponse(
            executions=[], total=0, limit=50, offset=0
        )
        r = repr(resp)
        assert "0 executions" in r
        assert "page 1/" in r

    def test_with_items(self) -> None:
        resp = PaginatedExecutionResponse(
            executions=[
                ExecutionListItem(
                    execution_id="exe_abc",
                    scene_id="scn_xyz",
                    name="Test Run",
                    execution_number=1,
                    status="completed",
                    created_at=datetime(
                        2026, 4, 5, 12, 0, tzinfo=timezone.utc
                    ),
                )
            ],
            total=1,
            limit=50,
            offset=0,
        )
        r = repr(resp)
        assert "1 executions" in r
        assert "exe_abc" in r
        assert "completed" in r
        assert "Test Run" in r
        assert "scn_xyz" in r

    def test_pagination(self) -> None:
        resp = PaginatedExecutionResponse(
            executions=[], total=100, limit=10, offset=20
        )
        r = repr(resp)
        assert "page 3/10" in r

    def test_unnamed_shows_dash(self) -> None:
        resp = PaginatedExecutionResponse(
            executions=[
                ExecutionListItem(
                    execution_id="exe_1",
                    scene_id="scn_1",
                    name=None,
                    execution_number=1,
                    status="running",
                    created_at=datetime(
                        2026, 1, 1, tzinfo=timezone.utc
                    ),
                )
            ],
            total=1,
            limit=50,
            offset=0,
        )
        r = repr(resp)
        # Name column should show "-" for None
        lines = r.split("\n")
        data_line = lines[-1]
        assert "-" in data_line


class TestPaginatedEnvironmentRepr:
    """Tests for PaginatedEnvironmentResponse.__repr__."""

    def test_with_items(self) -> None:
        resp = PaginatedEnvironmentResponse(
            environments=[
                EnvironmentListItem(
                    environment_id="env_test",
                    name="My Env",
                    environment_type="underground",
                    status="completed",
                    created_at=datetime(
                        2026, 3, 1, tzinfo=timezone.utc
                    ),
                    scene_count=3,
                )
            ],
            total=1,
            limit=50,
            offset=0,
        )
        r = repr(resp)
        assert "1 environments" in r
        assert "env_test" in r
        assert "underground" in r
        assert "3" in r


class TestPaginatedSceneRepr:
    """Tests for PaginatedSceneResponse.__repr__."""

    def test_with_items(self) -> None:
        resp = PaginatedSceneResponse(
            scenes=[
                SceneListItem(
                    scene_id="scn_test",
                    environment_id="env_parent",
                    name="My Scene",
                    status="completed",
                    created_at=datetime(
                        2026, 2, 1, tzinfo=timezone.utc
                    ),
                    execution_count=5,
                )
            ],
            total=1,
            limit=50,
            offset=0,
        )
        r = repr(resp)
        assert "1 scenes" in r
        assert "scn_test" in r
        assert "env_parent" in r
        assert "5" in r


class TestFilesResponseRepr:
    """Tests for file response __repr__ methods."""

    def _make_files(self) -> list[FileInfo]:
        return [
            FileInfo(
                file_id="abc",
                filename="data.parquet",
                subdir="results",
                file_size_bytes=194024967,
            ),
            FileInfo(
                file_id="def",
                filename="meta.json",
                subdir="results",
                file_size_bytes=468,
            ),
        ]

    def test_execution_files(self) -> None:
        resp = ExecutionFilesResponse(
            execution_id="exe_test",
            total_files=2,
            total_size_bytes=194025435,
            files=self._make_files(),
        )
        r = repr(resp)
        assert "2 files" in r
        assert "exe_test" in r
        assert "data.parquet" in r
        assert "185.0 MB" in r
        assert "468 B" in r

    def test_environment_files(self) -> None:
        resp = EnvironmentFilesResponse(
            environment_id="env_test",
            total_files=1,
            total_size_bytes=1024,
            files=[self._make_files()[1]],
        )
        r = repr(resp)
        assert "env_test" in r
        assert "1 files" in r

    def test_scene_files(self) -> None:
        resp = SceneFilesResponse(
            scene_id="scn_test",
            total_files=1,
            total_size_bytes=1024,
            files=[self._make_files()[0]],
        )
        r = repr(resp)
        assert "scn_test" in r

    def test_empty_files(self) -> None:
        resp = ExecutionFilesResponse(
            execution_id="exe_empty",
            total_files=0,
            total_size_bytes=0,
            files=[],
        )
        r = repr(resp)
        assert "0 files" in r
        assert "0 B" in r
        # Should not have a table header
        assert "Filename" not in r
