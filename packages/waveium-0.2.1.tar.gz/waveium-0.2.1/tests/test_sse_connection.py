"""Tests for SSE connection reconnection logic."""

import json
from contextlib import contextmanager
from typing import Generator, Iterator, List
from unittest.mock import MagicMock

import httpx
import pytest

from waveium._sse import (
    RawSSEEvent,
    SSEConnection,
)
from waveium.exceptions import (
    StreamReconnectError,
    StreamTimeoutError,
)


def _make_sse_response(
    lines: list[str],
    status_code: int = 200,
) -> MagicMock:
    """Create a mock response that yields SSE lines.

    Lines containing \\n are split into individual lines,
    matching httpx iter_lines() behavior.
    """
    response = MagicMock()
    response.status_code = status_code

    # Split multi-line strings into individual lines
    expanded: list[str] = []
    for line in lines:
        expanded.extend(line.split("\n"))

    response.iter_lines = MagicMock(return_value=iter(expanded))
    response.read = MagicMock()
    return response


def _make_client(
    responses: list[MagicMock],
) -> MagicMock:
    """Create a mock httpx.Client whose stream() returns
    successive context-managed responses."""
    client = MagicMock(spec=httpx.Client)
    call_idx = 0

    @contextmanager
    def stream_cm(
        *args: object, **kwargs: object
    ) -> Generator[MagicMock, None, None]:
        nonlocal call_idx
        idx = min(call_idx, len(responses) - 1)
        call_idx += 1
        yield responses[idx]

    client.stream = MagicMock(side_effect=stream_cm)
    return client


class TestSSEConnectionReconnect:
    """Tests for SSEConnection reconnection behavior."""

    def test_timeout_event_triggers_reconnect(self) -> None:
        """Server timeout event should cause immediate reconnect.

        SSEConnection yields raw events and reconnects on
        timeout/stream-end. The caller (StreamOperations) is
        responsible for stopping on terminal statuses. Here we
        manually close after receiving the expected events.
        """
        status_data = json.dumps(
            {"execution_id": "exe_1", "status": "running"}
        )
        timeout_data = json.dumps({"message": "timeout"})
        completed_data = json.dumps(
            {"execution_id": "exe_1", "status": "completed"}
        )

        resp1 = _make_sse_response(
            [
                f"event: status\ndata: {status_data}\n",
                "",
                f"event: timeout\ndata: {timeout_data}\n",
                "",
            ]
        )
        resp2 = _make_sse_response(
            [
                f"event: status\ndata: {completed_data}\n",
                "",
            ]
        )

        client = _make_client([resp1, resp2])
        conn = SSEConnection(
            client=client,
            url="/v0/executions/exe_1",
            headers={},
            max_reconnects=5,
            max_total_seconds=60,
        )

        events = []
        for event in conn:
            events.append(event)
            # Stop after receiving 2 status events
            # (simulating what StreamOperations.wait does)
            if len(events) == 2:
                conn.close()
                break

        assert len(events) == 2
        assert events[0].event == "status"
        assert events[1].event == "status"
        assert client.stream.call_count == 2

    def test_max_reconnects_exceeded(self) -> None:
        """Should raise StreamReconnectError after max reconnects."""
        client = MagicMock(spec=httpx.Client)
        client.stream.side_effect = httpx.RequestError(
            "Connection refused"
        )

        conn = SSEConnection(
            client=client,
            url="/test",
            headers={},
            max_reconnects=2,
            max_total_seconds=300,
            initial_retry_ms=1,
            max_retry_ms=1,
        )

        with pytest.raises(StreamReconnectError):
            list(conn)

    def test_max_total_seconds_exceeded(self) -> None:
        """Should raise StreamTimeoutError when time limit exceeded."""
        client = MagicMock(spec=httpx.Client)
        client.stream.side_effect = httpx.RequestError("timeout")

        conn = SSEConnection(
            client=client,
            url="/test",
            headers={},
            max_reconnects=1000,
            max_total_seconds=0.001,
            initial_retry_ms=1,
            max_retry_ms=1,
        )

        with pytest.raises(
            (StreamTimeoutError, StreamReconnectError)
        ):
            list(conn)

    def test_close_stops_iteration(self) -> None:
        """Calling close() should stop the event iteration."""
        status_data = json.dumps(
            {"execution_id": "exe_1", "status": "running"}
        )

        # Create a response with many events
        lines: list[str] = []
        for _ in range(100):
            lines.append(f"event: status\ndata: {status_data}\n")
            lines.append("")

        resp = _make_sse_response(lines)
        client = _make_client([resp])

        conn = SSEConnection(
            client=client,
            url="/test",
            headers={},
        )

        events = []
        for event in conn:
            events.append(event)
            if len(events) == 3:
                conn.close()
                break

        assert len(events) == 3

    def test_context_manager(self) -> None:
        """SSEConnection should work as a context manager."""
        client = MagicMock(spec=httpx.Client)
        client.stream.side_effect = httpx.RequestError("err")

        conn = SSEConnection(
            client=client,
            url="/test",
            headers={},
            max_reconnects=0,
        )

        with conn:
            try:
                list(conn)
            except StreamReconnectError:
                pass

        assert conn._closed


class TestSSEConnectionLastEventId:
    """Tests for Last-Event-ID header on reconnect."""

    def test_last_event_id_sent_on_reconnect(self) -> None:
        """Should send Last-Event-ID when reconnecting."""
        timeout_data = json.dumps({"message": "timeout"})
        status_data = json.dumps(
            {"execution_id": "exe_1", "status": "completed"}
        )

        headers_seen: List[dict[str, str]] = []
        call_idx = 0

        @contextmanager
        def stream_cm(
            *args: object, **kwargs: object
        ) -> Generator[MagicMock, None, None]:
            nonlocal call_idx
            call_idx += 1
            # Capture headers from kwargs
            hdrs = kwargs.get("headers", {})
            headers_seen.append(dict(hdrs))  # type: ignore[arg-type]

            if call_idx == 1:
                yield _make_sse_response(
                    [
                        f"id: evt_42\nevent: timeout\n"
                        f"data: {timeout_data}\n",
                        "",
                    ]
                )
            else:
                yield _make_sse_response(
                    [
                        f"event: status\ndata: {status_data}\n",
                        "",
                    ]
                )

        client = MagicMock(spec=httpx.Client)
        client.stream = MagicMock(side_effect=stream_cm)

        conn = SSEConnection(
            client=client,
            url="/test",
            headers={"X-API-Key": "wvx_test"},
            max_reconnects=5,
        )

        events = []
        for event in conn:
            events.append(event)
            if len(events) == 1:
                conn.close()
                break

        # First call should not have Last-Event-ID
        assert "Last-Event-ID" not in headers_seen[0]
        # Second call should have it
        assert headers_seen[1].get("Last-Event-ID") == "evt_42"
