"""Tests for SDK exception classes."""

from waveium.exceptions import (
    AuthenticationError,
    ConfigurationError,
    ExecutionFailedError,
    StreamError,
    StreamReconnectError,
    StreamTimeoutError,
    WaveiumError,
)


class TestExceptionHierarchy:
    """Tests for exception inheritance."""

    def test_stream_errors_inherit_from_waveium_error(self) -> None:
        assert issubclass(StreamError, WaveiumError)
        assert issubclass(StreamTimeoutError, StreamError)
        assert issubclass(StreamReconnectError, StreamError)

    def test_execution_failed_inherits_from_waveium_error(self) -> None:
        assert issubclass(ExecutionFailedError, WaveiumError)

    def test_stream_timeout_catchable_as_stream_error(self) -> None:
        try:
            raise StreamTimeoutError("timed out")
        except StreamError as e:
            assert "timed out" in str(e)

    def test_all_catchable_as_waveium_error(self) -> None:
        for exc_cls in (
            StreamTimeoutError,
            StreamReconnectError,
            AuthenticationError,
            ConfigurationError,
        ):
            try:
                raise exc_cls("test")
            except WaveiumError:
                pass  # expected

        # ExecutionFailedError needs execution_id
        try:
            raise ExecutionFailedError("test", execution_id="exe_1")
        except WaveiumError:
            pass  # expected


class TestExecutionFailedError:
    """Tests for ExecutionFailedError."""

    def test_stores_execution_id(self) -> None:
        err = ExecutionFailedError(
            message="failed",
            execution_id="exe_123",
            error_message="Out of memory",
        )
        assert err.execution_id == "exe_123"
        assert err.error_message == "Out of memory"
        assert err.message == "failed"

    def test_str_includes_code(self) -> None:
        err = ExecutionFailedError(
            message="failed",
            execution_id="exe_1",
            code="EXEC_FAILED",
        )
        assert "[EXEC_FAILED]" in str(err)

    def test_str_without_code(self) -> None:
        err = ExecutionFailedError(
            message="it broke",
            execution_id="exe_1",
        )
        assert str(err) == "it broke"
