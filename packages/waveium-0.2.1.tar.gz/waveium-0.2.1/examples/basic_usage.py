"""Basic usage example for Waveium SDK.

Demonstrates the Environment -> Scene -> Execution workflow.
"""

import waveium


def main() -> None:
    """Demonstrate basic Waveium SDK usage."""
    client = waveium.init(api_key="wvx_your_api_key_here")

    try:
        # 1. Create an environment (outdoor, route-based)
        print("Creating environment...")
        env_resp = client.environments.create(
            name="Stockholm Route",
            environment_type="outdoor",
            route={
                "start": "Stockholm Central Station",
                "end": "Gamla Stan",
                "area": "Stockholm, Sweden",
                "transport_mode": "walk",
            },
            stations={
                "BS1": [59.3293, 18.0686, 25.0],
                "BS2": [59.3251, 18.0711, 30.0],
            },
        )
        env = env_resp.environment
        print(f"Environment: {env.environment_id}")
        print(f"Status: {env.status}")
        print(f"Reused: {env_resp.reused}")

        # 2. List environments
        envs = client.environments.list(scope="mine")
        print(f"\nTotal environments: {envs.total}")

        # 3. Create a scene (if not auto-created)
        print("\nCreating scene...")
        scene = client.scenes.create(
            environment_id=env.environment_id,
            name="Default Scene",
            parameters={
                "stations": {
                    "BS1": [59.3293, 18.0686, 25.0],
                },
            },
        )
        print(f"Scene: {scene.scene_id}")
        print(f"Status: {scene.status}")

        # 4. Queue scene for generation
        scene = client.scenes.generate(scene.scene_id)
        print(f"Scene queued: {scene.status}")

        # 5. Create an execution on completed scene
        execution = client.scenes.create_execution(
            scene_id=scene.scene_id,
            name="Default Execution",
        )
        print(f"\nExecution: {execution.execution_id}")
        print(f"Status: {execution.status}")

        # 6. Check execution progress
        progress = client.executions.progress(
            execution.execution_id
        )
        print(f"Progress: {progress.status}")

        # 7. List tokens
        tokens = client.auth.list_tokens()
        print(f"\nAPI tokens: {len(tokens.tokens)}")

    except waveium.AuthenticationError as e:
        print(f"Authentication failed: {e}")
    except waveium.ConflictError as e:
        print(f"State conflict: {e}")
    except waveium.WaveiumError as e:
        print(f"Waveium error: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    main()
