"""Upload and download example for Waveium SDK.

Demonstrates scene file upload and execution result download.
"""

from pathlib import Path

import waveium


def main() -> None:
    """Demonstrate file upload and download workflow."""
    client = waveium.init(api_key="wvx_your_api_key_here")

    try:
        # Assume we have a completed environment
        env_id = "env_your_environment_id"

        # 1. Create a scene for file upload
        print("Creating scene...")
        scene = client.scenes.create(
            environment_id=env_id,
            name="Upload Example Scene",
            parameters={
                "stations": {
                    "BS1": [59.3293, 18.0686, 25.0],
                },
            },
        )
        print(f"Scene: {scene.scene_id}")

        # 2. Upload a trajectory file to the scene
        trajectory_file = Path("trajectory.gpx")
        if trajectory_file.exists():
            print(f"\nUploading {trajectory_file}...")
            result = client.scenes.upload(
                scene_id=scene.scene_id,
                file_path=trajectory_file,
                content_type="application/gpx+xml",
                purpose="trajectory",
            )
            print(f"Upload complete: {result.file_id}")
            print(f"Missing inputs: {result.missing_inputs}")

        # 3. Upload station positions CSV
        stations_file = Path("stations.csv")
        if stations_file.exists():
            print(f"\nUploading {stations_file}...")
            result = client.scenes.upload(
                scene_id=scene.scene_id,
                file_path=stations_file,
                content_type="text/csv",
                purpose="stations",
            )
            print(f"Upload complete: {result.file_id}")

        # 4. Queue scene for generation
        scene = client.scenes.generate(scene.scene_id)
        print(f"\nScene queued: {scene.status}")

        # 5. Download execution results (assuming
        #    completed execution exists)
        exec_id = "exec_your_execution_id"

        # List result files
        files = client.executions.list_files(
            exec_id, subdir="results"
        )
        print(f"\nResult files: {files.total_files}")
        for f in files.files:
            print(f"  {f.filename} ({f.file_size_bytes}b)")

        # Download individual file
        if files.files:
            dest = Path("./results") / files.files[0].filename
            client.executions.download(
                exec_id, files.files[0].file_id, dest
            )
            print(f"Downloaded: {dest}")

        # Batch download all results
        batch = client.executions.download_batch(
            exec_id,
            destination_dir="./results",
            subdir="results",
        )
        print(f"Batch downloaded {batch.total_files} files")

        # Download as zip archive
        archive = client.executions.download_archive(
            exec_id, subdir="results"
        )
        print(f"Archive URL: {archive.download_url}")
        print(f"Archive size: {archive.size} bytes")

    except waveium.FileUploadError as e:
        print(f"Upload failed: {e}")
    except waveium.FileDownloadError as e:
        print(f"Download failed: {e}")
    except waveium.ConflictError as e:
        print(f"State conflict: {e}")
    except waveium.WaveiumError as e:
        print(f"Waveium error: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    main()
