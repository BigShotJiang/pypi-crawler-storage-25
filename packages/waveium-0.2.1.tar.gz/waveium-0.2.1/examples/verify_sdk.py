#!/usr/bin/env python3
"""Quick verification script for Waveium SDK.

Usage:
    export WAVEIUM_SDK_TOKEN=wv_your_api_key_here
    python3 verify_sdk.py
"""

import os
import sys

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import waveium  # noqa: E402


def verify() -> bool:
    """Verify SDK is working correctly."""
    print("Waveium SDK Verification")
    print("=" * 60)
    print(f"Version: {waveium.__version__}")

    # Get API key from environment
    api_key = os.getenv("WAVEIUM_SDK_TOKEN") or os.getenv("WAVEIUM_API_KEY")
    if api_key:
        print("API key loaded from environment.\n")
    else:
        print("ERROR: No API key provided")
        print("  Set WAVEIUM_SDK_TOKEN or WAVEIUM_API_KEY")
        return False

    try:
        # Initialize client
        print("Initializing SDK...")
        client = waveium.init(api_key=api_key)
        print(f"  Base URL: {client._config.base_url}")
        print("  Status: OK\n")

        # Get current user
        print("Getting current user...")
        user = client.users.me()
        print(f"  User ID: {user.id}")
        print(f"  Email: {user.email}")
        print(f"  Org: {user.organization_id}")
        print("  Status: OK\n")

        # List environments
        print("Listing environments...")
        envs = client.environments.list(limit=5)
        print(f"  Total: {envs.total}")
        for e in envs.environments:
            print(f"  - {e.name} ({e.status})")
        print("  Status: OK\n")

        client.close()

        print("=" * 60)
        print("SUCCESS! Waveium SDK is working correctly.")
        print("=" * 60)
        return True

    except waveium.AuthenticationError as e:
        print(f"\nERROR: Authentication failed - {e.message}")
        return False
    except waveium.WaveiumError as e:
        print(f"\nERROR: {type(e).__name__} - {e.message}")
        return False
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        import traceback

        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = verify()
    sys.exit(0 if success else 1)
