"""Async usage example for Waveium SDK."""

import asyncio

import waveium


async def main() -> None:
    """Demonstrate async Waveium SDK usage."""
    async with waveium.AsyncClient(
        api_key="wvx_your_api_key_here"
    ) as client:
        try:
            # Create an environment
            print("Creating environment...")
            env_resp = await client.environments.create(
                name="Async Example Environment",
                environment_type="outdoor",
                route={
                    "start": "Tokyo Station",
                    "end": "Shibuya Station",
                    "area": "Tokyo, Japan",
                },
            )
            env = env_resp.environment
            print(f"Environment: {env.environment_id}")
            print(f"Status: {env.status}")

            # List environments
            envs = await client.environments.list()
            print(f"\nTotal environments: {envs.total}")

            # List tokens
            tokens = await client.auth.list_tokens()
            print(f"API tokens: {len(tokens.tokens)}")

        except waveium.AuthenticationError as e:
            print(f"Authentication failed: {e}")
        except waveium.WaveiumError as e:
            print(f"Waveium error: {e}")


if __name__ == "__main__":
    asyncio.run(main())
