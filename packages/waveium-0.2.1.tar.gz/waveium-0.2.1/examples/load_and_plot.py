'''
# environn-memory analysis (no disk)
df = client.executions.read_parquet("exe_xxx", structured=True)

# Local copy (auto-discovers parquet, same as read_parquet)
path = client.executions.download_parquet("exe_xxx", "./results/")
# path -> Path("./results/simulation_data.parquet")

# Both, one download, 'import pandas as pd'
path = client.executions.download_parquet("exe_xxx", "./results/")
df = pd.read_parquet(path)
'''

import waveium

import os
import numpy as np
import matplotlib.pyplot as plt

EXEC_ID = os.environ.get("WAVEIUM_EXEC_ID", "exe_your_execution_id")

client = waveium.init(api_key=os.environ["WAVEIUM_API_TOKEN"])
df = client.executions.read_parquet(EXEC_ID, structured=True)

positions = np.stack(df["entity_UE:ue_0"].values)
power = df["ue_0-AP_1"].apply(lambda h: 20*np.log10(np.sum(np.abs(h)**2)))

plt.figure()
plt.plot(power)

fig = plt.figure()
ax = fig.add_subplot(111, projection="3d")
ax.plot(positions[:, 0], positions[:, 1], positions[:, 2])
ax.set_xlabel("X")
ax.set_ylabel("Y")
ax.set_zlabel("Z")

plt.show()  



n = 512
window = np.hanning(n)

cir = df["ue_0-AP_1"].apply(np.fft.ifft)
# cir_mag = df["ue_0-AP_1"].apply(lambda h: np.abs(np.fft.ifft(h)))
cir_mag = df["ue_0-AP_1"].apply(lambda h: np.abs(np.fft.ifft(h * window))[:n // 2])
cir_matrix = np.stack(cir_mag.values)
cir_db = 20 * np.log10(cir_matrix + 1e-30)  # avoid log(0)  

fig, ax = plt.subplots()
im = ax.pcolormesh(
      cir_db.T,
      shading="auto",
      cmap="viridis",
)
ax.set_xlabel("Time step")
ax.set_ylabel("Delay tap")
fig.colorbar(im, label="dB")
plt.show()
