#!/usr/bin/env python3
"""Complete underground workflow using SSE streaming.

This is the SSE-powered version of underground_workflow.py. Instead of
polling loops, it uses the SDK's built-in SSE streaming to wait for
long-running operations with real-time progress reporting.

Demonstrates the full Environment -> Scene -> Execution pipeline
for an underground scenario using local data files:

  - nodegraphWithNeighbors.json: tunnel/corridor graph for 3D
    environment generation
  - UsedRBS.csv: access point / RBS positions
  - UE.csv: user equipment trajectory

Usage:
    export WAVEIUM_API_TOKEN="wvx_..."
    python3 underground_workflow_sse.py
"""

import os
import sys
from datetime import datetime, timezone
from pathlib import Path

# Add src to path for local development
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import waveium  # noqa: E402

# Data directory relative to this script
DATA_DIR = Path(__file__).parent / "data" / "underground"

# Maximum time to wait for each stage (seconds)
ENV_TIMEOUT = 600  # 10 minutes for environment generation
SCENE_TIMEOUT = 600  # 10 minutes for scene generation
EXEC_TIMEOUT = 3600  # 1 hour for execution


def on_environment_event(event: waveium.ServerEvent) -> None:
    """Report environment generation progress."""
    if isinstance(event, waveium.StatusEvent):
        print(f"  Environment [{event.status}]")


def on_scene_event(event: waveium.ServerEvent) -> None:
    """Report scene generation progress."""
    if isinstance(event, waveium.StatusEvent):
        print(f"  Scene [{event.status}]")


def on_execution_event(event: waveium.ServerEvent) -> None:
    """Report execution progress with detail."""
    if isinstance(event, waveium.StatusEvent):
        msg = f"  Execution [{event.status}]"
        if event.progress:
            if event.progress.overall_percent:
                msg += f" {event.progress.overall_percent}"
            if event.progress.overall_waypoints:
                msg += f" (waypoints: {event.progress.overall_waypoints})"
            if event.progress.entities_completed:
                msg += f" entities: {event.progress.entities_completed}"
        print(msg)


def main() -> None:
    """Run the complete underground workflow with SSE streaming."""
    print("Waveium Underground Workflow (SSE)")
    print("=" * 60)

    # Validate data files exist
    nodegraph_file = DATA_DIR / "nodegraphWithNeighbors.json"
    rbs_file = DATA_DIR / "UsedRBS.csv"
    ue_file = DATA_DIR / "UE.csv"

    for data_file in [nodegraph_file, rbs_file, ue_file]:
        if not data_file.exists():
            print(f"ERROR: Missing data file: {data_file}")
            sys.exit(1)

    # Initialize client
    api_token = os.getenv("WAVEIUM_API_TOKEN")
    if not api_token:
        print("ERROR: Set WAVEIUM_API_TOKEN environment variable")
        sys.exit(1)

    client = waveium.init(
        api_key=api_token,
    )
    print(f"Base URL: {client._config.base_url}\n")

    # Timestamp suffix so each run creates fresh resources
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")

    try:
        # --------------------------------------------------
        # Step 1: Create the underground environment
        # --------------------------------------------------
        print("Step 1: Creating underground environment...")
        env_resp = client.environments.create(
            name=f"Underground Tunnel {ts}",
            environment_type="underground",
            description=(
                "Underground tunnel environment generated "
                "from nodegraph data"
            ),
        )
        env = env_resp.environment
        env_id = env.environment_id
        print(f"  Environment ID: {env_id}")
        print(f"  Status: {env.status}")
        print(f"  Reused: {env_resp.reused}\n")

        # --------------------------------------------------
        # Step 2: Upload nodegraph to the environment
        # --------------------------------------------------
        print("Step 2: Uploading nodegraph to environment...")
        upload_result = client.environments.upload(
            environment_id=env_id,
            file_path=nodegraph_file,
            content_type="application/json",
        )
        nodegraph_file_id = upload_result.file_id
        print(f"  File ID: {nodegraph_file_id}")
        print(f"  Message: {upload_result.message}\n")

        # --------------------------------------------------
        # Step 3: Update environment with nodegraph file ID
        #         to trigger generation
        # --------------------------------------------------
        print("Step 3: Updating environment with nodegraph file ID...")
        env = client.environments.update(
            environment_id=env_id,
            parameters={
                "nodegraph_file_id": nodegraph_file_id,
            },
        )
        print(f"  Status: {env.status}\n")

        # --------------------------------------------------
        # Step 4: Wait for environment generation (SSE)
        # --------------------------------------------------
        print("Step 4: Waiting for environment generation...")
        env = client.environments.wait(
            env_id,
            timeout=ENV_TIMEOUT,
            on_event=on_environment_event,
        )
        print("  Environment completed.\n")

        # --------------------------------------------------
        # Step 5: Create a scene with station parameters
        # --------------------------------------------------
        print("Step 5: Creating scene...")
        scene = client.scenes.create(
            environment_id=env_id,
            name=f"Underground Scene {ts}",
            parameters={},
            description=(
                "Scene with RBS station positions " "and UE trajectory"
            ),
        )
        scene_id = scene.scene_id
        print(f"  Scene ID: {scene_id}")
        print(f"  Status: {scene.status}\n")

        # --------------------------------------------------
        # Step 6: Upload RBS stations file to scene
        # --------------------------------------------------
        print("Step 6: Uploading RBS stations file...")
        rbs_upload = client.scenes.upload(
            scene_id=scene_id,
            file_path=rbs_file,
            content_type="text/csv",
            purpose="stations",
        )
        print(f"  File ID: {rbs_upload.file_id}")
        print(f"  Message: {rbs_upload.message}\n")

        # --------------------------------------------------
        # Step 7: Upload UE trajectory file to scene
        # --------------------------------------------------
        print("Step 7: Uploading UE trajectory file...")
        ue_upload = client.scenes.upload(
            scene_id=scene_id,
            file_path=ue_file,
            content_type="text/csv",
            purpose="trajectory",
        )
        print(f"  File ID: {ue_upload.file_id}")
        print(f"  Message: {ue_upload.message}\n")

        # --------------------------------------------------
        # Step 8: Trigger scene generation
        # --------------------------------------------------
        print("Step 8: Triggering scene generation...")
        scene = client.scenes.generate(scene_id)
        print(f"  Status: {scene.status}\n")

        # --------------------------------------------------
        # Step 9: Wait for scene generation (SSE)
        # --------------------------------------------------
        print("Step 9: Waiting for scene generation...")
        scene = client.scenes.wait(
            scene_id,
            timeout=SCENE_TIMEOUT,
            on_event=on_scene_event,
        )
        print("  Scene completed.\n")

        # --------------------------------------------------
        # Step 10: Create execution and wait (SSE)
        #
        # create_and_run() combines create_execution() +
        # wait() into a single call with real-time progress.
        # --------------------------------------------------
        print("Step 10: Creating and running execution...")
        execution = client.scenes.create_and_run(
            scene_id,
            execution_name=f"Underground Run {ts}",
            timeout=EXEC_TIMEOUT,
            on_event=on_execution_event,
        )
        exec_id = execution.execution_id
        print(f"  Execution ID: {exec_id}")
        print("  Execution completed.\n")

        # --------------------------------------------------
        # Step 11: List and download results
        # --------------------------------------------------
        print("Step 11: Downloading results...")
        results_dir = Path("./results/underground")
        results_dir.mkdir(parents=True, exist_ok=True)

        files = client.executions.list_files(exec_id, subdir="results")
        print(f"  Result files: {files.total_files}")
        for result_file in files.files:
            print(
                f"    - {result_file.filename}"
                f" ({result_file.file_size_bytes} bytes)"
            )

        if files.total_files > 0:
            batch = client.executions.download_batch(
                exec_id,
                destination_dir=results_dir,
                subdir="results",
            )
            print(
                f"  Downloaded {batch.total_files} files " f"to {results_dir}\n"
            )
        else:
            print("  No result files available.\n")

        # --------------------------------------------------
        # Summary
        # --------------------------------------------------
        print("=" * 60)
        print("WORKFLOW COMPLETE")
        print(f"  Environment: {env_id}")
        print(f"  Scene:       {scene_id}")
        print(f"  Execution:   {exec_id}")
        print(f"  Results:     {results_dir.resolve()}")
        print("=" * 60)

    except waveium.ExecutionFailedError as e:
        print(f"\nExecution failed: {e.error_message}")
        print(f"  Execution ID: {e.execution_id}")
        sys.exit(1)
    except waveium.StreamTimeoutError as e:
        print(f"\nTimed out: {e.message}")
        sys.exit(1)
    except waveium.AuthenticationError as e:
        print(f"\nAuthentication failed: {e.message}")
        sys.exit(1)
    except waveium.ConflictError as e:
        print(f"\nState conflict: {e.message}")
        sys.exit(1)
    except waveium.WaveiumError as e:
        print(f"\nWaveium error: {type(e).__name__} - {e.message}")
        sys.exit(1)
    finally:
        client.close()


if __name__ == "__main__":
    main()
