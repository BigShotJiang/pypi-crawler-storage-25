"""SSE streaming examples for the Waveium SDK.

Demonstrates four tiers of abstraction for monitoring
long-running simulations via Server-Sent Events.

Prerequisites:
    - A valid WAVEIUM_API_KEY environment variable
    - An existing completed scene to create executions from
"""

import waveium


def print_progress(event: waveium.ServerEvent) -> None:
    """Example on_event callback for progress reporting."""
    if isinstance(event, waveium.StatusEvent):
        msg = f"  [{event.status}]"
        if event.progress and event.progress.overall_percent:
            msg += f" {event.progress.overall_percent}"
            if event.progress.entities_completed:
                msg += (
                    f" | entities: {event.progress.entities_completed}"
                )
        print(msg)


def tier1_raw_stream(execution_id: str) -> None:
    """Tier 1: Raw event stream -- full control.

    Use this when you need to handle each event type
    individually or implement custom logic.
    """
    print("--- Tier 1: Raw Event Stream ---")
    client = waveium.init()

    with client.executions.stream(execution_id) as events:
        for event in events:
            if event.event_type == "status":
                assert isinstance(event, waveium.StatusEvent)
                print(f"Status: {event.status}")
                if event.progress:
                    print(f"  Progress: {event.progress.overall_percent}")
                    print(
                        f"  Waypoints: {event.progress.overall_waypoints}"
                    )
                if event.status in ("completed", "failed", "cancelled"):
                    break
            elif event.event_type == "error":
                print(f"Error: {event.message}")
                break

    client.close()


def tier2_blocking_wait(execution_id: str) -> None:
    """Tier 2: Blocking wait with progress callback.

    Use this when you want a simple "wait for it" with
    optional progress reporting. Returns the final
    ExecutionResponse.
    """
    print("--- Tier 2: Blocking Wait ---")
    client = waveium.init()

    try:
        result = client.executions.wait(
            execution_id,
            timeout=3600,
            on_event=print_progress,
        )
        print(f"Completed: {result.execution_id}")
        print(f"Status: {result.status}")
    except waveium.ExecutionFailedError as e:
        print(f"Execution failed: {e.error_message}")
    except waveium.StreamTimeoutError:
        print("Timed out waiting for execution")
    finally:
        client.close()


def tier3_create_and_run(scene_id: str) -> None:
    """Tier 3: Create-and-wait convenience.

    Use this for the most common workflow: create an
    execution and wait for it to complete in one call.
    """
    print("--- Tier 3: Create and Run ---")
    client = waveium.init()

    try:
        result = client.scenes.create_and_run(
            scene_id,
            execution_name="SDK Streaming Test",
            timeout=3600,
            on_event=print_progress,
        )
        print(f"Execution completed: {result.execution_id}")
        print(f"Status: {result.status}")

        # Download results
        files = client.executions.list_files(
            result.execution_id, subdir="results"
        )
        print(f"Result files: {files.total_files}")

    except waveium.ExecutionFailedError as e:
        print(f"Execution failed: {e.error_message}")
    except waveium.ConflictError:
        print("Scene is not in completed status")
    finally:
        client.close()


def environment_wait_example(environment_id: str) -> None:
    """Wait for an environment to finish generating."""
    print("--- Environment Wait ---")
    client = waveium.init()

    try:
        env = client.environments.wait(
            environment_id,
            timeout=600,
            on_event=print_progress,
        )
        print(f"Environment ready: {env.environment_id}")
        print(f"Status: {env.status}")
    except waveium.StreamTimeoutError:
        print("Environment generation timed out")
    finally:
        client.close()


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print(
            "Usage: python streaming_usage.py "
            "<tier> <resource_id>"
        )
        print("  tier: 1, 2, 3, or env")
        print("  resource_id: execution or scene ID")
        sys.exit(1)

    tier = sys.argv[1]
    resource_id = sys.argv[2]

    if tier == "1":
        tier1_raw_stream(resource_id)
    elif tier == "2":
        tier2_blocking_wait(resource_id)
    elif tier == "3":
        tier3_create_and_run(resource_id)
    elif tier == "env":
        environment_wait_example(resource_id)
    else:
        print(f"Unknown tier: {tier}")
        sys.exit(1)
