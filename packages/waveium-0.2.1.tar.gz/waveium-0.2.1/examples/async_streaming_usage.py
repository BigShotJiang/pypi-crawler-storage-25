"""Async SSE streaming examples for the Waveium SDK.

Demonstrates async counterparts of the streaming tiers.

Prerequisites:
    - A valid WAVEIUM_API_KEY environment variable
    - An existing completed scene to create executions from
"""

import asyncio

import waveium


def print_progress(event: waveium.ServerEvent) -> None:
    """Example on_event callback for progress reporting."""
    if isinstance(event, waveium.StatusEvent):
        msg = f"  [{event.status}]"
        if event.progress and event.progress.overall_percent:
            msg += f" {event.progress.overall_percent}"
        print(msg)


async def async_raw_stream(execution_id: str) -> None:
    """Async raw event stream."""
    print("--- Async Raw Stream ---")
    async with waveium.AsyncClient() as client:
        async with client.executions.stream(execution_id) as events:
            async for event in events:
                if event.event_type == "status":
                    assert isinstance(event, waveium.StatusEvent)
                    print(f"Status: {event.status}")
                    if event.progress:
                        print(
                            f"  Progress: "
                            f"{event.progress.overall_percent}"
                        )
                    if event.status in (
                        "completed",
                        "failed",
                        "cancelled",
                    ):
                        break


async def async_wait(execution_id: str) -> None:
    """Async blocking wait with progress."""
    print("--- Async Wait ---")
    async with waveium.AsyncClient() as client:
        try:
            result = await client.executions.wait(
                execution_id,
                timeout=3600,
                on_event=print_progress,
            )
            print(f"Completed: {result.execution_id}")
            print(f"Status: {result.status}")
        except waveium.ExecutionFailedError as e:
            print(f"Failed: {e.error_message}")
        except waveium.StreamTimeoutError:
            print("Timed out")


async def async_create_and_run(scene_id: str) -> None:
    """Async create-and-wait convenience."""
    print("--- Async Create and Run ---")
    async with waveium.AsyncClient() as client:
        try:
            result = await client.scenes.create_and_run(
                scene_id,
                execution_name="Async SDK Test",
                timeout=3600,
                on_event=print_progress,
            )
            print(f"Completed: {result.execution_id}")

            files = await client.executions.list_files(
                result.execution_id, subdir="results"
            )
            print(f"Result files: {files.total_files}")
        except waveium.ExecutionFailedError as e:
            print(f"Failed: {e.error_message}")
        except waveium.ConflictError:
            print("Scene not in completed status")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print(
            "Usage: python async_streaming_usage.py "
            "<tier> <resource_id>"
        )
        print("  tier: 1, 2, 3")
        sys.exit(1)

    tier = sys.argv[1]
    resource_id = sys.argv[2]

    if tier == "1":
        asyncio.run(async_raw_stream(resource_id))
    elif tier == "2":
        asyncio.run(async_wait(resource_id))
    elif tier == "3":
        asyncio.run(async_create_and_run(resource_id))
    else:
        print(f"Unknown tier: {tier}")
        sys.exit(1)
