#!/usr/bin/env python3
"""Complete underground environment workflow using the Waveium SDK.

Demonstrates the full Environment -> Scene -> Execution pipeline
for an underground scenario using local data files:

  - nodegraphWithNeighbors.json: tunnel/corridor graph for 3D
    environment generation
  - UsedRBS.csv: access point / RBS positions
  - UE.csv: user equipment trajectory

Usage:
    export WAVEIUM_API_TOKEN="wvx_..."
    python3 underground_workflow.py
"""

import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# Add src to path for local development
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import waveium  # noqa: E402

# Data directory relative to this script
DATA_DIR = Path(__file__).parent / "data" / "underground"

# Polling configuration
POLL_INTERVAL = 10  # seconds
MAX_POLL_ATTEMPTS = 180  # 30 minutes max


def wait_for_environment(
    client: waveium.Client,
    environment_id: str,
) -> waveium.models.EnvironmentResponse:
    """Poll until environment reaches a terminal state."""
    for attempt in range(MAX_POLL_ATTEMPTS):
        env = client.environments.get(environment_id, sync=True)
        status = env.status
        print(f"  [{attempt + 1}] Environment status: {status}")

        if status == "completed":
            return env
        if status in ("failed", "cancelled"):
            raise RuntimeError(
                f"Environment {environment_id} "
                f"reached terminal state: {status}"
            )
        time.sleep(POLL_INTERVAL)

    raise TimeoutError(
        f"Environment {environment_id} did not complete "
        f"within {MAX_POLL_ATTEMPTS * POLL_INTERVAL}s"
    )


def wait_for_scene(
    client: waveium.Client,
    scene_id: str,
) -> waveium.models.SceneResponse:
    """Poll until scene reaches a terminal state."""
    for attempt in range(MAX_POLL_ATTEMPTS):
        scene = client.scenes.get(scene_id)
        status = scene.status
        print(f"  [{attempt + 1}] Scene status: {status}")

        if status == "completed":
            return scene
        if status in ("failed", "cancelled"):
            raise RuntimeError(
                f"Scene {scene_id} " f"reached terminal state: {status}"
            )
        time.sleep(POLL_INTERVAL)

    raise TimeoutError(
        f"Scene {scene_id} did not complete "
        f"within {MAX_POLL_ATTEMPTS * POLL_INTERVAL}s"
    )


def wait_for_execution(
    client: waveium.Client,
    execution_id: str,
) -> waveium.models.ExecutionResponse:
    """Poll until execution reaches a terminal state."""
    for attempt in range(MAX_POLL_ATTEMPTS):
        execution = client.executions.get(execution_id)
        status = execution.status
        print(f"  [{attempt + 1}] Execution status: {status}")

        if status == "completed":
            return execution
        if status in ("failed", "cancelled"):
            raise RuntimeError(
                f"Execution {execution_id} " f"reached terminal state: {status}"
            )

        # Show progress if available
        try:
            prog = client.executions.progress(execution_id)
            if prog.message:
                print(f"         {prog.message}")
            if prog.progress and "percent" in prog.progress:
                print(f"         Progress: {prog.progress['percent']:.1f}%")
        except waveium.WaveiumError:
            pass

        time.sleep(POLL_INTERVAL)

    raise TimeoutError(
        f"Execution {execution_id} did not complete "
        f"within {MAX_POLL_ATTEMPTS * POLL_INTERVAL}s"
    )


def main() -> None:
    """Run the complete underground workflow."""
    print("Waveium Underground Workflow")
    print("=" * 60)

    # Validate data files exist
    nodegraph_file = DATA_DIR / "nodegraphWithNeighbors.json"
    rbs_file = DATA_DIR / "UsedRBS.csv"
    ue_file = DATA_DIR / "UE.csv"

    for f in [nodegraph_file, rbs_file, ue_file]:
        if not f.exists():
            print(f"ERROR: Missing data file: {f}")
            sys.exit(1)

    # Initialize client
    api_token = os.getenv("WAVEIUM_API_TOKEN")
    if not api_token:
        print("ERROR: Set WAVEIUM_API_TOKEN environment variable")
        sys.exit(1)

    client = waveium.init(
        api_key=api_token,
    )
    print(f"Base URL: {client._config.base_url}\n")

    # Timestamp suffix so each run creates fresh resources
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")

    try:
        # --------------------------------------------------
        # Step 1: Create the underground environment
        # --------------------------------------------------
        print("Step 1: Creating underground environment...")
        env_resp = client.environments.create(
            name=f"Underground Tunnel {ts}",
            environment_type="underground",
            description=(
                "Underground tunnel environment generated "
                "from nodegraph data"
            ),
        )
        env = env_resp.environment
        env_id = env.environment_id
        print(f"  Environment ID: {env_id}")
        print(f"  Status: {env.status}")
        print(f"  Reused: {env_resp.reused}\n")

        # --------------------------------------------------
        # Step 2: Upload nodegraph to the environment
        # --------------------------------------------------
        print("Step 2: Uploading nodegraph to environment...")
        upload_result = client.environments.upload(
            environment_id=env_id,
            file_path=nodegraph_file,
            content_type="application/json",
        )
        nodegraph_file_id = upload_result.file_id
        print(f"  File ID: {nodegraph_file_id}")
        print(f"  Message: {upload_result.message}\n")

        # --------------------------------------------------
        # Step 3: Update environment with nodegraph file ID
        #         to trigger generation
        # --------------------------------------------------
        print("Step 3: Updating environment with " "nodegraph file ID...")
        env = client.environments.update(
            environment_id=env_id,
            parameters={
                "nodegraph_file_id": nodegraph_file_id,
            },
        )
        print(f"  Status: {env.status}\n")

        # --------------------------------------------------
        # Step 4: Wait for environment generation
        # --------------------------------------------------
        print("Step 4: Waiting for environment generation...")
        env = wait_for_environment(client, env_id)
        print("  Environment completed.\n")

        # --------------------------------------------------
        # Step 5: Create a scene with station parameters
        # --------------------------------------------------
        print("Step 5: Creating scene...")
        scene = client.scenes.create(
            environment_id=env_id,
            name=f"Underground Scene {ts}",
            parameters={},
            description=(
                "Scene with RBS station positions " "and UE trajectory"
            ),
        )
        scene_id = scene.scene_id
        print(f"  Scene ID: {scene_id}")
        print(f"  Status: {scene.status}\n")

        # --------------------------------------------------
        # Step 6: Upload RBS stations file to scene
        # --------------------------------------------------
        print("Step 6: Uploading RBS stations file...")
        rbs_upload = client.scenes.upload(
            scene_id=scene_id,
            file_path=rbs_file,
            content_type="text/csv",
            purpose="stations",
        )
        print(f"  File ID: {rbs_upload.file_id}")
        print(f"  Message: {rbs_upload.message}\n")

        # --------------------------------------------------
        # Step 7: Upload UE trajectory file to scene
        # --------------------------------------------------
        print("Step 7: Uploading UE trajectory file...")
        ue_upload = client.scenes.upload(
            scene_id=scene_id,
            file_path=ue_file,
            content_type="text/csv",
            purpose="trajectory",
        )
        print(f"  File ID: {ue_upload.file_id}")
        print(f"  Message: {ue_upload.message}\n")

        # --------------------------------------------------
        # Step 8: Trigger scene generation
        # --------------------------------------------------
        print("Step 8: Triggering scene generation...")
        scene = client.scenes.generate(scene_id)
        print(f"  Status: {scene.status}\n")

        # --------------------------------------------------
        # Step 9: Wait for scene generation
        # --------------------------------------------------
        print("Step 9: Waiting for scene generation...")
        scene = wait_for_scene(client, scene_id)
        print("  Scene completed.\n")

        # --------------------------------------------------
        # Step 10: Create execution
        # --------------------------------------------------
        print("Step 10: Creating execution...")
        execution = client.scenes.create_execution(
            scene_id=scene_id,
            name=f"Underground Run {ts}",
        )
        exec_id = execution.execution_id
        print(f"  Execution ID: {exec_id}")
        print(f"  Status: {execution.status}\n")

        # --------------------------------------------------
        # Step 11: Wait for execution to complete
        # --------------------------------------------------
        print("Step 11: Waiting for execution...")
        execution = wait_for_execution(client, exec_id)
        print("  Execution completed.\n")

        # --------------------------------------------------
        # Step 12: List and download results
        # --------------------------------------------------
        print("Step 12: Downloading results...")
        results_dir = Path("./results/underground")
        results_dir.mkdir(parents=True, exist_ok=True)

        files = client.executions.list_files(exec_id, subdir="results")
        print(f"  Result files: {files.total_files}")
        for f in files.files:
            print(f"    - {f.filename} " f"({f.file_size_bytes} bytes)")

        if files.total_files > 0:
            batch = client.executions.download_batch(
                exec_id,
                destination_dir=results_dir,
                subdir="results",
            )
            print(
                f"  Downloaded {batch.total_files} files " f"to {results_dir}\n"
            )
        else:
            print("  No result files available.\n")

        # --------------------------------------------------
        # Summary
        # --------------------------------------------------
        print("=" * 60)
        print("WORKFLOW COMPLETE")
        print(f"  Environment: {env_id}")
        print(f"  Scene:       {scene_id}")
        print(f"  Execution:   {exec_id}")
        print(f"  Results:     {results_dir.resolve()}")
        print("=" * 60)

    except waveium.AuthenticationError as e:
        print(f"\nAuthentication failed: {e.message}")
        sys.exit(1)
    except waveium.ConflictError as e:
        print(f"\nState conflict: {e.message}")
        sys.exit(1)
    except waveium.WaveiumError as e:
        print(f"\nWaveium error: {type(e).__name__} - {e.message}")
        sys.exit(1)
    except (RuntimeError, TimeoutError) as e:
        print(f"\nWorkflow error: {e}")
        sys.exit(1)
    finally:
        client.close()


if __name__ == "__main__":
    main()
