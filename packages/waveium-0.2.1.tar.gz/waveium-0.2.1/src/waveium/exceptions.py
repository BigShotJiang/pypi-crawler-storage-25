"""Exceptions for the Waveium SDK."""

from typing import Any, Dict, Optional


class WaveiumError(Exception):
    """Base exception for all Waveium SDK errors."""

    def __init__(
        self,
        message: str,
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize WaveiumError.

        Args:
            message: Error message
            code: Optional error code from API
            details: Optional additional error details
        """
        super().__init__(message)
        self.message = message
        self.code = code
        self.details = details or {}

    def __str__(self) -> str:
        """Return string representation of error."""
        if self.code:
            return f"[{self.code}] {self.message}"
        return self.message


class AuthenticationError(WaveiumError):
    """Raised when authentication fails (401)."""

    pass


class AuthorizationError(WaveiumError):
    """Raised when user lacks permission for operation (403)."""

    pass


class ConflictError(WaveiumError):
    """Raised when operation conflicts with resource state (409)."""

    pass


class NotFoundError(WaveiumError):
    """Raised when a resource is not found (404)."""

    pass


class ValidationError(WaveiumError):
    """Raised when request validation fails (400)."""

    pass


class RateLimitError(WaveiumError):
    """Raised when rate limit is exceeded (429)."""

    pass


class APIError(WaveiumError):
    """Raised for general API errors (500, 502, 503, etc.)."""

    pass


class NetworkError(WaveiumError):
    """Raised when network communication fails."""

    pass


class FileUploadError(WaveiumError):
    """Raised when file upload fails."""

    pass


class FileDownloadError(WaveiumError):
    """Raised when file download fails."""

    pass


class ConfigurationError(WaveiumError):
    """Raised when SDK configuration is invalid."""

    pass


class StreamError(WaveiumError):
    """Base exception for SSE streaming errors."""

    pass


class StreamTimeoutError(StreamError):
    """Raised when total stream duration exceeds the configured limit."""

    pass


class StreamReconnectError(StreamError):
    """Raised when maximum SSE reconnection attempts are exceeded."""

    pass


class ExecutionFailedError(WaveiumError):
    """Raised by wait() when an execution reaches 'failed' status."""

    def __init__(
        self,
        message: str,
        execution_id: str,
        error_message: Optional[str] = None,
        code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        super().__init__(message, code, details)
        self.execution_id = execution_id
        self.error_message = error_message
