"""User resource for the Waveium SDK."""

from typing import Any, Dict, List, Optional

from ..models.auth import TokenListResponse
from ..models.common import MessageResponse
from ..models.users import (
    AdminUpdateUserRequest,
    CreateUserRequest,
    PaginatedUserResponse,
    UpdateOwnUserRequest,
    UserResponse,
)
from ._base import AsyncBaseResource, BaseResource


class UsersResource(BaseResource):
    """Synchronous user operations."""

    def me(
        self,
        fields: Optional[str] = None,
        expand: Optional[str] = None,
    ) -> UserResponse:
        """Get the current user's profile.

        Args:
            fields: Comma-separated list of fields
                to include.
            expand: Comma-separated list of relations
                to expand.

        Returns:
            Current user information.
        """
        params: Dict[str, Any] = {}
        if fields:
            params["fields"] = fields
        if expand:
            params["expand"] = expand
        return self._http.request(
            "GET",
            "/users/me",
            params=params if params else None,
            response_model=UserResponse,
        )

    def update_me(
        self,
        email: Optional[str] = None,
        name: Optional[str] = None,
    ) -> UserResponse:
        """Update the current user's profile.

        Args:
            email: New email address.
            name: New display name.

        Returns:
            Updated user information.
        """
        request = UpdateOwnUserRequest(email=email, name=name)
        return self._http.request(
            "PUT",
            "/users/me",
            json_data=request.model_dump(exclude_none=True),
            response_model=UserResponse,
        )

    def create(
        self,
        email: str,
        organization_id: str,
        name: Optional[str] = None,
        temporary_password: Optional[str] = None,
    ) -> UserResponse:
        """Create a new user (admin only).

        Args:
            email: User email address.
            organization_id: Organization to assign.
            name: Optional display name.
            temporary_password: Optional initial password.

        Returns:
            Created user information.
        """
        request = CreateUserRequest(
            email=email,
            organization_id=organization_id,
            name=name,
            temporary_password=temporary_password,
        )
        return self._http.request(
            "POST",
            "/users",
            json_data=request.model_dump(exclude_none=True),
            response_model=UserResponse,
        )

    def list(
        self,
        q: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
        is_active: Optional[bool] = None,
        sort: Optional[str] = None,
    ) -> PaginatedUserResponse:
        """List users with pagination (admin only).

        Args:
            q: Search query string.
            page: Page number (1-based).
            page_size: Number of items per page.
            is_active: Filter by active status.
            sort: Sort field and direction.

        Returns:
            Paginated list of users.
        """
        params: Dict[str, Any] = {
            "page": page,
            "page_size": page_size,
        }
        if q:
            params["q"] = q
        if is_active is not None:
            params["is_active"] = is_active
        if sort:
            params["sort"] = sort
        return self._http.request(
            "GET",
            "/users",
            params=params,
            response_model=PaginatedUserResponse,
        )

    def get(self, user_id: str) -> UserResponse:
        """Get a user by ID (admin only).

        Args:
            user_id: User ID.

        Returns:
            User information.
        """
        return self._http.request(
            "GET",
            f"/users/{user_id}",
            response_model=UserResponse,
        )

    def update(
        self,
        user_id: str,
        email: Optional[str] = None,
        name: Optional[str] = None,
        is_active: Optional[bool] = None,
        role_ids: Optional[List[str]] = None,
    ) -> UserResponse:
        """Update a user (admin only).

        Args:
            user_id: User ID.
            email: New email address.
            name: New display name.
            is_active: New active status.
            role_ids: Role IDs to assign.

        Returns:
            Updated user information.
        """
        request = AdminUpdateUserRequest(
            email=email,
            name=name,
            is_active=is_active,
            role_ids=role_ids,
        )
        return self._http.request(
            "PUT",
            f"/users/{user_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=UserResponse,
        )

    def delete(self, user_id: str) -> MessageResponse:
        """Delete a user (admin only).

        Args:
            user_id: User ID.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"/users/{user_id}",
            response_model=MessageResponse,
        )

    def list_tokens(self, user_id: str) -> TokenListResponse:
        """List tokens for a user (admin only).

        Args:
            user_id: User ID.

        Returns:
            List of user tokens.
        """
        return self._http.request(
            "GET",
            f"/users/{user_id}/tokens",
            response_model=TokenListResponse,
        )

    def revoke_token(self, user_id: str, token_id: str) -> MessageResponse:
        """Revoke a user's token (admin only).

        Args:
            user_id: User ID.
            token_id: Token ID to revoke.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"/users/{user_id}/tokens/{token_id}",
            response_model=MessageResponse,
        )


class AsyncUsersResource(AsyncBaseResource):
    """Asynchronous user operations."""

    async def me(
        self,
        fields: Optional[str] = None,
        expand: Optional[str] = None,
    ) -> UserResponse:
        """Get the current user's profile.

        Args:
            fields: Comma-separated list of fields
                to include.
            expand: Comma-separated list of relations
                to expand.

        Returns:
            Current user information.
        """
        params: Dict[str, Any] = {}
        if fields:
            params["fields"] = fields
        if expand:
            params["expand"] = expand
        return await self._http.request(
            "GET",
            "/users/me",
            params=params if params else None,
            response_model=UserResponse,
        )

    async def update_me(
        self,
        email: Optional[str] = None,
        name: Optional[str] = None,
    ) -> UserResponse:
        """Update the current user's profile.

        Args:
            email: New email address.
            name: New display name.

        Returns:
            Updated user information.
        """
        request = UpdateOwnUserRequest(email=email, name=name)
        return await self._http.request(
            "PUT",
            "/users/me",
            json_data=request.model_dump(exclude_none=True),
            response_model=UserResponse,
        )

    async def create(
        self,
        email: str,
        organization_id: str,
        name: Optional[str] = None,
        temporary_password: Optional[str] = None,
    ) -> UserResponse:
        """Create a new user (admin only).

        Args:
            email: User email address.
            organization_id: Organization to assign.
            name: Optional display name.
            temporary_password: Optional initial password.

        Returns:
            Created user information.
        """
        request = CreateUserRequest(
            email=email,
            organization_id=organization_id,
            name=name,
            temporary_password=temporary_password,
        )
        return await self._http.request(
            "POST",
            "/users",
            json_data=request.model_dump(exclude_none=True),
            response_model=UserResponse,
        )

    async def list(
        self,
        q: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
        is_active: Optional[bool] = None,
        sort: Optional[str] = None,
    ) -> PaginatedUserResponse:
        """List users with pagination (admin only).

        Args:
            q: Search query string.
            page: Page number (1-based).
            page_size: Number of items per page.
            is_active: Filter by active status.
            sort: Sort field and direction.

        Returns:
            Paginated list of users.
        """
        params: Dict[str, Any] = {
            "page": page,
            "page_size": page_size,
        }
        if q:
            params["q"] = q
        if is_active is not None:
            params["is_active"] = is_active
        if sort:
            params["sort"] = sort
        return await self._http.request(
            "GET",
            "/users",
            params=params,
            response_model=PaginatedUserResponse,
        )

    async def get(self, user_id: str) -> UserResponse:
        """Get a user by ID (admin only).

        Args:
            user_id: User ID.

        Returns:
            User information.
        """
        return await self._http.request(
            "GET",
            f"/users/{user_id}",
            response_model=UserResponse,
        )

    async def update(
        self,
        user_id: str,
        email: Optional[str] = None,
        name: Optional[str] = None,
        is_active: Optional[bool] = None,
        role_ids: Optional[List[str]] = None,
    ) -> UserResponse:
        """Update a user (admin only).

        Args:
            user_id: User ID.
            email: New email address.
            name: New display name.
            is_active: New active status.
            role_ids: Role IDs to assign.

        Returns:
            Updated user information.
        """
        request = AdminUpdateUserRequest(
            email=email,
            name=name,
            is_active=is_active,
            role_ids=role_ids,
        )
        return await self._http.request(
            "PUT",
            f"/users/{user_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=UserResponse,
        )

    async def delete(self, user_id: str) -> MessageResponse:
        """Delete a user (admin only).

        Args:
            user_id: User ID.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"/users/{user_id}",
            response_model=MessageResponse,
        )

    async def list_tokens(self, user_id: str) -> TokenListResponse:
        """List tokens for a user (admin only).

        Args:
            user_id: User ID.

        Returns:
            List of user tokens.
        """
        return await self._http.request(
            "GET",
            f"/users/{user_id}/tokens",
            response_model=TokenListResponse,
        )

    async def revoke_token(
        self, user_id: str, token_id: str
    ) -> MessageResponse:
        """Revoke a user's token (admin only).

        Args:
            user_id: User ID.
            token_id: Token ID to revoke.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"/users/{user_id}/tokens/{token_id}",
            response_model=MessageResponse,
        )
