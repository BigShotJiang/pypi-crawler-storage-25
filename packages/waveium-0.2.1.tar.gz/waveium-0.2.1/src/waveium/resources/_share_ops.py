"""Reusable share operation mixins for resources."""

from typing import TYPE_CHECKING

from ..models.common import MessageResponse, PermissionLevel, ShareTargetType
from ..models.shares import (
    CreateShareRequest,
    PaginatedShareResponse,
    ShareResponse,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient


class ShareOperations:
    """Sync share operations for a resource."""

    def __init__(self, http: "HTTPClient", base_path: str) -> None:
        self._http = http
        self._base_path = base_path

    def create_share(
        self,
        resource_id: str,
        shared_with_type: ShareTargetType,
        shared_with_id: str,
        permission_level: PermissionLevel,
    ) -> ShareResponse:
        """Create a share for a resource.

        Args:
            resource_id: The resource identifier.
            shared_with_type: Target type (user/team/org).
            shared_with_id: Target entity identifier.
            permission_level: Permission (view/use/full).

        Returns:
            The created share record.
        """
        request = CreateShareRequest(
            shared_with_type=shared_with_type,
            shared_with_id=shared_with_id,
            permission_level=permission_level,
        )
        return self._http.request(
            "POST",
            f"{self._base_path}/{resource_id}/shares",
            json_data=request.model_dump(),
            response_model=ShareResponse,
        )

    def list_shares(
        self,
        resource_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedShareResponse:
        """List shares for a resource.

        Args:
            resource_id: The resource identifier.
            limit: Maximum number of results.
            offset: Number of results to skip.

        Returns:
            Paginated list of share records.
        """
        return self._http.request(
            "GET",
            f"{self._base_path}/{resource_id}/shares",
            params={"limit": limit, "offset": offset},
            response_model=PaginatedShareResponse,
        )

    def revoke_share(
        self,
        resource_id: str,
        share_id: str,
    ) -> MessageResponse:
        """Revoke a share for a resource.

        Args:
            resource_id: The resource identifier.
            share_id: The share identifier to revoke.

        Returns:
            Confirmation message response.
        """
        return self._http.request(
            "DELETE",
            (f"{self._base_path}/{resource_id}" f"/shares/{share_id}"),
            response_model=MessageResponse,
        )


class AsyncShareOperations:
    """Async share operations for a resource."""

    def __init__(self, http: "AsyncHTTPClient", base_path: str) -> None:
        self._http = http
        self._base_path = base_path

    async def create_share(
        self,
        resource_id: str,
        shared_with_type: ShareTargetType,
        shared_with_id: str,
        permission_level: PermissionLevel,
    ) -> ShareResponse:
        """Create a share for a resource.

        Args:
            resource_id: The resource identifier.
            shared_with_type: Target type (user/team/org).
            shared_with_id: Target entity identifier.
            permission_level: Permission (view/use/full).

        Returns:
            The created share record.
        """
        request = CreateShareRequest(
            shared_with_type=shared_with_type,
            shared_with_id=shared_with_id,
            permission_level=permission_level,
        )
        return await self._http.request(
            "POST",
            f"{self._base_path}/{resource_id}/shares",
            json_data=request.model_dump(),
            response_model=ShareResponse,
        )

    async def list_shares(
        self,
        resource_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedShareResponse:
        """List shares for a resource.

        Args:
            resource_id: The resource identifier.
            limit: Maximum number of results.
            offset: Number of results to skip.

        Returns:
            Paginated list of share records.
        """
        return await self._http.request(
            "GET",
            f"{self._base_path}/{resource_id}/shares",
            params={"limit": limit, "offset": offset},
            response_model=PaginatedShareResponse,
        )

    async def revoke_share(
        self,
        resource_id: str,
        share_id: str,
    ) -> MessageResponse:
        """Revoke a share for a resource.

        Args:
            resource_id: The resource identifier.
            share_id: The share identifier to revoke.

        Returns:
            Confirmation message response.
        """
        return await self._http.request(
            "DELETE",
            (f"{self._base_path}/{resource_id}" f"/shares/{share_id}"),
            response_model=MessageResponse,
        )
