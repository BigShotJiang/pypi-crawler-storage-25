"""Organization resource for the Waveium SDK."""

from typing import List, Optional

from ..models.common import MessageResponse
from ..models.organizations import (
    CreateOrganizationRequest,
    OrganizationResponse,
    OrganizationStatsResponse,
    UpdateOrganizationRequest,
)
from ..models.users import UserResponse
from ._base import AsyncBaseResource, BaseResource


class OrganizationsResource(BaseResource):
    """Synchronous organization operations."""

    def create(
        self,
        name: str,
        contact: Optional[str] = None,
        homepage: Optional[str] = None,
        subscription_tier: Optional[str] = None,
    ) -> OrganizationResponse:
        """Create a new organization (admin only).

        Args:
            name: Organization name.
            contact: Contact information.
            homepage: Homepage URL.
            subscription_tier: Subscription tier.

        Returns:
            Created organization details.
        """
        request = CreateOrganizationRequest(
            name=name,
            contact=contact,
            homepage=homepage,
            subscription_tier=subscription_tier,
        )
        return self._http.request(
            "POST",
            "/organizations",
            json_data=request.model_dump(exclude_none=True),
            response_model=OrganizationResponse,
        )

    def list(
        self,
        limit: int = 50,
        offset: int = 0,
    ) -> List[OrganizationResponse]:
        """List all organizations (admin only).

        Args:
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            List of organization details.
        """
        result = self._http.request(
            "GET",
            "/organizations",
            params={
                "limit": limit,
                "offset": offset,
            },
        )
        return [OrganizationResponse.model_validate(item) for item in result]

    def update(
        self,
        organization_id: str,
        name: Optional[str] = None,
        contact: Optional[str] = None,
        homepage: Optional[str] = None,
    ) -> OrganizationResponse:
        """Update an organization (admin only).

        Args:
            organization_id: Organization ID.
            name: New name.
            contact: New contact information.
            homepage: New homepage URL.

        Returns:
            Updated organization details.
        """
        request = UpdateOrganizationRequest(
            name=name,
            contact=contact,
            homepage=homepage,
        )
        return self._http.request(
            "PUT",
            f"/organizations/{organization_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=OrganizationResponse,
        )

    def delete(self, organization_id: str) -> MessageResponse:
        """Delete an organization (admin only).

        Args:
            organization_id: Organization ID.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"/organizations/{organization_id}",
            response_model=MessageResponse,
        )

    def stats(self, organization_id: str) -> OrganizationStatsResponse:
        """Get organization statistics (admin only).

        Args:
            organization_id: Organization ID.

        Returns:
            Organization statistics.
        """
        return self._http.request(
            "GET",
            f"/organizations/{organization_id}/stats",
            response_model=OrganizationStatsResponse,
        )

    def list_users(self, organization_id: str) -> List[UserResponse]:
        """List users in an organization (admin only).

        Args:
            organization_id: Organization ID.

        Returns:
            List of users in the organization.
        """
        result = self._http.request(
            "GET",
            (f"/organizations" f"/{organization_id}/users"),
        )
        return [UserResponse.model_validate(item) for item in result]


class AsyncOrganizationsResource(AsyncBaseResource):
    """Asynchronous organization operations."""

    async def create(
        self,
        name: str,
        contact: Optional[str] = None,
        homepage: Optional[str] = None,
        subscription_tier: Optional[str] = None,
    ) -> OrganizationResponse:
        """Create a new organization (admin only).

        Args:
            name: Organization name.
            contact: Contact information.
            homepage: Homepage URL.
            subscription_tier: Subscription tier.

        Returns:
            Created organization details.
        """
        request = CreateOrganizationRequest(
            name=name,
            contact=contact,
            homepage=homepage,
            subscription_tier=subscription_tier,
        )
        return await self._http.request(
            "POST",
            "/organizations",
            json_data=request.model_dump(exclude_none=True),
            response_model=OrganizationResponse,
        )

    async def list(
        self,
        limit: int = 50,
        offset: int = 0,
    ) -> List[OrganizationResponse]:
        """List all organizations (admin only).

        Args:
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            List of organization details.
        """
        result = await self._http.request(
            "GET",
            "/organizations",
            params={
                "limit": limit,
                "offset": offset,
            },
        )
        return [OrganizationResponse.model_validate(item) for item in result]

    async def update(
        self,
        organization_id: str,
        name: Optional[str] = None,
        contact: Optional[str] = None,
        homepage: Optional[str] = None,
    ) -> OrganizationResponse:
        """Update an organization (admin only).

        Args:
            organization_id: Organization ID.
            name: New name.
            contact: New contact information.
            homepage: New homepage URL.

        Returns:
            Updated organization details.
        """
        request = UpdateOrganizationRequest(
            name=name,
            contact=contact,
            homepage=homepage,
        )
        return await self._http.request(
            "PUT",
            f"/organizations/{organization_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=OrganizationResponse,
        )

    async def delete(self, organization_id: str) -> MessageResponse:
        """Delete an organization (admin only).

        Args:
            organization_id: Organization ID.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"/organizations/{organization_id}",
            response_model=MessageResponse,
        )

    async def stats(self, organization_id: str) -> OrganizationStatsResponse:
        """Get organization statistics (admin only).

        Args:
            organization_id: Organization ID.

        Returns:
            Organization statistics.
        """
        return await self._http.request(
            "GET",
            f"/organizations/{organization_id}/stats",
            response_model=OrganizationStatsResponse,
        )

    async def list_users(self, organization_id: str) -> List[UserResponse]:
        """List users in an organization (admin only).

        Args:
            organization_id: Organization ID.

        Returns:
            List of users in the organization.
        """
        result = await self._http.request(
            "GET",
            (f"/organizations" f"/{organization_id}/users"),
        )
        return [UserResponse.model_validate(item) for item in result]
