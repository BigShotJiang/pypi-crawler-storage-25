"""Team resource for the Waveium SDK."""

from typing import Optional

from ..models.common import MessageResponse
from ..models.teams import (
    AddTeamMemberRequest,
    CreateTeamRequest,
    PaginatedTeamMemberResponse,
    PaginatedTeamResponse,
    TeamMemberResponse,
    TeamResponse,
    UpdateTeamRequest,
)
from ._base import AsyncBaseResource, BaseResource


class TeamsResource(BaseResource):
    """Synchronous team operations."""

    def create(
        self,
        name: str,
        description: Optional[str] = None,
    ) -> TeamResponse:
        """Create a new team.

        Args:
            name: Team name.
            description: Optional team description.

        Returns:
            Created team details.
        """
        request = CreateTeamRequest(name=name, description=description)
        return self._http.request(
            "POST",
            "/teams",
            json_data=request.model_dump(exclude_none=True),
            response_model=TeamResponse,
        )

    def list(self, limit: int = 50, offset: int = 0) -> PaginatedTeamResponse:
        """List teams with pagination.

        Args:
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of teams.
        """
        return self._http.request(
            "GET",
            "/teams",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedTeamResponse,
        )

    def get(self, team_id: str) -> TeamResponse:
        """Get a team by ID.

        Args:
            team_id: Team ID.

        Returns:
            Team details.
        """
        return self._http.request(
            "GET",
            f"/teams/{team_id}",
            response_model=TeamResponse,
        )

    def update(
        self,
        team_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> TeamResponse:
        """Update a team.

        Args:
            team_id: Team ID.
            name: New team name.
            description: New team description.

        Returns:
            Updated team details.
        """
        request = UpdateTeamRequest(name=name, description=description)
        return self._http.request(
            "PUT",
            f"/teams/{team_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=TeamResponse,
        )

    def delete(self, team_id: str) -> MessageResponse:
        """Delete a team.

        Args:
            team_id: Team ID.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"/teams/{team_id}",
            response_model=MessageResponse,
        )

    def list_members(
        self,
        team_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedTeamMemberResponse:
        """List team members with pagination.

        Args:
            team_id: Team ID.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of team members.
        """
        return self._http.request(
            "GET",
            f"/teams/{team_id}/members",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedTeamMemberResponse,
        )

    def add_member(
        self,
        team_id: str,
        user_id: str,
        role: Optional[str] = None,
    ) -> TeamMemberResponse:
        """Add a member to a team.

        Args:
            team_id: Team ID.
            user_id: User ID to add.
            role: Member role (member or admin).

        Returns:
            Team member details.
        """
        request = AddTeamMemberRequest(user_id=user_id, role=role)
        return self._http.request(
            "POST",
            f"/teams/{team_id}/members",
            json_data=request.model_dump(exclude_none=True),
            response_model=TeamMemberResponse,
        )

    def remove_member(self, team_id: str, user_id: str) -> MessageResponse:
        """Remove a member from a team.

        Args:
            team_id: Team ID.
            user_id: User ID to remove.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"/teams/{team_id}/members/{user_id}",
            response_model=MessageResponse,
        )


class AsyncTeamsResource(AsyncBaseResource):
    """Asynchronous team operations."""

    async def create(
        self,
        name: str,
        description: Optional[str] = None,
    ) -> TeamResponse:
        """Create a new team.

        Args:
            name: Team name.
            description: Optional team description.

        Returns:
            Created team details.
        """
        request = CreateTeamRequest(name=name, description=description)
        return await self._http.request(
            "POST",
            "/teams",
            json_data=request.model_dump(exclude_none=True),
            response_model=TeamResponse,
        )

    async def list(
        self, limit: int = 50, offset: int = 0
    ) -> PaginatedTeamResponse:
        """List teams with pagination.

        Args:
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of teams.
        """
        return await self._http.request(
            "GET",
            "/teams",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedTeamResponse,
        )

    async def get(self, team_id: str) -> TeamResponse:
        """Get a team by ID.

        Args:
            team_id: Team ID.

        Returns:
            Team details.
        """
        return await self._http.request(
            "GET",
            f"/teams/{team_id}",
            response_model=TeamResponse,
        )

    async def update(
        self,
        team_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> TeamResponse:
        """Update a team.

        Args:
            team_id: Team ID.
            name: New team name.
            description: New team description.

        Returns:
            Updated team details.
        """
        request = UpdateTeamRequest(name=name, description=description)
        return await self._http.request(
            "PUT",
            f"/teams/{team_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=TeamResponse,
        )

    async def delete(self, team_id: str) -> MessageResponse:
        """Delete a team.

        Args:
            team_id: Team ID.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"/teams/{team_id}",
            response_model=MessageResponse,
        )

    async def list_members(
        self,
        team_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedTeamMemberResponse:
        """List team members with pagination.

        Args:
            team_id: Team ID.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of team members.
        """
        return await self._http.request(
            "GET",
            f"/teams/{team_id}/members",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedTeamMemberResponse,
        )

    async def add_member(
        self,
        team_id: str,
        user_id: str,
        role: Optional[str] = None,
    ) -> TeamMemberResponse:
        """Add a member to a team.

        Args:
            team_id: Team ID.
            user_id: User ID to add.
            role: Member role (member or admin).

        Returns:
            Team member details.
        """
        request = AddTeamMemberRequest(user_id=user_id, role=role)
        return await self._http.request(
            "POST",
            f"/teams/{team_id}/members",
            json_data=request.model_dump(exclude_none=True),
            response_model=TeamMemberResponse,
        )

    async def remove_member(
        self, team_id: str, user_id: str
    ) -> MessageResponse:
        """Remove a member from a team.

        Args:
            team_id: Team ID.
            user_id: User ID to remove.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"/teams/{team_id}/members/{user_id}",
            response_model=MessageResponse,
        )
