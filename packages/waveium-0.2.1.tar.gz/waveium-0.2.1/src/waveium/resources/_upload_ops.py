"""Reusable upload operation mixins for resources."""

import mimetypes
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, Optional, Union

import anyio
import httpx

from ..exceptions import FileUploadError

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient


class UploadOperations:
    """Sync upload operations for a resource."""

    def __init__(self, http: "HTTPClient", base_path: str) -> None:
        self._http = http
        self._base_path = base_path

    def initiate_upload(
        self,
        resource_id: str,
        filename: str,
        content_type: Optional[str] = None,
        response_model: type = None,  # type: ignore[assignment]
    ) -> Any:
        """Initiate a file upload session.

        Args:
            resource_id: The resource identifier.
            filename: Name of the file to upload.
            content_type: Optional MIME type override.
            response_model: Pydantic model for response.

        Returns:
            Upload session response with signed URL.
        """
        body: Dict[str, Any] = {"filename": filename}
        if content_type:
            body["content_type"] = content_type
        return self._http.request(
            "POST",
            f"{self._base_path}/{resource_id}/uploads",
            json_data=body,
            response_model=response_model,
        )

    def complete_upload(
        self,
        resource_id: str,
        upload_id: str,
        purpose: Optional[str] = None,
        response_model: type = None,  # type: ignore[assignment]
    ) -> Any:
        """Mark an upload session as complete.

        Args:
            resource_id: The resource identifier.
            upload_id: The upload session identifier.
            purpose: Optional purpose tag for the file.
            response_model: Pydantic model for response.

        Returns:
            Completed upload response.
        """
        params = {}
        if purpose:
            params["purpose"] = purpose
        return self._http.request(
            "POST",
            (
                f"{self._base_path}/{resource_id}"
                f"/uploads/{upload_id}/complete"
            ),
            params=params if params else None,
            response_model=response_model,
        )

    def upload(
        self,
        resource_id: str,
        file_path: Union[str, Path],
        content_type: Optional[str] = None,
        purpose: Optional[str] = None,
        initiate_model: type = None,  # type: ignore[assignment]
        complete_model: type = None,  # type: ignore[assignment]
    ) -> Any:
        """Upload a file end-to-end.

        Initiates an upload session, transfers the file
        to the signed URL, then completes the session.

        Args:
            resource_id: The resource identifier.
            file_path: Local path to the file.
            content_type: Optional MIME type override.
            purpose: Optional purpose tag for the file.
            initiate_model: Model for initiate response.
            complete_model: Model for complete response.

        Returns:
            Completed upload response.

        Raises:
            FileNotFoundError: If file does not exist.
            FileUploadError: If upload fails.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        filename = file_path.name
        if content_type is None:
            content_type, _ = mimetypes.guess_type(str(file_path))
            if content_type is None:
                content_type = "application/octet-stream"

        upload_resp = self.initiate_upload(
            resource_id=resource_id,
            filename=filename,
            content_type=content_type,
            response_model=initiate_model,
        )

        try:
            with (
                open(file_path, "rb") as f,
                httpx.Client() as client,
            ):
                r = client.request(
                    method=upload_resp.method,
                    url=upload_resp.upload_url,
                    content=f,
                    headers={"Content-Type": content_type},
                )
                r.raise_for_status()

            return self.complete_upload(
                resource_id=resource_id,
                upload_id=upload_resp.upload_id,
                purpose=purpose,
                response_model=complete_model,
            )
        except FileUploadError:
            raise
        except Exception as e:
            raise FileUploadError(f"Failed to upload file: {e}")


class AsyncUploadOperations:
    """Async upload operations for a resource."""

    def __init__(self, http: "AsyncHTTPClient", base_path: str) -> None:
        self._http = http
        self._base_path = base_path

    async def initiate_upload(
        self,
        resource_id: str,
        filename: str,
        content_type: Optional[str] = None,
        response_model: type = None,  # type: ignore[assignment]
    ) -> Any:
        """Initiate a file upload session.

        Args:
            resource_id: The resource identifier.
            filename: Name of the file to upload.
            content_type: Optional MIME type override.
            response_model: Pydantic model for response.

        Returns:
            Upload session response with signed URL.
        """
        body: Dict[str, Any] = {"filename": filename}
        if content_type:
            body["content_type"] = content_type
        return await self._http.request(
            "POST",
            f"{self._base_path}/{resource_id}/uploads",
            json_data=body,
            response_model=response_model,
        )

    async def complete_upload(
        self,
        resource_id: str,
        upload_id: str,
        purpose: Optional[str] = None,
        response_model: type = None,  # type: ignore[assignment]
    ) -> Any:
        """Mark an upload session as complete.

        Args:
            resource_id: The resource identifier.
            upload_id: The upload session identifier.
            purpose: Optional purpose tag for the file.
            response_model: Pydantic model for response.

        Returns:
            Completed upload response.
        """
        params = {}
        if purpose:
            params["purpose"] = purpose
        return await self._http.request(
            "POST",
            (
                f"{self._base_path}/{resource_id}"
                f"/uploads/{upload_id}/complete"
            ),
            params=params if params else None,
            response_model=response_model,
        )

    async def upload(
        self,
        resource_id: str,
        file_path: Union[str, Path],
        content_type: Optional[str] = None,
        purpose: Optional[str] = None,
        initiate_model: type = None,  # type: ignore[assignment]
        complete_model: type = None,  # type: ignore[assignment]
    ) -> Any:
        """Upload a file end-to-end.

        Initiates an upload session, transfers the file
        to the signed URL, then completes the session.

        Args:
            resource_id: The resource identifier.
            file_path: Local path to the file.
            content_type: Optional MIME type override.
            purpose: Optional purpose tag for the file.
            initiate_model: Model for initiate response.
            complete_model: Model for complete response.

        Returns:
            Completed upload response.

        Raises:
            FileNotFoundError: If file does not exist.
            FileUploadError: If upload fails.
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        filename = file_path.name
        if content_type is None:
            content_type, _ = mimetypes.guess_type(str(file_path))
            if content_type is None:
                content_type = "application/octet-stream"

        upload_resp = await self.initiate_upload(
            resource_id=resource_id,
            filename=filename,
            content_type=content_type,
            response_model=initiate_model,
        )

        try:
            async with (
                await anyio.open_file(file_path, "rb") as f,
                httpx.AsyncClient() as client,
            ):
                file_content = await f.read()
                r = await client.request(
                    method=upload_resp.method,
                    url=upload_resp.upload_url,
                    content=file_content,
                    headers={"Content-Type": content_type},
                )
                r.raise_for_status()

            return await self.complete_upload(
                resource_id=resource_id,
                upload_id=upload_resp.upload_id,
                purpose=purpose,
                response_model=complete_model,
            )
        except FileUploadError:
            raise
        except Exception as e:
            raise FileUploadError(f"Failed to upload file: {e}")
