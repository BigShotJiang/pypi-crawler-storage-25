"""Base resource classes for the Waveium SDK."""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient


class BaseResource:
    """Base class for synchronous API resources."""

    def __init__(self, http_client: "HTTPClient") -> None:
        """Initialize base resource.

        Args:
            http_client: HTTP client instance
        """
        self._http = http_client


class AsyncBaseResource:
    """Base class for asynchronous API resources."""

    def __init__(self, http_client: "AsyncHTTPClient") -> None:
        """Initialize async base resource.

        Args:
            http_client: Async HTTP client instance
        """
        self._http = http_client
