"""Execution resource for the Waveium SDK."""

from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Optional,
    Union,
)

from ..exceptions import ExecutionFailedError
from ..models.common import (
    MessageResponse,
    StorageStatsResponse,
)
from ..models.events import TERMINAL_STATUSES, ServerEvent
from ..models.executions import (
    ExecutionProgressResponse,
    ExecutionResponse,
    PaginatedExecutionResponse,
    UpdateExecutionRequest,
)
from ..models.files import (
    ArchiveDownloadResponse,
    BatchDownloadResponse,
    ExecutionFilesResponse,
    FileDownloadResponse,
)
from ._base import AsyncBaseResource, BaseResource
from ._file_ops import AsyncFileOperations, FileOperations
from ._stream_ops import (
    AsyncEventStream,
    AsyncStreamOperations,
    EventStream,
    StreamOperations,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient

_BASE = "/v0/executions"
_SSE_PATH = "/v0/executions/{resource_id}"


def _unpack_binary_columns(df: Any) -> Any:
    """Decode binary columns in a DataFrame to numpy arrays.

    Simulation parquet files store array data (e.g. channel
    coefficients) as packed float32 byte strings. This function
    detects those columns and converts each cell from raw bytes
    to a numpy float32 array.

    Args:
        df: A pandas DataFrame.

    Returns:
        The DataFrame with binary columns unpacked.
    """
    import numpy as np

    for col in df.columns:
        if df[col].dtype != object:
            continue
        sample = df[col].iloc[0] if len(df) > 0 else None
        if not isinstance(sample, (bytes, bytearray)):
            continue
        df[col] = df[col].apply(
            lambda cell: (
                np.frombuffer(cell, dtype=np.float32)
                if isinstance(cell, (bytes, bytearray))
                else cell
            )
        )
    return df


def _structure_columns(df: Any) -> Any:
    """Group related columns into structured arrays.

    Merges coordinate triplets and real/imaginary pairs:
      - ``entity_X_x``, ``entity_X_y``, ``entity_X_z``
        become ``entity_X`` with np.array([x, y, z]) per row.
      - ``ue_0-X_re``, ``ue_0-X_im`` become ``ue_0-X``
        with a complex numpy array per row.

    Columns that don't match either pattern are kept as-is.

    Args:
        df: A pandas DataFrame (already unpacked).

    Returns:
        A new DataFrame with grouped columns.
    """
    import numpy as np
    import pandas as pd  # type: ignore[import-untyped]

    columns = list(df.columns)
    col_set = set(columns)
    consumed: set[str] = set()
    new_columns: dict[str, Any] = {}

    # Pass 1: detect xyz position triplets
    for col in columns:
        if not col.endswith("_x"):
            continue
        prefix = col[:-2]
        y_col = prefix + "_y"
        z_col = prefix + "_z"
        if y_col in col_set and z_col in col_set:
            xyz = np.column_stack(
                [
                    df[col].values,
                    df[y_col].values,
                    df[z_col].values,
                ]
            ).astype(np.float32)
            new_columns[prefix] = list(xyz)
            consumed.update([col, y_col, z_col])

    # Pass 2: detect re/im pairs -> complex arrays
    for col in columns:
        if not col.endswith("_re"):
            continue
        prefix = col[:-3]
        im_col = prefix + "_im"
        if im_col not in col_set:
            continue

        re_series = df[col]
        im_series = df[im_col]

        # Check if cells are numpy arrays (unpacked binary)
        sample = re_series.iloc[0] if len(df) > 0 else None
        if hasattr(sample, "__len__") and not isinstance(sample, (str, bytes)):
            # Array-valued: element-wise complex
            new_columns[prefix] = [
                re_val.astype(np.float32) + 1j * im_val.astype(np.float32)
                for re_val, im_val in zip(re_series, im_series)
            ]
        else:
            # Scalar-valued: simple complex
            new_columns[prefix] = re_series.values + 1j * im_series.values
        consumed.update([col, im_col])

    # Build result: unconsumed columns first, then grouped
    result = pd.DataFrame()
    for col in columns:
        if col not in consumed:
            result[col] = df[col]
    for name in new_columns:
        result[name] = new_columns[name]

    return result


class ExecutionsResource(BaseResource):
    """Synchronous execution operations."""

    def __init__(self, http_client: "HTTPClient") -> None:
        super().__init__(http_client)
        self._files = FileOperations(http_client, _BASE)
        self._streams = StreamOperations(http_client, _SSE_PATH)

    # ------ Streaming ------

    def stream(
        self,
        execution_id: str,
        *,
        max_total_seconds: float = 7200.0,
    ) -> EventStream:
        """Stream real-time SSE events for an execution.

        Returns an EventStream that is both an iterator and
        a context manager. Events include status updates with
        detailed progress (waypoints, entity progress, overall
        completion percentage).

        Args:
            execution_id: The execution identifier.
            max_total_seconds: Maximum total stream duration
                including reconnections. Defaults to 2 hours.

        Returns:
            An EventStream yielding typed ServerEvent instances.

        Example:
            with client.executions.stream("exe_xxx") as events:
                for event in events:
                    if event.event_type == "status":
                        print(event.progress)
        """
        return self._streams.stream(
            execution_id,
            max_total_seconds=max_total_seconds,
        )

    def wait(
        self,
        execution_id: str,
        *,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> ExecutionResponse:
        """Block until an execution completes, streaming progress.

        Subscribes to the execution's SSE event stream and
        blocks until a terminal status (completed, failed,
        cancelled) is received. Returns the final
        ExecutionResponse fetched via GET.

        Args:
            execution_id: The execution identifier.
            timeout: Maximum wait time in seconds.
                Defaults to 1 hour.
            on_event: Optional callback invoked for each
                SSE event received. Useful for progress
                reporting.

        Returns:
            The final ExecutionResponse after completion.

        Raises:
            ExecutionFailedError: If execution fails.
            StreamTimeoutError: If timeout is exceeded.

        Example:
            def progress(event):
                if hasattr(event, 'progress') and event.progress:
                    print(event.progress.overall_percent)

            result = client.executions.wait(
                "exe_xxx", on_event=progress
            )
        """
        # Pre-check: if already terminal, return immediately
        # without opening an SSE stream that would hang.
        current = self.get(execution_id)
        if current.status in TERMINAL_STATUSES:
            if current.status == "failed":
                raise ExecutionFailedError(
                    message=(
                        f"Execution {execution_id} failed: "
                        f"{current.error_message or 'unknown error'}"
                    ),
                    execution_id=execution_id,
                    error_message=current.error_message,
                )
            return current

        final_event = self._streams.wait(
            execution_id,
            timeout=timeout,
            on_event=on_event,
        )

        # Fetch the full response object
        result = self.get(execution_id)

        if final_event.status == "failed":
            raise ExecutionFailedError(
                message=(
                    f"Execution {execution_id} failed: "
                    f"{final_event.error_message or 'unknown error'}"
                ),
                execution_id=execution_id,
                error_message=final_event.error_message,
            )

        return result

    # ------ CRUD ------

    def list(
        self,
        limit: int = 50,
        offset: int = 0,
        status: Optional[str] = None,
        scene_id: Optional[str] = None,
        scope: Optional[str] = None,
    ) -> PaginatedExecutionResponse:
        """List executions with optional filters.

        Args:
            limit: Maximum results per page.
            offset: Number of results to skip.
            status: Filter by status.
            scene_id: Filter by scene.
            scope: Filter scope (mine/shared/org).

        Returns:
            Paginated list of executions.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if status:
            params["status"] = status
        if scene_id:
            params["scene_id"] = scene_id
        if scope:
            params["scope"] = scope
        return self._http.request(
            "GET",
            _BASE,
            params=params,
            response_model=PaginatedExecutionResponse,
        )

    def get(self, execution_id: str) -> ExecutionResponse:
        """Get a single execution by ID.

        Args:
            execution_id: The execution identifier.

        Returns:
            Full execution response.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{execution_id}",
            response_model=ExecutionResponse,
        )

    def update(self, execution_id: str, name: str) -> ExecutionResponse:
        """Update an execution.

        Args:
            execution_id: The execution identifier.
            name: New execution name.

        Returns:
            Updated execution response.
        """
        request = UpdateExecutionRequest(name=name)
        return self._http.request(
            "PUT",
            f"{_BASE}/{execution_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=ExecutionResponse,
        )

    def delete(self, execution_id: str) -> MessageResponse:
        """Delete an execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"{_BASE}/{execution_id}",
            response_model=MessageResponse,
        )

    # ------ Actions ------

    def cancel(self, execution_id: str) -> ExecutionResponse:
        """Cancel a running execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Updated execution response.
        """
        return self._http.request(
            "POST",
            f"{_BASE}/{execution_id}/cancel",
            response_model=ExecutionResponse,
        )

    def progress(self, execution_id: str) -> ExecutionProgressResponse:
        """Get progress information for an execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Execution progress response.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{execution_id}/progress",
            response_model=ExecutionProgressResponse,
        )

    def storage(self, execution_id: str) -> StorageStatsResponse:
        """Get storage statistics for an execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Storage statistics.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{execution_id}/storage",
            response_model=StorageStatsResponse,
        )

    def download_archive(
        self,
        execution_id: str,
        subdir: Optional[str] = None,
    ) -> ArchiveDownloadResponse:
        """Get a zip archive download URL.

        Args:
            execution_id: The execution identifier.
            subdir: Optional subdirectory filter.

        Returns:
            Archive download URL response.
        """
        params: Dict[str, Any] = {}
        if subdir:
            params["subdir"] = subdir
        return self._http.request(
            "GET",
            (f"{_BASE}/{execution_id}" f"/downloads/archive"),
            params=params if params else None,
            response_model=ArchiveDownloadResponse,
        )

    # ------ File operations ------

    def list_files(
        self,
        execution_id: str,
        subdir: Optional[str] = None,
    ) -> ExecutionFilesResponse:
        """List files in an execution.

        Args:
            execution_id: The execution identifier.
            subdir: Optional subdirectory filter.

        Returns:
            List of execution files.
        """
        return self._files.list_files(  # type: ignore[return-value]
            execution_id, subdir, ExecutionFilesResponse
        )

    def get_download_url(
        self, execution_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            execution_id: The execution identifier.
            file_id: The file identifier.

        Returns:
            Signed download URL response.
        """
        return self._files.get_download_url(execution_id, file_id)

    def download(
        self,
        execution_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            execution_id: The execution identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.
        """
        return self._files.download(execution_id, file_id, destination)

    def download_batch(
        self,
        execution_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for an execution.

        Args:
            execution_id: The execution identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.
        """
        return self._files.download_batch(
            execution_id,
            destination_dir,
            subdir,
        )

    def read_bytes(
        self,
        execution_id: str,
        file_id: str,
    ) -> bytes:
        """Read a file's content into memory.

        Fetches the file via its signed download URL without
        writing to disk. For large files, use download() instead.

        Args:
            execution_id: The execution identifier.
            file_id: The file identifier.

        Returns:
            File content as bytes.
        """
        return self._files.read_bytes(execution_id, file_id)

    def read_parquet(
        self,
        execution_id: str,
        filename: Optional[str] = None,
        unpack: bool = True,
        structured: bool = False,
    ) -> Any:
        """Read a parquet result file directly into a DataFrame.

        Streams the parquet file from its signed download URL
        into pandas without writing to disk. Requires pandas
        and pyarrow to be installed.

        If filename is omitted and there is exactly one .parquet
        file in the results, it is used automatically. If there
        are multiple, you must specify which one.

        Binary columns (e.g. packed float32 channel
        coefficients) are automatically unpacked into numpy
        arrays unless unpack=False.

        When structured=True, related columns are merged:
          - ``entity_X_x/y/z`` become ``entity_X`` with
            np.array([x, y, z]) per row.
          - ``ue_0-X_re/im`` become ``ue_0-X`` with a
            complex numpy array per row.

        Args:
            execution_id: The execution identifier.
            filename: Parquet filename to read. If None,
                auto-discovers the single parquet file.
            unpack: If True (default), decode binary columns
                into numpy float32 arrays.
            structured: If True, merge coordinate triplets
                into position arrays and re/im pairs into
                complex arrays.

        Returns:
            A pandas DataFrame.

        Raises:
            ImportError: If pandas is not installed.
            FileDownloadError: If no parquet file is found
                or multiple exist without filename specified.

        Example:
            df = client.executions.read_parquet(
                "exe_xxx", structured=True
            )
            # df["entity_AP:G1N-AP-S-417"]  -> [x, y, z]
            # df["ue_0-G1N-AP-S-417"]       -> complex array
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for read_parquet(). "
                "Install with: pip install pandas pyarrow"
            )

        target = self._find_parquet_file(execution_id, filename)
        download = self.get_download_url(execution_id, target.file_id)
        df = pd.read_parquet(download.download_url)

        if unpack or structured:
            df = _unpack_binary_columns(df)

        if structured:
            df = _structure_columns(df)

        return df

    def download_parquet(
        self,
        execution_id: str,
        destination: Union[str, Path],
        filename: Optional[str] = None,
    ) -> Path:
        """Download the parquet result file to a local path.

        Auto-discovers the parquet file the same way
        read_parquet() does. Use this when you want a local
        copy to work with offline or to avoid re-downloading.

        Args:
            execution_id: The execution identifier.
            destination: Local file path or directory. If a
                directory, the original filename is used.
            filename: Parquet filename to download. If None,
                auto-discovers the single parquet file.

        Returns:
            Path to the downloaded file.

        Example:
            path = client.executions.download_parquet(
                "exe_xxx", "./results/"
            )
            df = pd.read_parquet(path)
        """
        target = self._find_parquet_file(execution_id, filename)
        dest = Path(destination)
        if dest.is_dir() or str(destination).endswith("/"):
            dest = dest / target.filename
        return self._files.download(execution_id, target.file_id, dest)

    def _find_parquet_file(
        self,
        execution_id: str,
        filename: Optional[str],
    ) -> Any:
        """Locate a parquet file in the execution results."""
        from ..exceptions import FileDownloadError

        files = self.list_files(execution_id, subdir="results")
        parquet_files = [
            f for f in files.files if f.filename.endswith(".parquet")
        ]

        if not parquet_files:
            raise FileDownloadError(
                "No parquet files found in execution results"
            )

        if filename is not None:
            matches = [f for f in parquet_files if f.filename == filename]
            if not matches:
                available = [f.filename for f in parquet_files]
                raise FileDownloadError(
                    f"Parquet file '{filename}' not found. "
                    f"Available: {available}"
                )
            return matches[0]

        if len(parquet_files) == 1:
            return parquet_files[0]

        available = [f.filename for f in parquet_files]
        raise FileDownloadError(
            f"Multiple parquet files found: {available}. "
            f"Specify filename parameter."
        )


class AsyncExecutionsResource(AsyncBaseResource):
    """Asynchronous execution operations."""

    def __init__(self, http_client: "AsyncHTTPClient") -> None:
        super().__init__(http_client)
        self._files = AsyncFileOperations(http_client, _BASE)
        self._streams = AsyncStreamOperations(http_client, _SSE_PATH)

    # ------ Streaming ------

    def stream(
        self,
        execution_id: str,
        *,
        max_total_seconds: float = 7200.0,
    ) -> AsyncEventStream:
        """Stream real-time SSE events for an execution.

        Returns an AsyncEventStream that is both an async
        iterator and an async context manager.

        Args:
            execution_id: The execution identifier.
            max_total_seconds: Maximum total stream duration.

        Returns:
            An AsyncEventStream yielding typed ServerEvent instances.

        Example:
            async with client.executions.stream("exe_xxx") as events:
                async for event in events:
                    if event.event_type == "status":
                        print(event.progress)
        """
        return self._streams.stream(
            execution_id,
            max_total_seconds=max_total_seconds,
        )

    async def wait(
        self,
        execution_id: str,
        *,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> ExecutionResponse:
        """Block until an execution completes, streaming progress.

        Async counterpart of ExecutionsResource.wait().

        Args:
            execution_id: The execution identifier.
            timeout: Maximum wait time in seconds.
            on_event: Optional callback for each event.

        Returns:
            The final ExecutionResponse after completion.

        Raises:
            ExecutionFailedError: If execution fails.
            StreamTimeoutError: If timeout is exceeded.
        """
        # Pre-check: if already terminal, return immediately
        current = await self.get(execution_id)
        if current.status in TERMINAL_STATUSES:
            if current.status == "failed":
                raise ExecutionFailedError(
                    message=(
                        f"Execution {execution_id} failed: "
                        f"{current.error_message or 'unknown error'}"
                    ),
                    execution_id=execution_id,
                    error_message=current.error_message,
                )
            return current

        final_event = await self._streams.wait(
            execution_id,
            timeout=timeout,
            on_event=on_event,
        )

        result = await self.get(execution_id)

        if final_event.status == "failed":
            raise ExecutionFailedError(
                message=(
                    f"Execution {execution_id} failed: "
                    f"{final_event.error_message or 'unknown error'}"
                ),
                execution_id=execution_id,
                error_message=final_event.error_message,
            )

        return result

    # ------ CRUD ------

    async def list(
        self,
        limit: int = 50,
        offset: int = 0,
        status: Optional[str] = None,
        scene_id: Optional[str] = None,
        scope: Optional[str] = None,
    ) -> PaginatedExecutionResponse:
        """List executions with optional filters.

        Args:
            limit: Maximum results per page.
            offset: Number of results to skip.
            status: Filter by status.
            scene_id: Filter by scene.
            scope: Filter scope (mine/shared/org).

        Returns:
            Paginated list of executions.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if status:
            params["status"] = status
        if scene_id:
            params["scene_id"] = scene_id
        if scope:
            params["scope"] = scope
        return await self._http.request(
            "GET",
            _BASE,
            params=params,
            response_model=PaginatedExecutionResponse,
        )

    async def get(self, execution_id: str) -> ExecutionResponse:
        """Get a single execution by ID.

        Args:
            execution_id: The execution identifier.

        Returns:
            Full execution response.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{execution_id}",
            response_model=ExecutionResponse,
        )

    async def update(self, execution_id: str, name: str) -> ExecutionResponse:
        """Update an execution.

        Args:
            execution_id: The execution identifier.
            name: New execution name.

        Returns:
            Updated execution response.
        """
        request = UpdateExecutionRequest(name=name)
        return await self._http.request(
            "PUT",
            f"{_BASE}/{execution_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=ExecutionResponse,
        )

    async def delete(self, execution_id: str) -> MessageResponse:
        """Delete an execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"{_BASE}/{execution_id}",
            response_model=MessageResponse,
        )

    # ------ Actions ------

    async def cancel(self, execution_id: str) -> ExecutionResponse:
        """Cancel a running execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Updated execution response.
        """
        return await self._http.request(
            "POST",
            f"{_BASE}/{execution_id}/cancel",
            response_model=ExecutionResponse,
        )

    async def progress(self, execution_id: str) -> ExecutionProgressResponse:
        """Get progress information for an execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Execution progress response.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{execution_id}/progress",
            response_model=ExecutionProgressResponse,
        )

    async def storage(self, execution_id: str) -> StorageStatsResponse:
        """Get storage statistics for an execution.

        Args:
            execution_id: The execution identifier.

        Returns:
            Storage statistics.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{execution_id}/storage",
            response_model=StorageStatsResponse,
        )

    async def download_archive(
        self,
        execution_id: str,
        subdir: Optional[str] = None,
    ) -> ArchiveDownloadResponse:
        """Get a zip archive download URL.

        Args:
            execution_id: The execution identifier.
            subdir: Optional subdirectory filter.

        Returns:
            Archive download URL response.
        """
        params: Dict[str, Any] = {}
        if subdir:
            params["subdir"] = subdir
        return await self._http.request(
            "GET",
            (f"{_BASE}/{execution_id}" f"/downloads/archive"),
            params=params if params else None,
            response_model=ArchiveDownloadResponse,
        )

    # ------ File operations ------

    async def list_files(
        self,
        execution_id: str,
        subdir: Optional[str] = None,
    ) -> ExecutionFilesResponse:
        """List files in an execution.

        Args:
            execution_id: The execution identifier.
            subdir: Optional subdirectory filter.

        Returns:
            List of execution files.
        """
        return await self._files.list_files(  # type: ignore[return-value]
            execution_id, subdir, ExecutionFilesResponse
        )

    async def get_download_url(
        self, execution_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            execution_id: The execution identifier.
            file_id: The file identifier.

        Returns:
            Signed download URL response.
        """
        return await self._files.get_download_url(execution_id, file_id)

    async def download(
        self,
        execution_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            execution_id: The execution identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.
        """
        return await self._files.download(execution_id, file_id, destination)

    async def download_batch(
        self,
        execution_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for an execution.

        Args:
            execution_id: The execution identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.
        """
        return await self._files.download_batch(
            execution_id, destination_dir, subdir
        )

    async def download_parquet(
        self,
        execution_id: str,
        destination: Union[str, Path],
        filename: Optional[str] = None,
    ) -> Path:
        """Download the parquet result file to a local path.

        Async counterpart of ExecutionsResource.download_parquet().

        Args:
            execution_id: The execution identifier.
            destination: Local file path or directory.
            filename: Parquet filename to download. If None,
                auto-discovers the single parquet file.

        Returns:
            Path to the downloaded file.
        """
        from ..exceptions import FileDownloadError

        files = await self.list_files(execution_id, subdir="results")
        parquet_files = [
            f for f in files.files if f.filename.endswith(".parquet")
        ]

        if not parquet_files:
            raise FileDownloadError(
                "No parquet files found in execution results"
            )

        if filename is not None:
            matches = [f for f in parquet_files if f.filename == filename]
            if not matches:
                available = [f.filename for f in parquet_files]
                raise FileDownloadError(
                    f"Parquet file '{filename}' not found. "
                    f"Available: {available}"
                )
            target = matches[0]
        elif len(parquet_files) == 1:
            target = parquet_files[0]
        else:
            available = [f.filename for f in parquet_files]
            raise FileDownloadError(
                f"Multiple parquet files found: "
                f"{available}. Specify filename parameter."
            )

        dest = Path(destination)
        if dest.is_dir() or str(destination).endswith("/"):
            dest = dest / target.filename
        return await self._files.download(execution_id, target.file_id, dest)

    async def read_bytes(
        self,
        execution_id: str,
        file_id: str,
    ) -> bytes:
        """Read a file's content into memory.

        Async counterpart of ExecutionsResource.read_bytes().

        Args:
            execution_id: The execution identifier.
            file_id: The file identifier.

        Returns:
            File content as bytes.
        """
        return await self._files.read_bytes(execution_id, file_id)

    async def read_parquet(
        self,
        execution_id: str,
        filename: Optional[str] = None,
        unpack: bool = True,
        structured: bool = False,
    ) -> Any:
        """Read a parquet result file directly into a DataFrame.

        Async counterpart of ExecutionsResource.read_parquet().

        Args:
            execution_id: The execution identifier.
            filename: Parquet filename to read. If None,
                auto-discovers the single parquet file.
            unpack: If True (default), decode binary columns
                into numpy float32 arrays.
            structured: If True, merge coordinate triplets
                into position arrays and re/im pairs into
                complex arrays.

        Returns:
            A pandas DataFrame.

        Raises:
            ImportError: If pandas is not installed.
            FileDownloadError: If no parquet file is found.
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for read_parquet(). "
                "Install with: pip install pandas pyarrow"
            )

        from ..exceptions import FileDownloadError

        files = await self.list_files(execution_id, subdir="results")
        parquet_files = [
            f for f in files.files if f.filename.endswith(".parquet")
        ]

        if not parquet_files:
            raise FileDownloadError(
                "No parquet files found in execution results"
            )

        if filename is not None:
            matches = [f for f in parquet_files if f.filename == filename]
            if not matches:
                available = [f.filename for f in parquet_files]
                raise FileDownloadError(
                    f"Parquet file '{filename}' not found. "
                    f"Available: {available}"
                )
            target = matches[0]
        elif len(parquet_files) == 1:
            target = parquet_files[0]
        else:
            available = [f.filename for f in parquet_files]
            raise FileDownloadError(
                f"Multiple parquet files found: {available}."
                f" Specify filename parameter."
            )

        download = await self.get_download_url(execution_id, target.file_id)
        df = pd.read_parquet(download.download_url)

        if unpack or structured:
            df = _unpack_binary_columns(df)

        if structured:
            df = _structure_columns(df)

        return df
