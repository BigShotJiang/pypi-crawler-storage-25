"""Reusable file operation mixins for resources."""

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union

import anyio
import httpx

from ..exceptions import FileDownloadError
from ..models.files import (
    BatchDownloadFile,
    BatchDownloadResponse,
    FileDownloadResponse,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient


class FileOperations:
    """Sync file operations for a resource."""

    def __init__(self, http: "HTTPClient", base_path: str) -> None:
        self._http = http
        self._base_path = base_path

    def list_files(
        self,
        resource_id: str,
        subdir: Optional[str] = None,
        response_model: type = None,  # type: ignore[assignment]
    ) -> object:
        """List files for a resource.

        Args:
            resource_id: The resource identifier.
            subdir: Optional subdirectory filter.
            response_model: Pydantic model for response.

        Returns:
            Parsed response object.
        """
        params = {}
        if subdir:
            params["subdir"] = subdir
        return self._http.request(
            "GET",
            f"{self._base_path}/{resource_id}/files",
            params=params if params else None,
            response_model=response_model,
        )

    def get_download_url(
        self, resource_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            resource_id: The resource identifier.
            file_id: The file identifier.

        Returns:
            Download URL response with signed URL.
        """
        return self._http.request(
            "GET",
            (f"{self._base_path}/{resource_id}" f"/files/{file_id}/download"),
            response_model=FileDownloadResponse,
        )

    def download(
        self,
        resource_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            resource_id: The resource identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.

        Raises:
            FileDownloadError: If download fails.
        """
        resp = self.get_download_url(resource_id, file_id)
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            with httpx.Client() as client:
                r = client.request(
                    method=resp.method,
                    url=resp.download_url,
                )
                r.raise_for_status()
                with open(destination, "wb") as f:
                    f.write(r.content)
            return destination
        except Exception as e:
            raise FileDownloadError(f"Failed to download file: {e}")

    def read_bytes(
        self,
        resource_id: str,
        file_id: str,
    ) -> bytes:
        """Read a file's content into memory.

        Fetches the file via its signed download URL and
        returns the raw bytes without writing to disk.
        Suitable for small-to-medium files (configs, CSVs,
        metadata). For large files, use download() instead.

        Args:
            resource_id: The resource identifier.
            file_id: The file identifier.

        Returns:
            File content as bytes.

        Raises:
            FileDownloadError: If download fails.
        """
        resp = self.get_download_url(resource_id, file_id)
        try:
            with httpx.Client() as client:
                r = client.request(
                    method=resp.method,
                    url=resp.download_url,
                )
                r.raise_for_status()
                return r.content
        except Exception as e:
            raise FileDownloadError(f"Failed to read file: {e}")

    def download_batch(
        self,
        resource_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for a resource.

        Args:
            resource_id: The resource identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.

        Raises:
            FileDownloadError: If any download fails.
        """
        params = {}
        if subdir:
            params["subdir"] = subdir
        batch: BatchDownloadResponse = self._http.request(
            "POST",
            f"{self._base_path}/{resource_id}/downloads",
            params=params if params else None,
            response_model=BatchDownloadResponse,
        )
        dest = Path(destination_dir)
        dest.mkdir(parents=True, exist_ok=True)
        with httpx.Client() as client:
            for fi in batch.files:
                try:
                    r = client.request(
                        method=fi.method,
                        url=fi.download_url,
                    )
                    r.raise_for_status()
                    fp = (dest / fi.filename).resolve()
                    if not str(fp).startswith(str(dest.resolve())):
                        raise FileDownloadError(
                            f"Unsafe filename rejected: " f"{fi.filename}"
                        )
                    with open(fp, "wb") as f:
                        f.write(r.content)
                except FileDownloadError:
                    raise
                except Exception as e:
                    raise FileDownloadError(
                        f"Failed to download {fi.filename}: {e}"
                    )
        return batch


class AsyncFileOperations:
    """Async file operations for a resource."""

    def __init__(self, http: "AsyncHTTPClient", base_path: str) -> None:
        self._http = http
        self._base_path = base_path

    async def list_files(
        self,
        resource_id: str,
        subdir: Optional[str] = None,
        response_model: type = None,  # type: ignore[assignment]
    ) -> object:
        """List files for a resource.

        Args:
            resource_id: The resource identifier.
            subdir: Optional subdirectory filter.
            response_model: Pydantic model for response.

        Returns:
            Parsed response object.
        """
        params = {}
        if subdir:
            params["subdir"] = subdir
        return await self._http.request(
            "GET",
            f"{self._base_path}/{resource_id}/files",
            params=params if params else None,
            response_model=response_model,
        )

    async def get_download_url(
        self, resource_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            resource_id: The resource identifier.
            file_id: The file identifier.

        Returns:
            Download URL response with signed URL.
        """
        return await self._http.request(
            "GET",
            (f"{self._base_path}/{resource_id}" f"/files/{file_id}/download"),
            response_model=FileDownloadResponse,
        )

    async def read_bytes(
        self,
        resource_id: str,
        file_id: str,
    ) -> bytes:
        """Read a file's content into memory.

        Async counterpart of FileOperations.read_bytes().

        Args:
            resource_id: The resource identifier.
            file_id: The file identifier.

        Returns:
            File content as bytes.

        Raises:
            FileDownloadError: If download fails.
        """
        resp = await self.get_download_url(resource_id, file_id)
        try:
            async with httpx.AsyncClient() as client:
                r = await client.request(
                    method=resp.method,
                    url=resp.download_url,
                )
                r.raise_for_status()
                return r.content
        except Exception as e:
            raise FileDownloadError(f"Failed to read file: {e}")

    async def download(
        self,
        resource_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            resource_id: The resource identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.

        Raises:
            FileDownloadError: If download fails.
        """
        resp = await self.get_download_url(resource_id, file_id)
        destination = Path(destination)
        await anyio.Path(destination.parent).mkdir(parents=True, exist_ok=True)
        try:
            async with httpx.AsyncClient() as client:
                r = await client.request(
                    method=resp.method,
                    url=resp.download_url,
                )
                r.raise_for_status()
                async with await anyio.open_file(destination, "wb") as f:
                    await f.write(r.content)
            return destination
        except Exception as e:
            raise FileDownloadError(f"Failed to download file: {e}")

    async def download_batch(
        self,
        resource_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for a resource.

        Args:
            resource_id: The resource identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.

        Raises:
            FileDownloadError: If any download fails.
        """
        params = {}
        if subdir:
            params["subdir"] = subdir
        batch: BatchDownloadResponse = await self._http.request(
            "POST",
            (f"{self._base_path}/{resource_id}" f"/downloads"),
            params=params if params else None,
            response_model=BatchDownloadResponse,
        )
        dest = Path(destination_dir)
        await anyio.Path(dest).mkdir(parents=True, exist_ok=True)

        async def _download_one(
            client: httpx.AsyncClient,
            fi: BatchDownloadFile,
        ) -> None:
            try:
                r = await client.request(
                    method=fi.method,
                    url=fi.download_url,
                )
                r.raise_for_status()
                fp = (dest / fi.filename).resolve()
                if not str(fp).startswith(str(dest.resolve())):
                    raise FileDownloadError(
                        f"Unsafe filename rejected: " f"{fi.filename}"
                    )
                async with await anyio.open_file(fp, "wb") as f:
                    await f.write(r.content)
            except FileDownloadError:
                raise
            except Exception as e:
                raise FileDownloadError(
                    f"Failed to download {fi.filename}: {e}"
                )

        async with httpx.AsyncClient() as client:
            await asyncio.gather(
                *[_download_one(client, fi) for fi in batch.files]
            )
        return batch
