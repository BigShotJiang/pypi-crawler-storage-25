"""Authentication resource for the Waveium SDK."""

from typing import Optional

from ..models.auth import (
    CreateTokenRequest,
    TokenExchangeResponse,
    TokenListResponse,
)
from ..models.common import MessageResponse
from ._base import AsyncBaseResource, BaseResource


class AuthResource(BaseResource):
    """Synchronous authentication operations."""

    def create_token(
        self,
        name: str,
        expires_days: int = 30,
        firebase_token: Optional[str] = None,
    ) -> TokenExchangeResponse:
        """Create a new API token by exchanging Firebase JWT.

        Args:
            name: Name/description for the API key
            expires_days: Number of days until token expires (1-365), default 30
            firebase_token: Firebase JWT token. If not provided, uses token from
                current client configuration.

        Returns:
            Token exchange response with API key and user info

        Raises:
            AuthenticationError: If Firebase token is invalid
            ValidationError: If request parameters are invalid
        """
        request = CreateTokenRequest(name=name, expires_days=expires_days)

        headers = {}
        if firebase_token:
            headers["Authorization"] = f"Bearer {firebase_token}"

        return self._http.request(
            "POST",
            "/auth/tokens",
            json_data=request.model_dump(exclude_none=True),
            headers=headers if headers else None,
            response_model=TokenExchangeResponse,
        )

    def list_tokens(self) -> TokenListResponse:
        """List all API tokens for the current user.

        Returns:
            List of API tokens

        Raises:
            AuthenticationError: If not authenticated
        """
        return self._http.request(
            "GET",
            "/auth/tokens",
            response_model=TokenListResponse,
        )

    def revoke_token(self, token_id: str) -> MessageResponse:
        """Revoke a specific API token owned by the current user.

        Args:
            token_id: ID of the token to revoke

        Returns:
            Success message

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If token not found or doesn't belong to user
        """
        return self._http.request(
            "DELETE",
            f"/auth/tokens/{token_id}",
            response_model=MessageResponse,
        )


class AsyncAuthResource(AsyncBaseResource):
    """Asynchronous authentication operations."""

    async def create_token(
        self,
        name: str,
        expires_days: int = 30,
        firebase_token: Optional[str] = None,
    ) -> TokenExchangeResponse:
        """Create a new API token by exchanging Firebase JWT.

        Args:
            name: Name/description for the API key
            expires_days: Number of days until token expires (1-365), default 30
            firebase_token: Firebase JWT token. If not provided, uses token from
                current client configuration.

        Returns:
            Token exchange response with API key and user info

        Raises:
            AuthenticationError: If Firebase token is invalid
            ValidationError: If request parameters are invalid
        """
        request = CreateTokenRequest(name=name, expires_days=expires_days)

        headers = {}
        if firebase_token:
            headers["Authorization"] = f"Bearer {firebase_token}"

        return await self._http.request(
            "POST",
            "/auth/tokens",
            json_data=request.model_dump(exclude_none=True),
            headers=headers if headers else None,
            response_model=TokenExchangeResponse,
        )

    async def list_tokens(self) -> TokenListResponse:
        """List all API tokens for the current user.

        Returns:
            List of API tokens

        Raises:
            AuthenticationError: If not authenticated
        """
        return await self._http.request(
            "GET",
            "/auth/tokens",
            response_model=TokenListResponse,
        )

    async def revoke_token(self, token_id: str) -> MessageResponse:
        """Revoke a specific API token owned by the current user.

        Args:
            token_id: ID of the token to revoke

        Returns:
            Success message

        Raises:
            AuthenticationError: If not authenticated
            NotFoundError: If token not found or doesn't belong to user
        """
        return await self._http.request(
            "DELETE",
            f"/auth/tokens/{token_id}",
            response_model=MessageResponse,
        )
