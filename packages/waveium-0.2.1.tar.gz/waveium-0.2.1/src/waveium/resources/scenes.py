"""Scene resource for the Waveium SDK."""

from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Optional,
    Union,
)

from ..models.common import (
    MessageResponse,
    PermissionLevel,
    ShareTargetType,
    StorageStatsResponse,
)
from ..models.executions import (
    CreateExecutionRequest,
    ExecutionResponse,
    PaginatedExecutionResponse,
)
from ..models.files import (
    BatchDownloadResponse,
    FileDownloadResponse,
    SceneFilesResponse,
)
from ..models.scenes import (
    CreateSceneRequest,
    PaginatedSceneResponse,
    PatchSceneRequest,
    SceneParameters,
    SceneResponse,
    SceneUploadCompleteResponse,
    SceneUploadResponse,
    SimilarSceneResponse,
    UpdateSceneRequest,
)
from ..models.shares import (
    PaginatedShareResponse,
    ShareResponse,
)
from ..exceptions import ExecutionFailedError
from ..models.events import TERMINAL_STATUSES, ServerEvent
from ._base import AsyncBaseResource, BaseResource
from ._file_ops import AsyncFileOperations, FileOperations
from ._share_ops import AsyncShareOperations, ShareOperations
from ._stream_ops import (
    AsyncEventStream,
    AsyncStreamOperations,
    EventStream,
    StreamOperations,
)
from ._upload_ops import (
    AsyncUploadOperations,
    UploadOperations,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient

_BASE = "/v0/scenes"
_SSE_PATH = "/v0/events/scenes/{resource_id}"
_EXEC_SSE_PATH = "/v0/executions/{resource_id}"


class ScenesResource(BaseResource):
    """Synchronous scene operations."""

    def __init__(self, http_client: "HTTPClient") -> None:
        super().__init__(http_client)
        self._files = FileOperations(http_client, _BASE)
        self._uploads = UploadOperations(http_client, _BASE)
        self._shares = ShareOperations(http_client, _BASE)
        self._streams = StreamOperations(http_client, _SSE_PATH)
        self._exec_streams = StreamOperations(http_client, _EXEC_SSE_PATH)

    # ------ Streaming ------

    def stream(
        self,
        scene_id: str,
        *,
        max_total_seconds: float = 7200.0,
    ) -> EventStream:
        """Stream real-time SSE events for a scene.

        Args:
            scene_id: The scene identifier.
            max_total_seconds: Maximum total stream duration.

        Returns:
            An EventStream yielding typed ServerEvent instances.
        """
        return self._streams.stream(
            scene_id,
            max_total_seconds=max_total_seconds,
        )

    def wait(
        self,
        scene_id: str,
        *,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> SceneResponse:
        """Block until scene generation completes.

        Args:
            scene_id: The scene identifier.
            timeout: Maximum wait time in seconds.
            on_event: Optional callback for each event.

        Returns:
            The final SceneResponse after completion.

        Raises:
            StreamTimeoutError: If timeout is exceeded.
        """
        # Pre-check: if already terminal, return immediately
        current = self.get(scene_id)
        if current.status in TERMINAL_STATUSES:
            return current

        self._streams.wait(
            scene_id,
            timeout=timeout,
            on_event=on_event,
        )
        return self.get(scene_id)

    def create_and_run(
        self,
        scene_id: str,
        *,
        execution_name: Optional[str] = None,
        execution_parameters: Optional[Dict[str, Any]] = None,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> ExecutionResponse:
        """Create an execution and wait for it to complete.

        Convenience method that combines create_execution()
        with execution wait() in a single call.

        Args:
            scene_id: The scene identifier (must be completed).
            execution_name: Optional name for the execution.
            execution_parameters: Optional execution parameters.
            timeout: Maximum wait time in seconds.
            on_event: Optional callback for progress events.

        Returns:
            The final ExecutionResponse after completion.

        Raises:
            ExecutionFailedError: If the execution fails.
            ConflictError: If scene is not in completed status.
            StreamTimeoutError: If timeout is exceeded.
        """
        execution = self.create_execution(
            scene_id,
            name=execution_name,
            parameters=execution_parameters,
        )

        final_event = self._exec_streams.wait(
            execution.execution_id,
            timeout=timeout,
            on_event=on_event,
        )

        from .executions import ExecutionsResource

        exec_resource = ExecutionsResource(self._http)
        result = exec_resource.get(execution.execution_id)

        if final_event.status == "failed":
            raise ExecutionFailedError(
                message=(
                    f"Execution {execution.execution_id} failed: "
                    f"{final_event.error_message or 'unknown error'}"
                ),
                execution_id=execution.execution_id,
                error_message=final_event.error_message,
            )

        return result

    # ------ CRUD ------

    def create(
        self,
        environment_id: str,
        name: str,
        parameters: Union[SceneParameters, Dict[str, Any]],
        description: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> SceneResponse:
        """Create a new scene.

        Args:
            environment_id: Parent environment ID.
            name: Scene name.
            parameters: Scene parameters object or dict.
            description: Optional description.
            project_id: Optional project ID.

        Returns:
            Created scene response.
        """
        if isinstance(parameters, dict):
            parameters = SceneParameters(**parameters)
        request = CreateSceneRequest(
            environment_id=environment_id,
            name=name,
            parameters=parameters,
            description=description,
            project_id=project_id,
        )
        return self._http.request(
            "POST",
            _BASE,
            json_data=request.model_dump(exclude_none=True),
            response_model=SceneResponse,
        )

    def list(
        self,
        limit: int = 50,
        offset: int = 0,
        status: Optional[str] = None,
        environment_id: Optional[str] = None,
        scope: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> PaginatedSceneResponse:
        """List scenes with optional filters.

        Args:
            limit: Maximum results per page.
            offset: Number of results to skip.
            status: Filter by status.
            environment_id: Filter by environment.
            scope: Filter scope.
            project_id: Filter by project.

        Returns:
            Paginated list of scenes.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if status:
            params["status"] = status
        if environment_id:
            params["environment_id"] = environment_id
        if scope:
            params["scope"] = scope
        if project_id:
            params["project_id"] = project_id
        return self._http.request(
            "GET",
            _BASE,
            params=params,
            response_model=PaginatedSceneResponse,
        )

    def get(self, scene_id: str) -> SceneResponse:
        """Get a single scene by ID.

        Args:
            scene_id: The scene identifier.

        Returns:
            Full scene response.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{scene_id}",
            response_model=SceneResponse,
        )

    def update(
        self,
        scene_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> SceneResponse:
        """Fully update a scene.

        Args:
            scene_id: The scene identifier.
            name: New name.
            description: New description.

        Returns:
            Updated scene response.
        """
        request = UpdateSceneRequest(
            name=name,
            description=description,
        )
        return self._http.request(
            "PUT",
            f"{_BASE}/{scene_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=SceneResponse,
        )

    def patch(
        self,
        scene_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        parameters: Optional[Union[SceneParameters, Dict[str, Any]]] = None,
    ) -> SceneResponse:
        """Partially update a scene.

        Args:
            scene_id: The scene identifier.
            name: New name.
            description: New description.
            parameters: Partial parameters to merge.

        Returns:
            Updated scene response.
        """
        if isinstance(parameters, dict):
            parameters = SceneParameters(**parameters)
        request = PatchSceneRequest(
            name=name,
            description=description,
            parameters=parameters,
        )
        return self._http.request(
            "PATCH",
            f"{_BASE}/{scene_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=SceneResponse,
        )

    def delete(self, scene_id: str) -> MessageResponse:
        """Delete a scene.

        Args:
            scene_id: The scene identifier.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"{_BASE}/{scene_id}",
            response_model=MessageResponse,
        )

    # ------ Actions ------

    def generate(self, scene_id: str) -> SceneResponse:
        """Trigger scene generation.

        Args:
            scene_id: The scene identifier.

        Returns:
            Updated scene response.
        """
        return self._http.request(
            "POST",
            f"{_BASE}/{scene_id}/generate",
            response_model=SceneResponse,
        )

    def cancel(self, scene_id: str) -> SceneResponse:
        """Cancel a running scene generation.

        Args:
            scene_id: The scene identifier.

        Returns:
            Updated scene response.
        """
        return self._http.request(
            "POST",
            f"{_BASE}/{scene_id}/cancel",
            response_model=SceneResponse,
        )

    def find_similar(
        self,
        environment_id: str,
        parameters: Union[SceneParameters, Dict[str, Any]],
    ) -> SimilarSceneResponse:
        """Find scenes with similar parameters.

        Args:
            environment_id: Parent environment ID.
            parameters: Parameters to match against.

        Returns:
            List of similar scenes.
        """
        if isinstance(parameters, dict):
            parameters = SceneParameters(**parameters)
        body: Dict[str, Any] = {
            "environment_id": environment_id,
            "parameters": parameters.model_dump(exclude_none=True),
        }
        return self._http.request(
            "POST",
            f"{_BASE}/similar",
            json_data=body,
            response_model=SimilarSceneResponse,
        )

    def storage(self, scene_id: str) -> StorageStatsResponse:
        """Get storage statistics for a scene.

        Args:
            scene_id: The scene identifier.

        Returns:
            Storage statistics.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{scene_id}/storage",
            response_model=StorageStatsResponse,
        )

    # ------ Execution operations ------

    def create_execution(
        self,
        scene_id: str,
        name: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> ExecutionResponse:
        """Create a new execution for a scene.

        Args:
            scene_id: The scene identifier.
            name: Optional execution name.
            parameters: Optional execution parameters.

        Returns:
            Created execution response.
        """
        request = CreateExecutionRequest(
            name=name,
            parameters=parameters,
        )
        return self._http.request(
            "POST",
            f"{_BASE}/{scene_id}/executions",
            json_data=request.model_dump(exclude_none=True),
            response_model=ExecutionResponse,
        )

    def list_executions(
        self,
        scene_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedExecutionResponse:
        """List executions for a scene.

        Args:
            scene_id: The scene identifier.
            limit: Maximum results per page.
            offset: Number of results to skip.

        Returns:
            Paginated list of executions.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{scene_id}/executions",
            params={"limit": limit, "offset": offset},
            response_model=PaginatedExecutionResponse,
        )

    # ------ File operations ------

    def list_files(
        self,
        scene_id: str,
        subdir: Optional[str] = None,
    ) -> SceneFilesResponse:
        """List files in a scene.

        Args:
            scene_id: The scene identifier.
            subdir: Optional subdirectory filter.

        Returns:
            List of scene files.
        """
        return self._files.list_files(  # type: ignore[return-value]
            scene_id, subdir, SceneFilesResponse
        )

    def get_download_url(
        self, scene_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            scene_id: The scene identifier.
            file_id: The file identifier.

        Returns:
            Signed download URL response.
        """
        return self._files.get_download_url(scene_id, file_id)

    def download(
        self,
        scene_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            scene_id: The scene identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.
        """
        return self._files.download(scene_id, file_id, destination)

    def download_batch(
        self,
        scene_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for a scene.

        Args:
            scene_id: The scene identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.
        """
        return self._files.download_batch(scene_id, destination_dir, subdir)

    # ------ Upload operations ------

    def initiate_upload(
        self,
        scene_id: str,
        filename: str,
        content_type: Optional[str] = None,
        purpose: Optional[str] = None,
    ) -> SceneUploadResponse:
        """Initiate a file upload session.

        Args:
            scene_id: The scene identifier.
            filename: Name of the file to upload.
            content_type: Optional MIME type override.
            purpose: Upload purpose (trajectory, etc.).

        Returns:
            Upload session with signed URL.
        """
        return self._uploads.initiate_upload(  # type: ignore[no-any-return]
            scene_id,
            filename,
            content_type,
            SceneUploadResponse,
        )

    def complete_upload(
        self,
        scene_id: str,
        upload_id: str,
        purpose: Optional[str] = None,
    ) -> SceneUploadCompleteResponse:
        """Mark an upload session as complete.

        Args:
            scene_id: The scene identifier.
            upload_id: The upload session identifier.
            purpose: Optional purpose query param.

        Returns:
            Completed upload response.
        """
        return self._uploads.complete_upload(  # type: ignore[no-any-return]
            scene_id,
            upload_id,
            purpose=purpose,
            response_model=SceneUploadCompleteResponse,
        )

    def upload(
        self,
        scene_id: str,
        file_path: Union[str, Path],
        content_type: Optional[str] = None,
        purpose: Optional[str] = None,
    ) -> SceneUploadCompleteResponse:
        """Upload a file end-to-end.

        Args:
            scene_id: The scene identifier.
            file_path: Local path to the file.
            content_type: Optional MIME type override.
            purpose: Optional purpose tag.

        Returns:
            Completed upload response.
        """
        return self._uploads.upload(  # type: ignore[no-any-return]
            scene_id,
            file_path,
            content_type,
            purpose=purpose,
            initiate_model=SceneUploadResponse,
            complete_model=SceneUploadCompleteResponse,
        )

    # ------ Share operations ------

    def create_share(
        self,
        scene_id: str,
        shared_with_type: ShareTargetType,
        shared_with_id: str,
        permission_level: PermissionLevel,
    ) -> ShareResponse:
        """Create a share for a scene.

        Args:
            scene_id: The scene identifier.
            shared_with_type: Target type (user/team/org).
            shared_with_id: Target entity identifier.
            permission_level: Permission (view/use/full).

        Returns:
            The created share record.
        """
        return self._shares.create_share(
            scene_id,
            shared_with_type,
            shared_with_id,
            permission_level,
        )

    def list_shares(
        self,
        scene_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedShareResponse:
        """List shares for a scene.

        Args:
            scene_id: The scene identifier.
            limit: Maximum number of results.
            offset: Number of results to skip.

        Returns:
            Paginated list of share records.
        """
        return self._shares.list_shares(scene_id, limit, offset)

    def revoke_share(self, scene_id: str, share_id: str) -> MessageResponse:
        """Revoke a share for a scene.

        Args:
            scene_id: The scene identifier.
            share_id: The share identifier to revoke.

        Returns:
            Confirmation message response.
        """
        return self._shares.revoke_share(scene_id, share_id)


class AsyncScenesResource(AsyncBaseResource):
    """Asynchronous scene operations."""

    def __init__(self, http_client: "AsyncHTTPClient") -> None:
        super().__init__(http_client)
        self._files = AsyncFileOperations(http_client, _BASE)
        self._uploads = AsyncUploadOperations(http_client, _BASE)
        self._shares = AsyncShareOperations(http_client, _BASE)
        self._streams = AsyncStreamOperations(http_client, _SSE_PATH)
        self._exec_streams = AsyncStreamOperations(http_client, _EXEC_SSE_PATH)

    # ------ Streaming ------

    def stream(
        self,
        scene_id: str,
        *,
        max_total_seconds: float = 7200.0,
    ) -> AsyncEventStream:
        """Stream real-time SSE events for a scene.

        Args:
            scene_id: The scene identifier.
            max_total_seconds: Maximum total stream duration.

        Returns:
            An AsyncEventStream yielding typed ServerEvent instances.
        """
        return self._streams.stream(
            scene_id,
            max_total_seconds=max_total_seconds,
        )

    async def wait(
        self,
        scene_id: str,
        *,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> SceneResponse:
        """Block until scene generation completes.

        Args:
            scene_id: The scene identifier.
            timeout: Maximum wait time in seconds.
            on_event: Optional callback for each event.

        Returns:
            The final SceneResponse after completion.

        Raises:
            StreamTimeoutError: If timeout is exceeded.
        """
        # Pre-check: if already terminal, return immediately
        current = await self.get(scene_id)
        if current.status in TERMINAL_STATUSES:
            return current

        await self._streams.wait(
            scene_id,
            timeout=timeout,
            on_event=on_event,
        )
        return await self.get(scene_id)

    async def create_and_run(
        self,
        scene_id: str,
        *,
        execution_name: Optional[str] = None,
        execution_parameters: Optional[Dict[str, Any]] = None,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> ExecutionResponse:
        """Create an execution and wait for it to complete.

        Async counterpart of ScenesResource.create_and_run().

        Args:
            scene_id: The scene identifier (must be completed).
            execution_name: Optional name for the execution.
            execution_parameters: Optional execution parameters.
            timeout: Maximum wait time in seconds.
            on_event: Optional callback for progress events.

        Returns:
            The final ExecutionResponse after completion.

        Raises:
            ExecutionFailedError: If the execution fails.
            ConflictError: If scene is not in completed status.
            StreamTimeoutError: If timeout is exceeded.
        """
        execution = await self.create_execution(
            scene_id,
            name=execution_name,
            parameters=execution_parameters,
        )

        final_event = await self._exec_streams.wait(
            execution.execution_id,
            timeout=timeout,
            on_event=on_event,
        )

        from .executions import AsyncExecutionsResource

        exec_resource = AsyncExecutionsResource(self._http)
        result = await exec_resource.get(execution.execution_id)

        if final_event.status == "failed":
            raise ExecutionFailedError(
                message=(
                    f"Execution {execution.execution_id} failed: "
                    f"{final_event.error_message or 'unknown error'}"
                ),
                execution_id=execution.execution_id,
                error_message=final_event.error_message,
            )

        return result

    # ------ CRUD ------

    async def create(
        self,
        environment_id: str,
        name: str,
        parameters: Union[SceneParameters, Dict[str, Any]],
        description: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> SceneResponse:
        """Create a new scene.

        Args:
            environment_id: Parent environment ID.
            name: Scene name.
            parameters: Scene parameters object or dict.
            description: Optional description.
            project_id: Optional project ID.

        Returns:
            Created scene response.
        """
        if isinstance(parameters, dict):
            parameters = SceneParameters(**parameters)
        request = CreateSceneRequest(
            environment_id=environment_id,
            name=name,
            parameters=parameters,
            description=description,
            project_id=project_id,
        )
        return await self._http.request(
            "POST",
            _BASE,
            json_data=request.model_dump(exclude_none=True),
            response_model=SceneResponse,
        )

    async def list(
        self,
        limit: int = 50,
        offset: int = 0,
        status: Optional[str] = None,
        environment_id: Optional[str] = None,
        scope: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> PaginatedSceneResponse:
        """List scenes with optional filters.

        Args:
            limit: Maximum results per page.
            offset: Number of results to skip.
            status: Filter by status.
            environment_id: Filter by environment.
            scope: Filter scope.
            project_id: Filter by project.

        Returns:
            Paginated list of scenes.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if status:
            params["status"] = status
        if environment_id:
            params["environment_id"] = environment_id
        if scope:
            params["scope"] = scope
        if project_id:
            params["project_id"] = project_id
        return await self._http.request(
            "GET",
            _BASE,
            params=params,
            response_model=PaginatedSceneResponse,
        )

    async def get(self, scene_id: str) -> SceneResponse:
        """Get a single scene by ID.

        Args:
            scene_id: The scene identifier.

        Returns:
            Full scene response.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{scene_id}",
            response_model=SceneResponse,
        )

    async def update(
        self,
        scene_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> SceneResponse:
        """Fully update a scene.

        Args:
            scene_id: The scene identifier.
            name: New name.
            description: New description.

        Returns:
            Updated scene response.
        """
        request = UpdateSceneRequest(
            name=name,
            description=description,
        )
        return await self._http.request(
            "PUT",
            f"{_BASE}/{scene_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=SceneResponse,
        )

    async def patch(
        self,
        scene_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        parameters: Optional[Union[SceneParameters, Dict[str, Any]]] = None,
    ) -> SceneResponse:
        """Partially update a scene.

        Args:
            scene_id: The scene identifier.
            name: New name.
            description: New description.
            parameters: Partial parameters to merge.

        Returns:
            Updated scene response.
        """
        if isinstance(parameters, dict):
            parameters = SceneParameters(**parameters)
        request = PatchSceneRequest(
            name=name,
            description=description,
            parameters=parameters,
        )
        return await self._http.request(
            "PATCH",
            f"{_BASE}/{scene_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=SceneResponse,
        )

    async def delete(self, scene_id: str) -> MessageResponse:
        """Delete a scene.

        Args:
            scene_id: The scene identifier.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"{_BASE}/{scene_id}",
            response_model=MessageResponse,
        )

    # ------ Actions ------

    async def generate(self, scene_id: str) -> SceneResponse:
        """Trigger scene generation.

        Args:
            scene_id: The scene identifier.

        Returns:
            Updated scene response.
        """
        return await self._http.request(
            "POST",
            f"{_BASE}/{scene_id}/generate",
            response_model=SceneResponse,
        )

    async def cancel(self, scene_id: str) -> SceneResponse:
        """Cancel a running scene generation.

        Args:
            scene_id: The scene identifier.

        Returns:
            Updated scene response.
        """
        return await self._http.request(
            "POST",
            f"{_BASE}/{scene_id}/cancel",
            response_model=SceneResponse,
        )

    async def find_similar(
        self,
        environment_id: str,
        parameters: Union[SceneParameters, Dict[str, Any]],
    ) -> SimilarSceneResponse:
        """Find scenes with similar parameters.

        Args:
            environment_id: Parent environment ID.
            parameters: Parameters to match against.

        Returns:
            List of similar scenes.
        """
        if isinstance(parameters, dict):
            parameters = SceneParameters(**parameters)
        body: Dict[str, Any] = {
            "environment_id": environment_id,
            "parameters": parameters.model_dump(exclude_none=True),
        }
        return await self._http.request(
            "POST",
            f"{_BASE}/similar",
            json_data=body,
            response_model=SimilarSceneResponse,
        )

    async def storage(self, scene_id: str) -> StorageStatsResponse:
        """Get storage statistics for a scene.

        Args:
            scene_id: The scene identifier.

        Returns:
            Storage statistics.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{scene_id}/storage",
            response_model=StorageStatsResponse,
        )

    # ------ Execution operations ------

    async def create_execution(
        self,
        scene_id: str,
        name: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> ExecutionResponse:
        """Create a new execution for a scene.

        Args:
            scene_id: The scene identifier.
            name: Optional execution name.
            parameters: Optional execution parameters.

        Returns:
            Created execution response.
        """
        request = CreateExecutionRequest(
            name=name,
            parameters=parameters,
        )
        return await self._http.request(
            "POST",
            f"{_BASE}/{scene_id}/executions",
            json_data=request.model_dump(exclude_none=True),
            response_model=ExecutionResponse,
        )

    async def list_executions(
        self,
        scene_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedExecutionResponse:
        """List executions for a scene.

        Args:
            scene_id: The scene identifier.
            limit: Maximum results per page.
            offset: Number of results to skip.

        Returns:
            Paginated list of executions.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{scene_id}/executions",
            params={"limit": limit, "offset": offset},
            response_model=PaginatedExecutionResponse,
        )

    # ------ File operations ------

    async def list_files(
        self,
        scene_id: str,
        subdir: Optional[str] = None,
    ) -> SceneFilesResponse:
        """List files in a scene.

        Args:
            scene_id: The scene identifier.
            subdir: Optional subdirectory filter.

        Returns:
            List of scene files.
        """
        return await self._files.list_files(  # type: ignore[return-value]
            scene_id, subdir, SceneFilesResponse
        )

    async def get_download_url(
        self, scene_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            scene_id: The scene identifier.
            file_id: The file identifier.

        Returns:
            Signed download URL response.
        """
        return await self._files.get_download_url(scene_id, file_id)

    async def download(
        self,
        scene_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            scene_id: The scene identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.
        """
        return await self._files.download(scene_id, file_id, destination)

    async def download_batch(
        self,
        scene_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for a scene.

        Args:
            scene_id: The scene identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.
        """
        return await self._files.download_batch(
            scene_id, destination_dir, subdir
        )

    # ------ Upload operations ------

    async def initiate_upload(
        self,
        scene_id: str,
        filename: str,
        content_type: Optional[str] = None,
        purpose: Optional[str] = None,
    ) -> SceneUploadResponse:
        """Initiate a file upload session.

        Args:
            scene_id: The scene identifier.
            filename: Name of the file to upload.
            content_type: Optional MIME type override.
            purpose: Upload purpose (trajectory, etc.).

        Returns:
            Upload session with signed URL.
        """
        result = await self._uploads.initiate_upload(
            scene_id,
            filename,
            content_type,
            SceneUploadResponse,
        )
        return result  # type: ignore[no-any-return]

    async def complete_upload(
        self,
        scene_id: str,
        upload_id: str,
        purpose: Optional[str] = None,
    ) -> SceneUploadCompleteResponse:
        """Mark an upload session as complete.

        Args:
            scene_id: The scene identifier.
            upload_id: The upload session identifier.
            purpose: Optional purpose query param.

        Returns:
            Completed upload response.
        """
        result = await self._uploads.complete_upload(
            scene_id,
            upload_id,
            purpose=purpose,
            response_model=SceneUploadCompleteResponse,
        )
        return result  # type: ignore[no-any-return]

    async def upload(
        self,
        scene_id: str,
        file_path: Union[str, Path],
        content_type: Optional[str] = None,
        purpose: Optional[str] = None,
    ) -> SceneUploadCompleteResponse:
        """Upload a file end-to-end.

        Args:
            scene_id: The scene identifier.
            file_path: Local path to the file.
            content_type: Optional MIME type override.
            purpose: Optional purpose tag.

        Returns:
            Completed upload response.
        """
        return await self._uploads.upload(  # type: ignore[no-any-return]
            scene_id,
            file_path,
            content_type,
            purpose=purpose,
            initiate_model=SceneUploadResponse,
            complete_model=SceneUploadCompleteResponse,
        )

    # ------ Share operations ------

    async def create_share(
        self,
        scene_id: str,
        shared_with_type: ShareTargetType,
        shared_with_id: str,
        permission_level: PermissionLevel,
    ) -> ShareResponse:
        """Create a share for a scene.

        Args:
            scene_id: The scene identifier.
            shared_with_type: Target type (user/team/org).
            shared_with_id: Target entity identifier.
            permission_level: Permission (view/use/full).

        Returns:
            The created share record.
        """
        return await self._shares.create_share(
            scene_id,
            shared_with_type,
            shared_with_id,
            permission_level,
        )

    async def list_shares(
        self,
        scene_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedShareResponse:
        """List shares for a scene.

        Args:
            scene_id: The scene identifier.
            limit: Maximum number of results.
            offset: Number of results to skip.

        Returns:
            Paginated list of share records.
        """
        return await self._shares.list_shares(scene_id, limit, offset)

    async def revoke_share(
        self, scene_id: str, share_id: str
    ) -> MessageResponse:
        """Revoke a share for a scene.

        Args:
            scene_id: The scene identifier.
            share_id: The share identifier to revoke.

        Returns:
            Confirmation message response.
        """
        return await self._shares.revoke_share(scene_id, share_id)
