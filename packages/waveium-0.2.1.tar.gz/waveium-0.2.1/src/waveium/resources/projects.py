"""Project resource for the Waveium SDK."""

from typing import Optional

from ..models.common import MessageResponse, ProjectMemberType, ProjectRole
from ..models.projects import (
    AddProjectEnvironmentRequest,
    AddProjectMemberRequest,
    CreateProjectRequest,
    PaginatedProjectEnvironmentResponse,
    PaginatedProjectMemberResponse,
    PaginatedProjectResponse,
    ProjectEnvironmentResponse,
    ProjectMemberResponse,
    ProjectResponse,
    UpdateProjectMemberRequest,
    UpdateProjectRequest,
)
from ._base import AsyncBaseResource, BaseResource

_BASE = "/v0/projects"


class ProjectsResource(BaseResource):
    """Synchronous project operations."""

    def create(
        self,
        name: str,
        description: Optional[str] = None,
    ) -> ProjectResponse:
        """Create a new project.

        Args:
            name: Project name.
            description: Optional project description.

        Returns:
            Created project details.
        """
        request = CreateProjectRequest(name=name, description=description)
        return self._http.request(
            "POST",
            _BASE,
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectResponse,
        )

    def list(
        self, limit: int = 50, offset: int = 0
    ) -> PaginatedProjectResponse:
        """List projects with pagination.

        Args:
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of projects.
        """
        return self._http.request(
            "GET",
            _BASE,
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedProjectResponse,
        )

    def get(self, project_id: str) -> ProjectResponse:
        """Get a project by ID.

        Args:
            project_id: Project ID.

        Returns:
            Project details.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{project_id}",
            response_model=ProjectResponse,
        )

    def update(
        self,
        project_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> ProjectResponse:
        """Update a project.

        Args:
            project_id: Project ID.
            name: New project name.
            description: New project description.

        Returns:
            Updated project details.
        """
        request = UpdateProjectRequest(name=name, description=description)
        return self._http.request(
            "PUT",
            f"{_BASE}/{project_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectResponse,
        )

    def delete(self, project_id: str) -> MessageResponse:
        """Delete a project.

        Args:
            project_id: Project ID.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"{_BASE}/{project_id}",
            response_model=MessageResponse,
        )

    # -- Members --

    def list_members(
        self,
        project_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedProjectMemberResponse:
        """List project members with pagination.

        Args:
            project_id: Project ID.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of project members.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{project_id}/members",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=(PaginatedProjectMemberResponse),
        )

    def add_member(
        self,
        project_id: str,
        member_type: ProjectMemberType,
        member_id: str,
        role: Optional[ProjectRole] = None,
    ) -> ProjectMemberResponse:
        """Add a member to a project.

        Args:
            project_id: Project ID.
            member_type: Type of member (user or team).
            member_id: User ID or Team ID.
            role: Member role (owner, admin, member).

        Returns:
            Project member details.
        """
        request = AddProjectMemberRequest(
            member_type=member_type,
            member_id=member_id,
            role=role,
        )
        return self._http.request(
            "POST",
            f"{_BASE}/{project_id}/members",
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectMemberResponse,
        )

    def update_member(
        self,
        project_id: str,
        member_id: str,
        role: ProjectRole,
    ) -> ProjectMemberResponse:
        """Update a project member's role.

        Args:
            project_id: Project ID.
            member_id: Member record ID.
            role: New role (owner, admin, member).

        Returns:
            Updated project member details.
        """
        request = UpdateProjectMemberRequest(role=role)
        return self._http.request(
            "PUT",
            (f"{_BASE}/{project_id}" f"/members/{member_id}"),
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectMemberResponse,
        )

    def remove_member(self, project_id: str, member_id: str) -> MessageResponse:
        """Remove a member from a project.

        Args:
            project_id: Project ID.
            member_id: Member record ID.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            (f"{_BASE}/{project_id}" f"/members/{member_id}"),
            response_model=MessageResponse,
        )

    # -- Environments --

    def list_environments(
        self,
        project_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedProjectEnvironmentResponse:
        """List project environments with pagination.

        Args:
            project_id: Project ID.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of project environments.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{project_id}/environments",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=(PaginatedProjectEnvironmentResponse),
        )

    def add_environment(
        self,
        project_id: str,
        environment_id: str,
    ) -> ProjectEnvironmentResponse:
        """Add an environment to a project.

        Args:
            project_id: Project ID.
            environment_id: Environment ID to add.

        Returns:
            Project environment details.
        """
        request = AddProjectEnvironmentRequest(environment_id=environment_id)
        return self._http.request(
            "POST",
            f"{_BASE}/{project_id}/environments",
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectEnvironmentResponse,
        )

    def remove_environment(
        self, project_id: str, environment_id: str
    ) -> MessageResponse:
        """Remove an environment from a project.

        Args:
            project_id: Project ID.
            environment_id: Environment ID to remove.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            (f"{_BASE}/{project_id}" f"/environments/{environment_id}"),
            response_model=MessageResponse,
        )


class AsyncProjectsResource(AsyncBaseResource):
    """Asynchronous project operations."""

    async def create(
        self,
        name: str,
        description: Optional[str] = None,
    ) -> ProjectResponse:
        """Create a new project.

        Args:
            name: Project name.
            description: Optional project description.

        Returns:
            Created project details.
        """
        request = CreateProjectRequest(name=name, description=description)
        return await self._http.request(
            "POST",
            _BASE,
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectResponse,
        )

    async def list(
        self, limit: int = 50, offset: int = 0
    ) -> PaginatedProjectResponse:
        """List projects with pagination.

        Args:
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of projects.
        """
        return await self._http.request(
            "GET",
            _BASE,
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=PaginatedProjectResponse,
        )

    async def get(self, project_id: str) -> ProjectResponse:
        """Get a project by ID.

        Args:
            project_id: Project ID.

        Returns:
            Project details.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{project_id}",
            response_model=ProjectResponse,
        )

    async def update(
        self,
        project_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
    ) -> ProjectResponse:
        """Update a project.

        Args:
            project_id: Project ID.
            name: New project name.
            description: New project description.

        Returns:
            Updated project details.
        """
        request = UpdateProjectRequest(name=name, description=description)
        return await self._http.request(
            "PUT",
            f"{_BASE}/{project_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectResponse,
        )

    async def delete(self, project_id: str) -> MessageResponse:
        """Delete a project.

        Args:
            project_id: Project ID.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"{_BASE}/{project_id}",
            response_model=MessageResponse,
        )

    # -- Members --

    async def list_members(
        self,
        project_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedProjectMemberResponse:
        """List project members with pagination.

        Args:
            project_id: Project ID.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of project members.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{project_id}/members",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=(PaginatedProjectMemberResponse),
        )

    async def add_member(
        self,
        project_id: str,
        member_type: ProjectMemberType,
        member_id: str,
        role: Optional[ProjectRole] = None,
    ) -> ProjectMemberResponse:
        """Add a member to a project.

        Args:
            project_id: Project ID.
            member_type: Type of member (user or team).
            member_id: User ID or Team ID.
            role: Member role (owner, admin, member).

        Returns:
            Project member details.
        """
        request = AddProjectMemberRequest(
            member_type=member_type,
            member_id=member_id,
            role=role,
        )
        return await self._http.request(
            "POST",
            f"{_BASE}/{project_id}/members",
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectMemberResponse,
        )

    async def update_member(
        self,
        project_id: str,
        member_id: str,
        role: ProjectRole,
    ) -> ProjectMemberResponse:
        """Update a project member's role.

        Args:
            project_id: Project ID.
            member_id: Member record ID.
            role: New role (owner, admin, member).

        Returns:
            Updated project member details.
        """
        request = UpdateProjectMemberRequest(role=role)
        return await self._http.request(
            "PUT",
            (f"{_BASE}/{project_id}" f"/members/{member_id}"),
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectMemberResponse,
        )

    async def remove_member(
        self, project_id: str, member_id: str
    ) -> MessageResponse:
        """Remove a member from a project.

        Args:
            project_id: Project ID.
            member_id: Member record ID.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            (f"{_BASE}/{project_id}" f"/members/{member_id}"),
            response_model=MessageResponse,
        )

    # -- Environments --

    async def list_environments(
        self,
        project_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedProjectEnvironmentResponse:
        """List project environments with pagination.

        Args:
            project_id: Project ID.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            Paginated list of project environments.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{project_id}/environments",
            params={
                "limit": limit,
                "offset": offset,
            },
            response_model=(PaginatedProjectEnvironmentResponse),
        )

    async def add_environment(
        self,
        project_id: str,
        environment_id: str,
    ) -> ProjectEnvironmentResponse:
        """Add an environment to a project.

        Args:
            project_id: Project ID.
            environment_id: Environment ID to add.

        Returns:
            Project environment details.
        """
        request = AddProjectEnvironmentRequest(environment_id=environment_id)
        return await self._http.request(
            "POST",
            f"{_BASE}/{project_id}/environments",
            json_data=request.model_dump(exclude_none=True),
            response_model=ProjectEnvironmentResponse,
        )

    async def remove_environment(
        self, project_id: str, environment_id: str
    ) -> MessageResponse:
        """Remove an environment from a project.

        Args:
            project_id: Project ID.
            environment_id: Environment ID to remove.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            (f"{_BASE}/{project_id}" f"/environments/{environment_id}"),
            response_model=MessageResponse,
        )
