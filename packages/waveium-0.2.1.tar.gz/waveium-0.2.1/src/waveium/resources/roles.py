"""Role resource for the Waveium SDK."""

from typing import Any, Dict, List, Optional

from ..models.roles import RoleDetailResponse, RoleResponse
from ._base import AsyncBaseResource, BaseResource


class RolesResource(BaseResource):
    """Synchronous role operations."""

    def list(
        self,
        scope: Optional[str] = None,
        is_system_role: Optional[bool] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[RoleResponse]:
        """List available roles.

        Args:
            scope: Filter by scope (e.g. system,
                organization).
            is_system_role: Filter by system role flag.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            List of role details.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if scope:
            params["scope"] = scope
        if is_system_role is not None:
            params["is_system_role"] = is_system_role
        result = self._http.request("GET", "/roles", params=params)
        return [RoleResponse.model_validate(item) for item in result]

    def get(self, role_id: str) -> RoleDetailResponse:
        """Get a role with its permissions.

        Args:
            role_id: Role ID.

        Returns:
            Role details including permissions.
        """
        return self._http.request(
            "GET",
            f"/roles/{role_id}",
            response_model=RoleDetailResponse,
        )


class AsyncRolesResource(AsyncBaseResource):
    """Asynchronous role operations."""

    async def list(
        self,
        scope: Optional[str] = None,
        is_system_role: Optional[bool] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> List[RoleResponse]:
        """List available roles.

        Args:
            scope: Filter by scope (e.g. system,
                organization).
            is_system_role: Filter by system role flag.
            limit: Maximum items to return.
            offset: Number of items to skip.

        Returns:
            List of role details.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if scope:
            params["scope"] = scope
        if is_system_role is not None:
            params["is_system_role"] = is_system_role
        result = await self._http.request("GET", "/roles", params=params)
        return [RoleResponse.model_validate(item) for item in result]

    async def get(self, role_id: str) -> RoleDetailResponse:
        """Get a role with its permissions.

        Args:
            role_id: Role ID.

        Returns:
            Role details including permissions.
        """
        return await self._http.request(
            "GET",
            f"/roles/{role_id}",
            response_model=RoleDetailResponse,
        )
