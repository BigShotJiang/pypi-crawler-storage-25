"""Environment resource for the Waveium SDK."""

from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    Optional,
    Union,
)

from ..models.common import (
    EnvironmentType,
    MessageResponse,
    PermissionLevel,
    ScopeFilter,
    ShareTargetType,
    StorageStatsResponse,
)
from ..models.environments import (
    CreateEnvironmentRequest,
    CreateEnvironmentResponse,
    EnvironmentResponse,
    EnvironmentUploadCompleteResponse,
    EnvironmentUploadResponse,
    PaginatedEnvironmentResponse,
    SimilarEnvironmentResponse,
    UpdateEnvironmentRequest,
)
from ..models.files import (
    BatchDownloadResponse,
    EnvironmentFilesResponse,
    FileDownloadResponse,
)
from ..models.events import TERMINAL_STATUSES, ServerEvent
from ..models.shares import (
    PaginatedShareResponse,
    ShareResponse,
)
from ._base import AsyncBaseResource, BaseResource
from ._file_ops import AsyncFileOperations, FileOperations
from ._share_ops import AsyncShareOperations, ShareOperations
from ._stream_ops import (
    AsyncEventStream,
    AsyncStreamOperations,
    EventStream,
    StreamOperations,
)
from ._upload_ops import (
    AsyncUploadOperations,
    UploadOperations,
)

if TYPE_CHECKING:
    from .._http import AsyncHTTPClient, HTTPClient

_BASE = "/v0/environments"
_SSE_PATH = "/v0/events/environments/{resource_id}"


class EnvironmentsResource(BaseResource):
    """Synchronous environment operations."""

    def __init__(self, http_client: "HTTPClient") -> None:
        super().__init__(http_client)
        self._files = FileOperations(http_client, _BASE)
        self._uploads = UploadOperations(http_client, _BASE)
        self._shares = ShareOperations(http_client, _BASE)
        self._streams = StreamOperations(http_client, _SSE_PATH)

    # ------ Streaming ------

    def stream(
        self,
        environment_id: str,
        *,
        max_total_seconds: float = 7200.0,
    ) -> EventStream:
        """Stream real-time SSE events for an environment.

        Args:
            environment_id: The environment identifier.
            max_total_seconds: Maximum total stream duration.

        Returns:
            An EventStream yielding typed ServerEvent instances.
        """
        return self._streams.stream(
            environment_id,
            max_total_seconds=max_total_seconds,
        )

    def wait(
        self,
        environment_id: str,
        *,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> EnvironmentResponse:
        """Block until environment generation completes.

        Args:
            environment_id: The environment identifier.
            timeout: Maximum wait time in seconds.
            on_event: Optional callback for each event.

        Returns:
            The final EnvironmentResponse after completion.

        Raises:
            StreamTimeoutError: If timeout is exceeded.
        """
        # Pre-check: if already terminal, return immediately
        current = self.get(environment_id)
        if current.status in TERMINAL_STATUSES:
            return current

        self._streams.wait(
            environment_id,
            timeout=timeout,
            on_event=on_event,
        )
        return self.get(environment_id)

    # ------ CRUD ------

    def create(
        self,
        name: str,
        environment_type: EnvironmentType = "outdoor",
        description: Optional[str] = None,
        bounds: Optional[Dict[str, Any]] = None,
        track_file_id: Optional[str] = None,
        route: Optional[Dict[str, Any]] = None,
        margin: Optional[float] = None,
        auto_create_scene: Optional[bool] = None,
        scene_name: Optional[str] = None,
        stations: Optional[Dict[str, Any]] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> CreateEnvironmentResponse:
        """Create a new environment.

        Args:
            name: Environment name.
            environment_type: outdoor, indoor, underground.
            description: Optional description.
            bounds: Direct WGS84 bounding box.
            track_file_id: Uploaded track file ID.
            route: Address-based route definition.
            margin: Margin in metres (0-1000).
            auto_create_scene: Auto-create a scene.
            scene_name: Name for auto-created scene.
            stations: Station positions mapping.
            parameters: Type-specific generation params.

        Returns:
            Created (or reused) environment response.
        """
        request = CreateEnvironmentRequest(
            name=name,
            environment_type=environment_type,
            description=description,
            bounds=bounds,  # type: ignore[arg-type]
            track_file_id=track_file_id,
            route=route,  # type: ignore[arg-type]
            margin=margin,
            auto_create_scene=auto_create_scene,
            scene_name=scene_name,
            stations=stations,
            parameters=parameters,
        )
        return self._http.request(
            "POST",
            _BASE,
            json_data=request.model_dump(exclude_none=True),
            response_model=CreateEnvironmentResponse,
        )

    def list(
        self,
        limit: int = 50,
        offset: int = 0,
        status: Optional[str] = None,
        environment_type: Optional[EnvironmentType] = None,
        scope: Optional[ScopeFilter] = None,
    ) -> PaginatedEnvironmentResponse:
        """List environments with optional filters.

        Args:
            limit: Maximum results per page.
            offset: Number of results to skip.
            status: Filter by status.
            environment_type: Filter by type.
            scope: Filter scope (mine/shared/org).

        Returns:
            Paginated list of environments.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if status:
            params["status"] = status
        if environment_type:
            params["environment_type"] = environment_type
        if scope:
            params["scope"] = scope
        return self._http.request(
            "GET",
            _BASE,
            params=params,
            response_model=PaginatedEnvironmentResponse,
        )

    def get(
        self,
        environment_id: str,
        sync: Optional[bool] = None,
    ) -> EnvironmentResponse:
        """Get a single environment by ID.

        Args:
            environment_id: The environment identifier.
            sync: Whether to synchronise status first.

        Returns:
            Full environment response.
        """
        params: Dict[str, Any] = {}
        if sync is not None:
            params["sync"] = sync
        return self._http.request(
            "GET",
            f"{_BASE}/{environment_id}",
            params=params if params else None,
            response_model=EnvironmentResponse,
        )

    def update(
        self,
        environment_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> EnvironmentResponse:
        """Update an environment.

        Args:
            environment_id: The environment identifier.
            name: New name.
            description: New description.
            parameters: Updated generation parameters.

        Returns:
            Updated environment response.
        """
        request = UpdateEnvironmentRequest(
            name=name,
            description=description,
            parameters=parameters,
        )
        return self._http.request(
            "PUT",
            f"{_BASE}/{environment_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=EnvironmentResponse,
        )

    def delete(self, environment_id: str) -> MessageResponse:
        """Delete an environment.

        Args:
            environment_id: The environment identifier.

        Returns:
            Confirmation message.
        """
        return self._http.request(
            "DELETE",
            f"{_BASE}/{environment_id}",
            response_model=MessageResponse,
        )

    # ------ Actions ------

    def cancel(self, environment_id: str) -> EnvironmentResponse:
        """Cancel a running environment generation.

        Args:
            environment_id: The environment identifier.

        Returns:
            Updated environment response.
        """
        return self._http.request(
            "POST",
            f"{_BASE}/{environment_id}/cancel",
            response_model=EnvironmentResponse,
        )

    def find_similar(
        self,
        environment_type: EnvironmentType,
        area: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
        building_margin: Optional[float] = None,
    ) -> SimilarEnvironmentResponse:
        """Find environments with similar parameters.

        Args:
            environment_type: Type to search for.
            area: Geographic area filter.
            start: Route start address.
            end: Route end address.
            building_margin: Building margin filter.

        Returns:
            List of similar environments.
        """
        params: Dict[str, Any] = {
            "environment_type": environment_type,
        }
        if area:
            params["area"] = area
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        if building_margin is not None:
            params["building_margin"] = building_margin
        return self._http.request(
            "GET",
            f"{_BASE}/similar",
            params=params,
            response_model=SimilarEnvironmentResponse,
        )

    def storage(self, environment_id: str) -> StorageStatsResponse:
        """Get storage statistics for an environment.

        Args:
            environment_id: The environment identifier.

        Returns:
            Storage statistics.
        """
        return self._http.request(
            "GET",
            f"{_BASE}/{environment_id}/storage",
            response_model=StorageStatsResponse,
        )

    # ------ File operations ------

    def list_files(
        self,
        environment_id: str,
        subdir: Optional[str] = None,
    ) -> EnvironmentFilesResponse:
        """List files in an environment.

        Args:
            environment_id: The environment identifier.
            subdir: Optional subdirectory filter.

        Returns:
            List of environment files.
        """
        return self._files.list_files(  # type: ignore[return-value]
            environment_id, subdir, EnvironmentFilesResponse
        )

    def get_download_url(
        self, environment_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            environment_id: The environment identifier.
            file_id: The file identifier.

        Returns:
            Signed download URL response.
        """
        return self._files.get_download_url(environment_id, file_id)

    def download(
        self,
        environment_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            environment_id: The environment identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.
        """
        return self._files.download(environment_id, file_id, destination)

    def download_batch(
        self,
        environment_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for an environment.

        Args:
            environment_id: The environment identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.
        """
        return self._files.download_batch(
            environment_id, destination_dir, subdir
        )

    # ------ Upload operations ------

    def initiate_upload(
        self,
        environment_id: str,
        filename: str,
        content_type: Optional[str] = None,
    ) -> EnvironmentUploadResponse:
        """Initiate a file upload session.

        Args:
            environment_id: The environment identifier.
            filename: Name of the file to upload.
            content_type: Optional MIME type override.

        Returns:
            Upload session with signed URL.
        """
        return self._uploads.initiate_upload(  # type: ignore[no-any-return]
            environment_id,
            filename,
            content_type,
            EnvironmentUploadResponse,
        )

    def complete_upload(
        self, environment_id: str, upload_id: str
    ) -> EnvironmentUploadCompleteResponse:
        """Mark an upload session as complete.

        Args:
            environment_id: The environment identifier.
            upload_id: The upload session identifier.

        Returns:
            Completed upload response.
        """
        return self._uploads.complete_upload(  # type: ignore[no-any-return]
            environment_id,
            upload_id,
            response_model=EnvironmentUploadCompleteResponse,
        )

    def upload(
        self,
        environment_id: str,
        file_path: Union[str, Path],
        content_type: Optional[str] = None,
    ) -> EnvironmentUploadCompleteResponse:
        """Upload a file end-to-end.

        Args:
            environment_id: The environment identifier.
            file_path: Local path to the file.
            content_type: Optional MIME type override.

        Returns:
            Completed upload response.
        """
        return self._uploads.upload(  # type: ignore[no-any-return]
            environment_id,
            file_path,
            content_type,
            initiate_model=EnvironmentUploadResponse,
            complete_model=EnvironmentUploadCompleteResponse,
        )

    # ------ Share operations ------

    def create_share(
        self,
        environment_id: str,
        shared_with_type: ShareTargetType,
        shared_with_id: str,
        permission_level: PermissionLevel,
    ) -> ShareResponse:
        """Create a share for an environment.

        Args:
            environment_id: The environment identifier.
            shared_with_type: Target type (user/team/org).
            shared_with_id: Target entity identifier.
            permission_level: Permission (view/use/full).

        Returns:
            The created share record.
        """
        return self._shares.create_share(
            environment_id,
            shared_with_type,
            shared_with_id,
            permission_level,
        )

    def list_shares(
        self,
        environment_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedShareResponse:
        """List shares for an environment.

        Args:
            environment_id: The environment identifier.
            limit: Maximum number of results.
            offset: Number of results to skip.

        Returns:
            Paginated list of share records.
        """
        return self._shares.list_shares(environment_id, limit, offset)

    def revoke_share(
        self, environment_id: str, share_id: str
    ) -> MessageResponse:
        """Revoke a share for an environment.

        Args:
            environment_id: The environment identifier.
            share_id: The share identifier to revoke.

        Returns:
            Confirmation message response.
        """
        return self._shares.revoke_share(environment_id, share_id)


class AsyncEnvironmentsResource(AsyncBaseResource):
    """Asynchronous environment operations."""

    def __init__(self, http_client: "AsyncHTTPClient") -> None:
        super().__init__(http_client)
        self._files = AsyncFileOperations(http_client, _BASE)
        self._uploads = AsyncUploadOperations(http_client, _BASE)
        self._shares = AsyncShareOperations(http_client, _BASE)
        self._streams = AsyncStreamOperations(http_client, _SSE_PATH)

    # ------ Streaming ------

    def stream(
        self,
        environment_id: str,
        *,
        max_total_seconds: float = 7200.0,
    ) -> AsyncEventStream:
        """Stream real-time SSE events for an environment.

        Args:
            environment_id: The environment identifier.
            max_total_seconds: Maximum total stream duration.

        Returns:
            An AsyncEventStream yielding typed ServerEvent instances.
        """
        return self._streams.stream(
            environment_id,
            max_total_seconds=max_total_seconds,
        )

    async def wait(
        self,
        environment_id: str,
        *,
        timeout: float = 3600.0,
        on_event: Optional[Callable[[ServerEvent], None]] = None,
    ) -> EnvironmentResponse:
        """Block until environment generation completes.

        Args:
            environment_id: The environment identifier.
            timeout: Maximum wait time in seconds.
            on_event: Optional callback for each event.

        Returns:
            The final EnvironmentResponse after completion.

        Raises:
            StreamTimeoutError: If timeout is exceeded.
        """
        # Pre-check: if already terminal, return immediately
        current = await self.get(environment_id)
        if current.status in TERMINAL_STATUSES:
            return current

        await self._streams.wait(
            environment_id,
            timeout=timeout,
            on_event=on_event,
        )
        return await self.get(environment_id)

    # ------ CRUD ------

    async def create(
        self,
        name: str,
        environment_type: EnvironmentType = "outdoor",
        description: Optional[str] = None,
        bounds: Optional[Dict[str, Any]] = None,
        track_file_id: Optional[str] = None,
        route: Optional[Dict[str, Any]] = None,
        margin: Optional[float] = None,
        auto_create_scene: Optional[bool] = None,
        scene_name: Optional[str] = None,
        stations: Optional[Dict[str, Any]] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> CreateEnvironmentResponse:
        """Create a new environment.

        Args:
            name: Environment name.
            environment_type: outdoor, indoor, underground.
            description: Optional description.
            bounds: Direct WGS84 bounding box.
            track_file_id: Uploaded track file ID.
            route: Address-based route definition.
            margin: Margin in metres (0-1000).
            auto_create_scene: Auto-create a scene.
            scene_name: Name for auto-created scene.
            stations: Station positions mapping.
            parameters: Type-specific generation params.

        Returns:
            Created (or reused) environment response.
        """
        request = CreateEnvironmentRequest(
            name=name,
            environment_type=environment_type,
            description=description,
            bounds=bounds,  # type: ignore[arg-type]
            track_file_id=track_file_id,
            route=route,  # type: ignore[arg-type]
            margin=margin,
            auto_create_scene=auto_create_scene,
            scene_name=scene_name,
            stations=stations,
            parameters=parameters,
        )
        return await self._http.request(
            "POST",
            _BASE,
            json_data=request.model_dump(exclude_none=True),
            response_model=CreateEnvironmentResponse,
        )

    async def list(
        self,
        limit: int = 50,
        offset: int = 0,
        status: Optional[str] = None,
        environment_type: Optional[EnvironmentType] = None,
        scope: Optional[ScopeFilter] = None,
    ) -> PaginatedEnvironmentResponse:
        """List environments with optional filters.

        Args:
            limit: Maximum results per page.
            offset: Number of results to skip.
            status: Filter by status.
            environment_type: Filter by type.
            scope: Filter scope (mine/shared/org).

        Returns:
            Paginated list of environments.
        """
        params: Dict[str, Any] = {
            "limit": limit,
            "offset": offset,
        }
        if status:
            params["status"] = status
        if environment_type:
            params["environment_type"] = environment_type
        if scope:
            params["scope"] = scope
        return await self._http.request(
            "GET",
            _BASE,
            params=params,
            response_model=PaginatedEnvironmentResponse,
        )

    async def get(
        self,
        environment_id: str,
        sync: Optional[bool] = None,
    ) -> EnvironmentResponse:
        """Get a single environment by ID.

        Args:
            environment_id: The environment identifier.
            sync: Whether to synchronise status first.

        Returns:
            Full environment response.
        """
        params: Dict[str, Any] = {}
        if sync is not None:
            params["sync"] = sync
        return await self._http.request(
            "GET",
            f"{_BASE}/{environment_id}",
            params=params if params else None,
            response_model=EnvironmentResponse,
        )

    async def update(
        self,
        environment_id: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> EnvironmentResponse:
        """Update an environment.

        Args:
            environment_id: The environment identifier.
            name: New name.
            description: New description.
            parameters: Updated generation parameters.

        Returns:
            Updated environment response.
        """
        request = UpdateEnvironmentRequest(
            name=name,
            description=description,
            parameters=parameters,
        )
        return await self._http.request(
            "PUT",
            f"{_BASE}/{environment_id}",
            json_data=request.model_dump(exclude_none=True),
            response_model=EnvironmentResponse,
        )

    async def delete(self, environment_id: str) -> MessageResponse:
        """Delete an environment.

        Args:
            environment_id: The environment identifier.

        Returns:
            Confirmation message.
        """
        return await self._http.request(
            "DELETE",
            f"{_BASE}/{environment_id}",
            response_model=MessageResponse,
        )

    # ------ Actions ------

    async def cancel(self, environment_id: str) -> EnvironmentResponse:
        """Cancel a running environment generation.

        Args:
            environment_id: The environment identifier.

        Returns:
            Updated environment response.
        """
        return await self._http.request(
            "POST",
            f"{_BASE}/{environment_id}/cancel",
            response_model=EnvironmentResponse,
        )

    async def find_similar(
        self,
        environment_type: EnvironmentType,
        area: Optional[str] = None,
        start: Optional[str] = None,
        end: Optional[str] = None,
        building_margin: Optional[float] = None,
    ) -> SimilarEnvironmentResponse:
        """Find environments with similar parameters.

        Args:
            environment_type: Type to search for.
            area: Geographic area filter.
            start: Route start address.
            end: Route end address.
            building_margin: Building margin filter.

        Returns:
            List of similar environments.
        """
        params: Dict[str, Any] = {
            "environment_type": environment_type,
        }
        if area:
            params["area"] = area
        if start:
            params["start"] = start
        if end:
            params["end"] = end
        if building_margin is not None:
            params["building_margin"] = building_margin
        return await self._http.request(
            "GET",
            f"{_BASE}/similar",
            params=params,
            response_model=SimilarEnvironmentResponse,
        )

    async def storage(self, environment_id: str) -> StorageStatsResponse:
        """Get storage statistics for an environment.

        Args:
            environment_id: The environment identifier.

        Returns:
            Storage statistics.
        """
        return await self._http.request(
            "GET",
            f"{_BASE}/{environment_id}/storage",
            response_model=StorageStatsResponse,
        )

    # ------ File operations ------

    async def list_files(
        self,
        environment_id: str,
        subdir: Optional[str] = None,
    ) -> EnvironmentFilesResponse:
        """List files in an environment.

        Args:
            environment_id: The environment identifier.
            subdir: Optional subdirectory filter.

        Returns:
            List of environment files.
        """
        return await self._files.list_files(  # type: ignore[return-value]
            environment_id, subdir, EnvironmentFilesResponse
        )

    async def get_download_url(
        self, environment_id: str, file_id: str
    ) -> FileDownloadResponse:
        """Get a signed download URL for a file.

        Args:
            environment_id: The environment identifier.
            file_id: The file identifier.

        Returns:
            Signed download URL response.
        """
        return await self._files.get_download_url(environment_id, file_id)

    async def download(
        self,
        environment_id: str,
        file_id: str,
        destination: Union[str, Path],
    ) -> Path:
        """Download a file to a local path.

        Args:
            environment_id: The environment identifier.
            file_id: The file identifier.
            destination: Local file path to write to.

        Returns:
            Path to the downloaded file.
        """
        return await self._files.download(environment_id, file_id, destination)

    async def download_batch(
        self,
        environment_id: str,
        destination_dir: Union[str, Path],
        subdir: Optional[str] = None,
    ) -> BatchDownloadResponse:
        """Download all files for an environment.

        Args:
            environment_id: The environment identifier.
            destination_dir: Local directory to write to.
            subdir: Optional subdirectory filter.

        Returns:
            Batch download response metadata.
        """
        return await self._files.download_batch(
            environment_id, destination_dir, subdir
        )

    # ------ Upload operations ------

    async def initiate_upload(
        self,
        environment_id: str,
        filename: str,
        content_type: Optional[str] = None,
    ) -> EnvironmentUploadResponse:
        """Initiate a file upload session.

        Args:
            environment_id: The environment identifier.
            filename: Name of the file to upload.
            content_type: Optional MIME type override.

        Returns:
            Upload session with signed URL.
        """
        result = await self._uploads.initiate_upload(
            environment_id,
            filename,
            content_type,
            EnvironmentUploadResponse,
        )
        return result  # type: ignore[no-any-return]

    async def complete_upload(
        self, environment_id: str, upload_id: str
    ) -> EnvironmentUploadCompleteResponse:
        """Mark an upload session as complete.

        Args:
            environment_id: The environment identifier.
            upload_id: The upload session identifier.

        Returns:
            Completed upload response.
        """
        result = await self._uploads.complete_upload(
            environment_id,
            upload_id,
            response_model=EnvironmentUploadCompleteResponse,
        )
        return result  # type: ignore[no-any-return]

    async def upload(
        self,
        environment_id: str,
        file_path: Union[str, Path],
        content_type: Optional[str] = None,
    ) -> EnvironmentUploadCompleteResponse:
        """Upload a file end-to-end.

        Args:
            environment_id: The environment identifier.
            file_path: Local path to the file.
            content_type: Optional MIME type override.

        Returns:
            Completed upload response.
        """
        return await self._uploads.upload(  # type: ignore[no-any-return]
            environment_id,
            file_path,
            content_type,
            initiate_model=EnvironmentUploadResponse,
            complete_model=EnvironmentUploadCompleteResponse,
        )

    # ------ Share operations ------

    async def create_share(
        self,
        environment_id: str,
        shared_with_type: ShareTargetType,
        shared_with_id: str,
        permission_level: PermissionLevel,
    ) -> ShareResponse:
        """Create a share for an environment.

        Args:
            environment_id: The environment identifier.
            shared_with_type: Target type (user/team/org).
            shared_with_id: Target entity identifier.
            permission_level: Permission (view/use/full).

        Returns:
            The created share record.
        """
        return await self._shares.create_share(
            environment_id,
            shared_with_type,
            shared_with_id,
            permission_level,
        )

    async def list_shares(
        self,
        environment_id: str,
        limit: int = 50,
        offset: int = 0,
    ) -> PaginatedShareResponse:
        """List shares for an environment.

        Args:
            environment_id: The environment identifier.
            limit: Maximum number of results.
            offset: Number of results to skip.

        Returns:
            Paginated list of share records.
        """
        return await self._shares.list_shares(environment_id, limit, offset)

    async def revoke_share(
        self, environment_id: str, share_id: str
    ) -> MessageResponse:
        """Revoke a share for an environment.

        Args:
            environment_id: The environment identifier.
            share_id: The share identifier to revoke.

        Returns:
            Confirmation message response.
        """
        return await self._shares.revoke_share(environment_id, share_id)
