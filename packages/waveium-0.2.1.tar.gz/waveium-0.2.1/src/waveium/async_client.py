"""Asynchronous Waveium API client."""

from typing import Optional

from ._config import Config
from ._http import AsyncHTTPClient
from .resources import (
    AsyncAuthResource,
    AsyncEnvironmentsResource,
    AsyncExecutionsResource,
    AsyncOrganizationsResource,
    AsyncProjectsResource,
    AsyncRolesResource,
    AsyncScenesResource,
    AsyncTeamsResource,
    AsyncUsersResource,
)


class AsyncClient:
    """Asynchronous Waveium API client.

    Example:
        >>> import waveium
        >>> async with waveium.AsyncClient(
        ...     api_key="wvx_..."
        ... ) as client:
        ...     resp = await client.environments.create(
        ...         name="My Environment"
        ...     )
        ...     env = resp.environment
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        """Initialize async Waveium client.

        Args:
            api_key: API key for authentication. If not
                provided, will try to load from
                WAVEIUM_API_KEY environment variable.
            base_url: Base URL for the Waveium API.
                Defaults to production URL.
            timeout: Request timeout in seconds.
                Defaults to 60.0.
            max_retries: Maximum number of retries for
                failed requests. Defaults to 3.

        Raises:
            ConfigurationError: If configuration is invalid.
        """
        self._config = Config(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._config.validate()

        self._http = AsyncHTTPClient(self._config)

        # Initialize resources
        self.auth = AsyncAuthResource(self._http)
        self.environments = AsyncEnvironmentsResource(self._http)
        self.scenes = AsyncScenesResource(self._http)
        self.executions = AsyncExecutionsResource(self._http)
        self.users = AsyncUsersResource(self._http)
        self.organizations = AsyncOrganizationsResource(self._http)
        self.roles = AsyncRolesResource(self._http)
        self.teams = AsyncTeamsResource(self._http)
        self.projects = AsyncProjectsResource(self._http)

    async def close(self) -> None:
        """Close the HTTP client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> "AsyncClient":
        """Enter async context manager."""
        return self

    async def __aexit__(self, *args: object) -> None:
        """Exit async context manager."""
        await self.close()

    def __repr__(self) -> str:
        """Return string representation of client."""
        return f"<Waveium AsyncClient base_url=" f"{self._config.base_url}>"
