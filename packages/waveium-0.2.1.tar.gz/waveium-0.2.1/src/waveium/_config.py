"""Configuration management for the Waveium SDK."""

import os
from typing import Optional

from dotenv import load_dotenv

from .exceptions import ConfigurationError

# Load environment variables from .env file
load_dotenv()

# Default configuration
DEFAULT_BASE_URL = "https://api.waveium.io"
DEFAULT_TIMEOUT = 60.0
DEFAULT_MAX_RETRIES = 3


class Config:
    """Configuration for Waveium SDK."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        """Initialize configuration.

        Args:
            api_key: API key for authentication. If not provided,
                will try to load from WAVEIUM_API_KEY or WAVEIUM_SDK_TOKEN
                environment variable.
            base_url: Base URL for the Waveium API.
                Defaults to production URL.
            timeout: Request timeout in seconds. Defaults to 60.0.
            max_retries: Maximum number of retries for failed requests.
                Defaults to 3.

        Raises:
            ConfigurationError: If no API key is provided or found
                in environment.
        """
        self.api_key = (
            api_key
            or os.getenv("WAVEIUM_API_KEY")
            or os.getenv("WAVEIUM_SDK_TOKEN")
        )
        self.base_url = base_url or os.getenv(
            "WAVEIUM_BASE_URL", DEFAULT_BASE_URL
        ).rstrip("/")
        self.timeout = timeout or float(
            os.getenv("WAVEIUM_TIMEOUT", str(DEFAULT_TIMEOUT))
        )
        self.max_retries = max_retries or int(
            os.getenv("WAVEIUM_MAX_RETRIES", str(DEFAULT_MAX_RETRIES))
        )

    def validate(self) -> None:
        """Validate configuration.

        Raises:
            ConfigurationError: If configuration is invalid.
        """
        if not self.api_key:
            raise ConfigurationError(
                "API key is required. Provide it via api_key parameter or "
                "WAVEIUM_API_KEY/WAVEIUM_SDK_TOKEN environment variable."
            )

        if not self.base_url:
            raise ConfigurationError("Base URL cannot be empty")

        if self.timeout <= 0:
            raise ConfigurationError("Timeout must be positive")

        if self.max_retries < 0:
            raise ConfigurationError("Max retries cannot be negative")


def get_firebase_token() -> Optional[str]:
    """Get Firebase token from environment variable.

    Returns:
        Firebase token if found, None otherwise.
    """
    return os.getenv("FIREBASE_TOKEN")
