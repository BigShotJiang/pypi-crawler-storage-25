"""Waveium SDK for Python.

Official Python client library for the Waveium API.

Example:
    >>> import waveium
    >>> client = waveium.init(api_key="wvx_...")
    >>> resp = client.environments.create(name="My Env")
    >>> env = resp.environment
"""

from typing import Optional

from ._config import get_firebase_token
from .async_client import AsyncClient
from .client import Client
from .exceptions import (
    APIError,
    AuthenticationError,
    AuthorizationError,
    ConfigurationError,
    ConflictError,
    ExecutionFailedError,
    FileDownloadError,
    FileUploadError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    StreamError,
    StreamReconnectError,
    StreamTimeoutError,
    ValidationError,
    WaveiumError,
)

# Expose key models
from .models import (
    CreateEnvironmentRequest,
    CreateTokenRequest,
    EnvironmentResponse,
    ExecutionProgress,
    ExecutionResponse,
    SceneResponse,
    ServerEvent,
    StatusEvent,
    TokenExchangeResponse,
)

__version__ = "0.2.0"

__all__ = [
    # Main clients
    "Client",
    "AsyncClient",
    # Convenience functions
    "init",
    "auth",
    # Exceptions
    "WaveiumError",
    "AuthenticationError",
    "AuthorizationError",
    "ConflictError",
    "NotFoundError",
    "ValidationError",
    "RateLimitError",
    "APIError",
    "NetworkError",
    "FileUploadError",
    "FileDownloadError",
    "ConfigurationError",
    "StreamError",
    "StreamTimeoutError",
    "StreamReconnectError",
    "ExecutionFailedError",
    # Common models
    "CreateEnvironmentRequest",
    "CreateTokenRequest",
    "EnvironmentResponse",
    "ExecutionProgress",
    "ExecutionResponse",
    "SceneResponse",
    "ServerEvent",
    "StatusEvent",
    "TokenExchangeResponse",
    # Version
    "__version__",
]


def init(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
    max_retries: Optional[int] = None,
) -> Client:
    """Initialize a Waveium client with an API key.

    Args:
        api_key: API key for authentication. If not
            provided, will try to load from
            WAVEIUM_API_KEY environment variable.
        base_url: Base URL for the Waveium API.
            Defaults to production URL.
        timeout: Request timeout in seconds.
            Defaults to 60.0.
        max_retries: Maximum number of retries for
            failed requests. Defaults to 3.

    Returns:
        Configured Waveium client

    Raises:
        ConfigurationError: If configuration is invalid

    Example:
        >>> import waveium
        >>> client = waveium.init(api_key="wvx_...")
        >>> resp = client.environments.create(
        ...     name="Test"
        ... )
    """
    return Client(
        api_key=api_key,
        base_url=base_url,
        timeout=timeout,
        max_retries=max_retries,
    )


def auth(
    firebase_token: Optional[str] = None,
    token_name: str = "Python SDK Token",
    expires_days: int = 30,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
    max_retries: Optional[int] = None,
) -> Client:
    """Initialize a Waveium client by exchanging a
    Firebase JWT for an API key.

    Args:
        firebase_token: Firebase JWT token. If not
            provided, will try to load from
            FIREBASE_TOKEN environment variable.
        token_name: Name for the created API token.
            Defaults to "Python SDK Token".
        expires_days: Number of days until token
            expires (1-365). Defaults to 30.
        base_url: Base URL for the Waveium API.
            Defaults to production URL.
        timeout: Request timeout in seconds.
            Defaults to 60.0.
        max_retries: Maximum number of retries for
            failed requests. Defaults to 3.

    Returns:
        Configured Waveium client with API key

    Raises:
        ConfigurationError: If no Firebase token
            provided or found
        AuthenticationError: If Firebase token is invalid

    Example:
        >>> import waveium
        >>> client = waveium.auth(
        ...     firebase_token="eyJ..."
        ... )
        >>> resp = client.environments.create(
        ...     name="Test"
        ... )
    """
    if firebase_token is None:
        firebase_token = get_firebase_token()

    if firebase_token is None:
        raise ConfigurationError(
            "Firebase token is required. Provide it via "
            "firebase_token parameter or FIREBASE_TOKEN "
            "environment variable."
        )

    temp_client = Client(
        api_key=firebase_token,
        base_url=base_url,
        timeout=timeout,
        max_retries=max_retries,
    )

    try:
        response = temp_client.auth.create_token(
            name=token_name,
            expires_days=expires_days,
            firebase_token=firebase_token,
        )

        return Client(
            api_key=response.api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
    finally:
        temp_client.close()
