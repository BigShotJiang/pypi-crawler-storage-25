"""Synchronous Waveium API client."""

from typing import Optional

from ._config import Config
from ._http import HTTPClient
from .resources import (
    AuthResource,
    EnvironmentsResource,
    ExecutionsResource,
    OrganizationsResource,
    ProjectsResource,
    RolesResource,
    ScenesResource,
    TeamsResource,
    UsersResource,
)


class Client:
    """Synchronous Waveium API client.

    Example:
        >>> import waveium
        >>> client = waveium.Client(api_key="wvx_...")
        >>> resp = client.environments.create(
        ...     name="My Environment"
        ... )
        >>> env = resp.environment
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
    ) -> None:
        """Initialize Waveium client.

        Args:
            api_key: API key for authentication. If not
                provided, will try to load from
                WAVEIUM_API_KEY environment variable.
            base_url: Base URL for the Waveium API.
                Defaults to production URL.
            timeout: Request timeout in seconds.
                Defaults to 60.0.
            max_retries: Maximum number of retries for
                failed requests. Defaults to 3.

        Raises:
            ConfigurationError: If configuration is invalid.
        """
        self._config = Config(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._config.validate()

        self._http = HTTPClient(self._config)

        # Initialize resources
        self.auth = AuthResource(self._http)
        self.environments = EnvironmentsResource(self._http)
        self.scenes = ScenesResource(self._http)
        self.executions = ExecutionsResource(self._http)
        self.users = UsersResource(self._http)
        self.organizations = OrganizationsResource(self._http)
        self.roles = RolesResource(self._http)
        self.teams = TeamsResource(self._http)
        self.projects = ProjectsResource(self._http)

    def close(self) -> None:
        """Close the HTTP client and release resources."""
        self._http.close()

    def __enter__(self) -> "Client":
        """Enter context manager."""
        return self

    def __exit__(self, *args: object) -> None:
        """Exit context manager."""
        self.close()

    def __repr__(self) -> str:
        """Return string representation of client."""
        return f"<Waveium Client base_url=" f"{self._config.base_url}>"
