"""Role models for the Waveium SDK."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class PermissionResponse(BaseModel):
    """Permission details."""

    id: str = Field(description="Permission ID")
    name: str = Field(description="Permission name")
    resource: str = Field(description="Resource type")
    action: str = Field(description="Action")
    description: Optional[str] = Field(default=None, description="Description")
    created_at: datetime = Field(description="Created at")


class RoleResponse(BaseModel):
    """Role details."""

    id: str = Field(description="Role ID")
    name: str = Field(description="Role name")
    description: Optional[str] = Field(default=None, description="Description")
    scope: str = Field(description="Scope")
    is_system_role: bool = Field(description="Is system role")
    created_at: datetime = Field(description="Created at")


class RolePermissionResponse(BaseModel):
    """Role-permission mapping."""

    permission: PermissionResponse = Field(description="Permission details")


class RoleDetailResponse(BaseModel):
    """Role with permissions."""

    id: str = Field(description="Role ID")
    name: str = Field(description="Role name")
    description: Optional[str] = Field(default=None, description="Description")
    scope: str = Field(description="Scope")
    is_system_role: bool = Field(description="Is system role")
    created_at: datetime = Field(description="Created at")
    role_permissions: List[RolePermissionResponse] = Field(
        description="Permissions"
    )
