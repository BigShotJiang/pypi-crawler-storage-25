"""Scene models for the Waveium SDK."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .common import _fmt_dt, _tabulate


class SceneParameters(BaseModel):
    """Parameters for scene configuration."""

    stations: Optional[Dict[str, List[float]]] = Field(
        default=None, description="Station positions"
    )
    stations_file_id: Optional[str] = Field(
        default=None, description="Stations CSV file ID"
    )
    trajectory_file_ids: Optional[List[str]] = Field(
        default=None, description="Trajectory file IDs"
    )
    trajectory_file_id: Optional[str] = Field(
        default=None,
        description="Deprecated: single trajectory file ID",
    )
    route: Optional[Dict[str, Any]] = Field(
        default=None, description="Route parameters"
    )


class CreateSceneRequest(BaseModel):
    """Request to create a new scene."""

    environment_id: str = Field(description="Parent environment ID")
    name: str = Field(description="Scene name", min_length=1, max_length=255)
    description: Optional[str] = Field(
        default=None, description="Scene description"
    )
    parameters: SceneParameters = Field(description="Scene parameters")
    project_id: Optional[str] = Field(
        default=None, description="Optional project ID"
    )


class UpdateSceneRequest(BaseModel):
    """Request to fully update a scene."""

    name: Optional[str] = Field(
        default=None,
        description="New name",
        min_length=1,
        max_length=255,
    )
    description: Optional[str] = Field(
        default=None, description="New description"
    )


class PatchSceneRequest(BaseModel):
    """Request to partially update a scene."""

    name: Optional[str] = Field(
        default=None,
        description="New name",
        min_length=1,
        max_length=255,
    )
    description: Optional[str] = Field(
        default=None, description="New description"
    )
    parameters: Optional[SceneParameters] = Field(
        default=None,
        description="Partial parameters to merge",
    )


class SceneResponse(BaseModel):
    """Full scene response from the API."""

    scene_id: str = Field(description="Scene ID")
    environment_id: str = Field(description="Parent environment ID")
    organization_id: str = Field(description="Organization ID")
    created_by_user_id: Optional[str] = Field(
        default=None, description="Creator user ID"
    )
    project_id: Optional[str] = Field(default=None, description="Project ID")
    name: str = Field(description="Scene name")
    description: Optional[str] = Field(default=None, description="Description")
    parameters: Dict[str, Any] = Field(description="Scene parameters")
    parameters_hash: str = Field(description="Parameters hash")
    status: str = Field(description="Scene status")
    storage_path: str = Field(description="Storage path")
    storage_size_bytes: Optional[int] = Field(
        default=None, description="Storage size"
    )
    created_at: datetime = Field(description="Created at")
    started_at: Optional[datetime] = Field(
        default=None, description="Started at"
    )
    completed_at: Optional[datetime] = Field(
        default=None, description="Completed at"
    )
    exit_code: Optional[int] = Field(default=None, description="Exit code")
    error_message: Optional[str] = Field(
        default=None, description="Error message"
    )
    execution_count: Optional[int] = Field(
        default=None, description="Execution count"
    )
    reused: bool = Field(
        default=False,
        description="Whether existing was returned",
    )
    missing_inputs: Optional[List[str]] = Field(
        default=None,
        description="Missing inputs before queueing",
    )


class SceneListItem(BaseModel):
    """Summary item for scene listings."""

    scene_id: str = Field(description="Scene ID")
    environment_id: str = Field(description="Parent environment ID")
    project_id: Optional[str] = Field(default=None, description="Project ID")
    name: str = Field(description="Name")
    description: Optional[str] = Field(default=None, description="Description")
    status: str = Field(description="Status")
    created_at: datetime = Field(description="Created at")
    completed_at: Optional[datetime] = Field(
        default=None, description="Completed at"
    )
    execution_count: Optional[int] = Field(
        default=None, description="Execution count"
    )


class PaginatedSceneResponse(BaseModel):
    """Paginated list of scenes."""

    scenes: List[SceneListItem] = Field(description="List of scenes")
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")

    def __repr__(self) -> str:
        page = (self.offset // self.limit) + 1 if self.limit else 1
        total_pages = (
            (self.total + self.limit - 1) // self.limit if self.limit else 1
        )
        header = (
            f"PaginatedSceneResponse: {self.total} scenes"
            f" (page {page}/{total_pages})"
        )
        if not self.scenes:
            return header

        rows = []
        for scene in self.scenes:
            rows.append(
                (
                    scene.scene_id,
                    scene.status,
                    scene.name,
                    scene.environment_id,
                    _fmt_dt(scene.created_at),
                    (
                        str(scene.execution_count)
                        if scene.execution_count is not None
                        else "-"
                    ),
                )
            )

        table = _tabulate(
            ("ID", "Status", "Name", "Environment", "Created", "Execs"),
            rows,
        )
        return f"{header}\n{table}"


class SimilarSceneResponse(BaseModel):
    """Response listing similar scenes."""

    similar_scenes: List[SceneListItem] = Field(description="Similar scenes")
    parameters_hash: str = Field(description="Parameters hash")


class SceneUploadRequest(BaseModel):
    """Request to initiate a scene file upload."""

    filename: str = Field(description="Filename", min_length=1, max_length=255)
    content_type: Optional[str] = Field(
        default="application/gpx+xml", description="MIME type"
    )
    purpose: Optional[str] = Field(
        default=None,
        description=("Upload purpose: trajectory or ap_positions"),
    )


class SceneUploadResponse(BaseModel):
    """Response with signed upload URL for scene files."""

    upload_id: str = Field(description="Upload ID")
    upload_url: str = Field(description="Signed upload URL")
    method: str = Field(default="PUT", description="HTTP method")
    expires_at: datetime = Field(description="URL expiration")
    file_id: str = Field(description="File ID")


class SceneUploadCompleteResponse(BaseModel):
    """Response after completing a scene file upload."""

    file_id: str = Field(description="File ID")
    message: str = Field(description="Status message")
    queued: bool = Field(default=False, description="Deprecated: always false")
    missing_inputs: Optional[List[str]] = Field(
        default=None,
        description="Remaining required inputs",
    )
