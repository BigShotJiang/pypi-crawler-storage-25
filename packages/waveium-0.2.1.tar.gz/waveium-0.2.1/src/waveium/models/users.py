"""User models for the Waveium SDK."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from .common import PaginationInfo


class CreateUserRequest(BaseModel):
    """Request to create a user (admin only)."""

    email: str = Field(description="User email")
    organization_id: str = Field(description="Organization ID")
    name: Optional[str] = Field(default=None, description="User name")
    temporary_password: Optional[str] = Field(
        default=None, description="Temporary password"
    )


class UpdateOwnUserRequest(BaseModel):
    """Request to update own profile."""

    email: Optional[str] = Field(default=None, description="New email")
    name: Optional[str] = Field(default=None, description="New name")


class AdminUpdateUserRequest(BaseModel):
    """Request to update a user (admin only)."""

    email: Optional[str] = Field(default=None, description="New email")
    name: Optional[str] = Field(default=None, description="New name")
    is_active: Optional[bool] = Field(default=None, description="Active status")
    role_ids: Optional[List[str]] = Field(
        default=None, description="Role IDs to assign"
    )


class RoleInUserResponse(BaseModel):
    """Inline role info in user role response."""

    id: str = Field(description="Role ID")
    name: str = Field(description="Role name")
    description: Optional[str] = Field(default=None, description="Description")
    scope: str = Field(description="Scope")
    is_system_role: bool = Field(description="Is system role")
    created_at: datetime = Field(description="Created at")


class UserRoleResponse(BaseModel):
    """User role assignment."""

    id: str = Field(description="User role ID")
    role: RoleInUserResponse = Field(description="Role details")
    scope_type: str = Field(description="Scope type")
    scope_id: Optional[str] = Field(default=None, description="Scope ID")
    granted_at: datetime = Field(description="Granted at")
    expires_at: Optional[datetime] = Field(
        default=None, description="Expires at"
    )


class UserResponse(BaseModel):
    """User information."""

    id: str = Field(description="User ID")
    email: str = Field(description="Email")
    name: Optional[str] = Field(default=None, description="Name")
    organization_id: str = Field(description="Organization ID")
    is_active: bool = Field(description="Active status")
    created_at: datetime = Field(description="Created at")
    updated_at: Optional[datetime] = Field(
        default=None, description="Updated at"
    )
    last_login: Optional[datetime] = Field(
        default=None, description="Last login"
    )
    user_roles: Optional[List[UserRoleResponse]] = Field(
        default=None, description="User roles"
    )


class PaginatedUserResponse(BaseModel):
    """Paginated user list."""

    data: List[UserResponse] = Field(description="List of users")
    pagination: PaginationInfo = Field(description="Pagination info")
