"""File models for the Waveium SDK."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from .common import _tabulate


def _fmt_size(n: int) -> str:
    """Format byte count as human-readable size."""
    if n < 1024:
        return f"{n} B"
    elif n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    elif n < 1024 * 1024 * 1024:
        return f"{n / (1024 * 1024):.1f} MB"
    else:
        return f"{n / (1024 * 1024 * 1024):.2f} GB"


class FileInfo(BaseModel):
    """File metadata common to all resource types."""

    file_id: str = Field(description="URL-safe file identifier")
    filename: str = Field(description="Filename")
    subdir: str = Field(description="Subdirectory")
    file_size_bytes: int = Field(description="File size in bytes")
    checksum: Optional[str] = Field(default=None, description="File checksum")


def _files_repr(
    label: str,
    resource_id: str,
    total_files: int,
    total_size_bytes: int,
    files: List["FileInfo"],
) -> str:
    """Build a tabular repr for file list responses."""
    header = (
        f"{label}: {total_files} files, "
        f"{_fmt_size(total_size_bytes)} ({resource_id})"
    )
    if not files:
        return header

    rows = []
    for file_info in files:
        rows.append(
            (
                file_info.filename,
                file_info.subdir,
                _fmt_size(file_info.file_size_bytes),
            )
        )

    table = _tabulate(("Filename", "Subdir", "Size"), rows)
    return f"{header}\n{table}"


class EnvironmentFilesResponse(BaseModel):
    """List of files in an environment."""

    environment_id: str = Field(description="Environment ID")
    total_files: int = Field(description="Total file count")
    total_size_bytes: int = Field(description="Total size in bytes")
    files: List[FileInfo] = Field(description="List of files")

    def __repr__(self) -> str:
        return _files_repr(
            "EnvironmentFilesResponse",
            self.environment_id,
            self.total_files,
            self.total_size_bytes,
            self.files,
        )


class SceneFilesResponse(BaseModel):
    """List of files in a scene."""

    scene_id: str = Field(description="Scene ID")
    total_files: int = Field(description="Total file count")
    total_size_bytes: int = Field(description="Total size in bytes")
    files: List[FileInfo] = Field(description="List of files")

    def __repr__(self) -> str:
        return _files_repr(
            "SceneFilesResponse",
            self.scene_id,
            self.total_files,
            self.total_size_bytes,
            self.files,
        )


class ExecutionFilesResponse(BaseModel):
    """List of files in an execution."""

    execution_id: str = Field(description="Execution ID")
    total_files: int = Field(description="Total file count")
    total_size_bytes: int = Field(description="Total size in bytes")
    files: List[FileInfo] = Field(description="List of files")

    def __repr__(self) -> str:
        return _files_repr(
            "ExecutionFilesResponse",
            self.execution_id,
            self.total_files,
            self.total_size_bytes,
            self.files,
        )


class FileDownloadResponse(BaseModel):
    """Signed download URL for a file."""

    file_id: str = Field(description="File ID")
    filename: str = Field(description="Filename")
    download_url: str = Field(description="Signed download URL")
    method: str = Field(default="GET", description="HTTP method")
    expires_at: datetime = Field(description="URL expiration")
    file_size_bytes: int = Field(description="File size in bytes")
    checksum: Optional[str] = Field(default=None, description="File checksum")


class BatchDownloadFile(BaseModel):
    """File entry in a batch download response."""

    file_id: str = Field(description="File ID")
    filename: str = Field(description="Filename")
    subdir: Optional[str] = Field(default=None, description="Subdirectory")
    download_url: str = Field(description="Signed download URL")
    method: str = Field(default="GET", description="HTTP method")
    expires_at: datetime = Field(description="URL expiration")
    file_size_bytes: int = Field(description="File size in bytes")
    checksum: Optional[str] = Field(default=None, description="File checksum")


class BatchDownloadResponse(BaseModel):
    """Batch download response with signed URLs."""

    model_config = {"extra": "allow"}

    total_files: int = Field(description="Total file count")
    total_size_bytes: int = Field(description="Total size in bytes")
    expires_at: datetime = Field(description="URLs expiration")
    files: List[BatchDownloadFile] = Field(description="List of download URLs")


class ArchiveDownloadResponse(BaseModel):
    """Response for zip archive download."""

    download_url: str = Field(description="Signed GCS URL")
    filename: str = Field(description="Archive filename")
    size: int = Field(description="Archive size in bytes")
    expires_at: datetime = Field(description="URL expiration")
