"""Environment models for the Waveium SDK."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .common import EnvironmentType, _fmt_dt, _tabulate


class BoundsInput(BaseModel):
    """Bounding box input for environment creation."""

    min: List[float] = Field(description="Southwest corner [lat_min, lon_min]")
    max: List[float] = Field(description="Northeast corner [lat_max, lon_max]")


class RouteInput(BaseModel):
    """Address-based route input for environment creation."""

    start: str = Field(description="Start address")
    end: str = Field(description="End address")
    area: str = Field(description="Geographic area for geocoding")
    transport_mode: Optional[str] = Field(
        default="walk",
        description="Transport mode: walk, bike, drive",
    )


class CreateEnvironmentRequest(BaseModel):
    """Request to create a new environment."""

    name: str = Field(
        description="Environment name",
        min_length=1,
        max_length=255,
    )
    description: Optional[str] = Field(
        default=None, description="Environment description"
    )
    environment_type: Optional[EnvironmentType] = Field(
        default="outdoor",
        description="Type: outdoor, indoor, underground",
    )
    bounds: Optional[BoundsInput] = Field(
        default=None, description="Direct WGS84 bounding box"
    )
    track_file_id: Optional[str] = Field(
        default=None, description="Uploaded track file ID"
    )
    route: Optional[RouteInput] = Field(
        default=None, description="Address-based route"
    )
    margin: Optional[float] = Field(
        default=None,
        description="Margin in meters",
        ge=0,
        le=1000,
    )
    auto_create_scene: Optional[bool] = Field(
        default=None, description="Auto-create scene"
    )
    scene_name: Optional[str] = Field(
        default=None,
        description="Name for auto-created scene",
        max_length=255,
    )
    stations: Optional[Dict[str, List[float]]] = Field(
        default=None, description="Station positions"
    )
    parameters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Type-specific generation parameters",
    )


class UpdateEnvironmentRequest(BaseModel):
    """Request to update an existing environment."""

    name: Optional[str] = Field(
        default=None,
        description="New name",
        min_length=1,
        max_length=255,
    )
    description: Optional[str] = Field(
        default=None, description="New description"
    )
    parameters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Updated generation parameters",
    )


class EnvironmentResponse(BaseModel):
    """Full environment response from the API."""

    environment_id: str = Field(description="Environment ID")
    organization_id: str = Field(description="Organization ID")
    created_by_user_id: Optional[str] = Field(
        default=None, description="Creator user ID"
    )
    name: str = Field(description="Environment name")
    description: Optional[str] = Field(default=None, description="Description")
    environment_type: EnvironmentType = Field(description="Environment type")
    parameters: Dict[str, Any] = Field(description="Generation parameters")
    parameters_hash: str = Field(description="Hash of parameters")
    bounds: Optional[Dict[str, Any]] = Field(
        default=None, description="Environment bounds"
    )
    status: str = Field(description="Environment status")
    storage_path: str = Field(description="Storage path")
    storage_size_bytes: Optional[int] = Field(
        default=None, description="Storage size"
    )
    created_at: datetime = Field(description="Creation timestamp")
    started_at: Optional[datetime] = Field(
        default=None, description="Start timestamp"
    )
    completed_at: Optional[datetime] = Field(
        default=None, description="Completion timestamp"
    )
    exit_code: Optional[int] = Field(default=None, description="Exit code")
    error_message: Optional[str] = Field(
        default=None, description="Error message"
    )
    scene_count: Optional[int] = Field(
        default=None, description="Number of scenes"
    )
    reused: bool = Field(
        default=False,
        description="Whether existing was returned",
    )


class CreateEnvironmentResponse(BaseModel):
    """Response from creating an environment."""

    environment: EnvironmentResponse = Field(
        description="Created or reused environment"
    )
    scene: Optional[Dict[str, Any]] = Field(
        default=None, description="Auto-created scene"
    )
    reused: bool = Field(
        default=False,
        description="Whether existing was returned",
    )


class EnvironmentListItem(BaseModel):
    """Summary item for environment listings."""

    environment_id: str = Field(description="Environment ID")
    name: str = Field(description="Name")
    description: Optional[str] = Field(default=None, description="Description")
    environment_type: EnvironmentType = Field(description="Type")
    status: str = Field(description="Status")
    created_at: datetime = Field(description="Created at")
    completed_at: Optional[datetime] = Field(
        default=None, description="Completed at"
    )
    scene_count: Optional[int] = Field(default=None, description="Scene count")


class PaginatedEnvironmentResponse(BaseModel):
    """Paginated list of environments."""

    environments: List[EnvironmentListItem] = Field(
        description="List of environments"
    )
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")

    def __repr__(self) -> str:
        page = (self.offset // self.limit) + 1 if self.limit else 1
        total_pages = (
            (self.total + self.limit - 1) // self.limit if self.limit else 1
        )
        header = (
            f"PaginatedEnvironmentResponse: {self.total} environments"
            f" (page {page}/{total_pages})"
        )
        if not self.environments:
            return header

        rows = []
        for env in self.environments:
            rows.append(
                (
                    env.environment_id,
                    env.status,
                    env.name,
                    env.environment_type,
                    _fmt_dt(env.created_at),
                    (
                        str(env.scene_count)
                        if env.scene_count is not None
                        else "-"
                    ),
                )
            )

        table = _tabulate(
            ("ID", "Status", "Name", "Type", "Created", "Scenes"),
            rows,
        )
        return f"{header}\n{table}"


class SimilarEnvironmentResponse(BaseModel):
    """Response listing similar environments."""

    similar_environments: List[EnvironmentListItem] = Field(
        description="Similar environments"
    )
    parameters_hash: str = Field(description="Parameters hash")


class EnvironmentUploadRequest(BaseModel):
    """Request to initiate an environment file upload."""

    filename: str = Field(description="Filename", min_length=1, max_length=255)
    content_type: Optional[str] = Field(
        default="application/json", description="MIME type"
    )


class EnvironmentUploadResponse(BaseModel):
    """Response with signed upload URL for environment files."""

    upload_id: str = Field(description="Upload ID")
    upload_url: str = Field(description="Signed upload URL")
    method: str = Field(default="PUT", description="HTTP method")
    expires_at: datetime = Field(description="URL expiration")
    file_id: str = Field(description="File ID for use in parameters")


class EnvironmentUploadCompleteResponse(BaseModel):
    """Response after completing an environment file upload."""

    file_id: str = Field(description="File ID")
    message: str = Field(
        default="Upload completed successfully",
        description="Status message",
    )
