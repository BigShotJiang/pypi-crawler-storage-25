"""Project models for the Waveium SDK."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from .common import ProjectMemberType, ProjectRole


class CreateProjectRequest(BaseModel):
    """Request to create a project."""

    name: str = Field(description="Project name", min_length=1, max_length=255)
    description: Optional[str] = Field(
        default=None, description="Project description"
    )


class UpdateProjectRequest(BaseModel):
    """Request to update a project."""

    name: Optional[str] = Field(
        default=None,
        description="New name",
        min_length=1,
        max_length=255,
    )
    description: Optional[str] = Field(
        default=None, description="New description"
    )


class ProjectResponse(BaseModel):
    """Project details."""

    project_id: str = Field(description="Project ID")
    organization_id: str = Field(description="Organization ID")
    name: str = Field(description="Project name")
    description: Optional[str] = Field(default=None, description="Description")
    created_by_user_id: Optional[str] = Field(
        default=None, description="Creator user ID"
    )
    created_at: datetime = Field(description="Created at")
    updated_at: Optional[datetime] = Field(
        default=None, description="Updated at"
    )
    archived_at: Optional[datetime] = Field(
        default=None, description="Archived at"
    )
    member_count: Optional[int] = Field(
        default=None, description="Member count"
    )
    environment_count: Optional[int] = Field(
        default=None, description="Environment count"
    )
    scene_count: Optional[int] = Field(default=None, description="Scene count")
    user_role: Optional[str] = Field(
        default=None, description="Current user role"
    )


class ProjectListItem(BaseModel):
    """Project list entry."""

    project_id: str = Field(description="Project ID")
    name: str = Field(description="Name")
    description: Optional[str] = Field(default=None, description="Description")
    created_at: datetime = Field(description="Created at")
    updated_at: Optional[datetime] = Field(
        default=None, description="Updated at"
    )
    member_count: Optional[int] = Field(
        default=None, description="Member count"
    )
    environment_count: Optional[int] = Field(
        default=None, description="Environment count"
    )
    scene_count: Optional[int] = Field(default=None, description="Scene count")
    user_role: Optional[str] = Field(
        default=None, description="Current user role"
    )


class PaginatedProjectResponse(BaseModel):
    """Paginated project list."""

    projects: List[ProjectListItem] = Field(description="List of projects")
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")


class AddProjectMemberRequest(BaseModel):
    """Request to add a project member."""

    member_type: ProjectMemberType = Field(
        description="Member type: user or team"
    )
    member_id: str = Field(description="User ID or Team ID")
    role: Optional[ProjectRole] = Field(
        default="member",
        description="Role: owner, admin, or member",
    )


class UpdateProjectMemberRequest(BaseModel):
    """Request to update member role."""

    role: ProjectRole = Field(description="New role: owner, admin, or member")


class ProjectMemberResponse(BaseModel):
    """Project member details."""

    id: str = Field(description="Member record ID")
    project_id: str = Field(description="Project ID")
    member_type: ProjectMemberType = Field(
        description="Member type: user or team"
    )
    member_id: str = Field(description="Member ID")
    member_name: Optional[str] = Field(default=None, description="Display name")
    member_email: Optional[str] = Field(
        default=None, description="Email (users only)"
    )
    role: ProjectRole = Field(description="Role: owner, admin, or member")
    added_by_user_id: Optional[str] = Field(
        default=None, description="Added by user ID"
    )
    added_at: datetime = Field(description="Added at")


class PaginatedProjectMemberResponse(BaseModel):
    """Paginated project member list."""

    members: List[ProjectMemberResponse] = Field(description="List of members")
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")


class AddProjectEnvironmentRequest(BaseModel):
    """Request to add environment to project."""

    environment_id: str = Field(description="Environment ID to add")


class ProjectEnvironmentResponse(BaseModel):
    """Project environment details."""

    id: str = Field(description="Record ID")
    project_id: str = Field(description="Project ID")
    environment_id: str = Field(description="Environment ID")
    environment_name: Optional[str] = Field(
        default=None, description="Environment name"
    )
    environment_type: Optional[str] = Field(
        default=None, description="Environment type"
    )
    environment_status: Optional[str] = Field(
        default=None, description="Environment status"
    )
    added_by_user_id: Optional[str] = Field(
        default=None, description="Added by user ID"
    )
    added_at: datetime = Field(description="Added at")


class PaginatedProjectEnvironmentResponse(BaseModel):
    """Paginated project environment list."""

    environments: List[ProjectEnvironmentResponse] = Field(
        description="List of environments"
    )
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")
