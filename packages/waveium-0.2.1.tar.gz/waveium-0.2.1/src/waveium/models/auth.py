"""Authentication models for the Waveium SDK."""

from datetime import datetime
from typing import List, Optional

from pydantic import Field

from .common import BaseWaveiumModel


class CreateTokenRequest(BaseWaveiumModel):
    """Request to create a new API token."""

    name: str = Field(description="Name/description for the API key")
    expires_days: int = Field(
        default=30,
        ge=1,
        le=365,
        description="Number of days until token expires (1-365)",
    )


class TokenUser(BaseWaveiumModel):
    """User information included in token response."""

    id: str = Field(description="User ID")
    email: str = Field(description="User email")
    name: Optional[str] = Field(default=None, description="User name")
    organization_id: str = Field(description="Organization ID")


class TokenExchangeResponse(BaseWaveiumModel):
    """Response from token exchange endpoint."""

    api_key: str = Field(description="Generated API key (only returned once)")
    expires_in: int = Field(description="Expiration time in seconds")
    user: TokenUser = Field(description="User information")


class AuthTokenResponse(BaseWaveiumModel):
    """Individual API token information."""

    id: str = Field(description="Token ID")
    name: str = Field(description="Token name/description")
    is_active: bool = Field(description="Whether the token is active")
    expires_at: Optional[datetime] = Field(
        default=None, description="When the token expires"
    )
    created_at: datetime = Field(description="When the token was created")
    last_used: Optional[datetime] = Field(
        default=None, description="When the token was last used"
    )


class TokenListResponse(BaseWaveiumModel):
    """Response containing list of tokens."""

    tokens: List[AuthTokenResponse] = Field(description="List of tokens")
