"""SSE event models for the Waveium SDK."""

import json
from typing import Literal, Optional, Union

from pydantic import BaseModel, Field


class ExecutionProgress(BaseModel):
    """Detailed progress information for a running execution."""

    overall_percent: Optional[str] = Field(
        default=None, description="Overall completion percentage"
    )
    overall_waypoints: Optional[str] = Field(
        default=None,
        description="Overall waypoint progress (e.g. '4586/11466')",
    )
    entities_completed: Optional[str] = Field(
        default=None, description="Entity completion count (e.g. '0/1')"
    )
    entity: Optional[str] = Field(
        default=None, description="Current entity identifier"
    )
    entity_progress: Optional[str] = Field(
        default=None, description="Current entity progress percentage"
    )
    entity_waypoint: Optional[str] = Field(
        default=None, description="Current entity waypoint progress"
    )


class StatusEvent(BaseModel):
    """A status update event from an SSE stream."""

    event_type: Literal["status"] = "status"
    resource_id: str = Field(description="ID of the resource")
    status: str = Field(description="Current resource status")
    started_at: Optional[str] = Field(
        default=None, description="When processing started"
    )
    completed_at: Optional[str] = Field(
        default=None, description="When processing completed"
    )
    error_message: Optional[str] = Field(
        default=None, description="Error message if failed"
    )
    progress: Optional[ExecutionProgress] = Field(
        default=None, description="Detailed progress (executions only)"
    )


class TimeoutEvent(BaseModel):
    """Server-side SSE connection timeout event.

    The server sends this when its 5-minute connection limit
    is reached. The client should reconnect immediately.
    """

    event_type: Literal["timeout"] = "timeout"
    message: Optional[str] = Field(default=None, description="Timeout message")


class ErrorEvent(BaseModel):
    """An error event from an SSE stream."""

    event_type: Literal["error"] = "error"
    message: str = Field(description="Error message")
    code: Optional[str] = Field(default=None, description="Error code")


ServerEvent = Union[StatusEvent, TimeoutEvent, ErrorEvent]

# Terminal statuses shared across resource types
TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled"})

# Resource ID field names in SSE payloads
_RESOURCE_ID_FIELDS = (
    "execution_id",
    "environment_id",
    "scene_id",
)


def parse_server_event(event_type: str, data: str) -> ServerEvent:
    """Parse a raw SSE event into a typed ServerEvent model.

    Args:
        event_type: The SSE event type field (status, timeout, error).
        data: The JSON-encoded event data string.

    Returns:
        A typed ServerEvent instance.

    Raises:
        ValueError: If event_type is unknown or data is invalid JSON.
    """
    try:
        payload = json.loads(data)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid SSE event data: {e}") from e

    resource_id = ""
    for field in _RESOURCE_ID_FIELDS:
        if field in payload:
            resource_id = payload[field]
            break

    if event_type == "status":
        return StatusEvent(
            resource_id=resource_id,
            status=payload.get("status", "unknown"),
            started_at=payload.get("started_at"),
            completed_at=payload.get("completed_at"),
            error_message=payload.get("error_message"),
            progress=(
                ExecutionProgress(**payload["progress"])
                if payload.get("progress")
                else None
            ),
        )
    elif event_type == "timeout":
        return TimeoutEvent(
            message=payload.get("message"),
        )
    elif event_type == "error":
        return ErrorEvent(
            message=payload.get("message", "Unknown error"),
            code=payload.get("code"),
        )
    else:
        raise ValueError(f"Unknown SSE event type: {event_type}")
