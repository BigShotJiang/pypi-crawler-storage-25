"""Team models for the Waveium SDK."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


class CreateTeamRequest(BaseModel):
    """Request to create a team."""

    name: str = Field(description="Team name", min_length=1, max_length=255)
    description: Optional[str] = Field(
        default=None, description="Team description"
    )


class UpdateTeamRequest(BaseModel):
    """Request to update a team."""

    name: Optional[str] = Field(
        default=None,
        description="New name",
        min_length=1,
        max_length=255,
    )
    description: Optional[str] = Field(
        default=None, description="New description"
    )


class TeamResponse(BaseModel):
    """Team details."""

    team_id: str = Field(description="Team ID")
    organization_id: str = Field(description="Organization ID")
    name: str = Field(description="Team name")
    description: Optional[str] = Field(default=None, description="Description")
    created_by_user_id: Optional[str] = Field(
        default=None, description="Creator user ID"
    )
    created_at: datetime = Field(description="Created at")
    updated_at: Optional[datetime] = Field(
        default=None, description="Updated at"
    )
    member_count: Optional[int] = Field(
        default=None, description="Member count"
    )


class PaginatedTeamResponse(BaseModel):
    """Paginated team list."""

    teams: List[TeamResponse] = Field(description="List of teams")
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")


class AddTeamMemberRequest(BaseModel):
    """Request to add a team member."""

    user_id: str = Field(description="User ID to add")
    role: Optional[str] = Field(
        default="member", description="Role: member or admin"
    )


class TeamMemberResponse(BaseModel):
    """Team member details."""

    id: str = Field(description="Member record ID")
    team_id: str = Field(description="Team ID")
    user_id: str = Field(description="User ID")
    user_email: Optional[str] = Field(default=None, description="User email")
    user_name: Optional[str] = Field(default=None, description="User name")
    role: str = Field(description="Role: member or admin")
    added_by_user_id: Optional[str] = Field(
        default=None, description="Added by user ID"
    )
    added_at: datetime = Field(description="Added at")


class PaginatedTeamMemberResponse(BaseModel):
    """Paginated team member list."""

    members: List[TeamMemberResponse] = Field(description="List of members")
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")
