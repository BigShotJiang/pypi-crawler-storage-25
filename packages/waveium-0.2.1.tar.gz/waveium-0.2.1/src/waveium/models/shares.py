"""Share models for the Waveium SDK."""

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from .common import PermissionLevel, ShareTargetType


class CreateShareRequest(BaseModel):
    """Request to share a resource."""

    shared_with_type: ShareTargetType = Field(
        description="Target type: user, team, or organization"
    )
    shared_with_id: str = Field(description="ID of user, team, or organization")
    permission_level: PermissionLevel = Field(
        description="Permission: view, use, or full"
    )


class ShareResponse(BaseModel):
    """Share record."""

    share_id: str = Field(description="Share ID")
    resource_type: str = Field(
        description="Resource type: environment or scene"
    )
    resource_id: str = Field(description="Resource ID")
    shared_by_user_id: str = Field(description="Sharer user ID")
    shared_with_type: ShareTargetType = Field(
        description="Target type: user, team, organization"
    )
    shared_with_id: str = Field(description="Target ID")
    shared_with_name: Optional[str] = Field(
        default=None, description="Target display name"
    )
    permission_level: PermissionLevel = Field(
        description="Permission: view, use, full"
    )
    created_at: datetime = Field(description="Created at")


class PaginatedShareResponse(BaseModel):
    """Paginated list of shares."""

    shares: List[ShareResponse] = Field(description="List of shares")
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")
