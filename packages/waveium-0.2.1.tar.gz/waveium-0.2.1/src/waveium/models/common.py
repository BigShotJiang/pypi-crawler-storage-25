"""Common models used across the Waveium SDK."""

from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Sequence  # noqa: F401

from pydantic import BaseModel, Field


class ErrorDetail(BaseModel):
    """Error detail from API responses."""

    code: str = Field(description="Error code")
    message: str = Field(description="Error message")
    details: Optional[Dict[str, Any]] = Field(
        default=None, description="Additional error details"
    )


class ErrorResponse(BaseModel):
    """Error response from the API."""

    error: ErrorDetail = Field(description="Error information")


class MessageResponse(BaseModel):
    """Generic message response."""

    message: str = Field(description="Response message")


class PaginationInfo(BaseModel):
    """Pagination information for list responses."""

    page: int = Field(description="Current page number (1-based)")
    page_size: int = Field(description="Items per page")
    total: int = Field(description="Total number of items")
    total_pages: int = Field(description="Total number of pages")
    has_next: bool = Field(description="Whether there is a next page")
    has_prev: bool = Field(description="Whether there is a previous page")


class BaseWaveiumModel(BaseModel):
    """Base model for all Waveium API models."""

    model_config = {"populate_by_name": True, "use_enum_values": True}


# Status type aliases
EnvironmentStatus = Literal[
    "pending",
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]
SceneStatus = Literal[
    "pending",
    "pending_environment",
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]
ExecutionStatus = Literal[
    "queued",
    "running",
    "completed",
    "failed",
    "cancelled",
]
EnvironmentType = Literal["outdoor", "indoor", "underground"]
ScopeFilter = Literal["mine", "shared", "org"]
SceneScopeFilter = Literal["mine", "shared", "project", "org"]
PermissionLevel = Literal["view", "use", "full"]
ShareTargetType = Literal["user", "team", "organization"]
ProjectRole = Literal["owner", "admin", "member"]
TeamRole = Literal["member", "admin"]
TransportMode = Literal["walk", "bike", "drive"]
SubscriptionTier = Literal["free", "starter", "pro", "enterprise"]
ProjectMemberType = Literal["user", "team"]


class StorageStatsResponse(BaseModel):
    """Storage statistics for a resource."""

    total_files: int = Field(description="Total number of files")
    total_size_bytes: int = Field(description="Total size in bytes")
    total_size_mb: float = Field(description="Total size in megabytes")
    objects: Optional[Dict[str, Any]] = Field(
        default=None, description="Object file statistics"
    )


def _fmt_dt(dt: Optional[datetime]) -> str:
    """Format a datetime for table display."""
    if dt is None:
        return "-"
    return dt.strftime("%Y-%m-%d %H:%M")


def _tabulate(
    headers: Sequence[str],
    rows: Sequence[Sequence[str]],
) -> str:
    """Render a simple aligned text table.

    Args:
        headers: Column header strings.
        rows: List of row tuples (same length as headers).

    Returns:
        Formatted table string with aligned columns.
    """
    # Compute column widths from headers and data
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    # Build format string
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)

    lines = [fmt.format(*headers)]
    lines.append("  ".join("-" * w for w in widths))
    for row in rows:
        lines.append(fmt.format(*row))

    return "\n".join(lines)
