"""Data models for the Waveium SDK."""

from .auth import (
    AuthTokenResponse,
    CreateTokenRequest,
    TokenExchangeResponse,
    TokenListResponse,
    TokenUser,
)
from .common import (
    BaseWaveiumModel,
    ErrorDetail,
    ErrorResponse,
    MessageResponse,
    PaginationInfo,
    StorageStatsResponse,
)
from .environments import (
    BoundsInput,
    CreateEnvironmentRequest,
    CreateEnvironmentResponse,
    EnvironmentListItem,
    EnvironmentResponse,
    EnvironmentUploadCompleteResponse,
    EnvironmentUploadRequest,
    EnvironmentUploadResponse,
    PaginatedEnvironmentResponse,
    RouteInput,
    SimilarEnvironmentResponse,
    UpdateEnvironmentRequest,
)
from .executions import (
    CreateExecutionRequest,
    ExecutionListItem,
    ExecutionProgressResponse,
    ExecutionResponse,
    PaginatedExecutionResponse,
    UpdateExecutionRequest,
)
from .files import (
    ArchiveDownloadResponse,
    BatchDownloadFile,
    BatchDownloadResponse,
    EnvironmentFilesResponse,
    ExecutionFilesResponse,
    FileDownloadResponse,
    FileInfo,
    SceneFilesResponse,
)
from .organizations import (
    CreateOrganizationRequest,
    OrganizationResponse,
    OrganizationStatsResponse,
    UpdateOrganizationRequest,
)
from .projects import (
    AddProjectEnvironmentRequest,
    AddProjectMemberRequest,
    CreateProjectRequest,
    PaginatedProjectEnvironmentResponse,
    PaginatedProjectMemberResponse,
    PaginatedProjectResponse,
    ProjectEnvironmentResponse,
    ProjectListItem,
    ProjectMemberResponse,
    ProjectResponse,
    UpdateProjectMemberRequest,
    UpdateProjectRequest,
)
from .roles import (
    PermissionResponse,
    RoleDetailResponse,
    RolePermissionResponse,
    RoleResponse,
)
from .scenes import (
    CreateSceneRequest,
    PaginatedSceneResponse,
    PatchSceneRequest,
    SceneListItem,
    SceneParameters,
    SceneResponse,
    SceneUploadCompleteResponse,
    SceneUploadRequest,
    SceneUploadResponse,
    SimilarSceneResponse,
    UpdateSceneRequest,
)
from .shares import (
    CreateShareRequest,
    PaginatedShareResponse,
    ShareResponse,
)
from .teams import (
    AddTeamMemberRequest,
    CreateTeamRequest,
    PaginatedTeamMemberResponse,
    PaginatedTeamResponse,
    TeamMemberResponse,
    TeamResponse,
    UpdateTeamRequest,
)
from .events import (
    ErrorEvent,
    ExecutionProgress,
    ServerEvent,
    StatusEvent,
    TimeoutEvent,
)
from .users import (
    AdminUpdateUserRequest,
    CreateUserRequest,
    PaginatedUserResponse,
    RoleInUserResponse,
    UpdateOwnUserRequest,
    UserResponse,
    UserRoleResponse,
)

__all__ = [
    # Common
    "BaseWaveiumModel",
    "ErrorDetail",
    "ErrorResponse",
    "MessageResponse",
    "PaginationInfo",
    "StorageStatsResponse",
    # Auth
    "AuthTokenResponse",
    "CreateTokenRequest",
    "TokenExchangeResponse",
    "TokenListResponse",
    "TokenUser",
    # Environments
    "BoundsInput",
    "CreateEnvironmentRequest",
    "CreateEnvironmentResponse",
    "EnvironmentListItem",
    "EnvironmentResponse",
    "EnvironmentUploadCompleteResponse",
    "EnvironmentUploadRequest",
    "EnvironmentUploadResponse",
    "PaginatedEnvironmentResponse",
    "RouteInput",
    "SimilarEnvironmentResponse",
    "UpdateEnvironmentRequest",
    # Scenes
    "CreateSceneRequest",
    "PaginatedSceneResponse",
    "PatchSceneRequest",
    "SceneListItem",
    "SceneParameters",
    "SceneResponse",
    "SceneUploadCompleteResponse",
    "SceneUploadRequest",
    "SceneUploadResponse",
    "SimilarSceneResponse",
    "UpdateSceneRequest",
    # Executions
    "CreateExecutionRequest",
    "ExecutionListItem",
    "ExecutionProgressResponse",
    "ExecutionResponse",
    "PaginatedExecutionResponse",
    "UpdateExecutionRequest",
    # Files
    "ArchiveDownloadResponse",
    "BatchDownloadFile",
    "BatchDownloadResponse",
    "EnvironmentFilesResponse",
    "ExecutionFilesResponse",
    "FileDownloadResponse",
    "FileInfo",
    "SceneFilesResponse",
    # Organizations
    "CreateOrganizationRequest",
    "OrganizationResponse",
    "OrganizationStatsResponse",
    "UpdateOrganizationRequest",
    # Projects
    "AddProjectEnvironmentRequest",
    "AddProjectMemberRequest",
    "CreateProjectRequest",
    "PaginatedProjectEnvironmentResponse",
    "PaginatedProjectMemberResponse",
    "PaginatedProjectResponse",
    "ProjectEnvironmentResponse",
    "ProjectListItem",
    "ProjectMemberResponse",
    "ProjectResponse",
    "UpdateProjectMemberRequest",
    "UpdateProjectRequest",
    # Roles
    "PermissionResponse",
    "RoleDetailResponse",
    "RolePermissionResponse",
    "RoleResponse",
    # Shares
    "CreateShareRequest",
    "PaginatedShareResponse",
    "ShareResponse",
    # Teams
    "AddTeamMemberRequest",
    "CreateTeamRequest",
    "PaginatedTeamMemberResponse",
    "PaginatedTeamResponse",
    "TeamMemberResponse",
    "TeamResponse",
    "UpdateTeamRequest",
    # Events (SSE)
    "ErrorEvent",
    "ExecutionProgress",
    "ServerEvent",
    "StatusEvent",
    "TimeoutEvent",
    # Users
    "AdminUpdateUserRequest",
    "CreateUserRequest",
    "PaginatedUserResponse",
    "RoleInUserResponse",
    "UpdateOwnUserRequest",
    "UserResponse",
    "UserRoleResponse",
]
