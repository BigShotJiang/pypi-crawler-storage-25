"""Organization models for the Waveium SDK."""

from datetime import datetime
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class CreateOrganizationRequest(BaseModel):
    """Request to create organization (admin only)."""

    name: str = Field(description="Organization name")
    contact: Optional[str] = Field(default=None, description="Contact info")
    homepage: Optional[str] = Field(default=None, description="Homepage URL")
    subscription_tier: Optional[str] = Field(
        default="free", description="Subscription tier"
    )


class UpdateOrganizationRequest(BaseModel):
    """Request to update organization."""

    name: Optional[str] = Field(default=None, description="New name")
    contact: Optional[str] = Field(default=None, description="New contact")
    homepage: Optional[str] = Field(default=None, description="New homepage")


class OrganizationResponse(BaseModel):
    """Organization details."""

    id: str = Field(description="Organization ID")
    name: str = Field(description="Name")
    contact: Optional[str] = Field(default=None, description="Contact")
    homepage: Optional[str] = Field(default=None, description="Homepage")
    subscription_tier: str = Field(description="Subscription tier")
    max_users: int = Field(description="Max users")
    max_storage_gb: int = Field(description="Max storage GB")
    created_at: datetime = Field(description="Created at")
    updated_at: Optional[datetime] = Field(
        default=None, description="Updated at"
    )


class OrganizationStatsResponse(BaseModel):
    """Organization statistics."""

    organization: Dict[str, Any] = Field(description="Organization info")
    users: Dict[str, Any] = Field(description="User stats")
    scenes: Dict[str, Any] = Field(description="Scene stats")
    executions: Dict[str, Any] = Field(description="Execution stats")
    storage: Dict[str, Any] = Field(description="Storage stats")
