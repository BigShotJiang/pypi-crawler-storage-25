"""Execution models for the Waveium SDK."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .common import _fmt_dt, _tabulate


class CreateExecutionRequest(BaseModel):
    """Request to create a new execution."""

    name: Optional[str] = Field(
        default=None,
        description="Execution name",
        max_length=255,
    )
    parameters: Optional[Dict[str, Any]] = Field(
        default=None, description="Execution parameters"
    )


class UpdateExecutionRequest(BaseModel):
    """Request to update an execution."""

    name: str = Field(
        description="New execution name",
        min_length=1,
        max_length=255,
    )


class ExecutionResponse(BaseModel):
    """Full execution response from the API."""

    execution_id: str = Field(description="Execution ID")
    scene_id: str = Field(description="Scene ID")
    organization_id: str = Field(description="Organization ID")
    created_by_user_id: Optional[str] = Field(
        default=None, description="Creator user ID"
    )
    name: Optional[str] = Field(default=None, description="Execution name")
    execution_number: int = Field(description="Execution number")
    parameters: Dict[str, Any] = Field(description="Execution parameters")
    status: str = Field(description="Execution status")
    attempt_number: Optional[int] = Field(
        default=None, description="Attempt number"
    )
    storage_path: str = Field(description="Storage path")
    storage_size_bytes: Optional[int] = Field(
        default=None, description="Storage size"
    )
    cloud_run_execution_id: Optional[str] = Field(
        default=None, description="Cloud Run execution ID"
    )
    created_at: datetime = Field(description="Created at")
    started_at: Optional[datetime] = Field(
        default=None, description="Started at"
    )
    completed_at: Optional[datetime] = Field(
        default=None, description="Completed at"
    )
    exit_code: Optional[int] = Field(default=None, description="Exit code")
    error_message: Optional[str] = Field(
        default=None, description="Error message"
    )
    output_metadata: Optional[Dict[str, Any]] = Field(
        default=None, description="Output metadata"
    )


class ExecutionListItem(BaseModel):
    """Summary item for execution listings."""

    execution_id: str = Field(description="Execution ID")
    scene_id: str = Field(description="Scene ID")
    name: Optional[str] = Field(default=None, description="Name")
    execution_number: int = Field(description="Execution number")
    status: str = Field(description="Status")
    created_at: datetime = Field(description="Created at")
    started_at: Optional[datetime] = Field(
        default=None, description="Started at"
    )
    completed_at: Optional[datetime] = Field(
        default=None, description="Completed at"
    )
    parameters: Optional[Dict[str, Any]] = Field(
        default=None, description="Parameters"
    )


class PaginatedExecutionResponse(BaseModel):
    """Paginated list of executions."""

    executions: List[ExecutionListItem] = Field(
        description="List of executions"
    )
    total: int = Field(description="Total count")
    limit: int = Field(description="Page size")
    offset: int = Field(description="Offset")

    def __repr__(self) -> str:
        page = (self.offset // self.limit) + 1 if self.limit else 1
        total_pages = (
            (self.total + self.limit - 1) // self.limit if self.limit else 1
        )
        header = (
            f"PaginatedExecutionResponse: {self.total} executions"
            f" (page {page}/{total_pages})"
        )
        if not self.executions:
            return header

        rows = []
        for ex in self.executions:
            rows.append(
                (
                    ex.execution_id,
                    ex.status,
                    ex.name or "-",
                    ex.scene_id,
                    _fmt_dt(ex.created_at),
                )
            )

        table = _tabulate(
            ("ID", "Status", "Name", "Scene", "Created"),
            rows,
        )
        return f"{header}\n{table}"


class ExecutionProgressResponse(BaseModel):
    """Progress information for an execution."""

    execution_id: str = Field(description="Execution ID")
    status: str = Field(description="Execution status")
    progress: Optional[Dict[str, Any]] = Field(
        default=None, description="Progress data"
    )
    last_log_timestamp: Optional[datetime] = Field(
        default=None, description="Last log timestamp"
    )
    message: Optional[str] = Field(default=None, description="Progress message")
