"""HTTP client wrappers for the Waveium SDK."""

import logging
from typing import (
    Any,
    Dict,
    Optional,
    Type,
    TypeVar,
    Union,
    overload,
)

import httpx
from pydantic import BaseModel, ValidationError as PydanticValidationError

from ._config import Config
from .exceptions import (
    APIError,
    AuthenticationError,
    AuthorizationError,
    ConflictError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    WaveiumError,
)
from .models.common import ErrorResponse

T = TypeVar("T", bound=BaseModel)

logger = logging.getLogger("waveium")


def _build_headers(config: Config) -> Dict[str, str]:
    """Build request headers from config.

    Args:
        config: Configuration object

    Returns:
        Dictionary of headers
    """
    headers = {
        "User-Agent": "waveium-python/0.2.0",
        "Content-Type": "application/json",
    }
    if config.api_key:
        if config.api_key.startswith(("wv_", "wvx_")):
            headers["X-API-Key"] = config.api_key
        else:
            headers["Authorization"] = f"Bearer {config.api_key}"
    return headers


def _handle_error_response(response: httpx.Response) -> WaveiumError:
    """Convert HTTP error response to appropriate exception.

    Args:
        response: HTTP response object

    Returns:
        Appropriate WaveiumError subclass
    """
    try:
        error_data = response.json()
        error_response = ErrorResponse.model_validate(error_data)
        message = error_response.error.message
        code = error_response.error.code
        details = error_response.error.details
    except Exception:
        message = response.text or f"HTTP {response.status_code}"
        code = None
        details = None

    if response.status_code == 400:
        return ValidationError(message, code, details)
    elif response.status_code == 401:
        return AuthenticationError(message, code, details)
    elif response.status_code == 403:
        return AuthorizationError(message, code, details)
    elif response.status_code == 404:
        return NotFoundError(message, code, details)
    elif response.status_code == 409:
        return ConflictError(message, code, details)
    elif response.status_code == 429:
        return RateLimitError(message, code, details)
    else:
        return APIError(message, code, details)


class HTTPClient:
    """Synchronous HTTP client for Waveium API."""

    def __init__(self, config: Config) -> None:
        """Initialize HTTP client.

        Args:
            config: Configuration object
        """
        self.config = config
        self._client: Optional[httpx.Client] = None

    def _get_client(self) -> httpx.Client:
        """Get or create HTTP client instance.

        Returns:
            HTTP client instance
        """
        if self._client is None:
            self._client = httpx.Client(
                base_url=self.config.base_url,
                timeout=self.config.timeout,
                headers=_build_headers(self.config),
            )
        return self._client

    @overload
    def request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        response_model: Type[T],
    ) -> T: ...

    @overload
    def request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        response_model: None = None,
    ) -> Dict[str, Any]: ...

    def request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        response_model: Optional[Type[T]] = None,
    ) -> Union[T, Dict[str, Any]]:
        """Make HTTP request.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            path: API endpoint path
            json_data: Optional JSON request body
            params: Optional query parameters
            headers: Optional additional headers
            response_model: Optional Pydantic model to parse response

        Returns:
            Parsed response model or raw dictionary

        Raises:
            WaveiumError: If request fails
        """
        client = self._get_client()
        logger.debug("%s %s", method, path)

        try:
            response = client.request(
                method=method,
                url=path,
                json=json_data,
                params=params,
                headers=headers,
            )
            response.raise_for_status()

            if response.status_code == 204:
                return (
                    {}
                    if response_model is None
                    else response_model.model_validate({})
                )

            response_data: Dict[str, Any] = response.json()

            if response_model:
                try:
                    return response_model.model_validate(response_data)
                except PydanticValidationError as e:
                    raise ValidationError(
                        f"Failed to parse response: {str(e)}",
                        code="VALIDATION_ERROR",
                        details={"errors": e.errors()},
                    )

            return response_data

        except httpx.HTTPStatusError as e:
            logger.debug("%s %s -> %d", method, path, e.response.status_code)
            raise _handle_error_response(e.response)
        except httpx.RequestError as e:
            logger.debug("%s %s -> network error: %s", method, path, e)
            raise NetworkError(f"Network error: {str(e)}")
        except Exception as e:
            if isinstance(e, WaveiumError):
                raise
            raise APIError(f"Unexpected error: {str(e)}")

    def close(self) -> None:
        """Close HTTP client."""
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self) -> "HTTPClient":
        """Enter context manager."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Exit context manager."""
        self.close()


class AsyncHTTPClient:
    """Asynchronous HTTP client for Waveium API."""

    def __init__(self, config: Config) -> None:
        """Initialize async HTTP client.

        Args:
            config: Configuration object
        """
        self.config = config
        self._client: Optional[httpx.AsyncClient] = None

    def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client instance.

        Returns:
            Async HTTP client instance
        """
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.config.base_url,
                timeout=self.config.timeout,
                headers=_build_headers(self.config),
            )
        return self._client

    @overload
    async def request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        response_model: Type[T],
    ) -> T: ...

    @overload
    async def request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        response_model: None = None,
    ) -> Dict[str, Any]: ...

    async def request(
        self,
        method: str,
        path: str,
        *,
        json_data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        response_model: Optional[Type[T]] = None,
    ) -> Union[T, Dict[str, Any]]:
        """Make async HTTP request.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            path: API endpoint path
            json_data: Optional JSON request body
            params: Optional query parameters
            headers: Optional additional headers
            response_model: Optional Pydantic model to parse response

        Returns:
            Parsed response model or raw dictionary

        Raises:
            WaveiumError: If request fails
        """
        client = self._get_client()
        logger.debug("%s %s", method, path)

        try:
            response = await client.request(
                method=method,
                url=path,
                json=json_data,
                params=params,
                headers=headers,
            )
            response.raise_for_status()

            if response.status_code == 204:
                return (
                    {}
                    if response_model is None
                    else response_model.model_validate({})
                )

            response_data: Dict[str, Any] = response.json()

            if response_model:
                try:
                    return response_model.model_validate(response_data)
                except PydanticValidationError as e:
                    raise ValidationError(
                        f"Failed to parse response: {str(e)}",
                        code="VALIDATION_ERROR",
                        details={"errors": e.errors()},
                    )

            return response_data

        except httpx.HTTPStatusError as e:
            logger.debug("%s %s -> %d", method, path, e.response.status_code)
            raise _handle_error_response(e.response)
        except httpx.RequestError as e:
            logger.debug("%s %s -> network error: %s", method, path, e)
            raise NetworkError(f"Network error: {str(e)}")
        except Exception as e:
            if isinstance(e, WaveiumError):
                raise
            raise APIError(f"Unexpected error: {str(e)}")

    async def close(self) -> None:
        """Close async HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "AsyncHTTPClient":
        """Enter async context manager."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context manager."""
        await self.close()
