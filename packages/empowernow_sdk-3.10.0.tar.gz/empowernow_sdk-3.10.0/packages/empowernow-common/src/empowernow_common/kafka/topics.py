"""Canonical Kafka topic registry used by platform_producer.

Applications should import TOPICS and reference keys instead of hardcoding
strings, so topic names can evolve centrally.
"""
from __future__ import annotations

TOPICS = {
    # Audit / security
    "audit.secret_access": "platform.secret_access_audit",

    # Orchestration Service
    "crud.operations": "crud.operations",
    "crud.metrics": "crud.metrics",

    # PDP service
    "pdp.decisions": "pdp.decisions",

    # Membership service
    "membership.identity": "membership.identities",
    "membership.projections": "membership.projections",

    # Authorization / governance events
    "authz.collection.changed": "authz.collection.changed",
    "authz.external_sync_policy.changed": "authz.external_sync_policy.changed",
    "authz.resource_collection.changed": "authz.resource_collection.changed",
} 