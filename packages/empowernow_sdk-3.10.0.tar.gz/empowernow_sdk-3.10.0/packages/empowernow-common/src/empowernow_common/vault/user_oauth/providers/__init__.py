"""
User OAuth storage providers.

Available providers:
- PostgresUserOAuthProvider: PostgreSQL with FIPS encryption
"""

from empowernow_common.vault.user_oauth.providers.postgres import (
    PostgresUserOAuthProvider,
)

__all__ = ["PostgresUserOAuthProvider"]
