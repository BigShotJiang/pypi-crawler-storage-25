"""User OAuth 2.1 authorization code flow (PKCE).

Public API for ``empowernow_common.oauth.user_flow``.

This subpackage consolidates the shared OAuth mechanics that were previously
duplicated across the MCP Gateway and CRUD Service:

- PKCE challenge generation (S256)
- State token generation + Redis storage (one-time-use)
- Rate limiting (per-user, configurable window)
- Authorization URL construction (including extra_auth_params)
- Token exchange (client_secret_basic and client_secret_post)
- Just-in-time secret resolution via :class:`~empowernow_common.vault.base.ReadableVaultProvider`
- Metadata enrichment (config-driven API calls post token-exchange)
- Provider-specific metadata extraction via ``OAuthMetadataExtractor``
- Encrypted credential storage via ``BaseUserOAuthProvider``

Usage::

    from empowernow_common.oauth.user_flow import (
        UnifiedOAuthFlow,
        OAuthFlowConfig,
        EnrichmentStep,
        OAuthFlowResult,
        OAuthStateStore,
        MetadataEnrichmentService,
        OAuthFlowError,
        OAuthStateError,
        OAuthRateLimitError,
        OAuthProviderError,
        OAuthEnrichmentError,
        OAuthSecretResolutionError,
    )
"""

from empowernow_common.oauth.user_flow.config import (
    EnrichmentStep,
    OAuthFlowConfig,
    OAuthStateStore,
)
from empowernow_common.oauth.user_flow.enrichment import MetadataEnrichmentService
from empowernow_common.oauth.user_flow.exceptions import (
    OAuthEnrichmentError,
    OAuthFlowError,
    OAuthProviderError,
    OAuthRateLimitError,
    OAuthSecretResolutionError,
    OAuthStateError,
)
from empowernow_common.oauth.user_flow.orchestrator import (
    OAuthFlowResult,
    UnifiedOAuthFlow,
)

__all__ = [
    # Main flow class
    "UnifiedOAuthFlow",
    # Config dataclasses
    "OAuthFlowConfig",
    "EnrichmentStep",
    "OAuthFlowResult",
    # Services
    "MetadataEnrichmentService",
    # Protocols
    "OAuthStateStore",
    # Exceptions
    "OAuthFlowError",
    "OAuthStateError",
    "OAuthRateLimitError",
    "OAuthProviderError",
    "OAuthEnrichmentError",
    "OAuthSecretResolutionError",
]
