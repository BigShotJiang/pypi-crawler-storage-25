"""
Cryptographic utilities for EmpowerNow services.

This module provides FIPS 140-3 compliant encryption for sensitive data
such as OAuth tokens, API keys, and other credentials.

Example:
    from empowernow_common.crypto import encrypt, decrypt

    # Encrypt sensitive data
    tokens = {"access_token": "secret", "refresh_token": "also_secret"}
    ciphertext = encrypt(tokens)

    # Store ciphertext in database BLOB column...

    # Later, decrypt
    decrypted = decrypt(ciphertext)
    print(decrypted["access_token"])  # "secret"

Environment Variables:
    CREDENTIAL_ENCRYPTION_KEY: Base64-encoded 32-byte AES key
    CREDENTIAL_ENCRYPTION_KEY_POINTER: Vault path to retrieve key
"""

from empowernow_common.crypto.fips_aead import (
    encrypt,
    decrypt,
    clear_key_cache,
    EncryptionKeyError,
)

__all__ = [
    "encrypt",
    "decrypt",
    "clear_key_cache",
    "EncryptionKeyError",
]
