"""Content-type adapter implementations."""
