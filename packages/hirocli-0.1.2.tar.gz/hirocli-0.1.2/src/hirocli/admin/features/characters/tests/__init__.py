# Character admin service tests
