"""Logs feature tests."""
