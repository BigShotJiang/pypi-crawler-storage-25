"""Dashboard feature tests."""
