import{x as a}from"./BBHmEqZ7.js";a();
