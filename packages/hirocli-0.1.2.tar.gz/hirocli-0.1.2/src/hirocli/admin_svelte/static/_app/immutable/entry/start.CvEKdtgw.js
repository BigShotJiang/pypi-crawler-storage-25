import{a as r}from"../chunks/DixAlA52.js";import{y as t}from"../chunks/DkIXRff8.js";export{t as load_css,r as start};
