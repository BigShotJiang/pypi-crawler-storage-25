#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_NAME="$(basename "${SCRIPT_DIR}")"
OUTPUT_DIR="${1:-$(dirname "${SCRIPT_DIR}")}"
OUTPUT_DIR="$(mkdir -p "${OUTPUT_DIR}" && cd "${OUTPUT_DIR}" && pwd)"
OUTPUT_PATH="${OUTPUT_DIR}/${PKG_NAME}.zip"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 is required" >&2
  exit 1
fi

python3 - "$SCRIPT_DIR" "$OUTPUT_PATH" <<'PY'
import os
import sys
import zipfile
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.parent.mkdir(parents=True, exist_ok=True)

try:
    out_rel = out.relative_to(root)
except ValueError:
    out_rel = None

with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for current_root, dirnames, filenames in os.walk(root):
        current_path = Path(current_root)
        rel_root = current_path.relative_to(root)

        dirnames[:] = [d for d in dirnames if d != ".git"]

        for filename in filenames:
            file_path = current_path / filename
            rel_path = file_path.relative_to(root)
            if rel_path.parts and rel_path.parts[0] == ".git":
                continue
            if out_rel is not None and rel_path == out_rel:
                continue
            zf.write(file_path, rel_path.as_posix())
PY

echo "Created: ${OUTPUT_PATH}"
