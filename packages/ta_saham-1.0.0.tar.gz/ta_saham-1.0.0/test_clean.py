import pandas as pd
import numpy as np
import time

np.random.seed(42)
dates = pd.bdate_range('2024-01-01', periods=300)
symbols = ['AAAA.JK', 'BBBB.JK', 'CCCC.JK']
sectors = ['Technology', 'Finance', 'Energy']

rows = []
for i, sym in enumerate(symbols):
    price = 1000 + i * 500
    for d in dates:
        ret = np.random.normal(0.001, 0.02)
        c = price * (1 + ret)
        o = price * (1 + np.random.normal(0, 0.005))
        h = max(o, c) * (1 + abs(np.random.normal(0, 0.01)))
        l = min(o, c) * (1 - abs(np.random.normal(0, 0.01)))
        v = int(np.random.lognormal(15, 1))
        rows.append({
            'symbol': sym, 'date': d, 'sector': sectors[i],
            'open': round(o, 2), 'high': round(h, 2),
            'low': round(l, 2), 'close': round(c, 2),
            'volume': v, 'market_cap': price * 1e9,
            'macro_dji': 42000 + np.random.normal(0, 200),
            'macro_eido': 22 + np.random.normal(0, 0.5),
        })
        price = c

df_raw = pd.DataFrame(rows)
print("Input:", df_raw.shape)

from ta_saham import generate_features

t = time.time()
df = generate_features(df_raw, verbose=False)
elapsed = time.time() - t

print("Time: %.1f seconds" % elapsed)
print("Output:", df.shape)
print("New features:", df.shape[1] - df_raw.shape[1])

cols = df.columns.tolist()
cdl = [x for x in cols if x.startswith('cdl_')]
lag = [x for x in cols if '_lag' in x]
mean_f = [x for x in cols if '_mean_' in x]
std_f = [x for x in cols if '_std_' in x]
rank_f = [x for x in cols if '_rank' in x]
ret_f = [x for x in cols if x.startswith('ret_')]

print("Candlestick:", len(cdl))
print("Lag:", len(lag))
print("Rolling mean:", len(mean_f))
print("Rolling std:", len(std_f))
print("Rank:", len(rank_f))
print("Return:", len(ret_f))
print("DONE")
