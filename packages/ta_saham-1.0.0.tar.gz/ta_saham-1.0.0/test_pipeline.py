"""Quick test of ta-saham with real data."""
import pandas as pd
import numpy as np
import time

# Create synthetic multi-stock data (simulating real OHLCV)
np.random.seed(42)
dates = pd.bdate_range('2024-01-01', periods=300)
symbols = ['AAAA.JK', 'BBBB.JK', 'CCCC.JK']
sectors = ['Technology', 'Finance', 'Energy']

rows = []
for i, sym in enumerate(symbols):
    price = 1000 + i * 500
    for d in dates:
        ret = np.random.normal(0.001, 0.02)
        c = price * (1 + ret)
        o = price * (1 + np.random.normal(0, 0.005))
        h = max(o, c) * (1 + abs(np.random.normal(0, 0.01)))
        l = min(o, c) * (1 - abs(np.random.normal(0, 0.01)))
        v = int(np.random.lognormal(15, 1))
        rows.append({
            'symbol': sym, 'date': d, 'sector': sectors[i],
            'open': round(o, 2), 'high': round(h, 2),
            'low': round(l, 2), 'close': round(c, 2),
            'volume': v, 'market_cap': price * 1e9,
            'macro_dji': 42000 + np.random.normal(0, 200),
            'macro_eido': 22 + np.random.normal(0, 0.5),
        })
        price = c

df_raw = pd.DataFrame(rows)
print(f"Input: {df_raw.shape[0]:,} baris x {df_raw.shape[1]} kolom")
print(f"Symbols: {df_raw['symbol'].nunique()}")

# Run pipeline
from ta_saham import generate_features

start = time.time()
df = generate_features(df_raw, include_candlestick=True, include_sliding_window=True)
elapsed = time.time() - start

print(f"\n⏱️  Waktu: {elapsed:.1f} detik")
print(f"📊 Output: {df.shape[0]:,} baris x {df.shape[1]} kolom")
print(f"🔢 Fitur baru: {df.shape[1] - df_raw.shape[1]}")

# Show feature categories
cols = df.columns.tolist()
cdl_count = len([c for c in cols if c.startswith('cdl_')])
lag_count = len([c for c in cols if '_lag' in c])
mean_count = len([c for c in cols if '_mean_' in c])
std_count = len([c for c in cols if '_std_' in c])
rank_count = len([c for c in cols if '_rank' in c])
ret_count = len([c for c in cols if c.startswith('ret_')])

print(f"\n📋 Breakdown:")
print(f"   Candlestick patterns: {cdl_count}")
print(f"   Lag features: {lag_count}")
print(f"   Rolling mean features: {mean_count}")
print(f"   Rolling std features: {std_count}")
print(f"   Rank features: {rank_count}")
print(f"   Return features: {ret_count}")
print(f"\n✅ TEST PASSED!")
