# ta-saham 🇮🇩

**Technical Analysis library untuk saham Indonesia. Pure Python — zero C dependencies.**

Menggantikan TA-Lib & pandas-ta tanpa masalah instalasi.

## Instalasi

```bash
pip install ta-saham
```

## Penggunaan

```python
from ta_saham import generate_features

# Input: DataFrame dengan kolom OHLCV + symbol
# Output: DataFrame dengan 300+ fitur teknikal
df = generate_features(df_raw)
```

## Fitur

- **80+ indikator teknikal** (RSI, MACD, ADX, Bollinger, dll)
- **61 pola candlestick** (Engulfing, Hammer, Doji, Morning Star, dll)
- **Sliding window features** (lag, rolling stats, delta, acceleration)
- **Cross-sectional ranking** (ranking saham vs peers)
- **Macro transforms** (return & regime macro indicators)
- **Zero external dependencies** — hanya pandas & numpy

## Dependency

- pandas >= 1.3.0
- numpy >= 1.20.0

Tidak perlu TA-Lib, tidak perlu C compiler, tidak perlu restart runtime.
