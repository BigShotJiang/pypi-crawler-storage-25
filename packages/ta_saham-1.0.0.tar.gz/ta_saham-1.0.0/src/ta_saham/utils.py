"""Utility helpers used across modules."""

import numpy as np
import pandas as pd


def safe_div(a, b, fill=0.0):
    """Division that returns fill value when denominator is zero."""
    return np.where(np.abs(b) < 1e-10, fill, a / b)


def true_range(high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    """Calculate True Range."""
    prev_close = close.shift(1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    return pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)


def real_body(open_: pd.Series, close: pd.Series) -> pd.Series:
    """Absolute size of candle body."""
    return (close - open_).abs()


def upper_shadow(open_: pd.Series, high: pd.Series, close: pd.Series) -> pd.Series:
    """Upper shadow length."""
    return high - pd.concat([open_, close], axis=1).max(axis=1)


def lower_shadow(open_: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    """Lower shadow length."""
    return pd.concat([open_, close], axis=1).min(axis=1) - low


def candle_range(high: pd.Series, low: pd.Series) -> pd.Series:
    """High - Low range."""
    return high - low


def is_bullish(open_: pd.Series, close: pd.Series) -> pd.Series:
    """True if close > open (green candle)."""
    return close > open_


def is_bearish(open_: pd.Series, close: pd.Series) -> pd.Series:
    """True if close < open (red candle)."""
    return close < open_


def body_pct_of_range(open_: pd.Series, high: pd.Series, low: pd.Series, close: pd.Series) -> pd.Series:
    """Body size as percentage of high-low range."""
    rng = candle_range(high, low)
    body = real_body(open_, close)
    return safe_div(body, rng, 0.0)
