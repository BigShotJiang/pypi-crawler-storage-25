"""
Overlap Studies
SMA, EMA, DEMA, TEMA, WMA, Bollinger Bands, KAMA, Parabolic SAR, Supertrend
"""

import numpy as np
import pandas as pd
from ta_saham.utils import true_range


def sma(series: pd.Series, period: int) -> pd.Series:
    """Simple Moving Average."""
    return series.rolling(period).mean()


def ema(series: pd.Series, period: int) -> pd.Series:
    """Exponential Moving Average."""
    return series.ewm(span=period, adjust=False).mean()


def dema(series: pd.Series, period: int) -> pd.Series:
    """Double Exponential Moving Average."""
    e1 = ema(series, period)
    e2 = ema(e1, period)
    return 2 * e1 - e2


def tema(series: pd.Series, period: int) -> pd.Series:
    """Triple Exponential Moving Average."""
    e1 = ema(series, period)
    e2 = ema(e1, period)
    e3 = ema(e2, period)
    return 3 * e1 - 3 * e2 + e3


def wma(series: pd.Series, period: int) -> pd.Series:
    """Weighted Moving Average."""
    weights = np.arange(1, period + 1, dtype=float)
    return series.rolling(period).apply(lambda x: np.dot(x, weights) / weights.sum(), raw=True)


def hma(series: pd.Series, period: int) -> pd.Series:
    """Hull Moving Average (pandas-ta exclusive)."""
    half = int(period / 2)
    sqrt_p = int(np.sqrt(period))
    wmaf = wma(series, half)
    wmas = wma(series, period)
    return wma(2 * wmaf - wmas, sqrt_p)


def bollinger_bands(close: pd.Series, period: int = 20, std_dev: float = 2.0):
    """Bollinger Bands — returns (upper, middle, lower, width, pct_b)."""
    middle = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    width = (upper - lower) / (middle + 1e-10)
    pct_b = (close - lower) / (upper - lower + 1e-10)
    return upper, middle, lower, width, pct_b


def kama(close: pd.Series, period: int = 10,
         fast_sc: int = 2, slow_sc: int = 30) -> pd.Series:
    """Kaufman Adaptive Moving Average."""
    direction = (close - close.shift(period)).abs()
    volatility = close.diff().abs().rolling(period).sum()
    er = direction / (volatility + 1e-10)  # Efficiency Ratio

    fast_alpha = 2.0 / (fast_sc + 1)
    slow_alpha = 2.0 / (slow_sc + 1)
    sc = (er * (fast_alpha - slow_alpha) + slow_alpha) ** 2

    result = pd.Series(np.nan, index=close.index)
    # Initialize with SMA
    first_valid = close.first_valid_index()
    if first_valid is None:
        return result

    start_loc = close.index.get_loc(first_valid) + period
    if start_loc >= len(close):
        return result

    result.iloc[start_loc] = close.iloc[:start_loc + 1].mean()

    for i in range(start_loc + 1, len(close)):
        if np.isnan(result.iloc[i-1]) or np.isnan(sc.iloc[i]):
            result.iloc[i] = result.iloc[i-1] if not np.isnan(result.iloc[i-1]) else close.iloc[i]
        else:
            result.iloc[i] = result.iloc[i-1] + sc.iloc[i] * (close.iloc[i] - result.iloc[i-1])

    return result


def parabolic_sar(high: pd.Series, low: pd.Series,
                  af_start: float = 0.02, af_step: float = 0.02,
                  af_max: float = 0.20) -> pd.Series:
    """Parabolic SAR."""
    n = len(high)
    sar = pd.Series(np.nan, index=high.index)
    trend = 1  # 1=up, -1=down
    af = af_start
    ep = low.iloc[0]
    sar_val = high.iloc[0]

    for i in range(2, n):
        prev_sar = sar_val

        if trend == 1:
            sar_val = prev_sar + af * (ep - prev_sar)
            sar_val = min(sar_val, low.iloc[i-1], low.iloc[i-2])

            if low.iloc[i] < sar_val:  # Reversal
                trend = -1
                sar_val = ep
                ep = low.iloc[i]
                af = af_start
            else:
                if high.iloc[i] > ep:
                    ep = high.iloc[i]
                    af = min(af + af_step, af_max)
        else:
            sar_val = prev_sar + af * (ep - prev_sar)
            sar_val = max(sar_val, high.iloc[i-1], high.iloc[i-2])

            if high.iloc[i] > sar_val:  # Reversal
                trend = 1
                sar_val = ep
                ep = high.iloc[i]
                af = af_start
            else:
                if low.iloc[i] < ep:
                    ep = low.iloc[i]
                    af = min(af + af_step, af_max)

        sar.iloc[i] = sar_val

    return sar


def supertrend(high: pd.Series, low: pd.Series, close: pd.Series,
               period: int = 10, multiplier: float = 3.0):
    """Supertrend — returns (supertrend_line, direction)."""
    tr = true_range(high, low, close)
    atr = tr.ewm(alpha=1/period, adjust=False).mean()

    hl2 = (high + low) / 2
    upper_band = hl2 + multiplier * atr
    lower_band = hl2 - multiplier * atr

    st = pd.Series(np.nan, index=close.index)
    direction = pd.Series(1, index=close.index)

    for i in range(1, len(close)):
        if close.iloc[i] > upper_band.iloc[i-1] if not np.isnan(upper_band.iloc[i-1]) else False:
            direction.iloc[i] = 1
        elif close.iloc[i] < lower_band.iloc[i-1] if not np.isnan(lower_band.iloc[i-1]) else False:
            direction.iloc[i] = -1
        else:
            direction.iloc[i] = direction.iloc[i-1]

        if direction.iloc[i] == 1:
            st.iloc[i] = max(lower_band.iloc[i],
                             st.iloc[i-1] if not np.isnan(st.iloc[i-1]) and direction.iloc[i-1] == 1 else lower_band.iloc[i])
        else:
            st.iloc[i] = min(upper_band.iloc[i],
                             st.iloc[i-1] if not np.isnan(st.iloc[i-1]) and direction.iloc[i-1] == -1 else upper_band.iloc[i])

    return st, direction


def donchian_channels(high: pd.Series, low: pd.Series, period: int = 20):
    """Donchian Channels — returns (upper, middle, lower)."""
    upper = high.rolling(period).max()
    lower = low.rolling(period).min()
    middle = (upper + lower) / 2
    return upper, middle, lower


def keltner_channels(high: pd.Series, low: pd.Series, close: pd.Series,
                     ema_period: int = 20, atr_period: int = 10, multiplier: float = 1.5):
    """Keltner Channels — returns (upper, middle, lower)."""
    middle = close.ewm(span=ema_period, adjust=False).mean()
    tr = true_range(high, low, close)
    atr = tr.ewm(alpha=1/atr_period, adjust=False).mean()
    upper = middle + multiplier * atr
    lower = middle - multiplier * atr
    return upper, middle, lower


def squeeze(high: pd.Series, low: pd.Series, close: pd.Series,
            bb_period: int = 20, bb_std: float = 2.0,
            kc_period: int = 20, kc_mult: float = 1.5) -> pd.Series:
    """TTM Squeeze — returns squeeze_on (1=squeeze active, 0=not)."""
    bb_upper, _, bb_lower, _, _ = bollinger_bands(close, bb_period, bb_std)
    kc_upper, _, kc_lower = keltner_channels(high, low, close, kc_period, kc_period, kc_mult)
    squeeze_on = ((bb_lower > kc_lower) & (bb_upper < kc_upper)).astype(int)
    return squeeze_on
