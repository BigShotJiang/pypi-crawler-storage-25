"""
Volume Indicators
OBV, Chaikin A/D, Chaikin Oscillator, CMF, Force Index, VPT, VWAP, PVI, NVI
"""

import numpy as np
import pandas as pd


def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
    """On Balance Volume."""
    sign = np.sign(close.diff())
    return (sign * volume).cumsum()


def ad_line(high: pd.Series, low: pd.Series, close: pd.Series,
            volume: pd.Series) -> pd.Series:
    """Chaikin Accumulation/Distribution Line."""
    mfm = ((close - low) - (high - close)) / (high - low + 1e-10)
    return (mfm * volume).cumsum()


def chaikin_oscillator(high: pd.Series, low: pd.Series, close: pd.Series,
                       volume: pd.Series, fast: int = 3, slow: int = 10) -> pd.Series:
    """Chaikin Oscillator."""
    adl = ad_line(high, low, close, volume)
    return adl.ewm(span=fast, adjust=False).mean() - adl.ewm(span=slow, adjust=False).mean()


def cmf(high: pd.Series, low: pd.Series, close: pd.Series,
        volume: pd.Series, period: int = 20) -> pd.Series:
    """Chaikin Money Flow."""
    mfm = ((close - low) - (high - close)) / (high - low + 1e-10)
    mfv = mfm * volume
    return mfv.rolling(period).sum() / (volume.rolling(period).sum() + 1e-10)


def force_index(close: pd.Series, volume: pd.Series,
                period: int = 13) -> pd.Series:
    """Elder Force Index."""
    fi = close.diff() * volume
    return fi.ewm(span=period, adjust=False).mean()


def vpt(close: pd.Series, volume: pd.Series) -> pd.Series:
    """Volume Price Trend."""
    return (volume * close.pct_change()).cumsum()


def vwap(high: pd.Series, low: pd.Series, close: pd.Series,
         volume: pd.Series, period: int = 20) -> pd.Series:
    """Rolling VWAP (Volume Weighted Average Price)."""
    tp = (high + low + close) / 3
    vp = tp * volume
    return vp.rolling(period).sum() / (volume.rolling(period).sum() + 1e-10)


def pvi(close: pd.Series, volume: pd.Series) -> pd.Series:
    """Positive Volume Index."""
    ret = close.pct_change()
    vol_up = volume > volume.shift(1)
    pvi_val = pd.Series(1000.0, index=close.index)
    for i in range(1, len(close)):
        if vol_up.iloc[i]:
            pvi_val.iloc[i] = pvi_val.iloc[i-1] * (1 + ret.iloc[i]) if not np.isnan(ret.iloc[i]) else pvi_val.iloc[i-1]
        else:
            pvi_val.iloc[i] = pvi_val.iloc[i-1]
    return pvi_val


def nvi(close: pd.Series, volume: pd.Series) -> pd.Series:
    """Negative Volume Index."""
    ret = close.pct_change()
    vol_down = volume < volume.shift(1)
    nvi_val = pd.Series(1000.0, index=close.index)
    for i in range(1, len(close)):
        if vol_down.iloc[i]:
            nvi_val.iloc[i] = nvi_val.iloc[i-1] * (1 + ret.iloc[i]) if not np.isnan(ret.iloc[i]) else nvi_val.iloc[i-1]
        else:
            nvi_val.iloc[i] = nvi_val.iloc[i-1]
    return nvi_val


def ease_of_movement(high: pd.Series, low: pd.Series,
                     volume: pd.Series, period: int = 14) -> pd.Series:
    """Ease of Movement."""
    distance = ((high + low) / 2) - ((high.shift(1) + low.shift(1)) / 2)
    box_ratio = volume / (high - low + 1e-10)
    emv = distance / (box_ratio + 1e-10)
    return emv.rolling(period).mean()
