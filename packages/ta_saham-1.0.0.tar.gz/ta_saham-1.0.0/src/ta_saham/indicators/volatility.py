"""
Volatility & Statistics Indicators
ATR, NATR, Historical Volatility, Linear Regression, Z-Score, Entropy
"""

import numpy as np
import pandas as pd
from ta_saham.utils import true_range


def atr(high: pd.Series, low: pd.Series, close: pd.Series,
        period: int = 14) -> pd.Series:
    """Average True Range."""
    tr = true_range(high, low, close)
    return tr.ewm(alpha=1/period, adjust=False).mean()


def natr(high: pd.Series, low: pd.Series, close: pd.Series,
         period: int = 14) -> pd.Series:
    """Normalized Average True Range (ATR as % of close)."""
    return atr(high, low, close, period) / (close + 1e-10) * 100


def historical_volatility(close: pd.Series, period: int = 20,
                          annualize: int = 252) -> pd.Series:
    """Historical Volatility (annualized std of log returns)."""
    log_ret = np.log(close / close.shift(1))
    return log_ret.rolling(period).std() * np.sqrt(annualize)


def linear_regression_slope(series: pd.Series, period: int = 14) -> pd.Series:
    """Linear Regression Slope — direction & speed of trend."""
    def _slope(x):
        if len(x) < 2:
            return np.nan
        n = len(x)
        x_idx = np.arange(n)
        denom = n * (x_idx ** 2).sum() - x_idx.sum() ** 2
        if abs(denom) < 1e-10:
            return 0.0
        return (n * (x_idx * x).sum() - x_idx.sum() * x.sum()) / denom
    return series.rolling(period).apply(_slope, raw=True)


def linear_regression_angle(series: pd.Series, period: int = 14) -> pd.Series:
    """Linear Regression Angle (in degrees)."""
    slope = linear_regression_slope(series, period)
    return np.degrees(np.arctan(slope))


def linear_regression_rsquare(series: pd.Series, period: int = 14) -> pd.Series:
    """R-squared of linear regression — how well price fits a line."""
    def _r2(x):
        if len(x) < 2:
            return np.nan
        n = len(x)
        x_idx = np.arange(n, dtype=float)
        mean_x = x_idx.mean()
        mean_y = x.mean()
        ss_tot = ((x - mean_y) ** 2).sum()
        if ss_tot < 1e-10:
            return 0.0
        b1 = ((x_idx - mean_x) * (x - mean_y)).sum() / ((x_idx - mean_x) ** 2).sum()
        b0 = mean_y - b1 * mean_x
        y_pred = b0 + b1 * x_idx
        ss_res = ((x - y_pred) ** 2).sum()
        return 1 - ss_res / ss_tot
    return series.rolling(period).apply(_r2, raw=True)


def zscore(series: pd.Series, period: int = 20) -> pd.Series:
    """Z-Score (how many std devs from rolling mean)."""
    mean = series.rolling(period).mean()
    std = series.rolling(period).std()
    return (series - mean) / (std + 1e-10)


def entropy(series: pd.Series, period: int = 20) -> pd.Series:
    """Approximate entropy of price changes (information content)."""
    def _entropy(x):
        pct = np.diff(x) / (x[:-1] + 1e-10)
        bins = np.histogram(pct, bins=10)[0]
        probs = bins / (bins.sum() + 1e-10)
        probs = probs[probs > 0]
        return -np.sum(probs * np.log2(probs))
    return series.rolling(period + 1).apply(_entropy, raw=True)


def skewness(series: pd.Series, period: int = 20) -> pd.Series:
    """Rolling skewness of returns."""
    return series.pct_change().rolling(period).skew()


def kurtosis(series: pd.Series, period: int = 20) -> pd.Series:
    """Rolling kurtosis of returns."""
    return series.pct_change().rolling(period).kurt()


def beta(stock_ret: pd.Series, market_ret: pd.Series,
         period: int = 60) -> pd.Series:
    """Rolling beta vs market."""
    cov = stock_ret.rolling(period).cov(market_ret)
    var = market_ret.rolling(period).var()
    return cov / (var + 1e-10)
