"""
Momentum Indicators
RSI, MACD, MFI, CCI, Stochastic, ADX, AROON, Williams %R,
Ultimate Oscillator, StochRSI, TRIX, PPO, CMO, BOP, ROC
"""

import numpy as np
import pandas as pd


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """Relative Strength Index."""
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0).ewm(alpha=1/period, adjust=False).mean()
    loss = (-delta.where(delta < 0, 0.0)).ewm(alpha=1/period, adjust=False).mean()
    rs = gain / (loss + 1e-10)
    return 100 - (100 / (1 + rs))


def macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    """MACD — returns (macd_line, signal_line, histogram)."""
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    hist = macd_line - signal_line
    return macd_line, signal_line, hist


def mfi(high: pd.Series, low: pd.Series, close: pd.Series,
        volume: pd.Series, period: int = 14) -> pd.Series:
    """Money Flow Index (RSI with volume)."""
    tp = (high + low + close) / 3
    rmf = tp * volume
    mf_pos = rmf.where(tp > tp.shift(1), 0.0)
    mf_neg = rmf.where(tp < tp.shift(1), 0.0)
    pos_sum = mf_pos.rolling(window=period).sum()
    neg_sum = mf_neg.rolling(window=period).sum()
    return 100 - (100 / (1 + pos_sum / (neg_sum + 1e-10)))


def cci(high: pd.Series, low: pd.Series, close: pd.Series,
        period: int = 20) -> pd.Series:
    """Commodity Channel Index."""
    tp = (high + low + close) / 3
    sma_tp = tp.rolling(period).mean()
    mad = (tp - sma_tp).abs().rolling(period).mean()
    return (tp - sma_tp) / (0.015 * mad + 1e-10)


def stochastic(high: pd.Series, low: pd.Series, close: pd.Series,
               k_period: int = 14, d_period: int = 3):
    """Stochastic Oscillator — returns (stoch_k, stoch_d)."""
    ll = low.rolling(k_period).min()
    hh = high.rolling(k_period).max()
    k = 100 * (close - ll) / (hh - ll + 1e-10)
    d = k.rolling(d_period).mean()
    return k, d


def adx(high: pd.Series, low: pd.Series, close: pd.Series,
        period: int = 14) -> pd.Series:
    """Average Directional Index — measures trend strength."""
    prev_high = high.shift(1)
    prev_low = low.shift(1)
    prev_close = close.shift(1)

    # True Range
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    # Directional Movement
    up_move = high - prev_high
    down_move = prev_low - low

    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)

    plus_dm = pd.Series(plus_dm, index=close.index)
    minus_dm = pd.Series(minus_dm, index=close.index)

    # Smoothed with Wilder's method (EMA with alpha=1/period)
    atr = tr.ewm(alpha=1/period, adjust=False).mean()
    plus_di = 100 * plus_dm.ewm(alpha=1/period, adjust=False).mean() / (atr + 1e-10)
    minus_di = 100 * minus_dm.ewm(alpha=1/period, adjust=False).mean() / (atr + 1e-10)

    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-10)
    adx_val = dx.ewm(alpha=1/period, adjust=False).mean()
    return adx_val


def adx_components(high: pd.Series, low: pd.Series, close: pd.Series,
                   period: int = 14):
    """ADX with +DI and -DI — returns (adx, plus_di, minus_di)."""
    prev_high = high.shift(1)
    prev_low = low.shift(1)
    prev_close = close.shift(1)

    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    up_move = high - prev_high
    down_move = prev_low - low
    plus_dm = pd.Series(np.where((up_move > down_move) & (up_move > 0), up_move, 0.0), index=close.index)
    minus_dm = pd.Series(np.where((down_move > up_move) & (down_move > 0), down_move, 0.0), index=close.index)

    atr = tr.ewm(alpha=1/period, adjust=False).mean()
    plus_di = 100 * plus_dm.ewm(alpha=1/period, adjust=False).mean() / (atr + 1e-10)
    minus_di = 100 * minus_dm.ewm(alpha=1/period, adjust=False).mean() / (atr + 1e-10)
    dx = 100 * (plus_di - minus_di).abs() / (plus_di + minus_di + 1e-10)
    adx_val = dx.ewm(alpha=1/period, adjust=False).mean()
    return adx_val, plus_di, minus_di


def aroon(high: pd.Series, low: pd.Series, period: int = 25):
    """Aroon indicator — returns (aroon_up, aroon_down, aroon_osc)."""
    aroon_up = high.rolling(period + 1).apply(lambda x: x.argmax(), raw=True) / period * 100
    aroon_down = low.rolling(period + 1).apply(lambda x: x.argmin(), raw=True) / period * 100
    aroon_osc = aroon_up - aroon_down
    return aroon_up, aroon_down, aroon_osc


def williams_r(high: pd.Series, low: pd.Series, close: pd.Series,
               period: int = 14) -> pd.Series:
    """Williams %R."""
    hh = high.rolling(period).max()
    ll = low.rolling(period).min()
    return -100 * (hh - close) / (hh - ll + 1e-10)


def ultimate_oscillator(high: pd.Series, low: pd.Series, close: pd.Series,
                        p1: int = 7, p2: int = 14, p3: int = 28) -> pd.Series:
    """Ultimate Oscillator — multi-timeframe momentum."""
    prev_close = close.shift(1)
    bp = close - pd.concat([low, prev_close], axis=1).min(axis=1)
    tr1 = high - low
    tr2 = (high - prev_close).abs()
    tr3 = (low - prev_close).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)

    avg1 = bp.rolling(p1).sum() / (tr.rolling(p1).sum() + 1e-10)
    avg2 = bp.rolling(p2).sum() / (tr.rolling(p2).sum() + 1e-10)
    avg3 = bp.rolling(p3).sum() / (tr.rolling(p3).sum() + 1e-10)

    return 100 * (4 * avg1 + 2 * avg2 + avg3) / 7


def stochrsi(close: pd.Series, rsi_period: int = 14,
             stoch_period: int = 14, k_period: int = 3) -> pd.Series:
    """Stochastic RSI."""
    rsi_val = rsi(close, rsi_period)
    ll = rsi_val.rolling(stoch_period).min()
    hh = rsi_val.rolling(stoch_period).max()
    stochrsi_k = (rsi_val - ll) / (hh - ll + 1e-10)
    return stochrsi_k.rolling(k_period).mean()


def trix(close: pd.Series, period: int = 15) -> pd.Series:
    """TRIX — 1-day ROC of triple smoothed EMA."""
    ema1 = close.ewm(span=period, adjust=False).mean()
    ema2 = ema1.ewm(span=period, adjust=False).mean()
    ema3 = ema2.ewm(span=period, adjust=False).mean()
    return ema3.pct_change() * 100


def ppo(close: pd.Series, fast: int = 12, slow: int = 26) -> pd.Series:
    """Percentage Price Oscillator (MACD in percent)."""
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    return (ema_fast - ema_slow) / (ema_slow + 1e-10) * 100


def cmo(close: pd.Series, period: int = 14) -> pd.Series:
    """Chande Momentum Oscillator."""
    delta = close.diff()
    gain = delta.where(delta > 0, 0.0).rolling(period).sum()
    loss = (-delta.where(delta < 0, 0.0)).rolling(period).sum()
    return (gain - loss) / (gain + loss + 1e-10) * 100


def bop(open_: pd.Series, high: pd.Series, low: pd.Series,
        close: pd.Series) -> pd.Series:
    """Balance of Power."""
    return (close - open_) / (high - low + 1e-10)


def roc(close: pd.Series, period: int = 10) -> pd.Series:
    """Rate of Change."""
    return (close - close.shift(period)) / (close.shift(period) + 1e-10) * 100


def momentum(close: pd.Series, period: int = 10) -> pd.Series:
    """Momentum (absolute difference)."""
    return close - close.shift(period)


def awesome_oscillator(high: pd.Series, low: pd.Series,
                       fast: int = 5, slow: int = 34) -> pd.Series:
    """Awesome Oscillator (pandas-ta exclusive)."""
    mid = (high + low) / 2
    return mid.rolling(fast).mean() - mid.rolling(slow).mean()


def fisher_transform(high: pd.Series, low: pd.Series,
                     period: int = 9) -> pd.Series:
    """Fisher Transform."""
    mid = (high + low) / 2
    ll = mid.rolling(period).min()
    hh = mid.rolling(period).max()
    val = 2 * ((mid - ll) / (hh - ll + 1e-10)) - 1
    val = val.clip(-0.999, 0.999)
    return 0.5 * np.log((1 + val) / (1 - val + 1e-10))
