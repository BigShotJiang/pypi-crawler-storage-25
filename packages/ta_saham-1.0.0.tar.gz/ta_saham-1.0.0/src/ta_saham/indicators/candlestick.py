"""
Candlestick Pattern Recognition — 61 patterns from TA-Lib reimplemented in pure Python.
Each function returns: +1 (bullish), -1 (bearish), or 0 (no pattern).
For single-direction patterns, returns 1 (detected) or 0 (not detected).
"""

import numpy as np
import pandas as pd

# ═══════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════

def _body(o, c):
    return (c - o).abs()

def _range(h, l):
    return h - l + 1e-10

def _upper_shadow(o, h, c):
    return h - pd.concat([o, c], axis=1).max(axis=1)

def _lower_shadow(o, l, c):
    return pd.concat([o, c], axis=1).min(axis=1) - l

def _is_bull(o, c):
    return c > o

def _is_bear(o, c):
    return c < o

def _is_doji(o, h, l, c, threshold=0.05):
    return _body(o, c) <= _range(h, l) * threshold

def _body_pct(o, h, l, c):
    return _body(o, c) / _range(h, l)

# ═══════════════════════════════════════════════════════════════
# SINGLE CANDLE PATTERNS
# ═══════════════════════════════════════════════════════════════

def cdl_doji(o, h, l, c):
    """Doji — body very small relative to range."""
    return _is_doji(o, h, l, c, 0.05).astype(int)

def cdl_dragonfly_doji(o, h, l, c):
    """Dragonfly Doji — doji with long lower shadow, no upper shadow."""
    doji = _is_doji(o, h, l, c, 0.05)
    long_lower = _lower_shadow(o, l, c) > _range(h, l) * 0.6
    small_upper = _upper_shadow(o, h, c) < _range(h, l) * 0.1
    return (doji & long_lower & small_upper).astype(int)

def cdl_gravestone_doji(o, h, l, c):
    """Gravestone Doji — doji with long upper shadow, no lower shadow."""
    doji = _is_doji(o, h, l, c, 0.05)
    long_upper = _upper_shadow(o, h, c) > _range(h, l) * 0.6
    small_lower = _lower_shadow(o, l, c) < _range(h, l) * 0.1
    return (doji & long_upper & small_lower).astype(int)

def cdl_long_legged_doji(o, h, l, c):
    """Long-Legged Doji — doji with long both shadows."""
    doji = _is_doji(o, h, l, c, 0.05)
    long_upper = _upper_shadow(o, h, c) > _range(h, l) * 0.3
    long_lower = _lower_shadow(o, l, c) > _range(h, l) * 0.3
    return (doji & long_upper & long_lower).astype(int)

def cdl_rickshaw_man(o, h, l, c):
    """Rickshaw Man — same as long legged doji (alias)."""
    return cdl_long_legged_doji(o, h, l, c)

def cdl_marubozu(o, h, l, c):
    """Marubozu — full body candle, no shadows. +1=bull, -1=bear."""
    body_big = _body_pct(o, h, l, c) > 0.95
    bull = body_big & _is_bull(o, c)
    bear = body_big & _is_bear(o, c)
    return bull.astype(int) - bear.astype(int)

def cdl_closing_marubozu(o, h, l, c):
    """Closing Marubozu — close equals high (bull) or low (bear)."""
    bull = (c == h) & _is_bull(o, c) & (_body_pct(o, h, l, c) > 0.6)
    bear = (c == l) & _is_bear(o, c) & (_body_pct(o, h, l, c) > 0.6)
    return bull.astype(int) - bear.astype(int)

def cdl_spinning_top(o, h, l, c):
    """Spinning Top — small body, shadows on both sides."""
    small_body = _body_pct(o, h, l, c) < 0.3
    has_shadows = (_upper_shadow(o, h, c) > _range(h, l) * 0.15) & \
                  (_lower_shadow(o, l, c) > _range(h, l) * 0.15)
    return (small_body & has_shadows & ~_is_doji(o, h, l, c, 0.05)).astype(int)

def cdl_high_wave(o, h, l, c):
    """High-Wave Candle — very long shadows relative to small body."""
    small_body = _body_pct(o, h, l, c) < 0.2
    long_shadows = (_upper_shadow(o, h, c) + _lower_shadow(o, l, c)) > _range(h, l) * 0.7
    return (small_body & long_shadows).astype(int)

def cdl_hammer(o, h, l, c):
    """Hammer — small body at top, long lower shadow (bullish reversal)."""
    small_body = _body_pct(o, h, l, c).between(0.1, 0.35)
    long_lower = _lower_shadow(o, l, c) >= _body(o, c) * 2
    small_upper = _upper_shadow(o, h, c) < _body(o, c) * 0.5
    return (small_body & long_lower & small_upper).astype(int)

def cdl_hanging_man(o, h, l, c):
    """Hanging Man — same shape as hammer but during uptrend (bearish)."""
    return cdl_hammer(o, h, l, c)  # Shape same; context determines meaning

def cdl_inverted_hammer(o, h, l, c):
    """Inverted Hammer — small body at bottom, long upper shadow."""
    small_body = _body_pct(o, h, l, c).between(0.1, 0.35)
    long_upper = _upper_shadow(o, h, c) >= _body(o, c) * 2
    small_lower = _lower_shadow(o, l, c) < _body(o, c) * 0.5
    return (small_body & long_upper & small_lower).astype(int)

def cdl_shooting_star(o, h, l, c):
    """Shooting Star — same as inverted hammer (bearish context)."""
    return cdl_inverted_hammer(o, h, l, c)

def cdl_belt_hold(o, h, l, c):
    """Belt-hold — opens at low (bull) or high (bear) with large body."""
    bull = (o == l) & _is_bull(o, c) & (_body_pct(o, h, l, c) > 0.6)
    bear = (o == h) & _is_bear(o, c) & (_body_pct(o, h, l, c) > 0.6)
    return bull.astype(int) - bear.astype(int)

def cdl_long_line(o, h, l, c):
    """Long Line Candle — very large body."""
    return (_body_pct(o, h, l, c) > 0.7).astype(int)

def cdl_short_line(o, h, l, c):
    """Short Line Candle — very small body."""
    return (_body_pct(o, h, l, c) < 0.2).astype(int)

def cdl_takuri(o, h, l, c):
    """Takuri — dragonfly doji with very long lower shadow."""
    doji = _is_doji(o, h, l, c, 0.1)
    very_long_lower = _lower_shadow(o, l, c) > _range(h, l) * 0.7
    return (doji & very_long_lower).astype(int)


# ═══════════════════════════════════════════════════════════════
# TWO CANDLE PATTERNS
# ═══════════════════════════════════════════════════════════════

def cdl_engulfing(o, h, l, c):
    """Engulfing Pattern. +1=bullish, -1=bearish."""
    po, pc = o.shift(1), c.shift(1)
    bull = _is_bear(po, pc) & _is_bull(o, c) & (o <= pc) & (c >= po)
    bear = _is_bull(po, pc) & _is_bear(o, c) & (o >= pc) & (c <= po)
    return bull.astype(int) - bear.astype(int)

def cdl_harami(o, h, l, c):
    """Harami Pattern. +1=bullish, -1=bearish."""
    po, pc = o.shift(1), c.shift(1)
    prev_big = _body(po, pc) > _range(h.shift(1), l.shift(1)) * 0.5
    bull = _is_bear(po, pc) & _is_bull(o, c) & (o >= pc) & (c <= po) & prev_big
    bear = _is_bull(po, pc) & _is_bear(o, c) & (o <= pc) & (c >= po) & prev_big
    return bull.astype(int) - bear.astype(int)

def cdl_harami_cross(o, h, l, c):
    """Harami Cross — harami where second candle is doji."""
    po, pc = o.shift(1), c.shift(1)
    doji = _is_doji(o, h, l, c, 0.05)
    prev_big = _body(po, pc) > _range(h.shift(1), l.shift(1)) * 0.5
    inside = (pd.concat([o, c], axis=1).max(axis=1) <= pd.concat([po, pc], axis=1).max(axis=1)) & \
             (pd.concat([o, c], axis=1).min(axis=1) >= pd.concat([po, pc], axis=1).min(axis=1))
    bull = _is_bear(po, pc) & doji & inside & prev_big
    bear = _is_bull(po, pc) & doji & inside & prev_big
    return bull.astype(int) - bear.astype(int)

def cdl_piercing(o, h, l, c):
    """Piercing Pattern (bullish)."""
    po, pc = o.shift(1), c.shift(1)
    prev_bear = _is_bear(po, pc)
    gap_down = o < pc
    close_above_mid = c > (po + pc) / 2
    close_below_prev_open = c < po
    return (prev_bear & gap_down & _is_bull(o, c) & close_above_mid & close_below_prev_open).astype(int)

def cdl_dark_cloud_cover(o, h, l, c):
    """Dark Cloud Cover (bearish)."""
    po, pc = o.shift(1), c.shift(1)
    prev_bull = _is_bull(po, pc)
    gap_up = o > pc
    close_below_mid = c < (po + pc) / 2
    close_above_prev_open = c > po
    return (prev_bull & gap_up & _is_bear(o, c) & close_below_mid & close_above_prev_open).astype(int)

def cdl_doji_star(o, h, l, c):
    """Doji Star — gap + doji. +1=bullish, -1=bearish."""
    po, pc = o.shift(1), c.shift(1)
    doji = _is_doji(o, h, l, c, 0.05)
    prev_big = _body(po, pc) > _range(h.shift(1), l.shift(1)) * 0.5
    bull = _is_bear(po, pc) & doji & (pd.concat([o, c], axis=1).max(axis=1) < pc) & prev_big
    bear = _is_bull(po, pc) & doji & (pd.concat([o, c], axis=1).min(axis=1) > pc) & prev_big
    return bull.astype(int) - bear.astype(int)

def cdl_counterattack(o, h, l, c):
    """Counterattack — opposite color, same close level."""
    po, pc = o.shift(1), c.shift(1)
    same_close = (c - pc).abs() < _range(h, l) * 0.05
    bull = _is_bear(po, pc) & _is_bull(o, c) & same_close
    bear = _is_bull(po, pc) & _is_bear(o, c) & same_close
    return bull.astype(int) - bear.astype(int)

def cdl_inn_neck(o, h, l, c):
    """In-Neck Pattern (bearish continuation)."""
    po, pc = o.shift(1), c.shift(1)
    prev_bear = _is_bear(po, pc) & (_body_pct(po, h.shift(1), l.shift(1), pc) > 0.5)
    return (prev_bear & _is_bull(o, c) & (o < pc) & ((c - pc).abs() < _range(h, l) * 0.05)).astype(int)

def cdl_on_neck(o, h, l, c):
    """On-Neck Pattern (bearish continuation)."""
    po, pc = o.shift(1), c.shift(1)
    prev_bear = _is_bear(po, pc) & (_body_pct(po, h.shift(1), l.shift(1), pc) > 0.5)
    close_at_prev_low = (c - l.shift(1)).abs() < _range(h, l) * 0.05
    return (prev_bear & _is_bull(o, c) & (o < pc) & close_at_prev_low).astype(int)

def cdl_thrusting(o, h, l, c):
    """Thrusting Pattern (bearish continuation)."""
    po, pc = o.shift(1), c.shift(1)
    prev_bear = _is_bear(po, pc)
    gap_down = o < pc
    close_in_prev = (c > pc) & (c < (po + pc) / 2)
    return (prev_bear & gap_down & _is_bull(o, c) & close_in_prev).astype(int)

def cdl_separating_lines(o, h, l, c):
    """Separating Lines. +1=bullish, -1=bearish."""
    po, pc = o.shift(1), c.shift(1)
    same_open = (o - po).abs() < _range(h, l) * 0.03
    bull = _is_bear(po, pc) & _is_bull(o, c) & same_open
    bear = _is_bull(po, pc) & _is_bear(o, c) & same_open
    return bull.astype(int) - bear.astype(int)

def cdl_matching_low(o, h, l, c):
    """Matching Low (bullish reversal)."""
    pc = c.shift(1)
    both_bear = _is_bear(o, c) & _is_bear(o.shift(1), pc)
    same_close = (c - pc).abs() < _range(h, l) * 0.03
    return (both_bear & same_close).astype(int)

def cdl_homing_pigeon(o, h, l, c):
    """Homing Pigeon (bullish) — like harami but both bearish."""
    po, pc = o.shift(1), c.shift(1)
    both_bear = _is_bear(o, c) & _is_bear(po, pc)
    inside = (c >= pc) & (o <= po)
    return (both_bear & inside).astype(int)

def cdl_kicking(o, h, l, c):
    """Kicking — marubozu gap. +1=bullish, -1=bearish."""
    po, ph, pl, pc = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    prev_bear_maru = _is_bear(po, pc) & (_body_pct(po, ph, pl, pc) > 0.9)
    curr_bull_maru = _is_bull(o, c) & (_body_pct(o, h, l, c) > 0.9)
    bull = prev_bear_maru & curr_bull_maru & (o > po)

    prev_bull_maru = _is_bull(po, pc) & (_body_pct(po, ph, pl, pc) > 0.9)
    curr_bear_maru = _is_bear(o, c) & (_body_pct(o, h, l, c) > 0.9)
    bear = prev_bull_maru & curr_bear_maru & (o < po)
    return bull.astype(int) - bear.astype(int)

def cdl_two_crows(o, h, l, c):
    """Two Crows (bearish)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    first_bull = _is_bull(o1, c1)
    second_bear_gap = _is_bear(o2, c2) & (o2 > c1)
    third_bear_engulf = _is_bear(o, c) & (o > o2) & (c < c2) & (c > c1)
    return (first_bull & second_bear_gap & third_bear_engulf).astype(int)


# ═══════════════════════════════════════════════════════════════
# THREE CANDLE PATTERNS
# ═══════════════════════════════════════════════════════════════

def cdl_morning_star(o, h, l, c, body_threshold=0.3):
    """Morning Star (bullish reversal)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, h2, l2, c2 = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    first_bear = _is_bear(o1, c1) & (_body_pct(o1, h.shift(2), l.shift(2), c1) > 0.5)
    second_small = _body_pct(o2, h2, l2, c2) < body_threshold
    second_gap = pd.concat([o2, c2], axis=1).max(axis=1) < c1
    third_bull = _is_bull(o, c) & (c > (o1 + c1) / 2)
    return (first_bear & second_small & second_gap & third_bull).astype(int)

def cdl_evening_star(o, h, l, c, body_threshold=0.3):
    """Evening Star (bearish reversal)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, h2, l2, c2 = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    first_bull = _is_bull(o1, c1) & (_body_pct(o1, h.shift(2), l.shift(2), c1) > 0.5)
    second_small = _body_pct(o2, h2, l2, c2) < body_threshold
    second_gap = pd.concat([o2, c2], axis=1).min(axis=1) > c1
    third_bear = _is_bear(o, c) & (c < (o1 + c1) / 2)
    return (first_bull & second_small & second_gap & third_bear).astype(int)

def cdl_morning_doji_star(o, h, l, c):
    """Morning Doji Star — morning star with doji as middle candle."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, h2, l2, c2 = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    first_bear = _is_bear(o1, c1) & (_body_pct(o1, h.shift(2), l.shift(2), c1) > 0.5)
    second_doji = _is_doji(o2, h2, l2, c2, 0.05)
    third_bull = _is_bull(o, c) & (c > (o1 + c1) / 2)
    return (first_bear & second_doji & third_bull).astype(int)

def cdl_evening_doji_star(o, h, l, c):
    """Evening Doji Star — evening star with doji."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, h2, l2, c2 = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    first_bull = _is_bull(o1, c1) & (_body_pct(o1, h.shift(2), l.shift(2), c1) > 0.5)
    second_doji = _is_doji(o2, h2, l2, c2, 0.05)
    third_bear = _is_bear(o, c) & (c < (o1 + c1) / 2)
    return (first_bull & second_doji & third_bear).astype(int)

def cdl_three_white_soldiers(o, h, l, c):
    """Three Advancing White Soldiers (bullish)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    all_bull = _is_bull(o1, c1) & _is_bull(o2, c2) & _is_bull(o, c)
    ascending = (c > c2) & (c2 > c1)
    opens_in_body = (o > o2) & (o < c2) & (o2 > o1) & (o2 < c1)
    return (all_bull & ascending & opens_in_body).astype(int)

def cdl_three_black_crows(o, h, l, c):
    """Three Black Crows (bearish)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    all_bear = _is_bear(o1, c1) & _is_bear(o2, c2) & _is_bear(o, c)
    descending = (c < c2) & (c2 < c1)
    opens_in_body = (o < o2) & (o > c2) & (o2 < o1) & (o2 > c1)
    return (all_bear & descending & opens_in_body).astype(int)

def cdl_three_inside(o, h, l, c):
    """Three Inside Up/Down. +1=bullish, -1=bearish."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    # Bullish: big bear, small bull inside, then close above
    bull_1 = _is_bear(o1, c1)
    bull_2 = _is_bull(o2, c2) & (o2 >= c1) & (c2 <= o1)
    bull_3 = _is_bull(o, c) & (c > o1)
    # Bearish: big bull, small bear inside, then close below
    bear_1 = _is_bull(o1, c1)
    bear_2 = _is_bear(o2, c2) & (o2 <= c1) & (c2 >= o1)
    bear_3 = _is_bear(o, c) & (c < o1)
    return (bull_1 & bull_2 & bull_3).astype(int) - (bear_1 & bear_2 & bear_3).astype(int)

def cdl_three_outside(o, h, l, c):
    """Three Outside Up/Down. +1=bullish, -1=bearish."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    bull_engulf = _is_bear(o1, c1) & _is_bull(o2, c2) & (o2 <= c1) & (c2 >= o1)
    bull_3 = _is_bull(o, c) & (c > c2)
    bear_engulf = _is_bull(o1, c1) & _is_bear(o2, c2) & (o2 >= c1) & (c2 <= o1)
    bear_3 = _is_bear(o, c) & (c < c2)
    return (bull_engulf & bull_3).astype(int) - (bear_engulf & bear_3).astype(int)

def cdl_three_line_strike(o, h, l, c):
    """Three-Line Strike. +1=bullish, -1=bearish."""
    o1, c1 = o.shift(3), c.shift(3)
    o2, c2 = o.shift(2), c.shift(2)
    o3, c3 = o.shift(1), c.shift(1)
    bull_3 = _is_bull(o1, c1) & _is_bull(o2, c2) & _is_bull(o3, c3) & (c2 > c1) & (c3 > c2)
    bull_strike = _is_bear(o, c) & (o > c3) & (c < o1)
    bear_3 = _is_bear(o1, c1) & _is_bear(o2, c2) & _is_bear(o3, c3) & (c2 < c1) & (c3 < c2)
    bear_strike = _is_bull(o, c) & (o < c3) & (c > o1)
    return (bull_3 & bull_strike).astype(int) - (bear_3 & bear_strike).astype(int)

def cdl_abandoned_baby(o, h, l, c):
    """Abandoned Baby. +1=bullish, -1=bearish."""
    o1, h1, l1, c1 = o.shift(2), h.shift(2), l.shift(2), c.shift(2)
    o2, h2, l2, c2 = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    doji2 = _is_doji(o2, h2, l2, c2, 0.05)
    bull = _is_bear(o1, c1) & doji2 & (h2 < l1) & _is_bull(o, c) & (l > h2)
    bear = _is_bull(o1, c1) & doji2 & (l2 > h1) & _is_bear(o, c) & (h < l2)
    return bull.astype(int) - bear.astype(int)

def cdl_tristar(o, h, l, c):
    """Tristar — three dojis. +1=bullish, -1=bearish."""
    d1 = _is_doji(o.shift(2), h.shift(2), l.shift(2), c.shift(2), 0.05)
    d2 = _is_doji(o.shift(1), h.shift(1), l.shift(1), c.shift(1), 0.05)
    d3 = _is_doji(o, h, l, c, 0.05)
    m1 = (h.shift(2) + l.shift(2)) / 2
    m2 = (h.shift(1) + l.shift(1)) / 2
    m3 = (h + l) / 2
    bull = d1 & d2 & d3 & (m2 < m1) & (m3 > m2)
    bear = d1 & d2 & d3 & (m2 > m1) & (m3 < m2)
    return bull.astype(int) - bear.astype(int)

def cdl_identical_three_crows(o, h, l, c):
    """Identical Three Crows — three bears, each opens at previous close."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    all_bear = _is_bear(o1, c1) & _is_bear(o2, c2) & _is_bear(o, c)
    descending = (c < c2) & (c2 < c1)
    opens_at_close = ((o2 - c1).abs() < _range(h, l) * 0.03) & \
                     ((o - c2).abs() < _range(h, l) * 0.03)
    return (all_bear & descending & opens_at_close).astype(int)

def cdl_advance_block(o, h, l, c):
    """Advance Block (bearish) — three bulls with diminishing bodies."""
    o1, h1, l1, c1 = o.shift(2), h.shift(2), l.shift(2), c.shift(2)
    o2, h2, l2, c2 = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    all_bull = _is_bull(o1, c1) & _is_bull(o2, c2) & _is_bull(o, c)
    ascending = (c > c2) & (c2 > c1)
    diminishing = (_body(o, c) < _body(o2, c2)) & (_body(o2, c2) < _body(o1, c1))
    return (all_bull & ascending & diminishing).astype(int)

def cdl_stalled_pattern(o, h, l, c):
    """Stalled Pattern (bearish) — three bulls, third has small body."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    all_bull = _is_bull(o1, c1) & _is_bull(o2, c2) & _is_bull(o, c)
    big_first = _body(o1, c1) > _body(o2, c2)
    small_third = _body(o, c) < _body(o2, c2) * 0.5
    return (all_bull & big_first & small_third).astype(int)

def cdl_stick_sandwich(o, h, l, c):
    """Stick Sandwich (bullish) — bear, bull, bear with same close as first."""
    c1 = c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    bear1 = _is_bear(o.shift(2), c1)
    bull2 = _is_bull(o2, c2)
    bear3 = _is_bear(o, c)
    same_close = (c - c1).abs() < _range(h, l) * 0.03
    return (bear1 & bull2 & bear3 & same_close).astype(int)

def cdl_unique_three_river(o, h, l, c):
    """Unique 3 River (bullish)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2, l2 = o.shift(1), c.shift(1), l.shift(1)
    first_bear = _is_bear(o1, c1) & (_body_pct(o1, h.shift(2), l.shift(2), c1) > 0.5)
    second_bear_hammer = _is_bear(o2, c2) & (c2 > c1) & (l2 < l.shift(2))
    third_small_bull = _is_bull(o, c) & (_body(o, c) < _body(o2, c2))
    return (first_bear & second_bear_hammer & third_small_bull).astype(int)

def cdl_three_stars_in_south(o, h, l, c):
    """Three Stars In The South (bullish)."""
    o1, h1, l1, c1 = o.shift(2), h.shift(2), l.shift(2), c.shift(2)
    o2, h2, l2, c2 = o.shift(1), h.shift(1), l.shift(1), c.shift(1)
    all_bear = _is_bear(o1, c1) & _is_bear(o2, c2) & _is_bear(o, c)
    diminishing = (_body(o, c) < _body(o2, c2)) & (_body(o2, c2) < _body(o1, c1))
    higher_lows = (l > l2) & (l2 > l1)
    return (all_bear & diminishing & higher_lows).astype(int)

def cdl_breakaway(o, h, l, c):
    """Breakaway (5 candle). +1=bullish, -1=bearish."""
    c4, c3, c2, c1 = c.shift(4), c.shift(3), c.shift(2), c.shift(1)
    o4 = o.shift(4)
    # Bullish: starts with big bear, ends with bull closing in gap
    bull = _is_bear(o4, c4) & (c3 < c4) & (c2 < c3) & (c1 < c2) & _is_bull(o, c) & (c > c3) & (c < c4)
    bear = _is_bull(o4, c4) & (c3 > c4) & (c2 > c3) & (c1 > c2) & _is_bear(o, c) & (c < c3) & (c > c4)
    return bull.astype(int) - bear.astype(int)

def cdl_ladder_bottom(o, h, l, c):
    """Ladder Bottom (bullish)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    three_bear = _is_bear(o.shift(4), c.shift(4)) & _is_bear(o.shift(3), c.shift(3)) & _is_bear(o1, c1)
    fourth_bear_with_upper = _is_bear(o2, c2) & (_upper_shadow(o2, h.shift(1), c2) > _body(o2, c2))
    fifth_bull = _is_bull(o, c) & (o > o2)
    return (three_bear & fourth_bear_with_upper & fifth_bull).astype(int)

def cdl_hikkake(o, h, l, c):
    """Hikkake Pattern — inside bar breakout failure."""
    # Day 1-2: inside bar (day 2 inside day 1)
    inside = (h.shift(1) < h.shift(2)) & (l.shift(1) > l.shift(2))
    # Day 3: breaks outside
    break_up = (h > h.shift(1)) & inside
    break_down = (l < l.shift(1)) & inside
    return (break_up).astype(int) - (break_down).astype(int)

def cdl_gap_side_side_white(o, h, l, c):
    """Up/Down Gap Side-by-Side White Lines."""
    o1, c1 = o.shift(1), c.shift(1)
    o2, c2 = o.shift(2), c.shift(2)
    both_bull = _is_bull(o, c) & _is_bull(o1, c1)
    same_size = (_body(o, c) - _body(o1, c1)).abs() < _body(o, c) * 0.3
    gap_above = (pd.concat([o, o1], axis=1).min(axis=1) > c2) & _is_bull(o2, c2)
    return (both_bull & same_size & gap_above).astype(int)

def cdl_tasuki_gap(o, h, l, c):
    """Tasuki Gap. +1=bullish, -1=bearish."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    bull_gap = _is_bull(o1, c1) & _is_bull(o2, c2) & (o2 > c1)
    bear_fill = _is_bear(o, c) & (o > o2) & (o < c2) & (c < o2) & (c > c1)
    bear_gap = _is_bear(o1, c1) & _is_bear(o2, c2) & (o2 < c1)
    bull_fill = _is_bull(o, c) & (o < o2) & (o > c2) & (c > o2) & (c < c1)
    return (bull_gap & bear_fill).astype(int) - (bear_gap & bull_fill).astype(int)

def cdl_mat_hold(o, h, l, c):
    """Mat Hold (bullish continuation, 5 candle)."""
    o4, c4 = o.shift(4), c.shift(4)
    c3, c2, c1 = c.shift(3), c.shift(2), c.shift(1)
    first_big_bull = _is_bull(o4, c4) & (_body_pct(o4, h.shift(4), l.shift(4), c4) > 0.5)
    small_pullback = (c3 < c4) & (c2 < c4) & (c1 < c4) & (c1 > o4)
    last_bull = _is_bull(o, c) & (c > c4)
    return (first_big_bull & small_pullback & last_bull).astype(int)

def cdl_rise_fall_three_methods(o, h, l, c):
    """Rising/Falling Three Methods. +1=rising, -1=falling."""
    o4, h4, l4, c4 = o.shift(4), h.shift(4), l.shift(4), c.shift(4)
    h3, l3, h2, l2, h1, l1 = h.shift(3), l.shift(3), h.shift(2), l.shift(2), h.shift(1), l.shift(1)
    first_big_bull = _is_bull(o4, c4) & (_body_pct(o4, h4, l4, c4) > 0.6)
    three_small = (h3 < h4) & (l3 > l4) & (h2 < h4) & (l2 > l4) & (h1 < h4) & (l1 > l4)
    last_big_bull = _is_bull(o, c) & (c > c4)
    rising = first_big_bull & three_small & last_big_bull

    first_big_bear = _is_bear(o4, c4) & (_body_pct(o4, h4, l4, c4) > 0.6)
    last_big_bear = _is_bear(o, c) & (c < c4)
    falling = first_big_bear & three_small & last_big_bear

    return rising.astype(int) - falling.astype(int)

def cdl_upside_gap_two_crows(o, h, l, c):
    """Upside Gap Two Crows (bearish)."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    first_bull = _is_bull(o1, c1) & (_body_pct(o1, h.shift(2), l.shift(2), c1) > 0.5)
    second_bear_gap = _is_bear(o2, c2) & (c2 > c1)
    third_bear_engulf = _is_bear(o, c) & (o > o2) & (c < c2) & (c > c1)
    return (first_bull & second_bear_gap & third_bear_engulf).astype(int)

def cdl_concealing_baby_swallow(o, h, l, c):
    """Concealing Baby Swallow (bullish, rare)."""
    o3, c3 = o.shift(3), c.shift(3)
    o2, c2 = o.shift(2), c.shift(2)
    o1, h1, c1 = o.shift(1), h.shift(1), c.shift(1)
    all_bear = _is_bear(o3, c3) & _is_bear(o2, c2) & _is_bear(o1, c1) & _is_bear(o, c)
    first_two_maru = (_body_pct(o3, h.shift(3), l.shift(3), c3) > 0.9) & \
                     (_body_pct(o2, h.shift(2), l.shift(2), c2) > 0.9)
    third_gap = (o1 < c2)
    fourth_engulf = (o > h1) & (c < c1)
    return (all_bear & first_two_maru & third_gap & fourth_engulf).astype(int)

def cdl_x_side_gap_three_methods(o, h, l, c):
    """Upside/Downside Gap Three Methods."""
    o1, c1 = o.shift(2), c.shift(2)
    o2, c2 = o.shift(1), c.shift(1)
    # Upside gap 3 methods (bearish)
    both_bull = _is_bull(o1, c1) & _is_bull(o2, c2)
    gap_up = o2 > c1
    bear_fill = _is_bear(o, c) & (o > o2) & (c < c1)
    upside = both_bull & gap_up & bear_fill

    both_bear = _is_bear(o1, c1) & _is_bear(o2, c2)
    gap_down = o2 < c1
    bull_fill = _is_bull(o, c) & (o < o2) & (c > c1)
    downside = both_bear & gap_down & bull_fill
    return upside.astype(int) - downside.astype(int)


# ═══════════════════════════════════════════════════════════════
# MASTER FUNCTION — Generate all 61 patterns at once
# ═══════════════════════════════════════════════════════════════

ALL_PATTERNS = {
    'cdl_doji': cdl_doji,
    'cdl_dragonfly_doji': cdl_dragonfly_doji,
    'cdl_gravestone_doji': cdl_gravestone_doji,
    'cdl_long_legged_doji': cdl_long_legged_doji,
    'cdl_rickshaw_man': cdl_rickshaw_man,
    'cdl_marubozu': cdl_marubozu,
    'cdl_closing_marubozu': cdl_closing_marubozu,
    'cdl_spinning_top': cdl_spinning_top,
    'cdl_high_wave': cdl_high_wave,
    'cdl_hammer': cdl_hammer,
    'cdl_hanging_man': cdl_hanging_man,
    'cdl_inverted_hammer': cdl_inverted_hammer,
    'cdl_shooting_star': cdl_shooting_star,
    'cdl_belt_hold': cdl_belt_hold,
    'cdl_long_line': cdl_long_line,
    'cdl_short_line': cdl_short_line,
    'cdl_takuri': cdl_takuri,
    'cdl_engulfing': cdl_engulfing,
    'cdl_harami': cdl_harami,
    'cdl_harami_cross': cdl_harami_cross,
    'cdl_piercing': cdl_piercing,
    'cdl_dark_cloud_cover': cdl_dark_cloud_cover,
    'cdl_doji_star': cdl_doji_star,
    'cdl_counterattack': cdl_counterattack,
    'cdl_inn_neck': cdl_inn_neck,
    'cdl_on_neck': cdl_on_neck,
    'cdl_thrusting': cdl_thrusting,
    'cdl_separating_lines': cdl_separating_lines,
    'cdl_matching_low': cdl_matching_low,
    'cdl_homing_pigeon': cdl_homing_pigeon,
    'cdl_kicking': cdl_kicking,
    'cdl_two_crows': cdl_two_crows,
    'cdl_morning_star': cdl_morning_star,
    'cdl_evening_star': cdl_evening_star,
    'cdl_morning_doji_star': cdl_morning_doji_star,
    'cdl_evening_doji_star': cdl_evening_doji_star,
    'cdl_three_white_soldiers': cdl_three_white_soldiers,
    'cdl_three_black_crows': cdl_three_black_crows,
    'cdl_three_inside': cdl_three_inside,
    'cdl_three_outside': cdl_three_outside,
    'cdl_three_line_strike': cdl_three_line_strike,
    'cdl_abandoned_baby': cdl_abandoned_baby,
    'cdl_tristar': cdl_tristar,
    'cdl_identical_three_crows': cdl_identical_three_crows,
    'cdl_advance_block': cdl_advance_block,
    'cdl_stalled_pattern': cdl_stalled_pattern,
    'cdl_stick_sandwich': cdl_stick_sandwich,
    'cdl_unique_three_river': cdl_unique_three_river,
    'cdl_three_stars_in_south': cdl_three_stars_in_south,
    'cdl_breakaway': cdl_breakaway,
    'cdl_ladder_bottom': cdl_ladder_bottom,
    'cdl_hikkake': cdl_hikkake,
    'cdl_gap_side_side_white': cdl_gap_side_side_white,
    'cdl_tasuki_gap': cdl_tasuki_gap,
    'cdl_mat_hold': cdl_mat_hold,
    'cdl_rise_fall_three_methods': cdl_rise_fall_three_methods,
    'cdl_upside_gap_two_crows': cdl_upside_gap_two_crows,
    'cdl_concealing_baby_swallow': cdl_concealing_baby_swallow,
    'cdl_x_side_gap_three_methods': cdl_x_side_gap_three_methods,
}


def generate_all_candlestick(open_: pd.Series, high: pd.Series,
                             low: pd.Series, close: pd.Series) -> pd.DataFrame:
    """Generate all candlestick pattern columns at once.

    Returns DataFrame with one column per pattern.
    """
    result = {}
    for name, func in ALL_PATTERNS.items():
        try:
            result[name] = func(open_, high, low, close)
        except Exception:
            result[name] = pd.Series(0, index=close.index)
    return pd.DataFrame(result, index=close.index)
