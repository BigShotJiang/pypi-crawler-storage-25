"""
ta-saham: Technical Analysis untuk Saham Indonesia
Pure Python/Pandas — zero C dependencies
"""

from ta_saham.pipeline import generate_features

__version__ = "1.0.0"
__all__ = ["generate_features"]
