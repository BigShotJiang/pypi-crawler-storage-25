"""
Main Pipeline — the single function that generates ALL features.

Usage:
    from ta_saham import generate_features
    df = generate_features(df_raw)
"""

import numpy as np
import pandas as pd

from ta_saham.indicators import momentum as mom
from ta_saham.indicators import overlap as ovl
from ta_saham.indicators import volume as vol
from ta_saham.indicators import volatility as vlt
from ta_saham.indicators.candlestick import generate_all_candlestick

from ta_saham.features.price_action import add_price_action_features
from ta_saham.features.custom import add_custom_features
from ta_saham.features.macro import add_macro_features
from ta_saham.features.cross_sectional import add_cross_sectional_features
from ta_saham.features.sliding_window import (
    add_sliding_window_features,
    add_momentum_features,
)


def generate_features(
    df_raw: pd.DataFrame,
    symbol_col: str = 'symbol',
    date_col: str = 'date',
    open_col: str = 'open',
    high_col: str = 'high',
    low_col: str = 'low',
    close_col: str = 'close',
    volume_col: str = 'volume',
    sector_col: str = 'sector',
    include_candlestick: bool = True,
    include_sliding_window: bool = True,
    include_cross_sectional: bool = True,
    sliding_lookbacks: list = None,
    sliding_max_lag: int = 5,
    sliding_key_features: list = None,
    drop_na: bool = True,
    verbose: bool = True,
) -> pd.DataFrame:
    """Generate all technical analysis features from raw OHLCV data.

    Args:
        df_raw: DataFrame with at minimum columns:
                [symbol, date, open, high, low, close, volume]
                Optional: [sector, industry, market_cap, macro_*]
        symbol_col: column name for stock symbol
        date_col: column name for date
        open_col, high_col, low_col, close_col, volume_col: OHLCV column names
        sector_col: column name for sector (for cross-sectional features)
        include_candlestick: whether to generate 61 candlestick pattern features
        include_sliding_window: whether to generate lag/rolling features
        include_cross_sectional: whether to generate rank/alpha features
        sliding_lookbacks: rolling window sizes (default [3, 5, 10])
        sliding_max_lag: max lag depth (default 5)
        sliding_key_features: which features to create lags for (None=default 20)
        drop_na: whether to drop NaN rows at the end
        verbose: print progress

    Returns:
        DataFrame with all features added.
    """
    if sliding_lookbacks is None:
        sliding_lookbacks = [3, 5, 10]

    df = df_raw.copy().sort_values([symbol_col, date_col])
    g = df.groupby(symbol_col)

    o = df[open_col]
    h = df[high_col]
    l = df[low_col]
    c = df[close_col]
    v = df[volume_col]

    initial_cols = len(df.columns)

    # ═══════════════════════════════════════════════════════════
    # LAYER 1: Technical Indicators (~80 features)
    # ═══════════════════════════════════════════════════════════
    if verbose:
        print("🔧 Layer 1: Technical Indicators...")

    # Daily return (needed by many features)
    df['daily_ret'] = g[close_col].pct_change()

    # --- Momentum indicators ---
    for period in [7, 14]:
        df[f'rsi_{period}'] = g[close_col].transform(lambda x: mom.rsi(x, period))

    _, _, macd_hist = mom.macd(c)  # Will be regrouped
    df['macd_hist'] = g[close_col].transform(lambda x: mom.macd(x)[2])

    df['mfi_14'] = g.apply(
        lambda x: mom.mfi(x[high_col], x[low_col], x[close_col], x[volume_col])
    ).droplevel(0)

    df['cci_20'] = g.apply(
        lambda x: mom.cci(x[high_col], x[low_col], x[close_col])
    ).droplevel(0)

    stoch_k, stoch_d = pd.Series(dtype=float), pd.Series(dtype=float)
    df['stoch_k'] = g.apply(
        lambda x: mom.stochastic(x[high_col], x[low_col], x[close_col])[0]
    ).droplevel(0)
    df['stoch_d'] = g.apply(
        lambda x: mom.stochastic(x[high_col], x[low_col], x[close_col])[1]
    ).droplevel(0)

    df['adx_14'] = g.apply(
        lambda x: mom.adx(x[high_col], x[low_col], x[close_col])
    ).droplevel(0)

    adx_comps = g.apply(
        lambda x: pd.DataFrame({
            'plus_di': mom.adx_components(x[high_col], x[low_col], x[close_col])[1],
            'minus_di': mom.adx_components(x[high_col], x[low_col], x[close_col])[2],
        })
    ).droplevel(0)
    df['plus_di'] = adx_comps['plus_di']
    df['minus_di'] = adx_comps['minus_di']

    aroon_vals = g.apply(
        lambda x: pd.DataFrame({
            'aroon_up': mom.aroon(x[high_col], x[low_col])[0],
            'aroon_down': mom.aroon(x[high_col], x[low_col])[1],
            'aroon_osc': mom.aroon(x[high_col], x[low_col])[2],
        })
    ).droplevel(0)
    df['aroon_up'] = aroon_vals['aroon_up']
    df['aroon_down'] = aroon_vals['aroon_down']
    df['aroon_osc'] = aroon_vals['aroon_osc']

    df['williams_r_14'] = g.apply(
        lambda x: mom.williams_r(x[high_col], x[low_col], x[close_col])
    ).droplevel(0)

    df['ultosc'] = g.apply(
        lambda x: mom.ultimate_oscillator(x[high_col], x[low_col], x[close_col])
    ).droplevel(0)

    df['stochrsi'] = g[close_col].transform(lambda x: mom.stochrsi(x))
    df['trix_15'] = g[close_col].transform(lambda x: mom.trix(x))
    df['ppo'] = g[close_col].transform(lambda x: mom.ppo(x))
    df['cmo_14'] = g[close_col].transform(lambda x: mom.cmo(x))

    df['bop'] = mom.bop(o, h, l, c)

    for period in [5, 10, 20]:
        df[f'roc_{period}'] = g[close_col].transform(lambda x: mom.roc(x, period))

    df['awesome_osc'] = g.apply(
        lambda x: mom.awesome_oscillator(x[high_col], x[low_col])
    ).droplevel(0)

    df['fisher'] = g.apply(
        lambda x: mom.fisher_transform(x[high_col], x[low_col])
    ).droplevel(0)

    # --- Overlap indicators ---
    for w in [20, 50, 200]:
        ma = g[close_col].transform(lambda x: ovl.sma(x, w))
        df[f'dist_ma_{w}'] = (c - ma) / (ma + 1e-10)
        if w == 200:
            df['ma_200'] = ma

    df['kama_10'] = g[close_col].transform(lambda x: ovl.kama(x))
    df['dist_kama'] = (c - df['kama_10']) / (df['kama_10'] + 1e-10)

    bb_results = g.apply(
        lambda x: pd.DataFrame({
            'bb_upper': ovl.bollinger_bands(x[close_col])[0],
            'bb_lower': ovl.bollinger_bands(x[close_col])[2],
            'bb_width': ovl.bollinger_bands(x[close_col])[3],
            'bb_pct_b': ovl.bollinger_bands(x[close_col])[4],
        })
    ).droplevel(0)
    for col in bb_results.columns:
        df[col] = bb_results[col]

    df['sar'] = g.apply(
        lambda x: ovl.parabolic_sar(x[high_col], x[low_col])
    ).droplevel(0)
    df['dist_sar'] = (c - df['sar']) / (c + 1e-10)

    # Supertrend
    st_results = g.apply(
        lambda x: pd.DataFrame({
            'supertrend': ovl.supertrend(x[high_col], x[low_col], x[close_col])[0],
            'supertrend_dir': ovl.supertrend(x[high_col], x[low_col], x[close_col])[1],
        })
    ).droplevel(0)
    df['supertrend'] = st_results['supertrend']
    df['supertrend_dir'] = st_results['supertrend_dir']
    df['dist_supertrend'] = (c - df['supertrend']) / (c + 1e-10)

    # Keltner & Squeeze
    df['squeeze_on'] = g.apply(
        lambda x: ovl.squeeze(x[high_col], x[low_col], x[close_col])
    ).droplevel(0)

    # --- Volume indicators ---
    df['chaikin_osc'] = g.apply(
        lambda x: vol.chaikin_oscillator(x[high_col], x[low_col], x[close_col], x[volume_col])
    ).droplevel(0)

    df['eom_14'] = g.apply(
        lambda x: vol.ease_of_movement(x[high_col], x[low_col], x[volume_col])
    ).droplevel(0)

    # --- Volatility indicators ---
    df['tr_daily'] = df.groupby(symbol_col).apply(
        lambda x: pd.Series(
            (x[high_col] - x[low_col]).values,
            index=x.index
        )
    ).droplevel(0)
    df['atr_14'] = g['tr_daily'].transform(lambda x: x.ewm(alpha=1/14, adjust=False).mean())
    df['atr_pct'] = df['atr_14'] / (c + 1e-10)
    df['atr_pct_chg'] = g['atr_pct'].pct_change(3)
    df['natr_14'] = df['atr_pct'] * 100

    for w in [5, 10, 20]:
        df[f'hv_{w}d'] = g['daily_ret'].transform(
            lambda x: x.rolling(w).std() * np.sqrt(252)
        )

    if 'hv_5d' in df.columns and 'hv_20d' in df.columns:
        df['hv_ratio_5_20'] = df['hv_5d'] / (df['hv_20d'] + 1e-10)

    df['linreg_slope_14'] = g[close_col].transform(lambda x: vlt.linear_regression_slope(x, 14))
    df['linreg_angle_14'] = g[close_col].transform(lambda x: vlt.linear_regression_angle(x, 14))
    df['price_zscore_20'] = g[close_col].transform(lambda x: vlt.zscore(x, 20))
    df['ret_skew_20'] = g[close_col].transform(lambda x: vlt.skewness(x, 20))
    df['ret_kurt_20'] = g[close_col].transform(lambda x: vlt.kurtosis(x, 20))

    # --- Time features ---
    if date_col in df.columns:
        dt = pd.to_datetime(df[date_col])
        df['day_of_week'] = dt.dt.dayofweek
        df['is_month_end'] = dt.dt.is_month_end.astype(int)
        df['quarter'] = dt.dt.quarter

    if verbose:
        print(f"   ✅ Technical Indicators: +{len(df.columns) - initial_cols} fitur")

    # ═══════════════════════════════════════════════════════════
    # LAYER 2: Price Action & Custom Features
    # ═══════════════════════════════════════════════════════════
    if verbose:
        print("🕯️  Layer 2: Price Action & Custom Features...")

    layer2_start = len(df.columns)
    df = add_price_action_features(df, g, open_col, high_col, low_col, close_col)

    if verbose:
        print(f"   ✅ Price Action: +{len(df.columns) - layer2_start} fitur")

    # ═══════════════════════════════════════════════════════════
    # LAYER 3: Candlestick Patterns (61 patterns)
    # ═══════════════════════════════════════════════════════════
    if include_candlestick:
        if verbose:
            print("🕯️  Layer 3: Candlestick Patterns (61 pola)...")

        cdl_df = generate_all_candlestick(o, h, l, c)
        for col in cdl_df.columns:
            df[col] = cdl_df[col].values

        if verbose:
            print(f"   ✅ Candlestick: +{len(cdl_df.columns)} fitur")

    # ═══════════════════════════════════════════════════════════
    # LAYER 4: Macro Features
    # ═══════════════════════════════════════════════════════════
    macro_cols = [c for c in df.columns if 'macro_' in c and '_chg' not in c]
    if len(macro_cols) > 0:
        if verbose:
            print("🌍 Layer 4: Macro Features...")
        layer4_start = len(df.columns)
        df = add_macro_features(df, g)
        if verbose:
            print(f"   ✅ Macro: +{len(df.columns) - layer4_start} fitur")

    # ═══════════════════════════════════════════════════════════
    # LAYER 5: Cross-Sectional Features (rank, alpha)
    # ═══════════════════════════════════════════════════════════
    if include_cross_sectional:
        if verbose:
            print("📊 Layer 5: Cross-Sectional Features...")
        layer5_start = len(df.columns)
        df = add_cross_sectional_features(df, date_col, sector_col)
        if verbose:
            print(f"   ✅ Cross-Sectional: +{len(df.columns) - layer5_start} fitur")

    # ═══════════════════════════════════════════════════════════
    # LAYER 6: Momentum Features
    # ═══════════════════════════════════════════════════════════
    if verbose:
        print("🚀 Layer 6: Momentum Features...")
    layer6_start = len(df.columns)
    g = df.groupby(symbol_col)  # Re-create after modifications
    df = add_momentum_features(df, g, close_col)
    if verbose:
        print(f"   ✅ Momentum: +{len(df.columns) - layer6_start} fitur")

    # ═══════════════════════════════════════════════════════════
    # LAYER 7: Sliding Window Features (lag, rolling, delta)
    # ═══════════════════════════════════════════════════════════
    if include_sliding_window:
        if verbose:
            print("⏳ Layer 7: Sliding Window Features (this takes a moment)...")
        layer7_start = len(df.columns)
        g = df.groupby(symbol_col)  # Re-create after modifications
        df = add_sliding_window_features(
            df, g,
            key_features=sliding_key_features,
            max_lag=sliding_max_lag,
            lookbacks=sliding_lookbacks,
        )
        if verbose:
            print(f"   ✅ Sliding Window: +{len(df.columns) - layer7_start} fitur")

    # ═══════════════════════════════════════════════════════════
    # FINALIZE
    # ═══════════════════════════════════════════════════════════
    if drop_na:
        df.dropna(inplace=True)

    total_features = len(df.columns) - initial_cols
    if verbose:
        print(f"\n🎉 SELESAI! Total: {len(df.columns)} kolom ({total_features} fitur baru)")
        print(f"   Data: {len(df):,} baris × {len(df.columns)} kolom")

    return df
