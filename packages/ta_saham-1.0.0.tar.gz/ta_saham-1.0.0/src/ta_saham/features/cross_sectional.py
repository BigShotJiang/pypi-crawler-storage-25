"""
Cross-Sectional Features — rank, alpha, relative strength vs market & sector.
"""

import numpy as np
import pandas as pd


def add_cross_sectional_features(df, date_col='date', sector_col='sector'):
    """Add cross-sectional (across stocks on same date) features."""

    # Market context
    if 'daily_ret' in df.columns:
        market_ret = df.groupby(date_col)['daily_ret'].transform('mean')
        df['alpha_market'] = df['daily_ret'] - market_ret

        if sector_col in df.columns:
            sector_ret = df.groupby([date_col, sector_col])['daily_ret'].transform('mean')
            df['alpha_sector'] = df['daily_ret'] - sector_ret

            # Sector momentum
            df['sector_daily_ret'] = sector_ret
            g = df.groupby('symbol') if 'symbol' in df.columns else df.groupby(level=0)
            for w in [3, 5, 20]:
                df[f'sector_mom_{w}'] = g['sector_daily_ret'].transform(lambda x: x.rolling(w).mean())

    # Cross-sectional ranks
    rank_features = [
        'rsi_14', 'mfi_14', 'vol_spike_ratio', 'vol_z_score', 'alpha_sector',
        'alpha_market', 'turnover_ratio', 'buying_pressure', 'dist_ma_20',
        'bb_pct_b', 'stoch_k', 'force_index_2', 'sector_mom_3',
        'adx_14', 'aroon_osc', 'williams_r_14', 'cmf_20',
    ]

    for col in rank_features:
        if col in df.columns:
            df[f'{col}_rank'] = df.groupby(date_col)[col].rank(pct=True)

    # Amihud rank
    if 'amihud' in df.columns:
        df['amihud_rank'] = df.groupby(date_col)['amihud'].rank(pct=True)

    # Volatility rank
    if 'hv_10d' in df.columns:
        df['hv_10d_rank'] = df.groupby(date_col)['hv_10d'].rank(pct=True)

    return df
