"""
Macro Features — transform macro indicators into returns and regime features.
"""

import numpy as np
import pandas as pd


def add_macro_features(df, g):
    """Add macro-derived features."""
    macro_cols = [c for c in df.columns if 'macro_' in c and '_chg' not in c and '_ret' not in c]

    for mac in macro_cols:
        # Return 1d and 5d
        df[f'{mac}_chg1d'] = g[mac].pct_change(1)
        df[f'{mac}_chg5d'] = g[mac].pct_change(5)

    # Macro alpha (if EIDO and USDIDR are available)
    if 'macro_eido_chg1d' in df.columns and 'daily_ret' in df.columns:
        df['alpha_vs_eido'] = df['daily_ret'] - df['macro_eido_chg1d']

    if 'macro_usdidr_chg1d' in df.columns and 'daily_ret' in df.columns:
        df['alpha_vs_usdidr'] = df['daily_ret'] - df['macro_usdidr_chg1d']

    return df
