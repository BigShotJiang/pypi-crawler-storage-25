"""
Sliding Window Features — lag, rolling statistics, delta, acceleration.
This is the "feature multiplier" that turns N base features into 10N+ features.
"""

import numpy as np
import pandas as pd


DEFAULT_KEY_FEATURES = [
    'rsi_14', 'mfi_14', 'stoch_k', 'macd_hist', 'bb_pct_b',
    'daily_ret', 'alpha_sector', 'alpha_market',
    'vol_spike_ratio', 'vol_z_score', 'buying_pressure',
    'turnover_ratio', 'atr_pct', 'dist_ma_20',
    'force_index_2', 'close_at_high', 'volume',
    'cmf_20', 'adx_14', 'body_pct',
]

EXTRA_ROLLING_FEATURES = [
    'rsi_14', 'vol_spike_ratio', 'alpha_sector', 'daily_ret',
    'close', 'volume', 'turnover_ratio',
]


def add_sliding_window_features(df, g, key_features=None,
                                max_lag=5, lookbacks=None):
    """Add sliding window features to DataFrame.

    For each key feature, generates:
    - Lag 1-5 (configurable)
    - Rolling mean at multiple windows
    - Rolling std at multiple windows
    - Rolling min/max for select features
    - Delta (change from lag) and acceleration

    Args:
        df: DataFrame
        g: GroupBy object (by symbol)
        key_features: list of column names to create lag/rolling features for
        max_lag: maximum lag depth (default 5)
        lookbacks: windows for rolling stats (default [3, 5, 10])
    """
    if key_features is None:
        key_features = DEFAULT_KEY_FEATURES
    if lookbacks is None:
        lookbacks = [3, 5, 10]

    available_feats = [f for f in key_features if f in df.columns]

    for feat in available_feats:
        # 1. Lags
        for i in range(1, max_lag + 1):
            df[f'{feat}_lag{i}'] = g[feat].shift(i)

        # 2. Rolling statistics (multi-window)
        for lb in lookbacks:
            df[f'{feat}_mean_{lb}d'] = g[feat].transform(lambda x: x.rolling(lb).mean())
            df[f'{feat}_std_{lb}d'] = g[feat].transform(lambda x: x.rolling(lb).std(ddof=0))

            # Min/Max for select features
            if feat in EXTRA_ROLLING_FEATURES:
                df[f'{feat}_max_{lb}d'] = g[feat].transform(lambda x: x.rolling(lb).max())
                df[f'{feat}_min_{lb}d'] = g[feat].transform(lambda x: x.rolling(lb).min())

        # 3. Delta (today vs lag1)
        if f'{feat}_lag1' in df.columns:
            df[f'{feat}_delta1'] = df[feat] - df[f'{feat}_lag1']

        # 4. Acceleration (delta of delta — measures if momentum is increasing)
        if f'{feat}_lag3' in df.columns:
            delta_vals = g[f'{feat}_delta1'].transform(
                lambda x: x.shift(2).rolling(window=2, min_periods=1).mean()
            ) if f'{feat}_delta1' in df.columns else 0
            df[f'{feat}_accel3'] = df.get(f'{feat}_delta1', 0) - delta_vals

    # ── Special derived features ──

    # Breakout flags
    if 'rsi_14' in df.columns and 'rsi_14_mean_5d' in df.columns:
        df['rsi_breakout_5d'] = (df['rsi_14'] > df['rsi_14_mean_5d']).astype(int)
        df['rsi_trend_5d'] = df['rsi_14'] - df['rsi_14_mean_5d']

    if 'volume' in df.columns and 'volume_max_5d' in df.columns:
        df['vol_breakout_5d'] = (df['volume'] >= df['volume_max_5d']).astype(int)

    if 'alpha_sector' in df.columns and 'alpha_sector_mean_5d' in df.columns:
        df['alpha_sector_breakout'] = (df['alpha_sector'] > df['alpha_sector_mean_5d']).astype(int)

    if 'vol_spike_ratio' in df.columns and 'vol_spike_ratio_mean_5d' in df.columns:
        df['vol_trend_5d'] = df['vol_spike_ratio'] - df['vol_spike_ratio_mean_5d']

    # Macro lag
    if 'macro_eido' in df.columns:
        df['macro_eido_lag1'] = g['macro_eido'].shift(1)
        df['macro_eido_chg1d_derived'] = df['macro_eido'] - df['macro_eido_lag1']

    return df


def add_momentum_features(df, g, close_col='close'):
    """Add comprehensive momentum features.

    Returns & rate of change at multiple horizons, streak, position, acceleration.
    """
    c = df[close_col]

    # Multi-horizon returns
    for w in [1, 2, 3, 5, 10, 20, 60]:
        df[f'ret_{w}d'] = g[close_col].pct_change(w)

    # Return magnitude
    for w in [1, 5]:
        if f'ret_{w}d' in df.columns:
            df[f'ret_{w}d_abs'] = df[f'ret_{w}d'].abs()

    # Return cumulative sums
    if 'daily_ret' in df.columns:
        for w in [3, 5, 10]:
            df[f'ret_cum_{w}d'] = g['daily_ret'].transform(lambda x: x.rolling(w).sum())

    # Acceleration
    if 'ret_1d' in df.columns:
        df['acceleration_1d'] = df['ret_1d'] - g['ret_1d'].shift(1)
        if 'ret_5d' in df.columns:
            df['ret_today_vs_5d'] = df['ret_1d'] / (df['ret_5d'] + 1e-10)

    # Momentum acceleration 3d
    if 'daily_ret' in df.columns:
        df['mom_accel_3d'] = df['daily_ret'] - g['daily_ret'].transform(
            lambda x: x.shift(3).rolling(window=3, min_periods=1).mean()
        )
        df['price_accel_1d'] = df['daily_ret'] - g['daily_ret'].shift(1)

    # Streak (consecutive up/down days)
    if 'daily_ret' in df.columns:
        up = (df['daily_ret'] > 0).astype(int)
        down = (df['daily_ret'] < 0).astype(int)

        def _streak(s):
            """Count consecutive 1s (resets on 0)."""
            result = s.copy()
            for i in range(1, len(s)):
                if s.iloc[i] == 1:
                    result.iloc[i] = result.iloc[i-1] + 1
                else:
                    result.iloc[i] = 0
            return result

        df['streak_up'] = g.apply(lambda x: _streak(up.loc[x.index])).droplevel(0)
        df['streak_down'] = g.apply(lambda x: _streak(down.loc[x.index])).droplevel(0)

        # Count up days in last 5
        df['count_up_5d'] = g.apply(
            lambda x: up.loc[x.index].rolling(5).sum()
        ).droplevel(0)

    # Max/Min return in last N days
    if 'daily_ret' in df.columns:
        for w in [5, 20]:
            df[f'max_ret_{w}d'] = g['daily_ret'].transform(lambda x: x.rolling(w).max())
            df[f'min_ret_{w}d'] = g['daily_ret'].transform(lambda x: x.rolling(w).min())

    # Distance from N-day high/low
    for w in [5, 20, 60]:
        high_n = g[close_col].transform(lambda x: x.rolling(w).max())
        low_n = g[close_col].transform(lambda x: x.rolling(w).min())
        df[f'dist_high_{w}d'] = (c - high_n) / (high_n + 1e-10)
        df[f'dist_low_{w}d'] = (c - low_n) / (low_n + 1e-10)

    # Percentile rank of today's return
    if 'daily_ret' in df.columns:
        for w in [20, 60]:
            df[f'ret_pctrank_{w}d'] = g['daily_ret'].transform(
                lambda x: x.rolling(w).rank(pct=True)
            )

    return df
