"""
Custom Features — liquidity, interaction features, Amihud, etc.
"""

import numpy as np
import pandas as pd


def add_custom_features(df, g, close_col='close', volume_col='volume'):
    """Add custom trading features."""
    c, v = df[close_col], df[volume_col]

    # Value transaksi & liquidity
    df['value_transaksi'] = c * v
    df['r20_value_transaksi'] = g['value_transaksi'].transform(lambda x: x.rolling(20).mean())
    df['liquidity_ratio'] = df['value_transaksi'] / (df['r20_value_transaksi'] + 1e-10)

    # Turnover
    if 'market_cap' in df.columns:
        df['turnover_ratio'] = df['value_transaksi'] / (df['market_cap'] + 1e-10)
    else:
        df['turnover_ratio'] = 0.0

    # Amihud illiquidity
    if 'daily_ret' in df.columns:
        df['amihud'] = df['daily_ret'].abs() / (df['value_transaksi'] / 1e9 + 1e-10)

    # Volume features
    for w in [5, 10, 20]:
        vol_ma = g[volume_col].transform(lambda x: x.rolling(w).mean())
        df[f'rvol_{w}'] = v / (vol_ma + 1)

    # OBV
    price_change = g[close_col].diff()
    vol_sign = np.where(price_change > 0, 1, np.where(price_change < 0, -1, 0))
    df['obv'] = (vol_sign * v.values).cumsum()  # Note: cumsum will be regrouped in pipeline

    # Volume Z-Score
    vol_ma_20 = g[volume_col].transform(lambda x: x.rolling(20).mean())
    vol_std_20 = g[volume_col].transform(lambda x: x.rolling(20).std())
    df['vol_z_score'] = (v - vol_ma_20) / (vol_std_20 + 1)
    df['vol_spike_ratio'] = v / (vol_ma_20 + 1)

    # VPT
    pct_chg = g[close_col].pct_change()
    df['vpt'] = (v * pct_chg).groupby(df.get('symbol', pd.Series(0, index=df.index))).cumsum().fillna(0)
    df['vpt_slope_3'] = g['vpt'].transform(lambda x: x.diff(3))

    # VWAP
    tp = (df.get('high', c) + df.get('low', c) + c) / 3
    vp = tp * v
    for w in [5, 20]:
        sum_vp = g['vp'].transform(lambda x: x.rolling(w).sum()) if 'vp' not in df.columns else \
                 pd.Series(vp).groupby(df.get('symbol', pd.Series(0, index=df.index))).transform(lambda x: x.rolling(w).sum())
        sum_vol = g[volume_col].transform(lambda x: x.rolling(w).sum())
        vwap_val = sum_vp / (sum_vol + 1)
        df[f'dist_vwap_{w}'] = (c - vwap_val) / (vwap_val + 1e-10)

    # Force Index
    df['force_index_raw'] = price_change * v
    df['force_index_2'] = g['force_index_raw'].transform(lambda x: x.ewm(span=2, adjust=False).mean())
    df['force_index_13'] = g['force_index_raw'].transform(lambda x: x.ewm(span=13, adjust=False).mean())

    # CMF
    if 'high' in df.columns and 'low' in df.columns:
        mfm = ((c - df['low']) - (df['high'] - c)) / (df['high'] - df['low'] + 1e-10)
        mfv = mfm * v
        df['cmf_20'] = g.apply(lambda x: pd.Series(
            (mfm.loc[x.index] * v.loc[x.index]).rolling(20).sum() /
            (v.loc[x.index].rolling(20).sum() + 1e-10),
            index=x.index
        )).droplevel(0) if len(g) > 0 else mfv.rolling(20).sum() / (v.rolling(20).sum() + 1e-10)

    # Ease of Movement
    if 'high' in df.columns and 'low' in df.columns:
        range_hl = df['high'] - df['low']
        df['vol_to_range_ratio'] = v / (range_hl + 1e-10)
        df['log_vol_to_range'] = np.log1p(df['vol_to_range_ratio'])

    # Interaction features
    if 'daily_ret' in df.columns:
        df['vol_mom_interaction'] = df['vol_spike_ratio'] * df['daily_ret']

    return df
