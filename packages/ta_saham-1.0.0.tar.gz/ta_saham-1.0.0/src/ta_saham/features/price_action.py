"""
Price Action Features — candle ratios, gap analysis, range.
"""

import numpy as np
import pandas as pd


def add_price_action_features(df, g, open_col='open', high_col='high',
                              low_col='low', close_col='close'):
    """Add price action features to DataFrame.

    Args:
        df: DataFrame with OHLC columns
        g: GroupBy object (grouped by symbol)
    """
    o, h, l, c = df[open_col], df[high_col], df[low_col], df[close_col]

    # Body & Shadow ratios
    rng = h - l + 1e-10
    body = (c - o).abs()
    df['body_pct'] = (c - o) / (o + 1e-10)
    df['body_ratio'] = body / rng
    df['upper_shadow_pct'] = (h - pd.concat([o, c], axis=1).max(axis=1)) / (c + 1e-10)
    df['lower_shadow_pct'] = (pd.concat([o, c], axis=1).min(axis=1) - l) / (c + 1e-10)
    df['high_low_range'] = (h - l) / (c + 1e-10)
    df['is_green'] = (c > o).astype(int)

    # Shadow dominance
    df['shadow_dominance'] = df['lower_shadow_pct'] / (df['upper_shadow_pct'] + 1e-10)

    # Gap analysis
    prev_close = g[close_col].shift(1)
    df['gap_pct'] = (o - prev_close) / (prev_close + 1e-10)
    df['gap_mom'] = (o - g[high_col].shift(1)) / (g[high_col].shift(1) + 1e-10)

    # Log return
    df['log_ret'] = np.log(c / c.shift(1))

    # Buying pressure
    df['buying_pressure'] = np.where(rng > 1e-8, (c - l) / rng, 0.0)

    # Range breakout intensity
    range_5d = g[high_col].transform(lambda x: x.rolling(5).max()) - \
               g[low_col].transform(lambda x: x.rolling(5).min())
    df['body_to_5d_range'] = body / (range_5d + 1e-10)

    # Close position relative to day's range
    df['close_position'] = (c - l) / rng  # 0=closed at low, 1=closed at high
    df['close_at_high'] = (c == h).astype(int)
    df['close_at_low'] = (c == l).astype(int)

    # Full marubozu detection
    df['full_marubozu'] = (
        ((o - l).abs() <= o * 0.001) &
        ((c - h).abs() <= c * 0.001) &
        (c > o)
    ).astype(int)

    # Hammer-like (long lower shadow)
    body_size = (o - c).abs()
    lower_shadow = pd.concat([o, c], axis=1).min(axis=1) - l
    df['long_lower_shadow'] = (lower_shadow > 2 * body_size).astype(int)

    # Doji
    df['is_doji'] = (df['body_pct'].abs() <= df['high_low_range'] * 0.1).astype(int)

    # Psychological round numbers
    def _dist_round(price):
        if price < 100: step = 50
        elif price < 500: step = 100
        elif price < 5000: step = 500
        else: step = 1000
        nearest = round(price / step) * step
        return abs(price - nearest) / (price + 1e-10)

    df['dist_round_num'] = c.apply(_dist_round)

    return df
