# LoadStrike SDK for Python

LoadStrike is a developer-first load testing SDK for Python services, jobs, and automated test suites. Use it to describe real workflows in Python, execute them in-process, and collect structured reports from the same codebase that owns the system under test.

## What This SDK Is For

- Author scenario-based load tests in Python.
- Model transaction flows across HTTP and event-driven systems.
- Apply load simulations, thresholds, and custom metrics during execution.
- Generate local reports and, on eligible plans, forward results to supported reporting sinks.

Built-in transport coverage includes HTTP, Kafka, RabbitMQ, NATS, Redis Streams, Azure Event Hubs, Push Diffusion, and delegate-based custom streams. Local report output supports HTML, Markdown, TXT, and CSV, and eligible plans can publish to InfluxDB, TimescaleDB, Grafana Loki, Datadog, Splunk HEC, and OpenTelemetry Collector.

## Requirements

- Python 3.9 or later

## Install

```bash
pip install loadstrike
```

## Quick Start

```python
from loadstrike_sdk import (
    LoadStrikeResponse,
    LoadStrikeRunner,
    LoadStrikeScenario,
    LoadStrikeSimulation,
    LoadStrikeStep,
)


def run_orders(context):
    return LoadStrikeStep.run(
        "publish-order",
        context,
        lambda: LoadStrikeResponse.ok("200"),
    ).as_reply()


scenario = (
    LoadStrikeScenario.create("orders", run_orders)
    .with_load_simulations(LoadStrikeSimulation.inject(10, 1, 20))
)

result = (
    LoadStrikeRunner.register_scenarios(scenario)
    .with_runner_key("rkl_your_runner_key")
    .run()
)
```

`run()` returns the detailed run result, including generated report files, scenario statistics, metrics, and sink status.

## Runner Keys

Runnable workloads require a `RunnerKey`. Supply it with `.with_runner_key(...)` or through your application configuration before calling `run()`.

## Documentation

- Product documentation: https://loadstrike.com/documentation
