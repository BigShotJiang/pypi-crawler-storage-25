from __future__ import annotations

from dataclasses import MISSING, dataclass, field, fields
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, TypeVar, Union, get_args, get_origin, get_type_hints

TContract = TypeVar("TContract", bound="_ContractModelMixin")
_NONE_TYPE = type(None)


class _ContractModelMixin:
    def to_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {}
        for dataclass_field in fields(self):
            payload[dataclass_field.name] = _serialize_contract_value(
                getattr(self, dataclass_field.name)
            )
        return payload

    to_dict = to_payload

    @classmethod
    def from_payload(cls: type[TContract], value: Any) -> TContract:
        if isinstance(value, cls):
            return value

        payload = value if isinstance(value, dict) else {}
        type_hints = get_type_hints(cls)
        kwargs: Dict[str, Any] = {}

        for dataclass_field in fields(cls):
            field_name = dataclass_field.name
            raw_value = payload.get(field_name, MISSING)
            if raw_value is MISSING:
                continue
            kwargs[field_name] = _deserialize_contract_value(
                raw_value,
                type_hints.get(field_name, dataclass_field.type),
            )

        return cls(**kwargs)  # type: ignore[arg-type]

    def __getitem__(self, key: str) -> Any:
        return self.to_payload()[key]

    def get(self, key: str, default: Any = None) -> Any:
        return self.to_payload().get(key, default)

    def keys(self):
        return self.to_payload().keys()

    def items(self):
        return self.to_payload().items()

    def values(self):
        return self.to_payload().values()

    def __contains__(self, key: object) -> bool:
        return key in self.to_payload()

    def __iter__(self):
        return iter(self.to_payload())


def _serialize_contract_value(value: Any) -> Any:
    if isinstance(value, datetime):
        normalized = value if value.tzinfo is not None else value.replace(tzinfo=timezone.utc)
        return normalized.isoformat()
    if isinstance(value, _ContractModelMixin):
        return value.to_payload()
    if isinstance(value, list):
        return [_serialize_contract_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _serialize_contract_value(item) for key, item in value.items()}
    return value


def _deserialize_contract_value(value: Any, type_hint: Any) -> Any:
    origin = get_origin(type_hint)
    if origin is Union:
        args = [arg for arg in get_args(type_hint) if arg is not _NONE_TYPE]
        if value is None:
            return None
        if len(args) == 1:
            return _deserialize_contract_value(value, args[0])

    if origin in (list, List):
        element_type = get_args(type_hint)[0] if get_args(type_hint) else Any
        if not isinstance(value, list):
            return []
        return [_deserialize_contract_value(item, element_type) for item in value]

    if origin in (dict, Dict):
        value_type = get_args(type_hint)[1] if len(get_args(type_hint)) >= 2 else Any
        if not isinstance(value, dict):
            return {}
        return {
            str(key): (
                _deserialize_contract_value(item, value_type)
                if value_type not in (Any, object)
                else item
            )
            for key, item in value.items()
        }

    if type_hint in (Any, object):
        return value
    if type_hint is datetime:
        return _deserialize_contract_datetime(value)
    if type_hint is str:
        return "" if value is None else str(value)
    if type_hint is int:
        return int(value)
    if type_hint is float:
        return float(value)
    if type_hint is bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        return str(value).strip().lower() in {"1", "true", "yes", "on"}
    if isinstance(type_hint, type) and issubclass(type_hint, _ContractModelMixin):
        return type_hint.from_payload(value)

    return value


def _deserialize_contract_datetime(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo is not None else value.replace(tzinfo=timezone.utc)
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(float(value), tz=timezone.utc)

    text = str(value).strip()
    if not text:
        return None

    normalized = text[:-1] + "+00:00" if text.endswith("Z") else text
    parsed = datetime.fromisoformat(normalized)
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)


@dataclass
class LoadStrikeRunContext(_ContractModelMixin):
    ConsoleMetricsEnabled: Optional[bool] = None
    LocalDevClusterEnabled: Optional[bool] = None
    ConfigPath: Optional[str] = None
    InfraConfigPath: Optional[str] = None
    AgentGroup: Optional[str] = None
    AgentsCount: Optional[int] = None
    AgentTargetScenarios: List[str] = field(default_factory=list)
    ClusterId: Optional[str] = None
    CoordinatorTargetScenarios: List[str] = field(default_factory=list)
    RunnerKey: Optional[str] = None
    LicenseValidationTimeoutSeconds: Optional[float] = None
    MinimumLogLevel: Optional[str] = None
    NatsServerUrl: Optional[str] = None
    NodeType: Optional[str] = None
    ReportsEnabled: Optional[bool] = None
    ReportFileName: Optional[str] = None
    ReportFolderPath: Optional[str] = None
    ReportFormats: List[str] = field(default_factory=list)
    ReportingIntervalSeconds: Optional[float] = None
    ReportingSinks: List["LoadStrikeReportingSinkSpec"] = field(default_factory=list)
    ScenarioCompletionTimeoutSeconds: Optional[float] = None
    ClusterCommandTimeoutSeconds: Optional[float] = None
    RestartIterationMaxAttempts: Optional[int] = None
    SessionId: Optional[str] = None
    TargetScenarios: List[str] = field(default_factory=list)
    TestName: Optional[str] = None
    TestSuite: Optional[str] = None
    WorkerPlugins: List["LoadStrikeWorkerPluginSpec"] = field(default_factory=list)


@dataclass(init=False)
class LoadStrikeRunRequest(_ContractModelMixin):
    Context: LoadStrikeRunContext = field(default_factory=LoadStrikeRunContext)
    Scenarios: List["LoadStrikeScenarioSpec"] = field(default_factory=list)
    RunArgs: List[str] = field(default_factory=list)

    def __init__(
        self,
        scenarios: Optional[List[Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        run_args: Optional[List[str]] = None,
        *,
        Context: Optional[Dict[str, Any] | LoadStrikeRunContext] = None,
        Scenarios: Optional[List[Any]] = None,
        RunArgs: Optional[List[str]] = None,
    ) -> None:
        context_value = Context if Context is not None else context
        scenarios_value = Scenarios if Scenarios is not None else scenarios
        run_args_value = RunArgs if RunArgs is not None else run_args

        self.Context = LoadStrikeRunContext.from_payload(context_value or {})
        self.Scenarios = [
            LoadStrikeScenarioSpec.from_payload(item)
            for item in list(scenarios_value or [])
        ]
        self.RunArgs = [str(item) for item in list(run_args_value or [])]

    @property
    def context(self) -> Dict[str, Any]:
        return self.Context.to_payload()

    @context.setter
    def context(self, value: Dict[str, Any]) -> None:
        self.Context = LoadStrikeRunContext.from_payload(value or {})

    @property
    def scenarios(self) -> List[Dict[str, Any]]:
        return [scenario.to_payload() for scenario in self.Scenarios]

    @scenarios.setter
    def scenarios(self, value: List[Any]) -> None:
        self.Scenarios = [LoadStrikeScenarioSpec.from_payload(item) for item in list(value or [])]

    @property
    def run_args(self) -> List[str]:
        return list(self.RunArgs)

    @run_args.setter
    def run_args(self, value: List[str]) -> None:
        self.RunArgs = [str(item) for item in list(value or [])]


@dataclass
class LoadStrikeLoadSimulationSpec(_ContractModelMixin):
    Kind: Optional[str] = None
    Rate: Optional[int] = None
    MinRate: Optional[int] = None
    MaxRate: Optional[int] = None
    Copies: Optional[int] = None
    Iterations: Optional[int] = None
    IntervalSeconds: Optional[float] = None
    DuringSeconds: Optional[float] = None


@dataclass
class LoadStrikeThresholdSpec(_ContractModelMixin):
    Scope: Optional[str] = None
    StepName: Optional[str] = None
    Field: Optional[str] = None
    Operator: Optional[str] = None
    Value: float = 0.0
    AbortWhenErrorCount: Optional[int] = None
    StartCheckAfterSeconds: Optional[float] = None


@dataclass
class LoadStrikeRedisCorrelationStoreSpec(_ContractModelMixin):
    ConnectionString: Optional[str] = None
    Database: Optional[int] = None
    KeyPrefix: Optional[str] = None
    EntryTtlSeconds: Optional[float] = None


@dataclass
class LoadStrikeCorrelationStoreSpec(_ContractModelMixin):
    Kind: Optional[str] = None
    Redis: Optional[LoadStrikeRedisCorrelationStoreSpec] = None


@dataclass
class LoadStrikeHttpOAuth2ClientCredentialsOptions(_ContractModelMixin):
    TokenEndpoint: Optional[str] = None
    ClientId: Optional[str] = None
    ClientSecret: Optional[str] = None
    Scopes: Optional[List[str]] = None
    AdditionalFormFields: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeHttpAuthOptions(_ContractModelMixin):
    Type: Optional[str] = None
    Username: Optional[str] = None
    Password: Optional[str] = None
    BearerToken: Optional[str] = None
    TokenUrl: Optional[str] = None
    ClientId: Optional[str] = None
    ClientSecret: Optional[str] = None
    Scope: Optional[str] = None
    Scopes: Optional[List[str]] = None
    Audience: Optional[str] = None
    AdditionalFormFields: Optional[Dict[str, str]] = None
    TokenHeaderName: Optional[str] = None
    OAuth2ClientCredentials: Optional[LoadStrikeHttpOAuth2ClientCredentialsOptions] = None


@dataclass
class LoadStrikeHttpEndpointOptions(_ContractModelMixin):
    Url: Optional[str] = None
    Method: Optional[str] = None
    BodyType: Optional[str] = None
    RequestTimeoutSeconds: Optional[float] = None
    ResponseSource: Optional[str] = None
    TrackingPayloadSource: Optional[str] = None
    ConsumeArrayPath: Optional[str] = None
    ConsumeJsonArrayResponse: Optional[bool] = None
    TokenRequestHeaders: Optional[Dict[str, str]] = None
    Auth: Optional[LoadStrikeHttpAuthOptions] = None


@dataclass
class LoadStrikeKafkaSaslOptions(_ContractModelMixin):
    Mechanism: Optional[str] = None
    Username: Optional[str] = None
    Password: Optional[str] = None
    OAuthBearerTokenEndpointUrl: Optional[str] = None
    AdditionalSettings: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeKafkaEndpointOptions(_ContractModelMixin):
    BootstrapServers: Optional[str] = None
    Topic: Optional[str] = None
    ConsumerGroupId: Optional[str] = None
    SecurityProtocol: Optional[str] = None
    Sasl: Optional[LoadStrikeKafkaSaslOptions] = None
    ConfluentSettings: Optional[Dict[str, str]] = None
    StartFromEarliest: Optional[bool] = None


@dataclass
class LoadStrikeRabbitMqEndpointOptions(_ContractModelMixin):
    HostName: Optional[str] = None
    Port: Optional[int] = None
    VirtualHost: Optional[str] = None
    UserName: Optional[str] = None
    Password: Optional[str] = None
    Exchange: Optional[str] = None
    RoutingKey: Optional[str] = None
    QueueName: Optional[str] = None
    Durable: Optional[bool] = None
    AutoAck: Optional[bool] = None
    UseSsl: Optional[bool] = None
    ClientProperties: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeNatsEndpointOptions(_ContractModelMixin):
    ServerUrl: Optional[str] = None
    Subject: Optional[str] = None
    QueueGroup: Optional[str] = None
    UserName: Optional[str] = None
    Password: Optional[str] = None
    Token: Optional[str] = None
    ConnectionName: Optional[str] = None
    MaxReconnectAttempts: Optional[int] = None


@dataclass
class LoadStrikeRedisStreamsEndpointOptions(_ContractModelMixin):
    ConnectionString: Optional[str] = None
    StreamKey: Optional[str] = None
    ConsumerGroup: Optional[str] = None
    ConsumerName: Optional[str] = None
    StartFromEarliest: Optional[bool] = None
    ReadCount: Optional[int] = None
    MaxLength: Optional[int] = None


@dataclass
class LoadStrikeAzureEventHubsEndpointOptions(_ContractModelMixin):
    ConnectionString: Optional[str] = None
    EventHubName: Optional[str] = None
    ConsumerGroup: Optional[str] = None
    StartFromEarliest: Optional[bool] = None
    PartitionId: Optional[str] = None
    PartitionKey: Optional[str] = None
    PartitionCount: Optional[int] = None


@dataclass
class LoadStrikeDelegateEndpointOptions(_ContractModelMixin):
    ProduceCallbackUrl: Optional[str] = None
    ConsumeCallbackUrl: Optional[str] = None
    ConnectionMetadata: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikePushDiffusionEndpointOptions(_ContractModelMixin):
    ServerUrl: Optional[str] = None
    TopicPath: Optional[str] = None
    Principal: Optional[str] = None
    Password: Optional[str] = None
    ConnectionProperties: Optional[Dict[str, str]] = None
    PublishCallbackUrl: Optional[str] = None
    SubscribeCallbackUrl: Optional[str] = None


@dataclass
class LoadStrikeEndpointSpec(_ContractModelMixin):
    Kind: Optional[str] = None
    Name: Optional[str] = None
    Mode: Optional[str] = None
    TrackingField: Optional[str] = None
    GatherByField: Optional[str] = None
    AutoGenerateTrackingIdWhenMissing: Optional[bool] = None
    PollIntervalSeconds: Optional[float] = None
    MessageHeaders: Optional[Dict[str, str]] = None
    MessagePayload: Any = None
    ContentType: Optional[str] = None
    Http: Optional[LoadStrikeHttpEndpointOptions] = None
    Kafka: Optional[LoadStrikeKafkaEndpointOptions] = None
    RabbitMq: Optional[LoadStrikeRabbitMqEndpointOptions] = None
    Nats: Optional[LoadStrikeNatsEndpointOptions] = None
    RedisStreams: Optional[LoadStrikeRedisStreamsEndpointOptions] = None
    AzureEventHubs: Optional[LoadStrikeAzureEventHubsEndpointOptions] = None
    DelegateStream: Optional[LoadStrikeDelegateEndpointOptions] = None
    PushDiffusion: Optional[LoadStrikePushDiffusionEndpointOptions] = None


@dataclass
class LoadStrikeTrackingConfigurationSpec(_ContractModelMixin):
    Source: Optional[LoadStrikeEndpointSpec] = None
    Destination: Optional[LoadStrikeEndpointSpec] = None
    RunMode: Optional[str] = None
    CorrelationTimeoutSeconds: Optional[float] = None
    TimeoutSweepIntervalSeconds: Optional[float] = None
    TimeoutBatchSize: Optional[int] = None
    TimeoutCountsAsFailure: Optional[bool] = None
    TrackingFieldValueCaseSensitive: Optional[bool] = None
    GatherByFieldValueCaseSensitive: Optional[bool] = None
    ExecuteOriginalScenarioRun: Optional[bool] = None
    MetricPrefix: Optional[str] = None
    CorrelationStore: Optional[LoadStrikeCorrelationStoreSpec] = None


@dataclass
class LoadStrikeScenarioSpec(_ContractModelMixin):
    Name: Optional[str] = None
    MaxFailCount: Optional[int] = None
    RestartIterationOnFail: Optional[bool] = None
    WithoutWarmUp: Optional[bool] = None
    WarmUpDurationSeconds: Optional[float] = None
    Weight: Optional[int] = None
    LoadSimulations: List[LoadStrikeLoadSimulationSpec] = field(default_factory=list)
    Thresholds: List[LoadStrikeThresholdSpec] = field(default_factory=list)
    Tracking: Optional[LoadStrikeTrackingConfigurationSpec] = None


@dataclass
class LoadStrikeInfluxDbSinkOptions(_ContractModelMixin):
    BaseUrl: Optional[str] = None
    WriteEndpointPath: Optional[str] = None
    Organization: Optional[str] = None
    Bucket: Optional[str] = None
    Token: Optional[str] = None
    MeasurementName: Optional[str] = None
    TimeoutSeconds: Optional[int] = None
    StaticTags: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeTimescaleDbSinkOptions(_ContractModelMixin):
    ConnectionString: Optional[str] = None
    Schema: Optional[str] = None
    TableName: Optional[str] = None
    CreateSchemaIfMissing: Optional[bool] = None
    EnableHypertableIfAvailable: Optional[bool] = None
    StaticTags: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeGrafanaLokiSinkOptions(_ContractModelMixin):
    BaseUrl: Optional[str] = None
    PushEndpointPath: Optional[str] = None
    BearerToken: Optional[str] = None
    Username: Optional[str] = None
    Password: Optional[str] = None
    TenantId: Optional[str] = None
    TimeoutSeconds: Optional[int] = None
    StaticLabels: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeDatadogSinkOptions(_ContractModelMixin):
    BaseUrl: Optional[str] = None
    LogsEndpointPath: Optional[str] = None
    MetricsEndpointPath: Optional[str] = None
    ApiKey: Optional[str] = None
    ApplicationKey: Optional[str] = None
    Source: Optional[str] = None
    Service: Optional[str] = None
    Host: Optional[str] = None
    TimeoutSeconds: Optional[int] = None
    StaticTags: Optional[Dict[str, str]] = None
    StaticAttributes: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeSplunkSinkOptions(_ContractModelMixin):
    BaseUrl: Optional[str] = None
    EventEndpointPath: Optional[str] = None
    Token: Optional[str] = None
    Source: Optional[str] = None
    Sourcetype: Optional[str] = None
    Index: Optional[str] = None
    Host: Optional[str] = None
    TimeoutSeconds: Optional[int] = None
    StaticFields: Optional[Dict[str, str]] = None


@dataclass
class LoadStrikeOtelCollectorSinkOptions(_ContractModelMixin):
    BaseUrl: Optional[str] = None
    LogsEndpointPath: Optional[str] = None
    MetricsEndpointPath: Optional[str] = None
    TimeoutSeconds: Optional[int] = None
    Headers: Optional[Dict[str, str]] = None
    StaticResourceAttributes: Optional[Dict[str, str]] = None

@dataclass
class LoadStrikeReportingSinkSpec(_ContractModelMixin):
    Kind: Optional[str] = None
    InfluxDb: Optional[LoadStrikeInfluxDbSinkOptions] = None
    TimescaleDb: Optional[LoadStrikeTimescaleDbSinkOptions] = None
    GrafanaLoki: Optional[LoadStrikeGrafanaLokiSinkOptions] = None
    Datadog: Optional[LoadStrikeDatadogSinkOptions] = None
    Splunk: Optional[LoadStrikeSplunkSinkOptions] = None
    OtelCollector: Optional[LoadStrikeOtelCollectorSinkOptions] = None


@dataclass
class LoadStrikeWorkerPluginSpec(_ContractModelMixin):
    PluginName: Optional[str] = None
    CallbackUrl: Optional[str] = None


@dataclass
class LoadStrikeNodeInfoDto(_ContractModelMixin):
    CoresCount: int = 0
    CurrentOperation: str = ""
    DotNetVersion: str = ""
    MachineName: str = ""
    EngineVersion: str = ""
    NodeType: str = ""
    OS: str = ""
    Processor: str = ""


@dataclass
class LoadStrikeTestInfoDto(_ContractModelMixin):
    ClusterId: str = ""
    CreatedUtc: Optional[datetime] = None
    SessionId: str = ""
    TestName: str = ""
    TestSuite: str = ""


@dataclass
class LoadStrikeRequestStatsDto(_ContractModelMixin):
    Count: int = 0
    Percent: int = 0
    Rps: float = 0.0


@dataclass
class LoadStrikeLatencyStatsDto(_ContractModelMixin):
    MinMs: float = 0.0
    MeanMs: float = 0.0
    MaxMs: float = 0.0
    StdDev: float = 0.0
    Percent50: float = 0.0
    Percent75: float = 0.0
    Percent95: float = 0.0
    Percent99: float = 0.0


@dataclass
class LoadStrikeDataTransferStatsDto(_ContractModelMixin):
    AllBytes: int = 0
    MinBytes: int = 0
    MeanBytes: int = 0
    MaxBytes: int = 0
    StdDev: float = 0.0
    Percent50: int = 0
    Percent75: int = 0
    Percent95: int = 0
    Percent99: int = 0


@dataclass
class LoadStrikeStatusCodeStatsDto(_ContractModelMixin):
    StatusCode: str = ""
    Message: str = ""
    Count: int = 0
    Percent: int = 0
    IsError: bool = False


@dataclass
class LoadStrikeMeasurementStatsDto(_ContractModelMixin):
    Request: LoadStrikeRequestStatsDto = field(default_factory=LoadStrikeRequestStatsDto)
    Latency: LoadStrikeLatencyStatsDto = field(default_factory=LoadStrikeLatencyStatsDto)
    DataTransfer: LoadStrikeDataTransferStatsDto = field(default_factory=LoadStrikeDataTransferStatsDto)
    StatusCodes: List[LoadStrikeStatusCodeStatsDto] = field(default_factory=list)


@dataclass
class LoadStrikeStepStatsDto(_ContractModelMixin):
    StepName: str = ""
    SortIndex: int = 0
    Ok: LoadStrikeMeasurementStatsDto = field(default_factory=LoadStrikeMeasurementStatsDto)
    Fail: LoadStrikeMeasurementStatsDto = field(default_factory=LoadStrikeMeasurementStatsDto)


@dataclass
class LoadStrikeScenarioStatsDto(_ContractModelMixin):
    ScenarioName: str = ""
    SortIndex: int = 0
    AllBytes: int = 0
    AllFailCount: int = 0
    AllOkCount: int = 0
    AllRequestCount: int = 0
    CurrentOperation: str = ""
    DurationMs: float = 0.0
    Ok: LoadStrikeMeasurementStatsDto = field(default_factory=LoadStrikeMeasurementStatsDto)
    Fail: LoadStrikeMeasurementStatsDto = field(default_factory=LoadStrikeMeasurementStatsDto)
    Steps: List[LoadStrikeStepStatsDto] = field(default_factory=list)


@dataclass
class LoadStrikeCounterStatsDto(_ContractModelMixin):
    ScenarioName: str = ""
    MetricName: str = ""
    UnitOfMeasure: str = ""
    Value: int = 0


@dataclass
class LoadStrikeGaugeStatsDto(_ContractModelMixin):
    ScenarioName: str = ""
    MetricName: str = ""
    UnitOfMeasure: str = ""
    Value: float = 0.0


@dataclass
class LoadStrikeMetricStatsDto(_ContractModelMixin):
    DurationMs: float = 0.0
    Counters: List[LoadStrikeCounterStatsDto] = field(default_factory=list)
    Gauges: List[LoadStrikeGaugeStatsDto] = field(default_factory=list)


@dataclass
class LoadStrikeThresholdResultDto(_ContractModelMixin):
    ScenarioName: str = ""
    StepName: str = ""
    CheckExpression: str = ""
    ErrorCount: int = 0
    IsFailed: bool = False
    ExceptionMessage: str = ""


@dataclass
class LoadStrikePluginDataTableDto(_ContractModelMixin):
    TableName: str = ""
    Rows: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class LoadStrikePluginDataDto(_ContractModelMixin):
    PluginName: str = ""
    Hints: List[str] = field(default_factory=list)
    Tables: List[LoadStrikePluginDataTableDto] = field(default_factory=list)


@dataclass
class LoadStrikeNodeStatsDto(_ContractModelMixin):
    AllBytes: int = 0
    AllFailCount: int = 0
    AllOkCount: int = 0
    AllRequestCount: int = 0
    DurationMs: float = 0.0
    NodeInfo: LoadStrikeNodeInfoDto = field(default_factory=LoadStrikeNodeInfoDto)
    TestInfo: LoadStrikeTestInfoDto = field(default_factory=LoadStrikeTestInfoDto)
    Metrics: LoadStrikeMetricStatsDto = field(default_factory=LoadStrikeMetricStatsDto)
    Scenarios: List[LoadStrikeScenarioStatsDto] = field(default_factory=list)
    Thresholds: List[LoadStrikeThresholdResultDto] = field(default_factory=list)
    Plugins: List[LoadStrikePluginDataDto] = field(default_factory=list)


@dataclass(init=False)
class LoadStrikeRunResponse(_ContractModelMixin):
    CompletedUtc: Optional[datetime] = None
    Stats: Optional[LoadStrikeNodeStatsDto] = None

    def __init__(
        self,
        CompletedUtc: Optional[datetime | str] = None,
        Stats: Optional[Dict[str, Any] | LoadStrikeNodeStatsDto] = None,
        *,
        completed_utc: Optional[datetime | str] = None,
        stats: Optional[Dict[str, Any] | LoadStrikeNodeStatsDto] = None,
    ) -> None:
        completed_value = CompletedUtc if CompletedUtc is not None else completed_utc
        stats_value = Stats if Stats is not None else stats
        self.CompletedUtc = _deserialize_contract_datetime(completed_value)
        self.Stats = None if stats_value is None else LoadStrikeNodeStatsDto.from_payload(stats_value)

    @property
    def completed_utc(self) -> Optional[datetime]:
        return self.CompletedUtc

    @property
    def stats(self) -> Optional[LoadStrikeNodeStatsDto]:
        return self.Stats


@dataclass
class LoadStrikePayloadDto(_ContractModelMixin):
    Headers: Optional[Dict[str, str]] = None
    BodyUtf8: Optional[str] = None
    BodyBase64: Optional[str] = None
    ContentType: Optional[str] = None


@dataclass
class LoadStrikeProducedMessageRequestDto(_ContractModelMixin):
    TrackingId: Optional[str] = None
    EndpointKind: Optional[str] = None
    EndpointName: Optional[str] = None
    Mode: Optional[str] = None
    Payload: Optional[LoadStrikePayloadDto] = None


@dataclass
class LoadStrikeProducedMessageResultDto(_ContractModelMixin):
    IsSuccess: bool = True
    TimestampUtc: Optional[str] = None
    ErrorMessage: Optional[str] = None
    ResponsePayload: Optional[LoadStrikePayloadDto] = None


@dataclass
class LoadStrikeConsumedMessageDto(_ContractModelMixin):
    TimestampUtc: Optional[str] = None
    Payload: Optional[LoadStrikePayloadDto] = None
