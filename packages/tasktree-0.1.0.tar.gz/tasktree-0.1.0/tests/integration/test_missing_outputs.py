"""Integration tests for missing output detection."""

import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from helpers.logging import logger_stub
from tasktree.executor import Executor
from tasktree.parser import Recipe, Task
from tasktree.process_runner import TaskOutputTypes, make_process_runner
from tasktree.state import StateManager


class TestMissingOutputsIntegration(unittest.TestCase):
    """
    """

    def test_missing_outputs_integration(self):
        """
        Integration test for missing outputs scenario.

        1. Run task with outputs successfully
        2. Delete one output file
        3. Run again - should execute and warn
        4. Run third time - should skip (outputs now exist)
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create a task that produces an output file
            task = Task(
                name="build",
                cmd=f"echo 'test output' > {project_root / 'output.txt'}",
                outputs=["output.txt"],
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            state_manager = StateManager(project_root)
            state_manager.load()
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # First run - task should execute (no inputs, always runs)
            statuses = executor.execute_task("build", TaskOutputTypes.ALL)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "no_inputs")
            self.assertTrue((project_root / "output.txt").exists())

            # Second run - task should run again (no inputs, always runs)
            statuses = executor.execute_task("build", TaskOutputTypes.ALL)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "no_inputs")

            # Delete the output file
            (project_root / "output.txt").unlink()
            self.assertFalse((project_root / "output.txt").exists())

            # Third run - task executes (no inputs, always runs)
            statuses = executor.execute_task("build", TaskOutputTypes.ALL)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "no_inputs")
            self.assertTrue((project_root / "output.txt").exists())

            # Fourth run - task runs again (no inputs, always runs)
            statuses = executor.execute_task("build", TaskOutputTypes.ALL)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "no_inputs")

    def test_partial_outputs_missing_triggers_rerun(self):
        """
        Test that missing some (but not all) outputs triggers rebuild.

        When a task declares multiple outputs but only some exist,
        the task should run to regenerate all outputs.
        """

        with TemporaryDirectory() as tmpdir:
            project_root = Path(tmpdir)

            # Create a task that produces two output files
            task = Task(
                name="build",
                cmd=f"echo 'output1' > {project_root / 'output1.txt'} && echo 'output2' > {project_root / 'output2.txt'}",
                outputs=["output1.txt", "output2.txt"],
            )

            tasks = {"build": task}
            recipe = Recipe(
                tasks=tasks,
                project_root=project_root,
                recipe_path=project_root / "tasktree.yaml",
            )
            state_manager = StateManager(project_root)
            state_manager.load()
            executor = Executor(recipe, state_manager, logger_stub, make_process_runner)

            # First run - task should execute (no inputs, always runs)
            statuses = executor.execute_task("build", TaskOutputTypes.ALL)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "no_inputs")
            self.assertTrue((project_root / "output1.txt").exists())
            self.assertTrue((project_root / "output2.txt").exists())

            # Second run - task should run again (no inputs, always runs)
            statuses = executor.execute_task("build", TaskOutputTypes.ALL)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "no_inputs")

            # Delete only one output file
            (project_root / "output1.txt").unlink()
            self.assertFalse((project_root / "output1.txt").exists())
            self.assertTrue((project_root / "output2.txt").exists())

            # Third run - task executes (no inputs, always runs)
            statuses = executor.execute_task("build", TaskOutputTypes.ALL)
            self.assertTrue(statuses["build"].will_run)
            self.assertEqual(statuses["build"].reason, "no_inputs")

            # Both outputs should exist again
            self.assertTrue((project_root / "output1.txt").exists())
            self.assertTrue((project_root / "output2.txt").exists())


if __name__ == "__main__":
    unittest.main()
