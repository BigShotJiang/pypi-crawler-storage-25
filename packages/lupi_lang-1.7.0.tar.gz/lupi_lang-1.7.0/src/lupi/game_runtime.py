
class GameRuntime:
    def window(self, width, height, title): print(f"[game] window {width}x{height} {title}")
    def clear(self, color='black'): print(f"[game] clear {color}")
    def rect(self, x, y, w, h, color='white'): print(f"[game] rect {x} {y} {w} {h} {color}")
    def circle(self, x, y, radius, color='white'): print(f"[game] circle {x} {y} {radius} {color}")
    def line(self, x1, y1, x2, y2, color='white', width=1): print(f"[game] line {x1} {y1} {x2} {y2} {color} {width}")
    def text(self, msg, x, y, color='white', size=24): print(f"[game] text {msg} at {x},{y}")
    def run(self): print("[game] loop iniciado (stub)")
