
from __future__ import annotations

class LupiGame3DError(Exception):
    pass

class _PlaceholderEntity:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)
        self.x = kwargs.get("x", 0)
        self.y = kwargs.get("y", 0)
        self.z = kwargs.get("z", 0)
        self.rx = kwargs.get("rx", 0)
        self.ry = kwargs.get("ry", 0)
        self.rz = kwargs.get("rz", 0)
        self.scale = kwargs.get("scale", 1)

    def look_at(self, other):
        return None

    def rotate(self, x=0, y=0, z=0):
        self.rx += x
        self.ry += y
        self.rz += z

    def collider(self, kind="box"):
        self.collider_type = kind


class Game3DRuntime:
    def __init__(self):
        self._enabled = False
        self._app = None
        self._entities = []

    def _ensure_engine(self):
        if self._enabled:
            return
        try:
            from ursina import Ursina, Entity, EditorCamera, DirectionalLight, Sky, color, mouse, raycast, held_keys, time
            self._Ursina = Ursina
            self._Entity = Entity
            self._EditorCamera = EditorCamera
            self._DirectionalLight = DirectionalLight
            self._Sky = Sky
            self._mouse = mouse
            self._raycast = raycast
            self._held_keys = held_keys
            self._time = time
            self._enabled = True
        except Exception as e:
            raise LupiGame3DError("Ursina nao instalada. Rode: lupi install ursina") from e

    def window(self, width, height, title):
        self._ensure_engine()
        if self._app is None:
            self._app = self._Ursina(borderless=False)
            try:
                from ursina import window
                window.title = str(title)
                window.size = (int(width), int(height))
            except Exception:
                pass

    def entity(self, **kwargs):
        self._ensure_engine()
        ent = self._Entity(**kwargs)
        self._entities.append(ent)
        return ent

    def camera(self):
        self._ensure_engine()
        return self._EditorCamera()

    def light(self, kind="directional", **kwargs):
        self._ensure_engine()
        if str(kind).lower() == "directional":
            return self._DirectionalLight(**kwargs)
        raise LupiGame3DError(f"Tipo de luz nao suportado: {kind}")

    def sky(self, texture=None):
        self._ensure_engine()
        return self._Sky(texture=texture) if texture is not None else self._Sky()

    def key(self, name):
        self._ensure_engine()
        return bool(self._held_keys.get(str(name), 0))

    def raycast(self, origin=(0,0,0), direction=(0,0,1), distance=999):
        self._ensure_engine()
        return self._raycast(origin, direction, distance=distance)

    def run(self):
        self._ensure_engine()
        if self._app is None:
            self._app = self._Ursina()
        self._app.run()
