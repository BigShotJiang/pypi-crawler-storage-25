
from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any

try:
    import discord
    from discord.ext import commands
except Exception:
    discord = None
    commands = None


class LupiDiscordError(Exception):
    pass


@dataclass
class AuthorWrapper:
    raw: Any

    @property
    def name(self):
        return getattr(self.raw, "name", "unknown")

    @property
    def bot(self):
        return bool(getattr(self.raw, "bot", False))

    @property
    def id(self):
        return getattr(self.raw, "id", None)


def _fire_and_forget(coro):
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(coro)
    except RuntimeError:
        asyncio.run(coro)


class LupiEmbed:
    def __init__(self, raw_embed):
        self._raw = raw_embed

    def field(self, name, value, inline=False):
        self._raw.add_field(name=str(name), value=str(value), inline=bool(inline))
        return self

    def footer(self, text):
        self._raw.set_footer(text=str(text))
        return self

    def thumbnail(self, url):
        self._raw.set_thumbnail(url=str(url))
        return self

    def image(self, url):
        self._raw.set_image(url=str(url))
        return self

    def author(self, name, url=None, icon_url=None):
        kwargs = {"name": str(name)}
        if url is not None:
            kwargs["url"] = str(url)
        if icon_url is not None:
            kwargs["icon_url"] = str(icon_url)
        self._raw.set_author(**kwargs)
        return self


class MessageWrapper:
    def __init__(self, raw_message):
        self.raw = raw_message
        self.content = raw_message.content
        self.author = AuthorWrapper(raw_message.author)
        self.channel = raw_message.channel
        self.guild = raw_message.guild

    def _normalize_value(self, value):
        return value._raw if hasattr(value, "_raw") else value

    def reply(self, value, view=None):
        if discord is None:
            return
        kwargs = {}
        if view is not None and hasattr(view, "_prepare"):
            view._prepare()
            kwargs["view"] = view._raw_view
        raw_value = self._normalize_value(value)
        if isinstance(raw_value, discord.Embed):
            _fire_and_forget(self.raw.reply(embed=raw_value, **kwargs))
        else:
            _fire_and_forget(self.raw.reply(str(raw_value), **kwargs))

    def send(self, value, view=None):
        if discord is None:
            return
        kwargs = {}
        if view is not None and hasattr(view, "_prepare"):
            view._prepare()
            kwargs["view"] = view._raw_view
        raw_value = self._normalize_value(value)
        if isinstance(raw_value, discord.Embed):
            _fire_and_forget(self.raw.channel.send(embed=raw_value, **kwargs))
        else:
            _fire_and_forget(self.raw.channel.send(str(raw_value), **kwargs))


class InteractionWrapper:
    def __init__(self, raw_interaction):
        self.raw = raw_interaction
        self.user = AuthorWrapper(raw_interaction.user)
        self.guild = raw_interaction.guild
        self.channel = raw_interaction.channel
        data = getattr(raw_interaction, "data", None) or {}
        self.id = data.get("custom_id") if isinstance(data, dict) else None
        self.values = data.get("values", []) if isinstance(data, dict) else []

    def _normalize_value(self, value):
        return value._raw if hasattr(value, "_raw") else value

    async def _send_response(self, value, *, ephemeral=False, view=None, modal=None):
        if discord is None:
            return

        if modal is not None:
            if hasattr(modal, "build"):
                modal.build()
            await self.raw.response.send_modal(modal._raw_modal)
            return

        kwargs = {}
        if view is not None and hasattr(view, "_prepare"):
            view._prepare()
            kwargs["view"] = view._raw_view

        raw_value = self._normalize_value(value)

        if not self.raw.response.is_done():
            if isinstance(raw_value, discord.Embed):
                await self.raw.response.send_message(embed=raw_value, ephemeral=ephemeral, **kwargs)
            else:
                await self.raw.response.send_message(str(raw_value), ephemeral=ephemeral, **kwargs)
        else:
            if isinstance(raw_value, discord.Embed):
                await self.raw.followup.send(embed=raw_value, ephemeral=ephemeral, **kwargs)
            else:
                await self.raw.followup.send(str(raw_value), ephemeral=ephemeral, **kwargs)

    def reply(self, value, ephemeral=False, view=None):
        _fire_and_forget(self._send_response(value, ephemeral=bool(ephemeral), view=view))

    def send(self, value, ephemeral=False, view=None):
        self.reply(value, ephemeral=ephemeral, view=view)

    def followup(self, value, ephemeral=False, view=None):
        if discord is None:
            return
        kwargs = {}
        if view is not None and hasattr(view, "_prepare"):
            view._prepare()
            kwargs["view"] = view._raw_view
        raw_value = self._normalize_value(value)

        async def _send():
            if isinstance(raw_value, discord.Embed):
                await self.raw.followup.send(embed=raw_value, ephemeral=bool(ephemeral), **kwargs)
            else:
                await self.raw.followup.send(str(raw_value), ephemeral=bool(ephemeral), **kwargs)

        _fire_and_forget(_send())

    def defer(self, ephemeral=False, thinking=True):
        if discord is None:
            return

        async def _defer():
            if not self.raw.response.is_done():
                await self.raw.response.defer(ephemeral=bool(ephemeral), thinking=bool(thinking))

        _fire_and_forget(_defer())

    def edit_original(self, value=None, view=None):
        if discord is None:
            return
        kwargs = {}
        if view is not None and hasattr(view, "_prepare"):
            view._prepare()
            kwargs["view"] = view._raw_view
        raw_value = self._normalize_value(value) if value is not None else None

        async def _edit():
            if isinstance(raw_value, discord.Embed):
                await self.raw.edit_original_response(embed=raw_value, **kwargs)
            elif raw_value is None:
                await self.raw.edit_original_response(**kwargs)
            else:
                await self.raw.edit_original_response(content=str(raw_value), **kwargs)

        _fire_and_forget(_edit())

    def delete_original(self):
        if discord is None:
            return
        _fire_and_forget(self.raw.delete_original_response())

    def send_modal(self, modal):
        _fire_and_forget(self._send_response(None, modal=modal))

    def field(self, name):
        return ""


class ContextWrapper:
    def __init__(self, raw_ctx: commands.Context):
        self.raw = raw_ctx
        self.author = AuthorWrapper(raw_ctx.author)
        self.channel = raw_ctx.channel
        self.guild = raw_ctx.guild
        self.args: list[str] = []

    def _normalize_value(self, value):
        return value._raw if hasattr(value, "_raw") else value

    def reply(self, value, view=None):
        if discord is None:
            return
        kwargs = {}
        if view is not None and hasattr(view, "_prepare"):
            view._prepare()
            kwargs["view"] = view._raw_view
        raw_value = self._normalize_value(value)
        if isinstance(raw_value, discord.Embed):
            _fire_and_forget(self.raw.reply(embed=raw_value, **kwargs))
        else:
            _fire_and_forget(self.raw.reply(str(raw_value), **kwargs))

    def send(self, value, view=None):
        if discord is None:
            return
        kwargs = {}
        if view is not None and hasattr(view, "_prepare"):
            view._prepare()
            kwargs["view"] = view._raw_view
        raw_value = self._normalize_value(value)
        if isinstance(raw_value, discord.Embed):
            _fire_and_forget(self.raw.send(embed=raw_value, **kwargs))
        else:
            _fire_and_forget(self.raw.send(str(raw_value), **kwargs))

    def send_modal(self, modal):
        raise LupiDiscordError(
            "Modais so podem ser abertos a partir de uma interaction "
            "(slash command, botao ou select), nao de comando por prefixo."
        )


class LupiView:
    def __init__(self, bot_wrapper=None, timeout=None):
        self._bot_wrapper = bot_wrapper
        self._raw_view = discord.ui.View(timeout=timeout) if discord else None
        self._components = []
        self._prepared = False

    def add(self, component):
        self._components.append(component)
        if self._raw_view is not None and hasattr(component, "_raw_item") and component._raw_item is not None:
            self._raw_view.add_item(component._raw_item)
        self._prepared = False

    def _prepare(self):
        if self._prepared or self._bot_wrapper is None or self._raw_view is None:
            return
        self._bot_wrapper._bind_view_callbacks(self)
        self._prepared = True


class LupiButton:
    STYLE_MAP = {
        "primary": getattr(discord.ButtonStyle, "primary", 1) if discord else 1,
        "secondary": getattr(discord.ButtonStyle, "secondary", 2) if discord else 2,
        "success": getattr(discord.ButtonStyle, "success", 3) if discord else 3,
        "danger": getattr(discord.ButtonStyle, "danger", 4) if discord else 4,
        "link": getattr(discord.ButtonStyle, "link", 5) if discord else 5,
    }

    def __init__(self, label, style="primary", custom_id="button_id", callback_name=None, url=None):
        self.label = str(label)
        self.style = str(style)
        self.id = str(custom_id)
        self.callback_name = callback_name
        self.url = None if url is None else str(url)
        self._callback_bound = False
        if discord is None:
            self._raw_item = None
        else:
            kwargs = {
                "label": self.label,
                "style": self.STYLE_MAP.get(self.style, discord.ButtonStyle.primary),
            }
            if self.style == "link" and self.url is not None:
                kwargs["url"] = self.url
            else:
                kwargs["custom_id"] = self.id
            self._raw_item = discord.ui.Button(**kwargs)


class LupiSelectOption:
    def __init__(self, label, value, description=None):
        self.label = str(label)
        self.value = str(value)
        self.description = None if description is None else str(description)


class LupiSelect:
    def __init__(self, placeholder, custom_id, options, select_type="string"):
        self.placeholder = str(placeholder)
        self.id = str(custom_id)
        self.options = options
        self.select_type = str(select_type)
        self._callback_bound = False
        if discord is None:
            self._raw_item = None
        else:
            if self.select_type == "string":
                raw_options = [discord.SelectOption(label=o.label, value=o.value, description=o.description) for o in options]
                self._raw_item = discord.ui.Select(placeholder=self.placeholder, custom_id=self.id, options=raw_options)
            elif self.select_type == "user":
                self._raw_item = discord.ui.UserSelect(placeholder=self.placeholder, custom_id=self.id)
            elif self.select_type == "role":
                self._raw_item = discord.ui.RoleSelect(placeholder=self.placeholder, custom_id=self.id)
            elif self.select_type == "channel":
                self._raw_item = discord.ui.ChannelSelect(placeholder=self.placeholder, custom_id=self.id)
            elif self.select_type == "mentionable":
                self._raw_item = discord.ui.MentionableSelect(placeholder=self.placeholder, custom_id=self.id)
            else:
                raise LupiDiscordError(f"Tipo de select nao suportado: {self.select_type}")


class LupiTextInput:
    STYLE_MAP = {
        "short": getattr(discord.TextStyle, "short", 1) if discord else 1,
        "paragraph": getattr(discord.TextStyle, "paragraph", 2) if discord else 2,
    }

    def __init__(self, label, custom_id, style="short"):
        self.label = str(label)
        self.id = str(custom_id)
        self.style = str(style)


class LupiModal:
    def __init__(self, runtime, title, custom_id):
        self.runtime = runtime
        self.title = str(title)
        self.id = str(custom_id)
        self.inputs = []
        self._raw_modal = None

    def add(self, text_input):
        self.inputs.append(text_input)

    def build(self):
        if discord is None:
            return None
        runtime = self.runtime
        modal_id = self.id
        inputs = self.inputs

        class _DynamicModal(discord.ui.Modal, title=self.title):
            def __init__(self):
                super().__init__(timeout=None, custom_id=modal_id)
                for inp in inputs:
                    item = discord.ui.TextInput(
                        label=inp.label,
                        custom_id=inp.id,
                        style=LupiTextInput.STYLE_MAP.get(inp.style, discord.TextStyle.short),
                    )
                    self.add_item(item)

            async def on_submit(self, interaction):
                wrapped = InteractionWrapper(interaction)
                wrapped.id = modal_id
                wrapped.field = lambda name: next(
                    (child.value for child in self.children if getattr(child, "custom_id", "") == name),
                    ""
                )
                await runtime._call_lupi_event("on_modal_submit", wrapped)

        self._raw_modal = _DynamicModal()
        return self._raw_modal


class DiscordBotWrapper:
    def __init__(self, interp, token: str, prefix: str = "!"):
        if commands is None or discord is None:
            raise LupiDiscordError("discord.py nao instalado. Rode: lupi install discord.py")
        self.interp = interp
        self.token = token
        self.prefix = prefix
        intents = discord.Intents.default()
        intents.message_content = True
        self.bot = commands.Bot(command_prefix=prefix, intents=intents)
        self.tree = self.bot.tree
        self._pending_status = None

        @self.bot.event
        async def on_ready():
            if self._pending_status:
                activity = discord.Game(name=self._pending_status)
                await self.bot.change_presence(activity=activity)
            try:
                await self.tree.sync()
            except Exception:
                pass
            await self._call_lupi_event("on_ready")

        @self.bot.event
        async def on_message(message):
            if message.author == self.bot.user:
                return
            wrapped = MessageWrapper(message)
            await self._call_lupi_event("on_message", wrapped)
            await self.bot.process_commands(message)

    async def _call_lupi_event(self, name, *args):
        try:
            fn = self.interp.global_env.get(name)
        except Exception:
            return
        result = self._invoke_lupi_callable(fn, list(args))
        if asyncio.iscoroutine(result):
            await result

    def _invoke_lupi_callable(self, fn, args):
        if hasattr(fn, "params"):
            return fn(self.interp, args)
        return fn(*args)

    def _bind_view_callbacks(self, view: LupiView):
        if view._raw_view is None:
            return

        for component in view._components:
            raw_item = getattr(component, "_raw_item", None)
            if raw_item is None or getattr(component, "_callback_bound", False):
                continue

            if isinstance(component, LupiButton) and component.style != "link":
                async def button_callback(interaction, comp=component):
                    wrapped = InteractionWrapper(interaction)
                    wrapped.id = comp.id
                    if comp.callback_name:
                        await self._call_lupi_event(comp.callback_name, wrapped)
                    else:
                        await self._call_lupi_event("on_button", wrapped)
                raw_item.callback = button_callback
                component._callback_bound = True

            elif isinstance(component, LupiSelect):
                async def select_callback(interaction, comp=component):
                    wrapped = InteractionWrapper(interaction)
                    wrapped.id = comp.id
                    data = getattr(interaction, "data", None) or {}
                    wrapped.values = data.get("values", []) if isinstance(data, dict) else []
                    await self._call_lupi_event("on_select", wrapped)
                raw_item.callback = select_callback
                component._callback_bound = True

    def command(self, name, fn):
        cmd_name = str(name)

        @self.bot.command(name=cmd_name)
        async def _wrapped(ctx):
            wrapped = ContextWrapper(ctx)
            raw = ctx.message.content[len(ctx.prefix + ctx.invoked_with):].strip()
            wrapped.args = raw.split() if raw else []
            result = self._invoke_lupi_callable(fn, [wrapped])
            if asyncio.iscoroutine(result):
                await result
        return fn

    def slash(self, name, fn, description="Lupi slash command"):
        cmd_name = str(name)

        @self.tree.command(name=cmd_name, description=str(description))
        async def _wrapped(interaction: discord.Interaction):
            wrapped = InteractionWrapper(interaction)
            result = self._invoke_lupi_callable(fn, [wrapped])
            if asyncio.iscoroutine(result):
                await result
        return fn

    def set_status(self, text):
        self._pending_status = str(text)

    def run(self):
        self.bot.run(self.token)


class DiscordRuntime:
    def __init__(self, interp):
        self.interp = interp
        self._current_bot = None

    async def _call_lupi_event(self, name, *args):
        if self._current_bot is None:
            return
        await self._current_bot._call_lupi_event(name, *args)

    def bot(self, token, prefix="!"):
        self._current_bot = DiscordBotWrapper(self.interp, str(token), str(prefix))
        return self._current_bot

    def embed(self, title, description="", color="yellow"):
        if discord is None:
            raise LupiDiscordError("discord.py nao instalado. Rode: lupi install discord.py")
        color_map = {
            "yellow": discord.Color.gold(),
            "red": discord.Color.red(),
            "green": discord.Color.green(),
            "blue": discord.Color.blue(),
            "magenta": discord.Color.magenta(),
            "cyan": discord.Color.teal(),
            "white": discord.Color.light_grey(),
            "black": discord.Color.dark_grey(),
        }
        emb = discord.Embed(
            title=str(title),
            description=str(description),
            color=color_map.get(str(color).lower(), discord.Color.gold()),
        )
        return LupiEmbed(emb)

    def view(self, timeout=None):
        return LupiView(bot_wrapper=self._current_bot, timeout=timeout)

    def button(self, label, style="primary", custom_id="button_id", callback_name=None, url=None):
        return LupiButton(label, style, custom_id, callback_name, url)

    def option(self, label, value, description=None):
        return LupiSelectOption(label, value, description)

    def select(self, placeholder, custom_id, options):
        return LupiSelect(placeholder, custom_id, options, "string")

    def user_select(self, placeholder, custom_id):
        return LupiSelect(placeholder, custom_id, [], "user")

    def role_select(self, placeholder, custom_id):
        return LupiSelect(placeholder, custom_id, [], "role")

    def channel_select(self, placeholder, custom_id):
        return LupiSelect(placeholder, custom_id, [], "channel")

    def mentionable_select(self, placeholder, custom_id):
        return LupiSelect(placeholder, custom_id, [], "mentionable")

    def modal(self, title, custom_id):
        return LupiModal(self, title, custom_id)

    def text_input(self, label, custom_id, style="short"):
        return LupiTextInput(label, custom_id, style)
