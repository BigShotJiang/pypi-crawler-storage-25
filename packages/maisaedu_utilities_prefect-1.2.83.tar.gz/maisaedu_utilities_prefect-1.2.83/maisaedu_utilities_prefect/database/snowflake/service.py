from cryptography.hazmat.primitives.serialization import (
    load_der_private_key,
    Encoding,
    PrivateFormat,
    NoEncryption,
)
import logging
import snowflake.connector
from prefect import get_run_logger
from prefect.exceptions import MissingContextError


def _get_logger():
    try:
        return get_run_logger()
    except MissingContextError:
        return logging.getLogger(__name__)


class SnowflakeService:
    def __init__(
        self,
        account: str,
        user: str,
        private_key_bytes: bytes,
        role: str | None = None,
        warehouse: str | None = None,
    ):
        self._account = account
        self._user = user
        self._role = role
        self._warehouse = warehouse
        self._private_key = self._build_private_key(private_key_bytes)

    @staticmethod
    def _build_private_key(raw_bytes: bytes) -> bytes:
        private_key = load_der_private_key(raw_bytes, password=None)
        return private_key.private_bytes(
            encoding=Encoding.DER,
            format=PrivateFormat.PKCS8,
            encryption_algorithm=NoEncryption(),
        )

    def set_role(self, role: str) -> None:
        self._role = role

    def set_warehouse(self, warehouse: str) -> None:
        self._warehouse = warehouse

    def _connect(self) -> snowflake.connector.SnowflakeConnection:
        params = dict(
            account=self._account,
            user=self._user,
            private_key=self._private_key,
        )
        if self._role is not None:
            params["role"] = self._role
        if self._warehouse is not None:
            params["warehouse"] = self._warehouse
        return snowflake.connector.connect(**params)

    def test_connectivity(self) -> str:
        """Runs SELECT CURRENT_VERSION(), logs connection details and returns the version."""
        logger = _get_logger()
        logger.info(
            f"Snowflake connection details — "
            f"account: {self._account} | "
            f"user: {self._user} | "
            f"role: {self._role or 'default'} | "
            f"warehouse: {self._warehouse or 'default'}"
        )
        conn = self._connect()
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT CURRENT_VERSION()")
            version = cursor.fetchone()[0]
            logger.info(f"Snowflake connection successful. Version: {version}")
            return version
        finally:
            conn.close()

    def execute_query(self, query: str) -> list[tuple]:
        """Executes an arbitrary query and returns all rows."""
        conn = self._connect()
        try:
            cursor = conn.cursor()
            cursor.execute(query)
            return cursor.fetchall()
        finally:
            conn.close()
