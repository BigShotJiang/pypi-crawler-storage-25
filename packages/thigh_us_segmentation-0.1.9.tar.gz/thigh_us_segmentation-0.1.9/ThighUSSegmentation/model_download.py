import os
from pathlib import Path
import zipfile
import requests


ZENODO_RECORD_ID = "19914473"
ZENODO_FILENAME = "models.zip"
ENV_MODELS_ROOT = "THIGH_US_MODELS"


def get_default_models_root() -> Path:
    """
    Carpeta por defecto para guardar los pesos.

    Prioridad:
    1. Variable de entorno THIGH_US_MODELS
    2. ~/.thigh_us_segmentation/models
    """
    return Path(
        os.environ.get(
            ENV_MODELS_ROOT,
            Path.home() / ".thigh_us_segmentation" / "models",
        )
    )


def model_is_complete(model_folder: Path) -> bool:
    required = [
        model_folder / "dataset.json",
        model_folder / "plans.json",
    ]

    for i in range(5):
        required.append(model_folder / f"fold_{i}" / "checkpoint_best.pth")

    return all(p.exists() for p in required)


def find_model_subfolder(models_root: str | Path) -> Path:
    models_root = Path(models_root)

    candidates = list(models_root.glob("Dataset*/nnUNetTrainer*"))

    for candidate in candidates:
        if model_is_complete(candidate):
            return candidate

    raise FileNotFoundError(
        f"No se encontró un modelo completo dentro de:\n{models_root}"
    )


def get_zenodo_file_url(
    record_id: str = ZENODO_RECORD_ID,
    filename: str = ZENODO_FILENAME,
) -> str:
    api_url = f"https://zenodo.org/api/records/{record_id}"

    response = requests.get(api_url, timeout=60)
    response.raise_for_status()

    data = response.json()

    for file_info in data["files"]:
        if file_info["key"] == filename:
            return file_info["links"]["self"]

    raise FileNotFoundError(
        f"No se encontró {filename} en Zenodo record {record_id}"
    )


def download_file(url: str, output_path: Path) -> None:
    with requests.get(url, stream=True, timeout=60) as response:
        response.raise_for_status()

        with open(output_path, "wb") as f:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)


def download_and_extract_model(models_root: str | Path) -> None:
    models_root = Path(models_root)
    models_root.mkdir(parents=True, exist_ok=True)

    zip_path = models_root / ZENODO_FILENAME

    if zip_path.exists():
        zip_path.unlink()

    file_url = get_zenodo_file_url()

    print(f"Descargando modelo desde Zenodo:\n{file_url}")
    download_file(file_url, zip_path)

    print(f"Descomprimiendo modelo en:\n{models_root}")
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(models_root)

    zip_path.unlink()


def ensure_model_exists(models_root: str | Path | None = None) -> str:
    """
    Devuelve la carpeta del modelo nnU-Net.

    Prioridad:
    1. models_root pasado como argumento
    2. THIGH_US_MODELS
    3. ~/.thigh_us_segmentation/models

    Si el modelo no está completo, lo descarga automáticamente.
    """
    if models_root is None:
        models_root = get_default_models_root()

    models_root = Path(models_root)
    models_root.mkdir(parents=True, exist_ok=True)

    try:
        return str(find_model_subfolder(models_root))
    except FileNotFoundError:
        download_and_extract_model(models_root)
        return str(find_model_subfolder(models_root))