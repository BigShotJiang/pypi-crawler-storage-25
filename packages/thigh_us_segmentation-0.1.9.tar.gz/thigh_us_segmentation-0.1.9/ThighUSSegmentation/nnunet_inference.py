import os
import shutil
import subprocess
from pathlib import Path
import logging

import SimpleITK as sitk


logger = logging.getLogger(__name__)


def check_nnunet_installed() -> None:
    try:
        import nnunetv2  # noqa: F401
    except ImportError as e:
        raise RuntimeError(
            "nnunetv2 no está instalado en este entorno.\n"
            "Instala la librería con:\n"
            "pip install ThighUSSegmentation\n"
            "o instala nnunetv2 manualmente:\n"
            "pip install nnunetv2==2.6.4"
        ) from e


def get_available_device(preferred: str | None = None) -> str:
    if preferred in {"cpu", "cuda"}:
        return preferred

    try:
        import torch

        if torch.cuda.is_available():
            return "cuda"
    except ImportError:
        pass

    return "cpu"


def find_nnunet_predict_executable() -> Path:
    exe_name = "nnUNetv2_predict_from_modelfolder"

    found = shutil.which(exe_name)
    if found:
        return Path(found)

    found_exe = shutil.which(exe_name + ".exe")
    if found_exe:
        return Path(found_exe)

    raise FileNotFoundError(
        "No se encontró nnUNetv2_predict_from_modelfolder en el entorno actual. "
        "Asegúrate de que nnunetv2 está instalado correctamente."
    )


def run_inference_command(cmd, env, log_lines):
    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        env=env,
    )

    if process.stdout is not None:
        for line in process.stdout:
            print(line, end="")
            log_lines.append(line.rstrip("\n"))

    return process.wait()


def run_nnunet_inference(
    input_image: str,
    output_root: str,
    model_folder: str,
    case_id: str = "case001",
    device: str | None = None,
    keep_temp_files: bool = False,
    log_to_file: bool = True,
) -> Path:
    """
    Ejecuta inferencia nnU-Net v2 usando siempre checkpoint_best.pth.
    """

    check_nnunet_installed()

    input_image = Path(input_image)
    output_root = Path(output_root)
    model_folder = Path(model_folder)

    if not input_image.exists():
        raise FileNotFoundError(f"No existe la imagen: {input_image}")

    if input_image.suffix.lower() != ".mha":
        raise ValueError(
            f"La imagen de entrada para inferencia debe ser .mha. "
            f"Recibido: {input_image.name}"
        )

    if not model_folder.exists():
        raise FileNotFoundError(f"No existe la carpeta del modelo: {model_folder}")

    required_files = [
        model_folder / "dataset.json",
        model_folder / "plans.json",
    ]

    for file in required_files:
        if not file.exists():
            raise FileNotFoundError(f"Falta archivo obligatorio del modelo: {file}")

    checkpoint_name = "checkpoint_best.pth"
    device = get_available_device(device)

    case_output_folder = output_root / case_id
    case_output_folder.mkdir(parents=True, exist_ok=True)

    temp_input = case_output_folder / "_tmp_input"

    if temp_input.exists():
        shutil.rmtree(temp_input)

    temp_input.mkdir(parents=True, exist_ok=True)

    temp_file = temp_input / f"{case_id}_0000.mha"

    img = sitk.ReadImage(str(input_image))
    sitk.WriteImage(img, str(temp_file))

    env = os.environ.copy()
    env.pop("PYTHONHOME", None)
    env.pop("PYTHONPATH", None)
    env.pop("PYTHONNOUSERSITE", None)

    nnunet_exe = find_nnunet_predict_executable()

    log_lines = [
        "=== nnU-Net inference ===",
        f"Input image: {input_image}",
        f"Temporary input: {temp_file}",
        f"Model folder: {model_folder}",
        f"Output folder: {case_output_folder}",
        f"Device inicial: {device}",
        f"Checkpoint: {checkpoint_name}",
        f"nnU-Net executable: {nnunet_exe}",
    ]

    cmd = [
        str(nnunet_exe),
        "-i",
        str(temp_input),
        "-o",
        str(case_output_folder),
        "-m",
        str(model_folder),
        "-device",
        device,
        "-chk",
        checkpoint_name,
    ]

    log_lines.append("Command: " + " ".join(cmd))

    return_code = run_inference_command(cmd, env, log_lines)

    if return_code != 0 and device == "cuda":
        log_lines.append("Fallo en GPU. Reintentando en CPU.")

        cmd_cpu = cmd.copy()
        cmd_cpu[cmd_cpu.index("-device") + 1] = "cpu"

        return_code = run_inference_command(cmd_cpu, env, log_lines)

        if return_code != 0:
            raise RuntimeError("Fallo también en CPU.\n" + "\n".join(log_lines))

    elif return_code != 0:
        raise RuntimeError("Error en inferencia.\n" + "\n".join(log_lines))

    output_seg = case_output_folder / f"{case_id}.mha"

    if not output_seg.exists():
        raise FileNotFoundError(f"No se generó segmentación esperada: {output_seg}")

    final_seg = case_output_folder / "input_labelmap.mha"

    if final_seg.exists():
        final_seg.unlink()

    shutil.move(str(output_seg), str(final_seg))

    if log_to_file:
        log_path = case_output_folder / "inference_log.txt"
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("\n".join(log_lines))

    if temp_input.exists() and not keep_temp_files:
        shutil.rmtree(temp_input, ignore_errors=True)

    return final_seg