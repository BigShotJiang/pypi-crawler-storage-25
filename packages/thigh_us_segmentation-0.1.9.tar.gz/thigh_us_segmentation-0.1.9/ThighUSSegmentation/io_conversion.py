from pathlib import Path
import shutil
import logging

import SimpleITK as sitk


logger = logging.getLogger(__name__)


def convert_to_mha(
    input_path: str,
    output_dir: str,
    output_filename: str = "image_converted.mha",
) -> str:
    """
    Convierte una imagen de entrada a .mha y la guarda dentro de output_dir.

    Soporta:
    - .mha
    - .nii
    - .nii.gz
    - .dcm
    - carpeta DICOM

    La salida será:
        output_dir / image_converted.mha
    """

    input_path = Path(input_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if not input_path.exists():
        raise FileNotFoundError(f"No existe la entrada: {input_path}")

    if not output_filename.endswith(".mha"):
        raise ValueError("output_filename debe terminar en .mha")

    output_path = output_dir / output_filename

    if output_path.exists():
        output_path.unlink()

    if input_path.is_file() and input_path.suffix.lower() == ".mha":
        shutil.copy2(input_path, output_path)
        return str(output_path)

    if input_path.is_file():
        logger.info(f"Convirtiendo archivo a .mha: {input_path}")
        img = sitk.ReadImage(str(input_path))
        sitk.WriteImage(img, str(output_path))
        return str(output_path)

    if input_path.is_dir():
        logger.info(f"Leyendo carpeta DICOM: {input_path}")

        reader = sitk.ImageSeriesReader()
        series_ids = reader.GetGDCMSeriesIDs(str(input_path))

        if not series_ids:
            raise ValueError(f"No se encontró ninguna serie DICOM en: {input_path}")

        if len(series_ids) > 1:
            logger.warning(
                f"Se encontraron {len(series_ids)} series DICOM. "
                f"Se usará la primera: {series_ids[0]}"
            )

        series_files = reader.GetGDCMSeriesFileNames(
            str(input_path),
            series_ids[0],
        )

        reader.SetFileNames(series_files)
        img = reader.Execute()
        sitk.WriteImage(img, str(output_path))

        return str(output_path)

    raise ValueError(f"Formato no soportado: {input_path}")