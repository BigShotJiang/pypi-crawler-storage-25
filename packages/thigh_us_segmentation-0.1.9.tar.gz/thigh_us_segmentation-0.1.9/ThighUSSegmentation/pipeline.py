from pathlib import Path

from .io_conversion import convert_to_mha
from .model_download import ensure_model_exists
from .preprocessing import preprocess_active_region
from .nnunet_inference import run_nnunet_inference
from .distances import extract_distances_dataframe


def run_full_pipeline(
    input_image_path: str,
    output_root: str,
    case_id: str = "case001",
    device: str | None = None,
    models_root: str | None = None,
    rectus_label: int = 3,
    epi_label: int = 1,
    femur_label: int = 2,
    keep_temp_files: bool = False,
):
    """
    Ejecuta el pipeline completo de segmentación y cálculo de distancias.

    Pasos:
    1. Conversión de la imagen de entrada a .mha.
    2. Preprocesado de la región activa.
    3. Inferencia con nnU-Net.
    4. Cálculo de distancias anatómicas.
    5. Exportación de puntos/markups para Slicer.
    """

    output_root = Path(output_root)
    case_dir = output_root / case_id
    case_dir.mkdir(parents=True, exist_ok=True)

    # Localizar o descargar automáticamente el modelo
    model_folder = ensure_model_exists(models_root=models_root)

    # Convertir imagen a .mha
    converted_image = convert_to_mha(
        input_path=input_image_path,
        output_dir=str(case_dir),
        output_filename="image_converted.mha",
    )

    # Preprocesamiento
    preprocessed_image = case_dir / "image_preprocessed.mha"

    preprocess_active_region(
        input_image_path=str(converted_image),
        output_image_path=str(preprocessed_image),
    )

    # Inferencia de nnU-Net
    segmentation_path = run_nnunet_inference(
        input_image=str(preprocessed_image),
        output_root=str(output_root),
        model_folder=model_folder,
        case_id=case_id,
        device=device,
        keep_temp_files=keep_temp_files,
    )

    # Cálculo de distancias y generación de markups
    markups_dir = case_dir / "markups"

    df_distances, mrk_paths = extract_distances_dataframe(
        image_path=str(preprocessed_image),
        mask_path=str(segmentation_path),
        output_mrk_json_path=str(markups_dir),
        case_id=case_id,
        epi_label=epi_label,
        femur_label=femur_label,
        rf_label=rectus_label,
    )

    return {
        "case_id": case_id,
        "case_dir": case_dir,
        "model_folder": Path(model_folder),
        "converted_image": Path(converted_image),
        "preprocessed_image": preprocessed_image,
        "segmentation_path": Path(segmentation_path),
        "markups_dir": markups_dir,
        "mrk_paths": mrk_paths,
        "df_distances": df_distances,
        "df_results": df_distances,
    }