from pathlib import Path
import logging

import SimpleITK as sitk
import numpy as np
import cv2 as cv


logger = logging.getLogger(__name__)


def ensure_3d_image(img: sitk.Image) -> sitk.Image:
    if img.GetDimension() == 4:
        return sitk.Extract(
            img,
            size=img.GetSize()[:3] + (0,),
            index=(0, 0, 0, 0),
        )

    if img.GetDimension() != 3:
        raise ValueError(
            f"Se esperaba una imagen 3D o 4D, llegó {img.GetDimension()}D"
        )

    return img


def extract_active_bbox_from_volume(
    img_sitk: sitk.Image,
    dilate_kernel_size: int = 6,
    dilate_iter: int = 1,
    crop_margin: int = 20,
):
    arr = sitk.GetArrayFromImage(img_sitk)

    if arr.ndim != 3:
        raise ValueError(f"Se esperaba 3D, llegó {arr.ndim}D")

    slice0 = arr[0, :, :]
    binary = (slice0 > 0).astype(np.uint8)

    if binary.sum() == 0:
        return None

    num_labels, labels = cv.connectedComponents(binary)

    if num_labels <= 1:
        return None

    unique, counts = np.unique(labels, return_counts=True)
    label_sizes = dict(zip(unique.tolist(), counts.tolist()))
    label_sizes.pop(0, None)

    if not label_sizes:
        return None

    largest_label = max(label_sizes, key=label_sizes.get)
    active_mask = (labels == largest_label).astype(np.uint8) * 255

    kernel = np.ones((dilate_kernel_size, dilate_kernel_size), np.uint8)
    dilated = cv.dilate(active_mask, kernel, iterations=dilate_iter)

    x, y, w, h = cv.boundingRect(dilated)

    height, width = slice0.shape

    x0 = max(0, x - crop_margin)
    y0 = max(0, y - crop_margin)
    x1 = min(width, x + w + crop_margin)
    y1 = min(height, y + h + crop_margin)

    if x1 <= x0 or y1 <= y0:
        return None

    return x0, y0, x1, y1


def crop_sitk_xy(img: sitk.Image, bbox_xyxy) -> sitk.Image:
    x0, y0, x1, y1 = bbox_xyxy
    size_x, size_y, size_z = img.GetSize()

    x0 = int(np.clip(x0, 0, size_x))
    x1 = int(np.clip(x1, 0, size_x))
    y0 = int(np.clip(y0, 0, size_y))
    y1 = int(np.clip(y1, 0, size_y))

    if x1 <= x0 or y1 <= y0:
        raise ValueError("BBox inválido tras clamp.")

    roi_size = [x1 - x0, y1 - y0, size_z]
    roi_index = [x0, y0, 0]

    return sitk.RegionOfInterest(img, roi_size, roi_index)


def resample_to_reference(
    moving: sitk.Image,
    reference: sitk.Image,
    is_mask: bool = False,
) -> sitk.Image:
    interpolator = sitk.sitkNearestNeighbor if is_mask else sitk.sitkLinear
    output_pixel_type = sitk.sitkUInt8 if is_mask else moving.GetPixelID()

    return sitk.Resample(
        moving,
        reference,
        sitk.Transform(),
        interpolator,
        0,
        output_pixel_type,
    )


def preprocess_active_region(
    input_image_path: str,
    output_image_path: str,
    dilate_kernel_size: int = 6,
    dilate_iter: int = 1,
    crop_margin: int = 20,
    allow_full_image: bool = True,
) -> str:
    """
    Preprocesa una imagen de ultrasonido ya convertida a .mha.

    Entrada recomendada:
        image_converted.mha

    Salida recomendada:
        image_preprocessed.mha
    """

    input_path = Path(input_image_path)
    output_path = Path(output_image_path)

    if not input_path.exists():
        raise FileNotFoundError(f"No existe la imagen de entrada: {input_path}")

    if input_path.suffix.lower() != ".mha":
        raise ValueError(
            f"La imagen de entrada debe estar en formato .mha. "
            f"Recibido: {input_path.name}"
        )

    if output_path.suffix.lower() != ".mha":
        raise ValueError(
            f"La imagen preprocesada debe guardarse como .mha. "
            f"Recibido: {output_path.name}"
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)

    logger.info(f"Leyendo imagen: {input_path}")

    img = sitk.ReadImage(str(input_path))
    img = ensure_3d_image(img)

    bbox = extract_active_bbox_from_volume(
        img,
        dilate_kernel_size=dilate_kernel_size,
        dilate_iter=dilate_iter,
        crop_margin=crop_margin,
    )

    if bbox is None:
        if not allow_full_image:
            raise ValueError("No se detectó zona activa en la imagen.")

        logger.warning("No se detectó zona activa. Se usará la imagen completa.")

        size_x, size_y, _ = img.GetSize()
        bbox = (0, 0, size_x, size_y)

    logger.info(f"BBox detectada: {bbox}")

    img_crop = crop_sitk_xy(img, bbox)

    img_proc = resample_to_reference(
        moving=img_crop,
        reference=img,
        is_mask=False,
    )

    img_proc = sitk.Cast(img_proc, sitk.sitkFloat32)
    img_proc.CopyInformation(img)

    if output_path.exists():
        output_path.unlink()

    logger.info(f"Guardando imagen preprocesada en: {output_path}")

    sitk.WriteImage(img_proc, str(output_path))

    return str(output_path)