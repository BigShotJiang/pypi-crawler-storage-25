# ThighUSSegmentation

Python library for automatic thigh ultrasound segmentation and analysis using nnU-Net.

## Features

- Automatic image conversion to `.mha`
- Preprocessing (active region detection)
- nnU-Net inference
- Muscle thickness computation
- Export of anatomical landmarks (`.mrk.json`)
- Automatic model download from Zenodo

## Installation

```bash
pip install thigh-us-segmentation
```

## Usage

```python
from ThighUSSegmentation import run_full_pipeline

result = run_full_pipeline(
    input_image_path="image.dcm",
    output_root="outputs",
    case_id = "case001"
)

print(result["df_results"])

# OR
result = run_full_pipeline(
    input_image_path="image.mha",
    output_root="outputs",
    models_root="D:/my_models", #You can also specify your own model path.
)
```

## Output
```text
outputs/
└── case001/
    ├── image_converted.mha
    ├── image_preprocessed.mha
    ├── case001_labelmap.mha
    ├──  inference_log.txt
    └── markups/
        ├── case001_epidermis.mrk.json
        ├── case001_fascia_lata.mrk.json
        ├── case001_aponeurosis.mrk.json
        ├── case001_femur.mrk.json
        └── case001_central_line.mrk.json
    
```

## Returned Results

The pipeline returns a dictionary:

{
    "case_id": str,
    "segmentation_path": str,
    "mrk_paths": dict,
    "df_distances": pd.DataFrame,
    "df_results": pd.DataFrame
}

## Model

The pretrained nnU-Net model is automatically downloaded from Zenodo on first use.
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.19914473.svg)](https://doi.org/10.5281/zenodo.19914473)

Expected strucutre:
```text
Dataset001_ThighUS/
└── nnUNetTrainer__nnUNetPlans__2d/
    ├── dataset.json
    ├── plans.json
    ├── fold_0/
    ├── fold_1/
    ├── fold_2/
    ├── fold_3/
    └── fold_4/
```

## Requirements

· Python >= 3.10, < 3.11
· SimpleITK
· OpenCV
· NumPy / SciPy / Pandas
· Matplotlib
· nnU-Net v2

## Citation

If you use this work, please cite:

Isensee et al., nnU-Net: a self-configuring method for deep learning-based biomedical image segmentation. Nature Methods (2021)

Mara Concepción Alavarez. (2026).
Thigh Ultrasound Segmentation Model (nnU-Net).
Zenodo. https://doi.org/10.5281/zenodo.19914473

## License

This project uses the following licenses:
· Code: MIT License (or the one you choose)
· Model weights (Zenodo): CC-BY 4.0 

