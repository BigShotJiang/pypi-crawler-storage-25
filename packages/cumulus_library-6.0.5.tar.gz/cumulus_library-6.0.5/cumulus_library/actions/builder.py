"""Handles the creation of new tables"""

import contextlib
import datetime
import importlib.util
import inspect
import pathlib
import re
import sys
import tomllib
import zipfile

import rich
import sqlglot
from rich import progress

from cumulus_library import (
    BaseTableBuilder,
    base_utils,
    const,
    databases,
    enums,
    errors,
    log_utils,
    study_manifest,
)
from cumulus_library.builders import (
    counts_builder,
    file_upload_builder,
    protected_table_builder,
    psm_builder,
    valueset_builder,
)
from cumulus_library.template_sql import base_templates

######### public functions #########


def build_study(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    *,
    db_parser: databases.DatabaseParser = None,
    continue_from: str | None = None,
    file_list: list | None = None,
    prepare: bool = False,
    data_path: pathlib.Path | None = None,
) -> None:
    """Creates tables in the schema by iterating through the stages in the specified build type

    :param config: a StudyConfig object
    :param manifest: a StudyManifest object
    :keyword db_parser: a parser for the target database
    :keyword continue_from: Name of a file to resume table creation from
    :keyword file_list: If provided, a list of files to build; otherwise pulled from manifest
    :keyword prepare: If true, will render query instead of executing
    :keyword data_path: If prepare is true, the path to write rendered data to
    """
    if prepare:
        _check_if_preparable(manifest.get_study_prefix())
    if file_list is None:
        file_list = manifest.get_file_list(config.stage, continue_from)
    if prepare:
        data_dir = data_path / manifest.get_study_prefix()
        for file in data_dir.glob("*"):
            if file.is_file():  # pragma: no cover
                file.unlink()
    stage = manifest.get_stage(config.stage)
    if len(stage) == 0:
        raise errors.StudyManifestParsingError(
            f"{config.stage} not found in the study manifest. "
            f"Available stages: {', '.join(manifest.get_stages())}"
        )

    for action in stage:
        if not action.get("type", "").startswith("build:"):
            continue
        query_count = 0
        if action.get("type") == enums.ManifestActions.PARALLEL.value:
            parallel = True
        else:
            parallel = False
        queries = []
        explicit_serial_queries = []
        for file in action["files"]:
            if file not in file_list:
                continue
            if file.endswith(".py"):
                b_queries, parallel_allowed = _run_builder(
                    config=config,
                    manifest=manifest,
                    filename=file,
                    db_parser=db_parser,
                    data_path=data_path,
                    prepare=prepare,
                    parallel=parallel,
                    query_count=query_count,
                )
                if parallel_allowed:
                    queries += b_queries
                else:
                    # If you're running in explicit serial mode, you can skip the parallel
                    # collector.
                    # Explicit serial queries are not actually used, but this is kept
                    # here as a debugging convenience if you ever need to look at
                    # the total number of manually executed queries.
                    explicit_serial_queries += b_queries
            elif file.endswith(".toml") or file.endswith(".workflow"):
                w_queries, parallel_allowed = _run_workflow(
                    config=config,
                    manifest=manifest,
                    filename=file,
                    data_path=data_path,
                    prepare=prepare,
                    parallel=parallel,
                    query_count=query_count,
                )
                if parallel_allowed:
                    queries = queries + w_queries
            elif file.endswith(".sql"):
                queries = queries + _run_raw_queries(
                    config=config,
                    manifest=manifest,
                    label=action.get("label"),
                    filename=file,
                    data_path=data_path,
                    prepare=prepare,
                    parallel=parallel,
                    query_count=query_count,
                )
            else:
                raise errors.StudyManifestParsingError(f"Unexpected filetype in manifest: {file}")
            for query in queries:
                _check_query_for_errors(config, manifest, query, file)
        if parallel:
            query_count += len(queries)
            if query_count > 0:
                queries = _update_build_source_table(config, manifest, queries)
                with base_utils.get_progress_bar() as progress_bar:
                    task = progress_bar.add_task(
                        f"Building {action.get('label', '')} tables...",
                        total=query_count,
                        visible=not config.verbose,
                    )
                    config.db.parallel_execute(
                        queries=queries,
                        verbose=config.verbose,
                        progress_bar=progress_bar,
                        task=task,
                    )
    if prepare:
        with zipfile.ZipFile(
            f"{data_path}/{manifest.get_study_prefix()}.zip", "w", zipfile.ZIP_DEFLATED
        ) as z:
            for file in data_dir.iterdir():
                z.write(file, file.relative_to(data_dir))
    else:
        log_ref_summary(config, manifest)


def build_matching_files(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    *,
    builder: str | None,
    db_parser: databases.DatabaseParser = None,
    prepare: bool,
    data_path: pathlib.Path,
):
    """targets all table builders matching a target string for running

    :param config: a StudyConfig object
    :param manifest: a StudyManifest object
    :keyword builder: filename of a module implementing a TableBuilder
    :keyword db_parser: an object implementing DatabaseParser for the target database
    :keyword prepare: If true, will render query instead of executing
    :keyword data_path: If prepare is true, the path to write rendered data to
    """
    if prepare:
        _check_if_preparable(manifest.get_study_prefix())  # pragma: no cover
    all_generators = manifest.get_all_generators()
    matches = []
    if not builder:  # pragma: no cover
        matches = all_generators
    else:
        for file in all_generators:
            if file.find(builder) != -1:
                matches.append(file)
    if len(matches) == 0:
        rich.print(f"No builders matching {builder} found - is it in your study manifest?")
        sys.exit()
    build_study(
        config,
        manifest,
        db_parser=db_parser,
        file_list=matches,
        prepare=prepare,
        data_path=data_path,
    )


def run_protected_table_builder(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
) -> None:
    """Creates protected tables for persisting selected data across runs

    :param config: a StudyConfig object
    :param manifest: a StudyManifest object
    """
    ptb = protected_table_builder.ProtectedTableBuilder()
    ptb.execute_queries(
        config=config,
        manifest=manifest,
    )


######### private helper functions #########


def _update_build_source_table(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    queries: list[str],
) -> list[str]:
    table_names = base_utils.get_viewtable_names_from_create_queries(config, queries)
    # it's possible to get a list of queries that contains no CREATE statements
    if len(table_names) > 0:
        # Otherwise, let's add new tables to the study build source tables.
        prefix = manifest.get_schema_aware_prefix_with_seperator()
        queries.insert(
            0,
            base_templates.get_insert_into_query(
                schema=config.schema,
                table_name=(f"{prefix}{enums.ProtectedTables.BUILD_SOURCE.value}"),
                table_cols=const.BUILD_SOURCE_COLS,
                dataset=[[config.stage, t[0], t[1]] for t in table_names],
            ),
        )
    return queries


def _check_if_preparable(prefix):
    # This list should include any study which requires interrogating the database to
    # find if data is available to query (outside of a toml-driven workflow),
    # which isn't doable as a distributed query
    if prefix in ["core", "discovery", "data_metrics", "example_nlp"]:
        sys.exit(
            f"Study '{prefix}'' does not support prepare mode. It must be run "
            "directly against a target database."
        )


def _execute_build_queries(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    *,
    cursor: databases.DatabaseCursor,
    queries: list,
    filename: str,
    progress: progress.Progress,
    task: progress.TaskID,
) -> None:
    """Handler for executing create table queries and displaying console output.

    :param config: A StudyConfig object
    :param manifest: a StudyManifest object
    :keyword cursor: A DatabaseCursor object
    :keyword queries: a list of queries read from files in sql_config.file_names
    :keyword filename: the filename the queries were sourced from
    :keyword progress: a rich progress bar renderer
    :keyword task: a TaskID for a given progress bar
    """
    for query in queries:
        _check_query_for_errors(config, manifest, query, filename)
        try:
            with base_utils.query_console_output(config.verbose, query, progress, task):
                cursor.execute(query)

        except Exception as e:  # pragma: no cover
            _query_error(
                config,
                manifest,
                query,
                filename,
                "You can debug issues with this query using `sqlfluff lint`, "
                "or by executing the query directly against the database.\n"
                f"Error: {e}",
            )


def _render_output(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    outputs: list,
    data_path: pathlib.Path,
    filename: str,
    count: int,
    *,
    is_toml: bool = False,
):
    if is_toml:
        suffix = "toml"
    else:
        suffix = "sql"
    for index, output in enumerate(outputs):
        if is_toml:
            name = "config"
        else:
            name = str(sqlglot.parse_one(output, dialect=config.db.db_type).find(sqlglot.exp.Table))
        new_filename = f"{config.stage}.{filename.rsplit('.', 1)[0]}.{index:02d}.{name}.{suffix}"
        file_path = data_path / f"{manifest.get_study_prefix()}/{new_filename}"

        file_path.parent.mkdir(exist_ok=True, parents=True)
        with open(file_path, "w", encoding="UTF-8") as f:
            f.write(output)


@contextlib.contextmanager
def _temporary_sys_path(add: pathlib.Path) -> None:
    orig_path = list(sys.path)
    try:
        sys.path.insert(0, str(add))
        yield
    finally:
        sys.path = orig_path


######### handlers for running different file types #########


def _run_builder(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    *,
    filename: str,
    db_parser: databases.DatabaseParser = None,
    write_reference_sql: bool = False,
    doc_str: str | None = None,
    prepare: bool = False,
    parallel: bool = False,
    data_path: pathlib.Path,
    query_count: int | None = None,
) -> tuple[list[str], bool]:
    """Loads a table builder from a file.

    :param config: a StudyConfig object
    :param manifest: a StudyManifest object
    :keyword filename: filename of a module implementing a TableBuilder
    :keyword db_parser: an object implementing DatabaseParser for the target database
    :keyword write_reference_sql: if true, writes sql to disk inside a study's directory
    :keyword doc_str: A string to insert between queries written to disk
    :keyword prepare: If true, will render query instead of executing
    :keyword parallel: If true, will execute queries in parallel
    :keyword data_path: If prepare is true, the path to write rendered data to
    :keyword query_count: if prepare is true, the number of queries already rendered
    :returns: a list of queries, a boolean indicating if parallel runs are allowed
    """

    # Since we have to support arbitrary user-defined python files here, we
    # jump through some importlib hoops to import the module directly from
    # a source file defined in the manifest.
    spec = importlib.util.spec_from_file_location(
        "table_builder", f"{manifest._study_path}/{filename}"
    )
    table_builder_module = importlib.util.module_from_spec(spec)
    sys.modules["table_builder"] = table_builder_module
    # Inject the study dir into sys.path so that builders can import
    # from surrounding utility code, even if the study isn't installed.
    # (i.e. you're working from a git checkout and do something like `-s .`)
    with _temporary_sys_path(manifest._study_path.parent):
        spec.loader.exec_module(table_builder_module)

    # We're going to find all subclasses of BaseTableBuild in this file.
    # Since BaseTableBuilder itself is a valid subclass of BaseTableBuilder,
    # we'll detect and skip it. If we don't find any subclasses,
    # we'll punt.
    table_builder_subclasses = []
    for _, cls_obj in inspect.getmembers(table_builder_module, inspect.isclass):
        if issubclass(cls_obj, BaseTableBuilder) and cls_obj != BaseTableBuilder:
            table_builder_subclasses.append(cls_obj)

    if len(table_builder_subclasses) == 0:
        raise errors.StudyManifestParsingError(
            f"Error loading {manifest._study_path}{filename}\n"
            "Custom builders must extend the BaseTableBuilder class."
        )
    # Remove instances of intermediate classes, if present (usually not)
    table_builder_subclasses = list(
        filter(lambda x: x.__name__ != "CountsBuilder", table_builder_subclasses)
    )

    # We'll get the subclass, initialize it, run the executor code, and then
    # remove it so it doesn't interfere with the next python module to
    # execute, since the subclass would otherwise hang around.
    table_builder_class = table_builder_subclasses[0]
    table_builder = table_builder_class(manifest=manifest)
    parallel_allowed = parallel and table_builder.parallel_allowed
    if write_reference_sql:
        prefix = manifest.get_study_prefix()
        table_builder.prepare_queries(config=config, manifest=manifest, parser=db_parser)
        for query_pos in range(len(table_builder.queries)):
            if "s3://" in table_builder.queries[query_pos]:
                table_builder.queries[query_pos] = re.sub(
                    f"s3://(.+){prefix}",
                    f"s3://bucket/db_path/{prefix}",
                    table_builder.queries[query_pos],
                )
        table_builder.comment_queries(doc_str=doc_str)
        new_filename = pathlib.Path(f"{filename}").stem + ".sql"
        table_builder.write_queries(
            path=pathlib.Path(f"{manifest._study_path}/reference_sql/" + new_filename)
        )
    elif prepare:
        table_builder.prepare_queries(
            config=config,
            manifest=manifest,
            parser=db_parser,
        )
        _render_output(
            config,
            manifest,
            table_builder.queries,
            data_path,
            filename,
            query_count,
        )

    else:
        table_builder.prepare_queries(
            config=config,
            manifest=manifest,
            parser=db_parser,
        )
        if not parallel_allowed and not write_reference_sql:
            table_builder.queries = _update_build_source_table(
                config, manifest, table_builder.queries
            )
            table_builder.execute_queries(
                config=config,
                manifest=manifest,
                parser=db_parser,
            )
    # After running the executor code, we'll remove
    # it so it doesn't interfere with the next python module to
    # execute, since the subclass would otherwise hang around.
    del sys.modules[table_builder_module.__name__]
    del table_builder_module

    return table_builder.queries, parallel_allowed


def _run_raw_queries(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    *,
    label: str | None,
    filename: str,
    data_path: pathlib.Path | None,
    prepare: bool,
    parallel: bool = False,
    query_count: int,
) -> list[str]:
    """Creates tables in the schema by iterating through the sql_config.file_names

    :param config: a StudyConfig object
    :param manifest: a StudyManifest object
    :keyword filename: the name of the sql file to read
    :keyword prepare: If true, will render query instead of executing
    :keyword data_path: If prepare is true, the path to write rendered data to
    :keyword parallel: If true, executes queries in parallel
    :keyword query_count: the number of queries currently processed
    :returns: a list of queries
    """
    raw_queries = []
    cleaned_queries = []
    for query in base_utils.parse_sql(base_utils.load_text(f"{manifest._study_path}/{filename}")):
        raw_queries.append(query)
    for query in raw_queries:
        query = base_utils.update_query_if_schema_specified(query, manifest)
        query = query.replace(
            f"`{manifest.get_study_prefix()}__",
            "`",
        )
        cleaned_queries.append(query)
    for query in cleaned_queries:
        _check_query_for_errors(config, manifest, query, filename)
    if prepare:
        _render_output(
            config,
            manifest,
            cleaned_queries,
            data_path,
            filename,
            query_count,
        )
        return cleaned_queries
    if not parallel:
        cleaned_queries = _update_build_source_table(config, manifest, cleaned_queries)
        # We'll explicitly create a cursor since recreating cursors for each
        # table in a study is slightly slower for some databases
        cursor = config.db.cursor()
        # We want to only show a progress bar if we are :not: printing SQL lines

        if label:
            display_str = f"Building {label} from {filename}..."
        else:
            display_str = f"Building tables from {filename}..."
        with base_utils.get_progress_bar(disable=config.verbose) as progress:
            task = progress.add_task(
                display_str,
                total=len(cleaned_queries),
                visible=not config.verbose,
            )
            _execute_build_queries(
                config=config,
                manifest=manifest,
                cursor=cursor,
                queries=cleaned_queries,
                filename=filename,
                progress=progress,
                task=task,
            )
    return cleaned_queries


def _run_workflow(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    *,
    filename: str,
    prepare: str,
    data_path: pathlib.Path,
    query_count: int,
    parallel: bool = False,
) -> tuple[list[str], bool]:
    """Loads workflow config from toml definitions and executes workflow

    :param config: a StudyConfig object
    :param manifest: a StudyManifest object
    :keyword filename: Filename of the workflow config
    :keyword prepare: If true, will render query instead of executing
    :keyword data_path: If prepare is true, the path to write rendered data to
    :keyword query_count: if prepare is true, the number of queries already rendered
    :keyword stage_name: the stage in the build currently being processed
    :keyword parallel; If true, execute queries in parallel if workflow allows
    :returns: a list of queries
    """
    toml_path = pathlib.Path(f"{manifest._study_path}/{filename}")
    if prepare:
        with open(toml_path, encoding="utf-8") as file:
            workflow_config = file.read()
        _render_output(
            config,
            manifest,
            [workflow_config],
            data_path,
            filename,
            query_count,
            is_toml=True,
        )
        return ([], False)

    # This open is a bit redundant with the open inside of the PSM builder,
    # but we're letting it slide so that builders function similarly
    # across the board
    safe_timestamp = base_utils.get_tablename_safe_iso_timestamp()
    with open(toml_path, "rb") as file:
        workflow_config = tomllib.load(file)
        config_type = workflow_config["config_type"]
        target_table = workflow_config.get("target_table", workflow_config.get("table_prefix", ""))

    match config_type:
        case "psm":
            existing_stats = []
            if not config.stats_build:
                existing_stats = (
                    config.db.cursor()
                    .execute(
                        "SELECT view_name FROM "  # noqa: S608
                        f"{manifest.get_study_prefix()}__{enums.ProtectedTables.STATISTICS.value}"
                    )
                    .fetchall()
                )
            if (target_table,) in existing_stats and not config.stats_build:
                return ([], False)
            builder = psm_builder.PsmBuilder(
                toml_config_path=toml_path,
                config=config,
                workflow_config=workflow_config,
                data_path=manifest.data_path / f"{manifest.get_study_prefix()}/psm",
            )
        case "valueset":
            builder = valueset_builder.ValuesetBuilder(
                toml_config_path=toml_path,
                config=config,
                workflow_config=workflow_config,
                data_path=manifest.data_path / f"{manifest.get_study_prefix()}/valueset",
            )
        case "file_upload":
            builder = file_upload_builder.FileUploadBuilder(
                toml_config_path=toml_path,
            )
        case "counts":
            builder = counts_builder.CountsBuilder(
                manifest=manifest,
                toml_config_path=toml_path,
            )
        case _:  # pragma: no cover
            raise errors.StudyManifestParsingError(
                f"{toml_path} references an invalid workflow type {config_type}."
            )

    builder.prepare_queries(
        config=config,
        manifest=manifest,
        table_suffix=safe_timestamp,
    )
    if not parallel or not builder.parallel_allowed:
        builder.queries = _update_build_source_table(config, manifest, builder.queries)
        builder.execute_queries(
            config=config,
            manifest=manifest,
            table_suffix=safe_timestamp,
        )
        if config_type in set(item.value for item in enums.StatisticsTypes):
            log_utils.log_statistics(
                config=config,
                manifest=manifest,
                table_type=config_type,
                table_name=f"{target_table}_{safe_timestamp}",
                view_name=target_table,
            )
    return builder.queries, bool(builder and builder.parallel_allowed)


def log_ref_summary(config: base_utils.StudyConfig, manifest: study_manifest.StudyManifest):
    """Updates the study ref_summary table with build results.

    The goal here is to do the following:
    - Find every table in a study containing a ref field
    - Get the most recent previous log results, if they exist
    - Get a count of the number of unique refs in the table
    - If there is a previous run, and that table is present, calculate the percent change
    - Write the count & results to the log table.

    :param config: a StudyConfig object
    :param manifest: a StudyManifest object
    """
    prefix = manifest.get_schema_aware_prefix_with_seperator()
    summary_table = f"{prefix}{enums.ProtectedTables.REF_SUMMARY.value}"

    # We'll set this up early in indeterminate mode while we wait for the
    # information_schema.tables query to run, since this can take a while
    # in athena
    with base_utils.get_progress_bar() as progress_bar:
        task = progress_bar.add_task(
            "Generating summary statistics...",
            total=None,
            visible=not config.verbose,
        )

        # In Athena, if we try to do a like/regex type lookup on table name while
        # looking for columns in an info schema query, we end up scanning the whole database.
        # It ends up being much faster to get a list of tables and do a filter on the table
        # being in the list instead, which bypasses the global search

        study_tables_query = base_templates.get_select_from_single_query(
            schema="information_schema",
            table_name="tables",
            columns=["table_name"],
            where_clauses=[
                [f"table_schema = '{config.schema}'", f"REGEXP_LIKE(table_name, '^({prefix}(.*))')"]
            ],
        )
        study_tables = config.db.cursor().execute(study_tables_query).fetchall()
        # Let's remove all the plumbing level tables from this list
        for reserved_slug in ["_dn_", "__etl_", "__nlp_", "__lib_"]:
            study_tables = [x for x in study_tables if reserved_slug not in x[0]]
        study_tables = f"""('{"', '".join([x[0] for x in study_tables])}')"""
        ref_cols_query = base_templates.get_select_from_single_query(
            schema="information_schema",
            table_name="columns",
            columns=["table_name", "column_name"],
            where_clauses=[
                [
                    f"table_schema = '{config.schema}'",
                    f"table_name in {study_tables}",
                    "REGEXP_LIKE(column_name, '((.*)_ref)$')",
                ]
            ],
        )

        ref_cols = config.db.cursor().execute(ref_cols_query).fetchall()

        prior_results_query = base_templates.get_select_from_single_query(
            schema=config.schema,
            table_name=summary_table,
            columns=const.REF_SUMMARY_COLS,
            where_clauses=[
                [
                    "event_time = (SELECT MAX(event_time) FROM "  # noqa: S608
                    f'"{config.schema}"."{summary_table}")'
                ]
            ],
        )
        prior_results_raw = config.db.cursor().execute(prior_results_query).fetchall()
        prior_results = {}
        for res in prior_results_raw:
            table_name = res[0]
            ref_type = res[1]
            ref_count = res[2]
            table_dict = prior_results.setdefault(table_name, {})
            table_dict[ref_type] = ref_count

        ref_queries = []
        for ref_col in ref_cols:
            ref_queries.append(
                base_templates.get_select_from_single_query(
                    schema=config.schema,
                    table_name=ref_col[0],
                    columns=[f"count(DISTINCT {ref_col[1]}) AS {ref_col[1]}"],
                )
            )
        progress_bar.update(task, total=len(ref_queries))
        parallel_results = config.db.parallel_execute(
            queries=ref_queries,
            verbose=config.verbose,
            progress_bar=progress_bar,
            task=task,
        )
        new_rows = []
        event_time = str(datetime.datetime.utcnow())
        deltas = False
        for res in parallel_results:
            formatted_table = (
                str(sqlglot.parse_one(res.query, dialect=config.db.db_type).find(sqlglot.exp.Table))
                .split(".")[1]
                .replace('"', "")
            )
            prior_raw = prior_results.get(formatted_table, {}).get(res.columns[0], None)

            if prior_raw is not None:
                deltas = True
                if prior_raw != 0:
                    prior = format(((res.rows[0][0] - prior_raw) / prior_raw) * 100, ".3f")
                else:
                    prior = "100.000"
            else:
                prior = None
            new_rows.append((formatted_table, res.columns[0], res.rows[0][0], prior, event_time))
        if len(new_rows) > 0:
            update_query = base_templates.get_insert_into_query(
                schema=config.schema,
                table_name=summary_table,
                table_cols=const.REF_SUMMARY_COLS,
                dataset=new_rows,
                type_casts={
                    "ref_count": "integer",
                    "delta_percent": "double",
                    "event_time": "timestamp",
                },
            )
            config.db.cursor().execute(update_query)
    if deltas:
        rich.print(f"Ref counts have changed. Check {summary_table} for more info.")


######### error handlers #########


def _query_error(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    query: str,
    filename: str,
    exit_message: str,
) -> None:
    rich.print(
        "An error occurred executing the following query in ",
        f"{filename}:",
        file=sys.stderr,
    )
    rich.print("--------", file=sys.stderr)
    rich.print(query, file=sys.stderr)
    rich.print("--------", file=sys.stderr)
    log_utils.log_transaction(config=config, manifest=manifest, status=enums.LogStatuses.ERROR)
    rich.print(exit_message)

    if any(init_error in exit_message for init_error in config.db.init_errors()):
        rich.print(
            "Have you initialized your database?\n"
            "https://docs.smarthealthit.org/cumulus/etl/setup/initialization.html"
        )
    sys.exit()


def _check_query_for_errors(
    config: base_utils.StudyConfig,
    manifest: study_manifest.StudyManifest,
    query: str,
    filename: str,
):
    try:
        table = str(sqlglot.parse_one(query, dialect=config.db.db_type).find(sqlglot.exp.Table))
    except sqlglot.errors.ParseError:
        _query_error(
            config,
            manifest,
            query,
            filename,
            "This query is not a valid SQL query. Check the query against a database "
            "for more debugging information.",
        )
    if (
        manifest.get_schema_aware_prefix_with_seperator() not in table
        and manifest.get_schema_aware_prefix_with_seperator() != ""
    ):
        _query_error(
            config,
            manifest,
            query,
            filename,
            "This query does not contain the study prefix. All tables should "
            f"start with a string like `{manifest.get_schema_aware_prefix_with_seperator()}`.",
        )
    if any(
        f"{manifest.get_study_prefix()}__{word.value}_" in table
        for word in enums.ProtectedTableKeywords
    ) and isinstance(
        sqlglot.parse_one(query, dialect=config.db.db_type), sqlglot.expressions.Create
    ):
        _query_error(
            config,
            manifest,
            query,
            filename,
            "This query contains a table name which contains a reserved word "
            "immediately after the study prefix. Please rename this table so "
            "that is does not begin with one of these special words "
            "immediately after the double underscore.\n Reserved words: "
            f"{[word.value for word in enums.ProtectedTableKeywords]}",
        )
    if table.count("__") > 1:
        _query_error(
            config,
            manifest,
            query,
            filename,
            "This query contains a table name with more than one '__' in it. "
            "Double underscores are reserved for special use cases. Please "
            "rename this table so the only double underscore is after the "
            f"study prefix, e.g. `{manifest.get_study_prefix()}__`",
        )
