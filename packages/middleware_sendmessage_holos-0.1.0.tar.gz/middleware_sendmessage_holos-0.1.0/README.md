# middleware-sendmessage-holos

Middleware FastAPI para recibir webhooks de Kommo, procesar mensajes y actualizar leads.

## Instalacion rapida

```bash
pip install git+https://github.com/<tu-org>/middleware_panama.git
```

Si trabajas dentro del repo:

```bash
pip install -e .
```

## Uso

El paquete expone el comando:

```bash
middleware-sendmessage-holos
```

Eso levanta el servidor en `0.0.0.0` y usa `PORT` si esta definida, o `8080` por defecto.

Tambien puedes ejecutar el modulo directamente:

```bash
python -m app
```

## Variables de entorno

- `TOKEN_KOMMO`
- `SUBDOMAIN_KOMMO`
- `OPENAI_API_KEY`
- `PORT` opcional

## Nota

`requirements.txt` sigue siendo la fuente de dependencias del proyecto. El paquete pip las instala automaticamente al usar `pip install .` o `pip install -e .`.

## Publicacion en PyPI (publico)

El paquete esta preparado para publicarse cuando hagas push de un tag que empiece con `v`, por ejemplo:

```bash
git tag v0.1.1
git push origin v0.1.1
```

El workflow de GitHub Actions construye el paquete y lo publica en PyPI publico.

Antes de ejecutar el workflow, crea este secret en el repositorio:

- `PYPI_API_TOKEN`: token de PyPI (formato `pypi-...`) con permiso para publicar

Puedes generarlo en PyPI desde Account settings > API tokens.

## Instalacion desde PyPI

Cuando una version este publicada, el equipo instala asi:

```bash
pip install middleware-sendmessage-holos
```
