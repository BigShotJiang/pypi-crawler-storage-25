import os
import asyncio
import uvicorn
import json
import time
import logging
from fastapi import FastAPI, Request, Form
from app.message_handler import parse_nested_form, process_request_data
from app.kommo_service.validate_stage_kommo import validate_stage_kommo
from app.kommo_service.add_message import add_message

logger = logging.getLogger(__name__)

app = FastAPI()

# --- Cache de deduplicación por message_id (TTL 120s) ---
_processed_messages: dict[str, float] = {}
_DEDUP_TTL_SECONDS = 120

def _is_duplicate(message_id: str) -> bool:
    """Retorna True si el message_id ya fue procesado recientemente."""
    now = time.monotonic()
    # Limpiar entradas expiradas (máx cada llamada para evitar crecimiento)
    expired = [k for k, t in _processed_messages.items() if now - t > _DEDUP_TTL_SECONDS]
    for k in expired:
        del _processed_messages[k]

    if message_id in _processed_messages:
        return True
    _processed_messages[message_id] = now
    return False

# Ruta webhook
@app.post("/add_message")
async def webhook(request: Request):
    try:
        # Validar el user-agent
        user_agent = request.headers.get("user-agent")
        if user_agent != "amoCRM-Webhooks/3.0":
            print(f"User-Agent no válido: {user_agent}")
            return {
                "status": "error",
                "message": "Este webhook solo acepta peticiones de amoCRM-Webhooks/3.0"
            }

        form = await request.form()
        data = parse_nested_form(form)

        # Imprimir detalles completos del request
        print("\n🚀 DETALLES COMPLETOS DEL REQUEST 🚀")

        # Headers
        print("\n📋 Headers:")
        for name, value in request.headers.items():
            print(f"{name}: {value}")

        # Client
        print("\n🌐 Client Info:")
        print(f"Client Host: {request.client.host}")
        print(f"Client Port: {request.client.port}")

        # Form Data
        print("\n📦 Form Data:")
        print(json.dumps(data, indent=2, ensure_ascii=False))

        print("\n🔚 FIN DETALLES REQUEST\n")

        msg = data["message"]["add"][0]
        lead_id = int(msg["entity_id"])
        message_id = msg.get("id", "")

        # Deduplicación: si ya procesamos este mensaje, responder OK sin reprocesar
        if message_id and _is_duplicate(message_id):
            logger.warning(f"Mensaje duplicado detectado: message_id={message_id}, lead_id={lead_id}. Ignorando.")
            print(f"⚠️ Duplicado ignorado: message_id={message_id}, lead_id={lead_id}")
            return {"status": "ok", "message": "Mensaje duplicado, ya fue procesado."}

        try:
            is_valid = await asyncio.to_thread(validate_stage_kommo, lead_id)
            if not is_valid:
                return {"status": "error", "message": "Lead no está en la etapa o pipeline permitidos."}
        except Exception as e:
            logger.error(f"Error validando etapa Kommo para lead {lead_id}: {e}", exc_info=True)
            return {"status": "error", "message": f"Error validando etapa Kommo: {e}"}

        processed = await process_request_data(data)
        
        add_message_result = await asyncio.to_thread(add_message, processed["lead_id"], processed["text"])
        if add_message_result["status"] == "error":
            logger.error(f"Error en add_message para lead {lead_id}: {add_message_result['message']}")
            return add_message_result
        else:
            print(f"Mensaje agregado: {processed['text']}")

        print(f"Mensaje agregado correctamente al lead {lead_id}")

        return {"status": "ok"}

    except Exception as e:
        logger.error(f"Error procesando el webhook: {e}", exc_info=True)
        print(f"Error procesando el webhook: {e}")
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)