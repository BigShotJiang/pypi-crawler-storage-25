"""Viperis: parse Python source into Velarium IR (not yet implemented)."""

__version__ = "0.2.0"
