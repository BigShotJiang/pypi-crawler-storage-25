"""统计查询。

stats(days=1)  → 汇总字典，含 by_channel / by_model / by_tag 明细
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Optional

from tokenetc._storage import _raw_query

# ---------------------------------------------------------------------------
# Public: stats()
# ---------------------------------------------------------------------------

def stats(
    days: int = 1,
    *,
    channel: Optional[str] = None,
    model: Optional[str] = None,
    tag: Optional[str] = None,
    start: Optional[datetime] = None,
    end: Optional[datetime] = None,
) -> dict:
    """返回指定时间段内的 token 用量统计。

    Parameters
    ----------
    days     最近 N 天（与 start/end 互斥，优先使用 start/end）
    channel  只统计指定渠道（可选过滤）
    model    只统计指定模型（可选过滤）
    tag      只统计指定标签/项目（可选过滤）
    start    起始时间（UTC datetime，含）
    end      结束时间（UTC datetime，含；默认当前时间）

    Returns
    -------
    {
        "total_tokens":  int,
        "input_tokens":  int,
        "output_tokens": int,
        "cost_usd":      float,
        "count":         int,
        "by_channel": {
            "<channel>": {"total_tokens": int, "input_tokens": int,
                          "output_tokens": int, "cost_usd": float, "count": int}
        },
        "by_model": {
            "<model>": {"total_tokens": int, "input_tokens": int,
                        "output_tokens": int, "cost_usd": float, "count": int}
        },
        "by_tag": {
            "<tag>": {"total_tokens": int, "input_tokens": int,
                      "output_tokens": int, "cost_usd": float, "count": int}
        },
        "daily": [
            {"date": "2026-04-11", "total_tokens": int, "cost_usd": float}
        ],
        "period": {"start": str, "end": str}
    }

    Examples
    --------
    >>> stats(days=7)
    >>> stats(days=30, channel="openai")
    >>> stats(days=7, tag="data-pipeline")
    """
    now = datetime.now(timezone.utc)
    if start is None:
        start = now - timedelta(days=days)
    if end is None:
        end = now

    start_str = start.isoformat()
    end_str = end.isoformat()

    # Build WHERE clause
    conditions = ["ts >= ?", "ts <= ?"]
    params: list = [start_str, end_str]

    if channel:
        conditions.append("channel = ?")
        params.append(channel)
    if model:
        conditions.append("model = ?")
        params.append(model)
    if tag:
        conditions.append("tag = ?")
        params.append(tag)

    where = " AND ".join(conditions)

    # ── Overall summary ──────────────────────────────────────────────────────
    summary_sql = f"""
        SELECT
            COALESCE(SUM(total_tokens),  0) AS total_tokens,
            COALESCE(SUM(input_tokens),  0) AS input_tokens,
            COALESCE(SUM(output_tokens), 0) AS output_tokens,
            COALESCE(SUM(cost_usd),      0) AS cost_usd,
            COUNT(*)                        AS count
        FROM records WHERE {where}
    """
    row = _raw_query(summary_sql, tuple(params))[0]
    result: dict = {
        "total_tokens":  int(row["total_tokens"]),
        "input_tokens":  int(row["input_tokens"]),
        "output_tokens": int(row["output_tokens"]),
        "cost_usd":      round(float(row["cost_usd"]), 8),
        "count":         int(row["count"]),
    }

    # ── By channel ───────────────────────────────────────────────────────────
    channel_sql = f"""
        SELECT
            channel,
            COALESCE(SUM(total_tokens),  0) AS total_tokens,
            COALESCE(SUM(input_tokens),  0) AS input_tokens,
            COALESCE(SUM(output_tokens), 0) AS output_tokens,
            COALESCE(SUM(cost_usd),      0) AS cost_usd,
            COUNT(*)                        AS count
        FROM records WHERE {where}
        GROUP BY channel
        ORDER BY total_tokens DESC
    """
    result["by_channel"] = {
        r["channel"]: {
            "total_tokens":  int(r["total_tokens"]),
            "input_tokens":  int(r["input_tokens"]),
            "output_tokens": int(r["output_tokens"]),
            "cost_usd":      round(float(r["cost_usd"]), 8),
            "count":         int(r["count"]),
        }
        for r in _raw_query(channel_sql, tuple(params))
    }

    # ── By model ─────────────────────────────────────────────────────────────
    model_sql = f"""
        SELECT
            COALESCE(model, 'unknown')      AS model,
            COALESCE(SUM(total_tokens),  0) AS total_tokens,
            COALESCE(SUM(input_tokens),  0) AS input_tokens,
            COALESCE(SUM(output_tokens), 0) AS output_tokens,
            COALESCE(SUM(cost_usd),      0) AS cost_usd,
            COUNT(*)                        AS count
        FROM records WHERE {where}
        GROUP BY model
        ORDER BY total_tokens DESC
    """
    result["by_model"] = {
        r["model"]: {
            "total_tokens":  int(r["total_tokens"]),
            "input_tokens":  int(r["input_tokens"]),
            "output_tokens": int(r["output_tokens"]),
            "cost_usd":      round(float(r["cost_usd"]), 8),
            "count":         int(r["count"]),
        }
        for r in _raw_query(model_sql, tuple(params))
    }

    # ── By tag ───────────────────────────────────────────────────────────────
    tag_sql = f"""
        SELECT
            COALESCE(tag, '(untagged)')     AS tag,
            COALESCE(SUM(total_tokens),  0) AS total_tokens,
            COALESCE(SUM(input_tokens),  0) AS input_tokens,
            COALESCE(SUM(output_tokens), 0) AS output_tokens,
            COALESCE(SUM(cost_usd),      0) AS cost_usd,
            COUNT(*)                        AS count
        FROM records WHERE {where}
        GROUP BY tag
        ORDER BY total_tokens DESC
    """
    result["by_tag"] = {
        r["tag"]: {
            "total_tokens":  int(r["total_tokens"]),
            "input_tokens":  int(r["input_tokens"]),
            "output_tokens": int(r["output_tokens"]),
            "cost_usd":      round(float(r["cost_usd"]), 8),
            "count":         int(r["count"]),
        }
        for r in _raw_query(tag_sql, tuple(params))
    }

    # ── Daily trend ──────────────────────────────────────────────────────────
    daily_sql = f"""
        SELECT
            DATE(ts)                        AS date,
            COALESCE(SUM(total_tokens),  0) AS total_tokens,
            COALESCE(SUM(input_tokens),  0) AS input_tokens,
            COALESCE(SUM(output_tokens), 0) AS output_tokens,
            COALESCE(SUM(cost_usd),      0) AS cost_usd,
            COUNT(*)                        AS count
        FROM records WHERE {where}
        GROUP BY DATE(ts)
        ORDER BY date
    """
    result["daily"] = [
        {
            "date":          r["date"],
            "total_tokens":  int(r["total_tokens"]),
            "input_tokens":  int(r["input_tokens"]),
            "output_tokens": int(r["output_tokens"]),
            "cost_usd":      round(float(r["cost_usd"]), 8),
            "count":         int(r["count"]),
        }
        for r in _raw_query(daily_sql, tuple(params))
    ]

    result["period"] = {"start": start_str, "end": end_str}
    return result
