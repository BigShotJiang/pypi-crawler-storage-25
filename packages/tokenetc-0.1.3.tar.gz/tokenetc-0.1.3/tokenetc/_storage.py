"""SQLite 存储层。

- 数据库路径：~/.tokenetc/data.db（可通过 TOKENETC_DB 环境变量覆盖）
- 写入是线程安全的（threading.Lock + WAL 模式）
- 同步写入，不依赖任何第三方库

Schema
------
records (id, channel, model, tag, input_tokens, output_tokens,
         total_tokens, cost_usd, source, ts)
"""

from __future__ import annotations

import os
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from tokenetc._pricing import cost as calc_cost

# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------

def _db_path() -> Path:
    env = os.environ.get("TOKENETC_DB")
    if env:
        p = Path(env)
    else:
        p = Path.home() / ".tokenetc" / "data.db"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


_DB_PATH: Path = _db_path()
_lock = threading.Lock()

# ---------------------------------------------------------------------------
# 初始化
# ---------------------------------------------------------------------------

_DDL = """
CREATE TABLE IF NOT EXISTS records (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    channel       TEXT    NOT NULL,
    model         TEXT,
    tag           TEXT,
    input_tokens  INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens  INTEGER NOT NULL DEFAULT 0,
    cost_usd      REAL    NOT NULL DEFAULT 0.0,
    source        TEXT    NOT NULL DEFAULT 'sdk',
    ts            TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ts      ON records(ts);
CREATE INDEX IF NOT EXISTS idx_channel ON records(channel);
CREATE INDEX IF NOT EXISTS idx_model   ON records(model);
CREATE INDEX IF NOT EXISTS idx_tag     ON records(tag);
"""

_MIGRATE_SQL = "ALTER TABLE records ADD COLUMN tag TEXT"


def _get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(_DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def _init() -> None:
    with _lock:
        conn = _get_conn()
        conn.executescript(_DDL)
        # 兼容旧数据库：tag 列可能不存在
        try:
            conn.execute(_MIGRATE_SQL)
            conn.commit()
        except sqlite3.OperationalError:
            pass  # 列已存在，忽略
        conn.commit()
        conn.close()


_init()

# ---------------------------------------------------------------------------
# Public: record()
# ---------------------------------------------------------------------------

def record(
    *,
    channel: str,
    model: Optional[str] = None,
    tag: Optional[str] = None,
    input_tokens: int = 0,
    output_tokens: int = 0,
    total_tokens: int = 0,
    cost_usd: Optional[float] = None,
    source: str = "manual",
    ts: Optional[datetime] = None,
) -> int:
    """写入一条 token 用量记录，返回新行的 id。

    Parameters
    ----------
    channel        渠道标识，如 "openai"、"cursor"、"gemini_web"
    model          模型名称，如 "gpt-4o"
    tag            自定义标签，用于区分不同脚本/项目，如 "data-pipeline"
    input_tokens   输入 token 数
    output_tokens  输出 token 数
    total_tokens   总 token 数；若为 0 则自动计算为 input + output
    cost_usd       费用；若为 None 则通过价格表自动估算
    source         来源：sdk（自动捕获）或 manual（手动录入）
    ts             时间戳；默认当前 UTC 时间

    Examples
    --------
    >>> record(channel="cursor", model="claude-sonnet-4",
    ...        tag="my-project", input_tokens=3000, output_tokens=500)
    1
    """
    if total_tokens == 0:
        total_tokens = input_tokens + output_tokens

    if cost_usd is None:
        cost_usd = calc_cost(
            model or "",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
        )

    if ts is None:
        ts = datetime.now(timezone.utc)

    ts_str = ts.isoformat()

    sql = """
        INSERT INTO records
            (channel, model, tag, input_tokens, output_tokens, total_tokens, cost_usd, source, ts)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    with _lock:
        conn = _get_conn()
        try:
            cur = conn.execute(sql, (
                channel, model, tag,
                input_tokens, output_tokens, total_tokens,
                cost_usd, source, ts_str,
            ))
            conn.commit()
            return cur.lastrowid
        finally:
            conn.close()


# ---------------------------------------------------------------------------
# Internal helpers used by _stats.py
# ---------------------------------------------------------------------------

def _raw_query(sql: str, params: tuple = ()) -> list[sqlite3.Row]:
    conn = _get_conn()
    try:
        return conn.execute(sql, params).fetchall()
    finally:
        conn.close()


def db_path() -> Path:
    """返回当前数据库文件路径。"""
    return _DB_PATH
