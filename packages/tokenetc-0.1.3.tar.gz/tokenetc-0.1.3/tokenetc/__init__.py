"""tokencost — 自动追踪 AI SDK token 用量。

Public API
----------
patch()          自动识别已安装的 OpenAI / Anthropic / Gemini SDK 并 monkey-patch
record(...)      手动录入一条 token 用量记录
stats(days=...)  查询统计（支持 by_channel / by_model）
cost(model, ...) 计算指定模型的估算费用（USD）
list_models()    列出价格表中所有已知模型
"""

from tokenetc._patch import patch
from tokenetc._storage import record
from tokenetc._stats import stats
from tokenetc._pricing import cost, list_models

__version__ = "0.1.3"

__all__ = [
    "patch",
    "record",
    "stats",
    "cost",
    "list_models",
    "__version__",
]
