"""模型价格表与费用计算。

价格单位：USD / token
数据来源：各厂商官网定价页（2025 年 4 月）

用法
----
from tokenetc._pricing import cost, list_models

cost("gpt-4o", input_tokens=1000, output_tokens=500)  # → 0.0075
list_models()  # → [{"model": "gpt-4o", "input": 2.5e-6, "output": 10e-6}, ...]
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# 价格表
# key   : 模型名前缀（小写），按从长到短顺序排列以保证精确匹配优先
# value : (input_usd_per_token, output_usd_per_token)
# ---------------------------------------------------------------------------
_PRICES: dict[str, tuple[float, float]] = {
    # ── OpenAI ──────────────────────────────────────────────────────────────
    "gpt-4o-mini":            (0.15e-6,   0.60e-6),
    "gpt-4o-audio-preview":   (2.50e-6,  10.00e-6),
    "gpt-4o":                 (2.50e-6,  10.00e-6),
    "gpt-4-turbo":            (10.00e-6, 30.00e-6),
    "gpt-4":                  (30.00e-6, 60.00e-6),
    "gpt-3.5-turbo":          (0.50e-6,   1.50e-6),
    "o3-mini":                (1.10e-6,   4.40e-6),
    "o3":                     (10.00e-6, 40.00e-6),
    "o1-mini":                (3.00e-6,  12.00e-6),
    "o1-pro":                 (150.0e-6, 600.0e-6),
    "o1":                     (15.00e-6, 60.00e-6),
    "o4-mini":                (1.10e-6,   4.40e-6),

    # ── Anthropic ────────────────────────────────────────────────────────────
    "claude-opus-4":          (15.00e-6, 75.00e-6),
    "claude-sonnet-4":        (3.00e-6,  15.00e-6),
    "claude-haiku-3-5":       (0.80e-6,   4.00e-6),
    "claude-3-5-sonnet":      (3.00e-6,  15.00e-6),
    "claude-3-5-haiku":       (0.80e-6,   4.00e-6),
    "claude-3-opus":          (15.00e-6, 75.00e-6),
    "claude-3-sonnet":        (3.00e-6,  15.00e-6),
    "claude-3-haiku":         (0.25e-6,   1.25e-6),

    # ── Google Gemini ────────────────────────────────────────────────────────
    "gemini-2.5-pro":         (1.25e-6,  10.00e-6),
    "gemini-2.0-flash-lite":  (0.075e-6,  0.30e-6),
    "gemini-2.0-flash":       (0.10e-6,   0.40e-6),
    "gemini-1.5-pro":         (1.25e-6,   5.00e-6),
    "gemini-1.5-flash-8b":    (0.0375e-6, 0.15e-6),
    "gemini-1.5-flash":       (0.075e-6,  0.30e-6),
    "gemini-1.0-pro":         (0.50e-6,   1.50e-6),

    # ── DeepSeek (云端 API: api.deepseek.com) ───────────────────────────────
    # 注意：相同模型名在 Ollama 本地运行时费用为 0（由 _patch.py 根据 base_url 判断）
    "deepseek-chat":      (0.27e-6,  1.10e-6),
    "deepseek-reasoner":  (0.55e-6,  2.19e-6),

    # ── Mistral (云端 API: api.mistral.ai) ───────────────────────────────────
    "mistral-large":          (3.00e-6,   9.00e-6),
    "mistral-small":          (0.20e-6,   0.60e-6),
    "codestral":              (0.20e-6,   0.60e-6),

    # ── Meta / Llama (via API providers) ─────────────────────────────────────
    "llama-3.3-70b":          (0.59e-6,   0.79e-6),
    "llama-3.1-70b":          (0.52e-6,   0.75e-6),
    "llama-3.1-8b":           (0.06e-6,   0.06e-6),
}

# 匹配顺序：从最长前缀到最短，保证 "gpt-4o-mini" 优先于 "gpt-4o"
_SORTED_KEYS: list[str] = sorted(_PRICES.keys(), key=len, reverse=True)


def _lookup(model: str) -> tuple[float, float] | None:
    """按前缀模糊匹配价格，返回 (input, output) 或 None。"""
    m = model.lower()
    for key in _SORTED_KEYS:
        if m.startswith(key) or m == key:
            return _PRICES[key]
    return None


def cost(
    model: str,
    *,
    input_tokens: int = 0,
    output_tokens: int = 0,
    total_tokens: int = 0,
) -> float:
    """计算指定模型的估算费用（USD）。

    Parameters
    ----------
    model          模型名称，如 "gpt-4o"、"claude-sonnet-4"
    input_tokens   输入 token 数（prompt）
    output_tokens  输出 token 数（completion）
    total_tokens   当 input/output 未知时，按 total * 0.8/0.2 估算

    Returns
    -------
    float  估算费用（USD），未知模型返回 0.0

    Examples
    --------
    >>> cost("gpt-4o", input_tokens=1000, output_tokens=500)
    0.0075
    """
    prices = _lookup(model)
    if prices is None:
        return 0.0
    ip, op = prices

    if input_tokens == 0 and output_tokens == 0 and total_tokens > 0:
        # 无明细时粗估：80% 输入、20% 输出
        input_tokens = int(total_tokens * 0.8)
        output_tokens = total_tokens - input_tokens

    return input_tokens * ip + output_tokens * op


def list_models() -> list[dict]:
    """返回所有已知模型的价格列表。

    Returns
    -------
    list of dict, 每项含 model / input_per_1m / output_per_1m（USD per 1M tokens）
    """
    return [
        {
            "model": k,
            "input_per_1m":  round(_PRICES[k][0] * 1_000_000, 4),
            "output_per_1m": round(_PRICES[k][1] * 1_000_000, 4),
        }
        for k in _SORTED_KEYS
    ]
