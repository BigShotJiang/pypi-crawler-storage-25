"""SDK monkey-patch 核心。

patch() 会自动检测已安装的 SDK 并在**类方法级别**替换，对所有实例生效。
支持同步调用、async/await 调用、以及流式响应（stream=True）。

支持的 SDK
----------
- openai  >= 1.0   (openai.OpenAI / openai.AsyncOpenAI)
- anthropic >= 0.20 (anthropic.Anthropic / anthropic.AsyncAnthropic)
- google-generativeai >= 0.5 (google.generativeai.GenerativeModel)

用法
----
import tokenetc
tokenetc.patch()                        # 自动检测所有已安装 SDK
tokenetc.patch(tag="data-pipeline")     # 打上项目标签，区分不同脚本
tokenetc.patch(gemini=False)            # 跳过 Gemini
"""

from __future__ import annotations

import asyncio
import functools
import logging
from typing import Any, Callable, Optional

from tokenetc._storage import record as _record

logger = logging.getLogger(__name__)

# 防止重复 patch
_patched: set[str] = set()

# 当前 tag（运行时可更新，wrapper 调用时读取）
_current_tag: Optional[str] = None


# ---------------------------------------------------------------------------
# URL → channel / local detection
# ---------------------------------------------------------------------------

# 已知云端 API base_url 前缀 → channel 名
_URL_CHANNEL_MAP = [
    ("api.openai.com",                    "openai"),
    ("api.anthropic.com",                 "anthropic"),
    ("generativelanguage.googleapis.com", "gemini"),
    ("aiplatform.googleapis.com",         "gemini"),
    ("api.deepseek.com",                  "deepseek"),
    ("api.mistral.ai",                    "mistral"),
    ("api.groq.com",                      "groq"),
    ("api.together.xyz",                  "together"),
    ("api.cohere.com",                    "cohere"),
    ("openrouter.ai",                     "openrouter"),
]

_LOCAL_HOSTS = ("localhost", "127.0.0.1", "0.0.0.0", "::1")


def _base_url_from_client(resource_self: Any) -> str:
    """从 SDK resource 对象上读取 base_url 字符串。"""
    try:
        client = getattr(resource_self, "_client", None)
        if client is None:
            return ""
        url = getattr(client, "base_url", None)
        return str(url) if url else ""
    except Exception:
        return ""


def _is_local(base_url: str) -> bool:
    """base_url 指向本地主机（Ollama 等）时返回 True。"""
    for host in _LOCAL_HOSTS:
        if host in base_url:
            return True
    return False


def _channel_from_url(base_url: str) -> str:
    """根据 base_url 推断渠道名称。"""
    if _is_local(base_url):
        return "ollama"
    for fragment, channel in _URL_CHANNEL_MAP:
        if fragment in base_url:
            return channel
    return "openai"  # 兜底：使用 OpenAI 兼容协议的未知端点


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def patch(
    *,
    openai: Optional[bool] = None,
    anthropic: Optional[bool] = None,
    gemini: Optional[bool] = None,
    tag: Optional[str] = None,
) -> list[str]:
    """自动 patch 已安装的 AI SDK。

    Parameters
    ----------
    openai     是否 patch openai SDK；None = 自动检测
    anthropic  是否 patch anthropic SDK；None = 自动检测
    gemini     是否 patch google-generativeai SDK；None = 自动检测
    tag        自定义标签，用于区分不同脚本或项目（如 "data-pipeline"、
               "research"），同一机器多个脚本共用同一 DB 时可通过 tag
               区分来源。可随时再次调用 patch(tag=...) 更新。

    Returns
    -------
    list[str]  实际成功 patch 的 SDK 名称列表

    Examples
    --------
    >>> import tokenetc
    >>> tokenetc.patch(tag="my-project")
    ['openai', 'anthropic']
    """
    global _current_tag
    _current_tag = tag

    done: list[str] = []

    if openai is not False:
        if _patch_openai():
            done.append("openai")
    if anthropic is not False:
        if _patch_anthropic():
            done.append("anthropic")
    if gemini is not False:
        if _patch_gemini():
            done.append("gemini")

    if done:
        logger.debug("[tokenetc] patched: %s  tag=%s", ", ".join(done), tag)
    return done


# ---------------------------------------------------------------------------
# Helper: write a record, silently ignoring errors
# ---------------------------------------------------------------------------

def _safe_record(**kwargs: Any) -> None:
    try:
        _record(**kwargs)
    except Exception as exc:
        logger.debug("[tokenetc] record failed: %s", exc)


# ---------------------------------------------------------------------------
# ── OpenAI ──────────────────────────────────────────────────────────────────
# SDK >= 1.0: openai.resources.chat.completions.Completions / AsyncCompletions
# ---------------------------------------------------------------------------

def _patch_openai() -> bool:
    if "openai" in _patched:
        return True
    try:
        import openai.resources.chat.completions as _mod  # type: ignore

        # ── Sync ─────────────────────────────────────────────────────────────
        _orig_sync = _mod.Completions.create

        @functools.wraps(_orig_sync)
        def _sync_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            _inject_openai_usage_option(kwargs)
            response = _orig_sync(self, *args, **kwargs)
            base_url = _base_url_from_client(self)
            _handle_openai_response(response, kwargs, base_url)
            return response

        _mod.Completions.create = _sync_create  # type: ignore

        # ── Async ─────────────────────────────────────────────────────────────
        _orig_async = _mod.AsyncCompletions.create

        @functools.wraps(_orig_async)
        async def _async_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            _inject_openai_usage_option(kwargs)
            response = await _orig_async(self, *args, **kwargs)
            base_url = _base_url_from_client(self)
            _handle_openai_response(response, kwargs, base_url)
            return response

        _mod.AsyncCompletions.create = _async_create  # type: ignore

        _patched.add("openai")
        return True

    except ImportError:
        return False
    except Exception as exc:
        logger.warning("[tokenetc] failed to patch openai: %s", exc)
        return False


def _inject_openai_usage_option(kwargs: dict) -> None:
    """流式调用时注入 stream_options 以获取 usage。"""
    if kwargs.get("stream"):
        opts = dict(kwargs.get("stream_options") or {})
        opts.setdefault("include_usage", True)
        kwargs["stream_options"] = opts


def _handle_openai_response(response: Any, kwargs: dict, base_url: str = "") -> None:
    """从 OpenAI 响应中提取并记录 usage。"""
    if kwargs.get("stream"):
        _wrap_openai_stream(response, base_url)
    else:
        _record_openai_usage(response, base_url)


def _record_openai_usage(response: Any, base_url: str = "") -> None:
    usage = getattr(response, "usage", None)
    if not usage:
        return
    model = getattr(response, "model", None) or ""
    channel = _channel_from_url(base_url)
    cost_usd = 0.0 if _is_local(base_url) else None
    _safe_record(
        channel=channel,
        model=model,
        tag=_current_tag,
        input_tokens=getattr(usage, "prompt_tokens", 0) or 0,
        output_tokens=getattr(usage, "completion_tokens", 0) or 0,
        total_tokens=getattr(usage, "total_tokens", 0) or 0,
        cost_usd=cost_usd,
        source="sdk",
    )


def _wrap_openai_stream(stream: Any, base_url: str = "") -> None:
    """给流式响应对象打补丁，在迭代结束时记录 usage。"""
    original_iter = stream.__iter__ if hasattr(stream, "__iter__") else None
    original_aiter = stream.__aiter__ if hasattr(stream, "__aiter__") else None

    if original_iter:
        def _new_iter(self_stream: Any = stream):  # type: ignore
            last_usage = None
            last_model = None
            for chunk in original_iter():
                if hasattr(chunk, "usage") and chunk.usage:
                    last_usage = chunk.usage
                    last_model = getattr(chunk, "model", None)
                yield chunk
            if last_usage:
                channel = _channel_from_url(base_url)
                cost_usd = 0.0 if _is_local(base_url) else None
                _safe_record(
                    channel=channel,
                    model=last_model or "",
                    tag=_current_tag,
                    input_tokens=getattr(last_usage, "prompt_tokens", 0) or 0,
                    output_tokens=getattr(last_usage, "completion_tokens", 0) or 0,
                    total_tokens=getattr(last_usage, "total_tokens", 0) or 0,
                    cost_usd=cost_usd,
                    source="sdk",
                )

        stream.__iter__ = _new_iter  # type: ignore

    if original_aiter:
        async def _new_aiter(self_stream: Any = stream):  # type: ignore
            last_usage = None
            last_model = None
            async for chunk in original_aiter():
                if hasattr(chunk, "usage") and chunk.usage:
                    last_usage = chunk.usage
                    last_model = getattr(chunk, "model", None)
                yield chunk
            if last_usage:
                channel = _channel_from_url(base_url)
                cost_usd = 0.0 if _is_local(base_url) else None
                _safe_record(
                    channel=channel,
                    model=last_model or "",
                    tag=_current_tag,
                    input_tokens=getattr(last_usage, "prompt_tokens", 0) or 0,
                    output_tokens=getattr(last_usage, "completion_tokens", 0) or 0,
                    total_tokens=getattr(last_usage, "total_tokens", 0) or 0,
                    cost_usd=cost_usd,
                    source="sdk",
                )

        stream.__aiter__ = _new_aiter  # type: ignore


# ---------------------------------------------------------------------------
# ── Anthropic ────────────────────────────────────────────────────────────────
# SDK >= 0.20: anthropic.resources.messages.Messages / AsyncMessages
# ---------------------------------------------------------------------------

def _patch_anthropic() -> bool:
    if "anthropic" in _patched:
        return True
    try:
        import anthropic.resources.messages as _mod  # type: ignore

        # ── Sync ─────────────────────────────────────────────────────────────
        _orig_sync = _mod.Messages.create

        @functools.wraps(_orig_sync)
        def _sync_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            response = _orig_sync(self, *args, **kwargs)
            if kwargs.get("stream"):
                _wrap_anthropic_stream(response)
            else:
                _record_anthropic_usage(response)
            return response

        _mod.Messages.create = _sync_create  # type: ignore

        # ── Async ─────────────────────────────────────────────────────────────
        _orig_async = _mod.AsyncMessages.create

        @functools.wraps(_orig_async)
        async def _async_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            response = await _orig_async(self, *args, **kwargs)
            if kwargs.get("stream"):
                _wrap_anthropic_stream(response)
            else:
                _record_anthropic_usage(response)
            return response

        _mod.AsyncMessages.create = _async_create  # type: ignore

        _patched.add("anthropic")
        return True

    except ImportError:
        return False
    except Exception as exc:
        logger.warning("[tokenetc] failed to patch anthropic: %s", exc)
        return False


def _record_anthropic_usage(response: Any) -> None:
    usage = getattr(response, "usage", None)
    if not usage:
        return
    model = getattr(response, "model", None) or ""
    input_t = getattr(usage, "input_tokens", 0) or 0
    output_t = getattr(usage, "output_tokens", 0) or 0
    _safe_record(
        channel="anthropic",
        model=model,
        tag=_current_tag,
        input_tokens=input_t,
        output_tokens=output_t,
        total_tokens=input_t + output_t,
        source="sdk",
    )


def _wrap_anthropic_stream(stream: Any) -> None:
    """包装 Anthropic 流式响应：在 message_stop 事件后记录 usage。"""
    original_iter = stream.__iter__ if hasattr(stream, "__iter__") else None
    original_aiter = stream.__aiter__ if hasattr(stream, "__aiter__") else None

    if original_iter:
        def _new_iter(self_stream: Any = stream):  # type: ignore
            final_msg = None
            for event in original_iter():
                etype = getattr(event, "type", "")
                if etype == "message_stop":
                    final_msg = getattr(event, "message", None)
                yield event
            if final_msg:
                _record_anthropic_usage(final_msg)

        stream.__iter__ = _new_iter  # type: ignore

    if original_aiter:
        async def _new_aiter(self_stream: Any = stream):  # type: ignore
            final_msg = None
            async for event in original_aiter():
                etype = getattr(event, "type", "")
                if etype == "message_stop":
                    final_msg = getattr(event, "message", None)
                yield event
            if final_msg:
                _record_anthropic_usage(final_msg)

        stream.__aiter__ = _new_aiter  # type: ignore


# ---------------------------------------------------------------------------
# ── Google Gemini ─────────────────────────────────────────────────────────────
# google-generativeai >= 0.5: google.generativeai.GenerativeModel
# ---------------------------------------------------------------------------

def _patch_gemini() -> bool:
    if "gemini" in _patched:
        return True
    try:
        import google.generativeai as genai  # type: ignore
        from google.generativeai.generative_models import GenerativeModel  # type: ignore

        # ── Sync ─────────────────────────────────────────────────────────────
        _orig_sync = GenerativeModel.generate_content

        @functools.wraps(_orig_sync)
        def _sync_generate(self: Any, *args: Any, **kwargs: Any) -> Any:
            response = _orig_sync(self, *args, **kwargs)
            _record_gemini_usage(response, self)
            return response

        GenerativeModel.generate_content = _sync_generate  # type: ignore

        # ── Async ─────────────────────────────────────────────────────────────
        _orig_async = GenerativeModel.generate_content_async

        @functools.wraps(_orig_async)
        async def _async_generate(self: Any, *args: Any, **kwargs: Any) -> Any:
            response = await _orig_async(self, *args, **kwargs)
            _record_gemini_usage(response, self)
            return response

        GenerativeModel.generate_content_async = _async_generate  # type: ignore

        _patched.add("gemini")
        return True

    except ImportError:
        return False
    except Exception as exc:
        logger.warning("[tokenetc] failed to patch gemini: %s", exc)
        return False


def _record_gemini_usage(response: Any, model_instance: Any) -> None:
    meta = getattr(response, "usage_metadata", None)
    if not meta:
        return

    model_name: str = ""
    try:
        mn = getattr(model_instance, "model_name", None)
        if mn:
            model_name = str(mn).removeprefix("models/")
    except Exception:
        pass

    input_t = getattr(meta, "prompt_token_count", 0) or 0
    output_t = getattr(meta, "candidates_token_count", 0) or 0
    total_t = getattr(meta, "total_token_count", 0) or (input_t + output_t)

    _safe_record(
        channel="gemini",
        model=model_name or "gemini",
        tag=_current_tag,
        input_tokens=input_t,
        output_tokens=output_t,
        total_tokens=total_t,
        source="sdk",
    )


# ---------------------------------------------------------------------------
# Utility: un-patch (mainly for testing)
# ---------------------------------------------------------------------------

def unpatch() -> None:
    """移除所有已打的 patch（用于测试）。"""
    _patched.clear()
