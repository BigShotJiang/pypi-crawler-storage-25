"""
darkmatter._env — zero-dependency .env loader
Automatically called by dm.commit() and all SDK functions.
No need for python-dotenv in quickstart examples.
"""
import os

def load_env(path=None):
    """Load .env from path or cwd. Safe to call multiple times."""
    if path is None:
        path = os.path.join(os.getcwd(), '.env')
    if not os.path.exists(path):
        return
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    k, v = line.split('=', 1)
                    k = k.strip()
                    v = v.strip().strip('"').strip("'")
                    if k and k not in os.environ:  # don't override existing env vars
                        os.environ[k] = v
    except Exception:
        pass  # never fail on env loading

# Auto-load on import
load_env()
