"""
DarkMatter Audit Bundle Demo
The template that makes a manager say "we need this."

Flow:
  1. Run a 5-step mixed pipeline (researcher → analyst → writer → reviewer → approver)
  2. Fork from step 3 with a different model
  3. Diff the two branches
  4. Export a full proof bundle
  5. Generate a markdown summary

Usage:
    python audit_bundle_demo.py
"""

import os
import json
import darkmatter_sdk as dm

AGENT = os.environ["DARKMATTER_AGENT_A_ID"]
trace_id = f"trc_audit_{os.urandom(3).hex()}"

print("\nDarkMatter Audit Bundle Demo")
print(f"Trace: {trace_id}\n")

# ── Run 5-step pipeline ───────────────────────────────────────────────────────
steps_data = [
    ("researcher", "anthropic", "claude-opus-4-6", "commit",
     {"input": "Analyze Q1 2026 APAC performance", "output": {"summary": "Revenue up 34%", "confidence": 0.94}}),
    ("analyst",    "anthropic", "claude-opus-4-6", "commit",
     {"input": "Validate research findings",        "output": {"validated": True, "flags": []}}),
    ("writer",     "openai",    "gpt-4o",           "commit",
     {"input": "Write executive summary",           "output": "Q1 APAC Performance: Strong growth driven by Japan and South Korea..."}),
    ("reviewer",   "anthropic", "claude-opus-4-6", "checkpoint",
     {"input": "Review draft",                      "output": {"approved": True, "edits": 1}}),
    ("approver",   "anthropic", "claude-opus-4-6", "checkpoint",
     {"input": "Final approval",                    "output": {"approved": True, "sent_to": "cfo@company.com"}}),
]

parent_id = None
ctx_ids = []
print("Running pipeline...")

for role, provider, model, event_type, payload in steps_data:
    ctx = dm.commit(
        to_agent_id=AGENT,
        payload=payload,
        parent_id=parent_id,
        trace_id=trace_id,
        event_type=event_type,
        agent={"role": role, "provider": provider, "model": model},
    )
    parent_id = ctx["id"]
    ctx_ids.append(ctx["id"])
    print(f"  ✓ {role:12} [{model}]  {ctx['id'][-16:]}")

tip_ctx_id = ctx_ids[-1]
fork_point  = ctx_ids[2]  # fork from step 3 (after writer)

# ── Fork from step 3 — try claude for writing instead of gpt-4o ──────────────
print(f"\nForking from step 3 to try claude-opus-4-6 for writing...")

fork_ctx = dm.fork(
    fork_point,
    to_agent_id=AGENT,
    branch_key="alt-claude-writer",
)
print(f"  ⑂ Fork: {fork_ctx['id'][-16:]} (branch: {fork_ctx['branch_key']})")

# Continue fork with Claude writing
fork_continue = dm.commit(
    to_agent_id=AGENT,
    payload={"input": "Write executive summary", "output": "Q1 APAC Performance Report: Exceptional growth trajectory with strong fundamentals..."},
    parent_id=fork_ctx["id"],
    trace_id=trace_id + "_fork",
    event_type="commit",
    agent={"role": "writer", "provider": "anthropic", "model": "claude-opus-4-6"},
)
print(f"  ✓ writer     [claude-opus-4-6]  {fork_continue['id'][-16:]}")

# ── Diff original vs fork ─────────────────────────────────────────────────────
print(f"\nDiffing original vs fork...")
d = dm.diff(tip_ctx_id, fork_continue["id"])
print(f"  Changed steps: {d['changedSteps']}")
print(f"  Models A: {d['summary']['modelsA']}")
print(f"  Models B: {d['summary']['modelsB']}")

# ── Verify chain ──────────────────────────────────────────────────────────────
print(f"\nVerifying chain integrity...")
v = dm.verify(tip_ctx_id)
print(f"  Chain intact: {v['chain_intact']}")
print(f"  Length: {v['length']} commits")
print(f"  Root hash: {v['root_hash'][:40]}...")

# ── Check retention ───────────────────────────────────────────────────────────
r = dm.retention(tip_ctx_id)
print(f"\nRetention:")
print(f"  Plan: {r['plan']}")
print(f"  Expires: {r['expiresAt'][:10]} ({r['daysRemaining']} days remaining)")
if r.get('upgradeMessage'):
    print(f"  ⚠ {r['upgradeMessage']}")

# ── Share link ────────────────────────────────────────────────────────────────
print(f"\nCreating share link...")
share = dm.share(tip_ctx_id, label="Q1 APAC Pipeline — Audit Demo")
print(f"  Share URL: {share['shareUrl']}")

# ── Markdown summary ──────────────────────────────────────────────────────────
md_result = dm.markdown(tip_ctx_id)
print(f"\nMarkdown summary:")
print("  " + "\n  ".join(md_result["markdown"].split("\n")))

# ── Export proof bundle ───────────────────────────────────────────────────────
print(f"\nExporting proof bundle...")
bundle = dm.bundle(tip_ctx_id)

# Save to file
output_file = f"proof_bundle_{trace_id}.json"
with open(output_file, "w") as f:
    json.dump(bundle, f, indent=2)

print(f"\nProof bundle saved: {output_file}")
print()
print("Bundle contents:")
print(f"  chain_hash:   {bundle['verification']['chainHash'][:48]}...")
print(f"  chain_intact: {bundle['verification']['chainIntact']}")
print(f"  root_hash:    {bundle['verification']['rootHash'][:40] if bundle['verification']['rootHash'] else 'n/a'}...")
print(f"  tip_hash:     {bundle['verification']['tipHash'][:40] if bundle['verification']['tipHash'] else 'n/a'}...")
print(f"  steps:        {bundle['metadata']['chainLength']}")
print(f"  models:       {', '.join(bundle['metadata']['models'])}")
print()
print(bundle["readme"])
print()
print(f"Done ✓")
print(f"  View chain:  {share['shareUrl']}")
print(f"  Bundle file: {output_file}")
