# cd-analyzer

CD spectroscopy data analysis toolkit — parse `.dsx` binary files, fit protein thermal melting curves, global spectral fitting, and calculate thermodynamic parameters (Tm, ΔH, ΔG).

## Install

```bash
pip install cd-analyzer
```

## Quick start

```bash
# Single-sample analysis
cdanalyzer analyze ./my_data/
cdanalyzer spectral ./my_data/
cdanalyzer svd ./my_data/

# Batch analysis across multiple samples
cdanalyzer batch ./experiment/ ./output/
```

### Python API

```python
from cdanalyzer import help_read_multifile, spectral_global_fit, batch_analyze

# Parse and fit
data = help_read_multifile("my_data/")
result = spectral_global_fit(data)
print(result["Tm (°C)"], result["ΔH (kJ/mol)"])

# Batch process all samples
batch_analyze("experiment/", "output/")
```

Output per sample:
- `reports.md` — summary table with Tm, ΔH, R²
- `spectra_low_T.png` — low-temperature CD spectrum
- `analysis.png` — 4-panel diagnostic (spectra, fit curve, populations, SVD)
- `data.xlsx` — raw data, fit parameters, SVD results

## Features

- **Binary `.dsx` parser** — native JASCO CD spectrometer format
- **Single-wavelength fit** — van't Hoff two-state model with linear baselines
- **Global spectral fit** — shared Tm/ΔH across all wavelengths for robust estimates
- **SVD analysis** — assess two-state vs multi-state transitions
- **Batch processing** — auto-discover `{sample}/[temp*.dsx][buffer.dsx]` directory layout
