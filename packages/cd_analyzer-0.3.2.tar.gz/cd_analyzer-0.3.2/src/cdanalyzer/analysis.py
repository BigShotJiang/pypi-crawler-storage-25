import logging
import re
import struct
from pathlib import Path
from typing import Any

import matplotlib.cm as cm
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from numpy.polynomial import Polynomial
from scipy.constants import R
from scipy.ndimage import gaussian_filter
from scipy.optimize import curve_fit
from scipy.stats import linregress

from .constants import (
    DEFAULT_FIT_MAXFEV,
    DEFAULT_INIT_DELTA_H,
    SINGLE_REPEAT_PADDING_SIZE,
    T_KELVIN_OFFSET,
    T_REF_C,
)
from .exceptions import DataError, FitError, ParseError

logger = logging.getLogger(__name__)


def parse_dsx(filepath: str | Path, debug: bool = False) -> list[tuple[pd.DataFrame, dict]]:
    log_level = logging.DEBUG if debug else logging.INFO
    logger.log(log_level, "Parsing file: %s", filepath)

    with open(filepath, "rb") as f:
        content = f.read()

    # Extract metadata
    metadata: dict[str, str] = {}
    metadata_matches = re.findall(rb"#([^:]+):\s*([^\x00]+)", content)
    for key_bytes, value_bytes in metadata_matches:
        try:
            metadata[key_bytes.decode("ascii").strip()] = value_bytes.decode("ascii").strip()
        except UnicodeDecodeError:
            continue

    # Locate column names
    start_anchor = b"Misc_AutoShutter:1\x00"
    end_anchor = b"\x00Wavelength -en"
    start_pos = content.find(start_anchor)
    if start_pos == -1:
        raise ParseError("Could not find start anchor 'Misc_AutoShutter:1' in file.")
    start_of_cols_pos = start_pos + len(start_anchor)
    end_of_cols_pos = content.find(end_anchor)
    if end_of_cols_pos == -1:
        raise ParseError("Could not find end anchor 'Wavelength -en' in file.")

    column_blob = content[start_of_cols_pos:end_of_cols_pos]
    potential_names = column_blob.split(b"\x00")
    data_column_candidates: list[str] = []
    for s_bytes in potential_names:
        if not s_bytes:
            continue
        try:
            s = s_bytes.decode("ascii").strip()
            if s and ":" not in s and s.isprintable() and len(s) > 1 and not s.isdigit():
                data_column_candidates.append(s)
        except (UnicodeDecodeError, TypeError):
            continue

    column_names = ["Wavelength_nm"]
    for col in data_column_candidates:
        column_names.append(col.split(" ")[0].strip())

    logger.debug("Parsed column names: %s", column_names)

    if len(column_names) <= 1:
        raise ParseError("No data columns found in file.")

    # Parse core parameters and determine pointer offsets
    try:
        range_marker = b"-range\x00"
        range_pos = content.find(range_marker, end_of_cols_pos)
        num_points_pos = range_pos + len(range_marker)
        num_points = struct.unpack("<i", content[num_points_pos : num_points_pos + 4])[0]
        wavelength_data_start_pos = num_points_pos + 4
        wavelength_bytes_size = num_points * 4
        wavelength_end_pos = wavelength_data_start_pos + wavelength_bytes_size

        repeat_marker = b"Repeat -iter\x00"
        repeat_pos = content.find(repeat_marker)

        if repeat_pos != -1:
            logger.debug("Detected 'Repeat -iter' marker — multi-repeat mode.")
            num_repeats_pos = repeat_pos + len(repeat_marker)
            num_repeats = struct.unpack("<i", content[num_repeats_pos : num_repeats_pos + 4])[0]
            dynamic_padding_size = 4 * num_repeats + 4
            data_columns_start_pos = repeat_pos + len(repeat_marker) + 4 + dynamic_padding_size
            logger.debug("N=%d, dynamic padding=%d bytes", num_repeats, dynamic_padding_size)
        else:
            logger.debug("No 'Repeat -iter' marker — single-repeat mode.")
            num_repeats = 1
            data_columns_start_pos = wavelength_end_pos + SINGLE_REPEAT_PADDING_SIZE

    except (struct.error, TypeError, IndexError) as e:
        raise ParseError(f"Failed to parse core parameters: {e}") from e

    logger.debug(
        "num_points=%d, num_repeats=%d, data_start=%d",
        num_points,
        num_repeats,
        data_columns_start_pos,
    )

    # Read wavelength data
    results_data: list[dict[str, Any]] = [{} for _ in range(num_repeats)]
    try:
        wavelengths = struct.unpack(
            f"<{num_points}f", content[wavelength_data_start_pos:wavelength_end_pos]
        )
        for i in range(num_repeats):
            results_data[i]["Wavelength_nm"] = wavelengths
    except (struct.error, IndexError) as e:
        raise ParseError(f"Failed to read wavelength data: {e}") from e

    # Read data columns
    current_pos = data_columns_start_pos
    data_columns = column_names[1:]
    for col_name in data_columns:
        logger.debug("Reading column '%s' for all repeats...", col_name)
        for i in range(num_repeats):
            try:
                col_bytes_size = num_points * 4
                col_data_block = content[current_pos : current_pos + col_bytes_size]

                if len(col_data_block) < col_bytes_size:
                    raise ParseError(
                        f"File ended prematurely while reading column '{col_name}' "
                        f"(Repeat #{i + 1})."
                    )

                col_data = struct.unpack(f"<{num_points}f", col_data_block)
                results_data[i][col_name] = col_data
                current_pos += col_bytes_size

            except (struct.error, ValueError, IndexError) as e:
                raise ParseError(
                    f"Failed to read column '{col_name}' (Repeat #{i + 1}): {e}"
                ) from e

    # Build result DataFrames
    final_results: list[tuple[pd.DataFrame, dict]] = []
    final_column_order = column_names

    for i in range(num_repeats):
        df = pd.DataFrame(results_data[i])
        final_results.append((df[final_column_order], metadata))

    return final_results


def sigmoid(x: np.ndarray, a: float, tm: float, b: float, c: float) -> np.ndarray:
    """
    Boltzmann sigmoid function for fitting protein unfolding curves.

    f(x) = a / (1 + exp((x - tm) / b)) + c

    Parameters
    ----------
    x : temperature values (°C).
    a : total amplitude.
    tm : melting temperature (inflection point, °C).
    b : slope factor (steepness of the transition).
    c : vertical offset (baseline).
    """
    return a / (1.0 + np.exp((x - tm) / b)) + c


def plot_dtemp_cd(
    ax: plt.Axes,
    data_arr: np.ndarray,
    factor: float = 1.0,
    add_colorbar: bool = True,
    smooth: int | None = None,
) -> tuple[plt.Axes, cm.ScalarMappable]:
    """
    Plot temperature-dependent CD spectra.

    Parameters
    ----------
    ax : matplotlib Axes.
    data_arr : shape (n_temps, n_wavelengths, 3), where the three columns are
               [wavelength, CD_signal, temperature].
    factor : CD signal scaling factor.
    add_colorbar : whether to add a temperature colorbar.
    smooth : if set, apply Gaussian smoothing with this sigma.

    Returns
    -------
    (ax, scalar_mappable)
    """
    temperature_arr = data_arr[:, :, 2].mean(axis=1)
    min_temp, max_temp = temperature_arr.min(), temperature_arr.max()
    norm = plt.Normalize(vmin=min_temp, vmax=max_temp)
    scalar_mappable = cm.ScalarMappable(norm=norm, cmap=cm.coolwarm)

    for i, temp in enumerate(temperature_arr):
        x = data_arr[i][:, 0]
        y = data_arr[i][:, 1] * factor
        if smooth:
            y = gaussian_filter(y, smooth)
        ax.plot(x, y, color=scalar_mappable.to_rgba(temp), lw=2)

    if add_colorbar:
        cbar = plt.colorbar(scalar_mappable, ax=ax, orientation="vertical")
        cbar.set_label("Temperature (°C)", fontsize=14)
        cbar.ax.tick_params(labelsize=12)

    ax.set_xlabel("Wavelength (nm)", fontsize=16)
    ax.set_ylabel("CD (mdeg)", fontsize=16)
    ax.tick_params(labelsize=12)
    ax.grid(True, linestyle="--", alpha=0.6)

    return ax, scalar_mappable


def help_read_multifile(path: str | Path) -> np.ndarray:
    """
    Read all .dsx files from a directory, buffer-subtract, and stack into a 3D array.

    Returns
    -------
    np.ndarray
        shape (n_temps, n_wavelengths, 3) with columns [Wavelength_nm, CircularDichroism, Temperature].
    """
    path = Path(path)
    f_lst = list(path.rglob("*.dsx"))
    if not f_lst:
        raise DataError(f"No .dsx files found in {path}")

    data_dic: dict[str, pd.DataFrame] = {}
    for fname in f_lst:
        data = parse_dsx(fname)[0][0]
        if "buf" in fname.stem.lower():
            k = "buffer"
        else:
            k = str(round(float(data["Temperature"].mean()), 1))
        df_new = pd.DataFrame(
            {col: data[col] for col in ["Wavelength_nm", "CircularDichroism", "Temperature"]}
        )
        data_dic[k] = df_new

    if "buffer" not in data_dic:
        raise DataError("No buffer file found (filename must contain 'buf').")

    new_dic: dict[str, pd.DataFrame] = {}
    for k, v in data_dic.items():
        if k == "buffer":
            continue
        v = v.copy()
        v["CircularDichroism"] = (
            v["CircularDichroism"].values - data_dic["buffer"]["CircularDichroism"].values
        )
        new_dic[k] = v

    k_lst = sorted(new_dic.keys(), key=float)
    data_arr = np.stack([np.array(new_dic[k]) for k in k_lst])
    return data_arr


def vanthoff_fraction(temp_c: np.ndarray | float, tm: float, delta_h: float) -> np.ndarray:
    """
    Two-state van't Hoff unfolded fraction f_u(T).

    Parameters
    ----------
    temp_c : temperature (°C).
    tm : melting temperature (°C).
    delta_h : unfolding enthalpy (J/mol).
    """
    temp_c = np.asarray(temp_c, dtype=float)
    temp_k = temp_c + T_KELVIN_OFFSET
    tm_k = tm + T_KELVIN_OFFSET
    exponent = (delta_h / R) * (1.0 / tm_k - 1.0 / temp_k)

    fu = np.empty_like(exponent, dtype=float)
    mask = exponent >= 0
    fu[mask] = 1.0 / (1.0 + np.exp(-exponent[mask]))
    fu[~mask] = np.exp(exponent[~mask]) / (1.0 + np.exp(exponent[~mask]))
    return fu


def vant_hoff_model(
    temp_c: np.ndarray | float,
    tm: float,
    delta_h: float,
    mn: float,
    cn: float,
    md: float,
    cd: float,
) -> np.ndarray:
    """
    Two-state van't Hoff model with linear baselines.

    Parameters
    ----------
    temp_c : temperature (°C).
    tm : melting temperature (°C).
    delta_h : unfolding enthalpy (J/mol).
    mn, cn : native baseline slope and intercept.
    md, cd : denatured baseline slope and intercept.
    """
    temp_c = np.asarray(temp_c, dtype=float)
    y_native = mn * temp_c + cn
    y_denatured = md * temp_c + cd
    f_u = vanthoff_fraction(temp_c, tm, delta_h)
    return y_native * (1.0 - f_u) + y_denatured * f_u


def find_best_wavelength(
    data_arr: np.ndarray,
    step_nm: float = 3.0,
    n_edge: int = 4,
) -> dict[str, Any]:
    """
    Greedy scan: fit the van't Hoff model at candidate wavelengths,
    return the wavelength with the best R².

    Useful when the "most variable" wavelength doesn't give the cleanest
    sigmoidal transition.

    Parameters
    ----------
    data_arr : shape (n_temps, n_wavelengths, 3).
    step_nm : spacing between candidate wavelengths (default 3 nm).
    n_edge : baseline fitting points.

    Returns
    -------
    dict with best_wavelength, best_result, top_candidates list.
    """
    wavelengths = data_arr[0, :, 0].astype(float)
    wl_min, wl_max = wavelengths.min(), wavelengths.max()

    # Build candidate list: every step_nm
    candidates: list[float] = []
    w = wl_min
    while w <= wl_max:
        # Find nearest actual wavelength
        idx = int(np.abs(wavelengths - w).argmin())
        wl_actual = float(wavelengths[idx])
        if not candidates or abs(wl_actual - candidates[-1]) > 0.5:
            candidates.append(wl_actual)
        w += step_nm

    results: list[dict] = []
    for wl in candidates:
        try:
            r = analyze_and_fit_curves(data_arr, wavelength=wl, n_edge=n_edge)
            results.append({
                "wavelength": wl,
                "Tm": r["Tm (°C)"],
                "ΔH": r["ΔH (kJ/mol)"],
                "R²": r["R²"],
            })
        except Exception:
            pass

    if not results:
        raise FitError("No wavelength converged during greedy scan.")

    results.sort(key=lambda x: x["R²"], reverse=True)

    logger.info(
        "Greedy scan: best wl=%.1f nm, R²=%.4f. Top 3: %s",
        results[0]["wavelength"], results[0]["R²"],
        [(f"{r['wavelength']:.0f}nm", f"{r['R²']:.4f}") for r in results[:3]],
    )

    return {
        "best_wavelength": results[0]["wavelength"],
        "best_result": results[0],
        "top_candidates": results[:5],
        "all_candidates": results,
    }


def analyze_and_fit_curves(
    data_arr: np.ndarray,
    wavelength: float | str = "auto",
    n_edge: int = 4,
    global_fit: bool = False,
) -> dict[str, Any]:
    """
    Fit a melting curve to the van't Hoff model.

    Two strategies:
    1. Two-step (default): linear baselines from edge points + van't Hoff on f_u.
    2. Global fit (global_fit=True): simultaneous 6-param optimization on raw signal.

    Parameters
    ----------
    data_arr : shape (n_temps, n_wavelengths, 3), [wavelength, signal, temp].
    wavelength : wavelength in nm, or 'auto' to pick the most variable wavelength.
    n_edge : points used for baseline estimation.
    global_fit : if True, use full simultaneous 6-param fitting (more robust).

    Returns
    -------
    dict with Tm (°C), ΔH (kJ/mol), ΔG_25C (kJ/mol), fit_params, R²,
         fit_wavelength, data, temps_sorted, signals_sorted, f_u_obs,
         baseline_native, baseline_denatured.
    """
    if wavelength == "auto":
        index = int(np.abs(data_arr[:, :, 1] - data_arr[0, :, 1]).sum(axis=0).argmax())
    else:
        index = int(np.abs(data_arr[0, :, 0] - float(wavelength)).argmin())

    data = data_arr[:, index, :]
    temps = data[:, 2].astype(float)
    signals = data[:, 1].astype(float)
    fit_wavelength = float(data[0, 0])

    order = np.argsort(temps)
    temps = temps[order]
    signals = signals[order]

    if len(temps) < 2 * n_edge:
        raise DataError(
            f"Too few data points ({len(temps)}) for baseline fitting with n_edge={n_edge}."
        )

    t_min, t_max = float(temps.min()), float(temps.max())

    # --- Two-step approach (initial guess) ---
    n_idx = slice(0, n_edge)
    d_idx = slice(-n_edge, None)

    mn, cn, *_ = linregress(temps[n_idx], signals[n_idx])
    md, cd_, *_ = linregress(temps[d_idx], signals[d_idx])

    y_native = mn * temps + cn
    y_denatured = md * temps + cd_

    denom = y_denatured - y_native
    if np.any(np.isclose(denom, 0)):
        raise FitError("Native and denatured baselines are nearly parallel and overlapping.")

    f_u_obs = (signals - y_native) / denom
    f_u_obs = np.clip(f_u_obs, 0.0, 1.0)

    tm0 = float(temps[len(temps) // 2])
    delta_h0 = DEFAULT_INIT_DELTA_H

    # Two-step: van't Hoff on f_u
    try:
        params_th, _ = curve_fit(
            vanthoff_fraction,
            temps,
            f_u_obs,
            p0=[tm0, delta_h0],
            bounds=([t_min, 1e3], [t_max, 1e6]),
            maxfev=DEFAULT_FIT_MAXFEV,
        )
    except RuntimeError as e:
        raise FitError(f"van't Hoff fitting failed: {e}") from e

    tm_fit, delta_h_fit = params_th

    if global_fit:
        # Full 6-param simultaneous fit with tight baseline bounds
        # Slopes for CD data are tiny (< 0.5 mdeg/°C typically); intercepts near data
        try:
            popt_global, _ = curve_fit(
                vant_hoff_model,
                temps,
                signals,
                p0=[tm_fit, delta_h_fit, mn, cn, md, cd_],
                bounds=(
                    [t_min, 1e3, -2.0, cn - 50, -2.0, cd_ - 50],
                    [t_max, 1e6, 2.0, cn + 50, 2.0, cd_ + 50],
                ),
                maxfev=DEFAULT_FIT_MAXFEV,
            )
            tm_fit, delta_h_fit, mn, cn, md, cd_ = popt_global
        except RuntimeError:
            logger.debug("Global 6-param fit failed, using two-step result.")

    fit_params = np.array([tm_fit, delta_h_fit, mn, cn, md, cd_], dtype=float)

    # R² on raw signal
    y_pred = vant_hoff_model(temps, tm_fit, delta_h_fit, mn, cn, md, cd_)
    ss_res = float(np.sum((signals - y_pred) ** 2))
    ss_tot = float(np.sum((signals - np.mean(signals)) ** 2))
    r_squared = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    t_ref_k = T_REF_C + T_KELVIN_OFFSET
    tm_fit_k = tm_fit + T_KELVIN_OFFSET
    delta_g_ref = delta_h_fit * (1.0 - t_ref_k / tm_fit_k)

    thermo_results: dict[str, Any] = {
        "Tm (°C)": tm_fit,
        "ΔH (kJ/mol)": delta_h_fit / 1000.0,
        "ΔG_25C (kJ/mol)": delta_g_ref / 1000.0,
        "R²": r_squared,
        "fit_params": fit_params,
        "fit_wavelength": fit_wavelength,
        "data": data_arr,
        "temps_sorted": temps,
        "signals_sorted": signals,
        "f_u_obs": f_u_obs,
        "baseline_native": (mn, cn),
        "baseline_denatured": (md, cd_),
    }

    logger.info(
        "Fit: Tm=%.2f °C, ΔH=%.2f kJ/mol, ΔG_25=%.2f kJ/mol, R²=%.4f, wl=%.1f nm",
        tm_fit, delta_h_fit / 1000.0, delta_g_ref / 1000.0, r_squared, fit_wavelength,
    )

    return thermo_results


def plot_fitted_curves(
    thermo_results: dict[str, Any],
    ax: plt.Axes | None = None,
    pointcolor: str | None = None,
    linecolor: str | None = None,
    showparams: bool = False,
    plotfitted: bool = True,
    factor: float = 1.0,
) -> plt.Axes | None:
    """
    Plot raw melting curve and fitted curve.

    Parameters
    ----------
    thermo_results : output from analyze_and_fit_curves.
    ax : optional matplotlib Axes. Creates a new figure if None.
    pointcolor : color of data points (default 'r').
    linecolor : color of fitted line (default 'k').
    showparams : whether to annotate Tm on the plot.
    plotfitted : whether to show the fitted curve.
    factor : signal scaling factor.
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(10, 7))

    if linecolor is None:
        linecolor = "k"
    if pointcolor is None:
        pointcolor = "r"

    data_arr = thermo_results["data"]
    wavelength = thermo_results["fit_wavelength"]
    index = int(np.abs(data_arr[0, :, 0] - wavelength).argmin())

    temperature = data_arr[:, index, 2].astype(float)
    cd_signal = data_arr[:, index, 1].astype(float)

    ax.plot(
        temperature, cd_signal * factor, "o", markersize=4, color=pointcolor, label="data"
    )

    if "fit_params" in thermo_results and plotfitted:
        params = thermo_results["fit_params"]
        temp_smooth = np.linspace(temperature.min(), temperature.max(), 200)
        fit_curve = vant_hoff_model(temp_smooth, *params)
        ax.plot(
            temp_smooth,
            fit_curve * factor,
            "-",
            color=linecolor,
            linewidth=2.5,
            alpha=0.8,
            label="fit",
        )

    if showparams and "Tm (°C)" in thermo_results:
        tm_val = round(float(thermo_results["Tm (°C)"]))
        ax.text(
            0.95,
            0.95,
            f"Tm={tm_val} °C",
            transform=ax.transAxes,
            fontsize=12,
            verticalalignment="top",
            horizontalalignment="right",
            bbox={"boxstyle": "round,pad=0.4", "facecolor": "white", "alpha": 0.8},
        )

    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("CD signal")

    return ax


def extrapolate_and_plot_dg(
    delta_g_arr: np.ndarray,
    ax: plt.Axes | None = None,
) -> tuple[float, float] | tuple[None, None]:
    """
    Linear extrapolation of ΔG vs denaturant concentration to get ΔG(H₂O).

    Parameters
    ----------
    deltaG_arr : shape (n, 2), [denaturant_conc, ΔG].
    ax : optional matplotlib Axes.

    Returns
    -------
    (ΔG_H2O, m_value) in kJ/(mol) and kJ/(mol·M) respectively.
    """
    if len(delta_g_arr) < 2:
        logger.error("Need at least 2 data points for linear extrapolation (got %d).", len(delta_g_arr))
        return None, None

    if ax is None:
        _, ax = plt.subplots(figsize=(8, 6))

    conc_points = delta_g_arr[:, 0]
    delta_g_points = delta_g_arr[:, 1]

    poly = Polynomial.fit(conc_points, delta_g_points, 1)
    m_value = float(poly.coef[1])
    delta_g_h2o = float(poly.coef[0])

    # Display with sign convention from original linear fit
    m_value_abs = abs(m_value)

    logger.info(
        "Extrapolation: ΔG(H₂O) = %.2f kJ/mol, m-value = %.2f kJ/(mol·M)",
        delta_g_h2o,
        m_value_abs,
    )

    ax.plot(conc_points, delta_g_points, "o", markersize=8, color="red", label="ΔG (fitted)")

    conc_line = np.linspace(0, conc_points.max() * 1.1, 100)
    delta_g_line = m_value * conc_line + delta_g_h2o
    ax.plot(conc_line, delta_g_line, "--", color="blue", label="extrapolate")

    ax.plot(
        [0],
        [delta_g_h2o],
        "s",
        markersize=12,
        color="green",
        label=f"ΔG(H₂O) = {delta_g_h2o:.2f} kJ/mol",
        zorder=5,
    )

    ax.set_title("ΔG extrapolation vs denaturant", fontsize=16)
    ax.set_xlabel("Denaturant concentration (M)", fontsize=12)
    ax.set_ylabel("ΔG at 25°C (kJ/mol)", fontsize=12)
    ax.grid(True)
    ax.legend()

    return delta_g_h2o, m_value_abs


# ---------------------------------------------------------------------------
# Global spectral (multi-wavelength) fitting
# ---------------------------------------------------------------------------


def spectral_vant_hoff_model(
    temps: np.ndarray,
    tm: float,
    delta_h: float,
    *baseline_params: float,
) -> np.ndarray:
    """
    Two-state model for all wavelengths simultaneously — vectorized.

    Shared tm, delta_h; per-wavelength baseline params [mn, cn, md, cd].
    Signal = (1-f_u)*native + f_u*denatured.

    Returns flattened signal of shape (n_temps * n_wavelengths,).
    """
    n_wavelengths = len(baseline_params) // 4
    f_u = vanthoff_fraction(temps, tm, delta_h)  # (n_temps,)

    # Reshape baselines to (n_wavelengths, 4): [mn, cn, md, cd] per row
    bl = np.asarray(baseline_params, dtype=float).reshape(n_wavelengths, 4)

    # Broadcast: (n_wavelengths, 1) * (n_temps,) → (n_wavelengths, n_temps)
    y_n = np.multiply.outer(bl[:, 0], temps) + bl[:, 1, None]
    y_d = np.multiply.outer(bl[:, 2], temps) + bl[:, 3, None]

    # Weighted sum + ravel (row-major: interleaves wavelengths)
    return (y_n * (1.0 - f_u) + y_d * f_u).ravel()


def _estimate_tm_from_svd(data_arr: np.ndarray) -> float:
    """Estimate Tm from SVD PC1: temperature at 50% transition amplitude."""
    svd = svd_spectral_analysis(data_arr)
    pc1 = svd["pc_amplitudes"][:, 0]
    temps_svd = svd["temps"]

    # Normalize PC1 to [0, 1]
    pc_min, pc_max = pc1.min(), pc1.max()
    if np.isclose(pc_max, pc_min):
        return float(temps_svd[len(temps_svd) // 2])
    pc1_norm = (pc1 - pc_min) / (pc_max - pc_min)

    # Find where PC1 crosses 0.5
    idx = int(np.searchsorted(pc1_norm, 0.5))
    idx = np.clip(idx, 1, len(temps_svd) - 1)

    t_lo, t_hi = float(temps_svd[idx - 1]), float(temps_svd[idx])
    y_lo, y_hi = float(pc1_norm[idx - 1]), float(pc1_norm[idx])
    dy = y_hi - y_lo
    if np.isclose(dy, 0):
        return (t_lo + t_hi) / 2.0
    return t_lo + (0.5 - y_lo) * (t_hi - t_lo) / dy


def _spectral_fit_score(
    temps: np.ndarray,
    y_obs: np.ndarray,
    p0: list[float],
    lower: list[float],
    upper: list[float],
    maxfev: int,
) -> tuple[np.ndarray | None, np.ndarray | None, float]:
    """Attempt a single spectral fit, return (popt, pcov, r_squared)."""
    try:
        popt, pcov = curve_fit(
            spectral_vant_hoff_model,
            temps,
            y_obs,
            p0=p0,
            bounds=(lower, upper),
            maxfev=maxfev,
        )
    except RuntimeError:
        return None, None, -np.inf

    tm, dh = popt[0], popt[1]
    y_pred = spectral_vant_hoff_model(temps, tm, dh, *popt[2:])
    ss_res = float(np.sum((y_obs - y_pred) ** 2))
    ss_tot = float(np.sum((y_obs - np.mean(y_obs)) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    return popt, pcov, r2


def spectral_global_fit(
    data_arr: np.ndarray,
    n_edge: int = 4,
    n_restarts: int = 5,
) -> dict[str, Any]:
    """
    Fit two-state van't Hoff model to all wavelengths simultaneously.

    Uses SVD-based initial Tm estimate + multiple random restarts to avoid
    local minima. Rejects fits where Tm falls outside the measured range.

    Parameters
    ----------
    data_arr : shape (n_temps, n_wavelengths, 3), [wavelength, signal, temp].
    n_edge : points for baseline estimation per wavelength.
    n_restarts : number of random-start attempts (in addition to SVD + midpoint).

    Returns
    -------
    dict with Tm, ΔH, ΔG_25C, per-wavelength baselines, R², fit convergence info.
    """
    n_temps, n_wls, n_cols = data_arr.shape
    if n_cols != 3:
        raise DataError(
            f"Expected data_arr shape (n_temps, n_wavelengths, 3), got {data_arr.shape}"
        )

    temps_raw = data_arr[:, 0, 2].astype(float)
    order = np.argsort(temps_raw)
    temps = temps_raw[order]
    t_min, t_max = float(temps.min()), float(temps.max())

    signals_matrix = np.empty((n_temps, n_wls))
    for j in range(n_wls):
        sig = data_arr[:, j, 1].astype(float)
        signals_matrix[:, j] = sig[order]

    if n_temps < 2 * n_edge:
        raise DataError(f"Too few temperature points ({n_temps}) for baseline estimation.")

    # --- Per-wavelength baseline estimates ---
    init_baselines: list[float] = []
    lower_bl: list[float] = []
    upper_bl: list[float] = []

    n_idx_slice = slice(0, n_edge)
    d_idx_slice = slice(-n_edge, None)

    for j in range(n_wls):
        sig = signals_matrix[:, j]
        mn, cn, *_ = linregress(temps[n_idx_slice], sig[n_idx_slice])
        md, cd, *_ = linregress(temps[d_idx_slice], sig[d_idx_slice])
        init_baselines.extend([mn, cn, md, cd])

        sig_min, sig_max = sig.min(), sig.max()
        sig_span = max(sig_max - sig_min, 0.1)
        margin = max(sig_span * 5, 20.0)
        lower_bl.extend([-margin, sig_min - margin, -margin, sig_min - margin])
        upper_bl.extend([margin, sig_max + margin, margin, sig_max + margin])

    # Tm bounds: strictly within measured temperature range
    lower_tm_bound = [t_min, 1e3]
    upper_tm_bound = [t_max, 1e6]
    lower_all = lower_tm_bound + lower_bl
    upper_all = upper_tm_bound + upper_bl

    y_obs = signals_matrix.T.ravel()  # flatten: [wl1, wl2, ...]
    maxfev = DEFAULT_FIT_MAXFEV * (n_wls + 1)

    # --- Build candidate initial Tm guesses ---
    tm_guesses: list[float] = []

    # SVD-based estimate
    try:
        svd_tm = _estimate_tm_from_svd(data_arr)
        if t_min - 5 < svd_tm < t_max + 5:
            tm_guesses.append(svd_tm)
    except Exception:
        pass

    # Temperature midpoint
    tm_guesses.append(float(temps[n_temps // 2]))

    # Additional grid: scan across the temperature range
    for i in range(1, n_restarts):
        frac = i / (n_restarts)  # 0.2, 0.4, 0.6, 0.8
        tm_guesses.append(t_min + frac * (t_max - t_min))

    # Also try single-wavelength result as a fallback
    try:
        r_single = analyze_and_fit_curves(data_arr, wavelength="auto", n_edge=n_edge)
        tm_single = float(r_single["Tm (°C)"])
        if t_min - 5 < tm_single < t_max + 5:
            tm_guesses.insert(0, tm_single)  # highest priority
    except Exception:
        pass

    # Deduplicate while preserving order
    seen: set[float] = set()
    tm_unique: list[float] = []
    for g in tm_guesses:
        r = round(g, 1)
        if r not in seen:
            seen.add(r)
            tm_unique.append(g)

    # --- Multi-start fitting with early termination ---
    best_score = -np.inf
    best_popt: np.ndarray | None = None
    best_pcov: np.ndarray | None = None
    all_attempts: list[dict] = []
    converged_flag = False

    for tm0 in tm_unique:
        p0 = [tm0, DEFAULT_INIT_DELTA_H] + init_baselines
        popt, pcov, r2 = _spectral_fit_score(temps, y_obs, p0, lower_all, upper_all, maxfev)
        all_attempts.append({"tm0": tm0, "r2": r2, "converged": popt is not None})

        if popt is not None and r2 > best_score:
            tm_candidate = popt[0]
            if t_min <= tm_candidate <= t_max:
                best_score = r2
                best_popt = popt
                best_pcov = pcov
                converged_flag = True

                # Early termination: if R² is excellent, skip remaining restarts
                if r2 > 0.995:
                    break

    if best_popt is None:
        # None of the valid-range fits converged — use best regardless
        for attempt in sorted(all_attempts, key=lambda x: x["r2"], reverse=True):
            if attempt["converged"]:
                # Re-fit to get popt (reconstruct from best attempt)
                p0 = [attempt["tm0"], DEFAULT_INIT_DELTA_H] + init_baselines
                popt, pcov, _ = _spectral_fit_score(temps, y_obs, p0, lower_all, upper_all, maxfev)
                if popt is not None:
                    best_popt = popt
                    best_pcov = pcov
                    best_score = attempt["r2"]
                    logger.warning(
                        "Best-fit Tm=%.1f outside data range [%.1f, %.1f]. Treat with caution.",
                        popt[0], t_min, t_max,
                    )
                    break

    if best_popt is None:
        raise FitError("All spectral fit attempts failed to converge.")

    tm_fit, delta_h_fit = best_popt[0], best_popt[1]
    baseline_params_fit = best_popt[2:]

    y_pred = spectral_vant_hoff_model(temps, tm_fit, delta_h_fit, *baseline_params_fit)
    ss_res = float(np.sum((y_obs - y_pred) ** 2))
    ss_tot = float(np.sum((y_obs - np.mean(y_obs)) ** 2))
    r_squared = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    t_ref_k = T_REF_C + T_KELVIN_OFFSET
    tm_fit_k = tm_fit + T_KELVIN_OFFSET
    delta_g_ref = delta_h_fit * (1.0 - t_ref_k / tm_fit_k)

    per_wl_baselines = {}
    for j in range(n_wls):
        mn = baseline_params_fit[4 * j]
        cn = baseline_params_fit[4 * j + 1]
        md = baseline_params_fit[4 * j + 2]
        cd = baseline_params_fit[4 * j + 3]
        per_wl_baselines[j] = {"native": (mn, cn), "denatured": (md, cd)}

    logger.info(
        "Spectral global fit: Tm=%.2f °C, ΔH=%.2f kJ/mol, ΔG_25=%.2f kJ/mol, R²=%.4f, valid=%s",
        tm_fit, delta_h_fit / 1000.0, delta_g_ref / 1000.0, r_squared, converged_flag,
    )

    return {
        "Tm (°C)": tm_fit,
        "ΔH (kJ/mol)": delta_h_fit / 1000.0,
        "ΔG_25C (kJ/mol)": delta_g_ref / 1000.0,
        "R²": r_squared,
        "fit_params_global": (tm_fit, delta_h_fit),
        "per_wl_baselines": per_wl_baselines,
        "temps": temps,
        "signals_matrix": signals_matrix,
        "full_params": best_popt,
        "pcov": best_pcov,
        "data": data_arr,
        "converged": converged_flag,
        "n_attempts": len(all_attempts),
    }


def svd_spectral_analysis(
    data_arr: np.ndarray,
) -> dict[str, Any]:
    """
    SVD decomposition of temperature-dependent CD spectra.

    Use singular values to assess whether the transition is two-state and
    to denoise the data before fitting.

    Parameters
    ----------
    data_arr : shape (n_temps, n_wavelengths, 3), [wavelength, signal, temp].

    Returns
    -------
    dict with U, S, Vt matrices, singular value fractions, and denoised matrix.
    """
    n_temps, n_wls, n_cols = data_arr.shape
    if n_cols != 3:
        raise DataError(f"Expected data_arr shape (n_temps, n_wavelengths, 3), got {data_arr.shape}")

    wavelengths = data_arr[0, :, 0].astype(float)
    temps_raw = data_arr[:, 0, 2].astype(float)
    order = np.argsort(temps_raw)
    temps = temps_raw[order]

    # Build signal matrix: wavelengths as columns, temperatures as rows
    signals_matrix = np.empty((n_temps, n_wls))
    for j in range(n_wls):
        sig = data_arr[:, j, 1].astype(float)
        signals_matrix[:, j] = sig[order]

    # Center the data (subtract mean spectrum)
    mean_spectrum = signals_matrix.mean(axis=0)
    centered = signals_matrix - mean_spectrum

    # Mean-center before SVD (essential for interpreting basis spectra)
    u, s, vt = np.linalg.svd(centered, full_matrices=False)

    # Fraction of variance explained by each component
    var_fraction = s**2 / np.sum(s**2)
    cumulative = np.cumsum(var_fraction)

    # Denoise using first k components (k = number with var_fraction > 1%)
    k = int(np.sum(var_fraction > 0.01))
    k = max(k, 1)  # at least 1
    denoised = u[:, :k] @ np.diag(s[:k]) @ vt[:k, :] + mean_spectrum

    # Temperature-dependent amplitudes (right singular vectors scaled by S)
    # The columns of U represent how each temperature projects onto each component
    pc_amplitudes = u * s  # shape (n_temps, k)

    logger.info(
        "SVD: %d wavelengths, %d temps. Top 3 singular values: %.1f%%, %.1f%%, %.1f%%",
        n_wls, n_temps,
        var_fraction[0] * 100, var_fraction[1] * 100,
        var_fraction[2] * 100 if len(var_fraction) > 2 else 0,
    )

    return {
        "u": u,
        "s": s,
        "vt": vt,
        "var_fraction": var_fraction,
        "cumulative_var": cumulative,
        "denoised": denoised,
        "wavelengths": wavelengths,
        "temps": temps,
        "signals_matrix": signals_matrix,
        "pc_amplitudes": pc_amplitudes,
        "n_significant": k,
        "data": data_arr,
    }


def plot_spectral_fit_results(
    result: dict[str, Any],
) -> None:
    """
    Plot global spectral fit diagnostics.

    Parameters
    ----------
    result : output from spectral_global_fit.
    """
    signals = result["signals_matrix"]
    temps = result["temps"]
    data_arr = result["data"]
    n_temps, n_wls = signals.shape
    tm = result["Tm (°C)"]
    tm_idx = int(np.abs(temps - tm).argmin())

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # Top-left: all spectra at all temperatures (like plot_dtemp_cd)
    ax = axes[0, 0]
    wavelengths = data_arr[0, :, 0].astype(float)
    norm = plt.Normalize(vmin=temps.min(), vmax=temps.max())
    sm = cm.ScalarMappable(norm=norm, cmap=cm.coolwarm)
    for i in range(n_temps):
        ax.plot(wavelengths, signals[i, :], color=sm.to_rgba(temps[i]), lw=1.5)
    cbar = plt.colorbar(sm, ax=ax)
    cbar.set_label("Temperature (°C)")
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("CD (mdeg)")
    ax.set_title("All spectra")
    ax.grid(True, linestyle="--", alpha=0.4)

    # Top-right: native vs denatured reconstructed spectra at Tm
    ax = axes[0, 1]
    baselines = result["per_wl_baselines"]
    native_spectrum = np.array([baselines[j]["native"][0] * tm + baselines[j]["native"][1]
                                 for j in range(n_wls)])
    denatured_spectrum = np.array([baselines[j]["denatured"][0] * tm + baselines[j]["denatured"][1]
                                    for j in range(n_wls)])
    actual_tm_spectrum = signals[tm_idx, :]
    ax.plot(wavelengths, native_spectrum, "b-", lw=2, label="Native (reconstructed)")
    ax.plot(wavelengths, denatured_spectrum, "r-", lw=2, label="Denatured (reconstructed)")
    ax.plot(wavelengths, actual_tm_spectrum, "k--", lw=1.5, label=f"Observed at {temps[tm_idx]:.1f}°C")
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("CD (mdeg)")
    ax.set_title("Native / Denatured spectra at Tm")
    ax.legend(fontsize=9)
    ax.grid(True, linestyle="--", alpha=0.4)

    # Bottom-left: fractional population vs T
    ax = axes[1, 0]
    tm_fit, delta_h_fit = result["fit_params_global"]
    t_smooth = np.linspace(temps.min(), temps.max(), 200)
    f_u_smooth = vanthoff_fraction(t_smooth, tm_fit, delta_h_fit)
    ax.plot(t_smooth, f_u_smooth, "k-", lw=2)
    ax.axvline(tm_fit, color="gray", linestyle="--", alpha=0.6)
    ax.axhline(0.5, color="gray", linestyle="--", alpha=0.4)
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("Fraction unfolded")
    ax.set_title(f"Two-state population (Tm = {tm_fit:.1f} °C)")
    ax.grid(True, linestyle="--", alpha=0.4)

    # Bottom-right: fit residuals heatmap
    ax = axes[1, 1]
    y_pred = spectral_vant_hoff_model(temps, tm_fit, delta_h_fit, *result["full_params"][2:])
    y_pred_2d = y_pred.reshape(n_wls, n_temps).T
    residuals = signals - y_pred_2d
    im = ax.imshow(
        residuals, aspect="auto", origin="lower",
        extent=[wavelengths[0], wavelengths[-1], temps.min(), temps.max()],
        cmap=cm.RdBu_r, vmin=-np.abs(residuals).max(), vmax=np.abs(residuals).max(),
    )
    cbar2 = plt.colorbar(im, ax=ax)
    cbar2.set_label("Residual (mdeg)")
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("Temperature (°C)")
    ax.set_title("Fit residuals")

    fig.suptitle(
        f"Global Spectral Fit: Tm = {result['Tm (°C)']:.1f} °C, "
        f"ΔH = {result['ΔH (kJ/mol)']:.1f} kJ/mol, R² = {result['R²']:.4f}",
        fontsize=13,
    )
    fig.tight_layout()
    plt.show()
