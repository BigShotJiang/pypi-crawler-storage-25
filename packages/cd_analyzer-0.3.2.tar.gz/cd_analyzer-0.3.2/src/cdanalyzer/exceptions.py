class CDAnalyzerError(Exception):
    """Base exception for all cdanalyzer errors."""

    pass


class ParseError(CDAnalyzerError):
    """Raised when .dsx file parsing fails."""

    pass


class FitError(CDAnalyzerError):
    """Raised when curve fitting fails."""

    pass


class DataError(CDAnalyzerError):
    """Raised when data is insufficient or malformed."""

    pass
