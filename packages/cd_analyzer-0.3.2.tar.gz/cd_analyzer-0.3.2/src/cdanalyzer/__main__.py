import argparse
import logging
import sys

from .analysis import (
    analyze_and_fit_curves,
    help_read_multifile,
    parse_dsx,
    plot_dtemp_cd,
    plot_fitted_curves,
    plot_spectral_fit_results,
    spectral_global_fit,
    svd_spectral_analysis,
)
from .batch import batch_analyze

logger = logging.getLogger(__name__)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="cdanalyzer",
        description="CD Spectroscopy Data Analysis Toolkit",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # parse-dsx
    p_parse = sub.add_parser("parse-dsx", help="Parse a single .dsx file")
    p_parse.add_argument("file", type=str, help="Path to .dsx file")
    p_parse.add_argument("--debug", action="store_true", help="Enable debug logging")

    # analyze (single-wavelength)
    p_analyze = sub.add_parser("analyze", help="Fit melting curve from multi-file CD data")
    p_analyze.add_argument("path", type=str, help="Directory containing .dsx files")
    p_analyze.add_argument(
        "--wavelength",
        type=str,
        default="auto",
        help="Wavelength in nm, or 'auto' (default: auto)",
    )
    p_analyze.add_argument(
        "--edge", type=int, default=4, help="Points for baseline fitting (default: 4)"
    )

    # spectral (global multi-wavelength fit)
    p_spec = sub.add_parser("spectral", help="Global spectral fit (all wavelengths)")
    p_spec.add_argument("path", type=str, help="Directory containing .dsx files")
    p_spec.add_argument(
        "--edge", type=int, default=4, help="Points for baseline estimation (default: 4)"
    )

    # svd
    p_svd = sub.add_parser("svd", help="SVD analysis of temperature-dependent CD spectra")
    p_svd.add_argument("path", type=str, help="Directory containing .dsx files")

    # batch
    p_batch = sub.add_parser("batch", help="Batch analyze multiple sample directories")
    p_batch.add_argument("input", type=str, help="Root directory containing sample subdirectories")
    p_batch.add_argument("output", type=str, help="Output directory for reports and plots")
    p_batch.add_argument(
        "--wavelength", "-w", type=float, default=None,
        help="Single-wavelength mode: fit only this wavelength (fast).",
    )
    p_batch.add_argument(
        "--greedy", "-g", action="store_true",
        help="Greedy mode: scan candidate wavelengths and pick the best R².",
    )
    p_batch.add_argument(
        "--pattern", type=str, default="*.dsx", help="Glob pattern for .dsx files (default: *.dsx)"
    )

    # plot
    p_plot = sub.add_parser("plot", help="Plot temperature-dependent CD spectra")
    p_plot.add_argument("path", type=str, help="Directory containing .dsx files")
    p_plot.add_argument("--smooth", type=int, default=None, help="Gaussian smooth sigma")
    p_plot.add_argument(
        "--factor", type=float, default=1.0, help="CD signal scaling factor"
    )

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if args.command == "parse-dsx":
        logging.getLogger("cdanalyzer.analysis").setLevel(
            logging.DEBUG if args.debug else logging.WARNING
        )
        try:
            results = parse_dsx(args.file, debug=args.debug)
            for i, (df, _meta) in enumerate(results):
                print(f"--- Repeat {i+1} ---")
                print(df.head())
                print()
        except Exception as e:
            logger.error("Parse failed: %s", e)
            sys.exit(1)

    elif args.command == "analyze":
        try:
            import matplotlib.pyplot as plt

            data_arr = help_read_multifile(args.path)
            wavelength = float(args.wavelength) if args.wavelength != "auto" else "auto"
            thermo = analyze_and_fit_curves(data_arr, wavelength=wavelength, n_edge=args.edge)
            fig, ax = plt.subplots(figsize=(10, 7))
            plot_fitted_curves(thermo, ax=ax, showparams=True)
            plt.show()
        except Exception as e:
            logger.error("Analysis failed: %s", e)
            sys.exit(1)

    elif args.command == "spectral":
        try:
            data_arr = help_read_multifile(args.path)
            result = spectral_global_fit(data_arr, n_edge=args.edge)
            print(f"Tm = {result['Tm (°C)']:.2f} °C")
            print(f"ΔH = {result['ΔH (kJ/mol)']:.2f} kJ/mol")
            print(f"ΔG (25°C) = {result['ΔG_25C (kJ/mol)']:.2f} kJ/mol")
            print(f"R² = {result['R²']:.4f}")
            plot_spectral_fit_results(result)
        except Exception as e:
            logger.error("Spectral fit failed: %s", e)
            sys.exit(1)

    elif args.command == "svd":
        try:
            data_arr = help_read_multifile(args.path)
            svd_result = svd_spectral_analysis(data_arr)
            var = svd_result["var_fraction"]
            print(f"Wavelengths: {len(svd_result['wavelengths'])}, "
                  f"Temperatures: {len(svd_result['temps'])}")
            print("SVD components (variance explained):")
            for i in range(min(5, len(var))):
                print(f"  PC{i+1}: {var[i]*100:.1f}%  (cumulative: {svd_result['cumulative_var'][i]*100:.1f}%)")
            print(f"Significant components: {svd_result['n_significant']}")
            if svd_result["n_significant"] <= 2:
                print("→ Consistent with a two-state transition.")
            else:
                print("→ Possible intermediate states or multiple transitions.")
        except Exception as e:
            logger.error("SVD analysis failed: %s", e)
            sys.exit(1)

    elif args.command == "batch":
        try:
            wl_arg = "greedy" if args.greedy else args.wavelength
            results = batch_analyze(
                args.input, args.output,
                wavelength=wl_arg,
                glob_pattern=args.pattern,
            )
            n = len(results)
            if args.greedy:
                mode = "greedy (best R² per sample)"
            elif args.wavelength:
                mode = f"single-wl @ {args.wavelength} nm"
            else:
                mode = "full"
            print(f"Batch complete ({mode}): {n} sample(s) processed.")
            print(f"Reports and figures: {args.output}")
        except Exception as e:
            logger.error("Batch analysis failed: %s", e)
            sys.exit(1)

    elif args.command == "plot":
        try:
            import matplotlib.pyplot as plt

            data_arr = help_read_multifile(args.path)
            fig, ax = plt.subplots(figsize=(10, 7))
            plot_dtemp_cd(ax, data_arr, factor=args.factor, smooth=args.smooth)
            plt.show()
        except Exception as e:
            logger.error("Plot failed: %s", e)
            sys.exit(1)


if __name__ == "__main__":
    main()
