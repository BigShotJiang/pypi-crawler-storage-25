"""Batch analysis: auto-discover .dsx directories and produce full reports."""

import logging
from pathlib import Path
from typing import Any

import matplotlib
import matplotlib.cm as cm
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .analysis import (
    analyze_and_fit_curves,
    find_best_wavelength,
    help_read_multifile,
    plot_fitted_curves,
    spectral_global_fit,
    svd_spectral_analysis,
)

matplotlib.use("Agg")  # non-interactive backend for batch

logger = logging.getLogger(__name__)


def _find_sample_dirs(input_root: Path) -> list[Path]:
    """Find subdirectories containing .dsx files."""
    dirs: list[Path] = []
    for p in sorted(input_root.iterdir()):
        if p.is_dir() and list(p.rglob("*.dsx")):
            dirs.append(p)
    return dirs


def _plot_low_t_spectrum(
    data_arr: np.ndarray,
    sample_name: str,
    output_dir: Path,
    n_low: int = 3,
) -> None:
    """Plot the averaged low-temperature CD spectrum (first n_low temps)."""
    wavelengths = data_arr[0, :, 0].astype(float)
    temps = data_arr[:, 0, 2].astype(float)
    order = np.argsort(temps)
    temps_sorted = temps[order]

    # Average the lowest n_low temperatures' spectra
    n_low_actual = min(n_low, len(temps_sorted))
    low_indices = order[:n_low_actual]
    low_signals = data_arr[low_indices, :, 1].astype(float)
    mean_spectrum = low_signals.mean(axis=0)
    std_spectrum = low_signals.std(axis=0) if n_low_actual > 1 else np.zeros_like(mean_spectrum)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(wavelengths, mean_spectrum, "b-", lw=2, label=f"Mean ({n_low_actual} lowest T)")
    ax.fill_between(
        wavelengths,
        mean_spectrum - std_spectrum,
        mean_spectrum + std_spectrum,
        alpha=0.25,
        color="b",
    )
    ax.set_xlabel("Wavelength (nm)", fontsize=13)
    ax.set_ylabel("CD (mdeg)", fontsize=13)
    ax.set_title(f"{sample_name} — Low-T CD Spectrum\n"
                 f"(avg of {n_low_actual} spectra: "
                 f"{', '.join(f'{temps_sorted[i]:.0f}' for i in range(n_low_actual))} °C)",
                 fontsize=13)
    ax.grid(True, linestyle="--", alpha=0.4)
    ax.legend()
    fig.tight_layout()
    fig.savefig(output_dir / "spectra_low_T.png", dpi=150)
    plt.close(fig)


def _plot_analysis_dashboard(
    data_arr: np.ndarray,
    thermo_single: dict[str, Any],
    thermo_global: dict[str, Any] | None,
    svd_result: dict[str, Any] | None,
    sample_name: str,
    output_dir: Path,
) -> None:
    """4-panel analysis dashboard: spectra + fitted curve + populations + SVD."""
    temps = thermo_single["temps_sorted"]
    signals_matrix = data_arr[:, :, 1].astype(float)
    wavelengths = data_arr[0, :, 0].astype(float)
    n_temps, n_wls = signals_matrix.shape

    # Sort signals by temperature
    temps_raw = data_arr[:, 0, 2].astype(float)
    order = np.argsort(temps_raw)
    signals_sorted = signals_matrix[order, :]

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # (A) Multi-temperature CD spectra
    ax = axes[0, 0]
    norm = plt.Normalize(vmin=temps.min(), vmax=temps.max())
    sm = cm.ScalarMappable(norm=norm, cmap=cm.coolwarm)
    for i in range(n_temps):
        ax.plot(wavelengths, signals_sorted[i, :], color=sm.to_rgba(temps[i]), lw=1.2)
    cbar = plt.colorbar(sm, ax=ax)
    cbar.set_label("T (°C)")
    ax.set_xlabel("Wavelength (nm)")
    ax.set_ylabel("CD (mdeg)")
    ax.set_title("Temperature-dependent CD spectra")
    ax.grid(True, linestyle="--", alpha=0.4)

    # (B) Single-wavelength melt curve + fit
    ax = axes[0, 1]
    if thermo_single:
        plot_fitted_curves(thermo_single, ax=ax, showparams=True)
        tm_s = thermo_single["Tm (°C)"]
        ax.set_title(f"Single-wl fit @ {thermo_single['fit_wavelength']:.0f} nm  "
                     f"(Tm = {tm_s:.1f} °C)")

    # (C) Fraction unfolded (from spectral fit)
    ax = axes[1, 0]
    if thermo_global and thermo_global.get("converged"):
        tm_g, dh_g = thermo_global["fit_params_global"]
        t_smooth = np.linspace(temps.min(), temps.max(), 200)
        from .analysis import vanthoff_fraction
        f_u = vanthoff_fraction(t_smooth, tm_g, dh_g)
        ax.plot(t_smooth, f_u, "k-", lw=2, label=f"Tm={tm_g:.1f} °C")
        ax.axvline(tm_g, color="gray", ls="--", alpha=0.5)
        ax.axhline(0.5, color="gray", ls="--", alpha=0.3)

        # Overlay single-wl Tm
        if thermo_single:
            ax.axvline(thermo_single["Tm (°C)"], color="red", ls=":", alpha=0.6,
                       label=f"1wl Tm={thermo_single['Tm (°C)']:.1f}")
        ax.legend(fontsize=9)
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("Fraction unfolded")
    ax.set_title("Two-state population (global spectral fit)")
    ax.grid(True, linestyle="--", alpha=0.4)

    # (D) SVD components
    ax = axes[1, 1]
    if svd_result:
        var = svd_result["var_fraction"]
        pc1 = svd_result["pc_amplitudes"][:, 0]
        pc_min, pc_max = pc1.min(), pc1.max()
        span = pc_max - pc_min
        pc1_norm = (pc1 - pc_min) / span if span > 0 else np.zeros_like(pc1)
        ax.plot(svd_result["temps"], pc1_norm, "b-", lw=2, label="PC1 (normalized)")
        if svd_result["n_significant"] >= 2:
            pc2 = svd_result["pc_amplitudes"][:, 1]
            ax.plot(svd_result["temps"], pc2 / np.abs(pc2).max(), "r--", lw=1.5, label="PC2")
        ax.set_xlabel("Temperature (°C)")
        ax.set_ylabel("Normalized amplitude")
        ax.set_title(f"SVD (PC1={var[0]*100:.1f}%, k={svd_result['n_significant']})"
                     f"  {'→ two-state' if svd_result['n_significant']<=2 else '→ multi-state'}")
        ax.legend(fontsize=9)
        ax.grid(True, linestyle="--", alpha=0.4)

    fig.suptitle(f"{sample_name} — Analysis Dashboard", fontsize=14, fontweight="bold")
    fig.tight_layout()
    fig.savefig(output_dir / "analysis.png", dpi=150)
    plt.close(fig)


def _export_excel(
    data_arr: np.ndarray,
    thermo_single: dict[str, Any] | None,
    thermo_global: dict[str, Any] | None,
    svd_result: dict[str, Any] | None,
    sample_name: str,
    output_dir: Path,
) -> None:
    """Export raw CD data, fit parameters, and SVD results to Excel."""
    wavelengths = data_arr[0, :, 0].astype(float)
    temps_raw = data_arr[:, 0, 2].astype(float)
    order = np.argsort(temps_raw)
    temps_sorted = temps_raw[order]
    signals_sorted = data_arr[:, :, 1].astype(float)[order, :]

    with pd.ExcelWriter(output_dir / "data.xlsx", engine="openpyxl") as writer:
        # Sheet 1: Raw data (wavelengths as rows, temperatures as columns)
        df_raw = pd.DataFrame(
            signals_sorted.T,
            index=pd.Index(wavelengths, name="Wavelength_nm"),
            columns=[f"{t:.1f}C" for t in temps_sorted],
        )
        df_raw.to_excel(writer, sheet_name="CD_signals")

        # Sheet 2: Fit parameters
        rows = []
        if thermo_single:
            rows.append({
                "Method": "Single-wavelength",
                "Wavelength (nm)": thermo_single.get("fit_wavelength", ""),
                "Tm (C)": f"{thermo_single['Tm (°C)']:.2f}",
                "dH (kJ/mol)": f"{thermo_single['ΔH (kJ/mol)']:.2f}",
                "dG_25C (kJ/mol)": f"{thermo_single['ΔG_25C (kJ/mol)']:.2f}",
                "R2": f"{thermo_single.get('R²', ''):.4f}",
            })
        if thermo_global:
            rows.append({
                "Method": "Global spectral",
                "Wavelength (nm)": "all",
                "Tm (C)": f"{thermo_global['Tm (°C)']:.2f}",
                "dH (kJ/mol)": f"{thermo_global['ΔH (kJ/mol)']:.2f}",
                "dG_25C (kJ/mol)": f"{thermo_global['ΔG_25C (kJ/mol)']:.2f}",
                "R2": f"{thermo_global.get('R²', ''):.4f}",
            })
        if rows:
            pd.DataFrame(rows).to_excel(writer, sheet_name="Fit_results", index=False)

        # Sheet 3: SVD
        if svd_result:
            var = svd_result["var_fraction"]
            n_show = min(5, len(var))
            df_svd = pd.DataFrame({
                "Component": [f"PC{i+1}" for i in range(n_show)],
                "Variance_explained": [f"{var[i]*100:.2f}%" for i in range(n_show)],
                "Cumulative": [f"{svd_result['cumulative_var'][i]*100:.2f}%" for i in range(n_show)],
                "Significant": ["Yes" if i < svd_result["n_significant"] else "No" for i in range(n_show)],
            })
            df_svd.to_excel(writer, sheet_name="SVD", index=False)


def _generate_sample_report(
    sample_name: str,
    thermo_single: dict[str, Any] | None,
    thermo_global: dict[str, Any] | None,
    svd_result: dict[str, Any] | None,
    n_temps: int,
    n_wls: int,
) -> str:
    """Generate a Markdown report section for a single sample."""
    lines = [f"## {sample_name}", ""]
    lines.append(f"- **Data**: {n_temps} temperatures × {n_wls} wavelengths")
    lines.append("")

    # Single-wavelength
    if thermo_single:
        lines.append("### Single-wavelength fit")
        lines.append("")
        lines.append("| Parameter | Value |")
        lines.append("|-----------|-------|")
        lines.append(f"| Wavelength | {thermo_single['fit_wavelength']:.0f} nm |")
        lines.append(f"| Tm | {thermo_single['Tm (°C)']:.2f} °C |")
        lines.append(f"| ΔH | {thermo_single['ΔH (kJ/mol)']:.2f} kJ/mol |")
        lines.append(f"| ΔG (25°C) | {thermo_single['ΔG_25C (kJ/mol)']:.2f} kJ/mol |")
        lines.append(f"| R² | {thermo_single.get('R²', 0):.4f} |")
        lines.append("")

    # Global spectral
    if thermo_global:
        lines.append("### Global spectral fit (all wavelengths)")
        lines.append("")
        lines.append("| Parameter | Value |")
        lines.append("|-----------|-------|")
        lines.append(f"| Tm | {thermo_global['Tm (°C)']:.2f} °C |")
        lines.append(f"| ΔH | {thermo_global['ΔH (kJ/mol)']:.2f} kJ/mol |")
        lines.append(f"| ΔG (25°C) | {thermo_global['ΔG_25C (kJ/mol)']:.2f} kJ/mol |")
        lines.append(f"| R² | {thermo_global.get('R²', 0):.4f} |")
        lines.append(f"| Converged | {thermo_global.get('converged', False)} |")
        lines.append("")

    # SVD
    if svd_result:
        var = svd_result["var_fraction"]
        lines.append("### SVD analysis")
        lines.append("")
        n_show = min(3, len(var))
        for i in range(n_show):
            lines.append(f"- **PC{i+1}**: {var[i]*100:.1f}% variance")
        n_sig = svd_result["n_significant"]
        lines.append(f"- Significant components: {n_sig}")
        lines.append(f"- Interpretation: {'Two-state' if n_sig <= 2 else 'Multi-state / intermediate(s) detected'}")
        lines.append("")

    # Images
    lines.append("### Figures")
    lines.append("")
    lines.append("![Low-T spectrum](spectra_low_T.png)")
    lines.append("![Analysis dashboard](analysis.png)")
    lines.append("")

    return "\n".join(lines)


def batch_analyze(
    input_root: str | Path,
    output_root: str | Path,
    *,
    wavelength: float | str | None = None,
    glob_pattern: str = "*.dsx",
) -> dict[str, dict[str, Any]]:
    """
    Batch analyze all .dsx sample directories under input_root.

    Two modes:
    - wavelength=None (default): full analysis — single-wl auto + global spectral + SVD
    - wavelength=float: single-wavelength only at specified nm
    - wavelength="greedy": scan candidate wavelengths, pick best R²

    For each sample subdirectory, produces:
      - reports.md (per-sample + summary at output_root)
      - spectra_low_T.png
      - analysis.png (4-panel dashboard, or simplified single-wl only)
      - data.xlsx

    Directory structure expected:
      input_root/
          sample_A/
              20.dsx ... 90.dsx  buffer.dsx
          sample_B/
              20.dsx ... 90.dsx  buffer.dsx

    Parameters
    ----------
    input_root : root directory containing sample subdirectories.
    output_root : where to write output subdirectories and reports.
    wavelength : if float, fit only this wavelength; None for full multi-wavelength analysis.
    glob_pattern : pattern for .dsx files (default "*.dsx").

    Returns
    -------
    dict mapping sample_name -> combined thermo results.
    """
    input_root = Path(input_root)
    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)

    single_wl_mode = wavelength is not None and wavelength != "greedy"
    greedy_mode = wavelength == "greedy"

    sample_dirs = _find_sample_dirs(input_root)
    if not sample_dirs:
        logger.warning("No directories with .dsx files found under %s", input_root)
        return {}

    logger.info("Found %d sample directories (mode: %s)",
                 len(sample_dirs),
                 "greedy" if greedy_mode else f"single-wl @ {wavelength} nm" if single_wl_mode else "full")

    all_results: dict[str, dict[str, Any]] = {}
    summary_rows: list[dict[str, str]] = []

    for sample_dir in sample_dirs:
        sample_name = sample_dir.name
        out_dir = output_root / sample_name
        out_dir.mkdir(parents=True, exist_ok=True)

        logger.info("Processing: %s", sample_name)

        try:
            data_arr = help_read_multifile(sample_dir)
        except Exception as e:
            logger.error("  Failed to parse %s: %s", sample_name, e)
            summary_rows.append({
                "Sample": sample_name,
                "Tm": "PARSE_FAIL",
                "Status": str(e)[:40],
            })
            continue

        n_temps, n_wls = data_arr.shape[0], data_arr.shape[1]

        # Single-wavelength fit
        thermo_single: dict[str, Any] | None = None
        greedy_info: dict[str, Any] | None = None

        if greedy_mode:
            try:
                greedy_info = find_best_wavelength(data_arr, step_nm=3)
                best_wl = greedy_info["best_wavelength"]
                thermo_single = analyze_and_fit_curves(data_arr, wavelength=best_wl)
                logger.info("  Greedy best: %.1f nm, Tm=%.1f °C, R²=%.4f",
                             best_wl, thermo_single["Tm (°C)"], thermo_single["R²"])
            except Exception as e:
                logger.warning("  Greedy scan failed: %s", e)
        else:
            wl_arg = wavelength if single_wl_mode else "auto"
            try:
                thermo_single = analyze_and_fit_curves(data_arr, wavelength=wl_arg)
            except Exception as e:
                logger.warning("  Single-wl fit failed: %s", e)

        # Global spectral fit + SVD (full mode only)
        thermo_global: dict[str, Any] | None = None
        svd_result: dict[str, Any] | None = None

        if not single_wl_mode:
            try:
                thermo_global = spectral_global_fit(data_arr, n_restarts=3)
            except Exception as e:
                logger.warning("  Global spectral fit failed: %s", e)

            try:
                svd_result = svd_spectral_analysis(data_arr)
            except Exception as e:
                logger.warning("  SVD failed: %s", e)

        # --- Generate outputs ---

        # 1. Low-temperature spectrum plot
        try:
            _plot_low_t_spectrum(data_arr, sample_name, out_dir)
        except Exception as e:
            logger.warning("  Low-T plot failed: %s", e)

        # 2. Analysis dashboard plot
        try:
            _plot_analysis_dashboard(
                data_arr, thermo_single, thermo_global, svd_result, sample_name, out_dir
            )
        except Exception as e:
            logger.warning("  Dashboard plot failed: %s", e)

        # 3. Excel export
        try:
            _export_excel(data_arr, thermo_single, thermo_global, svd_result, sample_name, out_dir)
        except Exception as e:
            logger.warning("  Excel export failed: %s", e)

        # 4. Per-sample report
        report_md = _generate_sample_report(
            sample_name, thermo_single, thermo_global, svd_result, n_temps, n_wls
        )
        (out_dir / "report.md").write_text(report_md, encoding="utf-8")

        # --- Collect summary ---
        if single_wl_mode or greedy_mode:
            tm_s = f"{thermo_single['Tm (°C)']:.2f}" if thermo_single else "FAIL"
            dh_s = f"{thermo_single.get('ΔH (kJ/mol)', 0):.1f}" if thermo_single else ""
            r2_s = f"{thermo_single.get('R²', 0):.4f}" if thermo_single else ""
            wl_label = f"{thermo_single['fit_wavelength']:.0f}" if thermo_single else "?"
            if greedy_mode and greedy_info:
                wl_label += " (greedy)"
            summary_rows.append({
                "Sample": sample_name,
                "Tm (°C)": tm_s,
                "ΔH (kJ/mol)": dh_s,
                "R²": r2_s,
                "Wavelength (nm)": wl_label,
            })
        else:
            tm_s = f"{thermo_single['Tm (°C)']:.2f}" if thermo_single else "FAIL"
            tm_g = f"{thermo_global['Tm (°C)']:.2f}" if thermo_global else "FAIL"
            dh_g = f"{thermo_global.get('ΔH (kJ/mol)', 0):.1f}" if thermo_global else ""
            r2_g = f"{thermo_global.get('R²', 0):.4f}" if thermo_global else ""
            two_state = "Yes" if svd_result and svd_result["n_significant"] <= 2 else "No"
            ok = "Yes" if thermo_global and thermo_global.get("converged") else "No"
            summary_rows.append({
                "Sample": sample_name,
                "Tm_1wl (°C)": tm_s,
                "Tm_global (°C)": tm_g,
                "ΔH_global (kJ/mol)": dh_g,
                "R²_global": r2_g,
                "Converged": ok,
                "Two-state": two_state,
            })

        all_results[sample_name] = {
            "single": thermo_single,
            "global": thermo_global,
            "svd": svd_result,
        }

    # --- Write summary report ---
    _write_summary_report(summary_rows, output_root)

    logger.info("Batch analysis complete. %d/%d samples processed.", len(all_results), len(sample_dirs))
    return all_results


def _write_summary_report(rows: list[dict[str, str]], output_root: Path) -> None:
    """Write overall summary reports.md."""
    if not rows:
        return

    cols = list(rows[0].keys())
    lines = ["# CD Analysis Batch Report", ""]
    lines.append(f"**Samples analyzed**: {len(rows)}")
    lines.append("")

    # Summary table
    header = "| " + " | ".join(cols) + " |"
    sep = "|" + "|".join(["---" for _ in cols]) + "|"
    lines.append(header)
    lines.append(sep)
    for row in rows:
        vals = [str(row.get(c, "")) for c in cols]
        lines.append("| " + " | ".join(vals) + " |")
    lines.append("")

    # Per-sample links
    lines.append("## Per-sample reports")
    lines.append("")
    for row in rows:
        name = row["Sample"]
        lines.append(f"- [{name}]({name}/report.md)")
    lines.append("")

    (output_root / "reports.md").write_text("\n".join(lines), encoding="utf-8")
    logger.info("Summary report written to %s", output_root / "reports.md")
