# Copyright 2023 Iguazio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import datetime
from typing import Union

import mlrun.alerts
import mlrun.common.formatters
import mlrun.common.runtimes.constants
import mlrun.common.schemas
import mlrun.common.schemas.model_monitoring.constants as mm_constants
import mlrun.errors
import mlrun.lists
import mlrun.model_monitoring

from ..config import config
from ..utils import logger
from .base import RunDBInterface


class NopDB(RunDBInterface):
    def __init__(self, url=None, *args, **kwargs):
        self.url = url
        self.token_provider = None

    def __getattribute__(self, attr):
        def nop(*args, **kwargs):
            env_var_message = (
                "MLRUN_DBPATH is misconfigured. Set this environment variable to the URL of the API "
                "server in order to connect"
            )
            if config.httpdb.nop_db.raise_error:
                raise mlrun.errors.MLRunBadRequestError(env_var_message)

            if config.httpdb.nop_db.verbose:
                logger.warning(
                    "Could not detect path to API server, not connected to API server!"
                )
                logger.warning(env_var_message)

            return

        # ignore __class__ because __getattribute__ overrides the parent class's method and it spams logs
        if attr in ["connect", "__class__"]:
            return super().__getattribute__(attr)
        else:
            nop()
            return super().__getattribute__(attr)

    def connect(self, secrets=None):
        pass

    def store_log(self, uid, project="", body=None, append=False):
        pass

    def get_log(self, uid, project="", offset=0, size=0, attempt=None):
        pass

    def store_run(self, struct, uid, project="", iter=0):
        pass

    def update_run(self, updates: dict, uid, project="", iter=0):
        pass

    def set_run_retrying_status(
        self, project: str, name: str, run_id: str, retrying: bool
    ):
        pass

    def abort_run(self, uid, project="", iter=0, timeout=45, status_text=""):
        pass

    def push_run_notifications(
        self,
        uid,
        project="",
        timeout=45,
    ):
        pass

    def refresh_smtp_configuration(self):
        pass

    def push_pipeline_notifications(
        self,
        pipeline_id,
        project="",
        notifications=None,
        timeout=45,
    ):
        pass

    def list_runtime_resources(
        self,
        project: str | None = None,
        label_selector: str | None = None,
        kind: str | None = None,
        object_id: str | None = None,
        group_by: mlrun.common.schemas.ListRuntimeResourcesGroupByField | None = None,
    ) -> Union[
        mlrun.common.schemas.RuntimeResourcesOutput,
        mlrun.common.schemas.GroupedByJobRuntimeResourcesOutput,
        mlrun.common.schemas.GroupedByProjectRuntimeResourcesOutput,
    ]:
        return []

    def read_run(
        self,
        uid,
        project="",
        iter=0,
        format_: mlrun.common.formatters.RunFormat = mlrun.common.formatters.RunFormat.full,
    ):
        pass

    def list_runs(
        self,
        name: str | None = None,
        uid: Union[str, list[str]] | None = None,
        project: str | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        states: list[mlrun.common.runtimes.constants.RunStates] | None = None,
        sort: bool = True,
        iter: bool = False,
        start_time_from: datetime.datetime | None = None,
        start_time_to: datetime.datetime | None = None,
        last_update_time_from: datetime.datetime | None = None,
        last_update_time_to: datetime.datetime | None = None,
        end_time_from: datetime.datetime | None = None,
        end_time_to: datetime.datetime | None = None,
        partition_by: Union[mlrun.common.schemas.RunPartitionByField, str] = None,
        rows_per_partition: int = 1,
        partition_sort_by: Union[mlrun.common.schemas.SortField, str] = None,
        partition_order: Union[
            mlrun.common.schemas.OrderType, str
        ] = mlrun.common.schemas.OrderType.desc,
        max_partitions: int = 0,
        with_notifications: bool = False,
    ):
        return mlrun.lists.RunList()

    def paginated_list_runs(
        self,
        *args,
        page: int | None = None,
        page_size: int | None = None,
        page_token: str | None = None,
        **kwargs,
    ):
        return mlrun.lists.RunList(), None

    def del_run(self, uid, project="", iter=0):
        pass

    def del_runs(
        self,
        name: str = "",
        project: str = "",
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        state: mlrun.common.runtimes.constants.RunStates | None = None,
        days_ago: int = 0,
    ):
        pass

    def store_artifact(
        self,
        key,
        artifact,
        iter=None,
        tag="",
        project="",
        tree=None,
    ):
        pass

    def read_artifact(
        self,
        key,
        tag="",
        iter=None,
        project="",
        tree=None,
        uid=None,
        format_: mlrun.common.formatters.ArtifactFormat = mlrun.common.formatters.ArtifactFormat.full,
    ):
        pass

    def list_artifacts(
        self,
        name="",
        project="",
        tag="",
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        since=None,
        until=None,
        iter: int | None = None,
        best_iteration: bool = False,
        kind: str | None = None,
        category: Union[str, mlrun.common.schemas.ArtifactCategories] = None,
        tree: str | None = None,
        parent: str | None = None,
        format_: mlrun.common.formatters.ArtifactFormat = mlrun.common.formatters.ArtifactFormat.full,
        partition_by: Union[mlrun.common.schemas.ArtifactPartitionByField, str]
        | None = None,
        rows_per_partition: int = 1,
        partition_sort_by: Union[mlrun.common.schemas.SortField, str]
        | None = mlrun.common.schemas.SortField.updated,
        partition_order: Union[
            mlrun.common.schemas.OrderType, str
        ] = mlrun.common.schemas.OrderType.desc,
    ):
        return mlrun.lists.ArtifactList()

    def paginated_list_artifacts(
        self,
        *args,
        page: int | None = None,
        page_size: int | None = None,
        page_token: str | None = None,
        **kwargs,
    ):
        return mlrun.lists.ArtifactList(), None

    def del_artifact(
        self,
        key,
        tag="",
        project="",
        tree=None,
        uid=None,
        deletion_strategy: mlrun.common.schemas.artifact.ArtifactsDeletionStrategies = (
            mlrun.common.schemas.artifact.ArtifactsDeletionStrategies.metadata_only
        ),
        secrets: dict | None = None,
        iter=None,
    ):
        pass

    def del_artifacts(
        self,
        name="",
        project="",
        tag="",
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
    ):
        pass

    def store_function(self, function, name, project="", tag="", versioned=False):
        pass

    def get_function(self, name, project="", tag="", hash_key=""):
        pass

    def delete_function(self, name: str, project: str = ""):
        pass

    def list_functions(
        self,
        name: str | None = None,
        project: str | None = None,
        tag: str | None = None,
        kind: str | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        states: list[mlrun.common.schemas.FunctionState] | None = None,
        format_: mlrun.common.formatters.FunctionFormat = mlrun.common.formatters.FunctionFormat.full,
        since: datetime.datetime | None = None,
        until: datetime.datetime | None = None,
    ):
        return []

    def paginated_list_functions(
        self,
        *args,
        page: int | None = None,
        page_size: int | None = None,
        page_token: str | None = None,
        **kwargs,
    ):
        return [], None

    def tag_objects(
        self,
        project: str,
        tag_name: str,
        tag_objects: mlrun.common.schemas.TagObjects,
        replace: bool = False,
    ):
        pass

    def delete_objects_tag(
        self, project: str, tag_name: str, tag_objects: mlrun.common.schemas.TagObjects
    ):
        pass

    def tag_artifacts(
        self, artifacts, project: str, tag_name: str, replace: bool = False
    ):
        pass

    def delete_artifacts_tags(self, artifacts, project: str, tag_name: str):
        pass

    def delete_project(
        self,
        name: str,
        deletion_strategy: mlrun.common.schemas.DeletionStrategy = mlrun.common.schemas.DeletionStrategy.default(),
    ):
        pass

    def create_project(
        self, project: mlrun.common.schemas.Project | dict
    ) -> mlrun.common.schemas.Project:
        if isinstance(project, dict):
            project = mlrun.projects.MlrunProject.from_dict(project)
        return project

    def store_project(
        self, name: str, project: mlrun.common.schemas.Project | dict
    ) -> mlrun.common.schemas.Project:
        return self.create_project(project)

    def patch_project(
        self,
        name: str,
        project: dict,
        patch_mode: mlrun.common.schemas.PatchMode = mlrun.common.schemas.PatchMode.replace,
    ) -> mlrun.common.schemas.Project:
        pass

    def list_projects(
        self,
        owner: str | None = None,
        format_: mlrun.common.formatters.ProjectFormat = mlrun.common.formatters.ProjectFormat.name_only,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        state: mlrun.common.schemas.ProjectState = None,
    ) -> mlrun.common.schemas.ProjectsOutput:
        pass

    def get_project(self, name: str) -> mlrun.common.schemas.Project:
        pass

    def list_artifact_tags(
        self,
        project=None,
        category: Union[str, mlrun.common.schemas.ArtifactCategories] = None,
    ):
        pass

    def create_feature_set(
        self,
        feature_set: Union[dict, mlrun.common.schemas.FeatureSet],
        project="",
        versioned=True,
    ) -> dict:
        pass

    def get_feature_set(
        self,
        name: str,
        project: str = "",
        tag: str | None = None,
        uid: str | None = None,
    ) -> dict:
        pass

    def list_features_v2(
        self,
        project: str,
        name: str | None = None,
        tag: str | None = None,
        entities: list[str] | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
    ) -> mlrun.common.schemas.FeaturesOutputV2:
        pass

    def list_entities_v2(
        self,
        project: str,
        name: str | None = None,
        tag: str | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
    ) -> mlrun.common.schemas.EntitiesOutputV2:
        pass

    def list_feature_sets(
        self,
        project: str = "",
        name: str | None = None,
        tag: str | None = None,
        state: str | None = None,
        entities: list[str] | None = None,
        features: list[str] | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        partition_by: Union[
            mlrun.common.schemas.FeatureStorePartitionByField, str
        ] = None,
        rows_per_partition: int = 1,
        partition_sort_by: Union[mlrun.common.schemas.SortField, str] = None,
        partition_order: Union[
            mlrun.common.schemas.OrderType, str
        ] = mlrun.common.schemas.OrderType.desc,
        format_: Union[
            str, mlrun.common.formatters.FeatureSetFormat
        ] = mlrun.common.formatters.FeatureSetFormat.full,
    ) -> list[dict]:
        pass

    def store_feature_set(
        self,
        feature_set: Union[dict, mlrun.common.schemas.FeatureSet],
        name=None,
        project="",
        tag=None,
        uid=None,
        versioned=True,
    ):
        pass

    def patch_feature_set(
        self,
        name,
        feature_set: dict,
        project="",
        tag=None,
        uid=None,
        patch_mode: Union[
            str, mlrun.common.schemas.PatchMode
        ] = mlrun.common.schemas.PatchMode.replace,
    ):
        pass

    def delete_feature_set(self, name, project="", tag=None, uid=None):
        pass

    def create_feature_vector(
        self,
        feature_vector: Union[dict, mlrun.common.schemas.FeatureVector],
        project="",
        versioned=True,
    ) -> dict:
        pass

    def get_feature_vector(
        self,
        name: str,
        project: str = "",
        tag: str | None = None,
        uid: str | None = None,
    ) -> dict:
        pass

    def list_feature_vectors(
        self,
        project: str = "",
        name: str | None = None,
        tag: str | None = None,
        state: str | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        partition_by: Union[
            mlrun.common.schemas.FeatureStorePartitionByField, str
        ] = None,
        rows_per_partition: int = 1,
        partition_sort_by: Union[mlrun.common.schemas.SortField, str] = None,
        partition_order: Union[
            mlrun.common.schemas.OrderType, str
        ] = mlrun.common.schemas.OrderType.desc,
    ) -> list[dict]:
        pass

    def store_feature_vector(
        self,
        feature_vector: Union[dict, mlrun.common.schemas.FeatureVector],
        name=None,
        project="",
        tag=None,
        uid=None,
        versioned=True,
    ):
        pass

    def patch_feature_vector(
        self,
        name,
        feature_vector_update: dict,
        project="",
        tag=None,
        uid=None,
        patch_mode: Union[
            str, mlrun.common.schemas.PatchMode
        ] = mlrun.common.schemas.PatchMode.replace,
    ):
        pass

    def delete_feature_vector(self, name, project="", tag=None, uid=None):
        pass

    def get_pipeline(
        self,
        run_id: str,
        namespace: str | None = None,
        timeout: int = 30,
        format_: Union[
            str, mlrun.common.formatters.PipelineFormat
        ] = mlrun.common.formatters.PipelineFormat.summary,
        project: str | None = None,
    ):
        pass

    def retry_pipeline(
        self,
        run_id: str,
        project: str,
        namespace: str | None = None,
        timeout: int = 30,
    ):
        pass

    def list_pipelines(
        self,
        project: str,
        namespace: str | None = None,
        sort_by: str = "",
        page_token: str = "",
        filter_: str = "",
        format_: Union[
            str, mlrun.common.formatters.PipelineFormat
        ] = mlrun.common.formatters.PipelineFormat.metadata_only,
        page_size: int | None = None,
    ) -> mlrun.common.schemas.PipelinesOutput:
        return mlrun.common.schemas.PipelinesOutput(runs=[], total_size=0)

    def create_project_secrets(
        self,
        project: str,
        provider: Union[
            str, mlrun.common.schemas.SecretProviderName
        ] = mlrun.common.schemas.SecretProviderName.kubernetes,
        secrets: dict | None = None,
    ):
        pass

    def list_project_secrets(
        self,
        project: str,
        token: str,
        provider: Union[
            str, mlrun.common.schemas.SecretProviderName
        ] = mlrun.common.schemas.SecretProviderName.kubernetes,
        secrets: list[str] | None = None,
    ) -> mlrun.common.schemas.SecretsData:
        pass

    def list_project_secret_keys(
        self,
        project: str,
        provider: Union[
            str, mlrun.common.schemas.SecretProviderName
        ] = mlrun.common.schemas.SecretProviderName.kubernetes,
        token: str | None = None,
    ) -> mlrun.common.schemas.SecretKeysData:
        pass

    def delete_project_secrets(
        self,
        project: str,
        provider: Union[
            str, mlrun.common.schemas.SecretProviderName
        ] = mlrun.common.schemas.SecretProviderName.kubernetes,
        secrets: list[str] | None = None,
    ):
        pass

    def create_model_endpoint(
        self,
        model_endpoint: mlrun.common.schemas.ModelEndpoint,
        creation_strategy: mm_constants.ModelEndpointCreationStrategy
        | None = mm_constants.ModelEndpointCreationStrategy.INPLACE,
    ) -> mlrun.common.schemas.ModelEndpoint:
        pass

    def delete_model_endpoint(
        self,
        name: str,
        project: str,
        function_name: str | None = None,
        function_tag: str | None = None,
        endpoint_id: str | None = None,
    ):
        pass

    def list_model_endpoints(
        self,
        project: str,
        names: Union[str, list[str]] | None = None,
        function_name: str | None = None,
        function_tag: str | None = None,
        model_name: str | None = None,
        model_tag: str | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        start: datetime.datetime | None = None,
        end: datetime.datetime | None = None,
        tsdb_metrics: bool = False,
        metric_list: list[str] | None = None,
        top_level: bool = False,
        modes: Union[mm_constants.EndpointMode, list[mm_constants.EndpointMode]]
        | None = None,
        uids: list[str] | None = None,
        latest_only: bool = False,
    ) -> mlrun.common.schemas.ModelEndpointList:
        pass

    def get_model_endpoint(
        self,
        name: str,
        project: str,
        function_name: str | None = None,
        function_tag: str | None = None,
        endpoint_id: str | None = None,
        tsdb_metrics: bool = True,
        metric_list: list[str] | None = None,
        feature_analysis: bool = False,
    ) -> mlrun.common.schemas.ModelEndpoint:
        pass

    def patch_model_endpoint(
        self,
        name: str,
        project: str,
        attributes: dict,
        function_name: str | None = None,
        function_tag: str | None = None,
        endpoint_id: str | None = None,
    ) -> mlrun.common.schemas.ModelEndpoint:
        pass

    def create_hub_source(
        self, source: Union[dict, mlrun.common.schemas.IndexedHubSource]
    ):
        pass

    def store_hub_source(
        self,
        source_name: str,
        source: Union[dict, mlrun.common.schemas.IndexedHubSource],
    ):
        pass

    def list_hub_sources(
        self,
        item_name: str | None = None,
        tag: str | None = None,
        version: str | None = None,
        item_type: mlrun.common.schemas.hub.HubSourceType = mlrun.common.schemas.hub.HubSourceType.functions,
    ):
        pass

    def get_hub_source(self, source_name: str):
        pass

    def delete_hub_source(self, source_name: str):
        pass

    def get_hub_catalog(
        self,
        source_name: str,
        channel: str | None = None,
        version: str | None = None,
        tag: str | None = None,
        force_refresh: bool = False,
        object_type: mlrun.common.schemas.hub.HubSourceType = mlrun.common.schemas.hub.HubSourceType.functions,
    ):
        pass

    def get_hub_item(
        self,
        source_name: str,
        item_name: str,
        channel: str = "development",
        version: str | None = None,
        tag: str = "latest",
        force_refresh: bool = False,
        item_type: mlrun.common.schemas.hub.HubSourceType = mlrun.common.schemas.hub.HubSourceType.functions,
    ):
        pass

    def get_hub_asset(
        self,
        source_name: str,
        item_name: str,
        asset_name: str,
        version: str | None = None,
        tag: str = "latest",
        item_type: mlrun.common.schemas.hub.HubSourceType = mlrun.common.schemas.hub.HubSourceType.functions,
    ):
        pass

    def store_api_gateway(
        self,
        api_gateway: Union[
            mlrun.common.schemas.APIGateway,
            mlrun.runtimes.nuclio.api_gateway.APIGateway,
        ],
        project: str | None = None,
    ) -> mlrun.common.schemas.APIGateway:
        pass

    def list_api_gateways(self, project=None):
        pass

    def get_api_gateway(self, name, project=None):
        pass

    def delete_api_gateway(self, name, project=None):
        pass

    def verify_authorization(
        self,
        authorization_verification_input: mlrun.common.schemas.AuthorizationVerificationInput,
    ):
        pass

    def remote_builder(
        self,
        func: "mlrun.runtimes.BaseRuntime",
        with_mlrun: bool,
        mlrun_version_specifier: str | None = None,
        skip_deployed: bool = False,
        builder_env: dict | None = None,
        force_build: bool = False,
    ):
        pass

    def deploy_nuclio_function(
        self,
        func: "mlrun.runtimes.RemoteRuntime",
        builder_env: dict | None = None,
    ):
        pass

    def get_builder_status(
        self,
        func: "mlrun.runtimes.BaseRuntime",
        offset: int = 0,
        logs: bool = True,
        last_log_timestamp: float = 0.0,
        verbose: bool = False,
        events_offset: int = 0,
    ):
        pass

    def get_nuclio_deploy_status(
        self,
        func: "mlrun.runtimes.RemoteRuntime",
        last_log_timestamp: float = 0.0,
        verbose: bool = False,
    ):
        pass

    def set_run_notifications(
        self,
        project: str,
        runs: list[mlrun.model.RunObject],
        notifications: list[mlrun.model.Notification],
    ):
        pass

    def store_run_notifications(
        self,
        notification_objects: list[mlrun.model.Notification],
        run_uid: str,
        project: str | None = None,
        mask_params: bool = True,
    ):
        pass

    def store_alert_notifications(
        self,
        session,
        notification_objects: list[mlrun.model.Notification],
        alert_id: str,
        project: str,
        mask_params: bool = True,
    ):
        pass

    def get_log_size(self, uid, project=""):
        pass

    def watch_log(self, uid, project="", watch=True, offset=0):
        pass

    def get_datastore_profile(
        self, name: str, project: str
    ) -> mlrun.common.schemas.DatastoreProfile | None:
        pass

    def delete_datastore_profile(self, name: str, project: str):
        pass

    def list_datastore_profiles(
        self, project: str
    ) -> list[mlrun.common.schemas.DatastoreProfile]:
        pass

    def store_datastore_profile(
        self, profile: mlrun.common.schemas.DatastoreProfile, project: str
    ):
        pass

    def function_status(self, project, name, kind, selector):
        pass

    def start_function(
        self,
        func_url: str | None = None,
        function: "mlrun.runtimes.BaseRuntime" = None,
    ):
        pass

    def submit_workflow(
        self,
        project: str,
        name: str,
        workflow_spec: Union[
            "mlrun.projects.pipelines.WorkflowSpec",
            "mlrun.common.schemas.WorkflowSpec",
            dict,
        ],
        arguments: dict | None = None,
        artifact_path: str | None = None,
        source: str | None = None,
        run_name: str | None = None,
        namespace: str | None = None,
        notifications: list["mlrun.model.Notification"] | None = None,
    ) -> "mlrun.common.schemas.WorkflowResponse":
        pass

    def update_model_monitoring_controller(
        self,
        project: str,
        base_period: int = 10,
        image: str = "mlrun/mlrun",
    ):
        pass

    def enable_model_monitoring(
        self,
        project: str,
        base_period: int = 10,
        image: str = "mlrun/mlrun",
        deploy_histogram_data_drift_app: bool = True,
        fetch_credentials_from_sys_config: bool = False,
        lag_threshold: int | None = None,
        lag_event_cooldown: int | None = None,
    ) -> None:
        pass

    def disable_model_monitoring(
        self,
        project: str,
        delete_resources: bool = True,
        delete_stream_function: bool = False,
        delete_histogram_data_drift_app: bool = True,
        delete_user_applications: bool = False,
        user_application_list: list[str] | None = None,
    ) -> bool:
        pass

    def delete_model_monitoring_function(
        self, project: str, functions: list[str]
    ) -> bool:
        pass

    def set_model_monitoring_credentials(
        self,
        project: str,
        credentials: dict[str, str | None],
        replace_creds: bool,
    ) -> None:
        pass

    def delete_model_monitoring_metrics(
        self,
        project: str,
        application_name: str,
        endpoint_ids: list[str] | None = None,
    ) -> None:
        pass

    def get_monitoring_function_summaries(
        self,
        project: str,
        start: datetime.datetime | None = None,
        end: datetime.datetime | None = None,
        names: Union[list[str], str] | None = None,
        labels: Union[str, dict[str, str | None], list[str]] | None = None,
        include_stats: bool = False,
        include_infra: bool = True,
    ) -> [mlrun.common.schemas.model_monitoring.FunctionSummary]:
        pass

    def get_monitoring_function_summary(
        self,
        project: str,
        function_name: str,
        start: datetime.datetime | None = None,
        end: datetime.datetime | None = None,
        include_latest_metrics: bool = False,
    ) -> mlrun.common.schemas.model_monitoring.FunctionSummary:
        pass

    def generate_event(
        self, name: str, event_data: Union[dict, mlrun.common.schemas.Event], project=""
    ):
        pass

    def store_alert_config(
        self,
        alert_name: str,
        alert_data: Union[dict, mlrun.alerts.alert.AlertConfig],
        project="",
        force_reset: bool = False,
    ):
        pass

    def get_alert_config(self, alert_name: str, project=""):
        pass

    def list_alerts_configs(self, project=""):
        pass

    def delete_alert_config(self, alert_name: str, project=""):
        pass

    def reset_alert_config(self, alert_name: str, project=""):
        pass

    def get_alert_template(self, template_name: str):
        pass

    def list_alert_templates(self):
        pass

    def list_alert_activations(
        self,
        project: str | None = None,
        name: str | None = None,
        since: datetime.datetime | None = None,
        until: datetime.datetime | None = None,
        entity: str | None = None,
        severity: list[Union[mlrun.common.schemas.alert.AlertSeverity, str]]
        | None = None,
        entity_kind: Union[mlrun.common.schemas.alert.EventEntityKind, str]
        | None = None,
        event_kind: Union[mlrun.common.schemas.alert.EventKind, str] | None = None,
    ):
        pass

    def paginated_list_alert_activations(
        self,
        *args,
        page: int | None = None,
        page_size: int | None = None,
        page_token: str | None = None,
        **kwargs,
    ):
        pass

    def get_alert_activation(
        self,
        project,
        activation_id,
    ) -> mlrun.common.schemas.AlertActivation:
        pass

    def get_project_summary(self, project: str):
        pass

    def get_drift_over_time(
        self,
        project: str,
        start: datetime.datetime | None = None,
        end: datetime.datetime | None = None,
    ) -> mlrun.common.schemas.model_monitoring.ModelEndpointDriftValues:
        pass

    def store_secret_token(
        self,
        secret_token: mlrun.common.schemas.SecretToken,
        log_warning: bool = True,
        force: bool = False,
    ) -> mlrun.common.schemas.StoreSecretTokensResponse:
        pass

    def store_secret_tokens(
        self,
        secret_tokens: list[mlrun.common.schemas.SecretToken],
        log_warning: bool = True,
        force: bool = False,
    ) -> mlrun.common.schemas.StoreSecretTokensResponse:
        pass

    def list_secret_tokens(
        self, username: str | None = None
    ) -> mlrun.common.schemas.ListSecretTokensResponse:
        pass

    def delete_secret_token(
        self, token_name: str, username: str | None = None
    ) -> mlrun.common.schemas.DeleteSecretTokenResponse:
        pass

    def get_secret_token(
        self,
        token_name: str,
        username: str | None = None,
    ) -> mlrun.common.schemas.SecretToken:
        pass
