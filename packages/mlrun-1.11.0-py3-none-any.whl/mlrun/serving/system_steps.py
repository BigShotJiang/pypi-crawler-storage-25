# Copyright 2023 Iguazio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import random
import typing
from copy import copy
from datetime import timedelta
from typing import Any, Union

import numpy as np
import storey

import mlrun
import mlrun.artifacts
import mlrun.common.schemas.model_monitoring as mm_schemas
import mlrun.feature_store
import mlrun.serving
from mlrun.common.model_monitoring.helpers import (
    get_model_endpoints_creation_task_status,
)
from mlrun.common.schemas import MonitoringData
from mlrun.utils import get_data_from_path, logger


class MatchingEndpointsState(mlrun.common.types.StrEnum):
    all_matched = "all_matched"
    not_all_matched = "not_all_matched"
    no_check_needed = "no_check_needed"
    not_yet_checked = "not_yet_matched"

    @staticmethod
    def success_states() -> list[str]:
        return [
            MatchingEndpointsState.all_matched,
            MatchingEndpointsState.no_check_needed,
        ]


class MonitoringPreProcessor(storey.MapClass):
    """preprocess step, reconstructs the serving output event body to StreamProcessingEvent schema"""

    def __init__(
        self,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.server: mlrun.serving.GraphServer = (
            getattr(self.context, "server", None) if self.context else None
        )

    def _aggregate_collected_chunks(self, chunks: list) -> Any:
        """
        Aggregate collected streaming chunks into a single result for model monitoring.

        For string chunks (e.g., LLM tokens): concatenate into a single string.
        For dict chunks: merge outputs and sum numeric metrics.
        """
        if not chunks:
            return {}

        # For string chunks (LLM tokens), concatenate
        if all(isinstance(c, str) for c in chunks):
            return "".join(chunks)

        # For dict chunks, merge appropriately
        if all(isinstance(c, dict) for c in chunks):
            return self._merge_dict_chunks(chunks)

        # Mixed types or other - return as-is (list)
        return chunks

    def _merge_dict_chunks(self, chunks: list[dict]) -> dict:
        """
        Merge a list of dict chunks into a single dict.

        - Outputs/results: concatenate if strings, otherwise collect into list
        - Metrics: sum numeric values
        - Other fields: take from first chunk
        """
        if not chunks:
            return {}

        result = {}
        first = chunks[0]
        all_keys = set()
        for c in chunks:
            all_keys.update(c.keys())

        for key in all_keys:
            values = [c.get(key) for c in chunks if key in c]
            if not values:
                continue

            if key == mm_schemas.StreamProcessingEvent.METRICS:
                # Sum numeric metrics
                result[key] = self._aggregate_metrics(values)
            elif key in ("outputs", "result", "output"):
                # Concatenate outputs if strings, otherwise keep as list
                result[key] = self._aggregate_outputs(values)
            elif key == mm_schemas.StreamProcessingEvent.ERROR:
                # Keep first non-None error
                result[key] = next((v for v in values if v is not None), None)
            else:
                # Take first value for other fields
                result[key] = first.get(key)

        return result

    def _aggregate_metrics(self, metrics_list: list) -> dict | None:
        """
        Aggregate metrics from multiple chunks by summing numeric values.
        """
        if not metrics_list or all(m is None for m in metrics_list):
            return None

        aggregated = {}
        for metrics in metrics_list:
            if metrics is None:
                continue
            if not isinstance(metrics, dict):
                continue
            for key, value in metrics.items():
                if key not in aggregated:
                    aggregated[key] = value
                elif isinstance(value, int | float) and isinstance(
                    aggregated[key], int | float
                ):
                    aggregated[key] += value
                # For non-numeric, keep the first value

        return aggregated if aggregated else None

    def _aggregate_outputs(self, outputs_list: list) -> Any:
        """
        Aggregate outputs from multiple chunks.

        For strings: concatenate.
        For lists: flatten.
        Otherwise: return as list.
        """
        if not outputs_list:
            return None

        # Filter out None values
        outputs_list = [o for o in outputs_list if o is not None]
        if not outputs_list:
            return None

        # If all are strings, concatenate
        if all(isinstance(o, str) for o in outputs_list):
            return "".join(outputs_list)

        # If all are lists, flatten
        if all(isinstance(o, list) for o in outputs_list):
            flattened = []
            for o in outputs_list:
                flattened.extend(o)
            return flattened

        # Otherwise return as list
        return outputs_list

    def _extract_event_body_for_model(
        self, event, model: str, multiple_models: bool
    ) -> tuple[Any, bool]:
        """
        Extract event body for a specific model, handling both single and batched events uniformly.

        :param event: Event to extract body from
        :param model: Model name to extract (when multiple_models=True)
        :param multiple_models: Whether to extract model-specific body from dict
        :return: Tuple of (event_body, is_error)
        """
        is_error = False

        if storey.flow.is_batched_event(event):
            # Check for errors first
            error = self._extract_error_from_batched_event(
                event, model=model if multiple_models else None
            )
            if error:
                return None, True

            # Extract body from each sub-event
            event_body = []
            for sub_event in event.body:
                if isinstance(sub_event.body, dict):
                    sub_event_by_model = sub_event.body.get(model, sub_event.body)
                    event_body.append(sub_event_by_model)
                else:
                    event_body.append(sub_event.body)
        else:
            # Single event handling
            if isinstance(event.body, dict):
                event_body = event.body.get(model, event.body)
                if isinstance(event_body, dict):
                    is_error = bool(event_body.get("error"))
            else:
                event_body = event.body

        return event_body, is_error

    def reconstruct_request_resp_fields(
        self, event, model: str, model_monitoring_data: dict, multiple_models=True
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        outputs = None
        new_output_schema = None
        result_path = model_monitoring_data.get(MonitoringData.RESULT_PATH)
        input_path = model_monitoring_data.get(MonitoringData.INPUT_PATH)

        output_schema = model_monitoring_data.get(MonitoringData.OUTPUTS)
        input_schema = model_monitoring_data.get(MonitoringData.INPUTS)
        logger.debug(
            "output and input schema retrieved",
            output_schema=output_schema,
            input_schema=input_schema,
        )

        # Extract event body uniformly for both single and batched events
        event_body, is_error = self._extract_event_body_for_model(
            event, model, multiple_models
        )

        # For stream-collected events the aggregated body IS the raw output
        # (e.g. concatenated text tokens), not wrapped in the result_path dict.
        if getattr(event, "stream_collected", False) and not isinstance(
            event_body, dict | list
        ):
            result_path = None

        # Only process outputs if no error
        if not is_error and event_body is not None:
            outputs, new_output_schema = self.get_listed_data(
                event_body, result_path, output_schema
            )

        # Always process inputs
        inputs, new_input_schema = self.get_listed_data(
            event._metadata.get("inputs", {}), input_path, input_schema
        )

        # Validate outputs
        if outputs and isinstance(outputs[0], list):
            if output_schema and len(output_schema) != len(outputs[0]):
                logger.info(
                    "The number of outputs returned by the model does not match the number of outputs "
                    "specified in the model endpoint.",
                    model_endpoint=model,
                    output_len=len(outputs[0]),
                    schema_len=len(output_schema),
                )
        elif outputs:
            if output_schema and len(output_schema) != 1:
                logger.info(
                    "The number of outputs returned by the model does not match the number of outputs "
                    "specified in the model endpoint.",
                    model_endpoint=model,
                    output_len=len(outputs),
                    schema_len=len(output_schema),
                )
            if len(inputs) != len(outputs):
                logger.warn(
                    "outputs and inputs are not in the same length check 'input_path' and "
                    "'output_path' was specified if needed"
                )

        request = {
            "inputs": inputs,
            "id": getattr(event, "id", None),
            "input_schema": new_input_schema,
        }
        resp = {"outputs": outputs, "output_schema": new_output_schema}

        return request, resp

    def get_listed_data(
        self,
        raw_data: typing.Union[dict, list],
        data_path: Union[list[str], str] | None = None,
        schema: list[str] | None = None,
    ):
        """Get data from a path and transpose it by keys if dict is provided."""
        new_schema = None
        data_from_path = get_data_from_path(data_path, raw_data)
        if isinstance(data_from_path, dict):
            # transpose by key the inputs:
            listed_data, new_schema = self.transpose_by_key(data_from_path, schema)
            new_schema = new_schema or schema
            if not schema:
                logger.warn(
                    f"No schema provided through add_model(); the order of {data_from_path} "
                    "may not be preserved."
                )
        elif not isinstance(data_from_path, list):
            listed_data = [data_from_path]
        else:  # list handling
            # Check if all items are dicts
            all_dicts = data_from_path and all(
                isinstance(item, dict) for item in data_from_path
            )

            if all_dicts:
                # Check if all dicts have the same keys
                same_keys = (
                    len(set(tuple(sorted(item.keys())) for item in data_from_path)) == 1
                )

                if same_keys:
                    # batch handling
                    # All items are dicts with the same keys - transpose by key
                    # Merge all dicts by combining values for each key into lists
                    merged_dict = {}
                    for item in data_from_path:
                        for key, value in item.items():
                            if key not in merged_dict:
                                merged_dict[key] = []
                            merged_dict[key].append(value)
                    listed_data, new_schema = self.transpose_by_key(merged_dict, schema)
                    new_schema = new_schema or schema
                else:
                    # Dicts with different keys - warn and fall back to default
                    logger.warn(
                        "List contains dicts with different keys; cannot transpose by key. "
                        "Falling back to default list handling."
                    )
                    listed_data = data_from_path
            else:
                # Fall back to default list handling
                listed_data = data_from_path
        return listed_data, new_schema

    @staticmethod
    def _extract_error_from_batched_event(
        event, model: str | None = None
    ) -> str | None:
        """
        Extract error from a batched event.

        :param event: The batched event to extract error from
        :param model: Optional model name to extract error for (when event body is dict with model keys)
        :return: The error string if found, None otherwise
        :raises RuntimeError: If inconsistent errors are found in batched event
        """
        errors = []
        for sub_event in event.body:
            if not isinstance(sub_event.body, dict):
                break

            # If model is specified, get error from se.body[model], otherwise from se.body directly
            if model is not None:
                if model not in sub_event.body:
                    continue
                event_data = sub_event.body[model]
            else:
                event_data = sub_event.body
            if not isinstance(event_data, dict):
                return None
            error = event_data.get(mm_schemas.StreamProcessingEvent.ERROR)
            errors.append(error)

        if len(set(errors)) > 1:
            raise RuntimeError("Inconsistent errors in batched event")

        return errors[0] if errors else None

    @staticmethod
    def transpose_by_key(
        data: dict, schema: Union[str, list[str]] | None = None
    ) -> tuple[Union[list[Any], list[list[Any]]], list[str]]:
        """
        Transpose values from a dictionary by keys.

        Given a dictionary and an optional schema (a key or list of keys), this function:
        - Extracts the values for the specified keys (or all keys if no schema is provided).
        - Ensures the data is represented as a list of rows, then transposes it (i.e., switches rows to columns).
        - Handles edge cases:
            * If a single scalar or single-element list is provided, returns a flat list.
            * If a single key is provided (as a string or a list with one element), handles it properly.
            * If only one row with len of one remains after transposition, unwraps it to avoid nested list-of-one.

        Example::

            transpose_by_key({"a": 1})
            # returns: [1]

            transpose_by_key({"a": [1, 2]})
            # returns: [1 ,2]

            transpose_by_key({"a": [1, 2], "b": [3, 4]})
            # returns: [[1, 3], [2, 4]]

        :param data:     Dictionary with values that are either scalars or lists.
        :param schema:   Optional key or list of keys to extract. If not provided, all keys are used.
                         Can be a string (single key) or a list of strings.

        :return:         Transposed values:
                         * If result is a single column or row, returns a flat list.
                         * If result is a matrix, returns a list of lists.

        :raises ValueError: If the values include a mix of scalars and lists, or if the list lengths do not match.
                mlrun.MLRunInvalidArgumentError if the schema keys are not contained in the data keys.
        """
        new_schema = None
        # Normalize keys in data:
        normalize_data = {
            mlrun.feature_store.api.norm_column_name(k): copy(v)
            for k, v in data.items()
        }
        # Normalize schema to list
        if not schema:
            keys = list(normalize_data.keys())
            new_schema = keys
        elif isinstance(schema, str):
            keys = [mlrun.feature_store.api.norm_column_name(schema)]
        else:
            keys = [mlrun.feature_store.api.norm_column_name(key) for key in schema]

        values = [normalize_data[key] for key in keys if key in normalize_data]
        if len(values) != len(keys):
            raise mlrun.MLRunInvalidArgumentError(
                f"Schema keys {keys} are not contained in the data keys {list(data.keys())}."
            )

        # Detect if all are scalars ie: int,float,str
        all_scalars = all(not isinstance(v, list | tuple | np.ndarray) for v in values)
        all_lists = all(isinstance(v, list | tuple | np.ndarray) for v in values)

        if not (all_scalars or all_lists):
            raise ValueError(
                "All values must be either scalars or lists of equal length."
            )

        if all_scalars:
            transposed = np.array([values], dtype=object)
        elif all_lists and len(keys) > 1:
            arrays = [np.array(v, dtype=object) for v in values]
            mat = np.stack(arrays, axis=0)
            transposed = mat.T
        else:
            return values[0], new_schema

        if transposed.shape[1] == 1 and transposed.shape[0] == 1:
            # Transform [[0]] -> [0]:
            return transposed[:, 0].tolist(), new_schema
        return transposed.tolist(), new_schema

    def do(self, event):
        monitoring_event_list = []
        model_runner_name = event._metadata.get("model_runner_name", "")
        step = self.server.graph.steps[model_runner_name] if self.server else None
        if not step or not hasattr(step, "monitoring_data"):
            raise mlrun.errors.MLRunRuntimeError(
                f"ModelRunnerStep name {model_runner_name} is not found in the graph or does not have monitoring data"
            )
        monitoring_data = step.monitoring_data

        # Check if this event was collected from a stream by the Collector step
        is_stream_collected = getattr(event, "stream_collected", False)
        if is_stream_collected:
            logger.debug(
                "Aggregating collected streaming chunks for monitoring",
                num_chunks=len(event.body) if isinstance(event.body, list) else 1,
                model_runner_name=model_runner_name,
            )
            event.body = self._aggregate_collected_chunks(
                event.body if isinstance(event.body, list) else [event.body]
            )

        # When streaming chunks were collected from a multi-model MRS, only
        # one model actually ran (streaming requires a single selected
        # runnable). The body is the raw aggregated output, not keyed by
        # model name, so narrow monitoring_data to the single selected model
        # so the single-model path below is used.
        if is_stream_collected and len(monitoring_data) > 1:
            selected_models = event._metadata.get("selected_models", [])
            if len(selected_models) == 1 and selected_models[0] in monitoring_data:
                monitoring_data = {
                    selected_models[0]: monitoring_data[selected_models[0]]
                }

        logger.debug(
            "monitoring preprocessor started",
            event=event,
            monitoring_data=monitoring_data,
            metadata=event._metadata,
        )
        if len(monitoring_data) > 1:
            if storey.flow.is_batched_event(event):
                models_by_event = set.intersection(
                    *(set(sub_event.body.keys()) for sub_event in event.body)
                )
            else:
                models_by_event = event.body.keys()
            for model in models_by_event:
                if model in monitoring_data:
                    request, resp = self.reconstruct_request_resp_fields(
                        event, model, monitoring_data[model]
                    )
                    if hasattr(event, "_original_timestamp"):
                        when = event._original_timestamp
                    else:
                        when = event._metadata.get(model, {}).get(
                            mm_schemas.StreamProcessingEvent.WHEN
                        )
                    #  if the body is not a dict, use empty labels, error and metrics
                    if isinstance(event.body, dict) and isinstance(
                        event.body[model], dict
                    ):
                        body_by_model = event.body[model]
                        labels = body_by_model.get("labels") or {}
                        error = body_by_model.get(
                            mm_schemas.StreamProcessingEvent.ERROR
                        )
                        metrics = body_by_model.get(
                            mm_schemas.StreamProcessingEvent.METRICS
                        )
                    else:
                        labels = {}
                        metrics = None
                        error = (
                            self._extract_error_from_batched_event(event, model=model)
                            if storey.flow.is_batched_event(event)
                            else None
                        )

                    monitoring_event_list.append(
                        {
                            mm_schemas.StreamProcessingEvent.MODEL: model,
                            mm_schemas.StreamProcessingEvent.MODEL_CLASS: monitoring_data[
                                model
                            ].get(mm_schemas.StreamProcessingEvent.MODEL_CLASS),
                            mm_schemas.StreamProcessingEvent.MICROSEC: event._metadata.get(
                                model, {}
                            ).get(mm_schemas.StreamProcessingEvent.MICROSEC),
                            mm_schemas.StreamProcessingEvent.WHEN: when,
                            mm_schemas.StreamProcessingEvent.ENDPOINT_ID: monitoring_data[
                                model
                            ].get(
                                mlrun.common.schemas.MonitoringData.MODEL_ENDPOINT_UID
                            ),
                            mm_schemas.StreamProcessingEvent.LABELS: labels,
                            mm_schemas.StreamProcessingEvent.FUNCTION_URI: self.server.function_uri
                            if self.server
                            else None,
                            mm_schemas.StreamProcessingEvent.REQUEST: request,
                            mm_schemas.StreamProcessingEvent.RESPONSE: resp,
                            mm_schemas.StreamProcessingEvent.ERROR: error,
                            mm_schemas.StreamProcessingEvent.METRICS: metrics,
                        }
                    )
        elif monitoring_data:
            model = list(monitoring_data.keys())[0]
            request, resp = self.reconstruct_request_resp_fields(
                event, model, monitoring_data[model], multiple_models=False
            )
            if hasattr(event, "_original_timestamp"):
                when = event._original_timestamp
            else:
                when = event._metadata.get(mm_schemas.StreamProcessingEvent.WHEN)
            #  if the body is not a dict, use empty labels, error and metrics
            if isinstance(event.body, dict):
                labels = event.body.get("labels") or {}
                error = event.body.get(mm_schemas.StreamProcessingEvent.ERROR)
                metrics = event.body.get(mm_schemas.StreamProcessingEvent.METRICS)
            else:
                #  batch step case
                labels = {}
                metrics = None
                error = (
                    self._extract_error_from_batched_event(event)
                    if storey.flow.is_batched_event(event)
                    else None
                )
            monitoring_event_list.append(
                {
                    mm_schemas.StreamProcessingEvent.MODEL: model,
                    mm_schemas.StreamProcessingEvent.MODEL_CLASS: monitoring_data[
                        model
                    ].get(mm_schemas.StreamProcessingEvent.MODEL_CLASS),
                    mm_schemas.StreamProcessingEvent.MICROSEC: event._metadata.get(
                        mm_schemas.StreamProcessingEvent.MICROSEC
                    ),
                    mm_schemas.StreamProcessingEvent.WHEN: when,
                    mm_schemas.StreamProcessingEvent.ENDPOINT_ID: monitoring_data[
                        model
                    ].get(mlrun.common.schemas.MonitoringData.MODEL_ENDPOINT_UID),
                    mm_schemas.StreamProcessingEvent.LABELS: labels,
                    mm_schemas.StreamProcessingEvent.FUNCTION_URI: self.server.function_uri
                    if self.server
                    else None,
                    mm_schemas.StreamProcessingEvent.REQUEST: request,
                    mm_schemas.StreamProcessingEvent.RESPONSE: resp,
                    mm_schemas.StreamProcessingEvent.ERROR: error,
                    mm_schemas.StreamProcessingEvent.METRICS: metrics,
                }
            )
        event.body = monitoring_event_list
        return event


class BackgroundTaskStatus(storey.MapClass):
    """
    background task status checker, prevent events from pushing to the model monitoring stream target if model endpoints
    creation failed or in progress
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.matching_endpoints = MatchingEndpointsState.not_yet_checked
        self.graph_model_endpoint_uids: set = set()
        self.listed_model_endpoint_uids: set = set()
        self.server: mlrun.serving.GraphServer = (
            getattr(self.context, "server", None) if self.context else None
        )
        self._background_task_check_timestamp = None
        self._background_task_state = mlrun.common.schemas.BackgroundTaskState.running

    def do(self, event):
        if self.server is None:
            return None
        if (
            self._background_task_state
            == mlrun.common.schemas.BackgroundTaskState.running
            and (
                self._background_task_check_timestamp is None
                or mlrun.utils.now_date() - self._background_task_check_timestamp
                >= timedelta(
                    seconds=mlrun.mlconf.model_endpoint_monitoring.model_endpoint_creation_check_period
                )
            )
        ):
            (
                self._background_task_state,
                self._background_task_check_timestamp,
                self.listed_model_endpoint_uids,
            ) = get_model_endpoints_creation_task_status(self.server)
        if (
            self.listed_model_endpoint_uids
            and self.matching_endpoints == MatchingEndpointsState.not_yet_checked
        ):
            if not self.graph_model_endpoint_uids:
                self.graph_model_endpoint_uids = collect_model_endpoint_uids(
                    self.server
                )

            if self.graph_model_endpoint_uids.issubset(self.listed_model_endpoint_uids):
                self.matching_endpoints = MatchingEndpointsState.all_matched
        elif self.listed_model_endpoint_uids is None:
            self.matching_endpoints = MatchingEndpointsState.no_check_needed

        if (
            self._background_task_state
            == mlrun.common.schemas.BackgroundTaskState.succeeded
            and self.matching_endpoints in MatchingEndpointsState.success_states()
        ):
            return event
        else:
            return None


def collect_model_endpoint_uids(server: mlrun.serving.GraphServer) -> set[str]:
    """Collects all model endpoint UIDs from the server's graph steps."""
    model_endpoint_uids = set()
    for step in server.graph.steps.values():
        if hasattr(step, "monitoring_data"):
            for model in step.monitoring_data.keys():
                uid = step.monitoring_data[model].get(
                    mlrun.common.schemas.MonitoringData.MODEL_ENDPOINT_UID
                )
                if uid:
                    model_endpoint_uids.add(uid)
    return model_endpoint_uids


class SamplingStep(storey.MapClass):
    """sampling step, samples the serving outputs for the model monitoring as sampling_percentage defines"""

    def __init__(
        self,
        sampling_percentage: float | None = 100.0,
        **kwargs,
    ):
        super().__init__(**kwargs)
        self.sampling_percentage = (
            sampling_percentage if 0 < sampling_percentage <= 100 else 100
        )

    def do(self, event):
        logger.debug(
            "sampling step runs",
            event=event,
            sampling_percentage=self.sampling_percentage,
        )
        if self.sampling_percentage != 100 and not event.get(
            mm_schemas.StreamProcessingEvent.ERROR
        ):
            request = event[mm_schemas.StreamProcessingEvent.REQUEST]
            num_of_inputs = len(request["inputs"])
            sampled_requests_indices = self._pick_random_requests(
                num_of_inputs, self.sampling_percentage
            )
            if not sampled_requests_indices:
                return None

            event[mm_schemas.StreamProcessingEvent.REQUEST]["inputs"] = [
                request["inputs"][i] for i in sampled_requests_indices
            ]

            if isinstance(
                event[mm_schemas.StreamProcessingEvent.RESPONSE]["outputs"], list
            ):
                event[mm_schemas.StreamProcessingEvent.RESPONSE]["outputs"] = [
                    event[mm_schemas.StreamProcessingEvent.RESPONSE]["outputs"][i]
                    for i in sampled_requests_indices
                ]
        event[mm_schemas.EventFieldType.SAMPLING_PERCENTAGE] = self.sampling_percentage
        event[mm_schemas.EventFieldType.EFFECTIVE_SAMPLE_COUNT] = len(
            event.get(mm_schemas.StreamProcessingEvent.REQUEST, {}).get("inputs", [])
        )
        return event

    @staticmethod
    def _pick_random_requests(num_of_reqs: int, percentage: float) -> list[int]:
        """
        Randomly selects indices of requests to sample based on the given percentage

        :param num_of_reqs: Number of requests to select from
        :param percentage: Sample percentage for each request
        :return: A list containing the indices of the selected requests
        """

        return [
            req for req in range(num_of_reqs) if random.random() < (percentage / 100)
        ]


class MockStreamPusher(storey.MapClass):
    def __init__(self, output_stream=None, **kwargs):
        super().__init__(**kwargs)
        stream = self.context.stream if self.context else None
        self.output_stream = output_stream or stream.output_stream

    def do(self, event):
        self.output_stream.push(
            [event], partition_key=mm_schemas.StreamProcessingEvent.ENDPOINT_ID
        )
