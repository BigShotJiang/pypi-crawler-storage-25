# Copyright 2023 Iguazio
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import re
from abc import ABC, abstractmethod

import mlrun.common.schemas
from mlrun.config import config as mlconf

_AUTH_SECRET_NAME_TEMPLATE = re.escape(
    mlconf.secret_stores.kubernetes.auth_secret_name.format(
        hashed_access_key="",
    )
)
AUTH_SECRET_PATTERN = re.compile(f"^{_AUTH_SECRET_NAME_TEMPLATE}.*")


def validate_not_forbidden_secret(secret_name: str) -> None:
    """
    Forbid client-supplied references to internal MLRun auth/project secrets.
    No-op when running inside the API server (API enrichments are allowed).
    """
    if not secret_name or mlrun.config.is_running_as_api():
        return
    if AUTH_SECRET_PATTERN.match(secret_name):
        raise mlrun.errors.MLRunInvalidArgumentError(
            f"Forbidden secret '{secret_name}' matches MLRun auth-secret pattern."
        )


class SecretProviderInterface(ABC):
    @abstractmethod
    def store_auth_secret(
        self, username: str, access_key: str, namespace=""
    ) -> (str, mlrun.common.schemas.SecretEventActions):
        pass

    @abstractmethod
    def delete_auth_secret(self, secret_ref: str, namespace=""):
        pass

    @abstractmethod
    def read_auth_secret(self, secret_name, namespace="", raise_on_not_found=False):
        pass

    @abstractmethod
    def store_project_secrets(
        self, project, secrets, namespace=""
    ) -> (str, mlrun.common.schemas.SecretEventActions):
        pass

    @abstractmethod
    def delete_project_secrets(self, project, secrets, namespace=""):
        pass

    @abstractmethod
    def get_project_secret_keys(self, project, namespace="", filter_internal=False):
        pass

    @abstractmethod
    def get_project_secret_data(self, project, secret_keys=None, namespace=""):
        pass

    @abstractmethod
    def get_secret_data(self, secret_name, namespace=""):
        pass

    @abstractmethod
    def store_user_token_secret(
        self,
        auth_info: mlrun.common.schemas.AuthInfo,
        token_name: str,
        token: str,
        expiration: int,
        force: bool = False,
        namespace: str | None = None,
    ) -> mlrun.common.schemas.SecretEventActions | None:
        pass

    @abstractmethod
    def get_user_token_secret_value(
        self,
        user_id: str,
        token_name: str,
        namespace: str | None = None,
    ) -> str:
        pass

    @abstractmethod
    def list_user_token_secrets(
        self,
        user_id: str,
        namespace: str | None = None,
    ) -> list[mlrun.common.schemas.SecretTokenInfo]:
        pass

    @abstractmethod
    def delete_user_token_secret(
        self,
        user_id: str,
        token_name: str,
        namespace: str | None = None,
    ) -> None:
        pass


class InMemorySecretProvider(SecretProviderInterface):
    def __init__(self):
        # project -> secret_key -> secret_value
        self.project_secrets_map = {}
        # ref -> secret_key -> secret_value
        self.auth_secrets_map = {}
        # secret-name -> secret_key -> secret_value
        self.secrets_map = {}

    def store_auth_secret(
        self, username: str, access_key: str, namespace=""
    ) -> (str, mlrun.common.schemas.SecretEventActions):
        secret_ref = self.resolve_auth_secret_name(username, access_key)
        self.auth_secrets_map.setdefault(secret_ref, {}).update(
            self._generate_auth_secret_data(username, access_key)
        )
        return secret_ref, mlrun.common.schemas.SecretEventActions.created

    def delete_auth_secret(self, secret_ref: str, namespace=""):
        del self.auth_secrets_map[secret_ref]

    def read_auth_secret(self, secret_name, namespace="", raise_on_not_found=False):
        secret = self.auth_secrets_map.get(secret_name)
        if not secret:
            if raise_on_not_found:
                raise mlrun.errors.MLRunNotFoundError(
                    f"Secret '{secret_name}' was not found in auth secrets map"
                )

            return None, None
        username = secret[
            mlrun.common.schemas.AuthSecretData.get_field_secret_key("username")
        ]
        access_key = secret[
            mlrun.common.schemas.AuthSecretData.get_field_secret_key("access_key")
        ]
        return username, access_key

    def store_project_secrets(
        self, project, secrets, namespace=""
    ) -> (str, mlrun.common.schemas.SecretEventActions):
        self.project_secrets_map.setdefault(project, {}).update(secrets)
        secret_name = project
        return secret_name, mlrun.common.schemas.SecretEventActions.created

    def delete_project_secrets(self, project, secrets, namespace=""):
        if not secrets:
            self.project_secrets_map.pop(project, None)
        else:
            for key in secrets:
                self.project_secrets_map.get(project, {}).pop(key, None)
        return "", True

    def get_project_secret_keys(self, project, namespace="", filter_internal=False):
        secret_keys = list(self.project_secrets_map.get(project, {}).keys())
        if filter_internal:
            secret_keys = list(
                filter(lambda key: not key.startswith("mlrun."), secret_keys)
            )
        return secret_keys

    def get_project_secret_data(self, project, secret_keys=None, namespace=""):
        secrets_data = self.project_secrets_map.get(project, {})
        return {
            key: value
            for key, value in secrets_data.items()
            if (secret_keys and key in secret_keys) or not secret_keys
        }

    def store_secret(self, secret_name, secrets: dict):
        self.secrets_map[secret_name] = secrets

    def get_secret_data(self, secret_name, namespace=""):
        return self.secrets_map[secret_name]

    def store_user_token_secret(
        self,
        auth_info: mlrun.common.schemas.AuthInfo,
        token_name: str,
        token: str,
        expiration: int,
        force: bool = False,
        namespace: str | None = None,
    ) -> mlrun.common.schemas.SecretEventActions | None:
        secret_name = self.resolve_auth_secret_name(auth_info.user_id, token_name)
        self.secrets_map[secret_name] = {
            "token": token,
            "expiration": expiration,
            "user_id": auth_info.user_id,
            "token_name": token_name,
        }
        return mlrun.common.schemas.SecretEventActions.created

    def get_user_token_secret_value(
        self,
        user_id: str,
        token_name: str,
        namespace: str | None = None,
    ) -> str:
        secret_name = self.resolve_auth_secret_name(user_id, token_name)
        return self.secrets_map[secret_name]["token"]

    def list_user_token_secrets(
        self,
        user_id: str,
        namespace: str | None = None,
    ) -> list[mlrun.common.schemas.SecretTokenInfo]:
        secret_names = list(self.secrets_map.keys())
        return [
            mlrun.common.schemas.SecretTokenInfo(
                name=self.secrets_map[secret_name]["token_name"],
                expiration=self.secrets_map[secret_name]["expiration"],
            )
            for secret_name in secret_names
            if self.secrets_map[secret_name]["user_id"] == user_id
        ]

    def delete_user_token_secret(
        self,
        user_id: str,
        token_name: str,
        namespace: str | None = None,
    ) -> None:
        secret_name = self.resolve_auth_secret_name(user_id, token_name)
        del self.secrets_map[secret_name]

    @staticmethod
    def _generate_auth_secret_data(username: str, access_key: str):
        return {
            mlrun.common.schemas.AuthSecretData.get_field_secret_key(
                "username"
            ): username,
            mlrun.common.schemas.AuthSecretData.get_field_secret_key(
                "access_key"
            ): access_key,
        }

    @staticmethod
    def resolve_auth_secret_name(username: str, access_key: str) -> str:
        return f"secret-ref-{username}-{access_key}"
