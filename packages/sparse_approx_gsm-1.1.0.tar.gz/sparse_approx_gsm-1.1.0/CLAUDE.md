# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Python (+ optional CUDA) implementation of **Sparse Approximation by the Generalized Soft-Min (GSM) Penalty** — a sparse-recovery solver based on the Trimmed Lasso approach. It solves:

> **P0**: min ‖Ax − y‖₂ subject to ‖x‖₀ ≤ k

via a sequence of weighted-ℓ₁ penalized problems with homotopy on penalty parameter λ and regularization parameter γ.

## Environments

Two conda envs exist on this machine:

| Env | Python | Use |
|-----|--------|-----|
| `~/miniconda3` (base) | 3.13 | — |
| `~/miniconda3/envs/nolan_env` | 3.10 | All development: CuPy, pybind11, nvcc |

**Always use `nolan_env`** for building and running.

```bash
NOLAN=/home/projects/nyosef/shachaco/miniconda3/envs/nolan_env
```

## Install (pip)

The preferred way to build and install is via `pip`. The package name is `sparse-approx-gsm`; the importable module is `gsm_python`.

```bash
NOLAN=/home/projects/nyosef/shachaco/miniconda3/envs/nolan_env
NVCC=$NOLAN/bin/nvcc
CMAKE_BIN=$NOLAN/lib/python3.10/site-packages/cmake/data/bin
PYBIND11_DIR=$($NOLAN/bin/python3 -c "import pybind11; print(pybind11.get_cmake_dir())")

cd sparse-approximation-gsm/python
PATH="$CMAKE_BIN:$PATH" \
CMAKE_ARGS="-DCMAKE_CUDA_COMPILER=$NVCC -Dpybind11_DIR=$PYBIND11_DIR -DCMAKE_CXX_COMPILER=/usr/bin/g++" \
  $NOLAN/bin/pip install --no-build-isolation . -v
```

`--no-build-isolation` is required because conda's `compiler_compat/ld` conflicts with the isolated build environment's cmake/ninja. `-DCMAKE_CXX_COMPILER=/usr/bin/g++` bypasses the conda g++ wrapper that injects `-B compiler_compat`.

**CPU-only (no CUDA):** omit `-DCMAKE_CUDA_COMPILER`. The CMakeLists.txt falls back to a CPU-only build automatically.

## Build (CUDA extension — manual cmake)

```bash
NOLAN=/home/projects/nyosef/shachaco/miniconda3/envs/nolan_env
NVCC=$NOLAN/bin/nvcc
CMAKE=$NOLAN/lib/python3.10/site-packages/cmake/data/bin/cmake
PYBIND11_DIR=$($NOLAN/bin/python3 -c "import pybind11; print(pybind11.get_cmake_dir())")
SRC_DIR=gsm_python/cuda
BUILD_DIR=gsm_python/cuda/build

mkdir -p $BUILD_DIR && cd $BUILD_DIR
$CMAKE $SRC_DIR \
  -Dpybind11_DIR=$PYBIND11_DIR \
  -DPYTHON_EXECUTABLE=$NOLAN/bin/python3 \
  -DCMAKE_CUDA_COMPILER=$NVCC \
  -DCMAKE_BUILD_TYPE=Release -Wno-dev
$CMAKE --build . -j4
cp gsm_cuda_core*.so ../
```

> **CUDA version warning**: The NVIDIA A40 driver supports CUDA ≤ 12.6. Using nvcc ≥ 12.7 produces PTX that fails silently at runtime — kernels return zeros for `theta` while `mu` appears correct. Always verify `nvcc --version` ≤ 12.6. The correct toolkit is `cuda-toolkit=12.6.3` in `nolan_env`.

All commands below assume `cd sparse-approximation-gsm/python` first.

## Running Tests

```bash
# Unit tests (CPU, no GPU required)
$NOLAN/bin/python3 -m pytest tests/test_gsm.py -v

# GPU tests (requires CUDA + CuPy)
$NOLAN/bin/python3 tests/test_gsm_gpu.py

# Single pytest test by name
$NOLAN/bin/python3 -m pytest tests/test_gsm.py::TestGSMSpecialCases::test_k_zero -v

# MATLAB comparison tests (requires matlab_ground_truth.mat — generate with MATLAB first)
$NOLAN/bin/python3 -m pytest tests/test_gsm_vs_matlab.py -v
# Generate ground truth (needs MATLAB on PATH):
#   cd tests && matlab -nodisplay -r "generate_matlab_ground_truth; exit"
```

## Architecture

### Package entry point: `gsm_python/__init__.py`
Exports: `SparseApproxGSM`, `sparse_approx_gsm`, `gsm`, `SolverParams`.

### Core algorithm flow

```
gsm_function.py  gsm(z, k, γ)
  └─ special cases: k=0, k=d, γ≤0, γ=∞, k>d/2 → closed-form
  └─ core case (1≤k≤⌊d/2⌋, γ>0):
       └─ GPU: gsm_cuda_core.gsm_core_gpu(z_cupy, k, γ)   [CUDA kernels]
       └─ CPU: gsm_cuda_core.gsm_core(z_np, k, γ)         [C++ via pybind11]
       └─ fallback: pure-Python Algorithms 3–7

solver.py  SparseApproxGSM.solve(y, A, k)
  └─ lambda homotopy (exponential λ sequence)
       └─ gamma homotopy (γ: 0 → ∞, MM iterations)
            └─ FISTA weighted-ℓ₁ subproblem (fista.py)
  └─ post-processing: OMP completion + greedy support swaps (utils.py)
```

### GPU dispatch
`gsm_function.py` detects `isinstance(z, cp.ndarray)` to select the GPU path. `solver.py` accepts `use_gpu=True` which wraps inputs in CuPy. FISTA (`fista.py`) supports both NumPy and CuPy arrays transparently.

### CUDA backend (`gsm_python/cuda/`)
- **`gsm_kernel.cu`**: Implements Algorithms 3–7. Host functions `alg3_host` / `alg6_host` run on CPU; `alg4_kernel`, `alg5_alg7_kernel`, `handle_duplicates_kernel` run on GPU.
- **`gsm_binding.cpp`**: pybind11 bindings. Exposes `gsm_core` (CPU) and `gsm_core_gpu` (CUDA). Falls back to CPU-only if `GSM_CUDA_ENABLED` not set at compile time.
- **`CMakeLists.txt`**: Uses `check_language(CUDA)` — builds GPU module if nvcc found, CPU-only otherwise.

### Parameter profiles (`params.py`)
`fast` / `normal` / `thorough` / `ultra` — trade speed for solution quality. `normal` is the default. Select via `SolverParams(profile="fast")`.

## Key invariants

- `gsm(z, k, γ)` always requires **z ≥ 0** (non-negative input).
- `gsm_core_gpu` / `gsm_core` expect **z sorted descending**; they return `theta` in the same sorted order. Callers must unsort if the original order matters.
- `mu` is always computed on CPU (numerically stable); only `theta` uses GPU kernels.
