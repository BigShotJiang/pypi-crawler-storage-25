"""Compare GSM and L1 on sparse recovery and save detailed trial metrics.

Produces a CSV file with one row per trial and includes:
- true support indices and coordinates
- top-k solution indices and coordinates for GSM and L1
- runtime for each solver
- L2 true loss and solver losses
- metrics: NormObj, RecErr, SuppPrec
"""

import argparse
import json
import os
import subprocess
import sys
import time

import numpy as np
from sklearn.linear_model import LassoCV

# Ensure local package import works when running as a script.
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from gsm_python import sparse_approx_gsm

try:
    import pandas as pd
except ImportError:
    pd = None

try:
    import cupy as cp
    try:
        gpu_count = cp.cuda.runtime.getDeviceCount()
        if gpu_count <= 0:
            raise RuntimeError('no CUDA devices found')
        _HAS_CUPY = True
    except Exception as exc:
        print(f'Warning: GPU backend unavailable: {exc}')
        cp = None
        _HAS_CUPY = False
except ImportError:
    cp = None
    _HAS_CUPY = False

print(f'Initial GPU backend available: {_HAS_CUPY}')


def try_install_cupy_cuda12x():
    """Install cupy-cuda12x into the current Python environment."""
    try:
        print('cupy not found: installing cupy-cuda12x...')
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'cupy-cuda12x'])
        print('cupy-cuda12x installation succeeded.')
        return True
    except Exception as exc:
        print(f'Warning: failed to install cupy-cuda12x: {exc}')
        return False


def normalize_columns(A):
    norms = np.linalg.norm(A, axis=0)
    norms[norms == 0] = 1.0
    return A / norms


def top_k_entries(x, k):
    k = int(k)
    if k <= 0:
        return np.array([], dtype=int), np.array([], dtype=x.dtype)
    idx = np.argsort(-np.abs(x))[:k]
    coords = x[idx]
    return idx, coords


def json_serialize(value):
    return json.dumps(value, separators=(',', ':'))


def compute_metrics(A, y, x0, x_hat, k):
    l2_true_loss = float(np.linalg.norm(A @ x0 - y))
    l2_loss = float(np.linalg.norm(A @ x_hat - y))
    normobj = l2_loss / l2_true_loss if l2_true_loss > 0 else float('inf')
    recerr = float(np.linalg.norm(x_hat - x0, 1)) / np.linalg.norm(x0, 1) if np.linalg.norm(x0, 1) > 0 else float('inf')
    supp_hat = set(np.where(np.abs(x_hat) > 1e-10)[0])
    supp_true = set(np.where(np.abs(x0) > 1e-10)[0])
    suppprec = len(supp_hat & supp_true) / float(k) if k > 0 else 0.0
    nz_count = int(np.sum(np.abs(x_hat) > 1e-10))
    return l2_true_loss, l2_loss, normobj, recerr, suppprec, nz_count


def prepare_trial_record(n, d, k, seed, A, x0, y, x_gsm, gsm_time, x_l1, l1_time):
    support_true = np.where(np.abs(x0) > 1e-10)[0]
    support_true_coords = x0[support_true].tolist()
    true_k = float(k)
    solver_k = int(round(k))
    topk_gsm_idx, topk_gsm_coords = top_k_entries(x_gsm, solver_k)
    topk_l1_idx, topk_l1_coords = top_k_entries(x_l1, solver_k)

    l2_true_loss, l2_gsm_loss, normobj_gsm, recerr_gsm, suppprec_gsm, nz_gsm = compute_metrics(
        A, y, x0, x_gsm, solver_k)
    _, l2_l1_loss, normobj_l1, recerr_l1, suppprec_l1, nz_l1 = compute_metrics(
        A, y, x0, x_l1, solver_k)

    record = {
        'n': int(n),
        'd': int(d),
        'true_k': true_k,
        'solver_k': solver_k,
        'seed': int(seed),
        'true_support_indices': json_serialize(support_true.tolist()),
        'true_support_coords': json_serialize(support_true_coords),
        'topk_gsm_indices': json_serialize(topk_gsm_idx.tolist()),
        'topk_gsm_coords': json_serialize(topk_gsm_coords.tolist()),
        'topk_l1_indices': json_serialize(topk_l1_idx.tolist()),
        'topk_l1_coords': json_serialize(topk_l1_coords.tolist()),
        'nnz_gsm': nz_gsm,
        'nnz_l1': nz_l1,
        'runtime_gsm_s': float(gsm_time),
        'runtime_l1_s': float(l1_time),
        'l2_true_loss': float(l2_true_loss),
        'l2_gsm_loss': float(l2_gsm_loss),
        'l2_l1_loss': float(l2_l1_loss),
        'normobj_gsm': float(normobj_gsm),
        'normobj_l1': float(normobj_l1),
        'recerr_gsm': float(recerr_gsm),
        'recerr_l1': float(recerr_l1),
        'suppprec_gsm': float(suppprec_gsm),
        'suppprec_l1': float(suppprec_l1),
    }
    return record


def solve_l1(A, y, n, d):
    model = LassoCV(cv=5, max_iter=5000, fit_intercept=False, n_jobs=-1)
    model.fit(A, y)
    return model.coef_



def run_single_trial(k, seed, n, d, noise_frac, use_gpu=False):
    trial_start = time.perf_counter()
    rng = np.random.default_rng(seed * 100 + int(k))

    t0 = time.perf_counter()
    A = rng.standard_normal((n, d))
    A = normalize_columns(A)
    x0 = np.zeros(d, dtype=float)
    support = rng.choice(d, int(k), replace=False)
    x0[support] = rng.standard_normal(int(k))
    y_clean = A @ x0
    e = rng.standard_normal(n)
    e *= noise_frac * np.linalg.norm(y_clean) / np.linalg.norm(e)
    y = y_clean + e
    data_time = time.perf_counter() - t0
    print(f'Trial {seed+1}: generated data in {data_time:.3f}s')

    t0 = time.perf_counter()
    print(f'Trial {seed+1}: solving GSM on {"GPU" if use_gpu and _HAS_CUPY else "CPU"}')
    if use_gpu and _HAS_CUPY:
        try:
            x_gsm = sparse_approx_gsm(A, y, int(k), profile='normal', use_gpu=True)
            cp.cuda.Stream.null.synchronize()
        except Exception as exc:
            print(f'Warning: GPU GSM failed ({exc}); retrying CPU GSM fallback.')
            x_gsm = sparse_approx_gsm(A, y, int(k), profile='normal', use_gpu=False)
            use_gpu = False
    else:
        x_gsm = sparse_approx_gsm(A, y, int(k), profile='normal', use_gpu=False)
    gsm_time = time.perf_counter() - t0

    t0 = time.perf_counter()
    x_l1 = solve_l1(A, y, n, d)
    l1_time = time.perf_counter() - t0

    total_time = time.perf_counter() - trial_start
    print(
        f'Trial {seed+1}: data={data_time:.3f}s, gsm={gsm_time:.3f}s, '
        f'l1={l1_time:.3f}s, total={total_time:.3f}s (use_gpu={use_gpu})'
    )

    return A, x0, y, x_gsm, gsm_time, x_l1, l1_time


def save_results(records, output_csv, output_pickle=None):
    if pd is not None:
        df = pd.DataFrame(records)
        df.to_csv(output_csv, index=False)
        if output_pickle is not None:
            df.to_pickle(output_pickle)
    else:
        import csv
        fieldnames = list(records[0].keys())
        with open(output_csv, 'w', newline='') as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)


def build_k_values(args):
    if args.k_values is not None:
        values = [float(x.strip()) for x in args.k_values.split(',') if x.strip()]
        return np.array(values, dtype=float)
    if args.k is not None:
        return np.array([float(args.k)], dtype=float)
    return np.arange(args.k_start, args.k_end + 1e-8, args.k_step)


def parse_args():
    parser = argparse.ArgumentParser(description='Compare GSM and L1 sparse recovery.')
    parser.add_argument('--n', type=int, default=100, help='Number of rows in A')
    parser.add_argument('--d', type=int, default=800, help='Number of columns in A')
    parser.add_argument('--k', type=float, default=None, help='Single true sparsity for x0')
    parser.add_argument('--k-start', type=float, default=15.0, help='Starting k value when running a full benchmark')
    parser.add_argument('--k-end', type=float, default=50.0, help='Ending k value when running a full benchmark')
    parser.add_argument('--k-step', type=float, default=3, help='Step size for k values when running a full benchmark')
    parser.add_argument('--k-values', type=str, default=None, help='Comma-separated list of k values to run')
    parser.add_argument('--noise-frac', type=float, default=0.05, help='Noise fraction ||e|| / ||Ax0||')
    parser.add_argument('--n-trials', type=int, default=10, help='Number of random trials')
    parser.add_argument('--output-csv', type=str, default='compare_lassocv_gsm_results.csv', help='CSV output file')
    parser.add_argument('--output-pkl', type=str, default='compare_lassocv_gsm_results.pkl', help='Optional pickle output file')
    parser.add_argument('--use-gpu', action='store_true', help='Use GPU backend for GSM if available')
    return parser.parse_args()


def main():
    global _HAS_CUPY, cp
    args = parse_args()
    print('compare_l1_gsm starting with args:', args)
    print(f'GPU support available at start: {_HAS_CUPY}')
    records = []
    use_gpu = args.use_gpu and _HAS_CUPY

    if args.use_gpu and not _HAS_CUPY:
        if try_install_cupy_cuda12x():
            try:
                import cupy as cp
                try:
                    gpu_count = cp.cuda.runtime.getDeviceCount()
                    if gpu_count > 0:
                        _HAS_CUPY = True
                    else:
                        raise RuntimeError('no CUDA devices found')
                except Exception as exc:
                    print(f'Warning: GPU backend unavailable after install: {exc}')
                    cp = None
                    _HAS_CUPY = False
            except ImportError as exc:
                print(f'Warning: cupy import failed after install: {exc}')
                cp = None
                _HAS_CUPY = False
        if not _HAS_CUPY:
            print('Warning: cannot enable GPU backend for GSM; falling back to CPU.')
        use_gpu = args.use_gpu and _HAS_CUPY
    print(f'GPU mode requested={args.use_gpu}, enabled={use_gpu}')

    k_values = build_k_values(args)
    print('Running k values:', k_values)

    for k in k_values:
        k_int = int(round(k))
        for seed in range(args.n_trials):
            A, x0, y, x_gsm, gsm_time, x_l1, l1_time = run_single_trial(
                k_int, seed, args.n, args.d, args.noise_frac, use_gpu=use_gpu)
            record = prepare_trial_record(
                args.n, args.d, k, seed, A, x0, y, x_gsm, gsm_time, x_l1, l1_time)
            records.append(record)
            print(f'k={k_int}, trial {seed+1}/{args.n_trials}: GSM loss={record["l2_gsm_loss"]:.4f}, L1 loss={record["l2_l1_loss"]:.4f}')

    if pd is not None and records:
        df = pd.DataFrame(records)
        summary = df.groupby('true_k')[['normobj_gsm','normobj_l1','runtime_gsm_s','runtime_l1_s']].mean()
        print('\nSummary by k (average over trials):')
        print(summary.to_string(float_format='%.4f'))

    output_csv = os.path.abspath(args.output_csv)
    output_pkl = os.path.abspath(args.output_pkl) if args.output_pkl else None
    save_results(records, output_csv, output_pkl)
    print(f'Results saved to: {output_csv}')
    if output_pkl is not None and pd is not None:
        print(f'Pickle saved to: {output_pkl}')


if __name__ == '__main__':
    main()
