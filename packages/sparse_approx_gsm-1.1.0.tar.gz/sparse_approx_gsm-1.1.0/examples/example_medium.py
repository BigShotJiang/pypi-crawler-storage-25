"""
Port of runExampleMedium.m
Test sparse recovery on a medium-sized problem: n=100, d=5000, k=20.
"""

import sys
import os
import time
import numpy as np

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from gsm_python import sparse_approx_gsm


def run_example(n=100, d=5000, k=20, noise_level=0.05, seed=42):
    """Run sparse recovery example."""
    np.random.seed(seed)

    print(f"Sparse Approximation by the Generalized Soft-Min Penalty")
    print(f"Problem size: n={n}, d={d}, k={k}, noise={noise_level*100}%")
    print()

    # Generate random Gaussian dictionary with normalized columns
    A = np.random.randn(n, d)
    col_norms = np.linalg.norm(A, axis=0)
    A = A / col_norms[np.newaxis, :]

    # Generate k-sparse signal
    support = np.random.choice(d, k, replace=False)
    x0 = np.zeros(d)
    x0[support] = np.random.randn(k)

    # Noisy observation
    y_clean = A @ x0
    noise = np.random.randn(n)
    noise = noise * (noise_level * np.linalg.norm(y_clean) / np.linalg.norm(noise))
    y = y_clean + noise

    print(f"  ||y_clean|| = {np.linalg.norm(y_clean):.4f}")
    print(f"  ||noise||   = {np.linalg.norm(noise):.4f}")
    print(f"  SNR         = {np.linalg.norm(y_clean)/np.linalg.norm(noise):.1f}")
    print()

    # Solve
    t0 = time.time()
    x_sol = sparse_approx_gsm(A, y, k, profile='normal', verbosity=2)
    elapsed = time.time() - t0

    # Evaluate
    residual_sol = np.linalg.norm(A @ x_sol - y)
    residual_true = np.linalg.norm(A @ x0 - y)
    rel_residual = residual_sol / residual_true if residual_true > 0 else np.inf
    l1_error = np.linalg.norm(x_sol - x0, 1) / np.linalg.norm(x0, 1) if np.linalg.norm(x0, 1) > 0 else np.inf

    # Support precision
    support_sol = set(np.where(np.abs(x_sol) > 1e-10)[0])
    support_true = set(support)
    precision = len(support_sol & support_true) / max(len(support_sol), 1)

    print()
    print(f"Results:")
    print(f"  Time:              {elapsed:.2f} sec")
    print(f"  ||Ax_sol-y||:      {residual_sol:.6f}")
    print(f"  ||Ax0-y||:         {residual_true:.6f}")
    print(f"  Relative residual: {rel_residual:.4f}")
    print(f"  L1 recovery error: {l1_error:.4f}")
    print(f"  Support precision: {precision*100:.1f}%")
    print(f"  ||x_sol||_0:       {np.sum(np.abs(x_sol) > 1e-10)}")

    return x_sol


if __name__ == '__main__':
    run_example()
