"""Compare GSM performance across solver profiles (fast, normal, thorough, ultra).

Runs trials for each profile and plots:
- NormObj (L2 loss ratio) vs k
- RecErr (L1 recovery error) vs k
- SuppPrec (support precision) vs k
- Runtime vs k

Results are saved as CSV and plots as PNG in the same directory as this script.
"""

import os
import sys
import time

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from gsm_python import sparse_approx_gsm

try:
    import pandas as pd
except ImportError:
    pd = None

PROFILES = ['fast', 'normal', 'thorough', 'ultra']

PROFILE_COLORS = {
    'fast': '#e74c3c',
    'normal': '#3498db',
    'thorough': '#2ecc71',
    'ultra': '#9b59b6',
}
PROFILE_MARKERS = {
    'fast': 'o',
    'normal': 's',
    'thorough': '^',
    'ultra': 'D',
}


def normalize_columns(A):
    norms = np.linalg.norm(A, axis=0)
    norms[norms == 0] = 1.0
    return A / norms


def compute_metrics(A, y, x0, x_hat, k):
    l2_true_loss = float(np.linalg.norm(A @ x0 - y))
    l2_loss = float(np.linalg.norm(A @ x_hat - y))
    normobj = l2_loss / l2_true_loss if l2_true_loss > 0 else float('inf')
    recerr = (float(np.linalg.norm(x_hat - x0, 1)) / np.linalg.norm(x0, 1)
              if np.linalg.norm(x0, 1) > 0 else float('inf'))
    supp_hat = set(np.where(np.abs(x_hat) > 1e-10)[0])
    supp_true = set(np.where(np.abs(x0) > 1e-10)[0])
    suppprec = len(supp_hat & supp_true) / float(k) if k > 0 else 0.0
    return l2_true_loss, l2_loss, normobj, recerr, suppprec


def generate_problem(n, d, k, seed, noise_frac):
    rng = np.random.default_rng(seed * 100 + int(k))
    A = rng.standard_normal((n, d))
    A = normalize_columns(A)
    x0 = np.zeros(d, dtype=float)
    support = rng.choice(d, int(k), replace=False)
    x0[support] = rng.standard_normal(int(k))
    y_clean = A @ x0
    e = rng.standard_normal(n)
    e *= noise_frac * np.linalg.norm(y_clean) / np.linalg.norm(e)
    y = y_clean + e
    return A, x0, y


def run_trials(n, d, k_values, n_trials, noise_frac, profiles):
    """Run all trials and return records list."""
    records = []
    total = len(profiles) * len(k_values) * n_trials
    done = 0
    for profile in profiles:
        for k in k_values:
            k_int = int(round(k))
            for seed in range(n_trials):
                done += 1
                print(f'[{done}/{total}] profile={profile}, k={k_int}, trial={seed+1}')
                A, x0, y = generate_problem(n, d, k_int, seed, noise_frac)

                t0 = time.perf_counter()
                x_hat = sparse_approx_gsm(A, y, k_int, profile=profile, use_gpu=False)
                elapsed = time.perf_counter() - t0

                _, _, normobj, recerr, suppprec = compute_metrics(A, y, x0, x_hat, k_int)
                records.append({
                    'profile': profile,
                    'k': k_int,
                    'seed': seed,
                    'normobj': normobj,
                    'recerr': recerr,
                    'suppprec': suppprec,
                    'runtime_s': elapsed,
                })
    return records


def save_csv(records, path):
    if pd is not None:
        pd.DataFrame(records).to_csv(path, index=False)
    else:
        import csv
        with open(path, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=list(records[0].keys()))
            writer.writeheader()
            writer.writerows(records)
    print(f'Results saved to: {path}')


def aggregate(records):
    """Return dict: profile -> k_values -> metric averages."""
    from collections import defaultdict
    agg = defaultdict(lambda: defaultdict(list))
    for r in records:
        agg[r['profile']][r['k']].append(r)
    result = {}
    for profile, k_dict in agg.items():
        result[profile] = {}
        for k, rows in sorted(k_dict.items()):
            result[profile][k] = {
                'normobj': np.mean([r['normobj'] for r in rows]),
                'recerr': np.mean([r['recerr'] for r in rows]),
                'suppprec': np.mean([r['suppprec'] for r in rows]),
                'runtime_s': np.mean([r['runtime_s'] for r in rows]),
            }
    return result


def make_plots(agg, output_dir, profiles):
    metrics = [
        ('normobj',   'NormObj  (L2 loss / L2 true loss)',  'lower is better'),
        ('recerr',    'RecErr  (L1 recovery error)',         'lower is better'),
        ('suppprec',  'SuppPrec  (support precision)',       'higher is better'),
        ('runtime_s', 'Runtime (s)',                        'lower is better'),
    ]

    fig, axes = plt.subplots(2, 2, figsize=(12, 9))
    axes = axes.flatten()

    for ax, (metric, ylabel, hint) in zip(axes, metrics):
        for profile in profiles:
            if profile not in agg:
                continue
            k_vals = sorted(agg[profile].keys())
            vals = [agg[profile][k][metric] for k in k_vals]
            ax.plot(
                k_vals, vals,
                color=PROFILE_COLORS[profile],
                marker=PROFILE_MARKERS[profile],
                linewidth=1.8,
                markersize=5,
                label=profile,
            )
        ax.set_xlabel('k (true sparsity)', fontsize=11)
        ax.set_ylabel(ylabel, fontsize=11)
        ax.set_title(f'{ylabel}\n({hint})', fontsize=11)
        ax.legend(fontsize=10)
        ax.grid(True, linestyle='--', alpha=0.5)

    fig.suptitle('GSM Profile Comparison', fontsize=14, fontweight='bold')
    fig.tight_layout()

    plot_path = os.path.join(output_dir, 'compare_gsm_profiles.png')
    fig.savefig(plot_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    print(f'Plot saved to: {plot_path}')
    return plot_path


def parse_args():
    import argparse
    parser = argparse.ArgumentParser(description='Compare GSM profiles.')
    parser.add_argument('--n', type=int, default=100)
    parser.add_argument('--d', type=int, default=800)
    parser.add_argument('--k-start', type=float, default=15.0)
    parser.add_argument('--k-end', type=float, default=45.0)
    parser.add_argument('--k-step', type=float, default=5.0)
    parser.add_argument('--k-values', type=str, default=None,
                        help='Comma-separated k values (overrides k-start/end/step)')
    parser.add_argument('--noise-frac', type=float, default=0.05)
    parser.add_argument('--n-trials', type=int, default=5)
    parser.add_argument('--profiles', type=str, default=','.join(PROFILES),
                        help='Comma-separated profiles to compare')
    parser.add_argument('--output-csv', type=str,
                        default=os.path.join(HERE, 'compare_gsm_profiles_results.csv'))
    return parser.parse_args()


def main():
    args = parse_args()
    profiles = [p.strip() for p in args.profiles.split(',') if p.strip()]

    if args.k_values is not None:
        k_values = np.array([float(x.strip()) for x in args.k_values.split(',') if x.strip()])
    else:
        k_values = np.arange(args.k_start, args.k_end + 1e-8, args.k_step)

    print(f'Profiles: {profiles}')
    print(f'k values: {k_values.tolist()}')
    print(f'n={args.n}, d={args.d}, n_trials={args.n_trials}, noise_frac={args.noise_frac}')

    records = run_trials(args.n, args.d, k_values, args.n_trials, args.noise_frac, profiles)

    output_csv = os.path.abspath(args.output_csv)
    save_csv(records, output_csv)

    agg = aggregate(records)

    # Print summary table
    print('\nSummary (mean over trials):')
    header = f'{"profile":>10}  {"k":>4}  {"normobj":>9}  {"recerr":>9}  {"suppprec":>9}  {"runtime_s":>10}'
    print(header)
    print('-' * len(header))
    for profile in profiles:
        if profile not in agg:
            continue
        for k in sorted(agg[profile].keys()):
            m = agg[profile][k]
            print(f'{profile:>10}  {k:>4}  {m["normobj"]:>9.4f}  {m["recerr"]:>9.4f}  '
                  f'{m["suppprec"]:>9.4f}  {m["runtime_s"]:>10.4f}')

    make_plots(agg, HERE, profiles)


if __name__ == '__main__':
    main()
