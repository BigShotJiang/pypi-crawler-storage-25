# cython: boundscheck=False, wraparound=False, cdivision=True, nonecheck=False
"""
Cython-accelerated GSM core computation (Algorithms 3-7).

Direct transliteration of the pure Python fallback in gsm_function.py,
using C math functions, typed memoryviews, and nogil blocks for speed.
"""

from libc.math cimport exp, log, expm1, log1p, fabs, INFINITY
from libc.stdlib cimport malloc, free
from libc.string cimport memcpy
cimport cython

import numpy as np
cimport numpy as cnp

cnp.import_array()

# DBL_MIN for subnormal detection (matches gsm_kernel.cu)
cdef double DBL_MIN_VAL = 2.2250738585072014e-308
cdef double DBL_MAX_VAL = 1.7976931348623157e+308


# ======================================================================
# Algorithm 3: compute b-coefficients and order statistics
# ======================================================================

cdef void _alg3_cy(const double *z, Py_ssize_t d, Py_ssize_t s, double gamma,
                   double *bz_out, double *z_ord_out, double *mu_out,
                   Py_ssize_t k_for_mu) noexcept nogil:
    """Algorithm 3: compute b-coefficients and order statistics.

    z: sorted descending, length d
    s: number of coefficients to compute (typically k or dl)
    bz_out: output b-coefficients, length s+1
    z_ord_out: output order statistics, length s+1
    mu_out: pointer to output mu value (computed using k_for_mu)
    k_for_mu: k value for mu computation
    """
    cdef Py_ssize_t r_1based, q, sp1, limit
    cdef double z_r, xi, eta, log1p_term
    cdef double *b
    cdef double *v
    cdef double *btilde
    cdef double *vtilde
    cdef double *tmp_ptr

    sp1 = s + 1

    # Allocate working buffers
    b = <double *>malloc(sp1 * sizeof(double))
    v = <double *>malloc(sp1 * sizeof(double))
    btilde = <double *>malloc(sp1 * sizeof(double))
    vtilde = <double *>malloc(sp1 * sizeof(double))

    # Initialize
    cdef Py_ssize_t i
    for i in range(sp1):
        b[i] = 0.0
        btilde[i] = 0.0
        v[i] = INFINITY
        vtilde[i] = INFINITY

    for r_1based in range(d, 0, -1):
        z_r = z[r_1based - 1]

        limit = s
        if d - r_1based < limit:
            limit = d - r_1based

        for q in range(1, limit + 1):
            # v[q] = max(min(z_r, vtilde[q-1]), vtilde[q])
            if z_r < vtilde[q - 1]:
                v[q] = z_r
            else:
                v[q] = vtilde[q - 1]
            if vtilde[q] > v[q]:
                v[q] = vtilde[q]

            xi = gamma * (z_r - vtilde[q])
            eta = (btilde[q] - btilde[q - 1]) - xi

            if eta <= 0:
                log1p_term = log1p(
                    (<double>(d - r_1based - q + 1) / <double>(d - r_1based + 1)) * expm1(eta))
                if -xi > 0.0:
                    b[q] = (btilde[q - 1] - (-xi)) + log1p_term
                else:
                    b[q] = btilde[q - 1] + log1p_term
            else:
                log1p_term = log1p(
                    (<double>q / <double>(d - r_1based + 1)) * expm1(-eta))
                if xi > 0.0:
                    b[q] = (btilde[q] - xi) + log1p_term
                else:
                    b[q] = btilde[q] + log1p_term

            if b[q] > 0.0:
                b[q] = 0.0

        if s >= d - r_1based + 1:
            if vtilde[d - r_1based] < z_r:
                v[d - r_1based + 1] = vtilde[d - r_1based]
            else:
                v[d - r_1based + 1] = z_r
            b[d - r_1based + 1] = 0.0

        # Swap pointers (no copy!)
        tmp_ptr = btilde
        btilde = b
        b = tmp_ptr

        tmp_ptr = vtilde
        vtilde = v
        v = tmp_ptr

    # Copy results to output
    for i in range(sp1):
        bz_out[i] = btilde[i]
        z_ord_out[i] = vtilde[i]

    # Compute mu
    cdef double mu = 0.0
    if k_for_mu > 0:
        for q in range(k_for_mu, 0, -1):
            mu = mu + vtilde[q]
        mu = mu + btilde[k_for_mu] / gamma

    mu_out[0] = mu

    free(b)
    free(v)
    free(btilde)
    free(vtilde)


# ======================================================================
# Algorithm 3 with capture of bzr/zr_ord at the right iteration
# ======================================================================

cdef void _alg3_with_zr_cy(const double *z, Py_ssize_t d, Py_ssize_t s, double gamma,
                            Py_ssize_t k_for_mu, Py_ssize_t dr,
                            double *bz_out, double *z_ord_out, double *mu_out,
                            double *bzr_out, double *zr_out) noexcept nogil:
    """Algorithm 3 with capture of bzr/zr_ord at iteration dr."""
    cdef Py_ssize_t r_1based, q, sp1, limit, cap_size
    cdef double z_r, xi, eta, log1p_term
    cdef double *b
    cdef double *v
    cdef double *btilde
    cdef double *vtilde
    cdef double *tmp_ptr

    sp1 = s + 1
    cap_size = dr
    if s < cap_size:
        cap_size = s
    cap_size = cap_size + 1

    b = <double *>malloc(sp1 * sizeof(double))
    v = <double *>malloc(sp1 * sizeof(double))
    btilde = <double *>malloc(sp1 * sizeof(double))
    vtilde = <double *>malloc(sp1 * sizeof(double))

    cdef Py_ssize_t i
    for i in range(sp1):
        b[i] = 0.0
        btilde[i] = 0.0
        v[i] = INFINITY
        vtilde[i] = INFINITY

    for r_1based in range(d, 0, -1):
        z_r = z[r_1based - 1]

        limit = s
        if d - r_1based < limit:
            limit = d - r_1based

        for q in range(1, limit + 1):
            if z_r < vtilde[q - 1]:
                v[q] = z_r
            else:
                v[q] = vtilde[q - 1]
            if vtilde[q] > v[q]:
                v[q] = vtilde[q]

            xi = gamma * (z_r - vtilde[q])
            eta = (btilde[q] - btilde[q - 1]) - xi

            if eta <= 0:
                log1p_term = log1p(
                    (<double>(d - r_1based - q + 1) / <double>(d - r_1based + 1)) * expm1(eta))
                if -xi > 0.0:
                    b[q] = (btilde[q - 1] - (-xi)) + log1p_term
                else:
                    b[q] = btilde[q - 1] + log1p_term
            else:
                log1p_term = log1p(
                    (<double>q / <double>(d - r_1based + 1)) * expm1(-eta))
                if xi > 0.0:
                    b[q] = (btilde[q] - xi) + log1p_term
                else:
                    b[q] = btilde[q] + log1p_term

            if b[q] > 0.0:
                b[q] = 0.0

        if s >= d - r_1based + 1:
            if vtilde[d - r_1based] < z_r:
                v[d - r_1based + 1] = vtilde[d - r_1based]
            else:
                v[d - r_1based + 1] = z_r
            b[d - r_1based + 1] = 0.0

        # Capture bzr/zr_ord at the right moment
        if dr > 0 and r_1based == d - dr + 1:
            for i in range(cap_size):
                bzr_out[i] = b[i]
                zr_out[i] = v[i]

        # Swap
        tmp_ptr = btilde
        btilde = b
        b = tmp_ptr

        tmp_ptr = vtilde
        vtilde = v
        v = tmp_ptr

    # Copy results
    for i in range(sp1):
        bz_out[i] = btilde[i]
        z_ord_out[i] = vtilde[i]

    # Compute mu
    cdef double mu = 0.0
    if k_for_mu > 0:
        for q in range(k_for_mu, 0, -1):
            mu = mu + vtilde[q]
        mu = mu + btilde[k_for_mu] / gamma

    mu_out[0] = mu

    free(b)
    free(v)
    free(btilde)
    free(vtilde)


# ======================================================================
# Algorithm 4: forward recursion for theta^i
# ======================================================================

cdef double _alg4_cy(double z_i, Py_ssize_t d, Py_ssize_t k, double gamma,
                     const double *bz, const double *z_ord) noexcept nogil:
    """Algorithm 4: forward recursion for theta^i."""
    cdef double xi = 0.0
    cdef double factor
    cdef Py_ssize_t q

    for q in range(1, k + 1):
        factor = (<double>q / <double>(d - q + 1)) * exp(
            gamma * (z_i - z_ord[q]) + (bz[q - 1] - bz[q]))
        xi = factor * (1.0 - xi)
        if xi > 1.0:
            xi = 1.0

    if xi < 0.0:
        xi = 0.0
    if xi > 1.0:
        xi = 1.0
    return xi


# ======================================================================
# Algorithm 5: backward recursion for theta_{q,gamma}^i(zl)
# ======================================================================

cdef void _alg5_cy(double zl_i, Py_ssize_t dl, Py_ssize_t k, double gamma,
                   const double *bzl, const double *zl_ord,
                   double *theta_zl_i) noexcept nogil:
    """Algorithm 5: backward recursion for theta_{q,gamma}^i(zl).

    theta_zl_i: output array of length dl+1
    """
    cdef Py_ssize_t q, q_hat
    cdef double eta, frac_term, val

    theta_zl_i[0] = 0.0

    cdef Py_ssize_t i
    for i in range(1, dl + 1):
        theta_zl_i[i] = 0.0
    theta_zl_i[dl] = 1.0

    q_hat = k + 1

    # Forward pass
    for q in range(1, k + 1):
        eta = gamma * (zl_i - zl_ord[q]) + (bzl[q - 1] - bzl[q])
        frac_term = <double>q / <double>(dl - q + 1)

        if eta <= -log(frac_term):
            val = frac_term * exp(eta)
            if val > 1.0:
                val = 1.0
            theta_zl_i[q] = val * (1.0 - theta_zl_i[q - 1])
        else:
            q_hat = q
            break

    # Backward pass
    if q_hat <= k:
        for q in range(dl - 1, q_hat - 1, -1):
            eta = (bzl[q + 1] - bzl[q]) - gamma * (zl_i - zl_ord[q + 1])
            frac_term = <double>(dl - q) / <double>(q + 1)
            val = -frac_term * exp(eta) * theta_zl_i[q + 1] + 1.0
            if val < 0.0:
                val = 0.0
            theta_zl_i[q] = val


# ======================================================================
# Algorithm 6: compute alpha coefficients and delta values
# ======================================================================

cdef void _alg6_cy(Py_ssize_t k, Py_ssize_t dl, Py_ssize_t dr,
                   const double *z_ord, const double *zl_ord, const double *zr_ord,
                   double *delta, double *alpha, double *log_alpha) noexcept nogil:
    """Algorithm 6: compute alpha coefficients and delta values."""
    cdef Py_ssize_t d = dl + dr
    cdef Py_ssize_t q, t, ta, tb, t_mode, t_mode_prev
    cdef double fac, facm1

    # Initialize
    cdef Py_ssize_t i
    for i in range(k + 1):
        delta[i] = 0.0
        alpha[i] = 0.0
        log_alpha[i] = -INFINITY

    alpha[0] = 1.0
    t_mode = 0

    for q in range(1, k + 1):
        ta = q - dr
        if ta < 0:
            ta = 0
        tb = q
        if k < tb:
            tb = k
        if dl < tb:
            tb = dl

        t_mode_prev = t_mode
        t_mode = (<Py_ssize_t>(dl + 1) * <Py_ssize_t>(q + 1)) // (d + 2)

        if t_mode == t_mode_prev:
            fac = (<double>(dr + t_mode - q + 1) * <double>q) / (<double>(d - q + 1) * <double>(q - t_mode))
            alpha[t_mode] = fac * alpha[t_mode_prev]
        elif t_mode == t_mode_prev + 1:
            fac = (<double>(dl - t_mode + 1) * <double>q) / (<double>(d - q + 1) * <double>t_mode)
            alpha[t_mode] = fac * alpha[t_mode_prev]

        # Delta computation
        for t in range(tb, -1, -1):
            if t < 1 or t < ta:
                break
            if z_ord[q] >= zl_ord[t]:
                delta[t] = delta[t - 1] + (z_ord[q] - zl_ord[t])
            else:
                delta[t] = delta[t] + (z_ord[q] - zr_ord[q - t])

        if ta == 0:
            delta[0] = delta[0] + (z_ord[q] - zr_ord[q])
        elif ta > 0:
            delta[ta - 1] = 0.0

    # Propagate alpha and log_alpha
    t_mode = (<Py_ssize_t>(dl + 1) * <Py_ssize_t>(k + 1)) // (d + 2)
    log_alpha[t_mode] = log(alpha[t_mode])

    ta = k - dr
    if ta < 0:
        ta = 0
    tb = k
    if dl < tb:
        tb = dl

    # Zero out invalid entries
    for t in range(k + 1):
        if t < ta or t > tb:
            delta[t] = 0.0
            alpha[t] = 0.0
            log_alpha[t] = -INFINITY

    # Propagate left
    for t in range(t_mode - 1, ta - 1, -1):
        fac = (<double>(t + 1) * <double>(dr - (k - t) + 1)) / (<double>(dl - t) * <double>(k - t))
        alpha[t] = fac * alpha[t + 1]

        if alpha[t] >= DBL_MIN_VAL:
            log_alpha[t] = log(alpha[t])
        elif fac <= 0.5:
            log_alpha[t] = log_alpha[t + 1] + log(fac)
            alpha[t] = 0.0
        else:
            facm1 = (<double>(dr + 1) * <double>(t + 1) - <double>(dl + 1) * <double>(k - t)) / (<double>(dl - t) * <double>(k - t))
            log_alpha[t] = log_alpha[t + 1] + log1p(facm1)
            alpha[t] = 0.0

    # Propagate right
    for t in range(t_mode + 1, tb + 1):
        fac = (<double>(dl - t + 1) * <double>(k - t + 1)) / (<double>t * <double>(dr - k + t))
        alpha[t] = fac * alpha[t - 1]

        if alpha[t] >= DBL_MIN_VAL:
            log_alpha[t] = log(alpha[t])
        elif fac <= 0.5:
            log_alpha[t] = log_alpha[t - 1] + log(fac)
            alpha[t] = 0.0
        else:
            facm1 = (<double>(dl + 1) * <double>(k - t + 1) - <double>(dr + 1) * <double>t) / (<double>t * <double>(dr - k + t))
            log_alpha[t] = log_alpha[t - 1] + log1p(facm1)
            alpha[t] = 0.0


# ======================================================================
# Algorithm 7: combine contributions
# ======================================================================

cdef double _alg7_cy(Py_ssize_t dr, Py_ssize_t k, double gamma,
                     const double *theta_zl_i, const double *bz,
                     const double *bzl, const double *bzr,
                     const double *delta, const double *alpha,
                     const double *log_alpha) noexcept nogil:
    """Algorithm 7: combine contributions."""
    cdef Py_ssize_t qa = 1
    if k - dr > 1:
        qa = k - dr
    cdef Py_ssize_t qb = k
    cdef double xi = 0.0
    cdef Py_ssize_t q
    cdef double alpha_curr, arg_curr, exp_curr, coeff_curr

    for q in range(qb, qa - 1, -1):
        alpha_curr = alpha[q]
        arg_curr = ((bzl[q] + bzr[k - q]) - bz[k]) - gamma * delta[q]
        exp_curr = exp(arg_curr)

        if arg_curr <= 0.0 or (alpha_curr > 0.0 and exp_curr < DBL_MAX_VAL):
            coeff_curr = alpha_curr * exp_curr
            if coeff_curr > 1.0:
                coeff_curr = 1.0
        else:
            coeff_curr = log_alpha[q] + arg_curr
            if coeff_curr > 0.0:
                coeff_curr = 0.0
            coeff_curr = exp(coeff_curr)

        xi = coeff_curr * theta_zl_i[q] + xi

    if xi < 0.0:
        xi = 0.0
    if xi > 1.0:
        xi = 1.0
    return xi


# ======================================================================
# Main entry point: gsm_core_cython
# ======================================================================


def gsm_core_cython(double[::1] z_sorted, Py_ssize_t d, Py_ssize_t k,
                    double gamma, Py_ssize_t dl):
    """Core GSM computation in Cython. z_sorted must be sorted descending.

    Args:
        z_sorted: 1-D contiguous float64 array, sorted descending, length d.
        d: dimension.
        k: sparsity parameter (1 <= k <= d/2).
        gamma: GSM parameter (0 < gamma < inf).
        dl: split point, typically max(2*k - 2, 1).

    Returns:
        mu: float, the GSM function value.
        theta: numpy array (d,), the GSM gradient.
    """
    cdef Py_ssize_t dr = d - dl
    cdef const double *z_ptr = &z_sorted[0]

    # Allocate output arrays
    cdef cnp.ndarray[double, ndim=1] theta_np = np.empty(d, dtype=np.float64)
    cdef double[::1] theta = theta_np

    # Allocate working arrays
    cdef cnp.ndarray[double, ndim=1] bz_np = np.empty(k + 1, dtype=np.float64)
    cdef cnp.ndarray[double, ndim=1] z_ord_np = np.empty(k + 1, dtype=np.float64)
    cdef cnp.ndarray[double, ndim=1] bzl_np = np.empty(dl + 1, dtype=np.float64)
    cdef cnp.ndarray[double, ndim=1] zl_ord_np = np.empty(dl + 1, dtype=np.float64)

    cdef Py_ssize_t bzr_size = dr
    if k < bzr_size:
        bzr_size = k
    bzr_size = bzr_size + 1

    cdef cnp.ndarray[double, ndim=1] bzr_np = np.empty(bzr_size, dtype=np.float64)
    cdef cnp.ndarray[double, ndim=1] zr_ord_np = np.empty(bzr_size, dtype=np.float64)

    cdef cnp.ndarray[double, ndim=1] delta_np = np.empty(k + 1, dtype=np.float64)
    cdef cnp.ndarray[double, ndim=1] alpha_np = np.empty(k + 1, dtype=np.float64)
    cdef cnp.ndarray[double, ndim=1] log_alpha_np = np.empty(k + 1, dtype=np.float64)

    cdef double[::1] bz = bz_np
    cdef double[::1] z_ord = z_ord_np
    cdef double[::1] bzl = bzl_np
    cdef double[::1] zl_ord = zl_ord_np
    cdef double[::1] bzr = bzr_np
    cdef double[::1] zr_ord = zr_ord_np
    cdef double[::1] delta = delta_np
    cdef double[::1] alpha_arr = alpha_np
    cdef double[::1] log_alpha = log_alpha_np

    cdef double mu_val = 0.0
    cdef double mu_dummy = 0.0

    # Algorithm 3: compute b-coefficients for zl (first dl elements)
    _alg3_cy(z_ptr, dl, dl, gamma, &bzl[0], &zl_ord[0], &mu_dummy, 0)

    # Algorithm 3 with zr capture: compute bz, z_ord, bzr, zr_ord
    _alg3_with_zr_cy(z_ptr, d, k, gamma, k, dr,
                     &bz[0], &z_ord[0], &mu_val,
                     &bzr[0], &zr_ord[0])

    # Algorithm 6: compute alpha and delta
    _alg6_cy(k, dl, dr, &z_ord[0], &zl_ord[0], &zr_ord[0],
             &delta[0], &alpha_arr[0], &log_alpha[0])

    # Compute stability threshold
    cdef double stability_thresh = z_ord[k] + (
        (bz[k] - bz[k - 1]) + log(<double>(d - k + 1) / <double>k)
    ) / gamma

    # Allocate theta_zl_i buffer for alg5 (reuse across iterations)
    cdef double *theta_zl_buf = <double *>malloc((dl + 1) * sizeof(double))

    cdef Py_ssize_t i
    cdef double z_i

    for i in range(d - 1, -1, -1):
        z_i = z_sorted[i]

        if i < d - 1 and z_i == z_sorted[i + 1]:
            theta[i] = theta[i + 1]
        elif i >= dl or z_i <= stability_thresh:
            theta[i] = _alg4_cy(z_i, d, k, gamma, &bz[0], &z_ord[0])
        else:
            _alg5_cy(z_i, dl, k, gamma, &bzl[0], &zl_ord[0], theta_zl_buf)
            theta[i] = _alg7_cy(dr, k, gamma, theta_zl_buf, &bz[0],
                                &bzl[0], &bzr[0], &delta[0],
                                &alpha_arr[0], &log_alpha[0])

    free(theta_zl_buf)

    return float(mu_val), theta_np
