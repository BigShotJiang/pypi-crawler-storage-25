"""
Sparse Approximation by the Generalized Soft-Min Penalty.

Python/CUDA implementation based on:
  Tal Amir, Ronen Basri, Boaz Nadler - "The Trimmed Lasso: Sparse Recovery
  Guarantees and Practical Optimization by the Generalized Soft-Min Penalty"

Usage:
    from sparse_approx_gsm import sparse_approx_gsm
    x_sol = sparse_approx_gsm(A, y, k)

    # Or using the class directly:
    from sparse_approx_gsm import SparseApproxGSM
    solver = SparseApproxGSM(A, y, k, profile='fast')
    x_sol = solver.solve()
"""

from .solver import SparseApproxGSM, sparse_approx_gsm
from .gsm_function import gsm
from .params import SolverParams

__all__ = ['SparseApproxGSM', 'sparse_approx_gsm', 'gsm', 'SolverParams']
__version__ = '1.0.0'
