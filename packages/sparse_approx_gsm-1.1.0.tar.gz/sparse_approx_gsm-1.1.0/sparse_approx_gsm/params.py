"""
Parameter profiles for the sparse approximation GSM solver.

Based on sparse_approx_gsm_v1_22.m by Tal Amir, Ronen Basri, Boaz Nadler.
"""

from dataclasses import dataclass, field
from typing import List, Optional
import numpy as np


# Profile defaults: (fast, normal, thorough, ultra)
_PROFILES = {
    'fast': dict(
        n_lambda_vals=5,
        lambda_rel_min=1e-2,
        n_lambdas_sparse_x_to_stop=1,
        gamma_growth_factors=[1.03, 1.1, 1.2, 1.5],
        gamma_binary_search_uncertainty_ratio=1.1,
        gamma_first_max_difference_of_sums=1e-4,
        gamma_test_every_n_iters=10,
        gamma_test_counter_init=9,
        gamma_test_maximal_x_distance_abs=1e-6,
        gamma_test_maximal_x_distance_rel=1e-6,
        w_diff_thresh_to_keep_increasing_gamma=1e-2,
        n_gammas_sparse_x_to_stop=2,
        n_gammas_sparse_w_to_stop=2,
        n_gamma_vals_max=10000,
        Flg_minimal_decrease=1e-2,
        Flg_minimal_decrease_immediate=1e-6,
        Flg_num_small_decreases_for_stopping=2,
        Flg_num_small_decreases_for_stopping_on_infinite_gamma=3,
        Flg_max_num_mm_iters=1000,
        Flw_fista_minimal_decrease=1e-5,
        Flw_fista_num_small_decreases_for_stopping=2,
        n_iter_max_fista=20000,
        fista_monitor_decrease_every_n_iter=3,
        escape_ambiguous_points=True,
        ambiguous_escape_strategy='gradient',
        postprocess_by_omp=False,
        omp_max_num_atoms_to_complete=3,
        sparsity_thresh_abs_x=1e-5,
        sparsity_thresh_abs_w=1e-5,
    ),
    'normal': dict(
        n_lambda_vals=10,
        lambda_rel_min=1e-3,
        n_lambdas_sparse_x_to_stop=1,
        gamma_growth_factors=[1.02, 1.1, 1.2, 1.5],
        gamma_binary_search_uncertainty_ratio=1.1,
        gamma_first_max_difference_of_sums=1e-4,
        gamma_test_every_n_iters=10,
        gamma_test_counter_init=9,
        gamma_test_maximal_x_distance_abs=1e-6,
        gamma_test_maximal_x_distance_rel=1e-6,
        w_diff_thresh_to_keep_increasing_gamma=1e-3,
        n_gammas_sparse_x_to_stop=3,
        n_gammas_sparse_w_to_stop=2,
        n_gamma_vals_max=10000,
        Flg_minimal_decrease=1e-3,
        Flg_minimal_decrease_immediate=1e-6,
        Flg_num_small_decreases_for_stopping=2,
        Flg_num_small_decreases_for_stopping_on_infinite_gamma=5,
        Flg_max_num_mm_iters=1000,
        Flw_fista_minimal_decrease=1e-5,
        Flw_fista_num_small_decreases_for_stopping=2,
        n_iter_max_fista=20000,
        fista_monitor_decrease_every_n_iter=3,
        escape_ambiguous_points=True,
        ambiguous_escape_strategy='ls',
        postprocess_by_omp=False,
        omp_max_num_atoms_to_complete=5,
        sparsity_thresh_abs_x=1e-5,
        sparsity_thresh_abs_w=1e-5,
    ),
    'thorough': dict(
        n_lambda_vals=31,
        lambda_rel_min=1e-5,
        n_lambdas_sparse_x_to_stop=2,
        gamma_growth_factors=[1.02, 1.1, 1.2, 1.5],
        gamma_binary_search_uncertainty_ratio=1.02,
        gamma_first_max_difference_of_sums=1e-4,
        gamma_test_every_n_iters=10,
        gamma_test_counter_init=9,
        gamma_test_maximal_x_distance_abs=1e-6,
        gamma_test_maximal_x_distance_rel=1e-6,
        w_diff_thresh_to_keep_increasing_gamma=1e-4,
        n_gammas_sparse_x_to_stop=5,
        n_gammas_sparse_w_to_stop=4,
        n_gamma_vals_max=10000,
        Flg_minimal_decrease=1e-4,
        Flg_minimal_decrease_immediate=1e-6,
        Flg_num_small_decreases_for_stopping=2,
        Flg_num_small_decreases_for_stopping_on_infinite_gamma=6,
        Flg_max_num_mm_iters=1000,
        Flw_fista_minimal_decrease=1e-6,
        Flw_fista_num_small_decreases_for_stopping=3,
        n_iter_max_fista=20000,
        fista_monitor_decrease_every_n_iter=3,
        escape_ambiguous_points=True,
        ambiguous_escape_strategy='ls',
        postprocess_by_omp=True,
        omp_max_num_atoms_to_complete=10,
        sparsity_thresh_abs_x=1e-6,
        sparsity_thresh_abs_w=1e-6,
    ),
    'ultra': dict(
        n_lambda_vals=43,
        lambda_rel_min=1e-7,
        n_lambdas_sparse_x_to_stop=3,
        gamma_growth_factors=[1.01, 1.1, 1.2, 1.5],
        gamma_binary_search_uncertainty_ratio=1.01,
        gamma_first_max_difference_of_sums=1e-4,
        gamma_test_every_n_iters=10,
        gamma_test_counter_init=9,
        gamma_test_maximal_x_distance_abs=1e-6,
        gamma_test_maximal_x_distance_rel=1e-6,
        w_diff_thresh_to_keep_increasing_gamma=1e-4,
        n_gammas_sparse_x_to_stop=10,
        n_gammas_sparse_w_to_stop=6,
        n_gamma_vals_max=10000,
        Flg_minimal_decrease=1e-5,
        Flg_minimal_decrease_immediate=1e-6,
        Flg_num_small_decreases_for_stopping=3,
        Flg_num_small_decreases_for_stopping_on_infinite_gamma=6,
        Flg_max_num_mm_iters=1000,
        Flw_fista_minimal_decrease=1e-6,
        Flw_fista_num_small_decreases_for_stopping=4,
        n_iter_max_fista=20000,
        fista_monitor_decrease_every_n_iter=3,
        escape_ambiguous_points=True,
        ambiguous_escape_strategy='ls',
        postprocess_by_omp=True,
        omp_max_num_atoms_to_complete=np.inf,
        sparsity_thresh_abs_x=1e-6,
        sparsity_thresh_abs_w=1e-6,
    ),
}


@dataclass
class SolverParams:
    """Parameters for the sparse approximation GSM solver."""

    profile: str = 'normal'
    verbosity: int = 1
    P0_objective_stop_threshold: float = 0.0

    # Lambda-related
    n_lambda_vals: Optional[int] = None
    lambda_rel_min: Optional[float] = None
    lambda_vals: Optional[np.ndarray] = None
    lambda_rel_vals: Optional[np.ndarray] = None
    n_lambdas_sparse_x_to_stop: Optional[int] = None

    # Gamma homotopy
    gamma_growth_factors: Optional[List[float]] = None
    gamma_binary_search_uncertainty_ratio: Optional[float] = None
    gamma_first_max_difference_of_sums: Optional[float] = None
    gamma_test_every_n_iters: Optional[int] = None
    gamma_test_counter_init: Optional[int] = None
    gamma_test_maximal_x_distance_abs: Optional[float] = None
    gamma_test_maximal_x_distance_rel: Optional[float] = None
    w_diff_thresh_to_keep_increasing_gamma: Optional[float] = None
    n_gammas_sparse_x_to_stop: Optional[int] = None
    n_gammas_sparse_w_to_stop: Optional[int] = None
    n_gamma_vals_max: Optional[int] = None

    # F_{lambda,gamma} convergence
    Flg_minimal_decrease: Optional[float] = None
    Flg_minimal_decrease_immediate: Optional[float] = None
    Flg_num_small_decreases_for_stopping: Optional[int] = None
    Flg_num_small_decreases_for_stopping_on_infinite_gamma: Optional[int] = None
    Flg_max_num_mm_iters: Optional[int] = None

    # FISTA
    Flw_fista_minimal_decrease: Optional[float] = None
    Flw_fista_num_small_decreases_for_stopping: Optional[int] = None
    n_iter_max_fista: Optional[int] = None
    fista_monitor_decrease_every_n_iter: Optional[int] = None

    # Post-processing
    escape_ambiguous_points: Optional[bool] = None
    ambiguous_escape_strategy: Optional[str] = None
    postprocess_by_omp: Optional[bool] = None
    omp_max_num_atoms_to_complete: Optional[float] = None
    sparsity_thresh_abs_x: Optional[float] = None
    sparsity_thresh_abs_w: Optional[float] = None

    # Initialization
    x_init: Optional[np.ndarray] = None
    init_x_from_previous_lambda: bool = False
    full_homotopy_with_init: bool = False

    # Gamma upper bound (set during precomputation)
    gamma_over_lambda_upper_bound: Optional[float] = None

    def __post_init__(self):
        if self.profile not in _PROFILES:
            raise ValueError(f"Unknown profile '{self.profile}'. "
                             f"Valid: {list(_PROFILES.keys())}")
        defaults = _PROFILES[self.profile]
        for key, val in defaults.items():
            if getattr(self, key, None) is None:
                setattr(self, key, val)
