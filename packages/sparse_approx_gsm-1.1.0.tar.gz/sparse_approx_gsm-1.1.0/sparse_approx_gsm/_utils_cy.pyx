# cython: boundscheck=False, wraparound=False, cdivision=True, nonecheck=False
"""
Cython-accelerated utility functions for the sparse approximation GSM solver.

Accelerates the OMP correlation selection and greedy improvement inner loops.
"""

from libc.math cimport fabs
cimport cython

import numpy as np
cimport numpy as cnp

cnp.import_array()


def omp_correlation_select(double[:, ::1] A, double[::1] residual,
                           cnp.uint8_t[::1] mask):
    """Compute correlations with residual and find best non-support column.

    Fuses A.T @ residual, masking, and argmax into one pass.

    Args:
        A: matrix (n, d), contiguous row-major.
        residual: vector (n,).
        mask: boolean mask (d,), 1 for valid (non-support) columns.

    Returns:
        j_best: index of the best column.
    """
    cdef Py_ssize_t n = A.shape[0]
    cdef Py_ssize_t d = A.shape[1]
    cdef Py_ssize_t i, j
    cdef double corr, best_corr, dot_val
    cdef Py_ssize_t j_best = 0

    best_corr = -1.0

    with nogil:
        for j in range(d):
            if mask[j] == 0:
                continue
            # Compute |A[:, j] . residual|
            dot_val = 0.0
            for i in range(n):
                dot_val = dot_val + A[i, j] * residual[i]
            corr = fabs(dot_val)
            if corr > best_corr:
                best_corr = corr
                j_best = j

    return j_best
