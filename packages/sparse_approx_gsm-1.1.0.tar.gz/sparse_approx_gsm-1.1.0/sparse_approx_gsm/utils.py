"""
Utility functions for the sparse approximation GSM solver.

Includes: k-sparse projection, least-squares on support, OMP completion,
sparsity measures, and greedy improvement for ambiguous points.
"""

import numpy as np

# Try Cython-accelerated helpers
try:
    from ._utils_cy import omp_correlation_select
    _USE_CY_UTILS = True
except ImportError:
    _USE_CY_UTILS = False


def project_to_k_sparse(x, k):
    """Keep only the k largest-magnitude entries of x.

    Returns:
        x_sparse: k-sparse vector.
        support: indices of the k entries kept.
    """
    x = np.asarray(x).ravel()
    d = x.size
    if k >= d:
        return x.copy(), np.arange(d)

    idx = np.argpartition(-np.abs(x), k)
    support = np.sort(idx[:k])
    x_sparse = np.zeros_like(x)
    x_sparse[support] = x[support]
    return x_sparse, support


def project_and_ls(x, A, y, k):
    """Project x to k-sparse and solve least-squares on the support.

    Returns:
        x_proj: k-sparse vector with LS coefficients on support.
        support: indices of the support.
    """
    _, support = project_to_k_sparse(x, k)
    A_s = A[:, support]
    x_proj = np.zeros(A.shape[1], dtype=np.float64)
    x_proj[support] = np.linalg.lstsq(A_s, y, rcond=None)[0]
    return x_proj, support


def non_sparsity_abs(x, s, thresh):
    """Check if x is approximately s-sparse.

    Returns True if the (s+1)-th largest |x_i| is below thresh.
    """
    x_abs = np.abs(x)
    if s >= x.size:
        return 0.0
    return float(-np.partition(-x_abs, s)[s])  # (s+1)-th largest magnitude


def is_k_sparse(x, k, thresh=1e-5):
    """Check if x is approximately k-sparse."""
    return non_sparsity_abs(x, k, thresh) <= thresh


def get_support(x, k, thresh=1e-5):
    """Get the support of x (indices of k largest magnitude entries)."""
    _, supp = project_to_k_sparse(x, k)
    return supp


def max_diff_of_sums(x, k):
    """Compute max difference of sums for gamma initialization.

    Delta_k(z) = sum of largest (d-k) entries - sum of smallest (d-k) entries
    of z, divided by something useful for gamma_1 determination.
    """
    z = np.abs(x)
    d = z.size
    z_sorted = np.sort(z)[::-1]  # descending
    if k >= d:
        return 0.0
    # Difference between max and min of the sorted absolute values
    # weighted by position
    top = z_sorted[:d - k]
    bot = z_sorted[k:]
    return float(np.max(np.abs(top - bot))) if top.size > 0 else 0.0


def omp_complete(A, y, k, support_init):
    """Complete a partial support to size k using OMP.

    Starting from support_init, greedily add atoms that maximize
    the correlation with the residual until support has k atoms.

    Args:
        A: matrix (n, d).
        y: vector (n,).
        k: target support size.
        support_init: initial support indices.

    Returns:
        x_out: k-sparse vector with LS coefficients.
        support: final support of size k.
    """
    n, d = A.shape
    support = list(support_init)

    if len(support) >= k:
        support = support[:k]
        A_s = A[:, support]
        x_out = np.zeros(d, dtype=np.float64)
        x_out[support] = np.linalg.lstsq(A_s, y, rcond=None)[0]
        return x_out, np.array(support)

    # LS on current support
    A_s = A[:, support]
    coeffs = np.linalg.lstsq(A_s, y, rcond=None)[0]
    residual = y - A_s @ coeffs

    mask = np.ones(d, dtype=bool)
    mask[support] = False

    while len(support) < k:
        # Correlations with residual for all non-support columns
        if _USE_CY_UTILS:
            mask_u8 = mask.view(np.uint8)
            j = omp_correlation_select(A, residual, mask_u8)
        else:
            corr = np.abs(A.T @ residual)
            corr[~mask] = -1.0
            j = int(np.argmax(corr))
        support.append(j)
        mask[j] = False

        # LS on updated support
        A_s = A[:, support]
        coeffs = np.linalg.lstsq(A_s, y, rcond=None)[0]
        residual = y - A_s @ coeffs

    x_out = np.zeros(d, dtype=np.float64)
    x_out[support] = coeffs
    return x_out, np.array(support)


def seek_greedy_improvement(x, A, y, k, lam, strategy='ls'):
    """Try to improve a k-sparse solution by swapping support entries.

    Args:
        x: current k-sparse solution.
        A: matrix (n, d).
        y: vector (n,).
        k: sparsity level.
        lam: current lambda value.
        strategy: 'gradient' or 'ls'.

    Returns:
        x_improved: improved solution (or x if no improvement found).
        improved: bool, whether improvement was found.
    """
    n, d = A.shape
    x_abs = np.abs(x)
    support = np.where(x_abs > 1e-15)[0]

    if len(support) < k:
        return x.copy(), False

    # Find the weakest entry in the support
    support_sorted = support[np.argsort(x_abs[support])]
    i_weakest = support_sorted[0]

    residual = A @ x - y
    energy_best = 0.5 * np.dot(residual, residual)

    non_support = np.setdiff1d(np.arange(d), support)
    if non_support.size == 0:
        return x.copy(), False

    if strategy == 'gradient':
        # Gradient strategy: pick the non-support entry with largest gradient
        grad = A.T @ residual
        j_best = non_support[np.argmax(np.abs(grad[non_support]))]

        # Try swapping
        new_support = np.sort(np.append(np.setdiff1d(support, [i_weakest]), j_best))
        A_s = A[:, new_support]
        coeffs = np.linalg.lstsq(A_s, y, rcond=None)[0]
        r_new = y - A_s @ coeffs
        energy_new = 0.5 * np.dot(r_new, r_new)

        if energy_new < energy_best:
            x_new = np.zeros(d, dtype=np.float64)
            x_new[new_support] = coeffs
            return x_new, True
        return x.copy(), False

    else:  # 'ls' strategy
        # Try all d-k possible swaps
        x_best = x.copy()
        improved = False

        for j in non_support:
            new_support = np.sort(np.append(np.setdiff1d(support, [i_weakest]), j))
            A_s = A[:, new_support]
            coeffs = np.linalg.lstsq(A_s, y, rcond=None)[0]
            r_new = y - A_s @ coeffs
            energy_new = 0.5 * np.dot(r_new, r_new)

            if energy_new < energy_best:
                energy_best = energy_new
                x_best = np.zeros(d, dtype=np.float64)
                x_best[new_support] = coeffs
                improved = True

        return x_best, improved
