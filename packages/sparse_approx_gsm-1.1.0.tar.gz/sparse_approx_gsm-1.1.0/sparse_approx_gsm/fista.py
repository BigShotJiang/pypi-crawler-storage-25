"""
FISTA solver for the weighted L1 problem:

    min_x  (1/2) * ||A*x - y||_2^2  +  lambda * <w, |x|>

Uses CuPy when available, falls back to NumPy/SciPy.
Supports Gram matrix mode (precomputed A'A) for faster iterations when n < d.

Based on Beck & Teboulle (2009) with adaptive restart.
"""

import numpy as np
from math import sqrt

# Backend selection: try CuPy, fall back to NumPy
try:
    import cupy as cp
    _xp = cp
    _HAS_CUPY = True
except ImportError:
    _xp = np
    _HAS_CUPY = False

# Try Cython-accelerated element-wise kernels
try:
    from ._fista_cy import soft_thresh_grad_step, momentum_or_restart
    _USE_CY_FISTA = True
except ImportError:
    _USE_CY_FISTA = False


def _to_xp(arr):
    """Convert array to the active backend (CuPy or NumPy)."""
    if _HAS_CUPY:
        if isinstance(arr, cp.ndarray):
            return arr
        return cp.asarray(arr)
    return np.asarray(arr)


def _to_np(arr):
    """Convert backend array back to numpy."""
    if _HAS_CUPY and isinstance(arr, cp.ndarray):
        return cp.asnumpy(arr)
    return np.asarray(arr)


def fista(A, y, Aty, L, lam, w, x_init=None, params=None,
          G=None, y_norm_sq=None, return_gpu=False):
    """Solve weighted L1 problem via FISTA with adaptive restart.

    Args:
        A: matrix (n, d) on backend device. Only needed if G is None.
        y: vector (n,) on backend device. Only needed if G is None.
        Aty: vector (d,) = A' @ y on backend device.
        L: float, Lipschitz constant (largest singular value of A squared).
        lam: float, penalty parameter lambda.
        w: vector (d,) on backend device, non-negative weights.
        x_init: optional vector (d,) initial point. Default: zeros.
        params: SolverParams with FISTA parameters.
        G: optional (d, d) Gram matrix A'A on backend device. Enables Gram mode.
        y_norm_sq: optional float, ||y||^2. Needed for Gram mode objective.

    Returns:
        x_best: vector (d,), the best solution found.
    """
    xp = _xp

    d = Aty.shape[0]
    Aty = _to_xp(Aty)
    w = _to_xp(w)

    if x_init is not None:
        x = _to_xp(x_init).copy()
    else:
        x = xp.zeros(d, dtype=np.float64)

    # FISTA parameters
    if params is not None:
        max_iter = params.n_iter_max_fista
        min_decrease = params.Flw_fista_minimal_decrease
        n_small_to_stop = params.Flw_fista_num_small_decreases_for_stopping
        monitor_every = params.fista_monitor_decrease_every_n_iter
    else:
        max_iter = 20000
        min_decrease = 1e-5
        n_small_to_stop = 2
        monitor_every = 3

    # Gram mode vs standard mode
    use_gram = G is not None
    if use_gram:
        G = _to_xp(G)
    else:
        A = _to_xp(A)
        y = _to_xp(y)

    # Pre-compute threshold vector
    thresh = (lam / L) * w
    L_inv = 1.0 / L

    # Determine if Cython kernels can be used (NumPy arrays only, not CuPy)
    _use_cy = _USE_CY_FISTA and not _HAS_CUPY

    # FISTA state
    z = x.copy()
    t = 1.0
    x_best = x.copy()
    obj_best = np.inf
    no_decrease_count = 0

    def compute_grad(v):
        """Compute gradient of (1/2)||Av-y||^2 = A'Av - A'y."""
        if use_gram:
            return G @ v - Aty
        else:
            return A.T @ (A @ v - y)

    def compute_objective(v):
        """Compute (1/2)||Av-y||^2 + lambda * <w, |v|>."""
        if use_gram:
            Gv = G @ v
            quad = 0.5 * float(xp.dot(v, Gv)) - float(xp.dot(Aty, v))
            if y_norm_sq is not None:
                quad += 0.5 * y_norm_sq
        else:
            r = A @ v - y
            quad = 0.5 * float(xp.dot(r, r))
        penalty = lam * float(xp.dot(w, xp.abs(v)))
        return quad + penalty

    def soft_thresh(v, t_vec):
        """Proximal operator: soft thresholding."""
        return xp.sign(v) * xp.maximum(xp.abs(v) - t_vec, 0.0)

    if _use_cy:
        x_new = np.empty(d, dtype=np.float64)

    for it in range(1, max_iter + 1):
        # Gradient step
        grad = compute_grad(z)

        if _use_cy:
            # Fused gradient step + soft thresholding (no temporary arrays)
            soft_thresh_grad_step(z, grad, L_inv, thresh, x_new)

            # Fused restart check + momentum update
            t, restarted = momentum_or_restart(x_new, x, z, t)
            x = x_new.copy()
        else:
            # Proximal step: x_new = soft_thresh(z - grad/L, (lambda/L)*w)
            x_new = soft_thresh(z - grad / L, thresh)

            # Adaptive restart check: restart if gradient mapping not descent
            if float(xp.dot(x_new - z, x_new - x)) > 0:
                # Restart
                t = 1.0
                z = x_new.copy()
            else:
                # FISTA momentum update
                t_new = (1.0 + sqrt(1.0 + 4.0 * t * t)) / 2.0
                ratio = (t - 1.0) / t_new
                z = x_new + ratio * (x_new - x)
                t = t_new

            x = x_new

        # Periodic convergence check
        if it % monitor_every == 0:
            obj = compute_objective(x)
            if obj < obj_best:
                obj_best_prev = obj_best
                obj_best = obj
                x_best = x.copy()

                # Check decrease
                if obj_best_prev < np.inf:
                    decrease = obj_best_prev - obj_best
                    if decrease <= min_decrease * obj_best_prev:
                        no_decrease_count += 1
                        if no_decrease_count >= n_small_to_stop:
                            break
                    else:
                        no_decrease_count = 0

    # Final check
    obj_final = compute_objective(x)
    if obj_final < obj_best:
        x_best = x.copy()

    if return_gpu:
        return x_best
    return _to_np(x_best)
