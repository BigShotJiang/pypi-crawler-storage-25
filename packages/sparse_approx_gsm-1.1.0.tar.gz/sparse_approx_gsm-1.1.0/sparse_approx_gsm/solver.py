"""
Sparse Approximation by the Generalized Soft-Min Penalty.

Main solver class implementing the algorithm from:
  Tal Amir, Ronen Basri, Boaz Nadler - "The Trimmed Lasso: Sparse Recovery
  Guarantees and Practical Optimization by the Generalized Soft-Min Penalty"

Solves: min_x ||A*x - y||_2  s.t.  ||x||_0 <= k
"""

import numpy as np
from math import sqrt, log
from .params import SolverParams
from .gsm_function import gsm
from .fista import fista
from .utils import (
    project_to_k_sparse, project_and_ls, is_k_sparse,
    get_support, max_diff_of_sums, omp_complete, seek_greedy_improvement,
    non_sparsity_abs,
)

try:
    import cupy as cp
    _HAS_CUPY = True
except ImportError:
    _HAS_CUPY = False
    cp = None


class SparseApproxGSM:
    """Sparse approximation solver using the Generalized Soft-Min penalty.

    Usage:
        solver = SparseApproxGSM(A, y, k, profile='normal')
        x_sol = solver.solve()
    """

    def __init__(self, A, y, k, **kwargs):
        """Initialize the solver.

        Args:
            A: matrix (n, d), dictionary / design matrix.
            y: vector (n,), observation.
            k: int, target sparsity level (1 < k < n).
            use_gpu: bool, if True and CuPy is available, use GPU for GSM
                     weight computation and FISTA matrix operations.
            **kwargs: additional parameters (see SolverParams).
        """
        self._use_gpu = bool(kwargs.pop('use_gpu', False)) and _HAS_CUPY
        self.A = np.asarray(A, dtype=np.float64)
        self.y = np.asarray(y, dtype=np.float64).ravel()
        self.k = int(k)
        self.n, self.d = self.A.shape
        self.params = SolverParams(**kwargs)

        self._precompute()

    def _ensure_np(self, arr):
        """Convert CuPy array to numpy if needed."""
        if self._use_gpu and _HAS_CUPY and isinstance(arr, cp.ndarray):
            return cp.asnumpy(arr)
        return arr

    def _precompute(self):
        """Precompute matrix properties and optimization data."""
        A, y, k = self.A, self.y, self.k
        n, d = self.n, self.d

        # Singular values for Lipschitz constant and lambda bounds
        sigma = np.linalg.svd(A, compute_uv=False)
        self.norm_A = sigma[0]
        self.L = sigma[0] ** 2  # Lipschitz constant

        # Precomputed products
        self.Aty = A.T @ y
        self.y_norm_sq = float(np.dot(y, y))
        self.norm_y = sqrt(self.y_norm_sq)

        # Gram matrix for FISTA (when d is manageable)
        if d <= 7000:
            self.G = A.T @ A
        else:
            self.G = None

        # Cache GPU copies of immutable arrays (avoids re-transfer every FISTA call)
        if self._use_gpu:
            self._A_gpu = cp.asarray(self.A)
            self._y_gpu = cp.asarray(self.y)
            self._Aty_gpu = cp.asarray(self.Aty)
            self._G_gpu = cp.asarray(self.G) if self.G is not None else None
        else:
            self._A_gpu = self._y_gpu = self._Aty_gpu = self._G_gpu = None

        # Lambda bounds (for power=2 residual)
        # lambda_bar: threshold above which any local min of F_lambda is k-sparse
        # Approximation: lambda_bar ~ sigma_1(A)^2
        self.lambda_large_mult = self.norm_A ** 2 / (2.0 * max(self.norm_y, 1e-15))

        # Gamma/lambda upper bound
        if self.params.gamma_over_lambda_upper_bound is None:
            # log(C(d,k)) approximation using Stirling
            try:
                from scipy.special import gammaln
                log_cdk = gammaln(d + 1) - gammaln(k + 1) - gammaln(d - k + 1)
            except ImportError:
                log_cdk = k * log(d / k) + (d - k) * log(d / (d - k)) if k > 0 and k < d else 0
            self.params.gamma_over_lambda_upper_bound = (
                1e16 * log_cdk / max(0.5 * self.y_norm_sq, 1e-15)
            )

    def solve(self):
        """Solve the sparse approximation problem.

        Returns:
            x_sol: numpy array (d,), estimated k-sparse solution.
        """
        p = self.params
        lambda_vals = self._get_lambda_vals()

        x_best = None
        energy_best = np.inf
        n_consecutive_sparse = 0

        x_init_for_lambda = p.x_init

        for i, lam in enumerate(lambda_vals):
            if p.verbosity >= 2:
                print(f"  Lambda {i+1}/{len(lambda_vals)}: {lam:.6e}")

            # Solve F_lambda
            x_unproj = self._solve_for_lambda(lam, x_init_for_lambda)

            # Project to k-sparse and solve LS on support
            x_proj, _ = project_and_ls(x_unproj, self.A, self.y, self.k)

            # Evaluate P0 objective
            residual = self.A @ x_proj - self.y
            energy = float(np.linalg.norm(residual))

            if energy < energy_best:
                energy_best = energy
                x_best = x_proj.copy()

            # Early stopping: consecutive k-sparse solutions
            if is_k_sparse(x_unproj, self.k, p.sparsity_thresh_abs_x):
                n_consecutive_sparse += 1
                if n_consecutive_sparse >= p.n_lambdas_sparse_x_to_stop:
                    if p.verbosity >= 1:
                        print(f"  Early stop: {n_consecutive_sparse} consecutive sparse solutions")
                    break
            else:
                n_consecutive_sparse = 0

            # Objective threshold
            if energy <= p.P0_objective_stop_threshold:
                if p.verbosity >= 1:
                    print(f"  Reached objective threshold: {energy:.6e}")
                break

            # Initialize next lambda from current solution
            if p.init_x_from_previous_lambda:
                x_init_for_lambda = x_unproj

        if x_best is None:
            x_best = np.zeros(self.d, dtype=np.float64)

        if p.verbosity >= 1:
            residual = self.A @ x_best - self.y
            print(f"  Final ||Ax-y|| = {np.linalg.norm(residual):.6e}")

        return x_best

    def _get_lambda_vals(self):
        """Compute the sequence of lambda values."""
        p = self.params

        if p.lambda_vals is not None:
            return np.sort(np.asarray(p.lambda_vals))

        if p.lambda_rel_vals is not None:
            return np.sort(self.lambda_large_mult * self.norm_y
                           * np.asarray(p.lambda_rel_vals))

        # Exponential progression from lambda_min to lambda_max
        lambda_max = self.lambda_large_mult * self.norm_y * (1 + 1e-8)
        lambda_min = p.lambda_rel_min * self.lambda_large_mult * self.norm_y

        if p.n_lambda_vals <= 1:
            return np.array([lambda_max])

        log_vals = np.linspace(np.log(lambda_min), np.log(lambda_max), p.n_lambda_vals)
        return np.exp(log_vals)

    def _solve_for_lambda(self, lam, x_init=None):
        """Solve F_lambda(x) via gamma homotopy.

        Gradually increases gamma from 0 to infinity, solving
        F_{lambda,gamma}(x) at each step.
        """
        p = self.params
        d, k = self.d, self.k

        # Step 1: gamma = 0 (uniform weights)
        w_uniform = np.full(d, (d - k) / d, dtype=np.float64)
        x_curr = self._solve_weighted_l1(lam, w_uniform, x_init)
        # Outer loop works with numpy; _solve_for_gamma handles GPU internally
        x_curr = self._ensure_np(x_curr)

        if x_init is not None and not p.full_homotopy_with_init:
            # Start gamma from where init becomes useful
            gamma_curr = self._find_starting_gamma(lam, x_curr, x_init)
        else:
            # Determine first nonzero gamma
            md = max_diff_of_sums(x_curr, k)
            if md > 0:
                gamma_curr = p.gamma_first_max_difference_of_sums / md
            else:
                gamma_curr = 1.0

        n_gammas = 0
        n_sparse_x = 0
        n_sparse_w = 0
        i_growth = 0
        growth_factors = p.gamma_growth_factors
        prev_support = None

        while gamma_curr < np.inf and n_gammas < p.n_gamma_vals_max:
            # Solve F_{lambda, gamma}
            x_new = self._solve_for_gamma(lam, gamma_curr, x_curr)
            n_gammas += 1

            # Check weight sparsity to decide if we can jump to gamma=inf
            w_curr, _ = self._compute_weights(x_new, gamma_curr)
            w_non_sparsity = non_sparsity_abs(self._ensure_np(w_curr), d - k, 1)
            if w_non_sparsity <= p.sparsity_thresh_abs_w:
                n_sparse_w += 1
                if n_sparse_w >= p.n_gammas_sparse_w_to_stop:
                    gamma_curr = np.inf
                    continue
            else:
                n_sparse_w = 0

            # Check x sparsity
            if is_k_sparse(x_new, k, p.sparsity_thresh_abs_x):
                curr_support = get_support(x_new, k)
                if prev_support is not None and np.array_equal(curr_support, prev_support):
                    n_sparse_x += 1
                else:
                    n_sparse_x = 1
                prev_support = curr_support

                if n_sparse_x >= p.n_gammas_sparse_x_to_stop:
                    # Try greedy escape
                    if p.escape_ambiguous_points:
                        x_improved, improved = seek_greedy_improvement(
                            x_new, self.A, self.y, k, lam,
                            strategy=p.ambiguous_escape_strategy)
                        if improved:
                            x_new = x_improved
                            n_sparse_x = 0
                            prev_support = None
                        else:
                            gamma_curr = np.inf
                            continue
                    else:
                        gamma_curr = np.inf
                        continue
            else:
                n_sparse_x = 0
                prev_support = None

            x_curr = x_new

            # Increase gamma
            gamma_curr = self._next_gamma(gamma_curr, lam, x_curr, i_growth, growth_factors)

            # Check gamma/lambda upper bound
            if gamma_curr >= lam * p.gamma_over_lambda_upper_bound:
                gamma_curr = np.inf

        # Final step: gamma = inf
        if gamma_curr == np.inf:
            x_curr = self._solve_for_gamma(lam, np.inf, x_curr)

            # OMP post-processing
            if p.postprocess_by_omp:
                x_curr = self._omp_postprocess(x_curr, lam)

        return x_curr

    def _solve_for_gamma(self, lam, gamma, x_init=None):
        """Solve F_{lambda,gamma}(x) via Majorization-Minimization.

        Iteratively: compute weights w from GSM, solve weighted L1 with those weights.
        """
        p = self.params
        d, k = self.d, self.k

        # Initialize (convert to GPU if available for the inner MM loop)
        if x_init is not None:
            if self._use_gpu:
                x_curr = cp.asarray(x_init) if not isinstance(x_init, cp.ndarray) else x_init.copy()
            else:
                x_curr = x_init.copy()
            w_curr, _ = self._compute_weights(x_curr, gamma)
        else:
            if self._use_gpu:
                x_curr = cp.zeros(d, dtype=np.float64)
                w_curr = cp.full(d, (d - k) / d, dtype=np.float64)
            else:
                x_curr = np.zeros(d, dtype=np.float64)
                w_curr = np.full(d, (d - k) / d, dtype=np.float64)

        energy_prev = np.inf
        no_decrease_count = 0
        n_stops = (p.Flg_num_small_decreases_for_stopping_on_infinite_gamma
                   if np.isinf(gamma)
                   else p.Flg_num_small_decreases_for_stopping)

        for mm_iter in range(p.Flg_max_num_mm_iters):
            # Solve weighted L1 subproblem (keep on GPU when available)
            x_new = self._solve_weighted_l1(lam, w_curr, x_curr)

            # Compute new weights and energy (mu cached to avoid redundant gsm call)
            w_new, mu_new = self._compute_weights(x_new, gamma)
            energy_new = self._compute_energy(x_new, lam, w_new, gamma, mu=mu_new)

            # Convergence check
            if energy_prev < np.inf:
                decrease = energy_prev - energy_new
                if decrease <= p.Flg_minimal_decrease_immediate * energy_prev:
                    x_curr = x_new
                    break
                if decrease <= p.Flg_minimal_decrease * energy_prev:
                    no_decrease_count += 1
                    if no_decrease_count >= n_stops:
                        x_curr = x_new
                        break
                else:
                    no_decrease_count = 0

            # Check if weights converged (for gamma=inf)
            if np.isinf(gamma):
                if self._use_gpu and isinstance(w_new, cp.ndarray):
                    w_converged = float(cp.max(cp.abs(w_new - w_curr))) < 1e-12
                else:
                    w_converged = np.allclose(w_new, w_curr, atol=1e-12)
                if w_converged:
                    x_curr = x_new
                    break

            x_curr = x_new
            w_curr = w_new
            energy_prev = energy_new

        # Convert back to numpy at the boundary
        return self._ensure_np(x_curr)

    def _compute_weights(self, x, gamma):
        """Compute GSM weights: w = theta_{d-k, -gamma}(|x|).

        Returns:
            (w, mu): weights and the GSM mu value. w is a CuPy array when
            use_gpu=True and x is a CuPy array; numpy otherwise.
        """
        if gamma == 0:
            ratio = (self.d - self.k) / self.d
            if _HAS_CUPY and isinstance(x, cp.ndarray):
                w = cp.full(self.d, ratio, dtype=np.float64)
                mu = float(ratio * cp.sum(cp.abs(x)))
            else:
                w = np.full(self.d, ratio, dtype=np.float64)
                mu = float(ratio * np.sum(np.abs(x)))
            return w, mu
        if self._use_gpu:
            z = cp.abs(x) if isinstance(x, cp.ndarray) else cp.asarray(np.abs(x))
            mu, w_gpu = gsm(z, self.d - self.k, -gamma)
            return w_gpu, mu
        mu, w = gsm(np.abs(x), self.d - self.k, -gamma)
        return w, mu

    def _compute_energy(self, x, lam, w, gamma, mu=None):
        """Compute F_{lambda,gamma}(x) = (1/2)||Ax-y||^2 + lambda*tau_{k,gamma}(x)."""
        _is_cupy = _HAS_CUPY and isinstance(x, cp.ndarray)
        if _is_cupy:
            r = self._A_gpu @ x - self._y_gpu
            quad = 0.5 * float(cp.dot(r, r))
        else:
            residual = self.A @ x - self.y
            quad = 0.5 * float(np.dot(residual, residual))
        if mu is None:
            if _is_cupy:
                mu, _ = gsm(cp.abs(x), self.d - self.k, -gamma)
            else:
                mu, _ = gsm(np.abs(x), self.d - self.k, -gamma)
        return quad + lam * mu

    def _solve_weighted_l1(self, lam, w, x_init=None):
        """Solve: min (1/2)||Ax-y||^2 + lambda*<w, |x|> via FISTA."""
        if self._use_gpu:
            return fista(
                A=self._A_gpu, y=self._y_gpu, Aty=self._Aty_gpu, L=self.L,
                lam=lam, w=w, x_init=x_init, params=self.params,
                G=self._G_gpu, y_norm_sq=self.y_norm_sq,
                return_gpu=True,
            )
        return fista(
            A=self.A, y=self.y, Aty=self.Aty, L=self.L,
            lam=lam, w=w, x_init=x_init, params=self.params,
            G=self.G, y_norm_sq=self.y_norm_sq,
        )

    def _next_gamma(self, gamma_curr, lam, x_curr, i_growth, growth_factors):
        """Compute the next gamma value in the homotopy."""
        p = self.params

        # Increase gamma by growth factor
        factor = growth_factors[min(i_growth, len(growth_factors) - 1)]
        gamma_next = gamma_curr * factor

        # Keep increasing while weights don't change much
        w_curr, _ = self._compute_weights(x_curr, gamma_curr)
        for _ in range(100):  # safety limit
            w_test, _ = self._compute_weights(x_curr, gamma_next)
            if self._use_gpu and isinstance(w_test, cp.ndarray):
                w_diff = float(cp.max(cp.abs(w_test - w_curr)))
            else:
                w_diff = float(np.max(np.abs(w_test - w_curr)))
            if w_diff > (self.d - self.k) / self.d * p.w_diff_thresh_to_keep_increasing_gamma:
                break
            gamma_next *= factor

        return gamma_next

    def _find_starting_gamma(self, lam, x_gamma0, x_init):
        """Find the smallest gamma where x_init becomes better than x_gamma0."""
        p = self.params
        gamma_a = 0.0
        gamma_b = self.norm_A * 10  # rough upper bound

        energy_0 = self._compute_energy(x_gamma0, lam, None, 0.0)
        energy_init = self._compute_energy(x_init, lam, None, 0.0)

        # If init is already better at gamma=0, start from gamma=0
        if energy_init <= energy_0:
            return p.gamma_first_max_difference_of_sums / max(
                max_diff_of_sums(x_init, self.k), 1e-15)

        # Binary search
        for _ in range(50):
            gamma_mid = sqrt(gamma_a * gamma_b) if gamma_a > 0 else gamma_b / 2
            e_0 = self._compute_energy(x_gamma0, lam, None, gamma_mid)
            e_i = self._compute_energy(x_init, lam, None, gamma_mid)
            if e_i <= e_0:
                gamma_b = gamma_mid
            else:
                gamma_a = gamma_mid
            if gamma_b <= p.gamma_binary_search_uncertainty_ratio * gamma_a:
                break

        return gamma_b

    def _omp_postprocess(self, x, lam):
        """OMP post-processing: try completing partial supports."""
        p = self.params
        k = self.k
        x_best = x.copy()
        energy_best = float(np.linalg.norm(self.A @ x - self.y))

        support = get_support(x, k)
        r_max = min(int(p.omp_max_num_atoms_to_complete), k)

        for s in range(max(k - r_max, 0), k + 1):
            # Take s largest entries and complete by OMP
            if s == 0:
                s_support = np.array([], dtype=int)
            else:
                idx = np.argsort(-np.abs(x))[:s]
                s_support = np.sort(idx)

            x_omp, _ = omp_complete(self.A, self.y, k, s_support)
            energy = float(np.linalg.norm(self.A @ x_omp - self.y))

            if energy < energy_best:
                energy_best = energy
                x_best = x_omp

        return x_best


def sparse_approx_gsm(A, y, k, **kwargs):
    """Convenience function: solve sparse approximation via GSM.

    Args:
        A: matrix (n, d).
        y: vector (n,).
        k: target sparsity.
        **kwargs: passed to SolverParams.

    Returns:
        x_sol: estimated k-sparse solution.
    """
    solver = SparseApproxGSM(A, y, k, **kwargs)
    return solver.solve()
