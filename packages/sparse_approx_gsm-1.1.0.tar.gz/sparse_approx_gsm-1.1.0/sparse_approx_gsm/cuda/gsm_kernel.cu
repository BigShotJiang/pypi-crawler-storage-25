// gsm_kernel.cu
// CUDA implementation of the Generalized Soft-Min function and gradient
//
// Ported from gsm_v5_1_mex.c by Tal Amir, Ronen Basri, Boaz Nadler
// Weizmann Institute of Science
//
// Algorithms 3-7 from:
// "The Trimmed Lasso: Sparse Recovery Guarantees and Practical Optimization
//  by the Generalized Soft-Min Penalty"

#include <cmath>
#include <cstdint>
#include <algorithm>
#include <vector>
#include <cstring>

// ======================================================================
// Configuration
// ======================================================================

// Maximum k supported in device kernels (for local arrays).
// Increase if needed; k is typically 14-50.
#define GSM_MAX_K 256

// ======================================================================
// Type aliases
// ======================================================================
using gsm_num = double;
using size_type = int64_t;
using index_type = int64_t;

static constexpr gsm_num gsm_zero = 0.0;
static constexpr gsm_num gsm_one  = 1.0;
static constexpr gsm_num gsm_inf  = HUGE_VAL;
static constexpr gsm_num gsm_realmin = 2.2250738585072014e-308; // DBL_MIN

// ======================================================================
// Inline math helpers (host + device)
// ======================================================================

#ifdef __CUDACC__
#define GSM_HD __host__ __device__
#else
#define GSM_HD
#endif

GSM_HD inline gsm_num gsm_exp(gsm_num x)   { return exp(x); }
GSM_HD inline gsm_num gsm_log(gsm_num x)   { return log(x); }
GSM_HD inline gsm_num gsm_expm1(gsm_num x) { return expm1(x); }
GSM_HD inline gsm_num gsm_log1p(gsm_num x) { return log1p(x); }
GSM_HD inline gsm_num gsm_fma(gsm_num x, gsm_num y, gsm_num a) { return x * y + a; }
GSM_HD inline gsm_num gsm_max(gsm_num x, gsm_num y) { return fmax(x, y); }
GSM_HD inline gsm_num gsm_min(gsm_num x, gsm_num y) { return fmin(x, y); }
GSM_HD inline gsm_num gsm_subplus(gsm_num x)  { return gsm_max(x, gsm_zero); }
GSM_HD inline gsm_num gsm_subminus(gsm_num x) { return gsm_max(-x, gsm_zero); }
GSM_HD inline gsm_num gsm_trim(gsm_num x) { return gsm_max(gsm_min(x, gsm_one), gsm_zero); }

template<typename T>
GSM_HD inline T tmax(T a, T b) { return a >= b ? a : b; }
template<typename T>
GSM_HD inline T tmin(T a, T b) { return a <= b ? a : b; }


// ======================================================================
// Algorithm 3: Compute mu_{k,gamma}(z) and b-coefficients
// HOST ONLY - sequential DP, O(d*k)
// ======================================================================
//
// Input:  z[0..d-1] (0-based), d, k, gamma, s
// Output: mu (if not null), bz[0..s], z_ord[0..s] (if not null)
// Optional: bzr[0..min(s,dr)], zr_ord[0..min(s,dr)] (if dr > 0)
void alg3_host(
    const gsm_num* z, size_type d, size_type k, gsm_num gamma, size_type s,
    gsm_num* mu, gsm_num* bz, gsm_num* z_ord,
    size_type dr, gsm_num* bzr, gsm_num* zr_ord)
{
    std::vector<gsm_num> b1(s + 1), b2(s + 1), v1(s + 1), v2(s + 1);

    gsm_num *b, *v, *btilde, *vtilde;
    int vecSwitch = 1;

    auto update_ptrs = [&]() {
        b      = (vecSwitch == 1 ? b1.data() : b2.data());
        v      = (vecSwitch == 1 ? v1.data() : v2.data());
        btilde = (vecSwitch == 1 ? b2.data() : b1.data());
        vtilde = (vecSwitch == 1 ? v2.data() : v1.data());
    };
    update_ptrs();

    // Initialize: b[0]=btilde[0]=0, v[0]=vtilde[0]=inf
    b[0] = btilde[0] = gsm_zero;
    v[0] = vtilde[0] = gsm_inf;

    // Main loop: r from d down to 1 (0-based: r_idx from d-1 down to 0)
    for (index_type r = d; r >= 1; --r) {
        gsm_num z_r = z[r - 1]; // 0-based access

        for (index_type q = 1; q <= tmin(s, d - r); ++q) {
            v[q] = gsm_max(gsm_min(z_r, vtilde[q - 1]), vtilde[q]);

            gsm_num xi = gamma * (z_r - vtilde[q]);
            gsm_num eta = (btilde[q] - btilde[q - 1]) - xi;

            if (eta <= gsm_zero) {
                gsm_num log1p_term = gsm_log1p(
                    (static_cast<gsm_num>(d - r - q + 1) / static_cast<gsm_num>(d - r + 1))
                    * gsm_expm1(eta));
                b[q] = (btilde[q - 1] - gsm_subminus(xi)) + log1p_term;
            } else {
                gsm_num log1p_term = gsm_log1p(
                    (static_cast<gsm_num>(q) / static_cast<gsm_num>(d - r + 1))
                    * gsm_expm1(-eta));
                b[q] = (btilde[q] - gsm_subplus(xi)) + log1p_term;
            }
            b[q] = gsm_min(b[q], gsm_zero);
        }

        // Handle q = d-r+1
        if (s >= d - r + 1) {
            v[d - r + 1] = gsm_min(vtilde[d - r], z_r);
            b[d - r + 1] = gsm_zero;
        }

        // Capture bzr at the right moment
        if (dr > 0 && r == d - dr + 1) {
            for (index_type q = 0; q <= tmin(s, dr); ++q) {
                bzr[q] = b[q];
                if (zr_ord) zr_ord[q] = v[q];
            }
        }

        // Swap buffers
        vecSwitch = -vecSwitch;
        update_ptrs();
    }

    // Output bz
    for (index_type q = 0; q <= s; ++q) {
        bz[q] = btilde[q];
    }

    // Output z_ord
    if (z_ord != nullptr) {
        for (index_type q = 0; q <= s; ++q) {
            z_ord[q] = vtilde[q];
        }
    }

    // Output mu
    if (mu != nullptr) {
        *mu = gsm_zero;
        for (index_type q = k; q >= 1; --q) {
            *mu += vtilde[q];
        }
        *mu += btilde[k] / gamma;
    }
}


// ======================================================================
// Algorithm 4: Forward recursion for theta^i (device function)
// ======================================================================
GSM_HD inline gsm_num device_alg4(
    gsm_num z_i, size_type d, size_type k, gsm_num gamma,
    const gsm_num* bz, const gsm_num* z_ord)
{
    gsm_num xi = gsm_zero;
    for (index_type q = 1; q <= k; ++q) {
        gsm_num factor = (static_cast<gsm_num>(q) / static_cast<gsm_num>(d - q + 1))
            * gsm_exp(gsm_fma(gamma, z_i - z_ord[q], bz[q - 1] - bz[q]));
        xi = gsm_min(gsm_one, factor * (gsm_one - xi));
    }
    return gsm_trim(xi);
}


// ======================================================================
// Algorithm 5: Backward recursion for theta_{q,gamma}^i(zl)
// ======================================================================
GSM_HD inline void device_alg5(
    gsm_num zl_i, size_type dl, size_type k, gsm_num gamma,
    const gsm_num* bzl, const gsm_num* zl_ord,
    gsm_num* theta_zl_i)
{
    theta_zl_i[0] = gsm_zero;
    theta_zl_i[dl] = gsm_one;

    index_type q_hat = k + 1;

    // Forward pass
    for (index_type q = 1; q <= k; ++q) {
        gsm_num eta = gamma * (zl_i - zl_ord[q]) + (bzl[q - 1] - bzl[q]);
        gsm_num frac_term = static_cast<gsm_num>(q) / static_cast<gsm_num>(dl - q + 1);

        if (eta <= -gsm_log(frac_term)) {
            theta_zl_i[q] = gsm_min(gsm_one, frac_term * gsm_exp(eta))
                            * (gsm_one - theta_zl_i[q - 1]);
        } else {
            q_hat = q;
            break;
        }
    }

    // Backward pass (if needed)
    if (q_hat <= k) {
        for (index_type q = dl - 1; q >= q_hat; --q) {
            gsm_num eta = (bzl[q + 1] - bzl[q]) - gamma * (zl_i - zl_ord[q + 1]);
            gsm_num frac_term = static_cast<gsm_num>(dl - q) / static_cast<gsm_num>(q + 1);
            theta_zl_i[q] = gsm_max(gsm_zero,
                gsm_fma(-frac_term * gsm_exp(eta), theta_zl_i[q + 1], gsm_one));
        }
    }
}


// ======================================================================
// Algorithm 6: Compute alpha coefficients and delta values
// HOST ONLY - O(k^2), sequential propagation
// ======================================================================
void alg6_host(
    size_type k, size_type dl, size_type dr,
    const gsm_num* z_ord, const gsm_num* zl_ord, const gsm_num* zr_ord,
    gsm_num* delta, gsm_num* alpha, gsm_num* log_alpha)
{
    const size_type d = dl + dr;

    delta[0] = gsm_zero;
    alpha[0] = gsm_one;

    index_type t_mode_prev, t_mode = 0;

    for (index_type q = 1; q <= k; ++q) {
        index_type ta = (dr >= q) ? 0 : (q - dr); // max(0, q-dr)
        index_type tb = tmin(q, tmin(k, dl));

        t_mode_prev = t_mode;
        t_mode = (static_cast<size_type>(dl + 1) * static_cast<size_type>(q + 1))
                 / static_cast<size_type>(d + 2);

        if (t_mode == t_mode_prev) {
            gsm_num fac = static_cast<gsm_num>(
                static_cast<size_type>(dr + t_mode - q + 1) * static_cast<size_type>(q))
                / static_cast<gsm_num>(
                static_cast<size_type>(d - q + 1) * static_cast<size_type>(q - t_mode));
            alpha[t_mode] = fac * alpha[t_mode_prev];
        } else if (t_mode == t_mode_prev + 1) {
            gsm_num fac = static_cast<gsm_num>(
                static_cast<size_type>(dl - t_mode + 1) * static_cast<size_type>(q))
                / static_cast<gsm_num>(
                static_cast<size_type>(d - q + 1) * static_cast<size_type>(t_mode));
            alpha[t_mode] = fac * alpha[t_mode_prev];
        }

        // Calculate delta for t = tb down to max(ta, 1)
        for (index_type t = tb; t >= tmax(ta, static_cast<index_type>(1)); --t) {
            if (z_ord[q] >= zl_ord[t]) {
                delta[t] = delta[t - 1] + (z_ord[q] - zl_ord[t]);
            } else {
                delta[t] = delta[t] + (z_ord[q] - zr_ord[q - t]);
            }
        }

        if (ta == 0) {
            delta[0] += z_ord[q] - zr_ord[q];
        } else {
            delta[ta - 1] = gsm_zero;
        }
    }

    // Propagate alpha and log_alpha from t_mode outward
    t_mode = (static_cast<size_type>(dl + 1) * static_cast<size_type>(k + 1))
             / static_cast<size_type>(d + 2);
    log_alpha[t_mode] = gsm_log(alpha[t_mode]);

    index_type ta = (dr >= k) ? 0 : (k - dr);
    index_type tb = tmin(k, dl);

    // Zero out invalid entries
    for (index_type t = 0; t <= k; ++t) {
        if (t < ta || t > tb) {
            delta[t] = gsm_zero;
            alpha[t] = gsm_zero;
            log_alpha[t] = -gsm_inf;
        }
    }

    // Propagate left from t_mode
    for (index_type t = t_mode - 1; t >= ta; --t) {
        gsm_num fac = static_cast<gsm_num>(
            static_cast<size_type>(t + 1) * static_cast<size_type>(dr - (k - t) + 1))
            / static_cast<gsm_num>(
            static_cast<size_type>(dl - t) * static_cast<size_type>(k - t));

        alpha[t] = fac * alpha[t + 1];

        if (alpha[t] >= gsm_realmin) {
            log_alpha[t] = gsm_log(alpha[t]);
        } else if (fac <= 0.5) {
            log_alpha[t] = log_alpha[t + 1] + gsm_log(fac);
            alpha[t] = gsm_zero; // flush subnormals
        } else {
            gsm_num facm1 = static_cast<gsm_num>(
                static_cast<size_type>(dr + 1) * static_cast<size_type>(t + 1)
                - static_cast<size_type>(dl + 1) * static_cast<size_type>(k - t))
                / static_cast<gsm_num>(
                static_cast<size_type>(dl - t) * static_cast<size_type>(k - t));
            log_alpha[t] = log_alpha[t + 1] + gsm_log1p(facm1);
            alpha[t] = gsm_zero;
        }
    }

    // Propagate right from t_mode
    for (index_type t = t_mode + 1; t <= tb; ++t) {
        gsm_num fac = static_cast<gsm_num>(
            static_cast<size_type>(dl - t + 1) * static_cast<size_type>(k - t + 1))
            / static_cast<gsm_num>(
            static_cast<size_type>(t) * static_cast<size_type>(dr - k + t));

        alpha[t] = fac * alpha[t - 1];

        if (alpha[t] >= gsm_realmin) {
            log_alpha[t] = gsm_log(alpha[t]);
        } else if (fac <= 0.5) {
            log_alpha[t] = log_alpha[t - 1] + gsm_log(fac);
            alpha[t] = gsm_zero;
        } else {
            gsm_num facm1 = static_cast<gsm_num>(
                static_cast<size_type>(dl + 1) * static_cast<size_type>(k - t + 1)
                - static_cast<size_type>(dr + 1) * static_cast<size_type>(t))
                / static_cast<gsm_num>(
                static_cast<size_type>(t) * static_cast<size_type>(dr - k + t));
            log_alpha[t] = log_alpha[t - 1] + gsm_log1p(facm1);
            alpha[t] = gsm_zero;
        }
    }
}


// ======================================================================
// Algorithm 7: Combine theta_zl_i contributions (device function)
// ======================================================================
GSM_HD inline gsm_num device_alg7(
    size_type dr, size_type k, gsm_num gamma,
    const gsm_num* theta_zl_i,
    const gsm_num* bz, const gsm_num* bzl, const gsm_num* bzr,
    const gsm_num* delta, const gsm_num* alpha, const gsm_num* log_alpha)
{
    const index_type qa = (dr >= k) ? 1 : (k - dr); // max(1, k-dr)
    const index_type qb = k;

    gsm_num xi = gsm_zero;

    for (index_type q = qb; q >= qa; --q) {
        gsm_num alpha_curr = alpha[q];
        gsm_num arg_curr = ((bzl[q] + bzr[k - q]) - bz[k]) - gamma * delta[q];
        gsm_num exp_curr = gsm_exp(arg_curr);
        gsm_num coeff_curr;

        if ((arg_curr <= gsm_zero) || ((alpha_curr > gsm_zero) && (exp_curr < 1.7976931348623157e+308))) {
            coeff_curr = gsm_min(gsm_one, alpha_curr * exp_curr);
        } else {
            coeff_curr = gsm_exp(gsm_min(gsm_zero, log_alpha[q] + arg_curr));
        }
        xi = gsm_fma(coeff_curr, theta_zl_i[q], xi);
    }

    return gsm_trim(xi);
}


// ======================================================================
// CUDA Kernels
// ======================================================================

#ifdef __CUDACC__

// Kernel: Compute theta for elements i > dl using Algorithm 4
// Each thread handles one element independently.
__global__ void alg4_kernel(
    const double* __restrict__ z,
    int d, int k, double gamma,
    const double* __restrict__ bz,    // size k+1, in global memory (copied to shared)
    const double* __restrict__ z_ord, // size k+1, in global memory (copied to shared)
    double* __restrict__ theta,
    int start_idx,  // first index to process (0-based)
    int count)      // number of elements to process
{
    // Shared memory for bz and z_ord (read by all threads)
    extern __shared__ double shared[];
    double* s_bz = shared;
    double* s_z_ord = shared + k + 1;

    // Cooperative load into shared memory
    for (int i = threadIdx.x; i <= k; i += blockDim.x) {
        s_bz[i] = bz[i];
        s_z_ord[i] = z_ord[i];
    }
    __syncthreads();

    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= count) return;

    int idx = start_idx + tid;
    double z_i = z[idx];

    // Algorithm 4: forward recursion
    double xi = 0.0;
    for (int q = 1; q <= k; ++q) {
        double factor = ((double)q / (double)(d - q + 1))
            * exp(gamma * (z_i - s_z_ord[q]) + (s_bz[q - 1] - s_bz[q]));
        xi = fmin(1.0, factor * (1.0 - xi));
    }
    theta[idx] = fmax(0.0, fmin(1.0, xi));
}


// Kernel: Compute theta for elements i <= dl using Algorithms 5+7
// Each thread handles one element. dl threads total (small kernel).
__global__ void alg5_alg7_kernel(
    const double* __restrict__ z,
    int d, int k, double gamma,
    int dl, int dr,
    const double* __restrict__ bz,
    const double* __restrict__ z_ord,
    const double* __restrict__ bzl,
    const double* __restrict__ zl_ord,
    const double* __restrict__ bzr,
    const double* __restrict__ delta,
    const double* __restrict__ alpha_arr,
    const double* __restrict__ log_alpha_arr,
    double* __restrict__ theta,
    double stability_thresh)
{
    int tid = threadIdx.x + blockIdx.x * blockDim.x;
    if (tid >= dl) return;

    // Process element i (0-based) = tid
    int i = tid;
    double z_i = z[i];

    // Check for duplicate with next element (handle in a second pass)
    // For now, compute each independently

    if (z_i <= stability_thresh) {
        // Stable case: use alg4
        theta[i] = device_alg4(z_i, d, k, gamma, bz, z_ord);
    } else {
        // Unstable case: use alg5 + alg7
        double theta_zl_i[GSM_MAX_K + 1]; // local array

        device_alg5(z_i, dl, k, gamma, bzl, zl_ord, theta_zl_i);
        theta[i] = device_alg7(dr, k, gamma, theta_zl_i, bz, bzl, bzr,
                                delta, alpha_arr, log_alpha_arr);
    }
}


// Kernel: Handle duplicate z values
// Each thread with a duplicate scans right to find the rightmost element
// in its duplicate group (which has the correctly computed theta).
__global__ void handle_duplicates_kernel(
    const double* __restrict__ z,
    double* __restrict__ theta,
    int d)
{
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid >= d - 1) return;

    int i = tid;
    if (z[i] == z[i + 1]) {
        // Scan right to find the last element in this duplicate group
        int j = i + 1;
        while (j < d - 1 && z[j] == z[j + 1]) {
            ++j;
        }
        // j is the rightmost duplicate; its theta was computed independently
        theta[i] = theta[j];
    }
}


// Kernel: Unsort theta back to original order
__global__ void unsort_kernel(
    const double* __restrict__ theta_sorted,
    const int64_t* __restrict__ sort_indices,
    double* __restrict__ theta_out,
    int d)
{
    int tid = blockIdx.x * blockDim.x + threadIdx.x;
    if (tid < d) {
        theta_out[sort_indices[tid]] = theta_sorted[tid];
    }
}

#endif // __CUDACC__


// ======================================================================
// Host orchestrator: calc_gsm_reduction
// Computes mu_{k,gamma}(z) and theta_{k,gamma}(z) for sorted z
// with 1 <= k <= d/2, 0 < gamma < inf
// ======================================================================

// CPU-only version (for fallback / testing without GPU)
void calc_gsm_reduction_cpu(
    const gsm_num* z, size_type d, size_type k, gsm_num gamma,
    gsm_num* mu_out, gsm_num* theta_out)
{
    size_type dl = tmax(2 * k - 2, static_cast<size_type>(1));
    size_type dr = d - dl;

    // Allocate arrays
    std::vector<gsm_num> bz(k + 1), bzl(dl + 1), bzr(k + 1);
    std::vector<gsm_num> z_ord(k + 1), zl_ord(dl + 1), zr_ord(tmin(k, dr) + 1);
    std::vector<gsm_num> delta(k + 1), alpha(k + 1), log_alpha(k + 1);

    // Step 1: alg3 on full z
    alg3_host(z, d, k, gamma, k, mu_out, bz.data(), z_ord.data(),
              dr, bzr.data(), zr_ord.data());

    // Step 2: alg3 on zl (first dl elements)
    alg3_host(z, dl, 0, gamma, dl, nullptr, bzl.data(), zl_ord.data(),
              0, nullptr, nullptr);

    // Step 3: alg6
    alg6_host(k, dl, dr, z_ord.data(), zl_ord.data(), zr_ord.data(),
              delta.data(), alpha.data(), log_alpha.data());

    // Step 4: calc_theta
    gsm_num stability_thresh = z_ord[k]
        + ((bz[k] - bz[k - 1]) + gsm_log(static_cast<gsm_num>(d - k + 1) / static_cast<gsm_num>(k)))
          / gamma;

    std::vector<gsm_num> theta_zl_i(dl + 1);

    // Process from right to left (i = d-1 down to 0, 0-based)
    for (index_type i = d - 1; i >= 0; --i) {
        if ((i < d - 1) && (z[i] == z[i + 1])) {
            // Duplicate: copy from right neighbor
            theta_out[i] = theta_out[i + 1];
        } else if ((i >= dl) || (z[i] <= stability_thresh)) {
            // Stable case: Algorithm 4
            theta_out[i] = device_alg4(z[i], d, k, gamma, bz.data(), z_ord.data());
        } else {
            // Unstable case: Algorithms 5 + 7
            device_alg5(z[i], dl, k, gamma, bzl.data(), zl_ord.data(), theta_zl_i.data());
            theta_out[i] = device_alg7(dr, k, gamma, theta_zl_i.data(),
                                       bz.data(), bzl.data(), bzr.data(),
                                       delta.data(), alpha.data(), log_alpha.data());
        }
    }
}


#ifdef __CUDACC__

// GPU version: hybrid CPU (alg3, alg6) + GPU (alg4, alg5/7, unsort)
void calc_gsm_reduction_gpu(
    const gsm_num* z_device,  // sorted z on GPU, size d
    size_type d, size_type k, gsm_num gamma,
    gsm_num* mu_out,          // host pointer for mu
    gsm_num* theta_device)    // output theta on GPU, size d
{
    size_type dl = tmax(2 * k - 2, static_cast<size_type>(1));
    size_type dr = d - dl;

    // Host arrays for alg3/alg6
    std::vector<gsm_num> z_host(d);
    std::vector<gsm_num> bz(k + 1), bzl(dl + 1), bzr(k + 1);
    std::vector<gsm_num> z_ord_h(k + 1), zl_ord_h(dl + 1), zr_ord_h(tmin(k, dr) + 1);
    std::vector<gsm_num> delta_h(k + 1), alpha_h(k + 1), log_alpha_h(k + 1);

    // Copy sorted z from device to host for alg3
    cudaMemcpy(z_host.data(), z_device, d * sizeof(gsm_num), cudaMemcpyDeviceToHost);

    // Step 1: alg3 on full z (CPU)
    alg3_host(z_host.data(), d, k, gamma, k, mu_out, bz.data(), z_ord_h.data(),
              dr, bzr.data(), zr_ord_h.data());

    // Step 2: alg3 on zl (CPU)
    alg3_host(z_host.data(), dl, 0, gamma, dl, nullptr, bzl.data(), zl_ord_h.data(),
              0, nullptr, nullptr);

    // Step 3: alg6 (CPU)
    alg6_host(k, dl, dr, z_ord_h.data(), zl_ord_h.data(), zr_ord_h.data(),
              delta_h.data(), alpha_h.data(), log_alpha_h.data());

    // Compute stability threshold
    gsm_num stability_thresh = z_ord_h[k]
        + ((bz[k] - bz[k - 1]) + gsm_log(static_cast<gsm_num>(d - k + 1) / static_cast<gsm_num>(k)))
          / gamma;

    // Step 4: Copy coefficient arrays to device
    gsm_num *d_bz, *d_z_ord, *d_bzl, *d_zl_ord, *d_bzr;
    gsm_num *d_delta, *d_alpha, *d_log_alpha;

    cudaMalloc(&d_bz, (k + 1) * sizeof(gsm_num));
    cudaMalloc(&d_z_ord, (k + 1) * sizeof(gsm_num));
    cudaMalloc(&d_bzl, (dl + 1) * sizeof(gsm_num));
    cudaMalloc(&d_zl_ord, (dl + 1) * sizeof(gsm_num));
    cudaMalloc(&d_bzr, (k + 1) * sizeof(gsm_num));
    cudaMalloc(&d_delta, (k + 1) * sizeof(gsm_num));
    cudaMalloc(&d_alpha, (k + 1) * sizeof(gsm_num));
    cudaMalloc(&d_log_alpha, (k + 1) * sizeof(gsm_num));

    cudaMemcpy(d_bz, bz.data(), (k + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);
    cudaMemcpy(d_z_ord, z_ord_h.data(), (k + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);
    cudaMemcpy(d_bzl, bzl.data(), (dl + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);
    cudaMemcpy(d_zl_ord, zl_ord_h.data(), (dl + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);
    cudaMemcpy(d_bzr, bzr.data(), (k + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);
    cudaMemcpy(d_delta, delta_h.data(), (k + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);
    cudaMemcpy(d_alpha, alpha_h.data(), (k + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);
    cudaMemcpy(d_log_alpha, log_alpha_h.data(), (k + 1) * sizeof(gsm_num), cudaMemcpyHostToDevice);

    // Step 5: Launch alg4 kernel for elements i >= dl
    int count_alg4 = static_cast<int>(d - dl);
    if (count_alg4 > 0) {
        int block_size = 256;
        int grid_size = (count_alg4 + block_size - 1) / block_size;
        size_t shared_mem = 2 * (k + 1) * sizeof(gsm_num);

        alg4_kernel<<<grid_size, block_size, shared_mem>>>(
            z_device, static_cast<int>(d), static_cast<int>(k), gamma,
            d_bz, d_z_ord, theta_device,
            static_cast<int>(dl), count_alg4);
    }

    // Step 6: Launch alg5+alg7 kernel for elements i < dl
    if (dl > 0) {
        int block_size_dl = tmin(static_cast<size_type>(256), dl);
        int grid_size_dl = (static_cast<int>(dl) + block_size_dl - 1) / block_size_dl;

        alg5_alg7_kernel<<<grid_size_dl, block_size_dl>>>(
            z_device, static_cast<int>(d), static_cast<int>(k), gamma,
            static_cast<int>(dl), static_cast<int>(dr),
            d_bz, d_z_ord, d_bzl, d_zl_ord, d_bzr,
            d_delta, d_alpha, d_log_alpha,
            theta_device, stability_thresh);
    }

    // Step 7: Handle duplicate z values
    if (d > 1) {
        int block_size = 256;
        int grid_size = (static_cast<int>(d - 1) + block_size - 1) / block_size;
        handle_duplicates_kernel<<<grid_size, block_size>>>(
            z_device, theta_device, static_cast<int>(d));
    }

    cudaDeviceSynchronize();

    // Cleanup
    cudaFree(d_bz);
    cudaFree(d_z_ord);
    cudaFree(d_bzl);
    cudaFree(d_zl_ord);
    cudaFree(d_bzr);
    cudaFree(d_delta);
    cudaFree(d_alpha);
    cudaFree(d_log_alpha);
}

#endif // __CUDACC__
