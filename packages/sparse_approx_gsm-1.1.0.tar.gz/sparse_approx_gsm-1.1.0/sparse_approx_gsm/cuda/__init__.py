# CUDA/C++ backend for GSM computation
# This package is optional - if gsm_cuda_core is not compiled,
# the pure Python fallback in gsm_function.py is used automatically.

try:
    from . import gsm_cuda_core
except ImportError:
    pass
