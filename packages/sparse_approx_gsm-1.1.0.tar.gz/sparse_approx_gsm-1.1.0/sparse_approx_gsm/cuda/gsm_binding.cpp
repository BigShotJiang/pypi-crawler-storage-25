// gsm_binding.cpp
// pybind11 bindings for the GSM CUDA/C++ implementation
//
// Provides two interfaces:
// - gsm_core(z, k, gamma) -> (mu, theta)  [numpy arrays, CPU]
// - gsm_core_gpu(z, k, gamma) -> (mu, theta)  [CUDA via DLPack, GPU]

#include <pybind11/pybind11.h>
#include <pybind11/numpy.h>
#include <cmath>
#include <vector>
#include <stdexcept>
#ifdef GSM_CUDA_ENABLED
#include <cuda_runtime.h>
#endif

namespace py = pybind11;

// Forward declarations from gsm_kernel.cu / gsm_kernel.cpp
extern void calc_gsm_reduction_cpu(
    const double* z, int64_t d, int64_t k, double gamma,
    double* mu_out, double* theta_out);

#ifdef GSM_CUDA_ENABLED
extern void calc_gsm_reduction_gpu(
    const double* z_device, int64_t d, int64_t k, double gamma,
    double* mu_out, double* theta_device);
#endif


// CPU interface: accepts numpy arrays, returns (mu, theta_numpy)
py::tuple gsm_core(py::array_t<double> z_arr, int64_t k, double gamma) {
    auto z_buf = z_arr.request();
    if (z_buf.ndim != 1) {
        throw std::runtime_error("z must be a 1-dimensional array");
    }

    int64_t d = z_buf.shape[0];
    if (d < 2) throw std::runtime_error("d must be >= 2");
    if (k < 1 || k > d / 2) throw std::runtime_error("k must be in [1, d/2]");
    if (gamma <= 0.0 || std::isinf(gamma)) {
        throw std::runtime_error("gamma must be positive and finite");
    }

    const double* z = static_cast<const double*>(z_buf.ptr);

    double mu;
    auto theta_arr = py::array_t<double>(d);
    auto theta_buf = theta_arr.request();
    double* theta = static_cast<double*>(theta_buf.ptr);

    calc_gsm_reduction_cpu(z, d, k, gamma, &mu, theta);

    return py::make_tuple(mu, theta_arr);
}


#ifdef GSM_CUDA_ENABLED
// GPU interface: accepts a CuPy ndarray, accesses device memory via .data.ptr
// z_gpu must be a sorted, contiguous float64 CuPy array (descending order)
// Returns (mu_float, theta_numpy) — theta is copied back to host
py::tuple gsm_core_gpu(py::object z_gpu, int64_t k, double gamma) {
    // Get dimension from CuPy shape
    int64_t d = z_gpu.attr("shape")[py::int_(0)].cast<int64_t>();

    if (d < 2) throw std::runtime_error("d must be >= 2");
    if (k < 1 || k > d / 2) throw std::runtime_error("k must be in [1, d/2]");
    if (gamma <= 0.0 || std::isinf(gamma))
        throw std::runtime_error("gamma must be positive and finite");

    // Extract raw device pointer from CuPy array (z stays on GPU — no H<->D copy)
    size_t z_ptr_int = z_gpu.attr("data").attr("ptr").cast<size_t>();
    const double* z_device = reinterpret_cast<const double*>(z_ptr_int);

    // Allocate theta output on device
    double* theta_device = nullptr;
    cudaMalloc(&theta_device, d * sizeof(double));

    double mu;
    calc_gsm_reduction_gpu(z_device, d, k, gamma, &mu, theta_device);

    // Copy theta back to host as a numpy array
    auto theta_arr = py::array_t<double>(d);
    double* theta_host = static_cast<double*>(theta_arr.request().ptr);
    cudaMemcpy(theta_host, theta_device, d * sizeof(double), cudaMemcpyDeviceToHost);
    cudaFree(theta_device);

    return py::make_tuple(mu, theta_arr);
}
#endif


PYBIND11_MODULE(gsm_cuda_core, m) {
    m.doc() = "GSM (Generalized Soft-Min) CUDA/C++ implementation";

    m.def("gsm_core", &gsm_core,
          "Compute GSM mu and theta for sorted z (CPU).\n\n"
          "Args:\n"
          "    z: numpy float64 array, sorted descending, size d\n"
          "    k: integer sparsity parameter, 1 <= k <= d/2\n"
          "    gamma: positive finite real number\n\n"
          "Returns:\n"
          "    (mu, theta): mu is float, theta is numpy float64 array size d",
          py::arg("z"), py::arg("k"), py::arg("gamma"));

#ifdef GSM_CUDA_ENABLED
    m.def("gsm_core_gpu", &gsm_core_gpu,
          "Compute GSM mu and theta on GPU (CuPy arrays via DLPack).",
          py::arg("z"), py::arg("k"), py::arg("gamma"));

    m.attr("cuda_available") = true;
#else
    m.attr("cuda_available") = false;
#endif
}
