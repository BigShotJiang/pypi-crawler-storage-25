// gsm_kernel_cpu.cpp
// CPU-only build of the GSM kernel.
// This file includes the .cu source but without CUDA compiler,
// so only the host functions are compiled.
// The __CUDACC__ macro is NOT defined, so CUDA kernels are excluded.

#include "gsm_kernel.cu"
