"""
Generalized Soft-Min function and gradient.

Computes mu_{k,gamma}(z) and theta_{k,gamma}(z) as defined in:
  Tal Amir, Ronen Basri, Boaz Nadler - "The Trimmed Lasso: Sparse Recovery
  Guarantees and Practical Optimization by the Generalized Soft-Min Penalty"

Handles all special cases (k=0, gamma=0/inf, k>d/2, etc.) in Python,
delegating the core computation (1<=k<=d/2, 0<gamma<inf) to either:
  - CUDA/C++ (if gsm_cuda_core is compiled and available)
  - Pure Python/NumPy fallback
"""

import numpy as np

# Try to import compiled C++/CUDA backend
try:
    from .cuda import gsm_cuda_core as _backend
    _USE_NATIVE = True
except ImportError:
    _backend = None
    _USE_NATIVE = False

# Optional CuPy support
try:
    import cupy as cp
    _HAS_CUPY = True
except ImportError:
    _HAS_CUPY = False
    cp = None

_USE_GPU = _HAS_CUPY and _USE_NATIVE and getattr(_backend, 'cuda_available', False)

# Try Cython-accelerated fallback (faster than pure Python, slower than C++)
try:
    from ._gsm_core_cy import gsm_core_cython as _gsm_core_cython
    _USE_CYTHON = True
except ImportError:
    _gsm_core_cython = None
    _USE_CYTHON = False


def gsm(z, k, gamma):
    """Compute the Generalized Soft-Min function and its gradient.

    Args:
        z: 1-D array (float64), dimension d. May be a numpy or CuPy array.
           When z is a CuPy array and the GPU backend is available, the
           computation runs on the GPU and returns a CuPy theta.
        k: integer sparsity parameter, 0 <= k <= d.
        gamma: real number (can be 0, positive, negative, or +/-inf).

    Returns:
        mu: float, the value mu_{k,gamma}(z).
        theta: array (float64), the gradient theta_{k,gamma}(z), same shape as z.
               On the same device (numpy/CuPy) as the input z.
    """
    _is_cupy = _HAS_CUPY and isinstance(z, cp.ndarray)
    xp = cp if _is_cupy else np

    z = xp.asarray(z, dtype=xp.float64).ravel()
    d = z.size

    # --- Special cases (Algorithm 8 from the paper) ---

    if k == 0:
        return 0.0, xp.zeros(d, dtype=xp.float64)

    if k == d:
        return float(z.sum()), xp.ones(d, dtype=xp.float64)

    if gamma == 0.0:
        ratio = k / d
        return float(ratio * z.sum()), xp.full(d, ratio, dtype=xp.float64)

    if gamma < 0:
        mu, theta = gsm(-z, k, -gamma)
        return -mu, theta

    if np.isinf(gamma) and gamma > 0:
        # Hard top-k on CPU (argpartition not available in CuPy for all versions)
        z_np = cp.asnumpy(z) if _is_cupy else z
        idx = np.argpartition(-z_np, k)[:k]
        mu = float(z_np[idx].sum())
        theta_np = np.zeros(d, dtype=np.float64)
        theta_np[idx] = 1.0
        # Handle ties at the boundary
        z_k = np.partition(-z_np, k)[k]
        z_k = -z_k
        on_boundary = np.abs(z_np - z_k) < 1e-15
        n_boundary = on_boundary.sum()
        n_in_top = (z_np[idx] > z_k + 1e-15).sum()
        n_need = k - n_in_top
        if n_boundary > 0 and n_need > 0:
            theta_np[on_boundary] = n_need / n_boundary
        theta = cp.asarray(theta_np) if _is_cupy else theta_np
        return mu, theta

    if 2 * k > d:
        # Reduction: mu_{k,gamma}(z) = sum(z) + mu_{d-k, gamma}(-z)
        mu_comp, theta_comp = gsm(-z, d - k, gamma)
        return float(z.sum()) + mu_comp, 1.0 - theta_comp

    # --- Non-trivial case: 1 <= k <= d/2, 0 < gamma < inf ---

    if _is_cupy and _USE_GPU:
        # Sort on GPU, call GPU backend, convert theta back to CuPy
        I_sort = cp.argsort(-z)
        z_sorted = z[I_sort]                            # sorted CuPy array, stays on GPU
        mu, theta_sorted_np = _backend.gsm_core_gpu(z_sorted, k, gamma)
        theta_sorted = cp.asarray(theta_sorted_np)      # back to GPU
        theta = cp.empty(d, dtype=cp.float64)
        theta[I_sort] = theta_sorted
        return float(mu), theta

    # CPU path (numpy, or CuPy falling back to CPU backend)
    z_np = cp.asnumpy(z) if _is_cupy else z
    dl = max(2 * k - 2, 1)
    I_sort = np.argsort(-z_np)
    z_sorted = z_np[I_sort].copy()

    if _USE_NATIVE:
        mu, theta_sorted = _backend.gsm_core(z_sorted, k, gamma)
    elif _USE_CYTHON:
        mu, theta_sorted = _gsm_core_cython(z_sorted, d, k, gamma, dl)
    else:
        mu, theta_sorted = _gsm_core_python(z_sorted, d, k, gamma, dl)

    theta_np = np.empty(d, dtype=np.float64)
    theta_np[I_sort] = theta_sorted
    theta = cp.asarray(theta_np) if _is_cupy else theta_np

    return float(mu), theta


# ======================================================================
# Pure Python/NumPy implementation of the GSM core
# Used when C++/CUDA backend is not compiled
# ======================================================================

def _gsm_core_python(z, d, k, gamma, dl):
    """Core GSM computation in pure Python. z is sorted descending."""
    dr = d - dl

    # Algorithm 3: compute b-coefficients for full z
    mu_val, bz, z_ord = _alg3(z, d, k, gamma, k)

    # Algorithm 3: compute b-coefficients for zl (first dl elements)
    _, bzl, zl_ord = _alg3(z[:dl], dl, 0, gamma, dl)

    # Also need bzr, zr_ord from the first alg3 call
    # Re-run alg3 with dr capture
    mu_val, bz, z_ord, bzr, zr_ord = _alg3_with_zr(z, d, k, gamma, k, dr)

    # Algorithm 6: compute alpha and delta
    delta, alpha, log_alpha = _alg6(k, dl, dr, z_ord, zl_ord, zr_ord)

    # Compute theta
    stability_thresh = z_ord[k] + (
        (bz[k] - bz[k - 1]) + np.log((d - k + 1) / k)
    ) / gamma

    theta = np.empty(d, dtype=np.float64)

    for i in range(d - 1, -1, -1):
        if i < d - 1 and z[i] == z[i + 1]:
            theta[i] = theta[i + 1]
        elif i >= dl or z[i] <= stability_thresh:
            theta[i] = _alg4(z[i], d, k, gamma, bz, z_ord)
        else:
            theta_zl_i = _alg5(z[i], dl, k, gamma, bzl, zl_ord)
            theta[i] = _alg7(dr, k, gamma, theta_zl_i, bz, bzl, bzr,
                             delta, alpha, log_alpha)

    return mu_val, theta


def _alg3(z, d, k_unused, gamma, s):
    """Algorithm 3: compute b-coefficients and order statistics."""
    b = np.zeros(s + 1, dtype=np.float64)
    v = np.full(s + 1, np.inf, dtype=np.float64)
    btilde = np.zeros(s + 1, dtype=np.float64)
    vtilde = np.full(s + 1, np.inf, dtype=np.float64)

    for r_1based in range(d, 0, -1):
        z_r = z[r_1based - 1]

        for q in range(1, min(s, d - r_1based) + 1):
            v[q] = max(min(z_r, vtilde[q - 1]), vtilde[q])
            xi = gamma * (z_r - vtilde[q])
            eta = (btilde[q] - btilde[q - 1]) - xi

            if eta <= 0:
                log1p_term = np.log1p(
                    ((d - r_1based - q + 1) / (d - r_1based + 1)) * np.expm1(eta))
                b[q] = (btilde[q - 1] - max(-xi, 0.0)) + log1p_term
            else:
                log1p_term = np.log1p(
                    (q / (d - r_1based + 1)) * np.expm1(-eta))
                b[q] = (btilde[q] - max(xi, 0.0)) + log1p_term

            b[q] = min(b[q], 0.0)

        if s >= d - r_1based + 1:
            v[d - r_1based + 1] = min(vtilde[d - r_1based], z_r)
            b[d - r_1based + 1] = 0.0

        # Swap
        btilde, b = b.copy(), btilde
        vtilde, v = v.copy(), vtilde

    bz = btilde.copy()
    z_ord = vtilde.copy()

    # Compute mu
    mu = sum(vtilde[q] for q in range(k_unused, 0, -1)) if k_unused > 0 else 0.0
    if k_unused > 0:
        mu += btilde[k_unused] / gamma

    return mu, bz, z_ord


def _alg3_with_zr(z, d, k, gamma, s, dr):
    """Algorithm 3 with capture of bzr/zr_ord at the right iteration."""
    b = np.zeros(s + 1, dtype=np.float64)
    v = np.full(s + 1, np.inf, dtype=np.float64)
    btilde = np.zeros(s + 1, dtype=np.float64)
    vtilde = np.full(s + 1, np.inf, dtype=np.float64)

    bzr = np.zeros(min(s, dr) + 1, dtype=np.float64)
    zr_ord = np.full(min(s, dr) + 1, np.inf, dtype=np.float64)

    for r_1based in range(d, 0, -1):
        z_r = z[r_1based - 1]

        for q in range(1, min(s, d - r_1based) + 1):
            v[q] = max(min(z_r, vtilde[q - 1]), vtilde[q])
            xi = gamma * (z_r - vtilde[q])
            eta = (btilde[q] - btilde[q - 1]) - xi

            if eta <= 0:
                log1p_term = np.log1p(
                    ((d - r_1based - q + 1) / (d - r_1based + 1)) * np.expm1(eta))
                b[q] = (btilde[q - 1] - max(-xi, 0.0)) + log1p_term
            else:
                log1p_term = np.log1p(
                    (q / (d - r_1based + 1)) * np.expm1(-eta))
                b[q] = (btilde[q] - max(xi, 0.0)) + log1p_term

            b[q] = min(b[q], 0.0)

        if s >= d - r_1based + 1:
            v[d - r_1based + 1] = min(vtilde[d - r_1based], z_r)
            b[d - r_1based + 1] = 0.0

        # Capture bzr at the right moment
        if dr > 0 and r_1based == d - dr + 1:
            for q in range(min(s, dr) + 1):
                bzr[q] = b[q]
                zr_ord[q] = v[q]

        btilde, b = b.copy(), btilde
        vtilde, v = v.copy(), vtilde

    bz = btilde.copy()
    z_ord = vtilde.copy()

    mu = sum(vtilde[q] for q in range(k, 0, -1))
    mu += btilde[k] / gamma

    return mu, bz, z_ord, bzr, zr_ord


def _alg4(z_i, d, k, gamma, bz, z_ord):
    """Algorithm 4: forward recursion for theta^i."""
    xi = 0.0
    for q in range(1, k + 1):
        factor = (q / (d - q + 1)) * np.exp(
            gamma * (z_i - z_ord[q]) + (bz[q - 1] - bz[q]))
        xi = min(1.0, factor * (1.0 - xi))
    return max(0.0, min(1.0, xi))


def _alg5(zl_i, dl, k, gamma, bzl, zl_ord):
    """Algorithm 5: backward recursion for theta_{q,gamma}^i(zl)."""
    theta_zl_i = np.zeros(dl + 1, dtype=np.float64)
    theta_zl_i[0] = 0.0
    theta_zl_i[dl] = 1.0

    q_hat = k + 1

    # Forward pass
    for q in range(1, k + 1):
        eta = gamma * (zl_i - zl_ord[q]) + (bzl[q - 1] - bzl[q])
        frac_term = q / (dl - q + 1)

        if eta <= -np.log(frac_term):
            theta_zl_i[q] = min(1.0, frac_term * np.exp(eta)) * (1.0 - theta_zl_i[q - 1])
        else:
            q_hat = q
            break

    # Backward pass
    if q_hat <= k:
        for q in range(dl - 1, q_hat - 1, -1):
            eta = (bzl[q + 1] - bzl[q]) - gamma * (zl_i - zl_ord[q + 1])
            frac_term = (dl - q) / (q + 1)
            theta_zl_i[q] = max(0.0,
                -frac_term * np.exp(eta) * theta_zl_i[q + 1] + 1.0)

    return theta_zl_i


def _alg6(k, dl, dr, z_ord, zl_ord, zr_ord):
    """Algorithm 6: compute alpha coefficients and delta values."""
    d = dl + dr
    delta = np.zeros(k + 1, dtype=np.float64)
    alpha = np.zeros(k + 1, dtype=np.float64)
    log_alpha = np.full(k + 1, -np.inf, dtype=np.float64)

    alpha[0] = 1.0
    t_mode = 0

    for q in range(1, k + 1):
        ta = max(0, q - dr)
        tb = min(q, min(k, dl))

        t_mode_prev = t_mode
        t_mode = ((dl + 1) * (q + 1)) // (d + 2)

        if t_mode == t_mode_prev:
            fac = ((dr + t_mode - q + 1) * q) / ((d - q + 1) * (q - t_mode))
            alpha[t_mode] = fac * alpha[t_mode_prev]
        elif t_mode == t_mode_prev + 1:
            fac = ((dl - t_mode + 1) * q) / ((d - q + 1) * t_mode)
            alpha[t_mode] = fac * alpha[t_mode_prev]

        # Delta computation
        for t in range(tb, max(ta, 1) - 1, -1):
            if z_ord[q] >= zl_ord[t]:
                delta[t] = delta[t - 1] + (z_ord[q] - zl_ord[t])
            else:
                delta[t] = delta[t] + (z_ord[q] - zr_ord[q - t])

        if ta == 0:
            delta[0] += z_ord[q] - zr_ord[q]
        elif ta > 0:
            delta[ta - 1] = 0.0

    # Propagate alpha and log_alpha
    t_mode = ((dl + 1) * (k + 1)) // (d + 2)
    log_alpha[t_mode] = np.log(alpha[t_mode])

    ta = max(0, k - dr)
    tb = min(k, dl)

    # Zero out invalid entries
    for t in range(k + 1):
        if t < ta or t > tb:
            delta[t] = 0.0
            alpha[t] = 0.0
            log_alpha[t] = -np.inf

    # Propagate left
    for t in range(t_mode - 1, ta - 1, -1):
        fac = ((t + 1) * (dr - (k - t) + 1)) / ((dl - t) * (k - t))
        alpha[t] = fac * alpha[t + 1]

        if alpha[t] >= 2.2250738585072014e-308:  # DBL_MIN
            log_alpha[t] = np.log(alpha[t])
        elif fac <= 0.5:
            log_alpha[t] = log_alpha[t + 1] + np.log(fac)
            alpha[t] = 0.0
        else:
            facm1 = ((dr + 1) * (t + 1) - (dl + 1) * (k - t)) / ((dl - t) * (k - t))
            log_alpha[t] = log_alpha[t + 1] + np.log1p(facm1)
            alpha[t] = 0.0

    # Propagate right
    for t in range(t_mode + 1, tb + 1):
        fac = ((dl - t + 1) * (k - t + 1)) / (t * (dr - k + t))
        alpha[t] = fac * alpha[t - 1]

        if alpha[t] >= 2.2250738585072014e-308:
            log_alpha[t] = np.log(alpha[t])
        elif fac <= 0.5:
            log_alpha[t] = log_alpha[t - 1] + np.log(fac)
            alpha[t] = 0.0
        else:
            facm1 = ((dl + 1) * (k - t + 1) - (dr + 1) * t) / (t * (dr - k + t))
            log_alpha[t] = log_alpha[t - 1] + np.log1p(facm1)
            alpha[t] = 0.0

    return delta, alpha, log_alpha


def _alg7(dr, k, gamma, theta_zl_i, bz, bzl, bzr, delta, alpha, log_alpha):
    """Algorithm 7: combine contributions."""
    qa = max(1, k - dr)
    qb = k
    xi = 0.0

    for q in range(qb, qa - 1, -1):
        alpha_curr = alpha[q]
        arg_curr = ((bzl[q] + bzr[k - q]) - bz[k]) - gamma * delta[q]
        exp_curr = np.exp(arg_curr)

        if arg_curr <= 0.0 or (alpha_curr > 0.0 and exp_curr < 1.7976931348623157e+308):
            coeff_curr = min(1.0, alpha_curr * exp_curr)
        else:
            coeff_curr = np.exp(min(0.0, log_alpha[q] + arg_curr))

        xi = coeff_curr * theta_zl_i[q] + xi

    return max(0.0, min(1.0, xi))
