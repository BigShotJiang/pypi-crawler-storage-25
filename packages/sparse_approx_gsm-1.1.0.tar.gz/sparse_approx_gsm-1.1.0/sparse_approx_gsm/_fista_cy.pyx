# cython: boundscheck=False, wraparound=False, cdivision=True, nonecheck=False
"""
Cython-accelerated helper kernels for the FISTA solver.

Fuses element-wise operations to eliminate temporary array allocations
and Python function call overhead in the inner loop.
"""

from libc.math cimport fabs, sqrt
cimport cython

import numpy as np
cimport numpy as cnp

cnp.import_array()


def soft_thresh_grad_step(double[::1] z, double[::1] grad, double L_inv,
                          double[::1] thresh, double[::1] out):
    """Fused gradient step + soft thresholding: out = sign(z - grad/L) * max(|z - grad/L| - thresh, 0).

    Replaces: x_new = sign(v) * max(|v| - t, 0) where v = z - grad/L
    Eliminates 4 temporary arrays.
    """
    cdef Py_ssize_t d = z.shape[0]
    cdef Py_ssize_t i
    cdef double v, av

    with nogil:
        for i in range(d):
            v = z[i] - grad[i] * L_inv
            av = fabs(v)
            if av > thresh[i]:
                if v > 0.0:
                    out[i] = av - thresh[i]
                else:
                    out[i] = thresh[i] - av
            else:
                out[i] = 0.0


def momentum_or_restart(double[::1] x_new, double[::1] x_old,
                        double[::1] z, double t):
    """Fused restart check + momentum update.

    Computes dot(x_new - z, x_new - x_old). If positive, restarts (t=1, z=x_new).
    Otherwise, applies FISTA momentum: t_new = (1+sqrt(1+4t^2))/2, z = x_new + ratio*(x_new - x_old).

    Returns:
        new_t: updated t value.
        restarted: 1 if restarted, 0 otherwise.
    """
    cdef Py_ssize_t d = x_new.shape[0]
    cdef Py_ssize_t i
    cdef double dot_val = 0.0
    cdef double diff_xz, diff_xx
    cdef double t_new, ratio

    # Compute restart dot product
    with nogil:
        for i in range(d):
            diff_xz = x_new[i] - z[i]
            diff_xx = x_new[i] - x_old[i]
            dot_val = dot_val + diff_xz * diff_xx

    if dot_val > 0.0:
        # Restart: z = x_new, t = 1
        with nogil:
            for i in range(d):
                z[i] = x_new[i]
        return 1.0, 1
    else:
        # FISTA momentum
        t_new = (1.0 + sqrt(1.0 + 4.0 * t * t)) / 2.0
        ratio = (t - 1.0) / t_new
        with nogil:
            for i in range(d):
                z[i] = x_new[i] + ratio * (x_new[i] - x_old[i])
        return t_new, 0


def weighted_abs_dot(double[::1] w, double[::1] v):
    """Compute dot(w, abs(v)) without allocating abs(v)."""
    cdef Py_ssize_t d = w.shape[0]
    cdef Py_ssize_t i
    cdef double result = 0.0

    with nogil:
        for i in range(d):
            result = result + w[i] * fabs(v[i])

    return result
