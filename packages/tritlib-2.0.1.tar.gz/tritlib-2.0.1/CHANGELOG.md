# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to [Semantic Versioning](https://semver.org/).

## [2.0.0] — 2026-05-18

### Breaking
- `Tryte` is now a fixed-width 9-trit type (T9), aligned with Setnex ISA v0.8.
  Its constructor no longer accepts a `width` argument. Code that did
  `Tryte(value, w)` for `w ≠ 9` must migrate to `TritArray(value, w)`.
- The arbitrary-width balanced ternary word type historically named `Tryte`
  is renamed `TritArray`. All public methods (`add_with_carry`,
  `add_saturating`, `to_width`, `set`, `__divmod__`, shifts, rotations,
  consensus, etc.) live on `TritArray` and are inherited by the three
  width-locked subclasses.

### Added
- `TritArray(value, width)` — arbitrary-width balanced ternary word (the
  generic base type).
- `Trybble(value)` — 3-trit field (T3), the smallest addressable grouping
  per the ISA.
- `Word(value)` — 27-trit word (T27), the basic memory and register unit
  per the ISA.
- Subclasses share `TritArray`'s implementation and preserve their concrete
  type through arithmetic via `type(self)._from_trits(...)` dispatch.
- `tests/test_tritarray.py` — generic-width regression suite migrated from
  the former `test_tryte.py`; `test_tryte.py` now exercises the 9-trit
  semantics (overflow at ±9841, fixed `len() == 9`, etc.).

### Changed
- All internal `TFloat` arithmetic (mantissa, regime, exponent, work-scale
  bounds, double-width products, division work widths) routes through
  `TritArray`. `TFloat._raw` is a `TritArray` of even width ≥ 8; the
  constructor accepts `float | int | TritArray` (any subclass instance
  whose width meets Tekum's even-and-≥-8 rule).
- `to_width(w)` on any subclass returns a `TritArray` (changing width
  exits the width-locked contract).
- `__init__.py` exports `TritArray`, `Trybble`, `Word` alongside `Tryte`.

## [1.3.0] — 2026-04-29

### Added
- Native trit-level division on `TFloat` (Tekum arithmetic)
  - Mantissa division at a working scale `p_work = max(p_self, p_other) + 2`
  - Numerator pre-shifted by `3^p_work` to recover the fractional quotient as an integer
  - Wheel-algebra special-value handling: `x/0 = ∞`, `0/0 = NaR`, `x/∞ = 0`, `∞/x = ∞`, `∞/∞ = NaR`
  - Result re-encoded by `_finalize`; no longer routes through Python `float`

### Fixed
- `Trits.__divmod__` and `Tryte.__divmod__` exponential drift on certain operand magnitudes.
  Initial `partial_rest = s[:len(d)-1]` could already exceed `|d|/2` when `|d|` sat at the
  lower end of its trit-length range, breaking the single-trit quotient invariant; the
  resulting remainder grew geometrically and the correction loop ran for billions of
  iterations. Both implementations now start with `partial_rest = []` and `pr = 0`,
  consuming every trit of the dividend and maintaining `|pr| ≤ |d|/2` at every step.
- `Tryte.__divmod__` silent overflow at width boundaries: the quotient-digit decision
  `V + V > abs_other` truncated when `2|V|` exceeded the Tryte range (e.g. width 26 with
  values near `3²⁶/2`). The decision now uses an `int` comparison, immune to truncation.

### Changed
- `TFloat._from_float` (renamed from `from_float`): privatized; bounded fraction
  quantification with `_find_regime` recomputed in-loop, plus a final clamp
- `_finalize` factored out of `__add__`, `__mul__`, and `__truediv__` for shared
  normalization and re-encoding
- `Trits.__divmod__` and `Tryte.__divmod__` now raise `TypeError` (not return
  `NotImplemented`) when the divisor is of the wrong type, matching `divmod` protocol
- `TFloat.__eq__` returns `NotImplemented` for cross-width comparisons rather than
  silently coercing
- `Tryte.to_tryte` (TFloat method): correct slicing for the `e == 0` and `e < 0`
  edge cases, plus explicit overflow guard when `e ≥ width`

## [1.2.3] — 2026-04-22
- added TFloat conversion from and into int/Tryte/Trits
- renamed to_tryte into to_raw

## [1.2.2] — 2026-04-05
- Updated README.md and pyproject.toml


## [1.2.1] — 2026-04-05
- Symmetric Euclidean `__divmod__` implementation


## [1.2.0] — 2026-04-05

### Added
- Native trit-level multiplication on `TFloat` (Tekum arithmetic)
  - Double-width Tryte arithmetic for the product
  - Exponent addition, scale reduction via ternary shift
  - Normalization into Tekum's [0.5, 1.5) range

## [1.1.0] — 2026-04-05

### Added
- Native trit-level addition on `TFloat` (Tekum arithmetic)
  - Direct manipulation of extended mantissas via `Tryte` operations
  - Exponent alignment via ternary shift
  - Normalization with Tekum's truncation-equals-rounding property
  - No longer relies on Python float for addition
- `_find_regime` and `_assemble_raw` internal helpers factored out of `from_float`

## [1.0.0] — 2026-04-04

### Changed
- API declared stable
- Version bumped to 1.0.0 — no breaking changes from 0.7.0

### Added
- `py.typed` marker for mypy support
- CHANGELOG.md
- 99% test coverage

## [0.7.0] — 2026-04-04

### Added
- `TFloat` — Tekum tapered precision floating-point type (arXiv:2512.10964)
  - Decode from `Tryte` and encode from Python `float`
  - Arithmetic via float conversion (`+`, `-`, `*`, `/`)
  - Negation, comparison, hashing
  - Special values: zero, infinity, NaR
  - Configurable width (even, ≥ 8)
- `pluralize` function and `PluralResult` dataclass for logical pluralism
- `logic_mode` context manager for runtime logic system selection
- Logic aliases: `K3`, `L3`, `HT`, `BI3`, `RM3`
- `Trit.imply` method dispatched via context manager
- `context.py` module with `ContextVar`-based logic dispatch
- Docstrings on all public classes and methods
- This CHANGELOG

### Changed
- `Trit.__and__`, `__or__`, `__invert__` now dispatch via active logic system (Kleene by default, fast path when no context manager is active)

## [0.2.0] — 2026-04-03

### Added
- `Tryte` — fixed-width ternary word type
  - Three addition modes: truncating, with carry, saturating
  - Shifts (`<<`, `>>`) and rotations (`rotate_left`, `rotate_right`)
  - Per-trit access (`__getitem__`) and immutable modification (`set`)
  - Sign extraction, absolute value
  - Consensus and anti-consensus (`cons`, `acons`)
  - Resize across widths (`to_width`)
  - Division (`__floordiv__`, `__mod__`, `__divmod__`)
- Five ternary logic systems with `TernaryLogic` abstract base class
  - Kleene (K3), Łukasiewicz (L3), Heyting (HT), Bochvar (BI3), R-mingle (RM3)
  - Each implements NOT, AND, OR, IMPLY, XOR, EQUIV
- `Trits` division via double trial quotient method
- Kleene logic operators on `Trit` (`&`, `|`, `~`)
- `Trit.cons` and `Trit.acons` operators

### Changed
- `Trits` internal storage changed to tuple (immutable)
- `Trits._from_trits` centralizes normalization and construction

## [0.1.0] — 2026-04-02

### Added
- `Trit` — immutable single balanced ternary digit
  - Construction from int with validation
  - Negation, multiplication
  - Half-adder and full-adder with ternary carry
  - Equality, hashing, comparison
  - Immutability via `__setattr__` guard
- `Trits` — arbitrary-precision balanced ternary integer
  - Construction from `int` or balanced ternary string
  - Addition, subtraction, multiplication
  - Conversion to/from Python `int`
  - Comparison operators
- Constants `P`, `Z`, `N`
- `pyproject.toml` with hatchling build system
- MIT license
- Initial README

[Unreleased]: https://codeberg.org/newick_2/tritlib/compare/v0.7.0...HEAD
[0.7.0]: https://codeberg.org/newick_2/tritlib/compare/v0.2.0...v0.7.0
[0.2.0]: https://codeberg.org/newick_2/tritlib/compare/v0.1.0...v0.2.0
[0.1.0]: https://codeberg.org/newick_2/tritlib/releases/tag/v0.1.0
