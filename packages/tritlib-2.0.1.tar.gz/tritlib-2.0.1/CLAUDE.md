# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Règle absolue

**Il t'est interdit de coder.** Tu ne dois jamais modifier la logique d'un fichier `.py` de ce dépôt. La seule modification autorisée dans un fichier `.py` est l'écriture ou la mise à jour de **docstrings**, et uniquement lorsque l'utilisateur le demande explicitement. Toute autre édition de code (ajout/suppression de fonctions, modification d'une expression, refactoring, correction de bug, etc.) est interdite, même si elle semble triviale ou évidente. Lecture, recherche, analyse et explication restent autorisées.

## Commands

Setup and test:
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
python -m pytest                          # full suite
python -m pytest tests/test_tfloat.py     # single file
python -m pytest tests/test_tfloat.py::test_name   # single test
python -m pytest --cov=tritlib            # with coverage
```

Build distribution: `python -m build` (hatchling backend, declared in `pyproject.toml`).

Python ≥ 3.11 required. No runtime dependencies — only `pytest` and `pytest-cov` for dev.

## Architecture

### Layering of the core types

`Trit` → `Trits` → `TritArray` → `TFloat`. Each layer is built on the one below and they must be edited consistent with that direction:

- **`Trit`** (`trit.py`) — single balanced ternary digit ∈ {N, Z, P}. Provides `half_add`/`full_add` returning `(sum, carry)` where carry is itself a Trit (ternary carry, not binary).
- **`Trits`** (`trits.py`) — arbitrary-precision balanced ternary integer, built as a tuple of `Trit` in **little-endian** order. Division uses the double trial quotient method; result follows symmetric Euclidean semantics (remainder may be negative).
- **`TritArray`** (`tritarray.py`) — fixed-width register-like word at arbitrary width. Three addition modes (`__add__` truncates, `add_with_carry` returns `(result, carry: Trit)`, `add_saturating` clamps). Operations construct via `type(self)._from_trits(trits, width)` (subclass-preserving dispatch) which truncates rather than raising — this is intentional hardware simulation behaviour.
- **`Trybble`** / **`Tryte`** / **`Word`** (`trybble.py`, `tryte.py`, `word.py`) — width-locked subclasses (3 / 9 / 27 trits) aligned with Setnex ISA v0.8. Each declares a `WIDTH` class attribute, an `__init__(self, value)` that forwards to `TritArray.__init__(value, WIDTH)`, and an override of `_from_trits` that ignores any `width` argument and forces `WIDTH`. Arithmetic between same-typed instances preserves the subtype via `type(self)._from_trits`. `to_width(w)` on a subclass returns a base `TritArray` (changing width exits the locked contract).
- **`TFloat`** (`tfloat.py`) — Tekum tapered precision float (arXiv:2512.10964). Stores raw as a `TritArray` (even width ≥ 8, not necessarily 9 or 27). Regime/exponent/fraction/sign are properties derived on demand. Arithmetic (`+`, `*`, `/`) is implemented natively at the trit level via `TritArray` operations (mantissa, double-width products, work-scale bounds), then re-encoded through `_finalize`.

All types are **immutable**: `__setattr__` raises, `__slots__` enforces fields, and every operation returns a new instance. Do not add mutators.

Internal storage is **little-endian** (least significant trit first), but string repr and constructor input strings are **big-endian** (`"+-0+"` reads MSB-to-LSB). Watch this direction reversal when editing.

### Logic-system dispatch

The five logic systems live in `src/tritlib/logic/`. Each subclasses `TernaryLogic` (in `base.py`) and only needs to override the operators where it diverges from defaults (most override only `imply_op`).

`Trit`'s `&`, `|`, `~`, and `imply` look up the active logic via a `ContextVar` (`_current_logic` in `context.py`). When unset, fast inlined Kleene paths are used (no dispatch overhead). The `logic_mode(system)` context manager swaps the active system for the duration of a `with` block. New logic systems should be added by subclassing `TernaryLogic` and exporting from `logic/__init__.py`.

`pluralize` (in `logic/plural.py`) evaluates a callable across all five systems and reports convergence/divergence — use it when reasoning about whether an expression is logic-system-sensitive.

### Tekum format invariants

When touching `TFloat`:
- Width must be **even and ≥ 8**. Constructors validate this.
- Three special values are stored as the raw `Tryte`: zero (all Z), infinity (all P), NaR (all N). The `_special` slot caches which one. Arithmetic on specials follows **wheel-algebra** semantics (e.g., `x/0 = ∞`, `0/0 = NaR`, `∞/∞ = NaR`) — see `__add__`, `__mul__`, `__truediv__` for the dispatch tables.
- Tekum's defining property: **truncation is rounding**. When reducing precision, slice the anchor; no carry propagation needed. The `_finalize` helper centralises this.
- Cross-width `==` returns `NotImplemented` (no silent coercion).
- `from_float` is the private `_from_float` since 1.3.0; external callers should use the `TFloat(value, width=…)` constructor.

### Division pitfalls (Trits / TritArray)

The 1.3.0 fix is load-bearing: `__divmod__` starts with `partial_rest = []` and `pr = 0`, then consumes every trit of the dividend while maintaining `|pr| ≤ |d|/2`. The previous shortcut of pre-loading `partial_rest = s[:len(d)-1]` could violate the invariant for divisors at the low end of their trit-length range and caused exponential drift. Do not "optimise" this back. The single-trit quotient decision must use a true `int` comparison (`V + V > abs_other`), not a `TritArray` comparison that could truncate.

## Conventions to follow

- Type-hinted, immutable, dunder-rich public API. Add `__hash__`, `__eq__`, and `@total_ordering` where comparable; raise `AttributeError` from `__setattr__`.
- Operators returning `NotImplemented` (not raising) for unsupported operand types — except `__divmod__`, which raises `TypeError` to match Python's `divmod` protocol.
- New public symbols must be re-exported from the appropriate `__init__.py` and added to `__all__`.
- Docstrings on public classes and methods; the project ships `py.typed` for downstream mypy users.
