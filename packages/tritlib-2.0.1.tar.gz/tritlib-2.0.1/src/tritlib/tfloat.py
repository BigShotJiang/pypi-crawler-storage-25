"""Tekum: balanced ternary tapered precision floating-point arithmetic.

Implements the Tekum format as defined by Laslo Hunhold
(arXiv:2512.10964). Tekum is a tapered precision number system for
balanced ternary logic, inspired by posit and takum formats.

Key properties:
- No sign trit: the sign is implicit in the balanced ternary mantissa.
- Tapered precision: the regime determines how many trits are allocated
  to the exponent vs. the fraction. Numbers near 1.0 have maximum
  precision; extreme values trade precision for dynamic range.
- Truncation is rounding: reducing precision is a simple truncation
  of the anchor, with no carry propagation needed.
- Three special values: zero (all Z), infinity (all P), NaR (all N).
- Width must be even and >= 8.

The value of a non-special tekum is:
    θ(t) = sign × (1 + fraction_value) × 3^exponent_value

where the exponent_value combines a regime-dependent bias with an
explicitly encoded exponent, and fraction_value ∈ (-0.5, 0.5).
"""

from __future__ import annotations
from functools import total_ordering
from math import floor, log, isnan, isinf
from typing import Optional
from tritlib import Z, N, P, TritArray, Trits, Trit

BIAS = [0, 1, 2, 4, 10, 28, 82, 244]
"""Exponent bias table indexed by |regime|.

For a given regime value r, the bias is sign(r) × BIAS[|r|].
The bias shifts the exponent window so that each regime covers
a distinct, non-overlapping range of exponent values.
"""


@total_ordering
class TFloat:
    """Balanced ternary tapered precision floating-point number (Tekum format).

    Stores the raw TritArray representation and derives all components
    (regime, exponent, fraction, sign) on demand via properties.
    Immutable: all operations return new instances.

    Can be constructed from a TritArray (decoding a register or memory word)
    or from a Python float/int (encoding into Tekum format).

    Args:
        v: A TritArray to decode, or a float/int to encode.
        width: Required when constructing from float/int. Must be even
            and >= 8.

    Raises:
        ValueError: If width is odd, < 8, or missing for float construction.
        TypeError: If v is neither TritArray nor float/int.

    Examples:
        >>> TFloat(TritArray(1640, 8))       # decode: θ = 1.0
        TFloat(1.0, width=8)
        >>> TFloat(3.14, width=20)       # encode
        TFloat(3.1399..., width=20)
        >>> float(TFloat(1.0, width=8))
        1.0
    """

    __slots__ = ("_raw", "_special")

    def __setattr__(self, name, value):
        raise AttributeError("TFloat is immutable")

    def __hash__(self):
        return hash(self._raw)

    def __init__(self, v: float | TritArray, width: Optional[int] = None):
        """Construct a TFloat by decoding a TritArray or encoding a Python number.

        Dispatches to ``_from_raw_tryte`` when ``v`` is a TritArray (the width
        is taken from the TritArray itself), or to ``_from_float`` when ``v``
        is an int or float (in which case ``width`` is required).

        Args:
            v: Either a TritArray to decode as a Tekum word, or a Python int
                or float to encode into Tekum format.
            width: Required when ``v`` is int or float. Must be even and
                >= 8. Ignored when ``v`` is a TritArray.

        Raises:
            ValueError: If ``v`` is int/float and ``width`` is missing,
                odd, or < 8.
            TypeError: If ``v`` is neither a TritArray nor a Python number.
        """
        if isinstance(v, TritArray):
            self._from_raw_tryte(v)
        elif isinstance(v, (int, float)):
            if width is None:
                raise ValueError("width required for float construction")
            self._from_float(v, width)
        else:
            raise TypeError

    # ── Construction ────────────────────────────────────────────────

    def _from_float(self, v: float, width: int):
        """Encode a Python float into Tekum format.

        Determines the optimal regime, exponent, and fraction to
        represent the value within the given width. The fraction
        is clamped to the representable range to handle floating-point
        rounding edge cases.

        Args:
            v: The float value to encode.
            width: Trit width, must be even and >= 8.

        Raises:
            ValueError: If width is odd or < 8.
        """
        if width < 8 or width % 2 != 0:
            raise ValueError("Length of TritArray must be even and >=8")
        if v == 0.0:
            object.__setattr__(self, "_raw", TritArray(0, width))
            object.__setattr__(self, "_special", "zero")
            return
        if isinf(v):
            object.__setattr__(self, "_raw", TritArray._from_trits([P] * width, width))
            object.__setattr__(self, "_special", "inf")
            return
        if isnan(v):
            object.__setattr__(self, "_raw", TritArray._from_trits([N] * width, width))
            object.__setattr__(self, "_special", "nar")
            return
        s = 1 if v > 0 else -1
        v_abs = abs(v)
        e = floor(log(v_abs) / log(3))

        for _ in range(4):
            r_signed, c, e_trits_val = self._find_regime(e)
            p = width - c - 3
            f = v_abs / 3**e - 1
            f_int = round(f * 3**p)
            max_f = (3**p - 1) // 2
            if -max_f <= f_int <= max_f:
                break
            if f_int > max_f:
                e += 1
                continue
            if f_int < -max_f:
                e -= 1
                continue
            break

        if e > 183:
            object.__setattr__(self, "_raw", TritArray._from_trits([P] * width, width))
            object.__setattr__(self, "_special", "inf")
            return
        if e < -183:
            object.__setattr__(self, "_raw", TritArray(0, width))
            object.__setattr__(self, "_special", "zero")
            return

        f_int = max(-max_f, min(max_f, f_int))
        fraction_trits = TritArray(f_int, p).trits
        anc = self._assemble_raw(
            sign=s,
            r_signed=r_signed,
            e_trits_val=e_trits_val,
            c=c,
            fraction_trits_le=fraction_trits,
            width=width,
        )
        object.__setattr__(self, "_raw", anc)
        object.__setattr__(self, "_special", None)

    @classmethod
    def _find_regime(cls, e_total) -> tuple[int, int, int]:
        """Resolve the regime, exponent trit count, and biased exponent.

        Walks the regime table and selects the smallest |r| ∈ {0,...,7}
        such that |e_total| fits within ``BIAS[|r|] + (3^c − 1) / 2``,
        where ``c = max(0, |r| − 2)`` is the number of exponent trits
        for that regime. The biased exponent
        ``e_trits_val = e_total − sign(r) · BIAS[|r|]`` is what gets
        encoded in the ``c`` exponent trits.

        Caller is responsible for clamping ``e_total`` to the
        representable range [−183, 183]; out of range values may
        produce ``e_trits_val`` outside the encodable interval and
        cause ``TritArray`` construction in ``_assemble_raw`` to overflow.
        ``_finalize`` performs this clamping.

        Args:
            e_total: The total integer exponent to encode.

        Returns:
            A tuple ``(r_signed, c, e_trits_val)``.
        """
        r_sign = 1 if e_total >= 0 else -1
        e_abs = abs(e_total)
        found_r = 0
        for r in range(8):
            c = max(0, r - 2)
            max_e = (3**c - 1) // 2 if c > 0 else 0
            if e_abs <= BIAS[r] + max_e:
                found_r = r
                break
        r_signed = r_sign * found_r
        c = max(0, found_r - 2)
        b = r_sign * BIAS[found_r]
        e_trits_val = e_total - b
        return (r_signed, c, e_trits_val)

    @classmethod
    def _assemble_raw(
        cls,
        sign: int,
        r_signed: int,
        e_trits_val: int,
        c: int,
        fraction_trits_le: tuple[Trit, ...],
        width: int,
    ):
        """Compose the raw Tekum word from its decoded components.

        Concatenates ``regime ⫲ exponent ⫲ fraction`` to form the
        anchor in big-endian order, adds the midpoint pattern
        ``+−+−...+−`` to recover the unsigned raw value, then negates
        entrywise if ``sign`` is negative.

        Args:
            sign: +1 or −1.
            r_signed: Regime value in {−7, ..., 7}.
            e_trits_val: Biased exponent value to be encoded in the
                ``c`` exponent trits. Must fit in [−(3^c − 1)/2,
                (3^c − 1)/2] or ``TritArray`` will raise OverflowError.
            c: Number of exponent trits (must equal max(0, |r| − 2)).
            fraction_trits_le: Fraction trits in little-endian order,
                length ``width − c − 3``.
            width: Total trit width of the resulting Tekum word.

        Returns:
            A ``TritArray`` of the requested width holding the raw Tekum
            encoding.
        """
        regime_trits = TritArray(r_signed, 3).trits
        exponent_trits = TritArray(e_trits_val, c).trits if c > 0 else ()
        le_raw = fraction_trits_le + exponent_trits + regime_trits
        be = list(reversed(le_raw))
        assert len(be) == width
        anc = TritArray.from_be_trits(be, width) + TritArray(
            "".join(["+-" for _ in range(width // 2)]), width
        )
        if sign < 0:
            anc = -anc
        return anc

    @classmethod
    def _finalize(
        cls, e_total: int, M_result: TritArray, work_scale: int, width: int
    ) -> TFloat:
        """Normalise a working mantissa and pack it into a Tekum word.

        Common back-end for ``__add__``, ``__mul__`` (and eventually
        ``__truediv__``). Takes a *signed* extended-width mantissa
        ``M_result`` whose value is interpreted as
        ``int(M_result) / 3^work_scale``, normalises it so the
        absolute value lies in [0.5, 1.5), adjusts ``e_total``
        accordingly, then encodes the result as a Tekum of the
        requested width.

        Sign is recovered from ``M_result.sign()`` after normalisation,
        not passed in: the caller is expected to embed the result
        sign by negating ``M_result`` before calling.

        Edge cases:
            - ``M_result == 0``: returns Tekum zero (e.g. exact
              cancellation in ``a + (−a)``).
            - ``e_total > 183``: saturates to Tekum infinity.
            - ``e_total < −183``: underflows to Tekum zero.

        Args:
            e_total: Pre-normalisation exponent (will shift by ±1
                for each normalisation step).
            M_result: Signed mantissa as a TritArray at scale
                ``work_scale``. Width must be wide enough to hold
                the un-normalised value plus guard trits.
            work_scale: The exponent of 3 by which ``int(M_result)``
                must be divided to recover the represented value.
            width: Trit width of the output TFloat.

        Returns:
            A new ``TFloat`` of the requested width.
        """
        if M_result == TritArray(0, M_result.width):
            return TFloat(0.0, width=width)
        low = TritArray((3**work_scale + 1) // 2, M_result.width)
        high = TritArray((3 ** (work_scale + 1) + 1) // 2, M_result.width)
        while abs(M_result) >= high:
            M_result >>= 1
            e_total += 1
        while abs(M_result) != TritArray(0, M_result.width) and abs(M_result) < low:
            M_result <<= 1
            e_total -= 1
        if e_total > 183:
            return TFloat(float("inf"), width=width)
        if e_total < -183:
            return TFloat(0.0, width=width)
        sign = 1 if M_result.sign() == P else -1
        M_abs = abs(M_result)
        be = list(reversed(M_abs.trits))
        (r_signed, c, e_trits_val) = TFloat._find_regime(e_total)
        p_final = width - c - 3

        leading_idx = 0
        for i, t in enumerate(be):
            if t != Z:
                leading_idx = i
                break

        # be[leading_idx] est le "1" de la mantisse
        # be[leading_idx+1:] sont les trits de fraction
        fraction_be = be[leading_idx + 1 : leading_idx + 1 + p_final]
        if len(fraction_be) < p_final:
            fraction_be = fraction_be + [Z] * (p_final - len(fraction_be))
        fraction_trits_le = tuple(reversed(fraction_be))
        anc = cls._assemble_raw(
            sign=sign,
            r_signed=r_signed,
            c=c,
            e_trits_val=e_trits_val,
            fraction_trits_le=fraction_trits_le,
            width=width,
        )
        # Assemble the anchor in little-endian order
        obj = TFloat.__new__(TFloat)
        object.__setattr__(obj, "_raw", anc)
        object.__setattr__(obj, "_special", None)
        return obj

    @classmethod
    def from_int(cls, value: int | Trits | TritArray, width: Optional[int] = None):
        """Encode a balanced ternary integer into Tekum format.

        Accepts a Python int, a ``Trits``, or a ``TritArray``. The integer
        is decomposed as ``sign × (1 + f) × 3^e`` with ``e = len − 1``
        in the magnitude's big-endian representation. The fraction
        trits below the leading "1" are taken straight from the
        integer's trit pattern; if the integer has more trits than
        the target Tekum's fraction width, the low-order trits are
        truncated (Tekum's truncation-equals-rounding property keeps
        this exact in the balanced ternary sense).

        Args:
            value: A Python int, a ``Trits``, or a ``TritArray``. When a
                ``TritArray`` is given, ``width`` is overridden by the
                TritArray's own width.
            width: Required when ``value`` is int or Trits. Must be
                even and >= 8.

        Returns:
            A new ``TFloat``. Returns Tekum zero for ``value == 0``.

        Raises:
            ValueError: If ``width`` is missing, odd, or < 8.
        """
        if (not isinstance(value, TritArray)) and (width is None):
            raise ValueError("width required for Trits construction")
        if isinstance(value, int):
            value = Trits(value)
        elif isinstance(value, TritArray):
            width = value.width
            value = value.to_trits()
        if value == Trits(0):
            return TFloat(0.0, width=width)
        assert width is not None
        if width % 2 != 0:
            raise ValueError("width must be even")
        if width < 8:
            raise ValueError("width must be >= 8")
        sign = int(value._be_trits[0])
        abs_value = abs(value)
        e = len(value) - 1
        fraction_be = abs_value._be_trits[1:]
        r_signed, c, e_trits_val = TFloat._find_regime(e)
        p_final = width - c - 3
        if len(fraction_be) > p_final:
            fraction_be = fraction_be[:p_final]
        else:
            fraction_be = fraction_be + [Z] * (p_final - len(fraction_be))
        anc = TFloat._assemble_raw(
            sign=sign,
            r_signed=r_signed,
            e_trits_val=e_trits_val,
            c=c,
            fraction_trits_le=tuple(reversed(fraction_be)),
            width=width,
        )
        obj = cls.__new__(cls)
        object.__setattr__(obj, "_raw", anc)
        object.__setattr__(obj, "_special", None)
        return obj

    def __int__(self) -> int:
        """Convert to Python int by truncation toward zero.

        Equivalent to ``int(self.to_trits())``. See ``to_trits`` for
        the behaviour on special values.
        """
        return int(self.to_trits())

    def to_trits(self) -> Trits:
        """Convert to a balanced ternary integer (truncation toward zero).

        For normal values, decodes ``(1 + f) · 3^e`` and truncates
        any sub-unit fractional part. ``e < 0`` yields ``Trits(0)``
        because the magnitude is below 1.

        Special values:
            - zero → ``Trits(0)``
            - inf → raises ``OverflowError``
            - NaR → raises ``ValueError``

        Returns:
            A new ``Trits`` carrying the truncated integer value
            with its original sign.
        """
        if self._special is not None:
            match self._special:
                case "zero":
                    return Trits(0)
                case "nar":
                    raise ValueError
                case "inf":
                    raise OverflowError
        e = self.exponent_value
        if e < 0:
            return Trits(0)
        if len(self.fraction) >= e:
            result = Trits.from_be_trits([P] + self.fraction[:e])
        else:
            result = Trits.from_be_trits(
                [P] + self.fraction + [Z] * (e - len(self.fraction))
            )
        if self.sign == N:
            return -result
        return result

    def to_tryte(self, width) -> TritArray:
        """Convert to a fixed-width balanced ternary integer (truncation toward zero).

        Decodes ``(1 + f) · 3^e`` and packs it into a ``TritArray`` of the
        given width. Trits of the source fraction that fall below
        position 0 (i.e. for ``e < p``) are truncated.

        Special values:
            - zero → ``TritArray(0, width)``
            - inf → raises ``OverflowError``
            - NaR → raises ``ValueError``

        Args:
            width: Width of the target ``TritArray``.

        Returns:
            A new ``TritArray`` of the requested width holding the
            truncated integer value with its original sign.

        Raises:
            OverflowError: If the leading "1" of the mantissa
                does not fit in ``width`` trits (i.e. ``e >= width``),
                or if the value is infinity.
            ValueError: If the value is NaR.
        """
        if self._special is not None:
            match self._special:
                case "zero":
                    return TritArray(0, width)
                case "nar":
                    raise ValueError
                case "inf":
                    raise OverflowError
        p = self.fraction_trit_count
        e = self.exponent_value
        if e >= width:
            raise OverflowError
        if e < 0:
            return TritArray(0, width)
        n = min(e, p)
        trits_le = [Z] * max(0, e - p) + self.fraction[:n][::-1] + [P]
        result = TritArray._from_trits(trits_le, width)
        if self.sign == N:
            return -result
        return result

    def _from_raw_tryte(self, t: TritArray):
        """Decode a TritArray as a Tekum floating-point value.

        Interprets the raw trit pattern according to the Tekum format:
        detects special values (zero, infinity, NaR) and stores the
        raw TritArray for on-demand decoding of regime, exponent, and
        fraction via properties.

        Args:
            t: The TritArray to interpret as a Tekum number.

        Raises:
            ValueError: If the TritArray width is odd or < 8.
        """
        if t.width < 8 or t.width % 2 != 0:
            raise ValueError("Length of TritArray must be even and >=8")
        if len(set(t._trits)) == 1:
            object.__setattr__(self, "_raw", t)
            if t._trits[0] == Z:
                object.__setattr__(self, "_special", "zero")
            elif t._trits[0] == N:
                object.__setattr__(self, "_special", "nar")
            else:
                object.__setattr__(self, "_special", "inf")
            return
        object.__setattr__(self, "_special", None)
        object.__setattr__(self, "_raw", t)

    def to_raw(self) -> TritArray:
        """Return the underlying raw TritArray representation."""
        return self._raw

    # ── Core properties ─────────────────────────────────────────────

    @property
    def special(self) -> str | None:
        """The special value kind, or None for normal numbers.

        Returns 'zero', 'inf', 'nar', or None.
        """
        return self._special

    @property
    def width(self) -> int:
        """The trit width of this Tekum number."""
        return len(self._raw)

    @property
    def sign(self) -> Trit:
        """The sign of this value as a Trit (P, Z, or N)."""
        return self._raw.sign()

    # ── Anchor and decoding ─────────────────────────────────────────

    @property
    def anchor(self) -> TritArray:
        """The anchor: anc(t) = |t| - +-+-...+-

        The anchor is the central decoding tool of the Tekum format.
        It normalizes the raw TritArray by taking its absolute value and
        subtracting the midpoint pattern +-+-..., yielding a
        representation where regime, exponent, and fraction can be
        read directly.
        """
        return abs(self._raw) - TritArray(
            "".join(["+-" for _ in range(self.width // 2)]), self.width
        )

    @property
    def _be_anchor(self) -> list[Trit]:
        """The anchor trits in big-endian order (most significant first)."""
        return list(reversed(self.anchor.trits))

    @property
    def regime(self) -> int:
        """The regime value r ∈ {-7, ..., 7}.

        Extracted from the three most significant trits of the anchor.
        Determines the number of exponent trits and the exponent bias.
        """
        if self._special is not None:
            return 0
        return int(Trits.from_be_trits(self._be_anchor[0:3]))

    @property
    def _c(self) -> int:
        """The exponent trit count: c = max(0, |r| - 2)."""
        return max(0, abs(self.regime) - 2)

    @property
    def exponent_trit_count(self) -> int:
        """The number of trits allocated to the exponent."""
        return self._c

    @property
    def fraction_trit_count(self) -> int:
        """The number of trits allocated to the fraction."""
        return self.width - self._c - 3

    @property
    def exponent(self) -> list[Trit]:
        """The raw exponent trits (big-endian), empty if c = 0."""
        if self._special is not None:
            return [Z]
        if self._c == 0:
            return []
        return self._be_anchor[3 : 3 + self._c]

    @property
    def exponent_value(self) -> int:
        """The total exponent value e = int(exponent_trits) + bias.

        Combines the regime-dependent bias with the value encoded
        in the exponent trits. When there are no exponent trits
        (c = 0), returns the bias alone.
        """
        if self._special is not None:
            return 0
        r = self.regime
        b = 0 if r == 0 else (abs(r) // r) * BIAS[abs(r)]
        if self._c == 0:
            return b
        return int(Trits.from_be_trits(self.exponent)) + b

    @property
    def fraction(self) -> list[Trit]:
        """The raw fraction trits (big-endian)."""
        if self._special is not None:
            return [Z]
        return self._be_anchor[3 + self._c :]

    @property
    def fraction_value(self) -> float:
        """The fraction value f ∈ (-0.5, 0.5).

        Computed as the sum of each fraction trit weighted by
        decreasing powers of 3: f = Σ trit_i × 3^(-i).
        """
        if self._special is not None:
            return 0
        f = sum(trit.value * 3.0 ** (-(i + 1)) for i, trit in enumerate(self.fraction))
        return f

    # ── Conversion ──────────────────────────────────────────────────

    def __float__(self) -> float:
        """Convert to Python float: θ = sign × (1 + f) × 3^e.

        Returns 0.0 for zero, float('inf') for infinity,
        and float('nan') for NaR.
        """
        if self._special is not None:
            if self._special == "zero":
                return 0.0
            elif self._special == "inf":
                return float("inf")
            elif self._special == "nar":
                return float("nan")
        e = self.exponent_value
        return int(self.sign) * (1 + self.fraction_value) * 3.0**e

    def __repr__(self):
        if self._special == "nar":
            return "TFloat(NaR)"
        if self._special == "inf":
            return "TFloat(∞)"
        if self._special == "zero":
            return "TFloat(0)"
        return f"TFloat({float(self)}, width={self.width})"

    def __str__(self):
        """Human-readable string of the float value."""
        if self._special == "nar":
            return "NaR"
        if self._special == "inf":
            return "∞"
        return str(float(self))

    # ── Comparison ──────────────────────────────────────────────────

    def __eq__(self, other) -> bool:
        """Equality by raw TritArray comparison."""
        if not isinstance(other, TFloat):
            return NotImplemented
        if self.width != other.width:
            return NotImplemented
        return self._raw == other._raw

    def __lt__(self, other) -> bool:
        """Less-than by raw TritArray integer comparison.

        Tekum monotonicity (Proposition 4) guarantees that integer
        ordering on the raw TritArray corresponds to numerical ordering
        of the represented values.
        """
        if not isinstance(other, TFloat):
            raise TypeError
        if self.width != other.width:
            return NotImplemented
        return self._raw < other._raw

    def __neg__(self) -> TFloat:
        """Negate by inverting all trits of the raw TritArray.

        Proposition 3 of the Tekum paper guarantees θ(-t) = -θ(t).
        """
        return TFloat(-self._raw)

    # ── Native Arithmetic ────────────────────────────────────────────
    #
    # Native arithmetic operations preserving the exact Tekum rounding
    # behaviour.

    def __sub__(self, other) -> TFloat:
        """Subtraction via negation and addition.

        Raises:
            TypeError: If widths differ.
        """
        if not isinstance(other, TFloat):
            raise TypeError
        if self.width != other.width:
            return NotImplemented
        return self + (-other)

    def __truediv__(self, other) -> TFloat:
        if not isinstance(other, TFloat):
            raise TypeError
        if self.width != other.width:
            return NotImplemented
        if self._special == "nar" or other._special == "nar":
            return TFloat(float("nan"), width=self.width)
        if other._special == "zero":
            if self._special == "zero":
                return TFloat(float("nan"), width=self.width)
            return TFloat(float("inf"), width=self.width)
        if self._special == "zero":
            return TFloat(0.0, width=self.width)
        if other._special == "inf":
            if self._special == "inf":
                return TFloat(float("nan"), width=self.width)
            else:
                return TFloat(0.0, self.width)
        if self._special == "inf":
            return TFloat(float("inf"), self.width)

        e1 = self.exponent_value
        e2 = other.exponent_value
        p_self = self.fraction_trit_count
        p_other = other.fraction_trit_count
        f1_int = int(Trits.from_be_trits(self.fraction)) if self.fraction else 0
        f2_int = int(Trits.from_be_trits(other.fraction)) if other.fraction else 0
        e_total = e1 - e2  # compare to __mul__ which adds e1 and e2

        work_scale = max(p_self, p_other) + 2
        M1_int = (3**p_self + f1_int) * 3 ** (work_scale - p_self)
        M2_int = (3**p_other + f2_int) * 3 ** (work_scale - p_other)
        if self.sign == N:
            M1_int = -M1_int
        if other.sign == N:
            M2_int = -M2_int
        numerator_int = M1_int * 3**work_scale
        div_width = 2 * work_scale + 4

        numerator = TritArray(numerator_int, div_width)
        divisor = TritArray(M2_int, div_width)
        Q, _ = divmod(numerator, divisor)
        return self._finalize(
            e_total=e_total, M_result=Q, work_scale=work_scale, width=self.width
        )

    def __add__(self, other) -> TFloat:
        """Add two TFloats using native trit-level Tekum arithmetic.

        Both operands are decoded into signed integer mantissas at a
        common working scale ``p_work = max(p_self, p_other) + 2``
        (with two guard trits). The smaller-exponent operand's
        mantissa is shifted right by the exponent difference, then
        the two are summed as TritArray. The result is normalised and
        re-encoded by ``_finalize``.

        Special-value handling:
            - any operand is NaR → NaR
            - any operand is inf → inf (Tekum has a single ∞)
            - any operand is zero → returns the other operand

        Args:
            other: Another TFloat of the same width.

        Returns:
            A new TFloat of the common width.

        Raises:
            TypeError: If ``other`` is not a TFloat.
            NotImplemented: If widths differ.
        """
        if not isinstance(other, TFloat):
            raise TypeError
        if self.width != other.width:
            return NotImplemented

        if (self._special is not None) or (other._special is not None):
            if self._special == "nar" or other._special == "nar":
                return TFloat(float("nan"), self.width)
            if self._special == "inf" or other._special == "inf":
                return TFloat(float("inf"), self.width)
            if self._special == "zero":
                return other
            if other._special == "zero":
                return self
        e1 = self.exponent_value
        e2 = other.exponent_value
        e_total = max(e1, e2)
        # Récupérer les fractions comme int signés
        p_self = self.fraction_trit_count
        p_other = other.fraction_trit_count
        f1_int = int(Trits.from_be_trits(self.fraction)) if self.fraction else 0
        f2_int = int(Trits.from_be_trits(other.fraction)) if other.fraction else 0

        # Mantisses entières normalisées à la même échelle
        p_work = max(p_self, p_other) + 2  # avec garde
        M1_int = (3**p_self + f1_int) * 3 ** (p_work - p_self)
        M2_int = (3**p_other + f2_int) * 3 ** (p_work - p_other)

        # Signes
        if self.sign == N:
            M1_int = -M1_int
        if other.sign == N:
            M2_int = -M2_int

        # Créer les TritArray
        work_width = p_work + 3
        M1 = TritArray(M1_int, work_width)
        M2 = TritArray(M2_int, work_width)
        diff = abs(e1 - e2)
        if e1 > e2:
            M2 = M2 >> diff
        else:
            M1 = M1 >> diff
        M_result = M1 + M2
        return self._finalize(
            M_result=M_result, work_scale=p_work, width=self.width, e_total=e_total
        )

    def __mul__(self, other) -> TFloat:
        """Multiply two TFloats using native trit-level Tekum arithmetic.

        Both operands are decoded into signed integer mantissas at a
        common working scale ``work_scale = max(p_self, p_other) + 2``,
        then multiplied at double width to avoid overflow. The
        product is right-shifted by ``work_scale`` to bring it back
        to single scale, then ``_finalize`` normalises and re-encodes
        with ``e_total = e_self + e_other``.

        Special-value handling:
            - any operand is NaR → NaR
            - 0 × ∞ or ∞ × 0 → NaR
            - any operand is zero → zero
            - any operand is inf → inf

        Args:
            other: Another TFloat of the same width.

        Returns:
            A new TFloat of the common width.

        Raises:
            TypeError: If ``other`` is not a TFloat.
            NotImplemented: If widths differ.
        """
        if not isinstance(other, TFloat):
            raise TypeError
        if self.width != other.width:
            return NotImplemented

        if (self._special is not None) or (other._special is not None):
            if self._special == "nar" or other._special == "nar":
                return TFloat(float("nan"), self.width)

            if self._special == "zero":
                if other._special == "inf":
                    return TFloat(float("nan"), self.width)
                else:
                    return TFloat(0.0, self.width)
            if other._special == "zero":
                if self._special == "inf":
                    return TFloat(float("nan"), self.width)
                else:
                    return TFloat(0.0, self.width)

            if other._special == "inf" or self._special == "inf":
                return TFloat(float("inf"), self.width)

        e1 = self.exponent_value
        e2 = other.exponent_value
        e_total = e1 + e2
        # Récupérer les fractions comme int signés
        p_self = self.fraction_trit_count
        p_other = other.fraction_trit_count

        # Construire les mantisses entières signées à échelle commune
        work_scale = max(p_self, p_other) + 2  # échelle avec garde
        work_width = work_scale + 3
        # f1 comme entier signé
        f1_int = int(Trits.from_be_trits(self.fraction)) if self.fraction else 0
        f2_int = int(Trits.from_be_trits(other.fraction)) if other.fraction else 0

        # Mantisses (1+f) × 3^work_scale comme entiers
        M1_int = (3**p_self + f1_int) * 3 ** (work_scale - p_self)
        M2_int = (3**p_other + f2_int) * 3 ** (work_scale - p_other)
        if self.sign == N:
            M1_int = -M1_int
        if other.sign == N:
            M2_int = -M2_int
        # Créer les TritArray
        double_width = work_width * 2
        M1 = TritArray(M1_int, double_width)
        M2 = TritArray(M2_int, double_width)
        M_result = M1 * M2
        M_result = M_result >> work_scale
        return self._finalize(
            e_total=e_total, M_result=M_result, work_scale=work_scale, width=self.width
        )
