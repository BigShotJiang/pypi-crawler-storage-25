from .tritarray import TritArray


class Trybble(TritArray):
    WIDTH = 3

    def __init__(self, value):
        super().__init__(value, self.WIDTH)

    @classmethod
    def _from_trits(cls, trits, width=None):
        return super()._from_trits(trits, cls.WIDTH)
