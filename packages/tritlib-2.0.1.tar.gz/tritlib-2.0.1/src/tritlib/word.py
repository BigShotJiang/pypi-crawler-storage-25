"""27-trit machine word type, wrapping tritlib.Tryte.

All arithmetic operations automatically wrap results as Word, ensuring
consistent types through the execution pipeline. Provides access to
tritlib's Tryte operations (arithmetic, shifts, consensus) plus
conversions to/from ternary floating-point.
"""

from __future__ import annotations
from .tritarray import TritArray
from .tfloat import TFloat


class Word(TritArray):
    WIDTH = 27

    def __init__(self, value):
        super().__init__(value, self.WIDTH)

    @classmethod
    def _from_trits(cls, trits, width=None):
        return super()._from_trits(trits, cls.WIDTH)

    @classmethod
    def from_tfloat(cls, tf: TFloat) -> Word:
        """Convert 26-trit ternary float to 27-trit Word.

        Args:
            tf: TFloat from tritlib (26 trits internally).

        Returns:
            Word with sign-extended representation.
        """
        return Word(tf._raw.to_width(27))

    def to_tfloat(self) -> TFloat:
        """Convert 27-trit Word to 26-trit ternary float.

        Args:
            None (instance method).

        Returns:
            TFloat (from tritlib) suitable for floating-point ALU ops.
        """
        return TFloat(super().to_width(26))

    def to_bytes(self) -> bytes:
        return int(self).to_bytes(6, signed=True)


# Class constants
Word.ZERO = Word(0)
"""Zero (all trits are Z)."""
Word.ONE = Word(1)
"""One."""
Word.MAX = Word("".join(["+"] * 27))
"""Maximum value (all trits are P, i.e., +1 in each position)."""
Word.MIN = Word("".join(["-"] * 27))
"""Minimum value (all trits are N, i.e., −1 in each position)."""
