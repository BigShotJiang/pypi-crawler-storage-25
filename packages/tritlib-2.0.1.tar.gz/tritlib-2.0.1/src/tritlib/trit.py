from __future__ import annotations
from functools import total_ordering
from tritlib.context import _current_logic


@total_ordering
class Trit:
    """A single balanced ternary digit (trit).

    Represents one of three values: -1 (N), 0 (Z), or +1 (P).
    Immutable and hashable, usable as dict keys and in sets.

    Supports arithmetic (negation, multiplication, half/full addition),
    Kleene (K3) logic via bitwise operators (&, |, ~), and
    trit-level consensus/anti-consensus operations.

    Args:
        value: An integer, must be -1, 0, or 1.

    Raises:
        ValueError: If value is not in {-1, 0, 1}.

    Examples:
        >>> Trit(1)
        Trit(1)
        >>> str(Trit(1))
        '+'
        >>> -Trit(1)
        Trit(-1)
        >>> Trit(1) & Trit(0)
        Trit(0)
    """

    __slots__ = ("_value",)

    def __init__(self, value: int):
        if value not in (-1, 0, 1) or not isinstance(value, int):
            raise ValueError
        object.__setattr__(self, "_value", value)

    def __repr__(self) -> str:
        return f"Trit({self._value})"

    def __str__(self) -> str:
        """Return the symbolic representation: '+', '0', or '-'."""
        if self._value > 0:
            return "+"
        elif self._value == 0:
            return "0"
        else:
            return "-"

    def __int__(self) -> int:
        return self._value

    def __eq__(self, other) -> bool:
        if not isinstance(other, Trit):
            return NotImplemented
        return self.value == other.value

    def __hash__(self) -> int:
        return hash(self._value)

    def __setattr__(self, name, value):
        raise AttributeError("Trit is immutable")

    @property
    def value(self) -> int:
        """The underlying integer value (-1, 0, or 1)."""
        return self._value

    # ── Arithmetic ──────────────────────────────────────────────────

    def __neg__(self) -> Trit:
        """Negate the trit: P becomes N, N becomes P, Z stays Z.

        In balanced ternary, negating every trit of a number
        negates the number — no carry propagation needed.
        """
        return Trit(-self._value)

    def __mul__(self, other) -> Trit:
        """Trit multiplication. The product of two trits always
        stays within {-1, 0, 1}, so no overflow is possible.

        Truth table:
            P * P = P,  P * N = N,  P * Z = Z
            N * P = N,  N * N = P,  N * Z = Z
            Z * anything = Z
        """
        if not isinstance(other, Trit):
            return NotImplemented
        return Trit(self.value * other.value)

    def half_add(self, other) -> tuple[Trit, Trit]:
        """Add two trits, returning (sum, carry).

        When both trits are equal and non-zero, the sum wraps and
        produces a carry. Otherwise the sum fits in one trit.

        Returns:
            A tuple (sum, carry) of two Trit values.

        Examples:
            >>> P.half_add(P)
            (Trit(-1), Trit(1))    # 1+1 = 2 = 3-1, sum=N carry=P
            >>> P.half_add(N)
            (Trit(0), Trit(0))     # 1+(-1) = 0, no carry
        """
        if not isinstance(other, Trit):
            return NotImplemented
        if self.value == other.value:
            s = -self
            c = self
        else:
            s = Trit(self.value + other.value)
            c = Z
        return (s, c)

    def full_add(self, other: Trit, carry: Trit) -> tuple[Trit, Trit]:
        """Add two trits plus a carry-in trit, returning (sum, carry).

        Chains two half_add operations. The two intermediate carries
        cannot both be non-zero simultaneously, so their sum is
        always a valid trit.

        Args:
            other: The second trit operand.
            carry: The carry-in trit from a previous addition.

        Returns:
            A tuple (sum, carry_out) of two Trit values.
        """
        if not isinstance(other, Trit) or not isinstance(carry, Trit):
            return NotImplemented
        s1, c1 = self.half_add(other)
        s2, c2 = s1.half_add(carry)
        return s2, Trit(c1.value + c2.value)

    # ── Kleene (K3) logic ───────────────────────────────────────────
    #
    # The bitwise operators implement Kleene's strong three-valued
    # logic, where P=true, N=false, Z=unknown. This is the default
    # logic system; other systems (Łukasiewicz, Heyting, BI3, RM3)
    # are available via the tritlib.logic module.

    def __invert__(self) -> Trit:
        """Kleene NOT (identical to arithmetic negation).

        ~P = N, ~Z = Z, ~N = P.
        """
        logic = _current_logic.get()
        if logic is None:
            return self.__neg__()
        return logic.not_op(self)

    def __and__(self, other: Trit | None) -> Trit:
        """Kleene AND: returns the minimum of two trits.

        P & P = P,  P & Z = Z,  P & N = N
        Z & Z = Z,  Z & N = N
        N & anything = N
        """
        if not isinstance(other, Trit):
            return NotImplemented
        logic = _current_logic.get()
        if logic is None:
            return Trit(min(self._value, other._value))
        return logic.and_op(self, other)

    def __or__(self, other) -> Trit:
        """Kleene OR: returns the maximum of two trits.

        N | N = N,  N | Z = Z,  N | P = P
        Z | Z = Z,  Z | P = P
        P | anything = P
        """
        if not isinstance(other, Trit):
            return NotImplemented
        logic = _current_logic.get()
        if logic is None:
            return Trit(max(self._value, other._value))
        return logic.or_op(self, other)

    def imply(self, other: Trit) -> Trit:
        if not isinstance(other, Trit):
            return NotImplemented
        logic = _current_logic.get()
        if logic is None:
            return -self | other
        return logic.imply_op(self, other)

    # ── Comparison ──────────────────────────────────────────────────

    def __lt__(self, other) -> bool:
        """Ordering on trit values: N < Z < P."""
        if not isinstance(other, Trit):
            return NotImplemented
        return self.value < other.value

    # ── Trit-level operations ───────────────────────────────────────

    def cons(self, other) -> Trit:
        """Consensus: returns the agreed value, or Z if they disagree.

        If both trits are equal, returns that value. Otherwise
        returns Z. Useful for detecting agreement in ternary
        circuits (CONS instruction).

        Examples:
            P.cons(P) = P,  N.cons(N) = N,  Z.cons(Z) = Z
            P.cons(N) = Z,  P.cons(Z) = Z
        """
        if not isinstance(other, Trit):
            return NotImplemented
        return self if self == other else Z

    def acons(self, other) -> Trit:
        """Anti-consensus: extracts the point of disagreement.

        Returns Z if both trits agree or are opposites.
        Otherwise returns the negation of the non-zero trit.
        Complement of consensus (ACONS instruction).

        Examples:
            P.acons(Z) = N,  N.acons(Z) = P
            Z.acons(P) = N,  Z.acons(N) = P
            P.acons(P) = Z,  P.acons(N) = Z
        """
        if not isinstance(other, Trit):
            return NotImplemented
        if self == other or self == -other:
            return Z
        if self == Z:
            return -other
        return -self


N = Trit(-1)
"""Constant: the negative trit (-1)."""

Z = Trit(0)
"""Constant: the zero trit (0)."""

P = Trit(1)
"""Constant: the positive trit (+1)."""
