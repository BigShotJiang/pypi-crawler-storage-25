from __future__ import annotations
from functools import total_ordering
from tritlib.trits import Trits
from tritlib.trit import Z, N, P, Trit


@total_ordering
class TritArray:
    """Fixed-width balanced ternary array.

    A Tritarray represents a balanced ternary integer of fixed width, analogous
    to a fixed-size register in a ternary processor. Trits are stored
    internally in little-endian order (least significant trit first).

    TritArray is immutable: all operations return new instances.

    Construction raises OverflowError if the value does not fit in the
    given width. Arithmetic operations silently truncate (wrap around)
    to simulate hardware behaviour. Use add_with_carry() to detect
    overflow, or add_saturating() to clamp to bounds.

    Args:
        value: An integer or balanced ternary string (e.g. "+-0").
        width: Number of trits. Determines the range
            [-(3^width - 1) / 2, (3^width - 1) / 2].

    Examples:
        >>> t = TritArray(42, 6)
        >>> int(t)
        42
        >>> len(t)
        6
        >>> TritArray("+-0+", 6)
        TritArray(8, 6)
    """

    __slots__ = ("_trits", "_width")

    def __hash__(self) -> int:
        return hash(self._trits)

    def __setattr__(self, name, value):
        raise AttributeError("Trits is immutable")

    def __init__(self, value: str | int | TritArray | bytes, width: int):
        if isinstance(value, TritArray):
            value = int(value)
        elif isinstance(value, bytes):
            value = int.from_bytes(value, signed=True)
        trits = Trits(value)
        if len(trits) > width:
            raise OverflowError
        else:
            _trits = list(trits.trits) + [Z] * (width - len(trits.trits))
        object.__setattr__(self, "_trits", tuple(_trits))
        object.__setattr__(self, "_width", width)

    @classmethod
    def _from_trits(cls, trits: list[Trit] | tuple[Trit, ...], width: int) -> TritArray:
        """Internal constructor from a list of trits (little-endian).

        Does not raise OverflowError; truncates to width to simulate
        hardware behaviour. Used by arithmetic operators.
        """
        if isinstance(trits, tuple):
            trits = list(trits)
        trits = trits + [Z] * (width - len(trits))
        obj = cls.__new__(cls)
        object.__setattr__(obj, "_trits", tuple(trits[:width]))
        object.__setattr__(obj, "_width", width)
        return obj

    @property
    def width(self) -> int:
        """The fixed width (number of trits) of this TritArray."""
        return self._width

    def __int__(self) -> int:
        """Convert to Python int using Horner's method."""
        acc = 0
        for trit in reversed(self._trits):
            acc = acc * 3 + trit.value
        return acc

    @property
    def trits(self) -> tuple[Trit]:
        """The underlying trits as a tuple (little-endian)."""
        return self._trits

    def to_trits(self) -> Trits:
        """Convert to a variable-length Trits, stripping leading zeros."""
        s = list(self._trits)
        while s[-1] == Z and len(s) > 1:
            s = s[:-1]
        return Trits._from_trits(s)

    @property
    def _be_trits(self) -> list[Trit]:
        """Internal: trits in big-endian order, leading zeros stripped."""
        s = list(self.trits)
        r: list[Trit] = []
        while len(s) > 0:
            a = s.pop()
            if len(r) == 0 and a == Z:
                continue
            r.append(a)
        return [Z] if len(r) == 0 else r

    @classmethod
    def from_be_trits(cls, trits: list[Trit], width: int) -> TritArray:
        """Construct a TritArray from big-endian trits.

        Args:
            trits: List of Trit, most significant first.
            width: Target width.

        Returns:
            A new TritArray with the given width.
        """
        return cls._from_trits(list(reversed(trits)), width)

    def to_width(self, width) -> TritArray:
        """Return a new TritArray resized to the given width.

        Pads with Z if wider, truncates if narrower (no OverflowError).

        Args:
            width: Target width in trits.

        Returns:
            A new TritArray of the requested width.
        """
        return TritArray._from_trits(list(self._trits), width)

    def __len__(self) -> int:
        """Return the width (number of trits)."""
        return len(self._trits)

    def __getitem__(self, key):
        """Access individual trits or slices.

        Args:
            key: An int index returns a single Trit.
                A slice returns a Trits of the selected range.

        Raises:
            TypeError: If key is neither int nor slice.
        """
        if isinstance(key, int):
            return self._trits[key]
        elif isinstance(key, slice):
            return Trits._from_trits(list(self._trits[key]))
        else:
            raise TypeError

    def set(self, key: int, v: Trit) -> TritArray:
        """Return a new TritArray with the trit at position key replaced by v.

        Args:
            key: Trit index (0 = least significant).
            v: The Trit value to set.

        Returns:
            A new TritArray with the modification applied.

        Raises:
            ValueError: If key is out of range.
        """
        if key >= self.width or key < 0:
            raise ValueError
        trits = list(self.trits)
        trits[key] = v
        return type(self)._from_trits(trits, self.width)

    def __eq__(self, other) -> bool:
        """Equality comparison. Raises ValueError if widths differ."""
        if len(self) != len(other):
            raise ValueError
        return self.trits == other.trits

    def __lt__(self, other) -> bool:
        """Less-than comparison, trit-by-trit from most significant.

        Raises ValueError if widths differ.
        """
        if len(self) != len(other):
            raise ValueError
        for t1, t2 in zip(reversed(self.trits), reversed(other.trits)):
            if t1 < t2:
                return True
            elif t1 > t2:
                return False
        return False

    def __abs__(self) -> TritArray:
        """Return the absolute value as a new TritArray."""
        if self._be_trits[0] == N:
            return -self
        return self

    def __repr__(self) -> str:
        return f"TritArray({int(self)},{self.width})"

    def __str__(self) -> str:
        """Human-readable balanced ternary string (big-endian, +/0/- symbols)."""
        trit_dict = {P: "+", N: "-", Z: "0"}
        return "".join(trit_dict[t] for t in reversed(self._trits))

    # ── Arithmetic ──────────────────────────────────────────────────

    def __add__(self, other) -> TritArray:
        """Addition with silent truncation to width.

        Raises TypeError if widths differ.
        """
        if not isinstance(other, TritArray):
            return NotImplemented
        if len(self) != len(other):
            raise TypeError
        _trits = []
        c = Z
        for a, b in zip(self.trits, other.trits):
            s, c = a.full_add(b, c)
            _trits.append(s)
        return type(self)._from_trits(_trits, self.width)

    def __neg__(self) -> TritArray:
        """Negate every trit (balanced ternary negation)."""
        return type(self)._from_trits([-t for t in self.trits], self.width)

    def __sub__(self, other) -> TritArray:
        """Subtraction via addition of the negated operand."""
        return self + -other

    def __mul__(self, other) -> TritArray:
        """Multiplication by long multiplication, truncated to width.

        Raises TypeError if widths differ.
        """
        if not isinstance(other, TritArray):
            return NotImplemented
        if len(self) != len(other):
            raise TypeError
        result = type(self)._from_trits([Z], self.width)
        for i, t in enumerate(self._trits):
            if t == Z:
                continue
            partial = [Z] * i + [t * a for a in other._trits]
            p = type(self)._from_trits(partial, self.width)
            result = result + p
        return type(self)._from_trits(list(result.trits), self.width)

    def add_with_carry(self, other) -> tuple[TritArray, Trit]:
        """Addition returning both the truncated result and the carry trit.

        The carry is a full Trit (N, Z, or P), richer than a binary
        carry flag. Implements the ADC/SBC instruction behaviour.

        Returns:
            A tuple (result, carry) where carry is Z if no overflow.

        Raises:
            TypeError: If widths differ.
        """
        if not isinstance(other, TritArray):
            return NotImplemented
        if len(self) != len(other):
            raise TypeError
        _trits = []
        c = Z
        for a, b in zip(self.trits, other.trits):
            s, c = a.full_add(b, c)
            _trits.append(s)
        return type(self)._from_trits(_trits, self.width), c

    def add_saturating(self, other) -> TritArray:
        """Addition with saturation: clamps to max/min on overflow.

        On positive overflow, returns max value (all P trits).
        On negative overflow, returns min value (all N trits).
        Implements the ADDS instruction behaviour.

        Returns:
            A new TritArray, clamped if overflow occurred.
        """
        result, carry = self.add_with_carry(other)
        if carry == Z:
            return result
        elif carry == P:
            return type(self)._from_trits([P] * self._width, self._width)
        else:
            return type(self)._from_trits([N] * self._width, self._width)

    def sub_saturating(self, other) -> TritArray:
        """Subtraction with saturation. Implements SUBS instruction."""
        return self.add_saturating(-other)

    # ── Division ────────────────────────────────────────────────────

    def __divmod__(self, other) -> tuple[TritArray, TritArray]:
        """Balanced ternary division using the double trial quotient method.

        Returns (quotient, remainder) such that
        self == other * quotient + remainder.
        The remainder carries the sign of the dividend.

        Raises:
            ZeroDivisionError: If other is zero.
            TypeError: If widths differ.
        """
        if not isinstance(other, TritArray):
            raise TypeError
        if len(self) != len(other):
            raise TypeError
        if other == TritArray(0, self.width):
            raise ZeroDivisionError
        if self == TritArray(0, self.width):
            return TritArray(0, self.width), TritArray(0, self.width)
        sign_s = self._be_trits[0] == P
        sign_d = other._be_trits[0] == P

        s = abs(self)._be_trits
        partial_rest = []
        rem = list(s)
        q_be_trits = []
        abs_other = abs(other)
        while len(rem) > 0:
            partial_rest += [rem.pop(0)]
            V = TritArray.from_be_trits(partial_rest, self.width)
            if V + V > abs_other:
                q_be_trits.append(P)
                pr = V - abs_other
            elif V + V < -abs_other:
                q_be_trits.append(N)
                pr = V + abs_other
            else:
                q_be_trits.append(Z)
                pr = V
            partial_rest = pr._be_trits
        q = TritArray.from_be_trits(q_be_trits, self.width)
        pr = TritArray.from_be_trits(partial_rest, self.width)
        while abs(pr) + abs(pr) > abs(other):
            if pr > TritArray(0, self.width):
                q = q + TritArray(1, self.width)
                pr = pr - abs(other)
            else:
                q = q - TritArray(1, self.width)
                pr = pr + abs(other)
        if sign_s != sign_d:
            q = -q
        if not sign_s:
            pr = -pr
        return type(self)._from_trits(q.trits, self._width), type(self)._from_trits(
            pr.trits, self._width
        )

    def __floordiv__(self, other) -> TritArray:
        """Floor division (quotient only)."""
        return divmod(self, other)[0]

    def __mod__(self, other) -> TritArray:
        """Modulo (remainder only)."""
        return divmod(self, other)[1]

    # ── Shifts and rotations ────────────────────────────────────────

    def __lshift__(self, n: int) -> TritArray:
        """Left shift by n positions (toward most significant).

        Equivalent to multiplication by 3^n, truncated to width.
        """
        return type(self)._from_trits([Z] * n + list(self.trits), self.width)

    def __rshift__(self, n: int) -> TritArray:
        """Right shift by n positions (toward least significant).

        Equivalent to floor division by 3^n.
        """
        trits = list(self.trits[n:]) + [Z] * n
        return type(self)._from_trits(trits, self.width)

    def rotate_left(self, n: int) -> TritArray:
        """Rotate trits left (toward most significant) by n positions.

        Trits that shift out at the top wrap around to the bottom.
        """
        trits = self.trits[-n:] + self.trits[:-n]
        return type(self)._from_trits(trits, self.width)

    def rotate_right(self, n: int) -> TritArray:
        """Rotate trits right (toward least significant) by n positions.

        Trits that shift out at the bottom wrap around to the top.
        """
        trits = self.trits[n:] + self.trits[:n]
        return type(self)._from_trits(trits, self.width)

    # ── Trit-level operations ───────────────────────────────────────

    def cons(self, other) -> TritArray:
        """Trit-wise consensus (CONS instruction).

        For each trit pair: if both are equal and non-zero, the result
        is that value; otherwise Z.
        """
        res = []
        for a, b in zip(self.trits, other.trits):
            res += [a.cons(b)]
        return type(self)._from_trits(res, self.width)

    def acons(self, other) -> TritArray:
        """Trit-wise anti-consensus (ACONS instruction).

        The complement of consensus.
        """
        res = []
        for a, b in zip(self.trits, other.trits):
            res += [a.acons(b)]
        return type(self)._from_trits(res, self.width)

    def sign(self) -> Trit:
        """Return the sign trit of the value (TSIGN instruction).

        Returns P if positive, N if negative, Z if zero.
        """
        return self._be_trits[0]
