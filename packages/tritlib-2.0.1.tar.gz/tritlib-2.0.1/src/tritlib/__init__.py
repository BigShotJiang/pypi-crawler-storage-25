"""
tritlib: A Python library for trinary arithmetic and logic operations.

This package provides classes for working with trits (ternary digits), trits numbers, and fixed-width trytes.
It supports arithmetic operations, comparisons, and conversions between strings, integers, and trits.
"""

from .trit import Trit, N, Z, P
from .trits import Trits
from .tritarray import TritArray
from .tryte import Tryte
from .trybble import Trybble
from .word import Word
from .logic import Lukasiewicz, RM3, Bochvar, HT, Kleene, K3, L3, B3, pluralize
from .context import logic_mode
from .tfloat import TFloat

__all__ = [
    "Trit",
    "Trits",
    "Tryte",
    "Word",
    "Trybble",
    "TritArray",
    "N",
    "Z",
    "P",
    "Lukasiewicz",
    "RM3",
    "Bochvar",
    "HT",
    "Kleene",
    "logic_mode",
    "L3",
    "B3",
    "K3",
    "pluralize",
    "TFloat",
]
