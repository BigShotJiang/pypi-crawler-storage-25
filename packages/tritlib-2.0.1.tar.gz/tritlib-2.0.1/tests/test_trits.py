from tritlib import Trits, Z, N, P
import pytest


def test_trits_init():
    assert Trits(0) == Trits.from_str("0")
    assert int(Trits(5)) == 5
    assert int(Trits(-5)) == -5
    assert int(Trits(42)) == 42
    with pytest.raises(TypeError):
        Trits(None)


def test_get_item():
    a = Trits("+-0++")
    assert a[2:4] == Trits("-0")
    assert a[0] == a[1] == a[4]
    with pytest.raises(TypeError):
        a["test"]


def test_hash_equal():
    assert hash(Trits(42)) == hash(Trits(42))


def test_hash_in_set():
    s = {Trits(42), Trits(42), Trits(10)}
    assert len(s) == 2


def test_hash_as_dict_key():
    d = {Trits(42): "hello"}
    assert d[Trits(42)] == "hello"


def test_trits_init_from_str():
    assert Trits(-1) == Trits.from_str("-")
    assert Trits(1) == Trits.from_str("+")
    assert Trits(0) == Trits.from_str("0")

    assert Trits(2) == Trits.from_str("+-")
    assert Trits(3) == Trits.from_str("+0")
    assert Trits(5) == Trits.from_str("+--")
    assert Trits(-2) == Trits.from_str("-+")
    assert Trits(-3) == Trits.from_str("-0")
    assert Trits(-5) == Trits.from_str("-++")

    assert Trits(5) == Trits("+--")
    with pytest.raises(ValueError):
        Trits("+-01")


def test_from_trits():
    assert Trits("+-0") == Trits._from_trits([Z, N, P, Z, Z])
    assert Trits("+-0") == Trits._from_trits((Z, N, P, Z, Z))
    assert Trits("++-0+") == Trits.from_be_trits([Z, Z, P, P, N, Z, P])
    assert Trits._from_trits([]) == Trits(0)


def test_immutability():
    t = Trits(12)
    with pytest.raises(AttributeError):
        t._trits = (Z, Z)


def test_trits_to_str():
    assert str(Trits(-1)) == "-"
    assert str(Trits(1)) == "+"
    assert str(Trits(0)) == "0"

    assert str(Trits(2)) == "+-"
    assert str(Trits(3)) == "+0"
    assert str(Trits(5)) == "+--"
    assert str(Trits(-2)) == "-+"
    assert str(Trits(-3)) == "-0"
    assert str(Trits(-5)) == "-++"


def test_repr_trits():
    assert Trits(2).__repr__() == 'Trits("+-")'


def test_not_implemented():
    assert False == (Trits(3) == 3)
    with pytest.raises(TypeError):
        _ = Trits(3) * 3
    with pytest.raises(TypeError):
        _ = Trits(3) + 3
    with pytest.raises(TypeError):
        _ = Trits(3) - 3
    with pytest.raises(TypeError):
        _ = Trits(3) / 3
    with pytest.raises(TypeError):
        assert Trits(3) > 2
    with pytest.raises(TypeError):
        assert Trits(2) < 2
    with pytest.raises(TypeError):
        divmod(Trits(4), 2)


def tests_trits_len():
    assert len(Trits(-1)) == 1
    assert len(Trits(0)) == 1
    assert len(Trits(1)) == 1
    assert len(Trits(-2)) == 2
    assert len(Trits(-5)) == 3
    assert len(Trits(5)) == 3


def test_trits_add():
    for i in range(-10, 10):
        for j in range(-10, 10):
            assert int(Trits(i) + Trits(j)) == i + j


def test_trits_sub():
    for i in range(-10, 10):
        for j in range(-10, 10):
            assert int(Trits(i) - Trits(j)) == i - j


def test_trits_mul():
    for i in range(-100, 10):
        for j in range(-10, 100):
            assert int(Trits(i) * Trits(j)) == i * j


def test_trits_lt():
    assert Trits(-1) < Trits(0) < Trits(1)
    for i in range(-10, 10):
        for j in range(i + 1, i + 11):
            assert Trits(i) < Trits(j)


def test_trits_le():
    assert Trits(42) <= Trits(42)
    assert Trits(0) <= Trits(20)
    assert Trits(-19) <= Trits(14)


def test_trits_gt():
    assert Trits(1) > Trits(0) > Trits(-1)
    for i in range(-10, 10):
        for j in range(i - 1, i - 11):
            assert Trits(i) > Trits(j)


def test_trits_ge():
    assert Trits(42) >= Trits(42)
    assert Trits(20) >= Trits(0)
    assert Trits(-13) >= Trits(-20)


def test_divmod():
    a = [-101, -42, -13, -4, 0, 5, 11, 43, 123]
    b = [-89, -34, -10, -1, 2, 8, 20, 40, 80]
    for i in a[::1]:
        for j in b:
            q, r = divmod(Trits(i), Trits(j))
            assert int(q) * j + int(r) == i
            assert abs(int(r)) < abs(j)
    q, r = divmod(Trits(13), Trits(4))
    assert int(q) * 4 + int(r) == 13
    q, r = divmod(Trits(7), Trits(4))
    assert int(q) == 2 and int(r) == -1
    q, r = divmod(Trits(-7), Trits(4))
    assert int(q) * 4 + int(r) == -7

    q, r = divmod(Trits(40), Trits(6))
    assert int(q) == 7 and int(r) == -2
    q, r = divmod(Trits(13), Trits(4))
    assert int(q) * 4 + int(r) == 13
    q, r = divmod(Trits(7), Trits(4))
    assert int(q) == 2 and int(r) == -1
    q, r = divmod(Trits(-7), Trits(4))
    assert int(q) * 4 + int(r) == -7

    q, r = divmod(Trits(0), Trits(5))
    assert int(q) == 0 and int(r) == 0

    with pytest.raises(ZeroDivisionError):
        divmod(Trits(4), Trits(0))

    q, r = divmod(Trits(5), Trits(15))
    assert int(q) == 0 and int(r) == 5
    q, r = divmod(Trits(14), Trits(15))
    assert int(q) == 1 and int(r) == -1
    assert q == Trits(14) // Trits(15)
    assert r == Trits(14) % Trits(15)
