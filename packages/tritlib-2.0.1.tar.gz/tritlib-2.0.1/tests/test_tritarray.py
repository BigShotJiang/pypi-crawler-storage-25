from tritlib import Trits, Trit, TritArray, Z, N, P
import pytest


def test_tryte():
    a = TritArray(0, width=6)
    assert list(a.trits) == [Z] * 6
    b = TritArray(2, width=6)
    assert list(b.trits) == [N, P] + [Z] * 4

    with pytest.raises(OverflowError):
        TritArray(-400, width=6)
    with pytest.raises(OverflowError):
        TritArray(400, width=6)

    assert TritArray(42, width=6) == TritArray("+---0", 6)


def test_hash_equal():
    assert hash(TritArray(42, 6)) == hash(TritArray(42, 6))


def test_hash_in_set():
    s = {TritArray(42, 6), TritArray(42, 6), TritArray(10, 6)}
    assert len(s) == 2


def test_hash_as_dict_key():
    d = {TritArray(42, 6): "hello"}
    assert d[TritArray(42, 6)] == "hello"


def test_immutability():
    t = TritArray(12, 4)
    with pytest.raises(AttributeError):
        t._trits = (Z, Z, P, Z)


def test_repr():
    t = TritArray(12, 4)
    assert t.__repr__() == "TritArray(12,4)"


def test_get_item():
    a = TritArray("+-0++", 5)
    assert a[2:4] == Trits("-0")
    with pytest.raises(TypeError):
        a["test"]


def test_set():
    a = TritArray("+--+", 4)
    b = a.set(3, Z)
    assert b == TritArray("0--+", 4)
    with pytest.raises(ValueError):
        a.set(5, Z)


def test_tryte_lt():
    assert TritArray(42, width=6) < TritArray(45, width=6)
    assert TritArray(-19, width=6) < TritArray(45, width=6)
    assert TritArray(-42, width=6) < TritArray(-14, width=6)
    assert TritArray(45, width=6) > TritArray(-42, width=6)
    assert TritArray(45, width=6) > TritArray(42, width=6)
    assert TritArray(-15, width=6) > TritArray(-42, width=6)
    assert TritArray(-42, width=6) <= TritArray(-42, width=6)
    assert TritArray(42, width=6) >= TritArray(42, width=6)


def test_tryte_width():
    assert len(TritArray(42, 6)) == 6
    with pytest.raises(ValueError):
        _ = TritArray(42, 6) > TritArray(42, 9)
    with pytest.raises(ValueError):
        _ = TritArray(42, 6) == TritArray(42, 9)


def test_tryte_add():
    assert TritArray(42, 6) == TritArray(31, 6) + TritArray(11, 6)
    assert TritArray(300, 6) + TritArray(300, 6)
    assert (TritArray(332, 6), Trit(0)) == TritArray(300, 6).add_with_carry(
        TritArray(32, 6)
    )
    assert (TritArray(-364, 6), Trit(1)) == TritArray(300, 6).add_with_carry(
        TritArray(65, 6)
    )
    for i in range(-10, 10):
        for j in range(-10, 10):
            assert TritArray(j, 6) + TritArray(i, 6) == TritArray(i + j, 6)

    with pytest.raises(TypeError):
        _ = TritArray(12, 4) + 3
    with pytest.raises(TypeError):
        _ = TritArray(12, 4) + TritArray(12, 5)
    with pytest.raises(TypeError):
        TritArray(300, 6).add_with_carry(TritArray(32, 4))
    assert TritArray(300, 6).add_with_carry(32) is NotImplemented


def test_tryte_neg():
    assert TritArray(4, 6) == -TritArray(-4, 6)
    assert TritArray(0, 6) == -TritArray(0, 6)
    assert TritArray(-10, 6) == -TritArray(10, 6)


def test_tryte_sub():
    assert TritArray(6, 6) - TritArray(7, 6) == TritArray(-1, 6)
    assert TritArray(20, 6) - TritArray(4, 6) == TritArray(16, 6)
    assert TritArray(10, 6) - TritArray(24, 6) == TritArray(-14, 6)
    for i in range(-10, 10):
        for j in range(-10, 10):
            assert TritArray(j, 6) - TritArray(i, 6) == TritArray(j - i, 6)


def test_tryte_mul():
    for i in range(-10, 10):
        for j in range(-10, 10):
            assert TritArray(j, 6) * TritArray(i, 6) == TritArray(i * j, 6)
    with pytest.raises(TypeError):
        _ = TritArray(12, 4) * TritArray(3, 3)
    with pytest.raises(TypeError):
        _ = TritArray(12, 4) * 3


def test_tryte_to_str():
    assert str(TritArray(-1, 6)) == "00000-"
    assert str(TritArray(1, 6)) == "00000+"
    assert str(TritArray(0, 6)) == "000000"
    assert str(TritArray(2, 6)) == "0000+-"
    assert str(TritArray(3, 6)) == "0000+0"
    assert str(TritArray(5, 6)) == "000+--"
    assert str(TritArray(-2, 6)) == "0000-+"
    assert str(TritArray(-3, 6)) == "0000-0"
    assert str(TritArray(-5, 6)) == "000-++"


def test_tryte_to_trits():
    for i in range(-15, 15):
        assert TritArray(i, 6).to_trits() == Trits(i)


def test_be_trits():
    assert TritArray(-1, 6)._be_trits == [N]
    assert TritArray(2, 6)._be_trits == [P, N]
    assert TritArray(5, 6)._be_trits == [P, N, N]
    assert TritArray(5, 9)._be_trits == [P, N, N]
    assert TritArray(-5, 6)._be_trits == [N, P, P]
    assert TritArray(-5, 9)._be_trits == [N, P, P]

    assert TritArray.from_be_trits([N, P, P], 6) == TritArray(-5, 6)
    assert TritArray.from_be_trits([P, N], 6) == TritArray(2, 6)
    assert TritArray.from_be_trits([P, N, N], 6) == TritArray(5, 6)
    assert TritArray.from_be_trits([N, P, P], 9) == TritArray(-5, 9)

    for i in range(-105, 355):
        t = TritArray(i, 6)
        b = t._be_trits
        assert TritArray.from_be_trits(b, 6) == t


def test_resize():
    for j in range(-10, 10):
        for i in range(7, 10):
            a = TritArray(j, 6)
            assert a.to_width(i) == TritArray(j, i)

    be_trits = [N, P, P, Z, P]
    assert TritArray.from_be_trits(be_trits, 6).to_width(3) == TritArray.from_be_trits(
        be_trits[2:], 3
    )


def test_divmod():
    a = [-101, -42, -13, -4, 0, 5, 11, 43, 123]
    b = [-89, -34, -10, -1, 2, 8, 20, 40, 80]
    for i in a[::1]:
        for j in b:
            q, r = divmod(TritArray(i, 6), TritArray(j, 6))
            assert int(q) * j + int(r) == i
    q, r = divmod(TritArray(13, 6), TritArray(4, 6))
    assert int(q) * 4 + int(r) == 13
    q, r = divmod(TritArray(7, 6), TritArray(4, 6))
    assert int(q) == 2 and int(r) == -1
    q, r = divmod(TritArray(-7, 6), TritArray(4, 6))
    assert int(q) * 4 + int(r) == -7

    q, r = divmod(TritArray(40, 27), TritArray(6, 27))
    assert len(q) == len(r) == 27
    assert int(q) == 7
    assert int(r) == -2

    q, r = divmod(TritArray(0, 6), TritArray(5, 6))
    assert int(q) == 0 and int(r) == 0

    with pytest.raises(ZeroDivisionError):
        divmod(TritArray(4, 6), TritArray(0, 6))

    q, r = divmod(TritArray(5, 6), TritArray(15, 6))
    assert int(q) == 0 and int(r) == 5
    q, r = divmod(TritArray(14, 6), TritArray(15, 6))
    assert int(q) == 1 and int(r) == -1
    with pytest.raises(TypeError):
        _ = divmod(TritArray(12, 4), TritArray(3, 3))
    with pytest.raises(TypeError):
        _ = divmod(TritArray(12, 4), 3)


def test_divmod_high():
    a = TritArray(12432098, 27)
    b = TritArray(1234, 27)
    q, r = divmod(a, b)
    assert q * b + r == a
    a = TritArray(12390843, 27)
    b = TritArray(123, 27)
    q, r = divmod(a, b)
    assert q * b + r == a


def test_floordiv_and_mod():
    assert TritArray(12, 4) // TritArray(5, 4) == TritArray(2, 4)
    assert TritArray(13, 4) % TritArray(5, 4) == TritArray(-2, 4)


def test_shift():
    for n in range(10):
        a = TritArray(3**n, 10)
        assert a >> n == TritArray(1, 10)
        assert TritArray(1, 10) << n == a
        a = TritArray(-(3**n), 10)
        assert a >> n == TritArray(-1, 10)
        assert TritArray(-1, 10) << n == a


def test_rotations():
    a = TritArray("++-+00", 6)
    assert a.rotate_left(2) == TritArray("-+00++", 6)
    assert a.rotate_right(2) == TritArray("00++-+", 6)


def test_get():
    a = TritArray("+-0++-", 6)
    assert a[0] == N
    assert a[1] == P
    assert a[2] == P
    assert a[3] == Z
    assert a[4] == N
    assert a[5] == P

    b = a.set(3, N)
    assert b[3] == N
    assert b == TritArray("+--++-", 6)


def test_cons():
    a = TritArray("+++---000", 9)
    b = TritArray("+-0+-0+-0", 9)
    assert a.cons(b) == TritArray("+000-0000", 9)


def test_acons():
    a = TritArray("+++---000", 9)
    b = TritArray("+-0+-0+-0", 9)
    assert a.acons(b) == TritArray("00-00+-+0", 9)


def test_add_saturating():
    assert int(TritArray(300, 6).add_saturating(TritArray(300, 6))) == 364
    assert int(TritArray(-300, 6).add_saturating(TritArray(-300, 6))) == -364
    assert int(TritArray(10, 6).add_saturating(TritArray(5, 6))) == 15  # pas d'overflow


def test_sub_saturating():
    assert int(TritArray(-300, 6).sub_saturating(TritArray(300, 6))) == -364
    assert int(TritArray(300, 6).sub_saturating(TritArray(-300, 6))) == 364
    assert (
        int(TritArray(10, 6).sub_saturating(TritArray(15, 6))) == -5
    )  # pas d'overflow
