from tritlib import Word, Z, TFloat, TritArray


def test_word_init():
    a = Word(42)
    assert len(a) == 27
    assert int(a) == 42

    b = Word(-432)

    assert len(b) == 27
    assert int(b) == -432


def test_word_min_max_zero():
    assert Word(0) == Word.ZERO
    assert Word(3812798742493) == Word.MAX == -Word.MIN


def test_word_rshift():
    a = Word(10)
    assert Word(30) == a << 1
    assert Word(3) == a >> 1


def test_word_op():
    a = Word(123)
    b = Word(10843)
    assert int(a + b) == int(a) + int(b)
    assert isinstance(a + b, Word)
    assert int(a - b) == int(a) - int(b)
    assert isinstance(a - b, Word)
    assert int(a * b) == int(a) * int(b)
    assert isinstance(a * b, Word)
    assert isinstance(a, Word)
    q, r = b.__divmod__(a)
    assert isinstance(q, Word)
    assert isinstance(r, Word)
    assert q * a + r == b


def test_word_tfloat():
    tf = TFloat(234.1234, 26)
    w = Word.from_tfloat(tf)
    assert len(w) == 27
    assert w.trits[:26] == tf._raw.trits
    assert w.trits[26] == Z
    assert isinstance(w, TritArray)
    tf2 = w.to_tfloat()
    assert tf == tf2


def test_word_neg_tfloat():
    tf = TFloat(-234.1234, 26)
    w = Word.from_tfloat(tf)
    assert len(w) == 27
    assert w.trits[:26] == tf._raw.trits
    assert w.trits[26] == Z

    tf2 = w.to_tfloat()
    assert tf == tf2


def test_word_to_bytes():
    a = Word(293812)
    b = a.to_bytes()
    assert len(b) == 6
    assert int.from_bytes(b) == int(a)


def test_bytes_to_word():
    a = Word(2349823)
    b = a.to_bytes()
    assert Word(b) == a
