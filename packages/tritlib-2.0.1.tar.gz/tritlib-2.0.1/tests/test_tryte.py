from tritlib import Tryte, Trybble, Word, Trits


def test_tryte():
    a = Tryte(28)
    assert a.width == 9
    b = Tryte(39)
    assert a + b == Tryte(28 + 39)


def test_trybble():
    a = Trybble(2)
    assert a.width == 3
    b = Trybble(3)
    assert a + b == Trybble(2 + 3)


def test_word():
    a = Word(129387)
    assert a.width == 27
    b = Word(2387)
    assert a + b == Word(129387 + 2387)

    t = Trits("+---0+").trits
    c = Word._from_trits(t)
    assert isinstance(c, Word)
