from tritlib import TFloat
import pytest


def test_truediv():
    with pytest.raises(TypeError):
        _ = TFloat(12.0, 24) / 23.2
    with pytest.raises(TypeError):
        _ = TFloat(12.0, 24) / TFloat(23.2, 22)


def test_div_by_zero():
    assert (TFloat(12.0, 8) / TFloat(0.0, 8)) == TFloat(float("inf"), 8)


def test_zero_by_zero():
    assert (TFloat(0.0, 8) / TFloat(0.0, 8)) == TFloat(float("nan"), 8)


def test_inf_by_inf():
    assert TFloat(float("inf"), 26) / TFloat(float("inf"), 26) == TFloat(
        float("nan"), 26
    )


def test_inf_by_zero():
    assert TFloat(float("inf"), 26) / TFloat(0.0, 26) == TFloat(float("inf"), 26)


def test_truediv_some_values():
    for i in [1230984.23, -30.23, 24.1, -1.3, 2.56, 15.23234, 1240.23]:
        for j in [-30.23, 24.1, -1.3, 2.56, 15.23234, 1240.23]:
            a = TFloat(i, 26)
            b = TFloat(j, 26)
            assert abs(float(a / b) - (i / j)) < 1e-4
