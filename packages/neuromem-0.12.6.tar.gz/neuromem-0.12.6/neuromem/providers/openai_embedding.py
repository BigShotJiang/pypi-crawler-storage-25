"""OpenAI-compatible embedding provider."""

import httpx

from neuromem.providers.embedding import EmbeddingProvider


class OpenAIEmbedding(EmbeddingProvider):
    """OpenAI embedding provider (text-embedding-3-small/large)."""

    def __init__(
        self,
        api_key: str,
        model: str = "text-embedding-3-small",
        base_url: str = "https://api.openai.com/v1",
        dimensions: int = 1536,
        batch_limit: int = 10,
    ):
        # batch_limit default 10 keeps us safe across the most restrictive
        # OpenAI-compatible providers (dashscope rejects > 10). Pure OpenAI
        # users can pass batch_limit=2048 to use the real upstream cap.
        self._api_key = api_key
        self._model = model
        self._base_url = base_url
        self._dims = dimensions
        self._batch_limit = batch_limit

    @property
    def dims(self) -> int:
        return self._dims

    async def embed(self, text: str) -> list[float]:
        result = await self.embed_batch([text])
        return result[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        if len(texts) <= self._batch_limit:
            return await self._embed_one_chunk(texts)
        results: list[list[float]] = []
        for i in range(0, len(texts), self._batch_limit):
            results.extend(await self._embed_one_chunk(texts[i:i + self._batch_limit]))
        return results

    async def _embed_one_chunk(self, texts: list[str]) -> list[list[float]]:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                f"{self._base_url}/embeddings",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": self._model,
                    "input": texts,
                    "dimensions": self._dims,
                },
            )
            resp.raise_for_status()
            data = resp.json()
            sorted_data = sorted(data["data"], key=lambda x: x["index"])
            return [item["embedding"] for item in sorted_data]
