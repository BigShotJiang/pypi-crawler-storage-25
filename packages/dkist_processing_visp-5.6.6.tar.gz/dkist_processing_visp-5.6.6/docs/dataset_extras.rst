Dataset Extras
==============

In addition to the L1 science frames, each ViSP dataset includes a collection of "dataset extras", which are described in detail on this page.

**NOTE:** The primary purpose of dataset extras is to provide a common context between the user and the DKIST Data Center
when discussing issues seen in the L1 data. Any user who uses dataset extras for analysis or inferring properties of the L1
data does so *at their own risk*. **Support for the dataset extras as useful end-user data is not guaranteed.**

Location and Naming
-------------------

All dataset extras are included with a full download of the main dataset and live in a subdirectory called "extra". The
general naming scheme is

`VISP_{DATASET_ID}_{NAME}_{DETAIL}_{COUNTER}.fits`

with

DATASET_ID
    The dataset ID of the current dataset. Matches the same value in the names of L1 files.

NAME
    The identifier of the current extra. See the list below.

DETAIL
    Most Dataset Extras use extra details in their filenames that correspond to properties that change within extras of
    the same NAME. The full list of potential DETAILS is below; see each extra's description for which details are
    included in its filename.

    BEAM_{VALUE}
        The current ViSP beam (ViSP has two beams).

    MODSATE_{VALUE}
        The current modulation state.

    READOUT_EXP_TIME_{VALUE}
        The current sensor exposure time.

    CS_STEP_{VALUE}
        For Polcal-As-Science extras, the current Calibration Sequence step.

    CS_STEP_FRAME_{VALUE}
        For Polcal-As-Science extras, the current frame within a single Calibration Sequence step.

    STOKES_{VALUE}
        For Polcal-As-Science extras, the current Stokes parameter.

COUNTER
    A counter that starts from 1. Allows for multiple extras of the same type, although this is very rare.

Headers
-------

All dataset extra files have headers that conform to the `Dataset Extras FITS Specification <https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#>`_.
Please see that page for a complete list of header keys and their meanings. Note that, apart from the
`ViSP <https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#visp-keywords>`_ table,
not all extras will have all header keys; the specific tables that apply to each extra are listed below.

List of Dataset Extras
----------------------

The values of this list correspond to the "NAME" field mentioned above.

DARK
    The average dark frame used to correct all other frames. The result of the `~dkist_processing_visp.tasks.dark` task.
    This extra also includes a `READOUT_EXP_TIME_{VALUE}` part of the filename that corresponds to the sensor readout
    time of the given dark.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM, READOUT_EXP_TIME

BACKGROUND-LIGHT
    Estimation of the :doc:`background light </background_light>` signal. Only produced if the background light task
    is run, which it isn't for data taken after December 1st, 2022.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

SOLAR-GAIN
    The average solar gain/flat array used to correct science data, with solar spectrum removed. The result of the
    :doc:`gain </gain_correction>` task.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

CHARACTERISTIC-SPECTRA
    The measured characteristic solar spectra that are removed from raw solar gain frames to produce the SOLAR-GAIN frames.
    See :doc:`here </gain_correction>` for more info.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

BEAM-ANGLE
    The rotation angle that, when applied to each beam, aligns the spatial axis with a pixel axis. There is one file per
    beam, each with a single float value. See :doc:`here </geometric>` for more information.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

MODULATION_STATE_OFFSETS
    The (x, y) pixel offsets needed to align each modstate's data with a reference modstate (beam 1, modstate 0). Each
    file corresponds to a single modstate from a single beam and has data shape `(2,)`, corresponding to the (x, y) shift.
    See :doc:`here </geometric>` for more information.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM, MODSTATE

SPECTRAL-CURVATURE-SHIFTS
    The pixel shift in the dispersion direction to apply to each spatial pixel to align all spectra to the same
    relative wavelength grid. There is one file per ViSP beam, each with a single value per spatial pixel.
    See :doc:`here </geometric>` for more information.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

    **DETAIL fields**: BEAM

WAVELENGTH-CALIBRATION-INPUT-SPECTRUM
    Representative solar spectrum (derived from the solar gain images) used to compute the absolute wavelength solution.
    See :doc:`here </wavelength_calibration>` for more information.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_

WAVELENGTH-CALIBRATION-REFERENCE-SPECTRUM
    The best-fit combination of Solar and telluric atlases. See :doc:`here </wavelength_calibration>` for more information.

    **Header tables**: `Common`_, `Atlas`_

REFERENCE-WAVELENGTH-VECTOR
    Wavelength abscissa for both the input and best-fit atlas spectra. Units are nanometers.

    **Header tables**: `Common`_, `Wavecal`_

DEMODULATION-MATRICES
    Arrays used to demodulate science data. Each has shape `(1000, 2560, 4, 10)`; the first two axes represent the chip
    size of a single beam and the last two correspond to Stokes dimension and modulation state, respectively.
    See :doc:`here </polarization_calibration>` for more information.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_

    **DETAIL fields**: BEAM

POLCAL-AS-SCIENCE
    The INPUT POLCAL task-type frames processed as if they were science frames. These extras also include `CS_STEP_{VALUE}`
    and `CS_STEP_FRAME_{value}` in their filenames, which correspond to the `Calibration Sequence <https://docs.dkist.nso.edu/projects/pac/en/stable/background.html#the-rol-of-polcal-data>`_
    step and separate frames within each step, respectively. These POLCAL frames are processed in
    :doc:`exactly the same way </science_calibration>` as science frames.

    **Header tables**: `Common`_, `Aggregate`_, `IPTASK`_, `GOS`_, `PCAS`_

    **DETAIL fields**: BEAM, CS_STEP, CS_STEP_FRAME, STOKES

.. _Common: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#common-keywords
.. _Aggregate: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#aggregate-keywords
.. _IPTASK: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#iptask-keywords
.. _GOS: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#gos-configuration-keywords
.. _Wavecal: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#wavelength-calibration-keywords
.. _Atlas: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#atlas-keywords
.. _PCAS: https://docs.dkist.nso.edu/projects/data-products/en/stable/specs/dataset_extra.html#pcas-keywords
