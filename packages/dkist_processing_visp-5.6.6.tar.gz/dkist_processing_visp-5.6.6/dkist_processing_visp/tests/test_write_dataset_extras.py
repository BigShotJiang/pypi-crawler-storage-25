import numpy as np
import pytest
from astropy.io import fits
from dkist_header_validator.spec_validators import spec_extras_validator
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.codecs.json import json_encoder
from dkist_processing_common.models.extras import DatasetExtraType
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_visp.models.tags import VispTag
from dkist_processing_visp.tasks.write_dataset_extras import VispWriteL1DatasetExtras
from dkist_processing_visp.tests.conftest import VispConstantsDb
from dkist_processing_visp.tests.conftest import VispInputDatasetParameterValues
from dkist_processing_visp.tests.conftest import write_intermediate_background_to_task
from dkist_processing_visp.tests.conftest import write_intermediate_darks_to_task
from dkist_processing_visp.tests.conftest import write_intermediate_geometric_to_task
from dkist_processing_visp.tests.conftest import write_intermediate_solar_cals_to_task


@pytest.fixture
def write_dataset_extras_task(recipe_run_id, init_visp_constants_db, pol_mode, tmp_path):
    """Dataset extras task."""
    constants_db = VispConstantsDb(
        POLARIMETER_MODE=pol_mode,
        NUM_MODSTATES=1 if pol_mode == "observe_intensity" else 10,
        NUM_FRAMES_PER_CS_STEP=2,
        POLCAL_EXPOSURE_TIMES=(1.0,),
    )
    init_visp_constants_db(recipe_run_id, constants_db)
    with VispWriteL1DatasetExtras(
        recipe_run_id=recipe_run_id,
        workflow_name="workflow_name",
        workflow_version="workflow_version",
    ) as task:
        try:  # This try... block is here to make sure the dbs get cleaned up if there's a failure in the fixture
            task.scratch = WorkflowFileSystem(
                scratch_base_path=tmp_path, recipe_run_id=recipe_run_id
            )
            yield task
        except:
            raise
        finally:
            task._purge()


def write_wavecal_solution_header_to_task(task):
    """Write wavelength calibration intermediate file to task for dataset extras."""
    header = {
        "CTYPE2": "AWAV-GRA",
        "CUNIT2": "nm",
        "CRPIX2": 509,
        "CRVAL2": 589.1,
        "CDELT2": 0.001,
        "PV2_0": 316000.0,
        "PV2_1": 10,
        "PV2_2": 73.1,
        "CTYPE2A": "AWAV-GRA",
        "CUNIT2A": "nm",
        "CRPIX2A": 509,
        "CRVAL2A": 589.1,
        "CDELT2A": 0.001,
        "PV2_0A": 316000.0,
        "PV2_1A": 10,
        "PV2_2A": 73.1,
    }
    task.write(
        data=header,
        tags=[VispTag.task_wavelength_calibration(), VispTag.intermediate()],
        encoder=json_encoder,
    )


def write_intermediate_characteristic_spectra_to_task(task, *, data_shape: tuple[int, int]):
    for beam in [1, 2]:
        task.write(
            data=np.ones(data_shape),
            tags=[
                VispTag.intermediate_frame(beam=beam),
                VispTag.task_characteristic_spectra(),
            ],
            encoder=fits_array_encoder,
        )


def write_intermediate_demodulation_matrices_to_task(task, *, data_shape: tuple[int, int]):
    for beam in [1, 2]:
        task.write(
            data=np.ones((*data_shape, 4, 10)),
            tags=[VispTag.intermediate_frame(beam=beam), VispTag.task_demodulation_matrices()],
            encoder=fits_array_encoder,
        )


def write_polcal_as_science_to_task(
    task,
    *,
    data_shape: tuple[int, int],
    num_cs_steps: int,
    num_frames_per_cs_step: int,
):
    for cs_step in range(num_cs_steps):
        for cs_step_frame in range(num_frames_per_cs_step):
            for stokes in ["I", "Q", "U", "V"]:
                task.write(
                    data=np.ones(data_shape),
                    tags=[
                        VispTag.task(TaskName.polcal_as_science),
                        VispTag.stokes(stokes),
                        VispTag.cs_step(cs_step),
                        VispTag.cs_step_frame(cs_step_frame),
                    ],
                    encoder=fits_array_encoder,
                )


def write_intermediate_wavecals_to_task(task, *, data_shape: tuple[int, int]):
    task.write(
        data=np.ones(data_shape[0]),
        tags=[VispTag.intermediate(), VispTag.task_wavelength_calibration_input_spectrum()],
        encoder=fits_array_encoder,
    )
    task.write(
        data=np.ones(data_shape[0]),
        tags=[VispTag.intermediate(), VispTag.task_wavelength_calibration_reference_spectrum()],
        encoder=fits_array_encoder,
    )
    task.write(
        data=np.ones(data_shape[0]),
        tags=[
            VispTag.intermediate(),
            VispTag.task_wavelength_calibration_reference_wavelength_vector(),
        ],
        encoder=fits_array_encoder,
    )


def write_intermediate_files_to_task(task, data_shape, num_dup_background: int):
    """Write intermediate files to task for dataset extras."""
    for readout_time in VispConstantsDb.DARK_READOUT_EXP_TIMES:
        write_intermediate_darks_to_task(
            task, dark_signal=1.0, readout_exp_time=readout_time, data_shape=data_shape
        )
    for _ in range(num_dup_background):
        write_intermediate_background_to_task(task, background_signal=1.0, data_shape=data_shape)
    write_intermediate_solar_cals_to_task(task, data_shape=data_shape)
    write_intermediate_geometric_to_task(
        task, num_modstates=VispConstantsDb.NUM_MODSTATES, data_shape=data_shape
    )
    write_intermediate_characteristic_spectra_to_task(task, data_shape=data_shape)
    write_intermediate_wavecals_to_task(task, data_shape=data_shape)
    write_intermediate_demodulation_matrices_to_task(task, data_shape=data_shape)
    write_polcal_as_science_to_task(
        task,
        data_shape=data_shape,
        num_cs_steps=task.constants.num_cs_steps,
        num_frames_per_cs_step=task.constants.num_frames_per_cs_step,
    )


@pytest.mark.parametrize(
    "pol_mode, background_on, num_dup_background",
    [
        pytest.param("observe_polarimetric", True, 0, id="polarimetric-background_on-missing"),
        pytest.param("observe_polarimetric", True, 1, id="polarimetric-background_on-single"),
        pytest.param("observe_polarimetric", True, 2, id="polarimetric-background_on-duplicate"),
        pytest.param("observe_polarimetric", False, 0, id="polarimetric-background_off"),
        pytest.param("observe_polarimetric", False, 1, id="polarimetric-background_off-discard"),
        pytest.param("observe_intensity", False, 0, id="intensity"),
    ],
)
def test_write_dataset_extras(
    write_dataset_extras_task,
    pol_mode,
    background_on,
    num_dup_background,
    mocker,
    fake_gql_client,
    assign_input_dataset_doc_to_task,
):
    """
    Given: Intermediate files written after calibration
    When: Writing the dataset extras
    Then: The correct files are written
    """
    mocker.patch(
        "dkist_processing_common.tasks.mixin.metadata_store.GraphQLClient", new=fake_gql_client
    )
    task = write_dataset_extras_task
    write_wavecal_solution_header_to_task(task)
    write_intermediate_files_to_task(
        task, data_shape=(10, 10), num_dup_background=num_dup_background
    )
    assign_input_dataset_doc_to_task(
        task, VispInputDatasetParameterValues(visp_background_on=background_on)
    )
    task()
    files = list(task.read(tags=[VispTag.extra()]))
    num_beams = 2
    expected_num_intensity_extras = {
        "dark": num_beams * len(task.constants.dark_readout_exp_times),
        "solar_gain": num_beams,
        "characteristic_spectra": num_beams,
        "mod_offsets": num_beams * task.constants.num_modstates,
        "beam_angles": num_beams,
        "spectral_curvature_shifts": num_beams,
        "wavecal_input": 1,
        "wavecal_best_fit": 1,
        "wavecal_wavelength": 1,
    }
    num_stokes = 4
    expected_num_polarization_extras = {
        "background": num_beams * background_on * (num_dup_background != 0),
        "demod_matrices": num_beams,
        "pcas": num_stokes * task.constants.num_cs_steps * task.constants.num_frames_per_cs_step,
    }
    if pol_mode == "observe_intensity":
        assert len(files) == sum(expected_num_intensity_extras.values())
    else:
        assert len(files) == sum(expected_num_intensity_extras.values()) + sum(
            expected_num_polarization_extras.values()
        )
    for file in files:
        assert file.exists
        assert spec_extras_validator.validate(file, extra=False)
        hdu_list = fits.open(file)
        header = hdu_list[1].header
        assert len(hdu_list) == 2  # Primary, CompImage
        assert isinstance(hdu_list[0], fits.PrimaryHDU)
        assert isinstance(hdu_list[1], fits.CompImageHDU)
        assert header["PROCTYPE"] == "L1_EXTRA"
        assert header["EXTNAME"] in DatasetExtraType
