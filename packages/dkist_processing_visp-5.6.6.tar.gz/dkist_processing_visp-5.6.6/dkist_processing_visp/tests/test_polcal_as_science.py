import numpy as np
import pytest
from dkist_processing_common._util.scratch import WorkflowFileSystem
from dkist_processing_common.codecs.fits import fits_array_encoder
from dkist_processing_common.codecs.json import json_encoder
from dkist_processing_common.models.task_name import TaskName

from dkist_processing_visp.models.tags import VispTag
from dkist_processing_visp.tasks.polcal_as_science import PolcalAsScienceCalibration
from dkist_processing_visp.tests.conftest import CalibrationSequence
from dkist_processing_visp.tests.conftest import VispConstantsDb
from dkist_processing_visp.tests.conftest import VispInputDatasetParameterValues
from dkist_processing_visp.tests.conftest import write_calibration_sequence_frames_to_task
from dkist_processing_visp.tests.conftest import write_intermediate_background_to_task
from dkist_processing_visp.tests.conftest import write_intermediate_darks_to_task
from dkist_processing_visp.tests.conftest import write_intermediate_geometric_to_task
from dkist_processing_visp.tests.conftest import write_intermediate_solar_cals_to_task
from dkist_processing_visp.tests.header_models import VispCSStepPolcalFrames


def write_demod_matrices_to_task(task, num_modstates: int):
    demod_matrices = np.zeros((4, num_modstates)) + np.array([1, 2, 3, 4])[:, None]
    for beam in [1, 2]:
        task.write(
            data=demod_matrices,
            tags=[
                VispTag.intermediate(),
                VispTag.frame(),
                VispTag.task_demodulation_matrices(),
                VispTag.beam(beam),
            ],
            encoder=fits_array_encoder,
        )


@pytest.fixture
def dummy_wavelength_solution():
    axis_num = 1
    dummy_fit_solution = {
        f"CTYPE{axis_num}": "AWAV-GRA",
        f"CUNIT{axis_num}": "nm",
        f"CRPIX{axis_num}": 5,
        f"CRVAL{axis_num}": 9999.0,
        f"CDELT{axis_num}": 4.56,
        f"PV{axis_num}_0": 78.9,
        f"PV{axis_num}_1": 51,
        f"PV{axis_num}_2": 11121,
    }

    return dummy_fit_solution | {f"{k}A": v for k, v in dummy_fit_solution.items()}


@pytest.fixture(scope="function", params=["observe_polarimetric", "observe_intensity"])
def pcas_calibration_task(
    tmp_path,
    recipe_run_id,
    init_visp_constants_db,
    request,
):
    num_cs_steps = 5
    num_frames_per_cs_step = 3
    num_map_scans = 2
    num_raster_steps = 2
    readout_exp_time = 0.04
    pol_mode = request.param
    if pol_mode == "observe_polarimetric":
        num_modstates = 2
    else:
        num_modstates = 1

    constants_db = VispConstantsDb(
        POLARIMETER_MODE=pol_mode,
        NUM_MODSTATES=num_modstates,
        NUM_MAP_SCANS=num_map_scans,
        NUM_RASTER_STEPS=num_raster_steps,
        NUM_BEAMS=2,
        NUM_CS_STEPS=num_cs_steps,
        NUM_FRAMES_PER_CS_STEP=num_frames_per_cs_step,
        OBSERVE_READOUT_EXP_TIMES=(readout_exp_time,),
        AXIS_1_TYPE="HPLT-TAN",
        AXIS_2_TYPE="AWAV",
    )
    init_visp_constants_db(recipe_run_id, constants_db)
    with PolcalAsScienceCalibration(
        recipe_run_id=recipe_run_id,
        workflow_name="polcal_as_science_calibration",
        workflow_version="VX.Y",
    ) as task:
        try:  # This try... block is here to make sure the dbs get cleaned up if there's a failure in the fixture
            task.scratch = WorkflowFileSystem(
                scratch_base_path=tmp_path, recipe_run_id=recipe_run_id
            )

            yield task, pol_mode, readout_exp_time, num_map_scans, num_raster_steps, num_modstates, num_cs_steps, num_frames_per_cs_step
        except:
            raise
        finally:
            task._purge()


def tag_on_modstate_and_cs_step_and_cs_step_frame(frame: VispCSStepPolcalFrames):
    modstate = frame.current_modstate("")  # Weird signature due to key_function
    cs_step = frame.current_cs_step
    cs_step_frame = frame.current_cs_step_frame

    return [
        VispTag.modstate(modstate),
        VispTag.cs_step(cs_step),
        VispTag.cs_step_frame(cs_step_frame),
    ]


def test_polcal_as_science_calibration_task(
    pcas_calibration_task,
    assign_input_dataset_doc_to_task,
    mocker,
    fake_gql_client,
    dummy_wavelength_solution,
):
    """
    Given: A PolcalAsScienceCalibration task
    When: Calling the task instance
    Then: There are the expected number of output frames with the correct tags applied
    """

    seq = CalibrationSequence()

    mocker.patch(
        "dkist_processing_common.tasks.mixin.metadata_store.GraphQLClient", new=fake_gql_client
    )

    # When
    (
        task,
        polarization_mode,
        readout_exp_time,
        num_maps,
        num_raster_steps,
        num_modstates,
        num_cs_steps,
        num_frames_per_cs_step,
    ) = pcas_calibration_task

    input_shape = (50, 20)
    intermediate_shape = (25, 20)
    beam_border = input_shape[0] // 2
    assign_input_dataset_doc_to_task(
        task,
        VispInputDatasetParameterValues(visp_background_on=True, visp_beam_border=beam_border),
    )

    offsets = np.tile(np.array([-10.2, -5.1]), (2, num_modstates, 1))
    offsets[0] = 0.0  # So beam 1 has zero offset

    write_intermediate_darks_to_task(
        task=task,
        dark_signal=0,
        readout_exp_time=readout_exp_time,
        data_shape=intermediate_shape,
    )
    write_intermediate_background_to_task(
        task=task, background_signal=0.0, data_shape=intermediate_shape
    )
    write_intermediate_geometric_to_task(
        task=task, num_modstates=num_modstates, data_shape=intermediate_shape, offsets=offsets
    )
    write_intermediate_solar_cals_to_task(
        task=task,
        data_shape=intermediate_shape,
    )
    write_demod_matrices_to_task(task=task, num_modstates=num_modstates)
    task.write(
        data=dummy_wavelength_solution,
        tags=[VispTag.intermediate(), VispTag.task_wavelength_calibration()],
        encoder=json_encoder,
    )
    # Create a fake set of calibration sequence frames
    write_calibration_sequence_frames_to_task(
        task=task,
        num_modstates=num_modstates,
        pol_status=seq.pol_status,
        pol_theta=seq.pol_theta,
        ret_status=seq.ret_status,
        ret_theta=seq.ret_theta,
        dark_status=seq.dark_status,
        dark_signal=5.0,
        clear_signal=6.0,
        data_shape=input_shape,
        tags=[VispTag.input(), VispTag.readout_exp_time(readout_exp_time)],
        tag_func=tag_on_modstate_and_cs_step_and_cs_step_frame,
        num_frames_per_cs_step=num_frames_per_cs_step,
    )

    task()

    output_files = list(task.read(tags=[VispTag.task(TaskName.polcal_as_science)]))

    if polarization_mode == "observe_intensity":
        assert len(output_files) == 0
    else:
        num_stokes = len(task.constants.stokes_params)
        assert len(output_files) == num_cs_steps * num_frames_per_cs_step * num_stokes

        for cs_step in range(num_cs_steps):
            for cs_step_frame in range(num_frames_per_cs_step):
                for stokes_param in task.constants.stokes_params:
                    tags = [
                        VispTag.task(TaskName.polcal_as_science),
                        VispTag.intermediate(),
                        VispTag.frame(),
                        VispTag.stokes(stokes_param),
                        VispTag.cs_step(cs_step),
                        VispTag.cs_step_frame(cs_step_frame),
                    ]
                    assert len(list(task.read(tags=tags))) == 1
