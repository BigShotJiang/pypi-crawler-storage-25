"""Configuration for the dkist-processing-visp package and the logging thereof."""

from dkist_processing_common.config import DKISTProcessingCommonConfiguration
from pydantic import Field


class DKISTProcessingVISPConfigurations(DKISTProcessingCommonConfiguration):
    """Configurations custom to the dkist-processing-visp package."""

    fts_atlas_data_dir: str | None = Field(
        default=None, description="Common cached directory for downloaded FTS Atlas."
    )


dkist_processing_visp_configurations = DKISTProcessingVISPConfigurations()
dkist_processing_visp_configurations.log_configurations(log_parent_configurations=False)
