"""Models for the dataset extras."""

from dkist_processing_common.models.extras import DatasetExtraHeaderData
from dkist_processing_common.models.extras import DatasetExtraHeaderSection
from dkist_service_configuration.logging import logger
from pydantic import Field
from pydantic import field_validator
from pydantic_core.core_schema import ValidationInfo

DEFAULT_HEADER_SECTIONS = [
    DatasetExtraHeaderSection.common,
    DatasetExtraHeaderSection.iptask,
    DatasetExtraHeaderSection.gos,
    DatasetExtraHeaderSection.aggregate,
    DatasetExtraHeaderSection.visp,
]


class VispDatasetExtraHeaderData(DatasetExtraHeaderData):
    """Container validating information necessary to create a single dataset extra."""

    readout_exposure: float | list[float]
    total_exposure: float | list[float]
    data_tags: list[str | list[str]]
    header_sections: list[DatasetExtraHeaderSection] = DEFAULT_HEADER_SECTIONS
    filename: str = Field(default="")
    filename_detail: list[str] = Field(default=[])
    beam: int = 1
    modstate: int = 1

    @field_validator("readout_exposure", "total_exposure", mode="after")
    @classmethod
    def return_first_in_list_and_warn(
        cls, value: float | list[float], info: ValidationInfo
    ) -> float:
        """Return the first item of the list if the value is a list."""
        if isinstance(value, float):
            return value
        if len(value) > 1:
            logger.info(
                f"WARNING: Multiple {info.field_name} = {value} found for a {info.data["extra_name"]} "
                f"dataset extra. Using the first value for the header."
            )
        return value[0]
