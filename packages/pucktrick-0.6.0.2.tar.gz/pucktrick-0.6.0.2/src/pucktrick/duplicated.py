import pandas as pd
from pucktrick.base_injector import BaseErrorInjector
import random
import string

def _random_upper_lower(series):
    """Apply random upper/lower casing to each string in the Series."""
    return series.apply(lambda text: ''.join(
        [char.upper() if random.random() > 0.5 else char.lower() for char in text]
    ))

def _replace_punctuation(text):
    """Sostituisce ogni segno di punteggiatura (/, ., -) con uno degli altri due in maniera casuale, mantenendo lo stesso sostituto all'interno della stessa stringa."""
    replacements = {
        '/': random.choice(['-', '.']),
        '.': random.choice([',', '/']),
        '-': random.choice(['/', '.'])}
    return ''.join([replacements[char] if char in replacements else char for char in text])

def _remove_or_replace(text):
    """Rimuove o sostituisce un carattere casuale, sostituendo lettere con lettere e numeri con numeri."""
    if len(text) < 2:
        return text
    pos = random.randint(0, len(text) - 1)
    char = text[pos]

    if char.isdigit():
        if random.random() > 0.5:
            return text[:pos] + text[pos + 1:]
        else:
            random_digit = str(random.randint(0, 9))
            return text[:pos] + random_digit + text[pos + 1:]
    elif char.isalpha():
        if random.random() > 0.5:
            return text[:pos] + text[pos + 1:]
        else:
            random_letter = random.choice(string.ascii_letters)
            return text[:pos] + random_letter + text[pos + 1:]
    return text

def _abbreviate_text(text):
    """Abbrevia il testo mantenendo solo le prime lettere di ogni parola."""
    return ''.join([word[0] for word in text.split()])

def _shuffle_words(text):
    """Cambia l'ordine delle parole in una stringa, garantendo un ordine diverso dall'originale."""
    words = text.split()
    while True:
        random.shuffle(words)
        if words != text.split():
            break
    return ' '.join(words)

class DuplicateErrorInjector(BaseErrorInjector):
    """
    Injector that duplicates rows and optionally applies text transformations.
    """
    def __init__(self, strategy):
        super().__init__(strategy)
        self.function = self.strategy.get('function')

    def _get_modifiable_mask(self, filtered_target_df, prepared_original_df):
        """
        For duplicates, 'modifiable' rows are the original ones. 
        Rows that were added as duplicates in a previous 'extended' step 
        are considered 'already modified' and will not be drawn from again.
        """
        if self.mode == "new" or prepared_original_df is None:
            return pd.Series(True, index=filtered_target_df.index)
        
        # Since duplicated rows are appended, we identify the original rows by index.
        return filtered_target_df.index.isin(prepared_original_df.index)

    def apply_injection(self, df, indices):
        """
        Extracts rows to duplicate, applies transformations, and appends them
        to the dataframe it received.
        """
        sampled_rows = df.loc[indices].copy()
        # Preserve backward compatibility: checking both function and selection_criteria
        target_func = self.function or self.selection_criteria
        
        if target_func in [
            "class", "upper_lower", "replace_punctuation", 
            "remove_replace", "abbreviate_text", "shuffle_words"
        ]:
            for col in self.affected_features:
                if target_func == "shuffle_words":
                    sampled_rows[col] = sampled_rows[col].astype(str).apply(_shuffle_words)
                elif target_func == "abbreviate_text":
                    sampled_rows[col] = sampled_rows[col].astype(str).apply(_abbreviate_text)
                elif target_func == "replace_punctuation":
                    sampled_rows[col] = sampled_rows[col].astype(str).apply(_replace_punctuation)
                elif target_func == "remove_replace":
                    sampled_rows[col] = sampled_rows[col].astype(str).apply(_remove_or_replace)
                elif target_func == "upper_lower":
                    sampled_rows[col] = _random_upper_lower(sampled_rows[col])
                    
        return pd.concat([df, sampled_rows], ignore_index=True)

    def _finalize_data(self, noise_df):
        """
        For duplicates, the main work is done in apply_injection.
        This method just handles cleanup of temporary columns and date formatting.
        """
        final_df = noise_df # The df is already complete with appended rows.

        if self.is_affected_selected == 1 and self.puck_cols:
            final_df = final_df.drop(columns=[c for c in self.puck_cols if c in final_df.columns])
            if self.original1_df is not None:
                self.original1_df = self.original1_df.drop(
                    columns=[c for c in self.puck_cols if c in self.original1_df.columns]
                )

        # Date cleanup specific to duplicated logic
        if "date" in final_df.columns:
            final_df["date"] = final_df["date"].astype(str).str.replace(r"\s00:00:00$", "", regex=True)
            
        return final_df


def duplicate(train_df, strategy=None, original_df=None):
    """
    Main function to inject duplicated rows.
    Wraps the Object-Oriented implementation for backward compatibility.
    """
    injector = DuplicateErrorInjector(strategy)
    return injector.apply(train_df, original_df)
