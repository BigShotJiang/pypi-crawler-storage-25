from pucktrick.utils import *
from pucktrick.base_injector import BaseErrorInjector

class LabelErrorInjector(BaseErrorInjector):
    """
    Injector that flips labels for binary or multi-class classification tasks.
    """

    def __init__(self, strategy):
        super().__init__(strategy)
        self.target_col = self.affected_features[0] if self.affected_features else None
        
        parameters = self.perturbate_config.get("parameters", {})
        
        self.noise_model = (
            self.perturbate_config.get("noise_model") or
            parameters.get("model-name", "NCAR")
        )
        self.random_state = parameters.get("random_state", None)
        
        self.params = parameters
        

    def _get_modifiable_mask(self, filtered_target_df, prepared_original_df):
        """
        For labels, a row is considered 'already modified' if its label differs
        from the original dataframe's label.
        """
        if self.mode == "new" or prepared_original_df is None or self.target_col is None:
            return pd.Series(True, index=filtered_target_df.index)
        
        # A row is modifiable if its target value is the same as the original one.
        return filtered_target_df[self.target_col] == prepared_original_df.loc[filtered_target_df.index, self.target_col]

    def apply_injection(self, df, indices):
        
        if not self.target_col:
            return df

        unique_values = df[self.target_col].dropna().unique()
        if len(unique_values) <= 1:
            return df

        if len(unique_values) == 2:
            for i in indices:
                df.loc[i, self.target_col] = 1 - df.loc[i, self.target_col]
        else:
            full_df_context = self.original1_df if self.original1_df is not None else df

            # Per NAR con flip_distribution, bypassa la selezione della base class
            # e passa l'intero df con la percentage originale
            if self.noise_model == "NAR" and self.params.get("flip_distribution"):
                  
                    modified_subset = self._labelMulticlassNew(
                        df,                    # tutto il df, non il subset
                        self.target_col,
                        self.sampling,
                        self.percentage,       # percentage originale (0.5)
                        None,
                        self.params,
                        noise_model=self.noise_model,
                        random_state=self.random_state,
                        full_df_context=full_df_context
                    )
                    df.loc[modified_subset.index, self.target_col] = modified_subset[self.target_col]
            else:
                subset_to_modify = df.loc[indices]
                sub_percentage = len(indices) / len(df)  # corretto rispetto al df intero
                modified_subset = self._labelMulticlassNew(
                    subset_to_modify,
                    self.target_col,
                    self.sampling,
                    sub_percentage,
                    None,
                    self.params,
                    noise_model=self.noise_model,
                    random_state=self.random_state,
                    full_df_context=full_df_context
                )
                df.loc[modified_subset.index, self.target_col] = modified_subset[self.target_col]

        return df

    


    def _labelMulticlassNew(self, train_df, target, distribution, percentage, number, params, noise_model="uniform", random_state=None, full_df_context=None):
        """
        noise_model:
            - "uniform" / "distribution" 
            - "NCAR", "NAR", "NNAR" 
        """

        if full_df_context is None:
            full_df_context = train_df

        rng = np.random.RandomState(random_state) if random_state is not None else np.random
        noise_df = train_df.copy()
        unique_classes = train_df[target].unique()

        if noise_model in ("uniform", "distribution", "NCAR"):

            indices_pos = sample_indices(distribution, train_df, percentage, number, params)
            indices_to_modify = train_df.index[indices_pos]

            for i in indices_to_modify:
                current_class = noise_df.at[i, target]
                possible_classes = [c for c in unique_classes if c != current_class]

                if noise_model in ("NCAR", "uniform"):    
                    new_class = rng.choice(possible_classes)

                elif noise_model == "distribution":
                    # Calcola frequenze
                    value_counts = full_df_context[target].value_counts().to_dict()
                    # Estrae le frequenze solo delle possibili classi
                    freqs = np.array([value_counts.get(c, 0) for c in possible_classes], dtype=float)

                    # Se tutte le frequenze sono zero
                    if freqs.sum() == 0:
                        probs = np.ones_like(freqs) / len(freqs)
                    else:
                        probs = freqs / freqs.sum()

                    new_class = rng.choice(possible_classes, p=probs)

                noise_df.at[i, target] = new_class

            return noise_df

        return self._label_multiclass_models(
            train_df, target, distribution, percentage, number, params,
            noise_model=noise_model, rng=rng, full_df_context=full_df_context
        )

    def _label_multiclass_models(self, train_df, target, distribution, percentage, number, params, noise_model="", rng=None, full_df_context=None):
        if rng is None:
            rng = np.random
        if full_df_context is None:
            full_df_context = train_df

        noise_df = train_df.copy()
        y_series = train_df[target]
        classes = y_series.dropna().unique()
        K = len(classes)
        if K <= 1:
            return noise_df
       
        class_flip_probs = params.get("class_flip_probs", None)
        flip_distribution = params.get("flip_distribution", None)

        # --- selezione indici ---
        if noise_model == "NAR":
            if class_flip_probs:
                
                indices_to_modify = []
                total_rows = len(y_series)

                # numero totale di record da perturbare nel dataset
                n_total = int(total_rows * percentage)

                for cls_val, cls_prob in class_flip_probs.items():
                    cls_idx = np.where(y_series == cls_val)[0]
                    if len(cls_idx) == 0:
                        continue
                    # calcolo numero di record di questa classe da perturbare 
                    n_cls = int(n_total * cls_prob)
                    if n_cls <= 0:
                        continue

                    # selezione casuale tra gli indici della classe
                    sel_idx = rng.choice(cls_idx, size=min(n_cls, len(cls_idx)), replace=False)
                    indices_to_modify.extend(sel_idx.tolist())

                indices_to_modify = np.array(indices_to_modify, dtype=int)
                pass
            elif flip_distribution:
                indices_to_modify = []
                cls_type = type(y_series.iloc[0])
                for cls_str in flip_distribution.keys():
                    cls_val = cls_type(cls_str)
                    cls_idx = np.where(y_series == cls_val)[0]
                    if len(cls_idx) == 0:
                        continue
                    n_cls = int(len(cls_idx) * percentage)
                    if n_cls <= 0:
                        continue
                    sel = rng.choice(cls_idx, size=min(n_cls, len(cls_idx)), replace=False)
                    indices_to_modify.extend(sel.tolist())
                indices_to_modify = np.array(indices_to_modify, dtype=int)
            else:
                indices_to_modify = sample_indices(distribution, train_df, percentage, number, params)

        elif noise_model == "NNAR":
        # --- Scelta delle feature da usare per la similarità ---
            features = params.get("features_for_similarity", None)
            if features is None:
                # uso solo feature numeriche
                features = train_df.select_dtypes(include=[np.number]).columns.tolist()
            else:
                # tengo solo le feature numeriche tra quelle indicate
                features = [f for f in features if f in train_df.columns and pd.api.types.is_numeric_dtype(train_df[f])]

            # se non ci sono feature valide → fallback casuale
            if not features:
                indices_to_modify = sample_indices(distribution, train_df, percentage, number, params)
            else:
                X_raw = full_df_context[features].fillna(full_df_context[features].mean())
                X = StandardScaler().fit_transform(X_raw)

                # --- Calcolo centroidi per classe ---
                centroids = {}
                for cls in classes:
                    sub = train_df[train_df[target] == cls]
                    if sub.empty:
                        continue
                    centroids[cls] = np.nanmean(X[sub.index], axis=0)

                # Se mancano centroidi validi → fallback casuale
                if len(centroids) < 2:
                    indices_to_modify = sample_indices(distribution, train_df, percentage, number, params)
                else:
                    # --- Calcolo delle distanze di ciascun record dai centroidi ---
                    
                    # dists = np.array([
                    #     [np.linalg.norm(x - centroids[cls]) if cls in centroids else np.inf for cls in classes]
                    #     for x in X
                    # ])

                    centroids_matrix = np.vstack([centroids[cls] for cls in classes if cls in centroids])

                    # Calcolo tutte le distanze in una volta (N x K)
                    dists = cdist(X, centroids_matrix, metric='euclidean')

                    # Ordinamento e margine (distanza tra prima e seconda classe più vicina)
                    sorted_idx = np.argsort(dists, axis=1)
                    margin = dists[np.arange(len(X)), sorted_idx[:, 1]] - dists[np.arange(len(X)), sorted_idx[:, 0]]
                    margin = np.maximum(0.0, margin)
                    margin_norm = margin / margin.max() if margin.max() > 0 else margin

                    flip_probs = 1.0 - margin_norm

                    # --- Selezione dei record più ambigui ---
                    n_target = int(len(flip_probs) * percentage)
                    if n_target > 0:

                        indices_to_modify = np.argpartition(flip_probs, -n_target)[-n_target:]
                    else:
                        indices_to_modify = np.array([], dtype=int)

        # --- applicazione del flip ---
        indices_to_modify_labels = train_df.index[indices_to_modify]
        for i in indices_to_modify_labels:
            current_class = noise_df.at[i, target]
            possible_classes = [c for c in classes if c != current_class]

            if noise_model == "NAR":
                cls_type = type(current_class)
                current_class_str = str(current_class)
                if flip_distribution and current_class_str in flip_distribution:
                    dist = flip_distribution[current_class_str]
                    possible_classes = [cls_type(c) for c in dist.keys() 
                                        if str(c) != current_class_str]
                    probs = np.array([dist[str(c)] for c in possible_classes], 
                                    dtype=float)
                    if probs.sum() > 0:
                        probs /= probs.sum()
                    else:
                        probs = None
                    new_class = (rng.choice(possible_classes, p=probs) 
                                if probs is not None 
                                else rng.choice(possible_classes))
                else:
                    new_class = rng.choice(possible_classes)
            # if noise_model == "NAR":

            #     if flip_distribution and current_class in flip_distribution:
            #         dist = flip_distribution[current_class]  # dict {classe_destinazione: peso}
            #         # escludo la classe corrente dalla scelta (diagonale = 0)
            #         possible_classes = [c for c in dist.keys() if c != current_class]
            #         probs = np.array([dist[c] for c in possible_classes], dtype=float)
                    
            #         # normalizzo per somma 1
            #         if probs.sum() > 0:
            #             probs /= probs.sum()
            #         else:
            #             probs = None  # fallback se tutti zero

            #         # scelta secondo le probabilità
            #         new_class = rng.choice(possible_classes, p=probs) if probs is not None else rng.choice(possible_classes)
            #     else:
            #         # fallback casuale uniforme se non ho flip_distribution
            #         new_class = rng.choice(possible_classes)

            elif noise_model == "NNAR":
                
                if params.get("features_for_similarity"):
                    x = (
                            noise_df.loc[i, params["features_for_similarity"]]
                            .infer_objects(copy=False) 
                            .fillna(0)
                            .astype(float)
                            .values
                        )
                    d = [np.linalg.norm(x - centroids[cls]) for cls in classes]
                    d = np.array([val if cls != current_class else np.inf for val, cls in zip(d, classes)])
                    probs = np.exp(-d)
                    probs = probs / probs.sum() if probs.sum() > 0 else None
                    new_class = rng.choice(classes, p=probs) if probs is not None else rng.choice(possible_classes)
                else:
                    new_class = rng.choice(possible_classes)
            else:
                new_class = rng.choice(possible_classes)

            noise_df.at[i, target] = new_class

        return noise_df




def labels(train_df, strategy, original_df=None):
    """
    Main function to inject label noise.
    Wraps the Object-Oriented implementation for backward compatibility.
    """
   
    injector = LabelErrorInjector(strategy)
    error, final_df = injector.apply(train_df, original_df)

    # Ensure integer columns remain integer after manipulation
    for col in final_df.select_dtypes(include=['int64']).columns:
        final_df[col] = final_df[col].astype('Int64')

    return error, final_df
