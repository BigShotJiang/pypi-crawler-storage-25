import unittest
from pucktrick.utils import *
from sklearn.preprocessing import StandardScaler
import pandas as pd
import numpy as np
from pandas.testing import assert_frame_equal
import random
import json
from datetime import timedelta
from dateutil import parser
import string
import re
from collections import Counter
from scipy.spatial.distance import cdist


def create_df_fake(type = 'binary', num_rows=1000, num_classes=0):
    f1 = np.random.uniform(-100, 100, num_rows)  # Continuous values between -100 and 100
    f2 = np.random.randint(-100, 101, num_rows)  # Discrete values between -100 and 100
    f3 = np.random.choice(['apple', 'banana', 'cherry'], num_rows)  # String values
    f4 = np.random.choice(['apple', 'banana', 'cherry'], num_rows)  # String values
    f5 = np.random.choice([0, 1,2,3,4,5], num_rows)  
    delta_days = (pd.to_datetime('2030-12-31') - pd.to_datetime('1970-01-01')).days
    random_days = np.random.randint(0, delta_days, num_rows)
    random_dates = pd.to_datetime('1970-01-01') + pd.to_timedelta(random_days, unit='D')
    date = random_dates

    if type == 'binary':
        target = np.random.choice([0, 1], num_rows)  
    if type == 'multiclass':
        target = np.random.choice(range(num_classes), num_rows)

    # Create the DataFrame
    df = pd.DataFrame({
        'f1': f1,
        'f2': f2,
        'f3': f3,
        'f4': f4,
        'f5': f5,
        'date' : date,
        'target': target
    })
    df['date'] = pd.to_datetime(df['date'])
    
    return df


def create_fake_table(num_rows=1000):
  type = 'binary'
  return create_df_fake(type, num_rows)


def create_fake_table_multiclass(num_rows=1000, num_classes=3):
    type = 'multiclass'
    return create_df_fake(type, num_rows, num_classes)
  



def sample_indices(sampling, data_length, percentage=None, number=None, params=None):
        if percentage is None:
            num_samples = number
        elif number is None:
         num_samples = int(len(data_length) * percentage)  # use data_length directly

        params = params or {}
        #print(percentage)

        if sampling== "random":
            # Change: use len(data_length) to get the size for random sampling
            return np.random.choice(len(data_length), num_samples, replace=False)

        elif sampling == "uniform":
            min_val = params.get("min", 0)
            max_val = params.get("max", len(data_length) - 1)  # data_length
            return np.random.uniform(min_val, max_val, num_samples).astype(int)

        elif sampling== "normal":
            mu = params.get("mu", len(data_length) / 2)  # data_length
            sigma = params.get("sigma", len(data_length) / 6)  # data_length
            samples = np.random.normal(mu, sigma, num_samples)
            samples = np.clip(samples, 0, len(data_length) - 1)  # data_length
            return samples.astype(int)

        elif sampling == "exponential":
            lambd = params.get("lambda", 1.0)
            samples = np.random.exponential(1 / lambd, num_samples)
            samples = (samples / np.max(samples)) * (len(data_length) - 1)  # data_length
            return samples.astype(int)

        else:
            raise ValueError(f"Sampling technique '{sampling}' not support.")



def affectedSelected(affected_features,selection_criteria):
        affectedSelected=r'\b('+"|".join(map(re.escape,affected_features))+r')\b'
        found=re.findall(affectedSelected,selection_criteria)
        if found:
            modified=re.sub(affectedSelected,r'puck_\1',selection_criteria)
            return modified,1
        else:
            return selection_criteria,0



# Funzione che modifica la distribuzione delle classi in un dataset multiclasse,
# rendendolo sbilanciato in base a dei rapporti specificati (target_ratios).

def introduce_multiclass_imbalance(X, y, target_ratios):

    X_new, y_new = [], []
    for c in np.unique(y):
        mask = y == c
        X_c, y_c = X[mask], y[mask]
        keep_n = int(len(X_c) * target_ratios.get(c, 1.0))
        idx = np.random.choice(len(X_c), size=keep_n, replace=False)
        X_new.append(X_c[idx])
        y_new.append(y_c[idx])
    return np.vstack(X_new), np.hstack(y_new)  # ritorna feature e target filtrati secondo i rapporti specificati.
