import pandas as pd
from abc import ABC, abstractmethod
from pucktrick.utils import affectedSelected, sample_indices

class BaseErrorInjector(ABC):
    """
    Base class for all error injectors implementing the Template Method pattern.
    Handles configuration parsing, data filtering, calculating target rows,
    sampling, and finalizing the data. Subclasses provide the actual injection logic.
    """
    def __init__(self, strategy):
        self.strategy = strategy or {}
        
        # Extract basic configurations
        affected = self.strategy.get("affected_features", [])
        self.affected_features = affected if isinstance(affected, list) else [affected]
        self.selection_criteria = self.strategy.get("selection_criteria", "all")
        self.percentage = self.strategy.get("percentage", 0.0)
        self.mode = self.strategy.get("mode", "new")
        
        # Extract perturbate_data configurations
        self.perturbate_config = self.strategy.get("perturbate_data", {})
        self.sampling = self.perturbate_config.get("sampling", "random")
        self.distribution = self.perturbate_config.get("distribution")
        self.params = self.perturbate_config.get("param", {})
        self.value = self.perturbate_config.get("value", [])
        self.condition_logic = self.perturbate_config.get("condition_logic", None)

        # Internal state variables
        self.is_affected_selected = 0
        self.original1_df = None
        self.puck_cols = []

    def _prepare_data(self, train_df, original_df):
        """
        Prepares the data by applying the selection criteria and handling the 'extended' mode.
        It manages the creation of 'puck_' prefixed columns if necessary.
        """
        train_df = train_df.copy()
        if original_df is not None:
            original_df = original_df.copy()

        if self.selection_criteria == 'all':
            if original_df is None:
                original_df = train_df.copy()
            self.original1_df = original_df.copy()
        else:
            if self.mode == "extended":
                self.selection_criteria, self.is_affected_selected = affectedSelected(
                    self.affected_features, self.selection_criteria
                )
            else:
                self.is_affected_selected = 0 
            
            # Add 'puck_' prefix if the selection criteria contains affected features
            if self.is_affected_selected == 1:
                if original_df is not None:
                    df_pref2 = original_df[self.affected_features].add_prefix("puck_")
                    original_df = pd.concat([original_df, df_pref2], axis=1)
                    train_df = pd.concat([train_df, df_pref2], axis=1)
                    self.puck_cols = df_pref2.columns.tolist()
            
            if original_df is None:
                self.original1_df = train_df.copy()
                original_df = train_df.query(self.selection_criteria).copy()         
            else:
                self.original1_df = original_df.copy()
                original_df = original_df.query(self.selection_criteria).copy()
            
            # Filter the target dataframe by the selection criteria
            train_df = train_df.query(self.selection_criteria).copy()

        return train_df, original_df

    def _filter_by_values(self, target_df):
        """
        Filters the dataframe based on the 'value' and 'condition_logic' parameters
        defined in the strategy JSON.
        """
        if not self.value and self.value is not None:
            return target_df

        # Normalize the values list to match the length of affected_features
        values = self.value if isinstance(self.value, list) else [self.value] * len(self.affected_features)
        if len(values) < len(self.affected_features):
            values.extend([None] * (len(self.affected_features) - len(values)))

        filters = []
        for col, val in zip(self.affected_features, values):
            if val is not None:
                filters.append(target_df[col] == val)
            else:
                filters.append(pd.Series(True, index=target_df.index))

        if not filters:
            return target_df

        # Combine filters based on condition logic (AND/OR)
        combined_filter = filters[0]
        for f in filters[1:]:
            if self.condition_logic == "or":
                combined_filter |= f
            else:
                # Default logic is 'and'
                combined_filter &= f

        return target_df[combined_filter]

    def _get_modifiable_mask(self, filtered_target_df, prepared_original_df):
        """
        Identifies which rows are modifiable. 
        By default, it assumes rows that differ from the original dataframe are already modified.
        Subclasses should override this if they have specific criteria (e.g., missing values).
        """
        if self.mode == "new" or prepared_original_df is None:
            return pd.Series(True, index=filtered_target_df.index)
        
        # Default check: rows where affected features do not differ from original
        already_modified = filtered_target_df[self.affected_features].ne(
            prepared_original_df.loc[filtered_target_df.index, self.affected_features]
        ).any(axis=1)
        
        return ~already_modified

    def _finalize_data(self, noise_df):
        """
        Removes temporary columns and merges the modified subset back into the main dataframe.
        """
        if self.is_affected_selected == 1 and self.puck_cols:
            # Remove prefixed columns created for the selection criteria
            noise_df = noise_df.drop(columns=[c for c in self.puck_cols if c in noise_df.columns])
            if self.original1_df is not None:
                self.original1_df = self.original1_df.drop(
                    columns=[c for c in self.puck_cols if c in self.original1_df.columns]
                )
        
        if self.original1_df is not None:
            self.original1_df.loc[noise_df.index, noise_df.columns] = noise_df
            return self.original1_df
        
        return noise_df

    @abstractmethod
    def apply_injection(self, df, indices):
        """
        Applies the specific error injection to the provided indices.
        MUST be implemented by subclasses.
        
        :param df: The dataframe to modify (subset).
        :param indices: The selected row indices to perturb.
        :return: The modified dataframe.
        """
        pass

    def apply(self, train_df, original_df=None):
        """
        Orchestrates the error injection pipeline using the Template Method pattern.
        """
        # 1. Prepare data (Selection Criteria, Mode logic, Prefixing)
        prepared_train_df, prepared_original_df = self._prepare_data(train_df, original_df)
        
        target_df = prepared_train_df

        # 2. Filter based on specific values and condition logic
        filtered_target_df = self._filter_by_values(target_df)
        
        # 3. Calculate the total number of rows that should be changed
        if self.mode == "extended" and prepared_original_df is not None:
            filtered_original_df = self._filter_by_values(prepared_original_df)
            total_target_rows = len(filtered_original_df)
        else:
            total_target_rows = len(filtered_target_df)
            
        total_rows_to_change = int(round(total_target_rows * self.percentage))
        
        # 4. Find modifiable rows within the filtered target dataframe
        modifiable_mask = self._get_modifiable_mask(filtered_target_df, prepared_original_df)
        modifiable_df = filtered_target_df[modifiable_mask]
        
        # 5. Determine how many rows are left to change
        if self.mode == "extended":
            already_modified_count = len(filtered_target_df) - len(modifiable_df)
            rows_to_change = total_rows_to_change - already_modified_count
        else:
            rows_to_change = total_rows_to_change

        if rows_to_change <= 0 or len(modifiable_df) == 0:
            # Return immediately if no rows need to be changed or no modifiable rows exist
            return 1, train_df
        
        # 6. Sample indices using the underlying utility function
        sampled_indices_positions = sample_indices(
            sampling=self.sampling, 
            data_length=modifiable_df, 
            percentage=None, 
            number=rows_to_change, 
            params=self.params
        )
        sampled_indices = modifiable_df.iloc[sampled_indices_positions].index
        
        # 7. Inject error using subclass logic
        noise_df = target_df.copy()
        noise_df = self.apply_injection(noise_df, sampled_indices)
        
        # 8. Finalize and merge into original dataset shape
        final_df = self._finalize_data(noise_df)
        
        return 0, final_df