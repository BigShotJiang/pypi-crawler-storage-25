from pucktrick.utils import *
from pucktrick.base_injector import BaseErrorInjector
import random

#modificare quando il selection criteria è uguale alla colonna

def is_int_categorical(series: pd.Series, max_unique: int = 10,
                       max_domain_size: int = 20,
                       max_unique_ratio: float = 0.05,
                       require_nonnegative: bool = True) -> bool:
    """
    Heuristic: decide if an integer-typed column is actually categorical (coded as ints).
    """
    if not pd.api.types.is_integer_dtype(series):
        return False
    
    s = series.dropna()
    if s.empty:
        return False
    
    nunq = s.nunique()
    if nunq <= max_unique:
        return True
    
    if nunq <= max_domain_size and nunq / len(s) <= max_unique_ratio:
        return True
    
    vals = np.sort(s.unique())
    if require_nonnegative and vals[0] < 0:
        return False
    
    # consecutive small domain?
    if len(vals) <= max_domain_size and np.all(np.diff(vals) == 1):
        return True
    
    return False

class OutlierErrorInjector(BaseErrorInjector):
    """
    Injector that introduces outlier values into specified features.
    The outlier generation logic depends on the data type of the feature.
    """

    def apply_injection(self, df, indices):
        """
        Applies outlier injection based on the data type of each affected feature.
        """
        source_df = self.original1_df if self.original1_df is not None else df
        
        for feature in self.affected_features:
            if pd.api.types.is_string_dtype(df[feature]) or isinstance(df[feature].dtype, pd.CategoricalDtype):
                df.loc[indices, feature] = "puck was here"

            elif pd.api.types.is_integer_dtype(df[feature]):
                if is_int_categorical(source_df[feature]):
                    # For categorical integers, create a new category
                    current_max = source_df[feature].max(skipna=True)
                    outlier_val = current_max + 1 if pd.notna(current_max) else 1
                    df.loc[indices, feature] = outlier_val
                else:
                    # For numerical integers, use 3-sigma rule
                    mean = source_df[feature].mean()
                    std_dev = source_df[feature].std()
                    upper_bound = mean + 3 * std_dev
                    lower_bound = mean - 3 * std_dev
                    new_upper = mean + 4 * std_dev
                    new_lower = mean - 4 * std_dev
                    for i in indices:
                        if random.random() > 0.5:
                            df.loc[i, feature] = random.randint(int(upper_bound), int(new_upper))
                        else:
                            df.loc[i, feature] = random.randint(int(new_lower), int(lower_bound))

            elif pd.api.types.is_float_dtype(df[feature]):
                mean = source_df[feature].mean()
                std_dev = source_df[feature].std()
                upper_bound = mean + 3 * std_dev
                lower_bound = mean - 3 * std_dev
                new_upper = mean + 4 * std_dev
                new_lower = mean - 4 * std_dev
                for i in indices:
                    if random.random() > 0.5:
                        df.loc[i, feature] = np.random.uniform(upper_bound, new_upper)
                    else:
                        df.loc[i, feature] = np.random.uniform(new_lower, mean - 3 * std_dev)

            elif pd.api.types.is_datetime64_any_dtype(df[feature]):
                # For dates, introduce a random date within the existing range (acting as a random error)
                valid_dates = source_df[feature].dropna()
                if valid_dates.empty:
                    continue
                min_date = valid_dates.min()
                max_date = valid_dates.max()
                for i in indices:
                    if min_date < max_date:
                        random_days = random.randint(0, (max_date - min_date).days)
                        df.loc[i, feature] = min_date + timedelta(days=random_days)
            else:
                raise ValueError(f"Unsupported column type for feature '{feature}'.")
        return df

def outlier(train_df, strategy, original_df=None):
    """
    Main function to inject outliers into a dataframe.
    Wraps the Object-Oriented implementation for backward compatibility.
    """
    injector = OutlierErrorInjector(strategy)
    return injector.apply(train_df, original_df)
