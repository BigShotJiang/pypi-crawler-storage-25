from pucktrick.utils import *
from pucktrick.base_injector import BaseErrorInjector
import random
from datetime import timedelta

class NoiseErrorInjector(BaseErrorInjector):
    """
    Injector that adds random noise to specified features.
    It supports different data types and noise distributions.
    """
    def __init__(self, strategy):
        super().__init__(strategy)
        # Shift-specific parameters
        self.shift_value = self.params.get("shift_value", 0.0)
        self.shift_unit = self.params.get("shift_unit", "absolute")
        self.shift_sign = self.params.get("shift_sign", "positive")

    def apply_injection(self, df, indices):
        """
        Applies noise based on the data type of each affected feature.
        """
        # Use original1_df as the source for distributions if available, otherwise use the input df
        source_df = self.original1_df if self.original1_df is not None else df

        for feature in self.affected_features:
            if pd.api.types.is_string_dtype(df[feature]) or isinstance(df[feature].dtype, pd.CategoricalDtype):
                unique_values = source_df[feature].dropna().unique()
                for idx in indices:
                    if len(unique_values) <= 1:
                        # Fallback to a random string if no other unique values exist
                        df.loc[idx, feature] = ''.join(np.random.choice(list('abcdefghijklmnopqrstuvwxyz'), size=5))
                    else:
                        current_value = df.loc[idx, feature]
                        possible_values = [v for v in unique_values if v != current_value]
                        if possible_values:
                            df.loc[idx, feature] = np.random.choice(possible_values)

            elif pd.api.types.is_numeric_dtype(df[feature]):
                if self.distribution == "shift":
                    delta = self.shift_value
                    if self.shift_unit == "std":
                        delta *= source_df[feature].std()
                    
                    if self.shift_sign == "negative":
                        delta = -delta
                    elif self.shift_sign == "random":
                        delta *= np.random.choice([-1, 1])
                    
                    # Apply shift vectorized
                    df.loc[indices, feature] += delta
                else:  # uniform or normal
                    min_val = source_df[feature].min()
                    max_val = source_df[feature].max()
                    for idx in indices:
                        if pd.api.types.is_integer_dtype(df[feature]):
                            new_value = random.randint(min_val, max_val)
                        else:
                            new_value = random.uniform(min_val, max_val)
                        df.loc[idx, feature] = new_value

            elif pd.api.types.is_datetime64_any_dtype(df[feature]):
                if self.distribution == "shift":
                    delta = timedelta(days=self.shift_value)
                    if self.shift_sign == "negative":
                        delta = -delta
                    elif self.shift_sign == "random":
                        delta *= np.random.choice([-1, 1])
                    
                    df.loc[indices, feature] += delta
                else:
                    valid_dates = source_df[feature].dropna()
                    if valid_dates.empty:
                        continue
                    min_date = valid_dates.min()
                    max_date = valid_dates.max()
                    for idx in indices:
                        if min_date < max_date:
                            random_days = random.randint(0, (max_date - min_date).days)
                            df.loc[idx, feature] = min_date + timedelta(days=random_days)

            else:
                raise ValueError(f"Unsupported column type for feature '{feature}'.")
        
        return df


def noise(train_df, strategy, original_df=None):
    """
    Main function to inject noise into a dataframe.
    Wraps the Object-Oriented implementation for backward compatibility.
    """
    injector = NoiseErrorInjector(strategy)
    return injector.apply(train_df, original_df)
