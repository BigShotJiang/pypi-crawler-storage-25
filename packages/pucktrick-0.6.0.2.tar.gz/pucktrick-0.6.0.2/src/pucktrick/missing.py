import numpy as np
import pandas as pd
from pucktrick.base_injector import BaseErrorInjector

class MissingErrorInjector(BaseErrorInjector):
    """
    Injector that introduces missing values (NaN) into the specified features.
    """
    
    def _get_modifiable_mask(self, filtered_target_df, prepared_original_df):
        """
        Overrides the default modifiable mask. 
        For missing values, a row is considered 'already modified' if 
        ALL affected features are already NaN.
        """
        if self.mode == "new":
            return pd.Series(True, index=filtered_target_df.index)
        
        # Returns True for rows that are NOT completely NaN in the affected features
        return ~filtered_target_df[self.affected_features].isnull().all(axis=1)

    def apply_injection(self, df, indices):
        """
        Injects NaN values into the selected indices for all affected features.
        """
        for col in self.affected_features:
            df.loc[indices, col] = np.nan
        return df


def missing(train_df, strategy=None, original_df=None):
    """
    Main function to inject missing values.
    It wraps the Object-Oriented implementation to maintain backward compatibility.
    
    :param train_df: The dataframe to modify.
    :param strategy: Dictionary containing injection configuration.
    :param original_df: The original dataframe used in 'extended' mode.
    :return: Tuple (error_code, modified_dataframe)
    """
    injector = MissingErrorInjector(strategy)
    return injector.apply(train_df, original_df)