import sys
from pathlib import Path
import unittest
import pandas as pd
import numpy as np
from datetime import timedelta

# Add ../src to PYTHONPATH
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from pucktrick.noisy import noise
from pucktrick.utils import create_fake_table 

class TestNoiseFunction(unittest.TestCase):

    def setUp(self):
        """
        Setup a controlled DataFrame to ensure predictable 
        results during systematic shift calculations.
        """
        self.num_rows = 10
        self.fake_df = pd.DataFrame({
            'num_val': [10.0, 20.0, 30.0, 40.0, 50.0] * 2, # Mean: 30, Std: ~15.81
            'date_val': pd.to_datetime(['2023-01-01'] * 10),
            'cat_val': ['apple'] * 5 + ['orange'] * 5
        })

    def test_systematic_shift_absolute(self):
        """
        Test systematic shift using an absolute numerical value (positive sign).
        Verify that: new_value = old_value + shift_value
        """
        column = ['num_val']
        shift_val = 5.0
        strategy = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': 1.0, # Apply to 100% for precise checking
            'mode': 'new',
            'perturbate_data': {
                'sampling': 'random',
                'distribution': 'shift',
                'param': {
                    'shift_value': shift_val,
                    'shift_unit': 'absolute',
                    'shift_sign': 'positive'
                }
            }
        }
        
        error, noise_df = noise(self.fake_df.copy(), strategy)
        
        self.assertEqual(error, 0)
        for idx in self.fake_df.index:
            expected = self.fake_df.loc[idx, 'num_val'] + shift_val
            actual = noise_df.loc[idx, 'num_val']
            self.assertEqual(actual, expected, f"Absolute shift mismatch at index {idx}")

    def test_systematic_shift_std(self):
        """
        Test systematic shift based on Standard Deviation units (negative sign).
        Verify that: new_value = old_value - (multiplier * std)
        """
        column = ['num_val']
        shift_multiplier = 1.5
        std_original = self.fake_df['num_val'].std()
        
        strategy = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': 1.0,
            'mode': 'new',
            'perturbate_data': {
                'sampling': 'random',
                'distribution': 'shift',
                'param': {
                    'shift_value': shift_multiplier,
                    'shift_unit': 'std',
                    'shift_sign': 'negative'
                }
            }
        }
        
        error, noise_df = noise(self.fake_df.copy(), strategy)
        
        expected_delta = shift_multiplier * std_original
        
        self.assertEqual(error, 0)
        for idx in self.fake_df.index:
            expected = self.fake_df.loc[idx, 'num_val'] - expected_delta
            actual = noise_df.loc[idx, 'num_val']
            # Use almostEqual for floating point precision
            self.assertAlmostEqual(actual, expected, places=5)

    def test_date_systematic_shift(self):
        """
        Test systematic shift on datetime features.
        Verify that days are correctly added to the original timestamp.
        """
        column = ['date_val']
        days_to_shift = 15
        strategy = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': 1.0,
            'mode': 'new',
            'perturbate_data': {
                'sampling': 'random',
                'distribution': 'shift',
                'param': {
                    'shift_value': days_to_shift,
                    'shift_sign': 'positive'
                }
            }
        }
        
        error, noise_df = noise(self.fake_df.copy(), strategy)
        
        expected_date = self.fake_df.loc[0, 'date_val'] + timedelta(days=days_to_shift)
        self.assertEqual(error, 0)
        self.assertEqual(noise_df.loc[0, 'date_val'], expected_date)

    def test_extended_mode_random_noise(self):
        """
        Regression test for the 'extended' mode with random distribution.
        Verify that noise is added to the existing noisy dataframe 
        up to the new desired percentage.
        """
        fake_df = create_fake_table(20)
        column = ['f3']
        
        # Step 1: Initial noise (50%)
        strategy1 = {'affected_features': column, 'selection_criteria': 'all', 'percentage': 0.5, 'mode': 'new', 'perturbate_data': {'sampling': 'random', 'distribution': 'random'}}
        _, noise_df = noise(fake_df.copy(), strategy1)
        
        # Step 2: Extended noise (target 80%)
        strategy2 = {'affected_features': column, 'selection_criteria': 'all', 'percentage': 0.8, 'mode': 'extended', 'perturbate_data': {'sampling': 'random', 'distribution': 'random'}}
        error, noise_final_df = noise(noise_df, strategy2, original_df=fake_df)
        
        # Verify changes compared to original
        diff_count = (fake_df[column] != noise_final_df[column]).sum().sum()
        actual_percentage = diff_count / len(fake_df)
        
        self.assertEqual(error, 0)
        # Check if actual percentage is close to 80%
        self.assertAlmostEqual(actual_percentage, 0.8, delta=0.15)

if __name__ == "__main__":
    unittest.main()