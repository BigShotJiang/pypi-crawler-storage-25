import sys
from pathlib import Path
import unittest
import pandas as pd
import numpy as np

# Add ../src to PYTHONPATH
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from pucktrick.missing import missing
from pucktrick.utils import create_fake_table 

class TestMissingFunction(unittest.TestCase):

    def setUp(self):
        """
        Setup a fresh fake dataframe before each test to ensure isolation.
        """
        self.num_rows = 100
        self.fake_df = create_fake_table(self.num_rows)

    def test_missing_new_mode(self):
        """
        Test injecting missing values in 'new' mode.
        Expects exactly the specified percentage of NaNs in the target column.
        """
        percentage = 0.5
        strategy = {
            "affected_features": ["f1"],
            "selection_criteria": "all",
            "percentage": percentage,
            "mode": "new",
            "perturbate_data": {
                "sampling": "random",
                "distribution": "random"
            }
        }
        
        error, noise_df = missing(self.fake_df.copy(), strategy)
        
        self.assertEqual(error, 0)
        
        # Verify that exactly 50% of the rows are NaN
        expected_nans = int(self.num_rows * percentage)
        actual_nans = noise_df["f1"].isnull().sum()
        self.assertEqual(actual_nans, expected_nans)

    def test_missing_extended_mode(self):
        """
        Test injecting missing values in 'extended' mode.
        Expects the total amount of NaNs to reach the new percentage, 
        building upon the already modified dataframe.
        """
        # 1. First injection: 20% missing
        strategy_new = {
            "affected_features": ["f1"],
            "selection_criteria": "all",
            "percentage": 0.2,
            "mode": "new",
            "perturbate_data": {"sampling": "random", "distribution": "random"}
        }
        _, noise_df = missing(self.fake_df.copy(), strategy_new)

        # Record the indices that were modified in the first pass
        missing_indices_new = noise_df[noise_df["f1"].isnull()].index
        self.assertEqual(len(missing_indices_new), int(self.num_rows * 0.2))
        
        # 2. Extended injection: increase to 60% missing
        strategy_extended = {
            "affected_features": ["f1"],
            "selection_criteria": "all",
            "percentage": 0.6,
            "mode": "extended",
            "perturbate_data": {"sampling": "random", "distribution": "random"}
        }
        error, noise_ext_df = missing(noise_df, strategy_extended, original_df=self.fake_df)
        
        self.assertEqual(error, 0)
        
        expected_nans = int(self.num_rows * 0.6)
        actual_nans = noise_ext_df["f1"].isnull().sum()
        self.assertEqual(actual_nans, expected_nans)
        
        # Verify that the originally missing rows are still missing in the extended dataframe
        self.assertTrue(noise_ext_df.loc[missing_indices_new, "f1"].isnull().all())

if __name__ == "__main__":
    unittest.main()