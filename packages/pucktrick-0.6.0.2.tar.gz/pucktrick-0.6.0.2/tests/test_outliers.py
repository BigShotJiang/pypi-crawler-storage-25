import sys
from pathlib import Path

# aggiunge ../src al PYTHONPATH
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

import unittest
from pucktrick.outliers import *
from pucktrick.utils import *
import pandas as pd
import numpy as np
from pandas.testing import assert_frame_equal
  
class TestOutlierFunction(unittest.TestCase):

    def setUp(self):
        """Setup a fresh fake dataframe before each test."""
        self.num_rows = 100
        self.fake_df = create_fake_table(self.num_rows)

    def test_outlier_new_mode(self):
        """Test injecting outliers in 'new' mode on a string column."""
        percentage = 0.3
        column = ['f3']
        strategy = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': percentage,
            'mode': 'new',
            'perturbate_data': {'sampling': 'random', 'distribution': 'random'}
        }
        
        error, noise_df = outlier(self.fake_df.copy(), strategy)
        
        self.assertEqual(error, 0)
        
        # Verify that the correct number of outliers were injected
        expected_outliers = int(self.num_rows * percentage)
        actual_outliers = (noise_df[column[0]] == "puck was here").sum()
        self.assertEqual(actual_outliers, expected_outliers)

    def test_outlier_extended_mode(self):
        """Test injecting outliers in 'extended' mode on a numeric column."""
        column = ['f1']
        
        # Step 1: Initial injection (20%)
        strategy_new = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': 0.2,
            'mode': 'new',
            'perturbate_data': {'sampling': 'random', 'distribution': 'random'}
        }
        _, noise_df = outlier(self.fake_df.copy(), strategy_new)

        # Record which rows were modified and verify they are outliers
        original_mean = self.fake_df[column[0]].mean()
        original_std = self.fake_df[column[0]].std()
        upper_bound = original_mean + 3 * original_std
        lower_bound = original_mean - 3 * original_std

        modified_mask_new = self.fake_df[column[0]] != noise_df[column[0]]
        modified_indices_new = self.fake_df[modified_mask_new].index

        # Step 2: Extended injection (target 60%)
        strategy_extended = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': 0.6,
            'mode': 'extended',
            'perturbate_data': {'sampling': 'random', 'distribution': 'random'}
        }
        error, final_df = outlier(noise_df, strategy_extended, original_df=self.fake_df)
        
        self.assertEqual(error, 0)

        # Verify the final number of modified rows
        modified_mask_final = self.fake_df[column[0]] != final_df[column[0]]
        diff_count = modified_mask_final.sum()
        expected_changes = int(self.num_rows * 0.6)
        self.assertEqual(diff_count, expected_changes)

        # Verify that the original outliers are still outliers
        self.assertTrue(modified_mask_final.loc[modified_indices_new].all())

        # Verify that all modified values are indeed outliers
        outlier_values = final_df.loc[modified_mask_final, column[0]]
        self.assertTrue(((outlier_values > upper_bound) | (outlier_values < lower_bound)).all())

if __name__ == "__main__":
    unittest.main()
