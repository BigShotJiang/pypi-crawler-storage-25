import sys
from pathlib import Path

from duckdb import df

# aggiunge ../src al PYTHONPATH
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

import unittest
from pucktrick.labels import labels
from pucktrick.utils import create_fake_table, create_fake_table_multiclass
import pandas as pd
import numpy as np


class TestLabelFunction(unittest.TestCase):

    def setUp(self):
        """Set up fresh dataframes for each test."""
        self.num_rows = 100
        self.binary_df = create_fake_table(self.num_rows)
        self.multiclass_df = create_fake_table_multiclass(self.num_rows, num_classes=4)

    def test_binary_label_flip_new_mode(self):
        """Test flipping binary labels in 'new' mode."""
        percentage = 0.4
        column = ['target']
        strategy = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': percentage,
            'mode': 'new',
            'perturbate_data': {
                'sampling': 'random',
                'distribution': 'random'
            }
        }
        
        error, noise_df = labels(self.binary_df.copy(), strategy)
        
        self.assertEqual(error, 0)
        
        # Verify that the correct percentage of labels were flipped
        diff_count = (self.binary_df['target'] != noise_df['target']).sum()
        expected_changes = int(self.num_rows * percentage)
        self.assertEqual(diff_count, expected_changes)

    def test_binary_label_flip_extended_mode(self):
        """Test flipping binary labels in 'extended' mode."""
        column = ['target']
        
        # 1. First pass: flip 20%
        strategy_new = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': 0.2,
            'mode': 'new',
            'perturbate_data': {
                'sampling': 'random',
                'distribution': 'random'
            }
        }
        _, noise_df = labels(self.binary_df.copy(), strategy_new)

        # 2. Extended pass: target 70%
        strategy_extended = {
            'affected_features': column,
            'selection_criteria': 'all',
            'percentage': 0.7,
            'mode': 'extended',
            'perturbate_data': {
                'sampling': 'random',
                'distribution': 'random'
            }
        }
        error, final_df = labels(noise_df, strategy_extended, original_df=self.binary_df)
        
        self.assertEqual(error, 0)

        # Verify the final percentage of flipped labels
        diff_count = (self.binary_df['target'] != final_df['target']).sum()
        expected_changes = int(self.num_rows * 0.7)
        self.assertEqual(diff_count, expected_changes)

    def test_multiclass_label_flip_new_mode(self):
        """Test flipping multi-class labels in 'new' mode using NCAR (uniform)."""
        percentage = 0.5
        column = ['target']
        strategy = {
            'affected_features': column,
            'selection_criteria': "all",
            'percentage': percentage,
            'mode': 'new',
            'perturbate_data': {
                "parameters": {"model-name": "NAR",
                                           "flip_distribution": {
                                                "0": {"1": 1.0},
                                                "1": {"2": 1},
                                                "2": {"3": 1},
                                                "3": {"0": 1}
                                                
                                                
                                                                            
                                            }

                            }
                        }
                    }
        
        print(self.multiclass_df['target'].value_counts())
        error, noise_df = labels(self.multiclass_df.copy(), strategy)
        print(noise_df['target'].value_counts())
        
        self.assertEqual(error, 0)
        
        # Verify that the correct percentage of labels were flipped
        diff_count = (self.multiclass_df['target'] != noise_df['target']).sum()
        expected_changes = int(self.num_rows * percentage)
        self.assertEqual(diff_count, expected_changes)


if __name__ == "__main__":
    unittest.main()