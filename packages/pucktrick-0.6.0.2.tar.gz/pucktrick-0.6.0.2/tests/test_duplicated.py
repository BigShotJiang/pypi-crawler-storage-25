import sys
from pathlib import Path

# aggiunge ../src al PYTHONPATH
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))


import unittest
from pucktrick.duplicated import duplicate
from pucktrick.utils import create_fake_table
import pandas as pd


class TestDuplicateFunction(unittest.TestCase):

    def setUp(self):
        """
        Setup a fresh fake dataframe before each test to ensure isolation.
        """
        self.num_rows = 100
        self.fake_df = create_fake_table(self.num_rows)

    def test_duplicate_new_mode(self):
        """
        Test duplicating rows in 'new' mode.
        Expects the total number of rows to increase by the specified percentage.
        """
        percentage = 0.3
        strategy = {
            "affected_features": ["f1"],
            "selection_criteria": "all",
            "percentage": percentage,
            "mode": "new",
            "perturbate_data": {
                "sampling": "random"
            }
        }
        
        error, noise_df = duplicate(self.fake_df.copy(), strategy)
        
        self.assertEqual(error, 0)
        
        # Verify that the number of rows has increased correctly
        expected_rows = self.num_rows + int(self.num_rows * percentage)
        actual_rows = len(noise_df)
        self.assertEqual(actual_rows, expected_rows)

    def test_duplicate_extended_mode(self):
        """
        Test duplicating rows in 'extended' mode.
        It should correctly add new duplicates to reach the target percentage,
        considering the duplicates already present.
        """
        # 1. First injection: duplicate 20% of rows
        strategy_new = {
            "affected_features": ["f1"],
            "selection_criteria": "all",
            "percentage": 0.2,
            "mode": "new",
            "perturbate_data": {"sampling": "random"}
        }
        _, noise_df_new = duplicate(self.fake_df.copy(), strategy_new)
        
        # Check intermediate state: 100 + 20 = 120 rows
        self.assertEqual(len(noise_df_new), self.num_rows + int(self.num_rows * 0.2))
        
        # 2. Extended injection: increase total duplicates to 50%
        strategy_extended = {
            "affected_features": ["f1"],
            "selection_criteria": "all",
            "percentage": 0.5,
            "mode": "extended",
            "perturbate_data": {"sampling": "random"}
        }
        error, noise_df_extended = duplicate(noise_df_new, strategy_extended, original_df=self.fake_df)
        
        self.assertEqual(error, 0)
        
        # Verify final state: total rows should be 100 + (100 * 0.5) = 150
        expected_final_rows = self.num_rows + int(self.num_rows * 0.5)
        actual_final_rows = len(noise_df_extended)
        self.assertEqual(actual_final_rows, expected_final_rows)
 

if __name__ == "__main__":
    unittest.main()
