from asyncio import CancelledError, sleep
import os
from collections.abc import AsyncIterator
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Awaitable, Callable, NotRequired, Protocol, TypedDict, TypeVar, cast

_NATIVE_IMPORT_ERROR: ImportError | None = None

try:
    from ._native import RustS3Client as _RustS3Client  # pyright: ignore[reportMissingImports]
except ImportError as exc:
    _RustS3Client = None
    _NATIVE_IMPORT_ERROR = exc


@dataclass(slots=True)
class S3BlobMetadata:
    content_length: int
    content_type: str
    etag: str
    last_modified: datetime | None
    metadata: dict[str, str]


StreamReadResult = bytes | bytearray | memoryview | str | None
UploadContent = str | bytes
DownloadChunk = memoryview
CompletedPart = tuple[int, str]
_T = TypeVar("_T")


@dataclass(slots=True)
class MultipartPart:
    part_number: int
    etag: str


class NativeHeadResponse(TypedDict):
    content_length: int
    etag: str
    content_type: NotRequired[str]
    last_modified: NotRequired[str | None]
    metadata: NotRequired[dict[str, str]]


class SupportsRead(Protocol):
    def read(self, size: int, /) -> StreamReadResult: ...


class AsyncSupportsRead(Protocol):
    async def read(self, size: int, /) -> StreamReadResult: ...


class NativeObjectReader(Protocol):
    async def read(self, size: int, /) -> bytes: ...
    async def next_chunk(self) -> memoryview | None: ...
    async def close(self) -> None: ...


class NativeS3Client(Protocol):
    async def get(self, bucket: str, key: str) -> bytes: ...
    async def open_reader(self, bucket: str, key: str) -> NativeObjectReader: ...
    async def put(self, bucket: str, key: str, content: UploadContent, content_type: str | None) -> None: ...
    async def upload_file(self, filename: str, bucket: str, key: str, content_type: str | None) -> None: ...
    async def upload_stream(self, bucket: str, key: str, stream: SupportsRead | AsyncSupportsRead, content_type: str | None) -> None: ...
    async def create_multipart_upload(self, bucket: str, key: str, content_type: str | None = None) -> str: ...
    async def upload_part(self, bucket: str, key: str, upload_id: str, part_number: int, body: bytes) -> str: ...
    async def complete_multipart_upload(self, bucket: str, key: str, upload_id: str, parts: list[CompletedPart]) -> None: ...
    async def abort_multipart_upload(self, bucket: str, key: str, upload_id: str) -> None: ...
    async def list_objects(self, bucket: str, prefix: str) -> list[str]: ...
    async def delete(self, bucket: str, key: str) -> None: ...
    async def head(self, bucket: str, key: str) -> NativeHeadResponse | None: ...
    async def generate_presigned_put_url(self, bucket: str, key: str, expires_in: int) -> str: ...
    async def generate_presigned_get_url(self, bucket: str, key: str, name: str | None, expires_in: int) -> str: ...


class NativeS3ClientConstructor(Protocol):
    def __call__(
        self,
        endpoint_url: str,
        access_key: str | None = None,
        secret_key: str | None = None,
        region: str = "enam",
        max_pool_connections: int | None = None,
    ) -> NativeS3Client: ...


def _parse_datetime(value: str | None) -> datetime | None:
    if value is None:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _require_native() -> NativeS3ClientConstructor:
    if _RustS3Client is None:
        message = "native extension is not available; build it with `maturin develop` or `maturin build`"
        if _NATIVE_IMPORT_ERROR is None:
            raise RuntimeError(message)
        raise RuntimeError(message) from _NATIVE_IMPORT_ERROR
    return cast(NativeS3ClientConstructor, _RustS3Client)


def _normalize_completed_parts(parts: list[MultipartPart]) -> list[CompletedPart]:
    normalized = [(part.part_number, part.etag) for part in parts]
    normalized.sort(key=lambda part: part[0])
    return normalized


class S3:
    _max_retries: int

    def __init__(
        self,
        *,
        endpoint_url: str | None = None,
        access_key_id: str | None = None,
        secret_access_key: str | None = None,
        region: str | None = None,
        max_pool_connections: int | None = None,
        max_retries: int = 4,
    ):
        rust_client_cls = _require_native()

        endpoint_url = endpoint_url or os.getenv("BLOB_STORAGE_URL")
        if not endpoint_url:
            raise RuntimeError("BLOB_STORAGE_URL is required")

        self._max_retries = max_retries

        self._native_client = rust_client_cls(
            endpoint_url,
            access_key_id or os.getenv("BLOB_STORAGE_ACCESS_KEY_ID"),
            secret_access_key or os.getenv("BLOB_STORAGE_SECRET_ACCESS_KEY"),
            region or os.getenv("BLOB_STORAGE_REGION", "enam"),
            max_pool_connections,
        )

    async def _call(self, fn: Callable[[], Awaitable[_T]], retryable: bool = True) -> _T:
        attempts = self._max_retries + 1 if retryable else 1
        last_error: RuntimeError | None = None
        for attempt in range(attempts):
            try:
                return await fn()
            except CancelledError:
                raise
            except RuntimeError as exc:
                last_error = exc
                if not retryable:
                    raise
            if attempt < attempts - 1:
                await sleep(min(0.1 * (2**attempt), 1.0))

        if last_error is not None:
            raise last_error

        raise RuntimeError("S3 client exhausted retries")

    async def get(self, bucket: str, key: str) -> bytes:
        return await self._call(lambda: self._native_client.get(bucket, key))

    async def get_stream(self, bucket: str, key: str, chunk_size: int = 64 * 1024 * 1024) -> AsyncIterator[DownloadChunk]:
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        reader = await self._call(lambda: self._native_client.open_reader(bucket, key))
        try:
            while True:
                chunk = await reader.next_chunk()
                if not chunk:
                    break
                view = cast(memoryview, chunk)
                start = 0
                while start < len(view):
                    end = min(start + chunk_size, len(view))
                    yield view[start:end]
                    start = end
        finally:
            await reader.close()

    async def put(self, bucket: str, key: str, content: str | bytes, content_type: str | None = None) -> None:
        await self._call(lambda: self._native_client.put(bucket, key, content, content_type))

    async def upload_file(self, filename: str | Path, bucket: str, key: str, content_type: str | None = None) -> None:
        await self._call(lambda: self._native_client.upload_file(str(filename), bucket, key, content_type))

    async def upload_stream(self, stream: SupportsRead | AsyncSupportsRead, bucket: str, key: str, content_type: str | None = None) -> None:
        await self._call(lambda: self._native_client.upload_stream(bucket, key, stream, content_type), retryable=False)

    async def create_multipart_upload(self, bucket: str, key: str, content_type: str | None = None) -> str:
        return await self._call(lambda: self._native_client.create_multipart_upload(bucket, key, content_type), retryable=False)

    async def upload_part(self, bucket: str, key: str, upload_id: str, part_number: int, body: bytes) -> str:
        return await self._call(lambda: self._native_client.upload_part(bucket, key, upload_id, part_number, body))

    async def complete_multipart_upload(self, bucket: str, key: str, upload_id: str, parts: list[MultipartPart]) -> None:
        normalized = _normalize_completed_parts(parts)
        await self._call(lambda: self._native_client.complete_multipart_upload(bucket, key, upload_id, normalized), retryable=False)

    async def abort_multipart_upload(self, bucket: str, key: str, upload_id: str) -> None:
        await self._call(lambda: self._native_client.abort_multipart_upload(bucket, key, upload_id), retryable=False)

    async def list_objects(self, bucket: str, prefix: str) -> list[str]:
        return await self._call(lambda: self._native_client.list_objects(bucket, prefix))

    async def delete(self, bucket: str, key: str) -> None:
        await self._call(lambda: self._native_client.delete(bucket, key))

    async def head(self, bucket: str, key: str) -> S3BlobMetadata | None:
        response = await self._call(lambda: self._native_client.head(bucket, key))
        if response is None:
            return None
        return S3BlobMetadata(
            content_length=response["content_length"],
            content_type=response.get("content_type", "application/octet-stream"),
            etag=response["etag"],
            last_modified=_parse_datetime(response.get("last_modified")),
            metadata=response.get("metadata", {}),
        )

    async def generate_presigned_url(self, bucket: str, key: str, expires_in: int = 3600) -> str:
        return await self._call(lambda: self._native_client.generate_presigned_put_url(bucket, key, expires_in))

    async def generate_get_url(self, bucket: str, key: str, name: str | None = None, expires_in: int = 3600) -> str:
        return await self._call(lambda: self._native_client.generate_presigned_get_url(bucket, key, name, expires_in))


__all__ = ["S3", "S3BlobMetadata"]
