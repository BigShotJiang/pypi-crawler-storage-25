"""PyPI version-drift check used by the agent main loop to self-recycle
when newer wisent-compute / wisent / wisent-tools releases ship.

Without this, an agent that pip-installed at boot time keeps running its
original version forever — newer code on PyPI never reaches the running
fleet until GCE preempts the VM, idle_shutdown fires (which only
triggers when the queue stops yielding work), or an operator manually
deletes the VM. The class of bugs this surfaces is "fixes shipped to
PyPI but not running": e.g. wisent-compute 0.4.59's verify_command
hook, wisent 0.11.23's batched HF commits, wisent-tools 0.1.16's
exit-non-zero-on-strategy-failure — all on PyPI but ignored by 32
already-running pre-fix VMs on 2026-05-06 producing fake-COMPLETED
jobs at ~80/hour.
"""
from __future__ import annotations

import json
import time
import urllib.request
from importlib.metadata import PackageNotFoundError, version as _local_version

_PACKAGES = ("wisent-compute", "wisent", "wisent-tools")
_CACHE: dict[str, tuple[float, str]] = {}
_CACHE_TTL_SECONDS = 300


def _version_tuple(v: str) -> tuple:
    parts = []
    for token in v.replace("-", ".").split("."):
        try:
            parts.append((0, int(token)))
        except ValueError:
            parts.append((1, token))
    return tuple(parts)


def _pypi_latest(pkg: str) -> str | None:
    cached = _CACHE.get(pkg)
    if cached and (time.time() - cached[0]) < _CACHE_TTL_SECONDS:
        return cached[1]
    try:
        with urllib.request.urlopen(
            f"https://pypi.org/pypi/{pkg}/json",
        ) as resp:
            data = json.loads(resp.read())
    except Exception:
        return None
    releases = data.get("releases") or {}
    if not releases:
        return None
    latest = max(releases.keys(), key=_version_tuple)
    _CACHE[pkg] = (time.time(), latest)
    return latest


def detect_drift() -> dict[str, tuple[str, str]]:
    """{pkg: (installed, pypi_latest)} for every package whose PyPI
    release is newer than the installed version. Empty = no drift."""
    out: dict[str, tuple[str, str]] = {}
    for pkg in _PACKAGES:
        try:
            installed = _local_version(pkg)
        except PackageNotFoundError:
            continue
        latest = _pypi_latest(pkg)
        if latest is None:
            continue
        if _version_tuple(installed) < _version_tuple(latest):
            out[pkg] = (installed, latest)
    return out
