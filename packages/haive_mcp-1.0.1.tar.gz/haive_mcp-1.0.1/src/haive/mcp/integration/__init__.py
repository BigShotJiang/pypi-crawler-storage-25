"""MCP integration module."""
