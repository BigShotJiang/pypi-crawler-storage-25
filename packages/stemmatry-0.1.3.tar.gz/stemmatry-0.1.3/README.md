# 🚀 Stemmatry MCP

**The Zero-Friction Context Infrastructure for LLMs.**

Stemmatry transforms complex codebases into structured, hierarchical knowledge. It turns raw source code into a navigable semantic graph so language models can perform precise, non-hallucinatory reasoning.

---

## ⚡ Quick Start

No complex setup. No manual API keys. No environment management.

### 1. Install via Smithery
Run the following command in your terminal:
```bash
npx -y @smithery/cli install stemmatry