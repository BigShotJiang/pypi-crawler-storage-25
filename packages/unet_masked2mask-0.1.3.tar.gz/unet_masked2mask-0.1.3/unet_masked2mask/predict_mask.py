from dataclasses import dataclass
from torchvision.transforms.functional import to_tensor, to_pil_image
import pytorch_lightning as pl
import gradio as gr
import torch
import os
import random
import numpy as np
from PIL import Image
from huggingface_hub import hf_hub_download
from io import BytesIO
from .models.unet_efb0 import UNet_pcb

@dataclass
class ModelConfig_ENB0:
    backbone: str = "efficientnet_b0"
    model_name: str = "unet_efb0_730k"
    pretrained: bool = True
    layer1_features: int = 32
    layer2_features: int = 16
    layer3_features: int = 24
    layer4_features: int = 40
    layer5_features: int = 80
    alpha_l: float = 1.0 # weight for L1 loss
    beta_l: float = 0.0#1.0 # weight for perceptual loss
    gamma_l: float = 0.0#150.0 # weight for style loss

#MODEL RESUME SETUP
class Img2ImgModel(pl.LightningModule):
    def __init__(self):
        super().__init__()
        model_cfg = ModelConfig_ENB0()
        model = UNet_pcb(pretrained=model_cfg.pretrained,
                         layer1_features=model_cfg.layer1_features,
                         layer2_features=model_cfg.layer2_features,
                         layer3_features=model_cfg.layer3_features,
                         layer4_features=model_cfg.layer4_features,
                         layer5_features=model_cfg.layer5_features)
        self.model = model

    def forward(self, x):
        return self.model(x)

def load_model(ckpt_path, device):
    model = Img2ImgModel.load_from_checkpoint(
        ckpt_path,
        map_location=device,
        strict=False
    )
    model.eval()
    model.to(device)
    return model

def init_model(device):
    global _MODEL_INSTANCE
    print("Downloading/loading weights...")
    weights_path = hf_hub_download(
        repo_id="mridula42/UNetMasked2Mask",
        filename="ckpts/efficientnetb0/unet_efb0_730k.ckpt",
        # token=hf_token # private repo
    )
    _MODEL_INSTANCE = load_model(weights_path, device)
    return _MODEL_INSTANCE

def overlay_mask(img, mask):
    newW, newH = img.size
    alpha_channel = np.array(mask.resize((newW, newH), resample=Image.Resampling.LANCZOS)).astype(np.float32)[..., np.newaxis]/255.0

    # Combine the original image with the new alpha channel
    print('Alpha channel range', alpha_channel.min(), alpha_channel.max())
    orig_img = np.array(img).astype(np.float32)/255.0
    img_rgb = np.ones_like(orig_img)*alpha_channel + orig_img*(1-alpha_channel)

    return torch.tensor(img_rgb).permute(2,0,1)# / 255.0

def auto_generate_mask(image, device):
    x = to_tensor(image).unsqueeze(0).to(device)
    model = init_model(device)
    with torch.no_grad():
      torch.cuda.empty_cache()
      pred_mask = model(x)
    print('Mask range', pred_mask.min(), pred_mask.max())
    # final_mask = torch.zeros_like(image)
    return to_pil_image(pred_mask.squeeze().detach())#1-pred_mask if not working

if __name__ == "__main__":
    DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
    _MODEL_INSTANCE = None # loaded model in mem
    TIER = 'efb0'
    OUTPUT_DIR = f"outputs/{TIER}/"
    IMG_FOLDER_PATH = f"test/"
    os.makedirs(OUTPUT_DIR, exist_ok = True)    

    for filename in os.listdir(IMG_FOLDER_PATH):
        print(f'Output to process as {OUTPUT_DIR}{filename}')
        if os.path.exists(f'{OUTPUT_DIR}{filename}'):
            print(filename, 'Output already processed')
        else:
            img = Image.open(IMG_FOLDER_PATH+filename)
            result = auto_generate_mask(img, DEVICE)
            result.save(f'{OUTPUT_DIR}{filename}')
        break