"""StarRocks-backed shared repositories.

Domain repositories that multiple ChainSwarm subsystems depend on. Subsystem-
specific repositories (synthetics_*, ml_*, analyzers_*) live in their own
repos and use the ``StarRocksWarehouseAdapter`` directly.
"""

from chainswarm_core.starrocks.repositories.address_label_repository import (
    AddressLabelRepository,
)

__all__ = ["AddressLabelRepository"]
