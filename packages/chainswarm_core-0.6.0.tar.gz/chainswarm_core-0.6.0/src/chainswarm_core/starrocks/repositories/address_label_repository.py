"""StarRocks-backed address label repository."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from chainswarm_core.constants import (
    AddressSubtypes,
    AddressTypes,
    TrustLevels,
)
from chainswarm_core.constants.risk import get_address_type_risk_level

from chainswarm_core.starrocks.adapter import StarRocksWarehouseAdapter
from chainswarm_core.starrocks.datetime_text import (
    to_datetime_text,
    utc_datetime_text,
)

LABEL_COLUMNS = (
    "address",
    "address_subtype",
    "source",
    "network_type",
    "label",
    "address_type",
    "trust_level",
    "related_address",
    "risk_level",
    "confidence_score",
    "block_height",
    "block_timestamp",
    "updated_timestamp",
)
REQUIRED_LABEL_FIELDS = (
    "address",
    "label",
    "source",
    "trust_level",
    "confidence_score",
)


class AddressLabelRepository:
    """Read and write address labels through StarRocks-only boundaries."""

    def __init__(self, adapter: StarRocksWarehouseAdapter) -> None:
        """Initialize the repository.

        Args:
            adapter: StarRocks warehouse adapter used for reads and writes.
        """
        self.adapter = adapter

    def insert_labels(self, labels: Iterable[Mapping[str, Any]]) -> int:
        """Insert address labels through the StarRocks MySQL protocol."""
        materialized_labels = list(labels)
        if not materialized_labels:
            return 0

        now_dt = utc_datetime_text()
        rows = [
            _label_to_row(label, now_dt)
            for label in materialized_labels
        ]
        return self.adapter.mysql_client.insert_rows(
            "core_address_labels",
            LABEL_COLUMNS,
            rows,
            batch_size=1000,
        )

    def get_labels_for_addresses(
        self,
        network: str,
        addresses: Sequence[str],
    ) -> list[dict[str, Any]]:
        """Get all labels for addresses."""
        if not addresses:
            return []

        placeholders = _placeholders(len(addresses))
        return self.adapter.query(
            f"""
            SELECT *
            FROM core_address_labels
            WHERE address IN ({placeholders})
            ORDER BY trust_level DESC, confidence_score DESC
            """,
            tuple(addresses),
        )

    def get_addresses_with_labels(
        self,
        addresses: Sequence[str],
        network: str,
    ) -> list[str]:
        """Get addresses that already have labels in the database."""
        if not addresses:
            return []

        placeholders = _placeholders(len(addresses))
        rows = self.adapter.query(
            f"""
            SELECT DISTINCT address
            FROM core_address_labels
            WHERE address IN ({placeholders})
            """,
            tuple(addresses),
        )
        return [str(row["address"]) for row in rows]

    def get_seed_labels(
        self,
        network: str,
        address_subtypes: Sequence[str],
        after_updated_timestamp: int = 0,
        after_address: str = "",
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        """Return graph seed labels for the requested address subtypes."""
        if not address_subtypes:
            return []

        placeholders = _placeholders(len(address_subtypes))
        return self.adapter.query(
            f"""
            SELECT address, address_subtype, updated_timestamp, block_height, block_timestamp
            FROM core_address_labels
            WHERE address_subtype IN ({placeholders})
              AND (
                  updated_timestamp > %s
                  OR (updated_timestamp = %s AND address > %s)
              )
            ORDER BY updated_timestamp ASC, address ASC
            LIMIT %s
            """,
            (
                *address_subtypes,
                after_updated_timestamp,
                after_updated_timestamp,
                after_address,
                limit,
            ),
        )

    def get_exchange_addresses(
        self,
        network: str,
        trust_levels: Sequence[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Get core exchange addresses for a network."""
        selected_trust_levels = (
            tuple(trust_levels)
            if trust_levels is not None
            else (TrustLevels.VERIFIED, TrustLevels.OFFICIAL)
        )
        placeholders = _placeholders(len(selected_trust_levels))
        return self.adapter.query(
            f"""
            SELECT DISTINCT address, label, address_subtype, trust_level, confidence_score
            FROM core_address_labels
            WHERE address_type = %s
              AND trust_level IN ({placeholders})
              AND address_subtype != %s
            """,
            (
                AddressTypes.EXCHANGE,
                *selected_trust_levels,
                AddressSubtypes.EXCHANGE_ADJACENT,
            ),
        )

    def get_all_labels(
        self,
        network: str,
        limit: int = 10_000_000,
    ) -> list[dict[str, Any]]:
        """Return all labels for a network."""
        return self.adapter.query(
            """
            SELECT *
            FROM core_address_labels
            ORDER BY address, trust_level DESC, confidence_score DESC
            LIMIT %s
            """,
            (limit,),
        )

    def get_addresses_needing_source(
        self,
        network: str,
        source_prefix: str,
        address_pattern: str = "0x%",
        network_type: str | None = None,
    ) -> list[str]:
        """Return addresses with labels but no labels matching source prefix."""
        network_type_clause = ""
        parameters: tuple[Any, ...]
        if network_type:
            network_type_clause = "AND network_type = %s"
            parameters = (
                address_pattern,
                network_type,
                f"{source_prefix}%",
            )
        else:
            parameters = (
                address_pattern,
                f"{source_prefix}%",
            )

        rows = self.adapter.query(
            f"""
            SELECT DISTINCT address
            FROM core_address_labels
            WHERE address LIKE %s
              {network_type_clause}
              AND address NOT IN (
                  SELECT address
                  FROM core_address_labels
                  WHERE source LIKE %s
              )
            ORDER BY address
            """,
            parameters,
        )
        return [str(row["address"]) for row in rows]


def _label_to_row(label: Mapping[str, Any], now_dt: str) -> tuple[Any, ...]:
    for field_name in REQUIRED_LABEL_FIELDS:
        _required_value(label, field_name)

    address_type = str(label.get("address_type", AddressTypes.UNKNOWN))
    raw_updated_timestamp = label.get("updated_timestamp")
    updated_timestamp_dt = to_datetime_text(raw_updated_timestamp, now_dt)
    return (
        label["address"],
        str(label.get("address_subtype", "")),
        label["source"],
        str(label.get("network_type", "")),
        label["label"],
        address_type,
        label["trust_level"],
        str(label.get("related_address", "")),
        get_address_type_risk_level(address_type),
        float(label["confidence_score"]),
        int(label.get("block_height", 0)),
        int(label.get("block_timestamp", 0)),
        updated_timestamp_dt,
    )


def _required_value(row: Mapping[str, Any], field_name: str) -> Any:
    if field_name not in row:
        raise ValueError(f"Missing required label field: {field_name}")
    value = row[field_name]
    if value is None:
        raise ValueError(f"Required label field cannot be None: {field_name}")
    return value


def _placeholders(count: int) -> str:
    return ", ".join(["%s"] * count)
