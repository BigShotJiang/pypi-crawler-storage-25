"""Central StarRocks warehouse routing between MySQL and Stream Load."""

from __future__ import annotations

import json
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

from .datetime_text import utc_datetime_text
from .identifiers import canonicalize_transfer_row
from .labels import StreamLoadLabelContext, build_payload_hash_prefix
from .stream_load import (
    DEFAULT_STREAM_LOAD_TABLES,
    StarRocksLoadError,
    StarRocksStreamLoadClient,
    StreamLoadOutcome,
    StreamLoadStatus,
)

FACT_STREAM_LOAD_TABLES = {
    "core_transfers",
    "core_block_stream",
    "core_block_stream_utxo_outputs",
    "core_money_flows_daily",
    "analyzers_features",
}
NON_DETERMINISTIC_IDENTITY_COLUMNS = {
    "inserted_at",
    "updated_at",
    "indexed_at",
    "refreshed_at",
}
LOAD_LABEL_SUBMITTED_STATUS = "submitted"


class StarRocksWarehouseAdapter:
    """Route StarRocks operations through the correct transport.

    Persists every Stream Load attempt in a ``_load_labels`` tracking table so
    duplicate-label retries can be resolved deterministically. Callers must
    provision the table (see ``ensure_load_labels_table``) before the first
    fact write.
    """

    def __init__(
        self,
        mysql_client: Any,
        stream_load_client: StarRocksStreamLoadClient | None = None,
    ) -> None:
        self.mysql_client = mysql_client
        self.stream_load_client = stream_load_client or StarRocksStreamLoadClient(
            mysql_client.config,
            allowed_tables=DEFAULT_STREAM_LOAD_TABLES,
        )

    def load_fact_rows(
        self,
        network: str,
        table_name: str,
        columns: Sequence[str],
        rows: Iterable[Sequence[Any] | Mapping[str, Any]],
        range_start: int | str,
        range_end: int | str,
    ) -> StreamLoadOutcome:
        """Route fact rows through deterministic HTTP Stream Load."""
        if table_name not in FACT_STREAM_LOAD_TABLES:
            raise StarRocksLoadError(f"Fact table is not allowed: {table_name}")

        materialized_rows = [
            self._materialize_row(network, table_name, columns, row) for row in rows
        ]
        identity_columns, identity_rows = _stable_payload_identity(
            columns,
            materialized_rows,
        )
        payload_hash_prefix = build_payload_hash_prefix(identity_columns, identity_rows)
        label_context = StreamLoadLabelContext(
            network=network,
            table_name=table_name,
            range_start=range_start,
            range_end=range_end,
            payload_hash_prefix=payload_hash_prefix,
        )
        self._ensure_load_label_submission(label_context, len(materialized_rows))
        outcome = self.stream_load_client.load_json(
            table_name,
            columns,
            materialized_rows,
            label_context,
        )

        if outcome.status is StreamLoadStatus.DUPLICATE_LABEL:
            return self._resolve_duplicate_label(label_context, outcome)
        self.record_load_label(label_context, outcome)
        return outcome

    def execute(self, sql: str, params: Sequence[Any] | None = None) -> None:
        """Route DDL and small control writes through MySQL protocol."""
        self.mysql_client.execute(sql, params)

    def query(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Route reads through MySQL protocol."""
        return self.mysql_client.query(sql, params)

    def health_check(self) -> bool:
        """Route health checks through MySQL protocol."""
        return self.mysql_client.health_check()

    def record_load_label(
        self,
        label_context: StreamLoadLabelContext,
        outcome: StreamLoadOutcome,
    ) -> None:
        """Persist committed load identity for duplicate-label replay checks."""
        self.mysql_client.execute(
            """
            INSERT INTO _load_labels (
                table_name,
                load_label,
                payload_hash_prefix,
                range_start,
                range_end,
                row_count,
                filtered_row_count,
                status,
                response_json,
                created_at,
                committed_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                label_context.table_name,
                label_context.to_label(),
                label_context.payload_hash_prefix,
                str(label_context.range_start),
                str(label_context.range_end),
                outcome.loaded_rows,
                outcome.filtered_rows,
                outcome.status.value,
                json.dumps(
                    {
                        "message": outcome.message,
                        "error_url": outcome.error_url,
                    },
                    sort_keys=True,
                ),
                utc_datetime_text(),
                utc_datetime_text() if outcome.is_committed else None,
            ),
        )

    def record_load_label_submission(
        self,
        label_context: StreamLoadLabelContext,
        row_count: int,
    ) -> None:
        """Persist deterministic load identity before submitting Stream Load."""
        self.mysql_client.execute(
            """
            INSERT INTO _load_labels (
                table_name,
                load_label,
                payload_hash_prefix,
                range_start,
                range_end,
                row_count,
                filtered_row_count,
                status,
                response_json,
                created_at,
                committed_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """,
            (
                label_context.table_name,
                label_context.to_label(),
                label_context.payload_hash_prefix,
                str(label_context.range_start),
                str(label_context.range_end),
                int(row_count),
                0,
                LOAD_LABEL_SUBMITTED_STATUS,
                json.dumps(
                    {
                        "message": "load identity recorded before Stream Load request",
                        "error_url": None,
                    },
                    sort_keys=True,
                ),
                utc_datetime_text(),
                None,
            ),
        )

    def find_load_label(self, label: str) -> dict[str, Any] | None:
        """Return a stored load label row if one exists."""
        rows = self.mysql_client.query(
            """
            SELECT
                load_label AS label,
                table_name,
                range_start,
                range_end,
                payload_hash_prefix,
                status,
                row_count,
                filtered_row_count,
                response_json,
                created_at,
                committed_at
            FROM _load_labels
            WHERE load_label = %s
            LIMIT 1
            """,
            (label,),
        )
        return rows[0] if rows else None

    def _resolve_duplicate_label(
        self,
        label_context: StreamLoadLabelContext,
        outcome: StreamLoadOutcome,
    ) -> StreamLoadOutcome:
        stored_label = self.find_load_label(label_context.to_label())
        identity_matches = bool(
            stored_label
            and stored_label.get("payload_hash_prefix")
            == label_context.payload_hash_prefix
        )
        return outcome.with_duplicate_identity_match(identity_matches)

    def _ensure_load_label_submission(
        self,
        label_context: StreamLoadLabelContext,
        row_count: int,
    ) -> None:
        stored_label = self.find_load_label(label_context.to_label())
        if stored_label:
            stored_payload_hash_prefix = stored_label.get("payload_hash_prefix")
            if stored_payload_hash_prefix != label_context.payload_hash_prefix:
                raise StarRocksLoadError(
                    "stored Stream Load label identity differs for "
                    f"{label_context.to_label()}"
                )
            return
        self.record_load_label_submission(label_context, row_count)

    def _materialize_row(
        self,
        network: str,
        table_name: str,
        columns: Sequence[str],
        row: Sequence[Any] | Mapping[str, Any],
    ) -> Sequence[Any]:
        if isinstance(row, Mapping):
            source_row = (
                canonicalize_transfer_row(network, row)
                if table_name == "core_transfers"
                else dict(row)
            )
            return tuple(source_row[column] for column in columns)
        return tuple(row)




def _stable_payload_identity(
    columns: Sequence[str],
    rows: Sequence[Sequence[Any]],
) -> tuple[list[str], list[tuple[Any, ...]]]:
    identity_column_indices = [
        column_index
        for column_index, column in enumerate(columns)
        if column not in NON_DETERMINISTIC_IDENTITY_COLUMNS
    ]
    identity_columns = [columns[column_index] for column_index in identity_column_indices]
    identity_rows = []
    for row in rows:
        if len(row) != len(columns):
            raise ValueError("row length must match columns length")
        identity_rows.append(
            tuple(row[column_index] for column_index in identity_column_indices)
        )
    return identity_columns, identity_rows
