from __future__ import annotations

import csv
import json
import re
from io import StringIO
from typing import Any, Iterable, Sequence

from mysql.connector.pooling import MySQLConnectionPool

from .config import StarRocksConfig

IDENTIFIER_PATTERN = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")


class StarRocksClient:
    """MySQL protocol client for StarRocks DDL, reads, and control writes."""

    def __init__(self, config: StarRocksConfig):
        if not config.is_configured:
            raise ValueError("StarRocksConfig is not configured")
        self.config = config
        self.pool = MySQLConnectionPool(
            pool_name=_build_pool_name(config.database),
            pool_size=config.pool_size,
            pool_reset_session=True,
            host=config.host,
            port=config.port,
            user=config.user,
            password=config.password,
            database=config.database,
            autocommit=True,
        )

    def _connect(self):
        return self.pool.get_connection()

    def health_check(self) -> bool:
        """Return whether StarRocks responds to a simple MySQL protocol query."""
        rows = self.query("SELECT 1 AS ok")
        return bool(rows and rows[0].get("ok") == 1)

    def execute(self, sql: str, params: Sequence[Any] | None = None) -> None:
        connection = self._connect()
        cursor = None
        try:
            cursor = connection.cursor()
            parameters = params or ()
            cursor.execute(sql, parameters)
        finally:
            if cursor is not None:
                cursor.close()
            connection.close()

    def query(
        self,
        sql: str,
        params: Sequence[Any] | None = None,
    ) -> list[dict[str, Any]]:
        connection = self._connect()
        cursor = None
        try:
            cursor = connection.cursor(dictionary=True)
            parameters = params or ()
            cursor.execute(sql, parameters)
            return list(cursor.fetchall())
        finally:
            if cursor is not None:
                cursor.close()
            connection.close()

    def insert_rows(
        self,
        table: str,
        columns: Sequence[str],
        rows: Iterable[Sequence[Any]],
        batch_size: int = 5000,
    ) -> int:
        if not columns:
            raise ValueError("columns must be non-empty")
        placeholders = ", ".join(["%s"] * len(columns))
        column_sql = ", ".join(quote_identifier(column) for column in columns)
        sql = (
            f"INSERT INTO {quote_identifier(table)} ({column_sql}) "
            f"VALUES ({placeholders})"
        )
        rows_buffer: list[Sequence[Any]] = []
        inserted = 0

        connection = self._connect()
        cursor = None
        try:
            cursor = connection.cursor()
            for row in rows:
                rows_buffer.append(
                    tuple(_starrocks_insert_value(value) for value in row)
                )
                if len(rows_buffer) >= batch_size:
                    cursor.executemany(sql, rows_buffer)
                    inserted += len(rows_buffer)
                    rows_buffer.clear()
            if rows_buffer:
                cursor.executemany(sql, rows_buffer)
                inserted += len(rows_buffer)
        finally:
            if cursor is not None:
                cursor.close()
            connection.close()

        return inserted

    @staticmethod
    def rows_to_csv(
        columns: Sequence[str],
        rows: Iterable[Sequence[Any]],
        include_header: bool = True,
    ) -> str:
        buffer = StringIO()
        writer = csv.writer(buffer)
        if include_header:
            writer.writerow(columns)
        writer.writerows(rows)
        return buffer.getvalue()


def _build_pool_name(database: str) -> str:
    """Build a deterministic MySQL connection pool name for a database."""
    safe_database = "".join(
        character if character.isalnum() else "_" for character in database
    )
    return f"starrocks_{safe_database}"


def validate_identifier(identifier: str) -> str:
    """Return a valid StarRocks identifier or raise before SQL/header use."""
    if not IDENTIFIER_PATTERN.fullmatch(identifier):
        raise ValueError(f"invalid StarRocks identifier: {identifier}")
    return identifier


def quote_identifier(identifier: str) -> str:
    """Return a safely quoted StarRocks SQL identifier."""
    return f"`{validate_identifier(identifier)}`"


def _starrocks_insert_value(value: Any) -> Any:
    """Convert Python containers into StarRocks MySQL-bindable values.

    StarRocks accepts JSON-encoded array literals via the MySQL protocol when
    the target column is ARRAY<...>.  Lists and tuples are JSON-serialized;
    other values pass through unchanged.

    Args:
        value: Source value from a row tuple.

    Returns:
        A MySQL-protocol-bindable value (str / int / float / Decimal / bytes /
        date / None).  Lists and tuples become compact JSON strings.
    """
    if isinstance(value, (list, tuple)):
        return json.dumps(list(value), separators=(",", ":"))
    return value
