"""Idempotency tracking table provisioning for the StarRocks adapter.

The ``_load_labels`` table backs ``StarRocksWarehouseAdapter``'s
duplicate-label resolution. The DDL is self-contained — no foreign keys, no
domain coupling — so chainswarm-core owns it directly. Consumers call
``ensure_load_labels_table()`` once at service startup against any new
StarRocks database before the adapter performs its first fact write.
"""

from __future__ import annotations

from typing import Any

LOAD_LABELS_DDL = """
CREATE TABLE IF NOT EXISTS _load_labels (
  table_name VARCHAR(128) NOT NULL,
  load_label VARCHAR(256) NOT NULL,
  payload_hash_prefix VARCHAR(32) NOT NULL,
  range_start VARCHAR(64) NOT NULL,
  range_end VARCHAR(64) NOT NULL,
  row_count BIGINT NOT NULL,
  filtered_row_count BIGINT NOT NULL,
  status VARCHAR(32) NOT NULL,
  response_json STRING NOT NULL,
  created_at DATETIME NOT NULL,
  committed_at DATETIME
)
PRIMARY KEY(table_name, load_label)
DISTRIBUTED BY HASH(load_label) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
)
""".strip()


def ensure_load_labels_table(client: Any) -> None:
    """Create the ``_load_labels`` tracking table if it does not exist.

    Idempotent: ``CREATE TABLE IF NOT EXISTS`` is safe to call repeatedly. The
    function executes a single DDL statement against the provided client and
    returns nothing on success.

    Args:
        client: Any object with an ``execute(sql)`` method that runs DDL
            against the consumer's StarRocks database (e.g.
            ``StarRocksClient`` or ``StarRocksWarehouseAdapter``).
    """
    client.execute(LOAD_LABELS_DDL)
