-- StarRocks-native warehouse schema.
-- Raw transfers store canonical facts only. Durable money-flow rows preserve
-- query results across future raw-history lifecycle changes.
--
-- Timestamp policy (#G):
--   Chain-derived timestamps stay BIGINT (epoch milliseconds) so they match
--   the format the indexers receive from each chain's RPC and so analytical
--   queries can do cheap integer math on them. The chain-derived columns are:
--     block_timestamp, first_seen_timestamp, last_seen_timestamp
--   All other timestamps are operational (recorded by the writer at write
--   time) and use DATETIME for human readability in DataGrip/SELECT output.
--   Operational columns include:
--     updated_timestamp, evidence_timestamp, indexed_at, refreshed_at,
--     started_at, completed_at, created_at, updated_at, resolved_at.
--
-- VARCHAR sizing convention (~20% safety buffer over the longest legitimate
-- per-chain value):
--   addresses        VARCHAR(80)   covers TON raw 67c, EVM 42c, Substrate 48c,
--                                  Solana 44c, Bitcoin Taproot ~62c
--   tx hashes /
--   block hashes     VARCHAR(108)  covers Solana sigs 88c, EVM/Substrate 66c
--
-- Bucket strategy:
--   per-partition big tables (transfers, money_flows, block_stream)  32
--   per-partition medium tables (utxo_outputs, asset_prices)         16
--   per-partition operational tables (refresh windows)                4
--   non-partitioned medium tables (address_labels, evidence)         16
--   non-partitioned small registries (assets)                          8
--   non-partitioned operational state (`_*` ops tables, settings)     4
--
-- Operational/internal tables prefixed with `_` (StarRocks accepts the leading
-- underscore) so analytics tooling and DataGrip group them separately from the
-- domain `core_*` surface.

CREATE TABLE IF NOT EXISTS core_transfers (
  block_date DATE NOT NULL,
  block_height BIGINT NOT NULL,
  tx_id VARCHAR(108) NOT NULL,
  event_index INT NOT NULL,
  edge_index INT NOT NULL,
  block_timestamp BIGINT NOT NULL,
  from_address VARCHAR(80) NOT NULL,
  to_address VARCHAR(80) NOT NULL,
  asset_id BIGINT NOT NULL,
  amount DECIMAL(38,8) NOT NULL
)
PRIMARY KEY(block_date, block_height, tx_id, event_index, edge_index)
PARTITION BY date_trunc('day', block_date)
DISTRIBUTED BY HASH(tx_id) BUCKETS 32
PROPERTIES (
  "bloom_filter_columns" = "from_address, to_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_block_stream (
  block_date DATE NOT NULL,
  block_height BIGINT NOT NULL,
  block_hash VARCHAR(108) NOT NULL,
  block_timestamp BIGINT NOT NULL,
  block_data JSON NOT NULL
)
PRIMARY KEY(block_date, block_height)
PARTITION BY date_trunc('month', block_date)
DISTRIBUTED BY HASH(block_height) BUCKETS 32
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_block_stream_utxo_outputs (
  block_height BIGINT NOT NULL,
  txid VARCHAR(108) NOT NULL,
  vout_index INT NOT NULL,
  block_date DATE NOT NULL,
  value DECIMAL(38,8) NOT NULL,
  address VARCHAR(80) NOT NULL,
  source_batch_label VARCHAR(256) NOT NULL,
  indexed_at DATETIME NOT NULL
)
PRIMARY KEY(block_height, txid, vout_index, block_date)
PARTITION BY date_trunc('day', block_date)
DISTRIBUTED BY HASH(txid) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_block_stream_event_statistics (
  partition_id BIGINT NOT NULL,
  module_id VARCHAR(128) NOT NULL,
  event_id VARCHAR(128) NOT NULL,
  first_seen_height BIGINT NOT NULL,
  last_seen_height BIGINT NOT NULL,
  event_count BIGINT NOT NULL,
  example_event_data STRING NOT NULL,
  source_batch_label VARCHAR(256) NOT NULL,
  updated_at DATETIME NOT NULL
)
PRIMARY KEY(partition_id, module_id, event_id)
DISTRIBUTED BY HASH(module_id) BUCKETS 8
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS _indexer_checkpoints (
  indexer_name VARCHAR(128) NOT NULL,
  last_scanned_height BIGINT NOT NULL,
  is_authoritative BOOLEAN NOT NULL,
  state_data STRING NOT NULL,
  updated_at DATETIME NOT NULL
)
PRIMARY KEY(indexer_name)
DISTRIBUTED BY HASH(indexer_name) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_money_flows_daily (
  activity_date DATE NOT NULL,
  from_address VARCHAR(80) NOT NULL,
  to_address VARCHAR(80) NOT NULL,
  asset_id BIGINT NOT NULL,
  flow_id VARCHAR(64) NOT NULL,
  tx_count BIGINT NOT NULL,
  amount_sum DECIMAL(38,8) NOT NULL,
  first_seen_timestamp BIGINT NOT NULL,
  last_seen_timestamp BIGINT NOT NULL,
  first_tx_id VARCHAR(108) NOT NULL,
  last_tx_id VARCHAR(108) NOT NULL,
  source_window_start_height BIGINT NOT NULL,
  source_window_end_height BIGINT NOT NULL,
  source_window_start_date DATE NOT NULL,
  source_window_end_date DATE NOT NULL,
  source_batch_label VARCHAR(256) NOT NULL,
  indexed_at DATETIME NOT NULL,
  refreshed_at DATETIME NOT NULL
)
PRIMARY KEY(activity_date, from_address, to_address, asset_id)
PARTITION BY date_trunc('day', activity_date)
DISTRIBUTED BY HASH(from_address, to_address) BUCKETS 32
PROPERTIES (
  "bloom_filter_columns" = "from_address, to_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS _money_flow_refresh_windows (
  window_start_height BIGINT NOT NULL,
  window_end_height BIGINT NOT NULL,
  refresh_kind VARCHAR(32) NOT NULL,
  window_start_date DATE NOT NULL,
  window_end_date DATE NOT NULL,
  refresh_status VARCHAR(32) NOT NULL,
  source_batch_label VARCHAR(256) NOT NULL,
  affected_row_count BIGINT NOT NULL,
  started_at DATETIME NOT NULL,
  completed_at DATETIME,
  error_message STRING
)
PRIMARY KEY(window_start_height, window_end_height, refresh_kind, window_start_date)
PARTITION BY date_trunc('day', window_start_date)
DISTRIBUTED BY HASH(window_start_height) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS _load_labels (
  table_name VARCHAR(128) NOT NULL,
  load_label VARCHAR(256) NOT NULL,
  payload_hash_prefix VARCHAR(32) NOT NULL,
  range_start VARCHAR(64) NOT NULL,
  range_end VARCHAR(64) NOT NULL,
  row_count BIGINT NOT NULL,
  filtered_row_count BIGINT NOT NULL,
  status VARCHAR(32) NOT NULL,
  response_json STRING NOT NULL,
  created_at DATETIME NOT NULL,
  committed_at DATETIME
)
PRIMARY KEY(table_name, load_label)
DISTRIBUTED BY HASH(load_label) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS _sync_state (
  pipeline_name VARCHAR(128) NOT NULL,
  synced_until_date DATE NOT NULL,
  synced_until_timestamp BIGINT NOT NULL,
  source_row_count BIGINT NOT NULL,
  target_row_count BIGINT NOT NULL,
  status VARCHAR(32) NOT NULL,
  updated_at DATETIME NOT NULL
)
PRIMARY KEY(pipeline_name)
DISTRIBUTED BY HASH(pipeline_name) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS _write_failures (
  failure_id VARCHAR(128) NOT NULL,
  table_name VARCHAR(128) NOT NULL,
  operation VARCHAR(64) NOT NULL,
  payload_json STRING NOT NULL,
  error_message STRING NOT NULL,
  created_at DATETIME NOT NULL,
  retry_count INT NOT NULL,
  resolved BOOLEAN NOT NULL
)
PRIMARY KEY(failure_id)
DISTRIBUTED BY HASH(failure_id) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_address_labels (
  address VARCHAR(80) NOT NULL,
  address_subtype VARCHAR(128) NOT NULL,
  source VARCHAR(128) NOT NULL,
  network_type VARCHAR(32) NOT NULL,
  label VARCHAR(256) NOT NULL,
  address_type VARCHAR(64) NOT NULL,
  trust_level VARCHAR(64) NOT NULL,
  related_address VARCHAR(80) NOT NULL,
  risk_level VARCHAR(64) NOT NULL,
  confidence_score FLOAT NOT NULL,
  block_height BIGINT NOT NULL,
  block_timestamp BIGINT NOT NULL,
  updated_timestamp DATETIME NOT NULL,
  INDEX idx_address_type (address_type) USING BITMAP,
  INDEX idx_trust_level (trust_level) USING BITMAP,
  INDEX idx_risk_level (risk_level) USING BITMAP
)
PRIMARY KEY(address, address_subtype, source)
DISTRIBUTED BY HASH(address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address, related_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_address_label_evidence (
  labeled_address VARCHAR(80) NOT NULL,
  address_subtype VARCHAR(128) NOT NULL,
  probe_name VARCHAR(128) NOT NULL,
  seed_address VARCHAR(80) NOT NULL,
  label_source VARCHAR(128) NOT NULL,
  path_addresses_json STRING NOT NULL,
  path_direction VARCHAR(32) NOT NULL,
  endpoint_address VARCHAR(80) NOT NULL,
  endpoint_type VARCHAR(64) NOT NULL,
  hop_count INT NOT NULL,
  amount_usd DECIMAL(38,8) NOT NULL,
  confidence_score FLOAT NOT NULL,
  safety_decisions_json STRING NOT NULL,
  evidence_timestamp DATETIME NOT NULL
)
PRIMARY KEY(labeled_address, address_subtype, probe_name, seed_address)
DISTRIBUTED BY HASH(labeled_address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "labeled_address, seed_address, endpoint_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_assets (
  asset_id BIGINT NOT NULL,
  asset_contract VARCHAR(80) NOT NULL,
  asset_symbol VARCHAR(64) NOT NULL,
  name VARCHAR(256) NOT NULL DEFAULT '',
  symbol_lower VARCHAR(64) NOT NULL DEFAULT '',
  decimals INT NOT NULL,
  verified BOOLEAN NOT NULL,
  verification_source VARCHAR(128) NOT NULL,
  first_seen_timestamp BIGINT NOT NULL,
  last_scanned_block_height BIGINT NOT NULL,
  coingecko_id VARCHAR(128),
  pricing_status VARCHAR(32) NOT NULL,
  pricing_tier TINYINT NOT NULL,
  registry_source VARCHAR(64) NOT NULL DEFAULT '',
  registry_first_seen_at DATETIME,
  registry_updated_at DATETIME,
  INDEX idx_pricing_status (pricing_status) USING BITMAP,
  INDEX idx_pricing_tier (pricing_tier) USING BITMAP
)
PRIMARY KEY(asset_id)
DISTRIBUTED BY HASH(asset_id) BUCKETS 8
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS core_asset_prices (
  asset_contract VARCHAR(80) NOT NULL,
  price_date DATE NOT NULL,
  source VARCHAR(64) NOT NULL,
  asset_symbol VARCHAR(64) NOT NULL,
  price_usd DECIMAL(38,8) NOT NULL
)
PRIMARY KEY(asset_contract, price_date, source)
PARTITION BY date_trunc('day', price_date)
DISTRIBUTED BY HASH(asset_contract) BUCKETS 16
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE VIEW IF NOT EXISTS core_address_labels_view AS
SELECT
  address,
  network_type,
  label,
  address_type,
  address_subtype,
  related_address,
  trust_level,
  source,
  risk_level,
  confidence_score,
  block_height,
  block_timestamp,
  updated_timestamp
FROM (
  SELECT
    address,
    network_type,
    label,
    address_type,
    address_subtype,
    related_address,
    trust_level,
    source,
    risk_level,
    confidence_score,
    block_height,
    block_timestamp,
    updated_timestamp,
    row_number() OVER (
      PARTITION BY address
      ORDER BY
        CASE trust_level
          WHEN 'verified' THEN 0
          WHEN 'official' THEN 1
          WHEN 'community' THEN 2
          ELSE 3
        END,
        block_timestamp DESC,
        updated_timestamp DESC
    ) AS row_rank
  FROM core_address_labels
) ranked
WHERE row_rank = 1;

CREATE VIEW IF NOT EXISTS core_asset_prices_latest_view AS
SELECT
  asset_contract,
  price_date,
  asset_symbol,
  source,
  price_usd
FROM (
  SELECT
    asset_contract,
    price_date,
    asset_symbol,
    source,
    price_usd,
    row_number() OVER (
      PARTITION BY asset_contract, price_date
      ORDER BY source ASC
    ) AS row_rank
  FROM core_asset_prices
) ranked
WHERE row_rank = 1;

CREATE VIEW IF NOT EXISTS core_block_stream_event_statistics_view AS
SELECT
  module_id,
  event_id,
  SUM(event_count) AS total_count,
  MIN(first_seen_height) AS first_seen_height,
  MAX(last_seen_height) AS last_seen_height,
  MAX(example_event_data) AS example_event_data,
  MAX(updated_at) AS updated_at
FROM core_block_stream_event_statistics
GROUP BY module_id, event_id;

CREATE VIEW IF NOT EXISTS core_address_base_features_view AS
SELECT
  address_book.address,
  COALESCE(sent_transfer.sent_count, 0) AS sent_count,
  COALESCE(received_transfer.received_count, 0) AS received_count,
  COALESCE(sent_transfer.sent_amount_sum, 0) AS sent_amount_sum,
  COALESCE(received_transfer.received_amount_sum, 0) AS received_amount_sum,
  label_view.label,
  label_view.address_type,
  label_view.trust_level,
  label_view.risk_level,
  label_view.confidence_score
FROM (
  SELECT from_address AS address FROM core_transfers
  UNION
  SELECT to_address AS address FROM core_transfers
) address_book
LEFT JOIN (
  SELECT
    from_address AS address,
    COUNT(*) AS sent_count,
    SUM(amount) AS sent_amount_sum
  FROM core_transfers
  GROUP BY from_address
) sent_transfer
  ON address_book.address = sent_transfer.address
LEFT JOIN (
  SELECT
    to_address AS address,
    COUNT(*) AS received_count,
    SUM(amount) AS received_amount_sum
  FROM core_transfers
  GROUP BY to_address
) received_transfer
  ON address_book.address = received_transfer.address
LEFT JOIN core_address_labels_view label_view
  ON address_book.address = label_view.address;

CREATE VIEW IF NOT EXISTS core_transfers_usd_view AS
SELECT
  transfer.block_date,
  transfer.block_height,
  transfer.tx_id,
  transfer.event_index,
  transfer.edge_index,
  transfer.from_address,
  transfer.to_address,
  asset.asset_contract,
  asset.asset_symbol,
  transfer.amount,
  price.price_usd,
  CAST(transfer.amount * COALESCE(price.price_usd, 0) AS DECIMAL(38,8)) AS amount_usd,
  transfer.block_timestamp
FROM core_transfers AS transfer
JOIN core_assets AS asset
  ON transfer.asset_id = asset.asset_id
LEFT JOIN core_asset_prices_latest_view AS price
  ON asset.asset_contract = price.asset_contract
 AND transfer.block_date = price.price_date;

CREATE VIEW IF NOT EXISTS core_money_flows_daily_features_view AS
SELECT
  flow.activity_date,
  flow.flow_id,
  flow.from_address,
  flow.to_address,
  asset.asset_contract,
  asset.asset_symbol,
  flow.tx_count,
  flow.amount_sum,
  flow.first_seen_timestamp,
  flow.last_seen_timestamp,
  flow.first_tx_id,
  flow.last_tx_id,
  flow.source_window_start_height,
  flow.source_window_end_height,
  flow.source_batch_label,
  flow.refreshed_at,
  CASE
    WHEN flow.tx_count > 0 THEN flow.amount_sum / flow.tx_count
    ELSE 0
  END AS avg_transfer_amount,
  GREATEST(1, CAST((flow.last_seen_timestamp - flow.first_seen_timestamp) / 86400000 AS INT)) AS active_days
FROM core_money_flows_daily AS flow
JOIN core_assets AS asset
  ON flow.asset_id = asset.asset_id;

CREATE VIEW IF NOT EXISTS core_money_flows_daily_usd_view AS
SELECT
  money_flow.activity_date,
  money_flow.flow_id,
  money_flow.from_address,
  money_flow.to_address,
  money_flow.asset_contract,
  money_flow.asset_symbol,
  money_flow.tx_count,
  money_flow.amount_sum,
  price.price_usd,
  CAST(money_flow.amount_sum * COALESCE(price.price_usd, 0) AS DECIMAL(38,8)) AS amount_usd_sum,
  money_flow.first_seen_timestamp,
  money_flow.last_seen_timestamp,
  money_flow.first_tx_id,
  money_flow.last_tx_id,
  money_flow.source_window_start_height,
  money_flow.source_window_end_height,
  money_flow.source_batch_label,
  money_flow.refreshed_at,
  price.price_usd IS NULL AS price_missing
FROM core_money_flows_daily_features_view AS money_flow
LEFT JOIN core_asset_prices_latest_view AS price
  ON money_flow.asset_contract = price.asset_contract
 AND money_flow.activity_date = price.price_date;

CREATE VIEW IF NOT EXISTS core_money_flows_graphrag_view AS
WITH pair_totals AS (
  SELECT
    MAX(activity_date) AS day,
    from_address,
    to_address,
    SUM(tx_count) AS tx_count,
    SUM(amount_sum) AS amount_sum,
    SUM(amount_usd_sum) AS amount_usd_sum,
    MIN(first_seen_timestamp) AS first_seen_timestamp,
    MAX(last_seen_timestamp) AS last_seen_timestamp,
    COUNT(DISTINCT asset_contract) AS unique_assets,
    MAX(asset_symbol) AS dominant_asset,
    MAX(CASE WHEN price_missing THEN 1 ELSE 0 END) AS has_missing_price
  FROM core_money_flows_daily_usd_view
  GROUP BY from_address, to_address
)
SELECT
  day,
  from_address,
  to_address,
  tx_count,
  amount_sum,
  amount_usd_sum,
  first_seen_timestamp,
  last_seen_timestamp,
  GREATEST(1, CAST((last_seen_timestamp - first_seen_timestamp) / 86400000 AS INT)) AS active_days,
  CASE WHEN tx_count > 0 THEN amount_usd_sum / tx_count ELSE 0 END AS avg_tx_size_usd,
  unique_assets,
  dominant_asset,
  has_missing_price,
  CAST(0 AS DECIMAL(38,8)) AS reciprocity_ratio,
  FALSE AS is_bidirectional
FROM pair_totals;

CREATE VIEW IF NOT EXISTS core_money_flows_analyzer_view AS
WITH pair_totals AS (
  SELECT * FROM core_money_flows_graphrag_view
),
reciprocity AS (
  SELECT
    first_pair.from_address,
    first_pair.to_address,
    CASE
      WHEN second_pair.amount_usd_sum > 0 AND first_pair.amount_usd_sum > 0
      THEN LEAST(first_pair.amount_usd_sum, second_pair.amount_usd_sum) / GREATEST(first_pair.amount_usd_sum, second_pair.amount_usd_sum)
      ELSE 0
    END AS reciprocity_ratio,
    second_pair.amount_usd_sum > 0 AS is_bidirectional
  FROM pair_totals first_pair
  LEFT JOIN pair_totals second_pair
    ON first_pair.from_address = second_pair.to_address
   AND first_pair.to_address = second_pair.from_address
)
SELECT
  pair_totals.day,
  pair_totals.from_address,
  pair_totals.to_address,
  pair_totals.tx_count,
  pair_totals.amount_sum,
  pair_totals.amount_usd_sum,
  pair_totals.first_seen_timestamp,
  pair_totals.last_seen_timestamp,
  pair_totals.active_days,
  pair_totals.avg_tx_size_usd,
  pair_totals.unique_assets,
  pair_totals.dominant_asset,
  COALESCE(reciprocity.reciprocity_ratio, CAST(0 AS DECIMAL(38,8))) AS reciprocity_ratio,
  COALESCE(reciprocity.is_bidirectional, FALSE) AS is_bidirectional,
  pair_totals.has_missing_price
FROM pair_totals
LEFT JOIN reciprocity
  ON pair_totals.from_address = reciprocity.from_address
 AND pair_totals.to_address = reciprocity.to_address;

CREATE VIEW IF NOT EXISTS money_flows AS
SELECT
  day,
  from_address,
  to_address,
  tx_count,
  amount_sum,
  amount_usd_sum,
  first_seen_timestamp,
  last_seen_timestamp,
  active_days,
  avg_tx_size_usd,
  unique_assets,
  dominant_asset,
  reciprocity_ratio,
  is_bidirectional,
  has_missing_price
FROM core_money_flows_analyzer_view;

-- ============================================================================
-- Analyzer output tables (analyzers_*)
--
-- Owned by analyzers-baseline. Created here so the schema is one canonical
-- source of truth for every table that lives in a chain database. Conventions
-- match the core_* tables: VARCHAR(80) addresses, bloom filters on hot
-- address columns, ZSTD compression, #G timestamp policy (chain-derived
-- BIGINT, operational DATETIME), dominant_asset_id_* FK to core_assets.
-- ============================================================================

CREATE TABLE IF NOT EXISTS analyzers_features (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  address VARCHAR(80) NOT NULL,
  degree_in INT NOT NULL,
  degree_out INT NOT NULL,
  unique_counterparties INT NOT NULL,
  total_in_usd DECIMAL(38,8) NOT NULL,
  total_out_usd DECIMAL(38,8) NOT NULL,
  net_flow_usd DECIMAL(38,8) NOT NULL,
  total_volume_usd DECIMAL(38,8) NOT NULL,
  avg_tx_in_usd DECIMAL(38,8) NOT NULL,
  avg_tx_out_usd DECIMAL(38,8) NOT NULL,
  median_tx_in_usd DECIMAL(38,8) NOT NULL,
  median_tx_out_usd DECIMAL(38,8) NOT NULL,
  max_tx_usd DECIMAL(38,8) NOT NULL,
  min_tx_usd DECIMAL(38,8) NOT NULL,
  amount_variance DOUBLE NOT NULL,
  amount_skewness DOUBLE NOT NULL,
  amount_kurtosis DOUBLE NOT NULL,
  volume_std DOUBLE NOT NULL,
  volume_cv DOUBLE NOT NULL,
  flow_concentration DOUBLE NOT NULL,
  tx_in_count BIGINT NOT NULL,
  tx_out_count BIGINT NOT NULL,
  tx_total_count BIGINT NOT NULL,
  activity_days INT NOT NULL,
  activity_span_days INT NOT NULL,
  avg_daily_volume_usd DECIMAL(38,8) NOT NULL,
  burst_factor FLOAT NOT NULL,
  reciprocity_ratio FLOAT NOT NULL,
  flow_diversity FLOAT NOT NULL,
  counterparty_concentration FLOAT NOT NULL,
  concentration_ratio FLOAT NOT NULL,
  velocity_score FLOAT NOT NULL,
  unique_assets_in INT NOT NULL,
  unique_assets_out INT NOT NULL,
  dominant_asset_id_in BIGINT NOT NULL,
  dominant_asset_id_out BIGINT NOT NULL,
  asset_diversity_score FLOAT NOT NULL,
  hourly_activity ARRAY<INT> NOT NULL,
  daily_activity ARRAY<INT> NOT NULL,
  peak_activity_hour INT NOT NULL,
  peak_activity_day INT NOT NULL,
  hourly_entropy FLOAT NOT NULL,
  daily_entropy FLOAT NOT NULL,
  weekend_transaction_ratio FLOAT NOT NULL,
  night_transaction_ratio FLOAT NOT NULL,
  small_transaction_ratio FLOAT NOT NULL,
  consistency_score FLOAT NOT NULL,
  pagerank FLOAT NOT NULL,
  betweenness FLOAT NOT NULL,
  closeness FLOAT NOT NULL,
  clustering_coefficient FLOAT NOT NULL,
  kcore INT NOT NULL,
  community_id INT NOT NULL,
  centrality_score FLOAT NOT NULL,
  khop1_count INT NOT NULL,
  khop2_count INT NOT NULL,
  khop3_count INT NOT NULL,
  khop1_volume_usd DECIMAL(38,8) NOT NULL,
  khop2_volume_usd DECIMAL(38,8) NOT NULL,
  khop3_volume_usd DECIMAL(38,8) NOT NULL,
  flow_reciprocity_entropy FLOAT NOT NULL,
  counterparty_stability FLOAT NOT NULL,
  flow_burstiness FLOAT NOT NULL,
  transaction_regularity FLOAT NOT NULL,
  amount_predictability FLOAT NOT NULL,
  avg_relationship_age_days INT NOT NULL,
  max_relationship_age_days INT NOT NULL,
  bidirectional_relationship_ratio FLOAT NOT NULL,
  avg_edge_reciprocity FLOAT NOT NULL,
  multi_asset_edge_ratio FLOAT NOT NULL,
  edge_hourly_entropy FLOAT NOT NULL,
  edge_weekly_entropy FLOAT NOT NULL,
  is_new_address BOOLEAN NOT NULL,
  is_dormant_reactivated BOOLEAN NOT NULL,
  unique_recipients_count INT NOT NULL,
  unique_senders_count INT NOT NULL,
  first_activity_timestamp BIGINT NOT NULL,
  last_activity_timestamp BIGINT NOT NULL,
  inter_tx_gap_mean FLOAT NOT NULL,
  inter_tx_gap_std FLOAT NOT NULL,
  inter_tx_gap_min FLOAT NOT NULL,
  inter_tx_gap_max FLOAT NOT NULL,
  inter_tx_gap_cv FLOAT NOT NULL
)
PRIMARY KEY(window_days, processing_date, address)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_cycle (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  flow_path ARRAY<STRING> NOT NULL,
  cycle_length INT NOT NULL,
  flow_volume_usd DECIMAL(38,8) NOT NULL,
  source_address VARCHAR(80) NOT NULL,
  destination_address VARCHAR(80) NOT NULL,
  is_wash_trading BOOLEAN NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "source_address, destination_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_layering (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  flow_path ARRAY<STRING> NOT NULL,
  layer_count INT NOT NULL,
  flow_volume_usd DECIMAL(38,8) NOT NULL,
  source_address VARCHAR(80) NOT NULL,
  destination_address VARCHAR(80) NOT NULL,
  layering_score FLOAT NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "source_address, destination_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_network (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  hub_addresses ARRAY<STRING> NOT NULL,
  network_size INT NOT NULL,
  network_density FLOAT NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_proximity (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  primary_address VARCHAR(80) NOT NULL,
  risk_address VARCHAR(80) NOT NULL,
  hop_distance INT NOT NULL,
  proximity_score FLOAT NOT NULL,
  risk_type VARCHAR(128) NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "primary_address, risk_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_motif (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  hub_address VARCHAR(80) NOT NULL,
  motif_type VARCHAR(128) NOT NULL,
  motif_size INT NOT NULL,
  flow_volume_usd DECIMAL(38,8) NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "hub_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_burst (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  primary_address VARCHAR(80) NOT NULL,
  burst_intensity FLOAT NOT NULL,
  z_score FLOAT NOT NULL,
  burst_start_timestamp BIGINT NOT NULL,
  burst_end_timestamp BIGINT NOT NULL,
  burst_tx_rate FLOAT NOT NULL,
  normal_tx_rate FLOAT NOT NULL,
  hourly_distribution ARRAY<INT> NOT NULL,
  peak_hours ARRAY<INT> NOT NULL,
  flow_path ARRAY<STRING> NOT NULL,
  flow_volume_usd DECIMAL(38,8) NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "primary_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_threshold (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  primary_address VARCHAR(80) NOT NULL,
  threshold_value DECIMAL(38,8) NOT NULL,
  threshold_type VARCHAR(128) NOT NULL,
  threshold_avoidance_score FLOAT NOT NULL,
  clustering_score FLOAT NOT NULL,
  transactions_near_threshold INT NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "primary_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS analyzers_patterns_dormant (
  window_days INT NOT NULL,
  processing_date DATE NOT NULL,
  pattern_hash VARCHAR(256) NOT NULL,
  pattern_id VARCHAR(256) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  addresses_involved ARRAY<STRING> NOT NULL,
  address_roles ARRAY<STRING> NOT NULL,
  pattern_start_time BIGINT NOT NULL,
  pattern_end_time BIGINT NOT NULL,
  pattern_duration_hours FLOAT NOT NULL,
  evidence_transaction_count INT NOT NULL,
  evidence_volume_usd DECIMAL(38,8) NOT NULL,
  detection_timestamp DATETIME NOT NULL,
  detection_method VARCHAR(256) NOT NULL,
  dormant_address VARCHAR(80) NOT NULL,
  dormant_days INT NOT NULL,
  reactivation_volume_usd DECIMAL(38,8) NOT NULL,
  reactivation_transaction_count INT NOT NULL,
  previous_last_seen_timestamp BIGINT NOT NULL,
  reactivation_timestamp BIGINT NOT NULL
)
PRIMARY KEY(window_days, processing_date, pattern_hash)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(pattern_hash) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "dormant_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

-- ============================================================================
-- ML model tables (ml_*)
--
-- Owned by ml-models.  Same conventions as core_* and analyzers_*: VARCHAR(80)
-- addresses, bloom_filter_columns on hot point-lookup columns, ZSTD compression,
-- StarRocks PRIMARY KEY tables (the legacy ClickHouse ReplacingMergeTree(_version)
-- DDLs were translated to StarRocks PK syntax; the upsert semantic comes from
-- the PK natively, no _version column needed).  No `network` column under the
-- single-DB-per-network model.
-- ============================================================================

CREATE TABLE IF NOT EXISTS ml_if_scores (
  processing_date DATE NOT NULL,
  address VARCHAR(80) NOT NULL,
  model_version VARCHAR(128) NOT NULL,
  cycle_anomaly_score FLOAT NOT NULL,
  layering_anomaly_score FLOAT NOT NULL,
  burst_anomaly_score FLOAT NOT NULL,
  threshold_anomaly_score FLOAT NOT NULL
)
PRIMARY KEY(processing_date, address, model_version)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_training_metrics (
  model_version VARCHAR(128) NOT NULL,
  processing_date DATE NOT NULL,
  auc_roc DOUBLE NOT NULL,
  test_auc_roc DOUBLE NOT NULL DEFAULT "0.0",
  is_champion BOOLEAN NOT NULL DEFAULT "false",
  training_mode VARCHAR(64) NOT NULL DEFAULT ""
)
PRIMARY KEY(model_version)
DISTRIBUTED BY HASH(model_version) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_predictions (
  processing_date DATE NOT NULL,
  address VARCHAR(80) NOT NULL,
  xgboost_model_version VARCHAR(128) NOT NULL,
  window_days INT NOT NULL,
  gnn_model_version VARCHAR(128) NOT NULL,
  risk_score FLOAT NOT NULL,
  risk_level VARCHAR(32) NOT NULL,
  shap_top_features ARRAY<STRING> NOT NULL,
  shap_top_values ARRAY<FLOAT> NOT NULL
)
PRIMARY KEY(processing_date, address, xgboost_model_version)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_shap_values (
  processing_date DATE NOT NULL,
  address VARCHAR(80) NOT NULL,
  xgboost_model_version VARCHAR(128) NOT NULL
  -- shap_<feature> FLOAT NOT NULL DEFAULT "0.0"  -- added at runtime per feature
)
PRIMARY KEY(processing_date, address, xgboost_model_version)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_model_registry (
  artifact_type VARCHAR(64) NOT NULL,
  model_version VARCHAR(128) NOT NULL,
  processing_date DATE NOT NULL,
  window_days INT NOT NULL,
  metric_name VARCHAR(64) NOT NULL,
  metric_value DOUBLE NOT NULL,
  is_champion BOOLEAN NOT NULL DEFAULT "false",
  artifact_path VARCHAR(512) NOT NULL DEFAULT "",
  github_release_tag VARCHAR(128) NOT NULL DEFAULT ""
)
PRIMARY KEY(artifact_type, model_version)
DISTRIBUTED BY HASH(artifact_type, model_version) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_gnn_embeddings (
  processing_date DATE NOT NULL,
  address VARCHAR(80) NOT NULL,
  model_version VARCHAR(128) NOT NULL,
  emb_alltime_0 FLOAT NOT NULL,
  emb_alltime_1 FLOAT NOT NULL,
  emb_alltime_2 FLOAT NOT NULL,
  emb_alltime_3 FLOAT NOT NULL,
  emb_alltime_4 FLOAT NOT NULL,
  emb_alltime_5 FLOAT NOT NULL,
  emb_alltime_6 FLOAT NOT NULL,
  emb_alltime_7 FLOAT NOT NULL,
  emb_alltime_8 FLOAT NOT NULL,
  emb_alltime_9 FLOAT NOT NULL,
  emb_alltime_10 FLOAT NOT NULL,
  emb_alltime_11 FLOAT NOT NULL,
  emb_alltime_12 FLOAT NOT NULL,
  emb_alltime_13 FLOAT NOT NULL,
  emb_alltime_14 FLOAT NOT NULL,
  emb_alltime_15 FLOAT NOT NULL,
  emb_alltime_16 FLOAT NOT NULL,
  emb_alltime_17 FLOAT NOT NULL,
  emb_alltime_18 FLOAT NOT NULL,
  emb_alltime_19 FLOAT NOT NULL,
  emb_alltime_20 FLOAT NOT NULL,
  emb_alltime_21 FLOAT NOT NULL,
  emb_alltime_22 FLOAT NOT NULL,
  emb_alltime_23 FLOAT NOT NULL,
  emb_alltime_24 FLOAT NOT NULL,
  emb_alltime_25 FLOAT NOT NULL,
  emb_alltime_26 FLOAT NOT NULL,
  emb_alltime_27 FLOAT NOT NULL,
  emb_alltime_28 FLOAT NOT NULL,
  emb_alltime_29 FLOAT NOT NULL,
  emb_alltime_30 FLOAT NOT NULL,
  emb_alltime_31 FLOAT NOT NULL,
  emb_alltime_32 FLOAT NOT NULL,
  emb_alltime_33 FLOAT NOT NULL,
  emb_alltime_34 FLOAT NOT NULL,
  emb_alltime_35 FLOAT NOT NULL,
  emb_alltime_36 FLOAT NOT NULL,
  emb_alltime_37 FLOAT NOT NULL,
  emb_alltime_38 FLOAT NOT NULL,
  emb_alltime_39 FLOAT NOT NULL,
  emb_alltime_40 FLOAT NOT NULL,
  emb_alltime_41 FLOAT NOT NULL,
  emb_alltime_42 FLOAT NOT NULL,
  emb_alltime_43 FLOAT NOT NULL,
  emb_alltime_44 FLOAT NOT NULL,
  emb_alltime_45 FLOAT NOT NULL,
  emb_alltime_46 FLOAT NOT NULL,
  emb_alltime_47 FLOAT NOT NULL,
  emb_alltime_48 FLOAT NOT NULL,
  emb_alltime_49 FLOAT NOT NULL,
  emb_alltime_50 FLOAT NOT NULL,
  emb_alltime_51 FLOAT NOT NULL,
  emb_alltime_52 FLOAT NOT NULL,
  emb_alltime_53 FLOAT NOT NULL,
  emb_alltime_54 FLOAT NOT NULL,
  emb_alltime_55 FLOAT NOT NULL,
  emb_alltime_56 FLOAT NOT NULL,
  emb_alltime_57 FLOAT NOT NULL,
  emb_alltime_58 FLOAT NOT NULL,
  emb_alltime_59 FLOAT NOT NULL,
  emb_alltime_60 FLOAT NOT NULL,
  emb_alltime_61 FLOAT NOT NULL,
  emb_alltime_62 FLOAT NOT NULL,
  emb_alltime_63 FLOAT NOT NULL,
  emb_30d_0 FLOAT NOT NULL,
  emb_30d_1 FLOAT NOT NULL,
  emb_30d_2 FLOAT NOT NULL,
  emb_30d_3 FLOAT NOT NULL,
  emb_30d_4 FLOAT NOT NULL,
  emb_30d_5 FLOAT NOT NULL,
  emb_30d_6 FLOAT NOT NULL,
  emb_30d_7 FLOAT NOT NULL,
  emb_30d_8 FLOAT NOT NULL,
  emb_30d_9 FLOAT NOT NULL,
  emb_30d_10 FLOAT NOT NULL,
  emb_30d_11 FLOAT NOT NULL,
  emb_30d_12 FLOAT NOT NULL,
  emb_30d_13 FLOAT NOT NULL,
  emb_30d_14 FLOAT NOT NULL,
  emb_30d_15 FLOAT NOT NULL,
  emb_30d_16 FLOAT NOT NULL,
  emb_30d_17 FLOAT NOT NULL,
  emb_30d_18 FLOAT NOT NULL,
  emb_30d_19 FLOAT NOT NULL,
  emb_30d_20 FLOAT NOT NULL,
  emb_30d_21 FLOAT NOT NULL,
  emb_30d_22 FLOAT NOT NULL,
  emb_30d_23 FLOAT NOT NULL,
  emb_30d_24 FLOAT NOT NULL,
  emb_30d_25 FLOAT NOT NULL,
  emb_30d_26 FLOAT NOT NULL,
  emb_30d_27 FLOAT NOT NULL,
  emb_30d_28 FLOAT NOT NULL,
  emb_30d_29 FLOAT NOT NULL,
  emb_30d_30 FLOAT NOT NULL,
  emb_30d_31 FLOAT NOT NULL,
  emb_30d_32 FLOAT NOT NULL,
  emb_30d_33 FLOAT NOT NULL,
  emb_30d_34 FLOAT NOT NULL,
  emb_30d_35 FLOAT NOT NULL,
  emb_30d_36 FLOAT NOT NULL,
  emb_30d_37 FLOAT NOT NULL,
  emb_30d_38 FLOAT NOT NULL,
  emb_30d_39 FLOAT NOT NULL,
  emb_30d_40 FLOAT NOT NULL,
  emb_30d_41 FLOAT NOT NULL,
  emb_30d_42 FLOAT NOT NULL,
  emb_30d_43 FLOAT NOT NULL,
  emb_30d_44 FLOAT NOT NULL,
  emb_30d_45 FLOAT NOT NULL,
  emb_30d_46 FLOAT NOT NULL,
  emb_30d_47 FLOAT NOT NULL,
  emb_30d_48 FLOAT NOT NULL,
  emb_30d_49 FLOAT NOT NULL,
  emb_30d_50 FLOAT NOT NULL,
  emb_30d_51 FLOAT NOT NULL,
  emb_30d_52 FLOAT NOT NULL,
  emb_30d_53 FLOAT NOT NULL,
  emb_30d_54 FLOAT NOT NULL,
  emb_30d_55 FLOAT NOT NULL,
  emb_30d_56 FLOAT NOT NULL,
  emb_30d_57 FLOAT NOT NULL,
  emb_30d_58 FLOAT NOT NULL,
  emb_30d_59 FLOAT NOT NULL,
  emb_30d_60 FLOAT NOT NULL,
  emb_30d_61 FLOAT NOT NULL,
  emb_30d_62 FLOAT NOT NULL,
  emb_30d_63 FLOAT NOT NULL
)
PRIMARY KEY(processing_date, address, model_version)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_gnn_properties (
  processing_date DATE NOT NULL,
  address VARCHAR(80) NOT NULL,
  model_version VARCHAR(128) NOT NULL,
  structural_role VARCHAR(64) NOT NULL,
  behavioral_drift FLOAT NOT NULL,
  playbook_similarity FLOAT NOT NULL
)
PRIMARY KEY(processing_date, address, model_version)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(address) BUCKETS 16
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_embedding_drift (
  run_date DATE NOT NULL,
  reference_date DATE NOT NULL,
  model_version VARCHAR(128) NOT NULL,
  drift_score FLOAT NOT NULL,
  recommendation VARCHAR(64) NOT NULL,
  n_addresses INT NOT NULL
)
PRIMARY KEY(run_date, reference_date, model_version)
DISTRIBUTED BY HASH(model_version) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS ml_label_validation_metrics (
  processing_date DATE NOT NULL,
  metric_type VARCHAR(64) NOT NULL,
  wallet_type VARCHAR(64) NOT NULL,
  metric_name VARCHAR(64) NOT NULL,
  metric_value DOUBLE NOT NULL,
  detail VARCHAR(1024) NOT NULL DEFAULT ""
)
PRIMARY KEY(processing_date, metric_type, wallet_type, metric_name)
DISTRIBUTED BY HASH(processing_date, metric_type) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

-- ============================================================================
-- Synthetics tables (synthetics_*)
--
-- Owned by synthetics.  Synthetic transfer + money-flow data used for ML
-- training.  Same conventions as core_*, analyzers_*, ml_*: VARCHAR(80)
-- addresses, bloom filters, ZSTD, no `network` column under
-- single-DB-per-network.  asset_contract stays denormalized as VARCHAR
-- because synthetics generates synthetic assets that are never registered
-- in core_assets (see spec for rationale).
-- ============================================================================

CREATE TABLE IF NOT EXISTS synthetics_datasets (
  processing_date DATE NOT NULL,
  window_days INT NOT NULL,
  iteration VARCHAR(128) NOT NULL,
  created_at DATETIME NOT NULL,
  transfer_count BIGINT NOT NULL,
  synthetic_count BIGINT NOT NULL,
  ground_truth_count BIGINT NOT NULL,
  pattern_types ARRAY<STRING> NOT NULL
)
PRIMARY KEY(processing_date, window_days, iteration)
DISTRIBUTED BY HASH(iteration) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS synthetics_transfers (
  processing_date DATE NOT NULL,
  window_days INT NOT NULL,
  iteration VARCHAR(128) NOT NULL,
  tx_id VARCHAR(108) NOT NULL,
  event_index INT NOT NULL,
  edge_index INT NOT NULL,
  block_height BIGINT NOT NULL,
  block_timestamp BIGINT NOT NULL,
  from_address VARCHAR(80) NOT NULL,
  to_address VARCHAR(80) NOT NULL,
  amount DECIMAL(38,18) NOT NULL,
  amount_usd DOUBLE NOT NULL,
  tx_origin VARCHAR(80) NOT NULL,
  asset_symbol VARCHAR(64) NOT NULL,
  asset_contract VARCHAR(80) NOT NULL,
  pattern_id VARCHAR(128) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL,
  is_synthetic BOOLEAN NOT NULL
)
PRIMARY KEY(processing_date, window_days, iteration, tx_id, event_index, edge_index)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(tx_id) BUCKETS 32
PROPERTIES (
  "bloom_filter_columns" = "from_address, to_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS synthetics_money_flows (
  processing_date DATE NOT NULL,
  window_days INT NOT NULL,
  iteration VARCHAR(128) NOT NULL,
  from_address VARCHAR(80) NOT NULL,
  to_address VARCHAR(80) NOT NULL,
  tx_count BIGINT NOT NULL,
  amount_usd_sum DOUBLE NOT NULL,
  first_seen_timestamp BIGINT NOT NULL,
  last_seen_timestamp BIGINT NOT NULL
)
DUPLICATE KEY(processing_date, window_days, iteration)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(from_address) BUCKETS 32
PROPERTIES (
  "bloom_filter_columns" = "from_address, to_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS synthetics_money_flows_daily (
  processing_date DATE NOT NULL,
  window_days INT NOT NULL,
  iteration VARCHAR(128) NOT NULL,
  activity_date DATE NOT NULL,
  from_address VARCHAR(80) NOT NULL,
  to_address VARCHAR(80) NOT NULL,
  from_address_display VARCHAR(80) NOT NULL,
  to_address_display VARCHAR(80) NOT NULL,
  tx_count BIGINT NOT NULL,
  amount_sum DOUBLE NOT NULL,
  first_seen_timestamp BIGINT NOT NULL,
  last_seen_timestamp BIGINT NOT NULL
)
DUPLICATE KEY(processing_date, window_days, iteration, activity_date)
PARTITION BY date_trunc('day', activity_date)
DISTRIBUTED BY HASH(from_address) BUCKETS 32
PROPERTIES (
  "bloom_filter_columns" = "from_address, to_address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS synthetics_ground_truth (
  processing_date DATE NOT NULL,
  window_days INT NOT NULL,
  iteration VARCHAR(128) NOT NULL,
  address VARCHAR(80) NOT NULL,
  pattern_id VARCHAR(128) NOT NULL,
  role VARCHAR(64) NOT NULL,
  pattern_type VARCHAR(128) NOT NULL
)
PRIMARY KEY(processing_date, window_days, iteration, address, pattern_id, role)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(address) BUCKETS 32
PROPERTIES (
  "bloom_filter_columns" = "address",
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);

CREATE TABLE IF NOT EXISTS synthetics_evaluation_results (
  processing_date DATE NOT NULL,
  window_days INT NOT NULL,
  iteration VARCHAR(128) NOT NULL,
  evaluated_at DATETIME NOT NULL,
  overall_score FLOAT NOT NULL,
  status VARCHAR(64) NOT NULL,
  amount_ks FLOAT NOT NULL,
  amount_mae FLOAT NOT NULL,
  hourly_cosine FLOAT NOT NULL,
  inter_tx_ks FLOAT NOT NULL,
  n_synthetic BIGINT NOT NULL,
  n_ground_truth BIGINT NOT NULL
)
PRIMARY KEY(processing_date, window_days, iteration)
PARTITION BY date_trunc('day', processing_date)
DISTRIBUTED BY HASH(iteration) BUCKETS 4
PROPERTIES (
  "replication_num" = "1",
  "enable_persistent_index" = "true",
  "compression" = "ZSTD"
);
