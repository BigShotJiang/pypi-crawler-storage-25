"""StarRocks warehouse abstraction for ChainSwarm consumers.

Provides a connection-pool-backed MySQL protocol client, an HTTP Stream Load
client with deterministic labels for idempotent fact writes, and a routing
adapter that combines them. Consumer code should depend on
``chainswarm_core.starrocks`` rather than re-implementing these primitives.

The adapter persists every Stream Load attempt in a ``_load_labels`` tracking
table so duplicate-label retries can be resolved deterministically.
``ensure_load_labels_table()`` provisions the DDL idempotently and is safe to
call at service startup.
"""

from chainswarm_core.starrocks.adapter import StarRocksWarehouseAdapter
from chainswarm_core.starrocks.client import (
    StarRocksClient,
    quote_identifier,
    validate_identifier,
)
from chainswarm_core.starrocks.config import StarRocksConfig
from chainswarm_core.starrocks.datetime_text import (
    DATETIME_FORMAT,
    to_datetime_text,
    utc_datetime_text,
)
from chainswarm_core.starrocks.identifiers import (
    EVM_NETWORKS,
    canonicalize_identifier,
    canonicalize_transfer_row,
    derive_asset_id,
)
from chainswarm_core.starrocks.labels import (
    StreamLoadLabelContext,
    build_payload_hash_prefix,
)
from chainswarm_core.starrocks.load_labels import (
    LOAD_LABELS_DDL,
    ensure_load_labels_table,
)
from chainswarm_core.starrocks.migrate import (
    DEFAULT_SCHEMA_PATH,
    bootstrap_schema,
    run_starrocks_schema,
    split_sql_statements,
)
from chainswarm_core.starrocks.repositories import AddressLabelRepository
from chainswarm_core.starrocks.stream_load import (
    DEFAULT_STREAM_LOAD_TABLES,
    StarRocksLoadError,
    StarRocksStreamLoadClient,
    StreamLoadOutcome,
    StreamLoadStatus,
)

__all__ = [
    "AddressLabelRepository",
    "DATETIME_FORMAT",
    "DEFAULT_SCHEMA_PATH",
    "DEFAULT_STREAM_LOAD_TABLES",
    "EVM_NETWORKS",
    "LOAD_LABELS_DDL",
    "StarRocksClient",
    "StarRocksConfig",
    "StarRocksLoadError",
    "StarRocksStreamLoadClient",
    "StarRocksWarehouseAdapter",
    "StreamLoadLabelContext",
    "StreamLoadOutcome",
    "StreamLoadStatus",
    "bootstrap_schema",
    "build_payload_hash_prefix",
    "canonicalize_identifier",
    "canonicalize_transfer_row",
    "derive_asset_id",
    "ensure_load_labels_table",
    "quote_identifier",
    "run_starrocks_schema",
    "split_sql_statements",
    "to_datetime_text",
    "utc_datetime_text",
    "validate_identifier",
]
