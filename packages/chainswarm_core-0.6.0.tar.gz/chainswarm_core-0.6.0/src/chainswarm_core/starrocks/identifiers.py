"""Canonical display-text helpers for StarRocks warehouse writes."""

from __future__ import annotations

import hashlib
import re
from collections.abc import Mapping
from typing import Any

EVM_NETWORKS = {"bittensor_evm", "ethereum", "base"}

_EVM_IDENTIFIER_LENGTHS = {
    "address": 40,
    "transaction_hash": 64,
    "tx_hash": 64,
    "tx_id": 64,
}

_ADDRESS_FIELDS = {"from_address", "to_address", "address", "related_address"}
_TRANSACTION_HASH_FIELDS = {"tx_id", "tx_hash", "transaction_hash", "first_tx_id", "last_tx_id"}
_OPTIONAL_ADDRESS_FIELDS = {"asset_contract", "contract_address"}


def canonicalize_identifier(network: str, value: str, identifier_type: str) -> str:
    """Return the StarRocks display-text representation for an identifier.

    Args:
        network: Chain/network name that determines EVM or chain-native rules.
        value: Identifier text from the normalizer or source row.
        identifier_type: Identifier category, such as ``address`` or
            ``transaction_hash``.

    Returns:
        Lowercase ``0x`` hex text for EVM identifiers, or the original
        chain-native text for non-EVM identifiers.

    Raises:
        ValueError: If a required identifier is empty or malformed.
    """
    _validate_non_empty_string(value, identifier_type)

    if network not in EVM_NETWORKS:
        return value

    expected_hex_length = _EVM_IDENTIFIER_LENGTHS.get(identifier_type)
    if expected_hex_length is None:
        return value

    if not re.fullmatch(rf"0[xX][0-9a-fA-F]{{{expected_hex_length}}}", value):
        raise ValueError(
            f"{network} {identifier_type} must be 0x-prefixed "
            f"{expected_hex_length}-character hex text"
        )

    return f"0x{value[2:].lower()}"


def canonicalize_transfer_row(network: str, row: Mapping[str, Any]) -> dict[str, Any]:
    """Return a transfer row with warehouse identifier fields normalized.

    Args:
        network: Chain/network name used for identifier normalization.
        row: Transfer fact row before StarRocks serialization.

    Returns:
        A copy of ``row`` with known address and transaction identifier fields
        normalized to the StarRocks display-text contract.
    """
    canonicalized_row = dict(row)
    for field_name, field_value in row.items():
        if field_name in _ADDRESS_FIELDS:
            canonicalized_row[field_name] = canonicalize_identifier(
                network,
                field_value,
                "address",
            )
        elif field_name in _TRANSACTION_HASH_FIELDS:
            canonicalized_row[field_name] = canonicalize_identifier(
                network,
                field_value,
                "transaction_hash",
            )
        elif field_name in _OPTIONAL_ADDRESS_FIELDS:
            canonicalized_row[field_name] = _canonicalize_optional_evm_address(
                network,
                field_value,
                field_name,
            )

    return canonicalized_row


def _canonicalize_optional_evm_address(
    network: str,
    value: Any,
    identifier_type: str,
) -> str:
    _validate_non_empty_string(value, identifier_type)
    if network in EVM_NETWORKS and value.lower().startswith("0x"):
        return canonicalize_identifier(network, value, "address")
    return value


def derive_asset_id(asset_contract: str) -> int:
    """Deterministic per-network BIGINT identifier for an asset contract.

    First 8 bytes of SHA-256 of the lowercased contract text, interpreted
    as a signed 64-bit integer. Same input always yields the same output.

    Per-network database scope (DB name == network name) bounds asset
    cardinality to ~thousands per chain, making 64-bit birthday-collision
    probability effectively zero (~1.4e-13). Stateless: writers compute
    IDs locally with no coordination.

    Args:
        asset_contract: Canonical asset contract text from the warehouse
            row (lowercase 0x-hex for EVM, chain-native text otherwise,
            'native' for the chain's native asset).

    Returns:
        Stable signed 64-bit integer suitable for the core_assets primary
        key and asset_id references in fact tables.

    Raises:
        ValueError: If asset_contract is empty or not a string.
    """
    if not isinstance(asset_contract, str) or not asset_contract.strip():
        raise ValueError("asset_contract must be a non-empty string")
    digest = hashlib.sha256(asset_contract.lower().encode()).digest()[:8]
    return int.from_bytes(digest, "big", signed=True)


def _validate_non_empty_string(value: Any, identifier_type: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{identifier_type} must be a non-empty string")
