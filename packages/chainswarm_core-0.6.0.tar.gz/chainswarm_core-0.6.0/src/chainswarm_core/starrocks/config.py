from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Mapping


STARROCKS_HTTP_PORT_DEFAULT = 8030
STARROCKS_POOL_SIZE_DEFAULT = 5
PORT_MINIMUM = 1
PORT_MAXIMUM = 65535


@dataclass(frozen=True)
class StarRocksConfig:
    """Validated StarRocks warehouse connection configuration."""

    host: str
    port: int
    http_port: int
    user: str
    password: str
    database: str
    backend_http_port: int | None = None
    pool_size: int = STARROCKS_POOL_SIZE_DEFAULT

    @property
    def is_configured(self) -> bool:
        """Return whether all required connection fields are populated."""
        return bool(
            self.host
            and self.port
            and self.http_port
            and self.user
            and self.database
            and self.pool_size
        )

    @classmethod
    def from_env(
        cls,
        environment: Mapping[str, str] | None = None,
    ) -> "StarRocksConfig":
        """Build StarRocks configuration from environment variable names.

        Args:
            environment: Optional mapping used by tests or callers that already
                captured process environment state.

        Returns:
            Strict StarRocks connection configuration.

        Raises:
            ValueError: If required variables are missing, ports are invalid, or
                the StarRocks password is empty.
        """
        source_environment = os.environ if environment is None else environment
        host = _required_variable(source_environment, "STARROCKS_HOST")
        port = _required_port(source_environment, "STARROCKS_PORT")
        http_port = _optional_port(
            source_environment,
            "STARROCKS_HTTP_PORT",
            STARROCKS_HTTP_PORT_DEFAULT,
        )
        backend_http_port = _optional_port_or_none(
            source_environment,
            "STARROCKS_BE_HTTP_PORT",
        )
        user = _required_variable(source_environment, "STARROCKS_USER")
        password = _required_password(source_environment)
        database = _required_variable(source_environment, "STARROCKS_DATABASE")
        pool_size = _optional_positive_integer(
            source_environment,
            "STARROCKS_POOL_SIZE",
            STARROCKS_POOL_SIZE_DEFAULT,
        )

        return cls(
            host=host,
            port=port,
            http_port=http_port,
            user=user,
            password=password,
            database=database,
            backend_http_port=backend_http_port,
            pool_size=pool_size,
        )


def _required_variable(
    environment: Mapping[str, str],
    variable_name: str,
) -> str:
    """Return a required non-empty environment value."""
    if variable_name not in environment or environment[variable_name] == "":
        raise ValueError(f"{variable_name} is required")
    return environment[variable_name]


def _required_integer(
    environment: Mapping[str, str],
    variable_name: str,
) -> int:
    """Return a required integer environment value."""
    value = _required_variable(environment, variable_name)
    try:
        return int(value)
    except ValueError as error:
        raise ValueError(f"{variable_name} must be an integer") from error


def _optional_integer(
    environment: Mapping[str, str],
    variable_name: str,
    default: int,
) -> int:
    """Return an optional integer environment value with an explicit default."""
    if variable_name not in environment:
        return default

    try:
        return int(environment[variable_name])
    except ValueError as error:
        raise ValueError(f"{variable_name} must be an integer") from error


def _required_port(
    environment: Mapping[str, str],
    variable_name: str,
) -> int:
    """Return a required TCP port environment value."""
    return _validate_port(variable_name, _required_integer(environment, variable_name))


def _optional_port(
    environment: Mapping[str, str],
    variable_name: str,
    default: int,
) -> int:
    """Return an optional TCP port environment value."""
    return _validate_port(
        variable_name,
        _optional_integer(environment, variable_name, default),
    )


def _optional_port_or_none(
    environment: Mapping[str, str],
    variable_name: str,
) -> int | None:
    """Return an optional TCP port when a variable is present."""
    if variable_name not in environment:
        return None
    return _validate_port(variable_name, _required_integer(environment, variable_name))


def _validate_port(variable_name: str, value: int) -> int:
    if not PORT_MINIMUM <= value <= PORT_MAXIMUM:
        raise ValueError(
            f"{variable_name} must be between {PORT_MINIMUM} and {PORT_MAXIMUM}"
        )
    return value


def _optional_positive_integer(
    environment: Mapping[str, str],
    variable_name: str,
    default: int,
) -> int:
    """Return an optional positive integer environment value."""
    value = _optional_integer(environment, variable_name, default)
    if value < 1:
        raise ValueError(f"{variable_name} must be a positive integer")
    return value


def _required_password(
    environment: Mapping[str, str],
) -> str:
    """Return a required non-empty password."""
    if "STARROCKS_PASSWORD" not in environment:
        raise ValueError("STARROCKS_PASSWORD is required")

    password = environment["STARROCKS_PASSWORD"]
    if password != "":
        return password

    raise ValueError("STARROCKS_PASSWORD cannot be empty")
