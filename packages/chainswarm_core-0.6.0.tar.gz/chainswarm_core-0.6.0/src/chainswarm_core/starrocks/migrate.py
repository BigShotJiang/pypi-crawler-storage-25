"""StarRocks schema bootstrap helpers.

Owns the canonical ``schema.sql`` for the ChainSwarm platform — every per-network
StarRocks database (`bittensor`, `bittensor_evm`, `base`, `ethereum`, `bitcoin`)
gets the same shared schema applied via ``bootstrap_schema(network)``. Tables
are scoped by owning subsystem prefix (`core_*`, `analyzers_*`, `ml_*`,
`synthetics_*`) but the DDL is shared infrastructure.

The functions are idempotent (every CREATE statement is `IF NOT EXISTS`), safe
to call concurrently, and safe to call on every service start.
"""

from __future__ import annotations

from pathlib import Path

from .client import StarRocksClient
from .config import StarRocksConfig

DEFAULT_SCHEMA_PATH = Path(__file__).with_name("schema.sql")


def split_sql_statements(sql: str) -> list[str]:
    """Split SQL text into executable statements.

    Args:
        sql: SQL text that may contain comments, quoted strings, and multiple
            semicolon-terminated statements.

    Returns:
        Executable SQL statements with comments removed.
    """
    statements: list[str] = []
    current: list[str] = []
    in_single = False
    in_double = False
    in_line_comment = False
    in_block_comment = False
    position = 0

    while position < len(sql):
        character = sql[position]
        next_character = sql[position + 1] if position + 1 < len(sql) else ""

        if in_line_comment:
            if character == "\n":
                in_line_comment = False
                current.append(character)
            position += 1
            continue

        if in_block_comment:
            if character == "*" and next_character == "/":
                in_block_comment = False
                position += 2
                continue
            position += 1
            continue

        if not in_single and not in_double:
            if character == "-" and next_character == "-":
                in_line_comment = True
                position += 2
                continue
            if character == "/" and next_character == "*":
                in_block_comment = True
                position += 2
                continue

        if character == "'" and in_single and next_character == "'":
            current.append(character)
            current.append(next_character)
            position += 2
            continue

        if character == '"' and in_double and next_character == '"':
            current.append(character)
            current.append(next_character)
            position += 2
            continue

        if character == "'" and not in_double:
            in_single = not in_single
        elif character == '"' and not in_single:
            in_double = not in_double

        if character == ";" and not in_single and not in_double:
            statement = "".join(current).strip()
            if statement:
                statements.append(statement)
            current.clear()
        else:
            current.append(character)

        position += 1

    tail = "".join(current).strip()
    if tail:
        statements.append(tail)
    return statements


def run_starrocks_schema(
    client: StarRocksClient,
    schema_path: Path | None = None,
) -> int:
    """Run the StarRocks schema file through the provided MySQL client.

    Args:
        client: StarRocks MySQL protocol client used for DDL execution.
        schema_path: Optional schema path. Defaults to chainswarm-core's
            bundled ``schema.sql`` — the canonical platform schema. Pass a
            path only for tests or alternate bootstrap entry points.

    Returns:
        Number of SQL statements executed.
    """
    path = schema_path or DEFAULT_SCHEMA_PATH
    count = 0
    for statement in split_sql_statements(path.read_text()):
        client.execute(statement)
        count += 1
    return count


def bootstrap_schema(
    network: str,
    schema_path: Path | None = None,
) -> None:
    """Bootstrap the StarRocks schema for the given network.

    Convenience wrapper for service startup paths. Reads ``STARROCKS_*``
    environment variables (overriding ``STARROCKS_DATABASE`` with ``network``)
    and runs the canonical platform ``schema.sql`` shipped with chainswarm-core.

    Args:
        network: Network database name (`bittensor`, `bittensor_evm`,
            `base`, `ethereum`, `bitcoin`). Becomes ``STARROCKS_DATABASE``
            for the duration of the call.
        schema_path: Optional schema path. Defaults to chainswarm-core's
            bundled ``schema.sql``.

    Raises:
        ValueError: ``network`` is empty.
        Any StarRocks-side DDL error — propagates unchanged so the caller
            sees the real cause.

    Example:
        >>> bootstrap_schema("bittensor")
    """
    if not network:
        raise ValueError("network must be non-empty")

    base_configuration = StarRocksConfig.from_env()
    network_configuration = StarRocksConfig(
        host=base_configuration.host,
        port=base_configuration.port,
        http_port=base_configuration.http_port,
        user=base_configuration.user,
        password=base_configuration.password,
        database=network,
        backend_http_port=base_configuration.backend_http_port,
        pool_size=base_configuration.pool_size,
    )
    client = StarRocksClient(network_configuration)
    run_starrocks_schema(client, schema_path=schema_path)
