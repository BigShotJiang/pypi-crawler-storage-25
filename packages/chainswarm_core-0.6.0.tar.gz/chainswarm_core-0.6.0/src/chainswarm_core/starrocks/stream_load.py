"""HTTP Stream Load client for deterministic StarRocks fact writes."""

from __future__ import annotations

import json
from collections.abc import Iterable, Sequence
from dataclasses import dataclass, replace
from enum import Enum
from typing import Any
from urllib.parse import urljoin, urlparse, urlunparse

import requests
from loguru import logger

from .client import validate_identifier
from .config import StarRocksConfig
from .labels import StreamLoadLabelContext

DEFAULT_STREAM_LOAD_TABLES = {
    "core_transfers",
    "core_block_stream",
    "core_block_stream_utxo_outputs",
    "core_money_flows_daily",
    "analyzers_features",
    "_load_labels",
}


class StreamLoadStatus(str, Enum):
    """Typed StarRocks Stream Load result categories."""

    SUCCESS = "success"
    DUPLICATE_LABEL = "duplicate_label"
    PUBLISH_TIMEOUT = "publish_timeout"
    FILTERED_ROWS = "filtered_rows"
    FAILED = "failed"


@dataclass(frozen=True)
class StreamLoadOutcome:
    """Parsed StarRocks Stream Load response without raw HTTP response leakage."""

    status: StreamLoadStatus
    label: str
    loaded_rows: int
    filtered_rows: int
    message: str
    error_url: str | None
    payload_hash_prefix: str
    duplicate_identity_matches: bool = False

    @property
    def is_committed(self) -> bool:
        """Return whether callers may treat this load as durably committed."""
        return self.status in {
            StreamLoadStatus.SUCCESS,
            StreamLoadStatus.PUBLISH_TIMEOUT,
        } or (
            self.status is StreamLoadStatus.DUPLICATE_LABEL
            and self.duplicate_identity_matches
        )

    def with_duplicate_identity_match(
        self,
        duplicate_identity_matches: bool,
    ) -> "StreamLoadOutcome":
        """Return a copy with duplicate identity resolution attached."""
        return replace(
            self,
            duplicate_identity_matches=duplicate_identity_matches,
        )


class StarRocksLoadError(RuntimeError):
    """Raised when a Stream Load request cannot be constructed or parsed."""


class StarRocksStreamLoadClient:
    """Execute StarRocks HTTP Stream Load requests for allowlisted tables."""

    def __init__(
        self,
        config: StarRocksConfig,
        allowed_tables: Iterable[str] | None = None,
        request_timeout_seconds: int = 100,
    ) -> None:
        if not config.is_configured:
            raise ValueError("StarRocksConfig is not configured")
        if request_timeout_seconds <= 0:
            raise ValueError("request_timeout_seconds must be positive")

        self.config = config
        self.allowed_tables = set(allowed_tables or DEFAULT_STREAM_LOAD_TABLES)
        self.request_timeout_seconds = request_timeout_seconds

    def load_csv(
        self,
        table_name: str,
        columns: Sequence[str],
        rows: Iterable[Sequence[Any]],
        label_context: StreamLoadLabelContext,
    ) -> StreamLoadOutcome:
        """Load rows through the JSON Stream Load path."""
        return self.load_json(table_name, columns, rows, label_context)

    def load_json(
        self,
        table_name: str,
        columns: Sequence[str],
        rows: Iterable[Sequence[Any]],
        label_context: StreamLoadLabelContext,
    ) -> StreamLoadOutcome:
        """Load JSON rows into an allowlisted StarRocks table."""
        self._validate_table_name(table_name)
        if not columns:
            raise StarRocksLoadError("columns must be non-empty")
        validated_columns = [
            _validate_stream_load_identifier(column, "column") for column in columns
        ]

        materialized_rows = list(rows)
        label = label_context.to_label()
        url = (
            f"http://{self.config.host}:{self.config.http_port}/api/"
            f"{self.config.database}/{table_name}/_stream_load"
        )
        headers = {
            "label": label,
            "Expect": "100-continue",
            "timeout": str(self.request_timeout_seconds),
            "max_filter_ratio": "0",
            "format": "json",
            "strip_outer_array": "true",
            "columns": ",".join(validated_columns),
        }
        json_payload = _rows_to_json_payload(
            validated_columns,
            materialized_rows,
        )

        try:
            http_response = self._put_with_starrocks_redirect(
                url,
                json_payload,
                headers,
            )
            http_response.raise_for_status()
            response_payload = http_response.json()
        except Exception as error:
            raise StarRocksLoadError(
                f"StarRocks Stream Load failed for table {table_name} "
                f"label {label}: {type(error).__name__}"
            ) from error

        outcome = self._parse_response_payload(response_payload, label_context)
        logger.info(
            "StarRocks Stream Load completed",
            extra={
                "table_name": table_name,
                "label": outcome.label,
                "status": outcome.status.value,
                "loaded_rows": outcome.loaded_rows,
                "filtered_rows": outcome.filtered_rows,
            },
        )
        return outcome

    def _put_with_starrocks_redirect(
        self,
        url: str,
        payload: str,
        headers: dict[str, str],
    ) -> requests.Response:
        """PUT Stream Load payloads and preserve auth across FE redirects."""
        request_keyword_arguments = {
            "data": payload,
            "headers": headers,
            "auth": (self.config.user, self.config.password),
            "timeout": self.request_timeout_seconds,
            "allow_redirects": False,
        }
        http_response = requests.put(url, **request_keyword_arguments)
        if http_response.status_code not in {307, 308}:
            return http_response

        redirect_location = http_response.headers.get("Location")
        if not redirect_location:
            raise StarRocksLoadError(
                "StarRocks Stream Load redirect did not include Location header"
            )
        redirect_url = self._resolve_redirect_url(url, redirect_location)
        redirected_response = requests.put(
            redirect_url,
            **request_keyword_arguments,
        )
        if redirected_response.status_code in {307, 308}:
            raise StarRocksLoadError(
                "StarRocks Stream Load returned multiple redirects"
            )
        return redirected_response

    def _resolve_redirect_url(self, url: str, redirect_location: str) -> str:
        """Return the Stream Load redirect URL, applying local port overrides."""
        redirect_url = urljoin(url, redirect_location)
        if self.config.backend_http_port is None:
            return redirect_url

        original_url = urlparse(url)
        parsed_redirect_url = urlparse(redirect_url)
        redirect_host = original_url.hostname
        if not redirect_host:
            return redirect_url

        netloc_host = (
            f"[{redirect_host}]"
            if ":" in redirect_host and not redirect_host.startswith("[")
            else redirect_host
        )
        replacement_netloc = f"{netloc_host}:{self.config.backend_http_port}"
        return urlunparse(parsed_redirect_url._replace(netloc=replacement_netloc))

    def _validate_table_name(self, table_name: str) -> None:
        if table_name not in self.allowed_tables:
            raise StarRocksLoadError(f"Stream Load table is not allowed: {table_name}")
        _validate_stream_load_identifier(table_name, "table")

    def _parse_response_payload(
        self,
        response_payload: dict[str, Any],
        label_context: StreamLoadLabelContext,
    ) -> StreamLoadOutcome:
        filtered_rows = _integer_response_field(response_payload, "NumberFilteredRows")
        loaded_rows = _integer_response_field(response_payload, "NumberLoadedRows")
        status_text = str(response_payload.get("Status", "")).strip()
        message = str(response_payload.get("Message", "")).strip()
        label = str(response_payload.get("Label") or label_context.to_label())
        error_url = response_payload.get("ErrorURL")
        status = _parse_status(status_text, message, filtered_rows)

        return StreamLoadOutcome(
            status=status,
            label=label,
            loaded_rows=loaded_rows,
            filtered_rows=filtered_rows,
            message=message,
            error_url=str(error_url) if error_url else None,
            payload_hash_prefix=label_context.payload_hash_prefix,
        )


def _integer_response_field(
    response_payload: dict[str, Any],
    field_name: str,
) -> int:
    value = response_payload.get(field_name, 0)
    try:
        return int(value)
    except (TypeError, ValueError) as error:
        raise StarRocksLoadError(
            f"StarRocks response field {field_name} must be an integer"
        ) from error


def _parse_status(
    status_text: str,
    message: str,
    filtered_rows: int,
) -> StreamLoadStatus:
    if filtered_rows > 0:
        return StreamLoadStatus.FILTERED_ROWS

    normalized_status = status_text.lower()
    normalized_message = message.lower()
    if normalized_status == "success":
        return StreamLoadStatus.SUCCESS
    if "publish timeout" in normalized_status or "publish timeout" in normalized_message:
        return StreamLoadStatus.PUBLISH_TIMEOUT
    if "label" in normalized_message and (
        "already" in normalized_message or "exist" in normalized_message
    ):
        return StreamLoadStatus.DUPLICATE_LABEL
    return StreamLoadStatus.FAILED


def _rows_to_json_payload(
    columns: Sequence[str],
    rows: Iterable[Sequence[Any]],
) -> str:
    objects = [dict(zip(columns, row, strict=True)) for row in rows]
    return json.dumps(objects, default=str, separators=(",", ":"))


def _validate_stream_load_identifier(identifier: str, identifier_kind: str) -> str:
    try:
        return validate_identifier(identifier)
    except ValueError as error:
        raise StarRocksLoadError(
            f"invalid StarRocks Stream Load {identifier_kind}: {identifier}"
        ) from error
