"""Deterministic StarRocks Stream Load label helpers."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class StreamLoadLabelContext:
    """Context used to build a deterministic Stream Load label."""

    network: str
    table_name: str
    range_start: int | str
    range_end: int | str
    payload_hash_prefix: str

    def to_label(self) -> str:
        """Return a deterministic Stream Load label for retry identity."""
        network = _label_part(self.network, "network")
        table_name = _label_part(self.table_name, "table_name")
        range_start = _label_part(self.range_start, "range_start")
        range_end = _label_part(self.range_end, "range_end")
        payload_hash_prefix = _label_part(
            self.payload_hash_prefix,
            "payload_hash_prefix",
        )
        return (
            f"dp_{network}_{table_name}_{range_start}_{range_end}_"
            f"{payload_hash_prefix}"
        )


def build_payload_hash_prefix(
    columns: Sequence[str],
    rows: Iterable[Sequence[Any]],
) -> str:
    """Return the 12-character SHA-256 prefix for a column/value payload."""
    if not columns:
        raise ValueError("columns must be non-empty")

    materialized_rows = [list(row) for row in rows]
    for row in materialized_rows:
        if len(row) != len(columns):
            raise ValueError("row length must match columns length")

    payload = {
        "columns": list(columns),
        "rows": materialized_rows,
    }
    serialized_payload = json.dumps(
        payload,
        default=str,
        separators=(",", ":"),
        sort_keys=True,
    )
    return hashlib.sha256(serialized_payload.encode("utf-8")).hexdigest()[:12]


def _label_part(value: object, field_name: str) -> str:
    if value is None:
        raise ValueError(f"{field_name} must be non-empty")
    text = str(value)
    if not text.strip():
        raise ValueError(f"{field_name} must be non-empty")
    return re.sub(r"[^A-Za-z0-9_]+", "_", text.strip())
