"""StarRocks DATETIME text formatting helpers.

These helpers convert epoch-milliseconds timestamps and pre-formatted
``YYYY-MM-DD HH:MM:SS`` text into the format that StarRocks DATETIME
columns require for Stream Load and SQL inserts.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def utc_datetime_text() -> str:
    """Return the current UTC time as a StarRocks DATETIME string.

    Returns:
        A ``YYYY-MM-DD HH:MM:SS`` string at second precision (microseconds
        truncated).

    Example:
        >>> text = utc_datetime_text()
        >>> len(text)
        19
    """
    return datetime.now(tz=UTC).replace(microsecond=0).strftime(DATETIME_FORMAT)


def to_datetime_text(value: Any, fallback: str) -> str:
    """Convert an epoch-milliseconds number or pre-formatted text to a DATETIME string.

    The function is deliberately lenient on input shape because callers
    receive heterogeneous data from StarRocks query results (where epoch
    millisecond columns may decode as ``int`` or ``float``) and from
    Stream Load row builders (where the value is often already a
    ``YYYY-MM-DD HH:MM:SS`` string).

    Args:
        value: One of:
            - ``None`` — ``fallback`` is returned unchanged.
            - ``str`` — returned unchanged. Callers are expected to have
              produced a StarRocks-compatible ``YYYY-MM-DD HH:MM:SS``
              representation; no validation is performed.
            - ``int`` or ``float`` — interpreted as epoch milliseconds.
              Floats are truncated via ``int(value)`` before scaling to
              seconds; subsecond precision is then dropped via
              ``replace(microsecond=0)``.
        fallback: DATETIME string returned when ``value`` is ``None``.
            Required so the caller documents the substitute explicitly.

    Returns:
        A ``YYYY-MM-DD HH:MM:SS`` string suitable for StarRocks DATETIME
        columns.

    Example:
        >>> to_datetime_text(1704067200000, "2026-01-01 00:00:00")
        '2024-01-01 00:00:00'
        >>> to_datetime_text(None, "2026-01-01 00:00:00")
        '2026-01-01 00:00:00'
        >>> to_datetime_text("2026-05-07 09:30:00", "fallback")
        '2026-05-07 09:30:00'
    """
    if value is None:
        return fallback
    if isinstance(value, str):
        return value
    return (
        datetime.fromtimestamp(int(value) / 1000, tz=UTC)
        .replace(microsecond=0)
        .strftime(DATETIME_FORMAT)
    )
