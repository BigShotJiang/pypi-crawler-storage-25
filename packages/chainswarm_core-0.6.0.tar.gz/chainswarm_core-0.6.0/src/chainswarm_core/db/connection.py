"""StarRocks connection utilities."""

import os
import re
from typing import Any

from mysql.connector import connect

_VALID_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _require_environment(name: str, environment: dict[str, str] | None = None) -> str:
    source = environment if environment is not None else os.environ
    value = source.get(name)
    if value is None or value.strip() == "":
        raise ValueError(f"{name} is required")
    return value


def _parse_port(name: str, value: str) -> int:
    try:
        port = int(value)
    except ValueError as error:
        raise ValueError(f"{name} must be an integer") from error
    if not 1 <= port <= 65535:
        raise ValueError(f"{name} must be between 1 and 65535")
    return port


def validate_identifier(identifier: str) -> str:
    """Return a validated StarRocks identifier or raise before SQL use."""
    if not _VALID_IDENTIFIER.fullmatch(identifier):
        raise ValueError(f"invalid StarRocks identifier: {identifier}")
    return identifier


def quote_identifier(identifier: str) -> str:
    """Quote a validated StarRocks identifier."""
    return f"`{validate_identifier(identifier)}`"

def get_connection_params(
    network: str | None = None,
    database_prefix: str | None = None,
    environment: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Build strict StarRocks connection parameters from environment values."""
    if database_prefix and network:
        database = f"{database_prefix}_{network}"
    elif network:
        database = network
    else:
        database = _require_environment("STARROCKS_DATABASE", environment)

    validate_identifier(database)

    return {
        "host": _require_environment("STARROCKS_HOST", environment),
        "port": _parse_port(
            "STARROCKS_PORT",
            _require_environment("STARROCKS_PORT", environment),
        ),
        "database": database,
        "user": _require_environment("STARROCKS_USER", environment),
        "password": _require_environment("STARROCKS_PASSWORD", environment),
    }


def create_database(connection_params: dict[str, Any]) -> None:
    """Create a StarRocks database if it does not exist."""
    database = quote_identifier(str(connection_params["database"]))
    connection = connect(
        host=connection_params["host"],
        port=int(connection_params["port"]),
        user=connection_params["user"],
        password=connection_params["password"],
    )
    cursor = connection.cursor()
    try:
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {database}")
        connection.commit()
    finally:
        cursor.close()
        connection.close()


def truncate_table(client: Any, table_name: str) -> None:
    """Truncate a StarRocks table if it exists."""
    cursor = client.cursor()
    try:
        cursor.execute(f"TRUNCATE TABLE {quote_identifier(table_name)}")
        client.commit()
    finally:
        cursor.close()
