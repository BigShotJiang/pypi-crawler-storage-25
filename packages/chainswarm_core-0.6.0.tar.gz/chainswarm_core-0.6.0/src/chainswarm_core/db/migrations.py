"""Schema migration utilities for StarRocks."""

import io
from pathlib import Path
from typing import Any, Iterable

from loguru import logger


def _split_sql(sql_text: str) -> Iterable[str]:
    """Split SQL text into statements."""
    cleaned = io.StringIO()
    for line in sql_text.splitlines():
        if line.strip().startswith("--"):
            continue
        parts = line.split("--", 1)
        cleaned.write(parts[0] + "\n")

    buf = []
    for ch in cleaned.getvalue():
        if ch == ";":
            stmt = "".join(buf).strip()
            if stmt:
                yield stmt
            buf = []
        else:
            buf.append(ch)

    tail = "".join(buf).strip()
    if tail:
        yield tail


def _execute_statement(client: Any, statement: str) -> None:
    if hasattr(client, "execute"):
        client.execute(statement)
        return

    cursor = client.cursor()
    try:
        cursor.execute(statement)
        if hasattr(client, "commit"):
            client.commit()
    finally:
        cursor.close()


def apply_schema_content(client: Any, sql_content: str) -> None:
    """Apply SQL statements from a content string."""
    for statement in _split_sql(sql_content):
        _execute_statement(client, statement)


def apply_schema_file(client: Any, schema_path: Path) -> None:
    """Apply SQL statements from a file path."""
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")

    sql_content = schema_path.read_text(encoding="utf-8")
    apply_schema_content(client, sql_content)


def apply_schema(client: Any, schema_name: str, schema_dir: Path) -> None:
    """Apply a named schema from a directory."""
    schema_path = schema_dir / schema_name
    apply_schema_file(client, schema_path)


class BaseMigrateSchema:
    """Base schema migration manager."""

    def __init__(self, client: Any):
        """Initialize migration manager."""
        self.client = client

    def run_schemas_from_dir(
        self,
        schema_files: list[str],
        schema_dir: Path,
    ) -> None:
        """Run migrations from a directory."""
        for schema_file in schema_files:
            schema_path = schema_dir / schema_file
            try:
                if schema_path.exists():
                    apply_schema_file(self.client, schema_path)
                    logger.info("Applied schema", extra={"schema_file": schema_file})
                else:
                    logger.warning("Schema not found", extra={"schema_path": str(schema_path)})
            except Exception as error:
                logger.error(
                    "Failed to apply schema",
                    extra={
                        "schema_file": schema_file,
                        "error": str(error),
                    },
                )
                raise
