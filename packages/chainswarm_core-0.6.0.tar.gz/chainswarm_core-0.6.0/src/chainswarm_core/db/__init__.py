"""Database utilities for StarRocks repositories."""

from chainswarm_core.db.base_repository import BaseRepository
from chainswarm_core.db.client_factory import ClientFactory
from chainswarm_core.db.connection import (
    create_database,
    get_connection_params,
    quote_identifier,
    truncate_table,
    validate_identifier,
)
from chainswarm_core.db.migrations import (
    BaseMigrateSchema,
    apply_schema,
    apply_schema_content,
    apply_schema_file,
)
from chainswarm_core.db.utils import (
    convert_warehouse_enum,
    row_to_dict,
    rows_to_pydantic_list,
    warehouse_row_to_pydantic,
)

__all__ = [
    # Repository
    "BaseRepository",
    # Client factory
    "ClientFactory",
    # Connection utilities
    "create_database",
    "truncate_table",
    "get_connection_params",
    "quote_identifier",
    "validate_identifier",
    # Migrations
    "BaseMigrateSchema",
    "apply_schema",
    "apply_schema_content",
    "apply_schema_file",
    # Row utilities
    "row_to_dict",
    "convert_warehouse_enum",
    "warehouse_row_to_pydantic",
    "rows_to_pydantic_list",
]
