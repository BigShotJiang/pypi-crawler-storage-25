"""Warehouse row conversion utilities."""

from decimal import Decimal
from enum import IntEnum
from typing import Any, TypeVar

from pydantic import BaseModel

T = TypeVar("T", bound=BaseModel)


def row_to_dict(row: tuple, column_names: list[str]) -> dict[str, Any]:
    """Convert a warehouse row tuple to a dictionary."""
    result = {}
    for name, value in zip(column_names, row):
        if isinstance(value, Decimal):
            result[name] = format(value, "f")
        else:
            result[name] = value
    return result


def convert_warehouse_enum(enum_class: type[IntEnum], value: Any) -> IntEnum | None:
    """Convert common warehouse enum encodings to an IntEnum value."""
    if value is None:
        return None

    if isinstance(value, enum_class):
        return value

    if isinstance(value, int):
        try:
            return enum_class(value)
        except ValueError:
            pass

    if isinstance(value, str) and value.isdigit():
        try:
            return enum_class(int(value))
        except ValueError:
            pass

    if isinstance(value, str):
        try:
            return enum_class[value.upper()]
        except KeyError:
            pass

    available_values = [f"{e.name}({e.value})" for e in enum_class]
    raise ValueError(
        f"Cannot convert '{value}' (type: {type(value).__name__}) to {enum_class.__name__}. "
        f"Available values: {', '.join(available_values)}"
    )


def warehouse_row_to_pydantic(
    model_class: type[T],
    row_data: dict[str, Any] | tuple,
    column_names: list[str] | None = None,
    enum_fields: dict[str, type[IntEnum]] | None = None,
) -> T:
    """Convert a warehouse row to a Pydantic model instance."""
    if isinstance(row_data, tuple):
        if not column_names:
            raise ValueError("column_names required when row_data is a tuple")
        row_dict = row_to_dict(row_data, column_names)
    else:
        row_dict = row_data.copy()

    if enum_fields:
        for field_name, enum_class in enum_fields.items():
            if field_name in row_dict:
                row_dict[field_name] = convert_warehouse_enum(enum_class, row_dict[field_name])

    return model_class(**row_dict)


def rows_to_pydantic_list(
    model_class: type[T],
    rows: list[dict[str, Any] | tuple],
    column_names: list[str] | None = None,
    enum_fields: dict[str, type[IntEnum]] | None = None,
) -> list[T]:
    """Convert multiple warehouse rows to a list of Pydantic models."""
    return [
        warehouse_row_to_pydantic(model_class, row, column_names, enum_fields) for row in rows
    ]
