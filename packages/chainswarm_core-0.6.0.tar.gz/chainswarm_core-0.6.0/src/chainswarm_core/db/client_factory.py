"""StarRocks MySQL protocol client factory."""

from contextlib import contextmanager
from typing import Any, Iterator

from loguru import logger
from mysql.connector import Error, connect


class ClientFactory:
    """Factory for creating StarRocks MySQL protocol client connections."""

    client: Any | None = None

    def __init__(self, connection_params: dict[str, Any]) -> None:
        """Initialize the factory with strict StarRocks connection parameters."""
        self.connection_params = connection_params

    def create_client(self) -> Any:
        """Create and return a new StarRocks MySQL protocol connection."""
        return self._get_client()

    def _get_client(self) -> Any:
        """Create and return a new StarRocks MySQL protocol connection."""
        self.client = connect(
            host=self.connection_params["host"],
            port=int(self.connection_params["port"]),
            user=self.connection_params["user"],
            password=self.connection_params["password"],
            database=self.connection_params["database"],
        )
        return self.client

    def _get_client_without_database(self) -> Any:
        """Create a StarRocks MySQL protocol connection without selecting a database."""
        client = connect(
            host=self.connection_params["host"],
            port=int(self.connection_params["port"]),
            user=self.connection_params["user"],
            password=self.connection_params["password"],
        )
        return client

    @contextmanager
    def client_context(self) -> Iterator[Any]:
        """Yield a StarRocks client and always close it when the context exits."""
        client = self._get_client()
        try:
            yield client
        except Error as error:
            import traceback

            logger.error(
                "StarRocks error",
                extra={
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                },
            )
            raise
        finally:
            if client:
                client.close()
