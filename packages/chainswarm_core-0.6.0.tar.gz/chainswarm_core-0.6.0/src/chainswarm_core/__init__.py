from chainswarm_core.constants import (
    AddressTypes,
    Network,
    NetworkType,
    RiskLevels,
    Severities,
    TrustLevels,
)
from chainswarm_core.db import (
    BaseRepository,
    BaseMigrateSchema,
    ClientFactory,
    create_database,
    get_connection_params,
)
from chainswarm_core.schema import (
    get_core_schema_dir,
    list_core_schemas,
    read_core_schema,
)
from chainswarm_core.observability import (
    COUNT_BUCKETS,
    DURATION_BUCKETS,
    SIZE_BUCKETS,
    MetricsRegistry,
    generate_correlation_id,
    get_correlation_id,
    get_metrics_registry,
    install_shutdown_handlers,
    log_errors,
    manage_metrics,
    set_correlation_id,
    setup_logger,
    setup_metrics,
    shutdown_handler,
    shutdown_metrics_servers,
    terminate_event,
)

__version__ = "0.6.0"

DEFAULT_ASSET_CONTRACT = "native"

__all__ = [
    "__version__",
    "DEFAULT_ASSET_CONTRACT",
    "NetworkType",
    "Network",
    "AddressTypes",
    "TrustLevels",
    "RiskLevels",
    "Severities",
    "BaseRepository",
    "BaseMigrateSchema",
    "ClientFactory",
    "create_database",
    "get_connection_params",
    "get_core_schema_dir",
    "list_core_schemas",
    "read_core_schema",
    "COUNT_BUCKETS",
    "DURATION_BUCKETS",
    "SIZE_BUCKETS",
    "MetricsRegistry",
    "generate_correlation_id",
    "get_correlation_id",
    "get_metrics_registry",
    "install_shutdown_handlers",
    "log_errors",
    "manage_metrics",
    "set_correlation_id",
    "setup_logger",
    "setup_metrics",
    "shutdown_handler",
    "shutdown_metrics_servers",
    "terminate_event",
]
