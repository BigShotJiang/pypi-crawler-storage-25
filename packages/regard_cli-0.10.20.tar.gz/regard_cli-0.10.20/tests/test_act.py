"""Tests for act commands — order, cancel, cancel-all, leverage, transfer, preflight."""

import json
import os
from unittest.mock import patch

import pytest

from hl_cli.main import app

ACTIVE_ASSET_DATA_EMPTY = {
    "user": "0xTEST",
    "coin": "xyz:CL",
    "leverage": {"type": "isolated", "value": 20, "rawUsd": "0.0"},
    "maxTradeSzs": ["0.0", "0.0"],
    "availableToTrade": ["0.0", "0.0"],
    "markPx": "100.50",
}


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


@pytest.fixture(autouse=True)
def _use_tmp_dir(tmp_path):
    """Run act tests in a temp dir so trade log doesn't pollute the project."""
    original = os.getcwd()
    os.chdir(tmp_path)
    yield
    os.chdir(original)


class TestOrder:
    def test_market_buy(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "--market"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_limit_buy(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.1", "65000"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_side_aliases(self, runner, patched):
        for side in ["buy", "long", "sell", "short"]:
            result = runner.invoke(app, ["hl", "order", "BTC", side, "0.1", "--market"])
            assert result.exit_code == 0, f"Failed for side={side}"

    def test_invalid_side(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "BTC", "yolo", "0.1", "65000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_SIDE"

    def test_unknown_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "order", "FAKECOIN", "buy", "0.1", "--market"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "UNKNOWN_ASSET"


class TestCancel:
    def test_by_oid_auto_lookup(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "cancel", "100001"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_by_oid_with_asset(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "cancel", "BTC", "100001"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_oid_not_found(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel", "999999"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "ORDER_NOT_FOUND"


class TestCancelAll:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "cancel-all"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filtered(self, runner, patched):
        result = runner.invoke(app, ["hl", "cancel-all", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert d["cancelled"] == 1
        assert d["assets"] == ["BTC"]

    def test_empty(self, runner, patched):
        patched["info"].frontend_open_orders.return_value = []
        result = runner.invoke(app, ["hl", "cancel-all"])
        assert result.exit_code == 0
        d = data(result)
        assert d["cancelled"] == 0


class TestLeverage:
    def test_cross_default(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_isolated(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10", "--isolated"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_both_flags_error(self, runner, patched):
        result = runner.invoke(app, ["hl", "leverage", "BTC", "10", "--cross", "--isolated"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "CONFLICTING_OPTIONS"


class TestPreflight:
    def test_can_trade(self, runner, patched):
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        assert d["can_trade"] is True
        assert d["asset"] == "BTC"
        assert d["dex"] == "default"
        assert float(d["max_size"]) > 0

    def test_cannot_trade_hip3(self, runner, patched):
        # Add xyz:CL to resolver's known coins
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("hl_cli.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5"])
            assert result.exit_code == 0
            d = data(result)
            assert d["can_trade"] is False
            assert d["dex"] == "xyz"

    def test_invalid_side(self, runner, patched):
        result = runner.invoke(app, ["hl", "preflight", "BTC", "sideways", "1.0"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_SIDE"

    def test_risk_metrics(self, runner, patched):
        """Preflight returns notional, equity, notional_pct, margin_required, liq_price_est."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        # mark_px from ACTIVE_ASSET_DATA is 69666.0, size 0.01
        assert d["notional"] == pytest.approx(696.66, abs=1)
        assert d["equity"] == pytest.approx(10000.0, abs=1)
        assert d["notional_pct"] == pytest.approx(6.97, abs=0.1)
        assert "margin_required" in d
        assert "leverage" in d

    def test_liq_price_est_isolated(self, runner, patched):
        """Isolated leverage: liq_price_est = mark * (1 - 1/lev) for longs."""
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("hl_cli.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5"])
            assert result.exit_code == 0
            d = data(result)
            # mark 100.50, leverage 20x isolated: liq = 100.50 * (1 - 1/20) = 95.475
            assert d["liq_price_est"] == pytest.approx(95.475, abs=0.01)

    def test_liq_price_est_cross_is_null(self, runner, patched):
        """Cross leverage: liq_price_est is null (depends on portfolio)."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        # BTC in ACTIVE_ASSET_DATA has cross leverage
        assert d["liq_price_est"] is None

    def test_high_notional_warning(self, runner, patched):
        """Warns when notional > 50% of equity."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.1"])
        assert result.exit_code == 0
        d = data(result)
        # 0.1 * 69666 = $6966.6, equity $10000 → 69.7%
        codes = [w["code"] for w in d["warnings"]]
        assert "HIGH_NOTIONAL" in codes

    def test_liq_above_stop_warning(self, runner, patched):
        """Warns when liq estimate is above planned stop for a long."""
        patched["info"].coin_to_asset["xyz:CL"] = 110029
        with patch("hl_cli.commands.act.get_active_asset_data", return_value=ACTIVE_ASSET_DATA_EMPTY):
            # mark 100.50, 20x isolated → liq ~95.475, stop at 96 → liq < stop (OK)
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5", "--sl", "96"])
            assert result.exit_code == 0
            d = data(result)
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_ABOVE_STOP" not in codes

            # stop at 94 → liq 95.475 > 94 → warning
            result = runner.invoke(app, ["hl", "preflight", "xyz:CL", "buy", "0.5", "--sl", "94"])
            assert result.exit_code == 0
            d = data(result)
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_ABOVE_STOP" in codes
            liq_warn = [w for w in d["warnings"] if w["code"] == "LIQ_ABOVE_STOP"][0]
            assert "suggested_leverage" in liq_warn

    def test_max_loss_with_sl(self, runner, patched):
        """--sl flag adds stop_price and max_loss to output."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01", "--sl", "65000"])
        assert result.exit_code == 0
        d = data(result)
        assert d["stop_price"] == "65000"
        # max_loss = 0.01 * abs(69666 - 65000) = 46.66
        assert d["max_loss"] == pytest.approx(46.66, abs=1)

    def test_existing_position_warning(self, runner, patched):
        """Warns when an existing position exists for the same asset."""
        # BTC has an existing long 0.05 position in USER_STATE
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        assert d["existing_position"]["side"] == "long"
        assert d["existing_position"]["size"] == 0.05
        codes = [w["code"] for w in d["warnings"]]
        assert "EXISTING_POSITION" in codes

    def test_display_field(self, runner, patched):
        """Preflight includes a display string."""
        result = runner.invoke(app, ["hl", "preflight", "BTC", "buy", "0.01"])
        assert result.exit_code == 0
        d = data(result)
        assert "Preflight:" in d["display"]
        assert "Mark price" in d["display"]


class TestDirectionValidation:
    """Tests for _validate_trigger_direction shared helper via order --sl/--tp."""

    def test_order_sl_wrong_direction_long(self, runner, patched):
        """--sl above market for a buy/long is rejected."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.01", "65000", "--sl", "75000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "BAD_STOP"

    def test_order_sl_wrong_direction_short(self, runner, patched):
        """--sl below market for a sell/short is rejected."""
        result = runner.invoke(app, ["hl", "order", "BTC", "sell", "0.01", "75000", "--sl", "60000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "BAD_STOP"

    def test_order_tp_wrong_direction_long(self, runner, patched):
        """--tp below market for a buy/long is rejected."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.01", "65000", "--tp", "60000"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "BAD_TP"

    def test_order_sl_correct_passes(self, runner, patched):
        """--sl below market for a buy/long passes validation."""
        result = runner.invoke(app, ["hl", "order", "BTC", "buy", "0.01", "65000", "--sl", "60000"])
        assert result.exit_code == 0


class TestStopLiqWarning:
    """Tests for liq-vs-stop warning on stop command."""

    def test_stop_warns_liq_above_stop_long(self, runner, patched):
        """Stop on a long warns if liq price is above the stop."""
        # BTC long, liq at 62000. Set stop at 61000 → liq > stop.
        with patch("hl_cli.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "cross", "value": 10}},
        ]), patch("hl_cli.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            result = runner.invoke(app, ["hl", "stop", "BTC", "61000"])
            assert result.exit_code == 0
            d = data(result)
            assert "warnings" in d
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_ABOVE_STOP" in codes

    def test_stop_no_warning_liq_below_stop(self, runner, patched):
        """No warning when liq is safely below stop."""
        # BTC long, liq at 62000. Set stop at 64000 → liq < stop. OK.
        with patch("hl_cli.commands.act.get_all_positions", return_value=[
            {"coin": "BTC", "szi": "0.05", "entryPx": "68000.00",
             "liquidationPx": "62000.00", "leverage": {"type": "cross", "value": 10}},
        ]), patch("hl_cli.commands.act.get_all_mids", return_value={"BTC": "69666.5"}):
            result = runner.invoke(app, ["hl", "stop", "BTC", "64000"])
            assert result.exit_code == 0
            d = data(result)
            assert "warnings" not in d

    def test_stop_warns_liq_below_stop_short(self, runner, patched):
        """Stop on a short warns if liq price is below the stop."""
        # ETH short, liq at 3800. Set stop at 3900 → liq < stop for short.
        with patch("hl_cli.commands.act.get_all_positions", return_value=[
            {"coin": "ETH", "szi": "-1.0", "entryPx": "3300.00",
             "liquidationPx": "3800.00", "leverage": {"type": "cross", "value": 5}},
        ]), patch("hl_cli.commands.act.get_all_mids", return_value={"ETH": "3250.0"}):
            result = runner.invoke(app, ["hl", "stop", "ETH", "3900"])
            assert result.exit_code == 0
            d = data(result)
            assert "warnings" in d
            codes = [w["code"] for w in d["warnings"]]
            assert "LIQ_BELOW_STOP" in codes


class TestTransfer:
    def test_missing_direction(self, runner, patched):
        result = runner.invoke(app, ["hl", "transfer", "5.00"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MISSING_OPTION"

    def test_both_from_and_to(self, runner, patched):
        """Both --from and --to is valid (e.g. --from spot --to flx)."""
        mock_exchange = patched["exchange"]
        mock_exchange.send_asset.return_value = {"status": "ok"}
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz", "--from", "default"])
        assert result.exit_code == 0

    def test_successful_transfer(self, runner, patched):
        """Transfer between USDC dexes succeeds."""
        mock_exchange = patched["exchange"]
        mock_exchange.send_asset.return_value = {"status": "ok"}
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "xyz"])
        assert result.exit_code == 0
        d = data(result)
        assert d["token"] == "USDC"
        assert d["to_dex"] == "xyz"
        assert d["from_dex"] == "default"

    def test_collateral_mismatch(self, runner, patched):
        """Transfer between dexes with different collateral tokens fails."""
        result = runner.invoke(app, ["hl", "transfer", "5.00", "--to", "flx"])
        assert result.exit_code == 2
        err = parse(result)["error"]
        assert err["code"] == "COLLATERAL_MISMATCH"
        assert "USDC" in err["message"]
        assert "USDH" in err["message"]

    def test_transfer_uses_withdrawable_not_account_value(self, runner, patched):
        """Transfer checks withdrawable (not accountValue) to avoid draining margin."""
        mock_exchange = patched["exchange"]
        mock_exchange.send_asset.return_value = {"status": "ok"}
        # Default state: accountValue=10000 but withdrawable=9500
        # Transfer 9800 should fail (exceeds withdrawable) even though < accountValue
        result = runner.invoke(app, ["hl", "transfer", "9800", "--to", "xyz"])
        assert result.exit_code == 4
        err = parse(result)["error"]
        assert err["code"] == "INSUFFICIENT_BALANCE"
        assert "withdrawable" in err["message"]
