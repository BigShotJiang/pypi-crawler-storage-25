"""Tests for the actual FastAPI routes in src/api/routes/tasks.py and server.py.

Uses httpx.AsyncClient with the real FastAPI app, but mocks app.state
providers so no external services are needed.
"""

from __future__ import annotations

import pytest
import pytest_asyncio
import httpx

from src.api.server import create_app
from src.core.agent import ReLoopAgent
from src.core.timeline import TimelineManager
from src.models import Task, TaskStatus
from tests.conftest import InMemoryBackend, MockLLMProvider, MockSandboxProvider


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def app():
    """Create a fresh FastAPI app with mocked providers in app.state."""
    application = create_app()

    memory = InMemoryBackend()
    sandbox = MockSandboxProvider()
    llm = MockLLMProvider()
    timeline = TimelineManager()
    agent = ReLoopAgent(memory=memory, sandbox=sandbox, llm=llm, timeline=timeline)

    # Inject test state directly — bypasses the lifespan initialiser
    application.state.memory = memory
    application.state.sandbox = sandbox
    application.state.llm = llm
    application.state.timeline = timeline
    application.state.agent = agent
    application.state.retry_engine = agent._retry_engine
    application.state.memory_manager = agent._memory
    application.state.tasks = {}
    application.state.surfaces_manager = None

    return application


@pytest_asyncio.fixture
async def client(app):
    """Async httpx client bound to the test app."""
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://testserver",
    ) as c:
        yield c


# ---------------------------------------------------------------------------
# Health endpoint
# ---------------------------------------------------------------------------


class TestHealthEndpoint:
    @pytest.mark.asyncio
    async def test_health_returns_ok(self, client):
        resp = await client.get("/v1/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data


# ---------------------------------------------------------------------------
# Providers endpoint
# ---------------------------------------------------------------------------


class TestProvidersEndpoint:
    @pytest.mark.asyncio
    async def test_providers_returns_types(self, client):
        resp = await client.get("/v1/providers")
        assert resp.status_code == 200
        data = resp.json()
        assert data["memory"] == "InMemoryBackend"
        assert data["sandbox"] == "MockSandboxProvider"
        assert data["llm"] == "MockLLMProvider"


# ---------------------------------------------------------------------------
# POST /v1/tasks
# ---------------------------------------------------------------------------


class TestCreateTask:
    @pytest.mark.asyncio
    async def test_create_task_201(self, client):
        resp = await client.post("/v1/tasks", json={
            "instruction": "echo hello",
            "max_retries": 3,
            "max_budget_usd": 0.50,
        })
        assert resp.status_code == 201
        data = resp.json()
        assert "id" in data
        assert data["instruction"] == "echo hello"
        assert data["status"] in ("pending", "running")

    @pytest.mark.asyncio
    async def test_create_task_missing_instruction(self, client):
        resp = await client.post("/v1/tasks", json={})
        assert resp.status_code == 422  # validation error


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}
# ---------------------------------------------------------------------------


class TestGetTask:
    @pytest.mark.asyncio
    async def test_get_existing_task(self, client, app):
        # Seed a task directly in app.state
        task = Task(instruction="test task")
        app.state.tasks[task.id] = task

        resp = await client.get(f"/v1/tasks/{task.id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["id"] == task.id
        assert data["instruction"] == "test task"

    @pytest.mark.asyncio
    async def test_get_nonexistent_task_404(self, client):
        resp = await client.get("/v1/tasks/nonexistent-id")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# GET /v1/tasks (list)
# ---------------------------------------------------------------------------


class TestListTasks:
    @pytest.mark.asyncio
    async def test_list_empty(self, client):
        resp = await client.get("/v1/tasks")
        assert resp.status_code == 200
        assert resp.json() == []

    @pytest.mark.asyncio
    async def test_list_with_tasks(self, client, app):
        t1 = Task(instruction="task one")
        t2 = Task(instruction="task two")
        app.state.tasks[t1.id] = t1
        app.state.tasks[t2.id] = t2

        resp = await client.get("/v1/tasks")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}/timeline
# ---------------------------------------------------------------------------


class TestTimeline:
    @pytest.mark.asyncio
    async def test_timeline_for_existing_task(self, client, app):
        task = Task(instruction="test")
        app.state.tasks[task.id] = task

        resp = await client.get(f"/v1/tasks/{task.id}/timeline")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    @pytest.mark.asyncio
    async def test_timeline_404_unknown_task(self, client):
        resp = await client.get("/v1/tasks/no-such-task/timeline")
        assert resp.status_code == 404


# ---------------------------------------------------------------------------
# GET /v1/tasks/{task_id}/circuit-breaker
# ---------------------------------------------------------------------------


class TestCircuitBreaker:
    @pytest.mark.asyncio
    async def test_circuit_breaker_default_closed(self, client, app):
        task = Task(instruction="test")
        app.state.tasks[task.id] = task

        resp = await client.get(f"/v1/tasks/{task.id}/circuit-breaker")
        assert resp.status_code == 200
        data = resp.json()
        assert data["is_open"] is False

    @pytest.mark.asyncio
    async def test_circuit_breaker_404(self, client):
        resp = await client.get("/v1/tasks/missing/circuit-breaker")
        assert resp.status_code == 404
