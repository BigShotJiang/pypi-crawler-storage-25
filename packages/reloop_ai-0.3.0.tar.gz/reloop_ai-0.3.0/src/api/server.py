"""FastAPI application entry point for the ReLoop API."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.config import settings
from src.core.agent import ReLoopAgent
from src.core.timeline import TimelineManager
from src.models import Task

from src.api.routes import tasks as tasks_router
from src.api.routes import memories as memories_router
from src.api.routes import checkpoints as checkpoints_router
from src.api.routes import surfaces as surfaces_router

logger = logging.getLogger(__name__)

VERSION = "0.1.0"

# ---------------------------------------------------------------------------
# Provider factory helpers — import lazily so missing implementations don't
# prevent the server from starting.
# ---------------------------------------------------------------------------

async def _init_memory():
    """Try to instantiate the configured memory backend; fall back to None."""
    try:
        from src.providers.memory.redis_backend import RedisMemoryBackend  # type: ignore
        backend = RedisMemoryBackend(
            redis_url=settings.redis_url,
            index_name=settings.redis_memory_index,
        )
        logger.info("Memory backend: RedisMemoryBackend initialised")
        return backend
    except ImportError:
        logger.warning(
            "RedisMemoryBackend not available — memory features disabled"
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to initialise RedisMemoryBackend: %s", exc)

    # Fall back to SQLite backend for local dev
    try:
        from src.providers.memory.sqlite_backend import SQLiteMemoryBackend  # type: ignore
        backend = SQLiteMemoryBackend()
        logger.info("Memory backend: SQLiteMemoryBackend initialised (fallback)")
        return backend
    except ImportError:
        logger.warning("SQLiteMemoryBackend not available — memory features disabled")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to initialise SQLiteMemoryBackend: %s", exc)

    return None


async def _init_sandbox():
    """Try to instantiate the configured sandbox provider; fall back to None."""
    try:
        from src.providers.sandbox.blaxel import BlaxelSandbox  # type: ignore
        provider = BlaxelSandbox(
            api_key=settings.blaxel_api_key,
            workspace=settings.blaxel_workspace,
        )
        logger.info("Sandbox provider: BlaxelSandbox initialised")
        return provider
    except ImportError:
        logger.warning("BlaxelSandbox not available — trying Docker fallback")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to initialise BlaxelSandbox: %s", exc)

    try:
        from src.providers.sandbox.docker import DockerSandbox  # type: ignore
        provider = DockerSandbox()
        logger.info("Sandbox provider: DockerSandbox initialised (fallback)")
        return provider
    except ImportError:
        logger.warning("DockerSandbox not available — sandbox features disabled")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to initialise DockerSandbox: %s", exc)

    return None


async def _init_llm():
    """Try to instantiate the configured LLM provider; fall back to None."""
    try:
        from src.providers.llm.openai import OpenAILLM  # type: ignore
        provider = OpenAILLM(
            api_key=settings.openai_api_key,
            model=settings.codex_model,
        )
        logger.info("LLM provider: OpenAILLM initialised")
        return provider
    except ImportError:
        logger.warning("OpenAILLM not available — LLM features disabled")
    except Exception as exc:  # noqa: BLE001
        logger.warning("Failed to initialise OpenAILLM: %s", exc)

    return None


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """Initialise providers and shared state on startup; clean up on shutdown."""
    logger.info("ReLoop API starting up (version %s)…", VERSION)

    # Initialise providers (all can be None if not configured)
    memory = await _init_memory()
    sandbox = await _init_sandbox()
    llm = await _init_llm()

    # Shared state
    timeline = TimelineManager()
    agent = ReLoopAgent(memory=memory, sandbox=sandbox, llm=llm, timeline=timeline)

    app.state.memory = memory
    app.state.sandbox = sandbox
    app.state.llm = llm
    app.state.timeline = timeline
    app.state.agent = agent
    app.state.retry_engine = agent._retry_engine
    app.state.memory_manager = agent._memory if agent._memory else None
    app.state.tasks: dict[str, Task] = {}

    # Context Surfaces manager (optional — requires admin key + package)
    surfaces_manager = None
    if settings.context_surfaces_admin_key:
        try:
            from src.providers.memory.context_surfaces_client import (
                CONTEXT_SURFACES_AVAILABLE,
                ContextSurfacesManager,
            )

            if not CONTEXT_SURFACES_AVAILABLE:
                logger.warning(
                    "context-surfaces package not installed or incompatible "
                    "Python version (requires 3.11-3.13) — surfaces features disabled"
                )
            else:
                surfaces_manager = ContextSurfacesManager(config=settings)
                logger.info("Context Surfaces manager initialised")
        except ImportError:
            logger.warning(
                "context-surfaces package not available — surfaces features disabled"
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Failed to initialise Context Surfaces manager: %s", exc)
    app.state.surfaces_manager = surfaces_manager

    logger.info("ReLoop API ready")
    yield

    # Shutdown
    logger.info("ReLoop API shutting down…")


# ---------------------------------------------------------------------------
# Application factory
# ---------------------------------------------------------------------------

def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(
        title="ReLoop API",
        version=VERSION,
        description=(
            "Self-healing agent framework with structured failure memory. "
            "Every failure is captured, analysed, and used to inform the next attempt."
        ),
        lifespan=lifespan,
    )

    # CORS — allow the Next.js dev servers
    app.add_middleware(
        CORSMiddleware,
        allow_origins=[
            "http://localhost:3000",
            "http://localhost:3001",
        ],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Routers
    app.include_router(tasks_router.router)
    app.include_router(memories_router.router)
    app.include_router(checkpoints_router.router)
    app.include_router(surfaces_router.router)

    # Health endpoint
    @app.get("/v1/health", tags=["health"])
    async def health() -> JSONResponse:
        return JSONResponse({"status": "ok", "version": VERSION})

    # Providers endpoint — shows what's active
    @app.get("/v1/providers", tags=["system"])
    async def list_providers(request: Request) -> JSONResponse:
        memory = request.app.state.memory
        sandbox = request.app.state.sandbox
        llm = request.app.state.llm
        return JSONResponse({
            "memory": type(memory).__name__ if memory else None,
            "sandbox": type(sandbox).__name__ if sandbox else None,
            "llm": type(llm).__name__ if llm else None,
        })

    return app


# Module-level app instance used by uvicorn / the test suite
app = create_app()


# ---------------------------------------------------------------------------
# FastAPI dependency helpers (importable by route modules if needed)
# ---------------------------------------------------------------------------

async def get_agent(request: Request) -> ReLoopAgent:
    """Dependency: return the shared ReLoopAgent instance."""
    return request.app.state.agent


async def get_timeline(request: Request) -> TimelineManager:
    """Dependency: return the shared TimelineManager instance."""
    return request.app.state.timeline


async def get_memory(request: Request):
    """Dependency: return the configured MemoryBackend (may be None)."""
    return request.app.state.memory
