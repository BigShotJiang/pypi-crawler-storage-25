"""ReLoop Failure Memory -- standalone API.

Drop-in failure memory for any agent framework in 3 lines:

    from reloop import FailureMemory

    memory = FailureMemory()
    await memory.store_failure(error_type="ImportError", error_message="No module named 'sharp'",
                               root_cause="Missing dependency", suggested_fix="pip install sharp")
    similar = await memory.search("ImportError sharp")
"""

from __future__ import annotations

import logging
from typing import Any

from src.models import (
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    FailureRecord,
    SuccessRecord,
)
from src.providers.base import MemoryBackend

logger = logging.getLogger(__name__)


class FailureMemory:
    """High-level, framework-agnostic API for ReLoop failure memory.

    Wraps RedisMemoryBackend (default) or SQLiteMemoryBackend (fallback)
    so any agent framework can add failure memory in 3 lines.
    """

    def __init__(
        self,
        redis_url: str = "redis://localhost:6379",
        embedding_model: str = "text-embedding-3-small",
        backend: str = "auto",
        sqlite_path: str = "reloop_memory.db",
    ) -> None:
        """Initialise failure memory.

        Args:
            redis_url: Redis connection URL. Used when backend is "redis" or "auto".
            embedding_model: Model name for generating embeddings (reserved for future use).
            backend: One of "auto", "redis", or "sqlite".
                     "auto" tries Redis first, falls back to SQLite.
            sqlite_path: Path to the SQLite database file when using the sqlite backend.
        """
        self._redis_url = redis_url
        self._embedding_model = embedding_model
        self._backend_type = backend
        self._sqlite_path = sqlite_path
        self._backend: MemoryBackend | None = None

    async def _get_backend(self) -> MemoryBackend:
        """Lazily initialise the memory backend."""
        if self._backend is not None:
            return self._backend

        if self._backend_type in ("auto", "redis"):
            try:
                from src.providers.memory.redis_backend import RedisMemoryBackend

                backend = RedisMemoryBackend(redis_url=self._redis_url)
                # Probe connection by getting the client
                await backend._get_client()
                self._backend = backend
                logger.info("FailureMemory: using Redis backend at %s", self._redis_url)
                return self._backend
            except Exception:
                if self._backend_type == "redis":
                    raise
                logger.info("FailureMemory: Redis unavailable, falling back to SQLite")

        if self._backend_type in ("auto", "sqlite"):
            from src.providers.memory.sqlite_backend import SQLiteMemoryBackend

            self._backend = SQLiteMemoryBackend(db_path=self._sqlite_path)
            logger.info("FailureMemory: using SQLite backend at %s", self._sqlite_path)
            return self._backend

        raise ValueError(f"Unknown backend type: {self._backend_type!r}")

    async def store_failure(
        self,
        error_type: str,
        error_message: str,
        root_cause: str = "",
        suggested_fix: str = "",
        task_id: str = "standalone",
        attempt_number: int = 1,
        confidence: float = 0.8,
        error_category: str = "unknown",
        what_was_tried: str = "",
        why_it_failed: str = "",
        anti_pattern: str = "",
        code_context: str = "",
        cost_usd: float = 0.0,
        transferable: bool = True,
        **kwargs: Any,
    ) -> str:
        """Store a failure record. Returns the failure ID.

        Args:
            error_type: The type/class of error (e.g. "ImportError", "TypeError").
            error_message: The error message text.
            root_cause: Analysis of why the error occurred.
            suggested_fix: How to fix the error.
            task_id: Optional task identifier for grouping.
            attempt_number: Which attempt this failure came from.
            confidence: Confidence score for the analysis (0.0 to 1.0).
            error_category: One of: dependency_error, runtime_error, config_error,
                           type_error, network_error, permission_error, timeout_error, unknown.
            what_was_tried: Description of what was attempted.
            why_it_failed: Explanation of why it failed.
            anti_pattern: Pattern to avoid in future.
            code_context: Relevant code snippet.
            cost_usd: Cost of this attempt in USD.
            transferable: Whether this failure applies across projects (default True).
        """
        backend = await self._get_backend()

        # Map string category to enum
        try:
            category = ErrorCategory(error_category)
        except ValueError:
            category = ErrorCategory.UNKNOWN

        signature = ErrorSignature(
            error_type=error_type,
            error_category=category,
            error_message=error_message,
            code_context=code_context,
        )
        analysis = FailureAnalysis(
            root_cause=root_cause,
            what_was_tried=what_was_tried,
            why_it_failed=why_it_failed,
            suggested_fix=suggested_fix,
            anti_pattern=anti_pattern,
            confidence=confidence,
        )
        record = FailureRecord(
            task_id=task_id,
            attempt_number=attempt_number,
            signature=signature,
            analysis=analysis,
            context=kwargs,
            cost_usd=cost_usd,
            transferable=transferable,
        )
        return await backend.store_failure(record)

    async def store_success(
        self,
        approach: str,
        key_insight: str,
        task_id: str = "standalone",
        attempt_number: int = 1,
        **kwargs: Any,
    ) -> str:
        """Store a success record. Returns the success ID.

        Args:
            approach: Description of the successful approach.
            key_insight: The key learning from this success.
            task_id: Optional task identifier for grouping.
            attempt_number: Which attempt succeeded.
        """
        backend = await self._get_backend()
        record = SuccessRecord(
            task_id=task_id,
            attempt_number=attempt_number,
            solution={"approach": approach, "key_insight": key_insight},
            learning=kwargs,
            metrics={},
        )
        return await backend.store_success(record)

    async def search(self, query: str, limit: int = 5) -> list[dict[str, Any]]:
        """Search failure memory by text match.

        Returns a list of dicts with keys: id, error_type, error_message,
        root_cause, suggested_fix, confidence, anti_pattern, transferable.
        """
        backend = await self._get_backend()
        records = await backend.search(query=query, limit=limit)
        return [
            {
                "id": r.id,
                "error_type": r.signature.error_type,
                "error_message": r.signature.error_message,
                "root_cause": r.analysis.root_cause,
                "suggested_fix": r.analysis.suggested_fix,
                "confidence": r.analysis.confidence,
                "anti_pattern": r.analysis.anti_pattern,
                "transferable": r.transferable,
            }
            for r in records
        ]

    async def search_cross_project(
        self,
        query: str,
        exclude_task_id: str | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Search ALL failures across all tasks/projects (cross-project transfer).

        Returns only transferable failures ranked by similarity and confidence.
        This enables memories from Project A to help Project B succeed faster.

        Args:
            query: Natural-language description of the error or problem.
            exclude_task_id: Optional task ID to exclude from results.
            limit: Maximum number of results to return.
        """
        backend = await self._get_backend()
        # Fetch extra candidates so we have enough after filtering
        records = await backend.search(query=query, limit=limit * 4)

        # Filter to transferable only, optionally excluding a task
        filtered = [
            r for r in records
            if r.transferable
            and (exclude_task_id is None or r.task_id != exclude_task_id)
        ]

        return [
            {
                "id": r.id,
                "task_id": r.task_id,
                "error_type": r.signature.error_type,
                "error_message": r.signature.error_message,
                "root_cause": r.analysis.root_cause,
                "suggested_fix": r.analysis.suggested_fix,
                "confidence": r.analysis.confidence,
                "anti_pattern": r.analysis.anti_pattern,
                "transferable": r.transferable,
            }
            for r in filtered[:limit]
        ]

    async def get_anti_patterns(self, domain: str | None = None) -> list[str]:
        """Get accumulated anti-patterns from failure history.

        Args:
            domain: Optional filter -- only return anti-patterns matching this domain.
        """
        backend = await self._get_backend()
        # Search broadly or by domain
        query = domain if domain else ""
        records = await backend.search(query=query, limit=100) if query else []

        # If no domain filter, scan all failures via stats + search
        if not query:
            try:
                stats = await backend.get_stats()
                # Get a broad sample of failures
                for cat in stats.top_error_categories:
                    records.extend(
                        await backend.search(query=cat, limit=20)
                    )
            except Exception:
                pass

        # Deduplicate and collect non-empty anti-patterns
        seen: set[str] = set()
        patterns: list[str] = []
        for r in records:
            ap = r.analysis.anti_pattern.strip()
            if ap and ap not in seen:
                seen.add(ap)
                patterns.append(ap)
        return patterns

    async def stats(self) -> dict[str, Any]:
        """Get memory statistics.

        Returns a dict with: total_failures, total_successes,
        top_error_categories, avg_confidence.
        """
        backend = await self._get_backend()
        s = await backend.get_stats()
        return {
            "total_failures": s.total_failures,
            "total_successes": s.total_successes,
            "top_error_categories": s.top_error_categories,
            "avg_confidence": s.avg_confidence,
        }

    async def clear(self) -> None:
        """Clear all failure memory."""
        backend = await self._get_backend()
        await backend.clear()
