"""ReLoopAgent — the REJD Loop Orchestrator.

REJD = Retrieve → Execute → Judge → Distill

This is the main entry-point for running tasks through the self-healing loop.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from src.config import settings
from src.models import (
    Attempt,
    AttemptStatus,
    ErrorCategory,
    ErrorSignature,
    FailureAnalysis,
    StepResult,
    Task,
    TaskStatus,
    TimelineEventType,
    CircuitBreakerState,
)
from src.providers.base import (
    ExecutionResult,
    LLMProvider,
    MemoryBackend,
    SandboxProvider,
)
from src.core.distiller import Distiller
from src.core.memory import FailureMemoryManager
from src.core.planner import Planner
from src.core.retry import RetryEngine
from src.core.timeline import TimelineManager
from src.providers.llm.agents_orchestrator import AgentsOrchestrator

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class ReLoopAgent:
    """Orchestrates the REJD loop for a given task.

    The loop:
    1. RETRIEVE — query failure memory for similar past failures
    2. EXECUTE  — run command(s) in sandbox with memory context injected
    3. JUDGE    — determine success or failure
    4. DISTILL  — extract learnings and store in memory
    5. Repeat until success, budget exhausted, or circuit breaker open
    """

    def __init__(
        self,
        memory: MemoryBackend | None = None,
        sandbox: SandboxProvider | None = None,
        llm: LLMProvider | None = None,
        timeline: TimelineManager | None = None,
        max_retries: int | None = None,
        max_budget_usd: float | None = None,
        circuit_breaker_threshold: int | None = None,
        *,
        memory_backend: MemoryBackend | None = None,
    ) -> None:
        # Accept both `memory` and `memory_backend` for compatibility
        backend = memory_backend or memory
        self._sandbox = sandbox
        self._llm = llm

        self._memory = FailureMemoryManager(backend, llm=llm) if backend else None
        self._timeline = timeline or TimelineManager()
        self._distiller = Distiller(llm) if llm else None
        self._planner: Planner | AgentsOrchestrator | None = None
        # Prefer the OpenAI Agents SDK orchestrator; fall back to the basic Planner
        try:
            from agents import Agent  # type: ignore[import]  # noqa: F401
            if llm or sandbox:
                self._planner = AgentsOrchestrator(
                    memory_manager=self._memory,
                    sandbox_provider=sandbox,
                )
                logger.info("Using OpenAI Agents SDK orchestrator for REJD planning")
        except ImportError:
            logger.info("openai-agents not installed; falling back to basic Planner")
        if self._planner is None and llm:
            self._planner = Planner(llm)
        self._max_retries = max_retries if max_retries is not None else settings.max_retries
        self._max_budget_usd = max_budget_usd if max_budget_usd is not None else settings.max_budget_usd
        self._circuit_breaker_threshold = (
            circuit_breaker_threshold
            if circuit_breaker_threshold is not None
            else settings.circuit_breaker_threshold
        )
        self._retry_engine = RetryEngine(
            memory=self._memory,
            max_retries=self._max_retries,
            max_budget_usd=self._max_budget_usd,
            circuit_breaker_threshold=self._circuit_breaker_threshold,
        ) if self._memory else None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def run(self, task: Task) -> Task:
        """Execute the REJD loop until the task succeeds, is abandoned, or budget runs out.

        Returns the mutated Task with updated status, attempts, and cost.
        """
        task.status = TaskStatus.RUNNING
        self._timeline.emit(
            task_id=task.id,
            event_type=TimelineEventType.TASK_CREATED,
            message=f"Task started: {task.instruction[:120]}",
            data={"instruction": task.instruction},
        )

        if not self._sandbox:
            logger.error("No sandbox provider configured — cannot run task")
            task.status = TaskStatus.ABANDONED
            task.completed_at = _utcnow()
            return task

        sandbox_id: str | None = None
        last_error: ErrorSignature | None = None

        try:
            sandbox_id = await self._create_sandbox()
            task.metadata["sandbox_id"] = sandbox_id
        except Exception:
            logger.exception("Failed to create sandbox for task_id=%s", task.id)
            task.status = TaskStatus.ABANDONED
            task.completed_at = _utcnow()
            self._timeline.emit(
                task_id=task.id,
                event_type=TimelineEventType.TASK_ABANDONED,
                message="Abandoned: sandbox creation failed",
            )
            self._timeline.close_subscribers(task.id)
            return task

        try:
            while True:
                attempt_number = task.current_attempt + 1

                # ---- RETRIEVE ------------------------------------------------
                retry_context: dict[str, Any] = {}
                if last_error is not None and self._retry_engine:
                    retry_context = await self._retrieve(task, last_error, attempt_number)
                elif last_error is None and self._memory and attempt_number == 1:
                    # Attempt 1: proactive memory search by instruction
                    # This is what gives the with-memory agent its advantage
                    try:
                        # Use backend directly — vector search with instruction
                        # text returns nothing (embeddings are error-based).
                        # Empty query fetches recent failures; filter here.
                        all_failures = await self._memory._backend.search(
                            query="",
                            limit=20,
                        )
                        similar = [
                            r for r in all_failures
                            if r.transferable and r.task_id != task.id
                        ][:5]
                        if similar:
                            memory_ctx = self._memory.build_memory_context(similar)
                            anti_patterns = [
                                r.analysis.anti_pattern
                                for r in similar
                                if r.analysis.anti_pattern
                            ]
                            retry_context = {
                                "recalled_memories": memory_ctx,
                                "anti_patterns": anti_patterns,
                                "raw_failures": similar,
                            }
                            self._timeline.emit(
                                task_id=task.id,
                                event_type=TimelineEventType.MEMORY_RECALLED,
                                attempt_number=attempt_number,
                                message=f"Proactive memory: recalled {len(similar)} relevant failure(s)",
                                data={"recalled_count": len(similar), "proactive": True},
                            )
                            logger.info(
                                "task_id=%s attempt=1 PROACTIVE RETRIEVE: recalled %d failures from memory",
                                task.id, len(similar),
                            )
                    except Exception:
                        logger.warning(
                            "Proactive memory search failed for task_id=%s; continuing without",
                            task.id, exc_info=True,
                        )

                # ---- PREDICT (pre-mortem) ------------------------------------
                if self._memory:
                    try:
                        predictions = await self._memory.predict_likely_failures(
                            instruction=task.instruction,
                            context=task.metadata.get("context"),
                            limit=3,
                        )
                    except Exception:
                        logger.warning(
                            "predict_likely_failures failed for task_id=%s; skipping",
                            task.id,
                            exc_info=True,
                        )
                        predictions = []

                    if predictions:
                        self._timeline.emit(
                            task_id=task.id,
                            event_type=TimelineEventType.PREDICTION,
                            attempt_number=attempt_number,
                            message=f"Predicted {len(predictions)} likely failure(s) before execution",
                            data={"predictions": predictions},
                        )
                        retry_context["predictions"] = predictions
                        retry_context["prediction_warnings"] = [
                            f"WARNING: {p['error_type']} has {p['prediction_score']:.0%} chance of occurring."
                            f" Prevention: {p['suggested_prevention']}"
                            for p in predictions
                        ]
                        # High-confidence predictions (>80%) become proactive mitigations
                        high_conf = [p for p in predictions if p["prediction_score"] > 0.8]
                        if high_conf:
                            proactive = [
                                f"PROACTIVE FIX for {p['error_type']}: {p['suggested_prevention']}"
                                for p in high_conf
                            ]
                            existing_anti = list(retry_context.get("anti_patterns", []))
                            retry_context["anti_patterns"] = existing_anti + proactive

                        logger.info(
                            "task_id=%s attempt=%d PREDICT: %d predicted failure(s), %d high-confidence",
                            task.id,
                            attempt_number,
                            len(predictions),
                            len(high_conf) if predictions else 0,
                        )

                # ---- EXECUTE -------------------------------------------------
                attempt = await self._execute(
                    task=task,
                    sandbox_id=sandbox_id,
                    attempt_number=attempt_number,
                    retry_context=retry_context,
                )

                # ---- CHECKPOINT after each attempt --------------------------
                if self._sandbox and sandbox_id:
                    try:
                        ckpt_id = await self._sandbox.checkpoint(sandbox_id)
                        attempt.checkpoint_id = ckpt_id
                        self._timeline.emit(
                            task_id=task.id,
                            event_type=TimelineEventType.CHECKPOINT_CREATED,
                            attempt_number=attempt_number,
                            message=f"Checkpoint {ckpt_id} created after attempt {attempt_number}",
                            data={"checkpoint_id": ckpt_id},
                        )
                    except Exception:
                        logger.warning(
                            "Checkpoint creation failed for task_id=%s attempt=%d",
                            task.id, attempt_number, exc_info=True,
                        )

                task.attempts.append(attempt)
                task.current_attempt = attempt_number
                task.total_cost_usd += attempt.cost_usd

                # ---- JUDGE ---------------------------------------------------
                succeeded = attempt.status == AttemptStatus.SUCCEEDED

                if succeeded:
                    # ---- DISTILL (success) -----------------------------------
                    await self._distill_success(task, attempt)
                    task.status = TaskStatus.SUCCEEDED
                    task.completed_at = _utcnow()
                    task.result = self._extract_result(attempt)
                    self._timeline.emit(
                        task_id=task.id,
                        event_type=TimelineEventType.TASK_COMPLETED,
                        attempt_number=attempt_number,
                        message="Task succeeded",
                        data={
                            "result": task.result,
                            "total_cost_usd": task.total_cost_usd,
                            "attempt_cost_usd": attempt.cost_usd,
                        },
                    )
                    break

                # ---- DISTILL (failure) ---------------------------------------
                last_error = await self._distill_failure(task, attempt)

                # Store the error hash in task metadata for the circuit breaker.
                if last_error:
                    task.metadata[f"attempt_{attempt_number}_error_hash"] = (
                        last_error.error_hash
                    )

                # ---- CHECK RETRY CONDITIONS ----------------------------------
                if not self._retry_engine or not self._retry_engine.should_retry(task):
                    # Check if the circuit breaker specifically caused the stop,
                    # and if so emit a dedicated event with full state details.
                    if self._retry_engine and self._retry_engine._circuit_is_open(task):
                        cb_state: CircuitBreakerState = self._retry_engine.get_circuit_breaker_state(task)
                        self._timeline.emit(
                            task_id=task.id,
                            event_type=TimelineEventType.CIRCUIT_BREAKER_OPEN,
                            attempt_number=attempt_number,
                            message=(
                                f"Circuit breaker open: agent failed {cb_state.consecutive_same_error} "
                                f"consecutive times with the same error. "
                                f"This suggests a fundamental issue that retrying won't fix."
                            ),
                            data={
                                "is_open": cb_state.is_open,
                                "consecutive_same_error": cb_state.consecutive_same_error,
                                "error_hash": cb_state.error_hash,
                                "error_type": cb_state.error_type,
                                "reason": cb_state.reason,
                                "recommendation": cb_state.recommendation,
                            },
                        )
                    task.status = TaskStatus.ABANDONED
                    task.completed_at = _utcnow()
                    self._timeline.emit(
                        task_id=task.id,
                        event_type=TimelineEventType.TASK_ABANDONED,
                        attempt_number=attempt_number,
                        message="Task abandoned: no more retries or budget exhausted",
                        data={"total_cost_usd": task.total_cost_usd},
                    )
                    break

                # Otherwise, loop back to RETRIEVE with updated last_error.

        except Exception:
            logger.exception("Unexpected error in REJD loop for task_id=%s", task.id)
            task.status = TaskStatus.FAILED
            task.completed_at = _utcnow()
            self._timeline.emit(
                task_id=task.id,
                event_type=TimelineEventType.TASK_ABANDONED,
                message="Task failed due to unexpected internal error",
            )
        finally:
            if sandbox_id:
                await self._destroy_sandbox(sandbox_id)
            self._timeline.close_subscribers(task.id)

        return task

    async def run_ab_comparison(self, task: Task) -> dict[str, Any]:
        """Run the same task twice: once WITHOUT memory, once WITH memory.

        Returns a dict with keys ``without_memory`` and ``with_memory``, each
        containing the completed Task object and key metrics.
        """
        import copy

        # --- Run WITHOUT memory (fresh backend with no stored memories) ---
        from src.providers.memory.sqlite_backend import SQLiteMemoryBackend  # type: ignore[import]

        # Use an in-memory (ephemeral) SQLite backend for the no-memory run.
        empty_backend = SQLiteMemoryBackend(":memory:")
        no_memory_agent = ReLoopAgent(
            memory_backend=empty_backend,
            sandbox=self._sandbox,
            llm=self._llm,
            max_retries=self._max_retries,
            max_budget_usd=self._max_budget_usd,
            circuit_breaker_threshold=self._circuit_breaker_threshold,
        )
        task_no_memory = copy.deepcopy(task)
        task_no_memory.id = task_no_memory.id + "_no_mem"

        logger.info("A/B comparison: running WITHOUT memory for task_id=%s", task.id)
        result_no_memory = await no_memory_agent.run(task_no_memory)

        # --- Run WITH memory (real backend) ---
        task_with_memory = copy.deepcopy(task)
        task_with_memory.id = task_with_memory.id + "_with_mem"

        logger.info("A/B comparison: running WITH memory for task_id=%s", task.id)
        result_with_memory = await self.run(task_with_memory)

        # Count failures avoided via cross-project transfer.
        # These are attempts where memory was recalled from a different task_id.
        failures_avoided_via_transfer = 0
        if self._memory:
            try:
                transferred = await self._memory._backend.search(query="", limit=200)
                transfer_ids = {
                    r.id for r in transferred
                    if r.transferable and r.task_id != task_with_memory.id
                }
                for att in result_with_memory.attempts:
                    for mem_id in att.recalled_memories:
                        if mem_id in transfer_ids:
                            failures_avoided_via_transfer += 1
                            break
            except Exception:
                logger.debug("Could not count transferred failures for A/B comparison")

        return {
            "without_memory": {
                "task": result_no_memory,
                "total_attempts": result_no_memory.current_attempt,
                "total_cost_usd": result_no_memory.total_cost_usd,
                "status": result_no_memory.status.value,
                "succeeded": result_no_memory.status == TaskStatus.SUCCEEDED,
            },
            "with_memory": {
                "task": result_with_memory,
                "total_attempts": result_with_memory.current_attempt,
                "total_cost_usd": result_with_memory.total_cost_usd,
                "status": result_with_memory.status.value,
                "succeeded": result_with_memory.status == TaskStatus.SUCCEEDED,
                "failures_avoided_via_transfer": failures_avoided_via_transfer,
            },
        }

    # ------------------------------------------------------------------
    # REJD step implementations
    # ------------------------------------------------------------------

    async def _retrieve(
        self,
        task: Task,
        last_error: ErrorSignature,
        attempt_number: int,
    ) -> dict[str, Any]:
        """RETRIEVE step: query memory for similar failures."""
        self._timeline.emit(
            task_id=task.id,
            event_type=TimelineEventType.MEMORY_RECALLED,
            attempt_number=attempt_number,
            message=f"Querying failure memory for: {last_error.error_type}",
            data={"error_type": last_error.error_type, "error_hash": last_error.error_hash},
        )

        retry_context = await self._retry_engine.prepare_retry_context(
            task=task,
            last_error=last_error,
        )

        recalled_count = len(retry_context.get("raw_failures", []))
        logger.info(
            "task_id=%s attempt=%d RETRIEVE: recalled %d similar failures",
            task.id,
            attempt_number,
            recalled_count,
        )
        return retry_context

    async def _execute(
        self,
        task: Task,
        sandbox_id: str,
        attempt_number: int,
        retry_context: dict[str, Any],
    ) -> Attempt:
        """EXECUTE step: run the task command in the sandbox."""
        attempt = Attempt(attempt_number=attempt_number)

        self._timeline.emit(
            task_id=task.id,
            event_type=TimelineEventType.ATTEMPT_STARTED,
            attempt_number=attempt_number,
            message=f"Starting attempt {attempt_number}",
            data={"has_memory_context": bool(retry_context.get("recalled_memories"))},
        )

        # Attach recalled memory IDs for provenance tracking.
        raw_failures = retry_context.get("raw_failures", [])
        attempt.recalled_memories = [f.id for f in raw_failures]

        # ---- PLANNING STEP (OpenAI Agents SDK or basic Planner) ----------------
        plan = None
        attempt_llm_cost = 0.0
        if self._planner:
            try:
                plan_kwargs: dict[str, Any] = {
                    "instruction": task.instruction,
                    "failure_history": raw_failures,
                    "retry_context": retry_context,
                }
                if isinstance(self._planner, AgentsOrchestrator):
                    plan_kwargs["sandbox_id"] = sandbox_id
                plan = await self._planner.plan_next_action(**plan_kwargs)
                attempt_llm_cost += plan.cost_usd
                self._timeline.emit(
                    task_id=task.id,
                    event_type=TimelineEventType.STEP_STARTED,
                    attempt_number=attempt_number,
                    step_number=0,
                    message=f"Planner decided: {plan.strategy}",
                    data={
                        "strategy": plan.strategy,
                        "commands": plan.commands,
                        "avoid_patterns": plan.avoid_patterns,
                        "confidence": plan.confidence,
                        "plan_cost_usd": plan.cost_usd,
                    },
                )
            except Exception:
                logger.warning(
                    "Planner failed for task_id=%s attempt=%d; using raw instruction",
                    task.id, attempt_number, exc_info=True,
                )
                plan = None

        if plan and plan.commands:
            merged_ctx = dict(retry_context)
            if plan.avoid_patterns:
                existing = list(merged_ctx.get("anti_patterns", []))
                merged_ctx["anti_patterns"] = existing + plan.avoid_patterns
            planned_cmd = " && ".join(plan.commands) if len(plan.commands) > 1 else plan.commands[0]
            command = self._build_command(planned_cmd, merged_ctx)
        else:
            command = self._build_command(task.instruction, retry_context)

        step = StepResult(
            step_number=1,
            description="Execute task command",
            command=command,
        )
        self._timeline.emit(
            task_id=task.id,
            event_type=TimelineEventType.STEP_STARTED,
            attempt_number=attempt_number,
            step_number=1,
            message=f"Executing command (attempt {attempt_number})",
            data={"command": command[:512]},
        )

        # Accumulate planner LLM cost into the attempt early so that
        # timeline events emitted below already reflect it.  Distiller
        # costs are added later in _distill_failure / _distill_success.
        attempt.cost_usd += attempt_llm_cost

        try:
            exec_result: ExecutionResult = await self._sandbox.execute(
                sandbox_id=sandbox_id,
                command=command,
                timeout=settings.sandbox_timeout_seconds,
            )
            step.output = exec_result.stdout
            step.error = exec_result.stderr if not exec_result.success else None
            # Fallback: use stdout as error when stderr is empty for failed steps
            if not exec_result.success and not step.error and exec_result.stdout:
                step.error = exec_result.stdout
            step.completed_at = _utcnow()

            if exec_result.success:
                step.status = AttemptStatus.SUCCEEDED
                attempt.status = AttemptStatus.SUCCEEDED
                self._timeline.emit(
                    task_id=task.id,
                    event_type=TimelineEventType.STEP_COMPLETED,
                    attempt_number=attempt_number,
                    step_number=1,
                    message="Step succeeded",
                    data={"exit_code": exec_result.exit_code, "output": exec_result.stdout[:256]},
                )
                self._timeline.emit(
                    task_id=task.id,
                    event_type=TimelineEventType.ATTEMPT_SUCCEEDED,
                    attempt_number=attempt_number,
                    message=f"Attempt {attempt_number} succeeded",
                    data={"cost_usd": attempt.cost_usd},
                )
            else:
                step.status = AttemptStatus.FAILED
                attempt.status = AttemptStatus.FAILED
                self._timeline.emit(
                    task_id=task.id,
                    event_type=TimelineEventType.STEP_FAILED,
                    attempt_number=attempt_number,
                    step_number=1,
                    message="Step failed",
                    data={
                        "exit_code": exec_result.exit_code,
                        "error": exec_result.stderr[:512],
                    },
                )
                self._timeline.emit(
                    task_id=task.id,
                    event_type=TimelineEventType.ATTEMPT_FAILED,
                    attempt_number=attempt_number,
                    message=f"Attempt {attempt_number} failed",
                    data={"error": exec_result.stderr[:256], "cost_usd": attempt.cost_usd},
                )

        except Exception as exc:
            logger.exception(
                "Sandbox execution raised an exception for task_id=%s attempt=%d",
                task.id,
                attempt_number,
            )
            step.status = AttemptStatus.FAILED
            step.error = str(exc)
            step.completed_at = _utcnow()
            attempt.status = AttemptStatus.FAILED
            self._timeline.emit(
                task_id=task.id,
                event_type=TimelineEventType.ATTEMPT_FAILED,
                attempt_number=attempt_number,
                message=f"Attempt {attempt_number} failed with exception: {exc}",
                data={"exception": str(exc), "cost_usd": attempt.cost_usd},
            )

        attempt.steps.append(step)
        attempt.completed_at = _utcnow()
        return attempt

    async def _distill_failure(
        self,
        task: Task,
        attempt: Attempt,
    ) -> ErrorSignature | None:
        """DISTILL (failure) step: analyse the failure, store memory, return ErrorSignature."""
        failed_step = next(
            (s for s in reversed(attempt.steps) if s.status == AttemptStatus.FAILED),
            None,
        )
        if failed_step is None:
            logger.warning(
                "task_id=%s attempt=%d: no failed step found for distillation",
                task.id,
                attempt.attempt_number,
            )
            return None

        error_text = failed_step.error or ""
        output_text = failed_step.output or ""

        # Classify the error.
        error_type = self._infer_error_type(error_text)
        try:
            error_category, classify_cost = await self._distiller.classify_error(  # type: ignore[union-attr]
                error_type=error_type,
                error_message=error_text,
            )
            attempt.cost_usd += classify_cost
            task.total_cost_usd += classify_cost
        except Exception:
            logger.warning("classify_error failed; defaulting to UNKNOWN")
            error_category = ErrorCategory.UNKNOWN

        signature = ErrorSignature(
            error_type=error_type,
            error_category=error_category,
            error_message=error_text[:1024],
            code_context=failed_step.command[:512],
        )

        # Distill failure analysis via LLM.
        distill_cost = 0.0
        transferable = True
        try:
            analysis, distill_cost, transferable = await self._distiller.distill_failure(
                command=failed_step.command,
                output=output_text,
                error=error_text,
                context={
                    "task_id": task.id,
                    "attempt_number": attempt.attempt_number,
                    "instruction": task.instruction[:512],
                },
            )
            attempt.cost_usd += distill_cost
            task.total_cost_usd += distill_cost
        except Exception:
            logger.exception("distill_failure raised; using minimal analysis")
            analysis = FailureAnalysis(
                root_cause="Distillation failed",
                what_was_tried=failed_step.command,
                why_it_failed=error_text,
                suggested_fix="",
                anti_pattern="",
                confidence=0.2,
            )

        # Persist to memory (if available).
        if not self._memory:
            return signature
        failure_record = await self._memory.store_failure(
            task_id=task.id,
            attempt_number=attempt.attempt_number,
            signature=signature,
            analysis=analysis,
            context={
                "instruction": task.instruction[:256],
                "command": failed_step.command[:256],
            },
            cost=attempt.cost_usd,
            transferable=transferable,
        )
        attempt.failure_record_id = failure_record.id

        self._timeline.emit(
            task_id=task.id,
            event_type=TimelineEventType.MEMORY_STORED,
            attempt_number=attempt.attempt_number,
            message=f"Failure recorded: {analysis.root_cause[:100]}",
            data={
                "failure_record_id": failure_record.id,
                "error_type": error_type,
                "confidence": analysis.confidence,
            },
        )

        return signature

    async def _distill_success(
        self,
        task: Task,
        attempt: Attempt,
    ) -> None:
        """DISTILL (success) step: summarise the solution and store as SuccessRecord."""
        if not self._memory:
            return
        try:
            success_summary, distill_cost = await self._distiller.distill_success(  # type: ignore[union-attr]
                task=task,
                attempts=task.attempts,
            )
            attempt.cost_usd += distill_cost
            task.total_cost_usd += distill_cost
        except Exception:
            logger.exception("distill_success raised; using minimal summary")
            success_summary = {
                "approach": "Task succeeded",
                "key_insight": "",
                "failures_that_helped": [],
                "transferable": False,
                "total_attempts": len(task.attempts),
            }

        metrics: dict[str, Any] = {
            "total_attempts": task.current_attempt,
            "total_cost_usd": task.total_cost_usd,
        }
        solution: dict[str, str] = {
            "approach": success_summary.get("approach", ""),
            "key_insight": success_summary.get("key_insight", ""),
        }
        learning: dict[str, Any] = {
            "failure_count": task.current_attempt - 1,
            "failures_that_helped": success_summary.get("failures_that_helped", []),
            "transferable": success_summary.get("transferable", False),
        }

        await self._memory.store_success(
            task_id=task.id,
            attempt_number=attempt.attempt_number,
            solution=solution,
            learning=learning,
            metrics=metrics,
        )

        self._timeline.emit(
            task_id=task.id,
            event_type=TimelineEventType.MEMORY_STORED,
            attempt_number=attempt.attempt_number,
            message="Success recorded in memory",
            data={"approach": solution["approach"][:200]},
        )

    # ------------------------------------------------------------------
    # Sandbox lifecycle helpers
    # ------------------------------------------------------------------

    async def _create_sandbox(self) -> str:
        """Create a sandbox and return its ID."""
        sandbox_id = await self._sandbox.create()
        logger.info("Created sandbox id=%s", sandbox_id)
        return sandbox_id

    async def _destroy_sandbox(self, sandbox_id: str) -> None:
        """Destroy a sandbox, swallowing any errors."""
        try:
            await self._sandbox.destroy(sandbox_id)
            logger.info("Destroyed sandbox id=%s", sandbox_id)
        except Exception:
            logger.warning("Failed to destroy sandbox id=%s", sandbox_id, exc_info=True)

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_command(instruction: str, retry_context: dict[str, Any]) -> str:
        """Build the shell command from a task instruction.

        Memory context is injected into the Planner prompt (not here).
        Prepending large comment blocks broke sh parsing, so we keep
        the command clean.
        """
        return instruction

    # Common non-Python error patterns: (regex, label)
    _ERROR_PATTERNS: list[tuple[str, str]] = [
        # Python / Node standard errors
        (r"((?:[A-Z][a-zA-Z]*(?:Error|Exception|Warning|Fault))[^\n:]*)", None),  # type: ignore[list-item]
        # npm errors
        (r"npm ERR!\s*(.*)", "NpmError"),
        (r"npm error\s*(.*)", "NpmError"),
        # Node / V8 errors
        (r"Error:\s*(EADDRINUSE[^\n]*)", "PortConflict"),
        (r"Error:\s*(ENOENT[^\n]*)", "FileNotFoundError"),
        (r"Error:\s*(EACCES[^\n]*)", "PermissionError"),
        (r"Error:\s*(ECONNREFUSED[^\n]*)", "ConnectionRefused"),
        (r"Error:\s*(Cannot find module[^\n]*)", "ModuleNotFoundError"),
        # Bash / shell errors
        (r"bash:\s*([^:]+):\s*command not found", "CommandNotFound"),
        (r"sh:\s*([^:]+):\s*not found", "CommandNotFound"),
        (r"command not found:\s*(.*)", "CommandNotFound"),
        # Python import / module errors
        (r"ModuleNotFoundError:\s*(.*)", "ModuleNotFoundError"),
        (r"ImportError:\s*(.*)", "ImportError"),
        (r"No module named\s+(.*)", "ModuleNotFoundError"),
        # TypeScript compiler errors
        (r"error TS\d+:\s*(.*)", "TypeScriptError"),
        (r"TS\d+:\s*(.*)", "TypeScriptError"),
        # Generic "Error:" pattern (common in JS)
        (r"(?:^|\n)\s*Error:\s*([^\n]+)", "RuntimeError"),
        # Exit code failures
        (r"exit (?:code|status)\s+(\d+)", "ProcessExitError"),
        (r"exited with code\s+(\d+)", "ProcessExitError"),
    ]

    @staticmethod
    def _infer_error_type(error_text: str) -> str:
        """Heuristically extract a meaningful error type from an error string.

        Handles Python-style errors, npm/node errors, shell errors, and
        TypeScript compiler errors — not just ``SomeError:`` patterns.
        """
        if not error_text:
            return "UnknownError"

        import re

        for pattern, label in ReLoopAgent._ERROR_PATTERNS:
            match = re.search(pattern, error_text, re.MULTILINE | re.IGNORECASE)
            if match:
                if label is None:
                    # Python-style: use the matched group directly
                    return match.group(1).strip()
                return label

        # Fallback: use the first non-empty line truncated to 64 chars.
        first_line = next(
            (line.strip() for line in error_text.splitlines() if line.strip()),
            "UnknownError",
        )
        return first_line[:64]

    @staticmethod
    def _extract_result(attempt: Attempt) -> str:
        """Extract a meaningful result string from a successful attempt."""
        successful_steps = [s for s in attempt.steps if s.status == AttemptStatus.SUCCEEDED]
        if successful_steps:
            last = successful_steps[-1]
            output = last.output.strip()
            return output[:2048] if output else "Task completed successfully"
        return "Task completed successfully"
