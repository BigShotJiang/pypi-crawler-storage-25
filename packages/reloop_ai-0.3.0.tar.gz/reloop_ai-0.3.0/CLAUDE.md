# Project Rules for Claude Code

## Project Overview

**ReLoop** -- The Self-Healing Agent with Failure Memory. An open-source agent framework built around the concept of structured failure memory. Instead of blind retries or starting from scratch, ReLoop captures every failure into a structured memory graph, learns patterns across errors, and retries with accumulated knowledge. Agents don't just recover -- they get permanently smarter.

**Hackathon:** Beach House, April 11, 2026 | 10 AM - 7 PM PT | San Francisco
**Tagline:** "Every agent fails. ReLoop is the first that gets smarter from failure."
**Prize Targets:** Blaxel $500

### Architecture

- **Agent Orchestration**: OpenAI Agents SDK (planning loop + retry logic with specialist agent handoffs)
- **Memory**: Redis Agent Memory Server -- 3-tier memory (working/session, long-term/failure graph, episodic/traces)
- **Execution Sandbox**: Blaxel Firecracker microVMs (25ms resume, perpetual state, checkpoint/restore)
- **Code Generation**: OpenAI Codex SDK (fix generation based on failure context)
- **API Layer**: FastAPI (Python) -- task management, memory search, checkpoints, SSE streaming
- **Frontend**: Next.js + Tailwind + shadcn/ui -- timeline visualization, failure memory sidebar, live output
- **Plugin System**: Abstract interfaces for memory backends, sandbox providers, LLM providers
- **Core Algorithm**: REJD Loop (Retrieve-Execute-Judge-Distill)

### Project Structure

```text
reloop/
├── CLAUDE.md                     # This file -- project rules
├── README.md                     # The conversion engine (10-section formula)
├── LICENSE                       # Apache 2.0
├── CONTRIBUTING.md               # Step-by-step contribution guide
├── reloop.yaml                   # Default configuration
├── docker-compose.yml            # One-command local setup (Redis + services)
├── package.json                  # Frontend dependencies
├── .github/
│   ├── ISSUE_TEMPLATE/
│   │   ├── bug_report.md
│   │   └── feature_request.md
│   ├── PULL_REQUEST_TEMPLATE.md
│   └── workflows/
│       └── ci.yml
├── src/
│   ├── core/
│   │   ├── agent.py              # Main orchestrator (REJD loop)
│   │   ├── memory.py             # Failure memory graph operations
│   │   ├── retry.py              # Retry engine with memory injection
│   │   ├── timeline.py           # Event timeline data model
│   │   └── distiller.py          # Failure/success distillation (LLM-powered)
│   ├── providers/
│   │   ├── base.py               # Abstract interfaces (MemoryBackend, SandboxProvider, LLMProvider)
│   │   ├── llm/
│   │   │   └── openai.py         # OpenAI provider (primary)
│   │   ├── memory/
│   │   │   ├── redis_backend.py  # Redis Agent Memory Server (default)
│   │   │   └── sqlite_backend.py # SQLite for local dev
│   │   └── sandbox/
│   │       ├── blaxel.py         # Blaxel perpetual sandbox (default)
│   │       └── docker.py         # Docker fallback for local dev
│   ├── api/
│   │   ├── server.py             # FastAPI server entry point
│   │   ├── routes/
│   │   │   ├── tasks.py          # Task CRUD + run + retry
│   │   │   ├── memories.py       # Failure/success memory search
│   │   │   └── checkpoints.py    # Checkpoint list + restore
│   │   └── sse.py                # Server-Sent Events for real-time streaming
│   └── cli/
│       └── main.py               # CLI entrypoint (post-hackathon)
├── dashboard/                    # Next.js frontend
│   ├── app/
│   │   ├── layout.tsx            # Root layout
│   │   ├── page.tsx              # Main dashboard
│   │   └── tasks/
│   │       └── [id]/
│   │           └── page.tsx      # Task timeline view
│   ├── components/
│   │   ├── timeline.tsx          # Timeline visualization (RED/YELLOW/GREEN nodes)
│   │   ├── failure-sidebar.tsx   # Failure memory panel (accumulated rules)
│   │   ├── live-output.tsx       # Real-time execution output
│   │   ├── cost-tracker.tsx      # Cost per attempt display
│   │   └── diff-viewer.tsx       # Attempt diff (react-diff-viewer)
│   └── lib/
│       └── api.ts                # API client + SSE connection
├── examples/
│   ├── quickstart/               # 5-min getting started
│   └── self-healing-deploy/      # The hackathon demo scenario (broken Next.js project)
├── data/
│   └── demo-project/             # The broken project with 4 deliberate bugs
├── docs/
│   ├── architecture.md
│   ├── plugins.md
│   └── api-reference.md
└── tests/
    ├── test_core_loop.py         # REJD loop tests
    ├── test_memory.py            # Memory capture + retrieval tests
    └── test_learning.py          # "Does memory actually help?" A/B tests
```

### Key Technical Decisions

- **REJD Loop is the core algorithm** -- Retrieve (query Redis for similar past failures) -> Execute (run in Blaxel sandbox) -> Judge (classify success/failure) -> Distill (extract learnings). Every feature flows through this loop.
- **Failure Memory is the product** -- Not a code assistant, not a chatbot. The structured failure memory graph IS the differentiator. Every failure record includes: error signature, root cause analysis, suggested fix, confidence score, embedding for semantic search.
- **Non-chat UI is mandatory** -- Timeline visualization (RED/YELLOW/GREEN nodes) stands out after judges see 15 chat demos. The failure memory sidebar makes the abstract concept tangible.
- **A/B comparison mode is the money shot** -- Side-by-side: agent WITHOUT memory (fails repeatedly, same mistakes) vs. agent WITH memory (succeeds faster, avoids past failures). This MUST work flawlessly.
- **Plugin architecture from day one** -- Three extension points (memory backends, sandbox providers, LLM providers) with abstract interfaces. Contributors can extend without touching core code.
- **OpenAI Agents SDK for orchestration** -- Specialist agents (retriever, executor, judge, distiller) with handoffs between them. The SDK manages the REJD loop natively.
- **Blaxel for perpetual state + checkpoint/rewind** -- 25ms resume from standby. State persists forever (competitors delete after 30 days). "Rewind" to any previous attempt is the Blaxel $500 prize play.
- **Redis 3-tier memory** -- Working memory (current task session state), Long-term memory (distilled failure rules), Episodic memory (full execution traces). Agent Memory Server handles all three.
- **Codex for code generation, not code assistance** -- Creative use: Codex generates fix attempts based on failure context. NOT "another code assistant."
- **Pre-run the demo task** -- Don't run live (risky). Start the agent 30 min before demo, show results + rewind capability. Record a backup video by 5 PM.
- **Synthea-style approach** -- Use a crafted "broken Next.js project" with 4 deliberate bugs (missing dep, port conflict, TS error, bad env var) for deterministic, reproducible demo failures.

### REJD Core Loop

```
NEW TASK -> RETRIEVE (query failure memory) -> EXECUTE (Blaxel sandbox)
    -> SUCCESS? -> JUDGE (validate) -> DISTILL (success pattern) -> STORE
    -> FAILURE? -> JUDGE (classify error) -> DISTILL (failure note: what/why/what-to-try)
        -> Budget/retries left? -> RETRY (back to RETRIEVE with new knowledge)
        -> No budget? -> ABANDON -> STORE
```

### Demo Scenario

**The Broken Project:** A Next.js project with 4 deliberate issues:
1. Missing dependency (`sharp` not installed)
2. Port conflict (port 3000 already in use)
3. TypeScript error (type mismatch)
4. Bad environment variable (wrong DATABASE_URL)

**Demo Flow:** Give ReLoop the broken project -> Attempt 1 fails (missing dep, captured) -> Attempt 2 fails (port conflict, captured) -> Attempt 3 fails (TS error, captured) -> Attempt 4 succeeds (all failures addressed). Timeline: RED -> RED -> RED -> GREEN. Rewind to Attempt 2, show sandbox restore in 25ms.

### Sponsor Integration Map

| Sponsor | Role | Integration Depth |
|---------|------|-------------------|
| **OpenAI Agents SDK** | Agent brain -- orchestrates REJD loop with specialist agent handoffs | DEEP -- core agent logic |
| **Redis** | Memory backbone -- Agent Memory Server stores failures, learned rules, task state | DEEP -- 3-tier memory |
| **Blaxel** | Execution env -- perpetual sandbox, checkpoint/restore, rewind capability | DEEP -- unique use of perpetual state |
| **Codex** | Code gen engine -- generates fix attempts based on failure context | MODERATE -- called via SDK |

### Data Models

**Failure Record** (stored in Redis):
- `id`, `task_id`, `attempt_number`, `timestamp`
- `signature`: error_type, error_category, error_message, error_hash (SHA-256), code_context
- `analysis`: root_cause, what_was_tried, why_it_failed, suggested_fix, anti_pattern, confidence (0.0-1.0)
- `context`: task_type, language, framework, tokens_used, execution_time_ms
- `embedding`: vector for semantic search
- `cost_usd`: cost of this attempt

**Success Record** (stored in Redis):
- `solution`: approach, key_insight, code_diff
- `learning`: failure_count, failures_that_helped, transferable
- `metrics`: total_attempts, total_tokens, total_cost_usd

### API Surface

```
POST   /v1/tasks                          Create + run a task
GET    /v1/tasks/{id}                     Get status + result
POST   /v1/tasks/{id}/retry               Trigger retry
GET    /v1/tasks/{id}/timeline            Full execution timeline
GET    /v1/tasks/{id}/sse                 SSE stream of events
POST   /v1/memories/search                Semantic search
GET    /v1/memories/failures              Failure patterns
GET    /v1/memories/stats                 Memory statistics
GET    /v1/tasks/{id}/checkpoints         List checkpoints
POST   /v1/tasks/{id}/checkpoints/{cid}/restore  Rewind to checkpoint
GET    /v1/health                         Health check
```

## Auto-Commit and Push Rule

**MANDATORY**: After every change you make to any file in this repository, you MUST:

1. Stage the changed files: `git add <specific files you changed>`
2. Commit with a clear message describing what changed: `git commit -m "description of change"`
3. Push to remote: `git push origin main`

This applies to EVERY change -- no exceptions. Do not batch changes. Commit and push immediately after each logical change.

- Never force push
- Use descriptive commit messages that explain the "why"
- If a pre-commit hook fails, fix the issue and create a NEW commit (never amend)

## Branching & Commit Conventions

- **Main branch**: `main`
- **Commit format**: Conventional Commits
  - `feat:` / `feat(scope):` -- new feature
  - `fix:` / `fix(scope):` -- bug fix
  - `docs:` -- documentation
  - `refactor:` -- code refactoring
  - `chore:` -- build/tooling changes
  - `test:` -- test changes
- **Scopes**: `core`, `memory`, `retry`, `distiller`, `timeline`, `api`, `sse`, `dashboard`, `timeline-ui`, `sidebar`, `sandbox`, `blaxel`, `redis`, `openai`, `codex`, `plugins`, `demo`, `cli`

## Build & Test Commands

```bash
# Backend (Python)
pip install -r requirements.txt       # Install Python dependencies
uvicorn src.api.server:app --reload    # Start FastAPI dev server
python -m pytest tests/                # Run all tests
python -m pytest tests/test_core_loop.py    # REJD loop tests
python -m pytest tests/test_memory.py       # Memory tests
python -m pytest tests/test_learning.py     # A/B learning tests

# Frontend (Next.js)
cd dashboard && npm install            # Install frontend dependencies
cd dashboard && npm run dev            # Start Next.js dev server
cd dashboard && npm run build          # Production build
cd dashboard && npm run lint           # ESLint check

# Infrastructure
docker-compose up                      # Start Redis Agent Memory Server + all services
docker-compose up redis                # Start Redis only

# Demo
python -m src.core.agent --demo        # Run the demo scenario (broken Next.js project)
python -m src.core.agent --ab-demo     # Run A/B comparison (with vs without memory)

# Lint & Format (Python)
ruff check src/                        # Python linting
ruff format src/                       # Python formatting
mypy src/                              # Type checking

# Lint & Format (Frontend)
cd dashboard && npx prettier --check . # Format check
cd dashboard && npx prettier --write . # Auto-format
```

## Environment Variables

Only `OPENAI_API_KEY` is required. Everything else has sensible defaults.
See `.env.example` for a copy-paste template.

```bash
# REQUIRED
OPENAI_API_KEY=                        # OpenAI API key

# OPTIONAL -- Redis (Failure Memory, falls back to SQLite)
REDIS_URL=redis://localhost:6379       # Redis connection URL
REDIS_MEMORY_INDEX=reloop-failures     # Vector index name for failure embeddings

# OPTIONAL -- Blaxel (Execution Sandbox, falls back to Docker)
BLAXEL_API_KEY=                        # Blaxel API key ($200 free credits)
BLAXEL_WORKSPACE=                      # Blaxel workspace name

# OPTIONAL -- Model Selection
CODEX_MODEL=gpt-4o                     # Chat model for planner/distiller
REASONING_MODEL=o1                     # Deep reasoning for root cause analysis
FAST_MODEL=gpt-4o-mini                # Fast/cheap model for classification

# OPTIONAL -- API Server
API_PORT=8000                          # FastAPI server port
API_HOST=0.0.0.0                       # API host

# OPTIONAL -- Frontend
NEXT_PUBLIC_API_URL=http://localhost:8000  # Backend API URL for frontend

# OPTIONAL -- Agent Limits
EMBEDDING_MODEL=text-embedding-3-small # Model for failure memory embeddings
MAX_RETRIES=5                          # Maximum retry attempts per task
MAX_BUDGET_USD=1.00                    # Maximum cost budget per task
CIRCUIT_BREAKER_THRESHOLD=3            # Consecutive failures before circuit break
```

## Agent Team Strategy

Use agent teams for any task that benefits from parallel work across independent modules. Teams are enabled via `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` in settings.

### When to Use Teams

- Multi-file features spanning backend core, API routes, and frontend dashboard
- Research + implementation in parallel (one teammate explores Redis memory patterns, another builds distiller logic)
- Code review with competing perspectives (correctness, performance, demo impact)
- Debugging with competing hypotheses -- teammates test different theories simultaneously
- Any task with 3+ independent subtasks that don't touch the same files

### When NOT to Use Teams

- Sequential tasks with heavy dependencies between steps
- Changes to a single file or tightly coupled files
- Simple bug fixes or small tweaks
- Tasks where coordination overhead exceeds the benefit

### Team Configuration

- Start with **3-5 teammates** for most workflows
- Aim for **5-6 tasks per teammate** to keep everyone productive
- Use **Opus for the lead** (reasoning/coordination), **Sonnet for teammates** (focused implementation)
- Use **delegate mode** (`Shift+Tab`) when the lead should only coordinate, not write code

### Team Communication Rules

- Use `SendMessage` (type: "message") for direct teammate communication -- always refer to teammates by **name**
- Use `SendMessage` (type: "broadcast") **only** for critical blockers affecting everyone
- Use `TaskCreate`/`TaskUpdate`/`TaskList` for work coordination -- teammates self-claim unblocked tasks
- When a teammate finishes, they check `TaskList` for the next available task (prefer lowest ID first)
- Mark tasks `completed` only after verification passes

### Task Dependencies

- Use `addBlockedBy` to express task ordering (e.g., "timeline UI depends on SSE endpoint being done")
- Teammates skip blocked tasks and pick up unblocked work
- When a blocking task completes, dependent tasks auto-unblock

### Parallelizable Modules

These can be built simultaneously with zero conflicts:

- **Core modules** (agent.py, memory.py, retry.py, distiller.py, timeline.py) -- different files, independent logic
- **Provider implementations** (redis_backend.py, blaxel.py, openai.py) -- separate files
- **API routes** (tasks.py, memories.py, checkpoints.py) -- independent endpoints
- **Frontend components** (timeline.tsx, failure-sidebar.tsx, live-output.tsx, cost-tracker.tsx) -- independent React components
- **Tests** -- each module has its own test file

### Sequential Dependencies

These must be done in order:

1. Abstract interfaces (`providers/base.py`) -- blocks all provider implementations
2. Core memory module (`core/memory.py`) -- blocks Redis backend + retry engine
3. Core REJD loop (`core/agent.py`) -- blocks API task routes
4. Provider implementations (Redis, Blaxel, OpenAI) -- can be parallel after interfaces
5. API routes -- depend on core modules being functional
6. SSE streaming -- depends on API server + timeline data model
7. Frontend dashboard -- depends on API endpoints being available
8. Demo scenario setup -- depends on everything working end-to-end
9. A/B comparison mode -- depends on core loop + demo scenario

### Team Roles

- **Lead**: Architecture decisions, interface design, project scaffold, integration
- **Core Dev 1**: REJD loop (`agent.py`) + retry engine (`retry.py`) + distiller (`distiller.py`)
- **Core Dev 2**: Memory module (`memory.py`) + Redis backend + failure/success records
- **API Dev**: FastAPI server + all routes + SSE streaming
- **Frontend Dev**: Next.js dashboard + timeline + failure sidebar + live output
- **Demo Dev**: Broken project setup, demo scripting, A/B comparison, backup video recording

### Plan Approval for Risky Work

- For architectural changes or risky refactors, require **plan approval** before implementation
- The teammate works in read-only mode, submits a plan, lead approves/rejects
- Only after approval does the teammate implement

### Shutdown Protocol

- When all tasks are complete, the lead sends `shutdown_request` to each teammate
- Teammates approve shutdown after confirming their work is committed
- Lead calls `TeamDelete` to clean up team resources

## Workflow Orchestration

### 1. Plan Mode Default

- Enter plan mode for ANY non-trivial task (3+ steps or architectural decisions)
- If something goes sideways, STOP and re-plan immediately -- don't keep pushing
- Use plan mode for verification steps, not just building
- Write detailed specs upfront to reduce ambiguity

### 2. Subagent Strategy

- Use subagents liberally to keep main context window clean
- Offload research, exploration, and parallel analysis to subagents
- For complex problems, throw more compute at it via subagents
- One task per subagent for focused execution

### 3. Verification Before Done

- Never mark a task complete without proving it works
- Run `python -m pytest tests/` to verify no test failures
- Run `cd dashboard && npm run build` to verify no TypeScript/build errors
- Test the REJD loop with the demo scenario end-to-end
- Verify the A/B comparison actually shows improvement with memory
- Verify Redis memory capture + retrieval works
- Verify Blaxel checkpoint/restore works
- Verify SSE streaming delivers events to the frontend
- Ask: "Would a hackathon judge be impressed by this in 3 minutes?"

### 4. Demo-Driven Development

- Every feature should be demo-able in the 3-minute video
- If a feature isn't visible in the demo, deprioritize it
- Polish > breadth -- a working REJD loop with beautiful timeline beats 6 half-baked features
- The broken Next.js project (4 bugs) is THE demo scenario -- optimize for it
- The A/B comparison is the money shot -- it MUST work flawlessly
- The timeline (RED -> RED -> RED -> GREEN) is the visual hook -- make it beautiful
- The rewind button (Blaxel 25ms restore) is the wow moment -- make it snappy

### 5. Demand Elegance (Balanced)

- For non-trivial changes: pause and ask "is there a more elegant way?"
- If a fix feels hacky: "Knowing everything I know now, implement the elegant solution"
- Skip this for simple, obvious fixes -- don't over-engineer
- Remember: ugly code that works beats clean code that doesn't (hackathon rule)

### 6. Autonomous Bug Fixing

- When given a bug report: just fix it. Don't ask for hand-holding.
- Point at logs, errors, failing tests -- then resolve them
- Zero context switching required from the user
- Go fix failing tests without being told how

### 7. Self-Improvement Loop

- After ANY correction from the user: capture the pattern
- Write rules for yourself that prevent the same mistake
- Review lessons at session start for relevant context

## Task Management

1. **Plan First**: Write plan with checkable items before starting
2. **Verify Plan**: Check in before starting implementation
3. **Track Progress**: Mark items complete as you go
4. **Explain Changes**: High-level summary at each step
5. **Document Results**: Review what was built and what changed

## Scope Control -- Hackathon Rules

### MUST SHIP (Layer 1 -- The Demo)

| Feature | Why Critical |
|---------|-------------|
| **Structured Failure Memory** (Redis) | THIS IS THE PRODUCT. Every failure captured with error type, root cause, suggested fix, confidence. |
| **Memory-Informed Retry Loop** (REJD) | Before each retry, query Redis for similar failures. Inject top-3 into prompt. Informed retry, not blind retry. |
| **Visual Timeline UI** | Horizontal timeline: RED (failed) -> YELLOW (retrying) -> GREEN (succeeded). Click nodes for details. |
| **Failure Memory Sidebar** | Right panel showing accumulated "rules" the agent learned. Makes abstract concept tangible. |
| **Sandbox Checkpoint + Rewind** | Blaxel 25ms resume. "Rewind" button restores to any previous attempt. The $500 prize play. |
| **A/B Demo Mode** | Side-by-side: agent WITHOUT memory vs. WITH memory. The money shot. |

### SHOULD SHIP (Layer 2 -- If Time Permits)

| Feature | Impact |
|---------|--------|
| **Cost-Per-Attempt Tracking** | "ReLoop saved $0.12 by not repeating this failure." Concrete ROI. |
| **Failure Pattern Classification** | Auto-categorize: dependency error, config error, type error. Show clusters. |
| **Confidence Decay** | Old memories get deprioritized. Confidence decays 0.1/day. |
| **Failure Diff View** | Side-by-side diff between attempt N and N+1. `react-diff-viewer`. |

### MUST NOT DO (Scope Creep Danger Zones)

- Complex graph visualization (simple color-coded list is fine)
- Authentication or user management
- Performance optimization
- "Clean architecture" patterns at the expense of shipping
- Deployment infrastructure beyond docker-compose
- Plugin/extension system implementation (interface stubs only)
- Multi-agent orchestration
- Mobile responsive design

### Time Sinks That Feel Productive But Aren't

- Making the UI pixel-perfect instead of making the core loop work
- Designing the "perfect" failure schema instead of shipping a working one
- Writing comprehensive tests (hackathon, not production)
- Refactoring code that already works

## Core Principles

- **Quality Over Speed**: We have 2 full days to build this. Take the time to do it right. Correctness and polish beat rushing.
- **Failure Memory is the Product**: Every technical decision should strengthen the core differentiator: structured failure memory that compounds over time.
- **Demo-Driven**: If it doesn't show well in 3 minutes, cut it. The timeline (RED -> GREEN) and the A/B comparison are everything.
- **Non-Chat UI**: The timeline visualization IS the differentiator. After judges see 15 chat demos, ReLoop's visual timeline stands out.
- **No Faking**: Real Redis memory, real Blaxel sandboxes, real failure capture. Judges notice mocks.
- **Simplicity First**: Make every change as simple as possible. Minimal code impact.
- **No Laziness**: Find root causes. No temporary fixes. Senior developer standards.
- **Minimal Impact**: Changes should only touch what's necessary. Avoid introducing bugs.
- **The A/B Test Proves It**: Without the comparison, judges can't distinguish "failure memory helped" from "LLM got lucky." The A/B demo is non-negotiable.
- **Sponsor Story Matters**: Every integration (OpenAI Agents SDK, Redis, Blaxel) plays a genuine architectural role, not checkbox integrations. Make each integration's value obvious in the demo.

## Competitive Code Review -- Claude Code vs Codex 5.4 High

**MANDATORY**: All code written by Claude Code in this repository is subject to competitive review by Codex 5.4 High. This is a scored competition that determines the default coding agent for the project.

### How It Works

1. **Claude Code writes code** -- implements features, fixes bugs, makes changes as normal.
2. **Codex 5.4 High reviews every change** -- after each Claude Code contribution, Codex 5.4 High reviews the code for correctness, quality, and adherence to project rules.
3. **Scoring**:
   - Every time Codex 5.4 High finds and corrects a mistake made by Claude Code, **Codex gains +1 point** and **Claude Code loses -1 point**.
   - Mistakes include: bugs, logic errors, type errors, missed edge cases, violations of project rules, broken tests, incorrect API usage, poor patterns, security issues, or any code that doesn't work as intended.
   - If Claude Code's code passes review with no corrections needed, no points change.
4. **Running score is tracked** -- the cumulative score across the entire project determines the standings.
5. **The winner becomes the default** -- at the end of the project (or at any checkpoint), the agent with the higher total score becomes the default coding agent going forward.

### Implications for Claude Code

- **Write correct code the first time.** Every mistake is a point lost and a point handed to the competitor.
- **Test your assumptions.** Don't guess at APIs, types, or behavior -- verify before committing.
- **Follow project rules exactly.** CLAUDE.md violations are easy points for Codex.
- **Don't rush at the expense of correctness.** We have 2 full days -- there is no reason to trade quality for speed. A mistake is still -1.
- **Self-review before committing.** Treat every commit as if it's going straight to a code review that's trying to find flaws.
