"""Window data models."""

from typing import Optional
from pydantic import BaseModel, Field
from peekaboowin.models.elements import BoundingBox


class WindowInfo(BaseModel):
    """Window information."""
    hwnd: int = Field(description="Window handle")
    title: str = Field(default="", description="Window title")
    class_name: str = Field(default="", description="Window class name")
    bounds: Optional[BoundingBox] = Field(default=None, description="Window bounding box")
    is_visible: bool = Field(default=True, description="Whether window is visible")
    is_enabled: bool = Field(default=True, description="Whether window is enabled")
    process_id: Optional[int] = Field(default=None, description="Process ID")
    process_name: Optional[str] = Field(default=None, description="Process name")

    def to_dict(self) -> dict:
        result = {
            "hwnd": self.hwnd,
            "title": self.title,
            "class_name": self.class_name,
            "is_visible": self.is_visible,
            "is_enabled": self.is_enabled,
        }
        if self.bounds:
            result["bounds"] = self.bounds.to_tuple()
        if self.process_id is not None:
            result["process_id"] = self.process_id
        if self.process_name is not None:
            result["process_name"] = self.process_name
        return result


class WindowState(BaseModel):
    """Window state information."""
    hwnd: int = Field(description="Window handle")
    is_minimized: bool = Field(default=False, description="Whether window is minimized")
    is_maximized: bool = Field(default=False, description="Whether window is maximized")
    is_visible: bool = Field(default=True, description="Whether window is visible")


class WaitState(BaseModel):
    """State tracking for wait operations."""
    start_time: float = Field(description="Time when wait started")
    timeout: float = Field(description="Maximum time to wait")


class WindowOperationResult(BaseModel):
    """Result of a window operation."""
    success: bool = Field(description="Whether operation succeeded")
    hwnd: int = Field(description="Window handle")
    operation: str = Field(description="Operation name")
    message: str = Field(description="Result message")


class WaitForWindowResult(BaseModel):
    """Result of wait_for_window operation."""
    found: bool = Field(description="Whether window was found")
    window: Optional[WindowInfo] = Field(default=None, description="Window info if found")
    elapsed_ms: float = Field(description="Time elapsed in milliseconds")
