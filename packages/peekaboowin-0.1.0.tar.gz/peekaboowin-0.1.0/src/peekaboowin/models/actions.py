"""Action models for input simulation."""

from typing import Optional, Literal

from pydantic import BaseModel, Field, field_validator


class MouseButton(BaseModel):
    """Mouse button identifier."""

    button: Literal["left", "right", "middle"] = Field(default="left", description="Mouse button")


class ClickAction(BaseModel):
    """Mouse click action."""

    x: int = Field(description="X coordinate")
    y: int = Field(description="Y coordinate")
    button: Literal["left", "right", "middle"] = Field(default="left", description="Mouse button")
    double: bool = Field(default=False, description="Double click")


class DragAction(BaseModel):
    """Mouse drag action."""

    x1: int = Field(description="Start X coordinate")
    y1: int = Field(description="Start Y coordinate")
    x2: int = Field(description="End X coordinate")
    y2: int = Field(description="End Y coordinate")
    duration: float = Field(default=0.5, description="Duration in seconds")


class KeyCombination(BaseModel):
    """Key combination for input."""

    keys: str = Field(description="Key combination string (e.g. 'ctrl+s')")

    @field_validator("keys")
    @classmethod
    def validate_keys(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("Keys cannot be empty")
        return v.strip()


class MouseAction(BaseModel):
    """Mouse action (move, click, scroll)."""

    action: Literal["move", "click", "scroll"] = Field(description="Action type")
    x: int = Field(description="X coordinate")
    y: int = Field(description="Y coordinate")


class KeyboardAction(BaseModel):
    """Keyboard action (type, press)."""

    action: Literal["type", "press"] = Field(description="Action type")
    text: Optional[str] = Field(default=None, description="Text to type")
    keys: Optional[str] = Field(default=None, description="Keys to press")


class ActionResult(BaseModel):
    """Result of an action execution."""

    success: bool = Field(description="Whether action succeeded")
    method: Optional[str] = Field(default=None, description="Method used")
    details: Optional[dict] = Field(default=None, description="Additional details")
