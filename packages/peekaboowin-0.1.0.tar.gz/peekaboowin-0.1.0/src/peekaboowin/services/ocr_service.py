"""OCR service using PaddleOCR and screen capture."""

import time
from typing import Optional

import structlog

from peekaboowin.config import get_config
from peekaboowin.errors import ServiceError
from peekaboowin.models.elements import BoundingBox
from peekaboowin.models.ocr import OCRReadResult, OCRTextItem
from peekaboowin.platform.ocr_engine import get_ocr_engine
from peekaboowin.services.screen_service import get_screen_service

logger = structlog.get_logger(__name__)


class OCRService:
    """Business logic for OCR operations."""

    _instance: Optional["OCRService"] = None

    def __init__(self) -> None:
        self._config = get_config()
        self._screen_service = get_screen_service()
        self._ocr_engine = get_ocr_engine()

    @classmethod
    def get_instance(cls) -> "OCRService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def ocr_read(self, source: str = "screen", hwnd: Optional[int] = None, region: Optional[dict] = None, lang: Optional[str] = None) -> OCRReadResult:
        start_time = time.time()
        if not self._config.ocr_enabled:
            raise ServiceError(message="OCR is disabled", service_name="OCRService")
        lang = lang or self._config.ocr_language
        logger.info("ocr_read_start", source=source, hwnd=hwnd, region=region, lang=lang)
        try:
            image = None
            offset_x = 0
            offset_y = 0
            if source == "screen":
                result = self._screen_service.take_screenshot(monitor=0)
                image = self._decode_image(result["image"])
            elif source == "window":
                if hwnd is None:
                    raise ServiceError(message="hwnd is required for source='window'", service_name="OCRService")
                result = self._screen_service.capture_window(hwnd=hwnd)
                image = self._decode_image(result["image"])
            elif source == "region":
                if region is None:
                    raise ServiceError(message="region is required for source='region'", service_name="OCRService")
                # ocr_read tool 用 x/y，take_screenshot 用 left/top，需要映射
                screen_region = {
                    "left": region["x"],
                    "top": region["y"],
                    "width": region["width"],
                    "height": region["height"],
                }
                result = self._screen_service.take_screenshot(region=screen_region)
                image = self._decode_image(result["image"])
                offset_x = region["x"]
                offset_y = region["y"]
            else:
                raise ServiceError(message=f"Invalid source: {source}", service_name="OCRService")
            if image is None:
                raise ServiceError(message="Failed to capture image for OCR", service_name="OCRService")
            items = self._ocr_engine.recognize(image, lang=lang)
            mapped_items: list[OCRTextItem] = []
            for item in items:
                mapped_bbox = BoundingBox(left=item.bbox.left + offset_x, top=item.bbox.top + offset_y, right=item.bbox.right + offset_x, bottom=item.bbox.bottom + offset_y)
                mapped_items.append(OCRTextItem(text=item.text, bbox=mapped_bbox, confidence=item.confidence))
            elapsed_ms = (time.time() - start_time) * 1000
            logger.info("ocr_read_complete", source=source, item_count=len(mapped_items), elapsed_ms=elapsed_ms)
            return OCRReadResult(items=mapped_items, source=source, elapsed_ms=elapsed_ms)
        except ServiceError:
            raise
        except Exception as e:
            logger.error("ocr_read_failed", error=str(e))
            raise ServiceError(message=f"OCR read failed: {e}", service_name="OCRService")

    def _decode_image(self, image_base64: str):
        import base64, io
        from PIL import Image
        return Image.open(io.BytesIO(base64.b64decode(image_base64)))


def get_ocr_service() -> OCRService:
    return OCRService.get_instance()
