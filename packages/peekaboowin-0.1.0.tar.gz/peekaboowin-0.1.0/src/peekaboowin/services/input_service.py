"""Input simulation service using Win32 SendInput."""

import ctypes
import time
from typing import Optional

import structlog

from peekaboowin.errors import ElementNotFoundError, InvalidParamsError, PermissionBoundaryError, PlatformError, ServiceError
from peekaboowin.models.elements import ElementRef
from peekaboowin.platform.permissions import can_send_input_to, check_elevation
from peekaboowin.platform.win32_input import Win32Input, get_win32_input
from peekaboowin.services.uia_service import UIAService, get_uia_service

logger = structlog.get_logger(__name__)


class InputService:
    """Business logic for input simulation operations."""

    _instance: Optional["InputService"] = None

    def __init__(self) -> None:
        try:
            self._win32_input = get_win32_input()
            self._uia_service = get_uia_service()
            logger.info("input_service_initialized")
        except Exception as e:
            logger.error("input_service_init_failed", error=str(e))
            raise ServiceError(message=f"Failed to initialize input service: {e}", service_name="Input")

    @classmethod
    def get_instance(cls) -> "InputService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _verify_foreground(self, hwnd: int) -> bool:
        try:
            foreground_hwnd = ctypes.windll.user32.GetForegroundWindow()
            is_foreground = (foreground_hwnd == hwnd)
            if not is_foreground:
                logger.warning("window_not_foreground", target_hwnd=hwnd, foreground_hwnd=foreground_hwnd)
            return is_foreground
        except Exception as e:
            logger.warning("failed_to_check_foreground", hwnd=hwnd, error=str(e))
            return False

    def _get_hwnd_at_point(self, x: int, y: int) -> Optional[int]:
        """获取屏幕坐标处的窗口句柄。"""
        try:
            hwnd = ctypes.windll.user32.WindowFromPoint(x, y)
            return hwnd if hwnd else None
        except Exception as e:
            logger.debug("get_hwnd_at_point_failed", x=x, y=y, error=str(e))
            return None

    def _ensure_window_focused(self, hwnd: int) -> bool:
        """将目标窗口激活到前台。使用 AttachThreadInput 绕过 Windows 前台锁。"""
        try:
            if self._verify_foreground(hwnd):
                return True
            logger.info("ensuring_window_focused", hwnd=hwnd)
            target_tid = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, None)
            current_tid = ctypes.windll.kernel32.GetCurrentThreadId()
            attached = False
            if target_tid != current_tid:
                ctypes.windll.user32.AttachThreadInput(current_tid, target_tid, True)
                attached = True
            try:
                ctypes.windll.user32.ShowWindow(hwnd, 9)
                ctypes.windll.user32.SetForegroundWindow(hwnd)
            finally:
                if attached:
                    ctypes.windll.user32.AttachThreadInput(current_tid, target_tid, False)
            time.sleep(0.1)
            if self._verify_foreground(hwnd):
                return True
            logger.warning("ensure_focused_may_not_have_worked", hwnd=hwnd)
            return False
        except Exception as e:
            logger.warning("ensure_window_focused_failed", hwnd=hwnd, error=str(e))
            return False

    def _get_element_by_ref(self, element_ref: str) -> dict:
        try:
            ref = ElementRef(ref=element_ref)
        except ValueError as e:
            raise InvalidParamsError(message=str(e), tool_name="input_operation", param_name="element_ref", suggestions=["Use format 'hwnd:NNNN', 'point:X,Y', or 'desktop'"])
        element_info = self._uia_service.get_element_info(element_ref)
        if element_info is None:
            raise ElementNotFoundError(message=f"Element not found for reference: {element_ref}", element_description=element_ref)
        return element_info

    def _get_clickable_point(self, element_ref: str) -> tuple[int, int]:
        element_info = self._get_element_by_ref(element_ref)
        if element_info.get("bounding_box"):
            bbox = element_info["bounding_box"]
            if isinstance(bbox, tuple) and len(bbox) == 4:
                return ((bbox[0] + bbox[2]) // 2, (bbox[1] + bbox[3]) // 2)
        raise ElementNotFoundError(message=f"Cannot determine clickable point for: {element_ref}", element_description=element_ref)

    def click(self, x: int, y: int, button: str = "left", double: bool = False) -> dict:
        try:
            target_hwnd = self._get_hwnd_at_point(x, y)
            if target_hwnd:
                self._ensure_window_focused(target_hwnd)
            self._win32_input.click(x, y, button=button, double=double)
            return {"success": True, "x": x, "y": y, "button": button}
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Click operation failed: {e}", service_name="Input")

    def move_mouse(self, x: int, y: int) -> dict:
        try:
            target_hwnd = self._get_hwnd_at_point(x, y)
            if target_hwnd:
                self._ensure_window_focused(target_hwnd)
            self._win32_input.move_to(x, y)
            return {"success": True, "x": x, "y": y}
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Move mouse operation failed: {e}", service_name="Input")

    def drag(self, x1: int, y1: int, x2: int, y2: int, duration: float = 0.5) -> dict:
        try:
            target_hwnd = self._get_hwnd_at_point(x1, y1)
            if target_hwnd:
                self._ensure_window_focused(target_hwnd)
            self._win32_input.drag(x1, y1, x2, y2, duration=duration)
            return {"success": True, "x1": x1, "y1": y1, "x2": x2, "y2": y2}
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Drag operation failed: {e}", service_name="Input")

    def scroll(self, x: int, y: int, delta: int = -3) -> dict:
        try:
            target_hwnd = self._get_hwnd_at_point(x, y)
            if target_hwnd:
                self._ensure_window_focused(target_hwnd)
            self._win32_input.scroll(x, y, delta=delta)
            return {"success": True, "x": x, "y": y, "delta": delta}
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Scroll operation failed: {e}", service_name="Input")

    def type_text(self, text: str) -> dict:
        try:
            self._win32_input.type_text(text)
            return {"success": True, "text_length": len(text)}
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Type text operation failed: {e}", service_name="Input")

    def press_keys(self, keys: str) -> dict:
        try:
            self._win32_input.press_keys(keys)
            return {"success": True, "keys": keys}
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Press keys operation failed: {e}", service_name="Input")

    def click_element(self, element_ref: str) -> dict:
        try:
            element_info = self._get_element_by_ref(element_ref)
            hwnd = element_info.get("hwnd")
            if hwnd:
                self._ensure_window_focused(hwnd)
            if hwnd and not check_elevation():
                if not can_send_input_to(hwnd):
                    raise PermissionBoundaryError(message="Cannot send input to elevated window", tool_name="click_element", target_handle=hwnd)
            x, y = self._get_clickable_point(element_ref)
            self._win32_input.click(x, y, button="left", double=False)
            return {"success": True, "method": "clickable_point", "x": x, "y": y}
        except (PermissionBoundaryError, ElementNotFoundError, InvalidParamsError, PlatformError):
            raise
        except Exception as e:
            raise ServiceError(message=f"Click element operation failed: {e}", service_name="Input")

    def type_into_element(self, element_ref: str, text: str) -> dict:
        try:
            element_info = self._get_element_by_ref(element_ref)
            hwnd = element_info.get("hwnd")
            if hwnd:
                self._ensure_window_focused(hwnd)
            if hwnd and not check_elevation():
                if not can_send_input_to(hwnd):
                    raise PermissionBoundaryError(message="Cannot send input to elevated window", tool_name="type_into_element", target_handle=hwnd)
            x, y = self._get_clickable_point(element_ref)
            self._win32_input.click(x, y, button="left", double=False)
            self._win32_input.type_text(text)
            return {"success": True, "method": "type_text", "text_length": len(text)}
        except (PermissionBoundaryError, ElementNotFoundError, InvalidParamsError, PlatformError):
            raise
        except Exception as e:
            raise ServiceError(message=f"Type into element operation failed: {e}", service_name="Input")


def get_input_service() -> InputService:
    return InputService.get_instance()
