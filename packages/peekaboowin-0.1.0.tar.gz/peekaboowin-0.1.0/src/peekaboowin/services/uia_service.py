"""UI Automation service using UIA platform layer.

Provides singleton access to UIAutomation with business logic for
element finding, property extraction, and tree traversal.
Supports OCR fallback for sparse UIA trees (UWP applications).
"""

import time
from typing import Optional
from functools import lru_cache

import structlog

from peekaboowin.config import get_config
from peekaboowin.errors import ElementNotFoundError, InvalidParamsError, PlatformError, ServiceError, UIATimeoutError
from peekaboowin.models.elements import BoundingBox, ElementInfo, ElementRef
from peekaboowin.platform.uia import UIAutomation, TreeScope_Children, TreeScope_Descendants, get_uia

logger = structlog.get_logger(__name__)

_UIA_SPARSE_THRESHOLD = 2


class UIAService:
    """Business logic for UIA element operations."""

    _instance: Optional["UIAService"] = None

    def __init__(self) -> None:
        try:
            self._uia = get_uia()
            logger.info("uia_service_initialized")
        except Exception as e:
            logger.error("uia_service_init_failed", error=str(e))
            raise ServiceError(message=f"Failed to initialize UIA service: {e}", service_name="UIA")

    @classmethod
    def get_instance(cls) -> "UIAService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _scope_to_treescope(self, scope: str) -> int:
        mapping = {"self": TreeScope_Element, "children": TreeScope_Children, "descendants": TreeScope_Descendants}
        if scope not in mapping:
            raise InvalidParamsError(message=f"Invalid scope: {scope}", param_name="scope", suggestions=["Use 'descendants', 'children', or 'self'"])
        return mapping[scope]

    def _validate_search_criteria(self, name=None, class_name=None, automation_id=None):
        if not any([name, class_name, automation_id]):
            raise InvalidParamsError(message="At least one of name, class_name, or automation_id is required", tool_name="find_element", param_name="name/class_name/automation_id")

    def _props_to_element_info(self, props: dict) -> ElementInfo:
        bbox = None
        if props.get("bounding_rectangle"):
            br = props["bounding_rectangle"]
            bbox = BoundingBox(left=br["left"], top=br["top"], right=br["right"], bottom=br["bottom"])
        return ElementInfo(
            name=props.get("name"),
            class_name=props.get("class_name"),
            automation_id=props.get("automation_id"),
            control_type=props.get("control_type"),
            is_enabled=props.get("is_enabled", True),
            is_offscreen=props.get("is_offscreen", False),
            bounding_box=bbox,
            process_id=props.get("process_id"),
            hwnd=props.get("hwnd"),
        )

    def find_element(self, name=None, class_name=None, automation_id=None, scope="descendants"):
        self._validate_search_criteria(name, class_name, automation_id)
        try:
            scope_flag = self._scope_to_treescope(scope)
            element = self._uia.find_element(parent=None, name=name, class_name=class_name, automation_id=automation_id, scope=scope_flag)
            if element is None:
                logger.debug("element_not_found", name=name, class_name=class_name, automation_id=automation_id)
                return None
            props = self._uia.get_element_properties(element)
            return self._props_to_element_info(props).to_dict()
        except UIATimeoutError:
            raise
        except PlatformError:
            raise
        except Exception as e:
            logger.error("find_element_failed", error=str(e))
            raise ServiceError(message=f"Element search failed: {e}", service_name="UIA")

    def get_element_info(self, element_ref: str) -> dict:
        try:
            ref = ElementRef(ref=element_ref)
        except ValueError as e:
            raise InvalidParamsError(message=str(e), tool_name="get_element_info", param_name="element_ref")
        try:
            if ref.type == "desktop":
                root = self._uia.get_root_element()
                props = self._uia.get_element_properties(root)
            elif ref.type == "hwnd":
                element = self._uia.element_from_hwnd(ref.hwnd)
                if element is None:
                    raise ElementNotFoundError(message=f"Element not found for HWND: {ref.hwnd}", element_description=element_ref)
                props = self._uia.get_element_properties(element)
            elif ref.type == "point":
                element = self._uia.element_from_point(ref.point[0], ref.point[1])
                if element is None:
                    raise ElementNotFoundError(message=f"Element not found at point: {ref.point}", element_description=element_ref)
                props = self._uia.get_element_properties(element)
            else:
                raise InvalidParamsError(message=f"Invalid element reference: {element_ref}", tool_name="get_element_info", param_name="element_ref")
            return self._props_to_element_info(props).to_dict()
        except (ElementNotFoundError, PlatformError):
            raise
        except Exception as e:
            logger.error("get_element_info_failed", ref=element_ref, error=str(e))
            raise ServiceError(message=f"Failed to get element info: {e}", service_name="UIA", details={"ref": element_ref})

    def get_children(self, element_ref: str, depth: int = 1) -> dict:
        try:
            ref = ElementRef(ref=element_ref)
        except ValueError as e:
            raise InvalidParamsError(message=str(e), tool_name="get_children", param_name="element_ref")
        config = get_config()
        actual_depth = min(depth, config.uia_max_depth)
        try:
            if ref.type == "desktop":
                root = self._uia.get_root_element()
                children_data = self._uia.get_children(root, max_depth=actual_depth)
            elif ref.type == "hwnd":
                element = self._uia.element_from_hwnd(ref.hwnd)
                if element is None:
                    raise ElementNotFoundError(message=f"Element not found for HWND: {ref.hwnd}", element_description=element_ref)
                children_data = self._uia.get_children(element, max_depth=actual_depth)
            elif ref.type == "point":
                element = self._uia.element_from_point(ref.point[0], ref.point[1])
                if element is None:
                    raise ElementNotFoundError(message=f"Element not found at point: {ref.point}", element_description=element_ref)
                children_data = self._uia.get_children(element, max_depth=actual_depth)
            else:
                raise InvalidParamsError(message=f"Invalid element reference: {element_ref}", tool_name="get_children", param_name="element_ref")
            children = []
            for child_props in children_data:
                internal_children = child_props.pop("_children", None)
                element_info = self._props_to_element_info(child_props)
                child_dict = element_info.to_dict()
                if internal_children:
                    child_dict["_children"] = internal_children
                children.append(child_dict)
            logger.debug("get_children_success", ref=element_ref, count=len(children))
            return {"children": children}
        except (ElementNotFoundError, PlatformError):
            raise
        except Exception as e:
            logger.error("get_children_failed", ref=element_ref, error=str(e))
            raise ServiceError(message=f"Failed to get children: {e}", service_name="UIA")

    def get_desktop(self, depth: int = 1) -> dict:
        if depth < 1:
            depth = 1
        config = get_config()
        actual_depth = min(depth, config.uia_max_depth)
        try:
            root = self._uia.get_root_element()
            props = self._uia.get_element_properties(root)
            element_info = self._props_to_element_info(props)
            result = element_info.to_dict()
            result["_children"] = self._uia.get_children(root, max_depth=actual_depth)
            logger.debug("get_desktop_success", depth=depth)
            return result
        except PlatformError:
            raise
        except Exception as e:
            logger.error("get_desktop_failed", error=str(e))
            raise ServiceError(message=f"Failed to get desktop: {e}", service_name="UIA")

    def element_from_point(self, x: int, y: int) -> Optional[dict]:
        try:
            element = self._uia.element_from_point(x, y)
            if element is None:
                return None
            props = self._uia.get_element_properties(element)
            return self._props_to_element_info(props).to_dict()
        except PlatformError:
            raise
        except Exception as e:
            logger.error("element_from_point_failed", x=x, y=y, error=str(e))
            raise ServiceError(message=f"Failed to get element at point: {e}", service_name="UIA")

    def element_from_hwnd(self, hwnd: int) -> Optional[dict]:
        try:
            element = self._uia.element_from_hwnd(hwnd)
            if element is None:
                return None
            props = self._uia.get_element_properties(element)
            return self._props_to_element_info(props).to_dict()
        except PlatformError:
            raise
        except Exception as e:
            logger.error("element_from_hwnd_failed", hwnd=hwnd, error=str(e))
            raise ServiceError(message=f"Failed to get element from hwnd: {e}", service_name="UIA")

    def is_ocr_available(self) -> bool:
        config = get_config()
        return config.ocr_enabled

    def ocr_fallback_find(self, name=None, hwnd=None):
        if not self.is_ocr_available():
            logger.debug("ocr_fallback_skipped", reason="ocr_disabled")
            return None
        start_time = time.time()
        try:
            from peekaboowin.services.ocr_service import get_ocr_service
            ocr_service = get_ocr_service()
            ocr_result = ocr_service.ocr_read(source="window" if hwnd is not None else "screen", hwnd=hwnd)
            elapsed_ms = int((time.time() - start_time) * 1000)
            logger.info("ocr_fallback_completed", hwnd=hwnd, name=name, item_count=len(ocr_result.items), elapsed_ms=elapsed_ms)
            matched_items = ocr_result.items
            if name:
                name_lower = name.lower()
                matched_items = [item for item in ocr_result.items if name_lower in item.text.lower()]
            if not matched_items:
                return None
            elements = []
            for item in matched_items:
                bbox = item.bbox
                elements.append({
                    "name": item.text, "class_name": None, "automation_id": None,
                    "control_type": "Text", "is_enabled": True, "is_offscreen": False,
                    "bounding_box": (bbox.left, bbox.top, bbox.right, bbox.bottom),
                    "process_id": None, "hwnd": hwnd, "confidence": item.confidence, "source": "ocr_fallback",
                })
            if name and elements:
                return max(elements, key=lambda e: e.get("confidence", 0))
            return {"source": "ocr_fallback", "elapsed_ms": elapsed_ms, "elements": elements}
        except Exception as e:
            logger.warning("ocr_fallback_failed", error=str(e))
            return None

    def find_element_with_fallback(self, name=None, class_name=None, automation_id=None, scope="descendants"):
        result = self.find_element(name=name, class_name=class_name, automation_id=automation_id, scope=scope)
        if result is not None:
            return result
        if name and self.is_ocr_available():
            logger.info("uia_fallback_to_ocr", name=name)
            return self.ocr_fallback_find(name=name)
        return None

    def harvest_with_fallback(self, element_ref: str, depth: int = 1) -> dict:
        uia_result = self.get_children(element_ref, depth=depth)
        children = uia_result.get("children", [])
        is_sparse = len(children) <= _UIA_SPARSE_THRESHOLD
        if is_sparse and self.is_ocr_available():
            hwnd = None
            if element_ref.startswith("hwnd:"):
                try:
                    hwnd = int(element_ref.split(":")[1])
                except ValueError:
                    pass
            logger.info("harvest_fallback_to_ocr", element_ref=element_ref, uia_child_count=len(children))
            ocr_result = self.ocr_fallback_find(hwnd=hwnd)
            if ocr_result and "elements" in ocr_result:
                ocr_elements = ocr_result["elements"]
                existing_names = {c.get("name", "").lower() for c in children if c.get("name")}
                new_elements = [e for e in ocr_elements if e.get("name", "").lower() not in existing_names]
                children.extend(new_elements)
        return {"children": children}


def get_uia_service() -> UIAService:
    return UIAService.get_instance()
