"""PaddleOCR engine wrapper."""

import threading
import time
from typing import Optional

import numpy as np
import structlog
from PIL import Image

logger = structlog.get_logger(__name__)


class OCREngine:
    """PaddleOCR engine wrapper with lazy initialization."""

    _instance: Optional["OCREngine"] = None
    _lock: threading.Lock = threading.Lock()

    def __new__(cls) -> "OCREngine":
        with cls._lock:
            if cls._instance is None:
                cls._instance = super().__new__(cls)
                cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._engine = None
        self._engine_lock = threading.Lock()
        self._initialized = True

    @classmethod
    def get_instance(cls) -> "OCREngine":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @property
    def _paddle_engine(self):
        if self._engine is None:
            with self._engine_lock:
                if self._engine is None:
                    start = time.time()
                    from paddleocr import PaddleOCR
                    self._engine = PaddleOCR(use_angle_cls=True, lang="ch", show_log=False)
                    elapsed = time.time() - start
                    logger.info("paddleocr_initialized", elapsed_seconds=round(elapsed, 2))
        return self._engine

    def _pil_to_numpy(self, image: Image.Image) -> np.ndarray:
        if image.mode != "RGB":
            image = image.convert("RGB")
        return np.array(image)

    def recognize(self, image: Image.Image, lang: str = "ch") -> list:
        engine = self._paddle_engine
        img_array = self._pil_to_numpy(image)
        result = engine.ocr(img_array, cls=True)
        items = []
        if result and result[0]:
            for line in result[0]:
                bbox, (text, confidence) = line
                x_coords = [p[0] for p in bbox]
                y_coords = [p[1] for p in bbox]
                from peekaboowin.models.elements import BoundingBox
                from peekaboowin.models.ocr import OCRTextItem
                items.append(OCRTextItem(
                    text=text,
                    bbox=BoundingBox(
                        left=int(min(x_coords)),
                        top=int(min(y_coords)),
                        right=int(max(x_coords)),
                        bottom=int(max(y_coords)),
                    ),
                    confidence=confidence,
                ))
        return items


def get_ocr_engine() -> OCREngine:
    return OCREngine.get_instance()
