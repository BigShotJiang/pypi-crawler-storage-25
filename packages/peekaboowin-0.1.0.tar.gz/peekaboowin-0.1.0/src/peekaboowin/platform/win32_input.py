"""Windows input simulation using SendInput."""

import ctypes
from ctypes import wintypes
from typing import NamedTuple, Optional

import structlog

from peekaboowin.errors import PlatformError
from peekaboowin.config import get_config

logger = structlog.get_logger(__name__)

# Structures for SendInput
INPUT_MOUSE = 0
INPUT_KEYBOARD = 1
KEYEVENTF_KEYDOWN = 0x0000
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_SCANCODE = 0x0008
KEYEVENTF_UNICODE = 0x0004

MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000
MOUSEEVENTF_LEFTDOWN = 0x0002
MOUSEEVENTF_LEFTUP = 0x0004
MOUSEEVENTF_RIGHTDOWN = 0x0008
MOUSEEVENTF_RIGHTUP = 0x0010
MOUSEEVENTF_MIDDLEDOWN = 0x0020
MOUSEEVENTF_MIDDLEUP = 0x0040
MOUSEEVENTF_WHEEL = 0x0800

VK_SHIFT = 0x10
VK_CONTROL = 0x11
VK_MENU = 0x12

MODIFIER_MAP = {
    "ctrl": VK_CONTROL, "control": VK_CONTROL,
    "alt": VK_MENU,
    "shift": VK_SHIFT,
    "win": 0x5B, "lwin": 0x5B, "rwin": 0x5C,
}

KEY_NAME_TO_VK: dict[str, int] = {
    "enter": 0x0D, "return": 0x0D, "tab": 0x09, "space": 0x20,
    "backspace": 0x08, "back": 0x08, "delete": 0x2E, "del": 0x2E,
    "escape": 0x1B, "esc": 0x1B, "insert": 0x2D, "ins": 0x2D,
    "home": 0x24, "end": 0x23, "pageup": 0x21, "pagedown": 0x22,
    "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27,
    "capslock": 0x14, "numlock": 0x90, "scrolllock": 0x91,
    "printscreen": 0x2C, "prtsc": 0x2C, "pause": 0x13,
    "apps": 0x5D, "sleep": 0x5F,
    "equal": 0xBB, "minus": 0xBD, "plus": 0xBB,
    "lbracket": 0xDB, "rbracket": 0xDD,
    "backslash": 0xDC, "semicolon": 0xBA, "quote": 0xDE,
    "comma": 0xBC, "period": 0xBE, "slash": 0xBF, "backtick": 0xC0,
    "volumeup": 0xAF, "volumedown": 0xAE, "volumemute": 0xAD,
    "nexttrack": 0xB0, "prevtrack": 0xB1, "playpause": 0xB3, "stop": 0xB2,
    "browserback": 0xA6, "browserforward": 0xA7, "browserrefresh": 0xA8,
    "browsersearch": 0xAA, "browserfavorites": 0xAB, "browserhome": 0xAC,
    "launchmail": 0xB4, "launchcalculator": 0xB5,
}

for i in range(1, 25):
    KEY_NAME_TO_VK[f"f{i}"] = 0x6F + i

for i in range(10):
    KEY_NAME_TO_VK[f"num{i}"] = 0x60 + i
KEY_NAME_TO_VK["numlock"] = 0x90
KEY_NAME_TO_VK["num/"] = 0x6F
KEY_NAME_TO_VK["num*"] = 0x6A
KEY_NAME_TO_VK["num-"] = 0x6D
KEY_NAME_TO_VK["num+"] = 0x6B
KEY_NAME_TO_VK["num."] = 0x6E


class KeyInfo(NamedTuple):
    vk_code: int
    shift_state: int = 0


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wintypes.LONG), ("dy", wintypes.LONG), ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_void_p)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wintypes.WORD), ("wScan", wintypes.WORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_void_p)]


class INPUT(ctypes.Structure):
    class _INPUT(ctypes.Union):
        _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT)]
    _fields_ = [("type", wintypes.DWORD), ("union", _INPUT)]


_IS_X64 = ctypes.sizeof(ctypes.c_void_p) == 8
ULONG_PTR = ctypes.c_longlong if _IS_X64 else ctypes.c_long

assert ctypes.sizeof(INPUT) == (40 if _IS_X64 else 28), f"INPUT struct size mismatch: {ctypes.sizeof(INPUT)}"


class Win32Input:
    """Low-level input simulation using SendInput."""

    _instance: Optional["Win32Input"] = None

    def __new__(cls) -> "Win32Input":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        self._user32 = ctypes.windll.user32
        self._kernel32 = ctypes.windll.kernel32
        self._initialized = True

    def _send_input(self, n_inputs: int, inputs, cb_size: int) -> int:
        result = self._user32.SendInput(n_inputs, inputs, cb_size)
        if result == 0:
            error = self._kernel32.GetLastError()
            raise PlatformError(message="SendInput failed", win_error_code=error)
        return result

    def _key_name_to_vk(self, name: str) -> KeyInfo:
        name_lower = name.lower().strip()
        if name_lower in KEY_NAME_TO_VK:
            return KeyInfo(vk_code=KEY_NAME_TO_VK[name_lower])
        if name_lower.startswith("f") and name_lower[1:].isdigit():
            num = int(name_lower[1:])
            if 1 <= num <= 24:
                return KeyInfo(vk_code=0x6F + num)
        if len(name) == 1:
            vk = ctypes.windll.user32.VkKeyScanW(ord(name))
            if vk != -1:
                return KeyInfo(vk_code=vk & 0xFF, shift_state=(vk >> 8) & 0xFF)
        raise PlatformError(message=f"Unknown key name: {name}")

    @staticmethod
    def _shift_state_to_vks(shift_state: int) -> list[int]:
        vks = []
        if shift_state & 1:
            vks.append(VK_SHIFT)
        if shift_state & 2:
            vks.append(VK_CONTROL)
        if shift_state & 4:
            vks.append(VK_MENU)
        return vks

    def _press_key(self, vk_code: int, key_up: bool = False) -> None:
        inp = INPUT(type=INPUT_KEYBOARD)
        inp.union.ki = KEYBDINPUT(wVk=vk_code & 0xFFFF, wScan=0, dwFlags=KEYEVENTF_KEYUP if key_up else KEYEVENTF_KEYDOWN, time=0, dwExtraInfo=0)
        self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

    def press_keys(self, keys: str) -> dict:
        keys = keys.strip()
        if not keys:
            raise PlatformError(message="Keys cannot be empty")
        parts = [k.strip() for k in keys.split("+") if k.strip()]
        explicit_modifier_vks = []
        main_key = None
        for part in parts:
            lower = part.lower()
            if lower in MODIFIER_MAP:
                explicit_modifier_vks.append(MODIFIER_MAP[lower])
            else:
                main_key = part
        if main_key is None:
            raise PlatformError(message="No main key specified (only modifiers given)")
        key_info = self._key_name_to_vk(main_key)
        implicit_modifier_vks = self._shift_state_to_vks(key_info.shift_state)
        try:
            for vk in explicit_modifier_vks:
                self._press_key(vk, key_up=False)
            for vk in implicit_modifier_vks:
                if vk not in explicit_modifier_vks:
                    self._press_key(vk, key_up=False)
            self._press_key(key_info.vk_code, key_up=False)
            self._press_key(key_info.vk_code, key_up=True)
            for vk in reversed(implicit_modifier_vks):
                if vk not in explicit_modifier_vks:
                    self._press_key(vk, key_up=True)
            for vk in reversed(explicit_modifier_vks):
                self._press_key(vk, key_up=True)
        except Exception as e:
            for vk in set(explicit_modifier_vks + implicit_modifier_vks):
                try:
                    self._press_key(vk, key_up=True)
                except Exception:
                    pass
            raise
        return {"success": True, "keys": keys}

    def type_text(self, text: str) -> dict:
        config = get_config()
        for char in text:
            inp = INPUT(type=INPUT_KEYBOARD)
            inp.union.ki = KEYBDINPUT(wVk=0, wScan=ord(char), dwFlags=KEYEVENTF_UNICODE, time=0, dwExtraInfo=0)
            self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
            inp.union.ki.dwFlags = KEYEVENTF_KEYUP | KEYEVENTF_UNICODE
            self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
            if config.input_type_delay > 0:
                import time
                time.sleep(config.input_type_delay)
        return {"success": True, "text_length": len(text)}

    def click(self, x: int, y: int, button: str = "left", double: bool = False) -> dict:
        config = get_config()
        screen_w = self._user32.GetSystemMetrics(0)
        screen_h = self._user32.GetSystemMetrics(1)
        norm_x = max(0, min(65535, int((x / max(screen_w, 1)) * 65535)))
        norm_y = max(0, min(65535, int((y / max(screen_h, 1)) * 65535)))
        inp = INPUT(type=INPUT_MOUSE)
        inp.union.mi = MOUSEINPUT(dx=norm_x, dy=norm_y, mouseData=0, dwFlags=MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, time=0, dwExtraInfo=0)
        self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        btn_down = {"left": MOUSEEVENTF_LEFTDOWN, "right": MOUSEEVENTF_RIGHTDOWN, "middle": MOUSEEVENTF_MIDDLEDOWN}
        btn_up = {"left": MOUSEEVENTF_LEFTUP, "right": MOUSEEVENTF_RIGHTUP, "middle": MOUSEEVENTF_MIDDLEUP}
        for _ in range(2 if double else 1):
            inp.union.mi = MOUSEINPUT(dx=0, dy=0, mouseData=0, dwFlags=btn_down[button], time=0, dwExtraInfo=0)
            self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
            inp.union.mi = MOUSEINPUT(dx=0, dy=0, mouseData=0, dwFlags=btn_up[button], time=0, dwExtraInfo=0)
            self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        if config.input_click_delay > 0:
            import time
            time.sleep(config.input_click_delay)
        return {"success": True, "x": x, "y": y, "button": button}

    def move_to(self, x: int, y: int) -> dict:
        screen_w = self._user32.GetSystemMetrics(0)
        screen_h = self._user32.GetSystemMetrics(1)
        norm_x = max(0, min(65535, int((x / max(screen_w, 1)) * 65535)))
        norm_y = max(0, min(65535, int((y / max(screen_h, 1)) * 65535)))
        inp = INPUT(type=INPUT_MOUSE)
        inp.union.mi = MOUSEINPUT(dx=norm_x, dy=norm_y, mouseData=0, dwFlags=MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, time=0, dwExtraInfo=0)
        self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        return {"success": True, "x": x, "y": y}

    def drag(self, x1: int, y1: int, x2: int, y2: int, duration: float = 0.5) -> dict:
        self.move_to(x1, y1)
        btn_down = MOUSEEVENTF_LEFTDOWN
        btn_up = MOUSEEVENTF_LEFTUP
        inp = INPUT(type=INPUT_MOUSE)
        inp.union.mi = MOUSEINPUT(dx=0, dy=0, mouseData=0, dwFlags=btn_down, time=0, dwExtraInfo=0)
        self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        import time
        steps = max(5, int(duration * 60))
        for i in range(1, steps + 1):
            t = i / steps
            cx = int(x1 + (x2 - x1) * t)
            cy = int(y1 + (y2 - y1) * t)
            screen_w = self._user32.GetSystemMetrics(0)
            screen_h = self._user32.GetSystemMetrics(1)
            norm_x = max(0, min(65535, int((cx / max(screen_w, 1)) * 65535)))
            norm_y = max(0, min(65535, int((cy / max(screen_h, 1)) * 65535)))
            inp.union.mi = MOUSEINPUT(dx=norm_x, dy=norm_y, mouseData=0, dwFlags=MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, time=0, dwExtraInfo=0)
            self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
            time.sleep(duration / steps)
        inp.union.mi = MOUSEINPUT(dx=0, dy=0, mouseData=0, dwFlags=btn_up, time=0, dwExtraInfo=0)
        self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        return {"success": True, "x1": x1, "y1": y1, "x2": x2, "y2": y2}

    def scroll(self, x: int, y: int, delta: int = -3) -> dict:
        screen_w = self._user32.GetSystemMetrics(0)
        screen_h = self._user32.GetSystemMetrics(1)
        norm_x = max(0, min(65535, int((x / max(screen_w, 1)) * 65535)))
        norm_y = max(0, min(65535, int((y / max(screen_h, 1)) * 65535)))
        inp = INPUT(type=INPUT_MOUSE)
        inp.union.mi = MOUSEINPUT(dx=norm_x, dy=norm_y, mouseData=0, dwFlags=MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE, time=0, dwExtraInfo=0)
        self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        inp.union.mi = MOUSEINPUT(dx=0, dy=0, mouseData=delta * 120, dwFlags=MOUSEEVENTF_WHEEL, time=0, dwExtraInfo=0)
        self._send_input(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        return {"success": True, "x": x, "y": y, "delta": delta}


_win32_input: Optional[Win32Input] = None


def get_win32_input() -> Win32Input:
    global _win32_input
    if _win32_input is None:
        _win32_input = Win32Input()
    return _win32_input
