"""Windows UI Automation client using comtypes."""

import ctypes
import sys
from typing import Optional

import comtypes
from comtypes import GUID
from comtypes.client import CreateObject

import structlog

from peekaboowin.config import get_config
from peekaboowin.errors import PlatformError, UIATimeoutError
from peekaboowin.platform.permissions import get_dpi_aware

logger = structlog.get_logger(__name__)


def _ensure_comtypes_gen() -> None:
    try:
        from comtypes.gen.UIAutomationClient import IUIAutomation
    except (ImportError, ModuleNotFoundError):
        try:
            import comtypes.client
            comtypes.client.GetModule("UIAutomationCore.dll")
            logger.info("comtypes_gen_regenerated")
        except Exception as e:
            logger.warning("comtypes_gen_regeneration_failed", error=str(e))


_ensure_comtypes_gen()

CLSID_UIAutomation = GUID("{ff48dba4-60ef-4201-aa87-54103eef594e}")
TreeScope_Element = 1
TreeScope_Children = 2
TreeScope_Descendants = 4

CONTROL_TYPE_NAMES = {
    50000: "Button", 50001: "Calendar", 50002: "CheckBox", 50003: "ComboBox",
    50004: "Edit", 50005: "Hyperlink", 50006: "Image", 50007: "ListItem",
    50008: "List", 50009: "Menu", 50010: "MenuBar", 50011: "MenuItem",
    50012: "ProgressBar", 50013: "RadioButton", 50014: "ScrollBar",
    50015: "Slider", 50016: "Spinner", 50017: "StatusBar", 50018: "Tab",
    50019: "TabItem", 50020: "Text", 50021: "ToolBar", 50022: "ToolTip",
    50023: "Tree", 50024: "TreeItem", 50025: "Custom", 50026: "Group",
    50027: "Thumb", 50028: "DataGrid", 50029: "DataItem", 50030: "Document",
    50031: "SplitButton", 50032: "Window", 50033: "Pane", 50034: "Header",
    50035: "HeaderItem", 50036: "Table", 50037: "TitleBar", 50038: "Separator",
    50039: "SemanticZoom", 50040: "AppBar",
}

UIA_NamePropertyId = 30005
UIA_ClassNamePropertyId = 30003
UIA_AutomationIdPropertyId = 30011
UIA_ControlTypePropertyId = 30008
UIA_IsEnabledPropertyId = 30009
UIA_IsOffscreenPropertyId = 30022
UIA_BoundingRectanglePropertyId = 30001
UIA_ProcessIdPropertyId = 30028
UIA_NativeWindowHandlePropertyId = 30020


class UIAutomation:
    """Low-level UIAutomation wrapper using comtypes."""

    _instance: Optional["UIAutomation"] = None
    _uia: Optional[comtypes.IUnknown] = None

    def __new__(cls) -> "UIAutomation":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        try:
            _ensure_comtypes_gen()
            ctypes.windll.ole32.CoInitialize(None)
            self._uia = CreateObject(CLSID_UIAutomation)
            self._initialized = True
            logger.info("uia_initialized")
        except Exception as e:
            logger.error("uia_init_failed", error=str(e))
            raise PlatformError(message="Failed to initialize UIAutomation", win_error_code=getattr(e, 'hresult', None))

    @property
    def uia(self) -> comtypes.IUnknown:
        if self._uia is None:
            raise PlatformError(message="UIA not initialized")
        return self._uia

    def get_root_element(self) -> comtypes.IUnknown:
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomation
            uia_iface = self._uia.QueryInterface(IUIAutomation)
            return uia_iface.GetRootElement()
        except Exception as e:
            logger.error("get_root_element_failed", error=str(e))
            raise PlatformError(message="Failed to get root element", win_error_code=getattr(e, 'hresult', None))

    def _create_condition(self, name=None, class_name=None, automation_id=None):
        from comtypes.gen.UIAutomationClient import IUIAutomation, IUIAutomationPropertyCondition, IUIAutomationAndCondition
        uia_iface = self._uia.QueryInterface(IUIAutomation)
        conditions = []
        if name:
            conditions.append(uia_iface.CreatePropertyCondition(UIA_NamePropertyId, name))
        if class_name:
            conditions.append(uia_iface.CreatePropertyCondition(UIA_ClassNamePropertyId, class_name))
        if automation_id:
            conditions.append(uia_iface.CreatePropertyCondition(UIA_AutomationIdPropertyId, automation_id))
        if not conditions:
            return uia_iface.CreateTrueCondition()
        if len(conditions) == 1:
            return conditions[0]
        and_cond = uia_iface.CreateAndCondition(conditions[0], conditions[1])
        for i in range(2, len(conditions)):
            and_cond = uia_iface.CreateAndCondition(and_cond, conditions[i])
        return and_cond

    def _get_element_properties(self, element: comtypes.IUnknown) -> dict:
        from comtypes.gen.UIAutomationClient import IUIAutomationElement
        try:
            elem = element.QueryInterface(IUIAutomationElement)
        except Exception:
            return {}
        config = get_config()
        is_dpi_aware = get_dpi_aware()
        props = {}
        try:
            props["name"] = elem.CurrentName
        except Exception:
            props["name"] = None
        try:
            props["class_name"] = elem.CurrentClassName
        except Exception:
            props["class_name"] = None
        try:
            props["automation_id"] = elem.CurrentAutomationId
        except Exception:
            props["automation_id"] = None
        try:
            control_type_id = elem.CurrentControlType
            props["control_type"] = CONTROL_TYPE_NAMES.get(control_type_id, f"Unknown({control_type_id})")
        except Exception:
            props["control_type"] = None
        try:
            props["is_enabled"] = bool(elem.CurrentIsEnabled)
        except Exception:
            props["is_enabled"] = True
        try:
            props["is_offscreen"] = bool(elem.CurrentIsOffscreen)
        except Exception:
            props["is_offscreen"] = False
        try:
            rect = elem.CurrentBoundingRectangle
            left, top, right, bottom = rect
            if not is_dpi_aware:
                scale_factor = ctypes.windll.user32.GetDpiForSystem() / 96.0
                if scale_factor != 1.0:
                    left = int(left / scale_factor)
                    top = int(top / scale_factor)
                    right = int(right / scale_factor)
                    bottom = int(bottom / scale_factor)
            props["bounding_rectangle"] = {
                "left": left, "top": top, "right": right, "bottom": bottom,
                "width": right - left, "height": bottom - top,
            }
        except Exception:
            props["bounding_rectangle"] = None
        try:
            props["process_id"] = elem.CurrentProcessId
        except Exception:
            props["process_id"] = None
        try:
            hwnd = elem.CurrentNativeWindowHandle
            props["hwnd"] = hwnd if hwnd else None
        except Exception:
            props["hwnd"] = None
        return props

    def find_element_by_name(self, parent: Optional[comtypes.IUnknown], name: str, scope: int = TreeScope_Descendants) -> Optional[comtypes.IUnknown]:
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomationElement
            elem = parent.QueryInterface(IUIAutomationElement) if parent else self.get_root_element()
            condition = self._create_condition(name=name)
            found = elem.FindFirst(scope, condition)
            return found if found else None
        except Exception as e:
            logger.debug("find_element_by_name_failed", name=name, error=str(e))
            return None

    def find_element_by_class(self, parent: Optional[comtypes.IUnknown], class_name: str, scope: int = TreeScope_Descendants) -> Optional[comtypes.IUnknown]:
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomationElement
            elem = parent.QueryInterface(IUIAutomationElement) if parent else self.get_root_element()
            condition = self._create_condition(class_name=class_name)
            found = elem.FindFirst(scope, condition)
            return found if found else None
        except Exception as e:
            logger.debug("find_element_by_class_failed", class_name=class_name, error=str(e))
            return None

    def find_element_by_id(self, parent: Optional[comtypes.IUnknown], automation_id: str, scope: int = TreeScope_Descendants) -> Optional[comtypes.IUnknown]:
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomationElement
            elem = parent.QueryInterface(IUIAutomationElement) if parent else self.get_root_element()
            condition = self._create_condition(automation_id=automation_id)
            found = elem.FindFirst(scope, condition)
            return found if found else None
        except Exception as e:
            logger.debug("find_element_by_id_failed", automation_id=automation_id, error=str(e))
            return None

    def find_element(self, parent: Optional[comtypes.IUnknown], name: Optional[str] = None, class_name: Optional[str] = None, automation_id: Optional[str] = None, scope: int = TreeScope_Descendants) -> Optional[comtypes.IUnknown]:
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomationElement
            elem = parent.QueryInterface(IUIAutomationElement) if parent else self.get_root_element()
            condition = self._create_condition(name=name, class_name=class_name, automation_id=automation_id)
            found = elem.FindFirst(scope, condition)
            return found if found else None
        except Exception as e:
            logger.debug("find_element_failed", error=str(e))
            return None

    def get_children(self, element: comtypes.IUnknown, max_depth: int = 1) -> list[dict]:
        from comtypes.gen.UIAutomationClient import IUIAutomationElement
        try:
            elem = element.QueryInterface(IUIAutomationElement)
        except Exception:
            return []
        children = []
        config = get_config()
        actual_depth = min(max_depth, config.uia_max_depth)
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomation
            uia_iface = self._uia.QueryInterface(IUIAutomation)
            found_children = elem.FindAll(TreeScope_Children, uia_iface.CreateTrueCondition())
            if found_children:
                for i in range(found_children.Length):
                    child = found_children.GetElement(i)
                    if child:
                        child_props = self._get_element_properties(child)
                        child_props["_children"] = []
                        if actual_depth > 1:
                            child_props["_children"] = self.get_children(child, actual_depth - 1)
                        children.append(child_props)
        except Exception as e:
            logger.debug("get_children_failed", error=str(e))
        return children

    def get_element_properties(self, element: comtypes.IUnknown) -> dict:
        return self._get_element_properties(element)

    def element_from_point(self, x: int, y: int) -> Optional[comtypes.IUnknown]:
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomation
            uia_iface = self._uia.QueryInterface(IUIAutomation)
            return uia_iface.ElementFromPoint(x, y)
        except Exception as e:
            logger.debug("element_from_point_failed", x=x, y=y, error=str(e))
            return None

    def element_from_hwnd(self, hwnd: int) -> Optional[comtypes.IUnknown]:
        try:
            from comtypes.gen.UIAutomationClient import IUIAutomation
            uia_iface = self._uia.QueryInterface(IUIAutomation)
            return uia_iface.ElementFromHandle(hwnd)
        except Exception as e:
            logger.debug("element_from_hwnd_failed", hwnd=hwnd, error=str(e))
            return None


_uia_instance: Optional[UIAutomation] = None


def get_uia() -> UIAutomation:
    global _uia_instance
    if _uia_instance is None:
        _uia_instance = UIAutomation()
    return _uia_instance
