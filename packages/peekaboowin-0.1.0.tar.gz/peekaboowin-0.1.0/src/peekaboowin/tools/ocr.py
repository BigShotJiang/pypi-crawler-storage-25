"""OCR tools."""

from typing import Optional

import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.server import mcp
from peekaboowin.services.ocr_service import get_ocr_service
from peekaboowin.tools._common import tool_error_handler

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("ocr_read")
def ocr_read(source: str = "screen", hwnd: Optional[int] = None, region: Optional[dict] = None, lang: str = "ch") -> dict:
    if source not in ("screen", "window", "region"):
        raise InvalidParamsError(message="source must be 'screen', 'window', or 'region'", tool_name="ocr_read", param_name="source")
    if source == "window" and (hwnd is None or not isinstance(hwnd, int) or hwnd <= 0):
        raise InvalidParamsError(message="valid hwnd required for source='window'", tool_name="ocr_read", param_name="hwnd")
    if source == "region":
        if region is None or not isinstance(region, dict):
            raise InvalidParamsError(message="region dict required for source='region'", tool_name="ocr_read", param_name="region")
        required_keys = {"x", "y", "width", "height"}
        if not required_keys.issubset(region.keys()):
            raise InvalidParamsError(message="region must have x, y, width, height keys", tool_name="ocr_read", param_name="region")
        for key in required_keys:
            if not isinstance(region.get(key), (int, float)) or region[key] < 0:
                raise InvalidParamsError(message=f"region.{key} must be non-negative", tool_name="ocr_read", param_name=f"region.{key}")
    if lang not in ("ch", "en"):
        raise InvalidParamsError(message="lang must be 'ch' or 'en'", tool_name="ocr_read", param_name="lang")
    service = get_ocr_service()
    result = service.ocr_read(source=source, hwnd=hwnd, region=region, lang=lang)
    return {
        "items": [{"text": item.text, "bbox": {"x": item.bbox.x, "y": item.bbox.y, "width": item.bbox.width, "height": item.bbox.height}, "confidence": item.confidence} for item in result.items],
        "source": result.source, "elapsed_ms": result.elapsed_ms,
    }
