"""Harvest/Discovery tool for comprehensive UI tree traversal."""

import time
from typing import Optional

import structlog

from peekaboowin.config import get_config
from peekaboowin.errors import InvalidParamsError, ServiceError
from peekaboowin.services.uia_service import get_uia_service, _UIA_SPARSE_THRESHOLD
from peekaboowin.services.window_service import get_window_service
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.server import mcp

logger = structlog.get_logger(__name__)


def _count_tree_elements(element: dict, max_count: int = 10) -> int:
    count = 1
    if count >= max_count:
        return count
    for child in element.get("_children", []):
        count += _count_tree_elements(child, max_count - count)
        if count >= max_count:
            return count
    return count


def _supplement_with_ocr(element: dict, hwnd: int, uia_service) -> None:
    total_elements = _count_tree_elements(element, max_count=_UIA_SPARSE_THRESHOLD + 1)
    if total_elements > _UIA_SPARSE_THRESHOLD:
        return
    if not uia_service.is_ocr_available():
        return
    logger.info("harvest_ocr_supplement", hwnd=hwnd, uia_element_count=total_elements)
    ocr_result = uia_service.ocr_fallback_find(hwnd=hwnd)
    if ocr_result is None or "elements" not in ocr_result:
        return
    ocr_elements = ocr_result["elements"]
    if not ocr_elements:
        return
    if "_children" not in element:
        element["_children"] = []
    existing_names = {c.get("name", "").lower() for c in element["_children"] if c.get("name")}
    added = 0
    for ocr_elem in ocr_elements:
        name = ocr_elem.get("name", "").lower()
        if name and name not in existing_names:
            element["_children"].append(ocr_elem)
            existing_names.add(name)
            added += 1
    logger.info("harvest_ocr_supplement_added", hwnd=hwnd, added=added)


def _build_element_tree(element: dict, uia_service, current_depth: int, max_depth: int) -> dict:
    if current_depth >= max_depth:
        return element
    try:
        hwnd = element.get("hwnd")
        if hwnd is None:
            return element
        remaining_depth = max_depth - current_depth - 1
        if remaining_depth < 1:
            remaining_depth = 1
        children_result = uia_service.get_children(element_ref=f"hwnd:{hwnd}", depth=remaining_depth)
        children = children_result.get("children", [])
        if children:
            tree_children = []
            for child in children:
                child_tree = _build_element_tree(child, uia_service, current_depth + 1, max_depth)
                tree_children.append(child_tree)
            element["_children"] = tree_children
    except Exception as e:
        logger.debug("build_element_tree_error", hwnd=element.get("hwnd"), error=str(e))
    return element


@mcp.tool()
@tool_error_handler("harvest_ui")
def harvest_ui(target: str = "desktop", depth: int = 3) -> dict:
    logger.info("tool_harvest_ui_called", target=target, depth=depth)
    config = get_config()
    if depth < 1:
        depth = 1
    actual_depth = min(depth, config.uia_max_depth)
    if not target or not target.strip():
        raise InvalidParamsError(message="target cannot be empty", tool_name="harvest_ui", param_name="target")
    target = target.strip()
    uia_service = get_uia_service()
    window_service = get_window_service()
    result = {"target": target, "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"), "elements": []}

    if target.lower() == "desktop":
        windows_result = window_service.list_windows()
        windows = windows_result.get("windows", [])
        desktop_elements = []
        for window in windows:
            try:
                hwnd = window.get("hwnd")
                if hwnd is None:
                    continue
                element = uia_service.element_from_hwnd(hwnd)
                if element is None:
                    element = {"name": window.get("title"), "class_name": window.get("class_name"), "control_type": "Window", "is_enabled": True, "is_offscreen": False, "bounding_box": None, "process_id": window.get("process_id"), "hwnd": hwnd}
                element = _build_element_tree(element, uia_service, 0, actual_depth)
                _supplement_with_ocr(element, hwnd, uia_service)
                desktop_elements.append(element)
            except Exception as e:
                logger.debug("harvest_desktop_window_error", hwnd=window.get("hwnd"), error=str(e))
        result["elements"] = desktop_elements

    elif target.lower() == "foreground":
        fg_window = window_service.get_foreground_window()
        fg_hwnd = fg_window.get("hwnd", 0)
        if fg_hwnd == 0:
            return {"target": target, "timestamp": result["timestamp"], "elements": [], "message": "No foreground window"}
        try:
            element = uia_service.element_from_hwnd(fg_hwnd)
            if element is None:
                element = {"name": fg_window.get("title"), "class_name": fg_window.get("class_name"), "control_type": "Window", "is_enabled": True, "is_offscreen": False, "bounding_box": fg_window.get("bounds"), "process_id": fg_window.get("process_id"), "hwnd": fg_hwnd}
            element = _build_element_tree(element, uia_service, 0, actual_depth)
            _supplement_with_ocr(element, fg_hwnd, uia_service)
            result["elements"] = [element]
        except Exception as e:
            raise ServiceError(message=f"Failed to harvest foreground: {e}", service_name="UIA")

    else:
        try:
            hwnd = int(target)
        except ValueError:
            raise InvalidParamsError(message=f"Invalid hwnd: {target}", tool_name="harvest_ui", param_name="target")
        if not window_service.is_valid_window(hwnd):
            return {"target": target, "timestamp": result["timestamp"], "elements": [], "message": f"Window {hwnd} not found"}
        try:
            element = uia_service.element_from_hwnd(hwnd)
            if element is None:
                element = {"name": None, "class_name": None, "control_type": "Window", "is_enabled": True, "is_offscreen": False, "bounding_box": None, "process_id": None, "hwnd": hwnd}
            element = _build_element_tree(element, uia_service, 0, actual_depth)
            _supplement_with_ocr(element, hwnd, uia_service)
            result["elements"] = [element]
        except Exception as e:
            raise ServiceError(message=f"Failed to harvest window {hwnd}: {e}", service_name="UIA")

    return result
