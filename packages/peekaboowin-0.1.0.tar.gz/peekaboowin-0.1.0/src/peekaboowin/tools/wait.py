"""Wait/Polling tools."""

from typing import Optional

import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.services.wait_service import get_wait_service
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.server import mcp

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("wait_for_element")
def wait_for_element(name: Optional[str] = None, automation_id: Optional[str] = None, class_name: Optional[str] = None, control_type: Optional[str] = None, timeout: float = 10.0, interval: float = 0.5, visible: bool = True) -> dict:
    if not any([name, automation_id, class_name, control_type]):
        raise InvalidParamsError(message="At least one search criterion required", tool_name="wait_for_element", param_name="name/automation_id/class_name/control_type")
    if timeout <= 0:
        raise InvalidParamsError(message="timeout must be positive", tool_name="wait_for_element", param_name="timeout")
    if interval <= 0:
        raise InvalidParamsError(message="interval must be positive", tool_name="wait_for_element", param_name="interval")
    service = get_wait_service()
    return service.wait_for_element(name=name, automation_id=automation_id, class_name=class_name, control_type=control_type, timeout=timeout, interval=interval, visible=visible).model_dump()


@mcp.tool()
@tool_error_handler("wait_for_window")
def wait_for_window(title: Optional[str] = None, class_name: Optional[str] = None, timeout: float = 10.0, interval: float = 0.5, appear: bool = True) -> dict:
    if not any([title, class_name]):
        raise InvalidParamsError(message="At least one of title or class_name required", tool_name="wait_for_window", param_name="title/class_name")
    if timeout <= 0:
        raise InvalidParamsError(message="timeout must be positive", tool_name="wait_for_window", param_name="timeout")
    if interval <= 0:
        raise InvalidParamsError(message="interval must be positive", tool_name="wait_for_window", param_name="interval")
    service = get_wait_service()
    return service.wait_for_window(title=title, class_name=class_name, timeout=timeout, interval=interval, appear=appear).model_dump()
