"""Screen capture tools."""

import sys
from typing import Optional

import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.server import mcp
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.config import get_config
from peekaboowin.platform.permissions import check_elevation, get_dpi_aware
from peekaboowin.platform.capture import ScreenCapture
from peekaboowin.services.screen_service import get_screen_service

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("screenshot")
def screenshot(monitor: Optional[int] = None, region: Optional[dict] = None, image_format: Optional[str] = None, quality: Optional[int] = None) -> dict:
    logger.info("tool_called", tool="screenshot", monitor=monitor, region=region, format=image_format)
    if region is not None:
        if not isinstance(region, dict):
            raise InvalidParamsError(message="region must be a dictionary", tool_name="screenshot", param_name="region")
        required_keys = {"left", "top", "width", "height"}
        if not required_keys.issubset(region.keys()):
            raise InvalidParamsError(message="region must have left, top, width, height keys", tool_name="screenshot", param_name="region", details={"required": list(required_keys)})
        for key in required_keys:
            if not isinstance(region[key], (int, float)) or (key in ("width", "height") and region[key] <= 0):
                raise InvalidParamsError(message=f"region.{key} must be a positive number", tool_name="screenshot", param_name=f"region.{key}")
    if image_format is not None and image_format.lower() not in ("png", "jpeg"):
        raise InvalidParamsError(message="image_format must be 'png' or 'jpeg'", tool_name="screenshot", param_name="image_format")
    if quality is not None and (not isinstance(quality, int) or quality < 1 or quality > 100):
        raise InvalidParamsError(message="quality must be an integer between 1 and 100", tool_name="screenshot", param_name="quality")
    service = get_screen_service()
    result = service.take_screenshot(monitor=monitor, region=region, format=image_format, quality=quality)
    return result


@mcp.tool()
@tool_error_handler("list_monitors")
def list_monitors() -> dict:
    service = get_screen_service()
    monitors = service.get_monitors()
    return {"monitors": monitors}


@mcp.tool()
@tool_error_handler("capture_window")
def capture_window(hwnd: int, image_format: Optional[str] = None, quality: Optional[int] = None) -> dict:
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="capture_window", param_name="hwnd")
    if image_format is not None and image_format.lower() not in ("png", "jpeg"):
        raise InvalidParamsError(message="image_format must be 'png' or 'jpeg'", tool_name="capture_window", param_name="image_format")
    if quality is not None and (not isinstance(quality, int) or quality < 1 or quality > 100):
        raise InvalidParamsError(message="quality must be an integer between 1 and 100", tool_name="capture_window", param_name="quality")
    service = get_screen_service()
    return service.capture_window(hwnd=hwnd, format=image_format, quality=quality)


@mcp.tool()
@tool_error_handler("health_check")
def health_check() -> dict:
    config = get_config()
    dpi_aware = get_dpi_aware()
    elevation = "admin" if check_elevation() else "user"
    ocr_available = False
    ocr_status = "disabled"
    try:
        if config.ocr_enabled:
            try:
                from peekaboowin.services.ocr_service import get_ocr_service
                ocr_service = get_ocr_service()
                capture = ScreenCapture()
                test_img = capture.capture_region(left=0, top=0, width=1, height=1, monitor_index=0)
                ocr_service._ocr_engine.recognize(test_img, lang="ch")
                ocr_available = True
                ocr_status = "available"
            except Exception as e:
                ocr_status = f"broken: {type(e).__name__}"
        else:
            ocr_status = "disabled"
    except ImportError:
        ocr_available = False
        ocr_status = "not_installed"
    try:
        screen_service = get_screen_service()
        monitors = screen_service.get_monitors()
    except Exception:
        monitors = []
    return {
        "status": "ok", "version": "0.1.0",
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "platform": "Windows", "dpi_aware": dpi_aware, "elevation": elevation,
        "ocr_available": ocr_available, "ocr_status": ocr_status, "monitors": monitors,
        "config": {"ocr_enabled": config.ocr_enabled, "log_level": config.log_level,
                   "screenshot_format": config.screenshot_format, "screenshot_quality": config.screenshot_quality,
                   "screenshot_max_width": config.screenshot_max_width},
    }
