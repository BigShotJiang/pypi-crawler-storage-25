"""Input simulation tools."""

import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.services.input_service import get_input_service
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.server import mcp

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("click")
def click(x: int, y: int, button: str = "left", double: bool = False) -> dict:
    if button not in ("left", "right", "middle"):
        raise InvalidParamsError(message=f"Invalid button: {button}", tool_name="click", param_name="button")
    service = get_input_service()
    return service.click(x=x, y=y, button=button, double=double)


@mcp.tool()
@tool_error_handler("move_mouse")
def move_mouse(x: int, y: int) -> dict:
    service = get_input_service()
    return service.move_mouse(x=x, y=y)


@mcp.tool()
@tool_error_handler("drag")
def drag(x1: int, y1: int, x2: int, y2: int, duration: float = 0.5) -> dict:
    if duration <= 0:
        raise InvalidParamsError(message="duration must be positive", tool_name="drag", param_name="duration")
    service = get_input_service()
    return service.drag(x1=x1, y1=y1, x2=x2, y2=y2, duration=duration)


@mcp.tool()
@tool_error_handler("scroll")
def scroll(x: int, y: int, delta: int = -3) -> dict:
    service = get_input_service()
    return service.scroll(x=x, y=y, delta=delta)


@mcp.tool()
@tool_error_handler("type_text")
def type_text(text: str) -> dict:
    if not text:
        raise InvalidParamsError(message="Text cannot be empty", tool_name="type_text", param_name="text")
    service = get_input_service()
    return service.type_text(text=text)


@mcp.tool()
@tool_error_handler("press_keys")
def press_keys(keys: str) -> dict:
    if not keys or not keys.strip():
        raise InvalidParamsError(message="Keys cannot be empty", tool_name="press_keys", param_name="keys")
    service = get_input_service()
    return service.press_keys(keys=keys)


@mcp.tool()
@tool_error_handler("click_element")
def click_element(element_ref: str) -> dict:
    if not element_ref or not element_ref.strip():
        raise InvalidParamsError(message="element_ref cannot be empty", tool_name="click_element", param_name="element_ref")
    service = get_input_service()
    return service.click_element(element_ref=element_ref)


@mcp.tool()
@tool_error_handler("type_into_element")
def type_into_element(element_ref: str, text: str) -> dict:
    if not element_ref or not element_ref.strip():
        raise InvalidParamsError(message="element_ref cannot be empty", tool_name="type_into_element", param_name="element_ref")
    if not text:
        raise InvalidParamsError(message="Text cannot be empty", tool_name="type_into_element", param_name="text")
    service = get_input_service()
    return service.type_into_element(element_ref=element_ref, text=text)
