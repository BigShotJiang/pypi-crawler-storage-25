"""Configuration system for PeekabooWin using pydantic-settings.

Supports:
    - Environment variables with PEEKABOOWIN_ prefix
    - YAML config file at ~/.peekaboowin/config.yaml
    - Default values for all settings
"""

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PeekabooWinConfig(BaseSettings):
    """Main configuration model for PeekabooWin."""

    model_config = SettingsConfigDict(
        env_prefix="PEEKABOOWIN_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        validate_default=True,
    )

    # Logging settings
    log_level: str = Field(default="info", description="Logging level (debug, info, warning, error)")
    log_format: str = Field(default="json", description="Log format (json or console)")

    # Screenshot settings
    screenshot_format: str = Field(default="png", description="Screenshot format (png or jpeg)")
    screenshot_quality: int = Field(default=85, ge=1, le=100, description="JPEG quality (1-100)")
    screenshot_max_width: int = Field(default=1920, ge=100, description="Maximum screenshot width")

    # OCR settings
    ocr_enabled: bool = Field(default=False, description="Enable OCR functionality (requires paddleocr package)")
    ocr_language: str = Field(default="ch", description="OCR language code (ch, en)")
    ocr_use_gpu: bool = Field(default=False, description="Use GPU acceleration for OCR")

    def set_ocr_enabled(self, value: bool) -> None:
        """Set OCR enabled status (bypasses Pydantic immutability)."""
        object.__setattr__(self, "ocr_enabled", value)

    # UIA settings
    uia_timeout: float = Field(default=2.0, ge=0.1, description="UIA operation timeout in seconds")
    uia_max_depth: int = Field(default=10, ge=1, description="Maximum UIA tree traversal depth")

    # Input settings
    input_click_delay: float = Field(default=0.05, ge=0, description="Delay after click in seconds")
    input_type_delay: float = Field(default=0.02, ge=0, description="Delay between keystrokes in seconds")


def _get_yaml_config_path() -> Optional[Path]:
    """Get the YAML config file path if it exists."""
    custom_path = os.environ.get("PEEKABOOWIN_CONFIG_FILE")
    if custom_path:
        path = Path(custom_path)
        if path.exists():
            return path
    home_dir = Path.home()
    default_path = home_dir / ".peekaboowin" / "config.yaml"
    if default_path.exists():
        return default_path
    return None


def _load_yaml_config(yaml_path: Path) -> dict:
    """Load configuration from YAML file."""
    import yaml
    with open(yaml_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


@lru_cache(maxsize=1)
def get_config() -> PeekabooWinConfig:
    """Get the singleton configuration instance.

    Precedence:
    1. Environment variables (highest)
    2. YAML config file (~/.peekaboowin/config.yaml)
    3. Default values (lowest)
    """
    config = PeekabooWinConfig()

    yaml_path = _get_yaml_config_path()
    if yaml_path:
        yaml_config = _load_yaml_config(yaml_path)
        for key, value in yaml_config.items():
            env_key = f"PEEKABOOWIN_{key.upper()}"
            if env_key not in os.environ:
                object.__setattr__(config, key, value)

    return config
