"""PeekabooWin MCP Server entry point."""

import logging
import sys

import structlog

from mcp.server.fastmcp import FastMCP

from peekaboowin.config import get_config
from peekaboowin.errors import PeekabooWinError

mcp = FastMCP("peekaboowin")


def _setup_logging() -> None:
    config = get_config()
    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
    ]
    if config.log_format == "json":
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer(colors=True))
    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(getattr(logging, config.log_level.upper(), logging.INFO)),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


def _auto_enable_ocr() -> None:
    config = get_config()
    if not config.ocr_enabled:
        try:
            import paddleocr  # noqa: F401
            config.set_ocr_enabled(True)
            structlog.get_logger().info("ocr_auto_enabled", reason="paddleocr_installed")
        except ImportError:
            pass


def _register_tools() -> None:
    import importlib
    tool_modules = [
        "peekaboowin.tools.screen", "peekaboowin.tools.find", "peekaboowin.tools.input",
        "peekaboowin.tools.window", "peekaboowin.tools.wait", "peekaboowin.tools.clipboard",
        "peekaboowin.tools.harvest", "peekaboowin.tools.ocr",
    ]
    logger = structlog.get_logger()
    for module_name in tool_modules:
        try:
            importlib.import_module(module_name)
            logger.debug("tool_module_registered", module=module_name)
        except Exception as e:
            logger.error("tool_module_register_error", module=module_name, error=str(e), error_type=type(e).__name__)


def main() -> None:
    from peekaboowin.platform.permissions import enable_dpi_awareness
    enable_dpi_awareness()
    _setup_logging()
    _auto_enable_ocr()
    logger = structlog.get_logger()
    logger.info("peekaboowin_starting", version="0.1.0")
    _register_tools()
    try:
        mcp.run()
    except KeyboardInterrupt:
        logger.info("peekaboowin_shutdown")
    except Exception as e:
        logger.exception("peekaboowin_fatal_error")
        sys.exit(1)


if __name__ == "__main__":
    main()
