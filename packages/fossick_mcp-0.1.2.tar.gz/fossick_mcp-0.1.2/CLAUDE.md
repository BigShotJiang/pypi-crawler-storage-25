# CLAUDE.md

Project instructions for AI coding agents working on **fossick-mcp**. Covers what the project is, how it's organized, and the recipes for common tasks.

## Table of contents

1. [What fossick is](#what-fossick-is)
2. [Stack](#stack)
3. [Repository layout](#repository-layout)
4. [Key patterns](#key-patterns)
5. [Tools](#tools)
6. [Hints system](#hints-system)
7. [Adding a new tool](#adding-a-new-tool)
8. [Tests](#tests)
9. [Rate limits](#rate-limits)
10. [Conventions](#conventions)

## What fossick is

Discovery-focused MCP server for finding and evaluating new libraries, frameworks, and packages to adopt in new projects. Seven tools covering the "starting a project, need to pick the right dependency" workflow, spanning GitHub (200M+ repos), PyPI, and npm.

**NOT for code archaeology** — git history, blame, PR tracking, version diffing. Reach for `git` / `gh` CLI via Bash instead.

The name comes from the Australian/NZ verb _fossick_ — "to prospect or rummage for gems" — which is what the tool does: sift 200M+ repos down to the handful worth evaluating.

## Stack

- **Python 3.11+**, pinned via `.python-version`
- **`uv`** for package management and builds
- **FastMCP** (`mcp >= 1.26`) with stdio transport
- **`httpx`** for async GitHub API calls
- **Pydantic** for settings
- **`tree-sitter`** for AST-based symbol search

## Repository layout

```
src/fossick/
  server.py             — FastMCP instance, instructions, lifespan, tool imports
  github_client.py      — Async httpx client, auth, rate limits, retry
  cache.py              — In-memory TTL cache with LRU eviction
  hints.py              — Rule-based next-step suggestion engine
  tools/                — One file per tool
  tools/_common.py      — Shared helpers (split_repo, http_error_to_tool_error)
  tools/_tree_sitter.py — AST queries for find_symbol

tests/
  unit/                 — No network. Classifier branches, cache, hints, etc.
  integration/          — Live, pinned to modelcontextprotocol/python-sdk@v1.14.0
  test_registration.py  — Schema + registration smoke for all 7 tools
```

## Key patterns

- **Server singleton.** `mcp` in `server.py` is the single FastMCP instance. Tool files import it and register via `@mcp.tool()`.
- **Client singleton.** `get_client()` in `github_client.py` lazily creates one shared `GitHubClient`. Token resolved from `GH_TOKEN`, `GITHUB_TOKEN`, or `GITHUB_PERSONAL_ACCESS_TOKEN` env vars, with `gh auth token` as a fallback.
- **Lifespan management.** The httpx client is created on startup and closed on shutdown via the `_lifespan()` context manager in `server.py`.
- **Rate-limit awareness.** Separate buckets for Search API (30/min) and Core API (5000/hr). Reads `X-RateLimit-*` headers and sleeps when exhausted.
- **Retry with backoff.** Exponential backoff on `403`/`429`/`502`/`503`, max 3 attempts.
- **TTL cache.** Search results: 120s. Branch content: 300s. SHA-pinned content: 3600s. Trees: 600s.
- **Tool annotations.** Every tool is marked `readOnlyHint=True, destructiveHint=False, idempotentHint=True`. This tells clients they're safe to auto-approve.
- **Error classification.** Tools wrap their body in `try/except Exception` and call `http_error_to_tool_error(e, tool="...", repo=..., path=..., ref=..., query=...)` from `tools/_common.py`. The helper classifies the httpx exception (401 / 403 rate-limit vs perm / 404 with tool-specific chain hints / 422 / 5xx / network) and returns a `ToolError` with an LLM-actionable message that names the next fossick tool to chain to. **Never raise a bare `ToolError(f"Error: {e}")`** — it drops the HTTP status and produces retry loops.
- **No `from __future__ import annotations`** in tool files. FastMCP needs runtime type introspection for JSON Schema generation.

## Tools

Seven tools, grouped by role in the discovery workflow.

### Find candidates
- **`search_repos`** — Discover libraries by topic, stars, language, trending. Accepts a `queries=[...]` list for multi-phrasing recall. `GET /search/repositories`.
- **`search_packages`** — Direct PyPI/npm lookup by package name. External APIs, no GitHub rate limit.

### Evaluate a candidate
- **`repo_tree`** — Browse a repo's layout with depth and glob filtering. `GET /repos/{o}/{r}/git/trees/{sha}?recursive=1`.
- **`get_file`** — Read specific files at any ref. `GET /repos/{o}/{r}/contents/{path}`.
- **`find_symbol`** — Locate a class/function/type definition via tree-sitter AST queries. `GET /search/code` plus local AST parsing of up to 15 files.
- **`list_tags`** — Check freshness and recent releases. `GET /repos/{o}/{r}/tags` or `/releases`.

### Real-world usage
- **`search_code`** — Full-text code search across all of GitHub. Supports `repo:`, `language:`, `path:`, boolean operators, and regex. `GET /search/code` with text-match headers.

### Param conventions
- Optional string params use `str = ""` (not `str | None`) so FastMCP generates clean JSON Schema types.
- Optional int params use `int = 0`.
- Convenience params (`repo`, `language`, `path`) are appended as GitHub search qualifiers to the query string.
- All tools return `str` — formatted text with hints appended.

## Hints system

Every tool response ends with suggested next steps generated by `hints.py`. Rules are defined as `(tool_name, condition_fn, template, priority)` tuples. The top 3 hints are appended as a markdown section. Templates use real values from the result (file paths, repo names, etc.) so the agent can act on them directly without extra reasoning.

The hints are load-bearing — they're how the agent learns the discovery workflow without extra prompting. When you add a new tool, write hint rules that point the agent toward the next sensible step.

## Adding a new tool

1. Create `src/fossick/tools/my_tool.py`.
2. Import `mcp` from `fossick.server`, `get_client` from `fossick.github_client`, and `http_error_to_tool_error` (plus `split_repo` if the tool takes a `repo`) from `fossick.tools._common`.
3. Decorate with:
   ```python
   @mcp.tool(annotations=ToolAnnotations(
       readOnlyHint=True,
       destructiveHint=False,
       idempotentHint=True,
       openWorldHint=True,
   ))
   ```
4. The tool function must be `async`, return `str`, and wrap its body in:
   ```python
   try:
       ...
   except Exception as e:
       raise http_error_to_tool_error(e, tool="my_tool", ...)
   ```
   passing whatever context (`repo`, `path`, `ref`, `query`) is available.
5. Add hint rules in `hints.py`.
6. Import the module in `server.py`.
7. Add a smoke test in `tests/integration/test_tools_smoke.py`. If the tool has a tool-specific 404 chain hint, add an error test in `tests/integration/test_tools_errors.py`.

## Tests

```bash
uv run pytest              # unit + registration (no network)
uv run pytest -m live      # live integration tests against real GitHub
```

Three layers:

- **`unit/`** — no network. Cache, hints, token resolution, `split_repo`, and `http_error_to_tool_error` (every classifier branch with fabricated `httpx.HTTPStatusError` instances).
- **`test_registration.py`** — schema and registration smoke for all 7 tools.
- **`integration/`** — `live`-marked, hits real GitHub pinned against `modelcontextprotocol/python-sdk@v1.14.0`. Auto-skipped without a resolvable token. `test_tools_smoke.py` covers happy paths; `test_tools_errors.py` forces real 404s on `get_file` / `repo_tree` / `list_tags` to verify each tool wires the right context into the classifier end-to-end.

CI lives in `.github/workflows/test.yml`. Unit + registration run on every push and PR; the integration job only runs on `main`, the nightly schedule, and manual `workflow_dispatch`.

## Rate limits

- **Search API** — 30/min: `search_repos`, `search_code`, `find_symbol`
- **Core API** — 5,000/hr: `get_file`, `repo_tree`, `list_tags`. `find_symbol` also spends Core quota fetching up to 15 files per call for tree-sitter parsing.
- **External APIs** — `search_packages` hits PyPI/npm directly; no GitHub rate limit.

## Conventions

- **Keep changes scoped.** A bug fix doesn't need a refactor. A new feature doesn't need extra configurability. Three similar lines of code beats a premature abstraction.
- **No speculative error handling.** Only validate at system boundaries. Trust internal code and framework guarantees.
- **Match existing patterns before inventing new ones.** When adding a tool, follow the shape of the existing seven. When touching an existing tool, preserve its structure unless there's a reason to change it.
- **The error classifier is load-bearing.** `_common.py::http_error_to_tool_error` is the single most important code surface for agent UX — every new error chain needs a unit test in `test_error_classification.py`.
- **No emojis in files unless explicitly requested.** Applies to code comments, docstrings, and documentation.
