"""Layer A: FastMCP registration / schema tests.

These are the highest-value, cheapest tests in the suite — they run in
milliseconds, need no network, and catch the class of bugs that a bad type
annotation or accidental `from __future__ import annotations` would cause
(FastMCP does runtime type introspection and silently breaks on bad signatures).
"""

import pytest

from fossick.server import mcp

# Expected tools and their required params. Adding or removing a tool
# forces an update here — intentional friction.
EXPECTED_TOOLS: dict[str, set[str]] = {
    "search_code": {"query"},
    "search_repos": set(),
    "get_file": {"repo", "path"},
    "repo_tree": {"repo"},
    "find_symbol": {"name"},
    "list_tags": {"repo"},
    "search_packages": {"name"},
}


async def test_all_expected_tools_registered():
    """Every tool in EXPECTED_TOOLS must be registered on the MCP server."""
    tools = await mcp.list_tools()
    registered = {t.name for t in tools}
    missing = set(EXPECTED_TOOLS) - registered
    assert not missing, f"Tools missing from registration: {sorted(missing)}"


async def test_no_unexpected_tools_registered():
    """Catch accidental registration of experimental or leftover tools."""
    tools = await mcp.list_tools()
    registered = {t.name for t in tools}
    extra = registered - set(EXPECTED_TOOLS)
    assert not extra, (
        f"Unexpected tools registered: {sorted(extra)}. "
        f"If intentional, add them to EXPECTED_TOOLS in this test."
    )


@pytest.mark.parametrize("tool_name", list(EXPECTED_TOOLS))
async def test_tool_has_description(tool_name: str):
    """Every tool must have a non-empty description (shown to LLMs)."""
    tools = await mcp.list_tools()
    tool = next((t for t in tools if t.name == tool_name), None)
    assert tool is not None, f"{tool_name} not registered"
    assert tool.description, f"{tool_name} has no description"
    assert len(tool.description) > 20, (
        f"{tool_name} description suspiciously short: {tool.description!r}"
    )


@pytest.mark.parametrize("tool_name", list(EXPECTED_TOOLS))
async def test_tool_input_schema_is_valid_object(tool_name: str):
    """FastMCP must have generated a JSON Schema with type=object and properties."""
    tools = await mcp.list_tools()
    tool = next((t for t in tools if t.name == tool_name), None)
    assert tool is not None

    schema = tool.inputSchema
    assert isinstance(schema, dict), f"{tool_name} schema is not a dict"
    assert schema.get("type") == "object", (
        f"{tool_name} schema type is {schema.get('type')!r}, expected 'object'"
    )
    assert isinstance(schema.get("properties"), dict), (
        f"{tool_name} schema is missing 'properties'"
    )
    assert schema["properties"], f"{tool_name} has no properties in schema"


@pytest.mark.parametrize(
    ("tool_name", "expected_required"),
    list(EXPECTED_TOOLS.items()),
)
async def test_tool_required_params(tool_name: str, expected_required: set[str]):
    """Required params in the schema must match the expected set."""
    tools = await mcp.list_tools()
    tool = next((t for t in tools if t.name == tool_name), None)
    assert tool is not None

    schema_required = set(tool.inputSchema.get("required", []))
    assert schema_required == expected_required, (
        f"{tool_name} required params mismatch.\n"
        f"  schema says: {sorted(schema_required)}\n"
        f"  expected:    {sorted(expected_required)}"
    )


# Tools that target a single repository — must take a combined 'owner/name'
# string, not split owner + repo. This guards against accidentally re-adding
# the split params that caused the retry-loop bug we just fixed.
TOOLS_WITH_COMBINED_REPO = {
    "get_file",
    "repo_tree",
    "list_tags",
}


@pytest.mark.parametrize("tool_name", sorted(TOOLS_WITH_COMBINED_REPO))
async def test_refactored_tools_use_combined_repo_param(tool_name: str):
    """Regression guard for the API unification fix.

    Every repo-targeting tool must expose a single ``repo`` param in the
    schema and MUST NOT expose a separate ``owner`` param. If someone adds
    an ``owner`` param back, Claude starts retry-looping on validation
    errors again because half the tools would take combined ``owner/name``
    and half would take split params — the exact inconsistency that drove
    ~40% of errored fossick calls in production session logs.
    """
    tools = await mcp.list_tools()
    tool = next((t for t in tools if t.name == tool_name), None)
    assert tool is not None

    props = tool.inputSchema.get("properties", {})
    assert "owner" not in props, (
        f"{tool_name} has an 'owner' param — the API unification fix "
        f"requires a single combined 'repo' param in 'owner/name' format."
    )
    assert "repo" in props, f"{tool_name} is missing the 'repo' param"
    assert "repo" in tool.inputSchema.get("required", []), (
        f"{tool_name} must mark 'repo' as required"
    )
