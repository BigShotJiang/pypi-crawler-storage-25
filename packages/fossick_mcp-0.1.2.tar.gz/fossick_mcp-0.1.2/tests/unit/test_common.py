"""Unit tests for fossick.tools._common.split_repo.

This helper drives the API uniformity fix: every tool that targets a single
repository now takes a combined ``"owner/name"`` string instead of split
``owner`` + ``repo`` params. The helper validates the format and produces a
clear, LLM-actionable error on malformed input — the whole point of the
change is to stop the retry-loop pattern where Claude passes a combined
string to a tool that expects split params (or vice versa) and keeps hitting
an opaque Pydantic validation error.
"""

import pytest

from mcp.server.fastmcp.exceptions import ToolError

from fossick.tools._common import split_repo


# -- happy path --------------------------------------------------------------


def test_splits_standard_owner_name():
    assert split_repo("modelcontextprotocol/python-sdk") == (
        "modelcontextprotocol",
        "python-sdk",
    )


def test_allows_dots_and_dashes():
    # GitHub org/repo names can contain these
    assert split_repo("foo-bar.baz/hello.world-v2") == (
        "foo-bar.baz",
        "hello.world-v2",
    )


def test_strips_surrounding_whitespace():
    assert split_repo("  owner/name  ") == ("owner", "name")


# -- error path --------------------------------------------------------------


def test_rejects_empty_string():
    with pytest.raises(ToolError) as exc:
        split_repo("")
    # Error message must mention the expected format so the LLM can self-correct
    assert "owner/name" in str(exc.value)


def test_rejects_whitespace_only():
    with pytest.raises(ToolError) as exc:
        split_repo("   ")
    assert "owner/name" in str(exc.value)


def test_rejects_missing_slash():
    with pytest.raises(ToolError) as exc:
        split_repo("justthename")
    assert "owner/name" in str(exc.value)
    # Echo the bad value so the user/LLM knows what was rejected
    assert "justthename" in str(exc.value)


def test_rejects_missing_owner():
    with pytest.raises(ToolError) as exc:
        split_repo("/name")
    assert "owner/name" in str(exc.value)


def test_rejects_missing_name():
    with pytest.raises(ToolError) as exc:
        split_repo("owner/")
    assert "owner/name" in str(exc.value)


def test_rejects_too_many_slashes():
    with pytest.raises(ToolError) as exc:
        split_repo("a/b/c")
    assert "owner/name" in str(exc.value)


def test_rejects_non_string():
    with pytest.raises(ToolError):
        split_repo(None)  # type: ignore[arg-type]
