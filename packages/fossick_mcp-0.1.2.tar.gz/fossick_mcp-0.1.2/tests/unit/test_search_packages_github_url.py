"""Unit tests for _pick_github_repo_url in search_packages.

Locks in the bug fix for PyPI packages whose `project_urls` exposes multiple
github.com entries, e.g. a `Bug Tracker` pointing at `.../issues` alongside a
`Homepage` or `Source` pointing at the repo root. The previous implementation
iterated `project_urls.items()` and grabbed the first github URL it saw, which
on packages like `mcp` produced `GitHub: .../issues` — the wrong link for the
"source repository" role the label implies.
"""

from fossick.tools.search_packages import (
    _is_github_repo_url,
    _pick_github_repo_url,
)


# -- _is_github_repo_url ------------------------------------------------------


def test_repo_root_url_passes():
    assert _is_github_repo_url("https://github.com/owner/repo")


def test_issues_subpage_rejected():
    assert not _is_github_repo_url("https://github.com/owner/repo/issues")


def test_pull_subpage_rejected():
    assert not _is_github_repo_url("https://github.com/owner/repo/pull/123")


def test_wiki_subpage_rejected():
    assert not _is_github_repo_url("https://github.com/owner/repo/wiki")


def test_non_github_url_rejected():
    assert not _is_github_repo_url("https://gitlab.com/owner/repo")


def test_empty_url_rejected():
    assert not _is_github_repo_url("")


# -- _pick_github_repo_url ----------------------------------------------------


def test_mcp_style_bug_tracker_before_homepage():
    # Reproduces the exact `mcp` package bug: Bug Tracker key appears
    # before Homepage in the dict, both are github.com URLs, and the
    # picker must return the repo root rather than /issues.
    project_urls = {
        "Bug Tracker": "https://github.com/modelcontextprotocol/python-sdk/issues",
        "Homepage": "https://github.com/modelcontextprotocol/python-sdk",
        "Documentation": "https://modelcontextprotocol.io",
    }
    assert (
        _pick_github_repo_url(project_urls, "")
        == "https://github.com/modelcontextprotocol/python-sdk"
    )


def test_source_key_beats_homepage():
    project_urls = {
        "Homepage": "https://example.com",
        "Source": "https://github.com/owner/repo",
        "Bug Tracker": "https://github.com/owner/repo/issues",
    }
    assert _pick_github_repo_url(project_urls, "") == "https://github.com/owner/repo"


def test_source_code_key_accepted():
    project_urls = {"Source Code": "https://github.com/owner/repo"}
    assert _pick_github_repo_url(project_urls, "") == "https://github.com/owner/repo"


def test_repository_key_accepted():
    project_urls = {"Repository": "https://github.com/owner/repo"}
    assert _pick_github_repo_url(project_urls, "") == "https://github.com/owner/repo"


def test_case_insensitive_keys():
    project_urls = {"SOURCE": "https://github.com/owner/repo"}
    assert _pick_github_repo_url(project_urls, "") == "https://github.com/owner/repo"


def test_falls_back_to_unpreferred_key_if_valid():
    # No preferred keys, but a non-preferred key has a valid repo URL.
    project_urls = {"Changelog": "https://github.com/owner/repo"}
    assert _pick_github_repo_url(project_urls, "") == "https://github.com/owner/repo"


def test_falls_back_to_home_page_field():
    # Empty project_urls — the top-level home_page field is last resort.
    assert (
        _pick_github_repo_url({}, "https://github.com/owner/repo")
        == "https://github.com/owner/repo"
    )


def test_only_issues_url_returns_empty():
    # If every candidate is a sub-page, return empty string rather than
    # emitting a wrong "GitHub:" label.
    project_urls = {"Bug Tracker": "https://github.com/owner/repo/issues"}
    assert _pick_github_repo_url(project_urls, "") == ""


def test_no_github_urls_returns_empty():
    project_urls = {"Homepage": "https://example.com"}
    assert _pick_github_repo_url(project_urls, "https://example.com") == ""


def test_ignores_empty_values():
    project_urls = {"Source": "", "Homepage": "https://github.com/owner/repo"}
    assert _pick_github_repo_url(project_urls, "") == "https://github.com/owner/repo"
