"""Unit tests for fossick.cache — TTLCache and cache_key."""

from fossick.cache import TTLCache, cache_key


# -- TTLCache.get / set -----------------------------------------------------


async def test_set_then_get_returns_value():
    c = TTLCache()
    await c.set("k", "v")
    assert await c.get("k") == "v"


async def test_get_missing_key_returns_none():
    c = TTLCache()
    assert await c.get("nope") is None


async def test_expired_entry_returns_none_and_is_purged():
    c = TTLCache()
    await c.set("k", "v", ttl=-1)  # already expired
    assert await c.get("k") is None
    # Second read confirms it was removed, not just masked
    assert await c.get("k") is None


async def test_set_overwrites_existing_value():
    c = TTLCache()
    await c.set("k", "v1")
    await c.set("k", "v2")
    assert await c.get("k") == "v2"


async def test_set_same_key_does_not_grow_store():
    c = TTLCache()
    await c.set("k", "v1")
    await c.set("k", "v2")
    assert len(c._store) == 1


# -- LRU eviction ------------------------------------------------------------


async def test_evicts_oldest_when_over_max_size():
    c = TTLCache(max_size=3)
    await c.set("a", 1)
    await c.set("b", 2)
    await c.set("c", 3)
    await c.set("d", 4)  # forces eviction of "a"

    assert await c.get("a") is None
    assert await c.get("b") == 2
    assert await c.get("c") == 3
    assert await c.get("d") == 4


async def test_get_promotes_entry_to_most_recently_used():
    c = TTLCache(max_size=3)
    await c.set("a", 1)
    await c.set("b", 2)
    await c.set("c", 3)
    # Touch "a" — it should now be most-recently-used
    await c.get("a")
    await c.set("d", 4)  # should evict "b", not "a"

    assert await c.get("a") == 1
    assert await c.get("b") is None
    assert await c.get("c") == 3
    assert await c.get("d") == 4


# -- invalidate --------------------------------------------------------------


async def test_invalidate_removes_matching_and_returns_count():
    c = TTLCache()
    await c.set("search:foo", 1)
    await c.set("search:bar", 2)
    await c.set("tree:baz", 3)

    removed = c.invalidate(r"^search:")
    assert removed == 2
    assert await c.get("search:foo") is None
    assert await c.get("search:bar") is None
    assert await c.get("tree:baz") == 3


async def test_invalidate_no_match_returns_zero():
    c = TTLCache()
    await c.set("a", 1)
    assert c.invalidate(r"^nothing") == 0
    assert await c.get("a") == 1


# -- cache_key ---------------------------------------------------------------


def test_cache_key_is_deterministic():
    k1 = cache_key("search_code", query="foo", page=1)
    k2 = cache_key("search_code", query="foo", page=1)
    assert k1 == k2


def test_cache_key_is_order_independent():
    k1 = cache_key("search_code", query="foo", page=1, per_page=30)
    k2 = cache_key("search_code", per_page=30, query="foo", page=1)
    assert k1 == k2


def test_cache_key_changes_when_endpoint_changes():
    k1 = cache_key("search_code", query="foo")
    k2 = cache_key("search_repos", query="foo")
    assert k1 != k2


def test_cache_key_changes_when_params_change():
    k1 = cache_key("search_code", query="foo")
    k2 = cache_key("search_code", query="bar")
    assert k1 != k2


def test_cache_key_is_hex_string():
    k = cache_key("search_code", query="foo")
    assert isinstance(k, str)
    assert len(k) == 64  # sha256 hex length
    int(k, 16)  # must parse as hex
