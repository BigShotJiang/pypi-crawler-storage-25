"""Unit tests for fossick.hints — generate_hints and format_hints."""

from fossick.hints import format_hints, generate_hints


# -- generate_hints: rule firing by tool ------------------------------------


def test_search_code_with_results_returns_two_highest_priority_hints():
    hints = generate_hints(
        "search_code",
        params={"query": "foo", "per_page": 30},
        result={"total_count": 5, "items": []},
    )
    assert len(hints) == 2
    # Priority 1 (get_file) and priority 2 (page=N doesn't fire because
    # 5 < 30) — so priority 1 and priority 3 (find_symbol) should remain
    assert "get_file" in hints[0]
    assert "find_symbol" in hints[1]


def test_search_code_with_pagination_needed_surfaces_paging_hint():
    hints = generate_hints(
        "search_code",
        params={"query": "foo", "per_page": 10},
        result={"total_count": 100, "items": []},
    )
    # get_file (prio 1) and page=N (prio 2) should be the top two
    assert len(hints) == 2
    assert "get_file" in hints[0]
    assert "page=N" in hints[1]


def test_search_code_with_zero_results_returns_no_hints():
    hints = generate_hints(
        "search_code",
        params={"query": "foo"},
        result={"total_count": 0, "items": []},
    )
    assert hints == []


def test_get_file_always_returns_two_hints():
    # get_file rules are unconditional
    hints = generate_hints("get_file", params={}, result={})
    assert len(hints) == 2
    assert "find_symbol" in hints[0]
    assert "search_code" in hints[1]


def test_find_symbol_with_results_returns_two_hints():
    hints = generate_hints(
        "find_symbol",
        params={"name": "FastMCP"},
        result={"total_count": 3},
    )
    assert len(hints) == 2
    assert "get_file" in hints[0]
    assert "search_code" in hints[1]


# -- generate_hints: bounds and edge cases ----------------------------------


def test_generate_hints_returns_at_most_two():
    # search_code has 3 rules; must still cap at 2
    hints = generate_hints(
        "search_code",
        params={"per_page": 1},
        result={"total_count": 100},
    )
    assert len(hints) == 2


def test_unknown_tool_returns_empty():
    assert generate_hints("made_up_tool", {}, {}) == []


def test_empty_result_does_not_crash_any_tool():
    # Template safety: every registered tool should tolerate an empty result
    # dict without raising. The rule engine catches exceptions, but this
    # documents and guards that behavior.
    from fossick.server import mcp  # triggers tool registration

    # Import is enough to register; we don't need the mcp object itself.
    del mcp

    tool_names = [
        "search_code", "search_repos", "get_file", "repo_tree",
        "find_symbol", "list_tags", "search_packages",
    ]
    for name in tool_names:
        # Must not raise
        result = generate_hints(name, params={}, result={})
        assert isinstance(result, list)


def test_condition_exception_is_swallowed():
    # Fabricate a params/result that would KeyError if any lambda did
    # direct indexing (we know the real lambdas use .get(), but this guards
    # against regressions).
    hints = generate_hints("search_code", params={}, result={})
    # With empty result, total_count defaults to 0, no rules fire
    assert hints == []


# -- format_hints ------------------------------------------------------------


def test_format_hints_empty_returns_empty_string():
    assert format_hints([]) == ""


def test_format_hints_renders_markdown_section():
    out = format_hints(
        ["`get_file` — read a matched file", "`find_symbol` — locate a definition"]
    )
    # Has the suggested-next-steps header
    assert "Suggested next steps" in out
    # Each hint becomes a bullet
    assert "- `get_file` — read a matched file" in out
    assert "- `find_symbol` — locate a definition" in out
    # Has the horizontal rule separator
    assert "---" in out
