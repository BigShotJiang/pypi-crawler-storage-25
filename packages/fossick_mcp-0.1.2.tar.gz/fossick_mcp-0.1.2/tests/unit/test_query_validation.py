"""Unit tests for fossick.tools._common.validate_search_query.

Why this exists: GitHub's three Search APIs (code, repository,
issues/PRs) each support a different set of qualifiers. When a query
contains a qualifier the target endpoint doesn't know about, GitHub
does NOT return an error — it silently matches the token as literal
content. That means an LLM passing ``stars:>100`` to the code-search
endpoint gets HTTP 200 with a body full of files whose source happens
to contain the substring ``stars:>100``, rather than filtering by repo
popularity. There is no signal anywhere in the response that the query
was wrong.

This is the symmetric, input-side counterpart to the error classifier
shipped 2026-04-11 for outputs: convert a silent-wrong-result failure
into an LLM-actionable ``ToolError`` that names the forbidden
qualifier, explains *why* it's wrong, and points at the right tool.

These tests are pure — the validator never touches the network. Each
test passes a fabricated query and asserts the resulting behavior
(raise vs. pass-through) and, for errors, the specific phrases the
message must contain so the model can self-correct.
"""

import pytest

from mcp.server.fastmcp.exceptions import ToolError

from fossick.tools._common import (
    CODE_SEARCH_QUALIFIERS,
    CODE_SEARCH_REDIRECTS,
    REPO_SEARCH_QUALIFIERS,
    REPO_SEARCH_REDIRECTS,
    validate_search_query,
)


# -- happy paths: valid queries pass through silently -----------------------


def test_empty_query_is_a_noop():
    # Every tool that calls the validator may receive an empty query;
    # the helper must not raise.
    validate_search_query(
        "",
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


def test_query_with_no_qualifiers_passes():
    validate_search_query(
        "FastMCP server tool",
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


def test_valid_code_search_qualifiers_pass():
    validate_search_query(
        "FastMCP repo:modelcontextprotocol/python-sdk language:python path:src",
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


def test_valid_repo_search_qualifiers_pass():
    validate_search_query(
        "topic:mcp stars:>1000 pushed:>2024-01-01 language:python is:public",
        tool="search_repos",
        allowed=REPO_SEARCH_QUALIFIERS,
        redirects=REPO_SEARCH_REDIRECTS,
    )


def test_negated_valid_qualifier_passes():
    # `-language:go` is negation on a valid qualifier — must not trip
    # the validator's leading-dash stripping.
    validate_search_query(
        "FastMCP -language:go",
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


def test_qualifier_shaped_text_inside_double_quotes_is_ignored():
    # Quoted content is literal — a qualifier-looking substring inside
    # quotes is a search term, not a filter, and must not trigger a
    # validation error.
    validate_search_query(
        '"stars:>100 is a documented example"',
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


def test_qualifier_shaped_text_inside_single_quotes_is_ignored():
    validate_search_query(
        "'stars:>100 is a documented example'",
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


def test_qualifier_shaped_text_inside_regex_literal_is_ignored():
    # A /.../ regex literal is opaque content to the validator.
    validate_search_query(
        "/stars:>\\d+/",
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


def test_uppercase_qualifier_name_is_normalized():
    # GitHub accepts qualifier names case-insensitively; the validator
    # normalizes to lowercase before matching the allowlist.
    validate_search_query(
        "FastMCP LANGUAGE:python",
        tool="search_code",
        allowed=CODE_SEARCH_QUALIFIERS,
        redirects=CODE_SEARCH_REDIRECTS,
    )


# -- error paths: the core bug — silent-qualifier leakage -------------------


def test_code_search_rejects_stars_with_redirect_to_search_repos():
    # This is the exact bug the validator exists to prevent: stars:>N
    # looks like a filter but GitHub code search treats it as literal
    # content, returning files whose source contains the substring.
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "@mcp.tool stars:>100",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    # Must name the offending qualifier
    assert "stars:" in msg
    # Must explain WHY (silent-match behavior)
    assert "silently" in msg.lower() or "literal" in msg.lower()
    # Must route the model to the correct tool for the intended filter
    assert "search_repos" in msg
    # Must mark as not-retryable — the output-side classifier uses the
    # same phrasing so the model already knows what it means.
    assert "Not retryable" in msg
    # Must list the valid qualifiers so the model can self-correct
    assert "repo:" in msg
    assert "language:" in msg


def test_code_search_rejects_pushed():
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "FastMCP pushed:>2024-01-01",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "pushed:" in msg
    assert "search_repos" in msg


def test_code_search_rejects_topic():
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "import mcp topic:mcp",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "topic:" in msg
    assert "search_repos" in msg


def test_code_search_rejects_forks_with_explanation_about_is_fork():
    # `forks:>N` is a repo-search qualifier; code search has only
    # `is:fork` for boolean filtering. The redirect should explain that.
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "@mcp.tool forks:>10",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "forks:" in msg
    assert "search_repos" in msg


def test_code_search_rejects_archived_with_redirect_to_is_archived():
    # `archived:true` is repo-search syntax; code search uses
    # `is:archived`. Redirect should teach that.
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "FastMCP archived:false",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "archived:" in msg
    assert "is:archived" in msg


def test_code_search_rejects_license():
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "import requests license:mit",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "license:" in msg
    assert "search_repos" in msg


def test_repo_search_rejects_path_with_redirect_to_search_code():
    # File-level qualifiers are the symmetric bug — dropping `path:src`
    # into a repo-search query matches repo metadata containing the
    # literal, not filtering by file path.
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "topic:mcp path:src",
            tool="search_repos",
            allowed=REPO_SEARCH_QUALIFIERS,
            redirects=REPO_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "path:" in msg
    assert "search_code" in msg
    assert "Not retryable" in msg


def test_repo_search_rejects_filename():
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "topic:python filename:pyproject.toml",
            tool="search_repos",
            allowed=REPO_SEARCH_QUALIFIERS,
            redirects=REPO_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "filename:" in msg
    assert "search_code" in msg


def test_repo_search_rejects_extension():
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "topic:data extension:ipynb",
            tool="search_repos",
            allowed=REPO_SEARCH_QUALIFIERS,
            redirects=REPO_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "extension:" in msg
    assert "search_code" in msg


def test_repo_search_rejects_content_and_symbol():
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "topic:mcp content:FastMCP symbol:main",
            tool="search_repos",
            allowed=REPO_SEARCH_QUALIFIERS,
            redirects=REPO_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "content:" in msg
    assert "symbol:" in msg
    assert "search_code" in msg


# -- multiple violations and edge cases -------------------------------------


def test_multiple_violations_are_all_reported():
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "@mcp.tool stars:>100 topic:mcp license:mit",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    # Every forbidden qualifier must be named so the model can fix all
    # of them in one pass rather than trial-and-erroring through a
    # whack-a-mole loop.
    assert "stars:" in msg
    assert "topic:" in msg
    assert "license:" in msg


def test_duplicate_forbidden_qualifier_reported_once():
    # If the same forbidden qualifier appears multiple times, we don't
    # want to spam the error message with repeats.
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "foo stars:>100 bar stars:<500",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    # The violations-list line should mention `stars:` exactly once in
    # the comma-separated list (count occurrences of the
    # backtick-wrapped form, which only appears in the header line and
    # at most one redirect hint line).
    header_line = msg.splitlines()[0]
    assert header_line.count("`stars:`") == 1


def test_error_message_includes_tool_name():
    # The tool name shows up in the header so multi-tool error logs
    # remain parseable — same convention as http_error_to_tool_error.
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "stars:>100",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    assert "search_code" in str(exc.value)


def test_unknown_qualifier_without_specific_hint_still_errors_cleanly():
    # A qualifier the validator has never heard of (no entry in the
    # redirects dict) must still raise — generic fall-through behavior.
    with pytest.raises(ToolError) as exc:
        validate_search_query(
            "foo bogusqualifier:bar",
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )
    msg = str(exc.value)
    assert "bogusqualifier:" in msg
    # Should still list the allowed qualifiers so the model has
    # something to work with even without a targeted redirect.
    assert "repo:" in msg


def test_code_search_and_repo_search_have_disjoint_redirects():
    # Regression test against the copy-paste that caused this whole
    # mess: code-search redirects must point at search_repos, and
    # vice versa. Swapping them would re-enable the bug.
    for name, hint in CODE_SEARCH_REDIRECTS.items():
        assert "search_repos" in hint or "is:" in hint, (
            f"code-search redirect for `{name}:` should route to "
            f"search_repos (got: {hint!r})"
        )
    for name, hint in REPO_SEARCH_REDIRECTS.items():
        assert "search_code" in hint or "find_symbol" in hint, (
            f"repo-search redirect for `{name}:` should route to "
            f"search_code or find_symbol (got: {hint!r})"
        )


def test_code_search_qualifiers_do_not_include_repo_search_filters():
    # The exact set-level assertion that would have caught the
    # original bug: stars/pushed/forks/topic/license must not appear
    # in CODE_SEARCH_QUALIFIERS.
    forbidden_on_code = {
        "stars", "pushed", "forks", "created", "updated",
        "topic", "topics", "license",
    }
    overlap = forbidden_on_code & CODE_SEARCH_QUALIFIERS
    assert overlap == set(), (
        f"these qualifiers are only valid on search_repos, not "
        f"search_code — they must NOT be in CODE_SEARCH_QUALIFIERS: "
        f"{overlap}"
    )


def test_repo_search_qualifiers_do_not_include_code_search_filters():
    forbidden_on_repo = {
        "path", "filename", "extension", "content", "symbol",
    }
    overlap = forbidden_on_repo & REPO_SEARCH_QUALIFIERS
    assert overlap == set(), (
        f"these qualifiers are only valid on search_code, not "
        f"search_repos — they must NOT be in REPO_SEARCH_QUALIFIERS: "
        f"{overlap}"
    )
