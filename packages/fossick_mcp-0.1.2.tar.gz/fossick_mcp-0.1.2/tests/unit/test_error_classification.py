"""Unit tests for fossick.tools._common.http_error_to_tool_error.

Why this exists: session-log analysis showed ~40 of the remaining errored
fossick tool calls were the same retry-loop pattern — Claude hits an
opaque ``Error <verbing>: <stringified exception>``, can't tell what went
wrong from the message, and re-issues the identical call. The classifier's
job is to convert each httpx exception into a message that is *specific*,
*actionable*, and tells the model whether retry is even worth attempting.

These tests are pure: they fabricate ``httpx.HTTPStatusError`` instances
with the relevant status/body/headers and assert the resulting ToolError
text contains the phrases that should drive the model to take the right
next action (e.g. ``list_tags``, ``gh auth status``, "not retryable").
No network calls, no GitHub token required.
"""

import httpx
import pytest

from mcp.server.fastmcp.exceptions import ToolError

from fossick.tools._common import http_error_to_tool_error


def _status_error(
    status: int,
    *,
    body: str = "",
    headers: dict[str, str] | None = None,
) -> httpx.HTTPStatusError:
    """Build a real ``httpx.HTTPStatusError`` for the given status code.

    Real instances (rather than mocks) keep the test honest about the
    classifier's actual ``isinstance`` check and header access patterns.
    """
    request = httpx.Request("GET", "https://api.github.com/test")
    response = httpx.Response(
        status,
        request=request,
        content=body.encode(),
        headers=headers or {},
    )
    return httpx.HTTPStatusError(
        f"status {status}", request=request, response=response,
    )


# -- 401 ---------------------------------------------------------------------


def test_401_says_authentication_and_names_repo_and_tool():
    err = http_error_to_tool_error(
        _status_error(401), tool="get_file", repo="acme/widgets",
    )
    assert isinstance(err, ToolError)
    msg = str(err)
    assert "Authentication failed" in msg
    assert "acme/widgets" in msg
    assert "get_file" in msg
    # Must point at the fix, not just describe the symptom
    assert "gh auth status" in msg
    assert "Not retryable" in msg


# -- 403 ---------------------------------------------------------------------


def test_403_with_rate_limit_body_classifies_as_rate_limit():
    err = http_error_to_tool_error(
        _status_error(
            403,
            body="API rate limit exceeded for user ID 123",
            headers={"X-RateLimit-Remaining": "0", "X-RateLimit-Reset": "1700000000"},
        ),
        tool="search_code",
        query="foo bar",
    )
    msg = str(err)
    assert "rate limit" in msg.lower()
    assert "1700000000" in msg
    assert "Do not retry" in msg


def test_403_with_zero_remaining_header_classifies_as_rate_limit_even_without_body():
    err = http_error_to_tool_error(
        _status_error(403, headers={"X-RateLimit-Remaining": "0"}),
        tool="search_code",
    )
    assert "rate limit" in str(err).lower()


def test_403_rate_limit_prefers_retry_after_header_over_reset_epoch():
    """``Retry-After`` is the directly actionable number — a model can
    wait N seconds without converting from epoch. The classifier should
    prefer it when present, even though X-RateLimit-Reset is also set."""
    err = http_error_to_tool_error(
        _status_error(
            403,
            body="You have exceeded a secondary rate limit",
            headers={
                "Retry-After": "60",
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Reset": "1700000000",
            },
        ),
        tool="search_code",
    )
    msg = str(err)
    assert "60 seconds" in msg
    # Epoch must NOT appear when Retry-After is available — otherwise the
    # model gets two competing wait values and may pick the wrong one.
    assert "1700000000" not in msg


def test_403_rate_limit_falls_back_to_epoch_when_no_retry_after():
    """When ``Retry-After`` is absent (primary rate limit responses often
    omit it), fall back to the epoch from ``X-RateLimit-Reset``."""
    err = http_error_to_tool_error(
        _status_error(
            403,
            body="API rate limit exceeded",
            headers={
                "X-RateLimit-Remaining": "0",
                "X-RateLimit-Reset": "1700000000",
            },
        ),
        tool="search_code",
    )
    msg = str(err)
    assert "1700000000" in msg
    assert "seconds before retrying" not in msg


def test_403_without_rate_limit_signals_classifies_as_permission():
    err = http_error_to_tool_error(
        _status_error(403, body="Resource not accessible by integration"),
        tool="get_file",
        repo="acme/private",
    )
    msg = str(err)
    assert "Permission denied" in msg
    assert "acme/private" in msg
    assert "rate limit" not in msg.lower()


# -- 404 ---------------------------------------------------------------------


def test_404_get_file_points_at_repo_tree_and_list_tags():
    err = http_error_to_tool_error(
        _status_error(404),
        tool="get_file",
        repo="acme/widgets",
        path="src/missing.py",
        ref="main",
    )
    msg = str(err)
    assert "src/missing.py" in msg
    assert "acme/widgets" in msg
    assert "@ `main`" in msg
    # Cross-tool chain hints — the whole point of the classifier
    assert "repo_tree" in msg
    assert "list_tags" in msg


def test_404_repo_tree_with_ref_mentions_ref_and_list_tags():
    err = http_error_to_tool_error(
        _status_error(404),
        tool="repo_tree",
        repo="acme/widgets",
        ref="nonexistent-branch",
    )
    msg = str(err)
    assert "acme/widgets" in msg
    assert "nonexistent-branch" in msg
    assert "list_tags" in msg


def test_404_list_tags_says_repo_not_found():
    err = http_error_to_tool_error(
        _status_error(404),
        tool="list_tags",
        repo="acme/typo",
    )
    msg = str(err)
    assert "acme/typo" in msg
    assert "not found" in msg.lower()


def test_404_generic_tool_falls_through_to_generic_message():
    err = http_error_to_tool_error(
        _status_error(404), tool="search_repos",
    )
    msg = str(err)
    assert "search_repos" in msg
    assert "not found" in msg.lower()


def test_404_get_file_without_path_falls_through_to_generic():
    """The tool-specific branch requires a `path` to give targeted advice;
    without one we should still produce *some* useful 404 message rather
    than crashing or returning an empty string."""
    err = http_error_to_tool_error(
        _status_error(404), tool="get_file", repo="acme/widgets",
    )
    msg = str(err)
    assert "get_file" in msg
    assert "acme/widgets" in msg
    assert "not found" in msg.lower()


# -- 422 ---------------------------------------------------------------------


def test_422_search_code_calls_out_missing_content_term():
    """The most common search_code 422 in the wild is "query made entirely
    of qualifiers" — e.g. ``repo:foo/bar`` with no actual search terms.
    The classifier must call this out specifically since it's a different
    fix than "fix your special characters"."""
    err = http_error_to_tool_error(
        _status_error(422),
        tool="search_code",
        query="repo:foo/bar",
    )
    msg = str(err)
    assert "search_code" in msg
    assert "repo:foo/bar" in msg
    assert "content term" in msg
    assert "Adjust the query" in msg


def test_422_generic_tool_falls_through_without_search_code_specific_hint():
    """For other search tools, the generic 422 advice still applies — no
    'content term' wording (which would be search_code-specific) but
    still echoes the query and tells the model to fix it."""
    err = http_error_to_tool_error(
        _status_error(422),
        tool="search_repos",
        query="foo AND repo:",
    )
    msg = str(err)
    assert "search_repos" in msg
    assert "foo AND repo:" in msg
    assert "rejected" in msg.lower()
    assert "Adjust the query" in msg
    assert "content term" not in msg


# -- 5xx ---------------------------------------------------------------------


@pytest.mark.parametrize("status", [500, 502, 503, 599])
def test_5xx_boundary_classified_as_upstream_transient(status):
    """Guard the ``500 <= status < 600`` range — a regression to ``<=``
    or ``<`` would silently move 500 or 599 into the catch-all snippet
    branch."""
    err = http_error_to_tool_error(
        _status_error(status), tool="search_code",
    )
    msg = str(err)
    assert str(status) in msg
    assert "transient" in msg.lower()
    assert "tight loop" in msg


# -- unhandled HTTP statuses -------------------------------------------------


def test_unhandled_status_falls_through_with_snippet():
    """Statuses we don't classify (e.g. 409 Conflict) must still surface
    the body so the model isn't blind to what GitHub said."""
    err = http_error_to_tool_error(
        _status_error(409, body="Conflict: branch already exists"),
        tool="get_file",
    )
    msg = str(err)
    assert "409" in msg
    assert "get_file" in msg
    assert "Conflict: branch already exists" in msg


def test_unhandled_status_truncates_body_at_200_chars():
    """Long error bodies (e.g. an entire HTML error page) must not flood
    the model context — the helper truncates at 200 characters."""
    long_body = "x" * 1000
    err = http_error_to_tool_error(
        _status_error(418, body=long_body), tool="search_code",
    )
    msg = str(err)
    # The 200-char window should be present, but not all 1000
    assert "x" * 200 in msg
    assert "x" * 201 not in msg


# -- network errors ----------------------------------------------------------


@pytest.mark.parametrize(
    "exc_factory",
    [
        lambda req: httpx.ConnectError("connection refused", request=req),
        lambda req: httpx.ReadTimeout("read timed out", request=req),
        lambda req: httpx.PoolTimeout("pool timed out", request=req),
    ],
    ids=["ConnectError", "ReadTimeout", "PoolTimeout"],
)
def test_request_error_subclasses_classified_as_network_error(exc_factory):
    """All ``httpx.RequestError`` subclasses we expect from real GitHub
    calls should hit the network-error branch — these are the actual
    failure modes the original error scan flagged as needing this fix."""
    request = httpx.Request("GET", "https://api.github.com/test")
    err = http_error_to_tool_error(
        exc_factory(request), tool="get_file", repo="acme/widgets",
    )
    msg = str(err)
    assert "Network error" in msg
    assert "get_file" in msg
    assert "transient" in msg.lower()


# -- passthroughs ------------------------------------------------------------


def test_existing_tool_error_passes_through_unchanged():
    """A ToolError raised inside a tool's try block (e.g. from split_repo
    in some future refactor) must not be re-wrapped — its message is
    already actionable."""
    original = ToolError("invalid `repo` value: 'foo'. Expected 'owner/name'")
    returned = http_error_to_tool_error(original, tool="get_file")
    assert returned is original


def test_unknown_exception_preserves_repr_and_does_not_swallow():
    """Silent failure check: an unexpected exception type must surface
    enough info to debug, not vanish behind a generic message."""
    err = http_error_to_tool_error(
        ValueError("totally unexpected"),
        tool="get_file",
        repo="acme/widgets",
    )
    msg = str(err)
    assert "Unexpected error" in msg
    assert "get_file" in msg
    assert "acme/widgets" in msg
    assert "ValueError" in msg
    assert "totally unexpected" in msg


# -- formatting sanity -------------------------------------------------------


@pytest.mark.parametrize("status", [401, 403, 404, 422, 500])
def test_message_always_names_the_tool(status):
    err = http_error_to_tool_error(
        _status_error(status), tool="my_tool", repo="o/r",
    )
    assert "my_tool" in str(err)


@pytest.mark.parametrize("status", [401, 403, 404])
def test_empty_repo_uses_generic_resource_label(status):
    """When a tool can't supply a repo (e.g. ``search_repos``), the message
    must still be grammatical — no stray empty backticks like ``\\`\\```."""
    err = http_error_to_tool_error(
        _status_error(status), tool="search_repos",
    )
    msg = str(err)
    # Either the generic phrase appears, or at minimum no empty `repo` label
    assert "the requested resource" in msg or "search_repos" in msg
    assert "``" not in msg  # no empty backtick pair from ``f"`{repo}`"`` with empty repo
