"""Unit tests for search_repos multi-query merge and ranking.

Why this exists: `in:description` is a sharp filter but has a narrow
aperture — different repos describe themselves with different wording
and a single phrasing routinely misses popular options. The canonical
example from the session this was built in: searching
`in:description "Postgres operator"` surfaces Zalando's postgres-operator
(5k★) but completely misses CloudNativePG (8k★), which describes
itself as "Kubernetes-native PostgreSQL."

The multi-query mode in search_repos runs N phrasings in parallel,
merges by repo name, dedupes, and ranks by (match-count, stars). A
repo found by *every* phrasing is high-confidence; a repo found by
only one phrasing is a phrase-fragile find that would have been lost
without the merge. Both need to be surfaced correctly, and the order
has to be deterministic.

These tests exercise the pure `_merge_subquery_results` helper
(no network, no async) with fabricated sub-result dicts shaped like
GitHub Search API responses. The rendered-output annotations
(`matched K/N`, `Found via:`) are tested via the `_format_repo`
helper separately so single-query mode and multi-query mode stay
behaviorally distinct.
"""

import pytest

from fossick.tools.search_repos import (
    _build_full_query,
    _compute_relevance_score,
    _extract_query_terms,
    _format_repo,
    _has_qualifier,
    _merge_subquery_results,
    _partition_by_tier,
    _phrase_fragile_alerts,
    _rerank_by_relevance,
)


def _repo(
    name: str,
    *,
    stars: int = 0,
    description: str = "",
    topics: list[str] | None = None,
    pushed: str = "2026-04-01T00:00:00Z",
    archived: bool = False,
    license_id: str | None = None,
    homepage: str = "",
    language: str = "Python",
) -> dict:
    """Fabricate a GitHub repo-search item matching the real API shape."""
    return {
        "full_name": name,
        "stargazers_count": stars,
        "description": description,
        "topics": topics or [],
        "pushed_at": pushed,
        "archived": archived,
        "license": ({"spdx_id": license_id} if license_id else None),
        "homepage": homepage,
        "language": language,
    }


def _sub(*items: dict) -> dict:
    """Wrap a list of items in the {items, total_count} envelope."""
    return {"items": list(items), "total_count": len(items)}


# -- merge happy paths: dedup, order, match tracking ------------------------


def test_single_query_returns_items_in_input_order_tied_by_stars():
    sub = _sub(
        _repo("a/one", stars=100),
        _repo("b/two", stars=300),
        _repo("c/three", stars=200),
    )
    ranked = _merge_subquery_results(["q1"], [sub])
    # Match-count is 1 for all three (single phrasing), so stars break
    # ties — descending.
    names = [e["item"]["full_name"] for e in ranked]
    assert names == ["b/two", "c/three", "a/one"]


def test_multi_query_dedupes_by_full_name():
    # A repo appearing in two sub-results should collapse to one entry.
    sub1 = _sub(_repo("shared/repo", stars=500))
    sub2 = _sub(_repo("shared/repo", stars=500))
    ranked = _merge_subquery_results(["q1", "q2"], [sub1, sub2])
    assert len(ranked) == 1
    assert ranked[0]["item"]["full_name"] == "shared/repo"
    # And both phrasings are recorded as having matched it.
    assert ranked[0]["matched_by"] == ["q1", "q2"]


def test_multi_query_ranks_match_count_above_stars():
    # The whole point of the merge: a repo matched by 2/2 phrasings
    # must rank above a repo matched by only 1/2 even if the latter
    # has more stars. Match count is the robustness signal.
    sub1 = _sub(
        _repo("unique/gem", stars=10_000),  # only in sub1
        _repo("shared/robust", stars=100),  # in both subs
    )
    sub2 = _sub(
        _repo("shared/robust", stars=100),
    )
    ranked = _merge_subquery_results(["q1", "q2"], [sub1, sub2])
    names = [e["item"]["full_name"] for e in ranked]
    # shared/robust matched 2/2 → ranks above unique/gem matched 1/2
    # despite the 100x star gap.
    assert names == ["shared/robust", "unique/gem"]


def test_multi_query_stars_break_ties_within_match_count():
    # Two repos with the same match count (1/2) rank by stars.
    sub1 = _sub(
        _repo("lo-star/repo", stars=100),
        _repo("hi-star/repo", stars=5_000),
    )
    sub2 = _sub()  # empty — neither matches here
    ranked = _merge_subquery_results(["q1", "q2"], [sub1, sub2])
    names = [e["item"]["full_name"] for e in ranked]
    assert names == ["hi-star/repo", "lo-star/repo"]


def test_matched_by_records_first_seen_order():
    # If a repo appears in queries q1, q2, q3 the matched_by list
    # should preserve that order so the `Found via:` annotation is
    # deterministic.
    name = "order/matters"
    subs = [_sub(_repo(name)), _sub(_repo(name)), _sub(_repo(name))]
    ranked = _merge_subquery_results(["q1", "q2", "q3"], subs)
    assert len(ranked) == 1
    assert ranked[0]["matched_by"] == ["q1", "q2", "q3"]


def test_matched_by_respects_partial_coverage():
    # Repo appears only in q1 and q3, not q2 — the matched_by list
    # should have exactly those two, in that order.
    name = "partial/coverage"
    sub1 = _sub(_repo(name))
    sub2 = _sub()
    sub3 = _sub(_repo(name))
    ranked = _merge_subquery_results(
        ["q1", "q2", "q3"], [sub1, sub2, sub3]
    )
    assert ranked[0]["matched_by"] == ["q1", "q3"]


def test_duplicate_item_within_one_subquery_does_not_double_count():
    # Defensive: if GitHub somehow returns the same repo twice in one
    # sub-result (or the same label is repeated), match_count should
    # still be 1 for that phrasing, not 2.
    sub1 = _sub(_repo("dup/repo"), _repo("dup/repo"))
    ranked = _merge_subquery_results(["q1"], [sub1])
    assert len(ranked) == 1
    assert ranked[0]["matched_by"] == ["q1"]


def test_empty_label_fallback_does_not_populate_matched_by():
    # The default-query fallback path passes an empty-string label —
    # that shouldn't show up in matched_by (or the `Found via:` line
    # would have an empty quoted string, which is ugly).
    sub1 = _sub(_repo("fallback/only"))
    ranked = _merge_subquery_results([""], [sub1])
    assert ranked[0]["matched_by"] == []


def test_item_missing_full_name_is_dropped():
    # A GitHub response item without full_name can't be merged by key,
    # so we drop it rather than crash.
    broken = {"stargazers_count": 100}  # no full_name
    good = _repo("valid/repo", stars=50)
    sub1 = _sub(broken, good)
    ranked = _merge_subquery_results(["q1"], [sub1])
    names = [e["item"]["full_name"] for e in ranked]
    assert names == ["valid/repo"]


def test_empty_inputs_yield_empty_ranking():
    assert _merge_subquery_results([], []) == []
    assert _merge_subquery_results(["q1"], [_sub()]) == []


# -- _format_repo: per-result output annotations ----------------------------


def test_format_repo_single_query_mode_has_no_match_annotation():
    # In single-query mode the `matched K/N` suffix must not appear
    # on the header and there must be no `Found via:` line — that
    # annotation is exclusive to multi-query mode.
    lines: list[str] = []
    _format_repo(
        _repo("cloudnative-pg/cloudnative-pg", stars=8400),
        lines,
    )
    block = "\n".join(lines)
    assert "matched" not in block
    assert "Found via" not in block


def test_format_repo_multi_query_mode_annotates_match_count_and_found_via():
    lines: list[str] = []
    _format_repo(
        _repo("cloudnative-pg/cloudnative-pg", stars=8400),
        lines,
        matched_by=["in:description X", "topic:postgres-operator"],
        total_queries=3,
    )
    block = "\n".join(lines)
    # Match annotation lands on the header and uses K/N form.
    assert "matched 2/3" in block
    # Found-via line names the exact phrasings.
    assert 'Found via: "in:description X", "topic:postgres-operator"' in block


def test_format_repo_surfaces_full_description_topics_license_homepage():
    lines: list[str] = []
    _format_repo(
        _repo(
            "example/repo",
            stars=1000,
            description="A full multi-sentence description that used to be truncated.",
            topics=["kubernetes", "operator", "postgres"],
            license_id="Apache-2.0",
            homepage="https://example.com",
            pushed="2026-04-10T12:00:00Z",
        ),
        lines,
    )
    block = "\n".join(lines)
    assert "A full multi-sentence description that used to be truncated." in block
    assert "Topics: kubernetes, operator, postgres" in block
    assert "License: Apache-2.0" in block
    assert "Homepage: https://example.com" in block
    assert "pushed 2026-04-10" in block


def test_format_repo_suppresses_noassertion_license():
    # GitHub returns {"spdx_id": "NOASSERTION"} when it can't detect a
    # license — that's noise, not signal. Must not appear in output.
    lines: list[str] = []
    _format_repo(
        _repo(
            "example/repo",
            stars=10,
            license_id="NOASSERTION",
        ),
        lines,
    )
    block = "\n".join(lines)
    assert "NOASSERTION" not in block
    assert "License" not in block


def test_format_repo_surfaces_archived_marker():
    lines: list[str] = []
    _format_repo(
        _repo("deprecated/tool", stars=500, archived=True),
        lines,
    )
    block = "\n".join(lines)
    # The archived marker is the "don't pick this for production"
    # signal — it must be visible on the header.
    assert "archived" in block


# -- hint rule: multi-query nudge fires in single-query mode only -----------


def test_single_query_mode_nudges_toward_multi_query():
    from fossick.hints import generate_hints

    hints = generate_hints(
        "search_repos",
        params={"num_queries": 1},
        result={"total_count": 25},
    )
    # Top hint should be the multi-query nudge — that's the blind-spot
    # correction this whole feature exists for.
    assert any("queries=" in h for h in hints), (
        f"expected the multi-query nudge hint in single-query mode, "
        f"got: {hints}"
    )


def test_multi_query_mode_does_not_nudge():
    from fossick.hints import generate_hints

    hints = generate_hints(
        "search_repos",
        params={"num_queries": 3},
        result={"total_count": 25},
    )
    # In multi-query mode the caller already did the right thing —
    # don't nag them.
    assert not any("queries=" in h for h in hints), (
        f"expected NO multi-query nudge in multi-query mode, "
        f"got: {hints}"
    )
    # But the other search_repos hints should still fire.
    assert any("repo_tree" in h for h in hints)


def test_zero_result_single_query_does_not_nudge():
    from fossick.hints import generate_hints

    # No results → no hints at all, not even the nudge. A nudge on an
    # empty result list is confusing — if nothing was found, the
    # problem is query shape, not phrasing count.
    hints = generate_hints(
        "search_repos",
        params={"num_queries": 1},
        result={"total_count": 0},
    )
    assert hints == []


# -- fork filter: auto-append fork:false unless caller specified ------------


def test_has_qualifier_detects_plain_token():
    assert _has_qualifier("foo fork:false", "fork") is True
    assert _has_qualifier("foo bar", "fork") is False


def test_has_qualifier_is_case_insensitive():
    assert _has_qualifier("Fork:true", "fork") is True
    assert _has_qualifier("FORK:only", "fork") is True


def test_has_qualifier_ignores_qualifier_inside_quotes():
    # A quoted substring containing `fork:` is literal content, not
    # a qualifier — the validator already teaches this behavior on
    # the input side, the fork-filter helper mirrors it.
    assert _has_qualifier('foo "fork:true is a common example"', "fork") is False


def test_has_qualifier_ignores_qualifier_inside_regex_literal():
    assert _has_qualifier("/fork:\\w+/", "fork") is False


def test_has_qualifier_detects_negation_prefix():
    # `-fork:true` is still a fork qualifier; don't override it.
    assert _has_qualifier("foo -fork:true", "fork") is True


def test_has_qualifier_does_not_false_match_substring():
    # A word that happens to end in "fork" (like "pitchfork:") must
    # not trip the fork detector.
    assert _has_qualifier("pitchfork:handle", "fork") is False


def test_build_full_query_auto_appends_fork_false():
    # The canonical fix — GitHub search includes forks by default,
    # which pollutes discovery shortlists with zero-star clones. The
    # builder appends `fork:false` when the caller hasn't specified
    # a preference.
    assembled = _build_full_query(
        "topic:mcp", topic="", language="python", trending=False,
    )
    assert "fork:false" in assembled
    assert "topic:mcp" in assembled
    assert "language:python" in assembled


def test_build_full_query_preserves_caller_fork_preference():
    # If the caller explicitly wants forks (e.g. researching a
    # popular repo's ecosystem), don't override their choice.
    assembled = _build_full_query(
        "topic:mcp fork:only", topic="", language="", trending=False,
    )
    assert "fork:only" in assembled
    assert "fork:false" not in assembled


def test_build_full_query_preserves_fork_true():
    assembled = _build_full_query(
        "topic:mcp fork:true", topic="", language="", trending=False,
    )
    assert "fork:true" in assembled
    assert "fork:false" not in assembled


def test_build_full_query_default_fallback_drops_stars_floor():
    # The old fallback was `stars:>1000`, which was actively hostile
    # to gem-finding: it hid every small-but-quality repo from
    # dev-session discovery. The new default falls back to
    # `is:public` and relies on client-side relevance ranking to
    # surface the useful results.
    assembled = _build_full_query(
        "", topic="", language="", trending=False,
    )
    assert "stars:>1000" not in assembled
    assert "is:public" in assembled
    assert "fork:false" in assembled


# -- tier partitioning ------------------------------------------------------


def test_partition_by_tier_three_queries():
    # Three queries produces three distinct tiers by match count.
    ranked = [
        {"item": _repo("all/three", stars=1000), "matched_by": ["a", "b", "c"]},
        {"item": _repo("two/three", stars=800), "matched_by": ["a", "b"]},
        {"item": _repo("one/three", stars=5000), "matched_by": ["b"]},
    ]
    robust, majority, fragile = _partition_by_tier(ranked, num_queries=3)
    assert [e["item"]["full_name"] for e in robust] == ["all/three"]
    assert [e["item"]["full_name"] for e in majority] == ["two/three"]
    assert [e["item"]["full_name"] for e in fragile] == ["one/three"]


def test_partition_by_tier_two_queries_has_no_majority():
    # N=2 has no valid "majority" band (1 < k < 2 has no integer),
    # so a 2-query run produces robust (2/2) and fragile (1/2) only.
    ranked = [
        {"item": _repo("both/match", stars=100), "matched_by": ["a", "b"]},
        {"item": _repo("one/match", stars=500), "matched_by": ["a"]},
    ]
    robust, majority, fragile = _partition_by_tier(ranked, num_queries=2)
    assert len(robust) == 1
    assert majority == []
    assert len(fragile) == 1


def test_partition_preserves_input_order_within_tier():
    # The merge helper emits a flat list sorted by (match_count desc,
    # stars desc). Partition must preserve that within-tier order so
    # the fragile tier is already stars-desc by inheritance.
    ranked = [
        {"item": _repo("fragile/high", stars=8000), "matched_by": ["a"]},
        {"item": _repo("fragile/mid", stars=300), "matched_by": ["a"]},
        {"item": _repo("fragile/low", stars=10), "matched_by": ["a"]},
    ]
    _robust, _majority, fragile = _partition_by_tier(ranked, num_queries=3)
    names = [e["item"]["full_name"] for e in fragile]
    assert names == ["fragile/high", "fragile/mid", "fragile/low"]


def test_partition_empty_input_yields_empty_tiers():
    robust, majority, fragile = _partition_by_tier([], num_queries=3)
    assert robust == [] and majority == [] and fragile == []


# -- phrase-fragile alert (top-N by incoming order) -------------------------


def test_phrase_fragile_alerts_returns_top_n_in_input_order():
    # The caller is responsible for sorting `fragile` into the
    # desired order (relevance score descending in the real tool).
    # The alert helper trusts the incoming order and returns the
    # first `cap` entries — it is NOT a re-sort.
    fragile = [
        {"item": _repo("top/one", stars=100), "matched_by": ["q1"]},
        {"item": _repo("top/two", stars=200), "matched_by": ["q2"]},
        {"item": _repo("top/three", stars=50), "matched_by": ["q1"]},
        {"item": _repo("top/four", stars=1000), "matched_by": ["q2"]},
    ]
    alerts = _phrase_fragile_alerts(fragile)
    names = [e["item"]["full_name"] for e in alerts]
    # Default cap is 3; order matches input order regardless of stars.
    assert names == ["top/one", "top/two", "top/three"]


def test_phrase_fragile_alerts_caps_at_default_3():
    # The whole point of the cap: alerts longer than a few entries
    # stop being salience signals and become noise. The live Rust TUI
    # stress test produced a 19-entry alert under the old logic; the
    # cap enforces that never happening again.
    fragile = [
        {"item": _repo(f"fragile/{i}", stars=i * 10), "matched_by": ["q1"]}
        for i in range(10)
    ]
    alerts = _phrase_fragile_alerts(fragile)
    assert len(alerts) == 3


def test_phrase_fragile_alerts_respects_custom_cap():
    fragile = [
        {"item": _repo(f"fragile/{i}", stars=100), "matched_by": ["q1"]}
        for i in range(10)
    ]
    assert len(_phrase_fragile_alerts(fragile, cap=5)) == 5
    assert len(_phrase_fragile_alerts(fragile, cap=0)) == 0


def test_phrase_fragile_alerts_empty_returns_empty():
    assert _phrase_fragile_alerts([]) == []


def test_phrase_fragile_alerts_fewer_than_cap_returns_all():
    # With only 2 entries and the default cap of 3, the function
    # returns both — it doesn't pad or fail.
    fragile = [
        {"item": _repo("only/one", stars=100), "matched_by": ["q1"]},
        {"item": _repo("only/two", stars=200), "matched_by": ["q2"]},
    ]
    alerts = _phrase_fragile_alerts(fragile)
    assert len(alerts) == 2


# -- query-term extraction for relevance scoring ----------------------------


def test_extract_query_terms_pulls_content_from_quoted_phrases():
    # The canonical case from the rank-experiment benchmark: a
    # quoted-phrase `in:description "Postgres operator"` should
    # yield "postgres" and "operator" as extracted terms.
    terms = _extract_query_terms(['in:description "Postgres operator"'])
    assert "postgres" in terms
    assert "operator" in terms
    # The `in:` prefix value is "description" — a stopword we want
    # to drop so it doesn't contaminate scoring.
    assert "description" not in terms


def test_extract_query_terms_handles_topic_qualifier_slugs():
    # Topic slugs are hyphenated; extraction should yield both the
    # full slug and each component part so queries like
    # `topic:postgres-operator` contribute "postgres", "operator",
    # AND "postgres-operator" to the match set.
    terms = _extract_query_terms(["topic:postgres-operator"])
    assert "postgres-operator" in terms
    assert "postgres" in terms
    assert "operator" in terms


def test_extract_query_terms_drops_non_term_qualifiers():
    # Qualifiers like stars:, fork:, pushed: are filter values,
    # not content words. They must not leak into the term set.
    terms = _extract_query_terms([
        "foo stars:>1000 fork:false pushed:>2025-01-01",
    ])
    assert "foo" in terms
    assert "stars" not in terms
    assert "fork" not in terms
    assert "pushed" not in terms
    assert "false" not in terms  # fork value is filtered too


def test_extract_query_terms_unions_across_sub_queries():
    # Multi-query mode passes 2-4 phrasings; the term set should be
    # the union of every phrasing's content words so relevance
    # scoring can reward matches against any of them.
    terms = _extract_query_terms([
        'in:description "agent framework" language:rust',
        'in:description "LLM agent"',
        "topic:ai-agents",
    ])
    assert "agent" in terms
    assert "framework" in terms
    assert "llm" in terms
    assert "rust" in terms
    assert "ai-agents" in terms
    assert "agents" in terms  # from "ai-agents" slug split


def test_extract_query_terms_applies_convenience_params():
    # The `language` and `topic` convenience params are appended as
    # qualifiers in the real tool, but they also carry literal
    # relevance signal ("the caller cares about Rust") and should
    # end up in the term set.
    terms = _extract_query_terms(
        ["some query"],
        language="rust",
        topic="ratatui",
    )
    assert "rust" in terms
    assert "ratatui" in terms
    assert "some" in terms
    assert "query" in terms


def test_extract_query_terms_strips_stopwords_and_short_tokens():
    terms = _extract_query_terms(['the a of in "postgres"'])
    # "postgres" should survive; glue words should not.
    assert "postgres" in terms
    for stop in {"the", "a", "of", "in"}:
        assert stop not in terms


def test_extract_query_terms_ignores_empty_and_digit_tokens():
    terms = _extract_query_terms(["foo 2025 42 bar"])
    assert "foo" in terms
    assert "bar" in terms
    assert "2025" not in terms
    assert "42" not in terms


# -- relevance score: per-signal contribution -------------------------------


def _entry_for(item: dict, matched_by: list[str] | None = None):
    return {"item": item, "matched_by": matched_by or ["q1"]}


def test_relevance_score_description_hit_contributes_three_per_term():
    # Two description terms should produce a 6-point bump from
    # description signal alone (weight is 3 per hit). We pick a
    # non-recent pushed date and zero stars to isolate the
    # description contribution.
    entry = _entry_for(_repo(
        "foo/bar",
        description="agent harness for rust",
        pushed="2020-01-01T00:00:00Z",
        stars=0,
    ))
    terms = {"agent", "harness"}
    # desc × 3 = 6; topics × 2 = 0; match_count × 2 = 2; recency = 0;
    # stars = 0.5 × log10(1) = 0 → total 8
    assert _compute_relevance_score(entry, terms) == pytest.approx(8.0)


def test_relevance_score_topic_hits_contribute_two_per_term():
    entry = _entry_for(_repo(
        "foo/bar",
        description="",
        topics=["rust", "harness"],
        pushed="2020-01-01T00:00:00Z",
        stars=0,
    ))
    terms = {"rust", "harness"}
    # desc × 3 = 0; topics × 2 = 4; match_count × 2 = 2; recency = 0
    # → 6
    assert _compute_relevance_score(entry, terms) == pytest.approx(6.0)


def test_relevance_score_stars_enter_at_half_log_weight():
    # The Claude-Code-CLI fix depends on stars being a WEAK
    # tiebreak, not a primary signal. Verify the math: a 10k-star
    # repo should contribute 0.5 × log10(10001) ≈ 2.0 to the score.
    entry = _entry_for(_repo(
        "foo/bar",
        description="",
        pushed="2020-01-01T00:00:00Z",
        stars=10_000,
    ))
    # desc=0, topics=0, match_count × 2 = 2, recency=0, stars ~= 2.0
    score = _compute_relevance_score(entry, set())
    assert score == pytest.approx(4.0, abs=0.05)


def test_relevance_score_match_count_rewarded_at_two_each():
    entry = _entry_for(
        _repo("foo/bar", description="", pushed="2020-01-01T00:00:00Z", stars=0),
        matched_by=["q1", "q2", "q3"],
    )
    # matches=3 × 2 = 6
    assert _compute_relevance_score(entry, set()) == pytest.approx(6.0)


def test_relevance_score_literal_match_beats_stars():
    # The canonical failure the new scoring exists to fix: a small
    # repo with a literal description match must outrank a huge
    # repo with none of the query terms.
    meerkat = _entry_for(_repo(
        "lukacf/meerkat",
        description="Meerkat - A modular, high-performance agent harness built in Rust",
        topics=["rust", "harness", "agentic"],
        stars=5,
        pushed="2026-04-11T00:00:00Z",
    ))
    goose = _entry_for(_repo(
        "aaif-goose/goose",
        description="an open source, extensible AI agent that goes beyond code suggestions",
        topics=["ai", "ai-agents"],
        stars=41_000,
        pushed="2026-04-11T00:00:00Z",
    ))
    terms = {"rust", "agent", "harness"}
    meerkat_score = _compute_relevance_score(meerkat, terms)
    goose_score = _compute_relevance_score(goose, terms)
    # The whole point of the redesign. meerkat MUST outrank goose
    # for the query "Rust agent harness" — goose's 41k star bonus
    # must not overwhelm meerkat's description match.
    assert meerkat_score > goose_score, (
        f"meerkat ({meerkat_score:.2f}) should outrank "
        f"goose ({goose_score:.2f})"
    )


def test_relevance_score_recency_bonus_applied():
    from datetime import datetime, timedelta, timezone
    recent = datetime.now(timezone.utc) - timedelta(days=5)
    stale = datetime.now(timezone.utc) - timedelta(days=400)
    fresh_entry = _entry_for(_repo(
        "foo/fresh", pushed=recent.isoformat(), stars=0,
    ))
    stale_entry = _entry_for(_repo(
        "foo/stale", pushed=stale.isoformat(), stars=0,
    ))
    # Same everything except recency; fresh should score 3 higher.
    delta = (
        _compute_relevance_score(fresh_entry, set())
        - _compute_relevance_score(stale_entry, set())
    )
    assert delta == pytest.approx(3.0)


# -- rerank by relevance ----------------------------------------------------


def test_rerank_by_relevance_reorders_literal_match_above_star_giant():
    # End-to-end integration of the rerank function: given a flat
    # merged list where a small literal match is buried below a big
    # off-topic repo, the rerank should surface the literal match.
    merged = [
        _entry_for(_repo(
            "aaif-goose/goose",
            description="open source AI agent extensible",
            topics=["ai", "agents"],
            stars=41_000,
            pushed="2026-04-11T00:00:00Z",
        )),
        _entry_for(_repo(
            "lukacf/meerkat",
            description="modular high-performance agent harness built in Rust",
            topics=["rust", "harness", "agentic"],
            stars=5,
            pushed="2026-04-11T00:00:00Z",
        )),
    ]
    terms = {"rust", "agent", "harness"}
    ranked = _rerank_by_relevance(merged, terms)
    assert ranked[0]["item"]["full_name"] == "lukacf/meerkat"
    assert ranked[1]["item"]["full_name"] == "aaif-goose/goose"


def test_rerank_by_relevance_empty_terms_passes_through():
    # When the caller has no extractable query terms (e.g., the
    # default fallback query path), the rerank must NOT destroy
    # the incoming match_count-based order.
    original = [
        _entry_for(_repo("a/first", stars=100), matched_by=["q1", "q2"]),
        _entry_for(_repo("b/second", stars=1000), matched_by=["q1"]),
    ]
    ranked = _rerank_by_relevance(original, set())
    assert ranked == original


def test_rerank_by_relevance_stable_tiebreak():
    # Two entries with identical score components should preserve
    # their incoming order (stable sort). This is what gives the
    # merge's match_count ordering a second-level role as tiebreak.
    a = _entry_for(_repo("a/one", description="rust agent", stars=100))
    b = _entry_for(_repo("b/two", description="rust agent", stars=100))
    ranked = _rerank_by_relevance([a, b], {"rust", "agent"})
    assert ranked[0]["item"]["full_name"] == "a/one"
    assert ranked[1]["item"]["full_name"] == "b/two"
