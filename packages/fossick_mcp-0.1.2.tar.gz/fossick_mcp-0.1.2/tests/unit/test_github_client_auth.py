"""Unit tests for fossick.github_client._resolve_token.

Covers the token resolution precedence:
  GH_TOKEN > GITHUB_TOKEN > GITHUB_PERSONAL_ACCESS_TOKEN > `gh auth token`
"""

import subprocess
from types import SimpleNamespace

import pytest

from fossick import github_client
from fossick.github_client import _resolve_token

TOKEN_ENV_VARS = ("GH_TOKEN", "GITHUB_TOKEN", "GITHUB_PERSONAL_ACCESS_TOKEN")


@pytest.fixture(autouse=True)
def _clear_token_env(monkeypatch):
    """Ensure tests start with no token env vars set."""
    for var in TOKEN_ENV_VARS:
        monkeypatch.delenv(var, raising=False)


@pytest.fixture
def _no_gh_cli(monkeypatch):
    """Force the `gh` CLI fallback to fail by pretending it isn't installed."""
    monkeypatch.setattr(github_client.shutil, "which", lambda _: None)


# -- env var precedence ------------------------------------------------------


def test_gh_token_wins(monkeypatch, _no_gh_cli):
    monkeypatch.setenv("GH_TOKEN", "from-gh")
    monkeypatch.setenv("GITHUB_TOKEN", "from-github")
    monkeypatch.setenv("GITHUB_PERSONAL_ACCESS_TOKEN", "from-pat")
    assert _resolve_token() == "from-gh"


def test_github_token_used_when_gh_token_absent(monkeypatch, _no_gh_cli):
    monkeypatch.setenv("GITHUB_TOKEN", "from-github")
    monkeypatch.setenv("GITHUB_PERSONAL_ACCESS_TOKEN", "from-pat")
    assert _resolve_token() == "from-github"


def test_pat_used_when_others_absent(monkeypatch, _no_gh_cli):
    monkeypatch.setenv("GITHUB_PERSONAL_ACCESS_TOKEN", "from-pat")
    assert _resolve_token() == "from-pat"


def test_empty_env_var_is_skipped(monkeypatch, _no_gh_cli):
    monkeypatch.setenv("GH_TOKEN", "")
    monkeypatch.setenv("GITHUB_TOKEN", "from-github")
    assert _resolve_token() == "from-github"


def test_whitespace_only_env_var_is_skipped(monkeypatch, _no_gh_cli):
    monkeypatch.setenv("GH_TOKEN", "   ")
    monkeypatch.setenv("GITHUB_TOKEN", "from-github")
    assert _resolve_token() == "from-github"


def test_env_var_whitespace_is_stripped(monkeypatch, _no_gh_cli):
    monkeypatch.setenv("GH_TOKEN", "  from-gh\n")
    assert _resolve_token() == "from-gh"


# -- `gh auth token` fallback ------------------------------------------------


def test_gh_cli_fallback_used_when_no_env_vars(monkeypatch):
    monkeypatch.setattr(github_client.shutil, "which", lambda _: "/usr/bin/gh")
    monkeypatch.setattr(
        github_client.subprocess,
        "run",
        lambda *a, **kw: SimpleNamespace(returncode=0, stdout="from-gh-cli\n"),
    )
    assert _resolve_token() == "from-gh-cli"


def test_gh_cli_fallback_not_used_when_env_var_present(monkeypatch):
    called = {"ran": False}

    def _fake_run(*a, **kw):
        called["ran"] = True
        return SimpleNamespace(returncode=0, stdout="from-gh-cli\n")

    monkeypatch.setattr(github_client.shutil, "which", lambda _: "/usr/bin/gh")
    monkeypatch.setattr(github_client.subprocess, "run", _fake_run)
    monkeypatch.setenv("GH_TOKEN", "from-env")

    assert _resolve_token() == "from-env"
    assert called["ran"] is False, "subprocess should not run when env var present"


def test_gh_cli_not_installed_returns_empty(monkeypatch, _no_gh_cli):
    assert _resolve_token() == ""


def test_gh_cli_nonzero_exit_returns_empty(monkeypatch):
    monkeypatch.setattr(github_client.shutil, "which", lambda _: "/usr/bin/gh")
    monkeypatch.setattr(
        github_client.subprocess,
        "run",
        lambda *a, **kw: SimpleNamespace(returncode=1, stdout=""),
    )
    assert _resolve_token() == ""


def test_gh_cli_empty_stdout_returns_empty(monkeypatch):
    monkeypatch.setattr(github_client.shutil, "which", lambda _: "/usr/bin/gh")
    monkeypatch.setattr(
        github_client.subprocess,
        "run",
        lambda *a, **kw: SimpleNamespace(returncode=0, stdout="  \n"),
    )
    assert _resolve_token() == ""


def test_gh_cli_timeout_returns_empty(monkeypatch):
    def _timeout(*a, **kw):
        raise subprocess.TimeoutExpired(cmd="gh", timeout=5)

    monkeypatch.setattr(github_client.shutil, "which", lambda _: "/usr/bin/gh")
    monkeypatch.setattr(github_client.subprocess, "run", _timeout)
    assert _resolve_token() == ""


def test_gh_cli_oserror_returns_empty(monkeypatch):
    def _oserror(*a, **kw):
        raise OSError("boom")

    monkeypatch.setattr(github_client.shutil, "which", lambda _: "/usr/bin/gh")
    monkeypatch.setattr(github_client.subprocess, "run", _oserror)
    assert _resolve_token() == ""
