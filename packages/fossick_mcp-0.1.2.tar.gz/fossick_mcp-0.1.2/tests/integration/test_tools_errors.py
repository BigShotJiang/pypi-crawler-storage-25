"""Layer C-error: live integration tests that force real GitHub error paths.

These tests prove the HTTP error classifier (``http_error_to_tool_error``
in ``src/fossick/tools/_common.py``) is wired correctly end-to-end:

  1. The error propagates through ``mcp.call_tool`` (FastMCP wraps any
     ``ToolError`` raised inside a tool as ``"Error executing tool X: ..."``,
     so the classifier message is embedded in the outer exception text).
  2. Each tool actually passes its context (``repo``, ``path``, ``ref``,
     ``base``, ``head``) into the helper — a unit test on the helper alone
     can't catch a tool that forgets a kwarg, since the helper only sees
     what's passed to it.
  3. GitHub's real 404 responses match the shape the unit tests fake.

Coverage scope: only the 404 branches with tool-specific chain hints.
The other classifier branches are NOT testable in CI integration:

  - **401** — would require a deliberately-bad token; CI uses a real one.
  - **403 rate limit** — can't trigger on demand without burning the
    Search API budget for the rest of the run.
  - **403 permission denied** — would require a private repo the test
    token can't see, which CI doesn't have.
  - **5xx upstream errors** — GitHub doesn't fail on demand.
  - **422 query rejection** — GitHub's search API is too lenient; most
    "bad" queries return zero results instead of 422.
  - **Network errors (httpx.RequestError)** — by definition, only happen
    when the network is broken; can't simulate without monkeypatching,
    which would defeat the point of an integration test.

Each of those branches is covered by ``tests/unit/test_error_classification.py``
with fabricated ``httpx.HTTPStatusError`` instances.

Skipped automatically when no GitHub token is resolvable.
"""

import pytest

from mcp.server.fastmcp.exceptions import ToolError

from fossick.server import mcp

from .helpers import PINNED_REPO_FULL

pytestmark = pytest.mark.live


# A path/ref/repo guaranteed not to exist on the pinned target — random
# enough that it won't collide with anything a user might create.
_GHOST_PATH = "fossick-test-does-not-exist-xyz123.py"
_GHOST_REF = "fossick-test-no-such-branch-xyz123"
_GHOST_REPO = "lipdog/fossick-test-no-such-repo-xyz123"


# -- get_file ----------------------------------------------------------------


async def test_get_file_404_chain_hints_present():
    """A bad path on a real repo must produce a 404 whose message points
    the model at ``repo_tree`` (verify the path) and ``list_tags`` (verify
    the ref) — proving get_file passes both ``path`` and ``repo`` into the
    classifier."""
    with pytest.raises(ToolError) as exc_info:
        await mcp.call_tool("get_file", {
            "repo": PINNED_REPO_FULL,
            "path": _GHOST_PATH,
        })
    msg = str(exc_info.value)
    assert _GHOST_PATH in msg
    assert PINNED_REPO_FULL in msg
    assert "repo_tree" in msg
    assert "list_tags" in msg


# -- repo_tree ---------------------------------------------------------------


async def test_repo_tree_404_chain_hint_present():
    """A bad ref on a real repo must produce a message that names the bad
    ref and points at ``list_tags`` — proving repo_tree passes ``ref``."""
    with pytest.raises(ToolError) as exc_info:
        await mcp.call_tool("repo_tree", {
            "repo": PINNED_REPO_FULL,
            "ref": _GHOST_REF,
        })
    msg = str(exc_info.value)
    # repo_tree currently catches "ref not found" before the HTTP layer
    # in some code paths and returns a string. The error must still mention
    # the ref so the model knows what to fix.
    assert _GHOST_REF in msg or "list_tags" in msg or "not found" in msg.lower()


# -- list_tags ---------------------------------------------------------------


async def test_list_tags_404_repo_not_found():
    """A nonexistent repo must produce a message naming the repo and
    saying it's not found — proving list_tags passes ``repo``."""
    with pytest.raises(ToolError) as exc_info:
        await mcp.call_tool("list_tags", {
            "repo": _GHOST_REPO,
        })
    msg = str(exc_info.value)
    assert _GHOST_REPO in msg
    assert "not found" in msg.lower()
