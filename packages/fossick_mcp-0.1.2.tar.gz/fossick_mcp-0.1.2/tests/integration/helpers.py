"""Shared constants and helpers for integration tests.

Kept separate from conftest.py so they can be imported explicitly —
conftest.py is reserved for pytest hooks and fixtures.
"""

from typing import Any

# Pinned fixture target — immutable public data for deterministic assertions.
# v1.14.0 was verified to have README.md, `class FastMCP`, and a mature test
# structure. Any stable tag would work.
PINNED_OWNER = "modelcontextprotocol"
PINNED_REPO = "python-sdk"
PINNED_REF = "v1.14.0"
PINNED_REPO_FULL = f"{PINNED_OWNER}/{PINNED_REPO}"


def text_of(result: Any) -> str:
    """Extract concatenated text from a FastMCP call_tool result.

    With no output_schema declared on the tool, FastMCP returns a list of
    ContentBlock objects. A (content, structured) tuple shape is handled
    defensively in case that changes in a future mcp release.
    """
    if isinstance(result, tuple) and result:
        result = result[0]
    if isinstance(result, (str, bytes)):
        return result if isinstance(result, str) else result.decode()
    if hasattr(result, "__iter__"):
        pieces: list[str] = []
        for block in result:
            text = getattr(block, "text", None)
            if isinstance(text, str):
                pieces.append(text)
        return "".join(pieces)
    return str(result)
