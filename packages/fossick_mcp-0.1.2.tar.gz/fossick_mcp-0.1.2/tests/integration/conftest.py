"""Integration test hooks — skip live tests if no GitHub token is available."""

import pytest

from fossick.github_client import _resolve_token


def pytest_collection_modifyitems(config, items):
    """Skip all `live`-marked tests when no GitHub token is available.

    Checked at collection time so the skip reason shows up in the test
    report rather than erroring during fixture setup.
    """
    del config  # unused — required by the pytest hook signature
    if _resolve_token():
        return
    skip_reason = pytest.mark.skip(
        reason="No GitHub token resolvable (env vars or `gh auth token`)"
    )
    for item in items:
        if "live" in item.keywords:
            item.add_marker(skip_reason)
