"""Layer C: live integration smoke tests — one per tool.

Hits real GitHub via mcp.call_tool (exercises the full schema/registration
path). Pinned against an immutable tag so content assertions are stable.

Skipped automatically when no GitHub token is resolvable.
"""

import pytest

from fossick.server import mcp

from .helpers import (
    PINNED_REF,
    PINNED_REPO_FULL,
    text_of,
)

pytestmark = pytest.mark.live


async def _call(name: str, args: dict) -> str:
    result = await mcp.call_tool(name, args)
    text = text_of(result)
    assert text, f"{name} returned empty text"
    return text


# -- search_code -------------------------------------------------------------


async def test_search_code_smoke():
    import re

    text = await _call("search_code", {
        "query": "FastMCP",
        "repo": PINNED_REPO_FULL,
        "per_page": 5,
    })
    # Must find results and include the repo name.
    assert "Found" in text
    assert PINNED_REPO_FULL in text
    # Ripgrep-style line-number prefixes: `<N>:` for match lines or
    # `<N>-` for context lines. At least one of these should appear
    # for each fragment when the file-content prefetch succeeds.
    # Regex matches 1+ digits followed by `:` or `-` then a space.
    assert re.search(r"\s\d+[:\-]\s", text), (
        "Expected ripgrep-style line-number prefix (e.g. '  301: ...' "
        "or '  139- ...') in search_code output, indicating the "
        "file-content prefetch resolved absolute line numbers"
    )
    # `--` separator between non-contiguous chunks in the same file
    # (ripgrep --context-separator idiom). FastMCP appears 2+ times
    # in the pinned README so at least one file should show it.
    assert "\n    --\n" in text


# -- search_repos ------------------------------------------------------------


async def test_search_repos_smoke():
    text = await _call("search_repos", {
        "query": "modelcontextprotocol python-sdk",
        "per_page": 5,
    })
    assert "python-sdk" in text


# -- get_file ----------------------------------------------------------------


async def test_get_file_smoke():
    text = await _call("get_file", {
        "repo": PINNED_REPO_FULL,
        "path": "README.md",
        "ref": PINNED_REF,
    })
    # Verified content in v1.14.0 README
    assert "Model Context Protocol" in text


# -- repo_tree ---------------------------------------------------------------


async def test_repo_tree_smoke():
    text = await _call("repo_tree", {
        "repo": PINNED_REPO_FULL,
        "ref": PINNED_REF,
    })
    assert "README.md" in text


# -- find_symbol -------------------------------------------------------------


async def test_find_symbol_smoke():
    import re

    # Use MCPServer (the post-rename name) so we exercise the real
    # definition-found path instead of the degenerate zero-results
    # branch that FastMCP hits at HEAD. Asserts the filter-ratio
    # header, the per-result pattern label, and the tree-sitter path
    # surfacing real absolute line numbers.
    text = await _call("find_symbol", {
        "name": "MCPServer",
        "repo": PINNED_REPO_FULL,
        "language": "python",
    })
    assert "definition(s) for `MCPServer`" in text
    assert "filtered from" in text
    assert "matched pattern: `class`" in text
    assert "class MCPServer" in text
    # Tree-sitter success path surfaces absolute line numbers inline:
    # `(L<n>)` in the header and `<n>:` ripgrep markers in the context.
    # Both markers prove we went through the tree-sitter branch, not
    # the regex-fragment fallback which has no line numbers.
    assert re.search(r"\(L\d+\)", text), (
        "Expected `(L<n>)` line marker in header, indicating the "
        "tree-sitter path resolved an absolute line number"
    )
    assert re.search(r"\s\d+[:\-]\s", text), (
        "Expected ripgrep-style `<n>: ` / `<n>- ` prefix in the "
        "context block, indicating tree-sitter context rendering"
    )


async def test_find_symbol_auto_widen_smoke():
    # Originally-failing case: `FastMCP` with language=python matches
    # zero results at HEAD because the class was renamed to MCPServer.
    # The auto-widen retry path should drop the language filter and
    # surface the surviving markdown references (migration doc), with
    # a clear warning explaining what happened.
    text = await _call("find_symbol", {
        "name": "FastMCP",
        "repo": PINNED_REPO_FULL,
        "language": "python",
    })
    assert "matched 0 results" in text  # auto-widen warning fired
    assert "Retried without filter" in text
    assert "FastMCP" in text  # surviving references surfaced
    assert "migration.md" in text


# -- list_tags ---------------------------------------------------------------


async def test_list_tags_smoke():
    text = await _call("list_tags", {
        "repo": PINNED_REPO_FULL,
        "per_page": 20,
    })
    # Confirmed tag must show up in the list
    assert PINNED_REF in text


# -- search_packages ---------------------------------------------------------


async def test_search_packages_pypi_smoke():
    text = await _call("search_packages", {
        "name": "mcp",
        "ecosystem": "pypi",
    })
    assert "mcp" in text.lower()
