# AGENTS.md

Agent instructions for **fossick-mcp**. This file is the universal entry point for AI coding agents (Claude Code, Cursor, OpenHands, Aider, etc.).

The full project instructions — architecture, file layout, key patterns, test recipes, and conventions — live in [`CLAUDE.md`](./CLAUDE.md).

Claude Code resolves the `@` import below automatically at load time. For other agents that don't recognize the `@` syntax, open `CLAUDE.md` directly.

@CLAUDE.md
