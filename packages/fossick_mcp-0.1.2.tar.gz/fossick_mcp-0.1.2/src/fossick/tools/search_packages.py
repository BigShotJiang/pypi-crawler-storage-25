"""search_packages — look up packages on PyPI or npm."""


from typing import Annotated

import httpx

from mcp.server.fastmcp.exceptions import ToolError
from mcp.types import ToolAnnotations
from pydantic import Field

from fossick.hints import format_hints, generate_hints
from fossick.server import mcp


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
    # See search_code.py for why structured_output=False.
    structured_output=False,
)
async def search_packages(
    name: Annotated[str, Field(description="Package name to search for.")],
    ecosystem: Annotated[str, Field(description="Package registry: pypi or npm.")] = "pypi",
    limit: Annotated[int, Field(description="Max results (npm only; PyPI returns exact match).")] = 5,
) -> str:
    """Search for a package on PyPI or npm (not GitHub — does not use GitHub API or rate limits). PyPI: exact-match lookup returning version, description, license, homepage, and GitHub URL. npm: text search returning multiple results with links. Use for looking up package metadata and versions — chain with search_repos to explore the source repository."""
    try:
        if ecosystem.lower() == "pypi":
            return await _search_pypi(name)
        elif ecosystem.lower() == "npm":
            return await _search_npm(name, limit)
        else:
            return (
                f"Unsupported ecosystem `{ecosystem}`. Use `pypi` or `npm`."
            )
    except Exception as e:
        raise ToolError(f"Error searching {ecosystem} for `{name}`: {e}")


# PyPI `project_urls` keys vary widely across packages (e.g. "Source",
# "Source Code", "Repository", "Homepage", "Bug Tracker", "Documentation",
# etc.). Iteration order isn't guaranteed, so taking the first github.com
# URL we happen to see often surfaced a `.../issues` bug-tracker link
# instead of the repo root. Rank keys semantically and reject URLs whose
# path clearly points at a GitHub sub-page (issues, pulls, wiki, …).
_PREFERRED_PROJECT_URL_KEYS = (
    "source",
    "source code",
    "sourcecode",
    "repository",
    "repo",
    "code",
    "github",
    "homepage",
    "home page",
    "home",
)

_GITHUB_SUBPAGE_FRAGMENTS = (
    "/issues",
    "/pulls",
    "/pull/",
    "/discussions",
    "/security",
    "/actions",
    "/wiki",
    "/projects",
    "/releases",
)


def _is_github_repo_url(url: str) -> bool:
    if not url or "github.com" not in url.lower():
        return False
    lower = url.lower()
    return not any(frag in lower for frag in _GITHUB_SUBPAGE_FRAGMENTS)


def _pick_github_repo_url(project_urls: dict, homepage: str) -> str:
    # First pass: preferred semantic keys (case-insensitive).
    normalized = {k.lower(): v for k, v in project_urls.items() if v}
    for pref in _PREFERRED_PROJECT_URL_KEYS:
        url = normalized.get(pref, "")
        if _is_github_repo_url(url):
            return url
    # Second pass: any project_urls entry that isn't a sub-page.
    for url in project_urls.values():
        if _is_github_repo_url(url):
            return url
    # Third pass: the top-level home_page field.
    if _is_github_repo_url(homepage):
        return homepage
    return ""


async def _search_pypi(name: str) -> str:
    """Look up a package on PyPI."""
    async with httpx.AsyncClient(timeout=15.0) as http:
        resp = await http.get(f"https://pypi.org/pypi/{name}/json")

        if resp.status_code == 404:
            # Fall back to simple index search
            resp2 = await http.get(
                "https://pypi.org/simple/",
                headers={"Accept": "application/vnd.pypi.simple.v1+json"},
            )
            if resp2.status_code != 200:
                return f"Package `{name}` not found on PyPI."

            projects = resp2.json().get("projects", [])
            matches = [
                p for p in projects
                if name.lower() in p.get("name", "").lower()
            ][:5]

            if not matches:
                return f"Package `{name}` not found on PyPI."

            lines = [f"No exact match for `{name}`. Similar packages:"]
            for p in matches:
                lines.append(f"  - {p.get('name', '')}")
            return "\n".join(lines)

        if resp.status_code != 200:
            return f"PyPI returned status {resp.status_code} for `{name}`."

        data = resp.json()
        info = data.get("info", {})

        pkg_name = info.get("name", name)
        version = info.get("version", "?")
        summary = info.get("summary", "")
        license_name = info.get("license", "unknown") or "unknown"
        homepage = info.get("home_page", "") or ""
        project_urls = info.get("project_urls") or {}

        github_url = _pick_github_repo_url(project_urls, homepage)

        lines: list[str] = [f"**{pkg_name}** v{version} (PyPI)"]
        if summary:
            lines.append(f"  {summary}")
        lines.append(f"  License: {license_name}")
        if homepage:
            lines.append(f"  Homepage: {homepage}")
        if github_url:
            lines.append(f"  GitHub: {github_url}")

        params = {"name": name, "ecosystem": "pypi"}
        result_data = {"github_url": github_url}
        hints = generate_hints("search_packages", params, result_data)
        lines.append(format_hints(hints))

        return "\n".join(lines)


async def _search_npm(name: str, limit: int) -> str:
    """Search for packages on npm."""
    async with httpx.AsyncClient(timeout=15.0) as http:
        resp = await http.get(
            "https://registry.npmjs.org/-/v1/search",
            params={"text": name, "size": limit},
        )

        if resp.status_code != 200:
            return f"npm returned status {resp.status_code} for `{name}`."

        data = resp.json()
        objects = data.get("objects", [])

        if not objects:
            return f"No packages matching `{name}` found on npm."

        lines: list[str] = [
            f"npm search results for `{name}` ({len(objects)}):",
            "",
        ]

        github_url = ""
        for obj in objects:
            pkg = obj.get("package", {})
            pkg_name = pkg.get("name", "?")
            version = pkg.get("version", "?")
            description = pkg.get("description", "")
            links = pkg.get("links", {})
            homepage = links.get("homepage", "")
            npm_url = links.get("npm", "")
            repo_url = links.get("repository", "")

            if repo_url and "github.com" in repo_url.lower():
                github_url = repo_url

            lines.append(f"**{pkg_name}** v{version}")
            if description:
                lines.append(f"  {description}")
            if npm_url:
                lines.append(f"  npm: {npm_url}")
            if homepage:
                lines.append(f"  Homepage: {homepage}")
            if repo_url:
                lines.append(f"  Repository: {repo_url}")
            lines.append("")

        params = {"name": name, "ecosystem": "npm"}
        result_data = {"github_url": github_url}
        hints = generate_hints("search_packages", params, result_data)
        lines.append(format_hints(hints))

        return "\n".join(lines)
