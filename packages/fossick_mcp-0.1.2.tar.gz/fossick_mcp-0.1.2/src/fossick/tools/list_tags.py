"""list_tags — list tags or releases for a GitHub repository."""


from typing import Annotated

from mcp.types import ToolAnnotations
from pydantic import Field

from fossick.github_client import get_client
from fossick.hints import format_hints, generate_hints
from fossick.server import mcp
from fossick.tools._common import http_error_to_tool_error, split_repo


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
    # See search_code.py for why structured_output=False.
    structured_output=False,
)
async def list_tags(
    repo: Annotated[str, Field(description="Repository in 'owner/name' format (e.g. 'modelcontextprotocol/python-sdk').")],
    releases: Annotated[bool, Field(description="If true, fetch releases (with changelogs and assets) instead of bare tags.")] = False,
    page: Annotated[int, Field(description="Result page.")] = 1,
    per_page: Annotated[int, Field(description="Results per page (max 100).")] = 20,
) -> str:
    """List tags or releases for one repository. Default mode returns lightweight tag names with commit SHAs. Release mode (releases=true) returns full release objects including tag name, title, changelog body, publish date, and attached assets. Use to check a library's freshness (is it actively maintained?), find the current version to pin against, or pick a specific release to read files at via get_file(ref=<tag>) or browse via repo_tree(ref=<tag>)."""
    owner, name = split_repo(repo)
    try:
        client = get_client()

        if releases:
            return await _format_releases(client, owner, name, repo, page, per_page)
        else:
            return await _format_tags(client, owner, name, repo, page, per_page)

    except Exception as e:
        raise http_error_to_tool_error(
            e, tool="list_tags", repo=repo,
        )


async def _format_tags(client, owner: str, name: str, repo: str, page: int, per_page: int) -> str:
    """Format bare tags."""
    tags = await client.get_tags(owner, name, page=page, per_page=per_page)

    if not tags:
        return f"No tags found for `{repo}` (page {page})."

    lines: list[str] = [f"Tags for `{repo}` (page {page}):"]
    lines.append("")

    for tag in tags:
        tag_name = tag.get("name", "?")
        sha = tag.get("commit", {}).get("sha", "?")[:10]
        lines.append(f"  {tag_name:30s}  {sha}")

    params = {"repo": repo, "releases": False}
    hints = generate_hints("list_tags", params, {})
    lines.append(format_hints(hints))

    return "\n".join(lines)


async def _format_releases(client, owner: str, name: str, repo: str, page: int, per_page: int) -> str:
    """Format releases with changelogs and assets."""
    rels = await client.get_releases(owner, name, page=page, per_page=per_page)

    if not rels:
        return f"No releases found for `{repo}` (page {page})."

    lines: list[str] = [f"Releases for `{repo}` (page {page}):"]
    lines.append("")

    for rel in rels:
        tag_name = rel.get("tag_name", "?")
        title = rel.get("name", "") or tag_name
        published = rel.get("published_at", "")
        if published and "T" in published:
            published = published.split("T")[0]
        prerelease = rel.get("prerelease", False)
        draft = rel.get("draft", False)
        body = rel.get("body", "") or ""
        assets = rel.get("assets", [])
        html_url = rel.get("html_url", "")

        status_parts: list[str] = []
        if draft:
            status_parts.append("draft")
        if prerelease:
            status_parts.append("pre-release")
        status = f" ({', '.join(status_parts)})" if status_parts else ""

        lines.append(f"**{tag_name}** — {title}{status}")
        lines.append(f"  Published: {published}")
        if html_url:
            lines.append(f"  URL: {html_url}")

        # Truncate changelog
        if body:
            body_lines = body.strip().split("\n")
            preview = "\n".join(body_lines[:15])
            if len(body_lines) > 15:
                preview += f"\n  ... ({len(body_lines) - 15} more lines)"
            for bl in preview.split("\n"):
                lines.append(f"  {bl}")

        # Assets
        if assets:
            lines.append(f"  Assets ({len(assets)}):")
            for asset in assets[:10]:
                aname = asset.get("name", "?")
                size = asset.get("size", 0)
                size_mb = size / (1024 * 1024)
                lines.append(f"    - {aname} ({size_mb:.1f} MB)")
            if len(assets) > 10:
                lines.append(f"    ... and {len(assets) - 10} more")

        lines.append("")

    params = {"repo": repo, "releases": True}
    hints = generate_hints("list_tags", params, {})
    lines.append(format_hints(hints))

    return "\n".join(lines)
