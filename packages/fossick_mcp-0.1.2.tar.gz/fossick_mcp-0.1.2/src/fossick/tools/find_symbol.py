"""find_symbol — goto-definition for GitHub-hosted code.

Strategy:
  1. Query GitHub's legacy code-search API for files containing the
     symbol name (narrowed by language/repo/path when provided). This
     gets us an accurate shortlist of candidate files — GitHub's
     full-text index is fine at file-level recall even though it's
     lossy at declaration-line level.
  2. In parallel, fetch the full content of each candidate file via
     get_contents, using the commit SHA embedded in each result's
     html_url so we see the exact same state GitHub indexed.
  3. Parse each fetched file with tree-sitter and run a
     language-specific AST query for declaration nodes (class,
     function, struct, trait, etc.) whose name equals our target.
     This is AST-accurate: strings in docstrings, comments, and
     arbitrary substring hits do not match.
  4. When tree-sitter finds a definition, emit ripgrep-style output
     with the real absolute line number and 2 lines of context above
     and below the declaration.
  5. Fall back to the legacy fragment-regex path for files whose
     language tree-sitter doesn't cover, or for cases where the
     AST query matches nothing — there are still cases worth
     surfacing via raw text hits with a clear "text-level, not
     verified" caveat.

GitHub's REST search API can't do this natively — its legacy index
doesn't honor the new `symbol:` qualifier (confirmed via the `gh
search code` docs, which explicitly say "new features like regex
search are not yet available via the GitHub API"), and the new
Blackbird index has no public API path regardless of authentication.
So we do the semantic work ourselves: file-level shortlist from
GitHub, declaration-level precision from tree-sitter on our side.
"""


import asyncio
import re
from typing import Annotated, Any

from mcp.types import ToolAnnotations
from pydantic import Field

from fossick.github_client import get_client
from fossick.hints import format_hints, generate_hints
from fossick.server import mcp
from fossick.tools import _tree_sitter
from fossick.tools._common import (
    CODE_SEARCH_QUALIFIERS,
    CODE_SEARCH_REDIRECTS,
    extract_commit_sha,
    fetch_file_content,
    http_error_to_tool_error,
    validate_search_query,
)

# Language-specific patterns that indicate a definition (not just a
# usage). Each entry is a (label, regex_template) pair: the label is
# surfaced on each result so Claude can see *which* pattern matched
# (e.g. `class`, `assign`, `export default function`) and weight the
# confidence of the match accordingly.
_DEFINITION_PATTERNS: dict[str, list[tuple[str, str]]] = {
    "python": [
        ("class", r"class\s+{name}\b"),
        ("def", r"(?:async\s+)?def\s+{name}\b"),
        ("assign", r"(?:^|\n)\s*{name}\s*(?::|=)"),
    ],
    "javascript": [
        ("class", r"class\s+{name}\b"),
        ("function", r"function\s+{name}\b"),
        ("const/let/var", r"(?:const|let|var)\s+{name}\b"),
        ("export", r"export\s+(?:default\s+)?(?:function|class)\s+{name}\b"),
    ],
    "typescript": [
        ("class", r"class\s+{name}\b"),
        ("interface", r"interface\s+{name}\b"),
        ("type", r"type\s+{name}\b"),
        ("enum", r"enum\s+{name}\b"),
        ("function", r"function\s+{name}\b"),
        ("const/let/var", r"(?:const|let|var)\s+{name}\b"),
        ("export", r"export\s+(?:default\s+)?(?:function|class|interface|type|enum)\s+{name}\b"),
    ],
    "go": [
        ("func", r"func\s+{name}\b"),
        ("method", r"func\s+\([^)]+\)\s+{name}\b"),
        ("type", r"type\s+{name}\s+(?:struct|interface)\b"),
    ],
    "rust": [
        ("fn/struct/enum/trait", r"(?:pub\s+)?(?:fn|struct|enum|trait|type|const|static)\s+{name}\b"),
    ],
    "java": [
        ("class/interface/enum", r"(?:class|interface|enum)\s+{name}\b"),
        ("method", r"(?:public|private|protected)\s+.*\s+{name}\s*\("),
    ],
    "ruby": [
        ("def/class/module", r"(?:def|class|module)\s+{name}\b"),
    ],
    "c": [
        ("type", r"(?:struct|enum|typedef)\s+{name}\b"),
        ("function", r"\w+\s+{name}\s*\("),
    ],
    "cpp": [
        ("class/struct/enum/namespace", r"(?:class|struct|enum|namespace)\s+{name}\b"),
        ("function", r"\w+\s+{name}\s*\("),
    ],
}

# Generic cross-language fallback used when `language` is not set.
# Less precise but broadly applicable — Claude sees the fallback label
# so it can judge whether to trust the match.
_GENERIC_DEFINITION_PATTERNS: list[tuple[str, str]] = [
    ("keyword", r"(?:def|func|function|class|interface|type|struct|enum|trait)\s+{name}\b"),
    ("binding", r"(?:const|let|var|val)\s+{name}\b"),
    ("export", r"export\s+(?:default\s+)?(?:function|class)\s+{name}\b"),
]


# Priority order for ranking definitions when multiple candidates
# exist across files. Lower number = higher priority.
#
# Why this matters: when a user asks "find symbol Foo", they almost
# always mean the type/class/struct declaration, NOT a method or
# function that happens to be named Foo. But GitHub's code search
# ranks by text-relevance, not declaration-kind, so a file containing
# `func (v *defaultValidator) Engine() any` can outrank `type Engine
# struct { ... }` in the raw result ordering. We sort tree-sitter
# results by this priority before rendering so type declarations
# always come first, then top-level functions, then methods, then
# variables/constants.
#
# Kind labels come from the capture names in _tree_sitter._QUERIES.
# Anything not listed here gets the worst priority so truly novel
# kinds sort last.
_KIND_PRIORITY: dict[str, int] = {
    # Type-declaring kinds — usually what "find X" means
    "class": 0,
    "struct": 0,
    "interface": 0,
    "trait": 0,
    "enum": 0,
    "type": 0,
    "typedef": 0,
    "union": 0,
    "namespace": 0,
    "module": 0,
    # Top-level functions
    "function": 1,
    # Methods on types
    "method": 2,
    # Variables, constants, statics
    "const": 3,
    "static": 3,
}


def _definition_kind(fragment: str, name: str, language: str) -> str | None:
    """Return the label of the first definition pattern that matches
    `fragment`, or None if no pattern matches.

    The label is surfaced on each result as provenance: Claude can
    see whether a match came from a strict `class` pattern or a
    looser `assign` pattern and weight confidence accordingly. For
    unknown languages with a non-empty `language`, falls back to a
    bare name-presence check and returns "match".
    """
    escaped = re.escape(name)
    if not language:
        for label, template in _GENERIC_DEFINITION_PATTERNS:
            if re.search(template.format(name=escaped), fragment):
                return label
        return None

    patterns = _DEFINITION_PATTERNS.get(language.lower())
    if not patterns:
        # Unknown language — fall back to name presence. Better than
        # nothing but tagged distinctly so the reader knows the
        # precision is lower.
        return "match" if name in fragment else None

    for label, template in patterns:
        if re.search(template.format(name=escaped), fragment):
            return label
    return None


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
    # See search_code.py for why structured_output=False.
    structured_output=False,
)
async def find_symbol(
    name: Annotated[str, Field(description="Symbol name (function, class, type, variable).")],
    repo: Annotated[str, Field(description="Scope to one repo (owner/repo). Omit for cross-repo search.")] = "",
    language: Annotated[str, Field(description="Filter by programming language.")] = "",
    kind: Annotated[str, Field(description="Reserved for future kind filtering.")] = "",
    path: Annotated[str, Field(description="File path filter (e.g. src/).")] = "",
    page: Annotated[int, Field(description="Result page.")] = 1,
    per_page: Annotated[int, Field(description="Results per page (max 100).")] = 20,
) -> str:
    """Goto-definition: find where a symbol is defined in one repo or across all of GitHub.

    How it works: queries GitHub's code-search index for files containing
    the symbol name, parallel-fetches the top ~15 candidate files, parses
    each with tree-sitter, and queries the AST for declaration nodes
    (class, function, struct, trait, interface, etc.) whose name matches
    exactly. Results are ranked with type-declaring kinds
    (class/struct/trait) first, then functions, then methods, then
    variables. Success responses include real absolute line numbers and
    ripgrep-style context (2 lines above, match line, 5 lines below)
    pulled from the full file, not GitHub's 3-line fragment.

    Languages with AST-precise matching via tree-sitter: Python, JavaScript,
    TypeScript, Go, Rust, Java, Ruby, C, C++. Other languages fall back to
    a regex-on-fragment path that is less precise but still useful.

    Best for **distinctive** symbol names — `FastMCP`, `DataLoader`,
    `ClaudeAgentOptions`, `Runtime`, `Tokenizer`. These are names creators
    chose to be findable, and the first-declaration-wins ranking is
    almost always right.

    NOT for generic names like `connect`, `handle`, `init`, `get`, `run`
    that show up in every library. GitHub's text-relevance ranking puts
    usage-heavy files above the one declaring them, so the declaration
    file often isn't in the top 15 we fetch. For generic names, use
    `search_code` with disambiguating keywords (e.g.
    `search_code("export function connect", repo="reduxjs/react-redux")`)
    or combine with `path:` qualifier to narrow the search.

    NOT for finding call-sites or usage patterns — use `search_code`
    with the symbol name and a `repo:` qualifier for that.
    """
    try:
        # The `name` is forwarded directly into a code-search query, so
        # the same qualifier allowlist applies — catch an LLM dropping a
        # `stars:>N`-style filter into the symbol name before GitHub
        # silently matches it as literal content.
        validate_search_query(
            name,
            tool="find_symbol",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )

        client = get_client()

        # Build the search query. Callable so we can rebuild it for
        # the auto-widen retry path without duplicating logic.
        def _build_query(include_filters: bool) -> str:
            parts = [name]
            if repo:
                parts.append(f"repo:{repo}")
            if include_filters:
                if language:
                    parts.append(f"language:{language}")
                if path:
                    parts.append(f"path:{path}")
            return " ".join(parts)

        query = _build_query(include_filters=True)
        result = await client.search_code(query, page=page, per_page=per_page)
        total = result.get("total_count", 0)
        items = result.get("items", [])

        # Auto-widen retry: if `language` or `path` filters excluded
        # everything, drop them once and re-query. GitHub code search
        # indexes the default branch at HEAD only, so a renamed or
        # filter-excluded symbol falls through silently on the first
        # attempt. The retry surfaces whatever exists at HEAD so the
        # caller sees the markdown/doc mention even when the Python
        # definition is gone.
        widen_note = ""
        filters_were_applied = bool(language or path)
        if total == 0 and filters_were_applied:
            dropped: list[str] = []
            if language:
                dropped.append(f"language={language}")
            if path:
                dropped.append(f"path={path}")
            fallback_query = _build_query(include_filters=False)
            fallback_result = await client.search_code(
                fallback_query, page=page, per_page=per_page,
            )
            fallback_total = fallback_result.get("total_count", 0)
            if fallback_total > 0:
                widen_note = (
                    f"⚠️  Original query with {', '.join(dropped)} "
                    f"matched 0 results. Retried without filter(s) — "
                    f"showing {fallback_total} results below. "
                    f"(GitHub code search only indexes the default "
                    f"branch at HEAD; a symbol may have been renamed, "
                    f"or may live in docs/configs excluded by the filter.)"
                )
                result = fallback_result
                total = fallback_total
                items = result.get("items", [])

        if total == 0:
            filter_desc = []
            if language:
                filter_desc.append(f"language={language}")
            if path:
                filter_desc.append(f"path={path}")
            filter_note = (
                f" (with filters {', '.join(filter_desc)})"
                if filter_desc else ""
            )
            # Build the chain-target suggestion lines outside the
            # f-string since Python 3.11 doesn't allow backslashes
            # in f-string expression parts.
            repo_arg = f', repo="{repo}"' if repo else ""
            search_suggestion = (
                f'- `search_code(query="{name}"{repo_arg})` — '
                "full-text search across all content, including "
                "docs and configs"
            )
            tree_repo = repo or "..."
            tree_suggestion = (
                f'- `repo_tree(repo="{tree_repo}", ref="<tag>")` — '
                "browse the tree at a specific historical ref to "
                "find the file directly"
            )
            return (
                f"No results found for symbol `{name}`"
                f"{filter_note}.\n\n"
                "GitHub code search only indexes the default branch "
                "at HEAD — a symbol that was renamed, moved, or "
                "deleted since the last index won't appear here.\n\n"
                "Next steps:\n"
                f"{search_suggestion}\n"
                f"{tree_suggestion}\n"
                "- If the symbol was renamed, try the new name "
                "(check docs/migration.md or CHANGELOG.md)"
            )

        lines: list[str] = []
        if widen_note:
            lines.append(widen_note)
            lines.append("")

        # -- Tree-sitter prefetch phase ---------------------------------
        # Fetch the full content of the top-N candidate files in
        # parallel so we can run AST queries against the whole file
        # rather than against GitHub's 3-line text_matches.fragment.
        # Using the commit SHA from each item's html_url as `ref` so
        # the fetched content is byte-identical to what GitHub
        # indexed. This is the same prefetch pattern search_code
        # already uses; the helpers live in tools/_common.py.
        #
        # Why 15 files and not 5: GitHub's code search ranks files by
        # relevance to the query text, not by "does this file declare
        # the symbol." A common failure mode — observed on gin's
        # `Engine` — is that the file containing the real
        # `type X struct` declaration ranks lower than files
        # containing methods named X or heavy usage of X, so with a
        # small cap we never fetch the right file. 15 gives enough
        # headroom without making the parallel-fetch burst too big.
        MAX_FILES_TO_PARSE = 15
        candidate_items = items[:MAX_FILES_TO_PARSE]
        file_fetch_keys: list[tuple[str, str, str, str]] = []
        for item in candidate_items:
            repo_full = item.get("repository", {}).get("full_name", "")
            if "/" not in repo_full:
                continue
            owner_part, name_part = repo_full.split("/", 1)
            file_path_iter = item.get("path", "")
            commit_sha = extract_commit_sha(item.get("html_url", ""))
            if not commit_sha or not file_path_iter:
                continue
            file_fetch_keys.append(
                (owner_part, name_part, commit_sha, file_path_iter),
            )

        async def _fetch_job(
            key: tuple[str, str, str, str],
        ) -> tuple[tuple[str, str, str, str], str]:
            owner_, name_, sha_, path_ = key
            content_ = await fetch_file_content(client, owner_, name_, path_, sha_)
            return key, content_

        file_contents: dict[tuple[str, str, str, str], str] = {}
        if file_fetch_keys:
            fetched = await asyncio.gather(
                *(_fetch_job(k) for k in file_fetch_keys),
                return_exceptions=False,
            )
            for key, content_ in fetched:
                file_contents[key] = content_

        # Extract definitions: tree-sitter first, regex fallback.
        #
        # For each candidate file, try to find definitions by parsing
        # the full content with tree-sitter and querying the AST. If
        # tree-sitter isn't available for the language, or finds
        # nothing in this particular file, fall back to the legacy
        # fragment-regex path for that file only — better than losing
        # the hit entirely.
        definitions: list[dict[str, Any]] = []
        ts_supported = (
            _tree_sitter.is_available()
            and language.lower() in _tree_sitter.supported_languages()
        )

        for item in candidate_items:
            repo_name = item.get("repository", {}).get("full_name", "unknown")
            file_path_iter = item.get("path", "unknown")
            html_url = item.get("html_url", "")
            text_matches = item.get("text_matches", [])

            # Look up prefetched content.
            owner_part = name_part = ""
            if "/" in repo_name:
                owner_part, name_part = repo_name.split("/", 1)
            commit_sha = extract_commit_sha(html_url)
            content = ""
            if commit_sha and owner_part and name_part:
                content = file_contents.get(
                    (owner_part, name_part, commit_sha, file_path_iter), "",
                )

            # Tree-sitter ran AND had a real file to parse against:
            # trust its answer. If it finds nothing for this file, the
            # symbol isn't declared here — fragment regex would only
            # add false positives (e.g. `type Component` inside a
            # type-import statement, `Engine()` method inside a
            # non-matching fragment). We move on rather than let a
            # loose pattern match imports or references.
            if ts_supported and content:
                ts_defs = _tree_sitter.find_definitions(
                    content, name, language,
                )
                for d in ts_defs:
                    definitions.append({
                        "repo": repo_name,
                        "path": file_path_iter,
                        "url": html_url,
                        "line": d.line,
                        "column": d.column,
                        "pattern": d.kind,
                        "source": "ast",
                        "content": content,
                    })
                continue  # next file — tree-sitter is authoritative here

            # Fallback: regex on GitHub's fragment. Only reached when
            # tree-sitter isn't applicable (unsupported language, file
            # fetch failed, or empty content). Never runs on a file
            # tree-sitter already scanned — that would just reintroduce
            # the fragment-regex false positives we fixed above.
            for match in text_matches:
                fragment = match.get("fragment", "")
                kind_label = _definition_kind(fragment, name, language)
                if kind_label is not None:
                    definitions.append({
                        "repo": repo_name,
                        "path": file_path_iter,
                        "url": html_url,
                        "line": None,
                        "column": None,
                        "pattern": kind_label,
                        "source": "regex-fragment",
                        "fragment": fragment,
                    })
                    break  # one match per file

        # Rank definitions by kind priority: type-declaring kinds
        # first (class/struct/trait/interface/enum/...), then
        # top-level functions, then methods, then variables. Tie-
        # break by file order (stable sort preserves the order of
        # definitions that share the same kind priority, which is
        # GitHub's original relevance ranking). This is the fix for
        # the "gin Engine method outranks gin.go type Engine struct"
        # class of bug — the real type declaration always wins over
        # an incidentally-named method now.
        definitions.sort(
            key=lambda d: _KIND_PRIORITY.get(d["pattern"], 99),
        )

        if not definitions:
            # Fallback: show raw content matches when no definition
            # pattern matched anywhere. Label clearly that these are
            # text-level hits, not verified definitions.
            lang_desc = language or "(auto-detect)"
            lines.append(
                f"Found {total} result(s) for `{name}` but none matched "
                f"definition patterns for language={lang_desc}. "
                f"Showing raw matches — these are text-level hits, not "
                f"verified definitions."
            )
            lines.append(
                f"Consider `search_code` with a `repo:` qualifier for "
                f"broader control if this looks wrong."
            )
            lines.append("")
            for item in items[:10]:
                repo_name = item.get("repository", {}).get("full_name", "")
                file_path_iter = item.get("path", "")
                lines.append(f"- `{repo_name}` — `{file_path_iter}`")
                for m in item.get("text_matches", [])[:1]:
                    frag = m.get("fragment", "").strip()
                    if frag:
                        for fl in frag.split("\n")[:4]:
                            lines.append(f"    {fl}")
        else:
            header = (
                f"Found {len(definitions)} definition(s) for `{name}` "
                f"(filtered from {total} content match"
                f"{'es' if total != 1 else ''}):"
            )
            lines.append(header)
            lines.append("")
            for d in definitions[:10]:
                header_line = (
                    f"**{d['repo']}** — `{d['path']}` · "
                    f"matched pattern: `{d['pattern']}`"
                )
                if d.get("line") is not None:
                    header_line += f" (L{d['line']})"
                lines.append(header_line)
                lines.append(f"  {d['url']}")

                if d["source"] == "ast" and d.get("content"):
                    # Render ripgrep-style context: 2 lines above,
                    # match line, up to 5 lines below. Mark the match
                    # line with `:` and context with `-`, same format
                    # as search_code.
                    all_file_lines = d["content"].split("\n")
                    match_line_idx = d["line"] - 1  # 0-indexed
                    start = max(0, match_line_idx - 2)
                    end = min(len(all_file_lines), match_line_idx + 6)
                    for i in range(start, end):
                        ln = i + 1
                        sep = ":" if ln == d["line"] else "-"
                        lines.append(
                            f"    {ln:>4}{sep} {all_file_lines[i]}"
                        )
                else:
                    # Regex-fragment fallback — no line numbers, just
                    # the raw fragment text.
                    lines.append("  Context (fragment, no line numbers):")
                    for fl in d.get("fragment", "").strip().split("\n")[:8]:
                        lines.append(f"    {fl}")
                lines.append("")

        params = {"name": name, "repo": repo, "language": language}
        hints = generate_hints("find_symbol", params, result)
        lines.append(format_hints(hints))

        return "\n".join(lines)

    except Exception as e:
        raise http_error_to_tool_error(
            e, tool="find_symbol", repo=repo, query=name,
        )
