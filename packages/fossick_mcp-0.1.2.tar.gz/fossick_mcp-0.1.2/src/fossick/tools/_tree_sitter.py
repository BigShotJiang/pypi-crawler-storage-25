"""AST-level definition finder for find_symbol.

Wraps `tree-sitter` + `tree-sitter-language-pack` to locate symbol
definitions in a source file with real 1-indexed line numbers and
language-aware kind labels (e.g. `class`, `function`, `struct`).

Why this exists: GitHub's REST code-search API returns 3-line
`text_matches.fragment` slices per hit, which our former regex-based
`_definition_kind` scanned for pattern matches. That approach has two
known failure modes — (1) when GitHub's fragment-selection picks
imports/docs instead of the declaration line, we miss real
definitions (observed on tokio-rs/tokio `Runtime`), and (2) regex
patterns can't distinguish `class FastMCP` in code from the same
string appearing in docstrings or comments, so we pick up false
positives (observed on gin-gonic/gin `Engine`).

Tree-sitter sidesteps both: we parse the whole fetched file (not
just a fragment) and query the AST for declaration nodes, so the
parser's semantics filter out strings/comments for us and the whole
file is in scope. The per-file parse cost is 10-30ms — negligible
compared to the network fetch that preceded it (~200-500ms).

What this module does NOT do: type resolution, cross-file symbol
tracking, call hierarchy. For true semantic goto-definition we would
need an LSP (pyright/rust-analyzer/gopls) with a full workspace,
which has 10-60s cold-start latency per repo and is out of scope.
For "where is X declared in this file" — which is find_symbol's
actual job once we've used GitHub search to narrow to candidate
files — tree-sitter is the right tool.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from typing import Any

try:
    import tree_sitter
    from tree_sitter_language_pack import get_language, get_parser
    _TS_AVAILABLE = True
except ImportError:
    _TS_AVAILABLE = False


@dataclass(frozen=True)
class Definition:
    """One symbol definition located in source by AST query.

    * `name` — the identifier text at the declaration site. Callers
      filter on exact equality so this always matches the requested
      name.
    * `kind` — the capture label from the tree-sitter query, which
      we use as a human-readable declaration kind (`class`,
      `function`, `struct`, `trait`, etc.). Same values as the
      labels we used in the regex path so downstream rendering is
      unchanged.
    * `line` — 1-indexed line number of the declaration in the file.
    """
    name: str
    kind: str
    line: int
    column: int


# Per-language tree-sitter queries. Keys match the lowercase
# language names we accept from the GitHub `language:` qualifier, so
# the caller doesn't have to remap. Each query is a multi-pattern
# S-expression: each alternative captures the identifier node of a
# declaration with a capture name that doubles as the kind label.
# We filter on `node.text == name` in Python rather than embedding
# `(#eq? @name "...")` predicates because (a) it avoids escaping the
# name into the query string, and (b) it's about the same cost at
# this scale (tens of candidates per file).
_QUERIES: dict[str, str] = {
    "python": """
        (class_definition name: (identifier) @class)
        (function_definition name: (identifier) @function)
        (decorated_definition
          definition: (class_definition name: (identifier) @class))
        (decorated_definition
          definition: (function_definition name: (identifier) @function))
    """,
    "javascript": """
        (class_declaration name: (identifier) @class)
        (function_declaration name: (identifier) @function)
        (method_definition name: (property_identifier) @method)
        (variable_declarator name: (identifier) @const)
        (export_statement
          declaration: (class_declaration name: (identifier) @class))
        (export_statement
          declaration: (function_declaration name: (identifier) @function))
    """,
    "typescript": """
        (class_declaration name: (type_identifier) @class)
        (function_declaration name: (identifier) @function)
        (interface_declaration name: (type_identifier) @interface)
        (type_alias_declaration name: (type_identifier) @type)
        (enum_declaration name: (identifier) @enum)
        (method_definition name: (property_identifier) @method)
        (variable_declarator name: (identifier) @const)
        (export_statement
          declaration: (class_declaration name: (type_identifier) @class))
        (export_statement
          declaration: (function_declaration name: (identifier) @function))
        (export_statement
          declaration: (interface_declaration name: (type_identifier) @interface))
        (export_statement
          declaration: (type_alias_declaration name: (type_identifier) @type))
    """,
    "go": """
        (function_declaration name: (identifier) @function)
        (method_declaration name: (field_identifier) @method)
        (type_declaration
          (type_spec name: (type_identifier) @type))
    """,
    "rust": """
        (struct_item name: (type_identifier) @struct)
        (enum_item name: (type_identifier) @enum)
        (trait_item name: (type_identifier) @trait)
        (type_item name: (type_identifier) @type)
        (function_item name: (identifier) @function)
        (const_item name: (identifier) @const)
        (static_item name: (identifier) @static)
        (mod_item name: (identifier) @module)
    """,
    "java": """
        (class_declaration name: (identifier) @class)
        (interface_declaration name: (identifier) @interface)
        (enum_declaration name: (identifier) @enum)
        (method_declaration name: (identifier) @method)
    """,
    "ruby": """
        (class name: (constant) @class)
        (module name: (constant) @module)
        (method name: (identifier) @method)
        (singleton_method name: (identifier) @method)
    """,
    "c": """
        (function_definition
          declarator: (function_declarator
            declarator: (identifier) @function))
        (struct_specifier name: (type_identifier) @struct)
        (union_specifier name: (type_identifier) @union)
        (enum_specifier name: (type_identifier) @enum)
        (type_definition declarator: (type_identifier) @typedef)
    """,
    "cpp": """
        (class_specifier name: (type_identifier) @class)
        (struct_specifier name: (type_identifier) @struct)
        (function_definition
          declarator: (function_declarator
            declarator: (identifier) @function))
        (namespace_definition name: (namespace_identifier) @namespace)
    """,
}


def is_available() -> bool:
    """Return True if tree-sitter is importable. Callers should use
    this as a guard before calling `find_definitions` and should fall
    back to regex (via `_definition_kind` in find_symbol.py) when it
    returns False."""
    return _TS_AVAILABLE


def supported_languages() -> frozenset[str]:
    """Return the set of lowercase GitHub-style language names for
    which we have a tree-sitter query defined. Callers should check
    membership before calling `find_definitions` and fall back to
    regex for anything else."""
    return frozenset(_QUERIES.keys())


@lru_cache(maxsize=32)
def _cached_query(language: str) -> tuple[Any, Any] | None:
    """Return (parser, compiled_query) for `language`, or None if
    unsupported. LRU-cached so we compile each query once per
    process. tree_sitter.Query objects are re-usable across calls;
    QueryCursor must be constructed fresh per query invocation."""
    if not _TS_AVAILABLE:
        return None
    if language not in _QUERIES:
        return None
    try:
        lang_obj = get_language(language)
        parser = get_parser(language)
        query = tree_sitter.Query(lang_obj, _QUERIES[language])
        return parser, query
    except Exception:  # noqa: BLE001
        return None


def find_definitions(
    source: str, name: str, language: str,
) -> list[Definition]:
    """Find definitions of `name` in `source` via a tree-sitter AST
    query for `language`.

    Returns an empty list when:
      * tree-sitter isn't importable
      * `language` isn't in our query table
      * the file parses cleanly but has no matching declaration
      * any unexpected error in the parsing/query pipeline

    Callers should treat an empty list as "fall through to the
    regex/fragment fallback" rather than "definitively no match."

    Deduplication: in a few languages the same declaration can be
    captured by multiple alternatives of the query (e.g. Python's
    `decorated_definition` wraps a plain `function_definition` so
    both patterns fire). We keep only the first capture per
    (line, column) tuple, which gives us one record per actual
    source position.
    """
    if not _TS_AVAILABLE or not source:
        return []
    cached = _cached_query(language.lower())
    if cached is None:
        return []
    parser, query = cached

    try:
        source_bytes = source.encode("utf-8", errors="replace")
        tree = parser.parse(source_bytes)
        cursor = tree_sitter.QueryCursor(query)
        matches = cursor.matches(tree.root_node)
    except Exception:  # noqa: BLE001
        return []

    results: list[Definition] = []
    seen: set[tuple[int, int]] = set()

    for _pattern_idx, captures in matches:
        for kind_label, nodes in captures.items():
            for node in nodes:
                try:
                    node_text = node.text.decode("utf-8", errors="replace")
                except Exception:  # noqa: BLE001
                    continue
                if node_text != name:
                    continue
                pos = (node.start_point[0], node.start_point[1])
                if pos in seen:
                    continue
                seen.add(pos)
                results.append(Definition(
                    name=node_text,
                    kind=kind_label,
                    line=node.start_point[0] + 1,
                    column=node.start_point[1] + 1,
                ))

    results.sort(key=lambda d: d.line)
    return results
