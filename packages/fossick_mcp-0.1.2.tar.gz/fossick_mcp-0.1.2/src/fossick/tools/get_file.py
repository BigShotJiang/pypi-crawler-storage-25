"""Tool: get_file — read file content from a GitHub repository."""


import base64
import re
from typing import Annotated

from mcp.types import ToolAnnotations
from pydantic import Field

from fossick.cache import cache, cache_key
from fossick.github_client import get_client
from fossick.hints import format_hints, generate_hints
from fossick.server import mcp
from fossick.tools._common import http_error_to_tool_error, split_repo


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
    # See search_code.py for why structured_output=False.
    structured_output=False,
)
async def get_file(
    repo: Annotated[str, Field(description="Repository in 'owner/name' format (e.g. 'modelcontextprotocol/python-sdk').")],
    path: Annotated[str, Field(description="File path within the repo.")],
    ref: Annotated[str, Field(description="Branch, tag, or commit SHA. Defaults to the default branch.")] = "",
    start_line: Annotated[int, Field(description="First line to show (1-indexed).")] = 0,
    end_line: Annotated[int, Field(description="Last line to show (1-indexed, inclusive).")] = 0,
    match: Annotated[str, Field(description="Show only lines containing this substring (case-insensitive). Surround with / for regex.")] = "",
    match_context: Annotated[int, Field(description="Context lines around each match.")] = 5,
) -> str:
    """Read file content from one file in a GitHub repository. Returns full file with line numbers, supports line range slicing (start_line/end_line) and substring/regex match filtering with context lines. Truncates files over 500 lines unless a range or match is specified. Use after locating a file via search_code, find_symbol, or repo_tree."""
    owner, name = split_repo(repo)
    try:
        # Cache key includes ref for immutability
        ttl = 3600 if ref and len(ref) == 40 else 300  # SHA = long TTL
        ck = cache_key("get_file", repo=repo, path=path, ref=ref or "")
        cached = await cache.get(ck)
        if cached is not None and not start_line and not match:
            return cached

        client = get_client()
        result = await client.get_contents(owner, name, path, ref=ref)

        # Handle directory responses
        if isinstance(result, list):
            entries = [f"  {'📁' if e.get('type') == 'dir' else '📄'} {e.get('name', '')}" for e in result[:50]]
            return f"`{path}` is a directory with {len(result)} entries:\n" + "\n".join(entries)

        content_b64 = result.get("content", "")
        encoding = result.get("encoding", "")
        if encoding == "base64" and content_b64:
            content = base64.b64decode(content_b64).decode("utf-8", errors="replace")
        else:
            content = content_b64

        size = result.get("size", 0)
        sha = result.get("sha", "")[:8]
        html_url = result.get("html_url", "")

        all_lines = content.split("\n")
        total_lines = len(all_lines)

        # Build header
        header = f"**{repo}** — `{path}`"
        if ref:
            header += f" @ `{ref}`"
        header += f"  ({size:,} bytes, {total_lines} lines, sha:{sha})"
        if html_url:
            header += f"\n{html_url}"

        # Apply line range filter
        if start_line and end_line:
            start_idx = max(0, start_line - 1)
            end_idx = min(total_lines, end_line)
            selected = all_lines[start_idx:end_idx]
            header += f"\nShowing lines {start_line}-{end_line}"
            numbered = [f"{i + start_line:4d} | {line}" for i, line in enumerate(selected)]
            output = header + "\n\n" + "\n".join(numbered)

        # Apply match filter
        elif match:
            # Check if it's a regex pattern (surrounded by /)
            if match.startswith("/") and match.endswith("/") and len(match) > 2:
                pat = re.compile(match[1:-1], re.IGNORECASE)
                is_match = lambda line: pat.search(line)  # noqa: E731
            else:
                match_lower = match.lower()
                is_match = lambda line: match_lower in line.lower()  # noqa: E731

            # Find matching lines and their context
            match_indices = set()
            for i, line in enumerate(all_lines):
                if is_match(line):
                    for j in range(max(0, i - match_context), min(total_lines, i + match_context + 1)):
                        match_indices.add(j)

            if not match_indices:
                output = header + f"\n\nNo lines matching `{match}` found in this file."
            else:
                sorted_indices = sorted(match_indices)
                header += f"\nShowing {len([i for i in range(total_lines) if is_match(all_lines[i])])} matches for `{match}`"

                numbered = []
                prev_idx = -2
                for idx in sorted_indices:
                    if idx > prev_idx + 1:
                        numbered.append("  ...")
                    marker = " >> " if is_match(all_lines[idx]) else "    "
                    numbered.append(f"{idx + 1:4d}{marker}| {all_lines[idx]}")
                    prev_idx = idx

                output = header + "\n\n" + "\n".join(numbered)

        # Full content with line numbers
        else:
            numbered = [f"{i + 1:4d} | {line}" for i, line in enumerate(all_lines)]
            # Truncate very large files
            if total_lines > 500:
                numbered = numbered[:500]
                numbered.append(f"\n... ({total_lines - 500} more lines, use start_line/end_line to read specific sections)")
            output = header + "\n\n" + "\n".join(numbered)

        params = {"repo": repo, "path": path}
        hints = generate_hints("get_file", params, result)
        output += format_hints(hints)

        if not start_line and not match:
            await cache.set(ck, output, ttl=ttl)
        return output

    except Exception as e:
        raise http_error_to_tool_error(
            e, tool="get_file", repo=repo, path=path, ref=ref,
        )
