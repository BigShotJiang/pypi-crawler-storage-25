"""Tool: repo_tree — view repository file structure with filtering."""


import fnmatch
from typing import Annotated

from mcp.types import ToolAnnotations
from pydantic import Field

from fossick.cache import cache, cache_key
from fossick.github_client import get_client
from fossick.hints import format_hints, generate_hints
from fossick.server import mcp
from fossick.tools._common import http_error_to_tool_error, split_repo

# Directories to auto-filter from tree output
_NOISE_DIRS = frozenset({
    ".git", "node_modules", "dist", "build", "__pycache__", ".venv",
    "venv", "vendor", ".tox", ".mypy_cache", ".pytest_cache",
    ".next", ".nuxt", "coverage",
})


def _depth_of(path: str) -> int:
    """Count nesting depth (0 = root-level file)."""
    return path.count("/")


def _format_size(size: int) -> str:
    if size < 1024:
        return f"{size}B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f}KB"
    return f"{size / (1024 * 1024):.1f}MB"


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
    # See search_code.py for why structured_output=False.
    structured_output=False,
)
async def repo_tree(
    repo: Annotated[str, Field(description="Repository in 'owner/name' format (e.g. 'modelcontextprotocol/python-sdk').")],
    path: Annotated[str, Field(description="Subdirectory to start from. Empty = root.")] = "",
    ref: Annotated[str, Field(description="Branch, tag, or commit SHA. Defaults to the default branch.")] = "",
    depth: Annotated[int, Field(description="How many levels deep to show (1-3).")] = 2,
    pattern: Annotated[str, Field(description="Glob filter for filenames (e.g. *.py). Dirs always shown.")] = "",
    show_sizes: Annotated[bool, Field(description="Include file sizes in the output.")] = False,
) -> str:
    """View the file tree of a GitHub repository or subdirectory. Recursive listing with depth control (1-3 levels), glob pattern filtering (e.g. *.py), and optional file sizes. Automatically filters noise directories (node_modules, __pycache__, .venv, dist, etc.). Use to understand project layout and discover key files before reading them with get_file."""
    owner, name = split_repo(repo)
    depth = max(1, min(3, depth))

    try:
        client = get_client()

        # Resolve ref to a tree SHA
        if ref:
            # Get the commit for this ref to find its tree SHA
            commits = await client.get_commits(owner, name, sha=ref, per_page=1)
            if not commits:
                return f"Error: ref `{ref}` not found in `{repo}`."
            tree_sha = commits[0]["commit"]["tree"]["sha"]
        else:
            # Use default branch
            repo_info = await client.get_repo(owner, name)
            default_branch = repo_info.get("default_branch", "main")
            commits = await client.get_commits(owner, name, sha=default_branch, per_page=1)
            if not commits:
                return f"Error: no commits found in `{repo}`."
            tree_sha = commits[0]["commit"]["tree"]["sha"]
            ref = default_branch

        ck = cache_key("repo_tree", repo=repo, sha=tree_sha, path=path, depth=depth, pattern=pattern or "")
        cached = await cache.get(ck)
        if cached is not None:
            return cached

        # Fetch full recursive tree
        result = await client.get_tree(owner, name, tree_sha, recursive=True)
        all_entries = result.get("tree", [])

        # Filter entries
        filtered = []
        file_count = 0
        dir_count = 0

        for entry in all_entries:
            entry_path = entry.get("path", "")
            entry_type = entry.get("type", "")

            # Filter by path prefix
            if path:
                if not entry_path.startswith(path + "/") and entry_path != path:
                    continue
                # Adjust depth relative to the path prefix
                relative = entry_path[len(path):].lstrip("/")
                entry_depth = relative.count("/")
            else:
                relative = entry_path
                entry_depth = _depth_of(entry_path)

            # Filter by depth
            if entry_depth >= depth:
                continue

            # Filter noise directories
            parts = entry_path.split("/")
            if any(p in _NOISE_DIRS for p in parts):
                continue

            # Filter by glob pattern (files only)
            if pattern and entry_type == "blob":
                filename = parts[-1] if parts else entry_path
                if not fnmatch.fnmatch(filename, pattern):
                    continue

            filtered.append(entry)
            if entry_type == "tree":
                dir_count += 1
            else:
                file_count += 1

        # Format output
        header = f"**{repo}**"
        if path:
            header += f" / `{path}`"
        header += f" @ `{ref}`"
        lines = [header, f"{file_count} files, {dir_count} directories", ""]

        # Sort in tree order: children after parent, dirs before files at each level
        def _tree_key(e: dict) -> str:
            parts = e["path"].split("/")
            # Tag each path segment: dirs sort before files via \x00 vs \x01
            tagged = []
            for i, part in enumerate(parts):
                is_last = i == len(parts) - 1
                if not is_last or e["type"] == "tree":
                    tagged.append(f"\x00{part}")
                else:
                    tagged.append(f"\x01{part}")
            return "/".join(tagged)

        filtered.sort(key=_tree_key)

        for entry in filtered[:300]:  # cap to prevent massive output
            entry_path = entry.get("path", "")
            entry_type = entry.get("type", "")

            # Show relative path if scoped to a subdirectory
            display_path = entry_path
            if path:
                display_path = entry_path[len(path):].lstrip("/")

            indent_level = display_path.count("/")
            indent = "  " * indent_level

            if entry_type == "tree":
                lines.append(f"{indent}📁 {display_path.rstrip('/').rsplit('/', 1)[-1]}/")
            else:
                name = display_path.rsplit("/", 1)[-1]
                size_str = ""
                if show_sizes:
                    size = entry.get("size", 0)
                    size_str = f" ({_format_size(size)})"
                lines.append(f"{indent}📄 {name}{size_str}")

        if len(filtered) > 300:
            lines.append(f"\n_(showing 300 of {len(filtered)} entries)_")

        params = {"repo": repo, "path": path}
        hints = generate_hints("repo_tree", params, {"file_count": file_count, "dir_count": dir_count})
        output = "\n".join(lines) + format_hints(hints)

        await cache.set(ck, output, ttl=600)
        return output

    except Exception as e:
        raise http_error_to_tool_error(
            e, tool="repo_tree", repo=repo, path=path, ref=ref,
        )
