"""Tool: search_repos — discover GitHub repositories by topic, language, popularity, or trending.

Scope: All of GitHub.
When to use: Finding repos by topic, language, popularity, activity, or trending repos.
"""


import asyncio
import math
import re
from datetime import datetime, timedelta, timezone
from typing import Annotated, Any

from mcp.types import ToolAnnotations
from pydantic import Field

from fossick.cache import cache, cache_key
from fossick.github_client import get_client
from fossick.hints import format_hints, generate_hints
from fossick.server import mcp
from fossick.tools._common import (
    REPO_SEARCH_QUALIFIERS,
    REPO_SEARCH_REDIRECTS,
    http_error_to_tool_error,
    validate_search_query,
)


# Regex for detecting a qualifier by name. Mirrors the validator's
# token-detection shape but restricted to a single qualifier — we
# strip quoted/regex-literal content first so a qualifier-shaped
# token inside a literal is ignored.
_QUOTED_DOUBLE_RE = re.compile(r'"[^"]*"')
_QUOTED_SINGLE_RE = re.compile(r"'[^']*'")
_REGEX_LITERAL_RE = re.compile(r"/[^/\n]+/")


# Qualifier classes for query-term extraction. The term-yielding set
# contains qualifiers whose VALUES are meaningful content words
# (e.g. `topic:postgres-operator` → "postgres" and "operator" are
# search-relevant). The non-term set is filters whose values are
# numeric/date/boolean and contribute nothing to literal relevance.
_TERM_YIELDING_QUALIFIERS = frozenset({"topic", "in", "language"})
_NON_TERM_QUALIFIERS = frozenset({
    "stars", "forks", "created", "pushed", "size", "followers",
    "is", "archived", "mirror", "fork", "template", "license",
    "repo", "user", "org",
})

# Stopwords stripped from extracted query terms. Kept tight — we only
# want to remove words that are common English glue, not
# domain-meaningful terms.
_QUERY_STOPWORDS = frozenset({
    "a", "an", "the", "of", "in", "on", "and", "or", "for", "to",
    "with", "is", "be", "at", "by", "as", "this", "that", "it",
    "i", "we", "description",
})


def _has_qualifier(query: str, qualifier: str) -> bool:
    """True if *query* contains a `<qualifier>:` token outside quotes/regex.

    Case-insensitive. Used to detect whether the caller has already
    specified something like `fork:` in their query so we don't
    override their explicit choice with a default.
    """
    if not query:
        return False
    stripped = _QUOTED_DOUBLE_RE.sub(" ", query)
    stripped = _QUOTED_SINGLE_RE.sub(" ", stripped)
    stripped = _REGEX_LITERAL_RE.sub(" ", stripped)
    pattern = re.compile(
        rf"(?:^|\s)-?{re.escape(qualifier)}:", re.IGNORECASE,
    )
    return bool(pattern.search(stripped))


def _build_full_query(
    base: str, topic: str, language: str, trending: bool,
) -> str:
    """Assemble a final GitHub repo-search query string.

    Convenience params (`topic`, `language`, `trending`) are appended as
    qualifiers to each sub-query — in multi-query mode, they apply
    uniformly across every phrasing so filters like `language:python`
    behave consistently regardless of which phrasing matched.

    Fork filter: if the caller hasn't specified a `fork:` preference
    anywhere in their query, `fork:false` is appended automatically.
    GitHub includes forks in repo-search results by default, which
    pollutes discovery shortlists with zero-star clones of the real
    target. Callers who specifically want forks can opt in with
    `fork:true` or `fork:only`, which we detect and leave alone.

    No `stars:>N` fallback: empty queries used to default to
    `stars:>1000`, which actively hid every small-but-quality gem
    from dev-session discovery. Now empty queries fall back to
    `is:public` (effectively "any public repo") and rely on
    client-side relevance ranking to surface the useful results.
    """
    parts: list[str] = []
    if base:
        parts.append(base)
    if topic:
        parts.append(f"topic:{topic}")
    if language:
        parts.append(f"language:{language}")
    if trending:
        seven_days_ago = (
            datetime.now(timezone.utc) - timedelta(days=7)
        ).strftime("%Y-%m-%d")
        parts.append(f"created:>{seven_days_ago}")

    assembled = " ".join(parts) if parts else "is:public"
    if not _has_qualifier(assembled, "fork"):
        assembled = f"{assembled} fork:false"
    return assembled


def _extract_query_terms(
    sub_queries: list[str],
    *,
    language: str = "",
    topic: str = "",
) -> set[str]:
    """Pull content words from a list of sub-queries for relevance scoring.

    Strips GitHub search qualifiers (stars:, fork:, etc.) but KEEPS
    the values of term-yielding ones (topic:, in:, language:) because
    those values are what the caller cares about. Content inside
    quoted substrings is unwrapped and included as individual words.
    Stopwords and single-character tokens are removed.

    For example, the sub-query list::

        ['in:description "Postgres operator"',
         'in:description "PostgreSQL" in:description "Kubernetes"',
         'topic:postgres-operator']

    yields the term set::

        {"postgres", "operator", "postgresql", "kubernetes", "postgres-operator"}

    plus any convenience-param values (e.g. ``language="go"`` adds
    ``"go"``).
    """
    terms: set[str] = set()
    if language:
        terms.add(language.lower())
    if topic:
        terms.add(topic.lower())
        terms.update(p for p in re.split(r"[-_/]", topic.lower()) if p)

    for raw_query in sub_queries:
        # Unwrap quoted substrings so their content becomes regular
        # tokens during the whitespace split below.
        content = re.sub(r'"([^"]+)"', r"\1", raw_query)
        content = re.sub(r"'([^']+)'", r"\1", content)

        for raw_token in re.split(r"\s+", content):
            token = raw_token.strip().lstrip("-")
            if not token:
                continue
            if ":" in token:
                key, _, value = token.partition(":")
                key_lower = key.lower()
                if key_lower in _NON_TERM_QUALIFIERS:
                    continue
                if key_lower in _TERM_YIELDING_QUALIFIERS:
                    if value:
                        terms.add(value.lower())
                        terms.update(
                            p for p in re.split(r"[-_/]", value.lower())
                            if p
                        )
                    continue
                # Unrecognized qualifier-shaped token — treat both
                # halves as content rather than drop them.
                if key_lower:
                    terms.add(key_lower)
                if value:
                    terms.add(value.lower())
                continue
            cleaned = re.sub(r"[^\w-]", "", token.lower())
            if cleaned:
                terms.add(cleaned)
                for part in re.split(r"[-_]", cleaned):
                    if part:
                        terms.add(part)

    return {
        t for t in terms
        if t
        and t not in _QUERY_STOPWORDS
        and len(t) > 1
        and not t.isdigit()
    }


def _desc_hit_count(item: dict[str, Any], terms: set[str]) -> int:
    """Count how many query terms appear in the repo's description."""
    desc = (item.get("description") or "").lower()
    if not desc or not terms:
        return 0
    return sum(1 for term in terms if term in desc)


def _topic_hit_count(item: dict[str, Any], terms: set[str]) -> int:
    """Count how many query terms appear in the repo's topic tags.

    A term counts as a hit if it exactly matches a topic slug OR
    appears as a hyphen-delimited component of one (so query term
    "postgres" hits on `topic:postgres-operator`). This mirrors the
    way topics are normalized on GitHub and matches the behavior
    validated in the rank-experiment benchmark.
    """
    topics = {t.lower() for t in (item.get("topics") or [])}
    if not topics or not terms:
        return 0
    hits = 0
    for term in terms:
        if term in topics:
            hits += 1
            continue
        for topic in topics:
            if term in topic.split("-"):
                hits += 1
                break
    return hits


def _recency_bonus(item: dict[str, Any]) -> float:
    """Return 0-3 depending on how recently the repo was pushed.

    Active > stale for dev-session discovery: a repo that hasn't been
    touched in 6 months is probably abandoned and should rank below a
    similarly-relevant one that was pushed this week. Scale is
    deliberately coarse (0/1/2/3) because finer gradation would
    overwhelm the description-hit signal.
    """
    pushed = item.get("pushed_at") or ""
    if not pushed:
        return 0.0
    try:
        dt = datetime.fromisoformat(pushed.replace("Z", "+00:00"))
    except ValueError:
        return 0.0
    days_ago = (datetime.now(timezone.utc) - dt).days
    if days_ago <= 30:
        return 3.0
    if days_ago <= 90:
        return 2.0
    if days_ago <= 180:
        return 1.0
    return 0.0


def _compute_relevance_score(
    entry: dict[str, Any],
    terms: set[str],
) -> float:
    """Composite dev-session discovery score for one merged entry.

    Formula (validated against 6 test queries in
    benchmarks/rank_experiment.py — see the session summary for the
    full scoring comparison):

        desc_hits * 3    — primary: natural-language match
      + topic_hits * 2   — secondary: explicit categorization
      + match_count * 2  — cross-phrasing robustness
      + recency_bonus    — alive > abandoned (0-3)
      + 0.5 * log10(stars+1)
                         — weak star tiebreak, NOT a driver

    Why these weights: description is the primary signal because
    maintainers write descriptions to convey what their project does,
    and a literal match there is the strongest "about X" evidence.
    Topics × 2 because tags are deliberate but sparse. Match count × 2
    because cross-phrasing agreement is a robustness signal, but
    shouldn't outrank a strong literal match that's phrase-fragile.
    Stars enter at half-weight through a log scale so they can break
    ties between otherwise-equivalent candidates without letting a
    huge-but-off-topic repo dominate the rank. This half-weight was
    the specific fix that made `kbwo/ccmanager` (994★, literal match)
    outrank `sickn33/antigravity-awesome-skills` (32k★, wrong
    category) on the Claude Code management CLI benchmark query.
    """
    item = entry["item"]
    desc = _desc_hit_count(item, terms)
    topics = _topic_hit_count(item, terms)
    match_count = len(entry.get("matched_by", []))
    recency = _recency_bonus(item)
    stars = item.get("stargazers_count", 0) or 0
    log_stars = math.log10(stars + 1)
    return (
        desc * 3.0
        + topics * 2.0
        + match_count * 2.0
        + recency
        + 0.5 * log_stars
    )


def _rerank_by_relevance(
    entries: list[dict[str, Any]],
    terms: set[str],
) -> list[dict[str, Any]]:
    """Re-sort a merged result list by composite relevance score.

    Stable — entries with equal scores preserve their incoming order,
    which is the match_count-descending order emitted by
    _merge_subquery_results. That means a tied pair falls back to
    "robust phrasing match wins" which is a sensible secondary key.
    """
    if not terms:
        return entries
    return sorted(
        entries,
        key=lambda e: -_compute_relevance_score(e, terms),
    )


def _partition_by_tier(
    ranked: list[dict[str, Any]], num_queries: int,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    """Split a flat ranked list into three tiers by match count.

    Tier definitions, for a multi-query run with N queries:

      - **robust**: match_count == N (every phrasing agrees)
      - **majority**: 1 < match_count < N (most but not all phrasings)
      - **fragile**: match_count == 1 (exactly one phrasing surfaced
        this repo — would have been missed by a single-query search)

    Input must already be sorted by (match_count desc, stars desc);
    _merge_subquery_results produces that order. Within each tier
    the existing order is preserved, so the fragile tier ends up
    sorted by stars descending automatically — the high-star
    phrase-fragile finds (the blind-spot catches) land at the top of
    the fragile section.
    """
    robust: list[dict[str, Any]] = []
    majority: list[dict[str, Any]] = []
    fragile: list[dict[str, Any]] = []
    for entry in ranked:
        mc = len(entry["matched_by"])
        if mc >= num_queries:
            robust.append(entry)
        elif mc > 1:
            majority.append(entry)
        else:
            fragile.append(entry)
    return robust, majority, fragile


_ALERT_CAP: int = 3


def _phrase_fragile_alerts(
    fragile: list[dict[str, Any]],
    *,
    cap: int = _ALERT_CAP,
) -> list[dict[str, Any]]:
    """Return the top phrase-fragile entries to surface above the fold.

    Input is expected to already be sorted in the ranking order the
    rest of the tool is using (relevance-descending by default), so
    the alert is simply the first *cap* entries of the fragile tier.

    Why this matters: in the live Rust TUI stress test, the old
    stars-threshold logic produced 19 alert entries — no longer
    salient. Capping at *cap* (default 3) forces the alert to name
    only the most useful catches, which the human's eye can actually
    parse. A fragile tier of 20+ entries still gets displayed in
    full in the fragile section below; the alert is the "above the
    fold" layer.
    """
    if not fragile:
        return []
    return list(fragile[:cap])


def _merge_subquery_results(
    query_labels: list[str],
    sub_results: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Merge per-sub-query result dicts into a deduped, ranked list.

    Returns a list of entries, each shaped as
    ``{"item": <github_repo_dict>, "matched_by": [<label>, ...]}``,
    ordered by match-count descending then star-count descending.

    Merge invariants:
      - Repos are deduped by `full_name`.
      - A repo's `matched_by` list preserves the *first-seen order*
        of labels that surfaced it, so the per-result annotation in
        the final output is deterministic.
      - Empty-string labels (the fallback-default-query path) are
        not added to `matched_by` so they don't clutter the
        ``Found via:`` line when the caller passed no real phrasings.
      - Duplicate labels from the same sub-query don't double-count
        (defensive — shouldn't happen in practice).

    Ranking: repos matched by more phrasings float above repos
    matched by fewer, with stars breaking ties. This is the
    robustness signal — an option found by every phrasing in a
    shortlisting run is more confidently in-scope than one found by
    only the narrowest phrasing.
    """
    merged: dict[str, dict[str, Any]] = {}
    for label, sub in zip(query_labels, sub_results):
        for item in sub.get("items", []):
            name = item.get("full_name", "")
            if not name:
                continue
            entry = merged.get(name)
            if entry is None:
                merged[name] = {
                    "item": item,
                    "matched_by": [label] if label else [],
                }
            elif label and label not in entry["matched_by"]:
                entry["matched_by"].append(label)

    return sorted(
        merged.values(),
        key=lambda e: (
            -len(e["matched_by"]),
            -(e["item"].get("stargazers_count", 0)),
        ),
    )


def _format_repo(
    item: dict[str, Any],
    lines: list[str],
    *,
    matched_by: list[str] | None = None,
    total_queries: int = 1,
) -> None:
    """Append the multi-line block for one repo to *lines*.

    In single-query mode (`matched_by is None`) the block is the base
    header + description + metadata. In multi-query mode it adds two
    extra annotations: a `matched K/N` suffix on the header so the
    caller can tell at a glance whether a candidate was found by every
    phrasing (robust) or by just one (phrase-fragile, easy to miss),
    and a `Found via:` line naming the specific phrasings that
    surfaced it — useful for self-correction on future shortlisting
    runs.
    """
    name = item.get("full_name", "")
    desc = (item.get("description") or "").strip()
    stars = item.get("stargazers_count", 0)
    lang = item.get("language") or "—"
    # YYYY-MM-DD slice of the ISO-8601 pushed_at timestamp; the full
    # timestamp is overkill for a listing and date alone is enough
    # signal to tell active from abandoned.
    pushed = (item.get("pushed_at") or "")[:10]
    archived = bool(item.get("archived"))
    topics = item.get("topics") or []
    # GitHub returns license as a nested object; spdx_id is the short
    # form (MIT, Apache-2.0). "NOASSERTION" means GitHub couldn't
    # detect a license — treat as absent rather than cluttering the
    # output.
    license_obj = item.get("license") or {}
    license_id = (
        license_obj.get("spdx_id")
        if isinstance(license_obj, dict)
        else None
    )
    if license_id == "NOASSERTION":
        license_id = None
    homepage = (item.get("homepage") or "").strip()

    header = f"**{name}** · {lang} · {stars:,}★"
    if pushed:
        header += f" · pushed {pushed}"
    if archived:
        header += " · archived"
    if matched_by is not None:
        header += f" · matched {len(matched_by)}/{total_queries}"
    lines.append(header)

    if desc:
        lines.append(f"  {desc}")

    meta_parts: list[str] = []
    if topics:
        meta_parts.append(f"Topics: {', '.join(topics)}")
    if license_id:
        meta_parts.append(f"License: {license_id}")
    if homepage:
        meta_parts.append(f"Homepage: {homepage}")
    if meta_parts:
        lines.append(f"  {' · '.join(meta_parts)}")

    if matched_by is not None:
        # Show which exact phrasings found this repo, so the caller can
        # tell which of their phrasings are carrying unique value.
        quoted = ", ".join(f'"{q}"' for q in matched_by)
        lines.append(f"  Found via: {quoted}")

    lines.append("")


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
    # See search_code.py for why structured_output=False.
    structured_output=False,
)
async def search_repos(
    query: Annotated[str, Field(description="Repository search query. Keep short (1-2 terms) — AND logic means more terms = fewer results. Use topic: for ecosystem discovery. Repo-search qualifiers: in:, repo:, user:, org:, size:, followers:, forks:, stars:, created:, pushed:, language:, topic:, license:, is:, mirror:, archived:, template:. File/content qualifiers (path:, filename:, extension:, content:, symbol:) are NOT supported by repo search — use `search_code` for those.")] = "",
    queries: Annotated[list[str], Field(description="List of query phrasings to run in parallel and merge. STRONGLY PREFERRED over `query` for shortlisting work — pass 2-4 different phrasings of the same concept (e.g. ['in:description \"Postgres operator\"', 'in:description \"PostgreSQL\" in:description \"Kubernetes\"', 'topic:postgres-operator']) and the tool will run them concurrently, dedupe by repo, and rank the union. Each result is annotated with `matched K/N` showing how many of your phrasings found it — a popular option found by only one phrasing would have been missed by a single-query call. If both `query` and `queries` are set, `query` is prepended to the list.")] = [],
    topic: Annotated[str, Field(description="Filter by topic.")] = "",
    language: Annotated[str, Field(description="Filter by programming language.")] = "",
    trending: Annotated[bool, Field(description="If true, find repos created in the last 7 days sorted by stars.")] = False,
    sort: Annotated[str, Field(description="Sort by: stars, forks, updated, or best match.")] = "best match",
    order: Annotated[str, Field(description="Sort order: asc or desc.")] = "desc",
    page: Annotated[int, Field(description="Page number.")] = 1,
    per_page: Annotated[int, Field(description="Results per page (max 100).")] = 30,
) -> str:
    """Discover GitHub repositories — the go-to tool for finding real, maintained, coherent repos during a coding session. Optimized for "find reference implementations / prior art / learning material / small-but-quality gems in an ecosystem," NOT for "rank by raw popularity." Returns per-result: name, full description, topics, primary language, star count, last-push date, license, homepage, and archived status.

    Dev-session use cases this serves well:
      • "Rust agent harness — what are my options?" — finds frameworks/harnesses ranked by literal relevance, not star count
      • "Python async rate limiter — show me existing libraries" — dedicated libs beat big frameworks
      • "What's the landscape of LLM observability tools?" — surfaces the actual category leaders
      • "Is there already a tool for managing Claude Code sessions?" — hyper-specific gem hunting, small focused CLIs float up
      • "What's new in this ecosystem this week?" — set `trending=True` for repos created in the last 7 days
      • "Disambiguate a name the user mentioned" — one-hop metadata lookup

    Ranking (multi-query mode): composite relevance score combining literal description match × 3, topic-tag match × 2, cross-phrasing robustness × 2, recency bonus (0-3), and log-scaled stars at half-weight. Stars are a TIEBREAK, not a driver — this is why a 500-star literal-match repo can outrank a 40,000-star repo that doesn't contain the query terms in its description. Tested against 6 dev-session queries in benchmarks/rank_experiment.py; composite scoring produced the best top-5 on 5/6 queries and consistently surfaced small-but-quality gems that star-first ranking buried.

    Query sharpness — most→least noisy:
      • `topic:X` — self-assigned tags. Noisy for umbrella terms (e.g. `topic:mcp` returns opportunistic taggers like n8n). Sharp for tight niches (`topic:ratatui`).
      • `in:readme "phrase"` — matches any mention in the README. Medium.
      • `in:description "phrase"` — matches repos whose short description contains the phrase. Sharpest, but note that GitHub does literal substring matching — so `"embeddings database"` will also match "embedded database" (burned in testing). Prefer specific, domain-meaningful phrases.

    SHORTLISTING — always use `queries=[...]` with 2-4 phrasings. Single-phrase `in:description` is sharp but narrow; popular options routinely describe themselves with different wording. For example, `in:description "Postgres operator"` returns Zalando's postgres-operator (5k★) but misses CloudNativePG (8k★), which describes itself as "Kubernetes-native PostgreSQL." Passing both phrasings via `queries=` runs them in parallel, dedupes by repo, and annotates each result with `matched K/N`. Recipe for concept X in language L: `queries=['in:description "X" language:L', 'in:description "X synonym" language:L', 'topic:X-slug language:L']`.

    Other tips: keep queries short (GitHub uses AND logic — more terms = fewer results). Use the `language` filter instead of putting the language in the query. Use `archived:false` to exclude abandoned repos. Use `pushed:>YYYY-MM-DD` to filter by activity. For strict popularity filtering (production dependency shortlisting), add `stars:>N` explicitly — the tool no longer applies a star floor by default because gem-finding needs to see small repos.

    NOT for: searching code inside repos (use `search_code`), fetching a repo you already know by name (use `get_file`/`repo_tree`), or authoritative library popularity (check package registries via `search_packages`).

    IMPORTANT: repo search does NOT support file-level qualifiers like path:, filename:, extension:, content:, symbol: — GitHub silently matches them as literal content, giving misleading results with no error. Use `search_code` for those.
    """
    try:
        # Build the ordered, deduped list of effective sub-queries.
        # `query` (if set) is prepended to `queries` so both params can
        # be combined — callers shortlisting with multi-phrasing should
        # prefer passing everything via `queries` for clarity.
        effective_queries: list[str] = []
        seen: set[str] = set()
        for q in [query, *queries]:
            if not q or q in seen:
                continue
            seen.add(q)
            effective_queries.append(q)

        # Validate every sub-query before any network call. A malformed
        # phrasing in a multi-query shortlisting run should fail loudly
        # and name the specific bad token, not silently drop one lane
        # of the merge.
        for q in effective_queries:
            validate_search_query(
                q,
                tool="search_repos",
                allowed=REPO_SEARCH_QUALIFIERS,
                redirects=REPO_SEARCH_REDIRECTS,
            )

        # Trending mode overrides sort/order globally, not per-query —
        # sorting by stars of repos created in the last 7 days is a
        # global intent, not per-phrasing.
        if trending:
            sort = "stars"
            order = "desc"

        # If no query was supplied at all, fall back to the legacy
        # default so the tool still returns something sensible.
        if not effective_queries:
            full_queries = [
                _build_full_query("", topic, language, trending),
            ]
            # Synthetic label for the merged-output "Found via" line —
            # only used if we somehow end up in multi-query mode with
            # no real queries, which shouldn't happen but we guard.
            query_labels = [""]
        else:
            full_queries = [
                _build_full_query(q, topic, language, trending)
                for q in effective_queries
            ]
            query_labels = effective_queries

        num_queries = len(full_queries)
        client = get_client()

        async def _run_sub_query(fq: str) -> dict[str, Any]:
            """Run one fully-qualified query, with per-sub-query caching.

            Cached at the raw-API-result level (not the formatted
            output) so that shortlisting calls reusing the same
            phrasing in different sessions hit the cache for each
            individual sub-query independently.
            """
            ck = cache_key(
                "search_repos_raw",
                query=fq,
                sort=sort,
                order=order,
                page=page,
                per_page=per_page,
            )
            cached_raw = await cache.get(ck)
            if cached_raw is not None:
                return cached_raw
            sub = await client.search_repos(
                fq, sort=sort, order=order, page=page, per_page=per_page,
            )
            await cache.set(ck, sub, ttl=120)
            return sub

        sub_results: list[dict[str, Any]] = await asyncio.gather(
            *(_run_sub_query(fq) for fq in full_queries)
        )

        merged = _merge_subquery_results(query_labels, sub_results)

        # Extract content words from the caller's queries so the
        # relevance scorer has something to match against. This is
        # what lets the tool surface literal description matches
        # (the dev-session discovery primary signal) instead of
        # defaulting to raw star count.
        query_terms = _extract_query_terms(
            effective_queries or [query] if query else effective_queries,
            language=language,
            topic=topic,
        )

        # Rerank the merged list by composite relevance score. Match
        # count-descending ordering from the merge is preserved as
        # a stable tiebreak when scores are equal. Partitioning into
        # tiers (done next) uses match_count, so the tier shape is
        # unchanged; only the *within-tier* ordering changes.
        ranked = _rerank_by_relevance(merged, query_terms)
        unique_count = len(ranked)

        lines: list[str] = []

        if num_queries > 1:
            # Multi-query mode: cluster into three match-count tiers
            # so the reader can distinguish "every phrasing agrees"
            # (high confidence) from "only one phrasing caught this"
            # (phrase-fragile — the blind-spot catches). Within each
            # tier, entries are ordered by relevance score (from the
            # rerank above) so literal-match gems rise above
            # high-star-but-off-topic noise.
            header_line = (
                f"**Found {unique_count} unique repositories** "
                f"(union of {num_queries} queries, showing page {page})"
            )
            lines.append(header_line)

            robust, majority, fragile = _partition_by_tier(
                ranked, num_queries,
            )

            # Alert line: top-3 phrase-fragile entries by relevance
            # score, naming the blind-spot catches the multi-query
            # merge saved from invisibility. Capped at 3 because
            # longer lists stop being an alert and start being a
            # second result list — the live Rust TUI test produced a
            # 19-entry alert under the old stars-threshold logic.
            alerts = _phrase_fragile_alerts(fragile)
            if alerts:
                lines.append("")
                alert_names = ", ".join(
                    f"{e['item'].get('full_name', '?')} "
                    f"({e['item'].get('stargazers_count', 0):,}★)"
                    for e in alerts
                )
                lines.append(
                    "**Phrase-fragile relevant finds** "
                    "(matched by only one phrasing — would have been "
                    "missed by a single-query search): "
                    + alert_names
                )

            # Tier 1 — robust (all phrasings agree)
            if robust:
                lines.append("")
                lines.append(
                    f"## Matched by all {num_queries} queries "
                    f"(high confidence: {len(robust)} result"
                    f"{'s' if len(robust) != 1 else ''})"
                )
                lines.append("")
                for entry in robust:
                    _format_repo(
                        entry["item"],
                        lines,
                        matched_by=entry["matched_by"],
                        total_queries=num_queries,
                    )

            # Tier 2 — majority (most but not all phrasings)
            if majority:
                lines.append(
                    f"## Matched by most queries "
                    f"(K/{num_queries}: {len(majority)} result"
                    f"{'s' if len(majority) != 1 else ''})"
                )
                lines.append("")
                for entry in majority:
                    _format_repo(
                        entry["item"],
                        lines,
                        matched_by=entry["matched_by"],
                        total_queries=num_queries,
                    )

            # Tier 3 — fragile (exactly one phrasing matched)
            if fragile:
                lines.append(
                    f"## Phrase-fragile finds "
                    f"(matched by only 1/{num_queries} — "
                    f"{len(fragile)} result"
                    f"{'s' if len(fragile) != 1 else ''}; "
                    "relevance-ranked, so the most literally on-target "
                    "catches from a single phrasing appear first)"
                )
                lines.append("")
                for entry in fragile:
                    _format_repo(
                        entry["item"],
                        lines,
                        matched_by=entry["matched_by"],
                        total_queries=num_queries,
                    )
        else:
            # Single-query mode: unchanged legacy output. Flat list,
            # "Found N repositories" wording, no tier clustering.
            legacy_total = sub_results[0].get("total_count", 0)
            header_line = (
                f"**Found {legacy_total} repositories** "
                f"(showing page {page})"
            )
            lines.append(header_line)
            lines.append("")
            for entry in ranked:
                _format_repo(
                    entry["item"],
                    lines,
                    matched_by=None,
                    total_queries=num_queries,
                )

        # Hint params carry num_queries so the multi-query nudge rule
        # in hints.py fires only in single-query mode.
        hint_result: dict[str, Any] = {
            "total_count": (
                unique_count
                if num_queries > 1
                else sub_results[0].get("total_count", 0)
            ),
        }
        hints = generate_hints(
            "search_repos",
            {"num_queries": num_queries},
            hint_result,
        )
        return "\n".join(lines) + format_hints(hints)

    except Exception as e:
        raise http_error_to_tool_error(
            e, tool="search_repos", query=query,
        )
