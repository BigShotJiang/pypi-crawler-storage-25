"""Shared helpers for fossick tool implementations."""

import re

import httpx

from mcp.server.fastmcp.exceptions import ToolError

# Qualifier allowlists per GitHub Search API endpoint.
#
# GitHub exposes two distinct Search APIs that fossick v2 uses — code
# search and repository search — each with its own set of supported
# qualifiers. When a freeform query is forwarded to the wrong endpoint,
# GitHub does NOT return an error for unknown qualifiers: it silently
# matches them as literal content. That's the silent-failure bug the
# classifier on the output side was built to prevent on *outputs*; this
# is the symmetric protection for *inputs*.
#
# These sets are intentionally endpoint-specific. Sharing them across
# tools (which was the original sin that leaked `stars:>N` from
# search_repos into the search_code docstring) would re-introduce the
# same bug.

#: Qualifiers supported by GitHub's code-search endpoint.
#: https://docs.github.com/en/search-github/github-code-search/understanding-github-code-search-syntax
CODE_SEARCH_QUALIFIERS: frozenset[str] = frozenset({
    "repo", "org", "user", "path", "language", "content", "symbol",
    "is", "size", "in", "filename", "extension",
})

#: Qualifiers supported by GitHub's repository-search endpoint.
#: https://docs.github.com/en/search-github/searching-on-github/searching-for-repositories
REPO_SEARCH_QUALIFIERS: frozenset[str] = frozenset({
    "in", "repo", "user", "org", "size", "followers", "forks", "stars",
    "created", "pushed", "language", "topic", "topics", "license", "is",
    "mirror", "archived", "template", "good-first-issues",
    "help-wanted-issues", "sponsorable",
})

# Redirect hints — per-qualifier, per-source-tool — explaining where a
# misapplied qualifier actually belongs. The keys are the forbidden
# qualifier names; values are fragments appended to the error message so
# the model is told *which other fossick tool* to chain to instead.

CODE_SEARCH_REDIRECTS: dict[str, str] = {
    "stars": "repository popularity is not filterable in code search — use `search_repos` with `stars:>N`",
    "pushed": "repository activity is not filterable in code search — use `search_repos` with `pushed:>DATE`",
    "forks": "use `search_repos` with `forks:>N` (code search only supports `is:fork`)",
    "fork": "use `is:fork` in code search (not `fork:true`)",
    "archived": "use `is:archived` in code search (not `archived:true`)",
    "created": "repo creation date is not filterable in code search — use `search_repos` with `created:>DATE`",
    "updated": "use `search_repos` with `pushed:>DATE` (code search has no updated qualifier)",
    "topic": "topic filtering is not available in code search — use `search_repos` with `topic:NAME`",
    "topics": "topic filtering is not available in code search — use `search_repos` with `topic:NAME`",
    "license": "license filtering is not available in code search — use `search_repos` with `license:SPDX_ID`",
}

REPO_SEARCH_REDIRECTS: dict[str, str] = {
    "path": "file path filtering is not available in repo search — use `search_code` with `path:FOO`",
    "filename": "filename filtering is not available in repo search — use `search_code` with `filename:FOO`",
    "extension": "extension filtering is not available in repo search — use `search_code` with `extension:FOO`",
    "content": "content filtering is not available in repo search — use `search_code` with `content:FOO`",
    "symbol": "symbol search is not available in repo search — use `search_code` with `symbol:FOO` or `find_symbol`",
}

# Regex for extracting the qualifier name from a single token. Anchored at
# the start so we only match tokens whose *first* word is a qualifier;
# this avoids false positives on URLs (e.g. `http://example.com`) which
# never appear at the start of a token-split element unless the LLM
# really dropped a raw URL into the query. A leading `-` is consumed so
# negation (e.g. `-language:go`) validates correctly.
_QUALIFIER_TOKEN_RE = re.compile(r"^-?([A-Za-z][A-Za-z_-]*):")

# Pre-stripped substitutions: quoted strings (both "..." and '...') and
# /.../ regex literals are replaced with spaces before qualifier
# extraction so that qualifier-shaped text inside them is correctly
# treated as literal content, not as a qualifier.
_QUOTED_DOUBLE_RE = re.compile(r'"[^"]*"')
_QUOTED_SINGLE_RE = re.compile(r"'[^']*'")
_REGEX_LITERAL_RE = re.compile(r"/[^/\n]+/")


def _extract_qualifier_names(query: str) -> list[str]:
    """Return the ordered list of qualifier names used in *query*.

    Strips quoted strings and /regex/ literals first so qualifier-shaped
    text inside them is ignored. Splits on whitespace and checks each
    token; only tokens whose *first* word is an identifier followed by a
    colon are considered qualifiers. Deduplicated in first-seen order.
    """
    stripped = _QUOTED_DOUBLE_RE.sub(" ", query)
    stripped = _QUOTED_SINGLE_RE.sub(" ", stripped)
    stripped = _REGEX_LITERAL_RE.sub(" ", stripped)

    seen: set[str] = set()
    ordered: list[str] = []
    for token in stripped.split():
        match = _QUALIFIER_TOKEN_RE.match(token)
        if not match:
            continue
        name = match.group(1).lower()
        if name in seen:
            continue
        seen.add(name)
        ordered.append(name)
    return ordered


def validate_search_query(
    query: str,
    *,
    tool: str,
    allowed: frozenset[str],
    redirects: dict[str, str] | None = None,
) -> None:
    """Raise :class:`ToolError` if *query* uses qualifiers outside *allowed*.

    GitHub's search endpoints silently match unknown qualifiers as
    literal content rather than returning an error. For example, passing
    ``stars:>100`` to the code-search API does not filter by repository
    popularity — it matches files whose source literally contains the
    substring ``"stars:>100"``. The resulting response has HTTP 200, a
    non-empty body, and completely wrong semantics. An LLM reading the
    output has no way to tell the query was broken.

    This helper catches that class of bug before the call is made. It
    scans the freeform query portion for qualifier-shaped tokens and
    raises a ToolError that:

      1. names the invalid qualifier(s),
      2. explains *why* they're invalid (GitHub silent matching),
      3. for well-known mis-applications, points at the right tool (e.g.
         ``stars:>N`` on code search → ``search_repos``),
      4. lists the qualifiers that ARE valid for this endpoint.

    The `allowed` set is endpoint-specific — code search, repo search,
    and issue/PR search each have their own, exposed as
    ``CODE_SEARCH_QUALIFIERS``, ``REPO_SEARCH_QUALIFIERS``, and
    ``ISSUE_SEARCH_QUALIFIERS``. Passing the wrong set would re-enable
    the exact bug this helper exists to prevent, so callers must choose
    deliberately at the call site.
    """
    if not query:
        return

    used = _extract_qualifier_names(query)
    violations = [name for name in used if name not in allowed]
    if not violations:
        return

    hints = redirects or {}
    lines = [
        f"Invalid qualifier(s) in `{tool}` query: "
        + ", ".join(f"`{v}:`" for v in violations)
        + ". GitHub accepts these without error but silently matches "
        "them as literal content, not as filters — the results you get "
        "back will be misleading."
    ]
    for name in violations:
        hint = hints.get(name)
        if hint:
            lines.append(f"  • `{name}:` → {hint}")
    allowed_display = ", ".join(
        f"`{q}:`" for q in sorted(allowed)
    )
    lines.append(f"Valid qualifiers for `{tool}`: {allowed_display}.")
    lines.append("Not retryable until the query is corrected.")
    raise ToolError("\n".join(lines))


def split_repo(repo: str) -> tuple[str, str]:
    """Parse a ``"owner/name"`` string into ``(owner, name)``.

    Every fossick tool that targets a single repository takes its repo as
    a combined ``"owner/name"`` string. This helper validates the format and
    splits it, raising a clear :class:`ToolError` on malformed input so the
    caller (typically an LLM) gets an actionable message instead of a raw
    Pydantic validation error or an HTTP 404.
    """
    if not isinstance(repo, str) or not repo.strip():
        raise ToolError(
            "The `repo` parameter is required and must be a non-empty string "
            "in 'owner/name' format (e.g. 'modelcontextprotocol/python-sdk')."
        )
    parts = repo.strip().split("/")
    if len(parts) != 2 or not parts[0] or not parts[1]:
        raise ToolError(
            f"Invalid `repo` value: {repo!r}. "
            "Expected 'owner/name' format (e.g. 'modelcontextprotocol/python-sdk')."
        )
    return parts[0], parts[1]


def http_error_to_tool_error(
    exc: Exception,
    *,
    tool: str,
    repo: str = "",
    path: str = "",
    ref: str = "",
    query: str = "",
) -> ToolError:
    """Convert a raw httpx/network exception into an LLM-actionable ToolError.

    Fossick tools call GitHub through ``httpx``. When something goes wrong,
    FastMCP catches the raised :class:`ToolError` and forwards its string to
    the model. The default ``f"Error ...: {e}"`` wrap loses the HTTP status,
    looks identical for unrelated failures (auth vs not-found vs rate limit),
    and gives the model nothing to act on — so it retries the same call in a
    tight loop. Session log analysis showed this accounted for ~40 of the
    remaining errored fossick calls (27x401, 9x404, 3x422, 1x500).

    This helper inspects the exception, picks the most likely root cause from
    the HTTP status, and returns a ToolError whose message:

      1. names what failed (tool, repo, path) in plain English,
      2. explains *why* (auth, rate limit, missing path, bad query),
      3. tells the model exactly what to do next — which other fossick tool
         to chain to, or that the error is not retryable until the input is
         fixed.

    A pre-existing :class:`ToolError` (e.g. raised by ``split_repo`` inside a
    try block in some future refactor) is passed through unchanged so we
    don't double-wrap an already-actionable message.
    """
    if isinstance(exc, ToolError):
        return exc

    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        repo_label = f"`{repo}`" if repo else "the requested resource"

        if status == 401:
            return ToolError(
                f"Authentication failed for {repo_label} during `{tool}`. "
                "Either the repo is private and your token can't see it, or "
                "your GitHub token is missing the `repo` scope. Run "
                "`gh auth status` to check. Not retryable until the token "
                "is fixed."
            )

        if status == 403:
            remaining = exc.response.headers.get("X-RateLimit-Remaining", "?")
            body_lower = (exc.response.text or "").lower()
            if "rate limit" in body_lower or remaining == "0":
                # Prefer Retry-After (seconds) over X-RateLimit-Reset (epoch)
                # — secondary rate limit responses set Retry-After and it's
                # the directly actionable number for a model to wait on.
                retry_after = exc.response.headers.get("Retry-After", "").strip()
                if retry_after:
                    wait_phrase = f"wait {retry_after} seconds before retrying"
                else:
                    reset = exc.response.headers.get(
                        "X-RateLimit-Reset", "unknown",
                    )
                    wait_phrase = f"resets at epoch {reset}"
                return ToolError(
                    f"GitHub rate limit exhausted during `{tool}` "
                    f"({wait_phrase}). Do not retry immediately — "
                    "wait for the reset window."
                )
            return ToolError(
                f"Permission denied for {repo_label} during `{tool}`. "
                "Likely missing token scope or the repo is private and "
                "inaccessible to this token. Not retryable until access is "
                "granted."
            )

        if status == 404:
            if tool == "get_file" and path:
                return ToolError(
                    f"`{path}` not found in {repo_label}"
                    + (f" @ `{ref}`" if ref else "")
                    + ". Verify the path with `repo_tree` or the ref with "
                    "`list_tags`. Not retryable until the path is corrected."
                )
            if tool == "repo_tree":
                return ToolError(
                    f"{repo_label} not found"
                    + (f" or ref `{ref}` does not exist" if ref else "")
                    + ". Verify the repo exists and the ref is valid via "
                    "`list_tags`. Not retryable until corrected."
                )
            if tool == "list_tags":
                return ToolError(
                    f"{repo_label} not found. Verify the repo exists. Not "
                    "retryable until corrected."
                )
            return ToolError(
                f"Resource not found during `{tool}` for {repo_label}. "
                "Verify the repo/path/ref. Not retryable until corrected."
            )

        if status == 422:
            if tool == "search_code":
                return ToolError(
                    f"GitHub rejected the query for `search_code`"
                    + (f": `{query}`" if query else "")
                    + ". The most common cause is that `search_code` "
                    "requires at least one content term — a query made "
                    "up entirely of qualifiers (e.g. just `repo:foo/bar` "
                    "with no search terms) will 422. Other causes: "
                    "unquoted special characters, queries longer than 256 "
                    "characters, or an empty `repo:`/`language:` qualifier. "
                    "Adjust the query before retrying."
                )
            return ToolError(
                f"GitHub rejected the query for `{tool}`"
                + (f": `{query}`" if query else "")
                + ". Common causes: unquoted special characters, an empty "
                "or malformed `repo:`/`language:` qualifier, or using a "
                "feature not supported by GitHub search. Adjust the query "
                "before retrying."
            )

        if 500 <= status < 600:
            return ToolError(
                f"GitHub upstream error (HTTP {status}) during `{tool}`. "
                "Transient — may retry once after a delay, but not in a "
                "tight loop."
            )

        snippet = (exc.response.text or "")[:200]
        return ToolError(
            f"HTTP {status} from GitHub during `{tool}`: {snippet}"
        )

    if isinstance(exc, httpx.RequestError):
        return ToolError(
            f"Network error during `{tool}`: {exc!r}. Transient — may "
            "retry once after a delay."
        )

    return ToolError(
        f"Unexpected error in `{tool}`"
        + (f" for `{repo}`" if repo else "")
        + f": {exc!r}. Likely not retryable unless this is a transient "
        "network issue."
    )


# ---- fragment location helpers -------------------------------------------
#
# Used by search_code (and find_symbol's tree-sitter prefetch path).
# GitHub's Code Search API returns `text_matches[].fragment` as a
# verbatim slice of file content but does NOT emit line numbers or
# absolute positions. Tools that consume this API can recover line
# numbers by prefetching the actual file and locating the fragment
# inside it. The helpers below package that pattern so tools can emit
# ripgrep-style output with consistent behavior.

import base64  # noqa: E402

_BLOB_SHA_RE = re.compile(r"/blob/([0-9a-f]{40})/")


def extract_commit_sha(html_url: str) -> str | None:
    """Extract the 40-char commit SHA from a GitHub blob URL.

    GitHub Code Search results carry the commit SHA they were indexed
    against in the `html_url` field as `.../blob/<sha>/<path>`. Using
    that SHA as the `ref` for a follow-up `get_contents` call returns
    the exact same file state even if main has moved on, which is what
    we need for fragment-to-line-number resolution to stay stable.
    """
    m = _BLOB_SHA_RE.search(html_url or "")
    return m.group(1) if m else None


def find_fragment_line(content: str, fragment: str) -> int | None:
    """Return the 1-indexed line number where `fragment` starts in
    `content`, or None if we cannot locate it.

    Direct substring search handles the common case where the fragment
    matches the file content verbatim. When that fails (whitespace
    normalization, edge-case drift), we fall back to searching for the
    first sufficiently-long stripped line of the fragment alone —
    enough to land on the right line for the ~90% case without
    expensive per-line fuzzy matching. Callers should degrade to a
    no-line-numbers rendering when this returns None.
    """
    if not fragment or not content:
        return None
    idx = content.find(fragment)
    if idx < 0:
        for line in fragment.split("\n"):
            stripped = line.strip()
            if stripped and len(stripped) >= 8:
                idx = content.find(stripped)
                if idx >= 0:
                    # Back up to the start of this line in `content`
                    # so the returned number points at the line
                    # itself, not mid-line.
                    line_start = content.rfind("\n", 0, idx) + 1
                    return content[:line_start].count("\n") + 1
        return None
    return content[:idx].count("\n") + 1


async def fetch_file_content(
    client, owner: str, repo: str, path: str, commit_sha: str,
) -> str:
    """Fetch raw file content for line-number attribution.

    Returns the full decoded file as a string, or an empty string on
    any failure (network error, oversize file, base64 decode failure,
    directory response where a file was expected). Callers should
    treat "" as "line-number prefetch failed — fall back to the
    no-line-numbers rendering" rather than raising, so one bad file
    downgrades only its own section rather than breaking the whole
    response.
    """
    try:
        result = await client.get_contents(owner, repo, path, ref=commit_sha)
        if isinstance(result, list):
            return ""
        content_b64 = result.get("content", "")
        encoding = result.get("encoding", "")
        if encoding == "base64" and content_b64:
            return base64.b64decode(content_b64).decode(
                "utf-8", errors="replace",
            )
        return content_b64 or ""
    except Exception:  # noqa: BLE001
        return ""
