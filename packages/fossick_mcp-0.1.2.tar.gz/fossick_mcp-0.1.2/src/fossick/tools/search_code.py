"""Tool: search_code — full GitHub code search with regex, symbol, and boolean support.

Scope: All of GitHub (200M+ repos), or narrowed to a specific repo/org/path.
When to use: Finding code patterns, implementations, examples across repos or within one repo.
"""


import asyncio
from typing import Annotated

from mcp.types import ToolAnnotations
from pydantic import Field

from fossick.cache import cache, cache_key
from fossick.github_client import get_client
from fossick.hints import format_hints, generate_hints
from fossick.server import mcp
from fossick.tools._common import (
    CODE_SEARCH_QUALIFIERS,
    CODE_SEARCH_REDIRECTS,
    extract_commit_sha,
    fetch_file_content,
    find_fragment_line,
    http_error_to_tool_error,
    validate_search_query,
)


@mcp.tool(
    annotations=ToolAnnotations(
        readOnlyHint=True,
        destructiveHint=False,
        idempotentHint=True,
        openWorldHint=True,
    ),
    # structured_output=False disables FastMCP's auto-generated
    # `{"result": str}` wrapping. Without this, str-returning tools
    # emit both `content[]` (the raw markdown) AND `structuredContent`
    # (the JSON-wrapped dict). Some MCP clients — including Claude Code
    # — display and/or pass the structuredContent form to the model,
    # which turns our carefully formatted markdown into a JSON-escaped
    # string with literal `\n` sequences. That defeats the whole point
    # of our markdown format work: ripgrep-style line prefixes become
    # harder to parse, every newline doubles in token cost, and the
    # model has to parse a JSON wrapper before reaching the content.
    # Unstructured output is exactly right for tools that return
    # human-readable text — which is all of ours.
    structured_output=False,
)
async def search_code(
    query: Annotated[str, Field(description="GitHub code search query. Supports regex (/pattern/), symbol:name, boolean (AND/OR/NOT), exact phrases. Code-search qualifiers: repo:, org:, user:, path:, language:, content:, symbol:, is:archived, is:fork, is:vendored, is:generated, size:, in:, filename:, extension:. Repository-level filters (stars:, pushed:, forks:, created:, topic:, license:, archived:) are NOT supported by code search — use `search_repos` for those.")],
    repo: Annotated[str, Field(description="Scope to one repository (owner/repo).")] = "",
    language: Annotated[str, Field(description="Filter by programming language.")] = "",
    path: Annotated[str, Field(description="Filter by file path pattern (e.g. src/).")] = "",
    page: Annotated[int, Field(description="Page number for paginated results.")] = 1,
    per_page: Annotated[int, Field(description="Results per page (max 100).")] = 30,
    context_lines: Annotated[int, Field(description="Max lines of code context per match (default 10).")] = 10,
) -> str:
    """Search for code across all of GitHub (200M+ repos), or narrowed to one repo/org/path. Supports regex (/pattern/), tree-sitter symbol search (symbol:name), boolean operators (AND/OR/NOT), exact phrases, and code-search qualifiers: repo:, org:, user:, path:, language:, content:, symbol:, is:archived, is:fork, is:vendored, is:generated, size:, in:file, in:path, filename:, extension:. Convenience params repo, language, path are appended as qualifiers automatically. Use this to find real-world usage patterns (how do projects actually import and call library X?), discover who uses a library (search for its import/crate name across GitHub), or locate example code for a framework you're evaluating. NOT for finding where a symbol is defined (use find_symbol). IMPORTANT: GitHub's code-search endpoint does NOT support repository-level qualifiers like stars:, pushed:, forks:, created:, topic:, license:, archived: — GitHub silently matches them as literal file content, giving wrong results with no error. For popularity-filtered discovery, use `search_repos` instead."""
    try:
        # Pre-flight: reject qualifiers that GitHub code search would
        # silently match as literal content. Without this, `stars:>100`
        # returns files whose source contains that string rather than
        # filtering by popularity — an opaque, wrong-results failure.
        validate_search_query(
            query,
            tool="search_code",
            allowed=CODE_SEARCH_QUALIFIERS,
            redirects=CODE_SEARCH_REDIRECTS,
        )

        # Build final query by appending convenience qualifiers
        parts = [query]
        if repo:
            parts.append(f"repo:{repo}")
        if language:
            parts.append(f"language:{language}")
        if path:
            parts.append(f"path:{path}")
        full_query = " ".join(parts)

        ck = cache_key("search_code", query=full_query, page=page, per_page=per_page)
        cached = await cache.get(ck)
        if cached is not None:
            return cached

        client = get_client()
        result = await client.search_code(full_query, page=page, per_page=per_page)

        items = result.get("items", [])
        total = result.get("total_count", 0)

        # -- File content prefetch for line-number attribution --------
        # For every unique (owner, repo, commit_sha, path) tuple in
        # the results, fetch the raw file content in parallel. We use
        # the commit SHA parsed from each item's `html_url` as the
        # `ref` so we get the exact state GitHub indexed — even if the
        # file moved on main. Fetches are coalesced per unique file;
        # multiple matches in the same file share one fetch. Errors
        # produce an empty string and the renderer falls back to the
        # no-line-numbers path, so a network hiccup on one file only
        # downgrades that file's output, not the whole result.
        file_jobs: dict[tuple[str, str, str, str], None] = {}
        for item in items:
            repo_full = item.get("repository", {}).get("full_name", "")
            if "/" not in repo_full:
                continue
            owner, name = repo_full.split("/", 1)
            file_path = item.get("path", "")
            commit_sha = extract_commit_sha(item.get("html_url", ""))
            if not commit_sha or not file_path:
                continue
            file_jobs[(owner, name, commit_sha, file_path)] = None

        async def _job(key: tuple[str, str, str, str]) -> tuple[tuple[str, str, str, str], str]:
            owner, name, sha, path_ = key
            content_ = await fetch_file_content(client, owner, name, path_, sha)
            return key, content_

        file_contents: dict[tuple[str, str, str, str], str] = {}
        if file_jobs:
            fetched = await asyncio.gather(
                *(_job(k) for k in file_jobs),
                return_exceptions=False,
            )
            for key, content_ in fetched:
                file_contents[key] = content_

        # Pagination frame: show "of total" + actionable page hint
        # when there's more to see. The hints section at the bottom
        # also surfaces a page-N nudge, but an inline header signal
        # is the first thing the reader sees and sets expectations.
        shown = len(items)
        if total > per_page:
            header_line = (
                f"**Found {total} code results** — "
                f"showing {shown} on page {page} "
                f"(use page=N for more)"
            )
        else:
            header_line = f"**Found {total} code results**"
        lines = [header_line, ""]

        # GitHub fragments are almost always 3 lines, so context_lines
        # was capping something that rarely existed. We still clamp as
        # a safety net for outlier fragments. Consensus default across
        # ripgrep/grep/Sourcegraph is 0-1 added context lines; GitHub
        # already gives us ~3, so we render what it returns.
        max_lines = max(1, min(context_lines, 30))
        # Max match blocks to show per file before collapsing. Files
        # with many hits are a signal to chain to get_file rather
        # than flood the search output with per-match noise.
        max_matches_per_file = 3

        for item in items:
            repo_full = item.get("repository", {}).get("full_name", "")
            repo_desc = (item.get("repository", {}).get("description") or "")[:100]
            repo_stars = item.get("repository", {}).get("stargazers_count", 0)
            file_path = item.get("path", "")
            html_url = item.get("html_url", "")
            text_matches = item.get("text_matches", [])
            match_count = len(text_matches)

            # Look up prefetched content for this file (may be "" on
            # fetch failure — that's the no-line-numbers fallback).
            content = ""
            if "/" in repo_full:
                owner, name = repo_full.split("/", 1)
                commit_sha = extract_commit_sha(html_url)
                if commit_sha:
                    content = file_contents.get(
                        (owner, name, commit_sha, file_path), "",
                    )

            # File header: repo/stars/path + match count when > 1.
            # A single matches-in-file note beats per-fragment
            # "match i/N" annotations — same signal, far less noise.
            count_suffix = (
                f" · {match_count} matches" if match_count > 1 else ""
            )
            lines.append(
                f"**{repo_full}** ({repo_stars:,}★) — "
                f"`{file_path}`{count_suffix}"
            )
            if repo_desc:
                lines.append(f"  {repo_desc}")
            if html_url:
                lines.append(f"  {html_url}")

            # Match fragments with ripgrep-style line-number prefixes.
            # `:` marks the match line, `-` marks context lines (same
            # convention the built-in Grep tool uses, which Claude is
            # trained on). Absolute file line numbers are derived by
            # locating the fragment inside the prefetched file content;
            # when that fails we emit without prefix as a fallback.
            shown_matches = text_matches[:max_matches_per_file]
            # Pre-extract the raw match strings per text_match so we
            # can mark each fragment line as match-or-context by
            # substring containment.
            for mi, match in enumerate(shown_matches):
                fragment = match.get("fragment", "").strip()
                if not fragment:
                    continue
                if mi > 0:
                    lines.append("    --")
                match_texts = [
                    m.get("text", "") for m in match.get("matches", [])
                    if m.get("text")
                ]
                fragment_lines = fragment.split("\n")[:max_lines]
                abs_first = find_fragment_line(content, fragment)
                for li, frag_line in enumerate(fragment_lines):
                    is_match = any(
                        mt and mt in frag_line for mt in match_texts
                    )
                    if abs_first is not None:
                        abs_line = abs_first + li
                        sep = ":" if is_match else "-"
                        lines.append(
                            f"    {abs_line:>4}{sep} {frag_line}"
                        )
                    else:
                        lines.append(f"    {frag_line}")

            if match_count > max_matches_per_file:
                more = match_count - max_matches_per_file
                lines.append(
                    f"    ... {more} more match"
                    f"{'es' if more != 1 else ''} in this file "
                    f"(use `get_file(path={file_path})` to see all "
                    f"in context)"
                )
            lines.append("")

        hints = generate_hints("search_code", {"per_page": per_page}, result)
        output = "\n".join(lines) + format_hints(hints)

        await cache.set(ck, output, ttl=120)
        return output

    except Exception as e:
        raise http_error_to_tool_error(
            e, tool="search_code", repo=repo, query=query,
        )
