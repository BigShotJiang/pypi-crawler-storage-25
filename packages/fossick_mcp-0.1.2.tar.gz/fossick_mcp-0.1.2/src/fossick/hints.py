"""Hint generation engine — suggests logical next steps after each tool call.

Fossick v2 is discovery-focused (7 tools, no archaeology tools like
blame/compare/search_prs/find_references). Hint rules only chain between
discovery tools.
"""

from __future__ import annotations

from typing import Any, Callable

# Each rule: (tool_name, condition, template, priority)
# Lower priority number = higher importance.
_Rule = tuple[str, Callable[[dict[str, Any], dict[str, Any]], bool], str, int]

_RULES: list[_Rule] = [
    # search_code
    ("search_code", lambda p, r: r.get("total_count", 0) > 0,
     "`get_file` — read a matched file", 1),
    ("search_code", lambda p, r: r.get("total_count", 0) > int(p.get("per_page", 30)),
     "`page=N` — more results available", 2),
    ("search_code", lambda p, r: r.get("total_count", 0) > 0,
     "`find_symbol` — find where it's defined", 3),
    # search_repos — in single-query mode the top hint nudges toward
    # multi-phrasing, because description-phrase matching is sharp but
    # narrow: single queries routinely miss popular options that
    # describe themselves with different wording (e.g. searching
    # "Postgres operator" misses CloudNativePG, which says
    # "Kubernetes-native PostgreSQL"). The nudge drops off automatically
    # once `queries=` is used (num_queries >= 2), so the old
    # repo_tree/search_code hints float up in multi-query mode.
    ("search_repos",
     lambda p, r: p.get("num_queries", 1) <= 1 and r.get("total_count", 0) > 0,
     "`queries=[...]` — shortlisting? rerun with 2-4 phrasings; single-phrase `in:description` routinely misses popular options that describe themselves differently",
     1),
    ("search_repos", lambda p, r: r.get("total_count", 0) > 0,
     "`repo_tree` — explore repo structure", 2),
    ("search_repos", lambda p, r: r.get("total_count", 0) > 0,
     "`search_code` — search code in the repo", 3),
    # get_file
    ("get_file", lambda p, r: True,
     "`find_symbol` — locate a class/function definition", 1),
    ("get_file", lambda p, r: True,
     "`search_code` — find usage patterns for something in this file", 2),
    # repo_tree
    ("repo_tree", lambda p, r: True,
     "`get_file` — read a file from the tree", 1),
    ("repo_tree", lambda p, r: True,
     "`search_code` — search within repo", 2),
    # find_symbol
    ("find_symbol", lambda p, r: r.get("total_count", 0) > 0,
     "`get_file` — read the definition with surrounding context", 1),
    ("find_symbol", lambda p, r: r.get("total_count", 0) > 0,
     "`search_code` — find real-world usages of this symbol", 2),
    # search_packages
    ("search_packages", lambda p, r: True,
     "`search_repos` — find the source repo", 1),
    ("search_packages", lambda p, r: True,
     "`search_code` — find where it's imported in other projects", 2),
    # list_tags
    ("list_tags", lambda p, r: True,
     "`get_file(ref=<tag>)` — read a file at a specific release", 1),
    ("list_tags", lambda p, r: True,
     "`repo_tree(ref=<tag>)` — browse the repo layout at a specific release", 2),
]


def generate_hints(
    tool_name: str, params: dict[str, Any], result: dict[str, Any]
) -> list[str]:
    """Return up to 2 contextual hints sorted by priority."""
    matched: list[tuple[int, str]] = []
    for rule_tool, condition, template, priority in _RULES:
        if rule_tool != tool_name:
            continue
        try:
            if condition(params, result):
                matched.append((priority, template))
        except Exception:  # noqa: BLE001
            continue
    matched.sort(key=lambda t: t[0])
    return [text for _, text in matched[:2]]


def format_hints(hints: list[str]) -> str:
    """Format a list of hint strings as a Markdown section."""
    if not hints:
        return ""
    lines = ["", "---", "**Suggested next steps:**"]
    for hint in hints:
        lines.append(f"- {hint}")
    return "\n".join(lines)
