"""Simple async TTL cache with LRU eviction."""

from __future__ import annotations

import hashlib
import json
import re
import time
from collections import OrderedDict
from typing import Any

_DEFAULT_MAX_SIZE = 500
_DEFAULT_TTL = 300  # seconds


class _Entry:
    __slots__ = ("value", "expires_at")

    def __init__(self, value: Any, expires_at: float) -> None:
        self.value = value
        self.expires_at = expires_at


class TTLCache:
    """In-memory TTL cache with LRU eviction."""

    def __init__(self, max_size: int = _DEFAULT_MAX_SIZE) -> None:
        self._store: OrderedDict[str, _Entry] = OrderedDict()
        self._max_size = max_size

    async def get(self, key: str) -> Any | None:
        """Return cached value or ``None`` if missing/expired."""
        entry = self._store.get(key)
        if entry is None:
            return None
        if time.monotonic() > entry.expires_at:
            del self._store[key]
            return None
        # Mark as recently used
        self._store.move_to_end(key)
        return entry.value

    async def set(self, key: str, value: Any, ttl: int = _DEFAULT_TTL) -> None:
        """Store a value with a TTL in seconds."""
        if key in self._store:
            del self._store[key]
        self._store[key] = _Entry(value, time.monotonic() + ttl)
        self._evict()

    def invalidate(self, pattern: str) -> int:
        """Remove all keys matching a regex *pattern*. Returns count removed."""
        regex = re.compile(pattern)
        to_delete = [k for k in self._store if regex.search(k)]
        for k in to_delete:
            del self._store[k]
        return len(to_delete)

    def _evict(self) -> None:
        """Evict oldest entries until we're within max_size."""
        while len(self._store) > self._max_size:
            self._store.popitem(last=False)


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

cache = TTLCache()


def cache_key(endpoint: str, **params: Any) -> str:
    """Build a deterministic cache key from an endpoint and parameters."""
    raw = json.dumps({"endpoint": endpoint, **params}, sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()
