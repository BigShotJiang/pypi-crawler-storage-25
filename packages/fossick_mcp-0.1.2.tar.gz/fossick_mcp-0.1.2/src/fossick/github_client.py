"""Async GitHub API client with rate-limit handling and retry logic."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import time
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_BASE_URL = "https://api.github.com"

# Rate-limit thresholds
_REMAINING_THRESHOLD = 5
_MAX_RETRIES = 3
_RETRY_BASE_DELAY = 1.0  # seconds


class _RateBucket:
    """Tracks rate-limit state for one API category."""

    __slots__ = ("remaining", "reset_at")

    def __init__(self) -> None:
        self.remaining: int | None = None
        self.reset_at: float = 0.0

    def update(self, headers: httpx.Headers) -> None:
        """Read rate-limit headers from a GitHub response."""
        if "x-ratelimit-remaining" in headers:
            self.remaining = int(headers["x-ratelimit-remaining"])
        if "x-ratelimit-reset" in headers:
            self.reset_at = float(headers["x-ratelimit-reset"])

    async def wait_if_needed(self) -> None:
        """Sleep until the reset window if remaining requests are low."""
        if self.remaining is not None and self.remaining < _REMAINING_THRESHOLD:
            sleep_for = max(self.reset_at - time.time(), 0) + 1
            logger.warning(
                "Rate limit nearly exhausted (remaining=%s). Sleeping %.1fs.",
                self.remaining,
                sleep_for,
            )
            await asyncio.sleep(sleep_for)


class GitHubClient:
    """Thin async wrapper around the GitHub REST API."""

    def __init__(self, token: str) -> None:
        self._token = token
        self._http = httpx.AsyncClient(
            base_url=_BASE_URL,
            headers={
                "Authorization": f"Bearer {token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
            timeout=30.0,
            # Follow redirects so renamed/transferred repos resolve
            # transparently. GitHub issues a 301 Moved Permanently
            # with a `Location: https://api.github.com/...` pointing
            # at the new owner when a repo has been transferred
            # (e.g. encode/starlette → Kludex/starlette). Without
            # this, every tool call against the old slug surfaces
            # an opaque `HTTP 301 from GitHub during <tool>:
            # {"message":"Moved Permanently","url":"..."}` error
            # through the classifier, which is actionable only if
            # the caller reads the JSON body and extracts the new
            # URL — basically never. With follow_redirects=True,
            # httpx re-issues the request against the new URL
            # automatically and returns the final 200 response,
            # so the caller sees the correct data from the moved
            # repo without any awareness that a redirect happened.
            follow_redirects=True,
        )
        self._search_bucket = _RateBucket()
        self._core_bucket = _RateBucket()

    # -- internal helpers -----------------------------------------------------

    def _bucket_for(self, path: str) -> _RateBucket:
        return self._search_bucket if path.startswith("/search/") else self._core_bucket

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> httpx.Response:
        """Issue a request with rate-limit awareness and exponential backoff."""
        bucket = self._bucket_for(path)

        for attempt in range(_MAX_RETRIES):
            await bucket.wait_if_needed()

            response = await self._http.request(
                method, path, params=params, json=json, headers=headers
            )
            bucket.update(response.headers)

            if response.status_code in (403, 429, 502, 503):
                delay = _RETRY_BASE_DELAY * (2**attempt)
                logger.warning(
                    "Retryable status %s on %s %s (attempt %d/%d). Sleeping %.1fs.",
                    response.status_code,
                    method,
                    path,
                    attempt + 1,
                    _MAX_RETRIES,
                    delay,
                )
                await asyncio.sleep(delay)
                continue

            response.raise_for_status()
            return response

        # Final attempt already failed; raise
        response.raise_for_status()
        return response  # unreachable, but keeps the type checker happy

    async def _get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        resp = await self._request("GET", path, params=params, headers=headers)
        return resp.json()

    # -- Search API -----------------------------------------------------------

    async def search_code(
        self, query: str, *, page: int = 1, per_page: int = 30
    ) -> dict[str, Any]:
        """Search code across GitHub (uses text-match fragment headers)."""
        return await self._get(
            "/search/code",
            params={"q": query, "page": page, "per_page": per_page},
            headers={"Accept": "application/vnd.github.text-match+json"},
        )

    async def search_repos(
        self,
        query: str,
        *,
        sort: str = "best match",
        order: str = "desc",
        page: int = 1,
        per_page: int = 30,
    ) -> dict[str, Any]:
        """Search repositories."""
        params: dict[str, Any] = {"q": query, "page": page, "per_page": per_page}
        if sort != "best match":
            params["sort"] = sort
        params["order"] = order
        return await self._get("/search/repositories", params=params)

    # -- Repos / Contents -----------------------------------------------------

    async def get_repo(
        self, owner: str, repo: str
    ) -> dict[str, Any]:
        """Get repository metadata (includes default_branch)."""
        return await self._get(f"/repos/{owner}/{repo}")

    async def get_contents(
        self, owner: str, repo: str, path: str, *, ref: str | None = None
    ) -> dict[str, Any]:
        """Get repository file or directory contents."""
        params = {"ref": ref} if ref else None
        return await self._get(f"/repos/{owner}/{repo}/contents/{path}", params=params)

    async def get_tree(
        self, owner: str, repo: str, sha: str, *, recursive: bool = False
    ) -> dict[str, Any]:
        """Get a Git tree."""
        params = {"recursive": "1"} if recursive else None
        return await self._get(f"/repos/{owner}/{repo}/git/trees/{sha}", params=params)

    # -- Commits / Compare ----------------------------------------------------

    async def get_commits(
        self,
        owner: str,
        repo: str,
        *,
        path: str | None = None,
        author: str | None = None,
        since: str | None = None,
        until: str | None = None,
        sha: str | None = None,
        page: int = 1,
        per_page: int = 30,
    ) -> list[dict[str, Any]]:
        """List commits for a repository."""
        params: dict[str, Any] = {"page": page, "per_page": per_page}
        if path:
            params["path"] = path
        if author:
            params["author"] = author
        if since:
            params["since"] = since
        if until:
            params["until"] = until
        if sha:
            params["sha"] = sha
        return await self._get(f"/repos/{owner}/{repo}/commits", params=params)

    # -- Tags / Releases ------------------------------------------------------

    async def get_tags(
        self, owner: str, repo: str, *, page: int = 1, per_page: int = 30
    ) -> list[dict[str, Any]]:
        """List repository tags."""
        return await self._get(
            f"/repos/{owner}/{repo}/tags",
            params={"page": page, "per_page": per_page},
        )

    async def get_releases(
        self, owner: str, repo: str, *, page: int = 1, per_page: int = 30
    ) -> list[dict[str, Any]]:
        """List repository releases."""
        return await self._get(
            f"/repos/{owner}/{repo}/releases",
            params={"page": page, "per_page": per_page},
        )

    # -- Lifecycle ------------------------------------------------------------

    async def close(self) -> None:
        await self._http.aclose()


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_client: GitHubClient | None = None


def _resolve_token() -> str:
    """Try multiple sources to find a GitHub token.

    Preference order:
      1. GH_TOKEN / GITHUB_TOKEN / GITHUB_PERSONAL_ACCESS_TOKEN env vars
      2. `gh auth token` (GitHub CLI)
    """
    for var in ("GH_TOKEN", "GITHUB_TOKEN", "GITHUB_PERSONAL_ACCESS_TOKEN"):
        token = os.environ.get(var, "").strip()
        if token:
            return token
    # Fall back to GitHub CLI
    if shutil.which("gh"):
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                token = result.stdout.strip()
                if token:
                    return token
        except (OSError, subprocess.TimeoutExpired):
            pass
    return ""


def get_client() -> GitHubClient:
    """Return the shared GitHubClient, creating it lazily on first call."""
    global _client
    if _client is None:
        token = _resolve_token()
        if not token:
            raise RuntimeError(
                "No GitHub token found. Set GITHUB_TOKEN env var, "
                "run `gh auth login`, or add to macOS Keychain."
            )
        _client = GitHubClient(token)
    return _client
