"""FastMCP server definition for fossick."""

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP


@asynccontextmanager
async def _lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """Manage the httpx client lifecycle."""
    from fossick.github_client import get_client
    client = get_client()
    try:
        yield {"github_client": client}
    finally:
        await client.close()

_INSTRUCTIONS = (
    "Fossick helps you discover and evaluate new libraries, frameworks, "
    "and packages to adopt in new projects. Its seven tools cover the "
    "'I'm starting a project and need to find the right dependency' "
    "workflow end-to-end, across all 200M+ GitHub repos plus PyPI and npm. "
    "NOT for code archaeology (git history, blame, PR tracking, version diffing) — "
    "use git / gh CLI via Bash for that. "
    "Tool selection: "
    "1. Use 'search_repos' to discover libraries by topic, stars, language, or trending — "
    "this is where most discovery sessions start. "
    "2. Use 'search_packages' for direct PyPI/npm lookups when you already know the package name. "
    "3. Use 'search_code' to find real-world usage patterns — how do other projects "
    "actually import and call library X? Supports regex, boolean operators, and qualifiers like "
    "repo:, language:, path:. "
    "4. Use 'find_symbol' to locate a class/function/type definition — 'where is "
    "X defined?' — so you can read its declaration and understand the API surface. "
    "5. Use 'repo_tree' to browse a repository's layout and 'get_file' to read "
    "specific files (READMEs, examples, the main module). "
    "6. Use 'list_tags' to check freshness — 'is this library actively maintained?' — "
    "and see recent releases. "
    "Usage guidance: "
    "Use the convenience params (repo, language, path) instead of embedding qualifiers in the query string. "
    "Use pagination — results default to page 1, request more with page=2. "
    "Chain tools: search_repos → repo_tree → get_file to evaluate a candidate library; "
    "search_code → get_file → find_symbol to understand how an API is used in the wild."
)

mcp = FastMCP("fossick", instructions=_INSTRUCTIONS, lifespan=_lifespan)

# Import tool modules to trigger @mcp.tool() registration
from fossick.tools import (  # noqa: F401, E402
    find_symbol,
    get_file,
    list_tags,
    repo_tree,
    search_code,
    search_packages,
    search_repos,
)
