# langgraph-init-cli

A production-oriented scaffolding CLI for [LangGraph](https://github.com/langchain-ai/langgraph) projects. Generate opinionated project layouts that start simple and scale into a full agentic architecture — with graph orchestration, prompt versioning, tool registries, evaluation, observability, and LangSmith-ready tracing.

```bash
pip install langgraph-init-cli
langgraph-init my-app --template production
```

---

## Why langgraph-init?

Starting a LangGraph project from scratch means a lot of boilerplate: wiring state graphs, organizing nodes, managing prompts, hooking up LangSmith. `langgraph-init` gives you a well-structured starting point so you can skip the scaffolding and focus on the agent logic that matters.

---

## Installation

```bash
pip install langgraph-init-cli
```

Or for a cleaner global CLI experience:

```bash
pipx install langgraph-init-cli
```

---

## Usage

```bash
langgraph-init <project-name> --template <template>
```

**Available templates:**

| Template | Best For |
|---|---|
| `base` | Quick experiments and prototypes |
| `advanced` | Modular team projects with clean graph structure |
| `production` | Full production systems with tooling, observability, and evaluation |

**Example:**

```bash
langgraph-init my-app --template production
cd my-app
pip install -e .
python -m src.app.main
```

---

## Templates

### `base`

A minimal LangGraph starter to get something running fast.

- Small `StateGraph` with typed state
- A few nodes wired together
- Runnable via `src.app.main:run`

### `advanced`

A modular architecture for teams that want clean structure without full production overhead.

- `graph/` package with `builder.py`, `state.py`, `edges.py`, `constants.py`, `registry.py`
- `Names` / `Nodes` / `Tags` pattern for readable graph wiring
- `nodes/`, `services/`, `prompts/`, and `utils/` directories
- Prompt loading abstraction and conditional edges

### `production`

A complete scaffold intended for real systems. Everything is modular, runnable without external services, and ready to extend.

- Graph orchestration with `StateGraph`, conditional routing, and retry logic
- `RunnableParallel` example for parallel enrichment
- Prompt versioning system (`prompts/versions/<task>/v1.txt`, `v2.txt`, ...)
- Tool framework with `BaseTool`, registry, and example tools (calculator, retriever, HTTP-style)
- Evaluation, confidence scoring, and field coverage checks
- Structured JSON logging, metrics counters, trace decorators
- LangSmith integration (environment-driven, safe when disabled)
- Optional API entry surface and storage layer abstractions

**Generated layout:**

```
src/app/
├── main.py
├── config.py
├── graph/
├── nodes/
├── services/
├── tools/
├── prompts/
├── models/
├── storage/
├── utils/
├── observability/
├── evaluation/
└── api/
```

---

## Graph Wiring Pattern

The `advanced` and `production` templates use a three-concept pattern to keep graph wiring readable and maintainable:

```python
class Names:
    INTENT = "intent"       # Stable node identifiers

class Nodes:
    INTENT = intent_node    # Callable implementations

class Tags:
    CONTINUE = "continue"   # Routing labels for conditional edges
```

This separates string identifiers from executable functions, making edges easy to read and refactor.

---

## After Generation

Recommended next steps once you have your scaffold:

- Replace deterministic LLM stubs with your actual provider client
- Add real persistence in `storage/`
- Swap demo tools for domain-specific tools
- Expand evaluation metrics for your use case
- Add tests around graph routing and node behavior
- Set `LANGCHAIN_API_KEY` and related env vars to activate LangSmith tracing

---

## Generated `langgraph.json`

All projects include:

```json
{
  "dependencies": ["."],
  "graphs": {
    "<project-name>": "src.app.main:run"
  }
}
```

This keeps the entrypoint consistent and compatible with LangGraph tooling.

---

## Links

- **PyPI:** https://pypi.org/project/langgraph-init-cli/
- **LangGraph docs:** https://langchain-ai.github.io/langgraph/
- **LangSmith:** https://smith.langchain.com/

---

## License

MIT
