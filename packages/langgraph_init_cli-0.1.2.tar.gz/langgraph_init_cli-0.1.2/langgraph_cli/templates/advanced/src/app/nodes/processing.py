import re

from src.app.graph.state import WorkflowState
from src.app.prompts.registry import PromptRegistry
from src.app.services.prompt_service import PromptService


def processing_node(state: WorkflowState) -> WorkflowState:
    prompt = PromptService(PromptRegistry()).get_prompt("processing")
    text = state.get("input_text", "")
    numbers = re.findall(r"\d+", text)
    extracted = ", ".join(numbers) if numbers else prompt
    validation_passed = bool(extracted)
    return {"extracted_value": extracted, "validation_passed": validation_passed}
