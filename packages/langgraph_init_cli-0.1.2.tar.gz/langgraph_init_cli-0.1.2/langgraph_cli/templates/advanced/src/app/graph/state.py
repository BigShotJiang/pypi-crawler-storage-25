from typing import TypedDict


class WorkflowState(TypedDict, total=False):
    input_text: str
    intent: str
    extracted_value: str
    output: str
    validation_passed: bool
