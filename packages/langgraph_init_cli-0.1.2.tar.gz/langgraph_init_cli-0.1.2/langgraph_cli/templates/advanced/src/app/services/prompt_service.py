class PromptService:
    def __init__(self, registry):
        self.registry = registry

    def get_prompt(self, task: str, version: str | None = None) -> str:
        return self.registry.get(task, version=version)
