from langgraph.graph import END, START, StateGraph

from src.app.graph.constants import Names
from src.app.graph.edges import EDGE_MAP, route_after_process
from src.app.graph.registry import NODE_REGISTRY
from src.app.graph.state import WorkflowState


def build_graph():
    graph = StateGraph(WorkflowState)
    for name, node in NODE_REGISTRY.items():
        graph.add_node(name, node)

    graph.add_edge(START, Names.INTENT)
    graph.add_edge(Names.INTENT, Names.PROCESS)
    graph.add_conditional_edges(Names.PROCESS, route_after_process, EDGE_MAP)
    graph.add_edge(Names.OUTPUT, END)
    return graph.compile()
