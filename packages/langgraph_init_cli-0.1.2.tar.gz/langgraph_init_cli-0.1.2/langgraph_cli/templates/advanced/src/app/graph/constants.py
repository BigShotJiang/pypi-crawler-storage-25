from src.app.nodes.intent import intent_node
from src.app.nodes.output import output_node
from src.app.nodes.processing import processing_node


class Names:
    INTENT = "intent"
    PROCESS = "process"
    OUTPUT = "output"


class Tags:
    CONTINUE = "continue"
    COMPLETE = "complete"


class Nodes:
    INTENT = intent_node
    PROCESS = processing_node
    OUTPUT = output_node
