from src.app.graph.constants import Names, Nodes


NODE_REGISTRY = {
    Names.INTENT: Nodes.INTENT,
    Names.PROCESS: Nodes.PROCESS,
    Names.OUTPUT: Nodes.OUTPUT,
}
