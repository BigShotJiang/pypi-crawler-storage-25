from src.app.graph.builder import build_graph


def run():
    app = build_graph()
    result = app.invoke({"input_text": "Calculate 2 + 2 and confirm it is valid."})
    print(result["output"])
    return result


if __name__ == "__main__":
    run()
