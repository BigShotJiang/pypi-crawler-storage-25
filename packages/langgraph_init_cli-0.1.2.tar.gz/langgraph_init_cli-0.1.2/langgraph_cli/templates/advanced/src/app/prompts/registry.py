class PromptRegistry:
    def __init__(self) -> None:
        self._prompts = {
            "processing": {
                "v1": "Extract relevant entities from the request.",
            }
        }
        self._defaults = {"processing": "v1"}

    def get(self, task: str, version: str | None = None) -> str:
        selected_version = version or self._defaults[task]
        return self._prompts[task][selected_version]
