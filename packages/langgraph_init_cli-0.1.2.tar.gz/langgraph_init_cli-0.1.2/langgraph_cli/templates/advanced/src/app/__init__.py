"""Advanced app package."""
