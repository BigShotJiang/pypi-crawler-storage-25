from src.app.graph.state import WorkflowState


def intent_node(state: WorkflowState) -> WorkflowState:
    text = state.get("input_text", "").lower()
    intent = "answer"
    if any(token in text for token in ("calculate", "+", "-", "*", "/")):
        intent = "math"
    return {"intent": intent}
