from src.app.graph.state import WorkflowState


def output_node(state: WorkflowState) -> WorkflowState:
    return {
        "output": (
            f"Intent={state.get('intent', 'unknown')}; "
            f"Extracted={state.get('extracted_value', 'none')}"
        )
    }
