from src.app.graph.constants import Names, Tags
from src.app.graph.state import WorkflowState


def route_after_process(state: WorkflowState) -> str:
    if state.get("validation_passed"):
        return Tags.COMPLETE
    return Tags.CONTINUE


EDGE_MAP = {
    Tags.COMPLETE: Names.OUTPUT,
    Tags.CONTINUE: Names.PROCESS,
}
