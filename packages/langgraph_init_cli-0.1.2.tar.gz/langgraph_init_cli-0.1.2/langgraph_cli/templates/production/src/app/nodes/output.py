from src.app.graph.state import WorkflowState
from src.app.models.workflow import WorkflowResult
from src.app.storage.workflow_store import WorkflowStore
from src.app.utils.logger import get_logger

logger = get_logger(__name__)


def output_node(state: WorkflowState) -> WorkflowState:
    result = WorkflowResult.from_state(state)
    WorkflowStore().save(result)
    logger.info("output_node", extra={"status": result.status})
    return {"output": result.render()}
