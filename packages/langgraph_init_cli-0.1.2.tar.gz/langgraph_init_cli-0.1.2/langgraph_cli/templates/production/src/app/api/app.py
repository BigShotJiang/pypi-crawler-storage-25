from __future__ import annotations

from src.app.api.routes import invoke_workflow


class Application:
    def handle(self, input_text: str) -> dict[str, object]:
        return invoke_workflow({"input_text": input_text})


app = Application()
