from __future__ import annotations

from src.app.tools.base import BaseTool


class HttpTool(BaseTool):
    def __init__(self) -> None:
        super().__init__(name="http", description="Return a deterministic HTTP-style response.")

    def run(self, **kwargs):
        url = kwargs.get("url", "https://example.local")
        return {"tool": self.name, "url": url, "status_code": 200, "body": {"ok": True}}
