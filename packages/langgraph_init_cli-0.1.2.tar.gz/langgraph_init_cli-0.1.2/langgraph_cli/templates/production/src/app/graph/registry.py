from src.app.graph.constants import Names, Nodes


NODE_REGISTRY = {
    Names.INTENT: Nodes.INTENT,
    Names.PROCESSING: Nodes.PROCESSING,
    Names.VALIDATION: Nodes.VALIDATION,
    Names.OUTPUT: Nodes.OUTPUT,
    Names.ERROR: Nodes.ERROR,
}
