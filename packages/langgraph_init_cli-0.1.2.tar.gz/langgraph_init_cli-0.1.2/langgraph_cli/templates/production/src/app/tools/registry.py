from __future__ import annotations

from src.app.tools.api.http_tool import HttpTool
from src.app.tools.base import BaseTool
from src.app.tools.db.query_tool import QueryTool
from src.app.tools.rag.retriever_tool import RetrieverTool
from src.app.tools.utils.calculator_tool import CalculatorTool


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, BaseTool] = {
            "http": HttpTool(),
            "query": QueryTool(),
            "calculator": CalculatorTool(),
            "retriever": RetrieverTool(),
        }

    def register(self, tool: BaseTool) -> None:
        self._tools[tool.name] = tool

    def get(self, name: str) -> BaseTool:
        return self._tools[name]

    def run(self, name: str, **kwargs):
        return self.get(name).run(**kwargs)
