from __future__ import annotations

from dataclasses import asdict


class WorkflowStore:
    _records: list[dict[str, object]] = []

    def save(self, workflow_result) -> None:
        self._records.append(asdict(workflow_result))

    def list(self) -> list[dict[str, object]]:
        return list(self._records)
