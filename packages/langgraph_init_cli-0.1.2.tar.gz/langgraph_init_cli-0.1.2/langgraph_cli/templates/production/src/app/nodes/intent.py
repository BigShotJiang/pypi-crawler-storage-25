from src.app.graph.state import WorkflowState
from src.app.services.llm_service import LLMService
from src.app.services.prompt_service import PromptService
from src.app.utils.logger import get_logger

logger = get_logger(__name__)


def intent_node(state: WorkflowState) -> WorkflowState:
    prompt_service = PromptService()
    llm_service = LLMService(prompt_service=prompt_service)
    user_input = state.get("input_text", "")
    version = state.get("prompt_versions", {}).get("intent")
    prompt = prompt_service.load_prompt("intent", version=version)
    intent_result = llm_service.classify_intent(prompt=prompt, text=user_input)
    logger.info("intent_node", extra={"intent": intent_result["intent"], "confidence": intent_result["confidence"]})
    return {
        "intent": intent_result["intent"],
        "confidence": intent_result["confidence"],
        "messages": state.get("messages", []) + [f"intent:{intent_result['intent']}"],
    }
