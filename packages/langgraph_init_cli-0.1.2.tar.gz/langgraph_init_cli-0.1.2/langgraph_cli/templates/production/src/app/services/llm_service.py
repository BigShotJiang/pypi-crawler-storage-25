from __future__ import annotations

import re
from dataclasses import dataclass

from langchain_core.runnables import RunnableLambda, RunnableParallel

from src.app.observability.langsmith import traceable
from src.app.observability.metrics import metrics
from src.app.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass(slots=True)
class LLMService:
    prompt_service: object

    @traceable(name="classify_intent")
    def classify_intent(self, prompt: str, text: str) -> dict[str, object]:
        lowered = text.lower()
        intent = "general"
        confidence = 0.55
        if any(token in lowered for token in ("calculate", "+", "-", "*", "/")):
            intent = "calculation"
            confidence = 0.93
        elif "validate" in lowered:
            intent = "validation"
            confidence = 0.8
        metrics.increment("llm.classify_intent.calls")
        logger.info("classify_intent", extra={"prompt_preview": prompt[:40], "intent": intent})
        return {"intent": intent, "confidence": confidence}

    @traceable(name="parallel_enrich")
    def parallel_enrich(self, prompt: str, text: str) -> dict[str, dict[str, object]]:
        extractor = RunnableLambda(lambda payload: self._extract_fields(prompt=payload["prompt"], text=payload["text"]))
        analyzer = RunnableLambda(lambda payload: self._derive_analysis(text=payload["text"]))
        pipeline = RunnableParallel(extraction=extractor, analysis=analyzer)
        metrics.increment("llm.parallel_enrich.calls")
        return pipeline.invoke({"prompt": prompt, "text": text})

    def _extract_fields(self, prompt: str, text: str) -> dict[str, object]:
        numbers = [int(match) for match in re.findall(r"-?\d+", text)]
        return {
            "prompt_used": prompt.splitlines()[0] if prompt else "missing-prompt",
            "numbers": numbers,
            "requires_tool": bool(numbers),
            "text_length": len(text),
        }

    def _derive_analysis(self, text: str) -> dict[str, object]:
        lowered = text.lower()
        return {
            "contains_validation": "validate" in lowered,
            "contains_math": any(token in lowered for token in ("calculate", "+", "-", "*", "/")),
        }
