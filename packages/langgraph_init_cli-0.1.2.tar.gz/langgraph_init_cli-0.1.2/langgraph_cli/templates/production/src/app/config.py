from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()


@dataclass(slots=True)
class Settings:
    project_name: str = "{{PROJECT_NAME}}"
    environment: str = os.getenv("APP_ENV", "development")
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    langsmith_tracing: bool = os.getenv("LANGSMITH_TRACING", "false").lower() == "true"
    langsmith_endpoint: str = os.getenv("LANGSMITH_ENDPOINT", "https://api.smith.langchain.com")
    langsmith_api_key: str = os.getenv("LANGSMITH_API_KEY", "")
    langsmith_project: str = os.getenv("LANGSMITH_PROJECT", "{{PROJECT_NAME}}")
    default_prompt_versions: dict[str, str] | None = None
    max_validation_retries: int = 2

    def __post_init__(self) -> None:
        if self.default_prompt_versions is None:
            self.default_prompt_versions = {
                "intent": "v2",
                "extraction": "v1",
                "validation": "v1",
            }

    @property
    def prompt_root(self) -> Path:
        return Path(__file__).resolve().parent / "prompts" / "versions"


settings = Settings()
