from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class WorkflowResult:
    intent: str
    confidence: float
    status: str
    validation_reason: str
    tool_results: dict[str, object] = field(default_factory=dict)

    @classmethod
    def from_state(cls, state):
        validation = state.get("validation", {})
        return cls(
            intent=state.get("intent", "unknown"),
            confidence=state.get("confidence", 0.0),
            status="success" if validation.get("is_valid") else "failed",
            validation_reason=validation.get("reason", "No validation result."),
            tool_results=state.get("tool_results", {}),
        )

    def render(self) -> str:
        return (
            f"intent={self.intent}; confidence={self.confidence:.2f}; "
            f"status={self.status}; validation={self.validation_reason}; "
            f"tools={self.tool_results}"
        )
