from __future__ import annotations

from src.app.config import settings
from src.app.prompts.registry import PromptRegistry
from src.app.storage.prompt_store import PromptStore
from src.app.utils.logger import get_logger

logger = get_logger(__name__)


class PromptService:
    def __init__(self) -> None:
        self.registry = PromptRegistry()
        self.store = PromptStore()

    def load_prompt(self, task: str, version: str | None = None) -> str:
        selected_version = version or settings.default_prompt_versions.get(task)
        prompt = self.registry.load(task=task, version=selected_version)
        self.store.record_access(task=task, version=self.registry.resolve_version(task, selected_version))
        logger.info("prompt_loaded", extra={"task": task, "version": selected_version})
        return prompt
