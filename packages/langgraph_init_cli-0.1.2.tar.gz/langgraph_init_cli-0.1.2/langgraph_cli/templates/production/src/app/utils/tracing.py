from __future__ import annotations

from contextlib import contextmanager

from src.app.utils.logger import get_logger

logger = get_logger(__name__)


@contextmanager
def trace_block(name: str):
    logger.info("trace_start", extra={"span": name})
    try:
        yield
    finally:
        logger.info("trace_end", extra={"span": name})
