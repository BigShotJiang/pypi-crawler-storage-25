from __future__ import annotations


class SimpleCache:
    def __init__(self) -> None:
        self._data: dict[str, object] = {}

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value: object) -> None:
        self._data[key] = value
