from src.app.graph.state import WorkflowState
from src.app.services.llm_service import LLMService
from src.app.services.prompt_service import PromptService
from src.app.services.tool_service import ToolService
from src.app.utils.logger import get_logger

logger = get_logger(__name__)


def processing_node(state: WorkflowState) -> WorkflowState:
    prompt_service = PromptService()
    llm_service = LLMService(prompt_service=prompt_service)
    tool_service = ToolService()
    prompt_version = state.get("prompt_versions", {}).get("extraction")
    prompt = prompt_service.load_prompt("extraction", version=prompt_version)
    enrichment = llm_service.parallel_enrich(prompt=prompt, text=state.get("input_text", ""))
    tool_payload = tool_service.execute_for_intent(
        intent=state.get("intent", "general"),
        text=state.get("input_text", ""),
        extracted=enrichment["extraction"],
    )
    extracted_data = {
        **enrichment["extraction"],
        "analysis": enrichment["analysis"],
    }
    logger.info("processing_node", extra={"extracted_keys": list(extracted_data.keys()), "tool_count": len(tool_payload)})
    return {
        "extracted_data": extracted_data,
        "tool_results": tool_payload,
        "retry_count": state.get("retry_count", 0) + 1,
        "messages": state.get("messages", []) + ["processed"],
    }
