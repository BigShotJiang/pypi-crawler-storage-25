from __future__ import annotations

from src.app.config import settings
from src.app.graph.builder import build_graph
from src.app.observability.metrics import metrics
from src.app.utils.logger import get_logger

logger = get_logger(__name__)


def run():
    app = build_graph()
    sample_state = {
        "input_text": "Please calculate 12 + 7 and validate the answer.",
        "retry_count": 0,
        "messages": [],
        "prompt_versions": settings.default_prompt_versions.copy(),
        "tool_results": {},
    }
    result = app.invoke(sample_state)
    logger.info("workflow_complete", extra={"output": result.get("output"), "metrics": metrics.snapshot()})
    print(result.get("output", "No output produced."))
    return result


if __name__ == "__main__":
    run()
