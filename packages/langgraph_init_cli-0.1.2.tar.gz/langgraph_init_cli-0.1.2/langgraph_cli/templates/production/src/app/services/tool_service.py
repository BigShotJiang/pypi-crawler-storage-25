from __future__ import annotations

from src.app.tools.registry import ToolRegistry


class ToolService:
    def __init__(self) -> None:
        self.registry = ToolRegistry()

    def execute_for_intent(self, intent: str, text: str, extracted: dict[str, object]) -> dict[str, object]:
        results: dict[str, object] = {}
        if extracted.get("requires_tool"):
            numbers = extracted.get("numbers", [])
            if len(numbers) >= 2:
                results["calculator"] = self.registry.run(
                    "calculator",
                    operation="add",
                    values=numbers[:2],
                )
        results["retriever"] = self.registry.run("retriever", query=text)
        results["query"] = self.registry.run("query", sql="SELECT 'healthy' AS status")
        return results
