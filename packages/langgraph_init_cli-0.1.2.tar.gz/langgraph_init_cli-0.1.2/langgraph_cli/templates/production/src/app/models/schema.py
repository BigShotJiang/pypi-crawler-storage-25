from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class ExtractionSchema:
    numbers: list[int] = field(default_factory=list)
    prompt_used: str = ""
    requires_tool: bool = False
    text_length: int = 0
