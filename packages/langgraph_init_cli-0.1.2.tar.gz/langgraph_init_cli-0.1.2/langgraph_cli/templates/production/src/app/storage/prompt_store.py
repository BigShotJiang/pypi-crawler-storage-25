from __future__ import annotations


class PromptStore:
    _access_log: list[dict[str, str]] = []

    def record_access(self, task: str, version: str) -> None:
        self._access_log.append({"task": task, "version": version})

    def history(self) -> list[dict[str, str]]:
        return list(self._access_log)
