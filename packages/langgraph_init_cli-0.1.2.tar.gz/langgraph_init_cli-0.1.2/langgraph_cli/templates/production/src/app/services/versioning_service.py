from __future__ import annotations

from src.app.config import settings


class VersioningService:
    def get_version(self, task: str, requested_version: str | None = None) -> str:
        return requested_version or settings.default_prompt_versions.get(task, "v1")

    def switch_version(self, task: str, version: str) -> dict[str, str]:
        settings.default_prompt_versions[task] = version
        return settings.default_prompt_versions.copy()
