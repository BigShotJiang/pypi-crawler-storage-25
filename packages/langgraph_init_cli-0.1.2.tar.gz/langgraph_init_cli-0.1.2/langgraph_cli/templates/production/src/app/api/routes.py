from __future__ import annotations

from src.app.config import settings
from src.app.graph.builder import build_graph


def invoke_workflow(payload: dict[str, object]) -> dict[str, object]:
    app = build_graph()
    initial_state = {
        "input_text": payload.get("input_text", ""),
        "retry_count": 0,
        "messages": [],
        "prompt_versions": payload.get("prompt_versions", settings.default_prompt_versions.copy()),
        "tool_results": {},
    }
    return app.invoke(initial_state)
