from __future__ import annotations

from src.app.evaluation.evaluator import Evaluator
from src.app.evaluation.scoring import score_validation


class EvaluationService:
    def __init__(self) -> None:
        self.evaluator = Evaluator()

    def validate(self, extracted: dict[str, object], confidence: float, prompt: str) -> dict[str, object]:
        evaluation = self.evaluator.evaluate(extracted=extracted, prompt=prompt)
        evaluation["confidence_score"] = score_validation(field_coverage=evaluation["field_coverage"], confidence=confidence)
        evaluation["is_valid"] = evaluation["field_coverage"] >= 0.5 and evaluation["confidence_score"] >= 0.5
        if evaluation["is_valid"]:
            evaluation["reason"] = "Validation passed."
        else:
            evaluation["reason"] = "Validation failed because coverage or confidence was too low."
        return evaluation
