from __future__ import annotations

from src.app.tools.base import BaseTool


class QueryTool(BaseTool):
    def __init__(self) -> None:
        super().__init__(name="query", description="Execute a deterministic demo query.")

    def run(self, **kwargs):
        sql = kwargs.get("sql", "")
        return {"tool": self.name, "sql": sql, "rows": [{"status": "healthy"}]}
