from src.app.nodes.error import error_node
from src.app.nodes.intent import intent_node
from src.app.nodes.output import output_node
from src.app.nodes.processing import processing_node
from src.app.nodes.validation import validation_node


class Names:
    INTENT = "intent"
    PROCESSING = "processing"
    VALIDATION = "validation"
    OUTPUT = "output"
    ERROR = "error"


class Tags:
    CONTINUE = "continue"
    RETRY = "retry"
    COMPLETE = "complete"
    ERROR = "error"


class Nodes:
    INTENT = intent_node
    PROCESSING = processing_node
    VALIDATION = validation_node
    OUTPUT = output_node
    ERROR = error_node
