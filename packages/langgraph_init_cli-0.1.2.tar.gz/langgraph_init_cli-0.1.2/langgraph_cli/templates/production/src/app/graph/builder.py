from langgraph.graph import END, START, StateGraph

from src.app.graph.constants import Names
from src.app.graph.edges import EDGE_MAP, route_after_validation
from src.app.graph.registry import NODE_REGISTRY
from src.app.graph.state import WorkflowState


def build_graph():
    graph = StateGraph(WorkflowState)
    for name, node in NODE_REGISTRY.items():
        graph.add_node(name, node)

    graph.add_edge(START, Names.INTENT)
    graph.add_edge(Names.INTENT, Names.PROCESSING)
    graph.add_edge(Names.PROCESSING, Names.VALIDATION)
    graph.add_conditional_edges(Names.VALIDATION, route_after_validation, EDGE_MAP)
    graph.add_edge(Names.OUTPUT, END)
    graph.add_edge(Names.ERROR, END)
    return graph.compile()
