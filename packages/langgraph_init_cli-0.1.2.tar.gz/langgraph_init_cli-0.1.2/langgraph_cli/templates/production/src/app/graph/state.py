from typing import Any, TypedDict


class WorkflowState(TypedDict, total=False):
    input_text: str
    intent: str
    extracted_data: dict[str, Any]
    validation: dict[str, Any]
    output: str
    error: str
    confidence: float
    retry_count: int
    messages: list[str]
    prompt_versions: dict[str, str]
    tool_results: dict[str, Any]
