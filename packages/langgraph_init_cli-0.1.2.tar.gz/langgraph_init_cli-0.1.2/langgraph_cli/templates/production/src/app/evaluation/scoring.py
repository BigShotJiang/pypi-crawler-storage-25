def score_validation(field_coverage: float, confidence: float) -> float:
    return round((field_coverage * 0.6) + (confidence * 0.4), 2)
