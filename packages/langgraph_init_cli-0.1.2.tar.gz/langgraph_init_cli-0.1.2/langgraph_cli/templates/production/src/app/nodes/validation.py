from src.app.graph.state import WorkflowState
from src.app.services.evaluation_service import EvaluationService
from src.app.services.prompt_service import PromptService
from src.app.utils.logger import get_logger

logger = get_logger(__name__)


def validation_node(state: WorkflowState) -> WorkflowState:
    prompt_service = PromptService()
    evaluation_service = EvaluationService()
    validation_prompt = prompt_service.load_prompt(
        "validation",
        version=state.get("prompt_versions", {}).get("validation"),
    )
    validation = evaluation_service.validate(
        extracted=state.get("extracted_data", {}),
        confidence=state.get("confidence", 0.0),
        prompt=validation_prompt,
    )
    logger.info("validation_node", extra={"validation": validation})
    return {"validation": validation, "messages": state.get("messages", []) + ["validated"]}
