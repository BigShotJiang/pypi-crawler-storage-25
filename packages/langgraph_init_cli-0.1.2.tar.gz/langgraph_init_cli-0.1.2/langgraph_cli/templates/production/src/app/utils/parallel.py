from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor


def run_parallel(tasks: dict[str, callable]) -> dict[str, object]:
    with ThreadPoolExecutor(max_workers=len(tasks) or 1) as executor:
        futures = {name: executor.submit(task) for name, task in tasks.items()}
        return {name: future.result() for name, future in futures.items()}
