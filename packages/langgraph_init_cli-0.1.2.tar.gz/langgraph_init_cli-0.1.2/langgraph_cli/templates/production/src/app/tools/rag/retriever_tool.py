from __future__ import annotations

from src.app.tools.base import BaseTool


class RetrieverTool(BaseTool):
    def __init__(self) -> None:
        super().__init__(name="retriever", description="Retrieve relevant snippets from an in-memory corpus.")
        self._corpus = [
            "Validation requires coverage and confidence above threshold.",
            "Calculator tasks can use the calculator tool for deterministic execution.",
            "Prompt versions allow safe iteration across node behaviors.",
        ]

    def run(self, **kwargs):
        query = kwargs.get("query", "").lower()
        matches = [item for item in self._corpus if any(token in item.lower() for token in query.split()[:3])]
        return {"tool": self.name, "matches": matches[:2] or self._corpus[:1]}
