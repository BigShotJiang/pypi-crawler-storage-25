from __future__ import annotations

from src.app.tools.base import BaseTool


class CalculatorTool(BaseTool):
    def __init__(self) -> None:
        super().__init__(name="calculator", description="Perform arithmetic on a list of values.")

    def run(self, **kwargs):
        operation = kwargs.get("operation", "add")
        values = kwargs.get("values", [])
        if not values:
            return {"tool": self.name, "operation": operation, "result": 0}
        if operation == "multiply":
            result = 1
            for value in values:
                result *= value
        else:
            result = sum(values)
        return {"tool": self.name, "operation": operation, "result": result}
