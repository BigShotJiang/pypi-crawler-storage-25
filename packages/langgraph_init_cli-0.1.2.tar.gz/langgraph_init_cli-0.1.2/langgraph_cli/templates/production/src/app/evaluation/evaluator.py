from __future__ import annotations


class Evaluator:
    def evaluate(self, extracted: dict[str, object], prompt: str) -> dict[str, object]:
        populated = [value for value in extracted.values() if value not in ("", None, [], {})]
        total_fields = max(len(extracted), 1)
        coverage = len(populated) / total_fields
        return {
            "field_coverage": round(coverage, 2),
            "checked_with_prompt": bool(prompt),
        }
