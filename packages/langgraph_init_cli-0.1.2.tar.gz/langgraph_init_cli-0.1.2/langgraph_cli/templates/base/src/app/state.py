from typing import TypedDict


class AppState(TypedDict, total=False):
    user_input: str
    topic: str
    response: str
