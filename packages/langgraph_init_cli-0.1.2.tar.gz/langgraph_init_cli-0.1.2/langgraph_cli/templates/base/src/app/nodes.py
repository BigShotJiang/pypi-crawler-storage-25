from src.app.state import AppState


def intake_node(state: AppState) -> AppState:
    text = state.get("user_input", "").strip()
    topic = "general"
    lowered = text.lower()
    if "billing" in lowered:
        topic = "billing"
    elif "support" in lowered:
        topic = "support"
    return {"topic": topic}


def draft_node(state: AppState) -> AppState:
    topic = state.get("topic", "general")
    text = state.get("user_input", "")
    return {"response": f"[{topic}] {text}"}


def output_node(state: AppState) -> AppState:
    return {"response": state.get("response", "No response generated.")}
