"""Base app package."""
