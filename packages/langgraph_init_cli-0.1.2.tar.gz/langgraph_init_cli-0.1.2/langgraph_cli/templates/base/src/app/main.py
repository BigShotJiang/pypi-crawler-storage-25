from langgraph.graph import END, START, StateGraph

from src.app.nodes import draft_node, intake_node, output_node
from src.app.state import AppState


def build_graph():
    graph = StateGraph(AppState)
    graph.add_node("intake", intake_node)
    graph.add_node("draft", draft_node)
    graph.add_node("output", output_node)
    graph.add_edge(START, "intake")
    graph.add_edge("intake", "draft")
    graph.add_edge("draft", "output")
    graph.add_edge("output", END)
    return graph.compile()


def run() -> AppState:
    app = build_graph()
    result = app.invoke({"user_input": "Support request for order status"})
    print(result["response"])
    return result


if __name__ == "__main__":
    run()
