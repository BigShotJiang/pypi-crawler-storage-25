from __future__ import annotations

import shutil
from importlib import resources
from pathlib import Path

TEMPLATE_NAMES = ("base", "advanced", "production")
TOKEN_MAP_KEY = "{{PROJECT_NAME}}"


def _template_root() -> Path:
    return Path(str(resources.files("langgraph_cli").joinpath("templates")))


def _replace_tokens(content: str, project_name: str) -> str:
    return content.replace(TOKEN_MAP_KEY, project_name)


def scaffold_project(project_name: str, template_name: str, target_dir: Path) -> Path:
    source_dir = _template_root() / template_name
    if not source_dir.exists():
        raise FileNotFoundError(f"Template '{template_name}' does not exist.")

    if target_dir.exists() and any(target_dir.iterdir()):
        raise FileExistsError(f"Target directory '{target_dir}' already exists and is not empty.")

    target_dir.mkdir(parents=True, exist_ok=True)

    for source_path in source_dir.rglob("*"):
        if "__pycache__" in source_path.parts or source_path.suffix == ".pyc":
            continue
        relative_path = source_path.relative_to(source_dir)
        destination = target_dir / relative_path

        if source_path.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            continue

        destination.parent.mkdir(parents=True, exist_ok=True)
        if source_path.suffix in {".png", ".jpg", ".jpeg", ".gif", ".ico"}:
            shutil.copy2(source_path, destination)
            continue

        rendered = _replace_tokens(source_path.read_text(encoding="utf-8"), project_name=project_name)
        destination.write_text(rendered, encoding="utf-8")

    return target_dir
