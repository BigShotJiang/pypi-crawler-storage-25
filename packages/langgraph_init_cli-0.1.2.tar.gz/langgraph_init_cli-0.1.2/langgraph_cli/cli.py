from pathlib import Path

import typer

from langgraph_cli.generator import TEMPLATE_NAMES, scaffold_project

app = typer.Typer(
    add_completion=False,
    help="Scaffold LangGraph projects with modular templates.",
)


@app.command()
def main(
    project_name: str = typer.Argument(..., help="Directory name for the new project."),
    template: str = typer.Option(
        "base",
        "--template",
        "-t",
        help="Project template to use.",
        case_sensitive=False,
    ),
) -> None:
    normalized = template.lower()
    if normalized not in TEMPLATE_NAMES:
        typer.secho(
            f"Unsupported template '{template}'. Choose from: {', '.join(TEMPLATE_NAMES)}.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=1)

    target_path = Path(project_name).resolve()
    scaffold_project(project_name=project_name, template_name=normalized, target_dir=target_path)
    typer.secho(
        f"Created {normalized} LangGraph project at {target_path}",
        fg=typer.colors.GREEN,
    )


if __name__ == "__main__":
    app()
