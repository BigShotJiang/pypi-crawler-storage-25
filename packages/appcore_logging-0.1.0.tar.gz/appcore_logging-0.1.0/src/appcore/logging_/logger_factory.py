"""Logger creation helpers for appcore."""

from __future__ import annotations

import json
import logging
import logging.handlers
import socket
import sys
from pathlib import Path

import structlog
from sqlalchemy.engine import Engine

from appcore.config import LoggingSettings, LoggingSinkConfig
from appcore.logging_.filters import SensitiveDataFilter
from appcore.logging_.handlers import BufferingSMTPHandler, DBHandler

LEVELS = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "FATAL": logging.CRITICAL,
    "CRITICAL": logging.CRITICAL,
}


class JsonFormatter(logging.Formatter):
    """Serialize log records as JSON strings."""

    def format(self, record: logging.LogRecord) -> str:
        """Return the record as a JSON string."""
        payload = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        return json.dumps(payload, ensure_ascii=True)


def to_level(level_name: str) -> int:
    """Translate a level name to a logging level integer."""
    return LEVELS.get(level_name.upper(), logging.INFO)


class LoggerFactory:
    """Construct the root application logger and its configured sinks."""

    @staticmethod
    def create(settings: LoggingSettings, db_engine: Engine | None = None) -> logging.Logger:
        """Build and return the root my_app logger."""
        logger = logging.getLogger("my_app")
        logger.setLevel(to_level(settings.level))
        logger.propagate = False

        for handler in list(logger.handlers):
            logger.removeHandler(handler)
            handler.close()

        logger.filters.clear()
        logger.addFilter(SensitiveDataFilter())

        if settings.structured:
            structlog.configure(
                processors=[
                    structlog.processors.add_log_level,
                    structlog.processors.TimeStamper(fmt="iso"),
                    structlog.processors.JSONRenderer(),
                ],
                logger_factory=structlog.stdlib.LoggerFactory(),
                wrapper_class=structlog.stdlib.BoundLogger,
            )

        formatter: logging.Formatter
        formatter = JsonFormatter() if settings.structured else logging.Formatter(settings.format)

        for sink in settings.sinks:
            handler = LoggerFactory._build_handler(sink, db_engine)
            if handler is None:
                continue
            handler.setLevel(to_level(sink.level))
            handler.setFormatter(formatter)
            logger.addHandler(handler)

        return logger

    @staticmethod
    def _build_handler(
        sink: LoggingSinkConfig,
        db_engine: Engine | None,
    ) -> logging.Handler | None:
        """Create a handler for one sink configuration."""
        if sink.type == "console":
            return logging.StreamHandler(sys.stdout)

        if sink.type == "rolling_file":
            path = Path(sink.path or "logs/app.log")
            path.parent.mkdir(parents=True, exist_ok=True)
            return logging.handlers.RotatingFileHandler(
                filename=path,
                maxBytes=sink.max_bytes,
                backupCount=sink.backup_count,
                encoding=sink.encoding,
            )

        if sink.type == "timed_rolling_file":
            path = Path(sink.path or "logs/app-daily.log")
            path.parent.mkdir(parents=True, exist_ok=True)
            return logging.handlers.TimedRotatingFileHandler(
                filename=path,
                when=sink.when,
                backupCount=sink.backup_count,
                encoding=sink.encoding,
            )

        if sink.type == "email":
            if sink.smtp_host is None or sink.from_addr is None or not sink.to_addrs:
                return None
            return BufferingSMTPHandler(
                smtp_host=sink.smtp_host,
                smtp_port=sink.smtp_port,
                use_ssl=sink.use_ssl,
                from_addr=sink.from_addr,
                to_addrs=sink.to_addrs,
                cc_addrs=sink.cc_addrs,
                bcc_addrs=sink.bcc_addrs,
                subject_template=sink.subject,
                capacity=sink.buffer_capacity,
            )

        if sink.type == "database":
            if db_engine is None:
                return None
            try:
                return DBHandler(db_engine, sink.table_name)
            except Exception:
                return None

        if sink.type == "syslog":
            if sink.host is None:
                return None
            socktype = socket.SOCK_DGRAM if sink.protocol == "udp" else socket.SOCK_STREAM
            facility = logging.handlers.SysLogHandler.facility_names.get(sink.facility, 16)
            return logging.handlers.SysLogHandler(
                address=(sink.host, sink.port),
                facility=facility,
                socktype=socktype,
            )

        return None
