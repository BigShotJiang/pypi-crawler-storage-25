"""Logging filters for sensitive data scrubbing."""

from __future__ import annotations

import logging
import re


class SensitiveDataFilter(logging.Filter):
    """Scrub sensitive patterns from log records before they are emitted."""

    PATTERNS = [
        re.compile(r"ENC\([^)]+\)"),
        re.compile(r"(?i)(password|secret|key)\s*[=:]\s*\S+"),
    ]

    def filter(self, record: logging.LogRecord) -> bool:
        """Sanitize the record message and arguments in place."""
        record.msg = self._scrub(str(record.msg))
        if isinstance(record.args, tuple):
            record.args = tuple(self._scrub(str(arg)) for arg in record.args)
        elif record.args:
            record.args = self._scrub(str(record.args))
        return True

    @classmethod
    def _scrub(cls, text: str) -> str:
        """Replace sensitive content with a redaction marker."""
        scrubbed = text
        for pattern in cls.PATTERNS:
            scrubbed = pattern.sub("[REDACTED]", scrubbed)
        return scrubbed
