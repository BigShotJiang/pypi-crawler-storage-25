"""Custom logging handlers used by appcore."""

from __future__ import annotations

import json
import logging
import logging.handlers
import queue
import smtplib
import sys
import threading
from collections.abc import Mapping
from datetime import datetime, timezone
from email.message import EmailMessage
from typing import Any

from sqlalchemy import text
from sqlalchemy.engine import Engine


class BufferingSMTPHandler(logging.handlers.MemoryHandler):
    """Buffer records and send them as a single email message."""

    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        use_ssl: bool,
        from_addr: str,
        to_addrs: list[str],
        cc_addrs: list[str],
        bcc_addrs: list[str],
        subject_template: str,
        capacity: int,
    ) -> None:
        """Initialize the email buffering handler."""
        super().__init__(capacity=capacity, flushLevel=logging.CRITICAL, target=None)
        self._smtp_host = smtp_host
        self._smtp_port = smtp_port
        self._use_ssl = use_ssl
        self._from_addr = from_addr
        self._to_addrs = to_addrs
        self._cc_addrs = cc_addrs
        self._bcc_addrs = bcc_addrs
        self._subject_template = subject_template

    def shouldFlush(self, record: logging.LogRecord) -> bool:
        """Flush when the buffer is full or a fatal record arrives."""
        return len(self.buffer) >= self.capacity or record.levelno >= logging.CRITICAL

    def flush(self) -> None:
        """Send the buffered records and swallow SMTP failures."""
        self.acquire()
        try:
            records = list(self.buffer)
            self.buffer.clear()
        finally:
            self.release()

        if not records:
            return

        try:
            self._send(records)
        except Exception as exc:  # pragma: no cover - validated via stderr contract
            print(f"[logging] email sink error: {exc}", file=sys.stderr)

    def _send(self, records: list[logging.LogRecord]) -> None:
        """Send the buffered records as one SMTP message."""
        highest = max(records, key=lambda record: record.levelno)
        subject = self._subject_template.format(levelname=highest.levelname)
        body = "\n".join(self.format(record) for record in records)

        message = EmailMessage()
        message["From"] = self._from_addr
        message["To"] = ", ".join(self._to_addrs)
        if self._cc_addrs:
            message["Cc"] = ", ".join(self._cc_addrs)
        if self._bcc_addrs:
            message["Bcc"] = ", ".join(self._bcc_addrs)
        message["Subject"] = subject
        message.set_content(body)

        recipients = [*self._to_addrs, *self._cc_addrs, *self._bcc_addrs]
        with smtplib.SMTP(self._smtp_host, self._smtp_port) as smtp:
            if self._use_ssl:
                smtp.starttls()
            smtp.sendmail(self._from_addr, recipients, message.as_string())


class DBHandler(logging.Handler):
    """Insert log records asynchronously into a database table."""

    _stderr_reported = False

    def __init__(self, engine: Engine, table_name: str) -> None:
        """Create the queue-backed database handler."""
        super().__init__()
        self._engine = engine
        self._table_name = table_name
        self._queue: queue.Queue[logging.LogRecord | None] = queue.Queue()
        self._thread = threading.Thread(target=self._worker, name="appcore-db-log", daemon=True)
        self._ensure_table()
        self._thread.start()

    def emit(self, record: logging.LogRecord) -> None:
        """Queue the record without blocking the caller."""
        try:
            self._queue.put_nowait(record)
        except queue.Full:
            return

    def close(self) -> None:
        """Stop the background worker and close the handler."""
        self._queue.put(None)
        self._thread.join(timeout=1)
        super().close()

    def _worker(self) -> None:
        """Process queued records until a sentinel is received."""
        while True:
            record = self._queue.get()
            if record is None:
                return
            try:
                self._insert(record)
            except Exception as exc:  # pragma: no cover - validated via stderr contract
                if not DBHandler._stderr_reported:
                    print(f"[logging] database sink error: {exc}", file=sys.stderr)
                    DBHandler._stderr_reported = True

    def _ensure_table(self) -> None:
        """Create the target logging table if it does not already exist."""
        ddl = text(
            f"""
            CREATE TABLE IF NOT EXISTS {self._table_name} (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP NOT NULL,
                level VARCHAR(10) NOT NULL,
                logger_name VARCHAR(255),
                message TEXT,
                exc_info TEXT,
                extra TEXT
            )
            """
        )
        with self._engine.begin() as connection:
            connection.execute(ddl)

    def _insert(self, record: logging.LogRecord) -> None:
        """Insert one log record into the target table."""
        exc_text = None
        if record.exc_info is not None:
            exc_text = self.formatter.formatException(record.exc_info) if self.formatter else None

        extra = {
            key: value
            for key, value in record.__dict__.items()
            if key not in logging.LogRecord("", 0, "", 0, "", (), None).__dict__
        }
        payload = {
            "timestamp": datetime.fromtimestamp(record.created, tz=timezone.utc),
            "level": record.levelname,
            "logger_name": record.name,
            "message": self.format(record),
            "exc_info": exc_text,
            "extra": json.dumps(extra) if extra else None,
        }
        statement = text(
            f"""
            INSERT INTO {self._table_name}
            (timestamp, level, logger_name, message, exc_info, extra)
            VALUES (:timestamp, :level, :logger_name, :message, :exc_info, :extra)
            """
        )
        with self._engine.begin() as connection:
            connection.execute(statement, payload)
