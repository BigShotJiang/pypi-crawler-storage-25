import pandas as pd
import streamlit as st
import numpy as np
    
def video_tab(schema=None):
    import streamlit as st
    st.write("### Pose estimation label sets")
    @st.cache_data    
    def get_labelsets():
        df =  pd.DataFrame(schema.PoseEstimationLabelSet().fetch())
        df.insert(0, "Select", False)
        return df

    labelsets = get_labelsets()
    label_df = st.data_editor(labelsets.sort_index(),
                                hide_index=True,
                                disabled = ['pose_label_set_num'])
    
    if label_df['Select'].sum():
        selected  = label_df[label_df['Select'] == True].to_dict(orient='records')[0]
        
        frames = (schema.PoseEstimationLabelSet.Frame & f'pose_label_set_num = "{selected["pose_label_set_num"]}"').fetch("KEY")
        import plotly.express as px
        if len(frames):
            
            iframe = st.slider(label = 'Label frame',min_value = 0, 
                              max_value = len(frames)-1,
                              value = 0)
            frame = (schema.PoseEstimationLabelSet.Frame & frames[iframe]).fetch1('frame')
            if not len(frame.shape) == 3:   
                frame = np.stack([frame]*3).transpose(1,2,0)
            im = px.imshow(frame)
            posdf = pd.DataFrame((schema.PoseEstimationLabelSet.Label & frames[iframe]).fetch())
            if len(posdf):
                import plotly.graph_objects as go
                im.add_scatter(x = posdf.x.values,y = posdf.y.values,line=None,
                               text = posdf.label_name.values,
                               marker=dict(color=posdf.index.values,
                                           colorscale = 'jet', opacity = 0.9, size=5,
                                           symbol='circle'),
                               hoverinfo='text',
                               mode='markers')
            im.update_layout(xaxis_visible=False, 
                            yaxis_visible=False,
                            xaxis_showgrid=False, 
                            yaxis_showgrid=False,
                            xaxis_zeroline=False, 
                            yaxis_zeroline=False)

            st.plotly_chart(im,use_container_width=True)
        else:
            st.write('No frames available.')

    col1, col2 = st.columns([1, 5])
    @st.cache_data
    def get_subjects():
        df = np.unique((schema.DatasetVideo()).fetch('subject_name'))
        df = pd.DataFrame(df,columns = ['subject_name'])
        
        df.insert(0, "Select", False)
        return df.set_index("subject_name").sort_index()
    @st.cache_data    
    def get_sessions(keys):
        if len(keys):
            keys = keys.reset_index()
            dfs = []
            for i in range(len(keys)):
                dfs.append(pd.DataFrame((schema.Session*schema.DatasetVideo.proj() &
                                         f'subject_name = "{keys["subject_name"].iloc[i]}"').fetch()))
                df = pd.concat([d for d in dfs if len(d)])
            return df.set_index("session_datetime").sort_index()
        return None
    subjects = get_subjects() 
    col1.write("### Subjects", )
    edited_df = col1.data_editor(subjects.sort_index(),
                               hide_index=False,
                               disabled = ['subject_name'])
                               #column_config={"Select":
                               #               st.column_config.CheckboxColumn(required=True)},)
    sessions = get_sessions(edited_df[edited_df['Select'] == True])
    
    @st.cache_data
    def get_frame_info(schema,sessions,selection):
        frames = None
        if len(selection.selection.rows):
            frames = (schema.DatasetVideo.Frame & [dict(s) for i,s in sessions.iloc[selection.selection.rows].iterrows()]).proj().fetch(as_dict = True)
        return frames
    
    @st.cache_data
    def get_frame(selected):
        try:
            return (schema.DatasetVideo.Frame() & selected).fetch1('frame')
        except:
            st.write('Could not get frame. Use C to clear cache')
        return None
    
    
    if sessions is None:
        col1.write('No subjects selected.')
    else:
        tx = f'### Sessions ({len(sessions)})'
        col2.write(tx)        
        selection = col2.dataframe(sessions,
                    on_select='rerun',
                    selection_mode="multi-row",) 
        frames = get_frame_info(schema,sessions,selection)
        if not frames is None:
            slide = col2.slider(label = 'Frame',min_value = 0, 
                              max_value = len(frames)-1,
                              value = 0)
            if slide<len(frames):
                im = get_frame(frames[slide])
                if not im is None:
                    col1.write(frames[slide])
                    col2.image(im)
            else:
                col2.write('No frames available.')

    