import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import subprocess
import os
import re
import tempfile
from typing import List
from config.config_loader import get_config

_DEFAULT_NGINX = get_config().get_validate_config().get("nginx_path", "nginx")

app = typer.Typer(help="Проверка синтаксиса nginx-конфига через nginx -t с подсветкой ошибок.")
console = Console()

ERRORS_RE = re.compile(r'in (.+?):(\d+)(?:\s*\n)?(.+?)(?=\nin |$)', re.DOTALL)


def _extract_nginx_warn_lines(output: str) -> List[str]:
    if not output:
        return []
    return [l.strip() for l in output.splitlines() if re.search(r"\[warn\]", l, re.IGNORECASE)]


def syntax(
    config_path: str = typer.Option(None, "-c", "--config", help="Путь к кастомному nginx.conf"),
    includes: List[str] = typer.Option(
        None,
        "--includes",
        help=("Проверить include-файлы (например conf.d/*.conf). Режим блока (http/stream) выбирается автоматически "
              "по расширению файла (например *.stream, *.stream.conf → stream; иначе → http). "
              "Можно указать несколько раз: --includes a.conf --includes b.conf"),
    ),
    includes_http: List[str] = typer.Option(
        None,
        "--includes-http",
        help="То же, что --includes, но всегда валидировать как http include (http { include ... }).",
    ),
    includes_stream: List[str] = typer.Option(
        None,
        "--includes-stream",
        help="То же, что --includes, но всегда валидировать как stream include (stream { include ... }).",
    ),
    nginx_path: str = typer.Option(
        _DEFAULT_NGINX,
        help="Путь к бинарю nginx (по умолчанию: [validate.nginx_path] в конфиге, иначе 'nginx')",
    ),
    skip_warns: bool = typer.Option(
        False,
        "--skip-warns",
        help="Игнорировать предупреждения [warn] от nginx (при exit 0, без сбоя проверки).",
    ),
):
    """
    Проверяет синтаксис nginx-конфига через nginx -t.

    В случае ошибки показывает место в виде таблицы с контекстом.

    Пример:
        nginx-lens syntax -c ./mynginx.conf
        nginx-lens syntax
        nginx-lens syntax --includes ./conf.d/site.conf
        nginx-lens syntax --includes-stream ./conf.d/stream.conf.stream
    """
    includes_any = bool(includes or includes_http or includes_stream)
    if includes_any and config_path:
        console.print("[red]Нельзя одновременно использовать -c/--config и --includes.[/red]")
        raise typer.Exit(1)

    if includes_any:
        if includes and (includes_http or includes_stream):
            console.print("[red]Нельзя смешивать --includes с --includes-http/--includes-stream.[/red]")
            raise typer.Exit(1)
        if includes_http and includes_stream:
            console.print("[red]Нельзя одновременно использовать --includes-http и --includes-stream.[/red]")
            raise typer.Exit(1)

        def _is_stream_path(p: str) -> bool:
            lp = p.lower()
            return lp.endswith(".stream") or lp.endswith(".stream.conf") or lp.endswith(".stream.stream")

        include_paths_raw = includes_http or includes_stream or includes or []
        include_paths = [os.path.abspath(p) for p in include_paths_raw]
        missing = [p for p in include_paths if not os.path.isfile(p)]
        if missing:
            for p in missing:
                console.print(f"[red]Файл {p} не найден. Проверьте путь.[/red]")
            raise typer.Exit(1)

        with tempfile.TemporaryDirectory(prefix="nginx-lens-syntax-") as td:
            wrapper_path = os.path.join(td, "nginx.conf")

            http_includes: List[str] = []
            stream_includes: List[str] = []
            if includes_http:
                http_includes = include_paths
            elif includes_stream:
                stream_includes = include_paths
            else:
                for p in include_paths:
                    (stream_includes if _is_stream_path(p) else http_includes).append(p)

            http_lines = "\n".join(f"    include {p};" for p in http_includes)
            stream_lines = "\n".join(f"    include {p};" for p in stream_includes)

            wrapper_parts = [
                "worker_processes  1;\n",
                "error_log stderr notice;\n",
                "pid /tmp/nginx-lens.pid;\n",
                "\n",
                "events { worker_connections  1024; }\n",
                "\n",
            ]
            if http_includes:
                wrapper_parts.append("http {\n")
                wrapper_parts.append(f"{http_lines}\n")
                wrapper_parts.append("}\n\n")
            if stream_includes:
                wrapper_parts.append("stream {\n")
                wrapper_parts.append(f"{stream_lines}\n")
                wrapper_parts.append("}\n")

            wrapper = "".join(wrapper_parts)
            with open(wrapper_path, "w", encoding="utf-8") as f:
                f.write(wrapper)

            prefix_dir = os.path.dirname(include_paths[0])
            cmd = [nginx_path, "-t", "-p", prefix_dir, "-c", wrapper_path]
            if hasattr(os, "geteuid") and os.geteuid() != 0:
                cmd = ["sudo"] + cmd

            try:
                result = subprocess.run(cmd, capture_output=True, text=True, check=False)
            except FileNotFoundError:
                console.print(f"[red]Не найден бинарь nginx: {nginx_path}[/red]")
                raise typer.Exit(1)

            combined = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
            warn_lines = _extract_nginx_warn_lines(combined)

            if result.returncode == 0:
                if warn_lines and not skip_warns:
                    wtable = Table(
                        title="[bold yellow]Предупреждения nginx[/bold yellow] [dim]([warn])[/dim]",
                        show_header=True,
                        header_style="bold yellow",
                        box=box.ROUNDED,
                        border_style="yellow",
                        show_lines=True,
                    )
                    wtable.add_column("Сообщение", overflow="fold")
                    for w in warn_lines:
                        wtable.add_row(w)
                    console.print(wtable)
                    console.print(
                        Panel(
                            "[red]Проверка не пройдена: есть предупреждения [warn]. "
                            "Запустите с [bold]--skip-warns[/bold], если их можно игнорировать.[/red]",
                            box=box.ROUNDED,
                            border_style="red",
                        )
                    )
                    raise typer.Exit(1)
                if warn_lines and skip_warns:
                    wbody = "\n".join(f"[yellow]{w}[/yellow]" for w in warn_lines)
                    console.print(
                        Panel(
                            wbody
                            + "\n\n[green]Синтаксис корректен; предупреждения пропущены ([bold]--skip-warns[/bold]).[/green]",
                            title="[dim]Предупреждения (пропущены)[/dim]",
                            box=box.ROUNDED,
                            border_style="yellow",
                        )
                    )
                    raise typer.Exit(0)
                console.print(
                    Panel(
                        "[green bold]Синтаксис корректен[/green bold]\n"
                        + "\n".join(f"[dim]{p}[/dim]" for p in include_paths),
                        title="[bold]nginx -t (includes)[/bold]",
                        box=box.ROUNDED,
                        border_style="green",
                    )
                )
                raise typer.Exit(0)

            console.print("[red]Ошибка синтаксиса (includes)![/red]")
            if result.stdout:
                console.print(result.stdout)
            if result.stderr:
                console.print(result.stderr)
            err = result.stderr or result.stdout
            errors = list(ERRORS_RE.finditer(err))
            if not errors:
                console.print("[red]Не удалось определить файл и строку ошибки[/red]")
                raise typer.Exit(1)
            table = Table(
                title="[bold red]Ошибки синтаксиса[/bold red]",
                show_header=True,
                header_style="bold red",
                box=box.ROUNDED,
                border_style="red",
                show_lines=True,
            )
            table.add_column("Файл", overflow="fold", style="bright_red")
            table.add_column("Сообщение", overflow="fold")
            table.add_column("Контекст", overflow="fold", style="dim")
            for m in errors:
                file, line, msg = m.group(1), int(m.group(2)), m.group(3).strip().split("\n")[0]
                context_lines = []
                try:
                    with open(file, encoding="utf-8", errors="replace") as f:
                        lines = f.readlines()
                    start = max(0, line - 3)
                    end = min(len(lines), line + 2)
                    for i in range(start, end):
                        mark = "->" if i + 1 == line else "  "
                        context_lines.append(f"{mark} {lines[i].rstrip()}")
                except Exception:
                    context_lines = []
                table.add_row(file, msg, "\n".join(context_lines))
            console.print(table)
            raise typer.Exit(1)

    if not config_path:
        # Сначала пробуем получить из конфига
        config = get_config()
        config_path = config.get_nginx_config_path()
        
        # Если не найден в конфиге, пробуем автопоиск
        if not config_path:
            candidates = [
                "/etc/nginx/nginx.conf",
                "/usr/local/etc/nginx/nginx.conf",
                "./nginx.conf"
            ]
            config_path = next((p for p in candidates if os.path.isfile(p)), None)
        
        if not config_path:
            console.print("[red]Не удалось найти nginx.conf.[/red]")
            console.print("[yellow]Укажите путь через -c или настройте nginx_config_path в конфиге.[/yellow]")
            raise typer.Exit(1)
    if not os.path.isfile(config_path):
        console.print(f"[red]Файл {config_path} не найден. Проверьте путь к конфигу.[/red]")
        raise typer.Exit(1)
    
    cmd = [nginx_path, "-t", "-c", os.path.abspath(config_path)]
    if hasattr(os, 'geteuid') and os.geteuid() != 0:
        cmd = ["sudo"] + cmd
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        combined = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
        warn_lines = _extract_nginx_warn_lines(combined)

        if result.returncode == 0:
            if warn_lines and not skip_warns:
                wtable = Table(
                    title="[bold yellow]Предупреждения nginx[/bold yellow] [dim]([warn])[/dim]",
                    show_header=True,
                    header_style="bold yellow",
                    box=box.ROUNDED,
                    border_style="yellow",
                    show_lines=True,
                )
                wtable.add_column("Сообщение", overflow="fold")
                for w in warn_lines:
                    wtable.add_row(w)
                console.print(wtable)
                console.print(
                    Panel(
                        "[red]Проверка не пройдена: есть предупреждения [warn]. "
                        "Запустите с [bold]--skip-warns[/bold], если их можно игнорировать.[/red]",
                        box=box.ROUNDED,
                        border_style="red",
                    )
                )
                raise typer.Exit(1)
            if warn_lines and skip_warns:
                wbody = "\n".join(f"[yellow]{w}[/yellow]" for w in warn_lines)
                console.print(
                    Panel(
                        wbody
                        + "\n\n[green]Синтаксис корректен; предупреждения пропущены ([bold]--skip-warns[/bold]).[/green]",
                        title="[dim]Предупреждения (пропущены)[/dim]",
                        box=box.ROUNDED,
                        border_style="yellow",
                    )
                )
                raise typer.Exit(0)
            console.print(
                Panel(
                    f"[green bold]Синтаксис корректен[/green bold]\n[dim]{os.path.abspath(config_path)}[/dim]",
                    title="[bold]nginx -t[/bold]",
                    box=box.ROUNDED,
                    border_style="green",
                )
            )
            raise typer.Exit(0)

        console.print("[red]Ошибка синтаксиса![/red]")
        if result.stdout:
            console.print(result.stdout)
        if result.stderr:
            console.print(result.stderr)
        # Парсим все ошибки
        err = result.stderr or result.stdout
        errors = list(ERRORS_RE.finditer(err))
        if not errors:
            console.print("[red]Не удалось определить файл и строку ошибки[/red]")
            raise typer.Exit(1)
        table = Table(
            title="[bold red]Ошибки синтаксиса[/bold red]",
            show_header=True,
            header_style="bold red",
            box=box.ROUNDED,
            border_style="red",
            show_lines=True,
        )
        table.add_column("Файл", overflow="fold", style="bright_red")
        table.add_column("Сообщение", overflow="fold")
        table.add_column("Контекст", overflow="fold", style="dim")
        for m in errors:
            file, line, msg = m.group(1), int(m.group(2)), m.group(3).strip().split('\n')[0]
            # Читаем контекст
            context_lines = []
            try:
                with open(file) as f:
                    lines = f.readlines()
                start = max(0, line-3)
                end = min(len(lines), line+2)
                for i in range(start, end):
                    mark = "->" if i+1 == line else "  "
                    context_lines.append(f"{mark} {lines[i].rstrip()}")
            except Exception:
                context_lines = []
            table.add_row(file, msg, '\n'.join(context_lines))
        console.print(table)
        raise typer.Exit(1)
    except FileNotFoundError:
        console.print(f"[red]Не найден бинарь nginx: {nginx_path}[/red]")
        raise typer.Exit(1)