"""SDK correctness tests: snake_case JSON (SC1), stub imports (SC2), make generate (SC3)."""

import importlib
import os
import subprocess
import sys
from pathlib import Path

import pytest
import requests

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Root of the monorepo.
# File is at: python-client/connector-service/tests/test_sdk_correctness.py
# Path hierarchy (each .parent goes one directory up):
#   tests/           <- parent 1
#   connector-service/ <- parent 2
#   python-client/   <- parent 3
#   project root/    <- parent 4 (where Makefile lives)
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent

API_BASE_URL = os.environ.get("API_BASE_URL", "").rstrip("/")
API_TOKEN = os.environ.get("API_TOKEN", "")
API_WORKSPACE = os.environ.get("API_WORKSPACE", "test-workspace")


# ---------------------------------------------------------------------------
# SC1: REST JSON responses use snake_case field names (requires live api-server)
# ---------------------------------------------------------------------------

class TestSnakeCaseJsonFields:
    """SC1: REST JSON responses use snake_case field names (requires live api-server)."""

    @pytest.fixture(autouse=True)
    def require_live_server(self):
        if not API_BASE_URL or not API_TOKEN:
            pytest.skip(
                "SC1 requires API_BASE_URL and API_TOKEN env vars (live api-server)"
            )

    def test_list_connectors_json_keys_are_snake_case(self):
        """GET .../connectors response has no camelCase field names in JSON body."""
        url = f"{API_BASE_URL}/v1alpha/workspaces/{API_WORKSPACE}/connectors"
        resp = requests.get(
            url,
            headers={"Authorization": f"Bearer {API_TOKEN}"},
            timeout=10,
        )
        assert resp.status_code == 200, f"{resp.status_code}: {resp.text}"
        # Scan for known camelCase keys that appear when UseProtoNames is NOT set
        body_str = resp.text
        known_camel = [
            "authToken",
            "workerId",
            "connectionId",
            "statusDetails",
            "dataSourceType",
            "workerEndpoint",
            "connectorTemplates",
        ]
        for key in known_camel:
            assert f'"{key}"' not in body_str, (
                f"camelCase key '{key}' found in JSON response. "
                f"api-server gRPC-Gateway is not using UseProtoNames=true. "
                f"Body: {body_str[:300]}"
            )

    def test_list_connections_json_keys_are_snake_case(self):
        """GET .../connections response has no camelCase field names in JSON body."""
        url = f"{API_BASE_URL}/v1alpha/workspaces/{API_WORKSPACE}/connections"
        resp = requests.get(
            url,
            headers={"Authorization": f"Bearer {API_TOKEN}"},
            timeout=10,
        )
        assert resp.status_code == 200, f"{resp.status_code}: {resp.text}"
        body_str = resp.text
        known_camel = [
            "connectionId",
            "workerId",
            "authToken",
            "workerEndpoint",
            "statusDetails",
        ]
        for key in known_camel:
            assert f'"{key}"' not in body_str, (
                f"camelCase key '{key}' found in JSON response. "
                f"api-server gRPC-Gateway is not using UseProtoNames=true. "
                f"Body: {body_str[:300]}"
            )


# ---------------------------------------------------------------------------
# SC2: All gen/ stubs import without ImportError
# ---------------------------------------------------------------------------

class TestStubImports:
    """SC2: All gen/ stubs import without ImportError."""

    GEN_DIR = (
        Path(__file__).resolve().parent.parent
        / "src" / "h2o_connector_service" / "gen"
    )

    def test_gen_directory_exists(self):
        """gen/ directory exists — make generate has been run."""
        assert self.GEN_DIR.exists(), (
            f"gen/ directory not found at {self.GEN_DIR}. Run 'make generate' first."
        )

    def test_core_stubs_importable(self):
        """Core protobuf stubs import without ImportError."""
        modules = [
            "h2o_connector_service.gen.connection_pb2",
            "h2o_connector_service.gen.connector_pb2",
            "h2o_connector_service.gen.connector_service_pb2",
            "h2o_connector_service.gen.worker_pb2",
            "h2o_connector_service.gen.connection_service_pb2",
        ]
        for mod in modules:
            try:
                importlib.import_module(mod)
            except ImportError as e:
                pytest.fail(
                    f"ImportError importing {mod}: {e}\n"
                    f"Ensure protobuf>=4.25 and googleapis-common-protos>=1.56 "
                    f"are installed (declared in pyproject.toml [project.dependencies])."
                )

    def test_gen_google_directory_exists(self):
        """gen/google/ directory exists — google/ stubs were copied by make generate."""
        google_dir = self.GEN_DIR / "google"
        assert google_dir.exists(), (
            f"gen/google/ not found at {google_dir}. "
            f"Run 'make generate' to copy google/ stubs into the SDK gen/ directory."
        )
        annotations = google_dir / "api" / "annotations_pb2.py"
        assert annotations.exists(), (
            f"gen/google/api/annotations_pb2.py not found. "
            f"The cp -r step in Makefile generate target may not have run."
        )

    def test_google_api_stubs_exist_as_files(self):
        """google/ API stub files exist in gen/ (file presence check, not import).

        Note: Importing gen/google/ stubs directly may conflict with the system-installed
        googleapis-common-protos package (duplicate proto descriptor pool registration).
        The stubs in gen/google/ are packaged as wheel data for environments where the
        system package is absent; they coexist with googleapis-common-protos at runtime
        since Python protobuf uses the installed package's descriptors.
        This test verifies the files are present, not that they can be imported standalone.
        """
        google_dir = self.GEN_DIR / "google"
        required_files = [
            google_dir / "api" / "annotations_pb2.py",
            google_dir / "api" / "http_pb2.py",
        ]
        for f in required_files:
            assert f.exists(), (
                f"Expected google stub file not found: {f}. "
                f"Run 'make generate' — the cp -r step copies proto/gen/python/google/ "
                f"into the SDK gen/ directory."
            )


# ---------------------------------------------------------------------------
# SC3: make generate produces a fully importable SDK gen/ including google/ stubs
# ---------------------------------------------------------------------------

class TestMakeGenerate:
    """SC3: make generate produces a fully importable SDK gen/ including google/ stubs."""

    GEN_DIR = (
        Path(__file__).resolve().parent.parent
        / "src" / "h2o_connector_service" / "gen"
    )
    # File: python-client/connector-service/tests/test_sdk_correctness.py
    # parent(1)=tests parent(2)=connector-service parent(3)=python-client
    # parent(4)=project root
    PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent

    @pytest.fixture(autouse=True)
    def require_make_and_buf(self):
        """Skip if make or buf are not installed."""
        if subprocess.run(["which", "make"], capture_output=True).returncode != 0:
            pytest.skip("make not available")
        if subprocess.run(["which", "buf"], capture_output=True).returncode != 0:
            pytest.skip("buf not available")

    def test_project_root_has_makefile(self):
        """Sanity check: PROJECT_ROOT points to the repo root containing Makefile."""
        makefile = self.PROJECT_ROOT / "Makefile"
        assert makefile.exists(), (
            f"Makefile not found at {makefile}. "
            f"PROJECT_ROOT ({self.PROJECT_ROOT}) may be incorrect."
        )

    def test_make_generate_produces_google_stubs(self):
        """make generate from project root produces google/ stubs in SDK gen/."""
        result = subprocess.run(
            ["make", "generate"],
            cwd=str(self.PROJECT_ROOT),
            capture_output=True,
            text=True,
            timeout=120,
        )
        assert result.returncode == 0, (
            f"make generate failed (exit {result.returncode}).\n"
            f"stdout: {result.stdout[-500:]}\n"
            f"stderr: {result.stderr[-500:]}"
        )
        google_annotations = self.GEN_DIR / "google" / "api" / "annotations_pb2.py"
        assert google_annotations.exists(), (
            f"google/api/annotations_pb2.py not found in gen/ after make generate. "
            f"The Makefile generate target must copy proto/gen/python/google/ to the SDK gen/. "
            f"Expected: {google_annotations}"
        )

    def test_make_generate_core_stubs_importable(self):
        """After make generate, core gen/ stubs (excluding google/) are importable."""
        mods_to_check = [
            "h2o_connector_service.gen.connection_pb2",
            "h2o_connector_service.gen.connector_service_pb2",
        ]
        for mod in mods_to_check:
            # Remove from cache to force fresh import
            for cached in list(sys.modules.keys()):
                if cached.startswith("h2o_connector_service.gen"):
                    del sys.modules[cached]
            try:
                importlib.import_module(mod)
            except ImportError as e:
                pytest.fail(
                    f"ImportError importing {mod} after make generate: {e}"
                )
