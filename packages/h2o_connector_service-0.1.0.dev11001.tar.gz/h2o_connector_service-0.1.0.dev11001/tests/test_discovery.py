"""Tests for h2o Cloud Discovery integration: _TokenAuth, Client.from_discovery(), deprecation warning."""

from __future__ import annotations

import pytest
import httpx
from unittest.mock import MagicMock, patch

from h2o_connector_service._base import Client, _TokenAuth
from h2o_connector_service import ConnectorService


# ---------------------------------------------------------------------------
# Helper: build a mock discovery object with a connector-service entry
# ---------------------------------------------------------------------------

def _make_mock_discovery(service_uri: str = "http://test-cs") -> MagicMock:
    """Create a MagicMock discovery object with connector-service registered."""
    discovery = MagicMock()
    discovery.services = {"connector-service": MagicMock(uri=service_uri)}
    return discovery


# ---------------------------------------------------------------------------
# test_from_discovery_resolves_url_and_wires_token_provider
# ---------------------------------------------------------------------------

def test_from_discovery_resolves_url_and_wires_token_provider():
    """Client.from_discovery() sets base_url from discovery.services and workspace_id."""
    mock_discovery = _make_mock_discovery("http://test-cs")
    mock_tp = MagicMock(return_value="tok")

    with patch("h2o_discovery.discover", return_value=mock_discovery):
        client = Client.from_discovery("https://cloud.h2o.ai", "ws1", token_provider=mock_tp)

    assert client.base_url == "http://test-cs"
    assert client.workspace_id == "ws1"


# ---------------------------------------------------------------------------
# test_from_discovery_fallback_to_env_var
# ---------------------------------------------------------------------------

def test_from_discovery_fallback_to_env_var(monkeypatch):
    """When connector-service not in registry, falls back to H2O_CONNECTOR_SERVICE_URL."""
    mock_discovery = MagicMock()
    mock_discovery.services = {}
    mock_tp = MagicMock(return_value="tok")
    monkeypatch.setenv("H2O_CONNECTOR_SERVICE_URL", "http://fallback:8080")

    with patch("h2o_discovery.discover", return_value=mock_discovery):
        client = Client.from_discovery("https://cloud.h2o.ai", "ws1", token_provider=mock_tp)

    assert client.base_url == "http://fallback:8080"


# ---------------------------------------------------------------------------
# test_from_discovery_raises_if_no_url_and_no_env
# ---------------------------------------------------------------------------

def test_from_discovery_raises_if_no_url_and_no_env(monkeypatch):
    """When neither discovery nor env var available, raises LookupError."""
    mock_discovery = MagicMock()
    mock_discovery.services = {}
    mock_tp = MagicMock(return_value="tok")
    monkeypatch.delenv("H2O_CONNECTOR_SERVICE_URL", raising=False)

    with patch("h2o_discovery.discover", return_value=mock_discovery):
        with pytest.raises(LookupError, match="connector-service"):
            Client.from_discovery("https://cloud.h2o.ai", "ws1", token_provider=mock_tp)


# ---------------------------------------------------------------------------
# test_from_discovery_auto_creates_token_provider
# ---------------------------------------------------------------------------

def test_from_discovery_auto_creates_token_provider():
    """When token_provider=None, calls h2o_authn.discovery.create(discovery) to auto-create one."""
    mock_discovery = _make_mock_discovery("http://test-cs")
    mock_auto_tp = MagicMock(return_value="auto-tok")

    with patch("h2o_discovery.discover", return_value=mock_discovery):
        with patch("h2o_authn.discovery.create", return_value=mock_auto_tp):
            client = Client.from_discovery("https://cloud.h2o.ai", "ws1")

    assert client.base_url == "http://test-cs"


# ---------------------------------------------------------------------------
# test_from_discovery_token_provider_error_raises_lookup_error
# ---------------------------------------------------------------------------

def test_from_discovery_token_provider_error_raises_lookup_error():
    """When h2o_authn.discovery.create raises KeyError, from_discovery raises LookupError."""
    mock_discovery = _make_mock_discovery("http://test-cs")

    with patch("h2o_discovery.discover", return_value=mock_discovery):
        with patch("h2o_authn.discovery.create", side_effect=KeyError("platform")):
            with pytest.raises(LookupError, match="token provider"):
                Client.from_discovery("https://cloud.h2o.ai", "ws1")


# ---------------------------------------------------------------------------
# test_token_auth_injects_bearer_header
# ---------------------------------------------------------------------------

def test_token_auth_injects_bearer_header():
    """_TokenAuth sets Authorization header to 'Bearer {token}' on each request."""
    auth = _TokenAuth(lambda: "my-token")
    request = httpx.Request("GET", "http://test/")
    # auth_flow is a generator
    gen = auth.auth_flow(request)
    modified_request = next(gen)
    assert modified_request.headers["Authorization"] == "Bearer my-token"


# ---------------------------------------------------------------------------
# test_token_provider_called_per_request
# ---------------------------------------------------------------------------

def test_token_provider_called_per_request():
    """_TokenAuth calls token_provider() on each auth_flow invocation (not cached)."""
    mock_tp = MagicMock(return_value="tok")
    auth = _TokenAuth(mock_tp)

    request1 = httpx.Request("GET", "http://test/")
    request2 = httpx.Request("GET", "http://test/other")

    gen1 = auth.auth_flow(request1)
    next(gen1)

    gen2 = auth.auth_flow(request2)
    next(gen2)

    assert mock_tp.call_count == 2


# ---------------------------------------------------------------------------
# test_deprecation_warning_on_old_constructor
# ---------------------------------------------------------------------------

def test_deprecation_warning_on_old_constructor():
    """Client(base_url, token, workspace_id) emits DeprecationWarning mentioning from_discovery."""
    with pytest.warns(DeprecationWarning, match="from_discovery"):
        c = Client("http://localhost:8080", "tok", "ws1")
    c.close()


# ---------------------------------------------------------------------------
# test_connector_service_from_discovery
# ---------------------------------------------------------------------------

def test_connector_service_from_discovery():
    """ConnectorService.from_discovery() creates a working instance with correct base_url."""
    mock_discovery = _make_mock_discovery("http://test-cs")
    mock_tp = MagicMock(return_value="tok")

    with patch("h2o_discovery.discover", return_value=mock_discovery):
        instance = ConnectorService.from_discovery(
            "https://cloud.h2o.ai", "ws1", token_provider=mock_tp
        )

    try:
        assert instance._client.base_url == "http://test-cs"
    finally:
        instance.close()


# ---------------------------------------------------------------------------
# test_discovery_client_context_manager
# ---------------------------------------------------------------------------

def test_discovery_client_context_manager():
    """Discovery-created Client works as a context manager and closes cleanly."""
    mock_discovery = _make_mock_discovery("http://test-cs")
    mock_tp = MagicMock(return_value="tok")

    with patch("h2o_discovery.discover", return_value=mock_discovery):
        with Client.from_discovery("https://cloud.h2o.ai", "ws1", token_provider=mock_tp) as client:
            assert client.base_url == "http://test-cs"
    # After exiting, _http should be closed (calling close again is safe)
    assert client._http.is_closed


# ---------------------------------------------------------------------------
# test_from_discovery_fallback_on_network_failure
# ---------------------------------------------------------------------------

def test_from_discovery_fallback_on_network_failure(monkeypatch):
    """When discovery is unreachable, falls back to H2O_CONNECTOR_SERVICE_URL env var."""
    mock_tp = MagicMock(return_value="tok")
    monkeypatch.setenv("H2O_CONNECTOR_SERVICE_URL", "http://fallback:8080")

    with patch("h2o_discovery.discover", side_effect=ConnectionError("unreachable")):
        client = Client.from_discovery("https://cloud.h2o.ai", "ws1", token_provider=mock_tp)

    try:
        assert client.base_url == "http://fallback:8080"
    finally:
        client.close()


# ---------------------------------------------------------------------------
# test_from_discovery_network_failure_no_env_raises
# ---------------------------------------------------------------------------

def test_from_discovery_network_failure_no_env_raises(monkeypatch):
    """When discovery unreachable and no env var, raises LookupError."""
    mock_tp = MagicMock(return_value="tok")
    monkeypatch.delenv("H2O_CONNECTOR_SERVICE_URL", raising=False)

    with patch("h2o_discovery.discover", side_effect=ConnectionError("unreachable")):
        with pytest.raises(LookupError, match="Cannot resolve"):
            Client.from_discovery("https://cloud.h2o.ai", "ws1", token_provider=mock_tp)


# ---------------------------------------------------------------------------
# test_from_discovery_network_failure_no_token_provider_raises
# ---------------------------------------------------------------------------

def test_from_discovery_network_failure_no_token_provider_raises(monkeypatch):
    """When discovery unreachable with env var but no token_provider, raises LookupError."""
    monkeypatch.setenv("H2O_CONNECTOR_SERVICE_URL", "http://fallback:8080")

    with patch("h2o_discovery.discover", side_effect=ConnectionError("unreachable")):
        with pytest.raises(LookupError, match="token provider without discovery"):
            Client.from_discovery("https://cloud.h2o.ai", "ws1")
