"""Unit tests for ConnectorServiceError.error_reason parsing and __str__ formatting."""

import json
import pytest

from h2o_connector_service.exceptions import ConnectorServiceError


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _body(code: int, message: str) -> str:
    return json.dumps({"code": code, "message": message})


# ---------------------------------------------------------------------------
# error_reason tests — known auth error patterns
# ---------------------------------------------------------------------------

def test_error_reason_workspace_auth():
    """PermissionDenied with 'permission denied: user ... lacks ... on resource ...' -> WORKSPACE_AUTH."""
    body = _body(
        7,
        "permission denied: user 'alice@h2o.ai' lacks 'actions/connectorservice/connectors/GET' on resource '//workspaceserver/workspaces/ws-abc'",
    )
    e = ConnectorServiceError(403, body)
    assert e.error_reason == "WORKSPACE_AUTH"


def test_error_reason_missing_credentials_oidc():
    """Unauthenticated 'missing authentication credentials' -> MISSING_CREDENTIALS."""
    body = _body(16, "missing authentication credentials")
    e = ConnectorServiceError(401, body)
    assert e.error_reason == "MISSING_CREDENTIALS"


def test_error_reason_missing_credentials_no_user():
    """'authorization check failed: no authenticated user in request context' -> MISSING_CREDENTIALS."""
    body = _body(16, "authorization check failed: no authenticated user in request context")
    e = ConnectorServiceError(401, body)
    assert e.error_reason == "MISSING_CREDENTIALS"


def test_error_reason_invalid_token_bad_format():
    """'invalid authorization header format' -> INVALID_TOKEN."""
    body = _body(16, "invalid authorization header format")
    e = ConnectorServiceError(401, body)
    assert e.error_reason == "INVALID_TOKEN"


def test_error_reason_invalid_token_oidc():
    """'OIDC authentication failed: ...' -> INVALID_TOKEN."""
    body = _body(16, "OIDC authentication failed: token expired")
    e = ConnectorServiceError(401, body)
    assert e.error_reason == "INVALID_TOKEN"


def test_error_reason_auth_service_unavailable():
    """'authorization service unavailable: ...' -> AUTH_SERVICE_UNAVAILABLE."""
    body = _body(13, "authorization service unavailable: connection refused")
    e = ConnectorServiceError(500, body)
    assert e.error_reason == "AUTH_SERVICE_UNAVAILABLE"


def test_error_reason_missing_token():
    """'missing x-connection-token header: ...' -> MISSING_TOKEN."""
    body = _body(16, "missing x-connection-token header: no gRPC metadata in request")
    e = ConnectorServiceError(401, body)
    assert e.error_reason == "MISSING_TOKEN"


def test_error_reason_invalid_connection_token():
    """'invalid connection token' -> INVALID_TOKEN."""
    body = _body(16, "invalid connection token")
    e = ConnectorServiceError(401, body)
    assert e.error_reason == "INVALID_TOKEN"


def test_error_reason_token_revoked():
    """'connection token has been revoked' -> TOKEN_REVOKED."""
    body = _body(16, "connection token has been revoked")
    e = ConnectorServiceError(401, body)
    assert e.error_reason == "TOKEN_REVOKED"


def test_error_reason_unknown():
    """Unrecognised gRPC message -> UNKNOWN."""
    body = _body(5, "some unknown error")
    e = ConnectorServiceError(500, body)
    assert e.error_reason == "UNKNOWN"


def test_error_reason_non_json_body():
    """Non-JSON body -> UNKNOWN (no grpc_code available)."""
    e = ConnectorServiceError(500, "plain text error")
    assert e.error_reason == "UNKNOWN"


# ---------------------------------------------------------------------------
# __str__ formatting tests
# ---------------------------------------------------------------------------

def test_str_includes_reason():
    """str() with grpc_code present includes reason in format [HTTP x / gRPC y / REASON] msg."""
    body = _body(
        7,
        "permission denied: user 'alice@h2o.ai' lacks 'actions/connectorservice/connectors/GET' on resource '//workspaceserver/workspaces/ws-abc'",
    )
    e = ConnectorServiceError(403, body)
    assert str(e) == (
        "[HTTP 403 / gRPC 7 / WORKSPACE_AUTH] "
        "permission denied: user 'alice@h2o.ai' lacks 'actions/connectorservice/connectors/GET' "
        "on resource '//workspaceserver/workspaces/ws-abc'"
    )


def test_str_non_json_no_reason():
    """Non-JSON body: str() uses old format '[HTTP x] body' with no reason section."""
    e = ConnectorServiceError(500, "raw body text")
    assert str(e) == "[HTTP 500] raw body text"


def test_str_grpc_code_unknown_reason():
    """JSON body with grpc_code but unrecognised message: includes UNKNOWN in str()."""
    body = _body(5, "some unknown error")
    e = ConnectorServiceError(500, body)
    assert str(e) == "[HTTP 500 / gRPC 5 / UNKNOWN] some unknown error"
