"""Tests for ConnectionServiceClient and ConnectorServiceClient using httpx.MockTransport."""

import json
import pytest
import httpx
from h2o_connector_service._base import Client
from h2o_connector_service.exceptions import ConnectorServiceError
from h2o_connector_service.connection_client import ConnectionServiceClient
from h2o_connector_service.connector_client import ConnectorServiceClient


# ---------------------------------------------------------------------------
# Helper: build a Client instance with a mock transport (no live server)
# ---------------------------------------------------------------------------

def _make_client(handler):
    transport = httpx.MockTransport(handler)
    raw_http = httpx.Client(base_url="http://test", transport=transport)
    c = Client.__new__(Client)
    c.base_url = "http://test"
    c.token = "tok"
    c.workspace_id = "ws1"
    c._http = raw_http
    return c


# ---------------------------------------------------------------------------
# ConnectionServiceClient tests (TEST-01)
# ---------------------------------------------------------------------------

def test_create_connection_success():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/v1alpha/workspaces/ws1/connections"
        body = json.loads(request.content)
        assert "connection" in body
        return httpx.Response(200, json={"connection": {"connection_id": "conn-123", "status": "CONNECTION_STATUS_SUBMITTED"}})

    client = _make_client(handler)
    svc = ConnectionServiceClient(client)
    result = svc.create_connection("ws1", {})
    assert result["connection"]["connection_id"] == "conn-123"


def test_get_connection_success():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert request.url.path == "/v1alpha/workspaces/ws1/connections/conn-123"
        return httpx.Response(200, json={"connection_id": "conn-123", "status": "CONNECTION_STATUS_WORKER_READY"})

    client = _make_client(handler)
    svc = ConnectionServiceClient(client)
    result = svc.get_connection("ws1", "conn-123")
    assert result["status"] == "CONNECTION_STATUS_WORKER_READY"


def test_cancel_connection_success():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/v1alpha/workspaces/ws1/connections/conn-123:cancel"
        return httpx.Response(200, json={"connection_id": "conn-123"})

    client = _make_client(handler)
    svc = ConnectionServiceClient(client)
    result = svc.cancel_connection("ws1", "conn-123")
    assert result["connection_id"] == "conn-123"


def test_generate_connection_token_success():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/v1alpha/workspaces/ws1/connections/conn-123:generateToken"
        return httpx.Response(200, json={"auth_token": "tok-abc"})

    client = _make_client(handler)
    svc = ConnectionServiceClient(client)
    result = svc.generate_connection_token("ws1", "conn-123")
    assert result["auth_token"] == "tok-abc"


def test_connection_client_raises_on_error():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, text="Not found")

    client = _make_client(handler)
    svc = ConnectionServiceClient(client)
    with pytest.raises(ConnectorServiceError) as exc_info:
        svc.create_connection("ws1", {})
    exc = exc_info.value
    assert exc.status_code == 404
    assert "Not found" in exc.body


# ---------------------------------------------------------------------------
# ConnectorServiceClient tests (TEST-01)
# ---------------------------------------------------------------------------

def test_create_connector_success():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/v1alpha/workspaces/ws1/connectors"
        body = json.loads(request.content)
        assert "connector" in body
        return httpx.Response(200, json={"metadata": {"name": "workspaces/ws1/connectors/my-connector"}})

    client = _make_client(handler)
    svc = ConnectorServiceClient(client)
    result = svc.create_connector("ws1", {})
    assert result["metadata"]["name"] == "workspaces/ws1/connectors/my-connector"


def test_list_connectors_success():
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "GET"
        assert request.url.path == "/v1alpha/workspaces/ws1/connectors"
        return httpx.Response(200, json={"connectors": [{"metadata": {"name": "workspaces/ws1/connectors/c1"}}]})

    client = _make_client(handler)
    svc = ConnectorServiceClient(client)
    result = svc.list_connectors("ws1")
    assert len(result["connectors"]) == 1
