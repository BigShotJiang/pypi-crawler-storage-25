"""Tests for ConnectorSession using unittest.mock."""

import os
import tempfile
from unittest.mock import patch, call, MagicMock

import pytest
from h2o_connector_service._base import Client
from h2o_connector_service.connector_session import ConnectorSession, _iter_chunks


# ---------------------------------------------------------------------------
# Shared response fixtures
# ---------------------------------------------------------------------------

CONN_PENDING = {"connection_id": "conn-123", "status": "CONNECTION_STATUS_SUBMITTED"}
CONN_READY = {"connection_id": "conn-123", "status": "CONNECTION_STATUS_WORKER_READY"}
CONN_ACTIVE = {"connection_id": "conn-123", "status": "CONNECTION_STATUS_WORKER_ACTIVE"}
CONN_IDLE = {"connection_id": "conn-123", "status": "CONNECTION_STATUS_WORKER_IDLE"}
CONN_FAILED = {"connection_id": "conn-123", "status": "CONNECTION_STATUS_FAILED"}
CONN_CANCELLED = {"connection_id": "conn-123", "status": "CONNECTION_STATUS_CANCELLED"}
CONN_PRECONDITION = {"connection_id": "conn-123", "status": "CONNECTION_STATUS_PRECONDITION_FAILURE"}


# ---------------------------------------------------------------------------
# Helper: build a ConnectorSession without a real HTTP connection
# ---------------------------------------------------------------------------

def _make_session():
    client = Client.__new__(Client)
    client.base_url = "http://test"
    client.token = "tok"
    client.workspace_id = "ws1"
    client._http = None  # not used in these tests
    return ConnectorSession(client, workspace_id="ws1", connection_id="conn-123")


# ---------------------------------------------------------------------------
# Tests (TEST-02)
# ---------------------------------------------------------------------------

def test_wait_for_worker_ready_immediate_ready():
    """Worker is immediately ready — no sleep needed."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", return_value=CONN_READY) as mock_get, \
         patch("h2o_connector_service.connector_session.time.sleep") as sleep_mock:
        result = session.wait_for_worker_ready(timeout=10, interval=0.001)
    assert result == CONN_READY
    sleep_mock.assert_not_called()


def test_wait_for_worker_ready_polls_then_ready():
    """Worker returns PENDING twice then READY — expect 3 get_connection calls and 2 sleeps."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", side_effect=[CONN_PENDING, CONN_PENDING, CONN_READY]) as mock_get, \
         patch("h2o_connector_service.connector_session.time.sleep") as sleep_mock:
        result = session.wait_for_worker_ready(timeout=30, interval=0.001)
    assert result == CONN_READY
    assert mock_get.call_count == 3
    assert sleep_mock.call_count == 2


def test_wait_for_worker_ready_active_status():
    """WORKER_ACTIVE is a ready status."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", return_value=CONN_ACTIVE), \
         patch("h2o_connector_service.connector_session.time.sleep"):
        result = session.wait_for_worker_ready(timeout=10, interval=0.001)
    assert result["status"] == "CONNECTION_STATUS_WORKER_ACTIVE"


def test_wait_for_worker_ready_idle_status():
    """WORKER_IDLE is a ready status."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", return_value=CONN_IDLE), \
         patch("h2o_connector_service.connector_session.time.sleep"):
        result = session.wait_for_worker_ready(timeout=10, interval=0.001)
    assert result["status"] == "CONNECTION_STATUS_WORKER_IDLE"


def test_wait_for_worker_ready_raises_on_failed():
    """FAILED status must raise RuntimeError with 'terminal status' in message."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", return_value=CONN_FAILED), \
         patch("h2o_connector_service.connector_session.time.sleep"):
        with pytest.raises(RuntimeError, match="terminal status"):
            session.wait_for_worker_ready(timeout=10, interval=0.001)


def test_wait_for_worker_ready_raises_on_cancelled():
    """CANCELLED status must raise RuntimeError."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", return_value=CONN_CANCELLED), \
         patch("h2o_connector_service.connector_session.time.sleep"):
        with pytest.raises(RuntimeError):
            session.wait_for_worker_ready(timeout=10, interval=0.001)


def test_wait_for_worker_ready_raises_on_precondition_failure():
    """PRECONDITION_FAILURE status must raise RuntimeError."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", return_value=CONN_PRECONDITION), \
         patch("h2o_connector_service.connector_session.time.sleep"):
        with pytest.raises(RuntimeError):
            session.wait_for_worker_ready(timeout=10, interval=0.001)


def test_wait_for_worker_ready_timeout():
    """timeout=0.0 forces TimeoutError on the first deadline check after get_connection."""
    session = _make_session()
    with patch.object(session._conn_svc, "get_connection", return_value=CONN_PENDING), \
         patch("h2o_connector_service.connector_session.time.sleep"):
        with pytest.raises(TimeoutError, match="did not become ready"):
            session.wait_for_worker_ready(timeout=0.0, interval=0.001)


# ---------------------------------------------------------------------------
# Sample data for stream_to_* tests
# ---------------------------------------------------------------------------

SAMPLE_ROWS = [
    {"id": i, "name": f"row_{i}", "value": float(i) * 1.1}
    for i in range(25)
]


# ---------------------------------------------------------------------------
# Tests: _iter_chunks helper
# ---------------------------------------------------------------------------

class TestIterChunks:
    def test_exact_multiple(self):
        """10 items with chunk_size=5 → 2 chunks of 5."""
        chunks = list(_iter_chunks(iter(range(10)), 5))
        assert len(chunks) == 2
        assert chunks[0] == [0, 1, 2, 3, 4]
        assert chunks[1] == [5, 6, 7, 8, 9]

    def test_remainder(self):
        """7 items with chunk_size=3 → 2 full chunks + 1 remainder."""
        chunks = list(_iter_chunks(iter(range(7)), 3))
        assert len(chunks) == 3
        assert len(chunks[0]) == 3
        assert len(chunks[1]) == 3
        assert len(chunks[2]) == 1

    def test_empty(self):
        """Empty iterator → no chunks."""
        chunks = list(_iter_chunks(iter([]), 5))
        assert chunks == []

    def test_single_item(self):
        """1 item → 1 chunk of 1."""
        chunks = list(_iter_chunks(iter([42]), 10))
        assert chunks == [[42]]


# ---------------------------------------------------------------------------
# Tests: stream_to_parquet (memory-safe)
# ---------------------------------------------------------------------------

class TestStreamToParquet:
    @pytest.fixture(autouse=True)
    def require_pyarrow(self):
        pytest.importorskip("pyarrow")

    def test_writes_correct_row_count(self):
        """25 rows with chunk_size=10 → parquet file with 25 rows."""
        import pyarrow.parquet as pq

        session = _make_session()
        with patch.object(session, "stream_records", return_value=iter(SAMPLE_ROWS)):
            with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
                tmp_path = f.name
            try:
                count = session.stream_to_parquet(tmp_path, chunk_size=10)
                assert count == 25
                table = pq.read_table(tmp_path)
                assert table.num_rows == 25
                assert set(table.column_names) == {"id", "name", "value"}
            finally:
                os.unlink(tmp_path)

    def test_creates_multiple_row_groups(self):
        """25 rows with chunk_size=10 → 3 row groups (10+10+5)."""
        import pyarrow.parquet as pq

        session = _make_session()
        with patch.object(session, "stream_records", return_value=iter(SAMPLE_ROWS)):
            with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
                tmp_path = f.name
            try:
                session.stream_to_parquet(tmp_path, chunk_size=10)
                pf = pq.ParquetFile(tmp_path)
                assert pf.metadata.num_row_groups == 3
            finally:
                os.unlink(tmp_path)

    def test_empty_stream(self):
        """Empty stream → 0 rows, no crash."""
        session = _make_session()
        with patch.object(session, "stream_records", return_value=iter([])):
            with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
                tmp_path = f.name
            try:
                count = session.stream_to_parquet(tmp_path, chunk_size=10)
                assert count == 0
            finally:
                os.unlink(tmp_path)


# ---------------------------------------------------------------------------
# Tests: stream_to_pandas (renamed from stream_to_dataframe)
# ---------------------------------------------------------------------------

class TestStreamToPandas:
    @pytest.fixture(autouse=True)
    def require_pandas(self):
        pytest.importorskip("pandas")

    def test_returns_dataframe(self):
        """stream_to_pandas returns a pandas DataFrame with correct shape."""
        import pandas as pd

        session = _make_session()
        with patch.object(session, "stream_records", return_value=iter(SAMPLE_ROWS)):
            df = session.stream_to_pandas()
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 25
        assert list(df.columns) == ["id", "name", "value"]

    def test_method_name_exists(self):
        """Confirm stream_to_pandas exists and stream_to_dataframe does not."""
        session = _make_session()
        assert hasattr(session, "stream_to_pandas")
        assert not hasattr(session, "stream_to_dataframe")


# ---------------------------------------------------------------------------
# Tests: stream_to_data_table (memory-safe)
# ---------------------------------------------------------------------------

class TestStreamToDataTable:
    @pytest.fixture(autouse=True)
    def require_datatable(self):
        pytest.importorskip("datatable")

    def test_returns_frame_with_correct_shape(self):
        """25 rows → datatable.Frame with 25 rows and 3 columns."""
        import datatable as dt

        session = _make_session()
        with patch.object(session, "stream_records", return_value=iter(SAMPLE_ROWS)):
            frame = session.stream_to_data_table(chunk_size=10)
        assert isinstance(frame, dt.Frame)
        assert frame.nrows == 25
        assert frame.ncols == 3

    def test_empty_stream(self):
        """Empty stream → empty datatable.Frame."""
        import datatable as dt

        session = _make_session()
        with patch.object(session, "stream_records", return_value=iter([])):
            frame = session.stream_to_data_table(chunk_size=10)
        assert isinstance(frame, dt.Frame)
        assert frame.nrows == 0


# ---------------------------------------------------------------------------
# Tests: stream_to_h2o_frame (memory-safe, temp file approach)
# ---------------------------------------------------------------------------

class TestStreamToH2oFrame:
    def test_uses_parquet_path_when_pyarrow_available(self):
        """When pyarrow is available, writes temp parquet then calls h2o.import_file."""
        pytest.importorskip("pyarrow")
        session = _make_session()

        mock_h2o = MagicMock()
        mock_h2o.connection.return_value = True
        mock_h2o.import_file.return_value = MagicMock(name="H2OFrame")

        with patch.dict("sys.modules", {"h2o": mock_h2o}), \
             patch.object(session, "stream_to_parquet", return_value=25) as mock_parquet:
            result = session.stream_to_h2o_frame()

        mock_parquet.assert_called_once()
        mock_h2o.import_file.assert_called_once()
        # Verify temp file was cleaned up
        tmp_path = mock_h2o.import_file.call_args[0][0]
        assert not os.path.exists(tmp_path)

    def test_falls_back_to_csv_without_pyarrow(self):
        """When pyarrow is missing, falls back to CSV path."""
        session = _make_session()

        mock_h2o = MagicMock()
        mock_h2o.connection.return_value = True
        mock_h2o.import_file.return_value = MagicMock(name="H2OFrame")

        # Set pyarrow to None in sys.modules so the import inside the method fails
        with patch.dict("sys.modules", {"h2o": mock_h2o, "pyarrow": None}), \
             patch.object(session, "stream_to_csv", return_value=25) as mock_csv:
            result = session.stream_to_h2o_frame()

        mock_csv.assert_called_once()
        mock_h2o.import_file.assert_called_once()

    def test_raises_without_h2o_connection(self):
        """Raises RuntimeError if h2o.connection() is falsy."""
        session = _make_session()

        mock_h2o = MagicMock()
        mock_h2o.connection.return_value = None

        with patch.dict("sys.modules", {"h2o": mock_h2o}):
            with pytest.raises(RuntimeError, match="No H2O cluster connection"):
                session.stream_to_h2o_frame()

    def test_cleans_up_temp_file_on_error(self):
        """Temp file is removed even if stream_to_parquet raises."""
        pytest.importorskip("pyarrow")
        session = _make_session()

        mock_h2o = MagicMock()
        mock_h2o.connection.return_value = True

        with patch.dict("sys.modules", {"h2o": mock_h2o}), \
             patch.object(session, "stream_to_parquet", side_effect=RuntimeError("boom")):
            with pytest.raises(RuntimeError, match="boom"):
                session.stream_to_h2o_frame()
