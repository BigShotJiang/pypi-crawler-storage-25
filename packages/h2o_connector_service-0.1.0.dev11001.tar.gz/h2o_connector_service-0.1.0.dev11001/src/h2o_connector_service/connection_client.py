"""REST client for ConnectionService (control plane)."""

from __future__ import annotations

import time

from h2o_connector_service._base import Client
from h2o_connector_service.models import ConnectionStatus


class ConnectionServiceClient:
    """Wraps ConnectionService REST RPCs.

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
    """

    def __init__(self, client: Client) -> None:
        self._c = client

    # ------------------------------------------------------------------
    # CRUD RPCs
    # ------------------------------------------------------------------

    def create_connection(self, workspace_id: str, connection: dict) -> dict:
        """Create a new connection (POST /v1alpha/workspaces/{workspace_id}/connections)."""
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/connections",
            json={"connection": connection},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def get_connection(self, workspace_id: str, connection_id: str) -> dict:
        """Get a connection by ID (GET /v1alpha/workspaces/{workspace_id}/connections/{connection_id})."""
        resp = self._c._http.get(
            f"/v1alpha/workspaces/{workspace_id}/connections/{connection_id}",
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def list_connections(self, workspace_id: str, **params: object) -> dict:
        """List connections in a workspace (GET /v1alpha/workspaces/{workspace_id}/connections).

        Optional keyword params are forwarded as query parameters
        (e.g., ``page_size``, ``page_token``, ``filter``, ``order_by``).
        """
        resp = self._c._http.get(
            f"/v1alpha/workspaces/{workspace_id}/connections",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def cancel_connection(self, workspace_id: str, connection_id: str) -> dict:
        """Cancel a running connection (POST .../connections/{connection_id}:cancel)."""
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:cancel",
            json={},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def pause_connection(self, workspace_id: str, connection_id: str, reason: str = "") -> dict:
        """Pause a running connection (POST .../connections/{connection_id}:pause)."""
        body: dict = {}
        if reason:
            body["reason"] = reason
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:pause",
            json=body,
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def resume_connection(self, workspace_id: str, connection_id: str) -> dict:
        """Resume a paused connection (POST .../connections/{connection_id}:resume)."""
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:resume",
            json={},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def delete_connection(self, workspace_id: str, connection_id: str) -> None:
        """Delete a connection (DELETE /v1alpha/workspaces/{workspace_id}/connections/{connection_id})."""
        resp = self._c._http.delete(
            f"/v1alpha/workspaces/{workspace_id}/connections/{connection_id}",
        )
        self._c._raise_for_status(resp)

    def generate_connection_token(self, workspace_id: str, connection_id: str) -> dict:
        """Generate an auth token for a connection (POST .../connections/{connection_id}:generateToken).

        Returns a dict with ``auth_token`` key containing the bearer token
        for authenticating with the worker gRPC endpoint.
        """
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:generateToken",
            json={},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def revoke_connection_token(self, workspace_id: str, connection_id: str, auth_token: str) -> dict:
        """Revoke an auth token for a connection (POST .../connections/{connection_id}:revokeToken).

        The token is immediately invalidated; the connection itself remains active.
        Returns an empty dict on success (proto Empty / RevokeConnectionTokenResponse).
        """
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:revokeToken",
            json={"auth_token": auth_token},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    # ------------------------------------------------------------------
    # Typed status accessor
    # ------------------------------------------------------------------

    def get_connection_status(self, workspace_id: str, connection_id: str) -> ConnectionStatus:
        """Get a typed connection status snapshot.

        Wraps :meth:`get_connection` and returns a :class:`ConnectionStatus`
        dataclass with ``connection_id``, ``status``, and ``worker_endpoint`` fields.
        """
        raw = self.get_connection(workspace_id, connection_id)
        return ConnectionStatus.from_dict(raw)

    # ------------------------------------------------------------------
    # Polling helper (REST-07)
    # ------------------------------------------------------------------

    def poll_connection_status(
        self,
        workspace_id: str,
        connection_id: str,
        until_status: str | list[str],
        interval: float = 2.0,
        timeout: float = 300.0,
    ) -> dict:
        """Poll :meth:`get_connection` until the connection reaches a target status.

        Replaces ``WatchConnection`` (server-streaming SSE) which is not
        supported by the gRPC-Gateway configuration in this project.

        Args:
            workspace_id: Workspace that owns the connection.
            connection_id: UUID of the connection to watch.
            until_status: Target status string or list of status strings
                (e.g. ``"CONNECTION_STATUS_WORKER_READY"`` or
                ``["CONNECTION_STATUS_WORKER_READY", "CONNECTION_STATUS_WORKER_ACTIVE"]``).
            interval: Polling interval in seconds (default 2.0).
            timeout: Maximum total wait time in seconds (default 300.0).

        Returns:
            The connection dict when a target status is reached.

        Raises:
            TimeoutError: If the connection does not reach *until_status* within *timeout* seconds.
        """
        if isinstance(until_status, str):
            until_status = [until_status]
        deadline = time.monotonic() + timeout
        while True:
            conn = self.get_connection(workspace_id, connection_id)
            if conn.get("status") in until_status:
                return conn
            if time.monotonic() >= deadline:
                raise TimeoutError(f"Connection {connection_id!r} did not reach {until_status!r} within {timeout}s")
            time.sleep(interval)
