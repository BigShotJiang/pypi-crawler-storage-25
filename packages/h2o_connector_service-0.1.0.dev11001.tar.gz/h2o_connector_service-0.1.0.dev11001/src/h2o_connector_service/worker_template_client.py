"""REST client for WorkerTemplateService (control plane)."""

from __future__ import annotations

from h2o_connector_service._base import Client


class WorkerTemplateServiceClient:
    """Wraps WorkerTemplateService REST RPCs (globally-scoped templates).

    WorkerTemplates are platform-global resources that define reusable worker
    configurations. No workspace_id is required for list/get/delete operations.

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
    """

    def __init__(self, client: Client) -> None:
        self._c = client

    def create_worker_template(self, worker_template: dict) -> dict:
        """Create a worker template (POST /v1alpha/workerTemplates).

        Args:
            worker_template: WorkerTemplate dict (sent as ``{"worker_template": ...}`` body).
        """
        resp = self._c._http.post(
            "/v1alpha/workerTemplates",
            json={"worker_template": worker_template},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def get_worker_template(self, name: str) -> dict:
        """Get a worker template by resource name (GET /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workerTemplates/default-worker"``.
        """
        resp = self._c._http.get(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
        return resp.json()

    def list_worker_templates(self, **params: object) -> dict:
        """List all worker templates (GET /v1alpha/workerTemplates).

        Optional keyword params are forwarded as query parameters
        (e.g., ``page_size``, ``page_token``, ``filter``, ``workspace_id``).
        ``workspace_id`` filters to templates accessible by a specific workspace.
        """
        resp = self._c._http.get(
            "/v1alpha/workerTemplates",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def update_worker_template(self, worker_template: dict, update_mask: str | None = None) -> dict:
        """Update a worker template (PATCH /v1alpha/{worker_template.metadata.name}).

        Args:
            worker_template: Template dict with ``metadata.name`` set to the full resource name.
            update_mask: Comma-separated field mask.
        """
        name = worker_template["metadata"]["name"]
        params: dict = {}
        if update_mask:
            params["update_mask"] = update_mask
        resp = self._c._http.patch(
            f"/v1alpha/{name}",
            json={"worker_template": worker_template},
            params=params,
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def delete_worker_template(self, name: str) -> None:
        """Delete a worker template (DELETE /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workerTemplates/default-worker"``.
        """
        resp = self._c._http.delete(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
