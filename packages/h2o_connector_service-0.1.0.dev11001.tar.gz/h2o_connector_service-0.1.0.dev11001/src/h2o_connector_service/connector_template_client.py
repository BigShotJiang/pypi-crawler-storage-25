"""REST client for ConnectorTemplateService (control plane)."""

from __future__ import annotations

from h2o_connector_service._base import Client


class ConnectorTemplateServiceClient:
    """Wraps ConnectorTemplateService REST RPCs (globally-scoped templates).

    ConnectorTemplates are not workspace-scoped — they are platform-global resources
    accessible to all workspaces (subject to access control). No workspace_id is
    required for list/get/delete operations.

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
    """

    def __init__(self, client: Client) -> None:
        self._c = client

    def create_connector_template(self, connector_template: dict) -> dict:
        """Create a connector template (POST /v1alpha/connectorTemplates).

        Args:
            connector_template: ConnectorTemplate dict (sent as ``{"connector_template": ...}`` body).
        """
        resp = self._c._http.post(
            "/v1alpha/connectorTemplates",
            json={"connector_template": connector_template},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def get_connector_template(self, name: str) -> dict:
        """Get a connector template by resource name (GET /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"connectorTemplates/prod-postgresql"``.
        """
        resp = self._c._http.get(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
        return resp.json()

    def list_connector_templates(self, **params: object) -> dict:
        """List all connector templates (GET /v1alpha/connectorTemplates).

        Optional keyword params are forwarded as query parameters
        (e.g., ``page_size``, ``page_token``, ``filter``, ``workspace_id``).
        ``workspace_id`` filters to templates accessible by a specific workspace.
        """
        resp = self._c._http.get(
            "/v1alpha/connectorTemplates",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def update_connector_template(self, connector_template: dict, update_mask: str | None = None) -> dict:
        """Update a connector template (PATCH /v1alpha/{connector_template.metadata.name}).

        Args:
            connector_template: Template dict with ``metadata.name`` set to the full resource name.
            update_mask: Comma-separated field mask.
        """
        name = connector_template["metadata"]["name"]
        params: dict = {}
        if update_mask:
            params["update_mask"] = update_mask
        resp = self._c._http.patch(
            f"/v1alpha/{name}",
            json={"connector_template": connector_template},
            params=params,
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def delete_connector_template(self, name: str) -> None:
        """Delete a connector template (DELETE /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"connectorTemplates/prod-postgresql"``.
        """
        resp = self._c._http.delete(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
