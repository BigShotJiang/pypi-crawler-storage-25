"""Exceptions for the connector-service Python SDK."""

from __future__ import annotations

import json
import re

# ---------------------------------------------------------------------------
# Reason constants
# ---------------------------------------------------------------------------

REASON_WORKSPACE_AUTH = "WORKSPACE_AUTH"
REASON_MISSING_CREDENTIALS = "MISSING_CREDENTIALS"
REASON_INVALID_TOKEN = "INVALID_TOKEN"
REASON_TOKEN_REVOKED = "TOKEN_REVOKED"
REASON_MISSING_TOKEN = "MISSING_TOKEN"
REASON_AUTH_SERVICE_UNAVAILABLE = "AUTH_SERVICE_UNAVAILABLE"
REASON_UNKNOWN = "UNKNOWN"

# ---------------------------------------------------------------------------
# Pattern-based reason detection
# ---------------------------------------------------------------------------

_REASON_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"^permission denied: user '.+' lacks '.+' on resource '.+'$"), REASON_WORKSPACE_AUTH),
    (re.compile(r"^missing authentication credentials$"), REASON_MISSING_CREDENTIALS),
    (re.compile(r"^authorization check failed:"), REASON_MISSING_CREDENTIALS),
    (re.compile(r"^invalid authorization header format$"), REASON_INVALID_TOKEN),
    (re.compile(r"^OIDC authentication failed:"), REASON_INVALID_TOKEN),
    (re.compile(r"^authorization service unavailable:"), REASON_AUTH_SERVICE_UNAVAILABLE),
    (re.compile(r"^missing x-connection-token header:"), REASON_MISSING_TOKEN),
    (re.compile(r"^invalid connection token$"), REASON_INVALID_TOKEN),
    (re.compile(r"^connection token has been revoked$"), REASON_TOKEN_REVOKED),
]


def _parse_error_reason(message: str) -> str:
    """Match *message* against known server error patterns and return a reason code.

    Returns one of the ``REASON_*`` constants defined in this module.
    Returns :data:`REASON_UNKNOWN` when no pattern matches.
    """
    for pattern, reason in _REASON_PATTERNS:
        if pattern.search(message):
            return reason
    return REASON_UNKNOWN


# ---------------------------------------------------------------------------
# Exception class
# ---------------------------------------------------------------------------


class ConnectorServiceError(Exception):
    """Raised when the Connector Service API returns a non-2xx HTTP response.

    Attributes:
        status_code: HTTP status code from the response.
        body: Raw response body text.
        message: Parsed error message (from JSON body if available, else raw body).
        grpc_code: gRPC status code integer if the body contains a JSON-encoded
            gRPC status (e.g. from gRPC-Gateway error responses), else ``None``.
        error_reason: Structured reason code string parsed from the gRPC status
            message.  One of the ``REASON_*`` constants (e.g. ``"WORKSPACE_AUTH"``,
            ``"INVALID_TOKEN"``, ``"MISSING_CREDENTIALS"``, etc.).  Returns
            ``"UNKNOWN"`` when the message does not match any known pattern or
            when the body is not a gRPC-Gateway JSON error.
    """

    def __init__(self, status_code: int, body: str) -> None:
        self.status_code = status_code
        self.body = body
        try:
            data = json.loads(body)
            self.message = data.get("message", body)
            self.grpc_code = data.get("code")
        except (json.JSONDecodeError, AttributeError):
            self.message = body
            self.grpc_code = None
        self.error_reason: str = _parse_error_reason(self.message) if self.grpc_code is not None else REASON_UNKNOWN
        super().__init__(str(self))

    def __str__(self) -> str:
        if self.grpc_code is not None:
            return f"[HTTP {self.status_code} / gRPC {self.grpc_code} / {self.error_reason}] {self.message}"
        return f"[HTTP {self.status_code}] {self.message}"
