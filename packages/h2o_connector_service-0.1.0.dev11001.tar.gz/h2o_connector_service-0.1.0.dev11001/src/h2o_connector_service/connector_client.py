"""REST client for ConnectorService (control plane)."""

from __future__ import annotations

from h2o_connector_service._base import Client


class ConnectorServiceClient:
    """Wraps ConnectorService REST RPCs (workspace-scoped connectors).

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
    """

    def __init__(self, client: Client) -> None:
        self._c = client

    def create_connector(self, workspace_id: str, connector: dict) -> dict:
        """Create a new connector (POST /v1alpha/workspaces/{workspace_id}/connectors).

        Args:
            workspace_id: Workspace to create the connector in.
            connector: Connector resource dict (sent as ``{"connector": connector}`` body).
        """
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/connectors",
            json={"connector": connector},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def get_connector(self, name: str) -> dict:
        """Get a connector by resource name (GET /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workspaces/my-ws/connectors/my-connector"``.
        """
        resp = self._c._http.get(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
        return resp.json()

    def list_connectors(self, workspace_id: str, **params: object) -> dict:
        """List connectors in a workspace (GET /v1alpha/workspaces/{workspace_id}/connectors).

        Optional keyword params are forwarded as query parameters
        (e.g., ``page_size``, ``page_token``, ``filter``, ``order_by``).
        """
        resp = self._c._http.get(
            f"/v1alpha/workspaces/{workspace_id}/connectors",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def update_connector(self, connector: dict, update_mask: str | None = None) -> dict:
        """Update a connector (PATCH /v1alpha/{connector.metadata.name}).

        Args:
            connector: Connector dict with ``metadata.name`` set to the full resource name.
            update_mask: Comma-separated field mask (e.g. ``"enabled,flow_control"``).
        """
        name = connector["metadata"]["name"]
        params: dict = {}
        if update_mask:
            params["update_mask"] = update_mask
        resp = self._c._http.patch(
            f"/v1alpha/{name}",
            json={"connector": connector},
            params=params,
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def delete_connector(self, name: str) -> None:
        """Delete a connector (DELETE /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workspaces/my-ws/connectors/my-connector"``.
        """
        resp = self._c._http.delete(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
