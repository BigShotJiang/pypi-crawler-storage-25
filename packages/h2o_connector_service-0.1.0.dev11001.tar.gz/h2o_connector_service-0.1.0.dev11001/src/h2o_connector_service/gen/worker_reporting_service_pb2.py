"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'worker_reporting_service.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from . import connection_service_pb2 as connection__service__pb2
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1eworker_reporting_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\x18connection_service.proto\x1a\x1cgoogle/api/annotations.proto\x1a\x1fgoogle/api/field_behavior.proto"\xeb\x01\n\x1eReportConnectionFailureRequest\x12(\n\rconnection_id\x18\x01 \x01(\tB\x03\xe0A\x02R\x0cconnectionId\x12(\n\rerror_message\x18\x02 \x01(\tB\x03\xe0A\x02R\x0cerrorMessage\x12R\n\nerror_code\x18\x03 \x01(\x0e2..ai.h2o.connectors.v1alpha.ConnectionErrorCodeB\x03\xe0A\x02R\terrorCode\x12!\n\tretryable\x18\x04 \x01(\x08B\x03\xe0A\x01R\tretryable"!\n\x1fReportConnectionFailureResponse"A\n\x15GetCredentialsRequest\x12(\n\rconnection_id\x18\x01 \x01(\tB\x03\xe0A\x02R\x0cconnectionId"a\n\x16GetCredentialsResponse\x12G\n\x0bcredentials\x18\x01 \x03(\x0b2%.ai.h2o.connectors.v1alpha.CredentialR\x0bcredentials"_\n\nCredential\x12\x17\n\x04name\x18\x01 \x01(\tB\x03\xe0A\x02R\x04name\x12\x19\n\x05value\x18\x02 \x01(\tB\x03\xe0A\x02R\x05value\x12\x1d\n\x07version\x18\x03 \x01(\tB\x03\xe0A\x01R\x07version2\xf0\x03\n\x16WorkerReportingService\x12\x90\x01\n\x17ReportConnectionFailure\x129.ai.h2o.connectors.v1alpha.ReportConnectionFailureRequest\x1a:.ai.h2o.connectors.v1alpha.ReportConnectionFailureResponse\x12\x90\x01\n\x17ValidateConnectionToken\x129.ai.h2o.connectors.v1alpha.ValidateConnectionTokenRequest\x1a:.ai.h2o.connectors.v1alpha.ValidateConnectionTokenResponse\x12\xaf\x01\n\x0eGetCredentials\x120.ai.h2o.connectors.v1alpha.GetCredentialsRequest\x1a1.ai.h2o.connectors.v1alpha.GetCredentialsResponse"8\x82\xd3\xe4\x93\x022\x120/v1alpha/connections/{connection_id}/credentialsB\x91\x01\n\x19ai.h2o.connectors.v1alphaB\x1bWorkerReportingServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'worker_reporting_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x1bWorkerReportingServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02'
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['error_message']._loaded_options = None
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['error_message']._serialized_options = b'\xe0A\x02'
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['error_code']._loaded_options = None
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['error_code']._serialized_options = b'\xe0A\x02'
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['retryable']._loaded_options = None
    _globals['_REPORTCONNECTIONFAILUREREQUEST'].fields_by_name['retryable']._serialized_options = b'\xe0A\x01'
    _globals['_GETCREDENTIALSREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_GETCREDENTIALSREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02'
    _globals['_CREDENTIAL'].fields_by_name['name']._loaded_options = None
    _globals['_CREDENTIAL'].fields_by_name['name']._serialized_options = b'\xe0A\x02'
    _globals['_CREDENTIAL'].fields_by_name['value']._loaded_options = None
    _globals['_CREDENTIAL'].fields_by_name['value']._serialized_options = b'\xe0A\x02'
    _globals['_CREDENTIAL'].fields_by_name['version']._loaded_options = None
    _globals['_CREDENTIAL'].fields_by_name['version']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERREPORTINGSERVICE'].methods_by_name['GetCredentials']._loaded_options = None
    _globals['_WORKERREPORTINGSERVICE'].methods_by_name['GetCredentials']._serialized_options = b'\x82\xd3\xe4\x93\x022\x120/v1alpha/connections/{connection_id}/credentials'
    _globals['_REPORTCONNECTIONFAILUREREQUEST']._serialized_start = 165
    _globals['_REPORTCONNECTIONFAILUREREQUEST']._serialized_end = 400
    _globals['_REPORTCONNECTIONFAILURERESPONSE']._serialized_start = 402
    _globals['_REPORTCONNECTIONFAILURERESPONSE']._serialized_end = 435
    _globals['_GETCREDENTIALSREQUEST']._serialized_start = 437
    _globals['_GETCREDENTIALSREQUEST']._serialized_end = 502
    _globals['_GETCREDENTIALSRESPONSE']._serialized_start = 504
    _globals['_GETCREDENTIALSRESPONSE']._serialized_end = 601
    _globals['_CREDENTIAL']._serialized_start = 603
    _globals['_CREDENTIAL']._serialized_end = 698
    _globals['_WORKERREPORTINGSERVICE']._serialized_start = 701
    _globals['_WORKERREPORTINGSERVICE']._serialized_end = 1197