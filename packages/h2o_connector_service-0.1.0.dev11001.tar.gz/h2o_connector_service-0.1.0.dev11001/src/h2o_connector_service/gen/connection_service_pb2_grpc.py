"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import connection_pb2 as connection__pb2
from . import connection_service_pb2 as connection__service__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2

class ConnectionServiceStub(object):
    """=============================================================================
    Connection Service
    =============================================================================

    ConnectionService manages data extraction connections.
    Connections are identified by auto-generated UUIDs (connection_id) to support multi-tenant environments.
    All REST paths are workspace-scoped: /v1alpha/workspaces/{workspace_id}/connections/...
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CreateConnection = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/CreateConnection', request_serializer=connection__service__pb2.CreateConnectionRequest.SerializeToString, response_deserializer=connection__pb2.Connection.FromString, _registered_method=True)
        self.GetConnection = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/GetConnection', request_serializer=connection__service__pb2.GetConnectionRequest.SerializeToString, response_deserializer=connection__pb2.Connection.FromString, _registered_method=True)
        self.ListConnections = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/ListConnections', request_serializer=connection__service__pb2.ListConnectionsRequest.SerializeToString, response_deserializer=connection__service__pb2.ListConnectionsResponse.FromString, _registered_method=True)
        self.CancelConnection = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/CancelConnection', request_serializer=connection__service__pb2.CancelConnectionRequest.SerializeToString, response_deserializer=connection__pb2.Connection.FromString, _registered_method=True)
        self.PauseConnection = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/PauseConnection', request_serializer=connection__service__pb2.PauseConnectionRequest.SerializeToString, response_deserializer=connection__pb2.Connection.FromString, _registered_method=True)
        self.ResumeConnection = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/ResumeConnection', request_serializer=connection__service__pb2.ResumeConnectionRequest.SerializeToString, response_deserializer=connection__pb2.Connection.FromString, _registered_method=True)
        self.UpdateConnection = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/UpdateConnection', request_serializer=connection__service__pb2.UpdateConnectionRequest.SerializeToString, response_deserializer=connection__pb2.Connection.FromString, _registered_method=True)
        self.DeleteConnection = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/DeleteConnection', request_serializer=connection__service__pb2.DeleteConnectionRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString, _registered_method=True)
        self.WatchConnection = channel.unary_stream('/ai.h2o.connectors.v1alpha.ConnectionService/WatchConnection', request_serializer=connection__service__pb2.WatchConnectionRequest.SerializeToString, response_deserializer=connection__service__pb2.WatchConnectionResponse.FromString, _registered_method=True)
        self.GenerateConnectionToken = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/GenerateConnectionToken', request_serializer=connection__service__pb2.GenerateConnectionTokenRequest.SerializeToString, response_deserializer=connection__service__pb2.GenerateConnectionTokenResponse.FromString, _registered_method=True)
        self.RevokeConnectionToken = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/RevokeConnectionToken', request_serializer=connection__service__pb2.RevokeConnectionTokenRequest.SerializeToString, response_deserializer=connection__service__pb2.RevokeConnectionTokenResponse.FromString, _registered_method=True)
        self.ValidateConnectionToken = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectionService/ValidateConnectionToken', request_serializer=connection__service__pb2.ValidateConnectionTokenRequest.SerializeToString, response_deserializer=connection__service__pb2.ValidateConnectionTokenResponse.FromString, _registered_method=True)

class ConnectionServiceServicer(object):
    """=============================================================================
    Connection Service
    =============================================================================

    ConnectionService manages data extraction connections.
    Connections are identified by auto-generated UUIDs (connection_id) to support multi-tenant environments.
    All REST paths are workspace-scoped: /v1alpha/workspaces/{workspace_id}/connections/...
    """

    def CreateConnection(self, request, context):
        """Creates and starts a new connection.
        Returns the created connection with auto-generated connection_id.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetConnection(self, request, context):
        """Gets a connection by its UUID.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListConnections(self, request, context):
        """Lists connections within a workspace.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def CancelConnection(self, request, context):
        """Cancels a running connection.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def PauseConnection(self, request, context):
        """Pauses a running connection.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ResumeConnection(self, request, context):
        """Resumes a paused connection.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def UpdateConnection(self, request, context):
        """Updates a connection (internal use by workload manager).
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteConnection(self, request, context):
        """Deletes a connection.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def WatchConnection(self, request, context):
        """Watches connection status changes (server streaming).
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GenerateConnectionToken(self, request, context):
        """Generates a new auth token for a running connection.
        The caller can use the returned token to authenticate with the worker.
        Previously issued tokens remain valid; all tokens are invalidated when
        the connection reaches a terminal state.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def RevokeConnectionToken(self, request, context):
        """Revokes a previously issued connection token.
        The token is immediately invalidated; the connection itself remains active.
        Callers should generate a new token if continued access is needed.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ValidateConnectionToken(self, request, context):
        """Validates whether a connection token (JWT) is still valid.
        Returns OK if valid; UNAUTHENTICATED if revoked or unknown.
        Internal: used by workload-manager to relay worker token validation.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_ConnectionServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'CreateConnection': grpc.unary_unary_rpc_method_handler(servicer.CreateConnection, request_deserializer=connection__service__pb2.CreateConnectionRequest.FromString, response_serializer=connection__pb2.Connection.SerializeToString), 'GetConnection': grpc.unary_unary_rpc_method_handler(servicer.GetConnection, request_deserializer=connection__service__pb2.GetConnectionRequest.FromString, response_serializer=connection__pb2.Connection.SerializeToString), 'ListConnections': grpc.unary_unary_rpc_method_handler(servicer.ListConnections, request_deserializer=connection__service__pb2.ListConnectionsRequest.FromString, response_serializer=connection__service__pb2.ListConnectionsResponse.SerializeToString), 'CancelConnection': grpc.unary_unary_rpc_method_handler(servicer.CancelConnection, request_deserializer=connection__service__pb2.CancelConnectionRequest.FromString, response_serializer=connection__pb2.Connection.SerializeToString), 'PauseConnection': grpc.unary_unary_rpc_method_handler(servicer.PauseConnection, request_deserializer=connection__service__pb2.PauseConnectionRequest.FromString, response_serializer=connection__pb2.Connection.SerializeToString), 'ResumeConnection': grpc.unary_unary_rpc_method_handler(servicer.ResumeConnection, request_deserializer=connection__service__pb2.ResumeConnectionRequest.FromString, response_serializer=connection__pb2.Connection.SerializeToString), 'UpdateConnection': grpc.unary_unary_rpc_method_handler(servicer.UpdateConnection, request_deserializer=connection__service__pb2.UpdateConnectionRequest.FromString, response_serializer=connection__pb2.Connection.SerializeToString), 'DeleteConnection': grpc.unary_unary_rpc_method_handler(servicer.DeleteConnection, request_deserializer=connection__service__pb2.DeleteConnectionRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString), 'WatchConnection': grpc.unary_stream_rpc_method_handler(servicer.WatchConnection, request_deserializer=connection__service__pb2.WatchConnectionRequest.FromString, response_serializer=connection__service__pb2.WatchConnectionResponse.SerializeToString), 'GenerateConnectionToken': grpc.unary_unary_rpc_method_handler(servicer.GenerateConnectionToken, request_deserializer=connection__service__pb2.GenerateConnectionTokenRequest.FromString, response_serializer=connection__service__pb2.GenerateConnectionTokenResponse.SerializeToString), 'RevokeConnectionToken': grpc.unary_unary_rpc_method_handler(servicer.RevokeConnectionToken, request_deserializer=connection__service__pb2.RevokeConnectionTokenRequest.FromString, response_serializer=connection__service__pb2.RevokeConnectionTokenResponse.SerializeToString), 'ValidateConnectionToken': grpc.unary_unary_rpc_method_handler(servicer.ValidateConnectionToken, request_deserializer=connection__service__pb2.ValidateConnectionTokenRequest.FromString, response_serializer=connection__service__pb2.ValidateConnectionTokenResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.ConnectionService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.ConnectionService', rpc_method_handlers)

class ConnectionService(object):
    """=============================================================================
    Connection Service
    =============================================================================

    ConnectionService manages data extraction connections.
    Connections are identified by auto-generated UUIDs (connection_id) to support multi-tenant environments.
    All REST paths are workspace-scoped: /v1alpha/workspaces/{workspace_id}/connections/...
    """

    @staticmethod
    def CreateConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/CreateConnection', connection__service__pb2.CreateConnectionRequest.SerializeToString, connection__pb2.Connection.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/GetConnection', connection__service__pb2.GetConnectionRequest.SerializeToString, connection__pb2.Connection.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ListConnections(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/ListConnections', connection__service__pb2.ListConnectionsRequest.SerializeToString, connection__service__pb2.ListConnectionsResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def CancelConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/CancelConnection', connection__service__pb2.CancelConnectionRequest.SerializeToString, connection__pb2.Connection.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def PauseConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/PauseConnection', connection__service__pb2.PauseConnectionRequest.SerializeToString, connection__pb2.Connection.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ResumeConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/ResumeConnection', connection__service__pb2.ResumeConnectionRequest.SerializeToString, connection__pb2.Connection.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def UpdateConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/UpdateConnection', connection__service__pb2.UpdateConnectionRequest.SerializeToString, connection__pb2.Connection.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def DeleteConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/DeleteConnection', connection__service__pb2.DeleteConnectionRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def WatchConnection(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_stream(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/WatchConnection', connection__service__pb2.WatchConnectionRequest.SerializeToString, connection__service__pb2.WatchConnectionResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GenerateConnectionToken(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/GenerateConnectionToken', connection__service__pb2.GenerateConnectionTokenRequest.SerializeToString, connection__service__pb2.GenerateConnectionTokenResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def RevokeConnectionToken(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/RevokeConnectionToken', connection__service__pb2.RevokeConnectionTokenRequest.SerializeToString, connection__service__pb2.RevokeConnectionTokenResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ValidateConnectionToken(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectionService/ValidateConnectionToken', connection__service__pb2.ValidateConnectionTokenRequest.SerializeToString, connection__service__pb2.ValidateConnectionTokenResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)