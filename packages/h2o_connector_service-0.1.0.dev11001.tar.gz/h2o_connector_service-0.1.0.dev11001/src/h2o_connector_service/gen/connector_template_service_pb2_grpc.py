"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import connector_template_pb2 as connector__template__pb2
from . import connector_template_service_pb2 as connector__template__service__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2

class ConnectorTemplateServiceStub(object):
    """=============================================================================
    Connector Template Service
    =============================================================================

    ConnectorTemplateService manages global connector templates.
    Templates define reusable connector configurations with workspace access controls.
    Platform administrators can create and manage templates.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CreateConnectorTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorTemplateService/CreateConnectorTemplate', request_serializer=connector__template__service__pb2.CreateConnectorTemplateRequest.SerializeToString, response_deserializer=connector__template__pb2.ConnectorTemplate.FromString, _registered_method=True)
        self.GetConnectorTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorTemplateService/GetConnectorTemplate', request_serializer=connector__template__service__pb2.GetConnectorTemplateRequest.SerializeToString, response_deserializer=connector__template__pb2.ConnectorTemplate.FromString, _registered_method=True)
        self.ListConnectorTemplates = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorTemplateService/ListConnectorTemplates', request_serializer=connector__template__service__pb2.ListConnectorTemplatesRequest.SerializeToString, response_deserializer=connector__template__service__pb2.ListConnectorTemplatesResponse.FromString, _registered_method=True)
        self.UpdateConnectorTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorTemplateService/UpdateConnectorTemplate', request_serializer=connector__template__service__pb2.UpdateConnectorTemplateRequest.SerializeToString, response_deserializer=connector__template__pb2.ConnectorTemplate.FromString, _registered_method=True)
        self.DeleteConnectorTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorTemplateService/DeleteConnectorTemplate', request_serializer=connector__template__service__pb2.DeleteConnectorTemplateRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString, _registered_method=True)

class ConnectorTemplateServiceServicer(object):
    """=============================================================================
    Connector Template Service
    =============================================================================

    ConnectorTemplateService manages global connector templates.
    Templates define reusable connector configurations with workspace access controls.
    Platform administrators can create and manage templates.
    """

    def CreateConnectorTemplate(self, request, context):
        """Creates a new connector template.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetConnectorTemplate(self, request, context):
        """Gets a connector template by name.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListConnectorTemplates(self, request, context):
        """Lists connector templates.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def UpdateConnectorTemplate(self, request, context):
        """Updates a connector template.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteConnectorTemplate(self, request, context):
        """Deletes a connector template.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_ConnectorTemplateServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'CreateConnectorTemplate': grpc.unary_unary_rpc_method_handler(servicer.CreateConnectorTemplate, request_deserializer=connector__template__service__pb2.CreateConnectorTemplateRequest.FromString, response_serializer=connector__template__pb2.ConnectorTemplate.SerializeToString), 'GetConnectorTemplate': grpc.unary_unary_rpc_method_handler(servicer.GetConnectorTemplate, request_deserializer=connector__template__service__pb2.GetConnectorTemplateRequest.FromString, response_serializer=connector__template__pb2.ConnectorTemplate.SerializeToString), 'ListConnectorTemplates': grpc.unary_unary_rpc_method_handler(servicer.ListConnectorTemplates, request_deserializer=connector__template__service__pb2.ListConnectorTemplatesRequest.FromString, response_serializer=connector__template__service__pb2.ListConnectorTemplatesResponse.SerializeToString), 'UpdateConnectorTemplate': grpc.unary_unary_rpc_method_handler(servicer.UpdateConnectorTemplate, request_deserializer=connector__template__service__pb2.UpdateConnectorTemplateRequest.FromString, response_serializer=connector__template__pb2.ConnectorTemplate.SerializeToString), 'DeleteConnectorTemplate': grpc.unary_unary_rpc_method_handler(servicer.DeleteConnectorTemplate, request_deserializer=connector__template__service__pb2.DeleteConnectorTemplateRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.ConnectorTemplateService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.ConnectorTemplateService', rpc_method_handlers)

class ConnectorTemplateService(object):
    """=============================================================================
    Connector Template Service
    =============================================================================

    ConnectorTemplateService manages global connector templates.
    Templates define reusable connector configurations with workspace access controls.
    Platform administrators can create and manage templates.
    """

    @staticmethod
    def CreateConnectorTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorTemplateService/CreateConnectorTemplate', connector__template__service__pb2.CreateConnectorTemplateRequest.SerializeToString, connector__template__pb2.ConnectorTemplate.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetConnectorTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorTemplateService/GetConnectorTemplate', connector__template__service__pb2.GetConnectorTemplateRequest.SerializeToString, connector__template__pb2.ConnectorTemplate.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ListConnectorTemplates(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorTemplateService/ListConnectorTemplates', connector__template__service__pb2.ListConnectorTemplatesRequest.SerializeToString, connector__template__service__pb2.ListConnectorTemplatesResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def UpdateConnectorTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorTemplateService/UpdateConnectorTemplate', connector__template__service__pb2.UpdateConnectorTemplateRequest.SerializeToString, connector__template__pb2.ConnectorTemplate.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def DeleteConnectorTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorTemplateService/DeleteConnectorTemplate', connector__template__service__pb2.DeleteConnectorTemplateRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)