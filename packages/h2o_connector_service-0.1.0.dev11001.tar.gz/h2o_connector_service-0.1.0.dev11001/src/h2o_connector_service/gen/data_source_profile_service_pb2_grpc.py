"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import data_source_profile_service_pb2 as data__source__profile__service__pb2

class DataSourceProfileServiceStub(object):
    """=============================================================================
    DataSourceProfile Service
    =============================================================================

    DataSourceProfileService exposes config schema discovery.
    Clients call this service to learn which data_source_type values exist and
    which configuration parameters each requires, without needing to create a
    ConnectorTemplate first.

    This is a global, read-only service — no workspace scoping is required.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.ListDataSourceProfiles = channel.unary_unary('/ai.h2o.connectors.v1alpha.DataSourceProfileService/ListDataSourceProfiles', request_serializer=data__source__profile__service__pb2.ListDataSourceProfilesRequest.SerializeToString, response_deserializer=data__source__profile__service__pb2.ListDataSourceProfilesResponse.FromString, _registered_method=True)

class DataSourceProfileServiceServicer(object):
    """=============================================================================
    DataSourceProfile Service
    =============================================================================

    DataSourceProfileService exposes config schema discovery.
    Clients call this service to learn which data_source_type values exist and
    which configuration parameters each requires, without needing to create a
    ConnectorTemplate first.

    This is a global, read-only service — no workspace scoping is required.
    """

    def ListDataSourceProfiles(self, request, context):
        """Lists all registered data source profiles.
        Optionally filters by category or data_source_type.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_DataSourceProfileServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'ListDataSourceProfiles': grpc.unary_unary_rpc_method_handler(servicer.ListDataSourceProfiles, request_deserializer=data__source__profile__service__pb2.ListDataSourceProfilesRequest.FromString, response_serializer=data__source__profile__service__pb2.ListDataSourceProfilesResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.DataSourceProfileService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.DataSourceProfileService', rpc_method_handlers)

class DataSourceProfileService(object):
    """=============================================================================
    DataSourceProfile Service
    =============================================================================

    DataSourceProfileService exposes config schema discovery.
    Clients call this service to learn which data_source_type values exist and
    which configuration parameters each requires, without needing to create a
    ConnectorTemplate first.

    This is a global, read-only service — no workspace scoping is required.
    """

    @staticmethod
    def ListDataSourceProfiles(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.DataSourceProfileService/ListDataSourceProfiles', data__source__profile__service__pb2.ListDataSourceProfilesRequest.SerializeToString, data__source__profile__service__pb2.ListDataSourceProfilesResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)