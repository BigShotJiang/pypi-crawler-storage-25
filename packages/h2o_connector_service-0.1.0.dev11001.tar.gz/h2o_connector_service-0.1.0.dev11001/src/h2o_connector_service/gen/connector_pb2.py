"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'connector.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import duration_pb2 as google_dot_protobuf_dot_duration__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0fconnector.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1egoogle/protobuf/duration.proto"\x9d\x07\n\tConnector\x12L\n\x08metadata\x18\x01 \x01(\x0b2+.ai.h2o.connectors.v1alpha.ResourceMetadataB\x03\xe0A\x02R\x08metadata\x12Z\n\x12connector_template\x18\x02 \x01(\tB+\xe0A\x01\xfaA%\n#connectors.h2o.ai/ConnectorTemplateR\x11connectorTemplate\x12-\n\x10data_source_type\x18\x03 \x01(\tB\x03\xe0A\x01R\x0edataSourceType\x12N\n\x08category\x18\x04 \x01(\x0e2-.ai.h2o.connectors.v1alpha.DataSourceCategoryB\x03\xe0A\x01R\x08category\x12R\n\x0bcredentials\x18\x05 \x01(\x0b2+.ai.h2o.connectors.v1alpha.CredentialConfigB\x03\xe0A\x01R\x0bcredentials\x12m\n\x12data_source_config\x18\x06 \x03(\x0b2:.ai.h2o.connectors.v1alpha.Connector.DataSourceConfigEntryB\x03\xe0A\x01R\x10dataSourceConfig\x12T\n\x0cflow_control\x18\x07 \x01(\x0b2,.ai.h2o.connectors.v1alpha.FlowControlConfigB\x03\xe0A\x01R\x0bflowControl\x12&\n\x0cworkspace_id\x18\x08 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12\x1d\n\x07enabled\x18\t \x01(\x08B\x03\xe0A\x01R\x07enabled\x122\n\x12overridable_fields\x18\n \x03(\tB\x03\xe0A\x01R\x11overridableFields\x12=\n\x18required_override_fields\x18\x0b \x03(\tB\x03\xe0A\x01R\x16requiredOverrideFields\x1aC\n\x15DataSourceConfigEntry\x12\x10\n\x03key\x18\x01 \x01(\tR\x03key\x12\x14\n\x05value\x18\x02 \x01(\tR\x05value:\x028\x01:O\xeaAL\n\x1bconnectors.h2o.ai/Connector\x12\x16connectors/{connector}*\nconnectors2\tconnector"\x9c\x01\n\x11FlowControlConfig\x12$\n\x0bwindow_size\x18\x01 \x01(\x05B\x03\xe0A\x01R\nwindowSize\x12?\n\x0back_timeout\x18\x02 \x01(\x0b2\x19.google.protobuf.DurationB\x03\xe0A\x01R\nackTimeout\x12 \n\tmax_units\x18\x03 \x01(\x03B\x03\xe0A\x01R\x08maxUnitsB\x84\x01\n\x19ai.h2o.connectors.v1alphaB\x0eConnectorProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'connector_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x0eConnectorProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CONNECTOR_DATASOURCECONFIGENTRY']._loaded_options = None
    _globals['_CONNECTOR_DATASOURCECONFIGENTRY']._serialized_options = b'8\x01'
    _globals['_CONNECTOR'].fields_by_name['metadata']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['metadata']._serialized_options = b'\xe0A\x02'
    _globals['_CONNECTOR'].fields_by_name['connector_template']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['connector_template']._serialized_options = b'\xe0A\x01\xfaA%\n#connectors.h2o.ai/ConnectorTemplate'
    _globals['_CONNECTOR'].fields_by_name['data_source_type']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['data_source_type']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR'].fields_by_name['category']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['category']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR'].fields_by_name['credentials']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['credentials']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR'].fields_by_name['data_source_config']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['data_source_config']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR'].fields_by_name['flow_control']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['flow_control']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_CONNECTOR'].fields_by_name['enabled']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['enabled']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR'].fields_by_name['overridable_fields']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['overridable_fields']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR'].fields_by_name['required_override_fields']._loaded_options = None
    _globals['_CONNECTOR'].fields_by_name['required_override_fields']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR']._loaded_options = None
    _globals['_CONNECTOR']._serialized_options = b'\xeaAL\n\x1bconnectors.h2o.ai/Connector\x12\x16connectors/{connector}*\nconnectors2\tconnector'
    _globals['_FLOWCONTROLCONFIG'].fields_by_name['window_size']._loaded_options = None
    _globals['_FLOWCONTROLCONFIG'].fields_by_name['window_size']._serialized_options = b'\xe0A\x01'
    _globals['_FLOWCONTROLCONFIG'].fields_by_name['ack_timeout']._loaded_options = None
    _globals['_FLOWCONTROLCONFIG'].fields_by_name['ack_timeout']._serialized_options = b'\xe0A\x01'
    _globals['_FLOWCONTROLCONFIG'].fields_by_name['max_units']._loaded_options = None
    _globals['_FLOWCONTROLCONFIG'].fields_by_name['max_units']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTOR']._serialized_start = 153
    _globals['_CONNECTOR']._serialized_end = 1078
    _globals['_CONNECTOR_DATASOURCECONFIGENTRY']._serialized_start = 930
    _globals['_CONNECTOR_DATASOURCECONFIGENTRY']._serialized_end = 997
    _globals['_FLOWCONTROLCONFIG']._serialized_start = 1081
    _globals['_FLOWCONTROLCONFIG']._serialized_end = 1237