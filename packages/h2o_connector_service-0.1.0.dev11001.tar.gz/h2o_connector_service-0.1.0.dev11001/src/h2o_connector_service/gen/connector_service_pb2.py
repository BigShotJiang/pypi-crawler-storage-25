"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'connector_service.proto')
_sym_db = _symbol_database.Default()
from . import connector_pb2 as connector__pb2
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import client_pb2 as google_dot_api_dot_client__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from google.protobuf import field_mask_pb2 as google_dot_protobuf_dot_field__mask__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x17connector_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0fconnector.proto\x1a\x1cgoogle/api/annotations.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a google/protobuf/field_mask.proto"\x8b\x01\n\x16CreateConnectorRequest\x12G\n\tconnector\x18\x01 \x01(\x0b2$.ai.h2o.connectors.v1alpha.ConnectorB\x03\xe0A\x02R\tconnector\x12(\n\rvalidate_only\x18\x02 \x01(\x08B\x03\xe0A\x01R\x0cvalidateOnly"N\n\x13GetConnectorRequest\x127\n\x04name\x18\x01 \x01(\tB#\xe0A\x02\xfaA\x1d\n\x1bconnectors.h2o.ai/ConnectorR\x04name"\xc2\x01\n\x15ListConnectorsRequest\x12 \n\tpage_size\x18\x01 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x02 \x01(\tB\x03\xe0A\x01R\tpageToken\x12\x1b\n\x06filter\x18\x03 \x01(\tB\x03\xe0A\x01R\x06filter\x12\x1e\n\x08order_by\x18\x04 \x01(\tB\x03\xe0A\x01R\x07orderBy\x12&\n\x0cworkspace_id\x18\x05 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId"\xb4\x01\n\x16ListConnectorsResponse\x12I\n\nconnectors\x18\x01 \x03(\x0b2$.ai.h2o.connectors.v1alpha.ConnectorB\x03\xe0A\x03R\nconnectors\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12"\n\ntotal_size\x18\x03 \x01(\x05B\x03\xe0A\x03R\ttotalSize"\xa3\x01\n\x16UpdateConnectorRequest\x12G\n\tconnector\x18\x01 \x01(\x0b2$.ai.h2o.connectors.v1alpha.ConnectorB\x03\xe0A\x02R\tconnector\x12@\n\x0bupdate_mask\x18\x02 \x01(\x0b2\x1a.google.protobuf.FieldMaskB\x03\xe0A\x01R\nupdateMask"Q\n\x16DeleteConnectorRequest\x127\n\x04name\x18\x01 \x01(\tB#\xe0A\x02\xfaA\x1d\n\x1bconnectors.h2o.ai/ConnectorR\x04name2\x86\x07\n\x10ConnectorService\x12\xba\x01\n\x0fCreateConnector\x121.ai.h2o.connectors.v1alpha.CreateConnectorRequest\x1a$.ai.h2o.connectors.v1alpha.Connector"N\xdaA\tconnector\x82\xd3\xe4\x93\x02<"7/v1alpha/workspaces/{connector.workspace_id}/connectors:\x01*\x12\x9e\x01\n\x0cGetConnector\x12..ai.h2o.connectors.v1alpha.GetConnectorRequest\x1a$.ai.h2o.connectors.v1alpha.Connector"8\xdaA\x04name\x82\xd3\xe4\x93\x02+\x12)/v1alpha/{name=workspaces/*/connectors/*}\x12\xac\x01\n\x0eListConnectors\x120.ai.h2o.connectors.v1alpha.ListConnectorsRequest\x1a1.ai.h2o.connectors.v1alpha.ListConnectorsResponse"5\x82\xd3\xe4\x93\x02/\x12-/v1alpha/workspaces/{workspace_id}/connectors\x12\xcb\x01\n\x0fUpdateConnector\x121.ai.h2o.connectors.v1alpha.UpdateConnectorRequest\x1a$.ai.h2o.connectors.v1alpha.Connector"_\xdaA\x15connector,update_mask\x82\xd3\xe4\x93\x02A2</v1alpha/{connector.metadata.name=workspaces/*/connectors/*}:\x01*\x12\x96\x01\n\x0fDeleteConnector\x121.ai.h2o.connectors.v1alpha.DeleteConnectorRequest\x1a\x16.google.protobuf.Empty"8\xdaA\x04name\x82\xd3\xe4\x93\x02+*)/v1alpha/{name=workspaces/*/connectors/*}B\x8b\x01\n\x19ai.h2o.connectors.v1alphaB\x15ConnectorServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'connector_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x15ConnectorServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CREATECONNECTORREQUEST'].fields_by_name['connector']._loaded_options = None
    _globals['_CREATECONNECTORREQUEST'].fields_by_name['connector']._serialized_options = b'\xe0A\x02'
    _globals['_CREATECONNECTORREQUEST'].fields_by_name['validate_only']._loaded_options = None
    _globals['_CREATECONNECTORREQUEST'].fields_by_name['validate_only']._serialized_options = b'\xe0A\x01'
    _globals['_GETCONNECTORREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_GETCONNECTORREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1d\n\x1bconnectors.h2o.ai/Connector'
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['filter']._loaded_options = None
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['order_by']._loaded_options = None
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['order_by']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_LISTCONNECTORSREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_LISTCONNECTORSRESPONSE'].fields_by_name['connectors']._loaded_options = None
    _globals['_LISTCONNECTORSRESPONSE'].fields_by_name['connectors']._serialized_options = b'\xe0A\x03'
    _globals['_LISTCONNECTORSRESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_LISTCONNECTORSRESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_LISTCONNECTORSRESPONSE'].fields_by_name['total_size']._loaded_options = None
    _globals['_LISTCONNECTORSRESPONSE'].fields_by_name['total_size']._serialized_options = b'\xe0A\x03'
    _globals['_UPDATECONNECTORREQUEST'].fields_by_name['connector']._loaded_options = None
    _globals['_UPDATECONNECTORREQUEST'].fields_by_name['connector']._serialized_options = b'\xe0A\x02'
    _globals['_UPDATECONNECTORREQUEST'].fields_by_name['update_mask']._loaded_options = None
    _globals['_UPDATECONNECTORREQUEST'].fields_by_name['update_mask']._serialized_options = b'\xe0A\x01'
    _globals['_DELETECONNECTORREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_DELETECONNECTORREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1d\n\x1bconnectors.h2o.ai/Connector'
    _globals['_CONNECTORSERVICE'].methods_by_name['CreateConnector']._loaded_options = None
    _globals['_CONNECTORSERVICE'].methods_by_name['CreateConnector']._serialized_options = b'\xdaA\tconnector\x82\xd3\xe4\x93\x02<"7/v1alpha/workspaces/{connector.workspace_id}/connectors:\x01*'
    _globals['_CONNECTORSERVICE'].methods_by_name['GetConnector']._loaded_options = None
    _globals['_CONNECTORSERVICE'].methods_by_name['GetConnector']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02+\x12)/v1alpha/{name=workspaces/*/connectors/*}'
    _globals['_CONNECTORSERVICE'].methods_by_name['ListConnectors']._loaded_options = None
    _globals['_CONNECTORSERVICE'].methods_by_name['ListConnectors']._serialized_options = b'\x82\xd3\xe4\x93\x02/\x12-/v1alpha/workspaces/{workspace_id}/connectors'
    _globals['_CONNECTORSERVICE'].methods_by_name['UpdateConnector']._loaded_options = None
    _globals['_CONNECTORSERVICE'].methods_by_name['UpdateConnector']._serialized_options = b'\xdaA\x15connector,update_mask\x82\xd3\xe4\x93\x02A2</v1alpha/{connector.metadata.name=workspaces/*/connectors/*}:\x01*'
    _globals['_CONNECTORSERVICE'].methods_by_name['DeleteConnector']._loaded_options = None
    _globals['_CONNECTORSERVICE'].methods_by_name['DeleteConnector']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02+*)/v1alpha/{name=workspaces/*/connectors/*}'
    _globals['_CREATECONNECTORREQUEST']._serialized_start = 250
    _globals['_CREATECONNECTORREQUEST']._serialized_end = 389
    _globals['_GETCONNECTORREQUEST']._serialized_start = 391
    _globals['_GETCONNECTORREQUEST']._serialized_end = 469
    _globals['_LISTCONNECTORSREQUEST']._serialized_start = 472
    _globals['_LISTCONNECTORSREQUEST']._serialized_end = 666
    _globals['_LISTCONNECTORSRESPONSE']._serialized_start = 669
    _globals['_LISTCONNECTORSRESPONSE']._serialized_end = 849
    _globals['_UPDATECONNECTORREQUEST']._serialized_start = 852
    _globals['_UPDATECONNECTORREQUEST']._serialized_end = 1015
    _globals['_DELETECONNECTORREQUEST']._serialized_start = 1017
    _globals['_DELETECONNECTORREQUEST']._serialized_end = 1098
    _globals['_CONNECTORSERVICE']._serialized_start = 1101
    _globals['_CONNECTORSERVICE']._serialized_end = 2003