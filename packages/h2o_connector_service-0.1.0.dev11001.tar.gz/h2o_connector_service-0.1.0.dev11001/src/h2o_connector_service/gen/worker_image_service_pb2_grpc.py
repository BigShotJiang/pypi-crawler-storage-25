"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from . import worker_image_pb2 as worker__image__pb2
from . import worker_image_service_pb2 as worker__image__service__pb2

class WorkerImageServiceStub(object):
    """=============================================================================
    Worker Image Service
    =============================================================================

    WorkerImageService manages worker images.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CreateWorkerImage = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerImageService/CreateWorkerImage', request_serializer=worker__image__service__pb2.CreateWorkerImageRequest.SerializeToString, response_deserializer=worker__image__pb2.WorkerImage.FromString, _registered_method=True)
        self.GetWorkerImage = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerImageService/GetWorkerImage', request_serializer=worker__image__service__pb2.GetWorkerImageRequest.SerializeToString, response_deserializer=worker__image__pb2.WorkerImage.FromString, _registered_method=True)
        self.ListWorkerImages = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerImageService/ListWorkerImages', request_serializer=worker__image__service__pb2.ListWorkerImagesRequest.SerializeToString, response_deserializer=worker__image__service__pb2.ListWorkerImagesResponse.FromString, _registered_method=True)
        self.UpdateWorkerImage = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerImageService/UpdateWorkerImage', request_serializer=worker__image__service__pb2.UpdateWorkerImageRequest.SerializeToString, response_deserializer=worker__image__pb2.WorkerImage.FromString, _registered_method=True)
        self.DeleteWorkerImage = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerImageService/DeleteWorkerImage', request_serializer=worker__image__service__pb2.DeleteWorkerImageRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString, _registered_method=True)

class WorkerImageServiceServicer(object):
    """=============================================================================
    Worker Image Service
    =============================================================================

    WorkerImageService manages worker images.
    """

    def CreateWorkerImage(self, request, context):
        """Creates a new worker image.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetWorkerImage(self, request, context):
        """Gets a worker image by name.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListWorkerImages(self, request, context):
        """Lists worker images.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def UpdateWorkerImage(self, request, context):
        """Updates a worker image.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteWorkerImage(self, request, context):
        """Deletes a worker image.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_WorkerImageServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'CreateWorkerImage': grpc.unary_unary_rpc_method_handler(servicer.CreateWorkerImage, request_deserializer=worker__image__service__pb2.CreateWorkerImageRequest.FromString, response_serializer=worker__image__pb2.WorkerImage.SerializeToString), 'GetWorkerImage': grpc.unary_unary_rpc_method_handler(servicer.GetWorkerImage, request_deserializer=worker__image__service__pb2.GetWorkerImageRequest.FromString, response_serializer=worker__image__pb2.WorkerImage.SerializeToString), 'ListWorkerImages': grpc.unary_unary_rpc_method_handler(servicer.ListWorkerImages, request_deserializer=worker__image__service__pb2.ListWorkerImagesRequest.FromString, response_serializer=worker__image__service__pb2.ListWorkerImagesResponse.SerializeToString), 'UpdateWorkerImage': grpc.unary_unary_rpc_method_handler(servicer.UpdateWorkerImage, request_deserializer=worker__image__service__pb2.UpdateWorkerImageRequest.FromString, response_serializer=worker__image__pb2.WorkerImage.SerializeToString), 'DeleteWorkerImage': grpc.unary_unary_rpc_method_handler(servicer.DeleteWorkerImage, request_deserializer=worker__image__service__pb2.DeleteWorkerImageRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.WorkerImageService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.WorkerImageService', rpc_method_handlers)

class WorkerImageService(object):
    """=============================================================================
    Worker Image Service
    =============================================================================

    WorkerImageService manages worker images.
    """

    @staticmethod
    def CreateWorkerImage(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerImageService/CreateWorkerImage', worker__image__service__pb2.CreateWorkerImageRequest.SerializeToString, worker__image__pb2.WorkerImage.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetWorkerImage(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerImageService/GetWorkerImage', worker__image__service__pb2.GetWorkerImageRequest.SerializeToString, worker__image__pb2.WorkerImage.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ListWorkerImages(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerImageService/ListWorkerImages', worker__image__service__pb2.ListWorkerImagesRequest.SerializeToString, worker__image__service__pb2.ListWorkerImagesResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def UpdateWorkerImage(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerImageService/UpdateWorkerImage', worker__image__service__pb2.UpdateWorkerImageRequest.SerializeToString, worker__image__pb2.WorkerImage.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def DeleteWorkerImage(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerImageService/DeleteWorkerImage', worker__image__service__pb2.DeleteWorkerImageRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)