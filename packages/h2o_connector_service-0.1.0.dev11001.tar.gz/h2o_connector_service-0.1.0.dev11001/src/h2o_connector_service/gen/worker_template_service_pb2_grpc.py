"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from . import worker_template_pb2 as worker__template__pb2
from . import worker_template_service_pb2 as worker__template__service__pb2

class WorkerTemplateServiceStub(object):
    """=============================================================================
    Worker Template Service
    =============================================================================

    WorkerTemplateService manages global worker templates.
    Templates define reusable worker configurations with workspace access controls.
    Platform administrators can create and manage templates.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CreateWorkerTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerTemplateService/CreateWorkerTemplate', request_serializer=worker__template__service__pb2.CreateWorkerTemplateRequest.SerializeToString, response_deserializer=worker__template__pb2.WorkerTemplate.FromString, _registered_method=True)
        self.GetWorkerTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerTemplateService/GetWorkerTemplate', request_serializer=worker__template__service__pb2.GetWorkerTemplateRequest.SerializeToString, response_deserializer=worker__template__pb2.WorkerTemplate.FromString, _registered_method=True)
        self.ListWorkerTemplates = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerTemplateService/ListWorkerTemplates', request_serializer=worker__template__service__pb2.ListWorkerTemplatesRequest.SerializeToString, response_deserializer=worker__template__service__pb2.ListWorkerTemplatesResponse.FromString, _registered_method=True)
        self.UpdateWorkerTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerTemplateService/UpdateWorkerTemplate', request_serializer=worker__template__service__pb2.UpdateWorkerTemplateRequest.SerializeToString, response_deserializer=worker__template__pb2.WorkerTemplate.FromString, _registered_method=True)
        self.DeleteWorkerTemplate = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerTemplateService/DeleteWorkerTemplate', request_serializer=worker__template__service__pb2.DeleteWorkerTemplateRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString, _registered_method=True)

class WorkerTemplateServiceServicer(object):
    """=============================================================================
    Worker Template Service
    =============================================================================

    WorkerTemplateService manages global worker templates.
    Templates define reusable worker configurations with workspace access controls.
    Platform administrators can create and manage templates.
    """

    def CreateWorkerTemplate(self, request, context):
        """Creates a new worker template.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetWorkerTemplate(self, request, context):
        """Gets a worker template by name.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListWorkerTemplates(self, request, context):
        """Lists worker templates.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def UpdateWorkerTemplate(self, request, context):
        """Updates a worker template.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteWorkerTemplate(self, request, context):
        """Deletes a worker template.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_WorkerTemplateServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'CreateWorkerTemplate': grpc.unary_unary_rpc_method_handler(servicer.CreateWorkerTemplate, request_deserializer=worker__template__service__pb2.CreateWorkerTemplateRequest.FromString, response_serializer=worker__template__pb2.WorkerTemplate.SerializeToString), 'GetWorkerTemplate': grpc.unary_unary_rpc_method_handler(servicer.GetWorkerTemplate, request_deserializer=worker__template__service__pb2.GetWorkerTemplateRequest.FromString, response_serializer=worker__template__pb2.WorkerTemplate.SerializeToString), 'ListWorkerTemplates': grpc.unary_unary_rpc_method_handler(servicer.ListWorkerTemplates, request_deserializer=worker__template__service__pb2.ListWorkerTemplatesRequest.FromString, response_serializer=worker__template__service__pb2.ListWorkerTemplatesResponse.SerializeToString), 'UpdateWorkerTemplate': grpc.unary_unary_rpc_method_handler(servicer.UpdateWorkerTemplate, request_deserializer=worker__template__service__pb2.UpdateWorkerTemplateRequest.FromString, response_serializer=worker__template__pb2.WorkerTemplate.SerializeToString), 'DeleteWorkerTemplate': grpc.unary_unary_rpc_method_handler(servicer.DeleteWorkerTemplate, request_deserializer=worker__template__service__pb2.DeleteWorkerTemplateRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.WorkerTemplateService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.WorkerTemplateService', rpc_method_handlers)

class WorkerTemplateService(object):
    """=============================================================================
    Worker Template Service
    =============================================================================

    WorkerTemplateService manages global worker templates.
    Templates define reusable worker configurations with workspace access controls.
    Platform administrators can create and manage templates.
    """

    @staticmethod
    def CreateWorkerTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerTemplateService/CreateWorkerTemplate', worker__template__service__pb2.CreateWorkerTemplateRequest.SerializeToString, worker__template__pb2.WorkerTemplate.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetWorkerTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerTemplateService/GetWorkerTemplate', worker__template__service__pb2.GetWorkerTemplateRequest.SerializeToString, worker__template__pb2.WorkerTemplate.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ListWorkerTemplates(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerTemplateService/ListWorkerTemplates', worker__template__service__pb2.ListWorkerTemplatesRequest.SerializeToString, worker__template__service__pb2.ListWorkerTemplatesResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def UpdateWorkerTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerTemplateService/UpdateWorkerTemplate', worker__template__service__pb2.UpdateWorkerTemplateRequest.SerializeToString, worker__template__pb2.WorkerTemplate.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def DeleteWorkerTemplate(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerTemplateService/DeleteWorkerTemplate', worker__template__service__pb2.DeleteWorkerTemplateRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)