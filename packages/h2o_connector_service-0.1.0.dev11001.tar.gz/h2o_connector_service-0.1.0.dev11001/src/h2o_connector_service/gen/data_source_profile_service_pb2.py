"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'data_source_profile_service.proto')
_sym_db = _symbol_database.Default()
from . import data_source_profile_pb2 as data__source__profile__pb2
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n!data_source_profile_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x19data_source_profile.proto\x1a\x1cgoogle/api/annotations.proto\x1a\x1fgoogle/api/field_behavior.proto"\x82\x01\n\x1dListDataSourceProfilesRequest\x12 \n\tpage_size\x18\x01 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x02 \x01(\tB\x03\xe0A\x01R\tpageToken\x12\x1b\n\x06filter\x18\x03 \x01(\tB\x03\xe0A\x01R\x06filter"\xc0\x01\n\x1eListDataSourceProfilesResponse\x12M\n\x08profiles\x18\x01 \x03(\x0b2,.ai.h2o.connectors.v1alpha.DataSourceProfileB\x03\xe0A\x03R\x08profiles\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12"\n\ntotal_size\x18\x03 \x01(\x05B\x03\xe0A\x03R\ttotalSize2\xcf\x01\n\x18DataSourceProfileService\x12\xb2\x01\n\x16ListDataSourceProfiles\x128.ai.h2o.connectors.v1alpha.ListDataSourceProfilesRequest\x1a9.ai.h2o.connectors.v1alpha.ListDataSourceProfilesResponse"#\x82\xd3\xe4\x93\x02\x1d\x12\x1b/v1alpha/dataSourceProfilesB\x93\x01\n\x19ai.h2o.connectors.v1alphaB\x1dDataSourceProfileServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'data_source_profile_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x1dDataSourceProfileServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_LISTDATASOURCEPROFILESREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTDATASOURCEPROFILESREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTDATASOURCEPROFILESREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTDATASOURCEPROFILESREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTDATASOURCEPROFILESREQUEST'].fields_by_name['filter']._loaded_options = None
    _globals['_LISTDATASOURCEPROFILESREQUEST'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_LISTDATASOURCEPROFILESRESPONSE'].fields_by_name['profiles']._loaded_options = None
    _globals['_LISTDATASOURCEPROFILESRESPONSE'].fields_by_name['profiles']._serialized_options = b'\xe0A\x03'
    _globals['_LISTDATASOURCEPROFILESRESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_LISTDATASOURCEPROFILESRESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_LISTDATASOURCEPROFILESRESPONSE'].fields_by_name['total_size']._loaded_options = None
    _globals['_LISTDATASOURCEPROFILESRESPONSE'].fields_by_name['total_size']._serialized_options = b'\xe0A\x03'
    _globals['_DATASOURCEPROFILESERVICE'].methods_by_name['ListDataSourceProfiles']._loaded_options = None
    _globals['_DATASOURCEPROFILESERVICE'].methods_by_name['ListDataSourceProfiles']._serialized_options = b'\x82\xd3\xe4\x93\x02\x1d\x12\x1b/v1alpha/dataSourceProfiles'
    _globals['_LISTDATASOURCEPROFILESREQUEST']._serialized_start = 155
    _globals['_LISTDATASOURCEPROFILESREQUEST']._serialized_end = 285
    _globals['_LISTDATASOURCEPROFILESRESPONSE']._serialized_start = 288
    _globals['_LISTDATASOURCEPROFILESRESPONSE']._serialized_end = 480
    _globals['_DATASOURCEPROFILESERVICE']._serialized_start = 483
    _globals['_DATASOURCEPROFILESERVICE']._serialized_end = 690