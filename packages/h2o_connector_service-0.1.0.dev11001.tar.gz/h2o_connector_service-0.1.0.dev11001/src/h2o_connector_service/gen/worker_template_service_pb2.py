"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'worker_template_service.proto')
_sym_db = _symbol_database.Default()
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import client_pb2 as google_dot_api_dot_client__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from google.protobuf import field_mask_pb2 as google_dot_protobuf_dot_field__mask__pb2
from . import worker_template_pb2 as worker__template__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1dworker_template_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x1cgoogle/api/annotations.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a google/protobuf/field_mask.proto\x1a\x15worker_template.proto"v\n\x1bCreateWorkerTemplateRequest\x12W\n\x0fworker_template\x18\x01 \x01(\x0b2).ai.h2o.connectors.v1alpha.WorkerTemplateB\x03\xe0A\x02R\x0eworkerTemplate"X\n\x18GetWorkerTemplateRequest\x12<\n\x04name\x18\x01 \x01(\tB(\xe0A\x02\xfaA"\n connectors.h2o.ai/WorkerTemplateR\x04name"\xc7\x01\n\x1aListWorkerTemplatesRequest\x12 \n\tpage_size\x18\x01 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x02 \x01(\tB\x03\xe0A\x01R\tpageToken\x12\x1b\n\x06filter\x18\x03 \x01(\tB\x03\xe0A\x01R\x06filter\x12\x1e\n\x08order_by\x18\x04 \x01(\tB\x03\xe0A\x01R\x07orderBy\x12&\n\x0cworkspace_id\x18\x05 \x01(\tB\x03\xe0A\x01R\x0bworkspaceId"\xc9\x01\n\x1bListWorkerTemplatesResponse\x12Y\n\x10worker_templates\x18\x01 \x03(\x0b2).ai.h2o.connectors.v1alpha.WorkerTemplateB\x03\xe0A\x03R\x0fworkerTemplates\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12"\n\ntotal_size\x18\x03 \x01(\x05B\x03\xe0A\x03R\ttotalSize"\xb8\x01\n\x1bUpdateWorkerTemplateRequest\x12W\n\x0fworker_template\x18\x01 \x01(\x0b2).ai.h2o.connectors.v1alpha.WorkerTemplateB\x03\xe0A\x02R\x0eworkerTemplate\x12@\n\x0bupdate_mask\x18\x02 \x01(\x0b2\x1a.google.protobuf.FieldMaskB\x03\xe0A\x01R\nupdateMask"[\n\x1bDeleteWorkerTemplateRequest\x12<\n\x04name\x18\x01 \x01(\tB(\xe0A\x02\xfaA"\n connectors.h2o.ai/WorkerTemplateR\x04name2\x97\x07\n\x15WorkerTemplateService\x12\xb0\x01\n\x14CreateWorkerTemplate\x126.ai.h2o.connectors.v1alpha.CreateWorkerTemplateRequest\x1a).ai.h2o.connectors.v1alpha.WorkerTemplate"5\xdaA\x0fworker_template\x82\xd3\xe4\x93\x02\x1d"\x18/v1alpha/workerTemplates:\x01*\x12\xa5\x01\n\x11GetWorkerTemplate\x123.ai.h2o.connectors.v1alpha.GetWorkerTemplateRequest\x1a).ai.h2o.connectors.v1alpha.WorkerTemplate"0\xdaA\x04name\x82\xd3\xe4\x93\x02#\x12!/v1alpha/{name=workerTemplates/*}\x12\xa6\x01\n\x13ListWorkerTemplates\x125.ai.h2o.connectors.v1alpha.ListWorkerTemplatesRequest\x1a6.ai.h2o.connectors.v1alpha.ListWorkerTemplatesResponse" \x82\xd3\xe4\x93\x02\x1a\x12\x18/v1alpha/workerTemplates\x12\xde\x01\n\x14UpdateWorkerTemplate\x126.ai.h2o.connectors.v1alpha.UpdateWorkerTemplateRequest\x1a).ai.h2o.connectors.v1alpha.WorkerTemplate"c\xdaA\x1bworker_template,update_mask\x82\xd3\xe4\x93\x02?2:/v1alpha/{worker_template.metadata.name=workerTemplates/*}:\x01*\x12\x98\x01\n\x14DeleteWorkerTemplate\x126.ai.h2o.connectors.v1alpha.DeleteWorkerTemplateRequest\x1a\x16.google.protobuf.Empty"0\xdaA\x04name\x82\xd3\xe4\x93\x02#*!/v1alpha/{name=workerTemplates/*}B\x90\x01\n\x19ai.h2o.connectors.v1alphaB\x1aWorkerTemplateServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'worker_template_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x1aWorkerTemplateServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CREATEWORKERTEMPLATEREQUEST'].fields_by_name['worker_template']._loaded_options = None
    _globals['_CREATEWORKERTEMPLATEREQUEST'].fields_by_name['worker_template']._serialized_options = b'\xe0A\x02'
    _globals['_GETWORKERTEMPLATEREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_GETWORKERTEMPLATEREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA"\n connectors.h2o.ai/WorkerTemplate'
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['filter']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['order_by']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['order_by']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERTEMPLATESRESPONSE'].fields_by_name['worker_templates']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESRESPONSE'].fields_by_name['worker_templates']._serialized_options = b'\xe0A\x03'
    _globals['_LISTWORKERTEMPLATESRESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESRESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_LISTWORKERTEMPLATESRESPONSE'].fields_by_name['total_size']._loaded_options = None
    _globals['_LISTWORKERTEMPLATESRESPONSE'].fields_by_name['total_size']._serialized_options = b'\xe0A\x03'
    _globals['_UPDATEWORKERTEMPLATEREQUEST'].fields_by_name['worker_template']._loaded_options = None
    _globals['_UPDATEWORKERTEMPLATEREQUEST'].fields_by_name['worker_template']._serialized_options = b'\xe0A\x02'
    _globals['_UPDATEWORKERTEMPLATEREQUEST'].fields_by_name['update_mask']._loaded_options = None
    _globals['_UPDATEWORKERTEMPLATEREQUEST'].fields_by_name['update_mask']._serialized_options = b'\xe0A\x01'
    _globals['_DELETEWORKERTEMPLATEREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_DELETEWORKERTEMPLATEREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA"\n connectors.h2o.ai/WorkerTemplate'
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['CreateWorkerTemplate']._loaded_options = None
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['CreateWorkerTemplate']._serialized_options = b'\xdaA\x0fworker_template\x82\xd3\xe4\x93\x02\x1d"\x18/v1alpha/workerTemplates:\x01*'
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['GetWorkerTemplate']._loaded_options = None
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['GetWorkerTemplate']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02#\x12!/v1alpha/{name=workerTemplates/*}'
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['ListWorkerTemplates']._loaded_options = None
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['ListWorkerTemplates']._serialized_options = b'\x82\xd3\xe4\x93\x02\x1a\x12\x18/v1alpha/workerTemplates'
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['UpdateWorkerTemplate']._loaded_options = None
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['UpdateWorkerTemplate']._serialized_options = b'\xdaA\x1bworker_template,update_mask\x82\xd3\xe4\x93\x02?2:/v1alpha/{worker_template.metadata.name=workerTemplates/*}:\x01*'
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['DeleteWorkerTemplate']._loaded_options = None
    _globals['_WORKERTEMPLATESERVICE'].methods_by_name['DeleteWorkerTemplate']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02#*!/v1alpha/{name=workerTemplates/*}'
    _globals['_CREATEWORKERTEMPLATEREQUEST']._serialized_start = 261
    _globals['_CREATEWORKERTEMPLATEREQUEST']._serialized_end = 379
    _globals['_GETWORKERTEMPLATEREQUEST']._serialized_start = 381
    _globals['_GETWORKERTEMPLATEREQUEST']._serialized_end = 469
    _globals['_LISTWORKERTEMPLATESREQUEST']._serialized_start = 472
    _globals['_LISTWORKERTEMPLATESREQUEST']._serialized_end = 671
    _globals['_LISTWORKERTEMPLATESRESPONSE']._serialized_start = 674
    _globals['_LISTWORKERTEMPLATESRESPONSE']._serialized_end = 875
    _globals['_UPDATEWORKERTEMPLATEREQUEST']._serialized_start = 878
    _globals['_UPDATEWORKERTEMPLATEREQUEST']._serialized_end = 1062
    _globals['_DELETEWORKERTEMPLATEREQUEST']._serialized_start = 1064
    _globals['_DELETEWORKERTEMPLATEREQUEST']._serialized_end = 1155
    _globals['_WORKERTEMPLATESERVICE']._serialized_start = 1158
    _globals['_WORKERTEMPLATESERVICE']._serialized_end = 2077