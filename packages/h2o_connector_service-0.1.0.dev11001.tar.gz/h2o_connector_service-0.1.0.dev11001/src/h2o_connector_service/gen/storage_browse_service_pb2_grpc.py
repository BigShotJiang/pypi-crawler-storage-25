"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import storage_browse_service_pb2 as storage__browse__service__pb2

class StorageBrowseServiceStub(object):
    """=============================================================================
    Storage Browse Service
    =============================================================================

    StorageBrowseService provides APIs for browsing folder structures in storage
    backends (S3, GCS, Azure Blob). After a connection is created and ready,
    clients connect to this service (via the worker endpoint) to browse storage.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.BrowseStorage = channel.unary_unary('/ai.h2o.connectors.v1alpha.StorageBrowseService/BrowseStorage', request_serializer=storage__browse__service__pb2.BrowseStorageRequest.SerializeToString, response_deserializer=storage__browse__service__pb2.BrowseStorageResponse.FromString, _registered_method=True)

class StorageBrowseServiceServicer(object):
    """=============================================================================
    Storage Browse Service
    =============================================================================

    StorageBrowseService provides APIs for browsing folder structures in storage
    backends (S3, GCS, Azure Blob). After a connection is created and ready,
    clients connect to this service (via the worker endpoint) to browse storage.
    """

    def BrowseStorage(self, request, context):
        """Browses storage entries under a given prefix.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_StorageBrowseServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'BrowseStorage': grpc.unary_unary_rpc_method_handler(servicer.BrowseStorage, request_deserializer=storage__browse__service__pb2.BrowseStorageRequest.FromString, response_serializer=storage__browse__service__pb2.BrowseStorageResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.StorageBrowseService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.StorageBrowseService', rpc_method_handlers)

class StorageBrowseService(object):
    """=============================================================================
    Storage Browse Service
    =============================================================================

    StorageBrowseService provides APIs for browsing folder structures in storage
    backends (S3, GCS, Azure Blob). After a connection is created and ready,
    clients connect to this service (via the worker endpoint) to browse storage.
    """

    @staticmethod
    def BrowseStorage(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.StorageBrowseService/BrowseStorage', storage__browse__service__pb2.BrowseStorageRequest.SerializeToString, storage__browse__service__pb2.BrowseStorageResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)