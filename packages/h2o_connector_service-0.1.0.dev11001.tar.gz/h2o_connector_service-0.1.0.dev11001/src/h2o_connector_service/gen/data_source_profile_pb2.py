"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'data_source_profile.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x19data_source_profile.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\x1fgoogle/api/field_behavior.proto"\x80\x03\n\x0fConfigParameter\x12\x15\n\x03key\x18\x01 \x01(\tB\x03\xe0A\x02R\x03key\x12&\n\x0cdisplay_name\x18\x02 \x01(\tB\x03\xe0A\x01R\x0bdisplayName\x12%\n\x0bdescription\x18\x03 \x01(\tB\x03\xe0A\x01R\x0bdescription\x12G\n\x04type\x18\x04 \x01(\x0e2..ai.h2o.connectors.v1alpha.ConfigParameterTypeB\x03\xe0A\x02R\x04type\x12\x1f\n\x08required\x18\x05 \x01(\x08B\x03\xe0A\x01R\x08required\x12(\n\rdefault_value\x18\x06 \x01(\tB\x03\xe0A\x01R\x0cdefaultValue\x12*\n\x0eallowed_values\x18\x07 \x03(\tB\x03\xe0A\x01R\rallowedValues\x12\x1d\n\x07example\x18\x08 \x01(\tB\x03\xe0A\x01R\x07example\x12(\n\rdisplay_order\x18\t \x01(\x05B\x03\xe0A\x01R\x0cdisplayOrder"\x80\x02\n\x14ConfigParameterGroup\x12\x1e\n\x08group_id\x18\x01 \x01(\tB\x03\xe0A\x02R\x07groupId\x12&\n\x0cdisplay_name\x18\x02 \x01(\tB\x03\xe0A\x01R\x0bdisplayName\x12%\n\x0bdescription\x18\x03 \x01(\tB\x03\xe0A\x01R\x0bdescription\x12O\n\nparameters\x18\x04 \x03(\x0b2*.ai.h2o.connectors.v1alpha.ConfigParameterB\x03\xe0A\x01R\nparameters\x12(\n\rdisplay_order\x18\x05 \x01(\x05B\x03\xe0A\x01R\x0cdisplayOrder"\xd2\x03\n\x11DataSourceProfile\x12-\n\x10data_source_type\x18\x01 \x01(\tB\x03\xe0A\x02R\x0edataSourceType\x12N\n\x08category\x18\x02 \x01(\x0e2-.ai.h2o.connectors.v1alpha.DataSourceCategoryB\x03\xe0A\x01R\x08category\x12&\n\x0cdisplay_name\x18\x03 \x01(\tB\x03\xe0A\x01R\x0bdisplayName\x12%\n\x0bdescription\x18\x04 \x01(\tB\x03\xe0A\x01R\x0bdescription\x12\\\n\x11common_parameters\x18\x05 \x03(\x0b2*.ai.h2o.connectors.v1alpha.ConfigParameterB\x03\xe0A\x01R\x10commonParameters\x12_\n\x10parameter_groups\x18\x06 \x03(\x0b2/.ai.h2o.connectors.v1alpha.ConfigParameterGroupB\x03\xe0A\x01R\x0fparameterGroups\x120\n\x11documentation_url\x18\x07 \x01(\tB\x03\xe0A\x01R\x10documentationUrl*\xe6\x01\n\x13ConfigParameterType\x12%\n!CONFIG_PARAMETER_TYPE_UNSPECIFIED\x10\x00\x12 \n\x1cCONFIG_PARAMETER_TYPE_STRING\x10\x01\x12!\n\x1dCONFIG_PARAMETER_TYPE_INTEGER\x10\x02\x12!\n\x1dCONFIG_PARAMETER_TYPE_BOOLEAN\x10\x03\x12 \n\x1cCONFIG_PARAMETER_TYPE_SECRET\x10\x04\x12\x1e\n\x1aCONFIG_PARAMETER_TYPE_ENUM\x10\x05B\x8c\x01\n\x19ai.h2o.connectors.v1alphaB\x16DataSourceProfileProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'data_source_profile_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x16DataSourceProfileProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CONFIGPARAMETER'].fields_by_name['key']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['key']._serialized_options = b'\xe0A\x02'
    _globals['_CONFIGPARAMETER'].fields_by_name['display_name']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['display_name']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETER'].fields_by_name['description']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['description']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETER'].fields_by_name['type']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['type']._serialized_options = b'\xe0A\x02'
    _globals['_CONFIGPARAMETER'].fields_by_name['required']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['required']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETER'].fields_by_name['default_value']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['default_value']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETER'].fields_by_name['allowed_values']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['allowed_values']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETER'].fields_by_name['example']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['example']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETER'].fields_by_name['display_order']._loaded_options = None
    _globals['_CONFIGPARAMETER'].fields_by_name['display_order']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['group_id']._loaded_options = None
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['group_id']._serialized_options = b'\xe0A\x02'
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['display_name']._loaded_options = None
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['display_name']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['description']._loaded_options = None
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['description']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['parameters']._loaded_options = None
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['parameters']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['display_order']._loaded_options = None
    _globals['_CONFIGPARAMETERGROUP'].fields_by_name['display_order']._serialized_options = b'\xe0A\x01'
    _globals['_DATASOURCEPROFILE'].fields_by_name['data_source_type']._loaded_options = None
    _globals['_DATASOURCEPROFILE'].fields_by_name['data_source_type']._serialized_options = b'\xe0A\x02'
    _globals['_DATASOURCEPROFILE'].fields_by_name['category']._loaded_options = None
    _globals['_DATASOURCEPROFILE'].fields_by_name['category']._serialized_options = b'\xe0A\x01'
    _globals['_DATASOURCEPROFILE'].fields_by_name['display_name']._loaded_options = None
    _globals['_DATASOURCEPROFILE'].fields_by_name['display_name']._serialized_options = b'\xe0A\x01'
    _globals['_DATASOURCEPROFILE'].fields_by_name['description']._loaded_options = None
    _globals['_DATASOURCEPROFILE'].fields_by_name['description']._serialized_options = b'\xe0A\x01'
    _globals['_DATASOURCEPROFILE'].fields_by_name['common_parameters']._loaded_options = None
    _globals['_DATASOURCEPROFILE'].fields_by_name['common_parameters']._serialized_options = b'\xe0A\x01'
    _globals['_DATASOURCEPROFILE'].fields_by_name['parameter_groups']._loaded_options = None
    _globals['_DATASOURCEPROFILE'].fields_by_name['parameter_groups']._serialized_options = b'\xe0A\x01'
    _globals['_DATASOURCEPROFILE'].fields_by_name['documentation_url']._loaded_options = None
    _globals['_DATASOURCEPROFILE'].fields_by_name['documentation_url']._serialized_options = b'\xe0A\x01'
    _globals['_CONFIGPARAMETERTYPE']._serialized_start = 1219
    _globals['_CONFIGPARAMETERTYPE']._serialized_end = 1449
    _globals['_CONFIGPARAMETER']._serialized_start = 104
    _globals['_CONFIGPARAMETER']._serialized_end = 488
    _globals['_CONFIGPARAMETERGROUP']._serialized_start = 491
    _globals['_CONFIGPARAMETERGROUP']._serialized_end = 747
    _globals['_DATASOURCEPROFILE']._serialized_start = 750
    _globals['_DATASOURCEPROFILE']._serialized_end = 1216