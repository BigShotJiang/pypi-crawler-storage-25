"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'k8s_service_account_service.proto')
_sym_db = _symbol_database.Default()
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n!k8s_service_account_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x1cgoogle/api/annotations.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x1bgoogle/protobuf/empty.proto"\x9e\x03\n\x11K8sServiceAccount\x12\x17\n\x04name\x18\x01 \x01(\tB\x03\xe0A\x03R\x04name\x12!\n\tnamespace\x18\x02 \x01(\tB\x03\xe0A\x03R\tnamespace\x12\x15\n\x03uid\x18\x03 \x01(\tB\x03\xe0A\x03R\x03uid\x12d\n\x0bannotations\x18\x04 \x03(\x0b2=.ai.h2o.connectors.v1alpha.K8sServiceAccount.AnnotationsEntryB\x03\xe0A\x03R\x0bannotations\x12U\n\x06labels\x18\x05 \x03(\x0b28.ai.h2o.connectors.v1alpha.K8sServiceAccount.LabelsEntryB\x03\xe0A\x03R\x06labels\x1a>\n\x10AnnotationsEntry\x12\x10\n\x03key\x18\x01 \x01(\tR\x03key\x12\x14\n\x05value\x18\x02 \x01(\tR\x05value:\x028\x01\x1a9\n\x0bLabelsEntry\x12\x10\n\x03key\x18\x01 \x01(\tR\x03key\x12\x14\n\x05value\x18\x02 \x01(\tR\x05value:\x028\x01"\xc2\x04\n\x1eCreateK8sServiceAccountRequest\x12!\n\tnamespace\x18\x01 \x01(\tB\x03\xe0A\x02R\tnamespace\x12\x17\n\x04name\x18\x02 \x01(\tB\x03\xe0A\x02R\x04name\x12l\n\x0bannotations\x18\x03 \x03(\x0b2J.ai.h2o.connectors.v1alpha.CreateK8sServiceAccountRequest.AnnotationsEntryR\x0bannotations\x12]\n\x06labels\x18\x04 \x03(\x0b2E.ai.h2o.connectors.v1alpha.CreateK8sServiceAccountRequest.LabelsEntryR\x06labels\x12,\n\x12image_pull_secrets\x18\x05 \x03(\tR\x10imagePullSecrets\x12J\n\x1fautomount_service_account_token\x18\x06 \x01(\x08H\x00R\x1cautomountServiceAccountToken\x88\x01\x01\x1a>\n\x10AnnotationsEntry\x12\x10\n\x03key\x18\x01 \x01(\tR\x03key\x12\x14\n\x05value\x18\x02 \x01(\tR\x05value:\x028\x01\x1a9\n\x0bLabelsEntry\x12\x10\n\x03key\x18\x01 \x01(\tR\x03key\x12\x14\n\x05value\x18\x02 \x01(\tR\x05value:\x028\x01B"\n _automount_service_account_token"\\\n\x1eDeleteK8sServiceAccountRequest\x12!\n\tnamespace\x18\x01 \x01(\tB\x03\xe0A\x02R\tnamespace\x12\x17\n\x04name\x18\x02 \x01(\tB\x03\xe0A\x02R\x04name2\x8a\x03\n\x18K8sServiceAccountService\x12\xbe\x01\n\x17CreateK8sServiceAccount\x129.ai.h2o.connectors.v1alpha.CreateK8sServiceAccountRequest\x1a,.ai.h2o.connectors.v1alpha.K8sServiceAccount":\x82\xd3\xe4\x93\x024"//v1alpha/namespaces/{namespace}/serviceAccounts:\x01*\x12\xac\x01\n\x17DeleteK8sServiceAccount\x129.ai.h2o.connectors.v1alpha.DeleteK8sServiceAccountRequest\x1a\x16.google.protobuf.Empty">\x82\xd3\xe4\x93\x028*6/v1alpha/namespaces/{namespace}/serviceAccounts/{name}B\x93\x01\n\x19ai.h2o.connectors.v1alphaB\x1dK8sServiceAccountServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'k8s_service_account_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x1dK8sServiceAccountServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_K8SSERVICEACCOUNT_ANNOTATIONSENTRY']._loaded_options = None
    _globals['_K8SSERVICEACCOUNT_ANNOTATIONSENTRY']._serialized_options = b'8\x01'
    _globals['_K8SSERVICEACCOUNT_LABELSENTRY']._loaded_options = None
    _globals['_K8SSERVICEACCOUNT_LABELSENTRY']._serialized_options = b'8\x01'
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['name']._loaded_options = None
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['name']._serialized_options = b'\xe0A\x03'
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['namespace']._loaded_options = None
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['namespace']._serialized_options = b'\xe0A\x03'
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['uid']._loaded_options = None
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['uid']._serialized_options = b'\xe0A\x03'
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['annotations']._loaded_options = None
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['annotations']._serialized_options = b'\xe0A\x03'
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['labels']._loaded_options = None
    _globals['_K8SSERVICEACCOUNT'].fields_by_name['labels']._serialized_options = b'\xe0A\x03'
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_ANNOTATIONSENTRY']._loaded_options = None
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_ANNOTATIONSENTRY']._serialized_options = b'8\x01'
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_LABELSENTRY']._loaded_options = None
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_LABELSENTRY']._serialized_options = b'8\x01'
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST'].fields_by_name['namespace']._loaded_options = None
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST'].fields_by_name['namespace']._serialized_options = b'\xe0A\x02'
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02'
    _globals['_DELETEK8SSERVICEACCOUNTREQUEST'].fields_by_name['namespace']._loaded_options = None
    _globals['_DELETEK8SSERVICEACCOUNTREQUEST'].fields_by_name['namespace']._serialized_options = b'\xe0A\x02'
    _globals['_DELETEK8SSERVICEACCOUNTREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_DELETEK8SSERVICEACCOUNTREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02'
    _globals['_K8SSERVICEACCOUNTSERVICE'].methods_by_name['CreateK8sServiceAccount']._loaded_options = None
    _globals['_K8SSERVICEACCOUNTSERVICE'].methods_by_name['CreateK8sServiceAccount']._serialized_options = b'\x82\xd3\xe4\x93\x024"//v1alpha/namespaces/{namespace}/serviceAccounts:\x01*'
    _globals['_K8SSERVICEACCOUNTSERVICE'].methods_by_name['DeleteK8sServiceAccount']._loaded_options = None
    _globals['_K8SSERVICEACCOUNTSERVICE'].methods_by_name['DeleteK8sServiceAccount']._serialized_options = b'\x82\xd3\xe4\x93\x028*6/v1alpha/namespaces/{namespace}/serviceAccounts/{name}'
    _globals['_K8SSERVICEACCOUNT']._serialized_start = 157
    _globals['_K8SSERVICEACCOUNT']._serialized_end = 571
    _globals['_K8SSERVICEACCOUNT_ANNOTATIONSENTRY']._serialized_start = 450
    _globals['_K8SSERVICEACCOUNT_ANNOTATIONSENTRY']._serialized_end = 512
    _globals['_K8SSERVICEACCOUNT_LABELSENTRY']._serialized_start = 514
    _globals['_K8SSERVICEACCOUNT_LABELSENTRY']._serialized_end = 571
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST']._serialized_start = 574
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST']._serialized_end = 1152
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_ANNOTATIONSENTRY']._serialized_start = 450
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_ANNOTATIONSENTRY']._serialized_end = 512
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_LABELSENTRY']._serialized_start = 514
    _globals['_CREATEK8SSERVICEACCOUNTREQUEST_LABELSENTRY']._serialized_end = 571
    _globals['_DELETEK8SSERVICEACCOUNTREQUEST']._serialized_start = 1154
    _globals['_DELETEK8SSERVICEACCOUNTREQUEST']._serialized_end = 1246
    _globals['_K8SSERVICEACCOUNTSERVICE']._serialized_start = 1249
    _globals['_K8SSERVICEACCOUNTSERVICE']._serialized_end = 1643