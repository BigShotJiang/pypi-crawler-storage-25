"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'worker_image.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x12worker_image.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto"\x96\x03\n\x0bWorkerImage\x12\x19\n\x05image\x18\x01 \x01(\tB\x03\xe0A\x02R\x05image\x12P\n\x0bpull_policy\x18\x02 \x01(\x0e2*.ai.h2o.connectors.v1alpha.ImagePullPolicyB\x03\xe0A\x01R\npullPolicy\x12p\n\x18workspace_access_control\x18\x03 \x01(\x0b21.ai.h2o.connectors.v1alpha.WorkspaceAccessControlB\x03\xe0A\x01R\x16workspaceAccessControl\x12L\n\x08metadata\x18\x04 \x01(\x0b2+.ai.h2o.connectors.v1alpha.ResourceMetadataB\x03\xe0A\x02R\x08metadata:Z\xeaAW\n\x1dconnectors.h2o.ai/WorkerImage\x12\x1bworkerImages/{worker_image}*\x0cworkerImages2\x0bworkerImage*\x95\x01\n\x0fImagePullPolicy\x12!\n\x1dIMAGE_PULL_POLICY_UNSPECIFIED\x10\x00\x12\x1c\n\x18IMAGE_PULL_POLICY_ALWAYS\x10\x01\x12$\n IMAGE_PULL_POLICY_IF_NOT_PRESENT\x10\x02\x12\x1b\n\x17IMAGE_PULL_POLICY_NEVER\x10\x03B\x86\x01\n\x19ai.h2o.connectors.v1alphaB\x10WorkerImageProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'worker_image_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x10WorkerImageProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_WORKERIMAGE'].fields_by_name['image']._loaded_options = None
    _globals['_WORKERIMAGE'].fields_by_name['image']._serialized_options = b'\xe0A\x02'
    _globals['_WORKERIMAGE'].fields_by_name['pull_policy']._loaded_options = None
    _globals['_WORKERIMAGE'].fields_by_name['pull_policy']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERIMAGE'].fields_by_name['workspace_access_control']._loaded_options = None
    _globals['_WORKERIMAGE'].fields_by_name['workspace_access_control']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERIMAGE'].fields_by_name['metadata']._loaded_options = None
    _globals['_WORKERIMAGE'].fields_by_name['metadata']._serialized_options = b'\xe0A\x02'
    _globals['_WORKERIMAGE']._loaded_options = None
    _globals['_WORKERIMAGE']._serialized_options = b'\xeaAW\n\x1dconnectors.h2o.ai/WorkerImage\x12\x1bworkerImages/{worker_image}*\x0cworkerImages2\x0bworkerImage'
    _globals['_IMAGEPULLPOLICY']._serialized_start = 533
    _globals['_IMAGEPULLPOLICY']._serialized_end = 682
    _globals['_WORKERIMAGE']._serialized_start = 124
    _globals['_WORKERIMAGE']._serialized_end = 530