"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'worker_service.proto')
_sym_db = _symbol_database.Default()
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import client_pb2 as google_dot_api_dot_client__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from google.protobuf import field_mask_pb2 as google_dot_protobuf_dot_field__mask__pb2
from . import worker_pb2 as worker__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x14worker_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x1cgoogle/api/annotations.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a google/protobuf/field_mask.proto\x1a\x0cworker.proto"\x7f\n\x13CreateWorkerRequest\x12>\n\x06worker\x18\x01 \x01(\x0b2!.ai.h2o.connectors.v1alpha.WorkerB\x03\xe0A\x02R\x06worker\x12(\n\rvalidate_only\x18\x02 \x01(\x08B\x03\xe0A\x01R\x0cvalidateOnly"H\n\x10GetWorkerRequest\x124\n\x04name\x18\x01 \x01(\tB \xe0A\x02\xfaA\x1a\n\x18connectors.h2o.ai/WorkerR\x04name"\xbf\x01\n\x12ListWorkersRequest\x12 \n\tpage_size\x18\x01 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x02 \x01(\tB\x03\xe0A\x01R\tpageToken\x12\x1b\n\x06filter\x18\x03 \x01(\tB\x03\xe0A\x01R\x06filter\x12\x1e\n\x08order_by\x18\x04 \x01(\tB\x03\xe0A\x01R\x07orderBy\x12&\n\x0cworkspace_id\x18\x05 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId"\xa8\x01\n\x13ListWorkersResponse\x12@\n\x07workers\x18\x01 \x03(\x0b2!.ai.h2o.connectors.v1alpha.WorkerB\x03\xe0A\x03R\x07workers\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12"\n\ntotal_size\x18\x03 \x01(\x05B\x03\xe0A\x03R\ttotalSize"\x97\x01\n\x13UpdateWorkerRequest\x12>\n\x06worker\x18\x01 \x01(\x0b2!.ai.h2o.connectors.v1alpha.WorkerB\x03\xe0A\x02R\x06worker\x12@\n\x0bupdate_mask\x18\x02 \x01(\x0b2\x1a.google.protobuf.FieldMaskB\x03\xe0A\x01R\nupdateMask"K\n\x13DeleteWorkerRequest\x124\n\x04name\x18\x01 \x01(\tB \xe0A\x02\xfaA\x1a\n\x18connectors.h2o.ai/WorkerR\x04name2\xbe\x06\n\rWorkerService\x12\xa8\x01\n\x0cCreateWorker\x12..ai.h2o.connectors.v1alpha.CreateWorkerRequest\x1a!.ai.h2o.connectors.v1alpha.Worker"E\xdaA\x06worker\x82\xd3\xe4\x93\x026"1/v1alpha/workspaces/{worker.workspace_id}/workers:\x01*\x12\x92\x01\n\tGetWorker\x12+.ai.h2o.connectors.v1alpha.GetWorkerRequest\x1a!.ai.h2o.connectors.v1alpha.Worker"5\xdaA\x04name\x82\xd3\xe4\x93\x02(\x12&/v1alpha/{name=workspaces/*/workers/*}\x12\xa0\x01\n\x0bListWorkers\x12-.ai.h2o.connectors.v1alpha.ListWorkersRequest\x1a..ai.h2o.connectors.v1alpha.ListWorkersResponse"2\x82\xd3\xe4\x93\x02,\x12*/v1alpha/workspaces/{workspace_id}/workers\x12\xb9\x01\n\x0cUpdateWorker\x12..ai.h2o.connectors.v1alpha.UpdateWorkerRequest\x1a!.ai.h2o.connectors.v1alpha.Worker"V\xdaA\x12worker,update_mask\x82\xd3\xe4\x93\x02;26/v1alpha/{worker.metadata.name=workspaces/*/workers/*}:\x01*\x12\x8d\x01\n\x0cDeleteWorker\x12..ai.h2o.connectors.v1alpha.DeleteWorkerRequest\x1a\x16.google.protobuf.Empty"5\xdaA\x04name\x82\xd3\xe4\x93\x02(*&/v1alpha/{name=workspaces/*/workers/*}B\x88\x01\n\x19ai.h2o.connectors.v1alphaB\x12WorkerServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'worker_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x12WorkerServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CREATEWORKERREQUEST'].fields_by_name['worker']._loaded_options = None
    _globals['_CREATEWORKERREQUEST'].fields_by_name['worker']._serialized_options = b'\xe0A\x02'
    _globals['_CREATEWORKERREQUEST'].fields_by_name['validate_only']._loaded_options = None
    _globals['_CREATEWORKERREQUEST'].fields_by_name['validate_only']._serialized_options = b'\xe0A\x01'
    _globals['_GETWORKERREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_GETWORKERREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1a\n\x18connectors.h2o.ai/Worker'
    _globals['_LISTWORKERSREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTWORKERSREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERSREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTWORKERSREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERSREQUEST'].fields_by_name['filter']._loaded_options = None
    _globals['_LISTWORKERSREQUEST'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERSREQUEST'].fields_by_name['order_by']._loaded_options = None
    _globals['_LISTWORKERSREQUEST'].fields_by_name['order_by']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERSREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_LISTWORKERSREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_LISTWORKERSRESPONSE'].fields_by_name['workers']._loaded_options = None
    _globals['_LISTWORKERSRESPONSE'].fields_by_name['workers']._serialized_options = b'\xe0A\x03'
    _globals['_LISTWORKERSRESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_LISTWORKERSRESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_LISTWORKERSRESPONSE'].fields_by_name['total_size']._loaded_options = None
    _globals['_LISTWORKERSRESPONSE'].fields_by_name['total_size']._serialized_options = b'\xe0A\x03'
    _globals['_UPDATEWORKERREQUEST'].fields_by_name['worker']._loaded_options = None
    _globals['_UPDATEWORKERREQUEST'].fields_by_name['worker']._serialized_options = b'\xe0A\x02'
    _globals['_UPDATEWORKERREQUEST'].fields_by_name['update_mask']._loaded_options = None
    _globals['_UPDATEWORKERREQUEST'].fields_by_name['update_mask']._serialized_options = b'\xe0A\x01'
    _globals['_DELETEWORKERREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_DELETEWORKERREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1a\n\x18connectors.h2o.ai/Worker'
    _globals['_WORKERSERVICE'].methods_by_name['CreateWorker']._loaded_options = None
    _globals['_WORKERSERVICE'].methods_by_name['CreateWorker']._serialized_options = b'\xdaA\x06worker\x82\xd3\xe4\x93\x026"1/v1alpha/workspaces/{worker.workspace_id}/workers:\x01*'
    _globals['_WORKERSERVICE'].methods_by_name['GetWorker']._loaded_options = None
    _globals['_WORKERSERVICE'].methods_by_name['GetWorker']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02(\x12&/v1alpha/{name=workspaces/*/workers/*}'
    _globals['_WORKERSERVICE'].methods_by_name['ListWorkers']._loaded_options = None
    _globals['_WORKERSERVICE'].methods_by_name['ListWorkers']._serialized_options = b'\x82\xd3\xe4\x93\x02,\x12*/v1alpha/workspaces/{workspace_id}/workers'
    _globals['_WORKERSERVICE'].methods_by_name['UpdateWorker']._loaded_options = None
    _globals['_WORKERSERVICE'].methods_by_name['UpdateWorker']._serialized_options = b'\xdaA\x12worker,update_mask\x82\xd3\xe4\x93\x02;26/v1alpha/{worker.metadata.name=workspaces/*/workers/*}:\x01*'
    _globals['_WORKERSERVICE'].methods_by_name['DeleteWorker']._loaded_options = None
    _globals['_WORKERSERVICE'].methods_by_name['DeleteWorker']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02(*&/v1alpha/{name=workspaces/*/workers/*}'
    _globals['_CREATEWORKERREQUEST']._serialized_start = 243
    _globals['_CREATEWORKERREQUEST']._serialized_end = 370
    _globals['_GETWORKERREQUEST']._serialized_start = 372
    _globals['_GETWORKERREQUEST']._serialized_end = 444
    _globals['_LISTWORKERSREQUEST']._serialized_start = 447
    _globals['_LISTWORKERSREQUEST']._serialized_end = 638
    _globals['_LISTWORKERSRESPONSE']._serialized_start = 641
    _globals['_LISTWORKERSRESPONSE']._serialized_end = 809
    _globals['_UPDATEWORKERREQUEST']._serialized_start = 812
    _globals['_UPDATEWORKERREQUEST']._serialized_end = 963
    _globals['_DELETEWORKERREQUEST']._serialized_start = 965
    _globals['_DELETEWORKERREQUEST']._serialized_end = 1040
    _globals['_WORKERSERVICE']._serialized_start = 1043
    _globals['_WORKERSERVICE']._serialized_end = 1873