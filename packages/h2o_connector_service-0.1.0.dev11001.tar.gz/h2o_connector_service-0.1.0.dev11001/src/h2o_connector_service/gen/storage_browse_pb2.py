"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'storage_browse.proto')
_sym_db = _symbol_database.Default()
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.protobuf import timestamp_pb2 as google_dot_protobuf_dot_timestamp__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x14storage_browse.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x1fgoogle/api/field_behavior.proto\x1a\x1fgoogle/protobuf/timestamp.proto"\x8d\x02\n\x0cStorageEntry\x12\x15\n\x03key\x18\x01 \x01(\tB\x03\xe0A\x03R\x03key\x12D\n\x04type\x18\x02 \x01(\x0e2+.ai.h2o.connectors.v1alpha.StorageEntryTypeB\x03\xe0A\x03R\x04type\x12\x17\n\x04size\x18\x03 \x01(\x03B\x03\xe0A\x03R\x04size\x12D\n\rlast_modified\x18\x04 \x01(\x0b2\x1a.google.protobuf.TimestampB\x03\xe0A\x03R\x0clastModified\x12(\n\rstorage_class\x18\x05 \x01(\tB\x03\xe0A\x03R\x0cstorageClass\x12\x17\n\x04etag\x18\x06 \x01(\tB\x03\xe0A\x03R\x04etag*t\n\x10StorageEntryType\x12"\n\x1eSTORAGE_ENTRY_TYPE_UNSPECIFIED\x10\x00\x12\x1d\n\x19STORAGE_ENTRY_TYPE_PREFIX\x10\x01\x12\x1d\n\x19STORAGE_ENTRY_TYPE_OBJECT\x10\x02B\x88\x01\n\x19ai.h2o.connectors.v1alphaB\x12StorageBrowseProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'storage_browse_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x12StorageBrowseProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_STORAGEENTRY'].fields_by_name['key']._loaded_options = None
    _globals['_STORAGEENTRY'].fields_by_name['key']._serialized_options = b'\xe0A\x03'
    _globals['_STORAGEENTRY'].fields_by_name['type']._loaded_options = None
    _globals['_STORAGEENTRY'].fields_by_name['type']._serialized_options = b'\xe0A\x03'
    _globals['_STORAGEENTRY'].fields_by_name['size']._loaded_options = None
    _globals['_STORAGEENTRY'].fields_by_name['size']._serialized_options = b'\xe0A\x03'
    _globals['_STORAGEENTRY'].fields_by_name['last_modified']._loaded_options = None
    _globals['_STORAGEENTRY'].fields_by_name['last_modified']._serialized_options = b'\xe0A\x03'
    _globals['_STORAGEENTRY'].fields_by_name['storage_class']._loaded_options = None
    _globals['_STORAGEENTRY'].fields_by_name['storage_class']._serialized_options = b'\xe0A\x03'
    _globals['_STORAGEENTRY'].fields_by_name['etag']._loaded_options = None
    _globals['_STORAGEENTRY'].fields_by_name['etag']._serialized_options = b'\xe0A\x03'
    _globals['_STORAGEENTRYTYPE']._serialized_start = 389
    _globals['_STORAGEENTRYTYPE']._serialized_end = 505
    _globals['_STORAGEENTRY']._serialized_start = 118
    _globals['_STORAGEENTRY']._serialized_end = 387