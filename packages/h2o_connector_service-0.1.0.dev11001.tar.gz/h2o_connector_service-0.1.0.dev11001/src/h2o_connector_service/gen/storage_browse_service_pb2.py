"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'storage_browse_service.proto')
_sym_db = _symbol_database.Default()
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from . import storage_browse_pb2 as storage__browse__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1cstorage_browse_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x1cgoogle/api/annotations.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x14storage_browse.proto"\xe7\x01\n\x14BrowseStorageRequest\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId\x12\x1b\n\x06prefix\x18\x02 \x01(\tB\x03\xe0A\x01R\x06prefix\x12!\n\tdelimiter\x18\x03 \x01(\tB\x03\xe0A\x01R\tdelimiter\x12 \n\tpage_size\x18\x04 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x05 \x01(\tB\x03\xe0A\x01R\tpageToken"\xb8\x01\n\x15BrowseStorageResponse\x12F\n\x07entries\x18\x01 \x03(\x0b2\'.ai.h2o.connectors.v1alpha.StorageEntryB\x03\xe0A\x03R\x07entries\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12*\n\x0ecurrent_prefix\x18\x03 \x01(\tB\x03\xe0A\x03R\rcurrentPrefix2\xc0\x01\n\x14StorageBrowseService\x12\xa7\x01\n\rBrowseStorage\x12/.ai.h2o.connectors.v1alpha.BrowseStorageRequest\x1a0.ai.h2o.connectors.v1alpha.BrowseStorageResponse"3\x82\xd3\xe4\x93\x02-\x12+/v1alpha/connections/{connection_id}/browseB\x8f\x01\n\x19ai.h2o.connectors.v1alphaB\x19StorageBrowseServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'storage_browse_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x19StorageBrowseServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['prefix']._loaded_options = None
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['prefix']._serialized_options = b'\xe0A\x01'
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['delimiter']._loaded_options = None
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['delimiter']._serialized_options = b'\xe0A\x01'
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_BROWSESTORAGEREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_BROWSESTORAGERESPONSE'].fields_by_name['entries']._loaded_options = None
    _globals['_BROWSESTORAGERESPONSE'].fields_by_name['entries']._serialized_options = b'\xe0A\x03'
    _globals['_BROWSESTORAGERESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_BROWSESTORAGERESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_BROWSESTORAGERESPONSE'].fields_by_name['current_prefix']._loaded_options = None
    _globals['_BROWSESTORAGERESPONSE'].fields_by_name['current_prefix']._serialized_options = b'\xe0A\x03'
    _globals['_STORAGEBROWSESERVICE'].methods_by_name['BrowseStorage']._loaded_options = None
    _globals['_STORAGEBROWSESERVICE'].methods_by_name['BrowseStorage']._serialized_options = b'\x82\xd3\xe4\x93\x02-\x12+/v1alpha/connections/{connection_id}/browse'
    _globals['_BROWSESTORAGEREQUEST']._serialized_start = 172
    _globals['_BROWSESTORAGEREQUEST']._serialized_end = 403
    _globals['_BROWSESTORAGERESPONSE']._serialized_start = 406
    _globals['_BROWSESTORAGERESPONSE']._serialized_end = 590
    _globals['_STORAGEBROWSESERVICE']._serialized_start = 593
    _globals['_STORAGEBROWSESERVICE']._serialized_end = 785