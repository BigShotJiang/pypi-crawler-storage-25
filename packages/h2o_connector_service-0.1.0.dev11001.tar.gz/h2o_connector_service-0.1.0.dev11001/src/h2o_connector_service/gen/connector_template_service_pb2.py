"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'connector_template_service.proto')
_sym_db = _symbol_database.Default()
from . import connector_template_pb2 as connector__template__pb2
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import client_pb2 as google_dot_api_dot_client__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from google.protobuf import field_mask_pb2 as google_dot_protobuf_dot_field__mask__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n connector_template_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x18connector_template.proto\x1a\x1cgoogle/api/annotations.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a google/protobuf/field_mask.proto"\x82\x01\n\x1eCreateConnectorTemplateRequest\x12`\n\x12connector_template\x18\x01 \x01(\x0b2,.ai.h2o.connectors.v1alpha.ConnectorTemplateB\x03\xe0A\x02R\x11connectorTemplate"^\n\x1bGetConnectorTemplateRequest\x12?\n\x04name\x18\x01 \x01(\tB+\xe0A\x02\xfaA%\n#connectors.h2o.ai/ConnectorTemplateR\x04name"\xca\x01\n\x1dListConnectorTemplatesRequest\x12 \n\tpage_size\x18\x01 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x02 \x01(\tB\x03\xe0A\x01R\tpageToken\x12\x1b\n\x06filter\x18\x03 \x01(\tB\x03\xe0A\x01R\x06filter\x12\x1e\n\x08order_by\x18\x04 \x01(\tB\x03\xe0A\x01R\x07orderBy\x12&\n\x0cworkspace_id\x18\x05 \x01(\tB\x03\xe0A\x01R\x0bworkspaceId"\xd5\x01\n\x1eListConnectorTemplatesResponse\x12b\n\x13connector_templates\x18\x01 \x03(\x0b2,.ai.h2o.connectors.v1alpha.ConnectorTemplateB\x03\xe0A\x03R\x12connectorTemplates\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12"\n\ntotal_size\x18\x03 \x01(\x05B\x03\xe0A\x03R\ttotalSize"\xc4\x01\n\x1eUpdateConnectorTemplateRequest\x12`\n\x12connector_template\x18\x01 \x01(\x0b2,.ai.h2o.connectors.v1alpha.ConnectorTemplateB\x03\xe0A\x02R\x11connectorTemplate\x12@\n\x0bupdate_mask\x18\x02 \x01(\x0b2\x1a.google.protobuf.FieldMaskB\x03\xe0A\x01R\nupdateMask"a\n\x1eDeleteConnectorTemplateRequest\x12?\n\x04name\x18\x01 \x01(\tB+\xe0A\x02\xfaA%\n#connectors.h2o.ai/ConnectorTemplateR\x04name2\xdc\x07\n\x18ConnectorTemplateService\x12\xbf\x01\n\x17CreateConnectorTemplate\x129.ai.h2o.connectors.v1alpha.CreateConnectorTemplateRequest\x1a,.ai.h2o.connectors.v1alpha.ConnectorTemplate";\xdaA\x12connector_template\x82\xd3\xe4\x93\x02 "\x1b/v1alpha/connectorTemplates:\x01*\x12\xb1\x01\n\x14GetConnectorTemplate\x126.ai.h2o.connectors.v1alpha.GetConnectorTemplateRequest\x1a,.ai.h2o.connectors.v1alpha.ConnectorTemplate"3\xdaA\x04name\x82\xd3\xe4\x93\x02&\x12$/v1alpha/{name=connectorTemplates/*}\x12\xb2\x01\n\x16ListConnectorTemplates\x128.ai.h2o.connectors.v1alpha.ListConnectorTemplatesRequest\x1a9.ai.h2o.connectors.v1alpha.ListConnectorTemplatesResponse"#\x82\xd3\xe4\x93\x02\x1d\x12\x1b/v1alpha/connectorTemplates\x12\xf0\x01\n\x17UpdateConnectorTemplate\x129.ai.h2o.connectors.v1alpha.UpdateConnectorTemplateRequest\x1a,.ai.h2o.connectors.v1alpha.ConnectorTemplate"l\xdaA\x1econnector_template,update_mask\x82\xd3\xe4\x93\x02E2@/v1alpha/{connector_template.metadata.name=connectorTemplates/*}:\x01*\x12\xa1\x01\n\x17DeleteConnectorTemplate\x129.ai.h2o.connectors.v1alpha.DeleteConnectorTemplateRequest\x1a\x16.google.protobuf.Empty"3\xdaA\x04name\x82\xd3\xe4\x93\x02&*$/v1alpha/{name=connectorTemplates/*}B\x93\x01\n\x19ai.h2o.connectors.v1alphaB\x1dConnectorTemplateServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'connector_template_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x1dConnectorTemplateServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CREATECONNECTORTEMPLATEREQUEST'].fields_by_name['connector_template']._loaded_options = None
    _globals['_CREATECONNECTORTEMPLATEREQUEST'].fields_by_name['connector_template']._serialized_options = b'\xe0A\x02'
    _globals['_GETCONNECTORTEMPLATEREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_GETCONNECTORTEMPLATEREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA%\n#connectors.h2o.ai/ConnectorTemplate'
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['filter']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['order_by']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['order_by']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTORTEMPLATESRESPONSE'].fields_by_name['connector_templates']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESRESPONSE'].fields_by_name['connector_templates']._serialized_options = b'\xe0A\x03'
    _globals['_LISTCONNECTORTEMPLATESRESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESRESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_LISTCONNECTORTEMPLATESRESPONSE'].fields_by_name['total_size']._loaded_options = None
    _globals['_LISTCONNECTORTEMPLATESRESPONSE'].fields_by_name['total_size']._serialized_options = b'\xe0A\x03'
    _globals['_UPDATECONNECTORTEMPLATEREQUEST'].fields_by_name['connector_template']._loaded_options = None
    _globals['_UPDATECONNECTORTEMPLATEREQUEST'].fields_by_name['connector_template']._serialized_options = b'\xe0A\x02'
    _globals['_UPDATECONNECTORTEMPLATEREQUEST'].fields_by_name['update_mask']._loaded_options = None
    _globals['_UPDATECONNECTORTEMPLATEREQUEST'].fields_by_name['update_mask']._serialized_options = b'\xe0A\x01'
    _globals['_DELETECONNECTORTEMPLATEREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_DELETECONNECTORTEMPLATEREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA%\n#connectors.h2o.ai/ConnectorTemplate'
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['CreateConnectorTemplate']._loaded_options = None
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['CreateConnectorTemplate']._serialized_options = b'\xdaA\x12connector_template\x82\xd3\xe4\x93\x02 "\x1b/v1alpha/connectorTemplates:\x01*'
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['GetConnectorTemplate']._loaded_options = None
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['GetConnectorTemplate']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02&\x12$/v1alpha/{name=connectorTemplates/*}'
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['ListConnectorTemplates']._loaded_options = None
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['ListConnectorTemplates']._serialized_options = b'\x82\xd3\xe4\x93\x02\x1d\x12\x1b/v1alpha/connectorTemplates'
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['UpdateConnectorTemplate']._loaded_options = None
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['UpdateConnectorTemplate']._serialized_options = b'\xdaA\x1econnector_template,update_mask\x82\xd3\xe4\x93\x02E2@/v1alpha/{connector_template.metadata.name=connectorTemplates/*}:\x01*'
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['DeleteConnectorTemplate']._loaded_options = None
    _globals['_CONNECTORTEMPLATESERVICE'].methods_by_name['DeleteConnectorTemplate']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02&*$/v1alpha/{name=connectorTemplates/*}'
    _globals['_CREATECONNECTORTEMPLATEREQUEST']._serialized_start = 268
    _globals['_CREATECONNECTORTEMPLATEREQUEST']._serialized_end = 398
    _globals['_GETCONNECTORTEMPLATEREQUEST']._serialized_start = 400
    _globals['_GETCONNECTORTEMPLATEREQUEST']._serialized_end = 494
    _globals['_LISTCONNECTORTEMPLATESREQUEST']._serialized_start = 497
    _globals['_LISTCONNECTORTEMPLATESREQUEST']._serialized_end = 699
    _globals['_LISTCONNECTORTEMPLATESRESPONSE']._serialized_start = 702
    _globals['_LISTCONNECTORTEMPLATESRESPONSE']._serialized_end = 915
    _globals['_UPDATECONNECTORTEMPLATEREQUEST']._serialized_start = 918
    _globals['_UPDATECONNECTORTEMPLATEREQUEST']._serialized_end = 1114
    _globals['_DELETECONNECTORTEMPLATEREQUEST']._serialized_start = 1116
    _globals['_DELETECONNECTORTEMPLATEREQUEST']._serialized_end = 1213
    _globals['_CONNECTORTEMPLATESERVICE']._serialized_start = 1216
    _globals['_CONNECTORTEMPLATESERVICE']._serialized_end = 2204