"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'connection.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import duration_pb2 as google_dot_protobuf_dot_duration__pb2
from google.protobuf import timestamp_pb2 as google_dot_protobuf_dot_timestamp__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x10connection.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1egoogle/protobuf/duration.proto\x1a\x1fgoogle/protobuf/timestamp.proto"\xfe\x04\n\nConnection\x12(\n\rconnection_id\x18\x01 \x01(\tB\x03\xe0A\x03R\x0cconnectionId\x12L\n\x08metadata\x18\x02 \x01(\x0b2+.ai.h2o.connectors.v1alpha.ResourceMetadataB\x03\xe0A\x01R\x08metadata\x12A\n\tconnector\x18\x03 \x01(\tB#\xe0A\x02\xfaA\x1d\n\x1bconnectors.h2o.ai/ConnectorR\tconnector\x128\n\x06worker\x18\x04 \x01(\tB \xe0A\x02\xfaA\x1a\n\x18connectors.h2o.ai/WorkerR\x06worker\x12P\n\nextraction\x18\x05 \x01(\x0b2+.ai.h2o.connectors.v1alpha.ExtractionConfigB\x03\xe0A\x02R\nextraction\x12H\n\x06status\x18\x06 \x01(\x0e2+.ai.h2o.connectors.v1alpha.ConnectionStatusB\x03\xe0A\x03R\x06status\x12^\n\x0estatus_details\x18\x07 \x01(\x0b22.ai.h2o.connectors.v1alpha.ConnectionStatusDetailsB\x03\xe0A\x03R\rstatusDetails\x12&\n\x0cworkspace_id\x18\x08 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId:W\xeaAT\n\x1cconnectors.h2o.ai/Connection\x12\x1bconnections/{connection_id}*\x0bconnections2\nconnection"\xde\x02\n\x10ExtractionConfig\x12\x16\n\x05query\x18\n \x01(\tH\x00R\x05query\x12D\n\x06tables\x18\x0b \x01(\x0b2*.ai.h2o.connectors.v1alpha.TableExtractionH\x00R\x06tables\x12A\n\x05paths\x18\x0c \x01(\x0b2).ai.h2o.connectors.v1alpha.PathExtractionH\x00R\x05paths\x12"\n\nbatch_size\x18\x14 \x01(\x05B\x03\xe0A\x01R\tbatchSize\x12 \n\tmax_units\x18\x15 \x01(\x03B\x03\xe0A\x01R\x08maxUnits\x128\n\x07timeout\x18\x16 \x01(\x0b2\x19.google.protobuf.DurationB\x03\xe0A\x01R\x07timeoutB\x08\n\x06sourceJ\x04\x08\r\x10\x0eJ\x04\x08\x0e\x10\x0fR\x06topicsR\x0bcollections"T\n\x0fTableExtraction\x12A\n\x06tables\x18\x01 \x03(\x0b2$.ai.h2o.connectors.v1alpha.TableSpecB\x03\xe0A\x02R\x06tables"\xb3\x01\n\tTableSpec\x12\x1b\n\x06schema\x18\x01 \x01(\tB\x03\xe0A\x01R\x06schema\x12\x19\n\x05table\x18\x02 \x01(\tB\x03\xe0A\x02R\x05table\x12\x1d\n\x07columns\x18\x03 \x03(\tB\x03\xe0A\x01R\x07columns\x12\x1b\n\x06filter\x18\x04 \x01(\tB\x03\xe0A\x01R\x06filter\x122\n\x12incremental_column\x18\x05 \x01(\tB\x03\xe0A\x01R\x11incrementalColumn"\x90\x01\n\x0ePathExtraction\x12>\n\x05paths\x18\x01 \x03(\x0b2#.ai.h2o.connectors.v1alpha.PathSpecB\x03\xe0A\x02R\x05paths\x12\x1b\n\x06format\x18\x02 \x01(\tB\x03\xe0A\x01R\x06format\x12!\n\trecursive\x18\x03 \x01(\x08B\x03\xe0A\x01R\trecursive"H\n\x08PathSpec\x12\x1d\n\x07pattern\x18\x01 \x01(\tB\x03\xe0A\x02R\x07pattern\x12\x1d\n\x07exclude\x18\x02 \x03(\tB\x03\xe0A\x01R\x07exclude"\xaa\x04\n\x17ConnectionStatusDetails\x12F\n\x05phase\x18\x01 \x01(\x0e2+.ai.h2o.connectors.v1alpha.ConnectionStatusB\x03\xe0A\x03R\x05phase\x12\x1d\n\x07message\x18\x02 \x01(\tB\x03\xe0A\x03R\x07message\x12W\n\x0fworker_endpoint\x18\x03 \x01(\x0b2).ai.h2o.connectors.v1alpha.WorkerEndpointB\x03\xe0A\x03R\x0eworkerEndpoint\x12;\n\x05error\x18\x04 \x01(\x0b2 .ai.h2o.connectors.v1alpha.ErrorB\x03\xe0A\x03R\x05error\x12E\n\x05stats\x18\x05 \x01(\x0b2*.ai.h2o.connectors.v1alpha.ConnectionStatsB\x03\xe0A\x03R\x05stats\x12T\n\ntimestamps\x18\x06 \x01(\x0b2/.ai.h2o.connectors.v1alpha.ConnectionTimestampsB\x03\xe0A\x03R\ntimestamps\x12R\n\nerror_code\x18\x07 \x01(\x0e2..ai.h2o.connectors.v1alpha.ConnectionErrorCodeB\x03\xe0A\x03R\terrorCode\x12!\n\tretryable\x18\x08 \x01(\x08B\x03\xe0A\x03R\tretryable"\xdc\x01\n\x0fConnectionStats\x12,\n\x0funits_processed\x18\x01 \x01(\x03B\x03\xe0A\x03R\x0eunitsProcessed\x12-\n\x10units_per_second\x18\x02 \x01(\x01B\x03\xe0A\x03R\x0eunitsPerSecond\x12$\n\x0bunits_acked\x18\x03 \x01(\x03B\x03\xe0A\x03R\nunitsAcked\x12$\n\x0berror_count\x18\x04 \x01(\x03B\x03\xe0A\x03R\nerrorCount\x12 \n\tunit_type\x18\x05 \x01(\tB\x03\xe0A\x03R\x08unitType"\x94\x02\n\x14ConnectionTimestamps\x12@\n\x0bcreate_time\x18\x01 \x01(\x0b2\x1a.google.protobuf.TimestampB\x03\xe0A\x03R\ncreateTime\x12>\n\nstart_time\x18\x02 \x01(\x0b2\x1a.google.protobuf.TimestampB\x03\xe0A\x03R\tstartTime\x12>\n\nready_time\x18\x03 \x01(\x0b2\x1a.google.protobuf.TimestampB\x03\xe0A\x03R\treadyTime\x12:\n\x08end_time\x18\x04 \x01(\x0b2\x1a.google.protobuf.TimestampB\x03\xe0A\x03R\x07endTimeB\x85\x01\n\x19ai.h2o.connectors.v1alphaB\x0fConnectionProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'connection_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x0fConnectionProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CONNECTION'].fields_by_name['connection_id']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTION'].fields_by_name['metadata']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['metadata']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTION'].fields_by_name['connector']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['connector']._serialized_options = b'\xe0A\x02\xfaA\x1d\n\x1bconnectors.h2o.ai/Connector'
    _globals['_CONNECTION'].fields_by_name['worker']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['worker']._serialized_options = b'\xe0A\x02\xfaA\x1a\n\x18connectors.h2o.ai/Worker'
    _globals['_CONNECTION'].fields_by_name['extraction']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['extraction']._serialized_options = b'\xe0A\x02'
    _globals['_CONNECTION'].fields_by_name['status']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['status']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTION'].fields_by_name['status_details']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['status_details']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTION'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_CONNECTION'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_CONNECTION']._loaded_options = None
    _globals['_CONNECTION']._serialized_options = b'\xeaAT\n\x1cconnectors.h2o.ai/Connection\x12\x1bconnections/{connection_id}*\x0bconnections2\nconnection'
    _globals['_EXTRACTIONCONFIG'].fields_by_name['batch_size']._loaded_options = None
    _globals['_EXTRACTIONCONFIG'].fields_by_name['batch_size']._serialized_options = b'\xe0A\x01'
    _globals['_EXTRACTIONCONFIG'].fields_by_name['max_units']._loaded_options = None
    _globals['_EXTRACTIONCONFIG'].fields_by_name['max_units']._serialized_options = b'\xe0A\x01'
    _globals['_EXTRACTIONCONFIG'].fields_by_name['timeout']._loaded_options = None
    _globals['_EXTRACTIONCONFIG'].fields_by_name['timeout']._serialized_options = b'\xe0A\x01'
    _globals['_TABLEEXTRACTION'].fields_by_name['tables']._loaded_options = None
    _globals['_TABLEEXTRACTION'].fields_by_name['tables']._serialized_options = b'\xe0A\x02'
    _globals['_TABLESPEC'].fields_by_name['schema']._loaded_options = None
    _globals['_TABLESPEC'].fields_by_name['schema']._serialized_options = b'\xe0A\x01'
    _globals['_TABLESPEC'].fields_by_name['table']._loaded_options = None
    _globals['_TABLESPEC'].fields_by_name['table']._serialized_options = b'\xe0A\x02'
    _globals['_TABLESPEC'].fields_by_name['columns']._loaded_options = None
    _globals['_TABLESPEC'].fields_by_name['columns']._serialized_options = b'\xe0A\x01'
    _globals['_TABLESPEC'].fields_by_name['filter']._loaded_options = None
    _globals['_TABLESPEC'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_TABLESPEC'].fields_by_name['incremental_column']._loaded_options = None
    _globals['_TABLESPEC'].fields_by_name['incremental_column']._serialized_options = b'\xe0A\x01'
    _globals['_PATHEXTRACTION'].fields_by_name['paths']._loaded_options = None
    _globals['_PATHEXTRACTION'].fields_by_name['paths']._serialized_options = b'\xe0A\x02'
    _globals['_PATHEXTRACTION'].fields_by_name['format']._loaded_options = None
    _globals['_PATHEXTRACTION'].fields_by_name['format']._serialized_options = b'\xe0A\x01'
    _globals['_PATHEXTRACTION'].fields_by_name['recursive']._loaded_options = None
    _globals['_PATHEXTRACTION'].fields_by_name['recursive']._serialized_options = b'\xe0A\x01'
    _globals['_PATHSPEC'].fields_by_name['pattern']._loaded_options = None
    _globals['_PATHSPEC'].fields_by_name['pattern']._serialized_options = b'\xe0A\x02'
    _globals['_PATHSPEC'].fields_by_name['exclude']._loaded_options = None
    _globals['_PATHSPEC'].fields_by_name['exclude']._serialized_options = b'\xe0A\x01'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['phase']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['phase']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['message']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['message']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['worker_endpoint']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['worker_endpoint']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['error']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['error']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['stats']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['stats']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['timestamps']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['timestamps']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['error_code']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['error_code']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['retryable']._loaded_options = None
    _globals['_CONNECTIONSTATUSDETAILS'].fields_by_name['retryable']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATS'].fields_by_name['units_processed']._loaded_options = None
    _globals['_CONNECTIONSTATS'].fields_by_name['units_processed']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATS'].fields_by_name['units_per_second']._loaded_options = None
    _globals['_CONNECTIONSTATS'].fields_by_name['units_per_second']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATS'].fields_by_name['units_acked']._loaded_options = None
    _globals['_CONNECTIONSTATS'].fields_by_name['units_acked']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATS'].fields_by_name['error_count']._loaded_options = None
    _globals['_CONNECTIONSTATS'].fields_by_name['error_count']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONSTATS'].fields_by_name['unit_type']._loaded_options = None
    _globals['_CONNECTIONSTATS'].fields_by_name['unit_type']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['create_time']._loaded_options = None
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['create_time']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['start_time']._loaded_options = None
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['start_time']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['ready_time']._loaded_options = None
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['ready_time']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['end_time']._loaded_options = None
    _globals['_CONNECTIONTIMESTAMPS'].fields_by_name['end_time']._serialized_options = b'\xe0A\x03'
    _globals['_CONNECTION']._serialized_start = 187
    _globals['_CONNECTION']._serialized_end = 825
    _globals['_EXTRACTIONCONFIG']._serialized_start = 828
    _globals['_EXTRACTIONCONFIG']._serialized_end = 1178
    _globals['_TABLEEXTRACTION']._serialized_start = 1180
    _globals['_TABLEEXTRACTION']._serialized_end = 1264
    _globals['_TABLESPEC']._serialized_start = 1267
    _globals['_TABLESPEC']._serialized_end = 1446
    _globals['_PATHEXTRACTION']._serialized_start = 1449
    _globals['_PATHEXTRACTION']._serialized_end = 1593
    _globals['_PATHSPEC']._serialized_start = 1595
    _globals['_PATHSPEC']._serialized_end = 1667
    _globals['_CONNECTIONSTATUSDETAILS']._serialized_start = 1670
    _globals['_CONNECTIONSTATUSDETAILS']._serialized_end = 2224
    _globals['_CONNECTIONSTATS']._serialized_start = 2227
    _globals['_CONNECTIONSTATS']._serialized_end = 2447
    _globals['_CONNECTIONTIMESTAMPS']._serialized_start = 2450
    _globals['_CONNECTIONTIMESTAMPS']._serialized_end = 2726