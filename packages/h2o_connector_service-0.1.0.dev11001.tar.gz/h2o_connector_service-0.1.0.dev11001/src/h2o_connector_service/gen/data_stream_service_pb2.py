"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'data_stream_service.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from . import data_pb2 as data__pb2
from google.api import client_pb2 as google_dot_api_dot_client__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x19data_stream_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\ndata.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto"\xe0\x01\n\x11StreamDataRequest\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId\x12U\n\x10preferred_format\x18\x02 \x01(\x0e2%.ai.h2o.connectors.v1alpha.DataFormatB\x03\xe0A\x01R\x0fpreferredFormat\x12)\n\x0emax_batch_size\x18\x03 \x01(\x05B\x03\xe0A\x01R\x0cmaxBatchSize"\x8c\x01\n\x1eStreamDataBidirectionalRequest\x12S\n\rstart_request\x18\x01 \x01(\x0b2,.ai.h2o.connectors.v1alpha.StreamDataRequestH\x00R\x0cstartRequestB\t\n\x07messageJ\x04\x08\x02\x10\x03J\x04\x08\x03\x10\x04"\xf3\x01\n\x1fStreamDataBidirectionalResponse\x12<\n\x05batch\x18\x01 \x01(\x0b2$.ai.h2o.connectors.v1alpha.DataBatchH\x00R\x05batch\x128\n\x05error\x18\x03 \x01(\x0b2 .ai.h2o.connectors.v1alpha.ErrorH\x00R\x05error\x12G\n\x08complete\x18\x04 \x01(\x0b2).ai.h2o.connectors.v1alpha.StreamCompleteH\x00R\x08completeB\t\n\x07messageJ\x04\x08\x02\x10\x03"\xa3\x01\n\x0eStreamComplete\x12(\n\rtotal_records\x18\x01 \x01(\x03B\x03\xe0A\x03R\x0ctotalRecords\x12$\n\x0btotal_bytes\x18\x02 \x01(\x03B\x03\xe0A\x03R\ntotalBytes\x12\x1b\n\x06reason\x18\x03 \x01(\tB\x03\xe0A\x03R\x06reason\x12$\n\x0btotal_files\x18\x04 \x01(\x03B\x03\xe0A\x03R\ntotalFiles"]\n\x10GetSchemaRequest\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId2\x81\x03\n\x11DataStreamService\x12d\n\nStreamData\x12,.ai.h2o.connectors.v1alpha.StreamDataRequest\x1a$.ai.h2o.connectors.v1alpha.DataBatch"\x000\x01\x12\x96\x01\n\x17StreamDataBidirectional\x129.ai.h2o.connectors.v1alpha.StreamDataBidirectionalRequest\x1a:.ai.h2o.connectors.v1alpha.StreamDataBidirectionalResponse"\x00(\x010\x01\x12m\n\tGetSchema\x12+.ai.h2o.connectors.v1alpha.GetSchemaRequest\x1a!.ai.h2o.connectors.v1alpha.Schema"\x10\xdaA\rconnection_idB\x8c\x01\n\x19ai.h2o.connectors.v1alphaB\x16DataStreamServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'data_stream_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x16DataStreamServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_STREAMDATAREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_STREAMDATAREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_STREAMDATAREQUEST'].fields_by_name['preferred_format']._loaded_options = None
    _globals['_STREAMDATAREQUEST'].fields_by_name['preferred_format']._serialized_options = b'\xe0A\x01'
    _globals['_STREAMDATAREQUEST'].fields_by_name['max_batch_size']._loaded_options = None
    _globals['_STREAMDATAREQUEST'].fields_by_name['max_batch_size']._serialized_options = b'\xe0A\x01'
    _globals['_STREAMCOMPLETE'].fields_by_name['total_records']._loaded_options = None
    _globals['_STREAMCOMPLETE'].fields_by_name['total_records']._serialized_options = b'\xe0A\x03'
    _globals['_STREAMCOMPLETE'].fields_by_name['total_bytes']._loaded_options = None
    _globals['_STREAMCOMPLETE'].fields_by_name['total_bytes']._serialized_options = b'\xe0A\x03'
    _globals['_STREAMCOMPLETE'].fields_by_name['reason']._loaded_options = None
    _globals['_STREAMCOMPLETE'].fields_by_name['reason']._serialized_options = b'\xe0A\x03'
    _globals['_STREAMCOMPLETE'].fields_by_name['total_files']._loaded_options = None
    _globals['_STREAMCOMPLETE'].fields_by_name['total_files']._serialized_options = b'\xe0A\x03'
    _globals['_GETSCHEMAREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_GETSCHEMAREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_DATASTREAMSERVICE'].methods_by_name['GetSchema']._loaded_options = None
    _globals['_DATASTREAMSERVICE'].methods_by_name['GetSchema']._serialized_options = b'\xdaA\rconnection_id'
    _globals['_STREAMDATAREQUEST']._serialized_start = 168
    _globals['_STREAMDATAREQUEST']._serialized_end = 392
    _globals['_STREAMDATABIDIRECTIONALREQUEST']._serialized_start = 395
    _globals['_STREAMDATABIDIRECTIONALREQUEST']._serialized_end = 535
    _globals['_STREAMDATABIDIRECTIONALRESPONSE']._serialized_start = 538
    _globals['_STREAMDATABIDIRECTIONALRESPONSE']._serialized_end = 781
    _globals['_STREAMCOMPLETE']._serialized_start = 784
    _globals['_STREAMCOMPLETE']._serialized_end = 947
    _globals['_GETSCHEMAREQUEST']._serialized_start = 949
    _globals['_GETSCHEMAREQUEST']._serialized_end = 1042
    _globals['_DATASTREAMSERVICE']._serialized_start = 1045
    _globals['_DATASTREAMSERVICE']._serialized_end = 1430