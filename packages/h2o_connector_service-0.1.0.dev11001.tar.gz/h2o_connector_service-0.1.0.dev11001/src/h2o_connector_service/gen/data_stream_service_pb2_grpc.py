"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import data_pb2 as data__pb2
from . import data_stream_service_pb2 as data__stream__service__pb2

class DataStreamServiceStub(object):
    """=============================================================================
    Data Stream Service
    =============================================================================

    DataStreamService provides APIs for streaming data from workers to clients.
    After a connection is created and ready, clients connect to this service
    (via the worker endpoint) to pull data.

    Worker-direct gRPC only — not proxied through api-server.
    No HTTP/REST bindings are provided; these RPCs are called directly on the
    worker pod endpoint returned in ConnectionStatusDetails.worker_endpoint.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.StreamData = channel.unary_stream('/ai.h2o.connectors.v1alpha.DataStreamService/StreamData', request_serializer=data__stream__service__pb2.StreamDataRequest.SerializeToString, response_deserializer=data__pb2.DataBatch.FromString, _registered_method=True)
        self.StreamDataBidirectional = channel.stream_stream('/ai.h2o.connectors.v1alpha.DataStreamService/StreamDataBidirectional', request_serializer=data__stream__service__pb2.StreamDataBidirectionalRequest.SerializeToString, response_deserializer=data__stream__service__pb2.StreamDataBidirectionalResponse.FromString, _registered_method=True)
        self.GetSchema = channel.unary_unary('/ai.h2o.connectors.v1alpha.DataStreamService/GetSchema', request_serializer=data__stream__service__pb2.GetSchemaRequest.SerializeToString, response_deserializer=data__pb2.Schema.FromString, _registered_method=True)

class DataStreamServiceServicer(object):
    """=============================================================================
    Data Stream Service
    =============================================================================

    DataStreamService provides APIs for streaming data from workers to clients.
    After a connection is created and ready, clients connect to this service
    (via the worker endpoint) to pull data.

    Worker-direct gRPC only — not proxied through api-server.
    No HTTP/REST bindings are provided; these RPCs are called directly on the
    worker pod endpoint returned in ConnectionStatusDetails.worker_endpoint.
    """

    def StreamData(self, request, context):
        """Streams data batches from the worker to the client.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def StreamDataBidirectional(self, request_iterator, context):
        """Bidirectional streaming for data with inline acknowledgments.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetSchema(self, request, context):
        """Gets the schema for the data being streamed.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_DataStreamServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'StreamData': grpc.unary_stream_rpc_method_handler(servicer.StreamData, request_deserializer=data__stream__service__pb2.StreamDataRequest.FromString, response_serializer=data__pb2.DataBatch.SerializeToString), 'StreamDataBidirectional': grpc.stream_stream_rpc_method_handler(servicer.StreamDataBidirectional, request_deserializer=data__stream__service__pb2.StreamDataBidirectionalRequest.FromString, response_serializer=data__stream__service__pb2.StreamDataBidirectionalResponse.SerializeToString), 'GetSchema': grpc.unary_unary_rpc_method_handler(servicer.GetSchema, request_deserializer=data__stream__service__pb2.GetSchemaRequest.FromString, response_serializer=data__pb2.Schema.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.DataStreamService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.DataStreamService', rpc_method_handlers)

class DataStreamService(object):
    """=============================================================================
    Data Stream Service
    =============================================================================

    DataStreamService provides APIs for streaming data from workers to clients.
    After a connection is created and ready, clients connect to this service
    (via the worker endpoint) to pull data.

    Worker-direct gRPC only — not proxied through api-server.
    No HTTP/REST bindings are provided; these RPCs are called directly on the
    worker pod endpoint returned in ConnectionStatusDetails.worker_endpoint.
    """

    @staticmethod
    def StreamData(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_stream(request, target, '/ai.h2o.connectors.v1alpha.DataStreamService/StreamData', data__stream__service__pb2.StreamDataRequest.SerializeToString, data__pb2.DataBatch.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def StreamDataBidirectional(request_iterator, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.stream_stream(request_iterator, target, '/ai.h2o.connectors.v1alpha.DataStreamService/StreamDataBidirectional', data__stream__service__pb2.StreamDataBidirectionalRequest.SerializeToString, data__stream__service__pb2.StreamDataBidirectionalResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetSchema(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.DataStreamService/GetSchema', data__stream__service__pb2.GetSchemaRequest.SerializeToString, data__pb2.Schema.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)