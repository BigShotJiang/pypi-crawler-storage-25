"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'worker_image_service.proto')
_sym_db = _symbol_database.Default()
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import client_pb2 as google_dot_api_dot_client__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from google.protobuf import field_mask_pb2 as google_dot_protobuf_dot_field__mask__pb2
from . import worker_image_pb2 as worker__image__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x1aworker_image_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x1cgoogle/api/annotations.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a google/protobuf/field_mask.proto\x1a\x12worker_image.proto"j\n\x18CreateWorkerImageRequest\x12N\n\x0cworker_image\x18\x01 \x01(\x0b2&.ai.h2o.connectors.v1alpha.WorkerImageB\x03\xe0A\x02R\x0bworkerImage"R\n\x15GetWorkerImageRequest\x129\n\x04name\x18\x01 \x01(\tB%\xe0A\x02\xfaA\x1f\n\x1dconnectors.h2o.ai/WorkerImageR\x04name"\x9c\x01\n\x17ListWorkerImagesRequest\x12 \n\tpage_size\x18\x01 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x02 \x01(\tB\x03\xe0A\x01R\tpageToken\x12\x1b\n\x06filter\x18\x03 \x01(\tB\x03\xe0A\x01R\x06filter\x12\x1e\n\x08order_by\x18\x04 \x01(\tB\x03\xe0A\x01R\x07orderBy"\xbd\x01\n\x18ListWorkerImagesResponse\x12P\n\rworker_images\x18\x01 \x03(\x0b2&.ai.h2o.connectors.v1alpha.WorkerImageB\x03\xe0A\x03R\x0cworkerImages\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12"\n\ntotal_size\x18\x03 \x01(\x05B\x03\xe0A\x03R\ttotalSize"\xac\x01\n\x18UpdateWorkerImageRequest\x12N\n\x0cworker_image\x18\x01 \x01(\x0b2&.ai.h2o.connectors.v1alpha.WorkerImageB\x03\xe0A\x02R\x0bworkerImage\x12@\n\x0bupdate_mask\x18\x02 \x01(\x0b2\x1a.google.protobuf.FieldMaskB\x03\xe0A\x01R\nupdateMask"U\n\x18DeleteWorkerImageRequest\x129\n\x04name\x18\x01 \x01(\tB%\xe0A\x02\xfaA\x1f\n\x1dconnectors.h2o.ai/WorkerImageR\x04name2\xd2\x06\n\x12WorkerImageService\x12\xa1\x01\n\x11CreateWorkerImage\x123.ai.h2o.connectors.v1alpha.CreateWorkerImageRequest\x1a&.ai.h2o.connectors.v1alpha.WorkerImage"/\xdaA\x0cworker_image\x82\xd3\xe4\x93\x02\x1a"\x15/v1alpha/workerImages:\x01*\x12\x99\x01\n\x0eGetWorkerImage\x120.ai.h2o.connectors.v1alpha.GetWorkerImageRequest\x1a&.ai.h2o.connectors.v1alpha.WorkerImage"-\xdaA\x04name\x82\xd3\xe4\x93\x02 \x12\x1e/v1alpha/{name=workerImages/*}\x12\x9a\x01\n\x10ListWorkerImages\x122.ai.h2o.connectors.v1alpha.ListWorkerImagesRequest\x1a3.ai.h2o.connectors.v1alpha.ListWorkerImagesResponse"\x1d\x82\xd3\xe4\x93\x02\x17\x12\x15/v1alpha/workerImages\x12\xcc\x01\n\x11UpdateWorkerImage\x123.ai.h2o.connectors.v1alpha.UpdateWorkerImageRequest\x1a&.ai.h2o.connectors.v1alpha.WorkerImage"Z\xdaA\x18worker_image,update_mask\x82\xd3\xe4\x93\x02924/v1alpha/{worker_image.metadata.name=workerImages/*}:\x01*\x12\x8f\x01\n\x11DeleteWorkerImage\x123.ai.h2o.connectors.v1alpha.DeleteWorkerImageRequest\x1a\x16.google.protobuf.Empty"-\xdaA\x04name\x82\xd3\xe4\x93\x02 *\x1e/v1alpha/{name=workerImages/*}B\x8d\x01\n\x19ai.h2o.connectors.v1alphaB\x17WorkerImageServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'worker_image_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x17WorkerImageServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CREATEWORKERIMAGEREQUEST'].fields_by_name['worker_image']._loaded_options = None
    _globals['_CREATEWORKERIMAGEREQUEST'].fields_by_name['worker_image']._serialized_options = b'\xe0A\x02'
    _globals['_GETWORKERIMAGEREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_GETWORKERIMAGEREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1f\n\x1dconnectors.h2o.ai/WorkerImage'
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['filter']._loaded_options = None
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['order_by']._loaded_options = None
    _globals['_LISTWORKERIMAGESREQUEST'].fields_by_name['order_by']._serialized_options = b'\xe0A\x01'
    _globals['_LISTWORKERIMAGESRESPONSE'].fields_by_name['worker_images']._loaded_options = None
    _globals['_LISTWORKERIMAGESRESPONSE'].fields_by_name['worker_images']._serialized_options = b'\xe0A\x03'
    _globals['_LISTWORKERIMAGESRESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_LISTWORKERIMAGESRESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_LISTWORKERIMAGESRESPONSE'].fields_by_name['total_size']._loaded_options = None
    _globals['_LISTWORKERIMAGESRESPONSE'].fields_by_name['total_size']._serialized_options = b'\xe0A\x03'
    _globals['_UPDATEWORKERIMAGEREQUEST'].fields_by_name['worker_image']._loaded_options = None
    _globals['_UPDATEWORKERIMAGEREQUEST'].fields_by_name['worker_image']._serialized_options = b'\xe0A\x02'
    _globals['_UPDATEWORKERIMAGEREQUEST'].fields_by_name['update_mask']._loaded_options = None
    _globals['_UPDATEWORKERIMAGEREQUEST'].fields_by_name['update_mask']._serialized_options = b'\xe0A\x01'
    _globals['_DELETEWORKERIMAGEREQUEST'].fields_by_name['name']._loaded_options = None
    _globals['_DELETEWORKERIMAGEREQUEST'].fields_by_name['name']._serialized_options = b'\xe0A\x02\xfaA\x1f\n\x1dconnectors.h2o.ai/WorkerImage'
    _globals['_WORKERIMAGESERVICE'].methods_by_name['CreateWorkerImage']._loaded_options = None
    _globals['_WORKERIMAGESERVICE'].methods_by_name['CreateWorkerImage']._serialized_options = b'\xdaA\x0cworker_image\x82\xd3\xe4\x93\x02\x1a"\x15/v1alpha/workerImages:\x01*'
    _globals['_WORKERIMAGESERVICE'].methods_by_name['GetWorkerImage']._loaded_options = None
    _globals['_WORKERIMAGESERVICE'].methods_by_name['GetWorkerImage']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02 \x12\x1e/v1alpha/{name=workerImages/*}'
    _globals['_WORKERIMAGESERVICE'].methods_by_name['ListWorkerImages']._loaded_options = None
    _globals['_WORKERIMAGESERVICE'].methods_by_name['ListWorkerImages']._serialized_options = b'\x82\xd3\xe4\x93\x02\x17\x12\x15/v1alpha/workerImages'
    _globals['_WORKERIMAGESERVICE'].methods_by_name['UpdateWorkerImage']._loaded_options = None
    _globals['_WORKERIMAGESERVICE'].methods_by_name['UpdateWorkerImage']._serialized_options = b'\xdaA\x18worker_image,update_mask\x82\xd3\xe4\x93\x02924/v1alpha/{worker_image.metadata.name=workerImages/*}:\x01*'
    _globals['_WORKERIMAGESERVICE'].methods_by_name['DeleteWorkerImage']._loaded_options = None
    _globals['_WORKERIMAGESERVICE'].methods_by_name['DeleteWorkerImage']._serialized_options = b'\xdaA\x04name\x82\xd3\xe4\x93\x02 *\x1e/v1alpha/{name=workerImages/*}'
    _globals['_CREATEWORKERIMAGEREQUEST']._serialized_start = 255
    _globals['_CREATEWORKERIMAGEREQUEST']._serialized_end = 361
    _globals['_GETWORKERIMAGEREQUEST']._serialized_start = 363
    _globals['_GETWORKERIMAGEREQUEST']._serialized_end = 445
    _globals['_LISTWORKERIMAGESREQUEST']._serialized_start = 448
    _globals['_LISTWORKERIMAGESREQUEST']._serialized_end = 604
    _globals['_LISTWORKERIMAGESRESPONSE']._serialized_start = 607
    _globals['_LISTWORKERIMAGESRESPONSE']._serialized_end = 796
    _globals['_UPDATEWORKERIMAGEREQUEST']._serialized_start = 799
    _globals['_UPDATEWORKERIMAGEREQUEST']._serialized_end = 971
    _globals['_DELETEWORKERIMAGEREQUEST']._serialized_start = 973
    _globals['_DELETEWORKERIMAGEREQUEST']._serialized_end = 1058
    _globals['_WORKERIMAGESERVICE']._serialized_start = 1061
    _globals['_WORKERIMAGESERVICE']._serialized_end = 1911