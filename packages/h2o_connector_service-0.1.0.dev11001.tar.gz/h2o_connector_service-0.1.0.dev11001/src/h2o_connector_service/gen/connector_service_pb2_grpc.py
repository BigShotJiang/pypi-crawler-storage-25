"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import connector_pb2 as connector__pb2
from . import connector_service_pb2 as connector__service__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2

class ConnectorServiceStub(object):
    """=============================================================================
    Connector Service
    =============================================================================

    ConnectorService manages connectors.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CreateConnector = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorService/CreateConnector', request_serializer=connector__service__pb2.CreateConnectorRequest.SerializeToString, response_deserializer=connector__pb2.Connector.FromString, _registered_method=True)
        self.GetConnector = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorService/GetConnector', request_serializer=connector__service__pb2.GetConnectorRequest.SerializeToString, response_deserializer=connector__pb2.Connector.FromString, _registered_method=True)
        self.ListConnectors = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorService/ListConnectors', request_serializer=connector__service__pb2.ListConnectorsRequest.SerializeToString, response_deserializer=connector__service__pb2.ListConnectorsResponse.FromString, _registered_method=True)
        self.UpdateConnector = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorService/UpdateConnector', request_serializer=connector__service__pb2.UpdateConnectorRequest.SerializeToString, response_deserializer=connector__pb2.Connector.FromString, _registered_method=True)
        self.DeleteConnector = channel.unary_unary('/ai.h2o.connectors.v1alpha.ConnectorService/DeleteConnector', request_serializer=connector__service__pb2.DeleteConnectorRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString, _registered_method=True)

class ConnectorServiceServicer(object):
    """=============================================================================
    Connector Service
    =============================================================================

    ConnectorService manages connectors.
    """

    def CreateConnector(self, request, context):
        """Creates a new connector.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetConnector(self, request, context):
        """Gets a connector by name.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListConnectors(self, request, context):
        """Lists connectors.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def UpdateConnector(self, request, context):
        """Updates a connector.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteConnector(self, request, context):
        """Deletes a connector.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_ConnectorServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'CreateConnector': grpc.unary_unary_rpc_method_handler(servicer.CreateConnector, request_deserializer=connector__service__pb2.CreateConnectorRequest.FromString, response_serializer=connector__pb2.Connector.SerializeToString), 'GetConnector': grpc.unary_unary_rpc_method_handler(servicer.GetConnector, request_deserializer=connector__service__pb2.GetConnectorRequest.FromString, response_serializer=connector__pb2.Connector.SerializeToString), 'ListConnectors': grpc.unary_unary_rpc_method_handler(servicer.ListConnectors, request_deserializer=connector__service__pb2.ListConnectorsRequest.FromString, response_serializer=connector__service__pb2.ListConnectorsResponse.SerializeToString), 'UpdateConnector': grpc.unary_unary_rpc_method_handler(servicer.UpdateConnector, request_deserializer=connector__service__pb2.UpdateConnectorRequest.FromString, response_serializer=connector__pb2.Connector.SerializeToString), 'DeleteConnector': grpc.unary_unary_rpc_method_handler(servicer.DeleteConnector, request_deserializer=connector__service__pb2.DeleteConnectorRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.ConnectorService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.ConnectorService', rpc_method_handlers)

class ConnectorService(object):
    """=============================================================================
    Connector Service
    =============================================================================

    ConnectorService manages connectors.
    """

    @staticmethod
    def CreateConnector(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorService/CreateConnector', connector__service__pb2.CreateConnectorRequest.SerializeToString, connector__pb2.Connector.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetConnector(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorService/GetConnector', connector__service__pb2.GetConnectorRequest.SerializeToString, connector__pb2.Connector.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ListConnectors(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorService/ListConnectors', connector__service__pb2.ListConnectorsRequest.SerializeToString, connector__service__pb2.ListConnectorsResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def UpdateConnector(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorService/UpdateConnector', connector__service__pb2.UpdateConnectorRequest.SerializeToString, connector__pb2.Connector.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def DeleteConnector(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.ConnectorService/DeleteConnector', connector__service__pb2.DeleteConnectorRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)