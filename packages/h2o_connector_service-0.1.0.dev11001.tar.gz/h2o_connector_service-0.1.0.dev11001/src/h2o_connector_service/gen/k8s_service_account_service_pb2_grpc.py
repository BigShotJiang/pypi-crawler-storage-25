"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from . import k8s_service_account_service_pb2 as k8s__service__account__service__pb2

class K8sServiceAccountServiceStub(object):
    """=============================================================================
    K8s ServiceAccount Service
    =============================================================================

    K8sServiceAccountService manages Kubernetes ServiceAccounts.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CreateK8sServiceAccount = channel.unary_unary('/ai.h2o.connectors.v1alpha.K8sServiceAccountService/CreateK8sServiceAccount', request_serializer=k8s__service__account__service__pb2.CreateK8sServiceAccountRequest.SerializeToString, response_deserializer=k8s__service__account__service__pb2.K8sServiceAccount.FromString, _registered_method=True)
        self.DeleteK8sServiceAccount = channel.unary_unary('/ai.h2o.connectors.v1alpha.K8sServiceAccountService/DeleteK8sServiceAccount', request_serializer=k8s__service__account__service__pb2.DeleteK8sServiceAccountRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString, _registered_method=True)

class K8sServiceAccountServiceServicer(object):
    """=============================================================================
    K8s ServiceAccount Service
    =============================================================================

    K8sServiceAccountService manages Kubernetes ServiceAccounts.
    """

    def CreateK8sServiceAccount(self, request, context):
        """Creates a new Kubernetes ServiceAccount in the specified namespace.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteK8sServiceAccount(self, request, context):
        """Deletes a Kubernetes ServiceAccount from the specified namespace.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_K8sServiceAccountServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'CreateK8sServiceAccount': grpc.unary_unary_rpc_method_handler(servicer.CreateK8sServiceAccount, request_deserializer=k8s__service__account__service__pb2.CreateK8sServiceAccountRequest.FromString, response_serializer=k8s__service__account__service__pb2.K8sServiceAccount.SerializeToString), 'DeleteK8sServiceAccount': grpc.unary_unary_rpc_method_handler(servicer.DeleteK8sServiceAccount, request_deserializer=k8s__service__account__service__pb2.DeleteK8sServiceAccountRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.K8sServiceAccountService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.K8sServiceAccountService', rpc_method_handlers)

class K8sServiceAccountService(object):
    """=============================================================================
    K8s ServiceAccount Service
    =============================================================================

    K8sServiceAccountService manages Kubernetes ServiceAccounts.
    """

    @staticmethod
    def CreateK8sServiceAccount(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.K8sServiceAccountService/CreateK8sServiceAccount', k8s__service__account__service__pb2.CreateK8sServiceAccountRequest.SerializeToString, k8s__service__account__service__pb2.K8sServiceAccount.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def DeleteK8sServiceAccount(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.K8sServiceAccountService/DeleteK8sServiceAccount', k8s__service__account__service__pb2.DeleteK8sServiceAccountRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)