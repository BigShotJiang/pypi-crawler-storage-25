"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'worker.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import duration_pb2 as google_dot_protobuf_dot_duration__pb2
from . import worker_image_pb2 as worker__image__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0cworker.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1egoogle/protobuf/duration.proto\x1a\x12worker_image.proto"\xd5\x04\n\x06Worker\x12L\n\x08metadata\x18\x01 \x01(\x0b2+.ai.h2o.connectors.v1alpha.ResourceMetadataB\x03\xe0A\x02R\x08metadata\x12Q\n\x0fworker_template\x18\x02 \x01(\tB(\xe0A\x01\xfaA"\n connectors.h2o.ai/WorkerTemplateR\x0eworkerTemplate\x12A\n\x05image\x18\x03 \x01(\x0b2&.ai.h2o.connectors.v1alpha.WorkerImageB\x03\xe0A\x01R\x05image\x12%\n\x0bconcurrency\x18\x04 \x01(\x05B\x03\xe0A\x01R\x0bconcurrency\x12H\n\x10max_run_duration\x18\x05 \x01(\x0b2\x19.google.protobuf.DurationB\x03\xe0A\x01R\x0emaxRunDuration\x12R\n\tresources\x18\x06 \x01(\x0b2/.ai.h2o.connectors.v1alpha.ResourceRequirementsB\x03\xe0A\x01R\tresources\x128\n\x16pod_template_spec_yaml\x18\x07 \x01(\tB\x03\xe0A\x01R\x13podTemplateSpecYaml\x12&\n\x0cworkspace_id\x18\x08 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId:@\xeaA=\n\x18connectors.h2o.ai/Worker\x12\x10workers/{worker}*\x07workers2\x06workerB\x81\x01\n\x19ai.h2o.connectors.v1alphaB\x0bWorkerProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'worker_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x0bWorkerProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_WORKER'].fields_by_name['metadata']._loaded_options = None
    _globals['_WORKER'].fields_by_name['metadata']._serialized_options = b'\xe0A\x02'
    _globals['_WORKER'].fields_by_name['worker_template']._loaded_options = None
    _globals['_WORKER'].fields_by_name['worker_template']._serialized_options = b'\xe0A\x01\xfaA"\n connectors.h2o.ai/WorkerTemplate'
    _globals['_WORKER'].fields_by_name['image']._loaded_options = None
    _globals['_WORKER'].fields_by_name['image']._serialized_options = b'\xe0A\x01'
    _globals['_WORKER'].fields_by_name['concurrency']._loaded_options = None
    _globals['_WORKER'].fields_by_name['concurrency']._serialized_options = b'\xe0A\x01'
    _globals['_WORKER'].fields_by_name['max_run_duration']._loaded_options = None
    _globals['_WORKER'].fields_by_name['max_run_duration']._serialized_options = b'\xe0A\x01'
    _globals['_WORKER'].fields_by_name['resources']._loaded_options = None
    _globals['_WORKER'].fields_by_name['resources']._serialized_options = b'\xe0A\x01'
    _globals['_WORKER'].fields_by_name['pod_template_spec_yaml']._loaded_options = None
    _globals['_WORKER'].fields_by_name['pod_template_spec_yaml']._serialized_options = b'\xe0A\x01'
    _globals['_WORKER'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_WORKER'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_WORKER']._loaded_options = None
    _globals['_WORKER']._serialized_options = b'\xeaA=\n\x18connectors.h2o.ai/Worker\x12\x10workers/{worker}*\x07workers2\x06worker'
    _globals['_WORKER']._serialized_start = 170
    _globals['_WORKER']._serialized_end = 767