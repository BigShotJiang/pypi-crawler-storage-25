"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'worker_template.proto')
_sym_db = _symbol_database.Default()
from . import common_pb2 as common__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import duration_pb2 as google_dot_protobuf_dot_duration__pb2
from . import worker_image_pb2 as worker__image__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x15worker_template.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x0ccommon.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1egoogle/protobuf/duration.proto\x1a\x12worker_image.proto"\xd8\x07\n\x0eWorkerTemplate\x12L\n\x08metadata\x18\x01 \x01(\x0b2+.ai.h2o.connectors.v1alpha.ResourceMetadataB\x03\xe0A\x02R\x08metadata\x12\x19\n\x05image\x18\x02 \x01(\tB\x03\xe0A\x02R\x05image\x12P\n\x0bpull_policy\x18\x03 \x01(\x0e2*.ai.h2o.connectors.v1alpha.ImagePullPolicyB\x03\xe0A\x01R\npullPolicy\x12B\n\x1bsupported_data_source_types\x18\x04 \x03(\tB\x03\xe0A\x01R\x18supportedDataSourceTypes\x12\x1d\n\x07version\x18\x05 \x01(\tB\x03\xe0A\x03R\x07version\x12a\n\x11default_resources\x18\x06 \x01(\x0b2/.ai.h2o.connectors.v1alpha.ResourceRequirementsB\x03\xe0A\x01R\x10defaultResources\x124\n\x13default_concurrency\x18\x07 \x01(\x05B\x03\xe0A\x01R\x12defaultConcurrency\x12W\n\x18default_max_run_duration\x18\x08 \x01(\x0b2\x19.google.protobuf.DurationB\x03\xe0A\x01R\x15defaultMaxRunDuration\x12G\n\x1edefault_pod_template_spec_yaml\x18\t \x01(\tB\x03\xe0A\x01R\x1adefaultPodTemplateSpecYaml\x12p\n\x18workspace_access_control\x18\n \x01(\x0b21.ai.h2o.connectors.v1alpha.WorkspaceAccessControlB\x03\xe0A\x01R\x16workspaceAccessControl\x12\x1d\n\x07enabled\x18\x0b \x01(\x08B\x03\xe0A\x01R\x07enabled\x122\n\x12overridable_fields\x18\x0c \x03(\tB\x03\xe0A\x01R\x11overridableFields\x12=\n\x18required_override_fields\x18\r \x03(\tB\x03\xe0A\x01R\x16requiredOverrideFields:i\xeaAf\n connectors.h2o.ai/WorkerTemplate\x12!workerTemplates/{worker_template}*\x0fworkerTemplates2\x0eworkerTemplateB\x89\x01\n\x19ai.h2o.connectors.v1alphaB\x13WorkerTemplateProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'worker_template_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x13WorkerTemplateProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_WORKERTEMPLATE'].fields_by_name['metadata']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['metadata']._serialized_options = b'\xe0A\x02'
    _globals['_WORKERTEMPLATE'].fields_by_name['image']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['image']._serialized_options = b'\xe0A\x02'
    _globals['_WORKERTEMPLATE'].fields_by_name['pull_policy']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['pull_policy']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['supported_data_source_types']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['supported_data_source_types']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['version']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['version']._serialized_options = b'\xe0A\x03'
    _globals['_WORKERTEMPLATE'].fields_by_name['default_resources']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['default_resources']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['default_concurrency']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['default_concurrency']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['default_max_run_duration']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['default_max_run_duration']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['default_pod_template_spec_yaml']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['default_pod_template_spec_yaml']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['workspace_access_control']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['workspace_access_control']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['enabled']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['enabled']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['overridable_fields']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['overridable_fields']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE'].fields_by_name['required_override_fields']._loaded_options = None
    _globals['_WORKERTEMPLATE'].fields_by_name['required_override_fields']._serialized_options = b'\xe0A\x01'
    _globals['_WORKERTEMPLATE']._loaded_options = None
    _globals['_WORKERTEMPLATE']._serialized_options = b'\xeaAf\n connectors.h2o.ai/WorkerTemplate\x12!workerTemplates/{worker_template}*\x0fworkerTemplates2\x0eworkerTemplate'
    _globals['_WORKERTEMPLATE']._serialized_start = 179
    _globals['_WORKERTEMPLATE']._serialized_end = 1163