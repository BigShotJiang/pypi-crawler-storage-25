"""Generated protocol buffer code."""
from google.protobuf import descriptor as _descriptor
from google.protobuf import descriptor_pool as _descriptor_pool
from google.protobuf import runtime_version as _runtime_version
from google.protobuf import symbol_database as _symbol_database
from google.protobuf.internal import builder as _builder
_runtime_version.ValidateProtobufRuntimeVersion(_runtime_version.Domain.PUBLIC, 6, 33, 5, '', 'connection_service.proto')
_sym_db = _symbol_database.Default()
from . import connection_pb2 as connection__pb2
from google.api import annotations_pb2 as google_dot_api_dot_annotations__pb2
from google.api import client_pb2 as google_dot_api_dot_client__pb2
from google.api import field_behavior_pb2 as google_dot_api_dot_field__behavior__pb2
from google.api import resource_pb2 as google_dot_api_dot_resource__pb2
from google.protobuf import duration_pb2 as google_dot_protobuf_dot_duration__pb2
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from google.protobuf import field_mask_pb2 as google_dot_protobuf_dot_field__mask__pb2
from google.protobuf import timestamp_pb2 as google_dot_protobuf_dot_timestamp__pb2
DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x18connection_service.proto\x12\x19ai.h2o.connectors.v1alpha\x1a\x10connection.proto\x1a\x1cgoogle/api/annotations.proto\x1a\x17google/api/client.proto\x1a\x1fgoogle/api/field_behavior.proto\x1a\x19google/api/resource.proto\x1a\x1egoogle/protobuf/duration.proto\x1a\x1bgoogle/protobuf/empty.proto\x1a google/protobuf/field_mask.proto\x1a\x1fgoogle/protobuf/timestamp.proto"e\n\x17CreateConnectionRequest\x12J\n\nconnection\x18\x01 \x01(\x0b2%.ai.h2o.connectors.v1alpha.ConnectionB\x03\xe0A\x02R\nconnection"\x89\x01\n\x14GetConnectionRequest\x12&\n\x0cworkspace_id\x18\x02 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId"\xc3\x01\n\x16ListConnectionsRequest\x12&\n\x0cworkspace_id\x18\x01 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12 \n\tpage_size\x18\x02 \x01(\x05B\x03\xe0A\x01R\x08pageSize\x12"\n\npage_token\x18\x03 \x01(\tB\x03\xe0A\x01R\tpageToken\x12\x1b\n\x06filter\x18\x04 \x01(\tB\x03\xe0A\x01R\x06filter\x12\x1e\n\x08order_by\x18\x05 \x01(\tB\x03\xe0A\x01R\x07orderBy"\xb8\x01\n\x17ListConnectionsResponse\x12L\n\x0bconnections\x18\x01 \x03(\x0b2%.ai.h2o.connectors.v1alpha.ConnectionB\x03\xe0A\x03R\x0bconnections\x12+\n\x0fnext_page_token\x18\x02 \x01(\tB\x03\xe0A\x03R\rnextPageToken\x12"\n\ntotal_size\x18\x03 \x01(\x05B\x03\xe0A\x03R\ttotalSize"\xa7\x01\n\x17UpdateConnectionRequest\x12J\n\nconnection\x18\x01 \x01(\x0b2%.ai.h2o.connectors.v1alpha.ConnectionB\x03\xe0A\x02R\nconnection\x12@\n\x0bupdate_mask\x18\x02 \x01(\x0b2\x1a.google.protobuf.FieldMaskB\x03\xe0A\x01R\nupdateMask"\xe7\x01\n\x17CancelConnectionRequest\x12&\n\x0cworkspace_id\x18\x04 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId\x12\x1f\n\x08graceful\x18\x02 \x01(\x08B\x03\xe0A\x01R\x08graceful\x128\n\x07timeout\x18\x03 \x01(\x0b2\x19.google.protobuf.DurationB\x03\xe0A\x01R\x07timeout"\xa8\x01\n\x16PauseConnectionRequest\x12&\n\x0cworkspace_id\x18\x03 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId\x12\x1b\n\x06reason\x18\x02 \x01(\tB\x03\xe0A\x01R\x06reason"\x8c\x01\n\x17ResumeConnectionRequest\x12&\n\x0cworkspace_id\x18\x02 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId"\x8c\x01\n\x17DeleteConnectionRequest\x12&\n\x0cworkspace_id\x18\x02 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId"\xb9\x01\n\x16WatchConnectionRequest\x12&\n\x0cworkspace_id\x18\x03 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId\x12,\n\x0finclude_initial\x18\x02 \x01(\x08B\x03\xe0A\x01R\x0eincludeInitial"\xe8\x01\n\x17WatchConnectionResponse\x12J\n\nconnection\x18\x01 \x01(\x0b2%.ai.h2o.connectors.v1alpha.ConnectionB\x03\xe0A\x03R\nconnection\x12"\n\nevent_type\x18\x02 \x01(\tB\x03\xe0A\x03R\teventType\x12>\n\nevent_time\x18\x03 \x01(\x0b2\x1a.google.protobuf.TimestampB\x03\xe0A\x03R\teventTime\x12\x1d\n\x07message\x18\x04 \x01(\tB\x03\xe0A\x03R\x07message"\x93\x01\n\x1eGenerateConnectionTokenRequest\x12&\n\x0cworkspace_id\x18\x02 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId"E\n\x1fGenerateConnectionTokenResponse\x12"\n\nauth_token\x18\x01 \x01(\tB\x03\xe0A\x03R\tauthToken"\xb5\x01\n\x1cRevokeConnectionTokenRequest\x12I\n\rconnection_id\x18\x01 \x01(\tB$\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/ConnectionR\x0cconnectionId\x12&\n\x0cworkspace_id\x18\x02 \x01(\tB\x03\xe0A\x02R\x0bworkspaceId\x12"\n\nauth_token\x18\x03 \x01(\tB\x03\xe0A\x02R\tauthToken"\x1f\n\x1dRevokeConnectionTokenResponse"n\n\x1eValidateConnectionTokenRequest\x12(\n\rconnection_id\x18\x01 \x01(\tB\x03\xe0A\x02R\x0cconnectionId\x12"\n\nauth_token\x18\x02 \x01(\tB\x03\xe0A\x02R\tauthToken"!\n\x1fValidateConnectionTokenResponse2\xe6\x14\n\x11ConnectionService\x12\xc0\x01\n\x10CreateConnection\x122.ai.h2o.connectors.v1alpha.CreateConnectionRequest\x1a%.ai.h2o.connectors.v1alpha.Connection"Q\xdaA\nconnection\x82\xd3\xe4\x93\x02>"9/v1alpha/workspaces/{connection.workspace_id}/connections:\x01*\x12\xcc\x01\n\rGetConnection\x12/.ai.h2o.connectors.v1alpha.GetConnectionRequest\x1a%.ai.h2o.connectors.v1alpha.Connection"c\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02@\x12>/v1alpha/workspaces/{workspace_id}/connections/{connection_id}\x12\xb0\x01\n\x0fListConnections\x121.ai.h2o.connectors.v1alpha.ListConnectionsRequest\x1a2.ai.h2o.connectors.v1alpha.ListConnectionsResponse"6\x82\xd3\xe4\x93\x020\x12./v1alpha/workspaces/{workspace_id}/connections\x12\xdc\x01\n\x10CancelConnection\x122.ai.h2o.connectors.v1alpha.CancelConnectionRequest\x1a%.ai.h2o.connectors.v1alpha.Connection"m\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02J"E/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:cancel:\x01*\x12\xd9\x01\n\x0fPauseConnection\x121.ai.h2o.connectors.v1alpha.PauseConnectionRequest\x1a%.ai.h2o.connectors.v1alpha.Connection"l\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02I"D/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:pause:\x01*\x12\xdc\x01\n\x10ResumeConnection\x122.ai.h2o.connectors.v1alpha.ResumeConnectionRequest\x1a%.ai.h2o.connectors.v1alpha.Connection"m\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02J"E/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:resume:\x01*\x12\xe7\x01\n\x10UpdateConnection\x122.ai.h2o.connectors.v1alpha.UpdateConnectionRequest\x1a%.ai.h2o.connectors.v1alpha.Connection"x\xdaA\x16connection,update_mask\x82\xd3\xe4\x93\x02Y2T/v1alpha/workspaces/{connection.workspace_id}/connections/{connection.connection_id}:\x01*\x12\xc3\x01\n\x10DeleteConnection\x122.ai.h2o.connectors.v1alpha.DeleteConnectionRequest\x1a\x16.google.protobuf.Empty"c\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02@*>/v1alpha/workspaces/{workspace_id}/connections/{connection_id}\x12\xe5\x01\n\x0fWatchConnection\x121.ai.h2o.connectors.v1alpha.WatchConnectionRequest\x1a2.ai.h2o.connectors.v1alpha.WatchConnectionResponse"i\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02F\x12D/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:watch0\x01\x12\x86\x02\n\x17GenerateConnectionToken\x129.ai.h2o.connectors.v1alpha.GenerateConnectionTokenRequest\x1a:.ai.h2o.connectors.v1alpha.GenerateConnectionTokenResponse"t\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02Q"L/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:generateToken:\x01*\x12\xfe\x01\n\x15RevokeConnectionToken\x127.ai.h2o.connectors.v1alpha.RevokeConnectionTokenRequest\x1a8.ai.h2o.connectors.v1alpha.RevokeConnectionTokenResponse"r\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02O"J/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:revokeToken:\x01*\x12\xcf\x01\n\x17ValidateConnectionToken\x129.ai.h2o.connectors.v1alpha.ValidateConnectionTokenRequest\x1a:.ai.h2o.connectors.v1alpha.ValidateConnectionTokenResponse"=\x82\xd3\xe4\x93\x027"2/v1alpha/connections/{connection_id}:validateToken:\x01*B\x8c\x01\n\x19ai.h2o.connectors.v1alphaB\x16ConnectionServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alphab\x06proto3')
_globals = globals()
_builder.BuildMessageAndEnumDescriptors(DESCRIPTOR, _globals)
_builder.BuildTopDescriptorsAndMessages(DESCRIPTOR, 'connection_service_pb2', _globals)
if not _descriptor._USE_C_DESCRIPTORS:
    _globals['DESCRIPTOR']._loaded_options = None
    _globals['DESCRIPTOR']._serialized_options = b'\n\x19ai.h2o.connectors.v1alphaB\x16ConnectionServiceProtoP\x01ZUgithub.com/h2oai/connector-service/gen/go/ai/h2o/connectors/v1alpha;connectorsv1alpha'
    _globals['_CREATECONNECTIONREQUEST'].fields_by_name['connection']._loaded_options = None
    _globals['_CREATECONNECTIONREQUEST'].fields_by_name['connection']._serialized_options = b'\xe0A\x02'
    _globals['_GETCONNECTIONREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_GETCONNECTIONREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_GETCONNECTIONREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_GETCONNECTIONREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['page_size']._loaded_options = None
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['page_size']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['page_token']._loaded_options = None
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['page_token']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['filter']._loaded_options = None
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['filter']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['order_by']._loaded_options = None
    _globals['_LISTCONNECTIONSREQUEST'].fields_by_name['order_by']._serialized_options = b'\xe0A\x01'
    _globals['_LISTCONNECTIONSRESPONSE'].fields_by_name['connections']._loaded_options = None
    _globals['_LISTCONNECTIONSRESPONSE'].fields_by_name['connections']._serialized_options = b'\xe0A\x03'
    _globals['_LISTCONNECTIONSRESPONSE'].fields_by_name['next_page_token']._loaded_options = None
    _globals['_LISTCONNECTIONSRESPONSE'].fields_by_name['next_page_token']._serialized_options = b'\xe0A\x03'
    _globals['_LISTCONNECTIONSRESPONSE'].fields_by_name['total_size']._loaded_options = None
    _globals['_LISTCONNECTIONSRESPONSE'].fields_by_name['total_size']._serialized_options = b'\xe0A\x03'
    _globals['_UPDATECONNECTIONREQUEST'].fields_by_name['connection']._loaded_options = None
    _globals['_UPDATECONNECTIONREQUEST'].fields_by_name['connection']._serialized_options = b'\xe0A\x02'
    _globals['_UPDATECONNECTIONREQUEST'].fields_by_name['update_mask']._loaded_options = None
    _globals['_UPDATECONNECTIONREQUEST'].fields_by_name['update_mask']._serialized_options = b'\xe0A\x01'
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['graceful']._loaded_options = None
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['graceful']._serialized_options = b'\xe0A\x01'
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['timeout']._loaded_options = None
    _globals['_CANCELCONNECTIONREQUEST'].fields_by_name['timeout']._serialized_options = b'\xe0A\x01'
    _globals['_PAUSECONNECTIONREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_PAUSECONNECTIONREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_PAUSECONNECTIONREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_PAUSECONNECTIONREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_PAUSECONNECTIONREQUEST'].fields_by_name['reason']._loaded_options = None
    _globals['_PAUSECONNECTIONREQUEST'].fields_by_name['reason']._serialized_options = b'\xe0A\x01'
    _globals['_RESUMECONNECTIONREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_RESUMECONNECTIONREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_RESUMECONNECTIONREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_RESUMECONNECTIONREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_DELETECONNECTIONREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_DELETECONNECTIONREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_DELETECONNECTIONREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_DELETECONNECTIONREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_WATCHCONNECTIONREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_WATCHCONNECTIONREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_WATCHCONNECTIONREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_WATCHCONNECTIONREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_WATCHCONNECTIONREQUEST'].fields_by_name['include_initial']._loaded_options = None
    _globals['_WATCHCONNECTIONREQUEST'].fields_by_name['include_initial']._serialized_options = b'\xe0A\x01'
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['connection']._loaded_options = None
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['connection']._serialized_options = b'\xe0A\x03'
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['event_type']._loaded_options = None
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['event_type']._serialized_options = b'\xe0A\x03'
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['event_time']._loaded_options = None
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['event_time']._serialized_options = b'\xe0A\x03'
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['message']._loaded_options = None
    _globals['_WATCHCONNECTIONRESPONSE'].fields_by_name['message']._serialized_options = b'\xe0A\x03'
    _globals['_GENERATECONNECTIONTOKENREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_GENERATECONNECTIONTOKENREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_GENERATECONNECTIONTOKENREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_GENERATECONNECTIONTOKENREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_GENERATECONNECTIONTOKENRESPONSE'].fields_by_name['auth_token']._loaded_options = None
    _globals['_GENERATECONNECTIONTOKENRESPONSE'].fields_by_name['auth_token']._serialized_options = b'\xe0A\x03'
    _globals['_REVOKECONNECTIONTOKENREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_REVOKECONNECTIONTOKENREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02\xfaA\x1e\n\x1cconnectors.h2o.ai/Connection'
    _globals['_REVOKECONNECTIONTOKENREQUEST'].fields_by_name['workspace_id']._loaded_options = None
    _globals['_REVOKECONNECTIONTOKENREQUEST'].fields_by_name['workspace_id']._serialized_options = b'\xe0A\x02'
    _globals['_REVOKECONNECTIONTOKENREQUEST'].fields_by_name['auth_token']._loaded_options = None
    _globals['_REVOKECONNECTIONTOKENREQUEST'].fields_by_name['auth_token']._serialized_options = b'\xe0A\x02'
    _globals['_VALIDATECONNECTIONTOKENREQUEST'].fields_by_name['connection_id']._loaded_options = None
    _globals['_VALIDATECONNECTIONTOKENREQUEST'].fields_by_name['connection_id']._serialized_options = b'\xe0A\x02'
    _globals['_VALIDATECONNECTIONTOKENREQUEST'].fields_by_name['auth_token']._loaded_options = None
    _globals['_VALIDATECONNECTIONTOKENREQUEST'].fields_by_name['auth_token']._serialized_options = b'\xe0A\x02'
    _globals['_CONNECTIONSERVICE'].methods_by_name['CreateConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['CreateConnection']._serialized_options = b'\xdaA\nconnection\x82\xd3\xe4\x93\x02>"9/v1alpha/workspaces/{connection.workspace_id}/connections:\x01*'
    _globals['_CONNECTIONSERVICE'].methods_by_name['GetConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['GetConnection']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02@\x12>/v1alpha/workspaces/{workspace_id}/connections/{connection_id}'
    _globals['_CONNECTIONSERVICE'].methods_by_name['ListConnections']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['ListConnections']._serialized_options = b'\x82\xd3\xe4\x93\x020\x12./v1alpha/workspaces/{workspace_id}/connections'
    _globals['_CONNECTIONSERVICE'].methods_by_name['CancelConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['CancelConnection']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02J"E/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:cancel:\x01*'
    _globals['_CONNECTIONSERVICE'].methods_by_name['PauseConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['PauseConnection']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02I"D/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:pause:\x01*'
    _globals['_CONNECTIONSERVICE'].methods_by_name['ResumeConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['ResumeConnection']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02J"E/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:resume:\x01*'
    _globals['_CONNECTIONSERVICE'].methods_by_name['UpdateConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['UpdateConnection']._serialized_options = b'\xdaA\x16connection,update_mask\x82\xd3\xe4\x93\x02Y2T/v1alpha/workspaces/{connection.workspace_id}/connections/{connection.connection_id}:\x01*'
    _globals['_CONNECTIONSERVICE'].methods_by_name['DeleteConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['DeleteConnection']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02@*>/v1alpha/workspaces/{workspace_id}/connections/{connection_id}'
    _globals['_CONNECTIONSERVICE'].methods_by_name['WatchConnection']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['WatchConnection']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02F\x12D/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:watch'
    _globals['_CONNECTIONSERVICE'].methods_by_name['GenerateConnectionToken']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['GenerateConnectionToken']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02Q"L/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:generateToken:\x01*'
    _globals['_CONNECTIONSERVICE'].methods_by_name['RevokeConnectionToken']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['RevokeConnectionToken']._serialized_options = b'\xdaA\x1aworkspace_id,connection_id\x82\xd3\xe4\x93\x02O"J/v1alpha/workspaces/{workspace_id}/connections/{connection_id}:revokeToken:\x01*'
    _globals['_CONNECTIONSERVICE'].methods_by_name['ValidateConnectionToken']._loaded_options = None
    _globals['_CONNECTIONSERVICE'].methods_by_name['ValidateConnectionToken']._serialized_options = b'\x82\xd3\xe4\x93\x027"2/v1alpha/connections/{connection_id}:validateToken:\x01*'
    _globals['_CREATECONNECTIONREQUEST']._serialized_start = 316
    _globals['_CREATECONNECTIONREQUEST']._serialized_end = 417
    _globals['_GETCONNECTIONREQUEST']._serialized_start = 420
    _globals['_GETCONNECTIONREQUEST']._serialized_end = 557
    _globals['_LISTCONNECTIONSREQUEST']._serialized_start = 560
    _globals['_LISTCONNECTIONSREQUEST']._serialized_end = 755
    _globals['_LISTCONNECTIONSRESPONSE']._serialized_start = 758
    _globals['_LISTCONNECTIONSRESPONSE']._serialized_end = 942
    _globals['_UPDATECONNECTIONREQUEST']._serialized_start = 945
    _globals['_UPDATECONNECTIONREQUEST']._serialized_end = 1112
    _globals['_CANCELCONNECTIONREQUEST']._serialized_start = 1115
    _globals['_CANCELCONNECTIONREQUEST']._serialized_end = 1346
    _globals['_PAUSECONNECTIONREQUEST']._serialized_start = 1349
    _globals['_PAUSECONNECTIONREQUEST']._serialized_end = 1517
    _globals['_RESUMECONNECTIONREQUEST']._serialized_start = 1520
    _globals['_RESUMECONNECTIONREQUEST']._serialized_end = 1660
    _globals['_DELETECONNECTIONREQUEST']._serialized_start = 1663
    _globals['_DELETECONNECTIONREQUEST']._serialized_end = 1803
    _globals['_WATCHCONNECTIONREQUEST']._serialized_start = 1806
    _globals['_WATCHCONNECTIONREQUEST']._serialized_end = 1991
    _globals['_WATCHCONNECTIONRESPONSE']._serialized_start = 1994
    _globals['_WATCHCONNECTIONRESPONSE']._serialized_end = 2226
    _globals['_GENERATECONNECTIONTOKENREQUEST']._serialized_start = 2229
    _globals['_GENERATECONNECTIONTOKENREQUEST']._serialized_end = 2376
    _globals['_GENERATECONNECTIONTOKENRESPONSE']._serialized_start = 2378
    _globals['_GENERATECONNECTIONTOKENRESPONSE']._serialized_end = 2447
    _globals['_REVOKECONNECTIONTOKENREQUEST']._serialized_start = 2450
    _globals['_REVOKECONNECTIONTOKENREQUEST']._serialized_end = 2631
    _globals['_REVOKECONNECTIONTOKENRESPONSE']._serialized_start = 2633
    _globals['_REVOKECONNECTIONTOKENRESPONSE']._serialized_end = 2664
    _globals['_VALIDATECONNECTIONTOKENREQUEST']._serialized_start = 2666
    _globals['_VALIDATECONNECTIONTOKENREQUEST']._serialized_end = 2776
    _globals['_VALIDATECONNECTIONTOKENRESPONSE']._serialized_start = 2778
    _globals['_VALIDATECONNECTIONTOKENRESPONSE']._serialized_end = 2811
    _globals['_CONNECTIONSERVICE']._serialized_start = 2814
    _globals['_CONNECTIONSERVICE']._serialized_end = 5476