"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from google.protobuf import empty_pb2 as google_dot_protobuf_dot_empty__pb2
from . import worker_pb2 as worker__pb2
from . import worker_service_pb2 as worker__service__pb2

class WorkerServiceStub(object):
    """=============================================================================
    Worker Service
    =============================================================================

    WorkerService manages workers.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.CreateWorker = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerService/CreateWorker', request_serializer=worker__service__pb2.CreateWorkerRequest.SerializeToString, response_deserializer=worker__pb2.Worker.FromString, _registered_method=True)
        self.GetWorker = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerService/GetWorker', request_serializer=worker__service__pb2.GetWorkerRequest.SerializeToString, response_deserializer=worker__pb2.Worker.FromString, _registered_method=True)
        self.ListWorkers = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerService/ListWorkers', request_serializer=worker__service__pb2.ListWorkersRequest.SerializeToString, response_deserializer=worker__service__pb2.ListWorkersResponse.FromString, _registered_method=True)
        self.UpdateWorker = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerService/UpdateWorker', request_serializer=worker__service__pb2.UpdateWorkerRequest.SerializeToString, response_deserializer=worker__pb2.Worker.FromString, _registered_method=True)
        self.DeleteWorker = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerService/DeleteWorker', request_serializer=worker__service__pb2.DeleteWorkerRequest.SerializeToString, response_deserializer=google_dot_protobuf_dot_empty__pb2.Empty.FromString, _registered_method=True)

class WorkerServiceServicer(object):
    """=============================================================================
    Worker Service
    =============================================================================

    WorkerService manages workers.
    """

    def CreateWorker(self, request, context):
        """Creates a new worker.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetWorker(self, request, context):
        """Gets a worker by name.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListWorkers(self, request, context):
        """Lists workers.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def UpdateWorker(self, request, context):
        """Updates a worker.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteWorker(self, request, context):
        """Deletes a worker.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_WorkerServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'CreateWorker': grpc.unary_unary_rpc_method_handler(servicer.CreateWorker, request_deserializer=worker__service__pb2.CreateWorkerRequest.FromString, response_serializer=worker__pb2.Worker.SerializeToString), 'GetWorker': grpc.unary_unary_rpc_method_handler(servicer.GetWorker, request_deserializer=worker__service__pb2.GetWorkerRequest.FromString, response_serializer=worker__pb2.Worker.SerializeToString), 'ListWorkers': grpc.unary_unary_rpc_method_handler(servicer.ListWorkers, request_deserializer=worker__service__pb2.ListWorkersRequest.FromString, response_serializer=worker__service__pb2.ListWorkersResponse.SerializeToString), 'UpdateWorker': grpc.unary_unary_rpc_method_handler(servicer.UpdateWorker, request_deserializer=worker__service__pb2.UpdateWorkerRequest.FromString, response_serializer=worker__pb2.Worker.SerializeToString), 'DeleteWorker': grpc.unary_unary_rpc_method_handler(servicer.DeleteWorker, request_deserializer=worker__service__pb2.DeleteWorkerRequest.FromString, response_serializer=google_dot_protobuf_dot_empty__pb2.Empty.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.WorkerService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.WorkerService', rpc_method_handlers)

class WorkerService(object):
    """=============================================================================
    Worker Service
    =============================================================================

    WorkerService manages workers.
    """

    @staticmethod
    def CreateWorker(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerService/CreateWorker', worker__service__pb2.CreateWorkerRequest.SerializeToString, worker__pb2.Worker.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetWorker(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerService/GetWorker', worker__service__pb2.GetWorkerRequest.SerializeToString, worker__pb2.Worker.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ListWorkers(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerService/ListWorkers', worker__service__pb2.ListWorkersRequest.SerializeToString, worker__service__pb2.ListWorkersResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def UpdateWorker(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerService/UpdateWorker', worker__service__pb2.UpdateWorkerRequest.SerializeToString, worker__pb2.Worker.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def DeleteWorker(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerService/DeleteWorker', worker__service__pb2.DeleteWorkerRequest.SerializeToString, google_dot_protobuf_dot_empty__pb2.Empty.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)