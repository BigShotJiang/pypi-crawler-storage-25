"""Client and server classes corresponding to protobuf-defined services."""
import grpc
from . import connection_service_pb2 as connection__service__pb2
from . import worker_reporting_service_pb2 as worker__reporting__service__pb2

class WorkerReportingServiceStub(object):
    """=============================================================================
    Worker Reporting Service
    =============================================================================

    WorkerReportingService is an internal gRPC service hosted by the workload-manager.
    Workers use it to proactively report connection failures so the workload-manager
    can mark the connection FAILED and terminate the pod.

    Authentication: callers must supply the correct reporting token in the
    x-connection-token gRPC metadata header. There is no REST binding.
    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.ReportConnectionFailure = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerReportingService/ReportConnectionFailure', request_serializer=worker__reporting__service__pb2.ReportConnectionFailureRequest.SerializeToString, response_deserializer=worker__reporting__service__pb2.ReportConnectionFailureResponse.FromString, _registered_method=True)
        self.ValidateConnectionToken = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerReportingService/ValidateConnectionToken', request_serializer=connection__service__pb2.ValidateConnectionTokenRequest.SerializeToString, response_deserializer=connection__service__pb2.ValidateConnectionTokenResponse.FromString, _registered_method=True)
        self.GetCredentials = channel.unary_unary('/ai.h2o.connectors.v1alpha.WorkerReportingService/GetCredentials', request_serializer=worker__reporting__service__pb2.GetCredentialsRequest.SerializeToString, response_deserializer=worker__reporting__service__pb2.GetCredentialsResponse.FromString, _registered_method=True)

class WorkerReportingServiceServicer(object):
    """=============================================================================
    Worker Reporting Service
    =============================================================================

    WorkerReportingService is an internal gRPC service hosted by the workload-manager.
    Workers use it to proactively report connection failures so the workload-manager
    can mark the connection FAILED and terminate the pod.

    Authentication: callers must supply the correct reporting token in the
    x-connection-token gRPC metadata header. There is no REST binding.
    """

    def ReportConnectionFailure(self, request, context):
        """Reports that a connection has failed due to a data-source error.
        The workload-manager validates the reporting token, marks the connection FAILED
        with the supplied error details, and terminates the worker pod.

        Idempotent: if the connection is already in a terminal state (FAILED, COMPLETED,
        CANCELLED), the call returns OK with no further side effects.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ValidateConnectionToken(self, request, context):
        """Validates whether a client-facing connection token (JWT) is still valid.
        Workers call this at stream start to enforce server-side token revocation.
        The workload-manager relays the check to the api-server's in-memory token set.

        Returns OK if valid; UNAUTHENTICATED if revoked or unknown.
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def GetCredentials(self, request, context):
        """Returns the resolved credentials for the calling worker's connection.
        Workers call this on first StreamData invocation to lazily fetch datasource
        credentials that were resolved from SecureStore by the workload-manager.

        Authentication: callers must supply the correct reporting token in the
        x-connection-token gRPC metadata header.

        Returns an empty credentials list if the connection does not use
        CREDENTIAL_SOURCE_SECURE_STORE (non-error, per D-09).
        """
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

def add_WorkerReportingServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {'ReportConnectionFailure': grpc.unary_unary_rpc_method_handler(servicer.ReportConnectionFailure, request_deserializer=worker__reporting__service__pb2.ReportConnectionFailureRequest.FromString, response_serializer=worker__reporting__service__pb2.ReportConnectionFailureResponse.SerializeToString), 'ValidateConnectionToken': grpc.unary_unary_rpc_method_handler(servicer.ValidateConnectionToken, request_deserializer=connection__service__pb2.ValidateConnectionTokenRequest.FromString, response_serializer=connection__service__pb2.ValidateConnectionTokenResponse.SerializeToString), 'GetCredentials': grpc.unary_unary_rpc_method_handler(servicer.GetCredentials, request_deserializer=worker__reporting__service__pb2.GetCredentialsRequest.FromString, response_serializer=worker__reporting__service__pb2.GetCredentialsResponse.SerializeToString)}
    generic_handler = grpc.method_handlers_generic_handler('ai.h2o.connectors.v1alpha.WorkerReportingService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('ai.h2o.connectors.v1alpha.WorkerReportingService', rpc_method_handlers)

class WorkerReportingService(object):
    """=============================================================================
    Worker Reporting Service
    =============================================================================

    WorkerReportingService is an internal gRPC service hosted by the workload-manager.
    Workers use it to proactively report connection failures so the workload-manager
    can mark the connection FAILED and terminate the pod.

    Authentication: callers must supply the correct reporting token in the
    x-connection-token gRPC metadata header. There is no REST binding.
    """

    @staticmethod
    def ReportConnectionFailure(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerReportingService/ReportConnectionFailure', worker__reporting__service__pb2.ReportConnectionFailureRequest.SerializeToString, worker__reporting__service__pb2.ReportConnectionFailureResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def ValidateConnectionToken(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerReportingService/ValidateConnectionToken', connection__service__pb2.ValidateConnectionTokenRequest.SerializeToString, connection__service__pb2.ValidateConnectionTokenResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)

    @staticmethod
    def GetCredentials(request, target, options=(), channel_credentials=None, call_credentials=None, insecure=False, compression=None, wait_for_ready=None, timeout=None, metadata=None):
        return grpc.experimental.unary_unary(request, target, '/ai.h2o.connectors.v1alpha.WorkerReportingService/GetCredentials', worker__reporting__service__pb2.GetCredentialsRequest.SerializeToString, worker__reporting__service__pb2.GetCredentialsResponse.FromString, options, channel_credentials, insecure, call_credentials, compression, wait_for_ready, timeout, metadata, _registered_method=True)