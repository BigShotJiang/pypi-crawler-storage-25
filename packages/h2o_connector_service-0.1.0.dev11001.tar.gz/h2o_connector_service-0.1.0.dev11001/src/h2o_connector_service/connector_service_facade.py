"""High-level facade that collapses the multi-step connector workflow into one call."""

from __future__ import annotations

import uuid
import warnings

from h2o_connector_service._base import Client
from h2o_connector_service.connection_client import ConnectionServiceClient
from h2o_connector_service.connector_client import ConnectorServiceClient
from h2o_connector_service.connector_session import ConnectorSession


class ConnectorService:
    """One-stop facade for the complete data extraction workflow.

    Wraps :class:`Client`, :class:`ConnectorServiceClient`,
    :class:`ConnectionServiceClient`, and :class:`ConnectorSession` behind a
    single entry point. New users can go from zero to streaming data in a few
    lines::

        with ConnectorService.from_discovery(environment, workspace_id) as svc:
            with svc.open_session("postgresql", config, worker_name="pg-worker") as session:
                for row in session.stream_records():
                    print(row)

    For legacy/manual construction (deprecated)::

        with ConnectorService(url, token, workspace_id) as svc:
            ...

    Args:
        base_url: Base URL of the api-server (e.g. ``"http://localhost:8080"``).
        token: OIDC bearer token.
        workspace_id: Workspace that owns the connectors and connections.
    """

    def _init_from_client(self, client: Client, workspace_id: str) -> None:
        """Shared initialisation used by both construction paths."""
        self._client = client
        self._workspace_id = workspace_id
        self._connector_svc = ConnectorServiceClient(client)
        self._conn_svc = ConnectionServiceClient(client)

    def __init__(self, base_url: str, token: str, workspace_id: str) -> None:
        warnings.warn(
            "ConnectorService(base_url, token, workspace_id) is deprecated. "
            "Use ConnectorService.from_discovery() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            self._init_from_client(Client(base_url, token, workspace_id), workspace_id)

    @classmethod
    def from_discovery(
        cls,
        environment: str,
        workspace_id: str,
        *,
        token_provider=None,
    ) -> ConnectorService:
        """Construct a ConnectorService by resolving the connector-service URL from h2o Cloud Discovery.

        Args:
            environment: H2O Cloud environment URL (e.g. ``"https://cloud.h2o.ai"``).
            workspace_id: Workspace that owns the connectors and connections.
            token_provider: Optional ``h2o_authn.TokenProvider``. If ``None``,
                auto-created from discovery credentials.

        Raises:
            LookupError: If connector-service URL cannot be determined or
                token provider cannot be created from discovery.
        """
        client = Client.from_discovery(environment, workspace_id, token_provider=token_provider)
        instance = cls.__new__(cls)
        instance._init_from_client(client, workspace_id)
        return instance

    # ------------------------------------------------------------------
    # Primary entry point
    # ------------------------------------------------------------------

    def open_session(
        self,
        connector_type: str,
        config: dict,
        *,
        worker_name: str,
        query: str | None = None,
        connector_name: str | None = None,
        timeout: float = 300,
    ) -> ConnectorSession:
        """Create connector + connection, wait for readiness, return a session.

        This is the simplified workflow that replaces the manual 8-step process
        of creating a connector, creating a connection, and polling for readiness.

        Args:
            connector_type: Data source type string
                (e.g. ``"postgresql"``, ``"snowflake"``, ``"hive"``).
            config: Data source configuration dict (host, port, database, etc.).
            worker_name: Name of a pre-provisioned worker resource to use
                for this connection (e.g. ``"pg-worker"``).
            query: Optional SQL query for the extraction. When set, passed as
                ``extraction.query`` on the connection.
            connector_name: Name for the connector resource. If ``None``, a UUID
                is auto-generated.
            timeout: Maximum seconds to wait for the worker to become ready
                (default 300).

        Returns:
            A ready-to-use :class:`ConnectorSession`. Use as a context manager
            for clean lifecycle management.
        """
        ws = self._workspace_id
        name = connector_name or f"auto-{uuid.uuid4().hex[:12]}"

        # Step 1: Create connector
        self._connector_svc.create_connector(
            ws,
            {
                "metadata": {"name": name},
                "data_source_type": connector_type,
                "data_source_config": config,
            },
        )

        # Step 2: Create connection referencing the connector and worker
        conn_body: dict = {
            "connector": f"workspaces/{ws}/connectors/{name}",
            "worker": f"workspaces/{ws}/workers/{worker_name}",
        }
        if query is not None:
            conn_body.setdefault("extraction", {})["query"] = query

        connection = self._conn_svc.create_connection(
            ws,
            conn_body,
        )
        connection_id = connection["connection_id"]

        # Step 3: Build session and wait for worker readiness
        session = ConnectorSession(self._client, ws, connection_id)
        session.wait_for_worker_ready(timeout=timeout)

        return session

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> ConnectorService:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
