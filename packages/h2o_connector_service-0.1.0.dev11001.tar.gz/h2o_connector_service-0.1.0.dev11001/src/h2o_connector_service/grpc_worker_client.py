"""gRPC worker data plane client for the connector-service Python SDK."""

from __future__ import annotations

import os
import threading
from collections.abc import Generator

import grpc

from h2o_connector_service.gen.data_stream_service_pb2 import (
    StreamDataBidirectionalRequest,
    StreamDataRequest,
)
from h2o_connector_service.gen.data_stream_service_pb2_grpc import DataStreamServiceStub


def _discover_ca_cert() -> bytes | None:
    """Discover CA certificate for TLS via env var fallback chain.

    Checks SSL_CERT_FILE first (standard convention), then
    CONNECTOR_SERVICE_CA_CERT as service-specific override.
    Both are env vars pointing to a PEM file path.
    """
    for env_var in ("SSL_CERT_FILE", "CONNECTOR_SERVICE_CA_CERT"):
        path = os.environ.get(env_var)
        if path and os.path.isfile(path):
            with open(path, "rb") as f:
                return f.read()
    return None


class WorkerClient:
    """gRPC client for the worker data plane (DataStreamService).

    Connects to the worker pod endpoint returned in
    ``ConnectionStatusDetails.worker_endpoint``. Injects the
    ``authorization: Bearer <token>`` metadata header on every RPC call.

    Supports two transport paths:

    - **EXTERNAL (Gateway + TLS):** When ``endpoint_type`` is
      ``WORKER_ENDPOINT_TYPE_EXTERNAL`` and ``use_tls`` is ``True``,
      a TLS channel is created targeting ``hostname:443`` (or
      ``DS_GATEWAY_PORT`` env var override). The CA certificate is
      discovered via the ``SSL_CERT_FILE`` / ``CONNECTOR_SERVICE_CA_CERT``
      fallback chain. A ``x-route-path`` metadata header is added for
      GRPCRoute header matching.

    - **INTERNAL (insecure, in-cluster):** When ``endpoint_type`` is
      ``WORKER_ENDPOINT_TYPE_INTERNAL`` or when legacy positional args are
      used, an insecure channel is created targeting the pod IP directly.

    Args:
        host: Hostname or IP address of the worker pod (legacy positional form).
        port: gRPC port of the worker pod (legacy positional form, typically 50052).
        connection_token: Auth token for ``authorization`` metadata header.
        address: WorkerEndpoint address string. For EXTERNAL:
            ``hostname/workspace/connection-id`` (no port, no scheme).
            For INTERNAL: ``podIP:port``.
        endpoint_type: WorkerEndpointType string from the REST response, e.g.
            ``WORKER_ENDPOINT_TYPE_EXTERNAL`` or ``WORKER_ENDPOINT_TYPE_INTERNAL``.
        use_tls: Whether to create a TLS channel (from ``WorkerEndpoint.use_tls``).

    Note:
        Backward compatibility: ``WorkerClient(host, port, token)`` positional
        form still works for existing callers. New callers should prefer the
        keyword-argument form: ``WorkerClient(connection_token=token,
        address=addr, endpoint_type=etype, use_tls=tls)``.
    """

    def __init__(
        self,
        host: str = "",
        port: int = 0,
        connection_token: str = "",
        *,
        address: str = "",
        endpoint_type: str = "",
        use_tls: bool = False,
    ) -> None:
        self._token = connection_token
        self._metadata = [("authorization", f"Bearer {connection_token}")]

        if endpoint_type == "WORKER_ENDPOINT_TYPE_EXTERNAL" and use_tls:
            # EXTERNAL path: address format is "hostname/workspace/connection-id"
            # Split on the first '/' to get hostname and route path
            if "/" not in address:
                raise ValueError(
                    f"EXTERNAL endpoint address must contain '/' separator "
                    f"(expected 'hostname/workspace/connection-id'), got {address!r}"
                )
            slash_idx = address.index("/")
            hostname = address[:slash_idx]
            path = address[slash_idx:]  # "/workspace/connection-id"

            # Port defaults to 443, overridable via DS_GATEWAY_PORT env var
            gw_port = int(os.environ.get("DS_GATEWAY_PORT", "443"))
            target = f"{hostname}:{gw_port}"

            # Add route path metadata for GRPCRoute header-based routing
            self._metadata.append(("x-route-path", path))

            # Discover CA cert via env var fallback chain
            ca_cert = _discover_ca_cert()
            credentials = grpc.ssl_channel_credentials(root_certificates=ca_cert)
            self._channel = grpc.secure_channel(target, credentials)

            self._host = hostname
            self._port = gw_port
        else:
            # INTERNAL path or legacy positional args
            if address and not host:
                # INTERNAL address format: "podIP:port"
                host, port_str = address.rsplit(":", 1)
                port = int(port_str)
            # Legacy callers pass host and port directly — use as-is
            self._channel = grpc.insecure_channel(f"{host}:{port}")
            self._host = host
            self._port = port

        self._data_stub = DataStreamServiceStub(self._channel)

    # ------------------------------------------------------------------
    # GRPC-02: DataStreamService.StreamDataBidirectional
    # ------------------------------------------------------------------

    def stream_data(
        self,
        connection_id: str,
        preferred_format: int = 0,
        max_batch_size: int = 0,
    ) -> Generator:
        """Stream data batches from the worker via bidirectional streaming.

        Sends a start request then yields each :class:`DataBatch` from the server
        stream. Stops when the server sends a ``StreamComplete`` message or the
        stream closes.

        Args:
            connection_id: UUID of the connection to stream from.
            preferred_format: Optional ``DataFormat`` enum value (0 = unspecified).
            max_batch_size: Optional max records per batch override (0 = server default).

        Yields:
            ``DataBatch`` protobuf messages from the server.

        Raises:
            grpc.RpcError: If the stream encounters a gRPC-level error.
            RuntimeError: If the server sends an error message in the stream.
        """
        start_req = StreamDataRequest(connection_id=connection_id)
        if preferred_format:
            start_req.preferred_format = preferred_format
        if max_batch_size:
            start_req.max_batch_size = max_batch_size

        start_msg = StreamDataBidirectionalRequest(start_request=start_req)

        # Keep the request iterator alive until streaming completes.
        # If exhausted immediately, the gRPC half-close triggers the Java
        # worker's onCompleted() which sets cancelled=true — causing the
        # streaming virtual thread to exit silently without completing the
        # response stream, leaving the Python client hanging forever.
        _done = threading.Event()

        def _request_iterator():
            yield start_msg
            _done.wait(timeout=300)

        try:
            for resp in self._data_stub.StreamDataBidirectional(_request_iterator(), metadata=self._metadata):
                if resp.HasField("batch"):
                    yield resp.batch
                elif resp.HasField("complete"):
                    break
                elif resp.HasField("error"):
                    raise RuntimeError(f"Worker stream error: {resp.error.code} — {resp.error.message}")
                # flow_state messages are silently ignored (informational only)
        finally:
            _done.set()

    # ------------------------------------------------------------------
    # Context manager + cleanup
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Close the underlying gRPC channel."""
        self._channel.close()

    def __enter__(self) -> WorkerClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
