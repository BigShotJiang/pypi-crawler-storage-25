"""REST client for WorkerImageService (control plane)."""

from __future__ import annotations

from h2o_connector_service._base import Client


class WorkerImageServiceClient:
    """Wraps WorkerImageService REST RPCs (globally-scoped worker images).

    WorkerImages are platform-global resources that define container images
    for workers. No workspace_id is required.

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
    """

    def __init__(self, client: Client) -> None:
        self._c = client

    def create_worker_image(self, worker_image: dict) -> dict:
        """Create a worker image (POST /v1alpha/workerImages).

        Args:
            worker_image: WorkerImage dict (sent as ``{"worker_image": ...}`` body).
        """
        resp = self._c._http.post(
            "/v1alpha/workerImages",
            json={"worker_image": worker_image},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def get_worker_image(self, name: str) -> dict:
        """Get a worker image by resource name (GET /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workerImages/my-image"``.
        """
        resp = self._c._http.get(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
        return resp.json()

    def list_worker_images(self, **params: object) -> dict:
        """List all worker images (GET /v1alpha/workerImages)."""
        resp = self._c._http.get(
            "/v1alpha/workerImages",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def update_worker_image(self, worker_image: dict, update_mask: str | None = None) -> dict:
        """Update a worker image (PATCH /v1alpha/{worker_image.metadata.name}).

        Args:
            worker_image: Image dict with ``metadata.name`` set to the full resource name.
            update_mask: Comma-separated field mask.
        """
        name = worker_image["metadata"]["name"]
        params: dict = {}
        if update_mask:
            params["update_mask"] = update_mask
        resp = self._c._http.patch(
            f"/v1alpha/{name}",
            json={"worker_image": worker_image},
            params=params,
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def delete_worker_image(self, name: str) -> None:
        """Delete a worker image (DELETE /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workerImages/my-image"``.
        """
        resp = self._c._http.delete(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
