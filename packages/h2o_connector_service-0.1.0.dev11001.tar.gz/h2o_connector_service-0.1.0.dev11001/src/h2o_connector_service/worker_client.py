"""REST client for WorkerService (control plane)."""

from __future__ import annotations

from h2o_connector_service._base import Client


class WorkerServiceClient:
    """Wraps WorkerService REST RPCs (workspace-scoped workers).

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
    """

    def __init__(self, client: Client) -> None:
        self._c = client

    def create_worker(self, workspace_id: str, worker: dict) -> dict:
        """Create a new worker (POST /v1alpha/workspaces/{workspace_id}/workers).

        Args:
            workspace_id: Workspace to create the worker in.
            worker: Worker resource dict (sent as ``{"worker": worker}`` body).
        """
        resp = self._c._http.post(
            f"/v1alpha/workspaces/{workspace_id}/workers",
            json={"worker": worker},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def get_worker(self, name: str) -> dict:
        """Get a worker by resource name (GET /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workspaces/my-ws/workers/my-worker"``.
        """
        resp = self._c._http.get(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
        return resp.json()

    def list_workers(self, workspace_id: str, **params: object) -> dict:
        """List workers in a workspace (GET /v1alpha/workspaces/{workspace_id}/workers).

        Optional keyword params are forwarded as query parameters
        (e.g., ``page_size``, ``page_token``, ``filter``, ``order_by``).
        """
        resp = self._c._http.get(
            f"/v1alpha/workspaces/{workspace_id}/workers",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def update_worker(self, worker: dict, update_mask: str | None = None) -> dict:
        """Update a worker (PATCH /v1alpha/{worker.metadata.name}).

        Args:
            worker: Worker dict with ``metadata.name`` set to the full resource name.
            update_mask: Comma-separated field mask (e.g. ``"enabled"``).
        """
        name = worker["metadata"]["name"]
        params: dict = {}
        if update_mask:
            params["update_mask"] = update_mask
        resp = self._c._http.patch(
            f"/v1alpha/{name}",
            json={"worker": worker},
            params=params,
        )
        self._c._raise_for_status(resp)
        return resp.json()

    def delete_worker(self, name: str) -> None:
        """Delete a worker (DELETE /v1alpha/{name}).

        Args:
            name: Full resource name, e.g. ``"workspaces/my-ws/workers/my-worker"``.
        """
        resp = self._c._http.delete(f"/v1alpha/{name}")
        self._c._raise_for_status(resp)
