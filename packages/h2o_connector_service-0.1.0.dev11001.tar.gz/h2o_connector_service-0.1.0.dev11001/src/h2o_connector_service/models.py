"""Typed response models for the connector-service Python SDK.

Provides dataclass wrappers around the most frequently accessed API responses,
giving IDE autocomplete and eliminating fragile .get() chains on raw dicts.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ConnectionStatus:
    """Snapshot of a connection's current status and worker endpoint."""

    connection_id: str
    status: str
    worker_endpoint: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> ConnectionStatus:
        """Parse a GetConnection REST response dict."""
        endpoint = data.get("status_details", {}).get("worker_endpoint", {}).get("address")
        return cls(
            connection_id=data.get("connection_id", ""),
            status=data.get("status", ""),
            worker_endpoint=endpoint or None,
        )

    @property
    def is_ready(self) -> bool:
        return self.status in (
            "CONNECTION_STATUS_WORKER_READY",
            "CONNECTION_STATUS_WORKER_ACTIVE",
            "CONNECTION_STATUS_WORKER_IDLE",
        )

    @property
    def is_terminal_error(self) -> bool:
        return self.status in (
            "CONNECTION_STATUS_FAILED",
            "CONNECTION_STATUS_CANCELLED",
            "CONNECTION_STATUS_PRECONDITION_FAILURE",
        )


@dataclass
class ConnectorMeta:
    """Core metadata for a connector resource."""

    name: str
    workspace_id: str
    connector_type: str

    @classmethod
    def from_dict(cls, data: dict) -> ConnectorMeta:
        """Parse a connector REST response dict."""
        meta = data.get("metadata", {})
        spec = data.get("spec", {})
        return cls(
            name=meta.get("name", ""),
            workspace_id=meta.get("workspace_id", ""),
            connector_type=spec.get("connector_type", ""),
        )


@dataclass
class StorageEntry:
    """A single entry from a BrowseStorage listing."""

    name: str
    is_prefix: bool = False
    size: int = 0
    last_modified: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> StorageEntry:
        """Parse a single storage entry dict from a browse response."""
        return cls(
            name=data.get("name", ""),
            is_prefix=data.get("is_prefix", False),
            size=int(data.get("size", 0)),
            last_modified=data.get("last_modified"),
        )

    @classmethod
    def from_browse_response(cls, data: dict) -> list[StorageEntry]:
        """Parse all entries from a BrowseStorage REST response."""
        return [cls.from_dict(e) for e in data.get("entries", [])]
