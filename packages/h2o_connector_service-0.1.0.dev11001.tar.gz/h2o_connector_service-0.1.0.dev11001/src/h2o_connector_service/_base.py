"""Base HTTP client for the connector-service Python SDK."""

from __future__ import annotations

import os
import warnings
from collections.abc import Callable, Generator

import httpx

from h2o_connector_service.exceptions import ConnectorServiceError


class _TokenAuth(httpx.Auth):
    """Per-request Bearer token injection via callable token provider."""

    def __init__(self, token_provider: Callable[[], str]) -> None:
        self._token_provider = token_provider

    def auth_flow(self, request: httpx.Request) -> Generator[httpx.Request, httpx.Response, None]:
        request.headers["Authorization"] = f"Bearer {self._token_provider()}"
        yield request


class Client:
    """Base httpx client that injects ``Authorization: Bearer <token>`` on every request.

    Args:
        base_url: Base URL of the api-server (e.g. ``"http://localhost:8080"``).
        token: OIDC bearer token. Injected as ``Authorization: Bearer <token>``.
        workspace_id: Default workspace ID for workspace-scoped operations.

    .. deprecated::
        Use :meth:`from_discovery` instead to construct a client with automatic
        URL resolution and token refresh from h2o Cloud Discovery.
    """

    def __init__(self, base_url: str, token: str, workspace_id: str) -> None:
        warnings.warn(
            "Client(base_url, token, workspace_id) is deprecated. Use Client.from_discovery() instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.workspace_id = workspace_id
        self._http = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {token}"},
        )

    @classmethod
    def from_discovery(
        cls,
        environment: str,
        workspace_id: str,
        *,
        token_provider=None,
    ) -> Client:
        """Construct a Client by resolving the connector-service URL from h2o Cloud Discovery.

        Args:
            environment: H2O Cloud environment URL (e.g. ``"https://cloud.h2o.ai"``).
            workspace_id: Workspace ID for workspace-scoped operations.
            token_provider: Optional ``h2o_authn.TokenProvider``. If ``None``,
                auto-created from discovery credentials.

        Raises:
            LookupError: If connector-service URL cannot be determined or
                token provider cannot be created from discovery.
        """
        import h2o_discovery

        discovery = None
        try:
            discovery = h2o_discovery.discover(environment=environment)
        except (OSError, ConnectionError, TimeoutError) as e:
            base_url = os.environ.get("H2O_CONNECTOR_SERVICE_URL")
            if not base_url:
                raise LookupError(
                    "Cannot resolve connector-service from h2o Cloud Discovery and "
                    "H2O_CONNECTOR_SERVICE_URL is not set."
                ) from e
        else:
            # Resolve connector-service URL with env var fallback (D-11)
            svc = discovery.services.get("connector-service")
            if svc is not None:
                base_url = svc.uri
            else:
                base_url = os.environ.get("H2O_CONNECTOR_SERVICE_URL")
                if not base_url:
                    raise LookupError(
                        "connector-service not found in h2o Cloud Discovery and H2O_CONNECTOR_SERVICE_URL is not set."
                    )

        # Auto-create token provider from discovery credentials (D-05)
        if token_provider is None:
            if discovery is None:
                raise LookupError(
                    "Cannot create token provider without discovery. "
                    "Provide token_provider when using H2O_CONNECTOR_SERVICE_URL fallback."
                )
            import h2o_authn.discovery as _authn_discovery

            try:
                token_provider = _authn_discovery.create(discovery)
            except (KeyError, ValueError) as e:
                raise LookupError(
                    "Cannot create token provider from discovery. "
                    "Configure the H2O CLI or set H2O_CLOUD_CLIENT_PLATFORM_TOKEN."
                ) from e

        # Build Client bypassing deprecated __init__ (D-12: cached at construction)
        instance = cls.__new__(cls)
        instance.base_url = base_url.rstrip("/")
        instance.token = None  # Not applicable for discovery-based clients
        instance.workspace_id = workspace_id
        instance._http = httpx.Client(
            base_url=instance.base_url,
            auth=_TokenAuth(token_provider),
        )
        return instance

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Raise :class:`ConnectorServiceError` if *response* is not 2xx."""
        if response.is_error:
            raise ConnectorServiceError(response.status_code, response.text)

    def close(self) -> None:
        """Close the underlying httpx client."""
        self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
