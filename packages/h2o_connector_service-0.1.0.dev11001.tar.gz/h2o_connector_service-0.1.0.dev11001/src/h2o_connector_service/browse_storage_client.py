"""REST client for StorageBrowseService (data plane proxy via api-server)."""

from __future__ import annotations

from h2o_connector_service._base import Client


class BrowseStorageClient(Client):
    """Wraps StorageBrowseService.BrowseStorage via the api-server REST proxy.

    The api-server proxies the gRPC ``BrowseStorage`` call to the worker pod
    identified by *connection_id*. Clients call the api-server HTTP endpoint
    rather than the worker pod directly, using the workspace OIDC ``authorization``
    token (Bearer).

    Args:
        base_url: Base URL of the api-server (e.g. ``"http://localhost:8080"``).
        token: OIDC bearer token injected as ``Authorization: Bearer <token>``.
    """

    def __init__(self, base_url: str, token: str) -> None:
        # workspace_id is not used for connection-scoped browse calls;
        # the api-server resolves the workspace from the connection record.
        super().__init__(base_url, token, workspace_id="")

    # ------------------------------------------------------------------
    # GRPC-04: StorageBrowseService.BrowseStorage
    # ------------------------------------------------------------------

    def browse(
        self,
        connection_id: str,
        prefix: str = "",
        delimiter: str = "/",
        page_size: int = 0,
        page_token: str = "",
    ) -> dict:
        """Browse storage entries for a connection.

        Wraps ``GET /v1alpha/connections/{connection_id}/browse``.

        Args:
            connection_id: UUID of the connection whose worker pod to browse.
            prefix: Path prefix to browse (default ``""`` — root).
            delimiter: Separator for folder-style listing (default ``"/"``).
                Pass ``""`` for a flat listing of all objects under *prefix*.
            page_size: Maximum number of entries to return per page
                (``0`` uses the server default).
            page_token: Opaque page token returned by a previous call
                (``""`` for the first page).

        Returns:
            A dict with the following keys:

            - ``entries``: list of ``StorageEntry`` dicts
            - ``next_page_token``: empty string when no further pages remain
            - ``current_prefix``: the effective prefix used for this page

        Raises:
            :class:`~h2o_connector_service.exceptions.ConnectorServiceError`:
                If the server returns a non-2xx HTTP status.
        """
        params: dict = {}
        if prefix:
            params["prefix"] = prefix
        if delimiter != "/":
            # Only override when caller explicitly changes the default
            params["delimiter"] = delimiter
        if page_size:
            params["page_size"] = page_size
        if page_token:
            params["page_token"] = page_token

        # Always send delimiter so the server gets explicit folder-vs-flat intent
        params["delimiter"] = delimiter

        resp = self._http.get(
            f"/v1alpha/connections/{connection_id}/browse",
            params=params,
        )
        self._raise_for_status(resp)
        return resp.json()
