"""REST client for DataSourceProfileService (control plane)."""

from __future__ import annotations

from h2o_connector_service._base import Client


class DataSourceProfileServiceClient:
    """Wraps DataSourceProfileService REST RPCs.

    DataSourceProfileService is a global, read-only service that exposes config
    schema discovery. No workspace_id is required.

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
    """

    def __init__(self, client: Client) -> None:
        self._c = client

    def list_data_source_profiles(self, **params: object) -> dict:
        """List registered data source profiles (GET /v1alpha/dataSourceProfiles).

        Optional keyword params are forwarded as query parameters.
        Supported params per the API spec:
          - ``page_size`` (int): Max profiles to return.
          - ``page_token`` (str): Pagination token.
          - ``filter`` (str): e.g. ``"category=TABULAR"`` or ``"data_source_type=postgresql"``.
        """
        resp = self._c._http.get(
            "/v1alpha/dataSourceProfiles",
            params={k: v for k, v in params.items() if v is not None},
        )
        self._c._raise_for_status(resp)
        return resp.json()
