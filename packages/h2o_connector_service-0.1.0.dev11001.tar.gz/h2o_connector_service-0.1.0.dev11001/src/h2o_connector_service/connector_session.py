"""High-level session handle composing REST control plane + gRPC data plane."""

from __future__ import annotations

import csv
import time
from collections.abc import Iterator

from h2o_connector_service._base import Client
from h2o_connector_service.connection_client import ConnectionServiceClient
from h2o_connector_service.grpc_worker_client import WorkerClient

# ---------------------------------------------------------------------------
# Internal helper: convert proto Value oneof → Python scalar
# ---------------------------------------------------------------------------


def _extract_value(val) -> object:
    """Convert a data_pb2.Value protobuf message to a plain Python value."""
    which = val.WhichOneof("value")
    if which is None or which == "null_value":
        return None
    if which == "bool_value":
        return val.bool_value
    if which == "int_value":
        return val.int_value
    if which == "float_value":
        return val.float_value
    if which == "string_value":
        return val.string_value
    if which == "bytes_value":
        return val.bytes_value
    if which == "timestamp_value":
        # microseconds since epoch
        return val.timestamp_value
    if which == "date_value":
        return val.date_value
    if which == "time_value":
        return val.time_value
    if which == "decimal_value":
        return val.decimal_value
    if which == "json_value":
        from google.protobuf.json_format import MessageToDict

        return MessageToDict(val.json_value)
    # array_value, map_value, struct_value — return string repr for now
    return str(val)


# ---------------------------------------------------------------------------
# Internal helper: chunked iteration
# ---------------------------------------------------------------------------


def _iter_chunks(it: Iterator, size: int) -> Iterator[list]:
    """Yield successive chunks of *size* items from an iterator."""
    chunk: list = []
    for item in it:
        chunk.append(item)
        if len(chunk) >= size:
            yield chunk
            chunk = []
    if chunk:
        yield chunk


# ---------------------------------------------------------------------------
# ConnectorSession
# ---------------------------------------------------------------------------


class ConnectorSession:
    """High-level session handle for a single connector-service connection.

    Bundles the REST client, workspace context, and connection identity into
    a single object that exposes the complete extraction workflow.

    Args:
        client: Authenticated :class:`~h2o_connector_service._base.Client` instance.
        workspace_id: Workspace that owns the connection.
        connection_id: UUID of the connection to use.

    Example::

        with Client(api_url, token, workspace_id) as client:
            session = ConnectorSession(client, workspace_id, connection_id)
            session.wait_for_worker_ready()
            records = session.stream_to_records()
    """

    _READY_STATUSES = [
        "CONNECTION_STATUS_WORKER_READY",
        "CONNECTION_STATUS_WORKER_ACTIVE",
        "CONNECTION_STATUS_WORKER_IDLE",
    ]
    _TERMINAL_ERROR_STATUSES = [
        "CONNECTION_STATUS_FAILED",
        "CONNECTION_STATUS_CANCELLED",
        "CONNECTION_STATUS_PRECONDITION_FAILURE",
    ]

    def __init__(self, client: Client, workspace_id: str, connection_id: str) -> None:
        self._client = client
        self._workspace_id = workspace_id
        self._connection_id = connection_id
        self._conn_svc = ConnectionServiceClient(client)

    # ------------------------------------------------------------------
    # Context manager (for use with ConnectorService facade)
    # ------------------------------------------------------------------

    def __enter__(self) -> ConnectorSession:
        return self

    def __exit__(self, *args: object) -> None:
        pass

    # ------------------------------------------------------------------
    # SDK-02: wait_for_worker_ready
    # ------------------------------------------------------------------

    def wait_for_worker_ready(
        self,
        timeout: float = 300.0,
        interval: float = 2.0,
    ) -> dict:
        """Poll until the connection's worker is ready to accept streaming requests.

        Polls ``GetConnection`` every *interval* seconds until the connection
        status is one of ``WORKER_READY``, ``WORKER_ACTIVE``, or ``WORKER_IDLE``.

        Args:
            timeout: Maximum wait time in seconds (default 300).
            interval: Polling interval in seconds (default 2).

        Returns:
            The connection dict when a ready status is reached.

        Raises:
            RuntimeError: If the connection reaches a terminal error status
                (FAILED, CANCELLED, PRECONDITION_FAILURE).
            TimeoutError: If the timeout expires before a ready status is reached.
        """
        deadline = time.monotonic() + timeout
        while True:
            conn = self._conn_svc.get_connection(self._workspace_id, self._connection_id)
            status = conn.get("status", "")
            if status in self._READY_STATUSES:
                return conn
            if status in self._TERMINAL_ERROR_STATUSES:
                raise RuntimeError(
                    f"Connection {self._connection_id!r} reached terminal status {status!r} — cannot proceed."
                )
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Connection {self._connection_id!r} did not become ready "
                    f"within {timeout}s (last status: {status!r})"
                )
            time.sleep(interval)

    # ------------------------------------------------------------------
    # SDK-03: generate_token
    # ------------------------------------------------------------------

    def generate_token(self) -> str:
        """Generate a fresh connection auth token (x-connection-token).

        Calls ``GenerateConnectionToken`` on the api-server. Returns the
        ``auth_token`` string for use with
        :class:`~h2o_connector_service.grpc_worker_client.WorkerClient`.

        Returns:
            The generated auth token string.
        """
        resp = self._conn_svc.generate_connection_token(self._workspace_id, self._connection_id)
        return resp["auth_token"]

    # ------------------------------------------------------------------
    # SDK-04a: stream_records (memory-efficient generator)
    # ------------------------------------------------------------------

    def stream_records(self, max_batches: int | None = None) -> Iterator[dict]:
        """Stream data from the worker, yielding one dict per row.

        This is the memory-efficient counterpart to :meth:`stream_to_records`.
        Each row is yielded as a plain Python dict keyed by column name and
        immediately eligible for garbage collection — memory usage stays constant
        regardless of dataset size.

        Internally:
        1. Calls ``GetConnection`` to retrieve the worker endpoint address.
        2. Calls ``GenerateConnectionToken`` for a fresh auth token.
        3. Creates a :class:`~h2o_connector_service.grpc_worker_client.WorkerClient`
           and streams all :class:`DataBatch` messages.
        4. Yields each row as a dict.

        Args:
            max_batches: If set, stop after this many batches (for testing/sampling).
                ``None`` means stream until completion.

        Yields:
            A dict per row, with column names as keys.
        """
        conn = self._conn_svc.get_connection(self._workspace_id, self._connection_id)
        endpoint = conn.get("status_details", {}).get("worker_endpoint", {})
        address = endpoint.get("address", "")
        if not address:
            raise RuntimeError(
                f"Connection {self._connection_id!r} has no worker_endpoint.address -- "
                "ensure wait_for_worker_ready() completes before streaming."
            )
        # Extract endpoint type and TLS fields (handles both snake_case and camelCase)
        endpoint_type = endpoint.get("type", "")
        use_tls = endpoint.get("use_tls", endpoint.get("useTls", False))

        token = self.generate_token()

        column_names: list[str] | None = None
        batches_received = 0

        with WorkerClient(
            connection_token=token,
            address=address,
            endpoint_type=endpoint_type,
            use_tls=use_tls,
        ) as wc:
            for batch in wc.stream_data(self._connection_id):
                if max_batches is not None and batches_received >= max_batches:
                    break

                # Capture column names from schema (usually in first batch)
                if column_names is None and batch.HasField("schema"):
                    schema = batch.schema
                    if schema.HasField("field_schema"):
                        column_names = [f.name for f in schema.field_schema.fields]

                # Yield individual rows
                if batch.HasField("records"):
                    for record in batch.records.records:
                        if record.HasField("values"):
                            row = [_extract_value(v) for v in record.values.values]
                            if column_names is None:
                                column_names = [f"col_{i}" for i in range(len(row))]
                            yield {name: (row[i] if i < len(row) else None) for i, name in enumerate(column_names)}

                batches_received += 1

    # ------------------------------------------------------------------
    # SDK-04b: stream_to_records (list — delegates to stream_records)
    # ------------------------------------------------------------------

    def stream_to_records(self, max_batches: int | None = None) -> list[dict]:
        """Stream all data from the worker and return as a list of dicts.

        Convenience wrapper around :meth:`stream_records` that collects all
        rows into a list. For large datasets prefer ``stream_records()`` or
        ``stream_to_csv()`` to avoid loading everything into memory.

        Args:
            max_batches: If set, stop after this many batches (for testing/sampling).
                ``None`` means stream until completion.

        Returns:
            A list of dicts, one per row, with column names as keys.
        """
        return list(self.stream_records(max_batches=max_batches))

    # ------------------------------------------------------------------
    # SDK-05: stream_to_csv (memory-safe — uses generator)
    # ------------------------------------------------------------------

    def stream_to_csv(
        self,
        path: str,
        max_batches: int | None = None,
    ) -> int:
        """Stream all data and write to a CSV file.

        Unlike the previous implementation, this no longer buffers all rows in
        memory. Rows are written to disk as they arrive from the gRPC stream.

        Args:
            path: Filesystem path for the output ``.csv`` file.
            max_batches: Passed through to :meth:`stream_records`.

        Returns:
            Number of rows written.
        """
        count = 0
        with open(path, "w", newline="") as f:
            writer: csv.DictWriter | None = None
            for record in self.stream_records(max_batches=max_batches):
                if writer is None:
                    writer = csv.DictWriter(f, fieldnames=list(record.keys()))
                    writer.writeheader()
                writer.writerow(record)
                count += 1
        return count

    # ------------------------------------------------------------------
    # SDK-06: stream_to_pandas (optional pandas dependency)
    # ------------------------------------------------------------------

    def stream_to_pandas(self, max_batches: int | None = None):
        """Stream all data and return as a pandas DataFrame.

        Requires ``pandas`` to be installed. Install with::

            pip install connector-service[pandas]

        Args:
            max_batches: Passed through to :meth:`stream_records`.

        Returns:
            A ``pandas.DataFrame`` with column names from the schema.

        Raises:
            ImportError: If pandas is not installed.
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for stream_to_pandas(). Install it with: pip install connector-service[pandas]"
            )
        return pd.DataFrame(self.stream_records(max_batches=max_batches))

    # ------------------------------------------------------------------
    # SDK-07: stream_to_parquet (memory-safe, optional pyarrow dependency)
    # ------------------------------------------------------------------

    def stream_to_parquet(
        self,
        path: str,
        max_batches: int | None = None,
        chunk_size: int = 10_000,
    ) -> int:
        """Stream all data and write to a Parquet file (memory-safe).

        Rows are written in chunks of *chunk_size* as separate Parquet row
        groups, so peak memory usage is proportional to the chunk size rather
        than the full dataset.

        Requires ``pyarrow`` to be installed. Install with::

            pip install connector-service[parquet]

        Args:
            path: Filesystem path for the output ``.parquet`` file.
            max_batches: Passed through to :meth:`stream_records`.
            chunk_size: Number of rows per Parquet row group (default 10 000).

        Returns:
            Number of rows written.

        Raises:
            ImportError: If pyarrow is not installed.
        """
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError:
            raise ImportError(
                "pyarrow is required for stream_to_parquet(). Install with: pip install connector-service[parquet]"
            )

        writer: pq.ParquetWriter | None = None
        total_rows = 0

        try:
            for chunk in _iter_chunks(self.stream_records(max_batches=max_batches), chunk_size):
                columns = {k: [row.get(k) for row in chunk] for k in chunk[0]}
                table = pa.table(columns)

                if writer is None:
                    writer = pq.ParquetWriter(path, table.schema)
                writer.write_table(table)
                total_rows += len(chunk)
        finally:
            if writer is not None:
                writer.close()

        return total_rows

    # ------------------------------------------------------------------
    # SDK-08: stream_to_data_table (memory-safe, optional datatable dep)
    # ------------------------------------------------------------------

    def stream_to_data_table(
        self,
        max_batches: int | None = None,
        chunk_size: int = 10_000,
    ):
        """Stream all data and return as a datatable Frame (memory-safe).

        Uses the `datatable <https://datatable.readthedocs.io/>`_ library
        (h2o datatable) which provides fast, memory-efficient columnar data
        frames powered by a C++ core. Rows are accumulated in chunks and
        concatenated via ``dt.rbind()``, avoiding a full pandas
        materialisation.

        Requires ``datatable`` to be installed. Install with::

            pip install connector-service[datatable]

        Args:
            max_batches: Passed through to :meth:`stream_records`.
            chunk_size: Number of rows per intermediate Frame (default 10 000).

        Returns:
            A ``datatable.Frame`` with column names from the schema.

        Raises:
            ImportError: If datatable is not installed.
        """
        try:
            import datatable as dt
        except ImportError:
            raise ImportError(
                "datatable is required for stream_to_data_table(). "
                "Install it with: pip install connector-service[datatable]"
            )

        frames: list = []
        for chunk in _iter_chunks(self.stream_records(max_batches=max_batches), chunk_size):
            frames.append(dt.Frame(chunk))

        if not frames:
            return dt.Frame()

        result = frames[0]
        if len(frames) > 1:
            result.rbind(*frames[1:])
        return result

    # ------------------------------------------------------------------
    # SDK-09: stream_to_h2o_frame (memory-safe, optional h2o dependency)
    # ------------------------------------------------------------------

    def stream_to_h2o_frame(
        self,
        max_batches: int | None = None,
        chunk_size: int = 10_000,
    ):
        """Stream all data and return as an H2O Frame (memory-safe).

        Uses the `h2o <https://docs.h2o.ai/h2o/latest-stable/h2o-py/>`_
        library which provides distributed data frames backed by a JVM
        cluster. **An H2O cluster must be running** — call ``h2o.init()``
        before invoking this method.

        Data is first written to a temporary Parquet file in chunks (if
        ``pyarrow`` is available) or a temporary CSV file (as fallback),
        then imported into the H2O cluster via ``h2o.import_file()``.
        This avoids holding the full dataset in Python memory.

        Requires ``h2o`` to be installed. Install with::

            pip install connector-service[h2o]

        Args:
            max_batches: Passed through to :meth:`stream_records`.
            chunk_size: Number of rows per intermediate write chunk
                (default 10 000).

        Returns:
            An ``h2o.H2OFrame`` with column names from the schema.

        Raises:
            ImportError: If h2o is not installed.
            RuntimeError: If no H2O cluster is running (``h2o.init()``
                was not called beforehand).
        """
        import os
        import tempfile

        try:
            import h2o
        except ImportError:
            raise ImportError(
                "h2o is required for stream_to_h2o_frame(). Install it with: pip install connector-service[h2o]"
            )
        if not h2o.connection():
            raise RuntimeError("No H2O cluster connection found. Call h2o.init() before using stream_to_h2o_frame().")

        # Prefer parquet (faster H2O ingest); fall back to CSV
        try:
            import pyarrow  # noqa: F401

            use_parquet = True
        except ImportError:
            use_parquet = False

        suffix = ".parquet" if use_parquet else ".csv"
        tmp_fd, tmp_path = tempfile.mkstemp(suffix=suffix)
        os.close(tmp_fd)

        try:
            if use_parquet:
                self.stream_to_parquet(
                    tmp_path,
                    max_batches=max_batches,
                    chunk_size=chunk_size,
                )
            else:
                self.stream_to_csv(tmp_path, max_batches=max_batches)

            return h2o.import_file(tmp_path)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
