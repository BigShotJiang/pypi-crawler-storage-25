# Flask-Caching

A fork of the [Flask-cache](https://github.com/thadeusb/flask-cache) extension which adds easy cache support to Flask.

## Installing

Install and update using [pip](https://pip.pypa.io/en/stable/getting-started/):

```text
$ pip install -U flask-caching
```

## Donate

The Pallets organization develops and supports Flask and the libraries
it uses. In order to grow the community of contributors and users, and
allow the maintainers to devote more time to the projects, [please
donate today](https://palletsprojects.com/donate).

## Links

-   Documentation: <https://flask-caching.readthedocs.io>
-   Changes: <https://flask-caching.readthedocs.io/en/latest/changelog.html>
-   PyPI Releases: <https://pypi.org/project/Flask-Caching/>
-   Source Code: <https://github.com/pallets-eco/flask-caching>
-   Issue Tracker: <https://github.com/pallets-eco/flask-caching/issues>
-   Twitter: <https://twitter.com/PalletsTeam>
-   Chat: <https://discord.gg/pallets>