"""Integration tests for paude."""
