print("Hello from Python")
