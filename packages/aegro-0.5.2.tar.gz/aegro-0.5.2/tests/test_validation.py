import pytest

from aegro.errors import InvalidKeyError
from aegro.validation import validate_key


def test_validate_key_normal():
    assert validate_key("abc123") == "abc123"


def test_validate_key_rejects_slash():
    with pytest.raises(InvalidKeyError):
        validate_key("abc/123")


def test_validate_key_rejects_question_mark():
    with pytest.raises(InvalidKeyError):
        validate_key("abc?123")


def test_validate_key_rejects_hash():
    with pytest.raises(InvalidKeyError):
        validate_key("abc#123")


def test_validate_key_rejects_whitespace():
    with pytest.raises(InvalidKeyError):
        validate_key("abc 123")
