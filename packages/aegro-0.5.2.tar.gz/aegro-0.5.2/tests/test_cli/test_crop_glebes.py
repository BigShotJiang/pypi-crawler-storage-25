from __future__ import annotations

import json


from aegro.cli import app


class TestCropGlebesGet:
    def test_get_crop_glebe(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = {"_id": "cg-1", "name": "Talhao Soja"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["crop-glebes", "get", "cg-1"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["name"] == "Talhao Soja"
        mock_client.get.assert_called_once_with("/pub/v1/crop-glebes/cg-1", api_key="key-1")


class TestCropGlebesList:
    def test_list_with_crop_key(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = [{"_id": "cg-1"}]
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["crop-glebes", "list", "crop-1"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert len(data) == 1
        assert mock_client.post.call_args.args[0] == "/pub/v1/crops/crop-1/crop-glebes/filter"
        call_body = mock_client.post.call_args.kwargs["json_body"]
        assert call_body["requiredPageNumber"] == 1
        assert call_body["maximumItemsPerPageCount"] == 50
