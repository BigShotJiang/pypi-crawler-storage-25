from __future__ import annotations

from unittest.mock import MagicMock

import pytest
from typer.testing import CliRunner

from aegro.config import Settings


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_settings(monkeypatch):
    """Settings with two test farms."""
    settings = Settings(farms={"Fazenda Sul": "key-1", "Fazenda Norte": "key-2"})
    monkeypatch.setattr("aegro.cli._config._settings", settings)
    return settings


@pytest.fixture
def mock_client(monkeypatch):
    """Mock SyncAegroClient injected into _config singleton.

    Uses MagicMock (not AsyncMock) because SyncAegroClient has
    synchronous methods.
    """
    client = MagicMock()
    monkeypatch.setattr("aegro.cli._config._client", client)
    return client


@pytest.fixture
def temp_state(tmp_path, monkeypatch):
    """Redirect farm state to a temp directory."""
    monkeypatch.setattr("aegro.cli._config.get_config_dir", lambda: tmp_path)
    return tmp_path


@pytest.fixture(autouse=True)
def _clear_active_farm_env(monkeypatch):
    """Prevent operator AEGRO_ACTIVE_FARM from leaking into tests."""
    monkeypatch.delenv("AEGRO_ACTIVE_FARM", raising=False)
    monkeypatch.delenv("AEGRO_SAFE_MODE", raising=False)
