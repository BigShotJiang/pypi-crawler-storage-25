from __future__ import annotations

import json

from aegro.cli import app


class TestFiscalProductsGet:
    def test_get(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = {"_id": "fp1", "name": "Soja"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["fiscal-products", "get", "fiscalProduct::abc"])
        assert result.exit_code == 0
        mock_client.get.assert_called_once_with(
            "/pub/v1/fiscal-products/fiscalProduct::abc", api_key="key-1"
        )

    def test_get_not_found(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = None
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["fiscal-products", "get", "missing"])
        assert result.exit_code == 0
        assert "nao encontrad" in result.stdout.lower()


class TestFiscalProductsList:
    def test_list(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["fiscal-products", "list", "--search-text", "soja"])
        assert result.exit_code == 0
        body = mock_client.post.call_args.kwargs["json_body"]
        assert body["searchText"] == "soja"
        assert body["requiredPageNumber"] == 1


class TestFiscalProductsCreate:
    def test_create_minimal(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = {"_id": "fp-new"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(
            app,
            [
                "fiscal-products",
                "create",
                "--name",
                "Soja",
                "--code",
                "SOJA-001",
                "--description",
                "Soja em graos",
                "--ncm-code",
                "1201.90.00",
                "--measuring-unit",
                "sc 60kg",
            ],
        )
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["_id"] == "fp-new"
        body = mock_client.post.call_args.kwargs["json_body"]
        assert body["name"] == "Soja"
        assert body["code"] == "SOJA-001"
        assert body["ncmCode"] == "1201.90.00"
        assert body["measuringUnit"] == "sc 60kg"
        assert body["global"] is False

    def test_create_with_optionals(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = {"_id": "fp-new"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        runner.invoke(
            app,
            [
                "fiscal-products",
                "create",
                "--name",
                "X",
                "--code",
                "C",
                "--description",
                "D",
                "--ncm-code",
                "99999999",
                "--measuring-unit",
                "kg",
                "--cest-code",
                "01.001.00",
                "--gtin-code",
                "7891234567890",
                "--additional-information",
                "info",
                "--cbenef-code",
                "123456",
                "--taxable-measuring-unit",
                "kg",
                "--global-fiscal-product-key",
                "fiscalProduct::global",
            ],
        )
        body = mock_client.post.call_args.kwargs["json_body"]
        assert body["cestCode"] == "01.001.00"
        assert body["gtinCode"] == "7891234567890"
        assert body["cbenefCode"] == "123456"
        assert body["globalFiscalProductKey"] == "fiscalProduct::global"
