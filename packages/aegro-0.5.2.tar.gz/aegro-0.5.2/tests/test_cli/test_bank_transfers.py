from __future__ import annotations

import json

from aegro.cli import app


class TestBankTransfersGet:
    def test_get(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = {"_id": "bt1"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["bank-transfers", "get", "bankTransfer::abc"])
        assert result.exit_code == 0
        mock_client.get.assert_called_once_with(
            "/pub/v1/bank-transfers/bankTransfer::abc", api_key="key-1"
        )

    def test_get_not_found(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = None
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["bank-transfers", "get", "bt1"])
        assert result.exit_code == 0
        assert "nao encontrad" in result.stdout.lower()


class TestBankTransfersList:
    def test_list_defaults(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["bank-transfers", "list"])
        assert result.exit_code == 0
        call = mock_client.post.call_args
        assert call.args[0] == "/pub/v1/bank-transfers/filter"
        body = call.kwargs["json_body"]
        assert body["requiredPageNumber"] == 1

    def test_list_with_filters(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        runner.invoke(
            app,
            [
                "bank-transfers",
                "list",
                "--source-key",
                "ba1",
                "--target-key",
                "ba2",
                "--reconciliation-status",
                "CONFIRMED",
                "--tag",
                "caixa",
                "--start-date",
                "2025-01-01",
            ],
        )
        body = mock_client.post.call_args.kwargs["json_body"]
        assert body["sourceBankAccountKeys"] == ["ba1"]
        assert body["targetBankAccountKeys"] == ["ba2"]
        assert body["reconciliationStatuses"] == ["CONFIRMED"]
        assert body["tags"] == ["caixa"]
        assert body["startDate"] == "2025-01-01"


class TestBankTransfersCreate:
    def test_create(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = {"_id": "bt-new"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(
            app,
            [
                "bank-transfers",
                "create",
                "--source-key",
                "bankAccount::src",
                "--target-key",
                "bankAccount::tgt",
                "--amount",
                "2500.50",
                "--entry-date",
                "2025-06-01",
                "--description",
                "Transf",
                "--tag",
                "invest",
            ],
        )
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["_id"] == "bt-new"
        body = mock_client.post.call_args.kwargs["json_body"]
        assert body["sourceBankAccountKey"] == "bankAccount::src"
        assert body["targetBankAccountKey"] == "bankAccount::tgt"
        assert body["amount"] == {"amount": 2500.50, "currency": "BRL"}
        assert body["entryDate"] == "2025-06-01"
        assert body["description"] == "Transf"
        assert body["tags"] == ["invest"]
