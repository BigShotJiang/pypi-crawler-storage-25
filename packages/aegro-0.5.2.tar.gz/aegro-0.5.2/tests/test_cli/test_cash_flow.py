from __future__ import annotations

from aegro.cli import app


class TestCashFlow:
    def test_list_required_dates(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = {"cashFlow": {}}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(
            app,
            [
                "cash-flow",
                "list",
                "--start-date",
                "2025-01-01",
                "--end-date",
                "2025-12-31",
            ],
        )
        assert result.exit_code == 0
        call = mock_client.post.call_args
        assert call.args[0] == "/pub/v1/cash-flow/filter"
        body = call.kwargs["json_body"]
        assert body["startDate"] == "2025-01-01"
        assert body["endDate"] == "2025-12-31"

    def test_list_missing_required(self, runner, mock_settings, mock_client, temp_state):
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["cash-flow", "list"])
        assert result.exit_code != 0

    def test_list_with_filters(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = {}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        runner.invoke(
            app,
            [
                "cash-flow",
                "list",
                "--start-date",
                "2025-01-01",
                "--end-date",
                "2025-12-31",
                "--crop-key",
                "c1",
                "--crop-key",
                "c2",
                "--all-tag",
                "soja",
                "--any-tag",
                "2025",
                "--structure-type",
                "SYNTHETIC_FINANCIAL_CATEGORY",
            ],
        )
        body = mock_client.post.call_args.kwargs["json_body"]
        assert body["cropKeys"] == ["c1", "c2"]
        assert body["allTags"] == ["soja"]
        assert body["anyTags"] == ["2025"]
        assert body["structureType"] == "SYNTHETIC_FINANCIAL_CATEGORY"
