from __future__ import annotations

from typer.testing import CliRunner

from aegro.cli import app

runner = CliRunner()


class TestSkillsList:
    def test_list_shows_all_embedded_skills(self):
        result = runner.invoke(app, ["skills", "list"])
        assert result.exit_code == 0
        assert "aegro-visao-geral" in result.stdout
        assert "aegro-agronomo" in result.stdout

    def test_list_shows_count(self):
        result = runner.invoke(app, ["skills", "list"])
        assert result.exit_code == 0
        assert "12 skills" in result.stdout


class TestSkillsStatus:
    def test_status_not_installed(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "aegro.cli.skills.TOOL_DIRS", {"claude": tmp_path / ".claude" / "skills"}
        )
        result = runner.invoke(app, ["skills", "status"])
        assert result.exit_code == 0
        assert "not installed" in result.stdout

    def test_status_outdated(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        skill_dir = skills_dir / "aegro-visao-geral"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\nname: aegro-visao-geral\nversion: 0.1.0\n---\nold"
        )
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        result = runner.invoke(app, ["skills", "status"])
        assert result.exit_code == 0
        assert "0.1.0" in result.stdout
        assert "update" in result.stdout.lower() or "->" in result.stdout

    def test_status_installed(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        skill_dir = skills_dir / "aegro-visao-geral"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text(
            "---\nname: aegro-visao-geral\nversion: 0.2.0\n---\ntest"
        )
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        result = runner.invoke(app, ["skills", "status"])
        assert result.exit_code == 0
        assert "aegro-visao-geral" in result.stdout


class TestSkillsInstall:
    def test_install_all(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        result = runner.invoke(app, ["skills", "install"])
        assert result.exit_code == 0
        assert skills_dir.exists()
        installed = list(skills_dir.glob("aegro-*/SKILL.md"))
        assert len(installed) == 12

    def test_install_specific(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        result = runner.invoke(app, ["skills", "install", "aegro-visao-geral"])
        assert result.exit_code == 0
        assert (skills_dir / "aegro-visao-geral" / "SKILL.md").exists()
        assert not (skills_dir / "aegro-agronomo").exists()

    def test_install_invalid_name(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        result = runner.invoke(app, ["skills", "install", "nonexistent"])
        assert result.exit_code != 0

    def test_install_idempotent(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        runner.invoke(app, ["skills", "install"])
        result = runner.invoke(app, ["skills", "install"])
        assert result.exit_code == 0

    def test_install_force_overwrites(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        skill_dir = skills_dir / "aegro-visao-geral"
        skill_dir.mkdir(parents=True)
        (skill_dir / "SKILL.md").write_text("custom content")
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        result = runner.invoke(app, ["skills", "install", "--force"])
        assert result.exit_code == 0
        content = (skill_dir / "SKILL.md").read_text()
        assert "custom content" not in content

    def test_install_tool_all(self, tmp_path, monkeypatch):
        claude_dir = tmp_path / ".claude" / "skills"
        codex_dir = tmp_path / ".codex" / "skills"
        monkeypatch.setattr(
            "aegro.cli.skills.TOOL_DIRS", {"claude": claude_dir, "codex": codex_dir}
        )
        result = runner.invoke(app, ["skills", "install", "--tool", "all"])
        assert result.exit_code == 0
        assert len(list(claude_dir.glob("aegro-*/SKILL.md"))) == 12
        assert len(list(codex_dir.glob("aegro-*/SKILL.md"))) == 12

    def test_install_tool_unknown(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "aegro.cli.skills.TOOL_DIRS", {"claude": tmp_path / ".claude" / "skills"}
        )
        result = runner.invoke(app, ["skills", "install", "--tool", "unknown"])
        assert result.exit_code != 0

    def test_install_with_tool_flag(self, tmp_path, monkeypatch):
        codex_dir = tmp_path / ".codex" / "skills"
        monkeypatch.setattr(
            "aegro.cli.skills.TOOL_DIRS",
            {"codex": codex_dir, "claude": tmp_path / ".claude" / "skills"},
        )
        result = runner.invoke(app, ["skills", "install", "--tool", "codex"])
        assert result.exit_code == 0
        assert codex_dir.exists()
        installed = list(codex_dir.glob("aegro-*/SKILL.md"))
        assert len(installed) == 12


class TestSkillsUninstall:
    def test_uninstall_all(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        runner.invoke(app, ["skills", "install"])
        result = runner.invoke(app, ["skills", "uninstall"])
        assert result.exit_code == 0
        remaining = list(skills_dir.glob("aegro-*/SKILL.md"))
        assert len(remaining) == 0

    def test_uninstall_specific(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        runner.invoke(app, ["skills", "install"])
        result = runner.invoke(app, ["skills", "uninstall", "aegro-visao-geral"])
        assert result.exit_code == 0
        assert not (skills_dir / "aegro-visao-geral").exists()
        assert (skills_dir / "aegro-agronomo" / "SKILL.md").exists()

    def test_uninstall_not_installed(self, tmp_path, monkeypatch):
        skills_dir = tmp_path / ".claude" / "skills"
        monkeypatch.setattr("aegro.cli.skills.TOOL_DIRS", {"claude": skills_dir})
        result = runner.invoke(app, ["skills", "uninstall"])
        assert result.exit_code == 0
