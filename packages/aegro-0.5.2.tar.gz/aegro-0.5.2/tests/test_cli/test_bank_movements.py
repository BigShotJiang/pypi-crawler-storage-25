from __future__ import annotations

from aegro.cli import app


class TestBankMovementsList:
    def test_list_defaults(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["bank-movements", "list"])
        assert result.exit_code == 0
        call = mock_client.post.call_args
        assert call.args[0] == "/pub/v1/bank-account-movements/filter"
        body = call.kwargs["json_body"]
        assert body["requiredPageNumber"] == 1

    def test_list_with_filters(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        runner.invoke(
            app,
            [
                "bank-movements",
                "list",
                "--bank-account-key",
                "ba1",
                "--start-date",
                "2025-01-01",
                "--end-date",
                "2025-06-30",
                "--financial-flow-type",
                "INFLOW",
                "--reconciliation-status",
                "CONFIRMED",
                "--installment-key",
                "inst1",
                "--bank-transfer-key",
                "bt1",
                "--min-amount",
                "50.00",
                "--max-amount",
                "1000.00",
                "--currency",
                "USD",
            ],
        )
        body = mock_client.post.call_args.kwargs["json_body"]
        assert body["bankAccountKeys"] == ["ba1"]
        assert body["startDate"] == "2025-01-01"
        assert body["endDate"] == "2025-06-30"
        assert body["financialFlowTypes"] == ["INFLOW"]
        assert body["reconciliationStatuses"] == ["CONFIRMED"]
        assert body["installmentKeys"] == ["inst1"]
        assert body["bankTransferKeys"] == ["bt1"]
        assert body["minAmount"] == {"amount": 50.0, "currency": "USD"}
        assert body["maxAmount"] == {"amount": 1000.0, "currency": "USD"}

    def test_empty(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = None
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["bank-movements", "list"])
        assert result.exit_code == 0
        assert "nenhum" in result.stdout.lower()
