from __future__ import annotations

from aegro.cli import app


class TestCostsSummary:
    def test_by_asset(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["costs", "by-asset", "--crop-key", "crop::abc"])
        assert result.exit_code == 0
        call = mock_client.post.call_args
        assert call.args[0] == "/pub/v1/costs/summary/by-asset/filter"
        assert call.kwargs["json_body"] == {"cropKey": "crop::abc"}

    def test_by_element(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["costs", "by-element", "--crop-key", "crop::abc"])
        assert result.exit_code == 0
        assert mock_client.post.call_args.args[0] == "/pub/v1/costs/summary/by-element/filter"

    def test_by_category(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = []
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["costs", "by-category", "--crop-key", "crop::abc"])
        assert result.exit_code == 0
        assert (
            mock_client.post.call_args.args[0]
            == "/pub/v1/costs/summary/by-financial-category/filter"
        )

    def test_requires_crop_key(self, runner, mock_settings, mock_client, temp_state):
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["costs", "by-asset"])
        assert result.exit_code != 0
