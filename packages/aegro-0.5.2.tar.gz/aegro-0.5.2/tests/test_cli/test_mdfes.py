from __future__ import annotations

from aegro.cli import app


class TestMdfeXml:
    def test_download_xml(self, runner, mock_settings, mock_client, temp_state, tmp_path):
        mock_client.download.return_value = b"<mdfe>xml</mdfe>"
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        out = tmp_path / "mdfe.xml"
        result = runner.invoke(app, ["mdfes", "xml", "mdfe::abc", "-o", str(out)])
        assert result.exit_code == 0
        assert out.read_bytes() == b"<mdfe>xml</mdfe>"
        mock_client.download.assert_called_once_with("/pub/v1/mdfes/mdfe::abc/xml", api_key="key-1")


class TestMdfeXmlBatch:
    def test_batch(self, runner, mock_settings, mock_client, temp_state, tmp_path):
        mock_client.download.return_value = b"PK\x03\x04"
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        out = tmp_path / "mdfes.zip"
        result = runner.invoke(
            app,
            [
                "mdfes",
                "xml-batch",
                "-o",
                str(out),
                "--issued-start-date",
                "2025-01-01",
                "--issued-end-date",
                "2025-12-31",
                "--status",
                "AUTHORIZED",
                "--series",
                "1",
            ],
        )
        assert result.exit_code == 0
        assert out.read_bytes() == b"PK\x03\x04"
        body = mock_client.download.call_args.kwargs["json_body"]
        assert body["issuedStartDate"] == "2025-01-01"
        assert body["issuedEndDate"] == "2025-12-31"
        assert body["status"] == ["AUTHORIZED"]
        assert body["series"] == ["1"]
