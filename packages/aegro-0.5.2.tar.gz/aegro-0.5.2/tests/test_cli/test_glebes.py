from __future__ import annotations

import json


from aegro.cli import app


class TestGlebesGet:
    def test_get_glebe(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = {"_id": "g-1", "name": "Talhao A"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["glebes", "get", "g-1"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["name"] == "Talhao A"
        mock_client.get.assert_called_once_with("/pub/v1/glebes/g-1", api_key="key-1")

    def test_get_glebe_not_found(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = None
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["glebes", "get", "missing"])
        assert result.exit_code == 0
        assert "nao encontrad" in result.stdout.lower()


class TestGlebesList:
    def test_list(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = [{"_id": "g-1", "name": "Talhao A"}]
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["glebes", "list"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert len(data) == 1
        call_body = mock_client.post.call_args.kwargs["json_body"]
        assert call_body["requiredPageNumber"] == 1
        assert call_body["maximumItemsPerPageCount"] == 50
        assert mock_client.post.call_args.args[0] == "/pub/v1/glebes/filter"
