from __future__ import annotations

import json


from aegro.cli import app


class TestAssetsGet:
    def test_get_asset(self, runner, mock_settings, mock_client, temp_state):
        mock_client.get.return_value = {"_id": "a-1", "name": "Trator JD"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["assets", "get", "a-1"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["name"] == "Trator JD"
        mock_client.get.assert_called_once_with("/pub/v1/assets/a-1", api_key="key-1")


class TestAssetsList:
    def test_list(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = [{"_id": "a-1", "name": "Trator"}]
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(app, ["assets", "list"])
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert len(data) == 1
        call_body = mock_client.post.call_args.kwargs["json_body"]
        assert call_body["requiredPageNumber"] == 1
        assert call_body["maximumItemsPerPageCount"] == 50
        assert mock_client.post.call_args.args[0] == "/pub/v1/assets/filter"


class TestAssetsCreateMachine:
    def test_create_machine(self, runner, mock_settings, mock_client, temp_state):
        mock_client.post.return_value = {"_id": "m-1", "name": "Trator John Deere"}
        runner.invoke(app, ["farms", "select", "Fazenda Sul"])
        result = runner.invoke(
            app,
            [
                "assets",
                "create-machine",
                "--name",
                "Trator John Deere",
                "--manufacturer",
                "John Deere",
                "--machine-type",
                "TRACTOR",
                "--manufacture-year",
                "2023",
            ],
        )
        assert result.exit_code == 0
        data = json.loads(result.stdout)
        assert data["name"] == "Trator John Deere"
        assert mock_client.post.call_args.args[0] == "/pub/v1/assets/machines"
        call_body = mock_client.post.call_args.kwargs["json_body"]
        assert call_body["name"] == "Trator John Deere"
        assert call_body["type"] == "MACHINE"
        assert call_body["manufacturer"] == "John Deere"
        assert call_body["machineType"] == "TRACTOR"
        assert call_body["manufactureYear"] == 2023
