from aegro.errors import AegroAPIError, translate_api_error


def test_translate_401():
    err = translate_api_error(401, {"message": "Invalid token"})
    assert isinstance(err, AegroAPIError)
    assert "API Key invalida" in err.user_message
    assert err.status_code == 401


def test_translate_403():
    err = translate_api_error(403, {})
    assert "permissao" in err.user_message.lower()


def test_translate_404():
    err = translate_api_error(404, {})
    assert "nao encontrado" in err.user_message.lower()


def test_translate_422_with_details():
    body = {"errors": [{"field": "cropKey", "message": "required"}]}
    err = translate_api_error(422, body)
    assert "validacao" in err.user_message.lower()
    assert "cropKey" in err.user_message


def test_translate_429():
    err = translate_api_error(429, {})
    assert "limite" in err.user_message.lower()


def test_translate_500():
    err = translate_api_error(500, {})
    assert "indisponivel" in err.user_message.lower()
    assert err.retryable is True


def test_translate_204():
    err = translate_api_error(204, {})
    assert "Nenhum resultado" in err.user_message


def test_translate_400():
    err = translate_api_error(400, {"message": "Bad request detail"})
    assert "invalida" in err.user_message.lower()


def test_no_farm_selected_error():
    from aegro.errors import NoFarmSelectedError

    err = NoFarmSelectedError()
    assert "aegro farms select" in str(err)


def test_farm_not_found_error():
    from aegro.errors import FarmNotFoundError

    err = FarmNotFoundError("Fazenda X")
    assert "Fazenda X" in str(err)
