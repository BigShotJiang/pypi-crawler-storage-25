from __future__ import annotations


class AegroAPIError(Exception):
    def __init__(self, status_code: int, user_message: str, *, retryable: bool = False):
        self.status_code = status_code
        self.user_message = user_message
        self.retryable = retryable
        super().__init__(user_message)


class NoFarmSelectedError(Exception):
    def __init__(self, available_farms: list[str] | None = None):
        self.available_farms = available_farms or []
        if len(self.available_farms) > 1:
            farms_list = ", ".join(self.available_farms)
            super().__init__(
                f"Nenhuma fazenda ativa e ha multiplas configuradas ({farms_list}). "
                "Defina AEGRO_ACTIVE_FARM=<nome> (recomendado para orquestracao via "
                "Claude Cowork) ou execute 'aegro farms select <nome>'."
            )
        else:
            super().__init__(
                "Nenhuma fazenda selecionada. Defina AEGRO_ACTIVE_FARM=<nome> "
                "ou execute 'aegro farms select <nome>' antes de realizar operacoes."
            )


class FarmNotFoundError(Exception):
    def __init__(self, farm_name: str):
        self.farm_name = farm_name
        super().__init__(
            f"Fazenda '{farm_name}' nao encontrada na configuracao. "
            "Use 'aegro farms list' para ver as fazendas disponiveis."
        )


class SafeModeBlockedError(Exception):
    def __init__(self, action: str):
        self.action = action
        super().__init__(
            f"Mutacao bloqueada por AEGRO_SAFE_MODE para '{action}'. "
            "Use --dry-run para validar a requisicao ou --execute para executar."
        )


class InvalidKeyError(ValueError):
    def __init__(self, key: str):
        self.key = key
        super().__init__(f"Chave invalida: '{key}'. Chaves nao podem conter /, ?, # ou espacos.")


def _extract_validation_details(body: dict) -> str:
    errors = body.get("errors", [])
    if not errors:
        return ""
    details = []
    for err in errors:
        field = err.get("field", "")
        msg = err.get("message", "")
        if field:
            details.append(f"{field}: {msg}" if msg else field)
    return " | ".join(details)


def translate_api_error(status_code: int, body: dict | None = None) -> AegroAPIError:
    body = body or {}
    messages = {
        204: ("Nenhum resultado encontrado para os filtros fornecidos.", False),
        400: ("Requisicao invalida: {detail}. Verifique os parametros.", False),
        401: ("API Key invalida ou expirada. Verifique a configuracao da fazenda.", False),
        403: ("Sem permissao para acessar este recurso na fazenda atual.", False),
        404: ("Recurso nao encontrado com a chave fornecida.", False),
        422: ("Erro de validacao: {detail}.", False),
        429: ("Limite de requisicoes atingido. Aguarde antes de tentar novamente.", False),
    }
    if status_code >= 500:
        return AegroAPIError(
            status_code,
            "Servico Aegro temporariamente indisponivel. Tente novamente em instantes.",
            retryable=True,
        )
    template, retryable = messages.get(status_code, ("Erro inesperado (HTTP {code}).", False))
    detail = ""
    if status_code == 422:
        detail = _extract_validation_details(body) or body.get("message", "campos invalidos")
    elif status_code == 400:
        detail = body.get("message", "verifique os dados enviados")
    msg = template.format(detail=detail, code=status_code)
    return AegroAPIError(status_code, msg, retryable=retryable)
