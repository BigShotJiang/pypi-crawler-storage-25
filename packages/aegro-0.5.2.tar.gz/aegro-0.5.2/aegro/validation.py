from __future__ import annotations

import re

from aegro.errors import InvalidKeyError

_UNSAFE_KEY_RE = re.compile(r"[/?#\s]")


def validate_key(key: str) -> str:
    """Validate that a resource key is safe for URL path interpolation.

    Raises InvalidKeyError if the key contains /, ?, #, or whitespace.
    """
    if _UNSAFE_KEY_RE.search(key):
        raise InvalidKeyError(key)
    return key
