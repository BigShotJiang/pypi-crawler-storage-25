from __future__ import annotations

import os

import typer

from aegro.cli._auth import (
    CREDENTIALS_FILE_NAME,
    load_credentials,
    remove_credentials,
    save_credentials,
    validate_api_key,
)
from aegro.cli._paths import get_config_dir

auth_app = typer.Typer(help="Gerenciar autenticacao com o Aegro.")


@auth_app.command("login")
def login(
    api_key: str = typer.Option(..., "--api-key", help="API key da fazenda."),
    farm_name: str = typer.Option(
        None, "--farm-name", help="Nome da fazenda (detectado automaticamente se omitido)."
    ),
) -> None:
    """Adicionar credenciais de uma fazenda.

    O nome da fazenda e detectado automaticamente a partir da API key.
    Use --farm-name para sobrescrever o nome detectado.

    Salva a API key no diretorio de configuracao do aegro.
    Use varias vezes para adicionar multiplas fazendas.

    EXAMPLES:
      aegro auth login --api-key "aegro_abc123..."
      aegro auth login --api-key "aegro_abc123..." --farm-name "Meu Apelido"
    """
    if not validate_api_key(api_key):
        typer.echo("API key invalida (vazia ou apenas espacos).", err=True)
        raise typer.Exit(1)

    if farm_name is None:
        farm_name = _resolve_farm_name(api_key)

    existing = load_credentials()
    if farm_name in existing:
        typer.echo(f"Atualizando credenciais para '{farm_name}' (ja existia).", err=True)
    existing[farm_name] = api_key
    try:
        save_credentials(existing)
    except OSError as exc:
        typer.echo(f"Erro ao salvar credenciais: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"Credenciais salvas para '{farm_name}'.")
    typer.echo("Para instalar skills do Aegro no Claude Code: aegro skills install", err=True)


def _resolve_farm_name(api_key: str) -> str:
    """Call the Aegro API to discover the farm name from an API key."""
    from aegro.cli._client import SyncAegroClient

    client = SyncAegroClient()
    try:
        result = client.get("/pub/v1/farms", api_key=api_key)
    except Exception as exc:
        typer.echo(f"Erro ao consultar API: {exc}", err=True)
        typer.echo("Use --farm-name para informar o nome manualmente.", err=True)
        raise typer.Exit(1)

    if isinstance(result, dict) and result.get("name"):
        name = result["name"]
        typer.echo(f"Fazenda detectada: {name}")
        return name

    typer.echo("Nao foi possivel detectar o nome da fazenda a partir da API key.", err=True)
    typer.echo("Use --farm-name para informar o nome manualmente.", err=True)
    raise typer.Exit(1)


@auth_app.command("status")
def status() -> None:
    """Verificar status de autenticacao.

    Mostra fazendas configuradas e a origem das credenciais.

    EXAMPLES:
      aegro auth status
    """
    farms = load_credentials()

    if not farms:
        typer.echo("Nenhuma credencial configurada.")
        typer.echo("Use 'aegro auth login' ou defina AEGRO_FARMS.")
        return

    if os.environ.get("AEGRO_FARMS"):
        source = "AEGRO_FARMS (env var)"
    elif os.environ.get("AEGRO_FARMS_FILE"):
        source = f"AEGRO_FARMS_FILE ({os.environ['AEGRO_FARMS_FILE']})"
    else:
        source = str(get_config_dir() / CREDENTIALS_FILE_NAME)

    typer.echo("Autenticacao: API Key")
    typer.echo(f"Origem: {source}")
    typer.echo(f"Fazendas configuradas ({len(farms)}):")
    for name in sorted(farms.keys()):
        key = farms[name]
        masked = f"***...{key[-3:]}" if len(key) > 3 else "***"
        typer.echo(f"  - {name} ({masked})")


@auth_app.command("logout")
def logout() -> None:
    """Remover credenciais salvas.

    Remove credenciais do diretorio de configuracao do aegro.
    Nao afeta credenciais via env vars.

    EXAMPLES:
      aegro auth logout
    """
    removed = remove_credentials()
    if removed:
        typer.echo("Credenciais removidas.")
    else:
        typer.echo("Nenhuma credencial local encontrada.")
