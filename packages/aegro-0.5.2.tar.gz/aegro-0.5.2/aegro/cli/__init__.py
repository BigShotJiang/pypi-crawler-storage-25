from __future__ import annotations

import typer

_EPILOG = (
    "Variaveis de ambiente: "
    "[bold]AEGRO_FARMS[/] (JSON fazenda->key), "
    "[bold]AEGRO_FARMS_FILE[/] (path JSON), "
    "[bold]AEGRO_ACTIVE_FARM[/] (fazenda ativa, precede 'farms select'), "
    "[bold]AEGRO_CONFIG_DIR[/], "
    "[bold]AEGRO_API_BASE_URL[/], "
    "[bold]AEGRO_SAFE_MODE[/] (bloqueia mutacoes sem --execute)."
    "\n\n"
    "[bold]Multi-fazenda (Claude Cowork)[/]: defina "
    "[bold]AEGRO_ACTIVE_FARM[/] por sessao/projeto para evitar que "
    "'farms select' de outra sessao contamine esta. Veja "
    "'aegro farms --help' para a ordem de resolucao."
)


app = typer.Typer(
    name="aegro",
    help="CLI para gerenciamento agricola via API Aegro.",
    epilog=_EPILOG,
    invoke_without_command=True,
)


@app.callback(invoke_without_command=True)
def _callback(ctx: typer.Context) -> None:
    """CLI para gerenciamento agricola via API Aegro."""
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


from aegro.cli.activities import activities_app  # noqa: E402
from aegro.cli.assets import assets_app  # noqa: E402
from aegro.cli.auth import auth_app  # noqa: E402
from aegro.cli.bank_accounts import bank_accounts_app  # noqa: E402
from aegro.cli.bank_movements import bank_movements_app  # noqa: E402
from aegro.cli.bank_transfers import bank_transfers_app  # noqa: E402
from aegro.cli.cash_flow import cash_flow_app  # noqa: E402
from aegro.cli.catalogs import catalogs_app  # noqa: E402
from aegro.cli.companies import companies_app  # noqa: E402
from aegro.cli.costs import costs_app  # noqa: E402
from aegro.cli.crop_glebes import crop_glebes_app  # noqa: E402
from aegro.cli.crops import crops_app  # noqa: E402
from aegro.cli.elements import elements_app  # noqa: E402
from aegro.cli.farms import farms_app  # noqa: E402
from aegro.cli.financial import financial_app  # noqa: E402
from aegro.cli.financial_categories import fin_categories_app  # noqa: E402
from aegro.cli.fiscal_products import fiscal_products_app  # noqa: E402
from aegro.cli.fuel_supplies import fuel_supplies_app  # noqa: E402
from aegro.cli.glebes import glebes_app  # noqa: E402
from aegro.cli.harvest_logs import harvest_logs_app  # noqa: E402
from aegro.cli.maintenances import maintenances_app  # noqa: E402
from aegro.cli.mdfes import mdfes_app  # noqa: E402
from aegro.cli.nfes import nfes_app  # noqa: E402
from aegro.cli.purchase_orders import purchase_orders_app  # noqa: E402
from aegro.cli.purchase_requisitions import purchase_requisitions_app  # noqa: E402
from aegro.cli.stock import stock_app  # noqa: E402
from aegro.cli.tags import tags_app  # noqa: E402
from aegro.cli.skills import skills_app  # noqa: E402
from aegro.cli.weather import weather_app  # noqa: E402

app.add_typer(activities_app, name="activities")
app.add_typer(assets_app, name="assets")
app.add_typer(auth_app, name="auth")
app.add_typer(bank_accounts_app, name="bank-accounts")
app.add_typer(bank_movements_app, name="bank-movements")
app.add_typer(bank_transfers_app, name="bank-transfers")
app.add_typer(cash_flow_app, name="cash-flow")
app.add_typer(catalogs_app, name="catalogs")
app.add_typer(companies_app, name="companies")
app.add_typer(costs_app, name="costs")
app.add_typer(crop_glebes_app, name="crop-glebes")
app.add_typer(crops_app, name="crops")
app.add_typer(elements_app, name="elements")
app.add_typer(farms_app, name="farms")
app.add_typer(financial_app, name="financial")
app.add_typer(fin_categories_app, name="fin-categories")
app.add_typer(fiscal_products_app, name="fiscal-products")
app.add_typer(fuel_supplies_app, name="fuel-supplies")
app.add_typer(glebes_app, name="glebes")
app.add_typer(harvest_logs_app, name="harvest-logs")
app.add_typer(maintenances_app, name="maintenances")
app.add_typer(mdfes_app, name="mdfes")
app.add_typer(nfes_app, name="nfes")
app.add_typer(purchase_orders_app, name="purchase-orders")
app.add_typer(purchase_requisitions_app, name="purchase-requisitions")
app.add_typer(skills_app, name="skills")
app.add_typer(stock_app, name="stock")
app.add_typer(tags_app, name="tags")
app.add_typer(weather_app, name="weather")


def main() -> None:
    """Entry point for the aegro CLI."""
    app()
