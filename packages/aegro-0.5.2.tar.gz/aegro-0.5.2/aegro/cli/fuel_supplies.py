from __future__ import annotations

from typing import Optional

import typer

from aegro.cli._config import get_client, require_farm
from aegro.cli._errors import handle_error
from aegro.cli._mutations import dry_run_option, execute_option, guard_mutation
from aegro.cli._output import OutputFormat, format_output
from aegro.validation import validate_key

fuel_supplies_app = typer.Typer(help="Abastecimentos de combustivel de ativos.")


@fuel_supplies_app.command("get")
def get_fuel_supply(
    key: str = typer.Argument(help="Chave unica do abastecimento."),
    output: OutputFormat = typer.Option(
        OutputFormat.json, "--output", "-o", help="Formato: json|table|csv"
    ),
) -> None:
    """Retorna os dados de um abastecimento pelo seu identificador.

    EXAMPLES:
      aegro fuel-supplies get abc123
      aegro fuel-supplies get abc123 --output table
    """
    try:
        _, api_key = require_farm()
        client = get_client()
        result = client.get(f"/pub/v1/assets/fuel-supplies/{validate_key(key)}", api_key=api_key)
        if result is None:
            typer.echo("Abastecimento nao encontrado.")
            return
        typer.echo(format_output(result, output))
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception as exc:
        handle_error(exc)


@fuel_supplies_app.command("list")
def list_fuel_supplies(
    asset_key: Optional[list[str]] = typer.Option(
        None, "--asset-key", help="Chave do ativo (repetivel para multiplos)."
    ),
    start_date: Optional[str] = typer.Option(
        None, "--start-date", help="Data inicial (YYYY-MM-DD)."
    ),
    end_date: Optional[str] = typer.Option(None, "--end-date", help="Data final (YYYY-MM-DD)."),
    page: int = typer.Option(1, "--page", help="Numero da pagina."),
    output: OutputFormat = typer.Option(
        OutputFormat.json, "--output", "-o", help="Formato: json|table|csv"
    ),
) -> None:
    """Lista abastecimentos de combustivel com filtros opcionais.

    EXAMPLES:
      aegro fuel-supplies list
      aegro fuel-supplies list --asset-key a1 --asset-key a2
      aegro fuel-supplies list --start-date 2025-01-01 --end-date 2025-12-31 --page 2
    """
    try:
        _, api_key = require_farm()
        client = get_client()
        body: dict = {
            "requiredPageNumber": page,
            "maximumItemsPerPageCount": 50,
        }
        if asset_key:
            body["assetKeys"] = asset_key
        if start_date is not None:
            body["startDate"] = start_date
        if end_date is not None:
            body["endDate"] = end_date
        result = client.post("/pub/v1/assets/fuel-supplies/filter", api_key=api_key, json_body=body)
        if result is None:
            typer.echo("Nenhum abastecimento encontrado.")
            return
        typer.echo(format_output(result, output))
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception as exc:
        handle_error(exc)


@fuel_supplies_app.command("create")
def create_fuel_supply(
    asset_key: str = typer.Option(..., "--asset-key", help="Chave do ativo."),
    date: str = typer.Option(..., "--date", help="Data da ocorrencia (YYYY-MM-DD)."),
    hourmeter: Optional[float] = typer.Option(
        None, "--hourmeter", help="Horimetro no momento do abastecimento."
    ),
    observations: Optional[str] = typer.Option(
        None, "--observations", help="Observacoes opcionais."
    ),
    stock_location_key: Optional[str] = typer.Option(
        None, "--stock-location-key", help="Chave do local de estoque."
    ),
    dry_run: bool = dry_run_option(),
    execute: bool = execute_option(),
    output: OutputFormat = typer.Option(
        OutputFormat.json, "--output", "-o", help="Formato: json|table|csv"
    ),
) -> None:
    """Cria um novo abastecimento de combustivel.

    EXAMPLES:
      aegro fuel-supplies create --asset-key a1 --date 2025-06-01
      aegro fuel-supplies create --asset-key a1 --date 2025-06-01 --hourmeter 1500.5 --observations "Diesel S10"
    """
    try:
        farm_name, api_key = require_farm()
        body: dict = {
            "assetKey": asset_key,
            "occurrenceDate": date,
        }
        if hourmeter is not None:
            body["hourmeterAtOccurrence"] = hourmeter
        if observations is not None:
            body["observations"] = observations
        if stock_location_key is not None:
            body["stockLocationKey"] = stock_location_key
        guard_mutation(
            farm=farm_name,
            action="fuel-supplies create",
            method="POST",
            path="/pub/v1/assets/fuel-supplies",
            body=body,
            dry_run=dry_run,
            execute=execute,
        )
        client = get_client()
        result = client.post("/pub/v1/assets/fuel-supplies", api_key=api_key, json_body=body)
        if result is None:
            typer.echo(f"Abastecimento criado na fazenda '{farm_name}'.")
        else:
            typer.echo(format_output(result, output))
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception as exc:
        handle_error(exc)


@fuel_supplies_app.command("update")
def update_fuel_supply(
    key: str = typer.Argument(help="Chave unica do abastecimento."),
    asset_key: Optional[str] = typer.Option(None, "--asset-key", help="Chave do ativo."),
    date: Optional[str] = typer.Option(None, "--date", help="Data da ocorrencia (YYYY-MM-DD)."),
    hourmeter: Optional[float] = typer.Option(
        None, "--hourmeter", help="Horimetro no momento do abastecimento."
    ),
    observations: Optional[str] = typer.Option(
        None, "--observations", help="Observacoes opcionais."
    ),
    stock_location_key: Optional[str] = typer.Option(
        None, "--stock-location-key", help="Chave do local de estoque."
    ),
    dry_run: bool = dry_run_option(),
    execute: bool = execute_option(),
    output: OutputFormat = typer.Option(
        OutputFormat.json, "--output", "-o", help="Formato: json|table|csv"
    ),
) -> None:
    """Atualiza um abastecimento de combustivel existente.

    EXAMPLES:
      aegro fuel-supplies update abc123 --date 2025-06-02
      aegro fuel-supplies update abc123 --hourmeter 1600 --observations "Correcao"
    """
    try:
        farm_name, api_key = require_farm()
        body: dict = {}
        if asset_key is not None:
            body["assetKey"] = asset_key
        if date is not None:
            body["occurrenceDate"] = date
        if hourmeter is not None:
            body["hourmeterAtOccurrence"] = hourmeter
        if observations is not None:
            body["observations"] = observations
        if stock_location_key is not None:
            body["stockLocationKey"] = stock_location_key
        path = f"/pub/v1/assets/fuel-supplies/{validate_key(key)}"
        guard_mutation(
            farm=farm_name,
            action="fuel-supplies update",
            method="PUT",
            path=path,
            body=body,
            dry_run=dry_run,
            execute=execute,
        )
        client = get_client()
        result = client.put(
            path,
            api_key=api_key,
            json_body=body,
        )
        if result is None:
            typer.echo(f"Abastecimento atualizado na fazenda '{farm_name}'.")
        else:
            typer.echo(format_output(result, output))
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception as exc:
        handle_error(exc)
