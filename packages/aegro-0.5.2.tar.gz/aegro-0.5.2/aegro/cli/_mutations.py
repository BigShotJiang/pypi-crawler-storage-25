from __future__ import annotations

import json
import os
import re
import sys
from typing import Any

import typer

from aegro.errors import SafeModeBlockedError

SAFE_MODE_ENV = "AEGRO_SAFE_MODE"
SAFE_MODE_TRUE_VALUES = {"1", "true", "yes", "on"}
_TEST_VALUE_RE = re.compile(r"\b(teste|test|dummy|sample|exemplo)\b", re.IGNORECASE)


def dry_run_option() -> bool:
    return typer.Option(
        False,
        "--dry-run",
        help="Mostra a requisicao que seria enviada, sem alterar dados.",
    )


def execute_option() -> bool:
    return typer.Option(
        False,
        "--execute",
        help=f"Executa a mutacao mesmo quando {SAFE_MODE_ENV}=1.",
    )


def is_safe_mode_enabled(value: str | None = None) -> bool:
    if value is None:
        value = os.environ.get(SAFE_MODE_ENV)
    if value is None:
        return False
    return value.strip().lower() in SAFE_MODE_TRUE_VALUES


def detect_test_value_warnings(body: Any) -> list[str]:
    warnings: list[str] = []

    def visit(value: Any, path: str) -> None:
        if isinstance(value, str):
            if _TEST_VALUE_RE.search(value):
                warnings.append(f"Valor com aparencia de teste em {path}: {value}")
            return
        if isinstance(value, dict):
            for key, child in value.items():
                visit(child, f"{path}.{key}" if path else str(key))
            return
        if isinstance(value, list):
            for idx, child in enumerate(value):
                visit(child, f"{path}[{idx}]")

    visit(body, "body")
    return list(dict.fromkeys(warnings))


def mutation_preview(
    *,
    farm: str,
    action: str,
    method: str,
    path: str,
    body: Any = None,
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "dryRun": True,
        "farm": farm,
        "action": action,
        "method": method.upper(),
        "path": path,
        "body": {} if body is None else body,
        "warnings": warnings or [],
    }


def guard_mutation(
    *,
    farm: str,
    action: str,
    method: str,
    path: str,
    body: Any = None,
    dry_run: bool = False,
    execute: bool = False,
) -> None:
    warnings = detect_test_value_warnings(body)
    if dry_run:
        typer.echo(
            json.dumps(
                mutation_preview(
                    farm=farm,
                    action=action,
                    method=method,
                    path=path,
                    body=body,
                    warnings=warnings,
                ),
                ensure_ascii=False,
                indent=2,
            )
        )
        raise SystemExit(0)

    if is_safe_mode_enabled() and not execute:
        raise SafeModeBlockedError(action)

    for warning in warnings:
        print(f"aegro: aviso: {warning}", file=sys.stderr)
