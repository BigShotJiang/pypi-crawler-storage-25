from __future__ import annotations

import os

import typer

from aegro.cli._config import (
    AEGRO_ACTIVE_FARM_ENV,
    get_active_farm_source,
    get_client,
    get_selected_farm,
    get_settings,
    set_selected_farm,
)
from aegro.cli._errors import handle_error
from aegro.cli._output import OutputFormat, format_output

_FARMS_EPILOG = (
    "[bold]Resolucao da fazenda ativa[/] (prioridade): "
    "(1) [bold]AEGRO_ACTIVE_FARM[/] env var — escopo de processo/sessao. "
    "(2) state.json — escrito por 'farms select', global por maquina."
    "\n\n"
    "Em [bold]Claude Cowork[/] e outros contextos multi-fazenda, prefira "
    "AEGRO_ACTIVE_FARM por sessao/projeto. 'farms select' grava global e "
    "pode ser sobrescrito por outra sessao em paralelo."
    "\n\n"
    "'farms list' expoe o campo [bold]source[/] indicando a origem da "
    "selecao ativa ('env', 'state' ou null)."
)


farms_app = typer.Typer(help="Gerenciar fazendas.", epilog=_FARMS_EPILOG)


@farms_app.command("list")
def list_farms(
    output: OutputFormat = typer.Option(
        OutputFormat.json, "--output", "-o", help="Formato: json|table|csv"
    ),
) -> None:
    """Lista todas as fazendas disponiveis.

    Campo `source` indica a origem da selecao ativa: "env" (AEGRO_ACTIVE_FARM),
    "state" (state.json) ou null para fazendas inativas.

    EXAMPLES:
      aegro farms list
      aegro farms list --output table
    """
    settings = get_settings()
    current = get_selected_farm()
    source = get_active_farm_source() if current else "none"
    farms = [
        {
            "name": name,
            "active": name == current,
            "source": source if name == current else None,
        }
        for name in settings.farm_names()
    ]
    typer.echo(format_output(farms, output))


@farms_app.command("select")
def select_farm(
    farm_name: str = typer.Argument(help="Nome exato da fazenda."),
) -> None:
    """Seleciona a fazenda ativa para operacoes subsequentes.

    Persiste em state.json (global por maquina). Para escopo por sessao/projeto
    (ex.: Claude Cowork operando multiplas fazendas em paralelo), prefira
    AEGRO_ACTIVE_FARM=<nome>, que tem precedencia sobre este comando.

    EXAMPLES:
      aegro farms select "Fazenda Sul"
    """
    settings = get_settings()
    if farm_name not in settings.farms:
        names = ", ".join(settings.farm_names())
        typer.echo(
            f"Fazenda '{farm_name}' nao encontrada. Disponiveis: {names}",
            err=True,
        )
        raise typer.Exit(1)
    set_selected_farm(farm_name)

    env_override = os.environ.get(AEGRO_ACTIVE_FARM_ENV, "").strip()
    if env_override:
        typer.echo(
            f"Aviso: AEGRO_ACTIVE_FARM='{env_override}' esta definida e tem "
            f"precedencia sobre esta selecao. Remova a variavel de ambiente "
            f"ou ajuste-a para usar '{farm_name}'.",
            err=True,
        )
    typer.echo(f"Fazenda ativa: {farm_name}")


@farms_app.command("info")
def farm_info(
    output: OutputFormat = typer.Option(
        OutputFormat.json, "--output", "-o", help="Formato: json|table|csv"
    ),
) -> None:
    """Mostra informacoes da fazenda ativa via API.

    EXAMPLES:
      aegro farms info
      aegro farms info --output table
    """
    try:
        from aegro.cli._config import require_farm

        _, api_key = require_farm()
        client = get_client()
        result = client.get("/pub/v1/farms", api_key=api_key)
        if result is None:
            typer.echo("Nenhum dado retornado para esta fazenda.")
            return
        typer.echo(format_output(result, output))
    except (SystemExit, KeyboardInterrupt):
        raise
    except Exception as exc:
        handle_error(exc)
