"""JSON-RPC 2.0 protocol helpers for the MCP server."""
import json

PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INTERNAL_ERROR = -32603

TOOL_DEFINITIONS = [
    {
        "name": "index_repository",
        "description": (
            "Index a repository to build a code intelligence graph. "
            "MUST be called before get_architecture, find_dead_code, or find_routes. "
            "Parses Python, JavaScript, and TypeScript files using tree-sitter. "
            "Indexing takes 1-5 seconds for typical repos."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute path to the repository root."},
                "force": {"type": "boolean", "description": "Force re-indexing even if already indexed."},
            },
            "required": ["path"],
        },
    },
    {
        "name": "get_architecture",
        "description": (
            "Get a high-level architectural overview: languages, packages, key files, entry points. "
            "Much more efficient than reading the entire repo. "
            "Requires index_repository first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "find_dead_code",
        "description": (
            "Find functions and methods with zero references — likely dead code. "
            "Scans the entire call graph and returns symbols that are never called. "
            "No grep equivalent — would require O(N^2) reference checks. "
            "Requires index_repository first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Maximum results (default: 200)."},
            },
        },
    },
    {
        "name": "find_routes",
        "description": (
            "Find all HTTP route handlers in the codebase. "
            "Returns functions that handle GET/POST/PUT/DELETE/etc. routes with their paths. "
            "No grep equivalent — detects routes from the call graph, not regex patterns. "
            "Requires index_repository first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Maximum results (default: 200)."},
            },
        },
    },
    {
        "name": "trace_fan",
        "description": (
            "Fan-out or fan-in from a function through the call graph. "
            "Accepts plain function names — no qualified name lookup needed. "
            "direction='outbound' traces what the function calls; "
            "direction='inbound' traces who calls the function. "
            "Requires index_repository first."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "function_name": {"type": "string", "description": "Function name or qualified name to trace from."},
                "direction": {
                    "type": "string",
                    "enum": ["outbound", "inbound"],
                    "description": "Trace direction. 'outbound': what this function calls. 'inbound': who calls this function.",
                },
                "depth": {"type": "integer", "description": "Maximum hop depth (default: 3)."},
            },
            "required": ["function_name"],
        },
    },
    {
        "name": "clean_html",
        "description": (
            "Strip noise from HTML and convert to token-optimized markdown or text. "
            "Reads the file server-side so raw HTML never enters agent context. "
            "Removes scripts, styles, navigation, ads, and other irrelevant content. "
            "Typically saves 60-90% of tokens. Does NOT require index_repository."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute path to the HTML file to clean."},
                "html": {"type": "string", "description": "Raw HTML content to clean (use path instead when possible)."},
                "mode": {
                    "type": "string",
                    "enum": ["markdown", "text", "minimal"],
                    "description": "Output mode. 'markdown' (default): semantic markdown. 'text': plain text. 'minimal': light clean, keep HTML.",
                },
            },
        },
    },
    {
        "name": "compact_json",
        "description": (
            "Convert JSON to a token-optimized format (CSV or YAML). "
            "Reads the file server-side so raw JSON never enters agent context. "
            "Auto-detects: CSV for flat/tabular data (saves 50-70%), YAML for nested data (saves 20-30%). "
            "Does NOT require index_repository."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute path to the JSON file to compact."},
                "json": {"type": "string", "description": "Raw JSON string to compact (use path instead when possible)."},
            },
        },
    },
    {
        "name": "search_markdown",
        "description": (
            "Search a markdown file for relevant sections by keyword. "
            "Reads the file server-side so the full content never enters agent context. "
            "Returns only matching sections ranked by precision. "
            "Empty query returns the header tree. Does NOT require index_repository."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute path to the markdown file to search."},
                "query": {"type": "string", "description": "Search keywords. Empty string returns header tree only."},
            },
            "required": ["path", "query"],
        },
    },
    {
        "name": "compact_output",
        "description": (
            "Compress shell command output (test results, build logs, lint reports) "
            "into token-optimized structured format. Extracts only actionable items "
            "(errors, failures, warnings) plus a summary line. "
            "Supported: pytest, ruff, mypy, jest, tsc, eslint, cargo, docker. "
            "Does NOT require index_repository."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Absolute path to file containing command output."},
                "text": {"type": "string", "description": "Raw command output to compress (use path instead when possible)."},
                "hint": {"type": "string", "description": "Tool identifier (e.g. 'pytest', 'eslint'). Omit for auto-detection."},
                "verbose": {"type": "boolean", "description": "Include all items, not just problems. Default: false."},
            },
        },
    },
]


def parse_request(line: str) -> dict:
    """Parse a JSON-RPC 2.0 request line."""
    try:
        data = json.loads(line)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError("Request must be a JSON object")
    return {
        "id": data.get("id"),
        "method": data.get("method"),
        "params": data.get("params", {}),
    }


def build_response(request_id, result) -> str:
    """Build a JSON-RPC 2.0 success response."""
    return json.dumps({"jsonrpc": "2.0", "id": request_id, "result": result})


def build_error(request_id, code: int, message: str, data=None) -> str:
    """Build a JSON-RPC 2.0 error response."""
    error: dict = {"code": code, "message": message}
    if data is not None:
        error["data"] = data
    return json.dumps({"jsonrpc": "2.0", "id": request_id, "error": error})


def build_initialize_response(request_id) -> str:
    """Build the MCP initialize response."""
    return build_response(
        request_id,
        {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "tokkit", "version": "0.1.15"},
        },
    )


def build_tools_list_response(request_id) -> str:
    """Build the MCP tools/list response."""
    return build_response(request_id, {"tools": TOOL_DEFINITIONS})
