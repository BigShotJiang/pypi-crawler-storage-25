use std::collections::HashMap;
use crate::graph::GraphBuffer;
use crate::types::{NodeLabel, EdgeType, Edge};

pub fn find_routes(buf: &mut GraphBuffer) {
    let func_nodes: Vec<(u64, String, Option<String>)> = buf
        .nodes()
        .iter()
        .filter(|n| n.label == NodeLabel::Function || n.label == NodeLabel::Method)
        .map(|n| (n.id, n.name.clone(), n.file_path.clone()))
        .collect();

    // Also check properties for explicit route metadata
    let prop_routes: Vec<(u64, String, String)> = buf
        .nodes()
        .iter()
        .filter(|n| n.label == NodeLabel::Function || n.label == NodeLabel::Method)
        .filter_map(|n| {
            let path = n.properties.get("route_path")?.clone();
            let method = n.properties.get("route_method").cloned().unwrap_or_else(|| "GET".to_string());
            Some((n.id, path, method))
        })
        .collect();

    let mut route_edges: Vec<(u64, String, String)> = Vec::new();

    // Process explicit route properties
    for (func_id, route_path, method) in prop_routes {
        route_edges.push((func_id, route_path, method));
    }

    // Process name-based route detection in route files
    let http_prefixes = ["get_", "post_", "put_", "delete_", "patch_"];
    for (func_id, func_name, file_path) in &func_nodes {
        // Skip if already handled via properties
        if route_edges.iter().any(|(id, _, _)| id == func_id) {
            continue;
        }

        let fp = file_path.as_deref().unwrap_or("");
        let is_route_file = fp.contains("route")
            || fp.contains("controller")
            || fp.contains("handler")
            || fp.contains("view");

        if !is_route_file {
            continue;
        }

        for prefix in &http_prefixes {
            if let Some(resource) = func_name.strip_prefix(prefix) {
                let method = prefix.trim_end_matches('_').to_uppercase();
                let route_path = format!("/{}", resource.replace('_', "/"));
                route_edges.push((*func_id, route_path, method));
                break;
            }
        }
    }

    // Create Route nodes and HANDLES edges
    let mut new_items: Vec<(u64, String, String)> = Vec::new();
    for (func_id, route_path, method) in route_edges {
        new_items.push((func_id, route_path, method));
    }

    for (func_id, route_path, method) in new_items {
        let route_qn = format!("route:{}:{}", method, route_path);
        let route_id = buf.add_node(
            NodeLabel::Route,
            &route_path,
            &route_qn,
            None,
            0,
            0,
        );

        // Set method property on the route node
        if let Some(node) = buf.nodes().iter().find(|n| n.id == route_id) {
            let _ = node; // just verify it exists
        }

        buf.add_edge(Edge {
            source_id: func_id,
            target_id: route_id,
            edge_type: EdgeType::Handles,
            confidence: None,
            properties: {
                let mut p = HashMap::new();
                p.insert("method".to_string(), method);
                p
            },
        });
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_route_handler() {
        let mut buf = GraphBuffer::new("proj", "/root");

        let _file_id = buf.add_node(
            NodeLabel::File,
            "users.py",
            "routes/users.py",
            Some("routes/users.py".to_string()),
            0,
            0,
        );

        let func_id = buf.add_node(
            NodeLabel::Function,
            "get_users",
            "routes/users.py::get_users",
            Some("routes/users.py".to_string()),
            1,
            10,
        );

        find_routes(&mut buf);

        let route_exists = buf
            .nodes()
            .iter()
            .any(|n| n.label == NodeLabel::Route);
        assert!(route_exists, "Expected a Route node to be created");

        let handles_edge = buf.edges().iter().any(|e| {
            e.source_id == func_id && e.edge_type == EdgeType::Handles
        });
        assert!(handles_edge, "Expected a HANDLES edge from get_users to the route");
    }
}
