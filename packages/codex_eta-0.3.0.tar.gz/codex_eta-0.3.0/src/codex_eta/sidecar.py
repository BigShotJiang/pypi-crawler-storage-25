#!/usr/bin/env python3
"""
codex-eta sidecar: monitors codex sessions externally, zero interference.
watches ~/.codex/sessions/ for active sessions, reads events as they stream,
estimates completion time as a range, shows live progress.
no MCP, no tool injection, codex doesn't know this exists.
usage: codex-eta-sidecar
"""

import json
import os
import sys
import time
import glob
import subprocess
import tempfile
import threading
import re as _re

if sys.platform == "win32":
    _home = os.environ.get("USERPROFILE", "")
else:
    _home = os.path.expanduser("~")

SESSIONS_DIR = os.path.join(_home, ".codex", "sessions")
PROGRESS_FILE = os.path.join(_home, ".codex", "eta_progress")
LOG_FILE = os.path.join(_home, ".codex", "eta_monitor_log.jsonl")

SPINNER = ["\u280b", "\u2819", "\u281a", "\u281e", "\u2816", "\u2826", "\u2834", "\u2832", "\u2833", "\u2813"]


def call_codex_exec(prompt_text, model=None, reasoning_effort=None, timeout=30):
    """Call codex exec and return the text response. Returns None on failure."""
    fd, outfile = tempfile.mkstemp(suffix=".txt")
    os.close(fd)
    try:
        use_model = model if model and model.strip() else "gpt-5.5"
        cmd = ["codex", "exec", "-m", use_model, "--ephemeral", "--skip-git-repo-check",
               "-o", outfile]
        if reasoning_effort and str(reasoning_effort).strip() and str(reasoning_effort).lower() != "none":
            cmd.extend(["-c", f'model_reasoning_effort="{reasoning_effort}"'])
        cmd.append("-")
        result = subprocess.run(
            cmd, input=prompt_text, capture_output=True, text=True, timeout=30,
            env={**os.environ,
                 "PATH": os.environ.get("PATH", "") + ":/opt/homebrew/bin:" + os.path.expanduser("~/.local/bin")},
        )
        if result.returncode == 0 and os.path.exists(outfile):
            with open(outfile, encoding="utf-8", errors="replace") as f:
                return f.read().strip()
        else:
            log_event("codex_exec_fail", {"returncode": result.returncode, "stderr": result.stderr[:200]})
    except Exception as e:
        log_event("codex_exec_exception", {"error": str(e)})
    finally:
        try:
            os.remove(outfile)
        except OSError:
            pass
    return None


def parse_range_response(text):
    """Extract two numbers from LLM response like '30-120' or '30 to 120' or 'low: 30, high: 120'."""
    if not text:
        return None
    nums = _re.findall(r'\d+', text)
    if len(nums) >= 2:
        lo, hi = int(nums[0]), int(nums[1])
        if 1 <= lo <= 3600 and 1 <= hi <= 3600 and lo <= hi:
            return (lo, hi)
    if len(nums) == 1:
        n = int(nums[0])
        if 1 <= n <= 3600:
            return (max(5, int(n * 0.6)), int(n * 1.5))
    return None


def estimate_range_llm(prompt, model, effort, callback, step_log=None, elapsed=None, heuristic_lo=0, heuristic_hi=0):
    """Background thread: asks codex exec for a time range estimate."""
    def _run():
        log_event("llm_call_started", {"step_log": bool(step_log), "elapsed": elapsed})
        _start = time.time()
        if step_log and elapsed:
            steps_desc = "\n".join(f"  step {s['step']}: {s['name']}" for s in step_log[-10:])
            est_prompt = (
                "You are codex. You were given this task and have been running for "
                f"{int(elapsed)} seconds so far, completing {len(step_log)} tool calls:\n"
                f"{steps_desc}\n\n"
                "How many MORE seconds do you think you need to finish? "
                "Give a range as two numbers: optimistic and pessimistic. "
                "Example: 30-90\n\n"
                f"Task: {prompt[:400]}"
            )
        else:
            est_prompt = (
                "You are codex. Another instance of you (same model, same capabilities) "
                "is about to execute this task. "
                f"A heuristic estimated {heuristic_lo}-{heuristic_hi} seconds. "
                "Do you agree or adjust? Keep range within 3 minutes. "
                "Two numbers: optimistic-pessimistic. Example: 40-120\n\n"
                f"Task: {prompt[:400]}"
            )

        response = call_codex_exec(est_prompt, model=model, reasoning_effort=effort)
        result = parse_range_response(response)
        log_event("llm_call_done", {"response": response[:100] if response else "None", "parsed": list(result) if result else None, "took": round(time.time() - _start, 1)})
        if result:
            callback(result)

    t = threading.Thread(target=_run, daemon=True)
    t.start()


def estimate_steps_heuristic(prompt):
    words = len(prompt.split())
    prompt_lower = prompt.lower()

    if words <= 5:
        steps = 1
    elif words <= 15:
        steps = 2
    elif words <= 30:
        steps = 4
    elif words <= 60:
        steps = 6
    elif words <= 150:
        steps = 10
    else:
        steps = 10 + (words - 150) // 30

    if any(w in prompt_lower for w in ["every", "all", "each", "recursive"]):
        steps = int(steps * 1.5)
    if any(w in prompt_lower for w in ["analyze", "review", "audit", "investigate", "debug"]):
        steps = int(steps * 1.4)
    if any(w in prompt_lower for w in ["write", "create", "generate", "build", "implement"]):
        steps += 2
    if any(w in prompt_lower for w in ["compare", "diff", "reconcile", "cross-reference"]):
        steps += 2
    if any(w in prompt_lower for w in ["and then", "after that", "also", "additionally"]):
        steps += 2
    if any(w in prompt_lower for w in ["just", "simply", "quick", "hello", "hi", "what time", "say "]):
        steps = max(1, steps // 2)

    return max(1, min(steps, 60))


def find_active_session():
    pattern = os.path.join(SESSIONS_DIR, "**", "rollout-*.jsonl")
    files = glob.glob(pattern, recursive=True)
    if not files:
        return None
    mtimes = []
    for file in files:
        try:
            mtimes.append((os.path.getmtime(file), file))
        except OSError:
            continue
    if not mtimes:
        return None
    mtime, latest = max(mtimes)
    if time.time() - mtime < 60:
        return latest
    return None


def read_latest_task(filepath):
    try:
        with open(filepath, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return None

    prompt = None
    steps = 0
    step_log = []
    token_events = []
    task_active = False
    task_done = False
    model = None
    reasoning_effort = None

    for line in lines:
        try:
            d = json.loads(line.strip())
        except:
            continue

        t = d.get("type", "")
        p = d.get("payload", {})

        if t == "turn_context":
            collab = p.get("collaboration_mode", {}).get("settings", {})
            model = collab.get("model") or p.get("model")
            reasoning_effort = collab.get("reasoning_effort") or p.get("effort")

        if t == "event_msg":
            if p.get("type") == "task_started":
                prompt = None
                steps = 0
                step_log = []
                token_events = []
                task_active = True
                task_done = False
            elif p.get("type") in ("task_complete", "turn_aborted"):
                task_done = True
                task_active = False
            elif p.get("type") == "token_count" and task_active:
                info = p.get("info") or {}
                total = info.get("total_token_usage") or {}
                if total:
                    token_events.append({
                        "total": total.get("input_tokens", 0) + total.get("cached_input_tokens", 0),
                    })

        elif t == "response_item" and task_active:
            if p.get("role") == "user" and not prompt:
                for c in p.get("content", []):
                    text = c.get("text", "")
                    if text and "<environment_context>" not in text and "<permissions" not in text and "<turn_aborted>" not in text and len(text) > 3:
                        prompt = text

            if p.get("type") == "function_call":
                steps += 1
                name = p.get("name", "unknown")
                args = p.get("arguments", "")
                cmd_hint = ""
                try:
                    a = json.loads(args) if isinstance(args, str) else args
                    cmd_hint = a.get("cmd", a.get("command", ""))[:80]
                except:
                    pass
                step_log.append({"step": steps, "name": f"{name}: {cmd_hint}" if cmd_hint else name})

    return {
        "prompt": prompt,
        "steps": steps,
        "step_log": step_log,
        "token_events": token_events,
        "task_active": task_active,
        "task_done": task_done,
        "model": model,
        "reasoning_effort": reasoning_effort,
    }


def fmt_time(seconds):
    if seconds is None:
        return "?"
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    return f"{seconds // 3600}h {(seconds % 3600) // 60}m"


def fmt_range(lo, hi):
    return f"{fmt_time(lo)}-{fmt_time(hi)}"


def fmt_tokens(n):
    if n > 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n > 1_000:
        return f"{n // 1000}K"
    return str(n)


def log_event(event, data):
    entry = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"), "event": event, "data": data}
    try:
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 1_000_000:
            with open(LOG_FILE, encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
            with open(LOG_FILE, "w") as f:
                f.writelines(lines[len(lines) // 2:])
        with open(LOG_FILE, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass


def write_progress(text):
    try:
        os.makedirs(os.path.dirname(PROGRESS_FILE), exist_ok=True)
        with open(PROGRESS_FILE, "w") as f:
            f.write(text + "\n")
    except OSError:
        pass


def get_width():
    try:
        return os.get_terminal_size().columns
    except:
        return 80


def _spawn_watcher():
    try:
        result = subprocess.run(["pgrep", "-f", "codex-eta-watch"], capture_output=True)
        if result.returncode == 0:
            return
    except:
        pass
    try:
        if sys.platform == "darwin":
            subprocess.Popen(
                ["osascript", "-e", 'tell application "Terminal" to do script "codex-eta-watch"'],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform == "win32":
            subprocess.Popen(
                ["cmd", "/c", "start", "ETA Monitor", "codex-eta-watch"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            for term in ["gnome-terminal", "xterm", "konsole", "xfce4-terminal"]:
                try:
                    subprocess.Popen([term, "--", "codex-eta-watch"],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    break
                except FileNotFoundError:
                    continue
    except:
        pass


def render_line(spin, text, width):
    line = f" {spin} {text}"
    if len(line) > width - 1:
        line = line[:width - 4] + "..."
    padded = line + " " * max(0, width - len(line) - 1)
    sys.stdout.write(f"\r{padded}")
    sys.stdout.flush()


def main():
    is_tty = sys.stdout.isatty()
    if not is_tty and os.environ.get("ETA_NO_WATCHER") != "1":
        _spawn_watcher()

    spin_idx = 0
    current_session = None

    prompt = None
    task_start_time = None
    logged_plan = False

    # range state
    range_lo = 0
    range_hi = 0
    range_source = "none"
    llm_result = [None]
    llm_pending = False
    re_estimating = False

    completed_msg = ""
    completed_at = 0
    showing_complete = False

    last_task_active = False
    last_task_done = False

    if is_tty:
        sys.stdout.write("\033[?25l")
        sys.stdout.flush()

    try:
        while True:
            width = get_width() if is_tty else 80
            spin = SPINNER[spin_idx % len(SPINNER)]
            spin_idx += 1

            if showing_complete and (time.time() - completed_at) < 10:
                if is_tty:
                    green_msg = f"\033[32m\u2713 {completed_msg}\033[0m"
                    padded = green_msg + " " * max(0, width - len(completed_msg) - 4)
                    sys.stdout.write(f"\r{padded}")
                    sys.stdout.flush()
                write_progress(completed_msg)
                time.sleep(0.1)
                continue
            elif showing_complete and (time.time() - completed_at) >= 10:
                showing_complete = False
                write_progress("")

            session_file = find_active_session()

            if session_file and session_file != current_session:
                current_session = session_file
                last_task_active = False
                last_task_done = False

            if not current_session:
                if is_tty:
                    sys.stdout.write(f"\r\033[2m {spin} waiting for codex...\033[0m{' ' * (width - 25)}")
                    sys.stdout.flush()
                time.sleep(0.3)
                continue

            data = read_latest_task(current_session)
            if not data:
                time.sleep(0.3)
                continue

            # new task
            if data["task_active"] and not last_task_active:
                prompt = None
                task_start_time = time.time()
                logged_plan = False
                showing_complete = False
                llm_result = [None]
                llm_pending = False
                re_estimating = False
                range_lo = 0
                range_hi = 0
                range_source = "none"

            last_task_active = data["task_active"]

            # completed
            if data["task_done"] and not last_task_done:
                last_task_done = True
                if task_start_time:
                    elapsed = time.time() - task_start_time
                    steps = data["steps"]
                    tok = data["token_events"][-1]["total"] if data["token_events"] else 0
                    in_range = range_lo <= elapsed <= range_hi if range_hi > 0 else False

                    log_event("complete", {
                        "prompt": (prompt or "")[:200],
                        "actual_seconds": round(elapsed, 1),
                        "actual_steps": steps,
                        "range": [round(range_lo), round(range_hi)],
                        "range_source": range_source,
                        "in_range": in_range,
                        "total_tokens": tok,
                    })

                    m, s = divmod(int(elapsed), 60)
                    time_str = f"{m}m {s}s" if m else f"{s}s"
                    if range_hi == 0:
                        accuracy = "no estimate"
                    elif in_range:
                        accuracy = f"within est {fmt_range(range_lo, range_hi)}"
                    elif elapsed < range_lo:
                        accuracy = f"faster than est {fmt_range(range_lo, range_hi)}"
                    else:
                        accuracy = f"exceeded est {fmt_range(range_lo, range_hi)}"
                    completed_msg = f"done in {time_str} ({steps} steps, {fmt_tokens(tok)}) [{accuracy}]"
                    completed_at = time.time()
                    showing_complete = True
                    write_progress(completed_msg)
                continue
            elif data["task_done"]:
                if not showing_complete:
                    if is_tty:
                        sys.stdout.write(f"\r\033[2m {spin} waiting for next task...\033[0m{' ' * (width - 30)}")
                        sys.stdout.flush()
                time.sleep(0.3)
                continue

            if data["task_active"]:
                last_task_done = False

            # prompt detected — fire first LLM estimate
            if data["prompt"] and not prompt:
                prompt = data["prompt"]
                task_start_time = task_start_time or time.time()
                llm_result = [None]

                # instant heuristic range
                h_steps = estimate_steps_heuristic(prompt)
                range_lo = max(5, int(h_steps * 5))
                range_hi = max(15, int(h_steps * 15))
                range_source = "heuristic"

                # fire LLM to refine
                llm_pending = os.environ.get("ETA_NO_LLM") != "1"
                if llm_pending:
                    def _on_first(r):
                        llm_result[0] = r
                    estimate_range_llm(prompt, data.get("model"), data.get("reasoning_effort"), _on_first,
                                       heuristic_lo=range_lo, heuristic_hi=range_hi)

                if not logged_plan:
                    log_event("plan", {
                        "prompt": prompt[:200],
                        "effort": str(data.get("reasoning_effort")),
                        "model": str(data.get("model")),
                        "heuristic_range": [range_lo, range_hi],
                    })
                    logged_plan = True

            # first LLM result arrived — merge with heuristic, cap at 3min spread
            if llm_pending and llm_result[0] is not None:
                llm_lo, llm_hi = llm_result[0]
                merged_lo = min(range_lo, llm_lo)
                merged_hi = max(range_hi, llm_hi)
                if merged_hi - merged_lo > 180:
                    mid = (merged_lo + merged_hi) // 2
                    merged_lo = max(5, mid - 90)
                    merged_hi = mid + 90
                range_lo = merged_lo
                range_hi = merged_hi
                range_source = "llm_merged"
                llm_pending = False
                log_event("range_set", {
                    "range": [range_lo, range_hi],
                    "llm_raw": [llm_lo, llm_hi],
                    "source": "llm_merged",
                })

            # expire initial LLM if it's been too long (25s timeout + 5s buffer)
            if llm_pending and task_start_time and (time.time() - task_start_time) > 35:
                llm_pending = False

            # check if we exceeded upper bound — trigger re-estimate
            if data["task_active"] and task_start_time and range_hi > 0 and not re_estimating and not llm_pending:
                elapsed = time.time() - task_start_time
                if elapsed > range_hi:
                    re_estimating = True
                    llm_result = [None]

                    if os.environ.get("ETA_NO_LLM") != "1":
                        def _on_reest(r):
                            llm_result[0] = r
                        estimate_range_llm(
                            prompt, data.get("model"), data.get("reasoning_effort"), _on_reest,
                            step_log=data.get("step_log", []),
                            elapsed=elapsed,
                        )

                    log_event("re_estimating", {
                        "elapsed": round(elapsed, 1),
                        "steps_so_far": data["steps"],
                        "old_range": [round(range_lo), round(range_hi)],
                    })

            # re-estimate result arrived
            if re_estimating and llm_result[0] is not None:
                elapsed = time.time() - task_start_time if task_start_time else 0
                additional_lo, additional_hi = llm_result[0]
                range_lo = round(elapsed)
                range_hi = round(elapsed + additional_hi)
                range_source = "llm_reestimate"
                re_estimating = False
                log_event("range_set", {
                    "range": [range_lo, range_hi],
                    "source": "llm_reestimate",
                    "additional": [additional_lo, additional_hi],
                })

            # display
            if data["task_active"] and task_start_time:
                elapsed = time.time() - task_start_time
                steps_done = data["steps"]
                tok = data["token_events"][-1] if data["token_events"] else None
                short_prompt = (prompt or "")[:30].replace("\n", " ")
                tok_str = f" {fmt_tokens(tok['total'])}" if tok else ""

                if re_estimating:
                    text = f"{short_prompt} | {fmt_time(elapsed)} elapsed, re-estimating... | step {steps_done}{tok_str}"
                elif range_hi > 0:
                    midpoint = (range_lo + range_hi) / 2
                    pct = min(95, int(elapsed / max(midpoint, 1) * 100))
                    bar_w = 15
                    filled = pct * bar_w // 100
                    bar = "\u2588" * filled + "\u2591" * (bar_w - filled)
                    text = f"{short_prompt} | [{bar}] | {fmt_time(elapsed)} elapsed, est {fmt_range(range_lo, range_hi)} | step {steps_done}{tok_str}"
                elif llm_pending:
                    text = f"{short_prompt} | {fmt_time(elapsed)} elapsed, estimating... | step {steps_done}{tok_str}"
                else:
                    text = f"{short_prompt} | {fmt_time(elapsed)} elapsed | step {steps_done}{tok_str}"

                if is_tty:
                    render_line(spin, text, width)
                write_progress(text)

            elif data["task_active"] and prompt:
                short_prompt = (prompt or "")[:40].replace("\n", " ")
                text = f"{short_prompt} | starting..."
                if is_tty:
                    render_line(spin, text, width)
                write_progress(text)

            elif data["task_active"]:
                if is_tty:
                    render_line(spin, "task starting...", width)

            time.sleep(0.1)

    except KeyboardInterrupt:
        pass
    finally:
        write_progress("")
        if is_tty:
            sys.stdout.write("\033[?25h\r\033[K\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
