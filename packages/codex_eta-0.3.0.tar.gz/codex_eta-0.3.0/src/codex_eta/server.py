#!/usr/bin/env python3
"""
minimal MCP server - just task_complete signal.
the sidecar does all the monitoring, this just tells it when codex is done.
"""

import json
import os
import sys
import time
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("eta-monitor")

if sys.platform == "win32":
    SIGNAL_FILE = os.path.join(os.environ.get("USERPROFILE", ""), ".codex", "eta_done_signal")
else:
    SIGNAL_FILE = os.path.expanduser("~/.codex/eta_done_signal")


@mcp.tool()
def task_complete(step_count: int = 0) -> str:
    """REQUIRED: Call this when you finish a task. Just pass how many steps you took."""
    try:
        os.makedirs(os.path.dirname(SIGNAL_FILE), exist_ok=True)
        with open(SIGNAL_FILE, "w") as f:
            f.write(json.dumps({"done": True, "steps": step_count, "time": time.time()}) + "\n")
    except OSError as exc:
        return f"error: could not write completion signal: {exc}"
    return "ok"


def main():
    if "--help" in sys.argv or "-h" in sys.argv:
        print("eta-monitor MCP - signals task completion to the sidecar")
        print("install: codex mcp add eta-monitor -- codex-eta")
        sys.exit(0)
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
