#!/usr/bin/env python3
"""
codex-eta sidecar: monitors codex sessions externally, zero interference.
watches ~/.codex/sessions/ for active sessions, reads events as they stream,
estimates completion time, shows live progress.
no MCP, no tool injection, codex doesn't know this exists.
usage: codex-eta-sidecar
"""

import json
import os
import sys
import time
import glob
import subprocess
import tempfile
import threading

if sys.platform == "win32":
    _home = os.environ.get("USERPROFILE", "")
else:
    _home = os.path.expanduser("~")

SESSIONS_DIR = os.path.join(_home, ".codex", "sessions")
PROGRESS_FILE = os.path.join(_home, ".codex", "eta_progress")
LOG_FILE = os.path.join(_home, ".codex", "eta_monitor_log.jsonl")

BASELINE_SEC_PER_STEP = 7.5
SPINNER = ["\u280b", "\u2819", "\u281a", "\u281e", "\u2816", "\u2826", "\u2834", "\u2832", "\u2833", "\u2813"]


def estimate_steps_llm(prompt, heuristic_estimate, callback):
    def _run():
        outfile = None
        try:
            est_prompt = (
                "You are codex. You have a terminal and can run commands. "
                "For this task, how many tool calls (commands) will you make? "
                "Remember how you actually work: "
                "if a task is pure code generation (write a script, create a file) "
                "you generate it directly from training in 1 call without reading anything first. "
                "If a task requires reading existing files or searching a codebase, "
                "you need 1 call per read/search plus 1 to write output. "
                "Reply with ONLY a number.\n\n"
                f"Task: {prompt[:500]}"
            )
            fd, outfile = tempfile.mkstemp(suffix=".txt")
            os.close(fd)
            result = subprocess.run(
                ["codex", "exec", "-m", "gpt-5.5", "--ephemeral", "--skip-git-repo-check",
                 "-o", outfile, "-"],
                input=est_prompt,
                capture_output=True, text=True, timeout=25,
                env={**os.environ,
                     "PATH": os.environ.get("PATH", "") + ":/opt/homebrew/bin:" + os.path.expanduser("~/.local/bin")},
            )
            if result.returncode == 0 and os.path.exists(outfile):
                import re
                with open(outfile, encoding="utf-8", errors="replace") as f:
                    text = f.read().strip()
                nums = re.findall(r'\d+', text)
                if nums:
                    n = int(nums[0])
                    if 1 <= n <= 200:
                        callback(n)
        except Exception:
            pass
        finally:
            if outfile:
                try:
                    os.remove(outfile)
                except OSError:
                    pass

    t = threading.Thread(target=_run, daemon=True)
    t.start()


def find_active_session():
    pattern = os.path.join(SESSIONS_DIR, "**", "rollout-*.jsonl")
    files = glob.glob(pattern, recursive=True)
    if not files:
        return None
    mtimes = []
    for file in files:
        try:
            mtimes.append((os.path.getmtime(file), file))
        except OSError:
            continue
    if not mtimes:
        return None
    mtime, latest = max(mtimes)
    if time.time() - mtime < 60:
        return latest
    return None


def estimate_steps_heuristic(prompt):
    words = len(prompt.split())
    prompt_lower = prompt.lower()

    if words <= 5:
        steps = 1
    elif words <= 15:
        steps = 2
    elif words <= 30:
        steps = 4
    elif words <= 60:
        steps = 6
    elif words <= 150:
        steps = 10
    else:
        steps = 10 + (words - 150) // 30

    if any(w in prompt_lower for w in ["every", "all", "each", "recursive"]):
        steps = int(steps * 1.5)
    if any(w in prompt_lower for w in ["analyze", "review", "audit", "investigate", "debug"]):
        steps = int(steps * 1.4)
    if any(w in prompt_lower for w in ["write", "create", "generate", "build", "implement"]):
        steps += 2
    if any(w in prompt_lower for w in ["compare", "diff", "reconcile", "cross-reference"]):
        steps += 2
    if any(w in prompt_lower for w in ["and then", "after that", "also", "additionally"]):
        steps += 2
    if any(w in prompt_lower for w in ["just", "simply", "quick", "hello", "hi", "what time", "say "]):
        steps = max(1, steps // 2)

    return max(1, min(steps, 60))


def read_latest_task(filepath):
    try:
        with open(filepath, encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except OSError:
        return None

    prompt = None
    steps = 0
    token_events = []
    task_active = False
    task_done = False

    for line in lines:
        try:
            d = json.loads(line.strip())
        except:
            continue

        t = d.get("type", "")
        p = d.get("payload", {})

        if t == "event_msg":
            if p.get("type") == "task_started":
                prompt = None
                steps = 0
                token_events = []
                task_active = True
                task_done = False
            elif p.get("type") in ("task_complete", "turn_aborted"):
                task_done = True
                task_active = False
            elif p.get("type") == "token_count" and task_active:
                info = p.get("info") or {}
                total = info.get("total_token_usage") or {}
                if total:
                    token_events.append({
                        "input": total.get("input_tokens", 0),
                        "cached": total.get("cached_input_tokens", 0),
                        "total": total.get("input_tokens", 0) + total.get("cached_input_tokens", 0),
                    })

        elif t == "response_item" and task_active:
            if p.get("role") == "user" and not prompt:
                for c in p.get("content", []):
                    text = c.get("text", "")
                    if text and "<environment_context>" not in text and "<permissions" not in text and "<turn_aborted>" not in text and len(text) > 3:
                        prompt = text

            if p.get("type") == "function_call":
                steps += 1

    return {
        "prompt": prompt,
        "steps": steps,
        "token_events": token_events,
        "task_active": task_active,
        "task_done": task_done,
        "n_lines": len(lines),
    }


def fmt_time(seconds):
    if seconds is None:
        return "?"
    seconds = int(seconds)
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}m {seconds % 60}s"
    return f"{seconds // 3600}h {(seconds % 3600) // 60}m"


def fmt_tokens(n):
    if n > 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n > 1_000:
        return f"{n // 1000}K"
    return str(n)


def log_event(event, data):
    entry = {"timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"), "event": event, "data": data}
    try:
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 1_000_000:
            with open(LOG_FILE, encoding="utf-8", errors="replace") as f:
                lines = f.readlines()
            with open(LOG_FILE, "w") as f:
                f.writelines(lines[len(lines) // 2:])
        with open(LOG_FILE, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass


def write_progress(text):
    try:
        os.makedirs(os.path.dirname(PROGRESS_FILE), exist_ok=True)
        with open(PROGRESS_FILE, "w") as f:
            f.write(text + "\n")
    except OSError:
        pass


def get_width():
    try:
        return os.get_terminal_size().columns
    except:
        return 80


def _spawn_watcher():
    try:
        result = subprocess.run(["pgrep", "-f", "codex-eta-watch"], capture_output=True)
        if result.returncode == 0:
            return
    except:
        pass
    try:
        if sys.platform == "darwin":
            subprocess.Popen(
                ["osascript", "-e", 'tell application "Terminal" to do script "codex-eta-watch"'],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif sys.platform == "win32":
            subprocess.Popen(
                ["cmd", "/c", "start", "ETA Monitor", "codex-eta-watch"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            for term in ["gnome-terminal", "xterm", "konsole", "xfce4-terminal"]:
                try:
                    subprocess.Popen([term, "--", "codex-eta-watch"],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    break
                except FileNotFoundError:
                    continue
    except:
        pass


def render_line(spin, text, width):
    line = f" {spin} {text}"
    if len(line) > width - 1:
        line = line[:width - 4] + "..."
    padded = line + " " * max(0, width - len(line) - 1)
    sys.stdout.write(f"\r{padded}")
    sys.stdout.flush()


def main():
    is_tty = sys.stdout.isatty()
    if not is_tty and os.environ.get("ETA_NO_WATCHER") != "1":
        _spawn_watcher()

    spin_idx = 0
    current_session = None

    prompt = None
    estimated_steps = None
    task_start_time = None
    last_step_count = 0
    frozen_sec_per_step = BASELINE_SEC_PER_STEP
    frozen_eta_remaining = None
    logged_plan = False
    llm_estimate_pending = False
    llm_estimate_result = [None]
    last_pct = 0

    completed_msg = ""
    completed_at = 0
    showing_complete = False

    last_task_active = False
    last_task_done = False

    if is_tty:
        sys.stdout.write("\033[?25l")
        sys.stdout.flush()

    try:
        while True:
            width = get_width() if is_tty else 80
            spin = SPINNER[spin_idx % len(SPINNER)]
            spin_idx += 1

            if showing_complete and (time.time() - completed_at) < 10:
                if is_tty:
                    green_msg = f"\033[32m\u2713 {completed_msg}\033[0m"
                    padded = green_msg + " " * max(0, width - len(completed_msg) - 4)
                    sys.stdout.write(f"\r{padded}")
                    sys.stdout.flush()
                write_progress(completed_msg)
                time.sleep(0.1)
                continue
            elif showing_complete and (time.time() - completed_at) >= 10:
                showing_complete = False
                write_progress("")

            session_file = find_active_session()

            if session_file and session_file != current_session:
                current_session = session_file
                last_task_active = False
                last_task_done = False

            if not current_session:
                if is_tty:
                    sys.stdout.write(f"\r\033[2m {spin} waiting for codex...\033[0m{' ' * (width - 25)}")
                    sys.stdout.flush()
                time.sleep(0.3)
                continue

            data = read_latest_task(current_session)
            if not data:
                time.sleep(0.3)
                continue

            if data["task_active"] and not last_task_active:
                prompt = None
                estimated_steps = None
                task_start_time = time.time()
                last_step_count = 0
                frozen_sec_per_step = BASELINE_SEC_PER_STEP
                frozen_eta_remaining = None
                logged_plan = False
                showing_complete = False
                llm_estimate_pending = False
                llm_estimate_result = [None]
                last_pct = 0

            last_task_active = data["task_active"]

            if data["task_done"] and not last_task_done:
                last_task_done = True
                if task_start_time:
                    elapsed = time.time() - task_start_time
                    steps = data["steps"]
                    tok = data["token_events"][-1]["total"] if data["token_events"] else 0
                    initial_eta = (estimated_steps or 1) * BASELINE_SEC_PER_STEP
                    err_pct = round((initial_eta - elapsed) / elapsed * 100) if elapsed > 0 else 0

                    log_event("complete", {
                        "prompt": (prompt or "")[:200],
                        "actual_seconds": round(elapsed, 1),
                        "actual_steps": steps,
                        "estimated_steps": estimated_steps,
                        "planned_steps": estimated_steps,
                        "estimation_error_pct": err_pct,
                        "total_tokens": tok,
                        "initial_eta_s": round(initial_eta),
                    })

                    m, s = divmod(int(elapsed), 60)
                    time_str = f"{m}m {s}s" if m else f"{s}s"
                    if abs(err_pct) <= 15:
                        accuracy = "spot on"
                    elif err_pct > 0:
                        accuracy = f"predicted {abs(err_pct)}% over"
                    else:
                        accuracy = f"predicted {abs(err_pct)}% under"
                    completed_msg = f"done in {time_str} ({steps} steps, {fmt_tokens(tok)}) [{accuracy}, est was {fmt_time(initial_eta)}]"
                    completed_at = time.time()
                    showing_complete = True
                    write_progress(completed_msg)
                continue
            elif data["task_done"]:
                if not showing_complete:
                    if is_tty:
                        sys.stdout.write(f"\r\033[2m {spin} waiting for next task...\033[0m{' ' * (width - 30)}")
                        sys.stdout.flush()
                time.sleep(0.3)
                continue

            if data["task_active"]:
                last_task_done = False

            if data["prompt"] and not prompt:
                prompt = data["prompt"]
                estimated_steps = estimate_steps_heuristic(prompt)
                task_start_time = task_start_time or time.time()
                llm_estimate_result = [None]
                llm_estimate_pending = os.environ.get("ETA_NO_LLM") != "1"

                if llm_estimate_pending:
                    def _on_llm_result(n):
                        llm_estimate_result[0] = n
                    estimate_steps_llm(prompt, estimated_steps, _on_llm_result)

                if not logged_plan:
                    log_event("plan", {
                        "prompt": prompt[:200],
                        "estimated_steps": estimated_steps,
                        "initial_eta_s": round(estimated_steps * BASELINE_SEC_PER_STEP),
                        "source": "heuristic",
                    })
                    logged_plan = True

            if llm_estimate_pending and llm_estimate_result[0] is not None:
                llm_steps = llm_estimate_result[0]
                llm_estimate_pending = False

                if data["task_active"] and llm_steps > data["steps"] and last_step_count < 2:
                    estimated_steps = max(estimated_steps, (estimated_steps + llm_steps) // 2)
                    log_event("plan_updated", {
                        "estimated_steps": estimated_steps,
                        "llm_raw": llm_steps,
                        "source": "llm_blended",
                    })

            if data["task_active"] and task_start_time and estimated_steps:
                elapsed = time.time() - task_start_time
                steps_done = data["steps"]
                tok = data["token_events"][-1] if data["token_events"] else None

                initial_est = estimated_steps * BASELINE_SEC_PER_STEP

                countdown_eta = max(1, initial_est - elapsed)

                if steps_done > last_step_count:
                    last_step_count = steps_done
                    if steps_done == 1:
                        frozen_sec_per_step = BASELINE_SEC_PER_STEP
                    else:
                        frozen_sec_per_step = elapsed / steps_done

                    if steps_done >= estimated_steps:
                        estimated_steps = steps_done + max(2, int(steps_done * 0.3))

                    remaining = max(0, estimated_steps - steps_done)
                    raw_eta = remaining * frozen_sec_per_step

                    if last_step_count >= 3:
                        frozen_eta_remaining = raw_eta
                    else:
                        frozen_eta_remaining = min(raw_eta, countdown_eta)

                    log_event("step", {
                        "step": steps_done,
                        "elapsed": round(elapsed, 1),
                        "sec_per_step": round(frozen_sec_per_step, 1),
                        "estimated_steps": estimated_steps,
                        "raw_eta": round(raw_eta, 1),
                        "capped_eta": round(frozen_eta_remaining, 1),
                        "countdown_eta": round(countdown_eta, 1),
                        "tokens": tok["total"] if tok else 0,
                    })

                if last_step_count > 0 and frozen_eta_remaining is not None:
                    time_since_last_recalc = elapsed - (last_step_count * frozen_sec_per_step)
                    eta_display = max(1, frozen_eta_remaining - time_since_last_recalc)

                    if last_step_count >= 2 and time_since_last_recalc > frozen_sec_per_step * 2:
                        eta_display = max(eta_display, time_since_last_recalc * 0.5)

                elif elapsed < initial_est:
                    eta_display = countdown_eta
                else:
                    eta_display = max(3, 10)

                short_prompt = (prompt or "")[:30].replace("\n", " ")
                tok_str = f" {fmt_tokens(tok['total'])}" if tok else ""

                raw_pct = min(95, int(elapsed / max(initial_est, 1) * 100)) if initial_est > 0 else 0
                if last_step_count >= 3:
                    max_drop = 2
                elif last_step_count >= 1:
                    max_drop = 5
                else:
                    max_drop = 10
                pct = max(raw_pct, last_pct - max_drop)
                last_pct = pct
                bar_w = 15
                filled = pct * bar_w // 100
                bar = "\u2588" * filled + "\u2591" * (bar_w - filled)

                text = f"{short_prompt} | [{bar}] {pct}% | {fmt_time(elapsed)} elapsed ~{fmt_time(eta_display)} left | step {steps_done}/~{estimated_steps}{tok_str}"

                if is_tty:
                    render_line(spin, text, width)
                write_progress(text)

            elif data["task_active"] and prompt:
                short_prompt = (prompt or "")[:40].replace("\n", " ")
                text = f"{short_prompt} | starting..."
                if is_tty:
                    render_line(spin, text, width)
                write_progress(text)

            elif data["task_active"]:
                if is_tty:
                    render_line(spin, "task starting...", width)

            time.sleep(0.1)

    except KeyboardInterrupt:
        pass
    finally:
        write_progress("")
        if is_tty:
            sys.stdout.write("\033[?25h\r\033[K\n")
            sys.stdout.flush()


if __name__ == "__main__":
    main()
