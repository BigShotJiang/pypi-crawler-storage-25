# codex-eta

time estimation for codex tasks. shows how long things will take.

## install

```
pip install codex-eta
codex mcp add eta-monitor -- codex-eta
codex-eta-install
```

Restart your shell, or run `source ~/.zshrc` / `source ~/.bashrc`.

The MCP server records completion signals. The sidecar does the ETA work by
watching Codex session files; `codex-eta-install` adds shell wrappers that start
the sidecar when you run `codex` or `codx`.

## what happens

when you give codex a task:
1. the sidecar detects the active Codex rollout file
2. it estimates the number of tool calls with a local heuristic
3. a live progress bar can pop up in a separate terminal
4. progress updates as Codex writes session events
5. when done, you see actual time vs estimate

## env vars

- `ETA_NO_WATCHER=1` skip the popup progress window
- `ETA_LLM_ESTIMATE=1` optionally ask `codex exec` for a second estimate based on the first 500 characters of the task prompt

## files

- `~/.codex/eta_monitor_log.jsonl` log of predictions vs actuals
- `~/.codex/eta_progress` live progress (read by watcher)
- `~/.codex/eta_done_signal` completion signal written by the MCP tool

## uninstall

```
codex mcp remove eta-monitor
codex-eta-install --uninstall
pip uninstall codex-eta
```
