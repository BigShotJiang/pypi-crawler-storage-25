# Docker compose assets.
