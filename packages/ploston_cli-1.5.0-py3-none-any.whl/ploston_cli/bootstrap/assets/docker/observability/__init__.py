# Docker observability assets.
