# Kubernetes assets.
