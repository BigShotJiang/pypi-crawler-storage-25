"""HTTP client for Ploston REST API.

This module provides the HTTP client for communicating with Ploston servers.
The CLI is a thin client that delegates all operations to the server via HTTP.
"""

from dataclasses import dataclass
from typing import Any

import httpx


@dataclass
class CPConnectionResult:
    """Result of checking CP connectivity."""

    connected: bool
    url: str
    error: str | None = None
    version: str | None = None


class PlostClientError(Exception):
    """Error from Ploston API client."""

    def __init__(self, message: str, status_code: int | None = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class PlostClient:
    """HTTP client for Ploston REST API.

    All operations are delegated to the server via HTTP.
    """

    def __init__(self, base_url: str, timeout: float = 30.0, insecure: bool = False):
        """Initialize client.

        Args:
            base_url: Server URL (e.g., http://localhost:8022)
            timeout: Request timeout in seconds
            insecure: Skip SSL certificate verification (like curl -k)
        """
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.insecure = insecure
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> "PlostClient":
        """Enter async context."""
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self.timeout,
            headers={"Content-Type": "application/json"},
            verify=not self.insecure,
        )
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context."""
        if self._client:
            await self._client.aclose()
            self._client = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure client is initialized."""
        if not self._client:
            raise PlostClientError("Client not initialized. Use 'async with' context.")
        return self._client

    async def _request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request to server.

        Args:
            method: HTTP method
            path: API path (e.g., /api/v1/workflows)
            json: JSON body for POST/PUT
            params: Query parameters

        Returns:
            Response JSON as dict

        Raises:
            PlostClientError: On connection or HTTP errors
        """
        client = self._ensure_client()
        try:
            response = await client.request(method, path, json=json, params=params)
            response.raise_for_status()
            return response.json()
        except httpx.ConnectError:
            raise PlostClientError(
                f"Cannot connect to Ploston server at {self.base_url}\n"
                "Is the server running? Start it with: ploston-server"
            )
        except httpx.HTTPStatusError as e:
            # Try to extract error message from response
            try:
                error_data = e.response.json()
                message = error_data.get("detail", str(e))
            except Exception:
                message = str(e)
            raise PlostClientError(message, status_code=e.response.status_code)
        except httpx.TimeoutException:
            raise PlostClientError(f"Request timed out after {self.timeout}s")
        except httpx.ReadError:
            raise PlostClientError(
                f"Connection to {self.base_url} was interrupted.\n"
                "The server may have crashed or restarted."
            )
        except httpx.HTTPError as e:
            # Catch-all for any other httpx errors
            raise PlostClientError(f"HTTP error: {e}")

    # -------------------------------------------------------------------------
    # Capabilities
    # -------------------------------------------------------------------------

    async def get_capabilities(self) -> dict[str, Any]:
        """Get server capabilities for tier detection.

        Returns:
            Capabilities dict with tier, version, features, limits
        """
        return await self._request("GET", "/api/v1/capabilities")

    # -------------------------------------------------------------------------
    # Workflows
    # -------------------------------------------------------------------------

    async def list_workflows(self) -> list[dict[str, Any]]:
        """List all workflows.

        Returns:
            List of workflow summaries
        """
        response = await self._request("GET", "/api/v1/workflows")
        # API returns {"workflows": [...], "total": ..., ...}
        return response.get("workflows", [])

    async def get_workflow(self, name: str) -> dict[str, Any]:
        """Get workflow details.

        Args:
            name: Workflow name

        Returns:
            Workflow details dict
        """
        return await self._request("GET", f"/api/v1/workflows/{name}")

    async def execute_workflow(
        self,
        name: str,
        inputs: dict[str, Any] | None = None,
        timeout: int | None = None,
    ) -> dict[str, Any]:
        """Execute a workflow.

        Args:
            name: Workflow name
            inputs: Workflow inputs
            timeout: Execution timeout in seconds

        Returns:
            Execution result dict
        """
        body: dict[str, Any] = {"inputs": inputs or {}}
        if timeout:
            body["timeout"] = timeout
        return await self._request("POST", f"/api/v1/workflows/{name}/execute", json=body)

    # -------------------------------------------------------------------------
    # Tools
    # -------------------------------------------------------------------------

    async def list_tools(
        self,
        source: str | None = None,
        server: str | None = None,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List available tools.

        Args:
            source: Filter by source (mcp, system)
            server: Filter by MCP server name
            status: Filter by status (available, unavailable)

        Returns:
            List of tool summaries
        """
        params: dict[str, Any] = {}
        if source:
            params["source"] = source
        if server:
            params["server"] = server
        if status:
            params["status"] = status
        response = await self._request("GET", "/api/v1/tools", params=params or None)
        # API returns {"tools": [...]} but we want just the list
        if isinstance(response, dict) and "tools" in response:
            return response["tools"]
        return response

    async def get_tool(self, name: str) -> dict[str, Any]:
        """Get tool details.

        Args:
            name: Tool name

        Returns:
            Tool details dict
        """
        return await self._request("GET", f"/api/v1/tools/{name}")

    async def refresh_tools(self, server: str | None = None) -> dict[str, Any]:
        """Refresh tool schemas from MCP servers.

        Args:
            server: Refresh specific server only

        Returns:
            Refresh result dict
        """
        params = {"server": server} if server else None
        return await self._request("POST", "/api/v1/tools/refresh", params=params)

    # -------------------------------------------------------------------------
    # Config (server config, not CLI config)
    # -------------------------------------------------------------------------

    async def get_config(self, section: str | None = None) -> dict[str, Any]:
        """Get server configuration.

        Args:
            section: Specific section to retrieve

        Returns:
            Configuration dict
        """
        params = {"section": section} if section else None
        return await self._request("GET", "/api/v1/config", params=params)

    # -------------------------------------------------------------------------
    # Health
    # -------------------------------------------------------------------------

    async def health(self) -> dict[str, Any]:
        """Check server health.

        Returns:
            Health status dict
        """
        return await self._request("GET", "/health")

    # -------------------------------------------------------------------------
    # Executions
    # -------------------------------------------------------------------------

    async def list_executions(
        self,
        workflow: str | None = None,
        status: str | None = None,
        since: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """List execution history.

        Shows execution history from TelemetryStore (OSS: 7-day rolling
        retention). For compliance audit logs see Premium audit logging
        (F-024).

        Args:
            workflow: Filter by workflow name
            status: Filter by status (pending, running, completed, failed, cancelled)
            since: Filter by start date (ISO 8601)
            page: Page number (1-based)
            page_size: Results per page

        Returns:
            Paginated execution list response
        """
        params: dict[str, Any] = {"page": page, "page_size": page_size}
        if workflow:
            params["workflow_id"] = workflow
        if status:
            params["status"] = status
        if since:
            params["since"] = since
        return await self._request("GET", "/api/v1/executions", params=params)

    async def get_execution(self, execution_id: str) -> dict[str, Any]:
        """Get execution details.

        Shows execution history from TelemetryStore (OSS: 7-day rolling
        retention). For compliance audit logs see Premium audit logging
        (F-024).

        Args:
            execution_id: Execution ID

        Returns:
            Execution detail dict with steps, inputs, outputs
        """
        return await self._request("GET", f"/api/v1/executions/{execution_id}")

    # -------------------------------------------------------------------------
    # Runners
    # -------------------------------------------------------------------------

    async def create_runner(
        self,
        name: str,
        mcps: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new runner.

        Args:
            name: Runner name
            mcps: Optional MCP server configurations

        Returns:
            Runner creation response with token and install command
        """
        body: dict[str, Any] = {"name": name}
        if mcps:
            body["mcps"] = mcps
        return await self._request("POST", "/api/v1/runners", json=body)

    async def list_runners(
        self,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List all runners.

        Args:
            status: Filter by status (connected, disconnected)

        Returns:
            List of runner summaries
        """
        params: dict[str, Any] = {}
        if status:
            params["status"] = status
        response = await self._request("GET", "/api/v1/runners", params=params or None)
        return response.get("runners", [])

    async def get_runner(self, name: str) -> dict[str, Any]:
        """Get runner details.

        Args:
            name: Runner name

        Returns:
            Runner details dict
        """
        return await self._request("GET", f"/api/v1/runners/{name}")

    async def delete_runner(self, name: str) -> dict[str, Any]:
        """Delete a runner.

        Args:
            name: Runner name

        Returns:
            Deletion result dict
        """
        return await self._request("DELETE", f"/api/v1/runners/{name}")

    async def regenerate_runner_token(self, name: str) -> dict[str, Any]:
        """Regenerate a runner's authentication token.

        Args:
            name: Runner name

        Returns:
            Token response dict with name, token, and install_command
        """
        return await self._request("POST", f"/api/v1/runners/{name}/regenerate-token")

    # Config operations

    async def get_config_diff(self) -> dict[str, Any]:
        """Get diff between current config and staged changes.

        Returns:
            Diff response dict with diff, has_changes, and in_config_mode
        """
        return await self._request("GET", "/api/v1/config/diff")

    # -------------------------------------------------------------------------
    # Config Import Methods (for ploston init --import)
    # -------------------------------------------------------------------------

    async def check_cp_connectivity(self) -> CPConnectionResult:
        """Check if CP is reachable and responding.

        Uses existing health() method but wraps result in CPConnectionResult.

        Returns:
            CPConnectionResult with connection status and version info
        """
        try:
            data = await self.health()
            return CPConnectionResult(
                connected=True,
                url=self.base_url,
                version=data.get("version"),
            )
        except PlostClientError as e:
            return CPConnectionResult(
                connected=False,
                url=self.base_url,
                error=e.message,
            )

    async def get_mode(self) -> dict[str, Any]:
        """Get current operating mode.

        Returns:
            Response with mode, running_workflows, and optional message
        """
        return await self._request("GET", "/api/v1/config/mode")

    async def enter_configuration_mode(self) -> dict[str, Any]:
        """Enter configuration mode.

        Must be called before using config_set.

        Returns:
            Response with mode, running_workflows, and message
        """
        return await self._request(
            "POST",
            "/api/v1/config/mode",
            json={"mode": "configuration"},
        )

    async def config_set(self, path: str, value: Any) -> dict[str, Any]:
        """Stage a configuration change.

        Args:
            path: Dot-separated config path (e.g., "runners.local")
            value: Value to set at that path

        Returns:
            Response with staged status and validation result
        """
        return await self._request(
            "POST",
            "/api/v1/config/set",
            json={"path": path, "value": value},
        )

    async def config_done(self) -> dict[str, Any]:
        """Apply staged configuration changes.

        Returns:
            Response with success status and applied config info
        """
        return await self._request("POST", "/api/v1/config/done", json={})

    async def push_runner_config(
        self,
        runner_name: str,
        mcp_servers: dict[str, dict[str, Any]],
        token: str,
        merge: bool = False,
    ) -> dict[str, Any]:
        """Push runner configuration to CP via staged config API.

        Convenience method that:
        1. Enters configuration mode if needed
        2. Stages the runner config
        3. Applies changes via config_done

        Args:
            runner_name: Name of the runner (e.g., "local")
            mcp_servers: Dict of MCP server configurations
            token: Authentication token for the runner
            merge: If True, additively merge servers into existing config.
                   If False (default), full replacement of the runner's server list.

        Returns:
            Response from config_done
        """
        # Check current mode and enter configuration mode if needed
        mode_response = await self.get_mode()
        if mode_response.get("mode") != "configuration":
            await self.enter_configuration_mode()

        if merge:
            # Additive merge: read existing runner config, merge in new servers
            try:
                existing = await self._request("GET", f"/api/v1/config/runners/{runner_name}")
                existing_servers = existing.get("mcp_servers", {})
                existing_servers.update(mcp_servers)
                mcp_servers = existing_servers
            except PlostClientError:
                pass  # Runner doesn't exist yet — full creation

        runner_config = {
            "token": token,
            "mcp_servers": mcp_servers,
        }
        await self.config_set(f"runners.{runner_name}", runner_config)
        return await self.config_done()

    async def get_runner_token(self, runner_name: str) -> str:
        """Get the authentication token for a runner.

        Args:
            runner_name: Name of the runner

        Returns:
            The runner's authentication token

        Raises:
            PlostClientError: If runner not found (404)
        """
        response = await self._request(
            "GET",
            f"/api/v1/runners/{runner_name}/token",
        )
        return response["token"]
