# Generated code. Do not modify.
# flake8: noqa: F401, F405, F811

from __future__ import annotations

import enum
import typing

from pydivkit.core import BaseDiv, Expr, Field


# Sets the cursor position in the specified input field.
class DivActionSetCursorPosition(BaseDiv):
    def __init__(
        self,
        *,
        type: str = "set_cursor_position",
        id: typing.Optional[typing.Union[Expr, str]] = None,
        position: typing.Optional[DivActionSetCursorPositionPosition] = None,
        **kwargs: typing.Any,
    ):
        super().__init__(
            type=type,
            id=id,
            position=position,
            **kwargs,
        )

    type: str = Field(default="set_cursor_position")
    id: typing.Union[Expr, str] = Field(description="ID of the input field.")
    position: DivActionSetCursorPositionPosition = Field(
        description=(
            "Defines the cursor position. If `end` is not set, or if "
            "`end` is equal to`start`, it will just be the cursor "
            "position, if both are set and the values aredifferent, part "
            "of the text will be selected. Use 0 to indicate the "
            "beginning ofthe text, -1 for the end."
        )
    )


# Defines the cursor position. If `end` is not set, or if `end` is equal to
# `start`, it will just be the cursor position, if both are set and the values are
# different, part of the text will be selected. Use 0 to indicate the beginning of
# the text, -1 for the end.
class DivActionSetCursorPositionPosition(BaseDiv):
    def __init__(
        self,
        *,
        type: str = "absolute",
        end: typing.Optional[typing.Union[Expr, int]] = None,
        start: typing.Optional[typing.Union[Expr, int]] = None,
        **kwargs: typing.Any,
    ):
        super().__init__(
            type=type,
            end=end,
            start=start,
            **kwargs,
        )

    type: str = Field(default="absolute")
    end: typing.Optional[typing.Union[Expr, int]] = Field()
    start: typing.Union[Expr, int] = Field()


DivActionSetCursorPositionPosition.update_forward_refs()


DivActionSetCursorPosition.update_forward_refs()
