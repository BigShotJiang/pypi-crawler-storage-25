# Generated code. Do not modify.
# flake8: noqa: F401, F405, F811

from __future__ import annotations

import enum
import typing

from pydivkit.core import BaseDiv, Expr, Field


# Specifies the element with the given `id` as the scrolling end position.
class ItemIdDestination(BaseDiv):
    def __init__(
        self,
        *,
        type: str = "item_id",
        value: typing.Optional[typing.Union[Expr, str]] = None,
        **kwargs: typing.Any,
    ):
        super().__init__(
            type=type,
            value=value,
            **kwargs,
        )

    type: str = Field(default="item_id")
    value: typing.Union[Expr, str] = Field(
        description="Identifier of the container child element to scroll to."
    )


ItemIdDestination.update_forward_refs()
