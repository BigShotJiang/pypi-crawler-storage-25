# Generated code. Do not modify.
# flake8: noqa: F401, F405, F811

from __future__ import annotations

import enum
import typing

from pydivkit.core import BaseDiv, Expr, Field

from . import div_typed_value


# Temporarily saves the variable in storage.
class DivActionSetStoredValue(BaseDiv):
    def __init__(
        self,
        *,
        type: str = "set_stored_value",
        lifetime: typing.Optional[typing.Union[Expr, int]] = None,
        name: typing.Optional[typing.Union[Expr, str]] = None,
        scope: typing.Optional[typing.Union[Expr, DivActionSetStoredValueScope]] = None,
        value: typing.Optional[div_typed_value.DivTypedValue] = None,
        **kwargs: typing.Any,
    ):
        super().__init__(
            type=type,
            lifetime=lifetime,
            name=name,
            scope=scope,
            value=value,
            **kwargs,
        )

    type: str = Field(default="set_stored_value")
    lifetime: typing.Union[Expr, int] = Field(
        description="Duration of storage in seconds."
    )
    name: typing.Union[Expr, str] = Field(description="Name of the saved variable.")
    scope: typing.Optional[typing.Union[Expr, DivActionSetStoredValueScope]] = Field(
        description=(
            "Scope of the stored variable:`global` — not bound to a "
            "specific card (availablefor any card);`card` — bound to the "
            "current card. On Android the card isidentified by "
            "`DivDataTag`, on iOS by the `cardId` parameter, on Web the "
            "scopevalue is passed to `Store` and the developer "
            "integrating DivKit must implementsaving variables for that "
            "scope./nDefault value for Android and iOS is `global'.For "
            "Web, the implementation depends entirely on the developer."
        )
    )
    value: div_typed_value.DivTypedValue = Field(description="Saved value.")


class DivActionSetStoredValueScope(str, enum.Enum):
    GLOBAL = "global"
    CARD = "card"


DivActionSetStoredValue.update_forward_refs()
