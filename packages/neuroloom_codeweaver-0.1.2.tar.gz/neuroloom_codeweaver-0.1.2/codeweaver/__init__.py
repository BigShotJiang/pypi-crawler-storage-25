"""codeweaver — client-side Tree-sitter parser for Neuroloom code graph extraction."""

from codeweaver.parser import discover_files, parse_files

__all__ = ["discover_files", "parse_files"]
