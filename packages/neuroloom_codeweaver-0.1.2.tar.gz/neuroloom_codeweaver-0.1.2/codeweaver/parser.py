"""
Client-side Tree-sitter parser for the Neuroloom code graph.

Extracts structural metadata (symbols, call edges, import edges) from
TypeScript and Python source files. No source code is included in the
output — only names, types, line ranges, and structural relationships.

The parser runs client-side (in the MCP server process) so that:
  1. No source code crosses the network boundary
  2. Parsing uses the agent's local file system access
  3. The API receives only structural metadata

# Usage:
#   from codeweaver import discover_files, parse_files
#
#   files = discover_files("/path/to/project")
#   nodes = parse_files(files)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

logger = logging.getLogger(__name__)

# Directories to skip — build artifacts and vendored code
_SKIP_DIRS = frozenset({
    "node_modules", ".next", ".nuxt", "dist", "build", "out",
    ".turbo", ".cache", "__pycache__", ".git", "coverage",
    ".nyc_output", ".venv", "venv", "env", ".env",
    ".mypy_cache", ".ruff_cache", ".pytest_cache",
})

# File extensions to language mapping
_EXTENSION_MAP: dict[str, str] = {
    ".ts": "typescript",
    ".tsx": "typescript",
    ".mts": "typescript",
    ".py": "python",
}

_BATCH_SIZE = 500


# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------


@dataclass
class Symbol:
    """Extracted code symbol."""
    qualified_name: str
    name: str
    file_path: str
    symbol_type: str  # "function", "class", "module"
    line_start: int | None = None
    line_end: int | None = None
    language: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class Edge:
    """A structural edge between two symbols."""
    source_qualified_name: str
    target_qualified_name: str
    edge_type: str  # "calls", "imports", "inherits"
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Tree-sitter lazy import
# ---------------------------------------------------------------------------

def _get_ts_parser(language: str, is_tsx: bool = False) -> Any:
    """Lazily import tree-sitter and return a configured Parser.

    Raises ImportError with a clear message if tree-sitter is not installed.
    """
    try:
        from tree_sitter import Language, Parser
    except ImportError:
        raise ImportError(
            "tree-sitter is required for code_sync. Install with: "
            "pip install neuroloom-codeweaver"
        )

    if language == "typescript":
        try:
            import tree_sitter_typescript as ts_typescript
        except ImportError:
            raise ImportError(
                "tree-sitter-typescript is required for TypeScript parsing. "
                "Install with: pip install neuroloom-codeweaver"
            )
        if is_tsx:
            lang = Language(ts_typescript.language_tsx())
        else:
            lang = Language(ts_typescript.language_typescript())
        return Parser(lang)

    elif language == "python":
        try:
            import tree_sitter_python as ts_python
        except ImportError:
            raise ImportError(
                "tree-sitter-python is required for Python parsing. "
                "Install with: pip install neuroloom-codeweaver"
            )
        lang = Language(ts_python.language())
        return Parser(lang)

    else:
        raise ValueError(f"Unsupported language: {language}")


def _qualified(rel_path: str, name: str) -> str:
    """Build qualified_name: '{rel_path}::{name}'."""
    return f"{rel_path}::{name}"


def _decode_node_text(node: Any) -> str | None:
    """Decode a tree-sitter node's text bytes to str."""
    raw = node.text
    if raw is None:
        return None
    return cast(str, raw.decode("utf-8", errors="replace"))


# ---------------------------------------------------------------------------
# TypeScript parsing
# ---------------------------------------------------------------------------


def _parse_typescript(
    source: bytes,
    rel_path: str,
    is_tsx: bool,
) -> tuple[list[Symbol], list[Edge], list[Edge]]:
    """Parse TypeScript/TSX source, returning symbols, call edges, import edges."""
    parser = _get_ts_parser("typescript", is_tsx=is_tsx)
    tree = parser.parse(source)
    root = tree.root_node

    symbols: list[Symbol] = []
    call_edges: list[Edge] = []
    import_edges: list[Edge] = []

    # MODULE symbol — anchor for import edges
    module_qname = _qualified(rel_path, "MODULE")
    symbols.append(Symbol(
        qualified_name=module_qname,
        name="MODULE",
        file_path=rel_path,
        symbol_type="module",
        language="typescript",
    ))

    # Pass 1: collect declared symbols
    active_class: str | None = None

    def _visit_symbols(node: Any) -> None:
        nonlocal active_class
        ntype = node.type

        if ntype == "function_declaration":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                name = _decode_node_text(name_node)
                if name is not None:
                    symbols.append(Symbol(
                        qualified_name=_qualified(rel_path, name),
                        name=name,
                        file_path=rel_path,
                        symbol_type="function",
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        language="typescript",
                    ))

        elif ntype == "class_declaration":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                name = _decode_node_text(name_node)
                if name is not None:
                    symbols.append(Symbol(
                        qualified_name=_qualified(rel_path, name),
                        name=name,
                        file_path=rel_path,
                        symbol_type="class",
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        language="typescript",
                    ))
                    prev = active_class
                    active_class = name
                    for child in node.children:
                        _visit_symbols(child)
                    active_class = prev
                    return

        elif ntype == "method_definition":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                raw_name = _decode_node_text(name_node)
                if raw_name is not None:
                    full_name = f"{active_class}.{raw_name}" if active_class else raw_name
                    symbols.append(Symbol(
                        qualified_name=_qualified(rel_path, full_name),
                        name=full_name,
                        file_path=rel_path,
                        symbol_type="function",
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        language="typescript",
                    ))

        elif ntype == "arrow_function":
            parent = node.parent
            if parent is not None and parent.type == "variable_declarator":
                name_node = parent.child_by_field_name("name")
                if name_node is not None:
                    name = _decode_node_text(name_node)
                    if name is not None:
                        symbols.append(Symbol(
                            qualified_name=_qualified(rel_path, name),
                            name=name,
                            file_path=rel_path,
                            symbol_type="function",
                            line_start=node.start_point[0] + 1,
                            line_end=node.end_point[0] + 1,
                            language="typescript",
                        ))

        for child in node.children:
            _visit_symbols(child)

    _visit_symbols(root)

    # Build local name index for call resolution
    local_name_index: dict[str, str] = {s.name: s.qualified_name for s in symbols}
    # Secondary index for intra-class method calls (this.method())
    _bare_method_index: dict[str, dict[str, str]] = {}
    for s in symbols:
        if "." in s.name:
            cls_part, method_part = s.name.rsplit(".", 1)
            _bare_method_index.setdefault(cls_part, {})[method_part] = s.qualified_name

    # Pass 2: collect call and import edges
    current_fn_qname: str = module_qname

    def _derive_class_name(node: Any) -> str | None:
        ancestor = node.parent
        while ancestor is not None:
            if ancestor.type == "class_declaration":
                cn = ancestor.child_by_field_name("name")
                if cn is not None:
                    return _decode_node_text(cn)
                return None
            ancestor = ancestor.parent
        return None

    def _visit_edges(node: Any) -> None:
        nonlocal current_fn_qname
        ntype = node.type

        if ntype in ("function_declaration", "method_definition", "arrow_function"):
            enclosing: str | None = None
            if ntype == "function_declaration":
                n = node.child_by_field_name("name")
                if n is not None:
                    decoded = _decode_node_text(n)
                    if decoded is not None:
                        enclosing = _qualified(rel_path, decoded)
            elif ntype == "method_definition":
                n = node.child_by_field_name("name")
                if n is not None:
                    raw = _decode_node_text(n)
                    if raw is not None:
                        cls = _derive_class_name(node)
                        full = f"{cls}.{raw}" if cls else raw
                        enclosing = _qualified(rel_path, full)
            elif ntype == "arrow_function":
                p = node.parent
                if p is not None and p.type == "variable_declarator":
                    n = p.child_by_field_name("name")
                    if n is not None:
                        decoded = _decode_node_text(n)
                        if decoded is not None:
                            enclosing = _qualified(rel_path, decoded)

            if enclosing is not None:
                prev = current_fn_qname
                current_fn_qname = enclosing
                for child in node.children:
                    _visit_edges(child)
                current_fn_qname = prev
                return

        elif ntype == "call_expression":
            fn_node = node.child_by_field_name("function")
            if fn_node is not None:
                callee_name: str | None = None
                if fn_node.type == "identifier":
                    # Plain function call: do_something()
                    callee_name = _decode_node_text(fn_node)
                elif fn_node.type == "member_expression":
                    # Method call: obj.method() or this.method().
                    prop_node = fn_node.child_by_field_name("property")
                    obj_node = fn_node.child_by_field_name("object")
                    if prop_node is not None:
                        method_name = _decode_node_text(prop_node)
                        receiver = _decode_node_text(obj_node) if obj_node is not None else None
                        if method_name is not None and receiver == "this":
                            enclosing_cls = _derive_class_name(node)
                            if enclosing_cls and enclosing_cls in _bare_method_index:
                                target = _bare_method_index[enclosing_cls].get(method_name)
                                if target is not None:
                                    call_edges.append(Edge(
                                        source_qualified_name=current_fn_qname,
                                        target_qualified_name=target,
                                        edge_type="calls",
                                    ))
                                    method_name = None  # already handled
                            callee_name = method_name
                        elif method_name is not None:
                            callee_name = method_name
                if callee_name is not None and callee_name in local_name_index:
                    call_edges.append(Edge(
                        source_qualified_name=current_fn_qname,
                        target_qualified_name=local_name_index[callee_name],
                        edge_type="calls",
                    ))

        elif ntype == "import_statement":
            src_node = node.child_by_field_name("source")
            if src_node is not None:
                raw = _decode_node_text(src_node)
                if raw is not None:
                    stripped = raw.strip("\"'")
                    import_edges.append(Edge(
                        source_qualified_name=module_qname,
                        target_qualified_name=stripped,  # resolved post-parse
                        edge_type="imports",
                    ))

        for child in node.children:
            _visit_edges(child)

    _visit_edges(root)

    return symbols, call_edges, import_edges


# ---------------------------------------------------------------------------
# Python parsing
# ---------------------------------------------------------------------------


def _parse_python(
    source: bytes,
    rel_path: str,
) -> tuple[list[Symbol], list[Edge], list[Edge]]:
    """Parse Python source, returning symbols, call edges, import edges."""
    parser = _get_ts_parser("python")
    tree = parser.parse(source)
    root = tree.root_node

    symbols: list[Symbol] = []
    call_edges: list[Edge] = []
    import_edges: list[Edge] = []

    module_qname = _qualified(rel_path, "MODULE")
    symbols.append(Symbol(
        qualified_name=module_qname,
        name="MODULE",
        file_path=rel_path,
        symbol_type="module",
        language="python",
    ))

    active_class: str | None = None

    def _visit_symbols(node: Any) -> None:
        nonlocal active_class
        ntype = node.type

        if ntype == "function_definition":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                name = _decode_node_text(name_node)
                if name is not None:
                    full_name = f"{active_class}.{name}" if active_class else name
                    symbols.append(Symbol(
                        qualified_name=_qualified(rel_path, full_name),
                        name=full_name,
                        file_path=rel_path,
                        symbol_type="function",
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        language="python",
                    ))

        elif ntype == "class_definition":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                name = _decode_node_text(name_node)
                if name is not None:
                    symbols.append(Symbol(
                        qualified_name=_qualified(rel_path, name),
                        name=name,
                        file_path=rel_path,
                        symbol_type="class",
                        line_start=node.start_point[0] + 1,
                        line_end=node.end_point[0] + 1,
                        language="python",
                    ))
                    prev = active_class
                    active_class = name
                    for child in node.children:
                        _visit_symbols(child)
                    active_class = prev
                    return

        for child in node.children:
            _visit_symbols(child)

    _visit_symbols(root)

    local_name_index: dict[str, str] = {s.name: s.qualified_name for s in symbols}
    # Secondary index for intra-class method calls: bare method name → qname.
    # local_name_index keys are "ClassName.method" for methods, so "self.run()"
    # extracting bare "run" won't match.  This index maps "run" → qname for
    # method symbols, enabling intra-class call resolution.  If multiple classes
    # define the same method name, the last one wins (acceptable heuristic —
    # the enclosing class check below disambiguates for self/this calls).
    _bare_method_index: dict[str, dict[str, str]] = {}  # class_name → {method → qname}
    for s in symbols:
        if "." in s.name:
            cls_part, method_part = s.name.rsplit(".", 1)
            _bare_method_index.setdefault(cls_part, {})[method_part] = s.qualified_name
    current_fn_qname: str = module_qname

    def _derive_class_name(node: Any) -> str | None:
        ancestor = node.parent
        while ancestor is not None:
            if ancestor.type == "class_definition":
                cn = ancestor.child_by_field_name("name")
                if cn is not None:
                    return _decode_node_text(cn)
                return None
            ancestor = ancestor.parent
        return None

    def _visit_edges(node: Any) -> None:
        nonlocal current_fn_qname
        ntype = node.type

        if ntype == "function_definition":
            name_node = node.child_by_field_name("name")
            if name_node is not None:
                raw = _decode_node_text(name_node)
                if raw is not None:
                    cls = _derive_class_name(node)
                    full = f"{cls}.{raw}" if cls else raw
                    enclosing = _qualified(rel_path, full)
                    prev = current_fn_qname
                    current_fn_qname = enclosing
                    for child in node.children:
                        _visit_edges(child)
                    current_fn_qname = prev
                    return

        elif ntype == "call":
            fn_node = node.child_by_field_name("function")
            if fn_node is not None:
                py_callee_name: str | None = None
                if fn_node.type == "identifier":
                    # Plain function call: do_something()
                    py_callee_name = _decode_node_text(fn_node)
                elif fn_node.type == "attribute":
                    # Method call: self.method() or engine.run().
                    # For self/cls calls, resolve via the enclosing class's
                    # method index to get intra-class edges.  For other
                    # receivers, fall back to bare-name lookup.
                    attr_node = fn_node.child_by_field_name("attribute")
                    obj_node = fn_node.child_by_field_name("object")
                    if attr_node is not None:
                        method_name = _decode_node_text(attr_node)
                        receiver = _decode_node_text(obj_node) if obj_node is not None else None
                        if method_name is not None and receiver in ("self", "cls"):
                            # Intra-class call — look up via enclosing class
                            enclosing_cls = _derive_class_name(node)
                            if enclosing_cls and enclosing_cls in _bare_method_index:
                                py_callee_name = method_name
                                target = _bare_method_index[enclosing_cls].get(method_name)
                                if target is not None:
                                    call_edges.append(Edge(
                                        source_qualified_name=current_fn_qname,
                                        target_qualified_name=target,
                                        edge_type="calls",
                                    ))
                                    py_callee_name = None  # already handled
                        elif method_name is not None:
                            py_callee_name = method_name
                if py_callee_name is not None and py_callee_name in local_name_index:
                    call_edges.append(Edge(
                        source_qualified_name=current_fn_qname,
                        target_qualified_name=local_name_index[py_callee_name],
                        edge_type="calls",
                    ))

        elif ntype == "import_from_statement":
            module_node = node.child_by_field_name("module_name")
            if module_node is not None:
                module_name = _decode_node_text(module_node)
                if module_name is not None:
                    import_edges.append(Edge(
                        source_qualified_name=module_qname,
                        target_qualified_name=module_name,
                        edge_type="imports",
                    ))

        elif ntype == "import_statement":
            for child in node.children:
                if child.type == "dotted_name":
                    module_name = _decode_node_text(child)
                    if module_name is not None:
                        import_edges.append(Edge(
                            source_qualified_name=module_qname,
                            target_qualified_name=module_name,
                            edge_type="imports",
                        ))

        for child in node.children:
            _visit_edges(child)

    _visit_edges(root)

    return symbols, call_edges, import_edges


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------


def discover_files(root: Path, extensions: set[str] | None = None) -> list[Path]:
    """Walk root recursively, returning files with supported extensions.

    Skips directories in _SKIP_DIRS.
    """
    if extensions is None:
        extensions = set(_EXTENSION_MAP.keys())

    results: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if any(part in _SKIP_DIRS for part in path.parts):
            continue
        if path.suffix in extensions:
            results.append(path)
    return sorted(results)


# ---------------------------------------------------------------------------
# Import map construction and call resolution
# ---------------------------------------------------------------------------


@dataclass
class ImportMap:
    """Per-file import resolution table.

    Maps local names to their source qualified names so call edges
    can be resolved to the correct target symbol.
    """
    # Maps local name -> source qualified_name
    named_imports: dict[str, str] = field(default_factory=dict)
    # Maps module path -> list of re-exported names (barrel files)
    namespace_imports: dict[str, list[str]] = field(default_factory=dict)


def _resolve_ts_import_path(
    importer_rel: str,
    import_path: str,
    known_files: set[str],
    file_stem_index: dict[str, str],
) -> str | None:
    """Resolve a TypeScript relative import to a workspace-relative file path."""
    if not import_path.startswith("."):
        return None  # external package

    importer_dir = str(Path(importer_rel).parent)
    if importer_dir == ".":
        resolved_base = import_path
    else:
        resolved_base = str(Path(importer_dir) / import_path)

    resolved_base = str(Path(resolved_base))

    # Try exact match
    if resolved_base in file_stem_index:
        return file_stem_index[resolved_base]

    # Try extension guessing
    for suffix in (".ts", ".tsx", "/index.ts", "/index.tsx"):
        candidate = resolved_base + suffix
        if candidate in known_files:
            return candidate

    return None


def _build_ts_import_map(
    source: bytes,
    rel_path: str,
    is_tsx: bool,
    known_files: set[str],
    file_stem_index: dict[str, str],
    all_symbols_by_file: dict[str, list[Symbol]],
    _visited: set[str] | None = None,
    _depth: int = 0,
) -> ImportMap:
    """Build an import map for a TypeScript file.

    Parses import statements and resolves them to qualified names.
    Follows barrel file re-exports up to 5 hops with cycle detection.
    """
    MAX_BARREL_DEPTH = 5
    import_map = ImportMap()

    if _visited is None:
        _visited = set()
    if rel_path in _visited or _depth > MAX_BARREL_DEPTH:
        if _depth > MAX_BARREL_DEPTH:
            logger.warning("Barrel file depth cap hit at %s (depth %d)", rel_path, _depth)
        return import_map
    _visited.add(rel_path)

    parser = _get_ts_parser("typescript", is_tsx=is_tsx)
    tree = parser.parse(source)
    root = tree.root_node

    for node in root.children:
        if node.type != "import_statement":
            continue

        src_node = node.child_by_field_name("source")
        if src_node is None:
            continue
        raw_source = _decode_node_text(src_node)
        if raw_source is None:
            continue
        module_spec = raw_source.strip("\"'")

        resolved_file = _resolve_ts_import_path(
            rel_path, module_spec, known_files, file_stem_index
        )
        if resolved_file is None:
            continue

        # Extract named imports: import { Foo, Bar } from "./module"
        for child in node.children:
            if child.type == "import_clause":
                for clause_child in child.children:
                    if clause_child.type == "named_imports":
                        for spec in clause_child.children:
                            if spec.type == "import_specifier":
                                name_node = spec.child_by_field_name("name")
                                alias_node = spec.child_by_field_name("alias")
                                if name_node is not None:
                                    original_name = _decode_node_text(name_node)
                                    local_name = (
                                        _decode_node_text(alias_node)
                                        if alias_node is not None
                                        else original_name
                                    )
                                    if original_name and local_name:
                                        target_qname = f"{resolved_file}::{original_name}"
                                        import_map.named_imports[local_name] = target_qname

    return import_map


def _build_py_import_map(
    source: bytes,
    rel_path: str,
) -> ImportMap:
    """Build an import map for a Python file.

    Handles:
    - from .module import name (relative imports)
    - from module import name (absolute imports)
    - import module
    """
    import_map = ImportMap()

    parser = _get_ts_parser("python")
    tree = parser.parse(source)
    root = tree.root_node

    for node in root.children:
        if node.type == "import_from_statement":
            module_node = node.child_by_field_name("module_name")
            if module_node is None:
                continue
            module_name = _decode_node_text(module_node)
            if module_name is None:
                continue

            # Resolve relative imports
            if module_name.startswith("."):
                dots = len(module_name) - len(module_name.lstrip("."))
                rel_module = module_name[dots:]
                current_dir = Path(rel_path).parent
                for _ in range(dots - 1):
                    current_dir = current_dir.parent
                if rel_module:
                    base_path = str(current_dir / rel_module.replace(".", "/"))
                else:
                    base_path = str(current_dir)
                module_name = base_path.replace("/", ".")

            # Extract named imports
            for child in node.children:
                if child.type == "dotted_name" and child != module_node:
                    name = _decode_node_text(child)
                    if name:
                        import_map.named_imports[name] = f"{module_name}::{name}"
                elif child.type == "aliased_import":
                    name_node = child.child_by_field_name("name")
                    alias_node = child.child_by_field_name("alias")
                    if name_node is not None:
                        original = _decode_node_text(name_node)
                        local = (
                            _decode_node_text(alias_node)
                            if alias_node is not None
                            else original
                        )
                        if original and local:
                            import_map.named_imports[local] = f"{module_name}::{original}"

    return import_map


def resolve_call(
    callee_name: str,
    import_map: ImportMap,
    same_file_symbols: dict[str, str],
    global_name_index: dict[str, str],
) -> str | None:
    """Resolve a call expression to a qualified name.

    Priority:
    1. Import-scoped match (callee in file's import map)
    2. Same-file match (callee defined in this file)
    3. Bare-name fallback (callee in global index)
    """
    # 1. Import-scoped
    if callee_name in import_map.named_imports:
        return import_map.named_imports[callee_name]
    # 2. Same-file
    if callee_name in same_file_symbols:
        return same_file_symbols[callee_name]
    # 3. Bare-name fallback
    return global_name_index.get(callee_name)


# ---------------------------------------------------------------------------
# Single-file parsing
# ---------------------------------------------------------------------------


def parse_file(
    path: Path,
    rel_path: str,
    language: str,
) -> tuple[list[Symbol], list[Edge], list[Edge]]:
    """Parse a single file and return (symbols, call_edges, import_edges).

    Args:
        path: Absolute path to the source file.
        rel_path: Workspace-relative path (used in qualified names).
        language: "typescript" or "python".

    Returns:
        Tuple of (symbols, call_edges, import_edges).
    """
    source = path.read_bytes()

    if language == "typescript":
        is_tsx = path.suffix == ".tsx"
        return _parse_typescript(source, rel_path, is_tsx)
    elif language == "python":
        return _parse_python(source, rel_path)
    else:
        raise ValueError(f"Unsupported language: {language}")


# ---------------------------------------------------------------------------
# Multi-file parsing → SyncPayload
# ---------------------------------------------------------------------------


def parse_files(
    paths: list[Path],
    workspace_root: Path,
) -> dict[str, Any]:
    """Parse multiple files and return a dict matching the SyncPayload schema.

    Uses import-scoped call resolution when possible, falling back to
    bare-name matching for unresolvable calls.
    """
    # Phase 1: Parse all files (bare-name resolution)
    all_symbols: list[Symbol] = []
    all_call_edges: list[Edge] = []
    symbols_by_file: dict[str, list[Symbol]] = {}
    file_sources: dict[str, bytes] = {}

    known_files: set[str] = set()
    file_stem_index: dict[str, str] = {}

    for abs_path in paths:
        if not abs_path.is_file():
            continue
        rel = str(abs_path.relative_to(workspace_root))
        known_files.add(rel)
        stem = str(abs_path.with_suffix("").relative_to(workspace_root))
        file_stem_index[stem] = rel
        file_stem_index[rel] = rel

    for abs_path in paths:
        if not abs_path.is_file():
            continue

        suffix = abs_path.suffix
        language = _EXTENSION_MAP.get(suffix)
        if language is None:
            continue

        rel_path = str(abs_path.relative_to(workspace_root))

        try:
            source = abs_path.read_bytes()
            file_sources[rel_path] = source
            syms, calls, imports = parse_file(abs_path, rel_path, language)
            all_symbols.extend(syms)
            all_call_edges.extend(calls)
            # imports are used by parse_file() callers but not by parse_files()
            # — Phase 2 re-parses source bytes to build import maps directly.
            symbols_by_file[rel_path] = syms
        except Exception:
            logger.exception("Failed to parse %s", rel_path)
            continue

    # Phase 2: Build import maps and re-resolve call edges
    global_name_index: dict[str, str] = {s.name: s.qualified_name for s in all_symbols}

    resolved_edges: list[Edge] = []
    for edge in all_call_edges:
        # Extract file path from source qualified name (format: "file::name")
        src_parts = edge.source_qualified_name.split("::", 1)
        if len(src_parts) < 2:
            resolved_edges.append(edge)
            continue

        src_file = src_parts[0]
        callee_parts = edge.target_qualified_name.split("::", 1)
        callee_name = callee_parts[1] if len(callee_parts) == 2 else edge.target_qualified_name

        # Build same-file symbol index
        same_file = {
            s.name: s.qualified_name
            for s in symbols_by_file.get(src_file, [])
        }

        # Build import map for this file
        source_bytes = file_sources.get(src_file)
        language = _EXTENSION_MAP.get(Path(src_file).suffix, "")
        import_map = ImportMap()

        if source_bytes and language == "typescript":
            is_tsx = src_file.endswith(".tsx")
            try:
                import_map = _build_ts_import_map(
                    source_bytes, src_file, is_tsx,
                    known_files, file_stem_index, symbols_by_file,
                )
            except Exception:
                logger.debug("Failed to build import map for %s", src_file)
        elif source_bytes and language == "python":
            try:
                import_map = _build_py_import_map(source_bytes, src_file)
            except Exception:
                logger.debug("Failed to build import map for %s", src_file)

        # Resolve
        resolved_target = resolve_call(callee_name, import_map, same_file, global_name_index)
        if resolved_target:
            resolved_edges.append(Edge(
                source_qualified_name=edge.source_qualified_name,
                target_qualified_name=resolved_target,
                edge_type=edge.edge_type,
                metadata=edge.metadata,
            ))
        # else: drop unresolvable edge

    # Build payload
    symbols_payload = [
        {
            "qualified_name": s.qualified_name,
            "name": s.name,
            "file_path": s.file_path,
            "symbol_type": s.symbol_type,
            "line_start": s.line_start,
            "line_end": s.line_end,
            "language": s.language,
            "metadata": s.metadata,
        }
        for s in all_symbols
    ]

    # Only include resolved call edges in the sync payload.  Import edges
    # have raw module paths as targets (e.g. "..config") that cannot be
    # resolved to symbol IDs during sync — they already served their
    # purpose building import maps for cross-file call resolution above.
    all_resolved_qnames = {s.qualified_name for s in all_symbols}
    all_edges_final = [
        e for e in resolved_edges
        if e.source_qualified_name in all_resolved_qnames
        and e.target_qualified_name in all_resolved_qnames
        and e.source_qualified_name != e.target_qualified_name
    ]
    edges_payload = [
        {
            "source_qualified_name": e.source_qualified_name,
            "target_qualified_name": e.target_qualified_name,
            "edge_type": e.edge_type,
            "metadata": e.metadata,
        }
        for e in all_edges_final
    ]

    return {
        "symbols": symbols_payload,
        "edges": edges_payload,
        "deleted_files": [],
    }
