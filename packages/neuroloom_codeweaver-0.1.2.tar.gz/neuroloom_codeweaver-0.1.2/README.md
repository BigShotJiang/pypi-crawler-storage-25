# neuroloom-codeweaver

Client-side Tree-sitter parser for Neuroloom code graph extraction.

## Install

```bash
pip install neuroloom-codeweaver
```

## Usage

```python
from codeweaver import discover_files, parse_files

# Discover source files under a directory
files = discover_files("/path/to/project")

# Parse them into structured code graph nodes
nodes = parse_files(files)
```

This package is intentionally standalone — it has no dependency on any Neuroloom server package.
Source code is parsed locally; only structural metadata (names, types, line ranges, relationships)
is produced.
