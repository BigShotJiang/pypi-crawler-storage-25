"""Workspace `git diff` reader.

The local CLI's job for `check_local_diff`: shell out to `git diff` in
the workspace, capture the unified diff, hand it to the cloud server
which runs the validator suite.

We diff against HEAD (working tree + staged) so the result captures
"everything that's changed since the last commit" — the most analogous
proxy for "what would my next PR contain". The agent can scope to
specific paths.
"""
from __future__ import annotations

import subprocess
from pathlib import Path


class DiffReadError(RuntimeError):
    """Raised when `git diff` fails (not a git repo, git missing, etc.)."""


def read_workspace_diff(
    repo_path: Path,
    scope_paths: list[str] | None = None,
    against: str = "HEAD",
    timeout: float = 30.0,
) -> str:
    """Run `git diff <against>` in `repo_path`. Returns the unified diff string.

    Args:
        repo_path: Workspace root.
        scope_paths: Optional list of git pathspecs to scope the diff.
        against: Git ref to diff against. Defaults to "HEAD" (working tree
            vs last commit — captures uncommitted + staged work). Pass a
            branch name like "main" to check working-tree vs that branch,
            or "main..HEAD" for branch-only changes (closest analogue to
            "what would land in a PR opened against main").
        timeout: Subprocess timeout in seconds.

    Empty diff returns an empty string.

    Raises:
        DiffReadError: git invocation failed (missing binary, not a
            repo, network filesystem refused, etc.).
    """
    cmd = ["git", "diff", against]
    if scope_paths:
        cmd.append("--")
        cmd.extend(scope_paths)

    try:
        result = subprocess.run(
            cmd,
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except FileNotFoundError as e:
        raise DiffReadError(f"`git` not found on PATH: {e}") from None
    except subprocess.TimeoutExpired:
        raise DiffReadError(f"git diff timed out after {timeout}s") from None

    if result.returncode != 0:
        # `git diff` returns 0 when a diff exists. Non-zero is a real error
        # (not a repo, bad pathspec, etc.). Surface stderr verbatim — it's
        # already user-friendly.
        raise DiffReadError(
            f"git diff failed (exit {result.returncode}): "
            f"{(result.stderr or '').strip() or '(no stderr)'}"
        )
    return result.stdout
