"""Credentials cache for the `archrails` CLI.

Stores the customer's API key + endpoint URLs at
`~/.archrails/credentials.json`, mode 0600. The file is local-only and
never synced anywhere by us — it's the same trust shape as
`~/.aws/credentials`.

Schema (versioned so we can evolve it without breaking installs):

    {
      "version": 1,
      "api_base":   "https://api.archrails.io",
      "mcp_url":    "https://<function-url>/",
      "dashboard":  "https://dashboard.archrails.io",
      "api_key":    "ar_live_...",
      "key_id":     "xFL9fAM3",
      "tenant_pk":  "TENANT#...",
      "username":   "alice@acme.com",
      "saved_at":   "2026-05-01T20:00:00Z"
    }

`api_key` is the only secret. The other fields are convenience metadata
the dashboard populates when minting the key, so the CLI can echo
"signed in as X (tenant Y)" without an extra round-trip.
"""
from __future__ import annotations

import json
import os
import stat
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

CREDENTIALS_DIR = Path(os.environ.get("ARCHRAILS_HOME") or (Path.home() / ".archrails"))
CREDENTIALS_PATH = CREDENTIALS_DIR / "credentials.json"

# Defaults — overrideable per-tenant via env or login args.
DEFAULT_API_BASE = os.environ.get(
    "ARCHRAILS_API_BASE",
    "https://ugq071csi5.execute-api.us-east-2.amazonaws.com",
)
DEFAULT_DASHBOARD = os.environ.get(
    "ARCHRAILS_DASHBOARD",
    "https://dk5t3868p8t0g.cloudfront.net",
)
DEFAULT_MCP_URL = os.environ.get(
    "ARCHRAILS_CLOUD_MCP_URL",
    # Stable customer-facing hostname — CNAME at Cloudflare points at
    # whichever AWS account's API Gateway terraform was last applied
    # against. Account-portable: a future dev→prod migration is a
    # one-line CNAME flip, not a wheel re-release. The cert + custom
    # domain themselves live in the same account as the Lambda; see
    # terraform/mcp_custom_domain.tf for the topology.
    "https://mcp.archrails.io/mcp",
)


@dataclass
class Credentials:
    api_key: str
    api_base: str = DEFAULT_API_BASE
    mcp_url: str = DEFAULT_MCP_URL
    dashboard: str = DEFAULT_DASHBOARD
    key_id: str = ""
    tenant_pk: str = ""
    username: str = ""
    saved_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    version: int = 1


def load() -> Credentials | None:
    """Read the on-disk credentials, or None if not signed in."""
    if not CREDENTIALS_PATH.is_file():
        return None
    try:
        data = json.loads(CREDENTIALS_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    # Tolerate older schemas — only `api_key` is strictly required.
    if not data.get("api_key"):
        return None
    known = {f.name for f in Credentials.__dataclass_fields__.values()}
    return Credentials(**{k: v for k, v in data.items() if k in known})


def save(creds: Credentials) -> Path:
    """Write credentials to disk with 0600 permissions. Returns the path."""
    CREDENTIALS_DIR.mkdir(parents=True, exist_ok=True)
    payload = asdict(creds)
    payload["saved_at"] = datetime.now(timezone.utc).isoformat()
    CREDENTIALS_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    try:
        os.chmod(CREDENTIALS_PATH, stat.S_IRUSR | stat.S_IWUSR)  # 0600
    except OSError:
        # Windows or restricted FS — best effort.
        pass
    return CREDENTIALS_PATH


def clear() -> bool:
    """Remove the credentials file. Returns True iff a file was removed."""
    if CREDENTIALS_PATH.is_file():
        CREDENTIALS_PATH.unlink()
        return True
    return False


# ── Provisioning gate ────────────────────────────────────────────────────────

# Undocumented escape hatch for our own CI / dev installs that need to run
# the MCP server without going through `archrails login`. Intentionally not
# advertised in user-facing error text or the README — anyone determined
# enough to bypass the gate can grep the source, but a typical
# unprovisioned user just sees "run archrails login."
_SKIP_AUTH_ENV = "ARCHRAILS_SKIP_AUTH"


class NotProvisioned(RuntimeError):
    """Raised when an authenticated entry point is invoked without
    cached credentials. The CLI catches this and exits non-zero with a
    pointer to `archrails login`."""


def require_credentials() -> Credentials | None:
    """Return cached credentials, or raise NotProvisioned.

    Honored by `archrails mcp start` (both code and architect modes) so
    unprovisioned users can't run the local MCP server. `archrails calm
    …`, `archrails arch init`, `archrails bootstrap`, and the login /
    logout commands deliberately do NOT call this — they are either
    pre-auth (bootstrap, login) or thin wrappers around the FINOS CLI
    that gating wouldn't meaningfully protect.

    Set ARCHRAILS_SKIP_AUTH=1 to bypass (development / CI only). When
    bypassed, returns None so callers can branch on "no creds" if they
    care.
    """
    if os.environ.get(_SKIP_AUTH_ENV, "").strip().lower() in ("1", "true", "yes"):
        return None
    creds = load()
    if creds is None:
        raise NotProvisioned(
            "No ArchRails credentials cached.\n"
            "\n"
            f"Expected: {CREDENTIALS_PATH}\n"
            "\n"
            "To provision this machine, run one of:\n"
            "    archrails bootstrap       # first-time setup\n"
            "    archrails login           # if you've bootstrapped before\n"
            "\n"
            "ArchRails MCP requires an active account. If you don't have\n"
            "one yet, contact your ArchRails admin or visit the dashboard."
        )
    return creds
