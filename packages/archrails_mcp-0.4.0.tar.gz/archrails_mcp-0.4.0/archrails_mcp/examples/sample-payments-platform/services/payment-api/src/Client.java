// Stub source file used by archrails-mcp examples. The path
// services/payment-api/** is bound to the `payment-api` node by
// archrails.yml, so resolve_path_to_node returns that here.
package com.acme.payment;

public class Client {}
