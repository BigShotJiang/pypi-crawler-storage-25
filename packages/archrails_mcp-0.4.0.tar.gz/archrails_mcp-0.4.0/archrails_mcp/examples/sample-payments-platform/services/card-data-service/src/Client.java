// Stub source file used by archrails-mcp examples. The path
// services/card-data-service/** is bound to the `card-data-service` node by
// archrails.yml, so resolve_path_to_node returns that here.
package com.acme.carddata;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class Client {
    private static final URI CARD_DB_ROOT = URI.create("https://card-db.internal/");

    public HttpResponse<String> get(String path) throws Exception {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request =
                HttpRequest.newBuilder(CARD_DB_ROOT.resolve(path.stripLeading('/')))
                        .GET()
                        .build();
        return client.send(request, HttpResponse.BodyHandlers.ofString());
    }
}
