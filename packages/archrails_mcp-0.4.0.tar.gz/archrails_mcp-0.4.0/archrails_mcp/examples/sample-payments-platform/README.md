# sample-payments-platform

A tiny CALM topology used by `archrails demo`, the LinkedIn product
walkthrough, and the parity-test fixtures. Four nodes, three CALM
relationships, one PCI control attached.

## Layout

```
.
├── archrails.yml                          # binds source paths → CALM nodes
├── architecture/
│   └── system.calm.json                   # CALM v1.x architecture document
└── services/
    └── payment-api/
        └── src/
            └── Client.java                # stub source mapped to payment-api
```

## The architecture in one breath

- `payment-api` — public-facing payment service, **PCI-scoped**
  (`controls: pci-no-card-logging`)
- `card-data-service` — tokenization layer, the **only** node CALM lets
  reach `card-db`
- `card-db` — PCI database, no node may talk to it directly
- `fraud-api` — fraud screening, called by `payment-api`

CALM-allowed relationships:

| from | to | protocol |
|---|---|---|
| `payment-api` | `card-data-service` | https |
| `payment-api` | `fraud-api` | https |
| `card-data-service` | `card-db` | tcp:5432 |

If anything tries to add `payment-api → card-db` directly, ArchRails
fires `AR-CTRL-DB-BOUNDARY-001` and lists the CALM-allowed alternatives.

## Try it

### Option A — let an AI agent see the rules

Wire your IDE to the sample as the workspace and let the agent
(Claude Code, Cursor, Windsurf) explore. The MCP server exposes
`get_architecture_context`, `resolve_path_to_node`,
`check_proposed_change`, `get_blast_radius`, and `check_local_diff`.

```bash
archrails mcp start --repo .
```

(With `archrails-local` already registered in your IDE — `archrails
bootstrap` wires this for you.)

Then ask the agent something like:

> *"Add a function in payment-api that fetches a card record directly
> from card-db by primary key."*

The agent will call `check_proposed_change`, get back
`allowed: false` with `AR-CTRL-DB-BOUNDARY-001`, see the allowed
alternatives in the response, and reroute through `card-data-service`.

### Option B — write a bad change by hand and check it

```bash
git init -q && git add -A && git commit -qm baseline
# Edit services/payment-api/src/Client.java to add a card-db.internal
# JDBC connection string.
archrails check
```

Same validators that fire at PR-time fire here. Same rule IDs, same
verdicts. Requires `archrails login` first.

## Going further

- New to CALM? Start with the [FINOS CALM tutorials](https://calm.finos.org/tutorials/)
- Want this on your own repo? ArchRails is currently invite-only beta
  — contact us for access.
