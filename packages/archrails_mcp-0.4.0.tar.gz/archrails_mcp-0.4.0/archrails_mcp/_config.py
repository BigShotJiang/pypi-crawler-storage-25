"""Minimal archrails.yml schema + loader, inlined into the local CLI.

The full config schema lives in `shared.calm.archrails_config` (server-
side), but we don't ship `shared/` in the CLI wheel — it would leak
validators, audit logic, and federation code. Architect-mode local
tools (`bind_path`, `validate_architecture`) need *just enough* of the
schema to read sources + mappings out of archrails.yml; that subset
lives here.

Kept tiny on purpose. If a field isn't accessed by `bind_path`,
`validate_architecture`, or the local `graph_loader.load_graph`, it's
not modelled here. Adding a field is cheap; bloating this with PR-time
config knobs reverses the IP boundary we set up.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import yaml


class ArchrailsConfigParseError(Exception):
    """YAML syntax error or top-level shape error in archrails.yml."""


@dataclass
class MappingRule:
    path: str
    node: str


@dataclass
class MonorepoSource:
    """One entry in governance.sources[] — maps to one CALM file."""
    id: str
    file: str
    paths: list[str] = field(default_factory=list)


@dataclass
class MonorepoGovernanceConfig:
    provider: str = "calm"
    sources: list[MonorepoSource] = field(default_factory=list)


@dataclass
class MonorepoArchrailsConfig:
    """Trimmed schema covering only the fields local architect-mode tools touch."""
    version: int = 1
    governance: MonorepoGovernanceConfig = field(default_factory=MonorepoGovernanceConfig)
    mapping: list[MappingRule] = field(default_factory=list)


def load_archrails_config(raw_yaml: str) -> MonorepoArchrailsConfig:
    """Parse archrails.yml into the trimmed MonorepoArchrailsConfig.

    Raises:
        ArchrailsConfigParseError: YAML invalid or top-level not a mapping.
    """
    if not raw_yaml or not raw_yaml.strip():
        raise ArchrailsConfigParseError("archrails.yml is empty")

    try:
        data = yaml.safe_load(raw_yaml)
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        location = f" (line {mark.line + 1}, col {mark.column + 1})" if mark else ""
        problem = getattr(exc, "problem", str(exc))
        raise ArchrailsConfigParseError(
            f"Invalid YAML in archrails.yml{location}: {problem}"
        ) from exc

    if not isinstance(data, dict):
        raise ArchrailsConfigParseError(
            "archrails.yml must be a YAML mapping at the top level"
        )

    gov_raw = data.get("governance") or {}
    sources_raw = gov_raw.get("sources") or []
    sources: list[MonorepoSource] = []
    for s in sources_raw if isinstance(sources_raw, list) else []:
        if not isinstance(s, dict):
            continue
        src_id = s.get("id") or ""
        src_file = s.get("file") or ""
        if not src_id or not src_file:
            continue
        sources.append(MonorepoSource(
            id=src_id,
            file=src_file,
            paths=s.get("paths") or [],
        ))

    mapping: list[MappingRule] = []
    for entry in (data.get("mapping") or []):
        if isinstance(entry, dict) and "path" in entry and "node" in entry:
            mapping.append(MappingRule(path=entry["path"], node=entry["node"]))

    return MonorepoArchrailsConfig(
        version=int(data.get("version", 1)),
        governance=MonorepoGovernanceConfig(
            provider=gov_raw.get("provider", "calm"),
            sources=sources,
        ),
        mapping=mapping,
    )
