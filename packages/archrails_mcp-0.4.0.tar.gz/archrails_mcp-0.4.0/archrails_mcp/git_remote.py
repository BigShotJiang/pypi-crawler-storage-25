"""Workspace git-remote URL reader.

The local CLI runs `git remote get-url origin` on the workspace it was
started against (`archrails mcp start --repo /path/...`) and ships the
canonicalized URL to the cloud handler in the X-Archrails-Repo-URL
header on every JSON-RPC request.

Why this exists
---------------
A developer can have multiple ArchRails-tracked repos checked out on
one machine (traderx-trading, traderx-accounts, traderx-data-platform,
…). They typically have ONE tenant-scoped MCP key cached in
~/.archrails/credentials.json. When the IDE opens a specific workspace,
Claude Code (or whatever) launches `archrails mcp start --repo
<that workspace>` — one MCP subprocess per workspace.

The cloud needs to know WHICH of the tenant's repos to load the graph
for. The MCP key alone doesn't tell it (when the key is tenant-wide).
The workspace's git remote does.

Failure mode is graceful: if there's no git remote, no `origin`, or
git is missing, we return None. The cloud handler then surfaces an
actionable error to the agent ("set X-Archrails-Repo-URL or use a
repo-scoped key").
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path


def read_origin_url(repo_path: Path, timeout: float = 5.0) -> str | None:
    """Return `git remote get-url origin` for `repo_path`, normalized to
    the canonical https URL form ArchRails uses internally.

    Examples (input → output):
      git@github.com:Acme/Pay.git           → https://github.com/Acme/Pay
      https://github.com/Acme/Pay.git       → https://github.com/Acme/Pay
      https://github.com/Acme/Pay           → https://github.com/Acme/Pay
      ssh://git@github.com/Acme/Pay.git     → https://github.com/Acme/Pay

    Returns None on any failure (not a repo, no `origin`, git missing,
    timeout, unrecognized URL shape). Callers MUST handle None — we
    don't raise so a missing remote never crashes the MCP startup.
    """
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None

    if result.returncode != 0:
        return None

    raw = (result.stdout or "").strip()
    if not raw:
        return None

    return _normalize_remote_url(raw)


def _normalize_remote_url(url: str) -> str | None:
    """Convert any common git remote URL shape to `https://host/owner/repo`.

    Tolerates:
      - SSH style: `git@host:owner/repo[.git]`
      - SSH URL:   `ssh://git@host[:port]/owner/repo[.git]`
      - HTTPS:     `https://[user@]host/owner/repo[.git][/]`
      - HTTP:      same, downgraded to https
    """
    if not url:
        return None
    url = url.strip()

    # `git@host:owner/repo` (no scheme separator). Convert to https.
    m = re.match(r"^[\w.+-]+@([\w.-]+):([^/].*)$", url)
    if m:
        host, path = m.group(1), m.group(2)
    else:
        # Strip scheme-with-user (ssh://git@…) → host + path
        m = re.match(r"^(?:ssh|git|https?)://(?:[^@/]+@)?([\w.-]+)(?::\d+)?/(.+)$", url)
        if not m:
            return None
        host, path = m.group(1), m.group(2)

    # Drop trailing /, .git, .git/
    path = path.rstrip("/")
    if path.endswith(".git"):
        path = path[:-4]
    if not path or "/" not in path:
        return None

    return f"https://{host}/{path}"
