"""HTTPS RPC client for the cloud MCP Lambda.

Thin transport — sends JSON-RPC requests to the cloud handler and
returns the JSON-RPC responses. Auth is the cached API key in the
X-Archrails-Api-Key header (same shape the cloud handler accepts when
the IDE talks to it directly).

This module owns no validator logic, no rule names, no graph
manipulation. It is pure transport. Failures bubble up so the stdio
server can translate them into MCP-compliant error responses.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

from archrails_mcp.credentials import Credentials


class RpcError(RuntimeError):
    """Raised when the cloud handler returns a non-2xx HTTP status."""

    def __init__(self, status: int, body: str) -> None:
        super().__init__(f"cloud MCP returned HTTP {status}: {body[:500]}")
        self.status = status
        self.body = body


def post(
    creds: Credentials,
    payload: dict[str, Any],
    timeout: float = 30.0,
    mode: str = "code",
    repo_url: str | None = None,
) -> dict[str, Any] | None:
    """POST a JSON-RPC payload to the cloud handler.

    Args:
        creds: Cached credentials (api key + cloud URL).
        payload: JSON-RPC envelope ({jsonrpc, id, method, params}).
        timeout: Request timeout in seconds.
        mode: "code" or "architect". Sent as the `X-Archrails-Mode`
            header so the cloud returns the right per-mode manifest
            (instructions + tool list) on `initialize` / `tools/list`,
            and applies the right tool-availability gate on
            `tools/call`. Defaults to "code".
        repo_url: Workspace repo URL (e.g. `https://github.com/owner/repo`).
            Sent as `X-Archrails-Repo-URL` so the cloud can pick the
            right per-repo graph when the MCP key is tenant-scoped.
            Optional — repo-scoped keys don't need it; tenant-wide
            keys won't get past the cloud's repo-resolution step
            without it.

    Returns the parsed JSON response, or None if the server returned
    204 No Content (notifications don't have responses per JSON-RPC 2.0).

    Raises:
        RpcError: non-2xx HTTP status from the server.
        urllib.error.URLError: network failure.
        json.JSONDecodeError: server returned invalid JSON.
    """
    body_bytes = json.dumps(payload).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "X-Archrails-Api-Key": creds.api_key,
        "X-Archrails-Mode": mode,
    }
    if repo_url:
        headers["X-Archrails-Repo-URL"] = repo_url
    req = urllib.request.Request(
        creds.mcp_url,
        data=body_bytes,
        method="POST",
        headers=headers,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = resp.status
            raw = resp.read()
    except urllib.error.HTTPError as e:
        # 4xx/5xx — read body for the error message and raise.
        try:
            err_body = e.read().decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            err_body = ""
        raise RpcError(e.code, err_body) from None

    if status == 204 or not raw:
        return None
    return json.loads(raw.decode("utf-8"))
