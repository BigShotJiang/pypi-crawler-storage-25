"""archrails.bind_path — add or remove a `mapping:` entry in archrails.yml.

Architect-mode only. The FINOS Claude skill teaches the agent to write
CALM JSON, but it knows nothing about ArchRails' own config file. This
tool is the missing seam: after the agent adds a node to system.calm.json
via Edit/Write, it calls bind_path(node_id, path_glob) to keep
archrails.yml in sync.

Implementation notes:
- We do **not** round-trip the YAML through pyyaml — that would silently
  drop comments and reorder keys, both of which matter in archrails.yml
  (it ships with explanatory comments and a deliberate top-level order).
- Instead we parse with pyyaml only to validate the requested change,
  then perform a text-level insertion / deletion that touches only the
  lines for the affected mapping entry. Comments and ordering elsewhere
  in the file are preserved byte-for-byte.
- Architect mode treats validate_architecture as the post-write gate;
  bind_path itself does NOT call calm validate (it edits archrails.yml,
  not CALM JSON).
"""
from __future__ import annotations

import re
from pathlib import Path

import yaml

from archrails_mcp.graph_loader import LoadedGraph

_MAPPING_BLOCK_RE = re.compile(r"^mapping:[ \t]*\r?\n", re.MULTILINE)
_TOP_LEVEL_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*:\s*$", re.MULTILINE)


def _err(msg: str) -> dict:
    return {"ok": False, "error": msg}


def _read_config(graph: LoadedGraph) -> tuple[str, dict]:
    raw = graph.config_path.read_text(encoding="utf-8")
    parsed = yaml.safe_load(raw) or {}
    if not isinstance(parsed, dict):
        raise ValueError("archrails.yml is not a YAML mapping at top level")
    return raw, parsed


def _node_ids(graph: LoadedGraph) -> set[str]:
    return {n.get("unique-id") for n in graph.nodes if n.get("unique-id")}


def _find_mapping_block(raw: str) -> tuple[int, int] | None:
    """Return (start_offset, end_offset) of the `mapping:` block body.

    `start_offset` points at the first character AFTER the `mapping:`
    line. `end_offset` points at the start of the next top-level key
    (or end-of-file).
    """
    m = _MAPPING_BLOCK_RE.search(raw)
    if not m:
        return None
    body_start = m.end()
    # Find next top-level key. _TOP_LEVEL_KEY_RE matches lines starting
    # in column 0 with `key:`. Skip past the mapping: line itself.
    next_key = None
    for nm in _TOP_LEVEL_KEY_RE.finditer(raw, body_start):
        next_key = nm
        break
    body_end = next_key.start() if next_key else len(raw)
    return body_start, body_end


def _entry_block(path_glob: str, node_id: str) -> str:
    return f"  - path: {path_glob}\n    node: {node_id}\n"


def _entry_already_present(parsed: dict, path_glob: str, node_id: str) -> bool:
    for entry in parsed.get("mapping") or []:
        if (
            isinstance(entry, dict)
            and entry.get("path") == path_glob
            and entry.get("node") == node_id
        ):
            return True
    return False


def _remove_entry_text(raw: str, path_glob: str, node_id: str) -> str | None:
    """Remove the two-line `  - path: …\n    node: …` block. Returns the new
    text, or None if the entry text wasn't found exactly."""
    # Match the exact 2-line entry. We're strict — if indentation or
    # whitespace differs we refuse to mutate so we never corrupt the file.
    pattern = re.compile(
        r"^[ \t]*-[ \t]+path:[ \t]+"
        + re.escape(path_glob)
        + r"[ \t]*\r?\n"
        + r"[ \t]+node:[ \t]+"
        + re.escape(node_id)
        + r"[ \t]*\r?\n",
        re.MULTILINE,
    )
    new_raw, count = pattern.subn("", raw, count=1)
    if count == 0:
        return None
    return new_raw


def run(
    graph: LoadedGraph,
    *,
    action: str,
    node_id: str,
    path_glob: str,
) -> dict:
    if action not in ("add", "remove"):
        return _err(f"action must be 'add' or 'remove', got {action!r}")
    if not node_id or not path_glob:
        return _err("both node_id and path_glob are required")

    try:
        raw, parsed = _read_config(graph)
    except (OSError, ValueError, yaml.YAMLError) as e:
        return _err(f"failed to read archrails.yml: {e}")

    if action == "add":
        # Only allow binding to a node that actually exists in CALM.
        # Catches typos and refuses to bind to a node the architect hasn't
        # declared yet (would silently desync archrails.yml from the graph).
        known_nodes = _node_ids(graph)
        if known_nodes and node_id not in known_nodes:
            return _err(
                f"node_id {node_id!r} is not declared in any CALM source. "
                f"Add it to *.calm.json first, then bind_path. Known nodes: "
                f"{sorted(known_nodes)}"
            )
        if _entry_already_present(parsed, path_glob, node_id):
            return {
                "ok": True,
                "no_change": True,
                "message": f"binding {path_glob} → {node_id} already present",
            }

        block = _find_mapping_block(raw)
        if block is None:
            # No `mapping:` section at all — append one at the end.
            new_raw = raw
            if not new_raw.endswith("\n"):
                new_raw += "\n"
            new_raw += "mapping:\n" + _entry_block(path_glob, node_id)
        else:
            body_start, body_end = block
            insert_at = body_end
            # If there's no trailing newline before the next top-level key
            # (shouldn't happen with valid YAML, but be defensive), add one.
            insertion = _entry_block(path_glob, node_id)
            new_raw = raw[:insert_at] + insertion + raw[insert_at:]

        try:
            yaml.safe_load(new_raw)
        except yaml.YAMLError as e:
            return _err(f"refusing to write — result is not valid YAML: {e}")

        _atomic_write(graph.config_path, new_raw)
        return {
            "ok": True,
            "action": "add",
            "node_id": node_id,
            "path_glob": path_glob,
            "config_file": str(graph.config_path.relative_to(graph.repo_path)),
            "guidance": (
                "Binding written to archrails.yml. The MCP server's loaded "
                "graph is now stale — restart the server (or wait for the "
                "next session) to pick up the new mapping. If you also "
                "edited a *.calm.json, call validate_architecture next."
            ),
        }

    # action == "remove"
    if not _entry_already_present(parsed, path_glob, node_id):
        return {
            "ok": True,
            "no_change": True,
            "message": f"binding {path_glob} → {node_id} was not present",
        }

    new_raw = _remove_entry_text(raw, path_glob, node_id)
    if new_raw is None:
        return _err(
            "couldn't locate the exact 2-line mapping entry to remove "
            "(likely whitespace / formatting differs from the standard "
            "shape `  - path: …\\n    node: …`). Edit archrails.yml by "
            "hand to remove this binding."
        )

    try:
        yaml.safe_load(new_raw)
    except yaml.YAMLError as e:
        return _err(f"refusing to write — result is not valid YAML: {e}")

    _atomic_write(graph.config_path, new_raw)
    return {
        "ok": True,
        "action": "remove",
        "node_id": node_id,
        "path_glob": path_glob,
        "config_file": str(graph.config_path.relative_to(graph.repo_path)),
        "guidance": (
            "Binding removed. Restart the MCP server to refresh the loaded "
            "graph."
        ),
    }


def _atomic_write(path: Path, content: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.replace(path)
