"""Local-only MCP tool implementations.

Only IP-free tools live here:
- `bind_path`: text-level YAML editing of archrails.yml (architect mode)
- `validate_architecture`: shells out to FINOS `calm validate` (architect mode)

Every other tool the local CLI exposes is forwarded to the cloud
server via `archrails_mcp.rpc_client`. The IP-bearing implementations
live server-side in `archrails_mcp_server.tools.*` and never ship in
the CLI wheel.
"""
from archrails_mcp.tools import bind_path, validate_architecture

__all__ = ["bind_path", "validate_architecture"]
