"""archrails.validate_architecture — re-runs `calm validate` over every CALM
source declared in archrails.yml and returns pass/fail per source.

Architect mode's hard gate. The agent is expected to call this after any
write to a CALM JSON file. If status != "ok" for any source, architect
mode tools refuse further mutations until validation is restored — this
is the structural enforcement that keeps schema-broken architecture out
of the repo.

Implementation just delegates to graph_loader._run_calm_validate, which
already shells out to FINOS `calm validate`. We re-read each CALM file
fresh from disk every call (no caching) so the result reflects the
agent's most recent edit, not a stale graph.
"""
from __future__ import annotations

from archrails_mcp.graph_loader import LoadedGraph, _run_calm_validate


def run(graph: LoadedGraph) -> dict:
    results: dict[str, dict] = {}
    overall_ok = True
    for src in graph.config.governance.sources:
        calm_path = graph.repo_path / src.file
        if not calm_path.is_file():
            results[src.id] = {
                "status": "missing",
                "detail": f"file not found: {src.file}",
            }
            overall_ok = False
            continue
        verdict = _run_calm_validate(calm_path)
        results[src.id] = verdict
        if verdict.get("status") not in ("ok", "skipped"):
            overall_ok = False

    return {
        "all_valid": overall_ok,
        "per_source": results,
        "guidance": (
            "Call this immediately after every edit to a *.calm.json file. "
            "If `all_valid` is false, do NOT make further architecture edits "
            "until the failing source validates — fix or revert your most "
            "recent change first."
            if overall_ok
            else "One or more CALM sources failed schema validation. Revert "
            "or fix your most recent edit before continuing. Do not call "
            "bind_path or make further architecture edits until "
            "validate_architecture returns all_valid: true."
        ),
    }
