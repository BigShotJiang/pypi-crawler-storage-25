"""Local graph loader: discovers archrails.yml + CALM files in a repo and
builds a `LoadedGraph` the MCP tools can query.

CALM-native by design:
- archrails.yml parsing → reuses shared.calm parsers
- CALM JSON loading → standard json (we don't reimplement CALM)
- Schema validation → shells out to FINOS `calm validate` if installed.
  We never reimplement CALM schema validation — that's the CLI's job.
- Pattern $refs → surfaced raw to the agent so it can resolve via
  CALM Hub itself (CALM Hub is the canonical pattern registry).

If the `calm` CLI isn't on PATH, schema validation is skipped with a
hint — the loader still works, but the agent loses one layer of
guarantee.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# Local CLI uses an inlined, trimmed config schema (archrails_mcp._config)
# instead of `shared.calm.archrails_config`. Two reasons:
#   1. Ships zero `shared/` files in the CLI wheel — no validators leak.
#   2. Architect-mode tools only touch sources + mapping; the full schema
#      with PR-time-only fields would be dead weight here.
from archrails_mcp._config import (
    MonorepoArchrailsConfig,
    load_archrails_config,
)


@dataclass(frozen=True)
class LoadedGraph:
    repo_path: Path
    config: MonorepoArchrailsConfig
    config_path: Path
    calm_documents: dict[str, dict]
    nodes: list[dict] = field(default_factory=list)
    relationships: list[dict] = field(default_factory=list)
    # Per-source schema validation result from `calm validate`.
    # Shape: { source_id: {"status": "ok"|"failed"|"skipped", "detail": str} }
    calm_validation: dict[str, dict] = field(default_factory=dict)


_CONFIG_CANDIDATES = (
    "archrails.yml",
    "archrails.yaml",
    ".archrails/config.yml",
    ".archrails/config.yaml",
)


def _find_config(repo_path: Path) -> Path:
    for rel in _CONFIG_CANDIDATES:
        p = repo_path / rel
        if p.is_file():
            return p
    raise FileNotFoundError(
        f"No archrails.yml found under {repo_path} (tried: {', '.join(_CONFIG_CANDIDATES)})"
    )


def _flatten_calm(doc: dict) -> tuple[list[dict], list[dict]]:
    nodes = doc.get("nodes") or []
    rels = doc.get("relationships") or []
    return list(nodes), list(rels)


def _calm_cli_available() -> bool:
    return shutil.which("calm") is not None


def _run_calm_validate(calm_path: Path) -> dict:
    """Shell out to the FINOS CALM CLI to schema-validate a CALM JSON file.

    We never reimplement the schema check — `calm validate` is the
    canonical validator. If the CLI isn't installed, return status
    "skipped" so the agent can be told.
    """
    if not _calm_cli_available():
        return {
            "status": "skipped",
            "detail": (
                "FINOS `calm` CLI not found on PATH. Install it "
                "(npm i -g @finos/calm-cli) for schema validation."
            ),
        }
    try:
        result = subprocess.run(
            ["calm", "validate", "--architecture", str(calm_path)],
            capture_output=True,
            text=True,
            timeout=15,
        )
    except subprocess.TimeoutExpired:
        return {"status": "failed", "detail": "calm validate timed out after 15s"}
    except FileNotFoundError:
        return {"status": "skipped", "detail": "calm CLI disappeared between check and exec"}

    if result.returncode == 0:
        return {"status": "ok", "detail": result.stdout.strip() or "valid"}
    return {
        "status": "failed",
        "detail": (result.stderr or result.stdout).strip()[:2000],
    }


def load_graph(repo_path: Path) -> LoadedGraph:
    """Find and load archrails.yml + referenced CALM files in `repo_path`.

    Each CALM source is also schema-checked via `calm validate` (FINOS
    CLI) when available; results are recorded in `calm_validation`.
    """
    config_path = _find_config(repo_path)
    raw_yaml = config_path.read_text(encoding="utf-8")
    config = load_archrails_config(raw_yaml)

    calm_documents: dict[str, dict] = {}
    all_nodes: list[dict] = []
    all_rels: list[dict] = []
    validation: dict[str, dict] = {}

    for src in config.governance.sources:
        calm_path = repo_path / src.file
        if not calm_path.is_file():
            print(
                f"[archrails-mcp] WARNING: CALM source not found: {calm_path}",
                file=sys.stderr,
            )
            validation[src.id] = {
                "status": "missing",
                "detail": f"file not found: {calm_path}",
            }
            continue

        # Delegate schema validation to FINOS CALM CLI.
        validation[src.id] = _run_calm_validate(calm_path)

        try:
            doc = json.loads(calm_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            print(
                f"[archrails-mcp] WARNING: CALM source {calm_path} not valid JSON: {e}",
                file=sys.stderr,
            )
            continue

        calm_documents[src.id] = doc
        nodes, rels = _flatten_calm(doc)
        all_nodes.extend(nodes)
        all_rels.extend(rels)

    return LoadedGraph(
        repo_path=repo_path,
        config=config,
        config_path=config_path,
        calm_documents=calm_documents,
        nodes=all_nodes,
        relationships=all_rels,
        calm_validation=validation,
    )
