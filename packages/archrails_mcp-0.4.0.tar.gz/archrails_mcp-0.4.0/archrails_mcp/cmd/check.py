"""archrails check — run the cloud validator suite against your local diff.

Direct CLI verb for "I just wrote some code, would the merge gate accept
it?". No agent / IDE required. Reads `git diff` from the workspace and
ships it to the same `check_local_diff` cloud endpoint that the IDE
agent uses, then pretty-prints the verdicts.

Same brain as PR-time: a clean response here means the merge gate would
also pass; a blocked verdict here means the merge will block.

Exit codes:
    0 = clean (no violations, OR --json with allowed=true)
    1 = violations present (would block merge if --json or stderr report)
    2 = invocation error (no creds, not a git repo, bad args)
    3 = cloud MCP unreachable / returned malformed response
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from archrails_mcp import credentials, diff_reader, rpc_client


_RPC_ID = 0


def _next_id() -> int:
    global _RPC_ID
    _RPC_ID += 1
    return _RPC_ID


def cmd_check(args) -> int:
    creds = credentials.load()
    if creds is None:
        print(
            "No ArchRails credentials cached. Run `archrails login` first.",
            file=sys.stderr,
        )
        return 2

    repo_path = Path(args.repo).resolve()
    if not repo_path.is_dir():
        print(f"--repo not a directory: {repo_path}", file=sys.stderr)
        return 2

    scope_paths = args.paths or None
    try:
        unified_diff = diff_reader.read_workspace_diff(
            repo_path,
            scope_paths=scope_paths,
            against=args.against,
        )
    except diff_reader.DiffReadError as e:
        print(f"Failed to read git diff: {e}", file=sys.stderr)
        return 2

    if not unified_diff.strip():
        if args.json:
            print(json.dumps({
                "allowed": True,
                "verdicts": [],
                "note": f"No changes against {args.against}.",
            }))
        else:
            print(f"No changes against {args.against}.", file=sys.stderr)
        return 0

    arguments: dict = {"unified_diff": unified_diff}
    if scope_paths:
        arguments["scope_paths"] = scope_paths

    payload = {
        "jsonrpc": "2.0",
        "id": _next_id(),
        "method": "tools/call",
        "params": {"name": "check_local_diff", "arguments": arguments},
    }

    try:
        resp = rpc_client.post(creds, payload)
    except rpc_client.RpcError as e:
        print(
            f"Cloud MCP returned HTTP {e.status}: {e.body[:300]}",
            file=sys.stderr,
        )
        return 3
    except Exception as e:  # noqa: BLE001
        print(
            f"Failed to reach cloud MCP: {type(e).__name__}: {e}",
            file=sys.stderr,
        )
        return 3

    body = _extract_tool_result(resp)
    if body is None:
        return 3

    if args.json:
        print(json.dumps(body, indent=2))
        return 0 if body.get("allowed") else 1

    return _print_human(body, against=args.against)


def _extract_tool_result(resp) -> dict | None:
    """Pull the tool result dict out of the JSON-RPC envelope.
    Prints diagnostics on stderr and returns None on any unexpected shape.
    """
    if not isinstance(resp, dict):
        print("Cloud MCP returned no body", file=sys.stderr)
        return None
    if "error" in resp:
        err = resp.get("error") or {}
        print(
            f"Cloud MCP error: {err.get('message', 'unknown')}",
            file=sys.stderr,
        )
        return None

    result = resp.get("result") or {}
    contents = result.get("content") or []
    text = (
        contents[0].get("text")
        if contents and isinstance(contents[0], dict)
        else None
    )
    if not isinstance(text, str):
        print("Cloud MCP returned no text content", file=sys.stderr)
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        print("Cloud MCP returned invalid JSON", file=sys.stderr)
        return None


def _print_human(body: dict, against: str) -> int:
    """Pretty-print verdicts. Returns 0 if clean, 1 if any violation present."""
    verdicts = body.get("verdicts") or []
    changed_paths = body.get("changed_paths") or []
    source_nodes = body.get("source_nodes") or []
    note = body.get("note")

    files_label = (
        f"{len(changed_paths)} file" if len(changed_paths) == 1
        else f"{len(changed_paths)} files"
    )
    nodes_label = (
        ", ".join(source_nodes) if source_nodes
        else "(no source nodes matched)"
    )
    print(f"ArchRails check (vs {against}) — {files_label}, source nodes: {nodes_label}")
    if note:
        print(f"Note: {note}")
    print()

    if not verdicts:
        print("✓ All clear. Would pass the merge gate.")
        return 0

    # Group verdicts by file for a tidier report.
    by_file: dict[str, list[dict]] = {}
    for v in verdicts:
        f = (v.get("evidence") or {}).get("file") or "(unspecified)"
        by_file.setdefault(f, []).append(v)

    for f in sorted(by_file.keys()):
        for v in by_file[f]:
            sev = v.get("severity") or "medium"
            rule = v.get("rule") or "AR-?"
            reason = v.get("reason") or ""
            evidence = v.get("evidence") or {}
            line_range = evidence.get("line_range")
            line_label = (
                f":{line_range[0]}" if line_range and line_range[0]
                else ""
            )
            print(f"✗ {rule}  [{sev}]")
            if reason:
                print(f"  {reason}")
            print(f"  {f}{line_label}")
            allowed = v.get("allowed_targets") or []
            if allowed:
                print(f"  CALM-allowed targets: {', '.join(allowed)}")
            print()

    blocked = body.get("would_block_pr")
    high = sum(
        1 for v in verdicts if (v.get("severity") or "").lower() == "high"
    )
    summary = (
        f"{len(verdicts)} violation"
        + ("" if len(verdicts) == 1 else "s")
        + f" ({high} high)"
    )
    if blocked:
        print(f"BLOCKED — would fail the merge gate. {summary}.")
    else:
        print(f"Findings present, would not block merge. {summary}.")
    return 1
