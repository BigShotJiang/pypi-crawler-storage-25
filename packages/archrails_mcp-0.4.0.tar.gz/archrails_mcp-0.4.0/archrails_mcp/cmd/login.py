"""`archrails login` / `archrails logout` — interactive auth.

Two flows:

- **Browser callback (default).** CLI starts a local HTTP listener on a
  random port, opens the dashboard's "Authorize CLI" page with the
  callback URL + a state nonce, and waits for the dashboard to POST the
  freshly-minted key back. Zero typing for the user beyond clicking
  "Authorize" in their browser.

- **Manual paste (`--paste` / fallback).** CLI opens the dashboard's
  API Keys page; user mints a key, copies it, pastes back into the CLI
  prompt. Used when the callback flow isn't viable (headless SSH, CORS
  blocked, dashboard URL not a recognized origin).

The browser flow falls back to paste automatically if it can't open a
browser, can't bind a port, or times out.
"""
from __future__ import annotations

import getpass
import json
import secrets
import socket
import sys
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlencode, urljoin

from archrails_mcp import credentials


_VALID_PREFIXES = ("ar_live_", "ar_dev_")
_CALLBACK_TIMEOUT_S = 300  # 5 minutes


# ── Manual paste flow (always available as a fallback) ──────────────────────

def _paste_flow(args, dashboard: str, *, msg: str | None = None) -> int:
    keys_page = urljoin(dashboard.rstrip("/") + "/", "dashboard/api-keys/")

    print()
    print("ArchRails sign-in (manual paste)")
    print("─────────────────────────────────")
    if msg:
        print(msg)
        print()
    print(f"Opening {keys_page} in your browser…")
    print()
    print("Steps:")
    print("  1. Sign in with your ArchRails credentials")
    print("  2. Click 'Generate key'")
    print("  3. Copy the key value (shown ONCE)")
    print("  4. Paste it back here when prompted")
    print()

    try:
        webbrowser.open(keys_page)
    except webbrowser.Error:
        print(f"Could not open browser. Please visit:\n  {keys_page}\n", file=sys.stderr)

    try:
        key = getpass.getpass("Paste API key (input hidden): ").strip()
    except (KeyboardInterrupt, EOFError):
        print("\nCancelled.", file=sys.stderr)
        return 130

    if not key:
        print("No key provided.", file=sys.stderr)
        return 2
    if not key.startswith(_VALID_PREFIXES):
        print(
            f"That doesn't look like an ArchRails key (must start with one of "
            f"{', '.join(_VALID_PREFIXES)}).",
            file=sys.stderr,
        )
        return 2

    return _save_and_report(args, dashboard, key=key, key_id="", tenant_pk="", username="")


def _save_and_report(
    args,
    dashboard: str,
    *,
    key: str,
    key_id: str,
    tenant_pk: str,
    username: str,
) -> int:
    creds = credentials.Credentials(
        api_key=key,
        api_base=args.api_base or credentials.DEFAULT_API_BASE,
        mcp_url=args.mcp_url or credentials.DEFAULT_MCP_URL,
        dashboard=dashboard,
        key_id=key_id,
        tenant_pk=tenant_pk,
        username=username,
    )
    path = credentials.save(creds)

    print()
    print(f"✓ Credentials cached at {path} (mode 0600)")
    if username:
        print(f"  signed in as: {username}")
    if tenant_pk:
        print(f"  tenant_pk:    {tenant_pk}")
    print(f"  cloud MCP:    {creds.mcp_url}")
    print()
    print("Note: the key is associated with your Cognito user. Sharing it")
    print("attributes activity to you — the dashboard surfaces unfamiliar usage.")
    return 0


# ── Browser callback flow ───────────────────────────────────────────────────

class _CallbackResult:
    """Mutable shared state between the HTTP handler thread and main."""
    key: str | None = None
    key_id: str = ""
    tenant_pk: str = ""
    username: str = ""
    error: str | None = None
    state_expected: str = ""
    done = threading.Event()


def _make_handler(result: _CallbackResult):

    class _Handler(BaseHTTPRequestHandler):
        # Suppress default request logging — it noises the user's terminal.
        def log_message(self, fmt, *args):
            return

        def _cors(self):
            # Loopback listener; allow any dashboard origin to POST. The
            # state token is the actual auth check.
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "content-type")
            self.send_header("Access-Control-Max-Age", "60")

        def do_OPTIONS(self):  # noqa: N802 — stdlib API
            self.send_response(204)
            self._cors()
            self.end_headers()

        def do_POST(self):  # noqa: N802
            if self.path.rstrip("/") != "/auth-callback":
                self.send_response(404)
                self._cors()
                self.end_headers()
                return

            length = int(self.headers.get("content-length") or 0)
            try:
                body = self.rfile.read(length).decode("utf-8")
                data = json.loads(body)
            except (UnicodeDecodeError, json.JSONDecodeError):
                self.send_response(400)
                self._cors()
                self.end_headers()
                self.wfile.write(b'{"error":"invalid json"}')
                return

            state = (data.get("state") or "").strip()
            key = (data.get("api_key") or data.get("key") or "").strip()

            if state != result.state_expected:
                result.error = "state_mismatch"
                self.send_response(403)
                self._cors()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error":"state mismatch"}')
                result.done.set()
                return

            if not key.startswith(_VALID_PREFIXES):
                result.error = "bad_key_format"
                self.send_response(400)
                self._cors()
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error":"bad key format"}')
                result.done.set()
                return

            result.key = key
            result.key_id = (data.get("key_id") or "").strip()
            result.tenant_pk = (data.get("tenant_pk") or "").strip()
            result.username = (data.get("username") or "").strip()

            self.send_response(200)
            self._cors()
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok":true}')
            result.done.set()

    return _Handler


def _free_localhost_port() -> int | None:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
        s.close()
        return port
    except OSError:
        return None


def _browser_flow(args, dashboard: str) -> int:
    port = _free_localhost_port()
    if port is None:
        return _paste_flow(args, dashboard, msg="(could not bind a localhost port — using manual paste)")

    state = secrets.token_urlsafe(24)
    callback_url = f"http://127.0.0.1:{port}/auth-callback"
    authorize_url = (
        urljoin(dashboard.rstrip("/") + "/", "dashboard/authorize-cli/")
        + "?"
        + urlencode({"callback": callback_url, "state": state})
    )

    result = _CallbackResult()
    result.state_expected = state

    server = HTTPServer(("127.0.0.1", port), _make_handler(result))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    print()
    print("ArchRails sign-in")
    print("─────────────────")
    print(f"Opening {authorize_url} in your browser…")
    print(f"Waiting up to {_CALLBACK_TIMEOUT_S}s for authorization (Ctrl-C to cancel,")
    print("or fall back to manual paste with `archrails login --paste`).")

    try:
        webbrowser.open(authorize_url)
    except webbrowser.Error:
        print(f"\nCould not open browser. Please visit:\n  {authorize_url}\n", file=sys.stderr)

    deadline = time.time() + _CALLBACK_TIMEOUT_S
    try:
        while not result.done.is_set():
            if time.time() >= deadline:
                break
            result.done.wait(timeout=1.0)
    except KeyboardInterrupt:
        print("\nCancelled.", file=sys.stderr)
        server.shutdown()
        return 130

    server.shutdown()

    if result.error:
        print(f"\nAuthorization failed: {result.error}", file=sys.stderr)
        return 2

    if not result.key:
        print("\nTimed out waiting for authorization.", file=sys.stderr)
        print("Falling back to manual paste flow:", file=sys.stderr)
        return _paste_flow(args, dashboard)

    return _save_and_report(
        args,
        dashboard,
        key=result.key,
        key_id=result.key_id,
        tenant_pk=result.tenant_pk,
        username=result.username,
    )


# ── Dispatch ─────────────────────────────────────────────────────────────────

def cmd_login(args) -> int:
    dashboard = args.dashboard or credentials.DEFAULT_DASHBOARD
    if getattr(args, "paste", False):
        return _paste_flow(args, dashboard)
    return _browser_flow(args, dashboard)


def cmd_logout(args) -> int:
    if credentials.clear():
        print(f"✓ Removed {credentials.CREDENTIALS_PATH}")
        return 0
    print(f"No credentials at {credentials.CREDENTIALS_PATH} (already signed out).")
    return 0


def cmd_logout(args) -> int:
    if credentials.clear():
        print(f"✓ Removed {credentials.CREDENTIALS_PATH}")
        return 0
    print(f"No credentials at {credentials.CREDENTIALS_PATH} (already signed out).")
    return 0
