"""`archrails bootstrap` — one-time setup for a newly-provisioned developer.

What it does, in order:

1. Verifies Node.js + npm are present (errors with platform-specific
   install hints if not — Node auto-download lands in Phase 3c).
2. Installs the pinned FINOS CALM CLI into ~/.archrails/calm/.
3. Smoke-tests `archrails calm --version` works.
4. Walks the user through `archrails login` (browser to dashboard,
   paste API key, save credentials).
5. Wires `archrails-local` into the user's IDE MCP config (Claude Code's
   `~/.claude.json` for now; Cursor / Windsurf instructions printed).
6. Prints next-steps.

Idempotent — running again on an already-bootstrapped machine re-checks
each step and only runs what's missing.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
from pathlib import Path

from archrails_mcp import credentials
from archrails_mcp.cmd import calm as calm_cmd
from archrails_mcp.cmd.login import cmd_login


CLAUDE_CONFIG_PATH = Path.home() / ".claude.json"


def _step(label: str) -> None:
    print(f"\n→ {label}")


def _ok(label: str) -> None:
    print(f"  ✓ {label}")


def _warn(label: str) -> None:
    print(f"  ! {label}", file=sys.stderr)


def _check_node() -> bool:
    """Return True if both `node` and `npm` are on PATH."""
    return bool(shutil.which("node") and shutil.which("npm"))


def _ensure_calm_cli() -> bool:
    """Install pinned CALM CLI if not already present."""
    binary = calm_cmd.find_calm_binary()
    if binary:
        _ok(f"FINOS CALM CLI already at {binary}")
        return True

    if not _check_node():
        _warn(
            "Node.js / npm not found.\n"
            + "  " + calm_cmd._platform_node_install_hint().replace("\n", "\n  ")
        )
        return False

    try:
        path = calm_cmd.install_calm_cli(quiet=False)
        _ok(f"FINOS CALM CLI installed at {path}")
        return True
    except calm_cmd.InstallError as e:
        _warn(f"CALM CLI install failed: {e}")
        return False


def _wire_claude_code(mcp_url: str | None, api_key: str | None) -> None:
    """Add archrails-local (and optionally archrails-cloud) to ~/.claude.json.

    We update in-place if the file exists; create it if not. Idempotent.
    """
    config: dict
    if CLAUDE_CONFIG_PATH.is_file():
        try:
            config = json.loads(CLAUDE_CONFIG_PATH.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            _warn(f"{CLAUDE_CONFIG_PATH} is not valid JSON — skipping Claude Code wiring.")
            return
    else:
        config = {}

    servers = config.setdefault("mcpServers", {})

    # Local mode — points at the user's current working directory.
    servers["archrails-local"] = {
        "command": "archrails",
        "args": ["mcp", "start", "--repo", "."],
    }

    # Cloud mode — only if we have credentials.
    if mcp_url and api_key:
        servers["archrails-cloud"] = {
            "url": mcp_url,
            "headers": {"X-Archrails-Api-Key": api_key},
        }

    CLAUDE_CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")
    _ok(f"Claude Code MCP config updated at {CLAUDE_CONFIG_PATH}")


def _print_other_ide_hints() -> None:
    print(
        "\n  Other IDEs:\n"
        "    Cursor:    add archrails-local to ~/.cursor/mcp.json\n"
        "    Windsurf:  add archrails-local to ~/.codeium/windsurf/mcp_config.json\n"
        "    See ArchrailsCustomerOnboarding.md Appendix B for snippets.",
        file=sys.stderr,
    )


def _smoke(creds: credentials.Credentials | None) -> None:
    """Run a few non-destructive checks and print results."""
    print()
    _step("Smoke checks")
    _ok(f"archrails CLI: {shutil.which('archrails')}")
    binary = calm_cmd.find_calm_binary()
    _ok(f"FINOS CALM CLI: {binary or '(not installed)'}")
    if creds:
        _ok(f"credentials at {credentials.CREDENTIALS_PATH}")
    else:
        _warn("no credentials cached — cloud MCP unavailable until `archrails login`")


def cmd_bootstrap(args) -> int:
    print("ArchRails bootstrap — one-time setup for a provisioned developer.\n")
    print("This will install the FINOS CALM CLI, walk you through sign-in,")
    print("and wire your IDE's MCP config to point at ArchRails.\n")

    # ── 1. Node check ────────────────────────────────────────────────────────
    _step("Checking Node.js / npm")
    if _check_node():
        _ok(f"node: {shutil.which('node')}")
        _ok(f"npm:  {shutil.which('npm')}")
    else:
        _warn("Node.js (with npm) is required for the FINOS CALM CLI.")
        print(
            "  Install Node.js 18+ from https://nodejs.org/ or via:\n"
            "    macOS:   brew install node\n"
            "    Linux:   apt install nodejs npm  /  dnf install nodejs npm\n"
            "    Windows: winget install OpenJS.NodeJS\n"
            "  Then re-run: archrails bootstrap"
        )
        # Continue anyway so the user can still set up MCP without CALM auth.
        if not args.no_calm_required:
            return 1

    # ── 2. CALM CLI ───────────────────────────────────────────────────────────
    _step("Installing FINOS CALM CLI")
    _ensure_calm_cli()

    # ── 3. Sign in ────────────────────────────────────────────────────────────
    creds = credentials.load()
    if creds and not args.force:
        _step("Sign in")
        _ok(f"already signed in as {creds.username or '(no username on file)'}")
        print(f"  re-run with --force to replace credentials")
    elif args.skip_login:
        _step("Sign in")
        _warn("--skip-login passed; cloud MCP credentials will not be cached")
    else:
        _step("Sign in (browser will open)")
        rc = cmd_login(args)
        if rc != 0:
            print("\nSign-in failed or was cancelled. Re-run `archrails login` later.", file=sys.stderr)
            # Don't abort the rest of bootstrap — local MCP still works.
        else:
            creds = credentials.load()

    # ── 4. IDE wiring ─────────────────────────────────────────────────────────
    _step("Wiring IDE MCP config")
    _wire_claude_code(
        mcp_url=(creds.mcp_url if creds else None),
        api_key=(creds.api_key if creds else None),
    )
    _print_other_ide_hints()

    # ── 5. Smoke ──────────────────────────────────────────────────────────────
    _smoke(creds)

    # ── 6. What next ──────────────────────────────────────────────────────────
    print()
    print("Setup complete. Try:")
    print("  archrails mcp start --repo .            # start the local MCP server")
    print("  archrails calm validate <path>          # schema-check a CALM file")
    print("  archrails calm --help                   # see all CALM subcommands")
    if creds:
        print("  Your IDE's cloud MCP entry is wired — restart the IDE to pick it up.")
    print()
    print("Questions? hello@archrails.io")
    return 0
