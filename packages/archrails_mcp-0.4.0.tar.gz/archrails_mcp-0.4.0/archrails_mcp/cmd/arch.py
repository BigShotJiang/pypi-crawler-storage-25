"""`archrails arch init` — drop the FINOS CALM Claude skill into a repo.

Thin wrapper around `calm init-ai --provider claude`. Lives here (not in
`cmd/calm.py`) because we want a first-class verb users can discover —
`archrails arch init` reads as "set up architecture authoring," whereas
`archrails calm init-ai --provider claude` reads as plumbing.

Why this command exists at all (rather than just documenting the calm
incantation):

- It pins `claude` as the provider — users in this product context
  always want the Claude skill, not Copilot/Kiro variants.
- It fronts the FINOS CALM CLI install check, so a fresh dev gets a
  single error path: missing CALM CLI → run `archrails calm install`.
- It's the natural pair to `archrails mcp start --mode architect` —
  one command for the skill, one for the server.
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from archrails_mcp.cmd.calm import find_calm_binary


def cmd_arch_init(args: argparse.Namespace) -> int:
    binary = find_calm_binary()
    if not binary:
        print(
            "FINOS CALM CLI not installed. Run:\n"
            "    archrails calm install\n"
            "(or `archrails bootstrap` to do it as part of first-time setup)",
            file=sys.stderr,
        )
        return 2

    target = Path(args.directory).resolve()
    if not target.is_dir():
        print(f"[archrails arch init] target not a directory: {target}", file=sys.stderr)
        return 2

    cmd = [binary, "init-ai", "--provider", "claude", "--directory", str(target)]
    print(
        f"Running: calm init-ai --provider claude --directory {target}",
        file=sys.stderr,
    )
    proc = subprocess.run(cmd)
    if proc.returncode != 0:
        return proc.returncode

    skill_path = target / ".claude" / "skills" / "calm" / "SKILL.md"
    if skill_path.is_file():
        print(
            f"\n✓ FINOS CALM Claude skill installed at {skill_path.relative_to(target)}\n"
            f"\nNext steps:\n"
            f"  1. Start the MCP server in architect mode:\n"
            f"       archrails mcp start --repo {target} --mode architect\n"
            f"  2. In Claude Code / Cursor, the `/calm` skill is now available\n"
            f"     for CALM authoring guidance.\n",
            file=sys.stderr,
        )
    return 0
