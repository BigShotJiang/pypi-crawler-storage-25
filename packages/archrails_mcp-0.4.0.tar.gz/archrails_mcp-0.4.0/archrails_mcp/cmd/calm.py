"""`archrails calm <subcommand>` — wraps the FINOS CALM CLI.

Customers should never type `npm` or `npx`. They run `archrails calm
validate path/to/topology.calm.json` and the wrapper finds the right
binary, falling back to `archrails calm install` if it isn't present.

Why we wrap rather than expecting CALM CLI on PATH:
- We pin a CALM CLI version we've tested. Customers don't pick.
- Future migrations (FINOS rename / breaking changes) get absorbed here.
- We can attach tenant-specific defaults (CALM Hub auth, schema mirrors)
  without changing customer commands.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

# Pin the CALM CLI version. Bump this when we've tested a new one;
# customers running `archrails calm install` always get this version.
CALM_CLI_VERSION = os.environ.get("ARCHRAILS_CALM_CLI_VERSION", "latest")

ARCHRAILS_HOME = Path(os.environ.get("ARCHRAILS_HOME") or (Path.home() / ".archrails"))
CALM_INSTALL_DIR = ARCHRAILS_HOME / "calm"
CALM_LOCAL_BIN = CALM_INSTALL_DIR / "node_modules" / ".bin" / "calm"


# ── Locate ────────────────────────────────────────────────────────────────────

def find_calm_binary() -> str | None:
    """Return path to a `calm` binary, or None if not installed.

    Lookup order:
    1. archrails-managed install at ~/.archrails/calm/  (preferred — pinned)
    2. system-wide `calm` on PATH
    """
    if CALM_LOCAL_BIN.is_file():
        return str(CALM_LOCAL_BIN)
    system = shutil.which("calm")
    return system if system else None


# ── Install ───────────────────────────────────────────────────────────────────

class InstallError(RuntimeError):
    pass


def _platform_node_install_hint() -> str:
    return (
        "Install Node.js 18+ from https://nodejs.org/ or via your package manager:\n"
        "  macOS:    brew install node\n"
        "  Linux:    apt install nodejs npm   (Debian/Ubuntu)\n"
        "            dnf install nodejs npm   (Fedora/RHEL)\n"
        "  Windows:  winget install OpenJS.NodeJS\n"
        "\n"
        "After Node is installed, re-run: archrails calm install"
    )


def _resolve_npm(*, allow_auto_install: bool = True, quiet: bool = False) -> str:
    """Find an npm binary. If neither system nor archrails-managed Node
    is present, auto-download a portable Node.js (cross-platform,
    SHA-256-verified) into ~/.archrails/node/ and use that one.

    `allow_auto_install=False` skips the auto-download attempt — used
    when the caller wants to fail fast with a manual-install hint.
    """
    npm = shutil.which("npm")
    if npm:
        return npm

    # Maybe we already auto-installed Node on a prior run.
    from archrails_mcp.cmd import node_install

    bin_dir = node_install.archrails_managed_node_bin()
    if bin_dir:
        candidate = bin_dir / ("npm.cmd" if os.name == "nt" else "npm")
        if candidate.exists():
            return str(candidate)

    if not allow_auto_install:
        raise InstallError(
            "Node.js (npm) is required to install the FINOS CALM CLI.\n\n"
            + _platform_node_install_hint()
        )

    # Auto-download.
    try:
        bin_dir = node_install.install_node(quiet=quiet)
    except node_install.UnsupportedPlatform as e:
        raise InstallError(str(e))
    except Exception as e:  # noqa: BLE001
        raise InstallError(
            f"Auto-installing Node.js failed: {e}\n\n"
            + _platform_node_install_hint()
        )

    candidate = bin_dir / ("npm.cmd" if os.name == "nt" else "npm")
    if not candidate.exists():
        raise InstallError(
            f"Auto-installed Node, but npm not found at {candidate}.\n\n"
            + _platform_node_install_hint()
        )
    return str(candidate)


def install_calm_cli(version: str = CALM_CLI_VERSION, *, quiet: bool = False) -> Path:
    """Install @finos/calm-cli into ~/.archrails/calm via npm.

    If npm isn't on PATH, auto-downloads a portable Node.js (pinned LTS,
    SHA-256-verified) into ~/.archrails/node/ and uses its bundled npm.
    Returns the path to the installed `calm` binary. Raises InstallError
    on any failure.
    """
    npm = _resolve_npm(quiet=quiet)

    CALM_INSTALL_DIR.mkdir(parents=True, exist_ok=True)

    if not quiet:
        print(f"Installing @finos/calm-cli@{version} into {CALM_INSTALL_DIR}…", file=sys.stderr)

    cmd = [
        npm, "install",
        "--prefix", str(CALM_INSTALL_DIR),
        "--no-audit", "--no-fund", "--silent",
        f"@finos/calm-cli@{version}",
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise InstallError(
            f"npm install failed (exit {proc.returncode}):\n"
            f"{proc.stderr.strip() or proc.stdout.strip()}"
        )

    if not CALM_LOCAL_BIN.is_file():
        raise InstallError(
            f"npm install reported success but {CALM_LOCAL_BIN} is missing.\n"
            "Try: archrails calm install --version <pinned-version>"
        )

    # Sanity: verify the binary can run.
    verify = subprocess.run([str(CALM_LOCAL_BIN), "--version"], capture_output=True, text=True)
    if verify.returncode != 0:
        raise InstallError(
            f"Installed binary at {CALM_LOCAL_BIN} failed to report a version "
            f"(exit {verify.returncode}). Output:\n{verify.stderr.strip() or verify.stdout.strip()}"
        )

    if not quiet:
        ver = (verify.stdout.strip() or verify.stderr.strip()).splitlines()[0]
        print(f"✓ FINOS CALM CLI installed ({ver})", file=sys.stderr)

    return CALM_LOCAL_BIN


# ── Dispatch ──────────────────────────────────────────────────────────────────

def cmd_calm(argv: list[str]) -> int:
    """Implements `archrails calm <subcommand> ...args`.

    Special subcommand `install` triggers our installer; everything else
    is passed through to the FINOS CALM CLI.
    """
    if not argv:
        print(
            "Usage: archrails calm <subcommand> [args]\n"
            "       archrails calm install        # install FINOS CALM CLI\n"
            "       archrails calm validate <p>   # schema-validate a CALM file\n"
            "       archrails calm template <p>   # extend a template\n"
            "       archrails calm generate <p>   # instantiate from a pattern\n"
            "       archrails calm visualize <p>  # render a graph diagram\n"
            "       archrails calm --help         # show CALM CLI's own help",
            file=sys.stderr,
        )
        return 2

    if argv[0] == "install":
        try:
            install_calm_cli()
            return 0
        except InstallError as e:
            print(f"[archrails calm install] {e}", file=sys.stderr)
            return 1

    binary = find_calm_binary()
    if not binary:
        print(
            "FINOS CALM CLI not installed. Run:\n"
            "    archrails calm install\n"
            "(or `archrails bootstrap` to do it as part of first-time setup)",
            file=sys.stderr,
        )
        return 2

    # Pass-through. Inherits stdin/stdout/stderr so streaming output (e.g.
    # `calm visualize`) flows naturally to the user's terminal.
    proc = subprocess.run([binary] + argv)
    return proc.returncode
