"""Auto-download a portable Node.js into ~/.archrails/node/.

Used by `archrails calm install` when Node isn't on PATH. Downloads the
official Node.js distribution from nodejs.org, verifies its SHA-256
against the published SHASUMS256.txt, and extracts it locally. No
admin rights required, no package manager needed.

Cross-platform:
- macOS / Linux: tar.xz archive, extracted via stdlib `tarfile`
- Windows:        zip archive, extracted via stdlib `zipfile`

Architecture detection covers darwin-arm64, darwin-x64, linux-arm64,
linux-x64, win-x64. Other targets (musl, freebsd, etc.) fall through to
"please install Node manually" with a helpful pointer.
"""
from __future__ import annotations

import hashlib
import os
import platform
import shutil
import sys
import tarfile
import urllib.request
import zipfile
from pathlib import Path
from typing import NamedTuple

# Pinned LTS. Bump deliberately when we've tested a newer one. Customers
# get the same Node version regardless of what's on their machine.
NODE_VERSION = os.environ.get("ARCHRAILS_NODE_VERSION", "22.11.0")

ARCHRAILS_HOME = Path(os.environ.get("ARCHRAILS_HOME") or (Path.home() / ".archrails"))
NODE_INSTALL_DIR = ARCHRAILS_HOME / "node" / f"v{NODE_VERSION}"


class NodeTarget(NamedTuple):
    platform_segment: str  # e.g. "darwin-arm64"
    archive_ext: str       # "tar.xz" or "zip"
    bin_subdir: str        # "bin" on POSIX, "" on Windows


class UnsupportedPlatform(RuntimeError):
    pass


def _detect_target() -> NodeTarget:
    system = platform.system()
    machine = platform.machine().lower()

    if system == "Darwin":
        if machine in ("arm64", "aarch64"):
            return NodeTarget("darwin-arm64", "tar.xz", "bin")
        if machine in ("x86_64", "amd64"):
            return NodeTarget("darwin-x64", "tar.xz", "bin")
    elif system == "Linux":
        # Note: nodejs.org distros are glibc-based. musl users (Alpine)
        # need the unofficial-builds tarball — we don't auto-detect here,
        # they hit the UnsupportedPlatform fallback.
        if machine in ("aarch64", "arm64"):
            return NodeTarget("linux-arm64", "tar.xz", "bin")
        if machine in ("x86_64", "amd64"):
            return NodeTarget("linux-x64", "tar.xz", "bin")
    elif system == "Windows":
        if machine in ("amd64", "x86_64"):
            return NodeTarget("win-x64", "zip", "")

    raise UnsupportedPlatform(
        f"Auto-download Node.js does not support {system}/{machine}.\n"
        "Install Node 18+ manually from https://nodejs.org/, then re-run "
        "`archrails calm install`."
    )


def node_archive_url(target: NodeTarget) -> str:
    return (
        f"https://nodejs.org/dist/v{NODE_VERSION}/"
        f"node-v{NODE_VERSION}-{target.platform_segment}.{target.archive_ext}"
    )


def shasums_url() -> str:
    return f"https://nodejs.org/dist/v{NODE_VERSION}/SHASUMS256.txt"


def archrails_managed_node_bin() -> Path | None:
    """Return path to the bin dir of an archrails-managed Node, if installed."""
    if not NODE_INSTALL_DIR.is_dir():
        return None
    # We extract the entire `node-v<VERSION>-<platform>` directory; the
    # binaries live under that root's bin/ on POSIX or directly on Windows.
    inner = next(
        (
            p
            for p in NODE_INSTALL_DIR.iterdir()
            if p.is_dir() and p.name.startswith(f"node-v{NODE_VERSION}-")
        ),
        None,
    )
    if not inner:
        return None
    target = _detect_target() if not _is_windows() else NodeTarget("", "", "")
    bin_dir = inner / target.bin_subdir if target.bin_subdir else inner
    if not bin_dir.is_dir():
        return None
    if not (bin_dir / ("node.exe" if _is_windows() else "node")).exists():
        return None
    return bin_dir


def _is_windows() -> bool:
    return platform.system() == "Windows"


def _download(url: str, dest: Path, *, quiet: bool = False) -> None:
    if not quiet:
        print(f"  downloading {url}", file=sys.stderr)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(url) as resp, open(dest, "wb") as f:
        shutil.copyfileobj(resp, f)


def _verify_sha256(archive: Path, expected_filename: str, *, quiet: bool = False) -> None:
    """Download SHASUMS256.txt and verify the archive's checksum."""
    if not quiet:
        print(f"  verifying SHA-256", file=sys.stderr)

    sums_text = ""
    with urllib.request.urlopen(shasums_url()) as resp:
        sums_text = resp.read().decode("utf-8")

    expected_hash: str | None = None
    for line in sums_text.splitlines():
        # Format: "<sha256>  <filename>"
        parts = line.split()
        if len(parts) == 2 and parts[1] == expected_filename:
            expected_hash = parts[0]
            break

    if not expected_hash:
        raise RuntimeError(
            f"SHASUMS256.txt did not list {expected_filename}; refusing to install."
        )

    h = hashlib.sha256()
    with open(archive, "rb") as f:
        for chunk in iter(lambda: f.read(64 * 1024), b""):
            h.update(chunk)
    actual = h.hexdigest()

    if actual != expected_hash:
        raise RuntimeError(
            f"SHA-256 mismatch on {archive.name}.\n"
            f"  expected: {expected_hash}\n"
            f"  actual:   {actual}\n"
            "Refusing to install. Re-run, or install Node manually from nodejs.org."
        )


def _extract(archive: Path, into: Path) -> None:
    into.mkdir(parents=True, exist_ok=True)
    name = archive.name
    if name.endswith(".tar.xz"):
        with tarfile.open(archive, mode="r:xz") as tf:
            tf.extractall(into)
    elif name.endswith(".zip"):
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(into)
    else:
        raise RuntimeError(f"Unknown archive format: {name}")


def install_node(*, quiet: bool = False) -> Path:
    """Download + verify + extract a portable Node into NODE_INSTALL_DIR.
    Returns the path to the bin directory (containing `node` / `npm`).
    Raises on any failure — caller decides how to surface to user.
    """
    existing = archrails_managed_node_bin()
    if existing:
        return existing

    target = _detect_target()
    url = node_archive_url(target)
    expected_filename = f"node-v{NODE_VERSION}-{target.platform_segment}.{target.archive_ext}"
    archive_path = NODE_INSTALL_DIR / expected_filename

    if not quiet:
        print(f"Installing Node.js v{NODE_VERSION} ({target.platform_segment}) "
              f"into {NODE_INSTALL_DIR}…", file=sys.stderr)

    _download(url, archive_path, quiet=quiet)
    _verify_sha256(archive_path, expected_filename, quiet=quiet)
    _extract(archive_path, NODE_INSTALL_DIR)
    archive_path.unlink(missing_ok=True)

    bin_dir = archrails_managed_node_bin()
    if not bin_dir:
        raise RuntimeError(
            f"Extracted Node into {NODE_INSTALL_DIR} but couldn't locate the bin/ dir."
        )

    if not quiet:
        print(f"  ✓ Node.js v{NODE_VERSION} installed at {bin_dir}", file=sys.stderr)
    return bin_dir
