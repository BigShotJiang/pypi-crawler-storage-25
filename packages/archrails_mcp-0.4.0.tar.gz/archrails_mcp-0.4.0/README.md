# ArchRails AWS Backend

Architecture governance for monorepos — enforces [FINOS CALM](https://calm.finos.org) specifications on every pull request using a deterministic rule engine combined with LLM-grounded explanations.

---

## What It Does

ArchRails hooks into your PR workflow. When a developer opens or updates a pull request it:

1. Fetches the diff and the repo's CALM architecture specification
2. Runs a suite of deterministic preflight checks against declared nodes, edges, interfaces, and controls
3. Calls AWS Bedrock (Claude) for grounded, plain-language explanations of any violations
4. Posts the findings as a PR review comment with inline annotations and a blast-radius summary
5. Approves or requests changes based on the deterministic verdict

---

## Supported Providers

| Provider | Auth Method | Inline Comments |
|---|---|---|
| GitHub App | GitHub App installation (HMAC) | Yes |
| GitHub Actions CI | Bearer token via workflow | Yes |
| GitLab (SaaS + Self-Hosted) | Bearer token (Secrets Manager) | Summary only |

---

## Quick Start

### Prerequisites

- AWS account with DynamoDB, S3, Secrets Manager, Bedrock, Step Functions, Lambda, and ECR access
- Python 3.11
- Docker (for Lambda container builds)

### 1. Configure Secrets Manager

Create one secret per tenant with these keys:

```json
{
  "GITHUB_TOKEN":        "<GitHub App installation token>",
  "GITHUB_WEBHOOK_SECRET": "<webhook HMAC secret>",
  "GITLAB_TOKEN":        "<GitLab personal/group access token>",
  "GITLAB_WEBHOOK_SECRET": "<GitLab webhook secret token>"
}
```

Secret ID pattern: `{PROVIDER_SECRET_ID_PREFIX}{tenant_pk}`

### 2. Deploy DynamoDB Tables

Create the following tables (see [Technical Design](TECH_DESIGN.md) for full schemas):

| Table | PK | SK |
|---|---|---|
| `ArchRailsTenants` | `tenant_pk` | — |
| `ArchRailsTenantsProvisioning` | `tenant_pk` | — |
| `ArchRailsRepoLatestConfig` | `tenant_pk` | `repo_sk` |
| `ArchRailsPRValidations` | `tenant_pk` | `repo_sk#{pr_number}` |
| `ArchRailsMergedPRs` | `tenant_pk` | `repo_sk#{pr_number}` |
| `ArchRailsNodeHistory` | `tenant_pk` | `node_id#{created_at}` |
| `ArchRailsAccess` | `tenant_pk` | `repo_sk` |
| `ArchRailsAuditResults` | `tenant_pk` | `repo_sk#{timestamp}` |

### 3. Build and Push Lambda Images

Each Lambda is packaged as a Docker container pushed to ECR:

```bash
ACCOUNT=353468317406
REGION=us-east-2

for lambda in webhook_router fetch_pr_diff fetch_archrails_config \
              bootstrap_governance process_calm_config validate_architecture \
              publish_review_result update_pr_status run_full_audit; do
  docker buildx build --platform linux/amd64 \
    -t ${ACCOUNT}.dkr.ecr.${REGION}.amazonaws.com/${lambda}:latest \
    ./${lambda}
  docker push ${ACCOUNT}.dkr.ecr.${REGION}.amazonaws.com/${lambda}:latest
done
```

### 4. Deploy Step Functions State Machine

Deploy `stepfunction.json` as an Express Workflow with the Lambda ARNs substituted in.

### 5. Add `.archrails/config.yml` to Your Repo

Open a PR with a config file — ArchRails will auto-generate the initial configuration:

```yaml
version: 1
governance:
  sources:
    - id: api
      file: services/api/architecture.json
      provider: calm
      owned_by: platform-team
mapping:
  - path: "services/api/**"
    node: api
  - path: "services/payments/**"
    node: payments
review:
  enforce_governance: true
  comment_mode: review
```

---

## Architecture Overview

```
GitHub / GitLab Webhook
         │
         ▼
  WebhookRouter Lambda
  (verify signature, normalize event)
         │
         ▼
  AWS Step Functions
         │
  ┌──────▼──────┐
  │FetchPRDiff  │  → fetch diff, file list, detect config change
  └──────┬──────┘
         │ archrails_config_in_pr?
         ├─ yes ──────────────────────────────────────┐
         │                                            ▼
         │                               FetchArchRailsConfig
         │                               (fetch CALM sources,
         │                                check bootstrap state)
         │                                            │
         │                              bootstrapped = false?
         │                               ├─ yes → BootstrapGovernance
         │                               │        (scan repo, infer
         │                               │         node→path bindings,
         │                               │         generate config.yml,
         │                               │         commit to PR branch)
         │                               │
         │                               └─ no  → CalmParserLambda
         │                                        (parse + merge CALM,
         │                                         write to S3 staging)
         │                                            │
         └────────────────────────────────────────────┘
                                                      │
                                              ┌───────▼────────┐
                                              │ValidateArch    │
                                              │ · 8 preflight  │
                                              │   checks       │
                                              │ · Bedrock LLM  │
                                              │ · blast radius │
                                              └───────┬────────┘
                                                      │
                                              ┌───────▼────────┐
                                              │PublishReview   │
                                              │ · PR comment   │
                                              │ · inline notes │
                                              │ · APPROVE /    │
                                              │   REQUEST CHGS │
                                              └────────────────┘

On PR merge / close:
  UpdatePRStatus Lambda
  (promote staging → live S3, archive record, activate tenant)
```

---

## Validation Rules

ArchRails enforces 19 deterministic rules across 6 categories:

### Diff vs Baseline (`AR-DIFF-*`)

| Rule | Severity | Trigger |
|---|---|---|
| AR-DIFF-001 | error | Diff calls a host:port not declared in CALM |
| AR-DIFF-002 | error | Diff uses a port not matching the declared interface |
| AR-DIFF-003 | error | Diff introduces a relationship not declared in CALM |
| AR-DIFF-004 | error | Direct DB access from code without a declared connection |
| AR-DIFF-005 | error | Source node not in CALM graph |
| AR-DIFF-007 | error | All files for a CALM node are deleted but node remains |
| AR-DIFF-008 | error | Hardcoded secret or high-entropy token detected in diff |

### CALM Model Compliance (`AR-NODE-*`, `AR-REL-*`)

| Rule | Severity | Trigger |
|---|---|---|
| AR-NODE-001 | warning | Node missing `data-classification` field |
| AR-NODE-002 | warning | Node missing `controls` declaration |
| AR-REL-001 | error | HTTPS declared but diff shows HTTP call |
| AR-REL-002 | warning | Relationship missing `controls` declaration |
| AR-REL-003 | warning | Declared CALM relationship has no diff evidence |
| AR-REL-004 | error | SQL/DB access but relationship type is not `connects` |

### Controls (`AR-CTRL-*`)

| Rule | Severity | Trigger |
|---|---|---|
| AR-CTRL-001 | error | Control config violates requirement JSON schema |
| AR-CTRL-002 | warning | Control requirement URL unreachable |
| AR-CTRL-003 | warning | Control requirement has no URLs to validate |

### Import Boundaries (`AR-IMPORT-*`)

| Rule | Severity | Trigger |
|---|---|---|
| AR-IMPORT-001 | error | Import explicitly forbidden by CALM constraint |
| AR-IMPORT-002 | error | Cross-boundary import not declared in CALM graph |
| AR-IMPORT-003 | warning | Enforced import relationship not evidenced in diff |

Supports 10 languages: Kotlin/Java, Python, TypeScript/JavaScript, Go, Swift, Ruby, C/C++, Rust, C#, Dart.

---

## Repository Structure

```
aws-backend/
├── webhook_router/           # Entrypoint: normalize + dispatch webhooks
├── fetch_pr_diff/            # Fetch PR diff and file list from SCM
├── fetch_archrails_config/   # Fetch .archrails/config.yml, resolve bootstrap state
├── bootstrap_governance/     # Auto-generate config.yml for new tenants
├── process_calm_config/      # Parse + merge CALM, write to S3
├── validate_architecture/    # Preflight checks + Bedrock LLM validation
│   ├── core/
│   │   ├── pattern.py                  # Path glob → node mapping
│   │   ├── control_validator.py        # AR-CTRL-* rules
│   │   ├── relationship_diff_validator.py  # AR-REL-003, AR-REL-004
│   │   ├── preflight_imports.py        # AR-IMPORT-* rules (CALM-driven)
│   │   ├── forbidding_imports.py       # AR-IMPORT-* rules (package-index-driven)
│   │   ├── driver_patterns.py          # DB/queue/HTTP driver detection
│   │   └── secret_scanner.py          # AR-DIFF-008 secret detection
│   ├── use_cases/
│   │   ├── system_prompt_use_case.py   # Bedrock system prompt builder
│   │   ├── user_prompt_use_case.py     # Bedrock user prompt builder
│   │   └── validation_use_case.py      # Bedrock orchestration + fallback
│   └── test/                           # 210 unit tests
├── publish_review_result/    # Post PR comment + inline annotations
├── update_pr_status/         # Handle merge/close, promote S3 staging → live
├── run_full_audit/           # On-demand repo coverage audit (dashboard API)
└── shared/                   # Shared modules across all Lambdas
    ├── aws/
    │   ├── dynamo/            # DynamoDB helpers + record stores
    │   ├── s3/                # S3 read/write helpers
    │   └── secrets/           # Secrets Manager token resolution
    ├── calm/
    │   ├── archrails_config.py  # .archrails/config.yml parser + model
    │   ├── mono/                # Monorepo merge logic
    │   └── shared/              # CALM validators, errors, parsers
    ├── http/                  # HTTP response helpers
    ├── exception/             # Standardized error responses
    ├── identifiers.py         # tenant_pk / repo_sk builders
    └── storage_keys.py        # S3 path builders
```

---

## Running Tests

```bash
# From repo root
python3.11 -m pytest validate_architecture/test/test_calm_validator_edge_cases.py   # 65 tests
python3.11 -m pytest validate_architecture/test/test_calm_enforcer_edge_cases.py    # 145 tests

# Run both (validator file must come first)
python3.11 -m pytest \
  validate_architecture/test/test_calm_validator_edge_cases.py \
  validate_architecture/test/test_calm_enforcer_edge_cases.py
```

---

## Environment Variables

| Variable | Lambda(s) | Description |
|---|---|---|
| `GITHUB_WEBHOOK_SECRET_ID` | WebhookRouter | Secrets Manager prefix for GitHub webhook secrets |
| `GITLAB_WEBHOOK_SECRET_ID` | WebhookRouter, FetchPRDiff | Secrets Manager prefix for GitLab secrets |
| `GITHUB_CI_WEBHOOK_SECRET_ID` | WebhookRouter | Secrets Manager prefix for GitHub CI secrets |
| `GITHUB_TOKEN_SECRET_NAME` | FetchPRDiff, FetchArchRailsConfig | Secret key name for GitHub token |
| `GITLAB_TOKEN_SECRET_NAME` | FetchPRDiff, FetchArchRailsConfig | Secret key name for GitLab token |
| `GITLAB_TOKEN_BEARER` | FetchPRDiff | If `"true"`, use Bearer auth instead of PRIVATE-TOKEN |
| `ARCHRAILS_REPO_LATEST_CONFIG` | BootstrapGovernance, FetchArchRailsConfig | DynamoDB table for repo configs |
| `ARCHRAILS_TABLE` | CalmParser, ValidateArch | DynamoDB table for live tenant data |
| `PR_VALIDATION_TABLE` | ValidateArch, UpdatePRStatus | DynamoDB table for PR validation records |
| `TENANT_PROVISIONING_TABLE` | PublishReview | DynamoDB table for tenant provisioning |
| `INLINE_MIN_SEVERITY` | PublishReview | Minimum severity for inline comments (default: `minor`) |
| `MAX_INLINE_COMMENTS` | PublishReview | Max inline comments per PR (default: `50`) |
| `USE_REVIEW_COMMENTS_API` | PublishReview | If `"true"`, batch inline+summary into single review |
| `SCHEMA_VERSION` | ValidateArch | DynamoDB record schema version |

---

## License

See [LICENSE](LICENSE).
