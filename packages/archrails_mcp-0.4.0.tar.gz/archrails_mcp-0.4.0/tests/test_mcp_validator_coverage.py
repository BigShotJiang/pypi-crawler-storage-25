"""Parity guard: every preflight_ in shared/calm/validators/ must be
either wired into MCP's _VALIDATORS suite OR in the explicit _PR_ONLY_OPTOUT
list with a documented reason.

Without this, the MCP/PR coverage gap silently re-opens every time a new
validator lands at PR-time but nobody remembers to wire it (or document
why it's PR-only). Whole point of the "same brain, two surfaces" design.
"""
from __future__ import annotations

import importlib
import inspect
import pkgutil
import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

import shared.calm.validators
from archrails_mcp_server.tools.check_proposed_change import (
    _PR_ONLY_OPTOUT,
    _VALIDATORS,
    _WIRED_VIA_ADAPTER,
)


def _all_preflight_functions() -> dict[str, str]:
    """Return {function_name: module_name} for every `preflight_*` callable
    defined in shared.calm.validators (recursively). Functions imported
    from elsewhere are skipped — only module-defined preflight_* counts.
    """
    found: dict[str, str] = {}
    pkg = shared.calm.validators
    pkg_path = Path(pkg.__file__).parent
    for mod_info in pkgutil.iter_modules([str(pkg_path)]):
        if mod_info.ispkg:
            continue
        mod_name = f"{pkg.__name__}.{mod_info.name}"
        mod = importlib.import_module(mod_name)
        for name, obj in inspect.getmembers(mod, inspect.isfunction):
            if not name.startswith("preflight_"):
                continue
            # Only count functions ACTUALLY defined in this module — skip
            # re-exports / cross-imports.
            if obj.__module__ != mod_name:
                continue
            found[name] = mod_name
    return found


def test_every_preflight_is_either_wired_or_documented_pr_only():
    """The MCP/PR parity invariant. New preflight_ landing without an
    entry in either _VALIDATORS or _PR_ONLY_OPTOUT fails this test —
    forcing the author to make an explicit decision instead of silently
    leaving MCP-time coverage behind.
    """
    discovered = _all_preflight_functions()
    wired = {runner.__name__ for runner, *_ in _VALIDATORS} | _WIRED_VIA_ADAPTER
    optout = set(_PR_ONLY_OPTOUT.keys())

    unaccounted = sorted(set(discovered.keys()) - wired - optout)

    assert not unaccounted, (
        "These preflight_ functions are neither wired into MCP nor "
        "explicitly opted out:\n  "
        + "\n  ".join(
            f"{name}  ({discovered[name]})" for name in unaccounted
        )
        + "\n\nFix: either add to _VALIDATORS in "
        "archrails_mcp_server/tools/check_proposed_change.py "
        "(if it consumes (graph, node_map, diff) and is meaningful at "
        "code-gen time), OR add to _PR_ONLY_OPTOUT with a reason "
        "(if it's graph-only / needs PR context / etc.)."
    )


def test_optout_entries_reference_real_validators():
    """Catches typos in the opt-out list — every name there must
    correspond to an actual preflight_ function that exists.
    """
    discovered = set(_all_preflight_functions().keys())
    stale = sorted(set(_PR_ONLY_OPTOUT.keys()) - discovered)
    assert not stale, (
        "These names appear in _PR_ONLY_OPTOUT but no preflight_ function "
        "with that name exists in shared.calm.validators:\n  "
        + "\n  ".join(stale)
        + "\n\nProbably a rename or removal. Update or delete the entry."
    )


def test_no_validator_appears_in_both_wired_and_optout():
    """A validator can't be both wired AND opted-out — that's contradictory."""
    wired = {runner.__name__ for runner, *_ in _VALIDATORS}
    optout = set(_PR_ONLY_OPTOUT.keys())
    overlap = sorted(wired & optout)
    assert not overlap, (
        "These validators appear in BOTH _VALIDATORS and _PR_ONLY_OPTOUT — "
        "pick one:\n  " + "\n  ".join(overlap)
    )


def test_optout_reasons_are_nonempty():
    """Every opt-out needs a reason — bare `: ""` defeats the point."""
    blank = sorted(name for name, reason in _PR_ONLY_OPTOUT.items() if not reason.strip())
    assert not blank, (
        "These opt-out entries have empty reasons:\n  " + "\n  ".join(blank)
    )
