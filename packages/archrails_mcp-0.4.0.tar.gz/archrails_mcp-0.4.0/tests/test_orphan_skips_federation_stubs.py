"""
AR-GRAPH-001 should NOT fire on federated stub nodes added by the
federation enrichment helper. Those nodes are inserted at validation
time so cross-repo boundary checks (DB-boundary, outbound) can resolve
hostnames; they're not authored topology and the user can't fix them
locally — declaring an edge would be wrong because the *real* edges
live in the federation table or the contract repo.
"""
from __future__ import annotations

import os
import sys

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))
sys.path.insert(0, os.path.join(this_dir, ".."))

from shared.calm.validators.graph_topology_validator import preflight_orphan_nodes


def test_skips_external_stub():
    """`metadata.external: True` marks a foreign-owned boundary node
    pulled in by the outbound/inbound enrichment passes."""
    graph = {
        "nodes": [
            {"id": "web-gui",         "type": "webclient"},
            {"id": "account-service", "type": "service",
             "metadata": {"external": True, "repository": "https://github.com/x/y"}},
        ],
        "edges": [{"from": "web-gui", "to": "account-service"}],
    }
    out = preflight_orphan_nodes(graph)
    assert out == []   # account-service is in an edge anyway, but if it weren't
                       # the external marker would skip it.


def test_skips_tenant_db_stub_when_orphan():
    """`metadata.tenant_db_stub: True` marks a DB-typed node added
    purely to populate the boundary validator's host index. It has
    no edges by design — flagging it as AR-GRAPH-001 is noise the
    user can't act on."""
    graph = {
        "nodes": [
            {"id": "web-gui", "type": "webclient"},
            {"id": "trade-data-store", "node-type": "database",
             "metadata": {"tenant_db_stub": True, "external": True}},
            {"id": "user-directory",   "node-type": "ldap",
             "metadata": {"tenant_db_stub": True, "external": True}},
        ],
        "edges": [],
    }
    out = preflight_orphan_nodes(graph)
    # web-gui has no edges either — but it's local-authored, so it
    # SHOULD fire. The two stubs should NOT.
    flagged = {v["node"] for v in out}
    assert "web-gui" in flagged
    assert "trade-data-store" not in flagged
    assert "user-directory" not in flagged


def test_local_orphan_still_fires():
    """A locally-authored node with no edges must still fire — the
    skip is only for federated stubs."""
    graph = {
        "nodes": [{"id": "lonely-service", "type": "service"}],
        "edges": [],
    }
    out = preflight_orphan_nodes(graph)
    flagged = {v["node"] for v in out}
    assert flagged == {"lonely-service"}
