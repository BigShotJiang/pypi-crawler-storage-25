"""Parity test: archrails.scan_for_drift (MCP path) ==
shared.calm.audit.drift_scanner.scan_for_drift (Lambda path).

The MCP tool wraps file collection + graph-dict construction around the
exact same scanner the run_full_audit Lambda invokes after fetching its
tarball from S3. This test runs both paths against the same fixture and
asserts the violation set is identical.

If this fails it means either:
- scan_for_drift.run() in archrails_mcp_server.tools is passing the scanner
  different inputs than the Lambda would (file shape, mapping shape,
  graph shape), OR
- the file-collection layer (`_collect_files`) is dropping or adding
  files in a way that changes the scan result.

Both are silent-drift hazards. CI catches them here.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from archrails_mcp_server.workspace_loader import load_graph
from archrails_mcp_server.tools import scan_for_drift as mcp_scan
from shared.calm.audit.drift_scanner import scan_for_drift


SAMPLE = _REPO_ROOT / "archrails_mcp" / "examples" / "sample-payments-platform"


@pytest.fixture(scope="module")
def graph():
    return load_graph(SAMPLE)


def _violations_set(report: dict) -> set[tuple]:
    """Reduce a violation report to a comparable set of (rule_id, file, node)
    tuples. We compare the SET, not the order — the scanner may emit
    violations in arbitrary order, but the set must match.
    """
    out: set[tuple] = set()
    for v in report.get("violations") or []:
        out.add((
            v.get("rule_id") or v.get("rule"),
            v.get("file"),
            v.get("node"),
        ))
    return out


def test_drift_parity_on_sample_fixture(graph):
    """Run both paths against the live sample. Same file contents, same
    mapping, same graph → same violations.
    """
    # Lambda path: build the file list the way the Lambda would after
    # untarring the tarball, then call scan_for_drift directly.
    files: list[tuple[str, str]] = []
    for fs_path in SAMPLE.rglob("*"):
        if not fs_path.is_file():
            continue
        rel = str(fs_path.relative_to(SAMPLE))
        if "__pycache__" in rel:
            continue
        try:
            content = fs_path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        files.append((rel, content))

    graph_dict = {
        "nodes": graph.nodes,
        "relationships": graph.relationships,
        "edges": graph.relationships,
    }
    lambda_report = scan_for_drift(
        files=files,
        mapping=graph.config.mapping,
        graph=graph_dict,
    )
    lambda_violations = _violations_set(lambda_report)

    # MCP path: ask the tool to do the same work.
    mcp_response = mcp_scan.run(graph, verbose=True)
    mcp_violations = _violations_set({"violations": mcp_response.get("violations") or []})

    assert lambda_violations == mcp_violations, (
        f"DRIFT — Lambda path fired {lambda_violations}, "
        f"MCP path fired {mcp_violations}; difference is "
        f"{lambda_violations ^ mcp_violations}"
    )


def test_mcp_summary_shape(graph):
    """The default (non-verbose) MCP response must include the summary
    fields the agent's tool description promises.
    """
    response = mcp_scan.run(graph)
    assert "summary" in response
    summary = response["summary"]
    for key in (
        "total_violations",
        "by_rule_id",
        "by_severity",
        "files_scanned",
    ):
        assert key in summary, f"summary missing {key}: {summary}"
    assert response.get("rules_evaluated") == [
        "AR-DRIFT-001",
        "AR-DRIFT-002",
        "AR-DRIFT-003",
    ]


def test_mcp_path_glob_scoping(graph):
    """When path_glob is provided, MCP should scan strictly fewer files."""
    full = mcp_scan.run(graph)
    scoped = mcp_scan.run(graph, path_glob="services/payment-api/**")

    full_count = full["summary"].get("files_scanned", 0)
    scoped_count = scoped["summary"].get("files_scanned", 0)

    # Either equal (only payment-api files exist) or strictly fewer.
    assert scoped_count <= full_count, (
        f"path_glob did not narrow: full={full_count}, scoped={scoped_count}"
    )
