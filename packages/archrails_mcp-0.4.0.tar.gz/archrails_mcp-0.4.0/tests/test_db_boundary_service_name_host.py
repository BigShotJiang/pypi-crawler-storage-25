"""
Tests for the architectural_db_boundary_validator regex fix that lets
service-name-style hostnames (Kubernetes/Docker DNS like
`trade-data-store`) flow through to the DB-host index lookup.

Before: the guard `h and "." in h or h in {"localhost"}` had a precedence
bug AND excluded any host without a literal dot. That silently dropped
the most common modern container hostname form, so AR-CTRL-DB-BOUNDARY-001
never fired on a Kubernetes-deployed monorepo.

After: hyphenated single-token hosts (containing `-`) are accepted
alongside DNS and localhost. False positives are filtered downstream by
the DB host index — if `trade-data-store` doesn't map to a `database`-
typed node in the graph, the lookup returns None and no violation fires.
"""
from __future__ import annotations

import os
import sys

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))
# The validator module uses bare `from shared.calm.validators.X import Y` imports that
# resolve only when validate_architecture/ is on sys.path.
sys.path.insert(0, os.path.join(this_dir, ".."))

from shared.calm.validators.architectural_db_boundary_validator import (
    _extract_db_hosts,
    preflight_architectural_db_boundary,
)


def test_extract_accepts_kubernetes_service_name_direct_assignment():
    """Direct assignment: `host: 'trade-data-store'` — what _SDK_HOST_RE
    is designed to catch. The fix is the precedence + service-name
    accept; the regex itself wasn't the gap here."""
    line = "  host: 'trade-data-store',"
    hosts = _extract_db_hosts(line)
    assert "trade-data-store" in hosts


def test_extract_accepts_nullish_coalesce_fallback_string():
    """The exact demo PR shape — `host: env.X ?? 'literal'`. The
    SDK_HOST_FALLBACK_RE pattern is the second SDK-host pattern,
    constrained to `??`/`||` so we don't false-fire on unrelated
    quoted strings later in the line."""
    line = "host: import.meta.env.VITE_TRADE_DB_HOST ?? 'trade-data-store',"
    hosts = _extract_db_hosts(line)
    assert "trade-data-store" in hosts


def test_extract_accepts_logical_or_fallback_string():
    """Same shape with `||` instead of `??`. Common in older JS/Ruby."""
    line = "host: process.env.DB_HOST || 'orders-db.prod',"
    hosts = _extract_db_hosts(line)
    assert "orders-db.prod" in hosts


def test_fallback_regex_does_not_eat_unrelated_strings_on_same_line():
    """Regression guard: the fallback pattern must only match literals
    after `??`/`||`. A bare quoted string elsewhere shouldn't trigger."""
    # `name` field carries a quoted literal that looks like a host but
    # is not preceded by host:/server:/cluster: + ??/|| — must be skipped.
    line = "name: 'orders-db', port: 5432,"
    hosts = _extract_db_hosts(line)
    assert "orders-db" not in hosts


def test_extract_accepts_jdbc_service_name():
    line = 'String url = "jdbc:postgresql://orders-db:5432/orders";'
    hosts = _extract_db_hosts(line)
    assert "orders-db" in hosts


def test_extract_still_accepts_dotted_dns():
    """Regression — must not break the existing case."""
    line = "DATABASE_URL=postgres://user:pass@db.payments.internal:5432/app"
    hosts = _extract_db_hosts(line)
    assert "db.payments.internal" in hosts


def test_extract_still_accepts_localhost():
    line = 'host="localhost"'
    hosts = _extract_db_hosts(line)
    assert "localhost" in hosts


def test_extract_drops_random_dotless_words():
    """The hyphen requirement keeps prose-style false positives out.
    A keyword like `host=banana` (no dot, no hyphen) is still rejected
    so we don't fire on developer comments."""
    line = "host=banana"
    hosts = _extract_db_hosts(line)
    assert "banana" not in hosts


def test_validator_fires_on_undeclared_kube_service_db_access():
    """End-to-end on the demo PR shape: web-gui code introduces a
    direct connection to trade-data-store, which is a database-typed
    node in the (federation-enriched) graph but has no declared
    `connects` edge from web-gui."""
    graph = {
        "nodes": [
            {"id": "web-gui", "node-type": "webclient"},
            {
                "id":         "trade-data-store",
                "node-type":  "database",
                "interfaces": {"primary": {"host": "trade-data-store"}},
                "metadata":   {"external": True},
            },
        ],
        "edges": [],
    }
    diff = (
        "+++ b/services/web-gui/src/pg.ts\n"
        "@@ -0,0 +1,3 @@\n"
        "+const pool = new Pool({\n"
        "+  host: 'trade-data-store',\n"
        "+  port: 5432,\n"
        "+});\n"
    )
    node_map = {"web-gui": ["services/web-gui/src/pg.ts"]}
    violations = preflight_architectural_db_boundary(
        graph=graph, node_map=node_map, diff=diff,
    )
    assert len(violations) == 1
    v = violations[0]
    assert v["rule_id"] == "AR-CTRL-DB-BOUNDARY-001"
    assert v["node"] == "web-gui"
    assert v["target_node"] == "trade-data-store"
    assert v["severity"] == "error"


def test_db_boundary_violation_carries_line_number_for_inline_comment():
    """Violations must include the new-file line number where the host
    literal was added so PublishReviewResult.inline_policy can place
    an inline review comment on that exact line. Without this,
    inline_policy.filter_inline_candidates rejects the issue (it
    requires a truthy `line_range`) and the finding silently lands as
    a summary-only comment."""
    graph = {
        "nodes": [
            {"id": "web-gui", "node-type": "webclient"},
            {"id": "trade-data-store", "node-type": "database"},
        ],
        "edges": [],
    }
    diff = (
        "+++ b/services/web-gui/src/api/tradeStoreClient.ts\n"
        "@@ -0,0 +1,5 @@\n"
        "+import { Pool } from 'pg';\n"
        "+const pool = new Pool({\n"
        "+  host: 'trade-data-store',\n"
        "+  port: 5432,\n"
        "+});\n"
    )
    node_map = {"web-gui": ["services/web-gui/src/api/tradeStoreClient.ts"]}
    violations = preflight_architectural_db_boundary(
        graph=graph, node_map=node_map, diff=diff,
    )
    assert len(violations) == 1
    v = violations[0]
    # Line 3 in the new file is where `host: 'trade-data-store'` lives.
    assert v.get("line") == 3
    assert v.get("line_range") == "3"


def test_db_boundary_fires_on_node_without_explicit_interface_host():
    """The fallback case: a database-typed node that doesn't declare
    interfaces explicitly should still register its `unique-id` as a
    host, so a code reference to `host: 'trade-data-store'` triggers
    the boundary rule even when the team CALM hasn't bothered to fill
    in `interfaces.host`. Matches the k8s / docker convention where
    service-name == DNS-name."""
    graph = {
        "nodes": [
            {"id": "web-gui", "node-type": "webclient"},
            {"id": "trade-data-store", "node-type": "database"},   # no interfaces
        ],
        "edges": [],
    }
    diff = (
        "+++ b/services/web-gui/src/api/tradeStoreClient.ts\n"
        "+const pool = new Pool({ host: 'trade-data-store' });\n"
    )
    node_map = {"web-gui": ["services/web-gui/src/api/tradeStoreClient.ts"]}
    violations = preflight_architectural_db_boundary(
        graph=graph, node_map=node_map, diff=diff,
    )
    assert len(violations) == 1
    v = violations[0]
    assert v["rule_id"] == "AR-CTRL-DB-BOUNDARY-001"
    assert v["target_node"] == "trade-data-store"


def test_validator_passes_when_edge_is_declared():
    """If the CALM declares web-gui → trade-data-store as a connects
    edge, the same diff must pass."""
    graph = {
        "nodes": [
            {"id": "web-gui", "node-type": "webclient"},
            {
                "id":         "trade-data-store",
                "node-type":  "database",
                "interfaces": {"primary": {"host": "trade-data-store"}},
            },
        ],
        "edges": [
            {"from": "web-gui", "to": "trade-data-store", "type": "connects"},
        ],
    }
    diff = (
        "+++ b/services/web-gui/src/pg.ts\n"
        "+const pool = new Pool({ host: 'trade-data-store' });\n"
    )
    node_map = {"web-gui": ["services/web-gui/src/pg.ts"]}
    violations = preflight_architectural_db_boundary(
        graph=graph, node_map=node_map, diff=diff,
    )
    assert violations == []
