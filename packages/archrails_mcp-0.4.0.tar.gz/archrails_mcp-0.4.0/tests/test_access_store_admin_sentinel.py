"""
Tests for shared.aws.dynamo.access_store.get_authorized_repos —
the admin-sentinel expansion that GetPRs / GetBlastRadius / GetNodeHistory
all delegate to.

The original bug: a tenant admin's ArchRailsAccess row carries
repo_sk = "__TENANT_ADMIN__" (a sentinel, not a real repo_sk). Handlers
that downstream-queried `repo_sk begins_with("__TENANT_ADMIN__#")`
matched zero PRs, so the admin saw an empty dashboard.

After the fix: the sentinel expands to one entry per repo currently
registered for the tenant, with the sentinel's role inherited.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import patch

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))

os.environ.setdefault("AWS_DEFAULT_REGION", "us-east-2")
os.environ.setdefault("AWS_ACCESS_KEY_ID", "test")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "test")

from shared.aws.dynamo import access_store


TENANT = "TENANT#ghci#github.com#tenant1"


class _FakeTable:
    """Minimal stand-in for boto3.dynamodb Table.query()."""
    def __init__(self, rows_by_group: dict[str, list[dict]]):
        self.rows_by_group = rows_by_group

    def query(self, *, IndexName, KeyConditionExpression, **_kwargs):
        # KeyConditionExpression is a boto3 condition object; in tests we
        # cheat and pass the group via a side-channel mock instead. The
        # real query in production binds `Key("group_name").eq(group)`.
        # We monkey-patch get_authorized_repos's `groups` iterator below
        # to drive lookups directly.
        return {"Items": []}  # not used; see _drive_lookup


def _patch_table_with_rows(rows_by_group: dict[str, list[dict]]):
    """Replace access_store._table() with a function that returns a
    fake table whose `query` honors the per-group rows dict."""
    class _T:
        @staticmethod
        def query(*, IndexName, KeyConditionExpression, **kwargs):
            # KeyConditionExpression is constructed via Key("group_name").eq(group).
            # Extract group from the condition object's _values when available.
            try:
                group = KeyConditionExpression._values[1]
            except Exception:
                group = None
            return {"Items": rows_by_group.get(group, [])}
    return patch.object(access_store, "_table", lambda: _T)


def test_no_groups_returns_empty():
    assert access_store.get_authorized_repos([]) == []


def test_non_admin_row_passes_through():
    """A row with a real repo_sk is returned verbatim."""
    rows = {"group-a": [
        {"tenant_pk": TENANT, "repo_sk": "github#github.com#42", "role": "regular"},
    ]}
    with _patch_table_with_rows(rows):
        out = access_store.get_authorized_repos(["group-a"])
    assert out == [
        {"tenant_pk": TENANT, "repo_sk": "github#github.com#42", "role": "regular"},
    ]


def test_admin_sentinel_expands_to_all_tenant_repos():
    """The bug we're fixing: sentinel must expand to per-repo rows."""
    rows = {"group-admin": [
        {"tenant_pk": TENANT, "repo_sk": access_store.ADMIN_SENTINEL_REPO_SK, "role": "admin"},
    ]}
    with _patch_table_with_rows(rows), \
         patch.object(access_store, "list_tenant_repos", return_value=[
            {"repo_sk": "github#github.com#100", "repo_owner": "ArchRails", "repo_name": "a"},
            {"repo_sk": "github#github.com#200", "repo_owner": "ArchRails", "repo_name": "b"},
            {"repo_sk": "github#github.com#300", "repo_owner": "ArchRails", "repo_name": "c"},
         ]):
        out = access_store.get_authorized_repos(["group-admin"])

    repo_sks = {r["repo_sk"] for r in out}
    assert repo_sks == {
        "github#github.com#100", "github#github.com#200", "github#github.com#300",
    }
    # Role must be inherited from the sentinel, not silently downgraded.
    assert all(r["role"] == "admin" for r in out)
    # Sentinel itself must NOT survive the expansion — downstream
    # `repo_sk begins_with("__TENANT_ADMIN__#")` queries match nothing.
    assert access_store.ADMIN_SENTINEL_REPO_SK not in repo_sks


def test_dedup_across_groups():
    """User in two admin-equivalent groups for the same tenant must
    not get the same repo twice."""
    rows = {
        "group-a": [
            {"tenant_pk": TENANT, "repo_sk": "github#github.com#42", "role": "regular"},
        ],
        "group-b": [
            {"tenant_pk": TENANT, "repo_sk": "github#github.com#42", "role": "admin"},
        ],
    }
    with _patch_table_with_rows(rows):
        out = access_store.get_authorized_repos(["group-a", "group-b"])
    assert len(out) == 1
    # First-write-wins on dedup — the regular role from group-a survives.
    # This isn't load-bearing for the demo bug, but the test pins the
    # current behavior so a future "highest role wins" change is
    # explicit.
    assert out[0]["repo_sk"] == "github#github.com#42"


def test_admin_and_explicit_repo_dedup():
    """If a user has BOTH the admin sentinel AND a direct row for repo
    X, expansion + dedup must yield a single entry for X."""
    rows = {"group-admin": [
        {"tenant_pk": TENANT, "repo_sk": access_store.ADMIN_SENTINEL_REPO_SK, "role": "admin"},
        {"tenant_pk": TENANT, "repo_sk": "github#github.com#100", "role": "regular"},
    ]}
    with _patch_table_with_rows(rows), \
         patch.object(access_store, "list_tenant_repos", return_value=[
            {"repo_sk": "github#github.com#100", "repo_owner": "x", "repo_name": "y"},
            {"repo_sk": "github#github.com#200", "repo_owner": "x", "repo_name": "z"},
         ]):
        out = access_store.get_authorized_repos(["group-admin"])

    repo_sks = [r["repo_sk"] for r in out]
    assert repo_sks.count("github#github.com#100") == 1
    assert "github#github.com#200" in repo_sks
