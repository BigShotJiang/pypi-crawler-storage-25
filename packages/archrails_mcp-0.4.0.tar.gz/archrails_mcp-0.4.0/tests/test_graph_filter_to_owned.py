"""
Tests for shared.calm.graph_filter.filter_graph_to_owned.

Pinned scenarios:
  - Owned-only filter drops boundary-stub nodes whose
    metadata.repository points elsewhere.
  - An edge whose endpoints span owned + external is dropped — that
    edge belongs in the federation table, not the live graph.
  - Nodes without metadata.repository are owned by the current repo
    (the contract repo's actor case, and the common monorepo case).
  - Idempotent: filtering twice = filtering once.
  - Falsy `repo_canonical` returns the input unchanged (deep-copied).
"""
from __future__ import annotations

import os
import sys

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))

from shared.calm.graph_filter import filter_graph_to_owned


CONTRACT = "https://github.com/archrails/traderx-architecture"
FRONTEND = "https://github.com/archrails/traderx-frontend"
ACCOUNTS = "https://github.com/archrails/traderx-accounts"


def test_drops_boundary_nodes_in_contract_repo():
    """Architecture's contract: 1 owned actor + many boundary stubs.
    After filter the cluster owns just the actor."""
    graph = {
        "nodes": [
            {"id": "trader", "type": "actor"},
            {"id": "web-gui", "metadata": {"repository": FRONTEND}},
            {"id": "account-service", "metadata": {"repository": ACCOUNTS}},
        ],
        "edges": [
            {"id": "trader-web-gui",         "from": "trader",  "to": "web-gui"},
            {"id": "web-gui-account-service","from": "web-gui", "to": "account-service"},
        ],
    }
    out = filter_graph_to_owned(graph, CONTRACT)
    assert {n["id"] for n in out["nodes"]} == {"trader"}
    # Both edges have at least one external endpoint → both dropped.
    assert out["edges"] == []


def test_keeps_internal_topology_for_team_repo():
    """A team repo that owns multiple services with only internal
    edges should be untouched by the filter."""
    graph = {
        "nodes": [
            {"id": "trade-service",   "metadata": {"repository": "https://github.com/archrails/traderx-trading"}},
            {"id": "trade-feed",      "metadata": {"repository": "https://github.com/archrails/traderx-trading"}},
            {"id": "trade-processor", "metadata": {"repository": "https://github.com/archrails/traderx-trading"}},
        ],
        "edges": [
            {"id": "ts-tf",  "from": "trade-service",   "to": "trade-feed"},
            {"id": "tf-tp",  "from": "trade-feed",      "to": "trade-processor"},
            {"id": "tp-tf",  "from": "trade-processor", "to": "trade-feed"},
        ],
    }
    out = filter_graph_to_owned(graph, "https://github.com/archrails/traderx-trading")
    assert len(out["nodes"]) == 3
    assert len(out["edges"]) == 3


def test_no_metadata_treated_as_owned():
    """A node with no metadata defaults to owned-by-current-repo —
    the common case for actor / unannotated monorepo nodes."""
    graph = {
        "nodes": [{"id": "trader", "type": "actor"}],
        "edges": [],
    }
    out = filter_graph_to_owned(graph, CONTRACT)
    assert out["nodes"] == [{"id": "trader", "type": "actor"}]


def test_drops_edge_when_one_endpoint_external():
    """An edge with one local + one external endpoint is a cross-repo
    reference — it belongs in the federation table, not in any per-repo
    live graph."""
    graph = {
        "nodes": [
            {"id": "web-gui", "metadata": {"repository": FRONTEND}},
            {"id": "account-service", "metadata": {"repository": ACCOUNTS}},
        ],
        "edges": [
            {"id": "web-gui-account-service", "from": "web-gui", "to": "account-service"},
        ],
    }
    out = filter_graph_to_owned(graph, FRONTEND)
    assert {n["id"] for n in out["nodes"]} == {"web-gui"}
    assert out["edges"] == []


def test_idempotent():
    graph = {
        "nodes": [
            {"id": "trader"},
            {"id": "web-gui", "metadata": {"repository": FRONTEND}},
        ],
        "edges": [{"id": "tw", "from": "trader", "to": "web-gui"}],
    }
    once  = filter_graph_to_owned(graph, CONTRACT)
    twice = filter_graph_to_owned(once, CONTRACT)
    assert once == twice


def test_falsy_repo_canonical_returns_unchanged_copy():
    graph = {"nodes": [{"id": "x"}], "edges": []}
    out = filter_graph_to_owned(graph, "")
    assert out == graph
    assert out is not graph   # deep-copied so callers can mutate


def test_canonicalization_handles_case_mismatch():
    """metadata.repository written with mixed case must still match
    the canonical form (path lowercased per canonicalize_repo_url)."""
    graph = {
        "nodes": [
            {"id": "web-gui", "metadata": {"repository": "https://github.com/ArchRails/traderx-frontend"}},
        ],
        "edges": [],
    }
    out = filter_graph_to_owned(graph, FRONTEND)   # FRONTEND is lowercase
    assert {n["id"] for n in out["nodes"]} == {"web-gui"}


def test_malformed_metadata_falls_through_as_owned():
    """A node with non-string metadata.repository value (number, list,
    bool) shouldn't blow up the filter — it's treated as owned, with
    the caller free to surface authoring errors elsewhere."""
    graph = {
        "nodes": [
            {"id": "weird1", "metadata": {"repository": 42}},
            {"id": "weird2", "metadata": {"repository": ["a", "b"]}},
            {"id": "ok",     "metadata": {"repository": ""}},
        ],
        "edges": [],
    }
    out = filter_graph_to_owned(graph, FRONTEND)
    assert {n["id"] for n in out["nodes"]} == {"weird1", "weird2", "ok"}
