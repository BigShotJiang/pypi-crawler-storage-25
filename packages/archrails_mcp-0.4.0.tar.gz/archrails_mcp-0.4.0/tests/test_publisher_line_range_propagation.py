"""
synthesize_issue_from_violation must propagate `line` / `line_range`
from validator output into the issue dict, otherwise inline-comment
filtering in publish_review_result rejects every issue (it requires a
truthy `line_range`) and high-severity findings silently land as a
summary-only comment instead of an inline review on the offending line.
"""
from __future__ import annotations

import os
import sys

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))
sys.path.insert(0, os.path.join(this_dir, "..", "publish_review_result"))

import os as _os
_os.environ.setdefault("AWS_DEFAULT_REGION", "us-east-2")
_os.environ.setdefault("AWS_ACCESS_KEY_ID", "test")
_os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "test")

from PublishReviewResult import synthesize_issue_from_violation


_ALLOWED = {"services/web-gui/src/api/tradeStoreClient.ts"}


def _violation(**overrides):
    base = {
        "rule":     "ARCHITECTURAL_DIRECT_DB_ACCESS_VIOLATION",
        "rule_id":  "AR-CTRL-DB-BOUNDARY-001",
        "severity": "error",
        "message":  "...",
        "file":     "services/web-gui/src/api/tradeStoreClient.ts",
    }
    base.update(overrides)
    return base


def test_propagates_int_line_to_string_line_range():
    """A validator that emits `line: 3` should produce an issue with
    `line_range: "3"` so inline_policy keeps it as a candidate."""
    issue = synthesize_issue_from_violation(_violation(line=3), _ALLOWED, {})
    assert issue is not None
    assert issue["line_range"] == "3"


def test_propagates_string_line_range_verbatim():
    """A validator that pre-formats `line_range: "12-15"` keeps it."""
    issue = synthesize_issue_from_violation(
        _violation(line_range="12-15"), _ALLOWED, {},
    )
    assert issue is not None
    assert issue["line_range"] == "12-15"


def test_no_line_info_yields_empty_line_range():
    """Backwards-compat: a validator that doesn't know its line
    number still produces a valid issue (just won't be eligible for
    inline placement)."""
    issue = synthesize_issue_from_violation(_violation(), _ALLOWED, {})
    assert issue is not None
    assert issue["line_range"] == ""


def test_zero_or_negative_line_treated_as_missing():
    """A line of 0 or negative isn't a real source line — don't pass
    a fake `line_range: "0"` through to the publisher (would 422 on
    GitHub's review API)."""
    for bad in (0, -1, "0"):
        issue = synthesize_issue_from_violation(_violation(line=bad), _ALLOWED, {})
        assert issue is not None
        assert issue["line_range"] == ""


def test_string_line_propagates_as_line_range():
    """Some validators might emit `line: "42"` (string) — accept it."""
    issue = synthesize_issue_from_violation(_violation(line="42"), _ALLOWED, {})
    assert issue is not None
    assert issue["line_range"] == "42"


def test_inline_policy_keeps_issue_with_line_range_after_fix():
    """End-to-end: violation → issue → filter_inline_candidates keeps
    it. Without the line propagation fix, inline_policy would silently
    drop every error-severity finding."""
    from provider.inline_policy import filter_inline_candidates
    issue = synthesize_issue_from_violation(_violation(line=3), _ALLOWED, {})
    keepers = filter_inline_candidates([issue], "high")
    assert keepers, "issue with line_range should pass the inline filter"
