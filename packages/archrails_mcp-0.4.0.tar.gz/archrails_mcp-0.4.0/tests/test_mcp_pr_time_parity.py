"""
Parity tests for the "same brain, two surfaces" claim.

For each scenario, the test runs the EXACT same `shared.calm.validators`
preflight_* functions twice:

  1. **PR-time path** — directly with a hand-written unified-diff string,
     the way ValidateArchitecture would invoke them on a real PR.
  2. **MCP path** — through `archrails_mcp_server.tools.check_proposed_change.run`
     which synthesizes a diff from a structured `evidence` payload via
     `archrails_mcp_server.evidence_diff.evidence_to_diff` and runs the same
     validators.

The assertion is: **the SET of rule IDs fired must be identical.** A
divergence means either:
- The translator (evidence_diff.py) failed to produce a diff line that
  triggers the validator's regex/AST patterns, OR
- A rule got reimplemented as an MCP-specific heuristic (i.e. drifted
  from same-brain).

These tests are the regression guard against silent drift. Run on every
push.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

# Make repo packages importable when invoked via `pytest tests/...`
_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from archrails_mcp_server.evidence_diff import evidence_to_diff, synthesize_node_map
from archrails_mcp_server.workspace_loader import load_graph
from archrails_mcp_server.tools.check_proposed_change import _VALIDATORS, run as check_run
from shared.calm.validators.pattern import map_paths_to_nodes


SAMPLE = _REPO_ROOT / "archrails_mcp" / "examples" / "sample-payments-platform"


@pytest.fixture(scope="module")
def graph():
    return load_graph(SAMPLE)


def _validator_graph(graph):
    """Same wrapping check_proposed_change uses internally."""
    return {
        "nodes": graph.nodes,
        "relationships": graph.relationships,
        "edges": graph.relationships,
    }


def _run_pr_time(graph, source_node: str, path: str, real_diff: str) -> set[str]:
    """Direct PR-time path: invoke each MCP-wired validator with the real
    diff and collect the rule_ids that fire. Phase 3d removed the
    sensitivity-gate divergence — both surfaces now run every wired
    validator on every governed file uniformly.
    """
    g = _validator_graph(graph)
    nm = {source_node: [path]}
    rule_ids: set[str] = set()

    for runner, _label, convention in _VALIDATORS:
        try:
            if convention == "kwargs":
                verdicts = runner(graph=g, node_map=nm, diff=real_diff) or []
            else:
                verdicts = runner(g, nm, real_diff) or []
        except Exception as e:
            pytest.fail(f"PR-time validator crashed: {type(e).__name__}: {e}")
        for v in verdicts:
            rid = v.get("rule_id") or v.get("rule")
            if rid:
                rule_ids.add(rid)
    return rule_ids


def _run_mcp(graph, path: str, evidence: dict) -> set[str]:
    """MCP path: invoke check_proposed_change.run, extract rule ids from
    the verdicts it returned.
    """
    response = check_run(graph, path=path, evidence=evidence)
    return {
        v["rule"]
        for v in response.get("verdicts", [])
        if v.get("rule") and v.get("rule") != "AR-MCP-INTERNAL"
    }


# ── Scenarios ────────────────────────────────────────────────────────────────

PAYMENT_API_PATH = "services/payment-api/src/Client.java"


def test_parity_forbidden_db_connection(graph):
    """payment-api → card-db direct JDBC. Should fire AR-CTRL-DB-BOUNDARY-001
    on both paths.
    """
    real_diff = (
        f"diff --git a/{PAYMENT_API_PATH} b/{PAYMENT_API_PATH}\n"
        f"--- a/{PAYMENT_API_PATH}\n"
        f"+++ b/{PAYMENT_API_PATH}\n"
        "@@ -1,1 +1,3 @@\n"
        '+String url = "jdbc:postgresql://card-db.internal:5432/db";\n'
    )
    evidence = {
        "calls_added": [
            {"target_host": "card-db.internal", "port": 5432, "protocol": "tcp"}
        ]
    }

    pr_ids = _run_pr_time(graph, "payment-api", PAYMENT_API_PATH, real_diff)
    mcp_ids = _run_mcp(graph, PAYMENT_API_PATH, evidence)

    assert "AR-CTRL-DB-BOUNDARY-001" in pr_ids, f"PR-time missed it: {pr_ids}"
    assert pr_ids == mcp_ids, (
        f"DRIFT — PR-time fired {pr_ids}, MCP fired {mcp_ids}; "
        f"the difference is {pr_ids ^ mcp_ids}"
    )


def test_parity_allowed_https_call(graph):
    """payment-api → card-data-service over HTTPS. Allowed by CALM.
    Both paths should fire NO rules.
    """
    real_diff = (
        f"diff --git a/{PAYMENT_API_PATH} b/{PAYMENT_API_PATH}\n"
        f"--- a/{PAYMENT_API_PATH}\n"
        f"+++ b/{PAYMENT_API_PATH}\n"
        "@@ -1,1 +1,3 @@\n"
        '+const url = "https://card-data-service.internal:443/api";\n'
    )
    evidence = {
        "calls_added": [
            {"target_host": "card-data-service.internal", "port": 443, "protocol": "https"}
        ]
    }

    pr_ids = _run_pr_time(graph, "payment-api", PAYMENT_API_PATH, real_diff)
    mcp_ids = _run_mcp(graph, PAYMENT_API_PATH, evidence)

    assert pr_ids == mcp_ids, f"DRIFT — PR-time={pr_ids} MCP={mcp_ids}"
    assert pr_ids == set(), f"unexpected verdict on the allowed path: {pr_ids}"


def test_parity_hardcoded_secret(graph):
    """A literal API key string. Should fire AR-CTRL-SECRET-001 (named
    credential) and AR-DIFF-008 (generic regex) on both paths.
    """
    secret_line = (
        'private static final String API_KEY = '
        '"sk_live_abc123def456ghi789jklmnop0qrstuv";'
    )
    real_diff = (
        f"diff --git a/{PAYMENT_API_PATH} b/{PAYMENT_API_PATH}\n"
        f"--- a/{PAYMENT_API_PATH}\n"
        f"+++ b/{PAYMENT_API_PATH}\n"
        "@@ -1,1 +1,3 @@\n"
        f"+{secret_line}\n"
    )
    evidence = {"code_lines_added": [secret_line]}

    pr_ids = _run_pr_time(graph, "payment-api", PAYMENT_API_PATH, real_diff)
    mcp_ids = _run_mcp(graph, PAYMENT_API_PATH, evidence)

    assert "AR-CTRL-SECRET-001" in pr_ids
    assert "AR-DIFF-008" in pr_ids
    assert pr_ids == mcp_ids, f"DRIFT — PR-time={pr_ids} MCP={mcp_ids}"


def test_parity_outbound_unknown_host(graph):
    """payment-api calls a host that's not on any CALM interface.
    Should fire AR-CTRL-OUTBOUND-001 on both paths.
    """
    real_diff = (
        f"diff --git a/{PAYMENT_API_PATH} b/{PAYMENT_API_PATH}\n"
        f"--- a/{PAYMENT_API_PATH}\n"
        f"+++ b/{PAYMENT_API_PATH}\n"
        "@@ -1,1 +1,3 @@\n"
        '+const url = "https://evil.example.com/data";\n'
    )
    evidence = {
        "calls_added": [
            {"target_host": "evil.example.com", "port": 443, "protocol": "https"}
        ]
    }

    pr_ids = _run_pr_time(graph, "payment-api", PAYMENT_API_PATH, real_diff)
    mcp_ids = _run_mcp(graph, PAYMENT_API_PATH, evidence)

    assert "AR-CTRL-OUTBOUND-001" in pr_ids, f"PR-time missed outbound: {pr_ids}"
    assert pr_ids == mcp_ids, f"DRIFT — PR-time={pr_ids} MCP={mcp_ids}"


def test_secrets_fire_on_every_governed_node_regardless_of_sensitivity(graph):
    """Phase 3d: the MCP sensitivity gate was removed because it caused
    PR/MCP divergence — PR-time always scanned every governed file but
    MCP was filtering by `review.sensitivity_controls`. Now both surfaces
    run secret detection on every file mapped to a node, sensitive or not.

    A secret committed to a non-PII node fires AR-CTRL-SECRET-001 +
    AR-DIFF-008 at MCP just like it does at PR-time. The agent gets the
    same answer the merge gate will give.
    """
    secret_line = (
        'const API_KEY = "sk_live_abc123def456ghi789jklmnop0qrstuv";'
    )
    non_pii_path = "services/card-data-service/src/Foo.java"
    evidence = {"code_lines_added": [secret_line]}

    response = check_run(graph, path=non_pii_path, evidence=evidence)
    rule_ids = {v.get("rule") for v in response.get("verdicts") or []}

    assert "AR-DIFF-008" in rule_ids, (
        f"Phase 3d: AR-DIFF-008 must fire on every governed file (was "
        f"sensitivity-gated, now isn't). Got: {rule_ids}"
    )


def test_secrets_also_fire_on_pii_nodes(graph):
    """Sanity: removing the gate didn't accidentally suppress findings on
    sensitive nodes either. Secrets fire here too.
    """
    secret_line = (
        'const API_KEY = "sk_live_abc123def456ghi789jklmnop0qrstuv";'
    )
    evidence = {"code_lines_added": [secret_line]}

    response = check_run(graph, path=PAYMENT_API_PATH, evidence=evidence)
    rule_ids = {v.get("rule") for v in response.get("verdicts") or []}

    assert "AR-DIFF-008" in rule_ids, (
        f"AR-DIFF-008 didn't fire on a sensitive node — that's a real "
        f"regression. Got: {rule_ids}"
    )


def test_authz_removal_fires_at_mcp_when_evidence_is_removed(graph):
    """Phase 3d: AR-CTRL-AUTHZ-001 fires only on `-` diff lines. Pre-3d,
    `evidence_to_diff` only synthesized `+` lines, so this rule was
    silently un-fireable at MCP — a real divergence from PR-time.

    Now `code_lines_removed` synthesizes `-` lines and the rule fires
    just like at PR-time.
    """
    real_diff = (
        f"diff --git a/{PAYMENT_API_PATH} b/{PAYMENT_API_PATH}\n"
        f"--- a/{PAYMENT_API_PATH}\n"
        f"+++ b/{PAYMENT_API_PATH}\n"
        "@@ -1,3 +1,1 @@\n"
        "-@PreAuthorize(\"hasRole('ADMIN')\")\n"
        "+public void doIt() {}\n"
    )
    evidence = {
        "code_lines_removed": ["@PreAuthorize(\"hasRole('ADMIN')\")"],
        "code_lines_added":   ["public void doIt() {}"],
    }

    pr_ids  = _run_pr_time(graph, "payment-api", PAYMENT_API_PATH, real_diff)
    mcp_ids = _run_mcp(graph, PAYMENT_API_PATH, evidence)

    assert "AR-CTRL-AUTHZ-001" in pr_ids, f"PR-time missed it: {pr_ids}"
    assert "AR-CTRL-AUTHZ-001" in mcp_ids, (
        f"MCP missed AR-CTRL-AUTHZ-001 — Wave 2 (code_lines_removed) is "
        f"broken. Got: {mcp_ids}"
    )


def test_translator_synthesizes_a_matching_diff(graph):
    """Direct translator test — the synthesized diff should make the
    PR-time validators fire the same rules as the equivalent real diff.

    This catches a class of drift the higher-level tests miss: cases
    where check_proposed_change happens to mask a translator gap (e.g.
    by also running a heuristic). It calls the translator first, then
    runs the validators on the synthesized output, and asserts the result
    matches the equivalent real diff.
    """
    evidence = {
        "calls_added": [
            {"target_host": "card-db.internal", "port": 5432, "protocol": "tcp"}
        ]
    }
    real_diff = (
        f"diff --git a/{PAYMENT_API_PATH} b/{PAYMENT_API_PATH}\n"
        f"--- a/{PAYMENT_API_PATH}\n"
        f"+++ b/{PAYMENT_API_PATH}\n"
        "@@ -1,1 +1,3 @@\n"
        '+String url = "jdbc:postgresql://card-db.internal:5432/db";\n'
    )

    synth_diff = evidence_to_diff(PAYMENT_API_PATH, evidence)
    real_ids = _run_pr_time(graph, "payment-api", PAYMENT_API_PATH, real_diff)
    synth_ids = _run_pr_time(graph, "payment-api", PAYMENT_API_PATH, synth_diff)

    assert real_ids == synth_ids, (
        f"translator gap — real diff fires {real_ids} but synthesized "
        f"diff fires {synth_ids}\nsynth_diff was:\n{synth_diff}"
    )
