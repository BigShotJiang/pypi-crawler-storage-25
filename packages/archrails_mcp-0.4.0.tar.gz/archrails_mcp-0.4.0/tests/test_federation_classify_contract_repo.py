"""
Tests for the federation_classify fix that lets a system-of-systems
contract repo emit reference rows for the cross-repo edges it declares.

Before the fix, classify_per_file_arch skipped any relationship whose
source node's metadata.repository didn't match the current repo. That
meant a "contract" CALM whose nodes all carry repository pointers to
team repos couldn't emit any of its declared cross-repo edges except
those rooted at metadata-less actor nodes — leaving the federated
graph nearly empty.

After the fix, the contract repo emits all its cross-repo edges. If
the team repo also declares the same edge, put_item is content-
idempotent (same PK/SK).
"""
from __future__ import annotations

import os
import sys

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))

from shared.calm.federation_classify import classify_per_file_arch


CONTRACT_REPO = "https://github.com/archrails/traderx-architecture"
FRONTEND_REPO = "https://github.com/archrails/traderx-frontend"
ACCOUNTS_REPO = "https://github.com/archrails/traderx-accounts"


def _file_arch(nodes, relationships, *, file_path="architecture/contract.calm.json"):
    """Build the per_file_arch shape classify_per_file_arch consumes:
    {file_path: {nodes: {nid: meta}, relationships: [...], flows: []}}."""
    return {
        file_path: {
            "nodes": {n["unique-id"]: n for n in nodes},
            "relationships": relationships,
            "flows": [],
        }
    }


def test_contract_repo_emits_cross_repo_edge_when_source_belongs_to_other_repo():
    """The bug we're fixing: web-gui-account-service has source=web-gui
    (frontend repo, not the contract repo). Old code skipped it; new
    code emits it from the contract."""
    nodes = [
        {
            "unique-id": "web-gui",
            "node-type": "webclient",
            "metadata":  {"repository": FRONTEND_REPO},
        },
        {
            "unique-id": "account-service",
            "node-type": "service",
            "metadata":  {"repository": ACCOUNTS_REPO},
        },
    ]
    relationships = [
        {
            "unique-id": "web-gui-account-service",
            "relationship-type": {
                "connects": {
                    "source":      {"node": "web-gui"},
                    "destination": {"node": "account-service"},
                },
            },
        },
    ]
    pfa = _file_arch(nodes, relationships)

    (_def_urls, _req_urls, owned, externals,
     _unowned, _local_rels, _arch_ctrls) = classify_per_file_arch(
        repo_canonical=CONTRACT_REPO,
        per_file_arch=pfa,
    )

    # Contract owns no service nodes — every node points elsewhere.
    assert owned == []
    # The cross-repo edge must be emitted as an external stub.
    stub_keys = {(s["source_node_id"], s["target_node_id"]) for s in externals}
    assert ("web-gui", "account-service") in stub_keys
    # Critical for the contract pattern: source_repo_url on the stub
    # must point at the SOURCE NODE'S owning repo (web-gui in
    # traderx-frontend), not the contract repo doing the bootstrap.
    # Without this, federation rows get attributed to the wrong source
    # repo and downstream cleanup / dedup logic misses duplicates.
    web_gui_stub = next(s for s in externals if s["source_node_id"] == "web-gui")
    assert web_gui_stub["source_repo_url"] == FRONTEND_REPO


def test_contract_repo_with_actor_owned_node_still_emits_other_edges():
    """The contract owns `trader` (no metadata.repository → defaults
    to current repo). Even with that local ownership, the contract
    must still emit cross-repo edges sourced from other repos'
    boundary nodes."""
    nodes = [
        {"unique-id": "trader", "node-type": "actor"},
        {
            "unique-id": "web-gui",
            "node-type": "webclient",
            "metadata":  {"repository": FRONTEND_REPO},
        },
        {
            "unique-id": "account-service",
            "node-type": "service",
            "metadata":  {"repository": ACCOUNTS_REPO},
        },
    ]
    relationships = [
        {
            "unique-id": "trader-web-gui",
            "relationship-type": {"interacts": {"actor": "trader", "nodes": ["web-gui"]}},
        },
        {
            "unique-id": "web-gui-account-service",
            "relationship-type": {
                "connects": {
                    "source":      {"node": "web-gui"},
                    "destination": {"node": "account-service"},
                },
            },
        },
    ]
    pfa = _file_arch(nodes, relationships)

    (_def_urls, _req_urls, owned, externals,
     _unowned, _local_rels, _arch_ctrls) = classify_per_file_arch(
        repo_canonical=CONTRACT_REPO,
        per_file_arch=pfa,
    )

    owned_ids = {nid for nid, _meta in owned}
    assert "trader" in owned_ids

    stub_keys = {(s["source_node_id"], s["target_node_id"]) for s in externals}
    # Both edges must surface — the actor-rooted edge AND the web-gui-rooted edge.
    assert ("trader", "web-gui") in stub_keys
    assert ("web-gui", "account-service") in stub_keys


def test_local_relationship_emitted_only_when_controls_present():
    """Same-repo edges only become local_relationship rows when they
    carry an inline `controls` block — the cleanup logic in
    process_calm_config relies on this so a PR that adds/removes
    controls correctly reflects in the federation table."""
    nodes = [
        {"unique-id": "a", "metadata": {"repository": FRONTEND_REPO}},
        {"unique-id": "b", "metadata": {"repository": FRONTEND_REPO}},
        {"unique-id": "c", "metadata": {"repository": FRONTEND_REPO}},
    ]
    relationships = [
        # a→b: no controls → not a local_relationship row
        {
            "unique-id": "a-b",
            "relationship-type": {
                "connects": {"source": {"node": "a"}, "destination": {"node": "b"}},
            },
        },
        # b→c: with controls → IS a local_relationship row
        {
            "unique-id": "b-c",
            "relationship-type": {
                "connects": {"source": {"node": "b"}, "destination": {"node": "c"}},
            },
            "controls": {"encryption": {"required": True}},
        },
    ]
    pfa = _file_arch(nodes, relationships)
    (_def_urls, _req_urls, _owned, _externals,
     _unowned, local_rels, _arch_ctrls) = classify_per_file_arch(
        repo_canonical=FRONTEND_REPO,
        per_file_arch=pfa,
    )
    rel_ids = {r["relationship_id"] for r in local_rels}
    assert "b-c" in rel_ids       # has controls → tracked
    assert "a-b" not in rel_ids   # no controls → not tracked


def test_team_repo_still_emits_only_its_own_outbound_edges():
    """The fix must not regress the common case: a normal team repo
    bootstrapping should continue to emit edges sourced from its OWN
    nodes (web-gui), not from other repos' nodes (which would be
    duplicates or wrong)."""
    nodes = [
        {
            "unique-id": "web-gui",
            "node-type": "webclient",
            "metadata":  {"repository": FRONTEND_REPO},
        },
        {
            "unique-id": "account-service",
            "node-type": "service",
            "metadata":  {"repository": ACCOUNTS_REPO},
        },
    ]
    relationships = [
        {
            "unique-id": "web-gui-account-service",
            "relationship-type": {
                "connects": {
                    "source":      {"node": "web-gui"},
                    "destination": {"node": "account-service"},
                },
            },
        },
    ]
    pfa = _file_arch(nodes, relationships, file_path="architecture/frontend.calm.json")

    # Bootstrap from FRONTEND_REPO — web-gui is locally owned.
    (_def_urls, _req_urls, owned, externals,
     _unowned, _local_rels, _arch_ctrls) = classify_per_file_arch(
        repo_canonical=FRONTEND_REPO,
        per_file_arch=pfa,
    )

    owned_ids = {nid for nid, _meta in owned}
    assert owned_ids == {"web-gui"}

    stub_keys = {(s["source_node_id"], s["target_node_id"]) for s in externals}
    assert ("web-gui", "account-service") in stub_keys
