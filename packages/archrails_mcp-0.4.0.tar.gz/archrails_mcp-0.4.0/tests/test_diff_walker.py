"""
Tests for shared/calm/validators/diff_walker.walk_added_lines.

The helper is the foundation for inline-comment placement across all
diff-walking validators. Bugs in line counting silently degrade every
rule's ability to attach an inline review comment, so the math gets
pinned with explicit fixtures rather than tested through validators.
"""
from __future__ import annotations

import os
import sys

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))

from shared.calm.validators.diff_walker import walk_added_lines


def test_simple_addition():
    diff = (
        "+++ b/services/web-gui/src/index.ts\n"
        "@@ -0,0 +1,3 @@\n"
        "+import x from 'y';\n"
        "+const z = 1;\n"
        "+export { z };\n"
    )
    out = list(walk_added_lines(diff))
    assert out == [
        ("services/web-gui/src/index.ts", 1, "import x from 'y';"),
        ("services/web-gui/src/index.ts", 2, "const z = 1;"),
        ("services/web-gui/src/index.ts", 3, "export { z };"),
    ]


def test_context_lines_advance_counter():
    """Context lines (` ` prefix) are present in both files and must
    advance the new-file counter so the next `+` lands on the right
    line. Without this, a `+` after 5 context lines would report line
    1 instead of line 6."""
    diff = (
        "+++ b/file.py\n"
        "@@ -1,5 +1,6 @@\n"
        " line1\n"
        " line2\n"
        " line3\n"
        "+inserted_at_line_4\n"
        " line5\n"
        " line6\n"
    )
    out = list(walk_added_lines(diff))
    assert out == [("file.py", 4, "inserted_at_line_4")]


def test_removed_lines_do_not_advance_counter():
    """`-` (removed) lines are present in the OLD file only and must
    NOT advance the new-file counter. Without this guard, every `-`
    would push subsequent `+` line numbers off by one for each removal."""
    diff = (
        "+++ b/file.py\n"
        "@@ -1,5 +1,3 @@\n"
        " keep1\n"
        "-removed1\n"
        "-removed2\n"
        "+added_at_line_2\n"
        " keep_end\n"
    )
    out = list(walk_added_lines(diff))
    assert out == [("file.py", 2, "added_at_line_2")]


def test_hunk_header_resets_counter():
    """A second `@@ ... +C @@` header resets the counter to C-1 so the
    next added line lands on C, not on (last position + 1)."""
    diff = (
        "+++ b/file.py\n"
        "@@ -1,1 +1,1 @@\n"
        "+first_at_line_1\n"
        "@@ -50,0 +100,1 @@\n"
        "+far_at_line_100\n"
    )
    out = list(walk_added_lines(diff))
    assert out == [
        ("file.py", 1, "first_at_line_1"),
        ("file.py", 100, "far_at_line_100"),
    ]


def test_file_change_resets_state():
    """Switching files via a new `+++ b/...` header must reset the
    counter and rebind `current_file`. Otherwise lines in the second
    file would inherit the line numbers of the first."""
    diff = (
        "+++ b/file_a.py\n"
        "@@ -0,0 +1,1 @@\n"
        "+a_line_1\n"
        "+++ b/file_b.py\n"
        "@@ -0,0 +1,1 @@\n"
        "+b_line_1\n"
    )
    out = list(walk_added_lines(diff))
    assert out == [
        ("file_a.py", 1, "a_line_1"),
        ("file_b.py", 1, "b_line_1"),
    ]


def test_strips_b_prefix():
    """Git diff `+++ b/path` — strip the `b/` prefix so consumers
    don't have to."""
    diff = "+++ b/services/foo.ts\n@@ -0,0 +1,1 @@\n+hi\n"
    out = list(walk_added_lines(diff))
    assert out[0][0] == "services/foo.ts"


def test_handles_no_b_prefix_gracefully():
    """Some tools emit `+++ path` without the `b/` prefix. Don't
    accidentally chop the first two characters."""
    diff = "+++ services/foo.ts\n@@ -0,0 +1,1 @@\n+hi\n"
    out = list(walk_added_lines(diff))
    assert out[0][0] == "services/foo.ts"


def test_empty_diff_yields_nothing():
    assert list(walk_added_lines("")) == []
    assert list(walk_added_lines(None)) == []   # type: ignore


def test_added_line_before_hunk_header_skipped():
    """Defensive: a `+` line before any hunk header has no reliable
    line number. Skip rather than emit a 0/garbage value."""
    diff = "+++ b/file.py\n+orphan_no_hunk\n@@ -0,0 +1,1 @@\n+real_at_1\n"
    out = list(walk_added_lines(diff))
    assert out == [("file.py", 1, "real_at_1")]


def test_single_line_hunk_no_count_suffix():
    """`@@ -3 +5 @@` is the no-comma form when both ranges are length 1."""
    diff = "+++ b/file.py\n@@ -3 +5 @@\n+at_line_5\n"
    out = list(walk_added_lines(diff))
    assert out == [("file.py", 5, "at_line_5")]
