"""Tests for the two net-new Phase 3c validators:
  - AR-CTRL-TIMEOUT-MISSING-001 (architectural_timeout_validator)
  - AR-CTRL-RETRY-MISSING-001  (architectural_retry_validator)

Both fire only when the CALM relationship explicitly declares a
resilience requirement (controls.timeout / controls.retry / metadata).
Tests cover: fires when expected, suppressed when timeout/retry present,
zero noise on edges without resilience declarations.
"""
from __future__ import annotations

import sys
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from shared.calm.validators.architectural_timeout_validator import (
    preflight_architectural_timeout_missing,
)
from shared.calm.validators.architectural_retry_validator import (
    preflight_architectural_retry_missing,
)


# ── Helpers ─────────────────────────────────────────────────────────────────

def _graph(*, edge_controls: dict | None = None) -> dict:
    """Minimal graph: payment-api → vendor-api with optional controls
    on the edge."""
    edge: dict = {
        "from": "payment-api",
        "to":   "vendor-api",
        "type": "connects",
    }
    if edge_controls:
        edge["controls"] = edge_controls
    return {
        "nodes": [
            {"unique-id": "payment-api", "node-type": "service"},
            {
                "unique-id": "vendor-api",
                "node-type":  "service",
                "interfaces": [{"unique-id": "rest", "host": "vendor.example.com"}],
            },
        ],
        "edges": [edge],
    }


def _diff(file_path: str, lines: list[str]) -> str:
    body = "\n".join(f"+{ln}" for ln in lines)
    return (
        f"diff --git a/{file_path} b/{file_path}\n"
        f"--- a/{file_path}\n+++ b/{file_path}\n"
        f"@@ -1,1 +1,{len(lines)} @@\n"
        f"{body}\n"
    )


_NODE_MAP = {"payment-api": ["src/payment.py"]}


# ── AR-CTRL-TIMEOUT-MISSING-001 ─────────────────────────────────────────────

def test_timeout_fires_on_resilient_edge_without_timeout():
    g = _graph(edge_controls={"timeout": {"deadline_ms": 5000}})
    diff = _diff("src/payment.py", [
        'requests.get("https://vendor.example.com/api/v1/charge")',
    ])
    v = preflight_architectural_timeout_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert len(v) == 1
    assert v[0]["rule_id"] == "AR-CTRL-TIMEOUT-MISSING-001"
    assert v[0]["target_node"] == "vendor-api"
    assert "vendor.example.com" in v[0]["evidence"]


def test_timeout_suppressed_when_timeout_kwarg_present():
    g = _graph(edge_controls={"timeout": {"deadline_ms": 5000}})
    diff = _diff("src/payment.py", [
        'requests.get("https://vendor.example.com/api/v1/charge", timeout=5)',
    ])
    v = preflight_architectural_timeout_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert v == []


def test_timeout_suppressed_when_js_timeout_object_present():
    g = _graph(edge_controls={"resilient": True})
    diff = _diff("src/charge.ts", [
        'await axios.get("https://vendor.example.com/api/v1/charge", { timeout: 5000 });',
    ])
    nm = {"payment-api": ["src/charge.ts"]}
    v = preflight_architectural_timeout_missing(graph=g, node_map=nm, diff=diff)
    assert v == []


def test_timeout_suppressed_when_fetch_uses_abort_signal():
    g = _graph(edge_controls={"resilient": True})
    diff = _diff("src/charge.ts", [
        'await fetch("https://vendor.example.com/api/v1/charge", { signal: AbortSignal.timeout(5000) });',
    ])
    nm = {"payment-api": ["src/charge.ts"]}
    v = preflight_architectural_timeout_missing(graph=g, node_map=nm, diff=diff)
    assert v == []


def test_timeout_silent_on_edge_without_resilience_declaration():
    """Zero-noise contract: edges without any timeout / resilient signal
    in CALM should produce no findings, even on bare requests.get."""
    g = _graph(edge_controls=None)  # no controls block at all
    diff = _diff("src/payment.py", [
        'requests.get("https://vendor.example.com/api/v1/charge")',
    ])
    v = preflight_architectural_timeout_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert v == []


def test_timeout_silent_on_unrelated_host():
    """Calls to hosts not on resilient edges aren't this rule's concern."""
    g = _graph(edge_controls={"timeout": {"deadline_ms": 5000}})
    diff = _diff("src/payment.py", [
        'requests.get("https://some-other-host.com/foo")',
    ])
    v = preflight_architectural_timeout_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert v == []


def test_timeout_metadata_signal_also_works():
    """Resilience under metadata (not just controls) also triggers the gate."""
    g = _graph()
    g["edges"][0]["metadata"] = {"timeout-ms": 5000}
    diff = _diff("src/payment.py", [
        'requests.get("https://vendor.example.com/api/v1/charge")',
    ])
    v = preflight_architectural_timeout_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert len(v) == 1


# ── AR-CTRL-RETRY-MISSING-001 ───────────────────────────────────────────────

def test_retry_fires_on_resilient_edge_without_retry():
    g = _graph(edge_controls={"retry": {"max_attempts": 3}})
    diff = _diff("src/payment.py", [
        'requests.get("https://vendor.example.com/api/v1/charge", timeout=5)',
    ])
    v = preflight_architectural_retry_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert len(v) == 1
    assert v[0]["rule_id"] == "AR-CTRL-RETRY-MISSING-001"
    assert v[0]["target_node"] == "vendor-api"


def test_retry_suppressed_when_tenacity_decorator_present():
    g = _graph(edge_controls={"retry": {"max_attempts": 3}})
    diff = _diff("src/payment.py", [
        'from tenacity import retry, wait_exponential',
        '',
        '@retry(wait=wait_exponential())',
        'def charge():',
        '    requests.get("https://vendor.example.com/api/v1/charge", timeout=5)',
    ])
    v = preflight_architectural_retry_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert v == []


def test_retry_suppressed_when_axios_retry_imported():
    g = _graph(edge_controls={"retry": {"max_attempts": 3}})
    diff = _diff("src/charge.ts", [
        'import axiosRetry from "axios-retry";',
        'axiosRetry(axios, { retries: 3 });',
        'await axios.get("https://vendor.example.com/api/v1/charge", { timeout: 5000 });',
    ])
    nm = {"payment-api": ["src/charge.ts"]}
    v = preflight_architectural_retry_missing(graph=g, node_map=nm, diff=diff)
    assert v == []


def test_retry_silent_on_edge_without_retry_declaration():
    g = _graph(edge_controls={"timeout": {"deadline_ms": 5000}})  # timeout, not retry
    diff = _diff("src/payment.py", [
        'requests.get("https://vendor.example.com/api/v1/charge", timeout=5)',
    ])
    # `timeout` keyword IS picked up as resilience signal — both validators
    # share keyword sets — so retry will fire too. That's intentional: a
    # "resilient" requirement covers both. To assert ONLY retry-specific
    # behavior, use a non-resilience edge:
    g_clean = _graph(edge_controls={"caching": {"ttl_s": 60}})
    v = preflight_architectural_retry_missing(graph=g_clean, node_map=_NODE_MAP, diff=diff)
    assert v == []


def test_retry_severity_escalates_for_externally_reachable_target():
    g = _graph(edge_controls={"retry": True})
    # Mark the target as externally reachable (has internet-facing interface)
    g["nodes"][1]["interfaces"][0]["host"] = "vendor.example.com"
    g["nodes"][1]["node-type"] = "api-gateway"  # external by type
    diff = _diff("src/payment.py", [
        'requests.get("https://vendor.example.com/api/v1/charge", timeout=5)',
    ])
    v = preflight_architectural_retry_missing(graph=g, node_map=_NODE_MAP, diff=diff)
    assert len(v) == 1
    assert v[0]["severity"] == "error"
