"""
tests/test_graph_entity_staging.py
----------------------------------
Tests for shared/calm/graph_entity_staging.stage_graph_diff — the
Phase A bridge that walks today's _compute_graph_diff output and
writes equivalent staged rows into ArchRailsGraphEntities.

Mocks both the underlying graph_entities_store calls so the test runs
without DDB / moto.
"""
from __future__ import annotations

import os
import sys
from unittest.mock import MagicMock, patch

import pytest

os.environ.setdefault("AWS_DEFAULT_REGION", "us-east-2")
os.environ.setdefault("AWS_ACCESS_KEY_ID", "test")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "test")
os.environ.setdefault("ARCHRAILS_GRAPH_ENTITIES_TABLE", "ArchRailsGraphEntitiesTest")

this_dir = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(this_dir, ".."))  # repo root

from shared.calm import graph_entity_staging as ges_stage  # noqa: E402
from shared.aws.dynamo import graph_entities_store as ges  # noqa: E402


TENANT = "TENANT#github#github.com#42"
REPO_SK = "REPO#github.com#example/payments-service"
PR = "57"


def _empty_diff() -> dict:
    return {
        "added_nodes": [], "removed_nodes": [],
        "added_edges": [], "removed_edges": [],
        "added_flows": [], "removed_flows": [],
    }


# ---------------------------------------------------------------------------
# Adds
# ---------------------------------------------------------------------------

def test_stage_graph_diff_emits_put_for_added_node():
    diff = _empty_diff()
    diff["added_nodes"] = [
        {
            "unique-id": "payment-api",
            "type":      "service",
            "metadata":  {"path": "services/payment/Service.java",
                           "owned_by": "team-payments"},
        },
    ]

    with patch.object(ges, "get_canonical_row", return_value=None) as get_row, \
         patch.object(ges, "put_staged_entity") as put_staged:
        entries = ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    assert len(entries) == 1
    e = entries[0]
    assert e["op"]           == "put"
    assert e["canonical_sk"] == "NODE#payment-api"
    assert e["staged_sk"]    == "STAGED#NODE#payment-api#57"

    # put_staged_entity called once with op_type="put" and prior_payload_hash=None
    # (because get_canonical_row returned None — net-new add).
    put_staged.assert_called_once()
    kwargs = put_staged.call_args.kwargs
    assert kwargs["canonical_sk"]       == "NODE#payment-api"
    assert kwargs["entity_type"]        == ges.ENTITY_NODE
    assert kwargs["op_type"]            == "put"
    assert kwargs["target_path"]        == "services/payment/Service.java"
    assert kwargs["owner"]              == "team-payments"
    assert kwargs["prior_payload_hash"] is None


def test_stage_graph_diff_captures_prior_hash_on_modify():
    """A node already in live with a different payload → prior_payload_hash
    is captured from the canonical row so the merge-time conflict check
    can detect concurrent modification."""
    diff = _empty_diff()
    diff["added_nodes"] = [{"unique-id": "payment-api", "type": "service"}]

    fake_live = {"payload_hash": "sha256:original"}
    with patch.object(ges, "get_canonical_row", return_value=fake_live), \
         patch.object(ges, "put_staged_entity") as put_staged:
        ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    assert put_staged.call_args.kwargs["prior_payload_hash"] == "sha256:original"


def test_stage_graph_diff_emits_tombstone_for_removed_node():
    diff = _empty_diff()
    diff["removed_nodes"] = [{"unique-id": "deprecated-svc"}]

    fake_live = {"payload_hash": "sha256:abc"}
    with patch.object(ges, "get_canonical_row", return_value=fake_live), \
         patch.object(ges, "put_staged_entity") as put_staged:
        entries = ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    assert len(entries) == 1
    e = entries[0]
    assert e["op"]           == "tombstone"
    assert e["canonical_sk"] == "NODE#deprecated-svc"

    kwargs = put_staged.call_args.kwargs
    assert kwargs["op_type"]            == "tombstone"
    assert kwargs["payload"]            == {}  # tombstones carry no payload
    assert kwargs["prior_payload_hash"] == "sha256:abc"


def test_stage_graph_diff_skips_tombstone_when_canonical_already_gone():
    """If the canonical row doesn't exist, another PR removed it first.
    No-op tombstone (don't write a staging row, don't add a manifest entry)."""
    diff = _empty_diff()
    diff["removed_nodes"] = [{"unique-id": "deprecated-svc"}]

    with patch.object(ges, "get_canonical_row", return_value=None), \
         patch.object(ges, "put_staged_entity") as put_staged:
        entries = ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    assert entries == []
    put_staged.assert_not_called()


def test_stage_graph_diff_handles_edges_and_flows():
    diff = _empty_diff()
    diff["added_edges"] = [
        {"id": "edge-1", "type": "connects", "from": "a", "to": "b"},
    ]
    diff["added_flows"] = [
        {"unique-id": "order-flow", "name": "Order processing"},
    ]

    with patch.object(ges, "get_canonical_row", return_value=None), \
         patch.object(ges, "put_staged_entity") as put_staged:
        entries = ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    canonical_sks = {e["canonical_sk"] for e in entries}
    assert canonical_sks == {"EDGE#edge-1", "FLOW#order-flow"}
    # 2 entities → 2 put_staged_entity calls.
    assert put_staged.call_count == 2


def test_stage_graph_diff_skips_entities_without_unique_ids():
    """Anonymous flows, nodes without unique-id, and edges with no key
    are silently dropped — same behavior as today's _flow_key/_node_key
    helpers in process_calm_config."""
    diff = _empty_diff()
    diff["added_nodes"] = [{"type": "service"}]              # no unique-id
    diff["added_flows"] = [{"name": "anon"}]                 # no unique-id
    diff["added_edges"] = [{}]                               # no key extractable
    # The third entry — empty edge dict — does still produce a key
    # ("EDGE#||" since type/from/to all default to ""). That's a v1
    # behavior we mirror; if process_calm_config's _edge_key emits
    # `||`, so do we.

    with patch.object(ges, "get_canonical_row", return_value=None), \
         patch.object(ges, "put_staged_entity") as put_staged:
        entries = ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    canonical_sks = [e["canonical_sk"] for e in entries]
    # Node and flow without unique-id are dropped; the empty-edge mirrors
    # v1 behavior and produces a degenerate but consistent key.
    assert "NODE#" not in canonical_sks
    assert "FLOW#" not in canonical_sks
    assert all(sk.startswith(("NODE#", "EDGE#", "FLOW#")) for sk in canonical_sks)


def test_stage_graph_diff_per_entity_failure_does_not_break_run():
    """One bad row shouldn't sink the whole staging pass. The good rows
    still land in the manifest; the bad one is logged and skipped."""
    diff = _empty_diff()
    diff["added_nodes"] = [
        {"unique-id": "good"},
        {"unique-id": "bad"},
    ]

    def fake_put(canonical_sk, **kwargs):
        if canonical_sk == "NODE#bad":
            raise RuntimeError("simulated DDB failure")
        return ("pk", canonical_sk)

    with patch.object(ges, "get_canonical_row", return_value=None), \
         patch.object(ges, "put_staged_entity",
                      side_effect=lambda **kw: fake_put(**kw)):
        entries = ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    canonical_sks = {e["canonical_sk"] for e in entries}
    assert canonical_sks == {"NODE#good"}


def test_stage_graph_diff_extracts_controls_idx():
    """Node payload's `controls` block → controls_idx on the staged row,
    populated with requirement-url / control-id values for the dashboard's
    'controls applied here' filter."""
    diff = _empty_diff()
    diff["added_nodes"] = [
        {
            "unique-id": "payment-api",
            "controls":  {
                "security": {
                    "requirements": [
                        {"requirement-url": "auth-required.json"},
                        {"control-id": "pci-no-card-logging"},
                    ],
                },
            },
        },
    ]

    with patch.object(ges, "get_canonical_row", return_value=None), \
         patch.object(ges, "put_staged_entity") as put_staged:
        ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=diff,
        )

    idx = put_staged.call_args.kwargs["controls_idx"]
    assert "auth-required.json" in idx
    assert "pci-no-card-logging" in idx


def test_empty_diff_produces_no_entries():
    with patch.object(ges, "get_canonical_row") as get_row, \
         patch.object(ges, "put_staged_entity") as put_staged:
        entries = ges_stage.stage_graph_diff(
            tenant_pk=TENANT, repo_sk=REPO_SK,
            change_number=PR, graph_diff=_empty_diff(),
        )

    assert entries == []
    get_row.assert_not_called()
    put_staged.assert_not_called()
