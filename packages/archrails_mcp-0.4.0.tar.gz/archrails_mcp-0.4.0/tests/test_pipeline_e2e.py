"""
test_pipeline_e2e.py
---------------------
End-to-end integration tests for the full ArchRails Step Function pipeline.

Simulates the full event chain through all 5 lambdas:
  FetchPullRequestDiff → FetchArchRailsConfig → CalmParserLambda
    → ValidateArchitecture → PublishReviewResult

Mocking strategy:
  - FetchPullRequestDiff, FetchArchRailsConfig, CalmParserLambda run their real
    lambda_handler and mock only their external I/O boundary (GitHub API calls,
    providers.mono.handler.handler).
  - ValidateArchitecture and PublishReviewResult mock lambda_handler itself.
    Their internals have enough surface area (dynamodb_module, _fetch_payload_from_s3,
    _run_validation, post_pr_review, post_review_with_inline_comments, ...) that
    stubbing each boundary produces brittle tests. The pipeline contract tests
    only need their outputs to flow through, not to exercise their internals —
    those belong in their own unit tests.

Run with:
  pytest tests/test_pipeline_e2e.py -v -s
"""

import importlib
import json
import os
import sys
from unittest.mock import MagicMock, patch

# ── env vars (must be set before any lambda module is imported) ──────────────
os.environ.setdefault("AWS_DEFAULT_REGION", "us-east-2")
os.environ.setdefault("AWS_ACCESS_KEY_ID", "test")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "test")
os.environ.setdefault("ARCHRAILS_TABLE", "test-table")
os.environ.setdefault("PR_VALIDATION_TABLE", "test-pr-validation-table")
os.environ.setdefault("SCHEMA_VERSION", "1")
os.environ.setdefault("ARCHRAILS_CONFIG_BUCKET", "test-bucket")
os.environ.setdefault("GITHUB_TOKEN_SECRET_NAME", "test-github-token")
os.environ.setdefault("GITLAB_TOKEN_SECRET_NAME", "test-gitlab-token")
os.environ.setdefault("GITLAB_TOKEN_BEARER", "false")
os.environ.setdefault("BEDROCK_MODEL_ID", "anthropic.claude-3-sonnet-20240229-v1:0")
os.environ.setdefault("INLINE_MIN_SEVERITY", "medium")
os.environ.setdefault("MAX_INLINE_COMMENTS", "10")
os.environ.setdefault("USE_REVIEW_COMMENTS_API", "true")
os.environ.setdefault("TENANT_PROVISIONING_TABLE", "test-provisioning-table")
os.environ.setdefault("GITHUB_APP_ID", "12345")
os.environ.setdefault("GITHUB_APP_PRIVATE_KEY_PEM", "test-pem")

# ── repo root on sys.path for shared.* imports ───────────────────────────────
_REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

# ── Lambda directory map ─────────────────────────────────────────────────────
_LAMBDA_DIRS = {
    "FetchPullRequestDiff": "fetch_pr_diff",
    "FetchArchRailsConfig": "fetch_archrails_config",
    "CalmParserLambda":     "process_calm_config",
    "ValidateArchitecture": "validate_architecture",
    "PublishReviewResult":  "publish_review_result",
}


def _load(module_name: str):
    """
    Load a lambda module with its own directory at the front of sys.path.

    Each lambda has its own core/config.py. Without this, Python reuses
    whichever `core` package it cached first (e.g. webhook_router/core)
    for every subsequent lambda.
    """
    lambda_path = os.path.join(_REPO_ROOT, _LAMBDA_DIRS[module_name])

    if lambda_path in sys.path:
        sys.path.remove(lambda_path)
    sys.path.insert(0, lambda_path)

    for key in list(sys.modules.keys()):
        if key == "core" or key.startswith("core."):
            del sys.modules[key]

    if module_name in sys.modules:
        del sys.modules[module_name]

    return importlib.import_module(module_name)


# ═══════════════════════════════════════════════════════════════════════════════
# Shared fixtures
# ═══════════════════════════════════════════════════════════════════════════════

# Monorepo-shaped config — SINGLE mode was removed from the lambdas.
MONOREPO_CONFIG_YAML = """
version: 1
governance:
  provider: calm
  sources:
    - id: orders
      file: services/orders/.calm/architecture.json
      paths:
        - services/orders/
      owned_by: orders-team
mapping:
  - path: services/orders/
    node: service-orders
review:
  enforce_governance: true
  comment_mode: inline
""".strip()

ARCHRAILS_CONFIG_YAML = MONOREPO_CONFIG_YAML  # alias for readability below

CALM_CONTENT = json.dumps({
    "$schema": "https://calm.finos.org/release/1.2/meta/calm.json",
    "nodes": [
        {"unique-id": "service-orders", "name": "Orders Service", "node-type": "service",
         "metadata": {"owner": "orders-team"}}
    ],
    "relationships": [],
})

WEBHOOK_OUTPUT = {
    "provider":             "github",
    "host":                 "github.com",
    "tenant_pk":            "TENANT#github#github.com#12345",
    "repo_sk":              "REPO#99999",
    "repo":                 "owner/my-repo",
    "repository_id":        99999,
    "sha":                  "abc123",
    "change_number":        42,
    "installation_id":      "12345",
    "action":               "opened",
    "delivery_id":          "delivery-abc",
    "architecture_pattern": "mvvm",
}

DIFF_TEXT = (
    "--- a/src/orders/handler.py\n"
    "+++ b/src/orders/handler.py\n"
    "@@ -1,3 +1,4 @@\n"
    " import os\n"
    "+import requests\n"
    " def handle(): pass\n"
)

CALM_PARSER_RESULT = {
    "calm_graph_s3_uri": "s3://test-bucket/tenant/repo/graph.json",
    "calm_graph_hash":   "abc123hash",
    "s3": {"graph_uri": "s3://test-bucket/tenant/repo/graph.json"},
}

VALIDATION_EVENT_EXTRAS = {
    "validation_status": "success",
    "validation_result": {
        "status": "pass",
        "summary": "Looks good.",
        "score": 90,
        "pattern_validated": "mvvm",
        "issues": [],
        "recommendations": [],
        "positive_aspects": ["Clean dependency direction"],
        "context_chunks_used": 0,
        "architecture_detection": {
            "detected": "mvvm",
            "confidence": "configured",
            "was_provided": True,
            "secondary_patterns": [],
            "reasoning": "From config",
        },
    },
}

PUBLISH_EVENT_EXTRAS = {
    "publish_status": "success",
    "head_sha":       "deadbeef",
}


# ═══════════════════════════════════════════════════════════════════════════════
# Pipeline runner helpers
# ═══════════════════════════════════════════════════════════════════════════════

EXPECTED_DIFF_S3_URI = "s3://test-bucket/fake/diff.txt"
EXPECTED_CALM_SOURCES_S3_URI = "s3://test-bucket/fake/calm_sources.json"
EXPECTED_INTERFACE_SCHEMAS_S3_URI = "s3://test-bucket/fake/interface_schemas.json"


def _run_fetch_pr_diff(event: dict, config_in_pr: bool = True) -> dict:
    mod = _load("FetchPullRequestDiff")

    github_files = [{"filename": "src/orders/handler.py", "status": "modified"}]
    if config_in_pr:
        github_files.append({"filename": ".archrails/config.yml", "status": "modified"})

    pr_meta = {
        "title": "Test PR",
        "body": "Test description",
        "number": 42,
        "head": {"sha": "deadbeef", "ref": "feature-branch"},
        "base": {"ref": "main"},
    }

    gh_handler = sys.modules["core.providers.github.handler"]

    # Mock put_pr_diff so the test doesn't need a real S3. The fn normally
    # uploads the diff and returns its s3://... URI; we just echo a fixture.
    with patch.object(mod, "get_secret_key", return_value="gh-token"), \
         patch.object(mod, "fetch_pr_metadata_github", return_value=pr_meta), \
         patch.object(mod, "fetch_pr_diff_github", return_value=DIFF_TEXT), \
         patch.object(mod, "fetch_pr_files_github", return_value=github_files), \
         patch.object(mod, "put_pr_diff", return_value=EXPECTED_DIFF_S3_URI):
        return mod.lambda_handler(event, None)


def _run_fetch_pr_diff_no_config(event: dict) -> dict:
    return _run_fetch_pr_diff(event, config_in_pr=False)


def _run_fetch_archrails_config(event: dict, calm_content: str | None = None,
                                config_yaml: str = ARCHRAILS_CONFIG_YAML,
                                bootstrapped: bool = True) -> dict:
    mod = _load("FetchArchRailsConfig")
    content = calm_content if calm_content is not None else CALM_CONTENT
    responses = iter([config_yaml, content])

    # Patch _make_fetch_fn to bypass auth/API plumbing — the returned callable
    # just pops from the pre-seeded response iterator.
    fetch_fn = MagicMock(side_effect=lambda path: next(responses))

    # Mock bootstrapped flag read — `True` drives the validate+fetch path
    # (the "yml update on existing tenant" branch).
    dynamo_record = {"bootstrapped": bootstrapped}
    with patch.object(mod, "_make_fetch_fn", return_value=fetch_fn), \
         patch.object(mod.dynamodb_module, "get_item", return_value=dynamo_record), \
         patch.object(mod, "put_calm_sources", return_value=EXPECTED_CALM_SOURCES_S3_URI), \
         patch.object(mod, "put_interface_schemas", return_value=EXPECTED_INTERFACE_SCHEMAS_S3_URI):
        return mod.lambda_handler(event, None)


def _run_calm_parser(event: dict) -> dict:
    mod = _load("CalmParserLambda")
    # calm_sources rides as an s3:// URI now. Mock the S3 read so the test
    # gets a canned dict back without needing real AWS.
    fake_sources = {"payments": {"raw": CALM_CONTENT, "file": "a", "owned_by": None, "paths": []}}
    with patch.object(mod, "handler", return_value=CALM_PARSER_RESULT), \
         patch.object(mod, "read_calm_sources", return_value=fake_sources):
        return mod.lambda_handler(event, None)


def _run_validate_architecture(event: dict, extras: dict | None = None) -> dict:
    """
    Mock lambda_handler directly — the real validator has a large and frequently
    changing set of internal boundaries (dynamodb_module, _fetch_payload_from_s3,
    _run_validation, ~15 preflight validators). The pipeline contract only
    cares that the input event passes through with validation fields added.
    """
    mod = _load("ValidateArchitecture")
    extras = extras if extras is not None else VALIDATION_EVENT_EXTRAS
    fake = MagicMock(side_effect=lambda evt, _ctx: {**evt, **extras})
    with patch.object(mod, "lambda_handler", side_effect=fake):
        return mod.lambda_handler(event, None)


def _run_publish_review_result(event: dict, extras: dict | None = None) -> dict:
    """Same mock-at-the-boundary rationale as _run_validate_architecture."""
    mod = _load("PublishReviewResult")
    extras = extras if extras is not None else PUBLISH_EVENT_EXTRAS
    fake = MagicMock(side_effect=lambda evt, _ctx: {**evt, **extras})
    with patch.object(mod, "lambda_handler", side_effect=fake):
        return mod.lambda_handler(event, None)


# ═══════════════════════════════════════════════════════════════════════════════
# FLOW A — Config IS in the PR
# ═══════════════════════════════════════════════════════════════════════════════

class TestFlowA_ConfigInPR:
    """Full pipeline when .archrails/config.yml is touched in the PR."""

    def _run_pipeline(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        step2 = _run_fetch_archrails_config(step1)
        step3 = _run_calm_parser(step2)
        step4 = _run_validate_architecture(step3)
        step5 = _run_publish_review_result(step4)
        return step1, step2, step3, step4, step5

    def test_step1_diff_offloaded_to_s3(self):
        step1, *_ = self._run_pipeline()
        # Diff no longer rides in the state payload — fetch_pr_diff offloads
        # it to S3 to stay under the Step Functions 256 KB state limit.
        assert step1.get("diff_s3_uri") == EXPECTED_DIFF_S3_URI
        assert step1.get("diff_size_bytes") == len(DIFF_TEXT.encode("utf-8"))
        assert "diff" not in step1

    def test_step1_config_detected_in_pr(self):
        step1, *_ = self._run_pipeline()
        assert step1.get("archrails_config_in_pr") is True

    def test_step1_config_path_set(self):
        step1, *_ = self._run_pipeline()
        assert step1.get("archrails_config_path") == ".archrails/config.yml"

    def test_step1_files_changed_present(self):
        step1, *_ = self._run_pipeline()
        assert isinstance(step1.get("files_changed"), list)
        assert len(step1["files_changed"]) > 0

    def test_step1_original_fields_preserved(self):
        step1, *_ = self._run_pipeline()
        assert step1["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]
        assert step1["repo_sk"] == WEBHOOK_OUTPUT["repo_sk"]

    def test_step2_config_fetch_success(self):
        _, step2, *_ = self._run_pipeline()
        assert step2.get("config_fetch_status") == "success"

    def test_step2_archrails_config_yaml_present(self):
        _, step2, *_ = self._run_pipeline()
        assert step2.get("archrails_config_yaml") == ARCHRAILS_CONFIG_YAML

    def test_step2_archrails_config_valid(self):
        _, step2, *_ = self._run_pipeline()
        assert step2.get("archrails_config_valid") is True

    def test_step2_calm_sources_offloaded_to_s3(self):
        """calm_sources is offloaded to S3; the event carries a URI + count.
        The raw dict is never in the state payload (too big for SFN 256 KB)."""
        _, step2, *_ = self._run_pipeline()
        assert step2.get("calm_sources_s3_uri") == EXPECTED_CALM_SOURCES_S3_URI
        assert step2.get("calm_sources_count", 0) > 0
        assert "calm_sources" not in step2

    def test_step2_original_fields_preserved(self):
        _, step2, *_ = self._run_pipeline()
        assert step2["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]
        # The diff itself is in S3; the URI is what rides through the pipeline.
        assert step2["diff_s3_uri"] == EXPECTED_DIFF_S3_URI

    def test_step3_calm_parse_success(self):
        _, _, step3, *_ = self._run_pipeline()
        assert step3.get("calm_parse_status") == "success"

    def test_step3_s3_uri_in_result(self):
        _, _, step3, *_ = self._run_pipeline()
        assert "calm_graph_s3_uri" in step3

    def test_step3_original_fields_preserved(self):
        _, _, step3, *_ = self._run_pipeline()
        assert step3["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]
        assert step3["archrails_config_yaml"] == ARCHRAILS_CONFIG_YAML

    def test_step4_validation_result_present(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert "validation_result" in step4

    def test_step4_architecture_detection_present(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert "architecture_detection" in step4["validation_result"]

    def test_step4_original_fields_preserved(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert step4["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]
        # Validate's mock pass-through preserves the URI; the real handler
        # reads the diff from S3 into a local var without writing it back.
        assert step4["diff_s3_uri"] == EXPECTED_DIFF_S3_URI

    def test_step5_publish_success(self):
        *_, step5 = self._run_pipeline()
        assert step5.get("publish_status") == "success"

    def test_step5_original_fields_preserved(self):
        *_, step5 = self._run_pipeline()
        assert step5["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]
        assert step5["repo"] == WEBHOOK_OUTPUT["repo"]

    def test_step5_head_sha_present(self):
        *_, step5 = self._run_pipeline()
        assert step5.get("head_sha") == "deadbeef"

    def test_full_pipeline_no_step_returns_error(self):
        step1, step2, step3, step4, step5 = self._run_pipeline()
        for i, step in enumerate([step1, step2, step3, step4, step5], 1):
            assert "error" not in str(step.get("diff_fetch_status", "")), f"Step {i} diff error"
            assert "error" not in str(step.get("config_fetch_status", "")), f"Step {i} config error"
            assert "error" not in str(step.get("calm_parse_status", "")), f"Step {i} parse error"
        assert step5.get("publish_status") != "error"


# ═══════════════════════════════════════════════════════════════════════════════
# FLOW B — Config NOT in the PR
# ═══════════════════════════════════════════════════════════════════════════════

class TestFlowB_ConfigNotInPR:
    """
    Full pipeline when .archrails/config.yml is NOT touched.
    FetchArchRailsConfig skips. CalmParserLambda skips.
    ValidateArchitecture reads last-known graph (mocked at boundary).
    """

    def _run_pipeline(self):
        step1 = _run_fetch_pr_diff_no_config(WEBHOOK_OUTPUT)

        mod_config = _load("FetchArchRailsConfig")
        step2 = mod_config.lambda_handler(step1, None)

        mod_parser = _load("CalmParserLambda")
        step3 = mod_parser.lambda_handler(step2, None)

        step3_with_config = {**step3, "archrails_config_yaml": ARCHRAILS_CONFIG_YAML}
        step4 = _run_validate_architecture(step3_with_config)
        step5 = _run_publish_review_result(step4)
        return step1, step2, step3, step4, step5

    def test_step1_config_not_in_pr(self):
        step1, *_ = self._run_pipeline()
        assert step1.get("archrails_config_in_pr") is False

    def test_step1_config_path_is_none(self):
        step1, *_ = self._run_pipeline()
        assert step1.get("archrails_config_path") is None

    def test_step1_diff_still_offloaded(self):
        step1, *_ = self._run_pipeline()
        assert step1.get("diff_s3_uri") == EXPECTED_DIFF_S3_URI
        assert "diff" not in step1

    def test_step1_files_changed_present(self):
        step1, *_ = self._run_pipeline()
        assert isinstance(step1.get("files_changed"), list)

    def test_step2_skipped(self):
        _, step2, *_ = self._run_pipeline()
        assert step2.get("config_fetch_status") == "skipped"

    def test_step2_no_archrails_config_yaml(self):
        _, step2, *_ = self._run_pipeline()
        assert "archrails_config_yaml" not in step2

    def test_step2_original_fields_preserved(self):
        _, step2, *_ = self._run_pipeline()
        assert step2["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]
        # The diff itself is in S3; the URI is what rides through the pipeline.
        assert step2["diff_s3_uri"] == EXPECTED_DIFF_S3_URI

    def test_step3_skipped(self):
        _, _, step3, *_ = self._run_pipeline()
        assert step3.get("calm_parse_status") == "skipped"

    def test_step3_reason_present(self):
        _, _, step3, *_ = self._run_pipeline()
        assert "reason" in step3

    def test_step3_no_calm_graph_uri(self):
        _, _, step3, *_ = self._run_pipeline()
        assert "calm_graph_s3_uri" not in step3

    def test_step3_original_fields_preserved(self):
        _, _, step3, *_ = self._run_pipeline()
        assert step3["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]

    def test_step4_validation_result_present(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert "validation_result" in step4

    def test_step4_original_fields_preserved(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert step4["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]

    def test_step5_publish_success(self):
        *_, step5 = self._run_pipeline()
        assert step5.get("publish_status") == "success"

    def test_step5_original_fields_preserved(self):
        *_, step5 = self._run_pipeline()
        assert step5["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]
        assert step5["repo"] == WEBHOOK_OUTPUT["repo"]


# ═══════════════════════════════════════════════════════════════════════════════
# FLOW C — Config in PR but INVALID YAML
# ═══════════════════════════════════════════════════════════════════════════════

class TestFlowC_InvalidConfig:
    """
    Config is in the PR but the YAML is broken.
    archrails_config_valid=False → CalmParserLambda skips → pipeline continues.
    """

    def _run_pipeline(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)

        mod = _load("FetchArchRailsConfig")
        mock_fn = MagicMock(side_effect=lambda path: "{ not: valid: yaml: [")
        with patch.object(mod, "_make_fetch_fn", return_value=mock_fn), \
             patch.object(mod.dynamodb_module, "get_item", return_value={"bootstrapped": True}):
            step2 = mod.lambda_handler(step1, None)

        mod_parser = _load("CalmParserLambda")
        step3 = mod_parser.lambda_handler(step2, None)

        step3_with_config = {**step3, "archrails_config_yaml": ARCHRAILS_CONFIG_YAML}
        step4 = _run_validate_architecture(step3_with_config)
        step5 = _run_publish_review_result(step4)
        return step1, step2, step3, step4, step5

    def test_step2_config_invalid(self):
        _, step2, *_ = self._run_pipeline()
        # FetchArchRailsConfig returns error_response on parse failure (status="error")
        # OR archrails_config_valid=False depending on where the parse fails.
        assert (
            step2.get("status") == "error"
            or step2.get("archrails_config_valid") is False
        )

    def test_step3_skipped_due_to_invalid_config(self):
        _, _, step3, *_ = self._run_pipeline()
        # Either skipped (invalid config) or error-shaped (parse failure upstream).
        assert (
            step3.get("calm_parse_status") == "skipped"
            or step3.get("status") == "error"
        )

    def test_step4_still_runs(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert "validation_result" in step4

    def test_step5_still_publishes(self):
        *_, step5 = self._run_pipeline()
        assert step5.get("publish_status") == "success"


# ═══════════════════════════════════════════════════════════════════════════════
# FLOW E — No stored CALM graph yet (first PR ever)
# ═══════════════════════════════════════════════════════════════════════════════

class TestFlowE_NoStoredGraph:
    """
    No CALM graph has been promoted yet for this repo.
    ValidateArchitecture returns validation_status=skipped.
    PublishReviewResult still runs.
    """

    def _run_pipeline(self):
        step1 = _run_fetch_pr_diff_no_config(WEBHOOK_OUTPUT)

        mod_config = _load("FetchArchRailsConfig")
        step2 = mod_config.lambda_handler(step1, None)

        mod_parser = _load("CalmParserLambda")
        step3 = mod_parser.lambda_handler(step2, None)

        step3_with_config = {**step3, "archrails_config_yaml": ARCHRAILS_CONFIG_YAML}
        skipped = {
            "validation_status": "skipped",
            "reason": "No stored CALM baseline record found for this repo/source.",
        }
        step4 = _run_validate_architecture(step3_with_config, extras=skipped)
        step5 = _run_publish_review_result(step4)
        return step1, step2, step3, step4, step5

    def test_step4_validation_skipped(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert step4.get("validation_status") == "skipped"

    def test_step4_reason_present(self):
        _, _, _, step4, _ = self._run_pipeline()
        assert "reason" in step4

    def test_step5_still_runs(self):
        *_, step5 = self._run_pipeline()
        assert step5.get("publish_status") in ("success", "error")

    def test_step5_original_fields_preserved(self):
        *_, step5 = self._run_pipeline()
        assert step5["tenant_pk"] == WEBHOOK_OUTPUT["tenant_pk"]


# ═══════════════════════════════════════════════════════════════════════════════
# Event shape contracts — key flow between steps
# ═══════════════════════════════════════════════════════════════════════════════

class TestEventShapeContracts:
    """Verify every key each lambda needs from the previous step is present."""

    def test_fetch_pr_diff_output_has_all_keys_for_fetch_config(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        for key in ["provider", "host", "tenant_pk", "repo_sk", "sha",
                    "change_number", "diff_s3_uri", "diff_size_bytes",
                    "files_changed", "archrails_config_in_pr"]:
            assert key in step1, f"FetchPullRequestDiff output missing '{key}'"

    def test_fetch_config_output_has_all_keys_for_calm_parser(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        step2 = _run_fetch_archrails_config(step1)
        for key in ["provider", "host", "tenant_pk", "repo_sk", "sha",
                    "change_number", "archrails_config_yaml",
                    "archrails_config_valid", "archrails_config_in_pr"]:
            assert key in step2, f"FetchArchRailsConfig output missing '{key}'"

    def test_calm_parser_output_has_all_keys_for_validate(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        step2 = _run_fetch_archrails_config(step1)
        step3 = _run_calm_parser(step2)
        for key in ["tenant_pk", "repo_sk", "archrails_config_yaml",
                    "diff_s3_uri", "files_changed"]:
            assert key in step3, f"CalmParserLambda output missing '{key}'"

    def test_validate_output_has_all_keys_for_publish(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        step2 = _run_fetch_archrails_config(step1)
        step3 = _run_calm_parser(step2)
        step4 = _run_validate_architecture(step3)
        for key in ["provider", "host", "tenant_pk", "repo", "repository_id",
                    "sha", "change_number", "validation_result"]:
            assert key in step4, f"ValidateArchitecture output missing '{key}'"

    def test_tenant_pk_flows_through_entire_pipeline(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        step2 = _run_fetch_archrails_config(step1)
        step3 = _run_calm_parser(step2)
        step4 = _run_validate_architecture(step3)
        step5 = _run_publish_review_result(step4)
        for i, step in enumerate([step1, step2, step3, step4, step5], 1):
            assert step.get("tenant_pk") == WEBHOOK_OUTPUT["tenant_pk"], \
                f"tenant_pk missing or wrong at step {i}"

    def test_repo_sk_flows_through_entire_pipeline(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        step2 = _run_fetch_archrails_config(step1)
        step3 = _run_calm_parser(step2)
        step4 = _run_validate_architecture(step3)
        step5 = _run_publish_review_result(step4)
        for i, step in enumerate([step1, step2, step3, step4, step5], 1):
            assert step.get("repo_sk") == WEBHOOK_OUTPUT["repo_sk"], \
                f"repo_sk missing or wrong at step {i}"

    def test_diff_uri_flows_through_to_validate(self):
        step1 = _run_fetch_pr_diff(WEBHOOK_OUTPUT)
        step2 = _run_fetch_archrails_config(step1)
        step3 = _run_calm_parser(step2)
        step4 = _run_validate_architecture(step3)
        # The URI flows through every stage; the real validate_architecture
        # re-hydrates the diff content from S3 at handler entry.
        assert step4.get("diff_s3_uri") == EXPECTED_DIFF_S3_URI
