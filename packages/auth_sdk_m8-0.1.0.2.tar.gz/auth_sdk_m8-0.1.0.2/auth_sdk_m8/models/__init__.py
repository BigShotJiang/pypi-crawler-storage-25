"""SQLModel shared model mixins."""
