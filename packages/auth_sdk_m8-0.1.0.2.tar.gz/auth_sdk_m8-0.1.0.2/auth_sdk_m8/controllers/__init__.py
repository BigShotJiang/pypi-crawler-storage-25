"""FastAPI base controller."""
