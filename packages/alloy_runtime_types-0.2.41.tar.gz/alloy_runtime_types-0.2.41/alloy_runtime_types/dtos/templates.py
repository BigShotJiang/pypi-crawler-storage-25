"""DTOs for template operations."""

import re
from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from alloy_runtime_types.enums.ownership_scope import OwnershipScope
from alloy_runtime_types.enums.template_enums import (
    TemplateContentType,
    TemplateVisibility,
)


class TagResponse(BaseModel):
    """Response model for a tag."""

    id: UUID
    organization_id: UUID
    tag_path: str
    display_name: str
    description: str | None


class TemplateContentResponse(BaseModel):
    """Response model for template content."""

    id: UUID
    organization_id: UUID | None
    user_id: UUID | None
    content_type_id: str
    name: str
    description: str | None
    visibility_id: str
    tags: list[TagResponse]
    created_at: datetime
    updated_at: datetime


class TemplateVersionResponse(BaseModel):
    """Response model for template version."""

    id: UUID
    template_content_id: UUID
    version: int
    content: str
    is_latest: bool
    required_variables: list[str] = Field(
        default_factory=list,
        description="Variables required to render this template version. "
        "Only populated for the latest version.",
    )
    created_at: datetime


class TemplateDependencyResponse(BaseModel):
    """Response model for template dependency."""

    parent_template_content_id: UUID
    child_template_content_id: UUID
    child_template_name: str
    pinned_child_version_id: UUID | None
    created_at: datetime


class CreateTemplateRequest(BaseModel):
    """Request to create a new template."""

    name: str = Field(..., min_length=1, max_length=255, description="Template name")
    content_type: TemplateContentType = Field(
        ..., description="Type of template content"
    )
    visibility: TemplateVisibility = Field(
        default=TemplateVisibility.ORGANIZATION,
        description="Visibility level. Defaults to organization visibility when omitted.",
    )
    initial_content: str = Field(
        ..., min_length=1, description="Initial version content"
    )
    tag_paths: list[str] = Field(
        ...,
        min_length=1,
        description="Tag paths (e.g., 'email.newsletter', 'marketing'). At least one tag is required.",
    )
    description: str | None = Field(default=None, description="Optional description")
    upsert: bool = Field(
        default=False, description="Return existing if name already exists"
    )
    scope: OwnershipScope = Field(
        default=OwnershipScope.ORGANIZATION,
        description="Ownership scope for the template. Defaults to organization scope when omitted.",
    )
    escape_jinja: bool = Field(
        default=False,
        description="Escape Jinja syntax ({{, {%, {#) so they render as literal text",
    )

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Template name must be lowercase alphanumeric with dots, dashes, or underscores."""
        if not re.match(r"^[a-z0-9._-]+$", v):
            raise ValueError(
                "Template name must be lowercase alphanumeric with dots, dashes, or underscores only"
            )
        return v


class CreateTemplateResponse(BaseModel):
    """Response after creating a template."""

    template: TemplateContentResponse
    version: TemplateVersionResponse
    dependencies: list[TemplateDependencyResponse]


class CreateTemplateVersionRequest(BaseModel):
    """Request to create a new version of an existing template."""

    content: str = Field(..., min_length=1, description="New template content")
    tag_paths: list[str] | None = Field(
        default=None,
        description="Updated tag paths (e.g., 'email.newsletter', 'marketing'). If omitted, existing tags are preserved. If empty list, all tags are cleared.",
    )


class CreateTemplateVersionResponse(BaseModel):
    """Response after creating a new template version."""

    template: TemplateContentResponse
    version: TemplateVersionResponse
    dependencies: list[TemplateDependencyResponse]


class GetTemplateResponse(BaseModel):
    """Response for getting a single template by ID."""

    template: TemplateContentResponse
    versions: list[TemplateVersionResponse]
    dependencies: list[TemplateDependencyResponse]


class RenderTemplateRequest(BaseModel):
    """Request to render a template."""

    variables: dict[str, Any] = Field(
        default_factory=dict, description="Variables for Jinja2 interpolation"
    )


class RenderTemplateResponse(BaseModel):
    """Response after rendering a template."""

    rendered_text: str = Field(description="Final rendered template content")
    content_hash: str = Field(description="SHA-256 hash of rendered text")
    character_count: int = Field(description="Length of rendered text")
    template_version_id: UUID = Field(description="Template version that was rendered")
    render_log_id: UUID = Field(description="Audit trail identifier")


class TemplateListItemResponse(BaseModel):
    """Response model for a single template in list view."""

    id: UUID
    organization_id: UUID | None
    user_id: UUID | None
    content_type_id: str
    name: str
    description: str | None
    visibility_id: str
    latest_version_id: UUID
    latest_version_number: int
    latest_version_created_at: datetime
    required_variables: list[str] = Field(
        default_factory=list,
        description="Variables required to render the latest version. "
        "Fragment variables only included if resolve_fragments=true.",
    )
    tags: list[TagResponse]
    created_at: datetime
    updated_at: datetime
    latest_version_content: str | None = Field(
        default=None,
        description="Content of the latest version. "
        "Only included when include_content=true in request.",
    )


class ListTemplatesResponse(BaseModel):
    """Response for listing templates with pagination."""

    templates: list[TemplateListItemResponse]
    cursor: str | None = Field(
        default=None, description="Cursor for next page. Null if no more results."
    )
    total_count: int = Field(description="Total matching templates across all pages")


class DependentTemplateInfo(BaseModel):
    """Information about a template that depends on another template."""

    id: UUID = Field(description="ID of the dependent template")
    name: str = Field(description="Name of the dependent template")
    user_id: UUID | None = Field(description="Owner user ID of the dependent template")
    organization_id: UUID | None = Field(
        description="Organization ID of the dependent template"
    )


def _empty_dependent_templates() -> list[DependentTemplateInfo]:
    return []


class DeleteTemplateResponse(BaseModel):
    """Response after deleting a template."""

    deleted_template: TemplateContentResponse = Field(
        description="The template that was deleted"
    )
    dependent_templates: list[DependentTemplateInfo] = Field(
        default_factory=_empty_dependent_templates,
        description="Templates that referenced the deleted template as a dependency. "
        "These templates may need to be updated to remove broken references.",
    )


class UpdateTemplateRequest(BaseModel):
    """Request to update an existing template.

    All fields are optional - only provided fields are updated.
    Content updates are only allowed for templates with a single version.
    """

    name: str | None = Field(
        default=None,
        min_length=1,
        max_length=255,
        description="New template name",
    )
    content_type: TemplateContentType | None = Field(
        default=None, description="New content type"
    )
    visibility: TemplateVisibility | None = Field(
        default=None, description="New visibility level"
    )
    description: str | None = Field(
        default=None,
        description="Updated description. Set to empty string to clear.",
    )
    tag_paths: list[str] | None = Field(
        default=None,
        description="Tag paths to replace existing tags. "
        "If omitted, existing tags are preserved. "
        "If empty list, all tags are cleared.",
    )
    content: str | None = Field(
        default=None,
        min_length=1,
        description="Updated template content. Only allowed for templates with a single version. "
        "Templates with multiple versions must use the create version endpoint instead.",
    )

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str | None) -> str | None:
        """Template name must be lowercase alphanumeric with dots, dashes, or underscores."""
        if v is not None and not re.match(r"^[a-z0-9._-]+$", v):
            raise ValueError(
                "Template name must be lowercase alphanumeric with dots, dashes, or underscores only"
            )
        return v


class UpdateTemplateResponse(BaseModel):
    """Response after updating a template."""

    template: TemplateContentResponse
    version: TemplateVersionResponse
    dependencies: list[TemplateDependencyResponse]
