import base64
import copy
import calendar
import json
import os
import platform
import re
import sys
import time
import zipfile

import requests
import traceback

from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from MediCafe.MediLink_ConfigLoader import load_configuration, log as mc_log
try:
    from MediCafe.MediLink_ConfigLoader import get_default_config as _loader_get_default_config
except Exception:
    _loader_get_default_config = None
try:
    from MediCafe.MediLink_ConfigLoader import get_last_load_diagnostics as _loader_get_last_load_diagnostics
except Exception:
    _loader_get_last_load_diagnostics = None
try:
    from MediCafe.MediLink_ConfigLoader import select_preferred_run_log_path as _loader_select_preferred_run_log_path
except Exception:
    _loader_select_preferred_run_log_path = None
try:
    from MediCafe.MediLink_ConfigLoader import _extract_daily_run_index as _loader_extract_daily_run_index
except Exception:
    _loader_extract_daily_run_index = None
from MediCafe.gmail_token_service import (
    get_gmail_access_token,
    get_gmail_access_token_outcome,
    clear_gmail_token_cache,
)
from MediLink.gmail_oauth_utils import REFRESH_TAXONOMY_INVALID_GRANT

GMAIL_SEND_API_URL = 'https://gmail.googleapis.com/gmail/v1/users/me/messages/send'
GMAIL_TOKENINFO_URL = 'https://www.googleapis.com/oauth2/v1/tokeninfo'

SUPPORT_DELIVERY_REAUTH_REQUIRED = 'SUPPORT_DELIVERY_REAUTH_REQUIRED'
SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION = 'SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION'

_LAST_SUPPORT_EMAIL_DELIVERY_META = {}


def get_last_support_email_delivery_meta():
    """Snapshot from the most recent submit_support_bundle_email attempt (delivery UX)."""
    return dict(_LAST_SUPPORT_EMAIL_DELIVERY_META)


def _store_support_email_delivery_meta(payload):
    global _LAST_SUPPORT_EMAIL_DELIVERY_META
    _LAST_SUPPORT_EMAIL_DELIVERY_META = dict(payload or {})


def _default_support_delivery_meta():
    return {
        'delivery_issue_code': '',
        'delivery_state': '',
        'auth_taxonomy': '',
        'reauth_required': False,
    }


def _annotate_support_job_self_observation(meta, extra_meta, medi):
    """If the bundle is built while its source support-send job is still running, flag incomplete observation."""
    try:
        if not isinstance(meta, dict):
            return
        ctx = meta.get('extra_context')
        if not isinstance(ctx, dict):
            return
        job_ctx = ctx.get('support_send_job_context')
        if not isinstance(job_ctx, dict):
            return
        jid = str(job_ctx.get('job_id') or '').strip()
        if not jid:
            return
        lab_root = ''
        if isinstance(extra_meta, dict):
            lab_root = str(extra_meta.get('lab_root') or '').strip()
        if not lab_root:
            lab_root = str(ctx.get('lab_root') or '').strip()
        if not lab_root:
            return
        job_path = os.path.join(lab_root, 'reports', 'support_send_jobs', 'job_{}.json'.format(jid))
        if not os.path.isfile(job_path):
            return
        try:
            with open(job_path, 'r') as handle:
                data = json.load(handle)
        except Exception:
            return
        if not isinstance(data, dict):
            return
        if str(data.get('status') or '').strip() != 'running':
            return
        ctx_out = dict(ctx)
        ctx_out['self_observation_status'] = 'incomplete_observation'
        ctx_out['delivery_issue_code_support'] = SUPPORT_SEND_JOB_INCOMPLETE_OBSERVATION
        meta['extra_context'] = _sanitize_extra_meta(ctx_out)
    except Exception:
        pass


def _safe_ascii(text):
	try:
		if text is None:
			return ''
		if isinstance(text, bytes):
			try:
				text = text.decode('ascii', 'ignore')
			except Exception:
				text = text.decode('utf-8', 'ignore')
		else:
			text = str(text)
		return text.encode('ascii', 'ignore').decode('ascii', 'ignore')
	except Exception:
		return ''


def _sanitize_extra_meta(value, depth=0, max_depth=5, max_items=50):
	"""Serialize caller-provided metadata into an ASCII-safe structure."""
	if depth > max_depth:
		return '...'
	if isinstance(value, dict):
		result = {}
		for idx, (key, val) in enumerate(value.items()):
			if idx >= max_items:
				result['_truncated'] = True
				break
			result[_safe_ascii(key)] = _sanitize_extra_meta(val, depth + 1, max_depth, max_items)
		return result
	if isinstance(value, (list, tuple, set)):
		serialized = []
		for idx, item in enumerate(value):
			if idx >= max_items:
				serialized.append('...')
				break
			serialized.append(_sanitize_extra_meta(item, depth + 1, max_depth, max_items))
		return serialized
	if isinstance(value, (int, float)) and not isinstance(value, bool):
		return value
	if isinstance(value, bool) or value is None:
		return value
	return _safe_ascii(value)


def _tail_file(path, max_lines):
	lines = []
	try:
		with open(path, 'r') as f:
			for line in f:
				lines.append(line)
				if len(lines) > max_lines:
					lines.pop(0)
		return ''.join(lines)
	except Exception:
		return ''


def _parse_log_run_filename(path):
    try:
        name = os.path.basename(path)
    except Exception:
        return {}
    m = re.match(r'^Log_(\d{8})_run(\d{3})(?:_[^.]*)?\.log$', name)
    if not m:
        return {}
    date_token = m.group(1)
    run_index = None
    try:
        if callable(_loader_extract_daily_run_index):
            run_index = _loader_extract_daily_run_index(name, date_token)
    except Exception:
        run_index = None
    if run_index is None:
        try:
            run_index = int(m.group(2))
        except Exception:
            run_index = None
    return {
        'date_token': date_token,
        'run_index': run_index,
        'name': name,
    }


def _log_date_token_sort_value(date_token):
    text = str(date_token or '')
    if len(text) != 8 or not text.isdigit():
        return 0
    try:
        month = int(text[0:2])
        day = int(text[2:4])
        year = int(text[4:8])
    except Exception:
        return 0
    if month < 1 or month > 12 or day < 1 or day > 31:
        return 0
    return year * 10000 + month * 100 + day


def _list_support_log_paths(local_storage_path):
    try:
        names = os.listdir(local_storage_path or '.')
    except Exception:
        names = []
    paths = []
    for name in names:
        try:
            if not (name.startswith('Log_') and name.endswith('.log')):
                continue
            path = os.path.join(local_storage_path or '.', name)
            if os.path.isfile(path):
                paths.append(path)
        except Exception:
            continue
    return paths


def _select_historical_support_bundle_logs(local_storage_path, selected_log_path, limit=2):
    selected = str(selected_log_path or '').strip()
    if not selected:
        return []
    try:
        selected_abs = os.path.abspath(selected)
    except Exception:
        selected_abs = selected
    selected_info = _parse_log_run_filename(selected)
    selected_mtime = 0.0
    try:
        selected_mtime = os.path.getmtime(selected)
    except Exception:
        selected_mtime = 0.0
    selected_date_token = selected_info.get('date_token')
    selected_date_value = _log_date_token_sort_value(selected_date_token)
    selected_index = selected_info.get('run_index')
    same_day_candidates = []
    older_candidates = []
    for path in _list_support_log_paths(local_storage_path):
        try:
            path_abs = os.path.abspath(path)
        except Exception:
            path_abs = path
        if path_abs == selected_abs:
            continue
        info = _parse_log_run_filename(path)
        try:
            mtime = os.path.getmtime(path)
        except Exception:
            mtime = 0.0
        row = {
            'path': path,
            'name': os.path.basename(path),
            'mtime': mtime,
            'date_token': info.get('date_token', ''),
            'date_value': _log_date_token_sort_value(info.get('date_token', '')),
            'run_index': info.get('run_index'),
        }
        if selected_date_token and info.get('date_token') == selected_date_token:
            run_index = info.get('run_index')
            if run_index is not None and selected_index is not None and run_index < selected_index:
                row['selection_reason'] = 'same_day_prior_run'
                same_day_candidates.append(row)
        elif selected_date_value and row.get('date_value') and row.get('date_value') < selected_date_value:
            row['selection_reason'] = 'older_filename_date'
            older_candidates.append(row)
        elif not selected_date_value and selected_mtime and mtime <= selected_mtime:
            row['selection_reason'] = 'older_mtime'
            older_candidates.append(row)
    if selected_date_token:
        same_day_candidates.sort(
            key=lambda row: (int(row.get('run_index') or 0), float(row.get('mtime') or 0.0)),
            reverse=True,
        )
        older_candidates.sort(
            key=lambda row: (
                int(row.get('date_value') or 0),
                int(row.get('run_index') or 0),
                float(row.get('mtime') or 0.0),
            ),
            reverse=True,
        )
        candidates = same_day_candidates + older_candidates
    else:
        candidates = older_candidates
        candidates.sort(key=lambda row: float(row.get('mtime') or 0.0), reverse=True)
    out = []
    max_count = max(0, int(limit or 0))
    for row in candidates[:max_count]:
        row = dict(row)
        row['archive_name'] = os.path.basename(str(row.get('path', '') or ''))
        out.append(row)
    return out

def _get_latest_log_path(local_storage_path):
	try:
		files = []
		for name in os.listdir(local_storage_path or '.'):
			if name.startswith('Log_') and name.endswith('.log'):
				files.append(os.path.join(local_storage_path, name))
		if not files:
			return None
		files.sort(key=lambda p: os.path.getmtime(p))
		return files[-1]
	except Exception:
		return None


def _select_support_bundle_log(local_storage_path):
    """
    Select support-bundle log with run-scoped preference.
    Returns dict with selected path/name/strategy and run-log identity.
    """
    selection = {
        'selected_log_path': '',
        'selected_log_name': '',
        'selected_log_selection_strategy': 'none',
        'app_log_run_id': str(os.environ.get('MEDICAFE_RUN_LOG_ID', '') or '').strip(),
        'run_log_expected_path': '',
    }
    try:
        if callable(_loader_select_preferred_run_log_path):
            resolved = _loader_select_preferred_run_log_path(local_storage_path, include_any_log_fallback=False)
            if isinstance(resolved, dict):
                selection.update({
                    'selected_log_path': str(resolved.get('selected_log_path') or ''),
                    'selected_log_name': str(resolved.get('selected_log_name') or ''),
                    'selected_log_selection_strategy': str(
                        resolved.get('selected_log_selection_strategy') or selection['selected_log_selection_strategy']
                    ),
                    'app_log_run_id': str(resolved.get('app_log_run_id') or selection.get('app_log_run_id', '')),
                    'run_log_expected_path': str(resolved.get('run_log_expected_path') or ''),
                })
    except Exception:
        pass

    if not selection.get('selected_log_path'):
        legacy_latest = _get_latest_log_path(local_storage_path)
        if legacy_latest:
            selection['selected_log_path'] = legacy_latest
            selection['selected_log_name'] = os.path.basename(legacy_latest)
            selection['selected_log_selection_strategy'] = 'latest_modified_fallback'

    if selection.get('selected_log_path') and not selection.get('selected_log_name'):
        try:
            selection['selected_log_name'] = os.path.basename(selection['selected_log_path'])
        except Exception:
            selection['selected_log_name'] = ''

    return selection


def redact_for_support_bundle(text):
    """Redact sensitive tokens/identifiers from content destined for support bundles."""
    # Best-effort ASCII redaction: mask common secrets in logs and JSON
    # Excludes process exit codes (e.g. "failed with code 1") from 9-11 digit masking
    try:
        text = _safe_ascii(text)
        patterns = [
            # SSN-like
            (r'\b(\d{3}-?\d{2}-?\d{4})\b', '***-**-****'),
            # 9-11 digit numeric IDs (exclude "code N" - process exit codes)
            (r'(?<!code )\b(\d{9,11})\b', '*********'),
            # PATID patterns in logs (PATID='12345' / PATID=12345 / PATID: 12345)
            (r"(PATID\s*[=:]\s*'?)\d{5}('?\b)", r'\1*****\2'),
            # Authorization headers
            (r'Authorization:\s*Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Authorization: Bearer ***'),
            (r'Authorization:\s*[^\n\r]+', 'Authorization: ***'),
            # JSON token fields
            (r'("access_token"\s*:\s*")([^"]+)(")', r'\1***\3'),
            (r'("refresh_token"\s*:\s*")([^"]+)(")', r'\1***\3'),
            (r'("id_token"\s*:\s*")([^"]+)(")', r'\1***\3'),
            (r'("X-Auth-Token"\s*:\s*")([^"]+)(")', r'\1***\3'),
            # URL query params: token=..., access_token=..., auth=...
            (r'(token|access_token|auth|authorization)=([^&\s]+)', r'\1=***'),
            # Bearer fragments in JSON or text
            (r'Bearer\s+[A-Za-z0-9\-._~+/]+=*', 'Bearer ***'),
        ]
        for pat, rep in patterns:
            text = re.sub(pat, rep, text)
        return text
    except Exception:
        return text


def _redact(text):
    """Backward-compatible internal alias; prefer redact_for_support_bundle()."""
    return redact_for_support_bundle(text)


def _ensure_dir(path):
	try:
		if not os.path.exists(path):
			os.makedirs(path)
		return True
	except Exception:
		return False


def _deep_merge_dicts(base, override):
    result = copy.deepcopy(base) if isinstance(base, dict) else {}
    if not isinstance(override, dict):
        return result
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge_dicts(result.get(key), value)
        else:
            try:
                result[key] = copy.deepcopy(value)
            except Exception:
                result[key] = value
    return result


def _get_degraded_storage_root():
    base = os.environ.get('MEDICAFE_BOOTSTRAP_LOG_DIR', '').strip()
    if base:
        return os.path.abspath(base)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))


def _default_medi_config_for_error_reporter():
    defaults = {
        'local_storage_path': _get_degraded_storage_root(),
        'logging': {
            'console_output': False,
        },
        'error_reporting': {
            'enabled': False,
            'endpoint_url': '',
            'auth_token': '',
            'insecure_http': False,
            'max_bundle_bytes': 2097152,
            'email': {
                'enabled': False,
                'to': '',
                'subject_prefix': 'MediCafe Error Report',
                'max_bundle_bytes': 1572864,
            },
        },
    }
    if callable(_loader_get_default_config):
        try:
            loader_defaults = _loader_get_default_config() or {}
            medi_defaults = loader_defaults.get('MediLink_Config', {}) if isinstance(loader_defaults, dict) else {}
            if isinstance(medi_defaults, dict):
                defaults = _deep_merge_dicts(defaults, medi_defaults)
        except Exception:
            pass
    if not str(defaults.get('local_storage_path', '') or '').strip():
        defaults['local_storage_path'] = _get_degraded_storage_root()
    return defaults


def _get_config_loader_diagnostics_snapshot():
    if callable(_loader_get_last_load_diagnostics):
        try:
            diagnostics = _loader_get_last_load_diagnostics() or {}
            if isinstance(diagnostics, dict):
                return diagnostics
        except Exception:
            pass
    return {}


def _is_config_loader_degraded(diagnostics):
    if not isinstance(diagnostics, dict) or not diagnostics:
        return False
    return diagnostics.get('overall_status') not in (None, '', 'ok')


def _config_loader_summary_text(diagnostics):
    if not isinstance(diagnostics, dict):
        return ''
    parts = diagnostics.get('summary_lines') or []
    if isinstance(parts, list) and parts:
        return '; '.join([_safe_ascii(part) for part in parts[:3] if part])
    loader_exception = diagnostics.get('loader_exception')
    return _safe_ascii(loader_exception)


def _attach_config_loader_meta(meta, diagnostics):
    if not isinstance(meta, dict) or not isinstance(diagnostics, dict) or not diagnostics:
        return
    try:
        snapshot = {
            'overall_status': diagnostics.get('overall_status', ''),
            'path_source': diagnostics.get('path_source', ''),
            'resolved_paths': diagnostics.get('resolved_paths', {}),
            'defaults_in_use': diagnostics.get('defaults_in_use', {}),
            'summary_lines': diagnostics.get('summary_lines', []),
        }
        if diagnostics.get('loader_exception'):
            snapshot['loader_exception'] = diagnostics.get('loader_exception')
        resolved = diagnostics.get('resolved_paths', {}) if isinstance(diagnostics.get('resolved_paths', {}), dict) else {}
        excluded = []
        for key in ('config_local', 'crosswalk_state'):
            path = str(resolved.get(key, '') or '').strip()
            if path:
                excluded.append(os.path.basename(path))
        if excluded:
            snapshot['excluded_sidecars_from_bundle'] = excluded
        meta['config_loader'] = _sanitize_extra_meta(snapshot)
    except Exception:
        pass


def _get_error_reporter_runtime_context():
    diagnostics = _get_config_loader_diagnostics_snapshot()
    loader_exception = ''
    try:
        config, _ = load_configuration()
    except Exception as e:
        config = {}
        loader_exception = _safe_ascii(e)
    diagnostics = _get_config_loader_diagnostics_snapshot() or diagnostics

    if not isinstance(config, dict):
        config = {}

    defaults = _default_medi_config_for_error_reporter()
    loaded_medi = config.get('MediLink_Config', {}) if isinstance(config.get('MediLink_Config', {}), dict) else {}
    medi = _deep_merge_dicts(defaults, loaded_medi)

    degraded = _is_config_loader_degraded(diagnostics) or bool(loader_exception)
    raw_local_storage = str(loaded_medi.get('local_storage_path', '') or '').strip() if isinstance(loaded_medi, dict) else ''
    if degraded and (not raw_local_storage or raw_local_storage == '.'):
        medi['local_storage_path'] = _get_degraded_storage_root()
    elif not str(medi.get('local_storage_path', '') or '').strip():
        medi['local_storage_path'] = defaults.get('local_storage_path', _get_degraded_storage_root())

    if loader_exception:
        diagnostics = copy.deepcopy(diagnostics) if isinstance(diagnostics, dict) and diagnostics else {}
        diagnostics.setdefault('overall_status', 'degraded')
        diagnostics['loader_exception'] = loader_exception
        summary_lines = diagnostics.get('summary_lines')
        if not isinstance(summary_lines, list):
            summary_lines = []
        summary_lines.append('config loader raised {}'.format(loader_exception))
        diagnostics['summary_lines'] = summary_lines

    return {
        'config': config,
        'medi': medi,
        'diagnostics': diagnostics,
        'degraded': degraded,
    }


def _iso_utc_now_report():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def _dedup_epoch_from_utc(last_utc):
    if not last_utc:
        return None
    try:
        struct = time.strptime(str(last_utc).replace('Z', ''), '%Y-%m-%dT%H:%M:%S')
        return calendar.timegm(struct)
    except (ValueError, TypeError):
        return None


def _dedup_within_window(last_key, last_utc, dedup_key, window_sec):
    if last_key != dedup_key or not last_utc:
        return False
    last_epoch = _dedup_epoch_from_utc(last_utc)
    if last_epoch is None:
        return False
    return (time.time() - last_epoch) < window_sec


def _report_dedup_lock_path(state_path):
    return '{0}.dedup.lock'.format(state_path)


# Dedup critical section should be sub-second; stale locks are stealable after this age.
_REPORT_DEDUP_LOCK_MAX_AGE_SEC = 600


def _dedup_lock_holder_pid(lock_path):
    """Return int pid from lock file, or None if missing/unparseable."""
    try:
        with open(lock_path, 'rb') as f:
            raw = f.read().decode('ascii', 'ignore').strip()
        if not raw:
            return None
        token = raw.split()[0]
        return int(token)
    except (IOError, OSError, ValueError):
        return None


def _dedup_lock_process_alive(pid):
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ValueError):
        return False


def _report_dedup_lock_is_stealable(lock_path, max_age_sec=_REPORT_DEDUP_LOCK_MAX_AGE_SEC):
    """
    True if lock file is orphaned (dead pid, corrupt content, or older than max_age_sec).
    Also stealable when the file mtime is past max_age even if the PID is alive (PID reuse).
    """
    try:
        if not os.path.exists(lock_path):
            return False
        try:
            file_age = time.time() - os.path.getmtime(lock_path)
        except (OSError, IOError, ValueError):
            return True
        threshold = max(30.0, float(max_age_sec))
        if file_age > threshold:
            return True
        holder = _dedup_lock_holder_pid(lock_path)
        if holder is None:
            return False
        return not _dedup_lock_process_alive(holder)
    except (OSError, IOError):
        return True


def try_acquire_report_dedup_lock(state_path, timeout_sec=60, sleep_sec=0.05):
    """
    Exclusive lock for diagnostics_state.json dedup (non-fatal; never sys.exit).
    Returns True when the lock file was created for this caller; False on timeout.
    Steals stale/orphan locks (dead pid, unparseable pid with old mtime, or lock file mtime past
    max age even when PID is alive—PID reuse) instead of waiting forever.
    """
    lock_path = _report_dedup_lock_path(state_path)
    dir_path = os.path.dirname(lock_path)
    if dir_path and not os.path.exists(dir_path):
        try:
            os.makedirs(dir_path)
        except (OSError, IOError):
            pass
    deadline = time.time() + max(0.0, float(timeout_sec))
    while True:
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            try:
                os.write(fd, str(os.getpid()).encode('ascii', 'ignore'))
            finally:
                os.close(fd)
            return True
        except (OSError, IOError) as e:
            errno_val = getattr(e, 'errno', None)
            if errno_val not in (17, 183):
                return False
        if _report_dedup_lock_is_stealable(lock_path):
            try:
                if os.path.exists(lock_path):
                    os.remove(lock_path)
            except (OSError, IOError):
                pass
            continue
        if time.time() >= deadline:
            return False
        time.sleep(sleep_sec)


def release_report_dedup_lock(state_path):
    lock_path = _report_dedup_lock_path(state_path)
    try:
        if os.path.exists(lock_path):
            os.remove(lock_path)
    except (OSError, IOError):
        pass


def _atomic_write_json_file(path, obj):
    tmp_path = path + '.tmp'
    dir_path = os.path.dirname(path)
    if dir_path and not os.path.exists(dir_path):
        try:
            os.makedirs(dir_path)
        except (OSError, IOError):
            pass
    with open(tmp_path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, indent=2)
    try:
        os.replace(tmp_path, path)
    except (OSError, IOError):
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except (OSError, IOError):
            pass
        raise


def _load_diagnostics_state(state_path):
    try:
        if os.path.exists(state_path):
            with open(state_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
    except (IOError, OSError, ValueError):
        pass
    return {}


def _dedup_suppressed_for_channel(state, channel, dedup_key, window_sec):
    """
    Per-channel suppression when report_dedup is non-empty; else legacy global fields.
    """
    rd = state.get('report_dedup')
    if isinstance(rd, dict) and rd:
        ent = rd.get(channel)
        if isinstance(ent, dict):
            return _dedup_within_window(
                ent.get('key'), ent.get('sent_at_utc'), dedup_key, window_sec,
            )
        return False
    last_key = state.get('last_report_dedup_key')
    last_utc = state.get('last_report_sent_at_utc')
    return _dedup_within_window(last_key, last_utc, dedup_key, window_sec)


def _apply_report_dedup_reservation(state, channel, dedup_key):
    now = _iso_utc_now_report()
    rd = state.get('report_dedup')
    if not isinstance(rd, dict):
        rd = {}
    rd[channel] = {'key': dedup_key, 'sent_at_utc': now}
    state['report_dedup'] = rd
    state['last_report_dedup_key'] = dedup_key
    state['last_report_sent_at_utc'] = now


def report_dedup_try_reserve(state_path, channel, dedup_key, window_sec, lock_timeout_sec=60):
    """
    Under an exclusive dedup lock: load state, skip if suppressed, else reserve slot and persist.
    Returns (allowed, state_dict). allowed False => do not send. state_dict is post-reserve copy when allowed.
    """
    if not channel or not isinstance(channel, str):
        raise ValueError('channel must be a non-empty string')
    if not try_acquire_report_dedup_lock(state_path, timeout_sec=lock_timeout_sec):
        return (False, None)
    try:
        state = _load_diagnostics_state(state_path)
        if _dedup_suppressed_for_channel(state, channel, dedup_key, window_sec):
            return (False, None)
        _apply_report_dedup_reservation(state, channel, dedup_key)
        _atomic_write_json_file(state_path, state)
        return (True, state)
    finally:
        release_report_dedup_lock(state_path)


def report_dedup_release_if_failed(state_path, channel, dedup_key, lock_timeout_sec=60):
    """If send failed after reserve, clear this channel (and matching legacy fields) under lock."""
    if not channel or not isinstance(channel, str):
        return
    if not try_acquire_report_dedup_lock(state_path, timeout_sec=lock_timeout_sec):
        return
    try:
        state = _load_diagnostics_state(state_path)
        rd = state.get('report_dedup')
        changed = False
        if isinstance(rd, dict) and channel in rd:
            ent = rd.get(channel)
            if isinstance(ent, dict) and ent.get('key') == dedup_key:
                del rd[channel]
                state['report_dedup'] = rd
                changed = True
        if state.get('last_report_dedup_key') == dedup_key:
            state['last_report_dedup_key'] = ''
            state['last_report_sent_at_utc'] = ''
            changed = True
        if changed:
            _atomic_write_json_file(state_path, state)
    finally:
        release_report_dedup_lock(state_path)


def check_report_dedup(state_path, dedup_key, window_sec, channel=None):
    """
    Check if we should send a report based on dedup key and window (read-only, no lock).
    When channel is None, uses legacy global fields only.
    When channel is set, uses the same rules as report_dedup_try_reserve (including report_dedup map).
    Returns (should_send, state_dict).
    """
    state = _load_diagnostics_state(state_path)
    if channel:
        if _dedup_suppressed_for_channel(state, channel, dedup_key, window_sec):
            return (False, state)
        return (True, state)
    last_key = state.get('last_report_dedup_key')
    last_utc = state.get('last_report_sent_at_utc')
    if _dedup_within_window(last_key, last_utc, dedup_key, window_sec):
        return (False, state)
    return (True, state)


# Resolve a writable queue directory with fallback to a stable degraded root and then ./reports_queue
def _resolve_queue_dir(medi_config):
    try:
        local_storage_path = medi_config.get('local_storage_path', '.') if isinstance(medi_config, dict) else '.'
    except Exception:
        local_storage_path = '.'
    primary = os.path.join(local_storage_path, 'reports_queue')
    if _ensure_dir(primary):
        return primary
    degraded_fallback = os.path.join(_get_degraded_storage_root(), 'reports_queue')
    if degraded_fallback != primary and _ensure_dir(degraded_fallback):
        try:
            mc_log("Queue directory fallback to {} due to path/permission issue.".format(degraded_fallback), level="WARNING")
            print("Falling back to {} for support bundles (check local_storage_path permissions).".format(degraded_fallback))
        except Exception:
            pass
        return degraded_fallback
    fallback = os.path.join('.', 'reports_queue')
    if _ensure_dir(fallback):
        try:
            mc_log("Queue directory fallback to ./reports_queue due to path/permission issue.", level="WARNING")
            print("Falling back to ./reports_queue for support bundles (check local_storage_path permissions).")
        except Exception:
            pass
        return fallback
    return primary


def _emit_progress(progress_callback, stage_label):
    """Best-effort coarse progress callback for long-running bundle/email operations."""
    try:
        from MediCafe.bundle_build_telemetry import telemetry_record_milestone
        telemetry_record_milestone(str(stage_label or '').strip(), subsystem='error_reporter')
    except Exception:
        pass
    try:
        from MediCafe.debug_bundle_perf import agent_log_progress_stage
        agent_log_progress_stage('bundle_heartbeat', stage_label)
    except Exception:
        pass
    if not callable(progress_callback):
        return
    try:
        progress_callback(str(stage_label or '').strip())
    except Exception:
        pass


def _flush_bundle_telemetry_log_line(telemetry_dict):
    """Write one-line bundle timing to run log and flush file handlers before log_tail capture."""
    try:
        from MediCafe.bundle_build_telemetry import (
            format_bundle_telemetry_log_line,
            resolve_bundle_telemetry_log_level,
        )
        line = format_bundle_telemetry_log_line(telemetry_dict)
        mc_log(line, level=resolve_bundle_telemetry_log_level(telemetry_dict))
    except Exception:
        pass
    try:
        import logging
        for h in logging.getLogger().handlers:
            flush_fn = getattr(h, 'flush', None)
            if callable(flush_fn):
                flush_fn()
    except Exception:
        pass


def _with_json_health_attachment(extra_files, config):
    out = list(extra_files or [])
    try:
        from MediCafe.json_health import get_latest_json_health_attachment
        json_health_attachment = get_latest_json_health_attachment(config=config)
        if not json_health_attachment:
            return out
        attachment_name = str(json_health_attachment[0] or '')
        existing_names = set()
        for item in out:
            try:
                existing_names.add(str(item[0] or ''))
            except Exception:
                continue
        if attachment_name and attachment_name in existing_names:
            return out
        out.append(json_health_attachment)
    except Exception:
        pass
    return out


def _dedupe_extra_files(extra_files):
    out = []
    seen_names = set()
    for item in extra_files or []:
        try:
            name, path_or_content = item
        except Exception:
            continue
        archive_name = _safe_ascii(name)
        if not archive_name:
            continue
        if archive_name in seen_names:
            try:
                mc_log('Skipping duplicate extra file attachment: {}'.format(archive_name), level='DEBUG')
            except Exception:
                pass
            continue
        seen_names.add(archive_name)
        out.append((archive_name, path_or_content))
    return out


def _format_epoch_utc(epoch_value):
    try:
        if epoch_value is None:
            return ''
        return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(int(epoch_value)))
    except Exception:
        return ''


_ATTACHMENT_STALE_AFTER_SEC = 86400


def _attachment_source_kind(archive_name):
    name = _safe_ascii(archive_name).lower()
    if name in ('diagnostics_state.json', 'run_cursor.json', 'cloud_health_diagnostics.json', 'cloud_health_tracker.json'):
        return 'current_live'
    if name.startswith('json_health_snapshot'):
        return 'historical_snapshot'
    if name.startswith('artifact_') or name.startswith('run_artifact_') or name.startswith('qa_') or name.startswith('shadow_run_report_'):
        return 'anchored_run'
    return 'attachment'


def _attachment_manifest_entry(archive_name, path_or_content, now_epoch):
    archive_name = _safe_ascii(archive_name)
    source_kind = _attachment_source_kind(archive_name)
    entry = {
        'archive_name': archive_name,
        'source_kind': source_kind,
        'generated_at_utc': '',
        'bundle_timestamp_utc': _format_epoch_utc(now_epoch),
        'freshness_status': 'inline_content',
    }
    try:
        if isinstance(path_or_content, str) and os.path.exists(path_or_content):
            mtime = float(os.path.getmtime(path_or_content))
            age_sec = int(max(0, int(now_epoch) - int(mtime)))
            entry['generated_at_utc'] = _format_epoch_utc(mtime)
            entry['age_sec'] = age_sec
            if source_kind == 'historical_snapshot' or age_sec > _ATTACHMENT_STALE_AFTER_SEC:
                entry['freshness_status'] = 'historical_snapshot'
            else:
                entry['freshness_status'] = 'current'
        elif isinstance(path_or_content, str) and (
                os.path.sep in path_or_content or (os.path.altsep and os.path.altsep in path_or_content)):
            entry['freshness_status'] = 'missing_path'
        elif isinstance(path_or_content, dict):
            entry['freshness_status'] = 'current_inline'
            generated = path_or_content.get('generated_at_utc') if isinstance(path_or_content, dict) else ''
            if generated:
                entry['generated_at_utc'] = _safe_ascii(generated)
    except Exception:
        entry['freshness_status'] = 'unknown'
    return entry


def _attachment_freshness_metadata(deduped_extra_files, now_epoch=None):
    """Summarize attachment mtime freshness without reading attachment content."""
    if now_epoch is None:
        try:
            now_epoch = time.time()
        except Exception:
            now_epoch = 0
    path_count = 0
    inline_count = 0
    mtimes = []
    missing_path_count = 0
    names = []
    manifest = []
    for name, path_or_content in deduped_extra_files or []:
        archive_name = _safe_ascii(name)
        if archive_name:
            names.append(archive_name)
        manifest.append(_attachment_manifest_entry(archive_name, path_or_content, now_epoch))
        try:
            if isinstance(path_or_content, str) and os.path.exists(path_or_content):
                path_count += 1
                try:
                    mtimes.append(float(os.path.getmtime(path_or_content)))
                except Exception:
                    pass
            elif isinstance(path_or_content, str) and (
                    os.path.sep in path_or_content or (os.path.altsep and os.path.altsep in path_or_content)):
                missing_path_count += 1
            else:
                inline_count += 1
        except Exception:
            inline_count += 1
    newest = max(mtimes) if mtimes else None
    oldest = min(mtimes) if mtimes else None
    max_age = None
    newest_age = None
    try:
        if oldest is not None:
            max_age = int(max(0, int(now_epoch) - int(oldest)))
        if newest is not None:
            newest_age = int(max(0, int(now_epoch) - int(newest)))
    except Exception:
        max_age = None
        newest_age = None
    if not deduped_extra_files:
        status = 'no_attachments'
    elif not mtimes:
        status = 'metadata_only'
    else:
        status = 'mtime_available'
    return {
        'schema_version': 1,
        'generated_at_utc': _format_epoch_utc(now_epoch),
        'attachment_count': len(deduped_extra_files or []),
        'file_path_attachment_count': path_count,
        'inline_attachment_count': inline_count,
        'missing_path_attachment_count': missing_path_count,
        'newest_attachment_mtime_utc': _format_epoch_utc(newest),
        'oldest_attachment_mtime_utc': _format_epoch_utc(oldest),
        'newest_attachment_age_sec': newest_age,
        'max_attachment_age_sec': max_age,
        'freshness_status': status,
        'attachment_manifest': manifest,
        'archive_names': names[:25],
        'archive_names_truncated': len(names) > 25,
    }


def _derive_evidence_scope(meta):
    meta = meta if isinstance(meta, dict) else {}
    ctx = meta.get('extra_context') if isinstance(meta.get('extra_context'), dict) else {}
    bundle_kind = _safe_ascii(meta.get('bundle_kind', '') or '')
    run_id = _safe_ascii(ctx.get('artifact_run_id', '') or ctx.get('run_id', '') or '')
    if ctx.get('run_evidence_bundle'):
        scope_kind = 'run_evidence'
        phase_scope = 'run_scoped'
    elif ctx.get('system_health_pack'):
        scope_kind = 'system_health'
        phase_scope = 'latest_available'
    elif ctx.get('cloud_health_failure'):
        scope_kind = 'cloud_health_failure'
        phase_scope = 'current_lab_state'
    elif ctx.get('orchestrator_failure_auto_report'):
        scope_kind = 'orchestrator_failure'
        phase_scope = 'current_lab_state'
    else:
        scope_kind = bundle_kind or 'error_report'
        phase_scope = 'mixed'
    diagnostics_scope = _safe_ascii(ctx.get('diagnostics_state_scope', '') or '')
    run_cursor_scope = _safe_ascii(ctx.get('run_cursor_scope', '') or '')
    log_tail_scope = _safe_ascii(ctx.get('log_tail_scope', '') or 'latest_application_log')
    if not diagnostics_scope and scope_kind == 'run_evidence':
        diagnostics_scope = 'lab_root_current'
    if not run_cursor_scope and scope_kind == 'run_evidence':
        run_cursor_scope = 'lab_root_current'
    mixed_note = ''
    if scope_kind == 'run_evidence':
        mixed_note = (
            'Phase artifacts are run-scoped; diagnostics_state, run_cursor, delivery status, '
            'and log tails may reflect current lab/application state.'
        )
    elif scope_kind == 'system_health':
        mixed_note = 'System health attachments represent latest/current lab state unless an anchor is stated.'
    default_coherence = 'review_required' if (
        scope_kind in ('run_evidence', 'cloud_health_failure') or phase_scope == 'mixed'
    ) else 'not_scored'
    result = {
        'schema_version': 1,
        'scope_kind': scope_kind,
        'bundle_kind': bundle_kind,
        'artifact_run_id': run_id,
        'anchor_run_id': _safe_ascii(ctx.get('anchor_run_id', '') or ctx.get('context_pack_anchor_run_id', '') or run_id),
        'active_run_id': _safe_ascii(ctx.get('active_run_id', '') or ''),
        'last_completed_run_id': _safe_ascii(ctx.get('last_completed_run_id', '') or ''),
        'phase_run_ids': _sanitize_extra_meta(ctx.get('phase_run_ids', {}) if isinstance(ctx.get('phase_run_ids', {}), dict) else {}),
        'coherence_status': _safe_ascii(ctx.get('coherence_status', '') or default_coherence),
        'phase_artifact_scope': phase_scope,
        'diagnostics_state_scope': diagnostics_scope,
        'run_cursor_scope': run_cursor_scope,
        'log_tail_scope': log_tail_scope,
        'context_pack_scope': _safe_ascii(ctx.get('context_pack_scope', '') or ''),
        'context_pack_anchor_run_id': _safe_ascii(ctx.get('context_pack_anchor_run_id', '') or ''),
        'mixed_scope_note': mixed_note,
        'scope_notes': mixed_note,
    }
    esc = ctx.get('evidence_scope')
    if isinstance(esc, dict):
        for key in ('anchor_run_id', 'artifact_run_id', 'coherence_status'):
            val = esc.get(key)
            if val:
                result[key] = _safe_ascii(str(val))
    return result


def _build_bundle_root_banner(meta, freshness, evidence_scope):
    meta = meta if isinstance(meta, dict) else {}
    freshness = freshness if isinstance(freshness, dict) else {}
    evidence_scope = evidence_scope if isinstance(evidence_scope, dict) else {}
    lines = [
        'MediCafe Support Bundle',
        '=' * 60,
        'bundle_kind={0}'.format(_safe_ascii(meta.get('bundle_kind', '') or '-')),
        'timestamp={0}'.format(_safe_ascii(meta.get('timestamp', '') or '-')),
        'scope_kind={0}'.format(_safe_ascii(evidence_scope.get('scope_kind', '') or '-')),
        'artifact_run_id={0}'.format(_safe_ascii(evidence_scope.get('artifact_run_id', '') or '-') or '-'),
        'phase_artifact_scope={0}'.format(_safe_ascii(evidence_scope.get('phase_artifact_scope', '') or '-')),
        'diagnostics_state_scope={0}'.format(_safe_ascii(evidence_scope.get('diagnostics_state_scope', '') or '-') or '-'),
        'run_cursor_scope={0}'.format(_safe_ascii(evidence_scope.get('run_cursor_scope', '') or '-') or '-'),
        'log_tail_scope={0}'.format(_safe_ascii(evidence_scope.get('log_tail_scope', '') or '-') or '-'),
        'attachment_count={0}'.format(freshness.get('attachment_count', 0)),
        'freshness_status={0}'.format(_safe_ascii(freshness.get('freshness_status', '') or '-')),
        'newest_attachment_mtime_utc={0}'.format(_safe_ascii(freshness.get('newest_attachment_mtime_utc', '') or '-') or '-'),
        'oldest_attachment_mtime_utc={0}'.format(_safe_ascii(freshness.get('oldest_attachment_mtime_utc', '') or '-') or '-'),
    ]
    note = _safe_ascii(evidence_scope.get('mixed_scope_note', '') or '')
    if note:
        lines.append('scope_note={0}'.format(note))
    lines.extend([
        '',
        'Machine-readable scope: evidence_scope.json (matches meta.json.evidence_scope).',
        'Read meta.json for full machine-readable context.',
    ])
    return '\n'.join(lines) + '\n'


def _evidence_manifest_zip_body(manifest):
    """Serialize manifest for evidence_manifest.json inside support ZIPs."""
    if not isinstance(manifest, dict):
        return None
    try:
        return json.dumps(manifest, ensure_ascii=True, indent=2, sort_keys=True)
    except (TypeError, ValueError):
        pass
    try:
        slim = {
            'schema_version': manifest.get('schema_version'),
            'request': manifest.get('request'),
            'scope': manifest.get('scope'),
            'validation': manifest.get('validation'),
            'missing_required_evidence': manifest.get('missing_required_evidence'),
            'operator_contract': manifest.get('operator_contract'),
        }
        return json.dumps(slim, ensure_ascii=True, indent=2, sort_keys=True)
    except Exception:
        return None


def _merge_evidence_manifest_extra_meta(extra_meta, evidence_manifest):
    """Merge manifest meta into caller meta; preserve caller-explicit bundle_kind."""
    out = {}
    if isinstance(extra_meta, dict):
        out.update(extra_meta)
    if evidence_manifest is None:
        return out
    try:
        from MediCafe import evidence_manifest as _em_manifest
        manifest_meta = _em_manifest.manifest_to_extra_meta(evidence_manifest)
    except Exception:
        manifest_meta = {}
    if not isinstance(manifest_meta, dict):
        return out
    for key, value in manifest_meta.items():
        if key == 'bundle_kind' and out.get('bundle_kind'):
            continue
        out[key] = value
    return out


def _attach_bundle_evidence_metadata(meta, deduped_extra_files):
    """Attach evidence_scope, attachment_freshness, and root banner metadata."""
    if not isinstance(meta, dict):
        return ''
    freshness = _attachment_freshness_metadata(deduped_extra_files)
    evidence_scope = _derive_evidence_scope(meta)
    meta['attachment_freshness'] = _sanitize_extra_meta(freshness)
    meta['evidence_scope'] = _sanitize_extra_meta(evidence_scope)
    meta['root_banner'] = {
        'archive_name': 'BUNDLE_README.txt',
        'schema_version': 1,
    }
    return _build_bundle_root_banner(meta, freshness, evidence_scope)


def _build_support_zip(zip_path, local_storage_path, max_log_lines, traceback_text, include_winscp, meta, claim_failure_summary=None, extra_files=None, progress_callback=None, evidence_manifest_for_zip=None):
    _emit_progress(progress_callback, 'reading latest log tail')
    log_selection = _select_support_bundle_log(local_storage_path)
    latest_log = str(log_selection.get('selected_log_path') or '')
    selected_log_name = os.path.basename(latest_log) if latest_log else ''
    log_tail = _tail_file(latest_log, max_log_lines) if latest_log else ''
    log_tail = _redact(log_tail)
    historical_logs = _select_historical_support_bundle_logs(local_storage_path, latest_log, limit=2)
    try:
        if isinstance(meta, dict):
            meta['selected_log_path'] = _safe_ascii(log_selection.get('selected_log_path', ''))
            meta['selected_log_name'] = _safe_ascii(log_selection.get('selected_log_name', ''))
            meta['selected_log_archive_name'] = _safe_ascii(selected_log_name)
            meta['selected_log_selection_strategy'] = _safe_ascii(
                log_selection.get('selected_log_selection_strategy', 'none')
            )
            meta['app_log_run_id'] = _safe_ascii(log_selection.get('app_log_run_id', ''))
            run_log_expected_path = _safe_ascii(log_selection.get('run_log_expected_path', ''))
            if run_log_expected_path:
                meta['run_log_expected_path'] = run_log_expected_path
            if historical_logs:
                meta['historical_log_tails'] = [_sanitize_extra_meta({
                    'archive_name': row.get('archive_name', ''),
                    'selected_log_path': row.get('path', ''),
                    'selected_log_name': row.get('name', ''),
                    'date_token': row.get('date_token', ''),
                    'run_index': row.get('run_index'),
                    'mtime': row.get('mtime'),
                    'selection_reason': row.get('selection_reason', ''),
                }) for row in historical_logs]
    except Exception:
        pass

    deduped_extra_files = _dedupe_extra_files(extra_files)
    root_banner_text = _attach_bundle_evidence_metadata(meta, deduped_extra_files)

    try:
        _emit_progress(progress_callback, 'writing zip bundle contents')
        # Remove any existing zip file to ensure we start fresh and don't include stale data
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except Exception:
                pass  # Continue even if removal fails
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('meta.json', json.dumps(meta, ensure_ascii=True, indent=2))
            em_body = _evidence_manifest_zip_body(evidence_manifest_for_zip)
            if em_body:
                z.writestr('evidence_manifest.json', _safe_ascii(em_body))
            scope_obj = meta.get('evidence_scope') if isinstance(meta.get('evidence_scope'), dict) else _derive_evidence_scope(meta)
            scope_written = dict(scope_obj) if isinstance(scope_obj, dict) else {}
            scope_written['schema_version'] = int(scope_written.get('schema_version') or 1)
            note = scope_written.get('mixed_scope_note') or scope_written.get('scope_notes') or ''
            scope_written['scope_notes'] = _safe_ascii(note)
            z.writestr('evidence_scope.json', json.dumps(_sanitize_extra_meta(scope_written), ensure_ascii=True, indent=2))
            if root_banner_text:
                z.writestr('BUNDLE_README.txt', _safe_ascii(root_banner_text))
            if latest_log and log_tail:
                z.writestr(_safe_ascii(selected_log_name or 'log_tail.txt'), log_tail)
            for row in historical_logs:
                hist_tail = _tail_file(str(row.get('path', '') or ''), max_log_lines)
                hist_tail = _redact(hist_tail)
                if hist_tail:
                    z.writestr(_safe_ascii(row.get('archive_name', '')), hist_tail)
            if traceback_text:
                z.writestr('traceback.txt', _redact(traceback_text))
            if include_winscp:
                upload_log = os.path.join(local_storage_path, 'winscp_upload.log')
                download_log = os.path.join(local_storage_path, 'winscp_download.log')
                winscp_logs = [(p, os.path.getmtime(p)) for p in [upload_log, download_log] if os.path.exists(p)]
                if winscp_logs:
                    latest_winscp = max(winscp_logs, key=lambda x: x[1])[0]
                    winscp_tail = _tail_file(latest_winscp, max_log_lines) if latest_winscp else ''
                    winscp_tail = _redact(winscp_tail)
                    if winscp_tail:
                        z.writestr('winscp_log_tail.txt', winscp_tail)
            if claim_failure_summary:
                # Write claim failure summary as a separate text file for easy reading
                # NOTE: This is generated fresh from the claim_failure_summary parameter, not read from disk
                summary_lines = [
                    'Claim Submission Failure Summary',
                    '=' * 60,
                    '',
                    'Total Failures: {}'.format(claim_failure_summary.get('total_failures', 0)),
                    'Total Successes: {}'.format(claim_failure_summary.get('total_successes', 0)),
                    '',
                    'Endpoints with Failures:',
                ]
                for endpoint in claim_failure_summary.get('endpoints_with_failures', []):
                    endpoint_data = claim_failure_summary.get('failures_by_endpoint', {}).get(endpoint, {})
                    summary_lines.append('  - {}: {} failure(s), {} success(es)'.format(
                        endpoint,
                        endpoint_data.get('failure_count', 0),
                        endpoint_data.get('success_count', 0)
                    ))
                summary_lines.extend([
                    '',
                    'Error Message Summary:',
                ])
                for error_msg in claim_failure_summary.get('error_message_summary', []):
                    # Use string concatenation instead of format to avoid issues if error_msg contains format chars
                    summary_lines.append('  - ' + str(error_msg))
                summary_text = '\n'.join(summary_lines)
                z.writestr('claim_failures_summary.txt', _safe_ascii(summary_text))
            if deduped_extra_files:
                _emit_progress(progress_callback, 'adding attachment files to zip')
                for name, path_or_content in deduped_extra_files:
                    try:
                        if isinstance(path_or_content, dict):
                            content = json.dumps(path_or_content, ensure_ascii=True, indent=2)
                        elif isinstance(path_or_content, str) and os.path.exists(path_or_content):
                            with open(path_or_content, 'r', encoding='utf-8') as f:
                                content = f.read()
                        else:
                            content = str(path_or_content)
                        z.writestr(name, _safe_ascii(content))
                    except Exception as ex:
                        mc_log('Failed to add extra file {0}: {1}'.format(name, ex), level='DEBUG')
        return True
    except Exception as e:
        mc_log('Error creating support bundle at {}: {}'.format(zip_path, e), level='ERROR')
        return False

# Centralized self-healing helpers for email reporting
def _attempt_gmail_reauth_interactive(max_wait_seconds=120):
    """
    Delegate to MediLink.MediLink_Gmail.ensure_authenticated_for_gmail_send to
    reuse existing OAuth/server logic without duplicating implementations.
    """
    try:
        from MediLink.MediLink_Gmail import ensure_authenticated_for_gmail_send
        return bool(ensure_authenticated_for_gmail_send(max_wait_seconds=max_wait_seconds))
    except Exception as e:
        try:
            mc_log("Failed to initiate Gmail re-authorization: {0}".format(e), level="ERROR")
        except Exception:
            pass
        return False


def _probe_gmail_access_token_validity(access_token, timeout_seconds=8):
    """
    Best-effort token validity probe against Google's tokeninfo endpoint.
    Returns:
      True  -> token is valid
      False -> token is invalid
      None  -> inconclusive (network/transient issue)
    """
    if not access_token:
        return None
    try:
        resp = requests.get(
            GMAIL_TOKENINFO_URL,
            params={'access_token': access_token},
            timeout=timeout_seconds,
        )
    except Exception as e:
        try:
            mc_log("Gmail token validity probe skipped due to request error: {0}".format(e), level="DEBUG")
        except Exception:
            pass
        return None
    if resp.status_code == 200:
        return True
    try:
        body_lower = (resp.text or '').lower()
    except Exception:
        body_lower = ''
    if resp.status_code == 400 and 'invalid_token' in body_lower:
        return False
    try:
        mc_log("Gmail token validity probe inconclusive (HTTP {}).".format(resp.status_code), level="DEBUG")
    except Exception:
        pass
    return None


def _clear_gmail_token_cache_safely():
    try:
        clear_gmail_token_cache(log=mc_log)
        return True
    except Exception as e:
        try:
            mc_log("Failed to clear Gmail token cache: {0}".format(e), level="WARNING")
        except Exception:
            pass
        return False


def _resolve_gmail_access_token_via_runbook(skip_interactive_reauth=False, force_reauth=False, max_wait_seconds=120, reason='send', progress_callback=None):
    """
    DRY Gmail auth recovery runbook used by all support-bundle send flows.
    Returns (access_token_or_none, meta) where meta classifies delivery_state / issue codes.
    """
    meta = _default_support_delivery_meta()
    token = None
    try:
        _emit_progress(progress_callback, 'checking Gmail token')
        if not force_reauth:
            outcome = get_gmail_access_token_outcome(log=mc_log, quiet=True)
            meta['auth_taxonomy'] = str(outcome.get('taxonomy') or '')
            meta['reauth_required'] = bool(outcome.get('reauth_required'))
            token = outcome.get('access_token')
            if meta['auth_taxonomy'] in (
                REFRESH_TAXONOMY_INVALID_GRANT,
                'missing_token_file',
                'missing_refresh_token',
                'invalid_token_structure',
            ):
                meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED

            if token:
                validity = _probe_gmail_access_token_validity(token)
                if validity is True:
                    meta['delivery_state'] = 'token_ready'
                    return token, meta
                if validity is None:
                    # Inconclusive probe (network/transient). Do not clear cache or force
                    # interactive re-auth; the access token may still be valid for Gmail API.
                    try:
                        mc_log(
                            "Gmail token validity probe inconclusive; continuing with cached token (reason: {}).".format(
                                reason
                            ),
                            level="WARNING",
                        )
                    except Exception:
                        pass
                    meta['delivery_state'] = 'token_ready_probe_inconclusive'
                    return token, meta
                try:
                    mc_log(
                        "Gmail token probe reported token invalid (reason: {}). Clearing cache and recovering.".format(reason),
                        level="WARNING"
                    )
                except Exception:
                    pass
                _clear_gmail_token_cache_safely()
                meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
                token = None
            elif meta.get('delivery_issue_code') == SUPPORT_DELIVERY_REAUTH_REQUIRED:
                pass
            else:
                meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
        else:
            _clear_gmail_token_cache_safely()
            meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED

        if skip_interactive_reauth:
            try:
                mc_log(
                    "Gmail auth runbook paused before interactive re-auth (reason: {}, skip_interactive_reauth=True).".format(reason),
                    level="INFO"
                )
            except Exception:
                pass
            meta['delivery_state'] = 'paused_waiting_for_operator_reauth'
            return None, meta

        try:
            mc_log("Running Gmail auth recovery runbook (reason: {}).".format(reason), level="INFO")
        except Exception:
            pass
        _emit_progress(progress_callback, 'waiting for Gmail sign-in')
        if not _attempt_gmail_reauth_interactive(max_wait_seconds=max_wait_seconds):
            meta['delivery_state'] = 'reauth_prompt_failed'
            meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
            return None, meta

        outcome2 = get_gmail_access_token_outcome(log=mc_log, quiet=True)
        meta['auth_taxonomy'] = str(outcome2.get('taxonomy') or '')
        meta['reauth_required'] = bool(outcome2.get('reauth_required'))
        token = outcome2.get('access_token')
        if not token:
            meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
            meta['delivery_state'] = 'reauth_no_token_after_prompt'
            return None, meta

        validity = _probe_gmail_access_token_validity(token)
        if validity is False:
            _clear_gmail_token_cache_safely()
            meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
            meta['delivery_state'] = 'token_probe_failed_after_reauth'
            return None, meta
        if validity is None:
            try:
                mc_log(
                    "Gmail token validity probe inconclusive after re-auth; continuing with new token (reason: {}).".format(
                        reason
                    ),
                    level="WARNING",
                )
            except Exception:
                pass
            meta['delivery_state'] = 'token_ready_after_reauth_probe_inconclusive'
            return token, meta
        meta['delivery_state'] = 'token_ready'
        return token, meta
    except Exception as e:
        try:
            mc_log("Gmail auth recovery runbook failed: {0}".format(e), level="ERROR")
        except Exception:
            pass
        meta['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
        meta['delivery_state'] = 'runbook_exception'
        return None, meta


def _run_queued_bundle_self_resolution(max_wait_seconds=120):
    """
    Embedded queue-delivery runbook:
      - Ensure Gmail auth is healthy
      - Attempt to drain queued bundles in-process
    """
    queued = list_queued_bundles()
    if not queued:
        return True

    # Reuse one auth session across queued sends so token recovery is not repeated per bundle.
    sent, failed = submit_all_queued_bundles(
        queued=queued,
        show_names=False,
        auth_session={},
        skip_interactive_reauth=False,
        reauth_wait_seconds=max_wait_seconds,
    )
    try:
        mc_log(
            "Queued bundle runbook complete. Sent: {} Failed: {}.".format(sent, failed),
            level="INFO" if failed == 0 else "WARNING",
        )
    except Exception:
        pass
    return failed == 0 and sent > 0

# _compute_report_id removed (unused)


def _collect_certificate_authority_metadata(config=None):
    """
    Safely collect certificate authority metadata for support bundles.
    
    Returns a dict with CA mode, status, and metadata if available.
    Handles all import/runtime errors gracefully.
    """
    ca_meta = {
        'mode': None,
        'managed': False,
        'status': None
    }
    
    try:
        # Get certificate provider config from MediLink_ConfigLoader
        from MediCafe.MediLink_ConfigLoader import get_certificate_provider_config
        provider_config = get_certificate_provider_config(config)
        
        if provider_config:
            ca_meta['mode'] = _safe_ascii(provider_config.get('mode', 'self_signed'))
            ca_meta['managed'] = bool(provider_config.get('mode') == 'managed_ca')
            
            # If managed CA is enabled, try to get detailed status
            if ca_meta['managed']:
                try:
                    # Try to import and get CA status from MediLink_Gmail
                    from MediLink.MediLink_Gmail import get_managed_ca_status
                    ca_status = get_managed_ca_status(refresh=False)
                    
                    if ca_status and isinstance(ca_status, dict):
                        # Extract key fields for support bundle
                        status_summary = {
                            'profile': _safe_ascii(ca_status.get('profile', 'unknown')),
                            'storage': _safe_ascii(str(ca_status.get('storage', ''))),
                            'san': [str(s) for s in ca_status.get('san', [])] if isinstance(ca_status.get('san'), list) else [],
                        }
                        
                        # Extract root certificate details
                        root_info = ca_status.get('root', {})
                        if root_info and isinstance(root_info, dict):
                            status_summary['root'] = {
                                'present': bool(root_info.get('present', False)),
                                'subject': _safe_ascii(str(root_info.get('subject', ''))),
                                'notAfter': _safe_ascii(str(root_info.get('notAfter', ''))),
                                'serial': _safe_ascii(str(root_info.get('serial', '')))
                            }
                        
                        # Extract server certificate details
                        server_info = ca_status.get('server', {})
                        if server_info and isinstance(server_info, dict):
                            status_summary['server'] = {
                                'present': bool(server_info.get('present', False)),
                                'subject': _safe_ascii(str(server_info.get('subject', ''))),
                                'notAfter': _safe_ascii(str(server_info.get('notAfter', ''))),
                                'serial': _safe_ascii(str(server_info.get('serial', '')))
                            }
                        
                        ca_meta['status'] = status_summary
                        
                        # Add provider config fields that are safe to include
                        if provider_config.get('root_subject'):
                            ca_meta['root_subject'] = _safe_ascii(str(provider_config.get('root_subject')))
                        if provider_config.get('server_subject'):
                            ca_meta['server_subject'] = _safe_ascii(str(provider_config.get('server_subject')))
                        if provider_config.get('san'):
                            san_list = provider_config.get('san')
                            if isinstance(san_list, list):
                                ca_meta['san'] = [str(s) for s in san_list]
                except Exception as status_err:
                    # CA status unavailable - log but continue
                    try:
                        mc_log('CA status collection failed (non-fatal): {}'.format(status_err), level='DEBUG')
                    except Exception:
                        pass
                    ca_meta['status_error'] = _safe_ascii(str(status_err))
    except Exception as e:
        # Certificate provider config unavailable - this is non-fatal
        try:
            mc_log('CA metadata collection failed (non-fatal): {}'.format(e), level='DEBUG')
        except Exception:
            pass
        ca_meta['error'] = _safe_ascii(str(e))
    
    return ca_meta


def collect_support_bundle(include_traceback=True, max_log_lines=500, claim_failure_summary=None,
					   insurance_type_mapping=None, extra_meta=None, extra_files=None, progress_callback=None, evidence_manifest=None):
    runtime = _get_error_reporter_runtime_context()
    config = runtime.get('config', {})
    medi = runtime.get('medi', {})
    local_storage_path = medi.get('local_storage_path', _get_degraded_storage_root())
    queue_dir = _resolve_queue_dir(medi)

    extra_meta = _merge_evidence_manifest_extra_meta(extra_meta, evidence_manifest)

    stamp = time.strftime('%Y%m%d_%H%M%S')
    bundle_kind = resolve_bundle_kind(extra_meta, claim_failure_summary=bool(claim_failure_summary))
    zip_path = os.path.join(queue_dir, 'medicafe_bundle_{}_{}.zip'.format(bundle_kind, stamp))

    traceback_txt = ''
    if include_traceback:
        try:
            trace_path = os.path.join(local_storage_path, 'traceback.txt')
            if os.path.exists(trace_path):
                with open(trace_path, 'r') as tf:
                    traceback_txt = tf.read()
        except Exception:
            traceback_txt = ''

    # Build error summary - prioritize claim failure info when provided (it's current/contextual)
    # When claim_failure_summary is provided, it represents the current error context
    if claim_failure_summary:
        failure_info = 'Claim submission failures detected: {} failure(s), {} success(es)'.format(
            claim_failure_summary.get('total_failures', 0),
            claim_failure_summary.get('total_successes', 0)
        )
        # Include traceback first line only if it exists and appears relevant (same error context)
        traceback_summary = _safe_ascii(_first_line(traceback_txt))
        if traceback_summary:
            error_summary = '{} | {}'.format(failure_info, traceback_summary)
        else:
            error_summary = failure_info
    else:
        # No claim failure summary - use traceback if available
        error_summary = _safe_ascii(_first_line(traceback_txt))

    # Override error_summary when provided in extra_meta (e.g. Phase A context)
    if extra_meta and isinstance(extra_meta.get('error_summary'), str):
        error_summary = _safe_ascii(extra_meta.get('error_summary'))

    meta = {
        'app_version': _safe_ascii(_get_version()),
        'python_version': _safe_ascii(sys.version.split(' ')[0]),
        'platform': _safe_ascii(platform.platform()),
        'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
        'error_summary': error_summary,
        'traceback_present': bool(traceback_txt),
        'bundle_kind': bundle_kind,
        'config_flags': {
            'console_logging': bool(medi.get('logging', {}).get('console_output', False)),
            'test_mode': bool(medi.get('TestMode', False))
        }
    }
    
    # Include claim failure summary in meta.json if provided
    if claim_failure_summary:
        meta['claim_failure_summary'] = claim_failure_summary
    
    # Include insurance type mapping in meta.json if provided (silent monitoring)
    if insurance_type_mapping and isinstance(insurance_type_mapping, dict) and insurance_type_mapping:
        meta['insurance_type_mapping'] = insurance_type_mapping
    
    # Attach caller-provided context to enrich diagnostics
    if extra_meta:
        try:
            meta['extra_context'] = _sanitize_extra_meta(extra_meta)
        except Exception as extra_err:
            meta['extra_context_error'] = _safe_ascii(extra_err)

    _attach_config_loader_meta(meta, runtime.get('diagnostics', {}))

    # Best-effort read-only self-test summary for support metadata. Never block
    # bundle creation if the registry is unavailable or a check fails internally.
    try:
        from MediCafe.self_test_registry import collect_self_test_summary
        self_test_summary = collect_self_test_summary(runtime_context=runtime)
        if self_test_summary:
            meta['self_test_summary'] = self_test_summary
    except Exception:
        pass

    # Include certificate authority metadata for remote triage
    try:
        ca_metadata = _collect_certificate_authority_metadata(config)
        if ca_metadata:
            meta['certificateAuthority'] = ca_metadata
    except Exception as ca_err:
        # Non-fatal - continue without CA metadata if collection fails
        try:
            mc_log('Failed to collect CA metadata for support bundle (non-fatal): {}'.format(ca_err), level='DEBUG')
        except Exception:
            pass

    merged_extra_files = extra_files
    if evidence_manifest is not None:
        try:
            from MediCafe import evidence_manifest as _em_manifest
            merged_extra_files = _em_manifest.merge_extra_files(
                _em_manifest.manifest_to_extra_files(evidence_manifest),
                extra_files or [],
            )
        except Exception:
            merged_extra_files = extra_files

    bundle_extra_files = _with_json_health_attachment(merged_extra_files, config)

    try:
        from MediCafe.bundle_build_telemetry import (
            telemetry_ensure_started_from_extra_meta,
            telemetry_merge_collect_counts,
        )
        telemetry_ensure_started_from_extra_meta(extra_meta, bundle_kind)
        telemetry_merge_collect_counts(len(bundle_extra_files) if bundle_extra_files else 0, max_log_lines)
    except Exception:
        pass

    _emit_progress(progress_callback, 'creating zip bundle')
    try:
        from MediCafe.bundle_build_telemetry import telemetry_finalize_for_meta
        tel = telemetry_finalize_for_meta(bundle_kind)
        meta['bundle_build_telemetry'] = tel
        _flush_bundle_telemetry_log_line(tel)
    except Exception:
        pass

    _annotate_support_job_self_observation(meta, extra_meta, medi)

    ok = _build_support_zip(
        zip_path,
        local_storage_path,
        max_log_lines,
        traceback_txt,
        True,
        meta,
        claim_failure_summary,
        bundle_extra_files,
        progress_callback=progress_callback,
        evidence_manifest_for_zip=evidence_manifest if isinstance(evidence_manifest, dict) else None,
    )
    try:
        from MediCafe.debug_bundle_perf import agent_log_bundle_event
        agent_log_bundle_event(
            'collect_support_bundle_exit',
            'error_reporter.collect_support_bundle',
            {
                'ok': bool(ok),
                'zip_basename': os.path.basename(zip_path) if zip_path else '',
            },
            hypothesis_id='H1',
        )
    except Exception:
        pass
    return zip_path if ok else None


def collect_test_support_bundle(max_log_lines=500):
    """
    Build a manual support self-test bundle using latest logs, a placeholder
    traceback, and bounded read-only self-test results.

    Returns absolute path to the created ZIP, or None on failure.
    """
    try:
        runtime = _get_error_reporter_runtime_context()
        config = runtime.get('config', {})
        medi = runtime.get('medi', {})
        local_storage_path = medi.get('local_storage_path', _get_degraded_storage_root())
        queue_dir = _resolve_queue_dir(medi)

        stamp = time.strftime('%Y%m%d_%H%M%S')
        zip_path = os.path.join(queue_dir, 'medicafe_bundle_test_{}.zip'.format(stamp))

        # Build a placeholder traceback - ASCII-only, no real data
        fake_tb = (
            "Traceback (most recent call last):\n"
            "  File \"MediCafe/test_runner.py\", line 42, in <module>\n"
            "  File \"MediCafe/error_reporter.py\", line 123, in simulate_error\n"
            "Exception: This is a TEST placeholder traceback for pipeline verification only.\n"
            "-- No real patient or PHI data is included. --\n"
        )
        self_test_report = None
        self_test_summary = None
        try:
            from MediCafe.self_test_registry import run_self_tests
            self_test_report = run_self_tests(runtime_context=runtime, include_results=True)
            self_test_summary = dict(self_test_report)
            if 'results' in self_test_summary:
                del self_test_summary['results']
        except Exception as self_test_err:
            self_test_summary = {
                'schema_version': 1,
                'registry_version': 0,
                'check_count': 0,
                'pass_count': 0,
                'fail_count': 1,
                'warning_count': 0,
                'failing_check_ids': ['self_test_registry.unavailable'],
                'warning_check_ids': [],
                'collection_error': _safe_ascii(self_test_err),
            }
            self_test_report = {
                'summary': self_test_summary,
                'results': [],
            }

        meta = {
            'app_version': _safe_ascii(_get_version()),
            'python_version': _safe_ascii(sys.version.split(' ')[0]),
            'platform': _safe_ascii(platform.platform()),
            'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'error_summary': 'Manual support self-test bundle',
            'traceback_present': True,
            'bundle_kind': 'test',
            'self_test_summary': self_test_summary,
            'config_flags': {
                'console_logging': bool(medi.get('logging', {}).get('console_output', False)),
                'test_mode': True
            }
        }
        _attach_config_loader_meta(meta, runtime.get('diagnostics', {}))
        self_test_readme = (
            'MediCafe Manual Support Self-Test\n'
            '=================================\n\n'
            'This bundle was created from the Troubleshooting menu. It exercises the support\n'
            'submission pipeline and includes bounded read-only self-test results in\n'
            'self_test_report.json and meta.json:self_test_summary.\n'
        )
        extra_files = [
            ('self_test_report.json', self_test_report),
            ('SELF_TEST_README.txt', self_test_readme),
        ]
        ok = _build_support_zip(zip_path, local_storage_path, max_log_lines, fake_tb, True, meta, extra_files=extra_files)
        return zip_path if ok else None
    except Exception as e:
        try:
            mc_log('Error creating TEST support bundle: {}'.format(e), level='ERROR')
        except Exception:
            pass
        return None


def _first_line(text):
	try:
		for line in (text or '').splitlines():
			line = line.strip()
			if line:
				return line[:200]
		return ''
	except Exception:
		return ''


def _get_version():
	try:
		from MediCafe import __version__
		return __version__
	except Exception:
		return 'unknown'


_DEFAULT_SUBJECT_PREFIX = 'MediCafe Error Report'
_BUNDLE_KIND_SLUG_RE = re.compile(r'^[a-z0-9_]{1,48}$')
_SUBJECT_TOKEN_RE = re.compile(r'[^A-Za-z0-9_.-]+')

# First matching extra_meta flag wins (explicit bundle_kind string handled separately).
_BUNDLE_KIND_ORDER = (
    ('run_evidence_bundle', 'run_evidence_bundle'),
    ('system_health_pack', 'system_health_pack'),
    ('orchestrator_failure_auto_report', 'orchestrator_failure'),
    ('cloud_health_failure', 'cloud_health_escalation'),
    ('cloud_readiness_import_failure', 'cloud_readiness_import'),
    ('phase_f_evidence', 'phase_f_evidence'),
    ('phase_f_report', 'phase_f_evidence'),
    ('phase_e_evidence', 'phase_e_evidence'),
    ('phase_d_evidence', 'phase_d_evidence'),
    ('phase_c_evidence', 'phase_c_evidence'),
    ('phase_b_evidence', 'phase_b_evidence'),
    ('phase_a_failure', 'phase_a_bootstrap_report'),
    ('phase_b_failure', 'phase_b_pipeline_report'),
    ('phase_c_failure', 'phase_c_pipeline_report'),
    ('phase_d_failure', 'phase_d_pipeline_report'),
    ('phase_e_failure', 'phase_e_pipeline_report'),
    ('pipeline_failure', 'pipeline_failure_report'),
)

# slug -> (short email title, body line with {fname}, success line)
_BUNDLE_KIND_LABELS = {
    'error_report': ('Error Report', 'Error report attached ({fname}).', 'Error report sent successfully. You do not need to send another report.'),
    'claim_submission_report': ('Claim Submission Report', 'Claim submission diagnostic bundle attached ({fname}).', 'Claim submission report sent successfully.'),
    'run_evidence_bundle': ('Run Evidence Bundle', 'Run-scoped lab evidence bundle attached ({fname}).', 'Run evidence bundle sent successfully.'),
    'system_health_pack': ('System Health Pack', 'System health pack attached ({fname}).', 'System health pack sent successfully.'),
    'orchestrator_failure': ('Orchestrator Failure Report', 'Shadow orchestrator failure bundle attached ({fname}).', 'Orchestrator failure report sent successfully.'),
    'cloud_health_escalation': ('Cloud Health Escalation', 'Cloud health escalation bundle attached ({fname}).', 'Cloud health escalation bundle sent successfully.'),
    'cloud_readiness_import': ('Cloud Readiness Import Failure', 'Cloud readiness import failure bundle attached ({fname}).', 'Support bundle sent successfully.'),
    'phase_f_evidence': ('Phase F Evidence', 'Phase F evidence bundle attached ({fname}).', 'Phase F evidence bundle sent successfully.'),
    'phase_e_evidence': ('Phase E Evidence', 'Phase E evidence bundle attached ({fname}).', 'Phase E evidence bundle sent successfully.'),
    'phase_d_evidence': ('Phase D Evidence', 'Phase D evidence bundle attached ({fname}).', 'Phase D evidence bundle sent successfully.'),
    'phase_c_evidence': ('Phase C Evidence', 'Phase C evidence bundle attached ({fname}).', 'Phase C evidence bundle sent successfully.'),
    'phase_b_evidence': ('Phase B Evidence', 'Phase B evidence bundle attached ({fname}).', 'Phase B evidence bundle sent successfully.'),
    'phase_a_bootstrap_report': ('Phase A Bootstrap Report', 'Phase A bootstrap failure bundle attached ({fname}).', 'Phase A bootstrap report sent successfully.'),
    'phase_b_pipeline_report': ('Phase B Pipeline Report', 'Phase B pipeline failure bundle attached ({fname}).', 'Phase B pipeline report sent successfully.'),
    'phase_c_pipeline_report': ('Phase C Pipeline Report', 'Phase C pipeline failure bundle attached ({fname}).', 'Phase C pipeline report sent successfully.'),
    'phase_d_pipeline_report': ('Phase D Pipeline Report', 'Phase D pipeline failure bundle attached ({fname}).', 'Phase D pipeline report sent successfully.'),
    'phase_e_pipeline_report': ('Phase E Pipeline Report', 'Phase E pipeline failure bundle attached ({fname}).', 'Phase E pipeline report sent successfully.'),
    'config_write_contention': (
        'Config Write Contention',
        'Config write / permission diagnostic bundle attached ({fname}).',
        'Config write diagnostic bundle sent successfully.',
    ),
    'pipeline_failure_report': ('Pipeline Failure Report', 'Pipeline failure bundle attached ({fname}).', 'Pipeline failure report sent successfully.'),
    'test': ('Support Self-Test Bundle', 'Support self-test bundle attached ({fname}).', 'Support self-test bundle sent successfully.'),
}


def _normalize_bundle_kind_slug(raw):
    if not raw or not isinstance(raw, str):
        return ''
    s = raw.strip().lower().replace('-', '_')
    if not _BUNDLE_KIND_SLUG_RE.match(s):
        return ''
    return s


def _extra_meta_truthy(meta, key):
    if not isinstance(meta, dict):
        return False
    v = meta.get(key)
    if v is True:
        return True
    if isinstance(v, str) and v.strip().lower() in ('true', '1', 'yes'):
        return True
    return False


def resolve_bundle_kind(extra_meta=None, claim_failure_summary=False):
    """
    Determine bundle_kind slug for ZIP naming and email labeling.
    Caller may set extra_meta['bundle_kind'] to override (ASCII slug).
    """
    if isinstance(extra_meta, dict):
        override = extra_meta.get('bundle_kind')
        if isinstance(override, str):
            slug = _normalize_bundle_kind_slug(override)
            if slug:
                return slug
        for key, slug in _BUNDLE_KIND_ORDER:
            if _extra_meta_truthy(extra_meta, key):
                return slug
    if claim_failure_summary:
        return 'claim_submission_report'
    return 'error_report'


def _read_bundle_kind_from_zip(zip_path):
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            if 'meta.json' not in zf.namelist():
                return ''
            raw = zf.read('meta.json').decode('utf-8', 'ignore')
            data = json.loads(raw)
            if not isinstance(data, dict):
                return ''
            k = data.get('bundle_kind')
            if isinstance(k, str):
                return _normalize_bundle_kind_slug(k) or ''
    except Exception:
        return ''
    return ''


def _bundle_kind_from_zip_or_meta(zip_path, extra_meta):
    if isinstance(extra_meta, dict):
        override = extra_meta.get('bundle_kind')
        if isinstance(override, str):
            slug = _normalize_bundle_kind_slug(override)
            if slug:
                return slug
        for key, slug in _BUNDLE_KIND_ORDER:
            if _extra_meta_truthy(extra_meta, key):
                return slug
    if zip_path and os.path.isfile(zip_path):
        from_zip = _read_bundle_kind_from_zip(zip_path)
        if from_zip:
            return from_zip
    return 'error_report'


def _normalize_subject_token(raw, lowercase=False, max_length=80):
    if raw is None:
        return ''
    try:
        text = _safe_ascii(raw).strip()
    except Exception:
        text = str(raw).strip()
    if not text:
        return ''
    if lowercase:
        text = text.lower()
    text = _SUBJECT_TOKEN_RE.sub('_', text).strip('._-')
    if not text:
        return ''
    return text[:max_length]


def _subject_context_from_meta_dict(meta):
    result = {'run_id': '', 'send_source': ''}
    if not isinstance(meta, dict):
        return result
    candidates = [meta]
    extra_context = meta.get('extra_context')
    if isinstance(extra_context, dict):
        candidates.append(extra_context)
    run_id_keys = (
        'run_id',
        'artifact_run_id',
        'pipeline_run_id',
        'anchor_run_id',
        'context_pack_anchor_run_id',
    )
    for candidate in candidates:
        for key in run_id_keys:
            run_id = _normalize_subject_token(candidate.get(key), lowercase=False, max_length=96)
            if run_id:
                result['run_id'] = run_id
                break
        if result['run_id']:
            break
    for candidate in candidates:
        send_source = _normalize_subject_token(candidate.get('send_source'), lowercase=True, max_length=48)
        if send_source:
            result['send_source'] = send_source
            break
    return result


def _read_subject_context_from_zip(zip_path):
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            if 'meta.json' not in zf.namelist():
                return {'run_id': '', 'send_source': ''}
            raw = zf.read('meta.json').decode('utf-8', 'ignore')
            data = json.loads(raw)
            return _subject_context_from_meta_dict(data)
    except Exception:
        return {'run_id': '', 'send_source': ''}


def _compose_email_subject(bundle_kind, subject_prefix, timestamp_suffix, run_id='', send_source=''):
    """subject_prefix is config default e.g. MediCafe Error Report; bundle_kind drives non-incident titles."""
    labels = _BUNDLE_KIND_LABELS
    title = labels.get(bundle_kind, ('Support Bundle', '', ''))[0]
    prefix = (subject_prefix or _DEFAULT_SUBJECT_PREFIX).strip()
    if bundle_kind == 'error_report':
        subject = '{} - {}'.format(prefix, timestamp_suffix)
    else:
        brand = prefix
        for suf in (' Error Report', ' error report'):
            if brand.endswith(suf):
                brand = brand[:-len(suf)].strip()
                break
        if not brand:
            brand = 'MediCafe'
        subject = '{} {} - {}'.format(brand, title, timestamp_suffix)
    details = []
    normalized_run_id = _normalize_subject_token(run_id, lowercase=False, max_length=96)
    normalized_send_source = _normalize_subject_token(send_source, lowercase=True, max_length=48)
    if normalized_run_id:
        details.append('run_id={0}'.format(normalized_run_id))
    if normalized_send_source:
        details.append('source={0}'.format(normalized_send_source))
    if details:
        return '{} [{}]'.format(subject, ' '.join(details))
    return subject


def _bundle_email_body_and_success(bundle_kind, attachment_basename):
    labels = _BUNDLE_KIND_LABELS.get(bundle_kind) or _BUNDLE_KIND_LABELS['error_report']
    _, body_t, ok_t = labels
    fname = attachment_basename or 'bundle.zip'
    body = body_t.format(fname=fname)
    return body, ok_t


def capture_unhandled_traceback(exc_type, exc_value, exc_traceback):
	try:
		runtime = _get_error_reporter_runtime_context()
		local_storage_path = runtime.get('medi', {}).get('local_storage_path', _get_degraded_storage_root())
		_ensure_dir(local_storage_path)
		trace_path = os.path.join(local_storage_path, 'traceback.txt')
		text = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
		text = _redact(text)
		with open(trace_path, 'w') as f:
			f.write(text)
		print("An error occurred. A traceback was saved to {}".format(trace_path))
	except Exception:
		try:
			mc_log('Failed to capture traceback to file', level='WARNING')
		except Exception:
			pass

def submit_support_bundle_email(zip_path=None, include_traceback=True, skip_interactive_reauth=False, extra_meta=None, extra_files=None, auth_session=None, reauth_wait_seconds=120, progress_callback=None, evidence_manifest=None):
    if not zip_path:
        _emit_progress(progress_callback, 'creating zip bundle')
        zip_path = collect_support_bundle(
            include_traceback,
            extra_meta=extra_meta,
            extra_files=extra_files,
            progress_callback=progress_callback,
            evidence_manifest=evidence_manifest,
        )
        if not zip_path:
            mc_log("Failed to create bundle.", level="ERROR")
            try:
                print("Failed to create support bundle. Ensure 'MediLink_Config.local_storage_path' is writable and logs exist.")
            except Exception:
                pass
            return False
    bundle_size = os.path.getsize(zip_path)
    trace = _default_support_delivery_meta()
    trace['send_succeeded'] = False
    if evidence_manifest is not None:
        try:
            trace['evidence_manifest_schema_version'] = evidence_manifest.get('schema_version')
            _em_meta = None
            try:
                from MediCafe import evidence_manifest as _em_manifest
                _em_meta = _em_manifest.manifest_to_extra_meta(evidence_manifest)
            except Exception:
                _em_meta = {}
            if isinstance(_em_meta, dict):
                if _em_meta.get('attachment_contract_status'):
                    trace['attachment_contract_status'] = str(_em_meta.get('attachment_contract_status') or '')
            req_snap = evidence_manifest.get('request')
            if isinstance(req_snap, dict) and req_snap.get('bundle_kind'):
                trace['evidence_bundle_kind'] = str(req_snap.get('bundle_kind') or '')
        except Exception:
            pass
    runtime = _get_error_reporter_runtime_context()
    config = runtime.get('config', {})
    medi = runtime.get('medi', {})
    email_config = medi.get('error_reporting', {}).get('email', {}) if isinstance(medi.get('error_reporting', {}), dict) else {}
    try:
        send_timeout_seconds = int(email_config.get('send_timeout_seconds', 15))
    except Exception:
        send_timeout_seconds = 15
    if send_timeout_seconds < 1:
        send_timeout_seconds = 15
    # Determine max size from config with default 1.5MB
    try:
        max_bytes = int(email_config.get('max_bundle_bytes', 1572864))
    except Exception:
        max_bytes = 1572864
    if bundle_size > max_bytes:
        mc_log("Bundle too large ({} bytes > {} bytes) - leaving in queue.".format(bundle_size, max_bytes), level="WARNING")
        try:
            print("Bundle too large to email ({} KB > {} KB). Left in 'reports_queue'. Path: {}".format(int(bundle_size/1024), int(max_bytes/1024), zip_path))
            print("Attempting to create and send a smaller LITE bundle (reduced logs, no traceback).")
        except Exception:
            pass
        # Repack prebuilt ZIP first (preserve bundle_kind + evidence); then log-only LITE fallback
        lite_zip = None
        lite_size = -1
        if os.path.isfile(zip_path):
            lite_zip = repack_support_bundle_lite_from_zip(zip_path)
        if lite_zip and os.path.exists(lite_zip):
            try:
                lite_size = os.path.getsize(lite_zip)
            except Exception:
                lite_size = -1
        if not (lite_zip and 0 < lite_size <= max_bytes):
            merged_meta = _merge_extra_meta_with_bundle_kind_from_zip(zip_path, extra_meta)
            _emit_progress(progress_callback, 'creating lightweight zip bundle')
            lite_zip = collect_support_bundle_lite(
                max_log_lines=200,
                extra_meta=merged_meta,
                extra_files=extra_files,
                evidence_manifest=evidence_manifest,
            )
            if lite_zip and os.path.exists(lite_zip):
                try:
                    lite_size = os.path.getsize(lite_zip)
                except Exception:
                    lite_size = -1
        if lite_zip and os.path.exists(lite_zip) and 0 < lite_size <= max_bytes:
            return submit_support_bundle_email(
                zip_path=lite_zip,
                include_traceback=False,
                skip_interactive_reauth=skip_interactive_reauth,
                extra_meta=None,
                extra_files=None,
                progress_callback=progress_callback,
                evidence_manifest=evidence_manifest,
            )
        if lite_zip and os.path.exists(lite_zip):
            try:
                print("LITE bundle is still too large ({} KB).".format(int(max(lite_size, 0) / 1024)))
            except Exception:
                pass
        try:
            print("Tip: Reduce log size or increase 'MediLink_Config.error_reporting.email.max_bundle_bytes'.")
        except Exception:
            pass
        trace['delivery_state'] = 'bundle_too_large'
        _store_support_email_delivery_meta(trace)
        return False
    # Before recipient / token handling: callers may pass a non-dict truthy auth_session.
    if not isinstance(auth_session, dict):
        auth_session = None
    # Feature is always available; proceed if recipients and token are available
    # Normalize and validate recipients
    to_emails = _normalize_recipients(email_config.get('to', []))
    if not to_emails:
        mc_log("No valid recipients configured in error_reporting.email.to", level="ERROR")
        try:
            summary = _config_loader_summary_text(runtime.get('diagnostics', {}))
            if runtime.get('degraded') and summary:
                print("No recipients configured. Bundle remains queued because config loading is degraded: {}.".format(summary))
            elif runtime.get('degraded'):
                print("No recipients configured. Bundle remains queued because config loading is degraded.")
            else:
                print("No recipients configured. Set 'MediLink_Config.error_reporting.email.to' to one or more email addresses.")
        except Exception:
            pass
        trace['delivery_state'] = 'no_recipients_configured'
        _store_support_email_delivery_meta(trace)
        return False

    subject_prefix = email_config.get('subject_prefix', _DEFAULT_SUBJECT_PREFIX)
    bundle_kind = _bundle_kind_from_zip_or_meta(zip_path, extra_meta)
    subject_context = _subject_context_from_meta_dict(extra_meta)
    if zip_path and os.path.isfile(zip_path):
        zip_subject_context = _read_subject_context_from_zip(zip_path)
        if not subject_context.get('run_id'):
            subject_context['run_id'] = zip_subject_context.get('run_id', '')
        if not subject_context.get('send_source'):
            subject_context['send_source'] = zip_subject_context.get('send_source', '')
    ts_suffix = time.strftime('%Y%m%d_%H%M%S')
    attach_name = os.path.basename(zip_path)
    email_body, success_line = _bundle_email_body_and_success(bundle_kind, attach_name)
    access_token = auth_session.get('access_token') if auth_session else None
    if access_token:
        trace['delivery_state'] = 'token_session_reuse'
    if not access_token:
        access_token, run_meta = _resolve_gmail_access_token_via_runbook(
            skip_interactive_reauth=skip_interactive_reauth,
            force_reauth=False,
            max_wait_seconds=reauth_wait_seconds,
            reason='initial_send',
            progress_callback=progress_callback,
        )
        for k, v in run_meta.items():
            trace[k] = v
        if access_token and auth_session is not None:
            auth_session['access_token'] = access_token
            auth_session['token_validated'] = True
    if not access_token:
        if auth_session is not None:
            auth_session.pop('access_token', None)
            auth_session.pop('token_validated', None)
        if skip_interactive_reauth:
            mc_log("No access token - skip_interactive_reauth=True; leaving bundle in queue.", level="INFO")
        else:
            try:
                print("Automatic Gmail authentication recovery did not complete. Bundle remains queued.")
            except Exception:
                pass
        if not trace.get('delivery_state'):
            trace['delivery_state'] = 'token_unavailable'
        _store_support_email_delivery_meta(trace)
        return False
    _emit_progress(progress_callback, 'assembling email payload')
    mc_log("Building email...", level="INFO")
    msg = MIMEMultipart()
    msg['To'] = ', '.join(to_emails)
    msg['Subject'] = _compose_email_subject(
        bundle_kind,
        subject_prefix,
        ts_suffix,
        run_id=subject_context.get('run_id', ''),
        send_source=subject_context.get('send_source', ''),
    )
    with open(zip_path, 'rb') as f:
        attach = MIMEApplication(f.read(), _subtype='zip')
        attach.add_header('Content-Disposition', 'attachment', filename=attach_name)
        msg.attach(attach)
    msg.attach(MIMEText(email_body, 'plain'))
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    _emit_progress(progress_callback, 'sending email to support')
    mc_log("Sending support bundle (kind={0})...".format(bundle_kind), level="INFO")
    headers = {'Authorization': 'Bearer {}'.format(access_token), 'Content-Type': 'application/json'}
    data = {'raw': raw}
    try:
        resp = requests.post(GMAIL_SEND_API_URL, headers=headers, json=data, timeout=send_timeout_seconds)
    except Exception as e:
        mc_log("Network error during Gmail send: {0}".format(e), level="ERROR")
        try:
            print("Network error while sending support bundle: {0}".format(e))
            print("Check internet connectivity or proxy settings and retry.")
        except Exception:
            pass
        trace['delivery_state'] = 'network_error'
        _store_support_email_delivery_meta(trace)
        return False
    if resp.status_code == 200:
        mc_log("Support bundle sent successfully (kind={0}).".format(bundle_kind), level="INFO")
        try:
            print(success_line)
        except Exception:
            pass
        try:
            os.remove(zip_path)
        except Exception:
            pass
        trace['send_succeeded'] = True
        trace['delivery_state'] = 'succeeded'
        _store_support_email_delivery_meta(trace)
        return True
    else:
        # Handle auth errors by prompting re-consent using existing OAuth helpers, then retry once
        if resp.status_code in (401, 403):
            if skip_interactive_reauth:
                mc_log("Gmail send unauthorized ({}). skip_interactive_reauth=True; leaving bundle in queue.".format(resp.status_code), level="INFO")
                trace['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
                trace['delivery_state'] = 'paused_waiting_for_operator_reauth'
                _store_support_email_delivery_meta(trace)
                return False
            mc_log("Gmail send unauthorized ({}). Running auth recovery runbook and retry.".format(resp.status_code), level="WARNING")
            _emit_progress(progress_callback, 'waiting for Gmail sign-in')
            new_token, run_meta = _resolve_gmail_access_token_via_runbook(
                skip_interactive_reauth=skip_interactive_reauth,
                force_reauth=True,
                max_wait_seconds=reauth_wait_seconds,
                reason='http_{}_send'.format(resp.status_code),
                progress_callback=progress_callback,
            )
            for k, v in run_meta.items():
                trace[k] = v
            if new_token:
                if auth_session is not None:
                    auth_session['access_token'] = new_token
                    auth_session['token_validated'] = True
                headers['Authorization'] = 'Bearer {}'.format(new_token)
                _emit_progress(progress_callback, 'retrying email after Gmail sign-in')
                try:
                    resp = requests.post(GMAIL_SEND_API_URL, headers=headers, json=data, timeout=send_timeout_seconds)
                except Exception as e:
                    mc_log("Network error on retry: {0}".format(e), level="ERROR")
                    try:
                        print("Network error on retry: {0}".format(e))
                    except Exception:
                        pass
                    trace['delivery_state'] = 'network_error_retry'
                    _store_support_email_delivery_meta(trace)
                    return False
                if resp.status_code == 200:
                    mc_log("Support bundle sent successfully after re-authorization (kind={0}).".format(bundle_kind), level="INFO")
                    try:
                        print(success_line)
                    except Exception:
                        pass
                    try:
                        os.remove(zip_path)
                    except Exception:
                        pass
                    trace['send_succeeded'] = True
                    trace['delivery_state'] = 'succeeded'
                    _store_support_email_delivery_meta(trace)
                    return True
            if auth_session is not None:
                auth_session.pop('access_token', None)
                auth_session.pop('token_validated', None)
            trace['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
        hint = ''
        try:
            err_payload = resp.json()
            err = err_payload.get('error', {}) if isinstance(err_payload, dict) else {}
            status = (err.get('status') or '').upper()
            message = err.get('message') or ''
            reasons = ','.join([e.get('reason') for e in err.get('errors', []) if isinstance(e, dict) and e.get('reason')])
            if 'RATELIMIT' in status or 'rateLimitExceeded' in reasons:
                hint = 'Quota exceeded. Wait and retry later.'
            elif 'DAILY' in status or 'dailyLimitExceeded' in reasons:
                hint = 'Daily quota exceeded. Try again tomorrow.'
            elif status in ('PERMISSION_DENIED', 'FORBIDDEN'):
                hint = 'Permissions insufficient. Re-authorize Gmail with required scopes.'
            elif status == 'INVALID_ARGUMENT':
                hint = 'Invalid request. Check recipient emails and attachment size.'
            elif status == 'UNAUTHENTICATED':
                hint = 'Authentication required. Re-authorize and retry.'
                trace['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
        except Exception:
            pass
        mc_log("Failed to send: {} - {}".format(resp.status_code, _redact(resp.text)), level="ERROR")
        try:
            base_msg = "Failed to send support bundle: HTTP {}.".format(resp.status_code)
            if hint:
                base_msg += " Hint: {}".format(hint)
            print(base_msg)
            print("The bundle remains in 'reports_queue'. See latest log for details.")
        except Exception:
            pass
        trace['delivery_state'] = trace.get('delivery_state') or 'http_error'
        if resp.status_code in (401, 403) and not trace.get('delivery_issue_code'):
            trace['delivery_issue_code'] = SUPPORT_DELIVERY_REAUTH_REQUIRED
        _store_support_email_delivery_meta(trace)
        return False


_PLACEHOLDER_EMAILS = frozenset([
    'test', 'test@test.com', 'test@test.test', 'example@example.com',
    'example@example.org', 'user@example.com', 'foo@bar.com',
])

def _is_placeholder_email(addr):
    """Return True if addr is a known placeholder (test, example, etc.)."""
    if not addr or not isinstance(addr, str):
        return True
    lower = addr.strip().lower()
    if lower in _PLACEHOLDER_EMAILS or lower.startswith('test@'):
        return True
    # Reserved documentation domains (RFC 2606) - avoid rejecting e.g. alice@myexample.com
    if '@example.' in lower or lower.endswith('@example.com') or lower.endswith('@example.org') or lower.endswith('@example.net'):
        return True
    return False


def _normalize_recipients(to_field, suppress_warnings=False):
    try:
        # Flatten to a list of strings
        if isinstance(to_field, str):
            separators_normalized = to_field.replace(';', ',').replace('\n', ',').replace('\r', ',')
            candidates = [p.strip() for p in separators_normalized.split(',')]
        elif isinstance(to_field, list):
            candidates = [str(p).strip() for p in to_field]
        else:
            candidates = []
        # Basic email regex: local@domain.tld
        import re
        email_re = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')
        valid = []
        for addr in candidates:
            if not addr:
                continue
            if _is_placeholder_email(addr):
                if not suppress_warnings:
                    try:
                        mc_log("Placeholder email recipient skipped (non-blocking): {}".format(addr), level="DEBUG")
                    except Exception:
                        pass
                continue
            if email_re.match(addr):
                valid.append(addr)
            else:
                if not suppress_warnings:
                    try:
                        mc_log("Invalid email recipient skipped: {}".format(addr), level="WARNING")
                    except Exception:
                        pass
        return valid
    except Exception:
        return []


def _should_probe_delivery_token(readiness, defer_token_probe_until_queue=False):
    """Return (should_probe, skip_reason) for startup-style token checks."""
    if not defer_token_probe_until_queue:
        return True, ''

    if not isinstance(readiness, dict):
        return True, ''

    if readiness.get('queue_probe_error'):
        return False, 'queue_probe_error'

    try:
        queued_bundle_count = int(readiness.get('queued_bundle_count') or 0)
    except Exception:
        queued_bundle_count = None

    if isinstance(queued_bundle_count, int) and queued_bundle_count <= 0:
        return False, 'queue_empty'

    recipient_count = readiness.get('recipient_count')
    if isinstance(recipient_count, int) and recipient_count <= 0:
        return False, 'no_recipients'

    return True, ''


def get_error_reporting_delivery_readiness(quiet_token=True, include_queue_paths=False, defer_token_probe_until_queue=False):
    """
    Shared delivery readiness snapshot used by launcher/cloud-readiness diagnostics.
    Returns:
      {
        token_available: bool|None,
        recipient_count: int|None,
        queued_bundle_count: int|None,
        queued_bundle_paths: [str] (optional),
        ...error keys...
      }
    """
    readiness = {
        'token_available': None,
        'recipient_count': None,
        'queued_bundle_count': None,
    }
    runtime = _get_error_reporter_runtime_context()
    readiness['config_loader_status'] = runtime.get('diagnostics', {}).get('overall_status') if isinstance(runtime.get('diagnostics', {}), dict) else None
    readiness['config_loader_summary'] = _config_loader_summary_text(runtime.get('diagnostics', {}))
    try:
        email_cfg = (
            runtime.get('medi', {})
            .get('error_reporting', {})
            .get('email', {})
        ) if isinstance(runtime.get('medi', {}), dict) else {}
        recipients = _normalize_recipients(email_cfg.get('to', []), suppress_warnings=True)
        readiness['recipient_count'] = len(recipients)
    except Exception as e:
        readiness['config_probe_error'] = str(e)

    try:
        queued = list_queued_bundles()
        readiness['queued_bundle_count'] = len(queued)
        if include_queue_paths:
            readiness['queued_bundle_paths'] = queued
    except Exception as e:
        readiness['queue_probe_error'] = str(e)

    should_probe_token, skip_reason = _should_probe_delivery_token(
        readiness,
        defer_token_probe_until_queue=defer_token_probe_until_queue,
    )
    if should_probe_token:
        try:
            token = get_gmail_access_token(log=None, quiet=bool(quiet_token))
            readiness['token_available'] = bool(token)
        except Exception as e:
            readiness['token_probe_error'] = str(e)
    elif skip_reason:
        readiness['token_probe_skipped_reason'] = skip_reason

    last_delivery = get_last_support_email_delivery_meta()
    if last_delivery:
        readiness['last_support_email_delivery'] = _sanitize_extra_meta(last_delivery)

    return readiness


# Members always dropped when repackaging an oversized prebuilt ZIP.
_LITE_REPACK_ALWAYS_DROP_NAMES = frozenset(['traceback.txt', 'winscp_log_tail.txt'])


def _support_bundle_log_member_names_from_meta(meta_obj):
    names = set(['log_tail.txt'])
    meta = meta_obj if isinstance(meta_obj, dict) else {}
    selected_name = str(meta.get('selected_log_archive_name') or meta.get('selected_log_name') or '').strip()
    if selected_name:
        names.add(selected_name)
    for row in meta.get('historical_log_tails', []) or []:
        if not isinstance(row, dict):
            continue
        archive_name = str(row.get('archive_name') or row.get('selected_log_name') or '').strip()
        if archive_name:
            names.add(archive_name)
    return names


def repack_support_bundle_lite_from_zip(source_zip_path):
    """
    Build a smaller ZIP from an existing support bundle by omitting heavy log/traceback
    members while preserving evidence files and bundle_kind in meta.json.
    Returns path to new ZIP in reports_queue, or None on failure.
    """
    try:
        if not source_zip_path or not os.path.isfile(source_zip_path):
            return None
        runtime = _get_error_reporter_runtime_context()
        queue_dir = _resolve_queue_dir(runtime.get('medi', {}))
        stamp = time.strftime('%Y%m%d_%H%M%S')
        with zipfile.ZipFile(source_zip_path, 'r') as zin:
            meta_obj = {}
            try:
                if 'meta.json' in zin.namelist():
                    raw = zin.read('meta.json').decode('utf-8', 'ignore')
                    parsed = json.loads(raw)
                    if isinstance(parsed, dict):
                        meta_obj = parsed
            except Exception:
                meta_obj = {}
            kind = _normalize_bundle_kind_slug(str(meta_obj.get('bundle_kind') or '')) or 'error_report'
            meta_obj['bundle_kind'] = kind
            meta_obj['bundle_lite'] = True
            meta_obj['traceback_present'] = False
            prev_sum = str(meta_obj.get('error_summary') or '').strip()
            lite_note = 'LITE repack: omitted heavy log/traceback members from oversized bundle.'
            meta_obj['error_summary'] = _safe_ascii((prev_sum + '; ' if prev_sum else '') + lite_note)[:500]
            out_path = os.path.join(queue_dir, 'medicafe_bundle_{}_LITE_{}.zip'.format(kind, stamp))
            with zipfile.ZipFile(out_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                zout.writestr('meta.json', json.dumps(meta_obj, ensure_ascii=True, indent=2))
                for info in zin.infolist():
                    name = info.filename
                    if not name or name.endswith('/'):
                        continue
                    if name == 'meta.json':
                        continue
                    base = name.split('/')[-1]
                    if base in _LITE_REPACK_ALWAYS_DROP_NAMES:
                        continue
                    if base in _support_bundle_log_member_names_from_meta(meta_obj):
                        continue
                    try:
                        data = zin.read(name)
                    except Exception:
                        continue
                    zout.writestr(name, data, compress_type=zipfile.ZIP_DEFLATED)
        if os.path.isfile(out_path) and os.path.getsize(out_path) > 0:
            return out_path
        try:
            if os.path.isfile(out_path):
                os.remove(out_path)
        except Exception:
            pass
        return None
    except Exception:
        return None


def _merge_extra_meta_with_bundle_kind_from_zip(zip_path, extra_meta):
    """If extra_meta lacks bundle_kind, copy from source ZIP meta.json for LITE fallback labeling."""
    merged = {}
    if isinstance(extra_meta, dict):
        merged.update(extra_meta)
    if merged.get('bundle_kind'):
        return merged
    k = _read_bundle_kind_from_zip(zip_path)
    if k:
        merged['bundle_kind'] = k
    return merged


def collect_support_bundle_lite(max_log_lines=200, extra_meta=None, extra_files=None, evidence_manifest=None):
    """Create a smaller 'lite' support bundle with reduced logs and no traceback/winscp logs."""
    try:
        runtime = _get_error_reporter_runtime_context()
        config = runtime.get('config', {})
        medi = runtime.get('medi', {})
        local_storage_path = medi.get('local_storage_path', _get_degraded_storage_root())
        queue_dir = _resolve_queue_dir(medi)
        extra_meta = _merge_evidence_manifest_extra_meta(extra_meta, evidence_manifest)
        stamp = time.strftime('%Y%m%d_%H%M%S')
        lite_kind = resolve_bundle_kind(extra_meta, claim_failure_summary=False)
        zip_path = os.path.join(queue_dir, 'medicafe_bundle_{}_LITE_{}.zip'.format(lite_kind, stamp))
        meta = {
            'app_version': _safe_ascii(_get_version()),
            'python_version': _safe_ascii(sys.version.split(' ')[0]),
            'platform': _safe_ascii(platform.platform()),
            'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'error_summary': 'LITE: No traceback included',
            'traceback_present': False,
            'bundle_kind': lite_kind,
            'bundle_lite': True,
            'config_flags': {
                'console_logging': bool(medi.get('logging', {}).get('console_output', False)),
                'test_mode': bool(medi.get('TestMode', False))
            }
        }
        if extra_meta and isinstance(extra_meta.get('error_summary'), str):
            meta['error_summary'] = _safe_ascii(extra_meta.get('error_summary'))
        if extra_meta:
            try:
                meta['extra_context'] = _sanitize_extra_meta(extra_meta)
            except Exception:
                pass
        _attach_config_loader_meta(meta, runtime.get('diagnostics', {}))
        # Include certificate authority metadata for remote triage
        try:
            ca_metadata = _collect_certificate_authority_metadata(config)
            if ca_metadata:
                meta['certificateAuthority'] = ca_metadata
        except Exception as ca_err:
            # Non-fatal - continue without CA metadata if collection fails
            try:
                mc_log('Failed to collect CA metadata for lite support bundle (non-fatal): {}'.format(ca_err), level='DEBUG')
            except Exception:
                pass
        merged_extra_files = extra_files
        if evidence_manifest is not None:
            try:
                from MediCafe import evidence_manifest as _em_manifest
                merged_extra_files = _em_manifest.merge_extra_files(
                    _em_manifest.manifest_to_extra_files(evidence_manifest),
                    extra_files or [],
                )
            except Exception:
                merged_extra_files = extra_files
        bundle_extra_files = _with_json_health_attachment(merged_extra_files, config)
        ok = _build_support_zip(
            zip_path,
            local_storage_path,
            max_log_lines,
            None,
            False,
            meta,
            None,
            bundle_extra_files,
            evidence_manifest_for_zip=evidence_manifest if isinstance(evidence_manifest, dict) else None,
        )
        return zip_path if ok else None
    except Exception:
        return None


def optional_error_report_manifest(send_source='generic_error_bundle'):
    """Best-effort error_report manifest for generic collect_support_bundle callers."""
    try:
        from MediCafe.evidence_manifest import try_resolve_error_report_manifest

        return try_resolve_error_report_manifest(send_source)
    except Exception:
        try:
            from evidence_manifest import try_resolve_error_report_manifest as _try_er

            return _try_er(send_source)
        except Exception:
            return None


def _print_queued_bundle_names(queued):
    try:
        if not queued:
            print("No queued bundles found.")
            return
        print("Queued bundle(s):")
        for z in queued:
            try:
                name = z
            except Exception:
                name = z
            print(" - {}".format(name))
    except Exception:
        pass


def _auto_resolve_state_path():
    """Best-effort path for passive queue auto-resolution state."""
    try:
        runtime = _get_error_reporter_runtime_context()
        queue_dir = _resolve_queue_dir(runtime.get('medi', {}))
        return os.path.join(queue_dir, 'queue_auto_resolve_state.json')
    except Exception:
        return os.path.join(_get_degraded_storage_root(), 'reports_queue', 'queue_auto_resolve_state.json')


def _load_auto_resolve_state():
    try:
        path = _auto_resolve_state_path()
        if not os.path.exists(path):
            return {}
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_auto_resolve_state(state):
    try:
        path = _auto_resolve_state_path()
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(state if isinstance(state, dict) else {}, f, indent=2, sort_keys=True)
        return True
    except Exception:
        return False


def _coerce_int(value, fallback):
    try:
        return int(value)
    except Exception:
        return int(fallback)


def maybe_auto_resolve_queued_bundles_passive(
    min_retry_interval_seconds=900,
    max_bundles_per_attempt=3,
    reauth_wait_seconds=30,
    readiness_snapshot=None,
    now_epoch=None,
):
    """
    Passive queue self-healing entry point intended for startup/readiness piggyback.
    Non-blocking behavior constraints:
      - no interactive OAuth prompt (skip_interactive_reauth=True)
      - throttled attempts via persisted state
      - bounded queue drain per run
    Returns a telemetry dict describing whether an attempt occurred and outcome.
    """
    outcome = {
        'attempted': False,
        'sent': 0,
        'failed': 0,
        'queued_before': 0,
        'reason': '',
    }
    readiness = readiness_snapshot
    if not isinstance(readiness, dict):
        readiness = get_error_reporting_delivery_readiness(
            quiet_token=True,
            include_queue_paths=True,
            defer_token_probe_until_queue=True,
        )
    if not isinstance(readiness, dict):
        outcome['reason'] = 'readiness_unavailable'
        return outcome

    if readiness.get('queue_probe_error'):
        outcome['reason'] = 'queue_probe_error'
        return outcome

    queued = readiness.get('queued_bundle_paths')
    if not isinstance(queued, list):
        queued = list_queued_bundles()
    outcome['queued_before'] = len(queued)

    if outcome['queued_before'] <= 0:
        outcome['reason'] = 'queue_empty'
        return outcome
    if readiness.get('token_available') is not True:
        outcome['reason'] = 'token_unavailable'
        return outcome
    recipient_count = readiness.get('recipient_count')
    if not isinstance(recipient_count, int) or recipient_count <= 0:
        outcome['reason'] = 'no_recipients'
        return outcome

    now = _coerce_int(now_epoch if now_epoch is not None else time.time(), time.time())
    min_retry_interval_seconds = max(0, _coerce_int(min_retry_interval_seconds, 900))
    max_bundles_per_attempt = max(1, _coerce_int(max_bundles_per_attempt, 3))
    reauth_wait_seconds = max(1, _coerce_int(reauth_wait_seconds, 30))

    state = _load_auto_resolve_state()
    last_attempt = state.get('last_attempt_epoch')
    if isinstance(last_attempt, int) and min_retry_interval_seconds > 0:
        elapsed = now - last_attempt
        last_queued_before = state.get('last_queued_before')
        queue_has_grown = False
        if isinstance(last_queued_before, int):
            queue_has_grown = outcome['queued_before'] > last_queued_before
        if elapsed < min_retry_interval_seconds and not queue_has_grown:
            outcome['reason'] = 'throttled'
            return outcome

    bounded = queued[:max_bundles_per_attempt]
    sent, failed = submit_all_queued_bundles(
        queued=bounded,
        show_names=False,
        auth_session={},
        skip_interactive_reauth=True,
        reauth_wait_seconds=reauth_wait_seconds,
    )
    outcome['attempted'] = True
    outcome['sent'] = int(sent)
    outcome['failed'] = int(failed)
    outcome['reason'] = 'attempted'
    _save_auto_resolve_state({
        'last_attempt_epoch': now,
        'last_attempt_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(now)),
        'last_sent': int(sent),
        'last_failed': int(failed),
        'last_queued_before': int(outcome['queued_before']),
    })
    return outcome

def list_queued_bundles():
    try:
        runtime = _get_error_reporter_runtime_context()
        medi = runtime.get('medi', {})
        local_storage_path = medi.get('local_storage_path', _get_degraded_storage_root())
        candidates = [
            os.path.join(local_storage_path, 'reports_queue'),
            os.path.join(_get_degraded_storage_root(), 'reports_queue'),
            os.path.join('.', 'reports_queue'),
        ]
        files = []
        for q in candidates:
            try:
                if os.path.isdir(q):
                    files.extend([os.path.join(q, f) for f in os.listdir(q) if f.endswith('.zip')])
            except Exception:
                pass
        files = sorted(set(files))
        return files
    except Exception:
        return []


def _orchestrator_queue_dedup_key_from_zip(zip_path):
    """If zip is an orchestrator_failure bundle, return stable error_code for queue dedup; else None."""
    try:
        if not zip_path or not os.path.isfile(zip_path):
            return None
        with zipfile.ZipFile(zip_path, 'r') as zf:
            if 'meta.json' not in zf.namelist():
                return None
            raw = zf.read('meta.json').decode('utf-8', 'ignore')
            data = json.loads(raw)
            if not isinstance(data, dict):
                return None
            kind = _normalize_bundle_kind_slug(data.get('bundle_kind', ''))
            extra = data.get('extra_context')
            if kind != 'orchestrator_failure' and isinstance(extra, dict):
                if _extra_meta_truthy(extra, 'orchestrator_failure_auto_report'):
                    kind = 'orchestrator_failure'
            if kind != 'orchestrator_failure':
                return None
            ec = ''
            if isinstance(extra, dict):
                ec = str(extra.get('error_code', '') or '').strip()
            if not ec:
                ec = str(data.get('error_code', '') or '').strip()
            return ec or 'UNKNOWN_ORCHESTRATOR_FAILURE'
    except Exception:
        return None


def _filter_queued_orchestrator_duplicate_paths(queued_paths):
    """Drop duplicate orchestrator_failure queue artifacts (same error_code), keep newest mtime, delete extras."""
    if not queued_paths:
        return queued_paths
    seen_codes = set()
    kept = []
    try:
        ranked = sorted(queued_paths, key=lambda p: os.path.getmtime(p), reverse=True)
    except Exception:
        ranked = list(queued_paths)
    for z in ranked:
        key = _orchestrator_queue_dedup_key_from_zip(z)
        if key is not None:
            if key in seen_codes:
                try:
                    if os.path.isfile(z):
                        os.remove(z)
                except Exception:
                    pass
                continue
            seen_codes.add(key)
        kept.append(z)
    try:
        return sorted(kept)
    except Exception:
        return kept


def submit_all_queued_bundles(queued=None, show_names=True, auth_session=None, skip_interactive_reauth=False, reauth_wait_seconds=120, max_sends=None):
    sent = 0
    failed = 0
    try:
        if not isinstance(auth_session, dict):
            auth_session = {}
        if queued is None:
            queued = list_queued_bundles()
        else:
            queued = list(queued)
        queued = _filter_queued_orchestrator_duplicate_paths(queued)
        if max_sends is not None:
            try:
                cap = int(max_sends)
            except Exception:
                cap = 0
            if cap > 0 and len(queued) > cap:
                try:
                    queued = sorted(queued, key=lambda p: os.path.getmtime(p), reverse=True)[:cap]
                except Exception:
                    queued = queued[:cap]
        if show_names:
            _print_queued_bundle_names(queued)
        for z in queued:
            try:
                ok = submit_support_bundle_email(
                    zip_path=z,
                    include_traceback=False,
                    skip_interactive_reauth=skip_interactive_reauth,
                    auth_session=auth_session,
                    reauth_wait_seconds=reauth_wait_seconds,
                )
                if ok:
                    sent += 1
                    if os.path.exists(z):
                        try:
                            os.remove(z)
                        except Exception:
                            pass
                else:
                    failed += 1
            except Exception:
                failed += 1
    except Exception:
        pass
    return sent, failed


def maybe_resolve_queued_bundles_opportunistically(auth_session=None, source='legacy_auth', announce=False, max_bundles=None):
    """Attempt queued bundle delivery after an explicit legacy Gmail auth opportunity.

    When ``source`` is ``legacy_gmail_download``, a default cap applies so one Gmail run does not
    email every pending bundle (those lines appear in the launcher process *after* MediLink exits).
    Override with env ``MEDICAFE_LEGACY_GMAIL_QUEUE_DRAIN_MAX`` (integer, or ``all`` for no cap).
    """
    outcome = {
        'attempted': False,
        'sent': 0,
        'failed': 0,
        'queued_before': 0,
        'reason': '',
    }
    try:
        queued = list_queued_bundles()
    except Exception as e:
        outcome['reason'] = 'queue_probe_error'
        try:
            mc_log("Opportunistic queued bundle resolution skipped (source: {}, reason: {}).".format(source, e), level="DEBUG")
        except Exception:
            pass
        return outcome

    outcome['queued_before'] = len(queued)
    if outcome['queued_before'] <= 0:
        outcome['reason'] = 'queue_empty'
        return outcome

    max_cap = max_bundles
    if max_cap is None and source == 'legacy_gmail_download':
        try:
            raw = str(os.environ.get('MEDICAFE_LEGACY_GMAIL_QUEUE_DRAIN_MAX', '6')).strip()
            if raw.lower() in ('all', 'none', ''):
                max_cap = None
            else:
                max_cap = int(raw)
                if max_cap < 1:
                    max_cap = None
        except Exception:
            max_cap = 6

    kind_summary = ''
    try:
        kind_counts = {}
        for p in queued:
            k = _read_bundle_kind_from_zip(p) or 'unknown'
            kind_counts[k] = kind_counts.get(k, 0) + 1
        kind_summary = ', '.join('{0}={1}'.format(k, v) for k, v in sorted(kind_counts.items()))
    except Exception:
        kind_summary = ''

    if source == 'legacy_gmail_download':
        try:
            send_n = min(outcome['queued_before'], max_cap) if max_cap else outcome['queued_before']
            print(
                "[MediCafe] reports_queue: {0} bundle(s) [{1}]. Launcher auto-send after Gmail: {2} of {0} (remaining: use Troubleshooting → Resolve queued reports).".format(
                    outcome['queued_before'],
                    kind_summary,
                    send_n,
                )
            )
        except Exception:
            pass

    runtime = _get_error_reporter_runtime_context()
    try:
        email_cfg = (
            runtime.get('medi', {})
            .get('error_reporting', {})
            .get('email', {})
        ) if isinstance(runtime.get('medi', {}), dict) else {}
        recipients = _normalize_recipients(email_cfg.get('to', []), suppress_warnings=True)
    except Exception:
        recipients = []
    if not recipients:
        outcome['reason'] = 'no_recipients'
        return outcome

    if not isinstance(auth_session, dict):
        auth_session = {}

    sent, failed = submit_all_queued_bundles(
        queued=queued,
        show_names=False,
        auth_session=auth_session,
        skip_interactive_reauth=True,
        max_sends=max_cap,
    )
    outcome['attempted'] = True
    outcome['sent'] = int(sent)
    outcome['failed'] = int(failed)
    outcome['reason'] = 'attempted'
    try:
        mc_log(
            "Opportunistic queued bundle resolution after {}: sent {} failed {}.".format(source, sent, failed),
            level="INFO" if failed == 0 else "WARNING"
        )
    except Exception:
        pass
    if announce:
        try:
            print("Queued support bundle follow-up attempted. Sent: {} Failed: {}.".format(sent, failed))
        except Exception:
            pass
    return outcome


def resolve_queued_bundles_flow():
    try:
        queued = list_queued_bundles()
        if not queued:
            try:
                print("No queued bundles found.")
            except Exception:
                pass
            return 0
        try:
            print("Found {} queued bundle(s).".format(len(queued)))
        except Exception:
            pass
        try:
            _print_queued_bundle_names(queued)
        except Exception:
            pass
        try:
            ans = input("Send queued bundles now? (Y/N): ").strip().lower()
        except Exception:
            ans = ''
        if ans not in ('y', 'yes'):
            try:
                print("Cancelled. No bundles were sent.")
            except Exception:
                pass
            return 0
        sent, failed = submit_all_queued_bundles(queued=queued, show_names=False)
        try:
            print("Queued send complete. Sent: {} Failed: {}".format(sent, failed))
        except Exception:
            pass
        return 0 if failed == 0 else 1
    except Exception as e:
        try:
            mc_log("[ERROR] Exception during queued bundle flow: {0}".format(e), level="ERROR")
        except Exception:
            pass
        try:
            print("Unexpected error while processing queued bundles: {0}".format(e))
        except Exception:
            pass
        return 1


def delete_all_queued_bundles():
    deleted = 0
    try:
        for z in list_queued_bundles():
            try:
                os.remove(z)
                deleted += 1
            except Exception:
                pass
    except Exception:
        pass
    return deleted

def email_error_report_flow():
    try:
        auth_session = {}
        sent = submit_support_bundle_email(zip_path=None, include_traceback=True, auth_session=auth_session)
        if sent:
            maybe_resolve_queued_bundles_opportunistically(
                auth_session=auth_session,
                source='email_error_report_flow',
                announce=True,
            )
        return 0 if sent else 1
    except Exception as e:
        mc_log("[ERROR] Exception during email report flow: {0}".format(e), level="ERROR")
        try:
            print("Unexpected error while sending error report: {0}".format(e))
        except Exception:
            pass
        return 1

def email_test_error_report_flow():
    """
    Create and send a manual support self-test bundle, containing bounded
    read-only self-test results, a placeholder traceback, and latest log tails.
    Intended for troubleshooting the submission pipeline and local runtime.

    This flow first attempts a non-interactive send and, if auth blocks
    delivery, runs an embedded self-resolution runbook to recover Gmail auth
    and drain the queued bundles automatically.
    """
    try:
        zip_path = collect_test_support_bundle()
        if not zip_path:
            try:
                print("Failed to create support self-test bundle. Ensure 'MediLink_Config.local_storage_path' is writable.")
            except Exception:
                pass
            return 1
        auth_session = {}
        sent = submit_support_bundle_email(
            zip_path=zip_path,
            include_traceback=False,
            skip_interactive_reauth=True,
            auth_session=auth_session,
        )
        if sent:
            maybe_resolve_queued_bundles_opportunistically(
                auth_session=auth_session,
                source='email_test_error_report_flow',
                announce=True,
            )
        if not sent:
            recovered = _run_queued_bundle_self_resolution(max_wait_seconds=120)
            try:
                if recovered:
                    print("Support self-test bundle delivery self-resolution completed.")
                else:
                    print("Support self-test bundle remains queued after automated recovery attempts.")
            except Exception:
                pass
        return 0
    except Exception as e:
        try:
            mc_log("[ERROR] Exception during test email report flow: {0}".format(e), level="ERROR")
        except Exception:
            pass
        try:
            print("Unexpected error during support self-test report flow: {0}".format(e))
        except Exception:
            pass
        return 1

if __name__ == "__main__":
    raise SystemExit(email_error_report_flow())
