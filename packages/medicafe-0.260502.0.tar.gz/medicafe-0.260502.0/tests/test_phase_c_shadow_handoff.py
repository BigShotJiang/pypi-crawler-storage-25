# -*- coding: utf-8 -*-
"""Shadow pipeline Phase C handoff coherence (pytest)."""

from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import unittest

try:
    from unittest.mock import patch
except ImportError:
    from mock import patch

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_UM = os.path.join(_REPO_ROOT, "scripts", "unified_model")
if _UM not in sys.path:
    sys.path.insert(0, _UM)

from phase_c_common import PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION


class TestPhaseCHandoffCoherence(unittest.TestCase):
    """Subprocess exit 0 must match persisted Phase C handoff."""

    def _make_lab(self):
        lab_root = tempfile.mkdtemp(prefix="mc_pc_handoff_")
        os.makedirs(os.path.join(lab_root, "reports"))
        return lab_root

    def test_handoff_fails_when_cursor_and_state_phase_c_ok_disagree(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_ok": False, "last_ingest_manifest_sha256": "m1"}, f)

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_cursor_and_state_ingest_sha_disagree(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "bsha",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "state-sha",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "cursor-sha",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_canonical_phase_c_summary_missing(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-missing",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c-missing",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_canonical_phase_c_summary_reports_failure(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": False,
                        "error_code": "PHASE_C_DB_WRITE_ERROR",
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_DB_WRITE_ERROR")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_summary_schema_version_missing(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_fails_when_summary_schema_version_mismatch(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION + 1,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_handoff_passes_when_summary_schema_version_matches(self):
        from run_shadow_pipeline import run_shadow_pipeline

        lab_root = self._make_lab()
        reports = os.path.join(lab_root, "reports")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(os.path.join(reports, "ingest_write_summary_c1.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "run_id": "c1",
                        "ok": True,
                        "summary_schema_version": PHASE_C_INGEST_SUMMARY_SCHEMA_VERSION,
                        "manifest_sha256": "m1",
                    },
                    f,
                )
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_manifest_sha256": "m1",
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": True,
                        "last_ingest_manifest_sha256": "m1",
                        "last_phase_c_run_id": "c1",
                    },
                    f,
                )

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_pkg:
                    mock_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertTrue(ok)
            self.assertIsNone(failed_phase)
            self.assertIn(error_code, (None, ""))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
