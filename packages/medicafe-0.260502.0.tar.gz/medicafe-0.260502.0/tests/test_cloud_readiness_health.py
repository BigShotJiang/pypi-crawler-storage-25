import os
import json
import sqlite3
import tempfile
import unittest

from MediCafe.cloud_readiness_health import build_cloud_health_lines
from MediCafe.cloud_readiness_health import _collect_health_diagnostics
from MediCafe.cloud_readiness_health import _HEALTH_SNAPSHOT_LINE_MAX


def _effective_bundle_archive_names(extra_files, evidence_manifest):
    """Mirror collect_support_bundle: manifest attachments first, then legacy extra_files."""
    try:
        from MediCafe import evidence_manifest as em

        primary = em.manifest_to_extra_files(evidence_manifest) if evidence_manifest else []
        merged = em.merge_extra_files(primary, list(extra_files or []))
    except Exception:
        merged = list(extra_files or [])
    return [item[0] for item in merged]


class TestCloudReadinessHealthPhaseF(unittest.TestCase):
    def test_failed_phase_prefers_legacy_run_id_over_stale_phase_map(self):
        lab_root = tempfile.mkdtemp()
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "active_phase": "B",
                        "pipeline_state": "running",
                        "last_shadow_pipeline_phase_run_ids": {"B": "old-b"},
                        "last_phase_b_run_id": "current-b",
                        "last_discovery_ok": False,
                        "last_discovery_error_code": "PHASE_B_ROOT_RESOLUTION_FAIL",
                    },
                    f,
                )
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            phase_b = [
                issue for issue in diagnostics.get("issues", [])
                if issue.get("code") == "PHASE_B_FAILED"
            ]
            self.assertEqual(1, len(phase_b))
            self.assertEqual("current-b", phase_b[0].get("run_id"))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_b_prefers_legacy_run_id_when_discovery_error_without_active_phase(self):
        """Phase B stores failures under last_discovery_error_code; stale v2 map must not win."""
        lab_root = tempfile.mkdtemp()
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "failed",
                        "active_phase": "",
                        "last_shadow_pipeline_failed_phase": "C",
                        "last_shadow_pipeline_phase_run_ids": {"B": "old-b"},
                        "last_phase_b_run_id": "current-b",
                        "last_discovery_ok": False,
                        "last_discovery_error_code": "PHASE_B_ROOT_RESOLUTION_FAIL",
                    },
                    f,
                )
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=True)
            phase_b = [
                issue for issue in diagnostics.get("issues", [])
                if issue.get("code") == "PHASE_B_FAILED"
            ]
            self.assertEqual(1, len(phase_b))
            self.assertEqual("current-b", phase_b[0].get("run_id"))
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_f_detail_includes_lock_diag_suffix(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "failed",
                        "last_shadow_pipeline_run_id": "run-1",
                        "last_shadow_pipeline_failed_phase": "F",
                        "last_shadow_pipeline_error_code": "PHASE_F_LOCK_FAIL",
                        "last_phase_f_lock_diag_path": os.path.join(lab_root, "reports", "phase_f_lock_diag_run-1_20260101T000000Z.json"),
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("err=PHASE_F_LOCK_FAIL", joined)
            compact = joined.replace("\n", "").replace(" ", "")
            self.assertIn("lock_diag=phase_f_lock_diag_run-1_20260101T000000Z.json", compact)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_build_cloud_health_lines_wraps_long_phase_detail(self):
        lab_root = tempfile.mkdtemp()
        try:
            big = dict(("cls_{0:04d}".format(i), i % 3) for i in range(80))
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_discovery_ok": True,
                        "last_phase_b_run_id": "run-wrap",
                        "last_discovery_counts_by_class": big,
                    },
                    f,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            for line in lines:
                self.assertLessEqual(
                    len(line),
                    _HEALTH_SNAPSHOT_LINE_MAX,
                    msg="line exceeds snapshot width: {0!r}".format(line[:160]),
                )
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_get_health_lines_can_suppress_escalation_send_side_effect(self):
        import shutil
        from MediCafe import cloud_readiness

        lab_root = tempfile.mkdtemp()
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_phase_c_ok": False,
                        "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                    },
                    f,
                )
            calls = []

            def fake_send(lab_root_arg, diagnostics, tracker_info):
                calls.append((lab_root_arg, diagnostics, tracker_info))
                return True

            def env_flag(_name, default):
                return default

            old_send = cloud_readiness._maybe_send_cloud_health_failure_report
            try:
                cloud_readiness._maybe_send_cloud_health_failure_report = fake_send
                lines = cloud_readiness.get_health_lines(
                    lab_root, env_flag, send_escalation=False)
            finally:
                cloud_readiness._maybe_send_cloud_health_failure_report = old_send

            self.assertEqual([], calls)
            self.assertIn(
                "Escalated diagnostics:",
                "\n".join(lines),
            )
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_cloud_health_scope_meta_prefers_failed_phase_legacy_run_id(self):
        import shutil
        from MediCafe import cloud_readiness

        lab_root = tempfile.mkdtemp()
        try:
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "active_phase": "B",
                        "last_shadow_pipeline_phase_run_ids": {"B": "old-b"},
                        "last_phase_b_run_id": "current-b",
                        "last_discovery_error_code": "PHASE_B_ROOT_RESOLUTION_FAIL",
                    },
                    f,
                )
            meta = cloud_readiness._cloud_health_evidence_scope_meta(lab_root)
            self.assertEqual("current-b", meta.get("phase_run_ids", {}).get("B"))
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_cloud_health_escalation_attaches_latest_phase_evidence(self):
        import shutil
        from MediCafe import cloud_readiness

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir)
        try:
            def write_report(name, payload):
                path = os.path.join(reports_dir, name)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(payload)
                return path

            write_report("artifact_discovery_summary_old.json", "{}")
            write_report("artifact_discovery_summary_new.json", "{}")
            write_report("artifact_discovery_summary_new.txt", "discovery")
            write_report("ingest_write_summary_old.json", "{\"run_id\":\"old-run\"}")
            write_report("ingest_write_summary_new.json", "{\"run_id\":\"run-c\"}")
            write_report("ingest_write_summary_new.txt", "run_id=run-c\ningest")
            write_report("qa_canonical_summary_new.json", "{}")
            write_report("qa_reject_samples_new.jsonl", "{}\n")
            write_report("projection_parity_summary_new.json", "{}")
            write_report("projection_parity_summary_new.txt", "projection")
            write_report("shadow_run_report_new.json", "{}")
            write_report("layer1_join_debug_pack_new.txt", "layer1")
            write_report("layer1_join_debug_summary_new.json", "{}")
            write_report("layer1_join_debug_samples_new.jsonl", "")
            write_report("run_artifact_index_new.txt", "run_id=run-c\nindex")
            write_report("run_artifact_index_latest.txt", "run_id=run-complete\nindex-latest")
            write_report("artifact_triage_pack_new.txt", "run_id=run-d\ntriage")
            write_report("artifact_triage_pack_latest.txt", "recommendation_anchor_run_id=run-complete\ntriage-latest")
            write_report("report_delivery_status.txt", "status")
            os.utime(os.path.join(reports_dir, "artifact_discovery_summary_new.json"), (200, 200))
            os.utime(os.path.join(reports_dir, "artifact_discovery_summary_old.json"), (100, 100))
            os.utime(os.path.join(reports_dir, "ingest_write_summary_new.json"), (200, 200))
            os.utime(os.path.join(reports_dir, "ingest_write_summary_old.json"), (100, 100))
            os.utime(os.path.join(reports_dir, "run_artifact_index_latest.txt"), (300, 300))
            os.utime(os.path.join(reports_dir, "run_artifact_index_new.txt"), (200, 200))
            os.utime(os.path.join(reports_dir, "artifact_triage_pack_latest.txt"), (300, 300))
            os.utime(os.path.join(reports_dir, "artifact_triage_pack_new.txt"), (200, 200))
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "running",
                        "active_run_id": "run-active",
                        "active_phase": "B",
                        "last_shadow_pipeline_run_id": "run-complete",
                        "last_shadow_pipeline_phase_run_ids": {
                            "B": "run-b",
                            "C": "run-c",
                            "D": "run-d",
                        },
                    },
                    f,
                )

            captured = {}

            def fake_collect_support_bundle(include_traceback=False, extra_meta=None, extra_files=None, progress_callback=None, evidence_manifest=None):
                captured["include_traceback"] = include_traceback
                captured["extra_meta"] = extra_meta
                captured["extra_files"] = list(extra_files or [])
                captured["evidence_manifest"] = evidence_manifest
                return os.path.join(lab_root, "bundle.zip")

            def fake_submit_bundle_with_delivery_diagnostics(zip_path=None, allow_interactive_reauth=False):
                return True, "ok", {}

            def fake_delivery_diagnostics():
                return {}

            old_collect = cloud_readiness.collect_support_bundle
            old_submit = cloud_readiness._submit_bundle_with_delivery_diagnostics
            old_delivery = cloud_readiness._collect_delivery_diagnostics
            try:
                cloud_readiness.collect_support_bundle = fake_collect_support_bundle
                cloud_readiness._submit_bundle_with_delivery_diagnostics = fake_submit_bundle_with_delivery_diagnostics
                cloud_readiness._collect_delivery_diagnostics = fake_delivery_diagnostics
                ok = cloud_readiness._maybe_send_cloud_health_failure_report(
                    lab_root,
                    {
                        "issues": [
                            {
                                "code": "PHASE_C_FAILED",
                                "message": "Phase C failed with error_code=PHASE_C_DB_WRITE_ERROR.",
                            }
                        ]
                    },
                    {"escalated_codes": ["PHASE_C_FAILED"]},
                )
            finally:
                cloud_readiness.collect_support_bundle = old_collect
                cloud_readiness._submit_bundle_with_delivery_diagnostics = old_submit
                cloud_readiness._collect_delivery_diagnostics = old_delivery

            self.assertTrue(ok)
            archive_names = _effective_bundle_archive_names(
                captured.get("extra_files"), captured.get("evidence_manifest")
            )
            self.assertIn("cloud_health_diagnostics.json", archive_names)
            self.assertIn("artifact_discovery_summary_new.json", archive_names)
            self.assertIn("artifact_discovery_summary_new.txt", archive_names)
            self.assertNotIn("artifact_discovery_summary_old.json", archive_names)
            self.assertIn("ingest_write_summary_new.json", archive_names)
            self.assertIn("ingest_write_summary_new.txt", archive_names)
            self.assertNotIn("ingest_write_summary_old.json", archive_names)
            self.assertIn("qa_canonical_summary_new.json", archive_names)
            self.assertIn("qa_reject_samples_new.jsonl", archive_names)
            self.assertIn("projection_parity_summary_new.json", archive_names)
            self.assertIn("projection_parity_summary_new.txt", archive_names)
            self.assertIn("shadow_run_report_new.json", archive_names)
            self.assertIn("layer1_join_debug_pack_new.txt", archive_names)
            self.assertIn("layer1_join_debug_summary_new.json", archive_names)
            self.assertIn("layer1_join_debug_samples_new.jsonl", archive_names)
            self.assertIn("run_artifact_index_latest.txt", archive_names)
            self.assertNotIn("run_artifact_index_new.txt", archive_names)
            self.assertIn("artifact_triage_pack_latest.txt", archive_names)
            self.assertNotIn("artifact_triage_pack_new.txt", archive_names)
            self.assertIn("report_delivery_status.txt", archive_names)
            extra_meta = captured.get("extra_meta") or {}
            self.assertEqual("lab_root_current", extra_meta.get("diagnostics_state_scope"))
            self.assertEqual("lab_root_current", extra_meta.get("run_cursor_scope"))
            self.assertEqual("current_lab_state", extra_meta.get("context_pack_scope"))
            self.assertEqual("review_required", extra_meta.get("coherence_status"))
            self.assertEqual("running", extra_meta.get("pipeline_state"))
            self.assertEqual("B", extra_meta.get("active_phase"))
            self.assertEqual("run-active", extra_meta.get("active_run_id"))
            self.assertEqual("run-complete", extra_meta.get("last_completed_run_id"))
            self.assertEqual("run-c", extra_meta.get("phase_run_ids", {}).get("C"))
            with open(os.path.join(reports_dir, "report_delivery_status.txt"), "r", encoding="utf-8") as f:
                delivery_status = f.read()
            self.assertIn("Report Delivery Status", delivery_status)
            self.assertNotEqual("status", delivery_status.strip())
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_cloud_health_escalation_skips_stale_operator_triage_evidence(self):
        import shutil
        from MediCafe import cloud_readiness

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir)
        try:
            def write_report(name, payload, mtime):
                path = os.path.join(reports_dir, name)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(payload)
                os.utime(path, (mtime, mtime))
                return path

            write_report("run_artifact_index_older_allowed.txt", "run_id=run-c\nindex", 200)
            write_report("run_artifact_index_newer_stale.txt", "run_id=stale-run\nstale index", 300)
            write_report("artifact_triage_pack_older_allowed.txt", "recommendation_anchor_run_id=run-active\ntriage", 200)
            write_report("artifact_triage_pack_newer_stale.txt", "run_id=stale-run\nstale triage", 300)
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "running",
                        "active_run_id": "run-active",
                        "last_shadow_pipeline_run_id": "run-complete",
                        "last_shadow_pipeline_phase_run_ids": {
                            "C": "run-c",
                        },
                    },
                    f,
                )

            captured = {}

            def fake_collect_support_bundle(include_traceback=False, extra_meta=None, extra_files=None, progress_callback=None, evidence_manifest=None):
                captured["extra_files"] = list(extra_files or [])
                captured["evidence_manifest"] = evidence_manifest
                return os.path.join(lab_root, "bundle.zip")

            def fake_submit_bundle_with_delivery_diagnostics(zip_path=None, allow_interactive_reauth=False):
                return True, "ok", {}

            def fake_delivery_diagnostics():
                return {}

            old_collect = cloud_readiness.collect_support_bundle
            old_submit = cloud_readiness._submit_bundle_with_delivery_diagnostics
            old_delivery = cloud_readiness._collect_delivery_diagnostics
            try:
                cloud_readiness.collect_support_bundle = fake_collect_support_bundle
                cloud_readiness._submit_bundle_with_delivery_diagnostics = fake_submit_bundle_with_delivery_diagnostics
                cloud_readiness._collect_delivery_diagnostics = fake_delivery_diagnostics
                ok = cloud_readiness._maybe_send_cloud_health_failure_report(
                    lab_root,
                    {
                        "issues": [
                            {
                                "code": "PHASE_C_FAILED",
                                "message": "Phase C failed with error_code=PHASE_C_DB_WRITE_ERROR.",
                                "run_id": "run-c",
                            }
                        ]
                    },
                    {"escalated_codes": ["PHASE_C_FAILED"]},
                )
            finally:
                cloud_readiness.collect_support_bundle = old_collect
                cloud_readiness._submit_bundle_with_delivery_diagnostics = old_submit
                cloud_readiness._collect_delivery_diagnostics = old_delivery

            self.assertTrue(ok)
            archive_names = _effective_bundle_archive_names(
                captured.get("extra_files"), captured.get("evidence_manifest")
            )
            self.assertIn("run_artifact_index_older_allowed.txt", archive_names)
            self.assertNotIn("run_artifact_index_newer_stale.txt", archive_names)
            self.assertIn("artifact_triage_pack_older_allowed.txt", archive_names)
            self.assertNotIn("artifact_triage_pack_newer_stale.txt", archive_names)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_cloud_health_escalation_falls_back_when_run_scope_unknown(self):
        """If diagnostics_state has no run ids, still attach triage/index (pre-scoping behavior)."""
        import shutil
        from MediCafe import cloud_readiness

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir)
        try:
            with open(os.path.join(reports_dir, "run_artifact_index_latest.txt"), "w", encoding="utf-8") as f:
                f.write("index-latest\n")
            with open(os.path.join(reports_dir, "artifact_triage_pack_latest.txt"), "w", encoding="utf-8") as f:
                f.write("triage-latest\n")
            # No diagnostics_state.json — _cloud_health_scope_run_ids is empty.

            captured = {}

            def fake_collect_support_bundle(include_traceback=False, extra_meta=None, extra_files=None, progress_callback=None, evidence_manifest=None):
                captured["extra_files"] = list(extra_files or [])
                captured["evidence_manifest"] = evidence_manifest
                return os.path.join(lab_root, "bundle.zip")

            def fake_submit_bundle_with_delivery_diagnostics(zip_path=None, allow_interactive_reauth=False):
                return True, "ok", {}

            def fake_delivery_diagnostics():
                return {}

            old_collect = cloud_readiness.collect_support_bundle
            old_submit = cloud_readiness._submit_bundle_with_delivery_diagnostics
            old_delivery = cloud_readiness._collect_delivery_diagnostics
            try:
                cloud_readiness.collect_support_bundle = fake_collect_support_bundle
                cloud_readiness._submit_bundle_with_delivery_diagnostics = fake_submit_bundle_with_delivery_diagnostics
                cloud_readiness._collect_delivery_diagnostics = fake_delivery_diagnostics
                ok = cloud_readiness._maybe_send_cloud_health_failure_report(
                    lab_root,
                    {
                        "issues": [
                            {
                                "code": "PHASE_C_FAILED",
                                "message": "Phase C failed with error_code=PHASE_C_DB_WRITE_ERROR.",
                            }
                        ]
                    },
                    {"escalated_codes": ["PHASE_C_FAILED"]},
                )
            finally:
                cloud_readiness.collect_support_bundle = old_collect
                cloud_readiness._submit_bundle_with_delivery_diagnostics = old_submit
                cloud_readiness._collect_delivery_diagnostics = old_delivery

            self.assertTrue(ok)
            archive_names = _effective_bundle_archive_names(
                captured.get("extra_files"), captured.get("evidence_manifest")
            )
            self.assertIn("run_artifact_index_latest.txt", archive_names)
            self.assertIn("artifact_triage_pack_latest.txt", archive_names)
        finally:
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_phase_rows_use_v2_phase_run_id_map(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_shadow_pipeline_phase_run_ids": {
                            "B": "rid-b",
                            "C": "rid-c",
                            "D": "rid-d",
                            "E": "rid-e",
                        },
                        "last_shadow_pipeline_ok": False,
                        "last_shadow_pipeline_failed_phase": "E",
                        "last_shadow_pipeline_error_code": "PHASE_E_DB_WRITE_ERROR",
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("B:?", joined)
            self.assertIn("run_id=rid-b", joined)
            self.assertIn("C:?", joined)
            self.assertIn("run_id=rid-c", joined)
            self.assertIn("D:?", joined)
            self.assertIn("run_id=rid-d", joined)
            self.assertIn("E:?", joined)
            self.assertIn("run_id=rid-e", joined)
            self.assertNotIn("state=not_run", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_pending_phase_rows_render_as_running_during_active_pipeline(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "pipeline_state": "running",
                        "active_phase": "C",
                        "active_run_id": "rid-active",
                        "last_shadow_pipeline_run_id": "rid-active",
                        "last_shadow_pipeline_phase_run_ids": {"B": "rid-b"},
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("state=awaiting_phase_write", joined)
            self.assertNotIn("PHASE_D_NOT_RUN", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_resolved_phase_d_remediation_does_not_emit_active_issue(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "phase_d_remediation": {
                            "status": "resolved",
                            "issue_code": "",
                            "verification_target": "none",
                            "verification_scope": "none",
                            "context_run_id": "rid-d",
                            "milestone_exit_ready": False,
                        }
                    },
                    f,
                    indent=2,
                )
            diagnostics = _collect_health_diagnostics(lab_root, auto_resolve=False)
            codes = [item.get("code") for item in diagnostics.get("issues", [])]
            self.assertNotIn("PHASE_D_REMEDIATION_ACTIVE", codes)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_health_snapshot_surfaces_post_medisoft_rows(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_discovery_dat_telemetry": {
                            "dat_configured_root_count": 1,
                            "dat_configured_root_missing_count": 1,
                            "dat_selected_root_count": 1,
                            "dat_selection_mode": "fallback",
                            "dat_selected_root_source_id": "dat_fallback",
                            "dat_existing_empty_root_count": 1,
                            "dat_effective_root_source_id": "dat_fallback",
                            "dat_manifest_rows_count": 0,
                            "post_medisoft_blocked_stage": "discovery",
                        },
                        "last_phase_d_dat_telemetry": {
                            "dat_selected_count": 1,
                            "dat_qa_pass_count": 0,
                            "dat_qa_reject_count": 1,
                            "dat_canonical_record_count": 0,
                            "post_medisoft_exercised": False,
                            "post_medisoft_blocked_stage": "qa",
                        },
                    },
                    f,
                    indent=2,
                )
            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("Post-MediSoft: status=BLOCKED, blocked=qa, manifest=0", joined)
            self.assertIn("DAT Roots: cfg=1, missing=1, selected=1, selection=fallback", joined)
            self.assertIn("DAT Roots Detail: selected=dat_fallback, empty=1, effective=dat_fallback", joined)
            self.assertIn("DAT Phase D: selected=1, qa_pass=0, qa_reject=1, canonical=0", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_health_snapshot_includes_data_plane_counts(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_discovery_ok": True,
                        "last_phase_c_ok": True,
                        "last_phase_d_ok": True,
                        "last_phase_e_ok": True,
                        "last_shadow_pipeline_ok": True,
                        "last_contract_parity_status": "pass",
                        "last_baseline_parity_status": "pass",
                        "last_discovery_counts_by_class": {"csv": 2},
                    },
                    f,
                    indent=2,
                )

            db_path = os.path.join(lab_root, "unified_model_xp.db")
            conn = sqlite3.connect(db_path)
            conn.execute("CREATE TABLE patient (patient_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE coverage (coverage_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE encounter (encounter_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE claim (claim_id INTEGER PRIMARY KEY, encounter_id INTEGER)")
            conn.execute("CREATE TABLE claim_line (claim_line_id INTEGER PRIMARY KEY, claim_id INTEGER)")
            conn.execute("CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE qa_result (qa_result_id INTEGER PRIMARY KEY, status TEXT)")
            conn.execute("CREATE TABLE replay_queue (replay_id INTEGER PRIMARY KEY, status TEXT)")
            conn.execute("CREATE TABLE extracted_canonical_record (canonical_record_id INTEGER PRIMARY KEY)")
            conn.execute(
                "CREATE TABLE projection_result (projection_id INTEGER PRIMARY KEY, projection_type TEXT, projection_status TEXT)"
            )
            conn.execute("INSERT INTO patient (patient_id) VALUES (1)")
            conn.execute("INSERT INTO qa_result (qa_result_id, status) VALUES (1, 'reject')")
            conn.execute("INSERT INTO replay_queue (replay_id, status) VALUES (1, 'pending')")
            conn.execute("INSERT INTO projection_result (projection_id, projection_type, projection_status) VALUES (1, 'patient_v1', 'success')")
            conn.commit()
            conn.close()

            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("Data Plane: status=", joined)
            self.assertIn("patient=1", joined)
            self.assertIn("replay_rows=1", joined)
            self.assertIn("qa_reject=1", joined)
            self.assertIn("replay_pending=1", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)

    def test_health_snapshot_prefers_version_scoped_quality_counts(self):
        lab_root = tempfile.mkdtemp()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(
                    {
                        "last_qa_policy_version": "qa_v2",
                        "last_projection_version": "proj_v2",
                    },
                    f,
                    indent=2,
                )

            db_path = os.path.join(lab_root, "unified_model_xp.db")
            conn = sqlite3.connect(db_path)
            conn.execute(
                "CREATE TABLE patient ("
                "patient_id INTEGER PRIMARY KEY, "
                "patient_key TEXT, "
                "external_patient_id TEXT)"
            )
            conn.execute("CREATE TABLE coverage (coverage_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE encounter (encounter_id INTEGER PRIMARY KEY)")
            conn.execute("CREATE TABLE claim (claim_id INTEGER PRIMARY KEY, encounter_id INTEGER)")
            conn.execute("CREATE TABLE claim_line (claim_line_id INTEGER PRIMARY KEY, claim_id INTEGER)")
            conn.execute("CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY)")
            conn.execute(
                "CREATE TABLE qa_result ("
                "qa_result_id INTEGER PRIMARY KEY, "
                "status TEXT, "
                "qa_version TEXT)"
            )
            conn.execute("CREATE TABLE replay_queue (replay_id INTEGER PRIMARY KEY, status TEXT)")
            conn.execute("CREATE TABLE extracted_canonical_record (canonical_record_id INTEGER PRIMARY KEY)")
            conn.execute(
                "CREATE TABLE projection_result ("
                "projection_id INTEGER PRIMARY KEY, "
                "projection_type TEXT, "
                "projection_status TEXT, "
                "projection_version TEXT)"
            )
            conn.execute("INSERT INTO patient (patient_id, patient_key, external_patient_id) VALUES (1, 'p1', '11111')")
            conn.execute("INSERT INTO qa_result (qa_result_id, status, qa_version) VALUES (1, 'reject', 'qa_v1')")
            conn.execute("INSERT INTO qa_result (qa_result_id, status, qa_version) VALUES (2, 'reject', 'qa_v2')")
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, projection_type, projection_status, projection_version) "
                "VALUES (1, 'patient_v1', 'success', 'proj_v1')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, projection_type, projection_status, projection_version) "
                "VALUES (2, 'patient_v1', 'rejected', 'proj_v2')"
            )
            conn.commit()
            conn.close()

            lines = build_cloud_health_lines(lab_root, auto_pipeline=True, auto_health=True)
            joined = "\n".join(lines)
            self.assertIn("Quality: qa_reject=1, replay_pending=0, proj_success=0, proj_reject=1", joined)
            self.assertIn("Quality Scope: qa_version=qa_v2, projection_version=proj_v2", joined)
        finally:
            import shutil
            shutil.rmtree(lab_root, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
