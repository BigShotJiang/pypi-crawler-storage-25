#!/usr/bin/env python
"""
Phase F reporting and packaging: unit tests.
Tests success, partial input, failure, lock-fail, determinism, idempotency, no DB side effects.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_f_common import (
    MISSING_MARKER,
    PHASE_F_LOCK_FAIL,
    PHASE_F_RUN_ID_MISMATCH,
    build_evidence_index,
    build_report_payload,
    resolve_source_paths,
    serialize_report_json,
)
from package_shadow_run_report import DIAGNOSTICS_STATE_MISSING

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab(lab_root=None):
    """Create temp lab dir with reports and state."""
    if lab_root is None:
        lab_root = tempfile.mkdtemp()
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    return lab_root, reports_dir


def _write_phase_summary(reports_dir, phase, rid, data):
    """Write a phase summary JSON."""
    patterns = {
        "B": "artifact_discovery_summary_{0}.json",
        "C": "ingest_write_summary_{0}.json",
        "D": "qa_canonical_summary_{0}.json",
        "E": "projection_parity_summary_{0}.json",
    }
    fname = patterns.get(phase, "").format(rid)
    path = os.path.join(reports_dir, fname)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    return path


class TestPhaseFCommon(unittest.TestCase):
    """phase_f_common: resolve_source_paths, build_report_payload, serialize."""

    def test_resolve_source_paths_missing(self):
        lab_root, reports_dir = _make_lab()
        try:
            paths = resolve_source_paths(lab_root, {})
            for phase in ("B", "C", "D", "E"):
                self.assertEqual(paths.get(phase), MISSING_MARKER)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_resolve_source_paths_partial(self):
        lab_root, reports_dir = _make_lab()
        try:
            _write_phase_summary(reports_dir, "B", "rid-b", {"manifest_sha256": "h1"})
            paths = resolve_source_paths(lab_root, {"B": "rid-b", "C": "rid-c"})
            self.assertNotEqual(paths.get("B"), MISSING_MARKER)
            self.assertEqual(paths.get("C"), MISSING_MARKER)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_build_report_payload(self):
        lab_root, _ = _make_lab()
        try:
            source_paths = {"B": MISSING_MARKER, "C": MISSING_MARKER, "D": MISSING_MARKER, "E": MISSING_MARKER}
            source_data = {
                "B": {"dat_telemetry": {
                    "dat_root_scanned_count": 1,
                    "dat_root_existing_count": 1,
                    "dat_configured_root_count": 1,
                    "dat_configured_root_existing_count": 1,
                    "dat_configured_root_missing_count": 0,
                    "dat_fallback_root_count": 0,
                    "dat_selected_root_count": 1,
                    "dat_selection_mode": "configured",
                    "dat_selected_root_source_id": "dat_cfg_0",
                    "dat_existing_empty_root_count": 0,
                    "dat_effective_root_source_id": "dat_cfg_0",
                    "dat_root_yield_counts_by_source": {"dat_cfg_0": 2},
                    "dat_yielding_root_source_ids": ["dat_cfg_0"],
                    "dat_manifest_rows_count": 2,
                }},
                "D": {"dat_telemetry": {
                    "dat_selected_count": 2,
                    "dat_qa_pass_count": 2,
                    "dat_qa_reject_count": 0,
                    "dat_qa_reject_counts_by_reason": {"QA_DAT_DATE_OF_SERVICE_MISSING": 1},
                    "dat_field_presence_by_alias": {"records_seen": 2, "PATID": 2, "DATE1": 2, "INSID": 2},
                    "dat_parse_diagnostics": {"tuple_parse_failure_count": 1, "first_failure_class": "ValueError"},
                    "dat_file_prefix_counts": {"Z": 2},
                    "dat_reject_file_prefix_counts": {"ZM": 1},
                    "dat_canonical_record_count": 2,
                    "phase_d_entity_scope": "v2",
                    "post_medisoft_exercised": True
                }},
                "E": {"contract_parity_status": "pass", "eligible_count": 5},
            }
            payload = build_report_payload(
                lab_root, "run1", "cli", True, "", "",
                source_paths, source_data
            )
            self.assertEqual(payload["run_id"], "run1")
            self.assertEqual(payload["run_id_source"], "cli")
            self.assertTrue(payload["pipeline_ok"])
            self.assertEqual(payload["phase_e_contract_parity_status"], "pass")
            self.assertEqual(payload["phase_e_eligible_count"], 5)
            self.assertEqual(payload["phase_b_dat_manifest_rows_count"], 2)
            self.assertEqual(payload["phase_b_dat_selection_mode"], "configured")
            self.assertEqual(payload["phase_b_dat_selected_root_source_id"], "dat_cfg_0")
            self.assertEqual(payload["phase_b_dat_effective_root_source_id"], "dat_cfg_0")
            self.assertEqual(payload["phase_b_dat_existing_empty_root_count"], 0)
            self.assertEqual(payload["phase_b_dat_root_yield_counts_by_source"], {"dat_cfg_0": 2})
            self.assertEqual(payload["phase_b_dat_yielding_root_source_ids"], ["dat_cfg_0"])
            self.assertEqual(payload["phase_d_dat_canonical_record_count"], 2)
            self.assertEqual(payload["phase_d_dat_qa_reject_counts_by_reason"], {"QA_DAT_DATE_OF_SERVICE_MISSING": 1})
            self.assertEqual(payload["phase_d_dat_field_presence_by_alias"], {"records_seen": 2, "PATID": 2, "DATE1": 2, "INSID": 2})
            self.assertEqual(payload["phase_d_dat_parse_diagnostics"], {"tuple_parse_failure_count": 1, "first_failure_class": "ValueError"})
            self.assertEqual(payload["phase_d_dat_file_prefix_counts"], {"Z": 2})
            self.assertEqual(payload["phase_d_dat_reject_file_prefix_counts"], {"ZM": 1})
            self.assertEqual(payload["phase_d_rows_selected"], 0)
            self.assertEqual(payload["phase_d_artifact_class_filter"], [])
            self.assertEqual(payload["phase_d_qa_policy_version"], "")
            self.assertEqual(payload["phase_d_entity_scope"], "v2")
            self.assertEqual(payload["post_medisoft_status"], "exercised")
            self.assertTrue(payload.get("machine_hostname", "") is not None)
            self.assertTrue(bool(payload.get("machine_python_version", "")))
            self.assertTrue(bool(payload.get("machine_app_version", "")))
            self.assertTrue("machine_test_mode" in payload)
            self.assertEqual(payload.get("phase_d_dat_v2_inserted_total", 0), 0)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_build_report_payload_includes_phase_run_ids_when_provided(self):
        lab_root, _ = _make_lab()
        try:
            source_paths = {"B": MISSING_MARKER, "C": MISSING_MARKER, "D": MISSING_MARKER, "E": MISSING_MARKER}
            source_data = {"D": {"qa_pass_count": 0, "qa_reject_count": 0, "dat_telemetry": {}}}
            pr = {"B": "rb", "C": "rc", "D": "rd", "E": "re"}
            payload = build_report_payload(
                lab_root, "anchor1", "state", True, "", "",
                source_paths, source_data, phase_run_ids=pr
            )
            self.assertEqual(payload.get("phase_run_ids"), {"B": "rb", "C": "rc", "D": "rd", "E": "re"})
            self.assertEqual(payload.get("run_id"), "anchor1")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_build_report_payload_includes_phase_c_lineage_shadow_keys(self):
        lab_root, _ = _make_lab()
        try:
            source_paths = {"B": MISSING_MARKER, "C": MISSING_MARKER, "D": MISSING_MARKER, "E": MISSING_MARKER}
            source_data = {
                "C": {
                    "phase_c_duplicate_dominant": True,
                    "phase_c_duplicate_only": False,
                    "rows_inserted_by_class": {"dat": 1},
                    "rows_skipped_duplicate_by_class": {"dat": 5},
                },
                "D": {"qa_pass_count": 0, "qa_reject_count": 0, "dat_telemetry": {}},
            }
            payload = build_report_payload(
                lab_root, "rid-c", "cli", True, "", "",
                source_paths, source_data
            )
            self.assertTrue(payload.get("phase_c_duplicate_dominant"))
            self.assertFalse(payload.get("phase_c_duplicate_only"))
            self.assertEqual(payload.get("phase_c_rows_inserted_by_class"), {"dat": 1})
            self.assertEqual(payload.get("phase_c_rows_skipped_duplicate_by_class"), {"dat": 5})
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_build_report_payload_preserves_not_exercised(self):
        lab_root, _ = _make_lab()
        try:
            source_paths = {"B": MISSING_MARKER, "C": MISSING_MARKER, "D": MISSING_MARKER, "E": MISSING_MARKER}
            source_data = {
                "B": {"dat_telemetry": {
                    "post_medisoft_blocked_stage": "not_configured",
                    "dat_manifest_rows_count": 0,
                    "dat_configured_root_missing_count": 1,
                    "dat_fallback_root_count": 0,
                    "dat_existing_empty_root_count": 0,
                    "dat_selection_mode": "none",
                    "dat_selected_root_source_id": "",
                    "dat_effective_root_source_id": "",
                    "dat_root_yield_counts_by_source": {},
                    "dat_yielding_root_source_ids": [],
                }},
                "D": {"dat_telemetry": {"dat_selected_count": 0, "dat_qa_pass_count": 0, "dat_qa_reject_count": 0, "post_medisoft_blocked_stage": "not_exercised"}},
            }
            payload = build_report_payload(lab_root, "run2", "cli", True, "", "", source_paths, source_data)
            self.assertEqual(payload["post_medisoft_status"], "not_exercised")
            self.assertEqual(payload["post_medisoft_blocked_stage"], "")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_build_report_payload_flattens_csv_docx_join_counts(self):
        lab_root, _ = _make_lab()
        try:
            source_paths = {"B": MISSING_MARKER, "C": MISSING_MARKER, "D": MISSING_MARKER, "E": MISSING_MARKER}
            source_data = {
                "D": {
                    "csv_docx_join_telemetry": {
                        "join_key": "patient_id+surgery_date",
                        "csv_candidate_count": 3,
                        "csv_join_key_count": 2,
                        "docx_candidate_count": 2,
                        "docx_join_key_count": 1,
                        "matched_count": 1,
                        "csv_only_count": 2,
                        "docx_only_count": 1,
                        "ambiguous_count": 0,
                        "ambiguous_negotiation": "multiple_candidates_shared_join_key_no_deterministic_docx_winner",
                        "ambiguous_default_policy": "suppress_docx_enrichment_keep_csv_row",
                        "negotiation_run_id": "run3",
                        "negotiation_telemetry_id": 17,
                        "negotiation_log_ref": "qa_planning_telemetry_log#17(run_id=run3)",
                        "primary_join_blocker_class": "missing_claim_key",
                        "join_blocker_counts": {"missing_claim_key": 2, "missing_claim_number": 1},
                    },
                    "dat_csv_join_telemetry": {
                        "join_key": "patient_id+surgery_date",
                        "matched_count": 1,
                        "csv_only_count": 0,
                        "dat_only_count": 0,
                        "ambiguous_multi_dat_count": 0,
                        "payer_mismatch_count": 0,
                        "dos_mismatch_count": 0,
                        "invalid_external_id_csv_count": 1,
                        "invalid_external_id_dat_count": 2,
                        "invalid_external_id_join_block_count": 3,
                        "primary_join_blocker_class": "dat_invalid_patient_id",
                        "join_blocker_counts": {
                            "dat_invalid_patient_id": 2,
                            "csv_invalid_patient_id": 1,
                            "join_key_absent": 0,
                        },
                    },
                },
            }
            payload = build_report_payload(lab_root, "run3", "cli", True, "", "", source_paths, source_data)
            self.assertEqual(payload["phase_d_csv_docx_join_key"], "patient_id+surgery_date")
            self.assertEqual(payload["phase_d_csv_docx_join_csv_candidate_count"], 3)
            self.assertEqual(payload["phase_d_csv_docx_join_csv_join_key_count"], 2)
            self.assertEqual(payload["phase_d_csv_docx_join_docx_candidate_count"], 2)
            self.assertEqual(payload["phase_d_csv_docx_join_docx_join_key_count"], 1)
            self.assertEqual(payload["phase_d_csv_docx_join_matched_count"], 1)
            self.assertEqual(payload["phase_d_csv_docx_join_csv_only_count"], 2)
            self.assertEqual(payload["phase_d_csv_docx_join_docx_only_count"], 1)
            self.assertEqual(payload["phase_d_csv_docx_join_ambiguous_count"], 0)
            self.assertEqual(payload["phase_d_csv_docx_join_ambiguous_negotiation"], "multiple_candidates_shared_join_key_no_deterministic_docx_winner")
            self.assertEqual(payload["phase_d_csv_docx_join_ambiguous_default_policy"], "suppress_docx_enrichment_keep_csv_row")
            self.assertEqual(payload["phase_d_csv_docx_join_negotiation_run_id"], "run3")
            self.assertEqual(payload["phase_d_csv_docx_join_negotiation_telemetry_id"], 17)
            self.assertEqual(payload["phase_d_csv_docx_join_negotiation_log_ref"], "qa_planning_telemetry_log#17(run_id=run3)")
            self.assertEqual(payload["phase_d_csv_docx_join_primary_join_blocker_class"], "missing_claim_key")
            self.assertEqual(payload["phase_d_csv_docx_join_blocker_missing_claim_key"], 2)
            self.assertEqual(payload["phase_d_csv_docx_join_blocker_missing_claim_number"], 1)
            self.assertEqual(payload["phase_d_dat_csv_join_primary_join_blocker_class"], "dat_invalid_patient_id")
            self.assertEqual(payload["phase_d_dat_csv_join_invalid_external_id_csv_count"], 1)
            self.assertEqual(payload["phase_d_dat_csv_join_invalid_external_id_dat_count"], 2)
            self.assertEqual(payload["phase_d_dat_csv_join_invalid_external_id_join_block_count"], 3)
            self.assertEqual(payload["phase_d_dat_csv_join_blocker_dat_invalid_patient_id"], 2)
            self.assertEqual(payload["phase_d_dat_csv_join_blocker_csv_invalid_patient_id"], 1)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_build_report_payload_flattens_dat_v2_compact_keys(self):
        lab_root, _ = _make_lab()
        try:
            source_paths = {"B": MISSING_MARKER, "C": MISSING_MARKER, "D": MISSING_MARKER, "E": MISSING_MARKER}
            source_data = {
                "D": {
                    "dat_telemetry": {
                        "dat_selected_count": 1,
                        "dat_qa_pass_count": 1,
                        "dat_qa_reject_count": 0,
                        "dat_canonical_record_count": 1,
                        "post_medisoft_exercised": True,
                        "phase_d_dat_v2_payload_attempted_total": 5,
                        "phase_d_dat_v2_dedup_attempted_total": 4,
                        "phase_d_dat_v2_inserted_total": 3,
                        "phase_d_dat_v2_ignored_duplicate_total": 1,
                        "phase_d_dat_v2_skipped_total": 0,
                        "phase_d_dat_v2_constraint_failed_total": 0,
                        "phase_d_dat_v2_inserted_patient": 1,
                        "phase_d_dat_v2_inserted_payer": 1,
                        "phase_d_dat_v2_inserted_insurance_plan": 1,
                        "phase_d_dat_v2_inserted_coverage": 0,
                        "phase_d_dat_v2_inserted_encounter": 0,
                        "phase_d_dat_v2_inserted_claim": 0,
                        "phase_d_dat_v2_inserted_claim_line": 0,
                    }
                },
            }
            payload = build_report_payload(lab_root, "run_v2", "cli", True, "", "", source_paths, source_data)
            self.assertEqual(payload["phase_d_dat_v2_payload_attempted_total"], 5)
            self.assertEqual(payload["phase_d_dat_v2_inserted_total"], 3)
            self.assertEqual(payload["phase_d_dat_v2_ignored_duplicate_total"], 1)
            self.assertEqual(payload["phase_d_dat_v2_inserted_payer"], 1)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_serialize_determinism(self):
        obj = {"b": 2, "a": 1, "c": 3}
        s1 = serialize_report_json(obj)
        s2 = serialize_report_json(obj)
        self.assertEqual(s1, s2)
        self.assertTrue(s1.index('"a"') < s1.index('"b"'))


class TestPackageShadowRunReport(unittest.TestCase):
    """package_shadow_run_report: success, partial, failure, lock-fail, idempotency, no DB effects."""

    def test_success_packaging(self):
        from package_shadow_run_report import run_package
        lab_root, reports_dir = _make_lab()
        try:
            rid_b = "20260101-120000-abc12345"
            rid_c = "20260101-120001-def67890"
            rid_d = "20260101-120002-ghi11111"
            rid_e = "20260101-120003-jkl22222"
            _write_phase_summary(reports_dir, "B", rid_b, {"manifest_sha256": "h1", "config_hash": "c1", "crosswalk_hash": "x1"})
            _write_phase_summary(reports_dir, "C", rid_c, {"rows_inserted": 10, "rows_skipped_duplicate": 2})
            _write_phase_summary(reports_dir, "D", rid_d, {"qa_pass_count": 8, "qa_reject_count": 2})
            _write_phase_summary(reports_dir, "E", rid_e, {"eligible_count": 5, "projected_success_this_run": 4,
                "projected_reject_this_run": 1, "contract_parity_status": "pass", "baseline_parity_status": "skipped"})
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run-pipeline",
                    "last_shadow_pipeline_ok": True,
                    "last_shadow_pipeline_phase_run_ids": {"B": rid_b, "C": rid_c, "D": rid_d, "E": rid_e},
                }, f, indent=2)
            with patch("lab_lock.acquire_lock"):
                with patch("lab_lock.release_lock"):
                    ok, rj, rt, ix, err, _, _detail = run_package(lab_root, "run-pipeline", "cli", auto_report=False)
            self.assertTrue(ok)
            self.assertIsNone(err)
            self.assertTrue(os.path.exists(rj))
            self.assertTrue(os.path.exists(rt))
            self.assertTrue(os.path.exists(ix))
            with open(rj, "r", encoding="utf-8") as f:
                report = json.load(f)
            self.assertEqual(report["phase_c_inserted_count"], 10)
            self.assertEqual(report["phase_e_contract_parity_status"], "pass")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_partial_input_missing_marker(self):
        from package_shadow_run_report import run_package
        lab_root, reports_dir = _make_lab()
        try:
            rid_b = "20260101-120000-abc12345"
            _write_phase_summary(reports_dir, "B", rid_b, {"manifest_sha256": "h1"})
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run-pipeline",
                    "last_shadow_pipeline_ok": True,
                    "last_shadow_pipeline_phase_run_ids": {"B": rid_b},
                }, f, indent=2)
            with patch("lab_lock.acquire_lock"):
                with patch("lab_lock.release_lock"):
                    ok, rj, rt, ix, err, _, _detail = run_package(lab_root, "run-pipeline", "cli", auto_report=False)
            self.assertTrue(ok)
            with open(rj, "r", encoding="utf-8") as f:
                report = json.load(f)
            self.assertIn(MISSING_MARKER, report.get("source_summary_paths", []))
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_failure_input(self):
        from package_shadow_run_report import run_package
        lab_root, reports_dir = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run-fail",
                    "last_shadow_pipeline_ok": False,
                    "last_shadow_pipeline_failed_phase": "C",
                    "last_shadow_pipeline_error_code": "PHASE_C_EXIT_1",
                    "last_shadow_pipeline_phase_run_ids": {"B": "rid-b"},
                }, f, indent=2)
            _write_phase_summary(reports_dir, "B", "rid-b", {"manifest_sha256": "h1"})
            with patch("lab_lock.acquire_lock"):
                with patch("lab_lock.release_lock"):
                    with patch("phase_e_auto_report.submit_phase_f_report", return_value=False) as mock_submit:
                        ok, rj, rt, ix, err, _, _detail = run_package(lab_root, "run-fail", "cli", auto_report=False)
            self.assertTrue(ok)
            mock_submit.assert_not_called()
            with open(rj, "r", encoding="utf-8") as f:
                report = json.load(f)
            self.assertFalse(report["pipeline_ok"])
            self.assertEqual(report["failed_phase"], "C")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_auto_report_true_triggers_submit_on_failure(self):
        """With auto_report=True and failure state, submit_phase_f_report is called."""
        from package_shadow_run_report import run_package
        lab_root, reports_dir = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run-fail",
                    "last_shadow_pipeline_ok": False,
                    "last_shadow_pipeline_failed_phase": "D",
                    "last_shadow_pipeline_error_code": "PHASE_D_EXIT_1",
                    "last_shadow_pipeline_phase_run_ids": {"B": "rid-b"},
                }, f, indent=2)
            _write_phase_summary(reports_dir, "B", "rid-b", {"manifest_sha256": "h1"})
            with patch("lab_lock.acquire_lock"):
                with patch("lab_lock.release_lock"):
                    with patch("phase_e_auto_report.submit_phase_f_report", return_value=False) as mock_submit:
                        ok, rj, rt, ix, err, _, _detail = run_package(lab_root, "run-fail", "cli", auto_report=True)
            self.assertTrue(ok)
            mock_submit.assert_called_once()
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_run_id_mismatch_returns_error(self):
        """When run_id_source is cli and state has different run_id, return PHASE_F_RUN_ID_MISMATCH."""
        from package_shadow_run_report import run_package
        lab_root, reports_dir = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "actual-run-in-state",
                    "last_shadow_pipeline_ok": True,
                    "last_shadow_pipeline_phase_run_ids": {},
                }, f)
            ok, rj, rt, ix, err, _, _detail = run_package(lab_root, "requested-run-id", "cli", auto_report=False)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_F_RUN_ID_MISMATCH)
            artifact_path = os.path.join(reports_dir, "phase_f_mismatch_requested-run-id.txt")
            self.assertTrue(os.path.exists(artifact_path))
            with open(artifact_path, "r", encoding="utf-8") as f:
                content = f.read()
            self.assertIn("PHASE_F_RUN_ID_MISMATCH", content)
            self.assertIn("requested-run-id", content)
            self.assertIn("actual-run-in-state", content)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_lock_fail_returns_error(self):
        from package_shadow_run_report import run_package
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({"last_shadow_pipeline_run_id": "run1"}, f)
            with patch("lab_lock.acquire_lock", side_effect=SystemExit(1)):
                ok, rj, rt, ix, err, _, detail = run_package(lab_root, "run1", "cli", auto_report=False)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_F_LOCK_FAIL)
            self.assertTrue(detail.get("lock_diag_path"))
            self.assertTrue(os.path.exists(detail.get("lock_diag_path")))
            self.assertEqual(detail.get("lock_outcome"), "hard_lock_fail")
            self.assertTrue(detail.get("recoverability"))
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_missing_diagnostics_state_returns_error(self):
        from package_shadow_run_report import run_package
        lab_root, _ = _make_lab()
        try:
            ok, rj, rt, ix, err, _, _detail = run_package(lab_root, "run1", "cli", auto_report=False)
            self.assertFalse(ok)
            self.assertIsNone(rj)
            self.assertIsNone(rt)
            self.assertIsNone(ix)
            self.assertEqual(err, DIAGNOSTICS_STATE_MISSING)
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_manual_rerun_idempotency(self):
        from package_shadow_run_report import run_package
        lab_root, reports_dir = _make_lab()
        try:
            rid = "20260101-120000-abc12345"
            _write_phase_summary(reports_dir, "B", rid, {"manifest_sha256": "h1"})
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run-same",
                    "last_shadow_pipeline_ok": True,
                    "last_shadow_pipeline_phase_run_ids": {"B": rid},
                }, f, indent=2)
            with patch("lab_lock.acquire_lock"):
                with patch("lab_lock.release_lock"):
                    ok1, rj1, _, _, _, _, _ = run_package(lab_root, "run-same", "cli", auto_report=False)
                    ok2, rj2, _, _, _, _, _ = run_package(lab_root, "run-same", "cli", auto_report=False)
            self.assertTrue(ok1)
            self.assertTrue(ok2)
            self.assertEqual(rj1, rj2)
            self.assertTrue(os.path.exists(rj1))
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_no_db_side_effects(self):
        """Phase F must not mutate core tables."""
        from package_shadow_run_report import run_package
        lab_root, reports_dir = _make_lab()
        db_path = os.path.join(lab_root, "unified_model_xp.db")
        try:
            if os.path.exists(SQL_PATH):
                with open(SQL_PATH, "r", encoding="utf-8") as f:
                    conn = sqlite3.connect(db_path)
                    conn.executescript(f.read())
                    conn.commit()
                    counts_before = {}
                    for tbl in ("ingest_artifact", "qa_result", "extracted_canonical_record", "projection_result"):
                        try:
                            cur = conn.execute("SELECT COUNT(*) FROM {0}".format(tbl))
                            counts_before[tbl] = cur.fetchone()[0]
                        except Exception:
                            counts_before[tbl] = 0
                    conn.close()
            else:
                counts_before = {}
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run-db-test",
                    "last_shadow_pipeline_ok": True,
                    "last_shadow_pipeline_phase_run_ids": {},
                }, f)
            with patch("lab_lock.acquire_lock"):
                with patch("lab_lock.release_lock"):
                    run_package(lab_root, "run-db-test", "cli", auto_report=False)
            if os.path.exists(db_path):
                conn = sqlite3.connect(db_path)
                for tbl, before in counts_before.items():
                    try:
                        cur = conn.execute("SELECT COUNT(*) FROM {0}".format(tbl))
                        after = cur.fetchone()[0]
                        self.assertEqual(before, after, "Table {0} changed: {1} -> {2}".format(tbl, before, after))
                    except Exception:
                        pass
                conn.close()
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass


class TestRunShadowPipelineOrchestrator(unittest.TestCase):
    """Orchestrator-level tests for run_shadow_pipeline flow."""

    def test_run_phase_uses_subprocess(self):
        """_run_phase must use subprocess; validates import and real code path."""
        import run_shadow_pipeline as rsp
        lab_root, _ = _make_lab()
        tmp_root = tempfile.mkdtemp()
        try:
            script_dir = os.path.join(tmp_root, "scripts", "unified_model")
            os.makedirs(script_dir, exist_ok=True)
            stub_path = os.path.join(script_dir, "_phase_stub.py")
            with open(stub_path, "w", encoding="utf-8") as f:
                f.write("# minimal stub for _run_phase test\n")
            ok, rc = rsp._run_phase("_phase_stub.py", lab_root, sys.executable, tmp_root, {})
        except NameError as e:
            self.fail("_run_phase raised NameError (missing import?): {0}".format(e))
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
                shutil.rmtree(tmp_root, ignore_errors=True)
            except Exception:
                pass
        self.assertIsInstance(ok, bool)
        self.assertIsInstance(rc, int)

    def test_run_phase_bootstrap_keyboardinterrupt_maps_to_130(self):
        """Bootstrap control-event interruption should map to rc=130 without traceback."""
        import run_shadow_pipeline as rsp
        lab_root, _ = _make_lab()
        tmp_root = tempfile.mkdtemp()
        try:
            script_dir = os.path.join(tmp_root, "scripts", "unified_model")
            os.makedirs(script_dir, exist_ok=True)
            stub_path = os.path.join(script_dir, "bootstrap_lab.py")
            with open(stub_path, "w", encoding="utf-8") as f:
                f.write("# minimal bootstrap stub\n")
            with patch("run_shadow_pipeline.subprocess.call", side_effect=KeyboardInterrupt):
                ok, rc = rsp._run_phase("bootstrap_lab.py", lab_root, sys.executable, tmp_root, {})
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
                shutil.rmtree(tmp_root, ignore_errors=True)
            except Exception:
                pass
        self.assertFalse(ok)
        self.assertEqual(rc, 130)

    def test_lock_released_before_phase_f_send(self):
        """run_phase_f_report_send is called only after lock is released."""
        from run_shadow_pipeline import run_shadow_pipeline, PIPELINE_LOCK_NAME
        lab_root, reports_dir = _make_lab()
        lock_path = os.path.join(lab_root, PIPELINE_LOCK_NAME)
        send_called_lock_released = []

        def check_lock_then_send(*args, **kwargs):
            send_called_lock_released.append(not os.path.exists(lock_path))
            return False

        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run1",
                    "last_shadow_pipeline_ok": False,
                    "last_shadow_pipeline_phase_run_ids": {},
                }, f)
            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, True, {})
                    with patch("package_shadow_run_report.run_phase_f_report_send", side_effect=check_lock_then_send):
                        with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                            run_shadow_pipeline(lab_root)
            self.assertTrue(send_called_lock_released, "run_phase_f_report_send should have been called")
            self.assertTrue(send_called_lock_released[0], "Lock should be released when send runs")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_phase_f_send_success_suppresses_fallback(self):
        """When Phase F send succeeds, Phase E fallback must not run."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run1",
                    "last_shadow_pipeline_ok": False,
                    "last_shadow_pipeline_phase_run_ids": {},
                }, f)

            def mock_send_update_state(lab_root, rj, rt, ix, meta):
                rid = meta.get("run_id", "")
                st = {}
                if os.path.exists(state_path):
                    with open(state_path, "r", encoding="utf-8") as f:
                        st = json.load(f)
                st["phase_f_report_sent"] = True
                st["phase_f_report_sent_for_run_id"] = rid
                with open(state_path, "w", encoding="utf-8") as f:
                    json.dump(st, f)
                return True

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, True, {})
                    with patch("package_shadow_run_report.run_phase_f_report_send", side_effect=mock_send_update_state):
                        with patch("phase_e_auto_report.submit_phase_e_failure_report") as mock_fallback:
                            run_shadow_pipeline(lab_root)
                            mock_fallback.assert_not_called()
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_phase_f_send_false_does_not_trigger_fallback(self):
        """A False send result (e.g., dedup suppression) must not trigger fallback."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run1",
                    "last_shadow_pipeline_ok": False,
                    "last_shadow_pipeline_phase_run_ids": {},
                }, f)
            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, True, {})
                    with patch("package_shadow_run_report.run_phase_f_report_send", return_value=False):
                        with patch("phase_e_auto_report.submit_phase_e_failure_report") as mock_fallback:
                            run_shadow_pipeline(lab_root)
                            mock_fallback.assert_not_called()
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_healthy_phase_f_run_does_not_auto_send(self):
        """Healthy startup runs must not auto-send Phase F evidence telemetry."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run1",
                    "last_shadow_pipeline_ok": True,
                    "last_shadow_pipeline_phase_run_ids": {},
                    "last_contract_parity_status": "pass",
                }, f)
            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, True, {})
                    with patch("package_shadow_run_report.run_phase_f_report_send") as mock_send:
                        with patch("phase_e_auto_report.submit_phase_e_failure_report") as mock_fallback:
                            run_shadow_pipeline(lab_root)
                            mock_send.assert_not_called()
                            mock_fallback.assert_not_called()
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass


    def test_phase_f_send_exception_triggers_fallback(self):
        """When Phase F send raises, Phase E fallback must run."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "run1",
                    "last_shadow_pipeline_ok": False,
                    "last_shadow_pipeline_phase_run_ids": {},
                }, f)
            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, True, {})
                    with patch("package_shadow_run_report.run_phase_f_report_send", side_effect=RuntimeError("send failed")):
                        with patch("phase_e_auto_report.submit_phase_e_failure_report") as mock_fallback:
                            run_shadow_pipeline(lab_root)
                            mock_fallback.assert_called_once()
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_failed_phase_records_changed_phase_run_id_and_clears_stale_map(self):
        """A phase that writes its cursor before failing must be packaged by its current run id."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_shadow_pipeline_run_id": "old-run",
                    "last_shadow_pipeline_ok": False,
                    "last_shadow_pipeline_phase_run_ids": {"B": "old-b", "C": "old-c"},
                    "last_discovery_error_code": "",
                }, f)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_b_run_id": "old-b"}, f)

            def fake_run_phase(script_name, lab_root_arg, python_exe, repo_root, env):
                if script_name == "bootstrap_lab.py":
                    return True, 0
                if script_name == "discover_artifacts.py":
                    with open(cursor_path, "w", encoding="utf-8") as cf:
                        json.dump({"last_phase_b_run_id": "current-b"}, cf)
                    with open(state_path, "r", encoding="utf-8") as sf:
                        st = json.load(sf)
                    st["last_phase_b_error_code"] = "PHASE_B_ROOT_RESOLUTION_FAIL"
                    with open(state_path, "w", encoding="utf-8") as sf:
                        json.dump(st, sf)
                    return False, 1
                return True, 0

            with patch("run_shadow_pipeline._run_phase", side_effect=fake_run_phase):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)

            self.assertFalse(ok)
            self.assertEqual(failed_phase, "B")
            self.assertEqual(error_code, "PHASE_B_ROOT_RESOLUTION_FAIL")
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual((state.get("last_shadow_pipeline_phase_run_ids") or {}).get("B"), "current-b")
            self.assertNotIn("C", state.get("last_shadow_pipeline_phase_run_ids") or {})
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_phase_f_lock_contention_classified_nonfatal_attach(self):
        """Healthy lock-owner contention in Phase F should not collapse pipeline to fatal."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        try:
            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (
                        False, None, None, None, "PHASE_F_LOCK_FAIL", False,
                        {"lock_owner_running": True, "lock_heartbeat_stale": False, "lock_diag_path": "/tmp/diag.json"},
                    )
                    with patch("phase_e_auto_report.submit_phase_e_failure_report") as mock_fallback:
                        ok, rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
                        self.assertTrue(ok)
                        self.assertIsNone(failed_phase)
                        self.assertEqual(error_code, "PHASE_F_LOCK_CONTENDED_ATTACH")
                        mock_fallback.assert_not_called()
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertTrue(state.get("last_shadow_pipeline_ok"))
            self.assertEqual(state.get("last_shadow_pipeline_error_code"), "PHASE_F_LOCK_CONTENDED_ATTACH")
            self.assertEqual(state.get("last_shadow_pipeline_failed_phase"), "")
            self.assertEqual(state.get("last_error_recoverability"), "attached")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_phase_e_error_code_preserved_in_pipeline_state(self):
        """Phase E specific error code should survive orchestrator failure mapping."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        try:
            state_path = os.path.join(lab_root, "diagnostics_state.json")
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_phase_e_error_code": "PHASE_E_DB_WRITE_ERROR",
                    "last_shadow_pipeline_run_id": "old-run",
                }, f, indent=2)

            run_side_effects = [(True, 0), (True, 0), (True, 0), (True, 0), (False, 1)]
            with patch("run_shadow_pipeline._run_phase", side_effect=run_side_effects):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, True, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
                        self.assertFalse(ok)
                        self.assertEqual(failed_phase, "E")
                        self.assertEqual(error_code, "PHASE_E_DB_WRITE_ERROR")
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual(state.get("last_shadow_pipeline_failed_phase"), "E")
            self.assertEqual(state.get("last_shadow_pipeline_error_code"), "PHASE_E_DB_WRITE_ERROR")
            self.assertEqual(state.get("last_error_source_exception_class"), "ProcessExit")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_phase_c_stale_failed_handoff_stops_before_phase_d(self):
        """Phase C may not exit 0 while leaving stale failed Phase C state."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        calls = []
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_manifest_sha256": "new-manifest",
                    "last_phase_c_ok": False,
                    "last_phase_c_error_code": "PHASE_C_DB_WRITE_ERROR",
                    "last_ingest_manifest_sha256": "old-manifest",
                    "last_phase_c_run_id": "old-c",
                }, f, indent=2)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_b_run_id": "new-b", "last_phase_c_run_id": "old-c"}, f)

            def fake_run_phase(script_name, lab_root_arg, python_exe, repo_root, env):
                calls.append(script_name)
                return True, 0

            with patch("run_shadow_pipeline._run_phase", side_effect=fake_run_phase):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_DB_WRITE_ERROR")
            self.assertEqual(calls, ["bootstrap_lab.py", "discover_artifacts.py", "ingest_from_manifest.py"])
            with open(state_path, "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertFalse(state.get("last_shadow_pipeline_ok"))
            self.assertEqual(state.get("last_shadow_pipeline_failed_phase"), "C")
            self.assertEqual(state.get("last_shadow_pipeline_error_code"), "PHASE_C_DB_WRITE_ERROR")
            self.assertEqual(state.get("last_error_source_exception_class"), "PhaseHandoff")
            self.assertEqual((state.get("last_shadow_pipeline_phase_run_ids") or {}).get("B"), "new-b")
            self.assertNotIn("C", state.get("last_shadow_pipeline_phase_run_ids") or {})
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_phase_c_manifest_sha_mismatch_stops_pipeline(self):
        """Even ok Phase C state must match the latest Phase B manifest."""
        from run_shadow_pipeline import run_shadow_pipeline
        lab_root, _ = _make_lab()
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "last_manifest_sha256": "new-manifest",
                    "last_phase_c_ok": True,
                    "last_phase_c_error_code": None,
                    "last_ingest_manifest_sha256": "old-manifest",
                    "last_phase_c_run_id": "old-c",
                }, f, indent=2)
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"last_phase_b_run_id": "new-b", "last_phase_c_run_id": "old-c"}, f)

            with patch("run_shadow_pipeline._run_phase", return_value=(True, 0)):
                with patch("package_shadow_run_report.run_package") as mock_run_pkg:
                    mock_run_pkg.return_value = (True, "/r/j.json", "/r/j.txt", "/r/ix.json", None, False, {})
                    with patch("phase_e_auto_report.submit_phase_e_failure_report"):
                        ok, _rid, failed_phase, error_code = run_shadow_pipeline(lab_root)
            self.assertFalse(ok)
            self.assertEqual(failed_phase, "C")
            self.assertEqual(error_code, "PHASE_C_HANDOFF_INCOHERENT")
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass


class TestPhaseFSupplementalBundleFiles(unittest.TestCase):
    """phase_e_auto_report supplemental attachments for Phase F evidence."""

    def test_includes_phase_c_json_when_failed_phase_c(self):
        from phase_e_auto_report import build_phase_f_bundle_supplemental_files

        lab_root = tempfile.mkdtemp()
        reports = os.path.join(lab_root, "reports")
        os.makedirs(reports)
        c_rid = "20260101-000000-testcrid"
        ingest_path = os.path.join(reports, "ingest_write_summary_{0}.json".format(c_rid))
        with open(ingest_path, "w", encoding="utf-8") as f:
            json.dump({"manifest_sha256": "sha9", "manifest_run_id": "b-run"}, f)
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump({
                "last_phase_c_run_id": c_rid,
                "last_shadow_pipeline_phase_run_ids": {"B": "bmanifest", "C": c_rid},
            }, f)
        try:
            extras = build_phase_f_bundle_supplemental_files(lab_root, {
                "run_id": "shadow-z",
                "failed_phase": "C",
            })
            basenames = [pair[0] for pair in extras]
            self.assertIn(os.path.basename(ingest_path), basenames)
            notes = [pair[1] for pair in extras if pair[0] == "phase_f_bc_correlation_note.txt"]
            self.assertEqual(len(notes), 1)
            self.assertIn("shadow-z", notes[0])
            self.assertIn("phase_c_failure_summary_attached=yes", notes[0])
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass


if __name__ == "__main__":
    unittest.main()
