"""
AgentPulse SDK - Python Client Library
Self-healing webhook monitoring for AI agents
"""

from .interceptor import monitor_agent_webhook

__version__ = "0.1.0"
__all__ = ["monitor_agent_webhook"]
