import functools
import httpx
from typing import Callable, Any

def monitor_agent_webhook(provider: str, agentpulse_key: str, gateway_url: str = "http://127.0.0.1:8000"):
    """
    Python decorator that intercepts incoming webhooks, routes them through 
    the AgentPulse cloud engine for self-healing verification, and passes 
    the validated payload down to the downstream application logic.
    """
    def decorator(func: Callable[..., Any]):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # 1. Safely locate incoming raw payload dictionary from keyword or positional arguments
            raw_payload = kwargs.get("payload") or (args[0] if args and isinstance(args[0], dict) else {})
            target_endpoint = kwargs.get("internal_route_url") or "https://httpbin.org/post"

            if not raw_payload:
                return await func(*args, **kwargs)

            # 2. Intercept and re-route through the active AgentPulse Gateway
            async with httpx.AsyncClient() as client:
                headers = {
                    "x-agentpulse-key": agentpulse_key,
                    "x-target-webhook-url": target_endpoint
                }
                proxy_target = f"{gateway_url.rstrip('/')}/v1/gateway/{provider}"
                
                try:
                    proxy_res = await client.post(proxy_target, json=raw_payload, headers=headers, timeout=5.0)
                    
                    # Fix 1 Applied (Option A): If the gateway processes the payload successfully, 
                    # we keep the raw_payload intact. We do NOT overwrite it with gateway metadata.
                    if proxy_res.status_code == 200:
                        pass 
                        
                except Exception as e:
                    print(f"[AgentPulse SDK Warning] Gateway communication fallback triggered: {e}")
                    pass

            return await func(*args, **kwargs)
        return wrapper
    return decorator
