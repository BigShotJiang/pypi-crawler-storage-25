import functools
import httpx
import asyncio

def monitor_agent_webhook(provider: str, agentpulse_key: str, gateway_url: str = "http://127.0.0.1:8000"):
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            payload = kwargs.get("payload", {})
            internal_route_url = kwargs.get("internal_route_url", "https://httpbin.org")
            
            async with httpx.AsyncClient() as client:
                try:
                    headers = {
                        "x-agentpulse-key": agentpulse_key,
                        "x-target-webhook-url": internal_route_url,
                        "Content-Type": "application/json"
                    }
                    response = await client.post(
                        f"{gateway_url}/v1/gateway/{provider}", 
                        json=payload, 
                        headers=headers,
                        timeout=10.0
                    )
                    
                    if response.status_code == 200:
                        gateway_data = response.json()
                        if isinstance(gateway_data, dict):
                            healed_data = gateway_data.get("data") if "data" in gateway_data else gateway_data
                            if isinstance(healed_data, dict) and "customer_id" in healed_data:
                                print("⚡ AgentPulse SDK: Intercepted healed payload structural mutations from Groq gateway!")
                                kwargs["payload"] = healed_data
                except Exception as e:
                    print(f"⚠️ AgentPulse SDK Pipeline Pass-through Warning: {e}")
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator
