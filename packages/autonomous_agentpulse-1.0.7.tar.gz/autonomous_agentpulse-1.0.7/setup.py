import os
from setuptools import setup, find_packages

readme_path = os.path.join(os.path.dirname(__file__), "README.md")
long_description = ""
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name="autonomous_agentpulse",  
    version="1.0.7",               # Version bump to update PyPI text fields
    author="AgentPulse Team",
    description="Self-healing telemetry proxy SDK for AI Agents",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=["autonomous_agentpulse"],
    install_requires=[
        "httpx>=0.27.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
