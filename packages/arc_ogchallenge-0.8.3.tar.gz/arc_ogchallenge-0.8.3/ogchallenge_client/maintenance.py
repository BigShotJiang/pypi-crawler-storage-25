from __future__ import annotations

from typing import Optional

from pydantic import BaseModel

from .base import BenchmarkClient
from .dtos import (
    Req_System, Resp_System,
    # Equipment
    Req_EquipmentList, Resp_EquipmentList,
    Req_GetEquipment, Resp_GetEquipment,
    Req_UpdateEquipment, Resp_UpdateEquipment,
    Req_EquipmentSearch, Resp_EquipmentSearch,
    # Employees
    Req_EmployeeList, Resp_EmployeeList,
    Req_GetEmployee, Resp_GetEmployee,
    Req_UpdateEmployee, Resp_UpdateEmployee,
    Req_EmployeeSearch, Resp_EmployeeSearch,
    # Materials
    Req_MaterialList, Resp_MaterialList,
    Req_MaterialGet, Resp_MaterialGet,
    Req_MaterialSearch, Resp_MaterialSearch,
    Req_MaterialReorder, Resp_MaterialReorder,
    # Notifications
    Req_NotifCreate, Resp_NotifCreate,
    Req_NotifGet, Resp_NotifGet,
    Req_NotifSearch, Resp_NotifSearch,
    Req_NotifUpdate, Resp_NotifUpdate,
    RiskAssessment, NotifStatus, WoStatus,
    # Work Orders
    Req_WOList, Resp_WOList,
    Req_WOSearch, Resp_WOSearch,
    Req_WOCreate, Resp_WOCreate,
    Req_WOGet, Resp_WOGet,
    Req_WOUpdate, Resp_WOUpdate,
    # Operations
    Req_OperationAdd, Resp_OperationAdd,
    Req_OperationUpdate, Resp_OperationUpdate,
    Req_OperationList, Resp_OperationList,
    WOOperation,
    # Wiki
    Req_WikiTree, Resp_WikiTree,
    Req_WikiLoad, Resp_WikiLoad,
    Req_WikiSearch, Resp_WikiSearch,
    Req_WikiUpdate, Resp_WikiUpdate,
    # Respond
    Req_Respond, Resp_Respond,
    Outcome, RunningStatus,
)


class MaintenanceClient(BenchmarkClient):
    """Task-scoped client for the maintenance-ops benchmark API.

    base_url must already include the task_id, e.g.:
        http://localhost:8000/maintenance/<task_id>

    Obtain via CoreClient.get_maintenance_client(task).
    """

    retryable_paths = frozenset(
        {
            "/system",
            "/floc/list",
            "/floc/get",
            "/floc/search",
            "/employees/list",
            "/employees/get",
            "/employees/search",
            "/materials/list",
            "/materials/get",
            "/materials/search",
            "/notifications/get",
            "/notifications/search",
            "/workorders/list",
            "/workorders/get",
            "/workorders/search",
            "/operations/list",
            "/wiki/tree",
            "/wiki/load",
            "/wiki/search",
            "/respond",
        }
    )

    def __init__(
        self,
        base_url: str,
        auth_token: Optional[str] = None,
        timeout_sec: int = 30,
        max_retries: int = 2,
        retry_backoff_sec: float = 0.5,
    ):
        super().__init__(
            base_url,
            auth_token=auth_token,
            timeout_sec=timeout_sec,
            max_retries=max_retries,
            retry_backoff_sec=retry_backoff_sec,
        )

    # ── Identity ──────────────────────────────────────────────────────────────

    def system(self) -> Resp_System:
        return self._post("/system", Req_System(), Resp_System)

    # ── FLOC (Equipment) ──────────────────────────────────────────────────────

    def floc_list(self, limit: int = 20, offset: int = 0) -> Resp_EquipmentList:
        return self._post("/floc/list", Req_EquipmentList(limit=limit, offset=offset), Resp_EquipmentList)

    def floc_get(self, floc: str) -> Resp_GetEquipment:
        return self._post("/floc/get", Req_GetEquipment(floc=floc), Resp_GetEquipment)

    def floc_update(
        self,
        floc: str,
        running_status: Optional[RunningStatus] = None,
        current_value: Optional[float] = None,
    ) -> Resp_UpdateEquipment:
        return self._post(
            "/floc/update",
            Req_UpdateEquipment(floc=floc, running_status=running_status, current_value=current_value),
            Resp_UpdateEquipment,
        )

    def floc_search(
        self,
        description: Optional[str] = None,
        floc: Optional[str] = None,
        superior_floc: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Resp_EquipmentSearch:
        return self._post(
            "/floc/search",
            Req_EquipmentSearch(description=description, floc=floc, superior_floc=superior_floc, limit=limit, offset=offset),
            Resp_EquipmentSearch,
        )

    # ── Employees ─────────────────────────────────────────────────────────────

    def employee_list(self, limit: int = 20, offset: int = 0) -> Resp_EmployeeList:
        return self._post("/employees/list", Req_EmployeeList(limit=limit, offset=offset), Resp_EmployeeList)

    def employee_get(self, emp_id: int) -> Resp_GetEmployee:
        return self._post("/employees/get", Req_GetEmployee(emp_id=emp_id), Resp_GetEmployee)

    def employee_update(
        self,
        emp_id: int,
        role: Optional[str] = None,
        department: Optional[str] = None,
    ) -> Resp_UpdateEmployee:
        return self._post("/employees/update", Req_UpdateEmployee(emp_id=emp_id, role=role, department=department), Resp_UpdateEmployee)

    def employee_search(
        self,
        name: Optional[str] = None,
        role: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Resp_EmployeeSearch:
        return self._post(
            "/employees/search",
            Req_EmployeeSearch(name=name, role=role, limit=limit, offset=offset),
            Resp_EmployeeSearch,
        )

    # ── Materials ─────────────────────────────────────────────────────────────

    def material_list(self, limit: int = 20, offset: int = 0) -> Resp_MaterialList:
        return self._post("/materials/list", Req_MaterialList(limit=limit, offset=offset), Resp_MaterialList)

    def material_get(self, mat_id: int) -> Resp_MaterialGet:
        return self._post("/materials/get", Req_MaterialGet(mat_id=mat_id), Resp_MaterialGet)

    def material_search(self, query: str, limit: int = 25, offset: int = 0) -> Resp_MaterialSearch:
        return self._post("/materials/search", Req_MaterialSearch(query=query, limit=limit, offset=offset), Resp_MaterialSearch)

    def material_reorder(self, mat_id: int, quantity: int) -> Resp_MaterialReorder:
        return self._post("/materials/reorder", Req_MaterialReorder(mat_id=mat_id, quantity=quantity), Resp_MaterialReorder)

    # ── Notifications ─────────────────────────────────────────────────────────

    def notif_create(
        self,
        floc: str,
        short_desc: str,
        long_desc: str,
        risk_assessment: Optional[RiskAssessment] = None,
    ) -> Resp_NotifCreate:
        return self._post(
            "/notifications/create",
            Req_NotifCreate(floc=floc, short_desc=short_desc, long_desc=long_desc, risk_assessment=risk_assessment),
            Resp_NotifCreate,
        )

    def notif_get(self, notif_id: int) -> Resp_NotifGet:
        return self._post("/notifications/get", Req_NotifGet(notif_id=notif_id), Resp_NotifGet)

    def notif_search(
        self,
        id: Optional[str] = None,
        short_desc: Optional[str] = None,
        long_desc: Optional[str] = None,
        risk_assessment: Optional[str] = None,
        status: Optional[NotifStatus] = None,
        floc: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Resp_NotifSearch:
        return self._post(
            "/notifications/search",
            Req_NotifSearch(
                id=id, short_desc=short_desc, long_desc=long_desc,
                risk_assessment=risk_assessment, status=status, floc=floc,
                limit=limit, offset=offset,
            ),
            Resp_NotifSearch,
        )

    def notif_update(
        self,
        notif_id: int,
        status: Optional[NotifStatus] = None,
        short_desc: Optional[str] = None,
        long_desc: Optional[str] = None,
        risk_assessment: Optional[RiskAssessment] = None,
    ) -> Resp_NotifUpdate:
        return self._post(
            "/notifications/update",
            Req_NotifUpdate(
                notif_id=notif_id,
                status=status,
                short_desc=short_desc,
                long_desc=long_desc,
                risk_assessment=risk_assessment,
            ),
            Resp_NotifUpdate,
        )

    # ── Work Orders ───────────────────────────────────────────────────────────

    def wo_list(self, limit: int = 20, offset: int = 0) -> Resp_WOList:
        return self._post("/workorders/list", Req_WOList(limit=limit, offset=offset), Resp_WOList)

    def wo_search(
        self,
        short_desc: Optional[str] = None,
        status: Optional[str] = None,
        work_center: Optional[str] = None,
        execution_date: Optional[str] = None,
        notification_id: Optional[int] = None,
        floc: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> Resp_WOSearch:
        return self._post("/workorders/search", Req_WOSearch(
            short_desc=short_desc, status=status, work_center=work_center,
            execution_date=execution_date, notification_id=notification_id, floc=floc,
            limit=limit, offset=offset,
        ), Resp_WOSearch)

    def wo_create(
        self,
        short_desc: str,
        notification_id: int,
        work_center: Optional[WorkCenter] = None,
        execution_date: Optional[str] = None,
    ) -> Resp_WOCreate:
        return self._post("/workorders/create", Req_WOCreate(
            short_desc=short_desc, notification_id=notification_id,
            work_center=work_center, execution_date=execution_date,
        ), Resp_WOCreate)

    def wo_get(self, wo_id: int) -> Resp_WOGet:
        return self._post("/workorders/get", Req_WOGet(wo_id=wo_id), Resp_WOGet)

    def wo_update(
        self,
        wo_id: int,
        short_desc: Optional[str] = None,
        long_desc: Optional[str] = None,
        status: Optional[WoStatus] = None,
        execution_date: Optional[str] = None,
        floc: Optional[str] = None,
    ) -> Resp_WOUpdate:
        return self._post("/workorders/update", Req_WOUpdate(
            wo_id=wo_id, short_desc=short_desc, long_desc=long_desc,
            status=status, execution_date=execution_date, floc=floc,
        ), Resp_WOUpdate)

    # ── Operations ────────────────────────────────────────────────────────────

    def operation_add(
        self,
        workorder_id: int,
        short_desc: str,
        work_center: Optional[WorkCenter] = None,
        work_instruction: Optional[str] = None,
        man_hours: float = 0.0,
        materials: Optional[list[MaterialUsage]] = None,
    ) -> Resp_OperationAdd:
        return self._post(
            "/operations/add",
            Req_OperationAdd(workorder_id=workorder_id, short_desc=short_desc,
                             work_center=work_center, work_instruction=work_instruction,
                             man_hours=man_hours, materials=materials),
            Resp_OperationAdd,
        )

    def operation_update(
        self,
        workorder_id: int,
        op_id: int,
        work_instruction: Optional[str] = None,
        man_hours: Optional[float] = None,
        materials: Optional[list[MaterialUsage]] = None,
    ) -> Resp_OperationUpdate:
        return self._post(
            "/operations/update",
            Req_OperationUpdate(workorder_id=workorder_id, op_id=op_id, work_instruction=work_instruction,
                                man_hours=man_hours, materials=materials),
            Resp_OperationUpdate,
        )

    def operation_list(self, workorder_id: int) -> Resp_OperationList:
        return self._post("/operations/list", Req_OperationList(workorder_id=workorder_id), Resp_OperationList)

    # ── Wiki ──────────────────────────────────────────────────────────────────

    def wiki_tree(self, path: str = "") -> Resp_WikiTree:
        return self._post("/wiki/tree", Req_WikiTree(path=path), Resp_WikiTree)

    def wiki_load(self, path: str) -> Resp_WikiLoad:
        return self._post("/wiki/load", Req_WikiLoad(path=path), Resp_WikiLoad)

    def wiki_search(self, root: str, pattern: str, limit: int = 100) -> Resp_WikiSearch:
        return self._post("/wiki/search", Req_WikiSearch(root=root, pattern=pattern, limit=limit), Resp_WikiSearch)

    def wiki_update(
        self,
        path: str,
        start_row: int,
        end_row: int,
        content: str,
        updated_by: Optional[str] = None,
    ) -> Resp_WikiUpdate:
        return self._post(
            "/wiki/update",
            Req_WikiUpdate(
                path=path,
                start_row=start_row,
                end_row=end_row,
                content=content,
                updated_by=updated_by,
            ),
            Resp_WikiUpdate,
        )

    # ── Respond ───────────────────────────────────────────────────────────────

    def respond(self, message: str, outcome: Outcome, ground_refs: list | None = None) -> Resp_Respond:
        return self._post(
            "/respond",
            Req_Respond(message=message, outcome=outcome, ground_refs=ground_refs or []),
            Resp_Respond,
        )

    # ── Dispatch (for LLM structured-output agents) ───────────────────────────

    def dispatch(self, req: BaseModel) -> BaseModel:
        if isinstance(req, Req_System):           return self.system()
        if isinstance(req, Req_EquipmentList):    return self.floc_list(req.limit, req.offset)
        if isinstance(req, Req_GetEquipment):     return self.floc_get(req.floc)
        if isinstance(req, Req_UpdateEquipment):  return self.floc_update(req.floc, req.running_status, req.current_value)
        if isinstance(req, Req_EquipmentSearch):  return self.floc_search(req.description, req.floc, req.superior_floc, req.limit, req.offset)
        if isinstance(req, Req_EmployeeList):     return self.employee_list(req.limit, req.offset)
        if isinstance(req, Req_GetEmployee):      return self.employee_get(req.emp_id)
        if isinstance(req, Req_UpdateEmployee):   return self.employee_update(req.emp_id, req.role, req.department)
        if isinstance(req, Req_EmployeeSearch):   return self.employee_search(req.name, req.role, req.limit, req.offset)
        if isinstance(req, Req_MaterialList):     return self.material_list(req.limit, req.offset)
        if isinstance(req, Req_MaterialGet):      return self.material_get(req.mat_id)
        if isinstance(req, Req_MaterialSearch):   return self.material_search(req.query, req.limit, req.offset)
        if isinstance(req, Req_MaterialReorder):  return self.material_reorder(req.mat_id, req.quantity)
        if isinstance(req, Req_NotifCreate):      return self.notif_create(req.floc, req.short_desc, req.long_desc, req.risk_assessment)
        if isinstance(req, Req_NotifSearch):      return self.notif_search(req.id, req.short_desc, req.long_desc, req.risk_assessment, req.status, req.floc, req.limit, req.offset)
        if isinstance(req, Req_NotifGet):         return self.notif_get(req.notif_id)
        if isinstance(req, Req_NotifUpdate):      return self.notif_update(req.notif_id, req.status, req.short_desc, req.long_desc, req.risk_assessment)
        if isinstance(req, Req_WOList):           return self.wo_list(req.limit, req.offset)
        if isinstance(req, Req_WOSearch):         return self.wo_search(req.short_desc, req.status, req.work_center, req.execution_date, req.notification_id, req.floc, req.limit, req.offset)
        if isinstance(req, Req_WOCreate):         return self.wo_create(req.short_desc, req.notification_id, req.work_center, req.execution_date)
        if isinstance(req, Req_WOGet):            return self.wo_get(req.wo_id)
        if isinstance(req, Req_WOUpdate):         return self.wo_update(req.wo_id, req.short_desc, req.long_desc, req.status, req.execution_date, req.floc)
        if isinstance(req, Req_OperationAdd):     return self.operation_add(req.workorder_id, req.short_desc, req.work_center, req.work_instruction, req.man_hours, req.materials)
        if isinstance(req, Req_OperationUpdate):  return self.operation_update(req.workorder_id, req.op_id, req.work_instruction, req.man_hours, req.materials)
        if isinstance(req, Req_OperationList):    return self.operation_list(req.workorder_id)
        if isinstance(req, Req_WikiTree):         return self.wiki_tree(req.path)
        if isinstance(req, Req_WikiLoad):         return self.wiki_load(req.path)
        if isinstance(req, Req_WikiSearch):       return self.wiki_search(req.root, req.pattern, req.limit)
        if isinstance(req, Req_WikiUpdate):       return self.wiki_update(req.path, req.start_row, req.end_row, req.content, req.updated_by)
        if isinstance(req, Req_Respond):          return self.respond(req.message, req.outcome, req.ground_refs)
        raise ValueError(f"Unsupported request type: {type(req).__name__}")
