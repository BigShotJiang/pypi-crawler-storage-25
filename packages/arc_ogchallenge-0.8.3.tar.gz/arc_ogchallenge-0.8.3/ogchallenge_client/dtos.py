from __future__ import annotations

from typing import Dict, List, Optional, Literal
from pydantic import BaseModel, Field

SessionStatus = Literal["open", "done", "evaluated"]
TaskStatus = Literal["new", "in_progress", "completed", "failed"]
SessionFlag = Literal["local", "compete_accuracy", "compete_speed", "compete_budget"]

Outcome = Literal[
    "ok_answer",
    "ok_not_found",
    "denied_security",
    "none_clarification_needed",
    "none_unsupported",
    "error_internal",
]

GroundRefType = Literal[
    "work_order",
    "notification",
    "equipment",
    "material",
    "employee",
    "operation",
    "wiki",
    "document",
]


class ApiError(BaseModel):
    status: int
    error: str
    code: str = ""


class Req_ListBenchmarks(BaseModel):
    pass


class BenchmarkInfo(BaseModel):
    id: str
    short_description: str
    status: str
    tasks: int


class Resp_ListBenchmarks(BaseModel):
    benchmarks: List[BenchmarkInfo] = Field(default_factory=list)


class Req_PublicBenchmarkView(BaseModel):
    benchmark: str


class PublicBenchmarkSpec(BaseModel):
    id: str
    task: str
    gotcha: Optional[str] = None


class PublicBenchmarkRoute(BaseModel):
    path: str
    description: str
    sample_request: Optional[dict] = None
    sample_response: Optional[dict] = None


class Resp_PublicBenchmarkView(BaseModel):
    id: str
    description: str
    api_root: str = Field(alias="apiRoot")
    status: str
    specs: List[PublicBenchmarkSpec] = Field(default_factory=list)
    routes: List[PublicBenchmarkRoute] = Field(default_factory=list)
    sample_agent_url: Optional[str] = None


class Req_StartSession(BaseModel):
    account_key: str = ""
    benchmark: str
    workspace: str = ""
    name: Optional[str] = None
    architecture: Optional[str] = None
    flags: List[SessionFlag] = Field(default_factory=list)


class Resp_StartSession(BaseModel):
    session_id: str
    task_count: int


class Session(BaseModel):
    id: str
    name: Optional[str] = None
    benchmark_type: str
    status: str
    created_at: str
    workspace: str
    benchmark_description: str
    total_tasks: int
    completed_tasks: int
    running_tasks: int
    new_tasks: int
    failed_tasks: int
    score: Optional[float] = None


class Req_StartTask(BaseModel):
    task_id: Optional[str] = None
    benchmark: Optional[str] = None
    spec_id: Optional[str] = None


class Resp_StartTask(BaseModel):
    task_id: str
    session_id: Optional[str] = None
    status: TaskStatus
    text: str
    benchmark: str


class Req_CompleteTask(BaseModel):
    task_id: str


class EvalResult(BaseModel):
    score: float
    logs: str


class Resp_CompleteTask(BaseModel):
    status: TaskStatus
    eval: Optional[EvalResult] = None


class Req_SessionStatus(BaseModel):
    session_id: str


class TaskInfo(BaseModel):
    spec_id: str
    task_id: str
    num: int
    task_text: str
    status: TaskStatus
    benchmark: str
    score: float
    error_message: Optional[str] = None
    role: str = "OpsManager"


class Resp_SessionStatus(BaseModel):
    status: SessionStatus
    benchmark: str
    failed: int
    new: int
    running: int
    completed: int
    tasks: List[TaskInfo] = Field(default_factory=list)
    name: Optional[str] = None
    architecture: Optional[str] = None
    flags: List[SessionFlag] = Field(default_factory=list)
    score: float


class Req_LogGenRequest(BaseModel):
    task_id: str
    completion: str
    prompt: Optional[str] = None
    model: Optional[str] = None
    usage: Dict[str, int] = Field(default_factory=dict)
    duration_sec: Optional[float] = None
    prompt_tokens: Optional[int] = None
    cached_prompt_tokens: Optional[int] = None
    completion_tokens: Optional[int] = None


class Resp_LogGenRequest(BaseModel):
    pass


class Req_System(BaseModel):
    type: Literal["system"] = "system"


class Resp_System(BaseModel):
    current_user: str
    role: str
    today: str
    is_public: bool = False


# ── Shared domain models ───────────────────────────────────────────────────────

RunningStatus  = Literal["on", "off", "maintenance"]
NotifStatus    = Literal["awaiting", "approved", "cancelled"]
WoStatus       = Literal["created", "approved", "exec", "completed", "cancelled"]
WorkCenter     = Literal["MECH", "INST", "ELEC"]


class EquipmentItem(BaseModel):
    floc: str
    description: str
    superior_floc: Optional[str] = None
    running_status: RunningStatus
    current_value: Optional[float] = None
    materials: List[int] = Field(default_factory=list)


class EmployeeItem(BaseModel):
    id: int
    name: str
    role: str
    department: str


class MaterialItem(BaseModel):
    id: int
    short_desc: str
    long_desc: str = ""
    in_stock: int = 0
    min_stock: int = 0
    max_stock: int = 0


class RiskAssessment(BaseModel):
    """Shell RAM: final_ranking = [Likelihood A-E][Severity 0-5], e.g. 'D4', 'B5'."""
    final_ranking: str
    consequences: str
    probability: str


class NotificationItem(BaseModel):
    id: int
    floc: str
    short_desc: str
    long_desc: str = ""
    risk_assessment: Optional[RiskAssessment] = None
    status: NotifStatus = "awaiting"
    created_at: str
    created_by: str = ""


class MaterialUsage(BaseModel):
    mat_id: int
    quantity: int = 1


class WOOperation(BaseModel):
    id: int
    short_desc: str
    work_center: Optional[WorkCenter] = None
    work_instruction: Optional[str] = None
    man_hours: float = 0.0
    materials: List[MaterialUsage] = Field(default_factory=list)


class WorkOrderItem(BaseModel):
    id: int
    short_desc: str
    long_desc: str = ""
    notification_id: int
    floc: Optional[str] = None
    work_center: Optional[WorkCenter] = None
    execution_date: Optional[str] = None
    operations: List[WOOperation] = Field(default_factory=list)
    status: WoStatus = "created"


# ── Equipment requests ─────────────────────────────────────────────────────────

class Req_EquipmentList(BaseModel):
    type: Literal["equipment_list"] = "equipment_list"
    limit: int = 20
    offset: int = 0


class Resp_EquipmentList(BaseModel):
    equipments: List[EquipmentItem] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


class Req_GetEquipment(BaseModel):
    type: Literal["equipment_get"] = "equipment_get"
    floc: str


class Resp_GetEquipment(BaseModel):
    equipment: Optional[EquipmentItem] = None
    found: bool = False


class Req_UpdateEquipment(BaseModel):
    type: Literal["equipment_update"] = "equipment_update"
    floc: str
    running_status: Optional[RunningStatus] = None
    current_value: Optional[float] = None


class Resp_UpdateEquipment(BaseModel):
    equipment: Optional[EquipmentItem] = None
    found: bool = False


class Req_EquipmentSearch(BaseModel):
    type: Literal["equipment_search"] = "equipment_search"
    description: Optional[str] = None
    floc: Optional[str] = None
    superior_floc: Optional[str] = None
    limit: int = 20
    offset: int = 0


class Resp_EquipmentSearch(BaseModel):
    equipments: List[EquipmentItem] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


# ── Employee requests ──────────────────────────────────────────────────────────

class Req_EmployeeList(BaseModel):
    type: Literal["employee_list"] = "employee_list"
    limit: int = 20
    offset: int = 0


class Resp_EmployeeList(BaseModel):
    employees: List[EmployeeItem] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


class Req_GetEmployee(BaseModel):
    type: Literal["employee_get"] = "employee_get"
    emp_id: int


class Resp_GetEmployee(BaseModel):
    employee: Optional[EmployeeItem] = None
    found: bool = False


class Req_UpdateEmployee(BaseModel):
    type: Literal["employee_update"] = "employee_update"
    emp_id: int
    role: Optional[str] = None
    department: Optional[str] = None


class Resp_UpdateEmployee(BaseModel):
    employee: Optional[EmployeeItem] = None
    found: bool = False


class Req_EmployeeSearch(BaseModel):
    type: Literal["employee_search"] = "employee_search"
    name: Optional[str] = None
    role: Optional[str] = None
    limit: int = 20
    offset: int = 0


class Resp_EmployeeSearch(BaseModel):
    employees: List[EmployeeItem] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


# ── Material requests ──────────────────────────────────────────────────────────

class Req_MaterialList(BaseModel):
    type: Literal["material_list"] = "material_list"
    limit: int = 20
    offset: int = 0


class Resp_MaterialList(BaseModel):
    materials: List[MaterialItem] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


class Req_MaterialGet(BaseModel):
    type: Literal["material_get"] = "material_get"
    mat_id: int

class Resp_MaterialGet(BaseModel):
    material: MaterialItem

class Req_MaterialSearch(BaseModel):
    type: Literal["material_search"] = "material_search"
    query: str
    limit: int = 25
    offset: int = 0


class Resp_MaterialSearch(BaseModel):
    materials: List[MaterialItem] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


class Req_MaterialReorder(BaseModel):
    type: Literal["material_reorder"] = "material_reorder"
    mat_id: int
    quantity: int


class Resp_MaterialReorder(BaseModel):
    mat_id: int
    short_desc: str
    in_stock: int
    reordered: int
    below_min: bool = False


# ── Notification requests ──────────────────────────────────────────────────────

class Req_NotifCreate(BaseModel):
    type: Literal["notif_create"] = "notif_create"
    floc: str
    short_desc: str = Field(..., max_length=80)
    long_desc: str
    risk_assessment: Optional[RiskAssessment] = None


class Resp_NotifCreate(BaseModel):
    notification: NotificationItem



class Req_NotifSearch(BaseModel):
    type: Literal["notif_search"] = "notif_search"
    id: Optional[str] = None
    short_desc: Optional[str] = None
    long_desc: Optional[str] = None
    risk_assessment: Optional[str] = None
    status: Optional[NotifStatus] = None
    floc: Optional[str] = None
    limit: int = 20
    offset: int = 0


class Resp_NotifSearch(BaseModel):
    notifications: List[NotificationItem] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


class Req_NotifUpdate(BaseModel):
    type: Literal["notif_update"] = "notif_update"
    notif_id: int
    status: Optional[NotifStatus] = None
    short_desc: Optional[str] = Field(None, max_length=80)
    long_desc: Optional[str] = None
    risk_assessment: Optional[RiskAssessment] = None


class Resp_NotifUpdate(BaseModel):
    notification: Optional[NotificationItem] = None
    found: bool = False


class Req_NotifGet(BaseModel):
    type: Literal["notif_get"] = "notif_get"
    notif_id: int


class Resp_NotifGet(BaseModel):
    notification: Optional[NotificationItem] = None
    found: bool = False


# ── Work Order requests ────────────────────────────────────────────────────────

class Req_WOList(BaseModel):
    type: Literal["wo_list"] = "wo_list"
    limit: int = 20
    offset: int = 0


class Resp_WOList(BaseModel):
    work_orders: List["WorkOrderItem"] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


class Req_WOSearch(BaseModel):
    type: Literal["wo_search"] = "wo_search"
    short_desc: Optional[str] = None
    status: Optional[str] = None
    work_center: Optional[str] = None
    execution_date: Optional[str] = None
    notification_id: Optional[int] = None
    floc: Optional[str] = None
    limit: int = 20
    offset: int = 0


class Resp_WOSearch(BaseModel):
    work_orders: List["WorkOrderItem"] = Field(default_factory=list)
    total: int = 0
    next_offset: int = -1


class Req_WOCreate(BaseModel):
    type: Literal["wo_create"] = "wo_create"
    short_desc: str = Field(..., max_length=80)
    notification_id: int
    work_center: Optional[WorkCenter] = None
    execution_date: Optional[str] = None


class Resp_WOCreate(BaseModel):
    work_order: WorkOrderItem


class Req_WOGet(BaseModel):
    type: Literal["wo_get"] = "wo_get"
    wo_id: int


class Resp_WOGet(BaseModel):
    work_order: Optional[WorkOrderItem] = None
    found: bool = False


class Req_WOUpdate(BaseModel):
    type: Literal["wo_update"] = "wo_update"
    wo_id: int
    short_desc: Optional[str] = Field(None, max_length=80)
    long_desc: Optional[str] = None
    status: Optional[WoStatus] = None
    execution_date: Optional[str] = None
    floc: Optional[str] = None


class Resp_WOUpdate(BaseModel):
    work_order: Optional[WorkOrderItem] = None
    found: bool = False


# ── Operation requests ─────────────────────────────────────────────────────────

class Req_OperationAdd(BaseModel):
    type: Literal["operation_add"] = "operation_add"
    workorder_id: int
    short_desc: str
    work_center: Optional[WorkCenter] = None
    work_instruction: Optional[str] = None
    man_hours: float = 0.0
    materials: Optional[List[MaterialUsage]] = None


class Resp_OperationAdd(BaseModel):
    work_order: Optional[WorkOrderItem] = None
    found: bool = False


class Req_OperationUpdate(BaseModel):
    type: Literal["operation_update"] = "operation_update"
    workorder_id: int
    op_id: int
    work_instruction: Optional[str] = None
    man_hours: Optional[float] = None
    materials: Optional[List[MaterialUsage]] = None


class Resp_OperationUpdate(BaseModel):
    work_order: Optional[WorkOrderItem] = None
    found: bool = False


class Req_OperationList(BaseModel):
    type: Literal["operation_list"] = "operation_list"
    workorder_id: int


class Resp_OperationList(BaseModel):
    operations: List[WOOperation] = Field(default_factory=list)


class WikiDoc(BaseModel):
    path: str
    content: str


class Req_WikiTree(BaseModel):
    type: Literal["wiki_tree"] = "wiki_tree"
    path: str = ""


class Resp_WikiTree(BaseModel):
    tree: str = ""


class Req_WikiLoad(BaseModel):
    type: Literal["wiki_load"] = "wiki_load"
    path: str


class Resp_WikiLoad(BaseModel):
    path: str
    content: str


class Req_WikiSearch(BaseModel):
    type: Literal["wiki_search"] = "wiki_search"
    root: str = ""
    pattern: str
    limit: int = 100


class WikiSearchHit(BaseModel):
    path: str
    line: int
    text: str


class Resp_WikiSearch(BaseModel):
    matches: List[WikiSearchHit] = Field(default_factory=list)
    total: int = 0


class Req_WikiUpdate(BaseModel):
    type: Literal["wiki_update"] = "wiki_update"
    path: str
    start_row: int
    end_row: int
    content: str
    updated_by: Optional[str] = None


class Resp_WikiUpdate(BaseModel):
    pass


class GroundRef(BaseModel):
    """Reference to an entity created or acted upon during the task."""
    type: GroundRefType = Field(
        ...,
        description=(
            "Entity category for the reference. Allowed values: work_order, notification, "
            "equipment, material, employee, operation, wiki, document."
        ),
    )
    id: str     # entity ID or FLOC
    label: Optional[str] = None


class Req_Respond(BaseModel):
    type: Literal["respond"] = "respond"
    message: str
    outcome: Outcome
    ground_refs: List[GroundRef] = Field(default_factory=list)


class Resp_Respond(BaseModel):
    pass


class Req_Login(BaseModel):
    key: str


class Resp_Login(BaseModel):
    token: str
    user: str


class Req_Logout(BaseModel):
    token: str


class Resp_Logout(BaseModel):
    pass


class SessionSummary(BaseModel):
    id: str
    name: str
    benchmark: str
    workspace: str
    created_at: str
    status: SessionStatus
    score: float
    total_tasks: int
    completed_tasks: int
    running_tasks: int
    failed_tasks: int


class Req_SessionsSearch(BaseModel):
    workspace: Optional[str] = None
    benchmark: Optional[str] = None


class Resp_SessionsSearch(BaseModel):
    sessions: List[SessionSummary] = Field(default_factory=list)


class LogLine(BaseModel):
    type: str
    text: str
    time: str
    unix: int
    body: Optional[dict] = None


class Req_TaskDetail(BaseModel):
    task_id: str


class Resp_TaskDetail(BaseModel):
    task: Optional[TaskInfo] = None
    actions: Dict[str, list] = Field(default_factory=dict)
    response: Optional[dict] = None
    logs: List[LogLine] = Field(default_factory=list)


class Req_SubmitSession(BaseModel):
    session_id: str
    force: bool = False


class Resp_SubmitSession(BaseModel):
    status: SessionStatus
    score: float
