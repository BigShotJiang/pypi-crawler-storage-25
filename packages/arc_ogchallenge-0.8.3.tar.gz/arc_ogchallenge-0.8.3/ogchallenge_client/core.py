from __future__ import annotations

from typing import Optional, List

from .base import BaseClient
from .dtos import (
    Req_ListBenchmarks,
    Resp_ListBenchmarks,
    Req_PublicBenchmarkView,
    Resp_PublicBenchmarkView,
    Req_StartSession,
    Resp_StartSession,
    Req_SessionStatus,
    Resp_SessionStatus,
    Req_SessionsSearch,
    Resp_SessionsSearch,
    Req_StartTask,
    Resp_StartTask,
    Req_CompleteTask,
    Resp_CompleteTask,
    Req_LogGenRequest,
    Resp_LogGenRequest,
    Req_TaskDetail,
    Resp_TaskDetail,
    Req_Login,
    Resp_Login,
    Req_Logout,
    Resp_Logout,
    Req_SubmitSession,
    Resp_SubmitSession,
    TaskInfo,
    SessionFlag,
)


class CoreClient(BaseClient):
    """Client for core session/task/benchmark management APIs.

    Analogous to erc3's CoreClient. Use get_maintenance_client(task) to obtain
    a task-scoped MaintenanceClient for the maintenance-ops benchmark.
    """

    retryable_paths = frozenset(
        {
            "/benchmarks/list",
            "/benchmarks/view",
            "/sessions/status",
            "/sessions/search",
            "/tasks/complete",
            "/tasks/view",
        }
    )

    def __init__(
        self,
        base_url: str,
        auth_token: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout_sec: int = 30,
        max_retries: int = 2,
        retry_backoff_sec: float = 0.5,
    ):
        super().__init__(
            base_url,
            auth_token=auth_token or api_key,
            timeout_sec=timeout_sec,
            max_retries=max_retries,
            retry_backoff_sec=retry_backoff_sec,
        )

    # ── Benchmarks ───────────────────────────────────────────────────────────

    def list_benchmarks(self) -> Resp_ListBenchmarks:
        return self._post("/benchmarks/list", Req_ListBenchmarks(), Resp_ListBenchmarks)

    def view_benchmark(self, benchmark: str) -> Resp_PublicBenchmarkView:
        return self._post("/benchmarks/view", Req_PublicBenchmarkView(benchmark=benchmark), Resp_PublicBenchmarkView)

    # ── Sessions ─────────────────────────────────────────────────────────────

    def start_session(
        self,
        benchmark: str,
        workspace: str = "",
        name: Optional[str] = None,
        architecture: Optional[str] = None,
        flags: Optional[List[SessionFlag]] = None,
    ) -> Resp_StartSession:
        req = Req_StartSession(
            benchmark=benchmark,
            workspace=workspace,
            name=name,
            architecture=architecture,
            flags=flags or [],
        )
        return self._post("/sessions/start", req, Resp_StartSession)

    def session_status(self, session_id: str) -> Resp_SessionStatus:
        return self._post("/sessions/status", Req_SessionStatus(session_id=session_id), Resp_SessionStatus)

    def sessions_search(
        self,
        workspace: Optional[str] = None,
        benchmark: Optional[str] = None,
    ) -> Resp_SessionsSearch:
        return self._post("/sessions/search", Req_SessionsSearch(workspace=workspace, benchmark=benchmark), Resp_SessionsSearch)

    # ── Tasks ─────────────────────────────────────────────────────────────────

    def start_task(self, task: TaskInfo) -> TaskInfo:
        """Start a task and hydrate the passed TaskInfo with the started task state."""
        resp = self._post("/tasks/start", Req_StartTask(task_id=task.task_id), Resp_StartTask, retry=True)
        task.task_text = resp.text
        task.status = resp.status
        task.benchmark = resp.benchmark
        return task

    def start_new_task(self, benchmark: str, spec_id: str) -> TaskInfo:
        """Start a standalone task by spec and return a populated TaskInfo."""
        resp = self._post("/tasks/start", Req_StartTask(benchmark=benchmark, spec_id=spec_id), Resp_StartTask)
        return TaskInfo(
            spec_id=spec_id,
            task_id=resp.task_id,
            benchmark=resp.benchmark,
            task_text=resp.text,
            status=resp.status,
            score=-1,
            num=0,
        )

    def complete_task(self, task: TaskInfo) -> Resp_CompleteTask:
        return self._post("/tasks/complete", Req_CompleteTask(task_id=task.task_id), Resp_CompleteTask)

    def log_llm(
        self,
        task_id: str,
        completion: str,
        *,
        prompt: Optional[str] = None,
        model: Optional[str] = None,
        duration_sec: Optional[float] = None,
        prompt_tokens: Optional[int] = None,
        cached_prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
    ) -> Resp_LogGenRequest:
        req = Req_LogGenRequest(
            task_id=task_id,
            completion=completion,
            prompt=prompt,
            model=model,
            duration_sec=duration_sec,
            prompt_tokens=prompt_tokens,
            cached_prompt_tokens=cached_prompt_tokens,
            completion_tokens=completion_tokens,
        )
        return self._post("/tasks/log", req, Resp_LogGenRequest)

    def task_detail(self, task_id: str) -> Resp_TaskDetail:
        return self._post("/tasks/view", Req_TaskDetail(task_id=task_id), Resp_TaskDetail)

    # ── Auth ─────────────────────────────────────────────────────────────────

    def login(self, key: str) -> Resp_Login:
        return self._post("/auth/login", Req_Login(key=key), Resp_Login)

    def logout(self, token: str) -> Resp_Logout:
        return self._post("/auth/logout", Req_Logout(token=token), Resp_Logout)

    def submit_session(self, session_id: str, force: bool = False) -> Resp_SubmitSession:
        """Finalise a session. Transitions open → done/evaluated."""
        return self._post("/sessions/submit", Req_SubmitSession(session_id=session_id, force=force), Resp_SubmitSession)

    # ── Factory ───────────────────────────────────────────────────────────────

    def get_maintenance_client(self, task: TaskInfo) -> "MaintenanceClient":
        """Return a task-scoped MaintenanceClient (analogous to erc3's get_store_client)."""
        from .maintenance import MaintenanceClient
        base_url = f"{self.base_url.rstrip('/')}/maintenance/{task.task_id}"
        return MaintenanceClient(
            base_url=base_url,
            auth_token=self.auth_token,
            timeout_sec=self.timeout_sec,
            max_retries=self.max_retries,
            retry_backoff_sec=self.retry_backoff_sec,
        )
