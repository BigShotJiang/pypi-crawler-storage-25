from __future__ import annotations

import json
import socket
import time
from typing import Optional, Type, TypeVar
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from pydantic import BaseModel, ValidationError

from .dtos import ApiError

TResp = TypeVar("TResp", bound=BaseModel)


class ApiException(Exception):
    """Raised when the API responds with a typed error payload."""

    def __init__(self, api_error: ApiError, status_code: Optional[int] = None):
        self.api_error = api_error
        self.status_code = status_code or api_error.status
        detail = f"Error {self.status_code}: {self.api_error.error}"
        if self.api_error.code:
            detail += f" (code={self.api_error.code})"
        super().__init__(detail)


def _dump_model(model: BaseModel | None) -> dict:
    if model is None:
        return {}
    if hasattr(model, "model_dump"):
        return model.model_dump(by_alias=True, exclude_none=True)
    return model.dict(by_alias=True, exclude_none=True)


def _load_model(model: Type[BaseModel], data: dict) -> BaseModel:
    if hasattr(model, "model_validate"):
        return model.model_validate(data)
    return model.parse_obj(data)


class BaseClient:
    """Base HTTP helper with Pydantic-aware request/response handling."""

    retryable_paths: frozenset[str] = frozenset()

    def __init__(
        self,
        base_url: str,
        auth_token: Optional[str] = None,
        timeout_sec: int = 30,
        max_retries: int = 2,
        retry_backoff_sec: float = 0.5,
    ):
        self.base_url = base_url if base_url.endswith("/") else base_url + "/"
        self.auth_token = auth_token
        self.timeout_sec = timeout_sec
        self.max_retries = max(0, int(max_retries))
        self.retry_backoff_sec = max(0.0, float(retry_backoff_sec))

    def set_auth_token(self, token: Optional[str]) -> None:
        self.auth_token = token

    def _headers(self, token: Optional[str] = None) -> dict:
        headers = {"Content-Type": "application/json"}
        use_token = token or self.auth_token
        if use_token:
            headers["Authorization"] = f"Bearer {use_token}"
        return headers

    def _post(
        self,
        path: str,
        request_model: BaseModel | None,
        response_model: Type[TResp],
        token: Optional[str] = None,
        retry: Optional[bool] = None,
    ) -> TResp:
        normalized_path = "/" + path.lstrip("/")
        url = urljoin(self.base_url, normalized_path.lstrip("/"))
        payload = _dump_model(request_model)
        body = json.dumps(payload).encode("utf-8")
        should_retry = self._is_retryable_path(normalized_path) if retry is None else retry
        total_attempts = self.max_retries + 1 if should_retry else 1

        for attempt in range(1, total_attempts + 1):
            request = Request(url, data=body, headers=self._headers(token), method="POST")

            try:
                response = urlopen(request, timeout=self.timeout_sec)
                raw = response.read().decode("utf-8")
                break
            except HTTPError as exc:
                raw = exc.read().decode("utf-8")
                try:
                    data = json.loads(raw) if raw else {}
                except ValueError:
                    data = {}
                api_error = self._parse_error(exc.code, data, raw)

                if self._should_retry_http(exc.code, attempt, total_attempts):
                    time.sleep(self._retry_delay(attempt))
                    continue

                raise ApiException(api_error, status_code=exc.code) from exc
            except URLError as exc:
                if self._should_retry_network(exc, attempt, total_attempts):
                    time.sleep(self._retry_delay(attempt))
                    continue
                raise ApiException(ApiError(status=0, error=str(exc), code="network_error")) from exc

        try:
            data = json.loads(raw) if raw else {}
        except ValueError as exc:
            raise ApiException(ApiError(status=0, error=f"Invalid JSON response: {exc}", code="invalid_json")) from exc

        try:
            return _load_model(response_model, data)  # type: ignore[arg-type]
        except ValidationError as exc:
            raise ApiException(ApiError(status=0, error=f"Invalid response payload: {exc}", code="invalid_response")) from exc

    @staticmethod
    def _parse_error(status: int, data: dict, raw: str) -> ApiError:
        if data:
            try:
                return _load_model(ApiError, data)  # type: ignore[arg-type]
            except ValidationError:
                return ApiError(status=status, error=raw or "error", code="invalid_error")
        return ApiError(status=status, error=raw or "error", code="invalid_error")

    def _should_retry_http(self, status: int, attempt: int, total_attempts: int) -> bool:
        if attempt >= total_attempts:
            return False
        return status in {408, 425, 429, 500, 502, 503, 504}

    def _should_retry_network(self, exc: URLError, attempt: int, total_attempts: int) -> bool:
        if attempt >= total_attempts:
            return False

        reason = getattr(exc, "reason", None)
        if isinstance(reason, (TimeoutError, socket.timeout, ConnectionResetError, ConnectionAbortedError)):
            return True
        if isinstance(reason, OSError):
            winerr = getattr(reason, "winerror", None)
            if winerr in {10053, 10054, 10060, 10061}:
                return True
            if reason.errno in {54, 104, 110}:
                return True
        return False

    def _retry_delay(self, attempt: int) -> float:
        return self.retry_backoff_sec * (2 ** (attempt - 1))

    def _is_retryable_path(self, path: str) -> bool:
        return path in self.retryable_paths


class BenchmarkClient(BaseClient):
    """Helper for benchmark-specific routes scoped by task ID."""

    def _post_benchmark(
        self,
        path: str,
        request_model: BaseModel | None,
        response_model: Type[TResp],
        token: Optional[str] = None,
        retry: Optional[bool] = None,
    ) -> TResp:
        return self._post(path, request_model, response_model, token=token, retry=retry)
