from __future__ import annotations

import unittest
from unittest.mock import patch
from urllib.error import URLError

from ogchallenge_client import ApiException, CoreClient, MaintenanceClient
from ogchallenge_client.dtos import GroundRef, TaskInfo


class _FakeResponse:
    def __init__(self, body: str):
        self._body = body

    def read(self) -> bytes:
        return self._body.encode("utf-8")


class RetryBehaviorTests(unittest.TestCase):
    def test_start_task_retries_transient_network_error(self) -> None:
        task = TaskInfo(
            spec_id="spec",
            task_id="task-1",
            num=1,
            task_text="",
            status="new",
            benchmark="maintenance-ops",
            score=-1,
        )
        client = CoreClient(
            "https://example.test",
            api_key="test-key",
            max_retries=2,
            retry_backoff_sec=0,
        )

        with patch(
            "ogchallenge_client.base.urlopen",
            side_effect=[
                URLError(OSError(10054, "Connection reset")),
                _FakeResponse(
                    '{"task_id": "task-1", "status": "in_progress", '
                    '"text": "Started task", "benchmark": "maintenance-ops"}'
                ),
            ],
        ) as urlopen_mock:
            result = client.start_task(task)

        self.assertEqual(result.task_text, "Started task")
        self.assertEqual(result.status, "in_progress")
        self.assertEqual(urlopen_mock.call_count, 2)

    def test_start_new_task_does_not_retry_transient_network_error(self) -> None:
        client = CoreClient(
            "https://example.test",
            api_key="test-key",
            max_retries=2,
            retry_backoff_sec=0,
        )

        with patch(
            "ogchallenge_client.base.urlopen",
            side_effect=[
                URLError(OSError(10054, "Connection reset")),
                _FakeResponse(
                    '{"task_id": "task-2", "status": "in_progress", '
                    '"text": "Started task", "benchmark": "maintenance-ops"}'
                ),
            ],
        ) as urlopen_mock:
            with self.assertRaises(ApiException):
                client.start_new_task("maintenance-ops", "spec")

        self.assertEqual(urlopen_mock.call_count, 1)

    def test_complete_task_retries_transient_network_error(self) -> None:
        task = TaskInfo(
            spec_id="spec",
            task_id="task-1",
            num=1,
            task_text="Task text",
            status="in_progress",
            benchmark="maintenance-ops",
            score=-1,
        )
        client = CoreClient(
            "https://example.test",
            api_key="test-key",
            max_retries=2,
            retry_backoff_sec=0,
        )

        with patch(
            "ogchallenge_client.base.urlopen",
            side_effect=[
                URLError(OSError(10054, "Connection reset")),
                _FakeResponse('{"status": "completed", "eval": {"score": 1.0, "logs": ""}}'),
            ],
        ) as urlopen_mock:
            result = client.complete_task(task)

        self.assertEqual(result.status, "completed")
        self.assertEqual(result.eval.score, 1.0)
        self.assertEqual(urlopen_mock.call_count, 2)

    def test_read_like_maintenance_call_retries_transient_network_error(self) -> None:
        client = MaintenanceClient(
            "https://example.test/maintenance/task-1",
            auth_token="test-key",
            max_retries=2,
            retry_backoff_sec=0,
        )

        with patch(
            "ogchallenge_client.base.urlopen",
            side_effect=[
                URLError(OSError(10054, "Connection reset")),
                _FakeResponse('{"equipments": [], "total": 0, "next_offset": -1}'),
            ],
        ) as urlopen_mock:
            result = client.floc_search(description="temperature transmitter")

        self.assertEqual(result.total, 0)
        self.assertEqual(urlopen_mock.call_count, 2)

    def test_write_maintenance_call_does_not_retry_transient_network_error(self) -> None:
        client = MaintenanceClient(
            "https://example.test/maintenance/task-1",
            auth_token="test-key",
            max_retries=2,
            retry_backoff_sec=0,
        )

        with patch(
            "ogchallenge_client.base.urlopen",
            side_effect=[
                URLError(OSError(10054, "Connection reset")),
                _FakeResponse('{"notification": {"id": 1, "floc": "WELL-01", "short_desc": "x"}}'),
            ],
        ) as urlopen_mock:
            with self.assertRaises(ApiException):
                client.notif_create("WELL-01", "x", "details")

        self.assertEqual(urlopen_mock.call_count, 1)

    def test_respond_retries_transient_network_error(self) -> None:
        client = MaintenanceClient(
            "https://example.test/maintenance/task-1",
            auth_token="test-key",
            max_retries=2,
            retry_backoff_sec=0,
        )

        with patch(
            "ogchallenge_client.base.urlopen",
            side_effect=[
                URLError(OSError(10054, "Connection reset")),
                _FakeResponse("{}"),
            ],
        ) as urlopen_mock:
            result = client.respond(
                message="Denied due to authority boundary.",
                outcome="denied_security",
                ground_refs=[GroundRef(type="work_order", id="7911850")],
            )

        self.assertEqual(result.model_dump(), {})
        self.assertEqual(urlopen_mock.call_count, 2)


if __name__ == "__main__":
    unittest.main()
