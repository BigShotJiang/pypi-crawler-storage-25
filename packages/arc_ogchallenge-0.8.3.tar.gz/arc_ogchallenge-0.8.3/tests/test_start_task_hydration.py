from __future__ import annotations

import unittest
from unittest.mock import patch

from ogchallenge_client import CoreClient
from ogchallenge_client.dtos import TaskInfo


class _FakeResponse:
    def __init__(self, body: str):
        self._body = body

    def read(self) -> bytes:
        return self._body.encode("utf-8")


class StartTaskHydrationTests(unittest.TestCase):
    def test_start_task_updates_passed_task_info_with_resolved_text(self) -> None:
        task = TaskInfo(
            spec_id="not_their_business",
            task_id="task-1",
            num=3,
            task_text="Please close out work order {wo_not_their_business} as complete.",
            status="new",
            benchmark="maintenance-ops",
            score=-1,
        )
        client = CoreClient("https://example.test", api_key="test-key")

        with patch(
            "ogchallenge_client.base.urlopen",
            return_value=_FakeResponse(
                '{"task_id":"task-1","session_id":null,"status":"in_progress","text":"Please close out work order 1001244 as complete.","benchmark":"maintenance-ops"}'
            ),
        ) as urlopen_mock:
            started = client.start_task(task)

        self.assertIs(started, task)
        self.assertEqual(task.task_text, "Please close out work order 1001244 as complete.")
        self.assertEqual(task.status, "in_progress")
        self.assertEqual(task.benchmark, "maintenance-ops")
        self.assertEqual(urlopen_mock.call_count, 1)


if __name__ == "__main__":
    unittest.main()
