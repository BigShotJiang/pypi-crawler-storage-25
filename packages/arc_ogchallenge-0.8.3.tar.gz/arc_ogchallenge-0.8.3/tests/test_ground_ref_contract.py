from __future__ import annotations

import unittest

from pydantic import ValidationError

from ogchallenge_client.dtos import GroundRef


class GroundRefContractTests(unittest.TestCase):
    def test_accepts_known_ground_ref_type(self) -> None:
        ref = GroundRef(type="wiki", id="sop/block-valve-replacement.md")
        self.assertEqual(ref.type, "wiki")

    def test_rejects_unknown_ground_ref_type(self) -> None:
        with self.assertRaises(ValidationError):
            GroundRef(type="wiki_document", id="sop/block-valve-replacement.md")


if __name__ == "__main__":
    unittest.main()
