# Posterior

::: bayinx.posterior
