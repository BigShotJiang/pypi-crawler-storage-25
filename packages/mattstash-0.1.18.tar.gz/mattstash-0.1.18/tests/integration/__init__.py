"""Integration tests for MattStash."""
