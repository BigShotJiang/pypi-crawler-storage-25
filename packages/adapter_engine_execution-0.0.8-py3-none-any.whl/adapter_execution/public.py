from typing import Dict, List, Any, Tuple, Iterable, Union

import polars as pl

from .execution import (
    ExecutionPlan,
    DeepModelAPIProtocol,
    PolarsType,
    EdgeQLQuery,
    ExecutionContext,
)
from .models import FieldSchema


DataPayload = List[Dict[str, Any]]


def _execute(
    exec_plan: ExecutionPlan,
    edgedb_dsn: str,
    edgedb_dbname: str,
    default_module: str,
    enable_lazy_frame: bool,
    header: Dict,
    deepmodel_api: DeepModelAPIProtocol,
    advance_sequence: bool = True,
    with_schema: bool = False,
    eql_result: Any = None,
    params: Dict[str, Any] = None,
    with_globals: Dict[str, Any] = None,
    without_globals: List[str] = None,
    global_index_offset: int = 0,
) -> Union[Tuple[pl.DataFrame, List[FieldSchema], Dict[str, Dict]], pl.DataFrame]:
    exec_ctx = ExecutionContext(
        edgedb_dsn=edgedb_dsn,
        edgedb_dbname=edgedb_dbname,
        default_module=default_module,
        plans=exec_plan.extract_subplan(),
        enable_lazy_frame=enable_lazy_frame,
        eql_result=eql_result,
        headers=header,
        advance_sequence=advance_sequence,
        deepmodel_api=deepmodel_api,
        params=params,
        with_globals=with_globals,
        without_globals=without_globals,
        global_index_offset=global_index_offset,
    )

    df = exec_plan.execute(exec_ctx)
    if exec_ctx.enable_lazy_frame:
        df = df.collect()

    if not with_schema:
        return df

    schema = {
        k: PolarsType.from_pltype(v)
        for k, v in df.schema.items()
    }
    human_readable_schema = [
        FieldSchema.from_polars_type(name, plt)
        for name, plt in schema.items()
    ]
    ser_schema = {
        k: v.dict(exclude_unset=True, exclude_defaults=True)
        for k, v in schema.items()
    }
    return df, human_readable_schema, ser_schema


def execute_plan(
    *args,
    with_schema: bool = False,
    **kwargs,
) -> Union[Tuple[DataPayload, List[FieldSchema], Dict[str, Dict]], DataPayload]:
    result = _execute(
        *args,
        with_schema=with_schema,
        **kwargs
    )
    if not with_schema:
        return result.to_dicts()

    df, *schema = result
    return (df.to_dicts(), *schema)  # noqa


def execute_plan_raw(
    *args,
    with_schema: bool = False,
    **kwargs,
) -> Union[Tuple[pl.DataFrame, List[FieldSchema], Dict[str, Dict]], pl.DataFrame]:
    result = _execute(
        *args,
        with_schema=with_schema,
        **kwargs
    )
    if not with_schema:
        return result

    df, *schema = result
    return (df, *schema)  # noqa


def execute_plan_stream(
    exec_plan: ExecutionPlan,
    edgedb_dsn: str,
    edgedb_dbname: str,
    default_module: str,
    enable_lazy_frame: bool,
    header: Dict,
    deepmodel_api: DeepModelAPIProtocol,
    advance_sequence: bool = True,
    params: Dict[str, Any] = None,
    with_globals: Dict[str, Any] = None,
    without_globals: List[str] = None,
    chunksize: int = 4096,
) -> Iterable[pl.DataFrame]:
    eql_plan = exec_plan.find_plan_of_type(EdgeQLQuery)
    if eql_plan is None:
        raise ValueError("No EdgeQL query found")

    ctx = ExecutionContext(
        edgedb_dsn=edgedb_dsn,
        edgedb_dbname=edgedb_dbname,
        default_module=default_module,
        deepmodel_api=deepmodel_api,
        params=params,
        with_globals=with_globals,
        without_globals=without_globals,
        chunksize=chunksize,
    )

    for idx, res in enumerate(eql_plan.query_stream(ctx)):
        yield _execute(
            exec_plan=exec_plan,
            edgedb_dsn=edgedb_dsn,
            edgedb_dbname=edgedb_dbname,
            default_module=default_module,
            enable_lazy_frame=enable_lazy_frame,
            header=header,
            deepmodel_api=deepmodel_api,
            advance_sequence=advance_sequence,
            eql_result=res,
            params=params,
            with_globals=with_globals,
            without_globals=without_globals,
            with_schema=False,
            global_index_offset=idx * chunksize,
        )
        exec_plan.invalidate_cache()
