from __future__ import annotations

import datetime
import decimal
import functools
import json
import uuid
from dataclasses import dataclass, replace
from typing import Any, Union, List, Tuple

import edgedb
from edgedb.introspect import introspect_object as intro

PathElem = Union[str, type[List]]
Path = Tuple[PathElem, ...]


@dataclass(frozen=True)
class Context:
    frame_desc: Any = None
    query_df: bool = False
    uuid_as_str: bool = True
    unnamedtuple_as_dict: bool = False
    path: Path = ()

    def with_field(self, field: str):
        return replace(
            self,
            frame_desc=self.frame_desc[field],
            path=self.path + (field, ),
        )

    def with_list(self):
        return replace(self, path=self.path + (list, ))


DEFAULT_CONTEXT = Context()


@functools.singledispatch
def serialize(o, ctx: Context = DEFAULT_CONTEXT):
    raise TypeError(f'无法序列化类型: {type(o)}')


@serialize.register
def _tuple(o: edgedb.Tuple, ctx: Context = DEFAULT_CONTEXT):
    if ctx.frame_desc is None:
        tup = tuple(serialize(el, ctx) for el in o)
    else:
        tup = tuple(
            serialize(el, replace(ctx, frame_desc=ctx.frame_desc[idx]))
            for idx, el in enumerate(o)
        )
    if ctx.unnamedtuple_as_dict:
        return dict(zip(map(str, range(len(tup))), tup))
    else:
        return tup


@serialize.register
def _namedtuple(o: edgedb.NamedTuple, ctx: Context = DEFAULT_CONTEXT):
    if ctx.frame_desc is None:
        return {attr: serialize(getattr(o, attr), ctx) for attr in dir(o)}
    return {
        attr: serialize(getattr(o, attr), replace(ctx, frame_desc=ctx.frame_desc[attr]))
        for attr in ctx.frame_desc
    }


@serialize.register
def _linkset(o: edgedb.LinkSet, ctx: Context = DEFAULT_CONTEXT):
    return [serialize(el, ctx) for el in o]


@serialize.register
def _link(o: edgedb.Link, ctx: Context = DEFAULT_CONTEXT):
    ret = {}
    if ctx.frame_desc is None:
        for lprop in dir(o):
            if lprop in {'source', 'target'}:
                continue
            ret[f'@{lprop}'] = serialize(getattr(o, lprop))

        ret.update(_object(o.target))
        return ret

    lprops = list(map(lambda x: f'@{x}', (set(dir(o)) - {'source', 'target'})))
    for field in ctx.frame_desc:
        new_ctx = replace(ctx, frame_desc=ctx.frame_desc[field])
        if field in lprops:
            ret[field] = serialize(getattr(o, field[1:]), new_ctx)
        else:
            ret[field] = serialize(getattr(o.target, field), new_ctx)
    return ret


def ignore_implicited_fields(o: edgedb.Object):
    return set(dir(o)) - {desc.name for desc in intro(o).pointers if desc.implicit}


@serialize.register
def _object(o: edgedb.Object, ctx: Context = DEFAULT_CONTEXT):
    ret = {}

    if ctx.frame_desc is None:
        if ctx.query_df:
            attrs = dir(o)
        else:
            attrs = ignore_implicited_fields(o)
        for attr in attrs:
            try:
                ret[attr] = serialize(o[attr])
            except (KeyError, TypeError):
                ret[attr] = serialize(getattr(o, attr), ctx)
        return ret

    ensure_one_field = ctx.query_df and len(ctx.frame_desc) == 1
    for key, value in dict(ctx.frame_desc).items():
        if isinstance(key, tuple):
            # key: (field_name, not_implicit)
            maybe_drop = ctx.frame_desc.pop(key)
            if ensure_one_field or key[1]:
                ctx.frame_desc[key[0]] = maybe_drop

    for attr in ctx.frame_desc:
        new_ctx = replace(ctx, frame_desc=ctx.frame_desc[attr])
        try:
            ret[attr] = serialize(o[attr], new_ctx)
        except (KeyError, TypeError):
            ret[attr] = serialize(getattr(o, attr), new_ctx)

    return ret


@serialize.register(edgedb.Set)
@serialize.register(edgedb.Array)
def _set(o, ctx: Context = DEFAULT_CONTEXT):
    return [serialize(el, ctx) for el in o]


@serialize.register(decimal.Decimal)
def _scalar(o, ctx: Context = DEFAULT_CONTEXT):
    return o


@serialize.register(int)
@serialize.register(float)
@serialize.register(str)
@serialize.register(bytes)
@serialize.register(bool)
@serialize.register(type(None))
@serialize.register(datetime.timedelta)
@serialize.register(datetime.date)
@serialize.register(datetime.datetime)
@serialize.register(datetime.time)
@serialize.register(edgedb.RelativeDuration)
def _scalar(o, ctx: Context = DEFAULT_CONTEXT):
    if ctx.frame_desc == 'std::json' and isinstance(o, str):
        return json.loads(o)
    return o


@serialize.register(uuid.UUID)
def _scalar(o: uuid.UUID, ctx: Context = DEFAULT_CONTEXT):
    if ctx.uuid_as_str:
        return str(o)
    return o


@serialize.register
def _enum(o: edgedb.EnumValue, ctx: Context = DEFAULT_CONTEXT):
    return str(o)
