from .execution import (
    ExecutionPlan,
    DeepModelAPIProtocol,
    PolarsType,
    EdgeQLQuery
)
from .models import FieldSchema
from .public import execute_plan, execute_plan_stream, execute_plan_raw

__version__ = '0.0.8'
__version_tuple__ = tuple(map(int, __version__.split('.')))
