from __future__ import annotations

import textwrap
import typing as t

from pydantic import Field
from pydantic.main import ModelMetaclass  # noqa

from adapter_execution.models.base import SubclassAwareModel


class AutoClassNameModel(ModelMetaclass):
    def __new__(mcs, name, bases, namespace: dict, **kwargs):  # noqa C901
        namespace["cls"] = name
        annos = namespace.setdefault("__annotations__", {})
        annos["cls"] = t.Literal[name]  # noqa
        cls = super().__new__(mcs, name, bases, namespace, **kwargs)
        return cls


class Expr(
    SubclassAwareModel,
    metaclass=AutoClassNameModel,
    abstract=True,
    collect_subclass=True,
):
    def dump_edgeql(self) -> str:
        raise NotImplementedError

    @property
    def multi_line(self) -> bool:
        return False


class Statement(Expr, abstract=True):
    def dump_edgeql(self) -> str:
        raise NotImplementedError

    @property
    def multi_line(self) -> bool:
        return True


class ObjectType(Expr):
    name: str
    module: t.Optional[str] = None

    def dump_edgeql(self) -> str:
        if self.module is None:
            return self.name
        return f"{self.module}::{self.name}"


class Constant(Expr):
    value: t.Any


class EmptySet(Expr):
    def dump_edgeql(self) -> str:
        return "{}"


class TypeCast(Expr):
    type: str
    value: AnyExpr
    in_parenthes: bool = False

    def dump_edgeql(self) -> str:
        if self.in_parenthes:
            return f"<{self.type}>({self.value.dump_edgeql()})"
        else:
            return f"<{self.type}>{self.value.dump_edgeql()}"


class Literal(Expr):
    value: str

    def dump_edgeql(self) -> str:
        return self.value


class MultiLineLiteral(Statement):
    value: str

    def dump_edgeql(self) -> str:
        return textwrap.dedent(self.value).strip()


class Assignment(Expr):
    target: str
    value: AnyExpr

    def dump_edgeql(self) -> str:
        if self.value.multi_line:
            return textwrap.dedent(f"""
                `{self.target}` := (
                %s
                )
            """).strip() % textwrap.indent(self.value.dump_edgeql(), " "*4)
        else:
            return f"`{self.target}` := {self.value.dump_edgeql()}"


class Ptr(Expr):
    ptr: str
    direction: t.Literal[">", "<"] = Field(">")

    def dump_edgeql(self) -> str:
        if self.direction == ">":
            return f".{self.ptr}"
        else:
            return f".<{self.ptr}"


class Shape(Statement):
    expr: t.Optional[AnyExpr]
    elements: t.List[AnyExpr]

    def dump_edgeql(self) -> str:
        if self.expr is None:
            subject = ""
        else:
            subject = self.expr.dump_edgeql() + " "

        if self.expr and self.expr.multi_line:
            template = textwrap.dedent("""
                (
                %s 
                ) {
                %s            
                }
            """)
            subject = textwrap.indent(subject, " " * 4)
        else:
            template = textwrap.dedent("""
                %s{
                %s            
                }
            """)

        elements = ',\n'.join(ele.dump_edgeql() for ele in self.elements)
        return template.strip() % (
            subject,
            textwrap.indent(elements, " " * 4)
        )


class Select(Statement):
    result: AnyExpr
    filter: t.Optional[AnyExpr]

    def dump_edgeql(self) -> str:
        args = (
            textwrap.indent(self.result.dump_edgeql(), " " * 4),
        )
        if self.result.multi_line:
            template = textwrap.dedent("""
                SELECT (
                %s
                )
            """)
        else:
            template = textwrap.dedent("""
                SELECT
                %s
            """)
        if self.filter is not None:
            template = textwrap.dedent("""
            %s
            FILTER
            %%s
            """) % template.strip()
            args += (textwrap.indent(self.filter.dump_edgeql(), " " * 4),)
        return template.strip() % args


class CTE(Statement):
    source: AnyExpr
    alias: str
    result: AnyExpr

    def dump_edgeql(self) -> str:
        return textwrap.dedent(f"""
            WITH {self.alias} := (
            %s
            )
            %s
        """) % (
            textwrap.indent(self.source.dump_edgeql(), " " * 4),
            Select(result=self.result).dump_edgeql(),
        )


class Group(Statement):
    subject: AnyExpr
    by: t.List[AnyExpr]

    def dump_edgeql(self) -> str:
        group_by = ",\n".join(item.dump_edgeql() for item in self.by)
        template = textwrap.dedent(f"""
            GROUP (
            %s
            )
            BY
            %s
        """)
        args = (
            textwrap.indent(self.subject.dump_edgeql(), " " * 4),
            textwrap.indent(group_by, " " * 4)
        )
        return template.strip() % args


class FunctionCall(Expr):
    function: str
    args: t.List[AnyExpr]

    def dump_edgeql(self) -> str:
        if self.multi_line:
            arg_list = ", ".join(arg.dump_edgeql() for arg in self.args)
            return f"{self.function}({arg_list})"

        template = textwrap.dedent(f"""
            {self.function}(
            %s
            )
        """)
        arg_list = textwrap.indent(
            ",\n".join(arg.dump_edgeql() for arg in self.args),
            " " * 4
        )
        return template.strip() % arg_list

    @property
    def multi_line(self) -> bool:
        return (
            len(self.args) > 3
            or any(expr.multi_line for expr in self.args)
        )


class UnaryOp(Expr):
    op: str
    operand: AnyExpr

    def dump_edgeql(self) -> str:
        return f"{self.op}{self.operand.dump_edgeql()}"

    @property
    def multi_line(self) -> bool:
        return self.operand.multi_line


class Comment(Expr):
    comment: str

    def dump_edgeql(self) -> str:
        return f"# {self.comment}"


AnyExpr = Expr.create_discriminated_union("cls")
for _cls in Expr.get_subclasses():
    _cls.update_forward_refs()
del _cls
