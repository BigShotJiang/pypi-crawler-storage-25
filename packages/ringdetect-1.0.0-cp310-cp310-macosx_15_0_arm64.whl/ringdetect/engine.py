import ctypes
import numpy as np
import os
import tempfile

_lib_path = os.path.join(os.path.dirname(__file__), "libringengine.so")
if not os.path.exists(_lib_path):
    raise FileNotFoundError(f"Shared library not found at {_lib_path}. Run 'make lib'.")

_lib = ctypes.CDLL(_lib_path)

# Update signature with the new cell pointer
_lib.find_rings.argtypes = [
    ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_double),
    ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_double),
    ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_int),
    ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_int),
    ctypes.POINTER(ctypes.c_int), ctypes.c_char_p,
    ctypes.POINTER(ctypes.c_double) # <-- NEW: Cell pointer
]

def _get_radii(elements):
    radii_map = {"H": 0.31, "C": 0.76, "N": 0.71, "O": 0.66, "Pd": 1.39}
    return np.array([radii_map.get(el, 1.00) for el in elements], dtype=np.float64)

def find_rings(x, y, z, elements, max_ring=6, threads=0, target_rings=None, cell=None):
    """Core function mapping NumPy arrays to the Fortran backend."""
    n_atoms = len(x)
    x_np = np.ascontiguousarray(x, dtype=np.float64)
    y_np = np.ascontiguousarray(y, dtype=np.float64)
    z_np = np.ascontiguousarray(z, dtype=np.float64)
    r_np = np.ascontiguousarray(_get_radii(elements), dtype=np.float64)
    
    # Handle Periodic Boundary Conditions
    if cell is not None:
        cell_np = np.ascontiguousarray(cell, dtype=np.float64)
    else:
        cell_np = np.zeros(3, dtype=np.float64)

    c_n_atoms = ctypes.c_int(n_atoms)
    c_max_ring = ctypes.c_int(max_ring)
    c_sep = ctypes.c_char(b',')
    c_threads = ctypes.c_int(threads)
    
    targets = np.zeros(100, dtype=np.int32)
    if target_rings:
        for tr in target_rings:
            if 3 <= tr <= 100: targets[tr-1] = 1
    else:
        targets[2:max_ring] = 1

    c_targets = np.ascontiguousarray(targets, dtype=np.int32)

    temp_fd, temp_path = tempfile.mkstemp(suffix=".tmp")
    os.close(temp_fd)
    c_out_filename = ctypes.c_char_p(temp_path.encode('utf-8'))

    _lib.find_rings(
        ctypes.byref(c_n_atoms), x_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
        y_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)), z_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)),
        r_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double)), ctypes.byref(c_max_ring),
        ctypes.byref(c_sep), ctypes.byref(c_threads),
        c_targets.ctypes.data_as(ctypes.POINTER(ctypes.c_int)), c_out_filename,
        cell_np.ctypes.data_as(ctypes.POINTER(ctypes.c_double))
    )

    results = []
    with open(temp_path, 'r') as f:
        for line in f:
            if "-MR" not in line: continue
            parts = line.strip().split(":")
            depth = int(parts[0].split("-")[0])
            results.append({
                "size": depth,
                "planar": "(PLANAR)" in parts[0],
                "indices": [int(idx) for idx in parts[1].split(",")]
            })
            
    os.remove(temp_path)
    return results

# ==========================================
# 🚀 THIRD PARTY INTEGRATIONS
# ==========================================

def find_rings_ase(atoms, max_ring=6, threads=0, target_rings=None):
    """Directly process an ASE Atoms object, auto-detecting periodic boundaries."""
    x, y, z = atoms.positions.T
    elements = atoms.get_chemical_symbols()
    
    # Auto-extract cell if PBC is active
    cell = atoms.cell.lengths() if any(atoms.pbc) else None
    
    return find_rings(x, y, z, elements, max_ring, threads, target_rings, cell)

def find_rings_rdkit(mol, conformer_id=-1, max_ring=6, threads=0, target_rings=None):
    """Directly process an RDKit Mol object."""
    conf = mol.GetConformer(conformer_id)
    positions = conf.GetPositions()
    x, y, z = positions.T
    elements = [atom.GetSymbol() for atom in mol.GetAtoms()]
    
    return find_rings(x, y, z, elements, max_ring, threads, target_rings)
