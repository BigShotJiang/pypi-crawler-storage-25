# === ANCHOR: VIB_MANUAL_CMD_START ===
"""vib manual - 코알못을 위한 VibeLign 상세 매뉴얼."""

from __future__ import annotations

import json
from argparse import Namespace
from typing import Protocol, TypedDict

has_rich: bool

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text
    from rich import box

    has_rich = True
    console = Console()
except ModuleNotFoundError:
    Console = None  # type: ignore[assignment]
    Panel = None  # type: ignore[assignment]
    Table = None  # type: ignore[assignment]
    Text = None  # type: ignore[assignment]
    box = None  # type: ignore[assignment]

    class _PlainConsole:
        def print(self, *parts: object, **_: object) -> None:
            print(" ".join(str(part) for part in parts))

        def rule(self, title: str = "") -> None:
            if title:
                print(f"\n=== {title} ===")
            else:
                print("\n====================")

    console = _PlainConsole()


class ManualEntry(TypedDict, total=False):
    emoji: str
    title: str
    one_line: str
    what: str
    when: list[str]
    examples: list[tuple[str, str]]
    options: list[tuple[str, str]]
    notes: list[str]  # 알아두면 좋은 동작 설명 (선택)


class ManualArgs(Protocol):
    command_name: str | None
    save: bool
    all: bool
    json: bool


# ──────────────────────────────────────────────
# 매뉴얼 데이터
# ──────────────────────────────────────────────

MANUAL: dict[str, ManualEntry] = {
    "start": {
        "emoji": "🚀",
        "title": "vib start",
        "one_line": "처음 시작할 때 딱 한 번만 실행해요",
        "what": (
            "새 프로젝트에서 VibeLign을 처음 쓸 때 필요한 파일을 자동으로 만들어줘요.\n"
            "AGENTS.md, AI_DEV_SYSTEM_SINGLE_FILE.md 같은 파일이 생기는데,\n"
            "이게 있어야 AI가 내 프로젝트를 제대로 이해하고 작업해요.\n\n"
            "Git을 쓰는 프로젝트라면 커밋 전에 비밀정보를 막아주는 보호도 같이 켜줘요.\n"
            "그래서 API 키, 토큰, .env 같은 걸 실수로 올리려 하면 커밋 단계에서 한 번 더 잡아줘요.\n"
            "지금은 여기에 `vib guard --strict` 검사도 같이 연결돼서 구조 문제까지 한 번 더 막아줘요.\n\n"
            "`vib start --all-tools`를 쓰면 Claude, Antigravity, OpenCode, Cursor, Codex 준비도 한 번에 해줘요.\n"
            "기본값은 기존 설정을 최대한 보존하면서 없는 것만 추가해요.\n"
            "정말 다시 깔듯이 새로 만들고 싶을 때만 `--force`를 써요.\n"
            "`--quickstart`를 붙이면 start 뒤에 앵커까지 자동으로 넣어줘서 더 빨리 시작할 수 있어요."
        ),
        "when": [
            "새 프로젝트 폴더에서 VibeLign을 처음 쓸 때",
            "AI한테 코딩을 맡기기 전에 한 번만 세팅할 때",
            "설치 직후 처음 설정할 때",
            "여러 AI 도구를 한 번에 준비하고 싶을 때",
        ],
        "examples": [
            ("vib start", "기본 세팅 (가장 많이 씀)"),
            (
                "vib start --all-tools",
                "Claude, Antigravity, OpenCode, Cursor, Codex를 한 번에 준비",
            ),
            ("vib start --all-tools --force", "기존 VibeLign 설정도 다시 생성"),
            ("vib start --quickstart", "세팅 + 앵커 자동 삽입까지 한 번에"),
        ],
        "options": [
            (
                "--all-tools",
                "Claude, Antigravity, OpenCode, Cursor, Codex 설정을 한 번에 준비해요.\n기존 설정은 최대한 보존하면서 없는 것만 추가해요.",
            ),
            (
                "--tools",
                "원하는 도구만 골라서 준비해요.\n예: claude,opencode,cursor,antigravity,codex",
            ),
            (
                "--force",
                "기존 VibeLign 설정 파일도 다시 만들거나 덮어써요.\n기본값은 안전 모드라서 기존 설정을 최대한 유지해요.",
            ),
            (
                "--quickstart",
                "start 실행 후 anchor --auto 까지 자동으로 실행해요.\n한 번에 다 끝내고 싶을 때 써요.",
            ),
            (
                "준비 상태 안내",
                "start가 끝나면 도구별로 '바로 사용 가능' / '거의 끝남'을 알려줘요.\n현재는 Claude, Antigravity, OpenCode는 바로 사용 가능으로 보여줘요.",
            ),
            (
                "비밀정보 커밋 보호",
                "Git 저장소라면 커밋할 때마다 자동 검사도 같이 켜줘요.\n커밋 전에 API 키, 토큰, 개인키, .env 같은 걸 검사하고, strict guard도 같이 확인해줘요.",
            ),
            (
                "message",
                "start 뒤에 메모를 짧게 붙일 수도 있어요.\n예: vib start 첫 세팅 시작",
            ),
        ],
    },
    "checkpoint": {
        "emoji": "💾",
        "title": "vib checkpoint",
        "one_line": "게임 세이브처럼 지금 상태를 저장해요",
        "what": (
            "AI한테 코드를 맡기기 전에 현재 상태를 저장해두는 기능이에요.\n"
            "뭔가 잘못되면 이 시점으로 되돌릴 수 있어요.\n"
            "게임에서 '세이브' 버튼 누르는 것과 똑같아요.\n\n"
            "메시지 없이 실행하면 메모를 입력할 수 있는 화면이 나와요.\n"
            "git commit 메시지처럼 '이 시점에 뭘 했는지' 적어두면\n"
            "나중에 vib undo 에서 어떤 걸 골라야 할지 쉽게 알 수 있어요.\n\n"
            "체크포인트 저장 시 PROJECT_CONTEXT.md도 자동으로 갱신돼요.\n"
            "AI 툴을 바꿀 때 별도로 vib transfer를 실행하지 않아도 됩니다.\n\n"
            "Git 저장소에서는 commit 뒤 자동 백업을 켤 수 있어요.\n"
            "커밋마다 저장본이 쌓이는 게 부담되면 `vib config auto-backup off`로 끄고,\n"
            "필요할 때만 `vib checkpoint`로 수동 저장하면 됩니다.\n\n"
            "BACKUPS 화면의 '백업 범위'는 복원 가능한 원본 크기의 합계예요.\n"
            "중복 제거/압축 뒤 실제 디스크 사용량은 `vib backup-db-viewer --json` 또는 GUI의 Backup DB Viewer에서 확인하세요."
        ),
        "when": [
            "AI한테 수정을 시키기 바로 직전",
            "기능이 완성됐을 때 기록을 남기고 싶을 때",
            "큰 작업을 시작하기 전에 안전망을 만들 때",
        ],
        "examples": [
            ("vib checkpoint", "실행 → 메시지 입력 화면이 나와요"),
            ('vib checkpoint "로그인 완성"', "메시지를 바로 지정해서 저장"),
            ('vib checkpoint "버그 수정 전"', "작업 전 백업"),
            ("vib config auto-backup off", "commit 뒤 자동 백업 끄기"),
            ("vib backup-db-viewer --json", "실제 백업 DB/object store 크기 확인"),
        ],
        "options": [
            (
                "message",
                '저장할 때 메모를 남길 수 있어요.\n메시지 없이 실행하면 입력 화면이 나와요.\n엔터만 누르면 메시지 없이 저장돼요.\n예: vib checkpoint "회원가입 버튼 추가"',
            ),
            (
                "auto-backup",
                "commit 뒤 자동 백업은 별도 설정이에요.\n`vib config auto-backup status`로 상태를 보고, on/off로 바꿀 수 있어요.",
            ),
        ],
    },
    "undo": {
        "emoji": "⏪",
        "title": "vib undo",
        "one_line": "저장한 곳으로 되돌려요",
        "what": (
            "AI가 코드를 이상하게 바꿨을 때 저장한 시점으로 되돌려요.\n"
            "게임에서 '불러오기' 버튼 누르는 것과 똑같아요.\n"
            "checkpoint로 저장해뒀어야 쓸 수 있어요.\n\n"
            "실행하면 저장된 목록이 번호와 함께 나와요:\n"
            "  [1] 오늘 16:52:47   로그인 기능 추가 전  ← 가장 최근\n"
            "  [2] 오늘 14:30:05   시작\n"
            "  [0] 취소\n\n"
            "번호를 입력하면 그 시점으로 되돌아가요.\n"
            "엔터만 누르면 가장 최근 저장으로 되돌려요.\n"
            "0을 누르면 아무것도 안 하고 취소돼요."
        ),
        "when": [
            "AI가 코드를 망가뜨렸을 때",
            "수정 결과가 마음에 들지 않을 때",
            "실수로 파일을 지웠을 때",
            "특정 시점으로 골라서 되돌리고 싶을 때",
        ],
        "examples": [
            ("vib undo", "목록 보고 번호 선택 → 되돌리기"),
        ],
        "options": [
            (
                "번호 입력",
                "목록에서 원하는 시점의 번호를 입력해요.\n엔터 = 가장 최근 / 0 또는 q = 취소",
            ),
        ],
    },
    "history": {
        "emoji": "📋",
        "title": "vib history",
        "one_line": "저장 목록을 봐요",
        "what": (
            "지금까지 checkpoint로 저장한 기록을 전부 보여줘요.\n"
            "언제 저장했는지, 어떤 메시지를 남겼는지 확인할 수 있어요.\n\n"
            "시간은 '오늘 16:52:34' / '어제 09:00:11' 처럼 읽기 쉽게 나와요.\n"
            "되돌리려면 vib undo 를 쓰세요."
        ),
        "when": [
            "내가 언제 저장했는지 확인하고 싶을 때",
            "어떤 버전으로 되돌릴지 결정하기 전에 목록을 먼저 볼 때",
            "저장이 제대로 됐는지 확인하고 싶을 때",
        ],
        "examples": [
            ("vib history", "저장 기록 전체 보기"),
        ],
        "options": [],
    },
    "backup-db-viewer": {
        "emoji": "🗄️",
        "title": "vib backup-db-viewer",
        "one_line": "백업 관리 DB의 실제 저장 상태를 읽기 전용으로 확인해요",
        "what": (
            "Rust/SQLite 백업 관리 DB(.vibelign/vibelign.db)를 안전하게 들여다보는 명령어예요.\n"
            "체크포인트 개수, DB/WAL/SHM 파일 크기, object store 실제 저장량을 구분해서 보여줘요.\n\n"
            "읽기 전용이라 Raw SQL 실행, DB 편집, object 삭제 같은 위험한 작업은 하지 않아요."
        ),
        "when": [
            "BACKUPS 화면의 '백업 범위'와 실제 디스크 사용량 차이를 확인할 때",
            "자동 백업이 많이 쌓여 DB/object store 상태를 점검하고 싶을 때",
            "Windows/macOS 번들 CLI에서 백업 DB 상태를 JSON으로 확인할 때",
        ],
        "examples": [
            ("vib backup-db-viewer --json", "현재 프로젝트 백업 DB 상태를 JSON으로 확인"),
            (
                "vib backup-db-viewer --root /path/to/project --json",
                "다른 프로젝트 루트의 백업 DB 상태 확인",
            ),
        ],
        "options": [
            ("--root", "확인할 프로젝트 루트예요. 안 쓰면 현재 폴더를 사용해요."),
            ("--json", "GUI/스크립트가 읽기 좋은 JSON으로 출력해요."),
        ],
    },
    "backup-db-maintenance": {
        "emoji": "🧹",
        "title": "vib backup-db-maintenance",
        "one_line": "백업 관리 DB 파일 크기를 dry-run 우선으로 안전하게 점검/정리해요",
        "what": (
            "백업 관리 DB의 WAL/빈 페이지 상태를 점검하고 필요한 정리 계획을 보여주는 명령어예요.\n"
            "기본값은 dry-run이라 실제 파일을 바꾸지 않고, `--apply`를 명시해야 정리를 실행해요.\n\n"
            "실행 모드에서는 DB 파일을 먼저 백업한 뒤 WAL 정리와 조건부 VACUUM을 수행해요."
        ),
        "when": [
            "커밋 후 자동 백업을 오래 켜둬 DB 파일 크기가 걱정될 때",
            "정리 전에 어떤 작업이 필요한지 먼저 확인하고 싶을 때",
            "백업 DB 파일을 안전하게 정리해야 할 때",
        ],
        "examples": [
            ("vib backup-db-maintenance --json", "정리 계획만 확인하는 dry-run"),
            ("vib backup-db-maintenance --apply --json", "DB 파일 백업 후 실제 정리 실행"),
        ],
        "options": [
            ("--root", "확인/정리할 프로젝트 루트예요. 안 쓰면 현재 폴더를 사용해요."),
            ("--apply", "dry-run이 아니라 실제 정리를 실행해요."),
            ("--json", "GUI/스크립트가 읽기 좋은 JSON으로 출력해요."),
        ],
    },
    "backup-graph-summary": {
        "emoji": "🗺️",
        "title": "vib backup-graph-summary",
        "one_line": "백업 범위 그래프 데이터를 작게 요약해요",
        "what": (
            "백업 DB의 파일 row 전체를 터미널/GUI로 보내지 않고, 폴더별 크기 트리만 읽기 전용으로 요약해요.\n"
            "BACKUPS 탭의 백업 범위 그래프를 대용량 백업 기록에서도 빠르게 표시하기 위한 명령입니다."
        ),
        "when": [
            "BACKUPS 탭에서 백업 범위 그래프를 빠르게 표시해야 할 때",
            "checkpoint list JSON이 너무 커서 파일 row 전체 전송을 피하고 싶을 때",
            "백업 DB를 수정하지 않고 그래프용 요약만 확인하고 싶을 때",
        ],
        "examples": [
            ("vib backup-graph-summary --json", "현재 프로젝트의 그래프 요약 확인"),
            ("vib backup-graph-summary --root /path/to/project --json", "다른 프로젝트 루트 그래프 요약 확인"),
        ],
        "options": [
            ("--root", "확인할 프로젝트 루트예요. 안 쓰면 현재 폴더를 사용해요."),
            ("--json", "GUI/스크립트가 읽기 좋은 JSON으로 출력해요."),
        ],
    },
    "backup-cleanup": {
        "emoji": "🧼",
        "title": "vib backup-cleanup",
        "one_line": "오래된 백업과 백업 관리 DB 파일을 한 번에 정리해요",
        "what": (
            "보관 정책에 따라 오래된 백업을 먼저 정리하고, 이어서 백업 관리 DB의 WAL/빈 페이지를 정리해요.\n"
            "GUI의 'DB 정리 실행' 버튼과 같은 흐름이라 터미널 명령을 잘 몰라도 안전하게 사용할 수 있어요."
        ),
        "when": [
            "Backup DB Viewer에서 DB 파일이 너무 커졌다는 경고가 나올 때",
            "오래된 자동 백업과 DB 파일 정리를 한 번에 처리하고 싶을 때",
            "비전문가도 안전하게 백업 정리를 실행해야 할 때",
        ],
        "examples": [
            ("vib backup-cleanup --json", "오래된 백업 정리 + DB 최적화 실행"),
            ("vib backup-cleanup --root /path/to/project --json", "다른 프로젝트 루트 정리"),
        ],
        "options": [
            ("--root", "정리할 프로젝트 루트예요. 안 쓰면 현재 폴더를 사용해요."),
            ("--json", "GUI/스크립트가 읽기 좋은 JSON으로 출력해요."),
        ],
    },
    "docs-build": {
        "emoji": "🧱",
        "title": "vib docs-build",
        "one_line": "문서 요약/다이어그램 캐시를 다시 만들어요",
        "what": (
            "Docs Viewer에서 오른쪽 요약이나 다이어그램이 예전 내용처럼 보일 때 쓰는 명령어예요.\n"
            "쉽게 말하면 '문서용 캐시 다시 만들기'예요.\n\n"
            "전체 문서를 한 번에 다시 만들 수도 있고,\n"
            "특정 markdown 파일 하나만 골라서 다시 만들 수도 있어요."
        ),
        "when": [
            "문서를 수정했는데 Docs Viewer가 안 바뀔 때",
            "다이어그램이 예전 내용처럼 보일 때",
            "특정 문서만 다시 생성하고 싶을 때",
        ],
        "examples": [
            ("vib docs-build", "전체 문서 다시 만들기"),
            ("vib docs-build PROJECT_CONTEXT.md", "루트 문서 하나만 다시 만들기"),
            ("vib docs-build docs/wiki/index.md", "docs 하위 문서 하나만 다시 만들기"),
        ],
        "options": [
            ("path", "다시 만들 markdown 파일 경로예요. 안 쓰면 전체 문서를 처리해요."),
            ("--json", "결과를 JSON으로 보고 싶을 때 써요. 개발/디버깅용이에요."),
        ],
    },
    "docs-index": {
        "emoji": "🗂️",
        "title": "vib docs-index",
        "one_line": "Docs Viewer가 읽는 문서 목록과 계약 정보를 보여줘요",
        "what": (
            "Docs Viewer가 어떤 문서를 보여줄지 목록으로 정리해주는 명령어예요.\n"
            "쉽게 말하면 '문서 리스트 확인하기'예요.\n\n"
            "보통은 GUI가 내부적으로 많이 쓰고,\n"
            "사람은 디버깅하거나 상태를 확인할 때 쓰면 돼요."
        ),
        "when": [
            "Docs Viewer에 어떤 문서가 잡히는지 확인하고 싶을 때",
            "문서 인덱스 문제를 디버깅할 때",
            "visual contract/schema 정보를 보고 싶을 때",
        ],
        "examples": [
            ("vib docs-index", "현재 프로젝트 문서 목록 보기"),
            ("vib docs-index /path/to/project", "다른 프로젝트의 문서 목록 보기"),
            (
                "vib docs-index --visual-contract",
                "docs visual schema/generator 계약 보기",
            ),
        ],
        "options": [
            (
                "path",
                "문서 목록을 만들 프로젝트 루트예요. 안 쓰면 현재 폴더를 사용해요.",
            ),
            (
                "--visual-contract",
                "docs visual artifact의 schema/generator 정보를 JSON으로 보여줘요.",
            ),
        ],
    },
    "docs-enhance": {
        "emoji": "✨",
        "title": "vib docs-enhance",
        "one_line": "AI로 현재 문서의 요약 필드를 생성해요",
        "what": (
            "Docs Viewer artifact에 들어가는 AI 요약 필드를 다시 생성하는 명령어예요.\n"
            "먼저 `vib docs-build <path>`로 문서 artifact를 만든 뒤 실행하면,\n"
            "해당 문서의 요약/설명 필드를 LLM 결과로 보강해요."
        ),
        "when": [
            "Docs Viewer의 AI 요약을 최신 문서 내용으로 다시 만들고 싶을 때",
            "문서 하나만 골라 AI 보강을 실행하고 싶을 때",
            "GUI에서 쓰는 문서 요약 데이터를 CLI로 점검할 때",
        ],
        "examples": [
            ("vib docs-enhance docs/wiki/index.md", "특정 문서의 AI 요약 필드 생성"),
            ("vib docs-enhance PROJECT_CONTEXT.md --json", "결과를 JSON으로 확인"),
        ],
        "options": [
            ("path", "AI 보강할 markdown 문서 경로예요."),
            ("--json", "결과를 JSON으로 출력해요."),
        ],
    },
    "doc-sources": {
        "emoji": "📚",
        "title": "vib doc-sources",
        "one_line": "추가 문서 소스를 등록/제거/조회해요",
        "what": (
            "Docs Viewer가 기본 문서 외에 `.omc/plans` 같은 추가 문서 폴더도 보게 만드는 명령어예요.\n"
            "등록된 소스는 GUI Docs Viewer 사이드바에 Custom 카테고리로 표시됩니다."
        ),
        "when": [
            "Docs Viewer에서 프로젝트 외부/추가 문서 폴더도 보고 싶을 때",
            "등록된 custom 문서 소스를 확인하거나 제거할 때",
            "GUI 문서 목록에 계획서나 스펙 폴더를 연결할 때",
        ],
        "examples": [
            ("vib doc-sources list", "등록된 추가 문서 소스 목록 보기"),
            ("vib doc-sources add .omc/plans", "추가 문서 소스 등록"),
            ("vib doc-sources remove .omc/plans", "추가 문서 소스 제거"),
        ],
        "options": [
            ("list", "등록된 추가 문서 소스를 JSON으로 보여줘요."),
            ("add path", "프로젝트 루트 기준 상대 경로를 추가 문서 소스로 등록해요."),
            ("remove path", "등록된 추가 문서 소스를 제거해요."),
        ],
    },
    "doctor": {
        "emoji": "🩺",
        "title": "vib doctor",
        "one_line": "프로젝트 건강 상태를 확인해요",
        "what": (
            "내 프로젝트가 AI 작업을 받기에 괜찮은 상태인지 점검해요.\n"
            "점수로 보여주고, 문제가 있으면 뭐가 문제인지 알려줘요.\n"
            "마치 의사가 건강검진 해주는 것처럼요."
        ),
        "when": [
            "AI한테 코딩을 시키기 전에 준비됐는지 확인할 때",
            "프로젝트 상태가 좋은지 수시로 확인할 때",
            "뭔가 이상한 것 같을 때 진단받고 싶을 때",
        ],
        "examples": [
            ("vib doctor", "기본 점검 (점수 + 문제 목록)"),
            ("vib doctor --strict", "더 꼼꼼하게 점검"),
            ("vib doctor --detailed", "문제마다 심각도·분류·추천 명령 포함"),
            ("vib doctor --fix", "앵커 없는 파일에 자동으로 앵커 추가"),
            (
                "vib doctor --fix-anchors --dry-run",
                "수정 없이 앵커가 필요한 파일만 먼저 확인",
            ),
            (
                "vib doctor --fix-anchors --paths src/app.py",
                "특정 파일 하나만 안전하게 앵커 추가",
            ),
            ("vib doctor --apply", "자동 수정 가능한 항목 일괄 적용"),
            ("vib doctor --write-report", "결과를 파일로 저장"),
        ],
        "options": [
            (
                "--strict",
                "기본 점검보다 더 꼼꼼하게 검사해요.\n작은 문제도 놓치지 않아요.",
            ),
            (
                "--detailed",
                "각 문제마다 심각도(HIGH/MEDIUM/LOW), 분류(구조/앵커/MCP 등),\n왜 중요한지, 추천 명령, 자동 수정 가능 여부를 보여줘요.",
            ),
            ("--fix-hints", "각 문제를 어떻게 고치면 되는지 힌트를 줘요."),
            (
                "--fix",
                "앵커가 없는 파일에 자동으로 앵커를 달아줘요.\n직접 하기 귀찮을 때 편해요.",
            ),
            (
                "--fix-anchors",
                "앵커 없는 파일만 명시적으로 정리해요.\n--dry-run으로 먼저 확인하거나 --paths로 파일을 하나만 지정할 수 있어요.",
            ),
            (
                "--dry-run",
                "doctor의 앵커 자동 수정에서 실제 파일을 바꾸지 않고 대상만 미리 보여줘요.",
            ),
            (
                "--paths src/app.py",
                "doctor의 앵커 자동 수정을 특정 파일로 제한해요.\n예: --paths src/app.py tests/test_app.py",
            ),
            (
                "--apply",
                "자동 수정 가능한 항목을 일괄 적용해요.\n적용 전에 자동으로 체크포인트가 만들어져서 되돌릴 수 있어요.",
            ),
            (
                "--write-report",
                "점검 결과를 파일로 저장해요.\n나중에 다시 볼 수 있어요.",
            ),
            ("--json", "결과를 JSON 형식으로 출력해요. (개발자용)"),
        ],
    },
    "anchor": {
        "emoji": "⚓",
        "title": "vib anchor",
        "one_line": "AI가 정확한 위치를 찾을 수 있도록 표식을 달아요",
        "what": (
            "코드 파일에 '여기서부터 여기까지가 이 기능이야'라는 표식(앵커)을 달아요.\n"
            "이 표식이 있으면 AI가 수정할 때 정확한 위치를 찾을 수 있어요.\n"
            "지도에 핀 꽂는 것처럼요."
        ),
        "when": [
            "AI한테 처음으로 코딩을 시키기 전에 (한 번만 하면 돼요)",
            "새 파일을 추가했을 때",
            "앵커가 제대로 있는지 확인하고 싶을 때",
        ],
        "examples": [
            ("vib anchor --auto", "모든 파일에 자동으로 앵커 달기 (가장 많이 씀)"),
            (
                "vib anchor --suggest",
                "어떻게 달면 좋을지 추천만 보기 (실제로 바꾸지 않음)",
            ),
            ("vib anchor --validate", "앵커가 제대로 달려있는지 검사"),
            ("vib anchor --dry-run", "실제로 바꾸지 않고 어떻게 바뀔지 미리 보기"),
            ("vib anchor --auto --paths src/app.py", "특정 파일 하나에만 앵커 달기"),
            (
                "vib anchor --auto --module-only --paths src/app.py",
                "고급: 함수/클래스 대신 파일 전체 앵커만 달기",
            ),
            ("vib anchor --auto-intent", "모든 앵커 의도 설명 자동 생성"),
            (
                'vib anchor --set-intent ANCHOR_NAME --intent "설명"',
                "앵커 의도 직접 등록",
            ),
            ("vib anchor --list-intent", "등록된 앵커 의도 목록 보기"),
            ("vib anchor --only-ext .py", "Python 파일만 처리"),
        ],
        "options": [
            ("--help", "anchor 명령 도움말을 보여줘요."),
            (
                "--auto",
                "모든 파일에 자동으로 앵커를 달아줘요.\n처음 설정할 때 이걸 써요.",
            ),
            (
                "--suggest",
                "앵커를 어떻게 달면 좋을지 추천만 보여줘요.\n실제로 파일을 바꾸지는 않아요.",
            ),
            (
                "--validate",
                "앵커가 올바르게 달려있는지 검사해요.\n짝이 안 맞는 앵커를 찾아줘요.",
            ),
            ("--dry-run", "실제로 바꾸지 않고 어떻게 바뀔지만 미리 보여줘요."),
            (
                "--paths src/app.py",
                "특정 파일만 대상으로 실행해요.\n예: --paths src/app.py tests/test_app.py",
            ),
            (
                "--module-only",
                "고급 옵션이에요. 함수/클래스 단위 앵커 대신 파일 전체 앵커만 달아요.\n기본값은 더 세밀한 함수/클래스 앵커까지 함께 다는 방식이에요.",
            ),
            (
                "--only-ext .py",
                "특정 확장자의 파일만 처리해요.\n예: --only-ext .py (파이썬만), --only-ext .js (자바스크립트만)",
            ),
            (
                "--set-intent ANCHOR_NAME",
                "특정 앵커에 사람이 직접 의도(intent)를 등록해요.\n--intent와 함께 사용해요.",
            ),
            (
                "--intent TEXT",
                "--set-intent로 등록할 의도 설명 문구예요.",
            ),
            ("--list-intent", "등록된 앵커 의도 목록을 보여줘요."),
            (
                "--auto-intent",
                "코드 기반으로 모든 앵커의 의도 설명을 자동 생성해요.",
            ),
            (
                "--force",
                "--auto-intent 실행 시 기존 AI 생성 항목도 다시 만들어요.",
            ),
            (
                "--with-ai",
                "--auto-intent 실행 시 코드 기반 결과에 AI 보강까지 적용해요.",
            ),
            (
                "--aliases A,B,C",
                "--set-intent 보조 옵션이에요. 검색에 쓸 별칭을 쉼표로 등록해요.",
            ),
            (
                "--description TEXT",
                "--set-intent 보조 옵션이에요. 앵커의 상세 설명을 등록해요.",
            ),
            (
                "--warning TEXT",
                "--set-intent 보조 옵션이에요. AI에게 전달할 주의사항을 등록해요.",
            ),
            (
                "--connects A,B,C",
                "--set-intent 보조 옵션이에요. 연결된 앵커 이름을 쉼표로 등록해요.",
            ),
            ("--json", "결과를 JSON 형식으로 출력해요. (개발자용)"),
        ],
    },
    "scan": {
        "emoji": "🔍",
        "title": "vib scan",
        "one_line": "앵커 스캔 + 코드맵 갱신을 한 번에 해요",
        "what": (
            "앵커 검사, 앵커 인덱스 갱신, 코드맵 재생성을 한 번에 실행해요.\n"
            "anchor 와 start 를 따로 실행하지 않아도 돼요.\n"
            "뭔가 꼬인 것 같을 때 이걸 실행하면 대부분 해결돼요."
        ),
        "when": [
            "파일을 많이 추가하거나 삭제했을 때",
            "앵커가 꼬인 것 같을 때 한 번에 정리하고 싶을 때",
            "코드맵을 최신 상태로 갱신하고 싶을 때",
        ],
        "examples": [
            ("vib scan", "앵커 스캔 + 코드맵 갱신"),
            ("vib scan --auto", "문제 있는 앵커 자동 수정 + 코드맵 갱신"),
        ],
        "options": [
            (
                "--auto",
                "문제 있는 앵커를 자동으로 고쳐줘요.\n앵커를 지웠다가 다시 달아서 깨끗하게 만들어요.",
            ),
        ],
    },
    "patch": {
        "emoji": "🛠️",
        "title": "vib patch",
        "one_line": "말로 요청하면 안전한 수정 계획을 만들어요",
        "what": (
            '"로그인 버튼 추가해줘" 같이 말로 요청하면,\n'
            "어떤 파일의 어느 부분을 어떻게 수정할지 계획을 세워줘요.\n"
            "이 계획을 복사해서 AI (Claude, ChatGPT 등)에 붙여넣으면 돼요."
        ),
        "when": [
            "AI한테 코드 수정을 요청할 때 더 정확하게 전달하고 싶을 때",
            "어떤 파일을 수정해야 할지 모를 때 도움받고 싶을 때",
            "수정 전에 계획을 먼저 확인하고 싶을 때",
        ],
        "examples": [
            ('vib patch "로그인 버튼 추가"', "수정 계획 만들기"),
            ('vib patch "버그 수정" --ai', "AI가 더 정확하게 분석"),
            ('vib patch "사이드바 제거" --preview', "미리 보기"),
            ('vib patch "기능 추가" --copy', "결과를 클립보드에 복사"),
        ],
        "options": [
            ("request", '수정 요청을 말로 써요.\n예: vib patch "다크모드 추가해줘"'),
            (
                "--ai",
                "AI가 코드를 더 자세히 분석해서 정확한 계획을 세워요.\n조금 더 시간이 걸려요.",
            ),
            ("--preview", "수정 계획을 미리 보기로 확인해요."),
            (
                "--copy",
                "AI에 전달할 프롬프트를 클립보드에 복사해요.\n바로 붙여넣기할 수 있어요.",
            ),
            ("--write-report", "수정 계획을 파일로 저장해요."),
            ("--json", "결과를 JSON 형식으로 출력해요. (개발자용)"),
        ],
    },
    "guard": {
        "emoji": "🛡️",
        "title": "vib guard",
        "one_line": "AI가 코드를 망가뜨리지 않았는지 검사해요",
        "what": (
            "AI가 코드를 수정한 후, 구조가 망가지지 않았는지 종합 검사해요.\n"
            "doctor (건강 점검) + explain (변경 설명)을 합친 거예요.\n"
            "AI 작업 후 항상 한 번 실행해보세요."
        ),
        "when": [
            "AI가 코드를 수정한 직후",
            "뭔가 이상한 것 같을 때 종합 검진을 받고 싶을 때",
            "AI 작업 결과를 확인하고 싶을 때",
        ],
        "examples": [
            ("vib guard", "기본 검사"),
            ("vib guard --strict", "더 꼼꼼하게 검사"),
            ("vib guard --since-minutes 30", "최근 30분 변경만 검사"),
            ("vib guard --write-report", "결과를 파일로 저장"),
        ],
        "options": [
            ("--strict", "더 꼼꼼하게 검사해요. 작은 문제도 잡아줘요."),
            (
                "--since-minutes 60",
                "최근 몇 분 동안의 변경만 확인해요.\n기본값은 120분이에요.",
            ),
            ("--write-report", "검사 결과를 파일로 저장해요."),
            ("--json", "결과를 JSON 형식으로 출력해요. (개발자용)"),
            (
                "구조 계획 확인",
                "여러 파일을 크게 바꾸거나 새 production 파일을 만들면 plan-structure가 필요한지도 같이 알려줘요.",
            ),
            (
                "신규 파일 앵커 검사",
                "새 source 파일에 앵커가 하나도 없으면 warn 또는 fail로 알려줘요.\nstrict 모드에서는 fail로 막아요.",
            ),
        ],
    },
    "explain": {
        "emoji": "📖",
        "title": "vib explain",
        "one_line": "뭐가 바뀌었는지 쉽게 알려줘요",
        "what": (
            "최근에 코드가 어떻게 바뀌었는지 쉬운 말로 설명해줘요.\n"
            "AI가 수정한 내용을 이해하기 어려울 때 쓰세요.\n"
            '개발 경험 없어도 "이 파일에서 이런 게 바뀌었어요" 수준으로 알려줘요.'
        ),
        "when": [
            "AI가 수정한 내용이 뭔지 이해하고 싶을 때",
            "어떤 파일이 바뀌었는지 확인하고 싶을 때",
            "변경 내역을 누군가한테 설명해야 할 때",
        ],
        "examples": [
            ("vib explain", "전체 변경 설명"),
            ("vib explain main.py", "특정 파일만 설명"),
            ("vib explain --ai", "AI가 더 자세하게 분석"),
            ("vib explain --since-minutes 30", "최근 30분 변경만 보기"),
        ],
        "options": [
            ("file", "특정 파일의 변경만 설명해요.\n예: vib explain login.py"),
            ("--ai", "AI가 변경 내용을 더 자세하게 분석해서 설명해줘요."),
            (
                "--since-minutes 숫자",
                "최근 몇 분 동안의 변경만 보여줘요.\n기본값은 120분이에요.",
            ),
            ("--write-report", "설명 결과를 파일로 저장해요."),
            ("--json", "결과를 JSON 형식으로 출력해요. (개발자용)"),
        ],
    },
    "protect": {
        "emoji": "🔒",
        "title": "vib protect",
        "one_line": "중요한 파일을 AI가 건드리지 못하게 잠가요",
        "what": (
            "절대 바뀌면 안 되는 파일을 보호해요.\n"
            "보호된 파일은 AI가 수정 대상으로 포함시키지 않아요.\n"
            "설정 파일, 환경 변수 파일 등에 쓰면 좋아요."
        ),
        "when": [
            ".env 같은 설정 파일을 AI가 건드리지 않았으면 할 때",
            "중요한 파일을 실수로 수정하는 걸 막고 싶을 때",
            "보호 목록을 관리하고 싶을 때",
        ],
        "examples": [
            ("vib protect main.py", "main.py 보호"),
            ("vib protect .env", ".env 파일 보호"),
            ("vib protect --list", "보호된 파일 목록 보기"),
            ("vib protect main.py --remove", "main.py 보호 해제"),
        ],
        "options": [
            ("file", "보호할 파일 이름을 써요.\n예: vib protect settings.py"),
            ("--list", "현재 보호되어 있는 파일 목록을 보여줘요."),
            ("--remove", "보호를 해제해요.\n예: vib protect main.py --remove"),
        ],
    },
    "watch": {
        "emoji": "👁️",
        "title": "vib watch",
        "one_line": "파일이 바뀔 때마다 자동으로 코드맵을 갱신해요",
        "what": (
            "파일이 저장될 때마다 자동으로 코드맵을 최신 상태로 유지해요.\n"
            "AI가 작업하는 동안 켜두면 항상 최신 정보로 작업할 수 있어요.\n"
            "watchdog 패키지가 설치되어 있어야 해요. (vib start 에서 자동 설치 제안)"
        ),
        "when": [
            "AI가 코딩하는 동안 백그라운드로 켜두고 싶을 때",
            "파일이 자주 바뀌는 작업 중에",
            "코드맵을 항상 최신 상태로 유지하고 싶을 때",
        ],
        "examples": [
            ("vib watch", "실시간 감시 시작 (Ctrl+C 로 종료)"),
            ("vib watch --strict", "더 꼼꼼한 감시 모드"),
            ("vib watch --auto-fix", "새 source 파일에 앵커를 자동으로 넣기"),
            ("vib watch --write-log", "감시 로그를 파일로 저장"),
        ],
        "options": [
            ("--strict", "더 꼼꼼하게 감시해요. 작은 변화도 잡아줘요."),
            (
                "--auto-fix",
                "새 .py/.ts/.tsx/.js/.jsx 파일에 앵커가 없으면 저장 직후 자동으로 앵커를 넣어줘요.",
            ),
            ("--write-log", "감시 중 발생한 일을 파일로 기록해요."),
            (
                "--debounce-ms 숫자",
                "파일이 바뀐 후 몇 밀리초 후에 처리할지 설정해요.\n기본값은 800ms예요. 너무 자주 갱신되면 늘려요.",
            ),
            ("--json", "결과를 JSON 형식으로 출력해요. (개발자용)"),
        ],
    },
    "bench": {
        "emoji": "📊",
        "title": "vib bench",
        "one_line": "앵커 효과를 비교 실험해요",
        "what": (
            "앵커가 AI 코드 수정 정확도를 얼마나 높이는지 비교하는 벤치마크 명령어예요.\n"
            "A/B 프롬프트를 만들고, 결과를 채점하거나 리포트로 정리할 수 있어요."
        ),
        "when": [
            "앵커 적용 전후의 AI 수정 정확도를 비교하고 싶을 때",
            "patch-suggester 정확도 회귀를 확인할 때",
            "벤치마크 리포트를 만들어 개선 효과를 설명해야 할 때",
        ],
        "examples": [
            ("vib bench --generate", "A/B 조건별 프롬프트 생성"),
            ("vib bench --score", "AI 수정 결과 채점"),
            ("vib bench --report", "마크다운 비교 리포트 생성"),
            ("vib bench --patch", "patch-suggester 정확도 회귀 측정"),
        ],
        "options": [
            ("--generate", "A/B 조건별 벤치마크 프롬프트를 생성해요."),
            ("--score", "생성된 결과를 채점해요."),
            ("--report", "채점 결과를 마크다운 리포트로 만들어요."),
            ("--patch", "patch-suggester 정확도 회귀 테스트를 실행해요."),
            ("--update-baseline", "--patch 결과를 현재 baseline으로 갱신해요."),
            ("--json", "결과를 JSON으로 출력해요."),
        ],
    },
    "ask": {
        "emoji": "💬",
        "title": "vib ask",
        "one_line": "파일이 뭘 하는지 쉬운 말로 설명해줘요",
        "what": (
            "코드 파일을 AI가 분석해서 쉬운 말로 설명해줘요.\n"
            "코드를 모르는 사람도 이 파일이 뭘 하는 건지 알 수 있어요.\n"
            "특정 질문도 할 수 있어요."
        ),
        "when": [
            "이 파일이 뭘 하는 건지 궁금할 때",
            "AI가 만든 코드를 이해하고 싶을 때",
            "특정 파일에 대해 질문하고 싶을 때",
        ],
        "examples": [
            ("vib ask main.py", "main.py가 뭘 하는지 설명"),
            ('vib ask login.py "비밀번호는 어디서 확인해?"', "특정 질문하기"),
            ("vib ask app.py --write", "설명을 파일로 저장"),
        ],
        "options": [
            ("file", "설명할 파일 이름이에요.\n예: vib ask login.py"),
            (
                "question",
                '파일에 대해 궁금한 걸 물어볼 수 있어요.\n예: vib ask login.py "이 함수는 뭐야?"',
            ),
            ("--write", "설명 결과를 VIBELIGN_ASK.md 파일로 저장해요."),
        ],
    },
    "show": {
        "emoji": "🔎",
        "title": "vib show",
        "one_line": "앵커 블록만 콘솔에 찍어요",
        "what": (
            "큰 파일 전체를 열지 않고 지정한 ANCHOR 구간만 줄번호와 함께 보여주는 명령어예요.\n"
            "AI와 작업할 때 필요한 안전 구역만 빠르게 확인할 수 있어요."
        ),
        "when": [
            "큰 파일에서 특정 앵커 내용만 확인하고 싶을 때",
            "AI에게 수정 범위를 알려주기 전에 앵커 구간을 검토할 때",
            "터미널에서 안전 수정 구역을 빠르게 확인할 때",
        ],
        "examples": [
            ("vib show vibelign/core/anchor_tools.py EXTRACT_ANCHOR_SPANS", "특정 앵커 블록 보기"),
            ("vib show vibelign-gui/src/pages/Onboarding.tsx ONBOARDING", "GUI 파일의 앵커 블록 보기"),
        ],
        "options": [
            ("file", "확인할 파일 경로예요. 프로젝트 루트 기준으로 입력해요."),
            ("anchor", "확인할 앵커 이름이에요. `_START`/`_END`는 빼고 입력해요."),
        ],
    },
    "config": {
        "emoji": "🔑",
        "title": "vib config",
        "one_line": "AI 기능을 쓰기 위한 API 키와 지원 모델을 설정해요",
        "what": (
            "AI 기능(ask, patch --ai 등)을 사용하려면 API 키가 필요해요.\n"
            "이 명령어로 Anthropic(Claude) 또는 Gemini API 키를 설정할 수 있어요.\n"
            "즉, 현재 지원하는 모델은 Claude와 Gemini예요."
        ),
        "when": [
            "처음 설치하고 AI 기능을 쓰려고 할 때",
            "API 키를 바꾸고 싶을 때",
        ],
        "examples": [
            ("vib config", "API 키 설정 시작"),
        ],
        "options": [],
    },
    "secrets": {
        "emoji": "🚫",
        "title": "vib secrets",
        "one_line": "API 키 같은 비밀정보가 Git에 올라가기 전에 막아요",
        "what": (
            "커밋하기 전에 지금 올리려는 내용을 검사해서\n"
            "API 키, 토큰, 개인키, .env 같은 비밀정보가 들어갔는지 확인해줘요.\n"
            "쉽게 말하면 '실수로 중요한 비밀번호를 인터넷에 올리기 전에 막아주는 문지기'예요.\n\n"
            "보통은 `vib start`를 하면 자동으로 연결돼서 따로 신경 쓸 일이 거의 없어요.\n"
            "직접 확인하고 싶을 때만 `vib secrets --staged`를 실행하면 돼요.\n"
            "자동 hook을 켜면 이제 비밀정보 검사뿐 아니라 `vib guard --strict`도 함께 돌아가요."
        ),
        "when": [
            "API 키나 .env를 실수로 커밋할 파일 목록에 넣은 것 같을 때",
            "커밋 전에 한 번 더 확인하고 싶을 때",
            "왜 커밋이 막혔는지 이해하고 싶을 때",
        ],
        "examples": [
            ("vib secrets --staged", "지금 커밋하려는 내용에 비밀정보가 있는지 검사"),
            ("vib secrets --install-hook", "앞으로 커밋할 때마다 자동 검사되게 켜기"),
            ("vib secrets --uninstall-hook", "자동 검사 끄기"),
        ],
        "options": [
            (
                "--staged",
                "지금 커밋할 내용만 검사해요.\n한 번만 직접 확인하고 싶을 때 쓰면 돼요.",
            ),
            (
                "--install-hook",
                "커밋 버튼을 누를 때마다 자동 검사되게 켜요.\n보통은 vib start가 자동으로 해줘요.\n이제 secrets 검사와 strict guard 검사가 같이 돌아가요.",
            ),
            (
                "--uninstall-hook",
                "커밋할 때마다 돌던 자동 검사를 꺼요.",
            ),
            (
                "오탐 예외 처리",
                "진짜 비밀정보가 아닌데도 막히면 그 줄 끝에 `vibelign: allow-secret`를 붙여서 예외 처리할 수 있어요.",
            ),
        ],
    },
    "claude-hook": {
        "emoji": "🪝",
        "title": "vib claude-hook",
        "one_line": "Claude PreToolUse 검사 on/off 상태를 관리해요",
        "what": (
            "Claude Code가 파일을 쓰기 전에 VibeLign 검사를 거치게 만드는 스위치예요.\n"
            "쉽게 말하면 'Claude가 저장 버튼 누르기 전에 한 번 더 확인하는 문지기'예요.\n"
            "이 명령어로 지금 켜져 있는지 보고, 켜고, 끌 수 있어요."
        ),
        "when": [
            "Claude Code에서 PreToolUse 검사가 켜져 있는지 확인하고 싶을 때",
            "Claude가 쓰기 전에 planning/anchor 검사를 하게 만들고 싶을 때",
            "잠깐 검사만 끄고 싶을 때",
        ],
        "examples": [
            ("vib claude-hook status", "현재 상태 보기"),
            ("vib claude-hook enable", "검사 켜기"),
            ("vib claude-hook disable", "검사 끄기"),
        ],
        "options": [
            ("status", "지금 켜져 있는지, 설정 파일이 준비됐는지 보여줘요."),
            (
                "enable",
                "Claude가 Write 도구를 쓰기 전에 VibeLign pre-check를 실행하게 해요.",
            ),
            ("disable", "검사는 끄지만 hook 엔트리는 남겨둬서 다시 켜기 쉽게 해요."),
        ],
    },
    "plan-structure": {
        "emoji": "🧱",
        "title": "vib plan-structure",
        "one_line": "코딩 전에 어느 파일을 바꿀지 구조 계획을 만들어요",
        "what": (
            "기능 설명을 바탕으로 어느 파일은 수정하고 어느 파일은 새로 만들어야 하는지 먼저 계획해요.\n"
            "쉽게 말하면 '코딩 시작 전에 설계도 한 장 먼저 만드는 버튼'이에요.\n"
            "계획은 `.vibelign/plans/` 아래에 저장되고, guard나 pre-check가 이 계획을 보고 검사할 수 있어요.\n\n"
            "보통은 '계획 먼저 → 구현 → guard로 확인' 순서로 쓰면 돼요.\n"
            "예를 들어 새 로그인 기능처럼 파일 여러 개가 같이 바뀌는 작업이면,\n"
            "바로 코드를 쓰기 전에 이 명령어로 파일 배치를 먼저 정하는 거예요."
        ),
        "when": [
            "새 기능을 추가해서 파일이 여러 개 바뀔 것 같을 때",
            "새 production 파일을 만들기 전에 어디에 둘지 정하고 싶을 때",
            "AI가 큰 기능을 한 파일에 몰아넣지 않게 막고 싶을 때",
            "작은 단일 파일 수정이 아니라 작업 범위가 헷갈릴 때",
        ],
        "examples": [
            ('vib plan-structure "OAuth 인증 추가"', "기본 구조 계획 만들기"),
            ('vib plan-structure "watch 기능 확장"', "가장 쉬운 기본 사용법"),
            (
                'vib plan-structure --scope vibelign/core/ "watch 기능 확장"',
                "특정 폴더만 보고 계획 만들기",
            ),
            ('vib plan-structure --ai "mcp handler 수정"', "AI 계획 메타데이터로 기록"),
            (
                'vib plan-structure "OAuth 인증 추가" → vib patch "OAuth 로그인 버튼과 서버 검증 추가" → vib guard --strict',
                "추천 흐름 예시",
            ),
        ],
        "options": [
            (
                "feature",
                '무엇을 만들지 말로 적어요.\n예: vib plan-structure "로그인 기능 추가"',
            ),
            ("--scope", "분석할 폴더를 좁혀요.\n예: --scope vibelign/core/"),
            ("--ai", "나중에 AI 흐름에서 참고할 plan metadata로 기록해요."),
            (
                "언제 안 써도 되나요?",
                "문서만 고치거나, 테스트만 조금 손보거나, 설정 파일만 바꾸는 작은 작업이면 보통 없어도 돼요.",
            ),
        ],
    },
    "export": {
        "emoji": "📤",
        "title": "vib export",
        "one_line": "Claude, Cursor 등 AI 도구에 맞는 설정 파일을 만들어요",
        "what": (
            "Claude Code, Cursor, OpenCode 같은 AI 도구에서\n"
            "VibeLign을 연동해서 쓸 수 있도록 설정 파일을 만들어줘요."
        ),
        "when": [
            "Claude Code를 쓰면서 VibeLign도 같이 쓰고 싶을 때",
            "Cursor에서 VibeLign 설정을 적용하고 싶을 때",
        ],
        "examples": [
            ("vib export claude", "Claude Code용 설정 파일 생성"),
            ("vib export cursor", "Cursor용 설정 파일 생성"),
            ("vib export opencode", "OpenCode용 설정 파일 생성"),
        ],
        "options": [
            (
                "tool",
                "어떤 AI 도구용인지 선택해요.\n선택지: claude / opencode / cursor / antigravity",
            ),
        ],
    },
    "transfer": {
        "emoji": "🔄",
        "title": "vib transfer",
        "one_line": "AI 툴을 바꿀 때 맥락 파일을 만들어요",
        "what": (
            "AI한테 코딩을 시키다 보면 대화창이 꽉 차거나\n"
            "다른 AI 툴로 바꿔야 할 때가 있어요.\n"
            "그럴 때 새 AI한테 '지금까지 뭘 했는지, 다음에 뭘 해야 하는지'\n"
            "한 번에 알려주는 파일을 만들어줘요.\n"
            "\n"
            "만들어지는 파일: PROJECT_CONTEXT.md\n"
            "\n"
            "--handoff 옵션을 쓰면 맨 위에 'Session Handoff' 블록이 생겨요.\n"
            "새 AI는 이 블록만 읽어도 바로 이어서 작업할 수 있어요."
        ),
        "when": [
            "AI 대화창이 꽉 차서 새 채팅을 열어야 할 때",
            "Claude → Cursor 같이 AI 툴을 바꾸기 직전에",
            "다른 사람에게 프로젝트를 넘길 때",
            "새 AI 채팅에 프로젝트 설명을 자동으로 전달하고 싶을 때",
        ],
        "examples": [
            ("vib transfer", "기본 생성 (PROJECT_CONTEXT.md 만들기)"),
            ("vib transfer --compact", "가벼운 버전 (토큰 절약)"),
            ("vib transfer --full", "파일 트리를 더 깊이 포함"),
            ("vib transfer --handoff", "AI 전환용 인수인계 블록 포함"),
            ("vib transfer --handoff --print", "인수인계 내용을 화면에도 출력"),
            ("vib transfer --handoff --no-prompt", "질문 없이 자동으로 만들기"),
            (
                'vib transfer --handoff --session-summary "현재 세션 작업"',
                "현재 세션 요약을 직접 넣기",
            ),
            (
                'vib transfer --handoff --first-next-action "다음 할 일"',
                "새 AI가 먼저 할 일을 직접 넣기",
            ),
            (
                'vib transfer --handoff --verification "pytest 53 passed"',
                "검증 결과를 직접 넣기",
            ),
            (
                'vib transfer --handoff --decision "git 상태를 기준으로 삼기"',
                "다음 AI가 볼 결정사항 저장하기",
            ),
            ("vib transfer --handoff --dry-run", "저장 없이 내용 미리 보기"),
            ("vib transfer --out ctx.md", "파일 이름 바꾸기"),
        ],
        "options": [
            (
                "--compact",
                "파일 크기를 줄여서 토큰을 아껴요.\n파일 트리를 얕게만 보여줘요 (깊이 2단계).\n무료 플랜이나 토큰이 부족할 때 좋아요.",
            ),
            (
                "--full",
                "파일 트리를 더 깊이까지 보여줘요 (깊이 4단계).\n프로젝트가 복잡하거나 AI한테 더 많은 구조를 알려주고 싶을 때 써요.",
            ),
            (
                "--handoff",
                "AI를 바꾸거나 새 채팅을 열기 직전에 쓰는 옵션이에요.\n파일 맨 위에 'Session Handoff' 블록을 넣어줘요.\n새 AI한테 '오늘 뭘 했는지, 다음에 뭘 해야 하는지' 한 줄로 알려줄 수 있어요.\n⚠️ --compact, --full 과 같이 쓸 수 없어요.",
            ),
            (
                "--print",
                "--handoff 와 함께 써요.\n인수인계 내용을 파일에 저장하면서 화면에도 바로 출력해줘요.\n새 AI 채팅창에 복붙하기 편해요.",
            ),
            (
                "--no-prompt",
                "--handoff 와 함께 써요.\n보통은 '다음 AI가 뭘 해야 해?' 하고 물어보는데\n이 옵션을 쓰면 아무것도 안 물어보고 자동으로 만들어줘요.\n모르는 내용은 '(not provided)' 라고 표시돼요.",
            ),
            (
                "--session-summary 텍스트",
                "--handoff 와 함께 써요.\n현재 세션에서 한 일을 직접 한 줄로 넣고 싶을 때 써요.\n자동 요약보다 사용자가 쓴 문장을 우선해서 Session Handoff에 넣어요.",
            ),
            (
                "--first-next-action 텍스트",
                "--handoff 와 함께 써요.\n새 AI가 제일 먼저 해야 할 일을 직접 지정해요.\n예: --first-next-action \"실패한 테스트부터 다시 실행\"",
            ),
            (
                "--verification 텍스트",
                "--handoff 와 함께 써요.\n테스트나 빌드 검증 결과를 직접 기록해요.\n여러 번 써서 pytest, build 같은 결과를 각각 남길 수 있어요.",
            ),
            (
                "--decision 텍스트",
                "--handoff 와 함께 써요.\n이번 세션에서 정한 중요한 방향이나 선택을 work_memory decisions에 저장해요.\n여러 번 써서 결정사항을 각각 남길 수 있어요.",
            ),
            (
                "--out 파일명",
                "저장할 파일 이름을 바꿀 수 있어요.\n기본값은 PROJECT_CONTEXT.md예요.\n예: --out handoff.md",
            ),
            (
                "--dry-run",
                "파일을 실제로 저장하지 않고 '이런 내용이 들어갈 거예요'를 미리 보여줘요.\n마치 게임에서 아이템 설명 읽고 살지 말지 결정하는 것처럼,\nhandoff 내용을 확인하고 나서 진짜로 실행할 수 있어요.\n--handoff 와 함께 쓰는 게 가장 유용해요.",
            ),
            (
                "--help",
                "transfer 명령어의 옵션 목록을 보여줘요.\n뭘 써야 할지 모를 때 먼저 확인해보세요.",
            ),
        ],
        "notes": [
            "Cursor처럼 MCP를 지원하는 AI 툴이 컨텍스트를 요청하면,\n     VibeLign이 파일을 새로 만들지 않고 저장된 PROJECT_CONTEXT.md를 그대로 전달해요.\n     그래서 handoff 블록이 날아가지 않아요.",
            "--handoff 실행 후 vib checkpoint를 돌리면 handoff 블록이 사라져요.\n     그럴 때 경고가 뜨니까, AI 전환 직전에 --handoff를 다시 실행하면 돼요.",
            "--handoff를 실행하면 AGENTS.md에 규칙이 자동으로 추가돼요:\n     '새 채팅 열면 PROJECT_CONTEXT.md 먼저 읽어라'\n     Cursor, Antigravity, OpenCode 등 AGENTS.md를 읽는 AI 툴이 자동으로 인지해요.",
        ],
    },
    "memory": {
        "emoji": "🧠",
        "title": "vib memory",
        "one_line": "지금 하던 일과 다음 할 일을 작업 메모리에 저장해요",
        "what": (
            "세션 메모리는 AI가 다음에 이어받을 때 보는 작업 메모장이에요.\n"
            "지금 목표가 뭔지, 다음에 뭘 해야 하는지, 어떤 파일이 중요한지,\n"
            "테스트를 돌렸는지 같은 걸 `.vibelign/work_memory.json`에 정리해요.\n\n"
            "쉽게 말하면 '다음 AI한테 남기는 인수인계 메모'예요.\n"
            "`vib transfer --handoff`를 실행하면 이 메모를 읽어서 PROJECT_CONTEXT.md에 같이 반영해줘요.\n\n"
            "proposal-create는 AI가 메모 초안을 제안하는 기능이고,\n"
            "proposal-accept를 해야만 진짜 메모에 저장돼요.\n"
            "그래서 AI가 멋대로 기록하지 않고, 사람이 검토한 내용만 남게 돼요."
        ),
        "when": [
            "지금 하던 일을 다음 AI가 바로 이어받게 하고 싶을 때",
            "중요한 결정이나 다음 할 일을 잊지 않게 남기고 싶을 때",
            "AI 이동 전에 work_memory.json 내용을 점검하고 싶을 때",
            "AI가 제안한 handoff 메모를 검토하고 수락/거절하고 싶을 때",
        ],
        "examples": [
            ("vib memory show", "현재 저장된 작업 메모리 보기"),
            ("vib memory show --json", "앱이나 자동화가 읽기 좋은 JSON으로 보기"),
            ("vib memory review", "handoff 전에 빠진 메모리가 없는지 검토"),
            ('vib memory intent "현재 목표"', "지금 작업 목표를 직접 저장"),
            ('vib memory decide "git 상태를 source of truth로 유지"', "중요한 결정을 저장"),
            ('vib memory next "실패한 테스트 다시 실행"', "다음 할 일을 저장"),
            ('vib memory relevant src/app.py "핵심 파일"', "중요한 파일과 이유를 저장"),
            ('vib memory proposal-create --first-next-action "다음 할 일"', "AI handoff 메모 초안 만들기"),
            ("vib memory proposal-accept --field next_action --draft-json '{...}'", "검토한 제안을 수락해서 저장"),
        ],
        "options": [
            (
                "show --json",
                "세션 메모리를 JSON으로 보여줘요.\nGUI나 자동화 스크립트가 읽을 때 좋아요.",
            ),
            (
                "intent 텍스트",
                "지금 목표를 확정해서 저장해요.\n다음 AI가 '지금 뭘 하는 중이었는지' 바로 알 수 있어요.",
            ),
            (
                "decide 텍스트",
                "중요한 결정을 저장해요.\n예: 'git 상태를 기준으로 삼기' 같은 방향을 남길 때 써요.",
            ),
            (
                "next 텍스트",
                "다음 할 일을 저장해요.\n예: '실패한 테스트 다시 실행'처럼 바로 행동으로 옮길 문장을 남겨요.",
            ),
            (
                "relevant 파일 이유",
                "왜 이 파일이 중요한지 같이 저장해요.\n핵심 파일을 handoff에 노출할 때 좋아요.",
            ),
            (
                "proposal-create",
                "AI가 handoff 메모 초안을 제안해요.\n`--session-summary`, `--first-next-action`, `--relevant-file`, `--verification`, `--risk-note`를 붙여 제안 내용을 채울 수 있어요.",
            ),
            (
                "proposal-accept --field --draft-json",
                "검토한 제안 한 항목을 수락해서 진짜 work_memory.json에 저장해요.",
            ),
            (
                "proposal-dismiss --field --draft-json",
                "제안을 거절해요.\n원본 메모리는 그대로 두고, 같은 제안을 계속 반복하지 않게 도와줘요.",
            ),
            (
                "proposal-undo --proposal-hash",
                "방금 수락한 제안을 다시 되돌려요.\n잘못 저장했을 때 '수락 취소'처럼 쓸 수 있어요.",
            ),
        ],
    },
    "recover": {
        "emoji": "↺",
        "title": "vib recover",
        "one_line": "되돌리기 전에 안전한 복구 후보를 먼저 보여줘요",
        "what": (
            "recover는 바로 파일을 바꾸기 전에 '어떻게 되돌리는 게 안전한지' 먼저 보여주는 기능이에요.\n"
            "지금 상태를 읽어서 복구 계획, 후보 checkpoint, 검토할 파일을 먼저 보여줘요.\n\n"
            "쉽게 말하면 '실행 전 미리 보는 복구 안내판'이에요.\n"
            "그래서 성급하게 되돌리기 전에 어느 시점이 가장 안전한지 확인할 수 있어요.\n\n"
            "특히 '언제부터 망가졌는지' 기억나는 경우\n"
            "`--recommend --phrase`로 복구 후보를 추천받는 게 편해요."
        ),
        "when": [
            "AI가 코드를 이상하게 바꿔서 어디로 돌아가야 할지 애매할 때",
            "바로 undo 하기 전에 안전한 checkpoint 후보를 먼저 보고 싶을 때",
            "문제가 생긴 시점을 대충 기억해서 복구 후보를 추천받고 싶을 때",
        ],
        "examples": [
            ("vib recover --explain", "복구 옵션이 뭔지 글로 설명 보기"),
            ("vib recover --preview", "읽기 전용 복구 계획 미리보기"),
            ("vib recover --recommend --phrase 'GUI broke 30m ago'", "문제 시점 기준 후보 추천"),
            ("vib recover --file src/app.py", "특정 파일 기준으로 복구 대상 미리보기"),
        ],
        "options": [
            (
                "--preview",
                "지금 상태를 읽어서 복구 계획만 미리 보여줘요.\nPhase 1에서는 파일을 바꾸지 않아요.",
            ),
            (
                "--recommend --phrase 텍스트",
                "'GUI broke 30m ago' 같은 문장을 바탕으로\n가장 그럴듯한 복구 후보를 순서대로 추천해줘요.",
            ),
            (
                "--file 경로",
                "특정 파일을 기준으로 복구 대상을 좁혀서 볼 때 써요.",
            ),
            (
                "--json",
                "복구 계획을 JSON으로 출력해요.\nGUI나 자동화 스크립트가 읽을 때 좋아요.",
            ),
            (
                "--apply",
                "명시적으로 확인된 파일 복구를 실제로 실행해요.\n실행 전 checkpoint 정보와 confirmation 문구가 필요해요.",
            ),
        ],
    },
    "completion": {
        "emoji": "⌨️",
        "title": "vib completion",
        "one_line": "탭키로 명령어를 자동완성해요",
        "what": (
            "vib + 탭키를 누르면 명령어 목록이 뜨게 해줘요.\n"
            '"vib pr" 치고 탭 누르면 "vib protect"가 자동완성돼요.\n'
            "macOS/Linux (zsh/bash)와 Windows (PowerShell) 모두 지원해요."
        ),
        "when": [
            "처음 설치하고 탭 자동완성을 설정하고 싶을 때 (딱 한 번만 하면 돼요)",
            "명령어 이름이 기억 안 날 때",
        ],
        "examples": [
            ("vib completion --install", "자동완성 자동 설정 (추천!)"),
            ("vib completion", "설정 방법 안내 보기"),
        ],
        "options": [
            (
                "--install",
                "자동완성을 자동으로 설정해줘요.\nzsh/bash/PowerShell을 자동으로 감지해요.\n새 터미널을 열면 바로 사용할 수 있어요.",
            ),
        ],
    },
    "init": {
        "emoji": "🔄",
        "title": "vib init",
        "one_line": "VibeLign을 최신 버전으로 다시 설치해요",
        "what": (
            "VibeLign을 최신 버전으로 재설치해요.\n"
            "업데이트가 있을 때, 또는 뭔가 이상할 때 쓰세요.\n"
            "uv 또는 pip을 자동으로 감지해서 설치해요."
        ),
        "when": [
            "VibeLign 업데이트를 하고 싶을 때",
            "설치가 꼬인 것 같을 때 다시 설치하고 싶을 때",
        ],
        "examples": [
            ("vib init", "최신 버전으로 재설치"),
            ("vib init --force", "강제로 다시 설치"),
        ],
        "options": [
            ("--force", "이미 최신 버전이어도 강제로 다시 설치해요."),
        ],
    },
    "install": {
        "emoji": "📦",
        "title": "vib install",
        "one_line": "단계별 설치 방법을 안내해줘요",
        "what": (
            "VibeLign을 처음 설치하는 방법을 단계별로 안내해줘요.\n"
            "터미널 여는 법부터 uv 설치, vibelign 설치까지 모두 설명해요."
        ),
        "when": [
            "처음 설치하는데 어떻게 해야 할지 모를 때",
            "설치 방법을 다시 확인하고 싶을 때",
        ],
        "examples": [
            ("vib install", "설치 방법 안내 보기"),
        ],
        "options": [],
    },
    "manual": {
        "emoji": "📖",
        "title": "vib manual",
        "one_line": "코알못을 위한 상세 사용 설명서",
        "what": (
            "VibeLign의 모든 명령어를 쉬운 말로 설명하는 내장 사용 설명서예요.\n"
            "명령어별로 언제 쓰는지, 예시, 옵션을 한 화면에서 확인할 수 있어요."
        ),
        "when": [
            "어떤 vib 명령어를 써야 할지 모를 때",
            "특정 명령어의 예시와 옵션을 자세히 보고 싶을 때",
            "전체 매뉴얼을 파일로 저장해 공유하고 싶을 때",
        ],
        "examples": [
            ("vib manual", "전체 명령어 목록 보기"),
            ("vib manual checkpoint", "checkpoint 명령 자세히 보기"),
            ("vib manual --all", "전체 상세 설명 보기"),
            ("vib manual --save", "VIBELIGN_MANUAL.md 파일로 저장"),
        ],
        "options": [
            ("command_name", "자세히 볼 커맨드 이름이에요. 예: checkpoint, anchor, guard"),
            ("--all", "전체 커맨드의 상세 설명을 모두 보여줘요."),
            ("--save", "전체 매뉴얼을 VIBELIGN_MANUAL.md 파일로 저장해요."),
            ("--json", "매뉴얼 데이터를 JSON으로 출력해요."),
        ],
    },
    "rules": {
        "emoji": "📋",
        "title": "VibeLign AI 개발 규칙",
        "one_line": "AI가 코드를 작성할 때 반드시 지켜야 할 규칙들이에요",
        "what": (
            "vib start를 실행하면 프로젝트에 AI_DEV_SYSTEM_SINGLE_FILE.md 파일이 생겨요.\n"
            "이 파일이 AI한테 '이렇게 코딩해야 해'를 알려주는 규칙서예요.\n"
            "Claude Code, OpenCode, Cursor 등 어떤 AI를 써도 이 규칙을 읽고 따라요.\n\n"
            "━━ 핵심 원칙 ━━\n\n"
            "🔹 패치 우선 원칙\n"
            "  AI는 파일 전체를 다시 쓰지 않아요.\n"
            "  꼭 필요한 부분만 최소한으로 수정해요.\n"
            "  관련 없는 파일은 절대 건드리지 않아요.\n\n"
            "🔹 VibeLign patch 규칙\n"
            "  복합 요청은 intent / source / destination / behavior_constraint 로 먼저 분해해요.\n"
            "  삭제와 이동이 같이 나오면, 기능 삭제가 아니라 이동 + 보존인지 먼저 확인해요.\n"
            "  source 와 destination 은 같은 규칙으로 처리하지 말고 역할별로 따로 해석해요.\n"
            "  patch contract 나 codespeak 구조가 바뀌면 테스트와 문서도 같이 갱신해요.\n"
            "  용어는 공통 문서와 glossary 기준으로 맞춰요.\n\n"
            "━━ 두 가지 수정 방식 ━━\n\n"
            "방식 1 — 일반 수정 (기본)\n"
            "  평소처럼 말하면 AI가 알아서 수정해요.\n"
            "  예: '로그인 버튼 색 파란색으로 바꿔줘'\n\n"
            "방식 2 — 바이브라인 안전 수정 ('바이브라인으로' 또는 'vibelign')\n"
            "  요청에 '바이브라인으로'를 붙이면 전체 안전 워크플로우 자동 실행:\n"
            "  patch_get → 정확한 위치 확인 → 수정 → guard_check → checkpoint 저장\n"
            "  예: '바이브라인으로 로그인 버튼 색 파란색으로 바꿔줘'\n\n"
            "  ⚠️  '바이브라인으로' 없으면 → AI가 직접 수정 (VibeLign 툴 사용 안 함)\n\n"
            "━━ 파일 구조 규칙 ━━\n\n"
            "🔹 진입 파일 보호 (main.py, index.js 등)\n"
            "  진입 파일은 작게 유지해요. 실제 로직은 별도 파일로 분리해요.\n\n"
            "🔹 UI와 비즈니스 로직 분리\n"
            "  UI 파일: 화면 레이아웃, 버튼, 입력창만\n"
            "  로직 파일: 실제 처리, 파일 읽기/쓰기, 네트워크\n"
            "  두 가지를 한 파일에 섞으면 안 돼요.\n\n"
            "🔹 파일 크기 관리\n"
            "  파일이 커지면 역할별로 나눠요.\n"
            "  utils.py, helpers.py, misc.py 같은 모호한 이름 금지.\n"
            "  대신: backup_worker.py, translation_pipeline.py처럼 구체적으로 지어요.\n\n"
            "━━ 함수 설계 규칙 ━━\n\n"
            "🔹 함수 길이\n"
            "  함수가 40줄 넘으면 → 분리 고려\n"
            "  함수가 80줄 넘으면 → 반드시 분리\n"
            "  한 함수는 딱 한 가지 일만 해요.\n\n"
            "🔹 함수 이름\n"
            "  좋은 예: load_config(), parse_excel_row(), validate_input_path()\n"
            "  나쁜 예: do_stuff(), process(), handle(), run_all()\n\n"
            "🔹 파일 간 연결\n"
            "  순환 import 금지 (A가 B를 부르고, B가 다시 A를 부르는 구조)\n"
            "  공통 로직은 별도 파일로 분리해서 양쪽에서 가져다 써요.\n\n"
            "━━ 유지보수 규칙 (코알못도 관리할 수 있게) ━━\n\n"
            "🔹 매직 넘버 금지\n"
            "  나쁜 예: if retry > 3\n"
            "  좋은 예: MAX_RETRY = 3 / if retry > MAX_RETRY\n\n"
            "🔹 에러 메시지는 사람이 읽을 수 있게\n"
            "  나쁜 예: raise Exception('NoneType')\n"
            "  좋은 예: raise Exception('파일을 찾을 수 없어요. 경로를 확인하세요')\n\n"
            "🔹 조용한 실패 금지\n"
            "  except: pass 절대 금지\n"
            "  에러가 나면 반드시 화면에 표시해요.\n\n"
            "🔹 죽은 코드 제거\n"
            "  주석 처리된 코드 덩어리 남기지 않아요.\n"
            "  쓰지 않는 import, 변수, 함수 삭제해요.\n\n"
            "🔹 의존성 동기화\n"
            "  새 패키지를 추가하면 pyproject.toml도 함께 업데이트해요.\n\n"
            "🔹 주석도 함께 업데이트\n"
            "  코드를 바꾸면 위에 있는 설명 주석도 같이 바꿔요.\n"
            "  오래된 주석은 없는 것보다 더 혼란스러워요.\n\n"
            "━━ 앵커 규칙 ━━\n\n"
            "🔹 앵커(ANCHOR)가 있으면 그 안에서만 수정\n"
            "  앵커를 무시하고 파일 전체를 바꾸면 안 돼요.\n"
            "  앵커가 없는 큰 파일은 먼저 앵커를 달고 작업해요.\n\n"
            "🔹 앵커를 허락 없이 지우면 안 돼요"
        ),
        "when": [
            "AI가 내 규칙을 제대로 따르고 있는지 확인하고 싶을 때",
            "'바이브라인으로' 키워드를 언제 써야 하는지 헷갈릴 때",
            "AI가 이상하게 코딩할 때 어떤 규칙이 있는지 확인할 때",
            "내 프로젝트 규칙을 처음부터 다시 보고 싶을 때",
        ],
        "examples": [
            ("vib manual rules", "전체 규칙 보기"),
            ("vib start", "프로젝트에 규칙 파일(AI_DEV_SYSTEM_SINGLE_FILE.md) 생성"),
            ("cat AI_DEV_SYSTEM_SINGLE_FILE.md", "규칙 파일 직접 보기"),
        ],
        "options": [
            (
                "규칙 파일 위치",
                "AI_DEV_SYSTEM_SINGLE_FILE.md — 프로젝트 루트에 생성돼요",
            ),
            (
                "규칙 업데이트",
                "vib start 재실행하면 최신 규칙으로 덮어써요 (기존 파일은 .md~ 백업)",
            ),
            (
                "어떤 AI든 적용",
                "AGENTS.md를 읽는 Claude Code, OpenCode, Cursor 모두 자동 적용",
            ),
        ],
    },
    "mcp": {
        "emoji": "🤖",
        "title": "MCP (AI 자동 연동)",
        "one_line": "AI가 VibeLign 기능을 자동으로 써요",
        "what": (
            "보통은 AI한테 '체크포인트 저장해줘'라고 말하면\n"
            "AI가 명령어를 알려주고, 여러분이 직접 터미널에서 쳐야 해요.\n\n"
            "MCP가 연결되면 달라져요.\n"
            "AI한테 말하면 AI가 직접 VibeLign을 실행해요.\n"
            "터미널을 따로 열 필요가 없어요.\n\n"
            "설정: vib start 실행 → Claude Code 재시작 (딱 한 번만)\n\n"
            "추가로 `vib start --all-tools`를 쓰면 여러 도구를 한 번에 준비할 수 있어요.\n"
            "현재 안내 기준으로는 Claude, Antigravity, OpenCode는 바로 사용 가능으로 보여주고,\n"
            "Cursor, Codex는 마지막 연결 확인이 한 번 더 필요할 수 있어요.\n\n"
            "쉽게 생각하면:\n"
            "  Claude        → 거의 바로 됨\n"
            "  Antigravity   → 사용자 경험상 바로 되는 경우가 많음\n"
            "  OpenCode      → 프로젝트 설정 파일까지 함께 준비 가능\n"
            "  Cursor/Codex  → 규칙 파일은 준비되지만 마지막 연결 확인이 필요할 수 있음\n\n"
            "━━ 두 가지 수정 방식 ━━\n\n"
            "방식 1 — 일반 수정 (기본)\n"
            "  평소처럼 말하면 AI가 알아서 수정해요.\n"
            "  예: '로그인 버튼 색 파란색으로 바꿔줘'\n\n"
            "방식 2 — 바이브라인 안전 수정 (키워드: '바이브라인으로')\n"
            "  요청 앞에 '바이브라인으로'를 붙이면 전체 안전 워크플로우 자동 실행:\n"
            "  patch_get → 정확한 위치 확인 → 수정 → guard_check → checkpoint 저장\n"
            "  예: '바이브라인으로 로그인 버튼 색 파란색으로 바꿔줘'\n\n"
            "━━ 사용 가능한 MCP 도구 ━━\n"
            "  checkpoint_create   — 체크포인트 저장   (vib checkpoint 와 같아요)\n"
            "  checkpoint_list     — 저장 목록 보기    (vib history 와 같아요)\n"
            "  checkpoint_restore  — 특정 시점 복원    (vib undo 와 같아요)\n"
            "\n"
            "  ⚠️  복원할 때는 '바이브라인 언두해줘'라고 말하면 돼요.\n"
            "     AI가 목록을 먼저 보여주고 → 번호를 고르면 → 자동으로 복원해요.\n"
            "     ('vib undo'를 직접 실행하면 MCP 환경에서 멈춰요. AI한테 맡기세요!)\n\n"
            "  project_context_get — AI 전환 시 컨텍스트 전달 (vib transfer 와 같아요)\n"
            "  doctor_run          — 건강 진단         (vib doctor 와 같아요)\n"
            "  guard_check         — AI 작업 후 확인   (vib guard 와 같아요)\n"
            "  protect_add         — 파일 보호 등록    (vib protect 와 같아요)\n"
            "  patch_get           — 자연어→CodeSpeak 번역 + 수정 위치 특정 (vib patch 와 같아요)\n"
            "  anchor_run          — 앵커 자동 삽입    (vib anchor --auto 와 같아요)\n"
            "  anchor_list         — 앵커 목록 보기\n"
            "  explain_get         — 변경 내역 분석    (vib explain 와 같아요)\n"
            "  config_get          — 현재 설정 확인"
        ),
        "when": [
            "Claude Code와 VibeLign을 함께 쓸 때",
            "Antigravity나 OpenCode도 같이 준비하고 싶을 때",
            "매번 터미널에서 명령어 치기 귀찮을 때",
            "AI가 작업 전후를 자동으로 관리해주길 원할 때",
            "어느 파일을 건드려야 할지 애매한 수정을 안전하게 하고 싶을 때",
        ],
        "examples": [
            ("vib start --all-tools", "여러 AI 도구를 한 번에 준비"),
            ('"저장해줘"', "checkpoint_create 호출"),
            ('"저장된 목록 보여줘"', "checkpoint_list 호출"),
            (
                '"바이브라인 언두해줘"',
                "목록 보여줌 → 번호 선택 → checkpoint_restore 자동 호출",
            ),
            ('"3번으로 복원해줘"', "checkpoint_restore 바로 호출"),
            (
                '"바이브라인으로 로그인 버튼 크기 키워줘"',
                "patch_get → 수정 → guard_check → checkpoint 자동 실행",
            ),
            (
                '"바이브라인으로 다크모드 배경색 바꿔줘"',
                "안전 수정 전체 워크플로우 자동 실행",
            ),
            ('"프로젝트 상태 진단해줘"', "doctor_run 호출"),
            ('"방금 수정한 거 문제없는지 확인해줘"', "guard_check 호출"),
            ('"앵커 없는 파일에 앵커 삽입해줘"', "anchor_run 호출"),
        ],
        "options": [
            ("설정 방법", "vib start 한 번 실행 → Claude Code 재시작"),
            (
                "여러 도구 한 번에 준비",
                "vib start --all-tools\nClaude, Antigravity, OpenCode, Cursor, Codex 준비를 한 번에 시도해요.",
            ),
            (
                "바로 사용 가능",
                "현재 start 안내 기준으로 Claude, Antigravity, OpenCode는 바로 사용 가능으로 보여줘요.",
            ),
            (
                "마지막 확인 필요",
                "Cursor, Codex는 설정 화면이나 설정 파일에서 VibeLign 연결을 한 번 더 확인해야 할 수 있어요.",
            ),
            (
                "'바이브라인으로' 키워드",
                "요청 앞에 붙이면 안전 수정 모드. 로직·기능 변경 시 권장",
            ),
            ("일반 수정", "단순 텍스트 변경, 오타 수정은 그냥 말해도 돼요"),
            (
                "복원은 시점 지정 필수",
                "'되돌려줘'만 하면 AI가 목록을 먼저 보여줘요. 번호나 메시지를 함께 말하세요",
            ),
            (
                "한 번에 여러 요청 가능",
                "'저장하고, 앵커 확인하고, 작업 시작해줘' → AI가 순서대로 자동 처리",
            ),
        ],
    },
}

# 그룹 순서
GROUPS = [
    ("🏁 처음 시작", ["start", "init", "install"]),
    (
        "💾 세이브 & 되돌리기",
        ["checkpoint", "undo", "history", "recover", "backup-db-viewer", "backup-graph-summary", "backup-db-maintenance", "backup-cleanup"],
    ),
    ("🔬 점검 & 확인", ["doctor", "guard", "explain"]),
    ("✏️ AI 수정 요청", ["patch", "anchor", "scan", "plan-structure"]),
    ("📚 문서 보기 & 다시생성", ["docs-build", "docs-enhance", "docs-index", "doc-sources"]),
    (
        "🗂️ 파일 & 설정",
        [
            "protect",
            "transfer",
            "memory",
            "ask",
            "show",
            "config",
            "secrets",
            "export",
            "watch",
            "bench",
            "claude-hook",
            "completion",
        ],
    ),
    ("🤖 MCP (AI 자동 연동)", ["mcp"]),
    ("📋 AI 개발 규칙", ["manual", "rules"]),
]


# ──────────────────────────────────────────────
# 렌더링
# ──────────────────────────────────────────────


def _render_command(key: str) -> None:
    """단일 커맨드 상세 매뉴얼 출력."""
    m = MANUAL.get(key)
    if not m:
        console.print(f"[red]'{key}' 커맨드를 찾을 수 없어요.[/red]")
        console.print("사용 가능한 커맨드: " + ", ".join(MANUAL.keys()))
        return

    emoji = m.get("emoji", "")
    title = m.get("title", key)
    one_line = m.get("one_line", "")
    what = m.get("what", "")
    when = m.get("when", [])
    examples = m.get("examples", [])
    options = m.get("options", [])
    notes = m.get("notes", [])

    if not has_rich:
        print()
        print(f"{emoji} {title} — {one_line}".strip())
        print()
        print("이게 뭐야?")
        print(what)
        if when:
            print()
            print("언제 써?")
            for item in when:
                print(f"- {item}")
        if examples:
            print()
            print("이렇게 쳐봐")
            for cmd, desc in examples:
                print(f"- {cmd}  # {desc}")
        if options:
            print()
            print("옵션 설명")
            for opt, desc in options:
                print(f"- {opt}: {desc.replace(chr(10), ' ')}")
        if notes:
            print()
            print("알아두면 좋은 것")
            for note in notes:
                print(f"- {note}")
        print()
        return

    assert Text is not None
    assert Panel is not None
    assert Table is not None
    assert box is not None

    # 헤더 패널
    header = Text()
    _ = header.append(f"{emoji}  ", style="bold")
    _ = header.append(title, style="bold cyan")
    _ = header.append(f"  —  {one_line}", style="dim white")
    console.print(Panel(header, border_style="cyan", padding=(0, 2)))

    # 이게 뭐야?
    console.print()
    console.print("  [bold yellow]💡 이게 뭐야?[/bold yellow]")
    for line in what.splitlines():
        console.print(f"     [white]{line}[/white]")

    # 언제 써?
    if when:
        console.print()
        console.print("  [bold green]🕐 언제 써?[/bold green]")
        for w in when:
            console.print(f"     [dim]•[/dim]  {w}")

    # 이렇게 쳐봐 (MCP는 AI한테 말하는 방식)
    if examples:
        console.print()
        label = "💬  AI한테 이렇게 말해봐" if key == "mcp" else "✏️  이렇게 쳐봐"
        console.print(f"  [bold magenta]{label}[/bold magenta]")
        tbl = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        tbl.add_column(style="bold cyan", no_wrap=True)
        tbl.add_column(style="dim white")
        for cmd, desc in examples:
            tbl.add_row(cmd, f"→  {desc}")
        console.print(tbl)

    # 옵션 설명
    if options:
        console.print()
        console.print("  [bold blue]⚙️  옵션 설명[/bold blue]")
        tbl = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        tbl.add_column(style="bold cyan", no_wrap=True, width=24)
        tbl.add_column(style="white")
        for opt, desc in options:
            tbl.add_row(opt, desc)
        console.print(tbl)

    # 알아두면 좋은 것
    if notes:
        console.print()
        console.print("  [bold yellow]📝 알아두면 좋은 것[/bold yellow]")
        for note in notes:
            console.print(f"     [dim]•[/dim]  {note}")

    console.print()


def _render_overview() -> None:
    """전체 커맨드 목록 개요 출력."""
    if not has_rich:
        print()
        print("VibeLign 전체 명령어 매뉴얼")
        print("상세 보기: vib manual <커맨드명>")
        print()
        for group_name, keys in GROUPS:
            print(group_name)
            for k in keys:
                m = MANUAL[k]
                print(f"- {k}: {m.get('one_line', '')}")
            print()
        return

    assert Text is not None
    assert Panel is not None
    assert Table is not None
    assert box is not None

    console.print()
    console.print(
        Panel(
            Text("VibeLign 전체 명령어 매뉴얼", style="bold white", justify="center"),
            subtitle="[dim]vib manual <커맨드명>  →  상세 보기[/dim]",
            border_style="bright_blue",
            padding=(0, 4),
        )
    )
    console.print()

    for group_name, keys in GROUPS:
        tbl = Table(
            title=group_name,
            box=box.ROUNDED,
            border_style="dim",
            title_style="bold white",
            show_header=False,
            padding=(0, 2),
            expand=False,
        )
        tbl.add_column(style="bold cyan", no_wrap=True, width=14)
        tbl.add_column(style="dim white", width=10)
        tbl.add_column(style="white")
        for k in keys:
            m = MANUAL[k]
            tbl.add_row(
                k,
                m.get("emoji", ""),
                m.get("one_line", ""),
            )
        console.print(tbl)
        console.print()

    console.print("[dim]  상세 보기:  vib manual checkpoint[/dim]")
    console.print("[dim]  파일 저장:  vib manual --save[/dim]")
    console.print()


def _render_all() -> None:
    """모든 커맨드 상세 출력 (--save용 또는 전체 보기)."""
    _render_overview()
    console.print()
    for group_name, keys in GROUPS:
        console.rule(f"[bold dim]{group_name}[/bold dim]")
        console.print()
        for k in keys:
            _render_command(k)


def _save_markdown() -> str:
    """마크다운 매뉴얼 생성 후 파일 저장."""
    lines = [
        "# VibeLign 사용 설명서\n",
        "> AI한테 코딩 시켜도 안전하게 지켜주는 도구 — 코알못을 위한 매뉴얼\n\n",
        "---\n\n",
        "## 목차\n\n",
    ]
    for group_name, keys in GROUPS:
        lines.append(f"### {group_name}\n")
        for k in keys:
            m = MANUAL[k]
            emoji = m.get("emoji", "")
            one_line = m.get("one_line", "")
            lines.append(f"- [{emoji} `vib {k}`](#{k}) — {one_line}\n")
        lines.append("\n")

    lines.append("---\n\n")

    for group_name, keys in GROUPS:
        lines.append(f"## {group_name}\n\n")
        for k in keys:
            m = MANUAL[k]
            emoji = m.get("emoji", "")
            title = m.get("title", f"vib {k}")
            one_line = m.get("one_line", "")
            what = m.get("what", "")
            when = m.get("when", [])
            examples = m.get("examples", [])
            options = m.get("options", [])
            lines.append(f"### {emoji} `{title}`\n\n")
            lines.append(f"> {one_line}\n\n")
            lines.append(f"**💡 이게 뭐야?**\n\n{what}\n\n")
            if when:
                lines.append("**🕐 언제 써?**\n\n")
                for w in when:
                    lines.append(f"- {w}\n")
                lines.append("\n")
            if examples:
                lines.append("**✏️ 이렇게 쳐봐**\n\n```\n")
                for cmd, desc in examples:
                    lines.append(f"{cmd}   # {desc}\n")
                lines.append("```\n\n")
            if options:
                lines.append("**⚙️ 옵션 설명**\n\n")
                lines.append("| 옵션 | 설명 |\n|------|------|\n")
                for opt, desc in options:
                    desc_inline = desc.replace("\n", " ")
                    lines.append(f"| `{opt}` | {desc_inline} |\n")
                lines.append("\n")
            lines.append("---\n\n")

    content = "".join(lines)
    save_path = "VIBELIGN_MANUAL.md"
    with open(save_path, "w", encoding="utf-8") as f:
        _ = f.write(content)
    return save_path


# ──────────────────────────────────────────────
# 진입점
# ──────────────────────────────────────────────


def run_vib_manual(args: ManualArgs | Namespace) -> None:
    command_value = getattr(args, "command_name", None)
    command = command_value if isinstance(command_value, str) else None
    save = bool(getattr(args, "save", False))
    all_flag = bool(getattr(args, "all", False))
    json_flag = bool(getattr(args, "json", False))

    if save:
        path = _save_markdown()
        console.print(
            f"\n[bold green]✅ 매뉴얼을 저장했어요![/bold green]  →  [cyan]{path}[/cyan]"
        )
        console.print(
            "[dim]이 파일을 AI한테 보여주면 VibeLign에 대해 더 잘 도와줄 수 있어요.[/dim]\n"
        )
        return

    if json_flag:
        if command:
            payload = MANUAL.get(command, {})
        elif all_flag:
            payload = MANUAL
        else:
            payload = MANUAL
        print(json.dumps(payload, ensure_ascii=False))
        return

    if command:
        _render_command(command)
    elif all_flag:
        _render_all()
    else:
        _render_overview()


# === ANCHOR: VIB_MANUAL_CMD_END ===
