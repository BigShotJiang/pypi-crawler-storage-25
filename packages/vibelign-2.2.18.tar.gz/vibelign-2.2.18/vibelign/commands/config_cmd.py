# === ANCHOR: CONFIG_CMD_START ===
from argparse import Namespace
import os
import json
import getpass
import sys
import urllib.request
from pathlib import Path
from typing import Protocol, TypedDict, cast


from vibelign.terminal_render import (
    clack_error,
    clack_info,
    clack_intro,
    clack_outro,
    clack_step,
    clack_success,
    clack_warn,
    cli_print,
)

print = cli_print

_DEFAULT_GEMINI_MODEL = "gemini-3-flash-preview"
_GEMINI_MODEL_FALLBACKS = [
    "gemini-2.5-flash",
    "gemini-2.5-flash-lite",
    "gemini-3-flash-preview",
    "gemini-3.1-flash-lite-preview",
    "gemini-3.1-pro-preview",
]
_CLEAR_GEMINI_MODEL = "__CLEAR_GEMINI_MODEL__"


class ProviderInfo(TypedDict):
    id: str
    label: str
    key_name: str
    url: str


class GeminiModelInfo(TypedDict, total=False):
    name: str
    supportedGenerationMethods: list[str]


class GeminiModelsResponse(TypedDict, total=False):
    models: list[GeminiModelInfo]


class ResponseLike(Protocol):
    def __enter__(self) -> "ResponseLike": ...
    def __exit__(self, exc_type: object, exc: object, tb: object) -> object: ...
    def read(self) -> bytes: ...


_PROVIDERS: list[ProviderInfo] = [
    {
        "id": "anthropic",
        "label": "Anthropic (Claude)",
        "key_name": "ANTHROPIC_API_KEY",
        "url": "https://console.anthropic.com",
    },
    {
        "id": "openai",
        "label": "OpenAI (GPT)",
        "key_name": "OPENAI_API_KEY",
        "url": "https://platform.openai.com/api-keys",
    },
    {
        "id": "gemini",
        "label": "Gemini (Google)",
        "key_name": "GEMINI_API_KEY",
        "url": "https://aistudio.google.com",
    },
    {
        "id": "glm",
        "label": "GLM (Zhipu AI)",
        "key_name": "GLM_API_KEY",
        "url": "https://open.bigmodel.cn",
    },
    {
        "id": "kimi",
        "label": "Kimi (Moonshot AI)",
        "key_name": "MOONSHOT_API_KEY",
        "url": "https://platform.moonshot.cn",
    },
]


# === ANCHOR: CONFIG_CMD__GET_SHELL_PROFILE_START ===
def _get_shell_profile() -> Path:
    shell = os.environ.get("SHELL", "")
    if "zsh" in shell:
        return Path("~/.zshrc").expanduser()
    if "bash" in shell:
        profile = Path("~/.bash_profile").expanduser()
        return profile if profile.exists() else Path("~/.bashrc").expanduser()
    return Path("~/.zshrc").expanduser()


# === ANCHOR: CONFIG_CMD__GET_SHELL_PROFILE_END ===


# === ANCHOR: CONFIG_CMD__SAVE_TO_PROFILE_START ===
def _save_to_profile(key_name: str, api_key: str) -> None:
    """키 파일에 저장 (플랫폼 무관)."""
    from vibelign.core.keys_store import save_key
    save_key(key_name, api_key)


# === ANCHOR: CONFIG_CMD__SAVE_TO_PROFILE_END ===


# === ANCHOR: CONFIG_CMD__FETCH_GEMINI_MODELS_START ===
def _fetch_gemini_models(api_key: str) -> list[str]:
    import ssl
    try:
        import certifi
        ctx: ssl.SSLContext | None = ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        ctx = None
    url = f"https://generativelanguage.googleapis.com/v1beta/models?key={api_key}"
    req = urllib.request.Request(url, method="GET")
    response = cast(ResponseLike, urllib.request.urlopen(req, timeout=20, context=ctx))
    with response:
        payload_bytes = response.read()
        payload = payload_bytes.decode("utf-8")
        result = cast(GeminiModelsResponse, json.loads(payload))

    models: list[str] = []
    for item in result.get("models", []):
        name = item.get("name", "")
        methods = item.get("supportedGenerationMethods", [])
        if not name.startswith("models/gemini-"):
            continue
        if "generateContent" not in methods:
            continue
        model = name.split("/", 1)[1]
        if any(
            token in model for token in ["image", "embedding", "tts", "aqa", "live"]
        ):
            continue
        models.append(model)

    ordered: list[str] = []
    seen: set[str] = set()
    for model in _GEMINI_MODEL_FALLBACKS + sorted(models):
        if model not in seen and model in models:
            ordered.append(model)
            seen.add(model)
    return ordered


# === ANCHOR: CONFIG_CMD__FETCH_GEMINI_MODELS_END ===


# === ANCHOR: CONFIG_CMD__RUN_DELETE_KEY_START ===
def _run_delete_key() -> None:
    from vibelign.core.keys_store import delete_key, is_key_disabled, load_keys
    all_keys = [p["key_name"] for p in _PROVIDERS] + ["GEMINI_MODEL"]
    stored = load_keys()
    env_only_keys = [
        k for k in all_keys if os.environ.get(k) and not stored.get(k) and not is_key_disabled(k)
    ]
    set_keys = [k for k in all_keys if stored.get(k)] + env_only_keys
    if not set_keys:
        clack_warn("삭제할 키가 없습니다.")
        return
    clack_step("삭제할 키를 선택하세요")
    for i, k in enumerate(set_keys, 1):
        source = "환경 변수 감지" if k in env_only_keys else "GUI/CLI 저장"
        print(f"  {i}. {k} ({source})")
    print(f"  {len(set_keys) + 1}. 전체 삭제")
    print("  0. 취소")
    print()
    choice = input(f"선택 (0-{len(set_keys) + 1}): ").strip()
    if choice == "0" or not choice:
        clack_warn("취소했습니다.")
        return
    try:
        choice_num = int(choice)
    except ValueError:
        clack_error("잘못된 선택입니다.")
        return
    if choice_num == len(set_keys) + 1:
        to_delete = set_keys
    elif 1 <= choice_num <= len(set_keys):
        to_delete = [set_keys[choice_num - 1]]
    else:
        clack_error("잘못된 선택입니다.")
        return
    for k in to_delete:
        delete_key(k)
        clack_success(f"{k} 삭제됨")
# === ANCHOR: CONFIG_CMD__RUN_DELETE_KEY_END ===


# === ANCHOR: CONFIG_CMD__SELECT_GEMINI_MODEL_START ===
def _select_gemini_model(api_key: str | None, current_model: str) -> str | None:
    clack_step("Gemini 모델 설정 (선택사항)")
    if current_model:
        clack_info(f"현재 GEMINI_MODEL: {current_model}")
    else:
        clack_info(f"현재 GEMINI_MODEL: 기본값 사용 ({_DEFAULT_GEMINI_MODEL})")

    models: list[str] = []
    source_label = "기본 추천 목록"
    if api_key:
        try:
            models = _fetch_gemini_models(api_key)
            if models:
                source_label = "Google AI Studio 공식 사용 가능 모델"
            else:
                clack_warn(
                    "Google AI Studio 모델 목록이 비어 있어 기본 추천 목록을 보여줍니다."
                )
        except Exception:
            models = []
            clack_warn(
                "Google AI Studio 모델 목록을 가져오지 못해 기본 추천 목록을 보여줍니다."
            )

    if not models:
        models = list(_GEMINI_MODEL_FALLBACKS)

    clack_info(f"모델 목록: {source_label}")
    for i, model in enumerate(models, 1):
        note = ""
        if model == _DEFAULT_GEMINI_MODEL:
            note = " (기본값)"
        elif model == current_model:
            note = " (현재값)"
        print(f"  {i}. {model}{note}")
    print(f"  {len(models) + 1}. 직접 입력")
    clear_choice = None
    if current_model:
        clear_choice = len(models) + 2
        print(f"  {clear_choice}. 설정 해제 (기본값 사용)")
    print("  0. 변경 안 함")
    print()

    max_choice = clear_choice or (len(models) + 1)
    choice = input(f"선택 (0-{max_choice}): ").strip()
    if choice == "0" or not choice:
        return None
    if choice.isdigit():
        choice_num = int(choice)
        if 1 <= choice_num <= len(models):
            return models[choice_num - 1]
        if choice_num == len(models) + 1:
            custom_model = input("Gemini 모델 ID를 입력하세요: ").strip()
            return custom_model or None
        if clear_choice and choice_num == clear_choice:
            return _CLEAR_GEMINI_MODEL

    clack_warn("잘못된 선택입니다. Gemini 모델 설정을 건너뜁니다.")
    return None


# === ANCHOR: CONFIG_CMD__SELECT_GEMINI_MODEL_END ===


# === ANCHOR: CONFIG_CMD__RUN_AI_ENHANCE_START ===
def _run_ai_enhance(action: str, json_mode: bool) -> None:
    """`.vibelign/config.yaml` 의 `ai_enhancement` 플래그를 조회/토글한다."""
    from vibelign.core.hook_setup import (
        is_ai_enhancement_enabled,
        set_ai_enhancement_enabled,
    )
    from vibelign.core.project_root import resolve_project_root

    root = resolve_project_root(Path.cwd())
    msg: str | None
    if action == "enable":
        set_ai_enhancement_enabled(root, True)
        enabled = True
        msg = "AI 앵커 intent 자동 보강을 켰어요."
    elif action == "disable":
        set_ai_enhancement_enabled(root, False)
        enabled = False
        msg = "AI 앵커 intent 자동 보강을 껐어요."
    else:
        enabled = is_ai_enhancement_enabled(root)
        msg = None

    if json_mode:
        _ = sys.stdout.write(
            json.dumps(
                {
                    "ok": True,
                    "error": None,
                    "data": {"ai_enhancement": enabled, "action": action},
                },
                ensure_ascii=False,
            )
            + "\n"
        )
        return
    if msg:
        clack_success(msg)
    clack_info(f"ai_enhancement: {'true' if enabled else 'false'}")
# === ANCHOR: CONFIG_CMD__RUN_AI_ENHANCE_END ===


def _run_auto_backup(action: str, json_mode: bool) -> None:
    from vibelign.core.checkpoint_engine.auto_backup import (
        is_auto_backup_enabled,
        set_auto_backup_enabled,
    )
    from vibelign.core.project_root import resolve_project_root

    root = resolve_project_root(Path.cwd())
    if action == "on":
        set_auto_backup_enabled(root, True)
        enabled = True
        msg = "커밋 후 자동 저장을 켰어요."
    elif action == "off":
        set_auto_backup_enabled(root, False)
        enabled = False
        msg = "커밋 후 자동 저장을 껐어요."
    else:
        enabled = is_auto_backup_enabled(root)
        msg = None

    if json_mode:
        _ = sys.stdout.write(
            json.dumps(
                {
                    "ok": True,
                    "error": None,
                    "data": {"auto_backup_on_commit": enabled, "action": action},
                },
                ensure_ascii=False,
            )
            + "\n"
        )
        return
    if msg:
        clack_success(msg)
    clack_info(f"auto_backup_on_commit: {'true' if enabled else 'false'}")


# === ANCHOR: CONFIG_CMD_RUN_CONFIG_START ===
def run_config(_args: Namespace) -> None:
    ai_enhance_action = getattr(_args, "ai_enhance", None)
    if ai_enhance_action:
        _run_ai_enhance(str(ai_enhance_action), bool(getattr(_args, "json", False)))
        return

    config_args = getattr(_args, "config_args", [])
    config_parts = cast(list[object], config_args) if isinstance(config_args, list) else []
    if config_parts:
        if len(config_parts) == 2 and config_parts[0] == "auto-backup":
            action = str(config_parts[1]).lower()
            if action in {"on", "off", "status"}:
                _run_auto_backup(action, bool(getattr(_args, "json", False)))
                return
        clack_error("사용법: vib config auto-backup on|off|status")
        return

    clack_intro("VibeLign API 키 설정")

    # 무료 API 안내
    from vibelign.core.keys_store import get_key, has_any_ai_key, is_key_disabled, keys_file_path, load_keys
    if not has_any_ai_key():
        clack_info("AI 기능을 쓰려면 API 키가 하나 이상 필요해요.")
        clack_info("무료로 시작하려면 Google AI Studio에서 Gemini 키를 받으세요:")
        clack_info("  https://aistudio.google.com/apikey")
        clack_info("  (Google 계정만 있으면 무료로 바로 발급돼요)")
        print()

    # 현재 상태 표시
    clack_step("현재 상태")
    stored_keys = load_keys()
    for p in _PROVIDERS:
        key_name = p["key_name"]
        from_file = bool(stored_keys.get(key_name))
        disabled = is_key_disabled(key_name)
        from_env = bool(os.environ.get(key_name)) and not disabled
        if from_file and from_env:
            status = "✓ 설정됨 (GUI/CLI 저장 + 환경 변수)"
        elif from_file:
            status = "✓ 설정됨 (GUI/CLI 저장)"
        elif from_env:
            status = "✓ 외부 환경 변수에서 감지됨"
        elif disabled:
            status = "✗ 없음 (VibeLign에서 삭제됨)"
        else:
            status = "✗ 없음"
        clack_info(f"{p['key_name']:<22}: {status}")
    gemini_model = (get_key("GEMINI_MODEL") or "").strip()
    if gemini_model:
        model_status = f"✓ 사용자 설정 ({gemini_model})"
    else:
        model_status = f"기본값 사용 ({_DEFAULT_GEMINI_MODEL})"
    clack_info(f"{'GEMINI_MODEL':<22}: {model_status}")

    # 제공자 선택
    delete_choice = len(_PROVIDERS) + 2
    clack_step("설정할 AI 서비스를 선택하세요")
    for i, p in enumerate(_PROVIDERS, 1):
        print(f"  {i}. {p['label']:<22} ({p['url']})")
    print(f"  {len(_PROVIDERS) + 1}. 전체")
    print(f"  {delete_choice}. 키 삭제")
    print("  0. 취소")
    print()

    choice = input(f"선택 (0-{delete_choice}): ").strip()

    if choice == "0" or not choice:
        clack_warn("취소했습니다.")
        return

    try:
        choice_num = int(choice)
    except ValueError:
        clack_error("잘못된 선택입니다.")
        return

    if choice_num == delete_choice:
        _run_delete_key()
        return
    elif choice_num == len(_PROVIDERS) + 1:
        selected = _PROVIDERS
    elif 1 <= choice_num <= len(_PROVIDERS):
        selected = [_PROVIDERS[choice_num - 1]]
    else:
        clack_error("잘못된 선택입니다.")
        return

    includes_gemini = any(p["id"] == "gemini" for p in selected)

    # API 키 입력
    print()
    collected: dict[str, str] = {}
    for p in selected:
        api_key = getpass.getpass(
            f"{p['label']} API 키를 입력하세요 (입력 내용은 표시되지 않습니다): "
        ).strip()
        if not api_key:
            clack_warn(f"{p['label']} 키 입력을 건너뜁니다.")
            continue
        collected[p["key_name"]] = api_key

    if includes_gemini:
        print()
        gemini_api_key = (
            collected.get("GEMINI_API_KEY") or get_key("GEMINI_API_KEY") or ""
        ).strip()
        gemini_model = _select_gemini_model(gemini_api_key, gemini_model)
        if gemini_model == _CLEAR_GEMINI_MODEL:
            collected["GEMINI_MODEL"] = ""
        elif gemini_model is not None:
            collected["GEMINI_MODEL"] = gemini_model

    if not collected:
        clack_warn("설정할 값이 없습니다.")
        return

    # 영구/임시 선택
    keys_path = keys_file_path()
    print()
    clack_step("저장 방식을 선택하세요")
    print(f"  1. 영구 저장 ({keys_path} 에 저장, GUI·터미널 모두 즉시 반영)")
    print("  2. 취소 (임시 저장은 키 노출 위험 때문에 지원하지 않아요)")
    print()

    save_choice = input("선택 (1/2): ").strip()
    print()

    if save_choice == "1":
        for key_name, api_key in collected.items():
            _save_to_profile(key_name, api_key)
            clack_success(f"{key_name} → {keys_path} 에 저장됨")
        print()
        clack_info("새 터미널·GUI 재시작 없이 즉시 적용됩니다.")
    elif save_choice == "2":
        clack_warn("API 키가 터미널 기록이나 화면 공유에 노출될 수 있어 임시 저장 명령 출력은 중단했어요.")
        clack_info("키를 쓰려면 1번 영구 저장을 선택하세요. 키 파일은 사용자 설정 폴더에 저장되고 레포에는 커밋되지 않습니다.")
        return
    else:
        clack_error("잘못된 선택입니다.")
        return

    clack_outro("설정 완료")
    clack_info("이제 'vib ask 파일명'을 실행하면 AI가 바로 설명합니다.")


# === ANCHOR: CONFIG_CMD_RUN_CONFIG_END ===
# === ANCHOR: CONFIG_CMD_END ===
