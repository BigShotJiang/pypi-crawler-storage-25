#!/usr/bin/env python3
"""
hoopoe - Play videos and webcam as colorful ASCII art in your terminal
"""

import sys
import argparse
import time
import os
import tty
import termios
import threading
import subprocess
import datetime
import collections
import signal

import cv2
import numpy as np

CHAR_MODES = {
    "classic": " .:-=+*#%@",
    "blocks":  " ░▒▓█",
    "braille": " ⠁⠃⠇⠿⣿",
    "minimal": " ·•●■",
    "solid":   " ",
}

ANSI_16_PALETTE = [
    #   R    G    B   fg   bg
    (  0,   0,   0,  30,  40),
    (170,   0,   0,  31,  41),
    (  0, 170,   0,  32,  42),
    (170, 170,   0,  33,  43),
    (  0,   0, 170,  34,  44),
    (170,   0, 170,  35,  45),
    (  0, 170, 170,  36,  46),
    (170, 170, 170,  37,  47),
    ( 85,  85,  85,  90, 100),
    (255,  85,  85,  91, 101),
    ( 85, 255,  85,  92, 102),
    (255, 255,  85,  93, 103),
    ( 85,  85, 255,  94, 104),
    (255,  85, 255,  95, 105),
    ( 85, 255, 255,  96, 106),
    (255, 255, 255,  97, 107),
]


def nearest_ansi16(r, g, b):
    best = min(ANSI_16_PALETTE, key=lambda c: (c[0]-r)**2 + (c[1]-g)**2 + (c[2]-b)**2)
    return best[3], best[4]


def _rgb_to_lab(r, g, b):
    r, g, b = r / 255.0, g / 255.0, b / 255.0
    r = ((r + 0.055) / 1.055) ** 2.4 if r > 0.04045 else r / 12.92
    g = ((g + 0.055) / 1.055) ** 2.4 if g > 0.04045 else g / 12.92
    b = ((b + 0.055) / 1.055) ** 2.4 if b > 0.04045 else b / 12.92
    x = (r * 0.4124564 + g * 0.3575761 + b * 0.1804375) / 0.95047
    y = (r * 0.2126729 + g * 0.7151522 + b * 0.0721750) / 1.00000
    z = (r * 0.0193339 + g * 0.1191920 + b * 0.9503041) / 1.08883
    def f(t): return t ** (1/3) if t > 0.008856 else 7.787 * t + 16 / 116
    return 116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))


_ANSI_16_LAB = [_rgb_to_lab(c[0], c[1], c[2]) for c in ANSI_16_PALETTE]


def nearest_ansi16_lab(r, g, b):
    L, a, b_ = _rgb_to_lab(r, g, b)
    idx = min(range(16), key=lambda i: (
        (_ANSI_16_LAB[i][0] - L) ** 2 +
        (_ANSI_16_LAB[i][1] - a) ** 2 +
        (_ANSI_16_LAB[i][2] - b_) ** 2
    ))
    return ANSI_16_PALETTE[idx][3], ANSI_16_PALETTE[idx][4]


def get_terminal_size():
    size = os.get_terminal_size()
    return size.columns, size.lines


def get_ansi(r, g, b, character=" ", bg=False, legacy_color=False, no_color=False):
    """Returns an ANSI escape sequence based on specified parameters."""

    if no_color:
        return character
    if legacy_color:
        fg_code, bg_code = nearest_ansi16_lab(r, g, b) if legacy_color == "lab" else nearest_ansi16(r, g, b)
        if bg:
            return f"\033[{bg_code}m\033[30m{character}\033[0m"
        return f"\033[{fg_code}m{character}\033[0m"
    if bg:
        return f"\033[48;2;{r};{g};{b}m\033[38;2;0;0;0m{character}\033[0m"
    return f"\033[38;2;{r};{g};{b}m{character}\033[0m"


def frame_to_lines(frame, width, height, mode, invert=False, flip=None, highlight=False,
                   legacy_color=False, no_color=False):
    """Convert a frame to a list of strings, one per terminal row."""

    chars = CHAR_MODES.get(mode, CHAR_MODES["classic"])
    n_chars = len(chars)

    if flip == "h":
        frame = cv2.flip(frame, 1)
    elif flip == "v":
        frame = cv2.flip(frame, 0)
    elif flip == "hv":
        frame = cv2.flip(frame, -1)

    frame_resized = cv2.resize(frame, (width, height))
    gray = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2GRAY).astype(np.float32)

    if invert:
        gray = 255.0 - gray

    indices = (gray / 255.0 * (n_chars - 1)).astype(np.int32).clip(0, n_chars - 1)
    char_array = np.array(list(chars), dtype=object)[indices]

    r_arr = frame_resized[:, :, 2].astype(np.int32)
    g_arr = frame_resized[:, :, 1].astype(np.int32)
    b_arr = frame_resized[:, :, 0].astype(np.int32)

    lines = []
    for y in range(height):
        row = []
        r_row = r_arr[y]
        g_row = g_arr[y]
        b_row = b_arr[y]
        ch_row = char_array[y]

        for x in range(width):
            ansi = get_ansi(r_row[x], g_row[x], b_row[x], ch_row[x],
                            highlight or mode == "solid", legacy_color, no_color)
            row.append(ansi)
        lines.append("".join(row))

    return lines


def render_frame(lines, hud_line=None):
    """Paint the entire terminal in one write."""

    buf = "\033[H"
    for line in lines:
        buf += line + "\033[K\r\n"
    if hud_line is not None:
        buf += "\033[7m" + hud_line + "\033[0m\033[K"
    sys.stdout.write(buf)
    sys.stdout.flush()


def write_frame_to_file(f, lines, hud_line=None):
    """Append a rendered frame to an open output file."""

    f.write("#FRAME\n")
    for line in lines:
        f.write(line + "\033[K\r\n")
    if hud_line is not None:
        f.write("\033[7m" + hud_line + "\033[0m\033[K\r\n")


def save_screenshot(lines, hud_line=None):
    """Save current frame as ANSI colored text file (.ans)."""

    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"hoopoe_screenshot_{ts}.ans"
    with open(filename, "w", encoding="utf-8") as f:
        for line in lines:
            f.write(line + "\033[K\n")
        if hud_line is not None:
            f.write("\033[7m" + hud_line + "\033[0m\033[K\n")
    return filename


def resolve_output_path(output):
    """Resolves --output argument to a concrete .ans file path."""

    if output is None:
        return None
    output = os.path.expanduser(output)
    if os.path.isdir(output):
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        return os.path.join(output, f"hoopoe_output_{ts}.ans")
    if not output.endswith(".ans"):
        output += ".ans"
    parent = os.path.dirname(output)
    if parent and not os.path.exists(parent):
        print(f"Error: output directory does not exist: {parent}")
        sys.exit(1)
    return output


QUALITY_MAP = {"low": 144, "medium": 360, "high": 480}


def get_video_capture(source, local=False, quality="high"):
    if local:
        if not os.path.exists(source):
            print(f"File not found: {source}")
            sys.exit(1)
        return cv2.VideoCapture(source), os.path.basename(source), False
    try:
        import yt_dlp
    except ImportError:
        print("yt-dlp not installed. Run: pip install yt-dlp")
        sys.exit(1)
    print("hoopoe-player - fetching video info...")
    height = QUALITY_MAP.get(quality, 480)
    ydl_opts = {"format": f"best[height<={height}]", "quiet": True,
                "js_runtimes": {"node": {}}, "remote_components": {"ejs:github"}}
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(source, download=False)
        is_live = bool(info.get("is_live", False))
        return cv2.VideoCapture(info["url"]), info.get("title", "Unknown"), is_live


def get_audio_info(source, local=False):
    """Returns (url, is_live, is_hls) for the best audio stream."""

    if local:
        return source, False, False
    try:
        import yt_dlp
        opts = {"format": "bestaudio/best", "quiet": True,
                "js_runtimes": {"node": {}}, "remote_components": {"ejs:github"}}
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(source, download=False)
            is_live = bool(info.get("is_live", False))
            url = info.get("url", "")
            protocol = info.get("protocol", "")
            is_hls = (protocol in ("m3u8", "m3u8_native", "dash")
                      or url.endswith(".m3u8") or "manifest" in url.lower())
            return url, is_live, is_hls
    except Exception:
        return None, False, False


class AudioPlayer:
    def __init__(self, url, is_live=False, is_hls=False):
        self.url = url
        self.volume = 50
        self.is_live = is_live
        self.is_hls = is_hls
        self._proc = None
        self._paused = False
        self._lock = threading.Lock()

    def start(self, offset=0):
        self._kill()
        self._paused = False
        cmd = ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet",
               "-volume", str(self.volume)]

        if self.is_live or self.is_hls:
            cmd += ["-fflags", "nobuffer",
                    "-flags", "low_delay",
                    "-framedrop",
                    "-analyzeduration", "500000",
                    "-probesize", "500000"]
        elif offset > 0:
            cmd += ["-ss", str(offset)]

        cmd.append(self.url)
        with self._lock:
            self._proc = subprocess.Popen(
                cmd,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

    def _kill(self):
        with self._lock:
            if self._proc:
                try:
                    self._proc.send_signal(signal.SIGCONT)
                except Exception:
                    pass
                self._proc.terminate()
                try:
                    self._proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    self._proc.kill()
                self._proc = None
        self._paused = False

    def pause(self):
        with self._lock:
            if self._proc and not self._paused:
                try:
                    self._proc.send_signal(signal.SIGSTOP)
                    self._paused = True
                except Exception:
                    pass

    def resume(self):
        with self._lock:
            if self._proc and self._paused:
                try:
                    self._proc.send_signal(signal.SIGCONT)
                    self._paused = False
                except Exception:
                    pass

    def stop(self):
        self._kill()

class KeyListener:
    def __init__(self):
        self.key = None
        self._stop = False
        self._fd = sys.stdin.fileno()
        self._old = termios.tcgetattr(self._fd)
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        tty.setraw(self._fd)
        while not self._stop:
            try:
                self.key = os.read(self._fd, 3)
            except Exception:
                break

    def stop(self):
        self._stop = True
        try:
            termios.tcsetattr(self._fd, termios.TCSADRAIN, self._old)
        except Exception:
            pass

    def pop(self):
        k, self.key = self.key, None
        return k


def format_time(secs):
    secs = max(0, int(secs))
    m, s = divmod(secs, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def make_hud(paused, cur_frame, total_frames, fps, volume, mode, has_sound, cols,
             is_live=False, loop=False, screenshot_msg=None, real_fps=None, sync=False,
             fps_limit=None, recording=False, legacy_color=False, no_color=False):
    elapsed       = format_time(cur_frame / fps)
    total         = "🔴LIVE" if is_live else (format_time(total_frames / fps) if total_frames else "--:--")
    state         = "⏸ PAUSE" if paused else "▶ PLAY"
    vol_str       = f" 🔊{volume}%" if has_sound else ""
    fps_limit_str = f" FPS limit: {fps_limit}" if fps_limit is not None else ""
    loop_str      = " 🔁" if loop else ""
    sync_str      = " 🔗SYNC" if sync else ""
    scr_str       = f" 📸{screenshot_msg}" if screenshot_msg else ""
    fps_str       = f" {real_fps:.1f}fps" if real_fps is not None else ""
    rec_str       = " REC" if recording else ""
    color_str     = f" LEGACY-{legacy_color.upper()}" if legacy_color else (" NOCOLOR" if no_color else "")
    bar = (f"  {state}  {elapsed}/{total}{fps_str}  [{mode}]{color_str}{fps_limit_str}{sync_str}{loop_str}{rec_str}{scr_str}"
           f"  P shot  Spc pause  Q quit  ")
    return bar[:cols].ljust(cols)


class FpsCounter:
    """Rolling average FPS over the last N frames."""

    def __init__(self, window=30):
        self._times = collections.deque(maxlen=window)

    def tick(self):
        self._times.append(time.monotonic())

    @property
    def fps(self):
        if len(self._times) < 2:
            return 0.0
        span = self._times[-1] - self._times[0]
        return (len(self._times) - 1) / span if span > 0 else 0.0


def make_webcam_hud(paused, mode, cols, screenshot_msg=None, real_fps=None, fps_limit=None,
                    recording=False, legacy_color=False, no_color=False):
    state     = "PAUSE" if paused else "PLAY"
    fps_str   = f" {real_fps:.1f}fps" if real_fps is not None else ""
    fps_limit_str = f" FPS limit: {fps_limit}" if fps_limit is not None else ""
    scr_str   = f" screenshot:{screenshot_msg}" if screenshot_msg else ""
    rec_str   = " REC" if recording else ""
    color_str = f" LEGACY-{legacy_color.upper()}" if legacy_color else (" NOCOLOR" if no_color else "")
    bar = (f"  {state}  WEBCAM{fps_str}  [{mode}]{color_str}{fps_limit_str}{rec_str}{scr_str}"
           f"  P shot  Spc pause  Q quit  ")
    return bar[:cols].ljust(cols)


def play_webcam(mode="classic", hud=False, camera=0, invert=False, flip=None, highlight=False,
                fps_limit=None, output=None, legacy_color=False, no_color=False):
    cap = cv2.VideoCapture(camera)
    if not cap.isOpened():
        print(f"Could not open camera {camera}.")
        sys.exit(1)

    video_fps = cap.get(cv2.CAP_PROP_FPS) or 30

    output_path = resolve_output_path(output)

    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()

    fps_limit_extra = ""
    if fps_limit is not None:
        fps_limit_extra = f" FPS limit: {fps_limit}"
    print(f"Webcam {camera} | Mode: {mode}{fps_limit_extra}")
    if output_path:
        print(f"Recording to: {output_path}")
    print("Controls: Space pause  P screenshot  Q quit")

    time.sleep(1)

    keys        = KeyListener()
    paused      = False
    cur_frame   = 0
    fps_counter = FpsCounter()

    last_render_time = time.monotonic()
    frame_time_limit = 1.0 / fps_limit if fps_limit else 0

    screenshot_msg       = None
    screenshot_msg_until = 0.0

    last_lines    = None
    last_hud_line = None
    last_cols, last_rows = get_terminal_size()

    sys.stdout.write("\033[?1049h\033[?25l\033[2J\033[H")
    sys.stdout.flush()

    if output_path:
        output_file = open(output_path, "w", encoding="utf-8")
        output_file.write(f"#HOOPOE fps={video_fps}\n")
    else:
        output_file = None

    try:
        while True:
            if not cap.isOpened():
                break

            # ── Key handling ──────────────────────────────────────────────────
            key = keys.pop()
            if key is not None:
                if key in (b'q', b'Q', b'\x03'):
                    break

                elif key == b' ':
                    paused = not paused

                elif key in (b'p', b'P'):
                    if last_lines:
                        fname = save_screenshot(last_lines, last_hud_line)
                        screenshot_msg       = os.path.basename(fname)
                        screenshot_msg_until = time.monotonic() + 3.0

            if screenshot_msg and time.monotonic() > screenshot_msg_until:
                screenshot_msg = None

            # ── Paused ────────────────────────────────────────────────────────
            if paused:
                cols, rows = get_terminal_size()
                resized = (cols, rows) != (last_cols, last_rows)
                if (resized or screenshot_msg is not None) and last_lines is not None:
                    if resized:
                        last_cols, last_rows = cols, rows
                        video_rows = rows - 1 if hud else rows
                        ret, frame = cap.read()
                        if ret:
                            last_lines = frame_to_lines(frame, cols, video_rows, mode, invert=invert, flip=flip, highlight=highlight,
                                                    legacy_color=legacy_color, no_color=no_color)
                    if hud:
                        last_hud_line = make_webcam_hud(
                            True, mode, cols, screenshot_msg, real_fps=None, fps_limit=fps_limit,
                            recording=output_file is not None, legacy_color=legacy_color, no_color=no_color)
                    render_frame(last_lines, last_hud_line)
                time.sleep(0.05)
                continue

            # ── Read & render ─────────────────────────────────────────────────
            t_frame_start = time.monotonic()

            ret, frame = cap.read()
            if not ret:
                break

            cur_frame += 1

            # ── FPS limitation frame drop ─────────────────────────────────────
            if time.monotonic() - last_render_time >= frame_time_limit:
                fps_counter.tick()

                cols, rows = get_terminal_size()
                last_cols, last_rows = cols, rows
                video_rows = rows - 1 if hud else rows

                last_lines = frame_to_lines(frame, cols, video_rows, mode, invert=invert, flip=flip, highlight=highlight,
                                            legacy_color=legacy_color, no_color=no_color)
                last_hud_line = None
                if hud:
                    last_hud_line = make_webcam_hud(
                        False, mode, cols, screenshot_msg, real_fps=fps_counter.fps,
                        fps_limit=fps_limit, recording=output_file is not None,
                        legacy_color=legacy_color, no_color=no_color)

                render_frame(last_lines, last_hud_line)
                if output_file:
                    write_frame_to_file(output_file, last_lines, last_hud_line)

                last_render_time = time.monotonic()

            render_ms = (time.monotonic() - t_frame_start) * 1000
            wait = (1.0 / video_fps) - render_ms / 1000
            if wait > 0:
                time.sleep(wait)

    except KeyboardInterrupt:
        pass
    finally:
        keys.stop()
        cap.release()
        if output_file:
            output_file.close()
            sys.stdout.write("\033[?25h\033[0m\033[2J\033[H\033[?1049l")
            sys.stdout.flush()
            print(f"hoopoe stopped. Output saved to: {output_path}")
        else:
            sys.stdout.write("\033[?25h\033[0m\033[2J\033[H\033[?1049l")
            sys.stdout.flush()
            print("hoopoe stopped. See you next time!")


def play_video(source, local=False, sound=False, mode="classic", hud=False,
               loop=False, sync=False, quality="medium", invert=False, highlight=False,
               fps_limit=None, output=None, legacy_color=False, no_color=False):
    try:
        cap, title, is_live = get_video_capture(source, local=local, quality=quality)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    video_fps    = cap.get(cv2.CAP_PROP_FPS) or 24
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    if fps_limit is not None and sound:
        sync = True

    output_path = resolve_output_path(output)

    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()

    print(f"Playing: {title}")

    extra = []
    if quality != "medium":   extra.append(f"Quality: {quality}")
    if sound:                 extra.append("Sound on")
    if is_live:               extra.append("Live stream")
    if loop:                  extra.append("Loop on")
    if sync:                  extra.append("Sync on")
    if fps_limit is not None: extra.append(f"FPS limit: {fps_limit}")
    if output_path:           extra.append(f"Recording to: {output_path}")

    print(f"Mode: {mode}" + ((" | " + " | ".join(extra)) if extra else ""))
    print("Controls: Space pause  P screenshot  Q quit")
    time.sleep(1)

    audio = None
    if sound:
        audio_url, audio_is_live, audio_is_hls = get_audio_info(source, local=local)
        if audio_url:
            if audio_is_live or audio_is_hls:
                print("Note: Live/HLS stream detected — using low-latency audio mode.")
                time.sleep(1)
            audio = AudioPlayer(audio_url, is_live=audio_is_live, is_hls=audio_is_hls)
            audio.start()
        else:
            print("Could not get audio stream.")
            time.sleep(2)

    keys      = KeyListener()
    paused    = False
    cur_frame = 0
    fps_counter = FpsCounter()

    last_render_ms = 1000.0 / (video_fps or 24)

    last_render_time = time.monotonic()
    frame_time_limit = 1.0 / fps_limit if fps_limit else 0

    audio_start_wall = time.monotonic()
    pause_wall       = 0.0

    screenshot_msg       = None
    screenshot_msg_until = 0.0

    last_lines    = None
    last_hud_line = None
    last_cols, last_rows = get_terminal_size()

    sys.stdout.write("\033[?1049h\033[?25l\033[2J\033[H")
    sys.stdout.flush()

    if output_path:
        output_file = open(output_path, "w", encoding="utf-8")
        output_file.write(f"#HOOPOE fps={video_fps}\n")
    else:
        output_file = None

    def reset_sync(frame_num, audio_offset=None):
        nonlocal audio_start_wall
        if audio and audio_offset is not None:
            audio.start(offset=audio_offset)
            audio_start_wall = time.monotonic() - audio_offset

    try:
        while True:
            if not cap.isOpened():
                break

            # ── Key handling ──────────────────────────────────────────────────
            key = keys.pop()
            if key is not None:
                if key in (b'q', b'Q', b'\x03'):
                    break

                elif key == b' ':
                    paused = not paused
                    if paused:
                        if audio: audio.pause()
                        pause_wall = time.monotonic()
                    else:
                        if audio: audio.resume()
                        audio_start_wall += time.monotonic() - pause_wall
                        reset_sync(cur_frame, audio_offset=None)

                elif key in (b'p', b'P'):
                    if last_lines:
                        fname = save_screenshot(last_lines, last_hud_line)
                        screenshot_msg       = os.path.basename(fname)
                        screenshot_msg_until = time.monotonic() + 3.0

            if screenshot_msg and time.monotonic() > screenshot_msg_until:
                screenshot_msg = None

            # ── Paused ────────────────────────────────────────────────────────
            if paused:
                cols, rows = get_terminal_size()
                resized = (cols, rows) != (last_cols, last_rows)
                if (resized or screenshot_msg is not None) and last_lines is not None:
                    if resized:
                        last_cols, last_rows = cols, rows
                        video_rows = rows - 1 if hud else rows
                        saved_pos = cur_frame
                        cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, saved_pos - 1))
                        ret, frame = cap.read()
                        cap.set(cv2.CAP_PROP_POS_FRAMES, saved_pos)
                        if ret:
                            last_lines = frame_to_lines(frame, cols, video_rows, mode, invert=invert, highlight=highlight,
                                                        legacy_color=legacy_color, no_color=no_color)
                    if hud:
                        vol = audio.volume if audio else 0
                        last_hud_line = make_hud(
                            True, cur_frame, total_frames, video_fps, vol, mode,
                            bool(audio), cols, is_live, loop, screenshot_msg,
                            None, sync, fps_limit, recording=output_file is not None,
                            legacy_color=legacy_color, no_color=no_color)
                    render_frame(last_lines, last_hud_line)
                time.sleep(0.05)
                continue

            # ── A/V sync: decide whether to drop this frame ───────────────────
            drop_frame = False
            if sync:
                audio_pos_s    = time.monotonic() - audio_start_wall
                expected_frame = audio_pos_s * video_fps
                debt           = expected_frame - cur_frame
                if debt > 1.0:
                    drop_frame = True

            # ── Read & render ─────────────────────────────────────────────────
            t_frame_start = time.monotonic()

            ret, frame = cap.read()
            if not ret:
                if loop:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    cur_frame = 0
                    reset_sync(0, audio_offset=0)
                    continue
                else:
                    break

            cur_frame += 1

            if not drop_frame:
                if time.monotonic() - last_render_time >= frame_time_limit:
                    fps_counter.tick()
                    cols, rows = get_terminal_size()
                    last_cols, last_rows = cols, rows
                    video_rows = rows - 1 if hud else rows

                    last_lines = frame_to_lines(frame, cols, video_rows, mode, invert=invert, highlight=highlight,
                                                legacy_color=legacy_color, no_color=no_color)
                    last_hud_line = None
                    if hud:
                        vol = audio.volume if audio else 0
                        last_hud_line = make_hud(
                            False, cur_frame, total_frames, video_fps, vol, mode,
                            bool(audio), cols, is_live, loop, screenshot_msg,
                            fps_counter.fps, sync, fps_limit, recording=output_file is not None,
                            legacy_color=legacy_color, no_color=no_color)

                    render_frame(last_lines, last_hud_line)
                    if output_file:
                        write_frame_to_file(output_file, last_lines, last_hud_line)

                    last_render_time = time.monotonic()

                render_ms = (time.monotonic() - t_frame_start) * 1000
                last_render_ms = last_render_ms * 0.7 + render_ms * 0.3

                wait = (1.0 / video_fps) - render_ms / 1000
                if wait > 0:
                    time.sleep(wait)

    except KeyboardInterrupt:
        pass
    finally:
        keys.stop()
        cap.release()
        if audio:
            audio.stop()
        if output_file:
            output_file.close()
            sys.stdout.write("\033[?25h\033[0m\033[2J\033[H\033[?1049l")
            sys.stdout.flush()
            print(f"hoopoe stopped. Output saved to: {output_path}")
        else:
            sys.stdout.write("\033[?25h\033[0m\033[2J\033[H\033[?1049l")
            sys.stdout.flush()
            print("hoopoe stopped. See you next time!")


def render_image(source, mode, invert, flip, highlight, hud, output=None, legacy_color=False, no_color=False):
    """Renders a source image into the terminal."""

    if not os.path.isfile(source):
        print(f"Error: image file not found or is not a file: {source}")
        sys.exit(1)

    output_path = resolve_output_path(output)

    sys.stdout.write("\033[?1049h\033[?25l\033[2J\033[H")
    sys.stdout.flush()

    keys = KeyListener()

    image = cv2.imread(source)
    if image is None:
        keys.stop()
        sys.stdout.write("\033[?25h\033[0m\033[2J\033[H\033[?1049l")
        sys.stdout.flush()
        print(f"Error: failed to read image: {source}")
        sys.exit(1)

    last_cols, last_rows = get_terminal_size()

    def do_render(cols, rows):
        video_rows = rows - 1 if hud else rows
        lines = frame_to_lines(image, cols, video_rows, mode, invert, flip, highlight,
                               legacy_color=legacy_color, no_color=no_color)
        hud_line = None
        if hud:
            hud_line = f" {os.path.basename(source)} | Press Q to quit".ljust(cols)
        render_frame(lines, f"\033[47;30m{hud_line}\033[0m" if hud_line else None)
        return lines, (f"\033[47;30m{hud_line}\033[0m" if hud_line else None)

    try:
        lines, hud_line = do_render(last_cols, last_rows)

        if output_path:
            with open(output_path, "w", encoding="utf-8") as f:
                write_frame_to_file(f, lines, hud_line)

        # ── Hang and wait for keypress, rerender on resize ────────────────
        while True:
            key = keys.pop()
            if key in (b'q', b'Q', b'\x03'):
                break

            cols, rows = get_terminal_size()
            if (cols, rows) != (last_cols, last_rows):
                last_cols, last_rows = cols, rows
                do_render(cols, rows)

            time.sleep(0.05)

    finally:
        keys.stop()
        sys.stdout.write("\033[?25h\033[0m\033[2J\033[H\033[?1049l")
        sys.stdout.flush()
        if output_path:
            print(f"Output saved to: {output_path}")


def play_ans(path, fps_override=None):
    """Replay a recorded .ans file at the original framerate."""

    if not os.path.isfile(path):
        print(f"Error: file not found: {path}")
        sys.exit(1)

    with open(path, "r", encoding="utf-8", newline="") as f:
        raw = f.read()

    fps = None

    first_newline = raw.find("\n")
    first_line = raw[:first_newline].rstrip("\r") if first_newline != -1 else ""

    if first_line.startswith("#HOOPOE fps="):
        try:
            fps = float(first_line.split("=")[1].strip())
        except ValueError:
            pass
        raw = raw[first_newline + 1:]

    if fps_override is not None:
        fps = fps_override
    if fps is None:
        fps = 24.0

    frames = raw.split("#FRAME\n")
    frames = [f for f in frames if f.strip()]

    frame_time = 1.0 / fps

    sys.stdout.write("\033[?1049h\033[?25l\033[2J\033[H")
    sys.stdout.flush()

    keys = KeyListener()
    paused = False

    try:
        for frame in frames:
            t_start = time.monotonic()

            key = keys.pop()
            if key in (b'q', b'Q', b'\x03'):
                break
            elif key == b' ':
                paused = not paused

            while paused:
                key = keys.pop()
                if key in (b'q', b'Q', b'\x03'):
                    paused = False
                    break
                elif key == b' ':
                    paused = False
                time.sleep(0.05)

            sys.stdout.write("\033[H" + frame)
            sys.stdout.flush()

            elapsed = time.monotonic() - t_start
            wait = frame_time - elapsed
            if wait > 0:
                time.sleep(wait)

    except KeyboardInterrupt:
        pass
    finally:
        keys.stop()
        sys.stdout.write("\033[?25h\033[0m\033[2J\033[H\033[?1049l")
        sys.stdout.flush()
        print("hoopoe-play stopped.")


def main():
    parser = argparse.ArgumentParser(
        description="hoopoe-player - Videos as colorful ASCII art in your terminal",
        formatter_class=argparse.RawTextHelpFormatter,
    )

    source_group = parser.add_mutually_exclusive_group()

    source_group.add_argument("-l", "--local",   action="store_true", help="Play a local video file")
    source_group.add_argument("-i", "--image",   action="store_true", help="Render a local image")
    source_group.add_argument("--play",          action="store_true", help="Replay a recorded .ans file")

    parser.add_argument("source", nargs="?", help="YouTube URL or path to local video file/image")
    parser.add_argument("-s", "--sound",   action="store_true", help="Enable audio (requires ffmpeg)")
    parser.add_argument("-m", "--mode",    choices=list(CHAR_MODES.keys()), default="classic",
                        help="Rendering mode: classic blocks braille minimal solid")
    parser.add_argument("--hud",           action="store_true",
                        help="Show status bar at the bottom")
    parser.add_argument("--loop",          action="store_true",
                        help="Loop video automatically when it ends")
    parser.add_argument("--sync",          action="store_true",
                        help="Sync video to audio: drop frames when rendering is slow")
    parser.add_argument("--quality",       choices=["low", "medium", "high"], default="medium",
                        help="Stream resolution: low (144p), medium (360p, default), high (480p)")
    parser.add_argument("--webcam",        action="store_true",
                        help="Stream webcam as ASCII art in the terminal")
    parser.add_argument("--camera",        type=int, default=0,
                        help="Camera index to use with --webcam (default: 0)")
    parser.add_argument("--invert",        action="store_true",
                        help="Invert brightness mapping for any character mode")
    parser.add_argument("--highlight",     action="store_true",
                        help="Render color as background for any character mode")
    parser.add_argument("--flip",          choices=["h", "v", "hv"],
                        help="Flip webcam feed: h (horizontal), v (vertical), hv (both)")
    parser.add_argument("--fps",           type=float, default=None,
                        help="Set rendering FPS limit, must be > 0 (default: unlimited)")
    parser.add_argument("--legacy-color",  nargs="?", const="rgb", default=None,
                        choices=["rgb", "lab"],
                        help="Use 16-color ANSI palette: rgb (default, fast) or lab (perceptual, slower)")
    parser.add_argument("--no-color",      action="store_true",
                        help="Disable all color output (for terminals with no color support)")
    parser.add_argument("--output",        type=str, default=None, metavar="PATH",
                        help="Save render to an ANSI file (.ans); accepts file path or directory")
    args = parser.parse_args()

    if args.fps is not None and args.fps <= 0:
        parser.error("--fps must be a positive number")

    if args.legacy_color and args.no_color:
        parser.error("--legacy-color and --no-color are mutually exclusive")

    if args.play:
        if not args.source:
            parser.error("source is required with --play")
        play_ans(args.source, fps_override=args.fps)
        return

    if args.image:
        if not args.source:
            parser.error("source is required unless --webcam is used")
        render_image(source=args.source, mode=args.mode, invert=args.invert,
                     flip=args.flip, highlight=args.highlight, hud=args.hud,
                     output=args.output, legacy_color=args.legacy_color, no_color=args.no_color)

    elif args.webcam:
        play_webcam(mode=args.mode, hud=args.hud, camera=args.camera,
                    invert=args.invert, flip=args.flip, highlight=args.highlight,
                    fps_limit=args.fps, output=args.output,
                    legacy_color=args.legacy_color, no_color=args.no_color)
    else:
        if not args.source:
            parser.error("source is required unless --webcam is used")
        play_video(args.source, local=args.local, sound=args.sound,
                   mode=args.mode, hud=args.hud, loop=args.loop, sync=args.sync,
                   quality=args.quality, invert=args.invert, highlight=args.highlight,
                   fps_limit=args.fps, output=args.output,
                   legacy_color=args.legacy_color, no_color=args.no_color)


if __name__ == "__main__":
    main()
