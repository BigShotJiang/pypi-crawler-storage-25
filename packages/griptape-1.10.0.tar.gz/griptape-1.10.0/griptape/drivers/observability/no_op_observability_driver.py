from __future__ import annotations

from typing import TYPE_CHECKING, Any

from attrs import define

from griptape.drivers.observability import BaseObservabilityDriver

if TYPE_CHECKING:
    from griptape.common import Observable


@define
class NoOpObservabilityDriver(BaseObservabilityDriver):
    def observe(self, call: Observable.Call) -> Any:
        return call()

    def get_span_id(self) -> str | None:
        return None
