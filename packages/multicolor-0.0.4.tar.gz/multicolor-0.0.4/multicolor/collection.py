"""Colormap collection abstraction for chained filtering, grouping, and export."""

from .render import ColormapRenderer


class ColormapCollection:
    """A chainable wrapper around colormap records for filtering and grouping."""

    def __init__(self, records):
        """Initialize with a list of colormap record dicts (from db._query_all)."""
        self._items = list(records)

    def __len__(self):
        return len(self._items)

    def __repr__(self):
        return f"ColormapCollection({len(self._items)} colormaps)"

    @property
    def names(self):
        """Return list of colormap names."""
        return [r["name"] for r in self._items]

    @property
    def records(self):
        """Return the underlying list of record dicts."""
        return list(self._items)

    def filter(
        self, cmap_type=None, tag=None, source=None, colorblind_safe=None, keyword=None
    ):
        """Return a new ColormapCollection with applied filters.

        Args:
            cmap_type: filter by type (sequential/diverging/qualitative)
            tag: single tag or list of tags (AND logic)
            source: single source or list of sources (AND logic)
            colorblind_safe: filter by colorblind compatibility
            keyword: fuzzy search in name, description, tags

        All filters are AND-combined.
        """
        result = self._items

        if cmap_type:
            result = [r for r in result if r["cmap_type"] == cmap_type]

        if tag:
            if isinstance(tag, str):
                tag = [tag]
            result = [r for r in result if all(t in r["tags"] for t in tag)]

        if source:
            if isinstance(source, str):
                source = [source]
            result = [r for r in result if all(s in r["source"] for s in source)]

        if colorblind_safe:
            if colorblind_safe == "any":
                result = [r for r in result if r["colorblind_safe"] != "none"]
            else:
                result = [
                    r
                    for r in result
                    if (
                        r["colorblind_safe"] == colorblind_safe
                        or colorblind_safe in r.get("colorblind_types", [])
                    )
                ]

        if keyword:
            kw = keyword.lower()
            result = [
                r
                for r in result
                if kw in r["name"].lower()
                or kw in r.get("description", "").lower()
                or any(kw in t.lower() for t in r["tags"])
            ]

        return ColormapCollection(result)

    def group_by(self, key):
        """Group colormaps by a field. Returns dict: {value: ColormapCollection}.

        Args:
            key: 'source', 'cmap_type', 'colorblind_safe', or any record field name
        """
        groups = {}
        for r in self._items:
            if key == "source":
                for s in r.get("source", []):
                    groups.setdefault(s, []).append(r)
            else:
                val = r.get(key, "unknown")
                groups.setdefault(val, []).append(r)

        return {k: ColormapCollection(v) for k, v in groups.items()}

    def to_list(self):
        """Return list of (id, name, cmap) tuples like cmap.list()."""
        from .utils import build_cmap

        return [
            (r["id"], r["name"], build_cmap(r["name"], r["colors"], r["cmap_type"]))
            for r in self._items
        ]

    def to_html(self, path, cols=4, title="ColorMap Collection"):
        """Export collection as an HTML page with visual colorbar previews."""
        cards = []
        for r in self._items:
            swatch_parts = []
            for c in r["colors"]:
                swatch_parts.append(
                    '<span style="display:inline-block;width:20px;height:20px;'
                    + "background:"
                    + c
                    + ';border:1px solid #ccc;"></span>'
                )
            bar_parts = []
            for c in r["colors"]:
                bar_parts.append(
                    '<div style="height:30px;background:' + c + ';"></div>'
                )

            card = "".join(
                [
                    '<div style="border:1px solid #ddd;padding:12px;margin:8px;border-radius:4px;">',
                    '<h3 style="margin:0 0 8px 0;">' + r["name"] + "</h3>",
                    '<div style="display:flex;gap:2px;margin-bottom:8px;">',
                    "".join(bar_parts),
                    "</div>",
                    '<div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px;">',
                    "".join(swatch_parts),
                    "</div>",
                    '<div style="color:#666;font-size:0.9em;">',
                    "Type: "
                    + r["cmap_type"]
                    + " | Colors: "
                    + str(len(r["colors"]))
                    + " | ",
                    "Colorblind: " + r["colorblind_safe"],
                    "</div></div>",
                ]
            )
            cards.append(card)

        width = cols * 400
        parts = [
            '<!DOCTYPE html><html><head><meta charset="utf-8">',
            "<title>" + title + "</title>",
            "<style>body{font-family:system-ui,sans-serif;max-width:"
            + str(width)
            + "px;margin:0 auto;padding:20px;}</style>",
            "</head><body>",
            "<h1>" + title + "</h1>",
            '<div style="display:flex;flex-wrap:wrap;">',
            "".join(cards),
            "</div></body></html>",
        ]
        html = "".join(parts)

        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

        return path

    def export_images(self, directory, orientation="horizontal", size=(10, 1), dpi=150):
        """Batch export all colormaps as PNG files."""
        import os
        from .utils import build_cmap

        os.makedirs(directory, exist_ok=True)
        renderer = ColormapRenderer()

        for r in self._items:
            cmap_obj = build_cmap(r["name"], r["colors"], r["cmap_type"])
            safe_name = "".join(
                c if c.isalnum() or c in "-_" else "_" for c in r["name"]
            )
            filepath = os.path.join(directory, safe_name + ".png")
            renderer.to_file(
                cmap_obj, filepath, orientation=orientation, size=size, dpi=dpi
            )
