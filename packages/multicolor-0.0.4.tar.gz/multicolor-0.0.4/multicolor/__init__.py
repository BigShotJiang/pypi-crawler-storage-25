"""A python package for mapping - colormap management and batch plotting."""

from importlib.metadata import version

from .batch import batch_cmaps, batch_colors
from .collection import ColormapCollection
from .cmap import (
    get,
    get_by_id,
    list,
    names,
    add,
    preview,
    records,
    remove,
    export,
    import_data,
    collection,
)
from .data import (
    list as data_list,
    get as data_get,
    ensure as data_ensure,
    is_available,
    remove as data_remove,
    DataError,
    DownloadError,
    HashError,
)

__author__ = "zbhgis"
__email__ = "zbhgisrs@gmail.com"
__version__ = "0.0.4"
