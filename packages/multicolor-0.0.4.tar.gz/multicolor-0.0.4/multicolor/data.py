"""Download manager for GIS vector/raster data.

Lazy-download with local cache, similar to cartopy.io.Downloader.
Data is only downloaded when first requested, then cached locally.
"""

import hashlib
import json
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path

# ---- Constants ----

_PACKAGE_DIR = Path(__file__).parent
_CATALOG_PATH = _PACKAGE_DIR / "data_catalog.json"

_USER_DIR = Path.home() / ".multicolor"
_DATA_DIR = _USER_DIR / "data"

# ---- Exceptions ----


class DataError(Exception):
    """Base exception for data module errors."""


class DownloadError(DataError):
    """Raised when a network download fails."""


class HashError(DataError):
    """Raised when a downloaded file hash doesn't match the catalog."""


# ---- Internal helpers ----


def _load_catalog():
    """Load and return the bundled data catalog."""
    with open(_CATALOG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _find_entry(name):
    """Find a dataset entry by name. Raises ValueError if not found."""
    catalog = _load_catalog()
    for entry in catalog["datasets"]:
        if entry["name"] == name:
            return entry
    raise ValueError(f"Dataset '{name}' not found in catalog")


def _cache_path(name):
    """Return the expected local cache Path for a dataset."""
    entry = _find_entry(name)
    return _DATA_DIR / entry["filename"]


def _compute_sha256(filepath):
    """Compute SHA256 hash of a file, streaming in chunks."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _verify_hash(filepath, expected):
    """Verify file matches expected SHA256. Raises HashError on mismatch."""
    if not expected:
        return
    actual = _compute_sha256(filepath)
    if actual != expected:
        filepath.unlink(missing_ok=True)
        raise HashError(
            f"Hash mismatch for {filepath.name}: expected {expected}, got {actual}"
        )


def _download_file(url, dest):
    """Download a file from url to dest with progress indication."""

    def _progress_hook(count, block_size, total_size):
        if total_size <= 0:
            return
        pct = min(100, count * block_size * 100 // total_size)
        print(f"\r  Downloading... {pct}%", end="", flush=True)

    urllib.request.urlretrieve(url, dest, reporthook=_progress_hook)
    print()


def _handle_archive(zip_path, target_filename, final_path):
    """Extract a zip archive, find the target file, move it to final_path."""
    extract_dir = tempfile.mkdtemp(dir=_DATA_DIR)
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)
        matches = list(Path(extract_dir).rglob(target_filename))
        if not matches:
            raise DataError(
                f"Expected file '{target_filename}' not found in archive"
            )
        final_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(matches[0]), str(final_path))
    finally:
        shutil.rmtree(extract_dir, ignore_errors=True)
        zip_path.unlink(missing_ok=True)


# ---- Public API ----


def list():
    """List all available datasets in the catalog.

    Returns a list of dicts with keys: name, type, format, size_hint,
    description, available.
    """
    catalog = _load_catalog()
    result = []
    for entry in catalog["datasets"]:
        local = _DATA_DIR / entry["filename"]
        result.append(
            {
                "name": entry["name"],
                "type": entry["type"],
                "format": entry["format"],
                "size_hint": entry.get("size_hint", "unknown"),
                "description": entry.get("description", ""),
                "available": local.exists(),
            }
        )
    return result


def is_available(name):
    """Check if a dataset is already downloaded and cached locally."""
    entry = _find_entry(name)
    return (_DATA_DIR / entry["filename"]).exists()


def get(name, force=False):
    """Get the local path to a dataset. Downloads if not cached.

    Args:
        name: dataset name from the catalog
        force: if True, re-download even if cached

    Returns:
        pathlib.Path to the local cached file.

    Raises:
        ValueError: if name not in catalog
        DownloadError: if download fails
        HashError: if downloaded file hash doesn't match catalog
    """
    entry = _find_entry(name)
    target = _DATA_DIR / entry["filename"]

    if not force and target.exists():
        return target

    _DATA_DIR.mkdir(parents=True, exist_ok=True)

    part_path = target.with_suffix(target.suffix + ".part")
    try:
        _download_file(entry["url"], part_path)

        if entry.get("archive", False):
            _handle_archive(part_path, entry["filename"], target)
        else:
            part_path.replace(target)

        _verify_hash(target, entry.get("sha256", ""))
    except HashError:
        raise
    except zipfile.BadZipFile as e:
        part_path.unlink(missing_ok=True)
        raise DownloadError(f"Failed to extract archive: {e}") from e
    except urllib.error.URLError as e:
        part_path.unlink(missing_ok=True)
        raise DownloadError(f"Download failed for {name}: {e}") from e
    except Exception as e:
        part_path.unlink(missing_ok=True)
        raise DownloadError(f"Unexpected error downloading {name}: {e}") from e

    return target


def ensure(name):
    """Ensure the dataset is available locally, downloading if necessary.

    This is the primary function for users. Simply pass the dataset name
    and it will be downloaded automatically on first use, then cached.

    Args:
        name: dataset name from the catalog

    Returns:
        pathlib.Path to the local cached file.

    Example:
        >>> from multicolor import data_ensure
        >>> path = data_ensure("tavg_10min")  # auto-download on first call
        >>> import rasterio
        >>> with rasterio.open(path) as src:
        ...     data = src.read(1)
    """
    return get(name)


def remove(name):
    """Delete a cached dataset file. No-op if not cached."""
    entry = _find_entry(name)
    target = _DATA_DIR / entry["filename"]
    if target.exists():
        target.unlink()
