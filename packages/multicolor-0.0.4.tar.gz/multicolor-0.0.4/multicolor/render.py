"""Rendering module for colormap visualization.

Centralizes all image rendering logic, removing duplicated numpy/matplotlib code.
"""

import math
import numpy as np


class ColormapRenderer:
    """Renders matplotlib Colormaps as images or subplots."""

    @staticmethod
    def to_image(cmap, orientation="horizontal", size=(10, 1), dpi=100):
        """Render a Colormap as an RGBA numpy array.

        Args:
            cmap: matplotlib.colors.Colormap instance
            orientation: 'horizontal' or 'vertical'
            size: (width_inches, height_inches)
            dpi: resolution

        Returns:
            RGBA numpy array of shape (height_px, width_px, 4)
        """
        width_px = int(size[0] * dpi)
        height_px = int(size[1] * dpi)

        if orientation == "horizontal":
            gradient = np.linspace(0, 1, width_px)
            gradient = np.tile(gradient, (height_px, 1))
        else:
            gradient = np.linspace(0, 1, height_px)
            gradient = np.tile(gradient, (1, width_px)).T

        return cmap(gradient)

    @staticmethod
    def preview(cmap, title=None, orientation="horizontal", size=(10, 1)):
        """Display a colormap as a colorbar-like image.

        Args:
            cmap: matplotlib.colors.Colormap instance
            title: display title (defaults to cmap.name)
            orientation: 'horizontal' or 'vertical'
            size: (width_inches, height_inches)
        """
        import matplotlib.pyplot as plt

        x = np.linspace(0, 1, 256)
        if orientation == "horizontal":
            grad = np.tile(x, (50, 1))
            figsize = (size[0], size[1])
        else:
            grad = np.tile(x[:, np.newaxis], (1, 50))
            figsize = (size[1], size[0])

        plt.figure(figsize=figsize)
        plt.imshow(grad, cmap=cmap, aspect="auto")
        plt.title(title or cmap.name)
        plt.axis("off")
        plt.show()

    @staticmethod
    def to_file(cmap, path, orientation="horizontal", size=(10, 1), dpi=150):
        """Save a colormap rendering to a PNG file.

        Args:
            cmap: matplotlib.colors.Colormap instance
            path: output file path
            orientation: 'horizontal' or 'vertical'
            size: (width_inches, height_inches)
            dpi: resolution
        """
        import matplotlib.pyplot as plt

        if orientation == "horizontal":
            figsize = (size[0], size[1])
        else:
            figsize = (size[1], size[0])

        fig, ax = plt.subplots(figsize=figsize)
        x = np.linspace(0, 1, int(size[0] * dpi))
        if orientation == "horizontal":
            grad = np.tile(x, (int(size[1] * dpi), 1))
        else:
            grad = np.tile(x[:, np.newaxis], (1, int(size[1] * dpi)))
        ax.imshow(grad, cmap=cmap, aspect="auto")
        ax.axis("off")
        fig.savefig(path, dpi=dpi, bbox_inches="tight", pad_inches=0)
        plt.close(fig)

    @staticmethod
    def render_grid(cmaps, cols=4, size_per_colormap=(3, 1.5)):
        """Render multiple colormaps in a single multi-subplot figure.

        Args:
            cmaps: list of (name, cmap) tuples
            cols: number of columns
            size_per_colormap: (width, height) per subplot in inches

        Returns:
            (fig, axes) tuple from matplotlib
        """
        import matplotlib.pyplot as plt

        n = len(cmaps)
        if n == 0:
            return None, None

        rows = math.ceil(n / cols)
        fig, axes = plt.subplots(
            rows,
            cols,
            figsize=(cols * size_per_colormap[0], rows * size_per_colormap[1]),
        )
        if hasattr(axes, "flatten"):
            axes = axes.flatten()
        else:
            axes = [axes]

        for i, (name, cmap) in enumerate(cmaps):
            x = np.linspace(0, 1, 256)
            grad = np.tile(x, (50, 1))
            axes[i].imshow(grad, cmap=cmap, aspect="auto")
            axes[i].set_title(name)
            axes[i].axis("off")

        for j in range(i + 1, len(axes)):
            axes[j].axis("off")

        plt.tight_layout()
        return fig, axes
