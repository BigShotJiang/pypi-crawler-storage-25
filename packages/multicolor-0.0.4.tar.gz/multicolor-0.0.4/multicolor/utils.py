"""Utility functions for color conversion and colormap building."""

import re
from matplotlib.colors import LinearSegmentedColormap, ListedColormap

_VALID_TYPES = {"sequential", "diverging", "qualitative"}
_HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")


def validate_hex(h):
    """Validate a hex color string. Raises ValueError if invalid."""
    if not _HEX_RE.match(h):
        raise ValueError(
            f"Invalid hex color: {h!r}. Expected format: '#RRGGBB', e.g. '#ff0000'."
        )


def validate_colors(colors):
    """Validate the colors list. Must be non-empty list of valid hex strings."""
    if not isinstance(colors, list) or not colors:
        raise ValueError("colors must be a non-empty list of hex color strings.")
    for c in colors:
        validate_hex(c)


def validate_cmap_type(cmap_type):
    """Validate cmap_type. Must be 'sequential', 'diverging', or 'qualitative'."""
    if cmap_type not in _VALID_TYPES:
        raise ValueError(
            f"Invalid cmap_type: {cmap_type!r}. Must be one of {_VALID_TYPES}."
        )


def validate_name(name):
    """Validate colormap name. Must be a non-empty string."""
    if not name or not isinstance(name, str) or not name.strip():
        raise ValueError("Colormap name must be a non-empty string.")


def hex_to_rgb(h):
    """Convert hex color string to (r, g, b) tuple with values 0-1."""
    h = h.lstrip("#")
    return tuple(int(h[i : i + 2], 16) / 255 for i in (0, 2, 4))


def build_cmap(name, colors, cmap_type):
    """Build a matplotlib Colormap from a list of hex colors."""
    rgb_colors = [hex_to_rgb(c) for c in colors]
    if cmap_type == "qualitative":
        return ListedColormap(rgb_colors, name=name)
    return LinearSegmentedColormap.from_list(name, rgb_colors, N=256)
