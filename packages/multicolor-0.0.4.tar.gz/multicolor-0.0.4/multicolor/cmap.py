"""Colormap factory module. Main public API for retrieving and creating colormaps."""

from . import db
from .utils import (
    build_cmap,
    hex_to_rgb,
    validate_colors,
    validate_cmap_type,
    validate_name,
)

# Backward-compat aliases for internal/test use
_hex_to_rgb = hex_to_rgb
_build_cmap = build_cmap


def get(name):
    """Get a single Colormap object by name."""
    record = db._get_by_name(name)
    if record is None:
        raise KeyError(f"Colormap '{name}' not found in database")
    return build_cmap(record["name"], record["colors"], record["cmap_type"])


def get_by_id(cmap_id):
    """Get a single Colormap object by id."""
    record = db._get_by_id(cmap_id)
    if record is None:
        raise KeyError(f"Colormap with id={cmap_id} not found in database")
    return build_cmap(record["name"], record["colors"], record["cmap_type"])


def list(
    cmap_type=None,
    tag=None,
    colorblind_safe=None,
    is_custom=None,
    source=None,
    keyword=None,
    sort_by="name",
    limit=None,
):
    """Return a list of (id, name, cmap) tuples matching the given filters.

    Args:
        cmap_type: 'sequential', 'diverging', or 'qualitative'
        tag: single tag string or list of tags (AND filter)
        colorblind_safe: 'deutan', 'protan', 'tritan', 'achromatopsia', 'any', or 'none'
        is_custom: True for user-defined, False for built-in, None for all
        source: single source string or list of sources (AND filter)
        keyword: fuzzy search in name, description, and tags
        sort_by: 'name', 'id', or 'type'
        limit: max number of results
    """
    records = db._query_all(
        cmap_type=cmap_type,
        tag=tag,
        colorblind_safe=colorblind_safe,
        is_custom=is_custom,
        source=source,
        keyword=keyword,
        sort_by=sort_by,
        limit=limit,
    )
    result = []
    for r in records:
        cmap = build_cmap(r["name"], r["colors"], r["cmap_type"])
        result.append((r["id"], r["name"], cmap))
    return result


def names(
    cmap_type=None,
    tag=None,
    colorblind_safe=None,
    is_custom=None,
    source=None,
    keyword=None,
    sort_by="name",
    limit=None,
):
    """Return a list of colormap names matching the given filters. Lightweight version of list()."""
    records = db._query_all(
        cmap_type=cmap_type,
        tag=tag,
        colorblind_safe=colorblind_safe,
        is_custom=is_custom,
        source=source,
        keyword=keyword,
        sort_by=sort_by,
        limit=limit,
    )
    return [r["name"] for r in records]


def add(
    name,
    colors,
    cmap_type,
    tags=None,
    colorblind_safe="none",
    colorblind_types=None,
    description="",
    source=None,
):
    """Add a new colormap to the database.

    Args:
        name: colormap name
        colors: list of hex color strings, e.g. ['#ff0000', '#00ff00']
        cmap_type: 'sequential', 'diverging', or 'qualitative'
        tags: list of tag strings
        colorblind_safe: 'none', 'deutan', 'protan', 'tritan', 'achromatopsia', 'multiple'
        colorblind_types: list of colorblind types this cmap supports
        description: text description
        source: list of source strings, e.g. ['matplotlib', 'colorbrewer']
    """
    validate_name(name)
    validate_colors(colors)
    validate_cmap_type(cmap_type)
    return db._insert(
        name=name,
        colors=colors,
        cmap_type=cmap_type,
        tags=tags,
        colorblind_safe=colorblind_safe,
        colorblind_types=colorblind_types,
        description=description,
        source=source,
    )


def preview(cmap, title=None, orientation="horizontal", size=(10, 1)):
    """Quick preview of a colormap as a horizontal colorbar.

    Args:
        cmap: matplotlib.colors.Colormap instance
        title: display title (defaults to cmap.name)
        orientation: 'horizontal' or 'vertical'
        size: (width_inches, height_inches)
    """
    from .render import ColormapRenderer

    ColormapRenderer.preview(cmap, title=title, orientation=orientation, size=size)


def records(
    cmap_type=None,
    tag=None,
    colorblind_safe=None,
    is_custom=None,
    source=None,
    keyword=None,
    sort_by="name",
    limit=None,
):
    """Return raw colormap records without building Colormap objects.

    Lightweight version of list() when you only need metadata (id, name, colors, etc).

    Args: same as list()
    """
    return db._query_all(
        cmap_type=cmap_type,
        tag=tag,
        colorblind_safe=colorblind_safe,
        is_custom=is_custom,
        source=source,
        keyword=keyword,
        sort_by=sort_by,
        limit=limit,
    )


def remove(name):
    """Remove a user-defined colormap from the database.

    Built-in colormaps cannot be deleted.
    """
    db._delete(name)


def export(filepath=None):
    """Export all user-defined colormaps to a JSON file.

    Args:
        filepath: output file path (defaults to ~/.multicolor/cmap_export.json)

    Returns:
        The output filepath.
    """
    return db._export_custom(filepath)


def import_data(filepath):
    """Import colormaps from a JSON export file.

    Each colormap is added via add() (overwrites existing custom colormaps with same name).

    Args:
        filepath: path to a JSON file exported from multicolor

    Returns:
        List of (name, id) tuples for imported colormaps.
    """
    return db._import_data(filepath)


def collection(
    cmap_type=None,
    tag=None,
    colorblind_safe=None,
    is_custom=None,
    source=None,
    keyword=None,
    sort_by="name",
    limit=None,
):
    """Return a ColormapCollection for chained filtering and grouping.

    Example:
        >>> cmaps = cmap.collection().filter(cmap_type="sequential").filter(colorblind_safe="any")
        >>> cmaps.group_by("cmap_type")
    """
    from .collection import ColormapCollection

    records = db._query_all(
        cmap_type=cmap_type,
        tag=tag,
        colorblind_safe=colorblind_safe,
        is_custom=is_custom,
        source=source,
        keyword=keyword,
        sort_by=sort_by,
        limit=limit,
    )
    return ColormapCollection(records)
