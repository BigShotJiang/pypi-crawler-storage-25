"""Batch plotting decorator. Apply a function to multiple colormaps or raw color data automatically."""

import math
from functools import wraps
from . import cmap
from . import db


def _fetch_records(names):
    """Fetch all records in one query, return list ordered by names."""
    all_records = db._query_all()
    record_map = {r["name"]: r for r in all_records}
    return [record_map[name] for name in names if name in record_map]


def _execute(names, layout, cols, func):
    """Core execution loop. Resolve names to Colormap objects and apply func."""
    if not names:
        return

    if layout == "grid":
        _render_grid(names, cols, func)
    else:
        for name in names:
            func(cmap.get(name))


def _render_grid(names, cols, func):
    """Render multiple colormaps in a single multi-subplot figure."""
    import matplotlib.pyplot as plt

    n = len(names)
    rows = math.ceil(n / cols)
    fig, axes = plt.subplots(
        rows,
        cols,
        figsize=(cols * 3, rows * 1.5),
    )
    if hasattr(axes, "flatten"):
        axes = axes.flatten()
    else:
        axes = [axes]

    for i, name in enumerate(names):
        c = cmap.get(name)
        func(c, ax=axes[i])
        axes[i].set_title(c.name)

    for j in range(i + 1, len(axes)):
        axes[j].axis("off")

    plt.tight_layout()
    plt.show()


def _execute_colors(names, layout, cols, func):
    """Core execution loop for colors mode. Pass raw DB records to func."""
    if not names:
        return

    if layout == "grid":
        _render_grid_colors(names, cols, func)
    else:
        for record in _fetch_records(names):
            func(record)


def _render_grid_colors(names, cols, func):
    """Grid layout for colors mode: pass raw DB records to func."""
    import matplotlib.pyplot as plt

    records = _fetch_records(names)
    n = len(records)
    if n == 0:
        return

    rows = math.ceil(n / cols)
    fig, axes = plt.subplots(
        rows,
        cols,
        figsize=(cols * 3, rows * 1.5),
    )
    if hasattr(axes, "flatten"):
        axes = axes.flatten()
    else:
        axes = [axes]

    for i, record in enumerate(records):
        func(record, ax=axes[i])
        axes[i].set_title(record["name"])

    for j in range(i + 1, len(axes)):
        axes[j].axis("off")

    plt.tight_layout()
    plt.show()


def _resolve_names(cmaps, query_func, **filters):
    """Resolve colormap names from various input sources.

    Auto-detects input type:
    - list[int] -> colormap IDs
    - list[str] -> colormap names
    - Collection -> .names property
    - query_func -> callable returning names
    - kwargs -> forwarded to cmap.names()
    """
    if cmaps is not None:
        if isinstance(cmaps, list) and cmaps and isinstance(cmaps[0], int):
            return [cmap.get_by_id(i).name for i in cmaps]
        if hasattr(cmaps, "names"):
            return cmaps.names
        return list(cmaps)
    if query_func is not None:
        return list(query_func())
    return cmap.names(**filters)


def batch_cmaps(cmaps=None, /, *, layout="single", cols=4, query_func=None, **filters):
    """Decorator that runs the wrapped function once per colormap.

    Supports five calling styles:

    1. Name list (str):
       @batch_cmaps(["Viridis", "Plasma"])

    2. ID list (int):
       @batch_cmaps([1, 2, 3])

    3. ColormapCollection:
       @batch_cmaps(cmap.collection().filter(tag="climate"))

    4. Filter kwargs (delegated to cmap.names()):
       @batch_cmaps(cmap_type="diverging", colorblind_safe="any")

    5. Query function:
       @batch_cmaps(query_func=lambda: cmap.names(is_custom=True))

    All styles support layout and cols parameters:
       @batch_cmaps([1, 2, 3], layout="grid", cols=3)

    Args:
        cmaps: list of names, list of IDs, ColormapCollection, or None
        layout: 'single' for separate windows, 'grid' for multi-subplot
        cols: number of columns in grid mode
        query_func: callable returning list of names
        **filters: keyword args forwarded to cmap.names()

    The wrapped function receives `cmap_obj` (Colormap) and, in grid mode,
    an `ax` parameter for drawing.
    """
    names = _resolve_names(cmaps, query_func, **filters)

    def decorator(func):
        @wraps(func)
        def wrapper():
            _execute(names, layout, cols, func)

        return wrapper

    return decorator


def batch_colors(cmaps=None, /, *, layout="single", cols=4, query_func=None, **filters):
    """Decorator that runs the wrapped function once per colormap, passing raw DB records.

    Like batch_cmaps(), but passes the raw database record dict instead of
    a Colormap object. The record contains: id, name, colors (hex list),
    cmap_type, tags, colorblind_safe, colorblind_types, description,
    is_custom, source.

    Supports the same five calling styles as batch_cmaps():

    1. Name list (str):
       @batch_colors(["Viridis", "Plasma"])

    2. ID list (int):
       @batch_colors([1, 2, 3])

    3. ColormapCollection:
       @batch_colors(cmap.collection().filter(tag="climate"))

    4. Filter kwargs (delegated to cmap.names()):
       @batch_colors(cmap_type="diverging", colorblind_safe="any")

    5. Query function:
       @batch_colors(query_func=lambda: cmap.names(is_custom=True))

    All styles support layout and cols parameters:
       @batch_colors([1, 2, 3], layout="grid", cols=3)

    Args:
        cmaps: list of names, list of IDs, ColormapCollection, or None
        layout: 'single' for separate windows, 'grid' for multi-subplot
        cols: number of columns in grid mode
        query_func: callable returning list of names
        **filters: keyword args forwarded to cmap.names()

    The wrapped function receives `record` (dict) and, in grid mode,
    an `ax` parameter for drawing.
    """
    names = _resolve_names(cmaps, query_func, **filters)

    def decorator(func):
        @wraps(func)
        def wrapper():
            _execute_colors(names, layout, cols, func)

        return wrapper

    return decorator
