"""Internal database layer for storing and querying colormaps.

This module is not meant to be used directly by users.
Access it through cmap.py instead.
"""

import json
import sqlite3
import shutil
from pathlib import Path

_PACKAGE_DIR = Path(__file__).parent
_PACKAGE_DB = _PACKAGE_DIR / "cmap_data.db"
_USER_DIR = Path.home() / ".multicolor"
_USER_DB = _USER_DIR / "cmap_data.db"

# Sync only once per Python session to avoid repeated full-table scans on every query.
_synced = False

_COLUMNS = "id, name, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, is_custom, source"


def _migrate_db(conn):
    """Add is_custom and source columns if they don't exist (for existing user DBs)."""
    cur = conn.cursor()
    cur.execute("PRAGMA table_info(cmaps)")
    col_names = [row[1] for row in cur.fetchall()]
    if "is_custom" not in col_names:
        cur.execute("ALTER TABLE cmaps ADD COLUMN is_custom INTEGER NOT NULL DEFAULT 0")
    if "source" not in col_names:
        cur.execute("ALTER TABLE cmaps ADD COLUMN source TEXT NOT NULL DEFAULT '[]'")
    conn.commit()


def _sync_builtins():
    """Merge new/updated built-in colormaps from bundled DB into user DB."""
    pkg_conn = sqlite3.connect(str(_PACKAGE_DB))
    pkg_cur = pkg_conn.cursor()
    pkg_cur.execute(
        "SELECT id, name, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, is_custom, source FROM cmaps"
    )
    pkg_rows = pkg_cur.fetchall()
    pkg_conn.close()

    if not pkg_rows:
        return

    user_conn = sqlite3.connect(str(_USER_DB))
    _migrate_db(user_conn)
    user_cur = user_conn.cursor()

    for pkg_row in pkg_rows:
        (
            pkg_id,
            name,
            pkg_colors,
            pkg_type,
            pkg_tags,
            pkg_cb_safe,
            pkg_cb_types,
            pkg_desc,
            _,
            pkg_source,
        ) = pkg_row

        user_cur.execute(
            "SELECT is_custom, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, source FROM cmaps WHERE name = ?",
            (name,),
        )
        user_row = user_cur.fetchone()

        if user_row is None:
            # 本地不存在 -> 插入新色带，保留原 ID
            user_cur.execute(
                "INSERT INTO cmaps (id, name, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, is_custom, source) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)",
                (
                    pkg_id,
                    name,
                    pkg_colors,
                    pkg_type,
                    pkg_tags,
                    pkg_cb_safe,
                    pkg_cb_types,
                    pkg_desc,
                    pkg_source,
                ),
            )
        else:
            (
                is_custom,
                u_colors,
                u_type,
                u_tags,
                u_cb_safe,
                u_cb_types,
                u_desc,
                u_source,
            ) = user_row
            # 仅同步内置色带（is_custom=0），保护用户自定义内容
            if is_custom == 0:
                # 检查是否有字段不一致
                if (
                    pkg_colors != u_colors
                    or pkg_type != u_type
                    or pkg_tags != u_tags
                    or pkg_cb_safe != u_cb_safe
                    or pkg_cb_types != u_cb_types
                    or pkg_desc != u_desc
                    or pkg_source != u_source
                ):
                    user_cur.execute(
                        "UPDATE cmaps SET colors=?, cmap_type=?, tags=?, colorblind_safe=?, colorblind_types=?, description=?, source=? "
                        "WHERE name=?",
                        (
                            pkg_colors,
                            pkg_type,
                            pkg_tags,
                            pkg_cb_safe,
                            pkg_cb_types,
                            pkg_desc,
                            pkg_source,
                            name,
                        ),
                    )

    user_conn.commit()
    user_conn.close()


def _ensure_user_db():
    """Copy bundled cmap_data.db to user directory if not already present, then sync built-ins once per session."""
    global _synced
    if _USER_DB.exists():
        if not _synced:
            _sync_builtins()
            _synced = True
        return
    _USER_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(str(_PACKAGE_DB), str(_USER_DB))


def _get_conn():
    """Get a connection to the user-writable database."""
    _ensure_user_db()
    conn = sqlite3.connect(str(_USER_DB), timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    _migrate_db(conn)
    return conn


def _row_to_dict(row):
    """Convert a DB row dict to a Python dict with JSON fields parsed."""
    result = dict(row)
    result["colors"] = json.loads(result["colors"])
    result["tags"] = json.loads(result["tags"])
    result["colorblind_types"] = (
        json.loads(result["colorblind_types"]) if result.get("colorblind_types") else []
    )
    result["source"] = json.loads(result["source"]) if result.get("source") else []
    return result


def _get_by_id(cmap_id):
    """Get a single colormap record by id."""
    conn = _get_conn()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(f"SELECT {_COLUMNS} FROM cmaps WHERE id = ?", (cmap_id,))
    row = cur.fetchone()
    conn.close()
    if row is None:
        return None
    return _row_to_dict(dict(row))


def _get_by_name(name):
    """Get a single colormap record by name."""
    conn = _get_conn()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(f"SELECT {_COLUMNS} FROM cmaps WHERE name = ?", (name,))
    row = cur.fetchone()
    conn.close()
    if row is None:
        return None
    return _row_to_dict(dict(row))


def _query_all(
    cmap_type=None,
    tag=None,
    colorblind_safe=None,
    is_custom=None,
    source=None,
    keyword=None,
    sort_by="name",
    limit=None,
):
    """Unified query entry point for listing colormaps with filters."""
    conn = _get_conn()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    where_clauses = []
    params = []

    if cmap_type:
        where_clauses.append("cmap_type = ?")
        params.append(cmap_type)

    if tag:
        if isinstance(tag, str):
            tag = [tag]
        for t in tag:
            where_clauses.append("tags LIKE ?")
            params.append(f"%{t}%")

    if colorblind_safe and colorblind_safe != "none":
        if colorblind_safe == "any":
            where_clauses.append("colorblind_safe != 'none'")
        else:
            where_clauses.append("(colorblind_safe = ? OR colorblind_types LIKE ?)")
            params.append(colorblind_safe)
            params.append(f'%"{colorblind_safe}"%')

    if is_custom is not None:
        where_clauses.append("is_custom = ?")
        params.append(1 if is_custom else 0)

    if source:
        if isinstance(source, str):
            source = [source]
        for s in source:
            where_clauses.append("source LIKE ?")
            params.append(f'%"{s}"%')

    if keyword:
        where_clauses.append("(name LIKE ? OR description LIKE ? OR tags LIKE ?)")
        params.extend([f"%{keyword}%", f"%{keyword}%", f"%{keyword}%"])

    where_sql = " WHERE " + " AND ".join(where_clauses) if where_clauses else ""

    order_map = {
        "name": "name ASC",
        "id": "id ASC",
        "type": "cmap_type ASC",
    }
    order_sql = f" ORDER BY {order_map.get(sort_by, 'name ASC')}"

    limit_sql = ""
    if limit:
        limit_sql = " LIMIT ?"
        params.append(limit)

    sql = f"SELECT {_COLUMNS}" f" FROM cmaps{where_sql}{order_sql}{limit_sql}"

    cur.execute(sql, params)
    rows = cur.fetchall()
    conn.close()
    return [_row_to_dict(dict(r)) for r in rows]


def _insert(
    name,
    colors,
    cmap_type,
    tags=None,
    colorblind_safe="none",
    colorblind_types=None,
    description="",
    source=None,
):
    """Insert or update a user-defined colormap in the user database.

    Built-in colormaps (is_custom=0) cannot be overwritten.
    """
    # Check if name conflicts with a built-in
    conn = _get_conn()
    cur = conn.cursor()
    cur.execute("SELECT is_custom FROM cmaps WHERE name = ?", (name,))
    existing = cur.fetchone()

    if existing is not None and existing[0] == 0:
        conn.close()
        raise ValueError(
            f"Cannot overwrite built-in colormap '{name}'. Use a different name."
        )

    tags = tags or []
    colorblind_types = colorblind_types or []
    source = source or []

    if existing is not None:
        # Overwrite existing custom colormap
        cur.execute(
            "UPDATE cmaps SET colors=?, cmap_type=?, tags=?, colorblind_safe=?, colorblind_types=?, description=?, is_custom=1, source=? WHERE name=?",
            (
                json.dumps(colors, ensure_ascii=False),
                cmap_type,
                json.dumps(tags, ensure_ascii=False),
                colorblind_safe,
                json.dumps(colorblind_types, ensure_ascii=False),
                description,
                json.dumps(source, ensure_ascii=False),
                name,
            ),
        )
    else:
        # Insert new custom colormap (ID starts from 10001)
        cur.execute("SELECT MAX(id) FROM cmaps WHERE is_custom = 1")
        max_id = cur.fetchone()[0]
        new_id = 10001 if max_id is None else max_id + 1

        # Ensure ID is within the user range
        if new_id < 10001:
            new_id = 10001

        cur.execute(
            "INSERT INTO cmaps (id, name, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, is_custom, source) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)",
            (
                new_id,
                name,
                json.dumps(colors, ensure_ascii=False),
                cmap_type,
                json.dumps(tags, ensure_ascii=False),
                colorblind_safe,
                json.dumps(colorblind_types, ensure_ascii=False),
                description,
                json.dumps(source, ensure_ascii=False),
            ),
        )

    conn.commit()
    # Return the id
    cur.execute("SELECT id FROM cmaps WHERE name = ?", (name,))
    cmap_id = cur.fetchone()[0]
    conn.close()
    return cmap_id


def _delete(name):
    """Delete a user-defined colormap. Built-in colormaps cannot be deleted."""
    conn = _get_conn()
    cur = conn.cursor()
    cur.execute("SELECT is_custom FROM cmaps WHERE name = ?", (name,))
    existing = cur.fetchone()

    if existing is None:
        conn.close()
        raise ValueError(f"Colormap '{name}' not found in database.")

    if existing[0] == 0:
        conn.close()
        raise ValueError(f"Cannot delete built-in colormap '{name}'.")

    cur.execute("DELETE FROM cmaps WHERE name = ?", (name,))
    conn.commit()
    conn.close()


def _export_custom(filepath=None):
    """Export all user-defined colormaps to a JSON file."""
    if filepath is None:
        filepath = str(_USER_DIR / "cmap_export.json")

    records = _query_all(is_custom=True)
    data = [
        {
            "name": r["name"],
            "colors": r["colors"],
            "cmap_type": r["cmap_type"],
            "tags": r["tags"],
            "colorblind_safe": r["colorblind_safe"],
            "colorblind_types": r["colorblind_types"],
            "description": r["description"],
            "source": r["source"],
        }
        for r in records
    ]

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return filepath


def _import_data(filepath):
    """Import colormaps from a JSON export file. Returns list of (name, id)."""
    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    results = []
    for item in data:
        cmap_id = _insert(
            name=item["name"],
            colors=item["colors"],
            cmap_type=item["cmap_type"],
            tags=item.get("tags", []),
            colorblind_safe=item.get("colorblind_safe", "none"),
            colorblind_types=item.get("colorblind_types", []),
            description=item.get("description", ""),
            source=item.get("source", []),
        )
        results.append((item["name"], cmap_id))

    return results
