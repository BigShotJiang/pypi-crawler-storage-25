# Installation

## 稳定版（推荐）

```bash
pip install multicolor
```

## 开发版

从 GitHub 安装最新开发版本：

```bash
pip install git+https://github.com/zbhgis/multicolor.git
```

或手动 clone 后本地安装：

```bash
git clone https://github.com/zbhgis/multicolor.git
cd multicolor
pip install -e .
```

## 环境要求

- **Python >= 3.10**
- 依赖包：

```
cartopy>=0.21.0
matplotlib>=3.7.0
numpy>=1.24.0
```
