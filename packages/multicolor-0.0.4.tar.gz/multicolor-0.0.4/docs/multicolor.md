
# multicolor module

::: multicolor.cmap
    options:
        show_root_heading: true

::: multicolor.batch
    options:
        show_root_heading: true
