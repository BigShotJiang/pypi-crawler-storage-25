# Usage

## 基础用法

```python
from multicolor import cmap, batch_cmaps
```

### 获取色带

```python
# 按名称获取
viridis = cmap.get("Viridis")

# 按 ID 获取
cm = cmap.get_by_id(1)
```

### 筛选与查询

```python
# 按类型筛选
for _, name, _ in cmap.list(cmap_type="sequential"):
    print(name)

# 按色盲兼容性筛选
names = cmap.names(colorblind_safe="any")

# 只看内置 / 自定义
cmap.list(is_custom=False)  # 内置色带
cmap.list(is_custom=True)   # 用户自定义色带

# 关键词搜索
cmap.list(keyword="temperature")
```

### 添加自定义色带

```python
cmap.add(
    name="MyCmap",
    colors=["#ff0000", "#00ff00"],
    cmap_type="sequential",
    tags=["custom"],
)
```

### 装饰器批量绘图

```python
@batch_cmaps(["Viridis", "Plasma"])
def draw(cmap_obj):
    # 自动循环两次
    pass

@batch_cmaps(query_func=lambda: cmap.names(cmap_type="diverging"))
def draw_all(cmap_obj):
    # 动态获取色带列表
    pass
```

## 完整示例

更多详细用法见 [Examples](examples/01_basic_preview.ipynb)：

- [基础色带预览](examples/01_basic_preview.ipynb)
- [色带筛选与查询](examples/02_filter_and_query.ipynb)
- [装饰器批量预览](examples/03_batch_preview.ipynb)
- [自定义色带](examples/04_custom_cmap.ipynb)
