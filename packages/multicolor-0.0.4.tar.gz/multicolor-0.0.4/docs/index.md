# Welcome to multicolor

[![PyPI version](https://img.shields.io/pypi/v/multicolor.svg)](https://pypi.python.org/pypi/multicolor)
[![License](https://img.shields.io/github/license/zbhgis/multicolor)](https://github.com/zbhgis/multicolor)

**A Python package for colormap management and batch plotting.**

- Free software: MIT License
- Documentation: <https://zbhgis.github.io/multicolor>
- Source code: <https://github.com/zbhgis/multicolor>

## Features

- **色带数据库**：基于 SQLite 的内置 12 条色带，支持标签、类型、色盲兼容性、关键词筛选
- **色带工厂**：从数据库生成 `matplotlib` Colormap 对象（Sequential / Diverging / Qualitative）
- **自定义色带**：用户可添加自己的色带，支持同名覆盖保护（内置色带不可覆盖）
- **自动同步**：升级包时自动同步新版内置色带，同时保留用户自定义内容
- **装饰器批量绘图**：`@batch_cmaps` 一键将同一绘图函数应用到多个色带
- **多子图导出**：支持 single（独立窗口）和 grid（单图多子图）两种布局

## Quick Start

```python
from multicolor import cmap, batch_cmaps

# 获取内置色带
viridis = cmap.get("Viridis")

# 筛选：所有兼容 deutan 的 sequential 色带
names = cmap.names(cmap_type="sequential", colorblind_safe="deutan")

# 批量预览
@batch_cmaps(["Viridis", "Plasma", "Inferno"])
def show(cm):
    cmap.preview(cm)

show()
```
