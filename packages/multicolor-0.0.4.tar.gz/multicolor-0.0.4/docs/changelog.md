# Changelog

## v0.0.3 (Unreleased)

**New Features**:

- **色带数据库（DB）**：基于 SQLite 的 `cmap.db` 内置 12 条色带，支持按类型、标签、色盲兼容性、关键词筛选
- **色带工厂**：从数据库生成 `matplotlib` Colormap 对象，支持 Sequential / Diverging / Qualitative 三种类型
- **自定义色带**：用户可通过 `cmap.add()` 添加自己的色带，内置色带受保护不可覆盖
- **自动同步**：升级包时自动同步新版内置色带，同时保留用户自定义内容
- **装饰器批量绘图**：`@batch_cmaps` 一键将同一绘图函数应用到多个色带
- **多子图导出**：支持 single（独立窗口）和 grid（单图多子图）两种布局
- **ID 分区机制**：内置色带 1-10000，自定义色带 10001 起递增
- **`is_custom` 筛选**：`cmap.list()` / `cmap.names()` 新增 `is_custom` 参数

**Improvements**:

- 数据库迁移机制（`_migrate_db`）自动适配已有用户库
- 用户自定义色带默认 50 像素高度，预览更清晰
- 4 个示例 notebook 覆盖全部功能

**Bug Fixes**:

- 修复 `preview()` 色带高度过细的问题
- 修复 `batch_cmaps` grid 模式所有色带显示相同颜色的问题
- 修复 `_sync_builtins()` 递归调用导致的 RecursionError
- 修复 CI Python 版本兼容性问题（最低 3.10）
- 修复 MkDocs API 文档引用不存在的模块

## v0.0.2 - 2026-05-17

- 测试初始化是否成功

## v0.0.1 - 2026-05-17

- 项目初始化
