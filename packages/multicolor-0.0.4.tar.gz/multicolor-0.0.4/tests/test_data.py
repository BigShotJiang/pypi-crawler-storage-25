#!/usr/bin/env python

"""Tests for `multicolor.data` module."""

import hashlib
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, MagicMock
from urllib.error import URLError

from multicolor import data


class TestCatalogLoading(unittest.TestCase):
    """Tests for catalog loading and entry lookup."""

    def test_load_catalog_returns_datasets(self):
        """Catalog should load and contain datasets."""
        catalog = data._load_catalog()
        self.assertIn("datasets", catalog)
        self.assertGreater(len(catalog["datasets"]), 0)

    def test_find_entry_by_name(self):
        """Should find a dataset entry by name."""
        entry = data._find_entry("ne_110m_admin_0_countries")
        self.assertEqual(entry["name"], "ne_110m_admin_0_countries")

    def test_find_entry_raises_for_unknown(self):
        """Should raise ValueError for unknown dataset name."""
        with self.assertRaises(ValueError) as ctx:
            data._find_entry("NonExistentDataset")
        self.assertIn("not found in catalog", str(ctx.exception))

    def test_cache_path_returns_correct_name(self):
        """Cache path should use the filename from the catalog entry."""
        entry = data._find_entry("ne_110m_admin_0_countries")
        expected = data._DATA_DIR / entry["filename"]
        self.assertEqual(data._cache_path("ne_110m_admin_0_countries"), expected)


class TestComputeSha256(unittest.TestCase):
    """Tests for SHA256 hash computation."""

    def test_compute_sha256_known_content(self):
        """Should compute correct SHA256 for known content."""
        fpath = Path(tempfile.mktemp(suffix=".txt"))
        fpath.write_bytes(b"hello world")
        h = data._compute_sha256(fpath)
        fpath.unlink()
        expected = hashlib.sha256(b"hello world").hexdigest()
        self.assertEqual(h, expected)


class TestVerifyHash(unittest.TestCase):
    """Tests for hash verification."""

    def test_verify_hash_passes(self):
        """Should pass when hash matches."""
        fpath = Path(tempfile.mktemp(suffix=".txt"))
        fpath.write_bytes(b"test data")
        expected = hashlib.sha256(b"test data").hexdigest()
        data._verify_hash(fpath, expected)
        fpath.unlink()

    def test_verify_hash_raises_on_mismatch(self):
        """Should raise HashError and delete file when hash mismatches."""
        fpath = Path(tempfile.mktemp(suffix=".txt"))
        fpath.write_bytes(b"test data")
        with self.assertRaises(data.HashError):
            data._verify_hash(fpath, "0" * 64)
        self.assertFalse(fpath.exists())

    def test_verify_hash_skips_empty(self):
        """Should not raise when expected hash is empty string."""
        fpath = Path(tempfile.mktemp(suffix=".txt"))
        fpath.write_bytes(b"anything")
        data._verify_hash(fpath, "")
        fpath.unlink()


class TestDataModule(unittest.TestCase):
    """Tests for public data API with mocked downloads."""

    def setUp(self):
        self.tmp_data = tempfile.TemporaryDirectory()
        self._orig_data_dir = data._DATA_DIR
        data._DATA_DIR = Path(self.tmp_data.name)

    def tearDown(self):
        self.tmp_data.cleanup()
        data._DATA_DIR = self._orig_data_dir

    def test_list_returns_all_entries(self):
        """list() should return all catalog entries with available field."""
        result = data.list()
        catalog = data._load_catalog()
        self.assertEqual(len(result), len(catalog["datasets"]))
        for entry in result:
            self.assertIn("name", entry)
            self.assertIn("type", entry)
            self.assertIn("available", entry)

    def test_is_available_false_for_uncached(self):
        """is_available should return False for uncached datasets."""
        self.assertFalse(data.is_available("ne_110m_admin_0_countries"))

    def test_is_available_raises_for_unknown(self):
        """is_available should raise ValueError for unknown name."""
        with self.assertRaises(ValueError):
            data.is_available("NonExistent")

    def _mock_download(self, url, dest, reporthook=None):
        """Helper: write a simple file to simulate download."""
        Path(dest).write_text(f"mock data from {url}")

    @patch("multicolor.data.urllib.request.urlretrieve")
    def test_get_downloads_and_caches(self, mock_retrieve):
        """get() should download and cache the file."""
        mock_retrieve.side_effect = self._mock_download

        path = data.get("srtm_90m_asia")
        self.assertTrue(path.exists())
        self.assertEqual(path.parent, data._DATA_DIR)
        mock_retrieve.assert_called_once()

    @patch("multicolor.data.urllib.request.urlretrieve")
    def test_get_returns_cached_without_download(self, mock_retrieve):
        """get() should not download if file is already cached."""
        mock_retrieve.side_effect = self._mock_download

        path1 = data.get("srtm_90m_asia")
        self.assertTrue(path1.exists())
        self.assertTrue(mock_retrieve.called)

        mock_retrieve.reset_mock()
        path2 = data.get("srtm_90m_asia")
        self.assertEqual(path1, path2)
        mock_retrieve.assert_not_called()

    @patch("multicolor.data.urllib.request.urlretrieve")
    def test_get_force_redownloads(self, mock_retrieve):
        """get(force=True) should re-download even if cached."""
        mock_retrieve.side_effect = self._mock_download

        data.get("srtm_90m_asia")
        mock_retrieve.reset_mock()

        data.get("srtm_90m_asia", force=True)
        mock_retrieve.assert_called_once()

    @patch("multicolor.data.urllib.request.urlretrieve")
    def test_get_raises_for_unknown_name(self, mock_retrieve):
        """get() should raise ValueError for unknown dataset name."""
        with self.assertRaises(ValueError):
            data.get("NonExistent")

    @patch("multicolor.data.urllib.request.urlretrieve")
    @patch("multicolor.data._load_catalog")
    def test_get_hash_mismatch_raises(self, mock_catalog, mock_retrieve):
        """get() should raise HashError when hash doesn't match."""
        fake = {
            "version": 1,
            "datasets": [
                {
                    "name": "srtm_90m_asia",
                    "type": "raster",
                    "format": "tif",
                    "url": "https://example.com/srtm_90m_asia.tif",
                    "filename": "srtm_90m_asia.tif",
                    "sha256": "0" * 64,
                    "size_hint": "45.0 MB",
                    "description": "test",
                    "archive": False,
                }
            ],
        }
        mock_catalog.return_value = fake

        def _mock_download(url, dest, reporthook=None):
            Path(dest).write_text("this content won't match the hash")

        mock_retrieve.side_effect = _mock_download

        with self.assertRaises(data.HashError):
            data.get("srtm_90m_asia")

    @patch("multicolor.data.urllib.request.urlretrieve")
    def test_get_network_failure_raises(self, mock_retrieve):
        """get() should raise DownloadError on network failure."""
        mock_retrieve.side_effect = URLError("connection refused")

        with self.assertRaises(data.DownloadError):
            data.get("srtm_90m_asia")

        target = data._DATA_DIR / "srtm_90m_asia.tif"
        self.assertFalse(target.exists())
        self.assertFalse(target.with_suffix(".tif.part").exists())

    def test_get_creates_data_directory(self):
        """get() should create the data directory if it doesn't exist."""
        mock_download = lambda url, dest, reporthook=None: Path(dest).write_text(
            "data"
        )

        with patch("multicolor.data.urllib.request.urlretrieve", mock_download):
            data.get("srtm_90m_asia")

        self.assertTrue(data._DATA_DIR.exists())

    @patch("multicolor.data.urllib.request.urlretrieve")
    def test_remove_deletes_cached_file(self, mock_retrieve):
        """remove() should delete the cached file."""
        mock_retrieve.side_effect = self._mock_download

        path = data.get("srtm_90m_asia")
        self.assertTrue(path.exists())

        data.remove("srtm_90m_asia")
        self.assertFalse(path.exists())

    def test_remove_noop_if_not_cached(self):
        """remove() should not raise if file is not cached."""
        data.remove("srtm_90m_asia")

    def test_remove_raises_for_unknown_name(self):
        """remove() should raise ValueError for unknown name."""
        with self.assertRaises(ValueError):
            data.remove("NonExistent")


if __name__ == "__main__":
    unittest.main()
