#!/usr/bin/env python

"""Tests for `multicolor.cmap` module."""

import unittest
from matplotlib.colors import LinearSegmentedColormap, ListedColormap
from multicolor import cmap


class TestCmapFactory(unittest.TestCase):
    """Tests for public cmap API."""

    def test_get_by_name(self):
        """Should return a Colormap object by name."""
        cm = cmap.get("Viridis")
        self.assertIsInstance(cm, LinearSegmentedColormap)
        self.assertEqual(cm.name, "Viridis")

    def test_get_by_name_raises_for_unknown(self):
        """Should raise KeyError for non-existent name."""
        with self.assertRaises(KeyError):
            cmap.get("NonExistentCmap")

    def test_get_by_id(self):
        """Should return a Colormap object by id."""
        cm = cmap.get_by_id(1)
        self.assertIsNotNone(cm)
        self.assertIsInstance(cm.name, str)

    def test_get_by_id_raises_for_unknown(self):
        """Should raise KeyError for non-existent id."""
        with self.assertRaises(KeyError):
            cmap.get_by_id(99999)

    def test_list_returns_tuples(self):
        """list() should return list of (id, name, cmap) tuples."""
        items = cmap.list()
        self.assertIsInstance(items, list)
        self.assertGreater(len(items), 0)
        for id_, name, cm in items:
            self.assertIsInstance(id_, int)
            self.assertIsInstance(name, str)
            self.assertTrue(hasattr(cm, "__call__"))  # it's a colormap

    def test_list_filters_by_type(self):
        """list() should filter by cmap_type."""
        items = cmap.list(cmap_type="diverging")
        self.assertTrue(len(items) > 0)
        # Verify we only got diverging colormaps
        all_types = cmap.list(cmap_type="sequential")
        all_sequential_names = {item[1] for item in all_types}
        for _, name, _ in items:
            self.assertNotIn(name, all_sequential_names)

    def test_list_filters_by_tag(self):
        """list() should filter by tag."""
        items = cmap.list(tag="common")
        self.assertTrue(len(items) > 0)

    def test_list_filters_by_colorblind(self):
        """list() should filter by colorblind_safe."""
        items = cmap.list(colorblind_safe="any")
        self.assertTrue(len(items) > 0)

    def test_list_filters_by_keyword(self):
        """list() should filter by keyword."""
        items = cmap.list(keyword="nightlights")
        self.assertGreater(len(items), 0)

    def test_list_limit(self):
        """list() should respect limit parameter."""
        items = cmap.list(limit=2)
        self.assertLessEqual(len(items), 2)

    def test_names_returns_list_of_strings(self):
        """names() should return a list of colormap name strings."""
        n = cmap.names()
        self.assertIsInstance(n, list)
        self.assertTrue(all(isinstance(x, str) for x in n))

    def test_names_returns_subset_of_list(self):
        """names() with same filters should match list() names."""
        full_list = cmap.list(tag="raster")
        name_list = cmap.names(tag="raster")
        list_names = [item[1] for item in full_list]
        self.assertEqual(list_names, name_list)

    def test_add_and_retrieve(self):
        """Adding a colormap should make it retrievable."""
        from multicolor.db import _get_conn

        # Clean up if exists from previous run
        try:
            conn = _get_conn()
            conn.execute("DELETE FROM cmaps WHERE name = 'TestAddCmap'")
            conn.commit()
            conn.close()
        except Exception:
            pass
        cmap.add(
            name="TestAddCmap",
            colors=["#ff0000", "#00ff00", "#0000ff"],
            cmap_type="sequential",
            tags=["test", "add"],
            colorblind_safe="none",
            description="test add colormap",
        )
        cm = cmap.get("TestAddCmap")
        self.assertEqual(cm.name, "TestAddCmap")

    def test_sequential_creates_linear_segmented(self):
        """Sequential type should produce LinearSegmentedColormap."""
        cm = cmap.get("Viridis")
        self.assertIsInstance(cm, LinearSegmentedColormap)

    def test_qualitative_creates_listed(self):
        """Qualitative type should produce ListedColormap."""
        cm = cmap.get("LandUse")
        self.assertIsInstance(cm, ListedColormap)

    def test_diverging_creates_linear_segmented(self):
        """Diverging type should produce LinearSegmentedColormap."""
        cm = cmap.get("RdYlGn")
        self.assertIsInstance(cm, LinearSegmentedColormap)

    def test_hex_to_rgb_conversion(self):
        """_hex_to_rgb should convert hex to 0-1 RGB tuples."""
        result = cmap._hex_to_rgb("#ff0000")
        self.assertEqual(result, (1.0, 0.0, 0.0))

    def test_build_cmap_sequential(self):
        """_build_cmap should work for sequential type."""
        cm = cmap._build_cmap("Test", ["#000000", "#ffffff"], "sequential")
        self.assertIsInstance(cm, LinearSegmentedColormap)

    def test_build_cmap_qualitative(self):
        """_build_cmap should work for qualitative type."""
        cm = cmap._build_cmap("Test", ["#ff0000", "#00ff00"], "qualitative")
        self.assertIsInstance(cm, ListedColormap)

    def test_add_overwrites_custom_rejects_builtin(self):
        """cmap.add() should reject overwriting built-in colormaps."""
        with self.assertRaises(ValueError):
            cmap.add(
                name="Viridis",
                colors=["#000000", "#ffffff"],
                cmap_type="sequential",
            )

    def test_add_and_overwrite_custom(self):
        """cmap.add() should allow overwriting user-defined colormaps."""
        from multicolor.db import _get_conn

        try:
            conn = _get_conn()
            conn.execute("DELETE FROM cmaps WHERE name = 'TestOverwriteCmap'")
            conn.commit()
            conn.close()
        except Exception:
            pass
        cmap.add(
            name="TestOverwriteCmap",
            colors=["#111111", "#222222"],
            cmap_type="sequential",
        )
        cmap.add(
            name="TestOverwriteCmap",
            colors=["#333333", "#444444"],
            cmap_type="sequential",
        )
        cm = cmap.get("TestOverwriteCmap")
        self.assertEqual(cm.name, "TestOverwriteCmap")

    def test_list_filters_by_is_custom(self):
        """list() should filter by is_custom flag."""
        builtin_items = cmap.list(is_custom=False)
        self.assertTrue(len(builtin_items) > 0)
        self.assertTrue(all(item[0] < 10001 for item in builtin_items))

        custom_items = cmap.list(is_custom=True)
        self.assertTrue(all(item[0] >= 10001 for item in custom_items))

    def test_names_filters_by_is_custom(self):
        """names() should filter by is_custom flag."""
        builtin_names = cmap.names(is_custom=False)
        self.assertTrue(len(builtin_names) > 0)
        self.assertIn("Viridis", builtin_names)

        custom_names = cmap.names(is_custom=True)
        for name in custom_names:
            self.assertNotIn(name, builtin_names)

    def test_custom_cmap_has_id_above_10000(self):
        """User-added colormaps should have IDs >= 10001."""
        from multicolor.db import _get_conn

        try:
            conn = _get_conn()
            conn.execute("DELETE FROM cmaps WHERE name = 'TestIdRange'")
            conn.commit()
            conn.close()
        except Exception:
            pass
        cmap.add(name="TestIdRange", colors=["#123456"], cmap_type="sequential")
        items = cmap.list(is_custom=True, keyword="TestIdRange")
        self.assertGreaterEqual(items[0][0], 10001)

        conn = _get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'TestIdRange'")
        conn.commit()
        conn.close()

    def test_list_filters_by_source(self):
        """list() should filter by source."""
        items = cmap.list(source="matplotlib")
        self.assertTrue(len(items) > 0)
        self.assertIn("Viridis", [item[1] for item in items])

    def test_names_filters_by_source(self):
        """names() should filter by source."""
        names = cmap.names(source="matplotlib")
        self.assertIn("Viridis", names)

    def test_add_with_source(self):
        """cmap.add() with source should store it correctly."""
        from multicolor.db import _get_conn

        try:
            conn = _get_conn()
            conn.execute("DELETE FROM cmaps WHERE name = 'TestAddSource'")
            conn.commit()
            conn.close()
        except Exception:
            pass
        cmap.add(
            name="TestAddSource",
            colors=["#ff0000"],
            cmap_type="sequential",
            source=["colorbrewer"],
        )
        names = cmap.names(source="colorbrewer")
        self.assertIn("TestAddSource", names)
        conn = _get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'TestAddSource'")
        conn.commit()
        conn.close()

    def test_add_source_default_empty_list(self):
        """cmap.add() without source should default to empty list."""
        from multicolor.db import _get_conn

        try:
            conn = _get_conn()
            conn.execute("DELETE FROM cmaps WHERE name = 'TestSourceDefault'")
            conn.commit()
            conn.close()
        except Exception:
            pass
        cmap.add(name="TestSourceDefault", colors=["#123456"], cmap_type="sequential")
        names = cmap.names(keyword="TestSourceDefault")
        self.assertEqual(names, ["TestSourceDefault"])
        conn = _get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'TestSourceDefault'")
        conn.commit()
        conn.close()

    def test_add_rejects_invalid_hex(self):
        """cmap.add() should reject invalid hex colors."""
        with self.assertRaises(ValueError):
            cmap.add(name="BadHex", colors=["not-a-color"], cmap_type="sequential")

    def test_add_rejects_invalid_cmap_type(self):
        """cmap.add() should reject invalid cmap_type."""
        with self.assertRaises(ValueError):
            cmap.add(name="BadType", colors=["#ff0000"], cmap_type="gradient")

    def test_add_rejects_empty_name(self):
        """cmap.add() should reject empty name."""
        with self.assertRaises(ValueError):
            cmap.add(name="", colors=["#ff0000"], cmap_type="sequential")

    def test_add_rejects_empty_colors(self):
        """cmap.add() should reject empty colors list."""
        with self.assertRaises(ValueError):
            cmap.add(name="EmptyColors", colors=[], cmap_type="sequential")

    def test_remove_custom(self):
        """cmap.remove() should delete a user-defined colormap."""
        from multicolor.db import _get_conn

        try:
            conn = _get_conn()
            conn.execute("DELETE FROM cmaps WHERE name = 'TestRemove'")
            conn.commit()
            conn.close()
        except Exception:
            pass
        cmap.add(name="TestRemove", colors=["#ff0000"], cmap_type="sequential")
        self.assertIsNotNone(cmap.get("TestRemove"))
        cmap.remove("TestRemove")
        with self.assertRaises(KeyError):
            cmap.get("TestRemove")

    def test_remove_builtin_raises(self):
        """cmap.remove() should reject deleting a built-in colormap."""
        with self.assertRaises(ValueError):
            cmap.remove("Viridis")

    def test_remove_nonexistent_raises(self):
        """cmap.remove() should reject deleting a non-existent colormap."""
        with self.assertRaises(ValueError):
            cmap.remove("NonExistent")

    def test_records_returns_raw_data(self):
        """cmap.records() should return raw record dicts without building Colormap objects."""
        recs = cmap.records(limit=1)
        self.assertEqual(len(recs), 1)
        self.assertIsInstance(recs[0], dict)
        self.assertIn("name", recs[0])
        self.assertIn("colors", recs[0])
        # records should NOT have a 'cmap' key (no Colormap object built)
        self.assertNotIn("cmap", recs[0])

    def test_export_and_import(self):
        """cmap.export() and cmap.import_data() should round-trip custom colormaps."""
        import os
        import tempfile
        from multicolor.db import _get_conn

        conn = _get_conn()
        conn.execute("DELETE FROM cmaps WHERE is_custom = 1")
        conn.commit()
        conn.close()

        cmap.add(
            name="RoundTrip",
            colors=["#111111", "#222222"],
            cmap_type="diverging",
            tags=["test"],
        )

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            cmap.export(path)
            self.assertTrue(os.path.exists(path))

            # Verify export contains our colormap
            results = cmap.import_data(path)
            self.assertGreaterEqual(len(results), 1)
            names = [r[0] for r in results]
            self.assertIn("RoundTrip", names)

            # Delete and re-import
            cmap.remove("RoundTrip")
            with self.assertRaises(KeyError):
                cmap.get("RoundTrip")

            # Re-import
            cmap.import_data(path)
            cm = cmap.get("RoundTrip")
            self.assertEqual(cm.name, "RoundTrip")
        finally:
            if os.path.exists(path):
                os.unlink(path)


if __name__ == "__main__":
    unittest.main()
