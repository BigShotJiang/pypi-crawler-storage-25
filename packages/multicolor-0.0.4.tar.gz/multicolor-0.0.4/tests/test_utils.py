#!/usr/bin/env python

"""Tests for `multicolor.utils` module."""

import unittest
from matplotlib.colors import LinearSegmentedColormap, ListedColormap
from multicolor.utils import (
    validate_hex,
    validate_colors,
    validate_cmap_type,
    validate_name,
    hex_to_rgb,
    build_cmap,
    _VALID_TYPES,
)


class TestValidation(unittest.TestCase):
    """Tests for input validation functions."""

    def test_validate_hex_valid(self):
        """Valid hex strings should pass without error."""
        validate_hex("#ff0000")
        validate_hex("#00FF00")
        validate_hex("#abcdef")

    def test_validate_hex_missing_hash(self):
        """Hex without leading # should fail."""
        with self.assertRaises(ValueError):
            validate_hex("ff0000")

    def test_validate_hex_invalid_chars(self):
        """Hex with non-hex characters should fail."""
        with self.assertRaises(ValueError):
            validate_hex("#gggggg")

    def test_validate_hex_too_short(self):
        """Short hex string should fail."""
        with self.assertRaises(ValueError):
            validate_hex("#ff")

    def test_validate_hex_empty(self):
        """Empty string should fail."""
        with self.assertRaises(ValueError):
            validate_hex("")

    def test_validate_colors_valid(self):
        """Valid color list should pass."""
        validate_colors(["#ff0000", "#00ff00"])

    def test_validate_colors_empty_list(self):
        """Empty list should fail."""
        with self.assertRaises(ValueError):
            validate_colors([])

    def test_validate_colors_not_a_list(self):
        """Non-list input should fail."""
        with self.assertRaises(ValueError):
            validate_colors("#ff0000")

    def test_validate_colors_contains_invalid(self):
        """List with an invalid hex should fail."""
        with self.assertRaises(ValueError):
            validate_colors(["#ff0000", "invalid"])

    def test_validate_cmap_type_valid(self):
        """Valid cmap types should pass."""
        for t in _VALID_TYPES:
            validate_cmap_type(t)

    def test_validate_cmap_type_invalid(self):
        """Invalid cmap type should fail."""
        with self.assertRaises(ValueError):
            validate_cmap_type("gradient")

    def test_validate_name_valid(self):
        """Valid name should pass."""
        validate_name("Viridis")

    def test_validate_name_empty(self):
        """Empty name should fail."""
        with self.assertRaises(ValueError):
            validate_name("")

    def test_validate_name_whitespace(self):
        """Whitespace-only name should fail."""
        with self.assertRaises(ValueError):
            validate_name("   ")

    def test_validate_name_none(self):
        """None name should fail."""
        with self.assertRaises(ValueError):
            validate_name(None)


class TestHexToRgb(unittest.TestCase):
    """Tests for hex_to_rgb conversion."""

    def test_red(self):
        self.assertEqual(hex_to_rgb("#ff0000"), (1.0, 0.0, 0.0))

    def test_green(self):
        self.assertEqual(hex_to_rgb("#00ff00"), (0.0, 1.0, 0.0))

    def test_blue(self):
        self.assertEqual(hex_to_rgb("#0000ff"), (0.0, 0.0, 1.0))

    def test_white(self):
        self.assertEqual(hex_to_rgb("#ffffff"), (1.0, 1.0, 1.0))

    def test_black(self):
        self.assertEqual(hex_to_rgb("#000000"), (0.0, 0.0, 0.0))

    def test_lowercase(self):
        self.assertEqual(hex_to_rgb("#abcdef"), (0xAB / 255, 0xCD / 255, 0xEF / 255))


class TestBuildCmap(unittest.TestCase):
    """Tests for build_cmap factory."""

    def test_sequential_returns_linear_segmented(self):
        cmap = build_cmap("test", ["#ff0000", "#00ff00"], "sequential")
        self.assertIsInstance(cmap, LinearSegmentedColormap)
        self.assertEqual(cmap.name, "test")

    def test_diverging_returns_linear_segmented(self):
        cmap = build_cmap("test", ["#ff0000", "#ffffff", "#0000ff"], "diverging")
        self.assertIsInstance(cmap, LinearSegmentedColormap)

    def test_qualitative_returns_listed(self):
        cmap = build_cmap("test", ["#ff0000", "#00ff00", "#0000ff"], "qualitative")
        self.assertIsInstance(cmap, ListedColormap)


if __name__ == "__main__":
    unittest.main()
