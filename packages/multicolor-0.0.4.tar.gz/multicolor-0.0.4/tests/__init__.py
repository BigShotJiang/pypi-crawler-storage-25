"""Unit test package for multicolor."""
