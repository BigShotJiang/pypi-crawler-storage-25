#!/usr/bin/env python

"""Tests for `multicolor.render` module."""

import os
import tempfile
import unittest
import numpy as np
from matplotlib.colors import ListedColormap
from multicolor.render import ColormapRenderer


class TestColormapRenderer(unittest.TestCase):
    """Tests for ColormapRenderer."""

    def setUp(self):
        self.cmap = ListedColormap(["#ff0000", "#00ff00", "#0000ff"], name="test")

    def test_to_image_returns_rgba_array(self):
        """to_image should return an RGBA numpy array."""
        img = ColormapRenderer.to_image(self.cmap)
        self.assertIsInstance(img, np.ndarray)
        self.assertEqual(img.ndim, 3)
        self.assertEqual(img.shape[2], 4)  # RGBA

    def test_to_image_horizontal_shape(self):
        """Horizontal to_image should be wider than tall."""
        img = ColormapRenderer.to_image(self.cmap, size=(10, 1), dpi=100)
        self.assertGreater(img.shape[1], img.shape[0])

    def test_to_image_vertical_shape(self):
        """Vertical to_image should be taller than wide."""
        img = ColormapRenderer.to_image(
            self.cmap, orientation="vertical", size=(1, 10), dpi=100
        )
        self.assertGreater(img.shape[0], img.shape[1])

    def test_to_file_creates_png(self):
        """to_file should create a PNG file."""
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            path = f.name
        try:
            ColormapRenderer.to_file(self.cmap, path, size=(4, 0.5), dpi=100)
            self.assertTrue(os.path.exists(path))
            self.assertGreater(os.path.getsize(path), 0)
        finally:
            os.unlink(path)

    def test_render_grid_returns_fig(self):
        """render_grid should return a figure and axes."""
        cmaps = [("test1", self.cmap), ("test2", self.cmap)]
        import matplotlib.pyplot as plt

        try:
            fig, axes = ColormapRenderer.render_grid(cmaps, cols=2)
            self.assertIsNotNone(fig)
            self.assertIsNotNone(axes)
            self.assertEqual(len(axes), 2)
            plt.close(fig)
        except Exception:
            plt.close("all")
            raise

    def test_render_grid_empty_returns_none(self):
        """render_grid with empty list should return None."""
        fig, axes = ColormapRenderer.render_grid([])
        self.assertIsNone(fig)
        self.assertIsNone(axes)

    def test_render_grid_single_cmap(self):
        """render_grid with single cmap should work."""
        cmaps = [("only", self.cmap)]
        import matplotlib.pyplot as plt

        try:
            fig, axes = ColormapRenderer.render_grid(cmaps)
            self.assertIsNotNone(fig)
            self.assertIsNotNone(axes)
            plt.close(fig)
        except Exception:
            plt.close("all")
            raise


if __name__ == "__main__":
    unittest.main()
