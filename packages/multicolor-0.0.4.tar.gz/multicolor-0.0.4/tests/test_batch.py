#!/usr/bin/env python

"""Tests for `multicolor.batch` module."""

import unittest
from multicolor import batch_cmaps, batch_colors, cmap


class TestBatch(unittest.TestCase):
    """Tests for the @batch_cmaps() decorator."""

    def test_name_list(self):
        """@batch_cmaps(["Viridis", "Plasma"]) should work."""
        names = []

        @batch_cmaps(["Viridis", "Plasma", "Inferno"])
        def capture(c):
            names.append(c.name)

        capture()
        self.assertEqual(len(names), 3)
        self.assertIn("Viridis", names)

    def test_id_list(self):
        """@batch_cmaps([1, 2, 3]) should resolve IDs to names."""
        items = cmap.list(limit=3)
        ids = [item[0] for item in items]
        expected_names = [item[1] for item in items]

        names = []

        @batch_cmaps(ids)
        def capture(c):
            names.append(c.name)

        capture()
        self.assertEqual(len(names), 3)
        for n in names:
            self.assertIn(n, expected_names)

    def test_collection(self):
        """@batch_cmaps(collection) should iterate the collection's names."""
        names = []
        col = cmap.collection(cmap_type="sequential", limit=2)

        @batch_cmaps(col)
        def capture(c):
            names.append(c.name)

        capture()
        self.assertEqual(len(names), 2)
        for n in names:
            self.assertIn(n, col.names)

    def test_filter_kwargs(self):
        """@batch_cmaps(cmap_type="...") should delegate to cmap.names()."""
        names = []

        @batch_cmaps(cmap_type="diverging", limit=2)
        def capture(c):
            names.append(c.name)

        capture()
        self.assertEqual(len(names), 2)

    def test_query_func(self):
        """@batch_cmaps(query_func=...) should support callback style."""
        names = []

        @batch_cmaps(query_func=lambda: cmap.names(is_custom=False, limit=2))
        def capture(c):
            names.append(c.name)

        capture()
        self.assertEqual(len(names), 2)

    def test_empty_list(self):
        """@batch_cmaps([]) should do nothing."""
        call_count = [0]

        @batch_cmaps([])
        def dummy(c):
            call_count[0] += 1

        dummy()
        self.assertEqual(call_count[0], 0)

    def test_empty_kwargs(self):
        """@batch_cmaps(cmap_type="nonexistent") should do nothing."""
        call_count = [0]

        @batch_cmaps(cmap_type="nonexistent_type")
        def dummy(c):
            call_count[0] += 1

        dummy()
        self.assertEqual(call_count[0], 0)

    def test_unknown_id_raises(self):
        """@batch_cmaps([99999]) should raise KeyError at decoration time."""
        with self.assertRaises(KeyError):

            @batch_cmaps([99999])
            def dummy(c):
                pass

    def test_layout_grid(self):
        """@batch_cmaps([...], layout="grid") should not raise."""

        @batch_cmaps(["Viridis"], layout="grid", cols=1)
        def dummy(c, ax=None):
            pass

        dummy()

    def test_layout_grid_multiple(self):
        """@batch_cmaps([...], layout="grid", cols=2) should work with multiple colormaps."""

        @batch_cmaps(["Viridis", "Plasma"], layout="grid", cols=2)
        def dummy(c, ax=None):
            pass

        dummy()

    def test_id_list_with_grid(self):
        """@batch_cmaps([1, 2], layout="grid") should work."""
        items = cmap.list(limit=2)
        ids = [item[0] for item in items]

        @batch_cmaps(ids, layout="grid", cols=2)
        def dummy(c, ax=None):
            pass

        dummy()


class TestBatchColors(unittest.TestCase):
    """Tests for the @batch_colors() decorator."""

    def test_name_list(self):
        """@batch_colors(["Viridis", "Plasma"]) should pass raw records."""
        records = []

        @batch_colors(["Viridis", "Plasma", "Inferno"])
        def capture(record):
            records.append(record)

        capture()
        self.assertEqual(len(records), 3)
        names = [r["name"] for r in records]
        self.assertIn("Viridis", names)
        # Verify record structure has 'colors' field (hex list)
        self.assertIsInstance(records[0]["colors"], list)
        self.assertIsInstance(records[0]["colors"][0], str)

    def test_id_list(self):
        """@batch_colors([1, 2, 3]) should resolve IDs to records."""
        items = cmap.list(limit=3)
        ids = [item[0] for item in items]
        expected_names = [item[1] for item in items]

        records = []

        @batch_colors(ids)
        def capture(record):
            records.append(record)

        capture()
        self.assertEqual(len(records), 3)
        names = [r["name"] for r in records]
        for n in names:
            self.assertIn(n, expected_names)

    def test_collection(self):
        """@batch_colors(collection) should iterate records."""
        records = []
        col = cmap.collection(cmap_type="sequential", limit=2)

        @batch_colors(col)
        def capture(record):
            records.append(record)

        capture()
        self.assertEqual(len(records), 2)
        names = [r["name"] for r in records]
        for n in names:
            self.assertIn(n, col.names)

    def test_filter_kwargs(self):
        """@batch_colors(cmap_type="...") should delegate to cmap.names()."""
        records = []

        @batch_colors(cmap_type="diverging", limit=2)
        def capture(record):
            records.append(record)

        capture()
        self.assertEqual(len(records), 2)

    def test_query_func(self):
        """@batch_colors(query_func=...) should support callback style."""
        records = []

        @batch_colors(query_func=lambda: cmap.names(is_custom=False, limit=2))
        def capture(record):
            records.append(record)

        capture()
        self.assertEqual(len(records), 2)

    def test_empty_list(self):
        """@batch_colors([]) should do nothing."""
        call_count = [0]

        @batch_colors([])
        def dummy(record):
            call_count[0] += 1

        dummy()
        self.assertEqual(call_count[0], 0)

    def test_empty_kwargs(self):
        """@batch_colors(cmap_type="nonexistent") should do nothing."""
        call_count = [0]

        @batch_colors(cmap_type="nonexistent_type")
        def dummy(record):
            call_count[0] += 1

        dummy()
        self.assertEqual(call_count[0], 0)

    def test_unknown_id_raises(self):
        """@batch_colors([99999]) should raise KeyError at decoration time."""
        with self.assertRaises(KeyError):

            @batch_colors([99999])
            def dummy(record):
                pass

    def test_layout_grid(self):
        """@batch_colors([...], layout="grid") should not raise."""

        @batch_colors(["Viridis"], layout="grid", cols=1)
        def dummy(record, ax=None):
            pass

        dummy()

    def test_layout_grid_multiple(self):
        """@batch_colors([...], layout="grid") should work with multiple records."""

        @batch_colors(["Viridis", "Plasma"], layout="grid", cols=2)
        def dummy(record, ax=None):
            pass

        dummy()

    def test_record_has_full_data(self):
        """Records passed to func should contain all DB fields."""

        @batch_colors(["Viridis"], layout="single")
        def check(record):
            self.assertIn("id", record)
            self.assertIn("name", record)
            self.assertIn("colors", record)
            self.assertIn("cmap_type", record)
            self.assertIn("tags", record)
            self.assertIn("colorblind_safe", record)
            self.assertIn("colorblind_types", record)
            self.assertIn("description", record)
            self.assertIn("is_custom", record)
            self.assertIn("source", record)

        check()

    def test_colors_are_hex_strings(self):
        """Record colors should be hex color strings."""

        @batch_colors(["RdYlGn"], layout="single")
        def check(record):
            for c in record["colors"]:
                self.assertIsInstance(c, str)
                self.assertTrue(c.startswith("#"), f"Expected hex color, got {c}")

        check()


if __name__ == "__main__":
    unittest.main()
