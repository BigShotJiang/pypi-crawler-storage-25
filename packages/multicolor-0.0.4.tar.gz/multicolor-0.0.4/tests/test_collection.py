#!/usr/bin/env python

"""Tests for `multicolor.collection` module."""

import os
import tempfile
import unittest
from multicolor import cmap
from multicolor.collection import ColormapCollection


class TestColormapCollection(unittest.TestCase):
    """Tests for ColormapCollection."""

    def setUp(self):
        self.records = cmap.records()
        self.collection = cmap.collection()

    def test_collection_from_cmap(self):
        """cmap.collection() should return a ColormapCollection."""
        self.assertIsInstance(self.collection, ColormapCollection)

    def test_collection_len(self):
        """Collection should have same length as records."""
        self.assertEqual(len(self.collection), len(self.records))

    def test_collection_repr(self):
        """repr should include count."""
        self.assertIn(str(len(self.collection)), repr(self.collection))

    def test_names_property(self):
        """names should return list of names."""
        names = self.collection.names
        self.assertIsInstance(names, list)
        self.assertIn("Viridis", names)

    def test_records_property(self):
        """records should return list of dicts."""
        recs = self.collection.records
        self.assertIsInstance(recs, list)
        self.assertIsInstance(recs[0], dict)

    def test_filter_by_type(self):
        """filter(cmap_type=...) should return filtered collection."""
        seq = self.collection.filter(cmap_type="sequential")
        self.assertTrue(len(seq) > 0)
        for r in seq.records:
            self.assertEqual(r["cmap_type"], "sequential")

    def test_filter_by_tag(self):
        """filter(tag=...) should filter by tag."""
        common = self.collection.filter(tag="common")
        self.assertTrue(len(common) > 0)
        for r in common.records:
            self.assertIn("common", r["tags"])

    def test_filter_by_multiple_tags(self):
        """filter(tag=[...]) should require all tags (AND)."""
        result = self.collection.filter(tag=["common", "raster"])
        for r in result.records:
            self.assertIn("common", r["tags"])
            self.assertIn("raster", r["tags"])

    def test_filter_chaining(self):
        """filter() calls should chain (AND across calls)."""
        result = self.collection.filter(cmap_type="sequential").filter(tag="common")
        for r in result.records:
            self.assertEqual(r["cmap_type"], "sequential")
            self.assertIn("common", r["tags"])

    def test_filter_by_colorblind(self):
        """filter(colorblind_safe=...) should filter."""
        cb = self.collection.filter(colorblind_safe="any")
        self.assertTrue(len(cb) > 0)
        for r in cb.records:
            self.assertNotEqual(r["colorblind_safe"], "none")

    def test_filter_by_source(self):
        """filter(source=...) should filter by source."""
        mpl = self.collection.filter(source="matplotlib")
        self.assertTrue(len(mpl) > 0)
        for r in mpl.records:
            self.assertIn("matplotlib", r["source"])

    def test_filter_by_keyword(self):
        """filter(keyword=...) should fuzzy search."""
        result = self.collection.filter(keyword="nightlights")
        self.assertTrue(len(result) > 0)

    def test_group_by_type(self):
        """group_by('cmap_type') should return dict of collections."""
        groups = self.collection.group_by("cmap_type")
        self.assertIn("sequential", groups)
        self.assertIn("diverging", groups)
        total = sum(len(g) for g in groups.values())
        self.assertEqual(total, len(self.collection))

    def test_group_by_source(self):
        """group_by('source') should distribute colormaps to source groups."""
        groups = self.collection.group_by("source")
        self.assertIn("matplotlib", groups)
        self.assertGreater(len(groups["matplotlib"]), 0)
        # Total may exceed collection size since one cmap can be in multiple source groups
        total = sum(len(g) for g in groups.values())
        self.assertGreaterEqual(total, len(groups["matplotlib"]))

    def test_to_list(self):
        """to_list() should return (id, name, cmap) tuples."""
        items = self.collection.to_list()
        self.assertIsInstance(items, list)
        id_, name, cm = items[0]
        self.assertIsInstance(id_, int)
        self.assertIsInstance(name, str)
        self.assertTrue(hasattr(cm, "__call__"))

    def test_to_html_creates_file(self):
        """to_html() should create an HTML file."""
        small = self.collection.filter(cmap_type="sequential").filter(tag="common")
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            path = f.name
        try:
            result_path = small.to_html(path, title="Test Collection")
            self.assertEqual(result_path, path)
            self.assertTrue(os.path.exists(path))
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            self.assertIn("<!DOCTYPE html>", content)
            self.assertIn("Test Collection", content)
            self.assertIn("Viridis", content)
        finally:
            if os.path.exists(path):
                os.unlink(path)

    def test_export_images_creates_files(self):
        """export_images() should create PNG files."""
        small = (
            self.collection.filter(cmap_type="sequential")
            .filter(tag="common")
            .filter(source="matplotlib")
        )
        with tempfile.TemporaryDirectory() as tmpdir:
            small.export_images(tmpdir)
            # Should have created PNG files
            files = os.listdir(tmpdir)
            png_files = [f for f in files if f.endswith(".png")]
            self.assertEqual(len(png_files), len(small))


if __name__ == "__main__":
    unittest.main()
