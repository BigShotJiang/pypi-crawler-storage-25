#!/usr/bin/env python

"""Tests for `multicolor.db` module."""

import os
import sqlite3
import unittest
from multicolor import db


class TestDbInternal(unittest.TestCase):
    """Tests for internal db module functions."""

    def test_ensure_user_db_creates_file(self):
        """User db should be copied from bundled db on first access."""
        db._ensure_user_db()
        self.assertTrue(db._USER_DB.exists())

    def test_get_by_name_returns_record(self):
        """Should return a colormap record by name."""
        record = db._get_by_name("Viridis")
        self.assertIsNotNone(record)
        self.assertEqual(record["name"], "Viridis")

    def test_get_by_name_returns_none_for_unknown(self):
        """Should return None for non-existent colormap name."""
        record = db._get_by_name("NonExistentCmap")
        self.assertIsNone(record)

    def test_get_by_id_returns_record(self):
        """Should return a colormap record by id."""
        record = db._get_by_id(1)
        self.assertIsNotNone(record)
        self.assertIsInstance(record["id"], int)

    def test_get_by_id_returns_none_for_unknown(self):
        """Should return None for non-existent id."""
        record = db._get_by_id(99999)
        self.assertIsNone(record)

    def test_query_all_returns_all(self):
        """Should return all colormaps when no filters given."""
        records = db._query_all()
        self.assertGreater(len(records), 0)

    def test_query_all_by_type(self):
        """Should filter by cmap_type."""
        records = db._query_all(cmap_type="diverging")
        self.assertTrue(all(r["cmap_type"] == "diverging" for r in records))

    def test_query_all_by_tag(self):
        """Should filter by tag."""
        records = db._query_all(tag="common")
        self.assertTrue(all("common" in r["tags"] for r in records))

    def test_query_all_by_tag_list(self):
        """Should filter by multiple tags (AND)."""
        records = db._query_all(tag=["common", "raster"])
        for r in records:
            self.assertIn("common", r["tags"])
            self.assertIn("raster", r["tags"])

    def test_query_all_by_colorblind(self):
        """Should filter by colorblind_safe type."""
        records = db._query_all(colorblind_safe="deutan")
        self.assertTrue(
            all(
                r["colorblind_safe"] == "deutan" or "deutan" in r["colorblind_types"]
                for r in records
            )
        )

    def test_query_all_by_colorblind_any(self):
        """Should return all colorblind-safe colormaps when using 'any'."""
        records = db._query_all(colorblind_safe="any")
        self.assertTrue(all(r["colorblind_safe"] != "none" for r in records))

    def test_query_all_by_keyword(self):
        """Should fuzzy-search by keyword in name/tags."""
        records = db._query_all(keyword="temperature")
        self.assertTrue(len(records) > 0)

    def test_query_all_sort_by(self):
        """Should sort results by specified field."""
        records = db._query_all(sort_by="id")
        ids = [r["id"] for r in records]
        self.assertEqual(ids, sorted(ids))

    def test_query_all_limit(self):
        """Should limit number of results."""
        records = db._query_all(limit=3)
        self.assertLessEqual(len(records), 3)

    def test_query_all_combined_filters(self):
        """Should apply all filters together."""
        records = db._query_all(
            cmap_type="sequential", tag="common", colorblind_safe="any", limit=5
        )
        for r in records:
            self.assertEqual(r["cmap_type"], "sequential")
            self.assertIn("common", r["tags"])
            self.assertNotEqual(r["colorblind_safe"], "none")

    def test_insert_returns_id(self):
        """Inserting a new colormap should return its id."""
        # Clean up if exists from previous run
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'TestCmap'")
        conn.commit()
        conn.close()
        new_id = db._insert(
            name="TestCmap",
            colors=["#ff0000", "#00ff00"],
            cmap_type="sequential",
            tags=["test"],
            colorblind_safe="none",
            description="test colormap",
        )
        self.assertIsNotNone(new_id)
        record = db._get_by_id(new_id)
        self.assertEqual(record["name"], "TestCmap")

    def test_row_to_dict_parses_json(self):
        """Row dict should have JSON fields parsed into Python lists."""
        record = db._get_by_name("Viridis")
        self.assertIsInstance(record["colors"], list)
        self.assertIsInstance(record["tags"], list)
        self.assertIsInstance(record["colorblind_types"], list)
        self.assertIsInstance(record["source"], list)

    def test_builtin_cmap_has_is_custom_zero(self):
        """Built-in colormaps should have is_custom=0."""
        record = db._get_by_name("Viridis")
        self.assertEqual(record["is_custom"], 0)

    def test_builtin_cmap_source(self):
        """Built-in matplotlib colormaps should have source=['matplotlib']."""
        record = db._get_by_name("Viridis")
        self.assertEqual(record["source"], ["matplotlib"])

    def test_query_all_by_source(self):
        """Should filter by source."""
        records = db._query_all(source="matplotlib")
        self.assertTrue(len(records) > 0)
        self.assertTrue(all("matplotlib" in r["source"] for r in records))

    def test_query_all_by_source_list(self):
        """Should filter by multiple sources (AND logic)."""
        records = db._query_all(source=["matplotlib"])
        self.assertTrue(len(records) > 0)

    def test_insert_with_source(self):
        """Inserting with a source value should store it."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SourceTest'")
        conn.commit()
        conn.close()
        db._insert(
            name="SourceTest",
            colors=["#ff0000"],
            cmap_type="sequential",
            source=["ggplot2"],
        )
        record = db._get_by_name("SourceTest")
        self.assertEqual(record["source"], ["ggplot2"])
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SourceTest'")
        conn.commit()
        conn.close()

    def test_insert_source_defaults_empty_list(self):
        """Inserting without source should default to empty list."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SourceDefaultTest'")
        conn.commit()
        conn.close()
        db._insert(
            name="SourceDefaultTest",
            colors=["#ff0000"],
            cmap_type="sequential",
        )
        record = db._get_by_name("SourceDefaultTest")
        self.assertEqual(record["source"], [])
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SourceDefaultTest'")
        conn.commit()
        conn.close()

    def test_sync_builtins_source_field(self):
        """Sync should propagate source changes in built-in colormaps."""
        conn = db._get_conn()
        # Tamper source in user DB
        conn.execute("UPDATE cmaps SET source = '[]' WHERE name = 'Viridis'")
        conn.commit()
        conn.close()
        db._sync_builtins()
        record = db._get_by_name("Viridis")
        self.assertEqual(record["source"], ["matplotlib"])

    def test_sync_builtins_preserves_custom_source(self):
        """Sync should NOT overwrite source on user-defined colormaps."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SyncSourceTest'")
        conn.commit()
        conn.close()
        db._insert(
            name="SyncSourceTest",
            colors=["#aaaaaa"],
            cmap_type="sequential",
            source=["user"],
        )
        # Clean up package DB first, then add a conflicting entry
        pkg_conn = sqlite3.connect(str(db._PACKAGE_DB))
        pkg_conn.execute("DELETE FROM cmaps WHERE name = 'SyncSourceTest'")
        pkg_conn.execute(
            "INSERT INTO cmaps (name, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, is_custom, source) "
            "VALUES ('SyncSourceTest', '[\"#000000\"]', 'sequential', '[]', 'none', '[]', '', 0, '[\"pkg\"]')"
        )
        pkg_conn.commit()
        pkg_conn.close()
        db._sync_builtins()
        record = db._get_by_name("SyncSourceTest")
        self.assertEqual(record["source"], ["user"])
        self.assertEqual(record["colors"], ["#aaaaaa"])
        # Clean up
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SyncSourceTest'")
        conn.commit()
        conn.close()
        pkg_conn = sqlite3.connect(str(db._PACKAGE_DB))
        pkg_conn.execute("DELETE FROM cmaps WHERE name = 'SyncSourceTest'")
        pkg_conn.commit()
        pkg_conn.close()

    def test_query_all_by_is_custom(self):
        """Should filter by is_custom flag."""
        builtin = db._query_all(is_custom=False)
        self.assertTrue(all(r["is_custom"] == 0 for r in builtin))
        custom = db._query_all(is_custom=True)
        self.assertTrue(all(r["is_custom"] == 1 for r in custom))

    def test_insert_custom_sets_is_custom_one(self):
        """Inserting a custom colormap should set is_custom=1."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'TestIsCustom'")
        conn.commit()
        conn.close()
        db._insert(
            name="TestIsCustom",
            colors=["#ff0000", "#00ff00"],
            cmap_type="sequential",
            tags=["test"],
        )
        record = db._get_by_name("TestIsCustom")
        self.assertEqual(record["is_custom"], 1)

    def test_insert_overwrites_custom_but_not_builtin(self):
        """Should allow overwrite of custom cmap but reject built-in."""
        # Overwrite existing custom - should succeed
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'OverwriteTest'")
        conn.commit()
        conn.close()
        db._insert(
            name="OverwriteTest", colors=["#111111", "#222222"], cmap_type="sequential"
        )
        new_id = db._insert(
            name="OverwriteTest", colors=["#333333", "#444444"], cmap_type="sequential"
        )
        self.assertIsNotNone(new_id)

        # Overwrite built-in - should fail
        with self.assertRaises(ValueError) as ctx:
            db._insert(
                name="Viridis", colors=["#000000", "#ffffff"], cmap_type="sequential"
            )
        self.assertIn("Cannot overwrite built-in", str(ctx.exception))

    def test_sync_builtins_inserts_new_colormaps(self):
        """New built-in colormaps from package should be inserted into user DB."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SyncTestNew'")
        conn.commit()
        conn.close()

        # Clean up package DB too in case of previous run
        pkg_conn = sqlite3.connect(str(db._PACKAGE_DB))
        pkg_conn.execute("DELETE FROM cmaps WHERE name = 'SyncTestNew'")
        pkg_conn.commit()
        # Add a new colormap in the package DB
        pkg_conn.execute(
            "INSERT INTO cmaps (name, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, is_custom, source) "
            "VALUES ('SyncTestNew', '[\"#ff0000\"]', 'sequential', '[\"sync\"]', 'none', '[]', 'sync test', 0, '[]')"
        )
        pkg_conn.commit()
        pkg_conn.close()

        db._sync_builtins()

        record = db._get_by_name("SyncTestNew")
        self.assertIsNotNone(record)
        self.assertEqual(record["is_custom"], 0)

        # Clean up
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SyncTestNew'")
        conn.commit()
        conn.close()
        pkg_conn = sqlite3.connect(str(db._PACKAGE_DB))
        pkg_conn.execute("DELETE FROM cmaps WHERE name = 'SyncTestNew'")
        pkg_conn.commit()
        pkg_conn.close()

    def test_sync_builtins_updates_changed_builtins(self):
        """Existing built-in colormaps should be updated when attributes differ."""
        conn = db._get_conn()
        # Tamper with a built-in colormap in the user DB
        conn.execute(
            "UPDATE cmaps SET description = 'tampered', colorblind_safe = 'deutan' WHERE name = 'Viridis'"
        )
        conn.commit()
        conn.close()

        db._sync_builtins()

        record = db._get_by_name("Viridis")
        # Should be restored to original (empty description, not 'deutan' unless it was in pkg)
        # We just verify the update happened by checking it's no longer 'tampered'
        self.assertNotEqual(record["description"], "tampered")

    def test_sync_builtins_preserves_custom_colormaps(self):
        """User-defined colormaps should NOT be overwritten by sync."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SyncProtectTest'")
        conn.commit()
        conn.close()
        db._insert(
            name="SyncProtectTest",
            colors=["#aaaaaa"],
            cmap_type="sequential",
            tags=["protect"],
            description="user description",
        )

        # Clean up package DB first, then add a conflicting entry
        pkg_conn = sqlite3.connect(str(db._PACKAGE_DB))
        pkg_conn.execute("DELETE FROM cmaps WHERE name = 'SyncProtectTest'")
        pkg_conn.execute(
            "INSERT INTO cmaps (name, colors, cmap_type, tags, colorblind_safe, colorblind_types, description, is_custom, source) "
            "VALUES ('SyncProtectTest', '[\"#000000\"]', 'sequential', '[]', 'none', '[]', 'pkg override', 0, '[]')"
        )
        pkg_conn.commit()
        pkg_conn.close()

        db._sync_builtins()

        record = db._get_by_name("SyncProtectTest")
        # User data should be preserved
        self.assertEqual(record["description"], "user description")
        self.assertEqual(record["colors"], ["#aaaaaa"])

        # Clean up both DBs
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'SyncProtectTest'")
        conn.commit()
        conn.close()
        pkg_conn = sqlite3.connect(str(db._PACKAGE_DB))
        pkg_conn.execute("DELETE FROM cmaps WHERE name = 'SyncProtectTest'")
        pkg_conn.commit()
        pkg_conn.close()

    def test_insert_custom_id_starts_from_10001(self):
        """New custom colormaps should get ID >= 10001."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'IdTestA'")
        conn.commit()
        conn.close()
        cmap_id = db._insert(name="IdTestA", colors=["#ff0000"], cmap_type="sequential")
        self.assertGreaterEqual(cmap_id, 10001)

        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name = 'IdTestA'")
        conn.commit()
        conn.close()

    def test_insert_custom_id_increments(self):
        """Sequential custom inserts should get incrementing IDs."""
        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name IN ('IdTestB', 'IdTestC')")
        conn.commit()
        conn.close()

        id1 = db._insert(name="IdTestB", colors=["#111111"], cmap_type="sequential")
        id2 = db._insert(name="IdTestC", colors=["#222222"], cmap_type="sequential")
        self.assertGreater(id2, id1)
        self.assertGreaterEqual(id1, 10001)

        conn = db._get_conn()
        conn.execute("DELETE FROM cmaps WHERE name IN ('IdTestB', 'IdTestC')")
        conn.commit()
        conn.close()

    def test_builtin_colormaps_have_id_under_10001(self):
        """All built-in colormaps should have IDs < 10001."""
        records = db._query_all(is_custom=False)
        self.assertTrue(all(r["id"] < 10001 for r in records))

    def test_custom_colormaps_have_id_above_10000(self):
        """All user-defined colormaps should have IDs >= 10001."""
        records = db._query_all(is_custom=True)
        self.assertTrue(all(r["id"] >= 10001 for r in records))


if __name__ == "__main__":
    unittest.main()
