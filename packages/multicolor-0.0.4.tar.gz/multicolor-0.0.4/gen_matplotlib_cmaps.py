"""Generate matplotlib colormap data in JSON format matching multicolor DB schema.

Extracts base colors from matplotlib source _cm.py and _cm_listed.py:
- Color Brewer maps: flat tuples of RGB values (e.g. Blues has 9 RGB tuples)
- Simple RGB tuples: bwr, seismic, brg (just a few anchor RGB values)
- (x, RGB) tuples: terrain, gist_rainbow (positioned anchor colors)
- {'listed': ...}: qualitative maps (direct color lists)
- _segmentdata dicts: red/green/blue channel anchor points (autumn, bone, etc.)
- _cm_listed.py: pre-built 256-color maps (viridis, turbo, etc.)
- Callable dicts: function-based maps (gnuplot, flag, etc.) — sample 256
"""

import json
import numpy as np
import matplotlib.colors as mcolors
import matplotlib as mpl

from matplotlib import _cm
from matplotlib import _cm_listed

# Classification
SEQUENTIAL = {
    'turbo', 'berlin', 'managua', 'vanimo',
    'viridis', 'plasma', 'inferno', 'magma', 'cividis',
    'Blues', 'BuGn', 'BuPu', 'GnBu', 'Greens', 'Greys', 'Oranges',
    'OrRd', 'PuBu', 'PuBuGn', 'PuRd', 'Purples', 'Reds', 'YlGn',
    'YlGnBu', 'YlOrBr', 'YlOrRd',
    'afmhot', 'autumn', 'bone', 'cool', 'copper', 'gray',
    'gist_gray', 'gist_heat', 'gist_yarg', 'gnuplot', 'gnuplot2',
    'hot', 'pink', 'spring', 'summer', 'winter',
    'CMRmap', 'cubehelix', 'gist_earth', 'gist_stern',
    'hsv', 'jet', 'ocean', 'rainbow', 'gist_ncar',
    'nipy_spectral', 'prism', 'Wistia', 'RdPu', 'binary',
}

DIVERGING = {
    'BrBG', 'PiYG', 'PRGn', 'PuOr', 'RdBu', 'RdGy', 'RdYlBu', 'RdYlGn',
    'Spectral',
    'bwr', 'coolwarm', 'seismic',
    'gist_rainbow', 'flag', 'terrain', 'twilight', 'twilight_shifted',
}

QUALITATIVE = {
    'Accent', 'Dark2', 'Paired', 'Pastel1', 'Pastel2',
    'Set1', 'Set2', 'Set3',
    'tab10', 'tab20', 'tab20b', 'tab20c',
}

COLORBLIND = {
    'viridis': ('deutan', ['deutan', 'protan', 'tritan']),
    'cividis': ('achromatopsia', ['deutan', 'protan', 'tritan', 'achromatopsia']),
    'turbo': ('deutan', ['deutan', 'protan']),
    'berlin': ('deutan', ['deutan', 'protan']),
    'managua': ('deutan', ['deutan', 'protan']),
    'vanimo': ('deutan', ['deutan', 'protan']),
    'plasma': ('deutan', ['deutan', 'protan']),
    'inferno': ('deutan', ['deutan', 'protan']),
    'magma': ('deutan', ['deutan', 'protan']),
    'coolwarm': ('deutan', ['deutan']),
    'RdBu': ('deutan', ['deutan']),
    'BrBG': ('deutan', ['deutan', 'protan']),
    'PiYG': ('deutan', ['deutan']),
    'PRGn': ('deutan', ['deutan']),
    'PuOr': ('deutan', ['deutan']),
    'RdGy': ('deutan', ['deutan']),
    'RdYlBu': ('deutan', ['deutan']),
    'RdYlGn': ('deutan', ['deutan', 'protan']),
    'Spectral': ('deutan', ['deutan']),
    'seismic': ('deutan', ['deutan']),
    'bwr': ('none', []),
    'Blues': ('deutan', ['deutan', 'protan']),
    'BuGn': ('deutan', ['deutan', 'protan']),
    'BuPu': ('deutan', ['deutan', 'protan']),
    'GnBu': ('deutan', ['deutan']),
    'Greens': ('deutan', ['deutan', 'protan']),
    'Greys': ('achromatopsia', ['deutan', 'protan', 'tritan', 'achromatopsia']),
    'Oranges': ('deutan', ['deutan']),
    'OrRd': ('deutan', ['deutan', 'protan']),
    'PuBu': ('deutan', ['deutan', 'protan']),
    'PuBuGn': ('deutan', ['deutan', 'protan']),
    'PuRd': ('deutan', ['deutan']),
    'Purples': ('deutan', ['deutan', 'protan']),
    'Reds': ('deutan', ['deutan', 'protan']),
    'YlGn': ('deutan', ['deutan']),
    'YlGnBu': ('deutan', ['deutan', 'protan']),
    'YlOrBr': ('deutan', ['deutan', 'protan']),
    'YlOrRd': ('deutan', ['deutan', 'protan']),
    'afmhot': ('none', []),
    'autumn': ('tritan', ['protan', 'tritan']),
    'bone': ('deutan', ['deutan', 'protan']),
    'cool': ('deutan', ['deutan']),
    'copper': ('deutan', ['deutan', 'protan']),
    'gray': ('achromatopsia', ['deutan', 'protan', 'tritan', 'achromatopsia']),
    'gist_gray': ('achromatopsia', ['deutan', 'protan', 'tritan', 'achromatopsia']),
    'gist_yarg': ('achromatopsia', ['deutan', 'protan', 'tritan', 'achromatopsia']),
    'gist_heat': ('none', []),
    'gnuplot': ('none', []),
    'gnuplot2': ('none', []),
    'hot': ('none', []),
    'pink': ('none', []),
    'spring': ('protan', ['protan']),
    'summer': ('deutan', ['deutan', 'protan']),
    'winter': ('deutan', ['deutan']),
    'CMRmap': ('none', []),
    'cubehelix': ('deutan', ['deutan', 'protan']),
    'gist_earth': ('deutan', ['deutan']),
    'gist_stern': ('none', []),
    'jet': ('none', []),
    'hsv': ('none', []),
    'ocean': ('deutan', ['deutan']),
    'rainbow': ('none', []),
    'gist_rainbow': ('none', []),
    'gist_ncar': ('none', []),
    'nipy_spectral': ('none', []),
    'prism': ('none', []),
    'flag': ('none', []),
    'terrain': ('none', []),
    'Wistia': ('deutan', ['deutan', 'protan']),
    'RdPu': ('deutan', ['deutan']),
    'binary': ('achromatopsia', ['deutan', 'protan', 'tritan', 'achromatopsia']),
    'twilight': ('none', []),
    'twilight_shifted': ('none', []),
}

TAGS = {
    'viridis': ['common', 'perceptually-uniform', 'raster'],
    'plasma': ['common', 'perceptually-uniform', 'raster'],
    'inferno': ['common', 'perceptually-uniform', 'raster'],
    'magma': ['common', 'perceptually-uniform', 'raster'],
    'cividis': ['common', 'perceptually-uniform', 'colorblind-safe', 'raster'],
    'turbo': ['common', 'perceptually-uniform', 'raster'],
    'berlin': ['perceptually-uniform', 'raster'],
    'managua': ['perceptually-uniform', 'raster'],
    'vanimo': ['perceptually-uniform', 'raster'],
    'Blues': ['colorbrewer', 'sequential'],
    'BuGn': ['colorbrewer', 'sequential'],
    'BuPu': ['colorbrewer', 'sequential'],
    'GnBu': ['colorbrewer', 'sequential'],
    'Greens': ['colorbrewer', 'sequential'],
    'Greys': ['colorbrewer', 'sequential', 'grayscale'],
    'Oranges': ['colorbrewer', 'sequential'],
    'OrRd': ['colorbrewer', 'sequential'],
    'PuBu': ['colorbrewer', 'sequential'],
    'PuBuGn': ['colorbrewer', 'sequential'],
    'PuRd': ['colorbrewer', 'sequential'],
    'Purples': ['colorbrewer', 'sequential'],
    'Reds': ['colorbrewer', 'sequential'],
    'YlGn': ['colorbrewer', 'sequential'],
    'YlGnBu': ['colorbrewer', 'sequential'],
    'YlOrBr': ['colorbrewer', 'sequential'],
    'YlOrRd': ['colorbrewer', 'sequential'],
    'afmhot': ['legacy', 'temperature'],
    'autumn': ['legacy'],
    'bone': ['legacy', 'grayscale'],
    'cool': ['legacy'],
    'copper': ['legacy', 'temperature'],
    'gray': ['legacy', 'grayscale'],
    'gist_gray': ['legacy', 'grayscale'],
    'gist_yarg': ['legacy', 'grayscale'],
    'gist_heat': ['legacy', 'temperature'],
    'gnuplot': ['legacy'],
    'gnuplot2': ['legacy'],
    'hot': ['legacy', 'temperature'],
    'pink': ['legacy'],
    'spring': ['legacy'],
    'summer': ['legacy'],
    'winter': ['legacy'],
    'CMRmap': ['satellite'],
    'cubehelix': ['astronomy', 'perceptually-uniform'],
    'gist_earth': ['elevation', 'terrain'],
    'gist_stern': [],
    'hsv': ['circular'],
    'jet': ['common', 'raster', 'not-recommended'],
    'ocean': [],
    'rainbow': ['circular'],
    'gist_rainbow': ['circular'],
    'gist_ncar': ['meteorology'],
    'nipy_spectral': ['spectral'],
    'prism': [],
    'flag': [],
    'terrain': ['elevation', 'landuse', 'raster'],
    'Wistia': [],
    'RdPu': ['colorbrewer', 'sequential'],
    'binary': ['grayscale'],
    'twilight': ['circular', 'diverging'],
    'twilight_shifted': ['circular', 'diverging'],
    'BrBG': ['colorbrewer', 'diverging'],
    'PiYG': ['colorbrewer', 'diverging'],
    'PRGn': ['colorbrewer', 'diverging'],
    'PuOr': ['colorbrewer', 'diverging'],
    'bwr': ['diverging', 'temperature'],
    'coolwarm': ['common', 'diverging', 'temperature'],
    'seismic': ['diverging', 'elevation'],
    'Accent': ['colorbrewer', 'qualitative', 'categorical'],
    'Dark2': ['colorbrewer', 'qualitative', 'categorical'],
    'Paired': ['colorbrewer', 'qualitative', 'categorical'],
    'Pastel1': ['colorbrewer', 'qualitative', 'categorical'],
    'Pastel2': ['colorbrewer', 'qualitative', 'categorical'],
    'Set1': ['colorbrewer', 'qualitative', 'categorical'],
    'Set2': ['colorbrewer', 'qualitative', 'categorical'],
    'Set3': ['colorbrewer', 'qualitative', 'categorical'],
    'tab10': ['qualitative', 'categorical', 'tab-colors'],
    'tab20': ['qualitative', 'categorical', 'tab-colors'],
    'tab20b': ['qualitative', 'categorical', 'tab-colors'],
    'tab20c': ['qualitative', 'categorical', 'tab-colors'],
}


def rgb_to_hex(r, g, b):
    """Convert RGB values (0-1 range) to hex string."""
    return '#{:02x}{:02x}{:02x}'.format(
        max(0, min(255, int(round(r * 255)))),
        max(0, min(255, int(round(g * 255)))),
        max(0, min(255, int(round(b * 255))))
    )


def get_colors_from_listed(name):
    """Get colors from _cm_listed.py pre-built colormaps (viridis, turbo, etc.)."""
    if name in _cm_listed.cmaps:
        cmap = _cm_listed.cmaps[name]
        return [mcolors.rgb2hex(c) for c in cmap.colors]
    return None


def extract_datad_colors(name, data):
    """Extract base colors from a _cm.py datad entry.

    Handles these formats:
    1. {'listed': tuples} → qualitative direct colors
    2. Flat RGB tuples: ((r,g,b), (r,g,b), ...) → Color Brewer style
    3. (x, RGB) tuples: ((x, (r,g,b)), ...) → terrain, gist_rainbow
    4. _segmentdata dict: {'red': ..., 'green': ..., 'blue': ...} → anchor colors
    5. Callable channels → None (fall back to sampling)
    """
    # 1. Qualitative listed
    if isinstance(data, dict) and 'listed' in data:
        return [rgb_to_hex(*c) for c in data['listed']]

    # 2. Tuple-based data
    if isinstance(data, (list, tuple)) and len(data) > 0:
        first = data[0]
        if isinstance(first, (list, tuple)):
            if len(first) == 2 and isinstance(first[1], (list, tuple)) and len(first[1]) == 3:
                # Format: (x, (r,g,b)) — terrain, gist_rainbow
                return [rgb_to_hex(*rgb) for _, rgb in data]
            elif len(first) == 3:
                # Format: (r,g,b) — Color Brewer, bwr, seismic, brg
                return [rgb_to_hex(*c) for c in data]

    # 3. _segmentdata dict
    if isinstance(data, dict):
        r_ch = data.get('red')
        g_ch = data.get('green')
        b_ch = data.get('blue')

        # Callable channels — can't extract base colors analytically
        if callable(r_ch) or callable(g_ch) or callable(b_ch):
            return None

        # Extract anchor colors from segment data
        x_positions = sorted(set(entry[0] for entry in r_ch))
        colors = []
        for x in x_positions:
            r = _lookup_channel(r_ch, x)
            g = _lookup_channel(g_ch, x)
            b = _lookup_channel(b_ch, x)
            colors.append(rgb_to_hex(r, g, b))
        return colors

    return None


def _lookup_channel(channel, x):
    """Look up the value at position x in a segmentdata channel.

    channel = ((x0, y0_0, y0_1), (x1, y1_0, y1_1), ...)
    At anchor x_i, use y_i_1 (right limit) except first point uses y_0_0.
    """
    for i, (xi, y0, y1) in enumerate(channel):
        if xi == x:
            return y0 if i == 0 else y1
    # Fallback: interpolate
    return _interpolate_channel(channel, x)


def _interpolate_channel(channel, x):
    """Linear interpolation for a channel at position x."""
    if x <= channel[0][0]:
        return channel[0][1]
    if x >= channel[-1][0]:
        return channel[-1][2]
    for i in range(len(channel) - 1):
        x0, _, y0_end = channel[i]
        x1, y1_start, _ = channel[i + 1]
        if x0 <= x <= x1:
            if x1 == x0:
                return y0_end
            t = (x - x0) / (x1 - x0)
            return y0_end + t * (y1_start - y0_end)
    return channel[-1][2]


def get_colors_by_sampling(name, n=256):
    """Fallback: sample colormap at n evenly-spaced points."""
    cm = mpl.colormaps[name]
    values = np.linspace(0, 1, n)
    rgba = cm(values)
    return [mcolors.rgb2hex(rgb) for rgb in rgba[:, :3]]


def get_base_colors(name):
    """Get base colors for a matplotlib colormap from source definitions.

    Priority:
    1. _cm_listed.py pre-built maps (viridis, plasma, turbo, etc.)
    2. _cm.py datad — extract anchor colors from various formats
    3. Fallback — sample the compiled colormap at 256 points
    """
    # 1. Pre-built ListedColormap from _cm_listed.py
    listed_colors = get_colors_from_listed(name)
    if listed_colors is not None:
        return listed_colors

    # 2. _cm.py datad
    if name in _cm.datad:
        colors = extract_datad_colors(name, _cm.datad[name])
        if colors is not None:
            return colors

    # 3. Fallback: sample
    return get_colors_by_sampling(name)


def main():
    all_names = sorted(SEQUENTIAL | DIVERGING | QUALITATIVE)
    records = []

    for name in all_names:
        if name in QUALITATIVE:
            cmap_type = 'qualitative'
        elif name in DIVERGING:
            cmap_type = 'diverging'
        else:
            cmap_type = 'sequential'

        colors = get_base_colors(name)
        cb_safe, cb_types = COLORBLIND.get(name, ('none', []))
        tags = TAGS.get(name, [])

        record = {
            "name": name,
            "colors": colors,
            "cmap_type": cmap_type,
            "tags": tags,
            "colorblind_safe": cb_safe,
            "colorblind_types": cb_types,
            "description": "",
            "source": ["matplotlib"],
        }
        records.append(record)

    # Print summary
    for r in records:
        print(f"{r['name']:25s} {r['cmap_type']:15s} colors={len(r['colors']):4d} cb={r['colorblind_safe']:20s} tags={r['tags']}")

    print(f"\nTotal: {len(records)}")
    print(f"  Sequential:  {sum(1 for r in records if r['cmap_type'] == 'sequential')}")
    print(f"  Diverging:   {sum(1 for r in records if r['cmap_type'] == 'diverging')}")
    print(f"  Qualitative: {sum(1 for r in records if r['cmap_type'] == 'qualitative')}")

    # Show which maps have few base colors (anchor colors) vs 256
    few = [r for r in records if len(r['colors']) < 50]
    many = [r for r in records if len(r['colors']) >= 50]
    print(f"\nMaps with anchor colors (<50): {len(few)}")
    for r in few:
        print(f"  {r['name']:25s} {len(r['colors']):4d} colors")
    print(f"\nMaps with 256 colors: {len(many)}")

    outpath = r'E:\AAAproject\multicolor\ai_docs\matplotlib_cmaps.json'
    with open(outpath, 'w', encoding='utf-8') as f:
        json.dump(records, f, ensure_ascii=False, indent=2)

    import os
    size = os.path.getsize(outpath)
    print(f"\nWritten to {outpath}")
    print(f"File size: {size / 1024:.1f} KB")


if __name__ == '__main__':
    main()
