"""
OrcaMonitor License Client
--------------------------
Verifies your OrcaMonitor license against the cloud API on startup,
caches the result locally, and re-verifies periodically in the background.

Designed for Docker-based on-premise deployments — no source code is
exposed to end customers. License key is read from an environment variable.

Usage
-----
    from orcamonitor import LicenseClient

    client = LicenseClient()        # reads ORCA_LICENSE_KEY + ORCA_API_URL from env
    client.verify_on_startup()      # raises on invalid / expired license
    client.start_background_checks()

    if client.feature("ai_remediation"):
        ...
"""

from __future__ import annotations

import logging
import os
import threading
import time
from pathlib import Path
from typing import Callable, Optional

import urllib.request
import urllib.error
import json

from .cache import LicenseCache
from .exceptions import (
    DeviceLimitExceeded,
    GracePeriodExpired,
    LicenseInvalid,
    LicenseNotFound,
    LicenseServerUnreachable,
)
from .models import LicenseStatus

logger = logging.getLogger(__name__)

_FEATURE_ALIASES = {
    "ai_remediation": "ai_remediation",
    "airemediation":  "ai_remediation",
    "ha_mode":        "ha_mode",
    "hamode":         "ha_mode",
    "multi_site":     "multi_site",
    "multisite":      "multi_site",
    "audit_log":      "audit_log",
    "auditlog":       "audit_log",
    "api_access":     "api_access",
    "apiaccess":      "api_access",
    "sso_ldap":       "sso_ldap",
    "ssoldap":        "sso_ldap",
    "custom_runbooks": "custom_runbooks",
    "customrunbooks": "custom_runbooks",
}


class LicenseClient:
    """
    Central license management client for OrcaMonitor on-premise nodes.

    Parameters
    ----------
    license_key : str, optional
        License key. Defaults to env var ``ORCA_LICENSE_KEY``.
    api_url : str, optional
        Base URL of the OrcaMonitor API. Defaults to env var ``ORCA_API_URL``
        or ``https://api.orcamonitor.com``.
    device_count_fn : callable, optional
        Zero-argument callable that returns the current number of monitored
        devices. Called on each verification. If omitted, device count is
        not reported.
    grace_period_hours : float
        Hours to keep running on cached data when the license server is
        unreachable. Default: 72.
    check_interval_hours : float
        How often the background thread re-verifies. Default: 24.
    cache_path : Path, optional
        Override the default cache file location
        (``/var/cache/orcamonitor/license.json`` or ``ORCA_CACHE_PATH`` env).
    on_warning : callable, optional
        Called with a warning string when the license is about to expire or
        device count is near the limit. Use it to surface alerts in your app.
    """

    def __init__(
        self,
        license_key: Optional[str] = None,
        api_url: Optional[str] = None,
        device_count_fn: Optional[Callable[[], int]] = None,
        grace_period_hours: float = 72.0,
        check_interval_hours: float = 24.0,
        cache_path: Optional[Path] = None,
        on_warning: Optional[Callable[[str], None]] = None,
    ):
        self._key = license_key or os.environ.get("ORCA_LICENSE_KEY", "")
        if not self._key:
            raise ValueError(
                "License key is required. Set ORCA_LICENSE_KEY environment variable."
            )

        base = api_url or os.environ.get("ORCA_API_URL", "https://orcamonitor.com")
        self._verify_url = base.rstrip("/") + "/api/license/verify"

        self._device_count_fn = device_count_fn
        self._grace_seconds = grace_period_hours * 3600
        self._check_interval = check_interval_hours * 3600
        self._on_warning = on_warning or (lambda msg: logger.warning("OrcaMonitor: %s", msg))

        self._cache = LicenseCache(cache_path) if cache_path else LicenseCache()
        self._status: Optional[LicenseStatus] = None
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._bg_thread: Optional[threading.Thread] = None

    # ── Public API ─────────────────────────────────────────────────────────────

    @property
    def status(self) -> Optional[LicenseStatus]:
        """Most recent known LicenseStatus (may be from cache)."""
        with self._lock:
            return self._status

    def feature(self, name: str) -> bool:
        """
        Return whether a feature is enabled on this license.

        Names are case-insensitive and accept both snake_case and camelCase:
            client.feature("ai_remediation")
            client.feature("aiRemediation")
            client.feature("ha_mode")
        """
        key = _FEATURE_ALIASES.get(name.lower().replace("-", "_"))
        if key is None:
            raise ValueError(f"Unknown feature name: {name!r}")
        with self._lock:
            if self._status is None:
                return False
            return bool(getattr(self._status.features, key, False))

    def verify_on_startup(self) -> LicenseStatus:
        """
        Verify the license immediately. Must be called before starting your app.

        Raises
        ------
        LicenseInvalid
            License is expired, suspended, or otherwise not valid.
        LicenseNotFound
            License key is not recognised by the server.
        DeviceLimitExceeded
            Reported device count is over the licensed maximum.
        GracePeriodExpired
            Server unreachable AND cached data is older than grace_period_hours.
        LicenseServerUnreachable
            Server unreachable AND there is no cached data at all.
        """
        logger.info("OrcaMonitor: verifying license %s…", self._masked_key())
        try:
            status = self._call_api()
            self._handle_status(status, raise_on_invalid=True)
            return status
        except LicenseServerUnreachable as exc:
            return self._handle_offline(exc, raise_on_invalid=True)

    def start_background_checks(self) -> None:
        """
        Start a daemon thread that re-verifies the license every
        ``check_interval_hours``. Call after ``verify_on_startup()``.
        """
        if self._bg_thread and self._bg_thread.is_alive():
            return
        self._stop_event.clear()
        self._bg_thread = threading.Thread(
            target=self._bg_loop, daemon=True, name="orca-license-checker"
        )
        self._bg_thread.start()
        logger.info(
            "OrcaMonitor: background license checks started (every %.0f h)",
            self._check_interval / 3600,
        )

    def stop_background_checks(self) -> None:
        """Gracefully stop the background thread."""
        self._stop_event.set()
        if self._bg_thread:
            self._bg_thread.join(timeout=5)

    def check_now(self) -> Optional[LicenseStatus]:
        """
        Trigger an immediate re-verification (non-raising).
        Returns the new status, or None if the server was unreachable.
        """
        try:
            status = self._call_api()
            self._handle_status(status, raise_on_invalid=False)
            return status
        except LicenseServerUnreachable:
            logger.warning("OrcaMonitor: server unreachable during periodic check; using cache")
            return self._status

    # ── Internal ───────────────────────────────────────────────────────────────

    def _masked_key(self) -> str:
        k = self._key
        return k[:8] + "****" if len(k) > 8 else "****"

    def _device_count(self) -> Optional[int]:
        if self._device_count_fn is None:
            return None
        try:
            return int(self._device_count_fn())
        except Exception:
            return None

    def _call_api(self) -> LicenseStatus:
        payload: dict = {"licenseKey": self._key}
        count = self._device_count()
        if count is not None:
            payload["deviceCount"] = count

        body = json.dumps(payload).encode()
        req = urllib.request.Request(
            self._verify_url,
            data=body,
            method="POST",
            headers={"Content-Type": "application/json", "User-Agent": "orcamonitor-sdk-python/1.0"},
        )

        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            if exc.code == 404:
                raise LicenseNotFound(f"License key not found: {self._masked_key()}") from exc
            raise LicenseServerUnreachable(
                f"License server returned HTTP {exc.code}"
            ) from exc
        except Exception as exc:
            raise LicenseServerUnreachable(
                f"Could not reach license server: {exc}"
            ) from exc

        return LicenseStatus.from_api(data)

    def _handle_status(self, status: LicenseStatus, *, raise_on_invalid: bool) -> None:
        with self._lock:
            self._status = status

        self._cache.save(status)

        if not status.valid:
            msg = status.message or f"License {status.status}"
            if raise_on_invalid:
                raise LicenseInvalid(msg, status.status)
            self._on_warning(msg)
            return

        if (
            status.reported_devices is not None
            and status.max_devices
            and status.reported_devices > status.max_devices
        ):
            exc = DeviceLimitExceeded(status.reported_devices, status.max_devices)
            if raise_on_invalid:
                raise exc
            self._on_warning(str(exc))
            return

        if status.days_remaining is not None and status.days_remaining <= 30:
            self._on_warning(status.message or f"License expires in {status.days_remaining} days")

        logger.info(
            "OrcaMonitor: license OK — edition=%s devices=%s/%s days_remaining=%s",
            status.edition,
            status.reported_devices,
            status.max_devices,
            status.days_remaining,
        )

    def _handle_offline(
        self, exc: LicenseServerUnreachable, *, raise_on_invalid: bool
    ) -> LicenseStatus:
        cached = self._cache.load()
        if cached is None:
            raise LicenseServerUnreachable(
                "License server unreachable and no local cache found. "
                "Cannot start without a valid license."
            ) from exc

        age = self._cache.age_seconds() or 0
        if age > self._grace_seconds:
            raise GracePeriodExpired(
                f"License server unreachable and grace period of "
                f"{self._grace_seconds / 3600:.0f} h has elapsed. "
                "Please restore connectivity."
            ) from exc

        remaining_grace = (self._grace_seconds - age) / 3600
        logger.warning(
            "OrcaMonitor: server unreachable — using cached license "
            "(grace period: %.1f h remaining)",
            remaining_grace,
        )
        self._on_warning(
            f"License server unreachable — running on cached license. "
            f"Grace period: {remaining_grace:.1f} h remaining."
        )
        with self._lock:
            self._status = cached
        return cached

    def _bg_loop(self) -> None:
        while not self._stop_event.wait(timeout=self._check_interval):
            logger.info("OrcaMonitor: periodic license re-verification…")
            self.check_now()
