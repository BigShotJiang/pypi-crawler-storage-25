from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class LicenseFeatures:
    ai_remediation: bool = False
    ha_mode: bool = False
    multi_site: bool = False
    audit_log: bool = False
    api_access: bool = False
    sso_ldap: bool = False
    custom_runbooks: bool = False

    @classmethod
    def from_dict(cls, d: dict) -> "LicenseFeatures":
        return cls(
            ai_remediation=bool(d.get("aiRemediation", False)),
            ha_mode=bool(d.get("haMode", False)),
            multi_site=bool(d.get("multiSite", False)),
            audit_log=bool(d.get("auditLog", False)),
            api_access=bool(d.get("apiAccess", False)),
            sso_ldap=bool(d.get("ssoLdap", False)),
            custom_runbooks=bool(d.get("customRunbooks", False)),
        )

    def to_dict(self) -> dict:
        return {
            "aiRemediation": self.ai_remediation,
            "haMode": self.ha_mode,
            "multiSite": self.multi_site,
            "auditLog": self.audit_log,
            "apiAccess": self.api_access,
            "ssoLdap": self.sso_ldap,
            "customRunbooks": self.custom_runbooks,
        }


@dataclass
class LicenseStatus:
    valid: bool
    status: str
    license_key: str
    edition: str
    max_devices: int
    features: LicenseFeatures = field(default_factory=LicenseFeatures)
    days_remaining: Optional[int] = None
    reported_devices: Optional[int] = None
    license_start: Optional[str] = None
    license_end: Optional[str] = None
    message: str = ""
    verified_at: str = ""
    cached_at: Optional[float] = None

    @classmethod
    def from_api(cls, data: dict) -> "LicenseStatus":
        return cls(
            valid=bool(data.get("valid", False)),
            status=data.get("status", "unknown"),
            license_key=data.get("licenseKey", ""),
            edition=data.get("edition", ""),
            max_devices=int(data.get("maxDevices", 0)),
            features=LicenseFeatures.from_dict(data.get("features") or {}),
            days_remaining=data.get("daysRemaining"),
            reported_devices=data.get("reportedDevices"),
            license_start=data.get("licenseStart"),
            license_end=data.get("licenseEnd"),
            message=data.get("message", ""),
            verified_at=data.get("verifiedAt", ""),
        )

    def to_dict(self) -> dict:
        return {
            "valid": self.valid,
            "status": self.status,
            "licenseKey": self.license_key,
            "edition": self.edition,
            "maxDevices": self.max_devices,
            "features": self.features.to_dict(),
            "daysRemaining": self.days_remaining,
            "reportedDevices": self.reported_devices,
            "licenseStart": self.license_start,
            "licenseEnd": self.license_end,
            "message": self.message,
            "verifiedAt": self.verified_at,
            "cachedAt": self.cached_at,
        }
