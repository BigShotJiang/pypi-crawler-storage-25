class OrcaLicenseError(Exception):
    """Base exception for OrcaMonitor license errors."""


class LicenseInvalid(OrcaLicenseError):
    """License key is invalid, expired, or suspended."""

    def __init__(self, message: str, status: str):
        super().__init__(message)
        self.status = status


class LicenseNotFound(OrcaLicenseError):
    """License key does not exist in OrcaMonitor."""


class DeviceLimitExceeded(OrcaLicenseError):
    """Reported device count exceeds the licensed maximum."""

    def __init__(self, reported: int, maximum: int):
        super().__init__(
            f"Device count {reported} exceeds licensed limit of {maximum}"
        )
        self.reported = reported
        self.maximum = maximum


class LicenseServerUnreachable(OrcaLicenseError):
    """Could not reach the OrcaMonitor license server."""


class GracePeriodExpired(OrcaLicenseError):
    """Network was down and the cached license grace period has elapsed."""
