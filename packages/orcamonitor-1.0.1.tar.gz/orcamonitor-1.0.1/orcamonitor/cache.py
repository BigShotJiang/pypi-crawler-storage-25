"""
Local disk cache for license status.
Allows the on-prem tool to keep running during temporary network outages.
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Optional

from .models import LicenseStatus

logger = logging.getLogger(__name__)

DEFAULT_CACHE_PATH = Path(
    os.environ.get("ORCA_CACHE_PATH", "/var/cache/orcamonitor/license.json")
)


class LicenseCache:
    def __init__(self, path: Path = DEFAULT_CACHE_PATH):
        self.path = path

    def save(self, status: LicenseStatus) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            data = status.to_dict()
            data["cachedAt"] = time.time()
            self.path.write_text(json.dumps(data, indent=2))
        except Exception as exc:
            logger.warning("Could not write license cache: %s", exc)

    def load(self) -> Optional[LicenseStatus]:
        try:
            if not self.path.exists():
                return None
            data = json.loads(self.path.read_text())
            status = LicenseStatus.from_api(data)
            status.cached_at = data.get("cachedAt")
            return status
        except Exception as exc:
            logger.warning("Could not read license cache: %s", exc)
            return None

    def age_seconds(self) -> Optional[float]:
        cached = self.load()
        if cached is None or cached.cached_at is None:
            return None
        return time.time() - cached.cached_at

    def clear(self) -> None:
        try:
            if self.path.exists():
                self.path.unlink()
        except Exception:
            pass
