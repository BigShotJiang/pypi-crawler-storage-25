"""
OrcaMonitor Python SDK
======================
License verification for OrcaMonitor on-premise deployments.

Quick start
-----------
    from orcamonitor import LicenseClient

    client = LicenseClient()          # ORCA_LICENSE_KEY + ORCA_API_URL from env
    client.verify_on_startup()        # raises if invalid / expired
    client.start_background_checks()  # re-verifies every 24 h in background

    # Feature gating
    if client.feature("ai_remediation"):
        run_ai_engine()
"""

from .client import LicenseClient
from .exceptions import (
    DeviceLimitExceeded,
    GracePeriodExpired,
    LicenseInvalid,
    LicenseNotFound,
    LicenseServerUnreachable,
    OrcaLicenseError,
)
from .models import LicenseFeatures, LicenseStatus

__version__ = "1.0.1"
__all__ = [
    "LicenseClient",
    "LicenseStatus",
    "LicenseFeatures",
    "OrcaLicenseError",
    "LicenseInvalid",
    "LicenseNotFound",
    "DeviceLimitExceeded",
    "LicenseServerUnreachable",
    "GracePeriodExpired",
]
