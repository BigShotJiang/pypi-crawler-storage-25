# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Sharding metadata for parameters.

Layers never depend on a live JAX mesh at construction time. Instead they
attach *logical* axis names (``("in", "out")``) to each
:class:`~specflux.Parameter`. A downstream consumer provides a
``mesh_map`` that resolves logical axis names to physical mesh axes, and
:meth:`Sharding.to_partition_spec` yields a
:class:`jax.sharding.PartitionSpec` suitable for ``with_sharding_constraint``
or ``jit``'s ``in_shardings`` / ``out_shardings``.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeAlias

from jax.sharding import PartitionSpec as Ps

if TYPE_CHECKING:
    from jax.sharding import PartitionSpec

__all__ = ["AxisNames", "Sharding", "normalize_sharding"]


AxisNames: TypeAlias = tuple[str | None, ...]
"""Per-dimension logical axis names. ``None`` denotes a replicated axis."""


@dataclass(frozen=True)
class Sharding:
    """Metadata describing how a parameter should be sharded.

    Attributes:
        axis_names: Per-dimension logical axis names
            (e.g. ``("in", "out")``). Resolved through a user-supplied
            ``mesh_map`` at consumption time.
        mesh_axes: Pre-resolved per-dimension mesh axes
            (e.g. ``("data", "model")``). When present these override
            ``axis_names`` and are passed straight into
            :class:`~jax.sharding.PartitionSpec`.
    """

    axis_names: AxisNames | None = None
    mesh_axes: tuple[str | None, ...] | None = None

    def to_partition_spec(
        self,
        mesh_map: Mapping[str, str | None] | None = None,
    ) -> PartitionSpec | None:
        """Materialize a :class:`~jax.sharding.PartitionSpec`.

        Behavior:

        * If ``mesh_axes`` is set, build a ``PartitionSpec`` from those.
        * Else if ``axis_names`` is set and ``mesh_map`` is given, resolve
          each logical name via ``mesh_map`` (missing keys -> replicated).
        * Else if ``axis_names`` is set and ``mesh_map`` is ``None``,
          return a fully-replicated spec.
        * Else (no axis info) return an empty ``PartitionSpec()``.

        Returns ``None`` only when ``jax.sharding`` cannot be imported
        (e.g. in a reduced jax build).
        """

        if self.mesh_axes is not None:
            return Ps(*self.mesh_axes)
        if self.axis_names is None:
            return Ps()
        if mesh_map is None:
            return Ps(*[None for _ in self.axis_names])
        return Ps(*[mesh_map.get(n) if n is not None else None for n in self.axis_names])


def normalize_sharding(s: Sharding | AxisNames | None) -> Sharding | None:
    """Coerce a sharding spec into a :class:`Sharding` instance.

    Accepted inputs:

    * ``None`` — returns ``None``.
    * a :class:`Sharding` — returned unchanged.
    * an :data:`AxisNames` tuple — wrapped as
      ``Sharding(axis_names=s)``.

    Raises :class:`TypeError` on any other input.
    """
    if s is None:
        return None
    if isinstance(s, Sharding):
        return s
    if isinstance(s, tuple):
        return Sharding(axis_names=s)
    raise TypeError(f"Unsupported sharding spec: {s!r}")
