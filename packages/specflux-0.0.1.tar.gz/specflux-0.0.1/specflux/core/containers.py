# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module containers: :class:`Sequential`, :class:`ModuleList`,
:class:`ModuleDict`, :class:`ParameterList`.

Containers are :class:`~specflux.Module` subclasses that expose their
elements under integer or string keys instead of attribute names. They
override :meth:`_spx_graph_children` so traversal emits those keys
directly, producing paths like ``"blocks.0.fc.weight"``.
"""

from __future__ import annotations

from collections.abc import Iterable, Iterator, Mapping
from typing import Any, ClassVar, TypeVar, overload

import jax
import jax.numpy as jnp

from .module import Module
from .variable import Parameter, Variable

__all__ = [
    "ModuleDict",
    "ModuleList",
    "ParameterList",
    "Sequential",
]


M = TypeVar("M", bound=Module)
P = TypeVar("P", bound=Parameter)


class _ListContainer(Module):
    """Shared implementation for list-shaped containers.

    Stores elements in :attr:`_spx_items` and exposes ``__len__`` /
    ``__getitem__`` / ``__iter__`` / ``append`` / ``extend``. Subclasses
    override :meth:`_validate_item` to enforce an element type, and
    inherit :meth:`_spx_graph_children` which yields integer-keyed
    children.
    """

    _spx_items: list[Any]

    def __init__(self, items: Iterable[Any] = ()) -> None:
        """Construct the container from an iterable of items.

        Items are validated one by one via :meth:`_validate_item` before
        being stored.
        """
        super().__init__()
        materialized = list(items)
        for item in materialized:
            self._validate_item(item)
        object.__setattr__(self, "_spx_items", materialized)

    def __len__(self) -> int:
        """Number of stored elements."""
        return len(self._spx_items)

    @overload
    def __getitem__(self, idx: int) -> Any: ...
    @overload
    def __getitem__(self, idx: slice) -> _ListContainer: ...
    def __getitem__(self, idx: int | slice) -> Any:
        """Index or slice into the container.

        Integer indices return the single element. Slices return a new
        container of the same concrete type.
        """
        if isinstance(idx, slice):
            return type(self)(self._spx_items[idx])
        return self._spx_items[idx]

    def __iter__(self) -> Iterator[Any]:
        """Iterate over stored elements."""
        return iter(self._spx_items)

    def append(self, value: Any) -> None:
        """Append ``value``, validating its type first."""
        self._validate_item(value)
        self._spx_items.append(value)

    def extend(self, values: Iterable[Any]) -> None:
        """Append every item from ``values``."""
        for v in values:
            self.append(v)

    def _validate_item(self, value: Any) -> None:
        """Raise :class:`TypeError` if ``value`` is of an unacceptable type."""
        raise NotImplementedError

    def _spx_graph_children(self) -> Iterator[tuple[int, Module | Variable]]:
        """Yield ``(index, child)`` for every Module/Variable in the list."""
        for i, it in enumerate(self._spx_items):
            if isinstance(it, Module | Variable):
                yield i, it

    def _spx_static_fields(self) -> dict[str, Any]:
        """Containers have no static fields."""
        return {}


class ModuleList(_ListContainer):
    """Ordered list of :class:`~specflux.Module` s, indexable by integer.

    Not callable; use it as a plain Python container iterated or indexed
    by the owning module.

    When indexed with a JAX tracer (e.g. inside ``spx.fori_loop`` or
    ``jax.lax.scan``), the container transparently exports all modules,
    stacks their states, slices the requested index, and returns a live
    bound module. This makes patterns like::

        def body(i, m, x):
            return m.blocks[i](x)

    work inside compiled transforms without materialising constants.
    """

    _spx_container_kind: ClassVar[str] = "list"

    def __init__(self, items: Iterable[Module] = ()) -> None:
        """Construct from an iterable of modules."""
        super().__init__(items)

    def _validate_item(self, value: Any) -> None:
        """Require every item to be a :class:`~specflux.Module`."""
        if not isinstance(value, Module):
            raise TypeError(f"ModuleList accepts Modules only, got {type(value).__name__}")

    def forward(self, *args: Any, **kwargs: Any) -> Any:
        """Always raises — :class:`ModuleList` is not a callable layer."""
        raise RuntimeError("ModuleList is not callable; iterate or index it.")

    def __getitem__(self, idx: int | slice) -> Any:
        if isinstance(idx, slice):
            return type(self)(self._spx_items[idx])
        if not jax.core.is_concrete(idx):
            return self._get_traced(idx)
        return self._spx_items[idx]

    def _get_traced(self, idx: Any) -> Module:
        """Return the module at tracer index ``idx`` via export/stack/bind."""
        # Local imports avoid circularities at module-load time.
        from .graph import bind, export

        # Check for a pre-computed cache injected by control-flow primitives.
        cache = getattr(self, "_spx_traced_cache", None)
        if cache is not None:
            gdef, stacked = cache
            layer_state = jax.tree.map(lambda leaf: leaf[idx], stacked)
            return bind(gdef, layer_state)

        exports = [export(m) for m in self._spx_items]
        gdef = exports[0][0]
        states = [s for _, s in exports]
        stacked = jax.tree.map(lambda *vs: jnp.stack(vs, axis=0), *states)
        layer_state = jax.tree.map(lambda leaf: leaf[idx], stacked)
        return bind(gdef, layer_state)

    def scan(self, fn, init_carry):
        """Scan over modules: ``fn(module, carry) -> new_carry``.

        Exports all modules, stacks their states, and runs
        ``jax.lax.scan`` with pytree-level slicing.
        """
        from .graph import bind, export

        cache = getattr(self, "_spx_traced_cache", None)
        if cache is not None:
            gdef, stacked = cache
        else:
            exports = [export(m) for m in self._spx_items]
            gdef = exports[0][0]
            states = [s for _, s in exports]
            stacked = jax.tree.map(lambda *vs: jnp.stack(vs, axis=0), *states)

        def body(carry, layer_state):
            live = bind(gdef, layer_state)
            return fn(live, carry), None

        return jax.lax.scan(body, init_carry, stacked)[0]

    def fori_loop(self, fn, init_carry):
        """fori_loop over modules: ``fn(i, module, carry) -> new_carry``.

        Exports all modules, stacks their states, and runs
        ``jax.lax.fori_loop`` with pytree-level slicing.
        """
        from .graph import bind, export

        cache = getattr(self, "_spx_traced_cache", None)
        if cache is not None:
            gdef, stacked = cache
        else:
            exports = [export(m) for m in self._spx_items]
            gdef = exports[0][0]
            states = [s for _, s in exports]
            stacked = jax.tree.map(lambda *vs: jnp.stack(vs, axis=0), *states)

        def body(i, carry):
            layer_state = jax.tree.map(lambda leaf: leaf[i], stacked)
            live = bind(gdef, layer_state)
            return fn(i, live, carry)

        return jax.lax.fori_loop(0, len(self), body, init_carry)


class Sequential(_ListContainer):
    """Callable chain of modules: output of one is input of the next.

    Forwards ``**kwargs`` through the chain; if a child's ``forward``
    does not accept them the call falls back to a positional-only
    invocation.
    """

    _spx_container_kind: ClassVar[str] = "sequential"

    def __init__(self, *modules: Module) -> None:
        """Construct from positional modules."""
        super().__init__(modules)

    def _validate_item(self, value: Any) -> None:
        """Require every item to be a :class:`~specflux.Module`."""
        if not isinstance(value, Module):
            raise TypeError(f"Sequential accepts Modules only, got {type(value).__name__}")

    def forward(self, x: Any, **kwargs: Any) -> Any:
        """Thread ``x`` through the chain, passing ``**kwargs`` where accepted."""
        for m in self._spx_items:
            try:
                x = m(x, **kwargs)
            except TypeError:
                x = m(x)
        return x


class ParameterList(_ListContainer):
    """Ordered list of :class:`~specflux.Parameter` s."""

    _spx_container_kind: ClassVar[str] = "list"

    def __init__(self, items: Iterable[Parameter] = ()) -> None:
        """Construct from an iterable of parameters."""
        super().__init__(items)

    def _validate_item(self, value: Any) -> None:
        """Require every item to be a :class:`~specflux.Parameter`."""
        if not isinstance(value, Parameter):
            raise TypeError(f"ParameterList accepts Parameters only, got {type(value).__name__}")

    def forward(self, *args: Any, **kwargs: Any) -> Any:
        """Always raises — :class:`ParameterList` is not a callable layer."""
        raise RuntimeError("ParameterList is not callable.")


class ModuleDict(Module):
    """String-keyed dict of :class:`~specflux.Module` s.

    Keys are plain Python strings; iteration preserves insertion order.
    Not callable; access children by key.
    """

    _spx_container_kind: ClassVar[str] = "dict"

    _spx_items: dict[str, Module]

    def __init__(self, items: Mapping[str, Module] | None = None) -> None:
        """Construct from an optional ``{name: module}`` mapping."""
        super().__init__()
        object.__setattr__(self, "_spx_items", {})
        if items:
            for k, v in items.items():
                self[k] = v

    def __setitem__(self, key: str, value: Module) -> None:
        """Assign ``value`` under ``key``, validating both types."""
        if not isinstance(value, Module):
            raise TypeError(f"ModuleDict accepts Modules only, got {type(value).__name__}")
        if not isinstance(key, str):
            raise TypeError(f"ModuleDict keys must be str, got {type(key).__name__}")
        self._spx_items[key] = value

    def __getitem__(self, key: str) -> Module:
        """Return the module stored under ``key``."""
        return self._spx_items[key]

    def __contains__(self, key: object) -> bool:
        """Membership test by key."""
        return key in self._spx_items

    def __len__(self) -> int:
        """Number of stored entries."""
        return len(self._spx_items)

    def __iter__(self) -> Iterator[str]:
        """Iterate over keys."""
        return iter(self._spx_items)

    def keys(self) -> Iterable[str]:
        """Return the dict's keys."""
        return self._spx_items.keys()

    def values(self) -> Iterable[Module]:
        """Return the dict's values."""
        return self._spx_items.values()

    def items(self) -> Iterable[tuple[str, Module]]:
        """Return the dict's ``(key, value)`` pairs."""
        return self._spx_items.items()

    def _spx_graph_children(self) -> Iterator[tuple[str, Module | Variable]]:
        """Yield ``(key, child)`` for every entry in insertion order."""
        yield from self._spx_items.items()

    def _spx_static_fields(self) -> dict[str, Any]:
        """Containers have no static fields."""
        return {}

    def forward(self, *args: Any, **kwargs: Any) -> Any:
        """Always raises — :class:`ModuleDict` is not a callable layer."""
        raise RuntimeError("ModuleDict is not callable; index by key.")
