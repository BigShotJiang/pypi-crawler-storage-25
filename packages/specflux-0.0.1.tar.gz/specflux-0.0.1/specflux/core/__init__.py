# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""SpecFlux core: variables, modules, graph, state, selectors, and errors.

This subpackage contains the runtime foundation every other specflux
subpackage builds on. Public names are re-exported here for convenience;
:mod:`specflux` itself re-exports them again for end users.
"""

from .errors import (
    CyclicGraphError,
    IllegalMutationError,
    LazyInitUnderTransformError,
    SelectorError,
    SpecFluxError,
)
from .lazy_init import lazy_init
from .paths import Path, path_to_str, str_to_path
from .policy import Policy
from .registry import qualified_name, resolve_class
from .sharding import AxisNames, Sharding
from .stage_assignment import assign_stage
from .static import Static
from .variable import Buffer, Parameter, Variable

__all__ = [
    "AxisNames",
    "Buffer",
    "CyclicGraphError",
    "IllegalMutationError",
    "LazyInitUnderTransformError",
    "Parameter",
    "Path",
    "Policy",
    "SelectorError",
    "Sharding",
    "SpecFluxError",
    "Static",
    "Variable",
    "assign_stage",
    "lazy_init",
    "path_to_str",
    "qualified_name",
    "resolve_class",
    "str_to_path",
]
