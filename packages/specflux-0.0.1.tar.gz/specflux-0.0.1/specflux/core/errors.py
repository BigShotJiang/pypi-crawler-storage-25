# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Typed exception hierarchy raised by specflux.

Every exception specflux raises inherits from :class:`SpecFluxError` so that
user code can catch all specflux-originated failures with a single
``except specflux.SpecFluxError`` clause. Individual subclasses describe
the class of failure:

* :class:`CyclicGraphError` — a module graph contains a cycle (a module
  reaches itself by following child references).
* :class:`IllegalMutationError` — a collection that was not declared
  ``mutable=`` was written to during a specflux transform.
* :class:`LazyInitUnderTransformError` — a lazy layer attempted to
  materialize while a specflux transform was active.
* :class:`SelectorError` — a :class:`~specflux.Selector` predicate raised,
  or a selector sugar value could not be coerced.
* :class:`PolicyError` — an invalid dtype policy was applied to a module.
* :class:`GraphStructureError` — the module graph or graph-def violates a
  structural invariant (non-module child, unknown container kind, etc.).
"""

from __future__ import annotations


class SpecFluxError(Exception):
    """Base class for every exception raised by specflux."""


class CyclicGraphError(SpecFluxError):
    """Raised when a module's graph contains a cycle.

    A cycle is detected when a traversal of child modules/variables reaches
    a module that is already on the active traversal stack.
    """


class IllegalMutationError(SpecFluxError):
    """Raised when a non-mutable collection changed under a transform.

    SpecFlux transforms capture all :class:`~specflux.Variable` writes that
    occur while the transform body executes. Writes to collections not
    listed in the ``mutable=`` selector of the transform are forbidden;
    encountering one raises this error.
    """


class LazyInitUnderTransformError(SpecFluxError):
    """Raised when a lazy layer materializes inside a specflux transform.

    Deferred parameters (e.g. :class:`~specflux.DeferredParameter`) infer
    their shape from the first input. Running materialization under ``jit`` /
    ``grad`` / ``vmap`` would silently bake the inferred shape into a traced
    program so it is refused eagerly.
    """


class SelectorError(SpecFluxError):
    """Raised for invalid :class:`~specflux.Selector` usage.

    Raised either when a predicate passed to a selector raises (wrapped and
    re-raised as ``SelectorError``) or when :func:`specflux.as_selector`
    cannot coerce a value to a :class:`~specflux.Selector`.
    """


class PolicyError(SpecFluxError):
    """Raised for invalid dtype policy configuration on a module."""


class GraphStructureError(SpecFluxError):
    """Raised when a graph or graph-def violates a structural invariant.

    Covers unexpected child types during traversal, missing or malformed
    nodes in a :class:`~specflux.GraphDef`, non-``str`` keys in a
    :class:`~specflux.nn.ModuleDict`, and similar low-level structural
    violations.
    """
