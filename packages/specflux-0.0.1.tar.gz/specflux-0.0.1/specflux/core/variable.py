# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The :class:`Variable` reference cell.

:class:`Variable` is the only mutable value specflux modules own. It is:

* identified by a process-wide unique ``ref_id`` allocated at
  construction, used by :func:`~specflux.export` to detect shared state;
* tagged with a ``kind`` (its collection — ``"params"``, ``"buffers"``,
  ``"batch_stats"``, ``"cache"``, ``"intermediates"``, ``"rng"``, or any
  user-defined string);
* a carrier of free-form ``metadata`` (sharding, logical axis names,
  tie group tags, …); and
* transparently array-like: arithmetic and the array protocols
  (``__array__``, ``__jax_array__``) delegate to ``.value``.

Sharing by identity (the same :class:`Variable` instance appearing at
two attribute paths) is the canonical mechanism for tied weights. The
``ref_id`` remains stable across ``export`` / ``bind`` round-trips so
downstream consumers can key on it.

Writes to ``.value`` are immediate in eager mode. Under a specflux
transform the transforms module installs a thread-local write hook that
intercepts writes and redirects them into the traced state, which is
how mutations (e.g. batch-norm running stats) survive the transform
boundary.
"""

from __future__ import annotations

import contextlib
import itertools
import threading
from collections.abc import Callable
from typing import Any, ClassVar

import jax
import jax.numpy as jnp
import numpy as np

from ._typing import Array, ArrayLike, DType, VariableObserver
from .sharding import Sharding, normalize_sharding
from .stage_assignment import (
    PIPELINE_STAGE_METADATA_KEY,
    current_stage_assignment,
    metadata_stage_assignment,
    resolve_stage_rank,
)

__all__ = ["KINDS_BUILTIN", "Buffer", "DeferredBuffer", "DeferredParameter", "Parameter", "Variable"]


_REF_COUNTER = itertools.count(1)
_ref_lock = threading.Lock()


def _fresh_ref_id() -> int:
    """Allocate a fresh process-unique ``ref_id`` (thread-safe)."""
    with _ref_lock:
        return next(_REF_COUNTER)


def _maybe_stamped_sharding(value: Any) -> Sharding | None:
    """Return any initializer-stamped sharding metadata on ``value``."""
    stamped = getattr(value, "_spx_sharding", None)
    return normalize_sharding(stamped) if stamped is not None else None


def _existing_value_sharding(value: Any) -> Any | None:
    """Return the concrete sharding already carried by ``value``, if any."""
    return getattr(value, "sharding", None)


_WRITE_HOOK: threading.local = threading.local()


def _set_write_hook(hook: Callable[[Variable, Any], bool] | None) -> None:
    """Install a thread-local write hook for :class:`Variable` writes.

    The hook signature is ``hook(var, new) -> bool``. If the hook returns
    ``True`` it is considered to have handled the write, and the normal
    eager write is suppressed. Passing ``None`` restores the default eager
    behavior.

    Used by the transforms module to redirect writes into the traced
    state carried across the transform boundary.
    """
    _WRITE_HOOK.hook = hook


def _get_write_hook() -> Callable[[Variable, Any], bool] | None:
    """Return the currently-installed write hook, or ``None``."""
    return getattr(_WRITE_HOOK, "hook", None)


_READ_HOOK: threading.local = threading.local()


def _set_read_hook(hook: Callable[[Variable], Any] | None) -> None:
    """Install a thread-local read hook for :class:`Variable` reads.

    The hook signature is ``hook(var) -> Any`` and its return value is
    used in place of the underlying ``_value``. Passing ``None`` restores
    the default eager read behavior.
    """
    _READ_HOOK.hook = hook


def _get_read_hook() -> Callable[[Variable], Any] | None:
    """Return the currently-installed read hook, or ``None``."""
    return getattr(_READ_HOOK, "hook", None)


KINDS_BUILTIN: tuple[str, ...] = (
    "params",
    "buffers",
    "batch_stats",
    "cache",
    "intermediates",
    "rng",
)
"""The collection names specflux reserves for built-in use.

User-defined collections are permitted; avoid the reserved names.
"""


class Variable:
    """Reference cell with identity, kind, metadata, and array delegation.

    :class:`Variable` is the base class. Use :class:`Parameter` for
    trainable weights and :class:`Buffer` for non-trainable state
    (running statistics, caches, …). Subclasses may override
    :attr:`default_kind` to set a per-class default collection.

    Attributes:
        _value: The underlying array. Access via the :attr:`value`
            property so read/write hooks run.
        kind: The collection this variable belongs to.
        metadata: A free-form dict of per-variable metadata
            (``"sharding"``, ``"axis_names"``, ``"tie_group"``, …).
        ref_id: Process-unique integer identity, stable across
            export/bind. Used by :func:`~specflux.export` to detect
            shared variables.
        _observers: Callbacks invoked on each successful write in eager
            mode. See :meth:`add_observer`.
    """

    default_kind: ClassVar[str] = "buffers"
    """Default :attr:`kind` for instances of this class."""

    __slots__ = (
        "_observers",
        "_value",
        "kind",
        "metadata",
        "ref_id",
    )

    _value: Any
    kind: str
    metadata: dict[str, Any]
    ref_id: int
    _observers: list[VariableObserver]

    def __init__(
        self,
        value: ArrayLike,
        *,
        kind: str | None = None,
        metadata: dict[str, Any] | None = None,
        ref_id: int | None = None,
    ) -> None:
        """Construct a reference cell wrapping ``value``.

        Args:
            value: The initial array (or array-like). Not coerced here;
              subclasses that need coercion do it themselves.
            kind: Override the default collection. ``None`` falls back to
              :attr:`default_kind`.
            metadata: Free-form per-variable metadata. A shallow copy is
              made.
            ref_id: An explicit ``ref_id`` to adopt. When ``None``
              (the common case) a fresh id is allocated.
        """
        self._value = value
        self.kind = kind if kind is not None else type(self).default_kind
        self.metadata = dict(metadata) if metadata else {}
        assignment = current_stage_assignment()
        if assignment is not None and PIPELINE_STAGE_METADATA_KEY not in self.metadata:
            self.metadata[PIPELINE_STAGE_METADATA_KEY] = assignment
        self.ref_id = ref_id if ref_id is not None else _fresh_ref_id()
        self._observers = []

    @property
    def value(self) -> Array:
        """Read the stored array.

        If a thread-local read hook is installed it is consulted first;
        otherwise the raw underlying value is returned.
        """
        read_hook = _get_read_hook()
        if read_hook is not None:
            return read_hook(self)
        return self._value

    @value.setter
    def value(self, new: ArrayLike) -> None:
        """Write ``new`` to the cell.

        Under a specflux transform the installed write hook may claim
        the write (returning ``True``), in which case the underlying
        storage is left untouched. Otherwise the value is stored and
        every registered :class:`~specflux.typing.VariableObserver` is
        notified; observer exceptions are swallowed.
        """
        hook = _get_write_hook()
        if hook is not None and hook(self, new):
            return
        old = self._value
        self._value = new
        for obs in list(self._observers):
            with contextlib.suppress(Exception):
                obs(self, old, new)

    def _raw_get(self) -> Any:
        """Return the underlying value, bypassing any installed hooks.

        Used by the graph / transform machinery that must not be
        redirected by its own hooks.
        """
        return self._value

    def _raw_set(self, new: Any) -> None:
        """Write ``new`` to the cell, bypassing hooks and observers.

        Used by the graph / transform machinery to apply a state patch
        back to a live module after a transform.
        """
        self._value = new

    def add_observer(self, fn: VariableObserver) -> None:
        """Register ``fn`` to be called on each eager write.

        Observers are not invoked under specflux transforms (writes are
        redirected by the write hook before observers run).
        """
        self._observers.append(fn)

    def remove_observer(self, fn: VariableObserver) -> None:
        """Unregister a previously-added observer (no-op if absent)."""
        if fn in self._observers:
            self._observers.remove(fn)

    @property
    def sharding(self) -> Sharding | None:
        """Return the :class:`Sharding` from :attr:`metadata` or ``None``."""
        s = self.metadata.get("sharding")
        return normalize_sharding(s) if s is not None else None

    @property
    def axis_names(self) -> tuple[str | None, ...] | None:
        """Return the logical axis names from :attr:`metadata` or ``None``."""
        names = self.metadata.get("axis_names")
        return tuple(names) if names is not None else None

    @property
    def stage_assignment(self) -> tuple[int, int] | None:
        """Return the logical ``(current, total)`` stage hint, if any."""
        return metadata_stage_assignment(self.metadata)

    @property
    def stage_index(self) -> int | None:
        """Return the variable's logical stage index within :attr:`stage_count`.

        This is the construction-time ``current`` value from
        ``assign_stage(total=..., current=...)``. Use
        :meth:`resolved_stage_index` to map it onto a concrete MPMD mesh.
        """
        assignment = self.stage_assignment
        return assignment[0] if assignment is not None else None

    @property
    def stage_count(self) -> int | None:
        """Return the logical number of stage slots the variable was tagged in."""
        assignment = self.stage_assignment
        return assignment[1] if assignment is not None else None

    def resolved_stage_index(self, mesh_or_dim: Any) -> int | None:
        """Resolve :attr:`stage_index` onto a physical MPMD stage index.

        ``mesh_or_dim`` may be:

        * an integer ``mpmd_dim``
        * a :class:`~specflux.sharding.SpxMesh`
        * a :class:`~specflux.pipeline.MpMdMesh`

        Returns ``None`` when the variable has no stage hint or when an
        ``SpxMesh`` without an MPMD axis is supplied.
        """
        mpmd_dim: int | None
        if isinstance(mesh_or_dim, int):
            mpmd_dim = mesh_or_dim
        else:
            from ..runtime.types.mesh import MpMdMesh
            from ..sharding.mesh import SpxMesh

            if isinstance(mesh_or_dim, SpxMesh):
                mpmd_dim = mesh_or_dim.mpmd_mesh.mpmd_dim if mesh_or_dim.is_mpmd else None
            elif isinstance(mesh_or_dim, MpMdMesh):
                mpmd_dim = mesh_or_dim.mpmd_dim
            else:
                raise TypeError(
                    "resolved_stage_index(mesh_or_dim): expected an int, "
                    f"SpxMesh, or MpMdMesh; got {type(mesh_or_dim).__name__}."
                )
        if mpmd_dim is None:
            return None
        return resolve_stage_rank(self.stage_assignment, mpmd_dim)

    def stage_mesh(self, mesh: Any) -> Any:
        """Return the stage-local mesh this variable should live on.

        For non-MPMD meshes, returns the input mesh unchanged (or its
        underlying ``jax_mesh`` for :class:`~specflux.sharding.SpxMesh`).
        For MPMD meshes plus a stage-tagged variable, returns the owning
        stage sub-mesh.
        """
        from ..runtime.types.mesh import MpMdMesh
        from ..sharding.mesh import SpxMesh

        if isinstance(mesh, SpxMesh):
            if not mesh.is_mpmd:
                return mesh.jax_mesh
            owner = self.resolved_stage_index(mesh)
            return mesh.mpmd_mesh.submesh(owner) if owner is not None else mesh.jax_mesh
        if isinstance(mesh, MpMdMesh):
            owner = self.resolved_stage_index(mesh)
            return mesh.submesh(owner) if owner is not None else mesh.jax_mesh
        return mesh

    def named_sharding(self, mesh: Any) -> Any:
        """Resolve this variable's metadata to a ``NamedSharding``."""
        from ..sharding.partition import named_sharding_for_variable

        return named_sharding_for_variable(self, mesh)

    def __array__(self, dtype: DType | None = None, copy: bool | None = None) -> np.ndarray:
        """Implement the NumPy array protocol so ``np.asarray(var)`` works.

        The NumPy 2 ``copy`` keyword is accepted and ignored; copy
        semantics are delegated to :func:`jax.numpy.asarray`.
        """
        del copy
        v = self.value
        if dtype is None:
            return np.asarray(v)
        return np.asarray(v, dtype=dtype)

    def __jax_array__(self) -> Array:
        """Implement the JAX array protocol so ``jnp.asarray(var) is var.value``."""
        return self.value

    @property
    def shape(self) -> tuple[int, ...]:
        """Shape of the stored array."""
        return tuple(self.value.shape)

    @property
    def dtype(self) -> Any:
        """Dtype of the stored array."""
        return self.value.dtype

    @property
    def ndim(self) -> int:
        """Rank (number of dimensions) of the stored array."""
        return int(self.value.ndim)

    @property
    def size(self) -> int:
        """Total number of elements in the stored array."""
        return int(self.value.size)

    def astype(self, dtype: DType) -> Array:
        """Return the value cast to ``dtype`` (not a Variable)."""
        return jnp.asarray(self.value, dtype=dtype)

    @staticmethod
    def _v(other: Any) -> Any:
        """Unwrap a :class:`Variable` (or pass through) for arithmetic ops."""
        return other.value if isinstance(other, Variable) else other

    def __pos__(self) -> Array:
        """Unary ``+``."""
        return +self.value

    def __neg__(self) -> Array:
        """Unary ``-``."""
        return -self.value

    def __abs__(self) -> Array:
        """``abs(var)``."""
        return abs(self.value)

    def __add__(self, o: Any) -> Array:
        """``var + o``."""
        return self.value + self._v(o)

    def __radd__(self, o: Any) -> Array:
        """``o + var``."""
        return self._v(o) + self.value

    def __sub__(self, o: Any) -> Array:
        """``var - o``."""
        return self.value - self._v(o)

    def __rsub__(self, o: Any) -> Array:
        """``o - var``."""
        return self._v(o) - self.value

    def __mul__(self, o: Any) -> Array:
        """``var * o``."""
        return self.value * self._v(o)

    def __rmul__(self, o: Any) -> Array:
        """``o * var``."""
        return self._v(o) * self.value

    def __truediv__(self, o: Any) -> Array:
        """``var / o``."""
        return self.value / self._v(o)

    def __rtruediv__(self, o: Any) -> Array:
        """``o / var``."""
        return self._v(o) / self.value

    def __floordiv__(self, o: Any) -> Array:
        """``var // o``."""
        return self.value // self._v(o)

    def __mod__(self, o: Any) -> Array:
        """``var % o``."""
        return self.value % self._v(o)

    def __pow__(self, o: Any) -> Array:
        """``var ** o``."""
        return self.value ** self._v(o)

    def __rpow__(self, o: Any) -> Array:
        """``o ** var``."""
        return self._v(o) ** self.value

    def __matmul__(self, o: Any) -> Array:
        """``var @ o``."""
        return self.value @ self._v(o)

    def __rmatmul__(self, o: Any) -> Array:
        """``o @ var``."""
        return self._v(o) @ self.value

    def __getitem__(self, idx: Any) -> Array:
        """``var[idx]`` — indexes into the stored array."""
        return self.value[idx]

    def __eq__(self, o: object) -> bool:
        """Identity-based equality: two Variables compare equal iff their
        ``ref_id`` matches. This keeps :class:`Variable` hashable and
        usable as a dict key.
        """
        if isinstance(o, Variable):
            return self.ref_id == o.ref_id
        return NotImplemented

    def __ne__(self, o: object) -> bool:
        """Inverse of :meth:`__eq__`."""
        r = self.__eq__(o)
        return r if r is NotImplemented else not r

    def __hash__(self) -> int:
        """Hash derived from :attr:`ref_id`."""
        return hash(("specflux.Variable", self.ref_id))

    def __bool__(self) -> bool:
        """``bool(var)`` — delegates to the stored array's truth value."""
        return bool(self.value)

    def __repr__(self) -> str:
        """Compact diagnostic repr with class, kind, shape, dtype, ref id."""
        try:
            shape = tuple(self.value.shape)
            dtype = self.value.dtype
            return f"{type(self).__name__}(kind={self.kind!r}, shape={shape}, dtype={dtype}, ref={self.ref_id})"
        except Exception:
            return f"{type(self).__name__}(kind={self.kind!r}, ref={self.ref_id})"


class Parameter(Variable):
    """Trainable weight.

    Default :attr:`kind` is ``"params"`` (or ``"buffers"`` when
    ``trainable=False``). :func:`~specflux.grad` differentiates with
    respect to ``"params"`` by default.
    """

    default_kind: ClassVar[str] = "params"

    def __init__(
        self,
        value: ArrayLike,
        *,
        dtype: DType | None = None,
        sharding: Sharding | tuple[str | None, ...] | None = None,
        axis_names: tuple[str | None, ...] | None = None,
        trainable: bool = True,
        metadata: dict[str, Any] | None = None,
        ref_id: int | None = None,
    ) -> None:
        """Construct a parameter cell.

        Args:
            value: Initial array.
            dtype: Storage dtype. ``None`` preserves the value's dtype.
            sharding: Sharding spec — a :class:`Sharding` or a tuple of
              logical axis names.
            axis_names: Per-dimension logical axis names.
            trainable: ``True`` stores under ``"params"``; ``False``
              stores under ``"buffers"`` so :func:`~specflux.grad`
              excludes it by default.
            metadata: Additional metadata (merged into :attr:`metadata`).
            ref_id: Explicit ``ref_id`` to adopt.
        """
        meta: dict[str, Any] = dict(metadata) if metadata else {}
        stamped_sharding = _maybe_stamped_sharding(value)
        assignment = current_stage_assignment()
        if sharding is not None:
            meta["sharding"] = normalize_sharding(sharding)
        elif stamped_sharding is not None:
            meta["sharding"] = stamped_sharding
        if axis_names is not None:
            meta["axis_names"] = tuple(axis_names)
        if assignment is not None and PIPELINE_STAGE_METADATA_KEY not in meta:
            meta[PIPELINE_STAGE_METADATA_KEY] = assignment
        arr = _initialize_value(value, dtype, metadata=meta, explicit_sharding=sharding is not None)
        super().__init__(
            arr,
            kind="params" if trainable else "buffers",
            metadata=meta,
            ref_id=ref_id,
        )


class Buffer(Variable):
    """Non-trainable state (running means, counters, KV caches, ...).

    Default :attr:`kind` is ``"buffers"``; pass an explicit ``kind=`` to
    route to another collection (``"batch_stats"``, ``"cache"``, …).
    """

    default_kind: ClassVar[str] = "buffers"

    def __init__(
        self,
        value: ArrayLike,
        *,
        dtype: DType | None = None,
        kind: str | None = None,
        sharding: Sharding | tuple[str | None, ...] | None = None,
        axis_names: tuple[str | None, ...] | None = None,
        metadata: dict[str, Any] | None = None,
        ref_id: int | None = None,
    ) -> None:
        """Construct a buffer cell.

        Args:
            value: Initial array.
            dtype: Storage dtype. ``None`` preserves the value's dtype.
            kind: Override the collection. ``None`` uses
              :attr:`default_kind` (``"buffers"``).
            sharding: Sharding spec.
            axis_names: Per-dimension logical axis names.
            metadata: Additional metadata.
            ref_id: Explicit ``ref_id`` to adopt.
        """
        meta: dict[str, Any] = dict(metadata) if metadata else {}
        stamped_sharding = _maybe_stamped_sharding(value)
        assignment = current_stage_assignment()
        if sharding is not None:
            meta["sharding"] = normalize_sharding(sharding)
        elif stamped_sharding is not None:
            meta["sharding"] = stamped_sharding
        if axis_names is not None:
            meta["axis_names"] = tuple(axis_names)
        if assignment is not None and PIPELINE_STAGE_METADATA_KEY not in meta:
            meta[PIPELINE_STAGE_METADATA_KEY] = assignment
        arr = _initialize_value(value, dtype, metadata=meta, explicit_sharding=sharding is not None)
        super().__init__(
            arr,
            kind=kind if kind is not None else "buffers",
            metadata=meta,
            ref_id=ref_id,
        )


class DeferredParameter(Parameter):
    """Parameter whose shape is resolved lazily during the first forward pass.

    Stores an initializer and a *shape specification* (which may contain
    ``None`` placeholders) instead of a concrete array.  On first access
    :attr:`value` returns a zero array of the resolved shape so the forward
    pass can execute for shape inference.  Calling :meth:`materialize`
    replaces the placeholder with a real initialized array.

    Built-in layers such as :class:`~specflux.nn.Linear` create a
    ``DeferredParameter`` automatically when an input dimension is passed as
    ``None``.
    """

    def __init__(
        self,
        shape_spec: tuple[int | None, ...],
        init: Callable[[Any, tuple[int, ...], Any], Any],
        rngs: Any,
        dtype: Any,
        *,
        sharding: Sharding | tuple[str | None, ...] | None = None,
        axis_names: tuple[str | None, ...] | None = None,
        trainable: bool = True,
        metadata: dict[str, Any] | None = None,
        ref_id: int | None = None,
    ) -> None:
        meta: dict[str, Any] = dict(metadata) if metadata else {}
        if sharding is not None:
            meta["sharding"] = normalize_sharding(sharding)
        if axis_names is not None:
            meta["axis_names"] = tuple(axis_names)
        super().__init__(jnp.zeros(1, dtype=dtype), dtype=dtype, metadata=meta, ref_id=ref_id, trainable=trainable)
        self._deferred_shape_spec = tuple(shape_spec)
        self._deferred_init = init
        self._deferred_rngs = rngs
        self._deferred_dtype = dtype
        self._deferred_resolved_shape: tuple[int, ...] | None = None
        self._deferred_materialized = False

    @property
    def is_materialized(self) -> bool:
        """Whether this deferred parameter has been materialized."""
        return getattr(self, "_deferred_materialized", False)

    def resolve_shape(self, shape: tuple[int, ...]) -> None:
        """Set the concrete shape.

        Raises if the resolved rank disagrees with the specification.
        """
        if self.is_materialized:
            return
        if len(shape) != len(self._deferred_shape_spec):
            raise ValueError(f"DeferredParameter expected rank {len(self._deferred_shape_spec)}, got {len(shape)}")
        self._deferred_resolved_shape = tuple(int(s) for s in shape)

    def materialize(self) -> None:
        """Call the stored initializer and replace the placeholder value."""
        if self.is_materialized:
            return
        if getattr(self, "_deferred_resolved_shape", None) is None:
            raise RuntimeError("DeferredParameter shape not resolved. Run a forward pass first.")
        arr = self._deferred_init(self._deferred_rngs, self._deferred_resolved_shape, self._deferred_dtype)
        arr = _initialize_value(arr, None, metadata=self.metadata, explicit_sharding="sharding" in self.metadata)
        self._raw_set(arr)
        self._deferred_materialized = True

    @property
    def value(self) -> Array:
        if self.is_materialized:
            return super().value
        if getattr(self, "_deferred_resolved_shape", None) is None:
            raise RuntimeError("DeferredParameter shape not resolved. Run a forward pass first.")
        return jnp.zeros(self._deferred_resolved_shape, self._deferred_dtype)

    @value.setter
    def value(self, new: ArrayLike) -> None:
        self._deferred_materialized = True
        super(DeferredParameter, self.__class__).value.fset(self, new)


class DeferredBuffer(Buffer):
    """Buffer whose shape is resolved lazily during the first forward pass.

    Mirrors :class:`DeferredParameter` for non-trainable state.
    """

    def __init__(
        self,
        shape_spec: tuple[int | None, ...],
        init: Callable[[Any, tuple[int, ...], Any], Any],
        rngs: Any,
        dtype: Any,
        *,
        kind: str | None = None,
        sharding: Sharding | tuple[str | None, ...] | None = None,
        axis_names: tuple[str | None, ...] | None = None,
        metadata: dict[str, Any] | None = None,
        ref_id: int | None = None,
    ) -> None:
        meta: dict[str, Any] = dict(metadata) if metadata else {}
        if sharding is not None:
            meta["sharding"] = normalize_sharding(sharding)
        if axis_names is not None:
            meta["axis_names"] = tuple(axis_names)
        super().__init__(jnp.zeros(1, dtype=dtype), dtype=dtype, kind=kind, metadata=meta, ref_id=ref_id)
        self._deferred_shape_spec = tuple(shape_spec)
        self._deferred_init = init
        self._deferred_rngs = rngs
        self._deferred_dtype = dtype
        self._deferred_resolved_shape: tuple[int, ...] | None = None
        self._deferred_materialized = False

    @property
    def is_materialized(self) -> bool:
        return getattr(self, "_deferred_materialized", False)

    def resolve_shape(self, shape: tuple[int, ...]) -> None:
        if self.is_materialized:
            return
        if len(shape) != len(self._deferred_shape_spec):
            raise ValueError(f"DeferredBuffer expected rank {len(self._deferred_shape_spec)}, got {len(shape)}")
        self._deferred_resolved_shape = tuple(int(s) for s in shape)

    def materialize(self) -> None:
        if self.is_materialized:
            return
        if getattr(self, "_deferred_resolved_shape", None) is None:
            raise RuntimeError("DeferredBuffer shape not resolved. Run a forward pass first.")
        arr = self._deferred_init(self._deferred_rngs, self._deferred_resolved_shape, self._deferred_dtype)
        arr = _initialize_value(arr, None, metadata=self.metadata, explicit_sharding="sharding" in self.metadata)
        self._raw_set(arr)
        self._deferred_materialized = True

    @property
    def value(self) -> Array:
        if self.is_materialized:
            return super().value
        if getattr(self, "_deferred_resolved_shape", None) is None:
            raise RuntimeError("DeferredBuffer shape not resolved. Run a forward pass first.")
        return jnp.zeros(self._deferred_resolved_shape, self._deferred_dtype)

    @value.setter
    def value(self, new: ArrayLike) -> None:
        self._deferred_materialized = True
        super(DeferredBuffer, self.__class__).value.fset(self, new)


def _initialize_value(
    value: ArrayLike,
    dtype: DType | None,
    *,
    metadata: dict[str, Any],
    explicit_sharding: bool,
) -> Any:
    """Coerce ``value`` and apply constructor-time sharding when available."""
    arr = _coerce_value(value, dtype)
    if not hasattr(arr, "shape") or not hasattr(arr, "dtype"):
        return arr

    from ..sharding.mesh import current_mesh
    from ..sharding.partition import named_sharding_for_metadata

    mesh = current_mesh()
    if mesh is None:
        return arr

    existing = _existing_value_sharding(arr)
    if existing is not None and not explicit_sharding and PIPELINE_STAGE_METADATA_KEY not in metadata:
        return arr

    sharding = named_sharding_for_metadata(metadata, mesh)
    if sharding is None:
        return arr
    if existing is not None and existing == sharding:
        return arr

    return jax.device_put(arr, sharding)


def _coerce_value(value: ArrayLike, dtype: DType | None) -> Any:
    """Coerce ``value`` while preserving existing JAX-array sharding."""
    if hasattr(value, "sharding") and hasattr(value, "dtype"):
        return value.astype(dtype) if dtype is not None else value
    if dtype is not None:
        return jnp.asarray(value, dtype=dtype)
    return _as_array(value)


def _as_array(value: ArrayLike) -> Any:
    """Coerce ``value`` to a JAX array when it is concrete enough to do so.

    Pass-through on values that are already traced or unrecognized so
    that abstract tracers flow untouched through layer construction.
    """
    if isinstance(value, np.ndarray | jnp.ndarray | int | float | complex | bool | list | tuple):
        return jnp.asarray(value)
    return value
