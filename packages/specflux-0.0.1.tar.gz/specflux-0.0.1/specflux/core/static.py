# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Static module attributes.

A *static* module attribute is one whose identity and value contribute to
:class:`~specflux.GraphDef`, and whose change therefore forces a retrace
under transforms. Most hyperparameters (``num_heads``, ``use_bias``, …)
are naturally static: they are plain immutable Python scalars assigned
during ``__init__``. :class:`Static` is the explicit generic form that
makes the static-ness visible in type signatures and also supports
wrapping compound-but-hashable values.
"""

from __future__ import annotations

from typing import Generic, TypeVar

T = TypeVar("T")


class Static(Generic[T]):
    """Explicit marker that an attribute belongs to :class:`~specflux.GraphDef`.

    Wrapping a value in ``Static`` declares that it is a hyperparameter:
    its identity participates in graph-def equality and hashing, and any
    change triggers a retrace under specflux transforms.

    Example:
        ``self.activation = Static("gelu")``

    The stored value is available as ``.value`` and is compared
    structurally.
    """

    __slots__ = ("value",)

    def __init__(self, value: T) -> None:
        """Wrap ``value`` as a static marker."""
        self.value = value

    def __repr__(self) -> str:
        """Return ``Static(<repr of value>)``."""
        return f"Static({self.value!r})"

    def __eq__(self, other: object) -> bool:
        """Structural equality: two markers are equal iff their values are."""
        if isinstance(other, Static):
            return self.value == other.value
        return NotImplemented

    def __hash__(self) -> int:
        """Hash derived from the wrapped value."""
        return hash(("specflux.Static", self.value))


def is_static_scalar(x: object) -> bool:
    """Return ``True`` iff ``x`` is safe to embed directly into a graph-def.

    A value is a static scalar if it is hashable, immutable, and semantically
    stable across processes: ``None``, Python numerics, strings, bytes,
    :class:`Static` markers, or tuples/frozensets recursively composed of
    the same. Anything else (lists, dicts, arbitrary objects) fails the
    check and must either be wrapped in :class:`Static` or stored as a
    :class:`~specflux.Variable`/``Module`` child.
    """
    if x is None or isinstance(x, bool | int | float | complex | str | bytes):
        return True
    if isinstance(x, Static):
        return True
    if isinstance(x, tuple):
        return all(is_static_scalar(e) for e in x)
    if isinstance(x, frozenset):
        return all(is_static_scalar(e) for e in x)
    return False
