# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""":class:`State`: the collection-partitioned, path-keyed pytree of arrays.

Every :class:`~specflux.Variable` in a module graph stores its array in a
:class:`State`. The layout is two-level: the outer dict is keyed by
collection (``"params"``, ``"batch_stats"``, …), the inner dict is keyed
by the variable's canonical dotted path. :class:`State` is registered as
a JAX pytree so it passes transparently through
``jax.jit`` / ``grad`` / ``vmap`` / ``scan`` / ``remat``.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator, Mapping
from typing import Any

import jax

from ._typing import Array, Path
from .paths import path_to_str

__all__ = ["State"]

Leaf = Array | Any
"""A stored leaf. Typically an :class:`Array` but left wide for traced values."""


class State:
    """Collection-partitioned, path-keyed state container.

    Use ``state[collection][dotted_path]`` for direct access.
    :class:`State` is hashable-free (it wraps a mutable dict) but is
    immutable-by-convention at the public API layer: methods like
    :meth:`filter`, :meth:`merge`, :meth:`map`, and :meth:`set` return
    fresh :class:`State` instances.
    """

    __slots__ = ("_data",)

    _data: dict[str, dict[str, Leaf]]

    def __init__(self, data: Mapping[str, Mapping[str, Leaf]] | None = None) -> None:
        """Construct from an optional ``{collection: {path: leaf}}`` mapping."""
        if data is None:
            d: dict[str, dict[str, Leaf]] = {}
        else:
            d = {c: dict(v) for c, v in data.items()}
        object.__setattr__(self, "_data", d)

    @classmethod
    def _from_raw(cls, data: dict[str, dict[str, Leaf]]) -> State:
        """Fast-path constructor that adopts ``data`` without copying.

        Used by the pytree unflattener and other internal hot paths where
        ``data`` is already a freshly allocated nested dict — skipping
        the per-collection dict copy that ``__init__`` otherwise performs.
        """
        obj = cls.__new__(cls)
        object.__setattr__(obj, "_data", data)
        return obj

    def __getitem__(self, collection: str) -> dict[str, Leaf]:
        """Return the (mutable) inner dict for ``collection``, creating it
        on demand if absent so downstream code may index without guards.
        """
        return self._data.setdefault(collection, {})

    def __setitem__(self, collection: str, value: Mapping[str, Leaf]) -> None:
        """Replace the inner dict for ``collection``."""
        self._data[collection] = dict(value)

    def __contains__(self, collection: object) -> bool:
        """Return ``True`` iff ``collection`` is a non-empty collection name."""
        if not isinstance(collection, str):
            return False
        return collection in self._data and bool(self._data[collection])

    def __iter__(self) -> Iterator[str]:
        """Iterate over collection names."""
        return iter(self._data)

    def __len__(self) -> int:
        """Total number of leaves across all collections."""
        return sum(len(v) for v in self._data.values())

    def collections(self) -> set[str]:
        """Return the set of non-empty collection names."""
        return {c for c, v in self._data.items() if v}

    def raw(self) -> dict[str, dict[str, Leaf]]:
        """Return the backing nested-dict; do not mutate externally."""
        return self._data

    def items(self) -> Iterator[tuple[str, str, Leaf]]:
        """Yield ``(collection, path, leaf)`` tuples over every leaf."""
        for c, d in self._data.items():
            for p, v in d.items():
                yield c, p, v

    def paths(self, collection: str | None = None) -> list[tuple[str, str]]:
        """Return every ``(collection, path)`` pair, optionally filtered."""
        if collection is not None:
            return [(collection, p) for p in self._data.get(collection, {})]
        return [(c, p) for c, d in self._data.items() for p in d]

    def filter(self, *collections: str) -> State:
        """Return a new :class:`State` containing only the named collections."""
        return State({c: self._data[c] for c in collections if c in self._data})

    def exclude(self, *collections: str) -> State:
        """Return a new :class:`State` with the named collections removed."""
        return State({c: d for c, d in self._data.items() if c not in collections})

    def merge(self, other: State) -> State:
        """Return a new :class:`State` merging ``self`` with ``other``.

        Entries in ``other`` win on collision.
        """
        out: dict[str, dict[str, Leaf]] = {c: dict(d) for c, d in self._data.items()}
        for c, d in other._data.items():
            out.setdefault(c, {}).update(d)
        return State(out)

    def map(self, fn: Callable[[Leaf], Leaf], *collections: str) -> State:
        """Apply ``fn`` to every leaf, optionally restricted to some collections.

        Collections not touched are copied as-is into the result.
        """
        target: set[str] | None = set(collections) if collections else None
        out: dict[str, dict[str, Leaf]] = {}
        for c, d in self._data.items():
            if target is None or c in target:
                out[c] = {p: fn(v) for p, v in d.items()}
            else:
                out[c] = dict(d)
        return State(out)

    def set(self, collection: str, path: str | Path, value: Leaf) -> State:
        """Return a new :class:`State` with ``value`` set at ``(collection, path)``."""
        p = path_to_str(path) if isinstance(path, tuple) else path
        new: dict[str, dict[str, Leaf]] = {c: dict(d) for c, d in self._data.items()}
        new.setdefault(collection, {})[p] = value
        return State(new)

    def get(self, collection: str, path: str | Path, default: Any = None) -> Any:
        """Return the leaf at ``(collection, path)`` or ``default`` if missing."""
        p = path_to_str(path) if isinstance(path, tuple) else path
        return self._data.get(collection, {}).get(p, default)

    def flatten(self) -> dict[str, Leaf]:
        """Return a flat ``{'collection/path': leaf}`` dict."""
        out: dict[str, Leaf] = {}
        for c, d in self._data.items():
            for p, v in d.items():
                out[f"{c}/{p}"] = v
        return out

    @classmethod
    def from_flat(cls, flat: Mapping[str, Leaf]) -> State:
        """Construct a :class:`State` from the dict produced by :meth:`flatten`.

        Keys are split on the first ``/``.
        """
        out: dict[str, dict[str, Leaf]] = {}
        for key, v in flat.items():
            if "/" not in key:
                raise ValueError(f"from_flat key must be 'collection/path', got {key!r}")
            c, p = key.split("/", 1)
            out.setdefault(c, {})[p] = v
        return cls(out)

    def __repr__(self) -> str:
        """Compact summary: total leaf count and per-collection counts."""
        total = len(self)
        cols = ", ".join(f"{c}={len(d)}" for c, d in self._data.items())
        return f"State({total} leaves | {cols})"


_StateAux = tuple[tuple[str, tuple[str, ...]], ...]


def _state_flatten(s: State) -> tuple[tuple[Leaf, ...], _StateAux]:
    """Fast path-agnostic pytree flattener.

    Identical leaf order to :func:`_state_flatten_with_keys` but skips
    the per-leaf :class:`jax.tree_util.GetAttrKey` and f-string
    allocations. JAX prefers this variant when keypaths are not
    requested (the common case on the jit dispatch hot path).

    The single-collection case (the most common one — 99% of training
    states are just ``{"params": {...}}``) is specialized to skip the
    outer ``sorted()`` call entirely.
    """
    data = s._data
    if len(data) == 1:
        ((c, inner),) = data.items()
        paths = sorted(inner)
        return (
            tuple([inner[p] for p in paths]),
            ((c, tuple(paths)),),
        )

    leaves_list: list[Leaf] = []
    aux_list: list[tuple[str, tuple[str, ...]]] = []
    for c in sorted(data):
        inner = data[c]
        paths = sorted(inner)
        aux_list.append((c, tuple(paths)))
        for p in paths:
            leaves_list.append(inner[p])
    return tuple(leaves_list), tuple(aux_list)


def _state_flatten_with_keys(
    s: State,
) -> tuple[tuple[tuple[jax.tree_util.GetAttrKey, Leaf], ...], _StateAux]:
    """JAX pytree flattener for :class:`State` with per-leaf keypaths.

    Only invoked when keypaths are requested (error messages, debug
    paths). The fast path-agnostic variant :func:`_state_flatten` is
    preferred by JAX's dispatch machinery when keys are not needed.
    """
    keys: list[jax.tree_util.GetAttrKey] = []
    leaves: list[Leaf] = []
    aux_structure: list[tuple[str, tuple[str, ...]]] = []
    for c in sorted(s._data):
        paths = sorted(s._data[c])
        aux_structure.append((c, tuple(paths)))
        for p in paths:
            keys.append(jax.tree_util.GetAttrKey(f"{c}::{p}"))
            leaves.append(s._data[c][p])
    return tuple(zip(keys, leaves, strict=False)), tuple(aux_structure)


def _state_unflatten(aux: _StateAux, leaves: tuple[Leaf, ...]) -> State:
    """JAX pytree unflattener: rebuild a :class:`State` from ``(aux, leaves)``.

    Pairs each collection's path tuple (from ``aux``) with its slice of
    ``leaves`` via :func:`zip` and drops the result into a fresh
    :class:`State` through :meth:`State._from_raw`, bypassing the
    defensive dict copy that :meth:`State.__init__` otherwise performs.
    Called once per jit output and per state flowing through a
    transform, so the short-circuit matters when the state has hundreds
    of leaves (large models).

    Args:
        aux: The ``((collection, paths), ...)`` structure produced by
            :func:`_state_flatten_with_keys`.
        leaves: Flat tuple of leaf values in the order dictated by
            ``aux`` (same ordering used at flatten time).

    Returns:
        A :class:`State` whose layout exactly mirrors the original.
    """
    data: dict[str, dict[str, Leaf]] = {}
    i = 0
    for c, paths in aux:
        n = len(paths)
        data[c] = dict(zip(paths, leaves[i : i + n], strict=False))
        i += n
    return State._from_raw(data)


jax.tree_util.register_pytree_with_keys(
    State,
    _state_flatten_with_keys,
    _state_unflatten,
    flatten_func=_state_flatten,
)
