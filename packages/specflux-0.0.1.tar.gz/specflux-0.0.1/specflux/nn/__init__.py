# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Neural-network layers.

Every class here is a :class:`~specflux.Module` subclass. Containers
(:class:`~specflux.nn.Sequential`, :class:`~specflux.nn.ModuleList`,
:class:`~specflux.nn.ModuleDict`, :class:`~specflux.nn.ParameterList`)
re-export from :mod:`specflux.core.containers` for convenience.
"""

from ..core.containers import ModuleDict, ModuleList, ParameterList, Sequential
from .activation import GELU, ReLU, Sigmoid, SiLU, Tanh
from .attention import CausalSelfAttention, MultiheadAttention
from .conv import (
    Conv1d,
    Conv2d,
    Conv3d,
    ConvTranspose1d,
    ConvTranspose2d,
    ConvTranspose3d,
)
from .dense import DenseGeneral, Einsum
from .dropout import Dropout
from .embed import Embed
from .fp8 import Fp8DotGeneral, Fp8Einsum, Fp8Linear, Fp8Meta
from .identity import Identity
from .linear import Bilinear, Linear
from .lora import LoRA, LoRALinear, LoraParameter, wrap_lora
from .mlp import MLPBlock
from .norm import BatchNorm1d, BatchNorm2d, GroupNorm, InstanceNorm, LayerNorm, RMSNorm
from .pipeline_sequential import PipelineSequential
from .pool import (
    AdaptiveAvgPool1d,
    AdaptiveAvgPool2d,
    AdaptiveAvgPool3d,
    AvgPool1d,
    AvgPool2d,
    AvgPool3d,
    MaxPool1d,
    MaxPool2d,
    MaxPool3d,
)
from .recurrent import (
    RNN,
    Bidirectional,
    ConvLSTMCell,
    GRUCell,
    LSTMCell,
    OptimizedLSTMCell,
    RNNCellBase,
    SimpleRNNCell,
)

__all__ = [
    "GELU",
    "RNN",
    "AdaptiveAvgPool1d",
    "AdaptiveAvgPool2d",
    "AdaptiveAvgPool3d",
    "AvgPool1d",
    "AvgPool2d",
    "AvgPool3d",
    "BatchNorm1d",
    "BatchNorm2d",
    "Bidirectional",
    "Bilinear",
    "CausalSelfAttention",
    "Conv1d",
    "Conv2d",
    "Conv3d",
    "ConvLSTMCell",
    "ConvTranspose1d",
    "ConvTranspose2d",
    "ConvTranspose3d",
    "DenseGeneral",
    "Dropout",
    "Einsum",
    "Embed",
    "Fp8DotGeneral",
    "Fp8Einsum",
    "Fp8Linear",
    "Fp8Meta",
    "GRUCell",
    "GroupNorm",
    "Identity",
    "InstanceNorm",
    "LSTMCell",
    "LayerNorm",
    "Linear",
    "LoRA",
    "LoRALinear",
    "LoraParameter",
    "MLPBlock",
    "MaxPool1d",
    "MaxPool2d",
    "MaxPool3d",
    "ModuleDict",
    "ModuleList",
    "MultiheadAttention",
    "OptimizedLSTMCell",
    "ParameterList",
    "PipelineSequential",
    "RMSNorm",
    "RNNCellBase",
    "ReLU",
    "Sequential",
    "SiLU",
    "Sigmoid",
    "SimpleRNNCell",
    "Tanh",
    "wrap_lora",
]
