# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Activation layers.

Each class is a thin :class:`~specflux.Module` wrapper over the
corresponding function in :mod:`specflux.functional.activation`. Use
these when you want an activation as a drop-in layer (e.g. inside a
:class:`~specflux.nn.Sequential`); otherwise call the functional form
directly from your :meth:`forward`.
"""

from __future__ import annotations

from ..core._typing import Array, ArrayLike
from ..core.module import Module
from ..functional import activation as F


class ReLU(Module):
    """:math:`\\mathrm{ReLU}(x) = \\max(0, x)`."""

    def __init__(self) -> None:
        """No parameters."""
        super().__init__()

    def forward(self, x: ArrayLike, **_: object) -> Array:
        """Apply :func:`~specflux.functional.relu` to ``x``."""
        return F.relu(x)


class GELU(Module):
    """Gaussian error linear unit.

    Exact by default; set ``approximate=True`` for the tanh approximation.
    """

    def __init__(self, approximate: bool = False) -> None:
        """Record the ``approximate`` flag as a static field.

        Args:
            approximate: When ``True``, use the tanh-based approximation.
        """
        super().__init__()
        self.approximate = approximate

    def forward(self, x: ArrayLike, **_: object) -> Array:
        """Apply :func:`~specflux.functional.gelu` honoring :attr:`approximate`."""
        return F.gelu(x, approximate=self.approximate)


class SiLU(Module):
    """Sigmoid-weighted linear unit: ``x * sigmoid(x)``."""

    def __init__(self) -> None:
        """No parameters."""
        super().__init__()

    def forward(self, x: ArrayLike, **_: object) -> Array:
        """Apply :func:`~specflux.functional.silu` to ``x``."""
        return F.silu(x)


class Tanh(Module):
    """Hyperbolic tangent."""

    def __init__(self) -> None:
        """No parameters."""
        super().__init__()

    def forward(self, x: ArrayLike, **_: object) -> Array:
        """Apply :func:`~specflux.functional.tanh` to ``x``."""
        return F.tanh(x)


class Sigmoid(Module):
    """Logistic sigmoid."""

    def __init__(self) -> None:
        """No parameters."""
        super().__init__()

    def forward(self, x: ArrayLike, **_: object) -> Array:
        """Apply :func:`~specflux.functional.sigmoid` to ``x``."""
        return F.sigmoid(x)
