# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""":func:`display` — treescope-based rich rendering of a module."""

from __future__ import annotations

from ..core.module import Module
from .repr import repr_module

__all__ = ["display"]


def display(module: Module, *, roundtrip: bool = False) -> None:
    """Render ``module`` via treescope when available, else the text repr.

    In a notebook this produces interactive HTML with collapsible nodes;
    on a plain TTY it prints the :func:`~specflux.inspect.repr.repr_module`
    text. Returns ``None``.
    """
    try:
        import treescope

        treescope.display(module)
    except Exception:
        print(repr_module(module))
    _ = roundtrip
