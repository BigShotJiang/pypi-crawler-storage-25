# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Rich tabular summary of a module, including per-submodule param/byte counts."""

from __future__ import annotations

from typing import Any

import jax
import jax.numpy as jnp

from ..core.graph import iter_modules, live_variables
from ..core.module import Module
from ..core.variable import Variable

__all__ = ["count_bytes", "count_params", "hlo_cost", "tabulate"]


def _var_size(v: Variable) -> tuple[int, int]:
    """Return ``(element_count, bytes)`` for a variable."""
    shape = getattr(v, "shape", ())
    n = 1
    for s in shape:
        try:
            n *= int(s)
        except Exception:
            n = 0
            break
    dtype = getattr(v, "dtype", None)
    try:
        itemsize = jnp.dtype(dtype).itemsize if dtype is not None else 4
    except Exception:
        itemsize = 4
    return n, n * itemsize


def count_params(module: Module, *, collection: str = "params") -> int:
    """Return the total number of scalar values across a collection."""
    total = 0
    for _, v in live_variables(module):
        if v.kind == collection:
            n, _ = _var_size(v)
            total += n
    return total


def count_bytes(module: Module, *, collection: str = "params") -> int:
    """Return the total byte count across a collection."""
    total = 0
    for _, v in live_variables(module):
        if v.kind == collection:
            _, b = _var_size(v)
            total += b
    return total


def tabulate(
    module: Module,
    *example_args: Any,
    depth: int | None = None,
    **example_kwargs: Any,
) -> str:
    """Return a PyTorch-style tabulated per-submodule report.

    Columns are ``(path, class, params, bytes)``. When example inputs
    are supplied the output shape is reported after running
    :func:`jax.eval_shape` on the module.
    """
    rows: list[tuple[str, str, str, str]] = []
    for path, mod in iter_modules(module):
        if depth is not None and path.count(".") + (1 if path else 0) > depth:
            continue
        params_here = 0
        bytes_here = 0
        prefix = path + ("." if path else "")
        for p, v in live_variables(mod):
            n, b = _var_size(v)
            if v.kind == "params":
                params_here += n
                bytes_here += b
            _ = p
            _ = prefix
        cls = type(mod).__name__
        rows.append((path or "(root)", cls, f"{params_here:,}", f"{bytes_here:,}"))

    w0 = max((len(r[0]) for r in rows), default=4)
    w1 = max((len(r[1]) for r in rows), default=5)
    w2 = max((len(r[2]) for r in rows), default=6)
    w3 = max((len(r[3]) for r in rows), default=5)
    header = f"{'path':<{w0}}  {'class':<{w1}}  {'params':>{w2}}  {'bytes':>{w3}}"
    lines: list[str] = [header, "-" * len(header)]
    for r in rows:
        lines.append(f"{r[0]:<{w0}}  {r[1]:<{w1}}  {r[2]:>{w2}}  {r[3]:>{w3}}")
    lines.append("-" * len(header))
    total_params = count_params(module)
    total_bytes = count_bytes(module)
    lines.append(f"Total params: {total_params:,}  bytes: {total_bytes:,}")
    if example_args or example_kwargs:
        try:
            out = jax.eval_shape(lambda: module(*example_args, **example_kwargs))
            lines.append(f"Output: {out}")
        except Exception as e:
            lines.append(f"Output: (eval_shape failed: {e})")
    return "\n".join(lines)


def hlo_cost(module: Module, *example_args: Any, **example_kwargs: Any) -> dict[str, float]:
    """Return a dict with ``flops`` and ``bytes_accessed`` derived from XLA's cost model.

    Uses ``jax.jit(...).lower(...).compile().cost_analysis()`` on a pure
    wrapping of ``module(*example_args, **example_kwargs)``. Failing
    compile returns ``{}``.
    """
    try:

        def run(*args: Any, **kwargs: Any) -> Any:
            return module(*args, **kwargs)

        lowered = jax.jit(run).lower(*example_args, **example_kwargs)
        compiled = lowered.compile()
        analysis = compiled.cost_analysis()
        if analysis is None:
            return {}
        if isinstance(analysis, list):
            analysis = analysis[0] if analysis else {}
        return {
            "flops": float(analysis.get("flops", 0.0)),
            "bytes_accessed": float(analysis.get("bytes accessed", analysis.get("bytes_accessed", 0.0))),
        }
    except Exception:
        return {}
