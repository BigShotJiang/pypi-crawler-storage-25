# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Structural inspection helpers."""

from __future__ import annotations

from typing import Any

from ..core.graph import export
from ..core.graph import tree_state as _tree_state
from ..core.module import Module
from ..core.state import State

__all__ = ["paths_and_shapes", "tree_state"]


def tree_state(module: Module) -> State:
    """Return the :class:`~specflux.State` half of :func:`specflux.export`.

    Convenience wrapper for users who only want the state tree.
    """
    return _tree_state(module)


def paths_and_shapes(module: Module) -> list[tuple[str, str, tuple[int, ...], Any]]:
    """List every leaf in ``module`` as ``(collection, path, shape, dtype)``.

    Sorted by ``(collection, path)`` for stable diagnostic output.
    """
    _gdef, state = export(module)
    out: list[tuple[str, str, tuple[int, ...], Any]] = []
    for c, p, v in state.items():
        shape = tuple(getattr(v, "shape", ()))
        dtype = getattr(v, "dtype", None)
        out.append((c, p, shape, dtype))
    return sorted(out, key=lambda r: (r[0], r[1]))
