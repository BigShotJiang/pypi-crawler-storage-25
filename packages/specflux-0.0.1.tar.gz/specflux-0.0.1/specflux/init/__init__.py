# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Pure initializer factories.

Each public function here returns a callable implementing the
:class:`~specflux.typing.Initializer` protocol —
``(key, shape, dtype) -> Array`` — suitable for direct use when
constructing a :class:`~specflux.Parameter`.
"""

from .constant import constant, ones, zeros
from .kaiming import kaiming_normal, kaiming_uniform
from .normal import normal, truncated_normal
from .orthogonal import orthogonal
from .uniform import uniform
from .xavier import xavier_normal, xavier_uniform

__all__ = [
    "constant",
    "kaiming_normal",
    "kaiming_uniform",
    "normal",
    "ones",
    "orthogonal",
    "truncated_normal",
    "uniform",
    "xavier_normal",
    "xavier_uniform",
    "zeros",
]
