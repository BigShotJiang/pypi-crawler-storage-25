# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Orthogonal initializer obtained via a QR decomposition of random noise."""

from __future__ import annotations

import jax
import jax.numpy as jnp

from ..core._typing import Array, DType, Initializer, PRNGKey, Shape


def orthogonal(gain: float = 1.0) -> Initializer:
    """Orthogonal initializer.

    For 2-D-or-higher shapes this computes a QR decomposition of a
    Gaussian matrix, corrects the signs of the diagonal of ``R``, and
    reshapes the orthonormal matrix back to ``shape``. For ranks below
    2 it falls back to scaled Gaussian noise.

    Args:
        gain: Scalar multiplier applied to the orthonormal matrix.
    """

    def init(key: PRNGKey, shape: Shape, dtype: DType = jnp.float32) -> Array:
        """Materialize an orthogonal weight of ``shape``."""
        if len(shape) < 2:
            return jax.random.normal(key, shape, dtype=dtype) * gain
        flat: tuple[int, int] = (shape[0], int(jnp.prod(jnp.array(shape[1:]))))
        a = jax.random.normal(key, flat, dtype=dtype)
        q, r = jnp.linalg.qr(a if flat[0] >= flat[1] else a.T)
        d = jnp.sign(jnp.diag(r))
        q = q * d
        if flat[0] < flat[1]:
            q = q.T
        return gain * q.reshape(shape)

    return init
