# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Derive JAX :class:`PartitionSpec` / :class:`NamedSharding` trees from modules."""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

import jax
from jax.sharding import NamedSharding, PartitionSpec

from ..core._typing import Array, ArrayLike, Initializer
from ..core.graph import export
from ..core.module import Module
from ..core.selector import select
from ..core.sharding import AxisNames, Sharding, normalize_sharding
from ..core.stage_assignment import metadata_stage_assignment, resolve_stage_rank
from ..core.variable import Variable
from .logical import current_axis_rules
from .mesh import SpxMesh

if TYPE_CHECKING:
    from jax.sharding import Mesh

    from ..runtime.types.mesh import MpMdMesh

__all__ = [
    "get_named_sharding",
    "get_partition_spec",
    "named_sharding_for_metadata",
    "named_sharding_for_variable",
    "with_partitioning",
    "with_sharding_constraint_by_name",
]


def with_partitioning(
    init: Initializer,
    axis_names: AxisNames | Sharding,
) -> Callable[..., Array]:
    """Wrap an initializer so its output carries ``axis_names`` metadata.

    The returned callable has the same ``(key, shape, dtype)`` signature
    as the wrapped initializer but additionally returns arrays whose
    sharding metadata has been pre-stamped via the companion
    ``_spx_axis_names`` attribute (consumed by constructors that don't
    take a ``sharding=`` keyword but still want to record it).

    In practice the cleanest use is::

        w_init = with_partitioning(normal(0.02), ("embed", "features"))
    """
    sharding = normalize_sharding(axis_names)

    def wrapped(key: Any, shape: tuple[int, ...], dtype: Any) -> Array:
        """Run the wrapped initializer and stamp its output with sharding metadata."""
        arr = init(key, shape, dtype)
        try:
            object.__setattr__(arr, "_spx_sharding", sharding)
        except (AttributeError, TypeError):
            pass
        return arr

    wrapped._spx_sharding = sharding
    return wrapped


def _iter_variables(module: Module):
    """Yield ``(path, var)`` for every variable in ``module`` in graph order."""
    yield from select().apply(module)


def get_partition_spec(module: Module) -> dict[str, dict[str, PartitionSpec | None]]:
    """Return ``{collection: {path: PartitionSpec}}`` derived from axis_names.

    Any variable without ``axis_names`` metadata maps to a fully
    replicated :class:`PartitionSpec`. Resolution honors the
    currently-active :func:`~specflux.sharding.logical_axis_rules`.
    """
    rules = current_axis_rules()
    gdef, _state = export(module)
    _ = gdef
    out: dict[str, dict[str, PartitionSpec | None]] = {}
    for p, v in _iter_variables(module):
        col = v.kind
        sharding: Sharding | None = v.metadata.get("sharding")
        if sharding is None:
            names = v.metadata.get("axis_names")
            sharding = Sharding(axis_names=tuple(names)) if names is not None else Sharding()
        spec = sharding.to_partition_spec(rules or None)
        out.setdefault(col, {})[p] = spec
    return out


def _resolve_named_sharding_mesh(mesh: "Mesh | SpxMesh | MpMdMesh") -> tuple["Mesh", "MpMdMesh | None"]:
    """Return ``(base_mesh, mpmd_mesh_or_none)`` for sharding resolution."""
    from ..runtime.types.mesh import MpMdMesh

    if isinstance(mesh, SpxMesh):
        return mesh.jax_mesh, mesh.mpmd_mesh
    if isinstance(mesh, MpMdMesh):
        return mesh.jax_mesh, mesh
    return mesh, None


def named_sharding_for_metadata(metadata: dict[str, Any], mesh: "Mesh | SpxMesh | MpMdMesh") -> NamedSharding | None:
    """Resolve raw variable-style metadata to a ``NamedSharding``."""
    rules = current_axis_rules()
    sharding = normalize_sharding(metadata.get("sharding"))
    if sharding is None:
        names = metadata.get("axis_names")
        sharding = Sharding(axis_names=tuple(names)) if names is not None else None
    if sharding is None:
        return None

    spec = sharding.to_partition_spec(rules or None)
    base_mesh, mpmd_mesh = _resolve_named_sharding_mesh(mesh)
    if mpmd_mesh is not None:
        owner = resolve_stage_rank(metadata_stage_assignment(metadata), mpmd_mesh.mpmd_dim)
        if owner is not None:
            return mpmd_mesh.sub_sharding(owner, spec)
    return NamedSharding(base_mesh, spec)


def named_sharding_for_variable(var: Variable, mesh: "Mesh | SpxMesh | MpMdMesh") -> NamedSharding:
    """Resolve one variable's metadata to a ``NamedSharding``.

    Stage-tagged variables on an MPMD mesh resolve against their owning
    stage sub-mesh. Untagged variables resolve against the full mesh,
    which means they replicate across the pipeline axis unless their
    spec explicitly names it.
    """
    resolved = named_sharding_for_metadata(var.metadata, mesh)
    if resolved is not None:
        return resolved

    base_mesh, _ = _resolve_named_sharding_mesh(mesh)
    return NamedSharding(base_mesh, Sharding().to_partition_spec(current_axis_rules() or None))


def get_named_sharding(module: Module, mesh: "Mesh | SpxMesh | MpMdMesh") -> dict[str, dict[str, NamedSharding]]:
    """Wrap each variable's resolved spec in a ``NamedSharding``.

    Accepts a plain JAX mesh, an :class:`~specflux.sharding.SpxMesh`,
    or an :class:`~specflux.pipeline.MpMdMesh`. When the mesh is MPMD
    and a variable carries a stage hint, the returned sharding is
    stage-local automatically.
    """
    out: dict[str, dict[str, NamedSharding]] = {}
    for path, var in _iter_variables(module):
        out.setdefault(var.kind, {})[path] = named_sharding_for_variable(var, mesh)
    return out


def with_sharding_constraint_by_name(x: ArrayLike, axis_names: AxisNames) -> Array:
    """Apply a sharding constraint using the active logical -> mesh rules.

    Inside an active :func:`logical_axis_rules` context the logical names
    are resolved to physical mesh axes; outside one the constraint is a
    no-op replicate.
    """

    rules = current_axis_rules()
    resolved = tuple(rules.get(n) if n is not None else None for n in axis_names)
    spec = PartitionSpec(*resolved)
    return jax.lax.with_sharding_constraint(x, spec)


_ = Variable
