# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""JAX mesh creation helpers for SPMD training.

Wraps :func:`jax.experimental.mesh_utils.create_device_mesh` and
:func:`jax.experimental.mesh_utils.create_hybrid_device_mesh` with
sensible defaults for the common data / FSDP / tensor / sequence /
expert parallelism axis set, plus three conveniences:

* :func:`create_mesh` — the main entry point. Automatically detects
  multi-slice TPU pod setups and multi-process distributed runs, and
  picks the right mesh-creation path.
* :func:`parse_mesh_from_string` — parse a human-readable config like
  ``"dp:2,tp:4"`` or the positional form ``"2,4"``.
* :func:`cpu_context` — one-shot context manager giving you a CPU
  mesh with JAX pinned to CPU; handy for local debug / unit tests.

Derived from NVIDIA-era patterns in `eformer.escale.mesh
<https://github.com/erfanzar/eformer/tree/main/eformer/escale/mesh>`_;
ported with minor adaptations (stdlib ``contextlib``, specflux-style
docstrings, type hints).
"""

from __future__ import annotations

import contextlib
import functools
import os
import threading
from collections.abc import Iterator, Sequence
from dataclasses import dataclass, field
from typing import Any, Literal

import jax
import numpy as np
from jax.experimental.mesh_utils import create_device_mesh, create_hybrid_device_mesh
from jax.sharding import AxisType, Mesh

__all__ = [
    "DEFAULT_MESH_AXIS_DIMS",
    "DEFAULT_MESH_AXIS_NAMES",
    "SpxMesh",
    "calculate_host_mesh_shape",
    "cpu_context",
    "create_cpu_mesh",
    "create_mesh",
    "force_cpu",
    "parse_mesh_from_string",
]


_CURRENT_MESH: threading.local = threading.local()


def current_mesh() -> SpxMesh | None:
    """Return the innermost active :class:`SpxMesh`, if any."""
    stack = getattr(_CURRENT_MESH, "stack", ())
    return stack[-1] if stack else None


@dataclass(frozen=True)
class SpxMesh:
    """Unified specflux mesh — a :class:`~jax.sharding.Mesh` plus optional
    MPMD axis tagging.

    Every specflux API takes :class:`SpxMesh` as ``mesh=...``. Pure-SPMD
    setups create one with ``mpmd_axis=None`` and behave like a plain
    JAX ``Mesh`` (use ``mesh.jax_mesh`` to drop into JAX). When
    ``mpmd_axis`` is set, ``mesh.mpmd_mesh`` exposes the
    :class:`~specflux.pipeline.MpMdMesh` view that pipeline runtimes
    consume.

    Attributes:
        jax_mesh: The underlying :class:`~jax.sharding.Mesh`.
        mpmd_axis: Optional axis name reserved for MPMD pipeline
            stages. ``None`` for pure-SPMD setups.

    Properties:
        ``mpmd_mesh`` : :class:`~specflux.pipeline.MpMdMesh` | ``None`` —
            built lazily; ``None`` iff ``mpmd_axis is None``.
        ``is_mpmd`` : bool — convenience for ``mpmd_axis is not None``.
        ``axis_names`` / ``shape`` / ``devices`` — forward to the
            underlying ``jax_mesh`` for ergonomic access.
    """

    jax_mesh: Mesh
    mpmd_axis: str | None = None
    _mpmd_mesh_cache: dict = field(default_factory=dict, repr=False, compare=False)

    def __post_init__(self) -> None:
        """Validate that ``mpmd_axis`` (if set) names an axis of ``jax_mesh``."""
        if self.mpmd_axis is not None and self.mpmd_axis not in self.jax_mesh.axis_names:
            raise ValueError(f"mpmd_axis {self.mpmd_axis!r} not in jax_mesh.axis_names {self.jax_mesh.axis_names}.")

    @property
    def is_mpmd(self) -> bool:
        """``True`` iff ``mpmd_axis`` is set (i.e. pipeline parallelism enabled)."""
        return self.mpmd_axis is not None

    @property
    def mpmd_mesh(self):
        """Lazy :class:`~specflux.pipeline.MpMdMesh` view.

        Returns ``None`` when ``mpmd_axis`` is unset. Construction is
        deferred (and cached) to avoid a circular import between
        ``specflux.sharding`` and ``specflux.pipeline``.
        """
        if self.mpmd_axis is None:
            return None
        if "mm" not in self._mpmd_mesh_cache:
            from ..runtime.types.mesh import MpMdMesh

            self._mpmd_mesh_cache["mm"] = MpMdMesh(self.jax_mesh, self.mpmd_axis)
        return self._mpmd_mesh_cache["mm"]

    @property
    def axis_names(self) -> tuple[str, ...]:
        """Axis names of the underlying ``jax_mesh``."""
        return self.jax_mesh.axis_names

    @property
    def shape(self):
        """Shape of the underlying ``jax_mesh``."""
        return self.jax_mesh.shape

    @property
    def devices(self):
        """Device grid of the underlying ``jax_mesh``."""
        return self.jax_mesh.devices

    def __enter__(self):
        """Enter the underlying ``jax_mesh`` context."""
        entered = self.jax_mesh.__enter__()
        stack = list(getattr(_CURRENT_MESH, "stack", ()))
        stack.append(self)
        _CURRENT_MESH.stack = tuple(stack)
        return entered

    def __exit__(self, *args):
        """Exit the underlying ``jax_mesh`` context."""
        stack = list(getattr(_CURRENT_MESH, "stack", ()))
        for idx in range(len(stack) - 1, -1, -1):
            if stack[idx] is self:
                del stack[idx]
                break
        _CURRENT_MESH.stack = tuple(stack)
        return self.jax_mesh.__exit__(*args)

    def __getattr__(self, name: str):
        """Forward unknown attributes to the underlying :class:`jax.sharding.Mesh`.

        Makes :class:`SpxMesh` a near-drop-in for plain ``Mesh`` in
        user code. Dunder names skip this path (they're looked up on
        the type, not the instance, so ``__getattr__`` isn't invoked).
        """
        try:
            return getattr(self.jax_mesh, name)
        except AttributeError:
            raise AttributeError(
                f"{type(self).__name__!r} has no attribute {name!r} (forwarded lookup on jax_mesh also failed)."
            ) from None


DEFAULT_MESH_AXIS_DIMS: tuple[int, ...] = (1, 1, -1, 1, 1, 1)
"""Default per-axis dimension sizes for :func:`create_mesh`.

Matches the ``(pp, dp, fsdp, ep, tp, sp)`` convention: FSDP absorbs
all remaining devices by default (``-1`` means "fill with what's
left"), everything else replicated.
"""


DEFAULT_MESH_AXIS_NAMES: tuple[str, ...] = ("pp", "dp", "fsdp", "ep", "tp", "sp")
"""Default axis names for :func:`create_mesh`.

- ``pp``: pipeline parallelism (split model by stages — see
  :mod:`specflux.pipeline`)
- ``dp``: data parallelism (replicate model, split batch)
- ``fsdp``: fully-sharded data parallelism (ZeRO-3-like)
- ``ep``: expert parallelism (mixture-of-experts)
- ``tp``: tensor parallelism (split model-width dims)
- ``sp``: sequence parallelism (split sequence dim)
"""


_AXIS_TYPE_BY_NAME: dict[str, AxisType] = {
    "auto": AxisType.Auto,
    "explicit": AxisType.Explicit,
    "manual": AxisType.Manual,
}


_SPX_MESH_CACHE: dict[tuple[int, str | None], SpxMesh] = {}


def _get_num_slices(devices: Sequence[Any]) -> int:
    """Count the distinct TPU pod slices across ``devices``.

    Inspects each device for a ``slice_index`` attribute (exposed on
    multi-slice TPU pod runtimes). Falls back to the
    ``MEGASCALE_NUM_SLICES`` environment variable when device objects
    don't carry the attribute.
    """
    num_slices = 1
    if devices and hasattr(devices[0], "slice_index"):
        try:
            num_slices = len({d.slice_index for d in devices})
        except Exception:
            pass
    if num_slices == 1:
        num_slices = int(os.environ.get("MEGASCALE_NUM_SLICES", num_slices))
    return num_slices


def _normalize_axis_types(
    axis_names: Sequence[str],
    axis_types: Sequence[AxisType | str] | AxisType | str | None,
) -> tuple[AxisType, ...] | None:
    """Coerce an ``axis_types`` argument into a ``(AxisType, ...)`` tuple.

    Accepts either a single value (applied to every axis), a sequence
    parallel to ``axis_names``, or ``None``.

    Args:
        axis_names: Axis names; fixes the output tuple length.
        axis_types: ``AxisType`` values, their string names
            (``"auto"`` / ``"explicit"`` / ``"manual"``), or ``None``.

    Returns:
        A tuple of ``AxisType`` of length ``len(axis_names)``, or
        ``None`` if ``axis_types`` was ``None``.

    Raises:
        ValueError: On unknown string names or length mismatches.
        TypeError: On unsupported entry types.
    """
    if axis_types is None:
        return None
    if isinstance(axis_types, (AxisType, str)):
        axis_types_seq: Sequence[AxisType | str] = (axis_types,) * len(axis_names)
    else:
        axis_types_seq = tuple(axis_types)
        if len(axis_types_seq) == 1 and len(axis_names) > 1:
            axis_types_seq = axis_types_seq * len(axis_names)
    normalized: list[AxisType] = []
    for at in axis_types_seq:
        if isinstance(at, str):
            key = at.strip().lower()
            if key not in _AXIS_TYPE_BY_NAME:
                raise ValueError(
                    f"axis_types entries must be one of {{'auto', 'explicit', 'manual'}} or AxisType; got {at!r}."
                )
            normalized.append(_AXIS_TYPE_BY_NAME[key])
        elif isinstance(at, AxisType):
            normalized.append(at)
        else:
            raise TypeError(f"axis_types entries must be strings or AxisType values, got {type(at).__name__}.")
    if len(normalized) != len(axis_names):
        raise ValueError(f"axis_types length ({len(normalized)}) must match axis_names length ({len(axis_names)}).")
    return tuple(normalized)


def calculate_host_mesh_shape(
    global_mesh_shape: Sequence[int],
    total_devices: int | None = None,
    num_processes: int | None = None,
) -> tuple[int, ...]:
    """Compute the per-host mesh shape for a multi-process global mesh.

    Given the desired global mesh, decide how each host slices off
    its share. Greedy packing: consume ``num_processes`` copies off
    the leading axis that can supply them; move to the next axis when
    the current one runs out.

    Args:
        global_mesh_shape: Desired global mesh dimensions across all
            processes.
        total_devices: Devices on this host. Default:
            ``jax.local_device_count()``.
        num_processes: Total processes. Default: ``jax.process_count()``.

    Returns:
        Per-host mesh shape (same rank as ``global_mesh_shape``).

    Raises:
        ValueError: If the global mesh size doesn't match
            ``total_devices * num_processes`` or the packing can't
            produce a shape with exactly ``total_devices`` entries.

    Example:
        >>> calculate_host_mesh_shape((2, 4), total_devices=4, num_processes=2)
        (1, 4)
    """
    total_devices = total_devices or jax.local_device_count()
    num_processes = num_processes or jax.process_count()
    total_mesh_size = int(np.prod(global_mesh_shape))
    if total_mesh_size != total_devices * num_processes:
        raise ValueError(
            f"Mesh size {total_mesh_size} doesn't match available devices "
            f"{total_devices * num_processes} (local x processes)."
        )
    host_mesh = list(global_mesh_shape)
    remaining_process_split = num_processes
    idx = 0
    while remaining_process_split > 1 and idx < len(host_mesh):
        dim_size = host_mesh[idx]
        if dim_size >= remaining_process_split:
            factor = remaining_process_split
            host_mesh[idx] = dim_size // factor
            remaining_process_split = 1
        else:
            factor = dim_size
            host_mesh[idx] = 1
            remaining_process_split //= factor
        idx += 1
    host_total = int(np.prod(host_mesh))
    if host_total != total_devices:
        raise ValueError(
            f"Host mesh shape {tuple(host_mesh)} uses {host_total} devices "
            f"instead of {total_devices}. Ensure ``num_processes`` factors "
            f"the global mesh shape."
        )
    return tuple(host_mesh)


def _cached_mesh(
    axis_dims: Sequence[int],
    axis_names: Sequence[str],
    axis_types: Sequence[AxisType] | None,
    dcn_mesh_dims: Sequence[int] | None,
    should_sort_granules_by_key: bool,
    allow_split_physical_axes: bool,
    backend: str | None,
) -> Mesh:
    """Hashable-args wrapper around :func:`_cached_mesh_impl`."""
    return _cached_mesh_impl(
        axis_dims=tuple(axis_dims),
        axis_names=tuple(axis_names),
        axis_types=None if axis_types is None else tuple(axis_types),
        dcn_mesh_dims=None if dcn_mesh_dims is None else tuple(dcn_mesh_dims),
        should_sort_granules_by_key=should_sort_granules_by_key,
        allow_split_physical_axes=allow_split_physical_axes,
        backend=backend or jax.default_backend(),
    )


@functools.cache
def _cached_mesh_impl(
    axis_dims: tuple[int, ...],
    axis_names: tuple[str, ...],
    axis_types: tuple[AxisType, ...] | None,
    dcn_mesh_dims: tuple[int, ...] | None,
    should_sort_granules_by_key: bool,
    allow_split_physical_axes: bool,
    backend: str,
) -> Mesh:
    """Cached mesh-creation implementation.

    Three branches:

    1. **Multi-slice TPU pods** — one mesh axis is divided across the
       slices, the rest replicated via ``create_hybrid_device_mesh``
       with ``process_is_granule=False``.
    2. **Multi-process (non-TPU) setups** — per-host submesh via
       :func:`calculate_host_mesh_shape` + ``create_hybrid_device_mesh``
       with ``process_is_granule=True``.
    3. **Single-process** — ordinary :func:`create_device_mesh`.
    """
    devices = jax.devices(backend)
    total_devices = jax.device_count(backend)
    local_devices = jax.local_device_count(backend)
    process_count = jax.process_count()
    global_mesh_shape = np.arange(total_devices).reshape(axis_dims).shape

    num_slices = _get_num_slices(devices)

    def fill_minus_one(shape: tuple[int, ...], target: int) -> tuple[int, ...]:
        """Replace a single ``-1`` entry with the value needed to reach ``target`` product."""
        shp = list(shape)
        minus = [i for i, v in enumerate(shp) if v == -1]
        if len(minus) > 1:
            raise ValueError("Only one -1 is supported in dcn_mesh_dims.")
        prod_known = 1
        for v in shp:
            if v != -1:
                if v <= 0:
                    raise ValueError(f"dcn_mesh_dims entries must be > 0 or -1, got {v}.")
                prod_known *= v
        if minus:
            if target % prod_known != 0:
                raise ValueError(f"dcn_mesh_dims product ({prod_known}) does not divide target ({target}).")
            shp[minus[0]] = target // prod_known
        if np.prod(shp) != target:
            raise ValueError(f"dcn_mesh_dims product {int(np.prod(shp))} must equal {target}; got {tuple(shp)}.")
        return tuple(int(v) for v in shp)

    if num_slices > 1:
        dynamic_axis = next(
            (i for i, dim in enumerate(global_mesh_shape) if dim % num_slices == 0),
            None,
        )

        if dynamic_axis is None:
            raise ValueError(
                f"Multi-slice detected (num_slices={num_slices}) but no mesh "
                f"axis in {global_mesh_shape} is divisible by num_slices."
            )
        per_slice_mesh_shape = list(global_mesh_shape)
        per_slice_mesh_shape[dynamic_axis] //= num_slices
        per_slice_tuple = tuple(per_slice_mesh_shape)
        if dcn_mesh_dims is None:
            dcn_list = [1] * len(axis_dims)
            dcn_list[dynamic_axis] = num_slices
            dcn: tuple[int, ...] = tuple(dcn_list)
        else:
            dcn = fill_minus_one(dcn_mesh_dims, num_slices)
        ndarray = create_hybrid_device_mesh(
            mesh_shape=per_slice_tuple,
            dcn_mesh_shape=dcn,
            devices=devices,
            allow_split_physical_axes=allow_split_physical_axes,
            process_is_granule=False,
            should_sort_granules_by_key=should_sort_granules_by_key,
        )
    elif process_count > 1:
        local_mesh_shape = calculate_host_mesh_shape(
            global_mesh_shape=global_mesh_shape,
            total_devices=local_devices,
            num_processes=process_count,
        )
        if dcn_mesh_dims is None:
            ratios = [int(g // le) for g, le in zip(global_mesh_shape, local_mesh_shape, strict=False)]
            if np.prod(ratios) != process_count:
                ratios = [1] * len(axis_dims)
                for i in range(len(axis_dims)):
                    ratios[i] = process_count
                    break
            dcn = tuple(ratios)
        else:
            dcn = fill_minus_one(dcn_mesh_dims, process_count)
        ndarray = create_hybrid_device_mesh(
            mesh_shape=local_mesh_shape,
            dcn_mesh_shape=dcn,
            devices=devices,
            allow_split_physical_axes=allow_split_physical_axes,
            process_is_granule=True,
            should_sort_granules_by_key=should_sort_granules_by_key,
        )
    else:
        ndarray = create_device_mesh(
            mesh_shape=global_mesh_shape,
            devices=devices,
            allow_split_physical_axes=allow_split_physical_axes,
        )

    return Mesh(ndarray, axis_names, axis_types=axis_types)


def create_mesh(
    axis_dims: Sequence[int] = DEFAULT_MESH_AXIS_DIMS,
    axis_names: Sequence[str] = DEFAULT_MESH_AXIS_NAMES,
    *,
    mpmd_axis: str | None = None,
    dcn_mesh_dims: Sequence[int] | None = None,
    should_sort_granules_by_key: bool = True,
    allow_split_physical_axes: bool = True,
    backend: str | None = None,
    use_jax: bool = False,
    axis_types: Sequence[AxisType | str] | AxisType | str | Literal["auto", "explicit", "manual"] | None = None,
) -> SpxMesh:
    """Create a JAX :class:`~jax.sharding.Mesh` for distributed training.

    Single-line drop-in for most specflux SPMD / FSDP / TP / PP setups.
    The default axis names ``(dp, fsdp, ep, tp, sp)`` match what
    :mod:`specflux.sharding.partition` and :mod:`specflux.pipeline`
    expect; passing ``axis_dims=(1, -1, 1, 1, 1)`` packs every device
    into the FSDP axis — the canonical "distribute everything" setup.

    The function auto-detects:

    * **Multi-slice TPU pods** — via device ``slice_index`` or
      ``MEGASCALE_NUM_SLICES`` env. Splits one mesh axis across
      slices and sets up the DCN (data-center-network) mapping.
    * **Multi-process (non-TPU)** — via ``jax.process_count()``.
      Derives a per-host submesh via
      :func:`calculate_host_mesh_shape`.
    * **Single-process** — plain :func:`create_device_mesh`.

    Results are cached by argument tuple — calling
    ``create_mesh(same_args)`` twice returns the same
    :class:`~jax.sharding.Mesh` object.

    Args:
        axis_dims: Dimensions for each mesh axis. One entry may be
            ``-1`` meaning "use all remaining devices". Must multiply
            to the total device count.
        axis_names: Names for each axis. Length must match
            ``axis_dims``.
        mpmd_axis: Optional axis name to tag as MPMD (pipeline-parallel).
            When set, the returned :class:`SpxMesh`'s ``mpmd_mesh``
            attribute is the :class:`~specflux.pipeline.MpMdMesh` view
            consumed by pipeline runtimes (``sxcall`` / ``sxjit``).
            ``None`` (default) -> pure-SPMD mesh.
        dcn_mesh_dims: Explicit DCN (inter-slice / inter-host) mesh
            dimensions. ``None`` means "auto-calculate"; one ``-1``
            is allowed to fill remaining.
        should_sort_granules_by_key: Whether to sort granules (hosts
            / slices) for consistent device ordering across processes.
        allow_split_physical_axes: Allow physical device axes to be
            split across logical mesh axes (needed for most exotic
            topologies).
        backend: JAX backend. ``None`` -> :func:`jax.default_backend`.
        use_jax: If ``True``, use :func:`jax.make_mesh` for
            single-process / single-slice setups (drops the
            explicit-mesh-utils path). Multi-slice and multi-process
            topologies always use mesh_utils.
        axis_types: Optional per-axis :class:`AxisType` — either
            ``"auto"`` / ``"explicit"`` / ``"manual"`` (string), an
            ``AxisType`` enum, or a sequence per-axis. Default
            ``None`` = JAX default.

    Returns:
        A :class:`~jax.sharding.Mesh` ready for pjit / shard_map /
        :mod:`specflux.sharding` helpers.

    Example:
        >>> import specflux as spx
        >>> mesh = spx.sharding.create_mesh(
        ...     axis_dims=(2, 4),
        ...     axis_names=("data", "model"),
        ... )
        >>> with mesh:
        ...     ...
    """
    if mpmd_axis is not None and mpmd_axis not in axis_names:
        raise ValueError(f"mpmd_axis {mpmd_axis!r} not in axis_names {tuple(axis_names)}.")

    axis_types_norm = _normalize_axis_types(axis_names, axis_types)
    if use_jax:
        devices = jax.devices(backend)
        num_slices = _get_num_slices(devices)
        process_count = jax.process_count()
        if num_slices == 1 and process_count == 1 and dcn_mesh_dims is None:
            total_devices = len(devices)
            axis_dims = np.arange(total_devices).reshape(axis_dims).shape
            jm = jax.make_mesh(
                axis_shapes=axis_dims,
                axis_names=axis_names,
                axis_types=axis_types_norm,
                devices=devices,
            )
            return _wrap_spx(jm, mpmd_axis)
    jm = _cached_mesh(
        axis_dims=axis_dims,
        axis_names=axis_names,
        axis_types=axis_types_norm,
        dcn_mesh_dims=dcn_mesh_dims,
        should_sort_granules_by_key=should_sort_granules_by_key,
        allow_split_physical_axes=allow_split_physical_axes,
        backend=backend,
    )
    return _wrap_spx(jm, mpmd_axis)


def _wrap_spx(jax_mesh: Mesh, mpmd_axis: str | None) -> SpxMesh:
    """Wrap ``jax_mesh`` in :class:`SpxMesh`, caching per ``(jax_mesh,
    mpmd_axis)`` so repeat calls to :func:`create_mesh` return the
    *same* :class:`SpxMesh` object (matches the underlying
    ``_cached_mesh`` semantics)."""
    key = (id(jax_mesh), mpmd_axis)
    cached = _SPX_MESH_CACHE.get(key)
    if cached is not None:
        return cached
    sm = SpxMesh(jax_mesh=jax_mesh, mpmd_axis=mpmd_axis)
    _SPX_MESH_CACHE[key] = sm
    return sm


def parse_mesh_from_string(axis_dims: str, names: Sequence[str]) -> Mesh:
    """Parse a mesh configuration from a human-readable string.

    Two formats supported:

    * **Named** — ``"dp:2,tp:4"`` explicitly maps axis name to size.
      Every name in ``names`` must appear exactly once.
    * **Positional** — ``"2,4"`` maps by position to the ``names``
      list.

    Useful for CLI / env-var driven configuration.

    Args:
        axis_dims: The config string (one of the two formats above).
        names: Axis names the result is expected to carry.

    Returns:
        The resulting :class:`~jax.sharding.Mesh`.

    Raises:
        ValueError: Unknown name, length mismatch, or the named
            entries don't cover ``names`` exactly.

    Example:
        >>> spx.sharding.parse_mesh_from_string("dp:2,tp:4", ("dp", "tp"))
        >>> spx.sharding.parse_mesh_from_string("2,4", ("data", "model"))
    """
    if ":" in axis_dims:
        dims: list[int] = []
        dim_names: list[str] = []
        for axis in axis_dims.split(","):
            name, dim = axis.split(":")
            if name not in names:
                raise ValueError(f"Axis name {name!r} not found in provided names: {tuple(names)}.")
            dims.append(int(dim))
            dim_names.append(name)
        if set(dim_names) != set(names):
            raise ValueError(
                f"Not all axis names were used in axis_dims. Expected: {tuple(names)}; got: {tuple(dim_names)}."
            )
    else:
        dims = [int(x) for x in axis_dims.split(",")]
        dim_names = list(names)
    if len(dims) != len(names):
        raise ValueError(f"Number of dimensions ({len(dims)}) must match names ({len(names)}).")
    return create_mesh(tuple(dims), tuple(dim_names))


def create_cpu_mesh(
    axis_dims: Sequence[int] = DEFAULT_MESH_AXIS_DIMS,
    axis_names: Sequence[str] = DEFAULT_MESH_AXIS_NAMES,
) -> Mesh:
    """Create a CPU-backed mesh for local debugging / unit tests.

    Shortcut for ``create_mesh(..., backend="cpu")``. Pairs naturally
    with ``XLA_FLAGS=--xla_force_host_platform_device_count=N`` to
    simulate a multi-device setup on a single host.

    Args:
        axis_dims: Per-axis dims. Default
            :data:`DEFAULT_MESH_AXIS_DIMS`.
        axis_names: Per-axis names. Default
            :data:`DEFAULT_MESH_AXIS_NAMES`.

    Returns:
        A :class:`~jax.sharding.Mesh` whose devices are all CPU.
    """
    return create_mesh(
        axis_dims=tuple(axis_dims),
        axis_names=tuple(axis_names),
        backend="cpu",
    )


@contextlib.contextmanager
def force_cpu() -> Iterator[Any]:
    """Temporarily pin JAX's default device to CPU.

    Unrelated state (meshes, already-placed arrays) is not affected.
    On exit, the previous default device is restored.

    Yields:
        The CPU device that was installed as default.

    Example:
        >>> with spx.sharding.force_cpu() as cpu:
        ...     y = jnp.ones((4,)) + 1      # runs on `cpu`
    """
    cpu = jax.local_devices(backend="cpu")[0]
    with jax.default_device(cpu):
        yield cpu


@contextlib.contextmanager
def cpu_context() -> Iterator[Mesh]:
    """Combined CPU mesh + forced-CPU execution context.

    Equivalent to::

        with force_cpu(), create_cpu_mesh() as mesh:
            yield mesh

    The commonest "debug my SPMD code locally" entry point.

    Yields:
        The CPU :class:`~jax.sharding.Mesh` created for the scope.

    Example:
        >>> with spx.sharding.cpu_context() as mesh:
        ...     @jax.jit
        ...     def step(x):
        ...         return x * 2
        ...     result = step(jnp.ones((4, 4)))
    """
    mesh = create_cpu_mesh()
    with force_cpu(), mesh:
        yield mesh
