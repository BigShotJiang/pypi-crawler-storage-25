# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""SPMD helpers.

Logical axis-name rules, per-initializer sharding metadata, and
:class:`~jax.sharding.PartitionSpec` / :class:`~jax.sharding.NamedSharding`
derivation from a module or a :class:`~specflux.State`.
"""

from .logical import current_axis_rules, logical_axis_rules
from .mesh import (
    DEFAULT_MESH_AXIS_DIMS,
    DEFAULT_MESH_AXIS_NAMES,
    SpxMesh,
    calculate_host_mesh_shape,
    cpu_context,
    create_cpu_mesh,
    create_mesh,
    force_cpu,
    parse_mesh_from_string,
)
from .partition import (
    get_named_sharding,
    get_partition_spec,
    with_partitioning,
    with_sharding_constraint_by_name,
)

__all__ = [
    "DEFAULT_MESH_AXIS_DIMS",
    "DEFAULT_MESH_AXIS_NAMES",
    "SpxMesh",
    "calculate_host_mesh_shape",
    "cpu_context",
    "create_cpu_mesh",
    "create_mesh",
    "current_axis_rules",
    "force_cpu",
    "get_named_sharding",
    "get_partition_spec",
    "logical_axis_rules",
    "parse_mesh_from_string",
    "with_partitioning",
    "with_sharding_constraint_by_name",
]
