# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Forward hooks and variable-write observers.

Forward hooks fire in eager mode around :meth:`Module.__call__`; under
a specflux transform they are suppressed with a single warning per
module (use ``self.sow("intermediates", ...)`` for transform-safe
capture). Variable observers fire on successful eager writes.
"""

from .forward import Handle, register_forward_hook, register_forward_pre_hook
from .variable import register_variable_hook

__all__ = [
    "Handle",
    "register_forward_hook",
    "register_forward_pre_hook",
    "register_variable_hook",
]
