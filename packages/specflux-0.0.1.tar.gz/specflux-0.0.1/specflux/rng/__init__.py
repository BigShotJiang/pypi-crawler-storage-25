# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Explicit named-stream RNG.

This subpackage implements the :class:`~specflux.Rngs` object and a
thread-local ``seed`` context manager. Stream state is stored in JAX
arrays inside :class:`~specflux.RngStream` variables, so it travels
with the model's :class:`~specflux.State` and survives
``jit`` / ``grad`` / ``vmap`` / ``scan`` / ``remat``.
"""

from .rngs import Rngs, RngStream, resolve_rngs
from .seed import default_rngs, seed

__all__ = ["RngStream", "Rngs", "default_rngs", "resolve_rngs", "seed"]
