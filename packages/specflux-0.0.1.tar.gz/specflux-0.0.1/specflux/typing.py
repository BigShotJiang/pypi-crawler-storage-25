# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Public type aliases and protocols for specflux users.

Re-exports from :mod:`specflux.core._typing`. Import these when typing
code that interacts with the specflux API so callers and implementers
agree on the shapes of arrays, dtypes, initializers, and hook
callables.
"""

from __future__ import annotations

from .core._typing import (
    Array,
    ArrayLike,
    DType,
    ForwardHook,
    ForwardPreHook,
    Initializer,
    ModulePredicate,
    Path,
    PathComponent,
    PRNGKey,
    Shape,
    VariableObserver,
    VariablePredicate,
)

__all__ = [
    "Array",
    "ArrayLike",
    "DType",
    "ForwardHook",
    "ForwardPreHook",
    "Initializer",
    "ModulePredicate",
    "PRNGKey",
    "Path",
    "PathComponent",
    "Shape",
    "VariableObserver",
    "VariablePredicate",
]
