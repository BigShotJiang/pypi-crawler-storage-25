# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module-aware :func:`jax.vmap` wrapper.

Module states are not vmapped (passed through with ``in_axes=None``);
only the remaining pytree arguments follow the user-provided
``in_axes``. Mutations to declared-mutable collections are reduced with
``out_axes=None`` so a single post-vmap state update is applied back
to the live module.
"""

from __future__ import annotations

import functools
from collections.abc import Callable
from typing import Any, TypeVar

import jax

from ..core.selector import SelectorSugar
from .split_merge import (
    apply_mutations,
    locate_and_strip,
    make_pure,
    resolve_mutable,
)

__all__ = ["vmap"]

F = TypeVar("F", bound=Callable[..., Any])

AxisName = Any
"""Placeholder for JAX axis-name sentinels (hashable values)."""


def vmap(
    fn: F | None = None,
    *,
    mutable: SelectorSugar = (),
    in_axes: Any = 0,
    out_axes: Any = 0,
    axis_name: AxisName | None = None,
    axis_size: int | None = None,
    spmd_axis_name: AxisName | tuple[AxisName, ...] | None = None,
    sum_match: bool = False,
) -> F:
    """Module-aware :func:`jax.vmap`.

    Args:
        fn: Function to vmap. When omitted, returns a decorator
            factory.
        mutable: Selector controlling which collections may be written
            back after the transform.
        in_axes, out_axes, axis_name, axis_size, spmd_axis_name,
            sum_match: Forwarded to :func:`jax.vmap`.
    """
    if fn is None:
        return lambda f: vmap(
            f,
            mutable=mutable,
            in_axes=in_axes,
            out_axes=out_axes,
            axis_name=axis_name,
            axis_size=axis_size,
            spmd_axis_name=spmd_axis_name,
            sum_match=sum_match,
        )

    mutable_sel = resolve_mutable(mutable)

    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        """Locate modules, build the pure callable, and dispatch through :func:`jax.vmap`."""
        refs, stripped_args, stripped_kwargs = locate_and_strip(args, kwargs)
        pure = make_pure(fn, refs)
        pure_in_axes = (None, in_axes, None)
        vmapped = jax.vmap(
            pure,
            in_axes=pure_in_axes,
            out_axes=(out_axes, None),
            axis_name=axis_name,
            axis_size=axis_size,
            spmd_axis_name=spmd_axis_name,
            sum_match=sum_match,
        )
        states_in = tuple(r.state for r in refs)
        out, new_states = vmapped(states_in, stripped_args, stripped_kwargs)
        apply_mutations(refs, list(new_states), mutable_sel)
        return out

    return wrapped
