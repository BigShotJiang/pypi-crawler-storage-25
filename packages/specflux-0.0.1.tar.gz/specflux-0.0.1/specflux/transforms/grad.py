# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module-aware gradients: :func:`grad` and :func:`value_and_grad`.

The differentiation target is selected by ``wrt`` — a
:class:`~specflux.Selector` or one of its sugar forms. By default
specflux differentiates the ``"params"`` collection of the first
:class:`~specflux.Module` argument. Every non-specflux keyword is
forwarded to :func:`jax.value_and_grad` verbatim.
"""

from __future__ import annotations

import functools
from collections.abc import Callable, Sequence
from typing import Any, TypeVar

import jax

from ..core.graph import bind, export
from ..core.module import Module, _set_inside_transform
from ..core.selector import SelectorSugar, as_selector
from ..core.state import State

__all__ = ["grad", "value_and_grad"]

F = TypeVar("F", bound=Callable[..., Any])

AxisName = Any
"""Type alias for a JAX axis-name sentinel (no canonical type exists)."""


def value_and_grad(
    fn: F | None = None,
    *,
    wrt: SelectorSugar = "params",
    argnum: int | None = None,
    has_aux: bool = False,
    holomorphic: bool = False,
    allow_int: bool = False,
    reduce_axes: Sequence[AxisName] = (),
) -> F:
    """Module-aware :func:`jax.value_and_grad`.

    Args:
        fn: Function whose first :class:`Module` argument is the target
            of differentiation. When called without ``fn`` returns a
            decorator factory.
        wrt: Selector for the state to differentiate (default:
            ``"params"``).
        argnum: Which positional argument is the differentiated
            :class:`Module`. Defaults to the first Module argument.
        has_aux: Forwarded to :func:`jax.value_and_grad`. When ``True``,
            ``fn`` is expected to return ``(value, aux)``.
        holomorphic, allow_int, reduce_axes: Forwarded to
            :func:`jax.value_and_grad`.

    Returns:
        A wrapped callable returning ``(value, grads)`` — or
        ``((value, aux), grads)`` if ``has_aux``. ``grads`` is a
        :class:`~specflux.State` with the same shape as the selected
        subset.
    """
    if fn is None:
        return lambda f: value_and_grad(
            f,
            wrt=wrt,
            argnum=argnum,
            has_aux=has_aux,
            holomorphic=holomorphic,
            allow_int=allow_int,
            reduce_axes=reduce_axes,
        )

    wrt_sel = as_selector(wrt)

    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        """Partition the module's state, differentiate, and re-merge."""
        idx = argnum if argnum is not None else _find_first_module(args)
        model = args[idx]
        if not isinstance(model, Module):
            raise TypeError(f"Argument {idx} must be a Module, got {type(model).__name__}")
        gdef, state = export(model)
        target, rest = wrt_sel.partition_state(model, state)
        other_args = tuple(args[:idx]) + tuple(args[idx + 1 :])

        def pure(
            target_state: State,
            rest_state: State,
            other: tuple[Any, ...],
            kw: dict[str, Any],
        ) -> tuple[Any, Any]:
            """Pure closure fed to :func:`jax.value_and_grad`."""
            merged = target_state.merge(rest_state)
            m = bind(gdef, merged)
            spliced = list(other)
            spliced.insert(idx, m)
            _set_inside_transform(True)
            try:
                out = fn(*spliced, **kw)
            finally:
                _set_inside_transform(False)
            if has_aux:
                val, aux = out
                return val, aux
            return out, None

        vg_kwargs: dict[str, Any] = {
            "has_aux": True,
            "holomorphic": holomorphic,
            "allow_int": allow_int,
        }
        if reduce_axes:
            vg_kwargs["reduce_axes"] = reduce_axes
        vg = jax.value_and_grad(pure, **vg_kwargs)
        (value, aux), grads_target = vg(target, rest, other_args, kwargs)
        if has_aux:
            return (value, aux), grads_target
        return value, grads_target

    return wrapped


def grad(
    fn: F | None = None,
    *,
    wrt: SelectorSugar = "params",
    argnum: int | None = None,
    has_aux: bool = False,
    holomorphic: bool = False,
    allow_int: bool = False,
    reduce_axes: Sequence[AxisName] = (),
) -> F:
    """Module-aware :func:`jax.grad`.

    Thin wrapper over :func:`value_and_grad` that drops the value
    component. See :func:`value_and_grad` for argument semantics.
    """
    if fn is None:
        return lambda f: grad(
            f,
            wrt=wrt,
            argnum=argnum,
            has_aux=has_aux,
            holomorphic=holomorphic,
            allow_int=allow_int,
            reduce_axes=reduce_axes,
        )

    vg = value_and_grad(
        fn,
        wrt=wrt,
        argnum=argnum,
        has_aux=has_aux,
        holomorphic=holomorphic,
        allow_int=allow_int,
        reduce_axes=reduce_axes,
    )

    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        """Return only the gradient half of the :func:`value_and_grad` output."""
        out = vg(*args, **kwargs)
        if has_aux:
            (_, aux), grads = out
            return grads, aux
        _, grads = out
        return grads

    return wrapped


def _find_first_module(args: tuple[Any, ...]) -> int:
    """Return the positional index of the first :class:`Module` in ``args``.

    Raises:
        TypeError: If no positional argument is a :class:`Module`.
    """
    for i, a in enumerate(args):
        if isinstance(a, Module):
            return i
    raise TypeError("specflux.grad requires at least one Module argument")
