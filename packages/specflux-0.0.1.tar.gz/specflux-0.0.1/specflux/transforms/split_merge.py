# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The shared split/merge shim used by every specflux transform.

Every specflux transform follows the same recipe:

1. Walk ``args`` / ``kwargs`` to locate :class:`~specflux.Module`
   instances via :func:`locate_modules`.
2. :func:`~specflux.export` each to produce ``(GraphDef, State)``.
3. Build a pure function that, given the list of states, rebinds fresh
   modules, calls the user function, and re-exports to capture
   mutations (:func:`make_pure`).
4. Apply the underlying JAX transform to that pure function.
5. On exit, apply mutations back to the original live modules,
   restricted to the ``mutable`` selector, via :func:`apply_mutations`.

Non-module arguments flow through unchanged via :func:`strip_modules`
and :func:`splice_modules` (they are replaced with ``None`` placeholders
through the pure function and re-spliced on the other side).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import jax

from ..core.context import _enter as _ctx_enter
from ..core.errors import IllegalMutationError
from ..core.graph import GraphDef, bind, export, live_variables
from ..core.module import Module, _set_inside_transform
from ..core.selector import Selector, SelectorSugar, as_selector
from ..core.selector import select as _sel
from ..core.state import State

__all__ = [
    "apply_mutations",
    "locate_and_strip",
    "locate_modules",
    "make_pure",
    "make_pure_ctx",
    "resolve_mutable",
    "splice_modules",
    "strip_modules",
]


PureFn = Callable[
    [tuple[State, ...], tuple[Any, ...], dict[str, Any]],
    tuple[Any, tuple[State, ...]],
]
"""Type of the pure function produced by :func:`make_pure`."""


@dataclass(slots=True)
class _ModuleRef:
    """A located module inside a transform's argument tree.

    Attributes:
        kind: ``"arg"`` or ``"kwarg"``.
        locator: Integer index (when ``kind == "arg"``) or string key
            (when ``kind == "kwarg"``).
        module: The live module reference.
        gdef: The graph-def snapshotted at :func:`locate_modules`.
        state: The state snapshotted at :func:`locate_modules`.
    """

    kind: str
    locator: int | str
    module: Module
    gdef: GraphDef
    state: State


def locate_modules(args: tuple[Any, ...], kwargs: dict[str, Any]) -> list[_ModuleRef]:
    """Scan ``args`` / ``kwargs`` and return one :class:`_ModuleRef` per :class:`Module`.

    Each reference carries a freshly-computed ``(gdef, state)`` snapshot
    used as the input to the transform.
    """
    refs: list[_ModuleRef] = []
    for i, a in enumerate(args):
        if isinstance(a, Module):
            g, s = export(a)
            refs.append(_ModuleRef("arg", i, a, g, s))
    for k, v in kwargs.items():
        if isinstance(v, Module):
            g, s = export(v)
            refs.append(_ModuleRef("kwarg", k, v, g, s))
    return refs


def locate_and_strip_fast(args: tuple[Any, ...]) -> tuple[list[_ModuleRef], tuple[Any, ...]]:
    """Kwargs-less fast variant of :func:`locate_and_strip`.

    Single pass over positional ``args``; each :class:`Module` is
    exported into a :class:`_ModuleRef` and replaced by ``None`` in the
    stripped tuple. Used by :func:`~specflux.jit`'s kwargs-empty hot
    path (the common case for training-step wrappers).
    """
    refs: list[_ModuleRef] = []
    stripped: list[Any] = []
    for i, a in enumerate(args):
        if isinstance(a, Module):
            g, s = export(a)
            refs.append(_ModuleRef("arg", i, a, g, s))
            stripped.append(None)
        else:
            stripped.append(a)
    return refs, tuple(stripped)


def locate_and_strip(
    args: tuple[Any, ...], kwargs: dict[str, Any]
) -> tuple[list[_ModuleRef], tuple[Any, ...], dict[str, Any]]:
    """Locate modules and strip them to ``None`` placeholders in one pass.

    Fused equivalent of :func:`locate_modules` followed by
    :func:`strip_modules`. Each ``args`` / ``kwargs`` sequence is
    iterated exactly once; non-module values flow through to the
    stripped tuple/dict while module values are exported (gdef + state
    snapshot) and recorded in a :class:`_ModuleRef`. Used by every
    module-aware transform wrapper (:func:`~specflux.jit`,
    :func:`~specflux.vmap`, :func:`~specflux.remat`) on the dispatch
    hot path.

    Args:
        args: Positional arguments passed to the wrapped function.
        kwargs: Keyword arguments passed to the wrapped function.

    Returns:
        A triple ``(refs, stripped_args, stripped_kwargs)``:

        * ``refs`` — one :class:`_ModuleRef` per located module, in the
          order ``args`` first then ``kwargs``.
        * ``stripped_args`` — ``args`` with every module replaced by
          ``None`` so the rest passes cleanly through :func:`jax.jit`.
        * ``stripped_kwargs`` — same substitution applied to ``kwargs``.
    """
    refs: list[_ModuleRef] = []
    new_args_list: list[Any] = [None] * len(args)
    for i, a in enumerate(args):
        if isinstance(a, Module):
            g, s = export(a)
            refs.append(_ModuleRef("arg", i, a, g, s))
        else:
            new_args_list[i] = a
    new_kwargs: dict[str, Any] = {}
    for k, v in kwargs.items():
        if isinstance(v, Module):
            g, s = export(v)
            refs.append(_ModuleRef("kwarg", k, v, g, s))
            new_kwargs[k] = None
        else:
            new_kwargs[k] = v
    return refs, tuple(new_args_list), new_kwargs


def strip_modules(args: tuple[Any, ...], kwargs: dict[str, Any]) -> tuple[tuple[Any, ...], dict[str, Any]]:
    """Replace :class:`Module` entries with ``None`` placeholders.

    The result flows through the pure function as a normal JAX pytree
    input; modules themselves are passed separately as states.
    """
    new_args = tuple(None if isinstance(a, Module) else a for a in args)
    new_kwargs = {k: None if isinstance(v, Module) else v for k, v in kwargs.items()}
    return new_args, new_kwargs


def splice_modules(
    stripped_args: tuple[Any, ...],
    stripped_kwargs: dict[str, Any],
    refs: list[_ModuleRef],
    modules: list[Module],
) -> tuple[tuple[Any, ...], dict[str, Any]]:
    """Write freshly-bound ``modules`` back into the stripped-arg tree.

    The inverse of :func:`strip_modules`. Preserves positional and
    keyword locations as recorded in ``refs``.
    """
    args = list(stripped_args)
    kwargs = dict(stripped_kwargs)
    for ref, m in zip(refs, modules, strict=False):
        if ref.kind == "arg":
            args[ref.locator] = m
        else:
            kwargs[ref.locator] = m
    return tuple(args), kwargs


def _run_pure_body(
    fn: Callable[..., Any],
    gdefs: tuple[GraphDef, ...],
    orig_modules: tuple[Module, ...],
    refs: list[_ModuleRef],
    states: tuple[State, ...],
    stripped_args: tuple[Any, ...],
    stripped_kwargs: dict[str, Any],
    ctx: dict[str, Any] | None,
) -> tuple[Any, tuple[State, ...]]:
    """Shared trace-time body of :func:`make_pure` and :func:`make_pure_ctx`.

    Rebinds fresh modules from ``states``, snapshots each live
    variable's ``_value`` identity, invokes ``fn``, and re-packs only
    the mutated leaves into ``new_states``. When ``ctx`` is provided
    (the :func:`make_pure_ctx` path), the invocation is wrapped in
    :func:`_ctx_enter` so :func:`~specflux.scope` lookups inside the
    trace see the traced values instead of concrete ones.
    """
    modules = [bind(g, s) for g, s in zip(gdefs, states, strict=False)]
    for src, dst in zip(orig_modules, modules, strict=False):
        _copy_runtime_state(src, dst)
    initial: list[list[tuple[str, Any, Any]]] = []
    for m in modules:
        entries: list[tuple[str, Any, Any]] = []
        for path, v in live_variables(m):
            entries.append((path, v, v._value))
        initial.append(entries)
    fargs, fkwargs = splice_modules(stripped_args, stripped_kwargs, refs, modules)
    _set_inside_transform(True)
    try:
        if ctx is None:
            out = fn(*fargs, **fkwargs)
        else:
            with _ctx_enter(ctx):
                out = fn(*fargs, **fkwargs)
    finally:
        _set_inside_transform(False)
    new_states: list[State] = []
    for entries in initial:
        changed: dict[str, dict[str, Any]] = {}
        for path, var, init_val in entries:
            cur = var._value
            if cur is not init_val:
                changed.setdefault(var.kind, {})[path] = cur
        new_states.append(State(changed))
    return out, tuple(new_states)


def make_pure(fn: Callable[..., Any], refs: list[_ModuleRef]) -> PureFn:
    """Construct the pure function fed into :mod:`jax`.

    The returned function has signature
    ``pure(states, stripped_args, stripped_kwargs) -> (out, new_states)``.
    It rebinds fresh :class:`Module` instances from the states, sets
    the thread-local "inside transform" flag, calls ``fn`` with the
    spliced arguments, and re-exports to capture any mutations.

    This runs at trace time (once per compile). The trick:
    :func:`~specflux.bind` creates fresh :class:`~specflux.Variable`
    instances whose ``_value`` is the incoming tracer from
    ``states``. Before calling ``fn`` we snapshot the ``_value``
    identity of every live variable; after ``fn`` returns, any
    variable whose ``_value`` is no longer identity-equal to its
    snapshot was mutated during the call (a ``var.value = ...``
    assignment rebinds ``_value`` to a new tracer).

    Only those mutated leaves are packed into ``new_states``. The
    unmutated majority is absent from the output pytree entirely,
    so the post-jit :func:`apply_mutations` step has no per-leaf
    comparison work to do on the dispatch hot path. The net effect
    is that a pure forward pass through jit returns an empty state
    tuple for every module.
    """
    gdefs = tuple(r.gdef for r in refs)
    orig_modules = tuple(r.module for r in refs)

    def pure(
        states: tuple[State, ...],
        stripped_args: tuple[Any, ...],
        stripped_kwargs: dict[str, Any],
    ) -> tuple[Any, tuple[State, ...]]:
        """JAX-traced body: rebind modules, invoke ``fn``, emit only mutated leaves."""
        return _run_pure_body(fn, gdefs, orig_modules, refs, states, stripped_args, stripped_kwargs, None)

    return pure


def make_pure_ctx(fn: Callable[..., Any], refs: list[_ModuleRef]) -> Callable[..., Any]:
    """Variant of :func:`make_pure` that reinstates a scope frame before ``fn``.

    Used by :func:`~specflux.jit` when the caller has active
    :func:`~specflux.scope` bindings. The extra ``traced_ctx`` argument
    carries the array-typed scope values as a pytree, which JAX
    lowers to tracers; installing them as a scope frame before
    invoking ``fn`` lets deep ``spx.scope.get(...)`` calls inside the
    traced body resolve to tracer values instead of the concrete
    constants that were live at trace time.

    Signature:
    ``pure(states, traced_ctx, stripped_args, stripped_kwargs) ->
    (out, new_states)``.

    Args:
        fn: The user function being traced.
        refs: Module refs produced by :func:`locate_and_strip`.

    Returns:
        A pure callable consumable by :func:`jax.jit`.
    """
    gdefs = tuple(r.gdef for r in refs)
    orig_modules = tuple(r.module for r in refs)

    def pure(
        states: tuple[State, ...],
        traced_ctx: dict[str, Any],
        stripped_args: tuple[Any, ...],
        stripped_kwargs: dict[str, Any],
    ) -> tuple[Any, tuple[State, ...]]:
        """Same shape as :func:`make_pure`'s pure, plus a ``traced_ctx`` arg."""
        return _run_pure_body(fn, gdefs, orig_modules, refs, states, stripped_args, stripped_kwargs, traced_ctx)

    return pure


def apply_mutations(
    refs: list[_ModuleRef],
    new_states: list[State],
    mutable: Selector | None,
) -> None:
    """Write ``new_states`` back to the live modules, honoring ``mutable``.

    The inverse of the trace-time capture done in :func:`make_pure`: for
    every variable whose leaf differs from the pre-transform snapshot,
    the new value is copied into the live :class:`~specflux.Variable`'s
    underlying storage. Leaves that are identity-equal to
    :attr:`_ModuleRef.state` are treated as unchanged — either
    :func:`make_pure` elided them at trace time, or a control-flow path
    (:func:`~specflux.cond`, :func:`~specflux.scan`, …) merged the
    untouched invariant portion of the state back in. Mutations outside
    the ``mutable`` selector raise :class:`~specflux.IllegalMutationError`.

    The ``vars_by_path`` dict is built once per call by reusing the live
    module's :func:`~specflux.export` cache — no extra tree walk. The
    ``allowed`` set is constructed lazily only when a real mutation is
    detected, so a pure forward pass (no mutations) pays only an
    ``if not new_raw: continue`` check per module.

    Args:
        refs: One :class:`_ModuleRef` per live module that flowed
            through the transform.
        new_states: List of :class:`State` objects parallel to ``refs``,
            typically the second half of the pure function's return.
        mutable: Selector picking which (collection, path) pairs are
            allowed to mutate. ``None`` means "nothing mutable".

    Raises:
        IllegalMutationError: When a variable's leaf changed under a
            transform but the (collection, path) is not picked by
            ``mutable``.
    """
    mutable_kind_set: set[str] | None = None
    if (
        mutable is not None
        and not mutable.subselectors
        and not mutable.module_types
        and not mutable.exclude_module_types
        and not mutable.module_where
        and not mutable.variable_types
        and not mutable.exclude_variable_types
        and not mutable.path_globs
        and not mutable.variable_where
        and not mutable.invert
        and mutable.variable_kinds
    ):
        mutable_kind_set = set(mutable.variable_kinds)

    if mutable_kind_set is not None:
        for ref, new_state in zip(refs, new_states, strict=False):
            new_raw = new_state.raw()
            if not new_raw:
                continue
            cache = ref.module._spx_export_cache
            vars_by_collection = cache[5] if cache is not None and len(cache) >= 6 else None
            old_raw = ref.state.raw()
            for c, d in new_raw.items():
                if not d:
                    continue
                if c not in mutable_kind_set:
                    for p, new_val in d.items():
                        old_val = old_raw.get(c, {}).get(p)
                        if old_val is new_val:
                            continue
                        raise IllegalMutationError(
                            f"Collection {c!r} at path {p!r} changed under a "
                            f"transform but was not declared mutable. "
                            f"Add it to `mutable=`."
                        )
                    continue
                old_d = old_raw.get(c, {})
                if vars_by_collection is not None:
                    inner = vars_by_collection.get(c)
                    if inner is None:
                        continue
                    for p, new_val in d.items():
                        if old_d.get(p) is new_val:
                            continue
                        var = inner.get(p)
                        if var is not None:
                            var._value = new_val
                else:
                    vars_by_path = {(_v.kind, _p): _v for _p, _v in _sel().apply(ref.module)}
                    for p, new_val in d.items():
                        if old_d.get(p) is new_val:
                            continue
                        var = vars_by_path.get((c, p))
                        if var is not None:
                            var._value = new_val
        return

    for ref, new_state in zip(refs, new_states, strict=False):
        new_raw = new_state.raw()
        if not new_raw:
            continue

        old_raw = ref.state.raw()
        vars_by_path: dict[tuple[str, str], Any] | None = None
        allowed: set[tuple[str, str]] | None = None

        for c, d in new_raw.items():
            if not d:
                continue
            old_d = old_raw.get(c, {})
            for p, new_val in d.items():
                old_val = old_d.get(p)
                if old_val is new_val:
                    continue
                if allowed is None:
                    allowed = set()
                    if mutable is not None:
                        for _p, _v in mutable.apply(ref.module):
                            allowed.add((_v.kind, _p))
                if (c, p) not in allowed:
                    raise IllegalMutationError(
                        f"Collection {c!r} at path {p!r} changed under a "
                        f"transform but was not declared mutable. "
                        f"Add it to `mutable=`."
                    )
                if vars_by_path is None:
                    cache = ref.module._spx_export_cache
                    if cache is not None and len(cache) >= 4:
                        vars_by_path = cache[3]
                    else:
                        vars_by_path = {(_v.kind, _p): _v for _p, _v in _sel().apply(ref.module)}
                var = vars_by_path.get((c, p))
                if var is not None:
                    var._raw_set(new_val)


def _copy_runtime_state(src: Module, dst: Module) -> None:
    """Copy non-graph runtime state (training flag) from ``src`` onto ``dst``.

    :class:`Module` mode flags are not part of :class:`GraphDef` and
    therefore do not survive :func:`bind`. This helper walks both trees in
    lockstep and restores them so eager-mode toggles (``train()`` /
    ``eval()``) take effect inside transforms.
    """
    object.__setattr__(dst, "_spx_training", src._spx_training)
    src_children = list(src._spx_graph_children())
    dst_children = list(dst._spx_graph_children())
    for (_, sc), (_, dc) in zip(src_children, dst_children, strict=False):
        if isinstance(sc, Module) and isinstance(dc, Module):
            _copy_runtime_state(sc, dc)


def _is_same(a: Any, b: Any) -> bool:
    """Return ``True`` if ``a`` and ``b`` refer to the same array value.

    Falls back to :func:`jax.numpy.array_equal`; returns ``False`` on
    any comparison exception (traced values during tracing, etc.).
    """
    if a is b:
        return True
    try:
        return bool(jax.numpy.array_equal(a, b))
    except Exception:
        return False


def resolve_mutable(mutable: SelectorSugar | tuple[()] | list[Any]) -> Selector | None:
    """Coerce a ``mutable=`` argument into a :class:`~specflux.Selector`.

    The empty tuple ``()`` and empty list ``[]`` as well as ``None``
    resolve to ``None`` (meaning "no collections are mutable").
    Everything else is forwarded to :func:`~specflux.as_selector`.
    """
    if mutable is None or mutable == () or mutable == []:
        return None
    return as_selector(mutable)
