# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module-aware ``jax.jit`` wrapper.

Every keyword supported by :func:`jax.jit` is available here with the
same default as upstream. SpecFlux adds one more: ``mutable`` selects
which collections (e.g. ``"batch_stats"``, ``"cache"``) may be written
back to live modules after the transformed call. Any other write raises
:class:`~specflux.IllegalMutationError`.

Note that the compiled function's argument layout is
``(states, stripped_args, stripped_kwargs)`` rather than the user's
original signature, so ``static_argnums`` / ``donate_argnums`` /
``in_shardings`` / ``out_shardings`` index into that 3-tuple. When in
doubt use the ``*_argnames`` variants.
"""

from __future__ import annotations

import functools
from collections.abc import Callable, Iterable, Sequence
from typing import Any, TypeVar

import jax

from ..core.context import _STACK as _CTX_STACK
from ..core.context import partition as _ctx_partition
from ..core.module import _graph_epoch
from ..core.selector import SelectorSugar
from .split_merge import (
    apply_mutations,
    locate_and_strip,
    locate_and_strip_fast,
    make_pure,
    make_pure_ctx,
    resolve_mutable,
)

__all__ = ["jit"]

F = TypeVar("F", bound=Callable[..., Any])

_UNSET: Any = object()
"""Sentinel indicating that a keyword was not supplied, so JAX's own
``UnspecifiedValue`` default is used.
"""


def jit(
    fn: F | None = None,
    *,
    mutable: SelectorSugar = (),
    in_shardings: Any = _UNSET,
    out_shardings: Any = _UNSET,
    static_argnums: int | Sequence[int] | None = None,
    static_argnames: str | Iterable[str] | None = None,
    donate_argnums: int | Sequence[int] | None = None,
    donate_argnames: str | Iterable[str] | None = None,
    keep_unused: bool = False,
    device: Any = None,
    backend: str | None = None,
    inline: bool = False,
    compiler_options: dict[str, Any] | None = None,
) -> F:
    """Module-aware ``jax.jit``.

    Args:
        fn: The function to compile. When called without ``fn`` the
            decorator returns a factory: ``@spx.jit(mutable=...)``.
        mutable: Selector (or collection-name sugar) controlling which
            collections may be written back after the call.
        in_shardings, out_shardings, static_argnums, static_argnames,
            donate_argnums, donate_argnames, keep_unused, device,
            backend, inline, compiler_options: Forwarded verbatim to
            :func:`jax.jit`.

    Returns:
        A wrapped function. The first call per distinct
        :class:`~specflux.GraphDef` tuple triggers a JAX trace; later
        calls with matching graph-defs re-use the cached compile.
    """
    if fn is None:
        return lambda f: jit(
            f,
            mutable=mutable,
            in_shardings=in_shardings,
            out_shardings=out_shardings,
            static_argnums=static_argnums,
            static_argnames=static_argnames,
            donate_argnums=donate_argnums,
            donate_argnames=donate_argnames,
            keep_unused=keep_unused,
            device=device,
            backend=backend,
            inline=inline,
            compiler_options=compiler_options,
        )

    mutable_sel = resolve_mutable(mutable)

    jit_kwargs: dict[str, Any] = {
        "static_argnums": static_argnums,
        "static_argnames": static_argnames,
        "donate_argnums": donate_argnums,
        "donate_argnames": donate_argnames,
        "keep_unused": keep_unused,
        "device": device,
        "backend": backend,
        "inline": inline,
        "compiler_options": compiler_options,
    }
    if in_shardings is not _UNSET:
        jit_kwargs["in_shardings"] = in_shardings
    if out_shardings is not _UNSET:
        jit_kwargs["out_shardings"] = out_shardings

    _compile_cache: dict[tuple[Any, ...], Any] = {}
    _id_cache: dict[tuple[int, ...], tuple[int, Any]] = {}
    _id_cache_one: dict[int, tuple[int, Any]] = {}
    _ctx_compile_cache: dict[tuple[Any, ...], Any] = {}

    _locate = locate_and_strip
    _locate_fast = locate_and_strip_fast
    _epoch_fn = _graph_epoch
    _apply = apply_mutations
    _make_pure = make_pure
    _make_pure_ctx = make_pure_ctx
    _jax_jit = jax.jit
    _ctx_stack_get = _CTX_STACK.get
    _empty_kwargs: dict[str, Any] = {}

    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        """Dispatch through the graph-def-keyed compile cache.

        Two-level cache:

        1. Identity cache (``_id_cache``) keyed by the Python ``id``
           tuple of the input modules plus the current global graph
           epoch. Hot path: same model instance + no structural change
           returns the cached jitted callable in O(1) without ever
           touching the graph-def hash.
        2. Structural cache (``_compile_cache``) keyed by the full
           graph-def tuple. Handles model swaps, reloads, and distinct
           instances with identical structure.

        A kwargs-empty fast path uses :func:`locate_and_strip_fast`
        which does a single pass over ``args`` and skips the kwargs
        iteration entirely.

        Scope-aware slow path activates when the caller has active
        :func:`~specflux.scope` bindings: static context values are
        folded into the compile cache key (so different static
        snapshots specialize cleanly); array-typed context values are
        lifted into the jit input tuple and reinstated as a scope
        frame inside the traced body (see :func:`make_pure_ctx`). The
        no-scope hot path above is completely unaffected — a single
        :class:`~contextvars.ContextVar` read (~50 ns) decides which
        path to take.
        """
        ctx_stack = _ctx_stack_get()
        if ctx_stack:
            return _wrapped_with_ctx(ctx_stack, args, kwargs)

        if kwargs:
            refs, stripped_args, stripped_kwargs = _locate(args, kwargs)
        else:
            refs, stripped_args = _locate_fast(args)
            stripped_kwargs = _empty_kwargs
        n = len(refs)
        if n == 1:
            r0 = refs[0]
            mid = id(r0.module)
            states_in: tuple = (r0.state,)
            id_hit = _id_cache_one.get(mid)
            if id_hit is not None and id_hit[0] == _epoch_fn():
                jitted = id_hit[1]
            else:
                epoch = _epoch_fn()
                key = (r0.gdef,)
                jitted = _compile_cache.get(key)
                if jitted is None:
                    pure = _make_pure(fn, refs)
                    jitted = _jax_jit(pure, **jit_kwargs)
                    _compile_cache[key] = jitted
                _id_cache_one[mid] = (epoch, jitted)
        else:
            id_key_list = []
            states_list = []
            for r in refs:
                id_key_list.append(id(r.module))
                states_list.append(r.state)
            id_key = tuple(id_key_list)
            states_in = tuple(states_list)
            id_hit = _id_cache.get(id_key)
            if id_hit is not None and id_hit[0] == _epoch_fn():
                jitted = id_hit[1]
            else:
                epoch = _epoch_fn()
                key = tuple([r.gdef for r in refs])
                jitted = _compile_cache.get(key)
                if jitted is None:
                    pure = _make_pure(fn, refs)
                    jitted = _jax_jit(pure, **jit_kwargs)
                    _compile_cache[key] = jitted
                _id_cache[id_key] = (epoch, jitted)
        out, new_states = jitted(states_in, stripped_args, stripped_kwargs)
        _apply(refs, new_states, mutable_sel)
        return out

    def _wrapped_with_ctx(
        ctx_stack: tuple[dict[str, Any], ...],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> Any:
        """Scope-active dispatch path.

        Flattens the scope stack, splits it into
        :data:`~specflux.core.context.partition`'s traced/static halves,
        augments the compile-cache key with the static snapshot, and
        routes the call through a separate ``pure`` built by
        :func:`make_pure_ctx` so deep ``spx.scope.get(...)`` calls
        inside the traced body resolve to tracers rather than the
        constants captured at the trace-time snapshot.
        """
        snap: dict[str, Any] = {}
        for frame in ctx_stack:
            snap.update(frame)
        traced_ctx, static_ctx = _ctx_partition(snap)
        if kwargs:
            refs, stripped_args, stripped_kwargs = _locate(args, kwargs)
        else:
            refs, stripped_args = _locate_fast(args)
            stripped_kwargs = _empty_kwargs
        key = (tuple([r.gdef for r in refs]), static_ctx)
        jitted = _ctx_compile_cache.get(key)
        if jitted is None:
            pure = _make_pure_ctx(fn, refs)
            jitted = _jax_jit(pure, **jit_kwargs)
            _ctx_compile_cache[key] = jitted
        states_in = tuple([r.state for r in refs])
        out, new_states = jitted(states_in, traced_ctx, stripped_args, stripped_kwargs)
        _apply(refs, new_states, mutable_sel)
        return out

    wrapped._spx_compile_cache = _compile_cache
    wrapped._spx_id_cache = _id_cache
    wrapped._spx_ctx_compile_cache = _ctx_compile_cache
    return wrapped
