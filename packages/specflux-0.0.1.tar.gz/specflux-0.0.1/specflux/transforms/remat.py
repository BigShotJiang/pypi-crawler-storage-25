# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module-aware :func:`jax.checkpoint` (gradient checkpointing) wrapper."""

from __future__ import annotations

import functools
import importlib
from collections.abc import Callable, Sequence
from typing import Any, TypeVar

import jax

from ..core.module import Module
from ..core.selector import SelectorSugar
from .split_merge import (
    apply_mutations,
    locate_and_strip,
    make_pure,
    resolve_mutable,
)

__all__ = ["remat"]

F = TypeVar("F", bound=Callable[..., Any])


_REMAT_CLASS_CACHE: dict[tuple, type] = {}
"""Cache of remat'd module subclasses keyed by ``(parent_class, config)``.

Ensures ``spx.remat(Llama3Block)`` returns the *same* class on every
call: avoids re-registering the pytree and lets
:func:`resolve_class` find the remat'd subclass during bind.
"""


def remat(
    fn: F | None = None,
    *,
    mutable: SelectorSugar = (),
    prevent_cse: bool | Sequence[bool] = True,
    policy: Callable[..., bool] | None = None,
    static_argnums: int | tuple[int, ...] = (),
) -> F:
    """Module-aware gradient checkpointing.

    Two usage modes:

    * **Function**: ``spx.remat(fn)`` returns a wrapped function that
      runs ``fn`` under :func:`jax.checkpoint`. Per-call wrapping.

    * **Module class**: ``spx.remat(MyBlock)`` where ``MyBlock`` is a
      subclass of :class:`specflux.Module` returns a new subclass whose
      ``forward`` is checkpointed once. Build instances normally and
      use them in a loop — every block call recomputes during backward
      without per-iteration ``spx.remat(...)`` calls in the model body::

          RematBlock = spx.remat(MyBlock)
          blocks = [RematBlock(cfg, rngs=rngs) for _ in range(N)]
          # inside model.forward:
          for blk in blocks:
              x = blk(x)   # already remat-wrapped

      The returned class is registered in the parent class's module
      namespace so ``specflux.export`` / ``bind`` can round-trip it.

    Args:
        fn: Function or :class:`Module` subclass to checkpoint; when
            omitted, returns a decorator factory.
        mutable: Selector controlling writable collections.
        prevent_cse, policy, static_argnums: Forwarded verbatim to
            :func:`jax.checkpoint`.
    """
    if fn is None:
        return lambda f: remat(
            f,
            mutable=mutable,
            prevent_cse=prevent_cse,
            policy=policy,
            static_argnums=static_argnums,
        )

    if isinstance(fn, type):
        if issubclass(fn, Module):
            return _remat_module_class(
                fn,
                mutable=mutable,
                prevent_cse=prevent_cse,
                policy=policy,
                static_argnums=static_argnums,
            )

    mutable_sel = resolve_mutable(mutable)

    @functools.wraps(fn)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        """Dispatch through :func:`jax.checkpoint` wrapped around the pure fn."""
        refs, stripped_args, stripped_kwargs = locate_and_strip(args, kwargs)
        pure = make_pure(fn, refs)
        checkpointed = jax.checkpoint(
            pure,
            prevent_cse=prevent_cse,
            policy=policy,
            static_argnums=static_argnums,
        )
        states_in = tuple(r.state for r in refs)
        out, new_states = checkpointed(states_in, stripped_args, stripped_kwargs)
        apply_mutations(refs, list(new_states), mutable_sel)
        return out

    return wrapped


def _remat_module_class(
    cls: type,
    *,
    mutable: SelectorSugar,
    prevent_cse: bool | Sequence[bool],
    policy: Callable[..., bool] | None,
    static_argnums: int | tuple[int, ...],
) -> type:
    """Build (and cache) a ``Remat<Cls>`` subclass whose ``forward`` is
    permanently wrapped in :func:`jax.checkpoint`. The new class is
    injected into ``cls``'s defining module under the name
    ``Remat<Qualname>`` so ``importlib`` / ``resolve_class`` finds it.

    On ``ImportError`` during parent-module registration, resolved
    class identity falls back to in-process use.
    """
    cache_key = (cls, mutable, prevent_cse, policy, static_argnums)
    cached = _REMAT_CLASS_CACHE.get(cache_key)
    if cached is not None:
        return cached

    parent_forward = cls.forward
    new_qualname = f"Remat{cls.__qualname__.replace('.', '_')}"

    class RematSubclass(cls):
        """Subclass of ``cls`` whose ``forward`` is wrapped in :func:`jax.checkpoint`."""

        def forward(self, *args: Any, **kwargs: Any) -> Any:
            """Run the parent ``forward`` under :func:`remat`."""
            return remat(
                parent_forward.__get__(self),
                mutable=mutable,
                prevent_cse=prevent_cse,
                policy=policy,
                static_argnums=static_argnums,
            )(*args, **kwargs)

    RematSubclass.__name__ = new_qualname
    RematSubclass.__qualname__ = new_qualname
    RematSubclass.__module__ = cls.__module__

    try:
        parent_module = importlib.import_module(cls.__module__)
        if not hasattr(parent_module, new_qualname):
            setattr(parent_module, new_qualname, RematSubclass)
    except ImportError:
        pass

    _REMAT_CLASS_CACHE[cache_key] = RematSubclass
    return RematSubclass
