# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Module-aware :func:`jax.lax.scan` wrapper.

Signature::

    scan(fn, init_module, xs, *, length=None, mutable=(), unroll=1)

``fn`` has the shape ``(module, x) -> y``. The module's state is
partitioned into a *carry* (the declared-mutable collections) and an
*invariant* (everything else). Only the carry is threaded through the
scan; the invariant is required to stay structurally identical from
step to step.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import jax.lax as lax

from ..core.graph import bind, export
from ..core.module import Module, _set_inside_transform
from ..core.selector import SelectorSugar
from ..core.state import State
from .split_merge import _ModuleRef, apply_mutations, resolve_mutable

__all__ = ["scan"]


def scan(
    fn: Callable[[Module, Any], Any],
    init_module: Module,
    xs: Any,
    *,
    length: int | None = None,
    mutable: SelectorSugar = (),
    unroll: int = 1,
) -> Any:
    """Scan ``fn`` over ``xs`` threading ``init_module`` as state.

    Args:
        fn: Per-step function ``(module, x) -> y``.
        init_module: :class:`Module` providing the initial state.
        xs: Scanned sequence (pytree with a leading axis).
        length: Optional explicit sequence length.
        mutable: Selector for collections that may be carried through
            the scan. Collections outside this selector must be
            structurally invariant from step to step.
        unroll: Forwarded to :func:`jax.lax.scan`.

    Returns:
        The stacked ``ys`` from every step. The final carry is written
        back to ``init_module`` in place.
    """
    mutable_sel = resolve_mutable(mutable)
    if not isinstance(init_module, Module):
        raise TypeError("scan() requires a Module as init_module")
    gdef, state = export(init_module)

    if mutable_sel is None:
        carry_state: State = State({})
        invariant: State = state
    else:
        carry_state, invariant = mutable_sel.partition_state(init_module, state)

    def step(carry: State, x: Any) -> tuple[State, Any]:
        """Single scan step: merge state, run ``fn``, re-partition."""
        full = carry.merge(invariant)
        m = bind(gdef, full)
        _set_inside_transform(True)
        try:
            y = fn(m, x)
        finally:
            _set_inside_transform(False)
        _, new_state = export(m)
        new_carry, new_invariant = (
            (State({}), new_state) if mutable_sel is None else mutable_sel.partition_state(m, new_state)
        )
        _check_invariant_equal(invariant, new_invariant)
        return new_carry, y

    final_carry, ys = lax.scan(step, carry_state, xs, length=length, unroll=unroll)
    apply_mutations(
        [_ModuleRef("arg", 0, init_module, gdef, state)],
        [final_carry.merge(invariant)],
        mutable_sel,
    )
    return ys


def _check_invariant_equal(a: State, b: State) -> None:
    """Assert ``a`` and ``b`` have the same ``(collection, path)`` keys.

    Structural (key-set) check only; value equality is too strong under
    tracing. Mismatches raise :class:`ValueError` prompting the user to
    declare the differing collection as mutable.
    """
    a_keys = {(c, p) for c, p in a.paths()}
    b_keys = {(c, p) for c, p in b.paths()}
    if a_keys != b_keys:
        raise ValueError(
            "scan() invariant state changed across iterations. Declare the changing collection via `mutable=...`."
        )
