# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Opt-in helpers that depend on third-party libraries.

Anything here lives behind an optional install (e.g.
``pip install specflux[contrib]``) and must import gracefully when its
dependency is missing.
"""

from .optimizer import MultiOptimizer, Optimizer

__all__ = ["MultiOptimizer", "Optimizer"]
