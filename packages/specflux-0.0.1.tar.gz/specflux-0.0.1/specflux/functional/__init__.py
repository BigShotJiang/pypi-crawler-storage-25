# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Stateless tensor operations.

Every function here is pure: it takes JAX-compatible inputs and returns
an :class:`~specflux.typing.Array`. The :mod:`specflux.nn` layers build
on these implementations, so users can drop down to the functional form
whenever a module wrapper feels heavy.
"""

from .activation import (
    celu,
    elu,
    gelu,
    glu,
    hard_sigmoid,
    hard_silu,
    hard_swish,
    hard_tanh,
    leaky_relu,
    log_sigmoid,
    log_softmax,
    mish,
    prelu,
    relu,
    selu,
    sigmoid,
    silu,
    soft_sign,
    softmax,
    tanh,
)
from .attention import scaled_dot_product_attention
from .conv import conv, conv_transpose
from .dropout import dropout
from .linear import linear
from .norm import layer_norm, rms_norm
from .pool import avg_pool, max_pool, pool
from .util import promote_dtype

__all__ = [
    "avg_pool",
    "celu",
    "conv",
    "conv_transpose",
    "dropout",
    "elu",
    "gelu",
    "glu",
    "hard_sigmoid",
    "hard_silu",
    "hard_swish",
    "hard_tanh",
    "layer_norm",
    "leaky_relu",
    "linear",
    "log_sigmoid",
    "log_softmax",
    "max_pool",
    "mish",
    "pool",
    "prelu",
    "promote_dtype",
    "relu",
    "rms_norm",
    "scaled_dot_product_attention",
    "selu",
    "sigmoid",
    "silu",
    "soft_sign",
    "softmax",
    "tanh",
]
