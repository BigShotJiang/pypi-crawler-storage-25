# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
""":func:`sxcall`: multiple-program pipeline runtime for **heterogeneous stages**.

The SPMD runtime in :mod:`~specflux.pipeline.runtime` compiles one
jaxpr shared by every pipeline device and relies on the same-shape
constraint to keep that jaxpr consistent. For models whose stages
have **different shapes** — e.g. a transformer with a bulky
embedding stage, many uniform middle stages, and an lm-head stage —
this runtime compiles a **separate jitted function per stage** and
orchestrates them in Python. Activation and cotangent transfers use
:func:`jax.device_put` between per-stage sub-meshes.

Trade-offs:

* **Flexibility**: every stage can have a different class, different
  parameter shapes, different input/output shapes. The
  :class:`~specflux.pipeline.PipelineSequential` container still
  represents the model; the MPMD runtime just doesn't require
  matching ``GraphDef`` s.
* **Mesh composition**: stages live on the
  :class:`~specflux.pipeline.MpMdMesh`'s MPMD axis; other mesh axes
  are free for intra-stage FSDP / TP / DP.
* **Lower throughput**: no :func:`shard_map` fusion, so cross-device
  communication is coarser-grained. Still competitive for medium
  pipelines (4-16 stages); for larger / bandwidth-critical pipelines
  the SPMD path is preferred when applicable.
* **Python orchestration overhead**: the schedule loop runs in
  Python at dispatch time. Each step's stage work is jitted, so the
  compute cost inside each step is compiled to XLA, but the outer
  loop doesn't fuse across time steps.

**Architecture.** :func:`sxcall` is the public entry point. It
builds per-(rank, virt) jitted forward/backward callables, places
each stage's params+rest state on its rank's sub-mesh, microbatches
the batch, and then runs the schedule. GPipe + flat (V=1) schedules
hit a vmap fast-path (:func:`_gpipe_run`) that collapses M microbatch
dispatches into 1 per stage/phase; other schedules fall through to
the per-action Python loop that honours :class:`Schedule` ordering.

The schedule parameter actually controls execution order here: GPipe
queues all forwards then all backwards, Std1F1B interleaves forward
and backward microbatches in the steady state, ZeroBubbleH1 splits
each backward into input-grad and weight-grad to slot weight-grads
into bubble time, and so on. This gives MPMD its real value over
SPMD's auto-pipelined single-jit step: different schedules produce
measurably different step times and activation-memory profiles.

**Virtual-stage support.** ``V`` logical stages live on each physical
rank (V=1 for flat schedules like GPipe / Std1F1B). The schedule
tells us where each logical stage goes and where activations flow
next, so the runtime stays schedule-agnostic. Models must supply
``V * mpmd_dim`` logical stages in logical order; the runtime routes
each to its ``(rank, virt)`` slot via ``schedule.logical_at``.

**Caches.** Several module-level caches keep steady-state dispatch
free of retracing and repeated ``jax.device_put`` costs:

* ``_STAGE_CALLABLE_CACHE``: per-stage jitted fwd/bwd keyed on
  ``id(stage)`` so two Module instances reuse the same jits.
* ``_MPMD_SETUP_CACHE``: full ``sxcall`` setup (placed params/rest
  + fwd/bwd jits per ``(rank, virt)``), keyed on
  ``(id(model), id(mpmd_mesh), V)`` — avoids ~40 ``jax.device_put``
  calls per step (each ~0.2 ms) for the same model/mesh.
* ``_GPIPE_VMAP_CACHE`` / ``_GPIPE_TERM_CACHE``: vmapped fwd/bwd
  pairs and fused (fwd + loss + bwd) terminal jits for the GPipe
  fast-path.
* ``_LOSS_JIT_CACHE`` / ``_VMAP_LOSS_CACHE``: jitted
  ``loss_and_g_y`` wrappers (scalar and vmapped) keyed by
  ``id(loss_fn)``.

**Observability.** :func:`collect_task_times_ms` is a context manager
that attributes wall-clock milliseconds to named sub-tasks (each
stage fwd/bwd/loss plus cross-stage transfers). Timing uses a
thread-local profiler so concurrent ``sxcall`` calls from different
threads stay independent.
"""

from __future__ import annotations

import contextlib
import functools
import threading
import time
from collections.abc import Callable, Iterator
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from ...sharding.mesh import SpxMesh

import jax
import jax.numpy as jnp

from ...core._weakcache import weak_invalidate
from ...core.graph import bind, export, live_variables
from ...core.module import Module
from ...core.stage_assignment import metadata_stage_assignment, resolve_stage_rank
from ...core.state import State
from ...core.variable import Variable
from ...nn.pipeline_sequential import PipelineSequential
from ...sharding.partition import get_named_sharding
from ..primitives.split import auto_split
from ..schedules import (
    FusedTask,
    GPipe,
    Phase,
    Schedule,
    fuse_1f1b_steady_state,
    fuse_zerobubble_bwd_pair,
)
from ..types.array import StagesArray
from ..types.mesh import MpMdMesh, resolve_mpmd_mesh
from .markers import cluster_jaxpr_by_markers
from .pscan_compiler import (
    _build_invar_sources,
    _build_logical_locs,
    _build_schedule_grid,
    _collect_used_constvars,
    _filtered_cluster,
    _iter_actions,
    _make_bwd_jit,
    _make_fwd_jit,
    _make_terminal_jit,
    _materialize_cotangents,
    build_pscan_plan,
    dispatch_pscan,
    has_pscan,
)

__all__ = ["collect_task_times_ms", "sxcall", "sxgrad", "sxjit", "sxvalue_and_grad"]

_PROFILER_STATE = threading.local()
_STAGE_CALLABLE_CACHE: dict[int, tuple[Callable[..., Any], Callable[..., Any]]] = {}
_MPMD_SETUP_CACHE: dict[
    tuple[int, int, int],
    tuple[
        dict[tuple[int, int], Callable[..., Any]],
        dict[tuple[int, int], Callable[..., Any]],
        dict[tuple[int, int], State],
        dict[tuple[int, int], State],
        list[Any],
        list[Any],
    ],
] = {}
_INV_M_CACHE: dict[tuple[int, int], jax.Array] = {}
_GPIPE_VMAP_CACHE: dict[int, tuple[Callable[..., Any], Callable[..., Any]]] = {}
_GPIPE_TERM_CACHE: dict[tuple[int, int, str], Callable[..., Any]] = {}
_VMAP_LOSS_CACHE: dict[int, Callable[..., Any]] = {}
_FUSED_FWDBWD_CACHE: dict[tuple[int, int], Callable[..., Any]] = {}
_LOSS_JIT_CACHE: dict[int, Callable[..., Any]] = {}
_MPMD_CALL_NORMALIZED_CACHE: dict[tuple[int, int], PipelineSequential] = {}
_FWD_ONLY_VMAP_CACHE: dict[int, Callable[..., Any]] = {}


def _arg_leaf_ranges(args: tuple[Any, ...]) -> list[tuple[int, int]]:
    """Return flat-leaf ``[start, end)`` ranges for each positional argument."""
    ranges: list[tuple[int, int]] = []
    start = 0
    for arg in args:
        n_leaves = len(jax.tree.leaves(arg))
        ranges.append((start, start + n_leaves))
        start += n_leaves
    return ranges


def _normalize_argnums(argnums: int | tuple[int, ...] | None, total: int) -> tuple[int, ...]:
    """Normalize argnums to a tuple and validate bounds."""
    if argnums is None:
        return ()
    if isinstance(argnums, int):
        argnums = (argnums,)
    else:
        argnums = tuple(argnums)
    for i in argnums:
        if i < 0 or i >= total:
            raise ValueError(f"argnum {i} out of range for function with {total} positional arguments")
    return argnums


def _normalize_argnames(argnames: str | tuple[str, ...] | None) -> tuple[str, ...]:
    if argnames is None:
        return ()
    if isinstance(argnames, str):
        return (argnames,)
    return tuple(argnames)


def _compute_donation(
    clusters: list,
    original_id_to_idx: dict[int, int],
    orig_flat_to_dynamic_flat: dict[int, int],
    args: tuple[Any, ...],
    donate_nums: set[int],
    static_nums: set[int],
    n: int,
) -> list[tuple[int, ...]]:
    """Compute per-stage donate_argnums from original donate_argnums."""
    donate_per_stage: list[set[int]] = [set() for _ in range(n)]
    for donate_num in donate_nums:
        if donate_num in static_nums:
            raise ValueError(
                f"sxjit: cannot donate static argument at index {donate_num}. "
                "Static arguments are compile-time constants and cannot be donated."
            )
        flat_start = sum(len(jax.tree.leaves(args[i])) for i in range(donate_num))
        n_leaves = len(jax.tree.leaves(args[donate_num]))
        for leaf_offset in range(n_leaves):
            orig_flat = flat_start + leaf_offset
            dyn_flat = orig_flat_to_dynamic_flat.get(orig_flat)
            if dyn_flat is None:
                continue
            used_by: list[tuple[int, int]] = []
            for rank, cluster in enumerate(clusters):
                for pos, v in enumerate(cluster.invars):
                    if original_id_to_idx.get(id(v)) == dyn_flat:
                        used_by.append((rank, pos))
            if len(used_by) == 1:
                rank, pos = used_by[0]
                donate_per_stage[rank].add(pos)
    return [tuple(sorted(s)) for s in donate_per_stage]


def _build_schedule_plan(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    schedule: Schedule,
    mpmd_mesh: MpMdMesh,
    stage_shardings: list,
    rank_submeshes: list,
    static_argnums: tuple[int, ...] | None,
    donate_argnums: tuple[int, ...] | None = None,
) -> dict[str, Any]:
    """Build a dispatch plan for schedule-driven ``sxjit``."""
    n = mpmd_mesh.mpmd_dim
    v = schedule.virtual_stages_per_rank()
    n_logical = n * v
    m = schedule.microbatches

    if static_argnums is None:
        static_nums = set(range(len(args)))
    else:
        static_nums = set(_normalize_argnums(static_argnums, len(args)))
    dynamic_argnums = tuple(i for i in range(len(args)) if i not in static_nums)

    # Build wrapper so static args become consts and dynamic args become invars.
    placeholder_args = list(args)
    for i in dynamic_argnums:
        placeholder_args[i] = None
    placeholder_args = tuple(placeholder_args)

    def _wrapper(*dyn_args: Any) -> Any:
        full_args = list(placeholder_args)
        for idx, darg in zip(dynamic_argnums, dyn_args, strict=False):
            full_args[idx] = darg
        return fn(*full_args, **kwargs)

    # Trace with microbatch shapes so shape-dependent literals (e.g. mean
    # divisor) match the per-microbatch execution shapes.
    mb_dynamic_args = tuple(jax.tree.map(lambda a: _microbatch(a, m)[0], args[i]) for i in dynamic_argnums)
    closed_jaxpr = jax.make_jaxpr(_wrapper)(*mb_dynamic_args)

    clusters = cluster_jaxpr_by_markers(closed_jaxpr.jaxpr)
    if len(clusters) != n_logical:
        raise ValueError(
            f"sxjit schedule path: function has {len(clusters)} stages "
            f"({len(clusters) - 1} sxstage_iter markers) but mesh has "
            f"{n} ranks with V={v} virtual stages. Need exactly "
            f"{n_logical} stages ({n_logical - 1} markers)."
        )

    loc_for_logical, logical_for_loc, terminal_loc = _build_logical_locs(schedule, n, v)
    invar_sources = _build_invar_sources(closed_jaxpr.jaxpr, clusters)

    all_constvars = list(closed_jaxpr.jaxpr.constvars)
    concrete_consts = tuple(closed_jaxpr.consts)
    all_const_idx_by_id = {id(v): i for i, v in enumerate(all_constvars)}

    # Map global const index -> global flat arg index.
    flat_args = jax.tree.leaves(args)
    const_idx_to_flat_idx: dict[int, int] = {}
    for ci, cval in enumerate(concrete_consts):
        for fi, fval in enumerate(flat_args):
            if fval is cval:
                const_idx_to_flat_idx[ci] = fi
                break

    # Map body invar index -> global flat arg index for dynamic args.
    dynamic_flat_to_global_flat: dict[int, int] = {}
    global_ranges = _arg_leaf_ranges(args)
    dyn_local_idx = 0
    for arg_idx in dynamic_argnums:
        g_start, _g_end = global_ranges[arg_idx]
        local_leaves = jax.tree.leaves(args[arg_idx])
        for li, _leaf in enumerate(local_leaves):
            dynamic_flat_to_global_flat[dyn_local_idx] = g_start + li
            dyn_local_idx += 1

    # Compute per-cluster donated invar positions for forward JITs.
    donate_nums = set(_normalize_argnums(donate_argnums, len(args))) if donate_argnums is not None else set()
    donate_invars_per_logical: dict[int, set[int]] = {i: set() for i in range(n_logical)}
    if donate_nums:
        for donate_num in donate_nums:
            if donate_num in static_nums:
                raise ValueError(
                    f"sxjit: cannot donate static argument at index {donate_num}. "
                    "Static arguments are compile-time constants and cannot be donated."
                )
        start_end = global_ranges
        for donate_num in donate_nums:
            dstart, dend = start_end[donate_num]
            # Map each leaf of this arg to its body_invar index.
            for dyn_idx, global_idx in dynamic_flat_to_global_flat.items():
                if dstart <= global_idx < dend:
                    used_by: list[tuple[int, int]] = []
                    for logical, sources in enumerate(invar_sources):
                        for invar_pos, (kind, src_a, _src_b) in enumerate(sources):
                            if kind == "body_invar" and src_a == dyn_idx:
                                used_by.append((logical, invar_pos))
                    if len(used_by) == 1:
                        logical, invar_pos = used_by[0]
                        donate_invars_per_logical[logical].add(invar_pos)

    per_loc_consts: dict[tuple[int, int], tuple[Any, ...]] = {}
    const_indices_per_loc: dict[tuple[int, int], tuple[int, ...]] = {}
    n_invars_per_loc: dict[tuple[int, int], int] = {}
    fwd_jits: dict[tuple[int, int], Callable[..., Any]] = {}
    bwd_jits: dict[tuple[int, int], Callable[..., Any] | None] = {}
    terminal_jit: Callable[..., Any] | None = None

    for logical, cluster in enumerate(clusters):
        loc = loc_for_logical[logical]
        rank, _virt = loc
        used_constvars = _collect_used_constvars(cluster)
        filtered_cluster = _filtered_cluster(cluster, used_constvars)
        const_indices = tuple(all_const_idx_by_id[id(v)] for v in used_constvars)
        n_invars = len(cluster.invars)

        placed_consts = tuple(jax.device_put(concrete_consts[idx], stage_shardings[rank]) for idx in const_indices)

        per_loc_consts[loc] = placed_consts
        const_indices_per_loc[loc] = const_indices
        n_invars_per_loc[loc] = n_invars
        donate_positions = tuple(1 + pos for pos in sorted(donate_invars_per_logical[logical]))
        fwd_jits[loc] = _make_fwd_jit(filtered_cluster, donate_argnums=donate_positions)

        if loc != terminal_loc:
            bwd_jits[loc] = _make_bwd_jit(filtered_cluster, n_invars, donate_argnums=donate_positions)
        else:
            bwd_jits[loc] = None
            terminal_jit = _make_terminal_jit(filtered_cluster, n_invars, donate_argnums=donate_positions)

    assert terminal_jit is not None

    vbwd_jits: dict[tuple[int, int], Callable[..., Any]] = {}
    if schedule.lazy_bwd_batching:
        for logical, loc in enumerate(loc_for_logical):
            if loc == terminal_loc:
                continue
            n_invars = n_invars_per_loc[loc]
            n_outs = len(clusters[logical].outvars)
            bwd = bwd_jits[loc]
            vbwd = jax.jit(jax.vmap(bwd, in_axes=(None,) + (0,) * n_invars + (0,) * n_outs))
            vbwd_jits[loc] = vbwd

    grid = _build_schedule_grid(schedule, n)

    n_flat = len(flat_args)
    dynamic_mask = [False] * n_flat
    for argnum in dynamic_argnums:
        start, end = global_ranges[argnum]
        for i in range(start, end):
            dynamic_mask[i] = True

    return {
        "n": n,
        "v": v,
        "n_logical": n_logical,
        "m": m,
        "schedule": schedule,
        "loc_for_logical": loc_for_logical,
        "logical_for_loc": logical_for_loc,
        "terminal_loc": terminal_loc,
        "invar_sources": invar_sources,
        "per_loc_consts": per_loc_consts,
        "const_indices_per_loc": const_indices_per_loc,
        "n_invars_per_loc": n_invars_per_loc,
        "fwd_jits": fwd_jits,
        "bwd_jits": bwd_jits,
        "terminal_jit": terminal_jit,
        "vbwd_jits": vbwd_jits,
        "grid": grid,
        "stage_shardings": stage_shardings,
        "rank_submeshes": rank_submeshes,
        "dynamic_mask": dynamic_mask,
        "n_flat": n_flat,
        "flat_args": flat_args,
        "const_idx_to_flat_idx": const_idx_to_flat_idx,
        "dynamic_flat_to_global_flat": dynamic_flat_to_global_flat,
        "clusters": clusters,
    }


def _dispatch_gpipe_fwd(
    plan: dict[str, Any],
    args: tuple,
) -> tuple[jax.Array, dict[str, Any]]:
    """All-forward path for schedule-driven ``sxjit``.

    Splits dynamic args into microbatches, walks the logical pipeline
    forward one microbatch at a time, and returns the scalar loss plus
    saved activations.
    """
    m = plan["m"]
    n_logical = plan["n_logical"]
    loc_for_logical = plan["loc_for_logical"]
    invar_sources = plan["invar_sources"]
    fwd_jits = plan["fwd_jits"]
    terminal_jit = plan["terminal_jit"]
    terminal_loc = plan["terminal_loc"]
    rank_submeshes = plan["rank_submeshes"]
    stage_shardings = plan["stage_shardings"]
    per_loc_consts = plan["per_loc_consts"]
    dynamic_mask = plan["dynamic_mask"]
    dynamic_flat_to_global_flat = plan["dynamic_flat_to_global_flat"]
    flat_args = jax.tree.leaves(args)

    mb_args: list[Any] = []
    for i, arg in enumerate(flat_args):
        if dynamic_mask[i]:
            mb_args.append(_microbatch(arg, m))
        else:
            mb_args.append(arg)

    saved_inputs: dict[tuple[int, int, int], tuple[Any, ...]] = {}
    saved_outputs: dict[tuple[int, int, int], tuple[Any, ...]] = {}
    loss_acc = jnp.asarray(0.0)

    for mb in range(m):
        for logical in range(n_logical):
            loc = loc_for_logical[logical]
            rank, virt = loc
            consts = per_loc_consts[loc]
            submesh = rank_submeshes[rank]

            invars: list[Any] = []
            for source_kind, source_a, source_b in invar_sources[logical]:
                if source_kind == "body_invar":
                    flat_idx = dynamic_flat_to_global_flat[source_a]
                    val = mb_args[flat_idx]
                    if dynamic_mask[flat_idx]:
                        val = val[mb]
                    invars.append(val)
                elif source_kind == "cluster_out":
                    producer_loc = loc_for_logical[source_a]
                    val = saved_outputs[(producer_loc[0], producer_loc[1], mb)][source_b]
                    if producer_loc[0] != rank:
                        val = jax.device_put(val, stage_shardings[rank])
                    invars.append(val)

            with submesh:
                if loc == terminal_loc:
                    loss, _ = terminal_jit(consts, *invars)
                    loss_acc = loss_acc + loss
                else:
                    out = fwd_jits[loc](consts, *invars)

            saved_inputs[(rank, virt, mb)] = tuple(invars)
            if loc != terminal_loc:
                saved_outputs[(rank, virt, mb)] = out

    mean_loss = loss_acc / jnp.asarray(m, dtype=loss_acc.dtype)
    return mean_loss, {"saved_inputs": saved_inputs, "saved_outputs": saved_outputs}


def _dispatch_gpipe_bwd(
    plan: dict[str, Any],
    saved: dict[str, Any],
    g: Any,
) -> tuple[Any, ...]:
    """All-backward path for custom_vjp.

    Uses saved activations from ``_dispatch_gpipe_fwd``, walks backward
    stages, and computes gradients for all argnums.
    """
    m = plan["m"]
    n_logical = plan["n_logical"]
    loc_for_logical = plan["loc_for_logical"]
    invar_sources = plan["invar_sources"]
    bwd_jits = plan["bwd_jits"]
    terminal_jit = plan["terminal_jit"]
    terminal_loc = plan["terminal_loc"]
    rank_submeshes = plan["rank_submeshes"]
    stage_shardings = plan["stage_shardings"]
    per_loc_consts = plan["per_loc_consts"]
    dynamic_mask = plan["dynamic_mask"]
    const_idx_to_flat_idx = plan["const_idx_to_flat_idx"]
    dynamic_flat_to_global_flat = plan["dynamic_flat_to_global_flat"]
    n_flat = plan["n_flat"]
    flat_args = plan["flat_args"]

    saved_inputs = saved["saved_inputs"]
    saved_outputs = saved["saved_outputs"]

    grad_accums: dict[int, Any] = {}
    recv_cots: dict[tuple[int, int, int], list[Any | None]] = {}

    for mb in range(m):
        for logical in reversed(range(n_logical)):
            loc = loc_for_logical[logical]
            rank, virt = loc
            consts = per_loc_consts[loc]
            submesh = rank_submeshes[rank]
            key = (rank, virt, mb)
            invars = saved_inputs[key]

            with submesh:
                if loc == terminal_loc:
                    _, (g_consts, g_invars) = terminal_jit(consts, *invars)
                    if g is not None:
                        scale = g / jnp.asarray(m, dtype=jnp.float32)
                        g_consts = jax.tree.map(lambda x, s=scale: x * s, g_consts, is_leaf=_is_leaf)
                        g_invars = tuple(x * scale for x in g_invars)
                else:
                    cotangents = _materialize_cotangents(
                        recv_cots.get(key),
                        saved_outputs[key],
                    )
                    g_consts, g_invars = bwd_jits[loc](consts, *invars, *cotangents)

            # Accumulate const grads for static args
            for local_idx, const_idx in enumerate(plan["const_indices_per_loc"][loc]):
                flat_idx = const_idx_to_flat_idx.get(const_idx)
                if flat_idx is None:
                    continue
                grad = g_consts[local_idx]
                if flat_idx not in grad_accums:
                    grad_accums[flat_idx] = grad
                else:
                    grad_accums[flat_idx] = grad_accums[flat_idx] + grad

            # Accumulate invar grads for dynamic args
            for invar_idx, (source_kind, source_a, _source_b) in enumerate(invar_sources[logical]):
                if source_kind != "body_invar":
                    continue
                flat_idx = dynamic_flat_to_global_flat.get(source_a)
                if flat_idx is None:
                    continue
                grad = g_invars[invar_idx]
                if dynamic_mask[flat_idx]:
                    if flat_idx not in grad_accums:
                        grad_accums[flat_idx] = [None] * m
                    grad_accums[flat_idx][mb] = grad
                else:
                    if flat_idx not in grad_accums:
                        grad_accums[flat_idx] = grad
                    else:
                        grad_accums[flat_idx] = grad_accums[flat_idx] + grad

            # Scatter cotangents to previous stages
            if logical > 0:
                for invar_idx, (source_kind, source_a, source_b) in enumerate(invar_sources[logical]):
                    if source_kind != "cluster_out":
                        continue
                    producer_logical = source_a
                    producer_out_idx = source_b
                    producer_loc = loc_for_logical[producer_logical]
                    p_key = (producer_loc[0], producer_loc[1], mb)
                    cot = g_invars[invar_idx]
                    if producer_loc[0] != rank:
                        cot = jax.device_put(cot, stage_shardings[producer_loc[0]])
                    slots = recv_cots.setdefault(
                        p_key,
                        [None] * len(saved_outputs[p_key]),
                    )
                    if slots[producer_out_idx] is None:
                        slots[producer_out_idx] = cot
                    else:
                        slots[producer_out_idx] = slots[producer_out_idx] + cot

    final_grads: list[Any] = []
    for i in range(n_flat):
        if i in grad_accums:
            grad = grad_accums[i]
            if dynamic_mask[i]:
                if isinstance(grad, list):
                    template = next(g for g in grad if g is not None)
                    for mb in range(m):
                        if grad[mb] is None:
                            grad[mb] = jnp.zeros_like(template)
                    final_grads.append(jnp.concatenate(grad, axis=0))
                else:
                    final_grads.append(grad)
            else:
                final_grads.append(grad)
        else:
            final_grads.append(jnp.zeros_like(flat_args[i]))

    return tuple(final_grads)


def _dispatch_schedule_faithful(
    plan: dict[str, Any],
    args: tuple,
    return_loss: bool = False,
) -> tuple[jax.Array | None, tuple[Any, ...]]:
    """Schedule-faithful forward+backward grid walker.

    Walks ``plan.grid`` step by step, executes FWD and BWD actions in
    schedule order, accumulates gradients, and returns ``(loss, grads_flat)``.
    """
    m = plan["m"]
    n_logical = plan["n_logical"]
    grid = plan["grid"]
    loc_for_logical = plan["loc_for_logical"]
    logical_for_loc = plan["logical_for_loc"]
    invar_sources = plan["invar_sources"]
    fwd_jits = plan["fwd_jits"]
    bwd_jits = plan["bwd_jits"]
    terminal_jit = plan["terminal_jit"]
    terminal_loc = plan["terminal_loc"]
    rank_submeshes = plan["rank_submeshes"]
    stage_shardings = plan["stage_shardings"]
    per_loc_consts = plan["per_loc_consts"]
    dynamic_mask = plan["dynamic_mask"]
    const_idx_to_flat_idx = plan["const_idx_to_flat_idx"]
    dynamic_flat_to_global_flat = plan["dynamic_flat_to_global_flat"]
    n_flat = plan["n_flat"]
    flat_args = plan["flat_args"]
    lazy_bwd_batching = plan["schedule"].lazy_bwd_batching

    flat_args_live = jax.tree.leaves(args)
    mb_args: list[Any] = []
    for i, arg in enumerate(flat_args_live):
        if dynamic_mask[i]:
            mb_args.append(_microbatch(arg, m))
        else:
            mb_args.append(arg)

    saved_inputs: dict[tuple[int, int, int], tuple[Any, ...]] = {}
    saved_outputs: dict[tuple[int, int, int], tuple[Any, ...]] = {}
    recv_cots: dict[tuple[int, int, int], list[Any | None]] = {}
    grad_accums: dict[int, Any] = {}
    loss_acc = jnp.asarray(0.0)
    lazy_bwd_actions: dict[tuple[int, int], list[tuple[Any, int]]] = {}

    for row in grid:
        for rank, virt, action in _iter_actions(row):
            mb = action.microbatch
            phase = action.phase
            loc = (rank, virt)
            logical = logical_for_loc[loc]
            submesh = rank_submeshes[rank]
            key = (rank, virt, mb)
            consts = per_loc_consts[loc]

            if phase is Phase.FWD:
                invars: list[Any] = []
                for source_kind, source_a, source_b in invar_sources[logical]:
                    if source_kind == "body_invar":
                        flat_idx = dynamic_flat_to_global_flat[source_a]
                        val = mb_args[flat_idx]
                        if dynamic_mask[flat_idx]:
                            val = val[mb]
                        invars.append(val)
                    elif source_kind == "cluster_out":
                        producer_loc = loc_for_logical[source_a]
                        val = saved_outputs[(producer_loc[0], producer_loc[1], mb)][source_b]
                        if producer_loc[0] != rank:
                            val = jax.device_put(val, stage_shardings[rank])
                        invars.append(val)

                with submesh:
                    if loc == terminal_loc:
                        loss, _ = terminal_jit(consts, *invars)
                        loss_acc = loss_acc + loss
                    else:
                        out = fwd_jits[loc](consts, *invars)

                saved_inputs[key] = tuple(invars)
                if loc != terminal_loc:
                    saved_outputs[key] = out

            elif phase in (Phase.BWD, Phase.BWD_I, Phase.BWD_W):
                if lazy_bwd_batching:
                    lazy_bwd_actions.setdefault(loc, []).append((action, mb))
                    continue

                invars = saved_inputs[key]

                with submesh:
                    if loc == terminal_loc:
                        _, (g_consts, g_invars) = terminal_jit(consts, *invars)
                        scale = 1.0 / jnp.asarray(m, dtype=jnp.float32)
                        g_consts = jax.tree.map(lambda x, s=scale: x * s, g_consts, is_leaf=_is_leaf)
                        g_invars = tuple(x * scale for x in g_invars)
                    else:
                        cotangents = _materialize_cotangents(
                            recv_cots.get(key),
                            saved_outputs[key],
                        )
                        g_consts, g_invars = bwd_jits[loc](consts, *invars, *cotangents)

                if phase is not Phase.BWD_I:
                    for local_idx, const_idx in enumerate(plan["const_indices_per_loc"][loc]):
                        flat_idx = const_idx_to_flat_idx.get(const_idx)
                        if flat_idx is None:
                            continue
                        grad = g_consts[local_idx]
                        if flat_idx not in grad_accums:
                            grad_accums[flat_idx] = grad
                        else:
                            grad_accums[flat_idx] = grad_accums[flat_idx] + grad

                if phase is not Phase.BWD_W:
                    for invar_idx, (source_kind, source_a, _source_b) in enumerate(invar_sources[logical]):
                        if source_kind != "body_invar":
                            continue
                        flat_idx = dynamic_flat_to_global_flat.get(source_a)
                        if flat_idx is None:
                            continue
                        grad = g_invars[invar_idx]
                        if dynamic_mask[flat_idx]:
                            if flat_idx not in grad_accums:
                                grad_accums[flat_idx] = [None] * m
                            grad_accums[flat_idx][mb] = grad
                        else:
                            if flat_idx not in grad_accums:
                                grad_accums[flat_idx] = grad
                            else:
                                grad_accums[flat_idx] = grad_accums[flat_idx] + grad

                if phase is not Phase.BWD_W:
                    for invar_idx, (source_kind, source_a, _source_b) in enumerate(invar_sources[logical]):
                        if source_kind != "cluster_out":
                            continue
                        producer_logical = source_a
                        producer_out_idx = source_b
                        producer_loc = loc_for_logical[producer_logical]
                        p_key = (producer_loc[0], producer_loc[1], mb)
                        cot = g_invars[invar_idx]
                        if producer_loc[0] != rank:
                            cot = jax.device_put(cot, stage_shardings[producer_loc[0]])
                        slots = recv_cots.setdefault(
                            p_key,
                            [None] * len(saved_outputs[p_key]),
                        )
                        if slots[producer_out_idx] is None:
                            slots[producer_out_idx] = cot
                        else:
                            slots[producer_out_idx] = slots[producer_out_idx] + cot

    if lazy_bwd_batching:
        vbwd_jits = plan.get("vbwd_jits", {})
        for logical in reversed(range(n_logical)):
            loc = loc_for_logical[logical]
            rank = loc[0]
            actions = lazy_bwd_actions.get(loc, [])
            if not actions:
                continue
            actions.sort(key=lambda x: x[1])
            mbs = [mb for _, mb in actions]
            submesh = rank_submeshes[rank]
            consts = per_loc_consts[loc]

            if loc == terminal_loc:
                scale = 1.0 / jnp.asarray(m, dtype=jnp.float32)
                for mb in mbs:
                    key = (rank, loc[1], mb)
                    invars = saved_inputs[key]
                    with submesh:
                        _, (g_consts, g_invars) = terminal_jit(consts, *invars)
                        g_consts = jax.tree.map(lambda x, s=scale: x * s, g_consts, is_leaf=_is_leaf)
                        g_invars = tuple(x * scale for x in g_invars)
                    for local_idx, const_idx in enumerate(plan["const_indices_per_loc"][loc]):
                        flat_idx = const_idx_to_flat_idx.get(const_idx)
                        if flat_idx is None:
                            continue
                        grad = g_consts[local_idx]
                        if flat_idx not in grad_accums:
                            grad_accums[flat_idx] = grad
                        else:
                            grad_accums[flat_idx] = grad_accums[flat_idx] + grad
                    for invar_idx, (source_kind, source_a, _source_b) in enumerate(invar_sources[logical]):
                        if source_kind != "body_invar":
                            continue
                        flat_idx = dynamic_flat_to_global_flat.get(source_a)
                        if flat_idx is None:
                            continue
                        grad = g_invars[invar_idx]
                        if dynamic_mask[flat_idx]:
                            if flat_idx not in grad_accums:
                                grad_accums[flat_idx] = [None] * m
                            grad_accums[flat_idx][mb] = grad
                        else:
                            if flat_idx not in grad_accums:
                                grad_accums[flat_idx] = grad
                            else:
                                grad_accums[flat_idx] = grad_accums[flat_idx] + grad
                    for invar_idx, (source_kind, source_a, source_b) in enumerate(invar_sources[logical]):
                        if source_kind != "cluster_out":
                            continue
                        producer_logical = source_a
                        producer_out_idx = source_b
                        producer_loc = loc_for_logical[producer_logical]
                        p_key = (producer_loc[0], producer_loc[1], mb)
                        cot = g_invars[invar_idx]
                        if producer_loc[0] != rank:
                            cot = jax.device_put(cot, stage_shardings[producer_loc[0]])
                        slots = recv_cots.setdefault(
                            p_key,
                            [None] * len(saved_outputs[p_key]),
                        )
                        if slots[producer_out_idx] is None:
                            slots[producer_out_idx] = cot
                        else:
                            slots[producer_out_idx] = slots[producer_out_idx] + cot
            else:
                invars_stack = []
                for invar_idx in range(len(invar_sources[logical])):
                    stacked = jnp.stack(
                        [saved_inputs[(rank, loc[1], mb)][invar_idx] for mb in mbs],
                        axis=0,
                    )
                    invars_stack.append(stacked)

                n_outs = len(saved_outputs[(rank, loc[1], mbs[0])])
                cots_stack = []
                for out_idx in range(n_outs):
                    cots_mb = []
                    for mb in mbs:
                        key = (rank, loc[1], mb)
                        slots = recv_cots.get(key, [None] * n_outs)
                        cot = slots[out_idx]
                        if cot is None:
                            cot = jnp.zeros_like(saved_outputs[key][out_idx])
                        cots_mb.append(cot)
                    cots_stack.append(jnp.stack(cots_mb, axis=0))

                with submesh:
                    g_consts, g_invars = vbwd_jits[loc](consts, *invars_stack, *cots_stack)

                for local_idx, const_idx in enumerate(plan["const_indices_per_loc"][loc]):
                    flat_idx = const_idx_to_flat_idx.get(const_idx)
                    if flat_idx is None:
                        continue
                    grad = g_consts[local_idx].sum(axis=0)
                    if flat_idx not in grad_accums:
                        grad_accums[flat_idx] = grad
                    else:
                        grad_accums[flat_idx] = grad_accums[flat_idx] + grad

                for invar_idx, (source_kind, source_a, _source_b) in enumerate(invar_sources[logical]):
                    if source_kind != "body_invar":
                        continue
                    flat_idx = dynamic_flat_to_global_flat.get(source_a)
                    if flat_idx is None:
                        continue
                    grad = g_invars[invar_idx]
                    if dynamic_mask[flat_idx]:
                        if flat_idx not in grad_accums:
                            grad_accums[flat_idx] = [None] * m
                        for idx, mb in enumerate(mbs):
                            grad_accums[flat_idx][mb] = grad[idx]
                    else:
                        summed_grad = grad.sum(axis=0)
                        if flat_idx not in grad_accums:
                            grad_accums[flat_idx] = summed_grad
                        else:
                            grad_accums[flat_idx] = grad_accums[flat_idx] + summed_grad

                for invar_idx, (source_kind, source_a, source_b) in enumerate(invar_sources[logical]):
                    if source_kind != "cluster_out":
                        continue
                    producer_logical = source_a
                    producer_out_idx = source_b
                    producer_loc = loc_for_logical[producer_logical]
                    for idx, mb in enumerate(mbs):
                        p_key = (producer_loc[0], producer_loc[1], mb)
                        cot = g_invars[invar_idx][idx]
                        if producer_loc[0] != rank:
                            cot = jax.device_put(cot, stage_shardings[producer_loc[0]])
                        slots = recv_cots.setdefault(
                            p_key,
                            [None] * len(saved_outputs[p_key]),
                        )
                        if slots[producer_out_idx] is None:
                            slots[producer_out_idx] = cot
                        else:
                            slots[producer_out_idx] = slots[producer_out_idx] + cot

    final_grads: list[Any] = []
    for i in range(n_flat):
        if i in grad_accums:
            grad = grad_accums[i]
            if dynamic_mask[i]:
                if isinstance(grad, list):
                    template = next(g for g in grad if g is not None)
                    for mb in range(m):
                        if grad[mb] is None:
                            grad[mb] = jnp.zeros_like(template)
                    final_grads.append(jnp.concatenate(grad, axis=0))
                else:
                    final_grads.append(grad)
            else:
                final_grads.append(grad)
        else:
            final_grads.append(jnp.zeros_like(flat_args[i]))

    mean_loss = loss_acc / jnp.asarray(m, dtype=loss_acc.dtype)
    return (mean_loss if return_loss else None), tuple(final_grads)


@functools.partial(jax.custom_vjp, nondiff_argnums=(0,))
def _schedule_forward(plan: dict[str, Any], *args: Any) -> jax.Array:
    """Forward-only dispatch for schedule-driven ``sxjit``."""
    loss, _ = _dispatch_gpipe_fwd(plan, args)
    return loss


def _schedule_forward_fwd(plan: dict[str, Any], *args: Any) -> tuple[jax.Array, dict[str, Any]]:
    """Forward pass returning loss and saved activations."""
    loss, saved = _dispatch_gpipe_fwd(plan, args)
    return loss, saved


def _schedule_forward_bwd(plan: dict[str, Any], saved: dict[str, Any], g: Any) -> tuple[Any, ...]:
    """Backward pass using saved activations."""
    grads = _dispatch_gpipe_bwd(plan, saved, g)
    return grads


_schedule_forward.defvjp(_schedule_forward_fwd, _schedule_forward_bwd)


def sxgrad(fn: Callable, argnums: int | tuple[int, ...] = 0) -> Callable:
    """Schedule-faithful gradient of a schedule-driven ``sxjit`` function.

    Args:
        fn: A function decorated with ``@sxjit(..., schedule=...)``.
        argnums: Positional argument indices to differentiate w.r.t.

    Returns:
        A callable with the same signature as ``fn`` that returns a tuple
        of gradients for the requested ``argnums``.
    """
    if not hasattr(fn, "_mpmd_state"):
        raise TypeError("sxgrad requires an sxjit-decorated function with a schedule.")
    plan = fn._mpmd_state.get("schedule_plan")
    if plan is None:
        raise TypeError("sxgrad requires the function to be jit-compiled with a schedule.")

    if isinstance(argnums, int):
        argnums = (argnums,)
    else:
        argnums = tuple(argnums)

    def grad_fn(*args: Any) -> tuple[Any, ...]:
        _loss, grads_flat = _dispatch_schedule_faithful(plan, args, return_loss=False)
        leaf_ranges = _arg_leaf_ranges(args)
        result = []
        for argnum in argnums:
            start, end = leaf_ranges[argnum]
            arg_leaves = grads_flat[start:end]
            if len(arg_leaves) == 1:
                result.append(arg_leaves[0])
            else:
                arg_grad = jax.tree.unflatten(jax.tree.structure(args[argnum]), list(arg_leaves))
                result.append(arg_grad)
        return tuple(result)

    return grad_fn


def sxvalue_and_grad(fn: Callable, argnums: int | tuple[int, ...] = 0) -> Callable:
    """Schedule-faithful ``value_and_grad`` of a schedule-driven ``sxjit`` function.

    Args:
        fn: A function decorated with ``@sxjit(..., schedule=...)``.
        argnums: Positional argument indices to differentiate w.r.t.

    Returns:
        A callable with the same signature as ``fn`` that returns
        ``(loss, grads_tuple)``.
    """
    if not hasattr(fn, "_mpmd_state"):
        raise TypeError("sxvalue_and_grad requires an sxjit-decorated function with a schedule.")
    plan = fn._mpmd_state.get("schedule_plan")
    if plan is None:
        raise TypeError("sxvalue_and_grad requires the function to be jit-compiled with a schedule.")

    if isinstance(argnums, int):
        argnums = (argnums,)
    else:
        argnums = tuple(argnums)

    def vg_fn(*args: Any) -> tuple[jax.Array, tuple[Any, ...]]:
        loss, grads_flat = _dispatch_schedule_faithful(plan, args, return_loss=True)
        leaf_ranges = _arg_leaf_ranges(args)
        result = []
        for argnum in argnums:
            start, end = leaf_ranges[argnum]
            arg_leaves = grads_flat[start:end]
            if len(arg_leaves) == 1:
                result.append(arg_leaves[0])
            else:
                arg_grad = jax.tree.unflatten(jax.tree.structure(args[argnum]), list(arg_leaves))
                result.append(arg_grad)
        return loss, tuple(result)

    return vg_fn


def sxjit(
    fn: Callable | None = None,
    *,
    mesh: "SpxMesh | MpMdMesh",
    schedule: Schedule | None = None,
    static_argnums: int | tuple[int, ...] | None = None,
    static_argnames: str | tuple[str, ...] | None = None,
    donate_argnums: int | tuple[int, ...] | None = None,
    in_shardings: Any | None = None,
    out_shardings: Any | None = None,
) -> Callable:
    """Decorator that traces a function, splits it at :func:`sxstage_iter`
    markers, and compiles each stage into a separate XLA executable per rank.

    True MPMD: rank 0 compiles only stage 0's ops, rank N-1 compiles only
    stage N-1. No ``lax.cond``, no ``shard_map``, no shared HLO.

    The decorated function must call :func:`sxstage_iter` to mark
    stage boundaries. For an N-rank mesh, use exactly N-1 markers::

        @sxjit(mesh=mesh)
        def forward(model, x):
            x = model.embed(x)
            for blk in model.blocks[:16]:
                x = blk(x)
            x = sxstage_iter(x)
            for blk in model.blocks[16:]:
                x = blk(x)
            return model.head(x)

        logits = forward(model, token_ids)

    On the first call the decorator traces ``fn`` via :func:`jax.make_jaxpr`,
    splits the jaxpr at the markers via :func:`cluster_jaxpr_by_markers`,
    builds a ``@jax.jit`` per cluster on its rank's sub-mesh, and places
    model parameters. Subsequent calls reuse the compiled executables and
    placed parameters, dispatching only the per-rank jits with
    :func:`jax.device_put` for cross-rank activation transfer.

    Return values may originate from any stage. The outvar map tracks
    which cluster produced each return value so that per-rank carry state
    (e.g. KV cache pages) is returned from the correct rank with its
    device placement preserved.

    Args:
        fn: The function to pipeline.
        mesh: An MPMD-capable mesh (:class:`SpxMesh` or :class:`MpMdMesh`).
        schedule: Optional :class:`Schedule` for schedule-driven training
            with ``jax.grad`` support. When provided, the function must
            return a scalar loss and ``sxgrad`` / ``sxvalue_and_grad``
            can be used for faithful schedule-aware backprop.
        static_argnums: Which positional arguments are static (compile-time
            constants). Static args are traced as constants and their values
            are embedded in the compiled XLA. This is useful for configuration
            objects, boolean flags, or small non-array data. When not provided,
            the legacy auto-inference is used (all but the last arg are static).
            Required when ``schedule`` is provided to distinguish model
            parameters from data inputs.
        static_argnames: Which keyword arguments are static (compile-time
            constants). Behaves like ``static_argnums`` but for kwargs.
        donate_argnums: Which positional arguments should have their device
            buffers donated to the computation. This can reduce memory usage
            for large inputs that are only used by a single pipeline stage.
            An argument used by multiple stages cannot be donated safely and
            will be silently skipped.
        in_shardings: Per-leaf input shardings as a pytree matching ``fn``'s
            args. ``None`` entries fall through to auto-inference from
            :class:`Module` logical axis annotations. If the entire argument
            is ``None``, all shardings are inferred automatically. Arrays
            already on the correct rank's devices are never moved.
        out_shardings: Sharding applied to all outputs after dispatch.
            Can be a single :class:`~jax.sharding.Sharding` (applied to
            every output), a list/tuple of shardings (one per output, with
            ``None`` meaning "preserve"), or ``None`` (preserve whatever
            sharding each output has from its producing rank).

    Returns:
        A wrapped callable with the same signature as ``fn``.
    """
    mpmd_mesh = resolve_mpmd_mesh(mesh)

    def decorator(fn: Callable) -> Callable:
        """Build the per-rank dispatch plan on first call, replay on subsequent calls."""
        n = mpmd_mesh.mpmd_dim
        stage_shardings = [mpmd_mesh.sub_sharding(i) for i in range(n)]
        rank_submeshes = [mpmd_mesh.submesh(i) for i in range(n)]
        _state: dict[str, Any] = {}

        def _build(args, kwargs):
            """Trace ``fn``, cluster by markers, compile per-rank jits, place params.

            Called exactly once on the first invocation. Populates
            ``_state`` with the compiled dispatch plan, placed static
            parameters, dynamic-index set, explicit sharding overrides,
            and the output variable map.

            Three code paths branch off the traced jaxpr:
            * If a ``pscan_p`` equation is present (user called
              :func:`treduce`), route through :mod:`pscan_compiler`.
            * If ``schedule`` is provided, build a schedule-driven plan.
            * Otherwise fall through to the forward-only marker-cluster path.
            """
            static_nums = set(_normalize_argnums(static_argnums, len(args)))
            donate_nums = set(_normalize_argnums(donate_argnums, len(args)))
            static_names = _normalize_argnames(static_argnames)

            use_legacy_path = static_argnums is None and static_argnames is None and donate_argnums is None

            if use_legacy_path:
                closed_jaxpr = jax.make_jaxpr(fn)(*args, **kwargs)
                dynamic_flat_to_orig_flat = None
                orig_flat_to_dynamic_flat = None
                constvar_id_to_idx = None
            else:
                if static_nums and donate_nums and static_nums & donate_nums:
                    overlap = sorted(static_nums & donate_nums)
                    raise ValueError(f"sxjit: arguments at indices {overlap} cannot be both static and donated.")

                static_kwargs = {k: kwargs[k] for k in static_names if k in kwargs}
                dynamic_kwargs = {k: v for k, v in kwargs.items() if k not in static_names}
                dynamic_nums = tuple(i for i in range(len(args)) if i not in static_nums)

                placeholder_args = list(args)
                for i in dynamic_nums:
                    placeholder_args[i] = None

                def _wrapper(*dyn_args, **dyn_kwargs):
                    full_args = list(placeholder_args)
                    for idx, darg in zip(dynamic_nums, dyn_args, strict=False):
                        full_args[idx] = darg
                    return fn(*full_args, **static_kwargs, **dyn_kwargs)

                dynamic_args = tuple(args[i] for i in dynamic_nums)
                closed_jaxpr = jax.make_jaxpr(_wrapper)(*dynamic_args, **dynamic_kwargs)

                dynamic_flat_to_orig_flat: dict[int, int] = {}
                orig_flat_to_dynamic_flat: dict[int, int] = {}
                dyn_flat_idx = 0
                orig_flat_idx = 0
                for i, arg in enumerate(args):
                    n_leaves = len(jax.tree.leaves(arg))
                    if i not in static_nums:
                        for j in range(n_leaves):
                            dynamic_flat_to_orig_flat[dyn_flat_idx + j] = orig_flat_idx + j
                            orig_flat_to_dynamic_flat[orig_flat_idx + j] = dyn_flat_idx + j
                        dyn_flat_idx += n_leaves
                    orig_flat_idx += n_leaves
                for _k, v in dynamic_kwargs.items():
                    n_leaves = len(jax.tree.leaves(v))
                    for j in range(n_leaves):
                        dynamic_flat_to_orig_flat[dyn_flat_idx + j] = orig_flat_idx + j
                        orig_flat_to_dynamic_flat[orig_flat_idx + j] = dyn_flat_idx + j
                    dyn_flat_idx += n_leaves
                    orig_flat_idx += n_leaves

                constvar_id_to_idx = {id(v): i for i, v in enumerate(closed_jaxpr.jaxpr.constvars)}

            pscan_eqns = has_pscan(closed_jaxpr.jaxpr)
            if pscan_eqns:
                if not use_legacy_path:
                    raise NotImplementedError(
                        "sxjit: static_argnums / donate_argnums are not yet supported with pscan paths."
                    )
                if len(pscan_eqns) > 1:
                    raise NotImplementedError(
                        "sxjit supports at most one pscan_p equation (treduce call) per decorated function in the MVP."
                    )
                outer_flat_args = tuple(jax.tree.leaves(args))
                plan = build_pscan_plan(
                    closed_jaxpr,
                    args,
                    outer_flat_args,
                    pscan_eqns[0],
                    mpmd_mesh,
                    stage_shardings,
                    rank_submeshes,
                )
                _state["pscan_plan"] = plan
                return

            if schedule is not None:
                plan = _build_schedule_plan(
                    fn,
                    args,
                    kwargs,
                    schedule,
                    mpmd_mesh,
                    stage_shardings,
                    rank_submeshes,
                    static_argnums,
                    donate_argnums,
                )
                _state["schedule_plan"] = plan
                return

            clusters = cluster_jaxpr_by_markers(closed_jaxpr.jaxpr)
            consts = closed_jaxpr.consts

            if len(clusters) != n:
                raise ValueError(
                    f"sxjit: function has {len(clusters)} stages "
                    f"({len(clusters) - 1} sxstage_iter markers) "
                    f"but mesh has {n} MPMD ranks. Need exactly "
                    f"{n - 1} markers."
                )

            original_id_to_idx = {id(v): i for i, v in enumerate(closed_jaxpr.jaxpr.invars)}

            fn_outvar_map = _build_outvar_map(
                closed_jaxpr,
                clusters,
                original_id_to_idx,
                constvar_id_to_idx=constvar_id_to_idx,
                consts=consts,
            )

            donate_per_stage = None
            if not use_legacy_path and donate_nums:
                donate_per_stage = _compute_donation(
                    clusters,
                    original_id_to_idx,
                    orig_flat_to_dynamic_flat,
                    args,
                    donate_nums,
                    static_nums,
                    n,
                )

            cluster_plans = _build_cluster_plans(
                clusters,
                consts,
                stage_shardings,
                rank_submeshes,
                original_id_to_idx,
                n,
                donate_argnums_per_stage=donate_per_stage,
                all_constvars=list(closed_jaxpr.jaxpr.constvars) if not use_legacy_path else None,
            )

            flat_init = jax.tree.leaves(args)
            if use_legacy_path:
                n_model_leaves = len(jax.tree.leaves(args[:-1]))
                dynamic = set(range(n_model_leaves, len(flat_init)))
            else:
                static_flat = set()
                for i in static_nums:
                    start = sum(len(jax.tree.leaves(args[j])) for j in range(i))
                    n_leaves = len(jax.tree.leaves(args[i]))
                    static_flat.update(range(start, start + n_leaves))
                dynamic = set(range(len(flat_init))) - static_flat

            leaf_shardings, leaf_stage_owners = _infer_leaf_shardings(
                args,
                flat_init,
                n,
                rank_submeshes,
            )

            explicit_in_sh = _resolve_explicit_shardings(in_shardings, flat_init)

            placed = _place_static_args(
                cluster_plans,
                flat_init,
                dynamic,
                explicit_in_sh,
                leaf_shardings,
                leaf_stage_owners,
                rank_submeshes,
            )

            _state["compiled"] = cluster_plans
            _state["placed"] = placed
            _state["dynamic"] = dynamic
            _state["explicit_in_sh"] = explicit_in_sh
            _state["fn_outvar_map"] = fn_outvar_map
            if not use_legacy_path:
                _state["dynamic_flat_to_orig_flat"] = dynamic_flat_to_orig_flat

        def _dispatch(args):
            """Fire per-rank executables with pre-placed params and fresh dynamic inputs.

            Static args (model params) use the cached placement from
            ``_build``. Dynamic args (user inputs) and inter-stage
            activations are placed per-call. Arrays already on the
            correct rank's devices pass through without ``device_put``.

            If a ``pscan_plan`` is present (schedule-driven training
            path), delegate to the schedule-aware dispatcher in
            :mod:`pscan_compiler`. Otherwise run the forward-only
            marker-cluster path.
            """
            if "pscan_plan" in _state:
                results = dispatch_pscan(_state["pscan_plan"])
                if len(results) == 1:
                    return results[0]
                return tuple(results)

            compiled = _state["compiled"]
            placed = _state["placed"]
            dynamic = _state["dynamic"]
            explicit_in_sh = _state["explicit_in_sh"]
            flat_args = jax.tree.leaves(args)
            all_cluster_outputs: list[tuple] = []
            prev_outputs: tuple = ()

            for ri, (stage_jit, submesh, my_sh, _, invar_map) in enumerate(compiled):
                rank_devices = set(rank_submeshes[ri].devices.flat)
                invars = _assemble_invars(
                    invar_map,
                    flat_args,
                    placed,
                    dynamic,
                    explicit_in_sh,
                    prev_outputs,
                    ri,
                    my_sh,
                    rank_devices,
                    dynamic_flat_to_orig_flat=_state.get("dynamic_flat_to_orig_flat"),
                )
                with submesh:
                    prev_outputs = stage_jit(*invars)
                all_cluster_outputs.append(prev_outputs)

            return _assemble_outputs(
                _state["fn_outvar_map"],
                all_cluster_outputs,
                flat_args,
            )

        def wrapped(*args, **kwargs):
            """Trace on first call, dispatch on every call."""
            if "compiled" not in _state and "schedule_plan" not in _state and "pscan_plan" not in _state:
                _build(args, kwargs)

            if "schedule_plan" in _state:
                plan = _state["schedule_plan"]
                return _schedule_forward(plan, *args)

            if "pscan_plan" in _state:
                results = dispatch_pscan(_state["pscan_plan"])
                if len(results) == 1:
                    return results[0]
                return tuple(results)

            result = _dispatch(args)
            return _apply_out_shardings(result, out_shardings)

        wrapped.__name__ = getattr(fn, "__name__", "mpmd_jit_fn")
        wrapped.__qualname__ = getattr(fn, "__qualname__", "mpmd_jit_fn")
        wrapped._mpmd_state = _state
        return wrapped

    if fn is not None:
        return decorator(fn)
    return decorator


def _build_outvar_map(
    closed_jaxpr: Any,
    clusters: list,
    original_id_to_idx: dict[int, int],
    constvar_id_to_idx: dict[int, int] | None = None,
    consts: tuple[Any, ...] | None = None,
) -> list[tuple]:
    """Map each of the original function's output vars to the cluster that defines it.

    Returns a list parallel to ``closed_jaxpr.jaxpr.outvars``. Each entry
    is ``(cluster_rank, position_in_cluster_outvars)`` for values produced
    by a cluster, ``("orig_passthrough", flat_arg_index)`` for values
    that are original function inputs passed through unchanged, or
    ``("const_passthrough", concrete_value)`` for static constants.
    """
    cluster_outvar_ids: list[dict[int, int]] = [{id(v): pos for pos, v in enumerate(c.outvars)} for c in clusters]
    fn_outvar_map: list[tuple] = []
    for v in closed_jaxpr.jaxpr.outvars:
        vid = id(v)
        found = None
        for ri in range(len(clusters) - 1, -1, -1):
            if vid in cluster_outvar_ids[ri]:
                found = (ri, cluster_outvar_ids[ri][vid])
                break
        if found is not None:
            fn_outvar_map.append(found)
        else:
            orig_idx = original_id_to_idx.get(vid)
            if orig_idx is not None:
                fn_outvar_map.append(("orig_passthrough", orig_idx))
            elif constvar_id_to_idx is not None:
                const_idx = constvar_id_to_idx.get(vid)
                if const_idx is not None and consts is not None:
                    fn_outvar_map.append(("const_passthrough", consts[const_idx]))
                else:
                    fn_outvar_map.append(("missing", -1))
            else:
                fn_outvar_map.append(("missing", -1))
    return fn_outvar_map


def _build_cluster_plans(
    clusters: list,
    consts: tuple,
    stage_shardings: list,
    rank_submeshes: list,
    original_id_to_idx: dict[int, int],
    n: int,
    donate_argnums_per_stage: list[tuple[int, ...]] | None = None,
    all_constvars: list | None = None,
) -> list[tuple]:
    """Build per-rank ``(stage_jit, submesh, sharding, next_sharding, invar_map)`` tuples.

    Each ``stage_jit`` is a ``@jax.jit``-wrapped evaluator for that
    cluster's sub-jaxpr with constants pre-placed on the rank's sub-mesh.
    ``invar_map`` classifies each cluster invar as either ``("orig", idx)``
    (from the original function args at flat index ``idx``) or
    ``("prev", pos)`` (from the previous cluster's output at position ``pos``).
    """
    if donate_argnums_per_stage is None:
        donate_argnums_per_stage = [()] * n

    const_idx_by_id: dict[int, int] | None = None
    if all_constvars is not None:
        const_idx_by_id = {id(v): i for i, v in enumerate(all_constvars)}

    plans = []
    for rank, cluster in enumerate(clusters):
        sub_sharding = stage_shardings[rank]
        invar_map: list[tuple[str, int]] = []
        prev_idx = 0
        for v in cluster.invars:
            orig_idx = original_id_to_idx.get(id(v))
            if orig_idx is not None:
                invar_map.append(("orig", orig_idx))
            else:
                invar_map.append(("prev", prev_idx))
                prev_idx += 1

        if const_idx_by_id is not None:
            used_constvars = _collect_used_constvars(cluster)
            filtered_cluster = _filtered_cluster(cluster, used_constvars)
            const_indices = tuple(const_idx_by_id[id(v)] for v in used_constvars)
            pc = tuple(jax.device_put(consts[idx], sub_sharding) for idx in const_indices)
            eval_jaxpr = filtered_cluster
        else:
            pc = tuple(jax.device_put(c, sub_sharding) for c in consts)
            eval_jaxpr = cluster

        donate = donate_argnums_per_stage[rank]
        if donate:

            @functools.partial(jax.jit, donate_argnums=donate)
            def stage_jit(*invars, _c=pc, _j=eval_jaxpr):
                """Evaluate the cluster's sub-jaxpr with pre-placed constants."""
                return tuple(jax.core.eval_jaxpr(_j, list(_c), *invars))

        else:

            @jax.jit
            def stage_jit(*invars, _c=pc, _j=eval_jaxpr):
                """Evaluate the cluster's sub-jaxpr with pre-placed constants."""
                return tuple(jax.core.eval_jaxpr(_j, list(_c), *invars))

        plans.append(
            (
                stage_jit,
                rank_submeshes[rank],
                sub_sharding,
                stage_shardings[rank + 1] if rank < n - 1 else None,
                invar_map,
            )
        )
    return plans


def _infer_leaf_shardings(
    args: tuple,
    flat_init: list,
    n: int,
    rank_submeshes: list,
) -> tuple[list[dict[int, Any]], dict[int, int]]:
    """Auto-infer per-leaf shardings from :class:`Module` logical axis annotations.

    Scans ``args`` for :class:`Module` instances, calls
    :func:`get_named_sharding` for each rank's sub-mesh, and returns a
    list of dicts mapping flat-arg indices to :class:`NamedSharding`
    objects plus a flat-index -> owning-rank map derived from any
    explicit ``assign_stage(...)`` metadata. Non-Module args get no
    entry (fall through to replicated).
    """
    leaf_shardings: list[dict[int, Any]] = [{} for _ in range(n)]
    leaf_stage_owners: dict[int, int] = {}
    for arg in args:
        if not isinstance(arg, Module):
            continue
        _, state = export(arg)
        raw = state.raw()
        vars_by_key = {(var.kind, path): var for path, var in live_variables(arg)}
        arg_leaves = jax.tree.leaves(arg)
        state_leaves_ordered = [(col, path) for col in sorted(raw.keys()) for path in sorted(raw[col].keys())]
        first_leaf_id = id(arg_leaves[0]) if arg_leaves else None
        offset = None
        for fi, fl in enumerate(flat_init):
            if id(fl) == first_leaf_id:
                offset = fi
                break
        if offset is None:
            continue
        leaf_entries: list[tuple[int, str, str, int | None]] = []
        for li, (col, path) in enumerate(state_leaves_ordered):
            flat_idx = offset + li
            var = vars_by_key.get((col, path))
            owner = resolve_stage_rank(
                metadata_stage_assignment(var.metadata) if var is not None else None,
                n,
            )
            if owner is not None:
                leaf_stage_owners[flat_idx] = owner
            leaf_entries.append((flat_idx, col, path, owner))
        for rank in range(n):
            per_leaf = get_named_sharding(arg, rank_submeshes[rank])
            for flat_idx, col, path, owner in leaf_entries:
                if owner is not None and owner != rank:
                    continue
                sh = per_leaf.get(col, {}).get(path)
                if sh is not None:
                    leaf_shardings[rank][flat_idx] = sh
    return leaf_shardings, leaf_stage_owners


def _resolve_explicit_shardings(
    in_shardings: Any | None,
    flat_init: list,
) -> dict[int, Any]:
    """Flatten explicit ``in_shardings`` into a flat-index to sharding map.

    Returns an empty dict when ``in_shardings`` is ``None``.
    """
    if in_shardings is None:
        return {}
    explicit: dict[int, Any] = {}
    for i, sh in enumerate(jax.tree.leaves(in_shardings)):
        if sh is not None and i < len(flat_init):
            explicit[i] = sh
    return explicit


def _place_static_args(
    cluster_plans: list[tuple],
    flat_init: list,
    dynamic: set[int],
    explicit_in_sh: dict[int, Any],
    leaf_shardings: list[dict[int, Any]],
    leaf_stage_owners: dict[int, int],
    rank_submeshes: list,
) -> dict[tuple[int, int], Any]:
    """Place static (non-dynamic) args on each rank's sub-mesh, cached for reuse.

    Placement priority per leaf:

    1. Explicit ``assign_stage(...)`` ownership, when present.
    2. Explicit ``in_shardings`` override.
    3. Already on the correct rank's devices — skip ``device_put``
       (preserves carry state like KV cache pages).
    4. Inferred from :class:`Module` logical axis annotations.
    5. Fallback: replicated on the rank's sub-mesh.
    """
    placed: dict[tuple[int, int], Any] = {}
    for ri, (_, _, fallback_sh, _, imap) in enumerate(cluster_plans):
        rank_devices = set(rank_submeshes[ri].devices.flat)
        for kind, idx in imap:
            if kind != "orig" or idx in dynamic:
                continue
            owner = leaf_stage_owners.get(idx)
            if owner is not None and owner != ri:
                raise ValueError(
                    f"sxjit: flat argument leaf {idx} is assigned to pipeline "
                    f"stage {owner}, but traced stage {ri} uses it. Move the "
                    f"corresponding layer into the matching pipeline segment or "
                    f"update its assign_stage(...) hint."
                )
            leaf = flat_init[idx]
            if idx in explicit_in_sh:
                placed[(ri, idx)] = jax.device_put(leaf, explicit_in_sh[idx])
            elif hasattr(leaf, "devices") and set(leaf.devices()).issubset(rank_devices):
                placed[(ri, idx)] = leaf
            elif idx in leaf_shardings[ri]:
                placed[(ri, idx)] = jax.device_put(leaf, leaf_shardings[ri][idx])
            else:
                placed[(ri, idx)] = jax.device_put(leaf, fallback_sh)
    return placed


def _assemble_invars(
    invar_map: list[tuple[str, int]],
    flat_args: list,
    placed: dict[tuple[int, int], Any],
    dynamic: set[int],
    explicit_in_sh: dict[int, Any],
    prev_outputs: tuple,
    ri: int,
    my_sh: Any,
    rank_devices: set,
    dynamic_flat_to_orig_flat: dict[int, int] | None = None,
) -> list:
    """Assemble invars for one stage dispatch from placed params, dynamic args,
    and previous stage outputs.

    Dynamic args use the same placement priority as static args: explicit
    sharding > already on correct devices > fallback replicated.
    """
    invars = []
    for kind, idx in invar_map:
        if kind == "orig":
            if dynamic_flat_to_orig_flat is not None:
                orig_idx = dynamic_flat_to_orig_flat.get(idx, idx)
            else:
                orig_idx = idx
            if orig_idx in dynamic:
                leaf = flat_args[orig_idx]
                if orig_idx in explicit_in_sh:
                    invars.append(jax.device_put(leaf, explicit_in_sh[orig_idx]))
                elif hasattr(leaf, "devices") and set(leaf.devices()).issubset(rank_devices):
                    invars.append(leaf)
                else:
                    invars.append(jax.device_put(leaf, my_sh))
            else:
                invars.append(placed[(ri, orig_idx)])
        else:
            invars.append(jax.device_put(prev_outputs[idx], my_sh))
    return invars


def _assemble_outputs(
    fn_outvar_map: list[tuple],
    all_cluster_outputs: list[tuple],
    flat_args: list,
) -> Any:
    """Collect return values from all clusters using the outvar map.

    Each function outvar is sourced from the cluster that defined it,
    preserving per-rank device placement for carry state.
    """
    final = []
    for mapping in fn_outvar_map:
        src_rank, src_pos = mapping
        if isinstance(src_rank, int):
            final.append(all_cluster_outputs[src_rank][src_pos])
        elif src_rank == "orig_passthrough":
            final.append(flat_args[src_pos])
        elif src_rank == "const_passthrough":
            final.append(src_pos)
        else:
            final.append(None)
    if len(final) == 1:
        return final[0]
    return tuple(final)


def _apply_out_shardings(result: Any, out_shardings: Any | None) -> Any:
    """Apply ``out_shardings`` to the dispatch result.

    ``None`` preserves whatever sharding each output has from its
    producing rank. A single :class:`~jax.sharding.Sharding` is
    broadcast to all outputs. A list/tuple applies per-output (``None``
    entries mean "preserve").
    """
    if out_shardings is None:
        return result
    if isinstance(result, jax.Array):
        return jax.device_put(result, out_shardings)
    if isinstance(result, tuple):
        if isinstance(out_shardings, (list, tuple)):
            return tuple(
                jax.device_put(r, s) if s is not None and isinstance(r, jax.Array) else r
                for r, s in zip(result, out_shardings, strict=False)
            )
        return tuple(jax.device_put(r, out_shardings) if isinstance(r, jax.Array) else r for r in result)
    return result


def _place_state_on_rank(
    state: State,
    rank: int,
    stage: Module,
    rank_submeshes: list[Any],
    stage_shardings: list[Any],
) -> State:
    """Place ``state`` on ``rank``'s sub-mesh with per-leaf shardings.

    Uses :func:`get_named_sharding` to derive logical-axis-aware
    shardings for each leaf; leaves without a registered sharding fall
    back to the rank's replicated sharding.
    """
    per_leaf = get_named_sharding(stage, rank_submeshes[rank])
    replicated = stage_shardings[rank]
    raw = state.raw()
    out: dict[str, dict[str, Any]] = {}
    for col, d in raw.items():
        paths_in_col = per_leaf.get(col, {})
        out_col: dict[str, Any] = {}
        for path, leaf in d.items():
            sh = paths_in_col.get(path, replicated)
            out_col[path] = jax.device_put(leaf, sh)
        out[col] = out_col
    return type(state)(out)


def _active_profiler() -> "_Profiler | None":
    """Return the innermost active profiler on this thread, or ``None``.

    Uses thread-local storage so concurrent ``sxcall`` calls from
    different threads stay independent — useful for nested tests and
    any future multi-run orchestration.
    """
    return getattr(_PROFILER_STATE, "active", None)


class _Profiler:
    """Per-task millisecond accumulator used by :func:`collect_task_times_ms`."""

    def __init__(self) -> None:
        """Initialise an empty per-task timing map."""
        self.times_ms: dict[str, list[float]] = {}

    def record(self, task_name: str, dt_ms: float) -> None:
        """Append ``dt_ms`` to the list for ``task_name``."""
        self.times_ms.setdefault(task_name, []).append(dt_ms)


@contextlib.contextmanager
def collect_task_times_ms() -> Iterator[dict[str, list[float]]]:
    """Record wall-clock milliseconds for each MPMD task in the body.

    Yields a ``dict[str, list[float]]`` that's filled as
    :func:`sxcall` executes: keys are task names like
    ``"stage0_fwd_mb3"`` / ``"stage2_bwd_i_mb0"``, values are a list
    of per-call durations in milliseconds (one entry per schedule
    action). :func:`jax.block_until_ready` is called before recording,
    so timings include actual device-side work, not just dispatch.

    Only one profiler may be active per thread at a time — nested
    calls share the outer profiler's dict.

    Example::

        with collect_task_times_ms() as times:
            loss, grads = sxcall(model, (x, y), mpmd_mesh=mm, ...)

        for name, ms in sorted(times.items()):
            print(f"{name}: {ms}")
    """
    outer = _active_profiler()
    if outer is not None:
        yield outer.times_ms
        return
    prof = _Profiler()
    _PROFILER_STATE.active = prof
    try:
        yield prof.times_ms
    finally:
        _PROFILER_STATE.active = None


def _time_call(
    task_name: str,
    fn: Callable[..., Any],
    *args: Any,
) -> Any:
    """Call ``fn(*args)``; if a profiler is active, record its wall time."""
    prof = _active_profiler()
    if prof is None:
        return fn(*args)
    t0 = time.perf_counter_ns()
    out = fn(*args)
    jax.block_until_ready(out)
    prof.record(task_name, (time.perf_counter_ns() - t0) / 1e6)
    return out


TransportKind = Literal["device_put"]


def _transport(
    kind: TransportKind,
    x: Any,
    dest_sharding: Any,
    *,
    task_name: str | None = None,
) -> Any:
    """Move ``x`` to ``dest_sharding`` via :func:`jax.device_put`.

    Args:
        kind: Currently only ``"device_put"`` is supported. Portable
            across CPU / TPU / single-process GPU backends.
        x: The source :class:`jax.Array`.
        dest_sharding: A :class:`jax.sharding.NamedSharding` whose mesh
            is the destination sub-mesh.
        task_name: Optional profiler label so :func:`collect_task_times_ms`
            can attribute the wall time to a specific transfer.

    Returns:
        A :class:`jax.Array` placed according to ``dest_sharding``.
    """
    if kind != "device_put":
        raise ValueError(f"Unknown transport kind: {kind!r}.")
    if task_name is not None:
        return _time_call(task_name, jax.device_put, x, dest_sharding)
    return jax.device_put(x, dest_sharding)


def _last_use_table(grid: list[list[Any]]) -> dict[tuple[int, int], int]:
    """Compute the last-use time step for each ``(stage, microbatch)``.

    ``last_use[(s, mb)] = t`` means the stage-``s`` activation for
    microbatch ``mb`` is read (as saved_inputs / saved_outputs /
    g_y_cache) for the last time at time step ``t``. Runtimes can
    use this table to free the corresponding buffer afterwards.
    """
    last: dict[tuple[int, int], int] = {}
    for t, row in enumerate(grid):
        for s, action in enumerate(row):
            if action is None:
                continue
            key = (s, action.microbatch)
            last[key] = t
    return last


def _delete_if_possible(x: Any) -> None:
    """Free an array's device buffer if JAX allows it.

    :class:`jax.Array` exposes a ``.delete()`` method on newer JAX
    versions; older versions / non-committed arrays silently ignore.
    Exceptions are swallowed so the schedule loop never crashes on a
    donation miss.
    """
    try:
        delete = getattr(x, "delete", None)
        if callable(delete):
            delete()
    except Exception:
        pass


def _is_leaf(x: Any) -> bool:
    """Treat JAX arrays / Variables as pytree leaves."""
    return isinstance(x, jax.Array | Variable)


def _microbatch(x: jax.Array, m: int) -> jax.Array:
    """Reshape ``x`` (leading axis = batch) into ``(m, batch//m, ...)``."""
    b = x.shape[0]
    if b % m:
        raise ValueError(f"Batch size {b} not divisible by number of microbatches {m}.")
    return x.reshape(m, b // m, *x.shape[1:])


def _split_params_rest(state: State) -> tuple[State, State]:
    """Split ``state`` into ``(params, rest)``: only params differentiate."""
    raw = state.raw()
    params_raw: dict[str, dict[str, Any]] = {}
    rest_raw: dict[str, dict[str, Any]] = {}
    for c, d in raw.items():
        (params_raw if c == "params" else rest_raw)[c] = dict(d)
    return State(params_raw), State(rest_raw)


def _get_fused_fwd_bwd_jit(
    fwd_jit: Callable[..., Any],
    bwd_jit: Callable[..., Any],
) -> Callable[..., Any]:
    """Return a cached jit that performs a ``(fwd_A, bwd_B)`` pair in one dispatch.

    For 1F1B-family schedules at steady state each rank alternates one
    forward (microbatch ``A``) and one backward (microbatch ``B``).
    Dispatching each as its own jit pays two trace/dispatch costs per
    microbatch; fusing them into one compiled kernel halves that cost
    and lets XLA interleave their HLO for better register reuse.

    The fused jit's signature is::

        (params, rest, x_fwd, x_bwd, g_y_bwd)
            -> (y_fwd, g_params_bwd, g_x_bwd)

    ``x_bwd`` is the saved activation for mb ``B`` (captured during
    its earlier forward); the runtime still manages saved_inputs /
    recv_cots / grad_accum the same way — only the dispatch count
    changes.
    """
    key = (id(fwd_jit), id(bwd_jit))
    cached = _FUSED_FWDBWD_CACHE.get(key)
    if cached is not None:
        return cached

    @jax.jit
    def fused(params, rest, x_fwd, x_bwd, g_y_bwd):
        """Run forward on ``x_fwd`` and backward on ``(x_bwd, g_y_bwd)`` in one HLO."""
        y_fwd = fwd_jit(params, rest, x_fwd)
        g_params, g_x = bwd_jit(params, rest, x_bwd, g_y_bwd)
        return y_fwd, g_params, g_x

    _FUSED_FWDBWD_CACHE[key] = fused
    weak_invalidate(fwd_jit, _FUSED_FWDBWD_CACHE, key)
    weak_invalidate(bwd_jit, _FUSED_FWDBWD_CACHE, key)
    return fused


def _get_vmap_loss_and_g_y(
    loss_fn: Callable[..., jax.Array],
    donate_argnums: tuple[int, ...] = (),
) -> Callable[..., Any]:
    """Return the cached vmap'd ``(y_stack, *t_stack) -> (loss_stack, g_y_stack)``."""
    key = (id(loss_fn), donate_argnums)
    cached = _VMAP_LOSS_CACHE.get(key)
    if cached is not None:
        return cached

    if donate_argnums:

        @functools.partial(jax.jit, donate_argnums=donate_argnums)
        def vmap_loss(y_stack, *t_stack):
            """Jitted vmap of ``(loss, d_loss/d_y)`` over the microbatch axis."""

            def per_mb(y_, *t_):
                """Per-microbatch ``(loss, g_y)`` via ``value_and_grad``."""
                return jax.value_and_grad(lambda yy: loss_fn(yy, *t_))(y_)

            return jax.vmap(per_mb)(y_stack, *t_stack)

    else:

        @jax.jit
        def vmap_loss(y_stack, *t_stack):
            """Jitted vmap of ``(loss, d_loss/d_y)`` over the microbatch axis."""

            def per_mb(y_, *t_):
                """Per-microbatch ``(loss, g_y)`` via ``value_and_grad``."""
                return jax.value_and_grad(lambda yy: loss_fn(yy, *t_))(y_)

            return jax.vmap(per_mb)(y_stack, *t_stack)

    _VMAP_LOSS_CACHE[key] = vmap_loss
    weak_invalidate(loss_fn, _VMAP_LOSS_CACHE, key)
    return vmap_loss


@jax.jit
def _vmap_sum_grads(g_stack):
    """Sum per-microbatch grads along the leading axis."""
    return jax.tree.map(lambda x: x.sum(axis=0), g_stack, is_leaf=_is_leaf)


@jax.jit
def _accumulate_state(acc, add):
    """Module-level cached grad accumulator: ``acc + add`` leaf-wise.

    Defined at module scope so JAX's trace cache hits across every
    ``sxcall`` call and across every stage with matching pytree
    shape — eliminates the per-call re-trace cost that previously
    dominated step time at small batch sizes.
    """
    return jax.tree.map(lambda a, b: a + b, acc, add, is_leaf=_is_leaf)


@jax.jit
def _zeros_like_state(state):
    """Module-level cached ``zeros_like`` over a State pytree.

    Replaces the per-call ``jax.tree.map(jnp.zeros_like, sp)`` which
    issued one eager dispatch per parameter leaf — ~0.3 ms each on
    TPU, easily 60+ ms per step on medium models.
    """
    return jax.tree.map(jnp.zeros_like, state, is_leaf=_is_leaf)


@jax.jit
def _scale_state(state, scalar):
    """Module-level cached ``state * scalar`` leaf-wise."""
    return jax.tree.map(lambda g: g * scalar, state, is_leaf=_is_leaf)


def _get_loss_and_g_y(
    loss_fn: Callable[..., jax.Array],
    has_aux: bool = False,
    donate_argnums: tuple[int, ...] = (),
) -> Callable[..., Any]:
    """Return a jitted ``(y, *targets) -> (loss, grad_wrt_y, [aux])`` for ``loss_fn``.

    When ``has_aux=True``, ``loss_fn`` must return ``(scalar, aux_pytree)``.
    The returned wrapper yields ``(loss, g_y, aux)`` so the caller can
    accumulate aux across microbatches.

    Cached on ``(id(loss_fn), has_aux, donate_argnums)``.
    """
    key = (id(loss_fn), has_aux, donate_argnums)
    cached = _LOSS_JIT_CACHE.get(key)
    if cached is not None:
        return cached

    if has_aux:
        if donate_argnums:

            @functools.partial(jax.jit, donate_argnums=donate_argnums)
            def loss_and_g_y(y, *targets):
                """``(loss, d_loss/d_y, aux)`` with aux passthrough."""

                def local_loss(y_):
                    """Loss with aux: returns ``(scalar, aux)``."""
                    return loss_fn(y_, *targets)

                (loss_val, aux), g_y = jax.value_and_grad(local_loss, has_aux=True)(y)
                return loss_val, g_y, aux

        else:

            @jax.jit
            def loss_and_g_y(y, *targets):
                """``(loss, d_loss/d_y, aux)`` with aux passthrough."""

                def local_loss(y_):
                    """Loss with aux: returns ``(scalar, aux)``."""
                    return loss_fn(y_, *targets)

                (loss_val, aux), g_y = jax.value_and_grad(local_loss, has_aux=True)(y)
                return loss_val, g_y, aux

    else:
        if donate_argnums:

            @functools.partial(jax.jit, donate_argnums=donate_argnums)
            def loss_and_g_y(y, *targets):
                """Scalar ``(loss, d_loss/d_y)``."""

                def local_loss(y_):
                    """Scalar loss on ``y_``."""
                    return loss_fn(y_, *targets)

                return jax.value_and_grad(local_loss)(y)

        else:

            @jax.jit
            def loss_and_g_y(y, *targets):
                """Scalar ``(loss, d_loss/d_y)``."""

                def local_loss(y_):
                    """Scalar loss on ``y_``."""
                    return loss_fn(y_, *targets)

                return jax.value_and_grad(local_loss)(y)

    _LOSS_JIT_CACHE[key] = loss_and_g_y
    weak_invalidate(loss_fn, _LOSS_JIT_CACHE, key)
    return loss_and_g_y


def _build_stage_callables(
    stage: Module,
    donate_fwd: tuple[int, ...] = (),
    donate_bwd: tuple[int, ...] = (),
) -> tuple[
    Callable[..., Any],
    Callable[..., Any],
    State,
    State,
    Any,
]:
    """Compile forward and unified-backward functions for a stage.

    Two jits per stage:

    * ``fwd_only(params, x) -> y`` — the forward pass.
    * ``bwd_only(params, x, g_y) -> (g_params, g_x)`` — the full
      VJP via :func:`jax.linearize` + :func:`jax.linear_transpose`.
      For :class:`~specflux.pipeline.ZeroBubbleH1`, both :attr:`Phase.BWD_I`
      and :attr:`Phase.BWD_W` call this same jit but discard one of
      the two outputs; XLA's dead-code elimination collapses each
      half-call to roughly half the work of the full backward.

    Compared to an earlier implementation with three separate VJP
    jits (``bwd``, ``bwd_i``, ``bwd_w``), this trims tracing cost by
    eliminating the redundant re-tracings of ``stage_fn``.

    ``rest`` and ``gdef`` are passed as explicit arguments to the jit
    (not closure-captured) so JAX's trace cache keys on ``(arg avals)``
    alone — every subsequent call with the same shape signature hits
    the cache, even across distinct ``sxcall`` invocations.

    Returns:
        ``(fwd_only, bwd_only, params, rest, gdef)`` — ``params`` /
        ``rest`` are the initial state split; ``gdef`` is the stage's
        :class:`GraphDef` (retained for potential reuse).
    """
    gdef, state = export(stage)
    params, rest = _split_params_rest(state)

    n_leaves = len(jax.tree.leaves(params))
    cache_key = (id(stage), donate_fwd, donate_bwd)
    cached = _STAGE_CALLABLE_CACHE.get(cache_key)
    if cached is not None:
        cached_fwd, cached_bwd, cached_n_leaves = cached
        if cached_n_leaves == n_leaves:
            return cached_fwd, cached_bwd, params, rest, gdef
        del _STAGE_CALLABLE_CACHE[cache_key]

    if donate_fwd:

        @functools.partial(jax.jit, donate_argnums=donate_fwd)
        def fwd_only(params, rest, x):
            """Forward pass through the stage."""
            module = bind(gdef, params.merge(rest))
            return module(x)

    else:

        @jax.jit
        def fwd_only(params, rest, x):
            """Forward pass through the stage."""
            module = bind(gdef, params.merge(rest))
            return module(x)

    if donate_bwd:

        @functools.partial(jax.jit, donate_argnums=donate_bwd)
        def bwd_only(params, rest, x, g_y):
            """(g_params, g_x) via :func:`jax.vjp`.

            Uses ``vjp`` instead of ``linearize + linear_transpose`` because
            ``linearize`` fails on stages whose inputs contain integers
            (e.g. an embedding layer taking token IDs). ``vjp`` handles the
            int-to-float boundary correctly.
            """

            def stage_fn(p, r, xi):
                """Stage forward parameterized by (p, r, xi) for vjp."""
                return bind(gdef, p.merge(r))(xi)

            _y, vjp_fn = jax.vjp(stage_fn, params, rest, x)
            g_params, _g_rest, g_x = vjp_fn(g_y)
            return g_params, g_x

    else:

        @jax.jit
        def bwd_only(params, rest, x, g_y):
            """(g_params, g_x) via :func:`jax.vjp`.

            Uses ``vjp`` instead of ``linearize + linear_transpose`` because
            ``linearize`` fails on stages whose inputs contain integers
            (e.g. an embedding layer taking token IDs). ``vjp`` handles the
            int-to-float boundary correctly.
            """

            def stage_fn(p, r, xi):
                """Stage forward parameterized by (p, r, xi) for vjp."""
                return bind(gdef, p.merge(r))(xi)

            _y, vjp_fn = jax.vjp(stage_fn, params, rest, x)
            g_params, _g_rest, g_x = vjp_fn(g_y)
            return g_params, g_x

    _STAGE_CALLABLE_CACHE[cache_key] = (fwd_only, bwd_only, n_leaves)
    weak_invalidate(stage, _STAGE_CALLABLE_CACHE, cache_key)
    return fwd_only, bwd_only, params, rest, gdef


def _normalize_target(
    target: "PipelineSequential | Module",
    n_logical: int,
) -> PipelineSequential:
    """Coerce ``target`` into a :class:`PipelineSequential` of ``n_logical`` stages.

    Accepts either a pre-built :class:`PipelineSequential` (returned
    unchanged) or a bare :class:`~specflux.Module` (auto-split via
    :func:`auto_split` and wrapped in :class:`PipelineSequential`).

    The auto-split result is cached on ``(id(target), n_logical)`` so
    repeat calls with the same model object reuse the same stage objects
    — stable ``id`` for those stages keeps the downstream jit and
    placement caches hot.
    """
    if isinstance(target, PipelineSequential):
        return target
    if isinstance(target, Module):
        cache_key = (id(target), n_logical)
        cached = _MPMD_CALL_NORMALIZED_CACHE.get(cache_key)
        if cached is not None:
            return cached
        stage_modules = auto_split(target, n_logical)
        seq = PipelineSequential(*stage_modules)
        _MPMD_CALL_NORMALIZED_CACHE[cache_key] = seq
        weak_invalidate(target, _MPMD_CALL_NORMALIZED_CACHE, cache_key)
        return seq
    raise TypeError(f"sxcall target must be a PipelineSequential or a Module, got {type(target).__name__}.")


def sxcall(
    target: "PipelineSequential | Module",
    batch: tuple[Any, ...],
    *,
    mesh: SpxMesh | MpMdMesh,
    schedule: Schedule,
    loss_fn: Callable[..., jax.Array] | None = None,
    transport: TransportKind = "device_put",
    donate_activations: bool = False,
    static_argnums: int | tuple[int, ...] | None = None,
    donate_argnums: int | tuple[int, ...] | None = None,
    chunks: int | None = None,
    fuse_1f1b: bool = False,
    fuse_zb: bool = False,
    mode: Literal["train", "forward"] = "train",
    has_aux: bool = False,
) -> tuple[jax.Array, StagesArray] | tuple[jax.Array, StagesArray, Any] | jax.Array:
    """Execute one pipeline-parallel step with heterogeneous stages.

    Each stage runs on its own sub-mesh of ``mpmd_mesh``; the schedule
    loop is driven in Python with :func:`jax.device_put` handling
    cross-stage transfers of activations (forward) and cotangents
    (backward).

    Args:
        model: :class:`PipelineSequential` whose stages can have
            **different shapes, classes, or parameter structures** —
            no same-GraphDef constraint.
        batch: Tuple of inputs. First element is the pipeline input;
            remaining elements are targets / aux args forwarded to
            ``loss_fn`` on the final stage.
        mpmd_mesh: A :class:`MpMdMesh` whose ``mpmd_dim`` equals
            ``model.num_stages``. Non-MPMD axes (if any) are available
            for intra-stage SPMD sharding; activations land replicated
            across them.
        schedule: A :class:`Schedule` (``GPipe``, ``Std1F1B``,
            ``ZeroBubbleH1``, ``InterleavedH1``, ``Eager1F1B``, ...).
        loss_fn: ``(final_stage_output, *batch[1:]) -> scalar``.
        transport: Cross-stage copy mechanism. Only ``"device_put"``
            (default) is supported today; it uses :func:`jax.device_put`
            and is portable across CPU / TPU / GPU backends.
        donate_activations: When ``True``, free the device buffer
            for each saved activation / cotangent / ``g_y`` cache
            entry as soon as the schedule's last-use time step passes.
            Reduces peak memory at the cost of losing the arrays for
            any post-hoc inspection. Defaults to ``False``.
        static_argnums: Which elements of ``batch`` are static (compile-time
            constants). Static batch elements are not microbatched and are
            passed directly to ``loss_fn``. Index 0 (pipeline input) cannot
            be static.
        donate_argnums: Which elements of ``batch`` should have their device
            buffers donated. Target elements (indices >= 1) are donated to
            ``loss_fn``. The pipeline input (index 0) can only be donated in
            ``mode='forward'``.

    Returns:
        ``(loss, per_stage_param_grads)``: mean loss over all
        microbatches and a tuple of per-stage :class:`State` s
        carrying the ``params`` gradients. Gradients are resident on
        the stage's sub-mesh.

    The full setup (placed params/rest + fwd/bwd jits per
    ``(rank, virt)``) is cached in ``_MPMD_SETUP_CACHE`` by
    ``(id(model), id(mpmd_mesh), V)`` so repeat calls skip the ~40
    ``jax.device_put`` calls that placement re-runs would do. The
    two-pass execution within each time step (FWDs in ascending
    logical order, then BWDs in descending logical order) respects
    data dependencies while letting unrelated stages dispatch
    concurrently. Grads are returned in LOGICAL order so indices line
    up with the input ``PipelineSequential`` — flat schedules produce
    ``n`` grads, virtual schedules produce ``V*n``.

    Per-rank sub-mesh context is entered around each stage's jit so
    any ``with_sharding_constraint`` inside the stage resolves named
    axes against THIS rank's device set (not the full PP x TP mesh).
    Per-leaf shardings come from the model's logical axis annotations
    via ``get_named_sharding``; leaves without a registered sharding
    fall back to the rank's replicated sharding (legacy single-axis
    behavior). Resolution of logical -> physical axis names uses
    whatever :func:`logical_axis_rules` context is active at the call
    site.

    Example::

        from jax.sharding import Mesh
        from specflux.runtime.schedules import Std1F1B
        from specflux.runtime.types import MpMdMesh
        from specflux.nn import PipelineSequential
        from specflux.runtime.mpmd import sxcall

        devices = np.array(jax.devices()[:8]).reshape(4, 2)
        mm = MpMdMesh(Mesh(devices, ("pp", "fsdp")), "pp")
        model = PipelineSequential(
            EmbedStage(vocab=50_000, d=512, rngs=rngs),
            BlockStage(d=512, rngs=rngs),
            BlockStage(d=512, rngs=rngs),
            HeadStage(d=512, vocab=50_000, rngs=rngs),
        )
        loss, grads = sxcall(
            model, (ids, targets),
            mpmd_mesh=mm,
            schedule=Std1F1B(microbatches=8),
            loss_fn=softmax_xent,
        )
    """
    mpmd_mesh = resolve_mpmd_mesh(mesh)
    n = mpmd_mesh.mpmd_dim
    m = schedule.microbatches

    V = schedule.virtual_stages_per_rank()
    n_logical = V * n

    model = _normalize_target(target, n_logical)
    stages = model.stages

    if len(stages) != n_logical:
        raise ValueError(
            f"{type(schedule).__name__} with virtual_stages={V} needs a "
            f"PipelineSequential of {n_logical} logical stages "
            f"({V} per rank x {n} ranks); got {len(stages)}. "
            f"Build the model with stages in logical order — the runtime "
            f"routes each to its (rank, virt) slot via "
            f"``schedule.logical_at``."
        )

    static_nums = set(_normalize_argnums(static_argnums, len(batch)))
    donate_nums = set(_normalize_argnums(donate_argnums, len(batch)))

    if 0 in static_nums:
        raise ValueError(
            "sxcall: batch[0] (pipeline input) cannot be static. "
            "static_argnums must refer to target/aux arguments (indices >= 1)."
        )
    if 0 in donate_nums and mode == "train":
        raise ValueError(
            "sxcall: cannot donate batch[0] (pipeline input) in train mode. "
            "Use mode='forward' or remove 0 from donate_argnums."
        )

    donate_fwd = (2,) if (0 in donate_nums and mode == "forward") else ()
    donate_bwd = ()
    loss_donate = tuple(i for i in donate_nums if i > 0)

    setup_key = (id(model), id(mpmd_mesh), V, type(schedule).__name__, donate_fwd, donate_bwd)
    cached_setup = _MPMD_SETUP_CACHE.get(setup_key)
    if cached_setup is not None:
        (fwd_jits, bwd_jits, stage_params, stage_rest, stage_shardings, rank_submeshes) = cached_setup
        _setup_done = True
    else:
        _setup_done = False

    stage_shardings = [mpmd_mesh.sub_sharding(i) for i in range(n)] if not _setup_done else stage_shardings
    rank_submeshes = [mpmd_mesh.submesh(i) for i in range(n)] if not _setup_done else rank_submeshes

    def _place_state(state: State, rank: int, stage: Module) -> State:
        """Apply per-leaf shardings derived from the stage's logical-axis metadata.

        Leaves without a registered sharding fall back to the rank's
        replicated sharding (legacy single-axis behavior). Resolution
        of logical -> physical axis names uses whatever
        :func:`logical_axis_rules` context is active at the call site.
        """
        per_leaf = get_named_sharding(stage, rank_submeshes[rank])
        replicated = stage_shardings[rank]
        raw = state.raw()
        out: dict[str, dict[str, Any]] = {}
        for col, d in raw.items():
            paths_in_col = per_leaf.get(col, {})
            out_col: dict[str, Any] = {}
            for path, leaf in d.items():
                sh = paths_in_col.get(path, replicated)
                out_col[path] = jax.device_put(leaf, sh)
            out[col] = out_col
        return type(state)(out)

    if not _setup_done:
        fwd_jits = {}
        bwd_jits = {}
        stage_params = {}
        stage_rest = {}
        for rank in range(n):
            for virt in range(V):
                logical = schedule.logical_at(rank, virt, n)
                stage = stages[logical]
                fwd, bwd, params, rest, _ = _build_stage_callables(stage, donate_fwd=donate_fwd, donate_bwd=donate_bwd)
                fwd_jits[(rank, virt)] = fwd
                bwd_jits[(rank, virt)] = bwd
                stage_params[(rank, virt)] = _place_state(params, rank, stage)
                stage_rest[(rank, virt)] = _place_state(rest, rank, stage)
        _MPMD_SETUP_CACHE[setup_key] = (
            fwd_jits,
            bwd_jits,
            stage_params,
            stage_rest,
            stage_shardings,
            rank_submeshes,
        )
        weak_invalidate(model, _MPMD_SETUP_CACHE, setup_key)
        weak_invalidate(mpmd_mesh, _MPMD_SETUP_CACHE, setup_key)

    # Microbatch only dynamic batch elements; static elements pass through.
    mb_batch = []
    for i, x in enumerate(batch):
        if i in static_nums:
            mb_batch.append(x)
        else:
            mb_batch.append(_microbatch(x, m))
    xs = mb_batch[0]
    target_args = mb_batch[1:]
    static_target_mask = [i in static_nums for i in range(1, len(batch))]

    is_forward_only = mode == "forward"

    if not is_forward_only and loss_fn is None:
        raise ValueError("sxcall with mode='train' requires loss_fn.")

    if is_forward_only:
        return _forward_only_run(
            n=n,
            V=V,
            m=m,
            schedule=schedule,
            fwd_jits=fwd_jits,
            stage_params=stage_params,
            stage_rest=stage_rest,
            stage_shardings=stage_shardings,
            rank_submeshes=rank_submeshes,
            xs=xs,
        )

    loss_and_g_y = (
        _get_loss_and_g_y(loss_fn, has_aux=has_aux, donate_argnums=loss_donate) if not is_forward_only else None
    )
    aux_accum: list[Any] = []

    saved_inputs: dict[tuple[int, int], dict[int, Any]] = {k: {} for k in fwd_jits}
    saved_outputs: dict[tuple[int, int], dict[int, Any]] = {k: {} for k in fwd_jits}
    recv_cots: dict[tuple[int, int], dict[int, Any]] = {k: {} for k in fwd_jits}
    g_y_cache: dict[tuple[int, int], dict[int, Any]] = {k: {} for k in fwd_jits}
    grad_accum: dict[tuple[int, int], State] = {k: _zeros_like_state(v) for k, v in stage_params.items()}
    loss_acc: jax.Array = jnp.asarray(0.0)

    terminal_rank, terminal_virt = schedule.terminal_loc(n)

    if isinstance(schedule, GPipe) and V == 1 and not static_nums and not donate_nums:
        return _gpipe_run(
            n=n,
            m=m,
            fwd_jits=fwd_jits,
            bwd_jits=bwd_jits,
            stage_params=stage_params,
            stage_rest=stage_rest,
            stage_shardings=stage_shardings,
            rank_submeshes=rank_submeshes,
            xs=xs,
            target_args=target_args,
            loss_fn=loss_fn,
            transport_kind=transport,
            chunks=chunks,
        )

    def _transport_to(src_loc, dst_loc, arr, task_name=None):
        """Move ``arr`` to the device hosting ``dst_loc``.

        Within the same rank (virtual-stage shift on the same device)
        no transfer is needed — just return the array.
        """
        if src_loc[0] == dst_loc[0]:
            return arr
        return _transport(transport, arr, stage_shardings[dst_loc[0]], task_name=task_name)

    grid: list[list[Any]] = [list(row) for row in schedule.build(n)]
    if fuse_1f1b:
        grid = fuse_1f1b_steady_state(grid)
    if fuse_zb:
        grid = fuse_zerobubble_bwd_pair(grid)

    def _expand_cell(cell: Any) -> list[Any]:
        """Expand a grid cell into one or more dispatch units.

        A plain :class:`Action` or :class:`FusedTask` with an
        unsupported phase combo returns as its component
        :class:`Action` s (runtime falls back to per-action dispatch).
        A :class:`FusedTask(FWD, BWD)` returns as a single element
        so the loop fires one fused jit.
        """
        if cell is None:
            return []
        if isinstance(cell, FusedTask):
            if cell.fwd.phase == Phase.FWD and cell.bwd.phase == Phase.BWD:
                return [cell]
            return [cell.fwd, cell.bwd]
        return [cell]

    for t, row in enumerate(grid):
        fwd_acts: list[tuple[int, int, Any]] = []
        bwd_acts: list[tuple[int, int, Any]] = []
        fused_acts: list[tuple[int, int, FusedTask]] = []
        for rank, cell in enumerate(row):
            for unit in _expand_cell(cell):
                if isinstance(unit, FusedTask):
                    fused_acts.append((rank, unit.virtual_stage, unit))
                    continue
                if unit.phase == Phase.FWD:
                    fwd_acts.append((rank, unit.virtual_stage, unit))
                else:
                    bwd_acts.append((rank, unit.virtual_stage, unit))
        fwd_acts.sort(key=lambda t: schedule.logical_at(t[0], t[1], n))
        if not is_forward_only:
            bwd_acts.sort(key=lambda t: -schedule.logical_at(t[0], t[1], n))

        for rank, virt, fused in [] if is_forward_only else fused_acts:
            loc = (rank, virt)
            fwd_act = fused.fwd
            bwd_act = fused.bwd
            fwd_mb = fwd_act.microbatch
            bwd_mb = bwd_act.microbatch
            logical = schedule.logical_at(rank, virt, n)
            next_loc = schedule.next_logical_loc(rank, virt, n)
            with rank_submeshes[rank]:
                if logical == 0:
                    x_fwd = _transport(transport, xs[fwd_mb], stage_shardings[rank])
                else:
                    x_fwd = saved_inputs[loc][fwd_mb]
                x_bwd = saved_inputs[loc][bwd_mb]
                if loc == (terminal_rank, terminal_virt):
                    x_out_bwd = saved_outputs[loc][bwd_mb]
                    targets_mb = tuple(
                        (
                            _transport(transport, t, stage_shardings[rank])
                            if static_target_mask[i]
                            else _transport(transport, t[bwd_mb], stage_shardings[rank])
                        )
                        for i, t in enumerate(target_args)
                    )
                    loss_mb, g_y_bwd = _time_call(
                        f"L{logical}_loss_mb{bwd_mb}",
                        loss_and_g_y,
                        x_out_bwd,
                        *targets_mb,
                    )
                    loss_acc = loss_acc + loss_mb
                else:
                    g_y_bwd = recv_cots[loc][bwd_mb]
                fused_jit = _get_fused_fwd_bwd_jit(fwd_jits[loc], bwd_jits[loc])
                y_fwd, g_params, g_x_bwd = _time_call(
                    f"L{logical}_fused_fwd{fwd_mb}_bwd{bwd_mb}",
                    fused_jit,
                    stage_params[loc],
                    stage_rest[loc],
                    x_fwd,
                    x_bwd,
                    g_y_bwd,
                )
                saved_inputs[loc][fwd_mb] = x_fwd
                saved_outputs[loc][fwd_mb] = y_fwd
                if next_loc is not None:
                    saved_inputs[next_loc][fwd_mb] = _transport_to(
                        loc,
                        next_loc,
                        y_fwd,
                        task_name=f"transfer_fwd_L{logical}_to_L{logical + 1}_mb{fwd_mb}",
                    )
                grad_accum[loc] = _accumulate_state(grad_accum[loc], g_params)
                if logical > 0:
                    prev_loc = _prev_loc(schedule, rank, virt, n)
                    recv_cots[prev_loc][bwd_mb] = _transport_to(
                        loc,
                        prev_loc,
                        g_x_bwd,
                        task_name=f"transfer_bwd_L{logical}_to_L{logical - 1}_mb{bwd_mb}",
                    )
                if donate_activations:
                    _delete_if_possible(saved_inputs[loc].pop(bwd_mb, None))
                    _delete_if_possible(saved_outputs[loc].pop(bwd_mb, None))
                    recv_cots[loc].pop(bwd_mb, None)

        actions_to_run = fwd_acts if is_forward_only else (*fwd_acts, *bwd_acts)
        for rank, virt, action in actions_to_run:
            loc = (rank, virt)
            mb = action.microbatch
            logical = schedule.logical_at(rank, virt, n)
            next_loc = schedule.next_logical_loc(rank, virt, n)
            with rank_submeshes[rank]:
                if action.phase == Phase.FWD:
                    if logical == 0:
                        x_in = _transport(transport, xs[mb], stage_shardings[rank])
                    else:
                        x_in = saved_inputs[loc][mb]
                    x_out = _time_call(
                        f"L{logical}_fwd_mb{mb}",
                        fwd_jits[loc],
                        stage_params[loc],
                        stage_rest[loc],
                        x_in,
                    )
                    saved_inputs[loc][mb] = x_in
                    saved_outputs[loc][mb] = x_out
                    if next_loc is not None:
                        saved_inputs[next_loc][mb] = _transport_to(
                            loc,
                            next_loc,
                            x_out,
                            task_name=f"transfer_fwd_L{logical}_to_L{logical + 1}_mb{mb}",
                        )
                elif action.phase == Phase.BWD:
                    x_in = saved_inputs[loc][mb]
                    if loc == (terminal_rank, terminal_virt):
                        x_out = saved_outputs[loc][mb]
                        targets_mb = tuple(
                            (
                                _transport(transport, t, stage_shardings[rank])
                                if static_target_mask[i]
                                else _transport(transport, t[mb], stage_shardings[rank])
                            )
                            for i, t in enumerate(target_args)
                        )
                        _loss_result = _time_call(
                            f"L{logical}_loss_mb{mb}",
                            loss_and_g_y,
                            x_out,
                            *targets_mb,
                        )
                        if has_aux:
                            loss_mb, g_y, aux_mb = _loss_result
                            aux_accum.append(aux_mb)
                        else:
                            loss_mb, g_y = _loss_result
                        loss_acc = loss_acc + loss_mb
                    else:
                        g_y = recv_cots[loc][mb]
                    g_params, g_x = _time_call(
                        f"L{logical}_bwd_mb{mb}",
                        bwd_jits[loc],
                        stage_params[loc],
                        stage_rest[loc],
                        x_in,
                        g_y,
                    )
                    grad_accum[loc] = _accumulate_state(grad_accum[loc], g_params)
                    if logical > 0:
                        prev_loc = _prev_loc(schedule, rank, virt, n)
                        recv_cots[prev_loc][mb] = _transport_to(
                            loc,
                            prev_loc,
                            g_x,
                            task_name=f"transfer_bwd_L{logical}_to_L{logical - 1}_mb{mb}",
                        )
                    if donate_activations:
                        _delete_if_possible(saved_inputs[loc].pop(mb, None))
                        _delete_if_possible(saved_outputs[loc].pop(mb, None))
                        recv_cots[loc].pop(mb, None)
                elif action.phase == Phase.BWD_I:
                    x_in = saved_inputs[loc][mb]
                    if loc == (terminal_rank, terminal_virt):
                        x_out = saved_outputs[loc][mb]
                        targets_mb = tuple(
                            (
                                _transport(transport, t, stage_shardings[rank])
                                if static_target_mask[i]
                                else _transport(transport, t[mb], stage_shardings[rank])
                            )
                            for i, t in enumerate(target_args)
                        )
                        _loss_result = _time_call(
                            f"L{logical}_loss_mb{mb}",
                            loss_and_g_y,
                            x_out,
                            *targets_mb,
                        )
                        if has_aux:
                            loss_mb, g_y, aux_mb = _loss_result
                            aux_accum.append(aux_mb)
                        else:
                            loss_mb, g_y = _loss_result
                        loss_acc = loss_acc + loss_mb
                    else:
                        g_y = recv_cots[loc][mb]
                    g_y_cache[loc][mb] = g_y
                    _, g_x = _time_call(
                        f"L{logical}_bwd_i_mb{mb}",
                        bwd_jits[loc],
                        stage_params[loc],
                        stage_rest[loc],
                        x_in,
                        g_y,
                    )
                    if logical > 0:
                        prev_loc = _prev_loc(schedule, rank, virt, n)
                        recv_cots[prev_loc][mb] = _transport_to(
                            loc,
                            prev_loc,
                            g_x,
                            task_name=f"transfer_bwd_L{logical}_to_L{logical - 1}_mb{mb}",
                        )
                    if donate_activations:
                        _delete_if_possible(saved_outputs[loc].pop(mb, None))
                        recv_cots[loc].pop(mb, None)
                elif action.phase == Phase.BWD_W:
                    x_in = saved_inputs[loc][mb]
                    g_y = g_y_cache[loc][mb]
                    g_params, _ = _time_call(
                        f"L{logical}_bwd_w_mb{mb}",
                        bwd_jits[loc],
                        stage_params[loc],
                        stage_rest[loc],
                        x_in,
                        g_y,
                    )
                    grad_accum[loc] = _accumulate_state(grad_accum[loc], g_params)
                    del g_y_cache[loc][mb]
                    if donate_activations:
                        _delete_if_possible(saved_inputs[loc].pop(mb, None))

    if is_forward_only:
        terminal_loc = (terminal_rank, terminal_virt)
        outputs = saved_outputs.get(terminal_loc, {})
        if outputs:
            output_stack = jnp.stack([outputs[mb_i] for mb_i in sorted(outputs.keys())], axis=0)
            return output_stack.reshape(-1, *output_stack.shape[2:])
        return jnp.zeros(())

    mean_loss = loss_acc / jnp.asarray(m, dtype=loss_acc.dtype)
    inv_m = jnp.asarray(1.0 / m, dtype=jnp.float32)
    logical_grads: list[State] = []
    for logical in range(n_logical):
        loc = _loc_for_logical(schedule, logical, n, V)
        logical_grads.append(_scale_state(grad_accum[loc], inv_m))
    grads_out = StagesArray(shards=dict(enumerate(logical_grads)))

    if has_aux and aux_accum:
        mean_aux = jax.tree.map(
            lambda *vals: sum(vals) / len(vals),
            *aux_accum,
        )
        return mean_loss, grads_out, mean_aux
    return mean_loss, grads_out


def _forward_only_run(
    *,
    n: int,
    V: int,
    m: int,
    schedule: Schedule,
    fwd_jits: dict[tuple[int, int], Callable[..., Any]],
    stage_params: dict[tuple[int, int], State],
    stage_rest: dict[tuple[int, int], State],
    stage_shardings: list[Any],
    rank_submeshes: list[Any],
    xs: jax.Array,
) -> jax.Array:
    """Forward-only fast-path for all schedules (flat and virtual-stage).

    Skips all backward machinery — no ``bwd_jits``, no ``loss_fn``, no
    ``grad_accum``, no ``_zeros_like_state``. Follows the schedule's
    logical stage routing via ``logical_at`` / ``next_logical_loc`` to
    handle virtual-stage schedules (KimiK2, DualPipeV) where data
    bounces between physical ranks.
    """

    def _get_vfwd(loc: tuple[int, int]) -> Callable[..., Any]:
        """Return a cached vmapped forward jit for location ``loc``."""
        key = id(fwd_jits[loc])
        cached = _FWD_ONLY_VMAP_CACHE.get(key)
        if cached is not None:
            return cached
        vfwd = jax.jit(jax.vmap(fwd_jits[loc], in_axes=(None, None, 0)))
        _FWD_ONLY_VMAP_CACHE[key] = vfwd
        weak_invalidate(fwd_jits[loc], _FWD_ONLY_VMAP_CACHE, key)
        return vfwd

    n_logical = V * n

    # Build the logical-order forward chain: [(rank, virt), ...]
    logical_chain: list[tuple[int, int]] = []
    for logical in range(n_logical):
        for r in range(n):
            for v in range(V):
                if schedule.logical_at(r, v, n) == logical:
                    logical_chain.append((r, v))

    first_rank = logical_chain[0][0]
    x_curr = jax.device_put(xs, stage_shardings[first_rank])
    for i, (rank, virt) in enumerate(logical_chain):
        loc = (rank, virt)
        vfwd = _get_vfwd(loc)
        with rank_submeshes[rank]:
            x_curr = vfwd(stage_params[loc], stage_rest[loc], x_curr)
        # Transfer to next logical stage's rank if different
        if i < n_logical - 1:
            next_rank, _ = logical_chain[i + 1]
            if next_rank != rank:
                x_curr = jax.device_put(x_curr, stage_shardings[next_rank])

    return x_curr.reshape(-1, *x_curr.shape[2:])


def _gpipe_run(
    *,
    n: int,
    m: int,
    fwd_jits: dict[tuple[int, int], Callable[..., Any]],
    bwd_jits: dict[tuple[int, int], Callable[..., Any]],
    stage_params: dict[tuple[int, int], State],
    stage_rest: dict[tuple[int, int], State],
    stage_shardings: list[Any],
    rank_submeshes: list[Any],
    xs: jax.Array,
    target_args: tuple[jax.Array, ...],
    loss_fn: Callable[..., jax.Array],
    transport_kind: TransportKind,
    chunks: int | None = None,
) -> tuple[jax.Array, tuple[State, ...]]:
    """GPipe fast-path: chunked-vmap execution over M microbatches.

    Pipelining semantics under GPipe (all-fwds then all-bwds, no
    interleaving) are preserved exactly: each stage still runs all
    microbatches before the next stage starts. The Python loop just
    issues 1 vmapped dispatch per stage instead of M per-microbatch
    dispatches, slashing dispatch overhead at small/medium configs.

    Compute on TPU is identical (vmap fuses cleanly through dense
    matmuls); only Python+dispatch overhead drops.

    K-chunked execution (real stage overlap): splits M microbatches
    into K chunks (K in {2, m}). Each chunk issues its own vmap per
    stage, and JAX's async dispatch lets rank ``r+1``'s ``chunk_k``
    start as soon as rank ``r``'s ``chunk_k`` output is enqueued —
    while rank ``r`` moves to ``chunk_{k+1}``. vmap-collapse is broken
    at the K-boundary; true cross-stage overlap at 2x (not Mx)
    dispatch cost. Picks K=2 when M >= 2 for the 2-stage sweet spot;
    falls back to no chunking when M=1 (no microbatching).

    Adaptive K: picks no-vmap full-unroll (``K=m``) when per-microbatch
    compute is large enough to hide per-dispatch Python cost; else
    K=2 (minimal chunked vmap). Heuristic uses per-mb element count
    (batch x seq-len-equivalent) as a compute proxy — threshold 2M
    elements is empirical. At bs=4 seq=128 M=4 (128 elements/mb) K=2
    wins; at bs=16 seq=1024 M=4 (4096 elements/mb) K=m wins within
    1.20x of SPMD.

    K (chunk count) controls the overlap/dispatch trade-off:

    * K=1: one big vmap per stage — max vmap-collapse, no overlap
      (baseline).
    * K=2: two chunks — one sync point, partial overlap (safe
      default).
    * K=m: full unroll — no vmap, Mx dispatches, full cross-stage
      overlap.

    User override: pass ``chunks=m`` via sxcall for large-compute
    configs (bs x seq-per-mb >> dispatch cost) where K=m unlocks
    <=1.20x of SPMD. Default K=2 is the safe choice that improves
    every tested config.
    """

    def _vmap_pair(loc: tuple[int, int]) -> tuple[Callable[..., Any], Callable[..., Any]]:
        """Return the cached (vfwd, vbwd) pair for stage location ``loc``.

        ``inv_m`` is static (Python float) — value is fixed for a
        given M so JAX bakes it into the HLO and skips the per-call
        re-cast. ``static_argnums`` keeps the jit cache hot and avoids
        re-tracing when the caller passes Python primitives (e.g.
        inv_m as float).
        """
        key = id(fwd_jits[loc])
        cached = _GPIPE_VMAP_CACHE.get(key)
        if cached is not None:
            return cached
        vfwd = jax.jit(jax.vmap(fwd_jits[loc], in_axes=(None, None, 0)))
        base_vbwd = jax.vmap(bwd_jits[loc], in_axes=(None, None, 0, 0))

        @functools.partial(jax.jit, static_argnames=("inv_m_const",))
        def vbwd(p, r, x_stack, gy_stack, inv_m_const):
            """Jitted vmapped backward with inline per-param 1/M scaling."""
            g_params_stack, g_x_stack = base_vbwd(p, r, x_stack, gy_stack)
            g_params = jax.tree.map(
                lambda a: (a.sum(axis=0) * inv_m_const).astype(a.dtype),
                g_params_stack,
                is_leaf=_is_leaf,
            )
            return g_params, g_x_stack

        _GPIPE_VMAP_CACHE[key] = (vfwd, vbwd)
        weak_invalidate(fwd_jits[loc], _GPIPE_VMAP_CACHE, key)
        return vfwd, vbwd

    def _terminal_full(loc: tuple[int, int]) -> Callable[..., Any]:
        """Fused (vfwd + loss + d_loss/dy + vbwd) for the terminal stage.

        All three live on the same sub-mesh, so combining them into
        one jit cuts dispatch count + lets XLA fuse fwd -> loss -> bwd
        with no materialization gap.
        """
        key = (id(fwd_jits[loc]), id(loss_fn), "term_full")
        cached = _GPIPE_TERM_CACHE.get(key)
        if cached is not None:
            return cached

        base_fwd = fwd_jits[loc]
        base_bwd = bwd_jits[loc]
        base_fwd_vmapped = jax.vmap(base_fwd, in_axes=(None, None, 0))
        base_bwd_vmapped = jax.vmap(base_bwd, in_axes=(None, None, 0, 0))

        @functools.partial(jax.jit, static_argnames=("inv_m_const",))
        def fwd_loss_bwd(p, r, x_in_stack, *t_stack, inv_m_const):
            """Fused forward + loss + backward for the terminal stage."""
            y_stack = base_fwd_vmapped(p, r, x_in_stack)

            def per_mb_loss(y_, *t_):
                """Per-microbatch ``(loss, g_y)`` via value_and_grad."""
                return jax.value_and_grad(lambda yy: loss_fn(yy, *t_))(y_)

            loss_stack, gy_stack = jax.vmap(per_mb_loss)(y_stack, *t_stack)

            g_params_stack, g_x_stack = base_bwd_vmapped(p, r, x_in_stack, gy_stack)
            g_params = jax.tree.map(
                lambda a: (a.sum(axis=0) * inv_m_const).astype(a.dtype),
                g_params_stack,
                is_leaf=_is_leaf,
            )
            return loss_stack.mean(), g_params, g_x_stack

        _GPIPE_TERM_CACHE[key] = fwd_loss_bwd
        weak_invalidate(fwd_jits[loc], _GPIPE_TERM_CACHE, key)
        weak_invalidate(loss_fn, _GPIPE_TERM_CACHE, key)
        return fwd_loss_bwd

    if chunks is not None:
        K = max(1, min(int(chunks), m))
    elif m >= 2:
        K = m if (int(xs.size // max(m, 1))) >= 2_000_000 else 2
    else:
        K = 1
    if m % K:
        K = 2 if m >= 2 and m % 2 == 0 else 1
    chunk_size = m // K
    assert m % K == 0, f"microbatches={m} not divisible by K={K}"

    def _chunk(x):
        """Reshape leading-M axis to ``(K, chunk_size, ...)`` for chunked vmap."""
        return x.reshape(K, chunk_size, *x.shape[1:])

    xs_chunks = [xs.reshape(K, chunk_size, *xs.shape[1:])[k] for k in range(K)] if K > 1 else [xs]
    target_chunks = tuple(
        [t.reshape(K, chunk_size, *t.shape[1:])[k] for k in range(K)] if K > 1 else [t] for t in target_args
    )

    inv_m = float(1.0 / m)
    terminal_loc = (n - 1, 0)
    saved_inputs: dict[tuple[int, int], list[jax.Array]] = {}

    x_curr_chunks = list(xs_chunks)
    for rank in range(n - 1):
        loc = (rank, 0)
        vfwd, _ = _vmap_pair(loc)
        out_chunks = []
        with rank_submeshes[rank]:
            for k in range(K):
                y_k = _time_call(
                    f"L{rank}_fwd_chunk{k}",
                    vfwd,
                    stage_params[loc],
                    stage_rest[loc],
                    x_curr_chunks[k],
                )
                out_chunks.append(y_k)
        saved_inputs[loc] = list(x_curr_chunks)
        x_curr_chunks = [jax.device_put(y_k, stage_shardings[rank + 1]) for y_k in out_chunks]

    fused_term = _terminal_full(terminal_loc)
    saved_inputs[terminal_loc] = list(x_curr_chunks)
    loss_chunks = []
    g_params_term_chunks = []
    g_x_chunks = []
    with rank_submeshes[n - 1]:
        for k in range(K):
            tgt_k = tuple(tc[k] for tc in target_chunks)
            loss_k, g_params_k, g_x_k = _time_call(
                f"L{n - 1}_fwd_loss_bwd_chunk{k}",
                functools.partial(fused_term, inv_m_const=inv_m),
                stage_params[terminal_loc],
                stage_rest[terminal_loc],
                x_curr_chunks[k],
                *tgt_k,
            )
            loss_chunks.append(loss_k)
            g_params_term_chunks.append(g_params_k)
            g_x_chunks.append(g_x_k)
        loss = sum(loss_chunks) * (1.0 / K)
        g_params_term = g_params_term_chunks[0]
        for g in g_params_term_chunks[1:]:
            g_params_term = _accumulate_state(g_params_term, g)

    grads: dict[tuple[int, int], State] = {terminal_loc: g_params_term}
    if n > 1:
        g_y_chunks = [jax.device_put(g, stage_shardings[n - 2]) for g in g_x_chunks]
    else:
        g_y_chunks = g_x_chunks
    for rank in range(n - 2, -1, -1):
        loc = (rank, 0)
        _, vbwd = _vmap_pair(loc)
        g_params_accum = None
        next_g_x_chunks = []
        with rank_submeshes[rank]:
            for k in range(K):
                g_params_k, g_x_k = _time_call(
                    f"L{rank}_bwd_chunk{k}",
                    functools.partial(vbwd, inv_m_const=inv_m),
                    stage_params[loc],
                    stage_rest[loc],
                    saved_inputs[loc][k],
                    g_y_chunks[k],
                )
                next_g_x_chunks.append(g_x_k)
                g_params_accum = g_params_k if g_params_accum is None else _accumulate_state(g_params_accum, g_params_k)
            grads[loc] = g_params_accum
        if rank > 0:
            g_y_chunks = [jax.device_put(g, stage_shardings[rank - 1]) for g in next_g_x_chunks]

    return loss, StagesArray(shards={r: grads[(r, 0)] for r in range(n)})


def _prev_loc(schedule: Schedule, rank: int, virt: int, n: int) -> tuple[int, int]:
    """Inverse of :meth:`Schedule.next_logical_loc` — where is ``logical - 1``."""
    logical = schedule.logical_at(rank, virt, n)
    prev_logical = logical - 1
    V = schedule.virtual_stages_per_rank()
    for r in range(n):
        for v in range(V):
            if schedule.logical_at(r, v, n) == prev_logical:
                return (r, v)
    raise ValueError(f"Schedule {type(schedule).__name__} has no rank/virt producing logical={prev_logical}.")


def _loc_for_logical(schedule: Schedule, logical: int, n: int, V: int) -> tuple[int, int]:
    """Return the ``(rank, virt)`` hosting ``logical``."""
    for r in range(n):
        for v in range(V):
            if schedule.logical_at(r, v, n) == logical:
                return (r, v)
    raise ValueError(f"Schedule {type(schedule).__name__} has no rank/virt for logical={logical}.")
