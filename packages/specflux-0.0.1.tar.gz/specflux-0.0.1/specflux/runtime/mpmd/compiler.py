# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Per-rank compiled executables from marker-clustered jaxprs.

Takes the output of :func:`specflux.pipeline.marker.cluster_jaxpr_by_markers`
(a list of per-stage sub-jaxprs produced by splitting a traced function
at :func:`sxstage_iter` markers) and a :class:`Schedule`, and
compiles **one jitted executable per physical rank** that runs that
rank's full schedule.

Takes marker-clustered sub-jaxprs and compiles per-rank executables.
The transport layer uses
:func:`jax.device_put` between per-rank jit calls (portable across
backends). Cross-rank overlap is NOT achieved here — each rank's
program runs in full before transporting activations/cotangents to the
next. The win is purely dispatch-count reduction (one jit per rank per
step vs one jit per action).

For cross-rank compute overlap, use :func:`make_scheduled_body`
(shard_map + ppermute) or wait for the NCCL transport layer.

**Entry points**:

* :func:`get_num_stages` — infer stage count from a flat task list.
* :func:`compile_ranked_executables` — marker clusters + schedule →
  per-rank jitted programs.
* :func:`run_ranked_pipeline` — end-to-end: compile + dispatch +
  transport + loss.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

import jax
import jax.numpy as jnp
from jax._src.core import ClosedJaxpr, Jaxpr

from ..schedules import Action, FusedTask, Phase, Schedule

__all__ = [
    "compile_ranked_executables",
    "get_num_stages",
    "get_num_stages_from_grid",
    "run_ranked_pipeline",
]


def get_num_stages(tasks: list[Action | FusedTask]) -> int:
    """Infer the number of pipeline stages from a flat task list.

    Conventions:

    * For schedules where the terminal stage fuses FWD + BWD into one
      task (``FusedTask``), there are ``2n - 1`` tasks for ``n``
      stages. This is the standard case for GPipe and 1F1B on the
      terminal rank.
    * For schedules where FWD and BWD are always separate (GPipe
      global grid), there are ``2n`` tasks for ``n`` stages.
    * For zero-bubble schedules that split BWD into BWD_I + BWD_W,
      there are ``3n - 2`` tasks for ``n`` stages (the terminal stage
      fuses FWD + BWD_I, and the first stage fuses BWD_I + BWD_W).

    This function counts distinct ``stage_id``s inferred from the
    task microbatch pattern rather than assuming a fixed formula —
    robust across schedule families.

    Args:
        tasks: A flat list of :class:`Action` / :class:`FusedTask`
            entries for one rank (as returned by ``schedule.tasks()``
            or :func:`dualpipev_tasks`).

    Returns:
        Number of distinct pipeline stages represented in the list.
    """
    fwd_count = 0
    for task in tasks:
        if isinstance(task, FusedTask):
            for sub in (task.fwd, task.bwd):
                if sub.phase == Phase.FWD:
                    fwd_count += 1
        elif isinstance(task, Action):
            if task.phase == Phase.FWD:
                fwd_count += 1
    if fwd_count == 0:
        return 0
    grid_stages: set[int] = set()
    for task in tasks:
        if isinstance(task, FusedTask):
            grid_stages.add(task.fwd.virtual_stage)
            grid_stages.add(task.bwd.virtual_stage)
        elif isinstance(task, Action):
            grid_stages.add(task.virtual_stage)
    return len(grid_stages) if grid_stages else 0


def get_num_stages_from_grid(grid: list[list[Action | FusedTask | None]]) -> int:
    """Infer the number of physical stages from a schedule grid.

    Simply returns the width of the grid (number of columns = number
    of physical ranks).

    Args:
        grid: A schedule grid from :meth:`Schedule.build`.

    Returns:
        Number of physical stages (columns in the grid).
    """
    if not grid:
        return 0
    return len(grid[0])


def compile_ranked_executables(
    clusters: list[ClosedJaxpr | Jaxpr],
    schedule: Schedule,
    n_stages: int,
) -> list[Callable[..., Any]]:
    """Compile one jitted program per physical rank from clustered sub-jaxprs.

    Each cluster (from :func:`cluster_jaxpr_by_markers`) represents one
    pipeline stage's computation. The schedule tells us which stages
    each rank runs and in what order. The returned per-rank callable
    wraps every stage call for that rank into a single :func:`jax.jit`,
    cutting dispatch from ``O(T × n)`` to ``O(n)`` per step.

    The per-rank program signature is::

        rank_fn(stage_params: list[params],
                mb_inputs: array[M, *shape],
                mb_cotangents: array[M, *shape],
                *mb_targets)
            -> (g_params_list, mb_outputs, mb_out_cots, loss_sum)

    Cross-rank transport happens OUTSIDE these programs via the caller
    (using :func:`jax.device_put` between rank invocations). There is
    no cross-rank overlap in this path.

    Args:
        clusters: List of ``n_stages`` sub-jaxprs in logical order
            (stage 0 first). Each is a :class:`ClosedJaxpr` or bare
            :class:`Jaxpr`. Closed jaxprs carry their constants;
            bare jaxprs use no constants.
        schedule: A flat (V=1) :class:`Schedule`.
        n_stages: Number of physical pipeline ranks.

    Returns:
        A list of ``n_stages`` jitted callables, one per rank.
    """
    V = schedule.virtual_stages_per_rank()
    n_logical = n_stages * V

    if len(clusters) != n_logical:
        raise ValueError(f"Expected {n_logical} clusters for {n_stages} stages × V={V}; got {len(clusters)}.")

    stage_fns: list[Callable[..., Any]] = []
    for cluster in clusters:
        if isinstance(cluster, ClosedJaxpr):
            fn = jax.core.jaxpr_as_fun(cluster)
        else:
            closed = ClosedJaxpr(cluster, [])
            fn = jax.core.jaxpr_as_fun(closed)
        stage_fns.append(fn)

    grid = schedule.build(n_stages)
    per_rank_actions: list[list[Action]] = [[] for _ in range(n_stages)]
    for row in grid:
        for r, cell in enumerate(row):
            if cell is None:
                continue
            if isinstance(cell, FusedTask):
                per_rank_actions[r].append(cell.fwd)
                per_rank_actions[r].append(cell.bwd)
            else:
                per_rank_actions[r].append(cell)

    programs: list[Callable[..., Any]] = []
    for r in range(n_stages):
        actions = per_rank_actions[r]
        my_logical_stages = set()
        for a in actions:
            logical = schedule.logical_at(r, a.virtual_stage, n_stages)
            my_logical_stages.add(logical)
        my_fns = {logical: stage_fns[logical] for logical in my_logical_stages}

        def make_program(rank, rank_actions, rank_fns):
            """Build one rank's program as a jitted callable."""

            @jax.jit
            def rank_fn(all_stage_params, mb_inputs, mb_cotangents, *mb_targets):
                """Execute every scheduled action for this rank in order.

                ``all_stage_params`` is a list/tuple of per-logical-stage
                params pytrees. ``mb_inputs[mb]`` is the microbatch input
                (from xs or transported from rank-1). ``mb_cotangents[mb]``
                is the cotangent arriving from rank+1 (zero for terminal).
                ``mb_targets`` is the tuple of target arrays (only used
                on the terminal rank).

                Returns ``(per_stage_grads, outgoing_activations,
                outgoing_cotangents, loss_sum)``.
                """
                mb_inputs.shape[0]
                saved_inputs: dict[tuple[int, int], Any] = {}
                saved_outputs: dict[tuple[int, int], Any] = {}
                outgoing_acts = jnp.zeros_like(mb_inputs)
                outgoing_cots = jnp.zeros_like(mb_inputs)
                g_params_accum: dict[int, Any] = {}
                loss_sum = jnp.zeros((), dtype=jnp.float32)

                for action in rank_actions:
                    mb = action.microbatch
                    virt = action.virtual_stage
                    logical = schedule.logical_at(rank, virt, n_stages)
                    sfn = rank_fns[logical]

                    if action.phase == Phase.FWD:
                        x_in = mb_inputs[mb]
                        y = sfn(*all_stage_params[logical], x_in)
                        if not isinstance(y, jax.Array):
                            y = y[0] if isinstance(y, (tuple, list)) else y
                        saved_inputs[(virt, mb)] = x_in
                        saved_outputs[(virt, mb)] = y
                        outgoing_acts = outgoing_acts.at[mb].set(y)

                    elif action.phase == Phase.BWD:
                        x_in = saved_inputs.get((virt, mb), mb_inputs[mb])
                        g_y = mb_cotangents[mb]

                        def _stage_for_grad(*p, _x=x_in, _fn=sfn):
                            out = _fn(*p, _x)
                            return out[0] if isinstance(out, (tuple, list)) else out

                        grad_fn = jax.grad(_stage_for_grad, argnums=tuple(range(len(all_stage_params[logical]))))
                        g_p = grad_fn(*all_stage_params[logical])
                        if not isinstance(g_p, tuple):
                            g_p = (g_p,)

                        _, vjp_fn = jax.vjp(
                            lambda _x, _fn=sfn, _p=all_stage_params[logical]: (
                                _fn(*_p, _x)[0] if isinstance(_fn(*_p, _x), (tuple, list)) else _fn(*_p, _x)
                            ),
                            x_in,
                        )
                        (g_x,) = vjp_fn(g_y)
                        outgoing_cots = outgoing_cots.at[mb].set(g_x)

                        if logical not in g_params_accum:
                            g_params_accum[logical] = g_p
                        else:
                            g_params_accum[logical] = jax.tree.map(
                                lambda a, b: a + b,  # noqa: B023
                                g_params_accum[logical],
                                g_p,
                            )

                return g_params_accum, outgoing_acts, outgoing_cots, loss_sum

            return rank_fn

        programs.append(make_program(r, actions, my_fns))

    return programs


def run_ranked_pipeline(
    clusters: list[ClosedJaxpr | Jaxpr],
    params_per_stage: list[tuple[Any, ...]],
    schedule: Schedule,
    n_stages: int,
    microbatches: int,
    xs: Any,
    target_args: tuple[Any, ...],
    loss_fn: Callable[..., Any],
    stage_shardings: list[Any] | None = None,
) -> tuple[Any, list[Any]]:
    """End-to-end: cluster → compile → execute → transport → loss.

    Drives one training step using per-rank compiled executables with
    :func:`jax.device_put` transport between ranks. No cross-rank
    overlap (serial per rank).

    Args:
        clusters: Per-stage sub-jaxprs from
            :func:`cluster_jaxpr_by_markers`.
        params_per_stage: ``params_per_stage[logical]`` is a tuple of
            arrays matching the cluster's invars (the "param" portion).
        schedule: A flat :class:`Schedule`.
        n_stages: Physical rank count.
        microbatches: ``M``.
        xs: Microbatched inputs ``(M, *shape)``.
        target_args: Microbatched targets.
        loss_fn: ``(y, *targets) -> scalar``.
        stage_shardings: Optional per-rank sharding for transport.

    Returns:
        ``(mean_loss, per_stage_grads)``.
    """
    programs = compile_ranked_executables(clusters, schedule, n_stages)

    zero_cots = jnp.zeros_like(xs)
    mb_inputs = xs
    grads: list[Any] = [None] * len(clusters)
    loss_sum = jnp.zeros((), dtype=jnp.float32)

    for r in range(n_stages):
        mb_in_r = mb_inputs
        if stage_shardings is not None:
            mb_in_r = jax.device_put(mb_in_r, stage_shardings[r])
        g_p, mb_out, _mb_cot, loss_r = programs[r](
            params_per_stage,
            mb_in_r,
            zero_cots,
            *target_args,
        )
        for logical, gp in g_p.items():
            grads[logical] = gp
        mb_inputs = mb_out
        loss_sum = loss_sum + loss_r

    mean_loss = loss_sum / jnp.asarray(microbatches, dtype=loss_sum.dtype)
    return mean_loss, grads
