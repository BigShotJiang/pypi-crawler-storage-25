# Copyright 2026 Erfan Zare Chavoshi
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Interleaved (virtual-stage) schedules: InterleavedH1, InterleavedGPipe, Interleaved1F1BPlusOne, KimiK2."""

from __future__ import annotations

from dataclasses import dataclass

from .base import Action, Phase, Schedule
from .gpipe import GPipe
from .one_f_one_b import Std1F1B, _Std1F1BWarmupBumped


@dataclass
class InterleavedH1(Schedule):
    """Interleaved 1F1B with virtual pipeline parallelism (Narayanan 2021).

    Each physical device owns ``virtual_stages`` non-contiguous logical
    stages. A device with virtual count ``v`` and physical rank ``r``
    in an ``n``-device pipeline owns logical stages
    ``r, r + n, r + 2n, …, r + (v - 1) n``.

    Pros:

    * Pipeline bubble ratio shrinks by a factor of ``virtual_stages``.
      With ``v = 4`` stages per device on a 4-device pipeline, the
      bubble is ~25% of 1F1B's.

    Cons:

    * ``(virtual_stages - 1) x n`` extra ``ppermute`` hops per
      microbatch. Makes sense on high-bandwidth interconnect (NVLink,
      TPU v5+ ICI); less beneficial on PCIe.

    Attributes:
        virtual_stages: Number of virtual stages per physical device.
    """

    virtual_stages: int = 2

    def __post_init__(self) -> None:
        """Validate configuration."""
        super().__post_init__()
        if self.virtual_stages < 1:
            raise ValueError(f"InterleavedH1.virtual_stages must be >= 1, got {self.virtual_stages}.")

    def virtual_stages_per_rank(self) -> int:
        """Number of virtual stages per physical device."""
        return self.virtual_stages

    def logical_at(self, rank: int, virt: int, n_stages: int) -> int:
        """Map ``(rank, virt)`` to its logical-stage index.

        Logical stages are laid out so rank 0 hosts logical ``[0, n,
        2n, ...]`` for ``virt = 0, 1, 2, ...``; more generally
        ``logical = virt * n_stages + rank``.
        """
        return virt * n_stages + rank

    def next_logical_loc(self, rank: int, virt: int, n_stages: int):
        """Return the ``(rank, virt)`` of the next logical stage (or ``None``)."""
        nxt = virt * n_stages + rank + 1
        if nxt >= self.virtual_stages * n_stages:
            return None
        return (nxt % n_stages, nxt // n_stages)

    def terminal_loc(self, n_stages: int) -> tuple[int, int]:
        """Return the ``(rank, virt)`` hosting the terminal logical stage."""
        return (n_stages - 1, self.virtual_stages - 1)

    def build(self, n_stages: int) -> list[list[Action | None]]:
        """Emit the interleaved-1F1B grid.

        The total number of logical stages is ``n_stages x
        virtual_stages``. Each logical stage handles ``M`` microbatches
        exactly like 1F1B; the physical device that owns a logical
        stage does its work.

        Implementation: build a 1F1B grid for ``n_logical = n * v``
        logical stages, then remap each logical stage ``l`` back to
        physical device ``l % n``, virtual stage ``l // n``. If two
        virtual stages on the same physical device want the same time
        step (shouldn't happen given 1F1B's construction on
        ``n_logical``, but handled defensively), we emit the current
        row and serialize the loser into a fresh row.
        """
        n = n_stages
        v = self.virtual_stages
        m = self.microbatches
        n_logical = n * v

        logical = Std1F1B(m).build(n_logical)
        grid: list[list[Action | None]] = []
        for row in logical:
            new_row: list[Action | None] = [None] * n
            for l_stage, action in enumerate(row):
                if action is None:
                    continue
                phys = l_stage % n
                virt = l_stage // n
                if new_row[phys] is not None:
                    grid.append(new_row)
                    new_row = [None] * n
                new_row[phys] = Action(action.phase, action.microbatch, virt)
            grid.append(new_row)

        while grid and all(c is None for c in grid[-1]):
            grid.pop()
        return grid

    def peak_activations(self, n_stages: int) -> int:
        """Peak ≈ ``n_stages x virtual_stages``."""
        return n_stages * self.virtual_stages


@dataclass
class InterleavedGPipe(Schedule):
    """Interleaved GPipe: all-fwd then all-bwd with virtual stages.

    The GPipe analog of :class:`InterleavedH1`: each physical device
    owns ``virtual_stages`` non-contiguous logical stages, but unlike
    1F1B the schedule runs every forward before any backward.

    Pros over :class:`InterleavedH1`:

    * Simpler activation lifetime — every stage's M activations are
      saved until the backward pass starts (O(M x v) per device).
    * Natural pairing with ``lax.remat`` for activation checkpointing.

    Cons:

    * Peak memory scales as ``virtual_stages x microbatches`` —
      large on long pipelines with many microbatches.

    Attributes:
        virtual_stages: Virtual stages per physical device.
    """

    virtual_stages: int = 2

    def __post_init__(self) -> None:
        """Validate ``virtual_stages >= 1``."""
        super().__post_init__()
        if self.virtual_stages < 1:
            raise ValueError(f"InterleavedGPipe.virtual_stages must be >= 1, got {self.virtual_stages}.")

    def virtual_stages_per_rank(self) -> int:
        """Number of virtual stages per physical device."""
        return self.virtual_stages

    def logical_at(self, rank: int, virt: int, n_stages: int) -> int:
        """Map ``(rank, virt)`` to its logical-stage index."""
        return virt * n_stages + rank

    def next_logical_loc(self, rank: int, virt: int, n_stages: int):
        """Return the ``(rank, virt)`` of the next logical stage (or ``None``)."""
        nxt = virt * n_stages + rank + 1
        if nxt >= self.virtual_stages * n_stages:
            return None
        return (nxt % n_stages, nxt // n_stages)

    def terminal_loc(self, n_stages: int) -> tuple[int, int]:
        """Return the ``(rank, virt)`` hosting the terminal logical stage."""
        return (n_stages - 1, self.virtual_stages - 1)

    def build(self, n_stages: int) -> list[list[Action | None]]:
        """Emit the interleaved-GPipe grid.

        Same logical->physical mapping as :class:`InterleavedH1`, but
        the underlying per-logical-stage schedule is :class:`GPipe`
        (all fwds, then all bwds) instead of 1F1B.
        """
        n = n_stages
        v = self.virtual_stages
        m = self.microbatches
        n_logical = n * v

        logical = GPipe(m).build(n_logical)
        grid: list[list[Action | None]] = []
        for row in logical:
            new_row: list[Action | None] = [None] * n
            for l_stage, action in enumerate(row):
                if action is None:
                    continue
                phys = l_stage % n
                virt = l_stage // n
                if new_row[phys] is not None:
                    grid.append(new_row)
                    new_row = [None] * n
                new_row[phys] = Action(action.phase, action.microbatch, virt)
            grid.append(new_row)

        while grid and all(c is None for c in grid[-1]):
            grid.pop()
        return grid

    def peak_activations(self, n_stages: int) -> int:
        """Peak ≈ ``virtual_stages x microbatches`` (all saved before BWD)."""
        return self.virtual_stages * self.microbatches


@dataclass
class Interleaved1F1BPlusOne(InterleavedH1):
    """:class:`InterleavedH1` with one extra warmup forward prepended.

    Variant that pulls a single forward op (stage 0, virtual 0,
    microbatch 0) into its own leading time step, then runs the rest
    of the standard interleaved-1F1B grid. Total op count is
    identical to :class:`InterleavedH1`; only the leading ordering
    differs.

    Honest framing: in a Python-driven runtime this strictly *adds*
    one empty-ish dispatch slot vs :class:`InterleavedH1`, so it's
    typically slower. The form is useful as a building block / sanity
    check for schedules that re-shuffle further (e.g. true Kimi-K2,
    which we ship as :class:`KimiK2`).

    Attributes:
        virtual_stages: Virtual stages per physical device.
    """

    def build(self, n_stages: int) -> list[list[Action | None]]:
        """Emit the grid: ``InterleavedH1`` with +1 warmup row prepended.

        Prepends a single-action row — ``(stage 0, virt 0, mb 0)`` —
        and removes the duplicate FWD of that same action from the
        base :class:`InterleavedH1` schedule to preserve total action
        counts. If ``microbatches < 1`` or the base grid is empty we
        fall through to the base unchanged.
        """
        base = super().build(n_stages)
        if self.microbatches < 1 or not base:
            return base
        first_row: list[Action | None] = [None] * n_stages
        first_row[0] = Action(Phase.FWD, 0, 0)
        found = False
        new_base: list[list[Action | None]] = []
        for row in base:
            new_row: list[Action | None] = list(row)
            if not found:
                for s in range(n_stages):
                    a = new_row[s]
                    if a is not None and a.phase == Phase.FWD and a.microbatch == 0 and a.virtual_stage == 0 and s == 0:
                        new_row[s] = None
                        found = True
                        break
            new_base.append(new_row)
        return [first_row, *new_base]


@dataclass
class KimiK2(InterleavedH1):
    """Kimi-K2 schedule (Moonshot AI training infra, 2024).

    Variant of :class:`InterleavedH1` that bumps the per-logical-stage
    warmup forward count by 1, folded into the steady-state 1F1B walk
    so no extra time-step row is wasted. The +1 warmup gives every
    physical rank one more forward in flight before the first
    backward fires, which trims the cooldown tail at large
    microbatch counts.

    The +1 warmup matches the Kimi-K2 paper's design intent. In a
    Python-driven runtime the gain is small (the schedule does the
    same total ops) and may be invisible against dispatch noise; the
    win shows up most clearly in compiler-aware runtimes that can use
    the longer warmup to overlap stages more aggressively.

    Compare to:

    * :class:`InterleavedH1` — the base interleaved 1F1B
    * :class:`Interleaved1F1BPlusOne` — naïve "+1 by prepended row"
      variant; structurally adds an idle slot (slower in dispatch-
      bound runtimes).

    Attributes:
        virtual_stages: Virtual stages per physical rank (vp).
    """

    def build(self, n_stages: int) -> list[list[Action | None]]:
        """Same logical->physical remap as :class:`InterleavedH1` but
        the underlying per-logical-stage 1F1B uses +1 warmup."""
        n = n_stages
        v = self.virtual_stages
        m = self.microbatches
        n_logical = n * v

        logical = _Std1F1BWarmupBumped(microbatches=m, extra_warmup=1).build(n_logical)
        grid: list[list[Action | None]] = []
        for row in logical:
            new_row: list[Action | None] = [None] * n
            for l_stage, action in enumerate(row):
                if action is None:
                    continue
                phys = l_stage % n
                virt = l_stage // n
                if new_row[phys] is not None:
                    grid.append(new_row)
                    new_row = [None] * n
                new_row[phys] = Action(action.phase, action.microbatch, virt)
            grid.append(new_row)

        while grid and all(c is None for c in grid[-1]):
            grid.pop()
        return grid
