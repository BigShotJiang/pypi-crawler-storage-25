"""Smart utilities for improved CLI functionality.

Provides search criteria builders, request body helpers,
and CLI-level error handling with rich console output.
"""

import json
from typing import Any

import typer
from rich import print as rprint
from rich.console import Console

from m2_sdk.formatters import format_output


def build_smart_search_criteria(
    name_like: str | None = None,
    sku_like: str | None = None,
    price_from: float | None = None,
    price_to: float | None = None,
    status: str | None = None,
    type: str | None = None,
    email_like: str | None = None,
    limit: int | None = 20,
    page: int | None = 1,
    sort_by: str | None = None,
    sort_order: str | None = "asc",
    **kwargs: Any,
) -> dict[str, Any]:
    """Build SearchCriteria parameters from human-friendly options.

    Examples:
        build_smart_search_criteria(name_like="Laptop%", price_from=100)
        # -> searchCriteria[filterGroups][0][filters][0][field]=name
        #   searchCriteria[filterGroups][0][filters][0][value]=Laptop%
        #   searchCriteria[filterGroups][0][filters][0][conditionType]=like
    """
    params: dict[str, Any] = {}

    # Pagination
    if limit:
        params["searchCriteria[pageSize]"] = limit
    if page:
        params["searchCriteria[currentPage]"] = page

    # Sorting
    if sort_by:
        params["searchCriteria[sortOrders][0][field]"] = sort_by
        params["searchCriteria[sortOrders][0][direction]"] = (sort_order or "asc").upper()

    # Build filters
    filter_idx = 0

    filter_mappings = [
        (name_like, "name", "like"),
        (sku_like, "sku", "like"),
        (email_like, "customer_email", "like"),
        (status, "status", "eq"),
        (type, "type_id", "eq"),
    ]

    for value, field, condition in filter_mappings:
        if value is not None:
            params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][field]"] = field
            params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][value]"] = str(value)
            params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][conditionType]"] = (
                condition
            )
            filter_idx += 1

    # Range filters
    if price_from is not None:
        params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][field]"] = "price"
        params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][value]"] = str(price_from)
        params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][conditionType]"] = "gteq"
        filter_idx += 1

    if price_to is not None:
        params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][field]"] = "price"
        params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][value]"] = str(price_to)
        params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][conditionType]"] = "lteq"
        filter_idx += 1

    # Add any additional filters from kwargs
    for key, value in kwargs.items():
        if value is not None and not key.startswith("_"):
            # Parse key like "field_condition" -> field, condition
            parts = key.rsplit("_", 1)
            if len(parts) == 2 and parts[1] in ["eq", "like", "gt", "lt", "gteq", "lteq"]:
                field, condition = parts
            else:
                field = key
                condition = "eq"

            params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][field]"] = field
            params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][value]"] = str(value)
            params[f"searchCriteria[filterGroups][0][filters][{filter_idx}][conditionType]"] = (
                condition
            )
            filter_idx += 1

    return params


def build_request_body(data: str | None = None, **kwargs: Any) -> dict[str, Any] | None:
    """Build request body from either JSON data or individual fields.

    Examples:
        # Full JSON mode
        build_request_body(data='{"sku":"X","name":"Y"}')
        # -> {"sku": "X", "name": "Y"}

        # Individual field mode
        build_request_body(sku="X", name="Y", price=99.99)
        # -> {"sku": "X", "name": "Y", "price": 99.99}

        # JSON from file
        build_request_body(data="@product.json")
        # -> {contents of product.json}
    """
    # If data provided, use it (advanced mode)
    if data:
        return parse_json_data(data)

    # Otherwise build from kwargs (simple mode)
    body = {}
    for key, value in kwargs.items():
        if value is not None:
            body[key] = value

    return body if body else None


def parse_json_data(data: str) -> dict[str, Any] | None:
    """Parse JSON data from string or file.

    Args:
        data: JSON string or @filename.json

    Returns:
        Parsed JSON dict or None

    Raises:
        typer.BadParameter: If JSON is invalid
    """
    if not data:
        return None

    # Load from file
    if data.startswith("@"):
        filename = data[1:]
        try:
            with open(filename) as f:
                content = f.read()
                result = json.loads(content)
                if isinstance(result, dict):
                    return result
                return None
        except FileNotFoundError as e:
            raise typer.BadParameter(f"File not found: {filename}") from e
        except json.JSONDecodeError as e:
            raise typer.BadParameter(f"Invalid JSON in {filename}: {e}") from e

    # Parse inline JSON
    try:
        result = json.loads(data)
        if isinstance(result, dict):
            return result
        return None
    except json.JSONDecodeError as e:
        raise typer.BadParameter(f"Invalid JSON: {e}") from e


def format_and_print(
    response: Any,
    json_output: bool = False,
    raw_output: bool = False,
) -> None:
    """Format and print API response."""
    formatted = format_output(
        response,
        format_type="rich",
        json_output=json_output,
        raw_output=raw_output,
    )
    rprint(formatted)


# --- CLI-level error handling ---


def _handle_validation_error(console: Console, error: Exception) -> None:
    """Handle 400 Bad Request errors."""
    msg = str(error)
    console.print(f"[red bold]Validation Error:[/red bold] {msg}")


def _handle_auth_error(console: Console) -> None:
    """Handle 401 Authentication error."""
    console.print("[red bold]Authentication Failed[/red bold]")
    console.print("[yellow]Your token may have expired.[/yellow]")
    console.print("[dim]Run: m2 auth login[/dim]")


def _handle_permission_error(console: Console, resource_type: str) -> None:
    """Handle 403 Permission Denied error."""
    console.print("[red bold]Permission Denied[/red bold]")
    console.print(f"[yellow]You don't have permission to access this {resource_type}.[/yellow]")


def _handle_not_found(console: Console, resource_type: str, resource_id: str | None) -> None:
    """Handle 404 Not Found errors."""
    console.print(f"[red bold]{resource_type.title()} Not Found[/red bold]")
    if resource_id:
        console.print(f"[dim]{resource_type} '{resource_id}' does not exist.[/dim]")


def _handle_conflict_error(console: Console, resource_type: str) -> None:
    """Handle 409 Conflict error."""
    console.print("[red bold]Conflict[/red bold]")
    console.print(f"[yellow]This {resource_type} already exists or has conflicting data.[/yellow]")


def _handle_rate_limit_error(console: Console) -> None:
    """Handle 429 Rate Limit error."""
    console.print("[red bold]Rate Limited[/red bold]")
    console.print("[yellow]Too many requests. Please wait a moment and try again.[/yellow]")


def _handle_server_error(console: Console, status_code: int, error: Exception) -> None:
    """Handle 5xx server errors."""
    console.print(f"[red bold]Server Error ({status_code})[/red bold]")
    console.print(
        "[yellow]The Magento server encountered an error. Please try again later.[/yellow]"
    )
    console.print(f"[dim]{error}[/dim]")


def handle_api_error(
    error: Exception,
    resource_type: str,
    resource_id: str | None = None,
) -> None:
    """Handle API errors with rich console output.

    Designed to be called from CLI command functions to display
    user-friendly error messages.

    Args:
        error: The caught exception (APIError, AuthError, etc.)
        resource_type: Type of resource (product, order, customer, etc.)
        resource_id: ID/SKU that was being accessed
    """
    console = Console()

    status_code = getattr(error, "status_code", None)

    if status_code == 401:
        _handle_auth_error(console)
    elif status_code == 400:
        _handle_validation_error(console, error)
    elif status_code == 403:
        _handle_permission_error(console, resource_type)
    elif status_code == 404:
        _handle_not_found(console, resource_type, resource_id)
    elif status_code == 409:
        _handle_conflict_error(console, resource_type)
    elif status_code == 429:
        _handle_rate_limit_error(console)
    elif status_code and status_code >= 500:
        _handle_server_error(console, status_code, error)
    else:
        # Network error or unknown
        console.print(f"[red bold]Error:[/red bold] {error}")
        error_str = str(error)
        if "Connection" in error_str or "Connect" in error_str:
            console.print("[yellow]Could not connect to the Magento server.[/yellow]")
            console.print("[dim]Check your MAGENTO_API_URL and network connection.[/dim]")
        elif "Timeout" in error_str:
            console.print("[yellow]Request timed out.[/yellow]")
            console.print("[dim]Try increasing MAGENTO_TIMEOUT or check server load.[/dim]")

    raise typer.Exit(1)


# Legacy alias for compatibility
def handle_magento_error(
    error: Exception, resource_type: str, resource_id: str | None = None
) -> None:
    """Alias for handle_api_error."""
    return handle_api_error(error, resource_type, resource_id)
