"""Logging middleware with structured logging support.

Provides verbose request/response logging with structured format,
request IDs, timing metrics, and configurable output formats.
"""

import json
import time
import uuid
from collections.abc import Awaitable, Callable
from typing import Any

import httpx
from rich import print as rprint


class StructuredLogEntry:
    """Represents a structured log entry.

    Provides consistent logging format with request/response details,
    timing metrics, and correlation IDs.
    """

    def __init__(
        self,
        request_id: str,
        method: str,
        url: str,
        start_time: float,
    ) -> None:
        """Initialize log entry.

        Args:
            request_id: Unique request identifier.
            method: HTTP method.
            url: Request URL.
            start_time: Request start timestamp.
        """
        self.request_id = request_id
        self.method = method
        self.url = url
        self.start_time = start_time
        self.end_time: float | None = None
        self.status_code: int | None = None
        self.error: str | None = None
        self.params: dict[str, Any] | None = None
        self.body_preview: str | None = None

    @property
    def duration_ms(self) -> float:
        """Calculate request duration in milliseconds."""
        end = self.end_time or time.time()
        return (end - self.start_time) * 1000

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON logging."""
        return {
            "request_id": self.request_id,
            "method": self.method,
            "url": self.url,
            "duration_ms": round(self.duration_ms, 2),
            "status_code": self.status_code,
            "error": self.error,
            "params": self.params,
            "body_preview": self.body_preview,
        }

    def to_rich_string(self) -> str:
        """Convert to rich-formatted string for console output."""
        status_str = f"{self.status_code}" if self.status_code else "???"
        duration_str = f"{self.duration_ms:.1f}ms"

        if self.error:
            return f"[{self.request_id}] {self.method} {status_str} ({duration_str}) - ERROR: {self.error}"

        return f"[{self.request_id}] {self.method} {status_str} ({duration_str})"


class LoggingMiddleware:
    """Structured logging middleware for request/response tracking.

    Features:
    - Request IDs for correlation
    - Timing metrics (duration in ms)
    - Structured JSON or rich console output
    - Request/response body preview (truncated)
    - Error tracking

    Example:
        >>> middleware = LoggingMiddleware(verbose=True, json_output=False)
        >>> client = M2Client(config, middlewares=[middleware, ...])
    """

    def __init__(
        self,
        verbose: bool = False,
        json_output: bool = False,
        max_body_preview: int = 500,
        include_params: bool = True,
        include_body: bool = True,
    ) -> None:
        """Initialize logging middleware.

        Args:
            verbose: Whether to enable logging output.
            json_output: If True, output JSON; if False, rich console.
            max_body_preview: Max characters for body preview.
            include_params: Whether to include query params.
            include_body: Whether to include request body preview.
        """
        self.verbose = verbose
        self.json_output = json_output
        self.max_body_preview = max_body_preview
        self.include_params = include_params
        self.include_body = include_body

    def _truncate_preview(self, data: Any) -> str | None:
        """Create truncated preview of data."""
        if data is None:
            return None

        preview = json.dumps(data, default=str) if not isinstance(data, str) else data

        if len(preview) > self.max_body_preview:
            preview = preview[: self.max_body_preview] + "..."

        return preview

    def _create_log_entry(
        self,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> StructuredLogEntry:
        """Create new log entry for request."""
        request_id = str(uuid.uuid4())[:8]

        entry = StructuredLogEntry(
            request_id=request_id,
            method=method,
            url=url,
            start_time=time.time(),
        )

        if self.include_params and kwargs.get("params"):
            entry.params = kwargs["params"]

        if self.include_body and kwargs.get("json"):
            entry.body_preview = self._truncate_preview(kwargs["json"])

        return entry

    def _log_request(self, entry: StructuredLogEntry) -> None:
        """Log outgoing request."""
        if not self.verbose:
            return

        if self.json_output:
            log_data = entry.to_dict()
            log_data["event"] = "request"
            print(json.dumps(log_data))
        else:
            rprint(f"[dim cyan]→ {entry.method} {entry.url}[/dim cyan]")
            if entry.params:
                rprint(f"[dim]  params: {entry.params}[/dim]")
            if entry.body_preview:
                rprint(f"[dim]  body: {entry.body_preview}[/dim]")

    def _log_response(self, entry: StructuredLogEntry, response: httpx.Response) -> None:
        """Log incoming response."""
        if not self.verbose:
            return

        entry.end_time = time.time()
        entry.status_code = response.status_code

        if self.json_output:
            log_data = entry.to_dict()
            log_data["event"] = "response"
            print(json.dumps(log_data))
        else:
            # Color based on status
            if response.status_code < 300:
                color = "green"
            elif response.status_code < 400:
                color = "yellow"
            else:
                color = "red"

            rprint(
                f"[dim {color}]← {entry.status_code} "
                f"({entry.duration_ms:.1f}ms) {entry.url}[/dim {color}]"
            )

    def _log_error(self, entry: StructuredLogEntry, error: Exception) -> None:
        """Log request error."""
        if not self.verbose:
            return

        entry.end_time = time.time()
        entry.error = str(error)

        if self.json_output:
            log_data = entry.to_dict()
            log_data["event"] = "error"
            print(json.dumps(log_data))
        else:
            rprint(f"[dim red]✗ ERROR: {entry.error} ({entry.url})[/dim red]")

    def __call__(
        self,
        handler: Callable[..., httpx.Response],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Sync logging wrapper."""
        entry = self._create_log_entry(method, url, **kwargs)
        self._log_request(entry)

        try:
            response = handler(method, url, **kwargs)
            self._log_response(entry, response)
            return response
        except Exception as e:
            self._log_error(entry, e)
            raise

    async def async_call(
        self,
        handler: Callable[..., Awaitable[httpx.Response]],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Async logging wrapper."""
        entry = self._create_log_entry(method, url, **kwargs)
        self._log_request(entry)

        try:
            response = await handler(method, url, **kwargs)
            self._log_response(entry, response)
            return response
        except Exception as e:
            self._log_error(entry, e)
            raise
