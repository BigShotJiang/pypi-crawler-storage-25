"""Retry middleware — exponential backoff on transient failures."""

import asyncio
import time
from collections.abc import Awaitable, Callable
from typing import Any

import httpx


class RetryMiddleware:
    """Retry failed requests with exponential backoff.

    Retries on: 429 (rate limit), 500-504 (server errors).
    Does NOT retry on: 4xx client errors (except 429).
    """

    def __init__(self, max_retries: int = 3, base_delay: float = 1.0) -> None:
        """Initialize.

        Args:
            max_retries: Maximum number of retry attempts.
            base_delay: Base delay in seconds (doubled each retry).
        """
        self.max_retries = max_retries
        self.base_delay = base_delay

    def _should_retry(self, status_code: int) -> bool:
        """Check if status code warrants a retry."""
        return status_code == 429 or 500 <= status_code <= 504

    def _get_retry_delay(self, attempt: int, response: httpx.Response | None = None) -> float:
        """Calculate delay before next retry.

        Respects Retry-After header if present on 429 responses.
        """
        if response is not None:
            retry_after = response.headers.get("Retry-After")
            if retry_after:
                try:
                    return float(retry_after)
                except ValueError:
                    pass
        return self.base_delay * (2**attempt)  # type: ignore[no-any-return]

    def __call__(
        self,
        handler: Callable[..., httpx.Response],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Sync retry with exponential backoff."""
        last_response: httpx.Response | None = None
        for attempt in range(self.max_retries + 1):
            response = handler(method, url, **kwargs)
            if not self._should_retry(response.status_code) or attempt == self.max_retries:
                return response
            last_response = response
            delay = self._get_retry_delay(attempt, response)
            time.sleep(delay)
        return last_response  # type: ignore[return-value]

    async def async_call(
        self,
        handler: Callable[..., Awaitable[httpx.Response]],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Async retry with exponential backoff."""
        last_response: httpx.Response | None = None
        for attempt in range(self.max_retries + 1):
            response = await handler(method, url, **kwargs)
            if not self._should_retry(response.status_code) or attempt == self.max_retries:
                return response
            last_response = response
            delay = self._get_retry_delay(attempt, response)
            await asyncio.sleep(delay)
        return last_response  # type: ignore[return-value]
