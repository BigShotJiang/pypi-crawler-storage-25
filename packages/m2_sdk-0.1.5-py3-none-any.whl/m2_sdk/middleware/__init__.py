"""Middleware pipeline for request/response processing.

Middleware wraps each HTTP request in a pipeline: logging → auth → retry → error.
Each middleware receives a handler callable and returns the final httpx.Response.
"""

from collections.abc import Awaitable, Callable
from typing import Any, Protocol

import httpx


class Middleware(Protocol):
    """Middleware protocol. Each middleware wraps the next handler."""

    def __call__(
        self,
        handler: Callable[..., httpx.Response],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response: ...

    async def async_call(
        self,
        handler: Callable[..., Awaitable[httpx.Response]],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response: ...


def build_pipeline(
    middlewares: list[Middleware],
    final_handler: Callable[..., httpx.Response],
) -> Callable[..., httpx.Response]:
    """Build sync middleware pipeline wrapping a final handler.

    Pipeline order: first middleware in list is outermost (called first).
    """
    handler = final_handler
    for mw in reversed(middlewares):
        handler = _wrap_sync(mw, handler)
    return handler


def build_async_pipeline(
    middlewares: list[Middleware],
    final_handler: Callable[..., Awaitable[httpx.Response]],
) -> Callable[..., Awaitable[httpx.Response]]:
    """Build async middleware pipeline wrapping a final handler."""
    handler = final_handler
    for mw in reversed(middlewares):
        handler = _wrap_async(mw, handler)
    return handler


def _wrap_sync(
    mw: Middleware,
    next_handler: Callable[..., httpx.Response],
) -> Callable[..., httpx.Response]:
    """Wrap a handler with sync middleware."""

    def wrapper(method: str, url: str, **kwargs: Any) -> httpx.Response:
        return mw(next_handler, method, url, **kwargs)

    return wrapper


def _wrap_async(
    mw: Middleware,
    next_handler: Callable[..., Awaitable[httpx.Response]],
) -> Callable[..., Awaitable[httpx.Response]]:
    """Wrap a handler with async middleware."""

    async def wrapper(method: str, url: str, **kwargs: Any) -> httpx.Response:
        return await mw.async_call(next_handler, method, url, **kwargs)

    return wrapper
