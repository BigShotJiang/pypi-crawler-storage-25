"""Error middleware — maps HTTP errors to typed exceptions."""

import json
from collections.abc import Awaitable, Callable
from typing import Any, NoReturn

import httpx

from m2_sdk.exceptions import APIError, AuthError


class ErrorMiddleware:
    """Convert httpx errors and error status codes to typed exceptions.

    Raises AuthError on 401, APIError on other HTTP errors.
    """

    def _raise_error(self, response: httpx.Response) -> NoReturn:
        """Raise appropriate exception for error response."""
        status_code = response.status_code
        error_body = response.text

        if status_code == 401:
            try:
                error_json = response.json()
                if "resources" in error_json.get("parameters", {}):
                    resource = error_json["parameters"]["resources"]
                    raise AuthError(
                        f"Permission denied: Your token doesn't have access to '{resource}'. "
                        f"Check your Magento Admin user role permissions."
                    )
            except (json.JSONDecodeError, KeyError):
                pass
            raise AuthError(
                "Authentication failed. Token may be expired or invalid. "
                "Run 'm2 auth login' to get a new token."
            )

        # Parse Magento error format
        try:
            error_json = response.json()
            if "message" in error_json:
                message = error_json["message"]
            elif "messages" in error_json:
                message = str(error_json["messages"])
            else:
                message = str(error_json)
        except Exception:
            message = error_body or f"HTTP {status_code}"

        # Helpful messages for common issues
        if status_code == 404 and "does not match any route" in message.lower():
            message = (
                "API endpoint not found.\n\n"
                "This usually means:\n"
                "  1. The API endpoint doesn't exist\n"
                "  2. The extension/module providing this endpoint is not installed\n"
                "  3. The URL path is incorrect\n\n"
                "Try: m2 --help to see available commands"
            )
        elif status_code == 400 and "fieldname" in message.lower():
            message = (
                "Missing required field in request\n\n"
                "The API expects certain fields that weren't provided. "
                "Check the command help with: m2 <command> --help"
            )

        raise APIError(
            message=message,
            status_code=status_code,
            response_body=error_body,
        )

    def __call__(
        self,
        handler: Callable[..., httpx.Response],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Sync: check response status, raise on errors."""
        try:
            response = handler(method, url, **kwargs)
        except httpx.HTTPStatusError as e:
            self._raise_error(e.response)
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {e}") from e

        if response.status_code >= 400:
            self._raise_error(response)
        return response

    async def async_call(
        self,
        handler: Callable[..., Awaitable[httpx.Response]],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Async: check response status, raise on errors."""
        try:
            response = await handler(method, url, **kwargs)
        except httpx.HTTPStatusError as e:
            self._raise_error(e.response)
        except httpx.RequestError as e:
            raise APIError(f"Request failed: {e}") from e

        if response.status_code >= 400:
            self._raise_error(response)
        return response
