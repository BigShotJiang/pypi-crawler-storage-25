"""Auth middleware — injects Bearer token into requests."""

import time
from collections.abc import Awaitable, Callable
from typing import Any

import httpx


class AuthMiddleware:
    """Inject Authorization header and handle 401 token refresh."""

    def __init__(
        self, get_token: Callable[[], str | None], refresh_token: Callable[[], str]
    ) -> None:
        """Initialize.

        Args:
            get_token: Callable returning current token (or None).
            refresh_token: Callable to acquire a fresh token.
        """
        self._get_token = get_token
        self._refresh_token = refresh_token
        self._token: str | None = None
        self._token_acquired_at: float = 0

    def _ensure_token(self, force_refresh: bool = False) -> str:
        """Get a valid token, refreshing if needed."""
        if self._token is None or force_refresh:
            self._token = (
                self._refresh_token()
                if force_refresh
                else (self._get_token() or self._refresh_token())
            )
            self._token_acquired_at = time.time()
        return self._token

    def _inject_headers(
        self, kwargs: dict[str, Any], force_refresh: bool = False
    ) -> dict[str, Any]:
        """Add Authorization header to request kwargs."""
        headers = dict(kwargs.get("headers", {}))
        headers["Authorization"] = f"Bearer {self._ensure_token(force_refresh=force_refresh)}"
        headers.setdefault("Content-Type", "application/json")
        headers.setdefault("Accept", "application/json")
        kwargs["headers"] = headers
        return kwargs

    def __call__(
        self,
        handler: Callable[..., httpx.Response],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Sync: inject token, retry once on 401 with fresh token."""
        self._inject_headers(kwargs)
        response = handler(method, url, **kwargs)
        if response.status_code == 401:
            self._inject_headers(kwargs, force_refresh=True)
            response = handler(method, url, **kwargs)
        return response

    async def async_call(
        self,
        handler: Callable[..., Awaitable[httpx.Response]],
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Async: inject token, retry once on 401 with fresh token."""
        self._inject_headers(kwargs)
        response = await handler(method, url, **kwargs)
        if response.status_code == 401:
            self._inject_headers(kwargs, force_refresh=True)
            response = await handler(method, url, **kwargs)
        return response
