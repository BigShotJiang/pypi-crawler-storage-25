"""Decorators and utilities for command modules.

Provides reusable patterns to eliminate code duplication
in command implementations.
"""

from collections.abc import Callable
from functools import wraps
from typing import Concatenate, ParamSpec, TypeVar

from m2_sdk.client import M2Client
from m2_sdk.config import get_config

P = ParamSpec("P")
T = TypeVar("T")


def with_m2_client(
    func: Callable[Concatenate[M2Client, P], T],
) -> Callable[P, T]:
    """Decorator to inject M2Client into command functions.

    Eliminates the repetitive boilerplate of:
    - Getting config
    - Creating auth manager
    - Creating client with context manager

    Example::

        @with_m2_client
        def list_products(client: M2Client, ...) -> None:
            response = client.products().limit(10).get()
            format_and_print(response)
    """

    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
        from m2_sdk.auth import AuthManager

        config = get_config()
        auth_manager = AuthManager(config)
        with M2Client(config, auth_manager) as client:
            return func(client, *args, **kwargs)

    # Mark this function as having the client injected so Typer knows
    # not to treat 'client' as a CLI parameter
    wrapper.__inject_m2_client__ = True  # type: ignore[attr-defined]

    return wrapper


def with_error_handling(
    resource_type: str,
) -> Callable[[Callable[P, None]], Callable[P, None]]:
    """Decorator to add standardized error handling to commands.

    Args:
        resource_type: Type of resource being operated on (product, order, etc.)

    Example::

        @with_error_handling("product")
        def get_product(...) -> None:
            ...
    """

    def decorator(func: Callable[P, None]) -> Callable[P, None]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> None:
            from m2_sdk.smart_utils import handle_api_error

            try:
                func(*args, **kwargs)
            except Exception as e:
                # Extract resource_id from kwargs if present
                resource_id = None
                if args and isinstance(args[0], (str, int)):
                    resource_id = str(args[0])
                elif "sku" in kwargs:
                    resource_id = str(kwargs["sku"])
                elif "id" in kwargs:
                    resource_id = str(kwargs["id"])

                handle_api_error(e, resource_type, resource_id)

        return wrapper

    return decorator
