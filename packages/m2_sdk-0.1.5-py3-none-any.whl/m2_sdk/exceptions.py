"""Shared exception classes for m2-sdk."""

from typing import Any


class APIError(Exception):
    """API request error with details."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response_body: str | None = None,
        request_info: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body
        self.request_info = request_info or {}


class AuthError(Exception):
    """Authentication error."""

    pass


class NotFoundError(APIError):
    """Resource not found (404)."""

    def __init__(
        self,
        message: str,
        resource_type: str | None = None,
        resource_id: str | None = None,
    ) -> None:
        super().__init__(message, status_code=404)
        self.resource_type = resource_type
        self.resource_id = resource_id


class ConflictError(APIError):
    """Resource conflict (409)."""

    def __init__(
        self,
        message: str,
        resource_type: str | None = None,
        resource_id: str | None = None,
    ) -> None:
        super().__init__(message, status_code=409)
        self.resource_type = resource_type
        self.resource_id = resource_id


class ValidationError(APIError):
    """Validation error (400)."""

    def __init__(
        self,
        message: str,
        field_errors: dict[str, str] | None = None,
    ) -> None:
        super().__init__(message, status_code=400)
        self.field_errors = field_errors or {}


class RateLimitError(APIError):
    """Rate limit exceeded (429)."""

    def __init__(self, message: str, retry_after: int | None = None) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class ServerError(APIError):
    """Server error (5xx)."""

    def __init__(self, message: str, status_code: int = 500) -> None:
        super().__init__(message, status_code=status_code)
