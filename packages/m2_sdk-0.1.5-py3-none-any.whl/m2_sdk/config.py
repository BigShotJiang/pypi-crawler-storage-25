"""Configuration management for m2-sdk.

Simple environment-based configuration.
"""

from pathlib import Path

from dotenv import load_dotenv
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

# Load .env file from project root or current directory
env_locations = [
    Path.cwd() / ".env",
    Path(__file__).parent.parent.parent / ".env",
    Path.home() / ".m2" / ".env",
]

for env_path in env_locations:
    if env_path.exists():
        load_dotenv(env_path, override=True)
        break


class M2Config(BaseSettings):
    """Configuration for Magento 2 CLI.

    Loads from environment variables (prefix: MAGENTO_) and .env file.
    The recommended approach is to set MAGENTO_API_KEY for authentication.
    """

    model_config = SettingsConfigDict(
        env_prefix="MAGENTO_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Authentication - use MAGENTO_API_KEY env variable
    api_key: str | None = Field(
        default=None,
        description="Admin bearer token for API authentication (set via MAGENTO_API_KEY)",
    )
    api_url: str = Field(
        default="http://localhost/rest/V1",
        description="Magento 2 REST API base URL (set via MAGENTO_API_URL)",
    )
    username: str | None = Field(default=None, description="Admin username for token generation")
    password: str | None = Field(default=None, description="Admin password for token generation")

    # Output formatting
    default_format: str = Field(
        default="rich", description="Default output format: rich, json, or raw"
    )
    table_max_width: int = Field(default=120, description="Maximum width for table output")
    table_max_rows: int = Field(default=100, description="Maximum rows to display in table format")

    # HTTP Client settings
    timeout: int = Field(default=30, description="Request timeout in seconds")
    max_retries: int = Field(default=3, description="Maximum number of retries for failed requests")
    retry_delay: float = Field(default=1.0, description="Delay between retries in seconds")

    # Debug settings
    verbose: bool = Field(default=False, description="Enable verbose output")

    @field_validator("default_format")
    @classmethod
    def validate_format(cls, v: str) -> str:
        """Validate output format."""
        allowed = {"rich", "json", "raw"}
        if v.lower() not in allowed:
            raise ValueError(f"Format must be one of: {allowed}")
        return v.lower()

    @field_validator("api_url")
    @classmethod
    def validate_api_url(cls, v: str) -> str:
        """Validate and normalize API URL."""
        if not v.startswith(("http://", "https://")):
            raise ValueError("API URL must start with http:// or https://")
        # Ensure URL ends with /V1 for Magento REST API
        v = v.rstrip("/")
        if not v.endswith("/V1"):
            v = f"{v}/V1"
        return v

    def get_token(self) -> str | None:
        """Get authentication token from environment variable."""
        return self.api_key

    @property
    def base_url(self) -> str:
        """Alias for api_url for backward compatibility."""
        return self.api_url


def get_config() -> M2Config:
    """Create a fresh configuration instance.

    This creates a new instance each time to ensure clean state.
    """
    return M2Config()
