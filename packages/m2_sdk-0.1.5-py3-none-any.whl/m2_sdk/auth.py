"""Authentication module for Magento 2 REST API.

Uses httpx for token acquisition via the admin/token endpoint.
"""

import httpx
from rich import print as rprint

from m2_sdk.config import M2Config
from m2_sdk.exceptions import AuthError


class AuthManager:
    """Manage authentication tokens for Magento 2 API."""

    def __init__(self, config: M2Config) -> None:
        """Initialize auth manager.

        Args:
            config: Configuration instance.
        """
        self.config = config

    def get_admin_token(self, username: str | None = None, password: str | None = None) -> str:
        """Get admin authentication token (sync).

        Args:
            username: Admin username. Uses config if not provided.
            password: Admin password. Uses config if not provided.

        Returns:
            Bearer token string.

        Raises:
            AuthError: If authentication fails.
        """
        username = username or self.config.username
        password = password or self.config.password

        if not username or not password:
            raise AuthError(
                "Username and password required. "
                "Set MAGENTO_USERNAME and MAGENTO_PASSWORD environment variables."
            )

        try:
            with httpx.Client(timeout=self.config.timeout) as client:
                response = client.post(
                    f"{self.config.api_url}/integration/admin/token",
                    json={"username": username, "password": password},
                )
                response.raise_for_status()

            token = response.json()
            if isinstance(token, str):
                return token
            else:
                raise AuthError(f"Unexpected token format: {token}")

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthError("Invalid username or password") from e
            raise AuthError(f"Authentication failed: {e.response.text}") from e
        except httpx.RequestError as e:
            raise AuthError(f"Connection error: {e}") from e

    async def async_get_admin_token(
        self, username: str | None = None, password: str | None = None
    ) -> str:
        """Get admin authentication token (async).

        Args:
            username: Admin username. Uses config if not provided.
            password: Admin password. Uses config if not provided.

        Returns:
            Bearer token string.

        Raises:
            AuthError: If authentication fails.
        """
        username = username or self.config.username
        password = password or self.config.password

        if not username or not password:
            raise AuthError(
                "Username and password required. "
                "Set MAGENTO_USERNAME and MAGENTO_PASSWORD environment variables."
            )

        try:
            async with httpx.AsyncClient(timeout=self.config.timeout) as client:
                response = await client.post(
                    f"{self.config.api_url}/integration/admin/token",
                    json={"username": username, "password": password},
                )
                response.raise_for_status()

            token = response.json()
            if isinstance(token, str):
                return token
            else:
                raise AuthError(f"Unexpected token format: {token}")

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                raise AuthError("Invalid username or password") from e
            raise AuthError(f"Authentication failed: {e.response.text}") from e
        except httpx.RequestError as e:
            raise AuthError(f"Connection error: {e}") from e

    def login(self, username: str | None = None, password: str | None = None) -> str:
        """Login and display success message.

        Args:
            username: Admin username.
            password: Admin password.

        Returns:
            Token string.
        """
        token = self.get_admin_token(username, password)

        # Mask token for display
        masked = f"{token[:10]}...{token[-10:]}" if len(token) > 20 else "..."
        rprint("[green]✓[/green] Authenticated successfully")
        rprint(f"[dim]Token: {masked}[/dim]")
        rprint("\n[yellow]Set this token as environment variable:[/yellow]")
        rprint(f"[bold]export MAGENTO_API_KEY={token}[/bold]")

        return token

    def get_token(self) -> str | None:
        """Get current token from environment."""
        return self.config.get_token()

    def ensure_token(self) -> str:
        """Ensure we have a valid token.

        Returns:
            Valid token string.

        Raises:
            AuthError: If no token available.
        """
        token = self.get_token()
        if not token:
            raise AuthError(
                "No authentication token found. "
                "Set MAGENTO_API_KEY environment variable, or run 'm2 auth login'"
            )
        return token
