"""Catalog-related pydantic models (products, categories, media)."""

from typing import Any

from m2_sdk.models.base import CustomAttribute, MagentoModel, SearchResult


class MediaGalleryEntry(MagentoModel):
    """Product media gallery entry."""

    id: int | None = None
    media_type: str
    label: str
    position: int
    disabled: bool
    types: list[str] = []
    file: str | None = None


class ProductLink(MagentoModel):
    """Product link (related, upsell, crosssell)."""

    sku: str | None = None
    link_type: str | None = None
    linked_product_sku: str | None = None
    linked_product_type: str | None = None
    position: int | None = None


class TierPrice(MagentoModel):
    """Product tier price."""

    customer_group_id: int | None = None
    qty: float | None = None
    value: float | None = None
    website_id: int | None = None


class Product(MagentoModel):
    """Catalog product."""

    id: int | None = None
    sku: str
    name: str | None = None
    attribute_set_id: int | None = None
    price: float | None = None
    status: int | None = None
    visibility: int | None = None
    type_id: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    weight: float | None = None
    website_ids: list[int] = []
    category_links: list[dict[str, Any]] | None = None
    product_links: list[ProductLink] = []
    tier_prices: list[TierPrice] = []
    media_gallery_entries: list[MediaGalleryEntry] = []
    custom_attributes: list[CustomAttribute] = []

    def get_custom_attr(self, code: str) -> str | None:
        """Get custom attribute value by code."""
        for attr in self.custom_attributes:
            if attr.attribute_code == code:
                return str(attr.value) if attr.value is not None else None
        return None


class ProductSearchResult(SearchResult[Product]):
    """Paginated product list response."""

    pass


class Category(MagentoModel):
    """Catalog category."""

    id: int | None = None
    parent_id: int | None = None
    name: str | None = None
    is_active: bool | None = None
    position: int | None = None
    level: int | None = None
    children: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    path: str | None = None
    available_sort_by: list[str] = []
    include_in_menu: bool | None = None
    custom_attributes: list[CustomAttribute] = []


class CategorySearchResult(SearchResult[Category]):
    """Paginated category list response."""

    pass


class ProductAttribute(MagentoModel):
    """Product attribute definition."""

    attribute_code: str | None = None
    frontend_input: str | None = None
    default_value: str | None = None
    is_required: bool | None = None
    options: list[dict[str, Any]] = []
    is_unique: bool | None = None
    is_user_defined: bool | None = None
    frontend_label: str | None = None
    backend_type: str | None = None
    is_searchable: bool | None = None
    is_filterable: bool | None = None
    is_comparable: bool | None = None
    is_used_for_promo_rules: bool | None = None
    is_visible_on_front: bool | None = None
    used_in_product_listing: bool | None = None
