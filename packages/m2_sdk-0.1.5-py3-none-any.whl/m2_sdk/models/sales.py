"""Sales-related pydantic models (Orders, Invoices, Shipments, CreditMemos)."""

from m2_sdk.models.base import MagentoModel, SearchResult


class OrderAddress(MagentoModel):
    """Order address."""

    id: int | None = None
    region: str | None = None
    region_id: int | None = None
    region_code: str | None = None
    country_id: str | None = None
    street: list[str] = []
    company: str | None = None
    telephone: str | None = None
    fax: str | None = None
    postcode: str | None = None
    city: str | None = None
    firstname: str | None = None
    lastname: str | None = None
    middlename: str | None = None
    prefix: str | None = None
    suffix: str | None = None
    vat_id: str | None = None


class OrderPayment(MagentoModel):
    """Order payment information."""

    account_status: str | None = None
    additional_information: list[str] = []
    amount_authorized: float | None = None
    amount_paid: float | None = None
    amount_ordered: float | None = None
    cc_last4: str | None = None
    cc_type: str | None = None
    method: str | None = None
    po_number: str | None = None


class OrderStatusHistory(MagentoModel):
    """Order status history comment."""

    comment: str | None = None
    created_at: str | None = None
    entity_name: str | None = None
    is_customer_notified: int | None = None
    is_visible_on_front: int | None = None
    parent_id: int | None = None
    status: str | None = None


class OrderItem(MagentoModel):
    """Order line item."""

    item_id: int | None = None
    order_id: int | None = None
    sku: str
    name: str | None = None
    product_id: int | None = None
    product_type: str | None = None
    parent_item_id: int | None = None
    price: float | None = None
    original_price: float | None = None
    qty_ordered: float | None = None
    qty_invoiced: float | None = None
    qty_shipped: float | None = None
    qty_canceled: float | None = None
    qty_refunded: float | None = None
    row_total: float | None = None
    tax_amount: float | None = None
    discount_amount: float | None = None
    discount_percent: float | None = None
    weight: float | None = None
    base_price: float | None = None
    base_row_total: float | None = None
    base_tax_amount: float | None = None
    base_discount_amount: float | None = None
    created_at: str | None = None
    updated_at: str | None = None


class Order(MagentoModel):
    """Sales order."""

    entity_id: int | None = None
    increment_id: str | None = None
    state: str | None = None
    status: str | None = None
    customer_id: int | None = None
    customer_email: str | None = None
    customer_firstname: str | None = None
    customer_lastname: str | None = None
    customer_group_id: int | None = None
    grand_total: float | None = None
    base_grand_total: float | None = None
    subtotal: float | None = None
    base_subtotal: float | None = None
    tax_amount: float | None = None
    discount_amount: float | None = None
    shipping_amount: float | None = None
    shipping_description: str | None = None
    total_qty_ordered: float | None = None
    total_item_count: int | None = None
    store_id: int | None = None
    quote_id: int | None = None
    coupon_code: str | None = None
    order_currency_code: str | None = None
    base_currency_code: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    items: list[OrderItem] = []
    billing_address: OrderAddress | None = None
    payment: OrderPayment | None = None
    status_histories: list[OrderStatusHistory] = []

    @property
    def customer_name(self) -> str:
        """Full customer name."""
        parts = [p for p in [self.customer_firstname, self.customer_lastname] if p]
        return " ".join(parts) or self.customer_email or "Unknown"


class OrderSearchResult(SearchResult[Order]):
    """Paginated order list response."""

    pass


class InvoiceItem(MagentoModel):
    """Invoice line item."""

    entity_id: int | None = None
    parent_id: int | None = None
    order_item_id: int | None = None
    qty: float | None = None
    sku: str | None = None
    name: str | None = None
    price: float | None = None
    row_total: float | None = None
    tax_amount: float | None = None
    discount_amount: float | None = None


class InvoiceComment(MagentoModel):
    """Invoice comment."""

    comment: str | None = None
    created_at: str | None = None
    entity_id: int | None = None
    is_customer_notified: int | None = None
    parent_id: int | None = None


class Invoice(MagentoModel):
    """Sales invoice."""

    entity_id: int | None = None
    increment_id: str | None = None
    order_id: int
    state: int | None = None
    grand_total: float | None = None
    base_grand_total: float | None = None
    subtotal: float | None = None
    tax_amount: float | None = None
    discount_amount: float | None = None
    shipping_amount: float | None = None
    total_qty: float
    billing_address_id: int | None = None
    shipping_address_id: int | None = None
    store_id: int | None = None
    created_at: str | None = None
    updated_at: str | None = None
    items: list[InvoiceItem] = []
    comments: list[InvoiceComment] = []


class InvoiceSearchResult(SearchResult[Invoice]):
    """Paginated invoice list response."""

    pass


class ShipmentItem(MagentoModel):
    """Shipment line item."""

    entity_id: int | None = None
    parent_id: int | None = None
    order_item_id: int | None = None
    qty: float | None = None
    sku: str | None = None
    name: str | None = None
    weight: float | None = None


class ShipmentTrack(MagentoModel):
    """Shipment tracking information."""

    entity_id: int | None = None
    parent_id: int | None = None
    order_id: int | None = None
    track_number: str | None = None
    title: str | None = None
    carrier_code: str | None = None
    created_at: str | None = None


class ShipmentComment(MagentoModel):
    """Shipment comment."""

    comment: str | None = None
    created_at: str | None = None
    entity_id: int | None = None
    is_customer_notified: int | None = None
    parent_id: int | None = None


class Shipment(MagentoModel):
    """Sales shipment."""

    entity_id: int | None = None
    increment_id: str | None = None
    order_id: int
    customer_id: int | None = None
    total_qty: float | None = None
    total_weight: float | None = None
    shipment_status: int | None = None
    shipping_label: str | None = None
    store_id: int | None = None
    created_at: str | None = None
    updated_at: str | None = None
    items: list[ShipmentItem] = []
    tracks: list[ShipmentTrack] = []
    comments: list[ShipmentComment] = []


class ShipmentSearchResult(SearchResult[Shipment]):
    """Paginated shipment list response."""

    pass


class CreditMemoItem(MagentoModel):
    """Credit memo line item."""

    entity_id: int | None = None
    parent_id: int | None = None
    order_item_id: int | None = None
    qty: float | None = None
    sku: str | None = None
    name: str | None = None
    price: float | None = None
    row_total: float | None = None
    tax_amount: float | None = None
    discount_amount: float | None = None


class CreditMemoComment(MagentoModel):
    """Credit memo comment."""

    comment: str | None = None
    created_at: str | None = None
    entity_id: int | None = None
    is_customer_notified: int | None = None
    parent_id: int | None = None


class CreditMemo(MagentoModel):
    """Sales credit memo."""

    entity_id: int | None = None
    increment_id: str | None = None
    order_id: int
    invoice_id: int | None = None
    state: int | None = None
    creditmemo_status: int | None = None
    grand_total: float | None = None
    base_grand_total: float | None = None
    subtotal: float | None = None
    tax_amount: float | None = None
    discount_amount: float | None = None
    shipping_amount: float | None = None
    adjustment: float | None = None
    adjustment_positive: float | None = None
    adjustment_negative: float | None = None
    store_id: int | None = None
    created_at: str | None = None
    updated_at: str | None = None
    items: list[CreditMemoItem] = []
    comments: list[CreditMemoComment] = []


class CreditMemoSearchResult(SearchResult[CreditMemo]):
    """Paginated credit memo list response."""

    pass


class CartItem(MagentoModel):
    """Shopping cart line item."""

    item_id: int | None = None
    sku: str | None = None
    qty: float
    name: str | None = None
    price: float | None = None
    product_type: str | None = None
    quote_id: str


class Cart(MagentoModel):
    """Shopping cart (quote)."""

    id: int
    created_at: str | None = None
    updated_at: str | None = None
    converted_at: str | None = None
    is_active: bool | None = None
    is_virtual: bool | None = None
    items: list[CartItem] = []
    items_count: int | None = None
    items_qty: float | None = None
    reserved_order_id: str | None = None
    customer_is_guest: bool | None = None
    customer_note: str | None = None
    store_id: int
