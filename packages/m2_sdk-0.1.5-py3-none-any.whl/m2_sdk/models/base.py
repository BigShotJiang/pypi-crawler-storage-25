"""Base pydantic models for Magento 2 REST API responses."""

from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict

T = TypeVar("T")


class MagentoModel(BaseModel):
    """Base model for all Magento entities. Tolerates extra fields from extension_attributes."""

    model_config = ConfigDict(
        extra="allow",
        populate_by_name=True,
        str_strip_whitespace=True,
    )


class Filter(MagentoModel):
    """Search criteria filter."""

    field: str
    value: str
    condition_type: str | None = None


class FilterGroup(MagentoModel):
    """Search criteria filter group (OR within group, AND between groups)."""

    filters: list[Filter] = []


class SortOrder(MagentoModel):
    """Search criteria sort order."""

    field: str
    direction: str = "ASC"


class SearchCriteria(MagentoModel):
    """Magento SearchCriteria for list/search endpoints."""

    filter_groups: list[FilterGroup] = []
    sort_orders: list[SortOrder] = []
    page_size: int | None = None
    current_page: int | None = None


class CustomAttribute(MagentoModel):
    """Framework attribute interface for custom attributes."""

    attribute_code: str
    value: Any


class ErrorParameter(MagentoModel):
    """Error parameter item."""

    resources: str | None = None
    field_name: str | None = None
    field_value: str | None = None


class ErrorItem(MagentoModel):
    """Individual error in error response."""

    message: str | None = None
    parameters: list[ErrorParameter] = []


class ErrorResponse(MagentoModel):
    """Magento API error response."""

    message: str
    code: int | None = None
    errors: list[ErrorItem] = []
    parameters: dict[str, Any] = {}
    trace: str | None = None


class SearchResult(MagentoModel, Generic[T]):
    """Generic paginated search result wrapper.

    All Magento list endpoints return this structure with items,
    search_criteria, and total_count.
    """

    items: list[T] = []
    search_criteria: SearchCriteria | None = None
    total_count: int = 0
