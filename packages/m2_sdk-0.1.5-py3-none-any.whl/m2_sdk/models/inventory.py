"""Inventory-related pydantic models."""

from m2_sdk.models.base import MagentoModel, SearchResult


class StockItem(MagentoModel):
    """Legacy stock item payload returned by Magento inventory endpoints."""

    sku: str | None = None
    item_id: int | None = None
    product_id: int | None = None
    stock_id: int | None = None
    qty: float | None = None
    is_in_stock: bool | None = None
    is_qty_decimal: bool | None = None
    show_default_notification_message: bool | None = None
    use_config_min_qty: bool | None = None
    min_qty: float | None = None
    use_config_min_sale_qty: int | None = None
    min_sale_qty: float | None = None
    use_config_max_sale_qty: bool | None = None
    max_sale_qty: float | None = None
    use_config_backorders: bool | None = None
    backorders: int | None = None
    use_config_notify_stock_qty: bool | None = None
    notify_stock_qty: float | None = None
    use_config_qty_increments: bool | None = None
    qty_increments: float | None = None
    use_config_enable_qty_inc: bool | None = None
    enable_qty_increments: bool | None = None
    use_config_manage_stock: bool | None = None
    manage_stock: bool | None = None
    low_stock_date: str | None = None
    is_decimal_divided: bool | None = None
    stock_status_changed_auto: int | None = None


class StockItemSearchResult(SearchResult[StockItem]):
    """Paginated stock item list response."""

    pass
