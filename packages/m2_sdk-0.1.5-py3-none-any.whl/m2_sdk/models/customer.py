"""Customer-related pydantic models."""

from m2_sdk.models.base import CustomAttribute, MagentoModel, SearchResult


class CustomerAddress(MagentoModel):
    """Customer address."""

    id: int | None = None
    customer_id: int | None = None
    region: str | None = None
    region_id: int | None = None
    region_code: str | None = None
    country_id: str | None = None
    street: list[str] = []
    company: str | None = None
    telephone: str | None = None
    fax: str | None = None
    postcode: str | None = None
    city: str | None = None
    firstname: str | None = None
    lastname: str | None = None
    middlename: str | None = None
    prefix: str | None = None
    suffix: str | None = None
    vat_id: str | None = None
    default_shipping: bool | None = None
    default_billing: bool | None = None
    custom_attributes: list[CustomAttribute] = []


class Customer(MagentoModel):
    """Customer account."""

    id: int | None = None
    group_id: int | None = None
    default_billing: str | None = None
    default_shipping: str | None = None
    confirmation: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    created_in: str | None = None
    dob: str | None = None
    email: str
    firstname: str
    lastname: str
    middlename: str | None = None
    prefix: str | None = None
    suffix: str | None = None
    gender: int | None = None
    store_id: int | None = None
    taxvat: str | None = None
    website_id: int | None = None
    addresses: list[CustomerAddress] = []
    disable_auto_group_change: int | None = None
    custom_attributes: list[CustomAttribute] = []

    @property
    def full_name(self) -> str:
        """Full customer name."""
        parts = [p for p in [self.firstname, self.middlename, self.lastname] if p]
        return " ".join(parts)


class CustomerSearchResult(SearchResult[Customer]):
    """Paginated customer list response."""

    pass


class CustomerGroup(MagentoModel):
    """Customer group."""

    id: int | None = None
    code: str | None = None
    tax_class_id: int | None = None
