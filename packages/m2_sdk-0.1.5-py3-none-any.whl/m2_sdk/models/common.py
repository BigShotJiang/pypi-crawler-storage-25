"""Common/shared pydantic models used across Magento domains."""

from m2_sdk.models.base import CustomAttribute, MagentoModel


class Region(MagentoModel):
    """Directory region information."""

    id: str | None = None
    code: str | None = None
    name: str | None = None


class Country(MagentoModel):
    """Directory country information."""

    id: str | None = None
    two_letter_abbreviation: str | None = None
    three_letter_abbreviation: str | None = None
    full_name_locale: str | None = None
    full_name_english: str | None = None
    available_regions: list[Region] | None = None


class Address(MagentoModel):
    """Base address model used by customer addresses and order addresses."""

    id: int | None = None
    region: str | None = None
    region_id: int | None = None
    region_code: str | None = None
    country_id: str | None = None
    street: list[str] = []
    company: str | None = None
    telephone: str | None = None
    fax: str | None = None
    postcode: str | None = None
    city: str | None = None
    firstname: str | None = None
    lastname: str | None = None
    middlename: str | None = None
    prefix: str | None = None
    suffix: str | None = None
    vat_id: str | None = None
    default_shipping: bool | None = None
    default_billing: bool | None = None
    custom_attributes: list[CustomAttribute] = []
