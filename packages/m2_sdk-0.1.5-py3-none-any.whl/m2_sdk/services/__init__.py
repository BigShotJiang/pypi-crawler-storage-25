"""High-level Magento API services for common operations.

Provides easy-to-use services for batch operations, media management,
configurable products, and inventory with automatic pagination,
retries, and structured logging.

Example:
    >>> from m2_sdk.services import ProductService, MediaService
    >>> from m2_cli import M2Client
    >>>
    >>> client = M2Client(config)
    >>> products = ProductService(client)
    >>>
    >>> # Batch get with automatic pagination
    >>> for product in products.iter_all(batch_size=100):
    ...     print(product.sku)
    >>>
    >>> # Get specific SKUs efficiently
    >>> products_map = products.get_by_skus(["SKU-001", "SKU-002"])
    >>>
    >>> # Upsert with full conflict handling
    >>> result = products.upsert({
    ...     "sku": "SKU-001",
    ...     "name": "Updated Name",
    ...     "price": 99.99
    ... })
"""

from typing import Any

from m2_sdk.services.batch_service import BatchService
from m2_sdk.services.configurable_service import ConfigurableProductService
from m2_sdk.services.inventory_service import InventoryService
from m2_sdk.services.media_service import MediaService
from m2_sdk.services.product_service import ProductService

__all__ = [
    "BatchService",
    "ConfigurableProductService",
    "InventoryService",
    "MediaService",
    "ProductService",
]


def get_all_services(client: Any) -> dict[str, Any]:
    """Create all service instances for a client.

    Args:
        client: M2Client instance.

    Returns:
        Dictionary of all services keyed by service name.
    """
    return {
        "batch": BatchService(client),
        "products": ProductService(client),
        "media": MediaService(client),
        "inventory": InventoryService(client),
        "configurable": ConfigurableProductService(client),
    }
