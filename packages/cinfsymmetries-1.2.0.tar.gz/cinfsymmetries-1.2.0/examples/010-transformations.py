import sympy as sp
from cinfsymmetries import Chart, VectorField, Transformation

def example_transformations():
    print("\n--- Example: Transformations and Pullbacks ---")
    
    # 1. Define Charts
    C1 = Chart(['x', 'y'])
    x, y = C1.coords
    
    C2 = Chart(['u', 'v'])
    u, v = C2.coords
    
    # Define a transformation phi: C1 -> C2
    # u = x + y, v = x * y
    phi = C1.map_to(C2, {u: x + y, v: x * y})
    
    print(f"Source Chart: {C1}")
    print(f"Target Chart: {C2}")
    print(f"Transformation: u = {phi.expressions[u]}, v = {phi.expressions[v]}")
    
    # 2. Pullback of a function
    f = u**2 + v
    f_star = phi.pullback_function(f)
    print(f"\nPullback of function f(u,v) = {f}:")
    print(f"phi^* f = {f_star}")
    
    # 3. Pullback of a differential form
    omega = C2.diff_form(1, {(u,): v, (v,): 1}) # omega = v du + dv
    omega_star = phi.pullback_form(omega)
    print(f"\nPullback of 1-form omega = {omega}:")
    print(f"phi^* omega = {omega_star}")
    
    # 4. Pushforward of a vector field
    X = VectorField({x: 1, y: -1})
    X_push = phi.pushforward_vector_field(X)
    print(f"\nPushforward of vector field X = {X}:")
    print(f"phi_* X = {X_push}")
    # Note: Components are in source variables unless inverted
    
    # 5. Pullback of a vector field (for coordinate change)
    # Let's use a simpler linear map for easy verification
    L1 = Chart(['x1', 'x2'])
    L2 = Chart(['y1', 'y2'])
    x1, x2 = L1.coords
    y1, y2 = L2.coords
    
    psi = L1.map_to(L2, {y1: x1 + x2, y2: x1 - x2})
    Y = VectorField({y1: 1, y2: 1}) # Y = d/dy1 + d/dy2
    
    Y_star = psi.pullback_vector_field(Y)
    print(f"\nPullback of vector field Y = {Y} under linear map:")
    print(f"psi^* Y = {Y_star}")
    # y1 = x1 + x2, y2 = x1 - x2 => x1 = (y1+y2)/2, x2 = (y1-y2)/2
    # d/dy1 + d/dy2 = (1/2 d/dx1 + 1/2 d/dx2) + (1/2 d/dx1 - 1/2 d/dx2) = d/dx1
    
if __name__ == "__main__":
    example_transformations()
