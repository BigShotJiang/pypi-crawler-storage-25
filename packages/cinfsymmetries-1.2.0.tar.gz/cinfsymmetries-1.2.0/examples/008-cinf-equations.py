import sympy as sp
from cinfsymmetries import VectorField, Distribution, Chart, get_cinf_determining_equations

def example_cinf_equations_1st_order():
    print("\n--- 1. C-inf Symmetry Equations (u' = 0) ---")
    x, u = sp.symbols('x u')
    chart = Chart([x, u])
    D = Distribution([VectorField({x: 1})])
    
    # Define a candidate X with unknown components
    xi_x = sp.Function('xi_x')(x, u)
    xi_u = sp.Function('xi_u')(x, u)
    X = VectorField({x: xi_x, u: xi_u})
    
    print("Deriving C-inf symmetry determining equations for D = <d/dx>:")
    eqs = get_cinf_determining_equations(D, X, chart)
    
    print(f"Found {len(eqs)} equations.")
    if not eqs:
        print("  (Every vector field is a C-inf symmetry for a rank n-1 distribution)")

def example_cinf_equations_rank_1_in_3d():
    print("\n--- 2. C-inf Symmetry Equations for Rank 1 in 3D ---")
    x, y, z = sp.symbols('x y z')
    chart = Chart([x, y, z])
    D = Distribution([VectorField({x: 1})])
    
    # Candidate X with unknown components
    xi_x = sp.Function('xi_x')(x, y, z)
    xi_y = sp.Function('xi_y')(x, y, z)
    xi_z = sp.Function('xi_z')(x, y, z)
    X = VectorField({x: xi_x, y: xi_y, z: xi_z})
    
    print("Deriving C-inf symmetry determining equations for D = <d/dx> in 3D:")
    eqs = get_cinf_determining_equations(D, X, chart)
    
    print(f"Found {len(eqs)} equations:")
    for i, eq in enumerate(eqs):
        print(f"  {i+1}: {eq} = 0")

def example_cinf_equations_with_ansatz():
    print("\n--- 3. C-inf Symmetry Equations with an Ansatz ---")
    x, y, z = sp.symbols('x y z')
    chart = Chart([x, y, z])
    D = Distribution([VectorField({x: 1})])
    
    # User-defined ansatz: we assume X has no x-component and y-component is constant 1.
    # X = 0*d/dx + 1*d/dy + f(x,y,z)*d/dz
    f = sp.Function('f')(x, y, z)
    X_ansatz = VectorField({y: 1, z: f})
    
    print("Deriving equations for ansatz X = d/dy + f(x,y,z) d/dz:")
    eqs = get_cinf_determining_equations(D, X_ansatz, chart)
    
    print(f"Found {len(eqs)} equations:")
    for i, eq in enumerate(eqs):
        print(f"  {i+1}: {eq} = 0")
    print("  (Note: This requires df/dx = 0, meaning f depends only on y, z)")

if __name__ == "__main__":
    example_cinf_equations_1st_order()
    example_cinf_equations_rank_1_in_3d()
    example_cinf_equations_with_ansatz()
