import sympy as sp
from cinfsymmetries import Chart, VectorField, LieBracket, Distribution, PfaffianSystem

def example_charts_and_vector_fields():
    print("\n--- 1. Charts and Vector Fields ---")
    # Define a Chart with arbitrary names (theta, phi, r)
    C = Chart(['r', 'theta', 'phi'])
    print(f"Chart C: {C}")
    
    # Unpack the symbols for cleaner expression building
    r, theta, phi = C.coords
    
    # Define a radial vector field R = d/dr
    R = VectorField({r: 1})
    
    # Define a rotational vector field S = d/dtheta + r^2 d/dphi
    S = VectorField({theta: 1, phi: r**2})
    
    print(f"Radial Vector Field R: {R}")
    print(f"Rotational Vector Field S: {S}")
    
    # Compute the Lie Bracket [R, S]
    bracket = LieBracket(R, S)
    print(f"Lie Bracket [R, S]: {bracket}")

def example_distributions_and_pfaffian_systems():
    print("\n--- 2. Distributions and Pfaffian Systems ---")
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # 1. Start with a Pfaffian System: omega = dz - y*dx
    # This represents the contact system in R^3
    omega = C.diff_form(1, {(z,): 1, (x,): -y})
    P = PfaffianSystem([omega], chart=C)
    print(f"Pfaffian System P:\n{P}")
    
    # 2. Get the dual Distribution D
    D = P.get_distribution()
    print(f"Dual Distribution D spanned by:\n{D.vector_fields}")
    # Should be spanned by d/dy and d/dx + y*d/dz
    
    # 3. Verify: omega(X) = 0 for all X in D
    for X in D.vector_fields:
        print(f"  omega({X}) = {omega(X)}")
        
    # 4. Inverse: Start with Distribution and get Pfaffian System
    P_dual = D.get_pfaffian_system(chart=C)
    print(f"Dual Pfaffian System P_dual:\n{P_dual}")

if __name__ == "__main__":
    example_charts_and_vector_fields()
    example_distributions_and_pfaffian_systems()
