import sys
import sympy as sp
import os

# Add parent directory to path to allow running from examples folder
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from cinfsymmetries.core import Chart, VectorField, Distribution

def main():
    print("================================================================")
    print("Example 9: Adapted Basis for the Dual Pfaffian System")
    print("================================================================\n")
    
    # Define a chart with coordinates (x, y, z)
    print("1. Defining the coordinate chart (x, y, z)...")
    C = Chart(['x', 'y', 'z'])
    x, y, z = C.coords
    
    # Define a 1-dimensional distribution D
    print("2. Defining the distribution D = span{ Z_1 }...")
    Z1 = VectorField({x: 1, z: y})
    D = Distribution([Z1])
    print(f"   Z_1 = {Z1}")
    
    # Define a C^inf-structure for D
    print("\n3. Providing a C^inf-structure [X_1, X_2] for D...")
    X1 = VectorField({y: 1})
    X2 = VectorField({z: 1})
    X_list = [X1, X2]
    print(f"   X_1 = {X1}")
    print(f"   X_2 = {X2}")
    
    # Compute the adapted basis
    print("\n4. Computing the adapted basis for the dual Pfaffian system...")
    print("   This uses the interior product formula on the volume form.")
    basis = D.get_adapted_pfaffian_basis(X_list, chart=C)
    
    omega_1, omega_2 = basis
    print(f"\n   omega_1 = {omega_1}")
    print(f"   omega_2 = {omega_2}")
    
    # Verify the results mathematically
    print("\n5. Verifying the mathematical properties:")
    print("   Property 1: omega_i(Z_a) = 0 for all Z_a in D")
    print(f"   omega_1(Z_1) = {omega_1(Z1)}  -> {'OK' if sp.simplify(omega_1(Z1)) == 0 else 'FAIL'}")
    print(f"   omega_2(Z_1) = {omega_2(Z1)}  -> {'OK' if sp.simplify(omega_2(Z1)) == 0 else 'FAIL'}")
    
    print("\n   Property 2: omega_i(X_j) = delta_ij (Kronecker delta)")
    print(f"   omega_1(X_1) = {omega_1(X1)}  -> {'OK' if sp.simplify(omega_1(X1)) == 1 else 'FAIL'}")
    print(f"   omega_1(X_2) = {omega_1(X2)}  -> {'OK' if sp.simplify(omega_1(X2)) == 0 else 'FAIL'}")
    print(f"   omega_2(X_1) = {omega_2(X1)}  -> {'OK' if sp.simplify(omega_2(X1)) == 0 else 'FAIL'}")
    print(f"   omega_2(X_2) = {omega_2(X2)}  -> {'OK' if sp.simplify(omega_2(X2)) == 1 else 'FAIL'}")
    
if __name__ == "__main__":
    main()
