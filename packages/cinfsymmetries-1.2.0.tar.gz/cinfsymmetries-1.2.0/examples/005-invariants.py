import sympy as sp
from cinfsymmetries import VectorField

def example_invariants():
    print("\n--- Invariants of a Vector Field ---")
    x, y, z = sp.symbols('x y z')
    
    # 1. Translation: X = d/dx + d/dy + d/dz
    X1 = VectorField({x: 1, y: 1, z: 1})
    inv1 = X1.get_invariants()
    print(f"Vector Field X1: {X1}")
    print(f"Invariants of X1: {inv1}")
    
    # 2. Scaling: X = x d/dx + y d/dy + z d/dz
    X2 = VectorField({x: x, y: y, z: z})
    inv2 = X2.get_invariants()
    print(f"Vector Field X2: {X2}")
    print(f"Invariants of X2: {inv2}")
    
    # 3. Mixed: X = d/dx + 2 d/dy
    X3 = VectorField({x: 1, y: 2})
    inv3 = X3.get_invariants()
    print(f"Vector Field X3: {X3}")
    print(f"Invariants of X3: {inv3}")

if __name__ == "__main__":
    example_invariants()
