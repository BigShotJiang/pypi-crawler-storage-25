import sympy as sp
from cinfsymmetries import Chart, VectorField

def example_differential_forms():
    """
    This example illustrates the core functionalities for working with differential forms
    in the cinfsymmetries library, including exterior products, derivatives, 
    and contractions.
    """
    print("\n" + "="*50)
    print("EXAMPLE 002: DIFFERENTIAL FORMS AND CARTAN'S FORMULA")
    print("="*50)

    # 1. Define a 3D coordinate chart
    C = Chart(['x', 'y', 'z'])
    C.inject(globals()) # Injects x, y, z into the global namespace
    print(f"\n[1] Defined Chart: {C}")
    
    # 2. Creating Differential Forms
    # A 1-form omega = y*dx + x*dy + dz
    # Components are defined as a dictionary mapping tuples of coordinate symbols to coefficients.
    omega = C.diff_form(1, {(x,): y, (y,): x, (z,): 1})
    print(f"\n[2] 1-form omega = {omega}")
    
    # A 1-form alpha = z*dx
    alpha = C.diff_form(1, {(x,): z})
    print(f"    1-form alpha = {alpha}")
    
    # 3. Exterior Product (Wedge Product)
    # The '^' operator implements the wedge product: beta = omega ^ alpha
    beta = omega ^ alpha
    print(f"\n[3] Exterior Product beta = omega ^ alpha:")
    print(f"    beta = {beta}")
    # Note: terms like dy ^ dx are automatically canonicalized to -dx ^ dy
    
    # 4. Exterior Derivative
    # d(omega) for a 1-form omega
    d_omega = omega.d()
    print(f"\n[4] Exterior Derivative d(omega):")
    print(f"    d(omega) = {d_omega}")
    # Since omega = d(xy + z), d(omega) should be 0.
    
    # For a non-exact form: eta = y*dx
    eta = C.diff_form(1, {(x,): y})
    d_eta = eta.d()
    print(f"    For eta = {eta}, d(eta) = {d_eta}")
    
    # 5. Interior Product (Contraction)
    # Define a vector field X = d/dx + d/dy
    X = VectorField({x: 1, y: 1})
    print(f"\n[5] Vector Field X = {X}")
    
    # i_X(beta) - contracting the 2-form beta with vector field X
    contraction = beta.i(X)
    print(f"    Interior Product i_X(beta) = {contraction}")
    
    # 6. Lie Derivative and Cartan's Magic Formula
    # The Lie derivative of a form with respect to a vector field: L_X(eta)
    # Both syntaxes are now supported:
    L_X_eta_v1 = eta.lie_derivative(X)
    L_X_eta_v2 = X.lie_derivative(eta)
    print(f"\n[6] Lie Derivative L_X(eta):")
    print(f"    eta.lie_derivative(X) = {L_X_eta_v1}")
    print(f"    X.lie_derivative(eta) = {L_X_eta_v2}")
    
    # Verify Cartan's Magic Formula: L_X = i_X o d + d o i_X
    term1 = eta.d().i(X)  # i_X(d(eta))
    term2 = eta.i(X).d()  # d(i_X(eta))
    print(f"    Verification via Cartan's Formula (i_X d + d i_X):")
    print(f"      i_X(d(eta)) = {term1}")
    print(f"      d(i_X(eta)) = {term2}")
    print(f"      Sum         = {term1 + term2}")
    
    # 7. Lie Derivative of Vector Fields (Lie Bracket)
    Y = VectorField({z: 1, x: x})
    L_X_Y = X.lie_derivative(Y)
    print(f"\n[7] Lie Derivative of Vector Field Y={Y} along X:")
    print(f"    L_X(Y) = [X, Y] = {L_X_Y}")

    # 8. Evaluation
    # Evaluating a k-form on k vector fields: omega(X1, ..., Xk)
    Z = VectorField({z: 1})
    val = beta(X, Z)
    print(f"\n[8] Evaluation of 2-form beta on X and Z={Z}:")
    print(f"    beta(X, Z) = {val}")

if __name__ == "__main__":
    example_differential_forms()
