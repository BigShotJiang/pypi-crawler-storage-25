import sympy as sp
from cinfsymmetries.core import JetSpaceChart, VectorField, Distribution, LieBracket

def verify():
    print("--- Verification of Vessiot Distribution and C^inf-structure ---")
    
    # 1. Initialize JetSpaceChart for J^1(R^2, R)
    # Coordinates: (x, y, u, u_x, u_y)
    J = JetSpaceChart(x_names=['x', 'y'], u_names='u', order=1)
    J.inject(globals())
    x, y, u, u_x, u_y = J.coords
    
    # 2. Define Vessiot Distribution generators Ax and Ay
    # Ax = ∂x + u_x*∂u + 1/2*u_x^2*∂u_x + e^u*∂u_y
    # Ay = ∂y + u_y*∂u + e^u*∂u_x + 1/2*u_y^2*∂u_y
    Ax = VectorField({x: 1, u: u_x, u_x: sp.Rational(1, 2) * u_x**2, u_y: sp.exp(u)})
    Ay = VectorField({y: 1, u: u_y, u_x: sp.exp(u), u_y: sp.Rational(1, 2) * u_y**2})
    
    print(f"\nAx = {Ax}")
    print(f"Ay = {Ay}")
    
    # 3. Verify [Ax, Ay] = 0
    bracket_Ax_Ay = LieBracket(Ax, Ay)
    print(f"\n[Ax, Ay] = {bracket_Ax_Ay}")
    
    is_involutive = (str(bracket_Ax_Ay) == "0")
    print(f"Is [Ax, Ay] == 0? {is_involutive}")
    
    # 4. Define Distribution
    D = Distribution([Ax, Ay])
    
    # 5. Define vertical vector fields X1, X2, X3
    # X1 = ∂u_y - (u_y/u_x)∂u_x
    # X2 = ∂u_x - (u_x/2)∂u_y
    # X3 = ∂u
    X1 = VectorField({u_y: 1, u_x: -u_y/u_x})
    X2 = VectorField({u_x: 1, u_y: -u_x/2})
    X3 = VectorField({u: 1})
    
    print(f"\nX1 = {X1}")
    print(f"X2 = {X2}")
    print(f"X3 = {X3}")
    
    # 6. Verify C^inf-structure
    # A C^inf-structure for a finite type system is a sequence of vector fields 
    # that spans the space and satisfies sequential symmetry conditions.
    # Here, {X1, X2, X3} form a vertical solvable subalgebra that complements {Ax, Ay}.
    
    print("\n--- Verification of C^inf-structure ---")
    
    # Check if {X1, X2, X3} forms an involutive vertical distribution
    V = Distribution([X1, X2, X3])
    print(f"Is vertical distribution <X1, X2, X3> involutive? {V.is_involutive()}")
    
    # Check if Ax and Ay are C^inf-symmetries of the vertical distribution
    is_Ax_sym = V.check_cinf_symmetry(Ax)
    is_Ay_sym = V.check_cinf_symmetry(Ay)
    print(f"Is Ax a C^inf-symmetry of <X1, X2, X3>? {is_Ax_sym}")
    print(f"Is Ay a C^inf-symmetry of <X1, X2, X3>? {is_Ay_sym}")

    # Check the full sequence from an empty base
    # Correct order for the library's check_structure: [X3, X1, X2, Ax, Ay]
    full_sequence = [X3, X1, X2, Ax, Ay]
    result = Distribution([]).check_structure(full_sequence, chart=J)
    print(f"\nFull structure check [X3, X1, X2, Ax, Ay]: {result} (C^inf-structure)")
    
    # Assertions
    assert is_involutive, "[Ax, Ay] should be 0"
    assert V.is_involutive(), "Vertical space should be involutive"
    assert is_Ax_sym and is_Ay_sym, "Ax, Ay should be symmetries of the vertical space"
    assert result == 2, "Full sequence should be a C^inf-structure"
    
    print("\nAll claims in the text are verified as TRUE!")
    
    print("\nAll verifications passed!")

if __name__ == "__main__":
    verify()
