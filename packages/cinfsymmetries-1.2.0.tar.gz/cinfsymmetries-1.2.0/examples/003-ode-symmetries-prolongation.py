import sympy as sp
from cinfsymmetries import VectorField, Distribution, JetSpaceChart, Prolongation, LambdaProlongation

def example_ode_symmetries_1st_order():
    print("\n--- 1. 1st Order ODE Symmetries (u' = u_x) ---")
    # Define a Jet Space of order 1 (contains x, u, u_x)
    J1 = JetSpaceChart(x_names='x', u_names='u', order=1)
    print(f"Jet Space Chart: {J1}")
    
    # Unpack coordinates
    x, u, u_x = J1.coords
    # u_x = sp.Symbol('u_x') # Wait, unpacking already gives the symbols
    
    # Define the Total Derivative operator D = d/dx + u_x*d/du
    D_op = J1.total_derivative()
    print(f"Total Derivative D: {D_op}")

    # Define a Distribution spanned by the Total Derivative (representing an ODE u' = u_x)
    D1 = Distribution([D_op])

    # Define a Vector Field Y = d/du (Translation in u)
    Y = VectorField({u: 1})
    print(f"Checking if Y = d/du is a symmetry of D: {D1.check_symmetry(Y)}")

def example_ode_symmetries_2nd_order():
    print("\n--- 2. 2nd Order ODE Symmetries (u'' = x*u + u_x) ---")
    # A vector field for a 2nd order ODE lives on J^1
    J = JetSpaceChart(x_names='x', u_names='u', order=1)
    x, u, u_x = J.coords
    
    # A = d/dx + u_x*d/du + (x*u + u_x)*d/du_x
    A = VectorField({x: 1, u: u_x, u_x: x*u + u_x})
    print(f"ODE Vector Field A: {A}")
    
    D = Distribution([A])
    
    # X1 = u*d/du + u_x*d/du_x (Scaling in u)
    X1 = VectorField({u: u, u_x: u_x})
    print(f"X1 = u*d/du + u_x*d/du_x: is symmetry? {D.check_symmetry(X1)}")
    
    # X2 = d/du (Translation in u)
    X2 = VectorField({u: 1})
    print(f"X2 = d/du: is symmetry? {D.check_symmetry(X2)}")

def example_cinf_and_lambda_symmetries():
    print("\n--- 3. C^inf-symmetry and Lambda-symmetries ---")
    # For the ODE u'' = 0, the distribution is spanned by the Total Derivative D.
    J = JetSpaceChart(x_names='x', u_names='u', order=1)
    x, u, u_x = J.coords
    
    # D = d/dx + u_x*d/du
    D_op = VectorField({x: 1, u: u_x})
    Dist = Distribution([D_op])
    print(f"Distribution D: {D_op}")
    
    # 1. A classical Lie symmetry (prolonged): X = d/du
    X_lie = VectorField({u: 1})
    print(f"X = d/du (Lie symmetry):")
    print(f"  Is regular symmetry? {Dist.check_symmetry(X_lie)}")
    print(f"  Is C^inf-symmetry? {Dist.check_cinf_symmetry(X_lie)}")
    
    # 2. A C^inf-symmetry which is NOT a regular symmetry.
    # Consider X = e^x * d/du
    X_cinf = VectorField({u: sp.exp(x)})
    print(f"X = exp(x)*d/du (lambda-symmetry with lambda=-1):")
    print(f"  Is regular symmetry? {Dist.check_symmetry(X_cinf)}")
    print(f"  Is C^inf-symmetry? {Dist.check_cinf_symmetry(X_cinf)}")

def example_automated_prolongation():
    print("\n--- 4. Automated Prolongation ---")
    J = JetSpaceChart(order=2)
    x, u, u_x, u_xx = J.coords
    
    # Define a point symmetry X = u*d/du (Scaling)
    X = VectorField({u: u})
    print(f"Point symmetry X: {X}")
    
    # Standard Prolongation
    prX = Prolongation(X, J)
    print(f"Prolonged pr X: {prX}")
    
    # Lambda-Prolongation with lambda = 1/x
    prX_lambda = LambdaProlongation(X, lambd=1/x, J=J)
    print(f"Lambda-Prolonged (lambda=1/x) pr_lambda X: {prX_lambda}")

    # Check symmetry of u'' = 0 (Distribution spanned by D)
    D_op = J.total_derivative()
    Dist = Distribution([D_op])
    print(f"Is pr X a symmetry of u''=0? {Dist.check_symmetry(prX)}")

if __name__ == "__main__":
    example_ode_symmetries_1st_order()
    example_ode_symmetries_2nd_order()
    example_cinf_and_lambda_symmetries()
    example_automated_prolongation()
