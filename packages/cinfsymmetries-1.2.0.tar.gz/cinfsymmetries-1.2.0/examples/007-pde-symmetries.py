import sympy as sp
from cinfsymmetries import JetSpaceChart, get_determining_equations

def example_pde_heat_equation():
    print("\n--- 1. Heat Equation Symmetries (u_t = u_xx) ---")
    # Define a Jet Space for u = f(t, x) of order 2
    # Coords: (t, x, u, u_t, u_x, u_tt, u_tx, u_xx)
    J = JetSpaceChart(x_names=['t', 'x'], u_names='u', order=2)
    print(f"Jet Space: {J}")
    
    t, x, u, u_t, u_x, u_tt, u_tx, u_xx = J.coords
    
    # Heat equation: u_t - u_xx = 0
    heat_eq = u_t - u_xx
    
    print("Deriving determining equations for the Heat Equation:")
    eqs = get_determining_equations(heat_eq, J)
    
    print(f"Found {len(eqs)} determining equations:")
    for i, eq in enumerate(eqs[:10]): # Print first 10
        print(f"  {i+1}: {eq} = 0")
    if len(eqs) > 10:
        print("  ...")

def example_system_of_odes():
    print("\n--- 2. System of ODEs (u' = v, v' = -u) ---")
    # Harmonic oscillator as a system
    J = JetSpaceChart(x_names='t', u_names=['u', 'v'], order=1)
    t, u, v, u_t, v_t = J.coords
    
    # Equations: u_t - v = 0, v_t + u = 0
    eqs = [u_t - v, v_t + u]
    
    print("Deriving determining equations for the Harmonic Oscillator system:")
    det_eqs = get_determining_equations(eqs, J)
    
    print(f"Found {len(det_eqs)} determining equations.")
    for i, eq in enumerate(det_eqs):
        print(f"  {i+1}: {eq} = 0")

if __name__ == "__main__":
    example_pde_heat_equation()
    example_system_of_odes()
