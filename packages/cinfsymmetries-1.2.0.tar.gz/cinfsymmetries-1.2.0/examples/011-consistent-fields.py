import sympy as sp
from cinfsymmetries import Chart, VectorField, ScalarField

def example_consistent_fields():
    print("\n--- Example: Chart-Aware Objects and ScalarFields ---")
    
    # 1. Define a Chart
    C = Chart(['x', 'y'])
    x, y = C.coords
    
    # 2. Creating ScalarFields (Functions linked to a chart)
    # New way: Use the helper C.scalar_field()
    f = C.scalar_field(x**2 + y)
    print(f"\n[1] ScalarField f = {f}")
    print(f"    Linked to Chart: {f.chart is not None}")
    
    # 3. Convenience methods: .d() on the function itself!
    df = f.d()
    print(f"\n[2] Exterior derivative df = f.d():")
    print(f"    df = {df}")
    
    # 4. Creating VectorFields linked to the chart
    X = C.vector_field({x: 1, y: 2*x})
    print(f"\n[3] VectorField X = {X}")
    print(f"    Linked to Chart: {X.chart is not None}")
    
    # 5. Application X(f) returns a ScalarField
    res = X(f)
    print(f"\n[4] Application res = X(f):")
    print(f"    res = {res}")
    print(f"    res is a ScalarField: {isinstance(res, ScalarField)}")
    
    # 6. Safety Checks
    C2 = Chart(['u', 'v'])
    u, v = C2.coords
    g = C2.scalar_field(u**2)
    
    print("\n[5] Safety Check (Conflicting Charts):")
    try:
        print("    Attempting f + g...")
        h = f + g
    except ValueError as e:
        print(f"    Caught expected error: {e}")
        
    # 7. Backward Compatibility
    # You can still use plain SymPy expressions or chart-less fields
    X_old = VectorField({x: 1}) # No chart link
    print(f"\n[6] Backward Compatibility:")
    print(f"    X_old (no chart) = {X_old}")
    
    # Adding old and new works!
    X_combined = X + X_old
    print(f"    X + X_old = {X_combined}")
    print(f"    Resulting chart: {X_combined.chart}")

if __name__ == "__main__":
    example_consistent_fields()
