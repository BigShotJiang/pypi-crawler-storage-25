import sympy as sp
from cinfsymmetries import JetSpaceChart, get_determining_equations

def example_symmetry_search_lie():
    print("\n--- 1. Lie Symmetry Search (u'' = 0) ---")
    J = JetSpaceChart(order=2)
    x, u, u_x, u_xx = J.coords
    
    # ODE: u_xx = 0
    ode_expr = u_xx
    
    print("Deriving Lie symmetry determining equations for u'' = 0:")
    eqs_lie = get_determining_equations(ode_expr, J)
    for i, eq in enumerate(eqs_lie):
        print(f"  {i+1}: {eq} = 0")

def example_symmetry_search_lambda():
    print("\n--- 2. Lambda-Symmetry Search (u'' = x*u) ---")
    J = JetSpaceChart(order=2)
    x, u, u_x, u_xx = J.coords
    
    ode_expr = u_xx - x*u
    print(f"Deriving lambda-symmetry equations for u'' = x*u with lambda = x:")
    eqs_lambda = get_determining_equations(ode_expr, J, type='lambda', lambd=x)
    for i, eq in enumerate(eqs_lambda):
        print(f"  {i+1}: {eq} = 0")

def example_symmetry_search_linear_ode():
    print("\n--- 3. Symmetry Search for u'' = x*u + u_x ---")
    J = JetSpaceChart(order=2)
    x, u, u_x, u_xx = J.coords
    
    ode_expr = u_xx - (x*u + u_x)
    print(f"Deriving symmetry equations for u'' = x*u + u_x:")
    eqs = get_determining_equations(ode_expr, J)
    for i, eq in enumerate(eqs):
        print(f"  {i+1}: {eq} = 0")

if __name__ == "__main__":
    example_symmetry_search_lie()
    example_symmetry_search_lambda()
    example_symmetry_search_linear_ode()
