import sympy as sp
from cinfsymmetries import Chart, JetSpaceChart, VectorField

def test_chart_basic():
    C = Chart(['x', 'y', 'z'])
    assert isinstance(C.x, sp.Symbol)
    assert C.x == sp.Symbol('x')
    assert C['y'] == sp.Symbol('y')
    
def test_jet_space_chart():
    J = JetSpaceChart(x_name='x', u_name='u', order=2)
    # Vars should be x, u, u1, u2
    assert J.x == sp.Symbol('x')
    assert J.u == sp.Symbol('u')
    assert J.u1 == sp.Symbol('u1')
    assert J.u2 == sp.Symbol('u2')
    
def test_total_derivative():
    J = JetSpaceChart(x_name='x', u_name='u', order=2)
    D = J.total_derivative()
    
    # D = d/dx + u1*d/du + u2*d/du1
    assert D.components[J.x] == 1
    assert D.components[J.u] == J.u1
    assert D.components[J.u1] == J.u2
    assert len(D.components) == 3
    
    # Test application
    expr = J.u**2 + J.x * J.u1
    # D(expr) = 2*u*u1 + 1*u1 + x*u2
    res = D(expr)
    expected = 2*J.u*J.u1 + J.u1 + J.x*J.u2
    assert sp.simplify(res - expected) == 0

def test_jet_space_order_1():
    J = JetSpaceChart(x_name='x', u_name='u', order=1)
    D = J.total_derivative()
    # D = d/dx + u1*d/du
    assert D.components[J.x] == 1
    assert D.components[J.u] == J.u1
    assert len(D.components) == 2
