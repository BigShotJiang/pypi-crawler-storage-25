# cinfsymmetries Manual

This manual provides an overview of the `cinfsymmetries` library, a Python tool for the geometric study of differential equations using `sympy`.

## Table of Contents
1. [Introduction to Vector Fields](#introduction-to-vector-fields)
2. [Creating Vector Fields](#creating-vector-fields)
3. [Lie Brackets](#lie-brackets)
4. [Distributions and Symmetries](#distributions-and-symmetries)
5. [Manifold Charts and Jet Spaces](#manifold-charts-and-jet-spaces)
6. [Prolongations](#prolongations)
7. [C^inf-Symmetries](#cinf-symmetries)
8. [Pfaffian Systems and Dual Distributions](#pfaffian-systems-and-dual-distributions)
9. [Invariants of a Vector Field](#invariants-of-a-vector-field)

---

## Introduction to Vector Fields

In differential geometry, a **Vector Field** $X$ on a manifold is an assignment of a tangent vector to each point. In local coordinates $(x^1, \dots, x^n)$, it is expressed as a first-order linear differential operator:

$$X = \sum_{i=1}^n \xi^i(x) \frac{\partial}{\partial x^i}$$

In `cinfsymmetries`, these are represented by the `VectorField` class.

## Creating Vector Fields

To create a vector field, you provide a dictionary where:
- **Keys** are `sympy` symbols representing the coordinates.
- **Values** are `sympy` expressions representing the coefficients $\xi^i$.

### Basic Example
```python
import sympy as sp
from cinfsymmetries import VectorField

x, y = sp.symbols('x y')

# Define X = d/dx + x*y d/dy
X = VectorField({x: 1, y: x*y})

print(X) # Outputs: (1)*d_x + (x*y)*d_y
```

### Applying to Functions
You can apply a vector field to a function (scalar expression) as a derivation:
```python
f = x**2 + y
result = X(f) # Computes X(f) = 1*(2x) + x*y*(1) = 2x + xy
print(result)
```

## Lie Brackets

The **Lie Bracket** of two vector fields $X$ and $Y$ is another vector field defined by $[X, Y](f) = X(Y(f)) - Y(X(f))$.

```python
from cinfsymmetries import LieBracket

# Define Y = d/dy
Y = VectorField({y: 1})

# Compute [X, Y]
bracket = LieBracket(X, Y)
print(bracket) # Outputs: -(x)*d_y

# Unified Syntax: Lie Derivative of Vector Fields
# L_X(Y) is also [X, Y]
bracket_alt = X.lie_derivative(Y)
print(bracket_alt == bracket) # True
```

## Distributions and Symmetries

A **Distribution** is a sub-bundle of the tangent bundle, usually spanned by a set of vector fields $\{Z_1, \dots, Z_k\}$.

### Checking Involutivity
A distribution is involutive if the Lie bracket of any two fields in the distribution is also in the distribution (Frobenius Theorem).

```python
from cinfsymmetries import Distribution

D = Distribution([X, Y])
print(D.is_involutive())
```

### Checking Symmetries
A vector field $W$ is a **symmetry** of a distribution $D$ if $[W, Z] \in \text{span}(D)$ for all $Z \in D$. If $D$ represents an ODE, this checks for infinitesimal symmetries.

```python
W = VectorField({x: 1})
is_sym = D.check_symmetry(W)
```

## Manifold Charts and Jet Spaces

### Jet Space and Total Derivation

The `Chart` and `JetSpaceChart` classes help manage coordinate systems, especially for high-order differential equations.

```python
from cinfsymmetries import JetSpaceChart

# Create a Jet Space of order 2: (x, u, u_x, u_xx)
J = JetSpaceChart(x_names='x', u_names='u', order=2)

# Get the Total Derivative operator D = d/dx + u_x d/du + u_xx d/du_x
D_op = J.total_derivative()
print(D_op)
```

### Multiple Variables
`JetSpaceChart` supports any number of independent and dependent variables.

```python
# System of PDEs: J^1(R^2, R^2) with coords (x, y, u, v, u_x, u_y, v_x, v_y)
J = JetSpaceChart(x_names=['x', 'y'], u_names=['u', 'v'], order=1)
print(J.coords)
```

### Accessing Coordinate Symbols

When using charts, you need the underlying `sympy` symbols to define vector fields. There are two convenient ways to do this:

#### 1. Unpacking (Recommended)
You can unpack all symbols into local variables in one line. This keeps your code clean and very similar to standard mathematical notation.

```python
# Unpack all symbols for cleaner syntax
x, u, u_x, u_xx = J.coords

# Now you can use them directly
X = VectorField({x: 1, u: u_x, u_x: u_xx})
```

#### 2. Injecting into Globals
For quick scripts or interactive notebooks, you can automatically inject all available coordinates into the current namespace (e.g., `globals()` or `locals()`).

```python
J = JetSpaceChart(order=1)
J.inject(globals()) # Now 'x', 'u', 'u_x' are available as variables

X = VectorField({x: 1, u: u_x})
```

---

## Prolongations

A point vector field $X = \xi \partial_x + \phi \partial_u$ can be **prolonged** to a jet space of order $k$ to handle higher-order derivatives.

### Standard Prolongation

Standard prolongation $pr^{(k)}X$ tracks how the vector field affects derivative variables $u_i$.

```python
from cinfsymmetries import JetSpaceChart, Prolongation

J = JetSpaceChart(order=2)
x, u, u_x, u_xx = J.coords

# Point symmetry: Scaling in u
X = VectorField({u: u})

# Prolong to order 2: pr X = u d/du + u_x d/du_x + u_xx d/du_xx
prX = Prolongation(X, J)
print(prX)
```

### $\lambda$-Prolongation

The **$\lambda$-prolongation** $pr_\lambda^{(k)}X$ is a generalized prolongation used for finding $\lambda$-symmetries. It involves a function (or form) $\lambda$.

```python
from cinfsymmetries import LambdaProlongation

# Use a lambda factor (e.g., lambda = 1/x)
prX_lam = LambdaProlongation(X, lambd=1/x, J=J)
print(prX_lam)
```

## C^inf-Symmetries

The `Distribution.check_cinf_symmetry(X)` method generalizes the standard symmetry check to identify $C^\infty$-symmetries, which include $\lambda$-symmetries.

A vector field $X$ is a $C^\infty$-symmetry of a distribution $\mathcal{D}$ if $[X, Y] \in \mathcal{D} \oplus \text{span}\{X\}$ for all $Y \in \mathcal{D}$.

```python
# Create an ODE distribution spanned by A
A = J.total_derivative()
D = Distribution([A])

# Check if a vector field is a C^inf-symmetry
# This includes point symmetries, Lie-Bäcklund, and lambda-symmetries
is_cinf = D.check_cinf_symmetry(prX)
```

### Deriving Determining Equations
To find the $C^\infty$-symmetries of a distribution, you can use `get_cinf_determining_equations(self, X, chart=None)`. This returns the system of PDEs for the unknown components of a candidate vector field $X$.

```python
from cinfsymmetries import get_cinf_determining_equations

# 1. Define distribution D = <d/dx> in 3D (x, y, z)
x, y, z = sp.symbols('x y z')
D = Distribution([VectorField({x: 1})])

# 2. Define a candidate vector field with an ansatz
# X = d/dy + f(x,y,z) d/dz
f = sp.Function('f')(x, y, z)
X_ansatz = VectorField({y: 1, z: f})

# 3. Get determining equations
eqs = D.get_cinf_determining_equations(X_ansatz)
for eq in eqs:
    print(eq) # Outputs: Derivative(f(x, y, z), x) = 0
```

## Differential Forms

The `DifferentialForm` class allows you to work with $k$-forms, compute exterior derivatives, wedge products, and interior products.

### Creating Differential Forms
You can create a form by providing its degree and a dictionary of components.

```python
from cinfsymmetries import DifferentialForm, Chart

C = Chart(['x', 'y', 'z'])
x, y, z = C.coords

# Define omega = x*dy ^ dz
omega = DifferentialForm(2, {(y, z): x}, chart=C)
```

### Exterior Derivative and Wedge Product
```python
# Compute d(omega) = dx ^ dy ^ dz
d_omega = omega.d()

# Compute wedge product: omega ^ dx
eta = DifferentialForm(1, {(x,): 1}, chart=C)
result = omega.wedge(eta) # x * dy ^ dz ^ dx = x * dx ^ dy ^ dz
```

### Interior Product and Evaluation
```python
from cinfsymmetries import VectorField

X = VectorField({x: 1, y: 0, z: 0})

# Compute interior product i_X(omega)
iota = omega.i(X) 

# Evaluate omega on two vector fields
Y = VectorField({y: 1})
Z = VectorField({z: 1})
val = omega(Y, Z) # Returns x
```

### Lie Derivative
The Lie derivative $\mathcal{L}_X \omega$ is computed using Cartan's magic formula. The library supports a unified syntax for this:

```python
# Both syntaxes return the same results
L_X_omega = omega.lie_derivative(X)
L_X_omega = X.lie_derivative(omega)
```

This works for forms of any degree (1-forms, 2-forms, 3-forms, etc.).

## Symmetry Search and Determining Equations

For a given ODE $u^{(n)} = \omega(x, u, u_1, \dots, u_{n-1})$, you can automatically derive the determining equations for its Lie or $\lambda$-symmetries.

```python
from cinfsymmetries import JetSpaceChart, get_determining_equations

# Define second-order ODE: u_xx = x*u + u_x
J = JetSpaceChart(order=2)
x, u, u_x, u_xx = J.coords
ode_system = u_xx - (x*u + u_x)

# Get determining equations for Lie symmetries
eqs = get_determining_equations(ode_system, J, type='lie')
for eq in eqs:
    print(eq)
```

---

## Pfaffian Systems and Dual Distributions

A **Pfaffian System** is a set of 1-forms $\{\omega^1, \dots, \omega^k\}$. The **dual distribution** $D$ is the set of vector fields annihilated by these forms.

### From Pfaffian System to Distribution
```python
from cinfsymmetries import PfaffianSystem, Chart

C = Chart(['x', 'y', 'z'])
x, y, z = C.coords

# Define omega = dz - y*dx
omega = C.diff_form(1, {(z,): 1, (x,): -y})
P = PfaffianSystem([omega], chart=C)

# Compute dual distribution
D = P.get_distribution()
print(D.vector_fields) # d/dy and d/dx + y*d/dz
```

### From Distribution to Pfaffian System
```python
# Compute dual Pfaffian system from distribution D
P_dual = D.get_pfaffian_system(chart=C)
```

## Invariants of a Vector Field

An **invariant** $I$ of a vector field $X$ satisfies $X(I) = 0$. The `VectorField.get_invariants()` method calculates a basis of independent invariants.

### Translation Invariants
```python
# X = d/dx + d/dy
X = VectorField({x: 1, y: 1})
inv = X.get_invariants() # [x - y]
```

### Scaling Invariants
```python
# X = x d/dx + y d/dy
X = VectorField({x: x, y: y})
inv = X.get_invariants() # [x/y]
```

---

*This manual was updated to include differential forms, symmetry search, Pfaffian systems, and invariants.*
