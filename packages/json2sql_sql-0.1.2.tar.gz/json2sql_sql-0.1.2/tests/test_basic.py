from json2sql import Converter


def test_basic_conversion():
    data = [
        {"id": 1, "name": "Naveen", "address": {"city": "Chennai"}},
        {"id": 2, "name": "Kumar", "address": {"city": "Madurai"}}
    ]

    converter = Converter(data)
    sql = converter.convert("users")

    assert "CREATE TABLE users" in sql
    assert "id INTEGER" in sql
    assert "name TEXT" in sql
    assert "address_city TEXT" in sql
    assert "INSERT INTO users" in sql