# json2sql

A simple Python library to convert JSON data into SQL queries.

## Features

- Auto table creation
- Insert query generation
- Schema detection
- Nested JSON flattening

## Installation

```bash
pip install -r requirements.txt