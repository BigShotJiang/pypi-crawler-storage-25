from typing import Any, Dict


def flatten_json(data: Dict[str, Any], parent_key: str = "", sep: str = "_") -> Dict[str, Any]:
    """
    Flatten nested JSON.
    Example:
    {
        "id": 1,
        "address": {"city": "Chennai"}
    }
    becomes:
    {
        "id": 1,
        "address_city": "Chennai"
    }
    """
    items: Dict[str, Any] = {}

    for key, value in data.items():
        new_key = f"{parent_key}{sep}{key}" if parent_key else key

        if isinstance(value, dict):
            items.update(flatten_json(value, new_key, sep))
        elif isinstance(value, list):
            # Store lists as JSON-like strings in first version
            items[new_key] = str(value)
        else:
            items[new_key] = value

    return items