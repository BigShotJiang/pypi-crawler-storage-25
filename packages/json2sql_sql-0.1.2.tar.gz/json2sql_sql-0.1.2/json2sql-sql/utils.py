import re
from typing import Any


def sanitize_identifier(name: str) -> str:
    """
    Convert any string into a safe SQL identifier.
    Example: 'user name' -> 'user_name'
    """
    if not isinstance(name, str):
        name = str(name)

    name = name.strip().lower()
    name = re.sub(r"[^a-zA-Z0-9_]", "_", name)
    name = re.sub(r"_+", "_", name)

    if not name:
        name = "column"

    if name[0].isdigit():
        name = f"col_{name}"

    return name


def sql_escape(value: Any) -> str:
    """
    Escape Python values for SQL INSERT statements.
    """
    if value is None:
        return "NULL"

    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"

    if isinstance(value, (int, float)):
        return str(value)

    value = str(value).replace("'", "''")
    return f"'{value}'"