from typing import Any, Dict, List

from .exceptions import SchemaDetectionError
from .utils import sanitize_identifier


def detect_sql_type(value: Any) -> str:
    """
    Detect SQL type from Python value.
    """
    if value is None:
        return "TEXT"

    if isinstance(value, bool):
        return "BOOLEAN"

    if isinstance(value, int) and not isinstance(value, bool):
        return "INTEGER"

    if isinstance(value, float):
        return "REAL"

    return "TEXT"


def merge_sql_types(type1: str, type2: str) -> str:
    """
    Merge conflicting SQL types into a safer common type.
    """
    priority = ["BOOLEAN", "INTEGER", "REAL", "TEXT"]

    if type1 == type2:
        return type1

    # If either is TEXT, safest is TEXT
    if "TEXT" in (type1, type2):
        return "TEXT"

    # INTEGER + REAL => REAL
    if {"INTEGER", "REAL"} == {type1, type2}:
        return "REAL"

    # BOOLEAN mixed with anything else => TEXT
    if "BOOLEAN" in (type1, type2):
        return "TEXT"

    return priority[max(priority.index(type1), priority.index(type2))]


def detect_schema(records: List[Dict[str, Any]]) -> Dict[str, str]:
    """
    Detect schema from list of flattened records.
    Returns dict like:
    {
        "id": "INTEGER",
        "name": "TEXT"
    }
    """
    if not records:
        raise SchemaDetectionError("No records found for schema detection.")

    schema: Dict[str, str] = {}

    for record in records:
        for key, value in record.items():
            safe_key = sanitize_identifier(key)
            current_type = detect_sql_type(value)

            if safe_key in schema:
                schema[safe_key] = merge_sql_types(schema[safe_key], current_type)
            else:
                schema[safe_key] = current_type

    return schema