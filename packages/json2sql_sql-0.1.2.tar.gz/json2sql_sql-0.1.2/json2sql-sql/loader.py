import json
from typing import Any, List, Dict

from .exceptions import InvalidJsonError


def load_json(source: str) -> List[Dict[str, Any]]:
    """
    Load JSON data from a file path.

    Supported input:
    - list of dictionaries
    - single dictionary (converted to list with one item)
    """
    try:
        with open(source, "r", encoding="utf-8") as file:
            data = json.load(file)
    except FileNotFoundError as exc:
        raise InvalidJsonError(f"JSON file not found: {source}") from exc
    except json.JSONDecodeError as exc:
        raise InvalidJsonError(f"Invalid JSON format in file: {source}") from exc

    return normalize_json_data(data)


def normalize_json_data(data: Any) -> List[Dict[str, Any]]:
    """
    Normalize JSON input into a list of dictionaries.
    """
    if isinstance(data, dict):
        return [data]

    if isinstance(data, list):
        if all(isinstance(item, dict) for item in data):
            return data
        raise InvalidJsonError("JSON list must contain only objects/dictionaries.")

    raise InvalidJsonError("JSON must be a dictionary or a list of dictionaries.")