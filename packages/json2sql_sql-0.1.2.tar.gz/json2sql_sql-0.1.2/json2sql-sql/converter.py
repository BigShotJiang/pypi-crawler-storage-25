from typing import Any, Dict, List, Optional

from .loader import load_json, normalize_json_data
from .flattener import flatten_json
from .schema import detect_schema
from .generator import generate_create_table_query, generate_insert_queries
from .exporter import export_sql


class Converter:
    """
    Main class for converting JSON data into SQL queries.
    """

    def __init__(self, source: Any, flatten: bool = True, separator: str = "_") -> None:
        """
        source can be:
        - file path to JSON
        - dict
        - list of dicts
        """
        self.source = source
        self.flatten = flatten
        self.separator = separator

        self.records: List[Dict[str, Any]] = []
        self.schema: Dict[str, str] = {}
        self.table_name: Optional[str] = None
        self.create_query: Optional[str] = None
        self.insert_queries: List[str] = []

        self._load_and_prepare()

    def _load_and_prepare(self) -> None:
        if isinstance(self.source, str):
            raw_records = load_json(self.source)
        else:
            raw_records = normalize_json_data(self.source)

        if self.flatten:
            self.records = [flatten_json(record, sep=self.separator) for record in raw_records]
        else:
            self.records = raw_records

        self.schema = detect_schema(self.records)

    def create_table(self, table_name: str) -> str:
        self.table_name = table_name
        self.create_query = generate_create_table_query(table_name, self.schema)
        return self.create_query

    def insert_data(self, table_name: Optional[str] = None) -> List[str]:
        if table_name:
            self.table_name = table_name

        if not self.table_name:
            raise ValueError("Table name is not set. Call create_table(table_name) first.")

        self.insert_queries = generate_insert_queries(self.table_name, self.records, self.schema)
        return self.insert_queries

    def convert(self, table_name: str) -> str:
        """
        Generate full SQL as a single string.
        """
        create_query = self.create_table(table_name)
        insert_queries = self.insert_data()

        sql_parts = [create_query, ""]
        sql_parts.extend(insert_queries)
        return "\n".join(sql_parts)

    def export(self, output_path: str) -> None:
        if not self.create_query:
            raise ValueError("Create query not generated. Call create_table(table_name) first.")

        if not self.insert_queries:
            raise ValueError("Insert queries not generated. Call insert_data() first.")

        export_sql(output_path, self.create_query, self.insert_queries)