from typing import Any, Dict, List

from .utils import sanitize_identifier, sql_escape


def generate_create_table_query(table_name: str, schema: Dict[str, str]) -> str:
    """
    Generate CREATE TABLE query.
    """
    safe_table = sanitize_identifier(table_name)

    columns = []
    for column_name, sql_type in schema.items():
        safe_column = sanitize_identifier(column_name)
        columns.append(f"    {safe_column} {sql_type}")

    columns_sql = ",\n".join(columns)

    return f"CREATE TABLE {safe_table} (\n{columns_sql}\n);"


def generate_insert_queries(table_name: str, records: List[Dict[str, Any]], schema: Dict[str, str]) -> List[str]:
    """
    Generate INSERT INTO queries.
    """
    safe_table = sanitize_identifier(table_name)
    ordered_columns = list(schema.keys())
    queries: List[str] = []

    for record in records:
        values = []
        for column in ordered_columns:
            original_value = None

            for key, value in record.items():
                if sanitize_identifier(key) == column:
                    original_value = value
                    break

            values.append(sql_escape(original_value))

        columns_sql = ", ".join(ordered_columns)
        values_sql = ", ".join(values)

        query = f"INSERT INTO {safe_table} ({columns_sql}) VALUES ({values_sql});"
        queries.append(query)

    return queries