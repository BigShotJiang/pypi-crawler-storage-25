class Json2SqlError(Exception):
    """Base exception for json2sql library."""


class InvalidJsonError(Json2SqlError):
    """Raised when JSON input is invalid."""


class SchemaDetectionError(Json2SqlError):
    """Raised when schema detection fails."""