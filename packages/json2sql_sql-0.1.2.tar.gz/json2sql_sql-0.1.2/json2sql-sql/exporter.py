from typing import List


def export_sql(output_path: str, create_query: str, insert_queries: List[str]) -> None:
    """
    Export SQL queries to a .sql file.
    """
    with open(output_path, "w", encoding="utf-8") as file:
        file.write(create_query + "\n\n")
        for query in insert_queries:
            file.write(query + "\n")