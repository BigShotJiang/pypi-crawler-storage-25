from setuptools import setup, find_packages

setup(
    name="json2sql-sql",
    version="0.1.2",
    description="Convert JSON data into SQL queries",
    author="Your Name",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
)