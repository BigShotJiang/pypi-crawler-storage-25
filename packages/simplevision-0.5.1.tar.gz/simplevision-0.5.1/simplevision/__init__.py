"""SimpleVision — student-friendly Python interface to SimpleVision pipelines.

Typical use::

    from simplevision import Pipeline

    p = Pipeline.load("my_pipeline.simplevision")
    p.run()

    hit = p.outputs.MatchPercentage[0]
    if hit > 0.85:
        print("Match found")

The pipeline definition (steps, params, output bindings) lives entirely
in the ``.simplevision`` JSON. To change a step, open the editor — the
``.py`` file never needs to be regenerated.
"""

from ._version import __version__
from .outputs import Outputs, Point
from .pipeline import Pipeline

__all__ = ["Pipeline", "Outputs", "Point", "__version__"]
