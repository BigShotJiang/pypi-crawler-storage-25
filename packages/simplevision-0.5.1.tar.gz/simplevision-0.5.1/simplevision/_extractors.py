"""Per-(fnId, outputId) extraction functions.

Each entry takes the step's params, the runtime's ApplyResult, and the
final image, and returns the value to set on the Outputs object. The TS
node manifests declare which output ids exist; this table implements
their Python-side computation.

Adding a new output to a node = add one entry here + one entry on the
TS manifest. Both sides must agree on the id.
"""

from __future__ import annotations

from typing import Any, Callable

import cv2
import numpy as np

from .outputs import Point
from .runtime.ops._registry import ApplyResult


# Signature: (params, result, final_image) -> value
Extractor = Callable[[dict[str, Any], ApplyResult, "np.ndarray"], Any]


def _rows(result: ApplyResult) -> list[dict[str, Any]]:
    return result.rows


# --- thr -------------------------------------------------------------------


def _thr_chosen_threshold(
    params: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> float:
    # The runtime stashes the chosen value into a `Threshold` row.
    for row in _rows(result):
        if row.get("metric") == "Threshold":
            v = row.get("value")
            if isinstance(v, (int, float)):
                return float(v)
            # Adaptive mode reports "adaptive" — surface as NaN so students
            # can `math.isnan(...)` check.
            return float("nan")
    # Fall back to the manual lower bound.
    return float(params.get("lower", 0))


# --- calibrate -------------------------------------------------------------


def _calibrate_px_per_mm(
    _params: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> float:
    for row in _rows(result):
        if row.get("metric") == "px/mm":
            return float(row["value"])
    return float("nan")


# --- hist ------------------------------------------------------------------


def _hist_bins(
    _params: dict[str, Any], _result: ApplyResult, img: "np.ndarray"
) -> list[int]:
    # The runtime's hist op only stores mean/stdev in rows. Compute the
    # full 256-bin histogram here from the final (possibly equalised) image.
    gray = img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256]).flatten()
    return [int(x) for x in hist]


# --- blob ------------------------------------------------------------------


def _blob_count(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return sum(1 for r in _rows(result) if r.get("ok", True))


def _blob_centers(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    return [Point(x=float(r["cx"]), y=float(r["cy"])) for r in _rows(result)]


def _blob_areas(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [float(r["area"]) for r in _rows(result)]


# --- particle --------------------------------------------------------------


def _particle_count(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return len(_rows(result))


def _particle_areas(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [float(r["area"]) for r in _rows(result)]


def _particle_perimeters(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [float(r["perim"]) for r in _rows(result)]


def _particle_circularities(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [float(r["circ"]) for r in _rows(result)]


def _particle_centroids(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    return [Point(x=float(r["cx"]), y=float(r["cy"])) for r in _rows(result)]


# --- shapematch ------------------------------------------------------------


def _shapematch_count(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> int:
    return len(_rows(result))


def _shapematch_scores(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    # Sort best-first to match the editor's UI hint.
    rows = sorted(_rows(result), key=lambda r: -float(r.get("score", 0)))
    return [float(r.get("score", 0.0)) for r in rows]


def _shapematch_positions(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    rows = sorted(_rows(result), key=lambda r: -float(r.get("score", 0)))
    return [Point(x=float(r["cx"]), y=float(r["cy"])) for r in rows]


# --- ocr -------------------------------------------------------------------


def _ocr_text(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> str:
    # The OCR op stashes the concatenated string on a synthetic first row
    # labelled "TEXT". Falls back to joining individual word rows if that
    # row is missing (e.g. nothing recognised).
    for row in _rows(result):
        if row.get("label") == "TEXT":
            return str(row.get("text", ""))
    return " ".join(
        str(r.get("text", "")) for r in _rows(result) if r.get("text")
    )


def _ocr_word_count(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return sum(1 for r in _rows(result) if r.get("label", "").startswith("W"))


def _ocr_positions(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    return [
        Point(x=float(r["cx"]), y=float(r["cy"]))
        for r in _rows(result)
        if r.get("label", "").startswith("W")
    ]


def _ocr_scores(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [
        float(r.get("score", 0.0))
        for r in _rows(result)
        if r.get("label", "").startswith("W")
    ]


# --- geomatch --------------------------------------------------------------


def _geomatch_count(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return len(_rows(result))


def _geomatch_positions(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    return [Point(x=float(r["cx"]), y=float(r["cy"])) for r in _rows(result)]


def _geomatch_scores(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [float(r.get("score", 0.0)) for r in _rows(result)]


def _geomatch_angles(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [float(r.get("angle", 0.0)) for r in _rows(result)]


# --- barcode ---------------------------------------------------------------


def _barcode_count(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return sum(1 for r in _rows(result) if r.get("decoded"))


def _barcode_text(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> str:
    return "\n".join(
        str(r.get("text", "")) for r in _rows(result) if r.get("decoded")
    )


def _barcode_positions(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    return [
        Point(x=float(r["cx"]), y=float(r["cy"]))
        for r in _rows(result)
        if r.get("decoded")
    ]


# --- pfilter ---------------------------------------------------------------


def _pfilter_kept(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return sum(1 for r in _rows(result) if r.get("kept"))


def _pfilter_dropped(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return sum(1 for r in _rows(result) if not r.get("kept", True))


def _pfilter_areas(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[float]:
    return [float(r["area"]) for r in _rows(result) if r.get("kept")]


def _pfilter_centroids(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    return [
        Point(x=float(r["cx"]), y=float(r["cy"]))
        for r in _rows(result)
        if r.get("kept")
    ]


# --- qrcode ----------------------------------------------------------------


def _qrcode_count(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> int:
    return sum(1 for r in _rows(result) if r.get("decoded"))


def _qrcode_text(_p: dict[str, Any], result: ApplyResult, _img: "np.ndarray") -> str:
    return "\n".join(
        str(r.get("text", "")) for r in _rows(result) if r.get("decoded")
    )


def _qrcode_positions(
    _p: dict[str, Any], result: ApplyResult, _img: "np.ndarray"
) -> list[Point]:
    return [
        Point(x=float(r["cx"]), y=float(r["cy"]))
        for r in _rows(result)
        if r.get("decoded")
    ]


# --- dispatch table --------------------------------------------------------

EXTRACTORS: dict[tuple[str, str], Extractor] = {
    ("thr", "chosen_threshold"): _thr_chosen_threshold,
    ("calibrate", "px_per_mm"): _calibrate_px_per_mm,
    ("hist", "bins"): _hist_bins,
    ("blob", "count"): _blob_count,
    ("blob", "centers"): _blob_centers,
    ("blob", "areas"): _blob_areas,
    ("particle", "count"): _particle_count,
    ("particle", "areas"): _particle_areas,
    ("particle", "perimeters"): _particle_perimeters,
    ("particle", "circularities"): _particle_circularities,
    ("particle", "centroids"): _particle_centroids,
    ("shapematch", "count"): _shapematch_count,
    ("shapematch", "scores"): _shapematch_scores,
    ("shapematch", "positions"): _shapematch_positions,
    ("ocr", "text"): _ocr_text,
    ("ocr", "wordCount"): _ocr_word_count,
    ("ocr", "positions"): _ocr_positions,
    ("ocr", "scores"): _ocr_scores,
    ("qrcode", "count"): _qrcode_count,
    ("qrcode", "text"): _qrcode_text,
    ("qrcode", "positions"): _qrcode_positions,
    ("pfilter", "kept"): _pfilter_kept,
    ("pfilter", "dropped"): _pfilter_dropped,
    ("pfilter", "areas"): _pfilter_areas,
    ("pfilter", "centroids"): _pfilter_centroids,
    ("barcode", "count"): _barcode_count,
    ("barcode", "text"): _barcode_text,
    ("barcode", "positions"): _barcode_positions,
    ("geomatch", "count"): _geomatch_count,
    ("geomatch", "positions"): _geomatch_positions,
    ("geomatch", "scores"): _geomatch_scores,
    ("geomatch", "angles"): _geomatch_angles,
}
