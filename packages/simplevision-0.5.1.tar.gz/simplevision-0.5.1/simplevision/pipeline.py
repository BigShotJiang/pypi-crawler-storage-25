"""``Pipeline.load(...).run()`` — the student-facing API.

Loads a ``.simplevision`` JSON, executes its steps using the same ops
the editor uses (via ``simplevision.runtime``), and populates an
Outputs object based on the bindings declared in the editor's Output
Control.

Source of the first frame:

- The ``load`` step's params decide where the source comes from (file or
  webcam). The ``path`` param is resolved relative to the ``.simplevision``
  file's directory, so distributing a pipeline + a sample frame as a
  single folder Just Works.
- Pass ``p.run(frame_or_path)`` to override the load step with your own
  image (handy for batch-processing many frames through the same
  pipeline).
"""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

import cv2
import numpy as np

from ._extractors import EXTRACTORS
from .outputs import Outputs
from .runtime import (
    OutputBinding,
    Pipeline as _PipelineSpec,
    Step,
    load_pipeline as _load_pipeline,
)
from .runtime.context import Context
from .runtime.ops import REGISTRY


class Pipeline:
    """Runs a SimpleVision pipeline against an image and exposes named
    measurements via :attr:`outputs`.

    Typical use::

        p = Pipeline.load("my_pipeline.simplevision")
        p.run()
        print(p.outputs)
    """

    def __init__(self, spec: _PipelineSpec, base_dir: Path):
        self._spec = spec
        self._base_dir = base_dir
        self.outputs: Outputs = Outputs()
        self.image: np.ndarray | None = None

    @classmethod
    def load(cls, path: str | Path) -> "Pipeline":
        """Load a pipeline from a ``.simplevision`` JSON file."""
        p = Path(path).resolve()
        spec = _load_pipeline(p)
        return cls(spec=spec, base_dir=p.parent)

    def run(self, source: "str | Path | np.ndarray | None" = None) -> "Pipeline":
        """Execute the pipeline and populate :attr:`outputs`.

        Args:
            source: Optional override for the first frame. If a path, the
                image is read from disk. If a numpy array, it's used
                directly (and the pipeline's load step is skipped). If
                ``None`` (the default), the load step's params decide.

        Returns ``self`` so calls can be chained:
        ``Pipeline.load(...).run().outputs``.
        """
        self.outputs = Outputs()  # fresh on every run

        ctx = self._build_context()
        img = self._initial_image(source, ctx)

        for step in self._spec.steps:
            if not step.enabled:
                continue
            # The load step is handled above; skip when source was provided
            # or when we've already resolved its image from params.
            if step.fnId == "load":
                self._bind_outputs(step, _LoadResult(image=img), img)
                continue
            img = self._execute_step(step, img, ctx)

        self.image = img
        return self

    # --- internals ---------------------------------------------------------

    def _build_context(self) -> Context:
        # The runtime's Context expects a frame_path + out_dir. The lab
        # doesn't write per-step PNGs (we only care about measurements),
        # but a few ops (load, calibrate) read from frame_path or
        # write into ctx.state, so we have to provide one. The frame_path
        # is set later once we know the load source.
        return Context(frame_path=Path("."), out_dir=Path(tempfile.gettempdir()))

    def _initial_image(
        self,
        source: "str | Path | np.ndarray | None",
        ctx: Context,
    ) -> np.ndarray:
        if isinstance(source, np.ndarray):
            return source

        if source is not None:
            path = Path(source)
            if not path.is_absolute():
                path = (self._base_dir / path).resolve()
            ctx.frame_path = path
            return _read_image(path)

        # Fall back to the load step's params.
        load_step = next((s for s in self._spec.steps if s.fnId == "load"), None)
        if load_step is None:
            raise RuntimeError(
                "Pipeline has no Load step and no source was passed to run()"
            )
        kind = load_step.params.get("kind", "file")
        if kind == "file":
            raw = load_step.params.get("path", "")
            if not raw:
                raise RuntimeError(
                    "Load step has no file path. Pass one to run(\"frame.png\") "
                    "or set it in the editor."
                )
            path = Path(raw)
            if not path.is_absolute():
                path = (self._base_dir / path).resolve()
            ctx.frame_path = path
            return _read_image(path)
        if kind == "webcam":
            return _capture_webcam(load_step.params)
        raise RuntimeError(f"Unknown Load kind: {kind!r}")

    def _execute_step(
        self, step: Step, img: np.ndarray, ctx: Context
    ) -> np.ndarray:
        op = REGISTRY.get(step.fnId)
        if op is None:
            raise RuntimeError(f"Unknown step fnId: {step.fnId!r}")
        result = op(img, step.params, ctx)
        self._bind_outputs(step, result, result.image)
        return result.image

    def _bind_outputs(
        self,
        step: Step,
        result: Any,
        final_image: np.ndarray,
    ) -> None:
        if not step.outputs:
            return
        for binding in step.outputs:
            extractor = EXTRACTORS.get((step.fnId, binding.outputId))
            if extractor is None:
                # Unknown binding — usually a stale .simplevision pointing
                # at an output we no longer support. Skip rather than
                # crash so the rest of the pipeline still runs.
                continue
            value = extractor(step.params, result, final_image)
            setattr(self.outputs, binding.variableName, value)


def _read_image(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {path}")
    return img


def _capture_webcam(params: dict[str, Any]) -> np.ndarray:
    """Minimal webcam capture mirroring the editor's Load form. Honours
    the same auto/manual settings the user picked. Lives here rather than
    in the runtime so the runtime stays headless-only."""
    import sys

    device = int(params.get("device", 0))
    settings = params.get("settings", {}) or {}
    cap = cv2.VideoCapture(device)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open webcam device {device}")
    try:
        ae = settings.get("autoExposure")
        if ae is not None:
            if sys.platform == "win32":
                cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.75 if ae else 0.25)
            else:
                cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 3 if ae else 1)
        af = settings.get("autoFocus")
        if af is not None:
            cap.set(cv2.CAP_PROP_AUTOFOCUS, 1 if af else 0)
        for prop_name, cv_prop in [
            ("exposure", cv2.CAP_PROP_EXPOSURE),
            ("focus", cv2.CAP_PROP_FOCUS),
            ("brightness", cv2.CAP_PROP_BRIGHTNESS),
            ("gain", cv2.CAP_PROP_GAIN),
        ]:
            v = settings.get(prop_name)
            if v is not None:
                cap.set(cv_prop, float(v))
        # Warm-up so the sensor applies the settings before we grab.
        for _ in range(4):
            cap.read()
        ok, frame = cap.read()
    finally:
        cap.release()
    if not ok or frame is None:
        raise RuntimeError(f"Failed to read frame from webcam {device}")
    return frame


class _LoadResult:
    """Stand-in ApplyResult for the load step — we don't run the op (we
    read the image ourselves), but the extractor table still expects
    something with the `rows` shape. Load has no exposed outputs today,
    so this stays empty; here only to keep the binding path uniform."""

    __slots__ = ("image", "rows")

    def __init__(self, image: np.ndarray):
        self.image = image
        self.rows = []
