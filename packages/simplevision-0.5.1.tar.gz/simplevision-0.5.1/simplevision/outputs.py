"""The ``Outputs`` container exposed as ``p.outputs`` after a pipeline run.

Bindings declared in the editor's Output Control populate this object
under student-chosen attribute names. The class itself stays simple:
attribute access for reads, a friendly ``__repr__`` so ``print(outputs)``
shows everything tidily.
"""

from __future__ import annotations

from collections import namedtuple
from typing import Any

# Named-tuple so students can write `outputs.Centroids[0].x` instead of
# unpacking. Confirmed during the design discussion: dot access is the
# expected style.
Point = namedtuple("Point", ["x", "y"])


class Outputs:
    """A simple attribute bag with a friendly repr.

    Each entry corresponds to one ticked output in the editor's Output
    Control panel. The variable name is whatever the student typed; the
    value's shape depends on the output type (scalar, list of numbers,
    list of ``Point``s — see the editor's type hint).
    """

    __slots__ = ("_values",)

    def __init__(self) -> None:
        # Bypass __setattr__ — direct dict assignment is the source of truth.
        object.__setattr__(self, "_values", {})

    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith("_"):
            object.__setattr__(self, name, value)
        else:
            self._values[name] = value

    def __getattr__(self, name: str) -> Any:
        # __getattr__ only fires when normal lookup fails, so the dunder
        # names are already handled by object.__getattribute__.
        try:
            return self._values[name]
        except KeyError as exc:
            raise AttributeError(
                f"outputs.{name} is not set. Open Output Control in the editor "
                f"and tick this measurement to expose it as a variable."
            ) from exc

    def __contains__(self, name: str) -> bool:
        return name in self._values

    def __iter__(self):
        return iter(self._values.items())

    def __repr__(self) -> str:
        if not self._values:
            return "Outputs(empty — no measurements exposed)"
        lines = ["Outputs:"]
        for k, v in self._values.items():
            lines.append(f"  {k} = {_short_repr(v)}")
        return "\n".join(lines)


def _short_repr(value: Any) -> str:
    """Compact repr for the Outputs.__repr__ — long lists get truncated."""
    if isinstance(value, list):
        if len(value) > 5:
            head = ", ".join(repr(x) for x in value[:3])
            return f"[{head}, ... +{len(value) - 3} more]"
        return repr(value)
    return repr(value)
