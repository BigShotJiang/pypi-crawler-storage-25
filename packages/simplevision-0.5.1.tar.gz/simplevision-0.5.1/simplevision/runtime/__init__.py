"""SimpleVision runtime — load and execute pipelines."""

from __future__ import annotations

import json
from pathlib import Path

from .._version import __version__
from .executor import execute
from .types import (
    PIPELINE_SCHEMA_VERSION,
    OutputBinding,
    Pipeline,
    RunReport,
    Step,
    StepResult,
)


def load_pipeline(path: str | Path) -> Pipeline:
    """Load + validate a pipeline from a JSON file on disk."""
    return load_pipeline_from_json(Path(path).read_text(encoding="utf-8"))


def load_pipeline_from_json(raw: str) -> Pipeline:
    data = json.loads(raw)
    return _parse_pipeline(data)


def _parse_pipeline(data: dict) -> Pipeline:
    version = data.get("schemaVersion")
    if version != PIPELINE_SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported pipeline schemaVersion: {version} "
            f"(expected {PIPELINE_SCHEMA_VERSION})"
        )
    steps = tuple(
        Step(
            id=s["id"],
            fnId=s["fnId"],
            enabled=bool(s["enabled"]),
            params=dict(s["params"]),
            outputs=tuple(
                OutputBinding(
                    outputId=b["outputId"],
                    variableName=b["variableName"],
                )
                for b in s.get("outputs", ())
            ),
        )
        for s in data["steps"]
    )
    return Pipeline(
        schemaVersion=version,
        name=data["name"],
        steps=steps,
        metadata=data.get("metadata", {}),
    )


__all__ = [
    "Pipeline",
    "Step",
    "StepResult",
    "RunReport",
    "OutputBinding",
    "PIPELINE_SCHEMA_VERSION",
    "__version__",
    "load_pipeline",
    "load_pipeline_from_json",
    "execute",
]
