"""Pipeline executor."""

from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

from .context import Context
from .ops import get as get_op
from .types import Pipeline, RunReport, StepResult


def execute(pipeline: Pipeline, frame_path: Path, out_dir: Path) -> RunReport:
    out_dir.mkdir(parents=True, exist_ok=True)
    ctx = Context(frame_path=frame_path, out_dir=out_dir)
    results: dict[str, StepResult] = {}

    # Pre-load the source frame so ops don't have to assume an explicit
    # Load step came first. If the user has an explicit Load step, it
    # re-reads the same file (idempotent).
    image: np.ndarray = cv2.imread(str(frame_path), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise FileNotFoundError(f"Cannot read frame: {frame_path}")

    failed = False
    started_total = time.perf_counter()

    for step in pipeline.steps:
        if not step.enabled:
            continue
        op = get_op(step.fnId)
        t0 = time.perf_counter()
        try:
            result = op(image, step.params, ctx)
        except Exception as exc:  # noqa: BLE001
            failed = True
            elapsed_ms = int((time.perf_counter() - t0) * 1000)
            results[step.id] = StepResult(
                fnId=step.fnId,
                timingMs=elapsed_ms,
                outputPath=None,
                rows=[{"metric": "error", "value": str(exc)}],
            )
            break

        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        image = result.image
        preview = result.preview if result.preview is not None else result.image
        out_path = out_dir / f"{step.id}_{step.fnId}.png"
        _save_step_image(preview, out_path)
        results[step.id] = StepResult(
            fnId=step.fnId,
            timingMs=elapsed_ms,
            outputPath=str(out_path),
            rows=result.rows,
        )

    total_ms = int((time.perf_counter() - started_total) * 1000)
    status = "fail" if failed else "pass"
    return RunReport(status=status, totalMs=total_ms, results=results)


def _save_step_image(image: np.ndarray, path: Path) -> None:
    if image.ndim == 2:
        out = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    elif image.ndim == 3 and image.shape[2] == 4:
        out = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
    else:
        out = image
    cv2.imwrite(str(path), out)
