"""CLI entry. Reads a JSON request from stdin and writes a RunReport JSON to stdout.

Request shape::

    {
      "spec":       <pipeline JSON, see docs/pipeline-spec.md>,
      "frame_path": "/abs/path/to/source.png",
      "out_dir":    "/abs/path/to/temp/dir"
    }

The Rust ``run_pipeline`` command writes this to stdin, reads stdout, and
forwards the result to the editor.
"""

from __future__ import annotations

import json
import sys
import traceback
from pathlib import Path

from . import _parse_pipeline, execute


def main() -> int:
    try:
        raw = sys.stdin.read()
        request = json.loads(raw)
        pipeline = _parse_pipeline(request["spec"])
        frame_path = Path(request["frame_path"])
        out_dir = Path(request["out_dir"])
        report = execute(pipeline, frame_path, out_dir)
        sys.stdout.write(json.dumps(report.to_json()))
        sys.stdout.flush()
        return 0
    except Exception as exc:  # noqa: BLE001 — surface to Rust
        sys.stderr.write(
            json.dumps(
                {
                    "error": str(exc),
                    "type": type(exc).__name__,
                    "traceback": traceback.format_exc(),
                }
            )
        )
        sys.stderr.flush()
        return 1


if __name__ == "__main__":
    sys.exit(main())
