"""Single-frame webcam capture CLI.

Invocation::

    python -m simplevision.runtime.capture --device 0 --out /tmp/snap.png \
        [--auto-exposure {true,false}] [--exposure VALUE] \
        [--auto-focus {true,false}] [--focus VALUE] \
        [--brightness VALUE] [--gain VALUE]

On success writes the frame to ``--out`` and exits 0. On failure exits 1
with a JSON error blob on stderr (matching the shape used by ``__main__``).

Notes on camera settings: OpenCV property values are driver-specific. Auto
exposure in particular uses different magic numbers on V4L2 (Linux) and
DSHOW (Windows); the helpers below paper over that. After applying
settings we read a few warm-up frames so the camera has time to converge
before we grab the one we keep.
"""

from __future__ import annotations

import argparse
import json
import sys
import traceback
from typing import Optional

import cv2


def _bool(arg: str) -> bool:
    v = arg.strip().lower()
    if v in ("true", "1", "yes", "on"):
        return True
    if v in ("false", "0", "no", "off"):
        return False
    raise argparse.ArgumentTypeError(f"expected true/false, got {arg!r}")


def _set_auto_exposure(cap: cv2.VideoCapture, on: bool) -> None:
    # V4L2: 3 = aperture-priority/auto, 1 = manual. DSHOW: 0.75 = auto, 0.25 = manual.
    if sys.platform == "win32":
        cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.75 if on else 0.25)
    else:
        cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 3 if on else 1)


def _set_auto_focus(cap: cv2.VideoCapture, on: bool) -> None:
    cap.set(cv2.CAP_PROP_AUTOFOCUS, 1 if on else 0)


def _capture(
    device: int,
    out_path: str,
    *,
    auto_exposure: Optional[bool],
    exposure: Optional[float],
    auto_focus: Optional[bool],
    focus: Optional[float],
    brightness: Optional[float],
    gain: Optional[float],
) -> None:
    cap = cv2.VideoCapture(device)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open webcam device {device}")
    try:
        # Auto toggles must be applied before their manual counterparts —
        # setting CAP_PROP_EXPOSURE while auto-exposure is still on is a
        # no-op on most drivers.
        if auto_exposure is not None:
            _set_auto_exposure(cap, auto_exposure)
        if auto_focus is not None:
            _set_auto_focus(cap, auto_focus)
        if exposure is not None:
            cap.set(cv2.CAP_PROP_EXPOSURE, exposure)
        if focus is not None:
            cap.set(cv2.CAP_PROP_FOCUS, focus)
        if brightness is not None:
            cap.set(cv2.CAP_PROP_BRIGHTNESS, brightness)
        if gain is not None:
            cap.set(cv2.CAP_PROP_GAIN, gain)

        # Warm-up: discard a few frames so the sensor/AE loop applies the
        # new settings before we grab the keeper.
        for _ in range(4):
            cap.read()

        ok, frame = cap.read()
        if not ok or frame is None:
            raise RuntimeError(f"Failed to read frame from webcam device {device}")
        if not cv2.imwrite(out_path, frame):
            raise RuntimeError(f"Failed to write captured frame to {out_path}")
    finally:
        cap.release()


def main() -> int:
    parser = argparse.ArgumentParser(prog="simplevision.runtime.capture")
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--out", type=str, required=True)
    parser.add_argument("--auto-exposure", type=_bool, default=None)
    parser.add_argument("--exposure", type=float, default=None)
    parser.add_argument("--auto-focus", type=_bool, default=None)
    parser.add_argument("--focus", type=float, default=None)
    parser.add_argument("--brightness", type=float, default=None)
    parser.add_argument("--gain", type=float, default=None)
    args = parser.parse_args()

    try:
        _capture(
            args.device,
            args.out,
            auto_exposure=args.auto_exposure,
            exposure=args.exposure,
            auto_focus=args.auto_focus,
            focus=args.focus,
            brightness=args.brightness,
            gain=args.gain,
        )
        return 0
    except Exception as exc:  # noqa: BLE001 — surface to Rust
        sys.stderr.write(
            json.dumps(
                {
                    "error": str(exc),
                    "type": type(exc).__name__,
                    "traceback": traceback.format_exc(),
                }
            )
        )
        sys.stderr.flush()
        return 1


if __name__ == "__main__":
    sys.exit(main())
