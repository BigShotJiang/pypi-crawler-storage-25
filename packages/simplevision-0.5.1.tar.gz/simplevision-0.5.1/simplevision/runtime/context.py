"""Execution context shared across ops in one pipeline run."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Context:
    """Per-run state passed through every op.

    Most ops only need to read ``frame_path`` (for the Load op) and write
    a per-step output PNG. The ``state`` dict is a free-form scratchpad
    so ops like Calibrate can stash data for later ops without polluting
    the image itself.
    """

    frame_path: Path
    out_dir: Path
    state: dict[str, Any] = field(default_factory=dict)
