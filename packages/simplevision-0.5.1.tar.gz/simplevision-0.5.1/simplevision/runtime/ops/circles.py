"""Grayscale category: circles — HoughCircles-based circle detector."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


@op("circles")
def op_circles(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    """Detect circles via cv2.HoughCircles (HOUGH_GRADIENT).

    Passes the input image through unchanged so downstream grayscale ops
    (e.g. threshold) can continue to operate on it. Circle geometry is
    returned as result rows; the SVG overlay in the frontend renders the
    rings live.
    """
    gray = to_grayscale(image)
    min_r = int(params.get("minRadius", 10))
    max_r = int(params.get("maxRadius", 50))
    min_dist = max(1, int(params.get("minDistance", 20)))
    sens = float(params.get("sensitivity", 50))
    max_hits = int(params.get("maxHits", 100))

    # Map sensitivity 0..100 → param2 (accumulator threshold) in range 5..100.
    # Higher sensitivity (more permissive) → lower param2 → more circles found.
    # The inversion is deliberate: sensitivity=100 gives param2=5 (very lenient),
    # sensitivity=0 gives param2=100 (very strict). The square-root curve keeps
    # the control responsive in the middle range where users spend most time.
    param2 = max(5, int(100 - sens))

    blurred = cv2.GaussianBlur(gray, (5, 5), 1.4)
    circles = cv2.HoughCircles(
        blurred,
        cv2.HOUGH_GRADIENT,
        dp=1.0,
        minDist=min_dist,
        param1=100,
        param2=param2,
        minRadius=min_r,
        maxRadius=max_r,
    )

    rows: list[dict[str, Any]] = []
    if circles is not None:
        for i, (cx, cy, r) in enumerate(circles[0][:max_hits]):
            rows.append(
                {
                    "label": f"C{i + 1:02d}",
                    "cx": float(cx),
                    "cy": float(cy),
                    "r": float(r),
                }
            )

    return ApplyResult(image=image, rows=rows)
