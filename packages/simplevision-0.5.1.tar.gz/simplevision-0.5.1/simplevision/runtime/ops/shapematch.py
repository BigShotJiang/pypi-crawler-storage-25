"""Shape Match — match blobs against a user-drawn template region.

Workflow:
  - User draws a rectangular ROI on the viewer; it's stored on the step's
    params as ``roi = {x, y, w, h}``.
  - At run time we crop the ROI from the propagated binary mask, take the
    largest contour inside it as the template, then walk all contours in
    the full mask and keep the ones that pass:
      1. absolute area gates: ``minArea`` <= area <= ``maxArea`` (0 disables)
      2. ``scaleTolerance`` — max % deviation of area vs. template area
      3. ``aspectTolerance`` — max % deviation of bounding-box aspect ratio
      4. shape similarity = ``100·exp(−d)`` where ``d`` is ``cv2.matchShapes``
         distance (Hu moments — scale/rotation invariant). Must be at least
         ``threshold`` (0..100).
  - Output is a binary mask containing only the matched contours.

Hu moments alone are scale-invariant, so a 20%-sized circle scores ~100%
against a full-size circle. The geometry filters above are what stop that
from being a "match".

If no ROI has been set yet, we pass the input through unchanged so the
preview keeps rendering and the user can see what they're targeting.
"""

from __future__ import annotations

import math
from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


def _ensure_binary(image: np.ndarray) -> np.ndarray:
    if image.ndim == 2 and ((image == 0) | (image == 255)).all():
        return image
    gray = to_grayscale(image)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return mask


def _largest_contour(mask: np.ndarray):
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return None
    return max(contours, key=cv2.contourArea)


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


@op("shapematch")
def op_shapematch(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    mask = _ensure_binary(image)
    h, w = mask.shape[:2]
    roi = params.get("roi")

    min_similarity = _clamp(float(params.get("threshold", 80.0)), 0.0, 100.0)
    scale_tol = _clamp(float(params.get("scaleTolerance", 100.0)), 0.0, 100.0)
    aspect_tol = _clamp(float(params.get("aspectTolerance", 100.0)), 0.0, 100.0)
    min_area = max(0.0, float(params.get("minArea", 0)))
    max_area_raw = float(params.get("maxArea", 0))
    max_area = math.inf if max_area_raw <= 0 else max_area_raw
    max_distance = math.inf if min_similarity <= 0 else -math.log(min_similarity / 100.0)

    if not roi:
        return ApplyResult(image=mask, rows=[])

    rx = max(0, min(int(roi.get("x", 0)), w - 1))
    ry = max(0, min(int(roi.get("y", 0)), h - 1))
    rw = max(1, min(int(roi.get("w", 1)), w - rx))
    rh = max(1, min(int(roi.get("h", 1)), h - ry))

    template_region = mask[ry : ry + rh, rx : rx + rw]
    template = _largest_contour(template_region)
    if template is None:
        return ApplyResult(image=mask, rows=[])

    template_area = float(cv2.contourArea(template))
    _, _, tbw, tbh = cv2.boundingRect(template)
    template_aspect = (tbw / tbh) if tbh > 0 else 1.0

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    out = np.zeros_like(mask)
    hits: list[dict[str, Any]] = []

    scale_strict = scale_tol < 100.0
    aspect_strict = aspect_tol < 100.0

    for c in contours:
        area = float(cv2.contourArea(c))
        if area < 1:
            continue
        # 1. absolute area gates
        if area < min_area or area > max_area:
            continue

        # 2. scale tolerance (area ratio)
        if scale_strict and template_area > 0:
            ratio = area / template_area
            if abs(ratio - 1.0) > scale_tol / 100.0:
                continue

        bx, by, bw, bh = cv2.boundingRect(c)
        cand_aspect = (bw / bh) if bh > 0 else 1.0

        # 3. aspect tolerance (aspect ratio deviation)
        if aspect_strict and template_aspect > 0:
            aspect_ratio = cand_aspect / template_aspect
            if abs(aspect_ratio - 1.0) > aspect_tol / 100.0:
                continue

        # 4. Hu-moments shape similarity
        try:
            d = float(cv2.matchShapes(template, c, cv2.CONTOURS_MATCH_I1, 0.0))
        except cv2.error:
            continue
        if d > max_distance:
            continue
        similarity = 100.0 * math.exp(-d)

        cv2.drawContours(out, [c], -1, color=255, thickness=cv2.FILLED)
        m = cv2.moments(c)
        cx = m["m10"] / m["m00"] if m["m00"] else bx + bw / 2.0
        cy = m["m01"] / m["m00"] if m["m00"] else by + bh / 2.0
        hits.append(
            {
                "score": round(similarity, 2),
                "area": int(round(area)),
                "scale": round(area / template_area, 3) if template_area > 0 else 0.0,
                "aspect": round(cand_aspect, 3),
                "cx": round(float(cx), 1),
                "cy": round(float(cy), 1),
                "x": int(bx),
                "y": int(by),
                "w": int(bw),
                "h": int(bh),
            }
        )

    hits.sort(key=lambda r: -r["score"])
    rows = [{"label": f"M{idx + 1:02d}", **hit} for idx, hit in enumerate(hits)]
    return ApplyResult(image=out, rows=rows)
