"""Caliper op — find edges along a user-drawn line.

Algorithm:
1. Convert image to grayscale.
2. Sample a perpendicular strip of width 2*width+1 pixels at each point along
   the line and average the samples to produce a 1-D intensity profile.
3. Apply optional Gaussian smoothing to the profile.
4. Compute the discrete derivative (np.diff) and locate peaks above
   `minStrength` using non-maximum suppression with a minimum spacing of
   `minSpacing` samples.
5. Classify each peak as 'rising' or 'falling' by the sign of the derivative.
6. Filter by the `polarity` parameter.
7. Return one row per kept edge; the image pass-through is unchanged.
"""

from __future__ import annotations

import math
from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


def _gaussian_kernel(sigma: float) -> np.ndarray:
    """Return a 1-D normalised Gaussian kernel for the given sigma."""
    if sigma <= 0:
        return np.array([1.0])
    radius = max(1, int(math.ceil(3.0 * sigma)))
    x = np.arange(-radius, radius + 1, dtype=np.float64)
    k = np.exp(-0.5 * (x / sigma) ** 2)
    return (k / k.sum()).astype(np.float32)


def _sample_profile(
    gray: np.ndarray,
    ax: float,
    ay: float,
    bx: float,
    by: float,
    width: int,
) -> np.ndarray:
    """Return a 1-D intensity profile along the line from (ax,ay) to (bx,by).

    At each of N = ceil(line_length) sample positions, (2*width+1) pixels are
    sampled perpendicular to the line and averaged.  Uses cv2.remap with
    bilinear interpolation so samples land at sub-pixel positions.
    """
    dx = bx - ax
    dy = by - ay
    length = math.sqrt(dx * dx + dy * dy)
    n = max(2, int(math.ceil(length)))

    ux = dx / length
    uy = dy / length
    perp_x = -uy
    perp_y = ux

    # Base sample positions along the line (shape: n)
    ts = np.linspace(0.0, 1.0, n, dtype=np.float64)
    xs_line = ax + ts * dx  # (n,)
    ys_line = ay + ts * dy  # (n,)

    # Stack perpendicular offsets: shape (2w+1, n)
    offsets = np.arange(-width, width + 1, dtype=np.float64)  # (2w+1,)
    map_x = (xs_line[np.newaxis, :] + offsets[:, np.newaxis] * perp_x).astype(np.float32)
    map_y = (ys_line[np.newaxis, :] + offsets[:, np.newaxis] * perp_y).astype(np.float32)

    h, w_img = gray.shape[:2]
    strip = np.empty((2 * width + 1, n), dtype=np.float32)
    for k in range(2 * width + 1):
        strip[k] = cv2.remap(
            gray,
            map_x[k : k + 1, :],
            map_y[k : k + 1, :],
            cv2.INTER_LINEAR,
            borderMode=cv2.BORDER_REPLICATE,
        )[0]

    profile = strip.mean(axis=0)
    return profile  # shape (n,)


def _nms_peaks(
    values: np.ndarray,
    min_strength: float,
    min_spacing: int,
) -> list[int]:
    """Non-maximum suppression on an absolute-value array.

    Returns indices of peaks in descending order of magnitude, with at least
    `min_spacing` samples between any two kept peaks.
    """
    candidates = np.where(values >= min_strength)[0].tolist()
    # Sort by descending magnitude so we greedily keep the strongest peaks first
    candidates.sort(key=lambda i: -values[i])
    kept: list[int] = []
    for idx in candidates:
        if all(abs(idx - k) >= min_spacing for k in kept):
            kept.append(idx)
    kept.sort()
    return kept


@op("caliper")
def op_caliper(image: np.ndarray, params: dict[str, Any], ctx: Context) -> ApplyResult:
    a = params.get("a")
    b = params.get("b")
    if not a or not b:
        return ApplyResult(image=image, rows=[])

    ax, ay = float(a["x"]), float(a["y"])
    bx, by = float(b["x"]), float(b["y"])

    dx = bx - ax
    dy = by - ay
    line_length = math.sqrt(dx * dx + dy * dy)
    if line_length < 2:
        return ApplyResult(image=image, rows=[])

    width = max(0, int(params.get("width", 5)))
    min_strength = float(params.get("minStrength", 30))
    min_spacing = max(1, int(params.get("minSpacing", 3)))
    smoothing = float(params.get("smoothing", 1.0))
    polarity = params.get("polarity", "Both")

    gray = to_grayscale(image)

    # 1. Sample the strip profile
    profile = _sample_profile(gray, ax, ay, bx, by, width)  # (n,)

    # 2. Smooth the profile
    kernel = _gaussian_kernel(smoothing)
    if len(kernel) > 1:
        profile = np.convolve(profile, kernel, mode="same")

    # 3. Discrete derivative
    derivative = np.diff(profile.astype(np.float32))  # (n-1,)

    # 4. Find peaks in |derivative| with NMS
    abs_deriv = np.abs(derivative)
    peak_indices = _nms_peaks(abs_deriv, min_strength, min_spacing)

    # 5. Classify, filter, and build rows
    n = len(profile)
    ux = dx / line_length
    uy = dy / line_length

    rows: list[dict[str, Any]] = []
    for rank, idx in enumerate(peak_indices):
        sign = derivative[idx]
        edge_polarity = "rising" if sign > 0 else "falling"

        if polarity == "Rising" and edge_polarity != "rising":
            continue
        if polarity == "Falling" and edge_polarity != "falling":
            continue

        # Position in px along line: idx is in [0, n-2], map back to [0, line_length]
        t = idx / max(1, n - 2)
        pos_px = t * line_length

        # Image coordinates of this edge
        ex = ax + ux * pos_px
        ey = ay + uy * pos_px

        rows.append(
            {
                "label": f"E{rank + 1:02d}",
                "position": round(pos_px, 2),
                "strength": round(float(abs_deriv[idx]), 2),
                "polarity": edge_polarity,
                "x": round(ex, 2),
                "y": round(ey, 2),
            }
        )

    return ApplyResult(image=image, rows=rows)
