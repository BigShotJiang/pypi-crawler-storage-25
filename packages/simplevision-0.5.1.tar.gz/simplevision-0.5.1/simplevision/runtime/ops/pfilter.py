"""Particle Filter — drop particles that fail any of the configured gates.

Operates on a binary mask. For every connected component we measure:
  - pixel area (cv2.connectedComponentsWithStats)
  - perimeter / circularity (from the contour)
  - bounding-box aspect ratio (long-side / short-side)
  - whether the bbox touches the image border
  - whether the contour has interior holes (RETR_CCOMP hierarchy)

Each gate is independent — set its bound to ``0`` to disable. The output
image is a binary mask containing only the surviving particles, so this
op is drop-in between Threshold/Blob and any downstream consumer.

Result rows include the rejected particles as well so the overlay can
draw red dashed boxes around them and tell the student *why* each was
dropped.
"""

from __future__ import annotations

import math
from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_grayscale
from ._registry import ApplyResult, op


def _ensure_binary(image: np.ndarray) -> np.ndarray:
    if image.ndim == 2 and ((image == 0) | (image == 255)).all():
        return image
    gray = to_grayscale(image)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return mask


@op("pfilter")
def op_pfilter(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    mask = _ensure_binary(image)
    h, w = mask.shape[:2]

    min_area = max(0, int(params.get("minArea", 0)))
    max_area_raw = int(params.get("maxArea", 0))
    max_area = math.inf if max_area_raw <= 0 else float(max_area_raw)

    min_circ = max(0.0, float(params.get("minCirc", 0)))
    max_circ_raw = float(params.get("maxCirc", 0))
    max_circ = math.inf if max_circ_raw <= 0 else max_circ_raw

    max_aspect_raw = float(params.get("maxAspect", 0))
    max_aspect = math.inf if max_aspect_raw <= 1.0 else max_aspect_raw

    drop_border = bool(params.get("dropBorderTouching", False))
    drop_holes = bool(params.get("dropWithHoles", False))

    n_cc, labels, stats, centroids = cv2.connectedComponentsWithStats(
        mask, connectivity=8, ltype=cv2.CV_32S
    )

    # Hole detection: count interior holes per outer contour via RETR_CCOMP.
    # contours_ccomp[hierarchy[i][3] == -1] is an outer; its children (next
    # index ring with parent == i) are holes.
    hole_count_by_label: dict[int, int] = {}
    if drop_holes:
        for i in range(1, n_cc):
            comp_mask = (labels == i).astype(np.uint8) * 255
            contours, hierarchy = cv2.findContours(
                comp_mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_NONE
            )
            holes = 0
            if hierarchy is not None and len(hierarchy) > 0:
                hier = hierarchy[0]
                for ci, entry in enumerate(hier):
                    # entry = [next, prev, first_child, parent]
                    if entry[3] != -1:  # has a parent → it's a hole
                        holes += 1
                    _ = ci  # unused, keep loop explicit
            hole_count_by_label[i] = holes

    out = np.zeros_like(mask)
    rows: list[dict[str, Any]] = []
    kept_count = 0
    dropped_count = 0

    for i in range(1, n_cc):
        area = int(stats[i, cv2.CC_STAT_AREA])
        if area < 1:
            continue
        x = int(stats[i, cv2.CC_STAT_LEFT])
        y = int(stats[i, cv2.CC_STAT_TOP])
        bw = int(stats[i, cv2.CC_STAT_WIDTH])
        bh = int(stats[i, cv2.CC_STAT_HEIGHT])
        cx = float(centroids[i, 0])
        cy = float(centroids[i, 1])

        comp_mask = (labels == i).astype(np.uint8) * 255
        contours, _ = cv2.findContours(
            comp_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE
        )
        if not contours:
            continue
        cnt = max(contours, key=cv2.contourArea)
        perim = float(cv2.arcLength(cnt, True))
        circ = (4 * math.pi * area / (perim * perim)) if perim > 0 else 0.0
        long_side = max(bw, bh)
        short_side = max(1, min(bw, bh))
        aspect = long_side / short_side

        reason = ""
        if area < min_area:
            reason = f"area<{min_area}"
        elif area > max_area:
            reason = f"area>{int(max_area)}"
        elif circ < min_circ:
            reason = f"circ<{min_circ:.2f}"
        elif circ > max_circ:
            reason = f"circ>{max_circ_raw:.2f}"
        elif aspect > max_aspect:
            reason = f"aspect>{max_aspect_raw:.1f}"
        elif drop_border and (
            x == 0 or y == 0 or x + bw >= w or y + bh >= h
        ):
            reason = "border"
        elif drop_holes and hole_count_by_label.get(i, 0) > 0:
            reason = "holes"

        kept = not reason
        if kept:
            out[labels == i] = 255
            kept_count += 1
            label = f"K{kept_count:02d}"
        else:
            dropped_count += 1
            label = f"x{dropped_count:02d}"

        rows.append(
            {
                "label": label,
                "kept": kept,
                "reason": reason,
                "area": area,
                "circ": round(float(circ), 3),
                "aspect": round(float(aspect), 2),
                "cx": round(cx, 1),
                "cy": round(cy, 1),
                "x": x,
                "y": y,
                "w": bw,
                "h": bh,
            }
        )

    # Sort: kept first (by area desc), then dropped (by area desc) so the
    # overlay paints the dropped boxes last (and underneath the kept centroids
    # visually if they overlap). This makes the kept particles read as the
    # primary signal.
    rows.sort(key=lambda r: (0 if r["kept"] else 1, -int(r["area"])))

    # Note: we deliberately don't append scalar summary rows here — the form
    # derives kept/dropped counts directly from the per-particle rows, which
    # keeps the row type homogeneous (so isPFilterRows + the overlay's
    # type-narrowed iteration both work without runtime branching).
    _ = scalar  # silence linter — imported for symmetry with other ops

    return ApplyResult(image=out, rows=rows)
