"""Image category: load, crop, rotate, resample, calibrate."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar
from ._registry import ApplyResult, op


@op("load")
def op_load(_image: np.ndarray, _params: dict[str, Any], ctx: Context) -> ApplyResult:
    img = cv2.imread(str(ctx.frame_path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {ctx.frame_path}")
    h, w = img.shape[:2]
    rows = [
        scalar("Filename", ctx.frame_path.name),
        scalar("Width", f"{w} px"),
        scalar("Height", f"{h} px"),
        scalar("Channels", img.shape[2] if img.ndim == 3 else 1),
    ]
    return ApplyResult(image=img, rows=rows)


@op("crop")
def op_crop(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    h, w = image.shape[:2]
    x = max(0, min(int(params.get("x", 0)), w - 1))
    y = max(0, min(int(params.get("y", 0)), h - 1))
    cw = max(1, min(int(params.get("w", w)), w - x))
    ch = max(1, min(int(params.get("h", h)), h - y))
    out = image[y : y + ch, x : x + cw].copy()
    rows = [scalar("Origin", f"({x}, {y})"), scalar("Size", f"{cw}×{ch}")]
    return ApplyResult(image=out, rows=rows)


@op("rotate")
def op_rotate(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    angle = float(params.get("angle", 0))
    flip = params.get("flip", "None")
    out = image
    if angle:
        h, w = out.shape[:2]
        m = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
        out = cv2.warpAffine(
            out, m, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE
        )
    if flip == "Horizontal":
        out = cv2.flip(out, 1)
    elif flip == "Vertical":
        out = cv2.flip(out, 0)
    rows = [scalar("Angle", angle), scalar("Flip", flip)]
    return ApplyResult(image=out, rows=rows)


@op("resample")
def op_resample(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    scale = float(params.get("scale", 1.0))
    method = params.get("method", "Bilinear")
    interp = {
        "Nearest": cv2.INTER_NEAREST,
        "Bilinear": cv2.INTER_LINEAR,
        "Bicubic": cv2.INTER_CUBIC,
    }.get(method, cv2.INTER_LINEAR)
    h, w = image.shape[:2]
    new_w = max(1, int(round(w * scale)))
    new_h = max(1, int(round(h * scale)))
    out = cv2.resize(image, (new_w, new_h), interpolation=interp)
    rows = [
        scalar("Scale", scale),
        scalar("Method", method),
        scalar("Size", f"{new_w}×{new_h}"),
    ]
    return ApplyResult(image=out, rows=rows)


@op("calibrate")
def op_calibrate(image: np.ndarray, params: dict[str, Any], ctx: Context) -> ApplyResult:
    """Apply spatial calibration (px to mm).

    Tries to detect an 8x6 (interior-corner) chessboard via
    ``cv2.findChessboardCorners``. When found, the average pixel distance
    between horizontally-adjacent corners is divided by ``square_size_mm``
    to yield px/mm. Otherwise we fall back to the user-supplied ``scale``.
    The image is passed through; the preview draws detected corners.
    """
    fallback_scale = float(params.get("scale", 12.4))
    square_size_mm = float(params.get("square_size_mm", 10.0))
    pattern_size = (8, 6)  # interior corners (cols, rows)

    if image.ndim == 2:
        gray = image
    elif image.ndim == 3 and image.shape[2] == 4:
        gray = cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
    elif image.ndim == 3 and image.shape[2] == 3:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    else:
        gray = image[..., 0] if image.ndim == 3 else image

    detected = False
    px_per_mm = fallback_scale
    preview: np.ndarray | None = None

    try:
        found, corners = cv2.findChessboardCorners(gray, pattern_size)
    except cv2.error:
        found, corners = False, None

    if found and corners is not None and square_size_mm > 0:
        cols, rows_n = pattern_size
        pts = corners.reshape(rows_n, cols, 2)
        # Average pixel distance between horizontally-adjacent corners.
        row_diffs = np.diff(pts, axis=1)  # shape (rows_n, cols-1, 2)
        row_dists = np.linalg.norm(row_diffs, axis=2)
        if row_dists.size > 0:
            avg_px = float(row_dists.mean())
            px_per_mm = avg_px / square_size_mm
            detected = True
            # Draw corners on a BGR preview copy.
            if image.ndim == 2:
                preview = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
            elif image.ndim == 3 and image.shape[2] == 4:
                preview = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
            else:
                preview = image.copy()
            cv2.drawChessboardCorners(preview, pattern_size, corners, True)

    ctx.state["px_per_mm"] = px_per_mm
    rows = [
        scalar("Detected", "yes" if detected else "no"),
        scalar("px/mm", round(px_per_mm, 4)),
        scalar("square_size_mm", square_size_mm),
    ]
    return ApplyResult(image=image, rows=rows, preview=preview)


@op("invert")
def op_invert(image: np.ndarray, _params: dict[str, Any], _ctx: Context) -> ApplyResult:
    out = cv2.bitwise_not(image)
    rows = [scalar("Operation", "out = 255 − in")]
    return ApplyResult(image=out, rows=rows)
