"""Grayscale category: gauss, median, bilateral, sobel, canny, morph, hist."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_grayscale
from ._registry import ApplyResult, op


def _odd(k: int) -> int:
    k = int(k)
    return k if k % 2 == 1 else k + 1


@op("gauss")
def op_gauss(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    sigma = float(params.get("sigma", 1.4))
    kernel = _odd(int(params.get("kernel", 5)))
    out = cv2.GaussianBlur(image, (kernel, kernel), sigma)
    rows = [scalar("Sigma", round(sigma, 2)), scalar("Kernel", f"{kernel}×{kernel}")]
    return ApplyResult(image=out, rows=rows)


@op("median")
def op_median(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    k = _odd(int(params.get("kernel", 3)))
    out = cv2.medianBlur(image, k)
    rows = [scalar("Kernel", k)]
    return ApplyResult(image=out, rows=rows)


@op("bilateral")
def op_bilateral(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    d = int(params.get("diameter", 5))
    sigma_color = float(params.get("sigmaColor", 50))
    sigma_space = float(params.get("sigmaSpace", 50))
    out = cv2.bilateralFilter(image, d, sigma_color, sigma_space)
    rows = [
        scalar("Diameter", d),
        scalar("Sigma color", sigma_color),
        scalar("Sigma space", sigma_space),
    ]
    return ApplyResult(image=out, rows=rows)


@op("sobel")
def op_sobel(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    direction = params.get("direction", "Both")
    gray = to_grayscale(image)
    if direction == "Both":
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
        mag = cv2.magnitude(gx, gy)
        out = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    else:
        dx, dy = (1, 0) if direction == "X" else (0, 1)
        g = cv2.Sobel(gray, cv2.CV_32F, dx, dy, ksize=3)
        out = cv2.convertScaleAbs(g)
    rows = [scalar("Direction", direction), scalar("Max", int(out.max()))]
    return ApplyResult(image=out, rows=rows)


@op("canny")
def op_canny(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    low = int(params.get("low", 50))
    high = int(params.get("high", 150))
    gray = to_grayscale(image)
    out = cv2.Canny(gray, low, high)
    edge_pct = float((out > 0).sum()) / out.size * 100.0
    rows = [
        scalar("Low", low),
        scalar("High", high),
        scalar("Edge coverage", f"{edge_pct:.2f}%"),
    ]
    return ApplyResult(image=out, rows=rows)


_MORPH_OPS: dict[str, int] = {
    "Open": cv2.MORPH_OPEN,
    "Close": cv2.MORPH_CLOSE,
    "Erode": cv2.MORPH_ERODE,
    "Dilate": cv2.MORPH_DILATE,
    "TopHat": cv2.MORPH_TOPHAT,
    "BlackHat": cv2.MORPH_BLACKHAT,
    "Gradient": cv2.MORPH_GRADIENT,
    "HitOrMiss": cv2.MORPH_HITMISS,
}

_MORPH_SHAPES: dict[str, int] = {
    "Rect": cv2.MORPH_RECT,
    "Ellipse": cv2.MORPH_ELLIPSE,
    "Cross": cv2.MORPH_CROSS,
}


def _ensure_binary(image: np.ndarray) -> np.ndarray:
    if image.ndim == 2 and ((image == 0) | (image == 255)).all():
        return image
    gray = to_grayscale(image)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return mask


@op("morph")
def op_morph(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    op_name = params.get("op", "Open")
    shape_name = params.get("shape", "Rect")
    k = _odd(int(params.get("kernel", 3)))
    iters = max(1, int(params.get("iter", 1)))

    mode = _MORPH_OPS.get(op_name, cv2.MORPH_OPEN)
    shape = _MORPH_SHAPES.get(shape_name, cv2.MORPH_RECT)

    if op_name == "HitOrMiss":
        # Hit-or-miss demands a binary input and a signed kernel (-1/0/1).
        # We expose this as a cross-shaped probe — bright center, dim ring —
        # which is the canonical "isolated foreground point" detector.
        mask = _ensure_binary(image)
        probe = np.zeros((k, k), dtype=np.int8)
        c = k // 2
        probe[c, :] = -1
        probe[:, c] = -1
        probe[c, c] = 1
        out = cv2.morphologyEx(mask, cv2.MORPH_HITMISS, probe)
    else:
        kernel = cv2.getStructuringElement(shape, (k, k))
        # Iterations only make sense for the four basic ops — for composite
        # ops OpenCV applies the requested iteration count on the underlying
        # erode/dilate cycle, which usually isn't what the student means.
        if op_name in ("Erode", "Dilate", "Open", "Close"):
            out = cv2.morphologyEx(image, mode, kernel, iterations=iters)
        else:
            out = cv2.morphologyEx(image, mode, kernel)

    rows = [
        scalar("Op", op_name),
        scalar("Shape", shape_name),
        scalar("Kernel", f"{k}×{k}"),
    ]
    if op_name in ("Erode", "Dilate", "Open", "Close"):
        rows.append(scalar("Iterations", iters))
    return ApplyResult(image=out, rows=rows)


@op("hist")
def op_hist(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    equalize = bool(params.get("equalize", True))
    gray = to_grayscale(image)
    out = cv2.equalizeHist(gray) if equalize else gray
    rows = [
        scalar("Equalize", "yes" if equalize else "no"),
        scalar("Mean", round(float(out.mean()), 2)),
        scalar("Stdev", round(float(out.std()), 2)),
    ]
    return ApplyResult(image=out, rows=rows)
