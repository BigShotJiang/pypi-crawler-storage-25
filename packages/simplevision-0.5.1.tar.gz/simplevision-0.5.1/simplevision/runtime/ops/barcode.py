"""Barcode detector — find and decode 1-D barcodes anywhere in the frame.

Wraps ``cv2.barcode.BarcodeDetector`` (OpenCV ≥ 4.5.4 with core builds).
``detectAndDecode(image)`` returns:
  ok           — True iff at least one barcode was found
  decoded_info — list[str] of decoded payloads (empty when found-but-not-read)
  decoded_type — list[str] of symbology names (EAN_13, CODE_128, …)
  corners      — Nx4x2 float corner array, same ordering convention as the
                 QR detector (top-left, top-right, bottom-right, bottom-left)

If ``showUndecoded`` is false (default), detections without a decoded
payload are dropped from the result rows so downstream steps only see
real codes.
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


def _make_detector():
    if not hasattr(cv2, "barcode"):
        return None
    try:
        return cv2.barcode.BarcodeDetector()
    except cv2.error:
        return None


_DETECTOR = _make_detector()


def _row_from_corners(
    idx: int, corners: np.ndarray, text: str, btype: str
) -> dict[str, Any]:
    pts = corners.reshape(-1, 2).astype(float)
    xs = pts[:, 0]
    ys = pts[:, 1]
    cx = float(xs.mean())
    cy = float(ys.mean())
    x_min = float(xs.min())
    y_min = float(ys.min())
    x_max = float(xs.max())
    y_max = float(ys.max())

    return {
        "label": f"B{idx + 1:02d}",
        "text": text,
        "decoded": bool(text),
        "type": btype,
        "x0": round(float(pts[0, 0]), 1),
        "y0": round(float(pts[0, 1]), 1),
        "x1": round(float(pts[1, 0]), 1),
        "y1": round(float(pts[1, 1]), 1),
        "x2": round(float(pts[2, 0]), 1),
        "y2": round(float(pts[2, 1]), 1),
        "x3": round(float(pts[3, 0]), 1),
        "y3": round(float(pts[3, 1]), 1),
        "cx": round(cx, 1),
        "cy": round(cy, 1),
        "x": int(round(x_min)),
        "y": int(round(y_min)),
        "w": max(1, int(round(x_max - x_min))),
        "h": max(1, int(round(y_max - y_min))),
    }


@op("barcode")
def op_barcode(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    if _DETECTOR is None:
        return ApplyResult(
            image=image,
            rows=[
                {
                    "metric": "error",
                    "value": "cv2.barcode is unavailable — requires OpenCV ≥ 4.5.4 "
                             "with the barcode module enabled.",
                }
            ],
        )

    gray = to_grayscale(image)
    show_undecoded = bool(params.get("showUndecoded", False))

    # ``detectAndDecodeWithType`` is the multi-result variant — returns
    # (ok, decoded_info, decoded_type, points). ``detectAndDecode`` itself
    # only handles a single code and returns a different shape, which the
    # detector method-list disambiguates.
    try:
        ok, decoded_info, decoded_type, corners = _DETECTOR.detectAndDecodeWithType(gray)
    except (cv2.error, AttributeError):
        ok = False
        decoded_info = []
        decoded_type = []
        corners = None

    if not ok or corners is None or len(corners) == 0:
        return ApplyResult(image=image, rows=[])

    rows: list[dict[str, Any]] = []
    for i, c in enumerate(corners):
        text = decoded_info[i] if i < len(decoded_info) and decoded_info[i] else ""
        btype = str(decoded_type[i]) if i < len(decoded_type) and decoded_type[i] else ""
        if not text and not show_undecoded:
            continue
        rows.append(_row_from_corners(len(rows), c, text, btype))

    return ApplyResult(image=image, rows=rows)
