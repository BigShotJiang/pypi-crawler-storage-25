"""Color category: extract, split, hsl, colorthr, colormatch."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_bgr
from ._registry import ApplyResult, op


@op("extract")
def op_extract(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    mode = params.get("mode", "Luminance")
    bgr = to_bgr(image)
    if mode == "Luminance":
        out = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    elif mode == "Red":
        out = bgr[..., 2]
    elif mode == "Green":
        out = bgr[..., 1]
    elif mode == "Blue":
        out = bgr[..., 0]
    elif mode == "Hue":
        out = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)[..., 0]
    elif mode == "Saturation":
        out = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)[..., 1]
    else:
        out = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    rows = [
        scalar("Mode", mode),
        scalar("Output", "8-bit grayscale · [0, 255]"),
        scalar("Mean", round(float(out.mean()), 2)),
    ]
    return ApplyResult(image=out, rows=rows)


@op("split")
def op_split(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    channel = params.get("channel", "R")
    bgr = to_bgr(image)
    idx = {"R": 2, "G": 1, "B": 0}.get(channel, 2)
    out = bgr[..., idx]
    rows = [scalar("Channel", channel), scalar("Mean", round(float(out.mean()), 2))]
    return ApplyResult(image=out, rows=rows)


@op("hsl")
def op_hsl(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    channel = params.get("channel", "H")
    bgr = to_bgr(image)
    hls = cv2.cvtColor(bgr, cv2.COLOR_BGR2HLS)
    idx = {"H": 0, "L": 1, "S": 2}.get(channel, 0)
    out = hls[..., idx]
    rows = [scalar("Channel", channel), scalar("Mean", round(float(out.mean()), 2))]
    return ApplyResult(image=out, rows=rows)


@op("colorthr")
def op_colorthr(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    space = params.get("space", "HSL")
    lower = int(params.get("lower", 0))
    upper = int(params.get("upper", 255))
    bgr = to_bgr(image)
    src = cv2.cvtColor(bgr, cv2.COLOR_BGR2HLS) if space == "HSL" else bgr
    lo = np.array([lower] * 3, dtype=np.uint8)
    hi = np.array([upper] * 3, dtype=np.uint8)
    out = cv2.inRange(src, lo, hi)
    coverage = float((out > 0).sum()) / out.size * 100.0
    rows = [
        scalar("Space", space),
        scalar("Range", f"[{lower}, {upper}]"),
        scalar("Coverage", f"{coverage:.1f}%"),
    ]
    return ApplyResult(image=out, rows=rows)


@op("colormatch")
def op_colormatch(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    """Pick-a-color match.

    Treats ``params['target']`` as the user's sampled BGR color and outputs
    a binary mask where each pixel's perceptual distance (LAB ΔE) to the
    target is within the ``tolerance`` feather radius. Tolerance is on a
    0..100 user scale and is mapped linearly to ΔE; larger values pick up
    nearby gradients and shading.
    """
    bgr = to_bgr(image)
    h, w = bgr.shape[:2]
    tolerance = max(0, min(100, int(params.get("tolerance", 20))))

    target = params.get("target") or None
    if not isinstance(target, dict) or "b" not in target:
        # Unconfigured: pass through an empty mask so the user gets a clear
        # signal in the viewer rather than a stale or surprising result.
        empty = np.zeros((h, w), dtype=np.uint8)
        rows = [scalar("Picked color", "— click on the viewer to sample —")]
        return ApplyResult(image=empty, rows=rows)

    tb = int(target.get("b", 0))
    tg = int(target.get("g", 0))
    tr = int(target.get("r", 0))

    # Convert both image and target into LAB so the distance is perceptual.
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB).astype(np.float32)
    target_bgr = np.array([[[tb, tg, tr]]], dtype=np.uint8)
    target_lab = cv2.cvtColor(target_bgr, cv2.COLOR_BGR2LAB).astype(np.float32)[0, 0]

    diff = lab - target_lab[None, None, :]
    delta_e = np.sqrt(np.einsum("hwc,hwc->hw", diff, diff))

    # 0..100 tolerance maps to 0..100 ΔE. ΔE > ~50 covers most of LAB so
    # a slider value in the 60-80 range will already sweep large regions.
    mask = (delta_e <= float(tolerance)).astype(np.uint8) * 255

    matched = int((mask > 0).sum())
    coverage = matched / mask.size * 100.0
    rows = [
        scalar("Picked color", f"BGR({tb},{tg},{tr}) · ({int(target.get('x', 0))}, {int(target.get('y', 0))})"),
        scalar("Feather (ΔE)", tolerance),
        scalar("Matched", f"{matched} px · {coverage:.1f}%"),
    ]
    return ApplyResult(image=mask, rows=rows)
