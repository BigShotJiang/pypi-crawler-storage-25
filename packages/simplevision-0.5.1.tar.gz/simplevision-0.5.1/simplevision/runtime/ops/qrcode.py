"""QR Code detector — find and decode QR codes anywhere in the frame.

Unlike OCR or Pattern Match, this op does not need a user-drawn ROI: the
detector scans the whole image. ``detectAndDecodeMulti`` returns one entry
per code, each with its 4 corner points and (when decoding succeeds) the
decoded text string.

Two detector backends are exposed via ``params['detector']``:
  - ``STANDARD`` (default) — ``cv2.QRCodeDetector`` (since OpenCV 4.0).
  - ``ARUCO`` — ``cv2.QRCodeDetectorAruco`` (since OpenCV 4.7). More robust
    on damaged / motion-blurred codes but a little slower.

If ``showUndecoded`` is false (the default), detections without a decoded
payload are dropped so downstream steps only see real codes.

The output image is unchanged — QR detection is a read, not a transform.
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


def _make_detector(kind: str):
    if kind == "ARUCO" and hasattr(cv2, "QRCodeDetectorAruco"):
        return cv2.QRCodeDetectorAruco()
    return cv2.QRCodeDetector()


def _row_from_corners(
    idx: int, corners: np.ndarray, text: str
) -> dict[str, Any]:
    """Build one result row from a 4x2 corner array and decoded text."""
    pts = corners.reshape(-1, 2).astype(float)
    xs = pts[:, 0]
    ys = pts[:, 1]
    cx = float(xs.mean())
    cy = float(ys.mean())
    x_min = float(xs.min())
    y_min = float(ys.min())
    x_max = float(xs.max())
    y_max = float(ys.max())

    return {
        "label": f"Q{idx + 1:02d}",
        "text": text,
        "decoded": bool(text),
        "x0": round(float(pts[0, 0]), 1),
        "y0": round(float(pts[0, 1]), 1),
        "x1": round(float(pts[1, 0]), 1),
        "y1": round(float(pts[1, 1]), 1),
        "x2": round(float(pts[2, 0]), 1),
        "y2": round(float(pts[2, 1]), 1),
        "x3": round(float(pts[3, 0]), 1),
        "y3": round(float(pts[3, 1]), 1),
        "cx": round(cx, 1),
        "cy": round(cy, 1),
        "x": int(round(x_min)),
        "y": int(round(y_min)),
        "w": max(1, int(round(x_max - x_min))),
        "h": max(1, int(round(y_max - y_min))),
    }


@op("qrcode")
def op_qrcode(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    # The detector works on either grayscale or BGR — grayscale is enough and
    # avoids surprises if an upstream step has already converted.
    gray = to_grayscale(image)

    detector_kind = str(params.get("detector", "STANDARD")).upper()
    show_undecoded = bool(params.get("showUndecoded", False))

    detector = _make_detector(detector_kind)

    try:
        ok, decoded, points, _straight = detector.detectAndDecodeMulti(gray)
    except cv2.error:
        ok = False
        decoded = []
        points = None

    if not ok or points is None or len(points) == 0:
        # Pass through — no codes found.
        return ApplyResult(image=image, rows=[])

    rows: list[dict[str, Any]] = []
    for i, corners in enumerate(points):
        text = decoded[i] if i < len(decoded) and decoded[i] else ""
        if not text and not show_undecoded:
            continue
        rows.append(_row_from_corners(len(rows), corners, text))

    return ApplyResult(image=image, rows=rows)
