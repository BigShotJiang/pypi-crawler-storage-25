"""Helpers shared across operator modules."""

from __future__ import annotations

import numpy as np


def to_grayscale(image: np.ndarray) -> np.ndarray:
    """Return an 8-bit single-channel grayscale view of ``image``."""
    import cv2

    if image.ndim == 2:
        return image
    if image.ndim == 3 and image.shape[2] == 1:
        return image[..., 0]
    if image.ndim == 3 and image.shape[2] == 3:
        return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    if image.ndim == 3 and image.shape[2] == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2GRAY)
    raise ValueError(f"Cannot convert image with shape {image.shape} to grayscale")


def to_bgr(image: np.ndarray) -> np.ndarray:
    """Return a 3-channel BGR view (the format OpenCV writes by default)."""
    import cv2

    if image.ndim == 2:
        return cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    if image.ndim == 3 and image.shape[2] == 4:
        return cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)
    return image


def scalar(metric: str, value: float | int | str) -> dict[str, float | int | str]:
    return {"metric": metric, "value": value}
