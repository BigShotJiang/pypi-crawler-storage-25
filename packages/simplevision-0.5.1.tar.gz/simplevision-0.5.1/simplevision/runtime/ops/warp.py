"""Warp / Fixture — cv2.warpAffine / cv2.warpPerspective operator."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar
from ._registry import ApplyResult, op


@op("warp")
def op_warp(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    mode = params.get("mode", "Perspective")
    src_pts = params.get("src")
    out_w = int(params.get("outW", 640))
    out_h = int(params.get("outH", 480))
    interp_name = params.get("interp", "Bilinear")
    interp = {
        "Nearest": cv2.INTER_NEAREST,
        "Bilinear": cv2.INTER_LINEAR,
        "Bicubic": cv2.INTER_CUBIC,
    }.get(interp_name, cv2.INTER_LINEAR)

    if not src_pts:
        return ApplyResult(
            image=image,
            rows=[scalar("Status", "no corners set — pass-through")],
        )

    src = np.array([[p["x"], p["y"]] for p in src_pts], dtype=np.float32)

    if mode == "Affine":
        if len(src) < 3:
            return ApplyResult(
                image=image,
                rows=[scalar("Status", "need 3 corners")],
            )
        dst = np.array(
            [[0, 0], [out_w - 1, 0], [0, out_h - 1]], dtype=np.float32
        )
        M = cv2.getAffineTransform(src[:3], dst)
        out = cv2.warpAffine(
            image, M, (out_w, out_h), flags=interp, borderMode=cv2.BORDER_REPLICATE
        )
    else:  # Perspective
        if len(src) < 4:
            return ApplyResult(
                image=image,
                rows=[scalar("Status", "need 4 corners")],
            )
        dst = np.array(
            [
                [0, 0],
                [out_w - 1, 0],
                [out_w - 1, out_h - 1],
                [0, out_h - 1],
            ],
            dtype=np.float32,
        )
        M = cv2.getPerspectiveTransform(src[:4], dst)
        out = cv2.warpPerspective(
            image, M, (out_w, out_h), flags=interp, borderMode=cv2.BORDER_REPLICATE
        )

    rows = [
        scalar("Mode", mode),
        scalar("Output size", f"{out_w}×{out_h}"),
        scalar("Interpolation", interp_name),
    ]
    return ApplyResult(image=out, rows=rows)
