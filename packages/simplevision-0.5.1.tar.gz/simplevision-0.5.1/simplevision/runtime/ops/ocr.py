"""OCR — read text inside a user-drawn region with RapidOCR (ONNX Runtime).

Workflow:
  - User draws a rectangular ROI on the viewer; stored on the step's params
    as ``roi = {x, y, w, h}``. That rectangle is the area the OCR engine reads.
  - At run time we crop the ROI from the source image and feed it to RapidOCR
    which runs PaddleOCR-derived detection + recognition models via ONNX.
  - The output image is the original grayscale (OCR is a read, not a transform).
    Rows are one dict per recognised text line, with absolute frame coordinates
    so the overlay can draw boxes on top of the viewer.

The engine is loaded lazily on first use and cached for the process lifetime
so subsequent runs don't reload the ONNX models (~50 MB).

If rapidocr-onnxruntime isn't installed, the op returns a single ``error``
scalar row so the failure is visible in the UI rather than crashing the runtime.
If ``roi`` is ``None`` the step passes the image through unchanged.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


# Cached RapidOCR engine. RapidOCR loads ~50 MB of ONNX models on construction,
# so we keep one instance per process. The cached failure path mirrors the
# success path so we don't retry the import on every step run.
_engine: Any = None
_engine_error: str | None = None


def _get_engine() -> Any:
    global _engine, _engine_error
    if _engine is not None:
        return _engine
    if _engine_error is not None:
        raise RuntimeError(_engine_error)
    try:
        from rapidocr_onnxruntime import RapidOCR
    except ImportError as exc:
        _engine_error = (
            "rapidocr-onnxruntime not installed. Reinstall the runtime with "
            f"the [ocr] extras (pip install '.[ocr]'). ({exc})"
        )
        raise RuntimeError(_engine_error) from exc
    _engine = RapidOCR()
    return _engine


@op("ocr")
def op_ocr(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    gray = to_grayscale(image)

    roi = params.get("roi")
    if not roi:
        return ApplyResult(image=gray, rows=[])

    h, w = gray.shape[:2]
    rx = max(0, min(int(roi.get("x", 0)), w - 1))
    ry = max(0, min(int(roi.get("y", 0)), h - 1))
    rw = max(1, min(int(roi.get("w", 1)), w - rx))
    rh = max(1, min(int(roi.get("h", 1)), h - ry))

    crop = gray[ry : ry + rh, rx : rx + rw]
    if crop.size == 0:
        return ApplyResult(image=gray, rows=[])

    try:
        engine = _get_engine()
    except RuntimeError as exc:
        return ApplyResult(image=gray, rows=[{"metric": "error", "value": str(exc)}])

    min_conf = float(params.get("minConfidence", 50))

    # RapidOCR returns (result, elapse). `result` is either None or a list of
    # (quad_box, text, score) tuples; quad_box is 4 corner points (top-left,
    # top-right, bottom-right, bottom-left) — possibly rotated.
    try:
        result, _elapse = engine(crop)
    except Exception as exc:  # noqa: BLE001
        return ApplyResult(
            image=gray,
            rows=[{"metric": "error", "value": f"OCR failed: {exc}"}],
        )

    rows: list[dict[str, Any]] = []
    texts: list[str] = []
    if result:
        for item in result:
            try:
                box_quad, text, score_raw = item
            except (TypeError, ValueError):
                continue
            text = (text or "").strip()
            if not text:
                continue
            conf = float(score_raw) * 100.0
            if conf < min_conf:
                continue
            xs = [float(p[0]) for p in box_quad]
            ys = [float(p[1]) for p in box_quad]
            bx = int(min(xs)) + rx
            by = int(min(ys)) + ry
            bw = int(max(xs) - min(xs))
            bh = int(max(ys) - min(ys))
            rows.append(
                {
                    "label": f"W{len(rows) + 1:02d}",
                    "text": text,
                    "score": round(conf, 1),
                    "cx": round(bx + bw / 2.0, 1),
                    "cy": round(by + bh / 2.0, 1),
                    "x": bx,
                    "y": by,
                    "w": bw,
                    "h": bh,
                }
            )
            texts.append(text)

    if rows:
        # Synthetic first row carries the concatenated text + ROI bbox so the
        # UI can surface "what did OCR see" with a single lookup.
        rows.insert(
            0,
            {
                "label": "TEXT",
                "text": " ".join(texts),
                "score": round(sum(r["score"] for r in rows) / max(1, len(rows)), 1),
                "cx": rx + rw / 2.0,
                "cy": ry + rh / 2.0,
                "x": rx,
                "y": ry,
                "w": rw,
                "h": rh,
            },
        )

    return ApplyResult(image=gray, rows=rows)
