"""Skeleton — reduce foreground regions to a 1-pixel-wide centerline.

OpenCV's ``cv2.ximgproc.thinning`` lives in the ``opencv-contrib-python``
build, which we don't depend on. So this module implements two thinners
itself, both well-known textbook algorithms:

  - ``ZhangSuen`` — the iterative two-pass algorithm from Zhang & Suen
    (1984). Produces 1-px-wide, fully connected skeletons. Implemented
    with vectorised NumPy so it stays interactive on typical lab frames
    (a few hundred kilopixels).

  - ``Morph`` — Lantuéjoul-style morphological skeletonisation: repeatedly
    erode the image and OR in the residual of the opening of the eroded
    image. Faster on big blobs but can leave isolated dots.

Both algorithms operate on a binary mask (0 / 255). If the input is grayscale
we Otsu it first; if ``invertInput`` is true we flip polarity so dark-on-light
inputs (printed text, etched markings) skeletonise without an extra invert
step.
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_grayscale
from ._registry import ApplyResult, op


def _ensure_binary(image: np.ndarray) -> np.ndarray:
    if image.ndim == 2 and ((image == 0) | (image == 255)).all():
        return image
    gray = to_grayscale(image)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return mask


# Pre-computed lookup tables for Zhang-Suen.
#
# For each of the 256 possible 8-neighbour patterns around a foreground pixel
# we precompute the two Zhang-Suen conditions:
#   - B(P1): number of non-zero neighbours, must be 2..6
#   - A(P1): number of 0→1 transitions in the ordered sequence P2..P9..P2
#
# The two sub-iterations differ in *which* two neighbour-triples must contain
# at least one background pixel — captured by ``_DELETE_A`` / ``_DELETE_B``.
def _build_zs_tables() -> tuple[np.ndarray, np.ndarray]:
    delete_a = np.zeros(256, dtype=bool)
    delete_b = np.zeros(256, dtype=bool)
    for code in range(256):
        # Bits represent P2..P9 (clockwise from N). Reconstruct list of 0/1.
        p = [(code >> i) & 1 for i in range(8)]
        # Number of 0→1 transitions in cyclic sequence p2..p9..p2.
        transitions = 0
        for i in range(8):
            if p[i] == 0 and p[(i + 1) % 8] == 1:
                transitions += 1
        nonzero = sum(p)
        cond_b = 2 <= nonzero <= 6
        cond_a = transitions == 1
        # Sub-iter 1: P2·P4·P6 == 0 AND P4·P6·P8 == 0.
        cond_c1 = (p[0] * p[2] * p[4]) == 0
        cond_d1 = (p[2] * p[4] * p[6]) == 0
        # Sub-iter 2: P2·P4·P8 == 0 AND P2·P6·P8 == 0.
        cond_c2 = (p[0] * p[2] * p[6]) == 0
        cond_d2 = (p[0] * p[4] * p[6]) == 0
        delete_a[code] = cond_a and cond_b and cond_c1 and cond_d1
        delete_b[code] = cond_a and cond_b and cond_c2 and cond_d2
    return delete_a, delete_b


_ZS_DELETE_A, _ZS_DELETE_B = _build_zs_tables()


def _zhang_suen(mask: np.ndarray) -> np.ndarray:
    """Vectorised Zhang-Suen thinning. ``mask`` is uint8 with 0/255."""
    img = (mask > 0).astype(np.uint8)
    h, w = img.shape
    # Bit-codes computed per-iteration over the inner pixels only.
    while True:
        padded = np.zeros((h + 2, w + 2), dtype=np.uint8)
        padded[1:-1, 1:-1] = img
        # Build neighbour-bitmap: each bit position is a neighbour, in the
        # order P2..P9 clockwise from north. Sum into a uint8.
        code = (
            (padded[0:-2, 1:-1] << 0)   # P2 N
            | (padded[0:-2, 2:] << 1)    # P3 NE
            | (padded[1:-1, 2:] << 2)    # P4 E
            | (padded[2:, 2:] << 3)      # P5 SE
            | (padded[2:, 1:-1] << 4)    # P6 S
            | (padded[2:, 0:-2] << 5)    # P7 SW
            | (padded[1:-1, 0:-2] << 6)  # P8 W
            | (padded[0:-2, 0:-2] << 7)  # P9 NW
        )
        # Only foreground pixels can be deleted.
        fg = img == 1
        # Sub-iter 1.
        delete = fg & _ZS_DELETE_A[code]
        changed = delete.any()
        if changed:
            img[delete] = 0

        # Recompute code for sub-iter 2 (img has changed).
        padded[1:-1, 1:-1] = img
        code = (
            (padded[0:-2, 1:-1] << 0)
            | (padded[0:-2, 2:] << 1)
            | (padded[1:-1, 2:] << 2)
            | (padded[2:, 2:] << 3)
            | (padded[2:, 1:-1] << 4)
            | (padded[2:, 0:-2] << 5)
            | (padded[1:-1, 0:-2] << 6)
            | (padded[0:-2, 0:-2] << 7)
        )
        fg = img == 1
        delete = fg & _ZS_DELETE_B[code]
        if delete.any():
            img[delete] = 0
            changed = True

        if not changed:
            break

    return (img * 255).astype(np.uint8)


def _morph_skeleton(mask: np.ndarray) -> np.ndarray:
    """Lantuéjoul-style morphological skeleton."""
    img = mask.copy()
    skel = np.zeros_like(img)
    kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    # Safety cap — at worst the diameter shrinks by 1 per pass, so
    # ``max(h, w) // 2`` iterations is enough for any real input.
    for _ in range(max(img.shape) // 2 + 4):
        opened = cv2.morphologyEx(img, cv2.MORPH_OPEN, kernel)
        residual = cv2.subtract(img, opened)
        skel = cv2.bitwise_or(skel, residual)
        eroded = cv2.erode(img, kernel)
        if cv2.countNonZero(eroded) == 0:
            break
        img = eroded
    return skel


@op("skeleton")
def op_skeleton(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    mask = _ensure_binary(image)
    if bool(params.get("invertInput", False)):
        mask = cv2.bitwise_not(mask)

    algorithm = str(params.get("algorithm", "ZhangSuen"))
    if algorithm == "Morph":
        out = _morph_skeleton(mask)
    else:
        out = _zhang_suen(mask)

    fg = int((out > 0).sum())
    coverage = fg / out.size * 100.0
    rows = [
        scalar("Algorithm", algorithm),
        scalar("Skeleton px", fg),
        scalar("Coverage", f"{coverage:.3f}%"),
    ]
    return ApplyResult(image=out, rows=rows)
