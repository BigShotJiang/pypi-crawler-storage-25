"""Range Threshold — cv2.inRange on all three channels at once.

VA's "Color Threshold (HSL)" is the obvious model: pick a colour space,
set per-channel bounds, get a binary mask. ``colorthr`` here only takes a
single scalar lower/upper applied to *every* channel — useful but blunt.
This op takes individual ranges per channel and adds:

  - ``wrapH``    for hue-axis wrap-around (red sits at 170..179 and 0..10
                 in HSV; the runtime ORs two inRange calls in that case)
  - ``invert``   for the common "everything except this colour" framing
  - ``cleanup``  light morphological open to drop speckle without the
                 student needing to chain a separate Morphology step
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_bgr
from ._registry import ApplyResult, op


_SPACE_CODES: dict[str, int | None] = {
    "HSV": cv2.COLOR_BGR2HSV,
    "HLS": cv2.COLOR_BGR2HLS,
    "Lab": cv2.COLOR_BGR2LAB,
    "BGR": None,
}


def _odd(k: int) -> int:
    k = int(k)
    if k < 3:
        return 0
    return k if k % 2 == 1 else k + 1


@op("rangethr")
def op_rangethr(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    bgr = to_bgr(image)
    space = str(params.get("space", "HSV"))
    code = _SPACE_CODES.get(space)
    src = bgr if code is None else cv2.cvtColor(bgr, code)

    c0_low = int(params.get("c0Low", 0))
    c0_high = int(params.get("c0High", 255))
    c1_low = int(params.get("c1Low", 0))
    c1_high = int(params.get("c1High", 255))
    c2_low = int(params.get("c2Low", 0))
    c2_high = int(params.get("c2High", 255))

    # Channel-0 maximum differs in HSV/HLS — OpenCV encodes H in 0..179.
    # Clamp here to avoid the slider letting the student set 200 and quietly
    # match nothing.
    max_c0 = 179 if space in ("HSV", "HLS") else 255
    c0_low = max(0, min(c0_low, max_c0))
    c0_high = max(0, min(c0_high, max_c0))

    wrap_h = bool(params.get("wrapH", False))

    lower = np.array([c0_low, c1_low, c2_low], dtype=np.uint8)
    upper = np.array([c0_high, c1_high, c2_high], dtype=np.uint8)

    if wrap_h and space in ("HSV", "HLS") and c0_low > c0_high:
        # Two-half mask: [c0_low, max] ∪ [0, c0_high].
        lower_a = np.array([c0_low, c1_low, c2_low], dtype=np.uint8)
        upper_a = np.array([max_c0, c1_high, c2_high], dtype=np.uint8)
        lower_b = np.array([0, c1_low, c2_low], dtype=np.uint8)
        upper_b = np.array([c0_high, c1_high, c2_high], dtype=np.uint8)
        mask_a = cv2.inRange(src, lower_a, upper_a)
        mask_b = cv2.inRange(src, lower_b, upper_b)
        mask = cv2.bitwise_or(mask_a, mask_b)
    else:
        if c0_low > c0_high:
            c0_low, c0_high = c0_high, c0_low
            lower[0], upper[0] = c0_low, c0_high
        mask = cv2.inRange(src, lower, upper)

    if bool(params.get("invert", False)):
        mask = cv2.bitwise_not(mask)

    cleanup = _odd(int(params.get("cleanup", 0)))
    if cleanup >= 3:
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (cleanup, cleanup))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)

    coverage = float((mask > 0).sum()) / mask.size * 100.0
    rows = [
        scalar("Space", space),
        scalar("Ch0 range", f"[{c0_low}, {c0_high}]"),
        scalar("Ch1 range", f"[{c1_low}, {c1_high}]"),
        scalar("Ch2 range", f"[{c2_low}, {c2_high}]"),
        scalar("Coverage", f"{coverage:.2f}%"),
    ]
    if wrap_h and space in ("HSV", "HLS"):
        rows.append(scalar("Wrap H", "yes"))
    if cleanup >= 3:
        rows.append(scalar("Cleanup", f"{cleanup}×{cleanup}"))
    return ApplyResult(image=mask, rows=rows)
