"""Geometric Match — rotation/scale-invariant template match.

Workflow:
  - Student draws a rectangular ROI; that's the template.
  - At run time we extract keypoints + descriptors from both the template
    crop and the scene using either ORB (binary descriptors, fast) or
    AKAZE (slower, more robust on textured surfaces).
  - Brute-force k-nearest matcher with k=2 and a Lowe ratio test filters
    out ambiguous matches.
  - cv2.findHomography(RANSAC) fits the rigid transformation.
  - The fitted homography is used to project the template's 4 corners
    into the scene — those become the visible polygon in the overlay.
  - When multi-instance is enabled we mask out the matched region and
    re-run on the residual until either ``maxHits`` is reached or a new
    match falls below the inlier-ratio threshold.

The image is passed through unchanged — matching is a detection, not a
transform.
"""

from __future__ import annotations

import math
from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


def _make_detector(kind: str, max_features: int):
    if kind == "AKAZE":
        try:
            return cv2.AKAZE_create()
        except cv2.error:
            return cv2.ORB_create(nfeatures=max_features)
    return cv2.ORB_create(nfeatures=max_features)


def _detect_and_compute(detector, image: np.ndarray):
    kp, des = detector.detectAndCompute(image, None)
    if kp is None or des is None or len(kp) == 0:
        return [], None
    return kp, des


def _match(des_t, des_s, lowe_ratio: float, is_binary: bool) -> list[Any]:
    if des_t is None or des_s is None:
        return []
    norm = cv2.NORM_HAMMING if is_binary else cv2.NORM_L2
    bf = cv2.BFMatcher(norm)
    try:
        knn = bf.knnMatch(des_t, des_s, k=2)
    except cv2.error:
        return []
    good = []
    for pair in knn:
        if len(pair) < 2:
            continue
        m, n = pair[0], pair[1]
        if m.distance < lowe_ratio * n.distance:
            good.append(m)
    return good


def _angle_from_homography(H: np.ndarray) -> tuple[float, float]:
    """Extract a rotation angle (deg, 0..360) and scale factor from H.
    For a similarity-like homography this is exact; for general H it's a
    first-order approximation — good enough as a UX read-out."""
    # First column of H captures the projected x-axis vector.
    a = float(H[0, 0])
    b = float(H[1, 0])
    angle = math.degrees(math.atan2(b, a))
    scale = math.hypot(a, b)
    return angle, scale


def _project_corners(template_w: int, template_h: int, H: np.ndarray) -> np.ndarray:
    corners = np.array(
        [[0, 0], [template_w, 0], [template_w, template_h], [0, template_h]],
        dtype=np.float32,
    ).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(corners, H).reshape(-1, 2)


def _row_from_projection(
    idx: int, proj: np.ndarray, score: float, inliers: int, angle: float, scale: float
) -> dict[str, Any]:
    xs = proj[:, 0]
    ys = proj[:, 1]
    cx = float(xs.mean())
    cy = float(ys.mean())
    return {
        "label": f"G{idx + 1:02d}",
        "score": round(float(score) * 100.0, 1),
        "inliers": int(inliers),
        "angle": round(float(angle), 1),
        "scale": round(float(scale), 3),
        "cx": round(cx, 1),
        "cy": round(cy, 1),
        "x0": round(float(proj[0, 0]), 1),
        "y0": round(float(proj[0, 1]), 1),
        "x1": round(float(proj[1, 0]), 1),
        "y1": round(float(proj[1, 1]), 1),
        "x2": round(float(proj[2, 0]), 1),
        "y2": round(float(proj[2, 1]), 1),
        "x3": round(float(proj[3, 0]), 1),
        "y3": round(float(proj[3, 1]), 1),
    }


@op("geomatch")
def op_geomatch(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    gray = to_grayscale(image)
    h, w = gray.shape[:2]
    roi = params.get("roi")
    if not roi:
        return ApplyResult(image=image, rows=[])

    rx = max(0, min(int(roi.get("x", 0)), w - 1))
    ry = max(0, min(int(roi.get("y", 0)), h - 1))
    rw = max(1, min(int(roi.get("w", 1)), w - rx))
    rh = max(1, min(int(roi.get("h", 1)), h - ry))
    template = gray[ry : ry + rh, rx : rx + rw]

    if template.size == 0 or rh < 20 or rw < 20:
        # Below ~20 px on a side the descriptors are essentially noise.
        return ApplyResult(image=image, rows=[])

    detector_kind = str(params.get("detector", "ORB")).upper()
    max_features = max(100, int(params.get("maxFeatures", 800)))
    lowe = max(0.4, min(0.95, float(params.get("loweRatio", 0.75))))
    ransac_thr = max(1.0, float(params.get("ransacThreshold", 4)))
    min_inlier_ratio = max(0.0, min(1.0, float(params.get("minInlierRatio", 0.12))))
    multi = bool(params.get("multiInstance", False))
    max_hits = max(1, int(params.get("maxHits", 5)))

    detector = _make_detector(detector_kind, max_features)
    is_binary = detector_kind == "ORB"

    kp_t, des_t = _detect_and_compute(detector, template)
    if not kp_t or des_t is None:
        return ApplyResult(image=image, rows=[])

    scene = gray.copy()
    mask = np.full(scene.shape, 255, dtype=np.uint8)

    rows: list[dict[str, Any]] = []
    iterations = max_hits if multi else 1
    for _ in range(iterations):
        kp_s, des_s = detector.detectAndCompute(scene, mask)
        if not kp_s or des_s is None or len(kp_s) < 4:
            break

        matches = _match(des_t, des_s, lowe, is_binary)
        if len(matches) < 6:
            break

        src_pts = np.array(
            [kp_t[m.queryIdx].pt for m in matches], dtype=np.float32
        ).reshape(-1, 1, 2)
        dst_pts = np.array(
            [kp_s[m.trainIdx].pt for m in matches], dtype=np.float32
        ).reshape(-1, 1, 2)

        try:
            H, inlier_mask = cv2.findHomography(
                src_pts, dst_pts, cv2.RANSAC, ransac_thr
            )
        except cv2.error:
            break
        if H is None or inlier_mask is None:
            break

        inliers = int(inlier_mask.sum())
        if inliers < 4:
            break
        ratio = inliers / max(1, len(matches))
        if ratio < min_inlier_ratio:
            break

        proj = _project_corners(rw, rh, H)
        # Sanity: drop nonsensical projections (collapsed / mirrored / huge).
        area = abs(cv2.contourArea(proj.astype(np.float32)))
        template_area = float(rw * rh)
        if area < template_area * 0.05 or area > template_area * 40:
            break

        angle, scale = _angle_from_homography(H)
        rows.append(
            _row_from_projection(len(rows), proj, ratio, inliers, angle, scale)
        )

        if not multi:
            break

        # Mask the matched region out of the scene so the next iteration
        # finds a different instance. Fill the projected quad with zeros in
        # the search mask.
        cv2.fillPoly(mask, [proj.astype(np.int32)], 0)

    return ApplyResult(image=image, rows=rows)
