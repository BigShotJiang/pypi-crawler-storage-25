"""Central op registry.

Each op function is decorated with ``@op("fnId")``. At import time the
decorator inserts the function into ``REGISTRY``. ``ops/__init__.py``
auto-imports every non-underscore module under ``ops/``, which triggers
all the ``@op`` calls — no manual dispatch dict.

The shared dataclass/typing live here so individual op modules can import
without depending on the package ``__init__`` (which itself imports them).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

import numpy as np

from ..context import Context


@dataclass
class ApplyResult:
    image: np.ndarray
    rows: list[dict[str, Any]]
    preview: np.ndarray | None = None


Operator = Callable[[np.ndarray, dict[str, Any], Context], ApplyResult]


REGISTRY: dict[str, Operator] = {}


def op(fn_id: str) -> Callable[[Operator], Operator]:
    """Register ``fn`` under ``fn_id``. Raises if the id is taken."""

    def decorator(fn: Operator) -> Operator:
        if fn_id in REGISTRY:
            raise RuntimeError(
                f"Duplicate op registration for fnId={fn_id!r} "
                f"(existing: {REGISTRY[fn_id].__module__}.{REGISTRY[fn_id].__name__}, "
                f"new: {fn.__module__}.{fn.__name__})"
            )
        REGISTRY[fn_id] = fn
        return fn

    return decorator


def get(fn_id: str) -> Operator:
    if fn_id not in REGISTRY:
        raise KeyError(f"Unknown fnId: {fn_id}")
    return REGISTRY[fn_id]
