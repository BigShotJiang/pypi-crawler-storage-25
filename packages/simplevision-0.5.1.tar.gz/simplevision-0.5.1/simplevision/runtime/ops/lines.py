"""Find straight line segments via Probabilistic Hough Transform."""

from __future__ import annotations

import math
from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op


@op("lines")
def op_lines(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    """Detect straight line segments using cv2.HoughLinesP.

    Accepts binary or grayscale input. If the image is not already a binary
    edge map, auto-Canny is applied before Hough so this node can sit
    directly after a grayscale step without requiring an explicit Canny step.
    """
    gray = to_grayscale(image) if image.ndim == 3 else image

    # Detect if image is already a binary edge map (all pixels 0 or 255).
    is_binary = image.ndim == 2 and bool(((gray == 0) | (gray == 255)).all())
    edges = gray if is_binary else cv2.Canny(gray, 50, 150)

    min_len = int(params.get("minLineLength", 40))
    max_gap = int(params.get("maxLineGap", 10))
    thr = int(params.get("threshold", 80))
    max_hits = int(params.get("maxHits", 200))

    lines = cv2.HoughLinesP(
        edges, 1, np.pi / 180, thr, minLineLength=min_len, maxLineGap=max_gap
    )

    rows: list[dict[str, Any]] = []
    if lines is not None:
        do_filter = bool(params.get("orientationFilter", False))
        tgt = float(params.get("targetAngle", 0))
        tol = float(params.get("angleTolerance", 10))

        for x1, y1, x2, y2 in lines[: max_hits, 0]:
            ang = math.degrees(math.atan2(y2 - y1, x2 - x1))
            # Normalise to (-90, 90].
            while ang > 90:
                ang -= 180
            while ang <= -90:
                ang += 180

            if do_filter:
                diff = abs(((ang - tgt + 90) % 180) - 90)
                if diff > tol:
                    continue

            length = math.hypot(x2 - x1, y2 - y1)
            rows.append(
                {
                    "label": f"L{len(rows) + 1:02d}",
                    "x1": int(x1),
                    "y1": int(y1),
                    "x2": int(x2),
                    "y2": int(y2),
                    "angle": round(ang, 1),
                    "length": round(length, 1),
                }
            )

    return ApplyResult(image=image, rows=rows)
