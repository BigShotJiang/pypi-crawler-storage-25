"""Custom convolution operator — cv2.filter2D with a user-defined kernel."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar
from ._registry import ApplyResult, op


@op("convolve")
def op_convolve(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    size = int(params.get("size", 3))
    if size not in (3, 5):
        size = 3

    kernel_list = params.get("kernel", [])
    if len(kernel_list) != size * size:
        # Fall back to identity if the stored kernel doesn't match the size.
        kernel_list = [0.0] * (size * size)
        kernel_list[size * size // 2] = 1.0

    kernel = np.array(kernel_list, dtype=np.float32).reshape(size, size)
    scale = float(params.get("scale", 1.0))
    delta = float(params.get("delta", 0.0))

    out = cv2.filter2D(
        image,
        ddepth=-1,
        kernel=kernel * scale,
        delta=delta,
        borderType=cv2.BORDER_REPLICATE,
    )

    rows = [
        scalar("Kernel size", f"{size}×{size}"),
        scalar("Preset", params.get("preset", "Custom")),
        scalar("Sum", round(float(kernel.sum() * scale), 3)),
        scalar("Scale", scale),
        scalar("Delta", delta),
    ]
    return ApplyResult(image=out, rows=rows)
