"""Binary category: thr, adapt, erode, dilate, blob, particle."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_grayscale
from ._registry import ApplyResult, op


def _odd(k: int) -> int:
    k = int(k)
    return k if k % 2 == 1 else k + 1


@op("thr")
def op_thr(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    method = params.get("method", "Auto")
    lower = int(params.get("lower", 64))
    upper = int(params.get("upper", 255))
    gray = to_grayscale(image)

    if method in ("Otsu", "Auto"):
        threshold_used, out = cv2.threshold(
            gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
        )
    elif method == "Manual":
        threshold_used = lower
        _, mask_low = cv2.threshold(gray, lower, 255, cv2.THRESH_BINARY)
        _, mask_high = cv2.threshold(gray, upper, 255, cv2.THRESH_BINARY_INV)
        out = cv2.bitwise_and(mask_low, mask_high)
    elif method == "Adaptive":
        threshold_used = -1
        out = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 4
        )
    else:
        threshold_used, out = cv2.threshold(gray, lower, 255, cv2.THRESH_BINARY)

    coverage = float((out > 0).sum()) / out.size * 100.0
    rows = [
        scalar("Method", method),
        scalar("Threshold", int(threshold_used) if threshold_used >= 0 else "adaptive"),
        scalar("Coverage", f"{coverage:.1f}%"),
        scalar("Mean", round(float(gray.mean()), 2)),
    ]
    return ApplyResult(image=out, rows=rows)


@op("adapt")
def op_adapt(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    block = max(3, _odd(int(params.get("block", 11))))
    c = int(params.get("c", 4))
    gray = to_grayscale(image)
    out = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, block, c
    )
    coverage = float((out > 0).sum()) / out.size * 100.0
    rows = [scalar("Block", block), scalar("C", c), scalar("Coverage", f"{coverage:.1f}%")]
    return ApplyResult(image=out, rows=rows)


@op("erode")
def op_erode(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    k = _odd(int(params.get("kernel", 3)))
    iters = int(params.get("iter", 1))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
    out = cv2.erode(image, kernel, iterations=iters)
    rows = [scalar("Kernel", f"{k}×{k}"), scalar("Iterations", iters)]
    return ApplyResult(image=out, rows=rows)


@op("dilate")
def op_dilate(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    k = _odd(int(params.get("kernel", 3)))
    iters = int(params.get("iter", 1))
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (k, k))
    out = cv2.dilate(image, kernel, iterations=iters)
    rows = [scalar("Kernel", f"{k}×{k}"), scalar("Iterations", iters)]
    return ApplyResult(image=out, rows=rows)


def _ensure_binary(image: np.ndarray) -> np.ndarray:
    if image.ndim == 2 and ((image == 0) | (image == 255)).all():
        return image
    gray = to_grayscale(image)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return mask


@op("blob")
def op_blob(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    """Find connected components. Propagates the binary mask unchanged so
    downstream ops (e.g. particle) can re-analyse it. Bounding boxes are
    rendered live as an SVG overlay in the Svelte viewer, not baked into
    the preview."""
    min_area = int(params.get("minArea", 0))
    max_area = int(params.get("maxArea", 1_000_000))
    connectivity = 8 if str(params.get("connectivity", "8")) == "8" else 4

    mask = _ensure_binary(image)
    n, labels, stats, centroids = cv2.connectedComponentsWithStats(
        mask, connectivity=connectivity, ltype=cv2.CV_32S
    )

    # Keep every component (ok=True for accepted, ok=False for filtered).
    # The frontend uses the full distribution to render an area histogram;
    # the lab extractors filter by `ok` when computing the named outputs.
    rows: list[dict[str, Any]] = []
    ok_idx = 0
    rej_idx = 0
    for i in range(1, n):
        area = int(stats[i, cv2.CC_STAT_AREA])
        ok = min_area <= area <= max_area
        if ok:
            ok_idx += 1
            label = f"B{ok_idx:02d}"
        else:
            rej_idx += 1
            label = f"x{rej_idx:02d}"
        cx, cy = float(centroids[i, 0]), float(centroids[i, 1])
        x = int(stats[i, cv2.CC_STAT_LEFT])
        y = int(stats[i, cv2.CC_STAT_TOP])
        w = int(stats[i, cv2.CC_STAT_WIDTH])
        h = int(stats[i, cv2.CC_STAT_HEIGHT])
        comp_mask = (labels == i).astype(np.uint8) * 255
        contours, _ = cv2.findContours(
            comp_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE
        )
        perim = float(cv2.arcLength(contours[0], True)) if contours else 0.0
        circ = (4 * np.pi * area / (perim * perim)) if perim > 0 else 0.0
        rows.append(
            {
                "label": label,
                "score": round(min(999.0, 800 + circ * 200), 2),
                "area": area,
                "perim": round(perim, 1),
                "cx": round(cx, 1),
                "cy": round(cy, 1),
                "circ": round(float(circ), 3),
                "x": x,
                "y": y,
                "w": w,
                "h": h,
                "ok": ok,
            }
        )

    return ApplyResult(image=mask, rows=rows)


@op("particle")
def op_particle(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    """Measure per-particle properties on the binary mask. Iterates each
    connected component (foreground islands), not just outer contours, so
    a frame-spanning background doesn't swallow everything else.
    Propagates the binary mask unchanged. Centroid markers and labels
    are rendered live as an SVG overlay in the Svelte viewer."""
    _measure = params.get("measure", "Area + Circularity")
    mask = _ensure_binary(image)

    n, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask, connectivity=8, ltype=cv2.CV_32S
    )

    rows: list[dict[str, Any]] = []
    for i in range(1, n):
        area_cc = int(stats[i, cv2.CC_STAT_AREA])
        if area_cc < 1:
            continue
        comp_mask = (labels == i).astype(np.uint8) * 255
        contours, _ = cv2.findContours(
            comp_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE
        )
        if not contours:
            continue
        cnt = max(contours, key=cv2.contourArea)
        area = float(cv2.contourArea(cnt))
        if area < 1:
            continue
        perim = float(cv2.arcLength(cnt, True))
        circ = (4 * np.pi * area / (perim * perim)) if perim > 0 else 0.0
        m = cv2.moments(cnt)
        cx = m["m10"] / m["m00"] if m["m00"] else 0.0
        cy = m["m01"] / m["m00"] if m["m00"] else 0.0
        major = minor = 0.0
        if cnt.shape[0] >= 5:
            try:
                (_, (mw, mh), _) = cv2.fitEllipse(cnt)
                major = float(max(mw, mh))
                minor = float(min(mw, mh))
            except cv2.error:
                pass
        rows.append(
            {
                "label": f"P{len(rows) + 1:02d}",
                "area": int(round(area)),
                "perim": round(perim, 1),
                "circ": round(float(circ), 3),
                "cx": round(cx, 1),
                "cy": round(cy, 1),
                "major": round(major, 1),
                "minor": round(minor, 1),
            }
        )

    return ApplyResult(image=mask, rows=rows)
