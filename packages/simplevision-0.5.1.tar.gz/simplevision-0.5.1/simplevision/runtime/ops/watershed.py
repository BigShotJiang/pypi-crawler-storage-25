"""Watershed separation. Splits touching foreground regions in a binary mask
by finding peaks in the distance transform and using them as seeds for
cv2.watershed. Output is the input mask with separator lines (~1 px wide)
between previously-touching components — downstream `blob` will then count
them correctly.

Peak detection strategy (v1):
    Rather than iterative peak-picking ordered by distance value (which would
    give the most accurate NMS), we use a two-step morphological approach:
    1. Local maxima via dilate-and-compare (keeps any pixel equal to its
       neighbourhood maximum).
    2. A dilation by the min_distance radius to merge nearby candidate pixels
       into single connected blobs; connectedComponents then gives one marker
       per cluster.
    This is O(image_size) and GPU-friendly. The approximation means two peaks
    that are exactly `min_distance` apart might occasionally merge into one
    marker, but the error is bounded to ±1 separation for typical inputs.
    A future v2 could iterate peaks in descending dt order with suppression
    radii for exact ANMS behaviour.
"""
from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_grayscale
from ._registry import ApplyResult, op


def _ensure_binary(image: np.ndarray) -> np.ndarray:
    """Return a binary (0/255) single-channel mask from any supported image."""
    if image.ndim == 2 and ((image == 0) | (image == 255)).all():
        return image
    gray = to_grayscale(image)
    _, mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return mask


@op("watershed")
def op_watershed(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    mask = _ensure_binary(image)
    min_distance = max(1, int(params.get("minDistance", 20)))
    sens = float(params.get("sensitivity", 50))  # 0..100

    # Distance transform on foreground pixels only.
    dt = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
    if dt.max() <= 0:
        # No foreground — nothing to separate.
        return ApplyResult(image=mask, rows=[scalar("Separated count", 0)])

    # Peak threshold: higher sensitivity → lower ratio → more peaks survive.
    # Map sensitivity 0..100 → ratio 0.70..0.10.
    ratio = max(0.05, 0.70 - (sens / 100.0) * 0.60)
    peak_thr = float(dt.max()) * ratio

    # Step 1 — local maxima: a pixel is a candidate peak if it equals its
    # dilated neighbourhood AND exceeds the threshold.
    k3 = np.ones((3, 3), np.uint8)
    dilated = cv2.dilate(dt, k3)
    peaks_mask = ((dt >= dilated) & (dt > peak_thr)).astype(np.uint8) * 255

    # Step 2 — merge peaks within min_distance using morphological dilation.
    # Each resulting connected blob becomes exactly one watershed marker.
    if min_distance > 1:
        nms_kernel = cv2.getStructuringElement(
            cv2.MORPH_ELLIPSE,
            (min_distance * 2 + 1, min_distance * 2 + 1),
        )
        peaks_mask = cv2.dilate(peaks_mask, nms_kernel)

    # Label each peak cluster as a distinct marker (1..N).
    num_markers, markers = cv2.connectedComponents(peaks_mask)
    if num_markers <= 1:
        # Only background marker found — image likely has a single large blob
        # with no interior distance-transform peaks above the threshold.
        return ApplyResult(image=mask, rows=[scalar("Separated count", 0)])

    # Build the watershed marker image.
    # Convention used here:
    #   0  = "unknown" region (let watershed decide)
    #   1  = definite background
    #   2+ = definite foreground seeds (one per detected peak cluster)
    #
    # We obtain definite background by dilating the mask slightly, then
    # subtracting the peak regions to expose the unknown band.
    bg = cv2.dilate(mask, k3, iterations=3)
    unknown = cv2.subtract(bg, peaks_mask)

    markers = markers + 1          # shift: bg-candidates → ≥2, peaks → ≥3
    markers[unknown == 255] = 0    # uncertain band becomes 0 for watershed

    # cv2.watershed requires a 3-channel uint8 image.
    bgr = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    markers = markers.astype(np.int32)
    cv2.watershed(bgr, markers)
    # Boundary pixels are set to -1 by watershed.

    out = mask.copy()
    out[markers == -1] = 0  # carve thin separator lines into the mask

    separated_count = int(num_markers - 1)  # exclude background marker
    rows = [
        scalar("Separated count", separated_count),
        scalar("Sensitivity", sens),
        scalar("Min distance", min_distance),
    ]
    return ApplyResult(image=out, rows=rows)
