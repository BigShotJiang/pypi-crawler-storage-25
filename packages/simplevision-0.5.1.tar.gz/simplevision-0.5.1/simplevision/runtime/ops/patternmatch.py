"""Pattern Match — cv2.matchTemplate across a grayscale image.

Workflow:
  - User draws a rectangular ROI on the viewer; stored on the step's params
    as ``roi = {x, y, w, h}``.  That rectangle becomes the template.
  - At run time we crop the template from the current grayscale frame, call
    ``cv2.matchTemplate`` with the requested method (TM_CCOEFF_NORMED /
    TM_CCORR_NORMED / TM_SQDIFF_NORMED), apply a confidence threshold, run
    a greedy 2-D NMS to suppress overlapping detections, and return up to
    ``maxHits`` results as structured rows.
  - The output image is always the original grayscale (template matching is a
    detection, not a transform).

If ``roi`` is ``None`` the step passes the image through unchanged so the
preview continues to render while the user is still drawing.
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import to_grayscale
from ._registry import ApplyResult, op

# Map user-facing method labels to (cv2 flag, invert_score).
# SQDIFF scores are *lower* = better, so we invert to make "higher = better"
# consistent across all three methods.
_METHODS: dict[str, tuple[int, bool]] = {
    "CCOEFF": (cv2.TM_CCOEFF_NORMED, False),
    "CCORR":  (cv2.TM_CCORR_NORMED,  False),
    "SQDIFF": (cv2.TM_SQDIFF_NORMED, True),
}


def _nms_2d(
    positions: list[tuple[int, int]],
    scores: list[float],
    nms_distance: float,
) -> list[int]:
    """Greedy 2-D NMS.  Returns indices of kept positions in score-desc order."""
    if not positions:
        return []
    order = sorted(range(len(scores)), key=lambda i: -scores[i])
    kept: list[int] = []
    suppressed = [False] * len(order)
    for idx, i in enumerate(order):
        if suppressed[i]:
            continue
        kept.append(i)
        xi, yi = positions[i]
        for j in order[idx + 1 :]:
            if suppressed[j]:
                continue
            xj, yj = positions[j]
            dist = ((xi - xj) ** 2 + (yi - yj) ** 2) ** 0.5
            if dist < nms_distance:
                suppressed[j] = True
    return kept


@op("patternmatch")
def op_patternmatch(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    gray = to_grayscale(image)

    roi = params.get("roi")
    if not roi:
        # No template defined yet — pass through so the preview keeps working.
        return ApplyResult(image=gray, rows=[])

    h, w = gray.shape[:2]

    # Clamp ROI to image bounds.
    rx = max(0, min(int(roi.get("x", 0)), w - 1))
    ry = max(0, min(int(roi.get("y", 0)), h - 1))
    rw = max(1, min(int(roi.get("w", 1)), w - rx))
    rh = max(1, min(int(roi.get("h", 1)), h - ry))

    template = gray[ry : ry + rh, rx : rx + rw]
    if template.size == 0:
        return ApplyResult(image=gray, rows=[])

    # Template must be strictly smaller than the image for matchTemplate.
    if rh >= h or rw >= w:
        return ApplyResult(image=gray, rows=[])

    method_key = str(params.get("method", "CCOEFF")).upper()
    cv2_flag, invert = _METHODS.get(method_key, _METHODS["CCOEFF"])

    result = cv2.matchTemplate(gray, template, cv2_flag)

    # Threshold in [0, 100] maps to score in [0, 1].
    raw_threshold = float(params.get("threshold", 70)) / 100.0
    nms_distance = max(1.0, float(params.get("nmsDistance", 20)))
    max_hits = max(1, int(params.get("maxHits", 50)))

    if invert:
        # SQDIFF: 0 = perfect match, 1 = worst. Invert so higher = better.
        scores_map = 1.0 - result
    else:
        scores_map = result

    # Collect candidate positions where score >= threshold.
    mask = scores_map >= raw_threshold
    ys, xs = np.where(mask)
    if len(xs) == 0:
        return ApplyResult(image=gray, rows=[])

    positions = [(int(xs[i]), int(ys[i])) for i in range(len(xs))]
    raw_scores = [float(scores_map[ys[i], xs[i]]) for i in range(len(xs))]

    kept_indices = _nms_2d(positions, raw_scores, nms_distance)
    kept_indices = kept_indices[:max_hits]

    rows: list[dict[str, Any]] = []
    for idx, ki in enumerate(kept_indices):
        tx, ty = positions[ki]
        score = raw_scores[ki]
        # The template match position is the *top-left* of where the template lands.
        x = tx
        y = ty
        bw = rw
        bh = rh
        cx = x + bw / 2.0
        cy = y + bh / 2.0
        rows.append(
            {
                "label": f"P{idx + 1:02d}",
                "score": round(score * 100.0, 1),
                "cx": round(cx, 1),
                "cy": round(cy, 1),
                "x": x,
                "y": y,
                "w": bw,
                "h": bh,
            }
        )

    return ApplyResult(image=gray, rows=rows)
