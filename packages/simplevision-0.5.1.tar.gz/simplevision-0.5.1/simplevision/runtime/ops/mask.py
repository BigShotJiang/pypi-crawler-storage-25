"""Image Mask — restrict downstream processing to a region.

The student draws a rectangle, ellipse, or polygon on the viewer. At run
time we build a single-channel mask of the same shape (255 inside, 0
outside, optionally inverted and feathered) and bitwise-AND it against
the input image.

Pixels outside the region are replaced with the ``fill`` colour
(0 = black, 255 = white). The output dtype/channels match the input —
masking a colour image stays colour, masking a binary mask stays binary —
so the node can be inserted anywhere in the pipeline without breaking the
type chain.
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar
from ._registry import ApplyResult, op


def _make_alpha(
    shape: str,
    h: int,
    w: int,
    roi: dict[str, Any] | None,
    polygon: list[dict[str, Any]] | None,
    invert: bool,
    feather: int,
) -> np.ndarray:
    """Return an HxW float32 mask in [0,1] where 1 = keep."""
    alpha = np.zeros((h, w), dtype=np.uint8)

    if shape in ("Rectangle", "Ellipse") and roi:
        rx = max(0, min(int(roi.get("x", 0)), w - 1))
        ry = max(0, min(int(roi.get("y", 0)), h - 1))
        rw = max(1, min(int(roi.get("w", 1)), w - rx))
        rh = max(1, min(int(roi.get("h", 1)), h - ry))
        if shape == "Rectangle":
            alpha[ry : ry + rh, rx : rx + rw] = 255
        else:  # Ellipse
            cx = rx + rw // 2
            cy = ry + rh // 2
            ax = max(1, rw // 2)
            ay = max(1, rh // 2)
            cv2.ellipse(alpha, (cx, cy), (ax, ay), 0, 0, 360, 255, -1)
    elif shape == "Polygon" and polygon and len(polygon) >= 3:
        pts = np.array(
            [[int(v.get("x", 0)), int(v.get("y", 0))] for v in polygon],
            dtype=np.int32,
        )
        cv2.fillPoly(alpha, [pts], 255)
    else:
        # Nothing configured yet — keep everything so the preview keeps
        # rendering and the student sees their image while drawing.
        alpha[:] = 255

    if invert:
        alpha = cv2.bitwise_not(alpha)

    if feather > 0:
        # Box+gauss feather. We blur the binary edge then re-scale to [0,1].
        k = feather if feather % 2 == 1 else feather + 1
        alpha = cv2.GaussianBlur(alpha, (k * 2 + 1, k * 2 + 1), 0)

    return alpha.astype(np.float32) / 255.0


@op("mask")
def op_mask(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    h, w = image.shape[:2]
    shape = str(params.get("shape", "Rectangle"))
    roi = params.get("roi") if isinstance(params.get("roi"), dict) else None
    polygon_raw = params.get("polygon")
    polygon = polygon_raw if isinstance(polygon_raw, list) else None
    invert = bool(params.get("invert", False))
    feather = max(0, int(params.get("feather", 0)))
    fill = 255 if int(params.get("fill", 0)) == 255 else 0

    alpha = _make_alpha(shape, h, w, roi, polygon, invert, feather)

    if image.ndim == 2:
        fg = image.astype(np.float32)
        bg = np.full_like(fg, fill, dtype=np.float32)
        blended = fg * alpha + bg * (1.0 - alpha)
        out = blended.clip(0, 255).astype(np.uint8)
    else:
        a3 = alpha[..., None]
        fg = image.astype(np.float32)
        bg = np.full_like(fg, fill, dtype=np.float32)
        blended = fg * a3 + bg * (1.0 - a3)
        out = blended.clip(0, 255).astype(np.uint8)

    keep_pct = float(alpha.sum()) / alpha.size * 100.0
    rows = [
        scalar("Shape", shape),
        scalar("Invert", "yes" if invert else "no"),
        scalar("Feather", feather),
        scalar("Fill", fill),
        scalar("Kept", f"{keep_pct:.1f}%"),
    ]
    return ApplyResult(image=out, rows=rows)
