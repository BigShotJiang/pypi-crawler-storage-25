"""LUT node: brightness + contrast + gamma via cv2.LUT."""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar
from ._registry import ApplyResult, op


@op("lut")
def op_lut(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    brightness = float(params.get("brightness", 0))
    contrast = float(params.get("contrast", 0))
    gamma = max(0.01, float(params.get("gamma", 1.0)))

    bright_offset = brightness * 1.27
    contrast_gain = (contrast + 100.0) / 100.0
    inv_gamma = 1.0 / gamma

    x = np.arange(256, dtype=np.float32) / 255.0
    y = (np.power(x, inv_gamma) * 255.0 - 128.0) * contrast_gain + 128.0 + bright_offset
    lut = np.clip(y, 0, 255).astype(np.uint8)

    if image.ndim == 2:
        out = cv2.LUT(image, lut)
    else:
        # apply per channel (works for both 3-channel BGR and 4-channel BGRA)
        out = cv2.LUT(image, lut)

    rows = [
        scalar("Brightness", brightness),
        scalar("Contrast", contrast),
        scalar("Gamma", round(gamma, 2)),
    ]
    return ApplyResult(image=out, rows=rows)
