"""Operator package.

The central ``REGISTRY`` is populated by ``@op("fnId")`` decorators in each
op module. Importing this package auto-imports every non-underscore
module under ``ops/`` so the registrations happen up-front.

External callers:
- ``from .ops import get`` (executor lookup by fnId)
- ``from .ops import ApplyResult`` (return type for op authors)
- ``from .ops import op``           (decorator for new op modules)
"""

from __future__ import annotations

import pkgutil
from importlib import import_module

from ._registry import ApplyResult, Operator, REGISTRY, get, op


def _autoload() -> None:
    for info in pkgutil.iter_modules(__path__):
        if info.name.startswith("_"):
            continue
        import_module(f"{__name__}.{info.name}")


_autoload()


__all__ = ["REGISTRY", "ApplyResult", "Operator", "get", "op"]
