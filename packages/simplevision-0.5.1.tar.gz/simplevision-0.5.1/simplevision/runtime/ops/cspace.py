"""Color Space Convert — BGR → HSV / HLS / Lab / YCrCb / XYZ.

Unlike the existing ``extract`` op (which collapses to a single channel),
``cspace`` keeps the full 3-channel encoding so downstream colour-aware
nodes can operate in the chosen space. The ``view`` param lets the viewer
flatten to a single channel as a preview without changing what is passed
downstream.

If we did flatten the propagated image to one channel, ops further down
(e.g. HSV threshold) would lose access to the other two channels — which
is exactly why VA distinguishes "Color Space Convert" from "Extract".
"""

from __future__ import annotations

from typing import Any

import cv2
import numpy as np

from ..context import Context
from ._common import scalar, to_bgr
from ._registry import ApplyResult, op


_CONVERSIONS: dict[str, int | None] = {
    "HSV": cv2.COLOR_BGR2HSV,
    "HLS": cv2.COLOR_BGR2HLS,
    "Lab": cv2.COLOR_BGR2LAB,
    "YCrCb": cv2.COLOR_BGR2YCrCb,
    "XYZ": cv2.COLOR_BGR2XYZ,
    "BGR": None,  # identity
}


def _channel_to_bgr(ch: np.ndarray) -> np.ndarray:
    """Replicate a single 2-D channel into a 3-channel grayscale image."""
    return cv2.cvtColor(ch, cv2.COLOR_GRAY2BGR)


def _pseudo_color(ch: np.ndarray) -> np.ndarray:
    return cv2.applyColorMap(ch, cv2.COLORMAP_VIRIDIS)


@op("cspace")
def op_cspace(image: np.ndarray, params: dict[str, Any], _ctx: Context) -> ApplyResult:
    bgr = to_bgr(image)
    space = str(params.get("space", "HSV"))
    code = _CONVERSIONS.get(space, cv2.COLOR_BGR2HSV)

    converted = bgr if code is None else cv2.cvtColor(bgr, code)

    view = str(params.get("view", "Encoded"))
    if view == "Channel0":
        out = _channel_to_bgr(converted[..., 0])
    elif view == "Channel1":
        out = _channel_to_bgr(converted[..., 1])
    elif view == "Channel2":
        out = _channel_to_bgr(converted[..., 2])
    elif view == "Pseudo":
        out = _pseudo_color(converted[..., 0])
    else:
        out = converted

    rows = [
        scalar("Space", space),
        scalar("View", view),
        scalar("Shape", f"{converted.shape[1]}×{converted.shape[0]}×{converted.shape[2]}"),
        scalar("Ch0 mean", round(float(converted[..., 0].mean()), 1)),
        scalar("Ch1 mean", round(float(converted[..., 1].mean()), 1)),
        scalar("Ch2 mean", round(float(converted[..., 2].mean()), 1)),
    ]
    return ApplyResult(image=out, rows=rows)
