"""List attached video-capture devices.

Invocation::

    python -m simplevision.runtime.list_cameras

Always prints a JSON array of ``{"index": int, "name": str}`` objects to
stdout and exits 0. On platforms where enumeration isn't implemented (or
the optional ``pygrabber`` dep is missing) the array is empty and the
caller is expected to fall back to a numeric device picker.

Enumeration is only implemented on Windows via DirectShow (pygrabber).
On Linux/macOS OpenCV alone can't return device names, so we deliberately
return ``[]`` rather than fabricating "Camera 0 / 1 / 2" labels.
"""

from __future__ import annotations

import json
import sys
import traceback


def _enumerate_windows() -> list[dict[str, object]]:
    from pygrabber.dshow_graph import FilterGraph  # type: ignore[import-not-found]

    names = FilterGraph().get_input_devices()
    return [{"index": i, "name": name} for i, name in enumerate(names)]


def main() -> int:
    try:
        if sys.platform == "win32":
            cameras = _enumerate_windows()
        else:
            cameras = []
    except Exception:  # noqa: BLE001 — never fail the caller for this
        # Emit empty list on any enumeration error so the UI can fall
        # back gracefully; surface the trace on stderr for diagnostics.
        sys.stderr.write(traceback.format_exc())
        sys.stderr.flush()
        cameras = []

    sys.stdout.write(json.dumps(cameras))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
