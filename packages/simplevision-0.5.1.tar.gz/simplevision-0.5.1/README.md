# simplevision

Run [SimpleVision](https://github.com/AutoElecAB/SimpleVision) computer-vision
pipelines from Python.

SimpleVision is a learning tool for students: you build a vision pipeline
visually in the desktop editor (threshold, blob detect, color match,
geometric match, OCR, …), tick the measurements you care about, and the
editor saves the pipeline as a single `.simplevision` JSON file. This
library is the companion that runs that pipeline from Python so you can
plug the measurements into your own code.

## Install

```bash
pip install simplevision
```

OCR is optional (it pulls in RapidOCR + ONNX Runtime, ~300 MB):

```bash
pip install "simplevision[ocr]"
```

## Use it

Open your pipeline in the SimpleVision editor, tick the measurements you
want in **Output Control**, and save. Then in Python:

```python
from simplevision import Pipeline

p = Pipeline.load("my_pipeline.simplevision")
p.run()

# Each name below is one you typed in the editor's Output Control panel.
if p.outputs.MatchPercentage[0] > 0.85:
    print("Match found at", p.outputs.Centroids[0])
```

Pass your own frame to `p.run()` to process many images through the same
pipeline:

```python
import cv2
for path in ["frame_001.png", "frame_002.png", "frame_003.png"]:
    p.run(path)
    print(path, "->", p.outputs.Count)
```

`print(p.outputs)` shows everything readably — handy while you're getting
oriented.

## What's in the package

- `simplevision.Pipeline`, `simplevision.Outputs`, `simplevision.Point` —
  the student-facing API.
- `simplevision.runtime` — the execution engine. You normally don't
  import this directly; the desktop app uses it as a sidecar and
  `Pipeline.run()` drives it under the hood. The runtime is documented
  in [`docs/pipeline-spec.md`](https://github.com/AutoElecAB/SimpleVision/blob/main/docs/pipeline-spec.md)
  if you want to build pipelines without the editor.

## License

Apache-2.0. See `LICENSE` and `NOTICE`.
