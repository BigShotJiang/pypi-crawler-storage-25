def say():
    print("I love python,hallo world!")
