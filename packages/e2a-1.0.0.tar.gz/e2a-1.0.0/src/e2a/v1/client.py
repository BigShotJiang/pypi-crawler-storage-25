"""High-level sync client for the e2a v1 API.

Wraps :class:`E2AApi` with ergonomic methods that return parsed
:class:`InboundEmail` objects and handle agent email resolution.
"""

from __future__ import annotations

import base64
import json
import os
from typing import Any, Optional

from e2a.v1.api import E2AApi
from e2a.v1.generated import (
    MessageDetail,
    RegisterAgentRequest,
    RegisterDomainRequest,
    ReplyToMessageRequest,
    SendEmailRequest,
)
from e2a.v1.generated import internal_agent
from e2a.v1.handler import (
    Attachment,
    InboundEmail,
    MessageList,
    MessageSummary,
    SendResult,
    build_inbound_email,
)


def _serialize_attachments(
    attachments: list[Attachment] | None,
) -> list[internal_agent.Attachment] | None:
    """Convert high-level Attachment objects to generated wire format."""
    if not attachments:
        return None
    return [
        internal_agent.Attachment(
            filename=att.filename,
            content_type=att.content_type,
            data=base64.b64encode(att.data).decode(),
        )
        for att in attachments
    ]


class E2AClient:
    """High-level sync client for the e2a v1 API.

    Wraps the raw :class:`E2AApi` with convenience methods that return
    parsed :class:`InboundEmail` objects.

    Args:
        api_key: Your API key.
            Falls back to the ``E2A_API_KEY`` environment variable.
        agent_email: Default agent email address.
            Falls back to ``E2A_AGENT_EMAIL``.
        base_url: e2a API base URL. Defaults to ``https://e2a.dev``.
        timeout: Request timeout in seconds. Defaults to 30.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_email: Optional[str] = None,
        base_url: str = "https://e2a.dev",
        timeout: float = 30,
    ) -> None:
        resolved_key = api_key or os.environ.get("E2A_API_KEY", "")
        self.agent_email = agent_email or os.environ.get("E2A_AGENT_EMAIL", "")
        self.api = E2AApi(api_key=resolved_key, base_url=base_url, timeout=timeout)

    def _require_agent_email(self, agent_email: Optional[str] = None) -> str:
        email = agent_email or self.agent_email
        if not email:
            raise ValueError(
                "agent_email is required. Pass it to E2AClient(), set E2A_AGENT_EMAIL, "
                "or use InboundEmail.reply() which auto-resolves it from the payload."
            )
        return email

    # ── Parsing ───────────────────────────────────────────────────────

    def parse(
        self,
        body: bytes | str | dict[str, Any] | MessageDetail,
        headers: dict[str, str] | None = None,
    ) -> InboundEmail:
        """Parse a webhook payload or MessageDetail into an InboundEmail.

        Accepts bytes, JSON string, dict, or a generated MessageDetail.
        """
        if isinstance(body, MessageDetail):
            data = body.model_dump(by_alias=True)
        elif isinstance(body, dict):
            data = body
        elif isinstance(body, (bytes, str)):
            data = json.loads(body)
        else:
            raise TypeError(f"Unsupported body type: {type(body)}")

        return build_inbound_email(data, self)

    # ── Messages ──────────────────────────────────────────────────────

    def get_message(
        self,
        message_id: str,
        agent_email: Optional[str] = None,
    ) -> InboundEmail:
        """Fetch a single message and return a parsed InboundEmail.

        Marks the message as read.
        """
        email = self._require_agent_email(agent_email)
        detail = self.api.get_message(email, message_id)
        data = detail.model_dump(by_alias=True)
        return build_inbound_email(data, self)

    def get_messages(
        self,
        status: str = "unread",
        page_size: int = 50,
        token: Optional[str] = None,
        agent_email: Optional[str] = None,
    ) -> MessageList:
        """Fetch message summaries with ergonomic field names."""
        email = self._require_agent_email(agent_email)
        resp = self.api.list_messages(email, status=status, page_size=page_size, token=token)
        messages = [
            MessageSummary(
                message_id=m.message_id or "",
                conversation_id=m.conversation_id,
                sender=m.from_ or "",
                recipient=m.to or "",
                subject=m.subject or "",
                status=m.status.value if m.status else "",
                created_at=m.created_at or "",
            )
            for m in (resp.messages or [])
        ]
        return MessageList(messages=messages, next_token=resp.next_token)

    # ── Reply / Send ──────────────────────────────────────────────────

    def reply(
        self,
        message_id: str,
        body: str,
        html_body: Optional[str] = None,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
        agent_email: Optional[str] = None,
    ) -> SendResult:
        """Reply to an inbound email."""
        email = self._require_agent_email(agent_email)
        req = ReplyToMessageRequest(
            body=body,
            html_body=html_body,
            conversation_id=conversation_id,
            attachments=_serialize_attachments(attachments),
        )
        resp = self.api.reply_to_message(email, message_id, req)
        return SendResult(
            status=resp.status or "",
            message_id=resp.message_id or "",
            method=resp.method or "",
        )

    def send(
        self,
        to: str,
        subject: str,
        body: str,
        conversation_id: Optional[str] = None,
        attachments: Optional[list[Attachment]] = None,
        agent_email: Optional[str] = None,
    ) -> SendResult:
        """Send a new email."""
        email = self._require_agent_email(agent_email)
        req = SendEmailRequest(
            to=to,
            subject=subject,
            body=body,
            from_=email,
            conversation_id=conversation_id,
            attachments=_serialize_attachments(attachments),
        )
        resp = self.api.send_email(req)
        return SendResult(
            status=resp.status or "",
            message_id=resp.message_id or "",
            method=resp.method or "",
        )

    # ── Agent CRUD ────────────────────────────────────────────────────

    def list_agents(self):
        return self.api.list_agents()

    def register_agent(
        self,
        slug: Optional[str] = None,
        *,
        email: Optional[str] = None,
        webhook_url: Optional[str] = None,
        agent_mode: Optional[str] = None,
    ):
        return self.api.register_agent(
            RegisterAgentRequest(
                slug=slug, email=email, webhook_url=webhook_url, agent_mode=agent_mode,
            )
        )

    def get_agent(self, email: str):
        return self.api.get_agent(email)

    def delete_agent(self, email: str):
        return self.api.delete_agent(email)

    # ── Domain CRUD ───────────────────────────────────────────────────

    def list_domains(self):
        return self.api.list_domains()

    def register_domain(self, domain: str):
        return self.api.register_domain(RegisterDomainRequest(domain=domain))

    def verify_domain(self, domain: str):
        return self.api.verify_domain(domain)

    def delete_domain(self, domain: str):
        return self.api.delete_domain(domain)

    # ── Lifecycle ─────────────────────────────────────────────────────

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self.api.close()

    def __enter__(self) -> E2AClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
