"""General utility functions."""
