"""Qt GUI related functions."""
