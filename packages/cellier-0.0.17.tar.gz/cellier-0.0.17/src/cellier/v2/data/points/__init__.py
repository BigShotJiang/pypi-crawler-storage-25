"""Data infrastructure for points."""
