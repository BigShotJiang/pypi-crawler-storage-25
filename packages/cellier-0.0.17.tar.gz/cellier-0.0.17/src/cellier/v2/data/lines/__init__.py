"""Data infrastructure for lines."""
