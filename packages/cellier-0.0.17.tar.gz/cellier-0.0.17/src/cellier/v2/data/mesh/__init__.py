"""Data infrastructure for meshes."""
