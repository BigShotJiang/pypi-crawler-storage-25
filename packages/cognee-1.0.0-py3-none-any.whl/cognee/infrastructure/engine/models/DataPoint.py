import logging
from uuid import UUID, NAMESPACE_OID, uuid4, uuid5
from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from typing_extensions import NotRequired, TypedDict

from cognee.infrastructure.engine.models.FieldAnnotations import _Embeddable, _Dedup
from cognee.infrastructure.engine.utils.generate_node_id import generate_node_id

logger = logging.getLogger(__name__)


# Define metadata type
class MetaData(TypedDict):
    """
    Represent a metadata structure with type and index fields.
    """

    type: str
    index_fields: list[str]
    identity_fields: NotRequired[list[str]]


# Updated DataPoint model with versioning and new fields
class DataPoint(BaseModel):
    """
    Model representing a data point with versioning and metadata support.

    Public methods include:
    - get_embeddable_data
    - get_embeddable_properties
    - get_embeddable_property_names
    - update_version
    - to_json
    - from_json
    - to_dict
    - from_dict
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    id: UUID = Field(default_factory=uuid4)
    created_at: int = Field(
        default_factory=lambda: int(datetime.now(timezone.utc).timestamp() * 1000)
    )
    updated_at: int = Field(
        default_factory=lambda: int(datetime.now(timezone.utc).timestamp() * 1000)
    )
    ontology_valid: bool = False
    version: int = 1  # Default version
    topological_rank: Optional[int] = 0
    metadata: Optional[MetaData] = {"index_fields": []}
    type: str = Field(default_factory=lambda: DataPoint.__name__)
    belongs_to_set: Optional[List["DataPoint"] | List[str]] = None
    source_pipeline: Optional[str] = None
    source_task: Optional[str] = None
    source_node_set: Optional[str] = None
    source_user: Optional[str] = None
    source_content_hash: Optional[str] = None
    feedback_weight: float = 0.5
    importance_weight: Optional[float] = 0.5

    def __init__(self, **data: Any) -> None:
        explicit_id = "id" in data
        super().__init__(**data)
        object.__setattr__(self, "type", self.__class__.__name__)
        if not explicit_id:
            identity_fields = self.__class__._get_identity_fields()
            if identity_fields:
                identity_id = self.__class__._generate_identity_id(
                    identity_fields, self.model_dump(), self.__class__.__name__
                )
                if identity_id is not None:
                    object.__setattr__(self, "id", identity_id)

    @classmethod
    def _get_identity_fields(cls) -> Optional[list[str]]:
        """Get identity_fields from the class's metadata field default, if defined.

        Walks the MRO to detect if a parent class defined identity_fields that a
        subclass accidentally dropped when overriding metadata.
        """
        metadata_field = cls.model_fields.get("metadata")
        if metadata_field is not None and metadata_field.default is not None:
            identity = metadata_field.default.get("identity_fields")
            if identity is None:
                for parent in cls.__mro__[1:]:
                    parent_meta = getattr(parent, "model_fields", {}).get("metadata")
                    if parent_meta is not None and parent_meta.default is not None:
                        parent_identity = parent_meta.default.get("identity_fields")
                        if parent_identity is not None:
                            logger.warning(
                                "%s overrides metadata but drops identity_fields "
                                "defined in parent %s",
                                cls.__name__,
                                parent.__name__,
                            )
                            break
            return identity
        return None

    @classmethod
    def _generate_identity_id(
        cls, identity_fields: list[str], data: dict, class_name: str
    ) -> Optional[UUID]:
        """Generate a deterministic UUID5 from identity field values.

        Returns None if any identity field is missing from both data
        and Pydantic field defaults, causing fallback to the default UUID4.
        """
        parts = []
        for field_name in identity_fields:
            if field_name in data:
                value = data[field_name]
            else:
                # Check Pydantic field default
                field_info = cls.model_fields.get(field_name)
                if field_info is not None and field_info.default is not None:
                    value = field_info.default
                else:
                    return None
            if isinstance(value, str):
                value = value.lower().replace(" ", "_").replace("'", "")
            else:
                value = str(value)
            parts.append(value)
        joined = "|".join(parts)
        identity_string = f"{class_name}:{joined}"
        return uuid5(NAMESPACE_OID, identity_string)

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs):
        """Auto-derive metadata index_fields and identity_fields from Annotated markers.

        If a subclass uses Annotated[str, Embeddable()] or Annotated[str, Dedup()]
        on its fields, and does NOT explicitly set metadata, the metadata default
        is automatically populated from those annotations.
        """
        super().__pydantic_init_subclass__(**kwargs)

        # Only auto-derive if the subclass didn't explicitly declare metadata
        if "metadata" in cls.__annotations__:
            return

        embeddable_fields = []
        dedup_fields = []

        for field_name, field_info in cls.model_fields.items():
            if field_info.metadata:
                for meta in field_info.metadata:
                    if isinstance(meta, _Embeddable):
                        embeddable_fields.append(field_name)
                    if isinstance(meta, _Dedup):
                        dedup_fields.append(field_name)

        if embeddable_fields or dedup_fields:
            new_metadata = {"index_fields": embeddable_fields}
            if dedup_fields:
                new_metadata["identity_fields"] = dedup_fields
            cls.model_fields["metadata"].default = new_metadata

    @classmethod
    def get_embeddable_data(self, data_point: "DataPoint"):
        """
        Retrieve embeddable data from the data point object based on index fields.

        This method checks if there are defined index fields in the metadata and retrieves the
        value of the first indexed attribute. If the attribute is a string, it strips whitespace
        from it before returning.

        Parameters:
        -----------

            - data_point ('DataPoint'): The DataPoint instance from which to retrieve embeddable
              data.

        Returns:
        --------

            The value of the embeddable data, or None if not found.
        """
        if (
            data_point.metadata
            and len(data_point.metadata["index_fields"]) > 0
            and hasattr(data_point, data_point.metadata["index_fields"][0])
        ):
            attribute = getattr(data_point, data_point.metadata["index_fields"][0])

            if isinstance(attribute, str):
                return attribute.strip()
            return attribute

    @classmethod
    def get_embeddable_properties(self, data_point: "DataPoint"):
        """
        Retrieve a list of embeddable properties from the data point.

        This method returns a list of attribute values based on the index fields defined in the
        data point's metadata. If there are no index fields, it returns an empty list.

        Parameters:
        -----------

            - data_point ('DataPoint'): The DataPoint instance from which to retrieve embeddable
              properties.

        Returns:
        --------

            A list of embeddable property values, or an empty list if none exist.
        """
        if data_point.metadata and len(data_point.metadata["index_fields"]) > 0:
            return [
                getattr(data_point, field, None) for field in data_point.metadata["index_fields"]
            ]

        return []

    @classmethod
    def get_embeddable_property_names(self, data_point: "DataPoint"):
        """
        Retrieve the names of embeddable properties defined in the metadata.

        If no index fields are defined in the metadata, this method will return an empty list.

        Parameters:
        -----------

            - data_point ('DataPoint'): The DataPoint instance from which to retrieve embeddable
              property names.

        Returns:
        --------

            A list of property names corresponding to the index fields, or an empty list if none
            exist.
        """
        return data_point.metadata["index_fields"] or []

    def update_version(self):
        """
        Increment the version number of the data point and update the timestamp.

        This method will automatically modify the version attribute and refresh the updated_at
        timestamp to the current time.
        """
        self.version += 1
        self.updated_at = int(datetime.now(timezone.utc).timestamp() * 1000)

    # JSON Serialization
    def to_json(self) -> str:
        """
        Serialize the DataPoint instance to a JSON string format.

        This method uses the model's built-in serialization functionality to convert the
        instance into a JSON-compatible string.

        Returns:
        --------

            - str: The JSON string representation of the DataPoint instance.
        """
        return self.model_dump_json()

    @classmethod
    def from_json(self, json_str: str):
        """
        Deserialize a DataPoint instance from a JSON string.

        The method transforms the input JSON string back into a DataPoint instance using model
        validation.

        Parameters:
        -----------

            - json_str (str): The JSON string representation of a DataPoint instance to be
              deserialized.

        Returns:
        --------

            A new DataPoint instance created from the JSON data.
        """
        return self.model_validate_json(json_str)

    def to_dict(self, **kwargs) -> Dict[str, Any]:
        """
        Convert the DataPoint instance to a dictionary representation.

        This method uses the model's built-in functionality to serialize the instance attributes
        to a dictionary, which can optionally include additional arguments.

        Parameters:
        -----------

            - **kwargs: Additional keyword arguments for serialization options.

        Returns:
        --------

            - Dict[str, Any]: A dictionary representation of the DataPoint instance.
        """
        return self.model_dump(**kwargs)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DataPoint":
        """
        Instantiate a DataPoint from a dictionary of attribute values.

        The method validates the incoming dictionary data against the model's schema and
        constructs a new DataPoint instance accordingly.

        Parameters:
        -----------

            - data (Dict[str, Any]): A dictionary containing the attributes of a DataPoint
              instance.

        Returns:
        --------

            - 'DataPoint': A new DataPoint instance constructed from the provided dictionary
              data.
        """
        return cls.model_validate(data)
