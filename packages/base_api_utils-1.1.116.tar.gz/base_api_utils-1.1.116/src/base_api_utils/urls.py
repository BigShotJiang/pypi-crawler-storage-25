from django.urls import path

from .views import TasksResultAPIView

private_tasks_admin_patterns = ([
    path('', TasksResultAPIView.as_view({'get': 'list'}), name='tasks_result'),
    path('/<str:task_id>', TasksResultAPIView.as_view({'get': 'retrieve_async_task_status'}), name='retrieve_async_task_status'),
    path('/<str:task_id>/retry', TasksResultAPIView.as_view({'post': 'retry'}), name='retry'),
], 'private-tasks-admin-endpoints')