from drf_spectacular.extensions import OpenApiAuthenticationExtension
from oauthlib.openid.connect.core.grant_types import refresh_token

from .config import config

class OAuth2CustomSchemaBase(OpenApiAuthenticationExtension):
    name = config('OPEN_API_SECURITY_SCHEMA_NAME')

    def get_security_definition(self, auto_schema):
        unique_scopes = set()

        endpoints = config("OAUTH2.CLIENT.ENDPOINTS")

        for endpoint, methods in endpoints.items():
            for method, details in methods.items():
                scopes = details.get("scopes")
                if scopes:
                    unique_scopes.update(scopes.split())

        base_url = config("OAUTH2.IDP.BASE_URL").rstrip("/")
        token_endpoint = config("OAUTH2.IDP.TOKEN_ENDPOINT").lstrip("/")
        refresh_token_endpoint = config("OAUTH2.IDP.REFRESH_TOKEN_ENDPOINT").lstrip("/")

        return {
            "type": "oauth2",
            "flows": {
                'clientCredentials': {
                    "tokenUrl": f"{base_url}/{token_endpoint}",
                    'refreshUrl':  f"{base_url}/{refresh_token_endpoint}",
                    "scopes": {scope: "" for scope in sorted(unique_scopes)},
                },
            },
            "description": "OAuth2 client credentials authentication.",
        }
