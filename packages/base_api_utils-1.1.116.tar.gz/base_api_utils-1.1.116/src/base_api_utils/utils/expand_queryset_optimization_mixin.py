from typing import Any, Iterable, List, Set, Tuple

from rest_framework.response import Response


class ExpandQuerysetOptimizationMixin:
    # Auto-optimizes queryset from serializer.expand_mappings (recursive),
    # plus runs bulk hooks for computed relations."""

    def _parse_trees(self):
        from base_api_utils.serializers.v2.query_params import parse_request_trees

        return parse_request_trees(self.request)

    def _include_field(self, fields_tree: dict | None, attr: str) -> bool:
        if fields_tree is None:
            return True
        return attr in fields_tree

    def _collect_orm_recursive(
        self,
        serializer_cls: type,
        *,
        expand_tree: dict,
        fields_tree: dict | None,
        relations_tree: dict | None,
        prefix: str = "",
    ) -> Tuple[Set[str], Set[str], List[Tuple[str, dict, dict | None, dict | None]]]:
        from base_api_utils.serializers.v2.query_params import should_expand, subtree

        select_paths: Set[str] = set()
        prefetch_paths: Set[str] = set()
        bulk_hooks: List[Tuple[str, dict, dict | None, dict | None]] = []

        mappings = getattr(serializer_cls, "expand_mappings", {}) or {}
        for attr, spec in mappings.items():
            if not spec:
                continue

            orm = spec.get("orm") or {}
            verify = bool(spec.get("verify_relation", False))

            is_included = self._include_field(fields_tree, attr)
            is_expanded = should_expand(expand_tree, relations_tree, attr, verify)

            for sr in orm.get("select_related", []) or []:
                if is_expanded:
                    select_paths.add(f"{prefix}{sr}" if prefix else sr)

            for pr in orm.get("prefetch_related", []) or []:
                if is_included:
                    prefetch_paths.add(f"{prefix}{pr}" if prefix else pr)

            hook = orm.get("bulk_prefetch")
            if hook and is_expanded:
                bulk_hooks.append(
                    (
                        hook,
                        subtree(expand_tree, attr) or {},
                        subtree(fields_tree, attr),
                        subtree(relations_tree, attr),
                    )
                )

            # recurse only if expanded
            if is_expanded:
                child_cls = spec.get("serializer")
                if child_cls:
                    child_expand = subtree(expand_tree, attr) or {}
                    child_fields = subtree(fields_tree, attr)
                    child_relations = subtree(relations_tree, attr)

                    join_seg = spec.get("source") or attr
                    if orm.get("nested_prefix") is not None:
                        join_seg = orm.get("nested_prefix")

                    # If this relation is computed/bulk, we can't build ORM paths on base qs,
                    # but recursion still matters for hooks (they get subtrees).
                    if not orm.get("bulk_prefetch"):
                        child_prefix = (
                            f"{prefix}{join_seg}__" if prefix else f"{join_seg}__"
                        )
                        c_sel, c_pre, c_hooks = self._collect_orm_recursive(
                            child_cls,
                            expand_tree=child_expand,
                            fields_tree=child_fields,
                            relations_tree=child_relations,
                            prefix=child_prefix,
                        )
                        select_paths |= c_sel
                        prefetch_paths |= c_pre
                        bulk_hooks += c_hooks

        return select_paths, prefetch_paths, bulk_hooks

    def get_queryset(self):
        qs = super().get_queryset()
        expand_tree, fields_tree, relations_tree = self._parse_trees()
        serializer_cls = self.get_serializer_class()

        select_paths, prefetch_paths, _ = self._collect_orm_recursive(
            serializer_cls,
            expand_tree=expand_tree,
            fields_tree=fields_tree,
            relations_tree=relations_tree,
            prefix="",
        )

        if select_paths:
            qs = qs.select_related(*sorted(select_paths))
        if prefetch_paths:
            qs = qs.prefetch_related(*sorted(prefetch_paths))
        return qs

    def _run_bulk_hooks(self, objects: Iterable[Any]):
        expand_tree, fields_tree, relations_tree = self._parse_trees()
        serializer_cls = self.get_serializer_class()
        _, _, hooks = self._collect_orm_recursive(
            serializer_cls,
            expand_tree=expand_tree,
            fields_tree=fields_tree,
            relations_tree=relations_tree,
            prefix="",
        )
        for hook_name, ex_sub, fi_sub, rel_sub in hooks:
            fn = getattr(self, f"bulk_prefetch__{hook_name}", None)
            if fn:
                fn(objects, ex_sub, fi_sub, rel_sub)

    def list(self, request, *args, **kwargs):
        queryset = self.filter_queryset(self.get_queryset())
        page = self.paginate_queryset(queryset)
        items = page if page is not None else list(queryset)

        self._run_bulk_hooks(items)

        serializer = self.get_serializer(items, many=True)
        if page is not None:
            return self.get_paginated_response(serializer.data)
        return Response(serializer.data)