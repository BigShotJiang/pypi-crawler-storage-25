import hashlib
from django.core.cache import cache

DEBOUNCE_TTL = 30  # seconds


def debounce_task(key: str, ttl: int = DEBOUNCE_TTL) -> bool:
    """
    Returns True if the task should proceed (no recent duplicate),
    False if a duplicate was already scheduled within the TTL window.
    Uses Redis SET NX (atomic) to avoid race conditions.
    """
    cache_key = f"debounce:{hashlib.md5(key.encode()).hexdigest()}"
    return cache.add(cache_key, 1, timeout=ttl)