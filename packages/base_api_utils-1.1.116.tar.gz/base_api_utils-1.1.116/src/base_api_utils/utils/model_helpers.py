from rest_framework.exceptions import NotFound

def get_or_not_found(model, obj_id: int, name: str):
    """Helper to fetch object or raise NotFound."""
    obj = model.objects.filter(id=obj_id).first()
    if obj is None:
        raise NotFound(f'{name} {obj_id} not found.')
    return obj