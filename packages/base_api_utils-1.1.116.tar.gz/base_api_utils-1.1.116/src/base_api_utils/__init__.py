from .urls import private_tasks_admin_patterns  # noqa: F401
