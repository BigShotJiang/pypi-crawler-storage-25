from unittest.mock import patch, MagicMock

from django.core.management import call_command
from rest_framework.test import APITestCase
from django.urls import reverse
import json
from rest_framework import status


class TaskStatusEndpointsTest(APITestCase):
    def setUp(self):
        self.access_token = 'ACCESS_TOKEN'
        call_command('seed_data')

    def test_task_status_pending(self):
        task_id = 'test-task-pending'
        url = reverse('private-tasks-admin-endpoints:retrieve_async_task_status', kwargs={'task_id': task_id})

        mock_result = MagicMock()
        mock_result.status = 'PENDING'

        with patch('base_api_utils.views.tasks_result_view.AsyncResult', return_value=mock_result):
            response = self.client.get(f'{url}?access_token={self.access_token}')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        json_response = json.loads(response.content)
        self.assertEqual(json_response['task_id'], task_id)
        self.assertEqual(json_response['status'], 'PENDING')
        self.assertNotIn('result', json_response)
        self.assertNotIn('error', json_response)

    def test_task_status_started(self):
        task_id = 'test-task-started'
        url = reverse('private-tasks-admin-endpoints:retrieve_async_task_status', kwargs={'task_id': task_id})

        mock_result = MagicMock()
        mock_result.status = 'STARTED'

        with patch('base_api_utils.views.tasks_result_view.AsyncResult', return_value=mock_result):
            response = self.client.get(f'{url}?access_token={self.access_token}')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        json_response = json.loads(response.content)
        self.assertEqual(json_response['status'], 'STARTED')
        self.assertNotIn('result', json_response)
        self.assertNotIn('error', json_response)

    def test_task_status_success(self):
        task_id = 'test-task-success'
        url = reverse('private-tasks-admin-endpoints:retrieve_async_task_status', kwargs={'task_id': task_id})

        mock_result = MagicMock()
        mock_result.status = 'SUCCESS'
        mock_result.result = {'imported': [1667], 'errors': []}

        with patch('base_api_utils.views.tasks_result_view.AsyncResult', return_value=mock_result):
            response = self.client.get(f'{url}?access_token={self.access_token}')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        json_response = json.loads(response.content)
        self.assertEqual(json_response['task_id'], task_id)
        self.assertEqual(json_response['status'], 'SUCCESS')
        self.assertIn('result', json_response)
        self.assertEqual(json_response['result'], {'imported': [1667], 'errors': []})
        self.assertNotIn('error', json_response)

    def test_task_status_success_with_partial_errors(self):
        task_id = 'test-task-partial'
        url = reverse('private-tasks-admin-endpoints:retrieve_async_task_status', kwargs={'task_id': task_id})

        mock_result = MagicMock()
        mock_result.status = 'SUCCESS'
        mock_result.result = {
            'imported': [1667],
            'errors': [{'user_id': 9999, 'error': 'There is no sponsor user registered with the id 9999'}]
        }

        with patch('base_api_utils.views.tasks_result_view.AsyncResult', return_value=mock_result):
            response = self.client.get(f'{url}?access_token={self.access_token}')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        json_response = json.loads(response.content)
        self.assertEqual(json_response['status'], 'SUCCESS')
        self.assertEqual(len(json_response['result']['imported']), 1)
        self.assertEqual(len(json_response['result']['errors']), 1)
        self.assertEqual(json_response['result']['errors'][0]['user_id'], 9999)

    def test_task_status_failure(self):
        task_id = 'test-task-failure'
        url = reverse('private-tasks-admin-endpoints:retrieve_async_task_status', kwargs={'task_id': task_id})

        mock_result = MagicMock()
        mock_result.status = 'FAILURE'
        mock_result.result = Exception('Sponsor 999 not found')

        with patch('base_api_utils.views.tasks_result_view.AsyncResult', return_value=mock_result):
            response = self.client.get(f'{url}?access_token={self.access_token}')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        json_response = json.loads(response.content)
        self.assertEqual(json_response['task_id'], task_id)
        self.assertEqual(json_response['status'], 'FAILURE')
        self.assertIn('error', json_response)
        self.assertNotIn('result', json_response)
