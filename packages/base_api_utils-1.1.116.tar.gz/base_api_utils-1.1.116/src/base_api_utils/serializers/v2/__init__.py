from .abstract_serializer import AbstractSerializer
from .base_model_serializer import BaseModelSerializer

try:
    import base_api_utils.serializers.v2.spectacular  # noqa: F401
except ImportError:
    pass  # drf-spectacular not installed