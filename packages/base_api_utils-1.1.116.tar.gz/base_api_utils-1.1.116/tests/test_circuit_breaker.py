import importlib.util
import sys
from pathlib import Path
from unittest.mock import MagicMock
import time

import pybreaker
import pytest
import requests
from rest_framework.exceptions import NotFound, ValidationError


def _load_module(name, file_path):
    """Load a module directly from file path, bypassing package __init__.py."""
    spec = importlib.util.spec_from_file_location(name, file_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


_utils_dir = Path(__file__).resolve().parent.parent / "src" / "base_api_utils" / "utils"
_external_errors = _load_module(
    "base_api_utils.utils.external_errors", _utils_dir / "external_errors.py"
)
_circuit_breaker = _load_module(
    "base_api_utils.utils.circuit_breaker", _utils_dir / "circuit_breaker.py"
)

NamedCircuitBreaker = _circuit_breaker.NamedCircuitBreaker
call_with_breaker = _circuit_breaker.call_with_breaker
NamedCircuitBreakerError = _external_errors.NamedCircuitBreakerError


def _failing():
    raise RuntimeError("fail")


@pytest.mark.unit
class TestNamedCircuitBreaker:

    def _make_breaker(self, fail_max=2, reset_timeout=1):
        return NamedCircuitBreaker(
            name="test_service",
            fail_max=fail_max,
            reset_timeout=reset_timeout,
        )

    def test_closed_state_passes_calls_through(self):
        breaker = self._make_breaker()
        result = breaker.call(lambda: "ok")
        assert result == "ok"

    def test_opens_after_fail_max_failures(self):
        breaker = self._make_breaker(fail_max=2)

        # First failure: count=1 < fail_max, original exception propagates
        with pytest.raises(RuntimeError):
            breaker.call(_failing)

        # Second failure: count reaches fail_max, pybreaker raises CircuitBreakerError
        # which our wrapper converts to NamedCircuitBreakerError
        with pytest.raises(NamedCircuitBreakerError):
            breaker.call(_failing)

        # Subsequent calls while open also raise NamedCircuitBreakerError
        with pytest.raises(NamedCircuitBreakerError) as exc_info:
            breaker.call(lambda: "should not run")

        assert "test_service" in str(exc_info.value)

    def test_raises_named_error_with_service_name(self):
        breaker = self._make_breaker(fail_max=2)

        # First failure below threshold
        with pytest.raises(RuntimeError):
            breaker.call(_failing)

        # Second failure reaches threshold -> NamedCircuitBreakerError
        with pytest.raises(NamedCircuitBreakerError) as exc_info:
            breaker.call(_failing)

        assert exc_info.value.service_name == "test_service"

    def test_recovers_after_reset_timeout(self):
        """Core regression test: verifies open -> half-open -> closed transition.

        The bug was that NamedCircuitBreaker.call() checked state == 'open'
        before delegating to super().call(), bypassing pybreaker's timeout
        evaluation and making the breaker permanently stuck open.
        """
        breaker = self._make_breaker(fail_max=2, reset_timeout=1)

        # Trip the breaker (need fail_max failures)
        with pytest.raises(RuntimeError):
            breaker.call(_failing)
        with pytest.raises(NamedCircuitBreakerError):
            breaker.call(_failing)

        # Confirm it's open
        with pytest.raises(NamedCircuitBreakerError):
            breaker.call(lambda: "blocked")

        # Wait for reset_timeout to elapse
        time.sleep(1.1)

        # Should transition to half-open and allow a trial call through
        result = breaker.call(lambda: "recovered")
        assert result == "recovered"

        # Should be fully closed again
        assert breaker.current_state == "closed"

    def test_half_open_failure_reopens(self):
        breaker = self._make_breaker(fail_max=2, reset_timeout=1)

        # Trip the breaker
        with pytest.raises(RuntimeError):
            breaker.call(_failing)
        with pytest.raises(NamedCircuitBreakerError):
            breaker.call(_failing)

        # Wait for reset_timeout
        time.sleep(1.1)

        # Trial call in half-open fails -> back to open
        # pybreaker raises CircuitBreakerError on the threshold-reaching failure
        with pytest.raises(NamedCircuitBreakerError):
            breaker.call(_failing)

        with pytest.raises(NamedCircuitBreakerError):
            breaker.call(lambda: "blocked again")

    def test_4xx_errors_do_not_count_as_failures(self):
        breaker = self._make_breaker(fail_max=2)

        mock_response = MagicMock()
        mock_response.status_code = 404

        def raise_4xx():
            error = requests.exceptions.HTTPError(response=mock_response)
            raise error

        # 4xx errors should pass through without tripping the breaker
        for _ in range(5):
            with pytest.raises(requests.exceptions.HTTPError):
                breaker.call(raise_4xx)

        # Breaker should still be closed
        assert breaker.current_state == "closed"

    def test_drf_not_found_does_not_trip_breaker(self):
        """DRF NotFound (converted from HTTP 404 by invoke_with_retry) must not trip the breaker."""
        breaker = self._make_breaker(fail_max=2)

        def raise_not_found():
            raise NotFound("Resource not found")

        for _ in range(5):
            with pytest.raises(NotFound):
                breaker.call(raise_not_found)

        assert breaker.current_state == "closed"

    def test_drf_validation_error_does_not_trip_breaker(self):
        """DRF ValidationError (converted from HTTP 412 by invoke_with_retry) must not trip the breaker."""
        breaker = self._make_breaker(fail_max=2)

        def raise_validation_error():
            raise ValidationError("Precondition failed")

        for _ in range(5):
            with pytest.raises(ValidationError):
                breaker.call(raise_validation_error)

        assert breaker.current_state == "closed"

    def test_exclude_kwarg_not_passed_twice(self):
        """Passing exclude= to NamedCircuitBreaker should not cause TypeError."""
        custom_exclude = [lambda e: isinstance(e, ValueError)]
        breaker = NamedCircuitBreaker(
            name="test_service",
            fail_max=2,
            reset_timeout=1,
            exclude=custom_exclude,
        )

        # Custom exclusion should work alongside built-in 4xx exclusion
        def raise_value_error():
            raise ValueError("excluded")

        for _ in range(5):
            with pytest.raises(ValueError):
                breaker.call(raise_value_error)

        assert breaker.current_state == "closed"


@pytest.mark.unit
class TestCallWithBreaker:

    def test_passes_call_through(self):
        breaker = pybreaker.CircuitBreaker(fail_max=2, reset_timeout=30)
        result = call_with_breaker(breaker, lambda: 42)
        assert result == 42

    def test_raises_on_open_breaker(self):
        breaker = pybreaker.CircuitBreaker(fail_max=2, reset_timeout=30)

        # First failure below threshold
        with pytest.raises(RuntimeError):
            call_with_breaker(breaker, _failing)

        # Second failure reaches threshold -> CircuitBreakerError
        with pytest.raises(pybreaker.CircuitBreakerError):
            call_with_breaker(breaker, _failing)

        # Subsequent calls while open
        with pytest.raises(pybreaker.CircuitBreakerError):
            call_with_breaker(breaker, lambda: "blocked")
