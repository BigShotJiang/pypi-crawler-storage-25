import importlib.util
import sys
from pathlib import Path

import pytest


def _load_module(name, file_path):
    """Load a module directly from file path, bypassing package __init__.py."""
    spec = importlib.util.spec_from_file_location(name, file_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load module {name} from {file_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


_utils_dir = Path(__file__).resolve().parent.parent / "src" / "base_api_utils" / "utils"


@pytest.mark.unit
class TestExpandQuerysetOptimizationMixinImports:
    """Regression: ExpandQuerysetOptimizationMixin must not trigger
    serializers/__init__.py at module load time, because that chain
    reaches django_celery_results.models.TaskResult (a Django model
    that requires the app registry to be ready).
    """

    def test_mixin_module_loads_without_triggering_serializers_init(self):
        """Loading the mixin module should NOT execute serializers/__init__.py."""
        # Clear any cached state
        mod_name = "base_api_utils.utils.expand_queryset_optimization_mixin"
        for key in list(sys.modules):
            if key.startswith("base_api_utils.serializers"):
                del sys.modules[key]
        if mod_name in sys.modules:
            del sys.modules[mod_name]

        module = _load_module(mod_name, _utils_dir / "expand_queryset_optimization_mixin.py")

        # Module should load successfully and define the mixin class
        assert hasattr(module, "ExpandQuerysetOptimizationMixin")

        # serializers/__init__.py should NOT have been executed during load
        assert "base_api_utils.serializers" not in sys.modules
        assert "base_api_utils.serializers.task_result_serializer" not in sys.modules

    def test_mixin_has_no_module_level_query_params_import(self):
        """The query_params import should be deferred to method level."""
        mod_name = "base_api_utils.utils.expand_queryset_optimization_mixin"
        if mod_name in sys.modules:
            del sys.modules[mod_name]

        module = _load_module(mod_name, _utils_dir / "expand_queryset_optimization_mixin.py")

        # query_params should NOT be loaded at module level
        assert "base_api_utils.serializers.v2.query_params" not in sys.modules
