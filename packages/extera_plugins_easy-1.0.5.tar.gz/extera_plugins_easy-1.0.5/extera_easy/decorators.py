import functools
from typing import Callable


def command(name: str, description: str = "", priority: int = 0):
    """
    Декоратор для команд в исходящих сообщениях.
    НЕ оборачивает функцию — просто добавляет метаданные.
    """
    def decorator(func):
        func._extera_command = {
            'name': name,
            'description': description,
            'priority': priority,
        }
        return func
    return decorator


def on_send_message(priority: int = 0, filter=None):
    """
    Декоратор для перехвата исходящих сообщений.
    """
    def decorator(func):
        func._extera_hook = {
            'type': 'send_message',
            'priority': priority,
            'filter': filter,
        }
        return func
    return decorator


def on_message(priority: int = 0, filter=None):
    """
    Декоратор для входящих сообщений (через NotificationCenter).
    """
    def decorator(func):
        func._extera_hook = {
            'type': 'message',
            'priority': priority,
            'filter': filter,
        }
        return func
    return decorator