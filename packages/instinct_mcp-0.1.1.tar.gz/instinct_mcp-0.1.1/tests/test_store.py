"""Tests for instinct.store."""
from __future__ import annotations

import os
import shutil
import tempfile

from instinct.store import InstinctStore, project_fingerprint


def _make_store():
    d = tempfile.mkdtemp()
    db = os.path.join(d, "test.db")
    return InstinctStore(db_path=db), d


def test_observe_new():
    store, d = _make_store()
    try:
        entry = store.observe("seq:a->b", category="sequence", source="test")
        assert entry["pattern"] == "seq:a->b"
        assert entry["confidence"] == 1
        assert entry["promoted"] == 0
        assert entry["level"] == "raw"
        assert entry["category"] == "sequence"
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_observe_increments():
    store, d = _make_store()
    try:
        store.observe("seq:x->y")
        store.observe("seq:x->y")
        store.observe("seq:x->y")
        entry = store.get("seq:x->y")
        assert entry["confidence"] == 3
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_observe_preserves_source():
    store, d = _make_store()
    try:
        store.observe("pat:a", source="claude")
        store.observe("pat:a")  # no source
        entry = store.get("pat:a")
        assert entry["source"] == "claude"
        assert entry["confidence"] == 2
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_get_missing():
    store, d = _make_store()
    try:
        assert store.get("nope") is None
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_delete():
    store, d = _make_store()
    try:
        store.observe("pat:del")
        assert store.delete("pat:del")
        assert store.get("pat:del") is None
        assert not store.delete("pat:del")
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_list_min_confidence():
    store, d = _make_store()
    try:
        store.observe("pat:low")  # 1
        for _ in range(4):
            store.observe("pat:high")  # 5
        entries = store.list(min_confidence=3)
        assert len(entries) == 1
        assert entries[0]["pattern"] == "pat:high"
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_list_by_category():
    store, d = _make_store()
    try:
        store.observe("a", category="sequence")
        store.observe("b", category="preference")
        entries = store.list(category="preference")
        assert len(entries) == 1
        assert entries[0]["pattern"] == "b"
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_list_by_project():
    store, d = _make_store()
    try:
        store.observe("a", project="proj1")
        store.observe("b", project="proj2")
        entries = store.list(project="proj1")
        assert len(entries) == 1
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_suggest_empty():
    store, d = _make_store()
    try:
        store.observe("pat:low")
        assert store.suggest() == []
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_suggest_returns_mature():
    store, d = _make_store()
    try:
        for _ in range(5):
            store.observe("pat:hot")
        suggestions = store.suggest()
        assert len(suggestions) == 1
        assert suggestions[0]["confidence"] == 5
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_suggest_project_filter():
    store, d = _make_store()
    try:
        for _ in range(5):
            store.observe("pat:global", project="")
        for _ in range(5):
            store.observe("pat:proj1", project="proj1")
        for _ in range(5):
            store.observe("pat:proj2", project="proj2")
        results = store.suggest(project="proj1")
        patterns = {r["pattern"] for r in results}
        assert "pat:global" in patterns
        assert "pat:proj1" in patterns
        assert "pat:proj2" not in patterns
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_consolidate():
    store, d = _make_store()
    try:
        for _ in range(5):
            store.observe("pat:mature")
        for _ in range(10):
            store.observe("pat:rule")
        store.observe("pat:raw")

        result = store.consolidate()
        assert result["promoted_to_mature"] >= 1
        assert result["promoted_to_rule"] >= 1
        assert result["total"] == 3

        assert store.get("pat:mature")["promoted"] == 1
        assert store.get("pat:mature")["level"] == "mature"
        assert store.get("pat:rule")["promoted"] == 2
        assert store.get("pat:rule")["level"] == "rule"
        assert store.get("pat:raw")["promoted"] == 0
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_decay():
    store, d = _make_store()
    try:
        store.observe("pat:old")
        # Manually backdate last_seen
        store._conn.execute(
            "UPDATE instincts SET last_seen = '2020-01-01T00:00:00+00:00' WHERE pattern = 'pat:old'"
        )
        store._conn.commit()
        count = store.decay(days_inactive=1)
        assert count == 1
        # confidence was 1, decayed by 1 = 0, so deleted
        assert store.get("pat:old") is None
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_stats():
    store, d = _make_store()
    try:
        for _ in range(10):
            store.observe("pat:rule")
        for _ in range(5):
            store.observe("pat:mature")
        store.observe("pat:raw")
        store.consolidate()

        s = store.stats()
        assert s["total"] == 3
        assert s["raw"] == 1
        assert s["mature"] == 1
        assert s["rules"] == 1
        assert s["max_confidence"] == 10
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_export_rules():
    store, d = _make_store()
    try:
        for _ in range(10):
            store.observe("pat:rule")
        store.observe("pat:raw")
        store.consolidate()

        rules = store.export_rules()
        assert len(rules) == 1
        assert rules[0]["pattern"] == "pat:rule"
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_search():
    store, d = _make_store()
    try:
        store.observe("seq:lint->fix")
        store.observe("pref:style=black")
        results = store.search("lint")
        assert len(results) == 1
        assert results[0]["pattern"] == "seq:lint->fix"
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)


def test_project_fingerprint():
    fp = project_fingerprint("/some/path")
    assert len(fp) == 12
    # Same path = same fingerprint
    assert project_fingerprint("/some/path") == fp
    # Different path = different fingerprint
    assert project_fingerprint("/other/path") != fp


def test_level_field():
    store, d = _make_store()
    try:
        entry = store.observe("pat:x")
        assert entry["level"] == "raw"
        for _ in range(4):
            store.observe("pat:x")
        store.consolidate()
        entry = store.get("pat:x")
        assert entry["level"] == "mature"
    finally:
        store.close()
        shutil.rmtree(d, ignore_errors=True)
