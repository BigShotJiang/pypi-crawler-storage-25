"""Tests for instinct.cli."""
from __future__ import annotations

import os
import shutil
import tempfile
from unittest.mock import patch

from instinct.cli import main
from instinct.store import InstinctStore


def _temp_db():
    d = tempfile.mkdtemp()
    db = os.path.join(d, "test.db")
    return db, d


def _patch_store(db):
    return patch("instinct.cli.InstinctStore", lambda: InstinctStore(db))


def test_help():
    assert main([]) == 0


def test_observe(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            assert main(["observe", "seq:a->b"]) == 0
            out = capsys.readouterr().out
            assert "OBSERVED" in out
            assert "seq:a->b" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_observe_json(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            assert main(["observe", "seq:x->y", "--json"]) == 0
            out = capsys.readouterr().out
            assert '"pattern"' in out
            assert "seq:x->y" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_get(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            main(["observe", "pat:a"])
            capsys.readouterr()
            assert main(["get", "pat:a"]) == 0
            out = capsys.readouterr().out
            assert "pat:a" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_get_not_found(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            assert main(["get", "nope"]) == 1
            out = capsys.readouterr().out
            assert "NOT FOUND" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_list(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            main(["observe", "a"])
            main(["observe", "b"])
            capsys.readouterr()
            assert main(["list"]) == 0
            out = capsys.readouterr().out
            assert "2 instincts" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_suggest_empty(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            assert main(["suggest"]) == 0
            out = capsys.readouterr().out
            assert "No mature" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_consolidate(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            assert main(["consolidate"]) == 0
            out = capsys.readouterr().out
            assert "Promoted" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_stats(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            main(["observe", "a"])
            capsys.readouterr()
            assert main(["stats"]) == 0
            out = capsys.readouterr().out
            assert "Total:" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_decay(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            assert main(["decay"]) == 0
            out = capsys.readouterr().out
            assert "Decayed" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_delete(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            main(["observe", "pat:del"])
            capsys.readouterr()
            assert main(["delete", "pat:del"]) == 0
            out = capsys.readouterr().out
            assert "DELETED" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_export_rules(capsys):
    db, d = _temp_db()
    try:
        with _patch_store(db):
            assert main(["export-rules"]) == 0
            out = capsys.readouterr().out
            assert "[]" in out
    finally:
        shutil.rmtree(d, ignore_errors=True)


def test_fingerprint(capsys):
    assert main(["fingerprint"]) == 0
