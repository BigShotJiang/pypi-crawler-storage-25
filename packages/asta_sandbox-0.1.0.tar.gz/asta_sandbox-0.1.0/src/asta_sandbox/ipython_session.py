"""IPython-backed execution helpers with optional subprocess isolation.

Ported from asta-autodiscovery/packages/code_execution with minor additions
(run_cell_with_options for per-call option overrides).
"""

import base64
import traceback
from dataclasses import dataclass
from multiprocessing import get_context
from typing import Any

from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output


@dataclass(frozen=True)
class ExecutionConfig:
    """Configuration for controlling how an IPython session executes cells."""

    use_subprocess: bool = False
    timeout_s: float | None = None
    matplotlib_backend: str | None = "module://matplotlib_inline.backend_inline"


def _normalize_value(value: Any) -> Any:
    # Ensure outputs are JSON-safe for downstream serialization.
    if isinstance(value, bytes):
        return base64.b64encode(value).decode("ascii")
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    if isinstance(value, (list, tuple)):
        return [_normalize_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): _normalize_value(item) for key, item in value.items()}
    return repr(value)



def _format_error(exc: BaseException | None) -> dict[str, str] | None:
    if exc is None:
        return None
    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
    }


def run_cell_with_shell(
    shell: InteractiveShell,
    code_str: str,
) -> dict[str, Any]:
    """Execute code in an existing IPython shell and return captured outputs.

    Public so InProcessExecutor can call it directly on its persistent shell.
    """
    with capture_output() as captured:
        result = shell.run_cell(code_str)

    error = result.error_before_exec or result.error_in_exec
    outputs: dict[str, Any] = {
        "stdout": captured.stdout,
        "stderr": captured.stderr,
        "rich_outputs": [],
        "success": result.success,
        "error": _format_error(error),
    }

    for display_obj in captured.outputs:
        outputs["rich_outputs"].append({k: _normalize_value(v) for k, v in display_obj.data.items()})

    return outputs


def _configure_matplotlib_backend(backend: str | None) -> None:
    if not backend:
        return
    try:
        import matplotlib
        import matplotlib_inline.backend_inline as backend_inline
    except Exception:
        return

    try:
        current = matplotlib.get_backend()
    except Exception:
        current = None

    if current == backend:
        return

    try:
        matplotlib.use(backend, force=True)
        if "matplotlib_inline.backend_inline" in backend:
            backend_inline.set_matplotlib_formats("png", "svg", "jpeg")
    except Exception:
        return


def configure_shell(
    shell: InteractiveShell,
    matplotlib_backend: str | None,
) -> None:
    """Configure matplotlib on an IPython shell.

    Public so InProcessExecutor can call this when starting up.
    """
    _configure_matplotlib_backend(matplotlib_backend)


def ensure_pip_available() -> None:
    # Bootstrap pip so %pip magic can install packages on demand.
    try:
        import pip  # noqa: F401
        return
    except Exception:
        pass
    try:
        import ensurepip
    except Exception:
        return
    try:
        ensurepip.bootstrap()
    except Exception:
        return


def _run_cell_in_subprocess(
    code_str: str,
    matplotlib_backend: str | None,
    connection: Any,
) -> None:
    # Run in a child process so a hard timeout can be enforced without blocking.
    shell = InteractiveShell.instance()
    configure_shell(shell, matplotlib_backend)
    outputs = run_cell_with_shell(shell, code_str)
    connection.send(outputs)
    connection.close()


class IPythonSession:
    """Run code in an IPython shell with optional subprocess isolation.

    A single IPythonSession holds a reference to InteractiveShell.instance(),
    which is a process-level singleton. Multiple IPythonSession objects within
    the same process therefore share kernel state. If you need isolated state,
    use use_subprocess=True (which spawns a fresh process) or a separate
    process altogether.
    """

    def __init__(
        self,
        *,
        use_subprocess: bool = False,
        timeout_s: float | None = None,
        matplotlib_backend: str | None = ExecutionConfig.matplotlib_backend,
    ) -> None:
        ensure_pip_available()
        self._config = ExecutionConfig(
            use_subprocess=use_subprocess,
            timeout_s=timeout_s,
            matplotlib_backend=matplotlib_backend,
        )
        self.shell = InteractiveShell.instance()
        configure_shell(self.shell, self._config.matplotlib_backend)

    def run_cell(self, code_str: str) -> dict[str, Any]:
        """Run a code cell using this session's configuration."""
        return self.run_cell_with_options(
            code_str,
            use_subprocess=self._config.use_subprocess,
            timeout_s=self._config.timeout_s,
        )

    def run_cell_with_options(
        self,
        code_str: str,
        *,
        use_subprocess: bool | None = None,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Run a code cell with per-call option overrides.

        Overridden values take precedence over the session-level config.
        If use_subprocess is True, the cell runs in a fresh child process
        and does not inherit or modify the session's shell state.
        """
        effective_subprocess = use_subprocess if use_subprocess is not None else self._config.use_subprocess
        effective_timeout = timeout_s if timeout_s is not None else self._config.timeout_s

        if effective_timeout is not None and not effective_subprocess:
            raise ValueError("timeout_s requires use_subprocess=True to enforce a hard timeout")

        if not effective_subprocess:
            return run_cell_with_shell(self.shell, code_str)

        ctx = get_context("spawn")
        parent_conn, child_conn = ctx.Pipe(duplex=False)
        process = ctx.Process(
            target=_run_cell_in_subprocess,
            args=(code_str, self._config.matplotlib_backend, child_conn),
        )
        process.start()
        child_conn.close()
        process.join(timeout=effective_timeout)

        if process.is_alive():
            process.terminate()
            process.join()
            parent_conn.close()
            return {
                "stdout": "",
                "stderr": "",
                "rich_outputs": [],
                "success": False,
                "error": {
                    "type": "TimeoutError",
                    "message": f"Execution exceeded {effective_timeout} seconds",
                    "traceback": "",
                },
            }

        if parent_conn.poll():
            result = parent_conn.recv()
            parent_conn.close()
            return result

        parent_conn.close()
        return {
            "stdout": "",
            "stderr": "",
            "rich_outputs": [],
            "success": False,
            "error": {
                "type": "RuntimeError",
                "message": "Subprocess exited without returning a result",
                "traceback": "",
            },
        }
