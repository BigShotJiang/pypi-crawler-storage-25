"""Modal backend — stateless ephemeral sandboxes.

Creates a fresh Modal sandbox for every run_code() call and terminates
it immediately after. No state (variables, imports) survives between calls.

Suitable for single-shot pipelines and experiment runners where isolation
between executions is desirable.

Requires the `modal-ephemeral` optional dependency group:
    pip install asta-sandbox[modal-ephemeral]
"""

from __future__ import annotations

import json
import logging
from collections.abc import Iterable
from typing import Any, Mapping, Optional, Sequence

import modal

from ..executor import (
    CloudMount,
    ExecutionError,
    ExecutionResult,
    FileShare,
    RichOutput,
    RunOptions,
    SandboxBase,
)
from ..images import build_modal_ephemeral_image
from ..mounts import to_modal_cloud_bucket_mount

_log = logging.getLogger(__name__)

_DEFAULT_SANDBOX_TIMEOUT_S = 600

# Inline runner script embedded in the sandbox — avoids needing a deployed function.
# The asta_sandbox package must be available inside the image (via add_local_python_source).
_SANDBOX_RUNNER = """
import json
import sys
import traceback

from asta_sandbox.ipython_session import ExecutionConfig, IPythonSession


def _format_error(exc: BaseException) -> dict:
    return {
        "type": type(exc).__name__,
        "message": str(exc),
        "traceback": "".join(traceback.format_exception(type(exc), exc, exc.__traceback__)),
    }


def main() -> None:
    try:
        payload = json.load(sys.stdin)
        session = IPythonSession(
            use_subprocess=payload.get("use_subprocess", False),
            timeout_s=payload.get("timeout_s"),
            matplotlib_backend=payload.get("matplotlib_backend", ExecutionConfig.matplotlib_backend),
        )
        result = session.run_cell(payload["code_str"])
    except BaseException as exc:
        result = {
            "stdout": "",
            "stderr": "",
            "rich_outputs": [],
            "success": False,
            "error": _format_error(exc),
        }
    json.dump(result, sys.stdout)


if __name__ == "__main__":
    main()
"""


def _coerce_stream_output(output: Any) -> str:
    if output is None:
        return ""
    if isinstance(output, bytes):
        return output.decode("utf-8", errors="replace")
    return str(output)


def _ipython_dict_to_result(raw: dict, options: RunOptions) -> ExecutionResult:
    error: ExecutionError | None = None
    if raw.get("error"):
        err = raw["error"]
        tb = err.get("traceback", "")
        error = ExecutionError(
            etype=err.get("type"),
            evalue=err.get("message"),
            traceback=(tb,) if tb else (),
        )

    rich_outputs = tuple(
        RichOutput(output_type="display_data", data=output, metadata={})
        for output in raw.get("rich_outputs", [])
        if output
    )

    return ExecutionResult(
        stdout=raw.get("stdout", ""),
        stderr=raw.get("stderr", ""),
        success=raw.get("success", False),
        rich_outputs=rich_outputs,
        error=error,
        metadata={"title": options.title},
    )


class ModalEphemeralExecutor(SandboxBase):
    """Creates a fresh Modal sandbox for every run_code() call.

    Stateless: no variables, imports, or data persist between calls.
    Each call is fully isolated from every other call.

    The executor instance itself is long-lived and holds configuration
    (image, mounts, env). Construct it once and reuse it across many calls.

    Cloud mounts are fixed at sandbox creation time. All calls made through
    this executor see the same mounted buckets.

    Args:
        app_name: Modal app name. Looked up or created if missing.
        image: Modal image to use. Defaults to build_modal_ephemeral_image(),
            which includes ipython and the asta_sandbox package as a local source.
        cloud_mounts: Cloud buckets to mount in every sandbox. These are
            converted to modal.CloudBucketMount automatically.
        mount_path: Default mount path when cloud_mounts are specified without
            an explicit path (single-mount convenience).
        environment: Environment variables injected into every sandbox.
        sandbox_timeout_s: Maximum sandbox lifetime per call in seconds.
    """

    def __init__(
        self,
        *,
        app_name: str = "asta-sandbox",
        image: modal.Image | None = None,
        cloud_mounts: Sequence[CloudMount] | None = None,
        environment: Mapping[str, str] | None = None,
        sandbox_timeout_s: int = _DEFAULT_SANDBOX_TIMEOUT_S,
        file_shares: Sequence[FileShare] | None = None,
    ) -> None:
        super().__init__(file_shares=file_shares)
        self._app_name = app_name
        self._image = image or build_modal_ephemeral_image()
        self._cloud_mounts = list(cloud_mounts or [])
        self._environment = dict(environment or {})
        self._sandbox_timeout_s = sandbox_timeout_s
        self._app: modal.App | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._app = await modal.App.lookup.aio(self._app_name, create_if_missing=True)
        self._started = True

    async def shutdown(self) -> None:
        self._app = None

    # ── Core API ───────────────────────────────────────────────────────────────

    async def run_code(self, code: str, options: RunOptions | None = None) -> ExecutionResult:
        """Execute code in a fresh Modal sandbox.

        Each call creates a new sandbox, runs the code, terminates the sandbox,
        and returns the result. State does not persist between calls.
        """
        await self._ensure_started()
        opts = options or RunOptions()
        volumes = self._build_volumes()
        secret = modal.Secret.from_dict(self._environment) if self._environment else None
        secrets = [secret] if secret is not None else []

        app = self._require_app()
        sandbox = await modal.Sandbox.create.aio(
            app=app,
            image=self._image,
            volumes=volumes,
            secrets=secrets,
            timeout=self._sandbox_timeout_s,
        )

        try:
            payload = {
                "code_str": code,
                "use_subprocess": opts.use_subprocess,
                "timeout_s": opts.timeout_seconds,
                "matplotlib_backend": None,  # no matplotlib in ephemeral by default
            }
            process = await sandbox.exec.aio(
                "python",
                "-c",
                _SANDBOX_RUNNER,
                timeout=opts.timeout_seconds,
            )
            process.stdin.write(json.dumps(payload).encode("utf-8"))
            process.stdin.write_eof()
            await process.stdin.drain.aio()
            await process.wait.aio()

            stdout = _coerce_stream_output(await process.stdout.read.aio())
            stderr = _coerce_stream_output(await process.stderr.read.aio())
        finally:
            await sandbox.terminate.aio()

        try:
            raw = json.loads(stdout) if stdout else {}
        except json.JSONDecodeError:
            raw = {
                "stdout": "",
                "stderr": stderr or "",
                "rich_outputs": [],
                "success": False,
                "error": {
                    "type": "RuntimeError",
                    "message": "Sandbox output was not valid JSON",
                    "traceback": stdout or "",
                },
            }

        if stderr:
            raw.setdefault("stderr", "")
            raw["stderr"] = f"{raw['stderr']}{stderr}"

        return _ipython_dict_to_result(raw, opts)

    async def install_packages(self, packages: Sequence[str], *, upgrade: bool = False, index_url: str | None = None) -> ExecutionResult:
        """Not supported for ephemeral sandboxes.

        Each run_code() call starts a fresh container, so there is no persistent
        environment to install into. Instead either:
          - include a ``%pip install ...`` magic at the top of your code string, or
          - bake packages into the image at construction time:
              ModalEphemeralExecutor(image=build_modal_ephemeral_image(extra_packages=[...]))
        """
        raise NotImplementedError(
            "ModalEphemeralExecutor does not support install_packages(): each call runs in a "
            "fresh container. Include '%pip install ...' in your code string, or pass "
            "extra_packages to build_modal_ephemeral_image()."
        )

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _build_volumes(self) -> dict[str, modal.CloudBucketMount]:
        volumes: dict[str, modal.CloudBucketMount] = {}
        for mount in self._cloud_mounts:
            volumes[mount.mount_path] = to_modal_cloud_bucket_mount(mount)
        return volumes

    def _require_app(self) -> modal.App:
        if self._app is None:
            raise RuntimeError("ModalEphemeralExecutor: call start() first")
        return self._app
