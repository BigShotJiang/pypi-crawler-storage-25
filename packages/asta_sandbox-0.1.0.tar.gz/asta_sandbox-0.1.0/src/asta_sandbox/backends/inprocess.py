"""In-process IPython backend.

Runs code in a persistent IPython shell within the current process.
State (variables, imports) accumulates across run_code() calls.

Best for local development, testing, and multi-turn interactive workflows
where you want low overhead and don't need process-level isolation.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Sequence

from IPython.core.interactiveshell import InteractiveShell

from ..executor import (
    ExecutionError,
    ExecutionResult,
    FileShare,
    RichOutput,
    RunOptions,
    SandboxBase,
    SandboxNotStartedError,
)
from ..ipython_session import ExecutionConfig, ensure_pip_available, configure_shell, run_cell_with_shell

_log = logging.getLogger(__name__)


def _ipython_dict_to_result(raw: dict) -> ExecutionResult:
    """Convert an IPython session output dict to an ExecutionResult."""
    error: ExecutionError | None = None
    if raw.get("error"):
        err = raw["error"]
        tb = err.get("traceback", "")
        error = ExecutionError(
            etype=err.get("type"),
            evalue=err.get("message"),
            traceback=(tb,) if tb else (),
        )

    rich_outputs = tuple(
        RichOutput(output_type="display_data", data=output, metadata={})
        for output in raw.get("rich_outputs", [])
        if output  # skip empty bundles
    )

    return ExecutionResult(
        stdout=raw.get("stdout", ""),
        stderr=raw.get("stderr", ""),
        success=raw.get("success", False),
        rich_outputs=rich_outputs,
        error=error,
    )


class InProcessExecutor(SandboxBase):
    """Runs code in a persistent in-process IPython shell.

    Stateful: variable and import state accumulates across run_code() calls.

    Note on process-level singleton: IPython's InteractiveShell.instance()
    returns the same shell for all callers in a process. If you run multiple
    InProcessExecutor instances concurrently, they will share shell state.
    This is usually fine in single-executor contexts; for isolation use a
    subprocess-based or remote backend.

    Args:
        matplotlib_backend: Matplotlib backend string. Defaults to inline.
        file_shares: Files to make available; only "upload" strategy is
            supported (files are copied to local_path / remote_path on start).
    """

    def __init__(
        self,
        *,
        matplotlib_backend: str | None = ExecutionConfig.matplotlib_backend,
        file_shares: Sequence[FileShare] | None = None,
    ) -> None:
        super().__init__(file_shares=file_shares)
        self._matplotlib_backend = matplotlib_backend
        self._shell: InteractiveShell | None = None

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    async def start(self) -> None:
        ensure_pip_available()
        self._shell = InteractiveShell.instance()
        configure_shell(self._shell, self._matplotlib_backend)
        _log.debug("InProcessExecutor: IPython shell ready")
        self._started = True

    async def shutdown(self) -> None:
        self._shell = None

    # ── Core API ───────────────────────────────────────────────────────────────

    async def run_code(self, code: str, options: RunOptions | None = None) -> ExecutionResult:
        """Execute code in the persistent shell.

        If options.use_subprocess is True, code runs in a fresh child process
        (hard timeout enforced, state is not preserved for that call).
        If False (default), code runs in-process; a timeout_seconds value
        is treated as a soft timeout — asyncio stops waiting, but the
        underlying thread continues running.
        """
        await self._ensure_started()
        opts = options or RunOptions()
        shell = self._require_shell()

        if opts.use_subprocess:
            # Hard-isolated subprocess; state is not preserved for this call.
            from ..ipython_session import IPythonSession
            def _run_sub() -> dict:
                session = IPythonSession(
                    use_subprocess=True,
                    timeout_s=opts.timeout_seconds,
                    matplotlib_backend=self._matplotlib_backend,
                )
                return session.run_cell(code)

            raw = await asyncio.to_thread(_run_sub)
        else:
            def _run_inline() -> dict:
                return run_cell_with_shell(shell, code)

            try:
                if opts.timeout_seconds:
                    raw = await asyncio.wait_for(
                        asyncio.to_thread(_run_inline),
                        timeout=opts.timeout_seconds,
                    )
                else:
                    raw = await asyncio.to_thread(_run_inline)
            except asyncio.TimeoutError:
                raw = {
                    "stdout": "",
                    "stderr": "",
                    "rich_outputs": [],
                    "success": False,
                    "error": {
                        "type": "TimeoutError",
                        "message": f"Execution timed out after {opts.timeout_seconds}s (soft limit — the thread may still be running)",
                        "traceback": "",
                    },
                }

        return _ipython_dict_to_result(raw)

    async def install_packages(self, packages: Sequence[str], *, upgrade: bool = False, index_url: str | None = None) -> ExecutionResult:
        parts = ["install"]
        if upgrade:
            parts.append("--upgrade")
        if index_url:
            parts += ["--index-url", index_url]
        parts.extend(packages)
        return await self.run_code(f"%pip {' '.join(parts)}")

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _require_shell(self) -> InteractiveShell:
        if self._shell is None:
            raise SandboxNotStartedError("InProcessExecutor: call start() first")
        return self._shell
