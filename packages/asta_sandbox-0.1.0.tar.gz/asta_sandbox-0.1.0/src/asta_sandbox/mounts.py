"""Cloud bucket mount helpers.

Converts the backend-agnostic CloudMount dataclass into the appropriate
Modal construct, keeping callers decoupled from modal-specific types.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import modal

from .executor import CloudMount


def to_modal_cloud_bucket_mount(mount: CloudMount) -> "modal.CloudBucketMount":
    """Convert a CloudMount to a modal.CloudBucketMount.

    Normalises the key_prefix to always end with a trailing slash, which
    Modal requires for directory-scoped mounts.

    For GCS buckets, set CloudMount.bucket_endpoint_url to the GCS
    S3-compatible endpoint: "https://storage.googleapis.com"
    """
    import modal

    key_prefix = mount.key_prefix if mount.key_prefix.endswith("/") else f"{mount.key_prefix}/"
    kwargs: dict = {
        "bucket_name": mount.bucket,
        "key_prefix": key_prefix,
        "read_only": mount.read_only,
    }
    if mount.bucket_endpoint_url is not None:
        kwargs["bucket_endpoint_url"] = mount.bucket_endpoint_url
    if mount.modal_secret is not None:
        kwargs["secret"] = mount.modal_secret
    if mount.oidc_auth_role_arn is not None:
        kwargs["oidc_auth_role_arn"] = mount.oidc_auth_role_arn

    return modal.CloudBucketMount(**kwargs)
