"""Default image builders for Modal and Docker backends.

Each builder returns a sensible default that can be extended for projects
with additional package requirements. Callers may also pass a fully custom
image to any backend constructor; these helpers are optional conveniences.
"""

from __future__ import annotations

import os
import sys
from collections.abc import Iterable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import modal

# Match the Python version of the calling process so the Modal image is always
# compatible with the client. Can be overridden per call if needed.
DEFAULT_PYTHON_VERSION = f"{sys.version_info.major}.{sys.version_info.minor}"

# Minimum Modal image builder version required per Python series.
# The '2023.12' default builder only supports up to Python 3.12.
# See: https://modal.com/docs/guide/custom-container#image-builder-versions
_PYTHON_TO_MIN_BUILDER: dict[tuple[int, int], str] = {
    (3, 13): "2024.10",
    (3, 14): "PREVIEW",
}


def _ensure_compatible_builder(python_version: str) -> None:
    """Set MODAL_IMAGE_BUILDER_VERSION if the configured builder won't support this Python.

    Only sets the env var if it hasn't been set externally already, so explicit
    user configuration always wins.
    """
    try:
        parts = python_version.split(".")
        ver = (int(parts[0]), int(parts[1]))
    except (IndexError, ValueError):
        return

    if os.environ.get("MODAL_IMAGE_BUILDER_VERSION"):
        return  # user explicitly configured it; don't override

    for threshold, required_builder in sorted(_PYTHON_TO_MIN_BUILDER.items(), reverse=True):
        if ver >= threshold:
            os.environ["MODAL_IMAGE_BUILDER_VERSION"] = required_builder
            return

# Packages baked into the kernel-gateway image (Docker + Modal stateful backends).
_KERNEL_GATEWAY_PACKAGES = [
    "jupyter_kernel_gateway",
    "ipykernel",
    "ipython>=9.8.0",
    "matplotlib",
    "matplotlib-inline",
]

# Packages baked into the ephemeral image (Modal stateless backend).
# Must include ipython; the asta_sandbox package itself is added as a local source.
_EPHEMERAL_PACKAGES = [
    "ipython>=9.8.0",
]

#: Default Docker image tag for the kernel-gateway backend.
#: Build it once with build_docker_kernel_image(); or use the Dockerfile in
#: the sandbox package's dockerfiles/ directory.
DEFAULT_DOCKER_IMAGE = "asta-sandbox-kernel-gateway:latest"


def build_modal_kernel_image(
    extra_packages: Iterable[str] | None = None,
    *,
    python_version: str = DEFAULT_PYTHON_VERSION,
) -> "modal.Image":
    """Build a Modal image with Jupyter Kernel Gateway for stateful execution.

    Used by ModalKernelExecutor. The image starts a kernel gateway process
    that stays alive for the duration of the sandbox.

    Args:
        extra_packages: Additional pip packages to install.
        python_version: Python version for the base image.

    Returns:
        A Modal image suitable for ModalKernelExecutor.
    """
    import modal

    _ensure_compatible_builder(python_version)
    packages = list(_KERNEL_GATEWAY_PACKAGES)
    if extra_packages:
        packages.extend(extra_packages)
    return modal.Image.debian_slim(python_version=python_version).pip_install(*packages)


def build_modal_ephemeral_image(
    extra_packages: Iterable[str] | None = None,
    *,
    python_version: str = DEFAULT_PYTHON_VERSION,
) -> "modal.Image":
    """Build a Modal image for ephemeral IPython-based execution.

    Used by ModalEphemeralExecutor. The asta_sandbox package is embedded as a
    local Python source so the ephemeral sandbox can import IPythonSession.

    Args:
        extra_packages: Additional packages to install alongside ipython.
        python_version: Python version for the base image.

    Returns:
        A Modal image suitable for ModalEphemeralExecutor.
    """
    import modal

    _ensure_compatible_builder(python_version)
    packages = list(_EPHEMERAL_PACKAGES)
    if extra_packages:
        packages.extend(extra_packages)
    return (
        modal.Image.debian_slim(python_version=python_version)
        .uv_pip_install(*packages)
        .add_local_python_source("asta_sandbox")
    )
