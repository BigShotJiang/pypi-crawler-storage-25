"""Core types, Protocol, and abstract base class for sandbox executors."""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence, runtime_checkable


# ── Result types ─────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class RichOutput:
    """A single rich display output (MIME bundle) from code execution."""

    output_type: str
    data: Mapping[str, Any]
    metadata: Mapping[str, Any] = field(default_factory=dict)
    execution_count: int | None = None


@dataclass(frozen=True)
class ExecutionError:
    """Details about an error raised during code execution."""

    etype: str | None
    evalue: str | None
    traceback: tuple[str, ...] = ()


@dataclass(frozen=True)
class ExecutionResult:
    """Complete output of a single code execution call."""

    stdout: str
    stderr: str
    success: bool
    rich_outputs: tuple[RichOutput, ...] = ()
    error: ExecutionError | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)


# ── Per-call options ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class RunOptions:
    """Options that may vary per run_code() call.

    Not all options are respected by every backend:
    - use_subprocess: InProcessExecutor and ModalEphemeralExecutor only.
      For Docker and ModalKernelExecutor, code already runs inside a remote process.
    - timeout_seconds: InProcessExecutor enforces a soft timeout (via asyncio);
      ModalEphemeralExecutor enforces a hard timeout via subprocess kill.
    - environment: Additional env vars injected for this call. Docker and Modal
      kernel backends do not support per-call env injection after start().
    """

    timeout_seconds: float | None = None
    use_subprocess: bool = False
    title: str = "cell"


# ── File sharing ──────────────────────────────────────────────────────────────────


class ShareStrategy:
    """String constants for FileShare.strategy."""

    MOUNT = "mount"    # bake into image (Modal) or bind-mount (Docker)
    UPLOAD = "upload"  # copy into a running sandbox after start
    VOLUME = "volume"  # attach a writable Modal Volume
    CLOUD = "cloud"    # mount a cloud bucket (S3 / GCS)


@dataclass
class FileShare:
    """Describes a path that should be accessible inside the sandbox.

    Interpretation is backend-specific:
    - "mount": Docker uses bind mounts; Modal bakes into the image via add_local_*.
    - "upload": Both backends copy files after the sandbox has started.
    - "volume": Modal only — attach a modal.Volume.
    - "cloud": Modal only — attach a CloudMount (S3/GCS bucket prefix).
      Use CloudMount instead of passing a raw modal.CloudBucketMount here;
      the backend will convert it.
    """

    remote_path: str
    strategy: str = ShareStrategy.MOUNT
    mode: str = "ro"  # "ro" or "rw"
    local_path: Path | None = None
    options: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.mode not in {"ro", "rw"}:
            raise ValueError("FileShare.mode must be 'ro' or 'rw'")
        if not self.remote_path.startswith("/"):
            raise ValueError("FileShare.remote_path must be an absolute path")


# ── Cloud mount ───────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class CloudMount:
    """Describes a cloud bucket prefix to mount inside the sandbox.

    Abstracts over S3 and GCS, and over OIDC vs secret-based auth, so callers
    don't need to construct backend-specific objects like modal.CloudBucketMount.

    The backend (ModalEphemeralExecutor, ModalKernelExecutor) converts this to
    the appropriate Modal construct at startup.

    For GCS, set bucket_endpoint_url to the GCS S3-compatible endpoint:
        "https://storage.googleapis.com"
    """

    bucket: str
    key_prefix: str
    mount_path: str
    read_only: bool = True
    bucket_endpoint_url: str | None = None    # GCS or S3-compatible endpoint
    oidc_auth_role_arn: str | None = None     # IAM role for OIDC auth
    modal_secret: Any | None = None           # modal.Secret for credential-based auth


# ── Errors ────────────────────────────────────────────────────────────────────────


class SandboxNotStartedError(RuntimeError):
    """Raised when a sandbox operation is attempted before start()."""


# ── Protocol ──────────────────────────────────────────────────────────────────────


@runtime_checkable
class SandboxExecutor(Protocol):
    """Structural type for all sandbox executor implementations.

    Use this as a type annotation when you want to accept any executor
    without depending on the concrete class or the abstract base.

    The two Modal backends and InProcessExecutor all satisfy this Protocol
    without inheriting from it; the Protocol check is structural (duck-typed).
    """

    async def start(self) -> None: ...
    async def shutdown(self) -> None: ...
    async def run_code(self, code: str, options: RunOptions | None = None) -> ExecutionResult: ...
    async def install_packages(self, packages: Sequence[str], *, upgrade: bool = False, index_url: str | None = None) -> ExecutionResult: ...
    async def upload_file(self, share: FileShare) -> None: ...


# ── Abstract base class ───────────────────────────────────────────────────────────


class SandboxBase(abc.ABC):
    """Convenience base class for sandbox executor implementations.

    Provides async context manager support (start/shutdown) and stores
    file shares passed at construction. Subclass this to get the boilerplate
    for free; the Protocol above is what callers should type against.
    """

    def __init__(
        self,
        *,
        file_shares: Sequence[FileShare] | None = None,
    ) -> None:
        self._file_shares: tuple[FileShare, ...] = tuple(file_shares or ())
        self._upload_shares: list[FileShare] = []
        self._started: bool = False

    @property
    def file_shares(self) -> tuple[FileShare, ...]:
        return self._file_shares

    async def __aenter__(self) -> SandboxBase:
        await self.start()
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        await self.shutdown()

    @abc.abstractmethod
    async def start(self) -> None:
        """Build or connect to the underlying runtime."""

    @abc.abstractmethod
    async def shutdown(self) -> None:
        """Cleanly tear down the runtime and release resources."""

    @abc.abstractmethod
    async def run_code(self, code: str, options: RunOptions | None = None) -> ExecutionResult:
        """Execute code and return structured outputs."""

    @abc.abstractmethod
    async def install_packages(self, packages: Sequence[str], *, upgrade: bool = False, index_url: str | None = None) -> ExecutionResult:
        """Install packages into the running sandbox."""

    async def _ensure_started(self) -> None:
        """Call start() automatically if not yet started.

        Backends call this at the top of run_code() so callers don't have to
        manage the start() / shutdown() lifecycle explicitly when not using the
        context manager.
        """
        if not self._started:
            await self.start()

    async def upload_file(self, share: FileShare) -> None:
        """Upload a local file or directory into a running sandbox."""
        if share.strategy != ShareStrategy.UPLOAD:
            return
        if not share.local_path:
            raise ValueError("upload share requires local_path")
        local_path = Path(share.local_path).resolve()
        if not local_path.exists():
            raise FileNotFoundError(f"Upload source {local_path} not found")
        await self._do_upload_file(local_path, Path(share.remote_path))

    async def _do_upload_file(self, local_path: Path, remote_path: Path) -> None:
        """Write a local path into the sandbox. Override in backends that support uploads."""
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support on-demand file uploads"
        )

    async def _upload_initial_files(self) -> None:
        """Upload all UPLOAD-strategy shares collected during _prepare_file_shares."""
        for share in self._upload_shares:
            local_path = Path(share.local_path).resolve()  # type: ignore[arg-type]
            if not local_path.exists():
                raise FileNotFoundError(f"Upload source {local_path} not found")
            await self._do_upload_file(local_path, Path(share.remote_path))
