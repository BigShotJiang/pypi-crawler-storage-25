"""Jupyter Kernel Gateway client for stateful remote execution.

Used by DockerExecutor and ModalKernelExecutor to communicate with a
Jupyter Kernel Gateway process running inside the sandbox.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from queue import Empty
from threading import Thread
from typing import Any, Mapping, Optional, Sequence

import websocket
from jupyter_core.utils import ensure_async
from jupyter_server.gateway.gateway_client import GatewayClient
from jupyter_server.gateway.managers import GatewayKernelClient, GatewayKernelManager
from jupyter_server.utils import url_path_join
from tornado.escape import url_escape

from .executor import ExecutionError, ExecutionResult, RichOutput, RunOptions

_log = logging.getLogger(__name__)

# GatewayKernelManager doesn't override _async_is_alive; it inherits
# KernelManager._async_is_alive which asserts self.provisioner is not None.
# Gateway kernels don't use the provisioner pattern, so patch it to return True.
# Liveness is validated separately via the HTTP gateway poll.
async def _gateway_is_alive(self: Any) -> bool:
    return True


if "_async_is_alive" not in GatewayKernelManager.__dict__:
    GatewayKernelManager._async_is_alive = _gateway_is_alive  # type: ignore[method-assign]


# Lock that serialises the brief window where we swap the GatewayClient
# singleton before making an HTTP lifecycle call (start_kernel / shutdown_kernel).
# All other communication (code execution) flows over per-instance WebSockets
# and never touches the singleton, so there is no lock overhead at run time.
_gateway_op_lock = asyncio.Lock()


def build_pip_install_code(
    packages: Sequence[str],
    *,
    upgrade: bool,
    index_url: Optional[str],
) -> str:
    args: list[str] = []
    if upgrade:
        args.append("--upgrade")
    if index_url:
        args.extend(["--index-url", index_url])
    args.extend(packages)
    # %pip is the IPython magic that routes to the kernel's own pip, ensuring
    # packages land in the same environment the kernel imports from.
    return f"%pip install {' '.join(args)}" if args else ""


# ── Per-instance GatewayClient subclasses ─────────────────────────────────────


class _InstanceGatewayKernelClient(GatewayKernelClient):
    """GatewayKernelClient that reads from a caller-supplied GatewayClient
    instance instead of the process-wide singleton.

    This allows multiple concurrent RemoteJupyterExecutor instances to
    maintain independent WebSocket connections to different gateway URLs.
    """

    def __init__(self, *, _gc: GatewayClient, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self._gc = _gc

    async def start_channels(
        self,
        shell: bool = True,
        iopub: bool = True,
        stdin: bool = True,
        hb: bool = True,
        control: bool = True,
    ) -> None:
        gc = self._gc
        ws_url = url_path_join(
            gc.ws_url or "",
            gc.kernels_endpoint,
            url_escape(self.kernel_id),
            "channels",
        )
        # Pass auth token as a query param; jupyter_kernel_gateway accepts
        # both the Authorization header and ?token=... on WebSocket upgrades.
        if gc.auth_token:
            ws_url = f"{ws_url}?token={gc.auth_token}"
        ssl_options = {
            "ca_certs": gc.ca_certs,
            "certfile": gc.client_cert,
            "keyfile": gc.client_key,
        }
        self.channel_socket = websocket.create_connection(
            ws_url,
            timeout=gc.KERNEL_LAUNCH_TIMEOUT,
            enable_multithread=True,
            sslopt=ssl_options,
        )
        # Call KernelClient.start_channels, skipping GatewayKernelClient's
        # override (which reads from the singleton) since we've replaced it above.
        await ensure_async(
            super(GatewayKernelClient, self).start_channels(
                shell=shell, iopub=iopub, stdin=stdin, hb=hb, control=control
            )
        )
        self.response_router = Thread(target=self._route_responses)
        self.response_router.start()


class _InstanceGatewayKernelManager(GatewayKernelManager):
    """GatewayKernelManager that uses a caller-supplied GatewayClient instance.

    ``kernels_url`` is derived from the supplied client's URL rather than the
    singleton. HTTP lifecycle calls (start_kernel / shutdown_kernel) are wrapped
    in a lock that temporarily installs our client as the process singleton so
    that ``gateway_request`` picks up the correct URL, auth token, and SSL
    settings.
    """

    def __init__(self, *, _gc: GatewayClient, **kwargs: Any) -> None:
        self._gc = _gc
        super().__init__(**kwargs)
        # super().__init__ set kernels_url from GatewayClient.instance(); overwrite it.
        self.kernels_url = url_path_join(_gc.url or "", _gc.kernels_endpoint)

    def client(self, **kwargs: Any) -> _InstanceGatewayKernelClient:
        kw: dict[str, Any] = {}
        kw.update(self.get_connection_info(session=True))
        kw.update({"connection_file": self.connection_file, "parent": self})
        kw["kernel_id"] = self.kernel_id
        kw.update(kwargs)
        return _InstanceGatewayKernelClient(_gc=self._gc, **kw)

    async def _with_our_gc(self, coro: Any) -> Any:
        """Acquire the global gateway lock, install our client as the singleton,
        await *coro*, then restore the previous singleton."""
        async with _gateway_op_lock:
            previous = GatewayClient._instance  # type: ignore[attr-defined]
            GatewayClient._instance = self._gc  # type: ignore[attr-defined]
            try:
                return await coro
            finally:
                GatewayClient._instance = previous  # type: ignore[attr-defined]

    async def start_kernel(self, **kwargs: Any) -> None:  # type: ignore[override]
        await self._with_our_gc(super().start_kernel(**kwargs))

    async def shutdown_kernel(self, now: bool = False, restart: bool = False) -> None:  # type: ignore[override]
        await self._with_our_gc(super().shutdown_kernel(now=now, restart=restart))


# ── Result types ──────────────────────────────────────────────────────────────


@dataclass(slots=True)
class _KernelResponse:
    stdout: str
    stderr: str
    rich_outputs: Sequence[RichOutput] = field(default_factory=tuple)
    error: Optional[Mapping[str, Any]] = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def succeeded(self) -> bool:
        return self.error is None and self.metadata.get("status") == "ok"


def kernel_response_to_result(response: _KernelResponse, options: RunOptions) -> ExecutionResult:
    """Convert a _KernelResponse to the package's canonical ExecutionResult."""
    error: ExecutionError | None = None
    if response.error:
        err = response.error
        raw_tb = err.get("traceback", [])
        error = ExecutionError(
            etype=err.get("ename"),
            evalue=err.get("evalue"),
            traceback=tuple(raw_tb) if isinstance(raw_tb, list) else (str(raw_tb),),
        )
    return ExecutionResult(
        stdout=response.stdout,
        stderr=response.stderr,
        success=response.succeeded,
        rich_outputs=tuple(response.rich_outputs),
        error=error,
        metadata=dict(response.metadata, title=options.title),
    )


# ── Executor ──────────────────────────────────────────────────────────────────


class RemoteJupyterExecutor:
    """Executes code on a remote Jupyter Kernel Gateway.

    Each instance creates its own GatewayClient, so multiple instances can
    connect to different gateway URLs concurrently within the same process.
    """

    def __init__(
        self,
        gateway_url: str,
        kernel_name: str = "python3",
        auth_token: str | None = None,
    ) -> None:
        # Create a fresh GatewayClient (not the singleton) so that multiple
        # RemoteJupyterExecutor instances can coexist without clobbering each
        # other's URL or auth token.
        self._gateway_client = GatewayClient()
        self._gateway_client.url = gateway_url
        if auth_token:
            self._gateway_client.auth_token = auth_token

        self._kernel_manager = _InstanceGatewayKernelManager(
            kernel_name=kernel_name,
            _gc=self._gateway_client,
        )
        self._client: _InstanceGatewayKernelClient | None = None

    async def start(self) -> None:
        await self._kernel_manager.start_kernel()
        # Retry with backoff: the gateway may need a moment after kernel creation
        # before the WebSocket endpoint is ready.
        for attempt in range(5):
            self._client = self._kernel_manager.client()
            try:
                await self._client.start_channels()
                await self._client.wait_for_ready()
                return
            except Exception as exc:
                if attempt == 4:
                    raise
                wait = 2 ** attempt
                _log.debug(
                    "WebSocket connection attempt %d failed (%s); retrying in %ds",
                    attempt + 1, exc, wait,
                )
                await asyncio.sleep(wait)

    async def execute(self, code: str, timeout: float | None = 10.0) -> _KernelResponse:
        if self._client is None:
            raise RuntimeError("RemoteJupyterExecutor not started")

        msg_id = self._client.execute(code)
        stdout_parts, stderr_parts, rich_outputs, error_payload, status = (
            await self._gather_iopub_output(msg_id, timeout)
        )
        status, execution_count, error_payload = await self._gather_shell_reply(
            msg_id, timeout, status, error_payload
        )
        metadata: dict[str, Any] = {"status": status}
        if execution_count is not None:
            metadata["execution_count"] = execution_count

        return _KernelResponse(
            stdout="".join(stdout_parts),
            stderr="".join(stderr_parts),
            rich_outputs=tuple(rich_outputs),
            error=error_payload,
            metadata=metadata,
        )

    async def _gather_iopub_output(
        self,
        msg_id: str,
        timeout: float | None,
    ) -> tuple[list[str], list[str], list[RichOutput], dict[str, Any] | None, str]:
        assert self._client is not None
        stdout_parts: list[str] = []
        stderr_parts: list[str] = []
        rich_outputs: list[RichOutput] = []
        error_payload: dict[str, Any] | None = None
        status = "ok"

        while True:
            try:
                msg = await self._client.get_iopub_msg(timeout=timeout)
            except Empty as exc:
                raise TimeoutError("Timed out waiting for kernel output") from exc

            if msg.get("parent_header", {}).get("msg_id") != msg_id:
                continue

            msg_type = msg.get("msg_type")
            content: Mapping[str, Any] = msg.get("content", {})

            if msg_type == "stream":
                text = content.get("text", "")
                if content.get("name") == "stderr":
                    stderr_parts.append(text)
                else:
                    stdout_parts.append(text)
            elif msg_type in {"display_data", "execute_result", "update_display_data"}:
                rich_outputs.append(
                    RichOutput(
                        output_type=msg_type,
                        data=content.get("data", {}),
                        metadata=content.get("metadata", {}),
                        execution_count=content.get("execution_count"),
                    )
                )
            elif msg_type == "error":
                status = "error"
                error_payload = {
                    "ename": content.get("ename"),
                    "evalue": content.get("evalue"),
                    "traceback": content.get("traceback", []),
                }
            elif msg_type == "status" and content.get("execution_state") == "idle":
                break
            elif msg_type == "clear_output":
                stdout_parts.clear()
                stderr_parts.clear()
                rich_outputs.clear()

        return stdout_parts, stderr_parts, rich_outputs, error_payload, status

    async def _gather_shell_reply(
        self,
        msg_id: str,
        timeout: float | None,
        status: str,
        error_payload: dict[str, Any] | None,
    ) -> tuple[str, int | None, dict[str, Any] | None]:
        assert self._client is not None
        while True:
            try:
                reply = await self._client.get_shell_msg(timeout=timeout)
            except Empty as exc:
                raise TimeoutError("Timed out waiting for kernel execute_reply") from exc

            if reply.get("parent_header", {}).get("msg_id") != msg_id:
                continue

            shell_reply = reply.get("content", {})
            break

        execution_count = shell_reply.get("execution_count")
        status = shell_reply.get("status", status)
        if status == "error" and error_payload is None:
            error_payload = {
                "ename": shell_reply.get("ename"),
                "evalue": shell_reply.get("evalue"),
                "traceback": shell_reply.get("traceback", []),
            }

        return status, execution_count, error_payload

    async def shutdown(self) -> None:
        if self._client:
            try:
                self._client.stop_channels()
            finally:
                await self._kernel_manager.shutdown_kernel()
