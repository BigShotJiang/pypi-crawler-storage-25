"""asta-sandbox — shared code execution sandbox abstractions for Asta projects.

Quick start::

    from asta_sandbox import InProcessExecutor, RunOptions

    async with InProcessExecutor() as executor:
        result = await executor.run_code("x = 1 + 1")
        result2 = await executor.run_code("print(x)")  # state is preserved
"""

# Core types — always available (no optional deps required)
from .executor import (
    CloudMount,
    ExecutionError,
    ExecutionResult,
    FileShare,
    RichOutput,
    RunOptions,
    SandboxBase,
    SandboxExecutor,
    SandboxNotStartedError,
    ShareStrategy,
)

# In-process backend — always available (only requires ipython)
from .backends.inprocess import InProcessExecutor

# Image builders (lazy modal import inside each function)
from .images import build_modal_ephemeral_image, build_modal_kernel_image

# Cloud mount helper (lazy modal import inside function)
from .mounts import to_modal_cloud_bucket_mount

__all__ = [
    # Types
    "CloudMount",
    "ExecutionError",
    "ExecutionResult",
    "FileShare",
    "RichOutput",
    "RunOptions",
    "SandboxBase",
    "SandboxExecutor",
    "SandboxNotStartedError",
    "ShareStrategy",
    # Backends
    "InProcessExecutor",
    # Image builders
    "build_modal_ephemeral_image",
    "build_modal_kernel_image",
    # Helpers
    "to_modal_cloud_bucket_mount",
]
