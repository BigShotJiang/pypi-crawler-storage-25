"""Legacy data utilities."""
