"""Singer related util functions."""

import ast
import datetime
import json
import os
import sys
from contextlib import redirect_stdout
from functools import partial, singledispatch

import pandas as pd
import polars as pl
import pytz
from gluestick.reader import Reader

_DATETIME_FMT = "%Y-%m-%dT%H:%M:%S.%fZ"


def _write_singer_message(msg: dict, fp=None) -> None:
    """Write a single Singer message as a newline-delimited JSON line.

    ``fp`` defaults to ``sys.stdout`` for backwards compatibility.  When an
    explicit file handle is provided we skip the per-message ``flush()`` and
    rely on the caller's ``with open(...) as fp`` to flush on close, which
    avoids a costly fsync per record on large exports.
    """
    if fp is None:
        sys.stdout.write(json.dumps(msg, default=str) + "\n")
        sys.stdout.flush()
    else:
        fp.write(json.dumps(msg, default=str) + "\n")


def write_schema(stream: str, schema: dict, key_properties, bookmark_properties=None, fp=None) -> None:
    """Write a Singer SCHEMA message.

    Pass ``fp`` to write to an explicit file handle instead of ``sys.stdout``.
    """
    if isinstance(key_properties, (str, bytes)):
        key_properties = [key_properties]
    if not isinstance(key_properties, list):
        raise ValueError("key_properties must be a string or list of strings")
    msg = {"type": "SCHEMA", "stream": stream, "schema": schema, "key_properties": key_properties}
    if bookmark_properties:
        msg["bookmark_properties"] = bookmark_properties
    _write_singer_message(msg, fp=fp)


def write_record(stream: str, record: dict, version=None, time_extracted=None, fp=None) -> None:
    """Write a Singer RECORD message.

    Pass ``fp`` to write to an explicit file handle instead of ``sys.stdout``.
    """
    msg = {"type": "RECORD", "stream": stream, "record": record}
    if version is not None:
        msg["version"] = version
    if time_extracted:
        if not time_extracted.tzinfo:
            raise ValueError("'time_extracted' must be either None or an aware datetime (with a time zone)")
        msg["time_extracted"] = time_extracted.astimezone(pytz.utc).strftime(_DATETIME_FMT)
    _write_singer_message(msg, fp=fp)


def write_state(value: dict, fp=None) -> None:
    """Write a Singer STATE message.

    Pass ``fp`` to write to an explicit file handle instead of ``sys.stdout``.
    """
    _write_singer_message({"type": "STATE", "value": value}, fp=fp)

def _serialize_value(x):
    """Serialize value for Singer: JSON for list/dict, string for non-null scalars, pass null through."""
    if isinstance(x, (list, dict)):
        return json.dumps(x, default=str)
    if not pd.isna(x):
        return str(x)
    return x


def _is_null_scalar(v):
    """Fast null check for a single scalar from ``DataFrame.to_dict``.

    Handles ``None``, float NaN, ``pd.NaT``, and ``pd.NA`` (the null sentinel
    for pandas nullable extension dtypes like Int64/boolean/string) without
    invoking ``pd.isna`` (which is slow per-cell and rejects collections).
    """
    if v is None:
        return True
    if isinstance(v, float) and v != v:
        return True
    if v is pd.NaT:
        return True
    if v is pd.NA:
        return True
    return False


def gen_singer_header(df: pd.DataFrame, allow_objects: bool, schema=None, catalog_schema=False, recursive_typing=True):
    """Generate singer headers based on pandas types.

    Parameters
    ----------
    df: pandas.DataFrame
        The dataframe to extranct the types from.
    allow_objects: bool
        If the function should proccess objects in the columns.

    Returns
    -------
    return: dict
        Dict of pandas.DataFrames. the keys of which are the entity names

    """
    header_map = dict(type=["object", "null"], properties={})

    type_mapping = {
        "float": {"type": ["number", "null"]},
        "int": {"type": ["integer", "null"]},
        "bool": {"type": ["boolean", "null"]},
        "str": {"type": ["string", "null"]},
        "date": {
            "format": "date-time",
            "type": ["string", "null"],
        },
        "array": {"type": ["array", "null"], "items": {"type": ["object", "string", "null"]}},
    }

    if schema and not catalog_schema:
        header_map = schema
        return df, header_map

    for col in df.columns:
        dtype = df[col].dtype.__str__().lower()

        if "date" in dtype:
            df[col] = df[col].dt.strftime("%Y-%m-%dT%H:%M:%S.%fZ")

        col_type = next((t for t in type_mapping.keys() if t in dtype), None)

        if col_type:
            header_map["properties"][col] = type_mapping[col_type]
        elif allow_objects:
            value = df[col].dropna()
            if value.empty:
                header_map["properties"][col] = type_mapping["str"]
                continue
            else:
                first_value = value.iloc[0]

            if isinstance(first_value, list):
                if recursive_typing:
                    new_input = {}
                    for row in value:
                        if len(row):
                            for arr_value in row:
                                if isinstance(arr_value, dict):
                                    temp_dict = {k:v for k, v in arr_value.items() if (k not in new_input.keys()) or isinstance(v, float)}
                                    new_input.update(temp_dict)
                                else:
                                    new_input = arr_value
                    _schema = dict(type=["array", "null"], items=to_singer_schema(new_input))
                    header_map["properties"][col] = _schema
                    if not new_input:
                        header_map["properties"][col] = {
                                "items": type_mapping["str"],
                                "type": ["array", "null"],
                            }
                else:
                    header_map["properties"][col] = type_mapping["array"]
            elif isinstance(first_value, dict):
                _schema = dict(type=["object", "null"], properties={})
                for k, v in first_value.items():
                    _schema["properties"][k] = to_singer_schema(v)
                header_map["properties"][col] = _schema
            else:
                header_map["properties"][col] = type_mapping["str"]
        else:
            header_map["properties"][col] = type_mapping["str"]
            df[col] = df[col].apply(_serialize_value)

    # update schema using types from catalog and keeping extra columns not defined in catalog
    # i.e. tenant, sync_date, etc
    if catalog_schema:
        header_map["properties"].update(schema["properties"])

    return df, header_map


def to_singer_schema(input):
    """Generate singer headers based on pandas types.

    Parameters
    ----------
    input:
        Object to extract the types from.

    Returns
    -------
    return: dict
        Dict of the singer mapped types.

    """
    if type(input) == dict:
        property = dict(type=["object", "null"], properties={})
        for k, v in input.items():
            property["properties"][k] = to_singer_schema(v)
        return property
    elif type(input) == list:
        if len(input):
            return dict(type=["array", "null"], items=to_singer_schema(input[0]))
        else:
            return {"items": {"type": ["string", "null"]}, "type": ["array", "null"]}
    elif type(input) == bool:
        return {"type": ["boolean", "null"]}
    elif type(input) == int:
        return {"type": ["integer", "null"]}
    elif type(input) == float:
        return {"type": ["number", "null"]}
    return {"type": ["string", "null"]}

def _resolve_refs(schema, defs):
    if isinstance(schema, dict):
        if '$ref' in schema:
            ref_path = schema['$ref'].split('/')
            ref_name = ref_path[-1]
            return _resolve_refs(defs[ref_name], defs)
        else:
            resolved_schema = {}
            for k,v in schema.items():
                if type(v) != list and type(v) != dict:
                    if k not in ['required', 'title']:
                        resolved_schema[k] = v
                else:
                    resolved_schema[k] = _resolve_refs(v, defs)
            return resolved_schema
    elif isinstance(schema, list):
        return [_resolve_refs(item, defs) for item in schema]
    else:
        return schema

def unwrap_json_schema(schema):
    def simplify_anyof(schema):
        if isinstance(schema, dict):
            if 'anyOf' in schema:
                types = [item.get('type') for item in schema['anyOf'] if 'type' in item]
                # if there's no types other than null, means it should support any type, return an empty dict to do it so
                if len(types) == 1 and types[0] == "null":
                    return {}

                # Handle cases where anyOf contains more than just type definitions
                # For example, when it includes properties or other nested structures
                combined_schema = {}
                for item in schema['anyOf']:
                    for key, value in item.items():
                        combined_schema[key] = simplify_anyof(value)
                combined_schema['type'] = types
                return combined_schema
            else:
                resolved_schema = {}
                for k,v in schema.items():
                    if type(v) != list and type(v) != dict:
                        if k not in ['required', 'title']:
                            resolved_schema[k] = v
                    else:
                        resolved_schema[k] = simplify_anyof(v)
                return resolved_schema
        elif isinstance(schema, list):
            return [simplify_anyof(item) for item in schema]
        else:
            return schema

    defs = schema.get('$defs', {})
    resolved_schema = _resolve_refs(schema, defs)
    simplified_schema = simplify_anyof(resolved_schema)
    simplified_schema.pop("$defs", None)
    return simplified_schema


def deep_convert_datetimes(value):
    """Transforms all nested datetimes in a list or dict to %Y-%m-%dT%H:%M:%S.%fZ.

    Notes
    -----
    This function transforms all datetimes to %Y-%m-%dT%H:%M:%S.%fZ

    Parameters
    ----------
    value: list, dict, datetime

    Returns
    -------
    return: list or dict with all datetime values transformed to %Y-%m-%dT%H:%M:%S.%fZ

    """
    if isinstance(value, list):
        return [deep_convert_datetimes(child) for child in value]
    elif isinstance(value, dict):
        return {k: deep_convert_datetimes(v) for k, v in value.items()}
    elif isinstance(value, datetime.datetime):
        return value.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    elif isinstance(value, datetime.date):
        return value.strftime("%Y-%m-%d")
    return value

def parse_objs(x):
    """Parse a stringified dict or list of dicts.

    Notes
    -----
    This function will parse a stringified dict or list of dicts

    Parameters
    ----------
    x: str
        stringified dict or list of dicts.

    Returns
    -------
    return: dict, list
        parsed dict or list of dicts.

    """
    # if it's not a string, we just return the input
    if type(x) != str:
        return x

    try:
        return ast.literal_eval(x)
    except:
        return json.loads(x)

def combine_anyof_types(field_types):
    types = set()
    for item in field_types:
        if 'type' in item:
            if isinstance(item['type'], list):
                types.update(set(item['type']))
            elif isinstance(item['type'], str):
                types.add(item['type'])
            else:
                raise ValueError(f"Invalid type: {item['type']}")
    return sorted(types)

def get_catalog_schema(stream):
    """Get a df schema using the catalog.

    Parameters
    ----------
    stream: str
        Stream name in catalog.

    """
    input = Reader()
    catalog = input.read_catalog()
    schema = next(
        (str["schema"] for str in catalog["streams"] if str["stream"] == stream), None
    )
    if not schema:
        raise Exception(f"No schema found in catalog for stream {stream}")
    else:
        # keep only relevant fields
        schema = {k: v for k, v in schema.items() if k in ["type", "properties"]}
        # need to ensure every array type has an items dict or we'll have issues
        for p in schema.get("properties", dict()):
            prop = schema["properties"][p]
            col_type = prop.get("type")
            if prop.get("anyOf"):
                # give priority to type with format   
                col_type = next((col_t for col_t in prop.get("anyOf", []) if "format" in col_t), None)
                # if no type with format, get combined values of all types
                if not col_type:
                    combined_types = combine_anyof_types(prop.get("anyOf", []))
                    col_type = {"type": combined_types}
                prop.update(col_type)
                prop.pop("anyOf", None)
                
            if prop.get("type") == "array" or "array" in prop.get("type") and prop.get("items") is None:
                prop["items"] = dict()
    return schema


def parse_df_cols(df, schema):
    """Parse all df list and dict columns according to schema.

    Parameters
    ----------
    stream: str
        Stream name in catalog.
    schema: dict
        Schema that will be used to export the data.

    """
    for col in df.columns:
        col_type = schema["properties"].get(col, {}).get("type", [])
        if (isinstance(col_type, list) and any(
            item in ["object", "array"]
            for item in col_type
        )) or col_type in ["object", "array"]:
            df[col] = df[col].apply(lambda x: parse_objs(x))
    return df


def remove_nulls_deep(data):
    """
    Recursively remove null or NaN values from a nested data structure.

    Parameters
    ----------
    data : dict, list, or pd.Series
        The data structure to clean. This can be:
        - A dictionary with nested elements
        - A list of nested elements
        - A pandas Series (such as a row from a DataFrame)

    """
    if isinstance(data, pd.Series):
        data = data.to_dict()  # Convert to plain dict for recursion

    if isinstance(data, dict):
        return {
            k: remove_nulls_deep(v)
            for k, v in data.items()
            if v is not None and not (isinstance(v, float) and pd.isna(v))
        }
    elif isinstance(data, list):
        return [
            remove_nulls_deep(item)
            for item in data
            if item is not None and not (isinstance(item, float) and pd.isna(item))
        ]
    else:
        return data


@singledispatch
def to_singer(
    df,
    stream,
    output_dir,
    keys=[],
    filename="data.singer",
    allow_objects=False,
    schema=None,
    unified_model=None,
    keep_null_fields=False,
    catalog_stream=None,
    recursive_typing=True
):
    raise NotImplementedError("to_singer is not implemented for this type")

@to_singer.register(pd.DataFrame)
def pandas_df_to_singer(
    df: pd.DataFrame,
    stream,
    output_dir,
    keys=[],
    filename="data.singer",
    allow_objects=False,
    schema=None,
    unified_model=None,
    keep_null_fields=False,
    catalog_stream=None,
    trim_nested_nulls=False,
    recursive_typing=True
):
    """Convert a pandas DataFrame into a singer file.

    Parameters
    ----------
    df: pd.DataFrame
        Object to extract the types from.
    stream: str
        Stream name to be used in the singer output file.
    output_dir: str
        Path to the output directory.
    keys: list
        The primary-keys to be used.
    filename: str
        The output file name.
    allow_objects: boolean
        Allow or not objects to the parsed, if false defaults types to str.
    keep_null_fields: boolean
        Flag to keep all null fields
    catalog_stream: str
        Name of the stream in the catalog to be used to generate the schema if USE_CATALOG_SCHEMA is set as true
        If this is not set it will use stream parameter to generate the catalog
    trim_nested_nulls: bool
        Flag to trims nulls from nested fields
    recursive_typing: boolean
        If true, the function will recursively convert arrays of objects to arrays of primitives.
        If false, the function will fuzzy list types when generating singer header.
    """
    catalog_schema = os.environ.get("USE_CATALOG_SCHEMA", "false").lower() == "true"
    include_all_unified_fields = os.environ.get("INCLUDE_ALL_UNIFIED_FIELDS", "false").lower() == "true" and unified_model is not None

    # drop columns with all null values except when we want to keep null fields
    if allow_objects and not (catalog_schema or include_all_unified_fields or keep_null_fields):
        df = df.dropna(how="all", axis=1)
    else:
        # df.dropna returns a new dataframe so df it's no longer pointing to the original dataframe, 
        # if dropna is not applied we need to copy it or gen_singer_header will cast the original dataframe datetime columns as strings
        df = df.copy()

    if catalog_schema or catalog_stream:
        # it'll allow_objects but keeping all columns
        allow_objects = True
        # get schema from catalog
        stream_name = catalog_stream or stream
        schema = get_catalog_schema(stream_name)
        # parse all fields that are typed as objects or lists
        df = parse_df_cols(df, schema)

    elif unified_model:
        schema = unwrap_json_schema(unified_model.model_json_schema())

    df, header_map = gen_singer_header(df, allow_objects, schema, catalog_schema, recursive_typing=recursive_typing)
    output = os.path.join(output_dir, filename)
    mode = "a" if os.path.isfile(output) else "w"

    keep_nulls = catalog_schema or include_all_unified_fields or keep_null_fields
    do_trim = trim_nested_nulls and not keep_nulls

    chunk_size = int(os.environ.get("SINGER_CHUNK_SIZE", "20000"))

    with open(output, mode) as f:
        write_schema(stream, header_map, keys, fp=f)

        n = len(df)
        for start in range(0, n, chunk_size):
            chunk = df.iloc[start : start + chunk_size]
            records = chunk.to_dict(orient="records")
            del chunk

            for rec in records:
                if not keep_nulls:
                    rec = {k: v for k, v in rec.items() if not _is_null_scalar(v)}
                else:
                    for k, v in list(rec.items()):
                        if _is_null_scalar(v):
                            rec[k] = None

                if do_trim:
                    rec = remove_nulls_deep(rec)

                rec = deep_convert_datetimes(rec)

                write_record(stream, rec, fp=f)
            f.flush() # flush after each chunk to avoid buffering
        write_state({}, fp=f)


def gen_singer_header_from_polars_schema(
    schema: pl.Schema
) -> dict:
    """
    Generate Singer headers from a Polars schema.

    Parameters
    ----------
    schema : pl.Schema
        Polars DataFrame schema.

    Returns
    -------
    dict
        Singer schema dictionary with non-primitives stringified.
    """
    primitive_mapping = {
        "Float64": {"type": ["number", "null"]},
        "Float32": {"type": ["number", "null"]},
        "Int64": {"type": ["integer", "null"]},
        "Int32": {"type": ["integer", "null"]},
        "Int16": {"type": ["integer", "null"]},
        "Int8": {"type": ["integer", "null"]},
        "UInt64": {"type": ["integer", "null"]},
        "UInt32": {"type": ["integer", "null"]},
        "UInt16": {"type": ["integer", "null"]},
        "UInt8": {"type": ["integer", "null"]},
        "Boolean": {"type": ["boolean", "null"]},
        "Utf8": {"type": ["string", "null"]},
        "Date": {"type": ["string", "null"], "format": "date"},
        "Datetime": {"type": ["string", "null"], "format": "date-time"},
        "Time": {"type": ["string", "null"], "format": "time"},
    }

    def map_dtype(dtype) -> dict:
        dtype_name = str(dtype)
        # Only primitive types keep their mapping
        if dtype_name.startswith("Struct("):
            return {"type": ["object", "null"]}
        
        if dtype_name.startswith("Datetime("):
            return {"type": ["string", "null"], "format": "date-time"}
        
        if dtype_name.startswith("List("):
            return {"type": ["array", "null"], "items": {"type": ["any", "null"]}}
        return primitive_mapping.get(dtype_name, {"type": ["string", "null"]})

    header_map = {
        "type": ["object", "null"],
        "properties": {col: map_dtype(dtype) for col, dtype in schema.items()}
    }

    return header_map


@to_singer.register(pl.DataFrame)
def polars_df_to_singer(
    df: pl.DataFrame,
    stream,
    output_dir,
    keys=[],
    filename="data.singer",
    allow_objects=False,
    schema=None,
    unified_model=None,
    keep_null_fields=False,
    catalog_stream=None,
    recursive_typing=True
):
    """Convert a polars DataFrame into a singer file.

    Parameters
    ----------
    df: pl.DataFrame
        Polars DataFrame to convert to singer.
    stream: str
        Stream name to be used in the singer output file.
    output_dir: str
        Path to the output directory.
    keys: list
        The primary-keys to be used.
    filename: str
        The output file name.
    allow_objects: boolean
        Allow or not objects to the parsed, if false defaults types to str.
    keep_null_fields: boolean
        Flag to keep all null fields
    catalog_stream: str
        Name of the stream in the catalog to be used to generate the schema if USE_CATALOG_SCHEMA is set as true
        If this is not set it will use stream parameter to generate the catalog
    recursive_typing: boolean
        If true, the function will recursively convert arrays of objects to arrays of primitives.
        If false, the function will fuzzy list types when generating singer header.
    """

    output = os.path.join(output_dir, filename)
    mode = "a" if os.path.isfile(output) else "w"

    header_map = gen_singer_header_from_polars_schema(df.schema)
 


    with open(output, mode) as f:
        with redirect_stdout(f):
            write_schema(stream, header_map, keys)
            for row in df.iter_rows(named=True):
                row = {k: v.strftime("%Y-%m-%dT%H:%M:%S.%fZ") if isinstance(v, datetime.datetime) else v for k, v in row.items()}
                write_record(stream, row)


            

@to_singer.register(pl.LazyFrame)
def polars_lf_to_singer(
    df: pl.LazyFrame,
    stream,
    output_dir,
    keys=[],
    filename="data.singer",
    allow_objects=False,
    schema=None,
    unified_model=None,
    keep_null_fields=False,
    catalog_stream=None,
    recursive_typing=True
):
    """Convert a polars Lazyframe into a singer file.

    Parameters
    ----------
    df: pd.DataFrame
        Object to extract the types from.
    stream: str
        Stream name to be used in the singer output file.
    output_dir: str
        Path to the output directory.
    keys: list
        The primary-keys to be used.
    filename: str
        The output file name.
    allow_objects: boolean
        Allow or not objects to the parsed, if false defaults types to str.
    keep_null_fields: boolean
        Flag to keep all null fields
    catalog_stream: str
        Name of the stream in the catalog to be used to generate the schema if USE_CATALOG_SCHEMA is set as true
        If this is not set it will use stream parameter to generate the catalog
    recursive_typing: boolean
        If true, the function will recursively convert arrays of objects to arrays of primitives.
        If false, the function will fuzzy list types when generating singer header.
    """

    sink_fn = partial(
        polars_df_to_singer,
        stream=stream,
        output_dir=output_dir,
        keys=keys,
        filename=filename,
        allow_objects=allow_objects,
        schema=schema,
        unified_model=unified_model,
        keep_null_fields=keep_null_fields,
        catalog_stream=catalog_stream,
        recursive_typing=recursive_typing,
    )
    df.sink_batches(sink_fn, chunk_size=1000)
