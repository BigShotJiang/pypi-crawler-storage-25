"""
Request/response types mirroring the OpenAPI 3.1 spec
(`docs/wop-spec/v1/api/openapi.yaml`) and JSON Schemas
(`docs/wop-spec/v1/schemas/`).

Hand-authored rather than codegen'd — see SDK README §rationale.
String-typed enums (Literal aliases) for fields whose spec'd values
may grow over time.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

# ── Type aliases ────────────────────────────────────────────────────────

RunStatus = Literal[
    "pending",
    "running",
    "paused",
    "waiting-approval",
    "waiting-input",
    "completed",
    "failed",
    "cancelled",
]
"""Run statuses per `RunSnapshot.status` in OpenAPI."""

StreamMode = Literal["values", "updates", "messages", "debug"]


# ── Capabilities ────────────────────────────────────────────────────────

@dataclass(frozen=True)
class CapabilitiesLimits:
    clarificationRounds: int
    schemaRounds: int
    envelopesPerTurn: int
    maxNodeExecutions: int | None = None


@dataclass(frozen=True)
class Capabilities:
    protocolVersion: str
    supportedEnvelopes: list[str]
    schemaVersions: dict[str, int]
    limits: CapabilitiesLimits
    extensions: dict[str, Any] | None = None
    # Network-handshake superset (all (future) per capabilities.md)
    implementation: dict[str, Any] | None = None
    engineVersion: int | None = None
    eventLogSchemaVersion: int | None = None
    supportedTransports: list[str] | None = None
    configurable: dict[str, Any] | None = None
    observability: dict[str, Any] | None = None
    minClientVersion: str | None = None


# ── RunSnapshot ─────────────────────────────────────────────────────────

@dataclass(frozen=True)
class RunSnapshotError:
    code: str
    message: str
    details: dict[str, Any] | None = None


@dataclass(frozen=True)
class RunSnapshot:
    runId: str
    workflowId: str
    status: RunStatus
    currentNodeId: str | None = None
    startedAt: str | None = None
    completedAt: str | None = None
    nodeStates: dict[str, Any] | None = None
    variables: dict[str, Any] | None = None
    channels: dict[str, Any] | None = None
    error: RunSnapshotError | None = None
    engineVersion: str | None = None
    eventLogSchemaVersion: int | None = None
    tags: list[str] | None = None
    metadata: dict[str, Any] | None = None
    configurable: dict[str, Any] | None = None


# ── RunOptions / configurable ───────────────────────────────────────────

@dataclass
class RunConfigurable:
    """Per-run parameter overlay carried in `RunOptions.configurable`.

    Reserved keys are typed; unknown keys are passed through verbatim
    via `extras`. See `docs/wop-spec/v1/run-options.md`.
    """

    recursionLimit: int | None = None
    model: str | None = None
    temperature: float | None = None
    maxTokens: int | None = None
    promptOverrides: dict[str, str] | None = None
    extras: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {}
        if self.recursionLimit is not None:
            out["recursionLimit"] = self.recursionLimit
        if self.model is not None:
            out["model"] = self.model
        if self.temperature is not None:
            out["temperature"] = self.temperature
        if self.maxTokens is not None:
            out["maxTokens"] = self.maxTokens
        if self.promptOverrides is not None:
            out["promptOverrides"] = dict(self.promptOverrides)
        out.update(self.extras)
        return out


# ── Run lifecycle requests/responses ────────────────────────────────────

@dataclass
class CreateRunRequest:
    workflowId: str
    inputs: dict[str, Any] | None = None
    tenantId: str | None = None
    scopeId: str | None = None
    callbackUrl: str | None = None
    configurable: RunConfigurable | dict[str, Any] | None = None
    tags: list[str] | None = None
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class CreateRunResponse:
    runId: str
    status: RunStatus
    eventsUrl: str
    statusUrl: str | None = None


@dataclass
class CancelRunRequest:
    reason: str | None = None


@dataclass(frozen=True)
class CancelRunResponse:
    runId: str
    status: Literal["cancelled", "cancelling"]


@dataclass
class ForkRunRequest:
    fromSeq: int
    mode: Literal["replay", "branch"]
    runOptionsOverlay: dict[str, Any] | None = None


@dataclass(frozen=True)
class ForkRunResponse:
    runId: str
    sourceRunId: str
    mode: Literal["replay", "branch"]
    status: RunStatus
    eventsUrl: str
    fromSeq: int | None = None


# ── HITL ────────────────────────────────────────────────────────────────

@dataclass
class ResolveInterruptRequest:
    resumeValue: Any


@dataclass(frozen=True)
class ResolveInterruptResponse:
    runId: str
    nodeId: str
    status: RunStatus


@dataclass(frozen=True)
class InterruptByTokenInspection:
    """Mirror of `suspend-request.schema.json` (InterruptPayload)."""

    kind: Literal["approval", "clarification", "external-event", "custom"]
    key: str
    data: Any
    resumeSchema: dict[str, Any] | None = None
    timeoutMs: int | None = None


# ── Events / poll ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class RunEventDoc:
    """Mirror of `run-event.schema.json` — top-level shape only.

    Per-event payload schemas live in `run-event-payloads.schema.json`;
    the SDK keeps `payload` as `Any` for forward-compat (consumers that
    want strict per-event validation should layer the payloads schema
    via Ajv/jsonschema themselves).
    """

    eventId: str
    runId: str
    type: str
    payload: Any
    timestamp: str
    sequence: int
    nodeId: str | None = None
    schemaVersion: int | None = None
    engineVersion: str | None = None
    causationId: str | None = None


@dataclass(frozen=True)
class PollEventsResponse:
    events: list[RunEventDoc]
    isComplete: bool


# ── Error envelope ──────────────────────────────────────────────────────

@dataclass(frozen=True)
class ErrorEnvelope:
    error: str
    message: str
    details: dict[str, Any] | None = None
