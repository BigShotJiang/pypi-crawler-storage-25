"""Streaming registrations for Qwen3 ASR.

The actual implementation lives in :mod:`fasr_asr_qwen3.models.asr` on a single
unified base class (:class:`_Qwen3ForASRBase`) that supports both batch and
streaming transcription on top of one shared vLLM engine. The thin subclasses
below only differ from their offline counterparts in which registry they join
and the outer shape of :meth:`get_config`, so selecting the streaming name and
the offline name at runtime yields the same weights either way.
"""

from __future__ import annotations

from typing import ClassVar

from fasr.config import registry
from fasr_asr_qwen3.models.asr import _Qwen3ForASRBase


@registry.stream_asr_models.register("stream_qwen3_0_6b")
class Qwen3_06BForStreamASR(_Qwen3ForASRBase):
    _config_outer_key: ClassVar[str] = "stream_asr_model"
    _config_registry: ClassVar[str] = "stream_asr_models"

    registry_name: ClassVar[str] = "stream_qwen3_0_6b"
    checkpoint: str = "Qwen/Qwen3-ASR-0.6B"


@registry.stream_asr_models.register("stream_qwen3_1_7b")
class Qwen3_17BForStreamASR(_Qwen3ForASRBase):
    _config_outer_key: ClassVar[str] = "stream_asr_model"
    _config_registry: ClassVar[str] = "stream_asr_models"

    registry_name: ClassVar[str] = "stream_qwen3_1_7b"
    checkpoint: str = "Qwen/Qwen3-ASR-1.7B"
