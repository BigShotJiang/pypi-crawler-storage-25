"""Tests for post management."""

import pytest
import json
from pathlib import Path

from postcraftin.profile import get_posts_drafts_dir, get_posts_published_dir, get_history_dir
from postcraftin import posts as posts_module
from postcraftin.posts import (
    create_post_with_frontmatter,
    update_post_status,
    update_post_topics,
    update_post_linkedin_url,
    list_profile_posts,
    get_post_by_filename,
    publish_post,
    get_post_history_stats,
    init_history,
)


class TestCreatePost:
    """Test post creation with frontmatter."""

    def test_create_post_saves_to_drafts(self, mock_profiles_dir, sample_profile):
        """create_post_with_frontmatter should save to drafts folder."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath = create_post_with_frontmatter(
            profile_name,
            "This is test post content",
            template="verlierer-gewinner",
            topics=["ai-ml", "tech"],
        )

        assert filepath.exists()
        assert "drafts" in str(filepath)

    def test_create_post_has_correct_frontmatter(self, mock_profiles_dir):
        """Created post should have correct frontmatter."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath = create_post_with_frontmatter(
            profile_name,
            "Test content",
            template="aha-moment",
            topics=["test-topic"],
        )

        content = filepath.read_text(encoding="utf-8")

        assert "status: draft" in content
        assert "template: aha-moment" in content
        assert "test-topic" in content

    def test_create_post_includes_word_count(self, mock_profiles_dir):
        """Created post should include word count in frontmatter."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath = create_post_with_frontmatter(profile_name, "one two three four five")

        content = filepath.read_text(encoding="utf-8")

        assert "word_count: 5" in content


class TestPublishPost:
    """Test publishing draft posts."""

    def test_publish_post_moves_to_published(self, mock_profiles_dir):
        """publish_post should move file from drafts to published."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath = create_post_with_frontmatter(profile_name, "Test post content")
        filepath = publish_post(profile_name, filepath.name)

        assert "published" in str(filepath)
        assert not (get_posts_drafts_dir(profile_name) / filepath.name).exists()

    def test_publish_post_updates_frontmatter(self, mock_profiles_dir):
        """publish_post should update status to published in frontmatter."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath = create_post_with_frontmatter(profile_name, "Test content")
        original_filename = filepath.name
        publish_post(profile_name, original_filename)

        published_file = get_posts_published_dir(profile_name) / original_filename
        content = published_file.read_text(encoding="utf-8")

        assert "status: published" in content
        assert "published_date:" in content


class TestUpdateTopics:
    """Test updating post topics."""

    def test_update_post_topics_changes_topics_array(self, mock_profiles_dir):
        """update_post_topics should change the topics array."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath = create_post_with_frontmatter(profile_name, "Test content")
        update_post_topics(profile_name, filepath, ["new-topic", "another-topic"])

        content = filepath.read_text(encoding="utf-8")

        assert "new-topic" in content
        assert "another-topic" in content


class TestListPosts:
    """Test listing posts with filters."""

    def test_list_profile_posts_returns_all_posts(self, mock_profiles_dir):
        """list_profile_posts should return all posts from drafts and published."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        create_post_with_frontmatter(profile_name, "Content 1")
        create_post_with_frontmatter(profile_name, "Content 2")

        posts = list_profile_posts(profile_name)

        assert len(posts) >= 2

    def test_list_profile_posts_filter_by_status_draft(self, mock_profiles_dir):
        """list_profile_posts with status_filter should return only drafts."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        create_post_with_frontmatter(profile_name, "Draft content")

        posts = list_profile_posts(profile_name, status_filter="draft")

        for post in posts:
            assert post["status"] == "draft"

    def test_list_profile_posts_filter_by_topic(self, mock_profiles_dir):
        """list_profile_posts with topic_filter should return posts with that topic."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath1 = create_post_with_frontmatter(profile_name, "Content 1", topics=["ai-ml"])
        filepath2 = create_post_with_frontmatter(profile_name, "Content 2", topics=["career"])

        posts = list_profile_posts(profile_name, topic_filter="ai-ml")

        assert len(posts) >= 1
        for post in posts:
            assert "ai-ml" in post["topics"]


class TestGetPostByFilename:
    """Test finding posts by filename."""

    def test_get_post_by_filename_in_drafts(self, mock_profiles_dir):
        """get_post_by_filename should find posts in drafts."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        filepath = create_post_with_frontmatter(profile_name, "Test content")

        found = get_post_by_filename(profile_name, filepath.name)

        assert found is not None
        assert found == filepath


class TestStats:
    """Test stats tracking."""

    def test_get_post_history_stats_returns_dict(self, mock_profiles_dir):
        """get_post_history_stats should return stats dict."""
        profile_name = "testuser"

        from postcraftin.profile import ensure_profile_dirs, init_history_stats

        ensure_profile_dirs(profile_name)
        init_history_stats(profile_name)

        stats = get_post_history_stats(profile_name)

        assert isinstance(stats, dict)
        assert "total_posts" in stats
        assert "draft_count" in stats
        assert "published_count" in stats


class TestExamplePosts:
    """Test example posts functionality."""

    def test_save_example_post_creates_file(self, mock_profiles_dir):
        """save_example_post should create file in examples/ folder."""
        profile_name = "testuser"
        from postcraftin.profile import ensure_profile_dirs

        ensure_profile_dirs(profile_name)

        from postcraftin.posts import save_example_post, get_posts_examples_dir

        filepath = save_example_post(profile_name, "This is an example post.", 1)

        assert filepath.exists()
        assert "examples" in str(filepath)
        assert filepath.name == "beispiel-1.md"

    def test_save_example_post_has_frontmatter(self, mock_profiles_dir):
        """Example post file should have YAML frontmatter."""
        profile_name = "testuser"
        from postcraftin.profile import ensure_profile_dirs

        ensure_profile_dirs(profile_name)

        from postcraftin.posts import save_example_post, parse_frontmatter

        save_example_post(profile_name, "Example content here.", 2)

        examples_dir = mock_profiles_dir / profile_name / "posts" / "examples"
        filepath = examples_dir / "beispiel-2.md"
        content = filepath.read_text(encoding="utf-8")

        frontmatter, _ = parse_frontmatter(content)
        assert "created" in frontmatter
        assert frontmatter["type"] == "example"
        assert frontmatter["example_num"] == 2
        assert "word_count" in frontmatter

    def test_list_example_posts_returns_list(self, mock_profiles_dir):
        """list_example_posts should return list of example posts."""
        profile_name = "testuser"
        from postcraftin.profile import ensure_profile_dirs

        ensure_profile_dirs(profile_name)

        from postcraftin.posts import save_example_post, list_example_posts

        save_example_post(profile_name, "Example 1", 1)
        save_example_post(profile_name, "Example 2", 2)

        examples = list_example_posts(profile_name)

        assert len(examples) == 2
        assert all("filename" in e for e in examples)
        assert all("content" in e for e in examples)
        assert all("frontmatter" in e for e in examples)

    def test_list_example_posts_empty_when_no_examples(self, mock_profiles_dir):
        """list_example_posts should return empty list when no examples exist."""
        profile_name = "testuser"
        from postcraftin.profile import ensure_profile_dirs

        ensure_profile_dirs(profile_name)

        from postcraftin.posts import list_example_posts

        examples = list_example_posts(profile_name)
        assert examples == []
