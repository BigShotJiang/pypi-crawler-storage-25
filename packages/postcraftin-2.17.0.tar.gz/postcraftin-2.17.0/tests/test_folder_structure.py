"""Tests for folder structure and profile management."""

import pytest
from pathlib import Path
import json

from postcraftin.profile import (
    get_profile_dir,
    get_posts_drafts_dir,
    get_posts_published_dir,
    get_brandguide_dir,
    get_templates_dir,
    get_history_dir,
    ensure_profile_dirs,
    init_history_stats,
    save_profile,
    load_profile,
    list_profiles,
    get_available_topics,
    create_empty_profile,
)


class TestFolderStructure:
    """Test that folder structure is created correctly."""

    def test_ensure_profile_dirs_creates_all_folders(self, mock_profiles_dir, tmp_path):
        """ensure_profile_dirs should create all required subdirectories."""
        profile_name = "testuser"

        ensure_profile_dirs(profile_name)

        profile_dir = get_profile_dir(profile_name)
        assert profile_dir.exists()
        assert (profile_dir / "posts").exists()
        assert (profile_dir / "posts" / "drafts").exists()
        assert (profile_dir / "posts" / "published").exists()
        assert (profile_dir / "brandguide").exists()
        assert (profile_dir / "templates").exists()
        assert (profile_dir / "history").exists()

    def test_get_posts_drafts_dir_returns_correct_path(self, mock_profiles_dir):
        """get_posts_drafts_dir should return path to drafts folder."""
        profile_name = "testuser"
        drafts_dir = get_posts_drafts_dir(profile_name)

        assert drafts_dir.name == "drafts"
        assert drafts_dir.parent.name == "posts"
        assert drafts_dir.parent.parent.name == "testuser"

    def test_get_posts_published_dir_returns_correct_path(self, mock_profiles_dir):
        """get_posts_published_dir should return path to published folder."""
        profile_name = "testuser"
        published_dir = get_posts_published_dir(profile_name)

        assert published_dir.name == "published"
        assert published_dir.parent.name == "posts"

    def test_get_brandguide_dir_returns_correct_path(self, mock_profiles_dir):
        """get_brandguide_dir should return path to brandguide folder."""
        profile_name = "testuser"
        brandguide_dir = get_brandguide_dir(profile_name)

        assert brandguide_dir.name == "brandguide"
        assert brandguide_dir.parent.name == "testuser"

    def test_get_templates_dir_returns_correct_path(self, mock_profiles_dir):
        """get_templates_dir should return path to templates folder."""
        profile_name = "testuser"
        templates_dir = get_templates_dir(profile_name)

        assert templates_dir.name == "templates"
        assert templates_dir.parent.name == "testuser"

    def test_get_history_dir_returns_correct_path(self, mock_profiles_dir):
        """get_history_dir should return path to history folder."""
        profile_name = "testuser"
        history_dir = get_history_dir(profile_name)

        assert history_dir.name == "history"
        assert history_dir.parent.name == "testuser"


class TestProfileStorage:
    """Test profile saving and loading with folder structure."""

    def test_save_profile_creates_config_json(self, mock_profiles_dir, sample_profile):
        """save_profile should create config.json in profile folder."""
        profile_name = "testuser"

        save_profile(profile_name, sample_profile)

        config_path = get_profile_dir(profile_name) / "config.json"
        assert config_path.exists()

        loaded = json.loads(config_path.read_text())
        assert loaded["identity"]["name"] == "Test User"

    def test_load_profile_reads_from_config_json(self, mock_profiles_dir, sample_profile):
        """load_profile should read from config.json."""
        profile_name = "testuser"
        save_profile(profile_name, sample_profile)

        loaded = load_profile(profile_name)

        assert loaded["identity"]["name"] == "Test User"
        assert loaded["identity"]["job_title"] == "Developer"

    def test_list_profiles_returns_saved_profiles(self, mock_profiles_dir, sample_profile):
        """list_profiles should return all saved profiles."""
        save_profile("user1", sample_profile)
        save_profile("user2", sample_profile)

        profiles = list_profiles()

        assert "user1" in profiles
        assert "user2" in profiles


class TestHistoryStats:
    """Test history/stats.json creation and management."""

    def test_init_history_stats_creates_stats_file(self, mock_profiles_dir):
        """init_history_stats should create stats.json with defaults."""
        profile_name = "testuser"
        ensure_profile_dirs(profile_name)

        init_history_stats(profile_name)

        stats_path = get_history_dir(profile_name) / "stats.json"
        assert stats_path.exists()

        stats = json.loads(stats_path.read_text())
        assert stats["total_posts"] == 0
        assert stats["draft_count"] == 0
        assert stats["published_count"] == 0
        assert stats["by_template"] == {}
        assert stats["by_topic"] == {}


class TestTopicExtraction:
    """Test topic extraction from content_strategy.pillars."""

    def test_get_available_topics_from_pillars(self, mock_profiles_dir, sample_profile):
        """get_available_topics should extract topics from pillars."""
        profile_name = "testuser"
        save_profile(profile_name, sample_profile)

        topics = get_available_topics(profile_name)

        assert "ai-ml" in topics

    def test_get_available_topics_empty_when_no_pillars(self, mock_profiles_dir, sample_profile):
        """get_available_topics should return empty list when no pillars."""
        profile_name = "testuser"
        profile_no_pillars = sample_profile.copy()
        profile_no_pillars["content_strategy"]["pillars"] = []
        save_profile(profile_name, profile_no_pillars)

        topics = get_available_topics(profile_name)

        assert topics == []
