import pytest
from postcraftin.generator import _clean_output

class TestCleanOutput:
    """Tests for ESC sequence cleaning using strip-ansi library."""

    def test_removes_standard_ansi(self):
        """Test removal of standard ANSI color codes."""
        text = "\x1b[32mGreen text\x1b[0m normal"
        result = _clean_output(text)
        assert "\x1b" not in result
        assert "Green text" in result
        assert "normal" in result

    def test_removes_ollama_cursor_hide(self):
        """Test removal of ESC[?25l (hide cursor) sequence."""
        text = "Before\x1b[?25lAfter"
        result = _clean_output(text)
        assert "\x1b" not in result
        assert "BeforeAfter" == result

    def test_removes_ollama_sync_start(self):
        """Test removal of ESC[?2026h (begin sync update) sequence."""
        text = "Text\x1b[?2026h more text"
        result = _clean_output(text)
        assert "\x1b" not in result
        assert "Text more text" == result

    def test_removes_ollama_progress(self):
        """Test removal of Ollama progress spinner sequences."""
        text = "\x1b[?25l\x1b[1G⠙ \x1b[K\x1b[?25hNormal text"
        result = _clean_output(text)
        assert "\x1b" not in result
        assert "Normal text" in result
        assert "⠙" not in result

    def test_preserves_newlines(self):
        """Test that newlines are preserved."""
        text = "Line1\nLine2\r\nLine3"
        result = _clean_output(text)
        assert "\n" in result
        assert "\r\n" in result

    def test_preserves_tabs(self):
        """Test that tabs are preserved."""
        text = "Col1\tCol2"
        result = _clean_output(text)
        assert "\t" in result

    def test_empty_string(self):
        """Test empty string handling."""
        assert _clean_output("") == ""

    def test_no_escape_sequences(self):
        """Test text without escape sequences."""
        text = "Just normal text here!"
        assert _clean_output(text) == "Just normal text here!"

    def test_mixed_content(self):
        """Test complex Ollama output with multiple sequence types."""
        text = "\x1b[?25l\x1b[1G⠹ \x1b[K\x1b[?25h\x1b[?2026hContent here\x1b[?2026l end"
        result = _clean_output(text)
        assert "\x1b" not in result
        assert "Content here end" == result
