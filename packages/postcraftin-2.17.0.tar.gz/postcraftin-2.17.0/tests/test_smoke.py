"""Smoke tests for postcraftin core functionality."""

from postcraftin.config import OLLAMA_HOST, DEFAULT_MODEL
from postcraftin.generator import build_prompt


def test_config_defaults():
    """OLLAMA_HOST and DEFAULT_MODEL must be set to non-empty strings."""
    assert OLLAMA_HOST, "OLLAMA_HOST should not be empty"
    assert DEFAULT_MODEL, "DEFAULT_MODEL should not be empty"
    assert OLLAMA_HOST.startswith("http"), "OLLAMA_HOST should be an HTTP URL"


def test_build_prompt_contains_profile_fields():
    """build_prompt() output must contain the topic and key profile fields."""
    topic = "AI in data pipelines"
    profile = {
        "identity": {
            "name": "Max",
            "job_title": "Data Engineer",
            "company": "Tech Corp",
            "industry": "Tech",
            "years_experience": 5,
            "expertise_areas": ["AI", "data"],
        },
        "voice": {
            "archetype": "analytisch",
            "formality": 3,
        },
        "audience": {
            "primary_roles": ["Data Engineers"],
        },
        "content_strategy": {
            "pillars": [{"name": "AI", "weight": 100}],
        },
        "technical_preferences": {
            "output_language": "DE",
            "emoji_style": "Minimal",
            "cta_default": "Question",
        },
        "post_history": {"stylesamples": []},
    }
    result = build_prompt(topic, profile)
    assert topic in result
    assert "Data Engineer" in result
    assert "analytisch" in result
