"""Tests for template system."""

import pytest
from pathlib import Path

from postcraftin.templates import (
    list_templates,
    get_template,
    get_template_with_fallback,
    copy_templates_to_profile,
    TEMPLATE_NAMES,
)


class TestTemplateList:
    """Test template listing."""

    def test_list_templates_returns_10_templates(self):
        """list_templates should return exactly 10 template names."""
        templates = list_templates()

        assert len(templates) == 10

    def test_list_templates_includes_all_expected_names(self):
        """list_templates should include all expected template names."""
        templates = list_templates()

        expected = [
            "verlierer-gewinner",
            "aha-moment",
            "weg-veraenderung",
            "herausforderung",
            "erkenntnisse",
            "experiment",
            "gegen-strom",
            "scheitern",
            "empfehlung",
            "perspektivwechsel",
        ]

        for name in expected:
            assert name in templates


class TestGetTemplate:
    """Test template retrieval."""

    def test_get_package_template_returns_source_package(self):
        """get_template without profile should return source='package'."""
        result = get_template("aha-moment")

        assert result is not None
        assert result["name"] == "aha-moment"
        assert result["source"] == "package"

    def test_get_template_with_underscore_normalized(self):
        """get_template should normalize underscores to hyphens."""
        result = get_template("verlierer_gewinner")

        assert result is not None
        assert result["name"] == "verlierer-gewinner"

    def test_get_template_case_insensitive(self):
        """get_template should be case-insensitive."""
        result = get_template("AHA-MOMENT")

        assert result is not None
        assert result["name"] == "aha-moment"

    def test_get_template_returns_none_for_missing(self):
        """get_template should return None for non-existent template."""
        result = get_template("nonexistent-template")

        assert result is None


class TestTemplatePriorityLookup:
    """Test template lookup priority (profile first, then package)."""

    def test_get_template_with_profile_no_custom_returns_package(self, mock_profiles_dir):
        """get_template with profile but no custom template should return package default."""
        result = get_template("aha-moment", profile_name="nonexistent")

        assert result is not None
        assert result["source"] == "package"

    def test_get_template_with_custom_profile_returns_profile(self, mock_profiles_dir):
        """get_template with custom template in profile should return source='profile'."""
        from postcraftin.profile import get_templates_dir

        profile_name = "testuser"
        templates_dir = get_templates_dir(profile_name)
        templates_dir.mkdir(parents=True, exist_ok=True)

        custom_template = templates_dir / "aha-moment.md"
        custom_template.write_text("---\ntitle: Custom AHA\n---\n\nCustom content", encoding="utf-8")

        result = get_template("aha-moment", profile_name=profile_name)

        assert result is not None
        assert result["source"] == "profile"
        assert "Custom content" in result["content"]


class TestCopyTemplates:
    """Test copying default templates to profile."""

    def test_copy_templates_to_profile_creates_files(self, mock_profiles_dir, tmp_path):
        """copy_templates_to_profile should copy all default templates."""
        from postcraftin.profile import get_templates_dir

        profile_name = "testuser"

        result_dir = copy_templates_to_profile(profile_name)

        assert result_dir.exists()
        assert result_dir.name == "templates"

        copied_files = list(result_dir.glob("*.md"))
        assert len(copied_files) == 10

    def test_copy_templates_does_not_overwrite_existing(self, mock_profiles_dir):
        """copy_templates_to_profile should not overwrite existing custom templates."""
        profile_name = "testuser"

        from postcraftin.profile import get_templates_dir

        templates_dir = get_templates_dir(profile_name)
        templates_dir.mkdir(parents=True, exist_ok=True)

        custom_file = templates_dir / "aha-moment.md"
        custom_file.write_text("Custom content", encoding="utf-8")

        copy_templates_to_profile(profile_name)

        custom_content = custom_file.read_text()
        assert custom_content == "Custom content"
