"""Tests for CLI commands."""

import pytest
from click.testing import CliRunner

from postcraftin.cli import cli


@pytest.fixture
def cli_runner():
    """Return a Click test runner."""
    return CliRunner()


class TestCLI:
    """Test CLI commands."""

    def test_cli_help(self, cli_runner):
        """CLI should show help."""
        result = cli_runner.invoke(cli, ["--help"])

        assert result.exit_code == 0
        assert "Postcraftin" in result.output

    def test_list_profiles_empty(self, cli_runner):
        """list-profiles should work even with no profiles."""
        result = cli_runner.invoke(cli, ["list-profiles"])

        assert result.exit_code == 0

    def test_generate_requires_topic(self, cli_runner):
        """generate should require --topic."""
        result = cli_runner.invoke(cli, ["generate"])

        assert result.exit_code != 0
        assert "Error" in result.output or "Missing" in result.output

    def test_profile_help(self, cli_runner):
        """profile command should show help."""
        result = cli_runner.invoke(cli, ["profile", "--help"])

        assert result.exit_code == 0
        assert "Manage profiles" in result.output

    def test_profile_posts_help(self, cli_runner):
        """profile posts command should show help."""
        result = cli_runner.invoke(cli, ["profile", "posts", "--help"])

        assert result.exit_code == 0

    def test_profile_templates_help(self, cli_runner):
        """profile templates command should show help."""
        result = cli_runner.invoke(cli, ["profile", "templates", "--help"])

        assert result.exit_code == 0

    def test_profile_topics_help(self, cli_runner):
        """profile topics command should show help."""
        result = cli_runner.invoke(cli, ["profile", "topics", "--help"])

        assert result.exit_code == 0


class TestGenerateCommand:
    """Test generate command."""

    def test_generate_with_template_flag(self, cli_runner):
        """generate should accept --template flag with valid templates."""
        result = cli_runner.invoke(
            cli,
            [
                "generate",
                "--topic",
                "Test topic",
                "--template",
                "aha-moment",
                "--profile",
                "nonexistent",
            ],
        )

        assert result.exit_code != 0
        assert "not found" in result.output.lower()

    def test_generate_template_case_insensitive(self, cli_runner):
        """generate --template should be case-insensitive."""
        result = cli_runner.invoke(
            cli,
            [
                "generate",
                "--topic",
                "Test",
                "--template",
                "AHA-MOMENT",
                "--profile",
                "nonexistent",
            ],
        )

        assert result.exit_code != 0


class TestConfigCommands:
    """Test config commands."""

    def test_config_show(self, cli_runner):
        """config command should show config."""
        result = cli_runner.invoke(cli, ["config"])

        assert result.exit_code == 0

    def test_config_model_list(self, cli_runner):
        """config model --list should work (may fail if ollama not running)."""
        result = cli_runner.invoke(cli, ["config", "model", "--list"])

        assert result.exit_code in [0, 1, 2]  # 0=success, 1/2=ollama issue
