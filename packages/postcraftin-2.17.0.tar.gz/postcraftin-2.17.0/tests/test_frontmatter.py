"""Tests for frontmatter parsing and rendering."""

import pytest
from pathlib import Path
import yaml

from postcraftin.posts import (
    parse_frontmatter,
    render_frontmatter,
    create_slug,
    create_post_filename,
)


class TestParseFrontmatter:
    """Test frontmatter parsing."""

    def test_parse_frontmatter_with_valid_frontmatter(self, sample_post_content, sample_frontmatter):
        """parse_frontmatter should correctly parse YAML frontmatter."""
        frontmatter, content = parse_frontmatter(sample_post_content)

        assert frontmatter["created"] == sample_frontmatter["created"]
        assert frontmatter["status"] == sample_frontmatter["status"]
        assert frontmatter["template"] == sample_frontmatter["template"]
        assert frontmatter["topics"] == sample_frontmatter["topics"]
        assert frontmatter["word_count"] == sample_frontmatter["word_count"]

    def test_parse_frontmatter_returns_content_after_frontmatter(self, sample_post_content):
        """parse_frontmatter should return markdown content after frontmatter."""
        _, content = parse_frontmatter(sample_post_content)

        assert "# Test Post" in content
        assert "This is a test post content." in content

    def test_parse_frontmatter_without_frontmatter(self):
        """parse_frontmatter should handle content without frontmatter."""
        content = "# Just a heading\n\nSome text"

        frontmatter, body = parse_frontmatter(content)

        assert frontmatter == {}
        assert body == content

    def test_parse_frontmatter_empty_string(self):
        """parse_frontmatter should handle empty string."""
        frontmatter, body = parse_frontmatter("")

        assert frontmatter == {}
        assert body == ""

    def test_parse_frontmatter_with_empty_topics_array(self):
        """parse_frontmatter should handle empty topics array."""
        content = """---
created: "2026-04-27"
status: draft
topics: []
---

# Post content"""

        frontmatter, body = parse_frontmatter(content)

        assert frontmatter["topics"] == []


class TestRenderFrontmatter:
    """Test frontmatter rendering."""

    def test_render_frontmatter_creates_valid_yaml(self, sample_frontmatter):
        """render_frontmatter should create valid YAML."""
        rendered = render_frontmatter(sample_frontmatter)

        lines = rendered.strip().split("\n")
        yaml_lines = [l for l in lines if l != "---" and not l.startswith("---")]
        yaml_content = "\n".join(yaml_lines)

        parsed = yaml.safe_load(yaml_content)
        assert parsed["created"] == sample_frontmatter["created"]
        assert parsed["status"] == sample_frontmatter["status"]
        assert parsed["template"] == sample_frontmatter["template"]

    def test_render_frontmatter_includes_dashes(self, sample_frontmatter):
        """render_frontmatter should include YAML delimiters."""
        rendered = render_frontmatter(sample_frontmatter)

        assert rendered.startswith("---")
        assert "---" in rendered[3:]

    def test_render_frontmatter_empty_dict(self):
        """render_frontmatter should handle empty dict."""
        rendered = render_frontmatter({})

        assert "---" in rendered


class TestFrontmatterRoundtrip:
    """Test that parse + render roundtrip preserves data."""

    def test_roundtrip_preserves_all_fields(self, sample_frontmatter):
        """parse(render(data)) should equal data."""
        rendered = render_frontmatter(sample_frontmatter)
        frontmatter, _ = parse_frontmatter(rendered)

        assert frontmatter["created"] == sample_frontmatter["created"]
        assert frontmatter["status"] == sample_frontmatter["status"]
        assert frontmatter["template"] == sample_frontmatter["template"]
        assert frontmatter["topics"] == sample_frontmatter["topics"]


class TestSlugAndFilename:
    """Test slug generation and filename creation."""

    def test_create_slug_lowercases(self):
        """create_slug should convert to lowercase."""
        slug = create_slug("HELLO WORLD")
        assert slug == "hello-world"

    def test_create_slug_replaces_spaces_with_hyphens(self):
        """create_slug should replace spaces with hyphens."""
        slug = create_slug("hello world test")
        assert slug == "hello-world-test"

    def test_create_slug_removes_special_chars(self):
        """create_slug should remove special characters."""
        slug = create_slug("hello@world!test")
        assert slug == "helloworldtest"

    def test_create_post_filename_includes_date(self):
        """create_post_filename should include current date."""
        filename = create_post_filename("my test topic")

        from datetime import datetime

        expected_date = datetime.now().strftime("%Y-%m-%d")

        assert filename.startswith(expected_date)
        assert filename.endswith(".md")

    def test_create_post_filename_includes_slug_from_topic(self):
        """create_post_filename slug should be from topic."""
        filename = create_post_filename("my test topic")

        assert "my-test-topic" in filename
