# postcraftin

AI-powered LinkedIn post generator using local LLMs via Ollama. Personalized ghostwriter with 6-module profile system, modular onboarding, and CLI interface.

## Features

- **Local LLMs** — runs fully on your machine via Ollama, no API costs, no data leaks
- **6-Module Profile System** — Identity, Voice, Audience, Content Strategy, Post History, Technical Preferences
- **Modular Onboarding** — Update individual modules with `--module` flag
- **Few-Shot prompting** — provide example posts to calibrate the output to your voice
- **Post length control** — kurz (150–500), mittel (1.200–1.500), lang (1.900–2.500 Zeichen)
- **Multiple profiles** — manage different personas or clients
- **Dynamic Model Selection** — List and select from available Ollama models
- **Config Management** — Global and profile-specific settings
- **Folder-Based Profiles** — Organized storage with drafts/, published/, brandguide/, templates/, history/
- **10 Storytelling Templates** — Verlierer→Gewinner, AHA-Moment, Weg der Veränderung, and more
- **Brand Guide Generator** — Auto-generates voice.md, vocabulary.md, anti-patterns.md
- **YAML Frontmatter** — Posts include metadata (topics, status, word count, LinkedIn URL)

## Requirements

- Python 3.10+
- [Ollama](https://ollama.com) running locally

## Installation

```bash
pip install postcraftin
```

## Usage

```bash
# Create a profile (interactive wizard - 6 modules)
postcraftin onboard --name myprofile

# Update specific module only
postcraftin onboard --name myprofile --module voice

# Generate a LinkedIn post with template
postcraftin generate --topic "The future of AI" --template verlierer-gewinner

# List available templates
postcraftin profile templates list

# Initialize templates to profile folder
postcraftin profile templates init --name myprofile

# Manage posts (drafts/published)
postcraftin profile posts list
postcraftin profile posts show <filename>
postcraftin profile posts publish <filename>
postcraftin profile posts set-topics <filename> --topics "AI,Future"

# Generate/regenerate brand guide
postcraftin profile brandguide --name myprofile --regenerate

# List available Ollama models
postcraftin models

# Select model interactively
postcraftin config model --select

# Show global config
postcraftin config

# Set profile-specific model
postcraftin profile set myprofile model gemma4:e2b

# List all profiles
postcraftin list-profiles
```

## Default Model

`gemma4:e2b` — the default model for LinkedIn post generation.

**First time?** Pull the model with:

```bash
ollama pull gemma4:e2b
```

**Want a different model?** Browse all available models at:
https://ollama.com/library

## Configuration

| Setting | Location | Description |
|---------|----------|-------------|
| Global Model | `~/.postcraftin/config.json` | Default model for all profiles |
| Profile Model | `~/.postcraftin/profiles/{name}/config.json` | Profile-specific model (optional) |
| Profiles | `~/.postcraftin/profiles/{name}/` | Folder-based profile storage |
| Drafts | `~/.postcraftin/profiles/{name}/posts/drafts/` | Draft posts with frontmatter |
| Published | `~/.postcraftin/profiles/{name}/posts/published/` | Published posts with LinkedIn URL |
| Templates | `~/.postcraftin/profiles/{name}/templates/` | Custom storytelling templates |
| Brand Guide | `~/.postcraftin/profiles/{name}/brandguide/` | voice.md, vocabulary.md, anti-patterns.md |
| History | `~/.postcraftin/profiles/{name}/history/` | Post statistics and analytics |

## License

MIT

## Contributing

Contributions welcome! Open an issue or PR.

Thank you to all contributors!

Built with ❤️ for the LinkedIn community.

Open source forever.