import json
import shutil
from datetime import datetime
from pathlib import Path

PROFILES_DIR = Path.home() / ".postcraftin" / "profiles"
SCHEMA_VERSION = "2.0"

DEFAULT_PROFILE_V2 = {
    "meta": {"version": SCHEMA_VERSION, "created_at": None, "last_updated": None, "interview_completed": False},
    "identity": {
        "name": "",
        "job_title": "",
        "company": "",
        "is_freelance": False,
        "industry": "",
        "years_experience": 0,
        "expertise_areas": [],
        "recent_transformation": "",
    },
    "voice": {
        "formality": 3,
        "archetype": "inspirierend",
        "humor_level": "gelegentlich",
        "sentence_style": "mixtur",
        "personal_ratio": "50%",
    },
    "audience": {
        "primary_roles": [],
        "secondary_roles": [],
        "industries": [],
        "seniority_focus": [],
        "company_size": [],
        "geography": "DACH",
        "language": "DE",
        "follower_count": 0,
        "connection_intent": "Follow",
    },
    "content_strategy": {
        "pillars": [{"name": "General", "weight": 100, "subtopics": [], "post_types": ["insight"]}],
        "posting_frequency": "3x per week",
        "preferred_days": ["Di", "Do", "Mo"],
        "preferred_time": "08:00-10:00",
        "content_goals": ["Thought Leadership", "Network Growth"],
    },
    "post_history": {"top_posts": [], "stylesamples": [], "performance_metrics": {}},
    "technical_preferences": {
        "model": "",
        "output_language": "DE",
        "post_length_target": "Medium",
        "emoji_style": "Minimal",
        "hashtag_style": "Standard",
        "cta_default": "Question",
        "formatting_style": "Gemischt",
        "include_hook_suggestion": True,
        "post_variants_count": 1,
    },
}


def _slugify(text: str) -> str:
    """Convert text to slug format."""
    import re

    text = text.lower()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_-]+", "-", text)
    return text.strip("-")


def get_profile_dir(name: str) -> Path:
    """Get profile folder path."""
    return PROFILES_DIR / name


def get_profile_config_path(name: str) -> Path:
    """Get profile config.json path."""
    return get_profile_dir(name) / "config.json"


def get_posts_drafts_dir(name: str) -> Path:
    """Get profile drafts directory."""
    return get_profile_dir(name) / "posts" / "drafts"


def get_posts_published_dir(name: str) -> Path:
    """Get profile published directory."""
    return get_profile_dir(name) / "posts" / "published"


def get_posts_dir(name: str) -> Path:
    """Get profile posts directory."""
    return get_profile_dir(name) / "posts"


def get_brandguide_dir(name: str) -> Path:
    """Get brandguide directory."""
    return get_profile_dir(name) / "brandguide"


def get_templates_dir(name: str) -> Path:
    """Get templates directory."""
    return get_profile_dir(name) / "templates"


def get_posts_examples_dir(name: str) -> Path:
    """Get profile examples directory for Beispielposts."""
    return get_profile_dir(name) / "posts" / "examples"


def get_history_dir(name: str) -> Path:
    """Get history directory."""
    return get_profile_dir(name) / "history"


def ensure_profile_dirs(name: str) -> None:
    """Create all profile directories."""
    profile_dir = get_profile_dir(name)
    (profile_dir / "posts" / "drafts").mkdir(parents=True, exist_ok=True)
    (profile_dir / "posts" / "published").mkdir(parents=True, exist_ok=True)
    (profile_dir / "posts" / "examples").mkdir(parents=True, exist_ok=True)
    (profile_dir / "brandguide").mkdir(parents=True, exist_ok=True)
    (profile_dir / "templates").mkdir(parents=True, exist_ok=True)
    (profile_dir / "history").mkdir(parents=True, exist_ok=True)


def init_history_stats(name: str) -> None:
    """Initialize history/stats.json for a profile."""
    history_dir = get_history_dir(name)
    stats_path = history_dir / "stats.json"
    if not stats_path.exists():
        stats = {
            "total_posts": 0,
            "draft_count": 0,
            "published_count": 0,
            "last_post": None,
            "by_template": {},
            "by_topic": {},
        }
        with open(stats_path, "w", encoding="utf-8") as f:
            json.dump(stats, f, indent=2)


def get_available_topics(name: str) -> list[str]:
    """Get available topics from content_strategy.pillars."""
    try:
        profile = load_profile(name)
        pillars = profile.get("content_strategy", {}).get("pillars", [])
        topics = []
        for pillar in pillars:
            name = pillar.get("name", "")
            if name:
                topics.append(_slugify(name))
        return topics
    except Exception:
        return []


def migrate_profile(data: dict) -> dict:
    """Migrate v1 profile to v2 schema with defaults."""
    if data.get("meta", {}).get("version") == SCHEMA_VERSION:
        return data

    now = datetime.now().isoformat()

    return {
        "meta": {
            "version": SCHEMA_VERSION,
            "created_at": data.get("created_at", now),
            "last_updated": now,
            "interview_completed": data.get("interview_completed", False),
        },
        "identity": {
            "name": data.get("name", ""),
            "job_title": data.get("role", ""),
            "company": data.get("company", ""),
            "is_freelance": data.get("is_freelance", False),
            "industry": data.get("industry", ""),
            "years_experience": data.get("years_experience", 0),
            "expertise_areas": data.get("keywords", []),
            "recent_transformation": data.get("recent_transformation", ""),
        },
        "voice": {
            "formality": data.get("formality", 3),
            "archetype": data.get("tonality", "inspirierend"),
            "humor_level": data.get("humor_level", "gelegentlich"),
            "sentence_style": data.get("sentence_style", "mixtur"),
            "personal_ratio": data.get("personal_ratio", "50%"),
        },
        "audience": {
            "primary_roles": [],
            "secondary_roles": [],
            "industries": [],
            "seniority_focus": [],
            "company_size": [],
            "geography": data.get("geography", "DACH"),
            "language": data.get("language", "DE"),
            "follower_count": 0,
            "connection_intent": data.get("connection_intent", "Follow"),
        },
        "content_strategy": {
            "pillars": [
                {"name": "General", "weight": 100, "subtopics": data.get("keywords", []), "post_types": ["insight"]}
            ],
            "posting_frequency": data.get("posting_frequency", "3x per week"),
            "preferred_days": data.get("preferred_days", ["Di", "Do", "Mo"]),
            "preferred_time": data.get("preferred_time", "08:00-10:00"),
            "content_goals": data.get("content_goals", ["Thought Leadership", "Network Growth"]),
        },
        "post_history": {"top_posts": [], "stylesamples": data.get("example_posts", []), "performance_metrics": {}},
        "technical_preferences": {
            "model": data.get("model", ""),
            "output_language": data.get("output_language", "DE"),
            "post_length_target": data.get("post_length_target", "Medium"),
            "emoji_style": data.get("emoji_style", "Minimal"),
            "hashtag_style": data.get("hashtag_style", "Standard"),
            "cta_default": data.get("cta_default", "Question"),
            "formatting_style": data.get("formatting_style", "Gemischt"),
            "include_hook_suggestion": data.get("include_hook_suggestion", True),
            "post_variants_count": data.get("post_variants_count", 1),
        },
    }


def get_schema_fields() -> list[str]:
    """Return list of required top-level profile fields."""
    return list(DEFAULT_PROFILE_V2.keys())


def create_empty_profile() -> dict:
    """Create a new empty profile with defaults."""
    now = datetime.now().isoformat()
    profile = DEFAULT_PROFILE_V2.copy()
    profile["meta"]["created_at"] = now
    profile["meta"]["last_updated"] = now
    return profile


def migrate_old_profile_locations() -> None:
    """Migrate profiles from old locations to ~/.postcraftin/profiles/."""
    import shutil

    # Check old location with double "postcraftin"
    old_double = Path.home() / "AppData" / "Local" / "postcraftin" / "postcraftin" / "profiles"
    if old_double.exists():
        for item in old_double.iterdir():
            if item.is_dir():
                dest = PROFILES_DIR / item.name
                if not dest.exists():
                    shutil.copytree(item, dest)
                    print(f"Migrated: {item.name} from old double-path location")
        # Optionally remove old location after successful migration
        # shutil.rmtree(old_double)

    # Check ~/.postcraftin/ directly (old flat profiles)
    old_flat = Path.home() / ".postcraftin"
    if old_flat.exists():
        for json_file in old_flat.glob("*.json"):
            profile_name = json_file.stem
            dest_dir = PROFILES_DIR / profile_name
            if not dest_dir.exists():
                dest_dir.mkdir(parents=True, exist_ok=True)
                shutil.move(str(json_file), str(dest_dir / "config.json"))
                print(f"Migrated flat profile: {profile_name}")


def migrate_flat_profile(name: str) -> bool:
    """Migrate flat JSON profile to folder structure. Returns True if migrated."""
    old_path = PROFILES_DIR / f"{name}.json"
    if not old_path.exists():
        return False
    new_config_path = get_profile_config_path(name)
    if new_config_path.exists():
        old_path.unlink()
        return False
    ensure_profile_dirs(name)
    shutil.move(str(old_path), str(new_config_path))
    init_history_stats(name)
    return True


def validate_profile(data: dict) -> tuple[bool, list[str]]:
    """Validate profile has required fields. Returns (is_valid, errors)."""
    errors = []
    required_top = get_schema_fields()

    for field in required_top:
        if field not in data:
            errors.append(f"Missing required field: {field}")

    voice = data.get("voice", {})
    valid_archetypes = ["analytisch", "inspirierend", "lehrend", "storytelling", "provokativ"]
    if voice.get("archetype") not in valid_archetypes:
        errors.append(f"voice.archetype must be one of: {valid_archetypes}")

    return (len(errors) == 0, errors)


def save_profile(name: str, data: dict) -> None:
    ensure_profile_dirs(name)

    if "meta" not in data:
        data = migrate_profile(data)

    data["meta"]["last_updated"] = datetime.now().isoformat()

    config_path = get_profile_config_path(name)
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def load_profile(name: str) -> dict:
    migrate_flat_profile(name)
    config_path = get_profile_config_path(name)
    if not config_path.exists():
        raise FileNotFoundError(f"Profile '{name}' not found at {config_path}")
    with open(config_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        return migrate_profile(data)


def list_profiles() -> list[str]:
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    profile_dirs = [d.name for d in PROFILES_DIR.iterdir() if d.is_dir()]
    flat_jsons = [p.stem for p in PROFILES_DIR.glob("*.json")]
    return list(set(profile_dirs + flat_jsons))


def get_default_profile_name() -> str | None:
    profiles = list_profiles()
    return profiles[0] if profiles else None
