from pathlib import Path
from typing import Any

TEMPLATE_DIR = Path(__file__).parent

TEMPLATE_NAMES = [
    "verlierer-gewinner",
    "aha-moment",
    "weg-veraenderung",
    "herausforderung",
    "erkenntnisse",
    "experiment",
    "gegen-strom",
    "scheitern",
    "empfehlung",
    "perspektivwechsel",
]


def list_templates() -> list[str]:
    """List all available template names."""
    return TEMPLATE_NAMES.copy()


def get_template(name: str, profile_name: str | None = None) -> dict[str, Any] | None:
    """Get template content by name.

    Searches in priority order:
    1. Profile templates folder (~/.postcraftin/profiles/{name}/templates/)
    2. Package defaults (postcraftin/templates/)

    Args:
        name: Template name (e.g., "verlierer-gewinner")
        profile_name: Optional profile name for custom template lookup

    Returns:
        Dict with name and content, or None if not found

    """
    name = name.lower().replace("_", "-")

    # Priority 1: Check profile custom templates
    if profile_name:
        from postcraftin.profile import get_templates_dir

        profile_template_path = get_templates_dir(profile_name) / f"{name}.md"
        if profile_template_path.exists():
            content = profile_template_path.read_text(encoding="utf-8")
            return {"name": name, "content": content, "source": "profile"}

    # Priority 2: Fall back to package defaults
    filepath = TEMPLATE_DIR / f"{name}.md"
    if not filepath.exists():
        return None

    content = filepath.read_text(encoding="utf-8")
    return {"name": name, "content": content, "source": "package"}


def get_template_with_fallback(name: str, profile_name: str | None = None) -> dict[str, Any] | None:
    """Get template, preferring profile custom version over default.

    This is an alias for get_template() - kept for clarity.
    """
    return get_template(name, profile_name)


def get_all_templates() -> dict[str, dict[str, Any]]:
    """Get all templates as dict."""
    templates = {}
    for name in TEMPLATE_NAMES:
        tmpl = get_template(name)
        if tmpl:
            templates[name] = tmpl
    return templates


def copy_templates_to_profile(profile_name: str) -> Path:
    """Copy all default templates to profile's templates folder."""
    from postcraftin.profile import get_templates_dir

    dest_dir = get_templates_dir(profile_name)
    dest_dir.mkdir(parents=True, exist_ok=True)

    for name in TEMPLATE_NAMES:
        src = TEMPLATE_DIR / f"{name}.md"
        dest = dest_dir / f"{name}.md"
        if src.exists() and not dest.exists():
            dest.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")

    return dest_dir
