import logging
import subprocess

from strip_ansi import strip_ansi
from postcraftin.config_manager import get_model as get_config_model

logger = logging.getLogger(__name__)

POST_LENGTHS = {
    "kurz": {
        "zeichen": "150-500",
        "woerter": "25-85",
        "beschreibung": "Kurzer Post für schnelle Insights und Umfragen",
    },
    "mittel": {
        "zeichen": "1.200-1.500",
        "woerter": "200-260",
        "beschreibung": "Optimaler Bereich für höchstes Engagement",
    },
    "lang": {"zeichen": "1.900-2.500", "woerter": "320-425", "beschreibung": "Tiefergehende Analysen und Case Studies"},
}


def _build_few_shot_block(profile: dict, profile_name: str = "") -> str:
    """Build few-shot examples block from example posts.

    Args:
        profile: Profile dict (kept for backward compatibility)
        profile_name: Profile name to load example files

    """
    # Try to load from files first (new method)
    if profile_name:
        try:
            from postcraftin.posts import list_example_posts

            examples = list_example_posts(profile_name)
            if examples:
                block = "\n\nHier sind Beispiele meines Schreibstils:\n"
                for i, ex in enumerate(examples, 1):
                    block += f"\n--- Beispiel {i} ---\n{ex['content']}\n"
                return block
        except Exception:
            pass

    # Fallback to JSON array (old method, for backward compatibility)
    examples = profile.get("post_history", {}).get("stylesamples", [])
    if not examples:
        return ""
    block = "\n\nHier sind Beispiele meines Schreibstils:\n"
    for i, ex in enumerate(examples, 1):
        block += f"\n--- Beispiel {i} ---\n{ex}\n"
    return block


def _get_archetype_instructions(archetype: str) -> str:
    """Get specific instructions based on voice archetype."""
    archetypes = {
        "analytisch": (
            "Verwende Fakten, Daten und logische Argumente. "
            "Strukturiere mit Bullet-Points wo sinnvoll. "
            "Bleibe objektiv und sachlich."
        ),
        "inspirierend": (
            "Verwende positive, motivierende Sprache. "
            "Beziehe den Leser mit 'du' und 'wir' ein. "
            "Baue Spannung mit Story-Elementen. "
            "Ende mit klarer, aufbauender CTA."
        ),
        "lehrend": (
            "Strukturiere klar mit Schritten oder Listen. "
            "Erkläre das 'Warum' hinter jedem Punkt. "
            "Biete echten Wert — Leser soll direkt umsetzen können. "
            "Ende mit Einladung zur Diskussion."
        ),
        "storytelling": (
            "Erzähle eine authentische Geschichte mit Setup, Conflict, Resolution. "
            "Verwende Dialoge und sinnliche Details. "
            "Sei authentisch — auch Schwächen zeigen. "
            "Die Moral kommt organisch am Ende."
        ),
        "provokativ": (
            "Nimm eine klare, polarisierende Position. "
            "Verwende starke, direkte Sprache. "
            "Fordere Leser heraus zu widersprechen. "
            "Bleib konstruktiv — kein reiner Troll."
        ),
    }
    return archetypes.get(archetype, "")


SYSTEM_PROMPT = (
    "Du bist ein professioneller LinkedIn-Content-Schreiber.\n"
    "- Antworte ausschließlich auf Deutsch.\n"
    "- Verwende KEINE Emojis, Emoticons oder Unicode-Symbole (wie ✨, 🚀, 💡, etc.).\n"
    "- Verwende keine englischen Begriffe oder Sätze.\n"
    "- Achte auf korrekte Rechtschreibung und Grammatik.\n"
    "- Schreibe in einem professionellen, seriösen Ton."
)


def _get_voice_instructions(voice: dict, archetype_instr: str, archetype: str = "inspirierend") -> str:
    """Build comprehensive voice instructions from all voice fields."""
    formality = voice.get("formality", 3)
    formality_map = {1: "sehr locker", 2: "locker", 3: "mittel", 4: "formell", 5: "sehr formell"}
    humor = voice.get("humor_level", "gelegentlich")
    humor_map = {
        "kein": "Kein Humor - sachlich und professionell",
        "gelegentlich": "Gelegentlich witzige Bemerkungen oder Ironie einbauen",
        "regelmäßig": "Regelmäßig Witze, Ironie, lustige Anekdoten einbauen",
    }
    humor_text = humor_map.get(humor, humor_map["gelegentlich"])
    sentence_style = voice.get("sentence_style", "mixtur")
    personal_ratio = voice.get("personal_ratio", "50%")
    ratio_num = int(personal_ratio.replace("%", "")) if personal_ratio.replace("%", "").isdigit() else 50

    if sentence_style == "kurz":
        satz_text = "kurze, prägnante Sätze"
    elif sentence_style == "lang":
        satz_text = "lange, detaillierte Sätze"
    else:
        satz_text = "Mischung aus kurzen und langen Sätzen"

    instr_parts = [
        f"Archetype: {archetype}",
        archetype_instr,
        f"Formality: {formality}/5 ({formality_map.get(formality, 'mittel')}).",
        f"Humor: {humor_text}.",
        f"Satzstil: {satz_text}.",
        f"Persönlich/Professionell: {personal_ratio} persönlich, {100 - ratio_num}% professionell."
        if personal_ratio != "50%"
        else "Ausgewogene Mischung aus persönlich und professionell.",
    ]
    return " ".join([p for p in instr_parts if p])


def _get_audience_instructions(audience: dict) -> str:
    """Build audience instructions from all audience fields."""
    parts = []

    primary = audience.get("primary_roles", [])
    if primary:
        parts.append(f"Zielgruppe: {', '.join(primary)}")

    secondary = audience.get("secondary_roles", [])
    if secondary:
        parts.append(f"Sekundär ansprechen: {', '.join(secondary)}")

    industries = audience.get("industries", [])
    if industries:
        parts.append(f"Branchen: {', '.join(industries)}")

    seniority = audience.get("seniority_focus", [])
    if seniority:
        parts.append(f"Erfahrungs-Level: {', '.join(seniority)}")

    company_size = audience.get("company_size", [])
    if company_size:
        parts.append(f"Unternehmensgröße: {', '.join(company_size)}")

    geography = audience.get("geography", "")
    if geography:
        parts.append(f"Region: {geography}")

    intent = audience.get("connection_intent", "")
    if intent:
        parts.append(f"Leser-Ziel: Soll {intent} tun/machen")

    return " | ".join(parts) if parts else "Fachleute auf LinkedIn"


def _get_content_strategy_instructions(cs: dict) -> str:
    """Build content strategy instructions."""
    parts = []

    freq = cs.get("posting_frequency", "")
    if freq:
        parts.append(f"Posting-Frequenz: {freq}")

    days = cs.get("preferred_days", [])
    if days:
        parts.append(f"Beste Tage: {', '.join(days)}")

    time = cs.get("preferred_time", "")
    if time:
        parts.append(f"Beste Uhrzeit: {time}")

    goals = cs.get("content_goals", [])
    if goals:
        parts.append(f"Ziele: {', '.join(goals)}")

    return " ".join(parts) if parts else ""


def _get_technical_instructions(tp: dict, post_length: str, length_info: dict) -> str:
    """Build technical instructions from all technical_preferences fields."""
    parts = []

    lang = tp.get("output_language", "DE")
    if lang:
        parts.append(f"Sprache: {lang}")

    target = POST_LENGTHS.get(post_length.lower(), POST_LENGTHS["mittel"])
    parts.append(f"Länge: ca. {target['zeichen']} Zeichen ({target['woerter']} Wörter)")

    emoji = tp.get("emoji_style", "Minimal")
    parts.append(f"Emojis: {emoji}")

    hashtag = tp.get("hashtag_style", "Standard")
    parts.append(f"Hashtags: {hashtag}")

    cta = tp.get("cta_default", "Question")
    cta_text = "Maximal 1 Frage am Ende" if cta == "Question" else cta
    parts.append(f"CTA: {cta_text}")

    format_style = tp.get("formatting_style", "Gemischt")
    if format_style:
        parts.append(f"Format: {format_style}")

    hook = tp.get("include_hook_suggestion", True)
    parts.append(f"Hook-Vorschlag: {'ja' if hook else 'nein'}")

    return " | ".join(parts)


def build_prompt(topic: str, profile: dict, post_length: str = "mittel", profile_name: str = "") -> str:
    identity = profile.get("identity", {})
    voice = profile.get("voice", {})
    audience = profile.get("audience", {})
    cs = profile.get("content_strategy", {})
    tp = profile.get("technical_preferences", {})

    role = identity.get("job_title", "")
    name = identity.get("name", "")
    company = identity.get("company", "")
    years = identity.get("years_experience", 0)
    industry = identity.get("industry", "")
    expertise = identity.get("expertise_areas", [])

    archetype = voice.get("archetype", "inspirierend")
    archetype_instr = _get_archetype_instructions(archetype)
    voice_instr = _get_voice_instructions(voice, archetype_instr, archetype)

    audience_instr = _get_audience_instructions(audience)

    pillars = cs.get("pillars", [])
    topics = ", ".join([p.get("name", "") for p in pillars[:3] if p.get("name")]) or "relevant"

    cs_instr = _get_content_strategy_instructions(cs)

    few_shot = _build_few_shot_block(profile, profile_name)
    length_info = POST_LENGTHS.get(post_length.lower(), POST_LENGTHS["mittel"])
    tech_instr = _get_technical_instructions(tp, post_length, length_info)

    prompt = (
        f"{SYSTEM_PROMPT}\n\n"
        f"=== IDENTITY ===\n"
        f"Name: {name}\n"
        f"Rolle: {role}\n"
        f"Unternehmen: {company}\n"
        f"Berufserfahrung: {years} Jahre\n"
        f"Branche: {industry}\n"
        f"Expertise: {', '.join(expertise) if expertise else 'general'}\n"
        f"Transformation: {identity.get('recent_transformation', '')}\n\n"
        f"=== VOICE ===\n{voice_instr}\n\n"
        f"=== AUDIENCE ===\n{audience_instr}\n\n"
        f"=== CONTENT STRATEGY ===\n"
        f"Themen: {topics}\n"
        f"{cs_instr}\n"
        f"{few_shot}\n\n"
        f"=== GENERATION ===\n"
        f"Schreibe einen LinkedIn-Post über:\n{topic}\n\n"
        f"{tech_instr}\n"
        f"Starker Hook in den ersten 210 Zeichen.\n"
        f"Klare Absätze mit Leerzeilen."
    )
    return prompt


def generate_post(  # noqa: C901
    topic: str,
    profile: dict,
    post_length: str = "mittel",
    model: str | None = None,
    return_content: bool = False,
    profile_name: str = "",
) -> str:
    """Generate a LinkedIn post using ollama CLI (more reliable than API on Windows).

    Args:
        topic: The topic for the post
        profile: User profile dict
        post_length: One of kurz, mittel, lang
        model: Ollama model to use (optional)
        return_content: If True, return generated content; if False, print directly
        profile_name: Profile name for loading example posts

    Returns:
        Generated post content if return_content=True, else empty string

    """
    if model is None:
        model = get_config_model()

    user_prompt = build_prompt(topic, profile, post_length, profile_name)

    extra_args: list[str] = ["--hidethinking"] if model.startswith("gemma") else []

    print(f"[Generating with {model}...]\n", flush=True)

    process: subprocess.Popen | None = None
    output_lines: list[str] = []

    try:
        process = subprocess.Popen(
            ["ollama", "run", model] + extra_args + [user_prompt],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            universal_newlines=True,
        )

        if process.stdout is None:
            print("[Error: Failed to start ollama process]")
            return ""

        for line in process.stdout:
            output_lines.append(line)
            if not return_content:
                print(line, end="", flush=True)

        process.wait(timeout=300)

        if process.returncode != 0:
            print(f"\n[Error: ollama exited with code {process.returncode}]")

    except subprocess.TimeoutExpired:
        if process:
            process.kill()
        print("\n[Timeout: Generation took too long. Try a shorter prompt.]")
    except FileNotFoundError:
        print("\n[Error: ollama not found. Make sure it's installed.]")
    except Exception as e:
        print(f"\n[Error: {e}]")
        logger.error(f"Generation error: {e}")

    if return_content:
        return "".join(output_lines)
    return ""


def _clean_output(text: str) -> str:
    """Remove ESC sequences and control characters from text."""
    import re

    # First remove standard ANSI codes
    text = strip_ansi(text)
    # Remove Ollama-specific patterns: ESC[?25l, ESC[?2026h, [1G, [K, etc.
    # Pattern matches:
    #   \x1b\[(\?[0-9;]*)?[0-9;]*[a-zA-Z]  - ESC[ sequences with optional ? (DEC private mode)
    #   \[[0-9;]*[GK]                       - bare CSI sequences without ESC (e.g., [1G, [K)
    ollama_pattern = re.compile(r"\x1b\[(\?[0-9;]*)?[0-9;]*[a-zA-Z]|\[[0-9;]*[GK]")
    text = ollama_pattern.sub("", text)
    # Remove any remaining ESC characters
    text = text.replace("\x1b", "")
    # Remove Ollama progress spinner characters (Braille patterns U+2800-U+28FF)
    text = re.sub(r"[\u2800-\u28FF]", "", text)
    # Remove control chars except newline, CR, tab
    text = "".join(ch for ch in text if ord(ch) >= 32 or ch in "\n\r\t")
    return text.strip()
